target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3, i64 %p_a4) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %callresult84 = alloca [24 x i8], align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %callresult366 = alloca [16 x i8], align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %callresult497 = alloca [16 x i8], align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  store i64 %p_a4, ptr %slot6, align 8
  %v551 = load i64, ptr %slot1, align 8
  %op552 = add i64 %v551, 32
  store i64 %op552, ptr %slot7, align 8
  %mem553 = alloca i8, i64 24, align 8
  %ptr554 = ptrtoint ptr %mem553 to i64
  store i64 %ptr554, ptr %slot8, align 8
  %mem555 = alloca i8, i64 8, align 8
  %ptr556 = ptrtoint ptr %mem555 to i64
  store i64 %ptr556, ptr %slot9, align 8
  %mem557 = alloca i8, i64 8, align 8
  %ptr558 = ptrtoint ptr %mem557 to i64
  store i64 %ptr558, ptr %slot10, align 8
  %mem559 = alloca i8, i64 8, align 8
  %ptr560 = ptrtoint ptr %mem559 to i64
  store i64 %ptr560, ptr %slot11, align 8
  %mem561 = alloca i8, i64 8, align 8
  %ptr562 = ptrtoint ptr %mem561 to i64
  store i64 %ptr562, ptr %slot12, align 8
  %mem563 = alloca i8, i64 8, align 8
  %ptr564 = ptrtoint ptr %mem563 to i64
  store i64 %ptr564, ptr %slot13, align 8
  %mem565 = alloca i8, i64 8, align 8
  %ptr566 = ptrtoint ptr %mem565 to i64
  store i64 %ptr566, ptr %slot14, align 8
  %mem567 = alloca i8, i64 8, align 8
  %ptr568 = ptrtoint ptr %mem567 to i64
  store i64 %ptr568, ptr %slot15, align 8
  %mem569 = alloca i8, i64 8, align 8
  %ptr570 = ptrtoint ptr %mem569 to i64
  store i64 %ptr570, ptr %slot16, align 8
  %mem571 = alloca i8, i64 8, align 8
  %ptr572 = ptrtoint ptr %mem571 to i64
  store i64 %ptr572, ptr %slot17, align 8
  %mem573 = alloca i8, i64 8, align 8
  %ptr574 = ptrtoint ptr %mem573 to i64
  store i64 %ptr574, ptr %slot18, align 8
  %mem575 = alloca i8, i64 8, align 8
  %ptr576 = ptrtoint ptr %mem575 to i64
  store i64 %ptr576, ptr %slot19, align 8
  %mem577 = alloca i8, i64 304, align 8
  %ptr578 = ptrtoint ptr %mem577 to i64
  store i64 %ptr578, ptr %slot20, align 8
  %mem579 = alloca i8, i64 304, align 8
  %ptr580 = ptrtoint ptr %mem579 to i64
  store i64 %ptr580, ptr %slot21, align 8
  %mem581 = alloca i8, i64 8, align 8
  %ptr582 = ptrtoint ptr %mem581 to i64
  store i64 %ptr582, ptr %slot22, align 8
  %mem583 = alloca i8, i64 8, align 8
  %ptr584 = ptrtoint ptr %mem583 to i64
  store i64 %ptr584, ptr %slot23, align 8
  %mem585 = alloca i8, i64 304, align 8
  %ptr586 = ptrtoint ptr %mem585 to i64
  store i64 %ptr586, ptr %slot24, align 8
  %mem587 = alloca i8, i64 8, align 8
  %ptr588 = ptrtoint ptr %mem587 to i64
  store i64 %ptr588, ptr %slot25, align 8
  %mem589 = alloca i8, i64 8, align 8
  %ptr590 = ptrtoint ptr %mem589 to i64
  store i64 %ptr590, ptr %slot26, align 8
  %mem591 = alloca i8, i64 8, align 8
  %ptr592 = ptrtoint ptr %mem591 to i64
  store i64 %ptr592, ptr %slot27, align 8
  %mem593 = alloca i8, i64 8, align 8
  %ptr594 = ptrtoint ptr %mem593 to i64
  store i64 %ptr594, ptr %slot28, align 8
  %mem595 = alloca i8, i64 8, align 8
  %ptr596 = ptrtoint ptr %mem595 to i64
  store i64 %ptr596, ptr %slot29, align 8
  %mem597 = alloca i8, i64 16, align 8
  %ptr598 = ptrtoint ptr %mem597 to i64
  store i64 %ptr598, ptr %slot30, align 8
  %mem599 = alloca i8, i64 208, align 8
  %ptr600 = ptrtoint ptr %mem599 to i64
  store i64 %ptr600, ptr %slot31, align 8
  %mem601 = alloca i8, i64 208, align 8
  %ptr602 = ptrtoint ptr %mem601 to i64
  store i64 %ptr602, ptr %slot32, align 8
  %mem603 = alloca i8, i64 8, align 8
  %ptr604 = ptrtoint ptr %mem603 to i64
  store i64 %ptr604, ptr %slot33, align 8
  %mem605 = alloca i8, i64 8, align 8
  %ptr606 = ptrtoint ptr %mem605 to i64
  store i64 %ptr606, ptr %slot34, align 8
  %mem607 = alloca i8, i64 8, align 8
  %ptr608 = ptrtoint ptr %mem607 to i64
  store i64 %ptr608, ptr %slot35, align 8
  %mem609 = alloca i8, i64 8, align 8
  %ptr610 = ptrtoint ptr %mem609 to i64
  store i64 %ptr610, ptr %slot36, align 8
  %mem611 = alloca i8, i64 304, align 8
  %ptr612 = ptrtoint ptr %mem611 to i64
  store i64 %ptr612, ptr %slot37, align 8
  %mem613 = alloca i8, i64 24, align 8
  %ptr614 = ptrtoint ptr %mem613 to i64
  store i64 %ptr614, ptr %slot38, align 8
  %mem615 = alloca i8, i64 24, align 8
  %ptr616 = ptrtoint ptr %mem615 to i64
  store i64 %ptr616, ptr %slot39, align 8
  %mem617 = alloca i8, i64 304, align 8
  %ptr618 = ptrtoint ptr %mem617 to i64
  store i64 %ptr618, ptr %slot40, align 8
  %mem619 = alloca i8, i64 208, align 8
  %ptr620 = ptrtoint ptr %mem619 to i64
  store i64 %ptr620, ptr %slot41, align 8
  %mem621 = alloca i8, i64 208, align 8
  %ptr622 = ptrtoint ptr %mem621 to i64
  store i64 %ptr622, ptr %slot42, align 8
  %mem623 = alloca i8, i64 24, align 8
  %ptr624 = ptrtoint ptr %mem623 to i64
  store i64 %ptr624, ptr %slot43, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem625 = alloca i8, i64 8, align 8
  %ptr626 = ptrtoint ptr %mem625 to i64
  store i64 %ptr626, ptr %slot44, align 8
  %v627 = load i64, ptr %slot1, align 8
  %op628 = add i64 %v627, 64
  store i64 %op628, ptr %slot45, align 8
  %v629 = load i64, ptr %slot45, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %ld631 = load i64, ptr %p630, align 8, !alias.scope !4, !noalias !3
  store i64 %ld631, ptr %slot46, align 8
  %stack632 = call ptr @llvm.stacksave()
  %stackaddr633 = ptrtoint ptr %stack632 to i64
  %v634 = load i64, ptr %slot46, align 8
  %cmp635 = icmp ult i64 %stackaddr633, %v634
  %cv636 = zext i1 %cmp635 to i64
  store i64 %cv636, ptr %slot47, align 8
  %v637 = load i64, ptr %slot47, align 8
  %cond638 = icmp ne i64 %v637, 0
  br i1 %cond638, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v639 = load i64, ptr %slot1, align 8
  %p640 = inttoptr i64 %v639 to ptr
  call void @myl_qbe_fail_frame(ptr %p640) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v641 = load i64, ptr %slot2, align 8
  %v642 = load i64, ptr %slot25, align 8
  %p643 = inttoptr i64 %v642 to ptr
  store i64 %v641, ptr %p643, align 8, !alias.scope !3, !noalias !4
  %v644 = load i64, ptr %slot3, align 8
  %v645 = load i64, ptr %slot26, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i64 %v644, ptr %p646, align 8, !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot4, align 8
  %v648 = load i64, ptr %slot27, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i64 %v647, ptr %p649, align 8, !alias.scope !3, !noalias !4
  %v650 = load i64, ptr %slot5, align 8
  %v651 = load i64, ptr %slot28, align 8
  %p652 = inttoptr i64 %v651 to ptr
  store i64 %v650, ptr %p652, align 8, !alias.scope !3, !noalias !4
  %v653 = load i64, ptr %slot6, align 8
  %v654 = load i64, ptr %slot29, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 %v653, ptr %p655, align 8, !alias.scope !3, !noalias !4
  %v656 = load i64, ptr %slot1, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %call658 = call ptr @myl_qbe_heap(ptr %p657) nomerge, !dbg !112
  %calladdr659 = ptrtoint ptr %call658 to i64
  store i64 %calladdr659, ptr %slot48, align 8
  %v660 = load i64, ptr %slot1, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %call662 = call i64 @myl_qbe_region_mark(ptr %p661) nomerge, !dbg !112
  store i64 %call662, ptr %slot49, align 8
  %v663 = load i64, ptr %slot9, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 0, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot10, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 0, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot11, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot12, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 0, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot13, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 0, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot14, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i32 0, ptr %p674, align 4, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot15, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i32 0, ptr %p676, align 4, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot16, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i32 0, ptr %p678, align 4, !alias.scope !3, !noalias !4
  %v679 = load i64, ptr %slot17, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i32 0, ptr %p680, align 4, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot18, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i32 0, ptr %p682, align 4, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot19, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 0, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot10, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i32 2, ptr %p686, align 4, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot12, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i32 2, ptr %p688, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v689 = load i64, ptr %slot27, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot50, align 8
  %v692 = load i64, ptr %slot50, align 8
  %v693 = load i64, ptr %slot33, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i64 %v692, ptr %p694, align 8, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot34, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 18446744073709551615, ptr %p696, align 8, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot34, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot51, align 8
  %v700 = load i64, ptr %slot33, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot52, align 8
  %v703 = load i64, ptr %slot52, align 8
  %v704 = load i64, ptr %slot51, align 8
  %cmp705 = icmp eq i64 %v703, %v704
  %cv706 = zext i1 %cmp705 to i64
  store i64 %cv706, ptr %slot53, align 8
  %v707 = load i64, ptr %slot53, align 8
  %v708 = load i64, ptr %slot33, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i64 %v707, ptr %p709, align 8, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot33, align 8
  %p711 = inttoptr i64 %v710 to ptr
  %ld712 = load i64, ptr %p711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld712, ptr %slot54, align 8
  %v713 = load i64, ptr %slot54, align 8
  %cond714 = icmp ne i64 %v713, 0
  br i1 %cond714, label %bb_next19, label %bb_i50
bb_next19:
  %v715 = load i64, ptr %slot25, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i64, ptr %p716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld717, ptr %slot55, align 8
  %v718 = load i64, ptr %slot55, align 8
  %v719 = load i64, ptr %slot33, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i64 %v718, ptr %p720, align 8, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot33, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i64, ptr %p722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld723, ptr %slot56, align 8
  %v724 = load i64, ptr %slot56, align 8
  %op725 = add i64 %v724, 32
  store i64 %op725, ptr %slot57, align 8
  %v726 = load i64, ptr %slot57, align 8
  %v727 = load i64, ptr %slot33, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 %v726, ptr %p728, align 8, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot13, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i32, ptr %p730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld731, ptr %slot58, align 8
  %v732 = load i32, ptr %slot58, align 8
  %cv733 = zext i32 %v732 to i64
  %cond734 = icmp ne i64 %cv733, 0
  br i1 %cond734, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v735 = load i64, ptr %slot13, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i32 0, ptr %p736, align 4, !alias.scope !3, !noalias !4
  %v737 = load i64, ptr %slot20, align 8
  store i64 %v737, ptr %slot59, align 8
  %v738 = load i64, ptr %slot14, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i32, ptr %p739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld740, ptr %slot60, align 8
  %v741 = load i32, ptr %slot60, align 8
  %op742 = and i32 %v741, 28
  store i32 %op742, ptr %slot61, align 8
  %v743 = load i32, ptr %slot61, align 8
  %cv744 = zext i32 %v743 to i64
  %cond745 = icmp ne i64 %cv744, 0
  br i1 %cond745, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v746 = load i64, ptr %slot48, align 8
  store i64 %v746, ptr %slot62, align 8
  %v747 = load i64, ptr %slot62, align 8
  %v748 = load i64, ptr %slot59, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v747, i64 %v748) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v749 = load i64, ptr %slot48, align 8
  store i64 %v749, ptr %slot63, align 8
  %v750 = load i64, ptr %slot63, align 8
  %v751 = load i64, ptr %slot59, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v750, i64 %v751) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v752 = load i64, ptr %slot33, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i64, ptr %p753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld754, ptr %slot64, align 8
  %v755 = load i64, ptr %slot64, align 8
  %op756 = add i64 %v755, 48
  store i64 %op756, ptr %slot65, align 8
  %v757 = load i64, ptr %slot65, align 8
  %v758 = load i64, ptr %slot33, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i64 %v757, ptr %p759, align 8, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot13, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %ld762 = load i32, ptr %p761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld762, ptr %slot66, align 8
  %v763 = load i32, ptr %slot66, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcslotdrop35, label %bb_rcslotdone35
bb_rcslotdrop35:
  %v766 = load i64, ptr %slot13, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 0, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot20, align 8
  store i64 %v768, ptr %slot67, align 8
  %v769 = load i64, ptr %slot14, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i32, ptr %p770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld771, ptr %slot68, align 8
  %v772 = load i32, ptr %slot68, align 8
  %op773 = and i32 %v772, 28
  store i32 %op773, ptr %slot69, align 8
  %v774 = load i32, ptr %slot69, align 8
  %cv775 = zext i32 %v774 to i64
  %cond776 = icmp ne i64 %cv775, 0
  br i1 %cond776, label %bb_rcslotrole35, label %bb_rcslotowner35
bb_rcslotrole35:
  %v777 = load i64, ptr %slot48, align 8
  store i64 %v777, ptr %slot70, align 8
  %v778 = load i64, ptr %slot70, align 8
  %v779 = load i64, ptr %slot67, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v778, i64 %v779) nomerge, !dbg !116
  br label %bb_rcslotdone35
bb_rcslotowner35:
  %v780 = load i64, ptr %slot48, align 8
  store i64 %v780, ptr %slot71, align 8
  %v781 = load i64, ptr %slot71, align 8
  %v782 = load i64, ptr %slot67, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v781, i64 %v782) nomerge, !dbg !116
  br label %bb_rcslotdone35
bb_rcslotdone35:
  %v783 = load i64, ptr %slot26, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot72, align 8
  %v786 = load i64, ptr %slot72, align 8
  %v787 = load i64, ptr %slot34, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 %v786, ptr %p788, align 8, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot25, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %ld791 = load i64, ptr %p790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld791, ptr %slot73, align 8
  %v792 = load i64, ptr %slot73, align 8
  %v793 = load i64, ptr %slot35, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 %v792, ptr %p794, align 8, !alias.scope !3, !noalias !4
  %v795 = load i64, ptr %slot35, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld797, ptr %slot74, align 8
  %v798 = load i64, ptr %slot74, align 8
  %op799 = add i64 %v798, 32
  store i64 %op799, ptr %slot75, align 8
  %v800 = load i64, ptr %slot75, align 8
  %v801 = load i64, ptr %slot35, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i64 %v800, ptr %p802, align 8, !alias.scope !3, !noalias !4
  %v803 = load i64, ptr %slot26, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i64, ptr %p804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld805, ptr %slot76, align 8
  %v806 = load i64, ptr %slot76, align 8
  %v807 = load i64, ptr %slot36, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i64 %v806, ptr %p808, align 8, !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot35, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i64, ptr %p810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld811, ptr %slot77, align 8
  %v812 = load i64, ptr %slot36, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot78, align 8
  %v815 = load i64, ptr %slot1, align 8
  %v816 = load i64, ptr %slot77, align 8
  %v817 = load i64, ptr %slot78, align 8
  %call818 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v815, i64 %v816, i64 %v817) nomerge, !dbg !118
  store i64 %call818, ptr %slot79, align 8
  %v819 = load i64, ptr %slot79, align 8
  %v820 = load i64, ptr %slot35, align 8
  %p821 = inttoptr i64 %v820 to ptr
  store i64 %v819, ptr %p821, align 8, !alias.scope !3, !noalias !4
  %v822 = load i64, ptr %slot33, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot80, align 8
  %v825 = load i64, ptr %slot34, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld827, ptr %slot81, align 8
  %v828 = load i64, ptr %slot35, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i64, ptr %p829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld830, ptr %slot82, align 8
  %v831 = load i64, ptr %slot1, align 8
  %v832 = load i64, ptr %slot80, align 8
  %v833 = load i64, ptr %slot81, align 8
  %v834 = load i64, ptr %slot82, align 8
  call void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %callresult84, i64 %v831, i64 %v832, i64 %v833, i64 %v834) nomerge, !dbg !120
  %addr835 = ptrtoint ptr %callresult84 to i64
  store i64 %addr835, ptr %slot83, align 8
  %v836 = load i64, ptr %slot83, align 8
  %v837 = load i64, ptr %slot33, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i64 %v836, ptr %p838, align 8, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot13, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i32, ptr %p840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld841, ptr %slot85, align 8
  %v842 = load i32, ptr %slot85, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcslotdrop74, label %bb_rcslotdone74
bb_rcslotdrop74:
  %v845 = load i64, ptr %slot13, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot20, align 8
  store i64 %v847, ptr %slot86, align 8
  %v848 = load i64, ptr %slot14, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %ld850 = load i32, ptr %p849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld850, ptr %slot87, align 8
  %v851 = load i32, ptr %slot87, align 8
  %op852 = and i32 %v851, 28
  store i32 %op852, ptr %slot88, align 8
  %v853 = load i32, ptr %slot88, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotrole74, label %bb_rcslotowner74
bb_rcslotrole74:
  %v856 = load i64, ptr %slot48, align 8
  store i64 %v856, ptr %slot89, align 8
  %v857 = load i64, ptr %slot89, align 8
  %v858 = load i64, ptr %slot86, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v857, i64 %v858) nomerge, !dbg !120
  br label %bb_rcslotdone74
bb_rcslotowner74:
  %v859 = load i64, ptr %slot48, align 8
  store i64 %v859, ptr %slot90, align 8
  %v860 = load i64, ptr %slot90, align 8
  %v861 = load i64, ptr %slot86, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v860, i64 %v861) nomerge, !dbg !120
  br label %bb_rcslotdone74
bb_rcslotdone74:
  %v862 = load i64, ptr %slot33, align 8
  %p863 = inttoptr i64 %v862 to ptr
  %ld864 = load i64, ptr %p863, align 8, !alias.scope !3, !noalias !4
  store i64 %ld864, ptr %slot91, align 8
  %v865 = load i64, ptr %slot91, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i32, ptr %p866, align 4
  %ext868 = zext i32 %ld867 to i64
  store i64 %ext868, ptr %slot92, align 8
  %v869 = load i64, ptr %slot92, align 8
  %cmp870 = icmp eq i64 %v869, 0
  %cv871 = zext i1 %cmp870 to i64
  store i64 %cv871, ptr %slot93, align 8
  %v872 = load i64, ptr %slot93, align 8
  %cond873 = icmp ne i64 %v872, 0
  br i1 %cond873, label %bb_rcarm83, label %bb_rcarmnext83
bb_rcarm83:
  br label %bb_i38
bb_rcarmnext83:
  %v874 = load i64, ptr %slot92, align 8
  %cmp875 = icmp eq i64 %v874, 1
  %cv876 = zext i1 %cmp875 to i64
  store i64 %cv876, ptr %slot94, align 8
  %v877 = load i64, ptr %slot94, align 8
  %cond878 = icmp ne i64 %v877, 0
  br i1 %cond878, label %bb_rcarm84, label %bb_rcarmnext84
bb_rcarm84:
  %v879 = load i64, ptr %slot24, align 8
  store i64 %v879, ptr %slot95, align 8
  %v880 = load i64, ptr %slot91, align 8
  %op881 = add i64 %v880, 8
  store i64 %op881, ptr %slot96, align 8
  %v882 = load i64, ptr %slot49, align 8
  store i64 %v882, ptr %slot97, align 8
  %v883 = load i64, ptr %slot96, align 8
  %v884 = load i64, ptr %slot95, align 8
  %p885 = inttoptr i64 %v883 to ptr
  %p886 = inttoptr i64 %v884 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p886, ptr %p885, i64 16, i1 false)
  %v887 = load i64, ptr %slot18, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i32 0, ptr %p888, align 4, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot17, align 8
  %p890 = inttoptr i64 %v889 to ptr
  store i32 1, ptr %p890, align 4, !alias.scope !3, !noalias !4
  %v891 = load i64, ptr %slot95, align 8
  %v892 = load i64, ptr %slot30, align 8
  %p893 = inttoptr i64 %v891 to ptr
  %p894 = inttoptr i64 %v892 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p894, ptr %p893, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot17, align 8
  %p896 = inttoptr i64 %v895 to ptr
  store i32 0, ptr %p896, align 4, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_rcarmnext84:
  br label %bb_failure
bb_i14:
  %v897 = load i64, ptr %slot25, align 8
  %p898 = inttoptr i64 %v897 to ptr
  %ld899 = load i64, ptr %p898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld899, ptr %slot98, align 8
  %v900 = load i64, ptr %slot98, align 8
  %v901 = load i64, ptr %slot37, align 8
  %p902 = inttoptr i64 %v900 to ptr
  %p903 = inttoptr i64 %v901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p903, ptr %p902, i64 304, i1 false), !alias.scope !10000000
  %v904 = load i64, ptr %slot37, align 8
  %v905 = load i64, ptr %slot33, align 8
  %p906 = inttoptr i64 %v905 to ptr
  store i64 %v904, ptr %p906, align 8, !alias.scope !3, !noalias !4
  %v907 = load i64, ptr %slot33, align 8
  %p908 = inttoptr i64 %v907 to ptr
  %ld909 = load i64, ptr %p908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld909, ptr %slot99, align 8
  %v910 = load i64, ptr %slot99, align 8
  %op911 = add i64 %v910, 32
  store i64 %op911, ptr %slot100, align 8
  %v912 = load i64, ptr %slot100, align 8
  %v913 = load i64, ptr %slot33, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i64 %v912, ptr %p914, align 8, !alias.scope !3, !noalias !4
  %v915 = load i64, ptr %slot9, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i32, ptr %p916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld917, ptr %slot101, align 8
  %v918 = load i32, ptr %slot101, align 8
  %cv919 = zext i32 %v918 to i64
  %cond920 = icmp ne i64 %cv919, 0
  br i1 %cond920, label %bb_rcslotdrop96, label %bb_rcslotdone96
bb_rcslotdrop96:
  %v921 = load i64, ptr %slot9, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i32 0, ptr %p922, align 4, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot31, align 8
  store i64 %v923, ptr %slot102, align 8
  %v924 = load i64, ptr %slot10, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i32, ptr %p925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld926, ptr %slot103, align 8
  %v927 = load i32, ptr %slot103, align 8
  %op928 = and i32 %v927, 28
  store i32 %op928, ptr %slot104, align 8
  %v929 = load i32, ptr %slot104, align 8
  %cv930 = zext i32 %v929 to i64
  %cond931 = icmp ne i64 %cv930, 0
  br i1 %cond931, label %bb_rcslotrole96, label %bb_rcslotowner96
bb_rcslotrole96:
  %v932 = load i64, ptr %slot48, align 8
  store i64 %v932, ptr %slot105, align 8
  %v933 = load i64, ptr %slot105, align 8
  %v934 = load i64, ptr %slot102, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v933, i64 %v934) nomerge, !dbg !122
  br label %bb_rcslotdone96
bb_rcslotowner96:
  %v935 = load i64, ptr %slot48, align 8
  store i64 %v935, ptr %slot106, align 8
  %v936 = load i64, ptr %slot106, align 8
  %v937 = load i64, ptr %slot102, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v936, i64 %v937) nomerge, !dbg !122
  br label %bb_rcslotdone96
bb_rcslotdone96:
  %v938 = load i64, ptr %slot25, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot107, align 8
  %v941 = load i64, ptr %slot107, align 8
  %op942 = add i64 %v941, 32
  store i64 %op942, ptr %slot108, align 8
  %v943 = load i64, ptr %slot31, align 8
  store i64 %v943, ptr %slot109, align 8
  %v944 = load i64, ptr %slot108, align 8
  %v945 = load i64, ptr %slot109, align 8
  %p946 = inttoptr i64 %v944 to ptr
  %p947 = inttoptr i64 %v945 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p947, ptr %p946, i64 208, i1 false), !alias.scope !10000000
  %v948 = load i64, ptr %slot108, align 8
  %p949 = inttoptr i64 %v948 to ptr
  call void @llvm.memset.p0.i64(ptr %p949, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !122
  %v950 = load i64, ptr %slot9, align 8
  %p951 = inttoptr i64 %v950 to ptr
  store i32 1, ptr %p951, align 4, !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot31, align 8
  %v953 = load i64, ptr %slot33, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i64 %v952, ptr %p954, align 8, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot30, align 8
  %v956 = load i64, ptr %slot34, align 8
  %p957 = inttoptr i64 %v956 to ptr
  store i64 %v955, ptr %p957, align 8, !alias.scope !3, !noalias !4
  %v958 = load i64, ptr %slot33, align 8
  %p959 = inttoptr i64 %v958 to ptr
  %ld960 = load i64, ptr %p959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld960, ptr %slot110, align 8
  %v961 = load i64, ptr %slot34, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i64, ptr %p962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld963, ptr %slot111, align 8
  %v964 = load i64, ptr %slot1, align 8
  %v965 = load i64, ptr %slot110, align 8
  %v966 = load i64, ptr %slot111, align 8
  %call967 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v964, i64 %v965, i64 %v966) nomerge, !dbg !124
  store i64 %call967, ptr %slot112, align 8
  %v968 = load i64, ptr %slot112, align 8
  %v969 = load i64, ptr %slot33, align 8
  %p970 = inttoptr i64 %v969 to ptr
  store i64 %v968, ptr %p970, align 8, !alias.scope !3, !noalias !4
  %v971 = load i64, ptr %slot13, align 8
  %p972 = inttoptr i64 %v971 to ptr
  %ld973 = load i32, ptr %p972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld973, ptr %slot113, align 8
  %v974 = load i32, ptr %slot113, align 8
  %cv975 = zext i32 %v974 to i64
  %cond976 = icmp ne i64 %cv975, 0
  br i1 %cond976, label %bb_rcslotdrop112, label %bb_rcslotdone112
bb_rcslotdrop112:
  %v977 = load i64, ptr %slot13, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i32 0, ptr %p978, align 4, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot20, align 8
  store i64 %v979, ptr %slot114, align 8
  %v980 = load i64, ptr %slot14, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i32, ptr %p981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld982, ptr %slot115, align 8
  %v983 = load i32, ptr %slot115, align 8
  %op984 = and i32 %v983, 28
  store i32 %op984, ptr %slot116, align 8
  %v985 = load i32, ptr %slot116, align 8
  %cv986 = zext i32 %v985 to i64
  %cond987 = icmp ne i64 %cv986, 0
  br i1 %cond987, label %bb_rcslotrole112, label %bb_rcslotowner112
bb_rcslotrole112:
  %v988 = load i64, ptr %slot48, align 8
  store i64 %v988, ptr %slot117, align 8
  %v989 = load i64, ptr %slot117, align 8
  %v990 = load i64, ptr %slot114, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v989, i64 %v990) nomerge, !dbg !124
  br label %bb_rcslotdone112
bb_rcslotowner112:
  %v991 = load i64, ptr %slot48, align 8
  store i64 %v991, ptr %slot118, align 8
  %v992 = load i64, ptr %slot118, align 8
  %v993 = load i64, ptr %slot114, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v992, i64 %v993) nomerge, !dbg !124
  br label %bb_rcslotdone112
bb_rcslotdone112:
  %v994 = load i64, ptr %slot25, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i64, ptr %p995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld996, ptr %slot119, align 8
  %v997 = load i64, ptr %slot119, align 8
  %op998 = add i64 %v997, 32
  store i64 %op998, ptr %slot120, align 8
  %v999 = load i64, ptr %slot31, align 8
  store i64 %v999, ptr %slot121, align 8
  %v1000 = load i64, ptr %slot121, align 8
  %v1001 = load i64, ptr %slot120, align 8
  %p1002 = inttoptr i64 %v1000 to ptr
  %p1003 = inttoptr i64 %v1001 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1003, ptr %p1002, i64 208, i1 false), !alias.scope !10000000
  %v1004 = load i64, ptr %slot121, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  call void @llvm.memset.p0.i64(ptr %p1005, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v1006 = load i64, ptr %slot9, align 8
  %p1007 = inttoptr i64 %v1006 to ptr
  store i32 0, ptr %p1007, align 4, !alias.scope !3, !noalias !4
  %v1008 = load i64, ptr %slot33, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i64 0, ptr %p1009, align 8, !alias.scope !3, !noalias !4
  %v1010 = load i64, ptr %slot33, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  store i64 0, ptr %p1011, align 8, !alias.scope !3, !noalias !4
  %v1012 = load i64, ptr %slot38, align 8
  store i64 %v1012, ptr %slot122, align 8
  %v1013 = load i64, ptr %slot122, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  store i64 0, ptr %p1014, align 8, !alias.scope !3, !noalias !4
  %v1015 = load i64, ptr %slot122, align 8
  %p1017 = inttoptr i64 %v1015 to ptr
  %gep1018 = getelementptr i8, ptr %p1017, i64 8
  %op1016 = ptrtoint ptr %gep1018 to i64
  store i64 %op1016, ptr %slot123, align 8
  %v1019 = load i64, ptr %slot123, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i64 0, ptr %p1020, align 8, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot122, align 8
  %p1023 = inttoptr i64 %v1021 to ptr
  %gep1024 = getelementptr i8, ptr %p1023, i64 16
  %op1022 = ptrtoint ptr %gep1024 to i64
  store i64 %op1022, ptr %slot124, align 8
  %v1025 = load i64, ptr %slot124, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i64 0, ptr %p1026, align 8, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot122, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i32 0, ptr %p1028, align 4, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot19, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i32 1, ptr %p1030, align 4, !alias.scope !3, !noalias !4
  %v1031 = load i64, ptr %slot33, align 8
  store i64 %v1031, ptr %slot125, align 8
  %v1032 = load i64, ptr %slot122, align 8
  %p1034 = inttoptr i64 %v1032 to ptr
  %gep1035 = getelementptr i8, ptr %p1034, i64 8
  %op1033 = ptrtoint ptr %gep1035 to i64
  store i64 %op1033, ptr %slot126, align 8
  %v1036 = load i64, ptr %slot49, align 8
  store i64 %v1036, ptr %slot127, align 8
  store i64 0, ptr %slot128, align 8
  %v1037 = load i64, ptr %slot122, align 8
  %v1038 = load i64, ptr %slot33, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i64 %v1037, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot33, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot129, align 8
  %v1043 = load i64, ptr %slot20, align 8
  store i64 %v1043, ptr %slot130, align 8
  %v1044 = load i64, ptr %slot129, align 8
  %v1045 = load i64, ptr %slot130, align 8
  %p1046 = inttoptr i64 %v1044 to ptr
  %p1047 = inttoptr i64 %v1045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1047, ptr %p1046, i64 24, i1 false)
  %v1048 = load i64, ptr %slot14, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  store i32 2, ptr %p1049, align 4, !alias.scope !3, !noalias !4
  %v1050 = load i64, ptr %slot13, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  store i32 1, ptr %p1051, align 4, !alias.scope !3, !noalias !4
  %v1052 = load i64, ptr %slot130, align 8
  %v1053 = load i64, ptr %slot33, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 %v1052, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot33, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i64, ptr %p1056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1057, ptr %slot131, align 8
  %v1058 = load i64, ptr %slot33, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i64, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1060, ptr %slot132, align 8
  %v1061 = load i64, ptr %slot24, align 8
  store i64 %v1061, ptr %slot133, align 8
  %v1062 = load i64, ptr %slot49, align 8
  store i64 %v1062, ptr %slot134, align 8
  %v1063 = load i64, ptr %slot48, align 8
  %v1064 = load i64, ptr %slot133, align 8
  %v1065 = load i64, ptr %slot132, align 8
  %v1066 = load i64, ptr %slot134, align 8
  %cv1067 = trunc i64 %v1066 to i32
  %call1068 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v1063, i64 %v1064, i64 %v1065, i32 %cv1067) nomerge, !dbg !128
  store i32 %call1068, ptr %slot135, align 8
  %v1069 = load i32, ptr %slot135, align 8
  %cv1070 = zext i32 %v1069 to i64
  %cond1071 = icmp ne i64 %cv1070, 0
  br i1 %cond1071, label %bb_rcsuccess141, label %bb_rcfailure141
bb_rcfailure141:
  %v1072 = load i64, ptr %slot48, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %call1074 = call i32 @myl_rc_take_failure(ptr %p1073) nomerge, !dbg !128
  store i32 %call1074, ptr %slot136, align 8
  %v1075 = load i64, ptr %slot1, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  %v1077 = load i32, ptr %slot136, align 8
  %call1078 = call i32 @myl_qbe_rc_status(ptr %p1076, i32 %v1077) nomerge, !dbg !128
  store i32 %call1078, ptr %slot137, align 8
  br label %bb_failure
bb_rcsuccess141:
  %v1079 = load i64, ptr %slot13, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i32 0, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  %v1081 = load i64, ptr %slot18, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i32 2, ptr %p1082, align 4, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot17, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i32 1, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot24, align 8
  store i64 %v1085, ptr %slot138, align 8
  %v1086 = load i64, ptr %slot17, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i32 0, ptr %p1087, align 4, !alias.scope !3, !noalias !4
  %v1088 = load i64, ptr %slot13, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  %ld1090 = load i32, ptr %p1089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1090, ptr %slot139, align 8
  %v1091 = load i32, ptr %slot139, align 8
  %cv1092 = zext i32 %v1091 to i64
  %cond1093 = icmp ne i64 %cv1092, 0
  br i1 %cond1093, label %bb_rcslotdrop151, label %bb_rcslotdone151
bb_rcslotdrop151:
  %v1094 = load i64, ptr %slot13, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  store i32 0, ptr %p1095, align 4, !alias.scope !3, !noalias !4
  %v1096 = load i64, ptr %slot20, align 8
  store i64 %v1096, ptr %slot140, align 8
  %v1097 = load i64, ptr %slot14, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  %ld1099 = load i32, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1099, ptr %slot141, align 8
  %v1100 = load i32, ptr %slot141, align 8
  %op1101 = and i32 %v1100, 28
  store i32 %op1101, ptr %slot142, align 8
  %v1102 = load i32, ptr %slot142, align 8
  %cv1103 = zext i32 %v1102 to i64
  %cond1104 = icmp ne i64 %cv1103, 0
  br i1 %cond1104, label %bb_rcslotrole151, label %bb_rcslotowner151
bb_rcslotrole151:
  %v1105 = load i64, ptr %slot48, align 8
  store i64 %v1105, ptr %slot143, align 8
  %v1106 = load i64, ptr %slot143, align 8
  %v1107 = load i64, ptr %slot140, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1106, i64 %v1107) nomerge, !dbg !128
  br label %bb_rcslotdone151
bb_rcslotowner151:
  %v1108 = load i64, ptr %slot48, align 8
  store i64 %v1108, ptr %slot144, align 8
  %v1109 = load i64, ptr %slot144, align 8
  %v1110 = load i64, ptr %slot140, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1109, i64 %v1110) nomerge, !dbg !128
  br label %bb_rcslotdone151
bb_rcslotdone151:
  %v1111 = load i64, ptr %slot11, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  %ld1113 = load i32, ptr %p1112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1113, ptr %slot145, align 8
  %v1114 = load i32, ptr %slot145, align 8
  %cv1115 = zext i32 %v1114 to i64
  %cond1116 = icmp ne i64 %cv1115, 0
  br i1 %cond1116, label %bb_rcslotdrop178, label %bb_rcslotdone178
bb_rcslotdrop178:
  %v1117 = load i64, ptr %slot11, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  store i32 0, ptr %p1118, align 4, !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot32, align 8
  store i64 %v1119, ptr %slot146, align 8
  %v1120 = load i64, ptr %slot12, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %ld1122 = load i32, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1122, ptr %slot147, align 8
  %v1123 = load i32, ptr %slot147, align 8
  %op1124 = and i32 %v1123, 28
  store i32 %op1124, ptr %slot148, align 8
  %v1125 = load i32, ptr %slot148, align 8
  %cv1126 = zext i32 %v1125 to i64
  %cond1127 = icmp ne i64 %cv1126, 0
  br i1 %cond1127, label %bb_rcslotrole178, label %bb_rcslotowner178
bb_rcslotrole178:
  %v1128 = load i64, ptr %slot48, align 8
  store i64 %v1128, ptr %slot149, align 8
  %v1129 = load i64, ptr %slot149, align 8
  %v1130 = load i64, ptr %slot146, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1129, i64 %v1130) nomerge, !dbg !128
  br label %bb_rcslotdone178
bb_rcslotowner178:
  %v1131 = load i64, ptr %slot48, align 8
  store i64 %v1131, ptr %slot150, align 8
  %v1132 = load i64, ptr %slot150, align 8
  %v1133 = load i64, ptr %slot146, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1132, i64 %v1133) nomerge, !dbg !128
  br label %bb_rcslotdone178
bb_rcslotdone178:
  %v1134 = load i64, ptr %slot9, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %ld1136 = load i32, ptr %p1135, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1136, ptr %slot151, align 8
  %v1137 = load i32, ptr %slot151, align 8
  %cv1138 = zext i32 %v1137 to i64
  %cond1139 = icmp ne i64 %cv1138, 0
  br i1 %cond1139, label %bb_rcslotdrop205, label %bb_rcslotdone205
bb_rcslotdrop205:
  %v1140 = load i64, ptr %slot9, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 0, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot31, align 8
  store i64 %v1142, ptr %slot152, align 8
  %v1143 = load i64, ptr %slot10, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i32, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1145, ptr %slot153, align 8
  %v1146 = load i32, ptr %slot153, align 8
  %op1147 = and i32 %v1146, 28
  store i32 %op1147, ptr %slot154, align 8
  %v1148 = load i32, ptr %slot154, align 8
  %cv1149 = zext i32 %v1148 to i64
  %cond1150 = icmp ne i64 %cv1149, 0
  br i1 %cond1150, label %bb_rcslotrole205, label %bb_rcslotowner205
bb_rcslotrole205:
  %v1151 = load i64, ptr %slot48, align 8
  store i64 %v1151, ptr %slot155, align 8
  %v1152 = load i64, ptr %slot155, align 8
  %v1153 = load i64, ptr %slot152, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1152, i64 %v1153) nomerge, !dbg !128
  br label %bb_rcslotdone205
bb_rcslotowner205:
  %v1154 = load i64, ptr %slot48, align 8
  store i64 %v1154, ptr %slot156, align 8
  %v1155 = load i64, ptr %slot156, align 8
  %v1156 = load i64, ptr %slot152, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1155, i64 %v1156) nomerge, !dbg !128
  br label %bb_rcslotdone205
bb_rcslotdone205:
  %v1157 = load i64, ptr %slot138, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1158, i64 24, i1 false)
  ret void
bb_i38:
  %p1159 = inttoptr i64 ptrtoint (ptr @myl_lit_8d47278f5246a959c9cf373236b198659ae1c259b6afd12cadab3d657868cf2b to i64) to ptr
  %ld1160 = load i64, ptr %p1159, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1160, ptr %slot157, align 8
  %v1161 = load i64, ptr %slot157, align 8
  %v1162 = load i64, ptr %slot33, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i64 %v1161, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot33, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %ld1166 = load i64, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1166, ptr %slot158, align 8
  %v1167 = load i64, ptr %slot158, align 8
  %v1168 = load i64, ptr %slot22, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i64 %v1167, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot22, align 8
  store i64 %v1170, ptr %slot159, align 8
  %v1171 = load i64, ptr %slot24, align 8
  store i64 %v1171, ptr %slot160, align 8
  %v1172 = load i64, ptr %slot159, align 8
  %v1173 = load i64, ptr %slot160, align 8
  %p1174 = inttoptr i64 %v1172 to ptr
  %p1175 = inttoptr i64 %v1173 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1175, ptr %p1174, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot18, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 2, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot17, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 1, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot20, align 8
  store i64 %v1180, ptr %slot161, align 8
  %v1181 = load i64, ptr %slot24, align 8
  store i64 %v1181, ptr %slot162, align 8
  %v1182 = load i64, ptr %slot162, align 8
  %v1183 = load i64, ptr %slot161, align 8
  %p1184 = inttoptr i64 %v1182 to ptr
  %p1185 = inttoptr i64 %v1183 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1185, ptr %p1184, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot14, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i32 2, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot18, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  %ld1190 = load i32, ptr %p1189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1190, ptr %slot163, align 8
  %v1191 = load i32, ptr %slot163, align 8
  %v1192 = load i64, ptr %slot14, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  store i32 %v1191, ptr %p1193, align 4, !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot17, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i32 0, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot13, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  store i32 1, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  %v1198 = load i64, ptr %slot161, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %ld1200 = load i64, ptr %p1199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1200, ptr %slot164, align 8
  %v1201 = load i64, ptr %slot164, align 8
  %v1202 = load i64, ptr %slot33, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i64 %v1201, ptr %p1203, align 8, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot25, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %ld1206 = load i64, ptr %p1205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1206, ptr %slot165, align 8
  %v1207 = load i64, ptr %slot165, align 8
  %v1208 = load i64, ptr %slot34, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  store i64 %v1207, ptr %p1209, align 8, !alias.scope !3, !noalias !4
  %v1210 = load i64, ptr %slot34, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i64, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1212, ptr %slot166, align 8
  %v1213 = load i64, ptr %slot166, align 8
  %op1214 = add i64 %v1213, 32
  store i64 %op1214, ptr %slot167, align 8
  %v1215 = load i64, ptr %slot167, align 8
  %v1216 = load i64, ptr %slot34, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i64 %v1215, ptr %p1217, align 8, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot15, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  %ld1220 = load i32, ptr %p1219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1220, ptr %slot168, align 8
  %v1221 = load i32, ptr %slot168, align 8
  %cv1222 = zext i32 %v1221 to i64
  %cond1223 = icmp ne i64 %cv1222, 0
  br i1 %cond1223, label %bb_rcslotdrop242, label %bb_rcslotdone242
bb_rcslotdrop242:
  %v1224 = load i64, ptr %slot15, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 0, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot21, align 8
  store i64 %v1226, ptr %slot169, align 8
  %v1227 = load i64, ptr %slot16, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %ld1229 = load i32, ptr %p1228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1229, ptr %slot170, align 8
  %v1230 = load i32, ptr %slot170, align 8
  %op1231 = and i32 %v1230, 28
  store i32 %op1231, ptr %slot171, align 8
  %v1232 = load i32, ptr %slot171, align 8
  %cv1233 = zext i32 %v1232 to i64
  %cond1234 = icmp ne i64 %cv1233, 0
  br i1 %cond1234, label %bb_rcslotrole242, label %bb_rcslotowner242
bb_rcslotrole242:
  %v1235 = load i64, ptr %slot48, align 8
  store i64 %v1235, ptr %slot172, align 8
  %v1236 = load i64, ptr %slot172, align 8
  %v1237 = load i64, ptr %slot169, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1236, i64 %v1237) nomerge, !dbg !130
  br label %bb_rcslotdone242
bb_rcslotowner242:
  %v1238 = load i64, ptr %slot48, align 8
  store i64 %v1238, ptr %slot173, align 8
  %v1239 = load i64, ptr %slot173, align 8
  %v1240 = load i64, ptr %slot169, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1239, i64 %v1240) nomerge, !dbg !130
  br label %bb_rcslotdone242
bb_rcslotdone242:
  %v1241 = load i64, ptr %slot26, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i64, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1243, ptr %slot174, align 8
  %v1244 = load i64, ptr %slot174, align 8
  %v1245 = load i64, ptr %slot35, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i64 %v1244, ptr %p1246, align 8, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot34, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %ld1249 = load i64, ptr %p1248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1249, ptr %slot175, align 8
  %v1250 = load i64, ptr %slot35, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i64, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1252, ptr %slot176, align 8
  %v1253 = load i64, ptr %slot1, align 8
  %v1254 = load i64, ptr %slot175, align 8
  %v1255 = load i64, ptr %slot176, align 8
  %call1256 = call i64 @myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b_rc_borrow(i64 %v1253, i64 %v1254, i64 %v1255) nomerge, !dbg !132
  store i64 %call1256, ptr %slot177, align 8
  %v1257 = load i64, ptr %slot177, align 8
  %v1258 = load i64, ptr %slot34, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  store i64 %v1257, ptr %p1259, align 8, !alias.scope !3, !noalias !4
  %v1260 = load i64, ptr %slot34, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %ld1262 = load i64, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1262, ptr %slot178, align 8
  %v1263 = load i64, ptr %slot178, align 8
  %v1264 = load i64, ptr %slot23, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i64 %v1263, ptr %p1265, align 8, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot23, align 8
  store i64 %v1266, ptr %slot179, align 8
  %v1267 = load i64, ptr %slot24, align 8
  store i64 %v1267, ptr %slot180, align 8
  %v1268 = load i64, ptr %slot179, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  %ld1270 = load i64, ptr %p1269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1270, ptr %slot181, align 8
  %v1271 = load i64, ptr %slot181, align 8
  %cmp1272 = icmp ne i64 %v1271, 0
  %cv1273 = zext i1 %cmp1272 to i32
  store i32 %cv1273, ptr %slot182, align 8
  %v1274 = load i32, ptr %slot182, align 8
  %cv1275 = zext i32 %v1274 to i64
  %cond1276 = icmp ne i64 %cv1275, 0
  br i1 %cond1276, label %bb_rcgnn257, label %bb_rcgstore257
bb_rcgnn257:
  %v1277 = load i64, ptr %slot181, align 8
  %op1278 = sub i64 %v1277, 16
  store i64 %op1278, ptr %slot183, align 8
  %v1279 = load i64, ptr %slot181, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %rgep1281 = getelementptr i8, ptr %p1280, i64 -16
  %ld1282 = load i64, ptr %rgep1281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1282, ptr %slot184, align 8
  %v1283 = load i64, ptr %slot184, align 8
  %op1284 = and i64 %v1283, 4611686018427387906
  store i64 %op1284, ptr %slot185, align 8
  %v1285 = load i64, ptr %slot185, align 8
  %cmp1286 = icmp ne i64 %v1285, 0
  %cv1287 = zext i1 %cmp1286 to i32
  store i32 %cv1287, ptr %slot186, align 8
  %v1288 = load i32, ptr %slot186, align 8
  %cv1289 = zext i32 %v1288 to i64
  %cond1290 = icmp ne i64 %cv1289, 0
  br i1 %cond1290, label %bb_rcgstore257, label %bb_rcginc257
bb_rcginc257:
  %v1291 = load i64, ptr %slot181, align 8
  %op1292 = sub i64 %v1291, 24
  store i64 %op1292, ptr %slot187, align 8
  %v1293 = load i64, ptr %slot181, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  %rgep1295 = getelementptr i8, ptr %p1294, i64 -24
  %ld1296 = load i64, ptr %rgep1295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1296, ptr %slot188, align 8
  %v1297 = load i64, ptr %slot188, align 8
  %op1298 = add i64 %v1297, 1
  store i64 %op1298, ptr %slot189, align 8
  %v1299 = load i64, ptr %slot189, align 8
  %cmp1300 = icmp eq i64 %v1299, 0
  %cv1301 = zext i1 %cmp1300 to i32
  store i32 %cv1301, ptr %slot190, align 8
  %v1302 = load i32, ptr %slot190, align 8
  %cv1303 = zext i32 %v1302 to i64
  %cond1304 = icmp ne i64 %cv1303, 0
  br i1 %cond1304, label %bb_rcglimit257, label %bb_rcgcapacity257
bb_rcglimit257:
  %v1305 = load i64, ptr %slot1, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %call1307 = call i32 @myl_qbe_rc_status(ptr %p1306, i32 2) nomerge, !dbg !132
  store i32 %call1307, ptr %slot191, align 8
  br label %bb_failure
bb_rcgcapacity257:
  %v1308 = load i64, ptr %slot189, align 8
  %v1309 = load i64, ptr %slot181, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %rgep1311 = getelementptr i8, ptr %p1310, i64 -24
  store i64 %v1308, ptr %rgep1311, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore257
bb_rcgstore257:
  %v1312 = load i64, ptr %slot181, align 8
  %v1313 = load i64, ptr %slot180, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  store i64 %v1312, ptr %p1314, align 8, !alias.scope !3, !noalias !4
  %v1315 = load i64, ptr %slot18, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 2, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot18, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  store i32 16, ptr %p1318, align 4, !alias.scope !3, !noalias !4
  %v1319 = load i64, ptr %slot17, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  store i32 1, ptr %p1320, align 4, !alias.scope !3, !noalias !4
  %v1321 = load i64, ptr %slot15, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  %ld1323 = load i32, ptr %p1322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1323, ptr %slot192, align 8
  %v1324 = load i32, ptr %slot192, align 8
  %cv1325 = zext i32 %v1324 to i64
  %cond1326 = icmp ne i64 %cv1325, 0
  br i1 %cond1326, label %bb_rcslotdrop273, label %bb_rcslotdone273
bb_rcslotdrop273:
  %v1327 = load i64, ptr %slot15, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  store i32 0, ptr %p1328, align 4, !alias.scope !3, !noalias !4
  %v1329 = load i64, ptr %slot21, align 8
  store i64 %v1329, ptr %slot193, align 8
  %v1330 = load i64, ptr %slot16, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  %ld1332 = load i32, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1332, ptr %slot194, align 8
  %v1333 = load i32, ptr %slot194, align 8
  %op1334 = and i32 %v1333, 28
  store i32 %op1334, ptr %slot195, align 8
  %v1335 = load i32, ptr %slot195, align 8
  %cv1336 = zext i32 %v1335 to i64
  %cond1337 = icmp ne i64 %cv1336, 0
  br i1 %cond1337, label %bb_rcslotrole273, label %bb_rcslotowner273
bb_rcslotrole273:
  %v1338 = load i64, ptr %slot48, align 8
  store i64 %v1338, ptr %slot196, align 8
  %v1339 = load i64, ptr %slot196, align 8
  %v1340 = load i64, ptr %slot193, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1339, i64 %v1340) nomerge, !dbg !132
  br label %bb_rcslotdone273
bb_rcslotowner273:
  %v1341 = load i64, ptr %slot48, align 8
  store i64 %v1341, ptr %slot197, align 8
  %v1342 = load i64, ptr %slot197, align 8
  %v1343 = load i64, ptr %slot193, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1342, i64 %v1343) nomerge, !dbg !132
  br label %bb_rcslotdone273
bb_rcslotdone273:
  %v1344 = load i64, ptr %slot21, align 8
  store i64 %v1344, ptr %slot198, align 8
  %v1345 = load i64, ptr %slot24, align 8
  store i64 %v1345, ptr %slot199, align 8
  %v1346 = load i64, ptr %slot199, align 8
  %v1347 = load i64, ptr %slot198, align 8
  %p1348 = inttoptr i64 %v1346 to ptr
  %p1349 = inttoptr i64 %v1347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1349, ptr %p1348, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot16, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  store i32 2, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot18, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  %ld1354 = load i32, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1354, ptr %slot200, align 8
  %v1355 = load i32, ptr %slot200, align 8
  %v1356 = load i64, ptr %slot16, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i32 %v1355, ptr %p1357, align 4, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot17, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 0, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot15, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  store i32 1, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  %v1362 = load i64, ptr %slot198, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %ld1364 = load i64, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1364, ptr %slot201, align 8
  %v1365 = load i64, ptr %slot201, align 8
  %v1366 = load i64, ptr %slot34, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  store i64 %v1365, ptr %p1367, align 8, !alias.scope !3, !noalias !4
  %v1368 = load i64, ptr %slot33, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %ld1370 = load i64, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1370, ptr %slot202, align 8
  %v1371 = load i64, ptr %slot34, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  %ld1373 = load i64, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1373, ptr %slot203, align 8
  %v1374 = load i64, ptr %slot33, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  %ld1376 = load i64, ptr %p1375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1376, ptr %slot204, align 8
  %v1377 = load i64, ptr %slot34, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i64, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1379, ptr %slot205, align 8
  %v1380 = load i64, ptr %slot48, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  %v1382 = load i64, ptr %slot204, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %v1384 = load i64, ptr %slot205, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %call1386 = call ptr @myl_native_bytes_concat(ptr %p1381, ptr %p1383, ptr %p1385) nomerge, !dbg !134
  %calladdr1387 = ptrtoint ptr %call1386 to i64
  store i64 %calladdr1387, ptr %slot206, align 8
  %v1388 = load i64, ptr %slot206, align 8
  %cond1389 = icmp ne i64 %v1388, 0
  br i1 %cond1389, label %bb_success295, label %bb_failed295
bb_failed295:
  %v1390 = load i64, ptr %slot1, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1391) nomerge, !dbg !134
  unreachable
bb_success295:
  %v1392 = load i64, ptr %slot206, align 8
  %v1393 = load i64, ptr %slot33, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i64 %v1392, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot33, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  %ld1397 = load i64, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1397, ptr %slot207, align 8
  %v1398 = load i64, ptr %slot207, align 8
  %v1399 = load i64, ptr %slot22, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  store i64 %v1398, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  %v1401 = load i64, ptr %slot22, align 8
  store i64 %v1401, ptr %slot208, align 8
  %v1402 = load i64, ptr %slot24, align 8
  store i64 %v1402, ptr %slot209, align 8
  %v1403 = load i64, ptr %slot208, align 8
  %v1404 = load i64, ptr %slot209, align 8
  %p1405 = inttoptr i64 %v1403 to ptr
  %p1406 = inttoptr i64 %v1404 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1406, ptr %p1405, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot18, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i32 2, ptr %p1408, align 4, !alias.scope !3, !noalias !4
  %v1409 = load i64, ptr %slot17, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i32 1, ptr %p1410, align 4, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot13, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i32, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1413, ptr %slot210, align 8
  %v1414 = load i32, ptr %slot210, align 8
  %cv1415 = zext i32 %v1414 to i64
  %cond1416 = icmp ne i64 %cv1415, 0
  br i1 %cond1416, label %bb_rcslotdrop303, label %bb_rcslotdone303
bb_rcslotdrop303:
  %v1417 = load i64, ptr %slot13, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 0, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot20, align 8
  store i64 %v1419, ptr %slot211, align 8
  %v1420 = load i64, ptr %slot14, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %ld1422 = load i32, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1422, ptr %slot212, align 8
  %v1423 = load i32, ptr %slot212, align 8
  %op1424 = and i32 %v1423, 28
  store i32 %op1424, ptr %slot213, align 8
  %v1425 = load i32, ptr %slot213, align 8
  %cv1426 = zext i32 %v1425 to i64
  %cond1427 = icmp ne i64 %cv1426, 0
  br i1 %cond1427, label %bb_rcslotrole303, label %bb_rcslotowner303
bb_rcslotrole303:
  %v1428 = load i64, ptr %slot48, align 8
  store i64 %v1428, ptr %slot214, align 8
  %v1429 = load i64, ptr %slot211, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot215, align 8
  %v1432 = load i64, ptr %slot215, align 8
  %cmp1433 = icmp ne i64 %v1432, 0
  %cv1434 = zext i1 %cmp1433 to i32
  store i32 %cv1434, ptr %slot216, align 8
  %v1435 = load i32, ptr %slot216, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcgnn319, label %bb_rcgdone319
bb_rcgnn319:
  %v1438 = load i64, ptr %slot215, align 8
  %op1439 = sub i64 %v1438, 16
  store i64 %op1439, ptr %slot217, align 8
  %v1440 = load i64, ptr %slot215, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %rgep1442 = getelementptr i8, ptr %p1441, i64 -16
  %ld1443 = load i64, ptr %rgep1442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1443, ptr %slot218, align 8
  %v1444 = load i64, ptr %slot218, align 8
  %op1445 = and i64 %v1444, 4611686018427387906
  store i64 %op1445, ptr %slot219, align 8
  %v1446 = load i64, ptr %slot219, align 8
  %cmp1447 = icmp ne i64 %v1446, 0
  %cv1448 = zext i1 %cmp1447 to i32
  store i32 %cv1448, ptr %slot220, align 8
  %v1449 = load i32, ptr %slot220, align 8
  %cv1450 = zext i32 %v1449 to i64
  %cond1451 = icmp ne i64 %cv1450, 0
  br i1 %cond1451, label %bb_rcgclear319, label %bb_rcgcounted319
bb_rcgcounted319:
  %v1452 = load i64, ptr %slot215, align 8
  %op1453 = sub i64 %v1452, 24
  store i64 %op1453, ptr %slot221, align 8
  %v1454 = load i64, ptr %slot215, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %rgep1456 = getelementptr i8, ptr %p1455, i64 -24
  %ld1457 = load i64, ptr %rgep1456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1457, ptr %slot222, align 8
  %v1458 = load i64, ptr %slot222, align 8
  %op1459 = sub i64 %v1458, 1
  store i64 %op1459, ptr %slot223, align 8
  %v1460 = load i64, ptr %slot223, align 8
  %cmp1461 = icmp eq i64 %v1460, 0
  %cv1462 = zext i1 %cmp1461 to i32
  store i32 %cv1462, ptr %slot224, align 8
  %v1463 = load i32, ptr %slot224, align 8
  %cv1464 = zext i32 %v1463 to i64
  %cond1465 = icmp ne i64 %cv1464, 0
  br i1 %cond1465, label %bb_rcglast319, label %bb_rcgdec319
bb_rcglast319:
  %v1466 = load i64, ptr %slot215, align 8
  %op1467 = sub i64 %v1466, 32
  store i64 %op1467, ptr %slot225, align 8
  %v1468 = load i64, ptr %slot215, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %rgep1470 = getelementptr i8, ptr %p1469, i64 -32
  %ld1471 = load i64, ptr %rgep1470, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1471, ptr %slot226, align 8
  %v1472 = load i64, ptr %slot226, align 8
  %cmp1473 = icmp ne i64 %v1472, 0
  %cv1474 = zext i1 %cmp1473 to i32
  store i32 %cv1474, ptr %slot227, align 8
  %v1475 = load i32, ptr %slot227, align 8
  %cv1476 = zext i32 %v1475 to i64
  %cond1477 = icmp ne i64 %cv1476, 0
  br i1 %cond1477, label %bb_rcgdec319, label %bb_rcgslow319
bb_rcgslow319:
  %v1478 = load i64, ptr %slot214, align 8
  %v1479 = load i64, ptr %slot211, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1478, i64 %v1479) nomerge, !dbg !134
  br label %bb_rcgdone319
bb_rcgdec319:
  %v1480 = load i64, ptr %slot223, align 8
  %v1481 = load i64, ptr %slot215, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %rgep1483 = getelementptr i8, ptr %p1482, i64 -24
  store i64 %v1480, ptr %rgep1483, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear319
bb_rcgclear319:
  %v1484 = load i64, ptr %slot211, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  store i64 0, ptr %p1485, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone319
bb_rcgdone319:
  br label %bb_rcslotdone303
bb_rcslotowner303:
  %v1486 = load i64, ptr %slot48, align 8
  store i64 %v1486, ptr %slot228, align 8
  %v1487 = load i64, ptr %slot211, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %ld1489 = load i64, ptr %p1488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1489, ptr %slot229, align 8
  %v1490 = load i64, ptr %slot229, align 8
  %cmp1491 = icmp ne i64 %v1490, 0
  %cv1492 = zext i1 %cmp1491 to i32
  store i32 %cv1492, ptr %slot230, align 8
  %v1493 = load i32, ptr %slot230, align 8
  %cv1494 = zext i32 %v1493 to i64
  %cond1495 = icmp ne i64 %cv1494, 0
  br i1 %cond1495, label %bb_rcgnn334, label %bb_rcgdone334
bb_rcgnn334:
  %v1496 = load i64, ptr %slot229, align 8
  %op1497 = sub i64 %v1496, 16
  store i64 %op1497, ptr %slot231, align 8
  %v1498 = load i64, ptr %slot229, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  %rgep1500 = getelementptr i8, ptr %p1499, i64 -16
  %ld1501 = load i64, ptr %rgep1500, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1501, ptr %slot232, align 8
  %v1502 = load i64, ptr %slot232, align 8
  %op1503 = and i64 %v1502, 4611686018427387906
  store i64 %op1503, ptr %slot233, align 8
  %v1504 = load i64, ptr %slot233, align 8
  %cmp1505 = icmp ne i64 %v1504, 0
  %cv1506 = zext i1 %cmp1505 to i32
  store i32 %cv1506, ptr %slot234, align 8
  %v1507 = load i32, ptr %slot234, align 8
  %cv1508 = zext i32 %v1507 to i64
  %cond1509 = icmp ne i64 %cv1508, 0
  br i1 %cond1509, label %bb_rcgclear334, label %bb_rcgcounted334
bb_rcgcounted334:
  %v1510 = load i64, ptr %slot229, align 8
  %op1511 = sub i64 %v1510, 32
  store i64 %op1511, ptr %slot235, align 8
  %v1512 = load i64, ptr %slot229, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %rgep1514 = getelementptr i8, ptr %p1513, i64 -32
  %ld1515 = load i64, ptr %rgep1514, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1515, ptr %slot236, align 8
  %v1516 = load i64, ptr %slot236, align 8
  %op1517 = sub i64 %v1516, 1
  store i64 %op1517, ptr %slot237, align 8
  %v1518 = load i64, ptr %slot237, align 8
  %cmp1519 = icmp eq i64 %v1518, 0
  %cv1520 = zext i1 %cmp1519 to i32
  store i32 %cv1520, ptr %slot238, align 8
  %v1521 = load i32, ptr %slot238, align 8
  %cv1522 = zext i32 %v1521 to i64
  %cond1523 = icmp ne i64 %cv1522, 0
  br i1 %cond1523, label %bb_rcglast334, label %bb_rcgdec334
bb_rcglast334:
  %v1524 = load i64, ptr %slot229, align 8
  %op1525 = sub i64 %v1524, 24
  store i64 %op1525, ptr %slot239, align 8
  %v1526 = load i64, ptr %slot229, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %rgep1528 = getelementptr i8, ptr %p1527, i64 -24
  %ld1529 = load i64, ptr %rgep1528, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1529, ptr %slot240, align 8
  %v1530 = load i64, ptr %slot240, align 8
  %cmp1531 = icmp ne i64 %v1530, 0
  %cv1532 = zext i1 %cmp1531 to i32
  store i32 %cv1532, ptr %slot241, align 8
  %v1533 = load i32, ptr %slot241, align 8
  %cv1534 = zext i32 %v1533 to i64
  %cond1535 = icmp ne i64 %cv1534, 0
  br i1 %cond1535, label %bb_rcgdec334, label %bb_rcgslow334
bb_rcgslow334:
  %v1536 = load i64, ptr %slot228, align 8
  %v1537 = load i64, ptr %slot211, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1536, i64 %v1537) nomerge, !dbg !134
  br label %bb_rcgdone334
bb_rcgdec334:
  %v1538 = load i64, ptr %slot237, align 8
  %v1539 = load i64, ptr %slot229, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %rgep1541 = getelementptr i8, ptr %p1540, i64 -32
  store i64 %v1538, ptr %rgep1541, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear334
bb_rcgclear334:
  %v1542 = load i64, ptr %slot211, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  store i64 0, ptr %p1543, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone334
bb_rcgdone334:
  br label %bb_rcslotdone303
bb_rcslotdone303:
  %v1544 = load i64, ptr %slot15, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %ld1546 = load i32, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1546, ptr %slot242, align 8
  %v1547 = load i32, ptr %slot242, align 8
  %cv1548 = zext i32 %v1547 to i64
  %cond1549 = icmp ne i64 %cv1548, 0
  br i1 %cond1549, label %bb_rcslotdrop340, label %bb_rcslotdone340
bb_rcslotdrop340:
  %v1550 = load i64, ptr %slot15, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  store i32 0, ptr %p1551, align 4, !alias.scope !3, !noalias !4
  %v1552 = load i64, ptr %slot21, align 8
  store i64 %v1552, ptr %slot243, align 8
  %v1553 = load i64, ptr %slot16, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  %ld1555 = load i32, ptr %p1554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1555, ptr %slot244, align 8
  %v1556 = load i32, ptr %slot244, align 8
  %op1557 = and i32 %v1556, 28
  store i32 %op1557, ptr %slot245, align 8
  %v1558 = load i32, ptr %slot245, align 8
  %cv1559 = zext i32 %v1558 to i64
  %cond1560 = icmp ne i64 %cv1559, 0
  br i1 %cond1560, label %bb_rcslotrole340, label %bb_rcslotowner340
bb_rcslotrole340:
  %v1561 = load i64, ptr %slot48, align 8
  store i64 %v1561, ptr %slot246, align 8
  %v1562 = load i64, ptr %slot243, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  %ld1564 = load i64, ptr %p1563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1564, ptr %slot247, align 8
  %v1565 = load i64, ptr %slot247, align 8
  %cmp1566 = icmp ne i64 %v1565, 0
  %cv1567 = zext i1 %cmp1566 to i32
  store i32 %cv1567, ptr %slot248, align 8
  %v1568 = load i32, ptr %slot248, align 8
  %cv1569 = zext i32 %v1568 to i64
  %cond1570 = icmp ne i64 %cv1569, 0
  br i1 %cond1570, label %bb_rcgnn356, label %bb_rcgdone356
bb_rcgnn356:
  %v1571 = load i64, ptr %slot247, align 8
  %op1572 = sub i64 %v1571, 16
  store i64 %op1572, ptr %slot249, align 8
  %v1573 = load i64, ptr %slot247, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %rgep1575 = getelementptr i8, ptr %p1574, i64 -16
  %ld1576 = load i64, ptr %rgep1575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1576, ptr %slot250, align 8
  %v1577 = load i64, ptr %slot250, align 8
  %op1578 = and i64 %v1577, 4611686018427387906
  store i64 %op1578, ptr %slot251, align 8
  %v1579 = load i64, ptr %slot251, align 8
  %cmp1580 = icmp ne i64 %v1579, 0
  %cv1581 = zext i1 %cmp1580 to i32
  store i32 %cv1581, ptr %slot252, align 8
  %v1582 = load i32, ptr %slot252, align 8
  %cv1583 = zext i32 %v1582 to i64
  %cond1584 = icmp ne i64 %cv1583, 0
  br i1 %cond1584, label %bb_rcgclear356, label %bb_rcgcounted356
bb_rcgcounted356:
  %v1585 = load i64, ptr %slot247, align 8
  %op1586 = sub i64 %v1585, 24
  store i64 %op1586, ptr %slot253, align 8
  %v1587 = load i64, ptr %slot247, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %rgep1589 = getelementptr i8, ptr %p1588, i64 -24
  %ld1590 = load i64, ptr %rgep1589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1590, ptr %slot254, align 8
  %v1591 = load i64, ptr %slot254, align 8
  %op1592 = sub i64 %v1591, 1
  store i64 %op1592, ptr %slot255, align 8
  %v1593 = load i64, ptr %slot255, align 8
  %cmp1594 = icmp eq i64 %v1593, 0
  %cv1595 = zext i1 %cmp1594 to i32
  store i32 %cv1595, ptr %slot256, align 8
  %v1596 = load i32, ptr %slot256, align 8
  %cv1597 = zext i32 %v1596 to i64
  %cond1598 = icmp ne i64 %cv1597, 0
  br i1 %cond1598, label %bb_rcglast356, label %bb_rcgdec356
bb_rcglast356:
  %v1599 = load i64, ptr %slot247, align 8
  %op1600 = sub i64 %v1599, 32
  store i64 %op1600, ptr %slot257, align 8
  %v1601 = load i64, ptr %slot247, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %rgep1603 = getelementptr i8, ptr %p1602, i64 -32
  %ld1604 = load i64, ptr %rgep1603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1604, ptr %slot258, align 8
  %v1605 = load i64, ptr %slot258, align 8
  %cmp1606 = icmp ne i64 %v1605, 0
  %cv1607 = zext i1 %cmp1606 to i32
  store i32 %cv1607, ptr %slot259, align 8
  %v1608 = load i32, ptr %slot259, align 8
  %cv1609 = zext i32 %v1608 to i64
  %cond1610 = icmp ne i64 %cv1609, 0
  br i1 %cond1610, label %bb_rcgdec356, label %bb_rcgslow356
bb_rcgslow356:
  %v1611 = load i64, ptr %slot246, align 8
  %v1612 = load i64, ptr %slot243, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1611, i64 %v1612) nomerge, !dbg !134
  br label %bb_rcgdone356
bb_rcgdec356:
  %v1613 = load i64, ptr %slot255, align 8
  %v1614 = load i64, ptr %slot247, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  %rgep1616 = getelementptr i8, ptr %p1615, i64 -24
  store i64 %v1613, ptr %rgep1616, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear356
bb_rcgclear356:
  %v1617 = load i64, ptr %slot243, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  store i64 0, ptr %p1618, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone356
bb_rcgdone356:
  br label %bb_rcslotdone340
bb_rcslotowner340:
  %v1619 = load i64, ptr %slot48, align 8
  store i64 %v1619, ptr %slot260, align 8
  %v1620 = load i64, ptr %slot243, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %ld1622 = load i64, ptr %p1621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1622, ptr %slot261, align 8
  %v1623 = load i64, ptr %slot261, align 8
  %cmp1624 = icmp ne i64 %v1623, 0
  %cv1625 = zext i1 %cmp1624 to i32
  store i32 %cv1625, ptr %slot262, align 8
  %v1626 = load i32, ptr %slot262, align 8
  %cv1627 = zext i32 %v1626 to i64
  %cond1628 = icmp ne i64 %cv1627, 0
  br i1 %cond1628, label %bb_rcgnn371, label %bb_rcgdone371
bb_rcgnn371:
  %v1629 = load i64, ptr %slot261, align 8
  %op1630 = sub i64 %v1629, 16
  store i64 %op1630, ptr %slot263, align 8
  %v1631 = load i64, ptr %slot261, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  %rgep1633 = getelementptr i8, ptr %p1632, i64 -16
  %ld1634 = load i64, ptr %rgep1633, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1634, ptr %slot264, align 8
  %v1635 = load i64, ptr %slot264, align 8
  %op1636 = and i64 %v1635, 4611686018427387906
  store i64 %op1636, ptr %slot265, align 8
  %v1637 = load i64, ptr %slot265, align 8
  %cmp1638 = icmp ne i64 %v1637, 0
  %cv1639 = zext i1 %cmp1638 to i32
  store i32 %cv1639, ptr %slot266, align 8
  %v1640 = load i32, ptr %slot266, align 8
  %cv1641 = zext i32 %v1640 to i64
  %cond1642 = icmp ne i64 %cv1641, 0
  br i1 %cond1642, label %bb_rcgclear371, label %bb_rcgcounted371
bb_rcgcounted371:
  %v1643 = load i64, ptr %slot261, align 8
  %op1644 = sub i64 %v1643, 32
  store i64 %op1644, ptr %slot267, align 8
  %v1645 = load i64, ptr %slot261, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %rgep1647 = getelementptr i8, ptr %p1646, i64 -32
  %ld1648 = load i64, ptr %rgep1647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1648, ptr %slot268, align 8
  %v1649 = load i64, ptr %slot268, align 8
  %op1650 = sub i64 %v1649, 1
  store i64 %op1650, ptr %slot269, align 8
  %v1651 = load i64, ptr %slot269, align 8
  %cmp1652 = icmp eq i64 %v1651, 0
  %cv1653 = zext i1 %cmp1652 to i32
  store i32 %cv1653, ptr %slot270, align 8
  %v1654 = load i32, ptr %slot270, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcglast371, label %bb_rcgdec371
bb_rcglast371:
  %v1657 = load i64, ptr %slot261, align 8
  %op1658 = sub i64 %v1657, 24
  store i64 %op1658, ptr %slot271, align 8
  %v1659 = load i64, ptr %slot261, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %rgep1661 = getelementptr i8, ptr %p1660, i64 -24
  %ld1662 = load i64, ptr %rgep1661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1662, ptr %slot272, align 8
  %v1663 = load i64, ptr %slot272, align 8
  %cmp1664 = icmp ne i64 %v1663, 0
  %cv1665 = zext i1 %cmp1664 to i32
  store i32 %cv1665, ptr %slot273, align 8
  %v1666 = load i32, ptr %slot273, align 8
  %cv1667 = zext i32 %v1666 to i64
  %cond1668 = icmp ne i64 %cv1667, 0
  br i1 %cond1668, label %bb_rcgdec371, label %bb_rcgslow371
bb_rcgslow371:
  %v1669 = load i64, ptr %slot260, align 8
  %v1670 = load i64, ptr %slot243, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1669, i64 %v1670) nomerge, !dbg !134
  br label %bb_rcgdone371
bb_rcgdec371:
  %v1671 = load i64, ptr %slot269, align 8
  %v1672 = load i64, ptr %slot261, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %rgep1674 = getelementptr i8, ptr %p1673, i64 -32
  store i64 %v1671, ptr %rgep1674, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear371
bb_rcgclear371:
  %v1675 = load i64, ptr %slot243, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  store i64 0, ptr %p1676, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone371
bb_rcgdone371:
  br label %bb_rcslotdone340
bb_rcslotdone340:
  %v1677 = load i64, ptr %slot20, align 8
  store i64 %v1677, ptr %slot274, align 8
  %v1678 = load i64, ptr %slot24, align 8
  store i64 %v1678, ptr %slot275, align 8
  %v1679 = load i64, ptr %slot275, align 8
  %v1680 = load i64, ptr %slot274, align 8
  %p1681 = inttoptr i64 %v1679 to ptr
  %p1682 = inttoptr i64 %v1680 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1682, ptr %p1681, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot14, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  store i32 2, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  %v1685 = load i64, ptr %slot18, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %ld1687 = load i32, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1687, ptr %slot276, align 8
  %v1688 = load i32, ptr %slot276, align 8
  %v1689 = load i64, ptr %slot14, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i32 %v1688, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot17, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i32 0, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot13, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 1, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot274, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %ld1697 = load i64, ptr %p1696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1697, ptr %slot277, align 8
  %v1698 = load i64, ptr %slot277, align 8
  %v1699 = load i64, ptr %slot33, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i64 %v1698, ptr %p1700, align 8, !alias.scope !3, !noalias !4
  %p1701 = inttoptr i64 ptrtoint (ptr @myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 to i64) to ptr
  %ld1702 = load i64, ptr %p1701, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1702, ptr %slot278, align 8
  %v1703 = load i64, ptr %slot278, align 8
  %v1704 = load i64, ptr %slot34, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i64 %v1703, ptr %p1705, align 8, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot34, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  %ld1708 = load i64, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1708, ptr %slot279, align 8
  %v1709 = load i64, ptr %slot279, align 8
  %v1710 = load i64, ptr %slot23, align 8
  %p1711 = inttoptr i64 %v1710 to ptr
  store i64 %v1709, ptr %p1711, align 8, !alias.scope !3, !noalias !4
  %v1712 = load i64, ptr %slot23, align 8
  store i64 %v1712, ptr %slot280, align 8
  %v1713 = load i64, ptr %slot24, align 8
  store i64 %v1713, ptr %slot281, align 8
  %v1714 = load i64, ptr %slot280, align 8
  %v1715 = load i64, ptr %slot281, align 8
  %p1716 = inttoptr i64 %v1714 to ptr
  %p1717 = inttoptr i64 %v1715 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1717, ptr %p1716, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1718 = load i64, ptr %slot18, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  store i32 2, ptr %p1719, align 4, !alias.scope !3, !noalias !4
  %v1720 = load i64, ptr %slot17, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  store i32 1, ptr %p1721, align 4, !alias.scope !3, !noalias !4
  %v1722 = load i64, ptr %slot21, align 8
  store i64 %v1722, ptr %slot282, align 8
  %v1723 = load i64, ptr %slot24, align 8
  store i64 %v1723, ptr %slot283, align 8
  %v1724 = load i64, ptr %slot283, align 8
  %v1725 = load i64, ptr %slot282, align 8
  %p1726 = inttoptr i64 %v1724 to ptr
  %p1727 = inttoptr i64 %v1725 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1727, ptr %p1726, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot16, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  store i32 2, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  %v1730 = load i64, ptr %slot18, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  %ld1732 = load i32, ptr %p1731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1732, ptr %slot284, align 8
  %v1733 = load i32, ptr %slot284, align 8
  %v1734 = load i64, ptr %slot16, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  store i32 %v1733, ptr %p1735, align 4, !alias.scope !3, !noalias !4
  %v1736 = load i64, ptr %slot17, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  store i32 0, ptr %p1737, align 4, !alias.scope !3, !noalias !4
  %v1738 = load i64, ptr %slot15, align 8
  %p1739 = inttoptr i64 %v1738 to ptr
  store i32 1, ptr %p1739, align 4, !alias.scope !3, !noalias !4
  %v1740 = load i64, ptr %slot282, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  %ld1742 = load i64, ptr %p1741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1742, ptr %slot285, align 8
  %v1743 = load i64, ptr %slot285, align 8
  %v1744 = load i64, ptr %slot34, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  store i64 %v1743, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  %v1746 = load i64, ptr %slot33, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i64, ptr %p1747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1748, ptr %slot286, align 8
  %v1749 = load i64, ptr %slot34, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot287, align 8
  %v1752 = load i64, ptr %slot33, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  %ld1754 = load i64, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1754, ptr %slot288, align 8
  %v1755 = load i64, ptr %slot34, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i64, ptr %p1756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1757, ptr %slot289, align 8
  %v1758 = load i64, ptr %slot48, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %v1760 = load i64, ptr %slot288, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %v1762 = load i64, ptr %slot289, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %call1764 = call ptr @myl_native_bytes_concat(ptr %p1759, ptr %p1761, ptr %p1763) nomerge, !dbg !136
  %calladdr1765 = ptrtoint ptr %call1764 to i64
  store i64 %calladdr1765, ptr %slot290, align 8
  %v1766 = load i64, ptr %slot290, align 8
  %cond1767 = icmp ne i64 %v1766, 0
  br i1 %cond1767, label %bb_success406, label %bb_failed406
bb_failed406:
  %v1768 = load i64, ptr %slot1, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1769) nomerge, !dbg !136
  unreachable
bb_success406:
  %v1770 = load i64, ptr %slot290, align 8
  %v1771 = load i64, ptr %slot33, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i64 %v1770, ptr %p1772, align 8, !alias.scope !3, !noalias !4
  %v1773 = load i64, ptr %slot33, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  %ld1775 = load i64, ptr %p1774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1775, ptr %slot291, align 8
  %v1776 = load i64, ptr %slot291, align 8
  %v1777 = load i64, ptr %slot22, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  store i64 %v1776, ptr %p1778, align 8, !alias.scope !3, !noalias !4
  %v1779 = load i64, ptr %slot22, align 8
  store i64 %v1779, ptr %slot292, align 8
  %v1780 = load i64, ptr %slot24, align 8
  store i64 %v1780, ptr %slot293, align 8
  %v1781 = load i64, ptr %slot292, align 8
  %v1782 = load i64, ptr %slot293, align 8
  %p1783 = inttoptr i64 %v1781 to ptr
  %p1784 = inttoptr i64 %v1782 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1784, ptr %p1783, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1785 = load i64, ptr %slot18, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i32 2, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot17, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i32 1, ptr %p1788, align 4, !alias.scope !3, !noalias !4
  %v1789 = load i64, ptr %slot13, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i32, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1791, ptr %slot294, align 8
  %v1792 = load i32, ptr %slot294, align 8
  %cv1793 = zext i32 %v1792 to i64
  %cond1794 = icmp ne i64 %cv1793, 0
  br i1 %cond1794, label %bb_rcslotdrop414, label %bb_rcslotdone414
bb_rcslotdrop414:
  %v1795 = load i64, ptr %slot13, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i32 0, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot20, align 8
  store i64 %v1797, ptr %slot295, align 8
  %v1798 = load i64, ptr %slot14, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  %ld1800 = load i32, ptr %p1799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1800, ptr %slot296, align 8
  %v1801 = load i32, ptr %slot296, align 8
  %op1802 = and i32 %v1801, 28
  store i32 %op1802, ptr %slot297, align 8
  %v1803 = load i32, ptr %slot297, align 8
  %cv1804 = zext i32 %v1803 to i64
  %cond1805 = icmp ne i64 %cv1804, 0
  br i1 %cond1805, label %bb_rcslotrole414, label %bb_rcslotowner414
bb_rcslotrole414:
  %v1806 = load i64, ptr %slot48, align 8
  store i64 %v1806, ptr %slot298, align 8
  %v1807 = load i64, ptr %slot295, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %ld1809 = load i64, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1809, ptr %slot299, align 8
  %v1810 = load i64, ptr %slot299, align 8
  %cmp1811 = icmp ne i64 %v1810, 0
  %cv1812 = zext i1 %cmp1811 to i32
  store i32 %cv1812, ptr %slot300, align 8
  %v1813 = load i32, ptr %slot300, align 8
  %cv1814 = zext i32 %v1813 to i64
  %cond1815 = icmp ne i64 %cv1814, 0
  br i1 %cond1815, label %bb_rcgnn430, label %bb_rcgdone430
bb_rcgnn430:
  %v1816 = load i64, ptr %slot299, align 8
  %op1817 = sub i64 %v1816, 16
  store i64 %op1817, ptr %slot301, align 8
  %v1818 = load i64, ptr %slot299, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  %rgep1820 = getelementptr i8, ptr %p1819, i64 -16
  %ld1821 = load i64, ptr %rgep1820, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1821, ptr %slot302, align 8
  %v1822 = load i64, ptr %slot302, align 8
  %op1823 = and i64 %v1822, 4611686018427387906
  store i64 %op1823, ptr %slot303, align 8
  %v1824 = load i64, ptr %slot303, align 8
  %cmp1825 = icmp ne i64 %v1824, 0
  %cv1826 = zext i1 %cmp1825 to i32
  store i32 %cv1826, ptr %slot304, align 8
  %v1827 = load i32, ptr %slot304, align 8
  %cv1828 = zext i32 %v1827 to i64
  %cond1829 = icmp ne i64 %cv1828, 0
  br i1 %cond1829, label %bb_rcgclear430, label %bb_rcgcounted430
bb_rcgcounted430:
  %v1830 = load i64, ptr %slot299, align 8
  %op1831 = sub i64 %v1830, 24
  store i64 %op1831, ptr %slot305, align 8
  %v1832 = load i64, ptr %slot299, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %rgep1834 = getelementptr i8, ptr %p1833, i64 -24
  %ld1835 = load i64, ptr %rgep1834, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1835, ptr %slot306, align 8
  %v1836 = load i64, ptr %slot306, align 8
  %op1837 = sub i64 %v1836, 1
  store i64 %op1837, ptr %slot307, align 8
  %v1838 = load i64, ptr %slot307, align 8
  %cmp1839 = icmp eq i64 %v1838, 0
  %cv1840 = zext i1 %cmp1839 to i32
  store i32 %cv1840, ptr %slot308, align 8
  %v1841 = load i32, ptr %slot308, align 8
  %cv1842 = zext i32 %v1841 to i64
  %cond1843 = icmp ne i64 %cv1842, 0
  br i1 %cond1843, label %bb_rcglast430, label %bb_rcgdec430
bb_rcglast430:
  %v1844 = load i64, ptr %slot299, align 8
  %op1845 = sub i64 %v1844, 32
  store i64 %op1845, ptr %slot309, align 8
  %v1846 = load i64, ptr %slot299, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %rgep1848 = getelementptr i8, ptr %p1847, i64 -32
  %ld1849 = load i64, ptr %rgep1848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1849, ptr %slot310, align 8
  %v1850 = load i64, ptr %slot310, align 8
  %cmp1851 = icmp ne i64 %v1850, 0
  %cv1852 = zext i1 %cmp1851 to i32
  store i32 %cv1852, ptr %slot311, align 8
  %v1853 = load i32, ptr %slot311, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rcgdec430, label %bb_rcgslow430
bb_rcgslow430:
  %v1856 = load i64, ptr %slot298, align 8
  %v1857 = load i64, ptr %slot295, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1856, i64 %v1857) nomerge, !dbg !136
  br label %bb_rcgdone430
bb_rcgdec430:
  %v1858 = load i64, ptr %slot307, align 8
  %v1859 = load i64, ptr %slot299, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  %rgep1861 = getelementptr i8, ptr %p1860, i64 -24
  store i64 %v1858, ptr %rgep1861, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear430
bb_rcgclear430:
  %v1862 = load i64, ptr %slot295, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i64 0, ptr %p1863, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone430
bb_rcgdone430:
  br label %bb_rcslotdone414
bb_rcslotowner414:
  %v1864 = load i64, ptr %slot48, align 8
  store i64 %v1864, ptr %slot312, align 8
  %v1865 = load i64, ptr %slot295, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %ld1867 = load i64, ptr %p1866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1867, ptr %slot313, align 8
  %v1868 = load i64, ptr %slot313, align 8
  %cmp1869 = icmp ne i64 %v1868, 0
  %cv1870 = zext i1 %cmp1869 to i32
  store i32 %cv1870, ptr %slot314, align 8
  %v1871 = load i32, ptr %slot314, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcgnn445, label %bb_rcgdone445
bb_rcgnn445:
  %v1874 = load i64, ptr %slot313, align 8
  %op1875 = sub i64 %v1874, 16
  store i64 %op1875, ptr %slot315, align 8
  %v1876 = load i64, ptr %slot313, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %rgep1878 = getelementptr i8, ptr %p1877, i64 -16
  %ld1879 = load i64, ptr %rgep1878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1879, ptr %slot316, align 8
  %v1880 = load i64, ptr %slot316, align 8
  %op1881 = and i64 %v1880, 4611686018427387906
  store i64 %op1881, ptr %slot317, align 8
  %v1882 = load i64, ptr %slot317, align 8
  %cmp1883 = icmp ne i64 %v1882, 0
  %cv1884 = zext i1 %cmp1883 to i32
  store i32 %cv1884, ptr %slot318, align 8
  %v1885 = load i32, ptr %slot318, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcgclear445, label %bb_rcgcounted445
bb_rcgcounted445:
  %v1888 = load i64, ptr %slot313, align 8
  %op1889 = sub i64 %v1888, 32
  store i64 %op1889, ptr %slot319, align 8
  %v1890 = load i64, ptr %slot313, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %rgep1892 = getelementptr i8, ptr %p1891, i64 -32
  %ld1893 = load i64, ptr %rgep1892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1893, ptr %slot320, align 8
  %v1894 = load i64, ptr %slot320, align 8
  %op1895 = sub i64 %v1894, 1
  store i64 %op1895, ptr %slot321, align 8
  %v1896 = load i64, ptr %slot321, align 8
  %cmp1897 = icmp eq i64 %v1896, 0
  %cv1898 = zext i1 %cmp1897 to i32
  store i32 %cv1898, ptr %slot322, align 8
  %v1899 = load i32, ptr %slot322, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcglast445, label %bb_rcgdec445
bb_rcglast445:
  %v1902 = load i64, ptr %slot313, align 8
  %op1903 = sub i64 %v1902, 24
  store i64 %op1903, ptr %slot323, align 8
  %v1904 = load i64, ptr %slot313, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %rgep1906 = getelementptr i8, ptr %p1905, i64 -24
  %ld1907 = load i64, ptr %rgep1906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1907, ptr %slot324, align 8
  %v1908 = load i64, ptr %slot324, align 8
  %cmp1909 = icmp ne i64 %v1908, 0
  %cv1910 = zext i1 %cmp1909 to i32
  store i32 %cv1910, ptr %slot325, align 8
  %v1911 = load i32, ptr %slot325, align 8
  %cv1912 = zext i32 %v1911 to i64
  %cond1913 = icmp ne i64 %cv1912, 0
  br i1 %cond1913, label %bb_rcgdec445, label %bb_rcgslow445
bb_rcgslow445:
  %v1914 = load i64, ptr %slot312, align 8
  %v1915 = load i64, ptr %slot295, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1914, i64 %v1915) nomerge, !dbg !136
  br label %bb_rcgdone445
bb_rcgdec445:
  %v1916 = load i64, ptr %slot321, align 8
  %v1917 = load i64, ptr %slot313, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %rgep1919 = getelementptr i8, ptr %p1918, i64 -32
  store i64 %v1916, ptr %rgep1919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear445
bb_rcgclear445:
  %v1920 = load i64, ptr %slot295, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i64 0, ptr %p1921, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone445
bb_rcgdone445:
  br label %bb_rcslotdone414
bb_rcslotdone414:
  %v1922 = load i64, ptr %slot15, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i32, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1924, ptr %slot326, align 8
  %v1925 = load i32, ptr %slot326, align 8
  %cv1926 = zext i32 %v1925 to i64
  %cond1927 = icmp ne i64 %cv1926, 0
  br i1 %cond1927, label %bb_rcslotdrop451, label %bb_rcslotdone451
bb_rcslotdrop451:
  %v1928 = load i64, ptr %slot15, align 8
  %p1929 = inttoptr i64 %v1928 to ptr
  store i32 0, ptr %p1929, align 4, !alias.scope !3, !noalias !4
  %v1930 = load i64, ptr %slot21, align 8
  store i64 %v1930, ptr %slot327, align 8
  %v1931 = load i64, ptr %slot16, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  %ld1933 = load i32, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1933, ptr %slot328, align 8
  %v1934 = load i32, ptr %slot328, align 8
  %op1935 = and i32 %v1934, 28
  store i32 %op1935, ptr %slot329, align 8
  %v1936 = load i32, ptr %slot329, align 8
  %cv1937 = zext i32 %v1936 to i64
  %cond1938 = icmp ne i64 %cv1937, 0
  br i1 %cond1938, label %bb_rcslotrole451, label %bb_rcslotowner451
bb_rcslotrole451:
  %v1939 = load i64, ptr %slot48, align 8
  store i64 %v1939, ptr %slot330, align 8
  %v1940 = load i64, ptr %slot327, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i64, ptr %p1941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1942, ptr %slot331, align 8
  %v1943 = load i64, ptr %slot331, align 8
  %cmp1944 = icmp ne i64 %v1943, 0
  %cv1945 = zext i1 %cmp1944 to i32
  store i32 %cv1945, ptr %slot332, align 8
  %v1946 = load i32, ptr %slot332, align 8
  %cv1947 = zext i32 %v1946 to i64
  %cond1948 = icmp ne i64 %cv1947, 0
  br i1 %cond1948, label %bb_rcgnn467, label %bb_rcgdone467
bb_rcgnn467:
  %v1949 = load i64, ptr %slot331, align 8
  %op1950 = sub i64 %v1949, 16
  store i64 %op1950, ptr %slot333, align 8
  %v1951 = load i64, ptr %slot331, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %rgep1953 = getelementptr i8, ptr %p1952, i64 -16
  %ld1954 = load i64, ptr %rgep1953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1954, ptr %slot334, align 8
  %v1955 = load i64, ptr %slot334, align 8
  %op1956 = and i64 %v1955, 4611686018427387906
  store i64 %op1956, ptr %slot335, align 8
  %v1957 = load i64, ptr %slot335, align 8
  %cmp1958 = icmp ne i64 %v1957, 0
  %cv1959 = zext i1 %cmp1958 to i32
  store i32 %cv1959, ptr %slot336, align 8
  %v1960 = load i32, ptr %slot336, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcgclear467, label %bb_rcgcounted467
bb_rcgcounted467:
  %v1963 = load i64, ptr %slot331, align 8
  %op1964 = sub i64 %v1963, 24
  store i64 %op1964, ptr %slot337, align 8
  %v1965 = load i64, ptr %slot331, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  %rgep1967 = getelementptr i8, ptr %p1966, i64 -24
  %ld1968 = load i64, ptr %rgep1967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1968, ptr %slot338, align 8
  %v1969 = load i64, ptr %slot338, align 8
  %op1970 = sub i64 %v1969, 1
  store i64 %op1970, ptr %slot339, align 8
  %v1971 = load i64, ptr %slot339, align 8
  %cmp1972 = icmp eq i64 %v1971, 0
  %cv1973 = zext i1 %cmp1972 to i32
  store i32 %cv1973, ptr %slot340, align 8
  %v1974 = load i32, ptr %slot340, align 8
  %cv1975 = zext i32 %v1974 to i64
  %cond1976 = icmp ne i64 %cv1975, 0
  br i1 %cond1976, label %bb_rcglast467, label %bb_rcgdec467
bb_rcglast467:
  %v1977 = load i64, ptr %slot331, align 8
  %op1978 = sub i64 %v1977, 32
  store i64 %op1978, ptr %slot341, align 8
  %v1979 = load i64, ptr %slot331, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  %rgep1981 = getelementptr i8, ptr %p1980, i64 -32
  %ld1982 = load i64, ptr %rgep1981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1982, ptr %slot342, align 8
  %v1983 = load i64, ptr %slot342, align 8
  %cmp1984 = icmp ne i64 %v1983, 0
  %cv1985 = zext i1 %cmp1984 to i32
  store i32 %cv1985, ptr %slot343, align 8
  %v1986 = load i32, ptr %slot343, align 8
  %cv1987 = zext i32 %v1986 to i64
  %cond1988 = icmp ne i64 %cv1987, 0
  br i1 %cond1988, label %bb_rcgdec467, label %bb_rcgslow467
bb_rcgslow467:
  %v1989 = load i64, ptr %slot330, align 8
  %v1990 = load i64, ptr %slot327, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1989, i64 %v1990) nomerge, !dbg !136
  br label %bb_rcgdone467
bb_rcgdec467:
  %v1991 = load i64, ptr %slot339, align 8
  %v1992 = load i64, ptr %slot331, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %rgep1994 = getelementptr i8, ptr %p1993, i64 -24
  store i64 %v1991, ptr %rgep1994, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear467
bb_rcgclear467:
  %v1995 = load i64, ptr %slot327, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i64 0, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone467
bb_rcgdone467:
  br label %bb_rcslotdone451
bb_rcslotowner451:
  %v1997 = load i64, ptr %slot48, align 8
  store i64 %v1997, ptr %slot344, align 8
  %v1998 = load i64, ptr %slot327, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ld2000 = load i64, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2000, ptr %slot345, align 8
  %v2001 = load i64, ptr %slot345, align 8
  %cmp2002 = icmp ne i64 %v2001, 0
  %cv2003 = zext i1 %cmp2002 to i32
  store i32 %cv2003, ptr %slot346, align 8
  %v2004 = load i32, ptr %slot346, align 8
  %cv2005 = zext i32 %v2004 to i64
  %cond2006 = icmp ne i64 %cv2005, 0
  br i1 %cond2006, label %bb_rcgnn482, label %bb_rcgdone482
bb_rcgnn482:
  %v2007 = load i64, ptr %slot345, align 8
  %op2008 = sub i64 %v2007, 16
  store i64 %op2008, ptr %slot347, align 8
  %v2009 = load i64, ptr %slot345, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %rgep2011 = getelementptr i8, ptr %p2010, i64 -16
  %ld2012 = load i64, ptr %rgep2011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2012, ptr %slot348, align 8
  %v2013 = load i64, ptr %slot348, align 8
  %op2014 = and i64 %v2013, 4611686018427387906
  store i64 %op2014, ptr %slot349, align 8
  %v2015 = load i64, ptr %slot349, align 8
  %cmp2016 = icmp ne i64 %v2015, 0
  %cv2017 = zext i1 %cmp2016 to i32
  store i32 %cv2017, ptr %slot350, align 8
  %v2018 = load i32, ptr %slot350, align 8
  %cv2019 = zext i32 %v2018 to i64
  %cond2020 = icmp ne i64 %cv2019, 0
  br i1 %cond2020, label %bb_rcgclear482, label %bb_rcgcounted482
bb_rcgcounted482:
  %v2021 = load i64, ptr %slot345, align 8
  %op2022 = sub i64 %v2021, 32
  store i64 %op2022, ptr %slot351, align 8
  %v2023 = load i64, ptr %slot345, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  %rgep2025 = getelementptr i8, ptr %p2024, i64 -32
  %ld2026 = load i64, ptr %rgep2025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2026, ptr %slot352, align 8
  %v2027 = load i64, ptr %slot352, align 8
  %op2028 = sub i64 %v2027, 1
  store i64 %op2028, ptr %slot353, align 8
  %v2029 = load i64, ptr %slot353, align 8
  %cmp2030 = icmp eq i64 %v2029, 0
  %cv2031 = zext i1 %cmp2030 to i32
  store i32 %cv2031, ptr %slot354, align 8
  %v2032 = load i32, ptr %slot354, align 8
  %cv2033 = zext i32 %v2032 to i64
  %cond2034 = icmp ne i64 %cv2033, 0
  br i1 %cond2034, label %bb_rcglast482, label %bb_rcgdec482
bb_rcglast482:
  %v2035 = load i64, ptr %slot345, align 8
  %op2036 = sub i64 %v2035, 24
  store i64 %op2036, ptr %slot355, align 8
  %v2037 = load i64, ptr %slot345, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %rgep2039 = getelementptr i8, ptr %p2038, i64 -24
  %ld2040 = load i64, ptr %rgep2039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2040, ptr %slot356, align 8
  %v2041 = load i64, ptr %slot356, align 8
  %cmp2042 = icmp ne i64 %v2041, 0
  %cv2043 = zext i1 %cmp2042 to i32
  store i32 %cv2043, ptr %slot357, align 8
  %v2044 = load i32, ptr %slot357, align 8
  %cv2045 = zext i32 %v2044 to i64
  %cond2046 = icmp ne i64 %cv2045, 0
  br i1 %cond2046, label %bb_rcgdec482, label %bb_rcgslow482
bb_rcgslow482:
  %v2047 = load i64, ptr %slot344, align 8
  %v2048 = load i64, ptr %slot327, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2047, i64 %v2048) nomerge, !dbg !136
  br label %bb_rcgdone482
bb_rcgdec482:
  %v2049 = load i64, ptr %slot353, align 8
  %v2050 = load i64, ptr %slot345, align 8
  %p2051 = inttoptr i64 %v2050 to ptr
  %rgep2052 = getelementptr i8, ptr %p2051, i64 -32
  store i64 %v2049, ptr %rgep2052, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear482
bb_rcgclear482:
  %v2053 = load i64, ptr %slot327, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i64 0, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone482
bb_rcgdone482:
  br label %bb_rcslotdone451
bb_rcslotdone451:
  %v2055 = load i64, ptr %slot20, align 8
  store i64 %v2055, ptr %slot358, align 8
  %v2056 = load i64, ptr %slot24, align 8
  store i64 %v2056, ptr %slot359, align 8
  %v2057 = load i64, ptr %slot359, align 8
  %v2058 = load i64, ptr %slot358, align 8
  %p2059 = inttoptr i64 %v2057 to ptr
  %p2060 = inttoptr i64 %v2058 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2060, ptr %p2059, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2061 = load i64, ptr %slot14, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i32 2, ptr %p2062, align 4, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot18, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %ld2065 = load i32, ptr %p2064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2065, ptr %slot360, align 8
  %v2066 = load i32, ptr %slot360, align 8
  %v2067 = load i64, ptr %slot14, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  store i32 %v2066, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  %v2069 = load i64, ptr %slot17, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i32 0, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot13, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i32 1, ptr %p2072, align 4, !alias.scope !3, !noalias !4
  %v2073 = load i64, ptr %slot358, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  %ld2075 = load i64, ptr %p2074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2075, ptr %slot361, align 8
  %v2076 = load i64, ptr %slot361, align 8
  %v2077 = load i64, ptr %slot33, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  store i64 %v2076, ptr %p2078, align 8, !alias.scope !3, !noalias !4
  %v2079 = load i64, ptr %slot29, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %ld2081 = load i64, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2081, ptr %slot362, align 8
  %v2082 = load i64, ptr %slot362, align 8
  %v2083 = load i64, ptr %slot34, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i64 %v2082, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot33, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i64, ptr %p2086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2087, ptr %slot363, align 8
  %v2088 = load i64, ptr %slot34, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i64, ptr %p2089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2090, ptr %slot364, align 8
  %v2091 = load i64, ptr %slot1, align 8
  %v2092 = load i64, ptr %slot363, align 8
  %v2093 = load i64, ptr %slot364, align 8
  %call2094 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v2091, i64 %v2092, i64 %v2093) nomerge, !dbg !138
  store { i64, i64 } %call2094, ptr %callresult366, align 8
  %addr2095 = ptrtoint ptr %callresult366 to i64
  store i64 %addr2095, ptr %slot365, align 8
  %v2096 = load i64, ptr %slot365, align 8
  %v2097 = load i64, ptr %slot33, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  store i64 %v2096, ptr %p2098, align 8, !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot33, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %ld2101 = load i64, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2101, ptr %slot367, align 8
  %v2102 = load i64, ptr %slot24, align 8
  store i64 %v2102, ptr %slot368, align 8
  %v2103 = load i64, ptr %slot48, align 8
  %v2104 = load i64, ptr %slot368, align 8
  %v2105 = load i64, ptr %slot367, align 8
  %call2106 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v2103, i64 %v2104, i64 %v2105) nomerge, !dbg !138
  store i32 %call2106, ptr %slot369, align 8
  %v2107 = load i32, ptr %slot369, align 8
  %cv2108 = zext i32 %v2107 to i64
  %cond2109 = icmp ne i64 %cv2108, 0
  br i1 %cond2109, label %bb_rcsuccess502, label %bb_rcfailure502
bb_rcfailure502:
  %v2110 = load i64, ptr %slot48, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %call2112 = call i32 @myl_rc_take_failure(ptr %p2111) nomerge, !dbg !138
  store i32 %call2112, ptr %slot370, align 8
  %v2113 = load i64, ptr %slot1, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %v2115 = load i32, ptr %slot370, align 8
  %call2116 = call i32 @myl_qbe_rc_status(ptr %p2114, i32 %v2115) nomerge, !dbg !138
  store i32 %call2116, ptr %slot371, align 8
  br label %bb_failure
bb_rcsuccess502:
  %v2117 = load i64, ptr %slot18, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  store i32 2, ptr %p2118, align 4, !alias.scope !3, !noalias !4
  %v2119 = load i64, ptr %slot18, align 8
  %p2120 = inttoptr i64 %v2119 to ptr
  store i32 16, ptr %p2120, align 4, !alias.scope !3, !noalias !4
  %v2121 = load i64, ptr %slot17, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  store i32 1, ptr %p2122, align 4, !alias.scope !3, !noalias !4
  %v2123 = load i64, ptr %slot13, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  %ld2125 = load i32, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2125, ptr %slot372, align 8
  %v2126 = load i32, ptr %slot372, align 8
  %cv2127 = zext i32 %v2126 to i64
  %cond2128 = icmp ne i64 %cv2127, 0
  br i1 %cond2128, label %bb_rcslotdrop510, label %bb_rcslotdone510
bb_rcslotdrop510:
  %v2129 = load i64, ptr %slot13, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i32 0, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot20, align 8
  store i64 %v2131, ptr %slot373, align 8
  %v2132 = load i64, ptr %slot14, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %ld2134 = load i32, ptr %p2133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2134, ptr %slot374, align 8
  %v2135 = load i32, ptr %slot374, align 8
  %op2136 = and i32 %v2135, 28
  store i32 %op2136, ptr %slot375, align 8
  %v2137 = load i32, ptr %slot375, align 8
  %cv2138 = zext i32 %v2137 to i64
  %cond2139 = icmp ne i64 %cv2138, 0
  br i1 %cond2139, label %bb_rcslotrole510, label %bb_rcslotowner510
bb_rcslotrole510:
  %v2140 = load i64, ptr %slot48, align 8
  store i64 %v2140, ptr %slot376, align 8
  %v2141 = load i64, ptr %slot373, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  %ld2143 = load i64, ptr %p2142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2143, ptr %slot377, align 8
  %v2144 = load i64, ptr %slot377, align 8
  %cmp2145 = icmp ne i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i32
  store i32 %cv2146, ptr %slot378, align 8
  %v2147 = load i32, ptr %slot378, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcgnn526, label %bb_rcgdone526
bb_rcgnn526:
  %v2150 = load i64, ptr %slot377, align 8
  %op2151 = sub i64 %v2150, 16
  store i64 %op2151, ptr %slot379, align 8
  %v2152 = load i64, ptr %slot377, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  %rgep2154 = getelementptr i8, ptr %p2153, i64 -16
  %ld2155 = load i64, ptr %rgep2154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2155, ptr %slot380, align 8
  %v2156 = load i64, ptr %slot380, align 8
  %op2157 = and i64 %v2156, 4611686018427387906
  store i64 %op2157, ptr %slot381, align 8
  %v2158 = load i64, ptr %slot381, align 8
  %cmp2159 = icmp ne i64 %v2158, 0
  %cv2160 = zext i1 %cmp2159 to i32
  store i32 %cv2160, ptr %slot382, align 8
  %v2161 = load i32, ptr %slot382, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcgclear526, label %bb_rcgcounted526
bb_rcgcounted526:
  %v2164 = load i64, ptr %slot377, align 8
  %op2165 = sub i64 %v2164, 24
  store i64 %op2165, ptr %slot383, align 8
  %v2166 = load i64, ptr %slot377, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %rgep2168 = getelementptr i8, ptr %p2167, i64 -24
  %ld2169 = load i64, ptr %rgep2168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2169, ptr %slot384, align 8
  %v2170 = load i64, ptr %slot384, align 8
  %op2171 = sub i64 %v2170, 1
  store i64 %op2171, ptr %slot385, align 8
  %v2172 = load i64, ptr %slot385, align 8
  %cmp2173 = icmp eq i64 %v2172, 0
  %cv2174 = zext i1 %cmp2173 to i32
  store i32 %cv2174, ptr %slot386, align 8
  %v2175 = load i32, ptr %slot386, align 8
  %cv2176 = zext i32 %v2175 to i64
  %cond2177 = icmp ne i64 %cv2176, 0
  br i1 %cond2177, label %bb_rcglast526, label %bb_rcgdec526
bb_rcglast526:
  %v2178 = load i64, ptr %slot377, align 8
  %op2179 = sub i64 %v2178, 32
  store i64 %op2179, ptr %slot387, align 8
  %v2180 = load i64, ptr %slot377, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %rgep2182 = getelementptr i8, ptr %p2181, i64 -32
  %ld2183 = load i64, ptr %rgep2182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2183, ptr %slot388, align 8
  %v2184 = load i64, ptr %slot388, align 8
  %cmp2185 = icmp ne i64 %v2184, 0
  %cv2186 = zext i1 %cmp2185 to i32
  store i32 %cv2186, ptr %slot389, align 8
  %v2187 = load i32, ptr %slot389, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcgdec526, label %bb_rcgslow526
bb_rcgslow526:
  %v2190 = load i64, ptr %slot376, align 8
  %v2191 = load i64, ptr %slot373, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2190, i64 %v2191) nomerge, !dbg !138
  br label %bb_rcgdone526
bb_rcgdec526:
  %v2192 = load i64, ptr %slot385, align 8
  %v2193 = load i64, ptr %slot377, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %rgep2195 = getelementptr i8, ptr %p2194, i64 -24
  store i64 %v2192, ptr %rgep2195, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear526
bb_rcgclear526:
  %v2196 = load i64, ptr %slot373, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i64 0, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone526
bb_rcgdone526:
  br label %bb_rcslotdone510
bb_rcslotowner510:
  %v2198 = load i64, ptr %slot48, align 8
  store i64 %v2198, ptr %slot390, align 8
  %v2199 = load i64, ptr %slot373, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot391, align 8
  %v2202 = load i64, ptr %slot391, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot392, align 8
  %v2205 = load i32, ptr %slot392, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcgnn541, label %bb_rcgdone541
bb_rcgnn541:
  %v2208 = load i64, ptr %slot391, align 8
  %op2209 = sub i64 %v2208, 16
  store i64 %op2209, ptr %slot393, align 8
  %v2210 = load i64, ptr %slot391, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -16
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot394, align 8
  %v2214 = load i64, ptr %slot394, align 8
  %op2215 = and i64 %v2214, 4611686018427387906
  store i64 %op2215, ptr %slot395, align 8
  %v2216 = load i64, ptr %slot395, align 8
  %cmp2217 = icmp ne i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot396, align 8
  %v2219 = load i32, ptr %slot396, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcgclear541, label %bb_rcgcounted541
bb_rcgcounted541:
  %v2222 = load i64, ptr %slot391, align 8
  %op2223 = sub i64 %v2222, 32
  store i64 %op2223, ptr %slot397, align 8
  %v2224 = load i64, ptr %slot391, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %rgep2226 = getelementptr i8, ptr %p2225, i64 -32
  %ld2227 = load i64, ptr %rgep2226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2227, ptr %slot398, align 8
  %v2228 = load i64, ptr %slot398, align 8
  %op2229 = sub i64 %v2228, 1
  store i64 %op2229, ptr %slot399, align 8
  %v2230 = load i64, ptr %slot399, align 8
  %cmp2231 = icmp eq i64 %v2230, 0
  %cv2232 = zext i1 %cmp2231 to i32
  store i32 %cv2232, ptr %slot400, align 8
  %v2233 = load i32, ptr %slot400, align 8
  %cv2234 = zext i32 %v2233 to i64
  %cond2235 = icmp ne i64 %cv2234, 0
  br i1 %cond2235, label %bb_rcglast541, label %bb_rcgdec541
bb_rcglast541:
  %v2236 = load i64, ptr %slot391, align 8
  %op2237 = sub i64 %v2236, 24
  store i64 %op2237, ptr %slot401, align 8
  %v2238 = load i64, ptr %slot391, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %rgep2240 = getelementptr i8, ptr %p2239, i64 -24
  %ld2241 = load i64, ptr %rgep2240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2241, ptr %slot402, align 8
  %v2242 = load i64, ptr %slot402, align 8
  %cmp2243 = icmp ne i64 %v2242, 0
  %cv2244 = zext i1 %cmp2243 to i32
  store i32 %cv2244, ptr %slot403, align 8
  %v2245 = load i32, ptr %slot403, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcgdec541, label %bb_rcgslow541
bb_rcgslow541:
  %v2248 = load i64, ptr %slot390, align 8
  %v2249 = load i64, ptr %slot373, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2248, i64 %v2249) nomerge, !dbg !138
  br label %bb_rcgdone541
bb_rcgdec541:
  %v2250 = load i64, ptr %slot399, align 8
  %v2251 = load i64, ptr %slot391, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %rgep2253 = getelementptr i8, ptr %p2252, i64 -32
  store i64 %v2250, ptr %rgep2253, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear541
bb_rcgclear541:
  %v2254 = load i64, ptr %slot373, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 0, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone541
bb_rcgdone541:
  br label %bb_rcslotdone510
bb_rcslotdone510:
  %v2256 = load i64, ptr %slot20, align 8
  store i64 %v2256, ptr %slot404, align 8
  %v2257 = load i64, ptr %slot24, align 8
  store i64 %v2257, ptr %slot405, align 8
  %v2258 = load i64, ptr %slot405, align 8
  %v2259 = load i64, ptr %slot404, align 8
  %p2260 = inttoptr i64 %v2258 to ptr
  %p2261 = inttoptr i64 %v2259 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2261, ptr %p2260, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot14, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i32 2, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot18, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %ld2266 = load i32, ptr %p2265, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2266, ptr %slot406, align 8
  %v2267 = load i32, ptr %slot406, align 8
  %v2268 = load i64, ptr %slot14, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  store i32 %v2267, ptr %p2269, align 4, !alias.scope !3, !noalias !4
  %v2270 = load i64, ptr %slot17, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  store i32 0, ptr %p2271, align 4, !alias.scope !3, !noalias !4
  %v2272 = load i64, ptr %slot13, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  store i32 1, ptr %p2273, align 4, !alias.scope !3, !noalias !4
  %v2274 = load i64, ptr %slot404, align 8
  %v2275 = load i64, ptr %slot33, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i64 %v2274, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot39, align 8
  store i64 %v2277, ptr %slot407, align 8
  %v2278 = load i64, ptr %slot407, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  store i64 0, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  %v2280 = load i64, ptr %slot407, align 8
  %p2282 = inttoptr i64 %v2280 to ptr
  %gep2283 = getelementptr i8, ptr %p2282, i64 8
  %op2281 = ptrtoint ptr %gep2283 to i64
  store i64 %op2281, ptr %slot408, align 8
  %v2284 = load i64, ptr %slot408, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i64 0, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot407, align 8
  %p2288 = inttoptr i64 %v2286 to ptr
  %gep2289 = getelementptr i8, ptr %p2288, i64 16
  %op2287 = ptrtoint ptr %gep2289 to i64
  store i64 %op2287, ptr %slot409, align 8
  %v2290 = load i64, ptr %slot409, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  store i64 0, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  %v2292 = load i64, ptr %slot407, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i32 1, ptr %p2293, align 4, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot19, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i32 1, ptr %p2295, align 4, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot33, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i64, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2298, ptr %slot410, align 8
  %v2299 = load i64, ptr %slot407, align 8
  %p2301 = inttoptr i64 %v2299 to ptr
  %gep2302 = getelementptr i8, ptr %p2301, i64 8
  %op2300 = ptrtoint ptr %gep2302 to i64
  store i64 %op2300, ptr %slot411, align 8
  %v2303 = load i64, ptr %slot49, align 8
  store i64 %v2303, ptr %slot412, align 8
  %v2304 = load i64, ptr %slot33, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  %ld2306 = load i64, ptr %p2305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2306, ptr %slot413, align 8
  %v2307 = load i64, ptr %slot13, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %ld2309 = load i32, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2309, ptr %slot414, align 8
  %v2310 = load i64, ptr %slot14, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %ld2312 = load i32, ptr %p2311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2312, ptr %slot415, align 8
  %v2313 = load i32, ptr %slot415, align 8
  %op2314 = and i32 %v2313, 24
  store i32 %op2314, ptr %slot415, align 8
  %v2315 = load i32, ptr %slot415, align 8
  %cmp2316 = icmp eq i32 %v2315, 0
  %cv2317 = zext i1 %cmp2316 to i32
  store i32 %cv2317, ptr %slot416, align 8
  %v2318 = load i32, ptr %slot414, align 8
  %v2319 = load i32, ptr %slot416, align 8
  %op2320 = and i32 %v2318, %v2319
  store i32 %op2320, ptr %slot417, align 8
  %v2321 = load i32, ptr %slot417, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rctake562, label %bb_rccopy562
bb_rctake562:
  %v2324 = load i64, ptr %slot24, align 8
  store i64 %v2324, ptr %slot418, align 8
  %v2325 = load i64, ptr %slot49, align 8
  store i64 %v2325, ptr %slot419, align 8
  %v2326 = load i64, ptr %slot413, align 8
  %v2327 = load i64, ptr %slot418, align 8
  %op2328 = sub i64 %v2326, %v2327
  store i64 %op2328, ptr %slot420, align 8
  %v2329 = load i64, ptr %slot418, align 8
  %v2330 = load i64, ptr %slot413, align 8
  %op2331 = sub i64 %v2329, %v2330
  store i64 %op2331, ptr %slot421, align 8
  %v2332 = load i64, ptr %slot420, align 8
  %cmp2333 = icmp ult i64 %v2332, 16
  %cv2334 = zext i1 %cmp2333 to i32
  store i32 %cv2334, ptr %slot422, align 8
  %v2335 = load i64, ptr %slot421, align 8
  %cmp2336 = icmp ult i64 %v2335, 16
  %cv2337 = zext i1 %cmp2336 to i32
  store i32 %cv2337, ptr %slot423, align 8
  %v2338 = load i32, ptr %slot422, align 8
  %v2339 = load i32, ptr %slot423, align 8
  %op2340 = or i32 %v2338, %v2339
  store i32 %op2340, ptr %slot424, align 8
  %v2341 = load i32, ptr %slot424, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcmoveslow571, label %bb_rcmovecheck571
bb_rcmovecheck571:
  %v2344 = load i64, ptr %slot413, align 8
  %op2345 = add i64 %v2344, 0
  store i64 %op2345, ptr %slot425, align 8
  %v2346 = load i64, ptr %slot425, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %ld2348 = load i64, ptr %p2347, align 8
  store i64 %ld2348, ptr %slot426, align 8
  %v2349 = load i64, ptr %slot426, align 8
  %cmp2350 = icmp ne i64 %v2349, 0
  %cv2351 = zext i1 %cmp2350 to i32
  store i32 %cv2351, ptr %slot427, align 8
  %v2352 = load i32, ptr %slot427, align 8
  %cv2353 = zext i32 %v2352 to i64
  %cond2354 = icmp ne i64 %cv2353, 0
  br i1 %cond2354, label %bb_rcmoveheader579, label %bb_rcmovenext579
bb_rcmoveheader579:
  %v2355 = load i64, ptr %slot426, align 8
  %op2356 = sub i64 %v2355, 16
  store i64 %op2356, ptr %slot428, align 8
  %v2357 = load i64, ptr %slot426, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %rgep2359 = getelementptr i8, ptr %p2358, i64 -16
  %ld2360 = load i64, ptr %rgep2359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2360, ptr %slot429, align 8
  %v2361 = load i64, ptr %slot429, align 8
  %op2362 = and i64 %v2361, 5764607523034234881
  store i64 %op2362, ptr %slot430, align 8
  %v2363 = load i64, ptr %slot430, align 8
  %cmp2364 = icmp ne i64 %v2363, 0
  %cv2365 = zext i1 %cmp2364 to i32
  store i32 %cv2365, ptr %slot431, align 8
  %v2366 = load i32, ptr %slot431, align 8
  %cv2367 = zext i32 %v2366 to i64
  %cond2368 = icmp ne i64 %cv2367, 0
  br i1 %cond2368, label %bb_rcmoveslow571, label %bb_rcmovenext579
bb_rcmovenext579:
  %v2369 = load i64, ptr %slot413, align 8
  %v2370 = load i64, ptr %slot418, align 8
  %p2371 = inttoptr i64 %v2369 to ptr
  %p2372 = inttoptr i64 %v2370 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2372, ptr %p2371, i64 16, i1 false)
  %v2373 = load i64, ptr %slot413, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  store i64 0, ptr %p2374, align 8
  %v2375 = load i64, ptr %slot413, align 8
  %op2376 = add i64 %v2375, 8
  store i64 %op2376, ptr %slot432, align 8
  %v2377 = load i64, ptr %slot432, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i64 0, ptr %p2378, align 8
  br label %bb_rcmoved571
bb_rcmoveslow571:
  %v2379 = load i64, ptr %slot48, align 8
  %v2380 = load i64, ptr %slot418, align 8
  %v2381 = load i64, ptr %slot413, align 8
  %v2382 = load i64, ptr %slot419, align 8
  %cv2383 = trunc i64 %v2382 to i32
  %call2384 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v2379, i64 %v2380, i64 %v2381, i32 %cv2383) nomerge, !dbg !140
  store i32 %call2384, ptr %slot433, align 8
  %v2385 = load i32, ptr %slot433, align 8
  %cv2386 = zext i32 %v2385 to i64
  %cond2387 = icmp ne i64 %cv2386, 0
  br i1 %cond2387, label %bb_rcsuccess587, label %bb_rcfailure587
bb_rcfailure587:
  %v2388 = load i64, ptr %slot48, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  %call2390 = call i32 @myl_rc_take_failure(ptr %p2389) nomerge, !dbg !140
  store i32 %call2390, ptr %slot434, align 8
  %v2391 = load i64, ptr %slot1, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  %v2393 = load i32, ptr %slot434, align 8
  %call2394 = call i32 @myl_qbe_rc_status(ptr %p2392, i32 %v2393) nomerge, !dbg !140
  store i32 %call2394, ptr %slot435, align 8
  br label %bb_failure
bb_rcsuccess587:
  br label %bb_rcmoved571
bb_rcmoved571:
  %v2395 = load i64, ptr %slot13, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  store i32 0, ptr %p2396, align 4, !alias.scope !3, !noalias !4
  %v2397 = load i64, ptr %slot18, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i32 2, ptr %p2398, align 4, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot17, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  store i32 1, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared562
bb_rccopy562:
  %v2401 = load i64, ptr %slot24, align 8
  store i64 %v2401, ptr %slot436, align 8
  %v2402 = load i64, ptr %slot49, align 8
  store i64 %v2402, ptr %slot437, align 8
  %v2403 = load i64, ptr %slot48, align 8
  %v2404 = load i64, ptr %slot436, align 8
  %v2405 = load i64, ptr %slot413, align 8
  %v2406 = load i64, ptr %slot437, align 8
  %cv2407 = trunc i64 %v2406 to i32
  %call2408 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2403, i64 %v2404, i64 %v2405, i32 %cv2407) nomerge, !dbg !140
  store i32 %call2408, ptr %slot438, align 8
  %v2409 = load i32, ptr %slot438, align 8
  %cv2410 = zext i32 %v2409 to i64
  %cond2411 = icmp ne i64 %cv2410, 0
  br i1 %cond2411, label %bb_rcsuccess596, label %bb_rcfailure596
bb_rcfailure596:
  %v2412 = load i64, ptr %slot48, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %call2414 = call i32 @myl_rc_take_failure(ptr %p2413) nomerge, !dbg !140
  store i32 %call2414, ptr %slot439, align 8
  %v2415 = load i64, ptr %slot1, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %v2417 = load i32, ptr %slot439, align 8
  %call2418 = call i32 @myl_qbe_rc_status(ptr %p2416, i32 %v2417) nomerge, !dbg !140
  store i32 %call2418, ptr %slot440, align 8
  br label %bb_failure
bb_rcsuccess596:
  %v2419 = load i64, ptr %slot18, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i32 2, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  %v2421 = load i64, ptr %slot17, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i32 1, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  %v2423 = load i64, ptr %slot13, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %ld2425 = load i32, ptr %p2424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2425, ptr %slot441, align 8
  %v2426 = load i32, ptr %slot441, align 8
  %cv2427 = zext i32 %v2426 to i64
  %cond2428 = icmp ne i64 %cv2427, 0
  br i1 %cond2428, label %bb_rcslotdrop603, label %bb_rcslotdone603
bb_rcslotdrop603:
  %v2429 = load i64, ptr %slot13, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  store i32 0, ptr %p2430, align 4, !alias.scope !3, !noalias !4
  %v2431 = load i64, ptr %slot20, align 8
  store i64 %v2431, ptr %slot442, align 8
  %v2432 = load i64, ptr %slot14, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  %ld2434 = load i32, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2434, ptr %slot443, align 8
  %v2435 = load i32, ptr %slot443, align 8
  %op2436 = and i32 %v2435, 28
  store i32 %op2436, ptr %slot444, align 8
  %v2437 = load i32, ptr %slot444, align 8
  %cv2438 = zext i32 %v2437 to i64
  %cond2439 = icmp ne i64 %cv2438, 0
  br i1 %cond2439, label %bb_rcslotrole603, label %bb_rcslotowner603
bb_rcslotrole603:
  %v2440 = load i64, ptr %slot48, align 8
  store i64 %v2440, ptr %slot445, align 8
  %v2441 = load i64, ptr %slot445, align 8
  %v2442 = load i64, ptr %slot442, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v2441, i64 %v2442) nomerge, !dbg !140
  br label %bb_rcslotdone603
bb_rcslotowner603:
  %v2443 = load i64, ptr %slot48, align 8
  store i64 %v2443, ptr %slot446, align 8
  %v2444 = load i64, ptr %slot446, align 8
  %v2445 = load i64, ptr %slot442, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v2444, i64 %v2445) nomerge, !dbg !140
  br label %bb_rcslotdone603
bb_rcslotdone603:
  br label %bb_rcprepared562
bb_rcprepared562:
  %v2446 = load i64, ptr %slot24, align 8
  store i64 %v2446, ptr %slot447, align 8
  %v2447 = load i64, ptr %slot447, align 8
  %v2448 = load i64, ptr %slot411, align 8
  %p2449 = inttoptr i64 %v2447 to ptr
  %p2450 = inttoptr i64 %v2448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2450, ptr %p2449, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot17, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  store i32 0, ptr %p2452, align 4, !alias.scope !3, !noalias !4
  %v2453 = load i64, ptr %slot407, align 8
  %v2454 = load i64, ptr %slot33, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i64 %v2453, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  %p2456 = inttoptr i64 ptrtoint (ptr @myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p2456, i64 48) "call-inline-cost"="0", !dbg !140
  %v2457 = load i64, ptr %slot33, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i64, ptr %p2458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2459, ptr %slot448, align 8
  %v2460 = load i64, ptr %slot20, align 8
  store i64 %v2460, ptr %slot449, align 8
  %v2461 = load i64, ptr %slot448, align 8
  %v2462 = load i64, ptr %slot449, align 8
  %p2463 = inttoptr i64 %v2461 to ptr
  %p2464 = inttoptr i64 %v2462 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2464, ptr %p2463, i64 24, i1 false)
  %v2465 = load i64, ptr %slot14, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i32 2, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot13, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  store i32 1, ptr %p2468, align 4, !alias.scope !3, !noalias !4
  %v2469 = load i64, ptr %slot449, align 8
  %v2470 = load i64, ptr %slot33, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  store i64 %v2469, ptr %p2471, align 8, !alias.scope !3, !noalias !4
  %v2472 = load i64, ptr %slot33, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  %ld2474 = load i64, ptr %p2473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2474, ptr %slot450, align 8
  %v2475 = load i64, ptr %slot33, align 8
  %p2476 = inttoptr i64 %v2475 to ptr
  %ld2477 = load i64, ptr %p2476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2477, ptr %slot451, align 8
  %v2478 = load i64, ptr %slot24, align 8
  store i64 %v2478, ptr %slot452, align 8
  %v2479 = load i64, ptr %slot49, align 8
  store i64 %v2479, ptr %slot453, align 8
  %v2480 = load i64, ptr %slot48, align 8
  %v2481 = load i64, ptr %slot452, align 8
  %v2482 = load i64, ptr %slot451, align 8
  %v2483 = load i64, ptr %slot453, align 8
  %cv2484 = trunc i64 %v2483 to i32
  %call2485 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2480, i64 %v2481, i64 %v2482, i32 %cv2484) nomerge, !dbg !142
  store i32 %call2485, ptr %slot454, align 8
  %v2486 = load i32, ptr %slot454, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcsuccess621, label %bb_rcfailure621
bb_rcfailure621:
  %v2489 = load i64, ptr %slot48, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %call2491 = call i32 @myl_rc_take_failure(ptr %p2490) nomerge, !dbg !142
  store i32 %call2491, ptr %slot455, align 8
  %v2492 = load i64, ptr %slot1, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %v2494 = load i32, ptr %slot455, align 8
  %call2495 = call i32 @myl_qbe_rc_status(ptr %p2493, i32 %v2494) nomerge, !dbg !142
  store i32 %call2495, ptr %slot456, align 8
  br label %bb_failure
bb_rcsuccess621:
  %v2496 = load i64, ptr %slot13, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 0, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot18, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  store i32 2, ptr %p2499, align 4, !alias.scope !3, !noalias !4
  %v2500 = load i64, ptr %slot17, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  store i32 1, ptr %p2501, align 4, !alias.scope !3, !noalias !4
  %v2502 = load i64, ptr %slot24, align 8
  store i64 %v2502, ptr %slot457, align 8
  %v2503 = load i64, ptr %slot17, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i32 0, ptr %p2504, align 4, !alias.scope !3, !noalias !4
  %v2505 = load i64, ptr %slot13, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %ld2507 = load i32, ptr %p2506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2507, ptr %slot458, align 8
  %v2508 = load i32, ptr %slot458, align 8
  %cv2509 = zext i32 %v2508 to i64
  %cond2510 = icmp ne i64 %cv2509, 0
  br i1 %cond2510, label %bb_rcslotdrop631, label %bb_rcslotdone631
bb_rcslotdrop631:
  %v2511 = load i64, ptr %slot13, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  store i32 0, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  %v2513 = load i64, ptr %slot20, align 8
  store i64 %v2513, ptr %slot459, align 8
  %v2514 = load i64, ptr %slot14, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %ld2516 = load i32, ptr %p2515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2516, ptr %slot460, align 8
  %v2517 = load i32, ptr %slot460, align 8
  %op2518 = and i32 %v2517, 28
  store i32 %op2518, ptr %slot461, align 8
  %v2519 = load i32, ptr %slot461, align 8
  %cv2520 = zext i32 %v2519 to i64
  %cond2521 = icmp ne i64 %cv2520, 0
  br i1 %cond2521, label %bb_rcslotrole631, label %bb_rcslotowner631
bb_rcslotrole631:
  %v2522 = load i64, ptr %slot48, align 8
  store i64 %v2522, ptr %slot462, align 8
  %v2523 = load i64, ptr %slot462, align 8
  %v2524 = load i64, ptr %slot459, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2523, i64 %v2524) nomerge, !dbg !142
  br label %bb_rcslotdone631
bb_rcslotowner631:
  %v2525 = load i64, ptr %slot48, align 8
  store i64 %v2525, ptr %slot463, align 8
  %v2526 = load i64, ptr %slot463, align 8
  %v2527 = load i64, ptr %slot459, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2526, i64 %v2527) nomerge, !dbg !142
  br label %bb_rcslotdone631
bb_rcslotdone631:
  %v2528 = load i64, ptr %slot11, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %ld2530 = load i32, ptr %p2529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2530, ptr %slot464, align 8
  %v2531 = load i32, ptr %slot464, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rcslotdrop658, label %bb_rcslotdone658
bb_rcslotdrop658:
  %v2534 = load i64, ptr %slot11, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  store i32 0, ptr %p2535, align 4, !alias.scope !3, !noalias !4
  %v2536 = load i64, ptr %slot32, align 8
  store i64 %v2536, ptr %slot465, align 8
  %v2537 = load i64, ptr %slot12, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %ld2539 = load i32, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2539, ptr %slot466, align 8
  %v2540 = load i32, ptr %slot466, align 8
  %op2541 = and i32 %v2540, 28
  store i32 %op2541, ptr %slot467, align 8
  %v2542 = load i32, ptr %slot467, align 8
  %cv2543 = zext i32 %v2542 to i64
  %cond2544 = icmp ne i64 %cv2543, 0
  br i1 %cond2544, label %bb_rcslotrole658, label %bb_rcslotowner658
bb_rcslotrole658:
  %v2545 = load i64, ptr %slot48, align 8
  store i64 %v2545, ptr %slot468, align 8
  %v2546 = load i64, ptr %slot468, align 8
  %v2547 = load i64, ptr %slot465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2546, i64 %v2547) nomerge, !dbg !142
  br label %bb_rcslotdone658
bb_rcslotowner658:
  %v2548 = load i64, ptr %slot48, align 8
  store i64 %v2548, ptr %slot469, align 8
  %v2549 = load i64, ptr %slot469, align 8
  %v2550 = load i64, ptr %slot465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2549, i64 %v2550) nomerge, !dbg !142
  br label %bb_rcslotdone658
bb_rcslotdone658:
  %v2551 = load i64, ptr %slot9, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i32, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2553, ptr %slot470, align 8
  %v2554 = load i32, ptr %slot470, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcslotdrop685, label %bb_rcslotdone685
bb_rcslotdrop685:
  %v2557 = load i64, ptr %slot9, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  store i32 0, ptr %p2558, align 4, !alias.scope !3, !noalias !4
  %v2559 = load i64, ptr %slot31, align 8
  store i64 %v2559, ptr %slot471, align 8
  %v2560 = load i64, ptr %slot10, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot472, align 8
  %v2563 = load i32, ptr %slot472, align 8
  %op2564 = and i32 %v2563, 28
  store i32 %op2564, ptr %slot473, align 8
  %v2565 = load i32, ptr %slot473, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcslotrole685, label %bb_rcslotowner685
bb_rcslotrole685:
  %v2568 = load i64, ptr %slot48, align 8
  store i64 %v2568, ptr %slot474, align 8
  %v2569 = load i64, ptr %slot474, align 8
  %v2570 = load i64, ptr %slot471, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2569, i64 %v2570) nomerge, !dbg !142
  br label %bb_rcslotdone685
bb_rcslotowner685:
  %v2571 = load i64, ptr %slot48, align 8
  store i64 %v2571, ptr %slot475, align 8
  %v2572 = load i64, ptr %slot475, align 8
  %v2573 = load i64, ptr %slot471, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2572, i64 %v2573) nomerge, !dbg !142
  br label %bb_rcslotdone685
bb_rcslotdone685:
  %v2574 = load i64, ptr %slot457, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2575, i64 24, i1 false)
  ret void
bb_i50:
  %v2576 = load i64, ptr %slot25, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i64, ptr %p2577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2578, ptr %slot476, align 8
  %v2579 = load i64, ptr %slot476, align 8
  %v2580 = load i64, ptr %slot40, align 8
  %p2581 = inttoptr i64 %v2579 to ptr
  %p2582 = inttoptr i64 %v2580 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2582, ptr %p2581, i64 304, i1 false), !alias.scope !10000000
  %v2583 = load i64, ptr %slot40, align 8
  %v2584 = load i64, ptr %slot33, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  store i64 %v2583, ptr %p2585, align 8, !alias.scope !3, !noalias !4
  %v2586 = load i64, ptr %slot33, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  %ld2588 = load i64, ptr %p2587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2588, ptr %slot477, align 8
  %v2589 = load i64, ptr %slot477, align 8
  %op2590 = add i64 %v2589, 32
  store i64 %op2590, ptr %slot478, align 8
  %v2591 = load i64, ptr %slot478, align 8
  %v2592 = load i64, ptr %slot33, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  store i64 %v2591, ptr %p2593, align 8, !alias.scope !3, !noalias !4
  %v2594 = load i64, ptr %slot11, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %ld2596 = load i32, ptr %p2595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2596, ptr %slot479, align 8
  %v2597 = load i32, ptr %slot479, align 8
  %cv2598 = zext i32 %v2597 to i64
  %cond2599 = icmp ne i64 %cv2598, 0
  br i1 %cond2599, label %bb_rcslotdrop706, label %bb_rcslotdone706
bb_rcslotdrop706:
  %v2600 = load i64, ptr %slot11, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  store i32 0, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot32, align 8
  store i64 %v2602, ptr %slot480, align 8
  %v2603 = load i64, ptr %slot12, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %ld2605 = load i32, ptr %p2604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2605, ptr %slot481, align 8
  %v2606 = load i32, ptr %slot481, align 8
  %op2607 = and i32 %v2606, 28
  store i32 %op2607, ptr %slot482, align 8
  %v2608 = load i32, ptr %slot482, align 8
  %cv2609 = zext i32 %v2608 to i64
  %cond2610 = icmp ne i64 %cv2609, 0
  br i1 %cond2610, label %bb_rcslotrole706, label %bb_rcslotowner706
bb_rcslotrole706:
  %v2611 = load i64, ptr %slot48, align 8
  store i64 %v2611, ptr %slot483, align 8
  %v2612 = load i64, ptr %slot483, align 8
  %v2613 = load i64, ptr %slot480, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2612, i64 %v2613) nomerge, !dbg !144
  br label %bb_rcslotdone706
bb_rcslotowner706:
  %v2614 = load i64, ptr %slot48, align 8
  store i64 %v2614, ptr %slot484, align 8
  %v2615 = load i64, ptr %slot484, align 8
  %v2616 = load i64, ptr %slot480, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2615, i64 %v2616) nomerge, !dbg !144
  br label %bb_rcslotdone706
bb_rcslotdone706:
  %v2617 = load i64, ptr %slot25, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2619, ptr %slot485, align 8
  %v2620 = load i64, ptr %slot485, align 8
  %op2621 = add i64 %v2620, 32
  store i64 %op2621, ptr %slot486, align 8
  %v2622 = load i64, ptr %slot32, align 8
  store i64 %v2622, ptr %slot487, align 8
  %v2623 = load i64, ptr %slot486, align 8
  %v2624 = load i64, ptr %slot487, align 8
  %p2625 = inttoptr i64 %v2623 to ptr
  %p2626 = inttoptr i64 %v2624 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2626, ptr %p2625, i64 208, i1 false), !alias.scope !10000000
  %v2627 = load i64, ptr %slot486, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  call void @llvm.memset.p0.i64(ptr %p2628, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !144
  %v2629 = load i64, ptr %slot11, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i32 1, ptr %p2630, align 4, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot32, align 8
  %v2632 = load i64, ptr %slot33, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i64 %v2631, ptr %p2633, align 8, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot32, align 8
  %v2635 = load i64, ptr %slot41, align 8
  %p2636 = inttoptr i64 %v2634 to ptr
  %p2637 = inttoptr i64 %v2635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2637, ptr %p2636, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v2638 = load i64, ptr %slot41, align 8
  %v2639 = load i64, ptr %slot34, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i64 %v2638, ptr %p2640, align 8, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot32, align 8
  %v2642 = load i64, ptr %slot42, align 8
  %p2643 = inttoptr i64 %v2641 to ptr
  %p2644 = inttoptr i64 %v2642 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2644, ptr %p2643, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot42, align 8
  %v2646 = load i64, ptr %slot35, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i64 %v2645, ptr %p2647, align 8, !alias.scope !3, !noalias !4
  %v2648 = load i64, ptr %slot27, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %ld2650 = load i64, ptr %p2649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2650, ptr %slot488, align 8
  %v2651 = load i64, ptr %slot488, align 8
  %v2652 = load i64, ptr %slot36, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i64 %v2651, ptr %p2653, align 8, !alias.scope !3, !noalias !4
  %v2654 = load i64, ptr %slot35, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %ld2656 = load i64, ptr %p2655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2656, ptr %slot489, align 8
  %v2657 = load i64, ptr %slot36, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  %ld2659 = load i64, ptr %p2658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2659, ptr %slot490, align 8
  %v2660 = load i64, ptr %slot1, align 8
  %v2661 = load i64, ptr %slot489, align 8
  %v2662 = load i64, ptr %slot490, align 8
  %call2663 = call i64 @myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268(i64 %v2660, i64 %v2661, i64 %v2662) nomerge, !dbg !146
  store i64 %call2663, ptr %slot491, align 8
  %v2664 = load i64, ptr %slot491, align 8
  %v2665 = load i64, ptr %slot35, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i64 %v2664, ptr %p2666, align 8, !alias.scope !3, !noalias !4
  %v2667 = load i64, ptr %slot28, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %ld2669 = load i64, ptr %p2668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2669, ptr %slot492, align 8
  %v2670 = load i64, ptr %slot492, align 8
  %v2671 = load i64, ptr %slot36, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  store i64 %v2670, ptr %p2672, align 8, !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot34, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  %ld2675 = load i64, ptr %p2674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2675, ptr %slot493, align 8
  %v2676 = load i64, ptr %slot35, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  %ld2678 = load i64, ptr %p2677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2678, ptr %slot494, align 8
  %v2679 = load i64, ptr %slot36, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %ld2681 = load i64, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2681, ptr %slot495, align 8
  %v2682 = load i64, ptr %slot1, align 8
  %v2683 = load i64, ptr %slot493, align 8
  %v2684 = load i64, ptr %slot494, align 8
  %v2685 = load i64, ptr %slot495, align 8
  %call2686 = call { i64, i64 } @myl_f_bef718364832da2350b7af6609e1fbb47c868e0b051a6562c056e76ae3623412(i64 %v2682, i64 %v2683, i64 %v2684, i64 %v2685) nomerge, !dbg !148
  store { i64, i64 } %call2686, ptr %callresult497, align 8
  %addr2687 = ptrtoint ptr %callresult497 to i64
  store i64 %addr2687, ptr %slot496, align 8
  %v2688 = load i64, ptr %slot496, align 8
  %v2689 = load i64, ptr %slot34, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 %v2688, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  %v2691 = load i64, ptr %slot15, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %ld2693 = load i32, ptr %p2692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2693, ptr %slot498, align 8
  %v2694 = load i32, ptr %slot498, align 8
  %cv2695 = zext i32 %v2694 to i64
  %cond2696 = icmp ne i64 %cv2695, 0
  br i1 %cond2696, label %bb_rcslotdrop737, label %bb_rcslotdone737
bb_rcslotdrop737:
  %v2697 = load i64, ptr %slot15, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  store i32 0, ptr %p2698, align 4, !alias.scope !3, !noalias !4
  %v2699 = load i64, ptr %slot21, align 8
  store i64 %v2699, ptr %slot499, align 8
  %v2700 = load i64, ptr %slot16, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  %ld2702 = load i32, ptr %p2701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2702, ptr %slot500, align 8
  %v2703 = load i32, ptr %slot500, align 8
  %op2704 = and i32 %v2703, 28
  store i32 %op2704, ptr %slot501, align 8
  %v2705 = load i32, ptr %slot501, align 8
  %cv2706 = zext i32 %v2705 to i64
  %cond2707 = icmp ne i64 %cv2706, 0
  br i1 %cond2707, label %bb_rcslotrole737, label %bb_rcslotowner737
bb_rcslotrole737:
  %v2708 = load i64, ptr %slot48, align 8
  store i64 %v2708, ptr %slot502, align 8
  %v2709 = load i64, ptr %slot502, align 8
  %v2710 = load i64, ptr %slot499, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2709, i64 %v2710) nomerge, !dbg !148
  br label %bb_rcslotdone737
bb_rcslotowner737:
  %v2711 = load i64, ptr %slot48, align 8
  store i64 %v2711, ptr %slot503, align 8
  %v2712 = load i64, ptr %slot503, align 8
  %v2713 = load i64, ptr %slot499, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2712, i64 %v2713) nomerge, !dbg !148
  br label %bb_rcslotdone737
bb_rcslotdone737:
  %v2714 = load i64, ptr %slot33, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  %ld2716 = load i64, ptr %p2715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2716, ptr %slot504, align 8
  %v2717 = load i64, ptr %slot34, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %ld2719 = load i64, ptr %p2718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2719, ptr %slot505, align 8
  %v2720 = load i64, ptr %slot1, align 8
  %v2721 = load i64, ptr %slot504, align 8
  %v2722 = load i64, ptr %slot505, align 8
  %call2723 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v2720, i64 %v2721, i64 %v2722) nomerge, !dbg !150
  store i64 %call2723, ptr %slot506, align 8
  %v2724 = load i64, ptr %slot506, align 8
  %v2725 = load i64, ptr %slot33, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i64 %v2724, ptr %p2726, align 8, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot13, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i32, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2729, ptr %slot507, align 8
  %v2730 = load i32, ptr %slot507, align 8
  %cv2731 = zext i32 %v2730 to i64
  %cond2732 = icmp ne i64 %cv2731, 0
  br i1 %cond2732, label %bb_rcslotdrop749, label %bb_rcslotdone749
bb_rcslotdrop749:
  %v2733 = load i64, ptr %slot13, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i32 0, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot20, align 8
  store i64 %v2735, ptr %slot508, align 8
  %v2736 = load i64, ptr %slot14, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  %ld2738 = load i32, ptr %p2737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2738, ptr %slot509, align 8
  %v2739 = load i32, ptr %slot509, align 8
  %op2740 = and i32 %v2739, 28
  store i32 %op2740, ptr %slot510, align 8
  %v2741 = load i32, ptr %slot510, align 8
  %cv2742 = zext i32 %v2741 to i64
  %cond2743 = icmp ne i64 %cv2742, 0
  br i1 %cond2743, label %bb_rcslotrole749, label %bb_rcslotowner749
bb_rcslotrole749:
  %v2744 = load i64, ptr %slot48, align 8
  store i64 %v2744, ptr %slot511, align 8
  %v2745 = load i64, ptr %slot511, align 8
  %v2746 = load i64, ptr %slot508, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2745, i64 %v2746) nomerge, !dbg !150
  br label %bb_rcslotdone749
bb_rcslotowner749:
  %v2747 = load i64, ptr %slot48, align 8
  store i64 %v2747, ptr %slot512, align 8
  %v2748 = load i64, ptr %slot512, align 8
  %v2749 = load i64, ptr %slot508, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2748, i64 %v2749) nomerge, !dbg !150
  br label %bb_rcslotdone749
bb_rcslotdone749:
  %v2750 = load i64, ptr %slot25, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  %ld2752 = load i64, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2752, ptr %slot513, align 8
  %v2753 = load i64, ptr %slot513, align 8
  %op2754 = add i64 %v2753, 32
  store i64 %op2754, ptr %slot514, align 8
  %v2755 = load i64, ptr %slot32, align 8
  store i64 %v2755, ptr %slot515, align 8
  %v2756 = load i64, ptr %slot515, align 8
  %v2757 = load i64, ptr %slot514, align 8
  %p2758 = inttoptr i64 %v2756 to ptr
  %p2759 = inttoptr i64 %v2757 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2759, ptr %p2758, i64 208, i1 false), !alias.scope !10000000
  %v2760 = load i64, ptr %slot515, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  call void @llvm.memset.p0.i64(ptr %p2761, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !152
  %v2762 = load i64, ptr %slot11, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  store i32 0, ptr %p2763, align 4, !alias.scope !3, !noalias !4
  %v2764 = load i64, ptr %slot33, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  store i64 0, ptr %p2765, align 8, !alias.scope !3, !noalias !4
  %v2766 = load i64, ptr %slot33, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  store i64 0, ptr %p2767, align 8, !alias.scope !3, !noalias !4
  %v2768 = load i64, ptr %slot43, align 8
  store i64 %v2768, ptr %slot516, align 8
  %v2769 = load i64, ptr %slot516, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  store i64 0, ptr %p2770, align 8, !alias.scope !3, !noalias !4
  %v2771 = load i64, ptr %slot516, align 8
  %p2773 = inttoptr i64 %v2771 to ptr
  %gep2774 = getelementptr i8, ptr %p2773, i64 8
  %op2772 = ptrtoint ptr %gep2774 to i64
  store i64 %op2772, ptr %slot517, align 8
  %v2775 = load i64, ptr %slot517, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i64 0, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot516, align 8
  %p2779 = inttoptr i64 %v2777 to ptr
  %gep2780 = getelementptr i8, ptr %p2779, i64 16
  %op2778 = ptrtoint ptr %gep2780 to i64
  store i64 %op2778, ptr %slot518, align 8
  %v2781 = load i64, ptr %slot518, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i64 0, ptr %p2782, align 8, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot516, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 0, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot19, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  store i32 1, ptr %p2786, align 4, !alias.scope !3, !noalias !4
  %v2787 = load i64, ptr %slot33, align 8
  store i64 %v2787, ptr %slot519, align 8
  %v2788 = load i64, ptr %slot516, align 8
  %p2790 = inttoptr i64 %v2788 to ptr
  %gep2791 = getelementptr i8, ptr %p2790, i64 8
  %op2789 = ptrtoint ptr %gep2791 to i64
  store i64 %op2789, ptr %slot520, align 8
  %v2792 = load i64, ptr %slot49, align 8
  store i64 %v2792, ptr %slot521, align 8
  store i64 0, ptr %slot522, align 8
  %v2793 = load i64, ptr %slot516, align 8
  %v2794 = load i64, ptr %slot33, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  store i64 %v2793, ptr %p2795, align 8, !alias.scope !3, !noalias !4
  %v2796 = load i64, ptr %slot33, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %ld2798 = load i64, ptr %p2797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2798, ptr %slot523, align 8
  %v2799 = load i64, ptr %slot20, align 8
  store i64 %v2799, ptr %slot524, align 8
  %v2800 = load i64, ptr %slot523, align 8
  %v2801 = load i64, ptr %slot524, align 8
  %p2802 = inttoptr i64 %v2800 to ptr
  %p2803 = inttoptr i64 %v2801 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2803, ptr %p2802, i64 24, i1 false)
  %v2804 = load i64, ptr %slot14, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i32 2, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot13, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 1, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot524, align 8
  %v2809 = load i64, ptr %slot33, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  store i64 %v2808, ptr %p2810, align 8, !alias.scope !3, !noalias !4
  %v2811 = load i64, ptr %slot33, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %ld2813 = load i64, ptr %p2812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2813, ptr %slot525, align 8
  %v2814 = load i64, ptr %slot33, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i64, ptr %p2815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2816, ptr %slot526, align 8
  %v2817 = load i64, ptr %slot24, align 8
  store i64 %v2817, ptr %slot527, align 8
  %v2818 = load i64, ptr %slot49, align 8
  store i64 %v2818, ptr %slot528, align 8
  %v2819 = load i64, ptr %slot48, align 8
  %v2820 = load i64, ptr %slot527, align 8
  %v2821 = load i64, ptr %slot526, align 8
  %v2822 = load i64, ptr %slot528, align 8
  %cv2823 = trunc i64 %v2822 to i32
  %call2824 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2819, i64 %v2820, i64 %v2821, i32 %cv2823) nomerge, !dbg !154
  store i32 %call2824, ptr %slot529, align 8
  %v2825 = load i32, ptr %slot529, align 8
  %cv2826 = zext i32 %v2825 to i64
  %cond2827 = icmp ne i64 %cv2826, 0
  br i1 %cond2827, label %bb_rcsuccess778, label %bb_rcfailure778
bb_rcfailure778:
  %v2828 = load i64, ptr %slot48, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  %call2830 = call i32 @myl_rc_take_failure(ptr %p2829) nomerge, !dbg !154
  store i32 %call2830, ptr %slot530, align 8
  %v2831 = load i64, ptr %slot1, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  %v2833 = load i32, ptr %slot530, align 8
  %call2834 = call i32 @myl_qbe_rc_status(ptr %p2832, i32 %v2833) nomerge, !dbg !154
  store i32 %call2834, ptr %slot531, align 8
  br label %bb_failure
bb_rcsuccess778:
  %v2835 = load i64, ptr %slot13, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i32 0, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  %v2837 = load i64, ptr %slot18, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  store i32 2, ptr %p2838, align 4, !alias.scope !3, !noalias !4
  %v2839 = load i64, ptr %slot17, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 1, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot24, align 8
  store i64 %v2841, ptr %slot532, align 8
  %v2842 = load i64, ptr %slot17, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  store i32 0, ptr %p2843, align 4, !alias.scope !3, !noalias !4
  %v2844 = load i64, ptr %slot13, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %ld2846 = load i32, ptr %p2845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2846, ptr %slot533, align 8
  %v2847 = load i32, ptr %slot533, align 8
  %cv2848 = zext i32 %v2847 to i64
  %cond2849 = icmp ne i64 %cv2848, 0
  br i1 %cond2849, label %bb_rcslotdrop788, label %bb_rcslotdone788
bb_rcslotdrop788:
  %v2850 = load i64, ptr %slot13, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  store i32 0, ptr %p2851, align 4, !alias.scope !3, !noalias !4
  %v2852 = load i64, ptr %slot20, align 8
  store i64 %v2852, ptr %slot534, align 8
  %v2853 = load i64, ptr %slot14, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  %ld2855 = load i32, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2855, ptr %slot535, align 8
  %v2856 = load i32, ptr %slot535, align 8
  %op2857 = and i32 %v2856, 28
  store i32 %op2857, ptr %slot536, align 8
  %v2858 = load i32, ptr %slot536, align 8
  %cv2859 = zext i32 %v2858 to i64
  %cond2860 = icmp ne i64 %cv2859, 0
  br i1 %cond2860, label %bb_rcslotrole788, label %bb_rcslotowner788
bb_rcslotrole788:
  %v2861 = load i64, ptr %slot48, align 8
  store i64 %v2861, ptr %slot537, align 8
  %v2862 = load i64, ptr %slot537, align 8
  %v2863 = load i64, ptr %slot534, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2862, i64 %v2863) nomerge, !dbg !154
  br label %bb_rcslotdone788
bb_rcslotowner788:
  %v2864 = load i64, ptr %slot48, align 8
  store i64 %v2864, ptr %slot538, align 8
  %v2865 = load i64, ptr %slot538, align 8
  %v2866 = load i64, ptr %slot534, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2865, i64 %v2866) nomerge, !dbg !154
  br label %bb_rcslotdone788
bb_rcslotdone788:
  %v2867 = load i64, ptr %slot11, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %ld2869 = load i32, ptr %p2868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2869, ptr %slot539, align 8
  %v2870 = load i32, ptr %slot539, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcslotdrop815, label %bb_rcslotdone815
bb_rcslotdrop815:
  %v2873 = load i64, ptr %slot11, align 8
  %p2874 = inttoptr i64 %v2873 to ptr
  store i32 0, ptr %p2874, align 4, !alias.scope !3, !noalias !4
  %v2875 = load i64, ptr %slot32, align 8
  store i64 %v2875, ptr %slot540, align 8
  %v2876 = load i64, ptr %slot12, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %ld2878 = load i32, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2878, ptr %slot541, align 8
  %v2879 = load i32, ptr %slot541, align 8
  %op2880 = and i32 %v2879, 28
  store i32 %op2880, ptr %slot542, align 8
  %v2881 = load i32, ptr %slot542, align 8
  %cv2882 = zext i32 %v2881 to i64
  %cond2883 = icmp ne i64 %cv2882, 0
  br i1 %cond2883, label %bb_rcslotrole815, label %bb_rcslotowner815
bb_rcslotrole815:
  %v2884 = load i64, ptr %slot48, align 8
  store i64 %v2884, ptr %slot543, align 8
  %v2885 = load i64, ptr %slot543, align 8
  %v2886 = load i64, ptr %slot540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2885, i64 %v2886) nomerge, !dbg !154
  br label %bb_rcslotdone815
bb_rcslotowner815:
  %v2887 = load i64, ptr %slot48, align 8
  store i64 %v2887, ptr %slot544, align 8
  %v2888 = load i64, ptr %slot544, align 8
  %v2889 = load i64, ptr %slot540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2888, i64 %v2889) nomerge, !dbg !154
  br label %bb_rcslotdone815
bb_rcslotdone815:
  %v2890 = load i64, ptr %slot9, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %ld2892 = load i32, ptr %p2891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2892, ptr %slot545, align 8
  %v2893 = load i32, ptr %slot545, align 8
  %cv2894 = zext i32 %v2893 to i64
  %cond2895 = icmp ne i64 %cv2894, 0
  br i1 %cond2895, label %bb_rcslotdrop842, label %bb_rcslotdone842
bb_rcslotdrop842:
  %v2896 = load i64, ptr %slot9, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  store i32 0, ptr %p2897, align 4, !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot31, align 8
  store i64 %v2898, ptr %slot546, align 8
  %v2899 = load i64, ptr %slot10, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %ld2901 = load i32, ptr %p2900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2901, ptr %slot547, align 8
  %v2902 = load i32, ptr %slot547, align 8
  %op2903 = and i32 %v2902, 28
  store i32 %op2903, ptr %slot548, align 8
  %v2904 = load i32, ptr %slot548, align 8
  %cv2905 = zext i32 %v2904 to i64
  %cond2906 = icmp ne i64 %cv2905, 0
  br i1 %cond2906, label %bb_rcslotrole842, label %bb_rcslotowner842
bb_rcslotrole842:
  %v2907 = load i64, ptr %slot48, align 8
  store i64 %v2907, ptr %slot549, align 8
  %v2908 = load i64, ptr %slot549, align 8
  %v2909 = load i64, ptr %slot546, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2908, i64 %v2909) nomerge, !dbg !154
  br label %bb_rcslotdone842
bb_rcslotowner842:
  %v2910 = load i64, ptr %slot48, align 8
  store i64 %v2910, ptr %slot550, align 8
  %v2911 = load i64, ptr %slot550, align 8
  %v2912 = load i64, ptr %slot546, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2911, i64 %v2912) nomerge, !dbg !154
  br label %bb_rcslotdone842
bb_rcslotdone842:
  %v2913 = load i64, ptr %slot532, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2914, i64 24, i1 false)
  ret void
bb_failure:
  %v2915 = load i64, ptr %slot8, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  call void @llvm.memset.p0.i64(ptr %p2916, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v2917 = load i64, ptr %slot8, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2918, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v2919 = load i64, ptr %slot8, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  call void @llvm.memset.p0.i64(ptr %p2920, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !154
  %v2921 = load i64, ptr %slot8, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2922, i64 24, i1 false)
  ret void
}

@myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0_meta = external global i8, align 8
@myl_lit_8d47278f5246a959c9cf373236b198659ae1c259b6afd12cadab3d657868cf2b = external global i8, align 8
@myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare i64 @myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b_rc_borrow(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare { i64, i64 } @myl_f_bef718364832da2350b7af6609e1fbb47c868e0b051a6562c056e76ae3623412(i64, i64, i64, i64)
declare i64 @myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268(i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0", linkageName: "myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1861126292428417145, i64 0, !"myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!120 = !DILocation(line: 13, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!122 = !DILocation(line: 16, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!126 = !DILocation(line: 33, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!128 = !DILocation(line: 38, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!130 = !DILocation(line: 41, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!132 = !DILocation(line: 43, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!134 = !DILocation(line: 44, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!136 = !DILocation(line: 46, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!138 = !DILocation(line: 48, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!140 = !DILocation(line: 49, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!142 = !DILocation(line: 50, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!144 = !DILocation(line: 52, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!146 = !DILocation(line: 59, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!148 = !DILocation(line: 61, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!150 = !DILocation(line: 62, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!152 = !DILocation(line: 74, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!154 = !DILocation(line: 79, column: 0, scope: !155)
