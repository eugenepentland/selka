target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %callresult37 = alloca [16 x i8], align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %callresult61 = alloca [48 x i8], align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v144 = load i64, ptr %slot1, align 8
  %op145 = add i64 %v144, 32
  store i64 %op145, ptr %slot4, align 8
  %mem146 = alloca i8, i64 8, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot5, align 8
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot6, align 8
  %mem150 = alloca i8, i64 8, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot7, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot8, align 8
  %mem154 = alloca i8, i64 8, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot9, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot10, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot11, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot12, align 8
  %mem162 = alloca i8, i64 208, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot13, align 8
  %mem164 = alloca i8, i64 208, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot14, align 8
  %mem166 = alloca i8, i64 208, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot15, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot16, align 8
  %mem170 = alloca i8, i64 208, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot17, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot18, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot19, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot20, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot21, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot22, align 8
  %mem182 = alloca i8, i64 8, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot23, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem184 = alloca i8, i64 8, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot24, align 8
  %v186 = load i64, ptr %slot1, align 8
  %op187 = add i64 %v186, 64
  store i64 %op187, ptr %slot25, align 8
  %v188 = load i64, ptr %slot25, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !4, !noalias !3
  store i64 %ld190, ptr %slot26, align 8
  %stack191 = call ptr @llvm.stacksave()
  %stackaddr192 = ptrtoint ptr %stack191 to i64
  %v193 = load i64, ptr %slot26, align 8
  %cmp194 = icmp ult i64 %stackaddr192, %v193
  %cv195 = zext i1 %cmp194 to i64
  store i64 %cv195, ptr %slot27, align 8
  %v196 = load i64, ptr %slot27, align 8
  %cond197 = icmp ne i64 %v196, 0
  br i1 %cond197, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v198 = load i64, ptr %slot1, align 8
  %p199 = inttoptr i64 %v198 to ptr
  call void @myl_qbe_fail_frame(ptr %p199) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v200 = load i64, ptr %slot2, align 8
  %v201 = load i64, ptr %slot18, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot3, align 8
  %v204 = load i64, ptr %slot19, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot1, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %call208 = call ptr @myl_qbe_heap(ptr %p207) nomerge, !dbg !112
  %calladdr209 = ptrtoint ptr %call208 to i64
  store i64 %calladdr209, ptr %slot28, align 8
  %v210 = load i64, ptr %slot1, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %call212 = call i64 @myl_qbe_region_mark(ptr %p211) nomerge, !dbg !112
  store i64 %call212, ptr %slot29, align 8
  %v213 = load i64, ptr %slot5, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i32 0, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot6, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 0, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot7, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i32 0, ptr %p218, align 4, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot8, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 0, ptr %p220, align 4, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot9, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i32 0, ptr %p222, align 4, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot10, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i32 0, ptr %p224, align 4, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot11, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i32 0, ptr %p226, align 4, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot12, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i32 0, ptr %p228, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v229 = load i64, ptr %slot18, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %ld231 = load i64, ptr %p230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld231, ptr %slot30, align 8
  %v232 = load i64, ptr %slot30, align 8
  %v233 = load i64, ptr %slot20, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i64 %v232, ptr %p234, align 8, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot18, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld237, ptr %slot31, align 8
  %v238 = load i64, ptr %slot31, align 8
  %v239 = load i64, ptr %slot21, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i64 %v238, ptr %p240, align 8, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot18, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot32, align 8
  %v244 = load i64, ptr %slot32, align 8
  %v245 = load i64, ptr %slot22, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i64 %v244, ptr %p246, align 8, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot19, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot33, align 8
  %v250 = load i64, ptr %slot33, align 8
  %v251 = load i64, ptr %slot23, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot22, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot34, align 8
  %v256 = load i64, ptr %slot23, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot35, align 8
  %v259 = load i64, ptr %slot1, align 8
  %v260 = load i64, ptr %slot34, align 8
  %v261 = load i64, ptr %slot35, align 8
  %call262 = call { i64, i64 } @myl_f_e438901bb103caf01d35d4490198d05e4e7cae9318795e3ba1543b9452700b5d(i64 %v259, i64 %v260, i64 %v261) nomerge, !dbg !114
  store { i64, i64 } %call262, ptr %callresult37, align 8
  %addr263 = ptrtoint ptr %callresult37 to i64
  store i64 %addr263, ptr %slot36, align 8
  %v264 = load i64, ptr %slot36, align 8
  %v265 = load i64, ptr %slot22, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot22, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld269, ptr %slot38, align 8
  %v270 = load i64, ptr %slot17, align 8
  store i64 %v270, ptr %slot39, align 8
  %v271 = load i64, ptr %slot38, align 8
  %v272 = load i64, ptr %slot39, align 8
  %p273 = inttoptr i64 %v271 to ptr
  %p274 = inttoptr i64 %v272 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p274, ptr %p273, i64 16, i1 false)
  %v275 = load i64, ptr %slot12, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i32 2, ptr %p276, align 4, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot11, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i32 1, ptr %p278, align 4, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot9, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i32, ptr %p280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld281, ptr %slot40, align 8
  %v282 = load i32, ptr %slot40, align 8
  %cv283 = zext i32 %v282 to i64
  %cond284 = icmp ne i64 %cv283, 0
  br i1 %cond284, label %bb_rcslotdrop21, label %bb_rcslotdone21
bb_rcslotdrop21:
  %v285 = load i64, ptr %slot9, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i32 0, ptr %p286, align 4, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot15, align 8
  store i64 %v287, ptr %slot41, align 8
  %v288 = load i64, ptr %slot10, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i32, ptr %p289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld290, ptr %slot42, align 8
  %v291 = load i32, ptr %slot42, align 8
  %op292 = and i32 %v291, 28
  store i32 %op292, ptr %slot43, align 8
  %v293 = load i32, ptr %slot43, align 8
  %cv294 = zext i32 %v293 to i64
  %cond295 = icmp ne i64 %cv294, 0
  br i1 %cond295, label %bb_rcslotrole21, label %bb_rcslotowner21
bb_rcslotrole21:
  %v296 = load i64, ptr %slot28, align 8
  store i64 %v296, ptr %slot44, align 8
  %v297 = load i64, ptr %slot44, align 8
  %v298 = load i64, ptr %slot41, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v297, i64 %v298) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotowner21:
  %v299 = load i64, ptr %slot28, align 8
  store i64 %v299, ptr %slot45, align 8
  %v300 = load i64, ptr %slot45, align 8
  %v301 = load i64, ptr %slot41, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v300, i64 %v301) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotdone21:
  %v302 = load i64, ptr %slot15, align 8
  store i64 %v302, ptr %slot46, align 8
  %v303 = load i64, ptr %slot17, align 8
  store i64 %v303, ptr %slot47, align 8
  %v304 = load i64, ptr %slot47, align 8
  %v305 = load i64, ptr %slot46, align 8
  %p306 = inttoptr i64 %v304 to ptr
  %p307 = inttoptr i64 %v305 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p307, ptr %p306, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot10, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i32 2, ptr %p309, align 4, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot12, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i32, ptr %p311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld312, ptr %slot48, align 8
  %v313 = load i32, ptr %slot48, align 8
  %v314 = load i64, ptr %slot10, align 8
  %p315 = inttoptr i64 %v314 to ptr
  store i32 %v313, ptr %p315, align 4, !alias.scope !3, !noalias !4
  %v316 = load i64, ptr %slot11, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i32 0, ptr %p317, align 4, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot9, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i32 1, ptr %p319, align 4, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot46, align 8
  %v321 = load i64, ptr %slot22, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot22, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot49, align 8
  %v326 = load i64, ptr %slot49, align 8
  %op327 = add i64 %v326, 0
  store i64 %op327, ptr %slot50, align 8
  %v328 = load i64, ptr %slot50, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot51, align 8
  %v331 = load i64, ptr %slot51, align 8
  %v332 = load i64, ptr %slot22, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot9, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i32, ptr %p335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld336, ptr %slot52, align 8
  %v337 = load i32, ptr %slot52, align 8
  %cv338 = zext i32 %v337 to i64
  %cond339 = icmp ne i64 %cv338, 0
  br i1 %cond339, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v340 = load i64, ptr %slot9, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i32 0, ptr %p341, align 4, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot15, align 8
  store i64 %v342, ptr %slot53, align 8
  %v343 = load i64, ptr %slot10, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %ld345 = load i32, ptr %p344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld345, ptr %slot54, align 8
  %v346 = load i32, ptr %slot54, align 8
  %op347 = and i32 %v346, 28
  store i32 %op347, ptr %slot55, align 8
  %v348 = load i32, ptr %slot55, align 8
  %cv349 = zext i32 %v348 to i64
  %cond350 = icmp ne i64 %cv349, 0
  br i1 %cond350, label %bb_rcslotrole41, label %bb_rcslotowner41
bb_rcslotrole41:
  %v351 = load i64, ptr %slot28, align 8
  store i64 %v351, ptr %slot56, align 8
  %v352 = load i64, ptr %slot56, align 8
  %v353 = load i64, ptr %slot53, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v352, i64 %v353) nomerge, !dbg !116
  br label %bb_rcslotdone41
bb_rcslotowner41:
  %v354 = load i64, ptr %slot28, align 8
  store i64 %v354, ptr %slot57, align 8
  %v355 = load i64, ptr %slot57, align 8
  %v356 = load i64, ptr %slot53, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v355, i64 %v356) nomerge, !dbg !116
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v357 = load i64, ptr %slot21, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot58, align 8
  %v360 = load i64, ptr %slot22, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld362, ptr %slot59, align 8
  %v363 = load i64, ptr %slot1, align 8
  %v364 = load i64, ptr %slot58, align 8
  %v365 = load i64, ptr %slot59, align 8
  call void @myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208(ptr sret([48 x i8]) align 8 %callresult61, i64 %v363, i64 %v364, i64 %v365) nomerge, !dbg !118
  %addr366 = ptrtoint ptr %callresult61 to i64
  store i64 %addr366, ptr %slot60, align 8
  %v367 = load i64, ptr %slot60, align 8
  %v368 = load i64, ptr %slot21, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 %v367, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot21, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot62, align 8
  %v373 = load i64, ptr %slot17, align 8
  store i64 %v373, ptr %slot63, align 8
  %v374 = load i64, ptr %slot62, align 8
  %v375 = load i64, ptr %slot63, align 8
  %p376 = inttoptr i64 %v374 to ptr
  %p377 = inttoptr i64 %v375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p377, ptr %p376, i64 48, i1 false)
  %v378 = load i64, ptr %slot12, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i32 2, ptr %p379, align 4, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot11, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i32 1, ptr %p381, align 4, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot7, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i32, ptr %p383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld384, ptr %slot64, align 8
  %v385 = load i32, ptr %slot64, align 8
  %cv386 = zext i32 %v385 to i64
  %cond387 = icmp ne i64 %cv386, 0
  br i1 %cond387, label %bb_rcslotdrop57, label %bb_rcslotdone57
bb_rcslotdrop57:
  %v388 = load i64, ptr %slot7, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i32 0, ptr %p389, align 4, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot14, align 8
  store i64 %v390, ptr %slot65, align 8
  %v391 = load i64, ptr %slot8, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i32, ptr %p392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld393, ptr %slot66, align 8
  %v394 = load i32, ptr %slot66, align 8
  %op395 = and i32 %v394, 28
  store i32 %op395, ptr %slot67, align 8
  %v396 = load i32, ptr %slot67, align 8
  %cv397 = zext i32 %v396 to i64
  %cond398 = icmp ne i64 %cv397, 0
  br i1 %cond398, label %bb_rcslotrole57, label %bb_rcslotowner57
bb_rcslotrole57:
  %v399 = load i64, ptr %slot28, align 8
  store i64 %v399, ptr %slot68, align 8
  %v400 = load i64, ptr %slot68, align 8
  %v401 = load i64, ptr %slot65, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v400, i64 %v401) nomerge, !dbg !118
  br label %bb_rcslotdone57
bb_rcslotowner57:
  %v402 = load i64, ptr %slot28, align 8
  store i64 %v402, ptr %slot69, align 8
  %v403 = load i64, ptr %slot69, align 8
  %v404 = load i64, ptr %slot65, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v403, i64 %v404) nomerge, !dbg !118
  br label %bb_rcslotdone57
bb_rcslotdone57:
  %v405 = load i64, ptr %slot14, align 8
  store i64 %v405, ptr %slot70, align 8
  %v406 = load i64, ptr %slot17, align 8
  store i64 %v406, ptr %slot71, align 8
  %v407 = load i64, ptr %slot71, align 8
  %v408 = load i64, ptr %slot70, align 8
  %p409 = inttoptr i64 %v407 to ptr
  %p410 = inttoptr i64 %v408 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p410, ptr %p409, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot8, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 2, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot12, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i32, ptr %p414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld415, ptr %slot72, align 8
  %v416 = load i32, ptr %slot72, align 8
  %v417 = load i64, ptr %slot8, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i32 %v416, ptr %p418, align 4, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot11, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i32 0, ptr %p420, align 4, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot7, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i32 1, ptr %p422, align 4, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot70, align 8
  %v424 = load i64, ptr %slot21, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i64 %v423, ptr %p425, align 8, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot20, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot73, align 8
  %v429 = load i64, ptr %slot21, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot74, align 8
  %v432 = load i64, ptr %slot1, align 8
  %v433 = load i64, ptr %slot73, align 8
  %v434 = load i64, ptr %slot74, align 8
  %call435 = call i64 @myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93(i64 %v432, i64 %v433, i64 %v434) nomerge, !dbg !120
  store i64 %call435, ptr %slot75, align 8
  %v436 = load i64, ptr %slot75, align 8
  %v437 = load i64, ptr %slot20, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i64 %v436, ptr %p438, align 8, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot20, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i64, ptr %p440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld441, ptr %slot76, align 8
  %v442 = load i64, ptr %slot76, align 8
  %v443 = load i64, ptr %slot16, align 8
  %p444 = inttoptr i64 %v443 to ptr
  store i64 %v442, ptr %p444, align 8, !alias.scope !3, !noalias !4
  %v445 = load i64, ptr %slot16, align 8
  store i64 %v445, ptr %slot77, align 8
  %v446 = load i64, ptr %slot17, align 8
  store i64 %v446, ptr %slot78, align 8
  %v447 = load i64, ptr %slot77, align 8
  %v448 = load i64, ptr %slot78, align 8
  %p449 = inttoptr i64 %v447 to ptr
  %p450 = inttoptr i64 %v448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p450, ptr %p449, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v451 = load i64, ptr %slot12, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i32 2, ptr %p452, align 4, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot11, align 8
  %p454 = inttoptr i64 %v453 to ptr
  store i32 1, ptr %p454, align 4, !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot5, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i32, ptr %p456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld457, ptr %slot79, align 8
  %v458 = load i32, ptr %slot79, align 8
  %cv459 = zext i32 %v458 to i64
  %cond460 = icmp ne i64 %cv459, 0
  br i1 %cond460, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v461 = load i64, ptr %slot5, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i32 0, ptr %p462, align 4, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot13, align 8
  store i64 %v463, ptr %slot80, align 8
  %v464 = load i64, ptr %slot6, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i32, ptr %p465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld466, ptr %slot81, align 8
  %v467 = load i32, ptr %slot81, align 8
  %op468 = and i32 %v467, 28
  store i32 %op468, ptr %slot82, align 8
  %v469 = load i32, ptr %slot82, align 8
  %cv470 = zext i32 %v469 to i64
  %cond471 = icmp ne i64 %cv470, 0
  br i1 %cond471, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v472 = load i64, ptr %slot28, align 8
  store i64 %v472, ptr %slot83, align 8
  %v473 = load i64, ptr %slot83, align 8
  %v474 = load i64, ptr %slot80, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v473, i64 %v474) nomerge, !dbg !120
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v475 = load i64, ptr %slot28, align 8
  store i64 %v475, ptr %slot84, align 8
  %v476 = load i64, ptr %slot84, align 8
  %v477 = load i64, ptr %slot80, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v476, i64 %v477) nomerge, !dbg !120
  br label %bb_rcslotdone82
bb_rcslotdone82:
  %v478 = load i64, ptr %slot7, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i32, ptr %p479, align 4, !alias.scope !3, !noalias !4
  store i32 %ld480, ptr %slot85, align 8
  %v481 = load i32, ptr %slot85, align 8
  %cv482 = zext i32 %v481 to i64
  %cond483 = icmp ne i64 %cv482, 0
  br i1 %cond483, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v484 = load i64, ptr %slot7, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 0, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot14, align 8
  store i64 %v486, ptr %slot86, align 8
  %v487 = load i64, ptr %slot8, align 8
  %p488 = inttoptr i64 %v487 to ptr
  %ld489 = load i32, ptr %p488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld489, ptr %slot87, align 8
  %v490 = load i32, ptr %slot87, align 8
  %op491 = and i32 %v490, 28
  store i32 %op491, ptr %slot88, align 8
  %v492 = load i32, ptr %slot88, align 8
  %cv493 = zext i32 %v492 to i64
  %cond494 = icmp ne i64 %cv493, 0
  br i1 %cond494, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v495 = load i64, ptr %slot28, align 8
  store i64 %v495, ptr %slot89, align 8
  %v496 = load i64, ptr %slot89, align 8
  %v497 = load i64, ptr %slot86, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v496, i64 %v497) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v498 = load i64, ptr %slot28, align 8
  store i64 %v498, ptr %slot90, align 8
  %v499 = load i64, ptr %slot90, align 8
  %v500 = load i64, ptr %slot86, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v499, i64 %v500) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v501 = load i64, ptr %slot13, align 8
  store i64 %v501, ptr %slot91, align 8
  %v502 = load i64, ptr %slot17, align 8
  store i64 %v502, ptr %slot92, align 8
  %v503 = load i64, ptr %slot92, align 8
  %v504 = load i64, ptr %slot91, align 8
  %p505 = inttoptr i64 %v503 to ptr
  %p506 = inttoptr i64 %v504 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p506, ptr %p505, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v507 = load i64, ptr %slot6, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i32 2, ptr %p508, align 4, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot12, align 8
  %p510 = inttoptr i64 %v509 to ptr
  %ld511 = load i32, ptr %p510, align 4, !alias.scope !3, !noalias !4
  store i32 %ld511, ptr %slot93, align 8
  %v512 = load i32, ptr %slot93, align 8
  %v513 = load i64, ptr %slot6, align 8
  %p514 = inttoptr i64 %v513 to ptr
  store i32 %v512, ptr %p514, align 4, !alias.scope !3, !noalias !4
  %v515 = load i64, ptr %slot11, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i32 0, ptr %p516, align 4, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot5, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i32 1, ptr %p518, align 4, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot91, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i64, ptr %p520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld521, ptr %slot94, align 8
  %v522 = load i64, ptr %slot94, align 8
  %v523 = load i64, ptr %slot20, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i64 %v522, ptr %p524, align 8, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot20, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld527, ptr %slot95, align 8
  %v528 = load i64, ptr %slot20, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot96, align 8
  %v531 = load i64, ptr %slot96, align 8
  %v532 = load i64, ptr %slot16, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 %v531, ptr %p533, align 8, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot16, align 8
  store i64 %v534, ptr %slot97, align 8
  %v535 = load i64, ptr %slot17, align 8
  store i64 %v535, ptr %slot98, align 8
  %v536 = load i64, ptr %slot29, align 8
  store i64 %v536, ptr %slot99, align 8
  %v537 = load i64, ptr %slot97, align 8
  %p539 = inttoptr i64 %v537 to ptr
  %gep540 = getelementptr i8, ptr %p539, i64 0
  %op538 = ptrtoint ptr %gep540 to i64
  store i64 %op538, ptr %slot100, align 8
  %v541 = load i64, ptr %slot100, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot101, align 8
  %v544 = load i64, ptr %slot101, align 8
  %cmp545 = icmp ne i64 %v544, 0
  %cv546 = zext i1 %cmp545 to i32
  store i32 %cv546, ptr %slot102, align 8
  %v547 = load i32, ptr %slot102, align 8
  %cv548 = zext i32 %v547 to i64
  %cond549 = icmp ne i64 %cv548, 0
  br i1 %cond549, label %bb_rcmoveheader115, label %bb_rcmovenext115
bb_rcmoveheader115:
  %v550 = load i64, ptr %slot101, align 8
  %op551 = sub i64 %v550, 16
  store i64 %op551, ptr %slot103, align 8
  %v552 = load i64, ptr %slot101, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %rgep554 = getelementptr i8, ptr %p553, i64 -16
  %ld555 = load i64, ptr %rgep554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld555, ptr %slot104, align 8
  %v556 = load i64, ptr %slot104, align 8
  %op557 = and i64 %v556, 5764607523034234881
  store i64 %op557, ptr %slot105, align 8
  %v558 = load i64, ptr %slot105, align 8
  %cmp559 = icmp ne i64 %v558, 0
  %cv560 = zext i1 %cmp559 to i32
  store i32 %cv560, ptr %slot106, align 8
  %v561 = load i32, ptr %slot106, align 8
  %cv562 = zext i32 %v561 to i64
  %cond563 = icmp ne i64 %cv562, 0
  br i1 %cond563, label %bb_rcmoveslow112, label %bb_rcmovenext115
bb_rcmovenext115:
  %v564 = load i64, ptr %slot97, align 8
  %v565 = load i64, ptr %slot98, align 8
  %p566 = inttoptr i64 %v564 to ptr
  %p567 = inttoptr i64 %v565 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p567, ptr %p566, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot97, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i64 0, ptr %p569, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved112
bb_rcmoveslow112:
  %v570 = load i64, ptr %slot28, align 8
  %v571 = load i64, ptr %slot98, align 8
  %v572 = load i64, ptr %slot97, align 8
  %v573 = load i64, ptr %slot99, align 8
  %cv574 = trunc i64 %v573 to i32
  %call575 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v570, i64 %v571, i64 %v572, i32 %cv574) nomerge, !dbg !122
  store i32 %call575, ptr %slot107, align 8
  %v576 = load i32, ptr %slot107, align 8
  %cv577 = zext i32 %v576 to i64
  %cond578 = icmp ne i64 %cv577, 0
  br i1 %cond578, label %bb_rcsuccess122, label %bb_rcfailure122
bb_rcfailure122:
  %v579 = load i64, ptr %slot28, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %call581 = call i32 @myl_rc_take_failure(ptr %p580) nomerge, !dbg !122
  store i32 %call581, ptr %slot108, align 8
  %v582 = load i64, ptr %slot1, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %v584 = load i32, ptr %slot108, align 8
  %call585 = call i32 @myl_qbe_rc_status(ptr %p583, i32 %v584) nomerge, !dbg !122
  store i32 %call585, ptr %slot109, align 8
  br label %bb_failure
bb_rcsuccess122:
  br label %bb_rcmoved112
bb_rcmoved112:
  %v586 = load i64, ptr %slot5, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i32 0, ptr %p587, align 4, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot12, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 2, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot11, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i32 1, ptr %p591, align 4, !alias.scope !3, !noalias !4
  %v592 = load i64, ptr %slot17, align 8
  store i64 %v592, ptr %slot110, align 8
  %v593 = load i64, ptr %slot110, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %ld595 = load i64, ptr %p594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld595, ptr %slot111, align 8
  %v596 = load i64, ptr %slot11, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 0, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot5, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i32, ptr %p599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld600, ptr %slot112, align 8
  %v601 = load i32, ptr %slot112, align 8
  %cv602 = zext i32 %v601 to i64
  %cond603 = icmp ne i64 %cv602, 0
  br i1 %cond603, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v604 = load i64, ptr %slot5, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot13, align 8
  store i64 %v606, ptr %slot113, align 8
  %v607 = load i64, ptr %slot6, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i32, ptr %p608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld609, ptr %slot114, align 8
  %v610 = load i32, ptr %slot114, align 8
  %op611 = and i32 %v610, 28
  store i32 %op611, ptr %slot115, align 8
  %v612 = load i32, ptr %slot115, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v615 = load i64, ptr %slot28, align 8
  store i64 %v615, ptr %slot116, align 8
  %v616 = load i64, ptr %slot113, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i64, ptr %p617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld618, ptr %slot117, align 8
  %v619 = load i64, ptr %slot117, align 8
  %cmp620 = icmp ne i64 %v619, 0
  %cv621 = zext i1 %cmp620 to i32
  store i32 %cv621, ptr %slot118, align 8
  %v622 = load i32, ptr %slot118, align 8
  %cv623 = zext i32 %v622 to i64
  %cond624 = icmp ne i64 %cv623, 0
  br i1 %cond624, label %bb_rcgnn149, label %bb_rcgdone149
bb_rcgnn149:
  %v625 = load i64, ptr %slot117, align 8
  %op626 = sub i64 %v625, 16
  store i64 %op626, ptr %slot119, align 8
  %v627 = load i64, ptr %slot117, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %rgep629 = getelementptr i8, ptr %p628, i64 -16
  %ld630 = load i64, ptr %rgep629, align 8, !alias.scope !9, !noalias !10
  store i64 %ld630, ptr %slot120, align 8
  %v631 = load i64, ptr %slot120, align 8
  %op632 = and i64 %v631, 4611686018427387906
  store i64 %op632, ptr %slot121, align 8
  %v633 = load i64, ptr %slot121, align 8
  %cmp634 = icmp ne i64 %v633, 0
  %cv635 = zext i1 %cmp634 to i32
  store i32 %cv635, ptr %slot122, align 8
  %v636 = load i32, ptr %slot122, align 8
  %cv637 = zext i32 %v636 to i64
  %cond638 = icmp ne i64 %cv637, 0
  br i1 %cond638, label %bb_rcgclear149, label %bb_rcgcounted149
bb_rcgcounted149:
  %v639 = load i64, ptr %slot117, align 8
  %op640 = sub i64 %v639, 24
  store i64 %op640, ptr %slot123, align 8
  %v641 = load i64, ptr %slot117, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %rgep643 = getelementptr i8, ptr %p642, i64 -24
  %ld644 = load i64, ptr %rgep643, align 8, !alias.scope !9, !noalias !10
  store i64 %ld644, ptr %slot124, align 8
  %v645 = load i64, ptr %slot124, align 8
  %op646 = sub i64 %v645, 1
  store i64 %op646, ptr %slot125, align 8
  %v647 = load i64, ptr %slot125, align 8
  %cmp648 = icmp eq i64 %v647, 0
  %cv649 = zext i1 %cmp648 to i32
  store i32 %cv649, ptr %slot126, align 8
  %v650 = load i32, ptr %slot126, align 8
  %cv651 = zext i32 %v650 to i64
  %cond652 = icmp ne i64 %cv651, 0
  br i1 %cond652, label %bb_rcglast149, label %bb_rcgdec149
bb_rcglast149:
  %v653 = load i64, ptr %slot117, align 8
  %op654 = sub i64 %v653, 32
  store i64 %op654, ptr %slot127, align 8
  %v655 = load i64, ptr %slot117, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %rgep657 = getelementptr i8, ptr %p656, i64 -32
  %ld658 = load i64, ptr %rgep657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld658, ptr %slot128, align 8
  %v659 = load i64, ptr %slot128, align 8
  %cmp660 = icmp ne i64 %v659, 0
  %cv661 = zext i1 %cmp660 to i32
  store i32 %cv661, ptr %slot129, align 8
  %v662 = load i32, ptr %slot129, align 8
  %cv663 = zext i32 %v662 to i64
  %cond664 = icmp ne i64 %cv663, 0
  br i1 %cond664, label %bb_rcgdec149, label %bb_rcgslow149
bb_rcgslow149:
  %v665 = load i64, ptr %slot116, align 8
  %v666 = load i64, ptr %slot113, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v665, i64 %v666) nomerge, !dbg !122
  br label %bb_rcgdone149
bb_rcgdec149:
  %v667 = load i64, ptr %slot125, align 8
  %v668 = load i64, ptr %slot117, align 8
  %p669 = inttoptr i64 %v668 to ptr
  %rgep670 = getelementptr i8, ptr %p669, i64 -24
  store i64 %v667, ptr %rgep670, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear149
bb_rcgclear149:
  %v671 = load i64, ptr %slot113, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i64 0, ptr %p672, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone149
bb_rcgdone149:
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v673 = load i64, ptr %slot28, align 8
  store i64 %v673, ptr %slot130, align 8
  %v674 = load i64, ptr %slot113, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i64, ptr %p675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld676, ptr %slot131, align 8
  %v677 = load i64, ptr %slot131, align 8
  %cmp678 = icmp ne i64 %v677, 0
  %cv679 = zext i1 %cmp678 to i32
  store i32 %cv679, ptr %slot132, align 8
  %v680 = load i32, ptr %slot132, align 8
  %cv681 = zext i32 %v680 to i64
  %cond682 = icmp ne i64 %cv681, 0
  br i1 %cond682, label %bb_rcgnn164, label %bb_rcgdone164
bb_rcgnn164:
  %v683 = load i64, ptr %slot131, align 8
  %op684 = sub i64 %v683, 16
  store i64 %op684, ptr %slot133, align 8
  %v685 = load i64, ptr %slot131, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %rgep687 = getelementptr i8, ptr %p686, i64 -16
  %ld688 = load i64, ptr %rgep687, align 8, !alias.scope !9, !noalias !10
  store i64 %ld688, ptr %slot134, align 8
  %v689 = load i64, ptr %slot134, align 8
  %op690 = and i64 %v689, 4611686018427387906
  store i64 %op690, ptr %slot135, align 8
  %v691 = load i64, ptr %slot135, align 8
  %cmp692 = icmp ne i64 %v691, 0
  %cv693 = zext i1 %cmp692 to i32
  store i32 %cv693, ptr %slot136, align 8
  %v694 = load i32, ptr %slot136, align 8
  %cv695 = zext i32 %v694 to i64
  %cond696 = icmp ne i64 %cv695, 0
  br i1 %cond696, label %bb_rcgclear164, label %bb_rcgcounted164
bb_rcgcounted164:
  %v697 = load i64, ptr %slot131, align 8
  %op698 = sub i64 %v697, 32
  store i64 %op698, ptr %slot137, align 8
  %v699 = load i64, ptr %slot131, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %rgep701 = getelementptr i8, ptr %p700, i64 -32
  %ld702 = load i64, ptr %rgep701, align 8, !alias.scope !9, !noalias !10
  store i64 %ld702, ptr %slot138, align 8
  %v703 = load i64, ptr %slot138, align 8
  %op704 = sub i64 %v703, 1
  store i64 %op704, ptr %slot139, align 8
  %v705 = load i64, ptr %slot139, align 8
  %cmp706 = icmp eq i64 %v705, 0
  %cv707 = zext i1 %cmp706 to i32
  store i32 %cv707, ptr %slot140, align 8
  %v708 = load i32, ptr %slot140, align 8
  %cv709 = zext i32 %v708 to i64
  %cond710 = icmp ne i64 %cv709, 0
  br i1 %cond710, label %bb_rcglast164, label %bb_rcgdec164
bb_rcglast164:
  %v711 = load i64, ptr %slot131, align 8
  %op712 = sub i64 %v711, 24
  store i64 %op712, ptr %slot141, align 8
  %v713 = load i64, ptr %slot131, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %rgep715 = getelementptr i8, ptr %p714, i64 -24
  %ld716 = load i64, ptr %rgep715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld716, ptr %slot142, align 8
  %v717 = load i64, ptr %slot142, align 8
  %cmp718 = icmp ne i64 %v717, 0
  %cv719 = zext i1 %cmp718 to i32
  store i32 %cv719, ptr %slot143, align 8
  %v720 = load i32, ptr %slot143, align 8
  %cv721 = zext i32 %v720 to i64
  %cond722 = icmp ne i64 %cv721, 0
  br i1 %cond722, label %bb_rcgdec164, label %bb_rcgslow164
bb_rcgslow164:
  %v723 = load i64, ptr %slot130, align 8
  %v724 = load i64, ptr %slot113, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v723, i64 %v724) nomerge, !dbg !122
  br label %bb_rcgdone164
bb_rcgdec164:
  %v725 = load i64, ptr %slot139, align 8
  %v726 = load i64, ptr %slot131, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %rgep728 = getelementptr i8, ptr %p727, i64 -32
  store i64 %v725, ptr %rgep728, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear164
bb_rcgclear164:
  %v729 = load i64, ptr %slot113, align 8
  %p730 = inttoptr i64 %v729 to ptr
  store i64 0, ptr %p730, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone164
bb_rcgdone164:
  br label %bb_rcslotdone133
bb_rcslotdone133:
  %v731 = load i64, ptr %slot111, align 8
  ret i64 %v731
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93(i64, i64, i64)
declare void @myl_f_c4abb1ae4e73bd5e9fdcd1fc864b2bf1d581447f6de48fd901ea77c30582c208(ptr sret([48 x i8]) align 8, i64, i64, i64)
declare { i64, i64 } @myl_f_e438901bb103caf01d35d4490198d05e4e7cae9318795e3ba1543b9452700b5d(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686", linkageName: "myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17044679923468577182, i64 0, !"myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
