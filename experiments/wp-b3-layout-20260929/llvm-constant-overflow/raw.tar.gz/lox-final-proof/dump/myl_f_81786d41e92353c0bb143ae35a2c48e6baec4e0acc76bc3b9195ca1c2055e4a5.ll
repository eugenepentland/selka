target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v684 = load i64, ptr %slot1, align 8
  %op685 = add i64 %v684, 32
  store i64 %op685, ptr %slot2, align 8
  %mem686 = alloca i8, i64 8, align 8
  %ptr687 = ptrtoint ptr %mem686 to i64
  store i64 %ptr687, ptr %slot3, align 8
  %mem688 = alloca i8, i64 8, align 8
  %ptr689 = ptrtoint ptr %mem688 to i64
  store i64 %ptr689, ptr %slot4, align 8
  %mem690 = alloca i8, i64 8, align 8
  %ptr691 = ptrtoint ptr %mem690 to i64
  store i64 %ptr691, ptr %slot5, align 8
  %mem692 = alloca i8, i64 8, align 8
  %ptr693 = ptrtoint ptr %mem692 to i64
  store i64 %ptr693, ptr %slot6, align 8
  %mem694 = alloca i8, i64 8, align 8
  %ptr695 = ptrtoint ptr %mem694 to i64
  store i64 %ptr695, ptr %slot7, align 8
  %mem696 = alloca i8, i64 8, align 8
  %ptr697 = ptrtoint ptr %mem696 to i64
  store i64 %ptr697, ptr %slot8, align 8
  %mem698 = alloca i8, i64 8, align 8
  %ptr699 = ptrtoint ptr %mem698 to i64
  store i64 %ptr699, ptr %slot9, align 8
  %mem700 = alloca i8, i64 8, align 8
  %ptr701 = ptrtoint ptr %mem700 to i64
  store i64 %ptr701, ptr %slot10, align 8
  %mem702 = alloca i8, i64 8, align 8
  %ptr703 = ptrtoint ptr %mem702 to i64
  store i64 %ptr703, ptr %slot11, align 8
  %mem704 = alloca i8, i64 8, align 8
  %ptr705 = ptrtoint ptr %mem704 to i64
  store i64 %ptr705, ptr %slot12, align 8
  %mem706 = alloca i8, i64 8, align 8
  %ptr707 = ptrtoint ptr %mem706 to i64
  store i64 %ptr707, ptr %slot13, align 8
  %mem708 = alloca i8, i64 8, align 8
  %ptr709 = ptrtoint ptr %mem708 to i64
  store i64 %ptr709, ptr %slot14, align 8
  %mem710 = alloca i8, i64 8, align 8
  %ptr711 = ptrtoint ptr %mem710 to i64
  store i64 %ptr711, ptr %slot15, align 8
  %mem712 = alloca i8, i64 8, align 8
  %ptr713 = ptrtoint ptr %mem712 to i64
  store i64 %ptr713, ptr %slot16, align 8
  %mem714 = alloca i8, i64 8, align 8
  %ptr715 = ptrtoint ptr %mem714 to i64
  store i64 %ptr715, ptr %slot17, align 8
  %mem716 = alloca i8, i64 8, align 8
  %ptr717 = ptrtoint ptr %mem716 to i64
  store i64 %ptr717, ptr %slot18, align 8
  %mem718 = alloca i8, i64 8, align 8
  %ptr719 = ptrtoint ptr %mem718 to i64
  store i64 %ptr719, ptr %slot19, align 8
  %v720 = load i64, ptr %slot16, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i64 0, ptr %p721, align 8, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot17, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 0, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot18, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i64 0, ptr %p725, align 8, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot1, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %call728 = call ptr @myl_qbe_heap(ptr %p727) nomerge, !dbg !110
  %calladdr729 = ptrtoint ptr %call728 to i64
  store i64 %calladdr729, ptr %slot20, align 8
  %v730 = load i64, ptr %slot1, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %call732 = call i64 @myl_qbe_region_mark(ptr %p731) nomerge, !dbg !110
  store i64 %call732, ptr %slot21, align 8
  %v733 = load i64, ptr %slot3, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i32 0, ptr %p734, align 4, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot4, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i32 0, ptr %p736, align 4, !alias.scope !3, !noalias !4
  %v737 = load i64, ptr %slot5, align 8
  %p738 = inttoptr i64 %v737 to ptr
  store i32 0, ptr %p738, align 4, !alias.scope !3, !noalias !4
  %v739 = load i64, ptr %slot6, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i32 0, ptr %p740, align 4, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot7, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i32 0, ptr %p742, align 4, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot8, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i32 0, ptr %p744, align 4, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot9, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i32 0, ptr %p746, align 4, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot10, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i32 0, ptr %p748, align 4, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot11, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i32 0, ptr %p750, align 4, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot12, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i32 0, ptr %p752, align 4, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot4, align 8
  %p754 = inttoptr i64 %v753 to ptr
  store i32 2, ptr %p754, align 4, !alias.scope !3, !noalias !4
  %v755 = load i64, ptr %slot6, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i32 2, ptr %p756, align 4, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot8, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i32 2, ptr %p758, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v759 = load i64, ptr %slot19, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i64 0, ptr %p760, align 8, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot19, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %ld763 = load i64, ptr %p762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld763, ptr %slot22, align 8
  %v764 = load i64, ptr %slot22, align 8
  %cmp765 = icmp sge i64 %v764, 0
  %cv766 = zext i1 %cmp765 to i64
  store i64 %cv766, ptr %slot23, align 8
  %v767 = load i64, ptr %slot23, align 8
  %cond768 = icmp ne i64 %v767, 0
  br i1 %cond768, label %bb_success5, label %bb_failed5
bb_failed5:
  %v769 = load i64, ptr %slot1, align 8
  %p770 = inttoptr i64 %v769 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p770) nomerge, !dbg !112
  unreachable
bb_success5:
  %v771 = load i64, ptr %slot20, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %p773 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v774 = load i64, ptr %slot22, align 8
  %call775 = call ptr @myl_native_list_new(ptr %p772, ptr %p773, i64 %v774) nomerge, !dbg !112
  %calladdr776 = ptrtoint ptr %call775 to i64
  store i64 %calladdr776, ptr %slot24, align 8
  %v777 = load i64, ptr %slot24, align 8
  %cond778 = icmp ne i64 %v777, 0
  br i1 %cond778, label %bb_success7, label %bb_failed7
bb_failed7:
  %v779 = load i64, ptr %slot1, align 8
  %p780 = inttoptr i64 %v779 to ptr
  call void @myl_qbe_fail_allocation(ptr %p780) nomerge, !dbg !112
  unreachable
bb_success7:
  %v781 = load i64, ptr %slot24, align 8
  %v782 = load i64, ptr %slot19, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i64 %v781, ptr %p783, align 8, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot19, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %ld786 = load i64, ptr %p785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld786, ptr %slot25, align 8
  %v787 = load i64, ptr %slot25, align 8
  %v788 = load i64, ptr %slot14, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i64 %v787, ptr %p789, align 8, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot14, align 8
  store i64 %v790, ptr %slot26, align 8
  %v791 = load i64, ptr %slot15, align 8
  store i64 %v791, ptr %slot27, align 8
  %v792 = load i64, ptr %slot26, align 8
  %v793 = load i64, ptr %slot27, align 8
  %p794 = inttoptr i64 %v792 to ptr
  %p795 = inttoptr i64 %v793 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p795, ptr %p794, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot12, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i32 2, ptr %p797, align 4, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot11, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 1, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot13, align 8
  store i64 %v800, ptr %slot28, align 8
  %v801 = load i64, ptr %slot15, align 8
  store i64 %v801, ptr %slot29, align 8
  %v802 = load i64, ptr %slot29, align 8
  %v803 = load i64, ptr %slot28, align 8
  %p804 = inttoptr i64 %v802 to ptr
  %p805 = inttoptr i64 %v803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p805, ptr %p804, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot10, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 2, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot12, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i32, ptr %p809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld810, ptr %slot30, align 8
  %v811 = load i32, ptr %slot30, align 8
  %v812 = load i64, ptr %slot10, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i32 %v811, ptr %p813, align 4, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot11, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i32 0, ptr %p815, align 4, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot9, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i32 1, ptr %p817, align 4, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot28, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot31, align 8
  %v821 = load i64, ptr %slot31, align 8
  %v822 = load i64, ptr %slot19, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 %v821, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot19, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %ld826 = load i64, ptr %p825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld826, ptr %slot32, align 8
  %v827 = load i64, ptr %slot32, align 8
  %v828 = load i64, ptr %slot14, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot14, align 8
  store i64 %v830, ptr %slot33, align 8
  %v831 = load i64, ptr %slot9, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %ld833 = load i32, ptr %p832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld833, ptr %slot34, align 8
  %v834 = load i64, ptr %slot10, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %ld836 = load i32, ptr %p835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld836, ptr %slot35, align 8
  %v837 = load i32, ptr %slot35, align 8
  %op838 = and i32 %v837, 24
  store i32 %op838, ptr %slot35, align 8
  %v839 = load i32, ptr %slot35, align 8
  %cmp840 = icmp eq i32 %v839, 0
  %cv841 = zext i1 %cmp840 to i32
  store i32 %cv841, ptr %slot36, align 8
  %v842 = load i32, ptr %slot34, align 8
  %v843 = load i32, ptr %slot36, align 8
  %op844 = and i32 %v842, %v843
  store i32 %op844, ptr %slot37, align 8
  %v845 = load i32, ptr %slot37, align 8
  %cv846 = zext i32 %v845 to i64
  %cond847 = icmp ne i64 %cv846, 0
  br i1 %cond847, label %bb_rcprivateown30, label %bb_rcprivateloan30
bb_rcprivateown30:
  %v848 = load i64, ptr %slot15, align 8
  store i64 %v848, ptr %slot38, align 8
  %v849 = load i64, ptr %slot21, align 8
  store i64 %v849, ptr %slot39, align 8
  %v850 = load i64, ptr %slot33, align 8
  %v851 = load i64, ptr %slot38, align 8
  %op852 = sub i64 %v850, %v851
  store i64 %op852, ptr %slot40, align 8
  %v853 = load i64, ptr %slot38, align 8
  %v854 = load i64, ptr %slot33, align 8
  %op855 = sub i64 %v853, %v854
  store i64 %op855, ptr %slot41, align 8
  %v856 = load i64, ptr %slot40, align 8
  %cmp857 = icmp ult i64 %v856, 8
  %cv858 = zext i1 %cmp857 to i32
  store i32 %cv858, ptr %slot42, align 8
  %v859 = load i64, ptr %slot41, align 8
  %cmp860 = icmp ult i64 %v859, 8
  %cv861 = zext i1 %cmp860 to i32
  store i32 %cv861, ptr %slot43, align 8
  %v862 = load i32, ptr %slot42, align 8
  %v863 = load i32, ptr %slot43, align 8
  %op864 = or i32 %v862, %v863
  store i32 %op864, ptr %slot44, align 8
  %v865 = load i32, ptr %slot44, align 8
  %cv866 = zext i32 %v865 to i64
  %cond867 = icmp ne i64 %cv866, 0
  br i1 %cond867, label %bb_rcmoveslow33, label %bb_rcmovecheck33
bb_rcmovecheck33:
  %v868 = load i64, ptr %slot33, align 8
  %p870 = inttoptr i64 %v868 to ptr
  %gep871 = getelementptr i8, ptr %p870, i64 0
  %op869 = ptrtoint ptr %gep871 to i64
  store i64 %op869, ptr %slot45, align 8
  %v872 = load i64, ptr %slot45, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %ld874 = load i64, ptr %p873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld874, ptr %slot46, align 8
  %v875 = load i64, ptr %slot46, align 8
  %cmp876 = icmp ne i64 %v875, 0
  %cv877 = zext i1 %cmp876 to i32
  store i32 %cv877, ptr %slot47, align 8
  %v878 = load i32, ptr %slot47, align 8
  %cv879 = zext i32 %v878 to i64
  %cond880 = icmp ne i64 %cv879, 0
  br i1 %cond880, label %bb_rcmoveheader41, label %bb_rcmovenext41
bb_rcmoveheader41:
  %v881 = load i64, ptr %slot46, align 8
  %op882 = sub i64 %v881, 16
  store i64 %op882, ptr %slot48, align 8
  %v883 = load i64, ptr %slot46, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %rgep885 = getelementptr i8, ptr %p884, i64 -16
  %ld886 = load i64, ptr %rgep885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld886, ptr %slot49, align 8
  %v887 = load i64, ptr %slot49, align 8
  %op888 = and i64 %v887, 5764607523034234881
  store i64 %op888, ptr %slot50, align 8
  %v889 = load i64, ptr %slot50, align 8
  %cmp890 = icmp ne i64 %v889, 0
  %cv891 = zext i1 %cmp890 to i32
  store i32 %cv891, ptr %slot51, align 8
  %v892 = load i32, ptr %slot51, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcmoveslow33, label %bb_rcmovenext41
bb_rcmovenext41:
  %v895 = load i64, ptr %slot33, align 8
  %v896 = load i64, ptr %slot38, align 8
  %p897 = inttoptr i64 %v895 to ptr
  %p898 = inttoptr i64 %v896 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p898, ptr %p897, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v899 = load i64, ptr %slot33, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 0, ptr %p900, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved33
bb_rcmoveslow33:
  %v901 = load i64, ptr %slot20, align 8
  %v902 = load i64, ptr %slot38, align 8
  %v903 = load i64, ptr %slot33, align 8
  %v904 = load i64, ptr %slot39, align 8
  %cv905 = trunc i64 %v904 to i32
  %call906 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v901, i64 %v902, i64 %v903, i32 %cv905) nomerge, !dbg !114
  store i32 %call906, ptr %slot52, align 8
  %v907 = load i32, ptr %slot52, align 8
  %cv908 = zext i32 %v907 to i64
  %cond909 = icmp ne i64 %cv908, 0
  br i1 %cond909, label %bb_rcsuccess48, label %bb_rcfailure48
bb_rcfailure48:
  %v910 = load i64, ptr %slot20, align 8
  %p911 = inttoptr i64 %v910 to ptr
  %call912 = call i32 @myl_rc_take_failure(ptr %p911) nomerge, !dbg !114
  store i32 %call912, ptr %slot53, align 8
  %v913 = load i64, ptr %slot1, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %v915 = load i32, ptr %slot53, align 8
  %call916 = call i32 @myl_qbe_rc_status(ptr %p914, i32 %v915) nomerge, !dbg !114
  store i32 %call916, ptr %slot54, align 8
  br label %bb_failure
bb_rcsuccess48:
  br label %bb_rcmoved33
bb_rcmoved33:
  %v917 = load i64, ptr %slot9, align 8
  %p918 = inttoptr i64 %v917 to ptr
  store i32 0, ptr %p918, align 4, !alias.scope !3, !noalias !4
  %v919 = load i64, ptr %slot12, align 8
  %p920 = inttoptr i64 %v919 to ptr
  store i32 2, ptr %p920, align 4, !alias.scope !3, !noalias !4
  %v921 = load i64, ptr %slot11, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i32 1, ptr %p922, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared30
bb_rcprivateloan30:
  %v923 = load i64, ptr %slot9, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i32, ptr %p924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld925, ptr %slot55, align 8
  %v926 = load i64, ptr %slot10, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot56, align 8
  %v929 = load i32, ptr %slot56, align 8
  %cmp930 = icmp eq i32 %v929, 16
  %cv931 = zext i1 %cmp930 to i32
  store i32 %cv931, ptr %slot57, align 8
  %v932 = load i32, ptr %slot57, align 8
  %v933 = load i32, ptr %slot55, align 8
  %op934 = and i32 %v932, %v933
  store i32 %op934, ptr %slot57, align 8
  %v935 = load i32, ptr %slot57, align 8
  %cv936 = zext i32 %v935 to i64
  %cond937 = icmp ne i64 %cv936, 0
  br i1 %cond937, label %bb_rcprivatemove30, label %bb_rcprivatenew30
bb_rcprivatemove30:
  %v938 = load i64, ptr %slot15, align 8
  store i64 %v938, ptr %slot58, align 8
  %v939 = load i64, ptr %slot33, align 8
  %v940 = load i64, ptr %slot58, align 8
  %p941 = inttoptr i64 %v939 to ptr
  %p942 = inttoptr i64 %v940 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p942, ptr %p941, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot33, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i64 0, ptr %p944, align 8, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot12, align 8
  %p946 = inttoptr i64 %v945 to ptr
  store i32 2, ptr %p946, align 4, !alias.scope !3, !noalias !4
  %v947 = load i64, ptr %slot12, align 8
  %p948 = inttoptr i64 %v947 to ptr
  store i32 16, ptr %p948, align 4, !alias.scope !3, !noalias !4
  %v949 = load i64, ptr %slot11, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i32 1, ptr %p950, align 4, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot9, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i32 0, ptr %p952, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared30
bb_rcprivatenew30:
  %v953 = load i64, ptr %slot15, align 8
  store i64 %v953, ptr %slot59, align 8
  %v954 = load i64, ptr %slot33, align 8
  %p955 = inttoptr i64 %v954 to ptr
  %ld956 = load i64, ptr %p955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld956, ptr %slot60, align 8
  %v957 = load i64, ptr %slot60, align 8
  %cmp958 = icmp ne i64 %v957, 0
  %cv959 = zext i1 %cmp958 to i32
  store i32 %cv959, ptr %slot61, align 8
  %v960 = load i32, ptr %slot61, align 8
  %cv961 = zext i32 %v960 to i64
  %cond962 = icmp ne i64 %cv961, 0
  br i1 %cond962, label %bb_rcgnn66, label %bb_rcgstore66
bb_rcgnn66:
  %v963 = load i64, ptr %slot60, align 8
  %op964 = sub i64 %v963, 16
  store i64 %op964, ptr %slot62, align 8
  %v965 = load i64, ptr %slot60, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %rgep967 = getelementptr i8, ptr %p966, i64 -16
  %ld968 = load i64, ptr %rgep967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld968, ptr %slot63, align 8
  %v969 = load i64, ptr %slot63, align 8
  %op970 = and i64 %v969, 4611686018427387906
  store i64 %op970, ptr %slot64, align 8
  %v971 = load i64, ptr %slot64, align 8
  %cmp972 = icmp ne i64 %v971, 0
  %cv973 = zext i1 %cmp972 to i32
  store i32 %cv973, ptr %slot65, align 8
  %v974 = load i32, ptr %slot65, align 8
  %cv975 = zext i32 %v974 to i64
  %cond976 = icmp ne i64 %cv975, 0
  br i1 %cond976, label %bb_rcgstore66, label %bb_rcginc66
bb_rcginc66:
  %v977 = load i64, ptr %slot60, align 8
  %op978 = sub i64 %v977, 24
  store i64 %op978, ptr %slot66, align 8
  %v979 = load i64, ptr %slot60, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %rgep981 = getelementptr i8, ptr %p980, i64 -24
  %ld982 = load i64, ptr %rgep981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld982, ptr %slot67, align 8
  %v983 = load i64, ptr %slot67, align 8
  %op984 = add i64 %v983, 1
  store i64 %op984, ptr %slot68, align 8
  %v985 = load i64, ptr %slot68, align 8
  %cmp986 = icmp eq i64 %v985, 0
  %cv987 = zext i1 %cmp986 to i32
  store i32 %cv987, ptr %slot69, align 8
  %v988 = load i32, ptr %slot69, align 8
  %cv989 = zext i32 %v988 to i64
  %cond990 = icmp ne i64 %cv989, 0
  br i1 %cond990, label %bb_rcglimit66, label %bb_rcgcapacity66
bb_rcglimit66:
  %v991 = load i64, ptr %slot1, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %call993 = call i32 @myl_qbe_rc_status(ptr %p992, i32 2) nomerge, !dbg !114
  store i32 %call993, ptr %slot70, align 8
  br label %bb_failure
bb_rcgcapacity66:
  %v994 = load i64, ptr %slot68, align 8
  %v995 = load i64, ptr %slot60, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %rgep997 = getelementptr i8, ptr %p996, i64 -24
  store i64 %v994, ptr %rgep997, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore66
bb_rcgstore66:
  %v998 = load i64, ptr %slot60, align 8
  %v999 = load i64, ptr %slot59, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  store i64 %v998, ptr %p1000, align 8, !alias.scope !3, !noalias !4
  %v1001 = load i64, ptr %slot12, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i32 2, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  %v1003 = load i64, ptr %slot12, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  store i32 16, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  %v1005 = load i64, ptr %slot11, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i32 1, ptr %p1006, align 4, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot9, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %ld1009 = load i32, ptr %p1008, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1009, ptr %slot71, align 8
  %v1010 = load i32, ptr %slot71, align 8
  %cv1011 = zext i32 %v1010 to i64
  %cond1012 = icmp ne i64 %cv1011, 0
  br i1 %cond1012, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1013 = load i64, ptr %slot9, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  store i32 0, ptr %p1014, align 4, !alias.scope !3, !noalias !4
  %v1015 = load i64, ptr %slot13, align 8
  store i64 %v1015, ptr %slot72, align 8
  %v1016 = load i64, ptr %slot10, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i32, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1018, ptr %slot73, align 8
  %v1019 = load i32, ptr %slot73, align 8
  %op1020 = and i32 %v1019, 28
  store i32 %op1020, ptr %slot74, align 8
  %v1021 = load i32, ptr %slot74, align 8
  %cv1022 = zext i32 %v1021 to i64
  %cond1023 = icmp ne i64 %cv1022, 0
  br i1 %cond1023, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1024 = load i64, ptr %slot20, align 8
  store i64 %v1024, ptr %slot75, align 8
  %v1025 = load i64, ptr %slot72, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i64, ptr %p1026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1027, ptr %slot76, align 8
  %v1028 = load i64, ptr %slot76, align 8
  %cmp1029 = icmp ne i64 %v1028, 0
  %cv1030 = zext i1 %cmp1029 to i32
  store i32 %cv1030, ptr %slot77, align 8
  %v1031 = load i32, ptr %slot77, align 8
  %cv1032 = zext i32 %v1031 to i64
  %cond1033 = icmp ne i64 %cv1032, 0
  br i1 %cond1033, label %bb_rcgnn98, label %bb_rcgdone98
bb_rcgnn98:
  %v1034 = load i64, ptr %slot76, align 8
  %op1035 = sub i64 %v1034, 16
  store i64 %op1035, ptr %slot78, align 8
  %v1036 = load i64, ptr %slot76, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %rgep1038 = getelementptr i8, ptr %p1037, i64 -16
  %ld1039 = load i64, ptr %rgep1038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1039, ptr %slot79, align 8
  %v1040 = load i64, ptr %slot79, align 8
  %op1041 = and i64 %v1040, 4611686018427387906
  store i64 %op1041, ptr %slot80, align 8
  %v1042 = load i64, ptr %slot80, align 8
  %cmp1043 = icmp ne i64 %v1042, 0
  %cv1044 = zext i1 %cmp1043 to i32
  store i32 %cv1044, ptr %slot81, align 8
  %v1045 = load i32, ptr %slot81, align 8
  %cv1046 = zext i32 %v1045 to i64
  %cond1047 = icmp ne i64 %cv1046, 0
  br i1 %cond1047, label %bb_rcgclear98, label %bb_rcgcounted98
bb_rcgcounted98:
  %v1048 = load i64, ptr %slot76, align 8
  %op1049 = sub i64 %v1048, 24
  store i64 %op1049, ptr %slot82, align 8
  %v1050 = load i64, ptr %slot76, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %rgep1052 = getelementptr i8, ptr %p1051, i64 -24
  %ld1053 = load i64, ptr %rgep1052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1053, ptr %slot83, align 8
  %v1054 = load i64, ptr %slot83, align 8
  %op1055 = sub i64 %v1054, 1
  store i64 %op1055, ptr %slot84, align 8
  %v1056 = load i64, ptr %slot84, align 8
  %cmp1057 = icmp eq i64 %v1056, 0
  %cv1058 = zext i1 %cmp1057 to i32
  store i32 %cv1058, ptr %slot85, align 8
  %v1059 = load i32, ptr %slot85, align 8
  %cv1060 = zext i32 %v1059 to i64
  %cond1061 = icmp ne i64 %cv1060, 0
  br i1 %cond1061, label %bb_rcglast98, label %bb_rcgdec98
bb_rcglast98:
  %v1062 = load i64, ptr %slot76, align 8
  %op1063 = sub i64 %v1062, 32
  store i64 %op1063, ptr %slot86, align 8
  %v1064 = load i64, ptr %slot76, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %rgep1066 = getelementptr i8, ptr %p1065, i64 -32
  %ld1067 = load i64, ptr %rgep1066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1067, ptr %slot87, align 8
  %v1068 = load i64, ptr %slot87, align 8
  %cmp1069 = icmp ne i64 %v1068, 0
  %cv1070 = zext i1 %cmp1069 to i32
  store i32 %cv1070, ptr %slot88, align 8
  %v1071 = load i32, ptr %slot88, align 8
  %cv1072 = zext i32 %v1071 to i64
  %cond1073 = icmp ne i64 %cv1072, 0
  br i1 %cond1073, label %bb_rcgdec98, label %bb_rcgslow98
bb_rcgslow98:
  %v1074 = load i64, ptr %slot75, align 8
  %v1075 = load i64, ptr %slot72, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1074, i64 %v1075) nomerge, !dbg !114
  br label %bb_rcgdone98
bb_rcgdec98:
  %v1076 = load i64, ptr %slot84, align 8
  %v1077 = load i64, ptr %slot76, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  %rgep1079 = getelementptr i8, ptr %p1078, i64 -24
  store i64 %v1076, ptr %rgep1079, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear98
bb_rcgclear98:
  %v1080 = load i64, ptr %slot72, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  store i64 0, ptr %p1081, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone98
bb_rcgdone98:
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1082 = load i64, ptr %slot20, align 8
  store i64 %v1082, ptr %slot89, align 8
  %v1083 = load i64, ptr %slot72, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i64, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1085, ptr %slot90, align 8
  %v1086 = load i64, ptr %slot90, align 8
  %cmp1087 = icmp ne i64 %v1086, 0
  %cv1088 = zext i1 %cmp1087 to i32
  store i32 %cv1088, ptr %slot91, align 8
  %v1089 = load i32, ptr %slot91, align 8
  %cv1090 = zext i32 %v1089 to i64
  %cond1091 = icmp ne i64 %cv1090, 0
  br i1 %cond1091, label %bb_rcgnn113, label %bb_rcgdone113
bb_rcgnn113:
  %v1092 = load i64, ptr %slot90, align 8
  %op1093 = sub i64 %v1092, 16
  store i64 %op1093, ptr %slot92, align 8
  %v1094 = load i64, ptr %slot90, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %rgep1096 = getelementptr i8, ptr %p1095, i64 -16
  %ld1097 = load i64, ptr %rgep1096, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1097, ptr %slot93, align 8
  %v1098 = load i64, ptr %slot93, align 8
  %op1099 = and i64 %v1098, 4611686018427387906
  store i64 %op1099, ptr %slot94, align 8
  %v1100 = load i64, ptr %slot94, align 8
  %cmp1101 = icmp ne i64 %v1100, 0
  %cv1102 = zext i1 %cmp1101 to i32
  store i32 %cv1102, ptr %slot95, align 8
  %v1103 = load i32, ptr %slot95, align 8
  %cv1104 = zext i32 %v1103 to i64
  %cond1105 = icmp ne i64 %cv1104, 0
  br i1 %cond1105, label %bb_rcgclear113, label %bb_rcgcounted113
bb_rcgcounted113:
  %v1106 = load i64, ptr %slot90, align 8
  %op1107 = sub i64 %v1106, 32
  store i64 %op1107, ptr %slot96, align 8
  %v1108 = load i64, ptr %slot90, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %rgep1110 = getelementptr i8, ptr %p1109, i64 -32
  %ld1111 = load i64, ptr %rgep1110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1111, ptr %slot97, align 8
  %v1112 = load i64, ptr %slot97, align 8
  %op1113 = sub i64 %v1112, 1
  store i64 %op1113, ptr %slot98, align 8
  %v1114 = load i64, ptr %slot98, align 8
  %cmp1115 = icmp eq i64 %v1114, 0
  %cv1116 = zext i1 %cmp1115 to i32
  store i32 %cv1116, ptr %slot99, align 8
  %v1117 = load i32, ptr %slot99, align 8
  %cv1118 = zext i32 %v1117 to i64
  %cond1119 = icmp ne i64 %cv1118, 0
  br i1 %cond1119, label %bb_rcglast113, label %bb_rcgdec113
bb_rcglast113:
  %v1120 = load i64, ptr %slot90, align 8
  %op1121 = sub i64 %v1120, 24
  store i64 %op1121, ptr %slot100, align 8
  %v1122 = load i64, ptr %slot90, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  %rgep1124 = getelementptr i8, ptr %p1123, i64 -24
  %ld1125 = load i64, ptr %rgep1124, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1125, ptr %slot101, align 8
  %v1126 = load i64, ptr %slot101, align 8
  %cmp1127 = icmp ne i64 %v1126, 0
  %cv1128 = zext i1 %cmp1127 to i32
  store i32 %cv1128, ptr %slot102, align 8
  %v1129 = load i32, ptr %slot102, align 8
  %cv1130 = zext i32 %v1129 to i64
  %cond1131 = icmp ne i64 %cv1130, 0
  br i1 %cond1131, label %bb_rcgdec113, label %bb_rcgslow113
bb_rcgslow113:
  %v1132 = load i64, ptr %slot89, align 8
  %v1133 = load i64, ptr %slot72, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1132, i64 %v1133) nomerge, !dbg !114
  br label %bb_rcgdone113
bb_rcgdec113:
  %v1134 = load i64, ptr %slot98, align 8
  %v1135 = load i64, ptr %slot90, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %rgep1137 = getelementptr i8, ptr %p1136, i64 -32
  store i64 %v1134, ptr %rgep1137, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear113
bb_rcgclear113:
  %v1138 = load i64, ptr %slot72, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 0, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone113
bb_rcgdone113:
  br label %bb_rcslotdone82
bb_rcslotdone82:
  br label %bb_rcprivateprepared30
bb_rcprivateprepared30:
  %v1140 = load i64, ptr %slot3, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot103, align 8
  %v1143 = load i32, ptr %slot103, align 8
  %cv1144 = zext i32 %v1143 to i64
  %cond1145 = icmp ne i64 %cv1144, 0
  br i1 %cond1145, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v1146 = load i64, ptr %slot3, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 0, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot16, align 8
  store i64 %v1148, ptr %slot104, align 8
  %v1149 = load i64, ptr %slot4, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i32, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1151, ptr %slot105, align 8
  %v1152 = load i32, ptr %slot105, align 8
  %op1153 = and i32 %v1152, 28
  store i32 %op1153, ptr %slot106, align 8
  %v1154 = load i32, ptr %slot106, align 8
  %cv1155 = zext i32 %v1154 to i64
  %cond1156 = icmp ne i64 %cv1155, 0
  br i1 %cond1156, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v1157 = load i64, ptr %slot20, align 8
  store i64 %v1157, ptr %slot107, align 8
  %v1158 = load i64, ptr %slot104, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i64, ptr %p1159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1160, ptr %slot108, align 8
  %v1161 = load i64, ptr %slot108, align 8
  %cmp1162 = icmp ne i64 %v1161, 0
  %cv1163 = zext i1 %cmp1162 to i32
  store i32 %cv1163, ptr %slot109, align 8
  %v1164 = load i32, ptr %slot109, align 8
  %cv1165 = zext i32 %v1164 to i64
  %cond1166 = icmp ne i64 %cv1165, 0
  br i1 %cond1166, label %bb_rcgnn136, label %bb_rcgdone136
bb_rcgnn136:
  %v1167 = load i64, ptr %slot108, align 8
  %op1168 = sub i64 %v1167, 16
  store i64 %op1168, ptr %slot110, align 8
  %v1169 = load i64, ptr %slot108, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %rgep1171 = getelementptr i8, ptr %p1170, i64 -16
  %ld1172 = load i64, ptr %rgep1171, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1172, ptr %slot111, align 8
  %v1173 = load i64, ptr %slot111, align 8
  %op1174 = and i64 %v1173, 4611686018427387906
  store i64 %op1174, ptr %slot112, align 8
  %v1175 = load i64, ptr %slot112, align 8
  %cmp1176 = icmp ne i64 %v1175, 0
  %cv1177 = zext i1 %cmp1176 to i32
  store i32 %cv1177, ptr %slot113, align 8
  %v1178 = load i32, ptr %slot113, align 8
  %cv1179 = zext i32 %v1178 to i64
  %cond1180 = icmp ne i64 %cv1179, 0
  br i1 %cond1180, label %bb_rcgclear136, label %bb_rcgcounted136
bb_rcgcounted136:
  %v1181 = load i64, ptr %slot108, align 8
  %op1182 = sub i64 %v1181, 24
  store i64 %op1182, ptr %slot114, align 8
  %v1183 = load i64, ptr %slot108, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %rgep1185 = getelementptr i8, ptr %p1184, i64 -24
  %ld1186 = load i64, ptr %rgep1185, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1186, ptr %slot115, align 8
  %v1187 = load i64, ptr %slot115, align 8
  %op1188 = sub i64 %v1187, 1
  store i64 %op1188, ptr %slot116, align 8
  %v1189 = load i64, ptr %slot116, align 8
  %cmp1190 = icmp eq i64 %v1189, 0
  %cv1191 = zext i1 %cmp1190 to i32
  store i32 %cv1191, ptr %slot117, align 8
  %v1192 = load i32, ptr %slot117, align 8
  %cv1193 = zext i32 %v1192 to i64
  %cond1194 = icmp ne i64 %cv1193, 0
  br i1 %cond1194, label %bb_rcglast136, label %bb_rcgdec136
bb_rcglast136:
  %v1195 = load i64, ptr %slot108, align 8
  %op1196 = sub i64 %v1195, 32
  store i64 %op1196, ptr %slot118, align 8
  %v1197 = load i64, ptr %slot108, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %rgep1199 = getelementptr i8, ptr %p1198, i64 -32
  %ld1200 = load i64, ptr %rgep1199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1200, ptr %slot119, align 8
  %v1201 = load i64, ptr %slot119, align 8
  %cmp1202 = icmp ne i64 %v1201, 0
  %cv1203 = zext i1 %cmp1202 to i32
  store i32 %cv1203, ptr %slot120, align 8
  %v1204 = load i32, ptr %slot120, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcgdec136, label %bb_rcgslow136
bb_rcgslow136:
  %v1207 = load i64, ptr %slot107, align 8
  %v1208 = load i64, ptr %slot104, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1207, i64 %v1208) nomerge, !dbg !114
  br label %bb_rcgdone136
bb_rcgdec136:
  %v1209 = load i64, ptr %slot116, align 8
  %v1210 = load i64, ptr %slot108, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %rgep1212 = getelementptr i8, ptr %p1211, i64 -24
  store i64 %v1209, ptr %rgep1212, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear136
bb_rcgclear136:
  %v1213 = load i64, ptr %slot104, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  store i64 0, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone136
bb_rcgdone136:
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v1215 = load i64, ptr %slot20, align 8
  store i64 %v1215, ptr %slot121, align 8
  %v1216 = load i64, ptr %slot104, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %ld1218 = load i64, ptr %p1217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1218, ptr %slot122, align 8
  %v1219 = load i64, ptr %slot122, align 8
  %cmp1220 = icmp ne i64 %v1219, 0
  %cv1221 = zext i1 %cmp1220 to i32
  store i32 %cv1221, ptr %slot123, align 8
  %v1222 = load i32, ptr %slot123, align 8
  %cv1223 = zext i32 %v1222 to i64
  %cond1224 = icmp ne i64 %cv1223, 0
  br i1 %cond1224, label %bb_rcgnn151, label %bb_rcgdone151
bb_rcgnn151:
  %v1225 = load i64, ptr %slot122, align 8
  %op1226 = sub i64 %v1225, 16
  store i64 %op1226, ptr %slot124, align 8
  %v1227 = load i64, ptr %slot122, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %rgep1229 = getelementptr i8, ptr %p1228, i64 -16
  %ld1230 = load i64, ptr %rgep1229, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1230, ptr %slot125, align 8
  %v1231 = load i64, ptr %slot125, align 8
  %op1232 = and i64 %v1231, 4611686018427387906
  store i64 %op1232, ptr %slot126, align 8
  %v1233 = load i64, ptr %slot126, align 8
  %cmp1234 = icmp ne i64 %v1233, 0
  %cv1235 = zext i1 %cmp1234 to i32
  store i32 %cv1235, ptr %slot127, align 8
  %v1236 = load i32, ptr %slot127, align 8
  %cv1237 = zext i32 %v1236 to i64
  %cond1238 = icmp ne i64 %cv1237, 0
  br i1 %cond1238, label %bb_rcgclear151, label %bb_rcgcounted151
bb_rcgcounted151:
  %v1239 = load i64, ptr %slot122, align 8
  %op1240 = sub i64 %v1239, 32
  store i64 %op1240, ptr %slot128, align 8
  %v1241 = load i64, ptr %slot122, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %rgep1243 = getelementptr i8, ptr %p1242, i64 -32
  %ld1244 = load i64, ptr %rgep1243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1244, ptr %slot129, align 8
  %v1245 = load i64, ptr %slot129, align 8
  %op1246 = sub i64 %v1245, 1
  store i64 %op1246, ptr %slot130, align 8
  %v1247 = load i64, ptr %slot130, align 8
  %cmp1248 = icmp eq i64 %v1247, 0
  %cv1249 = zext i1 %cmp1248 to i32
  store i32 %cv1249, ptr %slot131, align 8
  %v1250 = load i32, ptr %slot131, align 8
  %cv1251 = zext i32 %v1250 to i64
  %cond1252 = icmp ne i64 %cv1251, 0
  br i1 %cond1252, label %bb_rcglast151, label %bb_rcgdec151
bb_rcglast151:
  %v1253 = load i64, ptr %slot122, align 8
  %op1254 = sub i64 %v1253, 24
  store i64 %op1254, ptr %slot132, align 8
  %v1255 = load i64, ptr %slot122, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %rgep1257 = getelementptr i8, ptr %p1256, i64 -24
  %ld1258 = load i64, ptr %rgep1257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1258, ptr %slot133, align 8
  %v1259 = load i64, ptr %slot133, align 8
  %cmp1260 = icmp ne i64 %v1259, 0
  %cv1261 = zext i1 %cmp1260 to i32
  store i32 %cv1261, ptr %slot134, align 8
  %v1262 = load i32, ptr %slot134, align 8
  %cv1263 = zext i32 %v1262 to i64
  %cond1264 = icmp ne i64 %cv1263, 0
  br i1 %cond1264, label %bb_rcgdec151, label %bb_rcgslow151
bb_rcgslow151:
  %v1265 = load i64, ptr %slot121, align 8
  %v1266 = load i64, ptr %slot104, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1265, i64 %v1266) nomerge, !dbg !114
  br label %bb_rcgdone151
bb_rcgdec151:
  %v1267 = load i64, ptr %slot130, align 8
  %v1268 = load i64, ptr %slot122, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  %rgep1270 = getelementptr i8, ptr %p1269, i64 -32
  store i64 %v1267, ptr %rgep1270, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear151
bb_rcgclear151:
  %v1271 = load i64, ptr %slot104, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  store i64 0, ptr %p1272, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone151
bb_rcgdone151:
  br label %bb_rcslotdone120
bb_rcslotdone120:
  %v1273 = load i64, ptr %slot16, align 8
  store i64 %v1273, ptr %slot135, align 8
  %v1274 = load i64, ptr %slot15, align 8
  store i64 %v1274, ptr %slot136, align 8
  %v1275 = load i64, ptr %slot136, align 8
  %v1276 = load i64, ptr %slot135, align 8
  %p1277 = inttoptr i64 %v1275 to ptr
  %p1278 = inttoptr i64 %v1276 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1278, ptr %p1277, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot11, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i32 0, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot4, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 2, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot12, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %ld1285 = load i32, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1285, ptr %slot137, align 8
  %v1286 = load i32, ptr %slot137, align 8
  %v1287 = load i64, ptr %slot4, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 %v1286, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot3, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  store i32 1, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  %v1291 = load i64, ptr %slot16, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %ld1293 = load i64, ptr %p1292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1293, ptr %slot138, align 8
  %v1294 = load i64, ptr %slot138, align 8
  %v1295 = load i64, ptr %slot19, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i64 %v1294, ptr %p1296, align 8, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot19, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i64, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1299, ptr %slot139, align 8
  %v1300 = load i64, ptr %slot139, align 8
  %v1301 = load i64, ptr %slot14, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  store i64 %v1300, ptr %p1302, align 8, !alias.scope !3, !noalias !4
  %v1303 = load i64, ptr %slot14, align 8
  store i64 %v1303, ptr %slot140, align 8
  %v1304 = load i64, ptr %slot9, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  %ld1306 = load i32, ptr %p1305, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1306, ptr %slot141, align 8
  %v1307 = load i64, ptr %slot10, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i32, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1309, ptr %slot142, align 8
  %v1310 = load i32, ptr %slot142, align 8
  %op1311 = and i32 %v1310, 24
  store i32 %op1311, ptr %slot142, align 8
  %v1312 = load i32, ptr %slot142, align 8
  %cmp1313 = icmp eq i32 %v1312, 0
  %cv1314 = zext i1 %cmp1313 to i32
  store i32 %cv1314, ptr %slot143, align 8
  %v1315 = load i32, ptr %slot141, align 8
  %v1316 = load i32, ptr %slot143, align 8
  %op1317 = and i32 %v1315, %v1316
  store i32 %op1317, ptr %slot144, align 8
  %v1318 = load i32, ptr %slot144, align 8
  %cv1319 = zext i32 %v1318 to i64
  %cond1320 = icmp ne i64 %cv1319, 0
  br i1 %cond1320, label %bb_rctake165, label %bb_rccopy165
bb_rctake165:
  %v1321 = load i64, ptr %slot15, align 8
  store i64 %v1321, ptr %slot145, align 8
  %v1322 = load i64, ptr %slot21, align 8
  store i64 %v1322, ptr %slot146, align 8
  %v1323 = load i64, ptr %slot140, align 8
  %v1324 = load i64, ptr %slot145, align 8
  %op1325 = sub i64 %v1323, %v1324
  store i64 %op1325, ptr %slot147, align 8
  %v1326 = load i64, ptr %slot145, align 8
  %v1327 = load i64, ptr %slot140, align 8
  %op1328 = sub i64 %v1326, %v1327
  store i64 %op1328, ptr %slot148, align 8
  %v1329 = load i64, ptr %slot147, align 8
  %cmp1330 = icmp ult i64 %v1329, 8
  %cv1331 = zext i1 %cmp1330 to i32
  store i32 %cv1331, ptr %slot149, align 8
  %v1332 = load i64, ptr %slot148, align 8
  %cmp1333 = icmp ult i64 %v1332, 8
  %cv1334 = zext i1 %cmp1333 to i32
  store i32 %cv1334, ptr %slot150, align 8
  %v1335 = load i32, ptr %slot149, align 8
  %v1336 = load i32, ptr %slot150, align 8
  %op1337 = or i32 %v1335, %v1336
  store i32 %op1337, ptr %slot151, align 8
  %v1338 = load i32, ptr %slot151, align 8
  %cv1339 = zext i32 %v1338 to i64
  %cond1340 = icmp ne i64 %cv1339, 0
  br i1 %cond1340, label %bb_rcmoveslow174, label %bb_rcmovecheck174
bb_rcmovecheck174:
  %v1341 = load i64, ptr %slot140, align 8
  %p1343 = inttoptr i64 %v1341 to ptr
  %gep1344 = getelementptr i8, ptr %p1343, i64 0
  %op1342 = ptrtoint ptr %gep1344 to i64
  store i64 %op1342, ptr %slot152, align 8
  %v1345 = load i64, ptr %slot152, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i64, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1347, ptr %slot153, align 8
  %v1348 = load i64, ptr %slot153, align 8
  %cmp1349 = icmp ne i64 %v1348, 0
  %cv1350 = zext i1 %cmp1349 to i32
  store i32 %cv1350, ptr %slot154, align 8
  %v1351 = load i32, ptr %slot154, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcmoveheader182, label %bb_rcmovenext182
bb_rcmoveheader182:
  %v1354 = load i64, ptr %slot153, align 8
  %op1355 = sub i64 %v1354, 16
  store i64 %op1355, ptr %slot155, align 8
  %v1356 = load i64, ptr %slot153, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  %rgep1358 = getelementptr i8, ptr %p1357, i64 -16
  %ld1359 = load i64, ptr %rgep1358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1359, ptr %slot156, align 8
  %v1360 = load i64, ptr %slot156, align 8
  %op1361 = and i64 %v1360, 5764607523034234881
  store i64 %op1361, ptr %slot157, align 8
  %v1362 = load i64, ptr %slot157, align 8
  %cmp1363 = icmp ne i64 %v1362, 0
  %cv1364 = zext i1 %cmp1363 to i32
  store i32 %cv1364, ptr %slot158, align 8
  %v1365 = load i32, ptr %slot158, align 8
  %cv1366 = zext i32 %v1365 to i64
  %cond1367 = icmp ne i64 %cv1366, 0
  br i1 %cond1367, label %bb_rcmoveslow174, label %bb_rcmovenext182
bb_rcmovenext182:
  %v1368 = load i64, ptr %slot140, align 8
  %v1369 = load i64, ptr %slot145, align 8
  %p1370 = inttoptr i64 %v1368 to ptr
  %p1371 = inttoptr i64 %v1369 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1371, ptr %p1370, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1372 = load i64, ptr %slot140, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  store i64 0, ptr %p1373, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved174
bb_rcmoveslow174:
  %v1374 = load i64, ptr %slot20, align 8
  %v1375 = load i64, ptr %slot145, align 8
  %v1376 = load i64, ptr %slot140, align 8
  %v1377 = load i64, ptr %slot146, align 8
  %cv1378 = trunc i64 %v1377 to i32
  %call1379 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1374, i64 %v1375, i64 %v1376, i32 %cv1378) nomerge, !dbg !116
  store i32 %call1379, ptr %slot159, align 8
  %v1380 = load i32, ptr %slot159, align 8
  %cv1381 = zext i32 %v1380 to i64
  %cond1382 = icmp ne i64 %cv1381, 0
  br i1 %cond1382, label %bb_rcsuccess189, label %bb_rcfailure189
bb_rcfailure189:
  %v1383 = load i64, ptr %slot20, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %call1385 = call i32 @myl_rc_take_failure(ptr %p1384) nomerge, !dbg !116
  store i32 %call1385, ptr %slot160, align 8
  %v1386 = load i64, ptr %slot1, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %v1388 = load i32, ptr %slot160, align 8
  %call1389 = call i32 @myl_qbe_rc_status(ptr %p1387, i32 %v1388) nomerge, !dbg !116
  store i32 %call1389, ptr %slot161, align 8
  br label %bb_failure
bb_rcsuccess189:
  br label %bb_rcmoved174
bb_rcmoved174:
  %v1390 = load i64, ptr %slot9, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i32 0, ptr %p1391, align 4, !alias.scope !3, !noalias !4
  %v1392 = load i64, ptr %slot12, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 2, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot11, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i32 1, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared165
bb_rccopy165:
  %v1396 = load i64, ptr %slot15, align 8
  store i64 %v1396, ptr %slot162, align 8
  %v1397 = load i64, ptr %slot21, align 8
  store i64 %v1397, ptr %slot163, align 8
  %v1398 = load i64, ptr %slot140, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i64, ptr %p1399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1400, ptr %slot164, align 8
  %v1401 = load i64, ptr %slot164, align 8
  %cmp1402 = icmp ne i64 %v1401, 0
  %cv1403 = zext i1 %cmp1402 to i32
  store i32 %cv1403, ptr %slot165, align 8
  %v1404 = load i32, ptr %slot165, align 8
  %cv1405 = zext i32 %v1404 to i64
  %cond1406 = icmp ne i64 %cv1405, 0
  br i1 %cond1406, label %bb_rcgnn198, label %bb_rcgplain198
bb_rcgnn198:
  %v1407 = load i64, ptr %slot164, align 8
  %op1408 = sub i64 %v1407, 16
  store i64 %op1408, ptr %slot166, align 8
  %v1409 = load i64, ptr %slot164, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %rgep1411 = getelementptr i8, ptr %p1410, i64 -16
  %ld1412 = load i64, ptr %rgep1411, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1412, ptr %slot167, align 8
  %v1413 = load i64, ptr %slot167, align 8
  %op1414 = and i64 %v1413, 4611686018427387906
  store i64 %op1414, ptr %slot168, align 8
  %v1415 = load i64, ptr %slot168, align 8
  %cmp1416 = icmp ne i64 %v1415, 0
  %cv1417 = zext i1 %cmp1416 to i32
  store i32 %cv1417, ptr %slot169, align 8
  %v1418 = load i32, ptr %slot169, align 8
  %cv1419 = zext i32 %v1418 to i64
  %cond1420 = icmp ne i64 %cv1419, 0
  br i1 %cond1420, label %bb_rcgspecial198, label %bb_rcginc198
bb_rcginc198:
  %v1421 = load i64, ptr %slot164, align 8
  %op1422 = sub i64 %v1421, 32
  store i64 %op1422, ptr %slot170, align 8
  %v1423 = load i64, ptr %slot164, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  %rgep1425 = getelementptr i8, ptr %p1424, i64 -32
  %ld1426 = load i64, ptr %rgep1425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1426, ptr %slot171, align 8
  %v1427 = load i64, ptr %slot171, align 8
  %op1428 = add i64 %v1427, 1
  store i64 %op1428, ptr %slot172, align 8
  %v1429 = load i64, ptr %slot172, align 8
  %cmp1430 = icmp eq i64 %v1429, 0
  %cv1431 = zext i1 %cmp1430 to i32
  store i32 %cv1431, ptr %slot173, align 8
  %v1432 = load i32, ptr %slot173, align 8
  %cv1433 = zext i32 %v1432 to i64
  %cond1434 = icmp ne i64 %cv1433, 0
  br i1 %cond1434, label %bb_rcglimit198, label %bb_rcgcapacity198
bb_rcglimit198:
  %v1435 = load i64, ptr %slot1, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %call1437 = call i32 @myl_qbe_rc_status(ptr %p1436, i32 2) nomerge, !dbg !116
  store i32 %call1437, ptr %slot174, align 8
  br label %bb_failure
bb_rcgcapacity198:
  %v1438 = load i64, ptr %slot172, align 8
  %v1439 = load i64, ptr %slot164, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %rgep1441 = getelementptr i8, ptr %p1440, i64 -32
  store i64 %v1438, ptr %rgep1441, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain198
bb_rcgspecial198:
  %v1442 = load i64, ptr %slot167, align 8
  %op1443 = and i64 %v1442, 4611686018427387904
  store i64 %op1443, ptr %slot175, align 8
  %v1444 = load i64, ptr %slot175, align 8
  %cmp1445 = icmp ne i64 %v1444, 0
  %cv1446 = zext i1 %cmp1445 to i32
  store i32 %cv1446, ptr %slot176, align 8
  %v1447 = load i32, ptr %slot176, align 8
  %cv1448 = zext i32 %v1447 to i64
  %cond1449 = icmp ne i64 %cv1448, 0
  br i1 %cond1449, label %bb_rcgslow198, label %bb_rcgplain198
bb_rcgslow198:
  %v1450 = load i64, ptr %slot20, align 8
  %v1451 = load i64, ptr %slot162, align 8
  %v1452 = load i64, ptr %slot140, align 8
  %v1453 = load i64, ptr %slot163, align 8
  %cv1454 = trunc i64 %v1453 to i32
  %call1455 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1450, i64 %v1451, i64 %v1452, i32 %cv1454) nomerge, !dbg !116
  store i32 %call1455, ptr %slot177, align 8
  %v1456 = load i32, ptr %slot177, align 8
  %cv1457 = zext i32 %v1456 to i64
  %cond1458 = icmp ne i64 %cv1457, 0
  br i1 %cond1458, label %bb_rcsuccess212, label %bb_rcfailure212
bb_rcfailure212:
  %v1459 = load i64, ptr %slot20, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %call1461 = call i32 @myl_rc_take_failure(ptr %p1460) nomerge, !dbg !116
  store i32 %call1461, ptr %slot178, align 8
  %v1462 = load i64, ptr %slot1, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %v1464 = load i32, ptr %slot178, align 8
  %call1465 = call i32 @myl_qbe_rc_status(ptr %p1463, i32 %v1464) nomerge, !dbg !116
  store i32 %call1465, ptr %slot179, align 8
  br label %bb_failure
bb_rcsuccess212:
  br label %bb_rcgdone198
bb_rcgplain198:
  %v1466 = load i64, ptr %slot164, align 8
  %v1467 = load i64, ptr %slot162, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i64 %v1466, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone198
bb_rcgdone198:
  %v1469 = load i64, ptr %slot12, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  store i32 2, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  %v1471 = load i64, ptr %slot11, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  store i32 1, ptr %p1472, align 4, !alias.scope !3, !noalias !4
  %v1473 = load i64, ptr %slot9, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %ld1475 = load i32, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1475, ptr %slot180, align 8
  %v1476 = load i32, ptr %slot180, align 8
  %cv1477 = zext i32 %v1476 to i64
  %cond1478 = icmp ne i64 %cv1477, 0
  br i1 %cond1478, label %bb_rcslotdrop219, label %bb_rcslotdone219
bb_rcslotdrop219:
  %v1479 = load i64, ptr %slot9, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i32 0, ptr %p1480, align 4, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot13, align 8
  store i64 %v1481, ptr %slot181, align 8
  %v1482 = load i64, ptr %slot10, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %ld1484 = load i32, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1484, ptr %slot182, align 8
  %v1485 = load i32, ptr %slot182, align 8
  %op1486 = and i32 %v1485, 28
  store i32 %op1486, ptr %slot183, align 8
  %v1487 = load i32, ptr %slot183, align 8
  %cv1488 = zext i32 %v1487 to i64
  %cond1489 = icmp ne i64 %cv1488, 0
  br i1 %cond1489, label %bb_rcslotrole219, label %bb_rcslotowner219
bb_rcslotrole219:
  %v1490 = load i64, ptr %slot20, align 8
  store i64 %v1490, ptr %slot184, align 8
  %v1491 = load i64, ptr %slot181, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i64, ptr %p1492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1493, ptr %slot185, align 8
  %v1494 = load i64, ptr %slot185, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot186, align 8
  %v1497 = load i32, ptr %slot186, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcgnn235, label %bb_rcgdone235
bb_rcgnn235:
  %v1500 = load i64, ptr %slot185, align 8
  %op1501 = sub i64 %v1500, 16
  store i64 %op1501, ptr %slot187, align 8
  %v1502 = load i64, ptr %slot185, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %rgep1504 = getelementptr i8, ptr %p1503, i64 -16
  %ld1505 = load i64, ptr %rgep1504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1505, ptr %slot188, align 8
  %v1506 = load i64, ptr %slot188, align 8
  %op1507 = and i64 %v1506, 4611686018427387906
  store i64 %op1507, ptr %slot189, align 8
  %v1508 = load i64, ptr %slot189, align 8
  %cmp1509 = icmp ne i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot190, align 8
  %v1511 = load i32, ptr %slot190, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcgclear235, label %bb_rcgcounted235
bb_rcgcounted235:
  %v1514 = load i64, ptr %slot185, align 8
  %op1515 = sub i64 %v1514, 24
  store i64 %op1515, ptr %slot191, align 8
  %v1516 = load i64, ptr %slot185, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %rgep1518 = getelementptr i8, ptr %p1517, i64 -24
  %ld1519 = load i64, ptr %rgep1518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1519, ptr %slot192, align 8
  %v1520 = load i64, ptr %slot192, align 8
  %op1521 = sub i64 %v1520, 1
  store i64 %op1521, ptr %slot193, align 8
  %v1522 = load i64, ptr %slot193, align 8
  %cmp1523 = icmp eq i64 %v1522, 0
  %cv1524 = zext i1 %cmp1523 to i32
  store i32 %cv1524, ptr %slot194, align 8
  %v1525 = load i32, ptr %slot194, align 8
  %cv1526 = zext i32 %v1525 to i64
  %cond1527 = icmp ne i64 %cv1526, 0
  br i1 %cond1527, label %bb_rcglast235, label %bb_rcgdec235
bb_rcglast235:
  %v1528 = load i64, ptr %slot185, align 8
  %op1529 = sub i64 %v1528, 32
  store i64 %op1529, ptr %slot195, align 8
  %v1530 = load i64, ptr %slot185, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  %rgep1532 = getelementptr i8, ptr %p1531, i64 -32
  %ld1533 = load i64, ptr %rgep1532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1533, ptr %slot196, align 8
  %v1534 = load i64, ptr %slot196, align 8
  %cmp1535 = icmp ne i64 %v1534, 0
  %cv1536 = zext i1 %cmp1535 to i32
  store i32 %cv1536, ptr %slot197, align 8
  %v1537 = load i32, ptr %slot197, align 8
  %cv1538 = zext i32 %v1537 to i64
  %cond1539 = icmp ne i64 %cv1538, 0
  br i1 %cond1539, label %bb_rcgdec235, label %bb_rcgslow235
bb_rcgslow235:
  %v1540 = load i64, ptr %slot184, align 8
  %v1541 = load i64, ptr %slot181, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1540, i64 %v1541) nomerge, !dbg !116
  br label %bb_rcgdone235
bb_rcgdec235:
  %v1542 = load i64, ptr %slot193, align 8
  %v1543 = load i64, ptr %slot185, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %rgep1545 = getelementptr i8, ptr %p1544, i64 -24
  store i64 %v1542, ptr %rgep1545, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear235
bb_rcgclear235:
  %v1546 = load i64, ptr %slot181, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i64 0, ptr %p1547, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone235
bb_rcgdone235:
  br label %bb_rcslotdone219
bb_rcslotowner219:
  %v1548 = load i64, ptr %slot20, align 8
  store i64 %v1548, ptr %slot198, align 8
  %v1549 = load i64, ptr %slot181, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %ld1551 = load i64, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1551, ptr %slot199, align 8
  %v1552 = load i64, ptr %slot199, align 8
  %cmp1553 = icmp ne i64 %v1552, 0
  %cv1554 = zext i1 %cmp1553 to i32
  store i32 %cv1554, ptr %slot200, align 8
  %v1555 = load i32, ptr %slot200, align 8
  %cv1556 = zext i32 %v1555 to i64
  %cond1557 = icmp ne i64 %cv1556, 0
  br i1 %cond1557, label %bb_rcgnn250, label %bb_rcgdone250
bb_rcgnn250:
  %v1558 = load i64, ptr %slot199, align 8
  %op1559 = sub i64 %v1558, 16
  store i64 %op1559, ptr %slot201, align 8
  %v1560 = load i64, ptr %slot199, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %rgep1562 = getelementptr i8, ptr %p1561, i64 -16
  %ld1563 = load i64, ptr %rgep1562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1563, ptr %slot202, align 8
  %v1564 = load i64, ptr %slot202, align 8
  %op1565 = and i64 %v1564, 4611686018427387906
  store i64 %op1565, ptr %slot203, align 8
  %v1566 = load i64, ptr %slot203, align 8
  %cmp1567 = icmp ne i64 %v1566, 0
  %cv1568 = zext i1 %cmp1567 to i32
  store i32 %cv1568, ptr %slot204, align 8
  %v1569 = load i32, ptr %slot204, align 8
  %cv1570 = zext i32 %v1569 to i64
  %cond1571 = icmp ne i64 %cv1570, 0
  br i1 %cond1571, label %bb_rcgclear250, label %bb_rcgcounted250
bb_rcgcounted250:
  %v1572 = load i64, ptr %slot199, align 8
  %op1573 = sub i64 %v1572, 32
  store i64 %op1573, ptr %slot205, align 8
  %v1574 = load i64, ptr %slot199, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %rgep1576 = getelementptr i8, ptr %p1575, i64 -32
  %ld1577 = load i64, ptr %rgep1576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1577, ptr %slot206, align 8
  %v1578 = load i64, ptr %slot206, align 8
  %op1579 = sub i64 %v1578, 1
  store i64 %op1579, ptr %slot207, align 8
  %v1580 = load i64, ptr %slot207, align 8
  %cmp1581 = icmp eq i64 %v1580, 0
  %cv1582 = zext i1 %cmp1581 to i32
  store i32 %cv1582, ptr %slot208, align 8
  %v1583 = load i32, ptr %slot208, align 8
  %cv1584 = zext i32 %v1583 to i64
  %cond1585 = icmp ne i64 %cv1584, 0
  br i1 %cond1585, label %bb_rcglast250, label %bb_rcgdec250
bb_rcglast250:
  %v1586 = load i64, ptr %slot199, align 8
  %op1587 = sub i64 %v1586, 24
  store i64 %op1587, ptr %slot209, align 8
  %v1588 = load i64, ptr %slot199, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  %rgep1590 = getelementptr i8, ptr %p1589, i64 -24
  %ld1591 = load i64, ptr %rgep1590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1591, ptr %slot210, align 8
  %v1592 = load i64, ptr %slot210, align 8
  %cmp1593 = icmp ne i64 %v1592, 0
  %cv1594 = zext i1 %cmp1593 to i32
  store i32 %cv1594, ptr %slot211, align 8
  %v1595 = load i32, ptr %slot211, align 8
  %cv1596 = zext i32 %v1595 to i64
  %cond1597 = icmp ne i64 %cv1596, 0
  br i1 %cond1597, label %bb_rcgdec250, label %bb_rcgslow250
bb_rcgslow250:
  %v1598 = load i64, ptr %slot198, align 8
  %v1599 = load i64, ptr %slot181, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1598, i64 %v1599) nomerge, !dbg !116
  br label %bb_rcgdone250
bb_rcgdec250:
  %v1600 = load i64, ptr %slot207, align 8
  %v1601 = load i64, ptr %slot199, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %rgep1603 = getelementptr i8, ptr %p1602, i64 -32
  store i64 %v1600, ptr %rgep1603, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear250
bb_rcgclear250:
  %v1604 = load i64, ptr %slot181, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i64 0, ptr %p1605, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone250
bb_rcgdone250:
  br label %bb_rcslotdone219
bb_rcslotdone219:
  br label %bb_rcprepared165
bb_rcprepared165:
  %v1606 = load i64, ptr %slot5, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i32, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1608, ptr %slot212, align 8
  %v1609 = load i32, ptr %slot212, align 8
  %cv1610 = zext i32 %v1609 to i64
  %cond1611 = icmp ne i64 %cv1610, 0
  br i1 %cond1611, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v1612 = load i64, ptr %slot5, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot17, align 8
  store i64 %v1614, ptr %slot213, align 8
  %v1615 = load i64, ptr %slot6, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i32, ptr %p1616, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1617, ptr %slot214, align 8
  %v1618 = load i32, ptr %slot214, align 8
  %op1619 = and i32 %v1618, 28
  store i32 %op1619, ptr %slot215, align 8
  %v1620 = load i32, ptr %slot215, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcslotrole257, label %bb_rcslotowner257
bb_rcslotrole257:
  %v1623 = load i64, ptr %slot20, align 8
  store i64 %v1623, ptr %slot216, align 8
  %v1624 = load i64, ptr %slot213, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i64, ptr %p1625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1626, ptr %slot217, align 8
  %v1627 = load i64, ptr %slot217, align 8
  %cmp1628 = icmp ne i64 %v1627, 0
  %cv1629 = zext i1 %cmp1628 to i32
  store i32 %cv1629, ptr %slot218, align 8
  %v1630 = load i32, ptr %slot218, align 8
  %cv1631 = zext i32 %v1630 to i64
  %cond1632 = icmp ne i64 %cv1631, 0
  br i1 %cond1632, label %bb_rcgnn273, label %bb_rcgdone273
bb_rcgnn273:
  %v1633 = load i64, ptr %slot217, align 8
  %op1634 = sub i64 %v1633, 16
  store i64 %op1634, ptr %slot219, align 8
  %v1635 = load i64, ptr %slot217, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %rgep1637 = getelementptr i8, ptr %p1636, i64 -16
  %ld1638 = load i64, ptr %rgep1637, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1638, ptr %slot220, align 8
  %v1639 = load i64, ptr %slot220, align 8
  %op1640 = and i64 %v1639, 4611686018427387906
  store i64 %op1640, ptr %slot221, align 8
  %v1641 = load i64, ptr %slot221, align 8
  %cmp1642 = icmp ne i64 %v1641, 0
  %cv1643 = zext i1 %cmp1642 to i32
  store i32 %cv1643, ptr %slot222, align 8
  %v1644 = load i32, ptr %slot222, align 8
  %cv1645 = zext i32 %v1644 to i64
  %cond1646 = icmp ne i64 %cv1645, 0
  br i1 %cond1646, label %bb_rcgclear273, label %bb_rcgcounted273
bb_rcgcounted273:
  %v1647 = load i64, ptr %slot217, align 8
  %op1648 = sub i64 %v1647, 24
  store i64 %op1648, ptr %slot223, align 8
  %v1649 = load i64, ptr %slot217, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  %rgep1651 = getelementptr i8, ptr %p1650, i64 -24
  %ld1652 = load i64, ptr %rgep1651, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1652, ptr %slot224, align 8
  %v1653 = load i64, ptr %slot224, align 8
  %op1654 = sub i64 %v1653, 1
  store i64 %op1654, ptr %slot225, align 8
  %v1655 = load i64, ptr %slot225, align 8
  %cmp1656 = icmp eq i64 %v1655, 0
  %cv1657 = zext i1 %cmp1656 to i32
  store i32 %cv1657, ptr %slot226, align 8
  %v1658 = load i32, ptr %slot226, align 8
  %cv1659 = zext i32 %v1658 to i64
  %cond1660 = icmp ne i64 %cv1659, 0
  br i1 %cond1660, label %bb_rcglast273, label %bb_rcgdec273
bb_rcglast273:
  %v1661 = load i64, ptr %slot217, align 8
  %op1662 = sub i64 %v1661, 32
  store i64 %op1662, ptr %slot227, align 8
  %v1663 = load i64, ptr %slot217, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %rgep1665 = getelementptr i8, ptr %p1664, i64 -32
  %ld1666 = load i64, ptr %rgep1665, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1666, ptr %slot228, align 8
  %v1667 = load i64, ptr %slot228, align 8
  %cmp1668 = icmp ne i64 %v1667, 0
  %cv1669 = zext i1 %cmp1668 to i32
  store i32 %cv1669, ptr %slot229, align 8
  %v1670 = load i32, ptr %slot229, align 8
  %cv1671 = zext i32 %v1670 to i64
  %cond1672 = icmp ne i64 %cv1671, 0
  br i1 %cond1672, label %bb_rcgdec273, label %bb_rcgslow273
bb_rcgslow273:
  %v1673 = load i64, ptr %slot216, align 8
  %v1674 = load i64, ptr %slot213, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1673, i64 %v1674) nomerge, !dbg !116
  br label %bb_rcgdone273
bb_rcgdec273:
  %v1675 = load i64, ptr %slot225, align 8
  %v1676 = load i64, ptr %slot217, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %rgep1678 = getelementptr i8, ptr %p1677, i64 -24
  store i64 %v1675, ptr %rgep1678, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear273
bb_rcgclear273:
  %v1679 = load i64, ptr %slot213, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  store i64 0, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone273
bb_rcgdone273:
  br label %bb_rcslotdone257
bb_rcslotowner257:
  %v1681 = load i64, ptr %slot20, align 8
  store i64 %v1681, ptr %slot230, align 8
  %v1682 = load i64, ptr %slot213, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %ld1684 = load i64, ptr %p1683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1684, ptr %slot231, align 8
  %v1685 = load i64, ptr %slot231, align 8
  %cmp1686 = icmp ne i64 %v1685, 0
  %cv1687 = zext i1 %cmp1686 to i32
  store i32 %cv1687, ptr %slot232, align 8
  %v1688 = load i32, ptr %slot232, align 8
  %cv1689 = zext i32 %v1688 to i64
  %cond1690 = icmp ne i64 %cv1689, 0
  br i1 %cond1690, label %bb_rcgnn288, label %bb_rcgdone288
bb_rcgnn288:
  %v1691 = load i64, ptr %slot231, align 8
  %op1692 = sub i64 %v1691, 16
  store i64 %op1692, ptr %slot233, align 8
  %v1693 = load i64, ptr %slot231, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %rgep1695 = getelementptr i8, ptr %p1694, i64 -16
  %ld1696 = load i64, ptr %rgep1695, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1696, ptr %slot234, align 8
  %v1697 = load i64, ptr %slot234, align 8
  %op1698 = and i64 %v1697, 4611686018427387906
  store i64 %op1698, ptr %slot235, align 8
  %v1699 = load i64, ptr %slot235, align 8
  %cmp1700 = icmp ne i64 %v1699, 0
  %cv1701 = zext i1 %cmp1700 to i32
  store i32 %cv1701, ptr %slot236, align 8
  %v1702 = load i32, ptr %slot236, align 8
  %cv1703 = zext i32 %v1702 to i64
  %cond1704 = icmp ne i64 %cv1703, 0
  br i1 %cond1704, label %bb_rcgclear288, label %bb_rcgcounted288
bb_rcgcounted288:
  %v1705 = load i64, ptr %slot231, align 8
  %op1706 = sub i64 %v1705, 32
  store i64 %op1706, ptr %slot237, align 8
  %v1707 = load i64, ptr %slot231, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  %rgep1709 = getelementptr i8, ptr %p1708, i64 -32
  %ld1710 = load i64, ptr %rgep1709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1710, ptr %slot238, align 8
  %v1711 = load i64, ptr %slot238, align 8
  %op1712 = sub i64 %v1711, 1
  store i64 %op1712, ptr %slot239, align 8
  %v1713 = load i64, ptr %slot239, align 8
  %cmp1714 = icmp eq i64 %v1713, 0
  %cv1715 = zext i1 %cmp1714 to i32
  store i32 %cv1715, ptr %slot240, align 8
  %v1716 = load i32, ptr %slot240, align 8
  %cv1717 = zext i32 %v1716 to i64
  %cond1718 = icmp ne i64 %cv1717, 0
  br i1 %cond1718, label %bb_rcglast288, label %bb_rcgdec288
bb_rcglast288:
  %v1719 = load i64, ptr %slot231, align 8
  %op1720 = sub i64 %v1719, 24
  store i64 %op1720, ptr %slot241, align 8
  %v1721 = load i64, ptr %slot231, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %rgep1723 = getelementptr i8, ptr %p1722, i64 -24
  %ld1724 = load i64, ptr %rgep1723, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1724, ptr %slot242, align 8
  %v1725 = load i64, ptr %slot242, align 8
  %cmp1726 = icmp ne i64 %v1725, 0
  %cv1727 = zext i1 %cmp1726 to i32
  store i32 %cv1727, ptr %slot243, align 8
  %v1728 = load i32, ptr %slot243, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcgdec288, label %bb_rcgslow288
bb_rcgslow288:
  %v1731 = load i64, ptr %slot230, align 8
  %v1732 = load i64, ptr %slot213, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1731, i64 %v1732) nomerge, !dbg !116
  br label %bb_rcgdone288
bb_rcgdec288:
  %v1733 = load i64, ptr %slot239, align 8
  %v1734 = load i64, ptr %slot231, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %rgep1736 = getelementptr i8, ptr %p1735, i64 -32
  store i64 %v1733, ptr %rgep1736, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear288
bb_rcgclear288:
  %v1737 = load i64, ptr %slot213, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  store i64 0, ptr %p1738, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone288
bb_rcgdone288:
  br label %bb_rcslotdone257
bb_rcslotdone257:
  %v1739 = load i64, ptr %slot17, align 8
  store i64 %v1739, ptr %slot244, align 8
  %v1740 = load i64, ptr %slot15, align 8
  store i64 %v1740, ptr %slot245, align 8
  %v1741 = load i64, ptr %slot245, align 8
  %v1742 = load i64, ptr %slot244, align 8
  %p1743 = inttoptr i64 %v1741 to ptr
  %p1744 = inttoptr i64 %v1742 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1744, ptr %p1743, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot11, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i32 0, ptr %p1746, align 4, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot6, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i32 2, ptr %p1748, align 4, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot12, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i32, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1751, ptr %slot246, align 8
  %v1752 = load i32, ptr %slot246, align 8
  %v1753 = load i64, ptr %slot6, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i32 %v1752, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot5, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  store i32 1, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot3, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  %ld1759 = load i32, ptr %p1758, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1759, ptr %slot247, align 8
  %v1760 = load i32, ptr %slot247, align 8
  %cv1761 = zext i32 %v1760 to i64
  %cond1762 = icmp ne i64 %cv1761, 0
  br i1 %cond1762, label %bb_rcslotdrop301, label %bb_rcslotdone301
bb_rcslotdrop301:
  %v1763 = load i64, ptr %slot3, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  store i32 0, ptr %p1764, align 4, !alias.scope !3, !noalias !4
  %v1765 = load i64, ptr %slot16, align 8
  store i64 %v1765, ptr %slot248, align 8
  %v1766 = load i64, ptr %slot4, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %ld1768 = load i32, ptr %p1767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1768, ptr %slot249, align 8
  %v1769 = load i32, ptr %slot249, align 8
  %op1770 = and i32 %v1769, 28
  store i32 %op1770, ptr %slot250, align 8
  %v1771 = load i32, ptr %slot250, align 8
  %cv1772 = zext i32 %v1771 to i64
  %cond1773 = icmp ne i64 %cv1772, 0
  br i1 %cond1773, label %bb_rcslotrole301, label %bb_rcslotowner301
bb_rcslotrole301:
  %v1774 = load i64, ptr %slot20, align 8
  store i64 %v1774, ptr %slot251, align 8
  %v1775 = load i64, ptr %slot248, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i64, ptr %p1776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1777, ptr %slot252, align 8
  %v1778 = load i64, ptr %slot252, align 8
  %cmp1779 = icmp ne i64 %v1778, 0
  %cv1780 = zext i1 %cmp1779 to i32
  store i32 %cv1780, ptr %slot253, align 8
  %v1781 = load i32, ptr %slot253, align 8
  %cv1782 = zext i32 %v1781 to i64
  %cond1783 = icmp ne i64 %cv1782, 0
  br i1 %cond1783, label %bb_rcgnn317, label %bb_rcgdone317
bb_rcgnn317:
  %v1784 = load i64, ptr %slot252, align 8
  %op1785 = sub i64 %v1784, 16
  store i64 %op1785, ptr %slot254, align 8
  %v1786 = load i64, ptr %slot252, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  %rgep1788 = getelementptr i8, ptr %p1787, i64 -16
  %ld1789 = load i64, ptr %rgep1788, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1789, ptr %slot255, align 8
  %v1790 = load i64, ptr %slot255, align 8
  %op1791 = and i64 %v1790, 4611686018427387906
  store i64 %op1791, ptr %slot256, align 8
  %v1792 = load i64, ptr %slot256, align 8
  %cmp1793 = icmp ne i64 %v1792, 0
  %cv1794 = zext i1 %cmp1793 to i32
  store i32 %cv1794, ptr %slot257, align 8
  %v1795 = load i32, ptr %slot257, align 8
  %cv1796 = zext i32 %v1795 to i64
  %cond1797 = icmp ne i64 %cv1796, 0
  br i1 %cond1797, label %bb_rcgclear317, label %bb_rcgcounted317
bb_rcgcounted317:
  %v1798 = load i64, ptr %slot252, align 8
  %op1799 = sub i64 %v1798, 24
  store i64 %op1799, ptr %slot258, align 8
  %v1800 = load i64, ptr %slot252, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %rgep1802 = getelementptr i8, ptr %p1801, i64 -24
  %ld1803 = load i64, ptr %rgep1802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1803, ptr %slot259, align 8
  %v1804 = load i64, ptr %slot259, align 8
  %op1805 = sub i64 %v1804, 1
  store i64 %op1805, ptr %slot260, align 8
  %v1806 = load i64, ptr %slot260, align 8
  %cmp1807 = icmp eq i64 %v1806, 0
  %cv1808 = zext i1 %cmp1807 to i32
  store i32 %cv1808, ptr %slot261, align 8
  %v1809 = load i32, ptr %slot261, align 8
  %cv1810 = zext i32 %v1809 to i64
  %cond1811 = icmp ne i64 %cv1810, 0
  br i1 %cond1811, label %bb_rcglast317, label %bb_rcgdec317
bb_rcglast317:
  %v1812 = load i64, ptr %slot252, align 8
  %op1813 = sub i64 %v1812, 32
  store i64 %op1813, ptr %slot262, align 8
  %v1814 = load i64, ptr %slot252, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  %rgep1816 = getelementptr i8, ptr %p1815, i64 -32
  %ld1817 = load i64, ptr %rgep1816, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1817, ptr %slot263, align 8
  %v1818 = load i64, ptr %slot263, align 8
  %cmp1819 = icmp ne i64 %v1818, 0
  %cv1820 = zext i1 %cmp1819 to i32
  store i32 %cv1820, ptr %slot264, align 8
  %v1821 = load i32, ptr %slot264, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcgdec317, label %bb_rcgslow317
bb_rcgslow317:
  %v1824 = load i64, ptr %slot251, align 8
  %v1825 = load i64, ptr %slot248, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1824, i64 %v1825) nomerge, !dbg !116
  br label %bb_rcgdone317
bb_rcgdec317:
  %v1826 = load i64, ptr %slot260, align 8
  %v1827 = load i64, ptr %slot252, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %rgep1829 = getelementptr i8, ptr %p1828, i64 -24
  store i64 %v1826, ptr %rgep1829, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear317
bb_rcgclear317:
  %v1830 = load i64, ptr %slot248, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  store i64 0, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone317
bb_rcgdone317:
  br label %bb_rcslotdone301
bb_rcslotowner301:
  %v1832 = load i64, ptr %slot20, align 8
  store i64 %v1832, ptr %slot265, align 8
  %v1833 = load i64, ptr %slot248, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %ld1835 = load i64, ptr %p1834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1835, ptr %slot266, align 8
  %v1836 = load i64, ptr %slot266, align 8
  %cmp1837 = icmp ne i64 %v1836, 0
  %cv1838 = zext i1 %cmp1837 to i32
  store i32 %cv1838, ptr %slot267, align 8
  %v1839 = load i32, ptr %slot267, align 8
  %cv1840 = zext i32 %v1839 to i64
  %cond1841 = icmp ne i64 %cv1840, 0
  br i1 %cond1841, label %bb_rcgnn332, label %bb_rcgdone332
bb_rcgnn332:
  %v1842 = load i64, ptr %slot266, align 8
  %op1843 = sub i64 %v1842, 16
  store i64 %op1843, ptr %slot268, align 8
  %v1844 = load i64, ptr %slot266, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %rgep1846 = getelementptr i8, ptr %p1845, i64 -16
  %ld1847 = load i64, ptr %rgep1846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1847, ptr %slot269, align 8
  %v1848 = load i64, ptr %slot269, align 8
  %op1849 = and i64 %v1848, 4611686018427387906
  store i64 %op1849, ptr %slot270, align 8
  %v1850 = load i64, ptr %slot270, align 8
  %cmp1851 = icmp ne i64 %v1850, 0
  %cv1852 = zext i1 %cmp1851 to i32
  store i32 %cv1852, ptr %slot271, align 8
  %v1853 = load i32, ptr %slot271, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rcgclear332, label %bb_rcgcounted332
bb_rcgcounted332:
  %v1856 = load i64, ptr %slot266, align 8
  %op1857 = sub i64 %v1856, 32
  store i64 %op1857, ptr %slot272, align 8
  %v1858 = load i64, ptr %slot266, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %rgep1860 = getelementptr i8, ptr %p1859, i64 -32
  %ld1861 = load i64, ptr %rgep1860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1861, ptr %slot273, align 8
  %v1862 = load i64, ptr %slot273, align 8
  %op1863 = sub i64 %v1862, 1
  store i64 %op1863, ptr %slot274, align 8
  %v1864 = load i64, ptr %slot274, align 8
  %cmp1865 = icmp eq i64 %v1864, 0
  %cv1866 = zext i1 %cmp1865 to i32
  store i32 %cv1866, ptr %slot275, align 8
  %v1867 = load i32, ptr %slot275, align 8
  %cv1868 = zext i32 %v1867 to i64
  %cond1869 = icmp ne i64 %cv1868, 0
  br i1 %cond1869, label %bb_rcglast332, label %bb_rcgdec332
bb_rcglast332:
  %v1870 = load i64, ptr %slot266, align 8
  %op1871 = sub i64 %v1870, 24
  store i64 %op1871, ptr %slot276, align 8
  %v1872 = load i64, ptr %slot266, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %rgep1874 = getelementptr i8, ptr %p1873, i64 -24
  %ld1875 = load i64, ptr %rgep1874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1875, ptr %slot277, align 8
  %v1876 = load i64, ptr %slot277, align 8
  %cmp1877 = icmp ne i64 %v1876, 0
  %cv1878 = zext i1 %cmp1877 to i32
  store i32 %cv1878, ptr %slot278, align 8
  %v1879 = load i32, ptr %slot278, align 8
  %cv1880 = zext i32 %v1879 to i64
  %cond1881 = icmp ne i64 %cv1880, 0
  br i1 %cond1881, label %bb_rcgdec332, label %bb_rcgslow332
bb_rcgslow332:
  %v1882 = load i64, ptr %slot265, align 8
  %v1883 = load i64, ptr %slot248, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1882, i64 %v1883) nomerge, !dbg !116
  br label %bb_rcgdone332
bb_rcgdec332:
  %v1884 = load i64, ptr %slot274, align 8
  %v1885 = load i64, ptr %slot266, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  %rgep1887 = getelementptr i8, ptr %p1886, i64 -32
  store i64 %v1884, ptr %rgep1887, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear332
bb_rcgclear332:
  %v1888 = load i64, ptr %slot248, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i64 0, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone332
bb_rcgdone332:
  br label %bb_rcslotdone301
bb_rcslotdone301:
  %v1890 = load i64, ptr %slot17, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %ld1892 = load i64, ptr %p1891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1892, ptr %slot279, align 8
  %v1893 = load i64, ptr %slot279, align 8
  %v1894 = load i64, ptr %slot19, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 %v1893, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot19, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i64, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1898, ptr %slot280, align 8
  %v1899 = load i64, ptr %slot1, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %v1901 = load i64, ptr %slot280, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  %call1903 = call ptr @myl_qbe_bytes_from_list(ptr %p1900, ptr %p1902) nomerge, !dbg !118
  %calladdr1904 = ptrtoint ptr %call1903 to i64
  store i64 %calladdr1904, ptr %slot281, align 8
  %v1905 = load i64, ptr %slot281, align 8
  %v1906 = load i64, ptr %slot19, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i64 %v1905, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot19, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %ld1910 = load i64, ptr %p1909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1910, ptr %slot282, align 8
  %v1911 = load i64, ptr %slot282, align 8
  %v1912 = load i64, ptr %slot14, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  store i64 %v1911, ptr %p1913, align 8, !alias.scope !3, !noalias !4
  %v1914 = load i64, ptr %slot14, align 8
  store i64 %v1914, ptr %slot283, align 8
  %v1915 = load i64, ptr %slot15, align 8
  store i64 %v1915, ptr %slot284, align 8
  %v1916 = load i64, ptr %slot283, align 8
  %v1917 = load i64, ptr %slot284, align 8
  %p1918 = inttoptr i64 %v1916 to ptr
  %p1919 = inttoptr i64 %v1917 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1919, ptr %p1918, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1920 = load i64, ptr %slot12, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i32 2, ptr %p1921, align 4, !alias.scope !3, !noalias !4
  %v1922 = load i64, ptr %slot11, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i32 1, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot9, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i32, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1926, ptr %slot285, align 8
  %v1927 = load i32, ptr %slot285, align 8
  %cv1928 = zext i32 %v1927 to i64
  %cond1929 = icmp ne i64 %cv1928, 0
  br i1 %cond1929, label %bb_rcslotdrop346, label %bb_rcslotdone346
bb_rcslotdrop346:
  %v1930 = load i64, ptr %slot9, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  store i32 0, ptr %p1931, align 4, !alias.scope !3, !noalias !4
  %v1932 = load i64, ptr %slot13, align 8
  store i64 %v1932, ptr %slot286, align 8
  %v1933 = load i64, ptr %slot10, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i32, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1935, ptr %slot287, align 8
  %v1936 = load i32, ptr %slot287, align 8
  %op1937 = and i32 %v1936, 28
  store i32 %op1937, ptr %slot288, align 8
  %v1938 = load i32, ptr %slot288, align 8
  %cv1939 = zext i32 %v1938 to i64
  %cond1940 = icmp ne i64 %cv1939, 0
  br i1 %cond1940, label %bb_rcslotrole346, label %bb_rcslotowner346
bb_rcslotrole346:
  %v1941 = load i64, ptr %slot20, align 8
  store i64 %v1941, ptr %slot289, align 8
  %v1942 = load i64, ptr %slot286, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i64, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1944, ptr %slot290, align 8
  %v1945 = load i64, ptr %slot290, align 8
  %cmp1946 = icmp ne i64 %v1945, 0
  %cv1947 = zext i1 %cmp1946 to i32
  store i32 %cv1947, ptr %slot291, align 8
  %v1948 = load i32, ptr %slot291, align 8
  %cv1949 = zext i32 %v1948 to i64
  %cond1950 = icmp ne i64 %cv1949, 0
  br i1 %cond1950, label %bb_rcgnn362, label %bb_rcgdone362
bb_rcgnn362:
  %v1951 = load i64, ptr %slot290, align 8
  %op1952 = sub i64 %v1951, 16
  store i64 %op1952, ptr %slot292, align 8
  %v1953 = load i64, ptr %slot290, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %rgep1955 = getelementptr i8, ptr %p1954, i64 -16
  %ld1956 = load i64, ptr %rgep1955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1956, ptr %slot293, align 8
  %v1957 = load i64, ptr %slot293, align 8
  %op1958 = and i64 %v1957, 4611686018427387906
  store i64 %op1958, ptr %slot294, align 8
  %v1959 = load i64, ptr %slot294, align 8
  %cmp1960 = icmp ne i64 %v1959, 0
  %cv1961 = zext i1 %cmp1960 to i32
  store i32 %cv1961, ptr %slot295, align 8
  %v1962 = load i32, ptr %slot295, align 8
  %cv1963 = zext i32 %v1962 to i64
  %cond1964 = icmp ne i64 %cv1963, 0
  br i1 %cond1964, label %bb_rcgclear362, label %bb_rcgcounted362
bb_rcgcounted362:
  %v1965 = load i64, ptr %slot290, align 8
  %op1966 = sub i64 %v1965, 24
  store i64 %op1966, ptr %slot296, align 8
  %v1967 = load i64, ptr %slot290, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %rgep1969 = getelementptr i8, ptr %p1968, i64 -24
  %ld1970 = load i64, ptr %rgep1969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1970, ptr %slot297, align 8
  %v1971 = load i64, ptr %slot297, align 8
  %op1972 = sub i64 %v1971, 1
  store i64 %op1972, ptr %slot298, align 8
  %v1973 = load i64, ptr %slot298, align 8
  %cmp1974 = icmp eq i64 %v1973, 0
  %cv1975 = zext i1 %cmp1974 to i32
  store i32 %cv1975, ptr %slot299, align 8
  %v1976 = load i32, ptr %slot299, align 8
  %cv1977 = zext i32 %v1976 to i64
  %cond1978 = icmp ne i64 %cv1977, 0
  br i1 %cond1978, label %bb_rcglast362, label %bb_rcgdec362
bb_rcglast362:
  %v1979 = load i64, ptr %slot290, align 8
  %op1980 = sub i64 %v1979, 32
  store i64 %op1980, ptr %slot300, align 8
  %v1981 = load i64, ptr %slot290, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %rgep1983 = getelementptr i8, ptr %p1982, i64 -32
  %ld1984 = load i64, ptr %rgep1983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1984, ptr %slot301, align 8
  %v1985 = load i64, ptr %slot301, align 8
  %cmp1986 = icmp ne i64 %v1985, 0
  %cv1987 = zext i1 %cmp1986 to i32
  store i32 %cv1987, ptr %slot302, align 8
  %v1988 = load i32, ptr %slot302, align 8
  %cv1989 = zext i32 %v1988 to i64
  %cond1990 = icmp ne i64 %cv1989, 0
  br i1 %cond1990, label %bb_rcgdec362, label %bb_rcgslow362
bb_rcgslow362:
  %v1991 = load i64, ptr %slot289, align 8
  %v1992 = load i64, ptr %slot286, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1991, i64 %v1992) nomerge, !dbg !118
  br label %bb_rcgdone362
bb_rcgdec362:
  %v1993 = load i64, ptr %slot298, align 8
  %v1994 = load i64, ptr %slot290, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  %rgep1996 = getelementptr i8, ptr %p1995, i64 -24
  store i64 %v1993, ptr %rgep1996, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear362
bb_rcgclear362:
  %v1997 = load i64, ptr %slot286, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i64 0, ptr %p1998, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone362
bb_rcgdone362:
  br label %bb_rcslotdone346
bb_rcslotowner346:
  %v1999 = load i64, ptr %slot20, align 8
  store i64 %v1999, ptr %slot303, align 8
  %v2000 = load i64, ptr %slot286, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  %ld2002 = load i64, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2002, ptr %slot304, align 8
  %v2003 = load i64, ptr %slot304, align 8
  %cmp2004 = icmp ne i64 %v2003, 0
  %cv2005 = zext i1 %cmp2004 to i32
  store i32 %cv2005, ptr %slot305, align 8
  %v2006 = load i32, ptr %slot305, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcgnn377, label %bb_rcgdone377
bb_rcgnn377:
  %v2009 = load i64, ptr %slot304, align 8
  %op2010 = sub i64 %v2009, 16
  store i64 %op2010, ptr %slot306, align 8
  %v2011 = load i64, ptr %slot304, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %rgep2013 = getelementptr i8, ptr %p2012, i64 -16
  %ld2014 = load i64, ptr %rgep2013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2014, ptr %slot307, align 8
  %v2015 = load i64, ptr %slot307, align 8
  %op2016 = and i64 %v2015, 4611686018427387906
  store i64 %op2016, ptr %slot308, align 8
  %v2017 = load i64, ptr %slot308, align 8
  %cmp2018 = icmp ne i64 %v2017, 0
  %cv2019 = zext i1 %cmp2018 to i32
  store i32 %cv2019, ptr %slot309, align 8
  %v2020 = load i32, ptr %slot309, align 8
  %cv2021 = zext i32 %v2020 to i64
  %cond2022 = icmp ne i64 %cv2021, 0
  br i1 %cond2022, label %bb_rcgclear377, label %bb_rcgcounted377
bb_rcgcounted377:
  %v2023 = load i64, ptr %slot304, align 8
  %op2024 = sub i64 %v2023, 32
  store i64 %op2024, ptr %slot310, align 8
  %v2025 = load i64, ptr %slot304, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %rgep2027 = getelementptr i8, ptr %p2026, i64 -32
  %ld2028 = load i64, ptr %rgep2027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2028, ptr %slot311, align 8
  %v2029 = load i64, ptr %slot311, align 8
  %op2030 = sub i64 %v2029, 1
  store i64 %op2030, ptr %slot312, align 8
  %v2031 = load i64, ptr %slot312, align 8
  %cmp2032 = icmp eq i64 %v2031, 0
  %cv2033 = zext i1 %cmp2032 to i32
  store i32 %cv2033, ptr %slot313, align 8
  %v2034 = load i32, ptr %slot313, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcglast377, label %bb_rcgdec377
bb_rcglast377:
  %v2037 = load i64, ptr %slot304, align 8
  %op2038 = sub i64 %v2037, 24
  store i64 %op2038, ptr %slot314, align 8
  %v2039 = load i64, ptr %slot304, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %rgep2041 = getelementptr i8, ptr %p2040, i64 -24
  %ld2042 = load i64, ptr %rgep2041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2042, ptr %slot315, align 8
  %v2043 = load i64, ptr %slot315, align 8
  %cmp2044 = icmp ne i64 %v2043, 0
  %cv2045 = zext i1 %cmp2044 to i32
  store i32 %cv2045, ptr %slot316, align 8
  %v2046 = load i32, ptr %slot316, align 8
  %cv2047 = zext i32 %v2046 to i64
  %cond2048 = icmp ne i64 %cv2047, 0
  br i1 %cond2048, label %bb_rcgdec377, label %bb_rcgslow377
bb_rcgslow377:
  %v2049 = load i64, ptr %slot303, align 8
  %v2050 = load i64, ptr %slot286, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2049, i64 %v2050) nomerge, !dbg !118
  br label %bb_rcgdone377
bb_rcgdec377:
  %v2051 = load i64, ptr %slot312, align 8
  %v2052 = load i64, ptr %slot304, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %rgep2054 = getelementptr i8, ptr %p2053, i64 -32
  store i64 %v2051, ptr %rgep2054, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear377
bb_rcgclear377:
  %v2055 = load i64, ptr %slot286, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 0, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone377
bb_rcgdone377:
  br label %bb_rcslotdone346
bb_rcslotdone346:
  %v2057 = load i64, ptr %slot13, align 8
  store i64 %v2057, ptr %slot317, align 8
  %v2058 = load i64, ptr %slot15, align 8
  store i64 %v2058, ptr %slot318, align 8
  %v2059 = load i64, ptr %slot318, align 8
  %v2060 = load i64, ptr %slot317, align 8
  %p2061 = inttoptr i64 %v2059 to ptr
  %p2062 = inttoptr i64 %v2060 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2062, ptr %p2061, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot10, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  store i32 2, ptr %p2064, align 4, !alias.scope !3, !noalias !4
  %v2065 = load i64, ptr %slot12, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  %ld2067 = load i32, ptr %p2066, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2067, ptr %slot319, align 8
  %v2068 = load i32, ptr %slot319, align 8
  %v2069 = load i64, ptr %slot10, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i32 %v2068, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot11, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i32 0, ptr %p2072, align 4, !alias.scope !3, !noalias !4
  %v2073 = load i64, ptr %slot9, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  store i32 1, ptr %p2074, align 4, !alias.scope !3, !noalias !4
  %v2075 = load i64, ptr %slot317, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %ld2077 = load i64, ptr %p2076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2077, ptr %slot320, align 8
  %v2078 = load i64, ptr %slot320, align 8
  %v2079 = load i64, ptr %slot19, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i64 %v2078, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot19, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  %ld2083 = load i64, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2083, ptr %slot321, align 8
  %v2084 = load i64, ptr %slot321, align 8
  %v2085 = load i64, ptr %slot14, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i64 %v2084, ptr %p2086, align 8, !alias.scope !3, !noalias !4
  %v2087 = load i64, ptr %slot14, align 8
  store i64 %v2087, ptr %slot322, align 8
  %v2088 = load i64, ptr %slot9, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i32, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2090, ptr %slot323, align 8
  %v2091 = load i64, ptr %slot10, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i32, ptr %p2092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2093, ptr %slot324, align 8
  %v2094 = load i32, ptr %slot324, align 8
  %op2095 = and i32 %v2094, 24
  store i32 %op2095, ptr %slot324, align 8
  %v2096 = load i32, ptr %slot324, align 8
  %cmp2097 = icmp eq i32 %v2096, 0
  %cv2098 = zext i1 %cmp2097 to i32
  store i32 %cv2098, ptr %slot325, align 8
  %v2099 = load i32, ptr %slot323, align 8
  %v2100 = load i32, ptr %slot325, align 8
  %op2101 = and i32 %v2099, %v2100
  store i32 %op2101, ptr %slot326, align 8
  %v2102 = load i32, ptr %slot326, align 8
  %cv2103 = zext i32 %v2102 to i64
  %cond2104 = icmp ne i64 %cv2103, 0
  br i1 %cond2104, label %bb_rctake392, label %bb_rccopy392
bb_rctake392:
  %v2105 = load i64, ptr %slot15, align 8
  store i64 %v2105, ptr %slot327, align 8
  %v2106 = load i64, ptr %slot21, align 8
  store i64 %v2106, ptr %slot328, align 8
  %v2107 = load i64, ptr %slot322, align 8
  %v2108 = load i64, ptr %slot327, align 8
  %op2109 = sub i64 %v2107, %v2108
  store i64 %op2109, ptr %slot329, align 8
  %v2110 = load i64, ptr %slot327, align 8
  %v2111 = load i64, ptr %slot322, align 8
  %op2112 = sub i64 %v2110, %v2111
  store i64 %op2112, ptr %slot330, align 8
  %v2113 = load i64, ptr %slot329, align 8
  %cmp2114 = icmp ult i64 %v2113, 8
  %cv2115 = zext i1 %cmp2114 to i32
  store i32 %cv2115, ptr %slot331, align 8
  %v2116 = load i64, ptr %slot330, align 8
  %cmp2117 = icmp ult i64 %v2116, 8
  %cv2118 = zext i1 %cmp2117 to i32
  store i32 %cv2118, ptr %slot332, align 8
  %v2119 = load i32, ptr %slot331, align 8
  %v2120 = load i32, ptr %slot332, align 8
  %op2121 = or i32 %v2119, %v2120
  store i32 %op2121, ptr %slot333, align 8
  %v2122 = load i32, ptr %slot333, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcmoveslow401, label %bb_rcmovecheck401
bb_rcmovecheck401:
  %v2125 = load i64, ptr %slot322, align 8
  %p2127 = inttoptr i64 %v2125 to ptr
  %gep2128 = getelementptr i8, ptr %p2127, i64 0
  %op2126 = ptrtoint ptr %gep2128 to i64
  store i64 %op2126, ptr %slot334, align 8
  %v2129 = load i64, ptr %slot334, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %ld2131 = load i64, ptr %p2130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2131, ptr %slot335, align 8
  %v2132 = load i64, ptr %slot335, align 8
  %cmp2133 = icmp ne i64 %v2132, 0
  %cv2134 = zext i1 %cmp2133 to i32
  store i32 %cv2134, ptr %slot336, align 8
  %v2135 = load i32, ptr %slot336, align 8
  %cv2136 = zext i32 %v2135 to i64
  %cond2137 = icmp ne i64 %cv2136, 0
  br i1 %cond2137, label %bb_rcmoveheader409, label %bb_rcmovenext409
bb_rcmoveheader409:
  %v2138 = load i64, ptr %slot335, align 8
  %op2139 = sub i64 %v2138, 16
  store i64 %op2139, ptr %slot337, align 8
  %v2140 = load i64, ptr %slot335, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %rgep2142 = getelementptr i8, ptr %p2141, i64 -16
  %ld2143 = load i64, ptr %rgep2142, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2143, ptr %slot338, align 8
  %v2144 = load i64, ptr %slot338, align 8
  %op2145 = and i64 %v2144, 5764607523034234881
  store i64 %op2145, ptr %slot339, align 8
  %v2146 = load i64, ptr %slot339, align 8
  %cmp2147 = icmp ne i64 %v2146, 0
  %cv2148 = zext i1 %cmp2147 to i32
  store i32 %cv2148, ptr %slot340, align 8
  %v2149 = load i32, ptr %slot340, align 8
  %cv2150 = zext i32 %v2149 to i64
  %cond2151 = icmp ne i64 %cv2150, 0
  br i1 %cond2151, label %bb_rcmoveslow401, label %bb_rcmovenext409
bb_rcmovenext409:
  %v2152 = load i64, ptr %slot322, align 8
  %v2153 = load i64, ptr %slot327, align 8
  %p2154 = inttoptr i64 %v2152 to ptr
  %p2155 = inttoptr i64 %v2153 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2155, ptr %p2154, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2156 = load i64, ptr %slot322, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  store i64 0, ptr %p2157, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved401
bb_rcmoveslow401:
  %v2158 = load i64, ptr %slot20, align 8
  %v2159 = load i64, ptr %slot327, align 8
  %v2160 = load i64, ptr %slot322, align 8
  %v2161 = load i64, ptr %slot328, align 8
  %cv2162 = trunc i64 %v2161 to i32
  %call2163 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v2158, i64 %v2159, i64 %v2160, i32 %cv2162) nomerge, !dbg !120
  store i32 %call2163, ptr %slot341, align 8
  %v2164 = load i32, ptr %slot341, align 8
  %cv2165 = zext i32 %v2164 to i64
  %cond2166 = icmp ne i64 %cv2165, 0
  br i1 %cond2166, label %bb_rcsuccess416, label %bb_rcfailure416
bb_rcfailure416:
  %v2167 = load i64, ptr %slot20, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %call2169 = call i32 @myl_rc_take_failure(ptr %p2168) nomerge, !dbg !120
  store i32 %call2169, ptr %slot342, align 8
  %v2170 = load i64, ptr %slot1, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %v2172 = load i32, ptr %slot342, align 8
  %call2173 = call i32 @myl_qbe_rc_status(ptr %p2171, i32 %v2172) nomerge, !dbg !120
  store i32 %call2173, ptr %slot343, align 8
  br label %bb_failure
bb_rcsuccess416:
  br label %bb_rcmoved401
bb_rcmoved401:
  %v2174 = load i64, ptr %slot9, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 0, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot12, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  store i32 2, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  %v2178 = load i64, ptr %slot11, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  store i32 1, ptr %p2179, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared392
bb_rccopy392:
  %v2180 = load i64, ptr %slot15, align 8
  store i64 %v2180, ptr %slot344, align 8
  %v2181 = load i64, ptr %slot21, align 8
  store i64 %v2181, ptr %slot345, align 8
  %v2182 = load i64, ptr %slot322, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %ld2184 = load i64, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2184, ptr %slot346, align 8
  %v2185 = load i64, ptr %slot346, align 8
  %cmp2186 = icmp ne i64 %v2185, 0
  %cv2187 = zext i1 %cmp2186 to i32
  store i32 %cv2187, ptr %slot347, align 8
  %v2188 = load i32, ptr %slot347, align 8
  %cv2189 = zext i32 %v2188 to i64
  %cond2190 = icmp ne i64 %cv2189, 0
  br i1 %cond2190, label %bb_rcgnn425, label %bb_rcgplain425
bb_rcgnn425:
  %v2191 = load i64, ptr %slot346, align 8
  %op2192 = sub i64 %v2191, 16
  store i64 %op2192, ptr %slot348, align 8
  %v2193 = load i64, ptr %slot346, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %rgep2195 = getelementptr i8, ptr %p2194, i64 -16
  %ld2196 = load i64, ptr %rgep2195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2196, ptr %slot349, align 8
  %v2197 = load i64, ptr %slot349, align 8
  %op2198 = and i64 %v2197, 4611686018427387906
  store i64 %op2198, ptr %slot350, align 8
  %v2199 = load i64, ptr %slot350, align 8
  %cmp2200 = icmp ne i64 %v2199, 0
  %cv2201 = zext i1 %cmp2200 to i32
  store i32 %cv2201, ptr %slot351, align 8
  %v2202 = load i32, ptr %slot351, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rcgspecial425, label %bb_rcginc425
bb_rcginc425:
  %v2205 = load i64, ptr %slot346, align 8
  %op2206 = sub i64 %v2205, 32
  store i64 %op2206, ptr %slot352, align 8
  %v2207 = load i64, ptr %slot346, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %rgep2209 = getelementptr i8, ptr %p2208, i64 -32
  %ld2210 = load i64, ptr %rgep2209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2210, ptr %slot353, align 8
  %v2211 = load i64, ptr %slot353, align 8
  %op2212 = add i64 %v2211, 1
  store i64 %op2212, ptr %slot354, align 8
  %v2213 = load i64, ptr %slot354, align 8
  %cmp2214 = icmp eq i64 %v2213, 0
  %cv2215 = zext i1 %cmp2214 to i32
  store i32 %cv2215, ptr %slot355, align 8
  %v2216 = load i32, ptr %slot355, align 8
  %cv2217 = zext i32 %v2216 to i64
  %cond2218 = icmp ne i64 %cv2217, 0
  br i1 %cond2218, label %bb_rcglimit425, label %bb_rcgcapacity425
bb_rcglimit425:
  %v2219 = load i64, ptr %slot1, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  %call2221 = call i32 @myl_qbe_rc_status(ptr %p2220, i32 2) nomerge, !dbg !120
  store i32 %call2221, ptr %slot356, align 8
  br label %bb_failure
bb_rcgcapacity425:
  %v2222 = load i64, ptr %slot354, align 8
  %v2223 = load i64, ptr %slot346, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %rgep2225 = getelementptr i8, ptr %p2224, i64 -32
  store i64 %v2222, ptr %rgep2225, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain425
bb_rcgspecial425:
  %v2226 = load i64, ptr %slot349, align 8
  %op2227 = and i64 %v2226, 4611686018427387904
  store i64 %op2227, ptr %slot357, align 8
  %v2228 = load i64, ptr %slot357, align 8
  %cmp2229 = icmp ne i64 %v2228, 0
  %cv2230 = zext i1 %cmp2229 to i32
  store i32 %cv2230, ptr %slot358, align 8
  %v2231 = load i32, ptr %slot358, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcgslow425, label %bb_rcgplain425
bb_rcgslow425:
  %v2234 = load i64, ptr %slot20, align 8
  %v2235 = load i64, ptr %slot344, align 8
  %v2236 = load i64, ptr %slot322, align 8
  %v2237 = load i64, ptr %slot345, align 8
  %cv2238 = trunc i64 %v2237 to i32
  %call2239 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v2234, i64 %v2235, i64 %v2236, i32 %cv2238) nomerge, !dbg !120
  store i32 %call2239, ptr %slot359, align 8
  %v2240 = load i32, ptr %slot359, align 8
  %cv2241 = zext i32 %v2240 to i64
  %cond2242 = icmp ne i64 %cv2241, 0
  br i1 %cond2242, label %bb_rcsuccess439, label %bb_rcfailure439
bb_rcfailure439:
  %v2243 = load i64, ptr %slot20, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  %call2245 = call i32 @myl_rc_take_failure(ptr %p2244) nomerge, !dbg !120
  store i32 %call2245, ptr %slot360, align 8
  %v2246 = load i64, ptr %slot1, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %v2248 = load i32, ptr %slot360, align 8
  %call2249 = call i32 @myl_qbe_rc_status(ptr %p2247, i32 %v2248) nomerge, !dbg !120
  store i32 %call2249, ptr %slot361, align 8
  br label %bb_failure
bb_rcsuccess439:
  br label %bb_rcgdone425
bb_rcgplain425:
  %v2250 = load i64, ptr %slot346, align 8
  %v2251 = load i64, ptr %slot344, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i64 %v2250, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone425
bb_rcgdone425:
  %v2253 = load i64, ptr %slot12, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i32 2, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot11, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i32 1, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot9, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  %ld2259 = load i32, ptr %p2258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2259, ptr %slot362, align 8
  %v2260 = load i32, ptr %slot362, align 8
  %cv2261 = zext i32 %v2260 to i64
  %cond2262 = icmp ne i64 %cv2261, 0
  br i1 %cond2262, label %bb_rcslotdrop446, label %bb_rcslotdone446
bb_rcslotdrop446:
  %v2263 = load i64, ptr %slot9, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i32 0, ptr %p2264, align 4, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot13, align 8
  store i64 %v2265, ptr %slot363, align 8
  %v2266 = load i64, ptr %slot10, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %ld2268 = load i32, ptr %p2267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2268, ptr %slot364, align 8
  %v2269 = load i32, ptr %slot364, align 8
  %op2270 = and i32 %v2269, 28
  store i32 %op2270, ptr %slot365, align 8
  %v2271 = load i32, ptr %slot365, align 8
  %cv2272 = zext i32 %v2271 to i64
  %cond2273 = icmp ne i64 %cv2272, 0
  br i1 %cond2273, label %bb_rcslotrole446, label %bb_rcslotowner446
bb_rcslotrole446:
  %v2274 = load i64, ptr %slot20, align 8
  store i64 %v2274, ptr %slot366, align 8
  %v2275 = load i64, ptr %slot363, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %ld2277 = load i64, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2277, ptr %slot367, align 8
  %v2278 = load i64, ptr %slot367, align 8
  %cmp2279 = icmp ne i64 %v2278, 0
  %cv2280 = zext i1 %cmp2279 to i32
  store i32 %cv2280, ptr %slot368, align 8
  %v2281 = load i32, ptr %slot368, align 8
  %cv2282 = zext i32 %v2281 to i64
  %cond2283 = icmp ne i64 %cv2282, 0
  br i1 %cond2283, label %bb_rcgnn462, label %bb_rcgdone462
bb_rcgnn462:
  %v2284 = load i64, ptr %slot367, align 8
  %op2285 = sub i64 %v2284, 16
  store i64 %op2285, ptr %slot369, align 8
  %v2286 = load i64, ptr %slot367, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %rgep2288 = getelementptr i8, ptr %p2287, i64 -16
  %ld2289 = load i64, ptr %rgep2288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2289, ptr %slot370, align 8
  %v2290 = load i64, ptr %slot370, align 8
  %op2291 = and i64 %v2290, 4611686018427387906
  store i64 %op2291, ptr %slot371, align 8
  %v2292 = load i64, ptr %slot371, align 8
  %cmp2293 = icmp ne i64 %v2292, 0
  %cv2294 = zext i1 %cmp2293 to i32
  store i32 %cv2294, ptr %slot372, align 8
  %v2295 = load i32, ptr %slot372, align 8
  %cv2296 = zext i32 %v2295 to i64
  %cond2297 = icmp ne i64 %cv2296, 0
  br i1 %cond2297, label %bb_rcgclear462, label %bb_rcgcounted462
bb_rcgcounted462:
  %v2298 = load i64, ptr %slot367, align 8
  %op2299 = sub i64 %v2298, 24
  store i64 %op2299, ptr %slot373, align 8
  %v2300 = load i64, ptr %slot367, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %rgep2302 = getelementptr i8, ptr %p2301, i64 -24
  %ld2303 = load i64, ptr %rgep2302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2303, ptr %slot374, align 8
  %v2304 = load i64, ptr %slot374, align 8
  %op2305 = sub i64 %v2304, 1
  store i64 %op2305, ptr %slot375, align 8
  %v2306 = load i64, ptr %slot375, align 8
  %cmp2307 = icmp eq i64 %v2306, 0
  %cv2308 = zext i1 %cmp2307 to i32
  store i32 %cv2308, ptr %slot376, align 8
  %v2309 = load i32, ptr %slot376, align 8
  %cv2310 = zext i32 %v2309 to i64
  %cond2311 = icmp ne i64 %cv2310, 0
  br i1 %cond2311, label %bb_rcglast462, label %bb_rcgdec462
bb_rcglast462:
  %v2312 = load i64, ptr %slot367, align 8
  %op2313 = sub i64 %v2312, 32
  store i64 %op2313, ptr %slot377, align 8
  %v2314 = load i64, ptr %slot367, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %rgep2316 = getelementptr i8, ptr %p2315, i64 -32
  %ld2317 = load i64, ptr %rgep2316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2317, ptr %slot378, align 8
  %v2318 = load i64, ptr %slot378, align 8
  %cmp2319 = icmp ne i64 %v2318, 0
  %cv2320 = zext i1 %cmp2319 to i32
  store i32 %cv2320, ptr %slot379, align 8
  %v2321 = load i32, ptr %slot379, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcgdec462, label %bb_rcgslow462
bb_rcgslow462:
  %v2324 = load i64, ptr %slot366, align 8
  %v2325 = load i64, ptr %slot363, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2324, i64 %v2325) nomerge, !dbg !120
  br label %bb_rcgdone462
bb_rcgdec462:
  %v2326 = load i64, ptr %slot375, align 8
  %v2327 = load i64, ptr %slot367, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %rgep2329 = getelementptr i8, ptr %p2328, i64 -24
  store i64 %v2326, ptr %rgep2329, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear462
bb_rcgclear462:
  %v2330 = load i64, ptr %slot363, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  store i64 0, ptr %p2331, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone462
bb_rcgdone462:
  br label %bb_rcslotdone446
bb_rcslotowner446:
  %v2332 = load i64, ptr %slot20, align 8
  store i64 %v2332, ptr %slot380, align 8
  %v2333 = load i64, ptr %slot363, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i64, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2335, ptr %slot381, align 8
  %v2336 = load i64, ptr %slot381, align 8
  %cmp2337 = icmp ne i64 %v2336, 0
  %cv2338 = zext i1 %cmp2337 to i32
  store i32 %cv2338, ptr %slot382, align 8
  %v2339 = load i32, ptr %slot382, align 8
  %cv2340 = zext i32 %v2339 to i64
  %cond2341 = icmp ne i64 %cv2340, 0
  br i1 %cond2341, label %bb_rcgnn477, label %bb_rcgdone477
bb_rcgnn477:
  %v2342 = load i64, ptr %slot381, align 8
  %op2343 = sub i64 %v2342, 16
  store i64 %op2343, ptr %slot383, align 8
  %v2344 = load i64, ptr %slot381, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  %rgep2346 = getelementptr i8, ptr %p2345, i64 -16
  %ld2347 = load i64, ptr %rgep2346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2347, ptr %slot384, align 8
  %v2348 = load i64, ptr %slot384, align 8
  %op2349 = and i64 %v2348, 4611686018427387906
  store i64 %op2349, ptr %slot385, align 8
  %v2350 = load i64, ptr %slot385, align 8
  %cmp2351 = icmp ne i64 %v2350, 0
  %cv2352 = zext i1 %cmp2351 to i32
  store i32 %cv2352, ptr %slot386, align 8
  %v2353 = load i32, ptr %slot386, align 8
  %cv2354 = zext i32 %v2353 to i64
  %cond2355 = icmp ne i64 %cv2354, 0
  br i1 %cond2355, label %bb_rcgclear477, label %bb_rcgcounted477
bb_rcgcounted477:
  %v2356 = load i64, ptr %slot381, align 8
  %op2357 = sub i64 %v2356, 32
  store i64 %op2357, ptr %slot387, align 8
  %v2358 = load i64, ptr %slot381, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %rgep2360 = getelementptr i8, ptr %p2359, i64 -32
  %ld2361 = load i64, ptr %rgep2360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2361, ptr %slot388, align 8
  %v2362 = load i64, ptr %slot388, align 8
  %op2363 = sub i64 %v2362, 1
  store i64 %op2363, ptr %slot389, align 8
  %v2364 = load i64, ptr %slot389, align 8
  %cmp2365 = icmp eq i64 %v2364, 0
  %cv2366 = zext i1 %cmp2365 to i32
  store i32 %cv2366, ptr %slot390, align 8
  %v2367 = load i32, ptr %slot390, align 8
  %cv2368 = zext i32 %v2367 to i64
  %cond2369 = icmp ne i64 %cv2368, 0
  br i1 %cond2369, label %bb_rcglast477, label %bb_rcgdec477
bb_rcglast477:
  %v2370 = load i64, ptr %slot381, align 8
  %op2371 = sub i64 %v2370, 24
  store i64 %op2371, ptr %slot391, align 8
  %v2372 = load i64, ptr %slot381, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %rgep2374 = getelementptr i8, ptr %p2373, i64 -24
  %ld2375 = load i64, ptr %rgep2374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2375, ptr %slot392, align 8
  %v2376 = load i64, ptr %slot392, align 8
  %cmp2377 = icmp ne i64 %v2376, 0
  %cv2378 = zext i1 %cmp2377 to i32
  store i32 %cv2378, ptr %slot393, align 8
  %v2379 = load i32, ptr %slot393, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcgdec477, label %bb_rcgslow477
bb_rcgslow477:
  %v2382 = load i64, ptr %slot380, align 8
  %v2383 = load i64, ptr %slot363, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2382, i64 %v2383) nomerge, !dbg !120
  br label %bb_rcgdone477
bb_rcgdec477:
  %v2384 = load i64, ptr %slot389, align 8
  %v2385 = load i64, ptr %slot381, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %rgep2387 = getelementptr i8, ptr %p2386, i64 -32
  store i64 %v2384, ptr %rgep2387, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear477
bb_rcgclear477:
  %v2388 = load i64, ptr %slot363, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  store i64 0, ptr %p2389, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone477
bb_rcgdone477:
  br label %bb_rcslotdone446
bb_rcslotdone446:
  br label %bb_rcprepared392
bb_rcprepared392:
  %v2390 = load i64, ptr %slot7, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %ld2392 = load i32, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2392, ptr %slot394, align 8
  %v2393 = load i32, ptr %slot394, align 8
  %cv2394 = zext i32 %v2393 to i64
  %cond2395 = icmp ne i64 %cv2394, 0
  br i1 %cond2395, label %bb_rcslotdrop484, label %bb_rcslotdone484
bb_rcslotdrop484:
  %v2396 = load i64, ptr %slot7, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  store i32 0, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  %v2398 = load i64, ptr %slot18, align 8
  store i64 %v2398, ptr %slot395, align 8
  %v2399 = load i64, ptr %slot8, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i32, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2401, ptr %slot396, align 8
  %v2402 = load i32, ptr %slot396, align 8
  %op2403 = and i32 %v2402, 28
  store i32 %op2403, ptr %slot397, align 8
  %v2404 = load i32, ptr %slot397, align 8
  %cv2405 = zext i32 %v2404 to i64
  %cond2406 = icmp ne i64 %cv2405, 0
  br i1 %cond2406, label %bb_rcslotrole484, label %bb_rcslotowner484
bb_rcslotrole484:
  %v2407 = load i64, ptr %slot20, align 8
  store i64 %v2407, ptr %slot398, align 8
  %v2408 = load i64, ptr %slot395, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %ld2410 = load i64, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2410, ptr %slot399, align 8
  %v2411 = load i64, ptr %slot399, align 8
  %cmp2412 = icmp ne i64 %v2411, 0
  %cv2413 = zext i1 %cmp2412 to i32
  store i32 %cv2413, ptr %slot400, align 8
  %v2414 = load i32, ptr %slot400, align 8
  %cv2415 = zext i32 %v2414 to i64
  %cond2416 = icmp ne i64 %cv2415, 0
  br i1 %cond2416, label %bb_rcgnn500, label %bb_rcgdone500
bb_rcgnn500:
  %v2417 = load i64, ptr %slot399, align 8
  %op2418 = sub i64 %v2417, 16
  store i64 %op2418, ptr %slot401, align 8
  %v2419 = load i64, ptr %slot399, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %rgep2421 = getelementptr i8, ptr %p2420, i64 -16
  %ld2422 = load i64, ptr %rgep2421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2422, ptr %slot402, align 8
  %v2423 = load i64, ptr %slot402, align 8
  %op2424 = and i64 %v2423, 4611686018427387906
  store i64 %op2424, ptr %slot403, align 8
  %v2425 = load i64, ptr %slot403, align 8
  %cmp2426 = icmp ne i64 %v2425, 0
  %cv2427 = zext i1 %cmp2426 to i32
  store i32 %cv2427, ptr %slot404, align 8
  %v2428 = load i32, ptr %slot404, align 8
  %cv2429 = zext i32 %v2428 to i64
  %cond2430 = icmp ne i64 %cv2429, 0
  br i1 %cond2430, label %bb_rcgclear500, label %bb_rcgcounted500
bb_rcgcounted500:
  %v2431 = load i64, ptr %slot399, align 8
  %op2432 = sub i64 %v2431, 24
  store i64 %op2432, ptr %slot405, align 8
  %v2433 = load i64, ptr %slot399, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  %rgep2435 = getelementptr i8, ptr %p2434, i64 -24
  %ld2436 = load i64, ptr %rgep2435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2436, ptr %slot406, align 8
  %v2437 = load i64, ptr %slot406, align 8
  %op2438 = sub i64 %v2437, 1
  store i64 %op2438, ptr %slot407, align 8
  %v2439 = load i64, ptr %slot407, align 8
  %cmp2440 = icmp eq i64 %v2439, 0
  %cv2441 = zext i1 %cmp2440 to i32
  store i32 %cv2441, ptr %slot408, align 8
  %v2442 = load i32, ptr %slot408, align 8
  %cv2443 = zext i32 %v2442 to i64
  %cond2444 = icmp ne i64 %cv2443, 0
  br i1 %cond2444, label %bb_rcglast500, label %bb_rcgdec500
bb_rcglast500:
  %v2445 = load i64, ptr %slot399, align 8
  %op2446 = sub i64 %v2445, 32
  store i64 %op2446, ptr %slot409, align 8
  %v2447 = load i64, ptr %slot399, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  %rgep2449 = getelementptr i8, ptr %p2448, i64 -32
  %ld2450 = load i64, ptr %rgep2449, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2450, ptr %slot410, align 8
  %v2451 = load i64, ptr %slot410, align 8
  %cmp2452 = icmp ne i64 %v2451, 0
  %cv2453 = zext i1 %cmp2452 to i32
  store i32 %cv2453, ptr %slot411, align 8
  %v2454 = load i32, ptr %slot411, align 8
  %cv2455 = zext i32 %v2454 to i64
  %cond2456 = icmp ne i64 %cv2455, 0
  br i1 %cond2456, label %bb_rcgdec500, label %bb_rcgslow500
bb_rcgslow500:
  %v2457 = load i64, ptr %slot398, align 8
  %v2458 = load i64, ptr %slot395, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2457, i64 %v2458) nomerge, !dbg !120
  br label %bb_rcgdone500
bb_rcgdec500:
  %v2459 = load i64, ptr %slot407, align 8
  %v2460 = load i64, ptr %slot399, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %rgep2462 = getelementptr i8, ptr %p2461, i64 -24
  store i64 %v2459, ptr %rgep2462, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear500
bb_rcgclear500:
  %v2463 = load i64, ptr %slot395, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i64 0, ptr %p2464, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone500
bb_rcgdone500:
  br label %bb_rcslotdone484
bb_rcslotowner484:
  %v2465 = load i64, ptr %slot20, align 8
  store i64 %v2465, ptr %slot412, align 8
  %v2466 = load i64, ptr %slot395, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %ld2468 = load i64, ptr %p2467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2468, ptr %slot413, align 8
  %v2469 = load i64, ptr %slot413, align 8
  %cmp2470 = icmp ne i64 %v2469, 0
  %cv2471 = zext i1 %cmp2470 to i32
  store i32 %cv2471, ptr %slot414, align 8
  %v2472 = load i32, ptr %slot414, align 8
  %cv2473 = zext i32 %v2472 to i64
  %cond2474 = icmp ne i64 %cv2473, 0
  br i1 %cond2474, label %bb_rcgnn515, label %bb_rcgdone515
bb_rcgnn515:
  %v2475 = load i64, ptr %slot413, align 8
  %op2476 = sub i64 %v2475, 16
  store i64 %op2476, ptr %slot415, align 8
  %v2477 = load i64, ptr %slot413, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  %rgep2479 = getelementptr i8, ptr %p2478, i64 -16
  %ld2480 = load i64, ptr %rgep2479, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2480, ptr %slot416, align 8
  %v2481 = load i64, ptr %slot416, align 8
  %op2482 = and i64 %v2481, 4611686018427387906
  store i64 %op2482, ptr %slot417, align 8
  %v2483 = load i64, ptr %slot417, align 8
  %cmp2484 = icmp ne i64 %v2483, 0
  %cv2485 = zext i1 %cmp2484 to i32
  store i32 %cv2485, ptr %slot418, align 8
  %v2486 = load i32, ptr %slot418, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcgclear515, label %bb_rcgcounted515
bb_rcgcounted515:
  %v2489 = load i64, ptr %slot413, align 8
  %op2490 = sub i64 %v2489, 32
  store i64 %op2490, ptr %slot419, align 8
  %v2491 = load i64, ptr %slot413, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %rgep2493 = getelementptr i8, ptr %p2492, i64 -32
  %ld2494 = load i64, ptr %rgep2493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2494, ptr %slot420, align 8
  %v2495 = load i64, ptr %slot420, align 8
  %op2496 = sub i64 %v2495, 1
  store i64 %op2496, ptr %slot421, align 8
  %v2497 = load i64, ptr %slot421, align 8
  %cmp2498 = icmp eq i64 %v2497, 0
  %cv2499 = zext i1 %cmp2498 to i32
  store i32 %cv2499, ptr %slot422, align 8
  %v2500 = load i32, ptr %slot422, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcglast515, label %bb_rcgdec515
bb_rcglast515:
  %v2503 = load i64, ptr %slot413, align 8
  %op2504 = sub i64 %v2503, 24
  store i64 %op2504, ptr %slot423, align 8
  %v2505 = load i64, ptr %slot413, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -24
  %ld2508 = load i64, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2508, ptr %slot424, align 8
  %v2509 = load i64, ptr %slot424, align 8
  %cmp2510 = icmp ne i64 %v2509, 0
  %cv2511 = zext i1 %cmp2510 to i32
  store i32 %cv2511, ptr %slot425, align 8
  %v2512 = load i32, ptr %slot425, align 8
  %cv2513 = zext i32 %v2512 to i64
  %cond2514 = icmp ne i64 %cv2513, 0
  br i1 %cond2514, label %bb_rcgdec515, label %bb_rcgslow515
bb_rcgslow515:
  %v2515 = load i64, ptr %slot412, align 8
  %v2516 = load i64, ptr %slot395, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2515, i64 %v2516) nomerge, !dbg !120
  br label %bb_rcgdone515
bb_rcgdec515:
  %v2517 = load i64, ptr %slot421, align 8
  %v2518 = load i64, ptr %slot413, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  %rgep2520 = getelementptr i8, ptr %p2519, i64 -32
  store i64 %v2517, ptr %rgep2520, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear515
bb_rcgclear515:
  %v2521 = load i64, ptr %slot395, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i64 0, ptr %p2522, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone515
bb_rcgdone515:
  br label %bb_rcslotdone484
bb_rcslotdone484:
  %v2523 = load i64, ptr %slot18, align 8
  store i64 %v2523, ptr %slot426, align 8
  %v2524 = load i64, ptr %slot15, align 8
  store i64 %v2524, ptr %slot427, align 8
  %v2525 = load i64, ptr %slot427, align 8
  %v2526 = load i64, ptr %slot426, align 8
  %p2527 = inttoptr i64 %v2525 to ptr
  %p2528 = inttoptr i64 %v2526 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2528, ptr %p2527, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot11, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  store i32 0, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  %v2531 = load i64, ptr %slot8, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i32 2, ptr %p2532, align 4, !alias.scope !3, !noalias !4
  %v2533 = load i64, ptr %slot12, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i32, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2535, ptr %slot428, align 8
  %v2536 = load i32, ptr %slot428, align 8
  %v2537 = load i64, ptr %slot8, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 %v2536, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot7, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i32 1, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  %v2541 = load i64, ptr %slot5, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %ld2543 = load i32, ptr %p2542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2543, ptr %slot429, align 8
  %v2544 = load i32, ptr %slot429, align 8
  %cv2545 = zext i32 %v2544 to i64
  %cond2546 = icmp ne i64 %cv2545, 0
  br i1 %cond2546, label %bb_rcslotdrop528, label %bb_rcslotdone528
bb_rcslotdrop528:
  %v2547 = load i64, ptr %slot5, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i32 0, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot17, align 8
  store i64 %v2549, ptr %slot430, align 8
  %v2550 = load i64, ptr %slot6, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %ld2552 = load i32, ptr %p2551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2552, ptr %slot431, align 8
  %v2553 = load i32, ptr %slot431, align 8
  %op2554 = and i32 %v2553, 28
  store i32 %op2554, ptr %slot432, align 8
  %v2555 = load i32, ptr %slot432, align 8
  %cv2556 = zext i32 %v2555 to i64
  %cond2557 = icmp ne i64 %cv2556, 0
  br i1 %cond2557, label %bb_rcslotrole528, label %bb_rcslotowner528
bb_rcslotrole528:
  %v2558 = load i64, ptr %slot20, align 8
  store i64 %v2558, ptr %slot433, align 8
  %v2559 = load i64, ptr %slot430, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %ld2561 = load i64, ptr %p2560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2561, ptr %slot434, align 8
  %v2562 = load i64, ptr %slot434, align 8
  %cmp2563 = icmp ne i64 %v2562, 0
  %cv2564 = zext i1 %cmp2563 to i32
  store i32 %cv2564, ptr %slot435, align 8
  %v2565 = load i32, ptr %slot435, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcgnn544, label %bb_rcgdone544
bb_rcgnn544:
  %v2568 = load i64, ptr %slot434, align 8
  %op2569 = sub i64 %v2568, 16
  store i64 %op2569, ptr %slot436, align 8
  %v2570 = load i64, ptr %slot434, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  %rgep2572 = getelementptr i8, ptr %p2571, i64 -16
  %ld2573 = load i64, ptr %rgep2572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2573, ptr %slot437, align 8
  %v2574 = load i64, ptr %slot437, align 8
  %op2575 = and i64 %v2574, 4611686018427387906
  store i64 %op2575, ptr %slot438, align 8
  %v2576 = load i64, ptr %slot438, align 8
  %cmp2577 = icmp ne i64 %v2576, 0
  %cv2578 = zext i1 %cmp2577 to i32
  store i32 %cv2578, ptr %slot439, align 8
  %v2579 = load i32, ptr %slot439, align 8
  %cv2580 = zext i32 %v2579 to i64
  %cond2581 = icmp ne i64 %cv2580, 0
  br i1 %cond2581, label %bb_rcgclear544, label %bb_rcgcounted544
bb_rcgcounted544:
  %v2582 = load i64, ptr %slot434, align 8
  %op2583 = sub i64 %v2582, 24
  store i64 %op2583, ptr %slot440, align 8
  %v2584 = load i64, ptr %slot434, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  %rgep2586 = getelementptr i8, ptr %p2585, i64 -24
  %ld2587 = load i64, ptr %rgep2586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2587, ptr %slot441, align 8
  %v2588 = load i64, ptr %slot441, align 8
  %op2589 = sub i64 %v2588, 1
  store i64 %op2589, ptr %slot442, align 8
  %v2590 = load i64, ptr %slot442, align 8
  %cmp2591 = icmp eq i64 %v2590, 0
  %cv2592 = zext i1 %cmp2591 to i32
  store i32 %cv2592, ptr %slot443, align 8
  %v2593 = load i32, ptr %slot443, align 8
  %cv2594 = zext i32 %v2593 to i64
  %cond2595 = icmp ne i64 %cv2594, 0
  br i1 %cond2595, label %bb_rcglast544, label %bb_rcgdec544
bb_rcglast544:
  %v2596 = load i64, ptr %slot434, align 8
  %op2597 = sub i64 %v2596, 32
  store i64 %op2597, ptr %slot444, align 8
  %v2598 = load i64, ptr %slot434, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  %rgep2600 = getelementptr i8, ptr %p2599, i64 -32
  %ld2601 = load i64, ptr %rgep2600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2601, ptr %slot445, align 8
  %v2602 = load i64, ptr %slot445, align 8
  %cmp2603 = icmp ne i64 %v2602, 0
  %cv2604 = zext i1 %cmp2603 to i32
  store i32 %cv2604, ptr %slot446, align 8
  %v2605 = load i32, ptr %slot446, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcgdec544, label %bb_rcgslow544
bb_rcgslow544:
  %v2608 = load i64, ptr %slot433, align 8
  %v2609 = load i64, ptr %slot430, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2608, i64 %v2609) nomerge, !dbg !120
  br label %bb_rcgdone544
bb_rcgdec544:
  %v2610 = load i64, ptr %slot442, align 8
  %v2611 = load i64, ptr %slot434, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %rgep2613 = getelementptr i8, ptr %p2612, i64 -24
  store i64 %v2610, ptr %rgep2613, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear544
bb_rcgclear544:
  %v2614 = load i64, ptr %slot430, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  store i64 0, ptr %p2615, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone544
bb_rcgdone544:
  br label %bb_rcslotdone528
bb_rcslotowner528:
  %v2616 = load i64, ptr %slot20, align 8
  store i64 %v2616, ptr %slot447, align 8
  %v2617 = load i64, ptr %slot430, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2619, ptr %slot448, align 8
  %v2620 = load i64, ptr %slot448, align 8
  %cmp2621 = icmp ne i64 %v2620, 0
  %cv2622 = zext i1 %cmp2621 to i32
  store i32 %cv2622, ptr %slot449, align 8
  %v2623 = load i32, ptr %slot449, align 8
  %cv2624 = zext i32 %v2623 to i64
  %cond2625 = icmp ne i64 %cv2624, 0
  br i1 %cond2625, label %bb_rcgnn559, label %bb_rcgdone559
bb_rcgnn559:
  %v2626 = load i64, ptr %slot448, align 8
  %op2627 = sub i64 %v2626, 16
  store i64 %op2627, ptr %slot450, align 8
  %v2628 = load i64, ptr %slot448, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %rgep2630 = getelementptr i8, ptr %p2629, i64 -16
  %ld2631 = load i64, ptr %rgep2630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2631, ptr %slot451, align 8
  %v2632 = load i64, ptr %slot451, align 8
  %op2633 = and i64 %v2632, 4611686018427387906
  store i64 %op2633, ptr %slot452, align 8
  %v2634 = load i64, ptr %slot452, align 8
  %cmp2635 = icmp ne i64 %v2634, 0
  %cv2636 = zext i1 %cmp2635 to i32
  store i32 %cv2636, ptr %slot453, align 8
  %v2637 = load i32, ptr %slot453, align 8
  %cv2638 = zext i32 %v2637 to i64
  %cond2639 = icmp ne i64 %cv2638, 0
  br i1 %cond2639, label %bb_rcgclear559, label %bb_rcgcounted559
bb_rcgcounted559:
  %v2640 = load i64, ptr %slot448, align 8
  %op2641 = sub i64 %v2640, 32
  store i64 %op2641, ptr %slot454, align 8
  %v2642 = load i64, ptr %slot448, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  %rgep2644 = getelementptr i8, ptr %p2643, i64 -32
  %ld2645 = load i64, ptr %rgep2644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2645, ptr %slot455, align 8
  %v2646 = load i64, ptr %slot455, align 8
  %op2647 = sub i64 %v2646, 1
  store i64 %op2647, ptr %slot456, align 8
  %v2648 = load i64, ptr %slot456, align 8
  %cmp2649 = icmp eq i64 %v2648, 0
  %cv2650 = zext i1 %cmp2649 to i32
  store i32 %cv2650, ptr %slot457, align 8
  %v2651 = load i32, ptr %slot457, align 8
  %cv2652 = zext i32 %v2651 to i64
  %cond2653 = icmp ne i64 %cv2652, 0
  br i1 %cond2653, label %bb_rcglast559, label %bb_rcgdec559
bb_rcglast559:
  %v2654 = load i64, ptr %slot448, align 8
  %op2655 = sub i64 %v2654, 24
  store i64 %op2655, ptr %slot458, align 8
  %v2656 = load i64, ptr %slot448, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  %rgep2658 = getelementptr i8, ptr %p2657, i64 -24
  %ld2659 = load i64, ptr %rgep2658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2659, ptr %slot459, align 8
  %v2660 = load i64, ptr %slot459, align 8
  %cmp2661 = icmp ne i64 %v2660, 0
  %cv2662 = zext i1 %cmp2661 to i32
  store i32 %cv2662, ptr %slot460, align 8
  %v2663 = load i32, ptr %slot460, align 8
  %cv2664 = zext i32 %v2663 to i64
  %cond2665 = icmp ne i64 %cv2664, 0
  br i1 %cond2665, label %bb_rcgdec559, label %bb_rcgslow559
bb_rcgslow559:
  %v2666 = load i64, ptr %slot447, align 8
  %v2667 = load i64, ptr %slot430, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2666, i64 %v2667) nomerge, !dbg !120
  br label %bb_rcgdone559
bb_rcgdec559:
  %v2668 = load i64, ptr %slot456, align 8
  %v2669 = load i64, ptr %slot448, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %rgep2671 = getelementptr i8, ptr %p2670, i64 -32
  store i64 %v2668, ptr %rgep2671, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear559
bb_rcgclear559:
  %v2672 = load i64, ptr %slot430, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  store i64 0, ptr %p2673, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone559
bb_rcgdone559:
  br label %bb_rcslotdone528
bb_rcslotdone528:
  %v2674 = load i64, ptr %slot19, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i64 65536, ptr %p2675, align 8, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot18, align 8
  store i64 %v2676, ptr %slot461, align 8
  %v2677 = load i64, ptr %slot8, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  store i32 2, ptr %p2678, align 4, !alias.scope !3, !noalias !4
  %v2679 = load i64, ptr %slot461, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %ld2681 = load i64, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2681, ptr %slot462, align 8
  %v2682 = load i64, ptr %slot462, align 8
  %cmp2683 = icmp ne i64 %v2682, 0
  %cv2684 = zext i1 %cmp2683 to i32
  store i32 %cv2684, ptr %slot463, align 8
  %v2685 = load i32, ptr %slot463, align 8
  %cv2686 = zext i32 %v2685 to i64
  %cond2687 = icmp ne i64 %cv2686, 0
  br i1 %cond2687, label %bb_rcguniquenn566, label %bb_rcgunique566
bb_rcguniquenn566:
  %v2688 = load i64, ptr %slot462, align 8
  %op2689 = sub i64 %v2688, 16
  store i64 %op2689, ptr %slot464, align 8
  %v2690 = load i64, ptr %slot462, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %rgep2692 = getelementptr i8, ptr %p2691, i64 -16
  %ld2693 = load i64, ptr %rgep2692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2693, ptr %slot465, align 8
  %v2694 = load i64, ptr %slot465, align 8
  %op2695 = and i64 %v2694, 6917529027641081858
  store i64 %op2695, ptr %slot466, align 8
  %v2696 = load i64, ptr %slot466, align 8
  %cmp2697 = icmp ne i64 %v2696, 0
  %cv2698 = zext i1 %cmp2697 to i32
  store i32 %cv2698, ptr %slot467, align 8
  %v2699 = load i32, ptr %slot467, align 8
  %cv2700 = zext i32 %v2699 to i64
  %cond2701 = icmp ne i64 %cv2700, 0
  br i1 %cond2701, label %bb_rcguniqueslow566, label %bb_rcguniquecount566
bb_rcguniquecount566:
  %v2702 = load i64, ptr %slot462, align 8
  %op2703 = sub i64 %v2702, 32
  store i64 %op2703, ptr %slot468, align 8
  %v2704 = load i64, ptr %slot462, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  %rgep2706 = getelementptr i8, ptr %p2705, i64 -32
  %ld2707 = load i64, ptr %rgep2706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2707, ptr %slot469, align 8
  %v2708 = load i64, ptr %slot469, align 8
  %cmp2709 = icmp ult i64 %v2708, 2
  %cv2710 = zext i1 %cmp2709 to i32
  store i32 %cv2710, ptr %slot470, align 8
  %v2711 = load i32, ptr %slot470, align 8
  %cv2712 = zext i32 %v2711 to i64
  %cond2713 = icmp ne i64 %cv2712, 0
  br i1 %cond2713, label %bb_rcgunique566, label %bb_rcguniqueslow566
bb_rcguniqueslow566:
  %v2714 = load i64, ptr %slot1, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  %p2716 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v2717 = load i64, ptr %slot461, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %v2719 = load i64, ptr %slot7, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %call2721 = call i32 @myl_qbe_rc_unique_local(ptr %p2715, ptr %p2716, ptr %p2718, ptr %p2720) nomerge, !dbg !122
  store i32 %call2721, ptr %slot471, align 8
  %v2722 = load i32, ptr %slot471, align 8
  %cv2723 = zext i32 %v2722 to i64
  %cond2724 = icmp ne i64 %cv2723, 0
  br i1 %cond2724, label %bb_rcunique577, label %bb_failure
bb_rcunique577:
  br label %bb_rcgunique566
bb_rcgunique566:
  %v2725 = load i64, ptr %slot18, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  %ld2727 = load i64, ptr %p2726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2727, ptr %slot472, align 8
  %v2728 = load i64, ptr %slot19, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2730, ptr %slot473, align 8
  %v2731 = load i64, ptr %slot20, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  %v2733 = load i64, ptr %slot472, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %v2735 = load i64, ptr %slot473, align 8
  %call2736 = call i32 @myl_native_bytes_buffer_reserve(ptr %p2732, ptr %p2734, i64 %v2735) nomerge, !dbg !122
  store i32 %call2736, ptr %slot474, align 8
  %v2737 = load i32, ptr %slot474, align 8
  %ext2738 = zext i32 %v2737 to i64
  store i64 %ext2738, ptr %slot475, align 8
  %v2739 = load i64, ptr %slot475, align 8
  %cmp2740 = icmp ne i64 %v2739, 0
  %cv2741 = zext i1 %cmp2740 to i64
  store i64 %cv2741, ptr %slot476, align 8
  %v2742 = load i64, ptr %slot476, align 8
  %cond2743 = icmp ne i64 %v2742, 0
  br i1 %cond2743, label %bb_success584, label %bb_failed584
bb_failed584:
  %v2744 = load i64, ptr %slot1, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2745) nomerge, !dbg !122
  unreachable
bb_success584:
  %v2746 = load i32, ptr %slot474, align 8
  %cmp2747 = icmp eq i32 %v2746, 1
  %cv2748 = zext i1 %cmp2747 to i32
  store i32 %cv2748, ptr %slot477, align 8
  %v2749 = load i32, ptr %slot477, align 8
  %ext2750 = zext i32 %v2749 to i64
  store i64 %ext2750, ptr %slot478, align 8
  %v2751 = load i64, ptr %slot478, align 8
  %v2752 = load i64, ptr %slot19, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  store i64 %v2751, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  %v2754 = load i64, ptr %slot18, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  %ld2756 = load i64, ptr %p2755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2756, ptr %slot479, align 8
  %v2757 = load i64, ptr %slot479, align 8
  %v2758 = load i64, ptr %slot19, align 8
  %p2759 = inttoptr i64 %v2758 to ptr
  store i64 %v2757, ptr %p2759, align 8, !alias.scope !3, !noalias !4
  %v2760 = load i64, ptr %slot19, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %ld2762 = load i64, ptr %p2761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2762, ptr %slot480, align 8
  %v2763 = load i64, ptr %slot19, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot481, align 8
  %v2766 = load i64, ptr %slot481, align 8
  %v2767 = load i64, ptr %slot14, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  store i64 %v2766, ptr %p2768, align 8, !alias.scope !3, !noalias !4
  %v2769 = load i64, ptr %slot14, align 8
  store i64 %v2769, ptr %slot482, align 8
  %v2770 = load i64, ptr %slot9, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  %ld2772 = load i32, ptr %p2771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2772, ptr %slot483, align 8
  %v2773 = load i64, ptr %slot10, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %ld2775 = load i32, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2775, ptr %slot484, align 8
  %v2776 = load i32, ptr %slot484, align 8
  %op2777 = and i32 %v2776, 24
  store i32 %op2777, ptr %slot484, align 8
  %v2778 = load i32, ptr %slot484, align 8
  %cmp2779 = icmp eq i32 %v2778, 0
  %cv2780 = zext i1 %cmp2779 to i32
  store i32 %cv2780, ptr %slot485, align 8
  %v2781 = load i32, ptr %slot483, align 8
  %v2782 = load i32, ptr %slot485, align 8
  %op2783 = and i32 %v2781, %v2782
  store i32 %op2783, ptr %slot486, align 8
  %v2784 = load i32, ptr %slot486, align 8
  %cv2785 = zext i32 %v2784 to i64
  %cond2786 = icmp ne i64 %cv2785, 0
  br i1 %cond2786, label %bb_rctake591, label %bb_rccopy591
bb_rctake591:
  %v2787 = load i64, ptr %slot15, align 8
  store i64 %v2787, ptr %slot487, align 8
  %v2788 = load i64, ptr %slot21, align 8
  store i64 %v2788, ptr %slot488, align 8
  %v2789 = load i64, ptr %slot482, align 8
  %v2790 = load i64, ptr %slot487, align 8
  %op2791 = sub i64 %v2789, %v2790
  store i64 %op2791, ptr %slot489, align 8
  %v2792 = load i64, ptr %slot487, align 8
  %v2793 = load i64, ptr %slot482, align 8
  %op2794 = sub i64 %v2792, %v2793
  store i64 %op2794, ptr %slot490, align 8
  %v2795 = load i64, ptr %slot489, align 8
  %cmp2796 = icmp ult i64 %v2795, 8
  %cv2797 = zext i1 %cmp2796 to i32
  store i32 %cv2797, ptr %slot491, align 8
  %v2798 = load i64, ptr %slot490, align 8
  %cmp2799 = icmp ult i64 %v2798, 8
  %cv2800 = zext i1 %cmp2799 to i32
  store i32 %cv2800, ptr %slot492, align 8
  %v2801 = load i32, ptr %slot491, align 8
  %v2802 = load i32, ptr %slot492, align 8
  %op2803 = or i32 %v2801, %v2802
  store i32 %op2803, ptr %slot493, align 8
  %v2804 = load i32, ptr %slot493, align 8
  %cv2805 = zext i32 %v2804 to i64
  %cond2806 = icmp ne i64 %cv2805, 0
  br i1 %cond2806, label %bb_rcmoveslow600, label %bb_rcmovecheck600
bb_rcmovecheck600:
  %v2807 = load i64, ptr %slot482, align 8
  %p2809 = inttoptr i64 %v2807 to ptr
  %gep2810 = getelementptr i8, ptr %p2809, i64 0
  %op2808 = ptrtoint ptr %gep2810 to i64
  store i64 %op2808, ptr %slot494, align 8
  %v2811 = load i64, ptr %slot494, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %ld2813 = load i64, ptr %p2812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2813, ptr %slot495, align 8
  %v2814 = load i64, ptr %slot495, align 8
  %cmp2815 = icmp ne i64 %v2814, 0
  %cv2816 = zext i1 %cmp2815 to i32
  store i32 %cv2816, ptr %slot496, align 8
  %v2817 = load i32, ptr %slot496, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcmoveheader608, label %bb_rcmovenext608
bb_rcmoveheader608:
  %v2820 = load i64, ptr %slot495, align 8
  %op2821 = sub i64 %v2820, 16
  store i64 %op2821, ptr %slot497, align 8
  %v2822 = load i64, ptr %slot495, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %rgep2824 = getelementptr i8, ptr %p2823, i64 -16
  %ld2825 = load i64, ptr %rgep2824, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2825, ptr %slot498, align 8
  %v2826 = load i64, ptr %slot498, align 8
  %op2827 = and i64 %v2826, 5764607523034234881
  store i64 %op2827, ptr %slot499, align 8
  %v2828 = load i64, ptr %slot499, align 8
  %cmp2829 = icmp ne i64 %v2828, 0
  %cv2830 = zext i1 %cmp2829 to i32
  store i32 %cv2830, ptr %slot500, align 8
  %v2831 = load i32, ptr %slot500, align 8
  %cv2832 = zext i32 %v2831 to i64
  %cond2833 = icmp ne i64 %cv2832, 0
  br i1 %cond2833, label %bb_rcmoveslow600, label %bb_rcmovenext608
bb_rcmovenext608:
  %v2834 = load i64, ptr %slot482, align 8
  %v2835 = load i64, ptr %slot487, align 8
  %p2836 = inttoptr i64 %v2834 to ptr
  %p2837 = inttoptr i64 %v2835 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2837, ptr %p2836, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot482, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i64 0, ptr %p2839, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved600
bb_rcmoveslow600:
  %v2840 = load i64, ptr %slot20, align 8
  %v2841 = load i64, ptr %slot487, align 8
  %v2842 = load i64, ptr %slot482, align 8
  %v2843 = load i64, ptr %slot488, align 8
  %cv2844 = trunc i64 %v2843 to i32
  %call2845 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v2840, i64 %v2841, i64 %v2842, i32 %cv2844) nomerge, !dbg !124
  store i32 %call2845, ptr %slot501, align 8
  %v2846 = load i32, ptr %slot501, align 8
  %cv2847 = zext i32 %v2846 to i64
  %cond2848 = icmp ne i64 %cv2847, 0
  br i1 %cond2848, label %bb_rcsuccess615, label %bb_rcfailure615
bb_rcfailure615:
  %v2849 = load i64, ptr %slot20, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %call2851 = call i32 @myl_rc_take_failure(ptr %p2850) nomerge, !dbg !124
  store i32 %call2851, ptr %slot502, align 8
  %v2852 = load i64, ptr %slot1, align 8
  %p2853 = inttoptr i64 %v2852 to ptr
  %v2854 = load i32, ptr %slot502, align 8
  %call2855 = call i32 @myl_qbe_rc_status(ptr %p2853, i32 %v2854) nomerge, !dbg !124
  store i32 %call2855, ptr %slot503, align 8
  br label %bb_failure
bb_rcsuccess615:
  br label %bb_rcmoved600
bb_rcmoved600:
  %v2856 = load i64, ptr %slot9, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i32 0, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot12, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i32 2, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot11, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  store i32 1, ptr %p2861, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared591
bb_rccopy591:
  %v2862 = load i64, ptr %slot15, align 8
  store i64 %v2862, ptr %slot504, align 8
  %v2863 = load i64, ptr %slot21, align 8
  store i64 %v2863, ptr %slot505, align 8
  %v2864 = load i64, ptr %slot482, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  %ld2866 = load i64, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2866, ptr %slot506, align 8
  %v2867 = load i64, ptr %slot506, align 8
  %cmp2868 = icmp ne i64 %v2867, 0
  %cv2869 = zext i1 %cmp2868 to i32
  store i32 %cv2869, ptr %slot507, align 8
  %v2870 = load i32, ptr %slot507, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcgnn624, label %bb_rcgplain624
bb_rcgnn624:
  %v2873 = load i64, ptr %slot506, align 8
  %op2874 = sub i64 %v2873, 16
  store i64 %op2874, ptr %slot508, align 8
  %v2875 = load i64, ptr %slot506, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %rgep2877 = getelementptr i8, ptr %p2876, i64 -16
  %ld2878 = load i64, ptr %rgep2877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2878, ptr %slot509, align 8
  %v2879 = load i64, ptr %slot509, align 8
  %op2880 = and i64 %v2879, 4611686018427387906
  store i64 %op2880, ptr %slot510, align 8
  %v2881 = load i64, ptr %slot510, align 8
  %cmp2882 = icmp ne i64 %v2881, 0
  %cv2883 = zext i1 %cmp2882 to i32
  store i32 %cv2883, ptr %slot511, align 8
  %v2884 = load i32, ptr %slot511, align 8
  %cv2885 = zext i32 %v2884 to i64
  %cond2886 = icmp ne i64 %cv2885, 0
  br i1 %cond2886, label %bb_rcgspecial624, label %bb_rcginc624
bb_rcginc624:
  %v2887 = load i64, ptr %slot506, align 8
  %op2888 = sub i64 %v2887, 32
  store i64 %op2888, ptr %slot512, align 8
  %v2889 = load i64, ptr %slot506, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %rgep2891 = getelementptr i8, ptr %p2890, i64 -32
  %ld2892 = load i64, ptr %rgep2891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2892, ptr %slot513, align 8
  %v2893 = load i64, ptr %slot513, align 8
  %op2894 = add i64 %v2893, 1
  store i64 %op2894, ptr %slot514, align 8
  %v2895 = load i64, ptr %slot514, align 8
  %cmp2896 = icmp eq i64 %v2895, 0
  %cv2897 = zext i1 %cmp2896 to i32
  store i32 %cv2897, ptr %slot515, align 8
  %v2898 = load i32, ptr %slot515, align 8
  %cv2899 = zext i32 %v2898 to i64
  %cond2900 = icmp ne i64 %cv2899, 0
  br i1 %cond2900, label %bb_rcglimit624, label %bb_rcgcapacity624
bb_rcglimit624:
  %v2901 = load i64, ptr %slot1, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  %call2903 = call i32 @myl_qbe_rc_status(ptr %p2902, i32 2) nomerge, !dbg !124
  store i32 %call2903, ptr %slot516, align 8
  br label %bb_failure
bb_rcgcapacity624:
  %v2904 = load i64, ptr %slot514, align 8
  %v2905 = load i64, ptr %slot506, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %rgep2907 = getelementptr i8, ptr %p2906, i64 -32
  store i64 %v2904, ptr %rgep2907, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain624
bb_rcgspecial624:
  %v2908 = load i64, ptr %slot509, align 8
  %op2909 = and i64 %v2908, 4611686018427387904
  store i64 %op2909, ptr %slot517, align 8
  %v2910 = load i64, ptr %slot517, align 8
  %cmp2911 = icmp ne i64 %v2910, 0
  %cv2912 = zext i1 %cmp2911 to i32
  store i32 %cv2912, ptr %slot518, align 8
  %v2913 = load i32, ptr %slot518, align 8
  %cv2914 = zext i32 %v2913 to i64
  %cond2915 = icmp ne i64 %cv2914, 0
  br i1 %cond2915, label %bb_rcgslow624, label %bb_rcgplain624
bb_rcgslow624:
  %v2916 = load i64, ptr %slot20, align 8
  %v2917 = load i64, ptr %slot504, align 8
  %v2918 = load i64, ptr %slot482, align 8
  %v2919 = load i64, ptr %slot505, align 8
  %cv2920 = trunc i64 %v2919 to i32
  %call2921 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v2916, i64 %v2917, i64 %v2918, i32 %cv2920) nomerge, !dbg !124
  store i32 %call2921, ptr %slot519, align 8
  %v2922 = load i32, ptr %slot519, align 8
  %cv2923 = zext i32 %v2922 to i64
  %cond2924 = icmp ne i64 %cv2923, 0
  br i1 %cond2924, label %bb_rcsuccess638, label %bb_rcfailure638
bb_rcfailure638:
  %v2925 = load i64, ptr %slot20, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %call2927 = call i32 @myl_rc_take_failure(ptr %p2926) nomerge, !dbg !124
  store i32 %call2927, ptr %slot520, align 8
  %v2928 = load i64, ptr %slot1, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %v2930 = load i32, ptr %slot520, align 8
  %call2931 = call i32 @myl_qbe_rc_status(ptr %p2929, i32 %v2930) nomerge, !dbg !124
  store i32 %call2931, ptr %slot521, align 8
  br label %bb_failure
bb_rcsuccess638:
  br label %bb_rcgdone624
bb_rcgplain624:
  %v2932 = load i64, ptr %slot506, align 8
  %v2933 = load i64, ptr %slot504, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  store i64 %v2932, ptr %p2934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone624
bb_rcgdone624:
  %v2935 = load i64, ptr %slot12, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i32 2, ptr %p2936, align 4, !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot11, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  store i32 1, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  %v2939 = load i64, ptr %slot9, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  %ld2941 = load i32, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2941, ptr %slot522, align 8
  %v2942 = load i32, ptr %slot522, align 8
  %cv2943 = zext i32 %v2942 to i64
  %cond2944 = icmp ne i64 %cv2943, 0
  br i1 %cond2944, label %bb_rcslotdrop645, label %bb_rcslotdone645
bb_rcslotdrop645:
  %v2945 = load i64, ptr %slot9, align 8
  %p2946 = inttoptr i64 %v2945 to ptr
  store i32 0, ptr %p2946, align 4, !alias.scope !3, !noalias !4
  %v2947 = load i64, ptr %slot13, align 8
  store i64 %v2947, ptr %slot523, align 8
  %v2948 = load i64, ptr %slot10, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  %ld2950 = load i32, ptr %p2949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2950, ptr %slot524, align 8
  %v2951 = load i32, ptr %slot524, align 8
  %op2952 = and i32 %v2951, 28
  store i32 %op2952, ptr %slot525, align 8
  %v2953 = load i32, ptr %slot525, align 8
  %cv2954 = zext i32 %v2953 to i64
  %cond2955 = icmp ne i64 %cv2954, 0
  br i1 %cond2955, label %bb_rcslotrole645, label %bb_rcslotowner645
bb_rcslotrole645:
  %v2956 = load i64, ptr %slot20, align 8
  store i64 %v2956, ptr %slot526, align 8
  %v2957 = load i64, ptr %slot523, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %ld2959 = load i64, ptr %p2958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2959, ptr %slot527, align 8
  %v2960 = load i64, ptr %slot527, align 8
  %cmp2961 = icmp ne i64 %v2960, 0
  %cv2962 = zext i1 %cmp2961 to i32
  store i32 %cv2962, ptr %slot528, align 8
  %v2963 = load i32, ptr %slot528, align 8
  %cv2964 = zext i32 %v2963 to i64
  %cond2965 = icmp ne i64 %cv2964, 0
  br i1 %cond2965, label %bb_rcgnn661, label %bb_rcgdone661
bb_rcgnn661:
  %v2966 = load i64, ptr %slot527, align 8
  %op2967 = sub i64 %v2966, 16
  store i64 %op2967, ptr %slot529, align 8
  %v2968 = load i64, ptr %slot527, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %rgep2970 = getelementptr i8, ptr %p2969, i64 -16
  %ld2971 = load i64, ptr %rgep2970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2971, ptr %slot530, align 8
  %v2972 = load i64, ptr %slot530, align 8
  %op2973 = and i64 %v2972, 4611686018427387906
  store i64 %op2973, ptr %slot531, align 8
  %v2974 = load i64, ptr %slot531, align 8
  %cmp2975 = icmp ne i64 %v2974, 0
  %cv2976 = zext i1 %cmp2975 to i32
  store i32 %cv2976, ptr %slot532, align 8
  %v2977 = load i32, ptr %slot532, align 8
  %cv2978 = zext i32 %v2977 to i64
  %cond2979 = icmp ne i64 %cv2978, 0
  br i1 %cond2979, label %bb_rcgclear661, label %bb_rcgcounted661
bb_rcgcounted661:
  %v2980 = load i64, ptr %slot527, align 8
  %op2981 = sub i64 %v2980, 24
  store i64 %op2981, ptr %slot533, align 8
  %v2982 = load i64, ptr %slot527, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %rgep2984 = getelementptr i8, ptr %p2983, i64 -24
  %ld2985 = load i64, ptr %rgep2984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2985, ptr %slot534, align 8
  %v2986 = load i64, ptr %slot534, align 8
  %op2987 = sub i64 %v2986, 1
  store i64 %op2987, ptr %slot535, align 8
  %v2988 = load i64, ptr %slot535, align 8
  %cmp2989 = icmp eq i64 %v2988, 0
  %cv2990 = zext i1 %cmp2989 to i32
  store i32 %cv2990, ptr %slot536, align 8
  %v2991 = load i32, ptr %slot536, align 8
  %cv2992 = zext i32 %v2991 to i64
  %cond2993 = icmp ne i64 %cv2992, 0
  br i1 %cond2993, label %bb_rcglast661, label %bb_rcgdec661
bb_rcglast661:
  %v2994 = load i64, ptr %slot527, align 8
  %op2995 = sub i64 %v2994, 32
  store i64 %op2995, ptr %slot537, align 8
  %v2996 = load i64, ptr %slot527, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %rgep2998 = getelementptr i8, ptr %p2997, i64 -32
  %ld2999 = load i64, ptr %rgep2998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2999, ptr %slot538, align 8
  %v3000 = load i64, ptr %slot538, align 8
  %cmp3001 = icmp ne i64 %v3000, 0
  %cv3002 = zext i1 %cmp3001 to i32
  store i32 %cv3002, ptr %slot539, align 8
  %v3003 = load i32, ptr %slot539, align 8
  %cv3004 = zext i32 %v3003 to i64
  %cond3005 = icmp ne i64 %cv3004, 0
  br i1 %cond3005, label %bb_rcgdec661, label %bb_rcgslow661
bb_rcgslow661:
  %v3006 = load i64, ptr %slot526, align 8
  %v3007 = load i64, ptr %slot523, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v3006, i64 %v3007) nomerge, !dbg !124
  br label %bb_rcgdone661
bb_rcgdec661:
  %v3008 = load i64, ptr %slot535, align 8
  %v3009 = load i64, ptr %slot527, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %rgep3011 = getelementptr i8, ptr %p3010, i64 -24
  store i64 %v3008, ptr %rgep3011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear661
bb_rcgclear661:
  %v3012 = load i64, ptr %slot523, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i64 0, ptr %p3013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone661
bb_rcgdone661:
  br label %bb_rcslotdone645
bb_rcslotowner645:
  %v3014 = load i64, ptr %slot20, align 8
  store i64 %v3014, ptr %slot540, align 8
  %v3015 = load i64, ptr %slot523, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  %ld3017 = load i64, ptr %p3016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3017, ptr %slot541, align 8
  %v3018 = load i64, ptr %slot541, align 8
  %cmp3019 = icmp ne i64 %v3018, 0
  %cv3020 = zext i1 %cmp3019 to i32
  store i32 %cv3020, ptr %slot542, align 8
  %v3021 = load i32, ptr %slot542, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcgnn676, label %bb_rcgdone676
bb_rcgnn676:
  %v3024 = load i64, ptr %slot541, align 8
  %op3025 = sub i64 %v3024, 16
  store i64 %op3025, ptr %slot543, align 8
  %v3026 = load i64, ptr %slot541, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %rgep3028 = getelementptr i8, ptr %p3027, i64 -16
  %ld3029 = load i64, ptr %rgep3028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3029, ptr %slot544, align 8
  %v3030 = load i64, ptr %slot544, align 8
  %op3031 = and i64 %v3030, 4611686018427387906
  store i64 %op3031, ptr %slot545, align 8
  %v3032 = load i64, ptr %slot545, align 8
  %cmp3033 = icmp ne i64 %v3032, 0
  %cv3034 = zext i1 %cmp3033 to i32
  store i32 %cv3034, ptr %slot546, align 8
  %v3035 = load i32, ptr %slot546, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcgclear676, label %bb_rcgcounted676
bb_rcgcounted676:
  %v3038 = load i64, ptr %slot541, align 8
  %op3039 = sub i64 %v3038, 32
  store i64 %op3039, ptr %slot547, align 8
  %v3040 = load i64, ptr %slot541, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  %rgep3042 = getelementptr i8, ptr %p3041, i64 -32
  %ld3043 = load i64, ptr %rgep3042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3043, ptr %slot548, align 8
  %v3044 = load i64, ptr %slot548, align 8
  %op3045 = sub i64 %v3044, 1
  store i64 %op3045, ptr %slot549, align 8
  %v3046 = load i64, ptr %slot549, align 8
  %cmp3047 = icmp eq i64 %v3046, 0
  %cv3048 = zext i1 %cmp3047 to i32
  store i32 %cv3048, ptr %slot550, align 8
  %v3049 = load i32, ptr %slot550, align 8
  %cv3050 = zext i32 %v3049 to i64
  %cond3051 = icmp ne i64 %cv3050, 0
  br i1 %cond3051, label %bb_rcglast676, label %bb_rcgdec676
bb_rcglast676:
  %v3052 = load i64, ptr %slot541, align 8
  %op3053 = sub i64 %v3052, 24
  store i64 %op3053, ptr %slot551, align 8
  %v3054 = load i64, ptr %slot541, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  %rgep3056 = getelementptr i8, ptr %p3055, i64 -24
  %ld3057 = load i64, ptr %rgep3056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3057, ptr %slot552, align 8
  %v3058 = load i64, ptr %slot552, align 8
  %cmp3059 = icmp ne i64 %v3058, 0
  %cv3060 = zext i1 %cmp3059 to i32
  store i32 %cv3060, ptr %slot553, align 8
  %v3061 = load i32, ptr %slot553, align 8
  %cv3062 = zext i32 %v3061 to i64
  %cond3063 = icmp ne i64 %cv3062, 0
  br i1 %cond3063, label %bb_rcgdec676, label %bb_rcgslow676
bb_rcgslow676:
  %v3064 = load i64, ptr %slot540, align 8
  %v3065 = load i64, ptr %slot523, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3064, i64 %v3065) nomerge, !dbg !124
  br label %bb_rcgdone676
bb_rcgdec676:
  %v3066 = load i64, ptr %slot549, align 8
  %v3067 = load i64, ptr %slot541, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  %rgep3069 = getelementptr i8, ptr %p3068, i64 -32
  store i64 %v3066, ptr %rgep3069, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear676
bb_rcgclear676:
  %v3070 = load i64, ptr %slot523, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i64 0, ptr %p3071, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone676
bb_rcgdone676:
  br label %bb_rcslotdone645
bb_rcslotdone645:
  br label %bb_rcprepared591
bb_rcprepared591:
  %v3072 = load i64, ptr %slot15, align 8
  store i64 %v3072, ptr %slot554, align 8
  %v3073 = load i64, ptr %slot554, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  %ld3075 = load i64, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3075, ptr %slot555, align 8
  %v3076 = load i64, ptr %slot11, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i32 0, ptr %p3077, align 4, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot9, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %ld3080 = load i32, ptr %p3079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3080, ptr %slot556, align 8
  %v3081 = load i32, ptr %slot556, align 8
  %cv3082 = zext i32 %v3081 to i64
  %cond3083 = icmp ne i64 %cv3082, 0
  br i1 %cond3083, label %bb_rcslotdrop685, label %bb_rcslotdone685
bb_rcslotdrop685:
  %v3084 = load i64, ptr %slot9, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i32 0, ptr %p3085, align 4, !alias.scope !3, !noalias !4
  %v3086 = load i64, ptr %slot13, align 8
  store i64 %v3086, ptr %slot557, align 8
  %v3087 = load i64, ptr %slot10, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i32, ptr %p3088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3089, ptr %slot558, align 8
  %v3090 = load i32, ptr %slot558, align 8
  %op3091 = and i32 %v3090, 28
  store i32 %op3091, ptr %slot559, align 8
  %v3092 = load i32, ptr %slot559, align 8
  %cv3093 = zext i32 %v3092 to i64
  %cond3094 = icmp ne i64 %cv3093, 0
  br i1 %cond3094, label %bb_rcslotrole685, label %bb_rcslotowner685
bb_rcslotrole685:
  %v3095 = load i64, ptr %slot20, align 8
  store i64 %v3095, ptr %slot560, align 8
  %v3096 = load i64, ptr %slot557, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i64, ptr %p3097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3098, ptr %slot561, align 8
  %v3099 = load i64, ptr %slot561, align 8
  %cmp3100 = icmp ne i64 %v3099, 0
  %cv3101 = zext i1 %cmp3100 to i32
  store i32 %cv3101, ptr %slot562, align 8
  %v3102 = load i32, ptr %slot562, align 8
  %cv3103 = zext i32 %v3102 to i64
  %cond3104 = icmp ne i64 %cv3103, 0
  br i1 %cond3104, label %bb_rcgnn701, label %bb_rcgdone701
bb_rcgnn701:
  %v3105 = load i64, ptr %slot561, align 8
  %op3106 = sub i64 %v3105, 16
  store i64 %op3106, ptr %slot563, align 8
  %v3107 = load i64, ptr %slot561, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %rgep3109 = getelementptr i8, ptr %p3108, i64 -16
  %ld3110 = load i64, ptr %rgep3109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3110, ptr %slot564, align 8
  %v3111 = load i64, ptr %slot564, align 8
  %op3112 = and i64 %v3111, 4611686018427387906
  store i64 %op3112, ptr %slot565, align 8
  %v3113 = load i64, ptr %slot565, align 8
  %cmp3114 = icmp ne i64 %v3113, 0
  %cv3115 = zext i1 %cmp3114 to i32
  store i32 %cv3115, ptr %slot566, align 8
  %v3116 = load i32, ptr %slot566, align 8
  %cv3117 = zext i32 %v3116 to i64
  %cond3118 = icmp ne i64 %cv3117, 0
  br i1 %cond3118, label %bb_rcgclear701, label %bb_rcgcounted701
bb_rcgcounted701:
  %v3119 = load i64, ptr %slot561, align 8
  %op3120 = sub i64 %v3119, 24
  store i64 %op3120, ptr %slot567, align 8
  %v3121 = load i64, ptr %slot561, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %rgep3123 = getelementptr i8, ptr %p3122, i64 -24
  %ld3124 = load i64, ptr %rgep3123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3124, ptr %slot568, align 8
  %v3125 = load i64, ptr %slot568, align 8
  %op3126 = sub i64 %v3125, 1
  store i64 %op3126, ptr %slot569, align 8
  %v3127 = load i64, ptr %slot569, align 8
  %cmp3128 = icmp eq i64 %v3127, 0
  %cv3129 = zext i1 %cmp3128 to i32
  store i32 %cv3129, ptr %slot570, align 8
  %v3130 = load i32, ptr %slot570, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcglast701, label %bb_rcgdec701
bb_rcglast701:
  %v3133 = load i64, ptr %slot561, align 8
  %op3134 = sub i64 %v3133, 32
  store i64 %op3134, ptr %slot571, align 8
  %v3135 = load i64, ptr %slot561, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %rgep3137 = getelementptr i8, ptr %p3136, i64 -32
  %ld3138 = load i64, ptr %rgep3137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3138, ptr %slot572, align 8
  %v3139 = load i64, ptr %slot572, align 8
  %cmp3140 = icmp ne i64 %v3139, 0
  %cv3141 = zext i1 %cmp3140 to i32
  store i32 %cv3141, ptr %slot573, align 8
  %v3142 = load i32, ptr %slot573, align 8
  %cv3143 = zext i32 %v3142 to i64
  %cond3144 = icmp ne i64 %cv3143, 0
  br i1 %cond3144, label %bb_rcgdec701, label %bb_rcgslow701
bb_rcgslow701:
  %v3145 = load i64, ptr %slot560, align 8
  %v3146 = load i64, ptr %slot557, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v3145, i64 %v3146) nomerge, !dbg !124
  br label %bb_rcgdone701
bb_rcgdec701:
  %v3147 = load i64, ptr %slot569, align 8
  %v3148 = load i64, ptr %slot561, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  %rgep3150 = getelementptr i8, ptr %p3149, i64 -24
  store i64 %v3147, ptr %rgep3150, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear701
bb_rcgclear701:
  %v3151 = load i64, ptr %slot557, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i64 0, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone701
bb_rcgdone701:
  br label %bb_rcslotdone685
bb_rcslotowner685:
  %v3153 = load i64, ptr %slot20, align 8
  store i64 %v3153, ptr %slot574, align 8
  %v3154 = load i64, ptr %slot557, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i64, ptr %p3155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3156, ptr %slot575, align 8
  %v3157 = load i64, ptr %slot575, align 8
  %cmp3158 = icmp ne i64 %v3157, 0
  %cv3159 = zext i1 %cmp3158 to i32
  store i32 %cv3159, ptr %slot576, align 8
  %v3160 = load i32, ptr %slot576, align 8
  %cv3161 = zext i32 %v3160 to i64
  %cond3162 = icmp ne i64 %cv3161, 0
  br i1 %cond3162, label %bb_rcgnn716, label %bb_rcgdone716
bb_rcgnn716:
  %v3163 = load i64, ptr %slot575, align 8
  %op3164 = sub i64 %v3163, 16
  store i64 %op3164, ptr %slot577, align 8
  %v3165 = load i64, ptr %slot575, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %rgep3167 = getelementptr i8, ptr %p3166, i64 -16
  %ld3168 = load i64, ptr %rgep3167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3168, ptr %slot578, align 8
  %v3169 = load i64, ptr %slot578, align 8
  %op3170 = and i64 %v3169, 4611686018427387906
  store i64 %op3170, ptr %slot579, align 8
  %v3171 = load i64, ptr %slot579, align 8
  %cmp3172 = icmp ne i64 %v3171, 0
  %cv3173 = zext i1 %cmp3172 to i32
  store i32 %cv3173, ptr %slot580, align 8
  %v3174 = load i32, ptr %slot580, align 8
  %cv3175 = zext i32 %v3174 to i64
  %cond3176 = icmp ne i64 %cv3175, 0
  br i1 %cond3176, label %bb_rcgclear716, label %bb_rcgcounted716
bb_rcgcounted716:
  %v3177 = load i64, ptr %slot575, align 8
  %op3178 = sub i64 %v3177, 32
  store i64 %op3178, ptr %slot581, align 8
  %v3179 = load i64, ptr %slot575, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  %rgep3181 = getelementptr i8, ptr %p3180, i64 -32
  %ld3182 = load i64, ptr %rgep3181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3182, ptr %slot582, align 8
  %v3183 = load i64, ptr %slot582, align 8
  %op3184 = sub i64 %v3183, 1
  store i64 %op3184, ptr %slot583, align 8
  %v3185 = load i64, ptr %slot583, align 8
  %cmp3186 = icmp eq i64 %v3185, 0
  %cv3187 = zext i1 %cmp3186 to i32
  store i32 %cv3187, ptr %slot584, align 8
  %v3188 = load i32, ptr %slot584, align 8
  %cv3189 = zext i32 %v3188 to i64
  %cond3190 = icmp ne i64 %cv3189, 0
  br i1 %cond3190, label %bb_rcglast716, label %bb_rcgdec716
bb_rcglast716:
  %v3191 = load i64, ptr %slot575, align 8
  %op3192 = sub i64 %v3191, 24
  store i64 %op3192, ptr %slot585, align 8
  %v3193 = load i64, ptr %slot575, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  %rgep3195 = getelementptr i8, ptr %p3194, i64 -24
  %ld3196 = load i64, ptr %rgep3195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3196, ptr %slot586, align 8
  %v3197 = load i64, ptr %slot586, align 8
  %cmp3198 = icmp ne i64 %v3197, 0
  %cv3199 = zext i1 %cmp3198 to i32
  store i32 %cv3199, ptr %slot587, align 8
  %v3200 = load i32, ptr %slot587, align 8
  %cv3201 = zext i32 %v3200 to i64
  %cond3202 = icmp ne i64 %cv3201, 0
  br i1 %cond3202, label %bb_rcgdec716, label %bb_rcgslow716
bb_rcgslow716:
  %v3203 = load i64, ptr %slot574, align 8
  %v3204 = load i64, ptr %slot557, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3203, i64 %v3204) nomerge, !dbg !124
  br label %bb_rcgdone716
bb_rcgdec716:
  %v3205 = load i64, ptr %slot583, align 8
  %v3206 = load i64, ptr %slot575, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %rgep3208 = getelementptr i8, ptr %p3207, i64 -32
  store i64 %v3205, ptr %rgep3208, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear716
bb_rcgclear716:
  %v3209 = load i64, ptr %slot557, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 0, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone716
bb_rcgdone716:
  br label %bb_rcslotdone685
bb_rcslotdone685:
  %v3211 = load i64, ptr %slot7, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i32, ptr %p3212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3213, ptr %slot588, align 8
  %v3214 = load i32, ptr %slot588, align 8
  %cv3215 = zext i32 %v3214 to i64
  %cond3216 = icmp ne i64 %cv3215, 0
  br i1 %cond3216, label %bb_rcslotdrop722, label %bb_rcslotdone722
bb_rcslotdrop722:
  %v3217 = load i64, ptr %slot7, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i32 0, ptr %p3218, align 4, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot18, align 8
  store i64 %v3219, ptr %slot589, align 8
  %v3220 = load i64, ptr %slot8, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %ld3222 = load i32, ptr %p3221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3222, ptr %slot590, align 8
  %v3223 = load i32, ptr %slot590, align 8
  %op3224 = and i32 %v3223, 28
  store i32 %op3224, ptr %slot591, align 8
  %v3225 = load i32, ptr %slot591, align 8
  %cv3226 = zext i32 %v3225 to i64
  %cond3227 = icmp ne i64 %cv3226, 0
  br i1 %cond3227, label %bb_rcslotrole722, label %bb_rcslotowner722
bb_rcslotrole722:
  %v3228 = load i64, ptr %slot20, align 8
  store i64 %v3228, ptr %slot592, align 8
  %v3229 = load i64, ptr %slot589, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %ld3231 = load i64, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3231, ptr %slot593, align 8
  %v3232 = load i64, ptr %slot593, align 8
  %cmp3233 = icmp ne i64 %v3232, 0
  %cv3234 = zext i1 %cmp3233 to i32
  store i32 %cv3234, ptr %slot594, align 8
  %v3235 = load i32, ptr %slot594, align 8
  %cv3236 = zext i32 %v3235 to i64
  %cond3237 = icmp ne i64 %cv3236, 0
  br i1 %cond3237, label %bb_rcgnn738, label %bb_rcgdone738
bb_rcgnn738:
  %v3238 = load i64, ptr %slot593, align 8
  %op3239 = sub i64 %v3238, 16
  store i64 %op3239, ptr %slot595, align 8
  %v3240 = load i64, ptr %slot593, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %rgep3242 = getelementptr i8, ptr %p3241, i64 -16
  %ld3243 = load i64, ptr %rgep3242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3243, ptr %slot596, align 8
  %v3244 = load i64, ptr %slot596, align 8
  %op3245 = and i64 %v3244, 4611686018427387906
  store i64 %op3245, ptr %slot597, align 8
  %v3246 = load i64, ptr %slot597, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot598, align 8
  %v3249 = load i32, ptr %slot598, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcgclear738, label %bb_rcgcounted738
bb_rcgcounted738:
  %v3252 = load i64, ptr %slot593, align 8
  %op3253 = sub i64 %v3252, 24
  store i64 %op3253, ptr %slot599, align 8
  %v3254 = load i64, ptr %slot593, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %rgep3256 = getelementptr i8, ptr %p3255, i64 -24
  %ld3257 = load i64, ptr %rgep3256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3257, ptr %slot600, align 8
  %v3258 = load i64, ptr %slot600, align 8
  %op3259 = sub i64 %v3258, 1
  store i64 %op3259, ptr %slot601, align 8
  %v3260 = load i64, ptr %slot601, align 8
  %cmp3261 = icmp eq i64 %v3260, 0
  %cv3262 = zext i1 %cmp3261 to i32
  store i32 %cv3262, ptr %slot602, align 8
  %v3263 = load i32, ptr %slot602, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcglast738, label %bb_rcgdec738
bb_rcglast738:
  %v3266 = load i64, ptr %slot593, align 8
  %op3267 = sub i64 %v3266, 32
  store i64 %op3267, ptr %slot603, align 8
  %v3268 = load i64, ptr %slot593, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %rgep3270 = getelementptr i8, ptr %p3269, i64 -32
  %ld3271 = load i64, ptr %rgep3270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3271, ptr %slot604, align 8
  %v3272 = load i64, ptr %slot604, align 8
  %cmp3273 = icmp ne i64 %v3272, 0
  %cv3274 = zext i1 %cmp3273 to i32
  store i32 %cv3274, ptr %slot605, align 8
  %v3275 = load i32, ptr %slot605, align 8
  %cv3276 = zext i32 %v3275 to i64
  %cond3277 = icmp ne i64 %cv3276, 0
  br i1 %cond3277, label %bb_rcgdec738, label %bb_rcgslow738
bb_rcgslow738:
  %v3278 = load i64, ptr %slot592, align 8
  %v3279 = load i64, ptr %slot589, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v3278, i64 %v3279) nomerge, !dbg !124
  br label %bb_rcgdone738
bb_rcgdec738:
  %v3280 = load i64, ptr %slot601, align 8
  %v3281 = load i64, ptr %slot593, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  %rgep3283 = getelementptr i8, ptr %p3282, i64 -24
  store i64 %v3280, ptr %rgep3283, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear738
bb_rcgclear738:
  %v3284 = load i64, ptr %slot589, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  store i64 0, ptr %p3285, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone738
bb_rcgdone738:
  br label %bb_rcslotdone722
bb_rcslotowner722:
  %v3286 = load i64, ptr %slot20, align 8
  store i64 %v3286, ptr %slot606, align 8
  %v3287 = load i64, ptr %slot589, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  %ld3289 = load i64, ptr %p3288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3289, ptr %slot607, align 8
  %v3290 = load i64, ptr %slot607, align 8
  %cmp3291 = icmp ne i64 %v3290, 0
  %cv3292 = zext i1 %cmp3291 to i32
  store i32 %cv3292, ptr %slot608, align 8
  %v3293 = load i32, ptr %slot608, align 8
  %cv3294 = zext i32 %v3293 to i64
  %cond3295 = icmp ne i64 %cv3294, 0
  br i1 %cond3295, label %bb_rcgnn753, label %bb_rcgdone753
bb_rcgnn753:
  %v3296 = load i64, ptr %slot607, align 8
  %op3297 = sub i64 %v3296, 16
  store i64 %op3297, ptr %slot609, align 8
  %v3298 = load i64, ptr %slot607, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  %rgep3300 = getelementptr i8, ptr %p3299, i64 -16
  %ld3301 = load i64, ptr %rgep3300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3301, ptr %slot610, align 8
  %v3302 = load i64, ptr %slot610, align 8
  %op3303 = and i64 %v3302, 4611686018427387906
  store i64 %op3303, ptr %slot611, align 8
  %v3304 = load i64, ptr %slot611, align 8
  %cmp3305 = icmp ne i64 %v3304, 0
  %cv3306 = zext i1 %cmp3305 to i32
  store i32 %cv3306, ptr %slot612, align 8
  %v3307 = load i32, ptr %slot612, align 8
  %cv3308 = zext i32 %v3307 to i64
  %cond3309 = icmp ne i64 %cv3308, 0
  br i1 %cond3309, label %bb_rcgclear753, label %bb_rcgcounted753
bb_rcgcounted753:
  %v3310 = load i64, ptr %slot607, align 8
  %op3311 = sub i64 %v3310, 32
  store i64 %op3311, ptr %slot613, align 8
  %v3312 = load i64, ptr %slot607, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  %rgep3314 = getelementptr i8, ptr %p3313, i64 -32
  %ld3315 = load i64, ptr %rgep3314, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3315, ptr %slot614, align 8
  %v3316 = load i64, ptr %slot614, align 8
  %op3317 = sub i64 %v3316, 1
  store i64 %op3317, ptr %slot615, align 8
  %v3318 = load i64, ptr %slot615, align 8
  %cmp3319 = icmp eq i64 %v3318, 0
  %cv3320 = zext i1 %cmp3319 to i32
  store i32 %cv3320, ptr %slot616, align 8
  %v3321 = load i32, ptr %slot616, align 8
  %cv3322 = zext i32 %v3321 to i64
  %cond3323 = icmp ne i64 %cv3322, 0
  br i1 %cond3323, label %bb_rcglast753, label %bb_rcgdec753
bb_rcglast753:
  %v3324 = load i64, ptr %slot607, align 8
  %op3325 = sub i64 %v3324, 24
  store i64 %op3325, ptr %slot617, align 8
  %v3326 = load i64, ptr %slot607, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %rgep3328 = getelementptr i8, ptr %p3327, i64 -24
  %ld3329 = load i64, ptr %rgep3328, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3329, ptr %slot618, align 8
  %v3330 = load i64, ptr %slot618, align 8
  %cmp3331 = icmp ne i64 %v3330, 0
  %cv3332 = zext i1 %cmp3331 to i32
  store i32 %cv3332, ptr %slot619, align 8
  %v3333 = load i32, ptr %slot619, align 8
  %cv3334 = zext i32 %v3333 to i64
  %cond3335 = icmp ne i64 %cv3334, 0
  br i1 %cond3335, label %bb_rcgdec753, label %bb_rcgslow753
bb_rcgslow753:
  %v3336 = load i64, ptr %slot606, align 8
  %v3337 = load i64, ptr %slot589, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3336, i64 %v3337) nomerge, !dbg !124
  br label %bb_rcgdone753
bb_rcgdec753:
  %v3338 = load i64, ptr %slot615, align 8
  %v3339 = load i64, ptr %slot607, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %rgep3341 = getelementptr i8, ptr %p3340, i64 -32
  store i64 %v3338, ptr %rgep3341, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear753
bb_rcgclear753:
  %v3342 = load i64, ptr %slot589, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  store i64 0, ptr %p3343, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone753
bb_rcgdone753:
  br label %bb_rcslotdone722
bb_rcslotdone722:
  %v3344 = load i64, ptr %slot5, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %ld3346 = load i32, ptr %p3345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3346, ptr %slot620, align 8
  %v3347 = load i32, ptr %slot620, align 8
  %cv3348 = zext i32 %v3347 to i64
  %cond3349 = icmp ne i64 %cv3348, 0
  br i1 %cond3349, label %bb_rcslotdrop759, label %bb_rcslotdone759
bb_rcslotdrop759:
  %v3350 = load i64, ptr %slot5, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  store i32 0, ptr %p3351, align 4, !alias.scope !3, !noalias !4
  %v3352 = load i64, ptr %slot17, align 8
  store i64 %v3352, ptr %slot621, align 8
  %v3353 = load i64, ptr %slot6, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  %ld3355 = load i32, ptr %p3354, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3355, ptr %slot622, align 8
  %v3356 = load i32, ptr %slot622, align 8
  %op3357 = and i32 %v3356, 28
  store i32 %op3357, ptr %slot623, align 8
  %v3358 = load i32, ptr %slot623, align 8
  %cv3359 = zext i32 %v3358 to i64
  %cond3360 = icmp ne i64 %cv3359, 0
  br i1 %cond3360, label %bb_rcslotrole759, label %bb_rcslotowner759
bb_rcslotrole759:
  %v3361 = load i64, ptr %slot20, align 8
  store i64 %v3361, ptr %slot624, align 8
  %v3362 = load i64, ptr %slot621, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %ld3364 = load i64, ptr %p3363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3364, ptr %slot625, align 8
  %v3365 = load i64, ptr %slot625, align 8
  %cmp3366 = icmp ne i64 %v3365, 0
  %cv3367 = zext i1 %cmp3366 to i32
  store i32 %cv3367, ptr %slot626, align 8
  %v3368 = load i32, ptr %slot626, align 8
  %cv3369 = zext i32 %v3368 to i64
  %cond3370 = icmp ne i64 %cv3369, 0
  br i1 %cond3370, label %bb_rcgnn775, label %bb_rcgdone775
bb_rcgnn775:
  %v3371 = load i64, ptr %slot625, align 8
  %op3372 = sub i64 %v3371, 16
  store i64 %op3372, ptr %slot627, align 8
  %v3373 = load i64, ptr %slot625, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  %rgep3375 = getelementptr i8, ptr %p3374, i64 -16
  %ld3376 = load i64, ptr %rgep3375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3376, ptr %slot628, align 8
  %v3377 = load i64, ptr %slot628, align 8
  %op3378 = and i64 %v3377, 4611686018427387906
  store i64 %op3378, ptr %slot629, align 8
  %v3379 = load i64, ptr %slot629, align 8
  %cmp3380 = icmp ne i64 %v3379, 0
  %cv3381 = zext i1 %cmp3380 to i32
  store i32 %cv3381, ptr %slot630, align 8
  %v3382 = load i32, ptr %slot630, align 8
  %cv3383 = zext i32 %v3382 to i64
  %cond3384 = icmp ne i64 %cv3383, 0
  br i1 %cond3384, label %bb_rcgclear775, label %bb_rcgcounted775
bb_rcgcounted775:
  %v3385 = load i64, ptr %slot625, align 8
  %op3386 = sub i64 %v3385, 24
  store i64 %op3386, ptr %slot631, align 8
  %v3387 = load i64, ptr %slot625, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %rgep3389 = getelementptr i8, ptr %p3388, i64 -24
  %ld3390 = load i64, ptr %rgep3389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3390, ptr %slot632, align 8
  %v3391 = load i64, ptr %slot632, align 8
  %op3392 = sub i64 %v3391, 1
  store i64 %op3392, ptr %slot633, align 8
  %v3393 = load i64, ptr %slot633, align 8
  %cmp3394 = icmp eq i64 %v3393, 0
  %cv3395 = zext i1 %cmp3394 to i32
  store i32 %cv3395, ptr %slot634, align 8
  %v3396 = load i32, ptr %slot634, align 8
  %cv3397 = zext i32 %v3396 to i64
  %cond3398 = icmp ne i64 %cv3397, 0
  br i1 %cond3398, label %bb_rcglast775, label %bb_rcgdec775
bb_rcglast775:
  %v3399 = load i64, ptr %slot625, align 8
  %op3400 = sub i64 %v3399, 32
  store i64 %op3400, ptr %slot635, align 8
  %v3401 = load i64, ptr %slot625, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  %rgep3403 = getelementptr i8, ptr %p3402, i64 -32
  %ld3404 = load i64, ptr %rgep3403, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3404, ptr %slot636, align 8
  %v3405 = load i64, ptr %slot636, align 8
  %cmp3406 = icmp ne i64 %v3405, 0
  %cv3407 = zext i1 %cmp3406 to i32
  store i32 %cv3407, ptr %slot637, align 8
  %v3408 = load i32, ptr %slot637, align 8
  %cv3409 = zext i32 %v3408 to i64
  %cond3410 = icmp ne i64 %cv3409, 0
  br i1 %cond3410, label %bb_rcgdec775, label %bb_rcgslow775
bb_rcgslow775:
  %v3411 = load i64, ptr %slot624, align 8
  %v3412 = load i64, ptr %slot621, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3411, i64 %v3412) nomerge, !dbg !124
  br label %bb_rcgdone775
bb_rcgdec775:
  %v3413 = load i64, ptr %slot633, align 8
  %v3414 = load i64, ptr %slot625, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %rgep3416 = getelementptr i8, ptr %p3415, i64 -24
  store i64 %v3413, ptr %rgep3416, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear775
bb_rcgclear775:
  %v3417 = load i64, ptr %slot621, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  store i64 0, ptr %p3418, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone775
bb_rcgdone775:
  br label %bb_rcslotdone759
bb_rcslotowner759:
  %v3419 = load i64, ptr %slot20, align 8
  store i64 %v3419, ptr %slot638, align 8
  %v3420 = load i64, ptr %slot621, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  %ld3422 = load i64, ptr %p3421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3422, ptr %slot639, align 8
  %v3423 = load i64, ptr %slot639, align 8
  %cmp3424 = icmp ne i64 %v3423, 0
  %cv3425 = zext i1 %cmp3424 to i32
  store i32 %cv3425, ptr %slot640, align 8
  %v3426 = load i32, ptr %slot640, align 8
  %cv3427 = zext i32 %v3426 to i64
  %cond3428 = icmp ne i64 %cv3427, 0
  br i1 %cond3428, label %bb_rcgnn790, label %bb_rcgdone790
bb_rcgnn790:
  %v3429 = load i64, ptr %slot639, align 8
  %op3430 = sub i64 %v3429, 16
  store i64 %op3430, ptr %slot641, align 8
  %v3431 = load i64, ptr %slot639, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  %rgep3433 = getelementptr i8, ptr %p3432, i64 -16
  %ld3434 = load i64, ptr %rgep3433, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3434, ptr %slot642, align 8
  %v3435 = load i64, ptr %slot642, align 8
  %op3436 = and i64 %v3435, 4611686018427387906
  store i64 %op3436, ptr %slot643, align 8
  %v3437 = load i64, ptr %slot643, align 8
  %cmp3438 = icmp ne i64 %v3437, 0
  %cv3439 = zext i1 %cmp3438 to i32
  store i32 %cv3439, ptr %slot644, align 8
  %v3440 = load i32, ptr %slot644, align 8
  %cv3441 = zext i32 %v3440 to i64
  %cond3442 = icmp ne i64 %cv3441, 0
  br i1 %cond3442, label %bb_rcgclear790, label %bb_rcgcounted790
bb_rcgcounted790:
  %v3443 = load i64, ptr %slot639, align 8
  %op3444 = sub i64 %v3443, 32
  store i64 %op3444, ptr %slot645, align 8
  %v3445 = load i64, ptr %slot639, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  %rgep3447 = getelementptr i8, ptr %p3446, i64 -32
  %ld3448 = load i64, ptr %rgep3447, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3448, ptr %slot646, align 8
  %v3449 = load i64, ptr %slot646, align 8
  %op3450 = sub i64 %v3449, 1
  store i64 %op3450, ptr %slot647, align 8
  %v3451 = load i64, ptr %slot647, align 8
  %cmp3452 = icmp eq i64 %v3451, 0
  %cv3453 = zext i1 %cmp3452 to i32
  store i32 %cv3453, ptr %slot648, align 8
  %v3454 = load i32, ptr %slot648, align 8
  %cv3455 = zext i32 %v3454 to i64
  %cond3456 = icmp ne i64 %cv3455, 0
  br i1 %cond3456, label %bb_rcglast790, label %bb_rcgdec790
bb_rcglast790:
  %v3457 = load i64, ptr %slot639, align 8
  %op3458 = sub i64 %v3457, 24
  store i64 %op3458, ptr %slot649, align 8
  %v3459 = load i64, ptr %slot639, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  %rgep3461 = getelementptr i8, ptr %p3460, i64 -24
  %ld3462 = load i64, ptr %rgep3461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3462, ptr %slot650, align 8
  %v3463 = load i64, ptr %slot650, align 8
  %cmp3464 = icmp ne i64 %v3463, 0
  %cv3465 = zext i1 %cmp3464 to i32
  store i32 %cv3465, ptr %slot651, align 8
  %v3466 = load i32, ptr %slot651, align 8
  %cv3467 = zext i32 %v3466 to i64
  %cond3468 = icmp ne i64 %cv3467, 0
  br i1 %cond3468, label %bb_rcgdec790, label %bb_rcgslow790
bb_rcgslow790:
  %v3469 = load i64, ptr %slot638, align 8
  %v3470 = load i64, ptr %slot621, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3469, i64 %v3470) nomerge, !dbg !124
  br label %bb_rcgdone790
bb_rcgdec790:
  %v3471 = load i64, ptr %slot647, align 8
  %v3472 = load i64, ptr %slot639, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %rgep3474 = getelementptr i8, ptr %p3473, i64 -32
  store i64 %v3471, ptr %rgep3474, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear790
bb_rcgclear790:
  %v3475 = load i64, ptr %slot621, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i64 0, ptr %p3476, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone790
bb_rcgdone790:
  br label %bb_rcslotdone759
bb_rcslotdone759:
  %v3477 = load i64, ptr %slot3, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  %ld3479 = load i32, ptr %p3478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3479, ptr %slot652, align 8
  %v3480 = load i32, ptr %slot652, align 8
  %cv3481 = zext i32 %v3480 to i64
  %cond3482 = icmp ne i64 %cv3481, 0
  br i1 %cond3482, label %bb_rcslotdrop796, label %bb_rcslotdone796
bb_rcslotdrop796:
  %v3483 = load i64, ptr %slot3, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  store i32 0, ptr %p3484, align 4, !alias.scope !3, !noalias !4
  %v3485 = load i64, ptr %slot16, align 8
  store i64 %v3485, ptr %slot653, align 8
  %v3486 = load i64, ptr %slot4, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  %ld3488 = load i32, ptr %p3487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3488, ptr %slot654, align 8
  %v3489 = load i32, ptr %slot654, align 8
  %op3490 = and i32 %v3489, 28
  store i32 %op3490, ptr %slot655, align 8
  %v3491 = load i32, ptr %slot655, align 8
  %cv3492 = zext i32 %v3491 to i64
  %cond3493 = icmp ne i64 %cv3492, 0
  br i1 %cond3493, label %bb_rcslotrole796, label %bb_rcslotowner796
bb_rcslotrole796:
  %v3494 = load i64, ptr %slot20, align 8
  store i64 %v3494, ptr %slot656, align 8
  %v3495 = load i64, ptr %slot653, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %ld3497 = load i64, ptr %p3496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3497, ptr %slot657, align 8
  %v3498 = load i64, ptr %slot657, align 8
  %cmp3499 = icmp ne i64 %v3498, 0
  %cv3500 = zext i1 %cmp3499 to i32
  store i32 %cv3500, ptr %slot658, align 8
  %v3501 = load i32, ptr %slot658, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcgnn812, label %bb_rcgdone812
bb_rcgnn812:
  %v3504 = load i64, ptr %slot657, align 8
  %op3505 = sub i64 %v3504, 16
  store i64 %op3505, ptr %slot659, align 8
  %v3506 = load i64, ptr %slot657, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  %rgep3508 = getelementptr i8, ptr %p3507, i64 -16
  %ld3509 = load i64, ptr %rgep3508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3509, ptr %slot660, align 8
  %v3510 = load i64, ptr %slot660, align 8
  %op3511 = and i64 %v3510, 4611686018427387906
  store i64 %op3511, ptr %slot661, align 8
  %v3512 = load i64, ptr %slot661, align 8
  %cmp3513 = icmp ne i64 %v3512, 0
  %cv3514 = zext i1 %cmp3513 to i32
  store i32 %cv3514, ptr %slot662, align 8
  %v3515 = load i32, ptr %slot662, align 8
  %cv3516 = zext i32 %v3515 to i64
  %cond3517 = icmp ne i64 %cv3516, 0
  br i1 %cond3517, label %bb_rcgclear812, label %bb_rcgcounted812
bb_rcgcounted812:
  %v3518 = load i64, ptr %slot657, align 8
  %op3519 = sub i64 %v3518, 24
  store i64 %op3519, ptr %slot663, align 8
  %v3520 = load i64, ptr %slot657, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %rgep3522 = getelementptr i8, ptr %p3521, i64 -24
  %ld3523 = load i64, ptr %rgep3522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3523, ptr %slot664, align 8
  %v3524 = load i64, ptr %slot664, align 8
  %op3525 = sub i64 %v3524, 1
  store i64 %op3525, ptr %slot665, align 8
  %v3526 = load i64, ptr %slot665, align 8
  %cmp3527 = icmp eq i64 %v3526, 0
  %cv3528 = zext i1 %cmp3527 to i32
  store i32 %cv3528, ptr %slot666, align 8
  %v3529 = load i32, ptr %slot666, align 8
  %cv3530 = zext i32 %v3529 to i64
  %cond3531 = icmp ne i64 %cv3530, 0
  br i1 %cond3531, label %bb_rcglast812, label %bb_rcgdec812
bb_rcglast812:
  %v3532 = load i64, ptr %slot657, align 8
  %op3533 = sub i64 %v3532, 32
  store i64 %op3533, ptr %slot667, align 8
  %v3534 = load i64, ptr %slot657, align 8
  %p3535 = inttoptr i64 %v3534 to ptr
  %rgep3536 = getelementptr i8, ptr %p3535, i64 -32
  %ld3537 = load i64, ptr %rgep3536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3537, ptr %slot668, align 8
  %v3538 = load i64, ptr %slot668, align 8
  %cmp3539 = icmp ne i64 %v3538, 0
  %cv3540 = zext i1 %cmp3539 to i32
  store i32 %cv3540, ptr %slot669, align 8
  %v3541 = load i32, ptr %slot669, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcgdec812, label %bb_rcgslow812
bb_rcgslow812:
  %v3544 = load i64, ptr %slot656, align 8
  %v3545 = load i64, ptr %slot653, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3544, i64 %v3545) nomerge, !dbg !124
  br label %bb_rcgdone812
bb_rcgdec812:
  %v3546 = load i64, ptr %slot665, align 8
  %v3547 = load i64, ptr %slot657, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %rgep3549 = getelementptr i8, ptr %p3548, i64 -24
  store i64 %v3546, ptr %rgep3549, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear812
bb_rcgclear812:
  %v3550 = load i64, ptr %slot653, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  store i64 0, ptr %p3551, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone812
bb_rcgdone812:
  br label %bb_rcslotdone796
bb_rcslotowner796:
  %v3552 = load i64, ptr %slot20, align 8
  store i64 %v3552, ptr %slot670, align 8
  %v3553 = load i64, ptr %slot653, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  %ld3555 = load i64, ptr %p3554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3555, ptr %slot671, align 8
  %v3556 = load i64, ptr %slot671, align 8
  %cmp3557 = icmp ne i64 %v3556, 0
  %cv3558 = zext i1 %cmp3557 to i32
  store i32 %cv3558, ptr %slot672, align 8
  %v3559 = load i32, ptr %slot672, align 8
  %cv3560 = zext i32 %v3559 to i64
  %cond3561 = icmp ne i64 %cv3560, 0
  br i1 %cond3561, label %bb_rcgnn827, label %bb_rcgdone827
bb_rcgnn827:
  %v3562 = load i64, ptr %slot671, align 8
  %op3563 = sub i64 %v3562, 16
  store i64 %op3563, ptr %slot673, align 8
  %v3564 = load i64, ptr %slot671, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  %rgep3566 = getelementptr i8, ptr %p3565, i64 -16
  %ld3567 = load i64, ptr %rgep3566, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3567, ptr %slot674, align 8
  %v3568 = load i64, ptr %slot674, align 8
  %op3569 = and i64 %v3568, 4611686018427387906
  store i64 %op3569, ptr %slot675, align 8
  %v3570 = load i64, ptr %slot675, align 8
  %cmp3571 = icmp ne i64 %v3570, 0
  %cv3572 = zext i1 %cmp3571 to i32
  store i32 %cv3572, ptr %slot676, align 8
  %v3573 = load i32, ptr %slot676, align 8
  %cv3574 = zext i32 %v3573 to i64
  %cond3575 = icmp ne i64 %cv3574, 0
  br i1 %cond3575, label %bb_rcgclear827, label %bb_rcgcounted827
bb_rcgcounted827:
  %v3576 = load i64, ptr %slot671, align 8
  %op3577 = sub i64 %v3576, 32
  store i64 %op3577, ptr %slot677, align 8
  %v3578 = load i64, ptr %slot671, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  %rgep3580 = getelementptr i8, ptr %p3579, i64 -32
  %ld3581 = load i64, ptr %rgep3580, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3581, ptr %slot678, align 8
  %v3582 = load i64, ptr %slot678, align 8
  %op3583 = sub i64 %v3582, 1
  store i64 %op3583, ptr %slot679, align 8
  %v3584 = load i64, ptr %slot679, align 8
  %cmp3585 = icmp eq i64 %v3584, 0
  %cv3586 = zext i1 %cmp3585 to i32
  store i32 %cv3586, ptr %slot680, align 8
  %v3587 = load i32, ptr %slot680, align 8
  %cv3588 = zext i32 %v3587 to i64
  %cond3589 = icmp ne i64 %cv3588, 0
  br i1 %cond3589, label %bb_rcglast827, label %bb_rcgdec827
bb_rcglast827:
  %v3590 = load i64, ptr %slot671, align 8
  %op3591 = sub i64 %v3590, 24
  store i64 %op3591, ptr %slot681, align 8
  %v3592 = load i64, ptr %slot671, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  %rgep3594 = getelementptr i8, ptr %p3593, i64 -24
  %ld3595 = load i64, ptr %rgep3594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3595, ptr %slot682, align 8
  %v3596 = load i64, ptr %slot682, align 8
  %cmp3597 = icmp ne i64 %v3596, 0
  %cv3598 = zext i1 %cmp3597 to i32
  store i32 %cv3598, ptr %slot683, align 8
  %v3599 = load i32, ptr %slot683, align 8
  %cv3600 = zext i32 %v3599 to i64
  %cond3601 = icmp ne i64 %cv3600, 0
  br i1 %cond3601, label %bb_rcgdec827, label %bb_rcgslow827
bb_rcgslow827:
  %v3602 = load i64, ptr %slot670, align 8
  %v3603 = load i64, ptr %slot653, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3602, i64 %v3603) nomerge, !dbg !124
  br label %bb_rcgdone827
bb_rcgdec827:
  %v3604 = load i64, ptr %slot679, align 8
  %v3605 = load i64, ptr %slot671, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  %rgep3607 = getelementptr i8, ptr %p3606, i64 -32
  store i64 %v3604, ptr %rgep3607, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear827
bb_rcgclear827:
  %v3608 = load i64, ptr %slot653, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  store i64 0, ptr %p3609, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone827
bb_rcgdone827:
  br label %bb_rcslotdone796
bb_rcslotdone796:
  %v3610 = load i64, ptr %slot555, align 8
  ret i64 %v3610
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_buffer_reserve(ptr, ptr, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_qbe_bytes_from_list(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5", linkageName: "myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9965265108472585450, i64 0, !"myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!122 = !DILocation(line: 11, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
