target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6bb7e405fe7b568af6d34da9612bbe7c36dee5c1d2099dd3b1dfaa901a33874b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v19 = load i64, ptr %slot1, align 8
  %op20 = add i64 %v19, 32
  store i64 %op20, ptr %slot3, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot4, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot5, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot6, align 8
  %v27 = load i64, ptr %slot5, align 8
  %p28 = inttoptr i64 %v27 to ptr
  store i64 0, ptr %p28, align 8, !alias.scope !3, !noalias !4
  %v29 = load i64, ptr %slot2, align 8
  %v30 = load i64, ptr %slot4, align 8
  %p31 = inttoptr i64 %v30 to ptr
  store i64 %v29, ptr %p31, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v32 = load i64, ptr %slot4, align 8
  %p33 = inttoptr i64 %v32 to ptr
  %ld34 = load i64, ptr %p33, align 8, !alias.scope !3, !noalias !4
  store i64 %ld34, ptr %slot7, align 8
  %v35 = load i64, ptr %slot7, align 8
  %v36 = load i64, ptr %slot6, align 8
  %p37 = inttoptr i64 %v36 to ptr
  store i64 %v35, ptr %p37, align 8, !alias.scope !3, !noalias !4
  %v38 = load i64, ptr %slot6, align 8
  %p39 = inttoptr i64 %v38 to ptr
  %ld40 = load i64, ptr %p39, align 8, !alias.scope !3, !noalias !4
  store i64 %ld40, ptr %slot8, align 8
  %v41 = load i64, ptr %slot8, align 8
  %op42 = add i64 %v41, 0
  store i64 %op42, ptr %slot9, align 8
  %v43 = load i64, ptr %slot9, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !4, !noalias !3
  store i64 %ld45, ptr %slot10, align 8
  %v46 = load i64, ptr %slot10, align 8
  %v47 = load i64, ptr %slot6, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot6, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot11, align 8
  %v52 = load i64, ptr %slot5, align 8
  store i64 %v52, ptr %slot12, align 8
  %v53 = load i64, ptr %slot11, align 8
  %v54 = load i64, ptr %slot12, align 8
  %p55 = inttoptr i64 %v54 to ptr
  store i64 %v53, ptr %p55, align 8, !alias.scope !3, !noalias !4
  %v56 = load i64, ptr %slot5, align 8
  %p57 = inttoptr i64 %v56 to ptr
  %ld58 = load i64, ptr %p57, align 8, !alias.scope !3, !noalias !4
  store i64 %ld58, ptr %slot13, align 8
  %v59 = load i64, ptr %slot13, align 8
  %op60 = add i64 %v59, 0
  store i64 %op60, ptr %slot14, align 8
  %v61 = load i64, ptr %slot14, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !6, !noalias !7
  store i64 %ld63, ptr %slot15, align 8
  %v64 = load i64, ptr %slot15, align 8
  %v65 = load i64, ptr %slot6, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 %v64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot6, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot16, align 8
  %v70 = load i64, ptr %slot16, align 8
  %cmp71 = icmp ugt i64 %v70, 9223372036854775807
  %cv72 = zext i1 %cmp71 to i64
  store i64 %cv72, ptr %slot17, align 8
  %v73 = load i64, ptr %slot17, align 8
  %cond74 = icmp ne i64 %v73, 0
  br i1 %cond74, label %bb_cast_overflow11, label %bb_cast_ok11
bb_cast_overflow11:
  %v75 = load i64, ptr %slot1, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %v77 = load i64, ptr %slot16, align 8
  call void @myl_qbe_fail_cast(ptr %p76, i64 %v77, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok11:
  %v78 = load i64, ptr %slot16, align 8
  %v79 = load i64, ptr %slot6, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot6, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot18, align 8
  %v84 = load i64, ptr %slot18, align 8
  ret i64 %v84
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6bb7e405fe7b568af6d34da9612bbe7c36dee5c1d2099dd3b1dfaa901a33874b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6bb7e405fe7b568af6d34da9612bbe7c36dee5c1d2099dd3b1dfaa901a33874b", linkageName: "myl_f_6bb7e405fe7b568af6d34da9612bbe7c36dee5c1d2099dd3b1dfaa901a33874b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7033664550812604043, i64 0, !"myl_f_6bb7e405fe7b568af6d34da9612bbe7c36dee5c1d2099dd3b1dfaa901a33874b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!110 = !DILocation(line: 5, column: 0, scope: !111)
