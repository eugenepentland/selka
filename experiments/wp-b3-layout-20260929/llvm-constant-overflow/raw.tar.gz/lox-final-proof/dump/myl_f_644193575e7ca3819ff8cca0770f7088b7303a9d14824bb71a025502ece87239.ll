target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_644193575e7ca3819ff8cca0770f7088b7303a9d14824bb71a025502ece87239(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %callresult384 = alloca [32 x i8], align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i32, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i32, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i32, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i32, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i32, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i32, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i32, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i32, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i32, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i32, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i32, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i32, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i32, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i32, align 8
  %slot1384 = alloca i32, align 8
  %slot1385 = alloca i32, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i32, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i32, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i32, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i32, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i32, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i32, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i32, align 8
  %slot1443 = alloca i32, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i32, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i32, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i32, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i32, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i32, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i32, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i32, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i32, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i32, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i64, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i32, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i32, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i32, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i32, align 8
  %slot1501 = alloca i32, align 8
  %slot1502 = alloca i32, align 8
  %slot1503 = alloca i32, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i32, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i32, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i32, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i32, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i32, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i32, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i32, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i32, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i32, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i32, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i32, align 8
  %slot1545 = alloca i32, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i32, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i32, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i32, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i32, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i32, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i32, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i32, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i32, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i32, align 8
  %slot1579 = alloca i32, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i64, align 8
  %slot1582 = alloca i32, align 8
  %slot1583 = alloca i32, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i32, align 8
  %slot1586 = alloca i32, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i32, align 8
  %slot1590 = alloca i64, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i32, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i32, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i32, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i32, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i32, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i32, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i32, align 8
  %slot1615 = alloca i32, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i32, align 8
  %slot1618 = alloca i32, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i32, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i32, align 8
  %slot1624 = alloca i32, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i32, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i32, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i32, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i32, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i32, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i32, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i32, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i32, align 8
  %slot1653 = alloca i32, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i32, align 8
  %slot1656 = alloca i32, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i32, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i32, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i32, align 8
  %slot1668 = alloca i64, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i32, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i32, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i32, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i32, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i32, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i32, align 8
  %slot1692 = alloca i64, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i32, align 8
  %slot1696 = alloca i64, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i32, align 8
  %slot1700 = alloca i64, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i32, align 8
  %slot1703 = alloca i64, align 8
  %slot1704 = alloca i64, align 8
  %slot1705 = alloca i32, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i64, align 8
  %slot1711 = alloca i64, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i32, align 8
  %slot1714 = alloca i64, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i32, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i64, align 8
  %slot1719 = alloca i32, align 8
  %slot1720 = alloca i32, align 8
  %slot1721 = alloca i64, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i32, align 8
  %slot1724 = alloca i64, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i32, align 8
  %slot1728 = alloca i64, align 8
  %slot1729 = alloca i64, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i32, align 8
  %slot1732 = alloca i64, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i32, align 8
  %slot1735 = alloca i64, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i32, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i64, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i32, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i32, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i64, align 8
  %slot1748 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1749 = load i64, ptr %slot1, align 8
  %op1750 = add i64 %v1749, 32
  store i64 %op1750, ptr %slot4, align 8
  %mem1751 = alloca i8, i64 8, align 8
  %ptr1752 = ptrtoint ptr %mem1751 to i64
  store i64 %ptr1752, ptr %slot5, align 8
  %mem1753 = alloca i8, i64 8, align 8
  %ptr1754 = ptrtoint ptr %mem1753 to i64
  store i64 %ptr1754, ptr %slot6, align 8
  %mem1755 = alloca i8, i64 8, align 8
  %ptr1756 = ptrtoint ptr %mem1755 to i64
  store i64 %ptr1756, ptr %slot7, align 8
  %mem1757 = alloca i8, i64 8, align 8
  %ptr1758 = ptrtoint ptr %mem1757 to i64
  store i64 %ptr1758, ptr %slot8, align 8
  %mem1759 = alloca i8, i64 8, align 8
  %ptr1760 = ptrtoint ptr %mem1759 to i64
  store i64 %ptr1760, ptr %slot9, align 8
  %mem1761 = alloca i8, i64 8, align 8
  %ptr1762 = ptrtoint ptr %mem1761 to i64
  store i64 %ptr1762, ptr %slot10, align 8
  %mem1763 = alloca i8, i64 8, align 8
  %ptr1764 = ptrtoint ptr %mem1763 to i64
  store i64 %ptr1764, ptr %slot11, align 8
  %mem1765 = alloca i8, i64 8, align 8
  %ptr1766 = ptrtoint ptr %mem1765 to i64
  store i64 %ptr1766, ptr %slot12, align 8
  %mem1767 = alloca i8, i64 8, align 8
  %ptr1768 = ptrtoint ptr %mem1767 to i64
  store i64 %ptr1768, ptr %slot13, align 8
  %mem1769 = alloca i8, i64 8, align 8
  %ptr1770 = ptrtoint ptr %mem1769 to i64
  store i64 %ptr1770, ptr %slot14, align 8
  %mem1771 = alloca i8, i64 8, align 8
  %ptr1772 = ptrtoint ptr %mem1771 to i64
  store i64 %ptr1772, ptr %slot15, align 8
  %mem1773 = alloca i8, i64 8, align 8
  %ptr1774 = ptrtoint ptr %mem1773 to i64
  store i64 %ptr1774, ptr %slot16, align 8
  %mem1775 = alloca i8, i64 8, align 8
  %ptr1776 = ptrtoint ptr %mem1775 to i64
  store i64 %ptr1776, ptr %slot17, align 8
  %mem1777 = alloca i8, i64 8, align 8
  %ptr1778 = ptrtoint ptr %mem1777 to i64
  store i64 %ptr1778, ptr %slot18, align 8
  %mem1779 = alloca i8, i64 8, align 8
  %ptr1780 = ptrtoint ptr %mem1779 to i64
  store i64 %ptr1780, ptr %slot19, align 8
  %mem1781 = alloca i8, i64 8, align 8
  %ptr1782 = ptrtoint ptr %mem1781 to i64
  store i64 %ptr1782, ptr %slot20, align 8
  %mem1783 = alloca i8, i64 8, align 8
  %ptr1784 = ptrtoint ptr %mem1783 to i64
  store i64 %ptr1784, ptr %slot21, align 8
  %mem1785 = alloca i8, i64 8, align 8
  %ptr1786 = ptrtoint ptr %mem1785 to i64
  store i64 %ptr1786, ptr %slot22, align 8
  %mem1787 = alloca i8, i64 8, align 8
  %ptr1788 = ptrtoint ptr %mem1787 to i64
  store i64 %ptr1788, ptr %slot23, align 8
  %mem1789 = alloca i8, i64 32, align 8
  %ptr1790 = ptrtoint ptr %mem1789 to i64
  store i64 %ptr1790, ptr %slot24, align 8
  %mem1791 = alloca i8, i64 32, align 8
  %ptr1792 = ptrtoint ptr %mem1791 to i64
  store i64 %ptr1792, ptr %slot25, align 8
  %mem1793 = alloca i8, i64 8, align 8
  %ptr1794 = ptrtoint ptr %mem1793 to i64
  store i64 %ptr1794, ptr %slot26, align 8
  %mem1795 = alloca i8, i64 8, align 8
  %ptr1796 = ptrtoint ptr %mem1795 to i64
  store i64 %ptr1796, ptr %slot27, align 8
  %mem1797 = alloca i8, i64 32, align 8
  %ptr1798 = ptrtoint ptr %mem1797 to i64
  store i64 %ptr1798, ptr %slot28, align 8
  %mem1799 = alloca i8, i64 32, align 8
  %ptr1800 = ptrtoint ptr %mem1799 to i64
  store i64 %ptr1800, ptr %slot29, align 8
  %v1801 = load i64, ptr %slot29, align 8
  %p1803 = inttoptr i64 %v1801 to ptr
  %gep1804 = getelementptr i8, ptr %p1803, i64 24
  %op1802 = ptrtoint ptr %gep1804 to i64
  store i64 %op1802, ptr %slot30, align 8
  %v1805 = load i64, ptr %slot30, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i64 0, ptr %p1806, align 8, !alias.scope !3, !noalias !4
  %mem1807 = alloca i8, i64 32, align 8
  %ptr1808 = ptrtoint ptr %mem1807 to i64
  store i64 %ptr1808, ptr %slot31, align 8
  %v1809 = load i64, ptr %slot31, align 8
  %p1811 = inttoptr i64 %v1809 to ptr
  %gep1812 = getelementptr i8, ptr %p1811, i64 24
  %op1810 = ptrtoint ptr %gep1812 to i64
  store i64 %op1810, ptr %slot32, align 8
  %v1813 = load i64, ptr %slot32, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i64 0, ptr %p1814, align 8, !alias.scope !3, !noalias !4
  %mem1815 = alloca i8, i64 16, align 8
  %ptr1816 = ptrtoint ptr %mem1815 to i64
  store i64 %ptr1816, ptr %slot33, align 8
  %mem1817 = alloca i8, i64 8, align 8
  %ptr1818 = ptrtoint ptr %mem1817 to i64
  store i64 %ptr1818, ptr %slot34, align 8
  %mem1819 = alloca i8, i64 8, align 8
  %ptr1820 = ptrtoint ptr %mem1819 to i64
  store i64 %ptr1820, ptr %slot35, align 8
  %mem1821 = alloca i8, i64 8, align 8
  %ptr1822 = ptrtoint ptr %mem1821 to i64
  store i64 %ptr1822, ptr %slot36, align 8
  %mem1823 = alloca i8, i64 8, align 8
  %ptr1824 = ptrtoint ptr %mem1823 to i64
  store i64 %ptr1824, ptr %slot37, align 8
  %mem1825 = alloca i8, i64 8, align 8
  %ptr1826 = ptrtoint ptr %mem1825 to i64
  store i64 %ptr1826, ptr %slot38, align 8
  %mem1827 = alloca i8, i64 8, align 8
  %ptr1828 = ptrtoint ptr %mem1827 to i64
  store i64 %ptr1828, ptr %slot39, align 8
  %mem1829 = alloca i8, i64 8, align 8
  %ptr1830 = ptrtoint ptr %mem1829 to i64
  store i64 %ptr1830, ptr %slot40, align 8
  %mem1831 = alloca i8, i64 8, align 8
  %ptr1832 = ptrtoint ptr %mem1831 to i64
  store i64 %ptr1832, ptr %slot41, align 8
  %mem1833 = alloca i8, i64 8, align 8
  %ptr1834 = ptrtoint ptr %mem1833 to i64
  store i64 %ptr1834, ptr %slot42, align 8
  %mem1835 = alloca i8, i64 32, align 8
  %ptr1836 = ptrtoint ptr %mem1835 to i64
  store i64 %ptr1836, ptr %slot43, align 8
  %mem1837 = alloca i8, i64 8, align 8
  %ptr1838 = ptrtoint ptr %mem1837 to i64
  store i64 %ptr1838, ptr %slot44, align 8
  %mem1839 = alloca i8, i64 32, align 8
  %ptr1840 = ptrtoint ptr %mem1839 to i64
  store i64 %ptr1840, ptr %slot45, align 8
  %mem1841 = alloca i8, i64 8, align 8
  %ptr1842 = ptrtoint ptr %mem1841 to i64
  store i64 %ptr1842, ptr %slot46, align 8
  %mem1843 = alloca i8, i64 8, align 8
  %ptr1844 = ptrtoint ptr %mem1843 to i64
  store i64 %ptr1844, ptr %slot47, align 8
  %mem1845 = alloca i8, i64 16, align 8
  %ptr1846 = ptrtoint ptr %mem1845 to i64
  store i64 %ptr1846, ptr %slot48, align 8
  %mem1847 = alloca i8, i64 8, align 8
  %ptr1848 = ptrtoint ptr %mem1847 to i64
  store i64 %ptr1848, ptr %slot49, align 8
  %mem1849 = alloca i8, i64 8, align 8
  %ptr1850 = ptrtoint ptr %mem1849 to i64
  store i64 %ptr1850, ptr %slot50, align 8
  %mem1851 = alloca i8, i64 8, align 8
  %ptr1852 = ptrtoint ptr %mem1851 to i64
  store i64 %ptr1852, ptr %slot51, align 8
  %mem1853 = alloca i8, i64 8, align 8
  %ptr1854 = ptrtoint ptr %mem1853 to i64
  store i64 %ptr1854, ptr %slot52, align 8
  %mem1855 = alloca i8, i64 32, align 8
  %ptr1856 = ptrtoint ptr %mem1855 to i64
  store i64 %ptr1856, ptr %slot53, align 8
  %mem1857 = alloca i8, i64 16, align 8
  %ptr1858 = ptrtoint ptr %mem1857 to i64
  store i64 %ptr1858, ptr %slot54, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem1859 = alloca i8, i64 8, align 8
  %ptr1860 = ptrtoint ptr %mem1859 to i64
  store i64 %ptr1860, ptr %slot55, align 8
  %v1861 = load i64, ptr %slot1, align 8
  %op1862 = add i64 %v1861, 64
  store i64 %op1862, ptr %slot56, align 8
  %v1863 = load i64, ptr %slot56, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1865, ptr %slot57, align 8
  %stack1866 = call ptr @llvm.stacksave()
  %stackaddr1867 = ptrtoint ptr %stack1866 to i64
  %v1868 = load i64, ptr %slot57, align 8
  %cmp1869 = icmp ult i64 %stackaddr1867, %v1868
  %cv1870 = zext i1 %cmp1869 to i64
  store i64 %cv1870, ptr %slot58, align 8
  %v1871 = load i64, ptr %slot58, align 8
  %cond1872 = icmp ne i64 %v1871, 0
  br i1 %cond1872, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v1873 = load i64, ptr %slot1, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  call void @myl_qbe_fail_frame(ptr %p1874) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %v1875 = load i64, ptr %slot36, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  store i64 0, ptr %p1876, align 8, !alias.scope !3, !noalias !4
  %v1877 = load i64, ptr %slot37, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i64 0, ptr %p1878, align 8, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot40, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  store i64 0, ptr %p1880, align 8, !alias.scope !3, !noalias !4
  %v1881 = load i64, ptr %slot44, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i64 0, ptr %p1882, align 8, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot49, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  store i64 0, ptr %p1884, align 8, !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot2, align 8
  %v1886 = load i64, ptr %slot34, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i64 %v1885, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot3, align 8
  %v1889 = load i64, ptr %slot35, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i64 %v1888, ptr %p1890, align 8, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot1, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %call1893 = call ptr @myl_qbe_heap(ptr %p1892) nomerge, !dbg !112
  %calladdr1894 = ptrtoint ptr %call1893 to i64
  store i64 %calladdr1894, ptr %slot59, align 8
  %v1895 = load i64, ptr %slot1, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  %call1897 = call i64 @myl_qbe_region_mark(ptr %p1896) nomerge, !dbg !112
  store i64 %call1897, ptr %slot60, align 8
  %v1898 = load i64, ptr %slot5, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  store i32 0, ptr %p1899, align 4, !alias.scope !3, !noalias !4
  %v1900 = load i64, ptr %slot6, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  store i32 0, ptr %p1901, align 4, !alias.scope !3, !noalias !4
  %v1902 = load i64, ptr %slot7, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i32 0, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot8, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 0, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot9, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 0, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot10, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i32 0, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot11, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 0, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot12, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  store i32 0, ptr %p1913, align 4, !alias.scope !3, !noalias !4
  %v1914 = load i64, ptr %slot13, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i32 0, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot14, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i32 0, ptr %p1917, align 4, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot15, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  store i32 0, ptr %p1919, align 4, !alias.scope !3, !noalias !4
  %v1920 = load i64, ptr %slot16, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i32 0, ptr %p1921, align 4, !alias.scope !3, !noalias !4
  %v1922 = load i64, ptr %slot17, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i32 0, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot18, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  store i32 0, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  %v1926 = load i64, ptr %slot19, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  store i32 0, ptr %p1927, align 4, !alias.scope !3, !noalias !4
  %v1928 = load i64, ptr %slot20, align 8
  %p1929 = inttoptr i64 %v1928 to ptr
  store i32 0, ptr %p1929, align 4, !alias.scope !3, !noalias !4
  %v1930 = load i64, ptr %slot21, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  store i32 0, ptr %p1931, align 4, !alias.scope !3, !noalias !4
  %v1932 = load i64, ptr %slot22, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i32 0, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot23, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i32 0, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot6, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  store i32 2, ptr %p1937, align 4, !alias.scope !3, !noalias !4
  %v1938 = load i64, ptr %slot8, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i32 2, ptr %p1939, align 4, !alias.scope !3, !noalias !4
  %v1940 = load i64, ptr %slot10, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i32 2, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot12, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i32 2, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot14, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  store i32 2, ptr %p1945, align 4, !alias.scope !3, !noalias !4
  %v1946 = load i64, ptr %slot16, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  store i32 2, ptr %p1947, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1948 = load i64, ptr %slot50, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i64 0, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot50, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %ld1952 = load i64, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1952, ptr %slot61, align 8
  %v1953 = load i64, ptr %slot61, align 8
  %cmp1954 = icmp sge i64 %v1953, 0
  %cv1955 = zext i1 %cmp1954 to i64
  store i64 %cv1955, ptr %slot62, align 8
  %v1956 = load i64, ptr %slot62, align 8
  %cond1957 = icmp ne i64 %v1956, 0
  br i1 %cond1957, label %bb_success20, label %bb_failed20
bb_failed20:
  %v1958 = load i64, ptr %slot1, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1959) nomerge, !dbg !114
  unreachable
bb_success20:
  %v1960 = load i64, ptr %slot59, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %p1962 = inttoptr i64 ptrtoint (ptr @myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da to i64) to ptr
  %v1963 = load i64, ptr %slot61, align 8
  %call1964 = call ptr @myl_native_list_new(ptr %p1961, ptr %p1962, i64 %v1963) nomerge, !dbg !114
  %calladdr1965 = ptrtoint ptr %call1964 to i64
  store i64 %calladdr1965, ptr %slot63, align 8
  %v1966 = load i64, ptr %slot63, align 8
  %cond1967 = icmp ne i64 %v1966, 0
  br i1 %cond1967, label %bb_success22, label %bb_failed22
bb_failed22:
  %v1968 = load i64, ptr %slot1, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1969) nomerge, !dbg !114
  unreachable
bb_success22:
  %v1970 = load i64, ptr %slot63, align 8
  %v1971 = load i64, ptr %slot50, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  store i64 %v1970, ptr %p1972, align 8, !alias.scope !3, !noalias !4
  %v1973 = load i64, ptr %slot50, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  %ld1975 = load i64, ptr %p1974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1975, ptr %slot64, align 8
  %v1976 = load i64, ptr %slot64, align 8
  %v1977 = load i64, ptr %slot26, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  store i64 %v1976, ptr %p1978, align 8, !alias.scope !3, !noalias !4
  %v1979 = load i64, ptr %slot26, align 8
  store i64 %v1979, ptr %slot65, align 8
  %v1980 = load i64, ptr %slot28, align 8
  store i64 %v1980, ptr %slot66, align 8
  %v1981 = load i64, ptr %slot65, align 8
  %v1982 = load i64, ptr %slot66, align 8
  %p1983 = inttoptr i64 %v1981 to ptr
  %p1984 = inttoptr i64 %v1982 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1984, ptr %p1983, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot22, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 2, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot21, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 1, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot24, align 8
  store i64 %v1989, ptr %slot67, align 8
  %v1990 = load i64, ptr %slot28, align 8
  store i64 %v1990, ptr %slot68, align 8
  %v1991 = load i64, ptr %slot68, align 8
  %v1992 = load i64, ptr %slot67, align 8
  %p1993 = inttoptr i64 %v1991 to ptr
  %p1994 = inttoptr i64 %v1992 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1994, ptr %p1993, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1995 = load i64, ptr %slot18, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i32 2, ptr %p1996, align 4, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot22, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %ld1999 = load i32, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1999, ptr %slot69, align 8
  %v2000 = load i32, ptr %slot69, align 8
  %v2001 = load i64, ptr %slot18, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  store i32 %v2000, ptr %p2002, align 4, !alias.scope !3, !noalias !4
  %v2003 = load i64, ptr %slot21, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  store i32 0, ptr %p2004, align 4, !alias.scope !3, !noalias !4
  %v2005 = load i64, ptr %slot17, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i32 1, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot67, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %ld2009 = load i64, ptr %p2008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2009, ptr %slot70, align 8
  %v2010 = load i64, ptr %slot70, align 8
  %v2011 = load i64, ptr %slot50, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i64 %v2010, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot18, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %ld2015 = load i32, ptr %p2014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2015, ptr %slot71, align 8
  %v2016 = load i32, ptr %slot71, align 8
  %cmp2017 = icmp eq i32 %v2016, 8
  %cv2018 = zext i1 %cmp2017 to i32
  store i32 %cv2018, ptr %slot72, align 8
  %v2019 = load i64, ptr %slot17, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %ld2021 = load i32, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2021, ptr %slot73, align 8
  %v2022 = load i32, ptr %slot72, align 8
  %v2023 = load i32, ptr %slot73, align 8
  %op2024 = and i32 %v2022, %v2023
  store i32 %op2024, ptr %slot74, align 8
  %v2025 = load i32, ptr %slot74, align 8
  %cv2026 = zext i32 %v2025 to i64
  %cond2027 = icmp ne i64 %cv2026, 0
  br i1 %cond2027, label %bb_rchold37, label %bb_rcordinary37
bb_rchold37:
  %v2028 = load i64, ptr %slot28, align 8
  store i64 %v2028, ptr %slot75, align 8
  %v2029 = load i64, ptr %slot50, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  %ld2031 = load i64, ptr %p2030, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2031, ptr %slot76, align 8
  %v2032 = load i64, ptr %slot76, align 8
  %v2033 = load i64, ptr %slot75, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  store i64 %v2032, ptr %p2034, align 8, !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot22, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  store i32 2, ptr %p2036, align 4, !alias.scope !3, !noalias !4
  %v2037 = load i64, ptr %slot22, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  store i32 8, ptr %p2038, align 4, !alias.scope !3, !noalias !4
  %v2039 = load i64, ptr %slot21, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i32 1, ptr %p2040, align 4, !alias.scope !3, !noalias !4
  %v2041 = load i64, ptr %slot17, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i32 0, ptr %p2042, align 4, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot5, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %ld2045 = load i32, ptr %p2044, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2045, ptr %slot77, align 8
  %v2046 = load i32, ptr %slot77, align 8
  %cv2047 = zext i32 %v2046 to i64
  %cond2048 = icmp ne i64 %cv2047, 0
  br i1 %cond2048, label %bb_rcslotdrop52, label %bb_rcslotdone52
bb_rcslotdrop52:
  %v2049 = load i64, ptr %slot5, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i32 0, ptr %p2050, align 4, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot36, align 8
  store i64 %v2051, ptr %slot78, align 8
  %v2052 = load i64, ptr %slot6, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %ld2054 = load i32, ptr %p2053, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2054, ptr %slot79, align 8
  %v2055 = load i32, ptr %slot79, align 8
  %op2056 = and i32 %v2055, 28
  store i32 %op2056, ptr %slot80, align 8
  %v2057 = load i32, ptr %slot80, align 8
  %cv2058 = zext i32 %v2057 to i64
  %cond2059 = icmp ne i64 %cv2058, 0
  br i1 %cond2059, label %bb_rcslotrole52, label %bb_rcslotowner52
bb_rcslotrole52:
  %v2060 = load i64, ptr %slot59, align 8
  store i64 %v2060, ptr %slot81, align 8
  %v2061 = load i64, ptr %slot78, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %ld2063 = load i64, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2063, ptr %slot82, align 8
  %v2064 = load i64, ptr %slot82, align 8
  %cmp2065 = icmp ne i64 %v2064, 0
  %cv2066 = zext i1 %cmp2065 to i32
  store i32 %cv2066, ptr %slot83, align 8
  %v2067 = load i32, ptr %slot83, align 8
  %cv2068 = zext i32 %v2067 to i64
  %cond2069 = icmp ne i64 %cv2068, 0
  br i1 %cond2069, label %bb_rcgnn68, label %bb_rcgdone68
bb_rcgnn68:
  %v2070 = load i64, ptr %slot82, align 8
  %op2071 = sub i64 %v2070, 16
  store i64 %op2071, ptr %slot84, align 8
  %v2072 = load i64, ptr %slot82, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %rgep2074 = getelementptr i8, ptr %p2073, i64 -16
  %ld2075 = load i64, ptr %rgep2074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2075, ptr %slot85, align 8
  %v2076 = load i64, ptr %slot85, align 8
  %op2077 = and i64 %v2076, 4611686018427387906
  store i64 %op2077, ptr %slot86, align 8
  %v2078 = load i64, ptr %slot86, align 8
  %cmp2079 = icmp ne i64 %v2078, 0
  %cv2080 = zext i1 %cmp2079 to i32
  store i32 %cv2080, ptr %slot87, align 8
  %v2081 = load i32, ptr %slot87, align 8
  %cv2082 = zext i32 %v2081 to i64
  %cond2083 = icmp ne i64 %cv2082, 0
  br i1 %cond2083, label %bb_rcgclear68, label %bb_rcgcounted68
bb_rcgcounted68:
  %v2084 = load i64, ptr %slot82, align 8
  %op2085 = sub i64 %v2084, 24
  store i64 %op2085, ptr %slot88, align 8
  %v2086 = load i64, ptr %slot82, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %rgep2088 = getelementptr i8, ptr %p2087, i64 -24
  %ld2089 = load i64, ptr %rgep2088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2089, ptr %slot89, align 8
  %v2090 = load i64, ptr %slot89, align 8
  %op2091 = sub i64 %v2090, 1
  store i64 %op2091, ptr %slot90, align 8
  %v2092 = load i64, ptr %slot90, align 8
  %cmp2093 = icmp eq i64 %v2092, 0
  %cv2094 = zext i1 %cmp2093 to i32
  store i32 %cv2094, ptr %slot91, align 8
  %v2095 = load i32, ptr %slot91, align 8
  %cv2096 = zext i32 %v2095 to i64
  %cond2097 = icmp ne i64 %cv2096, 0
  br i1 %cond2097, label %bb_rcglast68, label %bb_rcgdec68
bb_rcglast68:
  %v2098 = load i64, ptr %slot82, align 8
  %op2099 = sub i64 %v2098, 32
  store i64 %op2099, ptr %slot92, align 8
  %v2100 = load i64, ptr %slot82, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %rgep2102 = getelementptr i8, ptr %p2101, i64 -32
  %ld2103 = load i64, ptr %rgep2102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2103, ptr %slot93, align 8
  %v2104 = load i64, ptr %slot93, align 8
  %cmp2105 = icmp ne i64 %v2104, 0
  %cv2106 = zext i1 %cmp2105 to i32
  store i32 %cv2106, ptr %slot94, align 8
  %v2107 = load i32, ptr %slot94, align 8
  %cv2108 = zext i32 %v2107 to i64
  %cond2109 = icmp ne i64 %cv2108, 0
  br i1 %cond2109, label %bb_rcgdec68, label %bb_rcgslow68
bb_rcgslow68:
  %v2110 = load i64, ptr %slot81, align 8
  %v2111 = load i64, ptr %slot78, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v2110, i64 %v2111) nomerge, !dbg !116
  br label %bb_rcgdone68
bb_rcgdec68:
  %v2112 = load i64, ptr %slot90, align 8
  %v2113 = load i64, ptr %slot82, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %rgep2115 = getelementptr i8, ptr %p2114, i64 -24
  store i64 %v2112, ptr %rgep2115, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear68
bb_rcgclear68:
  %v2116 = load i64, ptr %slot78, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  store i64 0, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone68
bb_rcgdone68:
  br label %bb_rcslotdone52
bb_rcslotowner52:
  %v2118 = load i64, ptr %slot59, align 8
  store i64 %v2118, ptr %slot95, align 8
  %v2119 = load i64, ptr %slot78, align 8
  %p2120 = inttoptr i64 %v2119 to ptr
  %ld2121 = load i64, ptr %p2120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2121, ptr %slot96, align 8
  %v2122 = load i64, ptr %slot96, align 8
  %cmp2123 = icmp ne i64 %v2122, 0
  %cv2124 = zext i1 %cmp2123 to i32
  store i32 %cv2124, ptr %slot97, align 8
  %v2125 = load i32, ptr %slot97, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcgnn83, label %bb_rcgdone83
bb_rcgnn83:
  %v2128 = load i64, ptr %slot96, align 8
  %op2129 = sub i64 %v2128, 16
  store i64 %op2129, ptr %slot98, align 8
  %v2130 = load i64, ptr %slot96, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  %rgep2132 = getelementptr i8, ptr %p2131, i64 -16
  %ld2133 = load i64, ptr %rgep2132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2133, ptr %slot99, align 8
  %v2134 = load i64, ptr %slot99, align 8
  %op2135 = and i64 %v2134, 4611686018427387906
  store i64 %op2135, ptr %slot100, align 8
  %v2136 = load i64, ptr %slot100, align 8
  %cmp2137 = icmp ne i64 %v2136, 0
  %cv2138 = zext i1 %cmp2137 to i32
  store i32 %cv2138, ptr %slot101, align 8
  %v2139 = load i32, ptr %slot101, align 8
  %cv2140 = zext i32 %v2139 to i64
  %cond2141 = icmp ne i64 %cv2140, 0
  br i1 %cond2141, label %bb_rcgclear83, label %bb_rcgcounted83
bb_rcgcounted83:
  %v2142 = load i64, ptr %slot96, align 8
  %op2143 = sub i64 %v2142, 32
  store i64 %op2143, ptr %slot102, align 8
  %v2144 = load i64, ptr %slot96, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %rgep2146 = getelementptr i8, ptr %p2145, i64 -32
  %ld2147 = load i64, ptr %rgep2146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2147, ptr %slot103, align 8
  %v2148 = load i64, ptr %slot103, align 8
  %op2149 = sub i64 %v2148, 1
  store i64 %op2149, ptr %slot104, align 8
  %v2150 = load i64, ptr %slot104, align 8
  %cmp2151 = icmp eq i64 %v2150, 0
  %cv2152 = zext i1 %cmp2151 to i32
  store i32 %cv2152, ptr %slot105, align 8
  %v2153 = load i32, ptr %slot105, align 8
  %cv2154 = zext i32 %v2153 to i64
  %cond2155 = icmp ne i64 %cv2154, 0
  br i1 %cond2155, label %bb_rcglast83, label %bb_rcgdec83
bb_rcglast83:
  %v2156 = load i64, ptr %slot96, align 8
  %op2157 = sub i64 %v2156, 24
  store i64 %op2157, ptr %slot106, align 8
  %v2158 = load i64, ptr %slot96, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %rgep2160 = getelementptr i8, ptr %p2159, i64 -24
  %ld2161 = load i64, ptr %rgep2160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2161, ptr %slot107, align 8
  %v2162 = load i64, ptr %slot107, align 8
  %cmp2163 = icmp ne i64 %v2162, 0
  %cv2164 = zext i1 %cmp2163 to i32
  store i32 %cv2164, ptr %slot108, align 8
  %v2165 = load i32, ptr %slot108, align 8
  %cv2166 = zext i32 %v2165 to i64
  %cond2167 = icmp ne i64 %cv2166, 0
  br i1 %cond2167, label %bb_rcgdec83, label %bb_rcgslow83
bb_rcgslow83:
  %v2168 = load i64, ptr %slot95, align 8
  %v2169 = load i64, ptr %slot78, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2168, i64 %v2169) nomerge, !dbg !116
  br label %bb_rcgdone83
bb_rcgdec83:
  %v2170 = load i64, ptr %slot104, align 8
  %v2171 = load i64, ptr %slot96, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %rgep2173 = getelementptr i8, ptr %p2172, i64 -32
  store i64 %v2170, ptr %rgep2173, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear83
bb_rcgclear83:
  %v2174 = load i64, ptr %slot78, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i64 0, ptr %p2175, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone83
bb_rcgdone83:
  br label %bb_rcslotdone52
bb_rcslotdone52:
  %v2176 = load i64, ptr %slot36, align 8
  store i64 %v2176, ptr %slot109, align 8
  %v2177 = load i64, ptr %slot75, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  %ld2179 = load i64, ptr %p2178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2179, ptr %slot110, align 8
  %v2180 = load i64, ptr %slot110, align 8
  %v2181 = load i64, ptr %slot109, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i64 %v2180, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  %v2183 = load i64, ptr %slot6, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i32 2, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot6, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 8, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot5, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i32 1, ptr %p2188, align 4, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot21, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i32 0, ptr %p2190, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined37
bb_rcordinary37:
  %v2191 = load i64, ptr %slot50, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i64, ptr %p2192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2193, ptr %slot111, align 8
  %v2194 = load i64, ptr %slot111, align 8
  %v2195 = load i64, ptr %slot26, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i64 %v2194, ptr %p2196, align 8, !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot26, align 8
  store i64 %v2197, ptr %slot112, align 8
  %v2198 = load i64, ptr %slot17, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  %ld2200 = load i32, ptr %p2199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2200, ptr %slot113, align 8
  %v2201 = load i64, ptr %slot18, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  %ld2203 = load i32, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2203, ptr %slot114, align 8
  %v2204 = load i32, ptr %slot114, align 8
  %op2205 = and i32 %v2204, 24
  store i32 %op2205, ptr %slot114, align 8
  %v2206 = load i32, ptr %slot114, align 8
  %cmp2207 = icmp eq i32 %v2206, 0
  %cv2208 = zext i1 %cmp2207 to i32
  store i32 %cv2208, ptr %slot115, align 8
  %v2209 = load i32, ptr %slot113, align 8
  %v2210 = load i32, ptr %slot115, align 8
  %op2211 = and i32 %v2209, %v2210
  store i32 %op2211, ptr %slot116, align 8
  %v2212 = load i32, ptr %slot116, align 8
  %cv2213 = zext i32 %v2212 to i64
  %cond2214 = icmp ne i64 %cv2213, 0
  br i1 %cond2214, label %bb_rcprivateown101, label %bb_rcprivateloan101
bb_rcprivateown101:
  %v2215 = load i64, ptr %slot28, align 8
  store i64 %v2215, ptr %slot117, align 8
  %v2216 = load i64, ptr %slot60, align 8
  store i64 %v2216, ptr %slot118, align 8
  %v2217 = load i64, ptr %slot112, align 8
  %v2218 = load i64, ptr %slot117, align 8
  %op2219 = sub i64 %v2217, %v2218
  store i64 %op2219, ptr %slot119, align 8
  %v2220 = load i64, ptr %slot117, align 8
  %v2221 = load i64, ptr %slot112, align 8
  %op2222 = sub i64 %v2220, %v2221
  store i64 %op2222, ptr %slot120, align 8
  %v2223 = load i64, ptr %slot119, align 8
  %cmp2224 = icmp ult i64 %v2223, 8
  %cv2225 = zext i1 %cmp2224 to i32
  store i32 %cv2225, ptr %slot121, align 8
  %v2226 = load i64, ptr %slot120, align 8
  %cmp2227 = icmp ult i64 %v2226, 8
  %cv2228 = zext i1 %cmp2227 to i32
  store i32 %cv2228, ptr %slot122, align 8
  %v2229 = load i32, ptr %slot121, align 8
  %v2230 = load i32, ptr %slot122, align 8
  %op2231 = or i32 %v2229, %v2230
  store i32 %op2231, ptr %slot123, align 8
  %v2232 = load i32, ptr %slot123, align 8
  %cv2233 = zext i32 %v2232 to i64
  %cond2234 = icmp ne i64 %cv2233, 0
  br i1 %cond2234, label %bb_rcmoveslow104, label %bb_rcmovecheck104
bb_rcmovecheck104:
  %v2235 = load i64, ptr %slot112, align 8
  %p2237 = inttoptr i64 %v2235 to ptr
  %gep2238 = getelementptr i8, ptr %p2237, i64 0
  %op2236 = ptrtoint ptr %gep2238 to i64
  store i64 %op2236, ptr %slot124, align 8
  %v2239 = load i64, ptr %slot124, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  %ld2241 = load i64, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2241, ptr %slot125, align 8
  %v2242 = load i64, ptr %slot125, align 8
  %cmp2243 = icmp ne i64 %v2242, 0
  %cv2244 = zext i1 %cmp2243 to i32
  store i32 %cv2244, ptr %slot126, align 8
  %v2245 = load i32, ptr %slot126, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcmoveheader112, label %bb_rcmovenext112
bb_rcmoveheader112:
  %v2248 = load i64, ptr %slot125, align 8
  %op2249 = sub i64 %v2248, 16
  store i64 %op2249, ptr %slot127, align 8
  %v2250 = load i64, ptr %slot125, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %rgep2252 = getelementptr i8, ptr %p2251, i64 -16
  %ld2253 = load i64, ptr %rgep2252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2253, ptr %slot128, align 8
  %v2254 = load i64, ptr %slot128, align 8
  %op2255 = and i64 %v2254, 5764607523034234881
  store i64 %op2255, ptr %slot129, align 8
  %v2256 = load i64, ptr %slot129, align 8
  %cmp2257 = icmp ne i64 %v2256, 0
  %cv2258 = zext i1 %cmp2257 to i32
  store i32 %cv2258, ptr %slot130, align 8
  %v2259 = load i32, ptr %slot130, align 8
  %cv2260 = zext i32 %v2259 to i64
  %cond2261 = icmp ne i64 %cv2260, 0
  br i1 %cond2261, label %bb_rcmoveslow104, label %bb_rcmovenext112
bb_rcmovenext112:
  %v2262 = load i64, ptr %slot112, align 8
  %v2263 = load i64, ptr %slot117, align 8
  %p2264 = inttoptr i64 %v2262 to ptr
  %p2265 = inttoptr i64 %v2263 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2265, ptr %p2264, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot112, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  store i64 0, ptr %p2267, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved104
bb_rcmoveslow104:
  %v2268 = load i64, ptr %slot59, align 8
  %v2269 = load i64, ptr %slot117, align 8
  %v2270 = load i64, ptr %slot112, align 8
  %v2271 = load i64, ptr %slot118, align 8
  %cv2272 = trunc i64 %v2271 to i32
  %call2273 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v2268, i64 %v2269, i64 %v2270, i32 %cv2272) nomerge, !dbg !116
  store i32 %call2273, ptr %slot131, align 8
  %v2274 = load i32, ptr %slot131, align 8
  %cv2275 = zext i32 %v2274 to i64
  %cond2276 = icmp ne i64 %cv2275, 0
  br i1 %cond2276, label %bb_rcsuccess119, label %bb_rcfailure119
bb_rcfailure119:
  %v2277 = load i64, ptr %slot59, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %call2279 = call i32 @myl_rc_take_failure(ptr %p2278) nomerge, !dbg !116
  store i32 %call2279, ptr %slot132, align 8
  %v2280 = load i64, ptr %slot1, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %v2282 = load i32, ptr %slot132, align 8
  %call2283 = call i32 @myl_qbe_rc_status(ptr %p2281, i32 %v2282) nomerge, !dbg !116
  store i32 %call2283, ptr %slot133, align 8
  br label %bb_failure
bb_rcsuccess119:
  br label %bb_rcmoved104
bb_rcmoved104:
  %v2284 = load i64, ptr %slot17, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 0, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot22, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  store i32 2, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  %v2288 = load i64, ptr %slot21, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i32 1, ptr %p2289, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared101
bb_rcprivateloan101:
  %v2290 = load i64, ptr %slot17, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i32, ptr %p2291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2292, ptr %slot134, align 8
  %v2293 = load i64, ptr %slot18, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  %ld2295 = load i32, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2295, ptr %slot135, align 8
  %v2296 = load i32, ptr %slot135, align 8
  %cmp2297 = icmp eq i32 %v2296, 16
  %cv2298 = zext i1 %cmp2297 to i32
  store i32 %cv2298, ptr %slot136, align 8
  %v2299 = load i32, ptr %slot136, align 8
  %v2300 = load i32, ptr %slot134, align 8
  %op2301 = and i32 %v2299, %v2300
  store i32 %op2301, ptr %slot136, align 8
  %v2302 = load i32, ptr %slot136, align 8
  %cv2303 = zext i32 %v2302 to i64
  %cond2304 = icmp ne i64 %cv2303, 0
  br i1 %cond2304, label %bb_rcprivatemove101, label %bb_rcprivatenew101
bb_rcprivatemove101:
  %v2305 = load i64, ptr %slot28, align 8
  store i64 %v2305, ptr %slot137, align 8
  %v2306 = load i64, ptr %slot112, align 8
  %v2307 = load i64, ptr %slot137, align 8
  %p2308 = inttoptr i64 %v2306 to ptr
  %p2309 = inttoptr i64 %v2307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2309, ptr %p2308, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2310 = load i64, ptr %slot112, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  store i64 0, ptr %p2311, align 8, !alias.scope !3, !noalias !4
  %v2312 = load i64, ptr %slot22, align 8
  %p2313 = inttoptr i64 %v2312 to ptr
  store i32 2, ptr %p2313, align 4, !alias.scope !3, !noalias !4
  %v2314 = load i64, ptr %slot22, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 16, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot21, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  store i32 1, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  %v2318 = load i64, ptr %slot17, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  store i32 0, ptr %p2319, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared101
bb_rcprivatenew101:
  %v2320 = load i64, ptr %slot28, align 8
  store i64 %v2320, ptr %slot138, align 8
  %v2321 = load i64, ptr %slot112, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  %ld2323 = load i64, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2323, ptr %slot139, align 8
  %v2324 = load i64, ptr %slot139, align 8
  %cmp2325 = icmp ne i64 %v2324, 0
  %cv2326 = zext i1 %cmp2325 to i32
  store i32 %cv2326, ptr %slot140, align 8
  %v2327 = load i32, ptr %slot140, align 8
  %cv2328 = zext i32 %v2327 to i64
  %cond2329 = icmp ne i64 %cv2328, 0
  br i1 %cond2329, label %bb_rcgnn137, label %bb_rcgstore137
bb_rcgnn137:
  %v2330 = load i64, ptr %slot139, align 8
  %op2331 = sub i64 %v2330, 16
  store i64 %op2331, ptr %slot141, align 8
  %v2332 = load i64, ptr %slot139, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %rgep2334 = getelementptr i8, ptr %p2333, i64 -16
  %ld2335 = load i64, ptr %rgep2334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2335, ptr %slot142, align 8
  %v2336 = load i64, ptr %slot142, align 8
  %op2337 = and i64 %v2336, 4611686018427387906
  store i64 %op2337, ptr %slot143, align 8
  %v2338 = load i64, ptr %slot143, align 8
  %cmp2339 = icmp ne i64 %v2338, 0
  %cv2340 = zext i1 %cmp2339 to i32
  store i32 %cv2340, ptr %slot144, align 8
  %v2341 = load i32, ptr %slot144, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcgstore137, label %bb_rcginc137
bb_rcginc137:
  %v2344 = load i64, ptr %slot139, align 8
  %op2345 = sub i64 %v2344, 24
  store i64 %op2345, ptr %slot145, align 8
  %v2346 = load i64, ptr %slot139, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %rgep2348 = getelementptr i8, ptr %p2347, i64 -24
  %ld2349 = load i64, ptr %rgep2348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2349, ptr %slot146, align 8
  %v2350 = load i64, ptr %slot146, align 8
  %op2351 = add i64 %v2350, 1
  store i64 %op2351, ptr %slot147, align 8
  %v2352 = load i64, ptr %slot147, align 8
  %cmp2353 = icmp eq i64 %v2352, 0
  %cv2354 = zext i1 %cmp2353 to i32
  store i32 %cv2354, ptr %slot148, align 8
  %v2355 = load i32, ptr %slot148, align 8
  %cv2356 = zext i32 %v2355 to i64
  %cond2357 = icmp ne i64 %cv2356, 0
  br i1 %cond2357, label %bb_rcglimit137, label %bb_rcgcapacity137
bb_rcglimit137:
  %v2358 = load i64, ptr %slot1, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %call2360 = call i32 @myl_qbe_rc_status(ptr %p2359, i32 2) nomerge, !dbg !116
  store i32 %call2360, ptr %slot149, align 8
  br label %bb_failure
bb_rcgcapacity137:
  %v2361 = load i64, ptr %slot147, align 8
  %v2362 = load i64, ptr %slot139, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %rgep2364 = getelementptr i8, ptr %p2363, i64 -24
  store i64 %v2361, ptr %rgep2364, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore137
bb_rcgstore137:
  %v2365 = load i64, ptr %slot139, align 8
  %v2366 = load i64, ptr %slot138, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  store i64 %v2365, ptr %p2367, align 8, !alias.scope !3, !noalias !4
  %v2368 = load i64, ptr %slot22, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  store i32 2, ptr %p2369, align 4, !alias.scope !3, !noalias !4
  %v2370 = load i64, ptr %slot22, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i32 16, ptr %p2371, align 4, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot21, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i32 1, ptr %p2373, align 4, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot17, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %ld2376 = load i32, ptr %p2375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2376, ptr %slot150, align 8
  %v2377 = load i32, ptr %slot150, align 8
  %cv2378 = zext i32 %v2377 to i64
  %cond2379 = icmp ne i64 %cv2378, 0
  br i1 %cond2379, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v2380 = load i64, ptr %slot17, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i32 0, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot24, align 8
  store i64 %v2382, ptr %slot151, align 8
  %v2383 = load i64, ptr %slot18, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i32, ptr %p2384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2385, ptr %slot152, align 8
  %v2386 = load i32, ptr %slot152, align 8
  %op2387 = and i32 %v2386, 28
  store i32 %op2387, ptr %slot153, align 8
  %v2388 = load i32, ptr %slot153, align 8
  %cv2389 = zext i32 %v2388 to i64
  %cond2390 = icmp ne i64 %cv2389, 0
  br i1 %cond2390, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v2391 = load i64, ptr %slot59, align 8
  store i64 %v2391, ptr %slot154, align 8
  %v2392 = load i64, ptr %slot151, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  %ld2394 = load i64, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2394, ptr %slot155, align 8
  %v2395 = load i64, ptr %slot155, align 8
  %cmp2396 = icmp ne i64 %v2395, 0
  %cv2397 = zext i1 %cmp2396 to i32
  store i32 %cv2397, ptr %slot156, align 8
  %v2398 = load i32, ptr %slot156, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcgnn169, label %bb_rcgdone169
bb_rcgnn169:
  %v2401 = load i64, ptr %slot155, align 8
  %op2402 = sub i64 %v2401, 16
  store i64 %op2402, ptr %slot157, align 8
  %v2403 = load i64, ptr %slot155, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %rgep2405 = getelementptr i8, ptr %p2404, i64 -16
  %ld2406 = load i64, ptr %rgep2405, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2406, ptr %slot158, align 8
  %v2407 = load i64, ptr %slot158, align 8
  %op2408 = and i64 %v2407, 4611686018427387906
  store i64 %op2408, ptr %slot159, align 8
  %v2409 = load i64, ptr %slot159, align 8
  %cmp2410 = icmp ne i64 %v2409, 0
  %cv2411 = zext i1 %cmp2410 to i32
  store i32 %cv2411, ptr %slot160, align 8
  %v2412 = load i32, ptr %slot160, align 8
  %cv2413 = zext i32 %v2412 to i64
  %cond2414 = icmp ne i64 %cv2413, 0
  br i1 %cond2414, label %bb_rcgclear169, label %bb_rcgcounted169
bb_rcgcounted169:
  %v2415 = load i64, ptr %slot155, align 8
  %op2416 = sub i64 %v2415, 24
  store i64 %op2416, ptr %slot161, align 8
  %v2417 = load i64, ptr %slot155, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  %rgep2419 = getelementptr i8, ptr %p2418, i64 -24
  %ld2420 = load i64, ptr %rgep2419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2420, ptr %slot162, align 8
  %v2421 = load i64, ptr %slot162, align 8
  %op2422 = sub i64 %v2421, 1
  store i64 %op2422, ptr %slot163, align 8
  %v2423 = load i64, ptr %slot163, align 8
  %cmp2424 = icmp eq i64 %v2423, 0
  %cv2425 = zext i1 %cmp2424 to i32
  store i32 %cv2425, ptr %slot164, align 8
  %v2426 = load i32, ptr %slot164, align 8
  %cv2427 = zext i32 %v2426 to i64
  %cond2428 = icmp ne i64 %cv2427, 0
  br i1 %cond2428, label %bb_rcglast169, label %bb_rcgdec169
bb_rcglast169:
  %v2429 = load i64, ptr %slot155, align 8
  %op2430 = sub i64 %v2429, 32
  store i64 %op2430, ptr %slot165, align 8
  %v2431 = load i64, ptr %slot155, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  %rgep2433 = getelementptr i8, ptr %p2432, i64 -32
  %ld2434 = load i64, ptr %rgep2433, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2434, ptr %slot166, align 8
  %v2435 = load i64, ptr %slot166, align 8
  %cmp2436 = icmp ne i64 %v2435, 0
  %cv2437 = zext i1 %cmp2436 to i32
  store i32 %cv2437, ptr %slot167, align 8
  %v2438 = load i32, ptr %slot167, align 8
  %cv2439 = zext i32 %v2438 to i64
  %cond2440 = icmp ne i64 %cv2439, 0
  br i1 %cond2440, label %bb_rcgdec169, label %bb_rcgslow169
bb_rcgslow169:
  %v2441 = load i64, ptr %slot154, align 8
  %v2442 = load i64, ptr %slot151, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v2441, i64 %v2442) nomerge, !dbg !116
  br label %bb_rcgdone169
bb_rcgdec169:
  %v2443 = load i64, ptr %slot163, align 8
  %v2444 = load i64, ptr %slot155, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %rgep2446 = getelementptr i8, ptr %p2445, i64 -24
  store i64 %v2443, ptr %rgep2446, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear169
bb_rcgclear169:
  %v2447 = load i64, ptr %slot151, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  store i64 0, ptr %p2448, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone169
bb_rcgdone169:
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v2449 = load i64, ptr %slot59, align 8
  store i64 %v2449, ptr %slot168, align 8
  %v2450 = load i64, ptr %slot151, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  %ld2452 = load i64, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2452, ptr %slot169, align 8
  %v2453 = load i64, ptr %slot169, align 8
  %cmp2454 = icmp ne i64 %v2453, 0
  %cv2455 = zext i1 %cmp2454 to i32
  store i32 %cv2455, ptr %slot170, align 8
  %v2456 = load i32, ptr %slot170, align 8
  %cv2457 = zext i32 %v2456 to i64
  %cond2458 = icmp ne i64 %cv2457, 0
  br i1 %cond2458, label %bb_rcgnn184, label %bb_rcgdone184
bb_rcgnn184:
  %v2459 = load i64, ptr %slot169, align 8
  %op2460 = sub i64 %v2459, 16
  store i64 %op2460, ptr %slot171, align 8
  %v2461 = load i64, ptr %slot169, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  %rgep2463 = getelementptr i8, ptr %p2462, i64 -16
  %ld2464 = load i64, ptr %rgep2463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2464, ptr %slot172, align 8
  %v2465 = load i64, ptr %slot172, align 8
  %op2466 = and i64 %v2465, 4611686018427387906
  store i64 %op2466, ptr %slot173, align 8
  %v2467 = load i64, ptr %slot173, align 8
  %cmp2468 = icmp ne i64 %v2467, 0
  %cv2469 = zext i1 %cmp2468 to i32
  store i32 %cv2469, ptr %slot174, align 8
  %v2470 = load i32, ptr %slot174, align 8
  %cv2471 = zext i32 %v2470 to i64
  %cond2472 = icmp ne i64 %cv2471, 0
  br i1 %cond2472, label %bb_rcgclear184, label %bb_rcgcounted184
bb_rcgcounted184:
  %v2473 = load i64, ptr %slot169, align 8
  %op2474 = sub i64 %v2473, 32
  store i64 %op2474, ptr %slot175, align 8
  %v2475 = load i64, ptr %slot169, align 8
  %p2476 = inttoptr i64 %v2475 to ptr
  %rgep2477 = getelementptr i8, ptr %p2476, i64 -32
  %ld2478 = load i64, ptr %rgep2477, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2478, ptr %slot176, align 8
  %v2479 = load i64, ptr %slot176, align 8
  %op2480 = sub i64 %v2479, 1
  store i64 %op2480, ptr %slot177, align 8
  %v2481 = load i64, ptr %slot177, align 8
  %cmp2482 = icmp eq i64 %v2481, 0
  %cv2483 = zext i1 %cmp2482 to i32
  store i32 %cv2483, ptr %slot178, align 8
  %v2484 = load i32, ptr %slot178, align 8
  %cv2485 = zext i32 %v2484 to i64
  %cond2486 = icmp ne i64 %cv2485, 0
  br i1 %cond2486, label %bb_rcglast184, label %bb_rcgdec184
bb_rcglast184:
  %v2487 = load i64, ptr %slot169, align 8
  %op2488 = sub i64 %v2487, 24
  store i64 %op2488, ptr %slot179, align 8
  %v2489 = load i64, ptr %slot169, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %rgep2491 = getelementptr i8, ptr %p2490, i64 -24
  %ld2492 = load i64, ptr %rgep2491, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2492, ptr %slot180, align 8
  %v2493 = load i64, ptr %slot180, align 8
  %cmp2494 = icmp ne i64 %v2493, 0
  %cv2495 = zext i1 %cmp2494 to i32
  store i32 %cv2495, ptr %slot181, align 8
  %v2496 = load i32, ptr %slot181, align 8
  %cv2497 = zext i32 %v2496 to i64
  %cond2498 = icmp ne i64 %cv2497, 0
  br i1 %cond2498, label %bb_rcgdec184, label %bb_rcgslow184
bb_rcgslow184:
  %v2499 = load i64, ptr %slot168, align 8
  %v2500 = load i64, ptr %slot151, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2499, i64 %v2500) nomerge, !dbg !116
  br label %bb_rcgdone184
bb_rcgdec184:
  %v2501 = load i64, ptr %slot177, align 8
  %v2502 = load i64, ptr %slot169, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %rgep2504 = getelementptr i8, ptr %p2503, i64 -32
  store i64 %v2501, ptr %rgep2504, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear184
bb_rcgclear184:
  %v2505 = load i64, ptr %slot151, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  store i64 0, ptr %p2506, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone184
bb_rcgdone184:
  br label %bb_rcslotdone153
bb_rcslotdone153:
  br label %bb_rcprivateprepared101
bb_rcprivateprepared101:
  %v2507 = load i64, ptr %slot5, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %ld2509 = load i32, ptr %p2508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2509, ptr %slot182, align 8
  %v2510 = load i32, ptr %slot182, align 8
  %cv2511 = zext i32 %v2510 to i64
  %cond2512 = icmp ne i64 %cv2511, 0
  br i1 %cond2512, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v2513 = load i64, ptr %slot5, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i32 0, ptr %p2514, align 4, !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot36, align 8
  store i64 %v2515, ptr %slot183, align 8
  %v2516 = load i64, ptr %slot6, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  %ld2518 = load i32, ptr %p2517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2518, ptr %slot184, align 8
  %v2519 = load i32, ptr %slot184, align 8
  %op2520 = and i32 %v2519, 28
  store i32 %op2520, ptr %slot185, align 8
  %v2521 = load i32, ptr %slot185, align 8
  %cv2522 = zext i32 %v2521 to i64
  %cond2523 = icmp ne i64 %cv2522, 0
  br i1 %cond2523, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v2524 = load i64, ptr %slot59, align 8
  store i64 %v2524, ptr %slot186, align 8
  %v2525 = load i64, ptr %slot183, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  %ld2527 = load i64, ptr %p2526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2527, ptr %slot187, align 8
  %v2528 = load i64, ptr %slot187, align 8
  %cmp2529 = icmp ne i64 %v2528, 0
  %cv2530 = zext i1 %cmp2529 to i32
  store i32 %cv2530, ptr %slot188, align 8
  %v2531 = load i32, ptr %slot188, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rcgnn207, label %bb_rcgdone207
bb_rcgnn207:
  %v2534 = load i64, ptr %slot187, align 8
  %op2535 = sub i64 %v2534, 16
  store i64 %op2535, ptr %slot189, align 8
  %v2536 = load i64, ptr %slot187, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %rgep2538 = getelementptr i8, ptr %p2537, i64 -16
  %ld2539 = load i64, ptr %rgep2538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2539, ptr %slot190, align 8
  %v2540 = load i64, ptr %slot190, align 8
  %op2541 = and i64 %v2540, 4611686018427387906
  store i64 %op2541, ptr %slot191, align 8
  %v2542 = load i64, ptr %slot191, align 8
  %cmp2543 = icmp ne i64 %v2542, 0
  %cv2544 = zext i1 %cmp2543 to i32
  store i32 %cv2544, ptr %slot192, align 8
  %v2545 = load i32, ptr %slot192, align 8
  %cv2546 = zext i32 %v2545 to i64
  %cond2547 = icmp ne i64 %cv2546, 0
  br i1 %cond2547, label %bb_rcgclear207, label %bb_rcgcounted207
bb_rcgcounted207:
  %v2548 = load i64, ptr %slot187, align 8
  %op2549 = sub i64 %v2548, 24
  store i64 %op2549, ptr %slot193, align 8
  %v2550 = load i64, ptr %slot187, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %rgep2552 = getelementptr i8, ptr %p2551, i64 -24
  %ld2553 = load i64, ptr %rgep2552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2553, ptr %slot194, align 8
  %v2554 = load i64, ptr %slot194, align 8
  %op2555 = sub i64 %v2554, 1
  store i64 %op2555, ptr %slot195, align 8
  %v2556 = load i64, ptr %slot195, align 8
  %cmp2557 = icmp eq i64 %v2556, 0
  %cv2558 = zext i1 %cmp2557 to i32
  store i32 %cv2558, ptr %slot196, align 8
  %v2559 = load i32, ptr %slot196, align 8
  %cv2560 = zext i32 %v2559 to i64
  %cond2561 = icmp ne i64 %cv2560, 0
  br i1 %cond2561, label %bb_rcglast207, label %bb_rcgdec207
bb_rcglast207:
  %v2562 = load i64, ptr %slot187, align 8
  %op2563 = sub i64 %v2562, 32
  store i64 %op2563, ptr %slot197, align 8
  %v2564 = load i64, ptr %slot187, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  %rgep2566 = getelementptr i8, ptr %p2565, i64 -32
  %ld2567 = load i64, ptr %rgep2566, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2567, ptr %slot198, align 8
  %v2568 = load i64, ptr %slot198, align 8
  %cmp2569 = icmp ne i64 %v2568, 0
  %cv2570 = zext i1 %cmp2569 to i32
  store i32 %cv2570, ptr %slot199, align 8
  %v2571 = load i32, ptr %slot199, align 8
  %cv2572 = zext i32 %v2571 to i64
  %cond2573 = icmp ne i64 %cv2572, 0
  br i1 %cond2573, label %bb_rcgdec207, label %bb_rcgslow207
bb_rcgslow207:
  %v2574 = load i64, ptr %slot186, align 8
  %v2575 = load i64, ptr %slot183, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v2574, i64 %v2575) nomerge, !dbg !116
  br label %bb_rcgdone207
bb_rcgdec207:
  %v2576 = load i64, ptr %slot195, align 8
  %v2577 = load i64, ptr %slot187, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %rgep2579 = getelementptr i8, ptr %p2578, i64 -24
  store i64 %v2576, ptr %rgep2579, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear207
bb_rcgclear207:
  %v2580 = load i64, ptr %slot183, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  store i64 0, ptr %p2581, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone207
bb_rcgdone207:
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v2582 = load i64, ptr %slot59, align 8
  store i64 %v2582, ptr %slot200, align 8
  %v2583 = load i64, ptr %slot183, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i64, ptr %p2584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2585, ptr %slot201, align 8
  %v2586 = load i64, ptr %slot201, align 8
  %cmp2587 = icmp ne i64 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i32
  store i32 %cv2588, ptr %slot202, align 8
  %v2589 = load i32, ptr %slot202, align 8
  %cv2590 = zext i32 %v2589 to i64
  %cond2591 = icmp ne i64 %cv2590, 0
  br i1 %cond2591, label %bb_rcgnn222, label %bb_rcgdone222
bb_rcgnn222:
  %v2592 = load i64, ptr %slot201, align 8
  %op2593 = sub i64 %v2592, 16
  store i64 %op2593, ptr %slot203, align 8
  %v2594 = load i64, ptr %slot201, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %rgep2596 = getelementptr i8, ptr %p2595, i64 -16
  %ld2597 = load i64, ptr %rgep2596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2597, ptr %slot204, align 8
  %v2598 = load i64, ptr %slot204, align 8
  %op2599 = and i64 %v2598, 4611686018427387906
  store i64 %op2599, ptr %slot205, align 8
  %v2600 = load i64, ptr %slot205, align 8
  %cmp2601 = icmp ne i64 %v2600, 0
  %cv2602 = zext i1 %cmp2601 to i32
  store i32 %cv2602, ptr %slot206, align 8
  %v2603 = load i32, ptr %slot206, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcgclear222, label %bb_rcgcounted222
bb_rcgcounted222:
  %v2606 = load i64, ptr %slot201, align 8
  %op2607 = sub i64 %v2606, 32
  store i64 %op2607, ptr %slot207, align 8
  %v2608 = load i64, ptr %slot201, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %rgep2610 = getelementptr i8, ptr %p2609, i64 -32
  %ld2611 = load i64, ptr %rgep2610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2611, ptr %slot208, align 8
  %v2612 = load i64, ptr %slot208, align 8
  %op2613 = sub i64 %v2612, 1
  store i64 %op2613, ptr %slot209, align 8
  %v2614 = load i64, ptr %slot209, align 8
  %cmp2615 = icmp eq i64 %v2614, 0
  %cv2616 = zext i1 %cmp2615 to i32
  store i32 %cv2616, ptr %slot210, align 8
  %v2617 = load i32, ptr %slot210, align 8
  %cv2618 = zext i32 %v2617 to i64
  %cond2619 = icmp ne i64 %cv2618, 0
  br i1 %cond2619, label %bb_rcglast222, label %bb_rcgdec222
bb_rcglast222:
  %v2620 = load i64, ptr %slot201, align 8
  %op2621 = sub i64 %v2620, 24
  store i64 %op2621, ptr %slot211, align 8
  %v2622 = load i64, ptr %slot201, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %rgep2624 = getelementptr i8, ptr %p2623, i64 -24
  %ld2625 = load i64, ptr %rgep2624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2625, ptr %slot212, align 8
  %v2626 = load i64, ptr %slot212, align 8
  %cmp2627 = icmp ne i64 %v2626, 0
  %cv2628 = zext i1 %cmp2627 to i32
  store i32 %cv2628, ptr %slot213, align 8
  %v2629 = load i32, ptr %slot213, align 8
  %cv2630 = zext i32 %v2629 to i64
  %cond2631 = icmp ne i64 %cv2630, 0
  br i1 %cond2631, label %bb_rcgdec222, label %bb_rcgslow222
bb_rcgslow222:
  %v2632 = load i64, ptr %slot200, align 8
  %v2633 = load i64, ptr %slot183, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2632, i64 %v2633) nomerge, !dbg !116
  br label %bb_rcgdone222
bb_rcgdec222:
  %v2634 = load i64, ptr %slot209, align 8
  %v2635 = load i64, ptr %slot201, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  %rgep2637 = getelementptr i8, ptr %p2636, i64 -32
  store i64 %v2634, ptr %rgep2637, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear222
bb_rcgclear222:
  %v2638 = load i64, ptr %slot183, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  store i64 0, ptr %p2639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone222
bb_rcgdone222:
  br label %bb_rcslotdone191
bb_rcslotdone191:
  %v2640 = load i64, ptr %slot36, align 8
  store i64 %v2640, ptr %slot214, align 8
  %v2641 = load i64, ptr %slot28, align 8
  store i64 %v2641, ptr %slot215, align 8
  %v2642 = load i64, ptr %slot215, align 8
  %v2643 = load i64, ptr %slot214, align 8
  %p2644 = inttoptr i64 %v2642 to ptr
  %p2645 = inttoptr i64 %v2643 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2645, ptr %p2644, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot21, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i32 0, ptr %p2647, align 4, !alias.scope !3, !noalias !4
  %v2648 = load i64, ptr %slot6, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i32 2, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot22, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot216, align 8
  %v2653 = load i32, ptr %slot216, align 8
  %v2654 = load i64, ptr %slot6, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  store i32 %v2653, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  %v2656 = load i64, ptr %slot5, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  store i32 1, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined37
bb_rcholdjoined37:
  %v2658 = load i64, ptr %slot36, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  %ld2660 = load i64, ptr %p2659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2660, ptr %slot217, align 8
  %v2661 = load i64, ptr %slot6, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %ld2663 = load i32, ptr %p2662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2663, ptr %slot218, align 8
  %v2664 = load i32, ptr %slot218, align 8
  %cmp2665 = icmp eq i32 %v2664, 8
  %cv2666 = zext i1 %cmp2665 to i32
  store i32 %cv2666, ptr %slot219, align 8
  %v2667 = load i64, ptr %slot5, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %ld2669 = load i32, ptr %p2668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2669, ptr %slot220, align 8
  %v2670 = load i32, ptr %slot219, align 8
  %v2671 = load i32, ptr %slot220, align 8
  %op2672 = and i32 %v2670, %v2671
  store i32 %op2672, ptr %slot221, align 8
  %v2673 = load i32, ptr %slot221, align 8
  %cv2674 = zext i32 %v2673 to i64
  %cond2675 = icmp ne i64 %cv2674, 0
  br i1 %cond2675, label %bb_rchold234, label %bb_rcordinary234
bb_rchold234:
  %v2676 = load i64, ptr %slot28, align 8
  store i64 %v2676, ptr %slot222, align 8
  %v2677 = load i64, ptr %slot217, align 8
  %cmp2678 = icmp ne i64 %v2677, 0
  %cv2679 = zext i1 %cmp2678 to i32
  store i32 %cv2679, ptr %slot223, align 8
  %v2680 = load i32, ptr %slot223, align 8
  %cv2681 = zext i32 %v2680 to i64
  %cond2682 = icmp ne i64 %cv2681, 0
  br i1 %cond2682, label %bb_rcgnn244, label %bb_rcgstore244
bb_rcgnn244:
  %v2683 = load i64, ptr %slot217, align 8
  %op2684 = sub i64 %v2683, 16
  store i64 %op2684, ptr %slot224, align 8
  %v2685 = load i64, ptr %slot217, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %rgep2687 = getelementptr i8, ptr %p2686, i64 -16
  %ld2688 = load i64, ptr %rgep2687, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2688, ptr %slot225, align 8
  %v2689 = load i64, ptr %slot225, align 8
  %op2690 = and i64 %v2689, 4611686018427387906
  store i64 %op2690, ptr %slot226, align 8
  %v2691 = load i64, ptr %slot226, align 8
  %cmp2692 = icmp ne i64 %v2691, 0
  %cv2693 = zext i1 %cmp2692 to i32
  store i32 %cv2693, ptr %slot227, align 8
  %v2694 = load i32, ptr %slot227, align 8
  %cv2695 = zext i32 %v2694 to i64
  %cond2696 = icmp ne i64 %cv2695, 0
  br i1 %cond2696, label %bb_rcgstore244, label %bb_rcginc244
bb_rcginc244:
  %v2697 = load i64, ptr %slot217, align 8
  %op2698 = sub i64 %v2697, 24
  store i64 %op2698, ptr %slot228, align 8
  %v2699 = load i64, ptr %slot217, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %rgep2701 = getelementptr i8, ptr %p2700, i64 -24
  %ld2702 = load i64, ptr %rgep2701, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2702, ptr %slot229, align 8
  %v2703 = load i64, ptr %slot229, align 8
  %op2704 = add i64 %v2703, 1
  store i64 %op2704, ptr %slot230, align 8
  %v2705 = load i64, ptr %slot230, align 8
  %cmp2706 = icmp eq i64 %v2705, 0
  %cv2707 = zext i1 %cmp2706 to i32
  store i32 %cv2707, ptr %slot231, align 8
  %v2708 = load i32, ptr %slot231, align 8
  %cv2709 = zext i32 %v2708 to i64
  %cond2710 = icmp ne i64 %cv2709, 0
  br i1 %cond2710, label %bb_rcglimit244, label %bb_rcgcapacity244
bb_rcglimit244:
  %v2711 = load i64, ptr %slot1, align 8
  %p2712 = inttoptr i64 %v2711 to ptr
  %call2713 = call i32 @myl_qbe_rc_status(ptr %p2712, i32 2) nomerge, !dbg !118
  store i32 %call2713, ptr %slot232, align 8
  br label %bb_failure
bb_rcgcapacity244:
  %v2714 = load i64, ptr %slot230, align 8
  %v2715 = load i64, ptr %slot217, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %rgep2717 = getelementptr i8, ptr %p2716, i64 -24
  store i64 %v2714, ptr %rgep2717, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore244
bb_rcgstore244:
  %v2718 = load i64, ptr %slot217, align 8
  %v2719 = load i64, ptr %slot222, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  store i64 %v2718, ptr %p2720, align 8, !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot22, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i32 2, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot22, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  store i32 8, ptr %p2724, align 4, !alias.scope !3, !noalias !4
  %v2725 = load i64, ptr %slot21, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i32 1, ptr %p2726, align 4, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot24, align 8
  store i64 %v2727, ptr %slot233, align 8
  %v2728 = load i64, ptr %slot28, align 8
  store i64 %v2728, ptr %slot234, align 8
  %v2729 = load i64, ptr %slot234, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %ld2731 = load i64, ptr %p2730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2731, ptr %slot235, align 8
  %v2732 = load i64, ptr %slot235, align 8
  %v2733 = load i64, ptr %slot233, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i64 %v2732, ptr %p2734, align 8, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot18, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i32 2, ptr %p2736, align 4, !alias.scope !3, !noalias !4
  %v2737 = load i64, ptr %slot18, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i32 8, ptr %p2738, align 4, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot17, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  store i32 1, ptr %p2740, align 4, !alias.scope !3, !noalias !4
  %v2741 = load i64, ptr %slot21, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i32 0, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot235, align 8
  %v2744 = load i64, ptr %slot50, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  store i64 %v2743, ptr %p2745, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined234
bb_rcordinary234:
  %v2746 = load i64, ptr %slot217, align 8
  %v2747 = load i64, ptr %slot50, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i64 %v2746, ptr %p2748, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined234
bb_rcholdjoined234:
  %v2749 = load i64, ptr %slot50, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %ld2751 = load i64, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2751, ptr %slot236, align 8
  %v2752 = load i64, ptr %slot236, align 8
  %v2753 = load i64, ptr %slot26, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i64 %v2752, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot26, align 8
  store i64 %v2755, ptr %slot237, align 8
  %v2756 = load i64, ptr %slot17, align 8
  %p2757 = inttoptr i64 %v2756 to ptr
  %ld2758 = load i32, ptr %p2757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2758, ptr %slot238, align 8
  %v2759 = load i64, ptr %slot18, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  %ld2761 = load i32, ptr %p2760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2761, ptr %slot239, align 8
  %v2762 = load i32, ptr %slot239, align 8
  %op2763 = and i32 %v2762, 24
  store i32 %op2763, ptr %slot239, align 8
  %v2764 = load i32, ptr %slot239, align 8
  %cmp2765 = icmp eq i32 %v2764, 0
  %cv2766 = zext i1 %cmp2765 to i32
  store i32 %cv2766, ptr %slot240, align 8
  %v2767 = load i32, ptr %slot238, align 8
  %v2768 = load i32, ptr %slot240, align 8
  %op2769 = and i32 %v2767, %v2768
  store i32 %op2769, ptr %slot241, align 8
  %v2770 = load i32, ptr %slot241, align 8
  %cv2771 = zext i32 %v2770 to i64
  %cond2772 = icmp ne i64 %cv2771, 0
  br i1 %cond2772, label %bb_rctake267, label %bb_rccopy267
bb_rctake267:
  %v2773 = load i64, ptr %slot28, align 8
  store i64 %v2773, ptr %slot242, align 8
  %v2774 = load i64, ptr %slot60, align 8
  store i64 %v2774, ptr %slot243, align 8
  %v2775 = load i64, ptr %slot237, align 8
  %v2776 = load i64, ptr %slot242, align 8
  %op2777 = sub i64 %v2775, %v2776
  store i64 %op2777, ptr %slot244, align 8
  %v2778 = load i64, ptr %slot242, align 8
  %v2779 = load i64, ptr %slot237, align 8
  %op2780 = sub i64 %v2778, %v2779
  store i64 %op2780, ptr %slot245, align 8
  %v2781 = load i64, ptr %slot244, align 8
  %cmp2782 = icmp ult i64 %v2781, 8
  %cv2783 = zext i1 %cmp2782 to i32
  store i32 %cv2783, ptr %slot246, align 8
  %v2784 = load i64, ptr %slot245, align 8
  %cmp2785 = icmp ult i64 %v2784, 8
  %cv2786 = zext i1 %cmp2785 to i32
  store i32 %cv2786, ptr %slot247, align 8
  %v2787 = load i32, ptr %slot246, align 8
  %v2788 = load i32, ptr %slot247, align 8
  %op2789 = or i32 %v2787, %v2788
  store i32 %op2789, ptr %slot248, align 8
  %v2790 = load i32, ptr %slot248, align 8
  %cv2791 = zext i32 %v2790 to i64
  %cond2792 = icmp ne i64 %cv2791, 0
  br i1 %cond2792, label %bb_rcmoveslow276, label %bb_rcmovecheck276
bb_rcmovecheck276:
  %v2793 = load i64, ptr %slot237, align 8
  %p2795 = inttoptr i64 %v2793 to ptr
  %gep2796 = getelementptr i8, ptr %p2795, i64 0
  %op2794 = ptrtoint ptr %gep2796 to i64
  store i64 %op2794, ptr %slot249, align 8
  %v2797 = load i64, ptr %slot249, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i64, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2799, ptr %slot250, align 8
  %v2800 = load i64, ptr %slot250, align 8
  %cmp2801 = icmp ne i64 %v2800, 0
  %cv2802 = zext i1 %cmp2801 to i32
  store i32 %cv2802, ptr %slot251, align 8
  %v2803 = load i32, ptr %slot251, align 8
  %cv2804 = zext i32 %v2803 to i64
  %cond2805 = icmp ne i64 %cv2804, 0
  br i1 %cond2805, label %bb_rcmoveheader284, label %bb_rcmovenext284
bb_rcmoveheader284:
  %v2806 = load i64, ptr %slot250, align 8
  %op2807 = sub i64 %v2806, 16
  store i64 %op2807, ptr %slot252, align 8
  %v2808 = load i64, ptr %slot250, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %rgep2810 = getelementptr i8, ptr %p2809, i64 -16
  %ld2811 = load i64, ptr %rgep2810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2811, ptr %slot253, align 8
  %v2812 = load i64, ptr %slot253, align 8
  %op2813 = and i64 %v2812, 5764607523034234881
  store i64 %op2813, ptr %slot254, align 8
  %v2814 = load i64, ptr %slot254, align 8
  %cmp2815 = icmp ne i64 %v2814, 0
  %cv2816 = zext i1 %cmp2815 to i32
  store i32 %cv2816, ptr %slot255, align 8
  %v2817 = load i32, ptr %slot255, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcmoveslow276, label %bb_rcmovenext284
bb_rcmovenext284:
  %v2820 = load i64, ptr %slot237, align 8
  %v2821 = load i64, ptr %slot242, align 8
  %p2822 = inttoptr i64 %v2820 to ptr
  %p2823 = inttoptr i64 %v2821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2823, ptr %p2822, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2824 = load i64, ptr %slot237, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i64 0, ptr %p2825, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved276
bb_rcmoveslow276:
  %v2826 = load i64, ptr %slot59, align 8
  %v2827 = load i64, ptr %slot242, align 8
  %v2828 = load i64, ptr %slot237, align 8
  %v2829 = load i64, ptr %slot243, align 8
  %cv2830 = trunc i64 %v2829 to i32
  %call2831 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v2826, i64 %v2827, i64 %v2828, i32 %cv2830) nomerge, !dbg !120
  store i32 %call2831, ptr %slot256, align 8
  %v2832 = load i32, ptr %slot256, align 8
  %cv2833 = zext i32 %v2832 to i64
  %cond2834 = icmp ne i64 %cv2833, 0
  br i1 %cond2834, label %bb_rcsuccess291, label %bb_rcfailure291
bb_rcfailure291:
  %v2835 = load i64, ptr %slot59, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  %call2837 = call i32 @myl_rc_take_failure(ptr %p2836) nomerge, !dbg !120
  store i32 %call2837, ptr %slot257, align 8
  %v2838 = load i64, ptr %slot1, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  %v2840 = load i32, ptr %slot257, align 8
  %call2841 = call i32 @myl_qbe_rc_status(ptr %p2839, i32 %v2840) nomerge, !dbg !120
  store i32 %call2841, ptr %slot258, align 8
  br label %bb_failure
bb_rcsuccess291:
  br label %bb_rcmoved276
bb_rcmoved276:
  %v2842 = load i64, ptr %slot17, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  store i32 0, ptr %p2843, align 4, !alias.scope !3, !noalias !4
  %v2844 = load i64, ptr %slot22, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  store i32 2, ptr %p2845, align 4, !alias.scope !3, !noalias !4
  %v2846 = load i64, ptr %slot21, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i32 1, ptr %p2847, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared267
bb_rccopy267:
  %v2848 = load i64, ptr %slot28, align 8
  store i64 %v2848, ptr %slot259, align 8
  %v2849 = load i64, ptr %slot60, align 8
  store i64 %v2849, ptr %slot260, align 8
  %v2850 = load i64, ptr %slot237, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %ld2852 = load i64, ptr %p2851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2852, ptr %slot261, align 8
  %v2853 = load i64, ptr %slot261, align 8
  %cmp2854 = icmp ne i64 %v2853, 0
  %cv2855 = zext i1 %cmp2854 to i32
  store i32 %cv2855, ptr %slot262, align 8
  %v2856 = load i32, ptr %slot262, align 8
  %cv2857 = zext i32 %v2856 to i64
  %cond2858 = icmp ne i64 %cv2857, 0
  br i1 %cond2858, label %bb_rcgnn300, label %bb_rcgplain300
bb_rcgnn300:
  %v2859 = load i64, ptr %slot261, align 8
  %op2860 = sub i64 %v2859, 16
  store i64 %op2860, ptr %slot263, align 8
  %v2861 = load i64, ptr %slot261, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %rgep2863 = getelementptr i8, ptr %p2862, i64 -16
  %ld2864 = load i64, ptr %rgep2863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2864, ptr %slot264, align 8
  %v2865 = load i64, ptr %slot264, align 8
  %op2866 = and i64 %v2865, 4611686018427387906
  store i64 %op2866, ptr %slot265, align 8
  %v2867 = load i64, ptr %slot265, align 8
  %cmp2868 = icmp ne i64 %v2867, 0
  %cv2869 = zext i1 %cmp2868 to i32
  store i32 %cv2869, ptr %slot266, align 8
  %v2870 = load i32, ptr %slot266, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcgspecial300, label %bb_rcginc300
bb_rcginc300:
  %v2873 = load i64, ptr %slot261, align 8
  %op2874 = sub i64 %v2873, 32
  store i64 %op2874, ptr %slot267, align 8
  %v2875 = load i64, ptr %slot261, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %rgep2877 = getelementptr i8, ptr %p2876, i64 -32
  %ld2878 = load i64, ptr %rgep2877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2878, ptr %slot268, align 8
  %v2879 = load i64, ptr %slot268, align 8
  %op2880 = add i64 %v2879, 1
  store i64 %op2880, ptr %slot269, align 8
  %v2881 = load i64, ptr %slot269, align 8
  %cmp2882 = icmp eq i64 %v2881, 0
  %cv2883 = zext i1 %cmp2882 to i32
  store i32 %cv2883, ptr %slot270, align 8
  %v2884 = load i32, ptr %slot270, align 8
  %cv2885 = zext i32 %v2884 to i64
  %cond2886 = icmp ne i64 %cv2885, 0
  br i1 %cond2886, label %bb_rcglimit300, label %bb_rcgcapacity300
bb_rcglimit300:
  %v2887 = load i64, ptr %slot1, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %call2889 = call i32 @myl_qbe_rc_status(ptr %p2888, i32 2) nomerge, !dbg !120
  store i32 %call2889, ptr %slot271, align 8
  br label %bb_failure
bb_rcgcapacity300:
  %v2890 = load i64, ptr %slot269, align 8
  %v2891 = load i64, ptr %slot261, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %rgep2893 = getelementptr i8, ptr %p2892, i64 -32
  store i64 %v2890, ptr %rgep2893, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain300
bb_rcgspecial300:
  %v2894 = load i64, ptr %slot264, align 8
  %op2895 = and i64 %v2894, 4611686018427387904
  store i64 %op2895, ptr %slot272, align 8
  %v2896 = load i64, ptr %slot272, align 8
  %cmp2897 = icmp ne i64 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot273, align 8
  %v2899 = load i32, ptr %slot273, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcgslow300, label %bb_rcgplain300
bb_rcgslow300:
  %v2902 = load i64, ptr %slot59, align 8
  %v2903 = load i64, ptr %slot259, align 8
  %v2904 = load i64, ptr %slot237, align 8
  %v2905 = load i64, ptr %slot260, align 8
  %cv2906 = trunc i64 %v2905 to i32
  %call2907 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64 %v2902, i64 %v2903, i64 %v2904, i32 %cv2906) nomerge, !dbg !120
  store i32 %call2907, ptr %slot274, align 8
  %v2908 = load i32, ptr %slot274, align 8
  %cv2909 = zext i32 %v2908 to i64
  %cond2910 = icmp ne i64 %cv2909, 0
  br i1 %cond2910, label %bb_rcsuccess314, label %bb_rcfailure314
bb_rcfailure314:
  %v2911 = load i64, ptr %slot59, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  %call2913 = call i32 @myl_rc_take_failure(ptr %p2912) nomerge, !dbg !120
  store i32 %call2913, ptr %slot275, align 8
  %v2914 = load i64, ptr %slot1, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %v2916 = load i32, ptr %slot275, align 8
  %call2917 = call i32 @myl_qbe_rc_status(ptr %p2915, i32 %v2916) nomerge, !dbg !120
  store i32 %call2917, ptr %slot276, align 8
  br label %bb_failure
bb_rcsuccess314:
  br label %bb_rcgdone300
bb_rcgplain300:
  %v2918 = load i64, ptr %slot261, align 8
  %v2919 = load i64, ptr %slot259, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  store i64 %v2918, ptr %p2920, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone300
bb_rcgdone300:
  %v2921 = load i64, ptr %slot22, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  store i32 2, ptr %p2922, align 4, !alias.scope !3, !noalias !4
  %v2923 = load i64, ptr %slot21, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  store i32 1, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  %v2925 = load i64, ptr %slot17, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %ld2927 = load i32, ptr %p2926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2927, ptr %slot277, align 8
  %v2928 = load i32, ptr %slot277, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcslotdrop321, label %bb_rcslotdone321
bb_rcslotdrop321:
  %v2931 = load i64, ptr %slot17, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  store i32 0, ptr %p2932, align 4, !alias.scope !3, !noalias !4
  %v2933 = load i64, ptr %slot24, align 8
  store i64 %v2933, ptr %slot278, align 8
  %v2934 = load i64, ptr %slot18, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  %ld2936 = load i32, ptr %p2935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2936, ptr %slot279, align 8
  %v2937 = load i32, ptr %slot279, align 8
  %op2938 = and i32 %v2937, 28
  store i32 %op2938, ptr %slot280, align 8
  %v2939 = load i32, ptr %slot280, align 8
  %cv2940 = zext i32 %v2939 to i64
  %cond2941 = icmp ne i64 %cv2940, 0
  br i1 %cond2941, label %bb_rcslotrole321, label %bb_rcslotowner321
bb_rcslotrole321:
  %v2942 = load i64, ptr %slot59, align 8
  store i64 %v2942, ptr %slot281, align 8
  %v2943 = load i64, ptr %slot278, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %ld2945 = load i64, ptr %p2944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2945, ptr %slot282, align 8
  %v2946 = load i64, ptr %slot282, align 8
  %cmp2947 = icmp ne i64 %v2946, 0
  %cv2948 = zext i1 %cmp2947 to i32
  store i32 %cv2948, ptr %slot283, align 8
  %v2949 = load i32, ptr %slot283, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcgnn337, label %bb_rcgdone337
bb_rcgnn337:
  %v2952 = load i64, ptr %slot282, align 8
  %op2953 = sub i64 %v2952, 16
  store i64 %op2953, ptr %slot284, align 8
  %v2954 = load i64, ptr %slot282, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %rgep2956 = getelementptr i8, ptr %p2955, i64 -16
  %ld2957 = load i64, ptr %rgep2956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2957, ptr %slot285, align 8
  %v2958 = load i64, ptr %slot285, align 8
  %op2959 = and i64 %v2958, 4611686018427387906
  store i64 %op2959, ptr %slot286, align 8
  %v2960 = load i64, ptr %slot286, align 8
  %cmp2961 = icmp ne i64 %v2960, 0
  %cv2962 = zext i1 %cmp2961 to i32
  store i32 %cv2962, ptr %slot287, align 8
  %v2963 = load i32, ptr %slot287, align 8
  %cv2964 = zext i32 %v2963 to i64
  %cond2965 = icmp ne i64 %cv2964, 0
  br i1 %cond2965, label %bb_rcgclear337, label %bb_rcgcounted337
bb_rcgcounted337:
  %v2966 = load i64, ptr %slot282, align 8
  %op2967 = sub i64 %v2966, 24
  store i64 %op2967, ptr %slot288, align 8
  %v2968 = load i64, ptr %slot282, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %rgep2970 = getelementptr i8, ptr %p2969, i64 -24
  %ld2971 = load i64, ptr %rgep2970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2971, ptr %slot289, align 8
  %v2972 = load i64, ptr %slot289, align 8
  %op2973 = sub i64 %v2972, 1
  store i64 %op2973, ptr %slot290, align 8
  %v2974 = load i64, ptr %slot290, align 8
  %cmp2975 = icmp eq i64 %v2974, 0
  %cv2976 = zext i1 %cmp2975 to i32
  store i32 %cv2976, ptr %slot291, align 8
  %v2977 = load i32, ptr %slot291, align 8
  %cv2978 = zext i32 %v2977 to i64
  %cond2979 = icmp ne i64 %cv2978, 0
  br i1 %cond2979, label %bb_rcglast337, label %bb_rcgdec337
bb_rcglast337:
  %v2980 = load i64, ptr %slot282, align 8
  %op2981 = sub i64 %v2980, 32
  store i64 %op2981, ptr %slot292, align 8
  %v2982 = load i64, ptr %slot282, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %rgep2984 = getelementptr i8, ptr %p2983, i64 -32
  %ld2985 = load i64, ptr %rgep2984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2985, ptr %slot293, align 8
  %v2986 = load i64, ptr %slot293, align 8
  %cmp2987 = icmp ne i64 %v2986, 0
  %cv2988 = zext i1 %cmp2987 to i32
  store i32 %cv2988, ptr %slot294, align 8
  %v2989 = load i32, ptr %slot294, align 8
  %cv2990 = zext i32 %v2989 to i64
  %cond2991 = icmp ne i64 %cv2990, 0
  br i1 %cond2991, label %bb_rcgdec337, label %bb_rcgslow337
bb_rcgslow337:
  %v2992 = load i64, ptr %slot281, align 8
  %v2993 = load i64, ptr %slot278, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v2992, i64 %v2993) nomerge, !dbg !120
  br label %bb_rcgdone337
bb_rcgdec337:
  %v2994 = load i64, ptr %slot290, align 8
  %v2995 = load i64, ptr %slot282, align 8
  %p2996 = inttoptr i64 %v2995 to ptr
  %rgep2997 = getelementptr i8, ptr %p2996, i64 -24
  store i64 %v2994, ptr %rgep2997, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear337
bb_rcgclear337:
  %v2998 = load i64, ptr %slot278, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i64 0, ptr %p2999, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone337
bb_rcgdone337:
  br label %bb_rcslotdone321
bb_rcslotowner321:
  %v3000 = load i64, ptr %slot59, align 8
  store i64 %v3000, ptr %slot295, align 8
  %v3001 = load i64, ptr %slot278, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %ld3003 = load i64, ptr %p3002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3003, ptr %slot296, align 8
  %v3004 = load i64, ptr %slot296, align 8
  %cmp3005 = icmp ne i64 %v3004, 0
  %cv3006 = zext i1 %cmp3005 to i32
  store i32 %cv3006, ptr %slot297, align 8
  %v3007 = load i32, ptr %slot297, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcgnn352, label %bb_rcgdone352
bb_rcgnn352:
  %v3010 = load i64, ptr %slot296, align 8
  %op3011 = sub i64 %v3010, 16
  store i64 %op3011, ptr %slot298, align 8
  %v3012 = load i64, ptr %slot296, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  %rgep3014 = getelementptr i8, ptr %p3013, i64 -16
  %ld3015 = load i64, ptr %rgep3014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3015, ptr %slot299, align 8
  %v3016 = load i64, ptr %slot299, align 8
  %op3017 = and i64 %v3016, 4611686018427387906
  store i64 %op3017, ptr %slot300, align 8
  %v3018 = load i64, ptr %slot300, align 8
  %cmp3019 = icmp ne i64 %v3018, 0
  %cv3020 = zext i1 %cmp3019 to i32
  store i32 %cv3020, ptr %slot301, align 8
  %v3021 = load i32, ptr %slot301, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcgclear352, label %bb_rcgcounted352
bb_rcgcounted352:
  %v3024 = load i64, ptr %slot296, align 8
  %op3025 = sub i64 %v3024, 32
  store i64 %op3025, ptr %slot302, align 8
  %v3026 = load i64, ptr %slot296, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %rgep3028 = getelementptr i8, ptr %p3027, i64 -32
  %ld3029 = load i64, ptr %rgep3028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3029, ptr %slot303, align 8
  %v3030 = load i64, ptr %slot303, align 8
  %op3031 = sub i64 %v3030, 1
  store i64 %op3031, ptr %slot304, align 8
  %v3032 = load i64, ptr %slot304, align 8
  %cmp3033 = icmp eq i64 %v3032, 0
  %cv3034 = zext i1 %cmp3033 to i32
  store i32 %cv3034, ptr %slot305, align 8
  %v3035 = load i32, ptr %slot305, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcglast352, label %bb_rcgdec352
bb_rcglast352:
  %v3038 = load i64, ptr %slot296, align 8
  %op3039 = sub i64 %v3038, 24
  store i64 %op3039, ptr %slot306, align 8
  %v3040 = load i64, ptr %slot296, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  %rgep3042 = getelementptr i8, ptr %p3041, i64 -24
  %ld3043 = load i64, ptr %rgep3042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3043, ptr %slot307, align 8
  %v3044 = load i64, ptr %slot307, align 8
  %cmp3045 = icmp ne i64 %v3044, 0
  %cv3046 = zext i1 %cmp3045 to i32
  store i32 %cv3046, ptr %slot308, align 8
  %v3047 = load i32, ptr %slot308, align 8
  %cv3048 = zext i32 %v3047 to i64
  %cond3049 = icmp ne i64 %cv3048, 0
  br i1 %cond3049, label %bb_rcgdec352, label %bb_rcgslow352
bb_rcgslow352:
  %v3050 = load i64, ptr %slot295, align 8
  %v3051 = load i64, ptr %slot278, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3050, i64 %v3051) nomerge, !dbg !120
  br label %bb_rcgdone352
bb_rcgdec352:
  %v3052 = load i64, ptr %slot304, align 8
  %v3053 = load i64, ptr %slot296, align 8
  %p3054 = inttoptr i64 %v3053 to ptr
  %rgep3055 = getelementptr i8, ptr %p3054, i64 -32
  store i64 %v3052, ptr %rgep3055, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear352
bb_rcgclear352:
  %v3056 = load i64, ptr %slot278, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i64 0, ptr %p3057, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone352
bb_rcgdone352:
  br label %bb_rcslotdone321
bb_rcslotdone321:
  br label %bb_rcprepared267
bb_rcprepared267:
  %v3058 = load i64, ptr %slot7, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %ld3060 = load i32, ptr %p3059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3060, ptr %slot309, align 8
  %v3061 = load i32, ptr %slot309, align 8
  %cv3062 = zext i32 %v3061 to i64
  %cond3063 = icmp ne i64 %cv3062, 0
  br i1 %cond3063, label %bb_rcslotdrop359, label %bb_rcslotdone359
bb_rcslotdrop359:
  %v3064 = load i64, ptr %slot7, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  store i32 0, ptr %p3065, align 4, !alias.scope !3, !noalias !4
  %v3066 = load i64, ptr %slot37, align 8
  store i64 %v3066, ptr %slot310, align 8
  %v3067 = load i64, ptr %slot8, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  %ld3069 = load i32, ptr %p3068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3069, ptr %slot311, align 8
  %v3070 = load i32, ptr %slot311, align 8
  %op3071 = and i32 %v3070, 28
  store i32 %op3071, ptr %slot312, align 8
  %v3072 = load i32, ptr %slot312, align 8
  %cv3073 = zext i32 %v3072 to i64
  %cond3074 = icmp ne i64 %cv3073, 0
  br i1 %cond3074, label %bb_rcslotrole359, label %bb_rcslotowner359
bb_rcslotrole359:
  %v3075 = load i64, ptr %slot59, align 8
  store i64 %v3075, ptr %slot313, align 8
  %v3076 = load i64, ptr %slot310, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %ld3078 = load i64, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3078, ptr %slot314, align 8
  %v3079 = load i64, ptr %slot314, align 8
  %cmp3080 = icmp ne i64 %v3079, 0
  %cv3081 = zext i1 %cmp3080 to i32
  store i32 %cv3081, ptr %slot315, align 8
  %v3082 = load i32, ptr %slot315, align 8
  %cv3083 = zext i32 %v3082 to i64
  %cond3084 = icmp ne i64 %cv3083, 0
  br i1 %cond3084, label %bb_rcgnn375, label %bb_rcgdone375
bb_rcgnn375:
  %v3085 = load i64, ptr %slot314, align 8
  %op3086 = sub i64 %v3085, 16
  store i64 %op3086, ptr %slot316, align 8
  %v3087 = load i64, ptr %slot314, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %rgep3089 = getelementptr i8, ptr %p3088, i64 -16
  %ld3090 = load i64, ptr %rgep3089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3090, ptr %slot317, align 8
  %v3091 = load i64, ptr %slot317, align 8
  %op3092 = and i64 %v3091, 4611686018427387906
  store i64 %op3092, ptr %slot318, align 8
  %v3093 = load i64, ptr %slot318, align 8
  %cmp3094 = icmp ne i64 %v3093, 0
  %cv3095 = zext i1 %cmp3094 to i32
  store i32 %cv3095, ptr %slot319, align 8
  %v3096 = load i32, ptr %slot319, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcgclear375, label %bb_rcgcounted375
bb_rcgcounted375:
  %v3099 = load i64, ptr %slot314, align 8
  %op3100 = sub i64 %v3099, 24
  store i64 %op3100, ptr %slot320, align 8
  %v3101 = load i64, ptr %slot314, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %rgep3103 = getelementptr i8, ptr %p3102, i64 -24
  %ld3104 = load i64, ptr %rgep3103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3104, ptr %slot321, align 8
  %v3105 = load i64, ptr %slot321, align 8
  %op3106 = sub i64 %v3105, 1
  store i64 %op3106, ptr %slot322, align 8
  %v3107 = load i64, ptr %slot322, align 8
  %cmp3108 = icmp eq i64 %v3107, 0
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot323, align 8
  %v3110 = load i32, ptr %slot323, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcglast375, label %bb_rcgdec375
bb_rcglast375:
  %v3113 = load i64, ptr %slot314, align 8
  %op3114 = sub i64 %v3113, 32
  store i64 %op3114, ptr %slot324, align 8
  %v3115 = load i64, ptr %slot314, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  %rgep3117 = getelementptr i8, ptr %p3116, i64 -32
  %ld3118 = load i64, ptr %rgep3117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3118, ptr %slot325, align 8
  %v3119 = load i64, ptr %slot325, align 8
  %cmp3120 = icmp ne i64 %v3119, 0
  %cv3121 = zext i1 %cmp3120 to i32
  store i32 %cv3121, ptr %slot326, align 8
  %v3122 = load i32, ptr %slot326, align 8
  %cv3123 = zext i32 %v3122 to i64
  %cond3124 = icmp ne i64 %cv3123, 0
  br i1 %cond3124, label %bb_rcgdec375, label %bb_rcgslow375
bb_rcgslow375:
  %v3125 = load i64, ptr %slot313, align 8
  %v3126 = load i64, ptr %slot310, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3125, i64 %v3126) nomerge, !dbg !120
  br label %bb_rcgdone375
bb_rcgdec375:
  %v3127 = load i64, ptr %slot322, align 8
  %v3128 = load i64, ptr %slot314, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %rgep3130 = getelementptr i8, ptr %p3129, i64 -24
  store i64 %v3127, ptr %rgep3130, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear375
bb_rcgclear375:
  %v3131 = load i64, ptr %slot310, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i64 0, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone375
bb_rcgdone375:
  br label %bb_rcslotdone359
bb_rcslotowner359:
  %v3133 = load i64, ptr %slot59, align 8
  store i64 %v3133, ptr %slot327, align 8
  %v3134 = load i64, ptr %slot310, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  %ld3136 = load i64, ptr %p3135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3136, ptr %slot328, align 8
  %v3137 = load i64, ptr %slot328, align 8
  %cmp3138 = icmp ne i64 %v3137, 0
  %cv3139 = zext i1 %cmp3138 to i32
  store i32 %cv3139, ptr %slot329, align 8
  %v3140 = load i32, ptr %slot329, align 8
  %cv3141 = zext i32 %v3140 to i64
  %cond3142 = icmp ne i64 %cv3141, 0
  br i1 %cond3142, label %bb_rcgnn390, label %bb_rcgdone390
bb_rcgnn390:
  %v3143 = load i64, ptr %slot328, align 8
  %op3144 = sub i64 %v3143, 16
  store i64 %op3144, ptr %slot330, align 8
  %v3145 = load i64, ptr %slot328, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %rgep3147 = getelementptr i8, ptr %p3146, i64 -16
  %ld3148 = load i64, ptr %rgep3147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3148, ptr %slot331, align 8
  %v3149 = load i64, ptr %slot331, align 8
  %op3150 = and i64 %v3149, 4611686018427387906
  store i64 %op3150, ptr %slot332, align 8
  %v3151 = load i64, ptr %slot332, align 8
  %cmp3152 = icmp ne i64 %v3151, 0
  %cv3153 = zext i1 %cmp3152 to i32
  store i32 %cv3153, ptr %slot333, align 8
  %v3154 = load i32, ptr %slot333, align 8
  %cv3155 = zext i32 %v3154 to i64
  %cond3156 = icmp ne i64 %cv3155, 0
  br i1 %cond3156, label %bb_rcgclear390, label %bb_rcgcounted390
bb_rcgcounted390:
  %v3157 = load i64, ptr %slot328, align 8
  %op3158 = sub i64 %v3157, 32
  store i64 %op3158, ptr %slot334, align 8
  %v3159 = load i64, ptr %slot328, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %rgep3161 = getelementptr i8, ptr %p3160, i64 -32
  %ld3162 = load i64, ptr %rgep3161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3162, ptr %slot335, align 8
  %v3163 = load i64, ptr %slot335, align 8
  %op3164 = sub i64 %v3163, 1
  store i64 %op3164, ptr %slot336, align 8
  %v3165 = load i64, ptr %slot336, align 8
  %cmp3166 = icmp eq i64 %v3165, 0
  %cv3167 = zext i1 %cmp3166 to i32
  store i32 %cv3167, ptr %slot337, align 8
  %v3168 = load i32, ptr %slot337, align 8
  %cv3169 = zext i32 %v3168 to i64
  %cond3170 = icmp ne i64 %cv3169, 0
  br i1 %cond3170, label %bb_rcglast390, label %bb_rcgdec390
bb_rcglast390:
  %v3171 = load i64, ptr %slot328, align 8
  %op3172 = sub i64 %v3171, 24
  store i64 %op3172, ptr %slot338, align 8
  %v3173 = load i64, ptr %slot328, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  %rgep3175 = getelementptr i8, ptr %p3174, i64 -24
  %ld3176 = load i64, ptr %rgep3175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3176, ptr %slot339, align 8
  %v3177 = load i64, ptr %slot339, align 8
  %cmp3178 = icmp ne i64 %v3177, 0
  %cv3179 = zext i1 %cmp3178 to i32
  store i32 %cv3179, ptr %slot340, align 8
  %v3180 = load i32, ptr %slot340, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcgdec390, label %bb_rcgslow390
bb_rcgslow390:
  %v3183 = load i64, ptr %slot327, align 8
  %v3184 = load i64, ptr %slot310, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3183, i64 %v3184) nomerge, !dbg !120
  br label %bb_rcgdone390
bb_rcgdec390:
  %v3185 = load i64, ptr %slot336, align 8
  %v3186 = load i64, ptr %slot328, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  %rgep3188 = getelementptr i8, ptr %p3187, i64 -32
  store i64 %v3185, ptr %rgep3188, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear390
bb_rcgclear390:
  %v3189 = load i64, ptr %slot310, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 0, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone390
bb_rcgdone390:
  br label %bb_rcslotdone359
bb_rcslotdone359:
  %v3191 = load i64, ptr %slot37, align 8
  store i64 %v3191, ptr %slot341, align 8
  %v3192 = load i64, ptr %slot28, align 8
  store i64 %v3192, ptr %slot342, align 8
  %v3193 = load i64, ptr %slot342, align 8
  %v3194 = load i64, ptr %slot341, align 8
  %p3195 = inttoptr i64 %v3193 to ptr
  %p3196 = inttoptr i64 %v3194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3196, ptr %p3195, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot21, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  store i32 0, ptr %p3198, align 4, !alias.scope !3, !noalias !4
  %v3199 = load i64, ptr %slot8, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i32 2, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot22, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %ld3203 = load i32, ptr %p3202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3203, ptr %slot343, align 8
  %v3204 = load i32, ptr %slot343, align 8
  %v3205 = load i64, ptr %slot8, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i32 %v3204, ptr %p3206, align 4, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot7, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  store i32 1, ptr %p3208, align 4, !alias.scope !3, !noalias !4
  %v3209 = load i64, ptr %slot5, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  %ld3211 = load i32, ptr %p3210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3211, ptr %slot344, align 8
  %v3212 = load i32, ptr %slot344, align 8
  %cv3213 = zext i32 %v3212 to i64
  %cond3214 = icmp ne i64 %cv3213, 0
  br i1 %cond3214, label %bb_rcslotdrop403, label %bb_rcslotdone403
bb_rcslotdrop403:
  %v3215 = load i64, ptr %slot5, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  store i32 0, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  %v3217 = load i64, ptr %slot36, align 8
  store i64 %v3217, ptr %slot345, align 8
  %v3218 = load i64, ptr %slot6, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %ld3220 = load i32, ptr %p3219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3220, ptr %slot346, align 8
  %v3221 = load i32, ptr %slot346, align 8
  %op3222 = and i32 %v3221, 28
  store i32 %op3222, ptr %slot347, align 8
  %v3223 = load i32, ptr %slot347, align 8
  %cv3224 = zext i32 %v3223 to i64
  %cond3225 = icmp ne i64 %cv3224, 0
  br i1 %cond3225, label %bb_rcslotrole403, label %bb_rcslotowner403
bb_rcslotrole403:
  %v3226 = load i64, ptr %slot59, align 8
  store i64 %v3226, ptr %slot348, align 8
  %v3227 = load i64, ptr %slot345, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  %ld3229 = load i64, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3229, ptr %slot349, align 8
  %v3230 = load i64, ptr %slot349, align 8
  %cmp3231 = icmp ne i64 %v3230, 0
  %cv3232 = zext i1 %cmp3231 to i32
  store i32 %cv3232, ptr %slot350, align 8
  %v3233 = load i32, ptr %slot350, align 8
  %cv3234 = zext i32 %v3233 to i64
  %cond3235 = icmp ne i64 %cv3234, 0
  br i1 %cond3235, label %bb_rcgnn419, label %bb_rcgdone419
bb_rcgnn419:
  %v3236 = load i64, ptr %slot349, align 8
  %op3237 = sub i64 %v3236, 16
  store i64 %op3237, ptr %slot351, align 8
  %v3238 = load i64, ptr %slot349, align 8
  %p3239 = inttoptr i64 %v3238 to ptr
  %rgep3240 = getelementptr i8, ptr %p3239, i64 -16
  %ld3241 = load i64, ptr %rgep3240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3241, ptr %slot352, align 8
  %v3242 = load i64, ptr %slot352, align 8
  %op3243 = and i64 %v3242, 4611686018427387906
  store i64 %op3243, ptr %slot353, align 8
  %v3244 = load i64, ptr %slot353, align 8
  %cmp3245 = icmp ne i64 %v3244, 0
  %cv3246 = zext i1 %cmp3245 to i32
  store i32 %cv3246, ptr %slot354, align 8
  %v3247 = load i32, ptr %slot354, align 8
  %cv3248 = zext i32 %v3247 to i64
  %cond3249 = icmp ne i64 %cv3248, 0
  br i1 %cond3249, label %bb_rcgclear419, label %bb_rcgcounted419
bb_rcgcounted419:
  %v3250 = load i64, ptr %slot349, align 8
  %op3251 = sub i64 %v3250, 24
  store i64 %op3251, ptr %slot355, align 8
  %v3252 = load i64, ptr %slot349, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  %rgep3254 = getelementptr i8, ptr %p3253, i64 -24
  %ld3255 = load i64, ptr %rgep3254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3255, ptr %slot356, align 8
  %v3256 = load i64, ptr %slot356, align 8
  %op3257 = sub i64 %v3256, 1
  store i64 %op3257, ptr %slot357, align 8
  %v3258 = load i64, ptr %slot357, align 8
  %cmp3259 = icmp eq i64 %v3258, 0
  %cv3260 = zext i1 %cmp3259 to i32
  store i32 %cv3260, ptr %slot358, align 8
  %v3261 = load i32, ptr %slot358, align 8
  %cv3262 = zext i32 %v3261 to i64
  %cond3263 = icmp ne i64 %cv3262, 0
  br i1 %cond3263, label %bb_rcglast419, label %bb_rcgdec419
bb_rcglast419:
  %v3264 = load i64, ptr %slot349, align 8
  %op3265 = sub i64 %v3264, 32
  store i64 %op3265, ptr %slot359, align 8
  %v3266 = load i64, ptr %slot349, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  %rgep3268 = getelementptr i8, ptr %p3267, i64 -32
  %ld3269 = load i64, ptr %rgep3268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3269, ptr %slot360, align 8
  %v3270 = load i64, ptr %slot360, align 8
  %cmp3271 = icmp ne i64 %v3270, 0
  %cv3272 = zext i1 %cmp3271 to i32
  store i32 %cv3272, ptr %slot361, align 8
  %v3273 = load i32, ptr %slot361, align 8
  %cv3274 = zext i32 %v3273 to i64
  %cond3275 = icmp ne i64 %cv3274, 0
  br i1 %cond3275, label %bb_rcgdec419, label %bb_rcgslow419
bb_rcgslow419:
  %v3276 = load i64, ptr %slot348, align 8
  %v3277 = load i64, ptr %slot345, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3276, i64 %v3277) nomerge, !dbg !120
  br label %bb_rcgdone419
bb_rcgdec419:
  %v3278 = load i64, ptr %slot357, align 8
  %v3279 = load i64, ptr %slot349, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %rgep3281 = getelementptr i8, ptr %p3280, i64 -24
  store i64 %v3278, ptr %rgep3281, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear419
bb_rcgclear419:
  %v3282 = load i64, ptr %slot345, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i64 0, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone419
bb_rcgdone419:
  br label %bb_rcslotdone403
bb_rcslotowner403:
  %v3284 = load i64, ptr %slot59, align 8
  store i64 %v3284, ptr %slot362, align 8
  %v3285 = load i64, ptr %slot345, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  %ld3287 = load i64, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3287, ptr %slot363, align 8
  %v3288 = load i64, ptr %slot363, align 8
  %cmp3289 = icmp ne i64 %v3288, 0
  %cv3290 = zext i1 %cmp3289 to i32
  store i32 %cv3290, ptr %slot364, align 8
  %v3291 = load i32, ptr %slot364, align 8
  %cv3292 = zext i32 %v3291 to i64
  %cond3293 = icmp ne i64 %cv3292, 0
  br i1 %cond3293, label %bb_rcgnn434, label %bb_rcgdone434
bb_rcgnn434:
  %v3294 = load i64, ptr %slot363, align 8
  %op3295 = sub i64 %v3294, 16
  store i64 %op3295, ptr %slot365, align 8
  %v3296 = load i64, ptr %slot363, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %rgep3298 = getelementptr i8, ptr %p3297, i64 -16
  %ld3299 = load i64, ptr %rgep3298, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3299, ptr %slot366, align 8
  %v3300 = load i64, ptr %slot366, align 8
  %op3301 = and i64 %v3300, 4611686018427387906
  store i64 %op3301, ptr %slot367, align 8
  %v3302 = load i64, ptr %slot367, align 8
  %cmp3303 = icmp ne i64 %v3302, 0
  %cv3304 = zext i1 %cmp3303 to i32
  store i32 %cv3304, ptr %slot368, align 8
  %v3305 = load i32, ptr %slot368, align 8
  %cv3306 = zext i32 %v3305 to i64
  %cond3307 = icmp ne i64 %cv3306, 0
  br i1 %cond3307, label %bb_rcgclear434, label %bb_rcgcounted434
bb_rcgcounted434:
  %v3308 = load i64, ptr %slot363, align 8
  %op3309 = sub i64 %v3308, 32
  store i64 %op3309, ptr %slot369, align 8
  %v3310 = load i64, ptr %slot363, align 8
  %p3311 = inttoptr i64 %v3310 to ptr
  %rgep3312 = getelementptr i8, ptr %p3311, i64 -32
  %ld3313 = load i64, ptr %rgep3312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3313, ptr %slot370, align 8
  %v3314 = load i64, ptr %slot370, align 8
  %op3315 = sub i64 %v3314, 1
  store i64 %op3315, ptr %slot371, align 8
  %v3316 = load i64, ptr %slot371, align 8
  %cmp3317 = icmp eq i64 %v3316, 0
  %cv3318 = zext i1 %cmp3317 to i32
  store i32 %cv3318, ptr %slot372, align 8
  %v3319 = load i32, ptr %slot372, align 8
  %cv3320 = zext i32 %v3319 to i64
  %cond3321 = icmp ne i64 %cv3320, 0
  br i1 %cond3321, label %bb_rcglast434, label %bb_rcgdec434
bb_rcglast434:
  %v3322 = load i64, ptr %slot363, align 8
  %op3323 = sub i64 %v3322, 24
  store i64 %op3323, ptr %slot373, align 8
  %v3324 = load i64, ptr %slot363, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %rgep3326 = getelementptr i8, ptr %p3325, i64 -24
  %ld3327 = load i64, ptr %rgep3326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3327, ptr %slot374, align 8
  %v3328 = load i64, ptr %slot374, align 8
  %cmp3329 = icmp ne i64 %v3328, 0
  %cv3330 = zext i1 %cmp3329 to i32
  store i32 %cv3330, ptr %slot375, align 8
  %v3331 = load i32, ptr %slot375, align 8
  %cv3332 = zext i32 %v3331 to i64
  %cond3333 = icmp ne i64 %cv3332, 0
  br i1 %cond3333, label %bb_rcgdec434, label %bb_rcgslow434
bb_rcgslow434:
  %v3334 = load i64, ptr %slot362, align 8
  %v3335 = load i64, ptr %slot345, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3334, i64 %v3335) nomerge, !dbg !120
  br label %bb_rcgdone434
bb_rcgdec434:
  %v3336 = load i64, ptr %slot371, align 8
  %v3337 = load i64, ptr %slot363, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  %rgep3339 = getelementptr i8, ptr %p3338, i64 -32
  store i64 %v3336, ptr %rgep3339, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear434
bb_rcgclear434:
  %v3340 = load i64, ptr %slot345, align 8
  %p3341 = inttoptr i64 %v3340 to ptr
  store i64 0, ptr %p3341, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone434
bb_rcgdone434:
  br label %bb_rcslotdone403
bb_rcslotdone403:
  %v3342 = load i64, ptr %slot50, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  store i64 0, ptr %p3343, align 8, !alias.scope !3, !noalias !4
  %v3344 = load i64, ptr %slot50, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %ld3346 = load i64, ptr %p3345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3346, ptr %slot376, align 8
  %v3347 = load i64, ptr %slot376, align 8
  %v3348 = load i64, ptr %slot38, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  store i64 %v3347, ptr %p3349, align 8, !alias.scope !3, !noalias !4
  br label %bb_i8
bb_i8:
  %v3350 = load i64, ptr %slot38, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i64, ptr %p3351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3352, ptr %slot377, align 8
  %v3353 = load i64, ptr %slot377, align 8
  %v3354 = load i64, ptr %slot50, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  store i64 %v3353, ptr %p3355, align 8, !alias.scope !3, !noalias !4
  %v3356 = load i64, ptr %slot35, align 8
  %p3357 = inttoptr i64 %v3356 to ptr
  %ld3358 = load i64, ptr %p3357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3358, ptr %slot378, align 8
  %v3359 = load i64, ptr %slot378, align 8
  %v3360 = load i64, ptr %slot51, align 8
  %p3361 = inttoptr i64 %v3360 to ptr
  store i64 %v3359, ptr %p3361, align 8, !alias.scope !3, !noalias !4
  %v3362 = load i64, ptr %slot51, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %ld3364 = load i64, ptr %p3363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3364, ptr %slot379, align 8
  %v3365 = load i64, ptr %slot50, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  %ld3367 = load i64, ptr %p3366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3367, ptr %slot380, align 8
  %v3368 = load i64, ptr %slot380, align 8
  %v3369 = load i64, ptr %slot379, align 8
  %cmp3370 = icmp slt i64 %v3368, %v3369
  %cv3371 = zext i1 %cmp3370 to i64
  store i64 %cv3371, ptr %slot381, align 8
  %v3372 = load i64, ptr %slot381, align 8
  %v3373 = load i64, ptr %slot50, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i64 %v3372, ptr %p3374, align 8, !alias.scope !3, !noalias !4
  %v3375 = load i64, ptr %slot50, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %ld3377 = load i64, ptr %p3376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3377, ptr %slot382, align 8
  %v3378 = load i64, ptr %slot382, align 8
  %cond3379 = icmp ne i64 %v3378, 0
  br i1 %cond3379, label %bb_next445, label %bb_i20
bb_next445:
  %v3380 = load i64, ptr %slot1, align 8
  call void @myl_f_f9596c0ae80ae31480fb911cf78c48a39c632b6cf68d532231bbaef0695efd77(ptr sret([32 x i8]) align 8 %callresult384, i64 %v3380) nomerge, !dbg !122
  %addr3381 = ptrtoint ptr %callresult384 to i64
  store i64 %addr3381, ptr %slot383, align 8
  %v3382 = load i64, ptr %slot383, align 8
  %v3383 = load i64, ptr %slot50, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  store i64 %v3382, ptr %p3384, align 8, !alias.scope !3, !noalias !4
  %v3385 = load i64, ptr %slot37, align 8
  store i64 %v3385, ptr %slot385, align 8
  %v3386 = load i64, ptr %slot8, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  store i32 2, ptr %p3387, align 4, !alias.scope !3, !noalias !4
  %v3388 = load i64, ptr %slot385, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  %ld3390 = load i64, ptr %p3389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3390, ptr %slot386, align 8
  %v3391 = load i64, ptr %slot386, align 8
  %cmp3392 = icmp ne i64 %v3391, 0
  %cv3393 = zext i1 %cmp3392 to i32
  store i32 %cv3393, ptr %slot387, align 8
  %v3394 = load i32, ptr %slot387, align 8
  %cv3395 = zext i32 %v3394 to i64
  %cond3396 = icmp ne i64 %cv3395, 0
  br i1 %cond3396, label %bb_rcguniquenn449, label %bb_rcgunique449
bb_rcguniquenn449:
  %v3397 = load i64, ptr %slot386, align 8
  %op3398 = sub i64 %v3397, 16
  store i64 %op3398, ptr %slot388, align 8
  %v3399 = load i64, ptr %slot386, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %rgep3401 = getelementptr i8, ptr %p3400, i64 -16
  %ld3402 = load i64, ptr %rgep3401, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3402, ptr %slot389, align 8
  %v3403 = load i64, ptr %slot389, align 8
  %op3404 = and i64 %v3403, 6917529027641081858
  store i64 %op3404, ptr %slot390, align 8
  %v3405 = load i64, ptr %slot390, align 8
  %cmp3406 = icmp ne i64 %v3405, 0
  %cv3407 = zext i1 %cmp3406 to i32
  store i32 %cv3407, ptr %slot391, align 8
  %v3408 = load i32, ptr %slot391, align 8
  %cv3409 = zext i32 %v3408 to i64
  %cond3410 = icmp ne i64 %cv3409, 0
  br i1 %cond3410, label %bb_rcguniqueslow449, label %bb_rcguniquecount449
bb_rcguniquecount449:
  %v3411 = load i64, ptr %slot386, align 8
  %op3412 = sub i64 %v3411, 32
  store i64 %op3412, ptr %slot392, align 8
  %v3413 = load i64, ptr %slot386, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  %rgep3415 = getelementptr i8, ptr %p3414, i64 -32
  %ld3416 = load i64, ptr %rgep3415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3416, ptr %slot393, align 8
  %v3417 = load i64, ptr %slot393, align 8
  %cmp3418 = icmp ult i64 %v3417, 2
  %cv3419 = zext i1 %cmp3418 to i32
  store i32 %cv3419, ptr %slot394, align 8
  %v3420 = load i32, ptr %slot394, align 8
  %cv3421 = zext i32 %v3420 to i64
  %cond3422 = icmp ne i64 %cv3421, 0
  br i1 %cond3422, label %bb_rcgunique449, label %bb_rcguniqueslow449
bb_rcguniqueslow449:
  %v3423 = load i64, ptr %slot1, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  %p3425 = inttoptr i64 ptrtoint (ptr @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c to i64) to ptr
  %v3426 = load i64, ptr %slot385, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %v3428 = load i64, ptr %slot7, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  %call3430 = call i32 @myl_qbe_rc_unique_local(ptr %p3424, ptr %p3425, ptr %p3427, ptr %p3429) nomerge, !dbg !124
  store i32 %call3430, ptr %slot395, align 8
  %v3431 = load i32, ptr %slot395, align 8
  %cv3432 = zext i32 %v3431 to i64
  %cond3433 = icmp ne i64 %cv3432, 0
  br i1 %cond3433, label %bb_rcunique460, label %bb_failure
bb_rcunique460:
  br label %bb_rcgunique449
bb_rcgunique449:
  %v3434 = load i64, ptr %slot37, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %ld3436 = load i64, ptr %p3435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3436, ptr %slot396, align 8
  %v3437 = load i64, ptr %slot50, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  %ld3439 = load i64, ptr %p3438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3439, ptr %slot397, align 8
  %v3440 = load i64, ptr %slot59, align 8
  %v3441 = load i64, ptr %slot396, align 8
  %v3442 = load i64, ptr %slot397, align 8
  %call3443 = call i32 @myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da_rcg_list_append(i64 %v3440, i64 %v3441, i64 %v3442) nomerge, !dbg !124
  store i32 %call3443, ptr %slot398, align 8
  %v3444 = load i32, ptr %slot398, align 8
  %cv3445 = zext i32 %v3444 to i64
  %cond3446 = icmp ne i64 %cv3445, 0
  br i1 %cond3446, label %bb_success464, label %bb_failed464
bb_failed464:
  %v3447 = load i64, ptr %slot1, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3448) nomerge, !dbg !124
  unreachable
bb_success464:
  %v3449 = load i64, ptr %slot50, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  store i64 0, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  %v3451 = load i64, ptr %slot38, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i64, ptr %p3452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3453, ptr %slot399, align 8
  %v3454 = load i64, ptr %slot399, align 8
  %v3455 = load i64, ptr %slot50, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i64 %v3454, ptr %p3456, align 8, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot51, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  store i64 1, ptr %p3458, align 8, !alias.scope !3, !noalias !4
  %v3459 = load i64, ptr %slot51, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  %ld3461 = load i64, ptr %p3460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3461, ptr %slot400, align 8
  %v3462 = load i64, ptr %slot50, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %ld3464 = load i64, ptr %p3463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3464, ptr %slot401, align 8
  %v3465 = load i64, ptr %slot401, align 8
  %v3466 = load i64, ptr %slot400, align 8
  %ovpair3468 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3465, i64 %v3466)
  %op3467 = extractvalue { i64, i1 } %ovpair3468, 0
  %ov3469 = extractvalue { i64, i1 } %ovpair3468, 1
  store i64 %op3467, ptr %slot402, align 8
  %cv3470 = zext i1 %ov3469 to i64
  store i64 %cv3470, ptr %slot403, align 8
  %v3471 = load i64, ptr %slot403, align 8
  %cond3472 = icmp ne i64 %v3471, 0
  br i1 %cond3472, label %bb_overflow468, label %bb_checked468
bb_overflow468:
  %v3473 = load i64, ptr %slot1, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %v3475 = load i64, ptr %slot401, align 8
  %v3476 = load i64, ptr %slot400, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3474, i64 0, i64 %v3475, i64 %v3476, i64 64) nomerge, !dbg !126
  unreachable
bb_checked468:
  %v3477 = load i64, ptr %slot402, align 8
  %v3478 = load i64, ptr %slot50, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i64 %v3477, ptr %p3479, align 8, !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot50, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  %ld3482 = load i64, ptr %p3481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3482, ptr %slot404, align 8
  %v3483 = load i64, ptr %slot404, align 8
  %v3484 = load i64, ptr %slot38, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  store i64 %v3483, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  br label %bb_i8
bb_i20:
  %v3486 = load i64, ptr %slot50, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i64 0, ptr %p3487, align 8, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot50, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %ld3490 = load i64, ptr %p3489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3490, ptr %slot405, align 8
  %v3491 = load i64, ptr %slot405, align 8
  %v3492 = load i64, ptr %slot39, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i64 %v3491, ptr %p3493, align 8, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot34, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  %ld3496 = load i64, ptr %p3495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3496, ptr %slot406, align 8
  %v3497 = load i64, ptr %slot406, align 8
  %v3498 = load i64, ptr %slot50, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  store i64 %v3497, ptr %p3499, align 8, !alias.scope !3, !noalias !4
  %v3500 = load i64, ptr %slot34, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  %ld3502 = load i64, ptr %p3501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3502, ptr %slot407, align 8
  %v3503 = load i64, ptr %slot407, align 8
  %v3504 = load i64, ptr %slot50, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i64 %v3503, ptr %p3505, align 8, !alias.scope !3, !noalias !4
  %v3506 = load i64, ptr %slot34, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  %ld3508 = load i64, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3508, ptr %slot408, align 8
  %v3509 = load i64, ptr %slot408, align 8
  %v3510 = load i64, ptr %slot50, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i64 %v3509, ptr %p3511, align 8, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot39, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  %ld3514 = load i64, ptr %p3513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3514, ptr %slot409, align 8
  %v3515 = load i64, ptr %slot409, align 8
  %v3516 = load i64, ptr %slot51, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  store i64 %v3515, ptr %p3517, align 8, !alias.scope !3, !noalias !4
  %v3518 = load i64, ptr %slot34, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  %ld3520 = load i64, ptr %p3519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3520, ptr %slot410, align 8
  %v3521 = load i64, ptr %slot410, align 8
  %v3522 = load i64, ptr %slot50, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  store i64 %v3521, ptr %p3523, align 8, !alias.scope !3, !noalias !4
  %v3524 = load i64, ptr %slot39, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  %ld3526 = load i64, ptr %p3525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3526, ptr %slot411, align 8
  %v3527 = load i64, ptr %slot34, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i64, ptr %p3528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3529, ptr %slot412, align 8
  %v3530 = load i64, ptr %slot412, align 8
  %op3531 = add i64 %v3530, 8
  store i64 %op3531, ptr %slot413, align 8
  %v3532 = load i64, ptr %slot411, align 8
  %v3533 = load i64, ptr %slot413, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  store i64 %v3532, ptr %p3534, align 8, !alias.scope !4, !noalias !3
  %v3535 = load i64, ptr %slot50, align 8
  %p3536 = inttoptr i64 %v3535 to ptr
  store i64 0, ptr %p3536, align 8, !alias.scope !3, !noalias !4
  %v3537 = load i64, ptr %slot34, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %ld3539 = load i64, ptr %p3538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3539, ptr %slot414, align 8
  %v3540 = load i64, ptr %slot414, align 8
  %v3541 = load i64, ptr %slot50, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  store i64 %v3540, ptr %p3542, align 8, !alias.scope !3, !noalias !4
  %v3543 = load i64, ptr %slot50, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %ld3545 = load i64, ptr %p3544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3545, ptr %slot415, align 8
  %v3546 = load i64, ptr %slot415, align 8
  %op3547 = add i64 %v3546, 0
  store i64 %op3547, ptr %slot416, align 8
  %v3548 = load i64, ptr %slot416, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  %ld3550 = load i64, ptr %p3549, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3550, ptr %slot417, align 8
  %v3551 = load i64, ptr %slot417, align 8
  %v3552 = load i64, ptr %slot50, align 8
  %p3553 = inttoptr i64 %v3552 to ptr
  store i64 %v3551, ptr %p3553, align 8, !alias.scope !3, !noalias !4
  %v3554 = load i64, ptr %slot17, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  %ld3556 = load i32, ptr %p3555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3556, ptr %slot418, align 8
  %v3557 = load i32, ptr %slot418, align 8
  %cv3558 = zext i32 %v3557 to i64
  %cond3559 = icmp ne i64 %cv3558, 0
  br i1 %cond3559, label %bb_rcslotdrop486, label %bb_rcslotdone486
bb_rcslotdrop486:
  %v3560 = load i64, ptr %slot17, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i32 0, ptr %p3561, align 4, !alias.scope !3, !noalias !4
  %v3562 = load i64, ptr %slot24, align 8
  store i64 %v3562, ptr %slot419, align 8
  %v3563 = load i64, ptr %slot18, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i32, ptr %p3564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3565, ptr %slot420, align 8
  %v3566 = load i32, ptr %slot420, align 8
  %op3567 = and i32 %v3566, 28
  store i32 %op3567, ptr %slot421, align 8
  %v3568 = load i32, ptr %slot421, align 8
  %cv3569 = zext i32 %v3568 to i64
  %cond3570 = icmp ne i64 %cv3569, 0
  br i1 %cond3570, label %bb_rcslotrole486, label %bb_rcslotowner486
bb_rcslotrole486:
  %v3571 = load i64, ptr %slot59, align 8
  store i64 %v3571, ptr %slot422, align 8
  %v3572 = load i64, ptr %slot422, align 8
  %v3573 = load i64, ptr %slot419, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3572, i64 %v3573) nomerge, !dbg !128
  br label %bb_rcslotdone486
bb_rcslotowner486:
  %v3574 = load i64, ptr %slot59, align 8
  store i64 %v3574, ptr %slot423, align 8
  %v3575 = load i64, ptr %slot423, align 8
  %v3576 = load i64, ptr %slot419, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3575, i64 %v3576) nomerge, !dbg !128
  br label %bb_rcslotdone486
bb_rcslotdone486:
  %v3577 = load i64, ptr %slot50, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %ld3579 = load i64, ptr %p3578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3579, ptr %slot424, align 8
  %v3580 = load i64, ptr %slot28, align 8
  store i64 %v3580, ptr %slot425, align 8
  %v3581 = load i64, ptr %slot424, align 8
  %cmp3582 = icmp ne i64 %v3581, 0
  %cv3583 = zext i1 %cmp3582 to i32
  store i32 %cv3583, ptr %slot426, align 8
  %v3584 = load i32, ptr %slot426, align 8
  %cv3585 = zext i32 %v3584 to i64
  %cond3586 = icmp ne i64 %cv3585, 0
  br i1 %cond3586, label %bb_rcgnn497, label %bb_rcgstore497
bb_rcgnn497:
  %v3587 = load i64, ptr %slot424, align 8
  %op3588 = sub i64 %v3587, 16
  store i64 %op3588, ptr %slot427, align 8
  %v3589 = load i64, ptr %slot424, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  %rgep3591 = getelementptr i8, ptr %p3590, i64 -16
  %ld3592 = load i64, ptr %rgep3591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3592, ptr %slot428, align 8
  %v3593 = load i64, ptr %slot428, align 8
  %op3594 = and i64 %v3593, 4611686018427387906
  store i64 %op3594, ptr %slot429, align 8
  %v3595 = load i64, ptr %slot429, align 8
  %cmp3596 = icmp ne i64 %v3595, 0
  %cv3597 = zext i1 %cmp3596 to i32
  store i32 %cv3597, ptr %slot430, align 8
  %v3598 = load i32, ptr %slot430, align 8
  %cv3599 = zext i32 %v3598 to i64
  %cond3600 = icmp ne i64 %cv3599, 0
  br i1 %cond3600, label %bb_rcgstore497, label %bb_rcginc497
bb_rcginc497:
  %v3601 = load i64, ptr %slot424, align 8
  %op3602 = sub i64 %v3601, 24
  store i64 %op3602, ptr %slot431, align 8
  %v3603 = load i64, ptr %slot424, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %rgep3605 = getelementptr i8, ptr %p3604, i64 -24
  %ld3606 = load i64, ptr %rgep3605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3606, ptr %slot432, align 8
  %v3607 = load i64, ptr %slot432, align 8
  %op3608 = add i64 %v3607, 1
  store i64 %op3608, ptr %slot433, align 8
  %v3609 = load i64, ptr %slot433, align 8
  %cmp3610 = icmp eq i64 %v3609, 0
  %cv3611 = zext i1 %cmp3610 to i32
  store i32 %cv3611, ptr %slot434, align 8
  %v3612 = load i32, ptr %slot434, align 8
  %cv3613 = zext i32 %v3612 to i64
  %cond3614 = icmp ne i64 %cv3613, 0
  br i1 %cond3614, label %bb_rcglimit497, label %bb_rcgcapacity497
bb_rcglimit497:
  %v3615 = load i64, ptr %slot1, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %call3617 = call i32 @myl_qbe_rc_status(ptr %p3616, i32 2) nomerge, !dbg !130
  store i32 %call3617, ptr %slot435, align 8
  br label %bb_failure
bb_rcgcapacity497:
  %v3618 = load i64, ptr %slot433, align 8
  %v3619 = load i64, ptr %slot424, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  %rgep3621 = getelementptr i8, ptr %p3620, i64 -24
  store i64 %v3618, ptr %rgep3621, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore497
bb_rcgstore497:
  %v3622 = load i64, ptr %slot424, align 8
  %v3623 = load i64, ptr %slot425, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  store i64 %v3622, ptr %p3624, align 8, !alias.scope !3, !noalias !4
  %v3625 = load i64, ptr %slot22, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i32 2, ptr %p3626, align 4, !alias.scope !3, !noalias !4
  %v3627 = load i64, ptr %slot22, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  store i32 8, ptr %p3628, align 4, !alias.scope !3, !noalias !4
  %v3629 = load i64, ptr %slot21, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  store i32 1, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  %v3631 = load i64, ptr %slot17, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  %ld3633 = load i32, ptr %p3632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3633, ptr %slot436, align 8
  %v3634 = load i32, ptr %slot436, align 8
  %cv3635 = zext i32 %v3634 to i64
  %cond3636 = icmp ne i64 %cv3635, 0
  br i1 %cond3636, label %bb_rcslotdrop513, label %bb_rcslotdone513
bb_rcslotdrop513:
  %v3637 = load i64, ptr %slot17, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i32 0, ptr %p3638, align 4, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot24, align 8
  store i64 %v3639, ptr %slot437, align 8
  %v3640 = load i64, ptr %slot18, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot438, align 8
  %v3643 = load i32, ptr %slot438, align 8
  %op3644 = and i32 %v3643, 28
  store i32 %op3644, ptr %slot439, align 8
  %v3645 = load i32, ptr %slot439, align 8
  %cv3646 = zext i32 %v3645 to i64
  %cond3647 = icmp ne i64 %cv3646, 0
  br i1 %cond3647, label %bb_rcslotrole513, label %bb_rcslotowner513
bb_rcslotrole513:
  %v3648 = load i64, ptr %slot59, align 8
  store i64 %v3648, ptr %slot440, align 8
  %v3649 = load i64, ptr %slot437, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i64, ptr %p3650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3651, ptr %slot441, align 8
  %v3652 = load i64, ptr %slot441, align 8
  %cmp3653 = icmp ne i64 %v3652, 0
  %cv3654 = zext i1 %cmp3653 to i32
  store i32 %cv3654, ptr %slot442, align 8
  %v3655 = load i32, ptr %slot442, align 8
  %cv3656 = zext i32 %v3655 to i64
  %cond3657 = icmp ne i64 %cv3656, 0
  br i1 %cond3657, label %bb_rcgnn529, label %bb_rcgdone529
bb_rcgnn529:
  %v3658 = load i64, ptr %slot441, align 8
  %op3659 = sub i64 %v3658, 16
  store i64 %op3659, ptr %slot443, align 8
  %v3660 = load i64, ptr %slot441, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  %rgep3662 = getelementptr i8, ptr %p3661, i64 -16
  %ld3663 = load i64, ptr %rgep3662, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3663, ptr %slot444, align 8
  %v3664 = load i64, ptr %slot444, align 8
  %op3665 = and i64 %v3664, 4611686018427387906
  store i64 %op3665, ptr %slot445, align 8
  %v3666 = load i64, ptr %slot445, align 8
  %cmp3667 = icmp ne i64 %v3666, 0
  %cv3668 = zext i1 %cmp3667 to i32
  store i32 %cv3668, ptr %slot446, align 8
  %v3669 = load i32, ptr %slot446, align 8
  %cv3670 = zext i32 %v3669 to i64
  %cond3671 = icmp ne i64 %cv3670, 0
  br i1 %cond3671, label %bb_rcgclear529, label %bb_rcgcounted529
bb_rcgcounted529:
  %v3672 = load i64, ptr %slot441, align 8
  %op3673 = sub i64 %v3672, 24
  store i64 %op3673, ptr %slot447, align 8
  %v3674 = load i64, ptr %slot441, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  %rgep3676 = getelementptr i8, ptr %p3675, i64 -24
  %ld3677 = load i64, ptr %rgep3676, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3677, ptr %slot448, align 8
  %v3678 = load i64, ptr %slot448, align 8
  %op3679 = sub i64 %v3678, 1
  store i64 %op3679, ptr %slot449, align 8
  %v3680 = load i64, ptr %slot449, align 8
  %cmp3681 = icmp eq i64 %v3680, 0
  %cv3682 = zext i1 %cmp3681 to i32
  store i32 %cv3682, ptr %slot450, align 8
  %v3683 = load i32, ptr %slot450, align 8
  %cv3684 = zext i32 %v3683 to i64
  %cond3685 = icmp ne i64 %cv3684, 0
  br i1 %cond3685, label %bb_rcglast529, label %bb_rcgdec529
bb_rcglast529:
  %v3686 = load i64, ptr %slot441, align 8
  %op3687 = sub i64 %v3686, 32
  store i64 %op3687, ptr %slot451, align 8
  %v3688 = load i64, ptr %slot441, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  %rgep3690 = getelementptr i8, ptr %p3689, i64 -32
  %ld3691 = load i64, ptr %rgep3690, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3691, ptr %slot452, align 8
  %v3692 = load i64, ptr %slot452, align 8
  %cmp3693 = icmp ne i64 %v3692, 0
  %cv3694 = zext i1 %cmp3693 to i32
  store i32 %cv3694, ptr %slot453, align 8
  %v3695 = load i32, ptr %slot453, align 8
  %cv3696 = zext i32 %v3695 to i64
  %cond3697 = icmp ne i64 %cv3696, 0
  br i1 %cond3697, label %bb_rcgdec529, label %bb_rcgslow529
bb_rcgslow529:
  %v3698 = load i64, ptr %slot440, align 8
  %v3699 = load i64, ptr %slot437, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3698, i64 %v3699) nomerge, !dbg !130
  br label %bb_rcgdone529
bb_rcgdec529:
  %v3700 = load i64, ptr %slot449, align 8
  %v3701 = load i64, ptr %slot441, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  %rgep3703 = getelementptr i8, ptr %p3702, i64 -24
  store i64 %v3700, ptr %rgep3703, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear529
bb_rcgclear529:
  %v3704 = load i64, ptr %slot437, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  store i64 0, ptr %p3705, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone529
bb_rcgdone529:
  br label %bb_rcslotdone513
bb_rcslotowner513:
  %v3706 = load i64, ptr %slot59, align 8
  store i64 %v3706, ptr %slot454, align 8
  %v3707 = load i64, ptr %slot437, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  %ld3709 = load i64, ptr %p3708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3709, ptr %slot455, align 8
  %v3710 = load i64, ptr %slot455, align 8
  %cmp3711 = icmp ne i64 %v3710, 0
  %cv3712 = zext i1 %cmp3711 to i32
  store i32 %cv3712, ptr %slot456, align 8
  %v3713 = load i32, ptr %slot456, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcgnn544, label %bb_rcgdone544
bb_rcgnn544:
  %v3716 = load i64, ptr %slot455, align 8
  %op3717 = sub i64 %v3716, 16
  store i64 %op3717, ptr %slot457, align 8
  %v3718 = load i64, ptr %slot455, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %rgep3720 = getelementptr i8, ptr %p3719, i64 -16
  %ld3721 = load i64, ptr %rgep3720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3721, ptr %slot458, align 8
  %v3722 = load i64, ptr %slot458, align 8
  %op3723 = and i64 %v3722, 4611686018427387906
  store i64 %op3723, ptr %slot459, align 8
  %v3724 = load i64, ptr %slot459, align 8
  %cmp3725 = icmp ne i64 %v3724, 0
  %cv3726 = zext i1 %cmp3725 to i32
  store i32 %cv3726, ptr %slot460, align 8
  %v3727 = load i32, ptr %slot460, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rcgclear544, label %bb_rcgcounted544
bb_rcgcounted544:
  %v3730 = load i64, ptr %slot455, align 8
  %op3731 = sub i64 %v3730, 32
  store i64 %op3731, ptr %slot461, align 8
  %v3732 = load i64, ptr %slot455, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  %rgep3734 = getelementptr i8, ptr %p3733, i64 -32
  %ld3735 = load i64, ptr %rgep3734, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3735, ptr %slot462, align 8
  %v3736 = load i64, ptr %slot462, align 8
  %op3737 = sub i64 %v3736, 1
  store i64 %op3737, ptr %slot463, align 8
  %v3738 = load i64, ptr %slot463, align 8
  %cmp3739 = icmp eq i64 %v3738, 0
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot464, align 8
  %v3741 = load i32, ptr %slot464, align 8
  %cv3742 = zext i32 %v3741 to i64
  %cond3743 = icmp ne i64 %cv3742, 0
  br i1 %cond3743, label %bb_rcglast544, label %bb_rcgdec544
bb_rcglast544:
  %v3744 = load i64, ptr %slot455, align 8
  %op3745 = sub i64 %v3744, 24
  store i64 %op3745, ptr %slot465, align 8
  %v3746 = load i64, ptr %slot455, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %rgep3748 = getelementptr i8, ptr %p3747, i64 -24
  %ld3749 = load i64, ptr %rgep3748, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3749, ptr %slot466, align 8
  %v3750 = load i64, ptr %slot466, align 8
  %cmp3751 = icmp ne i64 %v3750, 0
  %cv3752 = zext i1 %cmp3751 to i32
  store i32 %cv3752, ptr %slot467, align 8
  %v3753 = load i32, ptr %slot467, align 8
  %cv3754 = zext i32 %v3753 to i64
  %cond3755 = icmp ne i64 %cv3754, 0
  br i1 %cond3755, label %bb_rcgdec544, label %bb_rcgslow544
bb_rcgslow544:
  %v3756 = load i64, ptr %slot454, align 8
  %v3757 = load i64, ptr %slot437, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3756, i64 %v3757) nomerge, !dbg !130
  br label %bb_rcgdone544
bb_rcgdec544:
  %v3758 = load i64, ptr %slot463, align 8
  %v3759 = load i64, ptr %slot455, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %rgep3761 = getelementptr i8, ptr %p3760, i64 -32
  store i64 %v3758, ptr %rgep3761, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear544
bb_rcgclear544:
  %v3762 = load i64, ptr %slot437, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  store i64 0, ptr %p3763, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone544
bb_rcgdone544:
  br label %bb_rcslotdone513
bb_rcslotdone513:
  %v3764 = load i64, ptr %slot24, align 8
  store i64 %v3764, ptr %slot468, align 8
  %v3765 = load i64, ptr %slot28, align 8
  store i64 %v3765, ptr %slot469, align 8
  %v3766 = load i64, ptr %slot469, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  %ld3768 = load i64, ptr %p3767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3768, ptr %slot470, align 8
  %v3769 = load i64, ptr %slot470, align 8
  %v3770 = load i64, ptr %slot468, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i64 %v3769, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  %v3772 = load i64, ptr %slot18, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  store i32 2, ptr %p3773, align 4, !alias.scope !3, !noalias !4
  %v3774 = load i64, ptr %slot18, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i32 8, ptr %p3775, align 4, !alias.scope !3, !noalias !4
  %v3776 = load i64, ptr %slot17, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  store i32 1, ptr %p3777, align 4, !alias.scope !3, !noalias !4
  %v3778 = load i64, ptr %slot21, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  store i32 0, ptr %p3779, align 4, !alias.scope !3, !noalias !4
  %v3780 = load i64, ptr %slot470, align 8
  %v3781 = load i64, ptr %slot50, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  store i64 %v3780, ptr %p3782, align 8, !alias.scope !3, !noalias !4
  %v3783 = load i64, ptr %slot28, align 8
  store i64 %v3783, ptr %slot471, align 8
  %v3784 = load i64, ptr %slot50, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %ld3786 = load i64, ptr %p3785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3786, ptr %slot472, align 8
  %v3787 = load i64, ptr %slot472, align 8
  %v3788 = load i64, ptr %slot471, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  store i64 %v3787, ptr %p3789, align 8, !alias.scope !3, !noalias !4
  %v3790 = load i64, ptr %slot22, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  store i32 2, ptr %p3791, align 4, !alias.scope !3, !noalias !4
  %v3792 = load i64, ptr %slot22, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  store i32 8, ptr %p3793, align 4, !alias.scope !3, !noalias !4
  %v3794 = load i64, ptr %slot21, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  store i32 1, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot17, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  store i32 0, ptr %p3797, align 4, !alias.scope !3, !noalias !4
  %v3798 = load i64, ptr %slot9, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i32, ptr %p3799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3800, ptr %slot473, align 8
  %v3801 = load i32, ptr %slot473, align 8
  %cv3802 = zext i32 %v3801 to i64
  %cond3803 = icmp ne i64 %cv3802, 0
  br i1 %cond3803, label %bb_rcslotdrop563, label %bb_rcslotdone563
bb_rcslotdrop563:
  %v3804 = load i64, ptr %slot9, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i32 0, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot40, align 8
  store i64 %v3806, ptr %slot474, align 8
  %v3807 = load i64, ptr %slot10, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %ld3809 = load i32, ptr %p3808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3809, ptr %slot475, align 8
  %v3810 = load i32, ptr %slot475, align 8
  %op3811 = and i32 %v3810, 28
  store i32 %op3811, ptr %slot476, align 8
  %v3812 = load i32, ptr %slot476, align 8
  %cv3813 = zext i32 %v3812 to i64
  %cond3814 = icmp ne i64 %cv3813, 0
  br i1 %cond3814, label %bb_rcslotrole563, label %bb_rcslotowner563
bb_rcslotrole563:
  %v3815 = load i64, ptr %slot59, align 8
  store i64 %v3815, ptr %slot477, align 8
  %v3816 = load i64, ptr %slot474, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  %ld3818 = load i64, ptr %p3817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3818, ptr %slot478, align 8
  %v3819 = load i64, ptr %slot478, align 8
  %cmp3820 = icmp ne i64 %v3819, 0
  %cv3821 = zext i1 %cmp3820 to i32
  store i32 %cv3821, ptr %slot479, align 8
  %v3822 = load i32, ptr %slot479, align 8
  %cv3823 = zext i32 %v3822 to i64
  %cond3824 = icmp ne i64 %cv3823, 0
  br i1 %cond3824, label %bb_rcgnn579, label %bb_rcgdone579
bb_rcgnn579:
  %v3825 = load i64, ptr %slot478, align 8
  %op3826 = sub i64 %v3825, 16
  store i64 %op3826, ptr %slot480, align 8
  %v3827 = load i64, ptr %slot478, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  %rgep3829 = getelementptr i8, ptr %p3828, i64 -16
  %ld3830 = load i64, ptr %rgep3829, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3830, ptr %slot481, align 8
  %v3831 = load i64, ptr %slot481, align 8
  %op3832 = and i64 %v3831, 4611686018427387906
  store i64 %op3832, ptr %slot482, align 8
  %v3833 = load i64, ptr %slot482, align 8
  %cmp3834 = icmp ne i64 %v3833, 0
  %cv3835 = zext i1 %cmp3834 to i32
  store i32 %cv3835, ptr %slot483, align 8
  %v3836 = load i32, ptr %slot483, align 8
  %cv3837 = zext i32 %v3836 to i64
  %cond3838 = icmp ne i64 %cv3837, 0
  br i1 %cond3838, label %bb_rcgclear579, label %bb_rcgcounted579
bb_rcgcounted579:
  %v3839 = load i64, ptr %slot478, align 8
  %op3840 = sub i64 %v3839, 24
  store i64 %op3840, ptr %slot484, align 8
  %v3841 = load i64, ptr %slot478, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %rgep3843 = getelementptr i8, ptr %p3842, i64 -24
  %ld3844 = load i64, ptr %rgep3843, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3844, ptr %slot485, align 8
  %v3845 = load i64, ptr %slot485, align 8
  %op3846 = sub i64 %v3845, 1
  store i64 %op3846, ptr %slot486, align 8
  %v3847 = load i64, ptr %slot486, align 8
  %cmp3848 = icmp eq i64 %v3847, 0
  %cv3849 = zext i1 %cmp3848 to i32
  store i32 %cv3849, ptr %slot487, align 8
  %v3850 = load i32, ptr %slot487, align 8
  %cv3851 = zext i32 %v3850 to i64
  %cond3852 = icmp ne i64 %cv3851, 0
  br i1 %cond3852, label %bb_rcglast579, label %bb_rcgdec579
bb_rcglast579:
  %v3853 = load i64, ptr %slot478, align 8
  %op3854 = sub i64 %v3853, 32
  store i64 %op3854, ptr %slot488, align 8
  %v3855 = load i64, ptr %slot478, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %rgep3857 = getelementptr i8, ptr %p3856, i64 -32
  %ld3858 = load i64, ptr %rgep3857, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3858, ptr %slot489, align 8
  %v3859 = load i64, ptr %slot489, align 8
  %cmp3860 = icmp ne i64 %v3859, 0
  %cv3861 = zext i1 %cmp3860 to i32
  store i32 %cv3861, ptr %slot490, align 8
  %v3862 = load i32, ptr %slot490, align 8
  %cv3863 = zext i32 %v3862 to i64
  %cond3864 = icmp ne i64 %cv3863, 0
  br i1 %cond3864, label %bb_rcgdec579, label %bb_rcgslow579
bb_rcgslow579:
  %v3865 = load i64, ptr %slot477, align 8
  %v3866 = load i64, ptr %slot474, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3865, i64 %v3866) nomerge, !dbg !130
  br label %bb_rcgdone579
bb_rcgdec579:
  %v3867 = load i64, ptr %slot486, align 8
  %v3868 = load i64, ptr %slot478, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %rgep3870 = getelementptr i8, ptr %p3869, i64 -24
  store i64 %v3867, ptr %rgep3870, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear579
bb_rcgclear579:
  %v3871 = load i64, ptr %slot474, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  store i64 0, ptr %p3872, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone579
bb_rcgdone579:
  br label %bb_rcslotdone563
bb_rcslotowner563:
  %v3873 = load i64, ptr %slot59, align 8
  store i64 %v3873, ptr %slot491, align 8
  %v3874 = load i64, ptr %slot474, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %ld3876 = load i64, ptr %p3875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3876, ptr %slot492, align 8
  %v3877 = load i64, ptr %slot492, align 8
  %cmp3878 = icmp ne i64 %v3877, 0
  %cv3879 = zext i1 %cmp3878 to i32
  store i32 %cv3879, ptr %slot493, align 8
  %v3880 = load i32, ptr %slot493, align 8
  %cv3881 = zext i32 %v3880 to i64
  %cond3882 = icmp ne i64 %cv3881, 0
  br i1 %cond3882, label %bb_rcgnn594, label %bb_rcgdone594
bb_rcgnn594:
  %v3883 = load i64, ptr %slot492, align 8
  %op3884 = sub i64 %v3883, 16
  store i64 %op3884, ptr %slot494, align 8
  %v3885 = load i64, ptr %slot492, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  %rgep3887 = getelementptr i8, ptr %p3886, i64 -16
  %ld3888 = load i64, ptr %rgep3887, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3888, ptr %slot495, align 8
  %v3889 = load i64, ptr %slot495, align 8
  %op3890 = and i64 %v3889, 4611686018427387906
  store i64 %op3890, ptr %slot496, align 8
  %v3891 = load i64, ptr %slot496, align 8
  %cmp3892 = icmp ne i64 %v3891, 0
  %cv3893 = zext i1 %cmp3892 to i32
  store i32 %cv3893, ptr %slot497, align 8
  %v3894 = load i32, ptr %slot497, align 8
  %cv3895 = zext i32 %v3894 to i64
  %cond3896 = icmp ne i64 %cv3895, 0
  br i1 %cond3896, label %bb_rcgclear594, label %bb_rcgcounted594
bb_rcgcounted594:
  %v3897 = load i64, ptr %slot492, align 8
  %op3898 = sub i64 %v3897, 32
  store i64 %op3898, ptr %slot498, align 8
  %v3899 = load i64, ptr %slot492, align 8
  %p3900 = inttoptr i64 %v3899 to ptr
  %rgep3901 = getelementptr i8, ptr %p3900, i64 -32
  %ld3902 = load i64, ptr %rgep3901, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3902, ptr %slot499, align 8
  %v3903 = load i64, ptr %slot499, align 8
  %op3904 = sub i64 %v3903, 1
  store i64 %op3904, ptr %slot500, align 8
  %v3905 = load i64, ptr %slot500, align 8
  %cmp3906 = icmp eq i64 %v3905, 0
  %cv3907 = zext i1 %cmp3906 to i32
  store i32 %cv3907, ptr %slot501, align 8
  %v3908 = load i32, ptr %slot501, align 8
  %cv3909 = zext i32 %v3908 to i64
  %cond3910 = icmp ne i64 %cv3909, 0
  br i1 %cond3910, label %bb_rcglast594, label %bb_rcgdec594
bb_rcglast594:
  %v3911 = load i64, ptr %slot492, align 8
  %op3912 = sub i64 %v3911, 24
  store i64 %op3912, ptr %slot502, align 8
  %v3913 = load i64, ptr %slot492, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %rgep3915 = getelementptr i8, ptr %p3914, i64 -24
  %ld3916 = load i64, ptr %rgep3915, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3916, ptr %slot503, align 8
  %v3917 = load i64, ptr %slot503, align 8
  %cmp3918 = icmp ne i64 %v3917, 0
  %cv3919 = zext i1 %cmp3918 to i32
  store i32 %cv3919, ptr %slot504, align 8
  %v3920 = load i32, ptr %slot504, align 8
  %cv3921 = zext i32 %v3920 to i64
  %cond3922 = icmp ne i64 %cv3921, 0
  br i1 %cond3922, label %bb_rcgdec594, label %bb_rcgslow594
bb_rcgslow594:
  %v3923 = load i64, ptr %slot491, align 8
  %v3924 = load i64, ptr %slot474, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3923, i64 %v3924) nomerge, !dbg !130
  br label %bb_rcgdone594
bb_rcgdec594:
  %v3925 = load i64, ptr %slot500, align 8
  %v3926 = load i64, ptr %slot492, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  %rgep3928 = getelementptr i8, ptr %p3927, i64 -32
  store i64 %v3925, ptr %rgep3928, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear594
bb_rcgclear594:
  %v3929 = load i64, ptr %slot474, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i64 0, ptr %p3930, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone594
bb_rcgdone594:
  br label %bb_rcslotdone563
bb_rcslotdone563:
  %v3931 = load i64, ptr %slot40, align 8
  store i64 %v3931, ptr %slot505, align 8
  %v3932 = load i64, ptr %slot471, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  %ld3934 = load i64, ptr %p3933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3934, ptr %slot506, align 8
  %v3935 = load i64, ptr %slot506, align 8
  %v3936 = load i64, ptr %slot505, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  store i64 %v3935, ptr %p3937, align 8, !alias.scope !3, !noalias !4
  %v3938 = load i64, ptr %slot10, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  store i32 2, ptr %p3939, align 4, !alias.scope !3, !noalias !4
  %v3940 = load i64, ptr %slot10, align 8
  %p3941 = inttoptr i64 %v3940 to ptr
  store i32 8, ptr %p3941, align 4, !alias.scope !3, !noalias !4
  %v3942 = load i64, ptr %slot9, align 8
  %p3943 = inttoptr i64 %v3942 to ptr
  store i32 1, ptr %p3943, align 4, !alias.scope !3, !noalias !4
  %v3944 = load i64, ptr %slot21, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  store i32 0, ptr %p3945, align 4, !alias.scope !3, !noalias !4
  %v3946 = load i64, ptr %slot50, align 8
  %p3947 = inttoptr i64 %v3946 to ptr
  store i64 0, ptr %p3947, align 8, !alias.scope !3, !noalias !4
  %v3948 = load i64, ptr %slot50, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  %ld3950 = load i64, ptr %p3949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3950, ptr %slot507, align 8
  %v3951 = load i64, ptr %slot507, align 8
  %v3952 = load i64, ptr %slot41, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  store i64 %v3951, ptr %p3953, align 8, !alias.scope !3, !noalias !4
  %v3954 = load i64, ptr %slot40, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %ld3956 = load i64, ptr %p3955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3956, ptr %slot508, align 8
  %v3957 = load i64, ptr %slot508, align 8
  %op3958 = add i64 %v3957, 0
  store i64 %op3958, ptr %slot509, align 8
  %v3959 = load i64, ptr %slot509, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  %ld3961 = load i64, ptr %p3960, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3961, ptr %slot510, align 8
  %v3962 = load i64, ptr %slot510, align 8
  %v3963 = load i64, ptr %slot50, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i64 %v3962, ptr %p3964, align 8, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot50, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i64, ptr %p3966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3967, ptr %slot511, align 8
  %v3968 = load i64, ptr %slot511, align 8
  %cmp3969 = icmp ugt i64 %v3968, 9223372036854775807
  %cv3970 = zext i1 %cmp3969 to i64
  store i64 %cv3970, ptr %slot512, align 8
  %v3971 = load i64, ptr %slot512, align 8
  %cond3972 = icmp ne i64 %v3971, 0
  br i1 %cond3972, label %bb_cast_overflow610, label %bb_cast_ok610
bb_cast_overflow610:
  %v3973 = load i64, ptr %slot1, align 8
  %p3974 = inttoptr i64 %v3973 to ptr
  %v3975 = load i64, ptr %slot511, align 8
  call void @myl_qbe_fail_cast(ptr %p3974, i64 %v3975, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok610:
  %v3976 = load i64, ptr %slot511, align 8
  %v3977 = load i64, ptr %slot50, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  store i64 %v3976, ptr %p3978, align 8, !alias.scope !3, !noalias !4
  %v3979 = load i64, ptr %slot50, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  %ld3981 = load i64, ptr %p3980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3981, ptr %slot513, align 8
  %v3982 = load i64, ptr %slot513, align 8
  %v3983 = load i64, ptr %slot42, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  store i64 %v3982, ptr %p3984, align 8, !alias.scope !3, !noalias !4
  br label %bb_i40
bb_i40:
  %v3985 = load i64, ptr %slot41, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  %ld3987 = load i64, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3987, ptr %slot514, align 8
  %v3988 = load i64, ptr %slot514, align 8
  %v3989 = load i64, ptr %slot50, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  store i64 %v3988, ptr %p3990, align 8, !alias.scope !3, !noalias !4
  %v3991 = load i64, ptr %slot42, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  %ld3993 = load i64, ptr %p3992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3993, ptr %slot515, align 8
  %v3994 = load i64, ptr %slot515, align 8
  %v3995 = load i64, ptr %slot51, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  store i64 %v3994, ptr %p3996, align 8, !alias.scope !3, !noalias !4
  %v3997 = load i64, ptr %slot51, align 8
  %p3998 = inttoptr i64 %v3997 to ptr
  %ld3999 = load i64, ptr %p3998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3999, ptr %slot516, align 8
  %v4000 = load i64, ptr %slot50, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  %ld4002 = load i64, ptr %p4001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4002, ptr %slot517, align 8
  %v4003 = load i64, ptr %slot517, align 8
  %v4004 = load i64, ptr %slot516, align 8
  %cmp4005 = icmp slt i64 %v4003, %v4004
  %cv4006 = zext i1 %cmp4005 to i64
  store i64 %cv4006, ptr %slot518, align 8
  %v4007 = load i64, ptr %slot518, align 8
  %v4008 = load i64, ptr %slot50, align 8
  %p4009 = inttoptr i64 %v4008 to ptr
  store i64 %v4007, ptr %p4009, align 8, !alias.scope !3, !noalias !4
  %v4010 = load i64, ptr %slot50, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  %ld4012 = load i64, ptr %p4011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4012, ptr %slot519, align 8
  %v4013 = load i64, ptr %slot519, align 8
  %cond4014 = icmp ne i64 %v4013, 0
  br i1 %cond4014, label %bb_next618, label %bb_i102
bb_next618:
  %v4015 = load i64, ptr %slot42, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  %ld4017 = load i64, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4017, ptr %slot520, align 8
  %v4018 = load i64, ptr %slot520, align 8
  %v4019 = load i64, ptr %slot50, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  store i64 %v4018, ptr %p4020, align 8, !alias.scope !3, !noalias !4
  %v4021 = load i64, ptr %slot40, align 8
  %p4022 = inttoptr i64 %v4021 to ptr
  %ld4023 = load i64, ptr %p4022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4023, ptr %slot521, align 8
  %v4024 = load i64, ptr %slot50, align 8
  %p4025 = inttoptr i64 %v4024 to ptr
  %ld4026 = load i64, ptr %p4025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4026, ptr %slot522, align 8
  %v4027 = load i64, ptr %slot521, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %ld4029 = load i64, ptr %p4028, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4029, ptr %slot523, align 8
  %v4030 = load i64, ptr %slot523, align 8
  %v4031 = load i64, ptr %slot522, align 8
  %cmp4032 = icmp eq i64 %v4030, %v4031
  %cv4033 = zext i1 %cmp4032 to i64
  store i64 %cv4033, ptr %slot524, align 8
  %v4034 = load i64, ptr %slot524, align 8
  %cond4035 = icmp ne i64 %v4034, 0
  br i1 %cond4035, label %bb_success623, label %bb_failed623
bb_failed623:
  %v4036 = load i64, ptr %slot1, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  call void @myl_qbe_fail_iteration(ptr %p4037) nomerge, !dbg !134
  unreachable
bb_success623:
  %v4038 = load i64, ptr %slot50, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i64 0, ptr %p4039, align 8, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot41, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i64, ptr %p4041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4042, ptr %slot525, align 8
  %v4043 = load i64, ptr %slot525, align 8
  %v4044 = load i64, ptr %slot50, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i64 %v4043, ptr %p4045, align 8, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot40, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i64, ptr %p4047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4048, ptr %slot526, align 8
  %v4049 = load i64, ptr %slot50, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %ld4051 = load i64, ptr %p4050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4051, ptr %slot527, align 8
  %v4052 = load i64, ptr %slot526, align 8
  %p4053 = inttoptr i64 %v4052 to ptr
  %ld4054 = load i64, ptr %p4053, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4054, ptr %slot528, align 8
  %v4055 = load i64, ptr %slot527, align 8
  %v4056 = load i64, ptr %slot528, align 8
  %cmp4057 = icmp ult i64 %v4055, %v4056
  %cv4058 = zext i1 %cmp4057 to i64
  store i64 %cv4058, ptr %slot529, align 8
  %v4059 = load i64, ptr %slot529, align 8
  %cond4060 = icmp ne i64 %v4059, 0
  br i1 %cond4060, label %bb_success630, label %bb_failed630
bb_failed630:
  %v4061 = load i64, ptr %slot1, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  %v4063 = load i64, ptr %slot527, align 8
  %v4064 = load i64, ptr %slot528, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4062, i64 %v4063, i64 %v4064) nomerge, !dbg !136
  unreachable
bb_success630:
  %v4065 = load i64, ptr %slot526, align 8
  %op4066 = add i64 %v4065, 32
  store i64 %op4066, ptr %slot530, align 8
  %v4067 = load i64, ptr %slot530, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  %ld4069 = load i64, ptr %p4068, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4069, ptr %slot531, align 8
  %v4070 = load i64, ptr %slot527, align 8
  %op4071 = mul i64 %v4070, 32
  store i64 %op4071, ptr %slot532, align 8
  %v4072 = load i64, ptr %slot531, align 8
  %v4073 = load i64, ptr %slot532, align 8
  %op4074 = add i64 %v4072, %v4073
  store i64 %op4074, ptr %slot533, align 8
  %v4075 = load i64, ptr %slot533, align 8
  %v4076 = load i64, ptr %slot50, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i64 %v4075, ptr %p4077, align 8, !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot50, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i64, ptr %p4079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4080, ptr %slot534, align 8
  %v4081 = load i64, ptr %slot534, align 8
  %v4082 = load i64, ptr %slot43, align 8
  %p4083 = inttoptr i64 %v4081 to ptr
  %p4084 = inttoptr i64 %v4082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4084, ptr %p4083, i64 32, i1 false), !alias.scope !10000000
  %v4085 = load i64, ptr %slot43, align 8
  %v4086 = load i64, ptr %slot50, align 8
  %p4087 = inttoptr i64 %v4086 to ptr
  store i64 %v4085, ptr %p4087, align 8, !alias.scope !3, !noalias !4
  %v4088 = load i64, ptr %slot50, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %ld4090 = load i64, ptr %p4089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4090, ptr %slot535, align 8
  %v4091 = load i64, ptr %slot535, align 8
  %op4092 = add i64 %v4091, 0
  store i64 %op4092, ptr %slot536, align 8
  %v4093 = load i64, ptr %slot536, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  %ld4095 = load i64, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4095, ptr %slot537, align 8
  %v4096 = load i64, ptr %slot537, align 8
  %v4097 = load i64, ptr %slot50, align 8
  %p4098 = inttoptr i64 %v4097 to ptr
  store i64 %v4096, ptr %p4098, align 8, !alias.scope !3, !noalias !4
  %v4099 = load i64, ptr %slot51, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i64 18446744073709551615, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot51, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  %ld4103 = load i64, ptr %p4102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4103, ptr %slot538, align 8
  %v4104 = load i64, ptr %slot50, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  %ld4106 = load i64, ptr %p4105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4106, ptr %slot539, align 8
  %v4107 = load i64, ptr %slot539, align 8
  %v4108 = load i64, ptr %slot538, align 8
  %cmp4109 = icmp ne i64 %v4107, %v4108
  %cv4110 = zext i1 %cmp4109 to i64
  store i64 %cv4110, ptr %slot540, align 8
  %v4111 = load i64, ptr %slot540, align 8
  %v4112 = load i64, ptr %slot50, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i64 %v4111, ptr %p4113, align 8, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot50, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  %ld4116 = load i64, ptr %p4115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4116, ptr %slot541, align 8
  %v4117 = load i64, ptr %slot541, align 8
  %cond4118 = icmp ne i64 %v4117, 0
  br i1 %cond4118, label %bb_next643, label %bb_i94
bb_next643:
  %v4119 = load i64, ptr %slot43, align 8
  %v4120 = load i64, ptr %slot50, align 8
  %p4121 = inttoptr i64 %v4120 to ptr
  store i64 %v4119, ptr %p4121, align 8, !alias.scope !3, !noalias !4
  %v4122 = load i64, ptr %slot50, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  %ld4124 = load i64, ptr %p4123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4124, ptr %slot542, align 8
  %v4125 = load i64, ptr %slot542, align 8
  %v4126 = load i64, ptr %slot45, align 8
  %p4127 = inttoptr i64 %v4125 to ptr
  %p4128 = inttoptr i64 %v4126 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4128, ptr %p4127, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4129 = load i64, ptr %slot37, align 8
  store i64 %v4129, ptr %slot543, align 8
  %v4130 = load i64, ptr %slot8, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  store i32 2, ptr %p4131, align 4, !alias.scope !3, !noalias !4
  %v4132 = load i64, ptr %slot543, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  %ld4134 = load i64, ptr %p4133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4134, ptr %slot544, align 8
  %v4135 = load i64, ptr %slot544, align 8
  %cmp4136 = icmp ne i64 %v4135, 0
  %cv4137 = zext i1 %cmp4136 to i32
  store i32 %cv4137, ptr %slot545, align 8
  %v4138 = load i32, ptr %slot545, align 8
  %cv4139 = zext i32 %v4138 to i64
  %cond4140 = icmp ne i64 %cv4139, 0
  br i1 %cond4140, label %bb_rcguniquenn647, label %bb_rcgunique647
bb_rcguniquenn647:
  %v4141 = load i64, ptr %slot544, align 8
  %op4142 = sub i64 %v4141, 16
  store i64 %op4142, ptr %slot546, align 8
  %v4143 = load i64, ptr %slot544, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %rgep4145 = getelementptr i8, ptr %p4144, i64 -16
  %ld4146 = load i64, ptr %rgep4145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4146, ptr %slot547, align 8
  %v4147 = load i64, ptr %slot547, align 8
  %op4148 = and i64 %v4147, 6917529027641081858
  store i64 %op4148, ptr %slot548, align 8
  %v4149 = load i64, ptr %slot548, align 8
  %cmp4150 = icmp ne i64 %v4149, 0
  %cv4151 = zext i1 %cmp4150 to i32
  store i32 %cv4151, ptr %slot549, align 8
  %v4152 = load i32, ptr %slot549, align 8
  %cv4153 = zext i32 %v4152 to i64
  %cond4154 = icmp ne i64 %cv4153, 0
  br i1 %cond4154, label %bb_rcguniqueslow647, label %bb_rcguniquecount647
bb_rcguniquecount647:
  %v4155 = load i64, ptr %slot544, align 8
  %op4156 = sub i64 %v4155, 32
  store i64 %op4156, ptr %slot550, align 8
  %v4157 = load i64, ptr %slot544, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %rgep4159 = getelementptr i8, ptr %p4158, i64 -32
  %ld4160 = load i64, ptr %rgep4159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4160, ptr %slot551, align 8
  %v4161 = load i64, ptr %slot551, align 8
  %cmp4162 = icmp ult i64 %v4161, 2
  %cv4163 = zext i1 %cmp4162 to i32
  store i32 %cv4163, ptr %slot552, align 8
  %v4164 = load i32, ptr %slot552, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcgunique647, label %bb_rcguniqueslow647
bb_rcguniqueslow647:
  %v4167 = load i64, ptr %slot1, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  %p4169 = inttoptr i64 ptrtoint (ptr @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c to i64) to ptr
  %v4170 = load i64, ptr %slot543, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %v4172 = load i64, ptr %slot7, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  %call4174 = call i32 @myl_qbe_rc_unique_local(ptr %p4168, ptr %p4169, ptr %p4171, ptr %p4173) nomerge, !dbg !138
  store i32 %call4174, ptr %slot553, align 8
  %v4175 = load i32, ptr %slot553, align 8
  %cv4176 = zext i32 %v4175 to i64
  %cond4177 = icmp ne i64 %cv4176, 0
  br i1 %cond4177, label %bb_rcunique658, label %bb_failure
bb_rcunique658:
  br label %bb_rcgunique647
bb_rcgunique647:
  %v4178 = load i64, ptr %slot37, align 8
  %p4179 = inttoptr i64 %v4178 to ptr
  %ld4180 = load i64, ptr %p4179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4180, ptr %slot554, align 8
  %v4181 = load i64, ptr %slot8, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i32, ptr %p4182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4183, ptr %slot555, align 8
  %v4184 = load i32, ptr %slot555, align 8
  %cmp4185 = icmp eq i32 %v4184, 8
  %cv4186 = zext i1 %cmp4185 to i32
  store i32 %cv4186, ptr %slot556, align 8
  %v4187 = load i64, ptr %slot7, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %ld4189 = load i32, ptr %p4188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4189, ptr %slot557, align 8
  %v4190 = load i32, ptr %slot556, align 8
  %v4191 = load i32, ptr %slot557, align 8
  %op4192 = and i32 %v4190, %v4191
  store i32 %op4192, ptr %slot558, align 8
  %v4193 = load i32, ptr %slot558, align 8
  %cv4194 = zext i32 %v4193 to i64
  %cond4195 = icmp ne i64 %cv4194, 0
  br i1 %cond4195, label %bb_rchold660, label %bb_rcordinary660
bb_rchold660:
  %v4196 = load i64, ptr %slot28, align 8
  store i64 %v4196, ptr %slot559, align 8
  %v4197 = load i64, ptr %slot554, align 8
  %cmp4198 = icmp ne i64 %v4197, 0
  %cv4199 = zext i1 %cmp4198 to i32
  store i32 %cv4199, ptr %slot560, align 8
  %v4200 = load i32, ptr %slot560, align 8
  %cv4201 = zext i32 %v4200 to i64
  %cond4202 = icmp ne i64 %cv4201, 0
  br i1 %cond4202, label %bb_rcgnn670, label %bb_rcgstore670
bb_rcgnn670:
  %v4203 = load i64, ptr %slot554, align 8
  %op4204 = sub i64 %v4203, 16
  store i64 %op4204, ptr %slot561, align 8
  %v4205 = load i64, ptr %slot554, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %rgep4207 = getelementptr i8, ptr %p4206, i64 -16
  %ld4208 = load i64, ptr %rgep4207, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4208, ptr %slot562, align 8
  %v4209 = load i64, ptr %slot562, align 8
  %op4210 = and i64 %v4209, 4611686018427387906
  store i64 %op4210, ptr %slot563, align 8
  %v4211 = load i64, ptr %slot563, align 8
  %cmp4212 = icmp ne i64 %v4211, 0
  %cv4213 = zext i1 %cmp4212 to i32
  store i32 %cv4213, ptr %slot564, align 8
  %v4214 = load i32, ptr %slot564, align 8
  %cv4215 = zext i32 %v4214 to i64
  %cond4216 = icmp ne i64 %cv4215, 0
  br i1 %cond4216, label %bb_rcgstore670, label %bb_rcginc670
bb_rcginc670:
  %v4217 = load i64, ptr %slot554, align 8
  %op4218 = sub i64 %v4217, 24
  store i64 %op4218, ptr %slot565, align 8
  %v4219 = load i64, ptr %slot554, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  %rgep4221 = getelementptr i8, ptr %p4220, i64 -24
  %ld4222 = load i64, ptr %rgep4221, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4222, ptr %slot566, align 8
  %v4223 = load i64, ptr %slot566, align 8
  %op4224 = add i64 %v4223, 1
  store i64 %op4224, ptr %slot567, align 8
  %v4225 = load i64, ptr %slot567, align 8
  %cmp4226 = icmp eq i64 %v4225, 0
  %cv4227 = zext i1 %cmp4226 to i32
  store i32 %cv4227, ptr %slot568, align 8
  %v4228 = load i32, ptr %slot568, align 8
  %cv4229 = zext i32 %v4228 to i64
  %cond4230 = icmp ne i64 %cv4229, 0
  br i1 %cond4230, label %bb_rcglimit670, label %bb_rcgcapacity670
bb_rcglimit670:
  %v4231 = load i64, ptr %slot1, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %call4233 = call i32 @myl_qbe_rc_status(ptr %p4232, i32 2) nomerge, !dbg !138
  store i32 %call4233, ptr %slot569, align 8
  br label %bb_failure
bb_rcgcapacity670:
  %v4234 = load i64, ptr %slot567, align 8
  %v4235 = load i64, ptr %slot554, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  %rgep4237 = getelementptr i8, ptr %p4236, i64 -24
  store i64 %v4234, ptr %rgep4237, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore670
bb_rcgstore670:
  %v4238 = load i64, ptr %slot554, align 8
  %v4239 = load i64, ptr %slot559, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  store i64 %v4238, ptr %p4240, align 8, !alias.scope !3, !noalias !4
  %v4241 = load i64, ptr %slot22, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  store i32 2, ptr %p4242, align 4, !alias.scope !3, !noalias !4
  %v4243 = load i64, ptr %slot22, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  store i32 8, ptr %p4244, align 4, !alias.scope !3, !noalias !4
  %v4245 = load i64, ptr %slot21, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  store i32 1, ptr %p4246, align 4, !alias.scope !3, !noalias !4
  %v4247 = load i64, ptr %slot24, align 8
  store i64 %v4247, ptr %slot570, align 8
  %v4248 = load i64, ptr %slot28, align 8
  store i64 %v4248, ptr %slot571, align 8
  %v4249 = load i64, ptr %slot571, align 8
  %p4250 = inttoptr i64 %v4249 to ptr
  %ld4251 = load i64, ptr %p4250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4251, ptr %slot572, align 8
  %v4252 = load i64, ptr %slot572, align 8
  %v4253 = load i64, ptr %slot570, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  store i64 %v4252, ptr %p4254, align 8, !alias.scope !3, !noalias !4
  %v4255 = load i64, ptr %slot18, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  store i32 2, ptr %p4256, align 4, !alias.scope !3, !noalias !4
  %v4257 = load i64, ptr %slot18, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  store i32 8, ptr %p4258, align 4, !alias.scope !3, !noalias !4
  %v4259 = load i64, ptr %slot17, align 8
  %p4260 = inttoptr i64 %v4259 to ptr
  store i32 1, ptr %p4260, align 4, !alias.scope !3, !noalias !4
  %v4261 = load i64, ptr %slot21, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  store i32 0, ptr %p4262, align 4, !alias.scope !3, !noalias !4
  %v4263 = load i64, ptr %slot572, align 8
  %v4264 = load i64, ptr %slot50, align 8
  %p4265 = inttoptr i64 %v4264 to ptr
  store i64 %v4263, ptr %p4265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined660
bb_rcordinary660:
  %v4266 = load i64, ptr %slot554, align 8
  %v4267 = load i64, ptr %slot50, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  store i64 %v4266, ptr %p4268, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined660
bb_rcholdjoined660:
  %v4269 = load i64, ptr %slot18, align 8
  %p4270 = inttoptr i64 %v4269 to ptr
  %ld4271 = load i32, ptr %p4270, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4271, ptr %slot573, align 8
  %v4272 = load i32, ptr %slot573, align 8
  %cmp4273 = icmp eq i32 %v4272, 8
  %cv4274 = zext i1 %cmp4273 to i32
  store i32 %cv4274, ptr %slot574, align 8
  %v4275 = load i64, ptr %slot17, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  %ld4277 = load i32, ptr %p4276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4277, ptr %slot575, align 8
  %v4278 = load i32, ptr %slot574, align 8
  %v4279 = load i32, ptr %slot575, align 8
  %op4280 = and i32 %v4278, %v4279
  store i32 %op4280, ptr %slot576, align 8
  %v4281 = load i32, ptr %slot576, align 8
  %cv4282 = zext i32 %v4281 to i64
  %cond4283 = icmp ne i64 %cv4282, 0
  br i1 %cond4283, label %bb_rchold691, label %bb_rcordinary691
bb_rchold691:
  %v4284 = load i64, ptr %slot28, align 8
  store i64 %v4284, ptr %slot577, align 8
  %v4285 = load i64, ptr %slot50, align 8
  %p4286 = inttoptr i64 %v4285 to ptr
  %ld4287 = load i64, ptr %p4286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4287, ptr %slot578, align 8
  %v4288 = load i64, ptr %slot578, align 8
  %v4289 = load i64, ptr %slot577, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  store i64 %v4288, ptr %p4290, align 8, !alias.scope !3, !noalias !4
  %v4291 = load i64, ptr %slot22, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i32 2, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot22, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 8, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot21, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  store i32 1, ptr %p4296, align 4, !alias.scope !3, !noalias !4
  %v4297 = load i64, ptr %slot17, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  store i32 0, ptr %p4298, align 4, !alias.scope !3, !noalias !4
  %v4299 = load i64, ptr %slot11, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  %ld4301 = load i32, ptr %p4300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4301, ptr %slot579, align 8
  %v4302 = load i32, ptr %slot579, align 8
  %cv4303 = zext i32 %v4302 to i64
  %cond4304 = icmp ne i64 %cv4303, 0
  br i1 %cond4304, label %bb_rcslotdrop706, label %bb_rcslotdone706
bb_rcslotdrop706:
  %v4305 = load i64, ptr %slot11, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  store i32 0, ptr %p4306, align 4, !alias.scope !3, !noalias !4
  %v4307 = load i64, ptr %slot44, align 8
  store i64 %v4307, ptr %slot580, align 8
  %v4308 = load i64, ptr %slot12, align 8
  %p4309 = inttoptr i64 %v4308 to ptr
  %ld4310 = load i32, ptr %p4309, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4310, ptr %slot581, align 8
  %v4311 = load i32, ptr %slot581, align 8
  %op4312 = and i32 %v4311, 28
  store i32 %op4312, ptr %slot582, align 8
  %v4313 = load i32, ptr %slot582, align 8
  %cv4314 = zext i32 %v4313 to i64
  %cond4315 = icmp ne i64 %cv4314, 0
  br i1 %cond4315, label %bb_rcslotrole706, label %bb_rcslotowner706
bb_rcslotrole706:
  %v4316 = load i64, ptr %slot59, align 8
  store i64 %v4316, ptr %slot583, align 8
  %v4317 = load i64, ptr %slot580, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %ld4319 = load i64, ptr %p4318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4319, ptr %slot584, align 8
  %v4320 = load i64, ptr %slot584, align 8
  %cmp4321 = icmp ne i64 %v4320, 0
  %cv4322 = zext i1 %cmp4321 to i32
  store i32 %cv4322, ptr %slot585, align 8
  %v4323 = load i32, ptr %slot585, align 8
  %cv4324 = zext i32 %v4323 to i64
  %cond4325 = icmp ne i64 %cv4324, 0
  br i1 %cond4325, label %bb_rcgnn722, label %bb_rcgdone722
bb_rcgnn722:
  %v4326 = load i64, ptr %slot584, align 8
  %op4327 = sub i64 %v4326, 16
  store i64 %op4327, ptr %slot586, align 8
  %v4328 = load i64, ptr %slot584, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %rgep4330 = getelementptr i8, ptr %p4329, i64 -16
  %ld4331 = load i64, ptr %rgep4330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4331, ptr %slot587, align 8
  %v4332 = load i64, ptr %slot587, align 8
  %op4333 = and i64 %v4332, 4611686018427387906
  store i64 %op4333, ptr %slot588, align 8
  %v4334 = load i64, ptr %slot588, align 8
  %cmp4335 = icmp ne i64 %v4334, 0
  %cv4336 = zext i1 %cmp4335 to i32
  store i32 %cv4336, ptr %slot589, align 8
  %v4337 = load i32, ptr %slot589, align 8
  %cv4338 = zext i32 %v4337 to i64
  %cond4339 = icmp ne i64 %cv4338, 0
  br i1 %cond4339, label %bb_rcgclear722, label %bb_rcgcounted722
bb_rcgcounted722:
  %v4340 = load i64, ptr %slot584, align 8
  %op4341 = sub i64 %v4340, 24
  store i64 %op4341, ptr %slot590, align 8
  %v4342 = load i64, ptr %slot584, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %rgep4344 = getelementptr i8, ptr %p4343, i64 -24
  %ld4345 = load i64, ptr %rgep4344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4345, ptr %slot591, align 8
  %v4346 = load i64, ptr %slot591, align 8
  %op4347 = sub i64 %v4346, 1
  store i64 %op4347, ptr %slot592, align 8
  %v4348 = load i64, ptr %slot592, align 8
  %cmp4349 = icmp eq i64 %v4348, 0
  %cv4350 = zext i1 %cmp4349 to i32
  store i32 %cv4350, ptr %slot593, align 8
  %v4351 = load i32, ptr %slot593, align 8
  %cv4352 = zext i32 %v4351 to i64
  %cond4353 = icmp ne i64 %cv4352, 0
  br i1 %cond4353, label %bb_rcglast722, label %bb_rcgdec722
bb_rcglast722:
  %v4354 = load i64, ptr %slot584, align 8
  %op4355 = sub i64 %v4354, 32
  store i64 %op4355, ptr %slot594, align 8
  %v4356 = load i64, ptr %slot584, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  %rgep4358 = getelementptr i8, ptr %p4357, i64 -32
  %ld4359 = load i64, ptr %rgep4358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4359, ptr %slot595, align 8
  %v4360 = load i64, ptr %slot595, align 8
  %cmp4361 = icmp ne i64 %v4360, 0
  %cv4362 = zext i1 %cmp4361 to i32
  store i32 %cv4362, ptr %slot596, align 8
  %v4363 = load i32, ptr %slot596, align 8
  %cv4364 = zext i32 %v4363 to i64
  %cond4365 = icmp ne i64 %cv4364, 0
  br i1 %cond4365, label %bb_rcgdec722, label %bb_rcgslow722
bb_rcgslow722:
  %v4366 = load i64, ptr %slot583, align 8
  %v4367 = load i64, ptr %slot580, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v4366, i64 %v4367) nomerge, !dbg !140
  br label %bb_rcgdone722
bb_rcgdec722:
  %v4368 = load i64, ptr %slot592, align 8
  %v4369 = load i64, ptr %slot584, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  %rgep4371 = getelementptr i8, ptr %p4370, i64 -24
  store i64 %v4368, ptr %rgep4371, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear722
bb_rcgclear722:
  %v4372 = load i64, ptr %slot580, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  store i64 0, ptr %p4373, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone722
bb_rcgdone722:
  br label %bb_rcslotdone706
bb_rcslotowner706:
  %v4374 = load i64, ptr %slot59, align 8
  store i64 %v4374, ptr %slot597, align 8
  %v4375 = load i64, ptr %slot580, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  %ld4377 = load i64, ptr %p4376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4377, ptr %slot598, align 8
  %v4378 = load i64, ptr %slot598, align 8
  %cmp4379 = icmp ne i64 %v4378, 0
  %cv4380 = zext i1 %cmp4379 to i32
  store i32 %cv4380, ptr %slot599, align 8
  %v4381 = load i32, ptr %slot599, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcgnn737, label %bb_rcgdone737
bb_rcgnn737:
  %v4384 = load i64, ptr %slot598, align 8
  %op4385 = sub i64 %v4384, 16
  store i64 %op4385, ptr %slot600, align 8
  %v4386 = load i64, ptr %slot598, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  %rgep4388 = getelementptr i8, ptr %p4387, i64 -16
  %ld4389 = load i64, ptr %rgep4388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4389, ptr %slot601, align 8
  %v4390 = load i64, ptr %slot601, align 8
  %op4391 = and i64 %v4390, 4611686018427387906
  store i64 %op4391, ptr %slot602, align 8
  %v4392 = load i64, ptr %slot602, align 8
  %cmp4393 = icmp ne i64 %v4392, 0
  %cv4394 = zext i1 %cmp4393 to i32
  store i32 %cv4394, ptr %slot603, align 8
  %v4395 = load i32, ptr %slot603, align 8
  %cv4396 = zext i32 %v4395 to i64
  %cond4397 = icmp ne i64 %cv4396, 0
  br i1 %cond4397, label %bb_rcgclear737, label %bb_rcgcounted737
bb_rcgcounted737:
  %v4398 = load i64, ptr %slot598, align 8
  %op4399 = sub i64 %v4398, 32
  store i64 %op4399, ptr %slot604, align 8
  %v4400 = load i64, ptr %slot598, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %rgep4402 = getelementptr i8, ptr %p4401, i64 -32
  %ld4403 = load i64, ptr %rgep4402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4403, ptr %slot605, align 8
  %v4404 = load i64, ptr %slot605, align 8
  %op4405 = sub i64 %v4404, 1
  store i64 %op4405, ptr %slot606, align 8
  %v4406 = load i64, ptr %slot606, align 8
  %cmp4407 = icmp eq i64 %v4406, 0
  %cv4408 = zext i1 %cmp4407 to i32
  store i32 %cv4408, ptr %slot607, align 8
  %v4409 = load i32, ptr %slot607, align 8
  %cv4410 = zext i32 %v4409 to i64
  %cond4411 = icmp ne i64 %cv4410, 0
  br i1 %cond4411, label %bb_rcglast737, label %bb_rcgdec737
bb_rcglast737:
  %v4412 = load i64, ptr %slot598, align 8
  %op4413 = sub i64 %v4412, 24
  store i64 %op4413, ptr %slot608, align 8
  %v4414 = load i64, ptr %slot598, align 8
  %p4415 = inttoptr i64 %v4414 to ptr
  %rgep4416 = getelementptr i8, ptr %p4415, i64 -24
  %ld4417 = load i64, ptr %rgep4416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4417, ptr %slot609, align 8
  %v4418 = load i64, ptr %slot609, align 8
  %cmp4419 = icmp ne i64 %v4418, 0
  %cv4420 = zext i1 %cmp4419 to i32
  store i32 %cv4420, ptr %slot610, align 8
  %v4421 = load i32, ptr %slot610, align 8
  %cv4422 = zext i32 %v4421 to i64
  %cond4423 = icmp ne i64 %cv4422, 0
  br i1 %cond4423, label %bb_rcgdec737, label %bb_rcgslow737
bb_rcgslow737:
  %v4424 = load i64, ptr %slot597, align 8
  %v4425 = load i64, ptr %slot580, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4424, i64 %v4425) nomerge, !dbg !140
  br label %bb_rcgdone737
bb_rcgdec737:
  %v4426 = load i64, ptr %slot606, align 8
  %v4427 = load i64, ptr %slot598, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  %rgep4429 = getelementptr i8, ptr %p4428, i64 -32
  store i64 %v4426, ptr %rgep4429, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear737
bb_rcgclear737:
  %v4430 = load i64, ptr %slot580, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  store i64 0, ptr %p4431, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone737
bb_rcgdone737:
  br label %bb_rcslotdone706
bb_rcslotdone706:
  %v4432 = load i64, ptr %slot44, align 8
  store i64 %v4432, ptr %slot611, align 8
  %v4433 = load i64, ptr %slot577, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4435, ptr %slot612, align 8
  %v4436 = load i64, ptr %slot612, align 8
  %v4437 = load i64, ptr %slot611, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  store i64 %v4436, ptr %p4438, align 8, !alias.scope !3, !noalias !4
  %v4439 = load i64, ptr %slot12, align 8
  %p4440 = inttoptr i64 %v4439 to ptr
  store i32 2, ptr %p4440, align 4, !alias.scope !3, !noalias !4
  %v4441 = load i64, ptr %slot12, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i32 8, ptr %p4442, align 4, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot11, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  store i32 1, ptr %p4444, align 4, !alias.scope !3, !noalias !4
  %v4445 = load i64, ptr %slot21, align 8
  %p4446 = inttoptr i64 %v4445 to ptr
  store i32 0, ptr %p4446, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined691
bb_rcordinary691:
  %v4447 = load i64, ptr %slot17, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  %ld4449 = load i32, ptr %p4448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4449, ptr %slot613, align 8
  %v4450 = load i32, ptr %slot613, align 8
  %cv4451 = zext i32 %v4450 to i64
  %cond4452 = icmp ne i64 %cv4451, 0
  br i1 %cond4452, label %bb_rcslotdrop749, label %bb_rcslotdone749
bb_rcslotdrop749:
  %v4453 = load i64, ptr %slot17, align 8
  %p4454 = inttoptr i64 %v4453 to ptr
  store i32 0, ptr %p4454, align 4, !alias.scope !3, !noalias !4
  %v4455 = load i64, ptr %slot24, align 8
  store i64 %v4455, ptr %slot614, align 8
  %v4456 = load i64, ptr %slot18, align 8
  %p4457 = inttoptr i64 %v4456 to ptr
  %ld4458 = load i32, ptr %p4457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4458, ptr %slot615, align 8
  %v4459 = load i32, ptr %slot615, align 8
  %op4460 = and i32 %v4459, 28
  store i32 %op4460, ptr %slot616, align 8
  %v4461 = load i32, ptr %slot616, align 8
  %cv4462 = zext i32 %v4461 to i64
  %cond4463 = icmp ne i64 %cv4462, 0
  br i1 %cond4463, label %bb_rcslotrole749, label %bb_rcslotowner749
bb_rcslotrole749:
  %v4464 = load i64, ptr %slot59, align 8
  store i64 %v4464, ptr %slot617, align 8
  %v4465 = load i64, ptr %slot614, align 8
  %p4466 = inttoptr i64 %v4465 to ptr
  %ld4467 = load i64, ptr %p4466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4467, ptr %slot618, align 8
  %v4468 = load i64, ptr %slot618, align 8
  %cmp4469 = icmp ne i64 %v4468, 0
  %cv4470 = zext i1 %cmp4469 to i32
  store i32 %cv4470, ptr %slot619, align 8
  %v4471 = load i32, ptr %slot619, align 8
  %cv4472 = zext i32 %v4471 to i64
  %cond4473 = icmp ne i64 %cv4472, 0
  br i1 %cond4473, label %bb_rcgnn765, label %bb_rcgdone765
bb_rcgnn765:
  %v4474 = load i64, ptr %slot618, align 8
  %op4475 = sub i64 %v4474, 16
  store i64 %op4475, ptr %slot620, align 8
  %v4476 = load i64, ptr %slot618, align 8
  %p4477 = inttoptr i64 %v4476 to ptr
  %rgep4478 = getelementptr i8, ptr %p4477, i64 -16
  %ld4479 = load i64, ptr %rgep4478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4479, ptr %slot621, align 8
  %v4480 = load i64, ptr %slot621, align 8
  %op4481 = and i64 %v4480, 4611686018427387906
  store i64 %op4481, ptr %slot622, align 8
  %v4482 = load i64, ptr %slot622, align 8
  %cmp4483 = icmp ne i64 %v4482, 0
  %cv4484 = zext i1 %cmp4483 to i32
  store i32 %cv4484, ptr %slot623, align 8
  %v4485 = load i32, ptr %slot623, align 8
  %cv4486 = zext i32 %v4485 to i64
  %cond4487 = icmp ne i64 %cv4486, 0
  br i1 %cond4487, label %bb_rcgclear765, label %bb_rcgcounted765
bb_rcgcounted765:
  %v4488 = load i64, ptr %slot618, align 8
  %op4489 = sub i64 %v4488, 24
  store i64 %op4489, ptr %slot624, align 8
  %v4490 = load i64, ptr %slot618, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  %rgep4492 = getelementptr i8, ptr %p4491, i64 -24
  %ld4493 = load i64, ptr %rgep4492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4493, ptr %slot625, align 8
  %v4494 = load i64, ptr %slot625, align 8
  %op4495 = sub i64 %v4494, 1
  store i64 %op4495, ptr %slot626, align 8
  %v4496 = load i64, ptr %slot626, align 8
  %cmp4497 = icmp eq i64 %v4496, 0
  %cv4498 = zext i1 %cmp4497 to i32
  store i32 %cv4498, ptr %slot627, align 8
  %v4499 = load i32, ptr %slot627, align 8
  %cv4500 = zext i32 %v4499 to i64
  %cond4501 = icmp ne i64 %cv4500, 0
  br i1 %cond4501, label %bb_rcglast765, label %bb_rcgdec765
bb_rcglast765:
  %v4502 = load i64, ptr %slot618, align 8
  %op4503 = sub i64 %v4502, 32
  store i64 %op4503, ptr %slot628, align 8
  %v4504 = load i64, ptr %slot618, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  %rgep4506 = getelementptr i8, ptr %p4505, i64 -32
  %ld4507 = load i64, ptr %rgep4506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4507, ptr %slot629, align 8
  %v4508 = load i64, ptr %slot629, align 8
  %cmp4509 = icmp ne i64 %v4508, 0
  %cv4510 = zext i1 %cmp4509 to i32
  store i32 %cv4510, ptr %slot630, align 8
  %v4511 = load i32, ptr %slot630, align 8
  %cv4512 = zext i32 %v4511 to i64
  %cond4513 = icmp ne i64 %cv4512, 0
  br i1 %cond4513, label %bb_rcgdec765, label %bb_rcgslow765
bb_rcgslow765:
  %v4514 = load i64, ptr %slot617, align 8
  %v4515 = load i64, ptr %slot614, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v4514, i64 %v4515) nomerge, !dbg !140
  br label %bb_rcgdone765
bb_rcgdec765:
  %v4516 = load i64, ptr %slot626, align 8
  %v4517 = load i64, ptr %slot618, align 8
  %p4518 = inttoptr i64 %v4517 to ptr
  %rgep4519 = getelementptr i8, ptr %p4518, i64 -24
  store i64 %v4516, ptr %rgep4519, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear765
bb_rcgclear765:
  %v4520 = load i64, ptr %slot614, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  store i64 0, ptr %p4521, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone765
bb_rcgdone765:
  br label %bb_rcslotdone749
bb_rcslotowner749:
  %v4522 = load i64, ptr %slot59, align 8
  store i64 %v4522, ptr %slot631, align 8
  %v4523 = load i64, ptr %slot614, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  %ld4525 = load i64, ptr %p4524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4525, ptr %slot632, align 8
  %v4526 = load i64, ptr %slot632, align 8
  %cmp4527 = icmp ne i64 %v4526, 0
  %cv4528 = zext i1 %cmp4527 to i32
  store i32 %cv4528, ptr %slot633, align 8
  %v4529 = load i32, ptr %slot633, align 8
  %cv4530 = zext i32 %v4529 to i64
  %cond4531 = icmp ne i64 %cv4530, 0
  br i1 %cond4531, label %bb_rcgnn780, label %bb_rcgdone780
bb_rcgnn780:
  %v4532 = load i64, ptr %slot632, align 8
  %op4533 = sub i64 %v4532, 16
  store i64 %op4533, ptr %slot634, align 8
  %v4534 = load i64, ptr %slot632, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  %rgep4536 = getelementptr i8, ptr %p4535, i64 -16
  %ld4537 = load i64, ptr %rgep4536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4537, ptr %slot635, align 8
  %v4538 = load i64, ptr %slot635, align 8
  %op4539 = and i64 %v4538, 4611686018427387906
  store i64 %op4539, ptr %slot636, align 8
  %v4540 = load i64, ptr %slot636, align 8
  %cmp4541 = icmp ne i64 %v4540, 0
  %cv4542 = zext i1 %cmp4541 to i32
  store i32 %cv4542, ptr %slot637, align 8
  %v4543 = load i32, ptr %slot637, align 8
  %cv4544 = zext i32 %v4543 to i64
  %cond4545 = icmp ne i64 %cv4544, 0
  br i1 %cond4545, label %bb_rcgclear780, label %bb_rcgcounted780
bb_rcgcounted780:
  %v4546 = load i64, ptr %slot632, align 8
  %op4547 = sub i64 %v4546, 32
  store i64 %op4547, ptr %slot638, align 8
  %v4548 = load i64, ptr %slot632, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  %rgep4550 = getelementptr i8, ptr %p4549, i64 -32
  %ld4551 = load i64, ptr %rgep4550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4551, ptr %slot639, align 8
  %v4552 = load i64, ptr %slot639, align 8
  %op4553 = sub i64 %v4552, 1
  store i64 %op4553, ptr %slot640, align 8
  %v4554 = load i64, ptr %slot640, align 8
  %cmp4555 = icmp eq i64 %v4554, 0
  %cv4556 = zext i1 %cmp4555 to i32
  store i32 %cv4556, ptr %slot641, align 8
  %v4557 = load i32, ptr %slot641, align 8
  %cv4558 = zext i32 %v4557 to i64
  %cond4559 = icmp ne i64 %cv4558, 0
  br i1 %cond4559, label %bb_rcglast780, label %bb_rcgdec780
bb_rcglast780:
  %v4560 = load i64, ptr %slot632, align 8
  %op4561 = sub i64 %v4560, 24
  store i64 %op4561, ptr %slot642, align 8
  %v4562 = load i64, ptr %slot632, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  %rgep4564 = getelementptr i8, ptr %p4563, i64 -24
  %ld4565 = load i64, ptr %rgep4564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4565, ptr %slot643, align 8
  %v4566 = load i64, ptr %slot643, align 8
  %cmp4567 = icmp ne i64 %v4566, 0
  %cv4568 = zext i1 %cmp4567 to i32
  store i32 %cv4568, ptr %slot644, align 8
  %v4569 = load i32, ptr %slot644, align 8
  %cv4570 = zext i32 %v4569 to i64
  %cond4571 = icmp ne i64 %cv4570, 0
  br i1 %cond4571, label %bb_rcgdec780, label %bb_rcgslow780
bb_rcgslow780:
  %v4572 = load i64, ptr %slot631, align 8
  %v4573 = load i64, ptr %slot614, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4572, i64 %v4573) nomerge, !dbg !140
  br label %bb_rcgdone780
bb_rcgdec780:
  %v4574 = load i64, ptr %slot640, align 8
  %v4575 = load i64, ptr %slot632, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  %rgep4577 = getelementptr i8, ptr %p4576, i64 -32
  store i64 %v4574, ptr %rgep4577, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear780
bb_rcgclear780:
  %v4578 = load i64, ptr %slot614, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  store i64 0, ptr %p4579, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone780
bb_rcgdone780:
  br label %bb_rcslotdone749
bb_rcslotdone749:
  %v4580 = load i64, ptr %slot11, align 8
  %p4581 = inttoptr i64 %v4580 to ptr
  %ld4582 = load i32, ptr %p4581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4582, ptr %slot645, align 8
  %v4583 = load i32, ptr %slot645, align 8
  %cv4584 = zext i32 %v4583 to i64
  %cond4585 = icmp ne i64 %cv4584, 0
  br i1 %cond4585, label %bb_rcslotdrop786, label %bb_rcslotdone786
bb_rcslotdrop786:
  %v4586 = load i64, ptr %slot11, align 8
  %p4587 = inttoptr i64 %v4586 to ptr
  store i32 0, ptr %p4587, align 4, !alias.scope !3, !noalias !4
  %v4588 = load i64, ptr %slot44, align 8
  store i64 %v4588, ptr %slot646, align 8
  %v4589 = load i64, ptr %slot12, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %ld4591 = load i32, ptr %p4590, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4591, ptr %slot647, align 8
  %v4592 = load i32, ptr %slot647, align 8
  %op4593 = and i32 %v4592, 28
  store i32 %op4593, ptr %slot648, align 8
  %v4594 = load i32, ptr %slot648, align 8
  %cv4595 = zext i32 %v4594 to i64
  %cond4596 = icmp ne i64 %cv4595, 0
  br i1 %cond4596, label %bb_rcslotrole786, label %bb_rcslotowner786
bb_rcslotrole786:
  %v4597 = load i64, ptr %slot59, align 8
  store i64 %v4597, ptr %slot649, align 8
  %v4598 = load i64, ptr %slot646, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i64, ptr %p4599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4600, ptr %slot650, align 8
  %v4601 = load i64, ptr %slot650, align 8
  %cmp4602 = icmp ne i64 %v4601, 0
  %cv4603 = zext i1 %cmp4602 to i32
  store i32 %cv4603, ptr %slot651, align 8
  %v4604 = load i32, ptr %slot651, align 8
  %cv4605 = zext i32 %v4604 to i64
  %cond4606 = icmp ne i64 %cv4605, 0
  br i1 %cond4606, label %bb_rcgnn802, label %bb_rcgdone802
bb_rcgnn802:
  %v4607 = load i64, ptr %slot650, align 8
  %op4608 = sub i64 %v4607, 16
  store i64 %op4608, ptr %slot652, align 8
  %v4609 = load i64, ptr %slot650, align 8
  %p4610 = inttoptr i64 %v4609 to ptr
  %rgep4611 = getelementptr i8, ptr %p4610, i64 -16
  %ld4612 = load i64, ptr %rgep4611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4612, ptr %slot653, align 8
  %v4613 = load i64, ptr %slot653, align 8
  %op4614 = and i64 %v4613, 4611686018427387906
  store i64 %op4614, ptr %slot654, align 8
  %v4615 = load i64, ptr %slot654, align 8
  %cmp4616 = icmp ne i64 %v4615, 0
  %cv4617 = zext i1 %cmp4616 to i32
  store i32 %cv4617, ptr %slot655, align 8
  %v4618 = load i32, ptr %slot655, align 8
  %cv4619 = zext i32 %v4618 to i64
  %cond4620 = icmp ne i64 %cv4619, 0
  br i1 %cond4620, label %bb_rcgclear802, label %bb_rcgcounted802
bb_rcgcounted802:
  %v4621 = load i64, ptr %slot650, align 8
  %op4622 = sub i64 %v4621, 24
  store i64 %op4622, ptr %slot656, align 8
  %v4623 = load i64, ptr %slot650, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  %rgep4625 = getelementptr i8, ptr %p4624, i64 -24
  %ld4626 = load i64, ptr %rgep4625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4626, ptr %slot657, align 8
  %v4627 = load i64, ptr %slot657, align 8
  %op4628 = sub i64 %v4627, 1
  store i64 %op4628, ptr %slot658, align 8
  %v4629 = load i64, ptr %slot658, align 8
  %cmp4630 = icmp eq i64 %v4629, 0
  %cv4631 = zext i1 %cmp4630 to i32
  store i32 %cv4631, ptr %slot659, align 8
  %v4632 = load i32, ptr %slot659, align 8
  %cv4633 = zext i32 %v4632 to i64
  %cond4634 = icmp ne i64 %cv4633, 0
  br i1 %cond4634, label %bb_rcglast802, label %bb_rcgdec802
bb_rcglast802:
  %v4635 = load i64, ptr %slot650, align 8
  %op4636 = sub i64 %v4635, 32
  store i64 %op4636, ptr %slot660, align 8
  %v4637 = load i64, ptr %slot650, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  %rgep4639 = getelementptr i8, ptr %p4638, i64 -32
  %ld4640 = load i64, ptr %rgep4639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4640, ptr %slot661, align 8
  %v4641 = load i64, ptr %slot661, align 8
  %cmp4642 = icmp ne i64 %v4641, 0
  %cv4643 = zext i1 %cmp4642 to i32
  store i32 %cv4643, ptr %slot662, align 8
  %v4644 = load i32, ptr %slot662, align 8
  %cv4645 = zext i32 %v4644 to i64
  %cond4646 = icmp ne i64 %cv4645, 0
  br i1 %cond4646, label %bb_rcgdec802, label %bb_rcgslow802
bb_rcgslow802:
  %v4647 = load i64, ptr %slot649, align 8
  %v4648 = load i64, ptr %slot646, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v4647, i64 %v4648) nomerge, !dbg !140
  br label %bb_rcgdone802
bb_rcgdec802:
  %v4649 = load i64, ptr %slot658, align 8
  %v4650 = load i64, ptr %slot650, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %rgep4652 = getelementptr i8, ptr %p4651, i64 -24
  store i64 %v4649, ptr %rgep4652, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear802
bb_rcgclear802:
  %v4653 = load i64, ptr %slot646, align 8
  %p4654 = inttoptr i64 %v4653 to ptr
  store i64 0, ptr %p4654, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone802
bb_rcgdone802:
  br label %bb_rcslotdone786
bb_rcslotowner786:
  %v4655 = load i64, ptr %slot59, align 8
  store i64 %v4655, ptr %slot663, align 8
  %v4656 = load i64, ptr %slot646, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %ld4658 = load i64, ptr %p4657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4658, ptr %slot664, align 8
  %v4659 = load i64, ptr %slot664, align 8
  %cmp4660 = icmp ne i64 %v4659, 0
  %cv4661 = zext i1 %cmp4660 to i32
  store i32 %cv4661, ptr %slot665, align 8
  %v4662 = load i32, ptr %slot665, align 8
  %cv4663 = zext i32 %v4662 to i64
  %cond4664 = icmp ne i64 %cv4663, 0
  br i1 %cond4664, label %bb_rcgnn817, label %bb_rcgdone817
bb_rcgnn817:
  %v4665 = load i64, ptr %slot664, align 8
  %op4666 = sub i64 %v4665, 16
  store i64 %op4666, ptr %slot666, align 8
  %v4667 = load i64, ptr %slot664, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %rgep4669 = getelementptr i8, ptr %p4668, i64 -16
  %ld4670 = load i64, ptr %rgep4669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4670, ptr %slot667, align 8
  %v4671 = load i64, ptr %slot667, align 8
  %op4672 = and i64 %v4671, 4611686018427387906
  store i64 %op4672, ptr %slot668, align 8
  %v4673 = load i64, ptr %slot668, align 8
  %cmp4674 = icmp ne i64 %v4673, 0
  %cv4675 = zext i1 %cmp4674 to i32
  store i32 %cv4675, ptr %slot669, align 8
  %v4676 = load i32, ptr %slot669, align 8
  %cv4677 = zext i32 %v4676 to i64
  %cond4678 = icmp ne i64 %cv4677, 0
  br i1 %cond4678, label %bb_rcgclear817, label %bb_rcgcounted817
bb_rcgcounted817:
  %v4679 = load i64, ptr %slot664, align 8
  %op4680 = sub i64 %v4679, 32
  store i64 %op4680, ptr %slot670, align 8
  %v4681 = load i64, ptr %slot664, align 8
  %p4682 = inttoptr i64 %v4681 to ptr
  %rgep4683 = getelementptr i8, ptr %p4682, i64 -32
  %ld4684 = load i64, ptr %rgep4683, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4684, ptr %slot671, align 8
  %v4685 = load i64, ptr %slot671, align 8
  %op4686 = sub i64 %v4685, 1
  store i64 %op4686, ptr %slot672, align 8
  %v4687 = load i64, ptr %slot672, align 8
  %cmp4688 = icmp eq i64 %v4687, 0
  %cv4689 = zext i1 %cmp4688 to i32
  store i32 %cv4689, ptr %slot673, align 8
  %v4690 = load i32, ptr %slot673, align 8
  %cv4691 = zext i32 %v4690 to i64
  %cond4692 = icmp ne i64 %cv4691, 0
  br i1 %cond4692, label %bb_rcglast817, label %bb_rcgdec817
bb_rcglast817:
  %v4693 = load i64, ptr %slot664, align 8
  %op4694 = sub i64 %v4693, 24
  store i64 %op4694, ptr %slot674, align 8
  %v4695 = load i64, ptr %slot664, align 8
  %p4696 = inttoptr i64 %v4695 to ptr
  %rgep4697 = getelementptr i8, ptr %p4696, i64 -24
  %ld4698 = load i64, ptr %rgep4697, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4698, ptr %slot675, align 8
  %v4699 = load i64, ptr %slot675, align 8
  %cmp4700 = icmp ne i64 %v4699, 0
  %cv4701 = zext i1 %cmp4700 to i32
  store i32 %cv4701, ptr %slot676, align 8
  %v4702 = load i32, ptr %slot676, align 8
  %cv4703 = zext i32 %v4702 to i64
  %cond4704 = icmp ne i64 %cv4703, 0
  br i1 %cond4704, label %bb_rcgdec817, label %bb_rcgslow817
bb_rcgslow817:
  %v4705 = load i64, ptr %slot663, align 8
  %v4706 = load i64, ptr %slot646, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4705, i64 %v4706) nomerge, !dbg !140
  br label %bb_rcgdone817
bb_rcgdec817:
  %v4707 = load i64, ptr %slot672, align 8
  %v4708 = load i64, ptr %slot664, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  %rgep4710 = getelementptr i8, ptr %p4709, i64 -32
  store i64 %v4707, ptr %rgep4710, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear817
bb_rcgclear817:
  %v4711 = load i64, ptr %slot646, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  store i64 0, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone817
bb_rcgdone817:
  br label %bb_rcslotdone786
bb_rcslotdone786:
  %v4713 = load i64, ptr %slot37, align 8
  store i64 %v4713, ptr %slot677, align 8
  %v4714 = load i64, ptr %slot8, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  store i32 2, ptr %p4715, align 4, !alias.scope !3, !noalias !4
  %v4716 = load i64, ptr %slot677, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  %ld4718 = load i64, ptr %p4717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4718, ptr %slot678, align 8
  %v4719 = load i64, ptr %slot678, align 8
  %cmp4720 = icmp ne i64 %v4719, 0
  %cv4721 = zext i1 %cmp4720 to i32
  store i32 %cv4721, ptr %slot679, align 8
  %v4722 = load i32, ptr %slot679, align 8
  %cv4723 = zext i32 %v4722 to i64
  %cond4724 = icmp ne i64 %cv4723, 0
  br i1 %cond4724, label %bb_rcguniquenn824, label %bb_rcgunique824
bb_rcguniquenn824:
  %v4725 = load i64, ptr %slot678, align 8
  %op4726 = sub i64 %v4725, 16
  store i64 %op4726, ptr %slot680, align 8
  %v4727 = load i64, ptr %slot678, align 8
  %p4728 = inttoptr i64 %v4727 to ptr
  %rgep4729 = getelementptr i8, ptr %p4728, i64 -16
  %ld4730 = load i64, ptr %rgep4729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4730, ptr %slot681, align 8
  %v4731 = load i64, ptr %slot681, align 8
  %op4732 = and i64 %v4731, 6917529027641081858
  store i64 %op4732, ptr %slot682, align 8
  %v4733 = load i64, ptr %slot682, align 8
  %cmp4734 = icmp ne i64 %v4733, 0
  %cv4735 = zext i1 %cmp4734 to i32
  store i32 %cv4735, ptr %slot683, align 8
  %v4736 = load i32, ptr %slot683, align 8
  %cv4737 = zext i32 %v4736 to i64
  %cond4738 = icmp ne i64 %cv4737, 0
  br i1 %cond4738, label %bb_rcguniqueslow824, label %bb_rcguniquecount824
bb_rcguniquecount824:
  %v4739 = load i64, ptr %slot678, align 8
  %op4740 = sub i64 %v4739, 32
  store i64 %op4740, ptr %slot684, align 8
  %v4741 = load i64, ptr %slot678, align 8
  %p4742 = inttoptr i64 %v4741 to ptr
  %rgep4743 = getelementptr i8, ptr %p4742, i64 -32
  %ld4744 = load i64, ptr %rgep4743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4744, ptr %slot685, align 8
  %v4745 = load i64, ptr %slot685, align 8
  %cmp4746 = icmp ult i64 %v4745, 2
  %cv4747 = zext i1 %cmp4746 to i32
  store i32 %cv4747, ptr %slot686, align 8
  %v4748 = load i32, ptr %slot686, align 8
  %cv4749 = zext i32 %v4748 to i64
  %cond4750 = icmp ne i64 %cv4749, 0
  br i1 %cond4750, label %bb_rcgunique824, label %bb_rcguniqueslow824
bb_rcguniqueslow824:
  %v4751 = load i64, ptr %slot1, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  %p4753 = inttoptr i64 ptrtoint (ptr @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c to i64) to ptr
  %v4754 = load i64, ptr %slot677, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  %v4756 = load i64, ptr %slot7, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  %call4758 = call i32 @myl_qbe_rc_unique_local(ptr %p4752, ptr %p4753, ptr %p4755, ptr %p4757) nomerge, !dbg !140
  store i32 %call4758, ptr %slot687, align 8
  %v4759 = load i32, ptr %slot687, align 8
  %cv4760 = zext i32 %v4759 to i64
  %cond4761 = icmp ne i64 %cv4760, 0
  br i1 %cond4761, label %bb_rcunique835, label %bb_failure
bb_rcunique835:
  br label %bb_rcgunique824
bb_rcgunique824:
  %v4762 = load i64, ptr %slot37, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %ld4764 = load i64, ptr %p4763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4764, ptr %slot688, align 8
  %v4765 = load i64, ptr %slot29, align 8
  store i64 %v4765, ptr %slot689, align 8
  %v4766 = load i64, ptr %slot59, align 8
  %v4767 = load i64, ptr %slot689, align 8
  %p4768 = inttoptr i64 %v4767 to ptr
  store i64 %v4766, ptr %p4768, align 8, !alias.scope !3, !noalias !4
  %v4769 = load i64, ptr %slot59, align 8
  %p4771 = inttoptr i64 %v4769 to ptr
  %gep4772 = getelementptr i8, ptr %p4771, i64 5640
  %op4770 = ptrtoint ptr %gep4772 to i64
  store i64 %op4770, ptr %slot690, align 8
  %v4773 = load i64, ptr %slot690, align 8
  %p4774 = inttoptr i64 %v4773 to ptr
  %ld4775 = load i64, ptr %p4774, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4775, ptr %slot691, align 8
  %v4776 = load i64, ptr %slot691, align 8
  %op4777 = add i64 %v4776, 248
  store i64 %op4777, ptr %slot692, align 8
  %v4778 = load i64, ptr %slot692, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %ld4780 = load i64, ptr %p4779, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4780, ptr %slot693, align 8
  %v4781 = load i64, ptr %slot689, align 8
  %p4783 = inttoptr i64 %v4781 to ptr
  %gep4784 = getelementptr i8, ptr %p4783, i64 8
  %op4782 = ptrtoint ptr %gep4784 to i64
  store i64 %op4782, ptr %slot694, align 8
  %v4785 = load i64, ptr %slot693, align 8
  %v4786 = load i64, ptr %slot694, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i64 %v4785, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot689, align 8
  %p4790 = inttoptr i64 %v4788 to ptr
  %gep4791 = getelementptr i8, ptr %p4790, i64 16
  %op4789 = ptrtoint ptr %gep4791 to i64
  store i64 %op4789, ptr %slot695, align 8
  %v4792 = load i64, ptr %slot695, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i64 0, ptr %p4793, align 8, !alias.scope !3, !noalias !4
  %v4794 = load i64, ptr %slot59, align 8
  %p4796 = inttoptr i64 %v4794 to ptr
  %gep4797 = getelementptr i8, ptr %p4796, i64 112
  %op4795 = ptrtoint ptr %gep4797 to i64
  store i64 %op4795, ptr %slot696, align 8
  %v4798 = load i64, ptr %slot689, align 8
  %p4800 = inttoptr i64 %v4798 to ptr
  %gep4801 = getelementptr i8, ptr %p4800, i64 24
  %op4799 = ptrtoint ptr %gep4801 to i64
  store i64 %op4799, ptr %slot697, align 8
  %v4802 = load i64, ptr %slot689, align 8
  %p4804 = inttoptr i64 %v4802 to ptr
  %gep4805 = getelementptr i8, ptr %p4804, i64 28
  %op4803 = ptrtoint ptr %gep4805 to i64
  store i64 %op4803, ptr %slot698, align 8
  %v4806 = load i64, ptr %slot696, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  %ld4808 = load i32, ptr %p4807, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4808, ptr %slot699, align 8
  %v4809 = load i64, ptr %slot697, align 8
  %p4810 = inttoptr i64 %v4809 to ptr
  store i32 1, ptr %p4810, align 4, !alias.scope !3, !noalias !4
  %v4811 = load i32, ptr %slot699, align 8
  %v4812 = load i64, ptr %slot698, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  store i32 %v4811, ptr %p4813, align 4, !alias.scope !3, !noalias !4
  %v4814 = load i64, ptr %slot689, align 8
  %v4815 = load i64, ptr %slot692, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  store i64 %v4814, ptr %p4816, align 8, !alias.scope !9999998, !noalias !9999999
  %v4817 = load i64, ptr %slot688, align 8
  %cmp4818 = icmp ne i64 %v4817, 0
  %cv4819 = zext i1 %cmp4818 to i32
  store i32 %cv4819, ptr %slot700, align 8
  %v4820 = load i32, ptr %slot700, align 8
  %cv4821 = zext i32 %v4820 to i64
  %cond4822 = icmp ne i64 %cv4821, 0
  br i1 %cond4822, label %bb_rcspinmark848, label %bb_rcspindone848
bb_rcspinmark848:
  %v4823 = load i64, ptr %slot688, align 8
  %op4824 = sub i64 %v4823, 16
  store i64 %op4824, ptr %slot701, align 8
  %v4825 = load i64, ptr %slot688, align 8
  %p4826 = inttoptr i64 %v4825 to ptr
  %rgep4827 = getelementptr i8, ptr %p4826, i64 -16
  %ld4828 = load i64, ptr %rgep4827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4828, ptr %slot702, align 8
  %v4829 = load i64, ptr %slot702, align 8
  %op4830 = and i64 %v4829, 2
  store i64 %op4830, ptr %slot703, align 8
  %v4831 = load i64, ptr %slot703, align 8
  %cmp4832 = icmp ne i64 %v4831, 0
  %cv4833 = zext i1 %cmp4832 to i32
  store i32 %cv4833, ptr %slot704, align 8
  %v4834 = load i32, ptr %slot704, align 8
  %cv4835 = zext i32 %v4834 to i64
  %cond4836 = icmp ne i64 %cv4835, 0
  br i1 %cond4836, label %bb_rcspindone848, label %bb_rcspintype848
bb_rcspintype848:
  %v4837 = load i64, ptr %slot702, align 8
  %op4838 = and i64 %v4837, 4611686018427387907
  store i64 %op4838, ptr %slot705, align 8
  %v4839 = load i64, ptr %slot705, align 8
  %cmp4840 = icmp eq i64 %v4839, 0
  %cv4841 = zext i1 %cmp4840 to i32
  store i32 %cv4841, ptr %slot706, align 8
  %v4842 = load i32, ptr %slot706, align 8
  %cv4843 = zext i32 %v4842 to i64
  %cond4844 = icmp ne i64 %cv4843, 0
  br i1 %cond4844, label %bb_rcs856, label %bb_rcspinslow848
bb_rcs856:
  %v4845 = load i64, ptr %slot688, align 8
  %op4846 = sub i64 %v4845, 8
  store i64 %op4846, ptr %slot707, align 8
  %v4847 = load i64, ptr %slot688, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  %rgep4849 = getelementptr i8, ptr %p4848, i64 -8
  %ld4850 = load i64, ptr %rgep4849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4850, ptr %slot708, align 8
  %p4851 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld4852 = load i64, ptr %p4851, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4852, ptr %slot709, align 8
  %v4853 = load i64, ptr %slot708, align 8
  %v4854 = load i64, ptr %slot709, align 8
  %cmp4855 = icmp eq i64 %v4853, %v4854
  %cv4856 = zext i1 %cmp4855 to i32
  store i32 %cv4856, ptr %slot710, align 8
  %v4857 = load i32, ptr %slot710, align 8
  %cv4858 = zext i32 %v4857 to i64
  %cond4859 = icmp ne i64 %cv4858, 0
  br i1 %cond4859, label %bb_rcs861, label %bb_rcspinslow848
bb_rcs861:
  %v4860 = load i64, ptr %slot59, align 8
  %p4862 = inttoptr i64 %v4860 to ptr
  %gep4863 = getelementptr i8, ptr %p4862, i64 5640
  %op4861 = ptrtoint ptr %gep4863 to i64
  store i64 %op4861, ptr %slot711, align 8
  %v4864 = load i64, ptr %slot711, align 8
  %p4865 = inttoptr i64 %v4864 to ptr
  %ld4866 = load i64, ptr %p4865, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4866, ptr %slot712, align 8
  %v4867 = load i64, ptr %slot712, align 8
  %op4868 = add i64 %v4867, 256
  store i64 %op4868, ptr %slot713, align 8
  %v4869 = load i64, ptr %slot713, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i64, ptr %p4870, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4871, ptr %slot714, align 8
  %v4872 = load i64, ptr %slot714, align 8
  %cmp4873 = icmp ne i64 %v4872, 0
  %cv4874 = zext i1 %cmp4873 to i32
  store i32 %cv4874, ptr %slot715, align 8
  %v4875 = load i32, ptr %slot715, align 8
  %cv4876 = zext i32 %v4875 to i64
  %cond4877 = icmp ne i64 %cv4876, 0
  br i1 %cond4877, label %bb_rcs867, label %bb_rcspinslow848
bb_rcs867:
  %v4878 = load i64, ptr %slot59, align 8
  %p4880 = inttoptr i64 %v4878 to ptr
  %gep4881 = getelementptr i8, ptr %p4880, i64 24
  %op4879 = ptrtoint ptr %gep4881 to i64
  store i64 %op4879, ptr %slot716, align 8
  %v4882 = load i64, ptr %slot716, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  %ld4884 = load i64, ptr %p4883, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4884, ptr %slot717, align 8
  %v4885 = load i64, ptr %slot717, align 8
  %op4886 = add i64 %v4885, 40
  store i64 %op4886, ptr %slot718, align 8
  %v4887 = load i64, ptr %slot718, align 8
  %v4888 = load i64, ptr %slot717, align 8
  %cmp4889 = icmp uge i64 %v4887, %v4888
  %cv4890 = zext i1 %cmp4889 to i32
  store i32 %cv4890, ptr %slot719, align 8
  %v4891 = load i32, ptr %slot719, align 8
  %cv4892 = zext i32 %v4891 to i64
  %cond4893 = icmp ne i64 %cv4892, 0
  br i1 %cond4893, label %bb_rcs872, label %bb_rcspinslow848
bb_rcs872:
  %v4894 = load i64, ptr %slot59, align 8
  %p4896 = inttoptr i64 %v4894 to ptr
  %gep4897 = getelementptr i8, ptr %p4896, i64 88
  %op4895 = ptrtoint ptr %gep4897 to i64
  store i64 %op4895, ptr %slot720, align 8
  %v4898 = load i64, ptr %slot720, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %ld4900 = load i64, ptr %p4899, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4900, ptr %slot721, align 8
  %v4901 = load i64, ptr %slot721, align 8
  %cmp4902 = icmp eq i64 %v4901, 0
  %cv4903 = zext i1 %cmp4902 to i32
  store i32 %cv4903, ptr %slot722, align 8
  %v4904 = load i64, ptr %slot718, align 8
  %v4905 = load i64, ptr %slot721, align 8
  %cmp4906 = icmp ule i64 %v4904, %v4905
  %cv4907 = zext i1 %cmp4906 to i32
  store i32 %cv4907, ptr %slot723, align 8
  %v4908 = load i32, ptr %slot722, align 8
  %v4909 = load i32, ptr %slot723, align 8
  %op4910 = or i32 %v4908, %v4909
  store i32 %op4910, ptr %slot724, align 8
  %v4911 = load i32, ptr %slot724, align 8
  %cv4912 = zext i32 %v4911 to i64
  %cond4913 = icmp ne i64 %cv4912, 0
  br i1 %cond4913, label %bb_rcs878, label %bb_rcspinslow848
bb_rcs878:
  %v4914 = load i64, ptr %slot688, align 8
  %op4915 = sub i64 %v4914, 24
  store i64 %op4915, ptr %slot725, align 8
  %v4916 = load i64, ptr %slot688, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  %rgep4918 = getelementptr i8, ptr %p4917, i64 -24
  %ld4919 = load i64, ptr %rgep4918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4919, ptr %slot726, align 8
  %v4920 = load i64, ptr %slot726, align 8
  %cmp4921 = icmp ne i64 %v4920, 18446744073709551615
  %cv4922 = zext i1 %cmp4921 to i32
  store i32 %cv4922, ptr %slot727, align 8
  %v4923 = load i32, ptr %slot727, align 8
  %cv4924 = zext i32 %v4923 to i64
  %cond4925 = icmp ne i64 %cv4924, 0
  br i1 %cond4925, label %bb_rcs882, label %bb_rcspinslow848
bb_rcs882:
  %v4926 = load i64, ptr %slot688, align 8
  %op4927 = add i64 %v4926, 32
  store i64 %op4927, ptr %slot728, align 8
  %v4928 = load i64, ptr %slot728, align 8
  %p4929 = inttoptr i64 %v4928 to ptr
  %ld4930 = load i64, ptr %p4929, align 8
  store i64 %ld4930, ptr %slot729, align 8
  %v4931 = load i64, ptr %slot729, align 8
  %cmp4932 = icmp ne i64 %v4931, 0
  %cv4933 = zext i1 %cmp4932 to i32
  store i32 %cv4933, ptr %slot730, align 8
  %v4934 = load i32, ptr %slot730, align 8
  %cv4935 = zext i32 %v4934 to i64
  %cond4936 = icmp ne i64 %cv4935, 0
  br i1 %cond4936, label %bb_rcspinbacking848, label %bb_rcspincommit848
bb_rcspinbacking848:
  %v4937 = load i64, ptr %slot729, align 8
  %op4938 = sub i64 %v4937, 16
  store i64 %op4938, ptr %slot731, align 8
  %v4939 = load i64, ptr %slot729, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %rgep4941 = getelementptr i8, ptr %p4940, i64 -16
  %ld4942 = load i64, ptr %rgep4941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4942, ptr %slot732, align 8
  %v4943 = load i64, ptr %slot732, align 8
  %op4944 = and i64 %v4943, 4611686018427387907
  store i64 %op4944, ptr %slot733, align 8
  %v4945 = load i64, ptr %slot733, align 8
  %cmp4946 = icmp eq i64 %v4945, 0
  %cv4947 = zext i1 %cmp4946 to i32
  store i32 %cv4947, ptr %slot734, align 8
  %v4948 = load i32, ptr %slot734, align 8
  %cv4949 = zext i32 %v4948 to i64
  %cond4950 = icmp ne i64 %cv4949, 0
  br i1 %cond4950, label %bb_rcs890, label %bb_rcspinslow848
bb_rcs890:
  %v4951 = load i64, ptr %slot729, align 8
  %op4952 = sub i64 %v4951, 24
  store i64 %op4952, ptr %slot735, align 8
  %v4953 = load i64, ptr %slot729, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  %rgep4955 = getelementptr i8, ptr %p4954, i64 -24
  %ld4956 = load i64, ptr %rgep4955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4956, ptr %slot736, align 8
  %v4957 = load i64, ptr %slot736, align 8
  %cmp4958 = icmp ne i64 %v4957, 18446744073709551615
  %cv4959 = zext i1 %cmp4958 to i32
  store i32 %cv4959, ptr %slot737, align 8
  %v4960 = load i32, ptr %slot737, align 8
  %cv4961 = zext i32 %v4960 to i64
  %cond4962 = icmp ne i64 %cv4961, 0
  br i1 %cond4962, label %bb_rcs894, label %bb_rcspinslow848
bb_rcs894:
  br label %bb_rcspincommit848
bb_rcspincommit848:
  %v4963 = load i64, ptr %slot714, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  %ld4965 = load i64, ptr %p4964, align 8
  store i64 %ld4965, ptr %slot738, align 8
  %v4966 = load i64, ptr %slot712, align 8
  %op4967 = add i64 %v4966, 256
  store i64 %op4967, ptr %slot739, align 8
  %v4968 = load i64, ptr %slot738, align 8
  %v4969 = load i64, ptr %slot739, align 8
  %p4970 = inttoptr i64 %v4969 to ptr
  store i64 %v4968, ptr %p4970, align 8, !alias.scope !9999998, !noalias !9999999
  %v4971 = load i64, ptr %slot712, align 8
  %op4972 = add i64 %v4971, 264
  store i64 %op4972, ptr %slot740, align 8
  %v4973 = load i64, ptr %slot740, align 8
  %p4974 = inttoptr i64 %v4973 to ptr
  %ld4975 = load i64, ptr %p4974, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4975, ptr %slot741, align 8
  %v4976 = load i64, ptr %slot741, align 8
  %op4977 = add i64 %v4976, 18446744073709551615
  store i64 %op4977, ptr %slot742, align 8
  %v4978 = load i64, ptr %slot742, align 8
  %v4979 = load i64, ptr %slot740, align 8
  %p4980 = inttoptr i64 %v4979 to ptr
  store i64 %v4978, ptr %p4980, align 8, !alias.scope !9999998, !noalias !9999999
  %v4981 = load i64, ptr %slot59, align 8
  %p4983 = inttoptr i64 %v4981 to ptr
  %gep4984 = getelementptr i8, ptr %p4983, i64 24
  %op4982 = ptrtoint ptr %gep4984 to i64
  store i64 %op4982, ptr %slot743, align 8
  %v4985 = load i64, ptr %slot743, align 8
  %p4986 = inttoptr i64 %v4985 to ptr
  %ld4987 = load i64, ptr %p4986, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4987, ptr %slot744, align 8
  %v4988 = load i64, ptr %slot744, align 8
  %op4989 = add i64 %v4988, 40
  store i64 %op4989, ptr %slot745, align 8
  %v4990 = load i64, ptr %slot745, align 8
  %v4991 = load i64, ptr %slot743, align 8
  %p4992 = inttoptr i64 %v4991 to ptr
  store i64 %v4990, ptr %p4992, align 8, !alias.scope !9999998, !noalias !9999999
  %v4993 = load i64, ptr %slot712, align 8
  %op4994 = add i64 %v4993, 48
  store i64 %op4994, ptr %slot746, align 8
  %v4995 = load i64, ptr %slot746, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %ld4997 = load i64, ptr %p4996, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4997, ptr %slot747, align 8
  %v4998 = load i64, ptr %slot747, align 8
  %op4999 = add i64 %v4998, 40
  store i64 %op4999, ptr %slot748, align 8
  %v5000 = load i64, ptr %slot748, align 8
  %v5001 = load i64, ptr %slot746, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  store i64 %v5000, ptr %p5002, align 8, !alias.scope !9999998, !noalias !9999999
  %v5003 = load i64, ptr %slot688, align 8
  %op5004 = sub i64 %v5003, 24
  store i64 %op5004, ptr %slot749, align 8
  %v5005 = load i64, ptr %slot688, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  %rgep5007 = getelementptr i8, ptr %p5006, i64 -24
  %ld5008 = load i64, ptr %rgep5007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5008, ptr %slot750, align 8
  %v5009 = load i64, ptr %slot750, align 8
  %op5010 = add i64 %v5009, 1
  store i64 %op5010, ptr %slot751, align 8
  %v5011 = load i64, ptr %slot751, align 8
  %v5012 = load i64, ptr %slot688, align 8
  %p5013 = inttoptr i64 %v5012 to ptr
  %rgep5014 = getelementptr i8, ptr %p5013, i64 -24
  store i64 %v5011, ptr %rgep5014, align 8, !alias.scope !9, !noalias !10
  %v5015 = load i64, ptr %slot729, align 8
  %cmp5016 = icmp ne i64 %v5015, 0
  %cv5017 = zext i1 %cmp5016 to i32
  store i32 %cv5017, ptr %slot752, align 8
  %v5018 = load i32, ptr %slot752, align 8
  %cv5019 = zext i32 %v5018 to i64
  %cond5020 = icmp ne i64 %cv5019, 0
  br i1 %cond5020, label %bb_rcspinhold848, label %bb_rcspinjournal848
bb_rcspinhold848:
  %v5021 = load i64, ptr %slot729, align 8
  %op5022 = sub i64 %v5021, 24
  store i64 %op5022, ptr %slot753, align 8
  %v5023 = load i64, ptr %slot729, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %rgep5025 = getelementptr i8, ptr %p5024, i64 -24
  %ld5026 = load i64, ptr %rgep5025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5026, ptr %slot754, align 8
  %v5027 = load i64, ptr %slot754, align 8
  %op5028 = add i64 %v5027, 1
  store i64 %op5028, ptr %slot755, align 8
  %v5029 = load i64, ptr %slot755, align 8
  %v5030 = load i64, ptr %slot729, align 8
  %p5031 = inttoptr i64 %v5030 to ptr
  %rgep5032 = getelementptr i8, ptr %p5031, i64 -24
  store i64 %v5029, ptr %rgep5032, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal848
bb_rcspinjournal848:
  %v5033 = load i64, ptr %slot702, align 8
  %op5034 = and i64 %v5033, 1152921504606846976
  store i64 %op5034, ptr %slot756, align 8
  %v5035 = load i64, ptr %slot702, align 8
  %op5036 = or i64 %v5035, 1152921504606846976
  store i64 %op5036, ptr %slot757, align 8
  %v5037 = load i64, ptr %slot688, align 8
  %op5038 = sub i64 %v5037, 16
  store i64 %op5038, ptr %slot758, align 8
  %v5039 = load i64, ptr %slot757, align 8
  %v5040 = load i64, ptr %slot688, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  %rgep5042 = getelementptr i8, ptr %p5041, i64 -16
  store i64 %v5039, ptr %rgep5042, align 8, !alias.scope !9, !noalias !10
  %v5043 = load i64, ptr %slot689, align 8
  %p5045 = inttoptr i64 %v5043 to ptr
  %gep5046 = getelementptr i8, ptr %p5045, i64 16
  %op5044 = ptrtoint ptr %gep5046 to i64
  store i64 %op5044, ptr %slot759, align 8
  %v5047 = load i64, ptr %slot759, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %ld5049 = load i64, ptr %p5048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5049, ptr %slot760, align 8
  %v5050 = load i64, ptr %slot714, align 8
  %op5051 = add i64 %v5050, 0
  store i64 %op5051, ptr %slot761, align 8
  %v5052 = load i64, ptr %slot760, align 8
  %v5053 = load i64, ptr %slot761, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  store i64 %v5052, ptr %p5054, align 8, !alias.scope !9999998, !noalias !9999999
  %v5055 = load i64, ptr %slot714, align 8
  %op5056 = add i64 %v5055, 8
  store i64 %op5056, ptr %slot762, align 8
  %v5057 = load i64, ptr %slot688, align 8
  %v5058 = load i64, ptr %slot762, align 8
  %p5059 = inttoptr i64 %v5058 to ptr
  store i64 %v5057, ptr %p5059, align 8, !alias.scope !9999998, !noalias !9999999
  %v5060 = load i64, ptr %slot714, align 8
  %op5061 = add i64 %v5060, 16
  store i64 %op5061, ptr %slot763, align 8
  %v5062 = load i64, ptr %slot756, align 8
  %v5063 = load i64, ptr %slot763, align 8
  %p5064 = inttoptr i64 %v5063 to ptr
  store i64 %v5062, ptr %p5064, align 8, !alias.scope !9999998, !noalias !9999999
  %v5065 = load i64, ptr %slot714, align 8
  %op5066 = add i64 %v5065, 24
  store i64 %op5066, ptr %slot764, align 8
  %v5067 = load i64, ptr %slot764, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  store i32 1, ptr %p5068, align 4, !alias.scope !9999998, !noalias !9999999
  %v5069 = load i64, ptr %slot714, align 8
  %op5070 = add i64 %v5069, 32
  store i64 %op5070, ptr %slot765, align 8
  %v5071 = load i64, ptr %slot729, align 8
  %v5072 = load i64, ptr %slot765, align 8
  %p5073 = inttoptr i64 %v5072 to ptr
  store i64 %v5071, ptr %p5073, align 8, !alias.scope !9999998, !noalias !9999999
  %v5074 = load i64, ptr %slot689, align 8
  %p5076 = inttoptr i64 %v5074 to ptr
  %gep5077 = getelementptr i8, ptr %p5076, i64 16
  %op5075 = ptrtoint ptr %gep5077 to i64
  store i64 %op5075, ptr %slot766, align 8
  %v5078 = load i64, ptr %slot714, align 8
  %v5079 = load i64, ptr %slot766, align 8
  %p5080 = inttoptr i64 %v5079 to ptr
  store i64 %v5078, ptr %p5080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone848
bb_rcspinslow848:
  %v5081 = load i64, ptr %slot1, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  %v5083 = load i64, ptr %slot689, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  %v5085 = load i64, ptr %slot688, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %call5087 = call i32 @myl_qbe_rc_scope_pin(ptr %p5082, ptr %p5084, ptr %p5086) nomerge, !dbg !140
  store i32 %call5087, ptr %slot767, align 8
  %v5088 = load i32, ptr %slot767, align 8
  %cv5089 = zext i32 %v5088 to i64
  %cond5090 = icmp ne i64 %cv5089, 0
  br i1 %cond5090, label %bb_rcunique925, label %bb_failure
bb_rcunique925:
  br label %bb_rcspindone848
bb_rcspindone848:
  %v5091 = load i64, ptr %slot688, align 8
  %v5092 = load i64, ptr %slot44, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  store i64 %v5091, ptr %p5093, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined691
bb_rcholdjoined691:
  %v5094 = load i64, ptr %slot37, align 8
  %p5095 = inttoptr i64 %v5094 to ptr
  %ld5096 = load i64, ptr %p5095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5096, ptr %slot768, align 8
  %v5097 = load i64, ptr %slot8, align 8
  %p5098 = inttoptr i64 %v5097 to ptr
  %ld5099 = load i32, ptr %p5098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5099, ptr %slot769, align 8
  %v5100 = load i32, ptr %slot769, align 8
  %cmp5101 = icmp eq i32 %v5100, 8
  %cv5102 = zext i1 %cmp5101 to i32
  store i32 %cv5102, ptr %slot770, align 8
  %v5103 = load i64, ptr %slot7, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %ld5105 = load i32, ptr %p5104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5105, ptr %slot771, align 8
  %v5106 = load i32, ptr %slot770, align 8
  %v5107 = load i32, ptr %slot771, align 8
  %op5108 = and i32 %v5106, %v5107
  store i32 %op5108, ptr %slot772, align 8
  %v5109 = load i32, ptr %slot772, align 8
  %cv5110 = zext i32 %v5109 to i64
  %cond5111 = icmp ne i64 %cv5110, 0
  br i1 %cond5111, label %bb_rchold927, label %bb_rcordinary927
bb_rchold927:
  %v5112 = load i64, ptr %slot28, align 8
  store i64 %v5112, ptr %slot773, align 8
  %v5113 = load i64, ptr %slot768, align 8
  %cmp5114 = icmp ne i64 %v5113, 0
  %cv5115 = zext i1 %cmp5114 to i32
  store i32 %cv5115, ptr %slot774, align 8
  %v5116 = load i32, ptr %slot774, align 8
  %cv5117 = zext i32 %v5116 to i64
  %cond5118 = icmp ne i64 %cv5117, 0
  br i1 %cond5118, label %bb_rcgnn937, label %bb_rcgstore937
bb_rcgnn937:
  %v5119 = load i64, ptr %slot768, align 8
  %op5120 = sub i64 %v5119, 16
  store i64 %op5120, ptr %slot775, align 8
  %v5121 = load i64, ptr %slot768, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  %rgep5123 = getelementptr i8, ptr %p5122, i64 -16
  %ld5124 = load i64, ptr %rgep5123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5124, ptr %slot776, align 8
  %v5125 = load i64, ptr %slot776, align 8
  %op5126 = and i64 %v5125, 4611686018427387906
  store i64 %op5126, ptr %slot777, align 8
  %v5127 = load i64, ptr %slot777, align 8
  %cmp5128 = icmp ne i64 %v5127, 0
  %cv5129 = zext i1 %cmp5128 to i32
  store i32 %cv5129, ptr %slot778, align 8
  %v5130 = load i32, ptr %slot778, align 8
  %cv5131 = zext i32 %v5130 to i64
  %cond5132 = icmp ne i64 %cv5131, 0
  br i1 %cond5132, label %bb_rcgstore937, label %bb_rcginc937
bb_rcginc937:
  %v5133 = load i64, ptr %slot768, align 8
  %op5134 = sub i64 %v5133, 24
  store i64 %op5134, ptr %slot779, align 8
  %v5135 = load i64, ptr %slot768, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  %rgep5137 = getelementptr i8, ptr %p5136, i64 -24
  %ld5138 = load i64, ptr %rgep5137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5138, ptr %slot780, align 8
  %v5139 = load i64, ptr %slot780, align 8
  %op5140 = add i64 %v5139, 1
  store i64 %op5140, ptr %slot781, align 8
  %v5141 = load i64, ptr %slot781, align 8
  %cmp5142 = icmp eq i64 %v5141, 0
  %cv5143 = zext i1 %cmp5142 to i32
  store i32 %cv5143, ptr %slot782, align 8
  %v5144 = load i32, ptr %slot782, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcglimit937, label %bb_rcgcapacity937
bb_rcglimit937:
  %v5147 = load i64, ptr %slot1, align 8
  %p5148 = inttoptr i64 %v5147 to ptr
  %call5149 = call i32 @myl_qbe_rc_status(ptr %p5148, i32 2) nomerge, !dbg !142
  store i32 %call5149, ptr %slot783, align 8
  br label %bb_failure
bb_rcgcapacity937:
  %v5150 = load i64, ptr %slot781, align 8
  %v5151 = load i64, ptr %slot768, align 8
  %p5152 = inttoptr i64 %v5151 to ptr
  %rgep5153 = getelementptr i8, ptr %p5152, i64 -24
  store i64 %v5150, ptr %rgep5153, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore937
bb_rcgstore937:
  %v5154 = load i64, ptr %slot768, align 8
  %v5155 = load i64, ptr %slot773, align 8
  %p5156 = inttoptr i64 %v5155 to ptr
  store i64 %v5154, ptr %p5156, align 8, !alias.scope !3, !noalias !4
  %v5157 = load i64, ptr %slot22, align 8
  %p5158 = inttoptr i64 %v5157 to ptr
  store i32 2, ptr %p5158, align 4, !alias.scope !3, !noalias !4
  %v5159 = load i64, ptr %slot22, align 8
  %p5160 = inttoptr i64 %v5159 to ptr
  store i32 8, ptr %p5160, align 4, !alias.scope !3, !noalias !4
  %v5161 = load i64, ptr %slot21, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  store i32 1, ptr %p5162, align 4, !alias.scope !3, !noalias !4
  %v5163 = load i64, ptr %slot24, align 8
  store i64 %v5163, ptr %slot784, align 8
  %v5164 = load i64, ptr %slot28, align 8
  store i64 %v5164, ptr %slot785, align 8
  %v5165 = load i64, ptr %slot785, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  %ld5167 = load i64, ptr %p5166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5167, ptr %slot786, align 8
  %v5168 = load i64, ptr %slot786, align 8
  %v5169 = load i64, ptr %slot784, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  store i64 %v5168, ptr %p5170, align 8, !alias.scope !3, !noalias !4
  %v5171 = load i64, ptr %slot18, align 8
  %p5172 = inttoptr i64 %v5171 to ptr
  store i32 2, ptr %p5172, align 4, !alias.scope !3, !noalias !4
  %v5173 = load i64, ptr %slot18, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  store i32 8, ptr %p5174, align 4, !alias.scope !3, !noalias !4
  %v5175 = load i64, ptr %slot17, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  store i32 1, ptr %p5176, align 4, !alias.scope !3, !noalias !4
  %v5177 = load i64, ptr %slot21, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  store i32 0, ptr %p5178, align 4, !alias.scope !3, !noalias !4
  %v5179 = load i64, ptr %slot786, align 8
  %v5180 = load i64, ptr %slot50, align 8
  %p5181 = inttoptr i64 %v5180 to ptr
  store i64 %v5179, ptr %p5181, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined927
bb_rcordinary927:
  %v5182 = load i64, ptr %slot768, align 8
  %v5183 = load i64, ptr %slot50, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  store i64 %v5182, ptr %p5184, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined927
bb_rcholdjoined927:
  %v5185 = load i64, ptr %slot43, align 8
  %v5186 = load i64, ptr %slot51, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  store i64 %v5185, ptr %p5187, align 8, !alias.scope !3, !noalias !4
  %v5188 = load i64, ptr %slot51, align 8
  %p5189 = inttoptr i64 %v5188 to ptr
  %ld5190 = load i64, ptr %p5189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5190, ptr %slot787, align 8
  %v5191 = load i64, ptr %slot787, align 8
  %op5192 = add i64 %v5191, 0
  store i64 %op5192, ptr %slot788, align 8
  %v5193 = load i64, ptr %slot788, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %ld5195 = load i64, ptr %p5194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5195, ptr %slot789, align 8
  %v5196 = load i64, ptr %slot789, align 8
  %v5197 = load i64, ptr %slot51, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  store i64 %v5196, ptr %p5198, align 8, !alias.scope !3, !noalias !4
  %v5199 = load i64, ptr %slot43, align 8
  %v5200 = load i64, ptr %slot52, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  store i64 %v5199, ptr %p5201, align 8, !alias.scope !3, !noalias !4
  %v5202 = load i64, ptr %slot52, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  %ld5204 = load i64, ptr %p5203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5204, ptr %slot790, align 8
  %v5205 = load i64, ptr %slot790, align 8
  %op5206 = add i64 %v5205, 8
  store i64 %op5206, ptr %slot791, align 8
  %v5207 = load i64, ptr %slot791, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  %ld5209 = load i32, ptr %p5208, align 4, !alias.scope !3, !noalias !4
  %ext5210 = zext i32 %ld5209 to i64
  store i64 %ext5210, ptr %slot792, align 8
  %v5211 = load i64, ptr %slot792, align 8
  %v5212 = load i64, ptr %slot52, align 8
  %p5213 = inttoptr i64 %v5212 to ptr
  store i64 %v5211, ptr %p5213, align 8, !alias.scope !3, !noalias !4
  %v5214 = load i64, ptr %slot50, align 8
  %p5215 = inttoptr i64 %v5214 to ptr
  %ld5216 = load i64, ptr %p5215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5216, ptr %slot793, align 8
  %v5217 = load i64, ptr %slot51, align 8
  %p5218 = inttoptr i64 %v5217 to ptr
  %ld5219 = load i64, ptr %p5218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5219, ptr %slot794, align 8
  %v5220 = load i64, ptr %slot52, align 8
  %p5221 = inttoptr i64 %v5220 to ptr
  %ld5222 = load i64, ptr %p5221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5222, ptr %slot795, align 8
  %v5223 = load i64, ptr %slot1, align 8
  %v5224 = load i64, ptr %slot793, align 8
  %v5225 = load i64, ptr %slot794, align 8
  %v5226 = load i64, ptr %slot795, align 8
  %call5227 = call i64 @myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d(i64 %v5223, i64 %v5224, i64 %v5225, i64 %v5226) nomerge, !dbg !144
  store i64 %call5227, ptr %slot796, align 8
  %v5228 = load i64, ptr %slot796, align 8
  %v5229 = load i64, ptr %slot50, align 8
  %p5230 = inttoptr i64 %v5229 to ptr
  store i64 %v5228, ptr %p5230, align 8, !alias.scope !3, !noalias !4
  %v5231 = load i64, ptr %slot17, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  %ld5233 = load i32, ptr %p5232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5233, ptr %slot797, align 8
  %v5234 = load i32, ptr %slot797, align 8
  %cv5235 = zext i32 %v5234 to i64
  %cond5236 = icmp ne i64 %cv5235, 0
  br i1 %cond5236, label %bb_rcslotdrop970, label %bb_rcslotdone970
bb_rcslotdrop970:
  %v5237 = load i64, ptr %slot17, align 8
  %p5238 = inttoptr i64 %v5237 to ptr
  store i32 0, ptr %p5238, align 4, !alias.scope !3, !noalias !4
  %v5239 = load i64, ptr %slot24, align 8
  store i64 %v5239, ptr %slot798, align 8
  %v5240 = load i64, ptr %slot18, align 8
  %p5241 = inttoptr i64 %v5240 to ptr
  %ld5242 = load i32, ptr %p5241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5242, ptr %slot799, align 8
  %v5243 = load i32, ptr %slot799, align 8
  %op5244 = and i32 %v5243, 28
  store i32 %op5244, ptr %slot800, align 8
  %v5245 = load i32, ptr %slot800, align 8
  %cv5246 = zext i32 %v5245 to i64
  %cond5247 = icmp ne i64 %cv5246, 0
  br i1 %cond5247, label %bb_rcslotrole970, label %bb_rcslotowner970
bb_rcslotrole970:
  %v5248 = load i64, ptr %slot59, align 8
  store i64 %v5248, ptr %slot801, align 8
  %v5249 = load i64, ptr %slot798, align 8
  %p5250 = inttoptr i64 %v5249 to ptr
  %ld5251 = load i64, ptr %p5250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5251, ptr %slot802, align 8
  %v5252 = load i64, ptr %slot802, align 8
  %cmp5253 = icmp ne i64 %v5252, 0
  %cv5254 = zext i1 %cmp5253 to i32
  store i32 %cv5254, ptr %slot803, align 8
  %v5255 = load i32, ptr %slot803, align 8
  %cv5256 = zext i32 %v5255 to i64
  %cond5257 = icmp ne i64 %cv5256, 0
  br i1 %cond5257, label %bb_rcgnn986, label %bb_rcgdone986
bb_rcgnn986:
  %v5258 = load i64, ptr %slot802, align 8
  %op5259 = sub i64 %v5258, 16
  store i64 %op5259, ptr %slot804, align 8
  %v5260 = load i64, ptr %slot802, align 8
  %p5261 = inttoptr i64 %v5260 to ptr
  %rgep5262 = getelementptr i8, ptr %p5261, i64 -16
  %ld5263 = load i64, ptr %rgep5262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5263, ptr %slot805, align 8
  %v5264 = load i64, ptr %slot805, align 8
  %op5265 = and i64 %v5264, 4611686018427387906
  store i64 %op5265, ptr %slot806, align 8
  %v5266 = load i64, ptr %slot806, align 8
  %cmp5267 = icmp ne i64 %v5266, 0
  %cv5268 = zext i1 %cmp5267 to i32
  store i32 %cv5268, ptr %slot807, align 8
  %v5269 = load i32, ptr %slot807, align 8
  %cv5270 = zext i32 %v5269 to i64
  %cond5271 = icmp ne i64 %cv5270, 0
  br i1 %cond5271, label %bb_rcgclear986, label %bb_rcgcounted986
bb_rcgcounted986:
  %v5272 = load i64, ptr %slot802, align 8
  %op5273 = sub i64 %v5272, 24
  store i64 %op5273, ptr %slot808, align 8
  %v5274 = load i64, ptr %slot802, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  %rgep5276 = getelementptr i8, ptr %p5275, i64 -24
  %ld5277 = load i64, ptr %rgep5276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5277, ptr %slot809, align 8
  %v5278 = load i64, ptr %slot809, align 8
  %op5279 = sub i64 %v5278, 1
  store i64 %op5279, ptr %slot810, align 8
  %v5280 = load i64, ptr %slot810, align 8
  %cmp5281 = icmp eq i64 %v5280, 0
  %cv5282 = zext i1 %cmp5281 to i32
  store i32 %cv5282, ptr %slot811, align 8
  %v5283 = load i32, ptr %slot811, align 8
  %cv5284 = zext i32 %v5283 to i64
  %cond5285 = icmp ne i64 %cv5284, 0
  br i1 %cond5285, label %bb_rcglast986, label %bb_rcgdec986
bb_rcglast986:
  %v5286 = load i64, ptr %slot802, align 8
  %op5287 = sub i64 %v5286, 32
  store i64 %op5287, ptr %slot812, align 8
  %v5288 = load i64, ptr %slot802, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  %rgep5290 = getelementptr i8, ptr %p5289, i64 -32
  %ld5291 = load i64, ptr %rgep5290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5291, ptr %slot813, align 8
  %v5292 = load i64, ptr %slot813, align 8
  %cmp5293 = icmp ne i64 %v5292, 0
  %cv5294 = zext i1 %cmp5293 to i32
  store i32 %cv5294, ptr %slot814, align 8
  %v5295 = load i32, ptr %slot814, align 8
  %cv5296 = zext i32 %v5295 to i64
  %cond5297 = icmp ne i64 %cv5296, 0
  br i1 %cond5297, label %bb_rcgdec986, label %bb_rcgslow986
bb_rcgslow986:
  %v5298 = load i64, ptr %slot801, align 8
  %v5299 = load i64, ptr %slot798, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v5298, i64 %v5299) nomerge, !dbg !144
  br label %bb_rcgdone986
bb_rcgdec986:
  %v5300 = load i64, ptr %slot810, align 8
  %v5301 = load i64, ptr %slot802, align 8
  %p5302 = inttoptr i64 %v5301 to ptr
  %rgep5303 = getelementptr i8, ptr %p5302, i64 -24
  store i64 %v5300, ptr %rgep5303, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear986
bb_rcgclear986:
  %v5304 = load i64, ptr %slot798, align 8
  %p5305 = inttoptr i64 %v5304 to ptr
  store i64 0, ptr %p5305, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone986
bb_rcgdone986:
  br label %bb_rcslotdone970
bb_rcslotowner970:
  %v5306 = load i64, ptr %slot59, align 8
  store i64 %v5306, ptr %slot815, align 8
  %v5307 = load i64, ptr %slot798, align 8
  %p5308 = inttoptr i64 %v5307 to ptr
  %ld5309 = load i64, ptr %p5308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5309, ptr %slot816, align 8
  %v5310 = load i64, ptr %slot816, align 8
  %cmp5311 = icmp ne i64 %v5310, 0
  %cv5312 = zext i1 %cmp5311 to i32
  store i32 %cv5312, ptr %slot817, align 8
  %v5313 = load i32, ptr %slot817, align 8
  %cv5314 = zext i32 %v5313 to i64
  %cond5315 = icmp ne i64 %cv5314, 0
  br i1 %cond5315, label %bb_rcgnn1001, label %bb_rcgdone1001
bb_rcgnn1001:
  %v5316 = load i64, ptr %slot816, align 8
  %op5317 = sub i64 %v5316, 16
  store i64 %op5317, ptr %slot818, align 8
  %v5318 = load i64, ptr %slot816, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  %rgep5320 = getelementptr i8, ptr %p5319, i64 -16
  %ld5321 = load i64, ptr %rgep5320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5321, ptr %slot819, align 8
  %v5322 = load i64, ptr %slot819, align 8
  %op5323 = and i64 %v5322, 4611686018427387906
  store i64 %op5323, ptr %slot820, align 8
  %v5324 = load i64, ptr %slot820, align 8
  %cmp5325 = icmp ne i64 %v5324, 0
  %cv5326 = zext i1 %cmp5325 to i32
  store i32 %cv5326, ptr %slot821, align 8
  %v5327 = load i32, ptr %slot821, align 8
  %cv5328 = zext i32 %v5327 to i64
  %cond5329 = icmp ne i64 %cv5328, 0
  br i1 %cond5329, label %bb_rcgclear1001, label %bb_rcgcounted1001
bb_rcgcounted1001:
  %v5330 = load i64, ptr %slot816, align 8
  %op5331 = sub i64 %v5330, 32
  store i64 %op5331, ptr %slot822, align 8
  %v5332 = load i64, ptr %slot816, align 8
  %p5333 = inttoptr i64 %v5332 to ptr
  %rgep5334 = getelementptr i8, ptr %p5333, i64 -32
  %ld5335 = load i64, ptr %rgep5334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5335, ptr %slot823, align 8
  %v5336 = load i64, ptr %slot823, align 8
  %op5337 = sub i64 %v5336, 1
  store i64 %op5337, ptr %slot824, align 8
  %v5338 = load i64, ptr %slot824, align 8
  %cmp5339 = icmp eq i64 %v5338, 0
  %cv5340 = zext i1 %cmp5339 to i32
  store i32 %cv5340, ptr %slot825, align 8
  %v5341 = load i32, ptr %slot825, align 8
  %cv5342 = zext i32 %v5341 to i64
  %cond5343 = icmp ne i64 %cv5342, 0
  br i1 %cond5343, label %bb_rcglast1001, label %bb_rcgdec1001
bb_rcglast1001:
  %v5344 = load i64, ptr %slot816, align 8
  %op5345 = sub i64 %v5344, 24
  store i64 %op5345, ptr %slot826, align 8
  %v5346 = load i64, ptr %slot816, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  %rgep5348 = getelementptr i8, ptr %p5347, i64 -24
  %ld5349 = load i64, ptr %rgep5348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5349, ptr %slot827, align 8
  %v5350 = load i64, ptr %slot827, align 8
  %cmp5351 = icmp ne i64 %v5350, 0
  %cv5352 = zext i1 %cmp5351 to i32
  store i32 %cv5352, ptr %slot828, align 8
  %v5353 = load i32, ptr %slot828, align 8
  %cv5354 = zext i32 %v5353 to i64
  %cond5355 = icmp ne i64 %cv5354, 0
  br i1 %cond5355, label %bb_rcgdec1001, label %bb_rcgslow1001
bb_rcgslow1001:
  %v5356 = load i64, ptr %slot815, align 8
  %v5357 = load i64, ptr %slot798, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5356, i64 %v5357) nomerge, !dbg !144
  br label %bb_rcgdone1001
bb_rcgdec1001:
  %v5358 = load i64, ptr %slot824, align 8
  %v5359 = load i64, ptr %slot816, align 8
  %p5360 = inttoptr i64 %v5359 to ptr
  %rgep5361 = getelementptr i8, ptr %p5360, i64 -32
  store i64 %v5358, ptr %rgep5361, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1001
bb_rcgclear1001:
  %v5362 = load i64, ptr %slot798, align 8
  %p5363 = inttoptr i64 %v5362 to ptr
  store i64 0, ptr %p5363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1001
bb_rcgdone1001:
  br label %bb_rcslotdone970
bb_rcslotdone970:
  %v5364 = load i64, ptr %slot50, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %ld5366 = load i64, ptr %p5365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5366, ptr %slot829, align 8
  %v5367 = load i64, ptr %slot829, align 8
  %v5368 = load i64, ptr %slot46, align 8
  %p5369 = inttoptr i64 %v5368 to ptr
  store i64 %v5367, ptr %p5369, align 8, !alias.scope !3, !noalias !4
  %v5370 = load i64, ptr %slot46, align 8
  %p5371 = inttoptr i64 %v5370 to ptr
  %ld5372 = load i64, ptr %p5371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5372, ptr %slot830, align 8
  %v5373 = load i64, ptr %slot830, align 8
  %v5374 = load i64, ptr %slot50, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  store i64 %v5373, ptr %p5375, align 8, !alias.scope !3, !noalias !4
  %v5376 = load i64, ptr %slot51, align 8
  %p5377 = inttoptr i64 %v5376 to ptr
  store i64 0, ptr %p5377, align 8, !alias.scope !3, !noalias !4
  %v5378 = load i64, ptr %slot51, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  %ld5380 = load i64, ptr %p5379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5380, ptr %slot831, align 8
  %v5381 = load i64, ptr %slot50, align 8
  %p5382 = inttoptr i64 %v5381 to ptr
  %ld5383 = load i64, ptr %p5382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5383, ptr %slot832, align 8
  %v5384 = load i64, ptr %slot832, align 8
  %v5385 = load i64, ptr %slot831, align 8
  %cmp5386 = icmp slt i64 %v5384, %v5385
  %cv5387 = zext i1 %cmp5386 to i64
  store i64 %cv5387, ptr %slot833, align 8
  %v5388 = load i64, ptr %slot833, align 8
  %v5389 = load i64, ptr %slot50, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  store i64 %v5388, ptr %p5390, align 8, !alias.scope !3, !noalias !4
  %v5391 = load i64, ptr %slot50, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  %ld5393 = load i64, ptr %p5392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5393, ptr %slot834, align 8
  %v5394 = load i64, ptr %slot834, align 8
  %cond5395 = icmp ne i64 %v5394, 0
  br i1 %cond5395, label %bb_next1011, label %bb_i75
bb_next1011:
  %v5396 = load i64, ptr %slot44, align 8
  %p5397 = inttoptr i64 %v5396 to ptr
  %ld5398 = load i64, ptr %p5397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5398, ptr %slot835, align 8
  %v5399 = load i64, ptr %slot835, align 8
  %op5400 = add i64 %v5399, 0
  store i64 %op5400, ptr %slot836, align 8
  %v5401 = load i64, ptr %slot836, align 8
  %p5402 = inttoptr i64 %v5401 to ptr
  %ld5403 = load i64, ptr %p5402, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5403, ptr %slot837, align 8
  %v5404 = load i64, ptr %slot837, align 8
  %v5405 = load i64, ptr %slot50, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  store i64 %v5404, ptr %p5406, align 8, !alias.scope !3, !noalias !4
  %v5407 = load i64, ptr %slot50, align 8
  %p5408 = inttoptr i64 %v5407 to ptr
  %ld5409 = load i64, ptr %p5408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5409, ptr %slot838, align 8
  %v5410 = load i64, ptr %slot838, align 8
  %cmp5411 = icmp ugt i64 %v5410, 9223372036854775807
  %cv5412 = zext i1 %cmp5411 to i64
  store i64 %cv5412, ptr %slot839, align 8
  %v5413 = load i64, ptr %slot839, align 8
  %cond5414 = icmp ne i64 %v5413, 0
  br i1 %cond5414, label %bb_cast_overflow1016, label %bb_cast_ok1016
bb_cast_overflow1016:
  %v5415 = load i64, ptr %slot1, align 8
  %p5416 = inttoptr i64 %v5415 to ptr
  %v5417 = load i64, ptr %slot838, align 8
  call void @myl_qbe_fail_cast(ptr %p5416, i64 %v5417, i64 320) nomerge, !dbg !146
  unreachable
bb_cast_ok1016:
  %v5418 = load i64, ptr %slot838, align 8
  %v5419 = load i64, ptr %slot50, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  store i64 %v5418, ptr %p5420, align 8, !alias.scope !3, !noalias !4
  %v5421 = load i64, ptr %slot46, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %ld5423 = load i64, ptr %p5422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5423, ptr %slot840, align 8
  %v5424 = load i64, ptr %slot840, align 8
  %v5425 = load i64, ptr %slot51, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  store i64 %v5424, ptr %p5426, align 8, !alias.scope !3, !noalias !4
  %v5427 = load i64, ptr %slot51, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %ld5429 = load i64, ptr %p5428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5429, ptr %slot841, align 8
  %v5430 = load i64, ptr %slot50, align 8
  %p5431 = inttoptr i64 %v5430 to ptr
  %ld5432 = load i64, ptr %p5431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5432, ptr %slot842, align 8
  %v5433 = load i64, ptr %slot842, align 8
  %v5434 = load i64, ptr %slot841, align 8
  %ovpair5436 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5433, i64 %v5434)
  %op5435 = extractvalue { i64, i1 } %ovpair5436, 0
  %ov5437 = extractvalue { i64, i1 } %ovpair5436, 1
  store i64 %op5435, ptr %slot843, align 8
  %v5438 = load i64, ptr %slot842, align 8
  %v5439 = load i64, ptr %slot843, align 8
  %op5440 = xor i64 %v5438, %v5439
  store i64 %op5440, ptr %slot844, align 8
  %v5441 = load i64, ptr %slot841, align 8
  %v5442 = load i64, ptr %slot843, align 8
  %op5443 = xor i64 %v5441, %v5442
  store i64 %op5443, ptr %slot845, align 8
  %v5444 = load i64, ptr %slot844, align 8
  %v5445 = load i64, ptr %slot845, align 8
  %op5446 = and i64 %v5444, %v5445
  store i64 %op5446, ptr %slot846, align 8
  %cv5447 = zext i1 %ov5437 to i64
  store i64 %cv5447, ptr %slot847, align 8
  %v5448 = load i64, ptr %slot847, align 8
  %cond5449 = icmp ne i64 %v5448, 0
  br i1 %cond5449, label %bb_overflow1020, label %bb_checked1020
bb_overflow1020:
  %v5450 = load i64, ptr %slot1, align 8
  %p5451 = inttoptr i64 %v5450 to ptr
  %v5452 = load i64, ptr %slot842, align 8
  %v5453 = load i64, ptr %slot841, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5451, i64 0, i64 %v5452, i64 %v5453, i64 64) nomerge, !dbg !148
  unreachable
bb_checked1020:
  %v5454 = load i64, ptr %slot843, align 8
  %v5455 = load i64, ptr %slot50, align 8
  %p5456 = inttoptr i64 %v5455 to ptr
  store i64 %v5454, ptr %p5456, align 8, !alias.scope !3, !noalias !4
  %v5457 = load i64, ptr %slot50, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  %ld5459 = load i64, ptr %p5458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5459, ptr %slot848, align 8
  %v5460 = load i64, ptr %slot848, align 8
  %v5461 = load i64, ptr %slot46, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  store i64 %v5460, ptr %p5462, align 8, !alias.scope !3, !noalias !4
  br label %bb_i75
bb_i75:
  %v5463 = load i64, ptr %slot46, align 8
  %p5464 = inttoptr i64 %v5463 to ptr
  %ld5465 = load i64, ptr %p5464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5465, ptr %slot849, align 8
  %v5466 = load i64, ptr %slot849, align 8
  %v5467 = load i64, ptr %slot50, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  store i64 %v5466, ptr %p5468, align 8, !alias.scope !3, !noalias !4
  %v5469 = load i64, ptr %slot45, align 8
  %v5470 = load i64, ptr %slot53, align 8
  %p5471 = inttoptr i64 %v5469 to ptr
  %p5472 = inttoptr i64 %v5470 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5472, ptr %p5471, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5473 = load i64, ptr %slot53, align 8
  %v5474 = load i64, ptr %slot51, align 8
  %p5475 = inttoptr i64 %v5474 to ptr
  store i64 %v5473, ptr %p5475, align 8, !alias.scope !3, !noalias !4
  %v5476 = load i64, ptr %slot44, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  %ld5478 = load i64, ptr %p5477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5478, ptr %slot850, align 8
  %v5479 = load i64, ptr %slot51, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %ld5481 = load i64, ptr %p5480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5481, ptr %slot851, align 8
  %v5482 = load i64, ptr %slot50, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  %ld5484 = load i64, ptr %p5483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5484, ptr %slot852, align 8
  %v5485 = load i64, ptr %slot850, align 8
  %p5486 = inttoptr i64 %v5485 to ptr
  %ld5487 = load i64, ptr %p5486, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5487, ptr %slot853, align 8
  %v5488 = load i64, ptr %slot852, align 8
  %v5489 = load i64, ptr %slot853, align 8
  %cmp5490 = icmp ult i64 %v5488, %v5489
  %cv5491 = zext i1 %cmp5490 to i64
  store i64 %cv5491, ptr %slot854, align 8
  %v5492 = load i64, ptr %slot854, align 8
  %cond5493 = icmp ne i64 %v5492, 0
  br i1 %cond5493, label %bb_success1033, label %bb_failed1033
bb_failed1033:
  %v5494 = load i64, ptr %slot1, align 8
  %p5495 = inttoptr i64 %v5494 to ptr
  %v5496 = load i64, ptr %slot852, align 8
  %v5497 = load i64, ptr %slot853, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5495, i64 %v5496, i64 %v5497) nomerge, !dbg !150
  unreachable
bb_success1033:
  %v5498 = load i64, ptr %slot850, align 8
  %op5499 = add i64 %v5498, 32
  store i64 %op5499, ptr %slot855, align 8
  %v5500 = load i64, ptr %slot855, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  %ld5502 = load i64, ptr %p5501, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5502, ptr %slot856, align 8
  %v5503 = load i64, ptr %slot852, align 8
  %op5504 = mul i64 %v5503, 32
  store i64 %op5504, ptr %slot857, align 8
  %v5505 = load i64, ptr %slot856, align 8
  %v5506 = load i64, ptr %slot857, align 8
  %op5507 = add i64 %v5505, %v5506
  store i64 %op5507, ptr %slot858, align 8
  %v5508 = load i64, ptr %slot51, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %ld5510 = load i64, ptr %p5509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5510, ptr %slot859, align 8
  %v5511 = load i64, ptr %slot859, align 8
  %v5512 = load i64, ptr %slot858, align 8
  %p5513 = inttoptr i64 %v5511 to ptr
  %p5514 = inttoptr i64 %v5512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5514, ptr %p5513, i64 32, i1 false), !alias.scope !10000000
  %v5515 = load i64, ptr %slot50, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  store i64 0, ptr %p5516, align 8, !alias.scope !3, !noalias !4
  %v5517 = load i64, ptr %slot29, align 8
  store i64 %v5517, ptr %slot860, align 8
  %v5518 = load i64, ptr %slot860, align 8
  %p5520 = inttoptr i64 %v5518 to ptr
  %gep5521 = getelementptr i8, ptr %p5520, i64 24
  %op5519 = ptrtoint ptr %gep5521 to i64
  store i64 %op5519, ptr %slot861, align 8
  %v5522 = load i64, ptr %slot861, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  %ld5524 = load i32, ptr %p5523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5524, ptr %slot862, align 8
  %v5525 = load i32, ptr %slot862, align 8
  %cv5526 = zext i32 %v5525 to i64
  %cond5527 = icmp ne i64 %cv5526, 0
  br i1 %cond5527, label %bb_rcsendactive1040, label %bb_rcsenddone1040
bb_rcsendactive1040:
  %v5528 = load i64, ptr %slot59, align 8
  %p5530 = inttoptr i64 %v5528 to ptr
  %gep5531 = getelementptr i8, ptr %p5530, i64 5640
  %op5529 = ptrtoint ptr %gep5531 to i64
  store i64 %op5529, ptr %slot863, align 8
  %v5532 = load i64, ptr %slot863, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  %ld5534 = load i64, ptr %p5533, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5534, ptr %slot864, align 8
  %v5535 = load i64, ptr %slot864, align 8
  %op5536 = add i64 %v5535, 248
  store i64 %op5536, ptr %slot865, align 8
  %v5537 = load i64, ptr %slot865, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  %ld5539 = load i64, ptr %p5538, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5539, ptr %slot866, align 8
  %v5540 = load i64, ptr %slot866, align 8
  %v5541 = load i64, ptr %slot860, align 8
  %cmp5542 = icmp eq i64 %v5540, %v5541
  %cv5543 = zext i1 %cmp5542 to i32
  store i32 %cv5543, ptr %slot867, align 8
  %v5544 = load i32, ptr %slot867, align 8
  %cv5545 = zext i32 %v5544 to i64
  %cond5546 = icmp ne i64 %cv5545, 0
  br i1 %cond5546, label %bb_rcs1048, label %bb_rcsendslow1040
bb_rcs1048:
  %v5547 = load i64, ptr %slot864, align 8
  %op5548 = add i64 %v5547, 200
  store i64 %op5548, ptr %slot868, align 8
  %v5549 = load i64, ptr %slot868, align 8
  %p5550 = inttoptr i64 %v5549 to ptr
  %ld5551 = load i64, ptr %p5550, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5551, ptr %slot869, align 8
  %v5552 = load i64, ptr %slot869, align 8
  %cmp5553 = icmp eq i64 %v5552, 0
  %cv5554 = zext i1 %cmp5553 to i32
  store i32 %cv5554, ptr %slot870, align 8
  %v5555 = load i32, ptr %slot870, align 8
  %cv5556 = zext i32 %v5555 to i64
  %cond5557 = icmp ne i64 %cv5556, 0
  br i1 %cond5557, label %bb_rcs1052, label %bb_rcsendslow1040
bb_rcs1052:
  %v5558 = load i64, ptr %slot860, align 8
  %p5560 = inttoptr i64 %v5558 to ptr
  %gep5561 = getelementptr i8, ptr %p5560, i64 16
  %op5559 = ptrtoint ptr %gep5561 to i64
  store i64 %op5559, ptr %slot871, align 8
  %v5562 = load i64, ptr %slot871, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %ld5564 = load i64, ptr %p5563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5564, ptr %slot872, align 8
  %v5565 = load i64, ptr %slot872, align 8
  %cmp5566 = icmp ne i64 %v5565, 0
  %cv5567 = zext i1 %cmp5566 to i32
  store i32 %cv5567, ptr %slot873, align 8
  %v5568 = load i32, ptr %slot873, align 8
  %cv5569 = zext i32 %v5568 to i64
  %cond5570 = icmp ne i64 %cv5569, 0
  br i1 %cond5570, label %bb_rcsendnode1040, label %bb_rcsendunlink1040
bb_rcsendnode1040:
  %v5571 = load i64, ptr %slot872, align 8
  %op5572 = add i64 %v5571, 0
  store i64 %op5572, ptr %slot874, align 8
  %v5573 = load i64, ptr %slot874, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %ld5575 = load i64, ptr %p5574, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5575, ptr %slot875, align 8
  %v5576 = load i64, ptr %slot875, align 8
  %cmp5577 = icmp eq i64 %v5576, 0
  %cv5578 = zext i1 %cmp5577 to i32
  store i32 %cv5578, ptr %slot876, align 8
  %v5579 = load i32, ptr %slot876, align 8
  %cv5580 = zext i32 %v5579 to i64
  %cond5581 = icmp ne i64 %cv5580, 0
  br i1 %cond5581, label %bb_rcs1059, label %bb_rcsendslow1040
bb_rcs1059:
  %v5582 = load i64, ptr %slot864, align 8
  %op5583 = add i64 %v5582, 264
  store i64 %op5583, ptr %slot877, align 8
  %v5584 = load i64, ptr %slot877, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  %ld5586 = load i64, ptr %p5585, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5586, ptr %slot878, align 8
  %v5587 = load i64, ptr %slot878, align 8
  %cmp5588 = icmp ult i64 %v5587, 32
  %cv5589 = zext i1 %cmp5588 to i32
  store i32 %cv5589, ptr %slot879, align 8
  %v5590 = load i32, ptr %slot879, align 8
  %cv5591 = zext i32 %v5590 to i64
  %cond5592 = icmp ne i64 %cv5591, 0
  br i1 %cond5592, label %bb_rcs1063, label %bb_rcsendslow1040
bb_rcs1063:
  %v5593 = load i64, ptr %slot872, align 8
  %op5594 = add i64 %v5593, 8
  store i64 %op5594, ptr %slot880, align 8
  %v5595 = load i64, ptr %slot880, align 8
  %p5596 = inttoptr i64 %v5595 to ptr
  %ld5597 = load i64, ptr %p5596, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5597, ptr %slot881, align 8
  %v5598 = load i64, ptr %slot881, align 8
  %cmp5599 = icmp ne i64 %v5598, 0
  %cv5600 = zext i1 %cmp5599 to i32
  store i32 %cv5600, ptr %slot882, align 8
  %v5601 = load i32, ptr %slot882, align 8
  %cv5602 = zext i32 %v5601 to i64
  %cond5603 = icmp ne i64 %cv5602, 0
  br i1 %cond5603, label %bb_rcs1067, label %bb_rcsendslow1040
bb_rcs1067:
  %v5604 = load i64, ptr %slot881, align 8
  %op5605 = sub i64 %v5604, 16
  store i64 %op5605, ptr %slot883, align 8
  %v5606 = load i64, ptr %slot881, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  %rgep5608 = getelementptr i8, ptr %p5607, i64 -16
  %ld5609 = load i64, ptr %rgep5608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5609, ptr %slot884, align 8
  %v5610 = load i64, ptr %slot884, align 8
  %op5611 = and i64 %v5610, 4611686018427387907
  store i64 %op5611, ptr %slot885, align 8
  %v5612 = load i64, ptr %slot885, align 8
  %cmp5613 = icmp eq i64 %v5612, 0
  %cv5614 = zext i1 %cmp5613 to i32
  store i32 %cv5614, ptr %slot886, align 8
  %v5615 = load i32, ptr %slot886, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcs1072, label %bb_rcsendslow1040
bb_rcs1072:
  %v5618 = load i64, ptr %slot881, align 8
  %op5619 = sub i64 %v5618, 24
  store i64 %op5619, ptr %slot887, align 8
  %v5620 = load i64, ptr %slot881, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  %rgep5622 = getelementptr i8, ptr %p5621, i64 -24
  %ld5623 = load i64, ptr %rgep5622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5623, ptr %slot888, align 8
  %v5624 = load i64, ptr %slot888, align 8
  %cmp5625 = icmp ne i64 %v5624, 0
  %cv5626 = zext i1 %cmp5625 to i32
  store i32 %cv5626, ptr %slot889, align 8
  %v5627 = load i32, ptr %slot889, align 8
  %cv5628 = zext i32 %v5627 to i64
  %cond5629 = icmp ne i64 %cv5628, 0
  br i1 %cond5629, label %bb_rcs1076, label %bb_rcsendslow1040
bb_rcs1076:
  %v5630 = load i64, ptr %slot881, align 8
  %op5631 = sub i64 %v5630, 32
  store i64 %op5631, ptr %slot890, align 8
  %v5632 = load i64, ptr %slot881, align 8
  %p5633 = inttoptr i64 %v5632 to ptr
  %rgep5634 = getelementptr i8, ptr %p5633, i64 -32
  %ld5635 = load i64, ptr %rgep5634, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5635, ptr %slot891, align 8
  %v5636 = load i64, ptr %slot888, align 8
  %cmp5637 = icmp ugt i64 %v5636, 1
  %cv5638 = zext i1 %cmp5637 to i32
  store i32 %cv5638, ptr %slot892, align 8
  %v5639 = load i64, ptr %slot891, align 8
  %cmp5640 = icmp ne i64 %v5639, 0
  %cv5641 = zext i1 %cmp5640 to i32
  store i32 %cv5641, ptr %slot893, align 8
  %v5642 = load i32, ptr %slot892, align 8
  %v5643 = load i32, ptr %slot893, align 8
  %op5644 = or i32 %v5642, %v5643
  store i32 %op5644, ptr %slot894, align 8
  %v5645 = load i32, ptr %slot894, align 8
  %cv5646 = zext i32 %v5645 to i64
  %cond5647 = icmp ne i64 %cv5646, 0
  br i1 %cond5647, label %bb_rcs1082, label %bb_rcsendslow1040
bb_rcs1082:
  %v5648 = load i64, ptr %slot872, align 8
  %op5649 = add i64 %v5648, 32
  store i64 %op5649, ptr %slot895, align 8
  %v5650 = load i64, ptr %slot895, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  %ld5652 = load i64, ptr %p5651, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5652, ptr %slot896, align 8
  %v5653 = load i64, ptr %slot896, align 8
  %cmp5654 = icmp ne i64 %v5653, 0
  %cv5655 = zext i1 %cmp5654 to i32
  store i32 %cv5655, ptr %slot897, align 8
  %v5656 = load i32, ptr %slot897, align 8
  %cv5657 = zext i32 %v5656 to i64
  %cond5658 = icmp ne i64 %cv5657, 0
  br i1 %cond5658, label %bb_rcsendbacking1040, label %bb_rcsendcommit1040
bb_rcsendbacking1040:
  %v5659 = load i64, ptr %slot896, align 8
  %op5660 = sub i64 %v5659, 16
  store i64 %op5660, ptr %slot898, align 8
  %v5661 = load i64, ptr %slot896, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  %rgep5663 = getelementptr i8, ptr %p5662, i64 -16
  %ld5664 = load i64, ptr %rgep5663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5664, ptr %slot899, align 8
  %v5665 = load i64, ptr %slot899, align 8
  %op5666 = and i64 %v5665, 4611686018427387907
  store i64 %op5666, ptr %slot900, align 8
  %v5667 = load i64, ptr %slot900, align 8
  %cmp5668 = icmp eq i64 %v5667, 0
  %cv5669 = zext i1 %cmp5668 to i32
  store i32 %cv5669, ptr %slot901, align 8
  %v5670 = load i32, ptr %slot901, align 8
  %cv5671 = zext i32 %v5670 to i64
  %cond5672 = icmp ne i64 %cv5671, 0
  br i1 %cond5672, label %bb_rcs1090, label %bb_rcsendslow1040
bb_rcs1090:
  %v5673 = load i64, ptr %slot896, align 8
  %op5674 = sub i64 %v5673, 24
  store i64 %op5674, ptr %slot902, align 8
  %v5675 = load i64, ptr %slot896, align 8
  %p5676 = inttoptr i64 %v5675 to ptr
  %rgep5677 = getelementptr i8, ptr %p5676, i64 -24
  %ld5678 = load i64, ptr %rgep5677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5678, ptr %slot903, align 8
  %v5679 = load i64, ptr %slot903, align 8
  %cmp5680 = icmp ne i64 %v5679, 0
  %cv5681 = zext i1 %cmp5680 to i32
  store i32 %cv5681, ptr %slot904, align 8
  %v5682 = load i32, ptr %slot904, align 8
  %cv5683 = zext i32 %v5682 to i64
  %cond5684 = icmp ne i64 %cv5683, 0
  br i1 %cond5684, label %bb_rcs1094, label %bb_rcsendslow1040
bb_rcs1094:
  %v5685 = load i64, ptr %slot896, align 8
  %op5686 = sub i64 %v5685, 32
  store i64 %op5686, ptr %slot905, align 8
  %v5687 = load i64, ptr %slot896, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  %rgep5689 = getelementptr i8, ptr %p5688, i64 -32
  %ld5690 = load i64, ptr %rgep5689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5690, ptr %slot906, align 8
  %v5691 = load i64, ptr %slot903, align 8
  %cmp5692 = icmp ugt i64 %v5691, 1
  %cv5693 = zext i1 %cmp5692 to i32
  store i32 %cv5693, ptr %slot907, align 8
  %v5694 = load i64, ptr %slot906, align 8
  %cmp5695 = icmp ne i64 %v5694, 0
  %cv5696 = zext i1 %cmp5695 to i32
  store i32 %cv5696, ptr %slot908, align 8
  %v5697 = load i32, ptr %slot907, align 8
  %v5698 = load i32, ptr %slot908, align 8
  %op5699 = or i32 %v5697, %v5698
  store i32 %op5699, ptr %slot909, align 8
  %v5700 = load i32, ptr %slot909, align 8
  %cv5701 = zext i32 %v5700 to i64
  %cond5702 = icmp ne i64 %cv5701, 0
  br i1 %cond5702, label %bb_rcs1100, label %bb_rcsendslow1040
bb_rcs1100:
  br label %bb_rcsendcommit1040
bb_rcsendcommit1040:
  %v5703 = load i64, ptr %slot872, align 8
  %op5704 = add i64 %v5703, 24
  store i64 %op5704, ptr %slot910, align 8
  %v5705 = load i64, ptr %slot910, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  %ld5707 = load i32, ptr %p5706, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld5707, ptr %slot911, align 8
  %v5708 = load i32, ptr %slot911, align 8
  %cv5709 = zext i32 %v5708 to i64
  %cond5710 = icmp ne i64 %cv5709, 0
  br i1 %cond5710, label %bb_rcsendrestore1040, label %bb_rcsendreturned1040
bb_rcsendrestore1040:
  %v5711 = load i64, ptr %slot872, align 8
  %op5712 = add i64 %v5711, 16
  store i64 %op5712, ptr %slot912, align 8
  %v5713 = load i64, ptr %slot912, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  %ld5715 = load i64, ptr %p5714, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5715, ptr %slot913, align 8
  %v5716 = load i64, ptr %slot884, align 8
  %op5717 = and i64 %v5716, 17293822569102704639
  store i64 %op5717, ptr %slot914, align 8
  %v5718 = load i64, ptr %slot914, align 8
  %v5719 = load i64, ptr %slot913, align 8
  %op5720 = or i64 %v5718, %v5719
  store i64 %op5720, ptr %slot915, align 8
  %v5721 = load i64, ptr %slot881, align 8
  %op5722 = sub i64 %v5721, 16
  store i64 %op5722, ptr %slot916, align 8
  %v5723 = load i64, ptr %slot915, align 8
  %v5724 = load i64, ptr %slot881, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  %rgep5726 = getelementptr i8, ptr %p5725, i64 -16
  store i64 %v5723, ptr %rgep5726, align 8, !alias.scope !9, !noalias !10
  %v5727 = load i64, ptr %slot860, align 8
  %p5729 = inttoptr i64 %v5727 to ptr
  %gep5730 = getelementptr i8, ptr %p5729, i64 16
  %op5728 = ptrtoint ptr %gep5730 to i64
  store i64 %op5728, ptr %slot917, align 8
  br label %bb_rcsendreturned1040
bb_rcsendreturned1040:
  %v5731 = load i64, ptr %slot917, align 8
  %p5732 = inttoptr i64 %v5731 to ptr
  store i64 0, ptr %p5732, align 8, !alias.scope !3, !noalias !4
  %v5733 = load i64, ptr %slot864, align 8
  %op5734 = add i64 %v5733, 256
  store i64 %op5734, ptr %slot918, align 8
  %v5735 = load i64, ptr %slot918, align 8
  %p5736 = inttoptr i64 %v5735 to ptr
  %ld5737 = load i64, ptr %p5736, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5737, ptr %slot919, align 8
  %v5738 = load i64, ptr %slot872, align 8
  %op5739 = add i64 %v5738, 0
  store i64 %op5739, ptr %slot920, align 8
  %v5740 = load i64, ptr %slot919, align 8
  %v5741 = load i64, ptr %slot920, align 8
  %p5742 = inttoptr i64 %v5741 to ptr
  store i64 %v5740, ptr %p5742, align 8, !alias.scope !9999998, !noalias !9999999
  %v5743 = load i64, ptr %slot864, align 8
  %op5744 = add i64 %v5743, 256
  store i64 %op5744, ptr %slot921, align 8
  %v5745 = load i64, ptr %slot872, align 8
  %v5746 = load i64, ptr %slot921, align 8
  %p5747 = inttoptr i64 %v5746 to ptr
  store i64 %v5745, ptr %p5747, align 8, !alias.scope !9999998, !noalias !9999999
  %v5748 = load i64, ptr %slot864, align 8
  %op5749 = add i64 %v5748, 264
  store i64 %op5749, ptr %slot922, align 8
  %v5750 = load i64, ptr %slot922, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %ld5752 = load i64, ptr %p5751, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5752, ptr %slot923, align 8
  %v5753 = load i64, ptr %slot923, align 8
  %op5754 = add i64 %v5753, 1
  store i64 %op5754, ptr %slot924, align 8
  %v5755 = load i64, ptr %slot924, align 8
  %v5756 = load i64, ptr %slot922, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  store i64 %v5755, ptr %p5757, align 8, !alias.scope !9999998, !noalias !9999999
  %v5758 = load i64, ptr %slot59, align 8
  %p5760 = inttoptr i64 %v5758 to ptr
  %gep5761 = getelementptr i8, ptr %p5760, i64 24
  %op5759 = ptrtoint ptr %gep5761 to i64
  store i64 %op5759, ptr %slot925, align 8
  %v5762 = load i64, ptr %slot925, align 8
  %p5763 = inttoptr i64 %v5762 to ptr
  %ld5764 = load i64, ptr %p5763, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5764, ptr %slot926, align 8
  %v5765 = load i64, ptr %slot926, align 8
  %op5766 = add i64 %v5765, 18446744073709551576
  store i64 %op5766, ptr %slot927, align 8
  %v5767 = load i64, ptr %slot927, align 8
  %v5768 = load i64, ptr %slot925, align 8
  %p5769 = inttoptr i64 %v5768 to ptr
  store i64 %v5767, ptr %p5769, align 8, !alias.scope !9999998, !noalias !9999999
  %v5770 = load i64, ptr %slot864, align 8
  %op5771 = add i64 %v5770, 48
  store i64 %op5771, ptr %slot928, align 8
  %v5772 = load i64, ptr %slot928, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  %ld5774 = load i64, ptr %p5773, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5774, ptr %slot929, align 8
  %v5775 = load i64, ptr %slot929, align 8
  %op5776 = add i64 %v5775, 18446744073709551576
  store i64 %op5776, ptr %slot930, align 8
  %v5777 = load i64, ptr %slot930, align 8
  %v5778 = load i64, ptr %slot928, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  store i64 %v5777, ptr %p5779, align 8, !alias.scope !9999998, !noalias !9999999
  %v5780 = load i64, ptr %slot896, align 8
  %cmp5781 = icmp ne i64 %v5780, 0
  %cv5782 = zext i1 %cmp5781 to i32
  store i32 %cv5782, ptr %slot931, align 8
  %v5783 = load i32, ptr %slot931, align 8
  %cv5784 = zext i32 %v5783 to i64
  %cond5785 = icmp ne i64 %cv5784, 0
  br i1 %cond5785, label %bb_rcsenddropbacking1040, label %bb_rcsenddroppayload1040
bb_rcsenddropbacking1040:
  %v5786 = load i64, ptr %slot896, align 8
  %op5787 = sub i64 %v5786, 24
  store i64 %op5787, ptr %slot932, align 8
  %v5788 = load i64, ptr %slot896, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  %rgep5790 = getelementptr i8, ptr %p5789, i64 -24
  %ld5791 = load i64, ptr %rgep5790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5791, ptr %slot933, align 8
  %v5792 = load i64, ptr %slot933, align 8
  %op5793 = add i64 %v5792, 18446744073709551615
  store i64 %op5793, ptr %slot934, align 8
  %v5794 = load i64, ptr %slot934, align 8
  %v5795 = load i64, ptr %slot896, align 8
  %p5796 = inttoptr i64 %v5795 to ptr
  %rgep5797 = getelementptr i8, ptr %p5796, i64 -24
  store i64 %v5794, ptr %rgep5797, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1040
bb_rcsenddroppayload1040:
  %v5798 = load i64, ptr %slot881, align 8
  %op5799 = sub i64 %v5798, 24
  store i64 %op5799, ptr %slot935, align 8
  %v5800 = load i64, ptr %slot881, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  %rgep5802 = getelementptr i8, ptr %p5801, i64 -24
  %ld5803 = load i64, ptr %rgep5802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5803, ptr %slot936, align 8
  %v5804 = load i64, ptr %slot936, align 8
  %op5805 = add i64 %v5804, 18446744073709551615
  store i64 %op5805, ptr %slot937, align 8
  %v5806 = load i64, ptr %slot937, align 8
  %v5807 = load i64, ptr %slot881, align 8
  %p5808 = inttoptr i64 %v5807 to ptr
  %rgep5809 = getelementptr i8, ptr %p5808, i64 -24
  store i64 %v5806, ptr %rgep5809, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1040
bb_rcsendunlink1040:
  %v5810 = load i64, ptr %slot860, align 8
  %p5812 = inttoptr i64 %v5810 to ptr
  %gep5813 = getelementptr i8, ptr %p5812, i64 8
  %op5811 = ptrtoint ptr %gep5813 to i64
  store i64 %op5811, ptr %slot938, align 8
  %v5814 = load i64, ptr %slot938, align 8
  %p5815 = inttoptr i64 %v5814 to ptr
  %ld5816 = load i64, ptr %p5815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5816, ptr %slot939, align 8
  %v5817 = load i64, ptr %slot864, align 8
  %op5818 = add i64 %v5817, 248
  store i64 %op5818, ptr %slot940, align 8
  %v5819 = load i64, ptr %slot939, align 8
  %v5820 = load i64, ptr %slot940, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  store i64 %v5819, ptr %p5821, align 8, !alias.scope !9999998, !noalias !9999999
  %v5822 = load i64, ptr %slot860, align 8
  %p5824 = inttoptr i64 %v5822 to ptr
  %gep5825 = getelementptr i8, ptr %p5824, i64 24
  %op5823 = ptrtoint ptr %gep5825 to i64
  store i64 %op5823, ptr %slot941, align 8
  %v5826 = load i64, ptr %slot860, align 8
  %p5828 = inttoptr i64 %v5826 to ptr
  %gep5829 = getelementptr i8, ptr %p5828, i64 8
  %op5827 = ptrtoint ptr %gep5829 to i64
  store i64 %op5827, ptr %slot942, align 8
  %v5830 = load i64, ptr %slot941, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  store i32 0, ptr %p5831, align 4, !alias.scope !3, !noalias !4
  %v5832 = load i64, ptr %slot942, align 8
  %p5833 = inttoptr i64 %v5832 to ptr
  store i64 0, ptr %p5833, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1040
bb_rcsendslow1040:
  %v5834 = load i64, ptr %slot1, align 8
  %p5835 = inttoptr i64 %v5834 to ptr
  %v5836 = load i64, ptr %slot860, align 8
  %p5837 = inttoptr i64 %v5836 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p5835, ptr %p5837) nomerge, !dbg !150
  br label %bb_rcsenddone1040
bb_rcsenddone1040:
  %v5838 = load i64, ptr %slot34, align 8
  %p5839 = inttoptr i64 %v5838 to ptr
  %ld5840 = load i64, ptr %p5839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5840, ptr %slot943, align 8
  %v5841 = load i64, ptr %slot943, align 8
  %v5842 = load i64, ptr %slot50, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  store i64 %v5841, ptr %p5843, align 8, !alias.scope !3, !noalias !4
  %v5844 = load i64, ptr %slot50, align 8
  %p5845 = inttoptr i64 %v5844 to ptr
  %ld5846 = load i64, ptr %p5845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5846, ptr %slot944, align 8
  %v5847 = load i64, ptr %slot944, align 8
  %op5848 = add i64 %v5847, 8
  store i64 %op5848, ptr %slot945, align 8
  %v5849 = load i64, ptr %slot945, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  %ld5851 = load i64, ptr %p5850, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5851, ptr %slot946, align 8
  %v5852 = load i64, ptr %slot946, align 8
  %v5853 = load i64, ptr %slot50, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  store i64 %v5852, ptr %p5854, align 8, !alias.scope !3, !noalias !4
  %v5855 = load i64, ptr %slot17, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %ld5857 = load i32, ptr %p5856, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5857, ptr %slot947, align 8
  %v5858 = load i32, ptr %slot947, align 8
  %cv5859 = zext i32 %v5858 to i64
  %cond5860 = icmp ne i64 %cv5859, 0
  br i1 %cond5860, label %bb_rcslotdrop1140, label %bb_rcslotdone1140
bb_rcslotdrop1140:
  %v5861 = load i64, ptr %slot17, align 8
  %p5862 = inttoptr i64 %v5861 to ptr
  store i32 0, ptr %p5862, align 4, !alias.scope !3, !noalias !4
  %v5863 = load i64, ptr %slot24, align 8
  store i64 %v5863, ptr %slot948, align 8
  %v5864 = load i64, ptr %slot18, align 8
  %p5865 = inttoptr i64 %v5864 to ptr
  %ld5866 = load i32, ptr %p5865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5866, ptr %slot949, align 8
  %v5867 = load i32, ptr %slot949, align 8
  %op5868 = and i32 %v5867, 28
  store i32 %op5868, ptr %slot950, align 8
  %v5869 = load i32, ptr %slot950, align 8
  %cv5870 = zext i32 %v5869 to i64
  %cond5871 = icmp ne i64 %cv5870, 0
  br i1 %cond5871, label %bb_rcslotrole1140, label %bb_rcslotowner1140
bb_rcslotrole1140:
  %v5872 = load i64, ptr %slot59, align 8
  store i64 %v5872, ptr %slot951, align 8
  %v5873 = load i64, ptr %slot951, align 8
  %v5874 = load i64, ptr %slot948, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5873, i64 %v5874) nomerge, !dbg !152
  br label %bb_rcslotdone1140
bb_rcslotowner1140:
  %v5875 = load i64, ptr %slot59, align 8
  store i64 %v5875, ptr %slot952, align 8
  %v5876 = load i64, ptr %slot952, align 8
  %v5877 = load i64, ptr %slot948, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v5876, i64 %v5877) nomerge, !dbg !152
  br label %bb_rcslotdone1140
bb_rcslotdone1140:
  %v5878 = load i64, ptr %slot51, align 8
  %p5879 = inttoptr i64 %v5878 to ptr
  store i64 1, ptr %p5879, align 8, !alias.scope !3, !noalias !4
  %v5880 = load i64, ptr %slot51, align 8
  %p5881 = inttoptr i64 %v5880 to ptr
  %ld5882 = load i64, ptr %p5881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5882, ptr %slot953, align 8
  %v5883 = load i64, ptr %slot50, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %ld5885 = load i64, ptr %p5884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5885, ptr %slot954, align 8
  %v5886 = load i64, ptr %slot954, align 8
  %v5887 = load i64, ptr %slot953, align 8
  %ovpair5889 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5886, i64 %v5887)
  %op5888 = extractvalue { i64, i1 } %ovpair5889, 0
  %ov5890 = extractvalue { i64, i1 } %ovpair5889, 1
  store i64 %op5888, ptr %slot955, align 8
  %cv5891 = zext i1 %ov5890 to i64
  store i64 %cv5891, ptr %slot956, align 8
  %v5892 = load i64, ptr %slot956, align 8
  %cond5893 = icmp ne i64 %v5892, 0
  br i1 %cond5893, label %bb_overflow1149, label %bb_checked1149
bb_overflow1149:
  %v5894 = load i64, ptr %slot1, align 8
  %p5895 = inttoptr i64 %v5894 to ptr
  %v5896 = load i64, ptr %slot954, align 8
  %v5897 = load i64, ptr %slot953, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5895, i64 0, i64 %v5896, i64 %v5897, i64 64) nomerge, !dbg !154
  unreachable
bb_checked1149:
  %v5898 = load i64, ptr %slot955, align 8
  %v5899 = load i64, ptr %slot50, align 8
  %p5900 = inttoptr i64 %v5899 to ptr
  store i64 %v5898, ptr %p5900, align 8, !alias.scope !3, !noalias !4
  %v5901 = load i64, ptr %slot50, align 8
  %p5902 = inttoptr i64 %v5901 to ptr
  %ld5903 = load i64, ptr %p5902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5903, ptr %slot957, align 8
  %v5904 = load i64, ptr %slot957, align 8
  %v5905 = load i64, ptr %slot47, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  store i64 %v5904, ptr %p5906, align 8, !alias.scope !3, !noalias !4
  %v5907 = load i64, ptr %slot34, align 8
  %p5908 = inttoptr i64 %v5907 to ptr
  %ld5909 = load i64, ptr %p5908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5909, ptr %slot958, align 8
  %v5910 = load i64, ptr %slot958, align 8
  %v5911 = load i64, ptr %slot50, align 8
  %p5912 = inttoptr i64 %v5911 to ptr
  store i64 %v5910, ptr %p5912, align 8, !alias.scope !3, !noalias !4
  %v5913 = load i64, ptr %slot34, align 8
  %p5914 = inttoptr i64 %v5913 to ptr
  %ld5915 = load i64, ptr %p5914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5915, ptr %slot959, align 8
  %v5916 = load i64, ptr %slot959, align 8
  %v5917 = load i64, ptr %slot50, align 8
  %p5918 = inttoptr i64 %v5917 to ptr
  store i64 %v5916, ptr %p5918, align 8, !alias.scope !3, !noalias !4
  %v5919 = load i64, ptr %slot34, align 8
  %p5920 = inttoptr i64 %v5919 to ptr
  %ld5921 = load i64, ptr %p5920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5921, ptr %slot960, align 8
  %v5922 = load i64, ptr %slot960, align 8
  %v5923 = load i64, ptr %slot50, align 8
  %p5924 = inttoptr i64 %v5923 to ptr
  store i64 %v5922, ptr %p5924, align 8, !alias.scope !3, !noalias !4
  %v5925 = load i64, ptr %slot47, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %ld5927 = load i64, ptr %p5926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5927, ptr %slot961, align 8
  %v5928 = load i64, ptr %slot961, align 8
  %v5929 = load i64, ptr %slot51, align 8
  %p5930 = inttoptr i64 %v5929 to ptr
  store i64 %v5928, ptr %p5930, align 8, !alias.scope !3, !noalias !4
  %v5931 = load i64, ptr %slot34, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  %ld5933 = load i64, ptr %p5932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5933, ptr %slot962, align 8
  %v5934 = load i64, ptr %slot962, align 8
  %v5935 = load i64, ptr %slot50, align 8
  %p5936 = inttoptr i64 %v5935 to ptr
  store i64 %v5934, ptr %p5936, align 8, !alias.scope !3, !noalias !4
  %v5937 = load i64, ptr %slot47, align 8
  %p5938 = inttoptr i64 %v5937 to ptr
  %ld5939 = load i64, ptr %p5938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5939, ptr %slot963, align 8
  %v5940 = load i64, ptr %slot34, align 8
  %p5941 = inttoptr i64 %v5940 to ptr
  %ld5942 = load i64, ptr %p5941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5942, ptr %slot964, align 8
  %v5943 = load i64, ptr %slot964, align 8
  %op5944 = add i64 %v5943, 8
  store i64 %op5944, ptr %slot965, align 8
  %v5945 = load i64, ptr %slot963, align 8
  %v5946 = load i64, ptr %slot965, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  store i64 %v5945, ptr %p5947, align 8, !alias.scope !4, !noalias !3
  %v5948 = load i64, ptr %slot50, align 8
  %p5949 = inttoptr i64 %v5948 to ptr
  store i64 0, ptr %p5949, align 8, !alias.scope !3, !noalias !4
  br label %bb_i94
bb_i94:
  %v5950 = load i64, ptr %slot42, align 8
  %p5951 = inttoptr i64 %v5950 to ptr
  %ld5952 = load i64, ptr %p5951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5952, ptr %slot966, align 8
  %v5953 = load i64, ptr %slot966, align 8
  %v5954 = load i64, ptr %slot50, align 8
  %p5955 = inttoptr i64 %v5954 to ptr
  store i64 %v5953, ptr %p5955, align 8, !alias.scope !3, !noalias !4
  %v5956 = load i64, ptr %slot40, align 8
  %p5957 = inttoptr i64 %v5956 to ptr
  %ld5958 = load i64, ptr %p5957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5958, ptr %slot967, align 8
  %v5959 = load i64, ptr %slot50, align 8
  %p5960 = inttoptr i64 %v5959 to ptr
  %ld5961 = load i64, ptr %p5960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5961, ptr %slot968, align 8
  %v5962 = load i64, ptr %slot967, align 8
  %p5963 = inttoptr i64 %v5962 to ptr
  %ld5964 = load i64, ptr %p5963, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5964, ptr %slot969, align 8
  %v5965 = load i64, ptr %slot969, align 8
  %v5966 = load i64, ptr %slot968, align 8
  %cmp5967 = icmp eq i64 %v5965, %v5966
  %cv5968 = zext i1 %cmp5967 to i64
  store i64 %cv5968, ptr %slot970, align 8
  %v5969 = load i64, ptr %slot970, align 8
  %cond5970 = icmp ne i64 %v5969, 0
  br i1 %cond5970, label %bb_success1165, label %bb_failed1165
bb_failed1165:
  %v5971 = load i64, ptr %slot1, align 8
  %p5972 = inttoptr i64 %v5971 to ptr
  call void @myl_qbe_fail_iteration(ptr %p5972) nomerge, !dbg !156
  unreachable
bb_success1165:
  %v5973 = load i64, ptr %slot50, align 8
  %p5974 = inttoptr i64 %v5973 to ptr
  store i64 0, ptr %p5974, align 8, !alias.scope !3, !noalias !4
  %v5975 = load i64, ptr %slot41, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  %ld5977 = load i64, ptr %p5976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5977, ptr %slot971, align 8
  %v5978 = load i64, ptr %slot971, align 8
  %v5979 = load i64, ptr %slot50, align 8
  %p5980 = inttoptr i64 %v5979 to ptr
  store i64 %v5978, ptr %p5980, align 8, !alias.scope !3, !noalias !4
  %v5981 = load i64, ptr %slot51, align 8
  %p5982 = inttoptr i64 %v5981 to ptr
  store i64 1, ptr %p5982, align 8, !alias.scope !3, !noalias !4
  %v5983 = load i64, ptr %slot51, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %ld5985 = load i64, ptr %p5984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5985, ptr %slot972, align 8
  %v5986 = load i64, ptr %slot50, align 8
  %p5987 = inttoptr i64 %v5986 to ptr
  %ld5988 = load i64, ptr %p5987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5988, ptr %slot973, align 8
  %v5989 = load i64, ptr %slot973, align 8
  %v5990 = load i64, ptr %slot972, align 8
  %ovpair5992 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5989, i64 %v5990)
  %op5991 = extractvalue { i64, i1 } %ovpair5992, 0
  %ov5993 = extractvalue { i64, i1 } %ovpair5992, 1
  store i64 %op5991, ptr %slot974, align 8
  %cv5994 = zext i1 %ov5993 to i64
  store i64 %cv5994, ptr %slot975, align 8
  %v5995 = load i64, ptr %slot975, align 8
  %cond5996 = icmp ne i64 %v5995, 0
  br i1 %cond5996, label %bb_overflow1169, label %bb_checked1169
bb_overflow1169:
  %v5997 = load i64, ptr %slot1, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %v5999 = load i64, ptr %slot973, align 8
  %v6000 = load i64, ptr %slot972, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5998, i64 0, i64 %v5999, i64 %v6000, i64 64) nomerge, !dbg !158
  unreachable
bb_checked1169:
  %v6001 = load i64, ptr %slot974, align 8
  %v6002 = load i64, ptr %slot50, align 8
  %p6003 = inttoptr i64 %v6002 to ptr
  store i64 %v6001, ptr %p6003, align 8, !alias.scope !3, !noalias !4
  %v6004 = load i64, ptr %slot50, align 8
  %p6005 = inttoptr i64 %v6004 to ptr
  %ld6006 = load i64, ptr %p6005, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6006, ptr %slot976, align 8
  %v6007 = load i64, ptr %slot976, align 8
  %v6008 = load i64, ptr %slot41, align 8
  %p6009 = inttoptr i64 %v6008 to ptr
  store i64 %v6007, ptr %p6009, align 8, !alias.scope !3, !noalias !4
  br label %bb_i40
bb_i102:
  %v6010 = load i64, ptr %slot37, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  %ld6012 = load i64, ptr %p6011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6012, ptr %slot977, align 8
  %v6013 = load i64, ptr %slot8, align 8
  %p6014 = inttoptr i64 %v6013 to ptr
  %ld6015 = load i32, ptr %p6014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6015, ptr %slot978, align 8
  %v6016 = load i32, ptr %slot978, align 8
  %cmp6017 = icmp eq i32 %v6016, 8
  %cv6018 = zext i1 %cmp6017 to i32
  store i32 %cv6018, ptr %slot979, align 8
  %v6019 = load i64, ptr %slot7, align 8
  %p6020 = inttoptr i64 %v6019 to ptr
  %ld6021 = load i32, ptr %p6020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6021, ptr %slot980, align 8
  %v6022 = load i32, ptr %slot979, align 8
  %v6023 = load i32, ptr %slot980, align 8
  %op6024 = and i32 %v6022, %v6023
  store i32 %op6024, ptr %slot981, align 8
  %v6025 = load i32, ptr %slot981, align 8
  %cv6026 = zext i32 %v6025 to i64
  %cond6027 = icmp ne i64 %cv6026, 0
  br i1 %cond6027, label %bb_rchold1173, label %bb_rcordinary1173
bb_rchold1173:
  %v6028 = load i64, ptr %slot28, align 8
  store i64 %v6028, ptr %slot982, align 8
  %v6029 = load i64, ptr %slot977, align 8
  %cmp6030 = icmp ne i64 %v6029, 0
  %cv6031 = zext i1 %cmp6030 to i32
  store i32 %cv6031, ptr %slot983, align 8
  %v6032 = load i32, ptr %slot983, align 8
  %cv6033 = zext i32 %v6032 to i64
  %cond6034 = icmp ne i64 %cv6033, 0
  br i1 %cond6034, label %bb_rcgnn1183, label %bb_rcgstore1183
bb_rcgnn1183:
  %v6035 = load i64, ptr %slot977, align 8
  %op6036 = sub i64 %v6035, 16
  store i64 %op6036, ptr %slot984, align 8
  %v6037 = load i64, ptr %slot977, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  %rgep6039 = getelementptr i8, ptr %p6038, i64 -16
  %ld6040 = load i64, ptr %rgep6039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6040, ptr %slot985, align 8
  %v6041 = load i64, ptr %slot985, align 8
  %op6042 = and i64 %v6041, 4611686018427387906
  store i64 %op6042, ptr %slot986, align 8
  %v6043 = load i64, ptr %slot986, align 8
  %cmp6044 = icmp ne i64 %v6043, 0
  %cv6045 = zext i1 %cmp6044 to i32
  store i32 %cv6045, ptr %slot987, align 8
  %v6046 = load i32, ptr %slot987, align 8
  %cv6047 = zext i32 %v6046 to i64
  %cond6048 = icmp ne i64 %cv6047, 0
  br i1 %cond6048, label %bb_rcgstore1183, label %bb_rcginc1183
bb_rcginc1183:
  %v6049 = load i64, ptr %slot977, align 8
  %op6050 = sub i64 %v6049, 24
  store i64 %op6050, ptr %slot988, align 8
  %v6051 = load i64, ptr %slot977, align 8
  %p6052 = inttoptr i64 %v6051 to ptr
  %rgep6053 = getelementptr i8, ptr %p6052, i64 -24
  %ld6054 = load i64, ptr %rgep6053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6054, ptr %slot989, align 8
  %v6055 = load i64, ptr %slot989, align 8
  %op6056 = add i64 %v6055, 1
  store i64 %op6056, ptr %slot990, align 8
  %v6057 = load i64, ptr %slot990, align 8
  %cmp6058 = icmp eq i64 %v6057, 0
  %cv6059 = zext i1 %cmp6058 to i32
  store i32 %cv6059, ptr %slot991, align 8
  %v6060 = load i32, ptr %slot991, align 8
  %cv6061 = zext i32 %v6060 to i64
  %cond6062 = icmp ne i64 %cv6061, 0
  br i1 %cond6062, label %bb_rcglimit1183, label %bb_rcgcapacity1183
bb_rcglimit1183:
  %v6063 = load i64, ptr %slot1, align 8
  %p6064 = inttoptr i64 %v6063 to ptr
  %call6065 = call i32 @myl_qbe_rc_status(ptr %p6064, i32 2) nomerge, !dbg !160
  store i32 %call6065, ptr %slot992, align 8
  br label %bb_failure
bb_rcgcapacity1183:
  %v6066 = load i64, ptr %slot990, align 8
  %v6067 = load i64, ptr %slot977, align 8
  %p6068 = inttoptr i64 %v6067 to ptr
  %rgep6069 = getelementptr i8, ptr %p6068, i64 -24
  store i64 %v6066, ptr %rgep6069, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1183
bb_rcgstore1183:
  %v6070 = load i64, ptr %slot977, align 8
  %v6071 = load i64, ptr %slot982, align 8
  %p6072 = inttoptr i64 %v6071 to ptr
  store i64 %v6070, ptr %p6072, align 8, !alias.scope !3, !noalias !4
  %v6073 = load i64, ptr %slot22, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  store i32 2, ptr %p6074, align 4, !alias.scope !3, !noalias !4
  %v6075 = load i64, ptr %slot22, align 8
  %p6076 = inttoptr i64 %v6075 to ptr
  store i32 8, ptr %p6076, align 4, !alias.scope !3, !noalias !4
  %v6077 = load i64, ptr %slot21, align 8
  %p6078 = inttoptr i64 %v6077 to ptr
  store i32 1, ptr %p6078, align 4, !alias.scope !3, !noalias !4
  %v6079 = load i64, ptr %slot24, align 8
  store i64 %v6079, ptr %slot993, align 8
  %v6080 = load i64, ptr %slot28, align 8
  store i64 %v6080, ptr %slot994, align 8
  %v6081 = load i64, ptr %slot994, align 8
  %p6082 = inttoptr i64 %v6081 to ptr
  %ld6083 = load i64, ptr %p6082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6083, ptr %slot995, align 8
  %v6084 = load i64, ptr %slot995, align 8
  %v6085 = load i64, ptr %slot993, align 8
  %p6086 = inttoptr i64 %v6085 to ptr
  store i64 %v6084, ptr %p6086, align 8, !alias.scope !3, !noalias !4
  %v6087 = load i64, ptr %slot18, align 8
  %p6088 = inttoptr i64 %v6087 to ptr
  store i32 2, ptr %p6088, align 4, !alias.scope !3, !noalias !4
  %v6089 = load i64, ptr %slot18, align 8
  %p6090 = inttoptr i64 %v6089 to ptr
  store i32 8, ptr %p6090, align 4, !alias.scope !3, !noalias !4
  %v6091 = load i64, ptr %slot17, align 8
  %p6092 = inttoptr i64 %v6091 to ptr
  store i32 1, ptr %p6092, align 4, !alias.scope !3, !noalias !4
  %v6093 = load i64, ptr %slot21, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  store i32 0, ptr %p6094, align 4, !alias.scope !3, !noalias !4
  %v6095 = load i64, ptr %slot995, align 8
  %v6096 = load i64, ptr %slot50, align 8
  %p6097 = inttoptr i64 %v6096 to ptr
  store i64 %v6095, ptr %p6097, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1173
bb_rcordinary1173:
  %v6098 = load i64, ptr %slot977, align 8
  %v6099 = load i64, ptr %slot50, align 8
  %p6100 = inttoptr i64 %v6099 to ptr
  store i64 %v6098, ptr %p6100, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1173
bb_rcholdjoined1173:
  %v6101 = load i64, ptr %slot18, align 8
  %p6102 = inttoptr i64 %v6101 to ptr
  %ld6103 = load i32, ptr %p6102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6103, ptr %slot996, align 8
  %v6104 = load i32, ptr %slot996, align 8
  %cmp6105 = icmp eq i32 %v6104, 8
  %cv6106 = zext i1 %cmp6105 to i32
  store i32 %cv6106, ptr %slot997, align 8
  %v6107 = load i64, ptr %slot17, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %ld6109 = load i32, ptr %p6108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6109, ptr %slot998, align 8
  %v6110 = load i32, ptr %slot997, align 8
  %v6111 = load i32, ptr %slot998, align 8
  %op6112 = and i32 %v6110, %v6111
  store i32 %op6112, ptr %slot999, align 8
  %v6113 = load i32, ptr %slot999, align 8
  %cv6114 = zext i32 %v6113 to i64
  %cond6115 = icmp ne i64 %cv6114, 0
  br i1 %cond6115, label %bb_rchold1204, label %bb_rcordinary1204
bb_rchold1204:
  %v6116 = load i64, ptr %slot28, align 8
  store i64 %v6116, ptr %slot1000, align 8
  %v6117 = load i64, ptr %slot50, align 8
  %p6118 = inttoptr i64 %v6117 to ptr
  %ld6119 = load i64, ptr %p6118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6119, ptr %slot1001, align 8
  %v6120 = load i64, ptr %slot1001, align 8
  %v6121 = load i64, ptr %slot1000, align 8
  %p6122 = inttoptr i64 %v6121 to ptr
  store i64 %v6120, ptr %p6122, align 8, !alias.scope !3, !noalias !4
  %v6123 = load i64, ptr %slot22, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  store i32 2, ptr %p6124, align 4, !alias.scope !3, !noalias !4
  %v6125 = load i64, ptr %slot22, align 8
  %p6126 = inttoptr i64 %v6125 to ptr
  store i32 8, ptr %p6126, align 4, !alias.scope !3, !noalias !4
  %v6127 = load i64, ptr %slot21, align 8
  %p6128 = inttoptr i64 %v6127 to ptr
  store i32 1, ptr %p6128, align 4, !alias.scope !3, !noalias !4
  %v6129 = load i64, ptr %slot17, align 8
  %p6130 = inttoptr i64 %v6129 to ptr
  store i32 0, ptr %p6130, align 4, !alias.scope !3, !noalias !4
  %v6131 = load i64, ptr %slot15, align 8
  %p6132 = inttoptr i64 %v6131 to ptr
  %ld6133 = load i32, ptr %p6132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6133, ptr %slot1002, align 8
  %v6134 = load i32, ptr %slot1002, align 8
  %cv6135 = zext i32 %v6134 to i64
  %cond6136 = icmp ne i64 %cv6135, 0
  br i1 %cond6136, label %bb_rcslotdrop1219, label %bb_rcslotdone1219
bb_rcslotdrop1219:
  %v6137 = load i64, ptr %slot15, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  store i32 0, ptr %p6138, align 4, !alias.scope !3, !noalias !4
  %v6139 = load i64, ptr %slot49, align 8
  store i64 %v6139, ptr %slot1003, align 8
  %v6140 = load i64, ptr %slot16, align 8
  %p6141 = inttoptr i64 %v6140 to ptr
  %ld6142 = load i32, ptr %p6141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6142, ptr %slot1004, align 8
  %v6143 = load i32, ptr %slot1004, align 8
  %op6144 = and i32 %v6143, 28
  store i32 %op6144, ptr %slot1005, align 8
  %v6145 = load i32, ptr %slot1005, align 8
  %cv6146 = zext i32 %v6145 to i64
  %cond6147 = icmp ne i64 %cv6146, 0
  br i1 %cond6147, label %bb_rcslotrole1219, label %bb_rcslotowner1219
bb_rcslotrole1219:
  %v6148 = load i64, ptr %slot59, align 8
  store i64 %v6148, ptr %slot1006, align 8
  %v6149 = load i64, ptr %slot1003, align 8
  %p6150 = inttoptr i64 %v6149 to ptr
  %ld6151 = load i64, ptr %p6150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6151, ptr %slot1007, align 8
  %v6152 = load i64, ptr %slot1007, align 8
  %cmp6153 = icmp ne i64 %v6152, 0
  %cv6154 = zext i1 %cmp6153 to i32
  store i32 %cv6154, ptr %slot1008, align 8
  %v6155 = load i32, ptr %slot1008, align 8
  %cv6156 = zext i32 %v6155 to i64
  %cond6157 = icmp ne i64 %cv6156, 0
  br i1 %cond6157, label %bb_rcgnn1235, label %bb_rcgdone1235
bb_rcgnn1235:
  %v6158 = load i64, ptr %slot1007, align 8
  %op6159 = sub i64 %v6158, 16
  store i64 %op6159, ptr %slot1009, align 8
  %v6160 = load i64, ptr %slot1007, align 8
  %p6161 = inttoptr i64 %v6160 to ptr
  %rgep6162 = getelementptr i8, ptr %p6161, i64 -16
  %ld6163 = load i64, ptr %rgep6162, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6163, ptr %slot1010, align 8
  %v6164 = load i64, ptr %slot1010, align 8
  %op6165 = and i64 %v6164, 4611686018427387906
  store i64 %op6165, ptr %slot1011, align 8
  %v6166 = load i64, ptr %slot1011, align 8
  %cmp6167 = icmp ne i64 %v6166, 0
  %cv6168 = zext i1 %cmp6167 to i32
  store i32 %cv6168, ptr %slot1012, align 8
  %v6169 = load i32, ptr %slot1012, align 8
  %cv6170 = zext i32 %v6169 to i64
  %cond6171 = icmp ne i64 %cv6170, 0
  br i1 %cond6171, label %bb_rcgclear1235, label %bb_rcgcounted1235
bb_rcgcounted1235:
  %v6172 = load i64, ptr %slot1007, align 8
  %op6173 = sub i64 %v6172, 24
  store i64 %op6173, ptr %slot1013, align 8
  %v6174 = load i64, ptr %slot1007, align 8
  %p6175 = inttoptr i64 %v6174 to ptr
  %rgep6176 = getelementptr i8, ptr %p6175, i64 -24
  %ld6177 = load i64, ptr %rgep6176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6177, ptr %slot1014, align 8
  %v6178 = load i64, ptr %slot1014, align 8
  %op6179 = sub i64 %v6178, 1
  store i64 %op6179, ptr %slot1015, align 8
  %v6180 = load i64, ptr %slot1015, align 8
  %cmp6181 = icmp eq i64 %v6180, 0
  %cv6182 = zext i1 %cmp6181 to i32
  store i32 %cv6182, ptr %slot1016, align 8
  %v6183 = load i32, ptr %slot1016, align 8
  %cv6184 = zext i32 %v6183 to i64
  %cond6185 = icmp ne i64 %cv6184, 0
  br i1 %cond6185, label %bb_rcglast1235, label %bb_rcgdec1235
bb_rcglast1235:
  %v6186 = load i64, ptr %slot1007, align 8
  %op6187 = sub i64 %v6186, 32
  store i64 %op6187, ptr %slot1017, align 8
  %v6188 = load i64, ptr %slot1007, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %rgep6190 = getelementptr i8, ptr %p6189, i64 -32
  %ld6191 = load i64, ptr %rgep6190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6191, ptr %slot1018, align 8
  %v6192 = load i64, ptr %slot1018, align 8
  %cmp6193 = icmp ne i64 %v6192, 0
  %cv6194 = zext i1 %cmp6193 to i32
  store i32 %cv6194, ptr %slot1019, align 8
  %v6195 = load i32, ptr %slot1019, align 8
  %cv6196 = zext i32 %v6195 to i64
  %cond6197 = icmp ne i64 %cv6196, 0
  br i1 %cond6197, label %bb_rcgdec1235, label %bb_rcgslow1235
bb_rcgslow1235:
  %v6198 = load i64, ptr %slot1006, align 8
  %v6199 = load i64, ptr %slot1003, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v6198, i64 %v6199) nomerge, !dbg !162
  br label %bb_rcgdone1235
bb_rcgdec1235:
  %v6200 = load i64, ptr %slot1015, align 8
  %v6201 = load i64, ptr %slot1007, align 8
  %p6202 = inttoptr i64 %v6201 to ptr
  %rgep6203 = getelementptr i8, ptr %p6202, i64 -24
  store i64 %v6200, ptr %rgep6203, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1235
bb_rcgclear1235:
  %v6204 = load i64, ptr %slot1003, align 8
  %p6205 = inttoptr i64 %v6204 to ptr
  store i64 0, ptr %p6205, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1235
bb_rcgdone1235:
  br label %bb_rcslotdone1219
bb_rcslotowner1219:
  %v6206 = load i64, ptr %slot59, align 8
  store i64 %v6206, ptr %slot1020, align 8
  %v6207 = load i64, ptr %slot1003, align 8
  %p6208 = inttoptr i64 %v6207 to ptr
  %ld6209 = load i64, ptr %p6208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6209, ptr %slot1021, align 8
  %v6210 = load i64, ptr %slot1021, align 8
  %cmp6211 = icmp ne i64 %v6210, 0
  %cv6212 = zext i1 %cmp6211 to i32
  store i32 %cv6212, ptr %slot1022, align 8
  %v6213 = load i32, ptr %slot1022, align 8
  %cv6214 = zext i32 %v6213 to i64
  %cond6215 = icmp ne i64 %cv6214, 0
  br i1 %cond6215, label %bb_rcgnn1250, label %bb_rcgdone1250
bb_rcgnn1250:
  %v6216 = load i64, ptr %slot1021, align 8
  %op6217 = sub i64 %v6216, 16
  store i64 %op6217, ptr %slot1023, align 8
  %v6218 = load i64, ptr %slot1021, align 8
  %p6219 = inttoptr i64 %v6218 to ptr
  %rgep6220 = getelementptr i8, ptr %p6219, i64 -16
  %ld6221 = load i64, ptr %rgep6220, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6221, ptr %slot1024, align 8
  %v6222 = load i64, ptr %slot1024, align 8
  %op6223 = and i64 %v6222, 4611686018427387906
  store i64 %op6223, ptr %slot1025, align 8
  %v6224 = load i64, ptr %slot1025, align 8
  %cmp6225 = icmp ne i64 %v6224, 0
  %cv6226 = zext i1 %cmp6225 to i32
  store i32 %cv6226, ptr %slot1026, align 8
  %v6227 = load i32, ptr %slot1026, align 8
  %cv6228 = zext i32 %v6227 to i64
  %cond6229 = icmp ne i64 %cv6228, 0
  br i1 %cond6229, label %bb_rcgclear1250, label %bb_rcgcounted1250
bb_rcgcounted1250:
  %v6230 = load i64, ptr %slot1021, align 8
  %op6231 = sub i64 %v6230, 32
  store i64 %op6231, ptr %slot1027, align 8
  %v6232 = load i64, ptr %slot1021, align 8
  %p6233 = inttoptr i64 %v6232 to ptr
  %rgep6234 = getelementptr i8, ptr %p6233, i64 -32
  %ld6235 = load i64, ptr %rgep6234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6235, ptr %slot1028, align 8
  %v6236 = load i64, ptr %slot1028, align 8
  %op6237 = sub i64 %v6236, 1
  store i64 %op6237, ptr %slot1029, align 8
  %v6238 = load i64, ptr %slot1029, align 8
  %cmp6239 = icmp eq i64 %v6238, 0
  %cv6240 = zext i1 %cmp6239 to i32
  store i32 %cv6240, ptr %slot1030, align 8
  %v6241 = load i32, ptr %slot1030, align 8
  %cv6242 = zext i32 %v6241 to i64
  %cond6243 = icmp ne i64 %cv6242, 0
  br i1 %cond6243, label %bb_rcglast1250, label %bb_rcgdec1250
bb_rcglast1250:
  %v6244 = load i64, ptr %slot1021, align 8
  %op6245 = sub i64 %v6244, 24
  store i64 %op6245, ptr %slot1031, align 8
  %v6246 = load i64, ptr %slot1021, align 8
  %p6247 = inttoptr i64 %v6246 to ptr
  %rgep6248 = getelementptr i8, ptr %p6247, i64 -24
  %ld6249 = load i64, ptr %rgep6248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6249, ptr %slot1032, align 8
  %v6250 = load i64, ptr %slot1032, align 8
  %cmp6251 = icmp ne i64 %v6250, 0
  %cv6252 = zext i1 %cmp6251 to i32
  store i32 %cv6252, ptr %slot1033, align 8
  %v6253 = load i32, ptr %slot1033, align 8
  %cv6254 = zext i32 %v6253 to i64
  %cond6255 = icmp ne i64 %cv6254, 0
  br i1 %cond6255, label %bb_rcgdec1250, label %bb_rcgslow1250
bb_rcgslow1250:
  %v6256 = load i64, ptr %slot1020, align 8
  %v6257 = load i64, ptr %slot1003, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6256, i64 %v6257) nomerge, !dbg !162
  br label %bb_rcgdone1250
bb_rcgdec1250:
  %v6258 = load i64, ptr %slot1029, align 8
  %v6259 = load i64, ptr %slot1021, align 8
  %p6260 = inttoptr i64 %v6259 to ptr
  %rgep6261 = getelementptr i8, ptr %p6260, i64 -32
  store i64 %v6258, ptr %rgep6261, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1250
bb_rcgclear1250:
  %v6262 = load i64, ptr %slot1003, align 8
  %p6263 = inttoptr i64 %v6262 to ptr
  store i64 0, ptr %p6263, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1250
bb_rcgdone1250:
  br label %bb_rcslotdone1219
bb_rcslotdone1219:
  %v6264 = load i64, ptr %slot49, align 8
  store i64 %v6264, ptr %slot1034, align 8
  %v6265 = load i64, ptr %slot1000, align 8
  %p6266 = inttoptr i64 %v6265 to ptr
  %ld6267 = load i64, ptr %p6266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6267, ptr %slot1035, align 8
  %v6268 = load i64, ptr %slot1035, align 8
  %v6269 = load i64, ptr %slot1034, align 8
  %p6270 = inttoptr i64 %v6269 to ptr
  store i64 %v6268, ptr %p6270, align 8, !alias.scope !3, !noalias !4
  %v6271 = load i64, ptr %slot16, align 8
  %p6272 = inttoptr i64 %v6271 to ptr
  store i32 2, ptr %p6272, align 4, !alias.scope !3, !noalias !4
  %v6273 = load i64, ptr %slot16, align 8
  %p6274 = inttoptr i64 %v6273 to ptr
  store i32 8, ptr %p6274, align 4, !alias.scope !3, !noalias !4
  %v6275 = load i64, ptr %slot15, align 8
  %p6276 = inttoptr i64 %v6275 to ptr
  store i32 1, ptr %p6276, align 4, !alias.scope !3, !noalias !4
  %v6277 = load i64, ptr %slot21, align 8
  %p6278 = inttoptr i64 %v6277 to ptr
  store i32 0, ptr %p6278, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1204
bb_rcordinary1204:
  %v6279 = load i64, ptr %slot50, align 8
  %p6280 = inttoptr i64 %v6279 to ptr
  %ld6281 = load i64, ptr %p6280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6281, ptr %slot1036, align 8
  %v6282 = load i64, ptr %slot1036, align 8
  %v6283 = load i64, ptr %slot26, align 8
  %p6284 = inttoptr i64 %v6283 to ptr
  store i64 %v6282, ptr %p6284, align 8, !alias.scope !3, !noalias !4
  %v6285 = load i64, ptr %slot26, align 8
  store i64 %v6285, ptr %slot1037, align 8
  %v6286 = load i64, ptr %slot17, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  %ld6288 = load i32, ptr %p6287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6288, ptr %slot1038, align 8
  %v6289 = load i64, ptr %slot18, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %ld6291 = load i32, ptr %p6290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6291, ptr %slot1039, align 8
  %v6292 = load i32, ptr %slot1039, align 8
  %op6293 = and i32 %v6292, 24
  store i32 %op6293, ptr %slot1039, align 8
  %v6294 = load i32, ptr %slot1039, align 8
  %cmp6295 = icmp eq i32 %v6294, 0
  %cv6296 = zext i1 %cmp6295 to i32
  store i32 %cv6296, ptr %slot1040, align 8
  %v6297 = load i32, ptr %slot1038, align 8
  %v6298 = load i32, ptr %slot1040, align 8
  %op6299 = and i32 %v6297, %v6298
  store i32 %op6299, ptr %slot1041, align 8
  %v6300 = load i32, ptr %slot1041, align 8
  %cv6301 = zext i32 %v6300 to i64
  %cond6302 = icmp ne i64 %cv6301, 0
  br i1 %cond6302, label %bb_rcprivateown1268, label %bb_rcprivateloan1268
bb_rcprivateown1268:
  %v6303 = load i64, ptr %slot28, align 8
  store i64 %v6303, ptr %slot1042, align 8
  %v6304 = load i64, ptr %slot60, align 8
  store i64 %v6304, ptr %slot1043, align 8
  %v6305 = load i64, ptr %slot1037, align 8
  %v6306 = load i64, ptr %slot1042, align 8
  %op6307 = sub i64 %v6305, %v6306
  store i64 %op6307, ptr %slot1044, align 8
  %v6308 = load i64, ptr %slot1042, align 8
  %v6309 = load i64, ptr %slot1037, align 8
  %op6310 = sub i64 %v6308, %v6309
  store i64 %op6310, ptr %slot1045, align 8
  %v6311 = load i64, ptr %slot1044, align 8
  %cmp6312 = icmp ult i64 %v6311, 8
  %cv6313 = zext i1 %cmp6312 to i32
  store i32 %cv6313, ptr %slot1046, align 8
  %v6314 = load i64, ptr %slot1045, align 8
  %cmp6315 = icmp ult i64 %v6314, 8
  %cv6316 = zext i1 %cmp6315 to i32
  store i32 %cv6316, ptr %slot1047, align 8
  %v6317 = load i32, ptr %slot1046, align 8
  %v6318 = load i32, ptr %slot1047, align 8
  %op6319 = or i32 %v6317, %v6318
  store i32 %op6319, ptr %slot1048, align 8
  %v6320 = load i32, ptr %slot1048, align 8
  %cv6321 = zext i32 %v6320 to i64
  %cond6322 = icmp ne i64 %cv6321, 0
  br i1 %cond6322, label %bb_rcmoveslow1271, label %bb_rcmovecheck1271
bb_rcmovecheck1271:
  %v6323 = load i64, ptr %slot1037, align 8
  %p6325 = inttoptr i64 %v6323 to ptr
  %gep6326 = getelementptr i8, ptr %p6325, i64 0
  %op6324 = ptrtoint ptr %gep6326 to i64
  store i64 %op6324, ptr %slot1049, align 8
  %v6327 = load i64, ptr %slot1049, align 8
  %p6328 = inttoptr i64 %v6327 to ptr
  %ld6329 = load i64, ptr %p6328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6329, ptr %slot1050, align 8
  %v6330 = load i64, ptr %slot1050, align 8
  %cmp6331 = icmp ne i64 %v6330, 0
  %cv6332 = zext i1 %cmp6331 to i32
  store i32 %cv6332, ptr %slot1051, align 8
  %v6333 = load i32, ptr %slot1051, align 8
  %cv6334 = zext i32 %v6333 to i64
  %cond6335 = icmp ne i64 %cv6334, 0
  br i1 %cond6335, label %bb_rcmoveheader1279, label %bb_rcmovenext1279
bb_rcmoveheader1279:
  %v6336 = load i64, ptr %slot1050, align 8
  %op6337 = sub i64 %v6336, 16
  store i64 %op6337, ptr %slot1052, align 8
  %v6338 = load i64, ptr %slot1050, align 8
  %p6339 = inttoptr i64 %v6338 to ptr
  %rgep6340 = getelementptr i8, ptr %p6339, i64 -16
  %ld6341 = load i64, ptr %rgep6340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6341, ptr %slot1053, align 8
  %v6342 = load i64, ptr %slot1053, align 8
  %op6343 = and i64 %v6342, 5764607523034234881
  store i64 %op6343, ptr %slot1054, align 8
  %v6344 = load i64, ptr %slot1054, align 8
  %cmp6345 = icmp ne i64 %v6344, 0
  %cv6346 = zext i1 %cmp6345 to i32
  store i32 %cv6346, ptr %slot1055, align 8
  %v6347 = load i32, ptr %slot1055, align 8
  %cv6348 = zext i32 %v6347 to i64
  %cond6349 = icmp ne i64 %cv6348, 0
  br i1 %cond6349, label %bb_rcmoveslow1271, label %bb_rcmovenext1279
bb_rcmovenext1279:
  %v6350 = load i64, ptr %slot1037, align 8
  %v6351 = load i64, ptr %slot1042, align 8
  %p6352 = inttoptr i64 %v6350 to ptr
  %p6353 = inttoptr i64 %v6351 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6353, ptr %p6352, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6354 = load i64, ptr %slot1037, align 8
  %p6355 = inttoptr i64 %v6354 to ptr
  store i64 0, ptr %p6355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1271
bb_rcmoveslow1271:
  %v6356 = load i64, ptr %slot59, align 8
  %v6357 = load i64, ptr %slot1042, align 8
  %v6358 = load i64, ptr %slot1037, align 8
  %v6359 = load i64, ptr %slot1043, align 8
  %cv6360 = trunc i64 %v6359 to i32
  %call6361 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v6356, i64 %v6357, i64 %v6358, i32 %cv6360) nomerge, !dbg !162
  store i32 %call6361, ptr %slot1056, align 8
  %v6362 = load i32, ptr %slot1056, align 8
  %cv6363 = zext i32 %v6362 to i64
  %cond6364 = icmp ne i64 %cv6363, 0
  br i1 %cond6364, label %bb_rcsuccess1286, label %bb_rcfailure1286
bb_rcfailure1286:
  %v6365 = load i64, ptr %slot59, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  %call6367 = call i32 @myl_rc_take_failure(ptr %p6366) nomerge, !dbg !162
  store i32 %call6367, ptr %slot1057, align 8
  %v6368 = load i64, ptr %slot1, align 8
  %p6369 = inttoptr i64 %v6368 to ptr
  %v6370 = load i32, ptr %slot1057, align 8
  %call6371 = call i32 @myl_qbe_rc_status(ptr %p6369, i32 %v6370) nomerge, !dbg !162
  store i32 %call6371, ptr %slot1058, align 8
  br label %bb_failure
bb_rcsuccess1286:
  br label %bb_rcmoved1271
bb_rcmoved1271:
  %v6372 = load i64, ptr %slot17, align 8
  %p6373 = inttoptr i64 %v6372 to ptr
  store i32 0, ptr %p6373, align 4, !alias.scope !3, !noalias !4
  %v6374 = load i64, ptr %slot22, align 8
  %p6375 = inttoptr i64 %v6374 to ptr
  store i32 2, ptr %p6375, align 4, !alias.scope !3, !noalias !4
  %v6376 = load i64, ptr %slot21, align 8
  %p6377 = inttoptr i64 %v6376 to ptr
  store i32 1, ptr %p6377, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1268
bb_rcprivateloan1268:
  %v6378 = load i64, ptr %slot28, align 8
  store i64 %v6378, ptr %slot1059, align 8
  %v6379 = load i64, ptr %slot1037, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  %ld6381 = load i64, ptr %p6380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6381, ptr %slot1060, align 8
  %v6382 = load i64, ptr %slot1060, align 8
  %cmp6383 = icmp ne i64 %v6382, 0
  %cv6384 = zext i1 %cmp6383 to i32
  store i32 %cv6384, ptr %slot1061, align 8
  %v6385 = load i32, ptr %slot1061, align 8
  %cv6386 = zext i32 %v6385 to i64
  %cond6387 = icmp ne i64 %cv6386, 0
  br i1 %cond6387, label %bb_rcgnn1294, label %bb_rcgstore1294
bb_rcgnn1294:
  %v6388 = load i64, ptr %slot1060, align 8
  %op6389 = sub i64 %v6388, 16
  store i64 %op6389, ptr %slot1062, align 8
  %v6390 = load i64, ptr %slot1060, align 8
  %p6391 = inttoptr i64 %v6390 to ptr
  %rgep6392 = getelementptr i8, ptr %p6391, i64 -16
  %ld6393 = load i64, ptr %rgep6392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6393, ptr %slot1063, align 8
  %v6394 = load i64, ptr %slot1063, align 8
  %op6395 = and i64 %v6394, 4611686018427387906
  store i64 %op6395, ptr %slot1064, align 8
  %v6396 = load i64, ptr %slot1064, align 8
  %cmp6397 = icmp ne i64 %v6396, 0
  %cv6398 = zext i1 %cmp6397 to i32
  store i32 %cv6398, ptr %slot1065, align 8
  %v6399 = load i32, ptr %slot1065, align 8
  %cv6400 = zext i32 %v6399 to i64
  %cond6401 = icmp ne i64 %cv6400, 0
  br i1 %cond6401, label %bb_rcgstore1294, label %bb_rcginc1294
bb_rcginc1294:
  %v6402 = load i64, ptr %slot1060, align 8
  %op6403 = sub i64 %v6402, 24
  store i64 %op6403, ptr %slot1066, align 8
  %v6404 = load i64, ptr %slot1060, align 8
  %p6405 = inttoptr i64 %v6404 to ptr
  %rgep6406 = getelementptr i8, ptr %p6405, i64 -24
  %ld6407 = load i64, ptr %rgep6406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6407, ptr %slot1067, align 8
  %v6408 = load i64, ptr %slot1067, align 8
  %op6409 = add i64 %v6408, 1
  store i64 %op6409, ptr %slot1068, align 8
  %v6410 = load i64, ptr %slot1068, align 8
  %cmp6411 = icmp eq i64 %v6410, 0
  %cv6412 = zext i1 %cmp6411 to i32
  store i32 %cv6412, ptr %slot1069, align 8
  %v6413 = load i32, ptr %slot1069, align 8
  %cv6414 = zext i32 %v6413 to i64
  %cond6415 = icmp ne i64 %cv6414, 0
  br i1 %cond6415, label %bb_rcglimit1294, label %bb_rcgcapacity1294
bb_rcglimit1294:
  %v6416 = load i64, ptr %slot1, align 8
  %p6417 = inttoptr i64 %v6416 to ptr
  %call6418 = call i32 @myl_qbe_rc_status(ptr %p6417, i32 2) nomerge, !dbg !162
  store i32 %call6418, ptr %slot1070, align 8
  br label %bb_failure
bb_rcgcapacity1294:
  %v6419 = load i64, ptr %slot1068, align 8
  %v6420 = load i64, ptr %slot1060, align 8
  %p6421 = inttoptr i64 %v6420 to ptr
  %rgep6422 = getelementptr i8, ptr %p6421, i64 -24
  store i64 %v6419, ptr %rgep6422, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1294
bb_rcgstore1294:
  %v6423 = load i64, ptr %slot1060, align 8
  %v6424 = load i64, ptr %slot1059, align 8
  %p6425 = inttoptr i64 %v6424 to ptr
  store i64 %v6423, ptr %p6425, align 8, !alias.scope !3, !noalias !4
  %v6426 = load i64, ptr %slot22, align 8
  %p6427 = inttoptr i64 %v6426 to ptr
  store i32 2, ptr %p6427, align 4, !alias.scope !3, !noalias !4
  %v6428 = load i64, ptr %slot22, align 8
  %p6429 = inttoptr i64 %v6428 to ptr
  store i32 16, ptr %p6429, align 4, !alias.scope !3, !noalias !4
  %v6430 = load i64, ptr %slot21, align 8
  %p6431 = inttoptr i64 %v6430 to ptr
  store i32 1, ptr %p6431, align 4, !alias.scope !3, !noalias !4
  %v6432 = load i64, ptr %slot17, align 8
  %p6433 = inttoptr i64 %v6432 to ptr
  %ld6434 = load i32, ptr %p6433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6434, ptr %slot1071, align 8
  %v6435 = load i32, ptr %slot1071, align 8
  %cv6436 = zext i32 %v6435 to i64
  %cond6437 = icmp ne i64 %cv6436, 0
  br i1 %cond6437, label %bb_rcslotdrop1310, label %bb_rcslotdone1310
bb_rcslotdrop1310:
  %v6438 = load i64, ptr %slot17, align 8
  %p6439 = inttoptr i64 %v6438 to ptr
  store i32 0, ptr %p6439, align 4, !alias.scope !3, !noalias !4
  %v6440 = load i64, ptr %slot24, align 8
  store i64 %v6440, ptr %slot1072, align 8
  %v6441 = load i64, ptr %slot18, align 8
  %p6442 = inttoptr i64 %v6441 to ptr
  %ld6443 = load i32, ptr %p6442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6443, ptr %slot1073, align 8
  %v6444 = load i32, ptr %slot1073, align 8
  %op6445 = and i32 %v6444, 28
  store i32 %op6445, ptr %slot1074, align 8
  %v6446 = load i32, ptr %slot1074, align 8
  %cv6447 = zext i32 %v6446 to i64
  %cond6448 = icmp ne i64 %cv6447, 0
  br i1 %cond6448, label %bb_rcslotrole1310, label %bb_rcslotowner1310
bb_rcslotrole1310:
  %v6449 = load i64, ptr %slot59, align 8
  store i64 %v6449, ptr %slot1075, align 8
  %v6450 = load i64, ptr %slot1072, align 8
  %p6451 = inttoptr i64 %v6450 to ptr
  %ld6452 = load i64, ptr %p6451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6452, ptr %slot1076, align 8
  %v6453 = load i64, ptr %slot1076, align 8
  %cmp6454 = icmp ne i64 %v6453, 0
  %cv6455 = zext i1 %cmp6454 to i32
  store i32 %cv6455, ptr %slot1077, align 8
  %v6456 = load i32, ptr %slot1077, align 8
  %cv6457 = zext i32 %v6456 to i64
  %cond6458 = icmp ne i64 %cv6457, 0
  br i1 %cond6458, label %bb_rcgnn1326, label %bb_rcgdone1326
bb_rcgnn1326:
  %v6459 = load i64, ptr %slot1076, align 8
  %op6460 = sub i64 %v6459, 16
  store i64 %op6460, ptr %slot1078, align 8
  %v6461 = load i64, ptr %slot1076, align 8
  %p6462 = inttoptr i64 %v6461 to ptr
  %rgep6463 = getelementptr i8, ptr %p6462, i64 -16
  %ld6464 = load i64, ptr %rgep6463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6464, ptr %slot1079, align 8
  %v6465 = load i64, ptr %slot1079, align 8
  %op6466 = and i64 %v6465, 4611686018427387906
  store i64 %op6466, ptr %slot1080, align 8
  %v6467 = load i64, ptr %slot1080, align 8
  %cmp6468 = icmp ne i64 %v6467, 0
  %cv6469 = zext i1 %cmp6468 to i32
  store i32 %cv6469, ptr %slot1081, align 8
  %v6470 = load i32, ptr %slot1081, align 8
  %cv6471 = zext i32 %v6470 to i64
  %cond6472 = icmp ne i64 %cv6471, 0
  br i1 %cond6472, label %bb_rcgclear1326, label %bb_rcgcounted1326
bb_rcgcounted1326:
  %v6473 = load i64, ptr %slot1076, align 8
  %op6474 = sub i64 %v6473, 24
  store i64 %op6474, ptr %slot1082, align 8
  %v6475 = load i64, ptr %slot1076, align 8
  %p6476 = inttoptr i64 %v6475 to ptr
  %rgep6477 = getelementptr i8, ptr %p6476, i64 -24
  %ld6478 = load i64, ptr %rgep6477, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6478, ptr %slot1083, align 8
  %v6479 = load i64, ptr %slot1083, align 8
  %op6480 = sub i64 %v6479, 1
  store i64 %op6480, ptr %slot1084, align 8
  %v6481 = load i64, ptr %slot1084, align 8
  %cmp6482 = icmp eq i64 %v6481, 0
  %cv6483 = zext i1 %cmp6482 to i32
  store i32 %cv6483, ptr %slot1085, align 8
  %v6484 = load i32, ptr %slot1085, align 8
  %cv6485 = zext i32 %v6484 to i64
  %cond6486 = icmp ne i64 %cv6485, 0
  br i1 %cond6486, label %bb_rcglast1326, label %bb_rcgdec1326
bb_rcglast1326:
  %v6487 = load i64, ptr %slot1076, align 8
  %op6488 = sub i64 %v6487, 32
  store i64 %op6488, ptr %slot1086, align 8
  %v6489 = load i64, ptr %slot1076, align 8
  %p6490 = inttoptr i64 %v6489 to ptr
  %rgep6491 = getelementptr i8, ptr %p6490, i64 -32
  %ld6492 = load i64, ptr %rgep6491, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6492, ptr %slot1087, align 8
  %v6493 = load i64, ptr %slot1087, align 8
  %cmp6494 = icmp ne i64 %v6493, 0
  %cv6495 = zext i1 %cmp6494 to i32
  store i32 %cv6495, ptr %slot1088, align 8
  %v6496 = load i32, ptr %slot1088, align 8
  %cv6497 = zext i32 %v6496 to i64
  %cond6498 = icmp ne i64 %cv6497, 0
  br i1 %cond6498, label %bb_rcgdec1326, label %bb_rcgslow1326
bb_rcgslow1326:
  %v6499 = load i64, ptr %slot1075, align 8
  %v6500 = load i64, ptr %slot1072, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v6499, i64 %v6500) nomerge, !dbg !162
  br label %bb_rcgdone1326
bb_rcgdec1326:
  %v6501 = load i64, ptr %slot1084, align 8
  %v6502 = load i64, ptr %slot1076, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  %rgep6504 = getelementptr i8, ptr %p6503, i64 -24
  store i64 %v6501, ptr %rgep6504, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1326
bb_rcgclear1326:
  %v6505 = load i64, ptr %slot1072, align 8
  %p6506 = inttoptr i64 %v6505 to ptr
  store i64 0, ptr %p6506, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1326
bb_rcgdone1326:
  br label %bb_rcslotdone1310
bb_rcslotowner1310:
  %v6507 = load i64, ptr %slot59, align 8
  store i64 %v6507, ptr %slot1089, align 8
  %v6508 = load i64, ptr %slot1072, align 8
  %p6509 = inttoptr i64 %v6508 to ptr
  %ld6510 = load i64, ptr %p6509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6510, ptr %slot1090, align 8
  %v6511 = load i64, ptr %slot1090, align 8
  %cmp6512 = icmp ne i64 %v6511, 0
  %cv6513 = zext i1 %cmp6512 to i32
  store i32 %cv6513, ptr %slot1091, align 8
  %v6514 = load i32, ptr %slot1091, align 8
  %cv6515 = zext i32 %v6514 to i64
  %cond6516 = icmp ne i64 %cv6515, 0
  br i1 %cond6516, label %bb_rcgnn1341, label %bb_rcgdone1341
bb_rcgnn1341:
  %v6517 = load i64, ptr %slot1090, align 8
  %op6518 = sub i64 %v6517, 16
  store i64 %op6518, ptr %slot1092, align 8
  %v6519 = load i64, ptr %slot1090, align 8
  %p6520 = inttoptr i64 %v6519 to ptr
  %rgep6521 = getelementptr i8, ptr %p6520, i64 -16
  %ld6522 = load i64, ptr %rgep6521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6522, ptr %slot1093, align 8
  %v6523 = load i64, ptr %slot1093, align 8
  %op6524 = and i64 %v6523, 4611686018427387906
  store i64 %op6524, ptr %slot1094, align 8
  %v6525 = load i64, ptr %slot1094, align 8
  %cmp6526 = icmp ne i64 %v6525, 0
  %cv6527 = zext i1 %cmp6526 to i32
  store i32 %cv6527, ptr %slot1095, align 8
  %v6528 = load i32, ptr %slot1095, align 8
  %cv6529 = zext i32 %v6528 to i64
  %cond6530 = icmp ne i64 %cv6529, 0
  br i1 %cond6530, label %bb_rcgclear1341, label %bb_rcgcounted1341
bb_rcgcounted1341:
  %v6531 = load i64, ptr %slot1090, align 8
  %op6532 = sub i64 %v6531, 32
  store i64 %op6532, ptr %slot1096, align 8
  %v6533 = load i64, ptr %slot1090, align 8
  %p6534 = inttoptr i64 %v6533 to ptr
  %rgep6535 = getelementptr i8, ptr %p6534, i64 -32
  %ld6536 = load i64, ptr %rgep6535, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6536, ptr %slot1097, align 8
  %v6537 = load i64, ptr %slot1097, align 8
  %op6538 = sub i64 %v6537, 1
  store i64 %op6538, ptr %slot1098, align 8
  %v6539 = load i64, ptr %slot1098, align 8
  %cmp6540 = icmp eq i64 %v6539, 0
  %cv6541 = zext i1 %cmp6540 to i32
  store i32 %cv6541, ptr %slot1099, align 8
  %v6542 = load i32, ptr %slot1099, align 8
  %cv6543 = zext i32 %v6542 to i64
  %cond6544 = icmp ne i64 %cv6543, 0
  br i1 %cond6544, label %bb_rcglast1341, label %bb_rcgdec1341
bb_rcglast1341:
  %v6545 = load i64, ptr %slot1090, align 8
  %op6546 = sub i64 %v6545, 24
  store i64 %op6546, ptr %slot1100, align 8
  %v6547 = load i64, ptr %slot1090, align 8
  %p6548 = inttoptr i64 %v6547 to ptr
  %rgep6549 = getelementptr i8, ptr %p6548, i64 -24
  %ld6550 = load i64, ptr %rgep6549, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6550, ptr %slot1101, align 8
  %v6551 = load i64, ptr %slot1101, align 8
  %cmp6552 = icmp ne i64 %v6551, 0
  %cv6553 = zext i1 %cmp6552 to i32
  store i32 %cv6553, ptr %slot1102, align 8
  %v6554 = load i32, ptr %slot1102, align 8
  %cv6555 = zext i32 %v6554 to i64
  %cond6556 = icmp ne i64 %cv6555, 0
  br i1 %cond6556, label %bb_rcgdec1341, label %bb_rcgslow1341
bb_rcgslow1341:
  %v6557 = load i64, ptr %slot1089, align 8
  %v6558 = load i64, ptr %slot1072, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6557, i64 %v6558) nomerge, !dbg !162
  br label %bb_rcgdone1341
bb_rcgdec1341:
  %v6559 = load i64, ptr %slot1098, align 8
  %v6560 = load i64, ptr %slot1090, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  %rgep6562 = getelementptr i8, ptr %p6561, i64 -32
  store i64 %v6559, ptr %rgep6562, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1341
bb_rcgclear1341:
  %v6563 = load i64, ptr %slot1072, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  store i64 0, ptr %p6564, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1341
bb_rcgdone1341:
  br label %bb_rcslotdone1310
bb_rcslotdone1310:
  br label %bb_rcprivateprepared1268
bb_rcprivateprepared1268:
  %v6565 = load i64, ptr %slot15, align 8
  %p6566 = inttoptr i64 %v6565 to ptr
  %ld6567 = load i32, ptr %p6566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6567, ptr %slot1103, align 8
  %v6568 = load i32, ptr %slot1103, align 8
  %cv6569 = zext i32 %v6568 to i64
  %cond6570 = icmp ne i64 %cv6569, 0
  br i1 %cond6570, label %bb_rcslotdrop1348, label %bb_rcslotdone1348
bb_rcslotdrop1348:
  %v6571 = load i64, ptr %slot15, align 8
  %p6572 = inttoptr i64 %v6571 to ptr
  store i32 0, ptr %p6572, align 4, !alias.scope !3, !noalias !4
  %v6573 = load i64, ptr %slot49, align 8
  store i64 %v6573, ptr %slot1104, align 8
  %v6574 = load i64, ptr %slot16, align 8
  %p6575 = inttoptr i64 %v6574 to ptr
  %ld6576 = load i32, ptr %p6575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6576, ptr %slot1105, align 8
  %v6577 = load i32, ptr %slot1105, align 8
  %op6578 = and i32 %v6577, 28
  store i32 %op6578, ptr %slot1106, align 8
  %v6579 = load i32, ptr %slot1106, align 8
  %cv6580 = zext i32 %v6579 to i64
  %cond6581 = icmp ne i64 %cv6580, 0
  br i1 %cond6581, label %bb_rcslotrole1348, label %bb_rcslotowner1348
bb_rcslotrole1348:
  %v6582 = load i64, ptr %slot59, align 8
  store i64 %v6582, ptr %slot1107, align 8
  %v6583 = load i64, ptr %slot1104, align 8
  %p6584 = inttoptr i64 %v6583 to ptr
  %ld6585 = load i64, ptr %p6584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6585, ptr %slot1108, align 8
  %v6586 = load i64, ptr %slot1108, align 8
  %cmp6587 = icmp ne i64 %v6586, 0
  %cv6588 = zext i1 %cmp6587 to i32
  store i32 %cv6588, ptr %slot1109, align 8
  %v6589 = load i32, ptr %slot1109, align 8
  %cv6590 = zext i32 %v6589 to i64
  %cond6591 = icmp ne i64 %cv6590, 0
  br i1 %cond6591, label %bb_rcgnn1364, label %bb_rcgdone1364
bb_rcgnn1364:
  %v6592 = load i64, ptr %slot1108, align 8
  %op6593 = sub i64 %v6592, 16
  store i64 %op6593, ptr %slot1110, align 8
  %v6594 = load i64, ptr %slot1108, align 8
  %p6595 = inttoptr i64 %v6594 to ptr
  %rgep6596 = getelementptr i8, ptr %p6595, i64 -16
  %ld6597 = load i64, ptr %rgep6596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6597, ptr %slot1111, align 8
  %v6598 = load i64, ptr %slot1111, align 8
  %op6599 = and i64 %v6598, 4611686018427387906
  store i64 %op6599, ptr %slot1112, align 8
  %v6600 = load i64, ptr %slot1112, align 8
  %cmp6601 = icmp ne i64 %v6600, 0
  %cv6602 = zext i1 %cmp6601 to i32
  store i32 %cv6602, ptr %slot1113, align 8
  %v6603 = load i32, ptr %slot1113, align 8
  %cv6604 = zext i32 %v6603 to i64
  %cond6605 = icmp ne i64 %cv6604, 0
  br i1 %cond6605, label %bb_rcgclear1364, label %bb_rcgcounted1364
bb_rcgcounted1364:
  %v6606 = load i64, ptr %slot1108, align 8
  %op6607 = sub i64 %v6606, 24
  store i64 %op6607, ptr %slot1114, align 8
  %v6608 = load i64, ptr %slot1108, align 8
  %p6609 = inttoptr i64 %v6608 to ptr
  %rgep6610 = getelementptr i8, ptr %p6609, i64 -24
  %ld6611 = load i64, ptr %rgep6610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6611, ptr %slot1115, align 8
  %v6612 = load i64, ptr %slot1115, align 8
  %op6613 = sub i64 %v6612, 1
  store i64 %op6613, ptr %slot1116, align 8
  %v6614 = load i64, ptr %slot1116, align 8
  %cmp6615 = icmp eq i64 %v6614, 0
  %cv6616 = zext i1 %cmp6615 to i32
  store i32 %cv6616, ptr %slot1117, align 8
  %v6617 = load i32, ptr %slot1117, align 8
  %cv6618 = zext i32 %v6617 to i64
  %cond6619 = icmp ne i64 %cv6618, 0
  br i1 %cond6619, label %bb_rcglast1364, label %bb_rcgdec1364
bb_rcglast1364:
  %v6620 = load i64, ptr %slot1108, align 8
  %op6621 = sub i64 %v6620, 32
  store i64 %op6621, ptr %slot1118, align 8
  %v6622 = load i64, ptr %slot1108, align 8
  %p6623 = inttoptr i64 %v6622 to ptr
  %rgep6624 = getelementptr i8, ptr %p6623, i64 -32
  %ld6625 = load i64, ptr %rgep6624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6625, ptr %slot1119, align 8
  %v6626 = load i64, ptr %slot1119, align 8
  %cmp6627 = icmp ne i64 %v6626, 0
  %cv6628 = zext i1 %cmp6627 to i32
  store i32 %cv6628, ptr %slot1120, align 8
  %v6629 = load i32, ptr %slot1120, align 8
  %cv6630 = zext i32 %v6629 to i64
  %cond6631 = icmp ne i64 %cv6630, 0
  br i1 %cond6631, label %bb_rcgdec1364, label %bb_rcgslow1364
bb_rcgslow1364:
  %v6632 = load i64, ptr %slot1107, align 8
  %v6633 = load i64, ptr %slot1104, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v6632, i64 %v6633) nomerge, !dbg !162
  br label %bb_rcgdone1364
bb_rcgdec1364:
  %v6634 = load i64, ptr %slot1116, align 8
  %v6635 = load i64, ptr %slot1108, align 8
  %p6636 = inttoptr i64 %v6635 to ptr
  %rgep6637 = getelementptr i8, ptr %p6636, i64 -24
  store i64 %v6634, ptr %rgep6637, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1364
bb_rcgclear1364:
  %v6638 = load i64, ptr %slot1104, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  store i64 0, ptr %p6639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1364
bb_rcgdone1364:
  br label %bb_rcslotdone1348
bb_rcslotowner1348:
  %v6640 = load i64, ptr %slot59, align 8
  store i64 %v6640, ptr %slot1121, align 8
  %v6641 = load i64, ptr %slot1104, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  %ld6643 = load i64, ptr %p6642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6643, ptr %slot1122, align 8
  %v6644 = load i64, ptr %slot1122, align 8
  %cmp6645 = icmp ne i64 %v6644, 0
  %cv6646 = zext i1 %cmp6645 to i32
  store i32 %cv6646, ptr %slot1123, align 8
  %v6647 = load i32, ptr %slot1123, align 8
  %cv6648 = zext i32 %v6647 to i64
  %cond6649 = icmp ne i64 %cv6648, 0
  br i1 %cond6649, label %bb_rcgnn1379, label %bb_rcgdone1379
bb_rcgnn1379:
  %v6650 = load i64, ptr %slot1122, align 8
  %op6651 = sub i64 %v6650, 16
  store i64 %op6651, ptr %slot1124, align 8
  %v6652 = load i64, ptr %slot1122, align 8
  %p6653 = inttoptr i64 %v6652 to ptr
  %rgep6654 = getelementptr i8, ptr %p6653, i64 -16
  %ld6655 = load i64, ptr %rgep6654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6655, ptr %slot1125, align 8
  %v6656 = load i64, ptr %slot1125, align 8
  %op6657 = and i64 %v6656, 4611686018427387906
  store i64 %op6657, ptr %slot1126, align 8
  %v6658 = load i64, ptr %slot1126, align 8
  %cmp6659 = icmp ne i64 %v6658, 0
  %cv6660 = zext i1 %cmp6659 to i32
  store i32 %cv6660, ptr %slot1127, align 8
  %v6661 = load i32, ptr %slot1127, align 8
  %cv6662 = zext i32 %v6661 to i64
  %cond6663 = icmp ne i64 %cv6662, 0
  br i1 %cond6663, label %bb_rcgclear1379, label %bb_rcgcounted1379
bb_rcgcounted1379:
  %v6664 = load i64, ptr %slot1122, align 8
  %op6665 = sub i64 %v6664, 32
  store i64 %op6665, ptr %slot1128, align 8
  %v6666 = load i64, ptr %slot1122, align 8
  %p6667 = inttoptr i64 %v6666 to ptr
  %rgep6668 = getelementptr i8, ptr %p6667, i64 -32
  %ld6669 = load i64, ptr %rgep6668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6669, ptr %slot1129, align 8
  %v6670 = load i64, ptr %slot1129, align 8
  %op6671 = sub i64 %v6670, 1
  store i64 %op6671, ptr %slot1130, align 8
  %v6672 = load i64, ptr %slot1130, align 8
  %cmp6673 = icmp eq i64 %v6672, 0
  %cv6674 = zext i1 %cmp6673 to i32
  store i32 %cv6674, ptr %slot1131, align 8
  %v6675 = load i32, ptr %slot1131, align 8
  %cv6676 = zext i32 %v6675 to i64
  %cond6677 = icmp ne i64 %cv6676, 0
  br i1 %cond6677, label %bb_rcglast1379, label %bb_rcgdec1379
bb_rcglast1379:
  %v6678 = load i64, ptr %slot1122, align 8
  %op6679 = sub i64 %v6678, 24
  store i64 %op6679, ptr %slot1132, align 8
  %v6680 = load i64, ptr %slot1122, align 8
  %p6681 = inttoptr i64 %v6680 to ptr
  %rgep6682 = getelementptr i8, ptr %p6681, i64 -24
  %ld6683 = load i64, ptr %rgep6682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6683, ptr %slot1133, align 8
  %v6684 = load i64, ptr %slot1133, align 8
  %cmp6685 = icmp ne i64 %v6684, 0
  %cv6686 = zext i1 %cmp6685 to i32
  store i32 %cv6686, ptr %slot1134, align 8
  %v6687 = load i32, ptr %slot1134, align 8
  %cv6688 = zext i32 %v6687 to i64
  %cond6689 = icmp ne i64 %cv6688, 0
  br i1 %cond6689, label %bb_rcgdec1379, label %bb_rcgslow1379
bb_rcgslow1379:
  %v6690 = load i64, ptr %slot1121, align 8
  %v6691 = load i64, ptr %slot1104, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6690, i64 %v6691) nomerge, !dbg !162
  br label %bb_rcgdone1379
bb_rcgdec1379:
  %v6692 = load i64, ptr %slot1130, align 8
  %v6693 = load i64, ptr %slot1122, align 8
  %p6694 = inttoptr i64 %v6693 to ptr
  %rgep6695 = getelementptr i8, ptr %p6694, i64 -32
  store i64 %v6692, ptr %rgep6695, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1379
bb_rcgclear1379:
  %v6696 = load i64, ptr %slot1104, align 8
  %p6697 = inttoptr i64 %v6696 to ptr
  store i64 0, ptr %p6697, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1379
bb_rcgdone1379:
  br label %bb_rcslotdone1348
bb_rcslotdone1348:
  %v6698 = load i64, ptr %slot49, align 8
  store i64 %v6698, ptr %slot1135, align 8
  %v6699 = load i64, ptr %slot28, align 8
  store i64 %v6699, ptr %slot1136, align 8
  %v6700 = load i64, ptr %slot1136, align 8
  %v6701 = load i64, ptr %slot1135, align 8
  %p6702 = inttoptr i64 %v6700 to ptr
  %p6703 = inttoptr i64 %v6701 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6703, ptr %p6702, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6704 = load i64, ptr %slot21, align 8
  %p6705 = inttoptr i64 %v6704 to ptr
  store i32 0, ptr %p6705, align 4, !alias.scope !3, !noalias !4
  %v6706 = load i64, ptr %slot16, align 8
  %p6707 = inttoptr i64 %v6706 to ptr
  store i32 2, ptr %p6707, align 4, !alias.scope !3, !noalias !4
  %v6708 = load i64, ptr %slot22, align 8
  %p6709 = inttoptr i64 %v6708 to ptr
  %ld6710 = load i32, ptr %p6709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6710, ptr %slot1137, align 8
  %v6711 = load i32, ptr %slot1137, align 8
  %v6712 = load i64, ptr %slot16, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  store i32 %v6711, ptr %p6713, align 4, !alias.scope !3, !noalias !4
  %v6714 = load i64, ptr %slot15, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  store i32 1, ptr %p6715, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1204
bb_rcholdjoined1204:
  %v6716 = load i64, ptr %slot34, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  %ld6718 = load i64, ptr %p6717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6718, ptr %slot1138, align 8
  %v6719 = load i64, ptr %slot1138, align 8
  %v6720 = load i64, ptr %slot50, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  store i64 %v6719, ptr %p6721, align 8, !alias.scope !3, !noalias !4
  %v6722 = load i64, ptr %slot50, align 8
  %p6723 = inttoptr i64 %v6722 to ptr
  %ld6724 = load i64, ptr %p6723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6724, ptr %slot1139, align 8
  %v6725 = load i64, ptr %slot17, align 8
  %p6726 = inttoptr i64 %v6725 to ptr
  %ld6727 = load i32, ptr %p6726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6727, ptr %slot1140, align 8
  %v6728 = load i64, ptr %slot18, align 8
  %p6729 = inttoptr i64 %v6728 to ptr
  %ld6730 = load i32, ptr %p6729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6730, ptr %slot1141, align 8
  %v6731 = load i32, ptr %slot1141, align 8
  %op6732 = and i32 %v6731, 24
  store i32 %op6732, ptr %slot1141, align 8
  %v6733 = load i32, ptr %slot1141, align 8
  %cmp6734 = icmp eq i32 %v6733, 0
  %cv6735 = zext i1 %cmp6734 to i32
  store i32 %cv6735, ptr %slot1142, align 8
  %v6736 = load i32, ptr %slot1140, align 8
  %v6737 = load i32, ptr %slot1142, align 8
  %op6738 = and i32 %v6736, %v6737
  store i32 %op6738, ptr %slot1143, align 8
  %v6739 = load i32, ptr %slot1143, align 8
  %cv6740 = zext i32 %v6739 to i64
  %cond6741 = icmp ne i64 %cv6740, 0
  br i1 %cond6741, label %bb_rcprivateown1398, label %bb_rcprivateloan1398
bb_rcprivateown1398:
  %v6742 = load i64, ptr %slot28, align 8
  store i64 %v6742, ptr %slot1144, align 8
  %v6743 = load i64, ptr %slot60, align 8
  store i64 %v6743, ptr %slot1145, align 8
  %v6744 = load i64, ptr %slot1139, align 8
  %v6745 = load i64, ptr %slot1144, align 8
  %op6746 = sub i64 %v6744, %v6745
  store i64 %op6746, ptr %slot1146, align 8
  %v6747 = load i64, ptr %slot1144, align 8
  %v6748 = load i64, ptr %slot1139, align 8
  %op6749 = sub i64 %v6747, %v6748
  store i64 %op6749, ptr %slot1147, align 8
  %v6750 = load i64, ptr %slot1146, align 8
  %cmp6751 = icmp ult i64 %v6750, 16
  %cv6752 = zext i1 %cmp6751 to i32
  store i32 %cv6752, ptr %slot1148, align 8
  %v6753 = load i64, ptr %slot1147, align 8
  %cmp6754 = icmp ult i64 %v6753, 16
  %cv6755 = zext i1 %cmp6754 to i32
  store i32 %cv6755, ptr %slot1149, align 8
  %v6756 = load i32, ptr %slot1148, align 8
  %v6757 = load i32, ptr %slot1149, align 8
  %op6758 = or i32 %v6756, %v6757
  store i32 %op6758, ptr %slot1150, align 8
  %v6759 = load i32, ptr %slot1150, align 8
  %cv6760 = zext i32 %v6759 to i64
  %cond6761 = icmp ne i64 %cv6760, 0
  br i1 %cond6761, label %bb_rcmoveslow1401, label %bb_rcmovecheck1401
bb_rcmovecheck1401:
  %v6762 = load i64, ptr %slot1139, align 8
  %op6763 = add i64 %v6762, 0
  store i64 %op6763, ptr %slot1151, align 8
  %v6764 = load i64, ptr %slot1151, align 8
  %p6765 = inttoptr i64 %v6764 to ptr
  %ld6766 = load i64, ptr %p6765, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6766, ptr %slot1152, align 8
  %v6767 = load i64, ptr %slot1152, align 8
  %cmp6768 = icmp ne i64 %v6767, 0
  %cv6769 = zext i1 %cmp6768 to i32
  store i32 %cv6769, ptr %slot1153, align 8
  %v6770 = load i32, ptr %slot1153, align 8
  %cv6771 = zext i32 %v6770 to i64
  %cond6772 = icmp ne i64 %cv6771, 0
  br i1 %cond6772, label %bb_rcmoveheader1409, label %bb_rcmovenext1409
bb_rcmoveheader1409:
  %v6773 = load i64, ptr %slot1152, align 8
  %op6774 = sub i64 %v6773, 16
  store i64 %op6774, ptr %slot1154, align 8
  %v6775 = load i64, ptr %slot1152, align 8
  %p6776 = inttoptr i64 %v6775 to ptr
  %rgep6777 = getelementptr i8, ptr %p6776, i64 -16
  %ld6778 = load i64, ptr %rgep6777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6778, ptr %slot1155, align 8
  %v6779 = load i64, ptr %slot1155, align 8
  %op6780 = and i64 %v6779, 5764607523034234881
  store i64 %op6780, ptr %slot1156, align 8
  %v6781 = load i64, ptr %slot1156, align 8
  %cmp6782 = icmp ne i64 %v6781, 0
  %cv6783 = zext i1 %cmp6782 to i32
  store i32 %cv6783, ptr %slot1157, align 8
  %v6784 = load i32, ptr %slot1157, align 8
  %cv6785 = zext i32 %v6784 to i64
  %cond6786 = icmp ne i64 %cv6785, 0
  br i1 %cond6786, label %bb_rcmoveslow1401, label %bb_rcmovenext1409
bb_rcmovenext1409:
  %v6787 = load i64, ptr %slot1139, align 8
  %v6788 = load i64, ptr %slot1144, align 8
  %p6789 = inttoptr i64 %v6787 to ptr
  %p6790 = inttoptr i64 %v6788 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6790, ptr %p6789, i64 16, i1 false), !alias.scope !10000001
  %v6791 = load i64, ptr %slot1139, align 8
  %p6792 = inttoptr i64 %v6791 to ptr
  store i64 0, ptr %p6792, align 8, !alias.scope !4, !noalias !3
  %v6793 = load i64, ptr %slot1139, align 8
  %op6794 = add i64 %v6793, 8
  store i64 %op6794, ptr %slot1158, align 8
  %v6795 = load i64, ptr %slot1158, align 8
  %p6796 = inttoptr i64 %v6795 to ptr
  store i64 0, ptr %p6796, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1401
bb_rcmoveslow1401:
  %v6797 = load i64, ptr %slot59, align 8
  %v6798 = load i64, ptr %slot1144, align 8
  %v6799 = load i64, ptr %slot1139, align 8
  %v6800 = load i64, ptr %slot1145, align 8
  %cv6801 = trunc i64 %v6800 to i32
  %call6802 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v6797, i64 %v6798, i64 %v6799, i32 %cv6801) nomerge, !dbg !164
  store i32 %call6802, ptr %slot1159, align 8
  %v6803 = load i32, ptr %slot1159, align 8
  %cv6804 = zext i32 %v6803 to i64
  %cond6805 = icmp ne i64 %cv6804, 0
  br i1 %cond6805, label %bb_rcsuccess1417, label %bb_rcfailure1417
bb_rcfailure1417:
  %v6806 = load i64, ptr %slot59, align 8
  %p6807 = inttoptr i64 %v6806 to ptr
  %call6808 = call i32 @myl_rc_take_failure(ptr %p6807) nomerge, !dbg !164
  store i32 %call6808, ptr %slot1160, align 8
  %v6809 = load i64, ptr %slot1, align 8
  %p6810 = inttoptr i64 %v6809 to ptr
  %v6811 = load i32, ptr %slot1160, align 8
  %call6812 = call i32 @myl_qbe_rc_status(ptr %p6810, i32 %v6811) nomerge, !dbg !164
  store i32 %call6812, ptr %slot1161, align 8
  br label %bb_failure
bb_rcsuccess1417:
  br label %bb_rcmoved1401
bb_rcmoved1401:
  %v6813 = load i64, ptr %slot17, align 8
  %p6814 = inttoptr i64 %v6813 to ptr
  store i32 0, ptr %p6814, align 4, !alias.scope !3, !noalias !4
  %v6815 = load i64, ptr %slot22, align 8
  %p6816 = inttoptr i64 %v6815 to ptr
  store i32 2, ptr %p6816, align 4, !alias.scope !3, !noalias !4
  %v6817 = load i64, ptr %slot21, align 8
  %p6818 = inttoptr i64 %v6817 to ptr
  store i32 1, ptr %p6818, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1398
bb_rcprivateloan1398:
  %v6819 = load i64, ptr %slot28, align 8
  store i64 %v6819, ptr %slot1162, align 8
  %v6820 = load i64, ptr %slot59, align 8
  %v6821 = load i64, ptr %slot1162, align 8
  %v6822 = load i64, ptr %slot1139, align 8
  %call6823 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v6820, i64 %v6821, i64 %v6822) nomerge, !dbg !164
  store i32 %call6823, ptr %slot1163, align 8
  %v6824 = load i32, ptr %slot1163, align 8
  %cv6825 = zext i32 %v6824 to i64
  %cond6826 = icmp ne i64 %cv6825, 0
  br i1 %cond6826, label %bb_rcsuccess1425, label %bb_rcfailure1425
bb_rcfailure1425:
  %v6827 = load i64, ptr %slot59, align 8
  %p6828 = inttoptr i64 %v6827 to ptr
  %call6829 = call i32 @myl_rc_take_failure(ptr %p6828) nomerge, !dbg !164
  store i32 %call6829, ptr %slot1164, align 8
  %v6830 = load i64, ptr %slot1, align 8
  %p6831 = inttoptr i64 %v6830 to ptr
  %v6832 = load i32, ptr %slot1164, align 8
  %call6833 = call i32 @myl_qbe_rc_status(ptr %p6831, i32 %v6832) nomerge, !dbg !164
  store i32 %call6833, ptr %slot1165, align 8
  br label %bb_failure
bb_rcsuccess1425:
  %v6834 = load i64, ptr %slot22, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  store i32 2, ptr %p6835, align 4, !alias.scope !3, !noalias !4
  %v6836 = load i64, ptr %slot22, align 8
  %p6837 = inttoptr i64 %v6836 to ptr
  store i32 16, ptr %p6837, align 4, !alias.scope !3, !noalias !4
  %v6838 = load i64, ptr %slot21, align 8
  %p6839 = inttoptr i64 %v6838 to ptr
  store i32 1, ptr %p6839, align 4, !alias.scope !3, !noalias !4
  %v6840 = load i64, ptr %slot17, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  %ld6842 = load i32, ptr %p6841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6842, ptr %slot1166, align 8
  %v6843 = load i32, ptr %slot1166, align 8
  %cv6844 = zext i32 %v6843 to i64
  %cond6845 = icmp ne i64 %cv6844, 0
  br i1 %cond6845, label %bb_rcslotdrop1433, label %bb_rcslotdone1433
bb_rcslotdrop1433:
  %v6846 = load i64, ptr %slot17, align 8
  %p6847 = inttoptr i64 %v6846 to ptr
  store i32 0, ptr %p6847, align 4, !alias.scope !3, !noalias !4
  %v6848 = load i64, ptr %slot24, align 8
  store i64 %v6848, ptr %slot1167, align 8
  %v6849 = load i64, ptr %slot18, align 8
  %p6850 = inttoptr i64 %v6849 to ptr
  %ld6851 = load i32, ptr %p6850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6851, ptr %slot1168, align 8
  %v6852 = load i32, ptr %slot1168, align 8
  %op6853 = and i32 %v6852, 28
  store i32 %op6853, ptr %slot1169, align 8
  %v6854 = load i32, ptr %slot1169, align 8
  %cv6855 = zext i32 %v6854 to i64
  %cond6856 = icmp ne i64 %cv6855, 0
  br i1 %cond6856, label %bb_rcslotrole1433, label %bb_rcslotowner1433
bb_rcslotrole1433:
  %v6857 = load i64, ptr %slot59, align 8
  store i64 %v6857, ptr %slot1170, align 8
  %v6858 = load i64, ptr %slot1170, align 8
  %v6859 = load i64, ptr %slot1167, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v6858, i64 %v6859) nomerge, !dbg !164
  br label %bb_rcslotdone1433
bb_rcslotowner1433:
  %v6860 = load i64, ptr %slot1167, align 8
  %p6862 = inttoptr i64 %v6860 to ptr
  %gep6863 = getelementptr i8, ptr %p6862, i64 0
  %op6861 = ptrtoint ptr %gep6863 to i64
  store i64 %op6861, ptr %slot1171, align 8
  %v6864 = load i64, ptr %slot59, align 8
  store i64 %v6864, ptr %slot1172, align 8
  %v6865 = load i64, ptr %slot1171, align 8
  %p6866 = inttoptr i64 %v6865 to ptr
  %ld6867 = load i64, ptr %p6866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6867, ptr %slot1173, align 8
  %v6868 = load i64, ptr %slot1173, align 8
  %cmp6869 = icmp ne i64 %v6868, 0
  %cv6870 = zext i1 %cmp6869 to i32
  store i32 %cv6870, ptr %slot1174, align 8
  %v6871 = load i32, ptr %slot1174, align 8
  %cv6872 = zext i32 %v6871 to i64
  %cond6873 = icmp ne i64 %cv6872, 0
  br i1 %cond6873, label %bb_rcgnn1451, label %bb_rcgdone1451
bb_rcgnn1451:
  %v6874 = load i64, ptr %slot1173, align 8
  %op6875 = sub i64 %v6874, 16
  store i64 %op6875, ptr %slot1175, align 8
  %v6876 = load i64, ptr %slot1173, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  %rgep6878 = getelementptr i8, ptr %p6877, i64 -16
  %ld6879 = load i64, ptr %rgep6878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6879, ptr %slot1176, align 8
  %v6880 = load i64, ptr %slot1176, align 8
  %op6881 = and i64 %v6880, 4611686018427387906
  store i64 %op6881, ptr %slot1177, align 8
  %v6882 = load i64, ptr %slot1177, align 8
  %cmp6883 = icmp ne i64 %v6882, 0
  %cv6884 = zext i1 %cmp6883 to i32
  store i32 %cv6884, ptr %slot1178, align 8
  %v6885 = load i32, ptr %slot1178, align 8
  %cv6886 = zext i32 %v6885 to i64
  %cond6887 = icmp ne i64 %cv6886, 0
  br i1 %cond6887, label %bb_rcgclear1451, label %bb_rcgcounted1451
bb_rcgcounted1451:
  %v6888 = load i64, ptr %slot1173, align 8
  %op6889 = sub i64 %v6888, 32
  store i64 %op6889, ptr %slot1179, align 8
  %v6890 = load i64, ptr %slot1173, align 8
  %p6891 = inttoptr i64 %v6890 to ptr
  %rgep6892 = getelementptr i8, ptr %p6891, i64 -32
  %ld6893 = load i64, ptr %rgep6892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6893, ptr %slot1180, align 8
  %v6894 = load i64, ptr %slot1180, align 8
  %op6895 = sub i64 %v6894, 1
  store i64 %op6895, ptr %slot1181, align 8
  %v6896 = load i64, ptr %slot1181, align 8
  %cmp6897 = icmp eq i64 %v6896, 0
  %cv6898 = zext i1 %cmp6897 to i32
  store i32 %cv6898, ptr %slot1182, align 8
  %v6899 = load i32, ptr %slot1182, align 8
  %cv6900 = zext i32 %v6899 to i64
  %cond6901 = icmp ne i64 %cv6900, 0
  br i1 %cond6901, label %bb_rcglast1451, label %bb_rcgdec1451
bb_rcglast1451:
  %v6902 = load i64, ptr %slot1173, align 8
  %op6903 = sub i64 %v6902, 24
  store i64 %op6903, ptr %slot1183, align 8
  %v6904 = load i64, ptr %slot1173, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  %rgep6906 = getelementptr i8, ptr %p6905, i64 -24
  %ld6907 = load i64, ptr %rgep6906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6907, ptr %slot1184, align 8
  %v6908 = load i64, ptr %slot1184, align 8
  %cmp6909 = icmp ne i64 %v6908, 0
  %cv6910 = zext i1 %cmp6909 to i32
  store i32 %cv6910, ptr %slot1185, align 8
  %v6911 = load i32, ptr %slot1185, align 8
  %cv6912 = zext i32 %v6911 to i64
  %cond6913 = icmp ne i64 %cv6912, 0
  br i1 %cond6913, label %bb_rcgdec1451, label %bb_rcgslow1451
bb_rcgslow1451:
  %v6914 = load i64, ptr %slot1172, align 8
  %v6915 = load i64, ptr %slot1171, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6914, i64 %v6915) nomerge, !dbg !164
  br label %bb_rcgdone1451
bb_rcgdec1451:
  %v6916 = load i64, ptr %slot1181, align 8
  %v6917 = load i64, ptr %slot1173, align 8
  %p6918 = inttoptr i64 %v6917 to ptr
  %rgep6919 = getelementptr i8, ptr %p6918, i64 -32
  store i64 %v6916, ptr %rgep6919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1451
bb_rcgclear1451:
  %v6920 = load i64, ptr %slot1171, align 8
  %p6921 = inttoptr i64 %v6920 to ptr
  store i64 0, ptr %p6921, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1451
bb_rcgdone1451:
  %v6922 = load i64, ptr %slot1167, align 8
  %p6923 = inttoptr i64 %v6922 to ptr
  store i64 0, ptr %p6923, align 8, !alias.scope !3, !noalias !4
  %v6924 = load i64, ptr %slot1167, align 8
  %p6926 = inttoptr i64 %v6924 to ptr
  %gep6927 = getelementptr i8, ptr %p6926, i64 8
  %op6925 = ptrtoint ptr %gep6927 to i64
  store i64 %op6925, ptr %slot1186, align 8
  %v6928 = load i64, ptr %slot1186, align 8
  %p6929 = inttoptr i64 %v6928 to ptr
  store i64 0, ptr %p6929, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1433
bb_rcslotdone1433:
  br label %bb_rcprivateprepared1398
bb_rcprivateprepared1398:
  %v6930 = load i64, ptr %slot13, align 8
  %p6931 = inttoptr i64 %v6930 to ptr
  %ld6932 = load i32, ptr %p6931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6932, ptr %slot1187, align 8
  %v6933 = load i32, ptr %slot1187, align 8
  %cv6934 = zext i32 %v6933 to i64
  %cond6935 = icmp ne i64 %cv6934, 0
  br i1 %cond6935, label %bb_rcslotdrop1459, label %bb_rcslotdone1459
bb_rcslotdrop1459:
  %v6936 = load i64, ptr %slot13, align 8
  %p6937 = inttoptr i64 %v6936 to ptr
  store i32 0, ptr %p6937, align 4, !alias.scope !3, !noalias !4
  %v6938 = load i64, ptr %slot48, align 8
  store i64 %v6938, ptr %slot1188, align 8
  %v6939 = load i64, ptr %slot14, align 8
  %p6940 = inttoptr i64 %v6939 to ptr
  %ld6941 = load i32, ptr %p6940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6941, ptr %slot1189, align 8
  %v6942 = load i32, ptr %slot1189, align 8
  %op6943 = and i32 %v6942, 28
  store i32 %op6943, ptr %slot1190, align 8
  %v6944 = load i32, ptr %slot1190, align 8
  %cv6945 = zext i32 %v6944 to i64
  %cond6946 = icmp ne i64 %cv6945, 0
  br i1 %cond6946, label %bb_rcslotrole1459, label %bb_rcslotowner1459
bb_rcslotrole1459:
  %v6947 = load i64, ptr %slot59, align 8
  store i64 %v6947, ptr %slot1191, align 8
  %v6948 = load i64, ptr %slot1191, align 8
  %v6949 = load i64, ptr %slot1188, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v6948, i64 %v6949) nomerge, !dbg !164
  br label %bb_rcslotdone1459
bb_rcslotowner1459:
  %v6950 = load i64, ptr %slot1188, align 8
  %p6952 = inttoptr i64 %v6950 to ptr
  %gep6953 = getelementptr i8, ptr %p6952, i64 0
  %op6951 = ptrtoint ptr %gep6953 to i64
  store i64 %op6951, ptr %slot1192, align 8
  %v6954 = load i64, ptr %slot59, align 8
  store i64 %v6954, ptr %slot1193, align 8
  %v6955 = load i64, ptr %slot1192, align 8
  %p6956 = inttoptr i64 %v6955 to ptr
  %ld6957 = load i64, ptr %p6956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6957, ptr %slot1194, align 8
  %v6958 = load i64, ptr %slot1194, align 8
  %cmp6959 = icmp ne i64 %v6958, 0
  %cv6960 = zext i1 %cmp6959 to i32
  store i32 %cv6960, ptr %slot1195, align 8
  %v6961 = load i32, ptr %slot1195, align 8
  %cv6962 = zext i32 %v6961 to i64
  %cond6963 = icmp ne i64 %cv6962, 0
  br i1 %cond6963, label %bb_rcgnn1477, label %bb_rcgdone1477
bb_rcgnn1477:
  %v6964 = load i64, ptr %slot1194, align 8
  %op6965 = sub i64 %v6964, 16
  store i64 %op6965, ptr %slot1196, align 8
  %v6966 = load i64, ptr %slot1194, align 8
  %p6967 = inttoptr i64 %v6966 to ptr
  %rgep6968 = getelementptr i8, ptr %p6967, i64 -16
  %ld6969 = load i64, ptr %rgep6968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6969, ptr %slot1197, align 8
  %v6970 = load i64, ptr %slot1197, align 8
  %op6971 = and i64 %v6970, 4611686018427387906
  store i64 %op6971, ptr %slot1198, align 8
  %v6972 = load i64, ptr %slot1198, align 8
  %cmp6973 = icmp ne i64 %v6972, 0
  %cv6974 = zext i1 %cmp6973 to i32
  store i32 %cv6974, ptr %slot1199, align 8
  %v6975 = load i32, ptr %slot1199, align 8
  %cv6976 = zext i32 %v6975 to i64
  %cond6977 = icmp ne i64 %cv6976, 0
  br i1 %cond6977, label %bb_rcgclear1477, label %bb_rcgcounted1477
bb_rcgcounted1477:
  %v6978 = load i64, ptr %slot1194, align 8
  %op6979 = sub i64 %v6978, 32
  store i64 %op6979, ptr %slot1200, align 8
  %v6980 = load i64, ptr %slot1194, align 8
  %p6981 = inttoptr i64 %v6980 to ptr
  %rgep6982 = getelementptr i8, ptr %p6981, i64 -32
  %ld6983 = load i64, ptr %rgep6982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6983, ptr %slot1201, align 8
  %v6984 = load i64, ptr %slot1201, align 8
  %op6985 = sub i64 %v6984, 1
  store i64 %op6985, ptr %slot1202, align 8
  %v6986 = load i64, ptr %slot1202, align 8
  %cmp6987 = icmp eq i64 %v6986, 0
  %cv6988 = zext i1 %cmp6987 to i32
  store i32 %cv6988, ptr %slot1203, align 8
  %v6989 = load i32, ptr %slot1203, align 8
  %cv6990 = zext i32 %v6989 to i64
  %cond6991 = icmp ne i64 %cv6990, 0
  br i1 %cond6991, label %bb_rcglast1477, label %bb_rcgdec1477
bb_rcglast1477:
  %v6992 = load i64, ptr %slot1194, align 8
  %op6993 = sub i64 %v6992, 24
  store i64 %op6993, ptr %slot1204, align 8
  %v6994 = load i64, ptr %slot1194, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %rgep6996 = getelementptr i8, ptr %p6995, i64 -24
  %ld6997 = load i64, ptr %rgep6996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6997, ptr %slot1205, align 8
  %v6998 = load i64, ptr %slot1205, align 8
  %cmp6999 = icmp ne i64 %v6998, 0
  %cv7000 = zext i1 %cmp6999 to i32
  store i32 %cv7000, ptr %slot1206, align 8
  %v7001 = load i32, ptr %slot1206, align 8
  %cv7002 = zext i32 %v7001 to i64
  %cond7003 = icmp ne i64 %cv7002, 0
  br i1 %cond7003, label %bb_rcgdec1477, label %bb_rcgslow1477
bb_rcgslow1477:
  %v7004 = load i64, ptr %slot1193, align 8
  %v7005 = load i64, ptr %slot1192, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7004, i64 %v7005) nomerge, !dbg !164
  br label %bb_rcgdone1477
bb_rcgdec1477:
  %v7006 = load i64, ptr %slot1202, align 8
  %v7007 = load i64, ptr %slot1194, align 8
  %p7008 = inttoptr i64 %v7007 to ptr
  %rgep7009 = getelementptr i8, ptr %p7008, i64 -32
  store i64 %v7006, ptr %rgep7009, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1477
bb_rcgclear1477:
  %v7010 = load i64, ptr %slot1192, align 8
  %p7011 = inttoptr i64 %v7010 to ptr
  store i64 0, ptr %p7011, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1477
bb_rcgdone1477:
  %v7012 = load i64, ptr %slot1188, align 8
  %p7013 = inttoptr i64 %v7012 to ptr
  store i64 0, ptr %p7013, align 8, !alias.scope !3, !noalias !4
  %v7014 = load i64, ptr %slot1188, align 8
  %p7016 = inttoptr i64 %v7014 to ptr
  %gep7017 = getelementptr i8, ptr %p7016, i64 8
  %op7015 = ptrtoint ptr %gep7017 to i64
  store i64 %op7015, ptr %slot1207, align 8
  %v7018 = load i64, ptr %slot1207, align 8
  %p7019 = inttoptr i64 %v7018 to ptr
  store i64 0, ptr %p7019, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1459
bb_rcslotdone1459:
  %v7020 = load i64, ptr %slot48, align 8
  store i64 %v7020, ptr %slot1208, align 8
  %v7021 = load i64, ptr %slot28, align 8
  store i64 %v7021, ptr %slot1209, align 8
  %v7022 = load i64, ptr %slot1209, align 8
  %v7023 = load i64, ptr %slot1208, align 8
  %p7024 = inttoptr i64 %v7022 to ptr
  %p7025 = inttoptr i64 %v7023 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7025, ptr %p7024, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7026 = load i64, ptr %slot21, align 8
  %p7027 = inttoptr i64 %v7026 to ptr
  store i32 0, ptr %p7027, align 4, !alias.scope !3, !noalias !4
  %v7028 = load i64, ptr %slot14, align 8
  %p7029 = inttoptr i64 %v7028 to ptr
  store i32 2, ptr %p7029, align 4, !alias.scope !3, !noalias !4
  %v7030 = load i64, ptr %slot22, align 8
  %p7031 = inttoptr i64 %v7030 to ptr
  %ld7032 = load i32, ptr %p7031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7032, ptr %slot1210, align 8
  %v7033 = load i32, ptr %slot1210, align 8
  %v7034 = load i64, ptr %slot14, align 8
  %p7035 = inttoptr i64 %v7034 to ptr
  store i32 %v7033, ptr %p7035, align 4, !alias.scope !3, !noalias !4
  %v7036 = load i64, ptr %slot13, align 8
  %p7037 = inttoptr i64 %v7036 to ptr
  store i32 1, ptr %p7037, align 4, !alias.scope !3, !noalias !4
  %v7038 = load i64, ptr %slot34, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  %ld7040 = load i64, ptr %p7039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7040, ptr %slot1211, align 8
  %v7041 = load i64, ptr %slot1211, align 8
  %v7042 = load i64, ptr %slot50, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  store i64 %v7041, ptr %p7043, align 8, !alias.scope !3, !noalias !4
  %v7044 = load i64, ptr %slot50, align 8
  %p7045 = inttoptr i64 %v7044 to ptr
  %ld7046 = load i64, ptr %p7045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7046, ptr %slot1212, align 8
  %v7047 = load i64, ptr %slot17, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  %ld7049 = load i32, ptr %p7048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7049, ptr %slot1213, align 8
  %v7050 = load i64, ptr %slot18, align 8
  %p7051 = inttoptr i64 %v7050 to ptr
  %ld7052 = load i32, ptr %p7051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7052, ptr %slot1214, align 8
  %v7053 = load i32, ptr %slot1214, align 8
  %op7054 = and i32 %v7053, 24
  store i32 %op7054, ptr %slot1214, align 8
  %v7055 = load i32, ptr %slot1214, align 8
  %cmp7056 = icmp eq i32 %v7055, 0
  %cv7057 = zext i1 %cmp7056 to i32
  store i32 %cv7057, ptr %slot1215, align 8
  %v7058 = load i32, ptr %slot1213, align 8
  %v7059 = load i32, ptr %slot1215, align 8
  %op7060 = and i32 %v7058, %v7059
  store i32 %op7060, ptr %slot1216, align 8
  %v7061 = load i32, ptr %slot1216, align 8
  %cv7062 = zext i32 %v7061 to i64
  %cond7063 = icmp ne i64 %cv7062, 0
  br i1 %cond7063, label %bb_rcprivateown1497, label %bb_rcprivateloan1497
bb_rcprivateown1497:
  %v7064 = load i64, ptr %slot28, align 8
  store i64 %v7064, ptr %slot1217, align 8
  %v7065 = load i64, ptr %slot60, align 8
  store i64 %v7065, ptr %slot1218, align 8
  %v7066 = load i64, ptr %slot1212, align 8
  %v7067 = load i64, ptr %slot1217, align 8
  %op7068 = sub i64 %v7066, %v7067
  store i64 %op7068, ptr %slot1219, align 8
  %v7069 = load i64, ptr %slot1217, align 8
  %v7070 = load i64, ptr %slot1212, align 8
  %op7071 = sub i64 %v7069, %v7070
  store i64 %op7071, ptr %slot1220, align 8
  %v7072 = load i64, ptr %slot1219, align 8
  %cmp7073 = icmp ult i64 %v7072, 16
  %cv7074 = zext i1 %cmp7073 to i32
  store i32 %cv7074, ptr %slot1221, align 8
  %v7075 = load i64, ptr %slot1220, align 8
  %cmp7076 = icmp ult i64 %v7075, 16
  %cv7077 = zext i1 %cmp7076 to i32
  store i32 %cv7077, ptr %slot1222, align 8
  %v7078 = load i32, ptr %slot1221, align 8
  %v7079 = load i32, ptr %slot1222, align 8
  %op7080 = or i32 %v7078, %v7079
  store i32 %op7080, ptr %slot1223, align 8
  %v7081 = load i32, ptr %slot1223, align 8
  %cv7082 = zext i32 %v7081 to i64
  %cond7083 = icmp ne i64 %cv7082, 0
  br i1 %cond7083, label %bb_rcmoveslow1500, label %bb_rcmovecheck1500
bb_rcmovecheck1500:
  %v7084 = load i64, ptr %slot1212, align 8
  %op7085 = add i64 %v7084, 0
  store i64 %op7085, ptr %slot1224, align 8
  %v7086 = load i64, ptr %slot1224, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %ld7088 = load i64, ptr %p7087, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7088, ptr %slot1225, align 8
  %v7089 = load i64, ptr %slot1225, align 8
  %cmp7090 = icmp ne i64 %v7089, 0
  %cv7091 = zext i1 %cmp7090 to i32
  store i32 %cv7091, ptr %slot1226, align 8
  %v7092 = load i32, ptr %slot1226, align 8
  %cv7093 = zext i32 %v7092 to i64
  %cond7094 = icmp ne i64 %cv7093, 0
  br i1 %cond7094, label %bb_rcmoveheader1508, label %bb_rcmovenext1508
bb_rcmoveheader1508:
  %v7095 = load i64, ptr %slot1225, align 8
  %op7096 = sub i64 %v7095, 16
  store i64 %op7096, ptr %slot1227, align 8
  %v7097 = load i64, ptr %slot1225, align 8
  %p7098 = inttoptr i64 %v7097 to ptr
  %rgep7099 = getelementptr i8, ptr %p7098, i64 -16
  %ld7100 = load i64, ptr %rgep7099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7100, ptr %slot1228, align 8
  %v7101 = load i64, ptr %slot1228, align 8
  %op7102 = and i64 %v7101, 5764607523034234881
  store i64 %op7102, ptr %slot1229, align 8
  %v7103 = load i64, ptr %slot1229, align 8
  %cmp7104 = icmp ne i64 %v7103, 0
  %cv7105 = zext i1 %cmp7104 to i32
  store i32 %cv7105, ptr %slot1230, align 8
  %v7106 = load i32, ptr %slot1230, align 8
  %cv7107 = zext i32 %v7106 to i64
  %cond7108 = icmp ne i64 %cv7107, 0
  br i1 %cond7108, label %bb_rcmoveslow1500, label %bb_rcmovenext1508
bb_rcmovenext1508:
  %v7109 = load i64, ptr %slot1212, align 8
  %v7110 = load i64, ptr %slot1217, align 8
  %p7111 = inttoptr i64 %v7109 to ptr
  %p7112 = inttoptr i64 %v7110 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7112, ptr %p7111, i64 16, i1 false), !alias.scope !10000001
  %v7113 = load i64, ptr %slot1212, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  store i64 0, ptr %p7114, align 8, !alias.scope !4, !noalias !3
  %v7115 = load i64, ptr %slot1212, align 8
  %op7116 = add i64 %v7115, 8
  store i64 %op7116, ptr %slot1231, align 8
  %v7117 = load i64, ptr %slot1231, align 8
  %p7118 = inttoptr i64 %v7117 to ptr
  store i64 0, ptr %p7118, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1500
bb_rcmoveslow1500:
  %v7119 = load i64, ptr %slot59, align 8
  %v7120 = load i64, ptr %slot1217, align 8
  %v7121 = load i64, ptr %slot1212, align 8
  %v7122 = load i64, ptr %slot1218, align 8
  %cv7123 = trunc i64 %v7122 to i32
  %call7124 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v7119, i64 %v7120, i64 %v7121, i32 %cv7123) nomerge, !dbg !166
  store i32 %call7124, ptr %slot1232, align 8
  %v7125 = load i32, ptr %slot1232, align 8
  %cv7126 = zext i32 %v7125 to i64
  %cond7127 = icmp ne i64 %cv7126, 0
  br i1 %cond7127, label %bb_rcsuccess1516, label %bb_rcfailure1516
bb_rcfailure1516:
  %v7128 = load i64, ptr %slot59, align 8
  %p7129 = inttoptr i64 %v7128 to ptr
  %call7130 = call i32 @myl_rc_take_failure(ptr %p7129) nomerge, !dbg !166
  store i32 %call7130, ptr %slot1233, align 8
  %v7131 = load i64, ptr %slot1, align 8
  %p7132 = inttoptr i64 %v7131 to ptr
  %v7133 = load i32, ptr %slot1233, align 8
  %call7134 = call i32 @myl_qbe_rc_status(ptr %p7132, i32 %v7133) nomerge, !dbg !166
  store i32 %call7134, ptr %slot1234, align 8
  br label %bb_failure
bb_rcsuccess1516:
  br label %bb_rcmoved1500
bb_rcmoved1500:
  %v7135 = load i64, ptr %slot17, align 8
  %p7136 = inttoptr i64 %v7135 to ptr
  store i32 0, ptr %p7136, align 4, !alias.scope !3, !noalias !4
  %v7137 = load i64, ptr %slot22, align 8
  %p7138 = inttoptr i64 %v7137 to ptr
  store i32 2, ptr %p7138, align 4, !alias.scope !3, !noalias !4
  %v7139 = load i64, ptr %slot21, align 8
  %p7140 = inttoptr i64 %v7139 to ptr
  store i32 1, ptr %p7140, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1497
bb_rcprivateloan1497:
  %v7141 = load i64, ptr %slot28, align 8
  store i64 %v7141, ptr %slot1235, align 8
  %v7142 = load i64, ptr %slot59, align 8
  %v7143 = load i64, ptr %slot1235, align 8
  %v7144 = load i64, ptr %slot1212, align 8
  %call7145 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v7142, i64 %v7143, i64 %v7144) nomerge, !dbg !166
  store i32 %call7145, ptr %slot1236, align 8
  %v7146 = load i32, ptr %slot1236, align 8
  %cv7147 = zext i32 %v7146 to i64
  %cond7148 = icmp ne i64 %cv7147, 0
  br i1 %cond7148, label %bb_rcsuccess1524, label %bb_rcfailure1524
bb_rcfailure1524:
  %v7149 = load i64, ptr %slot59, align 8
  %p7150 = inttoptr i64 %v7149 to ptr
  %call7151 = call i32 @myl_rc_take_failure(ptr %p7150) nomerge, !dbg !166
  store i32 %call7151, ptr %slot1237, align 8
  %v7152 = load i64, ptr %slot1, align 8
  %p7153 = inttoptr i64 %v7152 to ptr
  %v7154 = load i32, ptr %slot1237, align 8
  %call7155 = call i32 @myl_qbe_rc_status(ptr %p7153, i32 %v7154) nomerge, !dbg !166
  store i32 %call7155, ptr %slot1238, align 8
  br label %bb_failure
bb_rcsuccess1524:
  %v7156 = load i64, ptr %slot22, align 8
  %p7157 = inttoptr i64 %v7156 to ptr
  store i32 2, ptr %p7157, align 4, !alias.scope !3, !noalias !4
  %v7158 = load i64, ptr %slot22, align 8
  %p7159 = inttoptr i64 %v7158 to ptr
  store i32 16, ptr %p7159, align 4, !alias.scope !3, !noalias !4
  %v7160 = load i64, ptr %slot21, align 8
  %p7161 = inttoptr i64 %v7160 to ptr
  store i32 1, ptr %p7161, align 4, !alias.scope !3, !noalias !4
  %v7162 = load i64, ptr %slot17, align 8
  %p7163 = inttoptr i64 %v7162 to ptr
  %ld7164 = load i32, ptr %p7163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7164, ptr %slot1239, align 8
  %v7165 = load i32, ptr %slot1239, align 8
  %cv7166 = zext i32 %v7165 to i64
  %cond7167 = icmp ne i64 %cv7166, 0
  br i1 %cond7167, label %bb_rcslotdrop1532, label %bb_rcslotdone1532
bb_rcslotdrop1532:
  %v7168 = load i64, ptr %slot17, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  store i32 0, ptr %p7169, align 4, !alias.scope !3, !noalias !4
  %v7170 = load i64, ptr %slot24, align 8
  store i64 %v7170, ptr %slot1240, align 8
  %v7171 = load i64, ptr %slot18, align 8
  %p7172 = inttoptr i64 %v7171 to ptr
  %ld7173 = load i32, ptr %p7172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7173, ptr %slot1241, align 8
  %v7174 = load i32, ptr %slot1241, align 8
  %op7175 = and i32 %v7174, 28
  store i32 %op7175, ptr %slot1242, align 8
  %v7176 = load i32, ptr %slot1242, align 8
  %cv7177 = zext i32 %v7176 to i64
  %cond7178 = icmp ne i64 %cv7177, 0
  br i1 %cond7178, label %bb_rcslotrole1532, label %bb_rcslotowner1532
bb_rcslotrole1532:
  %v7179 = load i64, ptr %slot59, align 8
  store i64 %v7179, ptr %slot1243, align 8
  %v7180 = load i64, ptr %slot1243, align 8
  %v7181 = load i64, ptr %slot1240, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v7180, i64 %v7181) nomerge, !dbg !166
  br label %bb_rcslotdone1532
bb_rcslotowner1532:
  %v7182 = load i64, ptr %slot1240, align 8
  %p7184 = inttoptr i64 %v7182 to ptr
  %gep7185 = getelementptr i8, ptr %p7184, i64 0
  %op7183 = ptrtoint ptr %gep7185 to i64
  store i64 %op7183, ptr %slot1244, align 8
  %v7186 = load i64, ptr %slot59, align 8
  store i64 %v7186, ptr %slot1245, align 8
  %v7187 = load i64, ptr %slot1244, align 8
  %p7188 = inttoptr i64 %v7187 to ptr
  %ld7189 = load i64, ptr %p7188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7189, ptr %slot1246, align 8
  %v7190 = load i64, ptr %slot1246, align 8
  %cmp7191 = icmp ne i64 %v7190, 0
  %cv7192 = zext i1 %cmp7191 to i32
  store i32 %cv7192, ptr %slot1247, align 8
  %v7193 = load i32, ptr %slot1247, align 8
  %cv7194 = zext i32 %v7193 to i64
  %cond7195 = icmp ne i64 %cv7194, 0
  br i1 %cond7195, label %bb_rcgnn1550, label %bb_rcgdone1550
bb_rcgnn1550:
  %v7196 = load i64, ptr %slot1246, align 8
  %op7197 = sub i64 %v7196, 16
  store i64 %op7197, ptr %slot1248, align 8
  %v7198 = load i64, ptr %slot1246, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  %rgep7200 = getelementptr i8, ptr %p7199, i64 -16
  %ld7201 = load i64, ptr %rgep7200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7201, ptr %slot1249, align 8
  %v7202 = load i64, ptr %slot1249, align 8
  %op7203 = and i64 %v7202, 4611686018427387906
  store i64 %op7203, ptr %slot1250, align 8
  %v7204 = load i64, ptr %slot1250, align 8
  %cmp7205 = icmp ne i64 %v7204, 0
  %cv7206 = zext i1 %cmp7205 to i32
  store i32 %cv7206, ptr %slot1251, align 8
  %v7207 = load i32, ptr %slot1251, align 8
  %cv7208 = zext i32 %v7207 to i64
  %cond7209 = icmp ne i64 %cv7208, 0
  br i1 %cond7209, label %bb_rcgclear1550, label %bb_rcgcounted1550
bb_rcgcounted1550:
  %v7210 = load i64, ptr %slot1246, align 8
  %op7211 = sub i64 %v7210, 32
  store i64 %op7211, ptr %slot1252, align 8
  %v7212 = load i64, ptr %slot1246, align 8
  %p7213 = inttoptr i64 %v7212 to ptr
  %rgep7214 = getelementptr i8, ptr %p7213, i64 -32
  %ld7215 = load i64, ptr %rgep7214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7215, ptr %slot1253, align 8
  %v7216 = load i64, ptr %slot1253, align 8
  %op7217 = sub i64 %v7216, 1
  store i64 %op7217, ptr %slot1254, align 8
  %v7218 = load i64, ptr %slot1254, align 8
  %cmp7219 = icmp eq i64 %v7218, 0
  %cv7220 = zext i1 %cmp7219 to i32
  store i32 %cv7220, ptr %slot1255, align 8
  %v7221 = load i32, ptr %slot1255, align 8
  %cv7222 = zext i32 %v7221 to i64
  %cond7223 = icmp ne i64 %cv7222, 0
  br i1 %cond7223, label %bb_rcglast1550, label %bb_rcgdec1550
bb_rcglast1550:
  %v7224 = load i64, ptr %slot1246, align 8
  %op7225 = sub i64 %v7224, 24
  store i64 %op7225, ptr %slot1256, align 8
  %v7226 = load i64, ptr %slot1246, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  %rgep7228 = getelementptr i8, ptr %p7227, i64 -24
  %ld7229 = load i64, ptr %rgep7228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7229, ptr %slot1257, align 8
  %v7230 = load i64, ptr %slot1257, align 8
  %cmp7231 = icmp ne i64 %v7230, 0
  %cv7232 = zext i1 %cmp7231 to i32
  store i32 %cv7232, ptr %slot1258, align 8
  %v7233 = load i32, ptr %slot1258, align 8
  %cv7234 = zext i32 %v7233 to i64
  %cond7235 = icmp ne i64 %cv7234, 0
  br i1 %cond7235, label %bb_rcgdec1550, label %bb_rcgslow1550
bb_rcgslow1550:
  %v7236 = load i64, ptr %slot1245, align 8
  %v7237 = load i64, ptr %slot1244, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7236, i64 %v7237) nomerge, !dbg !166
  br label %bb_rcgdone1550
bb_rcgdec1550:
  %v7238 = load i64, ptr %slot1254, align 8
  %v7239 = load i64, ptr %slot1246, align 8
  %p7240 = inttoptr i64 %v7239 to ptr
  %rgep7241 = getelementptr i8, ptr %p7240, i64 -32
  store i64 %v7238, ptr %rgep7241, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1550
bb_rcgclear1550:
  %v7242 = load i64, ptr %slot1244, align 8
  %p7243 = inttoptr i64 %v7242 to ptr
  store i64 0, ptr %p7243, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1550
bb_rcgdone1550:
  %v7244 = load i64, ptr %slot1240, align 8
  %p7245 = inttoptr i64 %v7244 to ptr
  store i64 0, ptr %p7245, align 8, !alias.scope !3, !noalias !4
  %v7246 = load i64, ptr %slot1240, align 8
  %p7248 = inttoptr i64 %v7246 to ptr
  %gep7249 = getelementptr i8, ptr %p7248, i64 8
  %op7247 = ptrtoint ptr %gep7249 to i64
  store i64 %op7247, ptr %slot1259, align 8
  %v7250 = load i64, ptr %slot1259, align 8
  %p7251 = inttoptr i64 %v7250 to ptr
  store i64 0, ptr %p7251, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1532
bb_rcslotdone1532:
  br label %bb_rcprivateprepared1497
bb_rcprivateprepared1497:
  %v7252 = load i64, ptr %slot13, align 8
  %p7253 = inttoptr i64 %v7252 to ptr
  %ld7254 = load i32, ptr %p7253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7254, ptr %slot1260, align 8
  %v7255 = load i32, ptr %slot1260, align 8
  %cv7256 = zext i32 %v7255 to i64
  %cond7257 = icmp ne i64 %cv7256, 0
  br i1 %cond7257, label %bb_rcslotdrop1558, label %bb_rcslotdone1558
bb_rcslotdrop1558:
  %v7258 = load i64, ptr %slot13, align 8
  %p7259 = inttoptr i64 %v7258 to ptr
  store i32 0, ptr %p7259, align 4, !alias.scope !3, !noalias !4
  %v7260 = load i64, ptr %slot48, align 8
  store i64 %v7260, ptr %slot1261, align 8
  %v7261 = load i64, ptr %slot14, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  %ld7263 = load i32, ptr %p7262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7263, ptr %slot1262, align 8
  %v7264 = load i32, ptr %slot1262, align 8
  %op7265 = and i32 %v7264, 28
  store i32 %op7265, ptr %slot1263, align 8
  %v7266 = load i32, ptr %slot1263, align 8
  %cv7267 = zext i32 %v7266 to i64
  %cond7268 = icmp ne i64 %cv7267, 0
  br i1 %cond7268, label %bb_rcslotrole1558, label %bb_rcslotowner1558
bb_rcslotrole1558:
  %v7269 = load i64, ptr %slot59, align 8
  store i64 %v7269, ptr %slot1264, align 8
  %v7270 = load i64, ptr %slot1264, align 8
  %v7271 = load i64, ptr %slot1261, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v7270, i64 %v7271) nomerge, !dbg !166
  br label %bb_rcslotdone1558
bb_rcslotowner1558:
  %v7272 = load i64, ptr %slot1261, align 8
  %p7274 = inttoptr i64 %v7272 to ptr
  %gep7275 = getelementptr i8, ptr %p7274, i64 0
  %op7273 = ptrtoint ptr %gep7275 to i64
  store i64 %op7273, ptr %slot1265, align 8
  %v7276 = load i64, ptr %slot59, align 8
  store i64 %v7276, ptr %slot1266, align 8
  %v7277 = load i64, ptr %slot1265, align 8
  %p7278 = inttoptr i64 %v7277 to ptr
  %ld7279 = load i64, ptr %p7278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7279, ptr %slot1267, align 8
  %v7280 = load i64, ptr %slot1267, align 8
  %cmp7281 = icmp ne i64 %v7280, 0
  %cv7282 = zext i1 %cmp7281 to i32
  store i32 %cv7282, ptr %slot1268, align 8
  %v7283 = load i32, ptr %slot1268, align 8
  %cv7284 = zext i32 %v7283 to i64
  %cond7285 = icmp ne i64 %cv7284, 0
  br i1 %cond7285, label %bb_rcgnn1576, label %bb_rcgdone1576
bb_rcgnn1576:
  %v7286 = load i64, ptr %slot1267, align 8
  %op7287 = sub i64 %v7286, 16
  store i64 %op7287, ptr %slot1269, align 8
  %v7288 = load i64, ptr %slot1267, align 8
  %p7289 = inttoptr i64 %v7288 to ptr
  %rgep7290 = getelementptr i8, ptr %p7289, i64 -16
  %ld7291 = load i64, ptr %rgep7290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7291, ptr %slot1270, align 8
  %v7292 = load i64, ptr %slot1270, align 8
  %op7293 = and i64 %v7292, 4611686018427387906
  store i64 %op7293, ptr %slot1271, align 8
  %v7294 = load i64, ptr %slot1271, align 8
  %cmp7295 = icmp ne i64 %v7294, 0
  %cv7296 = zext i1 %cmp7295 to i32
  store i32 %cv7296, ptr %slot1272, align 8
  %v7297 = load i32, ptr %slot1272, align 8
  %cv7298 = zext i32 %v7297 to i64
  %cond7299 = icmp ne i64 %cv7298, 0
  br i1 %cond7299, label %bb_rcgclear1576, label %bb_rcgcounted1576
bb_rcgcounted1576:
  %v7300 = load i64, ptr %slot1267, align 8
  %op7301 = sub i64 %v7300, 32
  store i64 %op7301, ptr %slot1273, align 8
  %v7302 = load i64, ptr %slot1267, align 8
  %p7303 = inttoptr i64 %v7302 to ptr
  %rgep7304 = getelementptr i8, ptr %p7303, i64 -32
  %ld7305 = load i64, ptr %rgep7304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7305, ptr %slot1274, align 8
  %v7306 = load i64, ptr %slot1274, align 8
  %op7307 = sub i64 %v7306, 1
  store i64 %op7307, ptr %slot1275, align 8
  %v7308 = load i64, ptr %slot1275, align 8
  %cmp7309 = icmp eq i64 %v7308, 0
  %cv7310 = zext i1 %cmp7309 to i32
  store i32 %cv7310, ptr %slot1276, align 8
  %v7311 = load i32, ptr %slot1276, align 8
  %cv7312 = zext i32 %v7311 to i64
  %cond7313 = icmp ne i64 %cv7312, 0
  br i1 %cond7313, label %bb_rcglast1576, label %bb_rcgdec1576
bb_rcglast1576:
  %v7314 = load i64, ptr %slot1267, align 8
  %op7315 = sub i64 %v7314, 24
  store i64 %op7315, ptr %slot1277, align 8
  %v7316 = load i64, ptr %slot1267, align 8
  %p7317 = inttoptr i64 %v7316 to ptr
  %rgep7318 = getelementptr i8, ptr %p7317, i64 -24
  %ld7319 = load i64, ptr %rgep7318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7319, ptr %slot1278, align 8
  %v7320 = load i64, ptr %slot1278, align 8
  %cmp7321 = icmp ne i64 %v7320, 0
  %cv7322 = zext i1 %cmp7321 to i32
  store i32 %cv7322, ptr %slot1279, align 8
  %v7323 = load i32, ptr %slot1279, align 8
  %cv7324 = zext i32 %v7323 to i64
  %cond7325 = icmp ne i64 %cv7324, 0
  br i1 %cond7325, label %bb_rcgdec1576, label %bb_rcgslow1576
bb_rcgslow1576:
  %v7326 = load i64, ptr %slot1266, align 8
  %v7327 = load i64, ptr %slot1265, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7326, i64 %v7327) nomerge, !dbg !166
  br label %bb_rcgdone1576
bb_rcgdec1576:
  %v7328 = load i64, ptr %slot1275, align 8
  %v7329 = load i64, ptr %slot1267, align 8
  %p7330 = inttoptr i64 %v7329 to ptr
  %rgep7331 = getelementptr i8, ptr %p7330, i64 -32
  store i64 %v7328, ptr %rgep7331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1576
bb_rcgclear1576:
  %v7332 = load i64, ptr %slot1265, align 8
  %p7333 = inttoptr i64 %v7332 to ptr
  store i64 0, ptr %p7333, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1576
bb_rcgdone1576:
  %v7334 = load i64, ptr %slot1261, align 8
  %p7335 = inttoptr i64 %v7334 to ptr
  store i64 0, ptr %p7335, align 8, !alias.scope !3, !noalias !4
  %v7336 = load i64, ptr %slot1261, align 8
  %p7338 = inttoptr i64 %v7336 to ptr
  %gep7339 = getelementptr i8, ptr %p7338, i64 8
  %op7337 = ptrtoint ptr %gep7339 to i64
  store i64 %op7337, ptr %slot1280, align 8
  %v7340 = load i64, ptr %slot1280, align 8
  %p7341 = inttoptr i64 %v7340 to ptr
  store i64 0, ptr %p7341, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1558
bb_rcslotdone1558:
  %v7342 = load i64, ptr %slot48, align 8
  store i64 %v7342, ptr %slot1281, align 8
  %v7343 = load i64, ptr %slot28, align 8
  store i64 %v7343, ptr %slot1282, align 8
  %v7344 = load i64, ptr %slot1282, align 8
  %v7345 = load i64, ptr %slot1281, align 8
  %p7346 = inttoptr i64 %v7344 to ptr
  %p7347 = inttoptr i64 %v7345 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7347, ptr %p7346, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7348 = load i64, ptr %slot21, align 8
  %p7349 = inttoptr i64 %v7348 to ptr
  store i32 0, ptr %p7349, align 4, !alias.scope !3, !noalias !4
  %v7350 = load i64, ptr %slot14, align 8
  %p7351 = inttoptr i64 %v7350 to ptr
  store i32 2, ptr %p7351, align 4, !alias.scope !3, !noalias !4
  %v7352 = load i64, ptr %slot22, align 8
  %p7353 = inttoptr i64 %v7352 to ptr
  %ld7354 = load i32, ptr %p7353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7354, ptr %slot1283, align 8
  %v7355 = load i32, ptr %slot1283, align 8
  %v7356 = load i64, ptr %slot14, align 8
  %p7357 = inttoptr i64 %v7356 to ptr
  store i32 %v7355, ptr %p7357, align 4, !alias.scope !3, !noalias !4
  %v7358 = load i64, ptr %slot13, align 8
  %p7359 = inttoptr i64 %v7358 to ptr
  store i32 1, ptr %p7359, align 4, !alias.scope !3, !noalias !4
  %v7360 = load i64, ptr %slot48, align 8
  %v7361 = load i64, ptr %slot50, align 8
  %p7362 = inttoptr i64 %v7361 to ptr
  store i64 %v7360, ptr %p7362, align 8, !alias.scope !3, !noalias !4
  %v7363 = load i64, ptr %slot49, align 8
  %p7364 = inttoptr i64 %v7363 to ptr
  %ld7365 = load i64, ptr %p7364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7365, ptr %slot1284, align 8
  %v7366 = load i64, ptr %slot16, align 8
  %p7367 = inttoptr i64 %v7366 to ptr
  %ld7368 = load i32, ptr %p7367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7368, ptr %slot1285, align 8
  %v7369 = load i32, ptr %slot1285, align 8
  %cmp7370 = icmp eq i32 %v7369, 8
  %cv7371 = zext i1 %cmp7370 to i32
  store i32 %cv7371, ptr %slot1286, align 8
  %v7372 = load i64, ptr %slot15, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  %ld7374 = load i32, ptr %p7373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7374, ptr %slot1287, align 8
  %v7375 = load i32, ptr %slot1286, align 8
  %v7376 = load i32, ptr %slot1287, align 8
  %op7377 = and i32 %v7375, %v7376
  store i32 %op7377, ptr %slot1288, align 8
  %v7378 = load i32, ptr %slot1288, align 8
  %cv7379 = zext i32 %v7378 to i64
  %cond7380 = icmp ne i64 %cv7379, 0
  br i1 %cond7380, label %bb_rchold1589, label %bb_rcordinary1589
bb_rchold1589:
  %v7381 = load i64, ptr %slot28, align 8
  store i64 %v7381, ptr %slot1289, align 8
  %v7382 = load i64, ptr %slot1284, align 8
  %cmp7383 = icmp ne i64 %v7382, 0
  %cv7384 = zext i1 %cmp7383 to i32
  store i32 %cv7384, ptr %slot1290, align 8
  %v7385 = load i32, ptr %slot1290, align 8
  %cv7386 = zext i32 %v7385 to i64
  %cond7387 = icmp ne i64 %cv7386, 0
  br i1 %cond7387, label %bb_rcgnn1599, label %bb_rcgstore1599
bb_rcgnn1599:
  %v7388 = load i64, ptr %slot1284, align 8
  %op7389 = sub i64 %v7388, 16
  store i64 %op7389, ptr %slot1291, align 8
  %v7390 = load i64, ptr %slot1284, align 8
  %p7391 = inttoptr i64 %v7390 to ptr
  %rgep7392 = getelementptr i8, ptr %p7391, i64 -16
  %ld7393 = load i64, ptr %rgep7392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7393, ptr %slot1292, align 8
  %v7394 = load i64, ptr %slot1292, align 8
  %op7395 = and i64 %v7394, 4611686018427387906
  store i64 %op7395, ptr %slot1293, align 8
  %v7396 = load i64, ptr %slot1293, align 8
  %cmp7397 = icmp ne i64 %v7396, 0
  %cv7398 = zext i1 %cmp7397 to i32
  store i32 %cv7398, ptr %slot1294, align 8
  %v7399 = load i32, ptr %slot1294, align 8
  %cv7400 = zext i32 %v7399 to i64
  %cond7401 = icmp ne i64 %cv7400, 0
  br i1 %cond7401, label %bb_rcgstore1599, label %bb_rcginc1599
bb_rcginc1599:
  %v7402 = load i64, ptr %slot1284, align 8
  %op7403 = sub i64 %v7402, 24
  store i64 %op7403, ptr %slot1295, align 8
  %v7404 = load i64, ptr %slot1284, align 8
  %p7405 = inttoptr i64 %v7404 to ptr
  %rgep7406 = getelementptr i8, ptr %p7405, i64 -24
  %ld7407 = load i64, ptr %rgep7406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7407, ptr %slot1296, align 8
  %v7408 = load i64, ptr %slot1296, align 8
  %op7409 = add i64 %v7408, 1
  store i64 %op7409, ptr %slot1297, align 8
  %v7410 = load i64, ptr %slot1297, align 8
  %cmp7411 = icmp eq i64 %v7410, 0
  %cv7412 = zext i1 %cmp7411 to i32
  store i32 %cv7412, ptr %slot1298, align 8
  %v7413 = load i32, ptr %slot1298, align 8
  %cv7414 = zext i32 %v7413 to i64
  %cond7415 = icmp ne i64 %cv7414, 0
  br i1 %cond7415, label %bb_rcglimit1599, label %bb_rcgcapacity1599
bb_rcglimit1599:
  %v7416 = load i64, ptr %slot1, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  %call7418 = call i32 @myl_qbe_rc_status(ptr %p7417, i32 2) nomerge, !dbg !168
  store i32 %call7418, ptr %slot1299, align 8
  br label %bb_failure
bb_rcgcapacity1599:
  %v7419 = load i64, ptr %slot1297, align 8
  %v7420 = load i64, ptr %slot1284, align 8
  %p7421 = inttoptr i64 %v7420 to ptr
  %rgep7422 = getelementptr i8, ptr %p7421, i64 -24
  store i64 %v7419, ptr %rgep7422, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1599
bb_rcgstore1599:
  %v7423 = load i64, ptr %slot1284, align 8
  %v7424 = load i64, ptr %slot1289, align 8
  %p7425 = inttoptr i64 %v7424 to ptr
  store i64 %v7423, ptr %p7425, align 8, !alias.scope !3, !noalias !4
  %v7426 = load i64, ptr %slot22, align 8
  %p7427 = inttoptr i64 %v7426 to ptr
  store i32 2, ptr %p7427, align 4, !alias.scope !3, !noalias !4
  %v7428 = load i64, ptr %slot22, align 8
  %p7429 = inttoptr i64 %v7428 to ptr
  store i32 8, ptr %p7429, align 4, !alias.scope !3, !noalias !4
  %v7430 = load i64, ptr %slot21, align 8
  %p7431 = inttoptr i64 %v7430 to ptr
  store i32 1, ptr %p7431, align 4, !alias.scope !3, !noalias !4
  %v7432 = load i64, ptr %slot25, align 8
  store i64 %v7432, ptr %slot1300, align 8
  %v7433 = load i64, ptr %slot28, align 8
  store i64 %v7433, ptr %slot1301, align 8
  %v7434 = load i64, ptr %slot1301, align 8
  %p7435 = inttoptr i64 %v7434 to ptr
  %ld7436 = load i64, ptr %p7435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7436, ptr %slot1302, align 8
  %v7437 = load i64, ptr %slot1302, align 8
  %v7438 = load i64, ptr %slot1300, align 8
  %p7439 = inttoptr i64 %v7438 to ptr
  store i64 %v7437, ptr %p7439, align 8, !alias.scope !3, !noalias !4
  %v7440 = load i64, ptr %slot20, align 8
  %p7441 = inttoptr i64 %v7440 to ptr
  store i32 2, ptr %p7441, align 4, !alias.scope !3, !noalias !4
  %v7442 = load i64, ptr %slot20, align 8
  %p7443 = inttoptr i64 %v7442 to ptr
  store i32 8, ptr %p7443, align 4, !alias.scope !3, !noalias !4
  %v7444 = load i64, ptr %slot19, align 8
  %p7445 = inttoptr i64 %v7444 to ptr
  store i32 1, ptr %p7445, align 4, !alias.scope !3, !noalias !4
  %v7446 = load i64, ptr %slot21, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  store i32 0, ptr %p7447, align 4, !alias.scope !3, !noalias !4
  %v7448 = load i64, ptr %slot1302, align 8
  %v7449 = load i64, ptr %slot51, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  store i64 %v7448, ptr %p7450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1589
bb_rcordinary1589:
  %v7451 = load i64, ptr %slot1284, align 8
  %v7452 = load i64, ptr %slot51, align 8
  %p7453 = inttoptr i64 %v7452 to ptr
  store i64 %v7451, ptr %p7453, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined1589
bb_rcholdjoined1589:
  %v7454 = load i64, ptr %slot50, align 8
  %p7455 = inttoptr i64 %v7454 to ptr
  %ld7456 = load i64, ptr %p7455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7456, ptr %slot1303, align 8
  %v7457 = load i64, ptr %slot17, align 8
  %p7458 = inttoptr i64 %v7457 to ptr
  %ld7459 = load i32, ptr %p7458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7459, ptr %slot1304, align 8
  %v7460 = load i64, ptr %slot18, align 8
  %p7461 = inttoptr i64 %v7460 to ptr
  %ld7462 = load i32, ptr %p7461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7462, ptr %slot1305, align 8
  %v7463 = load i32, ptr %slot1305, align 8
  %op7464 = and i32 %v7463, 24
  store i32 %op7464, ptr %slot1305, align 8
  %v7465 = load i32, ptr %slot1305, align 8
  %cmp7466 = icmp eq i32 %v7465, 0
  %cv7467 = zext i1 %cmp7466 to i32
  store i32 %cv7467, ptr %slot1306, align 8
  %v7468 = load i32, ptr %slot1304, align 8
  %v7469 = load i32, ptr %slot1306, align 8
  %op7470 = and i32 %v7468, %v7469
  store i32 %op7470, ptr %slot1307, align 8
  %v7471 = load i32, ptr %slot1307, align 8
  %cv7472 = zext i32 %v7471 to i64
  %cond7473 = icmp ne i64 %cv7472, 0
  br i1 %cond7473, label %bb_rctake1621, label %bb_rccopy1621
bb_rctake1621:
  %v7474 = load i64, ptr %slot28, align 8
  store i64 %v7474, ptr %slot1308, align 8
  %v7475 = load i64, ptr %slot60, align 8
  store i64 %v7475, ptr %slot1309, align 8
  %v7476 = load i64, ptr %slot1303, align 8
  %v7477 = load i64, ptr %slot1308, align 8
  %op7478 = sub i64 %v7476, %v7477
  store i64 %op7478, ptr %slot1310, align 8
  %v7479 = load i64, ptr %slot1308, align 8
  %v7480 = load i64, ptr %slot1303, align 8
  %op7481 = sub i64 %v7479, %v7480
  store i64 %op7481, ptr %slot1311, align 8
  %v7482 = load i64, ptr %slot1310, align 8
  %cmp7483 = icmp ult i64 %v7482, 16
  %cv7484 = zext i1 %cmp7483 to i32
  store i32 %cv7484, ptr %slot1312, align 8
  %v7485 = load i64, ptr %slot1311, align 8
  %cmp7486 = icmp ult i64 %v7485, 16
  %cv7487 = zext i1 %cmp7486 to i32
  store i32 %cv7487, ptr %slot1313, align 8
  %v7488 = load i32, ptr %slot1312, align 8
  %v7489 = load i32, ptr %slot1313, align 8
  %op7490 = or i32 %v7488, %v7489
  store i32 %op7490, ptr %slot1314, align 8
  %v7491 = load i32, ptr %slot1314, align 8
  %cv7492 = zext i32 %v7491 to i64
  %cond7493 = icmp ne i64 %cv7492, 0
  br i1 %cond7493, label %bb_rcmoveslow1630, label %bb_rcmovecheck1630
bb_rcmovecheck1630:
  %v7494 = load i64, ptr %slot1303, align 8
  %op7495 = add i64 %v7494, 0
  store i64 %op7495, ptr %slot1315, align 8
  %v7496 = load i64, ptr %slot1315, align 8
  %p7497 = inttoptr i64 %v7496 to ptr
  %ld7498 = load i64, ptr %p7497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7498, ptr %slot1316, align 8
  %v7499 = load i64, ptr %slot1316, align 8
  %cmp7500 = icmp ne i64 %v7499, 0
  %cv7501 = zext i1 %cmp7500 to i32
  store i32 %cv7501, ptr %slot1317, align 8
  %v7502 = load i32, ptr %slot1317, align 8
  %cv7503 = zext i32 %v7502 to i64
  %cond7504 = icmp ne i64 %cv7503, 0
  br i1 %cond7504, label %bb_rcmoveheader1638, label %bb_rcmovenext1638
bb_rcmoveheader1638:
  %v7505 = load i64, ptr %slot1316, align 8
  %op7506 = sub i64 %v7505, 16
  store i64 %op7506, ptr %slot1318, align 8
  %v7507 = load i64, ptr %slot1316, align 8
  %p7508 = inttoptr i64 %v7507 to ptr
  %rgep7509 = getelementptr i8, ptr %p7508, i64 -16
  %ld7510 = load i64, ptr %rgep7509, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7510, ptr %slot1319, align 8
  %v7511 = load i64, ptr %slot1319, align 8
  %op7512 = and i64 %v7511, 5764607523034234881
  store i64 %op7512, ptr %slot1320, align 8
  %v7513 = load i64, ptr %slot1320, align 8
  %cmp7514 = icmp ne i64 %v7513, 0
  %cv7515 = zext i1 %cmp7514 to i32
  store i32 %cv7515, ptr %slot1321, align 8
  %v7516 = load i32, ptr %slot1321, align 8
  %cv7517 = zext i32 %v7516 to i64
  %cond7518 = icmp ne i64 %cv7517, 0
  br i1 %cond7518, label %bb_rcmoveslow1630, label %bb_rcmovenext1638
bb_rcmovenext1638:
  %v7519 = load i64, ptr %slot1303, align 8
  %v7520 = load i64, ptr %slot1308, align 8
  %p7521 = inttoptr i64 %v7519 to ptr
  %p7522 = inttoptr i64 %v7520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7522, ptr %p7521, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7523 = load i64, ptr %slot1303, align 8
  %p7524 = inttoptr i64 %v7523 to ptr
  store i64 0, ptr %p7524, align 8, !alias.scope !3, !noalias !4
  %v7525 = load i64, ptr %slot1303, align 8
  %op7526 = add i64 %v7525, 8
  store i64 %op7526, ptr %slot1322, align 8
  %v7527 = load i64, ptr %slot1322, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  store i64 0, ptr %p7528, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1630
bb_rcmoveslow1630:
  %v7529 = load i64, ptr %slot59, align 8
  %v7530 = load i64, ptr %slot1308, align 8
  %v7531 = load i64, ptr %slot1303, align 8
  %v7532 = load i64, ptr %slot1309, align 8
  %cv7533 = trunc i64 %v7532 to i32
  %call7534 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v7529, i64 %v7530, i64 %v7531, i32 %cv7533) nomerge, !dbg !170
  store i32 %call7534, ptr %slot1323, align 8
  %v7535 = load i32, ptr %slot1323, align 8
  %cv7536 = zext i32 %v7535 to i64
  %cond7537 = icmp ne i64 %cv7536, 0
  br i1 %cond7537, label %bb_rcsuccess1646, label %bb_rcfailure1646
bb_rcfailure1646:
  %v7538 = load i64, ptr %slot59, align 8
  %p7539 = inttoptr i64 %v7538 to ptr
  %call7540 = call i32 @myl_rc_take_failure(ptr %p7539) nomerge, !dbg !170
  store i32 %call7540, ptr %slot1324, align 8
  %v7541 = load i64, ptr %slot1, align 8
  %p7542 = inttoptr i64 %v7541 to ptr
  %v7543 = load i32, ptr %slot1324, align 8
  %call7544 = call i32 @myl_qbe_rc_status(ptr %p7542, i32 %v7543) nomerge, !dbg !170
  store i32 %call7544, ptr %slot1325, align 8
  br label %bb_failure
bb_rcsuccess1646:
  br label %bb_rcmoved1630
bb_rcmoved1630:
  %v7545 = load i64, ptr %slot17, align 8
  %p7546 = inttoptr i64 %v7545 to ptr
  store i32 0, ptr %p7546, align 4, !alias.scope !3, !noalias !4
  %v7547 = load i64, ptr %slot22, align 8
  %p7548 = inttoptr i64 %v7547 to ptr
  store i32 2, ptr %p7548, align 4, !alias.scope !3, !noalias !4
  %v7549 = load i64, ptr %slot21, align 8
  %p7550 = inttoptr i64 %v7549 to ptr
  store i32 1, ptr %p7550, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1621
bb_rccopy1621:
  %v7551 = load i64, ptr %slot28, align 8
  store i64 %v7551, ptr %slot1326, align 8
  %v7552 = load i64, ptr %slot60, align 8
  store i64 %v7552, ptr %slot1327, align 8
  %v7553 = load i64, ptr %slot59, align 8
  %v7554 = load i64, ptr %slot1326, align 8
  %v7555 = load i64, ptr %slot1303, align 8
  %v7556 = load i64, ptr %slot1327, align 8
  %cv7557 = trunc i64 %v7556 to i32
  %call7558 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v7553, i64 %v7554, i64 %v7555, i32 %cv7557) nomerge, !dbg !170
  store i32 %call7558, ptr %slot1328, align 8
  %v7559 = load i32, ptr %slot1328, align 8
  %cv7560 = zext i32 %v7559 to i64
  %cond7561 = icmp ne i64 %cv7560, 0
  br i1 %cond7561, label %bb_rcsuccess1655, label %bb_rcfailure1655
bb_rcfailure1655:
  %v7562 = load i64, ptr %slot59, align 8
  %p7563 = inttoptr i64 %v7562 to ptr
  %call7564 = call i32 @myl_rc_take_failure(ptr %p7563) nomerge, !dbg !170
  store i32 %call7564, ptr %slot1329, align 8
  %v7565 = load i64, ptr %slot1, align 8
  %p7566 = inttoptr i64 %v7565 to ptr
  %v7567 = load i32, ptr %slot1329, align 8
  %call7568 = call i32 @myl_qbe_rc_status(ptr %p7566, i32 %v7567) nomerge, !dbg !170
  store i32 %call7568, ptr %slot1330, align 8
  br label %bb_failure
bb_rcsuccess1655:
  %v7569 = load i64, ptr %slot22, align 8
  %p7570 = inttoptr i64 %v7569 to ptr
  store i32 2, ptr %p7570, align 4, !alias.scope !3, !noalias !4
  %v7571 = load i64, ptr %slot21, align 8
  %p7572 = inttoptr i64 %v7571 to ptr
  store i32 1, ptr %p7572, align 4, !alias.scope !3, !noalias !4
  %v7573 = load i64, ptr %slot17, align 8
  %p7574 = inttoptr i64 %v7573 to ptr
  %ld7575 = load i32, ptr %p7574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7575, ptr %slot1331, align 8
  %v7576 = load i32, ptr %slot1331, align 8
  %cv7577 = zext i32 %v7576 to i64
  %cond7578 = icmp ne i64 %cv7577, 0
  br i1 %cond7578, label %bb_rcslotdrop1662, label %bb_rcslotdone1662
bb_rcslotdrop1662:
  %v7579 = load i64, ptr %slot17, align 8
  %p7580 = inttoptr i64 %v7579 to ptr
  store i32 0, ptr %p7580, align 4, !alias.scope !3, !noalias !4
  %v7581 = load i64, ptr %slot24, align 8
  store i64 %v7581, ptr %slot1332, align 8
  %v7582 = load i64, ptr %slot18, align 8
  %p7583 = inttoptr i64 %v7582 to ptr
  %ld7584 = load i32, ptr %p7583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7584, ptr %slot1333, align 8
  %v7585 = load i32, ptr %slot1333, align 8
  %op7586 = and i32 %v7585, 28
  store i32 %op7586, ptr %slot1334, align 8
  %v7587 = load i32, ptr %slot1334, align 8
  %cv7588 = zext i32 %v7587 to i64
  %cond7589 = icmp ne i64 %cv7588, 0
  br i1 %cond7589, label %bb_rcslotrole1662, label %bb_rcslotowner1662
bb_rcslotrole1662:
  %v7590 = load i64, ptr %slot59, align 8
  store i64 %v7590, ptr %slot1335, align 8
  %v7591 = load i64, ptr %slot1335, align 8
  %v7592 = load i64, ptr %slot1332, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v7591, i64 %v7592) nomerge, !dbg !170
  br label %bb_rcslotdone1662
bb_rcslotowner1662:
  %v7593 = load i64, ptr %slot59, align 8
  store i64 %v7593, ptr %slot1336, align 8
  %v7594 = load i64, ptr %slot1336, align 8
  %v7595 = load i64, ptr %slot1332, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v7594, i64 %v7595) nomerge, !dbg !170
  br label %bb_rcslotdone1662
bb_rcslotdone1662:
  br label %bb_rcprepared1621
bb_rcprepared1621:
  %v7596 = load i64, ptr %slot28, align 8
  store i64 %v7596, ptr %slot1337, align 8
  %v7597 = load i64, ptr %slot54, align 8
  store i64 %v7597, ptr %slot1338, align 8
  %v7598 = load i64, ptr %slot1337, align 8
  %v7599 = load i64, ptr %slot1338, align 8
  %p7600 = inttoptr i64 %v7598 to ptr
  %p7601 = inttoptr i64 %v7599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7601, ptr %p7600, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v7602 = load i64, ptr %slot21, align 8
  %p7603 = inttoptr i64 %v7602 to ptr
  store i32 0, ptr %p7603, align 4, !alias.scope !3, !noalias !4
  %v7604 = load i64, ptr %slot23, align 8
  %p7605 = inttoptr i64 %v7604 to ptr
  store i32 1, ptr %p7605, align 4, !alias.scope !3, !noalias !4
  %v7606 = load i64, ptr %slot60, align 8
  store i64 %v7606, ptr %slot1339, align 8
  %v7607 = load i64, ptr %slot51, align 8
  %p7608 = inttoptr i64 %v7607 to ptr
  %ld7609 = load i64, ptr %p7608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7609, ptr %slot1340, align 8
  %v7610 = load i64, ptr %slot1340, align 8
  %v7611 = load i64, ptr %slot27, align 8
  %p7612 = inttoptr i64 %v7611 to ptr
  store i64 %v7610, ptr %p7612, align 8, !alias.scope !3, !noalias !4
  %v7613 = load i64, ptr %slot27, align 8
  store i64 %v7613, ptr %slot1341, align 8
  %v7614 = load i64, ptr %slot1338, align 8
  %p7616 = inttoptr i64 %v7614 to ptr
  %gep7617 = getelementptr i8, ptr %p7616, i64 0
  %op7615 = ptrtoint ptr %gep7617 to i64
  store i64 %op7615, ptr %slot1342, align 8
  %v7618 = load i64, ptr %slot28, align 8
  store i64 %v7618, ptr %slot1343, align 8
  %v7619 = load i64, ptr %slot51, align 8
  %p7620 = inttoptr i64 %v7619 to ptr
  %ld7621 = load i64, ptr %p7620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7621, ptr %slot1344, align 8
  %v7622 = load i64, ptr %slot1344, align 8
  %v7623 = load i64, ptr %slot27, align 8
  %p7624 = inttoptr i64 %v7623 to ptr
  store i64 %v7622, ptr %p7624, align 8, !alias.scope !3, !noalias !4
  %v7625 = load i64, ptr %slot27, align 8
  store i64 %v7625, ptr %slot1345, align 8
  %v7626 = load i64, ptr %slot19, align 8
  %p7627 = inttoptr i64 %v7626 to ptr
  %ld7628 = load i32, ptr %p7627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7628, ptr %slot1346, align 8
  %v7629 = load i64, ptr %slot20, align 8
  %p7630 = inttoptr i64 %v7629 to ptr
  %ld7631 = load i32, ptr %p7630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7631, ptr %slot1347, align 8
  %v7632 = load i32, ptr %slot1347, align 8
  %op7633 = and i32 %v7632, 24
  store i32 %op7633, ptr %slot1347, align 8
  %v7634 = load i32, ptr %slot1347, align 8
  %cmp7635 = icmp eq i32 %v7634, 0
  %cv7636 = zext i1 %cmp7635 to i32
  store i32 %cv7636, ptr %slot1348, align 8
  %v7637 = load i32, ptr %slot1346, align 8
  %v7638 = load i32, ptr %slot1348, align 8
  %op7639 = and i32 %v7637, %v7638
  store i32 %op7639, ptr %slot1349, align 8
  %v7640 = load i32, ptr %slot1349, align 8
  %cv7641 = zext i32 %v7640 to i64
  %cond7642 = icmp ne i64 %cv7641, 0
  br i1 %cond7642, label %bb_rctake1681, label %bb_rccopy1681
bb_rctake1681:
  %v7643 = load i64, ptr %slot28, align 8
  store i64 %v7643, ptr %slot1350, align 8
  %v7644 = load i64, ptr %slot60, align 8
  store i64 %v7644, ptr %slot1351, align 8
  %v7645 = load i64, ptr %slot1345, align 8
  %v7646 = load i64, ptr %slot1350, align 8
  %op7647 = sub i64 %v7645, %v7646
  store i64 %op7647, ptr %slot1352, align 8
  %v7648 = load i64, ptr %slot1350, align 8
  %v7649 = load i64, ptr %slot1345, align 8
  %op7650 = sub i64 %v7648, %v7649
  store i64 %op7650, ptr %slot1353, align 8
  %v7651 = load i64, ptr %slot1352, align 8
  %cmp7652 = icmp ult i64 %v7651, 8
  %cv7653 = zext i1 %cmp7652 to i32
  store i32 %cv7653, ptr %slot1354, align 8
  %v7654 = load i64, ptr %slot1353, align 8
  %cmp7655 = icmp ult i64 %v7654, 8
  %cv7656 = zext i1 %cmp7655 to i32
  store i32 %cv7656, ptr %slot1355, align 8
  %v7657 = load i32, ptr %slot1354, align 8
  %v7658 = load i32, ptr %slot1355, align 8
  %op7659 = or i32 %v7657, %v7658
  store i32 %op7659, ptr %slot1356, align 8
  %v7660 = load i32, ptr %slot1356, align 8
  %cv7661 = zext i32 %v7660 to i64
  %cond7662 = icmp ne i64 %cv7661, 0
  br i1 %cond7662, label %bb_rcmoveslow1690, label %bb_rcmovecheck1690
bb_rcmovecheck1690:
  %v7663 = load i64, ptr %slot1345, align 8
  %p7665 = inttoptr i64 %v7663 to ptr
  %gep7666 = getelementptr i8, ptr %p7665, i64 0
  %op7664 = ptrtoint ptr %gep7666 to i64
  store i64 %op7664, ptr %slot1357, align 8
  %v7667 = load i64, ptr %slot1357, align 8
  %p7668 = inttoptr i64 %v7667 to ptr
  %ld7669 = load i64, ptr %p7668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7669, ptr %slot1358, align 8
  %v7670 = load i64, ptr %slot1358, align 8
  %cmp7671 = icmp ne i64 %v7670, 0
  %cv7672 = zext i1 %cmp7671 to i32
  store i32 %cv7672, ptr %slot1359, align 8
  %v7673 = load i32, ptr %slot1359, align 8
  %cv7674 = zext i32 %v7673 to i64
  %cond7675 = icmp ne i64 %cv7674, 0
  br i1 %cond7675, label %bb_rcmoveheader1698, label %bb_rcmovenext1698
bb_rcmoveheader1698:
  %v7676 = load i64, ptr %slot1358, align 8
  %op7677 = sub i64 %v7676, 16
  store i64 %op7677, ptr %slot1360, align 8
  %v7678 = load i64, ptr %slot1358, align 8
  %p7679 = inttoptr i64 %v7678 to ptr
  %rgep7680 = getelementptr i8, ptr %p7679, i64 -16
  %ld7681 = load i64, ptr %rgep7680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7681, ptr %slot1361, align 8
  %v7682 = load i64, ptr %slot1361, align 8
  %op7683 = and i64 %v7682, 5764607523034234881
  store i64 %op7683, ptr %slot1362, align 8
  %v7684 = load i64, ptr %slot1362, align 8
  %cmp7685 = icmp ne i64 %v7684, 0
  %cv7686 = zext i1 %cmp7685 to i32
  store i32 %cv7686, ptr %slot1363, align 8
  %v7687 = load i32, ptr %slot1363, align 8
  %cv7688 = zext i32 %v7687 to i64
  %cond7689 = icmp ne i64 %cv7688, 0
  br i1 %cond7689, label %bb_rcmoveslow1690, label %bb_rcmovenext1698
bb_rcmovenext1698:
  %v7690 = load i64, ptr %slot1345, align 8
  %v7691 = load i64, ptr %slot1350, align 8
  %p7692 = inttoptr i64 %v7690 to ptr
  %p7693 = inttoptr i64 %v7691 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7693, ptr %p7692, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7694 = load i64, ptr %slot1345, align 8
  %p7695 = inttoptr i64 %v7694 to ptr
  store i64 0, ptr %p7695, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1690
bb_rcmoveslow1690:
  %v7696 = load i64, ptr %slot59, align 8
  %v7697 = load i64, ptr %slot1350, align 8
  %v7698 = load i64, ptr %slot1345, align 8
  %v7699 = load i64, ptr %slot1351, align 8
  %cv7700 = trunc i64 %v7699 to i32
  %call7701 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v7696, i64 %v7697, i64 %v7698, i32 %cv7700) nomerge, !dbg !170
  store i32 %call7701, ptr %slot1364, align 8
  %v7702 = load i32, ptr %slot1364, align 8
  %cv7703 = zext i32 %v7702 to i64
  %cond7704 = icmp ne i64 %cv7703, 0
  br i1 %cond7704, label %bb_rcsuccess1705, label %bb_rcfailure1705
bb_rcfailure1705:
  %v7705 = load i64, ptr %slot59, align 8
  %p7706 = inttoptr i64 %v7705 to ptr
  %call7707 = call i32 @myl_rc_take_failure(ptr %p7706) nomerge, !dbg !170
  store i32 %call7707, ptr %slot1365, align 8
  %v7708 = load i64, ptr %slot1, align 8
  %p7709 = inttoptr i64 %v7708 to ptr
  %v7710 = load i32, ptr %slot1365, align 8
  %call7711 = call i32 @myl_qbe_rc_status(ptr %p7709, i32 %v7710) nomerge, !dbg !170
  store i32 %call7711, ptr %slot1366, align 8
  br label %bb_failure
bb_rcsuccess1705:
  br label %bb_rcmoved1690
bb_rcmoved1690:
  %v7712 = load i64, ptr %slot19, align 8
  %p7713 = inttoptr i64 %v7712 to ptr
  store i32 0, ptr %p7713, align 4, !alias.scope !3, !noalias !4
  %v7714 = load i64, ptr %slot22, align 8
  %p7715 = inttoptr i64 %v7714 to ptr
  store i32 2, ptr %p7715, align 4, !alias.scope !3, !noalias !4
  %v7716 = load i64, ptr %slot21, align 8
  %p7717 = inttoptr i64 %v7716 to ptr
  store i32 1, ptr %p7717, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1681
bb_rccopy1681:
  %v7718 = load i64, ptr %slot28, align 8
  store i64 %v7718, ptr %slot1367, align 8
  %v7719 = load i64, ptr %slot60, align 8
  store i64 %v7719, ptr %slot1368, align 8
  %v7720 = load i64, ptr %slot1345, align 8
  %p7721 = inttoptr i64 %v7720 to ptr
  %ld7722 = load i64, ptr %p7721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7722, ptr %slot1369, align 8
  %v7723 = load i64, ptr %slot1369, align 8
  %cmp7724 = icmp ne i64 %v7723, 0
  %cv7725 = zext i1 %cmp7724 to i32
  store i32 %cv7725, ptr %slot1370, align 8
  %v7726 = load i32, ptr %slot1370, align 8
  %cv7727 = zext i32 %v7726 to i64
  %cond7728 = icmp ne i64 %cv7727, 0
  br i1 %cond7728, label %bb_rcgnn1714, label %bb_rcgplain1714
bb_rcgnn1714:
  %v7729 = load i64, ptr %slot1369, align 8
  %op7730 = sub i64 %v7729, 16
  store i64 %op7730, ptr %slot1371, align 8
  %v7731 = load i64, ptr %slot1369, align 8
  %p7732 = inttoptr i64 %v7731 to ptr
  %rgep7733 = getelementptr i8, ptr %p7732, i64 -16
  %ld7734 = load i64, ptr %rgep7733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7734, ptr %slot1372, align 8
  %v7735 = load i64, ptr %slot1372, align 8
  %op7736 = and i64 %v7735, 4611686018427387906
  store i64 %op7736, ptr %slot1373, align 8
  %v7737 = load i64, ptr %slot1373, align 8
  %cmp7738 = icmp ne i64 %v7737, 0
  %cv7739 = zext i1 %cmp7738 to i32
  store i32 %cv7739, ptr %slot1374, align 8
  %v7740 = load i32, ptr %slot1374, align 8
  %cv7741 = zext i32 %v7740 to i64
  %cond7742 = icmp ne i64 %cv7741, 0
  br i1 %cond7742, label %bb_rcgspecial1714, label %bb_rcginc1714
bb_rcginc1714:
  %v7743 = load i64, ptr %slot1369, align 8
  %op7744 = sub i64 %v7743, 32
  store i64 %op7744, ptr %slot1375, align 8
  %v7745 = load i64, ptr %slot1369, align 8
  %p7746 = inttoptr i64 %v7745 to ptr
  %rgep7747 = getelementptr i8, ptr %p7746, i64 -32
  %ld7748 = load i64, ptr %rgep7747, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7748, ptr %slot1376, align 8
  %v7749 = load i64, ptr %slot1376, align 8
  %op7750 = add i64 %v7749, 1
  store i64 %op7750, ptr %slot1377, align 8
  %v7751 = load i64, ptr %slot1377, align 8
  %cmp7752 = icmp eq i64 %v7751, 0
  %cv7753 = zext i1 %cmp7752 to i32
  store i32 %cv7753, ptr %slot1378, align 8
  %v7754 = load i32, ptr %slot1378, align 8
  %cv7755 = zext i32 %v7754 to i64
  %cond7756 = icmp ne i64 %cv7755, 0
  br i1 %cond7756, label %bb_rcglimit1714, label %bb_rcgcapacity1714
bb_rcglimit1714:
  %v7757 = load i64, ptr %slot1, align 8
  %p7758 = inttoptr i64 %v7757 to ptr
  %call7759 = call i32 @myl_qbe_rc_status(ptr %p7758, i32 2) nomerge, !dbg !170
  store i32 %call7759, ptr %slot1379, align 8
  br label %bb_failure
bb_rcgcapacity1714:
  %v7760 = load i64, ptr %slot1377, align 8
  %v7761 = load i64, ptr %slot1369, align 8
  %p7762 = inttoptr i64 %v7761 to ptr
  %rgep7763 = getelementptr i8, ptr %p7762, i64 -32
  store i64 %v7760, ptr %rgep7763, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1714
bb_rcgspecial1714:
  %v7764 = load i64, ptr %slot1372, align 8
  %op7765 = and i64 %v7764, 4611686018427387904
  store i64 %op7765, ptr %slot1380, align 8
  %v7766 = load i64, ptr %slot1380, align 8
  %cmp7767 = icmp ne i64 %v7766, 0
  %cv7768 = zext i1 %cmp7767 to i32
  store i32 %cv7768, ptr %slot1381, align 8
  %v7769 = load i32, ptr %slot1381, align 8
  %cv7770 = zext i32 %v7769 to i64
  %cond7771 = icmp ne i64 %cv7770, 0
  br i1 %cond7771, label %bb_rcgslow1714, label %bb_rcgplain1714
bb_rcgslow1714:
  %v7772 = load i64, ptr %slot59, align 8
  %v7773 = load i64, ptr %slot1367, align 8
  %v7774 = load i64, ptr %slot1345, align 8
  %v7775 = load i64, ptr %slot1368, align 8
  %cv7776 = trunc i64 %v7775 to i32
  %call7777 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64 %v7772, i64 %v7773, i64 %v7774, i32 %cv7776) nomerge, !dbg !170
  store i32 %call7777, ptr %slot1382, align 8
  %v7778 = load i32, ptr %slot1382, align 8
  %cv7779 = zext i32 %v7778 to i64
  %cond7780 = icmp ne i64 %cv7779, 0
  br i1 %cond7780, label %bb_rcsuccess1728, label %bb_rcfailure1728
bb_rcfailure1728:
  %v7781 = load i64, ptr %slot59, align 8
  %p7782 = inttoptr i64 %v7781 to ptr
  %call7783 = call i32 @myl_rc_take_failure(ptr %p7782) nomerge, !dbg !170
  store i32 %call7783, ptr %slot1383, align 8
  %v7784 = load i64, ptr %slot1, align 8
  %p7785 = inttoptr i64 %v7784 to ptr
  %v7786 = load i32, ptr %slot1383, align 8
  %call7787 = call i32 @myl_qbe_rc_status(ptr %p7785, i32 %v7786) nomerge, !dbg !170
  store i32 %call7787, ptr %slot1384, align 8
  br label %bb_failure
bb_rcsuccess1728:
  br label %bb_rcgdone1714
bb_rcgplain1714:
  %v7788 = load i64, ptr %slot1369, align 8
  %v7789 = load i64, ptr %slot1367, align 8
  %p7790 = inttoptr i64 %v7789 to ptr
  store i64 %v7788, ptr %p7790, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1714
bb_rcgdone1714:
  %v7791 = load i64, ptr %slot22, align 8
  %p7792 = inttoptr i64 %v7791 to ptr
  store i32 2, ptr %p7792, align 4, !alias.scope !3, !noalias !4
  %v7793 = load i64, ptr %slot21, align 8
  %p7794 = inttoptr i64 %v7793 to ptr
  store i32 1, ptr %p7794, align 4, !alias.scope !3, !noalias !4
  %v7795 = load i64, ptr %slot19, align 8
  %p7796 = inttoptr i64 %v7795 to ptr
  %ld7797 = load i32, ptr %p7796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7797, ptr %slot1385, align 8
  %v7798 = load i32, ptr %slot1385, align 8
  %cv7799 = zext i32 %v7798 to i64
  %cond7800 = icmp ne i64 %cv7799, 0
  br i1 %cond7800, label %bb_rcslotdrop1735, label %bb_rcslotdone1735
bb_rcslotdrop1735:
  %v7801 = load i64, ptr %slot19, align 8
  %p7802 = inttoptr i64 %v7801 to ptr
  store i32 0, ptr %p7802, align 4, !alias.scope !3, !noalias !4
  %v7803 = load i64, ptr %slot25, align 8
  store i64 %v7803, ptr %slot1386, align 8
  %v7804 = load i64, ptr %slot20, align 8
  %p7805 = inttoptr i64 %v7804 to ptr
  %ld7806 = load i32, ptr %p7805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7806, ptr %slot1387, align 8
  %v7807 = load i32, ptr %slot1387, align 8
  %op7808 = and i32 %v7807, 28
  store i32 %op7808, ptr %slot1388, align 8
  %v7809 = load i32, ptr %slot1388, align 8
  %cv7810 = zext i32 %v7809 to i64
  %cond7811 = icmp ne i64 %cv7810, 0
  br i1 %cond7811, label %bb_rcslotrole1735, label %bb_rcslotowner1735
bb_rcslotrole1735:
  %v7812 = load i64, ptr %slot59, align 8
  store i64 %v7812, ptr %slot1389, align 8
  %v7813 = load i64, ptr %slot1386, align 8
  %p7814 = inttoptr i64 %v7813 to ptr
  %ld7815 = load i64, ptr %p7814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7815, ptr %slot1390, align 8
  %v7816 = load i64, ptr %slot1390, align 8
  %cmp7817 = icmp ne i64 %v7816, 0
  %cv7818 = zext i1 %cmp7817 to i32
  store i32 %cv7818, ptr %slot1391, align 8
  %v7819 = load i32, ptr %slot1391, align 8
  %cv7820 = zext i32 %v7819 to i64
  %cond7821 = icmp ne i64 %cv7820, 0
  br i1 %cond7821, label %bb_rcgnn1751, label %bb_rcgdone1751
bb_rcgnn1751:
  %v7822 = load i64, ptr %slot1390, align 8
  %op7823 = sub i64 %v7822, 16
  store i64 %op7823, ptr %slot1392, align 8
  %v7824 = load i64, ptr %slot1390, align 8
  %p7825 = inttoptr i64 %v7824 to ptr
  %rgep7826 = getelementptr i8, ptr %p7825, i64 -16
  %ld7827 = load i64, ptr %rgep7826, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7827, ptr %slot1393, align 8
  %v7828 = load i64, ptr %slot1393, align 8
  %op7829 = and i64 %v7828, 4611686018427387906
  store i64 %op7829, ptr %slot1394, align 8
  %v7830 = load i64, ptr %slot1394, align 8
  %cmp7831 = icmp ne i64 %v7830, 0
  %cv7832 = zext i1 %cmp7831 to i32
  store i32 %cv7832, ptr %slot1395, align 8
  %v7833 = load i32, ptr %slot1395, align 8
  %cv7834 = zext i32 %v7833 to i64
  %cond7835 = icmp ne i64 %cv7834, 0
  br i1 %cond7835, label %bb_rcgclear1751, label %bb_rcgcounted1751
bb_rcgcounted1751:
  %v7836 = load i64, ptr %slot1390, align 8
  %op7837 = sub i64 %v7836, 24
  store i64 %op7837, ptr %slot1396, align 8
  %v7838 = load i64, ptr %slot1390, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  %rgep7840 = getelementptr i8, ptr %p7839, i64 -24
  %ld7841 = load i64, ptr %rgep7840, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7841, ptr %slot1397, align 8
  %v7842 = load i64, ptr %slot1397, align 8
  %op7843 = sub i64 %v7842, 1
  store i64 %op7843, ptr %slot1398, align 8
  %v7844 = load i64, ptr %slot1398, align 8
  %cmp7845 = icmp eq i64 %v7844, 0
  %cv7846 = zext i1 %cmp7845 to i32
  store i32 %cv7846, ptr %slot1399, align 8
  %v7847 = load i32, ptr %slot1399, align 8
  %cv7848 = zext i32 %v7847 to i64
  %cond7849 = icmp ne i64 %cv7848, 0
  br i1 %cond7849, label %bb_rcglast1751, label %bb_rcgdec1751
bb_rcglast1751:
  %v7850 = load i64, ptr %slot1390, align 8
  %op7851 = sub i64 %v7850, 32
  store i64 %op7851, ptr %slot1400, align 8
  %v7852 = load i64, ptr %slot1390, align 8
  %p7853 = inttoptr i64 %v7852 to ptr
  %rgep7854 = getelementptr i8, ptr %p7853, i64 -32
  %ld7855 = load i64, ptr %rgep7854, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7855, ptr %slot1401, align 8
  %v7856 = load i64, ptr %slot1401, align 8
  %cmp7857 = icmp ne i64 %v7856, 0
  %cv7858 = zext i1 %cmp7857 to i32
  store i32 %cv7858, ptr %slot1402, align 8
  %v7859 = load i32, ptr %slot1402, align 8
  %cv7860 = zext i32 %v7859 to i64
  %cond7861 = icmp ne i64 %cv7860, 0
  br i1 %cond7861, label %bb_rcgdec1751, label %bb_rcgslow1751
bb_rcgslow1751:
  %v7862 = load i64, ptr %slot1389, align 8
  %v7863 = load i64, ptr %slot1386, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v7862, i64 %v7863) nomerge, !dbg !170
  br label %bb_rcgdone1751
bb_rcgdec1751:
  %v7864 = load i64, ptr %slot1398, align 8
  %v7865 = load i64, ptr %slot1390, align 8
  %p7866 = inttoptr i64 %v7865 to ptr
  %rgep7867 = getelementptr i8, ptr %p7866, i64 -24
  store i64 %v7864, ptr %rgep7867, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1751
bb_rcgclear1751:
  %v7868 = load i64, ptr %slot1386, align 8
  %p7869 = inttoptr i64 %v7868 to ptr
  store i64 0, ptr %p7869, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1751
bb_rcgdone1751:
  br label %bb_rcslotdone1735
bb_rcslotowner1735:
  %v7870 = load i64, ptr %slot59, align 8
  store i64 %v7870, ptr %slot1403, align 8
  %v7871 = load i64, ptr %slot1386, align 8
  %p7872 = inttoptr i64 %v7871 to ptr
  %ld7873 = load i64, ptr %p7872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7873, ptr %slot1404, align 8
  %v7874 = load i64, ptr %slot1404, align 8
  %cmp7875 = icmp ne i64 %v7874, 0
  %cv7876 = zext i1 %cmp7875 to i32
  store i32 %cv7876, ptr %slot1405, align 8
  %v7877 = load i32, ptr %slot1405, align 8
  %cv7878 = zext i32 %v7877 to i64
  %cond7879 = icmp ne i64 %cv7878, 0
  br i1 %cond7879, label %bb_rcgnn1766, label %bb_rcgdone1766
bb_rcgnn1766:
  %v7880 = load i64, ptr %slot1404, align 8
  %op7881 = sub i64 %v7880, 16
  store i64 %op7881, ptr %slot1406, align 8
  %v7882 = load i64, ptr %slot1404, align 8
  %p7883 = inttoptr i64 %v7882 to ptr
  %rgep7884 = getelementptr i8, ptr %p7883, i64 -16
  %ld7885 = load i64, ptr %rgep7884, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7885, ptr %slot1407, align 8
  %v7886 = load i64, ptr %slot1407, align 8
  %op7887 = and i64 %v7886, 4611686018427387906
  store i64 %op7887, ptr %slot1408, align 8
  %v7888 = load i64, ptr %slot1408, align 8
  %cmp7889 = icmp ne i64 %v7888, 0
  %cv7890 = zext i1 %cmp7889 to i32
  store i32 %cv7890, ptr %slot1409, align 8
  %v7891 = load i32, ptr %slot1409, align 8
  %cv7892 = zext i32 %v7891 to i64
  %cond7893 = icmp ne i64 %cv7892, 0
  br i1 %cond7893, label %bb_rcgclear1766, label %bb_rcgcounted1766
bb_rcgcounted1766:
  %v7894 = load i64, ptr %slot1404, align 8
  %op7895 = sub i64 %v7894, 32
  store i64 %op7895, ptr %slot1410, align 8
  %v7896 = load i64, ptr %slot1404, align 8
  %p7897 = inttoptr i64 %v7896 to ptr
  %rgep7898 = getelementptr i8, ptr %p7897, i64 -32
  %ld7899 = load i64, ptr %rgep7898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7899, ptr %slot1411, align 8
  %v7900 = load i64, ptr %slot1411, align 8
  %op7901 = sub i64 %v7900, 1
  store i64 %op7901, ptr %slot1412, align 8
  %v7902 = load i64, ptr %slot1412, align 8
  %cmp7903 = icmp eq i64 %v7902, 0
  %cv7904 = zext i1 %cmp7903 to i32
  store i32 %cv7904, ptr %slot1413, align 8
  %v7905 = load i32, ptr %slot1413, align 8
  %cv7906 = zext i32 %v7905 to i64
  %cond7907 = icmp ne i64 %cv7906, 0
  br i1 %cond7907, label %bb_rcglast1766, label %bb_rcgdec1766
bb_rcglast1766:
  %v7908 = load i64, ptr %slot1404, align 8
  %op7909 = sub i64 %v7908, 24
  store i64 %op7909, ptr %slot1414, align 8
  %v7910 = load i64, ptr %slot1404, align 8
  %p7911 = inttoptr i64 %v7910 to ptr
  %rgep7912 = getelementptr i8, ptr %p7911, i64 -24
  %ld7913 = load i64, ptr %rgep7912, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7913, ptr %slot1415, align 8
  %v7914 = load i64, ptr %slot1415, align 8
  %cmp7915 = icmp ne i64 %v7914, 0
  %cv7916 = zext i1 %cmp7915 to i32
  store i32 %cv7916, ptr %slot1416, align 8
  %v7917 = load i32, ptr %slot1416, align 8
  %cv7918 = zext i32 %v7917 to i64
  %cond7919 = icmp ne i64 %cv7918, 0
  br i1 %cond7919, label %bb_rcgdec1766, label %bb_rcgslow1766
bb_rcgslow1766:
  %v7920 = load i64, ptr %slot1403, align 8
  %v7921 = load i64, ptr %slot1386, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7920, i64 %v7921) nomerge, !dbg !170
  br label %bb_rcgdone1766
bb_rcgdec1766:
  %v7922 = load i64, ptr %slot1412, align 8
  %v7923 = load i64, ptr %slot1404, align 8
  %p7924 = inttoptr i64 %v7923 to ptr
  %rgep7925 = getelementptr i8, ptr %p7924, i64 -32
  store i64 %v7922, ptr %rgep7925, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1766
bb_rcgclear1766:
  %v7926 = load i64, ptr %slot1386, align 8
  %p7927 = inttoptr i64 %v7926 to ptr
  store i64 0, ptr %p7927, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1766
bb_rcgdone1766:
  br label %bb_rcslotdone1735
bb_rcslotdone1735:
  br label %bb_rcprepared1681
bb_rcprepared1681:
  %v7928 = load i64, ptr %slot28, align 8
  store i64 %v7928, ptr %slot1417, align 8
  %v7929 = load i64, ptr %slot1417, align 8
  %v7930 = load i64, ptr %slot1343, align 8
  %p7931 = inttoptr i64 %v7929 to ptr
  %p7932 = inttoptr i64 %v7930 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7932, ptr %p7931, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7933 = load i64, ptr %slot21, align 8
  %p7934 = inttoptr i64 %v7933 to ptr
  store i32 0, ptr %p7934, align 4, !alias.scope !3, !noalias !4
  %v7935 = load i64, ptr %slot22, align 8
  %p7936 = inttoptr i64 %v7935 to ptr
  store i32 2, ptr %p7936, align 4, !alias.scope !3, !noalias !4
  %v7937 = load i64, ptr %slot21, align 8
  %p7938 = inttoptr i64 %v7937 to ptr
  store i32 1, ptr %p7938, align 4, !alias.scope !3, !noalias !4
  %v7939 = load i64, ptr %slot59, align 8
  store i64 %v7939, ptr %slot1418, align 8
  %v7940 = load i64, ptr %slot1342, align 8
  %p7941 = inttoptr i64 %v7940 to ptr
  %ld7942 = load i64, ptr %p7941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7942, ptr %slot1419, align 8
  %v7943 = load i64, ptr %slot1419, align 8
  %cmp7944 = icmp ne i64 %v7943, 0
  %cv7945 = zext i1 %cmp7944 to i32
  store i32 %cv7945, ptr %slot1420, align 8
  %v7946 = load i32, ptr %slot1420, align 8
  %cv7947 = zext i32 %v7946 to i64
  %cond7948 = icmp ne i64 %cv7947, 0
  br i1 %cond7948, label %bb_rcgnn1785, label %bb_rcgdone1785
bb_rcgnn1785:
  %v7949 = load i64, ptr %slot1419, align 8
  %op7950 = sub i64 %v7949, 16
  store i64 %op7950, ptr %slot1421, align 8
  %v7951 = load i64, ptr %slot1419, align 8
  %p7952 = inttoptr i64 %v7951 to ptr
  %rgep7953 = getelementptr i8, ptr %p7952, i64 -16
  %ld7954 = load i64, ptr %rgep7953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7954, ptr %slot1422, align 8
  %v7955 = load i64, ptr %slot1422, align 8
  %op7956 = and i64 %v7955, 4611686018427387906
  store i64 %op7956, ptr %slot1423, align 8
  %v7957 = load i64, ptr %slot1423, align 8
  %cmp7958 = icmp ne i64 %v7957, 0
  %cv7959 = zext i1 %cmp7958 to i32
  store i32 %cv7959, ptr %slot1424, align 8
  %v7960 = load i32, ptr %slot1424, align 8
  %cv7961 = zext i32 %v7960 to i64
  %cond7962 = icmp ne i64 %cv7961, 0
  br i1 %cond7962, label %bb_rcgclear1785, label %bb_rcgcounted1785
bb_rcgcounted1785:
  %v7963 = load i64, ptr %slot1419, align 8
  %op7964 = sub i64 %v7963, 32
  store i64 %op7964, ptr %slot1425, align 8
  %v7965 = load i64, ptr %slot1419, align 8
  %p7966 = inttoptr i64 %v7965 to ptr
  %rgep7967 = getelementptr i8, ptr %p7966, i64 -32
  %ld7968 = load i64, ptr %rgep7967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7968, ptr %slot1426, align 8
  %v7969 = load i64, ptr %slot1426, align 8
  %op7970 = sub i64 %v7969, 1
  store i64 %op7970, ptr %slot1427, align 8
  %v7971 = load i64, ptr %slot1427, align 8
  %cmp7972 = icmp eq i64 %v7971, 0
  %cv7973 = zext i1 %cmp7972 to i32
  store i32 %cv7973, ptr %slot1428, align 8
  %v7974 = load i32, ptr %slot1428, align 8
  %cv7975 = zext i32 %v7974 to i64
  %cond7976 = icmp ne i64 %cv7975, 0
  br i1 %cond7976, label %bb_rcglast1785, label %bb_rcgdec1785
bb_rcglast1785:
  %v7977 = load i64, ptr %slot1419, align 8
  %op7978 = sub i64 %v7977, 24
  store i64 %op7978, ptr %slot1429, align 8
  %v7979 = load i64, ptr %slot1419, align 8
  %p7980 = inttoptr i64 %v7979 to ptr
  %rgep7981 = getelementptr i8, ptr %p7980, i64 -24
  %ld7982 = load i64, ptr %rgep7981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7982, ptr %slot1430, align 8
  %v7983 = load i64, ptr %slot1430, align 8
  %cmp7984 = icmp ne i64 %v7983, 0
  %cv7985 = zext i1 %cmp7984 to i32
  store i32 %cv7985, ptr %slot1431, align 8
  %v7986 = load i32, ptr %slot1431, align 8
  %cv7987 = zext i32 %v7986 to i64
  %cond7988 = icmp ne i64 %cv7987, 0
  br i1 %cond7988, label %bb_rcgdec1785, label %bb_rcgslow1785
bb_rcgslow1785:
  %v7989 = load i64, ptr %slot1418, align 8
  %v7990 = load i64, ptr %slot1342, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7989, i64 %v7990) nomerge, !dbg !170
  br label %bb_rcgdone1785
bb_rcgdec1785:
  %v7991 = load i64, ptr %slot1427, align 8
  %v7992 = load i64, ptr %slot1419, align 8
  %p7993 = inttoptr i64 %v7992 to ptr
  %rgep7994 = getelementptr i8, ptr %p7993, i64 -32
  store i64 %v7991, ptr %rgep7994, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1785
bb_rcgclear1785:
  %v7995 = load i64, ptr %slot1342, align 8
  %p7996 = inttoptr i64 %v7995 to ptr
  store i64 0, ptr %p7996, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1785
bb_rcgdone1785:
  %v7997 = load i64, ptr %slot1343, align 8
  %v7998 = load i64, ptr %slot1342, align 8
  %p7999 = inttoptr i64 %v7997 to ptr
  %p8000 = inttoptr i64 %v7998 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8000, ptr %p7999, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8001 = load i64, ptr %slot21, align 8
  %p8002 = inttoptr i64 %v8001 to ptr
  store i32 0, ptr %p8002, align 4, !alias.scope !3, !noalias !4
  %v8003 = load i64, ptr %slot1338, align 8
  %v8004 = load i64, ptr %slot50, align 8
  %p8005 = inttoptr i64 %v8004 to ptr
  store i64 %v8003, ptr %p8005, align 8, !alias.scope !3, !noalias !4
  %v8006 = load i64, ptr %slot50, align 8
  %p8007 = inttoptr i64 %v8006 to ptr
  %ld8008 = load i64, ptr %p8007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8008, ptr %slot1432, align 8
  %v8009 = load i64, ptr %slot28, align 8
  store i64 %v8009, ptr %slot1433, align 8
  %v8010 = load i64, ptr %slot1432, align 8
  %v8011 = load i64, ptr %slot1433, align 8
  %p8012 = inttoptr i64 %v8010 to ptr
  %p8013 = inttoptr i64 %v8011 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8013, ptr %p8012, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v8014 = load i64, ptr %slot22, align 8
  %p8015 = inttoptr i64 %v8014 to ptr
  store i32 2, ptr %p8015, align 4, !alias.scope !3, !noalias !4
  %v8016 = load i64, ptr %slot21, align 8
  %p8017 = inttoptr i64 %v8016 to ptr
  store i32 1, ptr %p8017, align 4, !alias.scope !3, !noalias !4
  %v8018 = load i64, ptr %slot17, align 8
  %p8019 = inttoptr i64 %v8018 to ptr
  %ld8020 = load i32, ptr %p8019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8020, ptr %slot1434, align 8
  %v8021 = load i32, ptr %slot1434, align 8
  %cv8022 = zext i32 %v8021 to i64
  %cond8023 = icmp ne i64 %cv8022, 0
  br i1 %cond8023, label %bb_rcslotdrop1796, label %bb_rcslotdone1796
bb_rcslotdrop1796:
  %v8024 = load i64, ptr %slot17, align 8
  %p8025 = inttoptr i64 %v8024 to ptr
  store i32 0, ptr %p8025, align 4, !alias.scope !3, !noalias !4
  %v8026 = load i64, ptr %slot24, align 8
  store i64 %v8026, ptr %slot1435, align 8
  %v8027 = load i64, ptr %slot18, align 8
  %p8028 = inttoptr i64 %v8027 to ptr
  %ld8029 = load i32, ptr %p8028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8029, ptr %slot1436, align 8
  %v8030 = load i32, ptr %slot1436, align 8
  %op8031 = and i32 %v8030, 28
  store i32 %op8031, ptr %slot1437, align 8
  %v8032 = load i32, ptr %slot1437, align 8
  %cv8033 = zext i32 %v8032 to i64
  %cond8034 = icmp ne i64 %cv8033, 0
  br i1 %cond8034, label %bb_rcslotrole1796, label %bb_rcslotowner1796
bb_rcslotrole1796:
  %v8035 = load i64, ptr %slot59, align 8
  store i64 %v8035, ptr %slot1438, align 8
  %v8036 = load i64, ptr %slot1438, align 8
  %v8037 = load i64, ptr %slot1435, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8036, i64 %v8037) nomerge, !dbg !170
  br label %bb_rcslotdone1796
bb_rcslotowner1796:
  %v8038 = load i64, ptr %slot59, align 8
  store i64 %v8038, ptr %slot1439, align 8
  %v8039 = load i64, ptr %slot1439, align 8
  %v8040 = load i64, ptr %slot1435, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8039, i64 %v8040) nomerge, !dbg !170
  br label %bb_rcslotdone1796
bb_rcslotdone1796:
  %v8041 = load i64, ptr %slot19, align 8
  %p8042 = inttoptr i64 %v8041 to ptr
  %ld8043 = load i32, ptr %p8042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8043, ptr %slot1440, align 8
  %v8044 = load i32, ptr %slot1440, align 8
  %cv8045 = zext i32 %v8044 to i64
  %cond8046 = icmp ne i64 %cv8045, 0
  br i1 %cond8046, label %bb_rcslotdrop1805, label %bb_rcslotdone1805
bb_rcslotdrop1805:
  %v8047 = load i64, ptr %slot19, align 8
  %p8048 = inttoptr i64 %v8047 to ptr
  store i32 0, ptr %p8048, align 4, !alias.scope !3, !noalias !4
  %v8049 = load i64, ptr %slot25, align 8
  store i64 %v8049, ptr %slot1441, align 8
  %v8050 = load i64, ptr %slot20, align 8
  %p8051 = inttoptr i64 %v8050 to ptr
  %ld8052 = load i32, ptr %p8051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8052, ptr %slot1442, align 8
  %v8053 = load i32, ptr %slot1442, align 8
  %op8054 = and i32 %v8053, 28
  store i32 %op8054, ptr %slot1443, align 8
  %v8055 = load i32, ptr %slot1443, align 8
  %cv8056 = zext i32 %v8055 to i64
  %cond8057 = icmp ne i64 %cv8056, 0
  br i1 %cond8057, label %bb_rcslotrole1805, label %bb_rcslotowner1805
bb_rcslotrole1805:
  %v8058 = load i64, ptr %slot59, align 8
  store i64 %v8058, ptr %slot1444, align 8
  %v8059 = load i64, ptr %slot1441, align 8
  %p8060 = inttoptr i64 %v8059 to ptr
  %ld8061 = load i64, ptr %p8060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8061, ptr %slot1445, align 8
  %v8062 = load i64, ptr %slot1445, align 8
  %cmp8063 = icmp ne i64 %v8062, 0
  %cv8064 = zext i1 %cmp8063 to i32
  store i32 %cv8064, ptr %slot1446, align 8
  %v8065 = load i32, ptr %slot1446, align 8
  %cv8066 = zext i32 %v8065 to i64
  %cond8067 = icmp ne i64 %cv8066, 0
  br i1 %cond8067, label %bb_rcgnn1821, label %bb_rcgdone1821
bb_rcgnn1821:
  %v8068 = load i64, ptr %slot1445, align 8
  %op8069 = sub i64 %v8068, 16
  store i64 %op8069, ptr %slot1447, align 8
  %v8070 = load i64, ptr %slot1445, align 8
  %p8071 = inttoptr i64 %v8070 to ptr
  %rgep8072 = getelementptr i8, ptr %p8071, i64 -16
  %ld8073 = load i64, ptr %rgep8072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8073, ptr %slot1448, align 8
  %v8074 = load i64, ptr %slot1448, align 8
  %op8075 = and i64 %v8074, 4611686018427387906
  store i64 %op8075, ptr %slot1449, align 8
  %v8076 = load i64, ptr %slot1449, align 8
  %cmp8077 = icmp ne i64 %v8076, 0
  %cv8078 = zext i1 %cmp8077 to i32
  store i32 %cv8078, ptr %slot1450, align 8
  %v8079 = load i32, ptr %slot1450, align 8
  %cv8080 = zext i32 %v8079 to i64
  %cond8081 = icmp ne i64 %cv8080, 0
  br i1 %cond8081, label %bb_rcgclear1821, label %bb_rcgcounted1821
bb_rcgcounted1821:
  %v8082 = load i64, ptr %slot1445, align 8
  %op8083 = sub i64 %v8082, 24
  store i64 %op8083, ptr %slot1451, align 8
  %v8084 = load i64, ptr %slot1445, align 8
  %p8085 = inttoptr i64 %v8084 to ptr
  %rgep8086 = getelementptr i8, ptr %p8085, i64 -24
  %ld8087 = load i64, ptr %rgep8086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8087, ptr %slot1452, align 8
  %v8088 = load i64, ptr %slot1452, align 8
  %op8089 = sub i64 %v8088, 1
  store i64 %op8089, ptr %slot1453, align 8
  %v8090 = load i64, ptr %slot1453, align 8
  %cmp8091 = icmp eq i64 %v8090, 0
  %cv8092 = zext i1 %cmp8091 to i32
  store i32 %cv8092, ptr %slot1454, align 8
  %v8093 = load i32, ptr %slot1454, align 8
  %cv8094 = zext i32 %v8093 to i64
  %cond8095 = icmp ne i64 %cv8094, 0
  br i1 %cond8095, label %bb_rcglast1821, label %bb_rcgdec1821
bb_rcglast1821:
  %v8096 = load i64, ptr %slot1445, align 8
  %op8097 = sub i64 %v8096, 32
  store i64 %op8097, ptr %slot1455, align 8
  %v8098 = load i64, ptr %slot1445, align 8
  %p8099 = inttoptr i64 %v8098 to ptr
  %rgep8100 = getelementptr i8, ptr %p8099, i64 -32
  %ld8101 = load i64, ptr %rgep8100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8101, ptr %slot1456, align 8
  %v8102 = load i64, ptr %slot1456, align 8
  %cmp8103 = icmp ne i64 %v8102, 0
  %cv8104 = zext i1 %cmp8103 to i32
  store i32 %cv8104, ptr %slot1457, align 8
  %v8105 = load i32, ptr %slot1457, align 8
  %cv8106 = zext i32 %v8105 to i64
  %cond8107 = icmp ne i64 %cv8106, 0
  br i1 %cond8107, label %bb_rcgdec1821, label %bb_rcgslow1821
bb_rcgslow1821:
  %v8108 = load i64, ptr %slot1444, align 8
  %v8109 = load i64, ptr %slot1441, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v8108, i64 %v8109) nomerge, !dbg !170
  br label %bb_rcgdone1821
bb_rcgdec1821:
  %v8110 = load i64, ptr %slot1453, align 8
  %v8111 = load i64, ptr %slot1445, align 8
  %p8112 = inttoptr i64 %v8111 to ptr
  %rgep8113 = getelementptr i8, ptr %p8112, i64 -24
  store i64 %v8110, ptr %rgep8113, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1821
bb_rcgclear1821:
  %v8114 = load i64, ptr %slot1441, align 8
  %p8115 = inttoptr i64 %v8114 to ptr
  store i64 0, ptr %p8115, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1821
bb_rcgdone1821:
  br label %bb_rcslotdone1805
bb_rcslotowner1805:
  %v8116 = load i64, ptr %slot59, align 8
  store i64 %v8116, ptr %slot1458, align 8
  %v8117 = load i64, ptr %slot1441, align 8
  %p8118 = inttoptr i64 %v8117 to ptr
  %ld8119 = load i64, ptr %p8118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8119, ptr %slot1459, align 8
  %v8120 = load i64, ptr %slot1459, align 8
  %cmp8121 = icmp ne i64 %v8120, 0
  %cv8122 = zext i1 %cmp8121 to i32
  store i32 %cv8122, ptr %slot1460, align 8
  %v8123 = load i32, ptr %slot1460, align 8
  %cv8124 = zext i32 %v8123 to i64
  %cond8125 = icmp ne i64 %cv8124, 0
  br i1 %cond8125, label %bb_rcgnn1836, label %bb_rcgdone1836
bb_rcgnn1836:
  %v8126 = load i64, ptr %slot1459, align 8
  %op8127 = sub i64 %v8126, 16
  store i64 %op8127, ptr %slot1461, align 8
  %v8128 = load i64, ptr %slot1459, align 8
  %p8129 = inttoptr i64 %v8128 to ptr
  %rgep8130 = getelementptr i8, ptr %p8129, i64 -16
  %ld8131 = load i64, ptr %rgep8130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8131, ptr %slot1462, align 8
  %v8132 = load i64, ptr %slot1462, align 8
  %op8133 = and i64 %v8132, 4611686018427387906
  store i64 %op8133, ptr %slot1463, align 8
  %v8134 = load i64, ptr %slot1463, align 8
  %cmp8135 = icmp ne i64 %v8134, 0
  %cv8136 = zext i1 %cmp8135 to i32
  store i32 %cv8136, ptr %slot1464, align 8
  %v8137 = load i32, ptr %slot1464, align 8
  %cv8138 = zext i32 %v8137 to i64
  %cond8139 = icmp ne i64 %cv8138, 0
  br i1 %cond8139, label %bb_rcgclear1836, label %bb_rcgcounted1836
bb_rcgcounted1836:
  %v8140 = load i64, ptr %slot1459, align 8
  %op8141 = sub i64 %v8140, 32
  store i64 %op8141, ptr %slot1465, align 8
  %v8142 = load i64, ptr %slot1459, align 8
  %p8143 = inttoptr i64 %v8142 to ptr
  %rgep8144 = getelementptr i8, ptr %p8143, i64 -32
  %ld8145 = load i64, ptr %rgep8144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8145, ptr %slot1466, align 8
  %v8146 = load i64, ptr %slot1466, align 8
  %op8147 = sub i64 %v8146, 1
  store i64 %op8147, ptr %slot1467, align 8
  %v8148 = load i64, ptr %slot1467, align 8
  %cmp8149 = icmp eq i64 %v8148, 0
  %cv8150 = zext i1 %cmp8149 to i32
  store i32 %cv8150, ptr %slot1468, align 8
  %v8151 = load i32, ptr %slot1468, align 8
  %cv8152 = zext i32 %v8151 to i64
  %cond8153 = icmp ne i64 %cv8152, 0
  br i1 %cond8153, label %bb_rcglast1836, label %bb_rcgdec1836
bb_rcglast1836:
  %v8154 = load i64, ptr %slot1459, align 8
  %op8155 = sub i64 %v8154, 24
  store i64 %op8155, ptr %slot1469, align 8
  %v8156 = load i64, ptr %slot1459, align 8
  %p8157 = inttoptr i64 %v8156 to ptr
  %rgep8158 = getelementptr i8, ptr %p8157, i64 -24
  %ld8159 = load i64, ptr %rgep8158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8159, ptr %slot1470, align 8
  %v8160 = load i64, ptr %slot1470, align 8
  %cmp8161 = icmp ne i64 %v8160, 0
  %cv8162 = zext i1 %cmp8161 to i32
  store i32 %cv8162, ptr %slot1471, align 8
  %v8163 = load i32, ptr %slot1471, align 8
  %cv8164 = zext i32 %v8163 to i64
  %cond8165 = icmp ne i64 %cv8164, 0
  br i1 %cond8165, label %bb_rcgdec1836, label %bb_rcgslow1836
bb_rcgslow1836:
  %v8166 = load i64, ptr %slot1458, align 8
  %v8167 = load i64, ptr %slot1441, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8166, i64 %v8167) nomerge, !dbg !170
  br label %bb_rcgdone1836
bb_rcgdec1836:
  %v8168 = load i64, ptr %slot1467, align 8
  %v8169 = load i64, ptr %slot1459, align 8
  %p8170 = inttoptr i64 %v8169 to ptr
  %rgep8171 = getelementptr i8, ptr %p8170, i64 -32
  store i64 %v8168, ptr %rgep8171, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1836
bb_rcgclear1836:
  %v8172 = load i64, ptr %slot1441, align 8
  %p8173 = inttoptr i64 %v8172 to ptr
  store i64 0, ptr %p8173, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1836
bb_rcgdone1836:
  br label %bb_rcslotdone1805
bb_rcslotdone1805:
  %v8174 = load i64, ptr %slot24, align 8
  store i64 %v8174, ptr %slot1472, align 8
  %v8175 = load i64, ptr %slot28, align 8
  store i64 %v8175, ptr %slot1473, align 8
  %v8176 = load i64, ptr %slot1473, align 8
  %v8177 = load i64, ptr %slot1472, align 8
  %p8178 = inttoptr i64 %v8176 to ptr
  %p8179 = inttoptr i64 %v8177 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8179, ptr %p8178, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v8180 = load i64, ptr %slot18, align 8
  %p8181 = inttoptr i64 %v8180 to ptr
  store i32 2, ptr %p8181, align 4, !alias.scope !3, !noalias !4
  %v8182 = load i64, ptr %slot22, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  %ld8184 = load i32, ptr %p8183, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8184, ptr %slot1474, align 8
  %v8185 = load i32, ptr %slot1474, align 8
  %v8186 = load i64, ptr %slot18, align 8
  %p8187 = inttoptr i64 %v8186 to ptr
  store i32 %v8185, ptr %p8187, align 4, !alias.scope !3, !noalias !4
  %v8188 = load i64, ptr %slot21, align 8
  %p8189 = inttoptr i64 %v8188 to ptr
  store i32 0, ptr %p8189, align 4, !alias.scope !3, !noalias !4
  %v8190 = load i64, ptr %slot17, align 8
  %p8191 = inttoptr i64 %v8190 to ptr
  store i32 1, ptr %p8191, align 4, !alias.scope !3, !noalias !4
  %v8192 = load i64, ptr %slot1472, align 8
  %v8193 = load i64, ptr %slot50, align 8
  %p8194 = inttoptr i64 %v8193 to ptr
  store i64 %v8192, ptr %p8194, align 8, !alias.scope !3, !noalias !4
  %v8195 = load i64, ptr %slot50, align 8
  %p8196 = inttoptr i64 %v8195 to ptr
  %ld8197 = load i64, ptr %p8196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8197, ptr %slot1475, align 8
  %v8198 = load i64, ptr %slot17, align 8
  %p8199 = inttoptr i64 %v8198 to ptr
  %ld8200 = load i32, ptr %p8199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8200, ptr %slot1476, align 8
  %v8201 = load i64, ptr %slot18, align 8
  %p8202 = inttoptr i64 %v8201 to ptr
  %ld8203 = load i32, ptr %p8202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8203, ptr %slot1477, align 8
  %v8204 = load i32, ptr %slot1477, align 8
  %op8205 = and i32 %v8204, 24
  store i32 %op8205, ptr %slot1477, align 8
  %v8206 = load i32, ptr %slot1477, align 8
  %cmp8207 = icmp eq i32 %v8206, 0
  %cv8208 = zext i1 %cmp8207 to i32
  store i32 %cv8208, ptr %slot1478, align 8
  %v8209 = load i32, ptr %slot1476, align 8
  %v8210 = load i32, ptr %slot1478, align 8
  %op8211 = and i32 %v8209, %v8210
  store i32 %op8211, ptr %slot1479, align 8
  %v8212 = load i32, ptr %slot1479, align 8
  %cv8213 = zext i32 %v8212 to i64
  %cond8214 = icmp ne i64 %cv8213, 0
  br i1 %cond8214, label %bb_rctake1849, label %bb_rccopy1849
bb_rctake1849:
  %v8215 = load i64, ptr %slot28, align 8
  store i64 %v8215, ptr %slot1480, align 8
  %v8216 = load i64, ptr %slot60, align 8
  store i64 %v8216, ptr %slot1481, align 8
  %v8217 = load i64, ptr %slot1475, align 8
  %v8218 = load i64, ptr %slot1480, align 8
  %op8219 = sub i64 %v8217, %v8218
  store i64 %op8219, ptr %slot1482, align 8
  %v8220 = load i64, ptr %slot1480, align 8
  %v8221 = load i64, ptr %slot1475, align 8
  %op8222 = sub i64 %v8220, %v8221
  store i64 %op8222, ptr %slot1483, align 8
  %v8223 = load i64, ptr %slot1482, align 8
  %cmp8224 = icmp ult i64 %v8223, 16
  %cv8225 = zext i1 %cmp8224 to i32
  store i32 %cv8225, ptr %slot1484, align 8
  %v8226 = load i64, ptr %slot1483, align 8
  %cmp8227 = icmp ult i64 %v8226, 16
  %cv8228 = zext i1 %cmp8227 to i32
  store i32 %cv8228, ptr %slot1485, align 8
  %v8229 = load i32, ptr %slot1484, align 8
  %v8230 = load i32, ptr %slot1485, align 8
  %op8231 = or i32 %v8229, %v8230
  store i32 %op8231, ptr %slot1486, align 8
  %v8232 = load i32, ptr %slot1486, align 8
  %cv8233 = zext i32 %v8232 to i64
  %cond8234 = icmp ne i64 %cv8233, 0
  br i1 %cond8234, label %bb_rcmoveslow1858, label %bb_rcmovecheck1858
bb_rcmovecheck1858:
  %v8235 = load i64, ptr %slot1475, align 8
  %op8236 = add i64 %v8235, 0
  store i64 %op8236, ptr %slot1487, align 8
  %v8237 = load i64, ptr %slot1487, align 8
  %p8238 = inttoptr i64 %v8237 to ptr
  %ld8239 = load i64, ptr %p8238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8239, ptr %slot1488, align 8
  %v8240 = load i64, ptr %slot1488, align 8
  %cmp8241 = icmp ne i64 %v8240, 0
  %cv8242 = zext i1 %cmp8241 to i32
  store i32 %cv8242, ptr %slot1489, align 8
  %v8243 = load i32, ptr %slot1489, align 8
  %cv8244 = zext i32 %v8243 to i64
  %cond8245 = icmp ne i64 %cv8244, 0
  br i1 %cond8245, label %bb_rcmoveheader1866, label %bb_rcmovenext1866
bb_rcmoveheader1866:
  %v8246 = load i64, ptr %slot1488, align 8
  %op8247 = sub i64 %v8246, 16
  store i64 %op8247, ptr %slot1490, align 8
  %v8248 = load i64, ptr %slot1488, align 8
  %p8249 = inttoptr i64 %v8248 to ptr
  %rgep8250 = getelementptr i8, ptr %p8249, i64 -16
  %ld8251 = load i64, ptr %rgep8250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8251, ptr %slot1491, align 8
  %v8252 = load i64, ptr %slot1491, align 8
  %op8253 = and i64 %v8252, 5764607523034234881
  store i64 %op8253, ptr %slot1492, align 8
  %v8254 = load i64, ptr %slot1492, align 8
  %cmp8255 = icmp ne i64 %v8254, 0
  %cv8256 = zext i1 %cmp8255 to i32
  store i32 %cv8256, ptr %slot1493, align 8
  %v8257 = load i32, ptr %slot1493, align 8
  %cv8258 = zext i32 %v8257 to i64
  %cond8259 = icmp ne i64 %cv8258, 0
  br i1 %cond8259, label %bb_rcmoveslow1858, label %bb_rcmovenext1866
bb_rcmovenext1866:
  %v8260 = load i64, ptr %slot1475, align 8
  %v8261 = load i64, ptr %slot1480, align 8
  %p8262 = inttoptr i64 %v8260 to ptr
  %p8263 = inttoptr i64 %v8261 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8263, ptr %p8262, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v8264 = load i64, ptr %slot1475, align 8
  %p8265 = inttoptr i64 %v8264 to ptr
  store i64 0, ptr %p8265, align 8, !alias.scope !3, !noalias !4
  %v8266 = load i64, ptr %slot1475, align 8
  %op8267 = add i64 %v8266, 8
  store i64 %op8267, ptr %slot1494, align 8
  %v8268 = load i64, ptr %slot1494, align 8
  %p8269 = inttoptr i64 %v8268 to ptr
  store i64 0, ptr %p8269, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1858
bb_rcmoveslow1858:
  %v8270 = load i64, ptr %slot59, align 8
  %v8271 = load i64, ptr %slot1480, align 8
  %v8272 = load i64, ptr %slot1475, align 8
  %v8273 = load i64, ptr %slot1481, align 8
  %cv8274 = trunc i64 %v8273 to i32
  %call8275 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v8270, i64 %v8271, i64 %v8272, i32 %cv8274) nomerge, !dbg !172
  store i32 %call8275, ptr %slot1495, align 8
  %v8276 = load i32, ptr %slot1495, align 8
  %cv8277 = zext i32 %v8276 to i64
  %cond8278 = icmp ne i64 %cv8277, 0
  br i1 %cond8278, label %bb_rcsuccess1874, label %bb_rcfailure1874
bb_rcfailure1874:
  %v8279 = load i64, ptr %slot59, align 8
  %p8280 = inttoptr i64 %v8279 to ptr
  %call8281 = call i32 @myl_rc_take_failure(ptr %p8280) nomerge, !dbg !172
  store i32 %call8281, ptr %slot1496, align 8
  %v8282 = load i64, ptr %slot1, align 8
  %p8283 = inttoptr i64 %v8282 to ptr
  %v8284 = load i32, ptr %slot1496, align 8
  %call8285 = call i32 @myl_qbe_rc_status(ptr %p8283, i32 %v8284) nomerge, !dbg !172
  store i32 %call8285, ptr %slot1497, align 8
  br label %bb_failure
bb_rcsuccess1874:
  br label %bb_rcmoved1858
bb_rcmoved1858:
  %v8286 = load i64, ptr %slot17, align 8
  %p8287 = inttoptr i64 %v8286 to ptr
  store i32 0, ptr %p8287, align 4, !alias.scope !3, !noalias !4
  %v8288 = load i64, ptr %slot22, align 8
  %p8289 = inttoptr i64 %v8288 to ptr
  store i32 2, ptr %p8289, align 4, !alias.scope !3, !noalias !4
  %v8290 = load i64, ptr %slot21, align 8
  %p8291 = inttoptr i64 %v8290 to ptr
  store i32 1, ptr %p8291, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1849
bb_rccopy1849:
  %v8292 = load i64, ptr %slot28, align 8
  store i64 %v8292, ptr %slot1498, align 8
  %v8293 = load i64, ptr %slot60, align 8
  store i64 %v8293, ptr %slot1499, align 8
  %v8294 = load i64, ptr %slot59, align 8
  %v8295 = load i64, ptr %slot1498, align 8
  %v8296 = load i64, ptr %slot1475, align 8
  %v8297 = load i64, ptr %slot1499, align 8
  %cv8298 = trunc i64 %v8297 to i32
  %call8299 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v8294, i64 %v8295, i64 %v8296, i32 %cv8298) nomerge, !dbg !172
  store i32 %call8299, ptr %slot1500, align 8
  %v8300 = load i32, ptr %slot1500, align 8
  %cv8301 = zext i32 %v8300 to i64
  %cond8302 = icmp ne i64 %cv8301, 0
  br i1 %cond8302, label %bb_rcsuccess1883, label %bb_rcfailure1883
bb_rcfailure1883:
  %v8303 = load i64, ptr %slot59, align 8
  %p8304 = inttoptr i64 %v8303 to ptr
  %call8305 = call i32 @myl_rc_take_failure(ptr %p8304) nomerge, !dbg !172
  store i32 %call8305, ptr %slot1501, align 8
  %v8306 = load i64, ptr %slot1, align 8
  %p8307 = inttoptr i64 %v8306 to ptr
  %v8308 = load i32, ptr %slot1501, align 8
  %call8309 = call i32 @myl_qbe_rc_status(ptr %p8307, i32 %v8308) nomerge, !dbg !172
  store i32 %call8309, ptr %slot1502, align 8
  br label %bb_failure
bb_rcsuccess1883:
  %v8310 = load i64, ptr %slot22, align 8
  %p8311 = inttoptr i64 %v8310 to ptr
  store i32 2, ptr %p8311, align 4, !alias.scope !3, !noalias !4
  %v8312 = load i64, ptr %slot21, align 8
  %p8313 = inttoptr i64 %v8312 to ptr
  store i32 1, ptr %p8313, align 4, !alias.scope !3, !noalias !4
  %v8314 = load i64, ptr %slot17, align 8
  %p8315 = inttoptr i64 %v8314 to ptr
  %ld8316 = load i32, ptr %p8315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8316, ptr %slot1503, align 8
  %v8317 = load i32, ptr %slot1503, align 8
  %cv8318 = zext i32 %v8317 to i64
  %cond8319 = icmp ne i64 %cv8318, 0
  br i1 %cond8319, label %bb_rcslotdrop1890, label %bb_rcslotdone1890
bb_rcslotdrop1890:
  %v8320 = load i64, ptr %slot17, align 8
  %p8321 = inttoptr i64 %v8320 to ptr
  store i32 0, ptr %p8321, align 4, !alias.scope !3, !noalias !4
  %v8322 = load i64, ptr %slot24, align 8
  store i64 %v8322, ptr %slot1504, align 8
  %v8323 = load i64, ptr %slot18, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  %ld8325 = load i32, ptr %p8324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8325, ptr %slot1505, align 8
  %v8326 = load i32, ptr %slot1505, align 8
  %op8327 = and i32 %v8326, 28
  store i32 %op8327, ptr %slot1506, align 8
  %v8328 = load i32, ptr %slot1506, align 8
  %cv8329 = zext i32 %v8328 to i64
  %cond8330 = icmp ne i64 %cv8329, 0
  br i1 %cond8330, label %bb_rcslotrole1890, label %bb_rcslotowner1890
bb_rcslotrole1890:
  %v8331 = load i64, ptr %slot59, align 8
  store i64 %v8331, ptr %slot1507, align 8
  %v8332 = load i64, ptr %slot1507, align 8
  %v8333 = load i64, ptr %slot1504, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8332, i64 %v8333) nomerge, !dbg !172
  br label %bb_rcslotdone1890
bb_rcslotowner1890:
  %v8334 = load i64, ptr %slot1504, align 8
  %p8336 = inttoptr i64 %v8334 to ptr
  %gep8337 = getelementptr i8, ptr %p8336, i64 0
  %op8335 = ptrtoint ptr %gep8337 to i64
  store i64 %op8335, ptr %slot1508, align 8
  %v8338 = load i64, ptr %slot59, align 8
  store i64 %v8338, ptr %slot1509, align 8
  %v8339 = load i64, ptr %slot1508, align 8
  %p8340 = inttoptr i64 %v8339 to ptr
  %ld8341 = load i64, ptr %p8340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8341, ptr %slot1510, align 8
  %v8342 = load i64, ptr %slot1510, align 8
  %cmp8343 = icmp ne i64 %v8342, 0
  %cv8344 = zext i1 %cmp8343 to i32
  store i32 %cv8344, ptr %slot1511, align 8
  %v8345 = load i32, ptr %slot1511, align 8
  %cv8346 = zext i32 %v8345 to i64
  %cond8347 = icmp ne i64 %cv8346, 0
  br i1 %cond8347, label %bb_rcgnn1908, label %bb_rcgdone1908
bb_rcgnn1908:
  %v8348 = load i64, ptr %slot1510, align 8
  %op8349 = sub i64 %v8348, 16
  store i64 %op8349, ptr %slot1512, align 8
  %v8350 = load i64, ptr %slot1510, align 8
  %p8351 = inttoptr i64 %v8350 to ptr
  %rgep8352 = getelementptr i8, ptr %p8351, i64 -16
  %ld8353 = load i64, ptr %rgep8352, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8353, ptr %slot1513, align 8
  %v8354 = load i64, ptr %slot1513, align 8
  %op8355 = and i64 %v8354, 4611686018427387906
  store i64 %op8355, ptr %slot1514, align 8
  %v8356 = load i64, ptr %slot1514, align 8
  %cmp8357 = icmp ne i64 %v8356, 0
  %cv8358 = zext i1 %cmp8357 to i32
  store i32 %cv8358, ptr %slot1515, align 8
  %v8359 = load i32, ptr %slot1515, align 8
  %cv8360 = zext i32 %v8359 to i64
  %cond8361 = icmp ne i64 %cv8360, 0
  br i1 %cond8361, label %bb_rcgclear1908, label %bb_rcgcounted1908
bb_rcgcounted1908:
  %v8362 = load i64, ptr %slot1510, align 8
  %op8363 = sub i64 %v8362, 32
  store i64 %op8363, ptr %slot1516, align 8
  %v8364 = load i64, ptr %slot1510, align 8
  %p8365 = inttoptr i64 %v8364 to ptr
  %rgep8366 = getelementptr i8, ptr %p8365, i64 -32
  %ld8367 = load i64, ptr %rgep8366, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8367, ptr %slot1517, align 8
  %v8368 = load i64, ptr %slot1517, align 8
  %op8369 = sub i64 %v8368, 1
  store i64 %op8369, ptr %slot1518, align 8
  %v8370 = load i64, ptr %slot1518, align 8
  %cmp8371 = icmp eq i64 %v8370, 0
  %cv8372 = zext i1 %cmp8371 to i32
  store i32 %cv8372, ptr %slot1519, align 8
  %v8373 = load i32, ptr %slot1519, align 8
  %cv8374 = zext i32 %v8373 to i64
  %cond8375 = icmp ne i64 %cv8374, 0
  br i1 %cond8375, label %bb_rcglast1908, label %bb_rcgdec1908
bb_rcglast1908:
  %v8376 = load i64, ptr %slot1510, align 8
  %op8377 = sub i64 %v8376, 24
  store i64 %op8377, ptr %slot1520, align 8
  %v8378 = load i64, ptr %slot1510, align 8
  %p8379 = inttoptr i64 %v8378 to ptr
  %rgep8380 = getelementptr i8, ptr %p8379, i64 -24
  %ld8381 = load i64, ptr %rgep8380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8381, ptr %slot1521, align 8
  %v8382 = load i64, ptr %slot1521, align 8
  %cmp8383 = icmp ne i64 %v8382, 0
  %cv8384 = zext i1 %cmp8383 to i32
  store i32 %cv8384, ptr %slot1522, align 8
  %v8385 = load i32, ptr %slot1522, align 8
  %cv8386 = zext i32 %v8385 to i64
  %cond8387 = icmp ne i64 %cv8386, 0
  br i1 %cond8387, label %bb_rcgdec1908, label %bb_rcgslow1908
bb_rcgslow1908:
  %v8388 = load i64, ptr %slot1509, align 8
  %v8389 = load i64, ptr %slot1508, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8388, i64 %v8389) nomerge, !dbg !172
  br label %bb_rcgdone1908
bb_rcgdec1908:
  %v8390 = load i64, ptr %slot1518, align 8
  %v8391 = load i64, ptr %slot1510, align 8
  %p8392 = inttoptr i64 %v8391 to ptr
  %rgep8393 = getelementptr i8, ptr %p8392, i64 -32
  store i64 %v8390, ptr %rgep8393, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1908
bb_rcgclear1908:
  %v8394 = load i64, ptr %slot1508, align 8
  %p8395 = inttoptr i64 %v8394 to ptr
  store i64 0, ptr %p8395, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1908
bb_rcgdone1908:
  %v8396 = load i64, ptr %slot1504, align 8
  %p8397 = inttoptr i64 %v8396 to ptr
  store i64 0, ptr %p8397, align 8, !alias.scope !3, !noalias !4
  %v8398 = load i64, ptr %slot1504, align 8
  %p8400 = inttoptr i64 %v8398 to ptr
  %gep8401 = getelementptr i8, ptr %p8400, i64 8
  %op8399 = ptrtoint ptr %gep8401 to i64
  store i64 %op8399, ptr %slot1523, align 8
  %v8402 = load i64, ptr %slot1523, align 8
  %p8403 = inttoptr i64 %v8402 to ptr
  store i64 0, ptr %p8403, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1890
bb_rcslotdone1890:
  br label %bb_rcprepared1849
bb_rcprepared1849:
  %v8404 = load i64, ptr %slot34, align 8
  %p8405 = inttoptr i64 %v8404 to ptr
  %ld8406 = load i64, ptr %p8405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8406, ptr %slot1524, align 8
  %v8407 = load i64, ptr %slot1524, align 8
  %op8408 = add i64 %v8407, 0
  store i64 %op8408, ptr %slot1525, align 8
  %v8409 = load i64, ptr %slot59, align 8
  store i64 %v8409, ptr %slot1526, align 8
  %v8410 = load i64, ptr %slot1525, align 8
  %p8411 = inttoptr i64 %v8410 to ptr
  %ld8412 = load i64, ptr %p8411, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8412, ptr %slot1527, align 8
  %v8413 = load i64, ptr %slot1527, align 8
  %cmp8414 = icmp ne i64 %v8413, 0
  %cv8415 = zext i1 %cmp8414 to i32
  store i32 %cv8415, ptr %slot1528, align 8
  %v8416 = load i32, ptr %slot1528, align 8
  %cv8417 = zext i32 %v8416 to i64
  %cond8418 = icmp ne i64 %cv8417, 0
  br i1 %cond8418, label %bb_rcgnn1926, label %bb_rcgdone1926
bb_rcgnn1926:
  %v8419 = load i64, ptr %slot1527, align 8
  %op8420 = sub i64 %v8419, 16
  store i64 %op8420, ptr %slot1529, align 8
  %v8421 = load i64, ptr %slot1527, align 8
  %p8422 = inttoptr i64 %v8421 to ptr
  %rgep8423 = getelementptr i8, ptr %p8422, i64 -16
  %ld8424 = load i64, ptr %rgep8423, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8424, ptr %slot1530, align 8
  %v8425 = load i64, ptr %slot1530, align 8
  %op8426 = and i64 %v8425, 4611686018427387906
  store i64 %op8426, ptr %slot1531, align 8
  %v8427 = load i64, ptr %slot1531, align 8
  %cmp8428 = icmp ne i64 %v8427, 0
  %cv8429 = zext i1 %cmp8428 to i32
  store i32 %cv8429, ptr %slot1532, align 8
  %v8430 = load i32, ptr %slot1532, align 8
  %cv8431 = zext i32 %v8430 to i64
  %cond8432 = icmp ne i64 %cv8431, 0
  br i1 %cond8432, label %bb_rcgclear1926, label %bb_rcgcounted1926
bb_rcgcounted1926:
  %v8433 = load i64, ptr %slot1527, align 8
  %op8434 = sub i64 %v8433, 32
  store i64 %op8434, ptr %slot1533, align 8
  %v8435 = load i64, ptr %slot1527, align 8
  %p8436 = inttoptr i64 %v8435 to ptr
  %rgep8437 = getelementptr i8, ptr %p8436, i64 -32
  %ld8438 = load i64, ptr %rgep8437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8438, ptr %slot1534, align 8
  %v8439 = load i64, ptr %slot1534, align 8
  %op8440 = sub i64 %v8439, 1
  store i64 %op8440, ptr %slot1535, align 8
  %v8441 = load i64, ptr %slot1535, align 8
  %cmp8442 = icmp eq i64 %v8441, 0
  %cv8443 = zext i1 %cmp8442 to i32
  store i32 %cv8443, ptr %slot1536, align 8
  %v8444 = load i32, ptr %slot1536, align 8
  %cv8445 = zext i32 %v8444 to i64
  %cond8446 = icmp ne i64 %cv8445, 0
  br i1 %cond8446, label %bb_rcglast1926, label %bb_rcgdec1926
bb_rcglast1926:
  %v8447 = load i64, ptr %slot1527, align 8
  %op8448 = sub i64 %v8447, 24
  store i64 %op8448, ptr %slot1537, align 8
  %v8449 = load i64, ptr %slot1527, align 8
  %p8450 = inttoptr i64 %v8449 to ptr
  %rgep8451 = getelementptr i8, ptr %p8450, i64 -24
  %ld8452 = load i64, ptr %rgep8451, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8452, ptr %slot1538, align 8
  %v8453 = load i64, ptr %slot1538, align 8
  %cmp8454 = icmp ne i64 %v8453, 0
  %cv8455 = zext i1 %cmp8454 to i32
  store i32 %cv8455, ptr %slot1539, align 8
  %v8456 = load i32, ptr %slot1539, align 8
  %cv8457 = zext i32 %v8456 to i64
  %cond8458 = icmp ne i64 %cv8457, 0
  br i1 %cond8458, label %bb_rcgdec1926, label %bb_rcgslow1926
bb_rcgslow1926:
  %v8459 = load i64, ptr %slot1526, align 8
  %v8460 = load i64, ptr %slot1525, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8459, i64 %v8460) nomerge, !dbg !172
  br label %bb_rcgdone1926
bb_rcgdec1926:
  %v8461 = load i64, ptr %slot1535, align 8
  %v8462 = load i64, ptr %slot1527, align 8
  %p8463 = inttoptr i64 %v8462 to ptr
  %rgep8464 = getelementptr i8, ptr %p8463, i64 -32
  store i64 %v8461, ptr %rgep8464, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1926
bb_rcgclear1926:
  %v8465 = load i64, ptr %slot1525, align 8
  %p8466 = inttoptr i64 %v8465 to ptr
  store i64 0, ptr %p8466, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcgdone1926
bb_rcgdone1926:
  %v8467 = load i64, ptr %slot1524, align 8
  %p8468 = inttoptr i64 %v8467 to ptr
  store i64 0, ptr %p8468, align 8, !alias.scope !4, !noalias !3
  %v8469 = load i64, ptr %slot1524, align 8
  %op8470 = add i64 %v8469, 8
  store i64 %op8470, ptr %slot1540, align 8
  %v8471 = load i64, ptr %slot1540, align 8
  %p8472 = inttoptr i64 %v8471 to ptr
  store i64 0, ptr %p8472, align 8, !alias.scope !4, !noalias !3
  %v8473 = load i64, ptr %slot28, align 8
  store i64 %v8473, ptr %slot1541, align 8
  %v8474 = load i64, ptr %slot1541, align 8
  %v8475 = load i64, ptr %slot1524, align 8
  %p8476 = inttoptr i64 %v8474 to ptr
  %p8477 = inttoptr i64 %v8475 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8477, ptr %p8476, i64 16, i1 false), !alias.scope !10000001
  %v8478 = load i64, ptr %slot21, align 8
  %p8479 = inttoptr i64 %v8478 to ptr
  store i32 0, ptr %p8479, align 4, !alias.scope !3, !noalias !4
  %v8480 = load i64, ptr %slot15, align 8
  %p8481 = inttoptr i64 %v8480 to ptr
  %ld8482 = load i32, ptr %p8481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8482, ptr %slot1542, align 8
  %v8483 = load i32, ptr %slot1542, align 8
  %cv8484 = zext i32 %v8483 to i64
  %cond8485 = icmp ne i64 %cv8484, 0
  br i1 %cond8485, label %bb_rcslotdrop1935, label %bb_rcslotdone1935
bb_rcslotdrop1935:
  %v8486 = load i64, ptr %slot15, align 8
  %p8487 = inttoptr i64 %v8486 to ptr
  store i32 0, ptr %p8487, align 4, !alias.scope !3, !noalias !4
  %v8488 = load i64, ptr %slot49, align 8
  store i64 %v8488, ptr %slot1543, align 8
  %v8489 = load i64, ptr %slot16, align 8
  %p8490 = inttoptr i64 %v8489 to ptr
  %ld8491 = load i32, ptr %p8490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8491, ptr %slot1544, align 8
  %v8492 = load i32, ptr %slot1544, align 8
  %op8493 = and i32 %v8492, 28
  store i32 %op8493, ptr %slot1545, align 8
  %v8494 = load i32, ptr %slot1545, align 8
  %cv8495 = zext i32 %v8494 to i64
  %cond8496 = icmp ne i64 %cv8495, 0
  br i1 %cond8496, label %bb_rcslotrole1935, label %bb_rcslotowner1935
bb_rcslotrole1935:
  %v8497 = load i64, ptr %slot59, align 8
  store i64 %v8497, ptr %slot1546, align 8
  %v8498 = load i64, ptr %slot1543, align 8
  %p8499 = inttoptr i64 %v8498 to ptr
  %ld8500 = load i64, ptr %p8499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8500, ptr %slot1547, align 8
  %v8501 = load i64, ptr %slot1547, align 8
  %cmp8502 = icmp ne i64 %v8501, 0
  %cv8503 = zext i1 %cmp8502 to i32
  store i32 %cv8503, ptr %slot1548, align 8
  %v8504 = load i32, ptr %slot1548, align 8
  %cv8505 = zext i32 %v8504 to i64
  %cond8506 = icmp ne i64 %cv8505, 0
  br i1 %cond8506, label %bb_rcgnn1951, label %bb_rcgdone1951
bb_rcgnn1951:
  %v8507 = load i64, ptr %slot1547, align 8
  %op8508 = sub i64 %v8507, 16
  store i64 %op8508, ptr %slot1549, align 8
  %v8509 = load i64, ptr %slot1547, align 8
  %p8510 = inttoptr i64 %v8509 to ptr
  %rgep8511 = getelementptr i8, ptr %p8510, i64 -16
  %ld8512 = load i64, ptr %rgep8511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8512, ptr %slot1550, align 8
  %v8513 = load i64, ptr %slot1550, align 8
  %op8514 = and i64 %v8513, 4611686018427387906
  store i64 %op8514, ptr %slot1551, align 8
  %v8515 = load i64, ptr %slot1551, align 8
  %cmp8516 = icmp ne i64 %v8515, 0
  %cv8517 = zext i1 %cmp8516 to i32
  store i32 %cv8517, ptr %slot1552, align 8
  %v8518 = load i32, ptr %slot1552, align 8
  %cv8519 = zext i32 %v8518 to i64
  %cond8520 = icmp ne i64 %cv8519, 0
  br i1 %cond8520, label %bb_rcgclear1951, label %bb_rcgcounted1951
bb_rcgcounted1951:
  %v8521 = load i64, ptr %slot1547, align 8
  %op8522 = sub i64 %v8521, 24
  store i64 %op8522, ptr %slot1553, align 8
  %v8523 = load i64, ptr %slot1547, align 8
  %p8524 = inttoptr i64 %v8523 to ptr
  %rgep8525 = getelementptr i8, ptr %p8524, i64 -24
  %ld8526 = load i64, ptr %rgep8525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8526, ptr %slot1554, align 8
  %v8527 = load i64, ptr %slot1554, align 8
  %op8528 = sub i64 %v8527, 1
  store i64 %op8528, ptr %slot1555, align 8
  %v8529 = load i64, ptr %slot1555, align 8
  %cmp8530 = icmp eq i64 %v8529, 0
  %cv8531 = zext i1 %cmp8530 to i32
  store i32 %cv8531, ptr %slot1556, align 8
  %v8532 = load i32, ptr %slot1556, align 8
  %cv8533 = zext i32 %v8532 to i64
  %cond8534 = icmp ne i64 %cv8533, 0
  br i1 %cond8534, label %bb_rcglast1951, label %bb_rcgdec1951
bb_rcglast1951:
  %v8535 = load i64, ptr %slot1547, align 8
  %op8536 = sub i64 %v8535, 32
  store i64 %op8536, ptr %slot1557, align 8
  %v8537 = load i64, ptr %slot1547, align 8
  %p8538 = inttoptr i64 %v8537 to ptr
  %rgep8539 = getelementptr i8, ptr %p8538, i64 -32
  %ld8540 = load i64, ptr %rgep8539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8540, ptr %slot1558, align 8
  %v8541 = load i64, ptr %slot1558, align 8
  %cmp8542 = icmp ne i64 %v8541, 0
  %cv8543 = zext i1 %cmp8542 to i32
  store i32 %cv8543, ptr %slot1559, align 8
  %v8544 = load i32, ptr %slot1559, align 8
  %cv8545 = zext i32 %v8544 to i64
  %cond8546 = icmp ne i64 %cv8545, 0
  br i1 %cond8546, label %bb_rcgdec1951, label %bb_rcgslow1951
bb_rcgslow1951:
  %v8547 = load i64, ptr %slot1546, align 8
  %v8548 = load i64, ptr %slot1543, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v8547, i64 %v8548) nomerge, !dbg !172
  br label %bb_rcgdone1951
bb_rcgdec1951:
  %v8549 = load i64, ptr %slot1555, align 8
  %v8550 = load i64, ptr %slot1547, align 8
  %p8551 = inttoptr i64 %v8550 to ptr
  %rgep8552 = getelementptr i8, ptr %p8551, i64 -24
  store i64 %v8549, ptr %rgep8552, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1951
bb_rcgclear1951:
  %v8553 = load i64, ptr %slot1543, align 8
  %p8554 = inttoptr i64 %v8553 to ptr
  store i64 0, ptr %p8554, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1951
bb_rcgdone1951:
  br label %bb_rcslotdone1935
bb_rcslotowner1935:
  %v8555 = load i64, ptr %slot59, align 8
  store i64 %v8555, ptr %slot1560, align 8
  %v8556 = load i64, ptr %slot1543, align 8
  %p8557 = inttoptr i64 %v8556 to ptr
  %ld8558 = load i64, ptr %p8557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8558, ptr %slot1561, align 8
  %v8559 = load i64, ptr %slot1561, align 8
  %cmp8560 = icmp ne i64 %v8559, 0
  %cv8561 = zext i1 %cmp8560 to i32
  store i32 %cv8561, ptr %slot1562, align 8
  %v8562 = load i32, ptr %slot1562, align 8
  %cv8563 = zext i32 %v8562 to i64
  %cond8564 = icmp ne i64 %cv8563, 0
  br i1 %cond8564, label %bb_rcgnn1966, label %bb_rcgdone1966
bb_rcgnn1966:
  %v8565 = load i64, ptr %slot1561, align 8
  %op8566 = sub i64 %v8565, 16
  store i64 %op8566, ptr %slot1563, align 8
  %v8567 = load i64, ptr %slot1561, align 8
  %p8568 = inttoptr i64 %v8567 to ptr
  %rgep8569 = getelementptr i8, ptr %p8568, i64 -16
  %ld8570 = load i64, ptr %rgep8569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8570, ptr %slot1564, align 8
  %v8571 = load i64, ptr %slot1564, align 8
  %op8572 = and i64 %v8571, 4611686018427387906
  store i64 %op8572, ptr %slot1565, align 8
  %v8573 = load i64, ptr %slot1565, align 8
  %cmp8574 = icmp ne i64 %v8573, 0
  %cv8575 = zext i1 %cmp8574 to i32
  store i32 %cv8575, ptr %slot1566, align 8
  %v8576 = load i32, ptr %slot1566, align 8
  %cv8577 = zext i32 %v8576 to i64
  %cond8578 = icmp ne i64 %cv8577, 0
  br i1 %cond8578, label %bb_rcgclear1966, label %bb_rcgcounted1966
bb_rcgcounted1966:
  %v8579 = load i64, ptr %slot1561, align 8
  %op8580 = sub i64 %v8579, 32
  store i64 %op8580, ptr %slot1567, align 8
  %v8581 = load i64, ptr %slot1561, align 8
  %p8582 = inttoptr i64 %v8581 to ptr
  %rgep8583 = getelementptr i8, ptr %p8582, i64 -32
  %ld8584 = load i64, ptr %rgep8583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8584, ptr %slot1568, align 8
  %v8585 = load i64, ptr %slot1568, align 8
  %op8586 = sub i64 %v8585, 1
  store i64 %op8586, ptr %slot1569, align 8
  %v8587 = load i64, ptr %slot1569, align 8
  %cmp8588 = icmp eq i64 %v8587, 0
  %cv8589 = zext i1 %cmp8588 to i32
  store i32 %cv8589, ptr %slot1570, align 8
  %v8590 = load i32, ptr %slot1570, align 8
  %cv8591 = zext i32 %v8590 to i64
  %cond8592 = icmp ne i64 %cv8591, 0
  br i1 %cond8592, label %bb_rcglast1966, label %bb_rcgdec1966
bb_rcglast1966:
  %v8593 = load i64, ptr %slot1561, align 8
  %op8594 = sub i64 %v8593, 24
  store i64 %op8594, ptr %slot1571, align 8
  %v8595 = load i64, ptr %slot1561, align 8
  %p8596 = inttoptr i64 %v8595 to ptr
  %rgep8597 = getelementptr i8, ptr %p8596, i64 -24
  %ld8598 = load i64, ptr %rgep8597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8598, ptr %slot1572, align 8
  %v8599 = load i64, ptr %slot1572, align 8
  %cmp8600 = icmp ne i64 %v8599, 0
  %cv8601 = zext i1 %cmp8600 to i32
  store i32 %cv8601, ptr %slot1573, align 8
  %v8602 = load i32, ptr %slot1573, align 8
  %cv8603 = zext i32 %v8602 to i64
  %cond8604 = icmp ne i64 %cv8603, 0
  br i1 %cond8604, label %bb_rcgdec1966, label %bb_rcgslow1966
bb_rcgslow1966:
  %v8605 = load i64, ptr %slot1560, align 8
  %v8606 = load i64, ptr %slot1543, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8605, i64 %v8606) nomerge, !dbg !172
  br label %bb_rcgdone1966
bb_rcgdec1966:
  %v8607 = load i64, ptr %slot1569, align 8
  %v8608 = load i64, ptr %slot1561, align 8
  %p8609 = inttoptr i64 %v8608 to ptr
  %rgep8610 = getelementptr i8, ptr %p8609, i64 -32
  store i64 %v8607, ptr %rgep8610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1966
bb_rcgclear1966:
  %v8611 = load i64, ptr %slot1543, align 8
  %p8612 = inttoptr i64 %v8611 to ptr
  store i64 0, ptr %p8612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1966
bb_rcgdone1966:
  br label %bb_rcslotdone1935
bb_rcslotdone1935:
  %v8613 = load i64, ptr %slot50, align 8
  %p8614 = inttoptr i64 %v8613 to ptr
  store i64 0, ptr %p8614, align 8, !alias.scope !3, !noalias !4
  %v8615 = load i64, ptr %slot50, align 8
  %p8616 = inttoptr i64 %v8615 to ptr
  store i64 0, ptr %p8616, align 8, !alias.scope !3, !noalias !4
  %v8617 = load i64, ptr %slot50, align 8
  %p8618 = inttoptr i64 %v8617 to ptr
  %ld8619 = load i64, ptr %p8618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8619, ptr %slot1574, align 8
  %v8620 = load i64, ptr %slot29, align 8
  %p8622 = inttoptr i64 %v8620 to ptr
  %gep8623 = getelementptr i8, ptr %p8622, i64 24
  %op8621 = ptrtoint ptr %gep8623 to i64
  store i64 %op8621, ptr %slot1575, align 8
  %v8624 = load i64, ptr %slot1575, align 8
  %p8625 = inttoptr i64 %v8624 to ptr
  %ld8626 = load i32, ptr %p8625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8626, ptr %slot1576, align 8
  %v8627 = load i64, ptr %slot31, align 8
  %p8629 = inttoptr i64 %v8627 to ptr
  %gep8630 = getelementptr i8, ptr %p8629, i64 24
  %op8628 = ptrtoint ptr %gep8630 to i64
  store i64 %op8628, ptr %slot1577, align 8
  %v8631 = load i64, ptr %slot1577, align 8
  %p8632 = inttoptr i64 %v8631 to ptr
  %ld8633 = load i32, ptr %p8632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8633, ptr %slot1578, align 8
  %v8634 = load i32, ptr %slot1576, align 8
  %v8635 = load i32, ptr %slot1578, align 8
  %op8636 = or i32 %v8634, %v8635
  store i32 %op8636, ptr %slot1579, align 8
  %v8637 = load i32, ptr %slot1579, align 8
  %cv8638 = zext i32 %v8637 to i64
  %cond8639 = icmp ne i64 %cv8638, 0
  br i1 %cond8639, label %bb_rcscopesopen1976, label %bb_rcscopesclosed1976
bb_rcscopesopen1976:
  %v8640 = load i64, ptr %slot33, align 8
  %p8642 = inttoptr i64 %v8640 to ptr
  %gep8643 = getelementptr i8, ptr %p8642, i64 0
  %op8641 = ptrtoint ptr %gep8643 to i64
  store i64 %op8641, ptr %slot1580, align 8
  %v8644 = load i64, ptr %slot29, align 8
  %v8645 = load i64, ptr %slot1580, align 8
  %p8646 = inttoptr i64 %v8645 to ptr
  store i64 %v8644, ptr %p8646, align 8, !alias.scope !3, !noalias !4
  %v8647 = load i64, ptr %slot33, align 8
  %p8649 = inttoptr i64 %v8647 to ptr
  %gep8650 = getelementptr i8, ptr %p8649, i64 8
  %op8648 = ptrtoint ptr %gep8650 to i64
  store i64 %op8648, ptr %slot1581, align 8
  %v8651 = load i64, ptr %slot31, align 8
  %v8652 = load i64, ptr %slot1581, align 8
  %p8653 = inttoptr i64 %v8652 to ptr
  store i64 %v8651, ptr %p8653, align 8, !alias.scope !3, !noalias !4
  %v8654 = load i64, ptr %slot1, align 8
  %p8655 = inttoptr i64 %v8654 to ptr
  %v8656 = load i64, ptr %slot33, align 8
  %p8657 = inttoptr i64 %v8656 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p8655, ptr %p8657, i64 2) nomerge, !dbg !174
  br label %bb_rcscopesclosed1976
bb_rcscopesclosed1976:
  %v8658 = load i64, ptr %slot17, align 8
  %p8659 = inttoptr i64 %v8658 to ptr
  %ld8660 = load i32, ptr %p8659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8660, ptr %slot1582, align 8
  %v8661 = load i32, ptr %slot1582, align 8
  %cv8662 = zext i32 %v8661 to i64
  %cond8663 = icmp ne i64 %cv8662, 0
  br i1 %cond8663, label %bb_rcslotdrop1981, label %bb_rcslotdone1981
bb_rcslotdrop1981:
  %v8664 = load i64, ptr %slot17, align 8
  %p8665 = inttoptr i64 %v8664 to ptr
  store i32 0, ptr %p8665, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1981
bb_rcslotdone1981:
  %v8666 = load i64, ptr %slot15, align 8
  %p8667 = inttoptr i64 %v8666 to ptr
  %ld8668 = load i32, ptr %p8667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8668, ptr %slot1583, align 8
  %v8669 = load i32, ptr %slot1583, align 8
  %cv8670 = zext i32 %v8669 to i64
  %cond8671 = icmp ne i64 %cv8670, 0
  br i1 %cond8671, label %bb_rcslotdrop1984, label %bb_rcslotdone1984
bb_rcslotdrop1984:
  %v8672 = load i64, ptr %slot15, align 8
  %p8673 = inttoptr i64 %v8672 to ptr
  store i32 0, ptr %p8673, align 4, !alias.scope !3, !noalias !4
  %v8674 = load i64, ptr %slot49, align 8
  store i64 %v8674, ptr %slot1584, align 8
  %v8675 = load i64, ptr %slot16, align 8
  %p8676 = inttoptr i64 %v8675 to ptr
  %ld8677 = load i32, ptr %p8676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8677, ptr %slot1585, align 8
  %v8678 = load i32, ptr %slot1585, align 8
  %op8679 = and i32 %v8678, 28
  store i32 %op8679, ptr %slot1586, align 8
  %v8680 = load i32, ptr %slot1586, align 8
  %cv8681 = zext i32 %v8680 to i64
  %cond8682 = icmp ne i64 %cv8681, 0
  br i1 %cond8682, label %bb_rcslotrole1984, label %bb_rcslotowner1984
bb_rcslotrole1984:
  %v8683 = load i64, ptr %slot59, align 8
  store i64 %v8683, ptr %slot1587, align 8
  %v8684 = load i64, ptr %slot1584, align 8
  %p8685 = inttoptr i64 %v8684 to ptr
  %ld8686 = load i64, ptr %p8685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8686, ptr %slot1588, align 8
  %v8687 = load i64, ptr %slot1588, align 8
  %cmp8688 = icmp ne i64 %v8687, 0
  %cv8689 = zext i1 %cmp8688 to i32
  store i32 %cv8689, ptr %slot1589, align 8
  %v8690 = load i32, ptr %slot1589, align 8
  %cv8691 = zext i32 %v8690 to i64
  %cond8692 = icmp ne i64 %cv8691, 0
  br i1 %cond8692, label %bb_rcgnn2000, label %bb_rcgdone2000
bb_rcgnn2000:
  %v8693 = load i64, ptr %slot1588, align 8
  %op8694 = sub i64 %v8693, 16
  store i64 %op8694, ptr %slot1590, align 8
  %v8695 = load i64, ptr %slot1588, align 8
  %p8696 = inttoptr i64 %v8695 to ptr
  %rgep8697 = getelementptr i8, ptr %p8696, i64 -16
  %ld8698 = load i64, ptr %rgep8697, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8698, ptr %slot1591, align 8
  %v8699 = load i64, ptr %slot1591, align 8
  %op8700 = and i64 %v8699, 4611686018427387906
  store i64 %op8700, ptr %slot1592, align 8
  %v8701 = load i64, ptr %slot1592, align 8
  %cmp8702 = icmp ne i64 %v8701, 0
  %cv8703 = zext i1 %cmp8702 to i32
  store i32 %cv8703, ptr %slot1593, align 8
  %v8704 = load i32, ptr %slot1593, align 8
  %cv8705 = zext i32 %v8704 to i64
  %cond8706 = icmp ne i64 %cv8705, 0
  br i1 %cond8706, label %bb_rcgclear2000, label %bb_rcgcounted2000
bb_rcgcounted2000:
  %v8707 = load i64, ptr %slot1588, align 8
  %op8708 = sub i64 %v8707, 24
  store i64 %op8708, ptr %slot1594, align 8
  %v8709 = load i64, ptr %slot1588, align 8
  %p8710 = inttoptr i64 %v8709 to ptr
  %rgep8711 = getelementptr i8, ptr %p8710, i64 -24
  %ld8712 = load i64, ptr %rgep8711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8712, ptr %slot1595, align 8
  %v8713 = load i64, ptr %slot1595, align 8
  %op8714 = sub i64 %v8713, 1
  store i64 %op8714, ptr %slot1596, align 8
  %v8715 = load i64, ptr %slot1596, align 8
  %cmp8716 = icmp eq i64 %v8715, 0
  %cv8717 = zext i1 %cmp8716 to i32
  store i32 %cv8717, ptr %slot1597, align 8
  %v8718 = load i32, ptr %slot1597, align 8
  %cv8719 = zext i32 %v8718 to i64
  %cond8720 = icmp ne i64 %cv8719, 0
  br i1 %cond8720, label %bb_rcglast2000, label %bb_rcgdec2000
bb_rcglast2000:
  %v8721 = load i64, ptr %slot1588, align 8
  %op8722 = sub i64 %v8721, 32
  store i64 %op8722, ptr %slot1598, align 8
  %v8723 = load i64, ptr %slot1588, align 8
  %p8724 = inttoptr i64 %v8723 to ptr
  %rgep8725 = getelementptr i8, ptr %p8724, i64 -32
  %ld8726 = load i64, ptr %rgep8725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8726, ptr %slot1599, align 8
  %v8727 = load i64, ptr %slot1599, align 8
  %cmp8728 = icmp ne i64 %v8727, 0
  %cv8729 = zext i1 %cmp8728 to i32
  store i32 %cv8729, ptr %slot1600, align 8
  %v8730 = load i32, ptr %slot1600, align 8
  %cv8731 = zext i32 %v8730 to i64
  %cond8732 = icmp ne i64 %cv8731, 0
  br i1 %cond8732, label %bb_rcgdec2000, label %bb_rcgslow2000
bb_rcgslow2000:
  %v8733 = load i64, ptr %slot1587, align 8
  %v8734 = load i64, ptr %slot1584, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v8733, i64 %v8734) nomerge, !dbg !174
  br label %bb_rcgdone2000
bb_rcgdec2000:
  %v8735 = load i64, ptr %slot1596, align 8
  %v8736 = load i64, ptr %slot1588, align 8
  %p8737 = inttoptr i64 %v8736 to ptr
  %rgep8738 = getelementptr i8, ptr %p8737, i64 -24
  store i64 %v8735, ptr %rgep8738, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2000
bb_rcgclear2000:
  %v8739 = load i64, ptr %slot1584, align 8
  %p8740 = inttoptr i64 %v8739 to ptr
  store i64 0, ptr %p8740, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2000
bb_rcgdone2000:
  br label %bb_rcslotdone1984
bb_rcslotowner1984:
  %v8741 = load i64, ptr %slot59, align 8
  store i64 %v8741, ptr %slot1601, align 8
  %v8742 = load i64, ptr %slot1584, align 8
  %p8743 = inttoptr i64 %v8742 to ptr
  %ld8744 = load i64, ptr %p8743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8744, ptr %slot1602, align 8
  %v8745 = load i64, ptr %slot1602, align 8
  %cmp8746 = icmp ne i64 %v8745, 0
  %cv8747 = zext i1 %cmp8746 to i32
  store i32 %cv8747, ptr %slot1603, align 8
  %v8748 = load i32, ptr %slot1603, align 8
  %cv8749 = zext i32 %v8748 to i64
  %cond8750 = icmp ne i64 %cv8749, 0
  br i1 %cond8750, label %bb_rcgnn2015, label %bb_rcgdone2015
bb_rcgnn2015:
  %v8751 = load i64, ptr %slot1602, align 8
  %op8752 = sub i64 %v8751, 16
  store i64 %op8752, ptr %slot1604, align 8
  %v8753 = load i64, ptr %slot1602, align 8
  %p8754 = inttoptr i64 %v8753 to ptr
  %rgep8755 = getelementptr i8, ptr %p8754, i64 -16
  %ld8756 = load i64, ptr %rgep8755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8756, ptr %slot1605, align 8
  %v8757 = load i64, ptr %slot1605, align 8
  %op8758 = and i64 %v8757, 4611686018427387906
  store i64 %op8758, ptr %slot1606, align 8
  %v8759 = load i64, ptr %slot1606, align 8
  %cmp8760 = icmp ne i64 %v8759, 0
  %cv8761 = zext i1 %cmp8760 to i32
  store i32 %cv8761, ptr %slot1607, align 8
  %v8762 = load i32, ptr %slot1607, align 8
  %cv8763 = zext i32 %v8762 to i64
  %cond8764 = icmp ne i64 %cv8763, 0
  br i1 %cond8764, label %bb_rcgclear2015, label %bb_rcgcounted2015
bb_rcgcounted2015:
  %v8765 = load i64, ptr %slot1602, align 8
  %op8766 = sub i64 %v8765, 32
  store i64 %op8766, ptr %slot1608, align 8
  %v8767 = load i64, ptr %slot1602, align 8
  %p8768 = inttoptr i64 %v8767 to ptr
  %rgep8769 = getelementptr i8, ptr %p8768, i64 -32
  %ld8770 = load i64, ptr %rgep8769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8770, ptr %slot1609, align 8
  %v8771 = load i64, ptr %slot1609, align 8
  %op8772 = sub i64 %v8771, 1
  store i64 %op8772, ptr %slot1610, align 8
  %v8773 = load i64, ptr %slot1610, align 8
  %cmp8774 = icmp eq i64 %v8773, 0
  %cv8775 = zext i1 %cmp8774 to i32
  store i32 %cv8775, ptr %slot1611, align 8
  %v8776 = load i32, ptr %slot1611, align 8
  %cv8777 = zext i32 %v8776 to i64
  %cond8778 = icmp ne i64 %cv8777, 0
  br i1 %cond8778, label %bb_rcglast2015, label %bb_rcgdec2015
bb_rcglast2015:
  %v8779 = load i64, ptr %slot1602, align 8
  %op8780 = sub i64 %v8779, 24
  store i64 %op8780, ptr %slot1612, align 8
  %v8781 = load i64, ptr %slot1602, align 8
  %p8782 = inttoptr i64 %v8781 to ptr
  %rgep8783 = getelementptr i8, ptr %p8782, i64 -24
  %ld8784 = load i64, ptr %rgep8783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8784, ptr %slot1613, align 8
  %v8785 = load i64, ptr %slot1613, align 8
  %cmp8786 = icmp ne i64 %v8785, 0
  %cv8787 = zext i1 %cmp8786 to i32
  store i32 %cv8787, ptr %slot1614, align 8
  %v8788 = load i32, ptr %slot1614, align 8
  %cv8789 = zext i32 %v8788 to i64
  %cond8790 = icmp ne i64 %cv8789, 0
  br i1 %cond8790, label %bb_rcgdec2015, label %bb_rcgslow2015
bb_rcgslow2015:
  %v8791 = load i64, ptr %slot1601, align 8
  %v8792 = load i64, ptr %slot1584, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8791, i64 %v8792) nomerge, !dbg !174
  br label %bb_rcgdone2015
bb_rcgdec2015:
  %v8793 = load i64, ptr %slot1610, align 8
  %v8794 = load i64, ptr %slot1602, align 8
  %p8795 = inttoptr i64 %v8794 to ptr
  %rgep8796 = getelementptr i8, ptr %p8795, i64 -32
  store i64 %v8793, ptr %rgep8796, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2015
bb_rcgclear2015:
  %v8797 = load i64, ptr %slot1584, align 8
  %p8798 = inttoptr i64 %v8797 to ptr
  store i64 0, ptr %p8798, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2015
bb_rcgdone2015:
  br label %bb_rcslotdone1984
bb_rcslotdone1984:
  %v8799 = load i64, ptr %slot13, align 8
  %p8800 = inttoptr i64 %v8799 to ptr
  %ld8801 = load i32, ptr %p8800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8801, ptr %slot1615, align 8
  %v8802 = load i32, ptr %slot1615, align 8
  %cv8803 = zext i32 %v8802 to i64
  %cond8804 = icmp ne i64 %cv8803, 0
  br i1 %cond8804, label %bb_rcslotdrop2021, label %bb_rcslotdone2021
bb_rcslotdrop2021:
  %v8805 = load i64, ptr %slot13, align 8
  %p8806 = inttoptr i64 %v8805 to ptr
  store i32 0, ptr %p8806, align 4, !alias.scope !3, !noalias !4
  %v8807 = load i64, ptr %slot48, align 8
  store i64 %v8807, ptr %slot1616, align 8
  %v8808 = load i64, ptr %slot14, align 8
  %p8809 = inttoptr i64 %v8808 to ptr
  %ld8810 = load i32, ptr %p8809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8810, ptr %slot1617, align 8
  %v8811 = load i32, ptr %slot1617, align 8
  %op8812 = and i32 %v8811, 28
  store i32 %op8812, ptr %slot1618, align 8
  %v8813 = load i32, ptr %slot1618, align 8
  %cv8814 = zext i32 %v8813 to i64
  %cond8815 = icmp ne i64 %cv8814, 0
  br i1 %cond8815, label %bb_rcslotrole2021, label %bb_rcslotowner2021
bb_rcslotrole2021:
  %v8816 = load i64, ptr %slot59, align 8
  store i64 %v8816, ptr %slot1619, align 8
  %v8817 = load i64, ptr %slot1619, align 8
  %v8818 = load i64, ptr %slot1616, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8817, i64 %v8818) nomerge, !dbg !174
  br label %bb_rcslotdone2021
bb_rcslotowner2021:
  %v8819 = load i64, ptr %slot59, align 8
  store i64 %v8819, ptr %slot1620, align 8
  %v8820 = load i64, ptr %slot1620, align 8
  %v8821 = load i64, ptr %slot1616, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8820, i64 %v8821) nomerge, !dbg !174
  br label %bb_rcslotdone2021
bb_rcslotdone2021:
  %v8822 = load i64, ptr %slot11, align 8
  %p8823 = inttoptr i64 %v8822 to ptr
  %ld8824 = load i32, ptr %p8823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8824, ptr %slot1621, align 8
  %v8825 = load i32, ptr %slot1621, align 8
  %cv8826 = zext i32 %v8825 to i64
  %cond8827 = icmp ne i64 %cv8826, 0
  br i1 %cond8827, label %bb_rcslotdrop2039, label %bb_rcslotdone2039
bb_rcslotdrop2039:
  %v8828 = load i64, ptr %slot11, align 8
  %p8829 = inttoptr i64 %v8828 to ptr
  store i32 0, ptr %p8829, align 4, !alias.scope !3, !noalias !4
  %v8830 = load i64, ptr %slot44, align 8
  store i64 %v8830, ptr %slot1622, align 8
  %v8831 = load i64, ptr %slot12, align 8
  %p8832 = inttoptr i64 %v8831 to ptr
  %ld8833 = load i32, ptr %p8832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8833, ptr %slot1623, align 8
  %v8834 = load i32, ptr %slot1623, align 8
  %op8835 = and i32 %v8834, 28
  store i32 %op8835, ptr %slot1624, align 8
  %v8836 = load i32, ptr %slot1624, align 8
  %cv8837 = zext i32 %v8836 to i64
  %cond8838 = icmp ne i64 %cv8837, 0
  br i1 %cond8838, label %bb_rcslotrole2039, label %bb_rcslotowner2039
bb_rcslotrole2039:
  %v8839 = load i64, ptr %slot59, align 8
  store i64 %v8839, ptr %slot1625, align 8
  %v8840 = load i64, ptr %slot1622, align 8
  %p8841 = inttoptr i64 %v8840 to ptr
  %ld8842 = load i64, ptr %p8841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8842, ptr %slot1626, align 8
  %v8843 = load i64, ptr %slot1626, align 8
  %cmp8844 = icmp ne i64 %v8843, 0
  %cv8845 = zext i1 %cmp8844 to i32
  store i32 %cv8845, ptr %slot1627, align 8
  %v8846 = load i32, ptr %slot1627, align 8
  %cv8847 = zext i32 %v8846 to i64
  %cond8848 = icmp ne i64 %cv8847, 0
  br i1 %cond8848, label %bb_rcgnn2055, label %bb_rcgdone2055
bb_rcgnn2055:
  %v8849 = load i64, ptr %slot1626, align 8
  %op8850 = sub i64 %v8849, 16
  store i64 %op8850, ptr %slot1628, align 8
  %v8851 = load i64, ptr %slot1626, align 8
  %p8852 = inttoptr i64 %v8851 to ptr
  %rgep8853 = getelementptr i8, ptr %p8852, i64 -16
  %ld8854 = load i64, ptr %rgep8853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8854, ptr %slot1629, align 8
  %v8855 = load i64, ptr %slot1629, align 8
  %op8856 = and i64 %v8855, 4611686018427387906
  store i64 %op8856, ptr %slot1630, align 8
  %v8857 = load i64, ptr %slot1630, align 8
  %cmp8858 = icmp ne i64 %v8857, 0
  %cv8859 = zext i1 %cmp8858 to i32
  store i32 %cv8859, ptr %slot1631, align 8
  %v8860 = load i32, ptr %slot1631, align 8
  %cv8861 = zext i32 %v8860 to i64
  %cond8862 = icmp ne i64 %cv8861, 0
  br i1 %cond8862, label %bb_rcgclear2055, label %bb_rcgcounted2055
bb_rcgcounted2055:
  %v8863 = load i64, ptr %slot1626, align 8
  %op8864 = sub i64 %v8863, 24
  store i64 %op8864, ptr %slot1632, align 8
  %v8865 = load i64, ptr %slot1626, align 8
  %p8866 = inttoptr i64 %v8865 to ptr
  %rgep8867 = getelementptr i8, ptr %p8866, i64 -24
  %ld8868 = load i64, ptr %rgep8867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8868, ptr %slot1633, align 8
  %v8869 = load i64, ptr %slot1633, align 8
  %op8870 = sub i64 %v8869, 1
  store i64 %op8870, ptr %slot1634, align 8
  %v8871 = load i64, ptr %slot1634, align 8
  %cmp8872 = icmp eq i64 %v8871, 0
  %cv8873 = zext i1 %cmp8872 to i32
  store i32 %cv8873, ptr %slot1635, align 8
  %v8874 = load i32, ptr %slot1635, align 8
  %cv8875 = zext i32 %v8874 to i64
  %cond8876 = icmp ne i64 %cv8875, 0
  br i1 %cond8876, label %bb_rcglast2055, label %bb_rcgdec2055
bb_rcglast2055:
  %v8877 = load i64, ptr %slot1626, align 8
  %op8878 = sub i64 %v8877, 32
  store i64 %op8878, ptr %slot1636, align 8
  %v8879 = load i64, ptr %slot1626, align 8
  %p8880 = inttoptr i64 %v8879 to ptr
  %rgep8881 = getelementptr i8, ptr %p8880, i64 -32
  %ld8882 = load i64, ptr %rgep8881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8882, ptr %slot1637, align 8
  %v8883 = load i64, ptr %slot1637, align 8
  %cmp8884 = icmp ne i64 %v8883, 0
  %cv8885 = zext i1 %cmp8884 to i32
  store i32 %cv8885, ptr %slot1638, align 8
  %v8886 = load i32, ptr %slot1638, align 8
  %cv8887 = zext i32 %v8886 to i64
  %cond8888 = icmp ne i64 %cv8887, 0
  br i1 %cond8888, label %bb_rcgdec2055, label %bb_rcgslow2055
bb_rcgslow2055:
  %v8889 = load i64, ptr %slot1625, align 8
  %v8890 = load i64, ptr %slot1622, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v8889, i64 %v8890) nomerge, !dbg !174
  br label %bb_rcgdone2055
bb_rcgdec2055:
  %v8891 = load i64, ptr %slot1634, align 8
  %v8892 = load i64, ptr %slot1626, align 8
  %p8893 = inttoptr i64 %v8892 to ptr
  %rgep8894 = getelementptr i8, ptr %p8893, i64 -24
  store i64 %v8891, ptr %rgep8894, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2055
bb_rcgclear2055:
  %v8895 = load i64, ptr %slot1622, align 8
  %p8896 = inttoptr i64 %v8895 to ptr
  store i64 0, ptr %p8896, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2055
bb_rcgdone2055:
  br label %bb_rcslotdone2039
bb_rcslotowner2039:
  %v8897 = load i64, ptr %slot59, align 8
  store i64 %v8897, ptr %slot1639, align 8
  %v8898 = load i64, ptr %slot1622, align 8
  %p8899 = inttoptr i64 %v8898 to ptr
  %ld8900 = load i64, ptr %p8899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8900, ptr %slot1640, align 8
  %v8901 = load i64, ptr %slot1640, align 8
  %cmp8902 = icmp ne i64 %v8901, 0
  %cv8903 = zext i1 %cmp8902 to i32
  store i32 %cv8903, ptr %slot1641, align 8
  %v8904 = load i32, ptr %slot1641, align 8
  %cv8905 = zext i32 %v8904 to i64
  %cond8906 = icmp ne i64 %cv8905, 0
  br i1 %cond8906, label %bb_rcgnn2070, label %bb_rcgdone2070
bb_rcgnn2070:
  %v8907 = load i64, ptr %slot1640, align 8
  %op8908 = sub i64 %v8907, 16
  store i64 %op8908, ptr %slot1642, align 8
  %v8909 = load i64, ptr %slot1640, align 8
  %p8910 = inttoptr i64 %v8909 to ptr
  %rgep8911 = getelementptr i8, ptr %p8910, i64 -16
  %ld8912 = load i64, ptr %rgep8911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8912, ptr %slot1643, align 8
  %v8913 = load i64, ptr %slot1643, align 8
  %op8914 = and i64 %v8913, 4611686018427387906
  store i64 %op8914, ptr %slot1644, align 8
  %v8915 = load i64, ptr %slot1644, align 8
  %cmp8916 = icmp ne i64 %v8915, 0
  %cv8917 = zext i1 %cmp8916 to i32
  store i32 %cv8917, ptr %slot1645, align 8
  %v8918 = load i32, ptr %slot1645, align 8
  %cv8919 = zext i32 %v8918 to i64
  %cond8920 = icmp ne i64 %cv8919, 0
  br i1 %cond8920, label %bb_rcgclear2070, label %bb_rcgcounted2070
bb_rcgcounted2070:
  %v8921 = load i64, ptr %slot1640, align 8
  %op8922 = sub i64 %v8921, 32
  store i64 %op8922, ptr %slot1646, align 8
  %v8923 = load i64, ptr %slot1640, align 8
  %p8924 = inttoptr i64 %v8923 to ptr
  %rgep8925 = getelementptr i8, ptr %p8924, i64 -32
  %ld8926 = load i64, ptr %rgep8925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8926, ptr %slot1647, align 8
  %v8927 = load i64, ptr %slot1647, align 8
  %op8928 = sub i64 %v8927, 1
  store i64 %op8928, ptr %slot1648, align 8
  %v8929 = load i64, ptr %slot1648, align 8
  %cmp8930 = icmp eq i64 %v8929, 0
  %cv8931 = zext i1 %cmp8930 to i32
  store i32 %cv8931, ptr %slot1649, align 8
  %v8932 = load i32, ptr %slot1649, align 8
  %cv8933 = zext i32 %v8932 to i64
  %cond8934 = icmp ne i64 %cv8933, 0
  br i1 %cond8934, label %bb_rcglast2070, label %bb_rcgdec2070
bb_rcglast2070:
  %v8935 = load i64, ptr %slot1640, align 8
  %op8936 = sub i64 %v8935, 24
  store i64 %op8936, ptr %slot1650, align 8
  %v8937 = load i64, ptr %slot1640, align 8
  %p8938 = inttoptr i64 %v8937 to ptr
  %rgep8939 = getelementptr i8, ptr %p8938, i64 -24
  %ld8940 = load i64, ptr %rgep8939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8940, ptr %slot1651, align 8
  %v8941 = load i64, ptr %slot1651, align 8
  %cmp8942 = icmp ne i64 %v8941, 0
  %cv8943 = zext i1 %cmp8942 to i32
  store i32 %cv8943, ptr %slot1652, align 8
  %v8944 = load i32, ptr %slot1652, align 8
  %cv8945 = zext i32 %v8944 to i64
  %cond8946 = icmp ne i64 %cv8945, 0
  br i1 %cond8946, label %bb_rcgdec2070, label %bb_rcgslow2070
bb_rcgslow2070:
  %v8947 = load i64, ptr %slot1639, align 8
  %v8948 = load i64, ptr %slot1622, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8947, i64 %v8948) nomerge, !dbg !174
  br label %bb_rcgdone2070
bb_rcgdec2070:
  %v8949 = load i64, ptr %slot1648, align 8
  %v8950 = load i64, ptr %slot1640, align 8
  %p8951 = inttoptr i64 %v8950 to ptr
  %rgep8952 = getelementptr i8, ptr %p8951, i64 -32
  store i64 %v8949, ptr %rgep8952, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2070
bb_rcgclear2070:
  %v8953 = load i64, ptr %slot1622, align 8
  %p8954 = inttoptr i64 %v8953 to ptr
  store i64 0, ptr %p8954, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2070
bb_rcgdone2070:
  br label %bb_rcslotdone2039
bb_rcslotdone2039:
  %v8955 = load i64, ptr %slot9, align 8
  %p8956 = inttoptr i64 %v8955 to ptr
  %ld8957 = load i32, ptr %p8956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8957, ptr %slot1653, align 8
  %v8958 = load i32, ptr %slot1653, align 8
  %cv8959 = zext i32 %v8958 to i64
  %cond8960 = icmp ne i64 %cv8959, 0
  br i1 %cond8960, label %bb_rcslotdrop2076, label %bb_rcslotdone2076
bb_rcslotdrop2076:
  %v8961 = load i64, ptr %slot9, align 8
  %p8962 = inttoptr i64 %v8961 to ptr
  store i32 0, ptr %p8962, align 4, !alias.scope !3, !noalias !4
  %v8963 = load i64, ptr %slot40, align 8
  store i64 %v8963, ptr %slot1654, align 8
  %v8964 = load i64, ptr %slot10, align 8
  %p8965 = inttoptr i64 %v8964 to ptr
  %ld8966 = load i32, ptr %p8965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8966, ptr %slot1655, align 8
  %v8967 = load i32, ptr %slot1655, align 8
  %op8968 = and i32 %v8967, 28
  store i32 %op8968, ptr %slot1656, align 8
  %v8969 = load i32, ptr %slot1656, align 8
  %cv8970 = zext i32 %v8969 to i64
  %cond8971 = icmp ne i64 %cv8970, 0
  br i1 %cond8971, label %bb_rcslotrole2076, label %bb_rcslotowner2076
bb_rcslotrole2076:
  %v8972 = load i64, ptr %slot59, align 8
  store i64 %v8972, ptr %slot1657, align 8
  %v8973 = load i64, ptr %slot1654, align 8
  %p8974 = inttoptr i64 %v8973 to ptr
  %ld8975 = load i64, ptr %p8974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8975, ptr %slot1658, align 8
  %v8976 = load i64, ptr %slot1658, align 8
  %cmp8977 = icmp ne i64 %v8976, 0
  %cv8978 = zext i1 %cmp8977 to i32
  store i32 %cv8978, ptr %slot1659, align 8
  %v8979 = load i32, ptr %slot1659, align 8
  %cv8980 = zext i32 %v8979 to i64
  %cond8981 = icmp ne i64 %cv8980, 0
  br i1 %cond8981, label %bb_rcgnn2092, label %bb_rcgdone2092
bb_rcgnn2092:
  %v8982 = load i64, ptr %slot1658, align 8
  %op8983 = sub i64 %v8982, 16
  store i64 %op8983, ptr %slot1660, align 8
  %v8984 = load i64, ptr %slot1658, align 8
  %p8985 = inttoptr i64 %v8984 to ptr
  %rgep8986 = getelementptr i8, ptr %p8985, i64 -16
  %ld8987 = load i64, ptr %rgep8986, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8987, ptr %slot1661, align 8
  %v8988 = load i64, ptr %slot1661, align 8
  %op8989 = and i64 %v8988, 4611686018427387906
  store i64 %op8989, ptr %slot1662, align 8
  %v8990 = load i64, ptr %slot1662, align 8
  %cmp8991 = icmp ne i64 %v8990, 0
  %cv8992 = zext i1 %cmp8991 to i32
  store i32 %cv8992, ptr %slot1663, align 8
  %v8993 = load i32, ptr %slot1663, align 8
  %cv8994 = zext i32 %v8993 to i64
  %cond8995 = icmp ne i64 %cv8994, 0
  br i1 %cond8995, label %bb_rcgclear2092, label %bb_rcgcounted2092
bb_rcgcounted2092:
  %v8996 = load i64, ptr %slot1658, align 8
  %op8997 = sub i64 %v8996, 24
  store i64 %op8997, ptr %slot1664, align 8
  %v8998 = load i64, ptr %slot1658, align 8
  %p8999 = inttoptr i64 %v8998 to ptr
  %rgep9000 = getelementptr i8, ptr %p8999, i64 -24
  %ld9001 = load i64, ptr %rgep9000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9001, ptr %slot1665, align 8
  %v9002 = load i64, ptr %slot1665, align 8
  %op9003 = sub i64 %v9002, 1
  store i64 %op9003, ptr %slot1666, align 8
  %v9004 = load i64, ptr %slot1666, align 8
  %cmp9005 = icmp eq i64 %v9004, 0
  %cv9006 = zext i1 %cmp9005 to i32
  store i32 %cv9006, ptr %slot1667, align 8
  %v9007 = load i32, ptr %slot1667, align 8
  %cv9008 = zext i32 %v9007 to i64
  %cond9009 = icmp ne i64 %cv9008, 0
  br i1 %cond9009, label %bb_rcglast2092, label %bb_rcgdec2092
bb_rcglast2092:
  %v9010 = load i64, ptr %slot1658, align 8
  %op9011 = sub i64 %v9010, 32
  store i64 %op9011, ptr %slot1668, align 8
  %v9012 = load i64, ptr %slot1658, align 8
  %p9013 = inttoptr i64 %v9012 to ptr
  %rgep9014 = getelementptr i8, ptr %p9013, i64 -32
  %ld9015 = load i64, ptr %rgep9014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9015, ptr %slot1669, align 8
  %v9016 = load i64, ptr %slot1669, align 8
  %cmp9017 = icmp ne i64 %v9016, 0
  %cv9018 = zext i1 %cmp9017 to i32
  store i32 %cv9018, ptr %slot1670, align 8
  %v9019 = load i32, ptr %slot1670, align 8
  %cv9020 = zext i32 %v9019 to i64
  %cond9021 = icmp ne i64 %cv9020, 0
  br i1 %cond9021, label %bb_rcgdec2092, label %bb_rcgslow2092
bb_rcgslow2092:
  %v9022 = load i64, ptr %slot1657, align 8
  %v9023 = load i64, ptr %slot1654, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v9022, i64 %v9023) nomerge, !dbg !174
  br label %bb_rcgdone2092
bb_rcgdec2092:
  %v9024 = load i64, ptr %slot1666, align 8
  %v9025 = load i64, ptr %slot1658, align 8
  %p9026 = inttoptr i64 %v9025 to ptr
  %rgep9027 = getelementptr i8, ptr %p9026, i64 -24
  store i64 %v9024, ptr %rgep9027, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2092
bb_rcgclear2092:
  %v9028 = load i64, ptr %slot1654, align 8
  %p9029 = inttoptr i64 %v9028 to ptr
  store i64 0, ptr %p9029, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2092
bb_rcgdone2092:
  br label %bb_rcslotdone2076
bb_rcslotowner2076:
  %v9030 = load i64, ptr %slot59, align 8
  store i64 %v9030, ptr %slot1671, align 8
  %v9031 = load i64, ptr %slot1654, align 8
  %p9032 = inttoptr i64 %v9031 to ptr
  %ld9033 = load i64, ptr %p9032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9033, ptr %slot1672, align 8
  %v9034 = load i64, ptr %slot1672, align 8
  %cmp9035 = icmp ne i64 %v9034, 0
  %cv9036 = zext i1 %cmp9035 to i32
  store i32 %cv9036, ptr %slot1673, align 8
  %v9037 = load i32, ptr %slot1673, align 8
  %cv9038 = zext i32 %v9037 to i64
  %cond9039 = icmp ne i64 %cv9038, 0
  br i1 %cond9039, label %bb_rcgnn2107, label %bb_rcgdone2107
bb_rcgnn2107:
  %v9040 = load i64, ptr %slot1672, align 8
  %op9041 = sub i64 %v9040, 16
  store i64 %op9041, ptr %slot1674, align 8
  %v9042 = load i64, ptr %slot1672, align 8
  %p9043 = inttoptr i64 %v9042 to ptr
  %rgep9044 = getelementptr i8, ptr %p9043, i64 -16
  %ld9045 = load i64, ptr %rgep9044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9045, ptr %slot1675, align 8
  %v9046 = load i64, ptr %slot1675, align 8
  %op9047 = and i64 %v9046, 4611686018427387906
  store i64 %op9047, ptr %slot1676, align 8
  %v9048 = load i64, ptr %slot1676, align 8
  %cmp9049 = icmp ne i64 %v9048, 0
  %cv9050 = zext i1 %cmp9049 to i32
  store i32 %cv9050, ptr %slot1677, align 8
  %v9051 = load i32, ptr %slot1677, align 8
  %cv9052 = zext i32 %v9051 to i64
  %cond9053 = icmp ne i64 %cv9052, 0
  br i1 %cond9053, label %bb_rcgclear2107, label %bb_rcgcounted2107
bb_rcgcounted2107:
  %v9054 = load i64, ptr %slot1672, align 8
  %op9055 = sub i64 %v9054, 32
  store i64 %op9055, ptr %slot1678, align 8
  %v9056 = load i64, ptr %slot1672, align 8
  %p9057 = inttoptr i64 %v9056 to ptr
  %rgep9058 = getelementptr i8, ptr %p9057, i64 -32
  %ld9059 = load i64, ptr %rgep9058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9059, ptr %slot1679, align 8
  %v9060 = load i64, ptr %slot1679, align 8
  %op9061 = sub i64 %v9060, 1
  store i64 %op9061, ptr %slot1680, align 8
  %v9062 = load i64, ptr %slot1680, align 8
  %cmp9063 = icmp eq i64 %v9062, 0
  %cv9064 = zext i1 %cmp9063 to i32
  store i32 %cv9064, ptr %slot1681, align 8
  %v9065 = load i32, ptr %slot1681, align 8
  %cv9066 = zext i32 %v9065 to i64
  %cond9067 = icmp ne i64 %cv9066, 0
  br i1 %cond9067, label %bb_rcglast2107, label %bb_rcgdec2107
bb_rcglast2107:
  %v9068 = load i64, ptr %slot1672, align 8
  %op9069 = sub i64 %v9068, 24
  store i64 %op9069, ptr %slot1682, align 8
  %v9070 = load i64, ptr %slot1672, align 8
  %p9071 = inttoptr i64 %v9070 to ptr
  %rgep9072 = getelementptr i8, ptr %p9071, i64 -24
  %ld9073 = load i64, ptr %rgep9072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9073, ptr %slot1683, align 8
  %v9074 = load i64, ptr %slot1683, align 8
  %cmp9075 = icmp ne i64 %v9074, 0
  %cv9076 = zext i1 %cmp9075 to i32
  store i32 %cv9076, ptr %slot1684, align 8
  %v9077 = load i32, ptr %slot1684, align 8
  %cv9078 = zext i32 %v9077 to i64
  %cond9079 = icmp ne i64 %cv9078, 0
  br i1 %cond9079, label %bb_rcgdec2107, label %bb_rcgslow2107
bb_rcgslow2107:
  %v9080 = load i64, ptr %slot1671, align 8
  %v9081 = load i64, ptr %slot1654, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v9080, i64 %v9081) nomerge, !dbg !174
  br label %bb_rcgdone2107
bb_rcgdec2107:
  %v9082 = load i64, ptr %slot1680, align 8
  %v9083 = load i64, ptr %slot1672, align 8
  %p9084 = inttoptr i64 %v9083 to ptr
  %rgep9085 = getelementptr i8, ptr %p9084, i64 -32
  store i64 %v9082, ptr %rgep9085, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2107
bb_rcgclear2107:
  %v9086 = load i64, ptr %slot1654, align 8
  %p9087 = inttoptr i64 %v9086 to ptr
  store i64 0, ptr %p9087, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2107
bb_rcgdone2107:
  br label %bb_rcslotdone2076
bb_rcslotdone2076:
  %v9088 = load i64, ptr %slot7, align 8
  %p9089 = inttoptr i64 %v9088 to ptr
  %ld9090 = load i32, ptr %p9089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9090, ptr %slot1685, align 8
  %v9091 = load i32, ptr %slot1685, align 8
  %cv9092 = zext i32 %v9091 to i64
  %cond9093 = icmp ne i64 %cv9092, 0
  br i1 %cond9093, label %bb_rcslotdrop2122, label %bb_rcslotdone2122
bb_rcslotdrop2122:
  %v9094 = load i64, ptr %slot7, align 8
  %p9095 = inttoptr i64 %v9094 to ptr
  store i32 0, ptr %p9095, align 4, !alias.scope !3, !noalias !4
  %v9096 = load i64, ptr %slot37, align 8
  store i64 %v9096, ptr %slot1686, align 8
  %v9097 = load i64, ptr %slot8, align 8
  %p9098 = inttoptr i64 %v9097 to ptr
  %ld9099 = load i32, ptr %p9098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9099, ptr %slot1687, align 8
  %v9100 = load i32, ptr %slot1687, align 8
  %op9101 = and i32 %v9100, 28
  store i32 %op9101, ptr %slot1688, align 8
  %v9102 = load i32, ptr %slot1688, align 8
  %cv9103 = zext i32 %v9102 to i64
  %cond9104 = icmp ne i64 %cv9103, 0
  br i1 %cond9104, label %bb_rcslotrole2122, label %bb_rcslotowner2122
bb_rcslotrole2122:
  %v9105 = load i64, ptr %slot59, align 8
  store i64 %v9105, ptr %slot1689, align 8
  %v9106 = load i64, ptr %slot1686, align 8
  %p9107 = inttoptr i64 %v9106 to ptr
  %ld9108 = load i64, ptr %p9107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9108, ptr %slot1690, align 8
  %v9109 = load i64, ptr %slot1690, align 8
  %cmp9110 = icmp ne i64 %v9109, 0
  %cv9111 = zext i1 %cmp9110 to i32
  store i32 %cv9111, ptr %slot1691, align 8
  %v9112 = load i32, ptr %slot1691, align 8
  %cv9113 = zext i32 %v9112 to i64
  %cond9114 = icmp ne i64 %cv9113, 0
  br i1 %cond9114, label %bb_rcgnn2138, label %bb_rcgdone2138
bb_rcgnn2138:
  %v9115 = load i64, ptr %slot1690, align 8
  %op9116 = sub i64 %v9115, 16
  store i64 %op9116, ptr %slot1692, align 8
  %v9117 = load i64, ptr %slot1690, align 8
  %p9118 = inttoptr i64 %v9117 to ptr
  %rgep9119 = getelementptr i8, ptr %p9118, i64 -16
  %ld9120 = load i64, ptr %rgep9119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9120, ptr %slot1693, align 8
  %v9121 = load i64, ptr %slot1693, align 8
  %op9122 = and i64 %v9121, 4611686018427387906
  store i64 %op9122, ptr %slot1694, align 8
  %v9123 = load i64, ptr %slot1694, align 8
  %cmp9124 = icmp ne i64 %v9123, 0
  %cv9125 = zext i1 %cmp9124 to i32
  store i32 %cv9125, ptr %slot1695, align 8
  %v9126 = load i32, ptr %slot1695, align 8
  %cv9127 = zext i32 %v9126 to i64
  %cond9128 = icmp ne i64 %cv9127, 0
  br i1 %cond9128, label %bb_rcgclear2138, label %bb_rcgcounted2138
bb_rcgcounted2138:
  %v9129 = load i64, ptr %slot1690, align 8
  %op9130 = sub i64 %v9129, 24
  store i64 %op9130, ptr %slot1696, align 8
  %v9131 = load i64, ptr %slot1690, align 8
  %p9132 = inttoptr i64 %v9131 to ptr
  %rgep9133 = getelementptr i8, ptr %p9132, i64 -24
  %ld9134 = load i64, ptr %rgep9133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9134, ptr %slot1697, align 8
  %v9135 = load i64, ptr %slot1697, align 8
  %op9136 = sub i64 %v9135, 1
  store i64 %op9136, ptr %slot1698, align 8
  %v9137 = load i64, ptr %slot1698, align 8
  %cmp9138 = icmp eq i64 %v9137, 0
  %cv9139 = zext i1 %cmp9138 to i32
  store i32 %cv9139, ptr %slot1699, align 8
  %v9140 = load i32, ptr %slot1699, align 8
  %cv9141 = zext i32 %v9140 to i64
  %cond9142 = icmp ne i64 %cv9141, 0
  br i1 %cond9142, label %bb_rcglast2138, label %bb_rcgdec2138
bb_rcglast2138:
  %v9143 = load i64, ptr %slot1690, align 8
  %op9144 = sub i64 %v9143, 32
  store i64 %op9144, ptr %slot1700, align 8
  %v9145 = load i64, ptr %slot1690, align 8
  %p9146 = inttoptr i64 %v9145 to ptr
  %rgep9147 = getelementptr i8, ptr %p9146, i64 -32
  %ld9148 = load i64, ptr %rgep9147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9148, ptr %slot1701, align 8
  %v9149 = load i64, ptr %slot1701, align 8
  %cmp9150 = icmp ne i64 %v9149, 0
  %cv9151 = zext i1 %cmp9150 to i32
  store i32 %cv9151, ptr %slot1702, align 8
  %v9152 = load i32, ptr %slot1702, align 8
  %cv9153 = zext i32 %v9152 to i64
  %cond9154 = icmp ne i64 %cv9153, 0
  br i1 %cond9154, label %bb_rcgdec2138, label %bb_rcgslow2138
bb_rcgslow2138:
  %v9155 = load i64, ptr %slot1689, align 8
  %v9156 = load i64, ptr %slot1686, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v9155, i64 %v9156) nomerge, !dbg !174
  br label %bb_rcgdone2138
bb_rcgdec2138:
  %v9157 = load i64, ptr %slot1698, align 8
  %v9158 = load i64, ptr %slot1690, align 8
  %p9159 = inttoptr i64 %v9158 to ptr
  %rgep9160 = getelementptr i8, ptr %p9159, i64 -24
  store i64 %v9157, ptr %rgep9160, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2138
bb_rcgclear2138:
  %v9161 = load i64, ptr %slot1686, align 8
  %p9162 = inttoptr i64 %v9161 to ptr
  store i64 0, ptr %p9162, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2138
bb_rcgdone2138:
  br label %bb_rcslotdone2122
bb_rcslotowner2122:
  %v9163 = load i64, ptr %slot59, align 8
  store i64 %v9163, ptr %slot1703, align 8
  %v9164 = load i64, ptr %slot1686, align 8
  %p9165 = inttoptr i64 %v9164 to ptr
  %ld9166 = load i64, ptr %p9165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9166, ptr %slot1704, align 8
  %v9167 = load i64, ptr %slot1704, align 8
  %cmp9168 = icmp ne i64 %v9167, 0
  %cv9169 = zext i1 %cmp9168 to i32
  store i32 %cv9169, ptr %slot1705, align 8
  %v9170 = load i32, ptr %slot1705, align 8
  %cv9171 = zext i32 %v9170 to i64
  %cond9172 = icmp ne i64 %cv9171, 0
  br i1 %cond9172, label %bb_rcgnn2153, label %bb_rcgdone2153
bb_rcgnn2153:
  %v9173 = load i64, ptr %slot1704, align 8
  %op9174 = sub i64 %v9173, 16
  store i64 %op9174, ptr %slot1706, align 8
  %v9175 = load i64, ptr %slot1704, align 8
  %p9176 = inttoptr i64 %v9175 to ptr
  %rgep9177 = getelementptr i8, ptr %p9176, i64 -16
  %ld9178 = load i64, ptr %rgep9177, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9178, ptr %slot1707, align 8
  %v9179 = load i64, ptr %slot1707, align 8
  %op9180 = and i64 %v9179, 4611686018427387906
  store i64 %op9180, ptr %slot1708, align 8
  %v9181 = load i64, ptr %slot1708, align 8
  %cmp9182 = icmp ne i64 %v9181, 0
  %cv9183 = zext i1 %cmp9182 to i32
  store i32 %cv9183, ptr %slot1709, align 8
  %v9184 = load i32, ptr %slot1709, align 8
  %cv9185 = zext i32 %v9184 to i64
  %cond9186 = icmp ne i64 %cv9185, 0
  br i1 %cond9186, label %bb_rcgclear2153, label %bb_rcgcounted2153
bb_rcgcounted2153:
  %v9187 = load i64, ptr %slot1704, align 8
  %op9188 = sub i64 %v9187, 32
  store i64 %op9188, ptr %slot1710, align 8
  %v9189 = load i64, ptr %slot1704, align 8
  %p9190 = inttoptr i64 %v9189 to ptr
  %rgep9191 = getelementptr i8, ptr %p9190, i64 -32
  %ld9192 = load i64, ptr %rgep9191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9192, ptr %slot1711, align 8
  %v9193 = load i64, ptr %slot1711, align 8
  %op9194 = sub i64 %v9193, 1
  store i64 %op9194, ptr %slot1712, align 8
  %v9195 = load i64, ptr %slot1712, align 8
  %cmp9196 = icmp eq i64 %v9195, 0
  %cv9197 = zext i1 %cmp9196 to i32
  store i32 %cv9197, ptr %slot1713, align 8
  %v9198 = load i32, ptr %slot1713, align 8
  %cv9199 = zext i32 %v9198 to i64
  %cond9200 = icmp ne i64 %cv9199, 0
  br i1 %cond9200, label %bb_rcglast2153, label %bb_rcgdec2153
bb_rcglast2153:
  %v9201 = load i64, ptr %slot1704, align 8
  %op9202 = sub i64 %v9201, 24
  store i64 %op9202, ptr %slot1714, align 8
  %v9203 = load i64, ptr %slot1704, align 8
  %p9204 = inttoptr i64 %v9203 to ptr
  %rgep9205 = getelementptr i8, ptr %p9204, i64 -24
  %ld9206 = load i64, ptr %rgep9205, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9206, ptr %slot1715, align 8
  %v9207 = load i64, ptr %slot1715, align 8
  %cmp9208 = icmp ne i64 %v9207, 0
  %cv9209 = zext i1 %cmp9208 to i32
  store i32 %cv9209, ptr %slot1716, align 8
  %v9210 = load i32, ptr %slot1716, align 8
  %cv9211 = zext i32 %v9210 to i64
  %cond9212 = icmp ne i64 %cv9211, 0
  br i1 %cond9212, label %bb_rcgdec2153, label %bb_rcgslow2153
bb_rcgslow2153:
  %v9213 = load i64, ptr %slot1703, align 8
  %v9214 = load i64, ptr %slot1686, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v9213, i64 %v9214) nomerge, !dbg !174
  br label %bb_rcgdone2153
bb_rcgdec2153:
  %v9215 = load i64, ptr %slot1712, align 8
  %v9216 = load i64, ptr %slot1704, align 8
  %p9217 = inttoptr i64 %v9216 to ptr
  %rgep9218 = getelementptr i8, ptr %p9217, i64 -32
  store i64 %v9215, ptr %rgep9218, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2153
bb_rcgclear2153:
  %v9219 = load i64, ptr %slot1686, align 8
  %p9220 = inttoptr i64 %v9219 to ptr
  store i64 0, ptr %p9220, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2153
bb_rcgdone2153:
  br label %bb_rcslotdone2122
bb_rcslotdone2122:
  %v9221 = load i64, ptr %slot5, align 8
  %p9222 = inttoptr i64 %v9221 to ptr
  %ld9223 = load i32, ptr %p9222, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9223, ptr %slot1717, align 8
  %v9224 = load i32, ptr %slot1717, align 8
  %cv9225 = zext i32 %v9224 to i64
  %cond9226 = icmp ne i64 %cv9225, 0
  br i1 %cond9226, label %bb_rcslotdrop2159, label %bb_rcslotdone2159
bb_rcslotdrop2159:
  %v9227 = load i64, ptr %slot5, align 8
  %p9228 = inttoptr i64 %v9227 to ptr
  store i32 0, ptr %p9228, align 4, !alias.scope !3, !noalias !4
  %v9229 = load i64, ptr %slot36, align 8
  store i64 %v9229, ptr %slot1718, align 8
  %v9230 = load i64, ptr %slot6, align 8
  %p9231 = inttoptr i64 %v9230 to ptr
  %ld9232 = load i32, ptr %p9231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9232, ptr %slot1719, align 8
  %v9233 = load i32, ptr %slot1719, align 8
  %op9234 = and i32 %v9233, 28
  store i32 %op9234, ptr %slot1720, align 8
  %v9235 = load i32, ptr %slot1720, align 8
  %cv9236 = zext i32 %v9235 to i64
  %cond9237 = icmp ne i64 %cv9236, 0
  br i1 %cond9237, label %bb_rcslotrole2159, label %bb_rcslotowner2159
bb_rcslotrole2159:
  %v9238 = load i64, ptr %slot59, align 8
  store i64 %v9238, ptr %slot1721, align 8
  %v9239 = load i64, ptr %slot1718, align 8
  %p9240 = inttoptr i64 %v9239 to ptr
  %ld9241 = load i64, ptr %p9240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9241, ptr %slot1722, align 8
  %v9242 = load i64, ptr %slot1722, align 8
  %cmp9243 = icmp ne i64 %v9242, 0
  %cv9244 = zext i1 %cmp9243 to i32
  store i32 %cv9244, ptr %slot1723, align 8
  %v9245 = load i32, ptr %slot1723, align 8
  %cv9246 = zext i32 %v9245 to i64
  %cond9247 = icmp ne i64 %cv9246, 0
  br i1 %cond9247, label %bb_rcgnn2175, label %bb_rcgdone2175
bb_rcgnn2175:
  %v9248 = load i64, ptr %slot1722, align 8
  %op9249 = sub i64 %v9248, 16
  store i64 %op9249, ptr %slot1724, align 8
  %v9250 = load i64, ptr %slot1722, align 8
  %p9251 = inttoptr i64 %v9250 to ptr
  %rgep9252 = getelementptr i8, ptr %p9251, i64 -16
  %ld9253 = load i64, ptr %rgep9252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9253, ptr %slot1725, align 8
  %v9254 = load i64, ptr %slot1725, align 8
  %op9255 = and i64 %v9254, 4611686018427387906
  store i64 %op9255, ptr %slot1726, align 8
  %v9256 = load i64, ptr %slot1726, align 8
  %cmp9257 = icmp ne i64 %v9256, 0
  %cv9258 = zext i1 %cmp9257 to i32
  store i32 %cv9258, ptr %slot1727, align 8
  %v9259 = load i32, ptr %slot1727, align 8
  %cv9260 = zext i32 %v9259 to i64
  %cond9261 = icmp ne i64 %cv9260, 0
  br i1 %cond9261, label %bb_rcgclear2175, label %bb_rcgcounted2175
bb_rcgcounted2175:
  %v9262 = load i64, ptr %slot1722, align 8
  %op9263 = sub i64 %v9262, 24
  store i64 %op9263, ptr %slot1728, align 8
  %v9264 = load i64, ptr %slot1722, align 8
  %p9265 = inttoptr i64 %v9264 to ptr
  %rgep9266 = getelementptr i8, ptr %p9265, i64 -24
  %ld9267 = load i64, ptr %rgep9266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9267, ptr %slot1729, align 8
  %v9268 = load i64, ptr %slot1729, align 8
  %op9269 = sub i64 %v9268, 1
  store i64 %op9269, ptr %slot1730, align 8
  %v9270 = load i64, ptr %slot1730, align 8
  %cmp9271 = icmp eq i64 %v9270, 0
  %cv9272 = zext i1 %cmp9271 to i32
  store i32 %cv9272, ptr %slot1731, align 8
  %v9273 = load i32, ptr %slot1731, align 8
  %cv9274 = zext i32 %v9273 to i64
  %cond9275 = icmp ne i64 %cv9274, 0
  br i1 %cond9275, label %bb_rcglast2175, label %bb_rcgdec2175
bb_rcglast2175:
  %v9276 = load i64, ptr %slot1722, align 8
  %op9277 = sub i64 %v9276, 32
  store i64 %op9277, ptr %slot1732, align 8
  %v9278 = load i64, ptr %slot1722, align 8
  %p9279 = inttoptr i64 %v9278 to ptr
  %rgep9280 = getelementptr i8, ptr %p9279, i64 -32
  %ld9281 = load i64, ptr %rgep9280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9281, ptr %slot1733, align 8
  %v9282 = load i64, ptr %slot1733, align 8
  %cmp9283 = icmp ne i64 %v9282, 0
  %cv9284 = zext i1 %cmp9283 to i32
  store i32 %cv9284, ptr %slot1734, align 8
  %v9285 = load i32, ptr %slot1734, align 8
  %cv9286 = zext i32 %v9285 to i64
  %cond9287 = icmp ne i64 %cv9286, 0
  br i1 %cond9287, label %bb_rcgdec2175, label %bb_rcgslow2175
bb_rcgslow2175:
  %v9288 = load i64, ptr %slot1721, align 8
  %v9289 = load i64, ptr %slot1718, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v9288, i64 %v9289) nomerge, !dbg !174
  br label %bb_rcgdone2175
bb_rcgdec2175:
  %v9290 = load i64, ptr %slot1730, align 8
  %v9291 = load i64, ptr %slot1722, align 8
  %p9292 = inttoptr i64 %v9291 to ptr
  %rgep9293 = getelementptr i8, ptr %p9292, i64 -24
  store i64 %v9290, ptr %rgep9293, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2175
bb_rcgclear2175:
  %v9294 = load i64, ptr %slot1718, align 8
  %p9295 = inttoptr i64 %v9294 to ptr
  store i64 0, ptr %p9295, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2175
bb_rcgdone2175:
  br label %bb_rcslotdone2159
bb_rcslotowner2159:
  %v9296 = load i64, ptr %slot59, align 8
  store i64 %v9296, ptr %slot1735, align 8
  %v9297 = load i64, ptr %slot1718, align 8
  %p9298 = inttoptr i64 %v9297 to ptr
  %ld9299 = load i64, ptr %p9298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9299, ptr %slot1736, align 8
  %v9300 = load i64, ptr %slot1736, align 8
  %cmp9301 = icmp ne i64 %v9300, 0
  %cv9302 = zext i1 %cmp9301 to i32
  store i32 %cv9302, ptr %slot1737, align 8
  %v9303 = load i32, ptr %slot1737, align 8
  %cv9304 = zext i32 %v9303 to i64
  %cond9305 = icmp ne i64 %cv9304, 0
  br i1 %cond9305, label %bb_rcgnn2190, label %bb_rcgdone2190
bb_rcgnn2190:
  %v9306 = load i64, ptr %slot1736, align 8
  %op9307 = sub i64 %v9306, 16
  store i64 %op9307, ptr %slot1738, align 8
  %v9308 = load i64, ptr %slot1736, align 8
  %p9309 = inttoptr i64 %v9308 to ptr
  %rgep9310 = getelementptr i8, ptr %p9309, i64 -16
  %ld9311 = load i64, ptr %rgep9310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9311, ptr %slot1739, align 8
  %v9312 = load i64, ptr %slot1739, align 8
  %op9313 = and i64 %v9312, 4611686018427387906
  store i64 %op9313, ptr %slot1740, align 8
  %v9314 = load i64, ptr %slot1740, align 8
  %cmp9315 = icmp ne i64 %v9314, 0
  %cv9316 = zext i1 %cmp9315 to i32
  store i32 %cv9316, ptr %slot1741, align 8
  %v9317 = load i32, ptr %slot1741, align 8
  %cv9318 = zext i32 %v9317 to i64
  %cond9319 = icmp ne i64 %cv9318, 0
  br i1 %cond9319, label %bb_rcgclear2190, label %bb_rcgcounted2190
bb_rcgcounted2190:
  %v9320 = load i64, ptr %slot1736, align 8
  %op9321 = sub i64 %v9320, 32
  store i64 %op9321, ptr %slot1742, align 8
  %v9322 = load i64, ptr %slot1736, align 8
  %p9323 = inttoptr i64 %v9322 to ptr
  %rgep9324 = getelementptr i8, ptr %p9323, i64 -32
  %ld9325 = load i64, ptr %rgep9324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9325, ptr %slot1743, align 8
  %v9326 = load i64, ptr %slot1743, align 8
  %op9327 = sub i64 %v9326, 1
  store i64 %op9327, ptr %slot1744, align 8
  %v9328 = load i64, ptr %slot1744, align 8
  %cmp9329 = icmp eq i64 %v9328, 0
  %cv9330 = zext i1 %cmp9329 to i32
  store i32 %cv9330, ptr %slot1745, align 8
  %v9331 = load i32, ptr %slot1745, align 8
  %cv9332 = zext i32 %v9331 to i64
  %cond9333 = icmp ne i64 %cv9332, 0
  br i1 %cond9333, label %bb_rcglast2190, label %bb_rcgdec2190
bb_rcglast2190:
  %v9334 = load i64, ptr %slot1736, align 8
  %op9335 = sub i64 %v9334, 24
  store i64 %op9335, ptr %slot1746, align 8
  %v9336 = load i64, ptr %slot1736, align 8
  %p9337 = inttoptr i64 %v9336 to ptr
  %rgep9338 = getelementptr i8, ptr %p9337, i64 -24
  %ld9339 = load i64, ptr %rgep9338, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9339, ptr %slot1747, align 8
  %v9340 = load i64, ptr %slot1747, align 8
  %cmp9341 = icmp ne i64 %v9340, 0
  %cv9342 = zext i1 %cmp9341 to i32
  store i32 %cv9342, ptr %slot1748, align 8
  %v9343 = load i32, ptr %slot1748, align 8
  %cv9344 = zext i32 %v9343 to i64
  %cond9345 = icmp ne i64 %cv9344, 0
  br i1 %cond9345, label %bb_rcgdec2190, label %bb_rcgslow2190
bb_rcgslow2190:
  %v9346 = load i64, ptr %slot1735, align 8
  %v9347 = load i64, ptr %slot1718, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v9346, i64 %v9347) nomerge, !dbg !174
  br label %bb_rcgdone2190
bb_rcgdec2190:
  %v9348 = load i64, ptr %slot1744, align 8
  %v9349 = load i64, ptr %slot1736, align 8
  %p9350 = inttoptr i64 %v9349 to ptr
  %rgep9351 = getelementptr i8, ptr %p9350, i64 -32
  store i64 %v9348, ptr %rgep9351, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2190
bb_rcgclear2190:
  %v9352 = load i64, ptr %slot1718, align 8
  %p9353 = inttoptr i64 %v9352 to ptr
  store i64 0, ptr %p9353, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2190
bb_rcgdone2190:
  br label %bb_rcslotdone2159
bb_rcslotdone2159:
  %v9354 = load i64, ptr %slot1574, align 8
  ret i64 %v9354
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da = external global i8, align 8
@myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1e099eb74b6fcbebc692a37dfef561df04e37fcd789b3166f766bf5c788dbb7d(i64, i64, i64, i64)
declare void @myl_f_f9596c0ae80ae31480fb911cf78c48a39c632b6cf68d532231bbaef0695efd77(ptr sret([32 x i8]) align 8, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da_rcg_list_append(i64, i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 32v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!10000001 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_644193575e7ca3819ff8cca0770f7088b7303a9d14824bb71a025502ece87239", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_644193575e7ca3819ff8cca0770f7088b7303a9d14824bb71a025502ece87239", linkageName: "myl_f_644193575e7ca3819ff8cca0770f7088b7303a9d14824bb71a025502ece87239", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4413073967460635435, i64 0, !"myl_f_644193575e7ca3819ff8cca0770f7088b7303a9d14824bb71a025502ece87239"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!118 = !DILocation(line: 4, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!120 = !DILocation(line: 6, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!128 = !DILocation(line: 34, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!130 = !DILocation(line: 35, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!132 = !DILocation(line: 39, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!134 = !DILocation(line: 46, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!136 = !DILocation(line: 49, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!138 = !DILocation(line: 58, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!140 = !DILocation(line: 59, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!142 = !DILocation(line: 60, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!144 = !DILocation(line: 65, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!146 = !DILocation(line: 72, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!148 = !DILocation(line: 74, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!150 = !DILocation(line: 78, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!152 = !DILocation(line: 81, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!154 = !DILocation(line: 83, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!156 = !DILocation(line: 96, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647335)
!158 = !DILocation(line: 100, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647359)
!160 = !DILocation(line: 103, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!162 = !DILocation(line: 104, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!164 = !DILocation(line: 106, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647399)
!166 = !DILocation(line: 108, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!168 = !DILocation(line: 110, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647431)
!170 = !DILocation(line: 112, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!172 = !DILocation(line: 113, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!174 = !DILocation(line: 117, column: 0, scope: !175)
