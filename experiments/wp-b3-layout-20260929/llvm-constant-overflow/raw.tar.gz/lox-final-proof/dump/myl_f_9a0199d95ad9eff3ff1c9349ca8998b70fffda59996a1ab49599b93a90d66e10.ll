target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9a0199d95ad9eff3ff1c9349ca8998b70fffda59996a1ab49599b93a90d66e10(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %callresult36 = alloca [16 x i8], align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %callresult40 = alloca [16 x i8], align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %callresult64 = alloca [16 x i8], align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %callresult79 = alloca [16 x i8], align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %callresult83 = alloca [16 x i8], align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v136 = load i64, ptr %slot1, align 8
  %op137 = add i64 %v136, 32
  store i64 %op137, ptr %slot5, align 8
  %mem138 = alloca i8, i64 8, align 8
  %ptr139 = ptrtoint ptr %mem138 to i64
  store i64 %ptr139, ptr %slot6, align 8
  %mem140 = alloca i8, i64 8, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot7, align 8
  %mem142 = alloca i8, i64 8, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot8, align 8
  %mem144 = alloca i8, i64 8, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot9, align 8
  %mem146 = alloca i8, i64 8, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot10, align 8
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot11, align 8
  %mem150 = alloca i8, i64 208, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot12, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot13, align 8
  %mem154 = alloca i8, i64 8, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot14, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot15, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot16, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot17, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot18, align 8
  %mem164 = alloca i8, i64 16, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot19, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot20, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot21, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot22, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot23, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot24, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot25, align 8
  %v178 = load i64, ptr %slot1, align 8
  %op179 = add i64 %v178, 64
  store i64 %op179, ptr %slot26, align 8
  %v180 = load i64, ptr %slot26, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !4, !noalias !3
  store i64 %ld182, ptr %slot27, align 8
  %stack183 = call ptr @llvm.stacksave()
  %stackaddr184 = ptrtoint ptr %stack183 to i64
  %v185 = load i64, ptr %slot27, align 8
  %cmp186 = icmp ult i64 %stackaddr184, %v185
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot28, align 8
  %v188 = load i64, ptr %slot28, align 8
  %cond189 = icmp ne i64 %v188, 0
  br i1 %cond189, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v190 = load i64, ptr %slot1, align 8
  %p191 = inttoptr i64 %v190 to ptr
  call void @myl_qbe_fail_frame(ptr %p191) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v192 = load i64, ptr %slot2, align 8
  %v193 = load i64, ptr %slot13, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot3, align 8
  %v196 = load i64, ptr %slot14, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot4, align 8
  %v199 = load i64, ptr %slot15, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot1, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %call203 = call ptr @myl_qbe_heap(ptr %p202) nomerge, !dbg !112
  %calladdr204 = ptrtoint ptr %call203 to i64
  store i64 %calladdr204, ptr %slot29, align 8
  %v205 = load i64, ptr %slot1, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %call207 = call i64 @myl_qbe_region_mark(ptr %p206) nomerge, !dbg !112
  store i64 %call207, ptr %slot30, align 8
  %v208 = load i64, ptr %slot6, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i32 0, ptr %p209, align 4, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot7, align 8
  %p211 = inttoptr i64 %v210 to ptr
  store i32 0, ptr %p211, align 4, !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot8, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i32 0, ptr %p213, align 4, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot9, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i32 0, ptr %p215, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v216 = load i64, ptr %slot13, align 8
  %p217 = inttoptr i64 %v216 to ptr
  %ld218 = load i64, ptr %p217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld218, ptr %slot31, align 8
  %v219 = load i64, ptr %slot31, align 8
  %v220 = load i64, ptr %slot20, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i64 %v219, ptr %p221, align 8, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot13, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot32, align 8
  %v225 = load i64, ptr %slot32, align 8
  %v226 = load i64, ptr %slot21, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 %v225, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot22, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 1, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot21, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot33, align 8
  %v233 = load i64, ptr %slot22, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot34, align 8
  %v236 = load i64, ptr %slot1, align 8
  %v237 = load i64, ptr %slot33, align 8
  %v238 = load i64, ptr %slot34, align 8
  %call239 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v236, i64 %v237, i64 %v238) nomerge, !dbg !114
  store { i64, i64 } %call239, ptr %callresult36, align 8
  %addr240 = ptrtoint ptr %callresult36 to i64
  store i64 %addr240, ptr %slot35, align 8
  %v241 = load i64, ptr %slot35, align 8
  %v242 = load i64, ptr %slot21, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i64 %v241, ptr %p243, align 8, !alias.scope !3, !noalias !4
  %v244 = load i64, ptr %slot20, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot37, align 8
  %v247 = load i64, ptr %slot21, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot38, align 8
  %v250 = load i64, ptr %slot1, align 8
  %v251 = load i64, ptr %slot37, align 8
  %v252 = load i64, ptr %slot38, align 8
  %call253 = call { i64, i64 } @myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d(i64 %v250, i64 %v251, i64 %v252) nomerge, !dbg !116
  store { i64, i64 } %call253, ptr %callresult40, align 8
  %addr254 = ptrtoint ptr %callresult40 to i64
  store i64 %addr254, ptr %slot39, align 8
  %v255 = load i64, ptr %slot39, align 8
  %v256 = load i64, ptr %slot20, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 %v255, ptr %p257, align 8, !alias.scope !3, !noalias !4
  %v258 = load i64, ptr %slot20, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot41, align 8
  %v261 = load i64, ptr %slot41, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i32, ptr %p262, align 4
  %ext264 = zext i32 %ld263 to i64
  store i64 %ext264, ptr %slot42, align 8
  %v265 = load i64, ptr %slot42, align 8
  %cmp266 = icmp eq i64 %v265, 0
  %cv267 = zext i1 %cmp266 to i64
  store i64 %cv267, ptr %slot43, align 8
  %v268 = load i64, ptr %slot43, align 8
  %cond269 = icmp ne i64 %v268, 0
  br i1 %cond269, label %bb_rcarm38, label %bb_rcarmnext38
bb_rcarm38:
  br label %bb_i36
bb_rcarmnext38:
  %v270 = load i64, ptr %slot42, align 8
  %cmp271 = icmp eq i64 %v270, 1
  %cv272 = zext i1 %cmp271 to i64
  store i64 %cv272, ptr %slot44, align 8
  %v273 = load i64, ptr %slot44, align 8
  %cond274 = icmp ne i64 %v273, 0
  br i1 %cond274, label %bb_rcarm39, label %bb_rcarmnext39
bb_rcarm39:
  %v275 = load i64, ptr %slot12, align 8
  store i64 %v275, ptr %slot45, align 8
  %v276 = load i64, ptr %slot41, align 8
  %op277 = add i64 %v276, 8
  store i64 %op277, ptr %slot46, align 8
  %v278 = load i64, ptr %slot30, align 8
  store i64 %v278, ptr %slot47, align 8
  %v279 = load i64, ptr %slot46, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8
  store i64 %ld281, ptr %slot48, align 8
  %v282 = load i64, ptr %slot48, align 8
  %v283 = load i64, ptr %slot45, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot9, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i32 0, ptr %p286, align 4, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot8, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i32 1, ptr %p288, align 4, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot45, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot49, align 8
  %v292 = load i64, ptr %slot49, align 8
  %v293 = load i64, ptr %slot16, align 8
  %p294 = inttoptr i64 %v293 to ptr
  store i64 %v292, ptr %p294, align 8, !alias.scope !3, !noalias !4
  %v295 = load i64, ptr %slot8, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i32 0, ptr %p296, align 4, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_rcarmnext39:
  br label %bb_failure
bb_i6:
  %v297 = load i64, ptr %slot15, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot50, align 8
  %v300 = load i64, ptr %slot50, align 8
  %v301 = load i64, ptr %slot20, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot20, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot51, align 8
  %v306 = load i64, ptr %slot1, align 8
  %v307 = load i64, ptr %slot51, align 8
  %call308 = call i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64 %v306, i64 %v307) nomerge, !dbg !118
  store i64 %call308, ptr %slot52, align 8
  %v309 = load i64, ptr %slot52, align 8
  %v310 = load i64, ptr %slot20, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i64 %v309, ptr %p311, align 8, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot20, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot53, align 8
  %v315 = load i64, ptr %slot53, align 8
  %v316 = load i64, ptr %slot17, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 %v315, ptr %p317, align 8, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot13, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld320, ptr %slot54, align 8
  %v321 = load i64, ptr %slot54, align 8
  %v322 = load i64, ptr %slot20, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i64 %v321, ptr %p323, align 8, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot17, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %ld326 = load i64, ptr %p325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld326, ptr %slot55, align 8
  %v327 = load i64, ptr %slot55, align 8
  %v328 = load i64, ptr %slot21, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i64 %v327, ptr %p329, align 8, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot20, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld332, ptr %slot56, align 8
  %v333 = load i64, ptr %slot21, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %ld335 = load i64, ptr %p334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld335, ptr %slot57, align 8
  %v336 = load i64, ptr %slot1, align 8
  %v337 = load i64, ptr %slot56, align 8
  %v338 = load i64, ptr %slot57, align 8
  %call339 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v336, i64 %v337, i64 %v338) nomerge, !dbg !120
  store i64 %call339, ptr %slot58, align 8
  %v340 = load i64, ptr %slot58, align 8
  %v341 = load i64, ptr %slot20, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 %v340, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot20, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %ld345 = load i64, ptr %p344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld345, ptr %slot59, align 8
  %v346 = load i64, ptr %slot59, align 8
  %v347 = load i64, ptr %slot18, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot13, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i64, ptr %p350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld351, ptr %slot60, align 8
  %v352 = load i64, ptr %slot60, align 8
  %v353 = load i64, ptr %slot20, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 %v352, ptr %p354, align 8, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot21, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i64 0, ptr %p356, align 8, !alias.scope !3, !noalias !4
  %v357 = load i64, ptr %slot20, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot61, align 8
  %v360 = load i64, ptr %slot21, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld362, ptr %slot62, align 8
  %v363 = load i64, ptr %slot1, align 8
  %v364 = load i64, ptr %slot61, align 8
  %v365 = load i64, ptr %slot62, align 8
  %call366 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v363, i64 %v364, i64 %v365) nomerge, !dbg !122
  store { i64, i64 } %call366, ptr %callresult64, align 8
  %addr367 = ptrtoint ptr %callresult64 to i64
  store i64 %addr367, ptr %slot63, align 8
  %v368 = load i64, ptr %slot63, align 8
  %v369 = load i64, ptr %slot20, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot20, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot65, align 8
  %v374 = load i64, ptr %slot65, align 8
  %v375 = load i64, ptr %slot19, align 8
  %p376 = inttoptr i64 %v374 to ptr
  %p377 = inttoptr i64 %v375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p377, ptr %p376, i64 16, i1 false)
  %v378 = load i64, ptr %slot13, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot66, align 8
  %v381 = load i64, ptr %slot66, align 8
  %v382 = load i64, ptr %slot20, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 %v381, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot16, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot67, align 8
  %v387 = load i64, ptr %slot67, align 8
  %v388 = load i64, ptr %slot21, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 %v387, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot17, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot68, align 8
  %v393 = load i64, ptr %slot68, align 8
  %v394 = load i64, ptr %slot22, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot18, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot69, align 8
  %v399 = load i64, ptr %slot69, align 8
  %v400 = load i64, ptr %slot23, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 %v399, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot19, align 8
  %v403 = load i64, ptr %slot24, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot20, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot70, align 8
  %v408 = load i64, ptr %slot21, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot71, align 8
  %v411 = load i64, ptr %slot22, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot72, align 8
  %v414 = load i64, ptr %slot23, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot73, align 8
  %v417 = load i64, ptr %slot24, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot74, align 8
  %v420 = load i64, ptr %slot1, align 8
  %v421 = load i64, ptr %slot70, align 8
  %v422 = load i64, ptr %slot71, align 8
  %v423 = load i64, ptr %slot72, align 8
  %v424 = load i64, ptr %slot73, align 8
  %v425 = load i64, ptr %slot74, align 8
  %call426 = call i64 @myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f(i64 %v420, i64 %v421, i64 %v422, i64 %v423, i64 %v424, i64 %v425) nomerge, !dbg !124
  store i64 %call426, ptr %slot75, align 8
  %v427 = load i64, ptr %slot75, align 8
  %v428 = load i64, ptr %slot20, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot13, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot76, align 8
  %v433 = load i64, ptr %slot76, align 8
  %v434 = load i64, ptr %slot20, align 8
  %p435 = inttoptr i64 %v434 to ptr
  store i64 %v433, ptr %p435, align 8, !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot20, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i64, ptr %p437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld438, ptr %slot77, align 8
  %v439 = load i64, ptr %slot1, align 8
  %v440 = load i64, ptr %slot77, align 8
  %call441 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v439, i64 %v440) nomerge, !dbg !126
  store { i64, i64 } %call441, ptr %callresult79, align 8
  %addr442 = ptrtoint ptr %callresult79 to i64
  store i64 %addr442, ptr %slot78, align 8
  %v443 = load i64, ptr %slot78, align 8
  %v444 = load i64, ptr %slot20, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 %v443, ptr %p445, align 8, !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot13, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot80, align 8
  %v449 = load i64, ptr %slot80, align 8
  %v450 = load i64, ptr %slot20, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot20, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot81, align 8
  %v455 = load i64, ptr %slot1, align 8
  %v456 = load i64, ptr %slot81, align 8
  %call457 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v455, i64 %v456) nomerge, !dbg !128
  store { i64, i64 } %call457, ptr %callresult83, align 8
  %addr458 = ptrtoint ptr %callresult83 to i64
  store i64 %addr458, ptr %slot82, align 8
  %v459 = load i64, ptr %slot82, align 8
  %v460 = load i64, ptr %slot20, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 %v459, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot13, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot84, align 8
  %v465 = load i64, ptr %slot84, align 8
  %v466 = load i64, ptr %slot20, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i64 %v465, ptr %p467, align 8, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot19, align 8
  %v469 = load i64, ptr %slot21, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i64 %v468, ptr %p470, align 8, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot20, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot85, align 8
  %v474 = load i64, ptr %slot21, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot86, align 8
  %v477 = load i64, ptr %slot1, align 8
  %v478 = load i64, ptr %slot85, align 8
  %v479 = load i64, ptr %slot86, align 8
  %call480 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v477, i64 %v478, i64 %v479) nomerge, !dbg !130
  store i64 %call480, ptr %slot87, align 8
  %v481 = load i64, ptr %slot87, align 8
  %v482 = load i64, ptr %slot20, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i64 %v481, ptr %p483, align 8, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot20, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 1, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot20, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i64, ptr %p487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld488, ptr %slot88, align 8
  %v489 = load i64, ptr %slot88, align 8
  ret i64 %v489
bb_i36:
  %v490 = load i64, ptr %slot13, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i64, ptr %p491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld492, ptr %slot89, align 8
  %v493 = load i64, ptr %slot89, align 8
  %v494 = load i64, ptr %slot20, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i64 %v493, ptr %p495, align 8, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot14, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %ld498 = load i64, ptr %p497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld498, ptr %slot90, align 8
  %v499 = load i64, ptr %slot90, align 8
  %v500 = load i64, ptr %slot21, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i64 %v499, ptr %p501, align 8, !alias.scope !3, !noalias !4
  %p502 = inttoptr i64 ptrtoint (ptr @myl_lit_ae34ea25ba6543390a4fad13083ff6a513fffab9c9bddab170c1a5122079ec98 to i64) to ptr
  %ld503 = load i64, ptr %p502, align 8, !alias.scope !4, !noalias !3
  store i64 %ld503, ptr %slot91, align 8
  %v504 = load i64, ptr %slot91, align 8
  %v505 = load i64, ptr %slot22, align 8
  %p506 = inttoptr i64 %v505 to ptr
  store i64 %v504, ptr %p506, align 8, !alias.scope !3, !noalias !4
  %v507 = load i64, ptr %slot22, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %ld509 = load i64, ptr %p508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld509, ptr %slot92, align 8
  %v510 = load i64, ptr %slot92, align 8
  %v511 = load i64, ptr %slot11, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i64 %v510, ptr %p512, align 8, !alias.scope !3, !noalias !4
  %v513 = load i64, ptr %slot11, align 8
  store i64 %v513, ptr %slot93, align 8
  %v514 = load i64, ptr %slot12, align 8
  store i64 %v514, ptr %slot94, align 8
  %v515 = load i64, ptr %slot93, align 8
  %v516 = load i64, ptr %slot94, align 8
  %p517 = inttoptr i64 %v515 to ptr
  %p518 = inttoptr i64 %v516 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p518, ptr %p517, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot9, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i32 2, ptr %p520, align 4, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot8, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 1, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot10, align 8
  store i64 %v523, ptr %slot95, align 8
  %v524 = load i64, ptr %slot12, align 8
  store i64 %v524, ptr %slot96, align 8
  %v525 = load i64, ptr %slot96, align 8
  %v526 = load i64, ptr %slot95, align 8
  %p527 = inttoptr i64 %v525 to ptr
  %p528 = inttoptr i64 %v526 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p528, ptr %p527, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot7, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i32 2, ptr %p530, align 4, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot9, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i32, ptr %p532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld533, ptr %slot97, align 8
  %v534 = load i32, ptr %slot97, align 8
  %v535 = load i64, ptr %slot7, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i32 %v534, ptr %p536, align 4, !alias.scope !3, !noalias !4
  %v537 = load i64, ptr %slot8, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i32 0, ptr %p538, align 4, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot6, align 8
  %p540 = inttoptr i64 %v539 to ptr
  store i32 1, ptr %p540, align 4, !alias.scope !3, !noalias !4
  %v541 = load i64, ptr %slot95, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot98, align 8
  %v544 = load i64, ptr %slot98, align 8
  %v545 = load i64, ptr %slot22, align 8
  %p546 = inttoptr i64 %v545 to ptr
  store i64 %v544, ptr %p546, align 8, !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot20, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld549, ptr %slot99, align 8
  %v550 = load i64, ptr %slot21, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot100, align 8
  %v553 = load i64, ptr %slot22, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot101, align 8
  %v556 = load i64, ptr %slot1, align 8
  %v557 = load i64, ptr %slot99, align 8
  %v558 = load i64, ptr %slot100, align 8
  %v559 = load i64, ptr %slot101, align 8
  %call560 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v556, i64 %v557, i64 %v558, i64 %v559) nomerge, !dbg !132
  store i64 %call560, ptr %slot102, align 8
  %v561 = load i64, ptr %slot102, align 8
  %v562 = load i64, ptr %slot20, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot6, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i32, ptr %p565, align 4, !alias.scope !3, !noalias !4
  store i32 %ld566, ptr %slot103, align 8
  %v567 = load i32, ptr %slot103, align 8
  %cv568 = zext i32 %v567 to i64
  %cond569 = icmp ne i64 %cv568, 0
  br i1 %cond569, label %bb_rcslotdrop219, label %bb_rcslotdone219
bb_rcslotdrop219:
  %v570 = load i64, ptr %slot6, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i32 0, ptr %p571, align 4, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot10, align 8
  store i64 %v572, ptr %slot104, align 8
  %v573 = load i64, ptr %slot7, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i32, ptr %p574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld575, ptr %slot105, align 8
  %v576 = load i32, ptr %slot105, align 8
  %op577 = and i32 %v576, 28
  store i32 %op577, ptr %slot106, align 8
  %v578 = load i32, ptr %slot106, align 8
  %cv579 = zext i32 %v578 to i64
  %cond580 = icmp ne i64 %cv579, 0
  br i1 %cond580, label %bb_rcslotrole219, label %bb_rcslotowner219
bb_rcslotrole219:
  %v581 = load i64, ptr %slot29, align 8
  store i64 %v581, ptr %slot107, align 8
  %v582 = load i64, ptr %slot104, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld584, ptr %slot108, align 8
  %v585 = load i64, ptr %slot108, align 8
  %cmp586 = icmp ne i64 %v585, 0
  %cv587 = zext i1 %cmp586 to i32
  store i32 %cv587, ptr %slot109, align 8
  %v588 = load i32, ptr %slot109, align 8
  %cv589 = zext i32 %v588 to i64
  %cond590 = icmp ne i64 %cv589, 0
  br i1 %cond590, label %bb_rcgnn235, label %bb_rcgdone235
bb_rcgnn235:
  %v591 = load i64, ptr %slot108, align 8
  %op592 = sub i64 %v591, 16
  store i64 %op592, ptr %slot110, align 8
  %v593 = load i64, ptr %slot108, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %rgep595 = getelementptr i8, ptr %p594, i64 -16
  %ld596 = load i64, ptr %rgep595, align 8, !alias.scope !9, !noalias !10
  store i64 %ld596, ptr %slot111, align 8
  %v597 = load i64, ptr %slot111, align 8
  %op598 = and i64 %v597, 4611686018427387906
  store i64 %op598, ptr %slot112, align 8
  %v599 = load i64, ptr %slot112, align 8
  %cmp600 = icmp ne i64 %v599, 0
  %cv601 = zext i1 %cmp600 to i32
  store i32 %cv601, ptr %slot113, align 8
  %v602 = load i32, ptr %slot113, align 8
  %cv603 = zext i32 %v602 to i64
  %cond604 = icmp ne i64 %cv603, 0
  br i1 %cond604, label %bb_rcgclear235, label %bb_rcgcounted235
bb_rcgcounted235:
  %v605 = load i64, ptr %slot108, align 8
  %op606 = sub i64 %v605, 24
  store i64 %op606, ptr %slot114, align 8
  %v607 = load i64, ptr %slot108, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %rgep609 = getelementptr i8, ptr %p608, i64 -24
  %ld610 = load i64, ptr %rgep609, align 8, !alias.scope !9, !noalias !10
  store i64 %ld610, ptr %slot115, align 8
  %v611 = load i64, ptr %slot115, align 8
  %op612 = sub i64 %v611, 1
  store i64 %op612, ptr %slot116, align 8
  %v613 = load i64, ptr %slot116, align 8
  %cmp614 = icmp eq i64 %v613, 0
  %cv615 = zext i1 %cmp614 to i32
  store i32 %cv615, ptr %slot117, align 8
  %v616 = load i32, ptr %slot117, align 8
  %cv617 = zext i32 %v616 to i64
  %cond618 = icmp ne i64 %cv617, 0
  br i1 %cond618, label %bb_rcglast235, label %bb_rcgdec235
bb_rcglast235:
  %v619 = load i64, ptr %slot108, align 8
  %op620 = sub i64 %v619, 32
  store i64 %op620, ptr %slot118, align 8
  %v621 = load i64, ptr %slot108, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %rgep623 = getelementptr i8, ptr %p622, i64 -32
  %ld624 = load i64, ptr %rgep623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld624, ptr %slot119, align 8
  %v625 = load i64, ptr %slot119, align 8
  %cmp626 = icmp ne i64 %v625, 0
  %cv627 = zext i1 %cmp626 to i32
  store i32 %cv627, ptr %slot120, align 8
  %v628 = load i32, ptr %slot120, align 8
  %cv629 = zext i32 %v628 to i64
  %cond630 = icmp ne i64 %cv629, 0
  br i1 %cond630, label %bb_rcgdec235, label %bb_rcgslow235
bb_rcgslow235:
  %v631 = load i64, ptr %slot107, align 8
  %v632 = load i64, ptr %slot104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v631, i64 %v632) nomerge, !dbg !132
  br label %bb_rcgdone235
bb_rcgdec235:
  %v633 = load i64, ptr %slot116, align 8
  %v634 = load i64, ptr %slot108, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %rgep636 = getelementptr i8, ptr %p635, i64 -24
  store i64 %v633, ptr %rgep636, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear235
bb_rcgclear235:
  %v637 = load i64, ptr %slot104, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i64 0, ptr %p638, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone235
bb_rcgdone235:
  br label %bb_rcslotdone219
bb_rcslotowner219:
  %v639 = load i64, ptr %slot29, align 8
  store i64 %v639, ptr %slot121, align 8
  %v640 = load i64, ptr %slot104, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot122, align 8
  %v643 = load i64, ptr %slot122, align 8
  %cmp644 = icmp ne i64 %v643, 0
  %cv645 = zext i1 %cmp644 to i32
  store i32 %cv645, ptr %slot123, align 8
  %v646 = load i32, ptr %slot123, align 8
  %cv647 = zext i32 %v646 to i64
  %cond648 = icmp ne i64 %cv647, 0
  br i1 %cond648, label %bb_rcgnn250, label %bb_rcgdone250
bb_rcgnn250:
  %v649 = load i64, ptr %slot122, align 8
  %op650 = sub i64 %v649, 16
  store i64 %op650, ptr %slot124, align 8
  %v651 = load i64, ptr %slot122, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %rgep653 = getelementptr i8, ptr %p652, i64 -16
  %ld654 = load i64, ptr %rgep653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld654, ptr %slot125, align 8
  %v655 = load i64, ptr %slot125, align 8
  %op656 = and i64 %v655, 4611686018427387906
  store i64 %op656, ptr %slot126, align 8
  %v657 = load i64, ptr %slot126, align 8
  %cmp658 = icmp ne i64 %v657, 0
  %cv659 = zext i1 %cmp658 to i32
  store i32 %cv659, ptr %slot127, align 8
  %v660 = load i32, ptr %slot127, align 8
  %cv661 = zext i32 %v660 to i64
  %cond662 = icmp ne i64 %cv661, 0
  br i1 %cond662, label %bb_rcgclear250, label %bb_rcgcounted250
bb_rcgcounted250:
  %v663 = load i64, ptr %slot122, align 8
  %op664 = sub i64 %v663, 32
  store i64 %op664, ptr %slot128, align 8
  %v665 = load i64, ptr %slot122, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %rgep667 = getelementptr i8, ptr %p666, i64 -32
  %ld668 = load i64, ptr %rgep667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld668, ptr %slot129, align 8
  %v669 = load i64, ptr %slot129, align 8
  %op670 = sub i64 %v669, 1
  store i64 %op670, ptr %slot130, align 8
  %v671 = load i64, ptr %slot130, align 8
  %cmp672 = icmp eq i64 %v671, 0
  %cv673 = zext i1 %cmp672 to i32
  store i32 %cv673, ptr %slot131, align 8
  %v674 = load i32, ptr %slot131, align 8
  %cv675 = zext i32 %v674 to i64
  %cond676 = icmp ne i64 %cv675, 0
  br i1 %cond676, label %bb_rcglast250, label %bb_rcgdec250
bb_rcglast250:
  %v677 = load i64, ptr %slot122, align 8
  %op678 = sub i64 %v677, 24
  store i64 %op678, ptr %slot132, align 8
  %v679 = load i64, ptr %slot122, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %rgep681 = getelementptr i8, ptr %p680, i64 -24
  %ld682 = load i64, ptr %rgep681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld682, ptr %slot133, align 8
  %v683 = load i64, ptr %slot133, align 8
  %cmp684 = icmp ne i64 %v683, 0
  %cv685 = zext i1 %cmp684 to i32
  store i32 %cv685, ptr %slot134, align 8
  %v686 = load i32, ptr %slot134, align 8
  %cv687 = zext i32 %v686 to i64
  %cond688 = icmp ne i64 %cv687, 0
  br i1 %cond688, label %bb_rcgdec250, label %bb_rcgslow250
bb_rcgslow250:
  %v689 = load i64, ptr %slot121, align 8
  %v690 = load i64, ptr %slot104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v689, i64 %v690) nomerge, !dbg !132
  br label %bb_rcgdone250
bb_rcgdec250:
  %v691 = load i64, ptr %slot130, align 8
  %v692 = load i64, ptr %slot122, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %rgep694 = getelementptr i8, ptr %p693, i64 -32
  store i64 %v691, ptr %rgep694, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear250
bb_rcgclear250:
  %v695 = load i64, ptr %slot104, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 0, ptr %p696, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone250
bb_rcgdone250:
  br label %bb_rcslotdone219
bb_rcslotdone219:
  %v697 = load i64, ptr %slot20, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot135, align 8
  %v700 = load i64, ptr %slot135, align 8
  ret i64 %v700
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_ae34ea25ba6543390a4fad13083ff6a513fffab9c9bddab170c1a5122079ec98 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1c0bd1b7bb117cc78f49bded6cea445b0f0085cd72c106cf259efd77a43b555f(i64, i64, i64, i64, i64, i64)
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare { i64, i64 } @myl_f_690c75f45428516b3ec0bdb8ee8a81e39a36557931bad6d619ef1296aa9a4a4d(i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare i64 @myl_f_94484f74f9fdfe749fe3bbd5703ff3b6b2a0ee43d3569a1125fbe02c5095250d(i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_region_mark(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9a0199d95ad9eff3ff1c9349ca8998b70fffda59996a1ab49599b93a90d66e10", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9a0199d95ad9eff3ff1c9349ca8998b70fffda59996a1ab49599b93a90d66e10", linkageName: "myl_f_9a0199d95ad9eff3ff1c9349ca8998b70fffda59996a1ab49599b93a90d66e10", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15691660879820164095, i64 0, !"myl_f_9a0199d95ad9eff3ff1c9349ca8998b70fffda59996a1ab49599b93a90d66e10"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!122 = !DILocation(line: 16, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!124 = !DILocation(line: 23, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!126 = !DILocation(line: 26, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!128 = !DILocation(line: 29, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!130 = !DILocation(line: 33, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!132 = !DILocation(line: 40, column: 0, scope: !133)
