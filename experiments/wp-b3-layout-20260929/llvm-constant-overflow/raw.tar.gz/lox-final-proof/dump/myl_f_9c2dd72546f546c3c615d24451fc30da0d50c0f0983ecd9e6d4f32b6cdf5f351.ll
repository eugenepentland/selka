target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %callresult202 = alloca [56 x i8], align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %callresult234 = alloca [56 x i8], align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %callresult266 = alloca [56 x i8], align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %callresult298 = alloca [56 x i8], align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %callresult330 = alloca [56 x i8], align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %callresult362 = alloca [56 x i8], align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %callresult394 = alloca [56 x i8], align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %callresult426 = alloca [56 x i8], align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %callresult458 = alloca [56 x i8], align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %callresult490 = alloca [56 x i8], align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %callresult522 = alloca [56 x i8], align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v548 = load i64, ptr %slot1, align 8
  %op549 = add i64 %v548, 32
  store i64 %op549, ptr %slot4, align 8
  %mem550 = alloca i8, i64 56, align 8
  %ptr551 = ptrtoint ptr %mem550 to i64
  store i64 %ptr551, ptr %slot5, align 8
  %mem552 = alloca i8, i64 8, align 8
  %ptr553 = ptrtoint ptr %mem552 to i64
  store i64 %ptr553, ptr %slot6, align 8
  %mem554 = alloca i8, i64 8, align 8
  %ptr555 = ptrtoint ptr %mem554 to i64
  store i64 %ptr555, ptr %slot7, align 8
  %mem556 = alloca i8, i64 8, align 8
  %ptr557 = ptrtoint ptr %mem556 to i64
  store i64 %ptr557, ptr %slot8, align 8
  %mem558 = alloca i8, i64 8, align 8
  %ptr559 = ptrtoint ptr %mem558 to i64
  store i64 %ptr559, ptr %slot9, align 8
  %mem560 = alloca i8, i64 304, align 8
  %ptr561 = ptrtoint ptr %mem560 to i64
  store i64 %ptr561, ptr %slot10, align 8
  %mem562 = alloca i8, i64 304, align 8
  %ptr563 = ptrtoint ptr %mem562 to i64
  store i64 %ptr563, ptr %slot11, align 8
  %mem564 = alloca i8, i64 8, align 8
  %ptr565 = ptrtoint ptr %mem564 to i64
  store i64 %ptr565, ptr %slot12, align 8
  %mem566 = alloca i8, i64 8, align 8
  %ptr567 = ptrtoint ptr %mem566 to i64
  store i64 %ptr567, ptr %slot13, align 8
  %mem568 = alloca i8, i64 8, align 8
  %ptr569 = ptrtoint ptr %mem568 to i64
  store i64 %ptr569, ptr %slot14, align 8
  %mem570 = alloca i8, i64 8, align 8
  %ptr571 = ptrtoint ptr %mem570 to i64
  store i64 %ptr571, ptr %slot15, align 8
  %mem572 = alloca i8, i64 56, align 8
  %ptr573 = ptrtoint ptr %mem572 to i64
  store i64 %ptr573, ptr %slot16, align 8
  %mem574 = alloca i8, i64 8, align 8
  %ptr575 = ptrtoint ptr %mem574 to i64
  store i64 %ptr575, ptr %slot17, align 8
  %mem576 = alloca i8, i64 8, align 8
  %ptr577 = ptrtoint ptr %mem576 to i64
  store i64 %ptr577, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem578 = alloca i8, i64 8, align 8
  %ptr579 = ptrtoint ptr %mem578 to i64
  store i64 %ptr579, ptr %slot19, align 8
  %v580 = load i64, ptr %slot1, align 8
  %op581 = add i64 %v580, 64
  store i64 %op581, ptr %slot20, align 8
  %v582 = load i64, ptr %slot20, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !4, !noalias !3
  store i64 %ld584, ptr %slot21, align 8
  %stack585 = call ptr @llvm.stacksave()
  %stackaddr586 = ptrtoint ptr %stack585 to i64
  %v587 = load i64, ptr %slot21, align 8
  %cmp588 = icmp ult i64 %stackaddr586, %v587
  %cv589 = zext i1 %cmp588 to i64
  store i64 %cv589, ptr %slot22, align 8
  %v590 = load i64, ptr %slot22, align 8
  %cond591 = icmp ne i64 %v590, 0
  br i1 %cond591, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v592 = load i64, ptr %slot1, align 8
  %p593 = inttoptr i64 %v592 to ptr
  call void @myl_qbe_fail_frame(ptr %p593) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v594 = load i64, ptr %slot14, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i64 0, ptr %p595, align 8, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot2, align 8
  %v597 = load i64, ptr %slot12, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i64 %v596, ptr %p598, align 8, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot3, align 8
  %v600 = load i64, ptr %slot13, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 %v599, ptr %p601, align 8, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot1, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %call604 = call ptr @myl_qbe_heap(ptr %p603) nomerge, !dbg !112
  %calladdr605 = ptrtoint ptr %call604 to i64
  store i64 %calladdr605, ptr %slot23, align 8
  %v606 = load i64, ptr %slot1, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %call608 = call i64 @myl_qbe_region_mark(ptr %p607) nomerge, !dbg !112
  store i64 %call608, ptr %slot24, align 8
  %v609 = load i64, ptr %slot6, align 8
  %p610 = inttoptr i64 %v609 to ptr
  store i32 0, ptr %p610, align 4, !alias.scope !3, !noalias !4
  %v611 = load i64, ptr %slot7, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i32 0, ptr %p612, align 4, !alias.scope !3, !noalias !4
  %v613 = load i64, ptr %slot8, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i32 0, ptr %p614, align 4, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot9, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i32 0, ptr %p616, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v617 = load i64, ptr %slot12, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %ld619 = load i64, ptr %p618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld619, ptr %slot25, align 8
  %v620 = load i64, ptr %slot25, align 8
  %v621 = load i64, ptr %slot17, align 8
  %p622 = inttoptr i64 %v621 to ptr
  store i64 %v620, ptr %p622, align 8, !alias.scope !3, !noalias !4
  %v623 = load i64, ptr %slot17, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i64, ptr %p624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld625, ptr %slot26, align 8
  %v626 = load i64, ptr %slot26, align 8
  %op627 = add i64 %v626, 0
  store i64 %op627, ptr %slot27, align 8
  %v628 = load i64, ptr %slot27, align 8
  %v629 = load i64, ptr %slot17, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i64 %v628, ptr %p630, align 8, !alias.scope !3, !noalias !4
  %v631 = load i64, ptr %slot6, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i32, ptr %p632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld633, ptr %slot28, align 8
  %v634 = load i32, ptr %slot28, align 8
  %cv635 = zext i32 %v634 to i64
  %cond636 = icmp ne i64 %cv635, 0
  br i1 %cond636, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v637 = load i64, ptr %slot6, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i32 0, ptr %p638, align 4, !alias.scope !3, !noalias !4
  %v639 = load i64, ptr %slot10, align 8
  store i64 %v639, ptr %slot29, align 8
  %v640 = load i64, ptr %slot7, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i32, ptr %p641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld642, ptr %slot30, align 8
  %v643 = load i32, ptr %slot30, align 8
  %op644 = and i32 %v643, 28
  store i32 %op644, ptr %slot31, align 8
  %v645 = load i32, ptr %slot31, align 8
  %cv646 = zext i32 %v645 to i64
  %cond647 = icmp ne i64 %cv646, 0
  br i1 %cond647, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v648 = load i64, ptr %slot23, align 8
  store i64 %v648, ptr %slot32, align 8
  %v649 = load i64, ptr %slot32, align 8
  %v650 = load i64, ptr %slot29, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v649, i64 %v650) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v651 = load i64, ptr %slot23, align 8
  store i64 %v651, ptr %slot33, align 8
  %v652 = load i64, ptr %slot33, align 8
  %v653 = load i64, ptr %slot29, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v652, i64 %v653) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v654 = load i64, ptr %slot17, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i64, ptr %p655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld656, ptr %slot34, align 8
  %v657 = load i64, ptr %slot34, align 8
  %op658 = add i64 %v657, 0
  store i64 %op658, ptr %slot35, align 8
  %v659 = load i64, ptr %slot35, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %ld661 = load i64, ptr %p660, align 8, !alias.scope !4, !noalias !3
  store i64 %ld661, ptr %slot36, align 8
  %v662 = load i64, ptr %slot36, align 8
  %v663 = load i64, ptr %slot17, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i64 %v662, ptr %p664, align 8, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot6, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %ld667 = load i32, ptr %p666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld667, ptr %slot37, align 8
  %v668 = load i32, ptr %slot37, align 8
  %cv669 = zext i32 %v668 to i64
  %cond670 = icmp ne i64 %cv669, 0
  br i1 %cond670, label %bb_rcslotdrop27, label %bb_rcslotdone27
bb_rcslotdrop27:
  %v671 = load i64, ptr %slot6, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 0, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot10, align 8
  store i64 %v673, ptr %slot38, align 8
  %v674 = load i64, ptr %slot7, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %ld676 = load i32, ptr %p675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld676, ptr %slot39, align 8
  %v677 = load i32, ptr %slot39, align 8
  %op678 = and i32 %v677, 28
  store i32 %op678, ptr %slot40, align 8
  %v679 = load i32, ptr %slot40, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcslotrole27, label %bb_rcslotowner27
bb_rcslotrole27:
  %v682 = load i64, ptr %slot23, align 8
  store i64 %v682, ptr %slot41, align 8
  %v683 = load i64, ptr %slot41, align 8
  %v684 = load i64, ptr %slot38, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v683, i64 %v684) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotowner27:
  %v685 = load i64, ptr %slot23, align 8
  store i64 %v685, ptr %slot42, align 8
  %v686 = load i64, ptr %slot42, align 8
  %v687 = load i64, ptr %slot38, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v686, i64 %v687) nomerge, !dbg !116
  br label %bb_rcslotdone27
bb_rcslotdone27:
  %v688 = load i64, ptr %slot17, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot43, align 8
  %v691 = load i64, ptr %slot43, align 8
  %v692 = load i64, ptr %slot14, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 %v691, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot13, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot44, align 8
  %v697 = load i64, ptr %slot44, align 8
  %v698 = load i64, ptr %slot17, align 8
  %p699 = inttoptr i64 %v698 to ptr
  store i64 %v697, ptr %p699, align 8, !alias.scope !3, !noalias !4
  %v700 = load i64, ptr %slot17, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot45, align 8
  %v703 = load i64, ptr %slot45, align 8
  %v704 = load i64, ptr %slot15, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot15, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i64, ptr %p707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld708, ptr %slot46, align 8
  %v709 = load i64, ptr %slot46, align 8
  %v710 = load i64, ptr %slot17, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot18, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 0, ptr %p713, align 8, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot18, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i64, ptr %p715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld716, ptr %slot47, align 8
  %v717 = load i64, ptr %slot17, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot48, align 8
  %v720 = load i64, ptr %slot48, align 8
  %v721 = load i64, ptr %slot47, align 8
  %cmp722 = icmp slt i64 %v720, %v721
  %cv723 = zext i1 %cmp722 to i64
  store i64 %cv723, ptr %slot49, align 8
  %v724 = load i64, ptr %slot49, align 8
  %v725 = load i64, ptr %slot17, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i64 %v724, ptr %p726, align 8, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot17, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot50, align 8
  %v730 = load i64, ptr %slot50, align 8
  %cond731 = icmp ne i64 %v730, 0
  br i1 %cond731, label %bb_next42, label %bb_i15
bb_next42:
  %v732 = load i64, ptr %slot14, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot51, align 8
  %v735 = load i64, ptr %slot51, align 8
  %op736 = add i64 %v735, 0
  store i64 %op736, ptr %slot52, align 8
  %v737 = load i64, ptr %slot52, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %ld739 = load i64, ptr %p738, align 8, !alias.scope !6, !noalias !7
  store i64 %ld739, ptr %slot53, align 8
  %v740 = load i64, ptr %slot53, align 8
  %v741 = load i64, ptr %slot17, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i64 %v740, ptr %p742, align 8, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot17, align 8
  %p744 = inttoptr i64 %v743 to ptr
  %ld745 = load i64, ptr %p744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld745, ptr %slot54, align 8
  %v746 = load i64, ptr %slot54, align 8
  %cmp747 = icmp ugt i64 %v746, 9223372036854775807
  %cv748 = zext i1 %cmp747 to i64
  store i64 %cv748, ptr %slot55, align 8
  %v749 = load i64, ptr %slot55, align 8
  %cond750 = icmp ne i64 %v749, 0
  br i1 %cond750, label %bb_cast_overflow47, label %bb_cast_ok47
bb_cast_overflow47:
  %v751 = load i64, ptr %slot1, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %v753 = load i64, ptr %slot54, align 8
  call void @myl_qbe_fail_cast(ptr %p752, i64 %v753, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok47:
  %v754 = load i64, ptr %slot54, align 8
  %v755 = load i64, ptr %slot17, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i64 %v754, ptr %p756, align 8, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot15, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %ld759 = load i64, ptr %p758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld759, ptr %slot56, align 8
  %v760 = load i64, ptr %slot56, align 8
  %v761 = load i64, ptr %slot18, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i64 %v760, ptr %p762, align 8, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot18, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld765, ptr %slot57, align 8
  %v766 = load i64, ptr %slot17, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %ld768 = load i64, ptr %p767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld768, ptr %slot58, align 8
  %v769 = load i64, ptr %slot58, align 8
  %v770 = load i64, ptr %slot57, align 8
  %ovpair772 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v769, i64 %v770)
  %op771 = extractvalue { i64, i1 } %ovpair772, 0
  %ov773 = extractvalue { i64, i1 } %ovpair772, 1
  store i64 %op771, ptr %slot59, align 8
  %v774 = load i64, ptr %slot58, align 8
  %v775 = load i64, ptr %slot59, align 8
  %op776 = xor i64 %v774, %v775
  store i64 %op776, ptr %slot60, align 8
  %v777 = load i64, ptr %slot57, align 8
  %v778 = load i64, ptr %slot59, align 8
  %op779 = xor i64 %v777, %v778
  store i64 %op779, ptr %slot61, align 8
  %v780 = load i64, ptr %slot60, align 8
  %v781 = load i64, ptr %slot61, align 8
  %op782 = and i64 %v780, %v781
  store i64 %op782, ptr %slot62, align 8
  %cv783 = zext i1 %ov773 to i64
  store i64 %cv783, ptr %slot63, align 8
  %v784 = load i64, ptr %slot63, align 8
  %cond785 = icmp ne i64 %v784, 0
  br i1 %cond785, label %bb_overflow51, label %bb_checked51
bb_overflow51:
  %v786 = load i64, ptr %slot1, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %v788 = load i64, ptr %slot58, align 8
  %v789 = load i64, ptr %slot57, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p787, i64 0, i64 %v788, i64 %v789, i64 64) nomerge, !dbg !120
  unreachable
bb_checked51:
  %v790 = load i64, ptr %slot59, align 8
  %v791 = load i64, ptr %slot17, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 %v790, ptr %p792, align 8, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot17, align 8
  %p794 = inttoptr i64 %v793 to ptr
  %ld795 = load i64, ptr %p794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld795, ptr %slot64, align 8
  %v796 = load i64, ptr %slot64, align 8
  %v797 = load i64, ptr %slot15, align 8
  %p798 = inttoptr i64 %v797 to ptr
  store i64 %v796, ptr %p798, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v799 = load i64, ptr %slot15, align 8
  %p800 = inttoptr i64 %v799 to ptr
  %ld801 = load i64, ptr %p800, align 8, !alias.scope !3, !noalias !4
  store i64 %ld801, ptr %slot65, align 8
  %v802 = load i64, ptr %slot65, align 8
  %v803 = load i64, ptr %slot17, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i64 %v802, ptr %p804, align 8, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot14, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot66, align 8
  %v808 = load i64, ptr %slot17, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot67, align 8
  %v811 = load i64, ptr %slot66, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i64, ptr %p812, align 8, !alias.scope !6, !noalias !7
  store i64 %ld813, ptr %slot68, align 8
  %v814 = load i64, ptr %slot67, align 8
  %v815 = load i64, ptr %slot68, align 8
  %cmp816 = icmp ult i64 %v814, %v815
  %cv817 = zext i1 %cmp816 to i64
  store i64 %cv817, ptr %slot69, align 8
  %v818 = load i64, ptr %slot69, align 8
  %cond819 = icmp ne i64 %v818, 0
  br i1 %cond819, label %bb_success63, label %bb_failed63
bb_failed63:
  %v820 = load i64, ptr %slot1, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %v822 = load i64, ptr %slot67, align 8
  %v823 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p821, i64 %v822, i64 %v823) nomerge, !dbg !122
  unreachable
bb_success63:
  %v824 = load i64, ptr %slot66, align 8
  %op825 = add i64 %v824, 32
  store i64 %op825, ptr %slot70, align 8
  %v826 = load i64, ptr %slot70, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !6, !noalias !7
  store i64 %ld828, ptr %slot71, align 8
  %v829 = load i64, ptr %slot67, align 8
  %op830 = mul i64 %v829, 112
  store i64 %op830, ptr %slot72, align 8
  %v831 = load i64, ptr %slot71, align 8
  %v832 = load i64, ptr %slot72, align 8
  %op833 = add i64 %v831, %v832
  store i64 %op833, ptr %slot73, align 8
  %v834 = load i64, ptr %slot73, align 8
  %v835 = load i64, ptr %slot17, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i64 %v834, ptr %p836, align 8, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot17, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld839, ptr %slot74, align 8
  %v840 = load i64, ptr %slot74, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i32, ptr %p841, align 4, !alias.scope !12, !noalias !13
  %ext843 = zext i32 %ld842 to i64
  store i64 %ext843, ptr %slot75, align 8
  %v844 = load i64, ptr %slot75, align 8
  %cmp845 = icmp eq i64 %v844, 0
  %cv846 = zext i1 %cmp845 to i64
  store i64 %cv846, ptr %slot76, align 8
  %v847 = load i64, ptr %slot76, align 8
  %cond848 = icmp ne i64 %v847, 0
  br i1 %cond848, label %bb_rcarm70, label %bb_rcarmnext70
bb_rcarm70:
  %v849 = load i64, ptr %slot6, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i32, ptr %p850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld851, ptr %slot77, align 8
  %v852 = load i32, ptr %slot77, align 8
  %cv853 = zext i32 %v852 to i64
  %cond854 = icmp ne i64 %cv853, 0
  br i1 %cond854, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v855 = load i64, ptr %slot6, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i32 0, ptr %p856, align 4, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot10, align 8
  store i64 %v857, ptr %slot78, align 8
  %v858 = load i64, ptr %slot7, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i32, ptr %p859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld860, ptr %slot79, align 8
  %v861 = load i32, ptr %slot79, align 8
  %op862 = and i32 %v861, 28
  store i32 %op862, ptr %slot80, align 8
  %v863 = load i32, ptr %slot80, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v866 = load i64, ptr %slot23, align 8
  store i64 %v866, ptr %slot81, align 8
  %v867 = load i64, ptr %slot81, align 8
  %v868 = load i64, ptr %slot78, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v867, i64 %v868) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v869 = load i64, ptr %slot23, align 8
  store i64 %v869, ptr %slot82, align 8
  %v870 = load i64, ptr %slot82, align 8
  %v871 = load i64, ptr %slot78, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v870, i64 %v871) nomerge, !dbg !124
  br label %bb_rcslotdone73
bb_rcslotdone73:
  br label %bb_i24
bb_rcarmnext70:
  %v872 = load i64, ptr %slot75, align 8
  %cmp873 = icmp eq i64 %v872, 1
  %cv874 = zext i1 %cmp873 to i64
  store i64 %cv874, ptr %slot83, align 8
  %v875 = load i64, ptr %slot83, align 8
  %cond876 = icmp ne i64 %v875, 0
  br i1 %cond876, label %bb_rcarm80, label %bb_rcarmnext80
bb_rcarm80:
  %v877 = load i64, ptr %slot6, align 8
  %p878 = inttoptr i64 %v877 to ptr
  %ld879 = load i32, ptr %p878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld879, ptr %slot84, align 8
  %v880 = load i32, ptr %slot84, align 8
  %cv881 = zext i32 %v880 to i64
  %cond882 = icmp ne i64 %cv881, 0
  br i1 %cond882, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v883 = load i64, ptr %slot6, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i32 0, ptr %p884, align 4, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot10, align 8
  store i64 %v885, ptr %slot85, align 8
  %v886 = load i64, ptr %slot7, align 8
  %p887 = inttoptr i64 %v886 to ptr
  %ld888 = load i32, ptr %p887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld888, ptr %slot86, align 8
  %v889 = load i32, ptr %slot86, align 8
  %op890 = and i32 %v889, 28
  store i32 %op890, ptr %slot87, align 8
  %v891 = load i32, ptr %slot87, align 8
  %cv892 = zext i32 %v891 to i64
  %cond893 = icmp ne i64 %cv892, 0
  br i1 %cond893, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v894 = load i64, ptr %slot23, align 8
  store i64 %v894, ptr %slot88, align 8
  %v895 = load i64, ptr %slot88, align 8
  %v896 = load i64, ptr %slot85, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v895, i64 %v896) nomerge, !dbg !124
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v897 = load i64, ptr %slot23, align 8
  store i64 %v897, ptr %slot89, align 8
  %v898 = load i64, ptr %slot89, align 8
  %v899 = load i64, ptr %slot85, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v898, i64 %v899) nomerge, !dbg !124
  br label %bb_rcslotdone83
bb_rcslotdone83:
  br label %bb_i30
bb_rcarmnext80:
  %v900 = load i64, ptr %slot75, align 8
  %cmp901 = icmp eq i64 %v900, 2
  %cv902 = zext i1 %cmp901 to i64
  store i64 %cv902, ptr %slot90, align 8
  %v903 = load i64, ptr %slot90, align 8
  %cond904 = icmp ne i64 %v903, 0
  br i1 %cond904, label %bb_rcarm90, label %bb_rcarmnext90
bb_rcarm90:
  %v905 = load i64, ptr %slot74, align 8
  %op906 = add i64 %v905, 8
  store i64 %op906, ptr %slot91, align 8
  %v907 = load i64, ptr %slot91, align 8
  %v908 = load i64, ptr %slot16, align 8
  %p909 = inttoptr i64 %v907 to ptr
  %p910 = inttoptr i64 %v908 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p910, ptr %p909, i64 56, i1 false), !alias.scope !10000000
  %v911 = load i64, ptr %slot6, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %ld913 = load i32, ptr %p912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld913, ptr %slot92, align 8
  %v914 = load i32, ptr %slot92, align 8
  %cv915 = zext i32 %v914 to i64
  %cond916 = icmp ne i64 %cv915, 0
  br i1 %cond916, label %bb_rcslotdrop104, label %bb_rcslotdone104
bb_rcslotdrop104:
  %v917 = load i64, ptr %slot6, align 8
  %p918 = inttoptr i64 %v917 to ptr
  store i32 0, ptr %p918, align 4, !alias.scope !3, !noalias !4
  %v919 = load i64, ptr %slot10, align 8
  store i64 %v919, ptr %slot93, align 8
  %v920 = load i64, ptr %slot7, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ld922 = load i32, ptr %p921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld922, ptr %slot94, align 8
  %v923 = load i32, ptr %slot94, align 8
  %op924 = and i32 %v923, 28
  store i32 %op924, ptr %slot95, align 8
  %v925 = load i32, ptr %slot95, align 8
  %cv926 = zext i32 %v925 to i64
  %cond927 = icmp ne i64 %cv926, 0
  br i1 %cond927, label %bb_rcslotrole104, label %bb_rcslotowner104
bb_rcslotrole104:
  %v928 = load i64, ptr %slot23, align 8
  store i64 %v928, ptr %slot96, align 8
  %v929 = load i64, ptr %slot96, align 8
  %v930 = load i64, ptr %slot93, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v929, i64 %v930) nomerge, !dbg !124
  br label %bb_rcslotdone104
bb_rcslotowner104:
  %v931 = load i64, ptr %slot23, align 8
  store i64 %v931, ptr %slot97, align 8
  %v932 = load i64, ptr %slot97, align 8
  %v933 = load i64, ptr %slot93, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v932, i64 %v933) nomerge, !dbg !124
  br label %bb_rcslotdone104
bb_rcslotdone104:
  br label %bb_i18
bb_rcarmnext90:
  %v934 = load i64, ptr %slot75, align 8
  %cmp935 = icmp eq i64 %v934, 3
  %cv936 = zext i1 %cmp935 to i64
  store i64 %cv936, ptr %slot98, align 8
  %v937 = load i64, ptr %slot98, align 8
  %cond938 = icmp ne i64 %v937, 0
  br i1 %cond938, label %bb_rcarm111, label %bb_rcarmnext111
bb_rcarm111:
  %v939 = load i64, ptr %slot6, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %ld941 = load i32, ptr %p940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld941, ptr %slot99, align 8
  %v942 = load i32, ptr %slot99, align 8
  %cv943 = zext i32 %v942 to i64
  %cond944 = icmp ne i64 %cv943, 0
  br i1 %cond944, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v945 = load i64, ptr %slot6, align 8
  %p946 = inttoptr i64 %v945 to ptr
  store i32 0, ptr %p946, align 4, !alias.scope !3, !noalias !4
  %v947 = load i64, ptr %slot10, align 8
  store i64 %v947, ptr %slot100, align 8
  %v948 = load i64, ptr %slot7, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i32, ptr %p949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld950, ptr %slot101, align 8
  %v951 = load i32, ptr %slot101, align 8
  %op952 = and i32 %v951, 28
  store i32 %op952, ptr %slot102, align 8
  %v953 = load i32, ptr %slot102, align 8
  %cv954 = zext i32 %v953 to i64
  %cond955 = icmp ne i64 %cv954, 0
  br i1 %cond955, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v956 = load i64, ptr %slot23, align 8
  store i64 %v956, ptr %slot103, align 8
  %v957 = load i64, ptr %slot103, align 8
  %v958 = load i64, ptr %slot100, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v957, i64 %v958) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v959 = load i64, ptr %slot23, align 8
  store i64 %v959, ptr %slot104, align 8
  %v960 = load i64, ptr %slot104, align 8
  %v961 = load i64, ptr %slot100, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v960, i64 %v961) nomerge, !dbg !124
  br label %bb_rcslotdone114
bb_rcslotdone114:
  br label %bb_i36
bb_rcarmnext111:
  %v962 = load i64, ptr %slot75, align 8
  %cmp963 = icmp eq i64 %v962, 4
  %cv964 = zext i1 %cmp963 to i64
  store i64 %cv964, ptr %slot105, align 8
  %v965 = load i64, ptr %slot105, align 8
  %cond966 = icmp ne i64 %v965, 0
  br i1 %cond966, label %bb_rcarm121, label %bb_rcarmnext121
bb_rcarm121:
  %v967 = load i64, ptr %slot6, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %ld969 = load i32, ptr %p968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld969, ptr %slot106, align 8
  %v970 = load i32, ptr %slot106, align 8
  %cv971 = zext i32 %v970 to i64
  %cond972 = icmp ne i64 %cv971, 0
  br i1 %cond972, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v973 = load i64, ptr %slot6, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i32 0, ptr %p974, align 4, !alias.scope !3, !noalias !4
  %v975 = load i64, ptr %slot10, align 8
  store i64 %v975, ptr %slot107, align 8
  %v976 = load i64, ptr %slot7, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %ld978 = load i32, ptr %p977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld978, ptr %slot108, align 8
  %v979 = load i32, ptr %slot108, align 8
  %op980 = and i32 %v979, 28
  store i32 %op980, ptr %slot109, align 8
  %v981 = load i32, ptr %slot109, align 8
  %cv982 = zext i32 %v981 to i64
  %cond983 = icmp ne i64 %cv982, 0
  br i1 %cond983, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v984 = load i64, ptr %slot23, align 8
  store i64 %v984, ptr %slot110, align 8
  %v985 = load i64, ptr %slot110, align 8
  %v986 = load i64, ptr %slot107, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v985, i64 %v986) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v987 = load i64, ptr %slot23, align 8
  store i64 %v987, ptr %slot111, align 8
  %v988 = load i64, ptr %slot111, align 8
  %v989 = load i64, ptr %slot107, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v988, i64 %v989) nomerge, !dbg !124
  br label %bb_rcslotdone124
bb_rcslotdone124:
  br label %bb_i42
bb_rcarmnext121:
  %v990 = load i64, ptr %slot75, align 8
  %cmp991 = icmp eq i64 %v990, 5
  %cv992 = zext i1 %cmp991 to i64
  store i64 %cv992, ptr %slot112, align 8
  %v993 = load i64, ptr %slot112, align 8
  %cond994 = icmp ne i64 %v993, 0
  br i1 %cond994, label %bb_rcarm131, label %bb_rcarmnext131
bb_rcarm131:
  %v995 = load i64, ptr %slot6, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i32, ptr %p996, align 4, !alias.scope !3, !noalias !4
  store i32 %ld997, ptr %slot113, align 8
  %v998 = load i32, ptr %slot113, align 8
  %cv999 = zext i32 %v998 to i64
  %cond1000 = icmp ne i64 %cv999, 0
  br i1 %cond1000, label %bb_rcslotdrop134, label %bb_rcslotdone134
bb_rcslotdrop134:
  %v1001 = load i64, ptr %slot6, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i32 0, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  %v1003 = load i64, ptr %slot10, align 8
  store i64 %v1003, ptr %slot114, align 8
  %v1004 = load i64, ptr %slot7, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  %ld1006 = load i32, ptr %p1005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1006, ptr %slot115, align 8
  %v1007 = load i32, ptr %slot115, align 8
  %op1008 = and i32 %v1007, 28
  store i32 %op1008, ptr %slot116, align 8
  %v1009 = load i32, ptr %slot116, align 8
  %cv1010 = zext i32 %v1009 to i64
  %cond1011 = icmp ne i64 %cv1010, 0
  br i1 %cond1011, label %bb_rcslotrole134, label %bb_rcslotowner134
bb_rcslotrole134:
  %v1012 = load i64, ptr %slot23, align 8
  store i64 %v1012, ptr %slot117, align 8
  %v1013 = load i64, ptr %slot117, align 8
  %v1014 = load i64, ptr %slot114, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1013, i64 %v1014) nomerge, !dbg !124
  br label %bb_rcslotdone134
bb_rcslotowner134:
  %v1015 = load i64, ptr %slot23, align 8
  store i64 %v1015, ptr %slot118, align 8
  %v1016 = load i64, ptr %slot118, align 8
  %v1017 = load i64, ptr %slot114, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1016, i64 %v1017) nomerge, !dbg !124
  br label %bb_rcslotdone134
bb_rcslotdone134:
  br label %bb_i48
bb_rcarmnext131:
  %v1018 = load i64, ptr %slot75, align 8
  %cmp1019 = icmp eq i64 %v1018, 6
  %cv1020 = zext i1 %cmp1019 to i64
  store i64 %cv1020, ptr %slot119, align 8
  %v1021 = load i64, ptr %slot119, align 8
  %cond1022 = icmp ne i64 %v1021, 0
  br i1 %cond1022, label %bb_rcarm141, label %bb_rcarmnext141
bb_rcarm141:
  %v1023 = load i64, ptr %slot6, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %ld1025 = load i32, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1025, ptr %slot120, align 8
  %v1026 = load i32, ptr %slot120, align 8
  %cv1027 = zext i32 %v1026 to i64
  %cond1028 = icmp ne i64 %cv1027, 0
  br i1 %cond1028, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v1029 = load i64, ptr %slot6, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i32 0, ptr %p1030, align 4, !alias.scope !3, !noalias !4
  %v1031 = load i64, ptr %slot10, align 8
  store i64 %v1031, ptr %slot121, align 8
  %v1032 = load i64, ptr %slot7, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %ld1034 = load i32, ptr %p1033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1034, ptr %slot122, align 8
  %v1035 = load i32, ptr %slot122, align 8
  %op1036 = and i32 %v1035, 28
  store i32 %op1036, ptr %slot123, align 8
  %v1037 = load i32, ptr %slot123, align 8
  %cv1038 = zext i32 %v1037 to i64
  %cond1039 = icmp ne i64 %cv1038, 0
  br i1 %cond1039, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v1040 = load i64, ptr %slot23, align 8
  store i64 %v1040, ptr %slot124, align 8
  %v1041 = load i64, ptr %slot124, align 8
  %v1042 = load i64, ptr %slot121, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1041, i64 %v1042) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v1043 = load i64, ptr %slot23, align 8
  store i64 %v1043, ptr %slot125, align 8
  %v1044 = load i64, ptr %slot125, align 8
  %v1045 = load i64, ptr %slot121, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1044, i64 %v1045) nomerge, !dbg !124
  br label %bb_rcslotdone144
bb_rcslotdone144:
  br label %bb_i54
bb_rcarmnext141:
  %v1046 = load i64, ptr %slot75, align 8
  %cmp1047 = icmp eq i64 %v1046, 7
  %cv1048 = zext i1 %cmp1047 to i64
  store i64 %cv1048, ptr %slot126, align 8
  %v1049 = load i64, ptr %slot126, align 8
  %cond1050 = icmp ne i64 %v1049, 0
  br i1 %cond1050, label %bb_rcarm151, label %bb_rcarmnext151
bb_rcarm151:
  %v1051 = load i64, ptr %slot6, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %ld1053 = load i32, ptr %p1052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1053, ptr %slot127, align 8
  %v1054 = load i32, ptr %slot127, align 8
  %cv1055 = zext i32 %v1054 to i64
  %cond1056 = icmp ne i64 %cv1055, 0
  br i1 %cond1056, label %bb_rcslotdrop154, label %bb_rcslotdone154
bb_rcslotdrop154:
  %v1057 = load i64, ptr %slot6, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 0, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot10, align 8
  store i64 %v1059, ptr %slot128, align 8
  %v1060 = load i64, ptr %slot7, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %ld1062 = load i32, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1062, ptr %slot129, align 8
  %v1063 = load i32, ptr %slot129, align 8
  %op1064 = and i32 %v1063, 28
  store i32 %op1064, ptr %slot130, align 8
  %v1065 = load i32, ptr %slot130, align 8
  %cv1066 = zext i32 %v1065 to i64
  %cond1067 = icmp ne i64 %cv1066, 0
  br i1 %cond1067, label %bb_rcslotrole154, label %bb_rcslotowner154
bb_rcslotrole154:
  %v1068 = load i64, ptr %slot23, align 8
  store i64 %v1068, ptr %slot131, align 8
  %v1069 = load i64, ptr %slot131, align 8
  %v1070 = load i64, ptr %slot128, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1069, i64 %v1070) nomerge, !dbg !124
  br label %bb_rcslotdone154
bb_rcslotowner154:
  %v1071 = load i64, ptr %slot23, align 8
  store i64 %v1071, ptr %slot132, align 8
  %v1072 = load i64, ptr %slot132, align 8
  %v1073 = load i64, ptr %slot128, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1072, i64 %v1073) nomerge, !dbg !124
  br label %bb_rcslotdone154
bb_rcslotdone154:
  br label %bb_i60
bb_rcarmnext151:
  %v1074 = load i64, ptr %slot75, align 8
  %cmp1075 = icmp eq i64 %v1074, 8
  %cv1076 = zext i1 %cmp1075 to i64
  store i64 %cv1076, ptr %slot133, align 8
  %v1077 = load i64, ptr %slot133, align 8
  %cond1078 = icmp ne i64 %v1077, 0
  br i1 %cond1078, label %bb_rcarm161, label %bb_rcarmnext161
bb_rcarm161:
  %v1079 = load i64, ptr %slot6, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %ld1081 = load i32, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1081, ptr %slot134, align 8
  %v1082 = load i32, ptr %slot134, align 8
  %cv1083 = zext i32 %v1082 to i64
  %cond1084 = icmp ne i64 %cv1083, 0
  br i1 %cond1084, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v1085 = load i64, ptr %slot6, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i32 0, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot10, align 8
  store i64 %v1087, ptr %slot135, align 8
  %v1088 = load i64, ptr %slot7, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  %ld1090 = load i32, ptr %p1089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1090, ptr %slot136, align 8
  %v1091 = load i32, ptr %slot136, align 8
  %op1092 = and i32 %v1091, 28
  store i32 %op1092, ptr %slot137, align 8
  %v1093 = load i32, ptr %slot137, align 8
  %cv1094 = zext i32 %v1093 to i64
  %cond1095 = icmp ne i64 %cv1094, 0
  br i1 %cond1095, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v1096 = load i64, ptr %slot23, align 8
  store i64 %v1096, ptr %slot138, align 8
  %v1097 = load i64, ptr %slot138, align 8
  %v1098 = load i64, ptr %slot135, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1097, i64 %v1098) nomerge, !dbg !124
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v1099 = load i64, ptr %slot23, align 8
  store i64 %v1099, ptr %slot139, align 8
  %v1100 = load i64, ptr %slot139, align 8
  %v1101 = load i64, ptr %slot135, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1100, i64 %v1101) nomerge, !dbg !124
  br label %bb_rcslotdone164
bb_rcslotdone164:
  br label %bb_i66
bb_rcarmnext161:
  %v1102 = load i64, ptr %slot75, align 8
  %cmp1103 = icmp eq i64 %v1102, 9
  %cv1104 = zext i1 %cmp1103 to i64
  store i64 %cv1104, ptr %slot140, align 8
  %v1105 = load i64, ptr %slot140, align 8
  %cond1106 = icmp ne i64 %v1105, 0
  br i1 %cond1106, label %bb_rcarm171, label %bb_rcarmnext171
bb_rcarm171:
  %v1107 = load i64, ptr %slot6, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i32, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1109, ptr %slot141, align 8
  %v1110 = load i32, ptr %slot141, align 8
  %cv1111 = zext i32 %v1110 to i64
  %cond1112 = icmp ne i64 %cv1111, 0
  br i1 %cond1112, label %bb_rcslotdrop174, label %bb_rcslotdone174
bb_rcslotdrop174:
  %v1113 = load i64, ptr %slot6, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i32 0, ptr %p1114, align 4, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot10, align 8
  store i64 %v1115, ptr %slot142, align 8
  %v1116 = load i64, ptr %slot7, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  %ld1118 = load i32, ptr %p1117, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1118, ptr %slot143, align 8
  %v1119 = load i32, ptr %slot143, align 8
  %op1120 = and i32 %v1119, 28
  store i32 %op1120, ptr %slot144, align 8
  %v1121 = load i32, ptr %slot144, align 8
  %cv1122 = zext i32 %v1121 to i64
  %cond1123 = icmp ne i64 %cv1122, 0
  br i1 %cond1123, label %bb_rcslotrole174, label %bb_rcslotowner174
bb_rcslotrole174:
  %v1124 = load i64, ptr %slot23, align 8
  store i64 %v1124, ptr %slot145, align 8
  %v1125 = load i64, ptr %slot145, align 8
  %v1126 = load i64, ptr %slot142, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1125, i64 %v1126) nomerge, !dbg !124
  br label %bb_rcslotdone174
bb_rcslotowner174:
  %v1127 = load i64, ptr %slot23, align 8
  store i64 %v1127, ptr %slot146, align 8
  %v1128 = load i64, ptr %slot146, align 8
  %v1129 = load i64, ptr %slot142, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1128, i64 %v1129) nomerge, !dbg !124
  br label %bb_rcslotdone174
bb_rcslotdone174:
  br label %bb_i72
bb_rcarmnext171:
  %v1130 = load i64, ptr %slot75, align 8
  %cmp1131 = icmp eq i64 %v1130, 10
  %cv1132 = zext i1 %cmp1131 to i64
  store i64 %cv1132, ptr %slot147, align 8
  %v1133 = load i64, ptr %slot147, align 8
  %cond1134 = icmp ne i64 %v1133, 0
  br i1 %cond1134, label %bb_rcarm181, label %bb_rcarmnext181
bb_rcarm181:
  %v1135 = load i64, ptr %slot6, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %ld1137 = load i32, ptr %p1136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1137, ptr %slot148, align 8
  %v1138 = load i32, ptr %slot148, align 8
  %cv1139 = zext i32 %v1138 to i64
  %cond1140 = icmp ne i64 %cv1139, 0
  br i1 %cond1140, label %bb_rcslotdrop184, label %bb_rcslotdone184
bb_rcslotdrop184:
  %v1141 = load i64, ptr %slot6, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i32 0, ptr %p1142, align 4, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot10, align 8
  store i64 %v1143, ptr %slot149, align 8
  %v1144 = load i64, ptr %slot7, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %ld1146 = load i32, ptr %p1145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1146, ptr %slot150, align 8
  %v1147 = load i32, ptr %slot150, align 8
  %op1148 = and i32 %v1147, 28
  store i32 %op1148, ptr %slot151, align 8
  %v1149 = load i32, ptr %slot151, align 8
  %cv1150 = zext i32 %v1149 to i64
  %cond1151 = icmp ne i64 %cv1150, 0
  br i1 %cond1151, label %bb_rcslotrole184, label %bb_rcslotowner184
bb_rcslotrole184:
  %v1152 = load i64, ptr %slot23, align 8
  store i64 %v1152, ptr %slot152, align 8
  %v1153 = load i64, ptr %slot152, align 8
  %v1154 = load i64, ptr %slot149, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1153, i64 %v1154) nomerge, !dbg !124
  br label %bb_rcslotdone184
bb_rcslotowner184:
  %v1155 = load i64, ptr %slot23, align 8
  store i64 %v1155, ptr %slot153, align 8
  %v1156 = load i64, ptr %slot153, align 8
  %v1157 = load i64, ptr %slot149, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1156, i64 %v1157) nomerge, !dbg !124
  br label %bb_rcslotdone184
bb_rcslotdone184:
  br label %bb_i78
bb_rcarmnext181:
  %v1158 = load i64, ptr %slot75, align 8
  %cmp1159 = icmp eq i64 %v1158, 11
  %cv1160 = zext i1 %cmp1159 to i64
  store i64 %cv1160, ptr %slot154, align 8
  %v1161 = load i64, ptr %slot154, align 8
  %cond1162 = icmp ne i64 %v1161, 0
  br i1 %cond1162, label %bb_rcarm191, label %bb_rcarmnext191
bb_rcarm191:
  %v1163 = load i64, ptr %slot6, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i32, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1165, ptr %slot155, align 8
  %v1166 = load i32, ptr %slot155, align 8
  %cv1167 = zext i32 %v1166 to i64
  %cond1168 = icmp ne i64 %cv1167, 0
  br i1 %cond1168, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v1169 = load i64, ptr %slot6, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 0, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot10, align 8
  store i64 %v1171, ptr %slot156, align 8
  %v1172 = load i64, ptr %slot7, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  %ld1174 = load i32, ptr %p1173, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1174, ptr %slot157, align 8
  %v1175 = load i32, ptr %slot157, align 8
  %op1176 = and i32 %v1175, 28
  store i32 %op1176, ptr %slot158, align 8
  %v1177 = load i32, ptr %slot158, align 8
  %cv1178 = zext i32 %v1177 to i64
  %cond1179 = icmp ne i64 %cv1178, 0
  br i1 %cond1179, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v1180 = load i64, ptr %slot23, align 8
  store i64 %v1180, ptr %slot159, align 8
  %v1181 = load i64, ptr %slot159, align 8
  %v1182 = load i64, ptr %slot156, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1181, i64 %v1182) nomerge, !dbg !124
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v1183 = load i64, ptr %slot23, align 8
  store i64 %v1183, ptr %slot160, align 8
  %v1184 = load i64, ptr %slot160, align 8
  %v1185 = load i64, ptr %slot156, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1184, i64 %v1185) nomerge, !dbg !124
  br label %bb_rcslotdone194
bb_rcslotdone194:
  br label %bb_i84
bb_rcarmnext191:
  br label %bb_failure
bb_i18:
  %v1186 = load i64, ptr %slot16, align 8
  %v1187 = load i64, ptr %slot17, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i64 %v1186, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot16, align 8
  %v1190 = load i64, ptr %slot17, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  store i64 %v1189, ptr %p1191, align 8, !alias.scope !3, !noalias !4
  %v1192 = load i64, ptr %slot17, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i64, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1194, ptr %slot161, align 8
  %v1195 = load i64, ptr %slot6, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i32, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1197, ptr %slot162, align 8
  %v1198 = load i64, ptr %slot7, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %ld1200 = load i32, ptr %p1199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1200, ptr %slot163, align 8
  %v1201 = load i32, ptr %slot163, align 8
  %op1202 = and i32 %v1201, 24
  store i32 %op1202, ptr %slot163, align 8
  %v1203 = load i32, ptr %slot163, align 8
  %cmp1204 = icmp eq i32 %v1203, 0
  %cv1205 = zext i1 %cmp1204 to i32
  store i32 %cv1205, ptr %slot164, align 8
  %v1206 = load i32, ptr %slot162, align 8
  %v1207 = load i32, ptr %slot164, align 8
  %op1208 = and i32 %v1206, %v1207
  store i32 %op1208, ptr %slot165, align 8
  %v1209 = load i64, ptr %slot24, align 8
  store i64 %v1209, ptr %slot166, align 8
  %v1210 = load i32, ptr %slot165, align 8
  %op1211 = mul i32 %v1210, 4
  store i32 %op1211, ptr %slot167, align 8
  %v1212 = load i32, ptr %slot167, align 8
  %op1213 = or i32 %v1212, 0
  store i32 %op1213, ptr %slot168, align 8
  %v1214 = load i64, ptr %slot11, align 8
  store i64 %v1214, ptr %slot169, align 8
  %v1215 = load i64, ptr %slot23, align 8
  %v1216 = load i64, ptr %slot169, align 8
  %v1217 = load i64, ptr %slot161, align 8
  %v1218 = load i64, ptr %slot166, align 8
  %cv1219 = trunc i64 %v1218 to i32
  %v1220 = load i32, ptr %slot168, align 8
  %call1221 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_publish(i64 %v1215, i64 %v1216, i64 %v1217, i32 %cv1219, i32 %v1220) nomerge, !dbg !126
  store i32 %call1221, ptr %slot170, align 8
  %v1222 = load i32, ptr %slot170, align 8
  %cv1223 = zext i32 %v1222 to i64
  %cond1224 = icmp ne i64 %cv1223, 0
  br i1 %cond1224, label %bb_rcsuccess215, label %bb_rcfailure215
bb_rcfailure215:
  %v1225 = load i64, ptr %slot23, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %call1227 = call i32 @myl_rc_take_failure(ptr %p1226) nomerge, !dbg !126
  store i32 %call1227, ptr %slot171, align 8
  %v1228 = load i64, ptr %slot1, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %v1230 = load i32, ptr %slot171, align 8
  %call1231 = call i32 @myl_qbe_rc_status(ptr %p1229, i32 %v1230) nomerge, !dbg !126
  store i32 %call1231, ptr %slot172, align 8
  br label %bb_failure
bb_rcsuccess215:
  %v1232 = load i32, ptr %slot165, align 8
  %cv1233 = zext i32 %v1232 to i64
  %cond1234 = icmp ne i64 %cv1233, 0
  br i1 %cond1234, label %bb_rchtaken218, label %bb_rchcopied218
bb_rchcopied218:
  %v1235 = load i64, ptr %slot6, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i32, ptr %p1236, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1237, ptr %slot173, align 8
  %v1238 = load i32, ptr %slot173, align 8
  %cv1239 = zext i32 %v1238 to i64
  %cond1240 = icmp ne i64 %cv1239, 0
  br i1 %cond1240, label %bb_rcslotdrop221, label %bb_rcslotdone221
bb_rcslotdrop221:
  %v1241 = load i64, ptr %slot6, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  store i32 0, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  %v1243 = load i64, ptr %slot10, align 8
  store i64 %v1243, ptr %slot174, align 8
  %v1244 = load i64, ptr %slot7, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i32, ptr %p1245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1246, ptr %slot175, align 8
  %v1247 = load i32, ptr %slot175, align 8
  %op1248 = and i32 %v1247, 28
  store i32 %op1248, ptr %slot176, align 8
  %v1249 = load i32, ptr %slot176, align 8
  %cv1250 = zext i32 %v1249 to i64
  %cond1251 = icmp ne i64 %cv1250, 0
  br i1 %cond1251, label %bb_rcslotrole221, label %bb_rcslotowner221
bb_rcslotrole221:
  %v1252 = load i64, ptr %slot23, align 8
  store i64 %v1252, ptr %slot177, align 8
  %v1253 = load i64, ptr %slot177, align 8
  %v1254 = load i64, ptr %slot174, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1253, i64 %v1254) nomerge, !dbg !126
  br label %bb_rcslotdone221
bb_rcslotowner221:
  %v1255 = load i64, ptr %slot23, align 8
  store i64 %v1255, ptr %slot178, align 8
  %v1256 = load i64, ptr %slot178, align 8
  %v1257 = load i64, ptr %slot174, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1256, i64 %v1257) nomerge, !dbg !126
  br label %bb_rcslotdone221
bb_rcslotdone221:
  br label %bb_rchprepared218
bb_rchtaken218:
  %v1258 = load i64, ptr %slot6, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  store i32 0, ptr %p1259, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared218
bb_rchprepared218:
  %v1260 = load i64, ptr %slot9, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i32 2, ptr %p1261, align 4, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot8, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  store i32 1, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  %v1264 = load i64, ptr %slot10, align 8
  store i64 %v1264, ptr %slot179, align 8
  %v1265 = load i64, ptr %slot11, align 8
  store i64 %v1265, ptr %slot180, align 8
  %v1266 = load i64, ptr %slot180, align 8
  %v1267 = load i64, ptr %slot179, align 8
  %p1268 = inttoptr i64 %v1266 to ptr
  %p1269 = inttoptr i64 %v1267 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1269, ptr %p1268, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot7, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i32 2, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot9, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i32, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1274, ptr %slot181, align 8
  %v1275 = load i32, ptr %slot181, align 8
  %v1276 = load i64, ptr %slot7, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i32 %v1275, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot8, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i32 0, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot6, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i32 1, ptr %p1281, align 4, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot179, align 8
  %v1283 = load i64, ptr %slot17, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  store i64 %v1282, ptr %p1284, align 8, !alias.scope !3, !noalias !4
  %v1285 = load i64, ptr %slot17, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  %ld1287 = load i64, ptr %p1286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1287, ptr %slot182, align 8
  %v1288 = load i64, ptr %slot17, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i64, ptr %p1289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1290, ptr %slot183, align 8
  %v1291 = load i64, ptr %slot11, align 8
  store i64 %v1291, ptr %slot184, align 8
  %v1292 = load i64, ptr %slot24, align 8
  store i64 %v1292, ptr %slot185, align 8
  %v1293 = load i64, ptr %slot23, align 8
  %v1294 = load i64, ptr %slot184, align 8
  %v1295 = load i64, ptr %slot183, align 8
  %v1296 = load i64, ptr %slot185, align 8
  %cv1297 = trunc i64 %v1296 to i32
  %call1298 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1293, i64 %v1294, i64 %v1295, i32 %cv1297) nomerge, !dbg !128
  store i32 %call1298, ptr %slot186, align 8
  %v1299 = load i32, ptr %slot186, align 8
  %cv1300 = zext i32 %v1299 to i64
  %cond1301 = icmp ne i64 %cv1300, 0
  br i1 %cond1301, label %bb_rcsuccess244, label %bb_rcfailure244
bb_rcfailure244:
  %v1302 = load i64, ptr %slot23, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %call1304 = call i32 @myl_rc_take_failure(ptr %p1303) nomerge, !dbg !128
  store i32 %call1304, ptr %slot187, align 8
  %v1305 = load i64, ptr %slot1, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %v1307 = load i32, ptr %slot187, align 8
  %call1308 = call i32 @myl_qbe_rc_status(ptr %p1306, i32 %v1307) nomerge, !dbg !128
  store i32 %call1308, ptr %slot188, align 8
  br label %bb_failure
bb_rcsuccess244:
  %v1309 = load i64, ptr %slot6, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i32 0, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot9, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  store i32 2, ptr %p1312, align 4, !alias.scope !3, !noalias !4
  %v1313 = load i64, ptr %slot8, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  store i32 1, ptr %p1314, align 4, !alias.scope !3, !noalias !4
  %v1315 = load i64, ptr %slot11, align 8
  store i64 %v1315, ptr %slot189, align 8
  %v1316 = load i64, ptr %slot8, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 0, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot6, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %ld1320 = load i32, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1320, ptr %slot190, align 8
  %v1321 = load i32, ptr %slot190, align 8
  %cv1322 = zext i32 %v1321 to i64
  %cond1323 = icmp ne i64 %cv1322, 0
  br i1 %cond1323, label %bb_rcslotdrop254, label %bb_rcslotdone254
bb_rcslotdrop254:
  %v1324 = load i64, ptr %slot6, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 0, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot10, align 8
  store i64 %v1326, ptr %slot191, align 8
  %v1327 = load i64, ptr %slot7, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  %ld1329 = load i32, ptr %p1328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1329, ptr %slot192, align 8
  %v1330 = load i32, ptr %slot192, align 8
  %op1331 = and i32 %v1330, 28
  store i32 %op1331, ptr %slot193, align 8
  %v1332 = load i32, ptr %slot193, align 8
  %cv1333 = zext i32 %v1332 to i64
  %cond1334 = icmp ne i64 %cv1333, 0
  br i1 %cond1334, label %bb_rcslotrole254, label %bb_rcslotowner254
bb_rcslotrole254:
  %v1335 = load i64, ptr %slot23, align 8
  store i64 %v1335, ptr %slot194, align 8
  %v1336 = load i64, ptr %slot194, align 8
  %v1337 = load i64, ptr %slot191, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1336, i64 %v1337) nomerge, !dbg !128
  br label %bb_rcslotdone254
bb_rcslotowner254:
  %v1338 = load i64, ptr %slot23, align 8
  store i64 %v1338, ptr %slot195, align 8
  %v1339 = load i64, ptr %slot195, align 8
  %v1340 = load i64, ptr %slot191, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1339, i64 %v1340) nomerge, !dbg !128
  br label %bb_rcslotdone254
bb_rcslotdone254:
  %v1341 = load i64, ptr %slot189, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1342, i64 56, i1 false)
  ret void
bb_i24:
  %v1343 = load i64, ptr %slot17, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i64 0, ptr %p1344, align 8, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot17, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %ld1347 = load i64, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1347, ptr %slot196, align 8
  %v1348 = load i64, ptr %slot196, align 8
  %cond1349 = icmp ne i64 %v1348, 0
  br i1 %cond1349, label %bb_success317, label %bb_failed317
bb_failed317:
  %v1350 = load i64, ptr %slot1, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  call void @myl_qbe_fail_assert(ptr %p1351) nomerge, !dbg !130
  unreachable
bb_success317:
  %v1352 = load i64, ptr %slot12, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  %ld1354 = load i64, ptr %p1353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1354, ptr %slot197, align 8
  %v1355 = load i64, ptr %slot197, align 8
  %v1356 = load i64, ptr %slot17, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i64 %v1355, ptr %p1357, align 8, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot13, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %ld1360 = load i64, ptr %p1359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1360, ptr %slot198, align 8
  %v1361 = load i64, ptr %slot198, align 8
  %v1362 = load i64, ptr %slot18, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i64 %v1361, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  %v1364 = load i64, ptr %slot17, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %ld1366 = load i64, ptr %p1365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1366, ptr %slot199, align 8
  %v1367 = load i64, ptr %slot18, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %ld1369 = load i64, ptr %p1368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1369, ptr %slot200, align 8
  %v1370 = load i64, ptr %slot1, align 8
  %v1371 = load i64, ptr %slot199, align 8
  %v1372 = load i64, ptr %slot200, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult202, i64 %v1370, i64 %v1371, i64 %v1372) nomerge, !dbg !132
  %addr1373 = ptrtoint ptr %callresult202 to i64
  store i64 %addr1373, ptr %slot201, align 8
  %v1374 = load i64, ptr %slot201, align 8
  %v1375 = load i64, ptr %slot17, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i64 %v1374, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot17, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i64, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1379, ptr %slot203, align 8
  %v1380 = load i64, ptr %slot11, align 8
  store i64 %v1380, ptr %slot204, align 8
  %v1381 = load i64, ptr %slot203, align 8
  %v1382 = load i64, ptr %slot204, align 8
  %p1383 = inttoptr i64 %v1381 to ptr
  %p1384 = inttoptr i64 %v1382 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1384, ptr %p1383, i64 56, i1 false)
  %v1385 = load i64, ptr %slot9, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 2, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot8, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  store i32 1, ptr %p1388, align 4, !alias.scope !3, !noalias !4
  %v1389 = load i64, ptr %slot6, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %ld1391 = load i32, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1391, ptr %slot205, align 8
  %v1392 = load i32, ptr %slot205, align 8
  %cv1393 = zext i32 %v1392 to i64
  %cond1394 = icmp ne i64 %cv1393, 0
  br i1 %cond1394, label %bb_rcslotdrop329, label %bb_rcslotdone329
bb_rcslotdrop329:
  %v1395 = load i64, ptr %slot6, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i32 0, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot10, align 8
  store i64 %v1397, ptr %slot206, align 8
  %v1398 = load i64, ptr %slot7, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i32, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1400, ptr %slot207, align 8
  %v1401 = load i32, ptr %slot207, align 8
  %op1402 = and i32 %v1401, 28
  store i32 %op1402, ptr %slot208, align 8
  %v1403 = load i32, ptr %slot208, align 8
  %cv1404 = zext i32 %v1403 to i64
  %cond1405 = icmp ne i64 %cv1404, 0
  br i1 %cond1405, label %bb_rcslotrole329, label %bb_rcslotowner329
bb_rcslotrole329:
  %v1406 = load i64, ptr %slot23, align 8
  store i64 %v1406, ptr %slot209, align 8
  %v1407 = load i64, ptr %slot209, align 8
  %v1408 = load i64, ptr %slot206, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1407, i64 %v1408) nomerge, !dbg !132
  br label %bb_rcslotdone329
bb_rcslotowner329:
  %v1409 = load i64, ptr %slot23, align 8
  store i64 %v1409, ptr %slot210, align 8
  %v1410 = load i64, ptr %slot210, align 8
  %v1411 = load i64, ptr %slot206, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1410, i64 %v1411) nomerge, !dbg !132
  br label %bb_rcslotdone329
bb_rcslotdone329:
  %v1412 = load i64, ptr %slot10, align 8
  store i64 %v1412, ptr %slot211, align 8
  %v1413 = load i64, ptr %slot11, align 8
  store i64 %v1413, ptr %slot212, align 8
  %v1414 = load i64, ptr %slot212, align 8
  %v1415 = load i64, ptr %slot211, align 8
  %p1416 = inttoptr i64 %v1414 to ptr
  %p1417 = inttoptr i64 %v1415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1417, ptr %p1416, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1418 = load i64, ptr %slot7, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  store i32 2, ptr %p1419, align 4, !alias.scope !3, !noalias !4
  %v1420 = load i64, ptr %slot9, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %ld1422 = load i32, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1422, ptr %slot213, align 8
  %v1423 = load i32, ptr %slot213, align 8
  %v1424 = load i64, ptr %slot7, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 %v1423, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot8, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i32 0, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot6, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i32 1, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot211, align 8
  %v1431 = load i64, ptr %slot17, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  store i64 %v1430, ptr %p1432, align 8, !alias.scope !3, !noalias !4
  %v1433 = load i64, ptr %slot17, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  %ld1435 = load i64, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1435, ptr %slot214, align 8
  %v1436 = load i64, ptr %slot17, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %ld1438 = load i64, ptr %p1437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1438, ptr %slot215, align 8
  %v1439 = load i64, ptr %slot11, align 8
  store i64 %v1439, ptr %slot216, align 8
  %v1440 = load i64, ptr %slot24, align 8
  store i64 %v1440, ptr %slot217, align 8
  %v1441 = load i64, ptr %slot23, align 8
  %v1442 = load i64, ptr %slot216, align 8
  %v1443 = load i64, ptr %slot215, align 8
  %v1444 = load i64, ptr %slot217, align 8
  %cv1445 = trunc i64 %v1444 to i32
  %call1446 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1441, i64 %v1442, i64 %v1443, i32 %cv1445) nomerge, !dbg !134
  store i32 %call1446, ptr %slot218, align 8
  %v1447 = load i32, ptr %slot218, align 8
  %cv1448 = zext i32 %v1447 to i64
  %cond1449 = icmp ne i64 %cv1448, 0
  br i1 %cond1449, label %bb_rcsuccess349, label %bb_rcfailure349
bb_rcfailure349:
  %v1450 = load i64, ptr %slot23, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  %call1452 = call i32 @myl_rc_take_failure(ptr %p1451) nomerge, !dbg !134
  store i32 %call1452, ptr %slot219, align 8
  %v1453 = load i64, ptr %slot1, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %v1455 = load i32, ptr %slot219, align 8
  %call1456 = call i32 @myl_qbe_rc_status(ptr %p1454, i32 %v1455) nomerge, !dbg !134
  store i32 %call1456, ptr %slot220, align 8
  br label %bb_failure
bb_rcsuccess349:
  %v1457 = load i64, ptr %slot6, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i32 0, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot9, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i32 2, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  %v1461 = load i64, ptr %slot8, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  store i32 1, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  %v1463 = load i64, ptr %slot11, align 8
  store i64 %v1463, ptr %slot221, align 8
  %v1464 = load i64, ptr %slot8, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  store i32 0, ptr %p1465, align 4, !alias.scope !3, !noalias !4
  %v1466 = load i64, ptr %slot6, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  %ld1468 = load i32, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1468, ptr %slot222, align 8
  %v1469 = load i32, ptr %slot222, align 8
  %cv1470 = zext i32 %v1469 to i64
  %cond1471 = icmp ne i64 %cv1470, 0
  br i1 %cond1471, label %bb_rcslotdrop359, label %bb_rcslotdone359
bb_rcslotdrop359:
  %v1472 = load i64, ptr %slot6, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  store i32 0, ptr %p1473, align 4, !alias.scope !3, !noalias !4
  %v1474 = load i64, ptr %slot10, align 8
  store i64 %v1474, ptr %slot223, align 8
  %v1475 = load i64, ptr %slot7, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i32, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1477, ptr %slot224, align 8
  %v1478 = load i32, ptr %slot224, align 8
  %op1479 = and i32 %v1478, 28
  store i32 %op1479, ptr %slot225, align 8
  %v1480 = load i32, ptr %slot225, align 8
  %cv1481 = zext i32 %v1480 to i64
  %cond1482 = icmp ne i64 %cv1481, 0
  br i1 %cond1482, label %bb_rcslotrole359, label %bb_rcslotowner359
bb_rcslotrole359:
  %v1483 = load i64, ptr %slot23, align 8
  store i64 %v1483, ptr %slot226, align 8
  %v1484 = load i64, ptr %slot226, align 8
  %v1485 = load i64, ptr %slot223, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1484, i64 %v1485) nomerge, !dbg !134
  br label %bb_rcslotdone359
bb_rcslotowner359:
  %v1486 = load i64, ptr %slot23, align 8
  store i64 %v1486, ptr %slot227, align 8
  %v1487 = load i64, ptr %slot227, align 8
  %v1488 = load i64, ptr %slot223, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1487, i64 %v1488) nomerge, !dbg !134
  br label %bb_rcslotdone359
bb_rcslotdone359:
  %v1489 = load i64, ptr %slot221, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1490, i64 56, i1 false)
  ret void
bb_i30:
  %v1491 = load i64, ptr %slot17, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  store i64 0, ptr %p1492, align 8, !alias.scope !3, !noalias !4
  %v1493 = load i64, ptr %slot17, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  %ld1495 = load i64, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1495, ptr %slot228, align 8
  %v1496 = load i64, ptr %slot228, align 8
  %cond1497 = icmp ne i64 %v1496, 0
  br i1 %cond1497, label %bb_success422, label %bb_failed422
bb_failed422:
  %v1498 = load i64, ptr %slot1, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  call void @myl_qbe_fail_assert(ptr %p1499) nomerge, !dbg !136
  unreachable
bb_success422:
  %v1500 = load i64, ptr %slot12, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %ld1502 = load i64, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1502, ptr %slot229, align 8
  %v1503 = load i64, ptr %slot229, align 8
  %v1504 = load i64, ptr %slot17, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  store i64 %v1503, ptr %p1505, align 8, !alias.scope !3, !noalias !4
  %v1506 = load i64, ptr %slot13, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  %ld1508 = load i64, ptr %p1507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1508, ptr %slot230, align 8
  %v1509 = load i64, ptr %slot230, align 8
  %v1510 = load i64, ptr %slot18, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  store i64 %v1509, ptr %p1511, align 8, !alias.scope !3, !noalias !4
  %v1512 = load i64, ptr %slot17, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %ld1514 = load i64, ptr %p1513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1514, ptr %slot231, align 8
  %v1515 = load i64, ptr %slot18, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %ld1517 = load i64, ptr %p1516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1517, ptr %slot232, align 8
  %v1518 = load i64, ptr %slot1, align 8
  %v1519 = load i64, ptr %slot231, align 8
  %v1520 = load i64, ptr %slot232, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult234, i64 %v1518, i64 %v1519, i64 %v1520) nomerge, !dbg !138
  %addr1521 = ptrtoint ptr %callresult234 to i64
  store i64 %addr1521, ptr %slot233, align 8
  %v1522 = load i64, ptr %slot233, align 8
  %v1523 = load i64, ptr %slot17, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i64 %v1522, ptr %p1524, align 8, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot17, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i64, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1527, ptr %slot235, align 8
  %v1528 = load i64, ptr %slot11, align 8
  store i64 %v1528, ptr %slot236, align 8
  %v1529 = load i64, ptr %slot235, align 8
  %v1530 = load i64, ptr %slot236, align 8
  %p1531 = inttoptr i64 %v1529 to ptr
  %p1532 = inttoptr i64 %v1530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1532, ptr %p1531, i64 56, i1 false)
  %v1533 = load i64, ptr %slot9, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i32 2, ptr %p1534, align 4, !alias.scope !3, !noalias !4
  %v1535 = load i64, ptr %slot8, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i32 1, ptr %p1536, align 4, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot6, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %ld1539 = load i32, ptr %p1538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1539, ptr %slot237, align 8
  %v1540 = load i32, ptr %slot237, align 8
  %cv1541 = zext i32 %v1540 to i64
  %cond1542 = icmp ne i64 %cv1541, 0
  br i1 %cond1542, label %bb_rcslotdrop434, label %bb_rcslotdone434
bb_rcslotdrop434:
  %v1543 = load i64, ptr %slot6, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i32 0, ptr %p1544, align 4, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot10, align 8
  store i64 %v1545, ptr %slot238, align 8
  %v1546 = load i64, ptr %slot7, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %ld1548 = load i32, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1548, ptr %slot239, align 8
  %v1549 = load i32, ptr %slot239, align 8
  %op1550 = and i32 %v1549, 28
  store i32 %op1550, ptr %slot240, align 8
  %v1551 = load i32, ptr %slot240, align 8
  %cv1552 = zext i32 %v1551 to i64
  %cond1553 = icmp ne i64 %cv1552, 0
  br i1 %cond1553, label %bb_rcslotrole434, label %bb_rcslotowner434
bb_rcslotrole434:
  %v1554 = load i64, ptr %slot23, align 8
  store i64 %v1554, ptr %slot241, align 8
  %v1555 = load i64, ptr %slot241, align 8
  %v1556 = load i64, ptr %slot238, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1555, i64 %v1556) nomerge, !dbg !138
  br label %bb_rcslotdone434
bb_rcslotowner434:
  %v1557 = load i64, ptr %slot23, align 8
  store i64 %v1557, ptr %slot242, align 8
  %v1558 = load i64, ptr %slot242, align 8
  %v1559 = load i64, ptr %slot238, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1558, i64 %v1559) nomerge, !dbg !138
  br label %bb_rcslotdone434
bb_rcslotdone434:
  %v1560 = load i64, ptr %slot10, align 8
  store i64 %v1560, ptr %slot243, align 8
  %v1561 = load i64, ptr %slot11, align 8
  store i64 %v1561, ptr %slot244, align 8
  %v1562 = load i64, ptr %slot244, align 8
  %v1563 = load i64, ptr %slot243, align 8
  %p1564 = inttoptr i64 %v1562 to ptr
  %p1565 = inttoptr i64 %v1563 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1565, ptr %p1564, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot7, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i32 2, ptr %p1567, align 4, !alias.scope !3, !noalias !4
  %v1568 = load i64, ptr %slot9, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  %ld1570 = load i32, ptr %p1569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1570, ptr %slot245, align 8
  %v1571 = load i32, ptr %slot245, align 8
  %v1572 = load i64, ptr %slot7, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i32 %v1571, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot8, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 0, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot6, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i32 1, ptr %p1577, align 4, !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot243, align 8
  %v1579 = load i64, ptr %slot17, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i64 %v1578, ptr %p1580, align 8, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot17, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  %ld1583 = load i64, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1583, ptr %slot246, align 8
  %v1584 = load i64, ptr %slot17, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %ld1586 = load i64, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1586, ptr %slot247, align 8
  %v1587 = load i64, ptr %slot11, align 8
  store i64 %v1587, ptr %slot248, align 8
  %v1588 = load i64, ptr %slot24, align 8
  store i64 %v1588, ptr %slot249, align 8
  %v1589 = load i64, ptr %slot23, align 8
  %v1590 = load i64, ptr %slot248, align 8
  %v1591 = load i64, ptr %slot247, align 8
  %v1592 = load i64, ptr %slot249, align 8
  %cv1593 = trunc i64 %v1592 to i32
  %call1594 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1589, i64 %v1590, i64 %v1591, i32 %cv1593) nomerge, !dbg !140
  store i32 %call1594, ptr %slot250, align 8
  %v1595 = load i32, ptr %slot250, align 8
  %cv1596 = zext i32 %v1595 to i64
  %cond1597 = icmp ne i64 %cv1596, 0
  br i1 %cond1597, label %bb_rcsuccess454, label %bb_rcfailure454
bb_rcfailure454:
  %v1598 = load i64, ptr %slot23, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  %call1600 = call i32 @myl_rc_take_failure(ptr %p1599) nomerge, !dbg !140
  store i32 %call1600, ptr %slot251, align 8
  %v1601 = load i64, ptr %slot1, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  %v1603 = load i32, ptr %slot251, align 8
  %call1604 = call i32 @myl_qbe_rc_status(ptr %p1602, i32 %v1603) nomerge, !dbg !140
  store i32 %call1604, ptr %slot252, align 8
  br label %bb_failure
bb_rcsuccess454:
  %v1605 = load i64, ptr %slot6, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i32 0, ptr %p1606, align 4, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot9, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  store i32 2, ptr %p1608, align 4, !alias.scope !3, !noalias !4
  %v1609 = load i64, ptr %slot8, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  store i32 1, ptr %p1610, align 4, !alias.scope !3, !noalias !4
  %v1611 = load i64, ptr %slot11, align 8
  store i64 %v1611, ptr %slot253, align 8
  %v1612 = load i64, ptr %slot8, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot6, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  %ld1616 = load i32, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1616, ptr %slot254, align 8
  %v1617 = load i32, ptr %slot254, align 8
  %cv1618 = zext i32 %v1617 to i64
  %cond1619 = icmp ne i64 %cv1618, 0
  br i1 %cond1619, label %bb_rcslotdrop464, label %bb_rcslotdone464
bb_rcslotdrop464:
  %v1620 = load i64, ptr %slot6, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 0, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot10, align 8
  store i64 %v1622, ptr %slot255, align 8
  %v1623 = load i64, ptr %slot7, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i32, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1625, ptr %slot256, align 8
  %v1626 = load i32, ptr %slot256, align 8
  %op1627 = and i32 %v1626, 28
  store i32 %op1627, ptr %slot257, align 8
  %v1628 = load i32, ptr %slot257, align 8
  %cv1629 = zext i32 %v1628 to i64
  %cond1630 = icmp ne i64 %cv1629, 0
  br i1 %cond1630, label %bb_rcslotrole464, label %bb_rcslotowner464
bb_rcslotrole464:
  %v1631 = load i64, ptr %slot23, align 8
  store i64 %v1631, ptr %slot258, align 8
  %v1632 = load i64, ptr %slot258, align 8
  %v1633 = load i64, ptr %slot255, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1632, i64 %v1633) nomerge, !dbg !140
  br label %bb_rcslotdone464
bb_rcslotowner464:
  %v1634 = load i64, ptr %slot23, align 8
  store i64 %v1634, ptr %slot259, align 8
  %v1635 = load i64, ptr %slot259, align 8
  %v1636 = load i64, ptr %slot255, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1635, i64 %v1636) nomerge, !dbg !140
  br label %bb_rcslotdone464
bb_rcslotdone464:
  %v1637 = load i64, ptr %slot253, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1638, i64 56, i1 false)
  ret void
bb_i36:
  %v1639 = load i64, ptr %slot17, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  store i64 0, ptr %p1640, align 8, !alias.scope !3, !noalias !4
  %v1641 = load i64, ptr %slot17, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i64, ptr %p1642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1643, ptr %slot260, align 8
  %v1644 = load i64, ptr %slot260, align 8
  %cond1645 = icmp ne i64 %v1644, 0
  br i1 %cond1645, label %bb_success527, label %bb_failed527
bb_failed527:
  %v1646 = load i64, ptr %slot1, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  call void @myl_qbe_fail_assert(ptr %p1647) nomerge, !dbg !142
  unreachable
bb_success527:
  %v1648 = load i64, ptr %slot12, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot261, align 8
  %v1651 = load i64, ptr %slot261, align 8
  %v1652 = load i64, ptr %slot17, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  store i64 %v1651, ptr %p1653, align 8, !alias.scope !3, !noalias !4
  %v1654 = load i64, ptr %slot13, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i64, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1656, ptr %slot262, align 8
  %v1657 = load i64, ptr %slot262, align 8
  %v1658 = load i64, ptr %slot18, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i64 %v1657, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot17, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i64, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1662, ptr %slot263, align 8
  %v1663 = load i64, ptr %slot18, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %ld1665 = load i64, ptr %p1664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1665, ptr %slot264, align 8
  %v1666 = load i64, ptr %slot1, align 8
  %v1667 = load i64, ptr %slot263, align 8
  %v1668 = load i64, ptr %slot264, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult266, i64 %v1666, i64 %v1667, i64 %v1668) nomerge, !dbg !144
  %addr1669 = ptrtoint ptr %callresult266 to i64
  store i64 %addr1669, ptr %slot265, align 8
  %v1670 = load i64, ptr %slot265, align 8
  %v1671 = load i64, ptr %slot17, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i64 %v1670, ptr %p1672, align 8, !alias.scope !3, !noalias !4
  %v1673 = load i64, ptr %slot17, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  %ld1675 = load i64, ptr %p1674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1675, ptr %slot267, align 8
  %v1676 = load i64, ptr %slot11, align 8
  store i64 %v1676, ptr %slot268, align 8
  %v1677 = load i64, ptr %slot267, align 8
  %v1678 = load i64, ptr %slot268, align 8
  %p1679 = inttoptr i64 %v1677 to ptr
  %p1680 = inttoptr i64 %v1678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1680, ptr %p1679, i64 56, i1 false)
  %v1681 = load i64, ptr %slot9, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i32 2, ptr %p1682, align 4, !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot8, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  store i32 1, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  %v1685 = load i64, ptr %slot6, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %ld1687 = load i32, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1687, ptr %slot269, align 8
  %v1688 = load i32, ptr %slot269, align 8
  %cv1689 = zext i32 %v1688 to i64
  %cond1690 = icmp ne i64 %cv1689, 0
  br i1 %cond1690, label %bb_rcslotdrop539, label %bb_rcslotdone539
bb_rcslotdrop539:
  %v1691 = load i64, ptr %slot6, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i32 0, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot10, align 8
  store i64 %v1693, ptr %slot270, align 8
  %v1694 = load i64, ptr %slot7, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i32, ptr %p1695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1696, ptr %slot271, align 8
  %v1697 = load i32, ptr %slot271, align 8
  %op1698 = and i32 %v1697, 28
  store i32 %op1698, ptr %slot272, align 8
  %v1699 = load i32, ptr %slot272, align 8
  %cv1700 = zext i32 %v1699 to i64
  %cond1701 = icmp ne i64 %cv1700, 0
  br i1 %cond1701, label %bb_rcslotrole539, label %bb_rcslotowner539
bb_rcslotrole539:
  %v1702 = load i64, ptr %slot23, align 8
  store i64 %v1702, ptr %slot273, align 8
  %v1703 = load i64, ptr %slot273, align 8
  %v1704 = load i64, ptr %slot270, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1703, i64 %v1704) nomerge, !dbg !144
  br label %bb_rcslotdone539
bb_rcslotowner539:
  %v1705 = load i64, ptr %slot23, align 8
  store i64 %v1705, ptr %slot274, align 8
  %v1706 = load i64, ptr %slot274, align 8
  %v1707 = load i64, ptr %slot270, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1706, i64 %v1707) nomerge, !dbg !144
  br label %bb_rcslotdone539
bb_rcslotdone539:
  %v1708 = load i64, ptr %slot10, align 8
  store i64 %v1708, ptr %slot275, align 8
  %v1709 = load i64, ptr %slot11, align 8
  store i64 %v1709, ptr %slot276, align 8
  %v1710 = load i64, ptr %slot276, align 8
  %v1711 = load i64, ptr %slot275, align 8
  %p1712 = inttoptr i64 %v1710 to ptr
  %p1713 = inttoptr i64 %v1711 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1713, ptr %p1712, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1714 = load i64, ptr %slot7, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  store i32 2, ptr %p1715, align 4, !alias.scope !3, !noalias !4
  %v1716 = load i64, ptr %slot9, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  %ld1718 = load i32, ptr %p1717, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1718, ptr %slot277, align 8
  %v1719 = load i32, ptr %slot277, align 8
  %v1720 = load i64, ptr %slot7, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  store i32 %v1719, ptr %p1721, align 4, !alias.scope !3, !noalias !4
  %v1722 = load i64, ptr %slot8, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i32 0, ptr %p1723, align 4, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot6, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 1, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot275, align 8
  %v1727 = load i64, ptr %slot17, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i64 %v1726, ptr %p1728, align 8, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot17, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i64, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1731, ptr %slot278, align 8
  %v1732 = load i64, ptr %slot17, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  %ld1734 = load i64, ptr %p1733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1734, ptr %slot279, align 8
  %v1735 = load i64, ptr %slot11, align 8
  store i64 %v1735, ptr %slot280, align 8
  %v1736 = load i64, ptr %slot24, align 8
  store i64 %v1736, ptr %slot281, align 8
  %v1737 = load i64, ptr %slot23, align 8
  %v1738 = load i64, ptr %slot280, align 8
  %v1739 = load i64, ptr %slot279, align 8
  %v1740 = load i64, ptr %slot281, align 8
  %cv1741 = trunc i64 %v1740 to i32
  %call1742 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1737, i64 %v1738, i64 %v1739, i32 %cv1741) nomerge, !dbg !146
  store i32 %call1742, ptr %slot282, align 8
  %v1743 = load i32, ptr %slot282, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcsuccess559, label %bb_rcfailure559
bb_rcfailure559:
  %v1746 = load i64, ptr %slot23, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %call1748 = call i32 @myl_rc_take_failure(ptr %p1747) nomerge, !dbg !146
  store i32 %call1748, ptr %slot283, align 8
  %v1749 = load i64, ptr %slot1, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %v1751 = load i32, ptr %slot283, align 8
  %call1752 = call i32 @myl_qbe_rc_status(ptr %p1750, i32 %v1751) nomerge, !dbg !146
  store i32 %call1752, ptr %slot284, align 8
  br label %bb_failure
bb_rcsuccess559:
  %v1753 = load i64, ptr %slot6, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i32 0, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot9, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  store i32 2, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot8, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  store i32 1, ptr %p1758, align 4, !alias.scope !3, !noalias !4
  %v1759 = load i64, ptr %slot11, align 8
  store i64 %v1759, ptr %slot285, align 8
  %v1760 = load i64, ptr %slot8, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  store i32 0, ptr %p1761, align 4, !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot6, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %ld1764 = load i32, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1764, ptr %slot286, align 8
  %v1765 = load i32, ptr %slot286, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcslotdrop569, label %bb_rcslotdone569
bb_rcslotdrop569:
  %v1768 = load i64, ptr %slot6, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  store i32 0, ptr %p1769, align 4, !alias.scope !3, !noalias !4
  %v1770 = load i64, ptr %slot10, align 8
  store i64 %v1770, ptr %slot287, align 8
  %v1771 = load i64, ptr %slot7, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  %ld1773 = load i32, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1773, ptr %slot288, align 8
  %v1774 = load i32, ptr %slot288, align 8
  %op1775 = and i32 %v1774, 28
  store i32 %op1775, ptr %slot289, align 8
  %v1776 = load i32, ptr %slot289, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rcslotrole569, label %bb_rcslotowner569
bb_rcslotrole569:
  %v1779 = load i64, ptr %slot23, align 8
  store i64 %v1779, ptr %slot290, align 8
  %v1780 = load i64, ptr %slot290, align 8
  %v1781 = load i64, ptr %slot287, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1780, i64 %v1781) nomerge, !dbg !146
  br label %bb_rcslotdone569
bb_rcslotowner569:
  %v1782 = load i64, ptr %slot23, align 8
  store i64 %v1782, ptr %slot291, align 8
  %v1783 = load i64, ptr %slot291, align 8
  %v1784 = load i64, ptr %slot287, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1783, i64 %v1784) nomerge, !dbg !146
  br label %bb_rcslotdone569
bb_rcslotdone569:
  %v1785 = load i64, ptr %slot285, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1786, i64 56, i1 false)
  ret void
bb_i42:
  %v1787 = load i64, ptr %slot17, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i64 0, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  %v1789 = load i64, ptr %slot17, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i64, ptr %p1790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1791, ptr %slot292, align 8
  %v1792 = load i64, ptr %slot292, align 8
  %cond1793 = icmp ne i64 %v1792, 0
  br i1 %cond1793, label %bb_success632, label %bb_failed632
bb_failed632:
  %v1794 = load i64, ptr %slot1, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  call void @myl_qbe_fail_assert(ptr %p1795) nomerge, !dbg !148
  unreachable
bb_success632:
  %v1796 = load i64, ptr %slot12, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  %ld1798 = load i64, ptr %p1797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1798, ptr %slot293, align 8
  %v1799 = load i64, ptr %slot293, align 8
  %v1800 = load i64, ptr %slot17, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  store i64 %v1799, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  %v1802 = load i64, ptr %slot13, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  %ld1804 = load i64, ptr %p1803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1804, ptr %slot294, align 8
  %v1805 = load i64, ptr %slot294, align 8
  %v1806 = load i64, ptr %slot18, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i64 %v1805, ptr %p1807, align 8, !alias.scope !3, !noalias !4
  %v1808 = load i64, ptr %slot17, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %ld1810 = load i64, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1810, ptr %slot295, align 8
  %v1811 = load i64, ptr %slot18, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i64, ptr %p1812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1813, ptr %slot296, align 8
  %v1814 = load i64, ptr %slot1, align 8
  %v1815 = load i64, ptr %slot295, align 8
  %v1816 = load i64, ptr %slot296, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult298, i64 %v1814, i64 %v1815, i64 %v1816) nomerge, !dbg !150
  %addr1817 = ptrtoint ptr %callresult298 to i64
  store i64 %addr1817, ptr %slot297, align 8
  %v1818 = load i64, ptr %slot297, align 8
  %v1819 = load i64, ptr %slot17, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i64 %v1818, ptr %p1820, align 8, !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot17, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  %ld1823 = load i64, ptr %p1822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1823, ptr %slot299, align 8
  %v1824 = load i64, ptr %slot11, align 8
  store i64 %v1824, ptr %slot300, align 8
  %v1825 = load i64, ptr %slot299, align 8
  %v1826 = load i64, ptr %slot300, align 8
  %p1827 = inttoptr i64 %v1825 to ptr
  %p1828 = inttoptr i64 %v1826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1828, ptr %p1827, i64 56, i1 false)
  %v1829 = load i64, ptr %slot9, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i32 2, ptr %p1830, align 4, !alias.scope !3, !noalias !4
  %v1831 = load i64, ptr %slot8, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 1, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot6, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %ld1835 = load i32, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1835, ptr %slot301, align 8
  %v1836 = load i32, ptr %slot301, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcslotdrop644, label %bb_rcslotdone644
bb_rcslotdrop644:
  %v1839 = load i64, ptr %slot6, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i32 0, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot10, align 8
  store i64 %v1841, ptr %slot302, align 8
  %v1842 = load i64, ptr %slot7, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  %ld1844 = load i32, ptr %p1843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1844, ptr %slot303, align 8
  %v1845 = load i32, ptr %slot303, align 8
  %op1846 = and i32 %v1845, 28
  store i32 %op1846, ptr %slot304, align 8
  %v1847 = load i32, ptr %slot304, align 8
  %cv1848 = zext i32 %v1847 to i64
  %cond1849 = icmp ne i64 %cv1848, 0
  br i1 %cond1849, label %bb_rcslotrole644, label %bb_rcslotowner644
bb_rcslotrole644:
  %v1850 = load i64, ptr %slot23, align 8
  store i64 %v1850, ptr %slot305, align 8
  %v1851 = load i64, ptr %slot305, align 8
  %v1852 = load i64, ptr %slot302, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1851, i64 %v1852) nomerge, !dbg !150
  br label %bb_rcslotdone644
bb_rcslotowner644:
  %v1853 = load i64, ptr %slot23, align 8
  store i64 %v1853, ptr %slot306, align 8
  %v1854 = load i64, ptr %slot306, align 8
  %v1855 = load i64, ptr %slot302, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1854, i64 %v1855) nomerge, !dbg !150
  br label %bb_rcslotdone644
bb_rcslotdone644:
  %v1856 = load i64, ptr %slot10, align 8
  store i64 %v1856, ptr %slot307, align 8
  %v1857 = load i64, ptr %slot11, align 8
  store i64 %v1857, ptr %slot308, align 8
  %v1858 = load i64, ptr %slot308, align 8
  %v1859 = load i64, ptr %slot307, align 8
  %p1860 = inttoptr i64 %v1858 to ptr
  %p1861 = inttoptr i64 %v1859 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1861, ptr %p1860, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1862 = load i64, ptr %slot7, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i32 2, ptr %p1863, align 4, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot9, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %ld1866 = load i32, ptr %p1865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1866, ptr %slot309, align 8
  %v1867 = load i32, ptr %slot309, align 8
  %v1868 = load i64, ptr %slot7, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i32 %v1867, ptr %p1869, align 4, !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot8, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  store i32 0, ptr %p1871, align 4, !alias.scope !3, !noalias !4
  %v1872 = load i64, ptr %slot6, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  store i32 1, ptr %p1873, align 4, !alias.scope !3, !noalias !4
  %v1874 = load i64, ptr %slot307, align 8
  %v1875 = load i64, ptr %slot17, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  store i64 %v1874, ptr %p1876, align 8, !alias.scope !3, !noalias !4
  %v1877 = load i64, ptr %slot17, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %ld1879 = load i64, ptr %p1878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1879, ptr %slot310, align 8
  %v1880 = load i64, ptr %slot17, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %ld1882 = load i64, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1882, ptr %slot311, align 8
  %v1883 = load i64, ptr %slot11, align 8
  store i64 %v1883, ptr %slot312, align 8
  %v1884 = load i64, ptr %slot24, align 8
  store i64 %v1884, ptr %slot313, align 8
  %v1885 = load i64, ptr %slot23, align 8
  %v1886 = load i64, ptr %slot312, align 8
  %v1887 = load i64, ptr %slot311, align 8
  %v1888 = load i64, ptr %slot313, align 8
  %cv1889 = trunc i64 %v1888 to i32
  %call1890 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v1885, i64 %v1886, i64 %v1887, i32 %cv1889) nomerge, !dbg !152
  store i32 %call1890, ptr %slot314, align 8
  %v1891 = load i32, ptr %slot314, align 8
  %cv1892 = zext i32 %v1891 to i64
  %cond1893 = icmp ne i64 %cv1892, 0
  br i1 %cond1893, label %bb_rcsuccess664, label %bb_rcfailure664
bb_rcfailure664:
  %v1894 = load i64, ptr %slot23, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %call1896 = call i32 @myl_rc_take_failure(ptr %p1895) nomerge, !dbg !152
  store i32 %call1896, ptr %slot315, align 8
  %v1897 = load i64, ptr %slot1, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  %v1899 = load i32, ptr %slot315, align 8
  %call1900 = call i32 @myl_qbe_rc_status(ptr %p1898, i32 %v1899) nomerge, !dbg !152
  store i32 %call1900, ptr %slot316, align 8
  br label %bb_failure
bb_rcsuccess664:
  %v1901 = load i64, ptr %slot6, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i32 0, ptr %p1902, align 4, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot9, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i32 2, ptr %p1904, align 4, !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot8, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i32 1, ptr %p1906, align 4, !alias.scope !3, !noalias !4
  %v1907 = load i64, ptr %slot11, align 8
  store i64 %v1907, ptr %slot317, align 8
  %v1908 = load i64, ptr %slot8, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i32 0, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot6, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i32, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1912, ptr %slot318, align 8
  %v1913 = load i32, ptr %slot318, align 8
  %cv1914 = zext i32 %v1913 to i64
  %cond1915 = icmp ne i64 %cv1914, 0
  br i1 %cond1915, label %bb_rcslotdrop674, label %bb_rcslotdone674
bb_rcslotdrop674:
  %v1916 = load i64, ptr %slot6, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i32 0, ptr %p1917, align 4, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot10, align 8
  store i64 %v1918, ptr %slot319, align 8
  %v1919 = load i64, ptr %slot7, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i32, ptr %p1920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1921, ptr %slot320, align 8
  %v1922 = load i32, ptr %slot320, align 8
  %op1923 = and i32 %v1922, 28
  store i32 %op1923, ptr %slot321, align 8
  %v1924 = load i32, ptr %slot321, align 8
  %cv1925 = zext i32 %v1924 to i64
  %cond1926 = icmp ne i64 %cv1925, 0
  br i1 %cond1926, label %bb_rcslotrole674, label %bb_rcslotowner674
bb_rcslotrole674:
  %v1927 = load i64, ptr %slot23, align 8
  store i64 %v1927, ptr %slot322, align 8
  %v1928 = load i64, ptr %slot322, align 8
  %v1929 = load i64, ptr %slot319, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v1928, i64 %v1929) nomerge, !dbg !152
  br label %bb_rcslotdone674
bb_rcslotowner674:
  %v1930 = load i64, ptr %slot23, align 8
  store i64 %v1930, ptr %slot323, align 8
  %v1931 = load i64, ptr %slot323, align 8
  %v1932 = load i64, ptr %slot319, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v1931, i64 %v1932) nomerge, !dbg !152
  br label %bb_rcslotdone674
bb_rcslotdone674:
  %v1933 = load i64, ptr %slot317, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1934, i64 56, i1 false)
  ret void
bb_i48:
  %v1935 = load i64, ptr %slot17, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i64 0, ptr %p1936, align 8, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot17, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i64, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1939, ptr %slot324, align 8
  %v1940 = load i64, ptr %slot324, align 8
  %cond1941 = icmp ne i64 %v1940, 0
  br i1 %cond1941, label %bb_success737, label %bb_failed737
bb_failed737:
  %v1942 = load i64, ptr %slot1, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  call void @myl_qbe_fail_assert(ptr %p1943) nomerge, !dbg !154
  unreachable
bb_success737:
  %v1944 = load i64, ptr %slot12, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %ld1946 = load i64, ptr %p1945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1946, ptr %slot325, align 8
  %v1947 = load i64, ptr %slot325, align 8
  %v1948 = load i64, ptr %slot17, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i64 %v1947, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot13, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %ld1952 = load i64, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1952, ptr %slot326, align 8
  %v1953 = load i64, ptr %slot326, align 8
  %v1954 = load i64, ptr %slot18, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i64 %v1953, ptr %p1955, align 8, !alias.scope !3, !noalias !4
  %v1956 = load i64, ptr %slot17, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  %ld1958 = load i64, ptr %p1957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1958, ptr %slot327, align 8
  %v1959 = load i64, ptr %slot18, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i64, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1961, ptr %slot328, align 8
  %v1962 = load i64, ptr %slot1, align 8
  %v1963 = load i64, ptr %slot327, align 8
  %v1964 = load i64, ptr %slot328, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult330, i64 %v1962, i64 %v1963, i64 %v1964) nomerge, !dbg !156
  %addr1965 = ptrtoint ptr %callresult330 to i64
  store i64 %addr1965, ptr %slot329, align 8
  %v1966 = load i64, ptr %slot329, align 8
  %v1967 = load i64, ptr %slot17, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  store i64 %v1966, ptr %p1968, align 8, !alias.scope !3, !noalias !4
  %v1969 = load i64, ptr %slot17, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  %ld1971 = load i64, ptr %p1970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1971, ptr %slot331, align 8
  %v1972 = load i64, ptr %slot11, align 8
  store i64 %v1972, ptr %slot332, align 8
  %v1973 = load i64, ptr %slot331, align 8
  %v1974 = load i64, ptr %slot332, align 8
  %p1975 = inttoptr i64 %v1973 to ptr
  %p1976 = inttoptr i64 %v1974 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1976, ptr %p1975, i64 56, i1 false)
  %v1977 = load i64, ptr %slot9, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  store i32 2, ptr %p1978, align 4, !alias.scope !3, !noalias !4
  %v1979 = load i64, ptr %slot8, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  store i32 1, ptr %p1980, align 4, !alias.scope !3, !noalias !4
  %v1981 = load i64, ptr %slot6, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %ld1983 = load i32, ptr %p1982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1983, ptr %slot333, align 8
  %v1984 = load i32, ptr %slot333, align 8
  %cv1985 = zext i32 %v1984 to i64
  %cond1986 = icmp ne i64 %cv1985, 0
  br i1 %cond1986, label %bb_rcslotdrop749, label %bb_rcslotdone749
bb_rcslotdrop749:
  %v1987 = load i64, ptr %slot6, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 0, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot10, align 8
  store i64 %v1989, ptr %slot334, align 8
  %v1990 = load i64, ptr %slot7, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  %ld1992 = load i32, ptr %p1991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1992, ptr %slot335, align 8
  %v1993 = load i32, ptr %slot335, align 8
  %op1994 = and i32 %v1993, 28
  store i32 %op1994, ptr %slot336, align 8
  %v1995 = load i32, ptr %slot336, align 8
  %cv1996 = zext i32 %v1995 to i64
  %cond1997 = icmp ne i64 %cv1996, 0
  br i1 %cond1997, label %bb_rcslotrole749, label %bb_rcslotowner749
bb_rcslotrole749:
  %v1998 = load i64, ptr %slot23, align 8
  store i64 %v1998, ptr %slot337, align 8
  %v1999 = load i64, ptr %slot337, align 8
  %v2000 = load i64, ptr %slot334, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1999, i64 %v2000) nomerge, !dbg !156
  br label %bb_rcslotdone749
bb_rcslotowner749:
  %v2001 = load i64, ptr %slot23, align 8
  store i64 %v2001, ptr %slot338, align 8
  %v2002 = load i64, ptr %slot338, align 8
  %v2003 = load i64, ptr %slot334, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2002, i64 %v2003) nomerge, !dbg !156
  br label %bb_rcslotdone749
bb_rcslotdone749:
  %v2004 = load i64, ptr %slot10, align 8
  store i64 %v2004, ptr %slot339, align 8
  %v2005 = load i64, ptr %slot11, align 8
  store i64 %v2005, ptr %slot340, align 8
  %v2006 = load i64, ptr %slot340, align 8
  %v2007 = load i64, ptr %slot339, align 8
  %p2008 = inttoptr i64 %v2006 to ptr
  %p2009 = inttoptr i64 %v2007 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2009, ptr %p2008, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2010 = load i64, ptr %slot7, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  store i32 2, ptr %p2011, align 4, !alias.scope !3, !noalias !4
  %v2012 = load i64, ptr %slot9, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %ld2014 = load i32, ptr %p2013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2014, ptr %slot341, align 8
  %v2015 = load i32, ptr %slot341, align 8
  %v2016 = load i64, ptr %slot7, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  store i32 %v2015, ptr %p2017, align 4, !alias.scope !3, !noalias !4
  %v2018 = load i64, ptr %slot8, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i32 0, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot6, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  store i32 1, ptr %p2021, align 4, !alias.scope !3, !noalias !4
  %v2022 = load i64, ptr %slot339, align 8
  %v2023 = load i64, ptr %slot17, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 %v2022, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot17, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i64, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2027, ptr %slot342, align 8
  %v2028 = load i64, ptr %slot17, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %ld2030 = load i64, ptr %p2029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2030, ptr %slot343, align 8
  %v2031 = load i64, ptr %slot11, align 8
  store i64 %v2031, ptr %slot344, align 8
  %v2032 = load i64, ptr %slot24, align 8
  store i64 %v2032, ptr %slot345, align 8
  %v2033 = load i64, ptr %slot23, align 8
  %v2034 = load i64, ptr %slot344, align 8
  %v2035 = load i64, ptr %slot343, align 8
  %v2036 = load i64, ptr %slot345, align 8
  %cv2037 = trunc i64 %v2036 to i32
  %call2038 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2033, i64 %v2034, i64 %v2035, i32 %cv2037) nomerge, !dbg !158
  store i32 %call2038, ptr %slot346, align 8
  %v2039 = load i32, ptr %slot346, align 8
  %cv2040 = zext i32 %v2039 to i64
  %cond2041 = icmp ne i64 %cv2040, 0
  br i1 %cond2041, label %bb_rcsuccess769, label %bb_rcfailure769
bb_rcfailure769:
  %v2042 = load i64, ptr %slot23, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %call2044 = call i32 @myl_rc_take_failure(ptr %p2043) nomerge, !dbg !158
  store i32 %call2044, ptr %slot347, align 8
  %v2045 = load i64, ptr %slot1, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  %v2047 = load i32, ptr %slot347, align 8
  %call2048 = call i32 @myl_qbe_rc_status(ptr %p2046, i32 %v2047) nomerge, !dbg !158
  store i32 %call2048, ptr %slot348, align 8
  br label %bb_failure
bb_rcsuccess769:
  %v2049 = load i64, ptr %slot6, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i32 0, ptr %p2050, align 4, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot9, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  store i32 2, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  %v2053 = load i64, ptr %slot8, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i32 1, ptr %p2054, align 4, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot11, align 8
  store i64 %v2055, ptr %slot349, align 8
  %v2056 = load i64, ptr %slot8, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i32 0, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  %v2058 = load i64, ptr %slot6, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i32, ptr %p2059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2060, ptr %slot350, align 8
  %v2061 = load i32, ptr %slot350, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcslotdrop779, label %bb_rcslotdone779
bb_rcslotdrop779:
  %v2064 = load i64, ptr %slot6, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  store i32 0, ptr %p2065, align 4, !alias.scope !3, !noalias !4
  %v2066 = load i64, ptr %slot10, align 8
  store i64 %v2066, ptr %slot351, align 8
  %v2067 = load i64, ptr %slot7, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i32, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2069, ptr %slot352, align 8
  %v2070 = load i32, ptr %slot352, align 8
  %op2071 = and i32 %v2070, 28
  store i32 %op2071, ptr %slot353, align 8
  %v2072 = load i32, ptr %slot353, align 8
  %cv2073 = zext i32 %v2072 to i64
  %cond2074 = icmp ne i64 %cv2073, 0
  br i1 %cond2074, label %bb_rcslotrole779, label %bb_rcslotowner779
bb_rcslotrole779:
  %v2075 = load i64, ptr %slot23, align 8
  store i64 %v2075, ptr %slot354, align 8
  %v2076 = load i64, ptr %slot354, align 8
  %v2077 = load i64, ptr %slot351, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2076, i64 %v2077) nomerge, !dbg !158
  br label %bb_rcslotdone779
bb_rcslotowner779:
  %v2078 = load i64, ptr %slot23, align 8
  store i64 %v2078, ptr %slot355, align 8
  %v2079 = load i64, ptr %slot355, align 8
  %v2080 = load i64, ptr %slot351, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2079, i64 %v2080) nomerge, !dbg !158
  br label %bb_rcslotdone779
bb_rcslotdone779:
  %v2081 = load i64, ptr %slot349, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2082, i64 56, i1 false)
  ret void
bb_i54:
  %v2083 = load i64, ptr %slot17, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i64 0, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot17, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i64, ptr %p2086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2087, ptr %slot356, align 8
  %v2088 = load i64, ptr %slot356, align 8
  %cond2089 = icmp ne i64 %v2088, 0
  br i1 %cond2089, label %bb_success842, label %bb_failed842
bb_failed842:
  %v2090 = load i64, ptr %slot1, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  call void @myl_qbe_fail_assert(ptr %p2091) nomerge, !dbg !160
  unreachable
bb_success842:
  %v2092 = load i64, ptr %slot12, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %ld2094 = load i64, ptr %p2093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2094, ptr %slot357, align 8
  %v2095 = load i64, ptr %slot357, align 8
  %v2096 = load i64, ptr %slot17, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i64 %v2095, ptr %p2097, align 8, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot13, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i64, ptr %p2099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2100, ptr %slot358, align 8
  %v2101 = load i64, ptr %slot358, align 8
  %v2102 = load i64, ptr %slot18, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i64 %v2101, ptr %p2103, align 8, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot17, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i64, ptr %p2105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2106, ptr %slot359, align 8
  %v2107 = load i64, ptr %slot18, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i64, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2109, ptr %slot360, align 8
  %v2110 = load i64, ptr %slot1, align 8
  %v2111 = load i64, ptr %slot359, align 8
  %v2112 = load i64, ptr %slot360, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult362, i64 %v2110, i64 %v2111, i64 %v2112) nomerge, !dbg !162
  %addr2113 = ptrtoint ptr %callresult362 to i64
  store i64 %addr2113, ptr %slot361, align 8
  %v2114 = load i64, ptr %slot361, align 8
  %v2115 = load i64, ptr %slot17, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 %v2114, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot17, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i64, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2119, ptr %slot363, align 8
  %v2120 = load i64, ptr %slot11, align 8
  store i64 %v2120, ptr %slot364, align 8
  %v2121 = load i64, ptr %slot363, align 8
  %v2122 = load i64, ptr %slot364, align 8
  %p2123 = inttoptr i64 %v2121 to ptr
  %p2124 = inttoptr i64 %v2122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2124, ptr %p2123, i64 56, i1 false)
  %v2125 = load i64, ptr %slot9, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  store i32 2, ptr %p2126, align 4, !alias.scope !3, !noalias !4
  %v2127 = load i64, ptr %slot8, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  store i32 1, ptr %p2128, align 4, !alias.scope !3, !noalias !4
  %v2129 = load i64, ptr %slot6, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %ld2131 = load i32, ptr %p2130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2131, ptr %slot365, align 8
  %v2132 = load i32, ptr %slot365, align 8
  %cv2133 = zext i32 %v2132 to i64
  %cond2134 = icmp ne i64 %cv2133, 0
  br i1 %cond2134, label %bb_rcslotdrop854, label %bb_rcslotdone854
bb_rcslotdrop854:
  %v2135 = load i64, ptr %slot6, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i32 0, ptr %p2136, align 4, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot10, align 8
  store i64 %v2137, ptr %slot366, align 8
  %v2138 = load i64, ptr %slot7, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i32, ptr %p2139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2140, ptr %slot367, align 8
  %v2141 = load i32, ptr %slot367, align 8
  %op2142 = and i32 %v2141, 28
  store i32 %op2142, ptr %slot368, align 8
  %v2143 = load i32, ptr %slot368, align 8
  %cv2144 = zext i32 %v2143 to i64
  %cond2145 = icmp ne i64 %cv2144, 0
  br i1 %cond2145, label %bb_rcslotrole854, label %bb_rcslotowner854
bb_rcslotrole854:
  %v2146 = load i64, ptr %slot23, align 8
  store i64 %v2146, ptr %slot369, align 8
  %v2147 = load i64, ptr %slot369, align 8
  %v2148 = load i64, ptr %slot366, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2147, i64 %v2148) nomerge, !dbg !162
  br label %bb_rcslotdone854
bb_rcslotowner854:
  %v2149 = load i64, ptr %slot23, align 8
  store i64 %v2149, ptr %slot370, align 8
  %v2150 = load i64, ptr %slot370, align 8
  %v2151 = load i64, ptr %slot366, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2150, i64 %v2151) nomerge, !dbg !162
  br label %bb_rcslotdone854
bb_rcslotdone854:
  %v2152 = load i64, ptr %slot10, align 8
  store i64 %v2152, ptr %slot371, align 8
  %v2153 = load i64, ptr %slot11, align 8
  store i64 %v2153, ptr %slot372, align 8
  %v2154 = load i64, ptr %slot372, align 8
  %v2155 = load i64, ptr %slot371, align 8
  %p2156 = inttoptr i64 %v2154 to ptr
  %p2157 = inttoptr i64 %v2155 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2157, ptr %p2156, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2158 = load i64, ptr %slot7, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  store i32 2, ptr %p2159, align 4, !alias.scope !3, !noalias !4
  %v2160 = load i64, ptr %slot9, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  %ld2162 = load i32, ptr %p2161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2162, ptr %slot373, align 8
  %v2163 = load i32, ptr %slot373, align 8
  %v2164 = load i64, ptr %slot7, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 %v2163, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot8, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i32 0, ptr %p2167, align 4, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot6, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  store i32 1, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  %v2170 = load i64, ptr %slot371, align 8
  %v2171 = load i64, ptr %slot17, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  store i64 %v2170, ptr %p2172, align 8, !alias.scope !3, !noalias !4
  %v2173 = load i64, ptr %slot17, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %ld2175 = load i64, ptr %p2174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2175, ptr %slot374, align 8
  %v2176 = load i64, ptr %slot17, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2178, ptr %slot375, align 8
  %v2179 = load i64, ptr %slot11, align 8
  store i64 %v2179, ptr %slot376, align 8
  %v2180 = load i64, ptr %slot24, align 8
  store i64 %v2180, ptr %slot377, align 8
  %v2181 = load i64, ptr %slot23, align 8
  %v2182 = load i64, ptr %slot376, align 8
  %v2183 = load i64, ptr %slot375, align 8
  %v2184 = load i64, ptr %slot377, align 8
  %cv2185 = trunc i64 %v2184 to i32
  %call2186 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2181, i64 %v2182, i64 %v2183, i32 %cv2185) nomerge, !dbg !164
  store i32 %call2186, ptr %slot378, align 8
  %v2187 = load i32, ptr %slot378, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcsuccess874, label %bb_rcfailure874
bb_rcfailure874:
  %v2190 = load i64, ptr %slot23, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  %call2192 = call i32 @myl_rc_take_failure(ptr %p2191) nomerge, !dbg !164
  store i32 %call2192, ptr %slot379, align 8
  %v2193 = load i64, ptr %slot1, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %v2195 = load i32, ptr %slot379, align 8
  %call2196 = call i32 @myl_qbe_rc_status(ptr %p2194, i32 %v2195) nomerge, !dbg !164
  store i32 %call2196, ptr %slot380, align 8
  br label %bb_failure
bb_rcsuccess874:
  %v2197 = load i64, ptr %slot6, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  store i32 0, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  %v2199 = load i64, ptr %slot9, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  store i32 2, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  %v2201 = load i64, ptr %slot8, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i32 1, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot11, align 8
  store i64 %v2203, ptr %slot381, align 8
  %v2204 = load i64, ptr %slot8, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  store i32 0, ptr %p2205, align 4, !alias.scope !3, !noalias !4
  %v2206 = load i64, ptr %slot6, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  %ld2208 = load i32, ptr %p2207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2208, ptr %slot382, align 8
  %v2209 = load i32, ptr %slot382, align 8
  %cv2210 = zext i32 %v2209 to i64
  %cond2211 = icmp ne i64 %cv2210, 0
  br i1 %cond2211, label %bb_rcslotdrop884, label %bb_rcslotdone884
bb_rcslotdrop884:
  %v2212 = load i64, ptr %slot6, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  store i32 0, ptr %p2213, align 4, !alias.scope !3, !noalias !4
  %v2214 = load i64, ptr %slot10, align 8
  store i64 %v2214, ptr %slot383, align 8
  %v2215 = load i64, ptr %slot7, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  %ld2217 = load i32, ptr %p2216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2217, ptr %slot384, align 8
  %v2218 = load i32, ptr %slot384, align 8
  %op2219 = and i32 %v2218, 28
  store i32 %op2219, ptr %slot385, align 8
  %v2220 = load i32, ptr %slot385, align 8
  %cv2221 = zext i32 %v2220 to i64
  %cond2222 = icmp ne i64 %cv2221, 0
  br i1 %cond2222, label %bb_rcslotrole884, label %bb_rcslotowner884
bb_rcslotrole884:
  %v2223 = load i64, ptr %slot23, align 8
  store i64 %v2223, ptr %slot386, align 8
  %v2224 = load i64, ptr %slot386, align 8
  %v2225 = load i64, ptr %slot383, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2224, i64 %v2225) nomerge, !dbg !164
  br label %bb_rcslotdone884
bb_rcslotowner884:
  %v2226 = load i64, ptr %slot23, align 8
  store i64 %v2226, ptr %slot387, align 8
  %v2227 = load i64, ptr %slot387, align 8
  %v2228 = load i64, ptr %slot383, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2227, i64 %v2228) nomerge, !dbg !164
  br label %bb_rcslotdone884
bb_rcslotdone884:
  %v2229 = load i64, ptr %slot381, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2230, i64 56, i1 false)
  ret void
bb_i60:
  %v2231 = load i64, ptr %slot17, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  store i64 0, ptr %p2232, align 8, !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot17, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i64, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2235, ptr %slot388, align 8
  %v2236 = load i64, ptr %slot388, align 8
  %cond2237 = icmp ne i64 %v2236, 0
  br i1 %cond2237, label %bb_success947, label %bb_failed947
bb_failed947:
  %v2238 = load i64, ptr %slot1, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  call void @myl_qbe_fail_assert(ptr %p2239) nomerge, !dbg !166
  unreachable
bb_success947:
  %v2240 = load i64, ptr %slot12, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  %ld2242 = load i64, ptr %p2241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2242, ptr %slot389, align 8
  %v2243 = load i64, ptr %slot389, align 8
  %v2244 = load i64, ptr %slot17, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  store i64 %v2243, ptr %p2245, align 8, !alias.scope !3, !noalias !4
  %v2246 = load i64, ptr %slot13, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %ld2248 = load i64, ptr %p2247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2248, ptr %slot390, align 8
  %v2249 = load i64, ptr %slot390, align 8
  %v2250 = load i64, ptr %slot18, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i64 %v2249, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot17, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %ld2254 = load i64, ptr %p2253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2254, ptr %slot391, align 8
  %v2255 = load i64, ptr %slot18, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %ld2257 = load i64, ptr %p2256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2257, ptr %slot392, align 8
  %v2258 = load i64, ptr %slot1, align 8
  %v2259 = load i64, ptr %slot391, align 8
  %v2260 = load i64, ptr %slot392, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult394, i64 %v2258, i64 %v2259, i64 %v2260) nomerge, !dbg !168
  %addr2261 = ptrtoint ptr %callresult394 to i64
  store i64 %addr2261, ptr %slot393, align 8
  %v2262 = load i64, ptr %slot393, align 8
  %v2263 = load i64, ptr %slot17, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 %v2262, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot17, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot395, align 8
  %v2268 = load i64, ptr %slot11, align 8
  store i64 %v2268, ptr %slot396, align 8
  %v2269 = load i64, ptr %slot395, align 8
  %v2270 = load i64, ptr %slot396, align 8
  %p2271 = inttoptr i64 %v2269 to ptr
  %p2272 = inttoptr i64 %v2270 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2272, ptr %p2271, i64 56, i1 false)
  %v2273 = load i64, ptr %slot9, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  store i32 2, ptr %p2274, align 4, !alias.scope !3, !noalias !4
  %v2275 = load i64, ptr %slot8, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  store i32 1, ptr %p2276, align 4, !alias.scope !3, !noalias !4
  %v2277 = load i64, ptr %slot6, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i32, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2279, ptr %slot397, align 8
  %v2280 = load i32, ptr %slot397, align 8
  %cv2281 = zext i32 %v2280 to i64
  %cond2282 = icmp ne i64 %cv2281, 0
  br i1 %cond2282, label %bb_rcslotdrop959, label %bb_rcslotdone959
bb_rcslotdrop959:
  %v2283 = load i64, ptr %slot6, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i32 0, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot10, align 8
  store i64 %v2285, ptr %slot398, align 8
  %v2286 = load i64, ptr %slot7, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i32, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2288, ptr %slot399, align 8
  %v2289 = load i32, ptr %slot399, align 8
  %op2290 = and i32 %v2289, 28
  store i32 %op2290, ptr %slot400, align 8
  %v2291 = load i32, ptr %slot400, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcslotrole959, label %bb_rcslotowner959
bb_rcslotrole959:
  %v2294 = load i64, ptr %slot23, align 8
  store i64 %v2294, ptr %slot401, align 8
  %v2295 = load i64, ptr %slot401, align 8
  %v2296 = load i64, ptr %slot398, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2295, i64 %v2296) nomerge, !dbg !168
  br label %bb_rcslotdone959
bb_rcslotowner959:
  %v2297 = load i64, ptr %slot23, align 8
  store i64 %v2297, ptr %slot402, align 8
  %v2298 = load i64, ptr %slot402, align 8
  %v2299 = load i64, ptr %slot398, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2298, i64 %v2299) nomerge, !dbg !168
  br label %bb_rcslotdone959
bb_rcslotdone959:
  %v2300 = load i64, ptr %slot10, align 8
  store i64 %v2300, ptr %slot403, align 8
  %v2301 = load i64, ptr %slot11, align 8
  store i64 %v2301, ptr %slot404, align 8
  %v2302 = load i64, ptr %slot404, align 8
  %v2303 = load i64, ptr %slot403, align 8
  %p2304 = inttoptr i64 %v2302 to ptr
  %p2305 = inttoptr i64 %v2303 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2305, ptr %p2304, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2306 = load i64, ptr %slot7, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  store i32 2, ptr %p2307, align 4, !alias.scope !3, !noalias !4
  %v2308 = load i64, ptr %slot9, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i32, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2310, ptr %slot405, align 8
  %v2311 = load i32, ptr %slot405, align 8
  %v2312 = load i64, ptr %slot7, align 8
  %p2313 = inttoptr i64 %v2312 to ptr
  store i32 %v2311, ptr %p2313, align 4, !alias.scope !3, !noalias !4
  %v2314 = load i64, ptr %slot8, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 0, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot6, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  store i32 1, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  %v2318 = load i64, ptr %slot403, align 8
  %v2319 = load i64, ptr %slot17, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  store i64 %v2318, ptr %p2320, align 8, !alias.scope !3, !noalias !4
  %v2321 = load i64, ptr %slot17, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  %ld2323 = load i64, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2323, ptr %slot406, align 8
  %v2324 = load i64, ptr %slot17, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i64, ptr %p2325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2326, ptr %slot407, align 8
  %v2327 = load i64, ptr %slot11, align 8
  store i64 %v2327, ptr %slot408, align 8
  %v2328 = load i64, ptr %slot24, align 8
  store i64 %v2328, ptr %slot409, align 8
  %v2329 = load i64, ptr %slot23, align 8
  %v2330 = load i64, ptr %slot408, align 8
  %v2331 = load i64, ptr %slot407, align 8
  %v2332 = load i64, ptr %slot409, align 8
  %cv2333 = trunc i64 %v2332 to i32
  %call2334 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2329, i64 %v2330, i64 %v2331, i32 %cv2333) nomerge, !dbg !170
  store i32 %call2334, ptr %slot410, align 8
  %v2335 = load i32, ptr %slot410, align 8
  %cv2336 = zext i32 %v2335 to i64
  %cond2337 = icmp ne i64 %cv2336, 0
  br i1 %cond2337, label %bb_rcsuccess979, label %bb_rcfailure979
bb_rcfailure979:
  %v2338 = load i64, ptr %slot23, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %call2340 = call i32 @myl_rc_take_failure(ptr %p2339) nomerge, !dbg !170
  store i32 %call2340, ptr %slot411, align 8
  %v2341 = load i64, ptr %slot1, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %v2343 = load i32, ptr %slot411, align 8
  %call2344 = call i32 @myl_qbe_rc_status(ptr %p2342, i32 %v2343) nomerge, !dbg !170
  store i32 %call2344, ptr %slot412, align 8
  br label %bb_failure
bb_rcsuccess979:
  %v2345 = load i64, ptr %slot6, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  store i32 0, ptr %p2346, align 4, !alias.scope !3, !noalias !4
  %v2347 = load i64, ptr %slot9, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  store i32 2, ptr %p2348, align 4, !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot8, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i32 1, ptr %p2350, align 4, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot11, align 8
  store i64 %v2351, ptr %slot413, align 8
  %v2352 = load i64, ptr %slot8, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  store i32 0, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot6, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %ld2356 = load i32, ptr %p2355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2356, ptr %slot414, align 8
  %v2357 = load i32, ptr %slot414, align 8
  %cv2358 = zext i32 %v2357 to i64
  %cond2359 = icmp ne i64 %cv2358, 0
  br i1 %cond2359, label %bb_rcslotdrop989, label %bb_rcslotdone989
bb_rcslotdrop989:
  %v2360 = load i64, ptr %slot6, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  store i32 0, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  %v2362 = load i64, ptr %slot10, align 8
  store i64 %v2362, ptr %slot415, align 8
  %v2363 = load i64, ptr %slot7, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i32, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2365, ptr %slot416, align 8
  %v2366 = load i32, ptr %slot416, align 8
  %op2367 = and i32 %v2366, 28
  store i32 %op2367, ptr %slot417, align 8
  %v2368 = load i32, ptr %slot417, align 8
  %cv2369 = zext i32 %v2368 to i64
  %cond2370 = icmp ne i64 %cv2369, 0
  br i1 %cond2370, label %bb_rcslotrole989, label %bb_rcslotowner989
bb_rcslotrole989:
  %v2371 = load i64, ptr %slot23, align 8
  store i64 %v2371, ptr %slot418, align 8
  %v2372 = load i64, ptr %slot418, align 8
  %v2373 = load i64, ptr %slot415, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2372, i64 %v2373) nomerge, !dbg !170
  br label %bb_rcslotdone989
bb_rcslotowner989:
  %v2374 = load i64, ptr %slot23, align 8
  store i64 %v2374, ptr %slot419, align 8
  %v2375 = load i64, ptr %slot419, align 8
  %v2376 = load i64, ptr %slot415, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2375, i64 %v2376) nomerge, !dbg !170
  br label %bb_rcslotdone989
bb_rcslotdone989:
  %v2377 = load i64, ptr %slot413, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2378, i64 56, i1 false)
  ret void
bb_i66:
  %v2379 = load i64, ptr %slot17, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i64 0, ptr %p2380, align 8, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot17, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i64, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2383, ptr %slot420, align 8
  %v2384 = load i64, ptr %slot420, align 8
  %cond2385 = icmp ne i64 %v2384, 0
  br i1 %cond2385, label %bb_success1052, label %bb_failed1052
bb_failed1052:
  %v2386 = load i64, ptr %slot1, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  call void @myl_qbe_fail_assert(ptr %p2387) nomerge, !dbg !172
  unreachable
bb_success1052:
  %v2388 = load i64, ptr %slot12, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  %ld2390 = load i64, ptr %p2389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2390, ptr %slot421, align 8
  %v2391 = load i64, ptr %slot421, align 8
  %v2392 = load i64, ptr %slot17, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i64 %v2391, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot13, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2396, ptr %slot422, align 8
  %v2397 = load i64, ptr %slot422, align 8
  %v2398 = load i64, ptr %slot18, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot17, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot423, align 8
  %v2403 = load i64, ptr %slot18, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %ld2405 = load i64, ptr %p2404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2405, ptr %slot424, align 8
  %v2406 = load i64, ptr %slot1, align 8
  %v2407 = load i64, ptr %slot423, align 8
  %v2408 = load i64, ptr %slot424, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult426, i64 %v2406, i64 %v2407, i64 %v2408) nomerge, !dbg !174
  %addr2409 = ptrtoint ptr %callresult426 to i64
  store i64 %addr2409, ptr %slot425, align 8
  %v2410 = load i64, ptr %slot425, align 8
  %v2411 = load i64, ptr %slot17, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  store i64 %v2410, ptr %p2412, align 8, !alias.scope !3, !noalias !4
  %v2413 = load i64, ptr %slot17, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  %ld2415 = load i64, ptr %p2414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2415, ptr %slot427, align 8
  %v2416 = load i64, ptr %slot11, align 8
  store i64 %v2416, ptr %slot428, align 8
  %v2417 = load i64, ptr %slot427, align 8
  %v2418 = load i64, ptr %slot428, align 8
  %p2419 = inttoptr i64 %v2417 to ptr
  %p2420 = inttoptr i64 %v2418 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2420, ptr %p2419, i64 56, i1 false)
  %v2421 = load i64, ptr %slot9, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i32 2, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  %v2423 = load i64, ptr %slot8, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  store i32 1, ptr %p2424, align 4, !alias.scope !3, !noalias !4
  %v2425 = load i64, ptr %slot6, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %ld2427 = load i32, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2427, ptr %slot429, align 8
  %v2428 = load i32, ptr %slot429, align 8
  %cv2429 = zext i32 %v2428 to i64
  %cond2430 = icmp ne i64 %cv2429, 0
  br i1 %cond2430, label %bb_rcslotdrop1064, label %bb_rcslotdone1064
bb_rcslotdrop1064:
  %v2431 = load i64, ptr %slot6, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  store i32 0, ptr %p2432, align 4, !alias.scope !3, !noalias !4
  %v2433 = load i64, ptr %slot10, align 8
  store i64 %v2433, ptr %slot430, align 8
  %v2434 = load i64, ptr %slot7, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %ld2436 = load i32, ptr %p2435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2436, ptr %slot431, align 8
  %v2437 = load i32, ptr %slot431, align 8
  %op2438 = and i32 %v2437, 28
  store i32 %op2438, ptr %slot432, align 8
  %v2439 = load i32, ptr %slot432, align 8
  %cv2440 = zext i32 %v2439 to i64
  %cond2441 = icmp ne i64 %cv2440, 0
  br i1 %cond2441, label %bb_rcslotrole1064, label %bb_rcslotowner1064
bb_rcslotrole1064:
  %v2442 = load i64, ptr %slot23, align 8
  store i64 %v2442, ptr %slot433, align 8
  %v2443 = load i64, ptr %slot433, align 8
  %v2444 = load i64, ptr %slot430, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2443, i64 %v2444) nomerge, !dbg !174
  br label %bb_rcslotdone1064
bb_rcslotowner1064:
  %v2445 = load i64, ptr %slot23, align 8
  store i64 %v2445, ptr %slot434, align 8
  %v2446 = load i64, ptr %slot434, align 8
  %v2447 = load i64, ptr %slot430, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2446, i64 %v2447) nomerge, !dbg !174
  br label %bb_rcslotdone1064
bb_rcslotdone1064:
  %v2448 = load i64, ptr %slot10, align 8
  store i64 %v2448, ptr %slot435, align 8
  %v2449 = load i64, ptr %slot11, align 8
  store i64 %v2449, ptr %slot436, align 8
  %v2450 = load i64, ptr %slot436, align 8
  %v2451 = load i64, ptr %slot435, align 8
  %p2452 = inttoptr i64 %v2450 to ptr
  %p2453 = inttoptr i64 %v2451 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2453, ptr %p2452, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2454 = load i64, ptr %slot7, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i32 2, ptr %p2455, align 4, !alias.scope !3, !noalias !4
  %v2456 = load i64, ptr %slot9, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i32, ptr %p2457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2458, ptr %slot437, align 8
  %v2459 = load i32, ptr %slot437, align 8
  %v2460 = load i64, ptr %slot7, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i32 %v2459, ptr %p2461, align 4, !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot8, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  store i32 0, ptr %p2463, align 4, !alias.scope !3, !noalias !4
  %v2464 = load i64, ptr %slot6, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  store i32 1, ptr %p2465, align 4, !alias.scope !3, !noalias !4
  %v2466 = load i64, ptr %slot435, align 8
  %v2467 = load i64, ptr %slot17, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  store i64 %v2466, ptr %p2468, align 8, !alias.scope !3, !noalias !4
  %v2469 = load i64, ptr %slot17, align 8
  %p2470 = inttoptr i64 %v2469 to ptr
  %ld2471 = load i64, ptr %p2470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2471, ptr %slot438, align 8
  %v2472 = load i64, ptr %slot17, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  %ld2474 = load i64, ptr %p2473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2474, ptr %slot439, align 8
  %v2475 = load i64, ptr %slot11, align 8
  store i64 %v2475, ptr %slot440, align 8
  %v2476 = load i64, ptr %slot24, align 8
  store i64 %v2476, ptr %slot441, align 8
  %v2477 = load i64, ptr %slot23, align 8
  %v2478 = load i64, ptr %slot440, align 8
  %v2479 = load i64, ptr %slot439, align 8
  %v2480 = load i64, ptr %slot441, align 8
  %cv2481 = trunc i64 %v2480 to i32
  %call2482 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2477, i64 %v2478, i64 %v2479, i32 %cv2481) nomerge, !dbg !176
  store i32 %call2482, ptr %slot442, align 8
  %v2483 = load i32, ptr %slot442, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcsuccess1084, label %bb_rcfailure1084
bb_rcfailure1084:
  %v2486 = load i64, ptr %slot23, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %call2488 = call i32 @myl_rc_take_failure(ptr %p2487) nomerge, !dbg !176
  store i32 %call2488, ptr %slot443, align 8
  %v2489 = load i64, ptr %slot1, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %v2491 = load i32, ptr %slot443, align 8
  %call2492 = call i32 @myl_qbe_rc_status(ptr %p2490, i32 %v2491) nomerge, !dbg !176
  store i32 %call2492, ptr %slot444, align 8
  br label %bb_failure
bb_rcsuccess1084:
  %v2493 = load i64, ptr %slot6, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  store i32 0, ptr %p2494, align 4, !alias.scope !3, !noalias !4
  %v2495 = load i64, ptr %slot9, align 8
  %p2496 = inttoptr i64 %v2495 to ptr
  store i32 2, ptr %p2496, align 4, !alias.scope !3, !noalias !4
  %v2497 = load i64, ptr %slot8, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i32 1, ptr %p2498, align 4, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot11, align 8
  store i64 %v2499, ptr %slot445, align 8
  %v2500 = load i64, ptr %slot8, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  store i32 0, ptr %p2501, align 4, !alias.scope !3, !noalias !4
  %v2502 = load i64, ptr %slot6, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %ld2504 = load i32, ptr %p2503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2504, ptr %slot446, align 8
  %v2505 = load i32, ptr %slot446, align 8
  %cv2506 = zext i32 %v2505 to i64
  %cond2507 = icmp ne i64 %cv2506, 0
  br i1 %cond2507, label %bb_rcslotdrop1094, label %bb_rcslotdone1094
bb_rcslotdrop1094:
  %v2508 = load i64, ptr %slot6, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  store i32 0, ptr %p2509, align 4, !alias.scope !3, !noalias !4
  %v2510 = load i64, ptr %slot10, align 8
  store i64 %v2510, ptr %slot447, align 8
  %v2511 = load i64, ptr %slot7, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %ld2513 = load i32, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2513, ptr %slot448, align 8
  %v2514 = load i32, ptr %slot448, align 8
  %op2515 = and i32 %v2514, 28
  store i32 %op2515, ptr %slot449, align 8
  %v2516 = load i32, ptr %slot449, align 8
  %cv2517 = zext i32 %v2516 to i64
  %cond2518 = icmp ne i64 %cv2517, 0
  br i1 %cond2518, label %bb_rcslotrole1094, label %bb_rcslotowner1094
bb_rcslotrole1094:
  %v2519 = load i64, ptr %slot23, align 8
  store i64 %v2519, ptr %slot450, align 8
  %v2520 = load i64, ptr %slot450, align 8
  %v2521 = load i64, ptr %slot447, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2520, i64 %v2521) nomerge, !dbg !176
  br label %bb_rcslotdone1094
bb_rcslotowner1094:
  %v2522 = load i64, ptr %slot23, align 8
  store i64 %v2522, ptr %slot451, align 8
  %v2523 = load i64, ptr %slot451, align 8
  %v2524 = load i64, ptr %slot447, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2523, i64 %v2524) nomerge, !dbg !176
  br label %bb_rcslotdone1094
bb_rcslotdone1094:
  %v2525 = load i64, ptr %slot445, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2526, i64 56, i1 false)
  ret void
bb_i72:
  %v2527 = load i64, ptr %slot17, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i64 0, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot17, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i64, ptr %p2530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2531, ptr %slot452, align 8
  %v2532 = load i64, ptr %slot452, align 8
  %cond2533 = icmp ne i64 %v2532, 0
  br i1 %cond2533, label %bb_success1157, label %bb_failed1157
bb_failed1157:
  %v2534 = load i64, ptr %slot1, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  call void @myl_qbe_fail_assert(ptr %p2535) nomerge, !dbg !178
  unreachable
bb_success1157:
  %v2536 = load i64, ptr %slot12, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %ld2538 = load i64, ptr %p2537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2538, ptr %slot453, align 8
  %v2539 = load i64, ptr %slot453, align 8
  %v2540 = load i64, ptr %slot17, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  store i64 %v2539, ptr %p2541, align 8, !alias.scope !3, !noalias !4
  %v2542 = load i64, ptr %slot13, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  %ld2544 = load i64, ptr %p2543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2544, ptr %slot454, align 8
  %v2545 = load i64, ptr %slot454, align 8
  %v2546 = load i64, ptr %slot18, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  store i64 %v2545, ptr %p2547, align 8, !alias.scope !3, !noalias !4
  %v2548 = load i64, ptr %slot17, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  %ld2550 = load i64, ptr %p2549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2550, ptr %slot455, align 8
  %v2551 = load i64, ptr %slot18, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i64, ptr %p2552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2553, ptr %slot456, align 8
  %v2554 = load i64, ptr %slot1, align 8
  %v2555 = load i64, ptr %slot455, align 8
  %v2556 = load i64, ptr %slot456, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult458, i64 %v2554, i64 %v2555, i64 %v2556) nomerge, !dbg !180
  %addr2557 = ptrtoint ptr %callresult458 to i64
  store i64 %addr2557, ptr %slot457, align 8
  %v2558 = load i64, ptr %slot457, align 8
  %v2559 = load i64, ptr %slot17, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  store i64 %v2558, ptr %p2560, align 8, !alias.scope !3, !noalias !4
  %v2561 = load i64, ptr %slot17, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  %ld2563 = load i64, ptr %p2562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2563, ptr %slot459, align 8
  %v2564 = load i64, ptr %slot11, align 8
  store i64 %v2564, ptr %slot460, align 8
  %v2565 = load i64, ptr %slot459, align 8
  %v2566 = load i64, ptr %slot460, align 8
  %p2567 = inttoptr i64 %v2565 to ptr
  %p2568 = inttoptr i64 %v2566 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2568, ptr %p2567, i64 56, i1 false)
  %v2569 = load i64, ptr %slot9, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 2, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot8, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i32 1, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot6, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  %ld2575 = load i32, ptr %p2574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2575, ptr %slot461, align 8
  %v2576 = load i32, ptr %slot461, align 8
  %cv2577 = zext i32 %v2576 to i64
  %cond2578 = icmp ne i64 %cv2577, 0
  br i1 %cond2578, label %bb_rcslotdrop1169, label %bb_rcslotdone1169
bb_rcslotdrop1169:
  %v2579 = load i64, ptr %slot6, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i32 0, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  %v2581 = load i64, ptr %slot10, align 8
  store i64 %v2581, ptr %slot462, align 8
  %v2582 = load i64, ptr %slot7, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %ld2584 = load i32, ptr %p2583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2584, ptr %slot463, align 8
  %v2585 = load i32, ptr %slot463, align 8
  %op2586 = and i32 %v2585, 28
  store i32 %op2586, ptr %slot464, align 8
  %v2587 = load i32, ptr %slot464, align 8
  %cv2588 = zext i32 %v2587 to i64
  %cond2589 = icmp ne i64 %cv2588, 0
  br i1 %cond2589, label %bb_rcslotrole1169, label %bb_rcslotowner1169
bb_rcslotrole1169:
  %v2590 = load i64, ptr %slot23, align 8
  store i64 %v2590, ptr %slot465, align 8
  %v2591 = load i64, ptr %slot465, align 8
  %v2592 = load i64, ptr %slot462, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2591, i64 %v2592) nomerge, !dbg !180
  br label %bb_rcslotdone1169
bb_rcslotowner1169:
  %v2593 = load i64, ptr %slot23, align 8
  store i64 %v2593, ptr %slot466, align 8
  %v2594 = load i64, ptr %slot466, align 8
  %v2595 = load i64, ptr %slot462, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2594, i64 %v2595) nomerge, !dbg !180
  br label %bb_rcslotdone1169
bb_rcslotdone1169:
  %v2596 = load i64, ptr %slot10, align 8
  store i64 %v2596, ptr %slot467, align 8
  %v2597 = load i64, ptr %slot11, align 8
  store i64 %v2597, ptr %slot468, align 8
  %v2598 = load i64, ptr %slot468, align 8
  %v2599 = load i64, ptr %slot467, align 8
  %p2600 = inttoptr i64 %v2598 to ptr
  %p2601 = inttoptr i64 %v2599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2601, ptr %p2600, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot7, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  store i32 2, ptr %p2603, align 4, !alias.scope !3, !noalias !4
  %v2604 = load i64, ptr %slot9, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i32, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2606, ptr %slot469, align 8
  %v2607 = load i32, ptr %slot469, align 8
  %v2608 = load i64, ptr %slot7, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i32 %v2607, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot8, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 0, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot6, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i32 1, ptr %p2613, align 4, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot467, align 8
  %v2615 = load i64, ptr %slot17, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i64 %v2614, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot17, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2619, ptr %slot470, align 8
  %v2620 = load i64, ptr %slot17, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %ld2622 = load i64, ptr %p2621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2622, ptr %slot471, align 8
  %v2623 = load i64, ptr %slot11, align 8
  store i64 %v2623, ptr %slot472, align 8
  %v2624 = load i64, ptr %slot24, align 8
  store i64 %v2624, ptr %slot473, align 8
  %v2625 = load i64, ptr %slot23, align 8
  %v2626 = load i64, ptr %slot472, align 8
  %v2627 = load i64, ptr %slot471, align 8
  %v2628 = load i64, ptr %slot473, align 8
  %cv2629 = trunc i64 %v2628 to i32
  %call2630 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2625, i64 %v2626, i64 %v2627, i32 %cv2629) nomerge, !dbg !182
  store i32 %call2630, ptr %slot474, align 8
  %v2631 = load i32, ptr %slot474, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcsuccess1189, label %bb_rcfailure1189
bb_rcfailure1189:
  %v2634 = load i64, ptr %slot23, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %call2636 = call i32 @myl_rc_take_failure(ptr %p2635) nomerge, !dbg !182
  store i32 %call2636, ptr %slot475, align 8
  %v2637 = load i64, ptr %slot1, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %v2639 = load i32, ptr %slot475, align 8
  %call2640 = call i32 @myl_qbe_rc_status(ptr %p2638, i32 %v2639) nomerge, !dbg !182
  store i32 %call2640, ptr %slot476, align 8
  br label %bb_failure
bb_rcsuccess1189:
  %v2641 = load i64, ptr %slot6, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  store i32 0, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot9, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i32 2, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot8, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i32 1, ptr %p2646, align 4, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot11, align 8
  store i64 %v2647, ptr %slot477, align 8
  %v2648 = load i64, ptr %slot8, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i32 0, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot6, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot478, align 8
  %v2653 = load i32, ptr %slot478, align 8
  %cv2654 = zext i32 %v2653 to i64
  %cond2655 = icmp ne i64 %cv2654, 0
  br i1 %cond2655, label %bb_rcslotdrop1199, label %bb_rcslotdone1199
bb_rcslotdrop1199:
  %v2656 = load i64, ptr %slot6, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  store i32 0, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  %v2658 = load i64, ptr %slot10, align 8
  store i64 %v2658, ptr %slot479, align 8
  %v2659 = load i64, ptr %slot7, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %ld2661 = load i32, ptr %p2660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2661, ptr %slot480, align 8
  %v2662 = load i32, ptr %slot480, align 8
  %op2663 = and i32 %v2662, 28
  store i32 %op2663, ptr %slot481, align 8
  %v2664 = load i32, ptr %slot481, align 8
  %cv2665 = zext i32 %v2664 to i64
  %cond2666 = icmp ne i64 %cv2665, 0
  br i1 %cond2666, label %bb_rcslotrole1199, label %bb_rcslotowner1199
bb_rcslotrole1199:
  %v2667 = load i64, ptr %slot23, align 8
  store i64 %v2667, ptr %slot482, align 8
  %v2668 = load i64, ptr %slot482, align 8
  %v2669 = load i64, ptr %slot479, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2668, i64 %v2669) nomerge, !dbg !182
  br label %bb_rcslotdone1199
bb_rcslotowner1199:
  %v2670 = load i64, ptr %slot23, align 8
  store i64 %v2670, ptr %slot483, align 8
  %v2671 = load i64, ptr %slot483, align 8
  %v2672 = load i64, ptr %slot479, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2671, i64 %v2672) nomerge, !dbg !182
  br label %bb_rcslotdone1199
bb_rcslotdone1199:
  %v2673 = load i64, ptr %slot477, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2674, i64 56, i1 false)
  ret void
bb_i78:
  %v2675 = load i64, ptr %slot17, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i64 0, ptr %p2676, align 8, !alias.scope !3, !noalias !4
  %v2677 = load i64, ptr %slot17, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  %ld2679 = load i64, ptr %p2678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2679, ptr %slot484, align 8
  %v2680 = load i64, ptr %slot484, align 8
  %cond2681 = icmp ne i64 %v2680, 0
  br i1 %cond2681, label %bb_success1262, label %bb_failed1262
bb_failed1262:
  %v2682 = load i64, ptr %slot1, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  call void @myl_qbe_fail_assert(ptr %p2683) nomerge, !dbg !184
  unreachable
bb_success1262:
  %v2684 = load i64, ptr %slot12, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  %ld2686 = load i64, ptr %p2685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2686, ptr %slot485, align 8
  %v2687 = load i64, ptr %slot485, align 8
  %v2688 = load i64, ptr %slot17, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i64 %v2687, ptr %p2689, align 8, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot13, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i64, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2692, ptr %slot486, align 8
  %v2693 = load i64, ptr %slot486, align 8
  %v2694 = load i64, ptr %slot18, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i64 %v2693, ptr %p2695, align 8, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot17, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %ld2698 = load i64, ptr %p2697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2698, ptr %slot487, align 8
  %v2699 = load i64, ptr %slot18, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %ld2701 = load i64, ptr %p2700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2701, ptr %slot488, align 8
  %v2702 = load i64, ptr %slot1, align 8
  %v2703 = load i64, ptr %slot487, align 8
  %v2704 = load i64, ptr %slot488, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult490, i64 %v2702, i64 %v2703, i64 %v2704) nomerge, !dbg !186
  %addr2705 = ptrtoint ptr %callresult490 to i64
  store i64 %addr2705, ptr %slot489, align 8
  %v2706 = load i64, ptr %slot489, align 8
  %v2707 = load i64, ptr %slot17, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  store i64 %v2706, ptr %p2708, align 8, !alias.scope !3, !noalias !4
  %v2709 = load i64, ptr %slot17, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %ld2711 = load i64, ptr %p2710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2711, ptr %slot491, align 8
  %v2712 = load i64, ptr %slot11, align 8
  store i64 %v2712, ptr %slot492, align 8
  %v2713 = load i64, ptr %slot491, align 8
  %v2714 = load i64, ptr %slot492, align 8
  %p2715 = inttoptr i64 %v2713 to ptr
  %p2716 = inttoptr i64 %v2714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2716, ptr %p2715, i64 56, i1 false)
  %v2717 = load i64, ptr %slot9, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  store i32 2, ptr %p2718, align 4, !alias.scope !3, !noalias !4
  %v2719 = load i64, ptr %slot8, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  store i32 1, ptr %p2720, align 4, !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot6, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %ld2723 = load i32, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2723, ptr %slot493, align 8
  %v2724 = load i32, ptr %slot493, align 8
  %cv2725 = zext i32 %v2724 to i64
  %cond2726 = icmp ne i64 %cv2725, 0
  br i1 %cond2726, label %bb_rcslotdrop1274, label %bb_rcslotdone1274
bb_rcslotdrop1274:
  %v2727 = load i64, ptr %slot6, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  store i32 0, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  %v2729 = load i64, ptr %slot10, align 8
  store i64 %v2729, ptr %slot494, align 8
  %v2730 = load i64, ptr %slot7, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  %ld2732 = load i32, ptr %p2731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2732, ptr %slot495, align 8
  %v2733 = load i32, ptr %slot495, align 8
  %op2734 = and i32 %v2733, 28
  store i32 %op2734, ptr %slot496, align 8
  %v2735 = load i32, ptr %slot496, align 8
  %cv2736 = zext i32 %v2735 to i64
  %cond2737 = icmp ne i64 %cv2736, 0
  br i1 %cond2737, label %bb_rcslotrole1274, label %bb_rcslotowner1274
bb_rcslotrole1274:
  %v2738 = load i64, ptr %slot23, align 8
  store i64 %v2738, ptr %slot497, align 8
  %v2739 = load i64, ptr %slot497, align 8
  %v2740 = load i64, ptr %slot494, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2739, i64 %v2740) nomerge, !dbg !186
  br label %bb_rcslotdone1274
bb_rcslotowner1274:
  %v2741 = load i64, ptr %slot23, align 8
  store i64 %v2741, ptr %slot498, align 8
  %v2742 = load i64, ptr %slot498, align 8
  %v2743 = load i64, ptr %slot494, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2742, i64 %v2743) nomerge, !dbg !186
  br label %bb_rcslotdone1274
bb_rcslotdone1274:
  %v2744 = load i64, ptr %slot10, align 8
  store i64 %v2744, ptr %slot499, align 8
  %v2745 = load i64, ptr %slot11, align 8
  store i64 %v2745, ptr %slot500, align 8
  %v2746 = load i64, ptr %slot500, align 8
  %v2747 = load i64, ptr %slot499, align 8
  %p2748 = inttoptr i64 %v2746 to ptr
  %p2749 = inttoptr i64 %v2747 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2749, ptr %p2748, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2750 = load i64, ptr %slot7, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i32 2, ptr %p2751, align 4, !alias.scope !3, !noalias !4
  %v2752 = load i64, ptr %slot9, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %ld2754 = load i32, ptr %p2753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2754, ptr %slot501, align 8
  %v2755 = load i32, ptr %slot501, align 8
  %v2756 = load i64, ptr %slot7, align 8
  %p2757 = inttoptr i64 %v2756 to ptr
  store i32 %v2755, ptr %p2757, align 4, !alias.scope !3, !noalias !4
  %v2758 = load i64, ptr %slot8, align 8
  %p2759 = inttoptr i64 %v2758 to ptr
  store i32 0, ptr %p2759, align 4, !alias.scope !3, !noalias !4
  %v2760 = load i64, ptr %slot6, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  store i32 1, ptr %p2761, align 4, !alias.scope !3, !noalias !4
  %v2762 = load i64, ptr %slot499, align 8
  %v2763 = load i64, ptr %slot17, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  store i64 %v2762, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  %v2765 = load i64, ptr %slot17, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i64, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2767, ptr %slot502, align 8
  %v2768 = load i64, ptr %slot17, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  %ld2770 = load i64, ptr %p2769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2770, ptr %slot503, align 8
  %v2771 = load i64, ptr %slot11, align 8
  store i64 %v2771, ptr %slot504, align 8
  %v2772 = load i64, ptr %slot24, align 8
  store i64 %v2772, ptr %slot505, align 8
  %v2773 = load i64, ptr %slot23, align 8
  %v2774 = load i64, ptr %slot504, align 8
  %v2775 = load i64, ptr %slot503, align 8
  %v2776 = load i64, ptr %slot505, align 8
  %cv2777 = trunc i64 %v2776 to i32
  %call2778 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2773, i64 %v2774, i64 %v2775, i32 %cv2777) nomerge, !dbg !188
  store i32 %call2778, ptr %slot506, align 8
  %v2779 = load i32, ptr %slot506, align 8
  %cv2780 = zext i32 %v2779 to i64
  %cond2781 = icmp ne i64 %cv2780, 0
  br i1 %cond2781, label %bb_rcsuccess1294, label %bb_rcfailure1294
bb_rcfailure1294:
  %v2782 = load i64, ptr %slot23, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %call2784 = call i32 @myl_rc_take_failure(ptr %p2783) nomerge, !dbg !188
  store i32 %call2784, ptr %slot507, align 8
  %v2785 = load i64, ptr %slot1, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %v2787 = load i32, ptr %slot507, align 8
  %call2788 = call i32 @myl_qbe_rc_status(ptr %p2786, i32 %v2787) nomerge, !dbg !188
  store i32 %call2788, ptr %slot508, align 8
  br label %bb_failure
bb_rcsuccess1294:
  %v2789 = load i64, ptr %slot6, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i32 0, ptr %p2790, align 4, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot9, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  store i32 2, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  %v2793 = load i64, ptr %slot8, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i32 1, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  %v2795 = load i64, ptr %slot11, align 8
  store i64 %v2795, ptr %slot509, align 8
  %v2796 = load i64, ptr %slot8, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  store i32 0, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  %v2798 = load i64, ptr %slot6, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  %ld2800 = load i32, ptr %p2799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2800, ptr %slot510, align 8
  %v2801 = load i32, ptr %slot510, align 8
  %cv2802 = zext i32 %v2801 to i64
  %cond2803 = icmp ne i64 %cv2802, 0
  br i1 %cond2803, label %bb_rcslotdrop1304, label %bb_rcslotdone1304
bb_rcslotdrop1304:
  %v2804 = load i64, ptr %slot6, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i32 0, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot10, align 8
  store i64 %v2806, ptr %slot511, align 8
  %v2807 = load i64, ptr %slot7, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  %ld2809 = load i32, ptr %p2808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2809, ptr %slot512, align 8
  %v2810 = load i32, ptr %slot512, align 8
  %op2811 = and i32 %v2810, 28
  store i32 %op2811, ptr %slot513, align 8
  %v2812 = load i32, ptr %slot513, align 8
  %cv2813 = zext i32 %v2812 to i64
  %cond2814 = icmp ne i64 %cv2813, 0
  br i1 %cond2814, label %bb_rcslotrole1304, label %bb_rcslotowner1304
bb_rcslotrole1304:
  %v2815 = load i64, ptr %slot23, align 8
  store i64 %v2815, ptr %slot514, align 8
  %v2816 = load i64, ptr %slot514, align 8
  %v2817 = load i64, ptr %slot511, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2816, i64 %v2817) nomerge, !dbg !188
  br label %bb_rcslotdone1304
bb_rcslotowner1304:
  %v2818 = load i64, ptr %slot23, align 8
  store i64 %v2818, ptr %slot515, align 8
  %v2819 = load i64, ptr %slot515, align 8
  %v2820 = load i64, ptr %slot511, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2819, i64 %v2820) nomerge, !dbg !188
  br label %bb_rcslotdone1304
bb_rcslotdone1304:
  %v2821 = load i64, ptr %slot509, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2822, i64 56, i1 false)
  ret void
bb_i84:
  %v2823 = load i64, ptr %slot17, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  store i64 0, ptr %p2824, align 8, !alias.scope !3, !noalias !4
  %v2825 = load i64, ptr %slot17, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  %ld2827 = load i64, ptr %p2826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2827, ptr %slot516, align 8
  %v2828 = load i64, ptr %slot516, align 8
  %cond2829 = icmp ne i64 %v2828, 0
  br i1 %cond2829, label %bb_success1367, label %bb_failed1367
bb_failed1367:
  %v2830 = load i64, ptr %slot1, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  call void @myl_qbe_fail_assert(ptr %p2831) nomerge, !dbg !190
  unreachable
bb_success1367:
  %v2832 = load i64, ptr %slot12, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i64, ptr %p2833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2834, ptr %slot517, align 8
  %v2835 = load i64, ptr %slot517, align 8
  %v2836 = load i64, ptr %slot17, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  store i64 %v2835, ptr %p2837, align 8, !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot13, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  %ld2840 = load i64, ptr %p2839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2840, ptr %slot518, align 8
  %v2841 = load i64, ptr %slot518, align 8
  %v2842 = load i64, ptr %slot18, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  store i64 %v2841, ptr %p2843, align 8, !alias.scope !3, !noalias !4
  %v2844 = load i64, ptr %slot17, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %ld2846 = load i64, ptr %p2845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2846, ptr %slot519, align 8
  %v2847 = load i64, ptr %slot18, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i64, ptr %p2848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2849, ptr %slot520, align 8
  %v2850 = load i64, ptr %slot1, align 8
  %v2851 = load i64, ptr %slot519, align 8
  %v2852 = load i64, ptr %slot520, align 8
  call void @myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351(ptr sret([56 x i8]) align 8 %callresult522, i64 %v2850, i64 %v2851, i64 %v2852) nomerge, !dbg !192
  %addr2853 = ptrtoint ptr %callresult522 to i64
  store i64 %addr2853, ptr %slot521, align 8
  %v2854 = load i64, ptr %slot521, align 8
  %v2855 = load i64, ptr %slot17, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i64 %v2854, ptr %p2856, align 8, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot17, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %ld2859 = load i64, ptr %p2858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2859, ptr %slot523, align 8
  %v2860 = load i64, ptr %slot11, align 8
  store i64 %v2860, ptr %slot524, align 8
  %v2861 = load i64, ptr %slot523, align 8
  %v2862 = load i64, ptr %slot524, align 8
  %p2863 = inttoptr i64 %v2861 to ptr
  %p2864 = inttoptr i64 %v2862 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2864, ptr %p2863, i64 56, i1 false)
  %v2865 = load i64, ptr %slot9, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  store i32 2, ptr %p2866, align 4, !alias.scope !3, !noalias !4
  %v2867 = load i64, ptr %slot8, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  store i32 1, ptr %p2868, align 4, !alias.scope !3, !noalias !4
  %v2869 = load i64, ptr %slot6, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  %ld2871 = load i32, ptr %p2870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2871, ptr %slot525, align 8
  %v2872 = load i32, ptr %slot525, align 8
  %cv2873 = zext i32 %v2872 to i64
  %cond2874 = icmp ne i64 %cv2873, 0
  br i1 %cond2874, label %bb_rcslotdrop1379, label %bb_rcslotdone1379
bb_rcslotdrop1379:
  %v2875 = load i64, ptr %slot6, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  store i32 0, ptr %p2876, align 4, !alias.scope !3, !noalias !4
  %v2877 = load i64, ptr %slot10, align 8
  store i64 %v2877, ptr %slot526, align 8
  %v2878 = load i64, ptr %slot7, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i32, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2880, ptr %slot527, align 8
  %v2881 = load i32, ptr %slot527, align 8
  %op2882 = and i32 %v2881, 28
  store i32 %op2882, ptr %slot528, align 8
  %v2883 = load i32, ptr %slot528, align 8
  %cv2884 = zext i32 %v2883 to i64
  %cond2885 = icmp ne i64 %cv2884, 0
  br i1 %cond2885, label %bb_rcslotrole1379, label %bb_rcslotowner1379
bb_rcslotrole1379:
  %v2886 = load i64, ptr %slot23, align 8
  store i64 %v2886, ptr %slot529, align 8
  %v2887 = load i64, ptr %slot529, align 8
  %v2888 = load i64, ptr %slot526, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2887, i64 %v2888) nomerge, !dbg !192
  br label %bb_rcslotdone1379
bb_rcslotowner1379:
  %v2889 = load i64, ptr %slot23, align 8
  store i64 %v2889, ptr %slot530, align 8
  %v2890 = load i64, ptr %slot530, align 8
  %v2891 = load i64, ptr %slot526, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2890, i64 %v2891) nomerge, !dbg !192
  br label %bb_rcslotdone1379
bb_rcslotdone1379:
  %v2892 = load i64, ptr %slot10, align 8
  store i64 %v2892, ptr %slot531, align 8
  %v2893 = load i64, ptr %slot11, align 8
  store i64 %v2893, ptr %slot532, align 8
  %v2894 = load i64, ptr %slot532, align 8
  %v2895 = load i64, ptr %slot531, align 8
  %p2896 = inttoptr i64 %v2894 to ptr
  %p2897 = inttoptr i64 %v2895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2897, ptr %p2896, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot7, align 8
  %p2899 = inttoptr i64 %v2898 to ptr
  store i32 2, ptr %p2899, align 4, !alias.scope !3, !noalias !4
  %v2900 = load i64, ptr %slot9, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  %ld2902 = load i32, ptr %p2901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2902, ptr %slot533, align 8
  %v2903 = load i32, ptr %slot533, align 8
  %v2904 = load i64, ptr %slot7, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  store i32 %v2903, ptr %p2905, align 4, !alias.scope !3, !noalias !4
  %v2906 = load i64, ptr %slot8, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  store i32 0, ptr %p2907, align 4, !alias.scope !3, !noalias !4
  %v2908 = load i64, ptr %slot6, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  store i32 1, ptr %p2909, align 4, !alias.scope !3, !noalias !4
  %v2910 = load i64, ptr %slot531, align 8
  %v2911 = load i64, ptr %slot17, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  store i64 %v2910, ptr %p2912, align 8, !alias.scope !3, !noalias !4
  %v2913 = load i64, ptr %slot17, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  %ld2915 = load i64, ptr %p2914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2915, ptr %slot534, align 8
  %v2916 = load i64, ptr %slot17, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %ld2918 = load i64, ptr %p2917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2918, ptr %slot535, align 8
  %v2919 = load i64, ptr %slot11, align 8
  store i64 %v2919, ptr %slot536, align 8
  %v2920 = load i64, ptr %slot24, align 8
  store i64 %v2920, ptr %slot537, align 8
  %v2921 = load i64, ptr %slot23, align 8
  %v2922 = load i64, ptr %slot536, align 8
  %v2923 = load i64, ptr %slot535, align 8
  %v2924 = load i64, ptr %slot537, align 8
  %cv2925 = trunc i64 %v2924 to i32
  %call2926 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v2921, i64 %v2922, i64 %v2923, i32 %cv2925) nomerge, !dbg !194
  store i32 %call2926, ptr %slot538, align 8
  %v2927 = load i32, ptr %slot538, align 8
  %cv2928 = zext i32 %v2927 to i64
  %cond2929 = icmp ne i64 %cv2928, 0
  br i1 %cond2929, label %bb_rcsuccess1399, label %bb_rcfailure1399
bb_rcfailure1399:
  %v2930 = load i64, ptr %slot23, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %call2932 = call i32 @myl_rc_take_failure(ptr %p2931) nomerge, !dbg !194
  store i32 %call2932, ptr %slot539, align 8
  %v2933 = load i64, ptr %slot1, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %v2935 = load i32, ptr %slot539, align 8
  %call2936 = call i32 @myl_qbe_rc_status(ptr %p2934, i32 %v2935) nomerge, !dbg !194
  store i32 %call2936, ptr %slot540, align 8
  br label %bb_failure
bb_rcsuccess1399:
  %v2937 = load i64, ptr %slot6, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  store i32 0, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  %v2939 = load i64, ptr %slot9, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i32 2, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot8, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  store i32 1, ptr %p2942, align 4, !alias.scope !3, !noalias !4
  %v2943 = load i64, ptr %slot11, align 8
  store i64 %v2943, ptr %slot541, align 8
  %v2944 = load i64, ptr %slot8, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  store i32 0, ptr %p2945, align 4, !alias.scope !3, !noalias !4
  %v2946 = load i64, ptr %slot6, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %ld2948 = load i32, ptr %p2947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2948, ptr %slot542, align 8
  %v2949 = load i32, ptr %slot542, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcslotdrop1409, label %bb_rcslotdone1409
bb_rcslotdrop1409:
  %v2952 = load i64, ptr %slot6, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  store i32 0, ptr %p2953, align 4, !alias.scope !3, !noalias !4
  %v2954 = load i64, ptr %slot10, align 8
  store i64 %v2954, ptr %slot543, align 8
  %v2955 = load i64, ptr %slot7, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  %ld2957 = load i32, ptr %p2956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2957, ptr %slot544, align 8
  %v2958 = load i32, ptr %slot544, align 8
  %op2959 = and i32 %v2958, 28
  store i32 %op2959, ptr %slot545, align 8
  %v2960 = load i32, ptr %slot545, align 8
  %cv2961 = zext i32 %v2960 to i64
  %cond2962 = icmp ne i64 %cv2961, 0
  br i1 %cond2962, label %bb_rcslotrole1409, label %bb_rcslotowner1409
bb_rcslotrole1409:
  %v2963 = load i64, ptr %slot23, align 8
  store i64 %v2963, ptr %slot546, align 8
  %v2964 = load i64, ptr %slot546, align 8
  %v2965 = load i64, ptr %slot543, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64 %v2964, i64 %v2965) nomerge, !dbg !194
  br label %bb_rcslotdone1409
bb_rcslotowner1409:
  %v2966 = load i64, ptr %slot23, align 8
  store i64 %v2966, ptr %slot547, align 8
  %v2967 = load i64, ptr %slot547, align 8
  %v2968 = load i64, ptr %slot543, align 8
  call void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64 %v2967, i64 %v2968) nomerge, !dbg !194
  br label %bb_rcslotdone1409
bb_rcslotdone1409:
  %v2969 = load i64, ptr %slot541, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2970, i64 56, i1 false)
  ret void
bb_failure:
  %v2971 = load i64, ptr %slot5, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  call void @llvm.memset.p0.i64(ptr %p2972, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !194
  %v2973 = load i64, ptr %slot5, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2974, i64 56, i1 false)
  ret void
bb_entry_failure:
  %v2975 = load i64, ptr %slot5, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  call void @llvm.memset.p0.i64(ptr %p2976, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !194
  %v2977 = load i64, ptr %slot5, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2978, i64 56, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_drop(i64, i64)
declare i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 112v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351", linkageName: "myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7450163064982392175, i64 0, !"myl_f_9c2dd72546f546c3c615d24451fc30da0d50c0f0983ecd9e6d4f32b6cdf5f351"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!128 = !DILocation(line: 24, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!136 = !DILocation(line: 32, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!140 = !DILocation(line: 36, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!142 = !DILocation(line: 38, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!144 = !DILocation(line: 41, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!146 = !DILocation(line: 42, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!148 = !DILocation(line: 44, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!150 = !DILocation(line: 47, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!152 = !DILocation(line: 48, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!154 = !DILocation(line: 50, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!156 = !DILocation(line: 53, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!158 = !DILocation(line: 54, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!160 = !DILocation(line: 56, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!162 = !DILocation(line: 59, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!164 = !DILocation(line: 60, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!166 = !DILocation(line: 62, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!168 = !DILocation(line: 65, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!170 = !DILocation(line: 66, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!172 = !DILocation(line: 68, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!174 = !DILocation(line: 71, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!176 = !DILocation(line: 72, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!178 = !DILocation(line: 74, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!180 = !DILocation(line: 77, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!182 = !DILocation(line: 78, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!184 = !DILocation(line: 80, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!186 = !DILocation(line: 83, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647207)
!188 = !DILocation(line: 84, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!190 = !DILocation(line: 86, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!192 = !DILocation(line: 89, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!194 = !DILocation(line: 90, column: 0, scope: !195)
