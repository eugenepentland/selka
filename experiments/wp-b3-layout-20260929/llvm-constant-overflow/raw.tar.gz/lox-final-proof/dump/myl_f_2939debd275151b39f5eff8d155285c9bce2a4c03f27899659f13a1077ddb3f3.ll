target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v77 = load i64, ptr %slot1, align 8
  %op78 = add i64 %v77, 32
  store i64 %op78, ptr %slot3, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot4, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot5, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot6, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot7, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot8, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot9, align 8
  %mem91 = alloca i8, i64 208, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot10, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot11, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot12, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot13, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot14, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot15, align 8
  %v103 = load i64, ptr %slot1, align 8
  %op104 = add i64 %v103, 64
  store i64 %op104, ptr %slot16, align 8
  %v105 = load i64, ptr %slot16, align 8
  %p106 = inttoptr i64 %v105 to ptr
  %ld107 = load i64, ptr %p106, align 8, !alias.scope !4, !noalias !3
  store i64 %ld107, ptr %slot17, align 8
  %stack108 = call ptr @llvm.stacksave()
  %stackaddr109 = ptrtoint ptr %stack108 to i64
  %v110 = load i64, ptr %slot17, align 8
  %cmp111 = icmp ult i64 %stackaddr109, %v110
  %cv112 = zext i1 %cmp111 to i64
  store i64 %cv112, ptr %slot18, align 8
  %v113 = load i64, ptr %slot18, align 8
  %cond114 = icmp ne i64 %v113, 0
  br i1 %cond114, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v115 = load i64, ptr %slot1, align 8
  %p116 = inttoptr i64 %v115 to ptr
  call void @myl_qbe_fail_frame(ptr %p116) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v117 = load i64, ptr %slot2, align 8
  %v118 = load i64, ptr %slot11, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot1, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %call122 = call ptr @myl_qbe_heap(ptr %p121) nomerge, !dbg !112
  %calladdr123 = ptrtoint ptr %call122 to i64
  store i64 %calladdr123, ptr %slot19, align 8
  %v124 = load i64, ptr %slot4, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i32 0, ptr %p125, align 4, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot5, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i32 0, ptr %p127, align 4, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot6, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i32 0, ptr %p129, align 4, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot7, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i32 0, ptr %p131, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v132 = load i64, ptr %slot11, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i64, ptr %p133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld134, ptr %slot20, align 8
  %v135 = load i64, ptr %slot20, align 8
  %v136 = load i64, ptr %slot13, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !3, !noalias !4
  %p138 = inttoptr i64 ptrtoint (ptr @myl_lit_b56535ef631de18d561d1a232d1aa553e4109037f69e6ed4e9be132b63557b79 to i64) to ptr
  %ld139 = load i64, ptr %p138, align 8, !alias.scope !4, !noalias !3
  store i64 %ld139, ptr %slot21, align 8
  %v140 = load i64, ptr %slot21, align 8
  %v141 = load i64, ptr %slot14, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 %v140, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot14, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot22, align 8
  %v146 = load i64, ptr %slot22, align 8
  %v147 = load i64, ptr %slot9, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot9, align 8
  store i64 %v149, ptr %slot23, align 8
  %v150 = load i64, ptr %slot10, align 8
  store i64 %v150, ptr %slot24, align 8
  %v151 = load i64, ptr %slot23, align 8
  %v152 = load i64, ptr %slot24, align 8
  %p153 = inttoptr i64 %v151 to ptr
  %p154 = inttoptr i64 %v152 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p154, ptr %p153, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot7, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i32 2, ptr %p156, align 4, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot6, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i32 1, ptr %p158, align 4, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot8, align 8
  store i64 %v159, ptr %slot25, align 8
  %v160 = load i64, ptr %slot10, align 8
  store i64 %v160, ptr %slot26, align 8
  %v161 = load i64, ptr %slot26, align 8
  %v162 = load i64, ptr %slot25, align 8
  %p163 = inttoptr i64 %v161 to ptr
  %p164 = inttoptr i64 %v162 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p164, ptr %p163, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot5, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i32 2, ptr %p166, align 4, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot7, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i32, ptr %p168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld169, ptr %slot27, align 8
  %v170 = load i32, ptr %slot27, align 8
  %v171 = load i64, ptr %slot5, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i32 %v170, ptr %p172, align 4, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot6, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i32 0, ptr %p174, align 4, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot4, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i32 1, ptr %p176, align 4, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot25, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot28, align 8
  %v180 = load i64, ptr %slot28, align 8
  %v181 = load i64, ptr %slot14, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot13, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot29, align 8
  %v186 = load i64, ptr %slot14, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld188, ptr %slot30, align 8
  %v189 = load i64, ptr %slot1, align 8
  %v190 = load i64, ptr %slot29, align 8
  %v191 = load i64, ptr %slot30, align 8
  %call192 = call i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64 %v189, i64 %v190, i64 %v191) nomerge, !dbg !114
  store i64 %call192, ptr %slot31, align 8
  %v193 = load i64, ptr %slot31, align 8
  %v194 = load i64, ptr %slot13, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot4, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i32, ptr %p197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld198, ptr %slot32, align 8
  %v199 = load i32, ptr %slot32, align 8
  %cv200 = zext i32 %v199 to i64
  %cond201 = icmp ne i64 %cv200, 0
  br i1 %cond201, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v202 = load i64, ptr %slot4, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i32 0, ptr %p203, align 4, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot8, align 8
  store i64 %v204, ptr %slot33, align 8
  %v205 = load i64, ptr %slot5, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i32, ptr %p206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld207, ptr %slot34, align 8
  %v208 = load i32, ptr %slot34, align 8
  %op209 = and i32 %v208, 28
  store i32 %op209, ptr %slot35, align 8
  %v210 = load i32, ptr %slot35, align 8
  %cv211 = zext i32 %v210 to i64
  %cond212 = icmp ne i64 %cv211, 0
  br i1 %cond212, label %bb_rcslotrole40, label %bb_rcslotowner40
bb_rcslotrole40:
  %v213 = load i64, ptr %slot19, align 8
  store i64 %v213, ptr %slot36, align 8
  %v214 = load i64, ptr %slot33, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot37, align 8
  %v217 = load i64, ptr %slot37, align 8
  %cmp218 = icmp ne i64 %v217, 0
  %cv219 = zext i1 %cmp218 to i32
  store i32 %cv219, ptr %slot38, align 8
  %v220 = load i32, ptr %slot38, align 8
  %cv221 = zext i32 %v220 to i64
  %cond222 = icmp ne i64 %cv221, 0
  br i1 %cond222, label %bb_rcgnn56, label %bb_rcgdone56
bb_rcgnn56:
  %v223 = load i64, ptr %slot37, align 8
  %op224 = sub i64 %v223, 16
  store i64 %op224, ptr %slot39, align 8
  %v225 = load i64, ptr %slot37, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %rgep227 = getelementptr i8, ptr %p226, i64 -16
  %ld228 = load i64, ptr %rgep227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld228, ptr %slot40, align 8
  %v229 = load i64, ptr %slot40, align 8
  %op230 = and i64 %v229, 4611686018427387906
  store i64 %op230, ptr %slot41, align 8
  %v231 = load i64, ptr %slot41, align 8
  %cmp232 = icmp ne i64 %v231, 0
  %cv233 = zext i1 %cmp232 to i32
  store i32 %cv233, ptr %slot42, align 8
  %v234 = load i32, ptr %slot42, align 8
  %cv235 = zext i32 %v234 to i64
  %cond236 = icmp ne i64 %cv235, 0
  br i1 %cond236, label %bb_rcgclear56, label %bb_rcgcounted56
bb_rcgcounted56:
  %v237 = load i64, ptr %slot37, align 8
  %op238 = sub i64 %v237, 24
  store i64 %op238, ptr %slot43, align 8
  %v239 = load i64, ptr %slot37, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %rgep241 = getelementptr i8, ptr %p240, i64 -24
  %ld242 = load i64, ptr %rgep241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld242, ptr %slot44, align 8
  %v243 = load i64, ptr %slot44, align 8
  %op244 = sub i64 %v243, 1
  store i64 %op244, ptr %slot45, align 8
  %v245 = load i64, ptr %slot45, align 8
  %cmp246 = icmp eq i64 %v245, 0
  %cv247 = zext i1 %cmp246 to i32
  store i32 %cv247, ptr %slot46, align 8
  %v248 = load i32, ptr %slot46, align 8
  %cv249 = zext i32 %v248 to i64
  %cond250 = icmp ne i64 %cv249, 0
  br i1 %cond250, label %bb_rcglast56, label %bb_rcgdec56
bb_rcglast56:
  %v251 = load i64, ptr %slot37, align 8
  %op252 = sub i64 %v251, 32
  store i64 %op252, ptr %slot47, align 8
  %v253 = load i64, ptr %slot37, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %rgep255 = getelementptr i8, ptr %p254, i64 -32
  %ld256 = load i64, ptr %rgep255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld256, ptr %slot48, align 8
  %v257 = load i64, ptr %slot48, align 8
  %cmp258 = icmp ne i64 %v257, 0
  %cv259 = zext i1 %cmp258 to i32
  store i32 %cv259, ptr %slot49, align 8
  %v260 = load i32, ptr %slot49, align 8
  %cv261 = zext i32 %v260 to i64
  %cond262 = icmp ne i64 %cv261, 0
  br i1 %cond262, label %bb_rcgdec56, label %bb_rcgslow56
bb_rcgslow56:
  %v263 = load i64, ptr %slot36, align 8
  %v264 = load i64, ptr %slot33, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v263, i64 %v264) nomerge, !dbg !114
  br label %bb_rcgdone56
bb_rcgdec56:
  %v265 = load i64, ptr %slot45, align 8
  %v266 = load i64, ptr %slot37, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %rgep268 = getelementptr i8, ptr %p267, i64 -24
  store i64 %v265, ptr %rgep268, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear56
bb_rcgclear56:
  %v269 = load i64, ptr %slot33, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 0, ptr %p270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone56
bb_rcgdone56:
  br label %bb_rcslotdone40
bb_rcslotowner40:
  %v271 = load i64, ptr %slot19, align 8
  store i64 %v271, ptr %slot50, align 8
  %v272 = load i64, ptr %slot33, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld274, ptr %slot51, align 8
  %v275 = load i64, ptr %slot51, align 8
  %cmp276 = icmp ne i64 %v275, 0
  %cv277 = zext i1 %cmp276 to i32
  store i32 %cv277, ptr %slot52, align 8
  %v278 = load i32, ptr %slot52, align 8
  %cv279 = zext i32 %v278 to i64
  %cond280 = icmp ne i64 %cv279, 0
  br i1 %cond280, label %bb_rcgnn71, label %bb_rcgdone71
bb_rcgnn71:
  %v281 = load i64, ptr %slot51, align 8
  %op282 = sub i64 %v281, 16
  store i64 %op282, ptr %slot53, align 8
  %v283 = load i64, ptr %slot51, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %rgep285 = getelementptr i8, ptr %p284, i64 -16
  %ld286 = load i64, ptr %rgep285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld286, ptr %slot54, align 8
  %v287 = load i64, ptr %slot54, align 8
  %op288 = and i64 %v287, 4611686018427387906
  store i64 %op288, ptr %slot55, align 8
  %v289 = load i64, ptr %slot55, align 8
  %cmp290 = icmp ne i64 %v289, 0
  %cv291 = zext i1 %cmp290 to i32
  store i32 %cv291, ptr %slot56, align 8
  %v292 = load i32, ptr %slot56, align 8
  %cv293 = zext i32 %v292 to i64
  %cond294 = icmp ne i64 %cv293, 0
  br i1 %cond294, label %bb_rcgclear71, label %bb_rcgcounted71
bb_rcgcounted71:
  %v295 = load i64, ptr %slot51, align 8
  %op296 = sub i64 %v295, 32
  store i64 %op296, ptr %slot57, align 8
  %v297 = load i64, ptr %slot51, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %rgep299 = getelementptr i8, ptr %p298, i64 -32
  %ld300 = load i64, ptr %rgep299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld300, ptr %slot58, align 8
  %v301 = load i64, ptr %slot58, align 8
  %op302 = sub i64 %v301, 1
  store i64 %op302, ptr %slot59, align 8
  %v303 = load i64, ptr %slot59, align 8
  %cmp304 = icmp eq i64 %v303, 0
  %cv305 = zext i1 %cmp304 to i32
  store i32 %cv305, ptr %slot60, align 8
  %v306 = load i32, ptr %slot60, align 8
  %cv307 = zext i32 %v306 to i64
  %cond308 = icmp ne i64 %cv307, 0
  br i1 %cond308, label %bb_rcglast71, label %bb_rcgdec71
bb_rcglast71:
  %v309 = load i64, ptr %slot51, align 8
  %op310 = sub i64 %v309, 24
  store i64 %op310, ptr %slot61, align 8
  %v311 = load i64, ptr %slot51, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %rgep313 = getelementptr i8, ptr %p312, i64 -24
  %ld314 = load i64, ptr %rgep313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld314, ptr %slot62, align 8
  %v315 = load i64, ptr %slot62, align 8
  %cmp316 = icmp ne i64 %v315, 0
  %cv317 = zext i1 %cmp316 to i32
  store i32 %cv317, ptr %slot63, align 8
  %v318 = load i32, ptr %slot63, align 8
  %cv319 = zext i32 %v318 to i64
  %cond320 = icmp ne i64 %cv319, 0
  br i1 %cond320, label %bb_rcgdec71, label %bb_rcgslow71
bb_rcgslow71:
  %v321 = load i64, ptr %slot50, align 8
  %v322 = load i64, ptr %slot33, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v321, i64 %v322) nomerge, !dbg !114
  br label %bb_rcgdone71
bb_rcgdec71:
  %v323 = load i64, ptr %slot59, align 8
  %v324 = load i64, ptr %slot51, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %rgep326 = getelementptr i8, ptr %p325, i64 -32
  store i64 %v323, ptr %rgep326, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear71
bb_rcgclear71:
  %v327 = load i64, ptr %slot33, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 0, ptr %p328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone71
bb_rcgdone71:
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v329 = load i64, ptr %slot13, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot64, align 8
  %v332 = load i64, ptr %slot64, align 8
  %v333 = load i64, ptr %slot12, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot11, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot65, align 8
  %v338 = load i64, ptr %slot65, align 8
  %v339 = load i64, ptr %slot13, align 8
  %p340 = inttoptr i64 %v339 to ptr
  store i64 %v338, ptr %p340, align 8, !alias.scope !3, !noalias !4
  %v341 = load i64, ptr %slot11, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i64, ptr %p342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld343, ptr %slot66, align 8
  %v344 = load i64, ptr %slot66, align 8
  %v345 = load i64, ptr %slot13, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i64 %v344, ptr %p346, align 8, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot11, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %ld349 = load i64, ptr %p348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld349, ptr %slot67, align 8
  %v350 = load i64, ptr %slot67, align 8
  %v351 = load i64, ptr %slot13, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 %v350, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot12, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot68, align 8
  %v356 = load i64, ptr %slot68, align 8
  %v357 = load i64, ptr %slot14, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 %v356, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot11, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %ld361 = load i64, ptr %p360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld361, ptr %slot69, align 8
  %v362 = load i64, ptr %slot69, align 8
  %v363 = load i64, ptr %slot13, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot12, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld367, ptr %slot70, align 8
  %v368 = load i64, ptr %slot11, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld370, ptr %slot71, align 8
  %v371 = load i64, ptr %slot71, align 8
  %op372 = add i64 %v371, 64
  store i64 %op372, ptr %slot72, align 8
  %v373 = load i64, ptr %slot70, align 8
  %v374 = load i64, ptr %slot72, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 %v373, ptr %p375, align 8, !alias.scope !4, !noalias !3
  %v376 = load i64, ptr %slot13, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 0, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot11, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %ld380 = load i64, ptr %p379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld380, ptr %slot73, align 8
  %v381 = load i64, ptr %slot73, align 8
  %v382 = load i64, ptr %slot13, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 %v381, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot13, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot74, align 8
  %v387 = load i64, ptr %slot1, align 8
  %v388 = load i64, ptr %slot74, align 8
  %call389 = call i64 @myl_f_556fe5183a519acd97b78bfe04477b8ec36f677ff53890e3927f4845e528ce2e(i64 %v387, i64 %v388) nomerge, !dbg !116
  store i64 %call389, ptr %slot75, align 8
  %v390 = load i64, ptr %slot75, align 8
  %v391 = load i64, ptr %slot13, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 %v390, ptr %p392, align 8, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot13, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 0, ptr %p394, align 8, !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot13, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %ld397 = load i64, ptr %p396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld397, ptr %slot76, align 8
  %v398 = load i64, ptr %slot76, align 8
  ret i64 %v398
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_b56535ef631de18d561d1a232d1aa553e4109037f69e6ed4e9be132b63557b79 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64, i64, i64)
declare i64 @myl_f_556fe5183a519acd97b78bfe04477b8ec36f677ff53890e3927f4845e528ce2e(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3", linkageName: "myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7573971705765373062, i64 0, !"myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!116 = !DILocation(line: 16, column: 0, scope: !117)
