target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v134 = load i64, ptr %slot1, align 8
  %op135 = add i64 %v134, 32
  store i64 %op135, ptr %slot3, align 8
  %mem136 = alloca i8, i64 8, align 8
  %ptr137 = ptrtoint ptr %mem136 to i64
  store i64 %ptr137, ptr %slot4, align 8
  %mem138 = alloca i8, i64 8, align 8
  %ptr139 = ptrtoint ptr %mem138 to i64
  store i64 %ptr139, ptr %slot5, align 8
  %mem140 = alloca i8, i64 8, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot6, align 8
  %mem142 = alloca i8, i64 8, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot7, align 8
  %mem144 = alloca i8, i64 8, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot8, align 8
  %mem146 = alloca i8, i64 8, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot9, align 8
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot10, align 8
  %mem150 = alloca i8, i64 8, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot11, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot12, align 8
  %v154 = load i64, ptr %slot2, align 8
  %v155 = load i64, ptr %slot11, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot1, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %call159 = call ptr @myl_qbe_heap(ptr %p158) nomerge, !dbg !110
  %calladdr160 = ptrtoint ptr %call159 to i64
  store i64 %calladdr160, ptr %slot13, align 8
  %v161 = load i64, ptr %slot1, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %call163 = call i64 @myl_qbe_region_mark(ptr %p162) nomerge, !dbg !110
  store i64 %call163, ptr %slot14, align 8
  %v164 = load i64, ptr %slot4, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i32 0, ptr %p165, align 4, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot5, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot6, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot7, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v172 = load i64, ptr %slot11, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld174, ptr %slot15, align 8
  %v175 = load i64, ptr %slot15, align 8
  %v176 = load i64, ptr %slot12, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot12, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot16, align 8
  %v181 = load i64, ptr %slot16, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i32, ptr %p182, align 4, !alias.scope !4, !noalias !3
  %ext184 = zext i32 %ld183 to i64
  store i64 %ext184, ptr %slot17, align 8
  %v185 = load i64, ptr %slot17, align 8
  %cmp186 = icmp eq i64 %v185, 0
  %cv187 = zext i1 %cmp186 to i64
  store i64 %cv187, ptr %slot18, align 8
  %v188 = load i64, ptr %slot18, align 8
  %cond189 = icmp ne i64 %v188, 0
  br i1 %cond189, label %bb_rcarm3, label %bb_rcarmnext3
bb_rcarm3:
  br label %bb_i2
bb_rcarmnext3:
  %v190 = load i64, ptr %slot17, align 8
  %cmp191 = icmp eq i64 %v190, 1
  %cv192 = zext i1 %cmp191 to i64
  store i64 %cv192, ptr %slot19, align 8
  %v193 = load i64, ptr %slot19, align 8
  %cond194 = icmp ne i64 %v193, 0
  br i1 %cond194, label %bb_rcarm4, label %bb_rcarmnext4
bb_rcarm4:
  br label %bb_i4
bb_rcarmnext4:
  br label %bb_failure
bb_i2:
  %p195 = inttoptr i64 ptrtoint (ptr @myl_lit_93b8421369485a0f5f8b96ec84475c450ff74cc1971189c6e2c10d5614929e1f to i64) to ptr
  %ld196 = load i64, ptr %p195, align 8, !alias.scope !4, !noalias !3
  store i64 %ld196, ptr %slot20, align 8
  %v197 = load i64, ptr %slot20, align 8
  %v198 = load i64, ptr %slot12, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i64 %v197, ptr %p199, align 8, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot12, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot21, align 8
  %v203 = load i64, ptr %slot21, align 8
  %v204 = load i64, ptr %slot9, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot9, align 8
  store i64 %v206, ptr %slot22, align 8
  %v207 = load i64, ptr %slot10, align 8
  store i64 %v207, ptr %slot23, align 8
  %v208 = load i64, ptr %slot22, align 8
  %v209 = load i64, ptr %slot23, align 8
  %p210 = inttoptr i64 %v208 to ptr
  %p211 = inttoptr i64 %v209 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p211, ptr %p210, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot7, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i32 2, ptr %p213, align 4, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot6, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i32 1, ptr %p215, align 4, !alias.scope !3, !noalias !4
  %v216 = load i64, ptr %slot8, align 8
  store i64 %v216, ptr %slot24, align 8
  %v217 = load i64, ptr %slot10, align 8
  store i64 %v217, ptr %slot25, align 8
  %v218 = load i64, ptr %slot25, align 8
  %v219 = load i64, ptr %slot24, align 8
  %p220 = inttoptr i64 %v218 to ptr
  %p221 = inttoptr i64 %v219 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p221, ptr %p220, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot5, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i32 2, ptr %p223, align 4, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot7, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i32, ptr %p225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld226, ptr %slot26, align 8
  %v227 = load i32, ptr %slot26, align 8
  %v228 = load i64, ptr %slot5, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i32 %v227, ptr %p229, align 4, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot6, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i32 0, ptr %p231, align 4, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot4, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i32 1, ptr %p233, align 4, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot24, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot27, align 8
  %v237 = load i64, ptr %slot27, align 8
  %v238 = load i64, ptr %slot12, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 %v237, ptr %p239, align 8, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot12, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot28, align 8
  %v243 = load i64, ptr %slot12, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot29, align 8
  %v246 = load i64, ptr %slot29, align 8
  %v247 = load i64, ptr %slot9, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot9, align 8
  store i64 %v249, ptr %slot30, align 8
  %v250 = load i64, ptr %slot10, align 8
  store i64 %v250, ptr %slot31, align 8
  %v251 = load i64, ptr %slot14, align 8
  store i64 %v251, ptr %slot32, align 8
  %v252 = load i64, ptr %slot30, align 8
  %p254 = inttoptr i64 %v252 to ptr
  %gep255 = getelementptr i8, ptr %p254, i64 0
  %op253 = ptrtoint ptr %gep255 to i64
  store i64 %op253, ptr %slot33, align 8
  %v256 = load i64, ptr %slot33, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot34, align 8
  %v259 = load i64, ptr %slot34, align 8
  %cmp260 = icmp ne i64 %v259, 0
  %cv261 = zext i1 %cmp260 to i32
  store i32 %cv261, ptr %slot35, align 8
  %v262 = load i32, ptr %slot35, align 8
  %cv263 = zext i32 %v262 to i64
  %cond264 = icmp ne i64 %cv263, 0
  br i1 %cond264, label %bb_rcmoveheader29, label %bb_rcmovenext29
bb_rcmoveheader29:
  %v265 = load i64, ptr %slot34, align 8
  %op266 = sub i64 %v265, 16
  store i64 %op266, ptr %slot36, align 8
  %v267 = load i64, ptr %slot34, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %rgep269 = getelementptr i8, ptr %p268, i64 -16
  %ld270 = load i64, ptr %rgep269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld270, ptr %slot37, align 8
  %v271 = load i64, ptr %slot37, align 8
  %op272 = and i64 %v271, 5764607523034234881
  store i64 %op272, ptr %slot38, align 8
  %v273 = load i64, ptr %slot38, align 8
  %cmp274 = icmp ne i64 %v273, 0
  %cv275 = zext i1 %cmp274 to i32
  store i32 %cv275, ptr %slot39, align 8
  %v276 = load i32, ptr %slot39, align 8
  %cv277 = zext i32 %v276 to i64
  %cond278 = icmp ne i64 %cv277, 0
  br i1 %cond278, label %bb_rcmoveslow26, label %bb_rcmovenext29
bb_rcmovenext29:
  %v279 = load i64, ptr %slot30, align 8
  %v280 = load i64, ptr %slot31, align 8
  %p281 = inttoptr i64 %v279 to ptr
  %p282 = inttoptr i64 %v280 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p282, ptr %p281, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot30, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 0, ptr %p284, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved26
bb_rcmoveslow26:
  %v285 = load i64, ptr %slot13, align 8
  %v286 = load i64, ptr %slot31, align 8
  %v287 = load i64, ptr %slot30, align 8
  %v288 = load i64, ptr %slot32, align 8
  %cv289 = trunc i64 %v288 to i32
  %call290 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v285, i64 %v286, i64 %v287, i32 %cv289) nomerge, !dbg !112
  store i32 %call290, ptr %slot40, align 8
  %v291 = load i32, ptr %slot40, align 8
  %cv292 = zext i32 %v291 to i64
  %cond293 = icmp ne i64 %cv292, 0
  br i1 %cond293, label %bb_rcsuccess36, label %bb_rcfailure36
bb_rcfailure36:
  %v294 = load i64, ptr %slot13, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %call296 = call i32 @myl_rc_take_failure(ptr %p295) nomerge, !dbg !112
  store i32 %call296, ptr %slot41, align 8
  %v297 = load i64, ptr %slot1, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %v299 = load i32, ptr %slot41, align 8
  %call300 = call i32 @myl_qbe_rc_status(ptr %p298, i32 %v299) nomerge, !dbg !112
  store i32 %call300, ptr %slot42, align 8
  br label %bb_failure
bb_rcsuccess36:
  br label %bb_rcmoved26
bb_rcmoved26:
  %v301 = load i64, ptr %slot4, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i32 0, ptr %p302, align 4, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot7, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i32 2, ptr %p304, align 4, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot6, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i32 1, ptr %p306, align 4, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot10, align 8
  store i64 %v307, ptr %slot43, align 8
  %v308 = load i64, ptr %slot43, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %ld310 = load i64, ptr %p309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld310, ptr %slot44, align 8
  %v311 = load i64, ptr %slot6, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i32 0, ptr %p312, align 4, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot4, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i32, ptr %p314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld315, ptr %slot45, align 8
  %v316 = load i32, ptr %slot45, align 8
  %cv317 = zext i32 %v316 to i64
  %cond318 = icmp ne i64 %cv317, 0
  br i1 %cond318, label %bb_rcslotdrop47, label %bb_rcslotdone47
bb_rcslotdrop47:
  %v319 = load i64, ptr %slot4, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot8, align 8
  store i64 %v321, ptr %slot46, align 8
  %v322 = load i64, ptr %slot5, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i32, ptr %p323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld324, ptr %slot47, align 8
  %v325 = load i32, ptr %slot47, align 8
  %op326 = and i32 %v325, 28
  store i32 %op326, ptr %slot48, align 8
  %v327 = load i32, ptr %slot48, align 8
  %cv328 = zext i32 %v327 to i64
  %cond329 = icmp ne i64 %cv328, 0
  br i1 %cond329, label %bb_rcslotrole47, label %bb_rcslotowner47
bb_rcslotrole47:
  %v330 = load i64, ptr %slot13, align 8
  store i64 %v330, ptr %slot49, align 8
  %v331 = load i64, ptr %slot46, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot50, align 8
  %v334 = load i64, ptr %slot50, align 8
  %cmp335 = icmp ne i64 %v334, 0
  %cv336 = zext i1 %cmp335 to i32
  store i32 %cv336, ptr %slot51, align 8
  %v337 = load i32, ptr %slot51, align 8
  %cv338 = zext i32 %v337 to i64
  %cond339 = icmp ne i64 %cv338, 0
  br i1 %cond339, label %bb_rcgnn63, label %bb_rcgdone63
bb_rcgnn63:
  %v340 = load i64, ptr %slot50, align 8
  %op341 = sub i64 %v340, 16
  store i64 %op341, ptr %slot52, align 8
  %v342 = load i64, ptr %slot50, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %rgep344 = getelementptr i8, ptr %p343, i64 -16
  %ld345 = load i64, ptr %rgep344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld345, ptr %slot53, align 8
  %v346 = load i64, ptr %slot53, align 8
  %op347 = and i64 %v346, 4611686018427387906
  store i64 %op347, ptr %slot54, align 8
  %v348 = load i64, ptr %slot54, align 8
  %cmp349 = icmp ne i64 %v348, 0
  %cv350 = zext i1 %cmp349 to i32
  store i32 %cv350, ptr %slot55, align 8
  %v351 = load i32, ptr %slot55, align 8
  %cv352 = zext i32 %v351 to i64
  %cond353 = icmp ne i64 %cv352, 0
  br i1 %cond353, label %bb_rcgclear63, label %bb_rcgcounted63
bb_rcgcounted63:
  %v354 = load i64, ptr %slot50, align 8
  %op355 = sub i64 %v354, 24
  store i64 %op355, ptr %slot56, align 8
  %v356 = load i64, ptr %slot50, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %rgep358 = getelementptr i8, ptr %p357, i64 -24
  %ld359 = load i64, ptr %rgep358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld359, ptr %slot57, align 8
  %v360 = load i64, ptr %slot57, align 8
  %op361 = sub i64 %v360, 1
  store i64 %op361, ptr %slot58, align 8
  %v362 = load i64, ptr %slot58, align 8
  %cmp363 = icmp eq i64 %v362, 0
  %cv364 = zext i1 %cmp363 to i32
  store i32 %cv364, ptr %slot59, align 8
  %v365 = load i32, ptr %slot59, align 8
  %cv366 = zext i32 %v365 to i64
  %cond367 = icmp ne i64 %cv366, 0
  br i1 %cond367, label %bb_rcglast63, label %bb_rcgdec63
bb_rcglast63:
  %v368 = load i64, ptr %slot50, align 8
  %op369 = sub i64 %v368, 32
  store i64 %op369, ptr %slot60, align 8
  %v370 = load i64, ptr %slot50, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %rgep372 = getelementptr i8, ptr %p371, i64 -32
  %ld373 = load i64, ptr %rgep372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld373, ptr %slot61, align 8
  %v374 = load i64, ptr %slot61, align 8
  %cmp375 = icmp ne i64 %v374, 0
  %cv376 = zext i1 %cmp375 to i32
  store i32 %cv376, ptr %slot62, align 8
  %v377 = load i32, ptr %slot62, align 8
  %cv378 = zext i32 %v377 to i64
  %cond379 = icmp ne i64 %cv378, 0
  br i1 %cond379, label %bb_rcgdec63, label %bb_rcgslow63
bb_rcgslow63:
  %v380 = load i64, ptr %slot49, align 8
  %v381 = load i64, ptr %slot46, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v380, i64 %v381) nomerge, !dbg !112
  br label %bb_rcgdone63
bb_rcgdec63:
  %v382 = load i64, ptr %slot58, align 8
  %v383 = load i64, ptr %slot50, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %rgep385 = getelementptr i8, ptr %p384, i64 -24
  store i64 %v382, ptr %rgep385, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear63
bb_rcgclear63:
  %v386 = load i64, ptr %slot46, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 0, ptr %p387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone63
bb_rcgdone63:
  br label %bb_rcslotdone47
bb_rcslotowner47:
  %v388 = load i64, ptr %slot13, align 8
  store i64 %v388, ptr %slot63, align 8
  %v389 = load i64, ptr %slot46, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i64, ptr %p390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld391, ptr %slot64, align 8
  %v392 = load i64, ptr %slot64, align 8
  %cmp393 = icmp ne i64 %v392, 0
  %cv394 = zext i1 %cmp393 to i32
  store i32 %cv394, ptr %slot65, align 8
  %v395 = load i32, ptr %slot65, align 8
  %cv396 = zext i32 %v395 to i64
  %cond397 = icmp ne i64 %cv396, 0
  br i1 %cond397, label %bb_rcgnn78, label %bb_rcgdone78
bb_rcgnn78:
  %v398 = load i64, ptr %slot64, align 8
  %op399 = sub i64 %v398, 16
  store i64 %op399, ptr %slot66, align 8
  %v400 = load i64, ptr %slot64, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %rgep402 = getelementptr i8, ptr %p401, i64 -16
  %ld403 = load i64, ptr %rgep402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld403, ptr %slot67, align 8
  %v404 = load i64, ptr %slot67, align 8
  %op405 = and i64 %v404, 4611686018427387906
  store i64 %op405, ptr %slot68, align 8
  %v406 = load i64, ptr %slot68, align 8
  %cmp407 = icmp ne i64 %v406, 0
  %cv408 = zext i1 %cmp407 to i32
  store i32 %cv408, ptr %slot69, align 8
  %v409 = load i32, ptr %slot69, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcgclear78, label %bb_rcgcounted78
bb_rcgcounted78:
  %v412 = load i64, ptr %slot64, align 8
  %op413 = sub i64 %v412, 32
  store i64 %op413, ptr %slot70, align 8
  %v414 = load i64, ptr %slot64, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %rgep416 = getelementptr i8, ptr %p415, i64 -32
  %ld417 = load i64, ptr %rgep416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld417, ptr %slot71, align 8
  %v418 = load i64, ptr %slot71, align 8
  %op419 = sub i64 %v418, 1
  store i64 %op419, ptr %slot72, align 8
  %v420 = load i64, ptr %slot72, align 8
  %cmp421 = icmp eq i64 %v420, 0
  %cv422 = zext i1 %cmp421 to i32
  store i32 %cv422, ptr %slot73, align 8
  %v423 = load i32, ptr %slot73, align 8
  %cv424 = zext i32 %v423 to i64
  %cond425 = icmp ne i64 %cv424, 0
  br i1 %cond425, label %bb_rcglast78, label %bb_rcgdec78
bb_rcglast78:
  %v426 = load i64, ptr %slot64, align 8
  %op427 = sub i64 %v426, 24
  store i64 %op427, ptr %slot74, align 8
  %v428 = load i64, ptr %slot64, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %rgep430 = getelementptr i8, ptr %p429, i64 -24
  %ld431 = load i64, ptr %rgep430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld431, ptr %slot75, align 8
  %v432 = load i64, ptr %slot75, align 8
  %cmp433 = icmp ne i64 %v432, 0
  %cv434 = zext i1 %cmp433 to i32
  store i32 %cv434, ptr %slot76, align 8
  %v435 = load i32, ptr %slot76, align 8
  %cv436 = zext i32 %v435 to i64
  %cond437 = icmp ne i64 %cv436, 0
  br i1 %cond437, label %bb_rcgdec78, label %bb_rcgslow78
bb_rcgslow78:
  %v438 = load i64, ptr %slot63, align 8
  %v439 = load i64, ptr %slot46, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v438, i64 %v439) nomerge, !dbg !112
  br label %bb_rcgdone78
bb_rcgdec78:
  %v440 = load i64, ptr %slot72, align 8
  %v441 = load i64, ptr %slot64, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %rgep443 = getelementptr i8, ptr %p442, i64 -32
  store i64 %v440, ptr %rgep443, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear78
bb_rcgclear78:
  %v444 = load i64, ptr %slot46, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 0, ptr %p445, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone78
bb_rcgdone78:
  br label %bb_rcslotdone47
bb_rcslotdone47:
  %v446 = load i64, ptr %slot44, align 8
  ret i64 %v446
bb_i4:
  %p447 = inttoptr i64 ptrtoint (ptr @myl_lit_ff31be7856a052d2c861e521018aab48cb0be45ce057542a48857eab12d1b524 to i64) to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !4, !noalias !3
  store i64 %ld448, ptr %slot77, align 8
  %v449 = load i64, ptr %slot77, align 8
  %v450 = load i64, ptr %slot12, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot12, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot78, align 8
  %v455 = load i64, ptr %slot78, align 8
  %v456 = load i64, ptr %slot9, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 %v455, ptr %p457, align 8, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot9, align 8
  store i64 %v458, ptr %slot79, align 8
  %v459 = load i64, ptr %slot10, align 8
  store i64 %v459, ptr %slot80, align 8
  %v460 = load i64, ptr %slot79, align 8
  %v461 = load i64, ptr %slot80, align 8
  %p462 = inttoptr i64 %v460 to ptr
  %p463 = inttoptr i64 %v461 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p463, ptr %p462, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot7, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i32 2, ptr %p465, align 4, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot6, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i32 1, ptr %p467, align 4, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot8, align 8
  store i64 %v468, ptr %slot81, align 8
  %v469 = load i64, ptr %slot10, align 8
  store i64 %v469, ptr %slot82, align 8
  %v470 = load i64, ptr %slot82, align 8
  %v471 = load i64, ptr %slot81, align 8
  %p472 = inttoptr i64 %v470 to ptr
  %p473 = inttoptr i64 %v471 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p473, ptr %p472, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot5, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 2, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot7, align 8
  %p477 = inttoptr i64 %v476 to ptr
  %ld478 = load i32, ptr %p477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld478, ptr %slot83, align 8
  %v479 = load i32, ptr %slot83, align 8
  %v480 = load i64, ptr %slot5, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 %v479, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot6, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot4, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 1, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot81, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %ld488 = load i64, ptr %p487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld488, ptr %slot84, align 8
  %v489 = load i64, ptr %slot84, align 8
  %v490 = load i64, ptr %slot12, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 %v489, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot12, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot85, align 8
  %v495 = load i64, ptr %slot12, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i64, ptr %p496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld497, ptr %slot86, align 8
  %v498 = load i64, ptr %slot86, align 8
  %v499 = load i64, ptr %slot9, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i64 %v498, ptr %p500, align 8, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot9, align 8
  store i64 %v501, ptr %slot87, align 8
  %v502 = load i64, ptr %slot10, align 8
  store i64 %v502, ptr %slot88, align 8
  %v503 = load i64, ptr %slot14, align 8
  store i64 %v503, ptr %slot89, align 8
  %v504 = load i64, ptr %slot87, align 8
  %p506 = inttoptr i64 %v504 to ptr
  %gep507 = getelementptr i8, ptr %p506, i64 0
  %op505 = ptrtoint ptr %gep507 to i64
  store i64 %op505, ptr %slot90, align 8
  %v508 = load i64, ptr %slot90, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i64, ptr %p509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld510, ptr %slot91, align 8
  %v511 = load i64, ptr %slot91, align 8
  %cmp512 = icmp ne i64 %v511, 0
  %cv513 = zext i1 %cmp512 to i32
  store i32 %cv513, ptr %slot92, align 8
  %v514 = load i32, ptr %slot92, align 8
  %cv515 = zext i32 %v514 to i64
  %cond516 = icmp ne i64 %cv515, 0
  br i1 %cond516, label %bb_rcmoveheader106, label %bb_rcmovenext106
bb_rcmoveheader106:
  %v517 = load i64, ptr %slot91, align 8
  %op518 = sub i64 %v517, 16
  store i64 %op518, ptr %slot93, align 8
  %v519 = load i64, ptr %slot91, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %rgep521 = getelementptr i8, ptr %p520, i64 -16
  %ld522 = load i64, ptr %rgep521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld522, ptr %slot94, align 8
  %v523 = load i64, ptr %slot94, align 8
  %op524 = and i64 %v523, 5764607523034234881
  store i64 %op524, ptr %slot95, align 8
  %v525 = load i64, ptr %slot95, align 8
  %cmp526 = icmp ne i64 %v525, 0
  %cv527 = zext i1 %cmp526 to i32
  store i32 %cv527, ptr %slot96, align 8
  %v528 = load i32, ptr %slot96, align 8
  %cv529 = zext i32 %v528 to i64
  %cond530 = icmp ne i64 %cv529, 0
  br i1 %cond530, label %bb_rcmoveslow103, label %bb_rcmovenext106
bb_rcmovenext106:
  %v531 = load i64, ptr %slot87, align 8
  %v532 = load i64, ptr %slot88, align 8
  %p533 = inttoptr i64 %v531 to ptr
  %p534 = inttoptr i64 %v532 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p534, ptr %p533, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot87, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i64 0, ptr %p536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved103
bb_rcmoveslow103:
  %v537 = load i64, ptr %slot13, align 8
  %v538 = load i64, ptr %slot88, align 8
  %v539 = load i64, ptr %slot87, align 8
  %v540 = load i64, ptr %slot89, align 8
  %cv541 = trunc i64 %v540 to i32
  %call542 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v537, i64 %v538, i64 %v539, i32 %cv541) nomerge, !dbg !114
  store i32 %call542, ptr %slot97, align 8
  %v543 = load i32, ptr %slot97, align 8
  %cv544 = zext i32 %v543 to i64
  %cond545 = icmp ne i64 %cv544, 0
  br i1 %cond545, label %bb_rcsuccess113, label %bb_rcfailure113
bb_rcfailure113:
  %v546 = load i64, ptr %slot13, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %call548 = call i32 @myl_rc_take_failure(ptr %p547) nomerge, !dbg !114
  store i32 %call548, ptr %slot98, align 8
  %v549 = load i64, ptr %slot1, align 8
  %p550 = inttoptr i64 %v549 to ptr
  %v551 = load i32, ptr %slot98, align 8
  %call552 = call i32 @myl_qbe_rc_status(ptr %p550, i32 %v551) nomerge, !dbg !114
  store i32 %call552, ptr %slot99, align 8
  br label %bb_failure
bb_rcsuccess113:
  br label %bb_rcmoved103
bb_rcmoved103:
  %v553 = load i64, ptr %slot4, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i32 0, ptr %p554, align 4, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot7, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i32 2, ptr %p556, align 4, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot6, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i32 1, ptr %p558, align 4, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot10, align 8
  store i64 %v559, ptr %slot100, align 8
  %v560 = load i64, ptr %slot100, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot101, align 8
  %v563 = load i64, ptr %slot6, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot4, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i32, ptr %p566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld567, ptr %slot102, align 8
  %v568 = load i32, ptr %slot102, align 8
  %cv569 = zext i32 %v568 to i64
  %cond570 = icmp ne i64 %cv569, 0
  br i1 %cond570, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v571 = load i64, ptr %slot4, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 0, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot8, align 8
  store i64 %v573, ptr %slot103, align 8
  %v574 = load i64, ptr %slot5, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %ld576 = load i32, ptr %p575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld576, ptr %slot104, align 8
  %v577 = load i32, ptr %slot104, align 8
  %op578 = and i32 %v577, 28
  store i32 %op578, ptr %slot105, align 8
  %v579 = load i32, ptr %slot105, align 8
  %cv580 = zext i32 %v579 to i64
  %cond581 = icmp ne i64 %cv580, 0
  br i1 %cond581, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v582 = load i64, ptr %slot13, align 8
  store i64 %v582, ptr %slot106, align 8
  %v583 = load i64, ptr %slot103, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot107, align 8
  %v586 = load i64, ptr %slot107, align 8
  %cmp587 = icmp ne i64 %v586, 0
  %cv588 = zext i1 %cmp587 to i32
  store i32 %cv588, ptr %slot108, align 8
  %v589 = load i32, ptr %slot108, align 8
  %cv590 = zext i32 %v589 to i64
  %cond591 = icmp ne i64 %cv590, 0
  br i1 %cond591, label %bb_rcgnn140, label %bb_rcgdone140
bb_rcgnn140:
  %v592 = load i64, ptr %slot107, align 8
  %op593 = sub i64 %v592, 16
  store i64 %op593, ptr %slot109, align 8
  %v594 = load i64, ptr %slot107, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %rgep596 = getelementptr i8, ptr %p595, i64 -16
  %ld597 = load i64, ptr %rgep596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld597, ptr %slot110, align 8
  %v598 = load i64, ptr %slot110, align 8
  %op599 = and i64 %v598, 4611686018427387906
  store i64 %op599, ptr %slot111, align 8
  %v600 = load i64, ptr %slot111, align 8
  %cmp601 = icmp ne i64 %v600, 0
  %cv602 = zext i1 %cmp601 to i32
  store i32 %cv602, ptr %slot112, align 8
  %v603 = load i32, ptr %slot112, align 8
  %cv604 = zext i32 %v603 to i64
  %cond605 = icmp ne i64 %cv604, 0
  br i1 %cond605, label %bb_rcgclear140, label %bb_rcgcounted140
bb_rcgcounted140:
  %v606 = load i64, ptr %slot107, align 8
  %op607 = sub i64 %v606, 24
  store i64 %op607, ptr %slot113, align 8
  %v608 = load i64, ptr %slot107, align 8
  %p609 = inttoptr i64 %v608 to ptr
  %rgep610 = getelementptr i8, ptr %p609, i64 -24
  %ld611 = load i64, ptr %rgep610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld611, ptr %slot114, align 8
  %v612 = load i64, ptr %slot114, align 8
  %op613 = sub i64 %v612, 1
  store i64 %op613, ptr %slot115, align 8
  %v614 = load i64, ptr %slot115, align 8
  %cmp615 = icmp eq i64 %v614, 0
  %cv616 = zext i1 %cmp615 to i32
  store i32 %cv616, ptr %slot116, align 8
  %v617 = load i32, ptr %slot116, align 8
  %cv618 = zext i32 %v617 to i64
  %cond619 = icmp ne i64 %cv618, 0
  br i1 %cond619, label %bb_rcglast140, label %bb_rcgdec140
bb_rcglast140:
  %v620 = load i64, ptr %slot107, align 8
  %op621 = sub i64 %v620, 32
  store i64 %op621, ptr %slot117, align 8
  %v622 = load i64, ptr %slot107, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %rgep624 = getelementptr i8, ptr %p623, i64 -32
  %ld625 = load i64, ptr %rgep624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld625, ptr %slot118, align 8
  %v626 = load i64, ptr %slot118, align 8
  %cmp627 = icmp ne i64 %v626, 0
  %cv628 = zext i1 %cmp627 to i32
  store i32 %cv628, ptr %slot119, align 8
  %v629 = load i32, ptr %slot119, align 8
  %cv630 = zext i32 %v629 to i64
  %cond631 = icmp ne i64 %cv630, 0
  br i1 %cond631, label %bb_rcgdec140, label %bb_rcgslow140
bb_rcgslow140:
  %v632 = load i64, ptr %slot106, align 8
  %v633 = load i64, ptr %slot103, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v632, i64 %v633) nomerge, !dbg !114
  br label %bb_rcgdone140
bb_rcgdec140:
  %v634 = load i64, ptr %slot115, align 8
  %v635 = load i64, ptr %slot107, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %rgep637 = getelementptr i8, ptr %p636, i64 -24
  store i64 %v634, ptr %rgep637, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear140
bb_rcgclear140:
  %v638 = load i64, ptr %slot103, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i64 0, ptr %p639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone140
bb_rcgdone140:
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v640 = load i64, ptr %slot13, align 8
  store i64 %v640, ptr %slot120, align 8
  %v641 = load i64, ptr %slot103, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i64, ptr %p642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld643, ptr %slot121, align 8
  %v644 = load i64, ptr %slot121, align 8
  %cmp645 = icmp ne i64 %v644, 0
  %cv646 = zext i1 %cmp645 to i32
  store i32 %cv646, ptr %slot122, align 8
  %v647 = load i32, ptr %slot122, align 8
  %cv648 = zext i32 %v647 to i64
  %cond649 = icmp ne i64 %cv648, 0
  br i1 %cond649, label %bb_rcgnn155, label %bb_rcgdone155
bb_rcgnn155:
  %v650 = load i64, ptr %slot121, align 8
  %op651 = sub i64 %v650, 16
  store i64 %op651, ptr %slot123, align 8
  %v652 = load i64, ptr %slot121, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %rgep654 = getelementptr i8, ptr %p653, i64 -16
  %ld655 = load i64, ptr %rgep654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld655, ptr %slot124, align 8
  %v656 = load i64, ptr %slot124, align 8
  %op657 = and i64 %v656, 4611686018427387906
  store i64 %op657, ptr %slot125, align 8
  %v658 = load i64, ptr %slot125, align 8
  %cmp659 = icmp ne i64 %v658, 0
  %cv660 = zext i1 %cmp659 to i32
  store i32 %cv660, ptr %slot126, align 8
  %v661 = load i32, ptr %slot126, align 8
  %cv662 = zext i32 %v661 to i64
  %cond663 = icmp ne i64 %cv662, 0
  br i1 %cond663, label %bb_rcgclear155, label %bb_rcgcounted155
bb_rcgcounted155:
  %v664 = load i64, ptr %slot121, align 8
  %op665 = sub i64 %v664, 32
  store i64 %op665, ptr %slot127, align 8
  %v666 = load i64, ptr %slot121, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %rgep668 = getelementptr i8, ptr %p667, i64 -32
  %ld669 = load i64, ptr %rgep668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld669, ptr %slot128, align 8
  %v670 = load i64, ptr %slot128, align 8
  %op671 = sub i64 %v670, 1
  store i64 %op671, ptr %slot129, align 8
  %v672 = load i64, ptr %slot129, align 8
  %cmp673 = icmp eq i64 %v672, 0
  %cv674 = zext i1 %cmp673 to i32
  store i32 %cv674, ptr %slot130, align 8
  %v675 = load i32, ptr %slot130, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcglast155, label %bb_rcgdec155
bb_rcglast155:
  %v678 = load i64, ptr %slot121, align 8
  %op679 = sub i64 %v678, 24
  store i64 %op679, ptr %slot131, align 8
  %v680 = load i64, ptr %slot121, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %rgep682 = getelementptr i8, ptr %p681, i64 -24
  %ld683 = load i64, ptr %rgep682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld683, ptr %slot132, align 8
  %v684 = load i64, ptr %slot132, align 8
  %cmp685 = icmp ne i64 %v684, 0
  %cv686 = zext i1 %cmp685 to i32
  store i32 %cv686, ptr %slot133, align 8
  %v687 = load i32, ptr %slot133, align 8
  %cv688 = zext i32 %v687 to i64
  %cond689 = icmp ne i64 %cv688, 0
  br i1 %cond689, label %bb_rcgdec155, label %bb_rcgslow155
bb_rcgslow155:
  %v690 = load i64, ptr %slot120, align 8
  %v691 = load i64, ptr %slot103, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v690, i64 %v691) nomerge, !dbg !114
  br label %bb_rcgdone155
bb_rcgdec155:
  %v692 = load i64, ptr %slot129, align 8
  %v693 = load i64, ptr %slot121, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %rgep695 = getelementptr i8, ptr %p694, i64 -32
  store i64 %v692, ptr %rgep695, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear155
bb_rcgclear155:
  %v696 = load i64, ptr %slot103, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 0, ptr %p697, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone155
bb_rcgdone155:
  br label %bb_rcslotdone124
bb_rcslotdone124:
  %v698 = load i64, ptr %slot101, align 8
  ret i64 %v698
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_93b8421369485a0f5f8b96ec84475c450ff74cc1971189c6e2c10d5614929e1f = external global i8, align 8
@myl_lit_ff31be7856a052d2c861e521018aab48cb0be45ce057542a48857eab12d1b524 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b", linkageName: "myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2417876426914359503, i64 0, !"myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
