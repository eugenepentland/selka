target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %callresult91 = alloca [48 x i8], align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i32, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i32, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i32, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i32, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i32, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i32, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i32, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i32, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i32, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i32, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i32, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i32, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i32, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i32, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i64, align 8
  %slot1488 = alloca i32, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i32, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i32, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i32, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i32, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i32, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i32, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i32, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i32, align 8
  %slot1529 = alloca i32, align 8
  %slot1530 = alloca i32, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i32, align 8
  %slot1533 = alloca i32, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i32, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i32, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i32, align 8
  %slot1545 = alloca i32, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i32, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i32, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i32, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i32, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i32, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i32, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i32, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i32, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i32, align 8
  %slot1585 = alloca i32, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i32, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i32, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i32, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i32, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i32, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i32, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i32, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i32, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i32, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i64, align 8
  %slot1619 = alloca i32, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i32, align 8
  %slot1631 = alloca i32, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i32, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i32, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i32, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i32, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i32, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i32, align 8
  %slot1654 = alloca i32, align 8
  %slot1655 = alloca i32, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i32, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i32, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i32, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i64, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i32, align 8
  %slot1684 = alloca i64, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i64, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i64, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i64, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i32, align 8
  %slot1699 = alloca i64, align 8
  %slot1700 = alloca i64, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i64, align 8
  %slot1704 = alloca i64, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i32, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i64, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i32, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i64, align 8
  %slot1722 = alloca i32, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i64, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i32, align 8
  %slot1727 = alloca i32, align 8
  %slot1728 = alloca i32, align 8
  %slot1729 = alloca i32, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i64, align 8
  %slot1732 = alloca i64, align 8
  %slot1733 = alloca i32, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i64, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i32, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i64, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i32, align 8
  %slot1742 = alloca i32, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i32, align 8
  %slot1745 = alloca i32, align 8
  %slot1746 = alloca i32, align 8
  %slot1747 = alloca i32, align 8
  %slot1748 = alloca i32, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i32, align 8
  %slot1751 = alloca i32, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i64, align 8
  %slot1754 = alloca i32, align 8
  %slot1755 = alloca i64, align 8
  %slot1756 = alloca i64, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i32, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i64, align 8
  %slot1762 = alloca i32, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i32, align 8
  %slot1766 = alloca i64, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i32, align 8
  %slot1769 = alloca i64, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i32, align 8
  %slot1773 = alloca i64, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i32, align 8
  %slot1777 = alloca i64, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i32, align 8
  %slot1780 = alloca i64, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i64, align 8
  %slot1783 = alloca i64, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i64, align 8
  %slot1787 = alloca i64, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i64, align 8
  %slot1790 = alloca i64, align 8
  %slot1791 = alloca i32, align 8
  %slot1792 = alloca i32, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i32, align 8
  %slot1795 = alloca i32, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i64, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i32, align 8
  %slot1801 = alloca i64, align 8
  %slot1802 = alloca i64, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i64, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i64, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i32, align 8
  %slot1812 = alloca i64, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i32, align 8
  %slot1815 = alloca i64, align 8
  %slot1816 = alloca i64, align 8
  %slot1817 = alloca i32, align 8
  %slot1818 = alloca i64, align 8
  %slot1819 = alloca i64, align 8
  %slot1820 = alloca i32, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i64, align 8
  %slot1823 = alloca i64, align 8
  %slot1824 = alloca i32, align 8
  %slot1825 = alloca i64, align 8
  %slot1826 = alloca i64, align 8
  %slot1827 = alloca i32, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i32, align 8
  %slot1831 = alloca i32, align 8
  %slot1832 = alloca i32, align 8
  %slot1833 = alloca i64, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i32, align 8
  %slot1836 = alloca i64, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i32, align 8
  %slot1840 = alloca i64, align 8
  %slot1841 = alloca i64, align 8
  %slot1842 = alloca i32, align 8
  %slot1843 = alloca i64, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i32, align 8
  %slot1846 = alloca i32, align 8
  %slot1847 = alloca i32, align 8
  %slot1848 = alloca i64, align 8
  %slot1849 = alloca i32, align 8
  %slot1850 = alloca i64, align 8
  %slot1851 = alloca i64, align 8
  %slot1852 = alloca i64, align 8
  %slot1853 = alloca i64, align 8
  %slot1854 = alloca i64, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i64, align 8
  %slot1857 = alloca i64, align 8
  %slot1858 = alloca i64, align 8
  %slot1859 = alloca i64, align 8
  %slot1860 = alloca i64, align 8
  %slot1861 = alloca i64, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i64, align 8
  %slot1864 = alloca i64, align 8
  %slot1865 = alloca i64, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i64, align 8
  %slot1868 = alloca i64, align 8
  %slot1869 = alloca i32, align 8
  %slot1870 = alloca i64, align 8
  %slot1871 = alloca i64, align 8
  %slot1872 = alloca i64, align 8
  %slot1873 = alloca i64, align 8
  %slot1874 = alloca i64, align 8
  %slot1875 = alloca i64, align 8
  %slot1876 = alloca i64, align 8
  %slot1877 = alloca i64, align 8
  %slot1878 = alloca i64, align 8
  %slot1879 = alloca i64, align 8
  %slot1880 = alloca i64, align 8
  %slot1881 = alloca i64, align 8
  %slot1882 = alloca i32, align 8
  %slot1883 = alloca i32, align 8
  %slot1884 = alloca i32, align 8
  %slot1885 = alloca i32, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i64, align 8
  %slot1888 = alloca i64, align 8
  %slot1889 = alloca i64, align 8
  %slot1890 = alloca i32, align 8
  %slot1891 = alloca i32, align 8
  %slot1892 = alloca i32, align 8
  %slot1893 = alloca i64, align 8
  %slot1894 = alloca i64, align 8
  %slot1895 = alloca i32, align 8
  %slot1896 = alloca i64, align 8
  %slot1897 = alloca i64, align 8
  %slot1898 = alloca i64, align 8
  %slot1899 = alloca i32, align 8
  %slot1900 = alloca i64, align 8
  %slot1901 = alloca i64, align 8
  %slot1902 = alloca i32, align 8
  %slot1903 = alloca i64, align 8
  %slot1904 = alloca i64, align 8
  %slot1905 = alloca i64, align 8
  %slot1906 = alloca i32, align 8
  %slot1907 = alloca i64, align 8
  %slot1908 = alloca i64, align 8
  %slot1909 = alloca i32, align 8
  %slot1910 = alloca i64, align 8
  %slot1911 = alloca i64, align 8
  %slot1912 = alloca i64, align 8
  %slot1913 = alloca i32, align 8
  %slot1914 = alloca i64, align 8
  %slot1915 = alloca i64, align 8
  %slot1916 = alloca i64, align 8
  %slot1917 = alloca i64, align 8
  %slot1918 = alloca i64, align 8
  %slot1919 = alloca i32, align 8
  %slot1920 = alloca i32, align 8
  %slot1921 = alloca i32, align 8
  %slot1922 = alloca i64, align 8
  %slot1923 = alloca i32, align 8
  %slot1924 = alloca i32, align 8
  %slot1925 = alloca i32, align 8
  %slot1926 = alloca i32, align 8
  %slot1927 = alloca i64, align 8
  %slot1928 = alloca i32, align 8
  %slot1929 = alloca i32, align 8
  %slot1930 = alloca i64, align 8
  %slot1931 = alloca i64, align 8
  %slot1932 = alloca i64, align 8
  %slot1933 = alloca i64, align 8
  %slot1934 = alloca i32, align 8
  %slot1935 = alloca i64, align 8
  %slot1936 = alloca i64, align 8
  %slot1937 = alloca i64, align 8
  %slot1938 = alloca i32, align 8
  %slot1939 = alloca i64, align 8
  %slot1940 = alloca i64, align 8
  %slot1941 = alloca i64, align 8
  %slot1942 = alloca i32, align 8
  %slot1943 = alloca i64, align 8
  %slot1944 = alloca i64, align 8
  %slot1945 = alloca i32, align 8
  %slot1946 = alloca i64, align 8
  %slot1947 = alloca i64, align 8
  %slot1948 = alloca i64, align 8
  %slot1949 = alloca i32, align 8
  %slot1950 = alloca i64, align 8
  %slot1951 = alloca i64, align 8
  %slot1952 = alloca i64, align 8
  %slot1953 = alloca i32, align 8
  %slot1954 = alloca i64, align 8
  %slot1955 = alloca i64, align 8
  %slot1956 = alloca i64, align 8
  %slot1957 = alloca i32, align 8
  %slot1958 = alloca i64, align 8
  %slot1959 = alloca i64, align 8
  %slot1960 = alloca i32, align 8
  %slot1961 = alloca i64, align 8
  %slot1962 = alloca i64, align 8
  %slot1963 = alloca i64, align 8
  %slot1964 = alloca i32, align 8
  %slot1965 = alloca i64, align 8
  %slot1966 = alloca i64, align 8
  %slot1967 = alloca i64, align 8
  %slot1968 = alloca i32, align 8
  %slot1969 = alloca i64, align 8
  %slot1970 = alloca i64, align 8
  %slot1971 = alloca i64, align 8
  %slot1972 = alloca i32, align 8
  %slot1973 = alloca i64, align 8
  %slot1974 = alloca i64, align 8
  %slot1975 = alloca i32, align 8
  %slot1976 = alloca i64, align 8
  %slot1977 = alloca i64, align 8
  %slot1978 = alloca i64, align 8
  %slot1979 = alloca i64, align 8
  %slot1980 = alloca i64, align 8
  %slot1981 = alloca i32, align 8
  %slot1982 = alloca i64, align 8
  %slot1983 = alloca i32, align 8
  %slot1984 = alloca i32, align 8
  %slot1985 = alloca i64, align 8
  %slot1986 = alloca i64, align 8
  %slot1987 = alloca i64, align 8
  %slot1988 = alloca i64, align 8
  %slot1989 = alloca i32, align 8
  %slot1990 = alloca i64, align 8
  %slot1991 = alloca i64, align 8
  %slot1992 = alloca i64, align 8
  %slot1993 = alloca i32, align 8
  %slot1994 = alloca i64, align 8
  %slot1995 = alloca i64, align 8
  %slot1996 = alloca i64, align 8
  %slot1997 = alloca i32, align 8
  %slot1998 = alloca i64, align 8
  %slot1999 = alloca i64, align 8
  %slot2000 = alloca i32, align 8
  %slot2001 = alloca i64, align 8
  %slot2002 = alloca i64, align 8
  %slot2003 = alloca i64, align 8
  %slot2004 = alloca i32, align 8
  %slot2005 = alloca i64, align 8
  %slot2006 = alloca i64, align 8
  %slot2007 = alloca i64, align 8
  %slot2008 = alloca i32, align 8
  %slot2009 = alloca i64, align 8
  %slot2010 = alloca i64, align 8
  %slot2011 = alloca i64, align 8
  %slot2012 = alloca i32, align 8
  %slot2013 = alloca i64, align 8
  %slot2014 = alloca i64, align 8
  %slot2015 = alloca i32, align 8
  %slot2016 = alloca i64, align 8
  %slot2017 = alloca i64, align 8
  %slot2018 = alloca i64, align 8
  %slot2019 = alloca i32, align 8
  %slot2020 = alloca i64, align 8
  %slot2021 = alloca i64, align 8
  %slot2022 = alloca i64, align 8
  %slot2023 = alloca i32, align 8
  %slot2024 = alloca i64, align 8
  %slot2025 = alloca i64, align 8
  %slot2026 = alloca i64, align 8
  %slot2027 = alloca i32, align 8
  %slot2028 = alloca i64, align 8
  %slot2029 = alloca i64, align 8
  %slot2030 = alloca i32, align 8
  %slot2031 = alloca i64, align 8
  %slot2032 = alloca i64, align 8
  %slot2033 = alloca i64, align 8
  %slot2034 = alloca i64, align 8
  %slot2035 = alloca i64, align 8
  %slot2036 = alloca i64, align 8
  %slot2037 = alloca i64, align 8
  %slot2038 = alloca i32, align 8
  %slot2039 = alloca i32, align 8
  %slot2040 = alloca i64, align 8
  %slot2041 = alloca i32, align 8
  %slot2042 = alloca i32, align 8
  %slot2043 = alloca i64, align 8
  %slot2044 = alloca i64, align 8
  %slot2045 = alloca i32, align 8
  %slot2046 = alloca i64, align 8
  %slot2047 = alloca i64, align 8
  %slot2048 = alloca i64, align 8
  %slot2049 = alloca i32, align 8
  %slot2050 = alloca i64, align 8
  %slot2051 = alloca i64, align 8
  %slot2052 = alloca i64, align 8
  %slot2053 = alloca i32, align 8
  %slot2054 = alloca i64, align 8
  %slot2055 = alloca i64, align 8
  %slot2056 = alloca i32, align 8
  %slot2057 = alloca i64, align 8
  %slot2058 = alloca i64, align 8
  %slot2059 = alloca i32, align 8
  %slot2060 = alloca i64, align 8
  %slot2061 = alloca i64, align 8
  %slot2062 = alloca i64, align 8
  %slot2063 = alloca i32, align 8
  %slot2064 = alloca i64, align 8
  %slot2065 = alloca i64, align 8
  %slot2066 = alloca i64, align 8
  %slot2067 = alloca i32, align 8
  %slot2068 = alloca i64, align 8
  %slot2069 = alloca i64, align 8
  %slot2070 = alloca i32, align 8
  %slot2071 = alloca i64, align 8
  %slot2072 = alloca i32, align 8
  %slot2073 = alloca i32, align 8
  %slot2074 = alloca i32, align 8
  %slot2075 = alloca i32, align 8
  %slot2076 = alloca i64, align 8
  %slot2077 = alloca i64, align 8
  %slot2078 = alloca i32, align 8
  %slot2079 = alloca i32, align 8
  %slot2080 = alloca i32, align 8
  %slot2081 = alloca i64, align 8
  %slot2082 = alloca i32, align 8
  %slot2083 = alloca i32, align 8
  %slot2084 = alloca i32, align 8
  %slot2085 = alloca i32, align 8
  %slot2086 = alloca i64, align 8
  %slot2087 = alloca i32, align 8
  %slot2088 = alloca i32, align 8
  %slot2089 = alloca i64, align 8
  %slot2090 = alloca i64, align 8
  %slot2091 = alloca i32, align 8
  %slot2092 = alloca i64, align 8
  %slot2093 = alloca i32, align 8
  %slot2094 = alloca i32, align 8
  %slot2095 = alloca i64, align 8
  %slot2096 = alloca i64, align 8
  %slot2097 = alloca i64, align 8
  %slot2098 = alloca i64, align 8
  %slot2099 = alloca i32, align 8
  %slot2100 = alloca i64, align 8
  %slot2101 = alloca i32, align 8
  %slot2102 = alloca i32, align 8
  %slot2103 = alloca i32, align 8
  %slot2104 = alloca i32, align 8
  %slot2105 = alloca i64, align 8
  %slot2106 = alloca i64, align 8
  %slot2107 = alloca i32, align 8
  %slot2108 = alloca i32, align 8
  %slot2109 = alloca i32, align 8
  %slot2110 = alloca i64, align 8
  %slot2111 = alloca i32, align 8
  %slot2112 = alloca i32, align 8
  %slot2113 = alloca i32, align 8
  %slot2114 = alloca i32, align 8
  %slot2115 = alloca i64, align 8
  %slot2116 = alloca i32, align 8
  %slot2117 = alloca i32, align 8
  %slot2118 = alloca i64, align 8
  %slot2119 = alloca i64, align 8
  %slot2120 = alloca i32, align 8
  %slot2121 = alloca i64, align 8
  %slot2122 = alloca i32, align 8
  %slot2123 = alloca i32, align 8
  %slot2124 = alloca i64, align 8
  %slot2125 = alloca i64, align 8
  %slot2126 = alloca i64, align 8
  %slot2127 = alloca i64, align 8
  %slot2128 = alloca i32, align 8
  %slot2129 = alloca i64, align 8
  %slot2130 = alloca i32, align 8
  %slot2131 = alloca i32, align 8
  %slot2132 = alloca i32, align 8
  %slot2133 = alloca i32, align 8
  %slot2134 = alloca i64, align 8
  %slot2135 = alloca i64, align 8
  %slot2136 = alloca i32, align 8
  %slot2137 = alloca i32, align 8
  %slot2138 = alloca i32, align 8
  %slot2139 = alloca i64, align 8
  %slot2140 = alloca i64, align 8
  %slot2141 = alloca i32, align 8
  %slot2142 = alloca i32, align 8
  %slot2143 = alloca i32, align 8
  %slot2144 = alloca i32, align 8
  %slot2145 = alloca i64, align 8
  %slot2146 = alloca i32, align 8
  %slot2147 = alloca i32, align 8
  %slot2148 = alloca i64, align 8
  %slot2149 = alloca i64, align 8
  %slot2150 = alloca i64, align 8
  %slot2151 = alloca i64, align 8
  %slot2152 = alloca i64, align 8
  %slot2153 = alloca i64, align 8
  %slot2154 = alloca i64, align 8
  %slot2155 = alloca i64, align 8
  %slot2156 = alloca i64, align 8
  %slot2157 = alloca i32, align 8
  %slot2158 = alloca i32, align 8
  %slot2159 = alloca i32, align 8
  %slot2160 = alloca i32, align 8
  %slot2161 = alloca i64, align 8
  %slot2162 = alloca i64, align 8
  %slot2163 = alloca i64, align 8
  %slot2164 = alloca i64, align 8
  %slot2165 = alloca i32, align 8
  %slot2166 = alloca i32, align 8
  %slot2167 = alloca i32, align 8
  %slot2168 = alloca i64, align 8
  %slot2169 = alloca i64, align 8
  %slot2170 = alloca i32, align 8
  %slot2171 = alloca i64, align 8
  %slot2172 = alloca i64, align 8
  %slot2173 = alloca i64, align 8
  %slot2174 = alloca i32, align 8
  %slot2175 = alloca i64, align 8
  %slot2176 = alloca i64, align 8
  %slot2177 = alloca i32, align 8
  %slot2178 = alloca i64, align 8
  %slot2179 = alloca i64, align 8
  %slot2180 = alloca i64, align 8
  %slot2181 = alloca i32, align 8
  %slot2182 = alloca i64, align 8
  %slot2183 = alloca i64, align 8
  %slot2184 = alloca i32, align 8
  %slot2185 = alloca i64, align 8
  %slot2186 = alloca i64, align 8
  %slot2187 = alloca i64, align 8
  %slot2188 = alloca i32, align 8
  %slot2189 = alloca i64, align 8
  %slot2190 = alloca i64, align 8
  %slot2191 = alloca i64, align 8
  %slot2192 = alloca i64, align 8
  %slot2193 = alloca i64, align 8
  %slot2194 = alloca i32, align 8
  %slot2195 = alloca i32, align 8
  %slot2196 = alloca i32, align 8
  %slot2197 = alloca i64, align 8
  %slot2198 = alloca i64, align 8
  %slot2199 = alloca i32, align 8
  %slot2200 = alloca i32, align 8
  %slot2201 = alloca i32, align 8
  %slot2202 = alloca i32, align 8
  %slot2203 = alloca i64, align 8
  %slot2204 = alloca i32, align 8
  %slot2205 = alloca i32, align 8
  %slot2206 = alloca i64, align 8
  %slot2207 = alloca i64, align 8
  %slot2208 = alloca i64, align 8
  %slot2209 = alloca i64, align 8
  %slot2210 = alloca i64, align 8
  %slot2211 = alloca i64, align 8
  %slot2212 = alloca i32, align 8
  %slot2213 = alloca i64, align 8
  %slot2214 = alloca i32, align 8
  %slot2215 = alloca i32, align 8
  %slot2216 = alloca i64, align 8
  %slot2217 = alloca i64, align 8
  %slot2218 = alloca i32, align 8
  %slot2219 = alloca i64, align 8
  %slot2220 = alloca i32, align 8
  %slot2221 = alloca i32, align 8
  %slot2222 = alloca i64, align 8
  %slot2223 = alloca i64, align 8
  %slot2224 = alloca i64, align 8
  %slot2225 = alloca i64, align 8
  %slot2226 = alloca i32, align 8
  %slot2227 = alloca i64, align 8
  %slot2228 = alloca i32, align 8
  %slot2229 = alloca i32, align 8
  %slot2230 = alloca i32, align 8
  %slot2231 = alloca i32, align 8
  %slot2232 = alloca i64, align 8
  %slot2233 = alloca i64, align 8
  %slot2234 = alloca i32, align 8
  %slot2235 = alloca i32, align 8
  %slot2236 = alloca i32, align 8
  %slot2237 = alloca i64, align 8
  %slot2238 = alloca i64, align 8
  %slot2239 = alloca i32, align 8
  %slot2240 = alloca i32, align 8
  %slot2241 = alloca i32, align 8
  %slot2242 = alloca i32, align 8
  %slot2243 = alloca i64, align 8
  %slot2244 = alloca i32, align 8
  %slot2245 = alloca i32, align 8
  %slot2246 = alloca i64, align 8
  %slot2247 = alloca i64, align 8
  %slot2248 = alloca i32, align 8
  %slot2249 = alloca i64, align 8
  %slot2250 = alloca i32, align 8
  %slot2251 = alloca i32, align 8
  %slot2252 = alloca i64, align 8
  %slot2253 = alloca i64, align 8
  %slot2254 = alloca i64, align 8
  %slot2255 = alloca i64, align 8
  %slot2256 = alloca i32, align 8
  %slot2257 = alloca i64, align 8
  %slot2258 = alloca i64, align 8
  %slot2259 = alloca i64, align 8
  %slot2260 = alloca i64, align 8
  %slot2261 = alloca i64, align 8
  %slot2262 = alloca i32, align 8
  %slot2263 = alloca i64, align 8
  %slot2264 = alloca i32, align 8
  %slot2265 = alloca i32, align 8
  %slot2266 = alloca i64, align 8
  %slot2267 = alloca i64, align 8
  %slot2268 = alloca i64, align 8
  %slot2269 = alloca i64, align 8
  %slot2270 = alloca i64, align 8
  %slot2271 = alloca i64, align 8
  %slot2272 = alloca i64, align 8
  %slot2273 = alloca i64, align 8
  %slot2274 = alloca i64, align 8
  %slot2275 = alloca i64, align 8
  %slot2276 = alloca i64, align 8
  %slot2277 = alloca i64, align 8
  %slot2278 = alloca i64, align 8
  %slot2279 = alloca i64, align 8
  %slot2280 = alloca i64, align 8
  %slot2281 = alloca i64, align 8
  %slot2282 = alloca i32, align 8
  %slot2283 = alloca i64, align 8
  %slot2284 = alloca i32, align 8
  %slot2285 = alloca i32, align 8
  %slot2286 = alloca i64, align 8
  %slot2287 = alloca i64, align 8
  %slot2288 = alloca i64, align 8
  %slot2289 = alloca i64, align 8
  %slot2290 = alloca i32, align 8
  %slot2291 = alloca i64, align 8
  %slot2292 = alloca i32, align 8
  %slot2293 = alloca i32, align 8
  %slot2294 = alloca i64, align 8
  %slot2295 = alloca i32, align 8
  %slot2296 = alloca i32, align 8
  %slot2297 = alloca i64, align 8
  %slot2298 = alloca i64, align 8
  %slot2299 = alloca i64, align 8
  %slot2300 = alloca i32, align 8
  %slot2301 = alloca i32, align 8
  %slot2302 = alloca i64, align 8
  %slot2303 = alloca i32, align 8
  %slot2304 = alloca i32, align 8
  %slot2305 = alloca i64, align 8
  %slot2306 = alloca i64, align 8
  %slot2307 = alloca i32, align 8
  %slot2308 = alloca i64, align 8
  %slot2309 = alloca i32, align 8
  %slot2310 = alloca i32, align 8
  %slot2311 = alloca i64, align 8
  %slot2312 = alloca i64, align 8
  %slot2313 = alloca i32, align 8
  %slot2314 = alloca i64, align 8
  %slot2315 = alloca i32, align 8
  %slot2316 = alloca i32, align 8
  %slot2317 = alloca i64, align 8
  %slot2318 = alloca i64, align 8
  %slot2319 = alloca i32, align 8
  %slot2320 = alloca i64, align 8
  %slot2321 = alloca i64, align 8
  %slot2322 = alloca i64, align 8
  %slot2323 = alloca i32, align 8
  %slot2324 = alloca i64, align 8
  %slot2325 = alloca i64, align 8
  %slot2326 = alloca i64, align 8
  %slot2327 = alloca i32, align 8
  %slot2328 = alloca i64, align 8
  %slot2329 = alloca i64, align 8
  %slot2330 = alloca i32, align 8
  %slot2331 = alloca i64, align 8
  %slot2332 = alloca i64, align 8
  %slot2333 = alloca i32, align 8
  %slot2334 = alloca i64, align 8
  %slot2335 = alloca i64, align 8
  %slot2336 = alloca i64, align 8
  %slot2337 = alloca i32, align 8
  %slot2338 = alloca i64, align 8
  %slot2339 = alloca i64, align 8
  %slot2340 = alloca i64, align 8
  %slot2341 = alloca i32, align 8
  %slot2342 = alloca i64, align 8
  %slot2343 = alloca i64, align 8
  %slot2344 = alloca i32, align 8
  %slot2345 = alloca i32, align 8
  %slot2346 = alloca i64, align 8
  %slot2347 = alloca i32, align 8
  %slot2348 = alloca i32, align 8
  %slot2349 = alloca i64, align 8
  %slot2350 = alloca i64, align 8
  %slot2351 = alloca i32, align 8
  %slot2352 = alloca i64, align 8
  %slot2353 = alloca i32, align 8
  %slot2354 = alloca i32, align 8
  %slot2355 = alloca i64, align 8
  %slot2356 = alloca i64, align 8
  %slot2357 = alloca i32, align 8
  %slot2358 = alloca i64, align 8
  %slot2359 = alloca i32, align 8
  %slot2360 = alloca i32, align 8
  %slot2361 = alloca i64, align 8
  %slot2362 = alloca i64, align 8
  %slot2363 = alloca i32, align 8
  %slot2364 = alloca i64, align 8
  %slot2365 = alloca i64, align 8
  %slot2366 = alloca i64, align 8
  %slot2367 = alloca i32, align 8
  %slot2368 = alloca i64, align 8
  %slot2369 = alloca i64, align 8
  %slot2370 = alloca i64, align 8
  %slot2371 = alloca i32, align 8
  %slot2372 = alloca i64, align 8
  %slot2373 = alloca i64, align 8
  %slot2374 = alloca i32, align 8
  %slot2375 = alloca i64, align 8
  %slot2376 = alloca i64, align 8
  %slot2377 = alloca i32, align 8
  %slot2378 = alloca i64, align 8
  %slot2379 = alloca i64, align 8
  %slot2380 = alloca i64, align 8
  %slot2381 = alloca i32, align 8
  %slot2382 = alloca i64, align 8
  %slot2383 = alloca i64, align 8
  %slot2384 = alloca i64, align 8
  %slot2385 = alloca i32, align 8
  %slot2386 = alloca i64, align 8
  %slot2387 = alloca i64, align 8
  %slot2388 = alloca i32, align 8
  %slot2389 = alloca i32, align 8
  %slot2390 = alloca i64, align 8
  %slot2391 = alloca i32, align 8
  %slot2392 = alloca i32, align 8
  %slot2393 = alloca i64, align 8
  %slot2394 = alloca i64, align 8
  %slot2395 = alloca i32, align 8
  %slot2396 = alloca i64, align 8
  %slot2397 = alloca i64, align 8
  %slot2398 = alloca i64, align 8
  %slot2399 = alloca i32, align 8
  %slot2400 = alloca i64, align 8
  %slot2401 = alloca i64, align 8
  %slot2402 = alloca i64, align 8
  %slot2403 = alloca i32, align 8
  %slot2404 = alloca i64, align 8
  %slot2405 = alloca i64, align 8
  %slot2406 = alloca i32, align 8
  %slot2407 = alloca i64, align 8
  %slot2408 = alloca i64, align 8
  %slot2409 = alloca i32, align 8
  %slot2410 = alloca i64, align 8
  %slot2411 = alloca i64, align 8
  %slot2412 = alloca i64, align 8
  %slot2413 = alloca i32, align 8
  %slot2414 = alloca i64, align 8
  %slot2415 = alloca i64, align 8
  %slot2416 = alloca i64, align 8
  %slot2417 = alloca i32, align 8
  %slot2418 = alloca i64, align 8
  %slot2419 = alloca i64, align 8
  %slot2420 = alloca i32, align 8
  %slot2421 = alloca i32, align 8
  %slot2422 = alloca i64, align 8
  %slot2423 = alloca i32, align 8
  %slot2424 = alloca i32, align 8
  %slot2425 = alloca i64, align 8
  %slot2426 = alloca i64, align 8
  %slot2427 = alloca i32, align 8
  %slot2428 = alloca i64, align 8
  %slot2429 = alloca i32, align 8
  %slot2430 = alloca i32, align 8
  %slot2431 = alloca i64, align 8
  %slot2432 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v2433 = load i64, ptr %slot1, align 8
  %op2434 = add i64 %v2433, 32
  store i64 %op2434, ptr %slot4, align 8
  %mem2435 = alloca i8, i64 8, align 8
  %ptr2436 = ptrtoint ptr %mem2435 to i64
  store i64 %ptr2436, ptr %slot5, align 8
  %mem2437 = alloca i8, i64 8, align 8
  %ptr2438 = ptrtoint ptr %mem2437 to i64
  store i64 %ptr2438, ptr %slot6, align 8
  %mem2439 = alloca i8, i64 8, align 8
  %ptr2440 = ptrtoint ptr %mem2439 to i64
  store i64 %ptr2440, ptr %slot7, align 8
  %mem2441 = alloca i8, i64 8, align 8
  %ptr2442 = ptrtoint ptr %mem2441 to i64
  store i64 %ptr2442, ptr %slot8, align 8
  %mem2443 = alloca i8, i64 8, align 8
  %ptr2444 = ptrtoint ptr %mem2443 to i64
  store i64 %ptr2444, ptr %slot9, align 8
  %mem2445 = alloca i8, i64 8, align 8
  %ptr2446 = ptrtoint ptr %mem2445 to i64
  store i64 %ptr2446, ptr %slot10, align 8
  %mem2447 = alloca i8, i64 8, align 8
  %ptr2448 = ptrtoint ptr %mem2447 to i64
  store i64 %ptr2448, ptr %slot11, align 8
  %mem2449 = alloca i8, i64 8, align 8
  %ptr2450 = ptrtoint ptr %mem2449 to i64
  store i64 %ptr2450, ptr %slot12, align 8
  %mem2451 = alloca i8, i64 8, align 8
  %ptr2452 = ptrtoint ptr %mem2451 to i64
  store i64 %ptr2452, ptr %slot13, align 8
  %mem2453 = alloca i8, i64 8, align 8
  %ptr2454 = ptrtoint ptr %mem2453 to i64
  store i64 %ptr2454, ptr %slot14, align 8
  %mem2455 = alloca i8, i64 8, align 8
  %ptr2456 = ptrtoint ptr %mem2455 to i64
  store i64 %ptr2456, ptr %slot15, align 8
  %mem2457 = alloca i8, i64 8, align 8
  %ptr2458 = ptrtoint ptr %mem2457 to i64
  store i64 %ptr2458, ptr %slot16, align 8
  %mem2459 = alloca i8, i64 8, align 8
  %ptr2460 = ptrtoint ptr %mem2459 to i64
  store i64 %ptr2460, ptr %slot17, align 8
  %mem2461 = alloca i8, i64 8, align 8
  %ptr2462 = ptrtoint ptr %mem2461 to i64
  store i64 %ptr2462, ptr %slot18, align 8
  %mem2463 = alloca i8, i64 8, align 8
  %ptr2464 = ptrtoint ptr %mem2463 to i64
  store i64 %ptr2464, ptr %slot19, align 8
  %mem2465 = alloca i8, i64 8, align 8
  %ptr2466 = ptrtoint ptr %mem2465 to i64
  store i64 %ptr2466, ptr %slot20, align 8
  %mem2467 = alloca i8, i64 8, align 8
  %ptr2468 = ptrtoint ptr %mem2467 to i64
  store i64 %ptr2468, ptr %slot21, align 8
  %mem2469 = alloca i8, i64 8, align 8
  %ptr2470 = ptrtoint ptr %mem2469 to i64
  store i64 %ptr2470, ptr %slot22, align 8
  %mem2471 = alloca i8, i64 8, align 8
  %ptr2472 = ptrtoint ptr %mem2471 to i64
  store i64 %ptr2472, ptr %slot23, align 8
  %mem2473 = alloca i8, i64 8, align 8
  %ptr2474 = ptrtoint ptr %mem2473 to i64
  store i64 %ptr2474, ptr %slot24, align 8
  %mem2475 = alloca i8, i64 8, align 8
  %ptr2476 = ptrtoint ptr %mem2475 to i64
  store i64 %ptr2476, ptr %slot25, align 8
  %mem2477 = alloca i8, i64 8, align 8
  %ptr2478 = ptrtoint ptr %mem2477 to i64
  store i64 %ptr2478, ptr %slot26, align 8
  %mem2479 = alloca i8, i64 8, align 8
  %ptr2480 = ptrtoint ptr %mem2479 to i64
  store i64 %ptr2480, ptr %slot27, align 8
  %mem2481 = alloca i8, i64 8, align 8
  %ptr2482 = ptrtoint ptr %mem2481 to i64
  store i64 %ptr2482, ptr %slot28, align 8
  %mem2483 = alloca i8, i64 8, align 8
  %ptr2484 = ptrtoint ptr %mem2483 to i64
  store i64 %ptr2484, ptr %slot29, align 8
  %mem2485 = alloca i8, i64 8, align 8
  %ptr2486 = ptrtoint ptr %mem2485 to i64
  store i64 %ptr2486, ptr %slot30, align 8
  %mem2487 = alloca i8, i64 8, align 8
  %ptr2488 = ptrtoint ptr %mem2487 to i64
  store i64 %ptr2488, ptr %slot31, align 8
  %mem2489 = alloca i8, i64 8, align 8
  %ptr2490 = ptrtoint ptr %mem2489 to i64
  store i64 %ptr2490, ptr %slot32, align 8
  %mem2491 = alloca i8, i64 8, align 8
  %ptr2492 = ptrtoint ptr %mem2491 to i64
  store i64 %ptr2492, ptr %slot33, align 8
  %mem2493 = alloca i8, i64 392, align 8
  %ptr2494 = ptrtoint ptr %mem2493 to i64
  store i64 %ptr2494, ptr %slot34, align 8
  %mem2495 = alloca i8, i64 392, align 8
  %ptr2496 = ptrtoint ptr %mem2495 to i64
  store i64 %ptr2496, ptr %slot35, align 8
  %mem2497 = alloca i8, i64 8, align 8
  %ptr2498 = ptrtoint ptr %mem2497 to i64
  store i64 %ptr2498, ptr %slot36, align 8
  %mem2499 = alloca i8, i64 8, align 8
  %ptr2500 = ptrtoint ptr %mem2499 to i64
  store i64 %ptr2500, ptr %slot37, align 8
  %mem2501 = alloca i8, i64 8, align 8
  %ptr2502 = ptrtoint ptr %mem2501 to i64
  store i64 %ptr2502, ptr %slot38, align 8
  %mem2503 = alloca i8, i64 8, align 8
  %ptr2504 = ptrtoint ptr %mem2503 to i64
  store i64 %ptr2504, ptr %slot39, align 8
  %mem2505 = alloca i8, i64 8, align 8
  %ptr2506 = ptrtoint ptr %mem2505 to i64
  store i64 %ptr2506, ptr %slot40, align 8
  %mem2507 = alloca i8, i64 8, align 8
  %ptr2508 = ptrtoint ptr %mem2507 to i64
  store i64 %ptr2508, ptr %slot41, align 8
  %mem2509 = alloca i8, i64 392, align 8
  %ptr2510 = ptrtoint ptr %mem2509 to i64
  store i64 %ptr2510, ptr %slot42, align 8
  %mem2511 = alloca i8, i64 8, align 8
  %ptr2512 = ptrtoint ptr %mem2511 to i64
  store i64 %ptr2512, ptr %slot43, align 8
  %mem2513 = alloca i8, i64 32, align 8
  %ptr2514 = ptrtoint ptr %mem2513 to i64
  store i64 %ptr2514, ptr %slot44, align 8
  %v2515 = load i64, ptr %slot44, align 8
  %p2517 = inttoptr i64 %v2515 to ptr
  %gep2518 = getelementptr i8, ptr %p2517, i64 24
  %op2516 = ptrtoint ptr %gep2518 to i64
  store i64 %op2516, ptr %slot45, align 8
  %v2519 = load i64, ptr %slot45, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i64 0, ptr %p2520, align 8, !alias.scope !3, !noalias !4
  %mem2521 = alloca i8, i64 32, align 8
  %ptr2522 = ptrtoint ptr %mem2521 to i64
  store i64 %ptr2522, ptr %slot46, align 8
  %v2523 = load i64, ptr %slot46, align 8
  %p2525 = inttoptr i64 %v2523 to ptr
  %gep2526 = getelementptr i8, ptr %p2525, i64 24
  %op2524 = ptrtoint ptr %gep2526 to i64
  store i64 %op2524, ptr %slot47, align 8
  %v2527 = load i64, ptr %slot47, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i64 0, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  %mem2529 = alloca i8, i64 32, align 8
  %ptr2530 = ptrtoint ptr %mem2529 to i64
  store i64 %ptr2530, ptr %slot48, align 8
  %v2531 = load i64, ptr %slot48, align 8
  %p2533 = inttoptr i64 %v2531 to ptr
  %gep2534 = getelementptr i8, ptr %p2533, i64 24
  %op2532 = ptrtoint ptr %gep2534 to i64
  store i64 %op2532, ptr %slot49, align 8
  %v2535 = load i64, ptr %slot49, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i64 0, ptr %p2536, align 8, !alias.scope !3, !noalias !4
  %mem2537 = alloca i8, i64 24, align 8
  %ptr2538 = ptrtoint ptr %mem2537 to i64
  store i64 %ptr2538, ptr %slot50, align 8
  %mem2539 = alloca i8, i64 8, align 8
  %ptr2540 = ptrtoint ptr %mem2539 to i64
  store i64 %ptr2540, ptr %slot51, align 8
  %mem2541 = alloca i8, i64 8, align 8
  %ptr2542 = ptrtoint ptr %mem2541 to i64
  store i64 %ptr2542, ptr %slot52, align 8
  %mem2543 = alloca i8, i64 48, align 8
  %ptr2544 = ptrtoint ptr %mem2543 to i64
  store i64 %ptr2544, ptr %slot53, align 8
  %mem2545 = alloca i8, i64 208, align 8
  %ptr2546 = ptrtoint ptr %mem2545 to i64
  store i64 %ptr2546, ptr %slot54, align 8
  %mem2547 = alloca i8, i64 8, align 8
  %ptr2548 = ptrtoint ptr %mem2547 to i64
  store i64 %ptr2548, ptr %slot55, align 8
  %mem2549 = alloca i8, i64 8, align 8
  %ptr2550 = ptrtoint ptr %mem2549 to i64
  store i64 %ptr2550, ptr %slot56, align 8
  %mem2551 = alloca i8, i64 8, align 8
  %ptr2552 = ptrtoint ptr %mem2551 to i64
  store i64 %ptr2552, ptr %slot57, align 8
  %mem2553 = alloca i8, i64 8, align 8
  %ptr2554 = ptrtoint ptr %mem2553 to i64
  store i64 %ptr2554, ptr %slot58, align 8
  %mem2555 = alloca i8, i64 88, align 8
  %ptr2556 = ptrtoint ptr %mem2555 to i64
  store i64 %ptr2556, ptr %slot59, align 8
  %mem2557 = alloca i8, i64 8, align 8
  %ptr2558 = ptrtoint ptr %mem2557 to i64
  store i64 %ptr2558, ptr %slot60, align 8
  %mem2559 = alloca i8, i64 208, align 8
  %ptr2560 = ptrtoint ptr %mem2559 to i64
  store i64 %ptr2560, ptr %slot61, align 8
  %mem2561 = alloca i8, i64 8, align 8
  %ptr2562 = ptrtoint ptr %mem2561 to i64
  store i64 %ptr2562, ptr %slot62, align 8
  %mem2563 = alloca i8, i64 8, align 8
  %ptr2564 = ptrtoint ptr %mem2563 to i64
  store i64 %ptr2564, ptr %slot63, align 8
  %mem2565 = alloca i8, i64 8, align 8
  %ptr2566 = ptrtoint ptr %mem2565 to i64
  store i64 %ptr2566, ptr %slot64, align 8
  %mem2567 = alloca i8, i64 88, align 8
  %ptr2568 = ptrtoint ptr %mem2567 to i64
  store i64 %ptr2568, ptr %slot65, align 8
  %mem2569 = alloca i8, i64 48, align 8
  %ptr2570 = ptrtoint ptr %mem2569 to i64
  store i64 %ptr2570, ptr %slot66, align 8
  %mem2571 = alloca i8, i64 8, align 8
  %ptr2572 = ptrtoint ptr %mem2571 to i64
  store i64 %ptr2572, ptr %slot67, align 8
  %mem2573 = alloca i8, i64 8, align 8
  %ptr2574 = ptrtoint ptr %mem2573 to i64
  store i64 %ptr2574, ptr %slot68, align 8
  %mem2575 = alloca i8, i64 8, align 8
  %ptr2576 = ptrtoint ptr %mem2575 to i64
  store i64 %ptr2576, ptr %slot69, align 8
  %mem2577 = alloca i8, i64 8, align 8
  %ptr2578 = ptrtoint ptr %mem2577 to i64
  store i64 %ptr2578, ptr %slot70, align 8
  %mem2579 = alloca i8, i64 8, align 8
  %ptr2580 = ptrtoint ptr %mem2579 to i64
  store i64 %ptr2580, ptr %slot71, align 8
  %mem2581 = alloca i8, i64 8, align 8
  %ptr2582 = ptrtoint ptr %mem2581 to i64
  store i64 %ptr2582, ptr %slot72, align 8
  %mem2583 = alloca i8, i64 8, align 8
  %ptr2584 = ptrtoint ptr %mem2583 to i64
  store i64 %ptr2584, ptr %slot73, align 8
  %mem2585 = alloca i8, i64 392, align 8
  %ptr2586 = ptrtoint ptr %mem2585 to i64
  store i64 %ptr2586, ptr %slot74, align 8
  %mem2587 = alloca i8, i64 208, align 8
  %ptr2588 = ptrtoint ptr %mem2587 to i64
  store i64 %ptr2588, ptr %slot75, align 8
  %mem2589 = alloca i8, i64 88, align 8
  %ptr2590 = ptrtoint ptr %mem2589 to i64
  store i64 %ptr2590, ptr %slot76, align 8
  %mem2591 = alloca i8, i64 8, align 8
  %ptr2592 = ptrtoint ptr %mem2591 to i64
  store i64 %ptr2592, ptr %slot77, align 8
  %mem2593 = alloca i8, i64 392, align 8
  %ptr2594 = ptrtoint ptr %mem2593 to i64
  store i64 %ptr2594, ptr %slot78, align 8
  %mem2595 = alloca i8, i64 8, align 8
  %ptr2596 = ptrtoint ptr %mem2595 to i64
  store i64 %ptr2596, ptr %slot79, align 8
  %mem2597 = alloca i8, i64 24, align 8
  %ptr2598 = ptrtoint ptr %mem2597 to i64
  store i64 %ptr2598, ptr %slot80, align 8
  %mem2599 = alloca i8, i64 88, align 8
  %ptr2600 = ptrtoint ptr %mem2599 to i64
  store i64 %ptr2600, ptr %slot81, align 8
  %mem2601 = alloca i8, i64 88, align 8
  %ptr2602 = ptrtoint ptr %mem2601 to i64
  store i64 %ptr2602, ptr %slot82, align 8
  %mem2603 = alloca i8, i64 392, align 8
  %ptr2604 = ptrtoint ptr %mem2603 to i64
  store i64 %ptr2604, ptr %slot83, align 8
  br label %bb_frameadmit3
bb_frameadmit3:
  %mem2605 = alloca i8, i64 8, align 8
  %ptr2606 = ptrtoint ptr %mem2605 to i64
  store i64 %ptr2606, ptr %slot84, align 8
  %v2607 = load i64, ptr %slot1, align 8
  %op2608 = add i64 %v2607, 64
  store i64 %op2608, ptr %slot85, align 8
  %v2609 = load i64, ptr %slot85, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %ld2611 = load i64, ptr %p2610, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2611, ptr %slot86, align 8
  %stack2612 = call ptr @llvm.stacksave()
  %stackaddr2613 = ptrtoint ptr %stack2612 to i64
  %v2614 = load i64, ptr %slot86, align 8
  %cmp2615 = icmp ult i64 %stackaddr2613, %v2614
  %cv2616 = zext i1 %cmp2615 to i64
  store i64 %cv2616, ptr %slot87, align 8
  %v2617 = load i64, ptr %slot87, align 8
  %cond2618 = icmp ne i64 %v2617, 0
  br i1 %cond2618, label %bb_floorfail5, label %bb_stackadmit4
bb_floorfail5:
  %v2619 = load i64, ptr %slot1, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  call void @myl_qbe_fail_frame(ptr %p2620) nomerge, !dbg !110
  unreachable
bb_stackadmit4:
  %v2621 = load i64, ptr %slot56, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  store i64 0, ptr %p2622, align 8, !alias.scope !3, !noalias !4
  %v2623 = load i64, ptr %slot57, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  store i64 0, ptr %p2624, align 8, !alias.scope !3, !noalias !4
  %v2625 = load i64, ptr %slot58, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 0, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  %v2627 = load i64, ptr %slot60, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  store i64 0, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot63, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i64 0, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot64, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  store i64 0, ptr %p2632, align 8, !alias.scope !3, !noalias !4
  %v2633 = load i64, ptr %slot67, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i64 0, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  %v2635 = load i64, ptr %slot2, align 8
  %v2636 = load i64, ptr %slot51, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  store i64 %v2635, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  %v2638 = load i64, ptr %slot3, align 8
  %v2639 = load i64, ptr %slot52, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i64 %v2638, ptr %p2640, align 8, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot1, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %call2643 = call ptr @myl_qbe_heap(ptr %p2642) nomerge, !dbg !112
  %calladdr2644 = ptrtoint ptr %call2643 to i64
  store i64 %calladdr2644, ptr %slot88, align 8
  %v2645 = load i64, ptr %slot1, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  %call2647 = call i64 @myl_qbe_region_mark(ptr %p2646) nomerge, !dbg !112
  store i64 %call2647, ptr %slot89, align 8
  %v2648 = load i64, ptr %slot5, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i32 0, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot6, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i32 0, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot7, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i32 0, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  %v2654 = load i64, ptr %slot8, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  store i32 0, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  %v2656 = load i64, ptr %slot9, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  store i32 0, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  %v2658 = load i64, ptr %slot10, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  store i32 0, ptr %p2659, align 4, !alias.scope !3, !noalias !4
  %v2660 = load i64, ptr %slot11, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  store i32 0, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  %v2662 = load i64, ptr %slot12, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  store i32 0, ptr %p2663, align 4, !alias.scope !3, !noalias !4
  %v2664 = load i64, ptr %slot13, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  store i32 0, ptr %p2665, align 4, !alias.scope !3, !noalias !4
  %v2666 = load i64, ptr %slot14, align 8
  %p2667 = inttoptr i64 %v2666 to ptr
  store i32 0, ptr %p2667, align 4, !alias.scope !3, !noalias !4
  %v2668 = load i64, ptr %slot15, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  store i32 0, ptr %p2669, align 4, !alias.scope !3, !noalias !4
  %v2670 = load i64, ptr %slot16, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i32 0, ptr %p2671, align 4, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot17, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  store i32 0, ptr %p2673, align 4, !alias.scope !3, !noalias !4
  %v2674 = load i64, ptr %slot18, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i32 0, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot19, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 0, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot20, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  store i32 0, ptr %p2679, align 4, !alias.scope !3, !noalias !4
  %v2680 = load i64, ptr %slot21, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i32 0, ptr %p2681, align 4, !alias.scope !3, !noalias !4
  %v2682 = load i64, ptr %slot22, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i32 0, ptr %p2683, align 4, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot23, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i32 0, ptr %p2685, align 4, !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot24, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  store i32 0, ptr %p2687, align 4, !alias.scope !3, !noalias !4
  %v2688 = load i64, ptr %slot25, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i32 0, ptr %p2689, align 4, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot26, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i32 0, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot27, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i32 0, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot28, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i32 0, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot29, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i32 0, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot30, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 0, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  %v2700 = load i64, ptr %slot31, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  store i32 0, ptr %p2701, align 4, !alias.scope !3, !noalias !4
  %v2702 = load i64, ptr %slot32, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  store i32 0, ptr %p2703, align 4, !alias.scope !3, !noalias !4
  %v2704 = load i64, ptr %slot33, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i32 0, ptr %p2705, align 4, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot6, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i32 2, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot8, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  store i32 2, ptr %p2709, align 4, !alias.scope !3, !noalias !4
  %v2710 = load i64, ptr %slot10, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  store i32 2, ptr %p2711, align 4, !alias.scope !3, !noalias !4
  %v2712 = load i64, ptr %slot12, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  store i32 2, ptr %p2713, align 4, !alias.scope !3, !noalias !4
  %v2714 = load i64, ptr %slot14, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  store i32 2, ptr %p2715, align 4, !alias.scope !3, !noalias !4
  %v2716 = load i64, ptr %slot16, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  store i32 2, ptr %p2717, align 4, !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot18, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  store i32 2, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  %v2720 = load i64, ptr %slot20, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  store i32 2, ptr %p2721, align 4, !alias.scope !3, !noalias !4
  %v2722 = load i64, ptr %slot22, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  store i32 2, ptr %p2723, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v2724 = load i64, ptr %slot1, align 8
  call void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8 %callresult91, i64 %v2724) nomerge, !dbg !112
  %addr2725 = ptrtoint ptr %callresult91 to i64
  store i64 %addr2725, ptr %slot90, align 8
  %v2726 = load i64, ptr %slot90, align 8
  %v2727 = load i64, ptr %slot68, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  store i64 %v2726, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  %v2729 = load i64, ptr %slot68, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %ld2731 = load i64, ptr %p2730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2731, ptr %slot92, align 8
  %v2732 = load i64, ptr %slot42, align 8
  store i64 %v2732, ptr %slot93, align 8
  %v2733 = load i64, ptr %slot92, align 8
  %v2734 = load i64, ptr %slot93, align 8
  %p2735 = inttoptr i64 %v2733 to ptr
  %p2736 = inttoptr i64 %v2734 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2736, ptr %p2735, i64 48, i1 false)
  %v2737 = load i64, ptr %slot32, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i32 2, ptr %p2738, align 4, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot31, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  store i32 1, ptr %p2740, align 4, !alias.scope !3, !noalias !4
  %v2741 = load i64, ptr %slot34, align 8
  store i64 %v2741, ptr %slot94, align 8
  %v2742 = load i64, ptr %slot42, align 8
  store i64 %v2742, ptr %slot95, align 8
  %v2743 = load i64, ptr %slot95, align 8
  %v2744 = load i64, ptr %slot94, align 8
  %p2745 = inttoptr i64 %v2743 to ptr
  %p2746 = inttoptr i64 %v2744 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2746, ptr %p2745, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2747 = load i64, ptr %slot24, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i32 2, ptr %p2748, align 4, !alias.scope !3, !noalias !4
  %v2749 = load i64, ptr %slot32, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %ld2751 = load i32, ptr %p2750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2751, ptr %slot96, align 8
  %v2752 = load i32, ptr %slot96, align 8
  %v2753 = load i64, ptr %slot24, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i32 %v2752, ptr %p2754, align 4, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot31, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  store i32 0, ptr %p2756, align 4, !alias.scope !3, !noalias !4
  %v2757 = load i64, ptr %slot23, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i32 1, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  %v2759 = load i64, ptr %slot94, align 8
  %v2760 = load i64, ptr %slot68, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  store i64 %v2759, ptr %p2761, align 8, !alias.scope !3, !noalias !4
  %v2762 = load i64, ptr %slot68, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  %ld2764 = load i64, ptr %p2763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2764, ptr %slot97, align 8
  %v2765 = load i64, ptr %slot42, align 8
  store i64 %v2765, ptr %slot98, align 8
  %v2766 = load i64, ptr %slot89, align 8
  store i64 %v2766, ptr %slot99, align 8
  %v2767 = load i64, ptr %slot97, align 8
  %op2768 = add i64 %v2767, 16
  store i64 %op2768, ptr %slot100, align 8
  %v2769 = load i64, ptr %slot100, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %ld2771 = load i64, ptr %p2770, align 8
  store i64 %ld2771, ptr %slot101, align 8
  %v2772 = load i64, ptr %slot101, align 8
  %cmp2773 = icmp ne i64 %v2772, 0
  %cv2774 = zext i1 %cmp2773 to i32
  store i32 %cv2774, ptr %slot102, align 8
  %v2775 = load i32, ptr %slot102, align 8
  %cv2776 = zext i32 %v2775 to i64
  %cond2777 = icmp ne i64 %cv2776, 0
  br i1 %cond2777, label %bb_rcmoveheader48, label %bb_rcmovenext48
bb_rcmoveheader48:
  %v2778 = load i64, ptr %slot101, align 8
  %op2779 = sub i64 %v2778, 16
  store i64 %op2779, ptr %slot103, align 8
  %v2780 = load i64, ptr %slot101, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  %rgep2782 = getelementptr i8, ptr %p2781, i64 -16
  %ld2783 = load i64, ptr %rgep2782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2783, ptr %slot104, align 8
  %v2784 = load i64, ptr %slot104, align 8
  %op2785 = and i64 %v2784, 5764607523034234881
  store i64 %op2785, ptr %slot105, align 8
  %v2786 = load i64, ptr %slot105, align 8
  %cmp2787 = icmp ne i64 %v2786, 0
  %cv2788 = zext i1 %cmp2787 to i32
  store i32 %cv2788, ptr %slot106, align 8
  %v2789 = load i32, ptr %slot106, align 8
  %cv2790 = zext i32 %v2789 to i64
  %cond2791 = icmp ne i64 %cv2790, 0
  br i1 %cond2791, label %bb_rcmoveslow45, label %bb_rcmovenext48
bb_rcmovenext48:
  %v2792 = load i64, ptr %slot97, align 8
  %op2793 = add i64 %v2792, 24
  store i64 %op2793, ptr %slot107, align 8
  %v2794 = load i64, ptr %slot107, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %ld2796 = load i64, ptr %p2795, align 8
  store i64 %ld2796, ptr %slot108, align 8
  %v2797 = load i64, ptr %slot108, align 8
  %cmp2798 = icmp ne i64 %v2797, 0
  %cv2799 = zext i1 %cmp2798 to i32
  store i32 %cv2799, ptr %slot109, align 8
  %v2800 = load i32, ptr %slot109, align 8
  %cv2801 = zext i32 %v2800 to i64
  %cond2802 = icmp ne i64 %cv2801, 0
  br i1 %cond2802, label %bb_rcmoveheader56, label %bb_rcmovenext56
bb_rcmoveheader56:
  %v2803 = load i64, ptr %slot108, align 8
  %op2804 = sub i64 %v2803, 16
  store i64 %op2804, ptr %slot110, align 8
  %v2805 = load i64, ptr %slot108, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %rgep2807 = getelementptr i8, ptr %p2806, i64 -16
  %ld2808 = load i64, ptr %rgep2807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2808, ptr %slot111, align 8
  %v2809 = load i64, ptr %slot111, align 8
  %op2810 = and i64 %v2809, 5764607523034234881
  store i64 %op2810, ptr %slot112, align 8
  %v2811 = load i64, ptr %slot112, align 8
  %cmp2812 = icmp ne i64 %v2811, 0
  %cv2813 = zext i1 %cmp2812 to i32
  store i32 %cv2813, ptr %slot113, align 8
  %v2814 = load i32, ptr %slot113, align 8
  %cv2815 = zext i32 %v2814 to i64
  %cond2816 = icmp ne i64 %cv2815, 0
  br i1 %cond2816, label %bb_rcmoveslow45, label %bb_rcmovenext56
bb_rcmovenext56:
  %v2817 = load i64, ptr %slot97, align 8
  %op2818 = add i64 %v2817, 32
  store i64 %op2818, ptr %slot114, align 8
  %v2819 = load i64, ptr %slot114, align 8
  %p2820 = inttoptr i64 %v2819 to ptr
  %ld2821 = load i64, ptr %p2820, align 8
  store i64 %ld2821, ptr %slot115, align 8
  %v2822 = load i64, ptr %slot115, align 8
  %cmp2823 = icmp ne i64 %v2822, 0
  %cv2824 = zext i1 %cmp2823 to i32
  store i32 %cv2824, ptr %slot116, align 8
  %v2825 = load i32, ptr %slot116, align 8
  %cv2826 = zext i32 %v2825 to i64
  %cond2827 = icmp ne i64 %cv2826, 0
  br i1 %cond2827, label %bb_rcmoveheader64, label %bb_rcmovenext64
bb_rcmoveheader64:
  %v2828 = load i64, ptr %slot115, align 8
  %op2829 = sub i64 %v2828, 16
  store i64 %op2829, ptr %slot117, align 8
  %v2830 = load i64, ptr %slot115, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %rgep2832 = getelementptr i8, ptr %p2831, i64 -16
  %ld2833 = load i64, ptr %rgep2832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2833, ptr %slot118, align 8
  %v2834 = load i64, ptr %slot118, align 8
  %op2835 = and i64 %v2834, 5764607523034234881
  store i64 %op2835, ptr %slot119, align 8
  %v2836 = load i64, ptr %slot119, align 8
  %cmp2837 = icmp ne i64 %v2836, 0
  %cv2838 = zext i1 %cmp2837 to i32
  store i32 %cv2838, ptr %slot120, align 8
  %v2839 = load i32, ptr %slot120, align 8
  %cv2840 = zext i32 %v2839 to i64
  %cond2841 = icmp ne i64 %cv2840, 0
  br i1 %cond2841, label %bb_rcmoveslow45, label %bb_rcmovenext64
bb_rcmovenext64:
  %v2842 = load i64, ptr %slot97, align 8
  %v2843 = load i64, ptr %slot98, align 8
  %p2844 = inttoptr i64 %v2842 to ptr
  %p2845 = inttoptr i64 %v2843 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2845, ptr %p2844, i64 48, i1 false)
  %v2846 = load i64, ptr %slot97, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i64 0, ptr %p2847, align 8
  %v2848 = load i64, ptr %slot97, align 8
  %op2849 = add i64 %v2848, 8
  store i64 %op2849, ptr %slot121, align 8
  %v2850 = load i64, ptr %slot121, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  store i64 0, ptr %p2851, align 8
  %v2852 = load i64, ptr %slot97, align 8
  %op2853 = add i64 %v2852, 16
  store i64 %op2853, ptr %slot122, align 8
  %v2854 = load i64, ptr %slot122, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  store i64 0, ptr %p2855, align 8
  %v2856 = load i64, ptr %slot97, align 8
  %op2857 = add i64 %v2856, 24
  store i64 %op2857, ptr %slot123, align 8
  %v2858 = load i64, ptr %slot123, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i64 0, ptr %p2859, align 8
  %v2860 = load i64, ptr %slot97, align 8
  %op2861 = add i64 %v2860, 32
  store i64 %op2861, ptr %slot124, align 8
  %v2862 = load i64, ptr %slot124, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i64 0, ptr %p2863, align 8
  %v2864 = load i64, ptr %slot97, align 8
  %op2865 = add i64 %v2864, 40
  store i64 %op2865, ptr %slot125, align 8
  %v2866 = load i64, ptr %slot125, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i64 0, ptr %p2867, align 8
  br label %bb_rcmoved45
bb_rcmoveslow45:
  %v2868 = load i64, ptr %slot88, align 8
  %v2869 = load i64, ptr %slot98, align 8
  %v2870 = load i64, ptr %slot97, align 8
  %v2871 = load i64, ptr %slot99, align 8
  %cv2872 = trunc i64 %v2871 to i32
  %call2873 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2868, i64 %v2869, i64 %v2870, i32 %cv2872) nomerge, !dbg !114
  store i32 %call2873, ptr %slot126, align 8
  %v2874 = load i32, ptr %slot126, align 8
  %cv2875 = zext i32 %v2874 to i64
  %cond2876 = icmp ne i64 %cv2875, 0
  br i1 %cond2876, label %bb_rcsuccess76, label %bb_rcfailure76
bb_rcfailure76:
  %v2877 = load i64, ptr %slot88, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %call2879 = call i32 @myl_rc_take_failure(ptr %p2878) nomerge, !dbg !114
  store i32 %call2879, ptr %slot127, align 8
  %v2880 = load i64, ptr %slot1, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %v2882 = load i32, ptr %slot127, align 8
  %call2883 = call i32 @myl_qbe_rc_status(ptr %p2881, i32 %v2882) nomerge, !dbg !114
  store i32 %call2883, ptr %slot128, align 8
  br label %bb_failure
bb_rcsuccess76:
  br label %bb_rcmoved45
bb_rcmoved45:
  %v2884 = load i64, ptr %slot23, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  store i32 0, ptr %p2885, align 4, !alias.scope !3, !noalias !4
  %v2886 = load i64, ptr %slot32, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  store i32 2, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  %v2888 = load i64, ptr %slot31, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  store i32 1, ptr %p2889, align 4, !alias.scope !3, !noalias !4
  %v2890 = load i64, ptr %slot5, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %ld2892 = load i32, ptr %p2891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2892, ptr %slot129, align 8
  %v2893 = load i32, ptr %slot129, align 8
  %cv2894 = zext i32 %v2893 to i64
  %cond2895 = icmp ne i64 %cv2894, 0
  br i1 %cond2895, label %bb_rcslotdrop85, label %bb_rcslotdone85
bb_rcslotdrop85:
  %v2896 = load i64, ptr %slot5, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  store i32 0, ptr %p2897, align 4, !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot53, align 8
  store i64 %v2898, ptr %slot130, align 8
  %v2899 = load i64, ptr %slot6, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %ld2901 = load i32, ptr %p2900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2901, ptr %slot131, align 8
  %v2902 = load i32, ptr %slot131, align 8
  %op2903 = and i32 %v2902, 28
  store i32 %op2903, ptr %slot132, align 8
  %v2904 = load i32, ptr %slot132, align 8
  %cv2905 = zext i32 %v2904 to i64
  %cond2906 = icmp ne i64 %cv2905, 0
  br i1 %cond2906, label %bb_rcslotrole85, label %bb_rcslotowner85
bb_rcslotrole85:
  %v2907 = load i64, ptr %slot88, align 8
  store i64 %v2907, ptr %slot133, align 8
  %v2908 = load i64, ptr %slot133, align 8
  %v2909 = load i64, ptr %slot130, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2908, i64 %v2909) nomerge, !dbg !114
  br label %bb_rcslotdone85
bb_rcslotowner85:
  %v2910 = load i64, ptr %slot130, align 8
  %p2912 = inttoptr i64 %v2910 to ptr
  %gep2913 = getelementptr i8, ptr %p2912, i64 16
  %op2911 = ptrtoint ptr %gep2913 to i64
  store i64 %op2911, ptr %slot134, align 8
  %v2914 = load i64, ptr %slot88, align 8
  store i64 %v2914, ptr %slot135, align 8
  %v2915 = load i64, ptr %slot134, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %ld2917 = load i64, ptr %p2916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2917, ptr %slot136, align 8
  %v2918 = load i64, ptr %slot136, align 8
  %cmp2919 = icmp ne i64 %v2918, 0
  %cv2920 = zext i1 %cmp2919 to i32
  store i32 %cv2920, ptr %slot137, align 8
  %v2921 = load i32, ptr %slot137, align 8
  %cv2922 = zext i32 %v2921 to i64
  %cond2923 = icmp ne i64 %cv2922, 0
  br i1 %cond2923, label %bb_rcgnn103, label %bb_rcgdone103
bb_rcgnn103:
  %v2924 = load i64, ptr %slot136, align 8
  %op2925 = sub i64 %v2924, 16
  store i64 %op2925, ptr %slot138, align 8
  %v2926 = load i64, ptr %slot136, align 8
  %p2927 = inttoptr i64 %v2926 to ptr
  %rgep2928 = getelementptr i8, ptr %p2927, i64 -16
  %ld2929 = load i64, ptr %rgep2928, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2929, ptr %slot139, align 8
  %v2930 = load i64, ptr %slot139, align 8
  %op2931 = and i64 %v2930, 4611686018427387906
  store i64 %op2931, ptr %slot140, align 8
  %v2932 = load i64, ptr %slot140, align 8
  %cmp2933 = icmp ne i64 %v2932, 0
  %cv2934 = zext i1 %cmp2933 to i32
  store i32 %cv2934, ptr %slot141, align 8
  %v2935 = load i32, ptr %slot141, align 8
  %cv2936 = zext i32 %v2935 to i64
  %cond2937 = icmp ne i64 %cv2936, 0
  br i1 %cond2937, label %bb_rcgclear103, label %bb_rcgcounted103
bb_rcgcounted103:
  %v2938 = load i64, ptr %slot136, align 8
  %op2939 = sub i64 %v2938, 32
  store i64 %op2939, ptr %slot142, align 8
  %v2940 = load i64, ptr %slot136, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %rgep2942 = getelementptr i8, ptr %p2941, i64 -32
  %ld2943 = load i64, ptr %rgep2942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2943, ptr %slot143, align 8
  %v2944 = load i64, ptr %slot143, align 8
  %op2945 = sub i64 %v2944, 1
  store i64 %op2945, ptr %slot144, align 8
  %v2946 = load i64, ptr %slot144, align 8
  %cmp2947 = icmp eq i64 %v2946, 0
  %cv2948 = zext i1 %cmp2947 to i32
  store i32 %cv2948, ptr %slot145, align 8
  %v2949 = load i32, ptr %slot145, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcglast103, label %bb_rcgdec103
bb_rcglast103:
  %v2952 = load i64, ptr %slot136, align 8
  %op2953 = sub i64 %v2952, 24
  store i64 %op2953, ptr %slot146, align 8
  %v2954 = load i64, ptr %slot136, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %rgep2956 = getelementptr i8, ptr %p2955, i64 -24
  %ld2957 = load i64, ptr %rgep2956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2957, ptr %slot147, align 8
  %v2958 = load i64, ptr %slot147, align 8
  %cmp2959 = icmp ne i64 %v2958, 0
  %cv2960 = zext i1 %cmp2959 to i32
  store i32 %cv2960, ptr %slot148, align 8
  %v2961 = load i32, ptr %slot148, align 8
  %cv2962 = zext i32 %v2961 to i64
  %cond2963 = icmp ne i64 %cv2962, 0
  br i1 %cond2963, label %bb_rcgdec103, label %bb_rcgslow103
bb_rcgslow103:
  %v2964 = load i64, ptr %slot135, align 8
  %v2965 = load i64, ptr %slot134, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2964, i64 %v2965) nomerge, !dbg !114
  br label %bb_rcgdone103
bb_rcgdec103:
  %v2966 = load i64, ptr %slot144, align 8
  %v2967 = load i64, ptr %slot136, align 8
  %p2968 = inttoptr i64 %v2967 to ptr
  %rgep2969 = getelementptr i8, ptr %p2968, i64 -32
  store i64 %v2966, ptr %rgep2969, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear103
bb_rcgclear103:
  %v2970 = load i64, ptr %slot134, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  store i64 0, ptr %p2971, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone103
bb_rcgdone103:
  %v2972 = load i64, ptr %slot130, align 8
  %p2974 = inttoptr i64 %v2972 to ptr
  %gep2975 = getelementptr i8, ptr %p2974, i64 24
  %op2973 = ptrtoint ptr %gep2975 to i64
  store i64 %op2973, ptr %slot149, align 8
  %v2976 = load i64, ptr %slot88, align 8
  store i64 %v2976, ptr %slot150, align 8
  %v2977 = load i64, ptr %slot149, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  %ld2979 = load i64, ptr %p2978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2979, ptr %slot151, align 8
  %v2980 = load i64, ptr %slot151, align 8
  %cmp2981 = icmp ne i64 %v2980, 0
  %cv2982 = zext i1 %cmp2981 to i32
  store i32 %cv2982, ptr %slot152, align 8
  %v2983 = load i32, ptr %slot152, align 8
  %cv2984 = zext i32 %v2983 to i64
  %cond2985 = icmp ne i64 %cv2984, 0
  br i1 %cond2985, label %bb_rcgnn119, label %bb_rcgdone119
bb_rcgnn119:
  %v2986 = load i64, ptr %slot151, align 8
  %op2987 = sub i64 %v2986, 16
  store i64 %op2987, ptr %slot153, align 8
  %v2988 = load i64, ptr %slot151, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %rgep2990 = getelementptr i8, ptr %p2989, i64 -16
  %ld2991 = load i64, ptr %rgep2990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2991, ptr %slot154, align 8
  %v2992 = load i64, ptr %slot154, align 8
  %op2993 = and i64 %v2992, 4611686018427387906
  store i64 %op2993, ptr %slot155, align 8
  %v2994 = load i64, ptr %slot155, align 8
  %cmp2995 = icmp ne i64 %v2994, 0
  %cv2996 = zext i1 %cmp2995 to i32
  store i32 %cv2996, ptr %slot156, align 8
  %v2997 = load i32, ptr %slot156, align 8
  %cv2998 = zext i32 %v2997 to i64
  %cond2999 = icmp ne i64 %cv2998, 0
  br i1 %cond2999, label %bb_rcgclear119, label %bb_rcgcounted119
bb_rcgcounted119:
  %v3000 = load i64, ptr %slot151, align 8
  %op3001 = sub i64 %v3000, 32
  store i64 %op3001, ptr %slot157, align 8
  %v3002 = load i64, ptr %slot151, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  %rgep3004 = getelementptr i8, ptr %p3003, i64 -32
  %ld3005 = load i64, ptr %rgep3004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3005, ptr %slot158, align 8
  %v3006 = load i64, ptr %slot158, align 8
  %op3007 = sub i64 %v3006, 1
  store i64 %op3007, ptr %slot159, align 8
  %v3008 = load i64, ptr %slot159, align 8
  %cmp3009 = icmp eq i64 %v3008, 0
  %cv3010 = zext i1 %cmp3009 to i32
  store i32 %cv3010, ptr %slot160, align 8
  %v3011 = load i32, ptr %slot160, align 8
  %cv3012 = zext i32 %v3011 to i64
  %cond3013 = icmp ne i64 %cv3012, 0
  br i1 %cond3013, label %bb_rcglast119, label %bb_rcgdec119
bb_rcglast119:
  %v3014 = load i64, ptr %slot151, align 8
  %op3015 = sub i64 %v3014, 24
  store i64 %op3015, ptr %slot161, align 8
  %v3016 = load i64, ptr %slot151, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  %rgep3018 = getelementptr i8, ptr %p3017, i64 -24
  %ld3019 = load i64, ptr %rgep3018, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3019, ptr %slot162, align 8
  %v3020 = load i64, ptr %slot162, align 8
  %cmp3021 = icmp ne i64 %v3020, 0
  %cv3022 = zext i1 %cmp3021 to i32
  store i32 %cv3022, ptr %slot163, align 8
  %v3023 = load i32, ptr %slot163, align 8
  %cv3024 = zext i32 %v3023 to i64
  %cond3025 = icmp ne i64 %cv3024, 0
  br i1 %cond3025, label %bb_rcgdec119, label %bb_rcgslow119
bb_rcgslow119:
  %v3026 = load i64, ptr %slot150, align 8
  %v3027 = load i64, ptr %slot149, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3026, i64 %v3027) nomerge, !dbg !114
  br label %bb_rcgdone119
bb_rcgdec119:
  %v3028 = load i64, ptr %slot159, align 8
  %v3029 = load i64, ptr %slot151, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  %rgep3031 = getelementptr i8, ptr %p3030, i64 -32
  store i64 %v3028, ptr %rgep3031, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear119
bb_rcgclear119:
  %v3032 = load i64, ptr %slot149, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  store i64 0, ptr %p3033, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone119
bb_rcgdone119:
  %v3034 = load i64, ptr %slot130, align 8
  %p3036 = inttoptr i64 %v3034 to ptr
  %gep3037 = getelementptr i8, ptr %p3036, i64 32
  %op3035 = ptrtoint ptr %gep3037 to i64
  store i64 %op3035, ptr %slot164, align 8
  %v3038 = load i64, ptr %slot88, align 8
  store i64 %v3038, ptr %slot165, align 8
  %v3039 = load i64, ptr %slot164, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  %ld3041 = load i64, ptr %p3040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3041, ptr %slot166, align 8
  %v3042 = load i64, ptr %slot166, align 8
  %cmp3043 = icmp ne i64 %v3042, 0
  %cv3044 = zext i1 %cmp3043 to i32
  store i32 %cv3044, ptr %slot167, align 8
  %v3045 = load i32, ptr %slot167, align 8
  %cv3046 = zext i32 %v3045 to i64
  %cond3047 = icmp ne i64 %cv3046, 0
  br i1 %cond3047, label %bb_rcgnn135, label %bb_rcgdone135
bb_rcgnn135:
  %v3048 = load i64, ptr %slot166, align 8
  %op3049 = sub i64 %v3048, 16
  store i64 %op3049, ptr %slot168, align 8
  %v3050 = load i64, ptr %slot166, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %rgep3052 = getelementptr i8, ptr %p3051, i64 -16
  %ld3053 = load i64, ptr %rgep3052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3053, ptr %slot169, align 8
  %v3054 = load i64, ptr %slot169, align 8
  %op3055 = and i64 %v3054, 4611686018427387906
  store i64 %op3055, ptr %slot170, align 8
  %v3056 = load i64, ptr %slot170, align 8
  %cmp3057 = icmp ne i64 %v3056, 0
  %cv3058 = zext i1 %cmp3057 to i32
  store i32 %cv3058, ptr %slot171, align 8
  %v3059 = load i32, ptr %slot171, align 8
  %cv3060 = zext i32 %v3059 to i64
  %cond3061 = icmp ne i64 %cv3060, 0
  br i1 %cond3061, label %bb_rcgclear135, label %bb_rcgcounted135
bb_rcgcounted135:
  %v3062 = load i64, ptr %slot166, align 8
  %op3063 = sub i64 %v3062, 32
  store i64 %op3063, ptr %slot172, align 8
  %v3064 = load i64, ptr %slot166, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %rgep3066 = getelementptr i8, ptr %p3065, i64 -32
  %ld3067 = load i64, ptr %rgep3066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3067, ptr %slot173, align 8
  %v3068 = load i64, ptr %slot173, align 8
  %op3069 = sub i64 %v3068, 1
  store i64 %op3069, ptr %slot174, align 8
  %v3070 = load i64, ptr %slot174, align 8
  %cmp3071 = icmp eq i64 %v3070, 0
  %cv3072 = zext i1 %cmp3071 to i32
  store i32 %cv3072, ptr %slot175, align 8
  %v3073 = load i32, ptr %slot175, align 8
  %cv3074 = zext i32 %v3073 to i64
  %cond3075 = icmp ne i64 %cv3074, 0
  br i1 %cond3075, label %bb_rcglast135, label %bb_rcgdec135
bb_rcglast135:
  %v3076 = load i64, ptr %slot166, align 8
  %op3077 = sub i64 %v3076, 24
  store i64 %op3077, ptr %slot176, align 8
  %v3078 = load i64, ptr %slot166, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %rgep3080 = getelementptr i8, ptr %p3079, i64 -24
  %ld3081 = load i64, ptr %rgep3080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3081, ptr %slot177, align 8
  %v3082 = load i64, ptr %slot177, align 8
  %cmp3083 = icmp ne i64 %v3082, 0
  %cv3084 = zext i1 %cmp3083 to i32
  store i32 %cv3084, ptr %slot178, align 8
  %v3085 = load i32, ptr %slot178, align 8
  %cv3086 = zext i32 %v3085 to i64
  %cond3087 = icmp ne i64 %cv3086, 0
  br i1 %cond3087, label %bb_rcgdec135, label %bb_rcgslow135
bb_rcgslow135:
  %v3088 = load i64, ptr %slot165, align 8
  %v3089 = load i64, ptr %slot164, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3088, i64 %v3089) nomerge, !dbg !114
  br label %bb_rcgdone135
bb_rcgdec135:
  %v3090 = load i64, ptr %slot174, align 8
  %v3091 = load i64, ptr %slot166, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  %rgep3093 = getelementptr i8, ptr %p3092, i64 -32
  store i64 %v3090, ptr %rgep3093, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear135
bb_rcgclear135:
  %v3094 = load i64, ptr %slot164, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  store i64 0, ptr %p3095, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone135
bb_rcgdone135:
  %v3096 = load i64, ptr %slot130, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  store i64 0, ptr %p3097, align 8, !alias.scope !3, !noalias !4
  %v3098 = load i64, ptr %slot130, align 8
  %p3100 = inttoptr i64 %v3098 to ptr
  %gep3101 = getelementptr i8, ptr %p3100, i64 8
  %op3099 = ptrtoint ptr %gep3101 to i64
  store i64 %op3099, ptr %slot179, align 8
  %v3102 = load i64, ptr %slot179, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  store i64 0, ptr %p3103, align 8, !alias.scope !3, !noalias !4
  %v3104 = load i64, ptr %slot130, align 8
  %p3106 = inttoptr i64 %v3104 to ptr
  %gep3107 = getelementptr i8, ptr %p3106, i64 16
  %op3105 = ptrtoint ptr %gep3107 to i64
  store i64 %op3105, ptr %slot180, align 8
  %v3108 = load i64, ptr %slot180, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i64 0, ptr %p3109, align 8, !alias.scope !3, !noalias !4
  %v3110 = load i64, ptr %slot130, align 8
  %p3112 = inttoptr i64 %v3110 to ptr
  %gep3113 = getelementptr i8, ptr %p3112, i64 24
  %op3111 = ptrtoint ptr %gep3113 to i64
  store i64 %op3111, ptr %slot181, align 8
  %v3114 = load i64, ptr %slot181, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  store i64 0, ptr %p3115, align 8, !alias.scope !3, !noalias !4
  %v3116 = load i64, ptr %slot130, align 8
  %p3118 = inttoptr i64 %v3116 to ptr
  %gep3119 = getelementptr i8, ptr %p3118, i64 32
  %op3117 = ptrtoint ptr %gep3119 to i64
  store i64 %op3117, ptr %slot182, align 8
  %v3120 = load i64, ptr %slot182, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 0, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot130, align 8
  %p3124 = inttoptr i64 %v3122 to ptr
  %gep3125 = getelementptr i8, ptr %p3124, i64 40
  %op3123 = ptrtoint ptr %gep3125 to i64
  store i64 %op3123, ptr %slot183, align 8
  %v3126 = load i64, ptr %slot183, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  store i64 0, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone85
bb_rcslotdone85:
  %v3128 = load i64, ptr %slot53, align 8
  store i64 %v3128, ptr %slot184, align 8
  %v3129 = load i64, ptr %slot42, align 8
  store i64 %v3129, ptr %slot185, align 8
  %v3130 = load i64, ptr %slot185, align 8
  %v3131 = load i64, ptr %slot184, align 8
  %p3132 = inttoptr i64 %v3130 to ptr
  %p3133 = inttoptr i64 %v3131 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3133, ptr %p3132, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot31, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 0, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot6, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  store i32 2, ptr %p3137, align 4, !alias.scope !3, !noalias !4
  %v3138 = load i64, ptr %slot32, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  %ld3140 = load i32, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3140, ptr %slot186, align 8
  %v3141 = load i32, ptr %slot186, align 8
  %v3142 = load i64, ptr %slot6, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  store i32 %v3141, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  %v3144 = load i64, ptr %slot5, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  store i32 1, ptr %p3145, align 4, !alias.scope !3, !noalias !4
  %v3146 = load i64, ptr %slot51, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  %ld3148 = load i64, ptr %p3147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3148, ptr %slot187, align 8
  %v3149 = load i64, ptr %slot187, align 8
  %v3150 = load i64, ptr %slot74, align 8
  %p3151 = inttoptr i64 %v3149 to ptr
  %p3152 = inttoptr i64 %v3150 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3152, ptr %p3151, i64 392, i1 false), !alias.scope !10000000
  %v3153 = load i64, ptr %slot74, align 8
  %v3154 = load i64, ptr %slot68, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  store i64 %v3153, ptr %p3155, align 8, !alias.scope !3, !noalias !4
  %v3156 = load i64, ptr %slot68, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  %ld3158 = load i64, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3158, ptr %slot188, align 8
  %v3159 = load i64, ptr %slot188, align 8
  %op3160 = add i64 %v3159, 0
  store i64 %op3160, ptr %slot189, align 8
  %v3161 = load i64, ptr %slot189, align 8
  %v3162 = load i64, ptr %slot68, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  store i64 %v3161, ptr %p3163, align 8, !alias.scope !3, !noalias !4
  %v3164 = load i64, ptr %slot7, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i32, ptr %p3165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3166, ptr %slot190, align 8
  %v3167 = load i32, ptr %slot190, align 8
  %cv3168 = zext i32 %v3167 to i64
  %cond3169 = icmp ne i64 %cv3168, 0
  br i1 %cond3169, label %bb_rcslotdrop156, label %bb_rcslotdone156
bb_rcslotdrop156:
  %v3170 = load i64, ptr %slot7, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  store i32 0, ptr %p3171, align 4, !alias.scope !3, !noalias !4
  %v3172 = load i64, ptr %slot54, align 8
  store i64 %v3172, ptr %slot191, align 8
  %v3173 = load i64, ptr %slot8, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  %ld3175 = load i32, ptr %p3174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3175, ptr %slot192, align 8
  %v3176 = load i32, ptr %slot192, align 8
  %op3177 = and i32 %v3176, 28
  store i32 %op3177, ptr %slot193, align 8
  %v3178 = load i32, ptr %slot193, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcslotrole156, label %bb_rcslotowner156
bb_rcslotrole156:
  %v3181 = load i64, ptr %slot88, align 8
  store i64 %v3181, ptr %slot194, align 8
  %v3182 = load i64, ptr %slot194, align 8
  %v3183 = load i64, ptr %slot191, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3182, i64 %v3183) nomerge, !dbg !116
  br label %bb_rcslotdone156
bb_rcslotowner156:
  %v3184 = load i64, ptr %slot88, align 8
  store i64 %v3184, ptr %slot195, align 8
  %v3185 = load i64, ptr %slot195, align 8
  %v3186 = load i64, ptr %slot191, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3185, i64 %v3186) nomerge, !dbg !116
  br label %bb_rcslotdone156
bb_rcslotdone156:
  %v3187 = load i64, ptr %slot51, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  %ld3189 = load i64, ptr %p3188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3189, ptr %slot196, align 8
  %v3190 = load i64, ptr %slot196, align 8
  %op3191 = add i64 %v3190, 0
  store i64 %op3191, ptr %slot197, align 8
  %v3192 = load i64, ptr %slot54, align 8
  store i64 %v3192, ptr %slot198, align 8
  %v3193 = load i64, ptr %slot197, align 8
  %v3194 = load i64, ptr %slot198, align 8
  %p3195 = inttoptr i64 %v3193 to ptr
  %p3196 = inttoptr i64 %v3194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3196, ptr %p3195, i64 208, i1 false), !alias.scope !10000000
  %v3197 = load i64, ptr %slot197, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  call void @llvm.memset.p0.i64(ptr %p3198, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !116
  %v3199 = load i64, ptr %slot7, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i32 1, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot54, align 8
  %v3202 = load i64, ptr %slot68, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i64 %v3201, ptr %p3203, align 8, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot53, align 8
  %v3205 = load i64, ptr %slot69, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i64 %v3204, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot69, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  %ld3209 = load i64, ptr %p3208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3209, ptr %slot199, align 8
  %v3210 = load i64, ptr %slot25, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  %ld3212 = load i32, ptr %p3211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3212, ptr %slot200, align 8
  %v3213 = load i64, ptr %slot26, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  %ld3215 = load i32, ptr %p3214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3215, ptr %slot201, align 8
  %v3216 = load i32, ptr %slot201, align 8
  %op3217 = and i32 %v3216, 24
  store i32 %op3217, ptr %slot201, align 8
  %v3218 = load i32, ptr %slot201, align 8
  %cmp3219 = icmp eq i32 %v3218, 0
  %cv3220 = zext i1 %cmp3219 to i32
  store i32 %cv3220, ptr %slot202, align 8
  %v3221 = load i32, ptr %slot200, align 8
  %v3222 = load i32, ptr %slot202, align 8
  %op3223 = and i32 %v3221, %v3222
  store i32 %op3223, ptr %slot203, align 8
  %v3224 = load i64, ptr %slot89, align 8
  store i64 %v3224, ptr %slot204, align 8
  %v3225 = load i32, ptr %slot203, align 8
  %op3226 = mul i32 %v3225, 4
  store i32 %op3226, ptr %slot205, align 8
  %v3227 = load i32, ptr %slot205, align 8
  %op3228 = or i32 %v3227, 0
  store i32 %op3228, ptr %slot206, align 8
  %v3229 = load i64, ptr %slot42, align 8
  store i64 %v3229, ptr %slot207, align 8
  %v3230 = load i64, ptr %slot88, align 8
  %v3231 = load i64, ptr %slot207, align 8
  %v3232 = load i64, ptr %slot199, align 8
  %v3233 = load i64, ptr %slot204, align 8
  %cv3234 = trunc i64 %v3233 to i32
  %v3235 = load i32, ptr %slot206, align 8
  %call3236 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v3230, i64 %v3231, i64 %v3232, i32 %cv3234, i32 %v3235) nomerge, !dbg !118
  store i32 %call3236, ptr %slot208, align 8
  %v3237 = load i32, ptr %slot208, align 8
  %cv3238 = zext i32 %v3237 to i64
  %cond3239 = icmp ne i64 %cv3238, 0
  br i1 %cond3239, label %bb_rcsuccess181, label %bb_rcfailure181
bb_rcfailure181:
  %v3240 = load i64, ptr %slot88, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %call3242 = call i32 @myl_rc_take_failure(ptr %p3241) nomerge, !dbg !118
  store i32 %call3242, ptr %slot209, align 8
  %v3243 = load i64, ptr %slot1, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %v3245 = load i32, ptr %slot209, align 8
  %call3246 = call i32 @myl_qbe_rc_status(ptr %p3244, i32 %v3245) nomerge, !dbg !118
  store i32 %call3246, ptr %slot210, align 8
  br label %bb_failure
bb_rcsuccess181:
  %v3247 = load i32, ptr %slot203, align 8
  %cv3248 = zext i32 %v3247 to i64
  %cond3249 = icmp ne i64 %cv3248, 0
  br i1 %cond3249, label %bb_rchtaken184, label %bb_rchcopied184
bb_rchcopied184:
  %v3250 = load i64, ptr %slot25, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %ld3252 = load i32, ptr %p3251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3252, ptr %slot211, align 8
  %v3253 = load i32, ptr %slot211, align 8
  %cv3254 = zext i32 %v3253 to i64
  %cond3255 = icmp ne i64 %cv3254, 0
  br i1 %cond3255, label %bb_rcslotdrop187, label %bb_rcslotdone187
bb_rcslotdrop187:
  %v3256 = load i64, ptr %slot25, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i32 0, ptr %p3257, align 4, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot35, align 8
  store i64 %v3258, ptr %slot212, align 8
  %v3259 = load i64, ptr %slot26, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i32, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3261, ptr %slot213, align 8
  %v3262 = load i32, ptr %slot213, align 8
  %op3263 = and i32 %v3262, 28
  store i32 %op3263, ptr %slot214, align 8
  %v3264 = load i32, ptr %slot214, align 8
  %cv3265 = zext i32 %v3264 to i64
  %cond3266 = icmp ne i64 %cv3265, 0
  br i1 %cond3266, label %bb_rcslotrole187, label %bb_rcslotowner187
bb_rcslotrole187:
  %v3267 = load i64, ptr %slot88, align 8
  store i64 %v3267, ptr %slot215, align 8
  %v3268 = load i64, ptr %slot215, align 8
  %v3269 = load i64, ptr %slot212, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3268, i64 %v3269) nomerge, !dbg !118
  br label %bb_rcslotdone187
bb_rcslotowner187:
  %v3270 = load i64, ptr %slot88, align 8
  store i64 %v3270, ptr %slot216, align 8
  %v3271 = load i64, ptr %slot216, align 8
  %v3272 = load i64, ptr %slot212, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3271, i64 %v3272) nomerge, !dbg !118
  br label %bb_rcslotdone187
bb_rcslotdone187:
  br label %bb_rchprepared184
bb_rchtaken184:
  %v3273 = load i64, ptr %slot25, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  store i32 0, ptr %p3274, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared184
bb_rchprepared184:
  %v3275 = load i64, ptr %slot32, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  store i32 2, ptr %p3276, align 4, !alias.scope !3, !noalias !4
  %v3277 = load i64, ptr %slot31, align 8
  %p3278 = inttoptr i64 %v3277 to ptr
  store i32 1, ptr %p3278, align 4, !alias.scope !3, !noalias !4
  %v3279 = load i64, ptr %slot35, align 8
  store i64 %v3279, ptr %slot217, align 8
  %v3280 = load i64, ptr %slot42, align 8
  store i64 %v3280, ptr %slot218, align 8
  %v3281 = load i64, ptr %slot218, align 8
  %v3282 = load i64, ptr %slot217, align 8
  %p3283 = inttoptr i64 %v3281 to ptr
  %p3284 = inttoptr i64 %v3282 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3284, ptr %p3283, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3285 = load i64, ptr %slot26, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  store i32 2, ptr %p3286, align 4, !alias.scope !3, !noalias !4
  %v3287 = load i64, ptr %slot32, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  %ld3289 = load i32, ptr %p3288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3289, ptr %slot219, align 8
  %v3290 = load i32, ptr %slot219, align 8
  %v3291 = load i64, ptr %slot26, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i32 %v3290, ptr %p3292, align 4, !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot31, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i32 0, ptr %p3294, align 4, !alias.scope !3, !noalias !4
  %v3295 = load i64, ptr %slot25, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  store i32 1, ptr %p3296, align 4, !alias.scope !3, !noalias !4
  %v3297 = load i64, ptr %slot217, align 8
  %v3298 = load i64, ptr %slot69, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i64 %v3297, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  %v3300 = load i64, ptr %slot75, align 8
  store i64 %v3300, ptr %slot220, align 8
  %v3301 = load i64, ptr %slot220, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  store i64 0, ptr %p3302, align 8, !alias.scope !3, !noalias !4
  %v3303 = load i64, ptr %slot220, align 8
  %p3305 = inttoptr i64 %v3303 to ptr
  %gep3306 = getelementptr i8, ptr %p3305, i64 8
  %op3304 = ptrtoint ptr %gep3306 to i64
  store i64 %op3304, ptr %slot221, align 8
  %v3307 = load i64, ptr %slot221, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  store i64 0, ptr %p3308, align 8, !alias.scope !3, !noalias !4
  %v3309 = load i64, ptr %slot220, align 8
  %p3311 = inttoptr i64 %v3309 to ptr
  %gep3312 = getelementptr i8, ptr %p3311, i64 16
  %op3310 = ptrtoint ptr %gep3312 to i64
  store i64 %op3310, ptr %slot222, align 8
  %v3313 = load i64, ptr %slot222, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i64 0, ptr %p3314, align 8, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot220, align 8
  %p3317 = inttoptr i64 %v3315 to ptr
  %gep3318 = getelementptr i8, ptr %p3317, i64 24
  %op3316 = ptrtoint ptr %gep3318 to i64
  store i64 %op3316, ptr %slot223, align 8
  %v3319 = load i64, ptr %slot223, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i64 0, ptr %p3320, align 8, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot220, align 8
  %p3323 = inttoptr i64 %v3321 to ptr
  %gep3324 = getelementptr i8, ptr %p3323, i64 32
  %op3322 = ptrtoint ptr %gep3324 to i64
  store i64 %op3322, ptr %slot224, align 8
  %v3325 = load i64, ptr %slot224, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  store i64 0, ptr %p3326, align 8, !alias.scope !3, !noalias !4
  %v3327 = load i64, ptr %slot220, align 8
  %p3329 = inttoptr i64 %v3327 to ptr
  %gep3330 = getelementptr i8, ptr %p3329, i64 40
  %op3328 = ptrtoint ptr %gep3330 to i64
  store i64 %op3328, ptr %slot225, align 8
  %v3331 = load i64, ptr %slot225, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i64 0, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot220, align 8
  %p3335 = inttoptr i64 %v3333 to ptr
  %gep3336 = getelementptr i8, ptr %p3335, i64 48
  %op3334 = ptrtoint ptr %gep3336 to i64
  store i64 %op3334, ptr %slot226, align 8
  %v3337 = load i64, ptr %slot226, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  store i64 0, ptr %p3338, align 8, !alias.scope !3, !noalias !4
  %v3339 = load i64, ptr %slot220, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 2, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot33, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  store i32 1, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  %v3343 = load i64, ptr %slot69, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  %ld3345 = load i64, ptr %p3344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3345, ptr %slot227, align 8
  %v3346 = load i64, ptr %slot220, align 8
  %p3348 = inttoptr i64 %v3346 to ptr
  %gep3349 = getelementptr i8, ptr %p3348, i64 8
  %op3347 = ptrtoint ptr %gep3349 to i64
  store i64 %op3347, ptr %slot228, align 8
  %v3350 = load i64, ptr %slot89, align 8
  store i64 %v3350, ptr %slot229, align 8
  %v3351 = load i64, ptr %slot69, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %ld3353 = load i64, ptr %p3352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3353, ptr %slot230, align 8
  %v3354 = load i64, ptr %slot42, align 8
  store i64 %v3354, ptr %slot231, align 8
  %v3355 = load i64, ptr %slot89, align 8
  store i64 %v3355, ptr %slot232, align 8
  %v3356 = load i64, ptr %slot230, align 8
  %op3357 = add i64 %v3356, 16
  store i64 %op3357, ptr %slot233, align 8
  %v3358 = load i64, ptr %slot233, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8
  store i64 %ld3360, ptr %slot234, align 8
  %v3361 = load i64, ptr %slot234, align 8
  %cmp3362 = icmp ne i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot235, align 8
  %v3364 = load i32, ptr %slot235, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcmoveheader223, label %bb_rcmovenext223
bb_rcmoveheader223:
  %v3367 = load i64, ptr %slot234, align 8
  %op3368 = sub i64 %v3367, 16
  store i64 %op3368, ptr %slot236, align 8
  %v3369 = load i64, ptr %slot234, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %rgep3371 = getelementptr i8, ptr %p3370, i64 -16
  %ld3372 = load i64, ptr %rgep3371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3372, ptr %slot237, align 8
  %v3373 = load i64, ptr %slot237, align 8
  %op3374 = and i64 %v3373, 5764607523034234881
  store i64 %op3374, ptr %slot238, align 8
  %v3375 = load i64, ptr %slot238, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot239, align 8
  %v3378 = load i32, ptr %slot239, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcmoveslow220, label %bb_rcmovenext223
bb_rcmovenext223:
  %v3381 = load i64, ptr %slot230, align 8
  %op3382 = add i64 %v3381, 24
  store i64 %op3382, ptr %slot240, align 8
  %v3383 = load i64, ptr %slot240, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %ld3385 = load i64, ptr %p3384, align 8
  store i64 %ld3385, ptr %slot241, align 8
  %v3386 = load i64, ptr %slot241, align 8
  %cmp3387 = icmp ne i64 %v3386, 0
  %cv3388 = zext i1 %cmp3387 to i32
  store i32 %cv3388, ptr %slot242, align 8
  %v3389 = load i32, ptr %slot242, align 8
  %cv3390 = zext i32 %v3389 to i64
  %cond3391 = icmp ne i64 %cv3390, 0
  br i1 %cond3391, label %bb_rcmoveheader231, label %bb_rcmovenext231
bb_rcmoveheader231:
  %v3392 = load i64, ptr %slot241, align 8
  %op3393 = sub i64 %v3392, 16
  store i64 %op3393, ptr %slot243, align 8
  %v3394 = load i64, ptr %slot241, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  %rgep3396 = getelementptr i8, ptr %p3395, i64 -16
  %ld3397 = load i64, ptr %rgep3396, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3397, ptr %slot244, align 8
  %v3398 = load i64, ptr %slot244, align 8
  %op3399 = and i64 %v3398, 5764607523034234881
  store i64 %op3399, ptr %slot245, align 8
  %v3400 = load i64, ptr %slot245, align 8
  %cmp3401 = icmp ne i64 %v3400, 0
  %cv3402 = zext i1 %cmp3401 to i32
  store i32 %cv3402, ptr %slot246, align 8
  %v3403 = load i32, ptr %slot246, align 8
  %cv3404 = zext i32 %v3403 to i64
  %cond3405 = icmp ne i64 %cv3404, 0
  br i1 %cond3405, label %bb_rcmoveslow220, label %bb_rcmovenext231
bb_rcmovenext231:
  %v3406 = load i64, ptr %slot230, align 8
  %op3407 = add i64 %v3406, 32
  store i64 %op3407, ptr %slot247, align 8
  %v3408 = load i64, ptr %slot247, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  %ld3410 = load i64, ptr %p3409, align 8
  store i64 %ld3410, ptr %slot248, align 8
  %v3411 = load i64, ptr %slot248, align 8
  %cmp3412 = icmp ne i64 %v3411, 0
  %cv3413 = zext i1 %cmp3412 to i32
  store i32 %cv3413, ptr %slot249, align 8
  %v3414 = load i32, ptr %slot249, align 8
  %cv3415 = zext i32 %v3414 to i64
  %cond3416 = icmp ne i64 %cv3415, 0
  br i1 %cond3416, label %bb_rcmoveheader239, label %bb_rcmovenext239
bb_rcmoveheader239:
  %v3417 = load i64, ptr %slot248, align 8
  %op3418 = sub i64 %v3417, 16
  store i64 %op3418, ptr %slot250, align 8
  %v3419 = load i64, ptr %slot248, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  %rgep3421 = getelementptr i8, ptr %p3420, i64 -16
  %ld3422 = load i64, ptr %rgep3421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3422, ptr %slot251, align 8
  %v3423 = load i64, ptr %slot251, align 8
  %op3424 = and i64 %v3423, 5764607523034234881
  store i64 %op3424, ptr %slot252, align 8
  %v3425 = load i64, ptr %slot252, align 8
  %cmp3426 = icmp ne i64 %v3425, 0
  %cv3427 = zext i1 %cmp3426 to i32
  store i32 %cv3427, ptr %slot253, align 8
  %v3428 = load i32, ptr %slot253, align 8
  %cv3429 = zext i32 %v3428 to i64
  %cond3430 = icmp ne i64 %cv3429, 0
  br i1 %cond3430, label %bb_rcmoveslow220, label %bb_rcmovenext239
bb_rcmovenext239:
  %v3431 = load i64, ptr %slot230, align 8
  %v3432 = load i64, ptr %slot231, align 8
  %p3433 = inttoptr i64 %v3431 to ptr
  %p3434 = inttoptr i64 %v3432 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3434, ptr %p3433, i64 48, i1 false)
  %v3435 = load i64, ptr %slot230, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  store i64 0, ptr %p3436, align 8
  %v3437 = load i64, ptr %slot230, align 8
  %op3438 = add i64 %v3437, 8
  store i64 %op3438, ptr %slot254, align 8
  %v3439 = load i64, ptr %slot254, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  store i64 0, ptr %p3440, align 8
  %v3441 = load i64, ptr %slot230, align 8
  %op3442 = add i64 %v3441, 16
  store i64 %op3442, ptr %slot255, align 8
  %v3443 = load i64, ptr %slot255, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  store i64 0, ptr %p3444, align 8
  %v3445 = load i64, ptr %slot230, align 8
  %op3446 = add i64 %v3445, 24
  store i64 %op3446, ptr %slot256, align 8
  %v3447 = load i64, ptr %slot256, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  store i64 0, ptr %p3448, align 8
  %v3449 = load i64, ptr %slot230, align 8
  %op3450 = add i64 %v3449, 32
  store i64 %op3450, ptr %slot257, align 8
  %v3451 = load i64, ptr %slot257, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  store i64 0, ptr %p3452, align 8
  %v3453 = load i64, ptr %slot230, align 8
  %op3454 = add i64 %v3453, 40
  store i64 %op3454, ptr %slot258, align 8
  %v3455 = load i64, ptr %slot258, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i64 0, ptr %p3456, align 8
  br label %bb_rcmoved220
bb_rcmoveslow220:
  %v3457 = load i64, ptr %slot88, align 8
  %v3458 = load i64, ptr %slot231, align 8
  %v3459 = load i64, ptr %slot230, align 8
  %v3460 = load i64, ptr %slot232, align 8
  %cv3461 = trunc i64 %v3460 to i32
  %call3462 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3457, i64 %v3458, i64 %v3459, i32 %cv3461) nomerge, !dbg !120
  store i32 %call3462, ptr %slot259, align 8
  %v3463 = load i32, ptr %slot259, align 8
  %cv3464 = zext i32 %v3463 to i64
  %cond3465 = icmp ne i64 %cv3464, 0
  br i1 %cond3465, label %bb_rcsuccess251, label %bb_rcfailure251
bb_rcfailure251:
  %v3466 = load i64, ptr %slot88, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  %call3468 = call i32 @myl_rc_take_failure(ptr %p3467) nomerge, !dbg !120
  store i32 %call3468, ptr %slot260, align 8
  %v3469 = load i64, ptr %slot1, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %v3471 = load i32, ptr %slot260, align 8
  %call3472 = call i32 @myl_qbe_rc_status(ptr %p3470, i32 %v3471) nomerge, !dbg !120
  store i32 %call3472, ptr %slot261, align 8
  br label %bb_failure
bb_rcsuccess251:
  br label %bb_rcmoved220
bb_rcmoved220:
  %v3473 = load i64, ptr %slot25, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i32 0, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot32, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i32 2, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot31, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  store i32 1, ptr %p3478, align 4, !alias.scope !3, !noalias !4
  %v3479 = load i64, ptr %slot42, align 8
  store i64 %v3479, ptr %slot262, align 8
  %v3480 = load i64, ptr %slot262, align 8
  %v3481 = load i64, ptr %slot228, align 8
  %p3482 = inttoptr i64 %v3480 to ptr
  %p3483 = inttoptr i64 %v3481 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3483, ptr %p3482, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3484 = load i64, ptr %slot31, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  store i32 0, ptr %p3485, align 4, !alias.scope !3, !noalias !4
  %v3486 = load i64, ptr %slot220, align 8
  %v3487 = load i64, ptr %slot69, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  store i64 %v3486, ptr %p3488, align 8, !alias.scope !3, !noalias !4
  %v3489 = load i64, ptr %slot69, align 8
  %p3490 = inttoptr i64 %v3489 to ptr
  %ld3491 = load i64, ptr %p3490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3491, ptr %slot263, align 8
  %v3492 = load i64, ptr %slot35, align 8
  store i64 %v3492, ptr %slot264, align 8
  %v3493 = load i64, ptr %slot263, align 8
  %v3494 = load i64, ptr %slot264, align 8
  %p3495 = inttoptr i64 %v3493 to ptr
  %p3496 = inttoptr i64 %v3494 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3496, ptr %p3495, i64 56, i1 false)
  %v3497 = load i64, ptr %slot26, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  store i32 2, ptr %p3498, align 4, !alias.scope !3, !noalias !4
  %v3499 = load i64, ptr %slot25, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  store i32 1, ptr %p3500, align 4, !alias.scope !3, !noalias !4
  %v3501 = load i64, ptr %slot264, align 8
  %v3502 = load i64, ptr %slot69, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  store i64 %v3501, ptr %p3503, align 8, !alias.scope !3, !noalias !4
  %v3504 = load i64, ptr %slot68, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i64, ptr %p3505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3506, ptr %slot265, align 8
  %v3507 = load i64, ptr %slot69, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i64, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3509, ptr %slot266, align 8
  %v3510 = load i64, ptr %slot1, align 8
  %v3511 = load i64, ptr %slot265, align 8
  %v3512 = load i64, ptr %slot266, align 8
  %call3513 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v3510, i64 %v3511, i64 %v3512) nomerge, !dbg !122
  store i64 %call3513, ptr %slot267, align 8
  %v3514 = load i64, ptr %slot267, align 8
  %v3515 = load i64, ptr %slot68, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  store i64 %v3514, ptr %p3516, align 8, !alias.scope !3, !noalias !4
  %v3517 = load i64, ptr %slot23, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  %ld3519 = load i32, ptr %p3518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3519, ptr %slot268, align 8
  %v3520 = load i32, ptr %slot268, align 8
  %cv3521 = zext i32 %v3520 to i64
  %cond3522 = icmp ne i64 %cv3521, 0
  br i1 %cond3522, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v3523 = load i64, ptr %slot23, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  store i32 0, ptr %p3524, align 4, !alias.scope !3, !noalias !4
  %v3525 = load i64, ptr %slot34, align 8
  store i64 %v3525, ptr %slot269, align 8
  %v3526 = load i64, ptr %slot24, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %ld3528 = load i32, ptr %p3527, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3528, ptr %slot270, align 8
  %v3529 = load i32, ptr %slot270, align 8
  %op3530 = and i32 %v3529, 28
  store i32 %op3530, ptr %slot271, align 8
  %v3531 = load i32, ptr %slot271, align 8
  %cv3532 = zext i32 %v3531 to i64
  %cond3533 = icmp ne i64 %cv3532, 0
  br i1 %cond3533, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v3534 = load i64, ptr %slot88, align 8
  store i64 %v3534, ptr %slot272, align 8
  %v3535 = load i64, ptr %slot272, align 8
  %v3536 = load i64, ptr %slot269, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3535, i64 %v3536) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v3537 = load i64, ptr %slot88, align 8
  store i64 %v3537, ptr %slot273, align 8
  %v3538 = load i64, ptr %slot273, align 8
  %v3539 = load i64, ptr %slot269, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3538, i64 %v3539) nomerge, !dbg !122
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v3540 = load i64, ptr %slot25, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %ld3542 = load i32, ptr %p3541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3542, ptr %slot274, align 8
  %v3543 = load i32, ptr %slot274, align 8
  %cv3544 = zext i32 %v3543 to i64
  %cond3545 = icmp ne i64 %cv3544, 0
  br i1 %cond3545, label %bb_rcslotdrop277, label %bb_rcslotdone277
bb_rcslotdrop277:
  %v3546 = load i64, ptr %slot25, align 8
  %p3547 = inttoptr i64 %v3546 to ptr
  store i32 0, ptr %p3547, align 4, !alias.scope !3, !noalias !4
  %v3548 = load i64, ptr %slot35, align 8
  store i64 %v3548, ptr %slot275, align 8
  %v3549 = load i64, ptr %slot26, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %ld3551 = load i32, ptr %p3550, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3551, ptr %slot276, align 8
  %v3552 = load i32, ptr %slot276, align 8
  %op3553 = and i32 %v3552, 28
  store i32 %op3553, ptr %slot277, align 8
  %v3554 = load i32, ptr %slot277, align 8
  %cv3555 = zext i32 %v3554 to i64
  %cond3556 = icmp ne i64 %cv3555, 0
  br i1 %cond3556, label %bb_rcslotrole277, label %bb_rcslotowner277
bb_rcslotrole277:
  %v3557 = load i64, ptr %slot88, align 8
  store i64 %v3557, ptr %slot278, align 8
  %v3558 = load i64, ptr %slot278, align 8
  %v3559 = load i64, ptr %slot275, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3558, i64 %v3559) nomerge, !dbg !122
  br label %bb_rcslotdone277
bb_rcslotowner277:
  %v3560 = load i64, ptr %slot88, align 8
  store i64 %v3560, ptr %slot279, align 8
  %v3561 = load i64, ptr %slot279, align 8
  %v3562 = load i64, ptr %slot275, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3561, i64 %v3562) nomerge, !dbg !122
  br label %bb_rcslotdone277
bb_rcslotdone277:
  %v3563 = load i64, ptr %slot68, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i64, ptr %p3564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3565, ptr %slot280, align 8
  %v3566 = load i64, ptr %slot280, align 8
  %v3567 = load i64, ptr %slot55, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  store i64 %v3566, ptr %p3568, align 8, !alias.scope !3, !noalias !4
  %v3569 = load i64, ptr %slot51, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  %ld3571 = load i64, ptr %p3570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3571, ptr %slot281, align 8
  %v3572 = load i64, ptr %slot281, align 8
  %op3573 = add i64 %v3572, 0
  store i64 %op3573, ptr %slot282, align 8
  %v3574 = load i64, ptr %slot54, align 8
  store i64 %v3574, ptr %slot283, align 8
  %v3575 = load i64, ptr %slot283, align 8
  %v3576 = load i64, ptr %slot282, align 8
  %p3577 = inttoptr i64 %v3575 to ptr
  %p3578 = inttoptr i64 %v3576 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3578, ptr %p3577, i64 208, i1 false), !alias.scope !10000000
  %v3579 = load i64, ptr %slot283, align 8
  %p3580 = inttoptr i64 %v3579 to ptr
  call void @llvm.memset.p0.i64(ptr %p3580, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v3581 = load i64, ptr %slot7, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  store i32 0, ptr %p3582, align 4, !alias.scope !3, !noalias !4
  %v3583 = load i64, ptr %slot68, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i64 0, ptr %p3584, align 8, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot51, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  %ld3587 = load i64, ptr %p3586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3587, ptr %slot284, align 8
  %v3588 = load i64, ptr %slot284, align 8
  %v3589 = load i64, ptr %slot68, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i64 %v3588, ptr %p3590, align 8, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot68, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  %ld3593 = load i64, ptr %p3592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3593, ptr %slot285, align 8
  %v3594 = load i64, ptr %slot285, align 8
  %op3595 = add i64 %v3594, 0
  store i64 %op3595, ptr %slot286, align 8
  %v3596 = load i64, ptr %slot286, align 8
  %v3597 = load i64, ptr %slot68, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  store i64 %v3596, ptr %p3598, align 8, !alias.scope !3, !noalias !4
  %v3599 = load i64, ptr %slot23, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  %ld3601 = load i32, ptr %p3600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3601, ptr %slot287, align 8
  %v3602 = load i32, ptr %slot287, align 8
  %cv3603 = zext i32 %v3602 to i64
  %cond3604 = icmp ne i64 %cv3603, 0
  br i1 %cond3604, label %bb_rcslotdrop294, label %bb_rcslotdone294
bb_rcslotdrop294:
  %v3605 = load i64, ptr %slot23, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  store i32 0, ptr %p3606, align 4, !alias.scope !3, !noalias !4
  %v3607 = load i64, ptr %slot34, align 8
  store i64 %v3607, ptr %slot288, align 8
  %v3608 = load i64, ptr %slot24, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i32, ptr %p3609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3610, ptr %slot289, align 8
  %v3611 = load i32, ptr %slot289, align 8
  %op3612 = and i32 %v3611, 28
  store i32 %op3612, ptr %slot290, align 8
  %v3613 = load i32, ptr %slot290, align 8
  %cv3614 = zext i32 %v3613 to i64
  %cond3615 = icmp ne i64 %cv3614, 0
  br i1 %cond3615, label %bb_rcslotrole294, label %bb_rcslotowner294
bb_rcslotrole294:
  %v3616 = load i64, ptr %slot88, align 8
  store i64 %v3616, ptr %slot291, align 8
  %v3617 = load i64, ptr %slot291, align 8
  %v3618 = load i64, ptr %slot288, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3617, i64 %v3618) nomerge, !dbg !126
  br label %bb_rcslotdone294
bb_rcslotowner294:
  %v3619 = load i64, ptr %slot88, align 8
  store i64 %v3619, ptr %slot292, align 8
  %v3620 = load i64, ptr %slot292, align 8
  %v3621 = load i64, ptr %slot288, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3620, i64 %v3621) nomerge, !dbg !126
  br label %bb_rcslotdone294
bb_rcslotdone294:
  %v3622 = load i64, ptr %slot68, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %ld3624 = load i64, ptr %p3623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3624, ptr %slot293, align 8
  %v3625 = load i64, ptr %slot293, align 8
  %op3626 = add i64 %v3625, 160
  store i64 %op3626, ptr %slot294, align 8
  %v3627 = load i64, ptr %slot294, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i64, ptr %p3628, align 8
  store i64 %ld3629, ptr %slot295, align 8
  %v3630 = load i64, ptr %slot295, align 8
  %v3631 = load i64, ptr %slot68, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  store i64 %v3630, ptr %p3632, align 8, !alias.scope !3, !noalias !4
  %v3633 = load i64, ptr %slot68, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  %ld3635 = load i64, ptr %p3634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3635, ptr %slot296, align 8
  %v3636 = load i64, ptr %slot296, align 8
  %v3637 = load i64, ptr %slot38, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i64 %v3636, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot38, align 8
  store i64 %v3639, ptr %slot297, align 8
  %v3640 = load i64, ptr %slot42, align 8
  store i64 %v3640, ptr %slot298, align 8
  %v3641 = load i64, ptr %slot297, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  %ld3643 = load i64, ptr %p3642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3643, ptr %slot299, align 8
  %v3644 = load i64, ptr %slot299, align 8
  %cmp3645 = icmp ne i64 %v3644, 0
  %cv3646 = zext i1 %cmp3645 to i32
  store i32 %cv3646, ptr %slot300, align 8
  %v3647 = load i32, ptr %slot300, align 8
  %cv3648 = zext i32 %v3647 to i64
  %cond3649 = icmp ne i64 %cv3648, 0
  br i1 %cond3649, label %bb_rcgnn308, label %bb_rcgstore308
bb_rcgnn308:
  %v3650 = load i64, ptr %slot299, align 8
  %op3651 = sub i64 %v3650, 16
  store i64 %op3651, ptr %slot301, align 8
  %v3652 = load i64, ptr %slot299, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %rgep3654 = getelementptr i8, ptr %p3653, i64 -16
  %ld3655 = load i64, ptr %rgep3654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3655, ptr %slot302, align 8
  %v3656 = load i64, ptr %slot302, align 8
  %op3657 = and i64 %v3656, 4611686018427387906
  store i64 %op3657, ptr %slot303, align 8
  %v3658 = load i64, ptr %slot303, align 8
  %cmp3659 = icmp ne i64 %v3658, 0
  %cv3660 = zext i1 %cmp3659 to i32
  store i32 %cv3660, ptr %slot304, align 8
  %v3661 = load i32, ptr %slot304, align 8
  %cv3662 = zext i32 %v3661 to i64
  %cond3663 = icmp ne i64 %cv3662, 0
  br i1 %cond3663, label %bb_rcgstore308, label %bb_rcginc308
bb_rcginc308:
  %v3664 = load i64, ptr %slot299, align 8
  %op3665 = sub i64 %v3664, 24
  store i64 %op3665, ptr %slot305, align 8
  %v3666 = load i64, ptr %slot299, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  %rgep3668 = getelementptr i8, ptr %p3667, i64 -24
  %ld3669 = load i64, ptr %rgep3668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3669, ptr %slot306, align 8
  %v3670 = load i64, ptr %slot306, align 8
  %op3671 = add i64 %v3670, 1
  store i64 %op3671, ptr %slot307, align 8
  %v3672 = load i64, ptr %slot307, align 8
  %cmp3673 = icmp eq i64 %v3672, 0
  %cv3674 = zext i1 %cmp3673 to i32
  store i32 %cv3674, ptr %slot308, align 8
  %v3675 = load i32, ptr %slot308, align 8
  %cv3676 = zext i32 %v3675 to i64
  %cond3677 = icmp ne i64 %cv3676, 0
  br i1 %cond3677, label %bb_rcglimit308, label %bb_rcgcapacity308
bb_rcglimit308:
  %v3678 = load i64, ptr %slot1, align 8
  %p3679 = inttoptr i64 %v3678 to ptr
  %call3680 = call i32 @myl_qbe_rc_status(ptr %p3679, i32 2) nomerge, !dbg !128
  store i32 %call3680, ptr %slot309, align 8
  br label %bb_failure
bb_rcgcapacity308:
  %v3681 = load i64, ptr %slot307, align 8
  %v3682 = load i64, ptr %slot299, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  %rgep3684 = getelementptr i8, ptr %p3683, i64 -24
  store i64 %v3681, ptr %rgep3684, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore308
bb_rcgstore308:
  %v3685 = load i64, ptr %slot299, align 8
  %v3686 = load i64, ptr %slot298, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  store i64 %v3685, ptr %p3687, align 8, !alias.scope !3, !noalias !4
  %v3688 = load i64, ptr %slot32, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  store i32 2, ptr %p3689, align 4, !alias.scope !3, !noalias !4
  %v3690 = load i64, ptr %slot32, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  store i32 16, ptr %p3691, align 4, !alias.scope !3, !noalias !4
  %v3692 = load i64, ptr %slot31, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  store i32 1, ptr %p3693, align 4, !alias.scope !3, !noalias !4
  %v3694 = load i64, ptr %slot23, align 8
  %p3695 = inttoptr i64 %v3694 to ptr
  %ld3696 = load i32, ptr %p3695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3696, ptr %slot310, align 8
  %v3697 = load i32, ptr %slot310, align 8
  %cv3698 = zext i32 %v3697 to i64
  %cond3699 = icmp ne i64 %cv3698, 0
  br i1 %cond3699, label %bb_rcslotdrop324, label %bb_rcslotdone324
bb_rcslotdrop324:
  %v3700 = load i64, ptr %slot23, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  store i32 0, ptr %p3701, align 4, !alias.scope !3, !noalias !4
  %v3702 = load i64, ptr %slot34, align 8
  store i64 %v3702, ptr %slot311, align 8
  %v3703 = load i64, ptr %slot24, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  %ld3705 = load i32, ptr %p3704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3705, ptr %slot312, align 8
  %v3706 = load i32, ptr %slot312, align 8
  %op3707 = and i32 %v3706, 28
  store i32 %op3707, ptr %slot313, align 8
  %v3708 = load i32, ptr %slot313, align 8
  %cv3709 = zext i32 %v3708 to i64
  %cond3710 = icmp ne i64 %cv3709, 0
  br i1 %cond3710, label %bb_rcslotrole324, label %bb_rcslotowner324
bb_rcslotrole324:
  %v3711 = load i64, ptr %slot88, align 8
  store i64 %v3711, ptr %slot314, align 8
  %v3712 = load i64, ptr %slot314, align 8
  %v3713 = load i64, ptr %slot311, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3712, i64 %v3713) nomerge, !dbg !128
  br label %bb_rcslotdone324
bb_rcslotowner324:
  %v3714 = load i64, ptr %slot88, align 8
  store i64 %v3714, ptr %slot315, align 8
  %v3715 = load i64, ptr %slot315, align 8
  %v3716 = load i64, ptr %slot311, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3715, i64 %v3716) nomerge, !dbg !128
  br label %bb_rcslotdone324
bb_rcslotdone324:
  %v3717 = load i64, ptr %slot34, align 8
  store i64 %v3717, ptr %slot316, align 8
  %v3718 = load i64, ptr %slot42, align 8
  store i64 %v3718, ptr %slot317, align 8
  %v3719 = load i64, ptr %slot317, align 8
  %v3720 = load i64, ptr %slot316, align 8
  %p3721 = inttoptr i64 %v3719 to ptr
  %p3722 = inttoptr i64 %v3720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3722, ptr %p3721, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3723 = load i64, ptr %slot24, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  store i32 2, ptr %p3724, align 4, !alias.scope !3, !noalias !4
  %v3725 = load i64, ptr %slot32, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  %ld3727 = load i32, ptr %p3726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3727, ptr %slot318, align 8
  %v3728 = load i32, ptr %slot318, align 8
  %v3729 = load i64, ptr %slot24, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i32 %v3728, ptr %p3730, align 4, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot31, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  store i32 0, ptr %p3732, align 4, !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot23, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  store i32 1, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  %v3735 = load i64, ptr %slot316, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %ld3737 = load i64, ptr %p3736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3737, ptr %slot319, align 8
  %v3738 = load i64, ptr %slot319, align 8
  %v3739 = load i64, ptr %slot68, align 8
  %p3740 = inttoptr i64 %v3739 to ptr
  store i64 %v3738, ptr %p3740, align 8, !alias.scope !3, !noalias !4
  %v3741 = load i64, ptr %slot68, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  %ld3743 = load i64, ptr %p3742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3743, ptr %slot320, align 8
  %v3744 = load i64, ptr %slot51, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  %ld3746 = load i64, ptr %p3745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3746, ptr %slot321, align 8
  %v3747 = load i64, ptr %slot23, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  %ld3749 = load i32, ptr %p3748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3749, ptr %slot322, align 8
  %v3750 = load i32, ptr %slot322, align 8
  %cv3751 = zext i32 %v3750 to i64
  %cond3752 = icmp ne i64 %cv3751, 0
  br i1 %cond3752, label %bb_rcslotdrop345, label %bb_rcslotdone345
bb_rcslotdrop345:
  %v3753 = load i64, ptr %slot23, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  store i32 0, ptr %p3754, align 4, !alias.scope !3, !noalias !4
  %v3755 = load i64, ptr %slot34, align 8
  store i64 %v3755, ptr %slot323, align 8
  %v3756 = load i64, ptr %slot24, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  %ld3758 = load i32, ptr %p3757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3758, ptr %slot324, align 8
  %v3759 = load i32, ptr %slot324, align 8
  %op3760 = and i32 %v3759, 28
  store i32 %op3760, ptr %slot325, align 8
  %v3761 = load i32, ptr %slot325, align 8
  %cv3762 = zext i32 %v3761 to i64
  %cond3763 = icmp ne i64 %cv3762, 0
  br i1 %cond3763, label %bb_rcslotrole345, label %bb_rcslotowner345
bb_rcslotrole345:
  %v3764 = load i64, ptr %slot88, align 8
  store i64 %v3764, ptr %slot326, align 8
  %v3765 = load i64, ptr %slot323, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  %ld3767 = load i64, ptr %p3766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3767, ptr %slot327, align 8
  %v3768 = load i64, ptr %slot327, align 8
  %cmp3769 = icmp ne i64 %v3768, 0
  %cv3770 = zext i1 %cmp3769 to i32
  store i32 %cv3770, ptr %slot328, align 8
  %v3771 = load i32, ptr %slot328, align 8
  %cv3772 = zext i32 %v3771 to i64
  %cond3773 = icmp ne i64 %cv3772, 0
  br i1 %cond3773, label %bb_rcgnn361, label %bb_rcgdone361
bb_rcgnn361:
  %v3774 = load i64, ptr %slot327, align 8
  %op3775 = sub i64 %v3774, 16
  store i64 %op3775, ptr %slot329, align 8
  %v3776 = load i64, ptr %slot327, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %rgep3778 = getelementptr i8, ptr %p3777, i64 -16
  %ld3779 = load i64, ptr %rgep3778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3779, ptr %slot330, align 8
  %v3780 = load i64, ptr %slot330, align 8
  %op3781 = and i64 %v3780, 4611686018427387906
  store i64 %op3781, ptr %slot331, align 8
  %v3782 = load i64, ptr %slot331, align 8
  %cmp3783 = icmp ne i64 %v3782, 0
  %cv3784 = zext i1 %cmp3783 to i32
  store i32 %cv3784, ptr %slot332, align 8
  %v3785 = load i32, ptr %slot332, align 8
  %cv3786 = zext i32 %v3785 to i64
  %cond3787 = icmp ne i64 %cv3786, 0
  br i1 %cond3787, label %bb_rcgclear361, label %bb_rcgcounted361
bb_rcgcounted361:
  %v3788 = load i64, ptr %slot327, align 8
  %op3789 = sub i64 %v3788, 24
  store i64 %op3789, ptr %slot333, align 8
  %v3790 = load i64, ptr %slot327, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %rgep3792 = getelementptr i8, ptr %p3791, i64 -24
  %ld3793 = load i64, ptr %rgep3792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3793, ptr %slot334, align 8
  %v3794 = load i64, ptr %slot334, align 8
  %op3795 = sub i64 %v3794, 1
  store i64 %op3795, ptr %slot335, align 8
  %v3796 = load i64, ptr %slot335, align 8
  %cmp3797 = icmp eq i64 %v3796, 0
  %cv3798 = zext i1 %cmp3797 to i32
  store i32 %cv3798, ptr %slot336, align 8
  %v3799 = load i32, ptr %slot336, align 8
  %cv3800 = zext i32 %v3799 to i64
  %cond3801 = icmp ne i64 %cv3800, 0
  br i1 %cond3801, label %bb_rcglast361, label %bb_rcgdec361
bb_rcglast361:
  %v3802 = load i64, ptr %slot327, align 8
  %op3803 = sub i64 %v3802, 32
  store i64 %op3803, ptr %slot337, align 8
  %v3804 = load i64, ptr %slot327, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %rgep3806 = getelementptr i8, ptr %p3805, i64 -32
  %ld3807 = load i64, ptr %rgep3806, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3807, ptr %slot338, align 8
  %v3808 = load i64, ptr %slot338, align 8
  %cmp3809 = icmp ne i64 %v3808, 0
  %cv3810 = zext i1 %cmp3809 to i32
  store i32 %cv3810, ptr %slot339, align 8
  %v3811 = load i32, ptr %slot339, align 8
  %cv3812 = zext i32 %v3811 to i64
  %cond3813 = icmp ne i64 %cv3812, 0
  br i1 %cond3813, label %bb_rcgdec361, label %bb_rcgslow361
bb_rcgslow361:
  %v3814 = load i64, ptr %slot326, align 8
  %v3815 = load i64, ptr %slot323, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3814, i64 %v3815) nomerge, !dbg !130
  br label %bb_rcgdone361
bb_rcgdec361:
  %v3816 = load i64, ptr %slot335, align 8
  %v3817 = load i64, ptr %slot327, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  %rgep3819 = getelementptr i8, ptr %p3818, i64 -24
  store i64 %v3816, ptr %rgep3819, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear361
bb_rcgclear361:
  %v3820 = load i64, ptr %slot323, align 8
  %p3821 = inttoptr i64 %v3820 to ptr
  store i64 0, ptr %p3821, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone361
bb_rcgdone361:
  br label %bb_rcslotdone345
bb_rcslotowner345:
  %v3822 = load i64, ptr %slot88, align 8
  store i64 %v3822, ptr %slot340, align 8
  %v3823 = load i64, ptr %slot323, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  %ld3825 = load i64, ptr %p3824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3825, ptr %slot341, align 8
  %v3826 = load i64, ptr %slot341, align 8
  %cmp3827 = icmp ne i64 %v3826, 0
  %cv3828 = zext i1 %cmp3827 to i32
  store i32 %cv3828, ptr %slot342, align 8
  %v3829 = load i32, ptr %slot342, align 8
  %cv3830 = zext i32 %v3829 to i64
  %cond3831 = icmp ne i64 %cv3830, 0
  br i1 %cond3831, label %bb_rcgnn376, label %bb_rcgdone376
bb_rcgnn376:
  %v3832 = load i64, ptr %slot341, align 8
  %op3833 = sub i64 %v3832, 16
  store i64 %op3833, ptr %slot343, align 8
  %v3834 = load i64, ptr %slot341, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  %rgep3836 = getelementptr i8, ptr %p3835, i64 -16
  %ld3837 = load i64, ptr %rgep3836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3837, ptr %slot344, align 8
  %v3838 = load i64, ptr %slot344, align 8
  %op3839 = and i64 %v3838, 4611686018427387906
  store i64 %op3839, ptr %slot345, align 8
  %v3840 = load i64, ptr %slot345, align 8
  %cmp3841 = icmp ne i64 %v3840, 0
  %cv3842 = zext i1 %cmp3841 to i32
  store i32 %cv3842, ptr %slot346, align 8
  %v3843 = load i32, ptr %slot346, align 8
  %cv3844 = zext i32 %v3843 to i64
  %cond3845 = icmp ne i64 %cv3844, 0
  br i1 %cond3845, label %bb_rcgclear376, label %bb_rcgcounted376
bb_rcgcounted376:
  %v3846 = load i64, ptr %slot341, align 8
  %op3847 = sub i64 %v3846, 32
  store i64 %op3847, ptr %slot347, align 8
  %v3848 = load i64, ptr %slot341, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %rgep3850 = getelementptr i8, ptr %p3849, i64 -32
  %ld3851 = load i64, ptr %rgep3850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3851, ptr %slot348, align 8
  %v3852 = load i64, ptr %slot348, align 8
  %op3853 = sub i64 %v3852, 1
  store i64 %op3853, ptr %slot349, align 8
  %v3854 = load i64, ptr %slot349, align 8
  %cmp3855 = icmp eq i64 %v3854, 0
  %cv3856 = zext i1 %cmp3855 to i32
  store i32 %cv3856, ptr %slot350, align 8
  %v3857 = load i32, ptr %slot350, align 8
  %cv3858 = zext i32 %v3857 to i64
  %cond3859 = icmp ne i64 %cv3858, 0
  br i1 %cond3859, label %bb_rcglast376, label %bb_rcgdec376
bb_rcglast376:
  %v3860 = load i64, ptr %slot341, align 8
  %op3861 = sub i64 %v3860, 24
  store i64 %op3861, ptr %slot351, align 8
  %v3862 = load i64, ptr %slot341, align 8
  %p3863 = inttoptr i64 %v3862 to ptr
  %rgep3864 = getelementptr i8, ptr %p3863, i64 -24
  %ld3865 = load i64, ptr %rgep3864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3865, ptr %slot352, align 8
  %v3866 = load i64, ptr %slot352, align 8
  %cmp3867 = icmp ne i64 %v3866, 0
  %cv3868 = zext i1 %cmp3867 to i32
  store i32 %cv3868, ptr %slot353, align 8
  %v3869 = load i32, ptr %slot353, align 8
  %cv3870 = zext i32 %v3869 to i64
  %cond3871 = icmp ne i64 %cv3870, 0
  br i1 %cond3871, label %bb_rcgdec376, label %bb_rcgslow376
bb_rcgslow376:
  %v3872 = load i64, ptr %slot340, align 8
  %v3873 = load i64, ptr %slot323, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3872, i64 %v3873) nomerge, !dbg !130
  br label %bb_rcgdone376
bb_rcgdec376:
  %v3874 = load i64, ptr %slot349, align 8
  %v3875 = load i64, ptr %slot341, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  %rgep3877 = getelementptr i8, ptr %p3876, i64 -32
  store i64 %v3874, ptr %rgep3877, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear376
bb_rcgclear376:
  %v3878 = load i64, ptr %slot323, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  store i64 0, ptr %p3879, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone376
bb_rcgdone376:
  br label %bb_rcslotdone345
bb_rcslotdone345:
  %v3880 = load i64, ptr %slot321, align 8
  %op3881 = add i64 %v3880, 0
  store i64 %op3881, ptr %slot354, align 8
  %v3882 = load i64, ptr %slot354, align 8
  %op3883 = add i64 %v3882, 160
  store i64 %op3883, ptr %slot355, align 8
  store i64 0, ptr %slot356, align 8
  %v3884 = load i64, ptr %slot355, align 8
  %p3885 = inttoptr i64 %v3884 to ptr
  %ld3886 = load i64, ptr %p3885, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3886, ptr %slot357, align 8
  %v3887 = load i64, ptr %slot357, align 8
  %cmp3888 = icmp ne i64 %v3887, 0
  %cv3889 = zext i1 %cmp3888 to i32
  store i32 %cv3889, ptr %slot358, align 8
  %v3890 = load i32, ptr %slot358, align 8
  %cv3891 = zext i32 %v3890 to i64
  %cond3892 = icmp ne i64 %cv3891, 0
  br i1 %cond3892, label %bb_rcguniquenn383, label %bb_rcgunique383
bb_rcguniquenn383:
  %v3893 = load i64, ptr %slot357, align 8
  %op3894 = sub i64 %v3893, 16
  store i64 %op3894, ptr %slot359, align 8
  %v3895 = load i64, ptr %slot357, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %rgep3897 = getelementptr i8, ptr %p3896, i64 -16
  %ld3898 = load i64, ptr %rgep3897, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3898, ptr %slot360, align 8
  %v3899 = load i64, ptr %slot360, align 8
  %op3900 = and i64 %v3899, 6917529027641081858
  store i64 %op3900, ptr %slot361, align 8
  %v3901 = load i64, ptr %slot361, align 8
  %cmp3902 = icmp ne i64 %v3901, 0
  %cv3903 = zext i1 %cmp3902 to i32
  store i32 %cv3903, ptr %slot362, align 8
  %v3904 = load i32, ptr %slot362, align 8
  %cv3905 = zext i32 %v3904 to i64
  %cond3906 = icmp ne i64 %cv3905, 0
  br i1 %cond3906, label %bb_rcguniqueslow383, label %bb_rcguniquecount383
bb_rcguniquecount383:
  %v3907 = load i64, ptr %slot357, align 8
  %op3908 = sub i64 %v3907, 32
  store i64 %op3908, ptr %slot363, align 8
  %v3909 = load i64, ptr %slot357, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %rgep3911 = getelementptr i8, ptr %p3910, i64 -32
  %ld3912 = load i64, ptr %rgep3911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3912, ptr %slot364, align 8
  %v3913 = load i64, ptr %slot364, align 8
  %cmp3914 = icmp ult i64 %v3913, 2
  %cv3915 = zext i1 %cmp3914 to i32
  store i32 %cv3915, ptr %slot365, align 8
  %v3916 = load i32, ptr %slot365, align 8
  %cv3917 = zext i32 %v3916 to i64
  %cond3918 = icmp ne i64 %cv3917, 0
  br i1 %cond3918, label %bb_rcgunique383, label %bb_rcguniqueslow383
bb_rcguniqueslow383:
  %v3919 = load i64, ptr %slot1, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %p3921 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v3922 = load i64, ptr %slot355, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  %v3924 = load i64, ptr %slot356, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %call3926 = call i32 @myl_qbe_rc_unique_field(ptr %p3920, ptr %p3921, ptr %p3923, ptr %p3925) nomerge, !dbg !130
  store i32 %call3926, ptr %slot366, align 8
  %v3927 = load i32, ptr %slot366, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rcunique393, label %bb_failure
bb_rcunique393:
  br label %bb_rcgunique383
bb_rcgunique383:
  %v3930 = load i64, ptr %slot355, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  %ld3932 = load i64, ptr %p3931, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3932, ptr %slot367, align 8
  %v3933 = load i64, ptr %slot367, align 8
  %v3934 = load i64, ptr %slot68, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  store i64 %v3933, ptr %p3935, align 8, !alias.scope !3, !noalias !4
  %v3936 = load i64, ptr %slot68, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  %ld3938 = load i64, ptr %p3937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3938, ptr %slot368, align 8
  %v3939 = load i64, ptr %slot23, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  %ld3941 = load i32, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3941, ptr %slot369, align 8
  %v3942 = load i32, ptr %slot369, align 8
  %cv3943 = zext i32 %v3942 to i64
  %cond3944 = icmp ne i64 %cv3943, 0
  br i1 %cond3944, label %bb_rcslotdrop398, label %bb_rcslotdone398
bb_rcslotdrop398:
  %v3945 = load i64, ptr %slot23, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  store i32 0, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  %v3947 = load i64, ptr %slot34, align 8
  store i64 %v3947, ptr %slot370, align 8
  %v3948 = load i64, ptr %slot24, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  %ld3950 = load i32, ptr %p3949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3950, ptr %slot371, align 8
  %v3951 = load i32, ptr %slot371, align 8
  %op3952 = and i32 %v3951, 28
  store i32 %op3952, ptr %slot372, align 8
  %v3953 = load i32, ptr %slot372, align 8
  %cv3954 = zext i32 %v3953 to i64
  %cond3955 = icmp ne i64 %cv3954, 0
  br i1 %cond3955, label %bb_rcslotrole398, label %bb_rcslotowner398
bb_rcslotrole398:
  %v3956 = load i64, ptr %slot88, align 8
  store i64 %v3956, ptr %slot373, align 8
  %v3957 = load i64, ptr %slot370, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i64, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3959, ptr %slot374, align 8
  %v3960 = load i64, ptr %slot374, align 8
  %cmp3961 = icmp ne i64 %v3960, 0
  %cv3962 = zext i1 %cmp3961 to i32
  store i32 %cv3962, ptr %slot375, align 8
  %v3963 = load i32, ptr %slot375, align 8
  %cv3964 = zext i32 %v3963 to i64
  %cond3965 = icmp ne i64 %cv3964, 0
  br i1 %cond3965, label %bb_rcgnn414, label %bb_rcgdone414
bb_rcgnn414:
  %v3966 = load i64, ptr %slot374, align 8
  %op3967 = sub i64 %v3966, 16
  store i64 %op3967, ptr %slot376, align 8
  %v3968 = load i64, ptr %slot374, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %rgep3970 = getelementptr i8, ptr %p3969, i64 -16
  %ld3971 = load i64, ptr %rgep3970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3971, ptr %slot377, align 8
  %v3972 = load i64, ptr %slot377, align 8
  %op3973 = and i64 %v3972, 4611686018427387906
  store i64 %op3973, ptr %slot378, align 8
  %v3974 = load i64, ptr %slot378, align 8
  %cmp3975 = icmp ne i64 %v3974, 0
  %cv3976 = zext i1 %cmp3975 to i32
  store i32 %cv3976, ptr %slot379, align 8
  %v3977 = load i32, ptr %slot379, align 8
  %cv3978 = zext i32 %v3977 to i64
  %cond3979 = icmp ne i64 %cv3978, 0
  br i1 %cond3979, label %bb_rcgclear414, label %bb_rcgcounted414
bb_rcgcounted414:
  %v3980 = load i64, ptr %slot374, align 8
  %op3981 = sub i64 %v3980, 24
  store i64 %op3981, ptr %slot380, align 8
  %v3982 = load i64, ptr %slot374, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %rgep3984 = getelementptr i8, ptr %p3983, i64 -24
  %ld3985 = load i64, ptr %rgep3984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3985, ptr %slot381, align 8
  %v3986 = load i64, ptr %slot381, align 8
  %op3987 = sub i64 %v3986, 1
  store i64 %op3987, ptr %slot382, align 8
  %v3988 = load i64, ptr %slot382, align 8
  %cmp3989 = icmp eq i64 %v3988, 0
  %cv3990 = zext i1 %cmp3989 to i32
  store i32 %cv3990, ptr %slot383, align 8
  %v3991 = load i32, ptr %slot383, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcglast414, label %bb_rcgdec414
bb_rcglast414:
  %v3994 = load i64, ptr %slot374, align 8
  %op3995 = sub i64 %v3994, 32
  store i64 %op3995, ptr %slot384, align 8
  %v3996 = load i64, ptr %slot374, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %rgep3998 = getelementptr i8, ptr %p3997, i64 -32
  %ld3999 = load i64, ptr %rgep3998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3999, ptr %slot385, align 8
  %v4000 = load i64, ptr %slot385, align 8
  %cmp4001 = icmp ne i64 %v4000, 0
  %cv4002 = zext i1 %cmp4001 to i32
  store i32 %cv4002, ptr %slot386, align 8
  %v4003 = load i32, ptr %slot386, align 8
  %cv4004 = zext i32 %v4003 to i64
  %cond4005 = icmp ne i64 %cv4004, 0
  br i1 %cond4005, label %bb_rcgdec414, label %bb_rcgslow414
bb_rcgslow414:
  %v4006 = load i64, ptr %slot373, align 8
  %v4007 = load i64, ptr %slot370, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4006, i64 %v4007) nomerge, !dbg !130
  br label %bb_rcgdone414
bb_rcgdec414:
  %v4008 = load i64, ptr %slot382, align 8
  %v4009 = load i64, ptr %slot374, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %rgep4011 = getelementptr i8, ptr %p4010, i64 -24
  store i64 %v4008, ptr %rgep4011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear414
bb_rcgclear414:
  %v4012 = load i64, ptr %slot370, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  store i64 0, ptr %p4013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone414
bb_rcgdone414:
  br label %bb_rcslotdone398
bb_rcslotowner398:
  %v4014 = load i64, ptr %slot88, align 8
  store i64 %v4014, ptr %slot387, align 8
  %v4015 = load i64, ptr %slot370, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  %ld4017 = load i64, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4017, ptr %slot388, align 8
  %v4018 = load i64, ptr %slot388, align 8
  %cmp4019 = icmp ne i64 %v4018, 0
  %cv4020 = zext i1 %cmp4019 to i32
  store i32 %cv4020, ptr %slot389, align 8
  %v4021 = load i32, ptr %slot389, align 8
  %cv4022 = zext i32 %v4021 to i64
  %cond4023 = icmp ne i64 %cv4022, 0
  br i1 %cond4023, label %bb_rcgnn429, label %bb_rcgdone429
bb_rcgnn429:
  %v4024 = load i64, ptr %slot388, align 8
  %op4025 = sub i64 %v4024, 16
  store i64 %op4025, ptr %slot390, align 8
  %v4026 = load i64, ptr %slot388, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  %rgep4028 = getelementptr i8, ptr %p4027, i64 -16
  %ld4029 = load i64, ptr %rgep4028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4029, ptr %slot391, align 8
  %v4030 = load i64, ptr %slot391, align 8
  %op4031 = and i64 %v4030, 4611686018427387906
  store i64 %op4031, ptr %slot392, align 8
  %v4032 = load i64, ptr %slot392, align 8
  %cmp4033 = icmp ne i64 %v4032, 0
  %cv4034 = zext i1 %cmp4033 to i32
  store i32 %cv4034, ptr %slot393, align 8
  %v4035 = load i32, ptr %slot393, align 8
  %cv4036 = zext i32 %v4035 to i64
  %cond4037 = icmp ne i64 %cv4036, 0
  br i1 %cond4037, label %bb_rcgclear429, label %bb_rcgcounted429
bb_rcgcounted429:
  %v4038 = load i64, ptr %slot388, align 8
  %op4039 = sub i64 %v4038, 32
  store i64 %op4039, ptr %slot394, align 8
  %v4040 = load i64, ptr %slot388, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %rgep4042 = getelementptr i8, ptr %p4041, i64 -32
  %ld4043 = load i64, ptr %rgep4042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4043, ptr %slot395, align 8
  %v4044 = load i64, ptr %slot395, align 8
  %op4045 = sub i64 %v4044, 1
  store i64 %op4045, ptr %slot396, align 8
  %v4046 = load i64, ptr %slot396, align 8
  %cmp4047 = icmp eq i64 %v4046, 0
  %cv4048 = zext i1 %cmp4047 to i32
  store i32 %cv4048, ptr %slot397, align 8
  %v4049 = load i32, ptr %slot397, align 8
  %cv4050 = zext i32 %v4049 to i64
  %cond4051 = icmp ne i64 %cv4050, 0
  br i1 %cond4051, label %bb_rcglast429, label %bb_rcgdec429
bb_rcglast429:
  %v4052 = load i64, ptr %slot388, align 8
  %op4053 = sub i64 %v4052, 24
  store i64 %op4053, ptr %slot398, align 8
  %v4054 = load i64, ptr %slot388, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  %rgep4056 = getelementptr i8, ptr %p4055, i64 -24
  %ld4057 = load i64, ptr %rgep4056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4057, ptr %slot399, align 8
  %v4058 = load i64, ptr %slot399, align 8
  %cmp4059 = icmp ne i64 %v4058, 0
  %cv4060 = zext i1 %cmp4059 to i32
  store i32 %cv4060, ptr %slot400, align 8
  %v4061 = load i32, ptr %slot400, align 8
  %cv4062 = zext i32 %v4061 to i64
  %cond4063 = icmp ne i64 %cv4062, 0
  br i1 %cond4063, label %bb_rcgdec429, label %bb_rcgslow429
bb_rcgslow429:
  %v4064 = load i64, ptr %slot387, align 8
  %v4065 = load i64, ptr %slot370, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4064, i64 %v4065) nomerge, !dbg !130
  br label %bb_rcgdone429
bb_rcgdec429:
  %v4066 = load i64, ptr %slot396, align 8
  %v4067 = load i64, ptr %slot388, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  %rgep4069 = getelementptr i8, ptr %p4068, i64 -32
  store i64 %v4066, ptr %rgep4069, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear429
bb_rcgclear429:
  %v4070 = load i64, ptr %slot370, align 8
  %p4071 = inttoptr i64 %v4070 to ptr
  store i64 0, ptr %p4071, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone429
bb_rcgdone429:
  br label %bb_rcslotdone398
bb_rcslotdone398:
  %v4072 = load i64, ptr %slot44, align 8
  store i64 %v4072, ptr %slot401, align 8
  %v4073 = load i64, ptr %slot88, align 8
  %v4074 = load i64, ptr %slot401, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  store i64 %v4073, ptr %p4075, align 8, !alias.scope !3, !noalias !4
  %v4076 = load i64, ptr %slot88, align 8
  %p4078 = inttoptr i64 %v4076 to ptr
  %gep4079 = getelementptr i8, ptr %p4078, i64 5640
  %op4077 = ptrtoint ptr %gep4079 to i64
  store i64 %op4077, ptr %slot402, align 8
  %v4080 = load i64, ptr %slot402, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  %ld4082 = load i64, ptr %p4081, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4082, ptr %slot403, align 8
  %v4083 = load i64, ptr %slot403, align 8
  %op4084 = add i64 %v4083, 248
  store i64 %op4084, ptr %slot404, align 8
  %v4085 = load i64, ptr %slot404, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  %ld4087 = load i64, ptr %p4086, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4087, ptr %slot405, align 8
  %v4088 = load i64, ptr %slot401, align 8
  %p4090 = inttoptr i64 %v4088 to ptr
  %gep4091 = getelementptr i8, ptr %p4090, i64 8
  %op4089 = ptrtoint ptr %gep4091 to i64
  store i64 %op4089, ptr %slot406, align 8
  %v4092 = load i64, ptr %slot405, align 8
  %v4093 = load i64, ptr %slot406, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i64 %v4092, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot401, align 8
  %p4097 = inttoptr i64 %v4095 to ptr
  %gep4098 = getelementptr i8, ptr %p4097, i64 16
  %op4096 = ptrtoint ptr %gep4098 to i64
  store i64 %op4096, ptr %slot407, align 8
  %v4099 = load i64, ptr %slot407, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i64 0, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot88, align 8
  %p4103 = inttoptr i64 %v4101 to ptr
  %gep4104 = getelementptr i8, ptr %p4103, i64 112
  %op4102 = ptrtoint ptr %gep4104 to i64
  store i64 %op4102, ptr %slot408, align 8
  %v4105 = load i64, ptr %slot401, align 8
  %p4107 = inttoptr i64 %v4105 to ptr
  %gep4108 = getelementptr i8, ptr %p4107, i64 24
  %op4106 = ptrtoint ptr %gep4108 to i64
  store i64 %op4106, ptr %slot409, align 8
  %v4109 = load i64, ptr %slot401, align 8
  %p4111 = inttoptr i64 %v4109 to ptr
  %gep4112 = getelementptr i8, ptr %p4111, i64 28
  %op4110 = ptrtoint ptr %gep4112 to i64
  store i64 %op4110, ptr %slot410, align 8
  %v4113 = load i64, ptr %slot408, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %ld4115 = load i32, ptr %p4114, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4115, ptr %slot411, align 8
  %v4116 = load i64, ptr %slot409, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  store i32 1, ptr %p4117, align 4, !alias.scope !3, !noalias !4
  %v4118 = load i32, ptr %slot411, align 8
  %v4119 = load i64, ptr %slot410, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  store i32 %v4118, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  %v4121 = load i64, ptr %slot401, align 8
  %v4122 = load i64, ptr %slot404, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  store i64 %v4121, ptr %p4123, align 8, !alias.scope !9999998, !noalias !9999999
  %v4124 = load i64, ptr %slot368, align 8
  %cmp4125 = icmp ne i64 %v4124, 0
  %cv4126 = zext i1 %cmp4125 to i32
  store i32 %cv4126, ptr %slot412, align 8
  %v4127 = load i32, ptr %slot412, align 8
  %cv4128 = zext i32 %v4127 to i64
  %cond4129 = icmp ne i64 %cv4128, 0
  br i1 %cond4129, label %bb_rcspinmark481, label %bb_rcspindone481
bb_rcspinmark481:
  %v4130 = load i64, ptr %slot368, align 8
  %op4131 = sub i64 %v4130, 16
  store i64 %op4131, ptr %slot413, align 8
  %v4132 = load i64, ptr %slot368, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  %rgep4134 = getelementptr i8, ptr %p4133, i64 -16
  %ld4135 = load i64, ptr %rgep4134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4135, ptr %slot414, align 8
  %v4136 = load i64, ptr %slot414, align 8
  %op4137 = and i64 %v4136, 2
  store i64 %op4137, ptr %slot415, align 8
  %v4138 = load i64, ptr %slot415, align 8
  %cmp4139 = icmp ne i64 %v4138, 0
  %cv4140 = zext i1 %cmp4139 to i32
  store i32 %cv4140, ptr %slot416, align 8
  %v4141 = load i32, ptr %slot416, align 8
  %cv4142 = zext i32 %v4141 to i64
  %cond4143 = icmp ne i64 %cv4142, 0
  br i1 %cond4143, label %bb_rcspindone481, label %bb_rcspintype481
bb_rcspintype481:
  %v4144 = load i64, ptr %slot414, align 8
  %op4145 = and i64 %v4144, 4611686018427387907
  store i64 %op4145, ptr %slot417, align 8
  %v4146 = load i64, ptr %slot417, align 8
  %cmp4147 = icmp eq i64 %v4146, 0
  %cv4148 = zext i1 %cmp4147 to i32
  store i32 %cv4148, ptr %slot418, align 8
  %v4149 = load i32, ptr %slot418, align 8
  %cv4150 = zext i32 %v4149 to i64
  %cond4151 = icmp ne i64 %cv4150, 0
  br i1 %cond4151, label %bb_rcs489, label %bb_rcspinslow481
bb_rcs489:
  %v4152 = load i64, ptr %slot368, align 8
  %op4153 = sub i64 %v4152, 8
  store i64 %op4153, ptr %slot419, align 8
  %v4154 = load i64, ptr %slot368, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  %rgep4156 = getelementptr i8, ptr %p4155, i64 -8
  %ld4157 = load i64, ptr %rgep4156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4157, ptr %slot420, align 8
  %p4158 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld4159 = load i64, ptr %p4158, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4159, ptr %slot421, align 8
  %v4160 = load i64, ptr %slot420, align 8
  %v4161 = load i64, ptr %slot421, align 8
  %cmp4162 = icmp eq i64 %v4160, %v4161
  %cv4163 = zext i1 %cmp4162 to i32
  store i32 %cv4163, ptr %slot422, align 8
  %v4164 = load i32, ptr %slot422, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcs494, label %bb_rcspinslow481
bb_rcs494:
  %v4167 = load i64, ptr %slot88, align 8
  %p4169 = inttoptr i64 %v4167 to ptr
  %gep4170 = getelementptr i8, ptr %p4169, i64 5640
  %op4168 = ptrtoint ptr %gep4170 to i64
  store i64 %op4168, ptr %slot423, align 8
  %v4171 = load i64, ptr %slot423, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i64, ptr %p4172, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4173, ptr %slot424, align 8
  %v4174 = load i64, ptr %slot424, align 8
  %op4175 = add i64 %v4174, 256
  store i64 %op4175, ptr %slot425, align 8
  %v4176 = load i64, ptr %slot425, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  %ld4178 = load i64, ptr %p4177, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4178, ptr %slot426, align 8
  %v4179 = load i64, ptr %slot426, align 8
  %cmp4180 = icmp ne i64 %v4179, 0
  %cv4181 = zext i1 %cmp4180 to i32
  store i32 %cv4181, ptr %slot427, align 8
  %v4182 = load i32, ptr %slot427, align 8
  %cv4183 = zext i32 %v4182 to i64
  %cond4184 = icmp ne i64 %cv4183, 0
  br i1 %cond4184, label %bb_rcs500, label %bb_rcspinslow481
bb_rcs500:
  %v4185 = load i64, ptr %slot88, align 8
  %p4187 = inttoptr i64 %v4185 to ptr
  %gep4188 = getelementptr i8, ptr %p4187, i64 24
  %op4186 = ptrtoint ptr %gep4188 to i64
  store i64 %op4186, ptr %slot428, align 8
  %v4189 = load i64, ptr %slot428, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  %ld4191 = load i64, ptr %p4190, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4191, ptr %slot429, align 8
  %v4192 = load i64, ptr %slot429, align 8
  %op4193 = add i64 %v4192, 40
  store i64 %op4193, ptr %slot430, align 8
  %v4194 = load i64, ptr %slot430, align 8
  %v4195 = load i64, ptr %slot429, align 8
  %cmp4196 = icmp uge i64 %v4194, %v4195
  %cv4197 = zext i1 %cmp4196 to i32
  store i32 %cv4197, ptr %slot431, align 8
  %v4198 = load i32, ptr %slot431, align 8
  %cv4199 = zext i32 %v4198 to i64
  %cond4200 = icmp ne i64 %cv4199, 0
  br i1 %cond4200, label %bb_rcs505, label %bb_rcspinslow481
bb_rcs505:
  %v4201 = load i64, ptr %slot88, align 8
  %p4203 = inttoptr i64 %v4201 to ptr
  %gep4204 = getelementptr i8, ptr %p4203, i64 88
  %op4202 = ptrtoint ptr %gep4204 to i64
  store i64 %op4202, ptr %slot432, align 8
  %v4205 = load i64, ptr %slot432, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %ld4207 = load i64, ptr %p4206, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4207, ptr %slot433, align 8
  %v4208 = load i64, ptr %slot433, align 8
  %cmp4209 = icmp eq i64 %v4208, 0
  %cv4210 = zext i1 %cmp4209 to i32
  store i32 %cv4210, ptr %slot434, align 8
  %v4211 = load i64, ptr %slot430, align 8
  %v4212 = load i64, ptr %slot433, align 8
  %cmp4213 = icmp ule i64 %v4211, %v4212
  %cv4214 = zext i1 %cmp4213 to i32
  store i32 %cv4214, ptr %slot435, align 8
  %v4215 = load i32, ptr %slot434, align 8
  %v4216 = load i32, ptr %slot435, align 8
  %op4217 = or i32 %v4215, %v4216
  store i32 %op4217, ptr %slot436, align 8
  %v4218 = load i32, ptr %slot436, align 8
  %cv4219 = zext i32 %v4218 to i64
  %cond4220 = icmp ne i64 %cv4219, 0
  br i1 %cond4220, label %bb_rcs511, label %bb_rcspinslow481
bb_rcs511:
  %v4221 = load i64, ptr %slot368, align 8
  %op4222 = sub i64 %v4221, 24
  store i64 %op4222, ptr %slot437, align 8
  %v4223 = load i64, ptr %slot368, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  %rgep4225 = getelementptr i8, ptr %p4224, i64 -24
  %ld4226 = load i64, ptr %rgep4225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4226, ptr %slot438, align 8
  %v4227 = load i64, ptr %slot438, align 8
  %cmp4228 = icmp ne i64 %v4227, 18446744073709551615
  %cv4229 = zext i1 %cmp4228 to i32
  store i32 %cv4229, ptr %slot439, align 8
  %v4230 = load i32, ptr %slot439, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcs515, label %bb_rcspinslow481
bb_rcs515:
  %v4233 = load i64, ptr %slot368, align 8
  %op4234 = add i64 %v4233, 32
  store i64 %op4234, ptr %slot440, align 8
  %v4235 = load i64, ptr %slot440, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  %ld4237 = load i64, ptr %p4236, align 8
  store i64 %ld4237, ptr %slot441, align 8
  %v4238 = load i64, ptr %slot441, align 8
  %cmp4239 = icmp ne i64 %v4238, 0
  %cv4240 = zext i1 %cmp4239 to i32
  store i32 %cv4240, ptr %slot442, align 8
  %v4241 = load i32, ptr %slot442, align 8
  %cv4242 = zext i32 %v4241 to i64
  %cond4243 = icmp ne i64 %cv4242, 0
  br i1 %cond4243, label %bb_rcspinbacking481, label %bb_rcspincommit481
bb_rcspinbacking481:
  %v4244 = load i64, ptr %slot441, align 8
  %op4245 = sub i64 %v4244, 16
  store i64 %op4245, ptr %slot443, align 8
  %v4246 = load i64, ptr %slot441, align 8
  %p4247 = inttoptr i64 %v4246 to ptr
  %rgep4248 = getelementptr i8, ptr %p4247, i64 -16
  %ld4249 = load i64, ptr %rgep4248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4249, ptr %slot444, align 8
  %v4250 = load i64, ptr %slot444, align 8
  %op4251 = and i64 %v4250, 4611686018427387907
  store i64 %op4251, ptr %slot445, align 8
  %v4252 = load i64, ptr %slot445, align 8
  %cmp4253 = icmp eq i64 %v4252, 0
  %cv4254 = zext i1 %cmp4253 to i32
  store i32 %cv4254, ptr %slot446, align 8
  %v4255 = load i32, ptr %slot446, align 8
  %cv4256 = zext i32 %v4255 to i64
  %cond4257 = icmp ne i64 %cv4256, 0
  br i1 %cond4257, label %bb_rcs523, label %bb_rcspinslow481
bb_rcs523:
  %v4258 = load i64, ptr %slot441, align 8
  %op4259 = sub i64 %v4258, 24
  store i64 %op4259, ptr %slot447, align 8
  %v4260 = load i64, ptr %slot441, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  %rgep4262 = getelementptr i8, ptr %p4261, i64 -24
  %ld4263 = load i64, ptr %rgep4262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4263, ptr %slot448, align 8
  %v4264 = load i64, ptr %slot448, align 8
  %cmp4265 = icmp ne i64 %v4264, 18446744073709551615
  %cv4266 = zext i1 %cmp4265 to i32
  store i32 %cv4266, ptr %slot449, align 8
  %v4267 = load i32, ptr %slot449, align 8
  %cv4268 = zext i32 %v4267 to i64
  %cond4269 = icmp ne i64 %cv4268, 0
  br i1 %cond4269, label %bb_rcs527, label %bb_rcspinslow481
bb_rcs527:
  br label %bb_rcspincommit481
bb_rcspincommit481:
  %v4270 = load i64, ptr %slot426, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  %ld4272 = load i64, ptr %p4271, align 8
  store i64 %ld4272, ptr %slot450, align 8
  %v4273 = load i64, ptr %slot424, align 8
  %op4274 = add i64 %v4273, 256
  store i64 %op4274, ptr %slot451, align 8
  %v4275 = load i64, ptr %slot450, align 8
  %v4276 = load i64, ptr %slot451, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  store i64 %v4275, ptr %p4277, align 8, !alias.scope !9999998, !noalias !9999999
  %v4278 = load i64, ptr %slot424, align 8
  %op4279 = add i64 %v4278, 264
  store i64 %op4279, ptr %slot452, align 8
  %v4280 = load i64, ptr %slot452, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  %ld4282 = load i64, ptr %p4281, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4282, ptr %slot453, align 8
  %v4283 = load i64, ptr %slot453, align 8
  %op4284 = add i64 %v4283, 18446744073709551615
  store i64 %op4284, ptr %slot454, align 8
  %v4285 = load i64, ptr %slot454, align 8
  %v4286 = load i64, ptr %slot452, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i64 %v4285, ptr %p4287, align 8, !alias.scope !9999998, !noalias !9999999
  %v4288 = load i64, ptr %slot88, align 8
  %p4290 = inttoptr i64 %v4288 to ptr
  %gep4291 = getelementptr i8, ptr %p4290, i64 24
  %op4289 = ptrtoint ptr %gep4291 to i64
  store i64 %op4289, ptr %slot455, align 8
  %v4292 = load i64, ptr %slot455, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  %ld4294 = load i64, ptr %p4293, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4294, ptr %slot456, align 8
  %v4295 = load i64, ptr %slot456, align 8
  %op4296 = add i64 %v4295, 40
  store i64 %op4296, ptr %slot457, align 8
  %v4297 = load i64, ptr %slot457, align 8
  %v4298 = load i64, ptr %slot455, align 8
  %p4299 = inttoptr i64 %v4298 to ptr
  store i64 %v4297, ptr %p4299, align 8, !alias.scope !9999998, !noalias !9999999
  %v4300 = load i64, ptr %slot424, align 8
  %op4301 = add i64 %v4300, 48
  store i64 %op4301, ptr %slot458, align 8
  %v4302 = load i64, ptr %slot458, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  %ld4304 = load i64, ptr %p4303, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4304, ptr %slot459, align 8
  %v4305 = load i64, ptr %slot459, align 8
  %op4306 = add i64 %v4305, 40
  store i64 %op4306, ptr %slot460, align 8
  %v4307 = load i64, ptr %slot460, align 8
  %v4308 = load i64, ptr %slot458, align 8
  %p4309 = inttoptr i64 %v4308 to ptr
  store i64 %v4307, ptr %p4309, align 8, !alias.scope !9999998, !noalias !9999999
  %v4310 = load i64, ptr %slot368, align 8
  %op4311 = sub i64 %v4310, 24
  store i64 %op4311, ptr %slot461, align 8
  %v4312 = load i64, ptr %slot368, align 8
  %p4313 = inttoptr i64 %v4312 to ptr
  %rgep4314 = getelementptr i8, ptr %p4313, i64 -24
  %ld4315 = load i64, ptr %rgep4314, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4315, ptr %slot462, align 8
  %v4316 = load i64, ptr %slot462, align 8
  %op4317 = add i64 %v4316, 1
  store i64 %op4317, ptr %slot463, align 8
  %v4318 = load i64, ptr %slot463, align 8
  %v4319 = load i64, ptr %slot368, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  %rgep4321 = getelementptr i8, ptr %p4320, i64 -24
  store i64 %v4318, ptr %rgep4321, align 8, !alias.scope !9, !noalias !10
  %v4322 = load i64, ptr %slot441, align 8
  %cmp4323 = icmp ne i64 %v4322, 0
  %cv4324 = zext i1 %cmp4323 to i32
  store i32 %cv4324, ptr %slot464, align 8
  %v4325 = load i32, ptr %slot464, align 8
  %cv4326 = zext i32 %v4325 to i64
  %cond4327 = icmp ne i64 %cv4326, 0
  br i1 %cond4327, label %bb_rcspinhold481, label %bb_rcspinjournal481
bb_rcspinhold481:
  %v4328 = load i64, ptr %slot441, align 8
  %op4329 = sub i64 %v4328, 24
  store i64 %op4329, ptr %slot465, align 8
  %v4330 = load i64, ptr %slot441, align 8
  %p4331 = inttoptr i64 %v4330 to ptr
  %rgep4332 = getelementptr i8, ptr %p4331, i64 -24
  %ld4333 = load i64, ptr %rgep4332, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4333, ptr %slot466, align 8
  %v4334 = load i64, ptr %slot466, align 8
  %op4335 = add i64 %v4334, 1
  store i64 %op4335, ptr %slot467, align 8
  %v4336 = load i64, ptr %slot467, align 8
  %v4337 = load i64, ptr %slot441, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  %rgep4339 = getelementptr i8, ptr %p4338, i64 -24
  store i64 %v4336, ptr %rgep4339, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal481
bb_rcspinjournal481:
  %v4340 = load i64, ptr %slot414, align 8
  %op4341 = and i64 %v4340, 1152921504606846976
  store i64 %op4341, ptr %slot468, align 8
  %v4342 = load i64, ptr %slot414, align 8
  %op4343 = or i64 %v4342, 1152921504606846976
  store i64 %op4343, ptr %slot469, align 8
  %v4344 = load i64, ptr %slot368, align 8
  %op4345 = sub i64 %v4344, 16
  store i64 %op4345, ptr %slot470, align 8
  %v4346 = load i64, ptr %slot469, align 8
  %v4347 = load i64, ptr %slot368, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  %rgep4349 = getelementptr i8, ptr %p4348, i64 -16
  store i64 %v4346, ptr %rgep4349, align 8, !alias.scope !9, !noalias !10
  %v4350 = load i64, ptr %slot401, align 8
  %p4352 = inttoptr i64 %v4350 to ptr
  %gep4353 = getelementptr i8, ptr %p4352, i64 16
  %op4351 = ptrtoint ptr %gep4353 to i64
  store i64 %op4351, ptr %slot471, align 8
  %v4354 = load i64, ptr %slot471, align 8
  %p4355 = inttoptr i64 %v4354 to ptr
  %ld4356 = load i64, ptr %p4355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4356, ptr %slot472, align 8
  %v4357 = load i64, ptr %slot426, align 8
  %op4358 = add i64 %v4357, 0
  store i64 %op4358, ptr %slot473, align 8
  %v4359 = load i64, ptr %slot472, align 8
  %v4360 = load i64, ptr %slot473, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i64 %v4359, ptr %p4361, align 8, !alias.scope !9999998, !noalias !9999999
  %v4362 = load i64, ptr %slot426, align 8
  %op4363 = add i64 %v4362, 8
  store i64 %op4363, ptr %slot474, align 8
  %v4364 = load i64, ptr %slot368, align 8
  %v4365 = load i64, ptr %slot474, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i64 %v4364, ptr %p4366, align 8, !alias.scope !9999998, !noalias !9999999
  %v4367 = load i64, ptr %slot426, align 8
  %op4368 = add i64 %v4367, 16
  store i64 %op4368, ptr %slot475, align 8
  %v4369 = load i64, ptr %slot468, align 8
  %v4370 = load i64, ptr %slot475, align 8
  %p4371 = inttoptr i64 %v4370 to ptr
  store i64 %v4369, ptr %p4371, align 8, !alias.scope !9999998, !noalias !9999999
  %v4372 = load i64, ptr %slot426, align 8
  %op4373 = add i64 %v4372, 24
  store i64 %op4373, ptr %slot476, align 8
  %v4374 = load i64, ptr %slot476, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  store i32 1, ptr %p4375, align 4, !alias.scope !9999998, !noalias !9999999
  %v4376 = load i64, ptr %slot426, align 8
  %op4377 = add i64 %v4376, 32
  store i64 %op4377, ptr %slot477, align 8
  %v4378 = load i64, ptr %slot441, align 8
  %v4379 = load i64, ptr %slot477, align 8
  %p4380 = inttoptr i64 %v4379 to ptr
  store i64 %v4378, ptr %p4380, align 8, !alias.scope !9999998, !noalias !9999999
  %v4381 = load i64, ptr %slot401, align 8
  %p4383 = inttoptr i64 %v4381 to ptr
  %gep4384 = getelementptr i8, ptr %p4383, i64 16
  %op4382 = ptrtoint ptr %gep4384 to i64
  store i64 %op4382, ptr %slot478, align 8
  %v4385 = load i64, ptr %slot426, align 8
  %v4386 = load i64, ptr %slot478, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  store i64 %v4385, ptr %p4387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone481
bb_rcspinslow481:
  %v4388 = load i64, ptr %slot1, align 8
  %p4389 = inttoptr i64 %v4388 to ptr
  %v4390 = load i64, ptr %slot401, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  %v4392 = load i64, ptr %slot368, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %call4394 = call i32 @myl_qbe_rc_scope_pin(ptr %p4389, ptr %p4391, ptr %p4393) nomerge, !dbg !130
  store i32 %call4394, ptr %slot479, align 8
  %v4395 = load i32, ptr %slot479, align 8
  %cv4396 = zext i32 %v4395 to i64
  %cond4397 = icmp ne i64 %cv4396, 0
  br i1 %cond4397, label %bb_rcunique558, label %bb_failure
bb_rcunique558:
  br label %bb_rcspindone481
bb_rcspindone481:
  %v4398 = load i64, ptr %slot368, align 8
  %v4399 = load i64, ptr %slot56, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i64 %v4398, ptr %p4400, align 8, !alias.scope !3, !noalias !4
  %v4401 = load i64, ptr %slot55, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i64, ptr %p4402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4403, ptr %slot480, align 8
  %v4404 = load i64, ptr %slot480, align 8
  %v4405 = load i64, ptr %slot68, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  store i64 %v4404, ptr %p4406, align 8, !alias.scope !3, !noalias !4
  %v4407 = load i64, ptr %slot56, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  %ld4409 = load i64, ptr %p4408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4409, ptr %slot481, align 8
  %v4410 = load i64, ptr %slot68, align 8
  store i64 %v4410, ptr %slot482, align 8
  %v4411 = load i64, ptr %slot482, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  %ld4413 = load i64, ptr %p4412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4413, ptr %slot483, align 8
  %v4414 = load i64, ptr %slot481, align 8
  %op4415 = add i64 %v4414, 0
  store i64 %op4415, ptr %slot484, align 8
  %v4416 = load i64, ptr %slot484, align 8
  %p4417 = inttoptr i64 %v4416 to ptr
  %ld4418 = load i64, ptr %p4417, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4418, ptr %slot485, align 8
  %v4419 = load i64, ptr %slot481, align 8
  %op4420 = add i64 %v4419, 8
  store i64 %op4420, ptr %slot486, align 8
  %v4421 = load i64, ptr %slot486, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %ld4423 = load i64, ptr %p4422, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4423, ptr %slot487, align 8
  %v4424 = load i64, ptr %slot481, align 8
  %op4425 = add i64 %v4424, 16
  store i64 %op4425, ptr %slot488, align 8
  %v4426 = load i64, ptr %slot488, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %ld4428 = load i64, ptr %p4427, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4428, ptr %slot489, align 8
  %v4429 = load i64, ptr %slot485, align 8
  %v4430 = load i64, ptr %slot487, align 8
  %cmp4431 = icmp ult i64 %v4429, %v4430
  %cv4432 = zext i1 %cmp4431 to i32
  store i32 %cv4432, ptr %slot490, align 8
  %v4433 = load i64, ptr %slot489, align 8
  %cmp4434 = icmp ne i64 %v4433, 18446744073709551615
  %cv4435 = zext i1 %cmp4434 to i32
  store i32 %cv4435, ptr %slot491, align 8
  %v4436 = load i32, ptr %slot490, align 8
  %v4437 = load i32, ptr %slot491, align 8
  %op4438 = and i32 %v4436, %v4437
  store i32 %op4438, ptr %slot492, align 8
  %v4439 = load i32, ptr %slot492, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcappend_check564, label %bb_rcappend_slow564
bb_rcappend_check564:
  %v4442 = load i64, ptr %slot88, align 8
  %p4443 = inttoptr i64 %v4442 to ptr
  %v4444 = load i64, ptr %slot481, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %call4446 = call i32 @myl_rc_list_plain_ready(ptr %p4443, ptr %p4445) nomerge, !dbg !132
  store i32 %call4446, ptr %slot493, align 8
  %v4447 = load i32, ptr %slot493, align 8
  %cv4448 = zext i32 %v4447 to i64
  %cond4449 = icmp ne i64 %cv4448, 0
  br i1 %cond4449, label %bb_rcappend_fast564, label %bb_rcappend_slow564
bb_rcappend_slow564:
  %v4450 = load i64, ptr %slot482, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %ld4452 = load i64, ptr %p4451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4452, ptr %slot494, align 8
  %v4453 = load i64, ptr %slot494, align 8
  %v4454 = load i64, ptr %slot43, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  store i64 %v4453, ptr %p4455, align 8, !alias.scope !3, !noalias !4
  %v4456 = load i64, ptr %slot43, align 8
  store i64 %v4456, ptr %slot495, align 8
  %v4457 = load i64, ptr %slot88, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  %v4459 = load i64, ptr %slot481, align 8
  %p4460 = inttoptr i64 %v4459 to ptr
  %v4461 = load i64, ptr %slot495, align 8
  %p4462 = inttoptr i64 %v4461 to ptr
  %call4463 = call i32 @myl_rc_list_append(ptr %p4458, ptr %p4460, ptr %p4462) nomerge, !dbg !132
  store i32 %call4463, ptr %slot496, align 8
  %v4464 = load i32, ptr %slot496, align 8
  %cv4465 = zext i32 %v4464 to i64
  %cond4466 = icmp ne i64 %cv4465, 0
  br i1 %cond4466, label %bb_success577, label %bb_failed577
bb_failed577:
  %v4467 = load i64, ptr %slot1, align 8
  %p4468 = inttoptr i64 %v4467 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4468) nomerge, !dbg !132
  unreachable
bb_success577:
  br label %bb_rcappend_done564
bb_rcappend_fast564:
  %v4469 = load i64, ptr %slot481, align 8
  %op4470 = add i64 %v4469, 32
  store i64 %op4470, ptr %slot497, align 8
  %v4471 = load i64, ptr %slot497, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %ld4473 = load i64, ptr %p4472, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4473, ptr %slot498, align 8
  %v4474 = load i64, ptr %slot485, align 8
  %op4475 = mul i64 %v4474, 8
  store i64 %op4475, ptr %slot499, align 8
  %v4476 = load i64, ptr %slot498, align 8
  %v4477 = load i64, ptr %slot499, align 8
  %op4478 = add i64 %v4476, %v4477
  store i64 %op4478, ptr %slot500, align 8
  %v4479 = load i64, ptr %slot483, align 8
  %v4480 = load i64, ptr %slot498, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  %v4482 = load i64, ptr %slot499, align 8
  %egep4483 = getelementptr i8, ptr %p4481, i64 %v4482
  store i64 %v4479, ptr %egep4483, align 8, !alias.scope !12, !noalias !13
  %v4484 = load i64, ptr %slot481, align 8
  %op4485 = add i64 %v4484, 0
  store i64 %op4485, ptr %slot501, align 8
  %v4486 = load i64, ptr %slot485, align 8
  %op4487 = add i64 %v4486, 1
  store i64 %op4487, ptr %slot502, align 8
  %v4488 = load i64, ptr %slot502, align 8
  %v4489 = load i64, ptr %slot501, align 8
  %p4490 = inttoptr i64 %v4489 to ptr
  store i64 %v4488, ptr %p4490, align 8, !alias.scope !6, !noalias !7
  %v4491 = load i64, ptr %slot481, align 8
  %op4492 = add i64 %v4491, 16
  store i64 %op4492, ptr %slot503, align 8
  %v4493 = load i64, ptr %slot489, align 8
  %op4494 = add i64 %v4493, 1
  store i64 %op4494, ptr %slot504, align 8
  %v4495 = load i64, ptr %slot504, align 8
  %v4496 = load i64, ptr %slot503, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  store i64 %v4495, ptr %p4497, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done564
bb_rcappend_done564:
  %v4498 = load i64, ptr %slot68, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  store i64 0, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  %v4500 = load i64, ptr %slot44, align 8
  store i64 %v4500, ptr %slot505, align 8
  %v4501 = load i64, ptr %slot505, align 8
  %p4503 = inttoptr i64 %v4501 to ptr
  %gep4504 = getelementptr i8, ptr %p4503, i64 24
  %op4502 = ptrtoint ptr %gep4504 to i64
  store i64 %op4502, ptr %slot506, align 8
  %v4505 = load i64, ptr %slot506, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  %ld4507 = load i32, ptr %p4506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4507, ptr %slot507, align 8
  %v4508 = load i32, ptr %slot507, align 8
  %cv4509 = zext i32 %v4508 to i64
  %cond4510 = icmp ne i64 %cv4509, 0
  br i1 %cond4510, label %bb_rcsendactive587, label %bb_rcsenddone587
bb_rcsendactive587:
  %v4511 = load i64, ptr %slot88, align 8
  %p4513 = inttoptr i64 %v4511 to ptr
  %gep4514 = getelementptr i8, ptr %p4513, i64 5640
  %op4512 = ptrtoint ptr %gep4514 to i64
  store i64 %op4512, ptr %slot508, align 8
  %v4515 = load i64, ptr %slot508, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  %ld4517 = load i64, ptr %p4516, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4517, ptr %slot509, align 8
  %v4518 = load i64, ptr %slot509, align 8
  %op4519 = add i64 %v4518, 248
  store i64 %op4519, ptr %slot510, align 8
  %v4520 = load i64, ptr %slot510, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  %ld4522 = load i64, ptr %p4521, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4522, ptr %slot511, align 8
  %v4523 = load i64, ptr %slot511, align 8
  %v4524 = load i64, ptr %slot505, align 8
  %cmp4525 = icmp eq i64 %v4523, %v4524
  %cv4526 = zext i1 %cmp4525 to i32
  store i32 %cv4526, ptr %slot512, align 8
  %v4527 = load i32, ptr %slot512, align 8
  %cv4528 = zext i32 %v4527 to i64
  %cond4529 = icmp ne i64 %cv4528, 0
  br i1 %cond4529, label %bb_rcs595, label %bb_rcsendslow587
bb_rcs595:
  %v4530 = load i64, ptr %slot509, align 8
  %op4531 = add i64 %v4530, 200
  store i64 %op4531, ptr %slot513, align 8
  %v4532 = load i64, ptr %slot513, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  %ld4534 = load i64, ptr %p4533, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4534, ptr %slot514, align 8
  %v4535 = load i64, ptr %slot514, align 8
  %cmp4536 = icmp eq i64 %v4535, 0
  %cv4537 = zext i1 %cmp4536 to i32
  store i32 %cv4537, ptr %slot515, align 8
  %v4538 = load i32, ptr %slot515, align 8
  %cv4539 = zext i32 %v4538 to i64
  %cond4540 = icmp ne i64 %cv4539, 0
  br i1 %cond4540, label %bb_rcs599, label %bb_rcsendslow587
bb_rcs599:
  %v4541 = load i64, ptr %slot505, align 8
  %p4543 = inttoptr i64 %v4541 to ptr
  %gep4544 = getelementptr i8, ptr %p4543, i64 16
  %op4542 = ptrtoint ptr %gep4544 to i64
  store i64 %op4542, ptr %slot516, align 8
  %v4545 = load i64, ptr %slot516, align 8
  %p4546 = inttoptr i64 %v4545 to ptr
  %ld4547 = load i64, ptr %p4546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4547, ptr %slot517, align 8
  %v4548 = load i64, ptr %slot517, align 8
  %cmp4549 = icmp ne i64 %v4548, 0
  %cv4550 = zext i1 %cmp4549 to i32
  store i32 %cv4550, ptr %slot518, align 8
  %v4551 = load i32, ptr %slot518, align 8
  %cv4552 = zext i32 %v4551 to i64
  %cond4553 = icmp ne i64 %cv4552, 0
  br i1 %cond4553, label %bb_rcsendnode587, label %bb_rcsendunlink587
bb_rcsendnode587:
  %v4554 = load i64, ptr %slot517, align 8
  %op4555 = add i64 %v4554, 0
  store i64 %op4555, ptr %slot519, align 8
  %v4556 = load i64, ptr %slot519, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  %ld4558 = load i64, ptr %p4557, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4558, ptr %slot520, align 8
  %v4559 = load i64, ptr %slot520, align 8
  %cmp4560 = icmp eq i64 %v4559, 0
  %cv4561 = zext i1 %cmp4560 to i32
  store i32 %cv4561, ptr %slot521, align 8
  %v4562 = load i32, ptr %slot521, align 8
  %cv4563 = zext i32 %v4562 to i64
  %cond4564 = icmp ne i64 %cv4563, 0
  br i1 %cond4564, label %bb_rcs606, label %bb_rcsendslow587
bb_rcs606:
  %v4565 = load i64, ptr %slot509, align 8
  %op4566 = add i64 %v4565, 264
  store i64 %op4566, ptr %slot522, align 8
  %v4567 = load i64, ptr %slot522, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %ld4569 = load i64, ptr %p4568, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4569, ptr %slot523, align 8
  %v4570 = load i64, ptr %slot523, align 8
  %cmp4571 = icmp ult i64 %v4570, 32
  %cv4572 = zext i1 %cmp4571 to i32
  store i32 %cv4572, ptr %slot524, align 8
  %v4573 = load i32, ptr %slot524, align 8
  %cv4574 = zext i32 %v4573 to i64
  %cond4575 = icmp ne i64 %cv4574, 0
  br i1 %cond4575, label %bb_rcs610, label %bb_rcsendslow587
bb_rcs610:
  %v4576 = load i64, ptr %slot517, align 8
  %op4577 = add i64 %v4576, 8
  store i64 %op4577, ptr %slot525, align 8
  %v4578 = load i64, ptr %slot525, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  %ld4580 = load i64, ptr %p4579, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4580, ptr %slot526, align 8
  %v4581 = load i64, ptr %slot526, align 8
  %cmp4582 = icmp ne i64 %v4581, 0
  %cv4583 = zext i1 %cmp4582 to i32
  store i32 %cv4583, ptr %slot527, align 8
  %v4584 = load i32, ptr %slot527, align 8
  %cv4585 = zext i32 %v4584 to i64
  %cond4586 = icmp ne i64 %cv4585, 0
  br i1 %cond4586, label %bb_rcs614, label %bb_rcsendslow587
bb_rcs614:
  %v4587 = load i64, ptr %slot526, align 8
  %op4588 = sub i64 %v4587, 16
  store i64 %op4588, ptr %slot528, align 8
  %v4589 = load i64, ptr %slot526, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %rgep4591 = getelementptr i8, ptr %p4590, i64 -16
  %ld4592 = load i64, ptr %rgep4591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4592, ptr %slot529, align 8
  %v4593 = load i64, ptr %slot529, align 8
  %op4594 = and i64 %v4593, 4611686018427387907
  store i64 %op4594, ptr %slot530, align 8
  %v4595 = load i64, ptr %slot530, align 8
  %cmp4596 = icmp eq i64 %v4595, 0
  %cv4597 = zext i1 %cmp4596 to i32
  store i32 %cv4597, ptr %slot531, align 8
  %v4598 = load i32, ptr %slot531, align 8
  %cv4599 = zext i32 %v4598 to i64
  %cond4600 = icmp ne i64 %cv4599, 0
  br i1 %cond4600, label %bb_rcs619, label %bb_rcsendslow587
bb_rcs619:
  %v4601 = load i64, ptr %slot526, align 8
  %op4602 = sub i64 %v4601, 24
  store i64 %op4602, ptr %slot532, align 8
  %v4603 = load i64, ptr %slot526, align 8
  %p4604 = inttoptr i64 %v4603 to ptr
  %rgep4605 = getelementptr i8, ptr %p4604, i64 -24
  %ld4606 = load i64, ptr %rgep4605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4606, ptr %slot533, align 8
  %v4607 = load i64, ptr %slot533, align 8
  %cmp4608 = icmp ne i64 %v4607, 0
  %cv4609 = zext i1 %cmp4608 to i32
  store i32 %cv4609, ptr %slot534, align 8
  %v4610 = load i32, ptr %slot534, align 8
  %cv4611 = zext i32 %v4610 to i64
  %cond4612 = icmp ne i64 %cv4611, 0
  br i1 %cond4612, label %bb_rcs623, label %bb_rcsendslow587
bb_rcs623:
  %v4613 = load i64, ptr %slot526, align 8
  %op4614 = sub i64 %v4613, 32
  store i64 %op4614, ptr %slot535, align 8
  %v4615 = load i64, ptr %slot526, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  %rgep4617 = getelementptr i8, ptr %p4616, i64 -32
  %ld4618 = load i64, ptr %rgep4617, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4618, ptr %slot536, align 8
  %v4619 = load i64, ptr %slot533, align 8
  %cmp4620 = icmp ugt i64 %v4619, 1
  %cv4621 = zext i1 %cmp4620 to i32
  store i32 %cv4621, ptr %slot537, align 8
  %v4622 = load i64, ptr %slot536, align 8
  %cmp4623 = icmp ne i64 %v4622, 0
  %cv4624 = zext i1 %cmp4623 to i32
  store i32 %cv4624, ptr %slot538, align 8
  %v4625 = load i32, ptr %slot537, align 8
  %v4626 = load i32, ptr %slot538, align 8
  %op4627 = or i32 %v4625, %v4626
  store i32 %op4627, ptr %slot539, align 8
  %v4628 = load i32, ptr %slot539, align 8
  %cv4629 = zext i32 %v4628 to i64
  %cond4630 = icmp ne i64 %cv4629, 0
  br i1 %cond4630, label %bb_rcs629, label %bb_rcsendslow587
bb_rcs629:
  %v4631 = load i64, ptr %slot517, align 8
  %op4632 = add i64 %v4631, 32
  store i64 %op4632, ptr %slot540, align 8
  %v4633 = load i64, ptr %slot540, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  %ld4635 = load i64, ptr %p4634, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4635, ptr %slot541, align 8
  %v4636 = load i64, ptr %slot541, align 8
  %cmp4637 = icmp ne i64 %v4636, 0
  %cv4638 = zext i1 %cmp4637 to i32
  store i32 %cv4638, ptr %slot542, align 8
  %v4639 = load i32, ptr %slot542, align 8
  %cv4640 = zext i32 %v4639 to i64
  %cond4641 = icmp ne i64 %cv4640, 0
  br i1 %cond4641, label %bb_rcsendbacking587, label %bb_rcsendcommit587
bb_rcsendbacking587:
  %v4642 = load i64, ptr %slot541, align 8
  %op4643 = sub i64 %v4642, 16
  store i64 %op4643, ptr %slot543, align 8
  %v4644 = load i64, ptr %slot541, align 8
  %p4645 = inttoptr i64 %v4644 to ptr
  %rgep4646 = getelementptr i8, ptr %p4645, i64 -16
  %ld4647 = load i64, ptr %rgep4646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4647, ptr %slot544, align 8
  %v4648 = load i64, ptr %slot544, align 8
  %op4649 = and i64 %v4648, 4611686018427387907
  store i64 %op4649, ptr %slot545, align 8
  %v4650 = load i64, ptr %slot545, align 8
  %cmp4651 = icmp eq i64 %v4650, 0
  %cv4652 = zext i1 %cmp4651 to i32
  store i32 %cv4652, ptr %slot546, align 8
  %v4653 = load i32, ptr %slot546, align 8
  %cv4654 = zext i32 %v4653 to i64
  %cond4655 = icmp ne i64 %cv4654, 0
  br i1 %cond4655, label %bb_rcs637, label %bb_rcsendslow587
bb_rcs637:
  %v4656 = load i64, ptr %slot541, align 8
  %op4657 = sub i64 %v4656, 24
  store i64 %op4657, ptr %slot547, align 8
  %v4658 = load i64, ptr %slot541, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %rgep4660 = getelementptr i8, ptr %p4659, i64 -24
  %ld4661 = load i64, ptr %rgep4660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4661, ptr %slot548, align 8
  %v4662 = load i64, ptr %slot548, align 8
  %cmp4663 = icmp ne i64 %v4662, 0
  %cv4664 = zext i1 %cmp4663 to i32
  store i32 %cv4664, ptr %slot549, align 8
  %v4665 = load i32, ptr %slot549, align 8
  %cv4666 = zext i32 %v4665 to i64
  %cond4667 = icmp ne i64 %cv4666, 0
  br i1 %cond4667, label %bb_rcs641, label %bb_rcsendslow587
bb_rcs641:
  %v4668 = load i64, ptr %slot541, align 8
  %op4669 = sub i64 %v4668, 32
  store i64 %op4669, ptr %slot550, align 8
  %v4670 = load i64, ptr %slot541, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  %rgep4672 = getelementptr i8, ptr %p4671, i64 -32
  %ld4673 = load i64, ptr %rgep4672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4673, ptr %slot551, align 8
  %v4674 = load i64, ptr %slot548, align 8
  %cmp4675 = icmp ugt i64 %v4674, 1
  %cv4676 = zext i1 %cmp4675 to i32
  store i32 %cv4676, ptr %slot552, align 8
  %v4677 = load i64, ptr %slot551, align 8
  %cmp4678 = icmp ne i64 %v4677, 0
  %cv4679 = zext i1 %cmp4678 to i32
  store i32 %cv4679, ptr %slot553, align 8
  %v4680 = load i32, ptr %slot552, align 8
  %v4681 = load i32, ptr %slot553, align 8
  %op4682 = or i32 %v4680, %v4681
  store i32 %op4682, ptr %slot554, align 8
  %v4683 = load i32, ptr %slot554, align 8
  %cv4684 = zext i32 %v4683 to i64
  %cond4685 = icmp ne i64 %cv4684, 0
  br i1 %cond4685, label %bb_rcs647, label %bb_rcsendslow587
bb_rcs647:
  br label %bb_rcsendcommit587
bb_rcsendcommit587:
  %v4686 = load i64, ptr %slot517, align 8
  %op4687 = add i64 %v4686, 24
  store i64 %op4687, ptr %slot555, align 8
  %v4688 = load i64, ptr %slot555, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  %ld4690 = load i32, ptr %p4689, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4690, ptr %slot556, align 8
  %v4691 = load i32, ptr %slot556, align 8
  %cv4692 = zext i32 %v4691 to i64
  %cond4693 = icmp ne i64 %cv4692, 0
  br i1 %cond4693, label %bb_rcsendrestore587, label %bb_rcsendreturned587
bb_rcsendrestore587:
  %v4694 = load i64, ptr %slot517, align 8
  %op4695 = add i64 %v4694, 16
  store i64 %op4695, ptr %slot557, align 8
  %v4696 = load i64, ptr %slot557, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %ld4698 = load i64, ptr %p4697, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4698, ptr %slot558, align 8
  %v4699 = load i64, ptr %slot529, align 8
  %op4700 = and i64 %v4699, 17293822569102704639
  store i64 %op4700, ptr %slot559, align 8
  %v4701 = load i64, ptr %slot559, align 8
  %v4702 = load i64, ptr %slot558, align 8
  %op4703 = or i64 %v4701, %v4702
  store i64 %op4703, ptr %slot560, align 8
  %v4704 = load i64, ptr %slot526, align 8
  %op4705 = sub i64 %v4704, 16
  store i64 %op4705, ptr %slot561, align 8
  %v4706 = load i64, ptr %slot560, align 8
  %v4707 = load i64, ptr %slot526, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  %rgep4709 = getelementptr i8, ptr %p4708, i64 -16
  store i64 %v4706, ptr %rgep4709, align 8, !alias.scope !9, !noalias !10
  %v4710 = load i64, ptr %slot505, align 8
  %p4712 = inttoptr i64 %v4710 to ptr
  %gep4713 = getelementptr i8, ptr %p4712, i64 16
  %op4711 = ptrtoint ptr %gep4713 to i64
  store i64 %op4711, ptr %slot562, align 8
  br label %bb_rcsendreturned587
bb_rcsendreturned587:
  %v4714 = load i64, ptr %slot562, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  store i64 0, ptr %p4715, align 8, !alias.scope !3, !noalias !4
  %v4716 = load i64, ptr %slot509, align 8
  %op4717 = add i64 %v4716, 256
  store i64 %op4717, ptr %slot563, align 8
  %v4718 = load i64, ptr %slot563, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %ld4720 = load i64, ptr %p4719, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4720, ptr %slot564, align 8
  %v4721 = load i64, ptr %slot517, align 8
  %op4722 = add i64 %v4721, 0
  store i64 %op4722, ptr %slot565, align 8
  %v4723 = load i64, ptr %slot564, align 8
  %v4724 = load i64, ptr %slot565, align 8
  %p4725 = inttoptr i64 %v4724 to ptr
  store i64 %v4723, ptr %p4725, align 8, !alias.scope !9999998, !noalias !9999999
  %v4726 = load i64, ptr %slot509, align 8
  %op4727 = add i64 %v4726, 256
  store i64 %op4727, ptr %slot566, align 8
  %v4728 = load i64, ptr %slot517, align 8
  %v4729 = load i64, ptr %slot566, align 8
  %p4730 = inttoptr i64 %v4729 to ptr
  store i64 %v4728, ptr %p4730, align 8, !alias.scope !9999998, !noalias !9999999
  %v4731 = load i64, ptr %slot509, align 8
  %op4732 = add i64 %v4731, 264
  store i64 %op4732, ptr %slot567, align 8
  %v4733 = load i64, ptr %slot567, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  %ld4735 = load i64, ptr %p4734, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4735, ptr %slot568, align 8
  %v4736 = load i64, ptr %slot568, align 8
  %op4737 = add i64 %v4736, 1
  store i64 %op4737, ptr %slot569, align 8
  %v4738 = load i64, ptr %slot569, align 8
  %v4739 = load i64, ptr %slot567, align 8
  %p4740 = inttoptr i64 %v4739 to ptr
  store i64 %v4738, ptr %p4740, align 8, !alias.scope !9999998, !noalias !9999999
  %v4741 = load i64, ptr %slot88, align 8
  %p4743 = inttoptr i64 %v4741 to ptr
  %gep4744 = getelementptr i8, ptr %p4743, i64 24
  %op4742 = ptrtoint ptr %gep4744 to i64
  store i64 %op4742, ptr %slot570, align 8
  %v4745 = load i64, ptr %slot570, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  %ld4747 = load i64, ptr %p4746, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4747, ptr %slot571, align 8
  %v4748 = load i64, ptr %slot571, align 8
  %op4749 = add i64 %v4748, 18446744073709551576
  store i64 %op4749, ptr %slot572, align 8
  %v4750 = load i64, ptr %slot572, align 8
  %v4751 = load i64, ptr %slot570, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  store i64 %v4750, ptr %p4752, align 8, !alias.scope !9999998, !noalias !9999999
  %v4753 = load i64, ptr %slot509, align 8
  %op4754 = add i64 %v4753, 48
  store i64 %op4754, ptr %slot573, align 8
  %v4755 = load i64, ptr %slot573, align 8
  %p4756 = inttoptr i64 %v4755 to ptr
  %ld4757 = load i64, ptr %p4756, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4757, ptr %slot574, align 8
  %v4758 = load i64, ptr %slot574, align 8
  %op4759 = add i64 %v4758, 18446744073709551576
  store i64 %op4759, ptr %slot575, align 8
  %v4760 = load i64, ptr %slot575, align 8
  %v4761 = load i64, ptr %slot573, align 8
  %p4762 = inttoptr i64 %v4761 to ptr
  store i64 %v4760, ptr %p4762, align 8, !alias.scope !9999998, !noalias !9999999
  %v4763 = load i64, ptr %slot541, align 8
  %cmp4764 = icmp ne i64 %v4763, 0
  %cv4765 = zext i1 %cmp4764 to i32
  store i32 %cv4765, ptr %slot576, align 8
  %v4766 = load i32, ptr %slot576, align 8
  %cv4767 = zext i32 %v4766 to i64
  %cond4768 = icmp ne i64 %cv4767, 0
  br i1 %cond4768, label %bb_rcsenddropbacking587, label %bb_rcsenddroppayload587
bb_rcsenddropbacking587:
  %v4769 = load i64, ptr %slot541, align 8
  %op4770 = sub i64 %v4769, 24
  store i64 %op4770, ptr %slot577, align 8
  %v4771 = load i64, ptr %slot541, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  %rgep4773 = getelementptr i8, ptr %p4772, i64 -24
  %ld4774 = load i64, ptr %rgep4773, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4774, ptr %slot578, align 8
  %v4775 = load i64, ptr %slot578, align 8
  %op4776 = add i64 %v4775, 18446744073709551615
  store i64 %op4776, ptr %slot579, align 8
  %v4777 = load i64, ptr %slot579, align 8
  %v4778 = load i64, ptr %slot541, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %rgep4780 = getelementptr i8, ptr %p4779, i64 -24
  store i64 %v4777, ptr %rgep4780, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload587
bb_rcsenddroppayload587:
  %v4781 = load i64, ptr %slot526, align 8
  %op4782 = sub i64 %v4781, 24
  store i64 %op4782, ptr %slot580, align 8
  %v4783 = load i64, ptr %slot526, align 8
  %p4784 = inttoptr i64 %v4783 to ptr
  %rgep4785 = getelementptr i8, ptr %p4784, i64 -24
  %ld4786 = load i64, ptr %rgep4785, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4786, ptr %slot581, align 8
  %v4787 = load i64, ptr %slot581, align 8
  %op4788 = add i64 %v4787, 18446744073709551615
  store i64 %op4788, ptr %slot582, align 8
  %v4789 = load i64, ptr %slot582, align 8
  %v4790 = load i64, ptr %slot526, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  %rgep4792 = getelementptr i8, ptr %p4791, i64 -24
  store i64 %v4789, ptr %rgep4792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink587
bb_rcsendunlink587:
  %v4793 = load i64, ptr %slot505, align 8
  %p4795 = inttoptr i64 %v4793 to ptr
  %gep4796 = getelementptr i8, ptr %p4795, i64 8
  %op4794 = ptrtoint ptr %gep4796 to i64
  store i64 %op4794, ptr %slot583, align 8
  %v4797 = load i64, ptr %slot583, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %ld4799 = load i64, ptr %p4798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4799, ptr %slot584, align 8
  %v4800 = load i64, ptr %slot509, align 8
  %op4801 = add i64 %v4800, 248
  store i64 %op4801, ptr %slot585, align 8
  %v4802 = load i64, ptr %slot584, align 8
  %v4803 = load i64, ptr %slot585, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  store i64 %v4802, ptr %p4804, align 8, !alias.scope !9999998, !noalias !9999999
  %v4805 = load i64, ptr %slot505, align 8
  %p4807 = inttoptr i64 %v4805 to ptr
  %gep4808 = getelementptr i8, ptr %p4807, i64 24
  %op4806 = ptrtoint ptr %gep4808 to i64
  store i64 %op4806, ptr %slot586, align 8
  %v4809 = load i64, ptr %slot505, align 8
  %p4811 = inttoptr i64 %v4809 to ptr
  %gep4812 = getelementptr i8, ptr %p4811, i64 8
  %op4810 = ptrtoint ptr %gep4812 to i64
  store i64 %op4810, ptr %slot587, align 8
  %v4813 = load i64, ptr %slot586, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  store i32 0, ptr %p4814, align 4, !alias.scope !3, !noalias !4
  %v4815 = load i64, ptr %slot587, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  store i64 0, ptr %p4816, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone587
bb_rcsendslow587:
  %v4817 = load i64, ptr %slot1, align 8
  %p4818 = inttoptr i64 %v4817 to ptr
  %v4819 = load i64, ptr %slot505, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p4818, ptr %p4820) nomerge, !dbg !132
  br label %bb_rcsenddone587
bb_rcsenddone587:
  %v4821 = load i64, ptr %slot53, align 8
  %v4822 = load i64, ptr %slot68, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  store i64 %v4821, ptr %p4823, align 8, !alias.scope !3, !noalias !4
  %v4824 = load i64, ptr %slot68, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %ld4826 = load i64, ptr %p4825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4826, ptr %slot588, align 8
  %v4827 = load i64, ptr %slot23, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  %ld4829 = load i32, ptr %p4828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4829, ptr %slot589, align 8
  %v4830 = load i64, ptr %slot24, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  %ld4832 = load i32, ptr %p4831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4832, ptr %slot590, align 8
  %v4833 = load i32, ptr %slot590, align 8
  %op4834 = and i32 %v4833, 24
  store i32 %op4834, ptr %slot590, align 8
  %v4835 = load i32, ptr %slot590, align 8
  %cmp4836 = icmp eq i32 %v4835, 0
  %cv4837 = zext i1 %cmp4836 to i32
  store i32 %cv4837, ptr %slot591, align 8
  %v4838 = load i32, ptr %slot589, align 8
  %v4839 = load i32, ptr %slot591, align 8
  %op4840 = and i32 %v4838, %v4839
  store i32 %op4840, ptr %slot592, align 8
  %v4841 = load i64, ptr %slot89, align 8
  store i64 %v4841, ptr %slot593, align 8
  %v4842 = load i32, ptr %slot592, align 8
  %op4843 = mul i32 %v4842, 4
  store i32 %op4843, ptr %slot594, align 8
  %v4844 = load i32, ptr %slot594, align 8
  %op4845 = or i32 %v4844, 0
  store i32 %op4845, ptr %slot595, align 8
  %v4846 = load i64, ptr %slot42, align 8
  store i64 %v4846, ptr %slot596, align 8
  %v4847 = load i64, ptr %slot88, align 8
  %v4848 = load i64, ptr %slot596, align 8
  %v4849 = load i64, ptr %slot588, align 8
  %v4850 = load i64, ptr %slot593, align 8
  %cv4851 = trunc i64 %v4850 to i32
  %v4852 = load i32, ptr %slot595, align 8
  %call4853 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v4847, i64 %v4848, i64 %v4849, i32 %cv4851, i32 %v4852) nomerge, !dbg !134
  store i32 %call4853, ptr %slot597, align 8
  %v4854 = load i32, ptr %slot597, align 8
  %cv4855 = zext i32 %v4854 to i64
  %cond4856 = icmp ne i64 %cv4855, 0
  br i1 %cond4856, label %bb_rcsuccess695, label %bb_rcfailure695
bb_rcfailure695:
  %v4857 = load i64, ptr %slot88, align 8
  %p4858 = inttoptr i64 %v4857 to ptr
  %call4859 = call i32 @myl_rc_take_failure(ptr %p4858) nomerge, !dbg !134
  store i32 %call4859, ptr %slot598, align 8
  %v4860 = load i64, ptr %slot1, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %v4862 = load i32, ptr %slot598, align 8
  %call4863 = call i32 @myl_qbe_rc_status(ptr %p4861, i32 %v4862) nomerge, !dbg !134
  store i32 %call4863, ptr %slot599, align 8
  br label %bb_failure
bb_rcsuccess695:
  %v4864 = load i32, ptr %slot592, align 8
  %cv4865 = zext i32 %v4864 to i64
  %cond4866 = icmp ne i64 %cv4865, 0
  br i1 %cond4866, label %bb_rchtaken698, label %bb_rchcopied698
bb_rchcopied698:
  %v4867 = load i64, ptr %slot23, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  %ld4869 = load i32, ptr %p4868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4869, ptr %slot600, align 8
  %v4870 = load i32, ptr %slot600, align 8
  %cv4871 = zext i32 %v4870 to i64
  %cond4872 = icmp ne i64 %cv4871, 0
  br i1 %cond4872, label %bb_rcslotdrop701, label %bb_rcslotdone701
bb_rcslotdrop701:
  %v4873 = load i64, ptr %slot23, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  store i32 0, ptr %p4874, align 4, !alias.scope !3, !noalias !4
  %v4875 = load i64, ptr %slot34, align 8
  store i64 %v4875, ptr %slot601, align 8
  %v4876 = load i64, ptr %slot24, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i32, ptr %p4877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4878, ptr %slot602, align 8
  %v4879 = load i32, ptr %slot602, align 8
  %op4880 = and i32 %v4879, 28
  store i32 %op4880, ptr %slot603, align 8
  %v4881 = load i32, ptr %slot603, align 8
  %cv4882 = zext i32 %v4881 to i64
  %cond4883 = icmp ne i64 %cv4882, 0
  br i1 %cond4883, label %bb_rcslotrole701, label %bb_rcslotowner701
bb_rcslotrole701:
  %v4884 = load i64, ptr %slot88, align 8
  store i64 %v4884, ptr %slot604, align 8
  %v4885 = load i64, ptr %slot604, align 8
  %v4886 = load i64, ptr %slot601, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4885, i64 %v4886) nomerge, !dbg !134
  br label %bb_rcslotdone701
bb_rcslotowner701:
  %v4887 = load i64, ptr %slot88, align 8
  store i64 %v4887, ptr %slot605, align 8
  %v4888 = load i64, ptr %slot605, align 8
  %v4889 = load i64, ptr %slot601, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4888, i64 %v4889) nomerge, !dbg !134
  br label %bb_rcslotdone701
bb_rcslotdone701:
  br label %bb_rchprepared698
bb_rchtaken698:
  %v4890 = load i64, ptr %slot23, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  store i32 0, ptr %p4891, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared698
bb_rchprepared698:
  %v4892 = load i64, ptr %slot32, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  store i32 2, ptr %p4893, align 4, !alias.scope !3, !noalias !4
  %v4894 = load i64, ptr %slot31, align 8
  %p4895 = inttoptr i64 %v4894 to ptr
  store i32 1, ptr %p4895, align 4, !alias.scope !3, !noalias !4
  %v4896 = load i64, ptr %slot34, align 8
  store i64 %v4896, ptr %slot606, align 8
  %v4897 = load i64, ptr %slot42, align 8
  store i64 %v4897, ptr %slot607, align 8
  %v4898 = load i64, ptr %slot607, align 8
  %v4899 = load i64, ptr %slot606, align 8
  %p4900 = inttoptr i64 %v4898 to ptr
  %p4901 = inttoptr i64 %v4899 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4901, ptr %p4900, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4902 = load i64, ptr %slot24, align 8
  %p4903 = inttoptr i64 %v4902 to ptr
  store i32 2, ptr %p4903, align 4, !alias.scope !3, !noalias !4
  %v4904 = load i64, ptr %slot32, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  %ld4906 = load i32, ptr %p4905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4906, ptr %slot608, align 8
  %v4907 = load i32, ptr %slot608, align 8
  %v4908 = load i64, ptr %slot24, align 8
  %p4909 = inttoptr i64 %v4908 to ptr
  store i32 %v4907, ptr %p4909, align 4, !alias.scope !3, !noalias !4
  %v4910 = load i64, ptr %slot31, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  store i32 0, ptr %p4911, align 4, !alias.scope !3, !noalias !4
  %v4912 = load i64, ptr %slot23, align 8
  %p4913 = inttoptr i64 %v4912 to ptr
  store i32 1, ptr %p4913, align 4, !alias.scope !3, !noalias !4
  %v4914 = load i64, ptr %slot606, align 8
  %v4915 = load i64, ptr %slot68, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  store i64 %v4914, ptr %p4916, align 8, !alias.scope !3, !noalias !4
  %v4917 = load i64, ptr %slot55, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %ld4919 = load i64, ptr %p4918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4919, ptr %slot609, align 8
  %v4920 = load i64, ptr %slot609, align 8
  %v4921 = load i64, ptr %slot69, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  store i64 %v4920, ptr %p4922, align 8, !alias.scope !3, !noalias !4
  %v4923 = load i64, ptr %slot52, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  %ld4925 = load i64, ptr %p4924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4925, ptr %slot610, align 8
  %v4926 = load i64, ptr %slot610, align 8
  %v4927 = load i64, ptr %slot70, align 8
  %p4928 = inttoptr i64 %v4927 to ptr
  store i64 %v4926, ptr %p4928, align 8, !alias.scope !3, !noalias !4
  %v4929 = load i64, ptr %slot71, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  store i64 0, ptr %p4930, align 8, !alias.scope !3, !noalias !4
  %v4931 = load i64, ptr %slot71, align 8
  %p4932 = inttoptr i64 %v4931 to ptr
  %ld4933 = load i64, ptr %p4932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4933, ptr %slot611, align 8
  %v4934 = load i64, ptr %slot611, align 8
  %cmp4935 = icmp sge i64 %v4934, 0
  %cv4936 = zext i1 %cmp4935 to i64
  store i64 %cv4936, ptr %slot612, align 8
  %v4937 = load i64, ptr %slot612, align 8
  %cond4938 = icmp ne i64 %v4937, 0
  br i1 %cond4938, label %bb_success723, label %bb_failed723
bb_failed723:
  %v4939 = load i64, ptr %slot1, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p4940) nomerge, !dbg !136
  unreachable
bb_success723:
  %v4941 = load i64, ptr %slot88, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  %p4943 = inttoptr i64 ptrtoint (ptr @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88 to i64) to ptr
  %v4944 = load i64, ptr %slot611, align 8
  %call4945 = call ptr @myl_native_list_new(ptr %p4942, ptr %p4943, i64 %v4944) nomerge, !dbg !136
  %calladdr4946 = ptrtoint ptr %call4945 to i64
  store i64 %calladdr4946, ptr %slot613, align 8
  %v4947 = load i64, ptr %slot613, align 8
  %cond4948 = icmp ne i64 %v4947, 0
  br i1 %cond4948, label %bb_success725, label %bb_failed725
bb_failed725:
  %v4949 = load i64, ptr %slot1, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4950) nomerge, !dbg !136
  unreachable
bb_success725:
  %v4951 = load i64, ptr %slot613, align 8
  %v4952 = load i64, ptr %slot71, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  store i64 %v4951, ptr %p4953, align 8, !alias.scope !3, !noalias !4
  %v4954 = load i64, ptr %slot71, align 8
  %p4955 = inttoptr i64 %v4954 to ptr
  %ld4956 = load i64, ptr %p4955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4956, ptr %slot614, align 8
  %v4957 = load i64, ptr %slot614, align 8
  %v4958 = load i64, ptr %slot40, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  store i64 %v4957, ptr %p4959, align 8, !alias.scope !3, !noalias !4
  %v4960 = load i64, ptr %slot40, align 8
  store i64 %v4960, ptr %slot615, align 8
  %v4961 = load i64, ptr %slot42, align 8
  store i64 %v4961, ptr %slot616, align 8
  %v4962 = load i64, ptr %slot615, align 8
  %v4963 = load i64, ptr %slot616, align 8
  %p4964 = inttoptr i64 %v4962 to ptr
  %p4965 = inttoptr i64 %v4963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4965, ptr %p4964, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4966 = load i64, ptr %slot32, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  store i32 2, ptr %p4967, align 4, !alias.scope !3, !noalias !4
  %v4968 = load i64, ptr %slot31, align 8
  %p4969 = inttoptr i64 %v4968 to ptr
  store i32 1, ptr %p4969, align 4, !alias.scope !3, !noalias !4
  %v4970 = load i64, ptr %slot36, align 8
  store i64 %v4970, ptr %slot617, align 8
  %v4971 = load i64, ptr %slot42, align 8
  store i64 %v4971, ptr %slot618, align 8
  %v4972 = load i64, ptr %slot618, align 8
  %v4973 = load i64, ptr %slot617, align 8
  %p4974 = inttoptr i64 %v4972 to ptr
  %p4975 = inttoptr i64 %v4973 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4975, ptr %p4974, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4976 = load i64, ptr %slot28, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  store i32 2, ptr %p4977, align 4, !alias.scope !3, !noalias !4
  %v4978 = load i64, ptr %slot32, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %ld4980 = load i32, ptr %p4979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4980, ptr %slot619, align 8
  %v4981 = load i32, ptr %slot619, align 8
  %v4982 = load i64, ptr %slot28, align 8
  %p4983 = inttoptr i64 %v4982 to ptr
  store i32 %v4981, ptr %p4983, align 4, !alias.scope !3, !noalias !4
  %v4984 = load i64, ptr %slot31, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  store i32 0, ptr %p4985, align 4, !alias.scope !3, !noalias !4
  %v4986 = load i64, ptr %slot27, align 8
  %p4987 = inttoptr i64 %v4986 to ptr
  store i32 1, ptr %p4987, align 4, !alias.scope !3, !noalias !4
  %v4988 = load i64, ptr %slot617, align 8
  %p4989 = inttoptr i64 %v4988 to ptr
  %ld4990 = load i64, ptr %p4989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4990, ptr %slot620, align 8
  %v4991 = load i64, ptr %slot620, align 8
  %v4992 = load i64, ptr %slot71, align 8
  %p4993 = inttoptr i64 %v4992 to ptr
  store i64 %v4991, ptr %p4993, align 8, !alias.scope !3, !noalias !4
  %v4994 = load i64, ptr %slot71, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %ld4996 = load i64, ptr %p4995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4996, ptr %slot621, align 8
  %v4997 = load i64, ptr %slot621, align 8
  %v4998 = load i64, ptr %slot40, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  store i64 %v4997, ptr %p4999, align 8, !alias.scope !3, !noalias !4
  %v5000 = load i64, ptr %slot40, align 8
  store i64 %v5000, ptr %slot622, align 8
  %v5001 = load i64, ptr %slot27, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  %ld5003 = load i32, ptr %p5002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5003, ptr %slot623, align 8
  %v5004 = load i64, ptr %slot28, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  %ld5006 = load i32, ptr %p5005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5006, ptr %slot624, align 8
  %v5007 = load i32, ptr %slot624, align 8
  %op5008 = and i32 %v5007, 24
  store i32 %op5008, ptr %slot624, align 8
  %v5009 = load i32, ptr %slot624, align 8
  %cmp5010 = icmp eq i32 %v5009, 0
  %cv5011 = zext i1 %cmp5010 to i32
  store i32 %cv5011, ptr %slot625, align 8
  %v5012 = load i32, ptr %slot623, align 8
  %v5013 = load i32, ptr %slot625, align 8
  %op5014 = and i32 %v5012, %v5013
  store i32 %op5014, ptr %slot626, align 8
  %v5015 = load i32, ptr %slot626, align 8
  %cv5016 = zext i32 %v5015 to i64
  %cond5017 = icmp ne i64 %cv5016, 0
  br i1 %cond5017, label %bb_rcprivateown748, label %bb_rcprivateloan748
bb_rcprivateown748:
  %v5018 = load i64, ptr %slot42, align 8
  store i64 %v5018, ptr %slot627, align 8
  %v5019 = load i64, ptr %slot89, align 8
  store i64 %v5019, ptr %slot628, align 8
  %v5020 = load i64, ptr %slot622, align 8
  %v5021 = load i64, ptr %slot627, align 8
  %op5022 = sub i64 %v5020, %v5021
  store i64 %op5022, ptr %slot629, align 8
  %v5023 = load i64, ptr %slot627, align 8
  %v5024 = load i64, ptr %slot622, align 8
  %op5025 = sub i64 %v5023, %v5024
  store i64 %op5025, ptr %slot630, align 8
  %v5026 = load i64, ptr %slot629, align 8
  %cmp5027 = icmp ult i64 %v5026, 8
  %cv5028 = zext i1 %cmp5027 to i32
  store i32 %cv5028, ptr %slot631, align 8
  %v5029 = load i64, ptr %slot630, align 8
  %cmp5030 = icmp ult i64 %v5029, 8
  %cv5031 = zext i1 %cmp5030 to i32
  store i32 %cv5031, ptr %slot632, align 8
  %v5032 = load i32, ptr %slot631, align 8
  %v5033 = load i32, ptr %slot632, align 8
  %op5034 = or i32 %v5032, %v5033
  store i32 %op5034, ptr %slot633, align 8
  %v5035 = load i32, ptr %slot633, align 8
  %cv5036 = zext i32 %v5035 to i64
  %cond5037 = icmp ne i64 %cv5036, 0
  br i1 %cond5037, label %bb_rcmoveslow751, label %bb_rcmovecheck751
bb_rcmovecheck751:
  %v5038 = load i64, ptr %slot622, align 8
  %p5040 = inttoptr i64 %v5038 to ptr
  %gep5041 = getelementptr i8, ptr %p5040, i64 0
  %op5039 = ptrtoint ptr %gep5041 to i64
  store i64 %op5039, ptr %slot634, align 8
  %v5042 = load i64, ptr %slot634, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %ld5044 = load i64, ptr %p5043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5044, ptr %slot635, align 8
  %v5045 = load i64, ptr %slot635, align 8
  %cmp5046 = icmp ne i64 %v5045, 0
  %cv5047 = zext i1 %cmp5046 to i32
  store i32 %cv5047, ptr %slot636, align 8
  %v5048 = load i32, ptr %slot636, align 8
  %cv5049 = zext i32 %v5048 to i64
  %cond5050 = icmp ne i64 %cv5049, 0
  br i1 %cond5050, label %bb_rcmoveheader759, label %bb_rcmovenext759
bb_rcmoveheader759:
  %v5051 = load i64, ptr %slot635, align 8
  %op5052 = sub i64 %v5051, 16
  store i64 %op5052, ptr %slot637, align 8
  %v5053 = load i64, ptr %slot635, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %rgep5055 = getelementptr i8, ptr %p5054, i64 -16
  %ld5056 = load i64, ptr %rgep5055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5056, ptr %slot638, align 8
  %v5057 = load i64, ptr %slot638, align 8
  %op5058 = and i64 %v5057, 5764607523034234881
  store i64 %op5058, ptr %slot639, align 8
  %v5059 = load i64, ptr %slot639, align 8
  %cmp5060 = icmp ne i64 %v5059, 0
  %cv5061 = zext i1 %cmp5060 to i32
  store i32 %cv5061, ptr %slot640, align 8
  %v5062 = load i32, ptr %slot640, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcmoveslow751, label %bb_rcmovenext759
bb_rcmovenext759:
  %v5065 = load i64, ptr %slot622, align 8
  %v5066 = load i64, ptr %slot627, align 8
  %p5067 = inttoptr i64 %v5065 to ptr
  %p5068 = inttoptr i64 %v5066 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5068, ptr %p5067, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5069 = load i64, ptr %slot622, align 8
  %p5070 = inttoptr i64 %v5069 to ptr
  store i64 0, ptr %p5070, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved751
bb_rcmoveslow751:
  %v5071 = load i64, ptr %slot88, align 8
  %v5072 = load i64, ptr %slot627, align 8
  %v5073 = load i64, ptr %slot622, align 8
  %v5074 = load i64, ptr %slot628, align 8
  %cv5075 = trunc i64 %v5074 to i32
  %call5076 = call i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64 %v5071, i64 %v5072, i64 %v5073, i32 %cv5075) nomerge, !dbg !138
  store i32 %call5076, ptr %slot641, align 8
  %v5077 = load i32, ptr %slot641, align 8
  %cv5078 = zext i32 %v5077 to i64
  %cond5079 = icmp ne i64 %cv5078, 0
  br i1 %cond5079, label %bb_rcsuccess766, label %bb_rcfailure766
bb_rcfailure766:
  %v5080 = load i64, ptr %slot88, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  %call5082 = call i32 @myl_rc_take_failure(ptr %p5081) nomerge, !dbg !138
  store i32 %call5082, ptr %slot642, align 8
  %v5083 = load i64, ptr %slot1, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  %v5085 = load i32, ptr %slot642, align 8
  %call5086 = call i32 @myl_qbe_rc_status(ptr %p5084, i32 %v5085) nomerge, !dbg !138
  store i32 %call5086, ptr %slot643, align 8
  br label %bb_failure
bb_rcsuccess766:
  br label %bb_rcmoved751
bb_rcmoved751:
  %v5087 = load i64, ptr %slot27, align 8
  %p5088 = inttoptr i64 %v5087 to ptr
  store i32 0, ptr %p5088, align 4, !alias.scope !3, !noalias !4
  %v5089 = load i64, ptr %slot32, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  store i32 2, ptr %p5090, align 4, !alias.scope !3, !noalias !4
  %v5091 = load i64, ptr %slot31, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i32 1, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared748
bb_rcprivateloan748:
  %v5093 = load i64, ptr %slot27, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  %ld5095 = load i32, ptr %p5094, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5095, ptr %slot644, align 8
  %v5096 = load i64, ptr %slot28, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %ld5098 = load i32, ptr %p5097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5098, ptr %slot645, align 8
  %v5099 = load i32, ptr %slot645, align 8
  %cmp5100 = icmp eq i32 %v5099, 16
  %cv5101 = zext i1 %cmp5100 to i32
  store i32 %cv5101, ptr %slot646, align 8
  %v5102 = load i32, ptr %slot646, align 8
  %v5103 = load i32, ptr %slot644, align 8
  %op5104 = and i32 %v5102, %v5103
  store i32 %op5104, ptr %slot646, align 8
  %v5105 = load i32, ptr %slot646, align 8
  %cv5106 = zext i32 %v5105 to i64
  %cond5107 = icmp ne i64 %cv5106, 0
  br i1 %cond5107, label %bb_rcprivatemove748, label %bb_rcprivatenew748
bb_rcprivatemove748:
  %v5108 = load i64, ptr %slot42, align 8
  store i64 %v5108, ptr %slot647, align 8
  %v5109 = load i64, ptr %slot622, align 8
  %v5110 = load i64, ptr %slot647, align 8
  %p5111 = inttoptr i64 %v5109 to ptr
  %p5112 = inttoptr i64 %v5110 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5112, ptr %p5111, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5113 = load i64, ptr %slot622, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  store i64 0, ptr %p5114, align 8, !alias.scope !3, !noalias !4
  %v5115 = load i64, ptr %slot32, align 8
  %p5116 = inttoptr i64 %v5115 to ptr
  store i32 2, ptr %p5116, align 4, !alias.scope !3, !noalias !4
  %v5117 = load i64, ptr %slot32, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  store i32 16, ptr %p5118, align 4, !alias.scope !3, !noalias !4
  %v5119 = load i64, ptr %slot31, align 8
  %p5120 = inttoptr i64 %v5119 to ptr
  store i32 1, ptr %p5120, align 4, !alias.scope !3, !noalias !4
  %v5121 = load i64, ptr %slot27, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  store i32 0, ptr %p5122, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared748
bb_rcprivatenew748:
  %v5123 = load i64, ptr %slot42, align 8
  store i64 %v5123, ptr %slot648, align 8
  %v5124 = load i64, ptr %slot622, align 8
  %p5125 = inttoptr i64 %v5124 to ptr
  %ld5126 = load i64, ptr %p5125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5126, ptr %slot649, align 8
  %v5127 = load i64, ptr %slot649, align 8
  %cmp5128 = icmp ne i64 %v5127, 0
  %cv5129 = zext i1 %cmp5128 to i32
  store i32 %cv5129, ptr %slot650, align 8
  %v5130 = load i32, ptr %slot650, align 8
  %cv5131 = zext i32 %v5130 to i64
  %cond5132 = icmp ne i64 %cv5131, 0
  br i1 %cond5132, label %bb_rcgnn784, label %bb_rcgstore784
bb_rcgnn784:
  %v5133 = load i64, ptr %slot649, align 8
  %op5134 = sub i64 %v5133, 16
  store i64 %op5134, ptr %slot651, align 8
  %v5135 = load i64, ptr %slot649, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  %rgep5137 = getelementptr i8, ptr %p5136, i64 -16
  %ld5138 = load i64, ptr %rgep5137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5138, ptr %slot652, align 8
  %v5139 = load i64, ptr %slot652, align 8
  %op5140 = and i64 %v5139, 4611686018427387906
  store i64 %op5140, ptr %slot653, align 8
  %v5141 = load i64, ptr %slot653, align 8
  %cmp5142 = icmp ne i64 %v5141, 0
  %cv5143 = zext i1 %cmp5142 to i32
  store i32 %cv5143, ptr %slot654, align 8
  %v5144 = load i32, ptr %slot654, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcgstore784, label %bb_rcginc784
bb_rcginc784:
  %v5147 = load i64, ptr %slot649, align 8
  %op5148 = sub i64 %v5147, 24
  store i64 %op5148, ptr %slot655, align 8
  %v5149 = load i64, ptr %slot649, align 8
  %p5150 = inttoptr i64 %v5149 to ptr
  %rgep5151 = getelementptr i8, ptr %p5150, i64 -24
  %ld5152 = load i64, ptr %rgep5151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5152, ptr %slot656, align 8
  %v5153 = load i64, ptr %slot656, align 8
  %op5154 = add i64 %v5153, 1
  store i64 %op5154, ptr %slot657, align 8
  %v5155 = load i64, ptr %slot657, align 8
  %cmp5156 = icmp eq i64 %v5155, 0
  %cv5157 = zext i1 %cmp5156 to i32
  store i32 %cv5157, ptr %slot658, align 8
  %v5158 = load i32, ptr %slot658, align 8
  %cv5159 = zext i32 %v5158 to i64
  %cond5160 = icmp ne i64 %cv5159, 0
  br i1 %cond5160, label %bb_rcglimit784, label %bb_rcgcapacity784
bb_rcglimit784:
  %v5161 = load i64, ptr %slot1, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  %call5163 = call i32 @myl_qbe_rc_status(ptr %p5162, i32 2) nomerge, !dbg !138
  store i32 %call5163, ptr %slot659, align 8
  br label %bb_failure
bb_rcgcapacity784:
  %v5164 = load i64, ptr %slot657, align 8
  %v5165 = load i64, ptr %slot649, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  %rgep5167 = getelementptr i8, ptr %p5166, i64 -24
  store i64 %v5164, ptr %rgep5167, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore784
bb_rcgstore784:
  %v5168 = load i64, ptr %slot649, align 8
  %v5169 = load i64, ptr %slot648, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  store i64 %v5168, ptr %p5170, align 8, !alias.scope !3, !noalias !4
  %v5171 = load i64, ptr %slot32, align 8
  %p5172 = inttoptr i64 %v5171 to ptr
  store i32 2, ptr %p5172, align 4, !alias.scope !3, !noalias !4
  %v5173 = load i64, ptr %slot32, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  store i32 16, ptr %p5174, align 4, !alias.scope !3, !noalias !4
  %v5175 = load i64, ptr %slot31, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  store i32 1, ptr %p5176, align 4, !alias.scope !3, !noalias !4
  %v5177 = load i64, ptr %slot27, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  %ld5179 = load i32, ptr %p5178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5179, ptr %slot660, align 8
  %v5180 = load i32, ptr %slot660, align 8
  %cv5181 = zext i32 %v5180 to i64
  %cond5182 = icmp ne i64 %cv5181, 0
  br i1 %cond5182, label %bb_rcslotdrop800, label %bb_rcslotdone800
bb_rcslotdrop800:
  %v5183 = load i64, ptr %slot27, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  store i32 0, ptr %p5184, align 4, !alias.scope !3, !noalias !4
  %v5185 = load i64, ptr %slot36, align 8
  store i64 %v5185, ptr %slot661, align 8
  %v5186 = load i64, ptr %slot28, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i32, ptr %p5187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5188, ptr %slot662, align 8
  %v5189 = load i32, ptr %slot662, align 8
  %op5190 = and i32 %v5189, 28
  store i32 %op5190, ptr %slot663, align 8
  %v5191 = load i32, ptr %slot663, align 8
  %cv5192 = zext i32 %v5191 to i64
  %cond5193 = icmp ne i64 %cv5192, 0
  br i1 %cond5193, label %bb_rcslotrole800, label %bb_rcslotowner800
bb_rcslotrole800:
  %v5194 = load i64, ptr %slot88, align 8
  store i64 %v5194, ptr %slot664, align 8
  %v5195 = load i64, ptr %slot661, align 8
  %p5196 = inttoptr i64 %v5195 to ptr
  %ld5197 = load i64, ptr %p5196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5197, ptr %slot665, align 8
  %v5198 = load i64, ptr %slot665, align 8
  %cmp5199 = icmp ne i64 %v5198, 0
  %cv5200 = zext i1 %cmp5199 to i32
  store i32 %cv5200, ptr %slot666, align 8
  %v5201 = load i32, ptr %slot666, align 8
  %cv5202 = zext i32 %v5201 to i64
  %cond5203 = icmp ne i64 %cv5202, 0
  br i1 %cond5203, label %bb_rcgnn816, label %bb_rcgdone816
bb_rcgnn816:
  %v5204 = load i64, ptr %slot665, align 8
  %op5205 = sub i64 %v5204, 16
  store i64 %op5205, ptr %slot667, align 8
  %v5206 = load i64, ptr %slot665, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  %rgep5208 = getelementptr i8, ptr %p5207, i64 -16
  %ld5209 = load i64, ptr %rgep5208, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5209, ptr %slot668, align 8
  %v5210 = load i64, ptr %slot668, align 8
  %op5211 = and i64 %v5210, 4611686018427387906
  store i64 %op5211, ptr %slot669, align 8
  %v5212 = load i64, ptr %slot669, align 8
  %cmp5213 = icmp ne i64 %v5212, 0
  %cv5214 = zext i1 %cmp5213 to i32
  store i32 %cv5214, ptr %slot670, align 8
  %v5215 = load i32, ptr %slot670, align 8
  %cv5216 = zext i32 %v5215 to i64
  %cond5217 = icmp ne i64 %cv5216, 0
  br i1 %cond5217, label %bb_rcgclear816, label %bb_rcgcounted816
bb_rcgcounted816:
  %v5218 = load i64, ptr %slot665, align 8
  %op5219 = sub i64 %v5218, 24
  store i64 %op5219, ptr %slot671, align 8
  %v5220 = load i64, ptr %slot665, align 8
  %p5221 = inttoptr i64 %v5220 to ptr
  %rgep5222 = getelementptr i8, ptr %p5221, i64 -24
  %ld5223 = load i64, ptr %rgep5222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5223, ptr %slot672, align 8
  %v5224 = load i64, ptr %slot672, align 8
  %op5225 = sub i64 %v5224, 1
  store i64 %op5225, ptr %slot673, align 8
  %v5226 = load i64, ptr %slot673, align 8
  %cmp5227 = icmp eq i64 %v5226, 0
  %cv5228 = zext i1 %cmp5227 to i32
  store i32 %cv5228, ptr %slot674, align 8
  %v5229 = load i32, ptr %slot674, align 8
  %cv5230 = zext i32 %v5229 to i64
  %cond5231 = icmp ne i64 %cv5230, 0
  br i1 %cond5231, label %bb_rcglast816, label %bb_rcgdec816
bb_rcglast816:
  %v5232 = load i64, ptr %slot665, align 8
  %op5233 = sub i64 %v5232, 32
  store i64 %op5233, ptr %slot675, align 8
  %v5234 = load i64, ptr %slot665, align 8
  %p5235 = inttoptr i64 %v5234 to ptr
  %rgep5236 = getelementptr i8, ptr %p5235, i64 -32
  %ld5237 = load i64, ptr %rgep5236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5237, ptr %slot676, align 8
  %v5238 = load i64, ptr %slot676, align 8
  %cmp5239 = icmp ne i64 %v5238, 0
  %cv5240 = zext i1 %cmp5239 to i32
  store i32 %cv5240, ptr %slot677, align 8
  %v5241 = load i32, ptr %slot677, align 8
  %cv5242 = zext i32 %v5241 to i64
  %cond5243 = icmp ne i64 %cv5242, 0
  br i1 %cond5243, label %bb_rcgdec816, label %bb_rcgslow816
bb_rcgslow816:
  %v5244 = load i64, ptr %slot664, align 8
  %v5245 = load i64, ptr %slot661, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v5244, i64 %v5245) nomerge, !dbg !138
  br label %bb_rcgdone816
bb_rcgdec816:
  %v5246 = load i64, ptr %slot673, align 8
  %v5247 = load i64, ptr %slot665, align 8
  %p5248 = inttoptr i64 %v5247 to ptr
  %rgep5249 = getelementptr i8, ptr %p5248, i64 -24
  store i64 %v5246, ptr %rgep5249, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear816
bb_rcgclear816:
  %v5250 = load i64, ptr %slot661, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  store i64 0, ptr %p5251, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone816
bb_rcgdone816:
  br label %bb_rcslotdone800
bb_rcslotowner800:
  %v5252 = load i64, ptr %slot88, align 8
  store i64 %v5252, ptr %slot678, align 8
  %v5253 = load i64, ptr %slot661, align 8
  %p5254 = inttoptr i64 %v5253 to ptr
  %ld5255 = load i64, ptr %p5254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5255, ptr %slot679, align 8
  %v5256 = load i64, ptr %slot679, align 8
  %cmp5257 = icmp ne i64 %v5256, 0
  %cv5258 = zext i1 %cmp5257 to i32
  store i32 %cv5258, ptr %slot680, align 8
  %v5259 = load i32, ptr %slot680, align 8
  %cv5260 = zext i32 %v5259 to i64
  %cond5261 = icmp ne i64 %cv5260, 0
  br i1 %cond5261, label %bb_rcgnn831, label %bb_rcgdone831
bb_rcgnn831:
  %v5262 = load i64, ptr %slot679, align 8
  %op5263 = sub i64 %v5262, 16
  store i64 %op5263, ptr %slot681, align 8
  %v5264 = load i64, ptr %slot679, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  %rgep5266 = getelementptr i8, ptr %p5265, i64 -16
  %ld5267 = load i64, ptr %rgep5266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5267, ptr %slot682, align 8
  %v5268 = load i64, ptr %slot682, align 8
  %op5269 = and i64 %v5268, 4611686018427387906
  store i64 %op5269, ptr %slot683, align 8
  %v5270 = load i64, ptr %slot683, align 8
  %cmp5271 = icmp ne i64 %v5270, 0
  %cv5272 = zext i1 %cmp5271 to i32
  store i32 %cv5272, ptr %slot684, align 8
  %v5273 = load i32, ptr %slot684, align 8
  %cv5274 = zext i32 %v5273 to i64
  %cond5275 = icmp ne i64 %cv5274, 0
  br i1 %cond5275, label %bb_rcgclear831, label %bb_rcgcounted831
bb_rcgcounted831:
  %v5276 = load i64, ptr %slot679, align 8
  %op5277 = sub i64 %v5276, 32
  store i64 %op5277, ptr %slot685, align 8
  %v5278 = load i64, ptr %slot679, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %rgep5280 = getelementptr i8, ptr %p5279, i64 -32
  %ld5281 = load i64, ptr %rgep5280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5281, ptr %slot686, align 8
  %v5282 = load i64, ptr %slot686, align 8
  %op5283 = sub i64 %v5282, 1
  store i64 %op5283, ptr %slot687, align 8
  %v5284 = load i64, ptr %slot687, align 8
  %cmp5285 = icmp eq i64 %v5284, 0
  %cv5286 = zext i1 %cmp5285 to i32
  store i32 %cv5286, ptr %slot688, align 8
  %v5287 = load i32, ptr %slot688, align 8
  %cv5288 = zext i32 %v5287 to i64
  %cond5289 = icmp ne i64 %cv5288, 0
  br i1 %cond5289, label %bb_rcglast831, label %bb_rcgdec831
bb_rcglast831:
  %v5290 = load i64, ptr %slot679, align 8
  %op5291 = sub i64 %v5290, 24
  store i64 %op5291, ptr %slot689, align 8
  %v5292 = load i64, ptr %slot679, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %rgep5294 = getelementptr i8, ptr %p5293, i64 -24
  %ld5295 = load i64, ptr %rgep5294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5295, ptr %slot690, align 8
  %v5296 = load i64, ptr %slot690, align 8
  %cmp5297 = icmp ne i64 %v5296, 0
  %cv5298 = zext i1 %cmp5297 to i32
  store i32 %cv5298, ptr %slot691, align 8
  %v5299 = load i32, ptr %slot691, align 8
  %cv5300 = zext i32 %v5299 to i64
  %cond5301 = icmp ne i64 %cv5300, 0
  br i1 %cond5301, label %bb_rcgdec831, label %bb_rcgslow831
bb_rcgslow831:
  %v5302 = load i64, ptr %slot678, align 8
  %v5303 = load i64, ptr %slot661, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v5302, i64 %v5303) nomerge, !dbg !138
  br label %bb_rcgdone831
bb_rcgdec831:
  %v5304 = load i64, ptr %slot687, align 8
  %v5305 = load i64, ptr %slot679, align 8
  %p5306 = inttoptr i64 %v5305 to ptr
  %rgep5307 = getelementptr i8, ptr %p5306, i64 -32
  store i64 %v5304, ptr %rgep5307, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear831
bb_rcgclear831:
  %v5308 = load i64, ptr %slot661, align 8
  %p5309 = inttoptr i64 %v5308 to ptr
  store i64 0, ptr %p5309, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone831
bb_rcgdone831:
  br label %bb_rcslotdone800
bb_rcslotdone800:
  br label %bb_rcprivateprepared748
bb_rcprivateprepared748:
  %v5310 = load i64, ptr %slot9, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %ld5312 = load i32, ptr %p5311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5312, ptr %slot692, align 8
  %v5313 = load i32, ptr %slot692, align 8
  %cv5314 = zext i32 %v5313 to i64
  %cond5315 = icmp ne i64 %cv5314, 0
  br i1 %cond5315, label %bb_rcslotdrop838, label %bb_rcslotdone838
bb_rcslotdrop838:
  %v5316 = load i64, ptr %slot9, align 8
  %p5317 = inttoptr i64 %v5316 to ptr
  store i32 0, ptr %p5317, align 4, !alias.scope !3, !noalias !4
  %v5318 = load i64, ptr %slot57, align 8
  store i64 %v5318, ptr %slot693, align 8
  %v5319 = load i64, ptr %slot10, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %ld5321 = load i32, ptr %p5320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5321, ptr %slot694, align 8
  %v5322 = load i32, ptr %slot694, align 8
  %op5323 = and i32 %v5322, 28
  store i32 %op5323, ptr %slot695, align 8
  %v5324 = load i32, ptr %slot695, align 8
  %cv5325 = zext i32 %v5324 to i64
  %cond5326 = icmp ne i64 %cv5325, 0
  br i1 %cond5326, label %bb_rcslotrole838, label %bb_rcslotowner838
bb_rcslotrole838:
  %v5327 = load i64, ptr %slot88, align 8
  store i64 %v5327, ptr %slot696, align 8
  %v5328 = load i64, ptr %slot693, align 8
  %p5329 = inttoptr i64 %v5328 to ptr
  %ld5330 = load i64, ptr %p5329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5330, ptr %slot697, align 8
  %v5331 = load i64, ptr %slot697, align 8
  %cmp5332 = icmp ne i64 %v5331, 0
  %cv5333 = zext i1 %cmp5332 to i32
  store i32 %cv5333, ptr %slot698, align 8
  %v5334 = load i32, ptr %slot698, align 8
  %cv5335 = zext i32 %v5334 to i64
  %cond5336 = icmp ne i64 %cv5335, 0
  br i1 %cond5336, label %bb_rcgnn854, label %bb_rcgdone854
bb_rcgnn854:
  %v5337 = load i64, ptr %slot697, align 8
  %op5338 = sub i64 %v5337, 16
  store i64 %op5338, ptr %slot699, align 8
  %v5339 = load i64, ptr %slot697, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  %rgep5341 = getelementptr i8, ptr %p5340, i64 -16
  %ld5342 = load i64, ptr %rgep5341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5342, ptr %slot700, align 8
  %v5343 = load i64, ptr %slot700, align 8
  %op5344 = and i64 %v5343, 4611686018427387906
  store i64 %op5344, ptr %slot701, align 8
  %v5345 = load i64, ptr %slot701, align 8
  %cmp5346 = icmp ne i64 %v5345, 0
  %cv5347 = zext i1 %cmp5346 to i32
  store i32 %cv5347, ptr %slot702, align 8
  %v5348 = load i32, ptr %slot702, align 8
  %cv5349 = zext i32 %v5348 to i64
  %cond5350 = icmp ne i64 %cv5349, 0
  br i1 %cond5350, label %bb_rcgclear854, label %bb_rcgcounted854
bb_rcgcounted854:
  %v5351 = load i64, ptr %slot697, align 8
  %op5352 = sub i64 %v5351, 24
  store i64 %op5352, ptr %slot703, align 8
  %v5353 = load i64, ptr %slot697, align 8
  %p5354 = inttoptr i64 %v5353 to ptr
  %rgep5355 = getelementptr i8, ptr %p5354, i64 -24
  %ld5356 = load i64, ptr %rgep5355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5356, ptr %slot704, align 8
  %v5357 = load i64, ptr %slot704, align 8
  %op5358 = sub i64 %v5357, 1
  store i64 %op5358, ptr %slot705, align 8
  %v5359 = load i64, ptr %slot705, align 8
  %cmp5360 = icmp eq i64 %v5359, 0
  %cv5361 = zext i1 %cmp5360 to i32
  store i32 %cv5361, ptr %slot706, align 8
  %v5362 = load i32, ptr %slot706, align 8
  %cv5363 = zext i32 %v5362 to i64
  %cond5364 = icmp ne i64 %cv5363, 0
  br i1 %cond5364, label %bb_rcglast854, label %bb_rcgdec854
bb_rcglast854:
  %v5365 = load i64, ptr %slot697, align 8
  %op5366 = sub i64 %v5365, 32
  store i64 %op5366, ptr %slot707, align 8
  %v5367 = load i64, ptr %slot697, align 8
  %p5368 = inttoptr i64 %v5367 to ptr
  %rgep5369 = getelementptr i8, ptr %p5368, i64 -32
  %ld5370 = load i64, ptr %rgep5369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5370, ptr %slot708, align 8
  %v5371 = load i64, ptr %slot708, align 8
  %cmp5372 = icmp ne i64 %v5371, 0
  %cv5373 = zext i1 %cmp5372 to i32
  store i32 %cv5373, ptr %slot709, align 8
  %v5374 = load i32, ptr %slot709, align 8
  %cv5375 = zext i32 %v5374 to i64
  %cond5376 = icmp ne i64 %cv5375, 0
  br i1 %cond5376, label %bb_rcgdec854, label %bb_rcgslow854
bb_rcgslow854:
  %v5377 = load i64, ptr %slot696, align 8
  %v5378 = load i64, ptr %slot693, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v5377, i64 %v5378) nomerge, !dbg !138
  br label %bb_rcgdone854
bb_rcgdec854:
  %v5379 = load i64, ptr %slot705, align 8
  %v5380 = load i64, ptr %slot697, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %rgep5382 = getelementptr i8, ptr %p5381, i64 -24
  store i64 %v5379, ptr %rgep5382, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear854
bb_rcgclear854:
  %v5383 = load i64, ptr %slot693, align 8
  %p5384 = inttoptr i64 %v5383 to ptr
  store i64 0, ptr %p5384, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone854
bb_rcgdone854:
  br label %bb_rcslotdone838
bb_rcslotowner838:
  %v5385 = load i64, ptr %slot88, align 8
  store i64 %v5385, ptr %slot710, align 8
  %v5386 = load i64, ptr %slot693, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %ld5388 = load i64, ptr %p5387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5388, ptr %slot711, align 8
  %v5389 = load i64, ptr %slot711, align 8
  %cmp5390 = icmp ne i64 %v5389, 0
  %cv5391 = zext i1 %cmp5390 to i32
  store i32 %cv5391, ptr %slot712, align 8
  %v5392 = load i32, ptr %slot712, align 8
  %cv5393 = zext i32 %v5392 to i64
  %cond5394 = icmp ne i64 %cv5393, 0
  br i1 %cond5394, label %bb_rcgnn869, label %bb_rcgdone869
bb_rcgnn869:
  %v5395 = load i64, ptr %slot711, align 8
  %op5396 = sub i64 %v5395, 16
  store i64 %op5396, ptr %slot713, align 8
  %v5397 = load i64, ptr %slot711, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  %rgep5399 = getelementptr i8, ptr %p5398, i64 -16
  %ld5400 = load i64, ptr %rgep5399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5400, ptr %slot714, align 8
  %v5401 = load i64, ptr %slot714, align 8
  %op5402 = and i64 %v5401, 4611686018427387906
  store i64 %op5402, ptr %slot715, align 8
  %v5403 = load i64, ptr %slot715, align 8
  %cmp5404 = icmp ne i64 %v5403, 0
  %cv5405 = zext i1 %cmp5404 to i32
  store i32 %cv5405, ptr %slot716, align 8
  %v5406 = load i32, ptr %slot716, align 8
  %cv5407 = zext i32 %v5406 to i64
  %cond5408 = icmp ne i64 %cv5407, 0
  br i1 %cond5408, label %bb_rcgclear869, label %bb_rcgcounted869
bb_rcgcounted869:
  %v5409 = load i64, ptr %slot711, align 8
  %op5410 = sub i64 %v5409, 32
  store i64 %op5410, ptr %slot717, align 8
  %v5411 = load i64, ptr %slot711, align 8
  %p5412 = inttoptr i64 %v5411 to ptr
  %rgep5413 = getelementptr i8, ptr %p5412, i64 -32
  %ld5414 = load i64, ptr %rgep5413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5414, ptr %slot718, align 8
  %v5415 = load i64, ptr %slot718, align 8
  %op5416 = sub i64 %v5415, 1
  store i64 %op5416, ptr %slot719, align 8
  %v5417 = load i64, ptr %slot719, align 8
  %cmp5418 = icmp eq i64 %v5417, 0
  %cv5419 = zext i1 %cmp5418 to i32
  store i32 %cv5419, ptr %slot720, align 8
  %v5420 = load i32, ptr %slot720, align 8
  %cv5421 = zext i32 %v5420 to i64
  %cond5422 = icmp ne i64 %cv5421, 0
  br i1 %cond5422, label %bb_rcglast869, label %bb_rcgdec869
bb_rcglast869:
  %v5423 = load i64, ptr %slot711, align 8
  %op5424 = sub i64 %v5423, 24
  store i64 %op5424, ptr %slot721, align 8
  %v5425 = load i64, ptr %slot711, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  %rgep5427 = getelementptr i8, ptr %p5426, i64 -24
  %ld5428 = load i64, ptr %rgep5427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5428, ptr %slot722, align 8
  %v5429 = load i64, ptr %slot722, align 8
  %cmp5430 = icmp ne i64 %v5429, 0
  %cv5431 = zext i1 %cmp5430 to i32
  store i32 %cv5431, ptr %slot723, align 8
  %v5432 = load i32, ptr %slot723, align 8
  %cv5433 = zext i32 %v5432 to i64
  %cond5434 = icmp ne i64 %cv5433, 0
  br i1 %cond5434, label %bb_rcgdec869, label %bb_rcgslow869
bb_rcgslow869:
  %v5435 = load i64, ptr %slot710, align 8
  %v5436 = load i64, ptr %slot693, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v5435, i64 %v5436) nomerge, !dbg !138
  br label %bb_rcgdone869
bb_rcgdec869:
  %v5437 = load i64, ptr %slot719, align 8
  %v5438 = load i64, ptr %slot711, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %rgep5440 = getelementptr i8, ptr %p5439, i64 -32
  store i64 %v5437, ptr %rgep5440, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear869
bb_rcgclear869:
  %v5441 = load i64, ptr %slot693, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  store i64 0, ptr %p5442, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone869
bb_rcgdone869:
  br label %bb_rcslotdone838
bb_rcslotdone838:
  %v5443 = load i64, ptr %slot57, align 8
  store i64 %v5443, ptr %slot724, align 8
  %v5444 = load i64, ptr %slot42, align 8
  store i64 %v5444, ptr %slot725, align 8
  %v5445 = load i64, ptr %slot725, align 8
  %v5446 = load i64, ptr %slot724, align 8
  %p5447 = inttoptr i64 %v5445 to ptr
  %p5448 = inttoptr i64 %v5446 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5448, ptr %p5447, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5449 = load i64, ptr %slot31, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  store i32 0, ptr %p5450, align 4, !alias.scope !3, !noalias !4
  %v5451 = load i64, ptr %slot10, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  store i32 2, ptr %p5452, align 4, !alias.scope !3, !noalias !4
  %v5453 = load i64, ptr %slot32, align 8
  %p5454 = inttoptr i64 %v5453 to ptr
  %ld5455 = load i32, ptr %p5454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5455, ptr %slot726, align 8
  %v5456 = load i32, ptr %slot726, align 8
  %v5457 = load i64, ptr %slot10, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  store i32 %v5456, ptr %p5458, align 4, !alias.scope !3, !noalias !4
  %v5459 = load i64, ptr %slot9, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  store i32 1, ptr %p5460, align 4, !alias.scope !3, !noalias !4
  %v5461 = load i64, ptr %slot57, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  %ld5463 = load i64, ptr %p5462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5463, ptr %slot727, align 8
  %v5464 = load i64, ptr %slot727, align 8
  %v5465 = load i64, ptr %slot71, align 8
  %p5466 = inttoptr i64 %v5465 to ptr
  store i64 %v5464, ptr %p5466, align 8, !alias.scope !3, !noalias !4
  %v5467 = load i64, ptr %slot72, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  store i64 0, ptr %p5468, align 8, !alias.scope !3, !noalias !4
  %v5469 = load i64, ptr %slot72, align 8
  %p5470 = inttoptr i64 %v5469 to ptr
  %ld5471 = load i64, ptr %p5470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5471, ptr %slot728, align 8
  %v5472 = load i64, ptr %slot728, align 8
  %cmp5473 = icmp sge i64 %v5472, 0
  %cv5474 = zext i1 %cmp5473 to i64
  store i64 %cv5474, ptr %slot729, align 8
  %v5475 = load i64, ptr %slot729, align 8
  %cond5476 = icmp ne i64 %v5475, 0
  br i1 %cond5476, label %bb_success883, label %bb_failed883
bb_failed883:
  %v5477 = load i64, ptr %slot1, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p5478) nomerge, !dbg !140
  unreachable
bb_success883:
  %v5479 = load i64, ptr %slot88, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %p5481 = inttoptr i64 ptrtoint (ptr @myl_t_c0235a2002b47316e7055cdcc9950d30a5168fa64698c21e07a3f1d907870193 to i64) to ptr
  %v5482 = load i64, ptr %slot728, align 8
  %call5483 = call ptr @myl_native_list_new(ptr %p5480, ptr %p5481, i64 %v5482) nomerge, !dbg !140
  %calladdr5484 = ptrtoint ptr %call5483 to i64
  store i64 %calladdr5484, ptr %slot730, align 8
  %v5485 = load i64, ptr %slot730, align 8
  %cond5486 = icmp ne i64 %v5485, 0
  br i1 %cond5486, label %bb_success885, label %bb_failed885
bb_failed885:
  %v5487 = load i64, ptr %slot1, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5488) nomerge, !dbg !140
  unreachable
bb_success885:
  %v5489 = load i64, ptr %slot730, align 8
  %v5490 = load i64, ptr %slot72, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  store i64 %v5489, ptr %p5491, align 8, !alias.scope !3, !noalias !4
  %v5492 = load i64, ptr %slot72, align 8
  %p5493 = inttoptr i64 %v5492 to ptr
  %ld5494 = load i64, ptr %p5493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5494, ptr %slot731, align 8
  %v5495 = load i64, ptr %slot731, align 8
  %v5496 = load i64, ptr %slot41, align 8
  %p5497 = inttoptr i64 %v5496 to ptr
  store i64 %v5495, ptr %p5497, align 8, !alias.scope !3, !noalias !4
  %v5498 = load i64, ptr %slot41, align 8
  store i64 %v5498, ptr %slot732, align 8
  %v5499 = load i64, ptr %slot42, align 8
  store i64 %v5499, ptr %slot733, align 8
  %v5500 = load i64, ptr %slot732, align 8
  %v5501 = load i64, ptr %slot733, align 8
  %p5502 = inttoptr i64 %v5500 to ptr
  %p5503 = inttoptr i64 %v5501 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5503, ptr %p5502, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5504 = load i64, ptr %slot32, align 8
  %p5505 = inttoptr i64 %v5504 to ptr
  store i32 2, ptr %p5505, align 4, !alias.scope !3, !noalias !4
  %v5506 = load i64, ptr %slot31, align 8
  %p5507 = inttoptr i64 %v5506 to ptr
  store i32 1, ptr %p5507, align 4, !alias.scope !3, !noalias !4
  %v5508 = load i64, ptr %slot37, align 8
  store i64 %v5508, ptr %slot734, align 8
  %v5509 = load i64, ptr %slot42, align 8
  store i64 %v5509, ptr %slot735, align 8
  %v5510 = load i64, ptr %slot735, align 8
  %v5511 = load i64, ptr %slot734, align 8
  %p5512 = inttoptr i64 %v5510 to ptr
  %p5513 = inttoptr i64 %v5511 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5513, ptr %p5512, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5514 = load i64, ptr %slot30, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  store i32 2, ptr %p5515, align 4, !alias.scope !3, !noalias !4
  %v5516 = load i64, ptr %slot32, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %ld5518 = load i32, ptr %p5517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5518, ptr %slot736, align 8
  %v5519 = load i32, ptr %slot736, align 8
  %v5520 = load i64, ptr %slot30, align 8
  %p5521 = inttoptr i64 %v5520 to ptr
  store i32 %v5519, ptr %p5521, align 4, !alias.scope !3, !noalias !4
  %v5522 = load i64, ptr %slot31, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  store i32 0, ptr %p5523, align 4, !alias.scope !3, !noalias !4
  %v5524 = load i64, ptr %slot29, align 8
  %p5525 = inttoptr i64 %v5524 to ptr
  store i32 1, ptr %p5525, align 4, !alias.scope !3, !noalias !4
  %v5526 = load i64, ptr %slot734, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  %ld5528 = load i64, ptr %p5527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5528, ptr %slot737, align 8
  %v5529 = load i64, ptr %slot737, align 8
  %v5530 = load i64, ptr %slot72, align 8
  %p5531 = inttoptr i64 %v5530 to ptr
  store i64 %v5529, ptr %p5531, align 8, !alias.scope !3, !noalias !4
  %v5532 = load i64, ptr %slot72, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  %ld5534 = load i64, ptr %p5533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5534, ptr %slot738, align 8
  %v5535 = load i64, ptr %slot738, align 8
  %v5536 = load i64, ptr %slot41, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  store i64 %v5535, ptr %p5537, align 8, !alias.scope !3, !noalias !4
  %v5538 = load i64, ptr %slot41, align 8
  store i64 %v5538, ptr %slot739, align 8
  %v5539 = load i64, ptr %slot29, align 8
  %p5540 = inttoptr i64 %v5539 to ptr
  %ld5541 = load i32, ptr %p5540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5541, ptr %slot740, align 8
  %v5542 = load i64, ptr %slot30, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %ld5544 = load i32, ptr %p5543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5544, ptr %slot741, align 8
  %v5545 = load i32, ptr %slot741, align 8
  %op5546 = and i32 %v5545, 24
  store i32 %op5546, ptr %slot741, align 8
  %v5547 = load i32, ptr %slot741, align 8
  %cmp5548 = icmp eq i32 %v5547, 0
  %cv5549 = zext i1 %cmp5548 to i32
  store i32 %cv5549, ptr %slot742, align 8
  %v5550 = load i32, ptr %slot740, align 8
  %v5551 = load i32, ptr %slot742, align 8
  %op5552 = and i32 %v5550, %v5551
  store i32 %op5552, ptr %slot743, align 8
  %v5553 = load i32, ptr %slot743, align 8
  %cv5554 = zext i32 %v5553 to i64
  %cond5555 = icmp ne i64 %cv5554, 0
  br i1 %cond5555, label %bb_rcprivateown908, label %bb_rcprivateloan908
bb_rcprivateown908:
  %v5556 = load i64, ptr %slot42, align 8
  store i64 %v5556, ptr %slot744, align 8
  %v5557 = load i64, ptr %slot89, align 8
  store i64 %v5557, ptr %slot745, align 8
  %v5558 = load i64, ptr %slot739, align 8
  %v5559 = load i64, ptr %slot744, align 8
  %op5560 = sub i64 %v5558, %v5559
  store i64 %op5560, ptr %slot746, align 8
  %v5561 = load i64, ptr %slot744, align 8
  %v5562 = load i64, ptr %slot739, align 8
  %op5563 = sub i64 %v5561, %v5562
  store i64 %op5563, ptr %slot747, align 8
  %v5564 = load i64, ptr %slot746, align 8
  %cmp5565 = icmp ult i64 %v5564, 8
  %cv5566 = zext i1 %cmp5565 to i32
  store i32 %cv5566, ptr %slot748, align 8
  %v5567 = load i64, ptr %slot747, align 8
  %cmp5568 = icmp ult i64 %v5567, 8
  %cv5569 = zext i1 %cmp5568 to i32
  store i32 %cv5569, ptr %slot749, align 8
  %v5570 = load i32, ptr %slot748, align 8
  %v5571 = load i32, ptr %slot749, align 8
  %op5572 = or i32 %v5570, %v5571
  store i32 %op5572, ptr %slot750, align 8
  %v5573 = load i32, ptr %slot750, align 8
  %cv5574 = zext i32 %v5573 to i64
  %cond5575 = icmp ne i64 %cv5574, 0
  br i1 %cond5575, label %bb_rcmoveslow911, label %bb_rcmovecheck911
bb_rcmovecheck911:
  %v5576 = load i64, ptr %slot739, align 8
  %p5578 = inttoptr i64 %v5576 to ptr
  %gep5579 = getelementptr i8, ptr %p5578, i64 0
  %op5577 = ptrtoint ptr %gep5579 to i64
  store i64 %op5577, ptr %slot751, align 8
  %v5580 = load i64, ptr %slot751, align 8
  %p5581 = inttoptr i64 %v5580 to ptr
  %ld5582 = load i64, ptr %p5581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5582, ptr %slot752, align 8
  %v5583 = load i64, ptr %slot752, align 8
  %cmp5584 = icmp ne i64 %v5583, 0
  %cv5585 = zext i1 %cmp5584 to i32
  store i32 %cv5585, ptr %slot753, align 8
  %v5586 = load i32, ptr %slot753, align 8
  %cv5587 = zext i32 %v5586 to i64
  %cond5588 = icmp ne i64 %cv5587, 0
  br i1 %cond5588, label %bb_rcmoveheader919, label %bb_rcmovenext919
bb_rcmoveheader919:
  %v5589 = load i64, ptr %slot752, align 8
  %op5590 = sub i64 %v5589, 16
  store i64 %op5590, ptr %slot754, align 8
  %v5591 = load i64, ptr %slot752, align 8
  %p5592 = inttoptr i64 %v5591 to ptr
  %rgep5593 = getelementptr i8, ptr %p5592, i64 -16
  %ld5594 = load i64, ptr %rgep5593, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5594, ptr %slot755, align 8
  %v5595 = load i64, ptr %slot755, align 8
  %op5596 = and i64 %v5595, 5764607523034234881
  store i64 %op5596, ptr %slot756, align 8
  %v5597 = load i64, ptr %slot756, align 8
  %cmp5598 = icmp ne i64 %v5597, 0
  %cv5599 = zext i1 %cmp5598 to i32
  store i32 %cv5599, ptr %slot757, align 8
  %v5600 = load i32, ptr %slot757, align 8
  %cv5601 = zext i32 %v5600 to i64
  %cond5602 = icmp ne i64 %cv5601, 0
  br i1 %cond5602, label %bb_rcmoveslow911, label %bb_rcmovenext919
bb_rcmovenext919:
  %v5603 = load i64, ptr %slot739, align 8
  %v5604 = load i64, ptr %slot744, align 8
  %p5605 = inttoptr i64 %v5603 to ptr
  %p5606 = inttoptr i64 %v5604 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5606, ptr %p5605, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5607 = load i64, ptr %slot739, align 8
  %p5608 = inttoptr i64 %v5607 to ptr
  store i64 0, ptr %p5608, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved911
bb_rcmoveslow911:
  %v5609 = load i64, ptr %slot88, align 8
  %v5610 = load i64, ptr %slot744, align 8
  %v5611 = load i64, ptr %slot739, align 8
  %v5612 = load i64, ptr %slot745, align 8
  %cv5613 = trunc i64 %v5612 to i32
  %call5614 = call i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_take(i64 %v5609, i64 %v5610, i64 %v5611, i32 %cv5613) nomerge, !dbg !142
  store i32 %call5614, ptr %slot758, align 8
  %v5615 = load i32, ptr %slot758, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcsuccess926, label %bb_rcfailure926
bb_rcfailure926:
  %v5618 = load i64, ptr %slot88, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  %call5620 = call i32 @myl_rc_take_failure(ptr %p5619) nomerge, !dbg !142
  store i32 %call5620, ptr %slot759, align 8
  %v5621 = load i64, ptr %slot1, align 8
  %p5622 = inttoptr i64 %v5621 to ptr
  %v5623 = load i32, ptr %slot759, align 8
  %call5624 = call i32 @myl_qbe_rc_status(ptr %p5622, i32 %v5623) nomerge, !dbg !142
  store i32 %call5624, ptr %slot760, align 8
  br label %bb_failure
bb_rcsuccess926:
  br label %bb_rcmoved911
bb_rcmoved911:
  %v5625 = load i64, ptr %slot29, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  store i32 0, ptr %p5626, align 4, !alias.scope !3, !noalias !4
  %v5627 = load i64, ptr %slot32, align 8
  %p5628 = inttoptr i64 %v5627 to ptr
  store i32 2, ptr %p5628, align 4, !alias.scope !3, !noalias !4
  %v5629 = load i64, ptr %slot31, align 8
  %p5630 = inttoptr i64 %v5629 to ptr
  store i32 1, ptr %p5630, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared908
bb_rcprivateloan908:
  %v5631 = load i64, ptr %slot29, align 8
  %p5632 = inttoptr i64 %v5631 to ptr
  %ld5633 = load i32, ptr %p5632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5633, ptr %slot761, align 8
  %v5634 = load i64, ptr %slot30, align 8
  %p5635 = inttoptr i64 %v5634 to ptr
  %ld5636 = load i32, ptr %p5635, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5636, ptr %slot762, align 8
  %v5637 = load i32, ptr %slot762, align 8
  %cmp5638 = icmp eq i32 %v5637, 16
  %cv5639 = zext i1 %cmp5638 to i32
  store i32 %cv5639, ptr %slot763, align 8
  %v5640 = load i32, ptr %slot763, align 8
  %v5641 = load i32, ptr %slot761, align 8
  %op5642 = and i32 %v5640, %v5641
  store i32 %op5642, ptr %slot763, align 8
  %v5643 = load i32, ptr %slot763, align 8
  %cv5644 = zext i32 %v5643 to i64
  %cond5645 = icmp ne i64 %cv5644, 0
  br i1 %cond5645, label %bb_rcprivatemove908, label %bb_rcprivatenew908
bb_rcprivatemove908:
  %v5646 = load i64, ptr %slot42, align 8
  store i64 %v5646, ptr %slot764, align 8
  %v5647 = load i64, ptr %slot739, align 8
  %v5648 = load i64, ptr %slot764, align 8
  %p5649 = inttoptr i64 %v5647 to ptr
  %p5650 = inttoptr i64 %v5648 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5650, ptr %p5649, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5651 = load i64, ptr %slot739, align 8
  %p5652 = inttoptr i64 %v5651 to ptr
  store i64 0, ptr %p5652, align 8, !alias.scope !3, !noalias !4
  %v5653 = load i64, ptr %slot32, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  store i32 2, ptr %p5654, align 4, !alias.scope !3, !noalias !4
  %v5655 = load i64, ptr %slot32, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  store i32 16, ptr %p5656, align 4, !alias.scope !3, !noalias !4
  %v5657 = load i64, ptr %slot31, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  store i32 1, ptr %p5658, align 4, !alias.scope !3, !noalias !4
  %v5659 = load i64, ptr %slot29, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  store i32 0, ptr %p5660, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared908
bb_rcprivatenew908:
  %v5661 = load i64, ptr %slot42, align 8
  store i64 %v5661, ptr %slot765, align 8
  %v5662 = load i64, ptr %slot739, align 8
  %p5663 = inttoptr i64 %v5662 to ptr
  %ld5664 = load i64, ptr %p5663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5664, ptr %slot766, align 8
  %v5665 = load i64, ptr %slot766, align 8
  %cmp5666 = icmp ne i64 %v5665, 0
  %cv5667 = zext i1 %cmp5666 to i32
  store i32 %cv5667, ptr %slot767, align 8
  %v5668 = load i32, ptr %slot767, align 8
  %cv5669 = zext i32 %v5668 to i64
  %cond5670 = icmp ne i64 %cv5669, 0
  br i1 %cond5670, label %bb_rcgnn944, label %bb_rcgstore944
bb_rcgnn944:
  %v5671 = load i64, ptr %slot766, align 8
  %op5672 = sub i64 %v5671, 16
  store i64 %op5672, ptr %slot768, align 8
  %v5673 = load i64, ptr %slot766, align 8
  %p5674 = inttoptr i64 %v5673 to ptr
  %rgep5675 = getelementptr i8, ptr %p5674, i64 -16
  %ld5676 = load i64, ptr %rgep5675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5676, ptr %slot769, align 8
  %v5677 = load i64, ptr %slot769, align 8
  %op5678 = and i64 %v5677, 4611686018427387906
  store i64 %op5678, ptr %slot770, align 8
  %v5679 = load i64, ptr %slot770, align 8
  %cmp5680 = icmp ne i64 %v5679, 0
  %cv5681 = zext i1 %cmp5680 to i32
  store i32 %cv5681, ptr %slot771, align 8
  %v5682 = load i32, ptr %slot771, align 8
  %cv5683 = zext i32 %v5682 to i64
  %cond5684 = icmp ne i64 %cv5683, 0
  br i1 %cond5684, label %bb_rcgstore944, label %bb_rcginc944
bb_rcginc944:
  %v5685 = load i64, ptr %slot766, align 8
  %op5686 = sub i64 %v5685, 24
  store i64 %op5686, ptr %slot772, align 8
  %v5687 = load i64, ptr %slot766, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  %rgep5689 = getelementptr i8, ptr %p5688, i64 -24
  %ld5690 = load i64, ptr %rgep5689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5690, ptr %slot773, align 8
  %v5691 = load i64, ptr %slot773, align 8
  %op5692 = add i64 %v5691, 1
  store i64 %op5692, ptr %slot774, align 8
  %v5693 = load i64, ptr %slot774, align 8
  %cmp5694 = icmp eq i64 %v5693, 0
  %cv5695 = zext i1 %cmp5694 to i32
  store i32 %cv5695, ptr %slot775, align 8
  %v5696 = load i32, ptr %slot775, align 8
  %cv5697 = zext i32 %v5696 to i64
  %cond5698 = icmp ne i64 %cv5697, 0
  br i1 %cond5698, label %bb_rcglimit944, label %bb_rcgcapacity944
bb_rcglimit944:
  %v5699 = load i64, ptr %slot1, align 8
  %p5700 = inttoptr i64 %v5699 to ptr
  %call5701 = call i32 @myl_qbe_rc_status(ptr %p5700, i32 2) nomerge, !dbg !142
  store i32 %call5701, ptr %slot776, align 8
  br label %bb_failure
bb_rcgcapacity944:
  %v5702 = load i64, ptr %slot774, align 8
  %v5703 = load i64, ptr %slot766, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  %rgep5705 = getelementptr i8, ptr %p5704, i64 -24
  store i64 %v5702, ptr %rgep5705, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore944
bb_rcgstore944:
  %v5706 = load i64, ptr %slot766, align 8
  %v5707 = load i64, ptr %slot765, align 8
  %p5708 = inttoptr i64 %v5707 to ptr
  store i64 %v5706, ptr %p5708, align 8, !alias.scope !3, !noalias !4
  %v5709 = load i64, ptr %slot32, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  store i32 2, ptr %p5710, align 4, !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot32, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i32 16, ptr %p5712, align 4, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot31, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  store i32 1, ptr %p5714, align 4, !alias.scope !3, !noalias !4
  %v5715 = load i64, ptr %slot29, align 8
  %p5716 = inttoptr i64 %v5715 to ptr
  %ld5717 = load i32, ptr %p5716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5717, ptr %slot777, align 8
  %v5718 = load i32, ptr %slot777, align 8
  %cv5719 = zext i32 %v5718 to i64
  %cond5720 = icmp ne i64 %cv5719, 0
  br i1 %cond5720, label %bb_rcslotdrop960, label %bb_rcslotdone960
bb_rcslotdrop960:
  %v5721 = load i64, ptr %slot29, align 8
  %p5722 = inttoptr i64 %v5721 to ptr
  store i32 0, ptr %p5722, align 4, !alias.scope !3, !noalias !4
  %v5723 = load i64, ptr %slot37, align 8
  store i64 %v5723, ptr %slot778, align 8
  %v5724 = load i64, ptr %slot30, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  %ld5726 = load i32, ptr %p5725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5726, ptr %slot779, align 8
  %v5727 = load i32, ptr %slot779, align 8
  %op5728 = and i32 %v5727, 28
  store i32 %op5728, ptr %slot780, align 8
  %v5729 = load i32, ptr %slot780, align 8
  %cv5730 = zext i32 %v5729 to i64
  %cond5731 = icmp ne i64 %cv5730, 0
  br i1 %cond5731, label %bb_rcslotrole960, label %bb_rcslotowner960
bb_rcslotrole960:
  %v5732 = load i64, ptr %slot88, align 8
  store i64 %v5732, ptr %slot781, align 8
  %v5733 = load i64, ptr %slot778, align 8
  %p5734 = inttoptr i64 %v5733 to ptr
  %ld5735 = load i64, ptr %p5734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5735, ptr %slot782, align 8
  %v5736 = load i64, ptr %slot782, align 8
  %cmp5737 = icmp ne i64 %v5736, 0
  %cv5738 = zext i1 %cmp5737 to i32
  store i32 %cv5738, ptr %slot783, align 8
  %v5739 = load i32, ptr %slot783, align 8
  %cv5740 = zext i32 %v5739 to i64
  %cond5741 = icmp ne i64 %cv5740, 0
  br i1 %cond5741, label %bb_rcgnn976, label %bb_rcgdone976
bb_rcgnn976:
  %v5742 = load i64, ptr %slot782, align 8
  %op5743 = sub i64 %v5742, 16
  store i64 %op5743, ptr %slot784, align 8
  %v5744 = load i64, ptr %slot782, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %rgep5746 = getelementptr i8, ptr %p5745, i64 -16
  %ld5747 = load i64, ptr %rgep5746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5747, ptr %slot785, align 8
  %v5748 = load i64, ptr %slot785, align 8
  %op5749 = and i64 %v5748, 4611686018427387906
  store i64 %op5749, ptr %slot786, align 8
  %v5750 = load i64, ptr %slot786, align 8
  %cmp5751 = icmp ne i64 %v5750, 0
  %cv5752 = zext i1 %cmp5751 to i32
  store i32 %cv5752, ptr %slot787, align 8
  %v5753 = load i32, ptr %slot787, align 8
  %cv5754 = zext i32 %v5753 to i64
  %cond5755 = icmp ne i64 %cv5754, 0
  br i1 %cond5755, label %bb_rcgclear976, label %bb_rcgcounted976
bb_rcgcounted976:
  %v5756 = load i64, ptr %slot782, align 8
  %op5757 = sub i64 %v5756, 24
  store i64 %op5757, ptr %slot788, align 8
  %v5758 = load i64, ptr %slot782, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  %rgep5760 = getelementptr i8, ptr %p5759, i64 -24
  %ld5761 = load i64, ptr %rgep5760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5761, ptr %slot789, align 8
  %v5762 = load i64, ptr %slot789, align 8
  %op5763 = sub i64 %v5762, 1
  store i64 %op5763, ptr %slot790, align 8
  %v5764 = load i64, ptr %slot790, align 8
  %cmp5765 = icmp eq i64 %v5764, 0
  %cv5766 = zext i1 %cmp5765 to i32
  store i32 %cv5766, ptr %slot791, align 8
  %v5767 = load i32, ptr %slot791, align 8
  %cv5768 = zext i32 %v5767 to i64
  %cond5769 = icmp ne i64 %cv5768, 0
  br i1 %cond5769, label %bb_rcglast976, label %bb_rcgdec976
bb_rcglast976:
  %v5770 = load i64, ptr %slot782, align 8
  %op5771 = sub i64 %v5770, 32
  store i64 %op5771, ptr %slot792, align 8
  %v5772 = load i64, ptr %slot782, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  %rgep5774 = getelementptr i8, ptr %p5773, i64 -32
  %ld5775 = load i64, ptr %rgep5774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5775, ptr %slot793, align 8
  %v5776 = load i64, ptr %slot793, align 8
  %cmp5777 = icmp ne i64 %v5776, 0
  %cv5778 = zext i1 %cmp5777 to i32
  store i32 %cv5778, ptr %slot794, align 8
  %v5779 = load i32, ptr %slot794, align 8
  %cv5780 = zext i32 %v5779 to i64
  %cond5781 = icmp ne i64 %cv5780, 0
  br i1 %cond5781, label %bb_rcgdec976, label %bb_rcgslow976
bb_rcgslow976:
  %v5782 = load i64, ptr %slot781, align 8
  %v5783 = load i64, ptr %slot778, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v5782, i64 %v5783) nomerge, !dbg !142
  br label %bb_rcgdone976
bb_rcgdec976:
  %v5784 = load i64, ptr %slot790, align 8
  %v5785 = load i64, ptr %slot782, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  %rgep5787 = getelementptr i8, ptr %p5786, i64 -24
  store i64 %v5784, ptr %rgep5787, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear976
bb_rcgclear976:
  %v5788 = load i64, ptr %slot778, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  store i64 0, ptr %p5789, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone976
bb_rcgdone976:
  br label %bb_rcslotdone960
bb_rcslotowner960:
  %v5790 = load i64, ptr %slot88, align 8
  store i64 %v5790, ptr %slot795, align 8
  %v5791 = load i64, ptr %slot778, align 8
  %p5792 = inttoptr i64 %v5791 to ptr
  %ld5793 = load i64, ptr %p5792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5793, ptr %slot796, align 8
  %v5794 = load i64, ptr %slot796, align 8
  %cmp5795 = icmp ne i64 %v5794, 0
  %cv5796 = zext i1 %cmp5795 to i32
  store i32 %cv5796, ptr %slot797, align 8
  %v5797 = load i32, ptr %slot797, align 8
  %cv5798 = zext i32 %v5797 to i64
  %cond5799 = icmp ne i64 %cv5798, 0
  br i1 %cond5799, label %bb_rcgnn991, label %bb_rcgdone991
bb_rcgnn991:
  %v5800 = load i64, ptr %slot796, align 8
  %op5801 = sub i64 %v5800, 16
  store i64 %op5801, ptr %slot798, align 8
  %v5802 = load i64, ptr %slot796, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %rgep5804 = getelementptr i8, ptr %p5803, i64 -16
  %ld5805 = load i64, ptr %rgep5804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5805, ptr %slot799, align 8
  %v5806 = load i64, ptr %slot799, align 8
  %op5807 = and i64 %v5806, 4611686018427387906
  store i64 %op5807, ptr %slot800, align 8
  %v5808 = load i64, ptr %slot800, align 8
  %cmp5809 = icmp ne i64 %v5808, 0
  %cv5810 = zext i1 %cmp5809 to i32
  store i32 %cv5810, ptr %slot801, align 8
  %v5811 = load i32, ptr %slot801, align 8
  %cv5812 = zext i32 %v5811 to i64
  %cond5813 = icmp ne i64 %cv5812, 0
  br i1 %cond5813, label %bb_rcgclear991, label %bb_rcgcounted991
bb_rcgcounted991:
  %v5814 = load i64, ptr %slot796, align 8
  %op5815 = sub i64 %v5814, 32
  store i64 %op5815, ptr %slot802, align 8
  %v5816 = load i64, ptr %slot796, align 8
  %p5817 = inttoptr i64 %v5816 to ptr
  %rgep5818 = getelementptr i8, ptr %p5817, i64 -32
  %ld5819 = load i64, ptr %rgep5818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5819, ptr %slot803, align 8
  %v5820 = load i64, ptr %slot803, align 8
  %op5821 = sub i64 %v5820, 1
  store i64 %op5821, ptr %slot804, align 8
  %v5822 = load i64, ptr %slot804, align 8
  %cmp5823 = icmp eq i64 %v5822, 0
  %cv5824 = zext i1 %cmp5823 to i32
  store i32 %cv5824, ptr %slot805, align 8
  %v5825 = load i32, ptr %slot805, align 8
  %cv5826 = zext i32 %v5825 to i64
  %cond5827 = icmp ne i64 %cv5826, 0
  br i1 %cond5827, label %bb_rcglast991, label %bb_rcgdec991
bb_rcglast991:
  %v5828 = load i64, ptr %slot796, align 8
  %op5829 = sub i64 %v5828, 24
  store i64 %op5829, ptr %slot806, align 8
  %v5830 = load i64, ptr %slot796, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  %rgep5832 = getelementptr i8, ptr %p5831, i64 -24
  %ld5833 = load i64, ptr %rgep5832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5833, ptr %slot807, align 8
  %v5834 = load i64, ptr %slot807, align 8
  %cmp5835 = icmp ne i64 %v5834, 0
  %cv5836 = zext i1 %cmp5835 to i32
  store i32 %cv5836, ptr %slot808, align 8
  %v5837 = load i32, ptr %slot808, align 8
  %cv5838 = zext i32 %v5837 to i64
  %cond5839 = icmp ne i64 %cv5838, 0
  br i1 %cond5839, label %bb_rcgdec991, label %bb_rcgslow991
bb_rcgslow991:
  %v5840 = load i64, ptr %slot795, align 8
  %v5841 = load i64, ptr %slot778, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v5840, i64 %v5841) nomerge, !dbg !142
  br label %bb_rcgdone991
bb_rcgdec991:
  %v5842 = load i64, ptr %slot804, align 8
  %v5843 = load i64, ptr %slot796, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  %rgep5845 = getelementptr i8, ptr %p5844, i64 -32
  store i64 %v5842, ptr %rgep5845, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear991
bb_rcgclear991:
  %v5846 = load i64, ptr %slot778, align 8
  %p5847 = inttoptr i64 %v5846 to ptr
  store i64 0, ptr %p5847, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone991
bb_rcgdone991:
  br label %bb_rcslotdone960
bb_rcslotdone960:
  br label %bb_rcprivateprepared908
bb_rcprivateprepared908:
  %v5848 = load i64, ptr %slot11, align 8
  %p5849 = inttoptr i64 %v5848 to ptr
  %ld5850 = load i32, ptr %p5849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5850, ptr %slot809, align 8
  %v5851 = load i32, ptr %slot809, align 8
  %cv5852 = zext i32 %v5851 to i64
  %cond5853 = icmp ne i64 %cv5852, 0
  br i1 %cond5853, label %bb_rcslotdrop998, label %bb_rcslotdone998
bb_rcslotdrop998:
  %v5854 = load i64, ptr %slot11, align 8
  %p5855 = inttoptr i64 %v5854 to ptr
  store i32 0, ptr %p5855, align 4, !alias.scope !3, !noalias !4
  %v5856 = load i64, ptr %slot58, align 8
  store i64 %v5856, ptr %slot810, align 8
  %v5857 = load i64, ptr %slot12, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  %ld5859 = load i32, ptr %p5858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5859, ptr %slot811, align 8
  %v5860 = load i32, ptr %slot811, align 8
  %op5861 = and i32 %v5860, 28
  store i32 %op5861, ptr %slot812, align 8
  %v5862 = load i32, ptr %slot812, align 8
  %cv5863 = zext i32 %v5862 to i64
  %cond5864 = icmp ne i64 %cv5863, 0
  br i1 %cond5864, label %bb_rcslotrole998, label %bb_rcslotowner998
bb_rcslotrole998:
  %v5865 = load i64, ptr %slot88, align 8
  store i64 %v5865, ptr %slot813, align 8
  %v5866 = load i64, ptr %slot810, align 8
  %p5867 = inttoptr i64 %v5866 to ptr
  %ld5868 = load i64, ptr %p5867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5868, ptr %slot814, align 8
  %v5869 = load i64, ptr %slot814, align 8
  %cmp5870 = icmp ne i64 %v5869, 0
  %cv5871 = zext i1 %cmp5870 to i32
  store i32 %cv5871, ptr %slot815, align 8
  %v5872 = load i32, ptr %slot815, align 8
  %cv5873 = zext i32 %v5872 to i64
  %cond5874 = icmp ne i64 %cv5873, 0
  br i1 %cond5874, label %bb_rcgnn1014, label %bb_rcgdone1014
bb_rcgnn1014:
  %v5875 = load i64, ptr %slot814, align 8
  %op5876 = sub i64 %v5875, 16
  store i64 %op5876, ptr %slot816, align 8
  %v5877 = load i64, ptr %slot814, align 8
  %p5878 = inttoptr i64 %v5877 to ptr
  %rgep5879 = getelementptr i8, ptr %p5878, i64 -16
  %ld5880 = load i64, ptr %rgep5879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5880, ptr %slot817, align 8
  %v5881 = load i64, ptr %slot817, align 8
  %op5882 = and i64 %v5881, 4611686018427387906
  store i64 %op5882, ptr %slot818, align 8
  %v5883 = load i64, ptr %slot818, align 8
  %cmp5884 = icmp ne i64 %v5883, 0
  %cv5885 = zext i1 %cmp5884 to i32
  store i32 %cv5885, ptr %slot819, align 8
  %v5886 = load i32, ptr %slot819, align 8
  %cv5887 = zext i32 %v5886 to i64
  %cond5888 = icmp ne i64 %cv5887, 0
  br i1 %cond5888, label %bb_rcgclear1014, label %bb_rcgcounted1014
bb_rcgcounted1014:
  %v5889 = load i64, ptr %slot814, align 8
  %op5890 = sub i64 %v5889, 24
  store i64 %op5890, ptr %slot820, align 8
  %v5891 = load i64, ptr %slot814, align 8
  %p5892 = inttoptr i64 %v5891 to ptr
  %rgep5893 = getelementptr i8, ptr %p5892, i64 -24
  %ld5894 = load i64, ptr %rgep5893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5894, ptr %slot821, align 8
  %v5895 = load i64, ptr %slot821, align 8
  %op5896 = sub i64 %v5895, 1
  store i64 %op5896, ptr %slot822, align 8
  %v5897 = load i64, ptr %slot822, align 8
  %cmp5898 = icmp eq i64 %v5897, 0
  %cv5899 = zext i1 %cmp5898 to i32
  store i32 %cv5899, ptr %slot823, align 8
  %v5900 = load i32, ptr %slot823, align 8
  %cv5901 = zext i32 %v5900 to i64
  %cond5902 = icmp ne i64 %cv5901, 0
  br i1 %cond5902, label %bb_rcglast1014, label %bb_rcgdec1014
bb_rcglast1014:
  %v5903 = load i64, ptr %slot814, align 8
  %op5904 = sub i64 %v5903, 32
  store i64 %op5904, ptr %slot824, align 8
  %v5905 = load i64, ptr %slot814, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  %rgep5907 = getelementptr i8, ptr %p5906, i64 -32
  %ld5908 = load i64, ptr %rgep5907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5908, ptr %slot825, align 8
  %v5909 = load i64, ptr %slot825, align 8
  %cmp5910 = icmp ne i64 %v5909, 0
  %cv5911 = zext i1 %cmp5910 to i32
  store i32 %cv5911, ptr %slot826, align 8
  %v5912 = load i32, ptr %slot826, align 8
  %cv5913 = zext i32 %v5912 to i64
  %cond5914 = icmp ne i64 %cv5913, 0
  br i1 %cond5914, label %bb_rcgdec1014, label %bb_rcgslow1014
bb_rcgslow1014:
  %v5915 = load i64, ptr %slot813, align 8
  %v5916 = load i64, ptr %slot810, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v5915, i64 %v5916) nomerge, !dbg !142
  br label %bb_rcgdone1014
bb_rcgdec1014:
  %v5917 = load i64, ptr %slot822, align 8
  %v5918 = load i64, ptr %slot814, align 8
  %p5919 = inttoptr i64 %v5918 to ptr
  %rgep5920 = getelementptr i8, ptr %p5919, i64 -24
  store i64 %v5917, ptr %rgep5920, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1014
bb_rcgclear1014:
  %v5921 = load i64, ptr %slot810, align 8
  %p5922 = inttoptr i64 %v5921 to ptr
  store i64 0, ptr %p5922, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1014
bb_rcgdone1014:
  br label %bb_rcslotdone998
bb_rcslotowner998:
  %v5923 = load i64, ptr %slot88, align 8
  store i64 %v5923, ptr %slot827, align 8
  %v5924 = load i64, ptr %slot810, align 8
  %p5925 = inttoptr i64 %v5924 to ptr
  %ld5926 = load i64, ptr %p5925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5926, ptr %slot828, align 8
  %v5927 = load i64, ptr %slot828, align 8
  %cmp5928 = icmp ne i64 %v5927, 0
  %cv5929 = zext i1 %cmp5928 to i32
  store i32 %cv5929, ptr %slot829, align 8
  %v5930 = load i32, ptr %slot829, align 8
  %cv5931 = zext i32 %v5930 to i64
  %cond5932 = icmp ne i64 %cv5931, 0
  br i1 %cond5932, label %bb_rcgnn1029, label %bb_rcgdone1029
bb_rcgnn1029:
  %v5933 = load i64, ptr %slot828, align 8
  %op5934 = sub i64 %v5933, 16
  store i64 %op5934, ptr %slot830, align 8
  %v5935 = load i64, ptr %slot828, align 8
  %p5936 = inttoptr i64 %v5935 to ptr
  %rgep5937 = getelementptr i8, ptr %p5936, i64 -16
  %ld5938 = load i64, ptr %rgep5937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5938, ptr %slot831, align 8
  %v5939 = load i64, ptr %slot831, align 8
  %op5940 = and i64 %v5939, 4611686018427387906
  store i64 %op5940, ptr %slot832, align 8
  %v5941 = load i64, ptr %slot832, align 8
  %cmp5942 = icmp ne i64 %v5941, 0
  %cv5943 = zext i1 %cmp5942 to i32
  store i32 %cv5943, ptr %slot833, align 8
  %v5944 = load i32, ptr %slot833, align 8
  %cv5945 = zext i32 %v5944 to i64
  %cond5946 = icmp ne i64 %cv5945, 0
  br i1 %cond5946, label %bb_rcgclear1029, label %bb_rcgcounted1029
bb_rcgcounted1029:
  %v5947 = load i64, ptr %slot828, align 8
  %op5948 = sub i64 %v5947, 32
  store i64 %op5948, ptr %slot834, align 8
  %v5949 = load i64, ptr %slot828, align 8
  %p5950 = inttoptr i64 %v5949 to ptr
  %rgep5951 = getelementptr i8, ptr %p5950, i64 -32
  %ld5952 = load i64, ptr %rgep5951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5952, ptr %slot835, align 8
  %v5953 = load i64, ptr %slot835, align 8
  %op5954 = sub i64 %v5953, 1
  store i64 %op5954, ptr %slot836, align 8
  %v5955 = load i64, ptr %slot836, align 8
  %cmp5956 = icmp eq i64 %v5955, 0
  %cv5957 = zext i1 %cmp5956 to i32
  store i32 %cv5957, ptr %slot837, align 8
  %v5958 = load i32, ptr %slot837, align 8
  %cv5959 = zext i32 %v5958 to i64
  %cond5960 = icmp ne i64 %cv5959, 0
  br i1 %cond5960, label %bb_rcglast1029, label %bb_rcgdec1029
bb_rcglast1029:
  %v5961 = load i64, ptr %slot828, align 8
  %op5962 = sub i64 %v5961, 24
  store i64 %op5962, ptr %slot838, align 8
  %v5963 = load i64, ptr %slot828, align 8
  %p5964 = inttoptr i64 %v5963 to ptr
  %rgep5965 = getelementptr i8, ptr %p5964, i64 -24
  %ld5966 = load i64, ptr %rgep5965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5966, ptr %slot839, align 8
  %v5967 = load i64, ptr %slot839, align 8
  %cmp5968 = icmp ne i64 %v5967, 0
  %cv5969 = zext i1 %cmp5968 to i32
  store i32 %cv5969, ptr %slot840, align 8
  %v5970 = load i32, ptr %slot840, align 8
  %cv5971 = zext i32 %v5970 to i64
  %cond5972 = icmp ne i64 %cv5971, 0
  br i1 %cond5972, label %bb_rcgdec1029, label %bb_rcgslow1029
bb_rcgslow1029:
  %v5973 = load i64, ptr %slot827, align 8
  %v5974 = load i64, ptr %slot810, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v5973, i64 %v5974) nomerge, !dbg !142
  br label %bb_rcgdone1029
bb_rcgdec1029:
  %v5975 = load i64, ptr %slot836, align 8
  %v5976 = load i64, ptr %slot828, align 8
  %p5977 = inttoptr i64 %v5976 to ptr
  %rgep5978 = getelementptr i8, ptr %p5977, i64 -32
  store i64 %v5975, ptr %rgep5978, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1029
bb_rcgclear1029:
  %v5979 = load i64, ptr %slot810, align 8
  %p5980 = inttoptr i64 %v5979 to ptr
  store i64 0, ptr %p5980, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1029
bb_rcgdone1029:
  br label %bb_rcslotdone998
bb_rcslotdone998:
  %v5981 = load i64, ptr %slot58, align 8
  store i64 %v5981, ptr %slot841, align 8
  %v5982 = load i64, ptr %slot42, align 8
  store i64 %v5982, ptr %slot842, align 8
  %v5983 = load i64, ptr %slot842, align 8
  %v5984 = load i64, ptr %slot841, align 8
  %p5985 = inttoptr i64 %v5983 to ptr
  %p5986 = inttoptr i64 %v5984 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5986, ptr %p5985, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5987 = load i64, ptr %slot31, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  store i32 0, ptr %p5988, align 4, !alias.scope !3, !noalias !4
  %v5989 = load i64, ptr %slot12, align 8
  %p5990 = inttoptr i64 %v5989 to ptr
  store i32 2, ptr %p5990, align 4, !alias.scope !3, !noalias !4
  %v5991 = load i64, ptr %slot32, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  %ld5993 = load i32, ptr %p5992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5993, ptr %slot843, align 8
  %v5994 = load i32, ptr %slot843, align 8
  %v5995 = load i64, ptr %slot12, align 8
  %p5996 = inttoptr i64 %v5995 to ptr
  store i32 %v5994, ptr %p5996, align 4, !alias.scope !3, !noalias !4
  %v5997 = load i64, ptr %slot11, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  store i32 1, ptr %p5998, align 4, !alias.scope !3, !noalias !4
  %v5999 = load i64, ptr %slot58, align 8
  %p6000 = inttoptr i64 %v5999 to ptr
  %ld6001 = load i64, ptr %p6000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6001, ptr %slot844, align 8
  %v6002 = load i64, ptr %slot844, align 8
  %v6003 = load i64, ptr %slot72, align 8
  %p6004 = inttoptr i64 %v6003 to ptr
  store i64 %v6002, ptr %p6004, align 8, !alias.scope !3, !noalias !4
  %v6005 = load i64, ptr %slot73, align 8
  %p6006 = inttoptr i64 %v6005 to ptr
  store i64 0, ptr %p6006, align 8, !alias.scope !3, !noalias !4
  %v6007 = load i64, ptr %slot76, align 8
  store i64 %v6007, ptr %slot845, align 8
  %v6008 = load i64, ptr %slot845, align 8
  %p6009 = inttoptr i64 %v6008 to ptr
  call void @llvm.memset.p0.i64(ptr %p6009, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !144
  %v6010 = load i64, ptr %slot33, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  store i32 1, ptr %p6011, align 4, !alias.scope !3, !noalias !4
  %v6012 = load i64, ptr %slot89, align 8
  store i64 %v6012, ptr %slot846, align 8
  %v6013 = load i64, ptr %slot68, align 8
  %p6014 = inttoptr i64 %v6013 to ptr
  %ld6015 = load i64, ptr %p6014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6015, ptr %slot847, align 8
  %v6016 = load i64, ptr %slot845, align 8
  %p6018 = inttoptr i64 %v6016 to ptr
  %gep6019 = getelementptr i8, ptr %p6018, i64 0
  %op6017 = ptrtoint ptr %gep6019 to i64
  store i64 %op6017, ptr %slot848, align 8
  %v6020 = load i64, ptr %slot68, align 8
  %p6021 = inttoptr i64 %v6020 to ptr
  %ld6022 = load i64, ptr %p6021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6022, ptr %slot849, align 8
  %v6023 = load i64, ptr %slot23, align 8
  %p6024 = inttoptr i64 %v6023 to ptr
  %ld6025 = load i32, ptr %p6024, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6025, ptr %slot850, align 8
  %v6026 = load i64, ptr %slot24, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  %ld6028 = load i32, ptr %p6027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6028, ptr %slot851, align 8
  %v6029 = load i32, ptr %slot851, align 8
  %op6030 = and i32 %v6029, 24
  store i32 %op6030, ptr %slot851, align 8
  %v6031 = load i32, ptr %slot851, align 8
  %cmp6032 = icmp eq i32 %v6031, 0
  %cv6033 = zext i1 %cmp6032 to i32
  store i32 %cv6033, ptr %slot852, align 8
  %v6034 = load i32, ptr %slot850, align 8
  %v6035 = load i32, ptr %slot852, align 8
  %op6036 = and i32 %v6034, %v6035
  store i32 %op6036, ptr %slot853, align 8
  %v6037 = load i32, ptr %slot853, align 8
  %cv6038 = zext i32 %v6037 to i64
  %cond6039 = icmp ne i64 %cv6038, 0
  br i1 %cond6039, label %bb_rctake1048, label %bb_rccopy1048
bb_rctake1048:
  %v6040 = load i64, ptr %slot42, align 8
  store i64 %v6040, ptr %slot854, align 8
  %v6041 = load i64, ptr %slot89, align 8
  store i64 %v6041, ptr %slot855, align 8
  %v6042 = load i64, ptr %slot849, align 8
  %v6043 = load i64, ptr %slot854, align 8
  %op6044 = sub i64 %v6042, %v6043
  store i64 %op6044, ptr %slot856, align 8
  %v6045 = load i64, ptr %slot854, align 8
  %v6046 = load i64, ptr %slot849, align 8
  %op6047 = sub i64 %v6045, %v6046
  store i64 %op6047, ptr %slot857, align 8
  %v6048 = load i64, ptr %slot856, align 8
  %cmp6049 = icmp ult i64 %v6048, 48
  %cv6050 = zext i1 %cmp6049 to i32
  store i32 %cv6050, ptr %slot858, align 8
  %v6051 = load i64, ptr %slot857, align 8
  %cmp6052 = icmp ult i64 %v6051, 48
  %cv6053 = zext i1 %cmp6052 to i32
  store i32 %cv6053, ptr %slot859, align 8
  %v6054 = load i32, ptr %slot858, align 8
  %v6055 = load i32, ptr %slot859, align 8
  %op6056 = or i32 %v6054, %v6055
  store i32 %op6056, ptr %slot860, align 8
  %v6057 = load i32, ptr %slot860, align 8
  %cv6058 = zext i32 %v6057 to i64
  %cond6059 = icmp ne i64 %cv6058, 0
  br i1 %cond6059, label %bb_rcmoveslow1057, label %bb_rcmovecheck1057
bb_rcmovecheck1057:
  %v6060 = load i64, ptr %slot849, align 8
  %op6061 = add i64 %v6060, 16
  store i64 %op6061, ptr %slot861, align 8
  %v6062 = load i64, ptr %slot861, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  %ld6064 = load i64, ptr %p6063, align 8
  store i64 %ld6064, ptr %slot862, align 8
  %v6065 = load i64, ptr %slot862, align 8
  %cmp6066 = icmp ne i64 %v6065, 0
  %cv6067 = zext i1 %cmp6066 to i32
  store i32 %cv6067, ptr %slot863, align 8
  %v6068 = load i32, ptr %slot863, align 8
  %cv6069 = zext i32 %v6068 to i64
  %cond6070 = icmp ne i64 %cv6069, 0
  br i1 %cond6070, label %bb_rcmoveheader1065, label %bb_rcmovenext1065
bb_rcmoveheader1065:
  %v6071 = load i64, ptr %slot862, align 8
  %op6072 = sub i64 %v6071, 16
  store i64 %op6072, ptr %slot864, align 8
  %v6073 = load i64, ptr %slot862, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  %rgep6075 = getelementptr i8, ptr %p6074, i64 -16
  %ld6076 = load i64, ptr %rgep6075, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6076, ptr %slot865, align 8
  %v6077 = load i64, ptr %slot865, align 8
  %op6078 = and i64 %v6077, 5764607523034234881
  store i64 %op6078, ptr %slot866, align 8
  %v6079 = load i64, ptr %slot866, align 8
  %cmp6080 = icmp ne i64 %v6079, 0
  %cv6081 = zext i1 %cmp6080 to i32
  store i32 %cv6081, ptr %slot867, align 8
  %v6082 = load i32, ptr %slot867, align 8
  %cv6083 = zext i32 %v6082 to i64
  %cond6084 = icmp ne i64 %cv6083, 0
  br i1 %cond6084, label %bb_rcmoveslow1057, label %bb_rcmovenext1065
bb_rcmovenext1065:
  %v6085 = load i64, ptr %slot849, align 8
  %op6086 = add i64 %v6085, 24
  store i64 %op6086, ptr %slot868, align 8
  %v6087 = load i64, ptr %slot868, align 8
  %p6088 = inttoptr i64 %v6087 to ptr
  %ld6089 = load i64, ptr %p6088, align 8
  store i64 %ld6089, ptr %slot869, align 8
  %v6090 = load i64, ptr %slot869, align 8
  %cmp6091 = icmp ne i64 %v6090, 0
  %cv6092 = zext i1 %cmp6091 to i32
  store i32 %cv6092, ptr %slot870, align 8
  %v6093 = load i32, ptr %slot870, align 8
  %cv6094 = zext i32 %v6093 to i64
  %cond6095 = icmp ne i64 %cv6094, 0
  br i1 %cond6095, label %bb_rcmoveheader1073, label %bb_rcmovenext1073
bb_rcmoveheader1073:
  %v6096 = load i64, ptr %slot869, align 8
  %op6097 = sub i64 %v6096, 16
  store i64 %op6097, ptr %slot871, align 8
  %v6098 = load i64, ptr %slot869, align 8
  %p6099 = inttoptr i64 %v6098 to ptr
  %rgep6100 = getelementptr i8, ptr %p6099, i64 -16
  %ld6101 = load i64, ptr %rgep6100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6101, ptr %slot872, align 8
  %v6102 = load i64, ptr %slot872, align 8
  %op6103 = and i64 %v6102, 5764607523034234881
  store i64 %op6103, ptr %slot873, align 8
  %v6104 = load i64, ptr %slot873, align 8
  %cmp6105 = icmp ne i64 %v6104, 0
  %cv6106 = zext i1 %cmp6105 to i32
  store i32 %cv6106, ptr %slot874, align 8
  %v6107 = load i32, ptr %slot874, align 8
  %cv6108 = zext i32 %v6107 to i64
  %cond6109 = icmp ne i64 %cv6108, 0
  br i1 %cond6109, label %bb_rcmoveslow1057, label %bb_rcmovenext1073
bb_rcmovenext1073:
  %v6110 = load i64, ptr %slot849, align 8
  %op6111 = add i64 %v6110, 32
  store i64 %op6111, ptr %slot875, align 8
  %v6112 = load i64, ptr %slot875, align 8
  %p6113 = inttoptr i64 %v6112 to ptr
  %ld6114 = load i64, ptr %p6113, align 8
  store i64 %ld6114, ptr %slot876, align 8
  %v6115 = load i64, ptr %slot876, align 8
  %cmp6116 = icmp ne i64 %v6115, 0
  %cv6117 = zext i1 %cmp6116 to i32
  store i32 %cv6117, ptr %slot877, align 8
  %v6118 = load i32, ptr %slot877, align 8
  %cv6119 = zext i32 %v6118 to i64
  %cond6120 = icmp ne i64 %cv6119, 0
  br i1 %cond6120, label %bb_rcmoveheader1081, label %bb_rcmovenext1081
bb_rcmoveheader1081:
  %v6121 = load i64, ptr %slot876, align 8
  %op6122 = sub i64 %v6121, 16
  store i64 %op6122, ptr %slot878, align 8
  %v6123 = load i64, ptr %slot876, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  %rgep6125 = getelementptr i8, ptr %p6124, i64 -16
  %ld6126 = load i64, ptr %rgep6125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6126, ptr %slot879, align 8
  %v6127 = load i64, ptr %slot879, align 8
  %op6128 = and i64 %v6127, 5764607523034234881
  store i64 %op6128, ptr %slot880, align 8
  %v6129 = load i64, ptr %slot880, align 8
  %cmp6130 = icmp ne i64 %v6129, 0
  %cv6131 = zext i1 %cmp6130 to i32
  store i32 %cv6131, ptr %slot881, align 8
  %v6132 = load i32, ptr %slot881, align 8
  %cv6133 = zext i32 %v6132 to i64
  %cond6134 = icmp ne i64 %cv6133, 0
  br i1 %cond6134, label %bb_rcmoveslow1057, label %bb_rcmovenext1081
bb_rcmovenext1081:
  %v6135 = load i64, ptr %slot849, align 8
  %v6136 = load i64, ptr %slot854, align 8
  %p6137 = inttoptr i64 %v6135 to ptr
  %p6138 = inttoptr i64 %v6136 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6138, ptr %p6137, i64 48, i1 false)
  %v6139 = load i64, ptr %slot849, align 8
  %p6140 = inttoptr i64 %v6139 to ptr
  store i64 0, ptr %p6140, align 8
  %v6141 = load i64, ptr %slot849, align 8
  %op6142 = add i64 %v6141, 8
  store i64 %op6142, ptr %slot882, align 8
  %v6143 = load i64, ptr %slot882, align 8
  %p6144 = inttoptr i64 %v6143 to ptr
  store i64 0, ptr %p6144, align 8
  %v6145 = load i64, ptr %slot849, align 8
  %op6146 = add i64 %v6145, 16
  store i64 %op6146, ptr %slot883, align 8
  %v6147 = load i64, ptr %slot883, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  store i64 0, ptr %p6148, align 8
  %v6149 = load i64, ptr %slot849, align 8
  %op6150 = add i64 %v6149, 24
  store i64 %op6150, ptr %slot884, align 8
  %v6151 = load i64, ptr %slot884, align 8
  %p6152 = inttoptr i64 %v6151 to ptr
  store i64 0, ptr %p6152, align 8
  %v6153 = load i64, ptr %slot849, align 8
  %op6154 = add i64 %v6153, 32
  store i64 %op6154, ptr %slot885, align 8
  %v6155 = load i64, ptr %slot885, align 8
  %p6156 = inttoptr i64 %v6155 to ptr
  store i64 0, ptr %p6156, align 8
  %v6157 = load i64, ptr %slot849, align 8
  %op6158 = add i64 %v6157, 40
  store i64 %op6158, ptr %slot886, align 8
  %v6159 = load i64, ptr %slot886, align 8
  %p6160 = inttoptr i64 %v6159 to ptr
  store i64 0, ptr %p6160, align 8
  br label %bb_rcmoved1057
bb_rcmoveslow1057:
  %v6161 = load i64, ptr %slot88, align 8
  %v6162 = load i64, ptr %slot854, align 8
  %v6163 = load i64, ptr %slot849, align 8
  %v6164 = load i64, ptr %slot855, align 8
  %cv6165 = trunc i64 %v6164 to i32
  %call6166 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v6161, i64 %v6162, i64 %v6163, i32 %cv6165) nomerge, !dbg !144
  store i32 %call6166, ptr %slot887, align 8
  %v6167 = load i32, ptr %slot887, align 8
  %cv6168 = zext i32 %v6167 to i64
  %cond6169 = icmp ne i64 %cv6168, 0
  br i1 %cond6169, label %bb_rcsuccess1093, label %bb_rcfailure1093
bb_rcfailure1093:
  %v6170 = load i64, ptr %slot88, align 8
  %p6171 = inttoptr i64 %v6170 to ptr
  %call6172 = call i32 @myl_rc_take_failure(ptr %p6171) nomerge, !dbg !144
  store i32 %call6172, ptr %slot888, align 8
  %v6173 = load i64, ptr %slot1, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %v6175 = load i32, ptr %slot888, align 8
  %call6176 = call i32 @myl_qbe_rc_status(ptr %p6174, i32 %v6175) nomerge, !dbg !144
  store i32 %call6176, ptr %slot889, align 8
  br label %bb_failure
bb_rcsuccess1093:
  br label %bb_rcmoved1057
bb_rcmoved1057:
  %v6177 = load i64, ptr %slot23, align 8
  %p6178 = inttoptr i64 %v6177 to ptr
  store i32 0, ptr %p6178, align 4, !alias.scope !3, !noalias !4
  %v6179 = load i64, ptr %slot32, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  store i32 2, ptr %p6180, align 4, !alias.scope !3, !noalias !4
  %v6181 = load i64, ptr %slot31, align 8
  %p6182 = inttoptr i64 %v6181 to ptr
  store i32 1, ptr %p6182, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1048
bb_rccopy1048:
  %v6183 = load i64, ptr %slot42, align 8
  store i64 %v6183, ptr %slot890, align 8
  %v6184 = load i64, ptr %slot89, align 8
  store i64 %v6184, ptr %slot891, align 8
  %v6185 = load i64, ptr %slot88, align 8
  %v6186 = load i64, ptr %slot890, align 8
  %v6187 = load i64, ptr %slot849, align 8
  %v6188 = load i64, ptr %slot891, align 8
  %cv6189 = trunc i64 %v6188 to i32
  %call6190 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v6185, i64 %v6186, i64 %v6187, i32 %cv6189) nomerge, !dbg !144
  store i32 %call6190, ptr %slot892, align 8
  %v6191 = load i32, ptr %slot892, align 8
  %cv6192 = zext i32 %v6191 to i64
  %cond6193 = icmp ne i64 %cv6192, 0
  br i1 %cond6193, label %bb_rcsuccess1102, label %bb_rcfailure1102
bb_rcfailure1102:
  %v6194 = load i64, ptr %slot88, align 8
  %p6195 = inttoptr i64 %v6194 to ptr
  %call6196 = call i32 @myl_rc_take_failure(ptr %p6195) nomerge, !dbg !144
  store i32 %call6196, ptr %slot893, align 8
  %v6197 = load i64, ptr %slot1, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  %v6199 = load i32, ptr %slot893, align 8
  %call6200 = call i32 @myl_qbe_rc_status(ptr %p6198, i32 %v6199) nomerge, !dbg !144
  store i32 %call6200, ptr %slot894, align 8
  br label %bb_failure
bb_rcsuccess1102:
  %v6201 = load i64, ptr %slot32, align 8
  %p6202 = inttoptr i64 %v6201 to ptr
  store i32 2, ptr %p6202, align 4, !alias.scope !3, !noalias !4
  %v6203 = load i64, ptr %slot31, align 8
  %p6204 = inttoptr i64 %v6203 to ptr
  store i32 1, ptr %p6204, align 4, !alias.scope !3, !noalias !4
  %v6205 = load i64, ptr %slot23, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  %ld6207 = load i32, ptr %p6206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6207, ptr %slot895, align 8
  %v6208 = load i32, ptr %slot895, align 8
  %cv6209 = zext i32 %v6208 to i64
  %cond6210 = icmp ne i64 %cv6209, 0
  br i1 %cond6210, label %bb_rcslotdrop1109, label %bb_rcslotdone1109
bb_rcslotdrop1109:
  %v6211 = load i64, ptr %slot23, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  store i32 0, ptr %p6212, align 4, !alias.scope !3, !noalias !4
  %v6213 = load i64, ptr %slot34, align 8
  store i64 %v6213, ptr %slot896, align 8
  %v6214 = load i64, ptr %slot24, align 8
  %p6215 = inttoptr i64 %v6214 to ptr
  %ld6216 = load i32, ptr %p6215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6216, ptr %slot897, align 8
  %v6217 = load i32, ptr %slot897, align 8
  %op6218 = and i32 %v6217, 28
  store i32 %op6218, ptr %slot898, align 8
  %v6219 = load i32, ptr %slot898, align 8
  %cv6220 = zext i32 %v6219 to i64
  %cond6221 = icmp ne i64 %cv6220, 0
  br i1 %cond6221, label %bb_rcslotrole1109, label %bb_rcslotowner1109
bb_rcslotrole1109:
  %v6222 = load i64, ptr %slot88, align 8
  store i64 %v6222, ptr %slot899, align 8
  %v6223 = load i64, ptr %slot899, align 8
  %v6224 = load i64, ptr %slot896, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v6223, i64 %v6224) nomerge, !dbg !144
  br label %bb_rcslotdone1109
bb_rcslotowner1109:
  %v6225 = load i64, ptr %slot88, align 8
  store i64 %v6225, ptr %slot900, align 8
  %v6226 = load i64, ptr %slot900, align 8
  %v6227 = load i64, ptr %slot896, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v6226, i64 %v6227) nomerge, !dbg !144
  br label %bb_rcslotdone1109
bb_rcslotdone1109:
  br label %bb_rcprepared1048
bb_rcprepared1048:
  %v6228 = load i64, ptr %slot42, align 8
  store i64 %v6228, ptr %slot901, align 8
  %v6229 = load i64, ptr %slot901, align 8
  %v6230 = load i64, ptr %slot848, align 8
  %p6231 = inttoptr i64 %v6229 to ptr
  %p6232 = inttoptr i64 %v6230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6232, ptr %p6231, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v6233 = load i64, ptr %slot31, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  store i32 0, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  %v6235 = load i64, ptr %slot69, align 8
  store i64 %v6235, ptr %slot902, align 8
  %v6236 = load i64, ptr %slot845, align 8
  %p6238 = inttoptr i64 %v6236 to ptr
  %gep6239 = getelementptr i8, ptr %p6238, i64 48
  %op6237 = ptrtoint ptr %gep6239 to i64
  store i64 %op6237, ptr %slot903, align 8
  %v6240 = load i64, ptr %slot902, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %ld6242 = load i64, ptr %p6241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6242, ptr %slot904, align 8
  %v6243 = load i64, ptr %slot904, align 8
  %v6244 = load i64, ptr %slot903, align 8
  %p6245 = inttoptr i64 %v6244 to ptr
  store i64 %v6243, ptr %p6245, align 8, !alias.scope !3, !noalias !4
  %v6246 = load i64, ptr %slot70, align 8
  %p6247 = inttoptr i64 %v6246 to ptr
  %ld6248 = load i64, ptr %p6247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6248, ptr %slot905, align 8
  %v6249 = load i64, ptr %slot845, align 8
  %p6251 = inttoptr i64 %v6249 to ptr
  %gep6252 = getelementptr i8, ptr %p6251, i64 56
  %op6250 = ptrtoint ptr %gep6252 to i64
  store i64 %op6250, ptr %slot906, align 8
  %v6253 = load i64, ptr %slot905, align 8
  %v6254 = load i64, ptr %slot906, align 8
  %p6255 = inttoptr i64 %v6253 to ptr
  %p6256 = inttoptr i64 %v6254 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6256, ptr %p6255, i64 4, i1 false)
  %v6257 = load i64, ptr %slot71, align 8
  %p6258 = inttoptr i64 %v6257 to ptr
  %ld6259 = load i64, ptr %p6258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6259, ptr %slot907, align 8
  %v6260 = load i64, ptr %slot907, align 8
  %v6261 = load i64, ptr %slot40, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  store i64 %v6260, ptr %p6262, align 8, !alias.scope !3, !noalias !4
  %v6263 = load i64, ptr %slot40, align 8
  store i64 %v6263, ptr %slot908, align 8
  %v6264 = load i64, ptr %slot845, align 8
  %p6266 = inttoptr i64 %v6264 to ptr
  %gep6267 = getelementptr i8, ptr %p6266, i64 64
  %op6265 = ptrtoint ptr %gep6267 to i64
  store i64 %op6265, ptr %slot909, align 8
  %v6268 = load i64, ptr %slot71, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  %ld6270 = load i64, ptr %p6269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6270, ptr %slot910, align 8
  %v6271 = load i64, ptr %slot910, align 8
  %v6272 = load i64, ptr %slot40, align 8
  %p6273 = inttoptr i64 %v6272 to ptr
  store i64 %v6271, ptr %p6273, align 8, !alias.scope !3, !noalias !4
  %v6274 = load i64, ptr %slot40, align 8
  store i64 %v6274, ptr %slot911, align 8
  %v6275 = load i64, ptr %slot27, align 8
  %p6276 = inttoptr i64 %v6275 to ptr
  %ld6277 = load i32, ptr %p6276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6277, ptr %slot912, align 8
  %v6278 = load i64, ptr %slot28, align 8
  %p6279 = inttoptr i64 %v6278 to ptr
  %ld6280 = load i32, ptr %p6279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6280, ptr %slot913, align 8
  %v6281 = load i32, ptr %slot913, align 8
  %op6282 = and i32 %v6281, 24
  store i32 %op6282, ptr %slot913, align 8
  %v6283 = load i32, ptr %slot913, align 8
  %cmp6284 = icmp eq i32 %v6283, 0
  %cv6285 = zext i1 %cmp6284 to i32
  store i32 %cv6285, ptr %slot914, align 8
  %v6286 = load i32, ptr %slot912, align 8
  %v6287 = load i32, ptr %slot914, align 8
  %op6288 = and i32 %v6286, %v6287
  store i32 %op6288, ptr %slot915, align 8
  %v6289 = load i32, ptr %slot915, align 8
  %cv6290 = zext i32 %v6289 to i64
  %cond6291 = icmp ne i64 %cv6290, 0
  br i1 %cond6291, label %bb_rctake1128, label %bb_rccopy1128
bb_rctake1128:
  %v6292 = load i64, ptr %slot42, align 8
  store i64 %v6292, ptr %slot916, align 8
  %v6293 = load i64, ptr %slot89, align 8
  store i64 %v6293, ptr %slot917, align 8
  %v6294 = load i64, ptr %slot911, align 8
  %v6295 = load i64, ptr %slot916, align 8
  %op6296 = sub i64 %v6294, %v6295
  store i64 %op6296, ptr %slot918, align 8
  %v6297 = load i64, ptr %slot916, align 8
  %v6298 = load i64, ptr %slot911, align 8
  %op6299 = sub i64 %v6297, %v6298
  store i64 %op6299, ptr %slot919, align 8
  %v6300 = load i64, ptr %slot918, align 8
  %cmp6301 = icmp ult i64 %v6300, 8
  %cv6302 = zext i1 %cmp6301 to i32
  store i32 %cv6302, ptr %slot920, align 8
  %v6303 = load i64, ptr %slot919, align 8
  %cmp6304 = icmp ult i64 %v6303, 8
  %cv6305 = zext i1 %cmp6304 to i32
  store i32 %cv6305, ptr %slot921, align 8
  %v6306 = load i32, ptr %slot920, align 8
  %v6307 = load i32, ptr %slot921, align 8
  %op6308 = or i32 %v6306, %v6307
  store i32 %op6308, ptr %slot922, align 8
  %v6309 = load i32, ptr %slot922, align 8
  %cv6310 = zext i32 %v6309 to i64
  %cond6311 = icmp ne i64 %cv6310, 0
  br i1 %cond6311, label %bb_rcmoveslow1137, label %bb_rcmovecheck1137
bb_rcmovecheck1137:
  %v6312 = load i64, ptr %slot911, align 8
  %p6314 = inttoptr i64 %v6312 to ptr
  %gep6315 = getelementptr i8, ptr %p6314, i64 0
  %op6313 = ptrtoint ptr %gep6315 to i64
  store i64 %op6313, ptr %slot923, align 8
  %v6316 = load i64, ptr %slot923, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  %ld6318 = load i64, ptr %p6317, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6318, ptr %slot924, align 8
  %v6319 = load i64, ptr %slot924, align 8
  %cmp6320 = icmp ne i64 %v6319, 0
  %cv6321 = zext i1 %cmp6320 to i32
  store i32 %cv6321, ptr %slot925, align 8
  %v6322 = load i32, ptr %slot925, align 8
  %cv6323 = zext i32 %v6322 to i64
  %cond6324 = icmp ne i64 %cv6323, 0
  br i1 %cond6324, label %bb_rcmoveheader1145, label %bb_rcmovenext1145
bb_rcmoveheader1145:
  %v6325 = load i64, ptr %slot924, align 8
  %op6326 = sub i64 %v6325, 16
  store i64 %op6326, ptr %slot926, align 8
  %v6327 = load i64, ptr %slot924, align 8
  %p6328 = inttoptr i64 %v6327 to ptr
  %rgep6329 = getelementptr i8, ptr %p6328, i64 -16
  %ld6330 = load i64, ptr %rgep6329, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6330, ptr %slot927, align 8
  %v6331 = load i64, ptr %slot927, align 8
  %op6332 = and i64 %v6331, 5764607523034234881
  store i64 %op6332, ptr %slot928, align 8
  %v6333 = load i64, ptr %slot928, align 8
  %cmp6334 = icmp ne i64 %v6333, 0
  %cv6335 = zext i1 %cmp6334 to i32
  store i32 %cv6335, ptr %slot929, align 8
  %v6336 = load i32, ptr %slot929, align 8
  %cv6337 = zext i32 %v6336 to i64
  %cond6338 = icmp ne i64 %cv6337, 0
  br i1 %cond6338, label %bb_rcmoveslow1137, label %bb_rcmovenext1145
bb_rcmovenext1145:
  %v6339 = load i64, ptr %slot911, align 8
  %v6340 = load i64, ptr %slot916, align 8
  %p6341 = inttoptr i64 %v6339 to ptr
  %p6342 = inttoptr i64 %v6340 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6342, ptr %p6341, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6343 = load i64, ptr %slot911, align 8
  %p6344 = inttoptr i64 %v6343 to ptr
  store i64 0, ptr %p6344, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1137
bb_rcmoveslow1137:
  %v6345 = load i64, ptr %slot88, align 8
  %v6346 = load i64, ptr %slot916, align 8
  %v6347 = load i64, ptr %slot911, align 8
  %v6348 = load i64, ptr %slot917, align 8
  %cv6349 = trunc i64 %v6348 to i32
  %call6350 = call i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64 %v6345, i64 %v6346, i64 %v6347, i32 %cv6349) nomerge, !dbg !144
  store i32 %call6350, ptr %slot930, align 8
  %v6351 = load i32, ptr %slot930, align 8
  %cv6352 = zext i32 %v6351 to i64
  %cond6353 = icmp ne i64 %cv6352, 0
  br i1 %cond6353, label %bb_rcsuccess1152, label %bb_rcfailure1152
bb_rcfailure1152:
  %v6354 = load i64, ptr %slot88, align 8
  %p6355 = inttoptr i64 %v6354 to ptr
  %call6356 = call i32 @myl_rc_take_failure(ptr %p6355) nomerge, !dbg !144
  store i32 %call6356, ptr %slot931, align 8
  %v6357 = load i64, ptr %slot1, align 8
  %p6358 = inttoptr i64 %v6357 to ptr
  %v6359 = load i32, ptr %slot931, align 8
  %call6360 = call i32 @myl_qbe_rc_status(ptr %p6358, i32 %v6359) nomerge, !dbg !144
  store i32 %call6360, ptr %slot932, align 8
  br label %bb_failure
bb_rcsuccess1152:
  br label %bb_rcmoved1137
bb_rcmoved1137:
  %v6361 = load i64, ptr %slot27, align 8
  %p6362 = inttoptr i64 %v6361 to ptr
  store i32 0, ptr %p6362, align 4, !alias.scope !3, !noalias !4
  %v6363 = load i64, ptr %slot32, align 8
  %p6364 = inttoptr i64 %v6363 to ptr
  store i32 2, ptr %p6364, align 4, !alias.scope !3, !noalias !4
  %v6365 = load i64, ptr %slot31, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  store i32 1, ptr %p6366, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1128
bb_rccopy1128:
  %v6367 = load i64, ptr %slot42, align 8
  store i64 %v6367, ptr %slot933, align 8
  %v6368 = load i64, ptr %slot89, align 8
  store i64 %v6368, ptr %slot934, align 8
  %v6369 = load i64, ptr %slot911, align 8
  %p6370 = inttoptr i64 %v6369 to ptr
  %ld6371 = load i64, ptr %p6370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6371, ptr %slot935, align 8
  %v6372 = load i64, ptr %slot935, align 8
  %cmp6373 = icmp ne i64 %v6372, 0
  %cv6374 = zext i1 %cmp6373 to i32
  store i32 %cv6374, ptr %slot936, align 8
  %v6375 = load i32, ptr %slot936, align 8
  %cv6376 = zext i32 %v6375 to i64
  %cond6377 = icmp ne i64 %cv6376, 0
  br i1 %cond6377, label %bb_rcgnn1161, label %bb_rcgplain1161
bb_rcgnn1161:
  %v6378 = load i64, ptr %slot935, align 8
  %op6379 = sub i64 %v6378, 16
  store i64 %op6379, ptr %slot937, align 8
  %v6380 = load i64, ptr %slot935, align 8
  %p6381 = inttoptr i64 %v6380 to ptr
  %rgep6382 = getelementptr i8, ptr %p6381, i64 -16
  %ld6383 = load i64, ptr %rgep6382, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6383, ptr %slot938, align 8
  %v6384 = load i64, ptr %slot938, align 8
  %op6385 = and i64 %v6384, 4611686018427387906
  store i64 %op6385, ptr %slot939, align 8
  %v6386 = load i64, ptr %slot939, align 8
  %cmp6387 = icmp ne i64 %v6386, 0
  %cv6388 = zext i1 %cmp6387 to i32
  store i32 %cv6388, ptr %slot940, align 8
  %v6389 = load i32, ptr %slot940, align 8
  %cv6390 = zext i32 %v6389 to i64
  %cond6391 = icmp ne i64 %cv6390, 0
  br i1 %cond6391, label %bb_rcgspecial1161, label %bb_rcginc1161
bb_rcginc1161:
  %v6392 = load i64, ptr %slot935, align 8
  %op6393 = sub i64 %v6392, 32
  store i64 %op6393, ptr %slot941, align 8
  %v6394 = load i64, ptr %slot935, align 8
  %p6395 = inttoptr i64 %v6394 to ptr
  %rgep6396 = getelementptr i8, ptr %p6395, i64 -32
  %ld6397 = load i64, ptr %rgep6396, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6397, ptr %slot942, align 8
  %v6398 = load i64, ptr %slot942, align 8
  %op6399 = add i64 %v6398, 1
  store i64 %op6399, ptr %slot943, align 8
  %v6400 = load i64, ptr %slot943, align 8
  %cmp6401 = icmp eq i64 %v6400, 0
  %cv6402 = zext i1 %cmp6401 to i32
  store i32 %cv6402, ptr %slot944, align 8
  %v6403 = load i32, ptr %slot944, align 8
  %cv6404 = zext i32 %v6403 to i64
  %cond6405 = icmp ne i64 %cv6404, 0
  br i1 %cond6405, label %bb_rcglimit1161, label %bb_rcgcapacity1161
bb_rcglimit1161:
  %v6406 = load i64, ptr %slot1, align 8
  %p6407 = inttoptr i64 %v6406 to ptr
  %call6408 = call i32 @myl_qbe_rc_status(ptr %p6407, i32 2) nomerge, !dbg !144
  store i32 %call6408, ptr %slot945, align 8
  br label %bb_failure
bb_rcgcapacity1161:
  %v6409 = load i64, ptr %slot943, align 8
  %v6410 = load i64, ptr %slot935, align 8
  %p6411 = inttoptr i64 %v6410 to ptr
  %rgep6412 = getelementptr i8, ptr %p6411, i64 -32
  store i64 %v6409, ptr %rgep6412, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1161
bb_rcgspecial1161:
  %v6413 = load i64, ptr %slot938, align 8
  %op6414 = and i64 %v6413, 4611686018427387904
  store i64 %op6414, ptr %slot946, align 8
  %v6415 = load i64, ptr %slot946, align 8
  %cmp6416 = icmp ne i64 %v6415, 0
  %cv6417 = zext i1 %cmp6416 to i32
  store i32 %cv6417, ptr %slot947, align 8
  %v6418 = load i32, ptr %slot947, align 8
  %cv6419 = zext i32 %v6418 to i64
  %cond6420 = icmp ne i64 %cv6419, 0
  br i1 %cond6420, label %bb_rcgslow1161, label %bb_rcgplain1161
bb_rcgslow1161:
  %v6421 = load i64, ptr %slot88, align 8
  %v6422 = load i64, ptr %slot933, align 8
  %v6423 = load i64, ptr %slot911, align 8
  %v6424 = load i64, ptr %slot934, align 8
  %cv6425 = trunc i64 %v6424 to i32
  %call6426 = call i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_retain(i64 %v6421, i64 %v6422, i64 %v6423, i32 %cv6425) nomerge, !dbg !144
  store i32 %call6426, ptr %slot948, align 8
  %v6427 = load i32, ptr %slot948, align 8
  %cv6428 = zext i32 %v6427 to i64
  %cond6429 = icmp ne i64 %cv6428, 0
  br i1 %cond6429, label %bb_rcsuccess1175, label %bb_rcfailure1175
bb_rcfailure1175:
  %v6430 = load i64, ptr %slot88, align 8
  %p6431 = inttoptr i64 %v6430 to ptr
  %call6432 = call i32 @myl_rc_take_failure(ptr %p6431) nomerge, !dbg !144
  store i32 %call6432, ptr %slot949, align 8
  %v6433 = load i64, ptr %slot1, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  %v6435 = load i32, ptr %slot949, align 8
  %call6436 = call i32 @myl_qbe_rc_status(ptr %p6434, i32 %v6435) nomerge, !dbg !144
  store i32 %call6436, ptr %slot950, align 8
  br label %bb_failure
bb_rcsuccess1175:
  br label %bb_rcgdone1161
bb_rcgplain1161:
  %v6437 = load i64, ptr %slot935, align 8
  %v6438 = load i64, ptr %slot933, align 8
  %p6439 = inttoptr i64 %v6438 to ptr
  store i64 %v6437, ptr %p6439, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1161
bb_rcgdone1161:
  %v6440 = load i64, ptr %slot32, align 8
  %p6441 = inttoptr i64 %v6440 to ptr
  store i32 2, ptr %p6441, align 4, !alias.scope !3, !noalias !4
  %v6442 = load i64, ptr %slot31, align 8
  %p6443 = inttoptr i64 %v6442 to ptr
  store i32 1, ptr %p6443, align 4, !alias.scope !3, !noalias !4
  %v6444 = load i64, ptr %slot27, align 8
  %p6445 = inttoptr i64 %v6444 to ptr
  %ld6446 = load i32, ptr %p6445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6446, ptr %slot951, align 8
  %v6447 = load i32, ptr %slot951, align 8
  %cv6448 = zext i32 %v6447 to i64
  %cond6449 = icmp ne i64 %cv6448, 0
  br i1 %cond6449, label %bb_rcslotdrop1182, label %bb_rcslotdone1182
bb_rcslotdrop1182:
  %v6450 = load i64, ptr %slot27, align 8
  %p6451 = inttoptr i64 %v6450 to ptr
  store i32 0, ptr %p6451, align 4, !alias.scope !3, !noalias !4
  %v6452 = load i64, ptr %slot36, align 8
  store i64 %v6452, ptr %slot952, align 8
  %v6453 = load i64, ptr %slot28, align 8
  %p6454 = inttoptr i64 %v6453 to ptr
  %ld6455 = load i32, ptr %p6454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6455, ptr %slot953, align 8
  %v6456 = load i32, ptr %slot953, align 8
  %op6457 = and i32 %v6456, 28
  store i32 %op6457, ptr %slot954, align 8
  %v6458 = load i32, ptr %slot954, align 8
  %cv6459 = zext i32 %v6458 to i64
  %cond6460 = icmp ne i64 %cv6459, 0
  br i1 %cond6460, label %bb_rcslotrole1182, label %bb_rcslotowner1182
bb_rcslotrole1182:
  %v6461 = load i64, ptr %slot88, align 8
  store i64 %v6461, ptr %slot955, align 8
  %v6462 = load i64, ptr %slot952, align 8
  %p6463 = inttoptr i64 %v6462 to ptr
  %ld6464 = load i64, ptr %p6463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6464, ptr %slot956, align 8
  %v6465 = load i64, ptr %slot956, align 8
  %cmp6466 = icmp ne i64 %v6465, 0
  %cv6467 = zext i1 %cmp6466 to i32
  store i32 %cv6467, ptr %slot957, align 8
  %v6468 = load i32, ptr %slot957, align 8
  %cv6469 = zext i32 %v6468 to i64
  %cond6470 = icmp ne i64 %cv6469, 0
  br i1 %cond6470, label %bb_rcgnn1198, label %bb_rcgdone1198
bb_rcgnn1198:
  %v6471 = load i64, ptr %slot956, align 8
  %op6472 = sub i64 %v6471, 16
  store i64 %op6472, ptr %slot958, align 8
  %v6473 = load i64, ptr %slot956, align 8
  %p6474 = inttoptr i64 %v6473 to ptr
  %rgep6475 = getelementptr i8, ptr %p6474, i64 -16
  %ld6476 = load i64, ptr %rgep6475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6476, ptr %slot959, align 8
  %v6477 = load i64, ptr %slot959, align 8
  %op6478 = and i64 %v6477, 4611686018427387906
  store i64 %op6478, ptr %slot960, align 8
  %v6479 = load i64, ptr %slot960, align 8
  %cmp6480 = icmp ne i64 %v6479, 0
  %cv6481 = zext i1 %cmp6480 to i32
  store i32 %cv6481, ptr %slot961, align 8
  %v6482 = load i32, ptr %slot961, align 8
  %cv6483 = zext i32 %v6482 to i64
  %cond6484 = icmp ne i64 %cv6483, 0
  br i1 %cond6484, label %bb_rcgclear1198, label %bb_rcgcounted1198
bb_rcgcounted1198:
  %v6485 = load i64, ptr %slot956, align 8
  %op6486 = sub i64 %v6485, 24
  store i64 %op6486, ptr %slot962, align 8
  %v6487 = load i64, ptr %slot956, align 8
  %p6488 = inttoptr i64 %v6487 to ptr
  %rgep6489 = getelementptr i8, ptr %p6488, i64 -24
  %ld6490 = load i64, ptr %rgep6489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6490, ptr %slot963, align 8
  %v6491 = load i64, ptr %slot963, align 8
  %op6492 = sub i64 %v6491, 1
  store i64 %op6492, ptr %slot964, align 8
  %v6493 = load i64, ptr %slot964, align 8
  %cmp6494 = icmp eq i64 %v6493, 0
  %cv6495 = zext i1 %cmp6494 to i32
  store i32 %cv6495, ptr %slot965, align 8
  %v6496 = load i32, ptr %slot965, align 8
  %cv6497 = zext i32 %v6496 to i64
  %cond6498 = icmp ne i64 %cv6497, 0
  br i1 %cond6498, label %bb_rcglast1198, label %bb_rcgdec1198
bb_rcglast1198:
  %v6499 = load i64, ptr %slot956, align 8
  %op6500 = sub i64 %v6499, 32
  store i64 %op6500, ptr %slot966, align 8
  %v6501 = load i64, ptr %slot956, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  %rgep6503 = getelementptr i8, ptr %p6502, i64 -32
  %ld6504 = load i64, ptr %rgep6503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6504, ptr %slot967, align 8
  %v6505 = load i64, ptr %slot967, align 8
  %cmp6506 = icmp ne i64 %v6505, 0
  %cv6507 = zext i1 %cmp6506 to i32
  store i32 %cv6507, ptr %slot968, align 8
  %v6508 = load i32, ptr %slot968, align 8
  %cv6509 = zext i32 %v6508 to i64
  %cond6510 = icmp ne i64 %cv6509, 0
  br i1 %cond6510, label %bb_rcgdec1198, label %bb_rcgslow1198
bb_rcgslow1198:
  %v6511 = load i64, ptr %slot955, align 8
  %v6512 = load i64, ptr %slot952, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v6511, i64 %v6512) nomerge, !dbg !144
  br label %bb_rcgdone1198
bb_rcgdec1198:
  %v6513 = load i64, ptr %slot964, align 8
  %v6514 = load i64, ptr %slot956, align 8
  %p6515 = inttoptr i64 %v6514 to ptr
  %rgep6516 = getelementptr i8, ptr %p6515, i64 -24
  store i64 %v6513, ptr %rgep6516, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1198
bb_rcgclear1198:
  %v6517 = load i64, ptr %slot952, align 8
  %p6518 = inttoptr i64 %v6517 to ptr
  store i64 0, ptr %p6518, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1198
bb_rcgdone1198:
  br label %bb_rcslotdone1182
bb_rcslotowner1182:
  %v6519 = load i64, ptr %slot88, align 8
  store i64 %v6519, ptr %slot969, align 8
  %v6520 = load i64, ptr %slot952, align 8
  %p6521 = inttoptr i64 %v6520 to ptr
  %ld6522 = load i64, ptr %p6521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6522, ptr %slot970, align 8
  %v6523 = load i64, ptr %slot970, align 8
  %cmp6524 = icmp ne i64 %v6523, 0
  %cv6525 = zext i1 %cmp6524 to i32
  store i32 %cv6525, ptr %slot971, align 8
  %v6526 = load i32, ptr %slot971, align 8
  %cv6527 = zext i32 %v6526 to i64
  %cond6528 = icmp ne i64 %cv6527, 0
  br i1 %cond6528, label %bb_rcgnn1213, label %bb_rcgdone1213
bb_rcgnn1213:
  %v6529 = load i64, ptr %slot970, align 8
  %op6530 = sub i64 %v6529, 16
  store i64 %op6530, ptr %slot972, align 8
  %v6531 = load i64, ptr %slot970, align 8
  %p6532 = inttoptr i64 %v6531 to ptr
  %rgep6533 = getelementptr i8, ptr %p6532, i64 -16
  %ld6534 = load i64, ptr %rgep6533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6534, ptr %slot973, align 8
  %v6535 = load i64, ptr %slot973, align 8
  %op6536 = and i64 %v6535, 4611686018427387906
  store i64 %op6536, ptr %slot974, align 8
  %v6537 = load i64, ptr %slot974, align 8
  %cmp6538 = icmp ne i64 %v6537, 0
  %cv6539 = zext i1 %cmp6538 to i32
  store i32 %cv6539, ptr %slot975, align 8
  %v6540 = load i32, ptr %slot975, align 8
  %cv6541 = zext i32 %v6540 to i64
  %cond6542 = icmp ne i64 %cv6541, 0
  br i1 %cond6542, label %bb_rcgclear1213, label %bb_rcgcounted1213
bb_rcgcounted1213:
  %v6543 = load i64, ptr %slot970, align 8
  %op6544 = sub i64 %v6543, 32
  store i64 %op6544, ptr %slot976, align 8
  %v6545 = load i64, ptr %slot970, align 8
  %p6546 = inttoptr i64 %v6545 to ptr
  %rgep6547 = getelementptr i8, ptr %p6546, i64 -32
  %ld6548 = load i64, ptr %rgep6547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6548, ptr %slot977, align 8
  %v6549 = load i64, ptr %slot977, align 8
  %op6550 = sub i64 %v6549, 1
  store i64 %op6550, ptr %slot978, align 8
  %v6551 = load i64, ptr %slot978, align 8
  %cmp6552 = icmp eq i64 %v6551, 0
  %cv6553 = zext i1 %cmp6552 to i32
  store i32 %cv6553, ptr %slot979, align 8
  %v6554 = load i32, ptr %slot979, align 8
  %cv6555 = zext i32 %v6554 to i64
  %cond6556 = icmp ne i64 %cv6555, 0
  br i1 %cond6556, label %bb_rcglast1213, label %bb_rcgdec1213
bb_rcglast1213:
  %v6557 = load i64, ptr %slot970, align 8
  %op6558 = sub i64 %v6557, 24
  store i64 %op6558, ptr %slot980, align 8
  %v6559 = load i64, ptr %slot970, align 8
  %p6560 = inttoptr i64 %v6559 to ptr
  %rgep6561 = getelementptr i8, ptr %p6560, i64 -24
  %ld6562 = load i64, ptr %rgep6561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6562, ptr %slot981, align 8
  %v6563 = load i64, ptr %slot981, align 8
  %cmp6564 = icmp ne i64 %v6563, 0
  %cv6565 = zext i1 %cmp6564 to i32
  store i32 %cv6565, ptr %slot982, align 8
  %v6566 = load i32, ptr %slot982, align 8
  %cv6567 = zext i32 %v6566 to i64
  %cond6568 = icmp ne i64 %cv6567, 0
  br i1 %cond6568, label %bb_rcgdec1213, label %bb_rcgslow1213
bb_rcgslow1213:
  %v6569 = load i64, ptr %slot969, align 8
  %v6570 = load i64, ptr %slot952, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v6569, i64 %v6570) nomerge, !dbg !144
  br label %bb_rcgdone1213
bb_rcgdec1213:
  %v6571 = load i64, ptr %slot978, align 8
  %v6572 = load i64, ptr %slot970, align 8
  %p6573 = inttoptr i64 %v6572 to ptr
  %rgep6574 = getelementptr i8, ptr %p6573, i64 -32
  store i64 %v6571, ptr %rgep6574, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1213
bb_rcgclear1213:
  %v6575 = load i64, ptr %slot952, align 8
  %p6576 = inttoptr i64 %v6575 to ptr
  store i64 0, ptr %p6576, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1213
bb_rcgdone1213:
  br label %bb_rcslotdone1182
bb_rcslotdone1182:
  br label %bb_rcprepared1128
bb_rcprepared1128:
  %v6577 = load i64, ptr %slot42, align 8
  store i64 %v6577, ptr %slot983, align 8
  %v6578 = load i64, ptr %slot983, align 8
  %v6579 = load i64, ptr %slot909, align 8
  %p6580 = inttoptr i64 %v6578 to ptr
  %p6581 = inttoptr i64 %v6579 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6581, ptr %p6580, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6582 = load i64, ptr %slot31, align 8
  %p6583 = inttoptr i64 %v6582 to ptr
  store i32 0, ptr %p6583, align 4, !alias.scope !3, !noalias !4
  %v6584 = load i64, ptr %slot72, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  %ld6586 = load i64, ptr %p6585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6586, ptr %slot984, align 8
  %v6587 = load i64, ptr %slot984, align 8
  %v6588 = load i64, ptr %slot41, align 8
  %p6589 = inttoptr i64 %v6588 to ptr
  store i64 %v6587, ptr %p6589, align 8, !alias.scope !3, !noalias !4
  %v6590 = load i64, ptr %slot41, align 8
  store i64 %v6590, ptr %slot985, align 8
  %v6591 = load i64, ptr %slot845, align 8
  %p6593 = inttoptr i64 %v6591 to ptr
  %gep6594 = getelementptr i8, ptr %p6593, i64 72
  %op6592 = ptrtoint ptr %gep6594 to i64
  store i64 %op6592, ptr %slot986, align 8
  %v6595 = load i64, ptr %slot72, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %ld6597 = load i64, ptr %p6596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6597, ptr %slot987, align 8
  %v6598 = load i64, ptr %slot987, align 8
  %v6599 = load i64, ptr %slot41, align 8
  %p6600 = inttoptr i64 %v6599 to ptr
  store i64 %v6598, ptr %p6600, align 8, !alias.scope !3, !noalias !4
  %v6601 = load i64, ptr %slot41, align 8
  store i64 %v6601, ptr %slot988, align 8
  %v6602 = load i64, ptr %slot29, align 8
  %p6603 = inttoptr i64 %v6602 to ptr
  %ld6604 = load i32, ptr %p6603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6604, ptr %slot989, align 8
  %v6605 = load i64, ptr %slot30, align 8
  %p6606 = inttoptr i64 %v6605 to ptr
  %ld6607 = load i32, ptr %p6606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6607, ptr %slot990, align 8
  %v6608 = load i32, ptr %slot990, align 8
  %op6609 = and i32 %v6608, 24
  store i32 %op6609, ptr %slot990, align 8
  %v6610 = load i32, ptr %slot990, align 8
  %cmp6611 = icmp eq i32 %v6610, 0
  %cv6612 = zext i1 %cmp6611 to i32
  store i32 %cv6612, ptr %slot991, align 8
  %v6613 = load i32, ptr %slot989, align 8
  %v6614 = load i32, ptr %slot991, align 8
  %op6615 = and i32 %v6613, %v6614
  store i32 %op6615, ptr %slot992, align 8
  %v6616 = load i32, ptr %slot992, align 8
  %cv6617 = zext i32 %v6616 to i64
  %cond6618 = icmp ne i64 %cv6617, 0
  br i1 %cond6618, label %bb_rctake1224, label %bb_rccopy1224
bb_rctake1224:
  %v6619 = load i64, ptr %slot42, align 8
  store i64 %v6619, ptr %slot993, align 8
  %v6620 = load i64, ptr %slot89, align 8
  store i64 %v6620, ptr %slot994, align 8
  %v6621 = load i64, ptr %slot988, align 8
  %v6622 = load i64, ptr %slot993, align 8
  %op6623 = sub i64 %v6621, %v6622
  store i64 %op6623, ptr %slot995, align 8
  %v6624 = load i64, ptr %slot993, align 8
  %v6625 = load i64, ptr %slot988, align 8
  %op6626 = sub i64 %v6624, %v6625
  store i64 %op6626, ptr %slot996, align 8
  %v6627 = load i64, ptr %slot995, align 8
  %cmp6628 = icmp ult i64 %v6627, 8
  %cv6629 = zext i1 %cmp6628 to i32
  store i32 %cv6629, ptr %slot997, align 8
  %v6630 = load i64, ptr %slot996, align 8
  %cmp6631 = icmp ult i64 %v6630, 8
  %cv6632 = zext i1 %cmp6631 to i32
  store i32 %cv6632, ptr %slot998, align 8
  %v6633 = load i32, ptr %slot997, align 8
  %v6634 = load i32, ptr %slot998, align 8
  %op6635 = or i32 %v6633, %v6634
  store i32 %op6635, ptr %slot999, align 8
  %v6636 = load i32, ptr %slot999, align 8
  %cv6637 = zext i32 %v6636 to i64
  %cond6638 = icmp ne i64 %cv6637, 0
  br i1 %cond6638, label %bb_rcmoveslow1233, label %bb_rcmovecheck1233
bb_rcmovecheck1233:
  %v6639 = load i64, ptr %slot988, align 8
  %p6641 = inttoptr i64 %v6639 to ptr
  %gep6642 = getelementptr i8, ptr %p6641, i64 0
  %op6640 = ptrtoint ptr %gep6642 to i64
  store i64 %op6640, ptr %slot1000, align 8
  %v6643 = load i64, ptr %slot1000, align 8
  %p6644 = inttoptr i64 %v6643 to ptr
  %ld6645 = load i64, ptr %p6644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6645, ptr %slot1001, align 8
  %v6646 = load i64, ptr %slot1001, align 8
  %cmp6647 = icmp ne i64 %v6646, 0
  %cv6648 = zext i1 %cmp6647 to i32
  store i32 %cv6648, ptr %slot1002, align 8
  %v6649 = load i32, ptr %slot1002, align 8
  %cv6650 = zext i32 %v6649 to i64
  %cond6651 = icmp ne i64 %cv6650, 0
  br i1 %cond6651, label %bb_rcmoveheader1241, label %bb_rcmovenext1241
bb_rcmoveheader1241:
  %v6652 = load i64, ptr %slot1001, align 8
  %op6653 = sub i64 %v6652, 16
  store i64 %op6653, ptr %slot1003, align 8
  %v6654 = load i64, ptr %slot1001, align 8
  %p6655 = inttoptr i64 %v6654 to ptr
  %rgep6656 = getelementptr i8, ptr %p6655, i64 -16
  %ld6657 = load i64, ptr %rgep6656, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6657, ptr %slot1004, align 8
  %v6658 = load i64, ptr %slot1004, align 8
  %op6659 = and i64 %v6658, 5764607523034234881
  store i64 %op6659, ptr %slot1005, align 8
  %v6660 = load i64, ptr %slot1005, align 8
  %cmp6661 = icmp ne i64 %v6660, 0
  %cv6662 = zext i1 %cmp6661 to i32
  store i32 %cv6662, ptr %slot1006, align 8
  %v6663 = load i32, ptr %slot1006, align 8
  %cv6664 = zext i32 %v6663 to i64
  %cond6665 = icmp ne i64 %cv6664, 0
  br i1 %cond6665, label %bb_rcmoveslow1233, label %bb_rcmovenext1241
bb_rcmovenext1241:
  %v6666 = load i64, ptr %slot988, align 8
  %v6667 = load i64, ptr %slot993, align 8
  %p6668 = inttoptr i64 %v6666 to ptr
  %p6669 = inttoptr i64 %v6667 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6669, ptr %p6668, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6670 = load i64, ptr %slot988, align 8
  %p6671 = inttoptr i64 %v6670 to ptr
  store i64 0, ptr %p6671, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1233
bb_rcmoveslow1233:
  %v6672 = load i64, ptr %slot88, align 8
  %v6673 = load i64, ptr %slot993, align 8
  %v6674 = load i64, ptr %slot988, align 8
  %v6675 = load i64, ptr %slot994, align 8
  %cv6676 = trunc i64 %v6675 to i32
  %call6677 = call i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_take(i64 %v6672, i64 %v6673, i64 %v6674, i32 %cv6676) nomerge, !dbg !144
  store i32 %call6677, ptr %slot1007, align 8
  %v6678 = load i32, ptr %slot1007, align 8
  %cv6679 = zext i32 %v6678 to i64
  %cond6680 = icmp ne i64 %cv6679, 0
  br i1 %cond6680, label %bb_rcsuccess1248, label %bb_rcfailure1248
bb_rcfailure1248:
  %v6681 = load i64, ptr %slot88, align 8
  %p6682 = inttoptr i64 %v6681 to ptr
  %call6683 = call i32 @myl_rc_take_failure(ptr %p6682) nomerge, !dbg !144
  store i32 %call6683, ptr %slot1008, align 8
  %v6684 = load i64, ptr %slot1, align 8
  %p6685 = inttoptr i64 %v6684 to ptr
  %v6686 = load i32, ptr %slot1008, align 8
  %call6687 = call i32 @myl_qbe_rc_status(ptr %p6685, i32 %v6686) nomerge, !dbg !144
  store i32 %call6687, ptr %slot1009, align 8
  br label %bb_failure
bb_rcsuccess1248:
  br label %bb_rcmoved1233
bb_rcmoved1233:
  %v6688 = load i64, ptr %slot29, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  store i32 0, ptr %p6689, align 4, !alias.scope !3, !noalias !4
  %v6690 = load i64, ptr %slot32, align 8
  %p6691 = inttoptr i64 %v6690 to ptr
  store i32 2, ptr %p6691, align 4, !alias.scope !3, !noalias !4
  %v6692 = load i64, ptr %slot31, align 8
  %p6693 = inttoptr i64 %v6692 to ptr
  store i32 1, ptr %p6693, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1224
bb_rccopy1224:
  %v6694 = load i64, ptr %slot42, align 8
  store i64 %v6694, ptr %slot1010, align 8
  %v6695 = load i64, ptr %slot89, align 8
  store i64 %v6695, ptr %slot1011, align 8
  %v6696 = load i64, ptr %slot988, align 8
  %p6697 = inttoptr i64 %v6696 to ptr
  %ld6698 = load i64, ptr %p6697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6698, ptr %slot1012, align 8
  %v6699 = load i64, ptr %slot1012, align 8
  %cmp6700 = icmp ne i64 %v6699, 0
  %cv6701 = zext i1 %cmp6700 to i32
  store i32 %cv6701, ptr %slot1013, align 8
  %v6702 = load i32, ptr %slot1013, align 8
  %cv6703 = zext i32 %v6702 to i64
  %cond6704 = icmp ne i64 %cv6703, 0
  br i1 %cond6704, label %bb_rcgnn1257, label %bb_rcgplain1257
bb_rcgnn1257:
  %v6705 = load i64, ptr %slot1012, align 8
  %op6706 = sub i64 %v6705, 16
  store i64 %op6706, ptr %slot1014, align 8
  %v6707 = load i64, ptr %slot1012, align 8
  %p6708 = inttoptr i64 %v6707 to ptr
  %rgep6709 = getelementptr i8, ptr %p6708, i64 -16
  %ld6710 = load i64, ptr %rgep6709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6710, ptr %slot1015, align 8
  %v6711 = load i64, ptr %slot1015, align 8
  %op6712 = and i64 %v6711, 4611686018427387906
  store i64 %op6712, ptr %slot1016, align 8
  %v6713 = load i64, ptr %slot1016, align 8
  %cmp6714 = icmp ne i64 %v6713, 0
  %cv6715 = zext i1 %cmp6714 to i32
  store i32 %cv6715, ptr %slot1017, align 8
  %v6716 = load i32, ptr %slot1017, align 8
  %cv6717 = zext i32 %v6716 to i64
  %cond6718 = icmp ne i64 %cv6717, 0
  br i1 %cond6718, label %bb_rcgspecial1257, label %bb_rcginc1257
bb_rcginc1257:
  %v6719 = load i64, ptr %slot1012, align 8
  %op6720 = sub i64 %v6719, 32
  store i64 %op6720, ptr %slot1018, align 8
  %v6721 = load i64, ptr %slot1012, align 8
  %p6722 = inttoptr i64 %v6721 to ptr
  %rgep6723 = getelementptr i8, ptr %p6722, i64 -32
  %ld6724 = load i64, ptr %rgep6723, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6724, ptr %slot1019, align 8
  %v6725 = load i64, ptr %slot1019, align 8
  %op6726 = add i64 %v6725, 1
  store i64 %op6726, ptr %slot1020, align 8
  %v6727 = load i64, ptr %slot1020, align 8
  %cmp6728 = icmp eq i64 %v6727, 0
  %cv6729 = zext i1 %cmp6728 to i32
  store i32 %cv6729, ptr %slot1021, align 8
  %v6730 = load i32, ptr %slot1021, align 8
  %cv6731 = zext i32 %v6730 to i64
  %cond6732 = icmp ne i64 %cv6731, 0
  br i1 %cond6732, label %bb_rcglimit1257, label %bb_rcgcapacity1257
bb_rcglimit1257:
  %v6733 = load i64, ptr %slot1, align 8
  %p6734 = inttoptr i64 %v6733 to ptr
  %call6735 = call i32 @myl_qbe_rc_status(ptr %p6734, i32 2) nomerge, !dbg !144
  store i32 %call6735, ptr %slot1022, align 8
  br label %bb_failure
bb_rcgcapacity1257:
  %v6736 = load i64, ptr %slot1020, align 8
  %v6737 = load i64, ptr %slot1012, align 8
  %p6738 = inttoptr i64 %v6737 to ptr
  %rgep6739 = getelementptr i8, ptr %p6738, i64 -32
  store i64 %v6736, ptr %rgep6739, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1257
bb_rcgspecial1257:
  %v6740 = load i64, ptr %slot1015, align 8
  %op6741 = and i64 %v6740, 4611686018427387904
  store i64 %op6741, ptr %slot1023, align 8
  %v6742 = load i64, ptr %slot1023, align 8
  %cmp6743 = icmp ne i64 %v6742, 0
  %cv6744 = zext i1 %cmp6743 to i32
  store i32 %cv6744, ptr %slot1024, align 8
  %v6745 = load i32, ptr %slot1024, align 8
  %cv6746 = zext i32 %v6745 to i64
  %cond6747 = icmp ne i64 %cv6746, 0
  br i1 %cond6747, label %bb_rcgslow1257, label %bb_rcgplain1257
bb_rcgslow1257:
  %v6748 = load i64, ptr %slot88, align 8
  %v6749 = load i64, ptr %slot1010, align 8
  %v6750 = load i64, ptr %slot988, align 8
  %v6751 = load i64, ptr %slot1011, align 8
  %cv6752 = trunc i64 %v6751 to i32
  %call6753 = call i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_retain(i64 %v6748, i64 %v6749, i64 %v6750, i32 %cv6752) nomerge, !dbg !144
  store i32 %call6753, ptr %slot1025, align 8
  %v6754 = load i32, ptr %slot1025, align 8
  %cv6755 = zext i32 %v6754 to i64
  %cond6756 = icmp ne i64 %cv6755, 0
  br i1 %cond6756, label %bb_rcsuccess1271, label %bb_rcfailure1271
bb_rcfailure1271:
  %v6757 = load i64, ptr %slot88, align 8
  %p6758 = inttoptr i64 %v6757 to ptr
  %call6759 = call i32 @myl_rc_take_failure(ptr %p6758) nomerge, !dbg !144
  store i32 %call6759, ptr %slot1026, align 8
  %v6760 = load i64, ptr %slot1, align 8
  %p6761 = inttoptr i64 %v6760 to ptr
  %v6762 = load i32, ptr %slot1026, align 8
  %call6763 = call i32 @myl_qbe_rc_status(ptr %p6761, i32 %v6762) nomerge, !dbg !144
  store i32 %call6763, ptr %slot1027, align 8
  br label %bb_failure
bb_rcsuccess1271:
  br label %bb_rcgdone1257
bb_rcgplain1257:
  %v6764 = load i64, ptr %slot1012, align 8
  %v6765 = load i64, ptr %slot1010, align 8
  %p6766 = inttoptr i64 %v6765 to ptr
  store i64 %v6764, ptr %p6766, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1257
bb_rcgdone1257:
  %v6767 = load i64, ptr %slot32, align 8
  %p6768 = inttoptr i64 %v6767 to ptr
  store i32 2, ptr %p6768, align 4, !alias.scope !3, !noalias !4
  %v6769 = load i64, ptr %slot31, align 8
  %p6770 = inttoptr i64 %v6769 to ptr
  store i32 1, ptr %p6770, align 4, !alias.scope !3, !noalias !4
  %v6771 = load i64, ptr %slot29, align 8
  %p6772 = inttoptr i64 %v6771 to ptr
  %ld6773 = load i32, ptr %p6772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6773, ptr %slot1028, align 8
  %v6774 = load i32, ptr %slot1028, align 8
  %cv6775 = zext i32 %v6774 to i64
  %cond6776 = icmp ne i64 %cv6775, 0
  br i1 %cond6776, label %bb_rcslotdrop1278, label %bb_rcslotdone1278
bb_rcslotdrop1278:
  %v6777 = load i64, ptr %slot29, align 8
  %p6778 = inttoptr i64 %v6777 to ptr
  store i32 0, ptr %p6778, align 4, !alias.scope !3, !noalias !4
  %v6779 = load i64, ptr %slot37, align 8
  store i64 %v6779, ptr %slot1029, align 8
  %v6780 = load i64, ptr %slot30, align 8
  %p6781 = inttoptr i64 %v6780 to ptr
  %ld6782 = load i32, ptr %p6781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6782, ptr %slot1030, align 8
  %v6783 = load i32, ptr %slot1030, align 8
  %op6784 = and i32 %v6783, 28
  store i32 %op6784, ptr %slot1031, align 8
  %v6785 = load i32, ptr %slot1031, align 8
  %cv6786 = zext i32 %v6785 to i64
  %cond6787 = icmp ne i64 %cv6786, 0
  br i1 %cond6787, label %bb_rcslotrole1278, label %bb_rcslotowner1278
bb_rcslotrole1278:
  %v6788 = load i64, ptr %slot88, align 8
  store i64 %v6788, ptr %slot1032, align 8
  %v6789 = load i64, ptr %slot1029, align 8
  %p6790 = inttoptr i64 %v6789 to ptr
  %ld6791 = load i64, ptr %p6790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6791, ptr %slot1033, align 8
  %v6792 = load i64, ptr %slot1033, align 8
  %cmp6793 = icmp ne i64 %v6792, 0
  %cv6794 = zext i1 %cmp6793 to i32
  store i32 %cv6794, ptr %slot1034, align 8
  %v6795 = load i32, ptr %slot1034, align 8
  %cv6796 = zext i32 %v6795 to i64
  %cond6797 = icmp ne i64 %cv6796, 0
  br i1 %cond6797, label %bb_rcgnn1294, label %bb_rcgdone1294
bb_rcgnn1294:
  %v6798 = load i64, ptr %slot1033, align 8
  %op6799 = sub i64 %v6798, 16
  store i64 %op6799, ptr %slot1035, align 8
  %v6800 = load i64, ptr %slot1033, align 8
  %p6801 = inttoptr i64 %v6800 to ptr
  %rgep6802 = getelementptr i8, ptr %p6801, i64 -16
  %ld6803 = load i64, ptr %rgep6802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6803, ptr %slot1036, align 8
  %v6804 = load i64, ptr %slot1036, align 8
  %op6805 = and i64 %v6804, 4611686018427387906
  store i64 %op6805, ptr %slot1037, align 8
  %v6806 = load i64, ptr %slot1037, align 8
  %cmp6807 = icmp ne i64 %v6806, 0
  %cv6808 = zext i1 %cmp6807 to i32
  store i32 %cv6808, ptr %slot1038, align 8
  %v6809 = load i32, ptr %slot1038, align 8
  %cv6810 = zext i32 %v6809 to i64
  %cond6811 = icmp ne i64 %cv6810, 0
  br i1 %cond6811, label %bb_rcgclear1294, label %bb_rcgcounted1294
bb_rcgcounted1294:
  %v6812 = load i64, ptr %slot1033, align 8
  %op6813 = sub i64 %v6812, 24
  store i64 %op6813, ptr %slot1039, align 8
  %v6814 = load i64, ptr %slot1033, align 8
  %p6815 = inttoptr i64 %v6814 to ptr
  %rgep6816 = getelementptr i8, ptr %p6815, i64 -24
  %ld6817 = load i64, ptr %rgep6816, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6817, ptr %slot1040, align 8
  %v6818 = load i64, ptr %slot1040, align 8
  %op6819 = sub i64 %v6818, 1
  store i64 %op6819, ptr %slot1041, align 8
  %v6820 = load i64, ptr %slot1041, align 8
  %cmp6821 = icmp eq i64 %v6820, 0
  %cv6822 = zext i1 %cmp6821 to i32
  store i32 %cv6822, ptr %slot1042, align 8
  %v6823 = load i32, ptr %slot1042, align 8
  %cv6824 = zext i32 %v6823 to i64
  %cond6825 = icmp ne i64 %cv6824, 0
  br i1 %cond6825, label %bb_rcglast1294, label %bb_rcgdec1294
bb_rcglast1294:
  %v6826 = load i64, ptr %slot1033, align 8
  %op6827 = sub i64 %v6826, 32
  store i64 %op6827, ptr %slot1043, align 8
  %v6828 = load i64, ptr %slot1033, align 8
  %p6829 = inttoptr i64 %v6828 to ptr
  %rgep6830 = getelementptr i8, ptr %p6829, i64 -32
  %ld6831 = load i64, ptr %rgep6830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6831, ptr %slot1044, align 8
  %v6832 = load i64, ptr %slot1044, align 8
  %cmp6833 = icmp ne i64 %v6832, 0
  %cv6834 = zext i1 %cmp6833 to i32
  store i32 %cv6834, ptr %slot1045, align 8
  %v6835 = load i32, ptr %slot1045, align 8
  %cv6836 = zext i32 %v6835 to i64
  %cond6837 = icmp ne i64 %cv6836, 0
  br i1 %cond6837, label %bb_rcgdec1294, label %bb_rcgslow1294
bb_rcgslow1294:
  %v6838 = load i64, ptr %slot1032, align 8
  %v6839 = load i64, ptr %slot1029, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v6838, i64 %v6839) nomerge, !dbg !144
  br label %bb_rcgdone1294
bb_rcgdec1294:
  %v6840 = load i64, ptr %slot1041, align 8
  %v6841 = load i64, ptr %slot1033, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  %rgep6843 = getelementptr i8, ptr %p6842, i64 -24
  store i64 %v6840, ptr %rgep6843, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1294
bb_rcgclear1294:
  %v6844 = load i64, ptr %slot1029, align 8
  %p6845 = inttoptr i64 %v6844 to ptr
  store i64 0, ptr %p6845, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1294
bb_rcgdone1294:
  br label %bb_rcslotdone1278
bb_rcslotowner1278:
  %v6846 = load i64, ptr %slot88, align 8
  store i64 %v6846, ptr %slot1046, align 8
  %v6847 = load i64, ptr %slot1029, align 8
  %p6848 = inttoptr i64 %v6847 to ptr
  %ld6849 = load i64, ptr %p6848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6849, ptr %slot1047, align 8
  %v6850 = load i64, ptr %slot1047, align 8
  %cmp6851 = icmp ne i64 %v6850, 0
  %cv6852 = zext i1 %cmp6851 to i32
  store i32 %cv6852, ptr %slot1048, align 8
  %v6853 = load i32, ptr %slot1048, align 8
  %cv6854 = zext i32 %v6853 to i64
  %cond6855 = icmp ne i64 %cv6854, 0
  br i1 %cond6855, label %bb_rcgnn1309, label %bb_rcgdone1309
bb_rcgnn1309:
  %v6856 = load i64, ptr %slot1047, align 8
  %op6857 = sub i64 %v6856, 16
  store i64 %op6857, ptr %slot1049, align 8
  %v6858 = load i64, ptr %slot1047, align 8
  %p6859 = inttoptr i64 %v6858 to ptr
  %rgep6860 = getelementptr i8, ptr %p6859, i64 -16
  %ld6861 = load i64, ptr %rgep6860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6861, ptr %slot1050, align 8
  %v6862 = load i64, ptr %slot1050, align 8
  %op6863 = and i64 %v6862, 4611686018427387906
  store i64 %op6863, ptr %slot1051, align 8
  %v6864 = load i64, ptr %slot1051, align 8
  %cmp6865 = icmp ne i64 %v6864, 0
  %cv6866 = zext i1 %cmp6865 to i32
  store i32 %cv6866, ptr %slot1052, align 8
  %v6867 = load i32, ptr %slot1052, align 8
  %cv6868 = zext i32 %v6867 to i64
  %cond6869 = icmp ne i64 %cv6868, 0
  br i1 %cond6869, label %bb_rcgclear1309, label %bb_rcgcounted1309
bb_rcgcounted1309:
  %v6870 = load i64, ptr %slot1047, align 8
  %op6871 = sub i64 %v6870, 32
  store i64 %op6871, ptr %slot1053, align 8
  %v6872 = load i64, ptr %slot1047, align 8
  %p6873 = inttoptr i64 %v6872 to ptr
  %rgep6874 = getelementptr i8, ptr %p6873, i64 -32
  %ld6875 = load i64, ptr %rgep6874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6875, ptr %slot1054, align 8
  %v6876 = load i64, ptr %slot1054, align 8
  %op6877 = sub i64 %v6876, 1
  store i64 %op6877, ptr %slot1055, align 8
  %v6878 = load i64, ptr %slot1055, align 8
  %cmp6879 = icmp eq i64 %v6878, 0
  %cv6880 = zext i1 %cmp6879 to i32
  store i32 %cv6880, ptr %slot1056, align 8
  %v6881 = load i32, ptr %slot1056, align 8
  %cv6882 = zext i32 %v6881 to i64
  %cond6883 = icmp ne i64 %cv6882, 0
  br i1 %cond6883, label %bb_rcglast1309, label %bb_rcgdec1309
bb_rcglast1309:
  %v6884 = load i64, ptr %slot1047, align 8
  %op6885 = sub i64 %v6884, 24
  store i64 %op6885, ptr %slot1057, align 8
  %v6886 = load i64, ptr %slot1047, align 8
  %p6887 = inttoptr i64 %v6886 to ptr
  %rgep6888 = getelementptr i8, ptr %p6887, i64 -24
  %ld6889 = load i64, ptr %rgep6888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6889, ptr %slot1058, align 8
  %v6890 = load i64, ptr %slot1058, align 8
  %cmp6891 = icmp ne i64 %v6890, 0
  %cv6892 = zext i1 %cmp6891 to i32
  store i32 %cv6892, ptr %slot1059, align 8
  %v6893 = load i32, ptr %slot1059, align 8
  %cv6894 = zext i32 %v6893 to i64
  %cond6895 = icmp ne i64 %cv6894, 0
  br i1 %cond6895, label %bb_rcgdec1309, label %bb_rcgslow1309
bb_rcgslow1309:
  %v6896 = load i64, ptr %slot1046, align 8
  %v6897 = load i64, ptr %slot1029, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v6896, i64 %v6897) nomerge, !dbg !144
  br label %bb_rcgdone1309
bb_rcgdec1309:
  %v6898 = load i64, ptr %slot1055, align 8
  %v6899 = load i64, ptr %slot1047, align 8
  %p6900 = inttoptr i64 %v6899 to ptr
  %rgep6901 = getelementptr i8, ptr %p6900, i64 -32
  store i64 %v6898, ptr %rgep6901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1309
bb_rcgclear1309:
  %v6902 = load i64, ptr %slot1029, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  store i64 0, ptr %p6903, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1309
bb_rcgdone1309:
  br label %bb_rcslotdone1278
bb_rcslotdone1278:
  br label %bb_rcprepared1224
bb_rcprepared1224:
  %v6904 = load i64, ptr %slot42, align 8
  store i64 %v6904, ptr %slot1060, align 8
  %v6905 = load i64, ptr %slot1060, align 8
  %v6906 = load i64, ptr %slot986, align 8
  %p6907 = inttoptr i64 %v6905 to ptr
  %p6908 = inttoptr i64 %v6906 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6908, ptr %p6907, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6909 = load i64, ptr %slot31, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  store i32 0, ptr %p6910, align 4, !alias.scope !3, !noalias !4
  %v6911 = load i64, ptr %slot73, align 8
  store i64 %v6911, ptr %slot1061, align 8
  %v6912 = load i64, ptr %slot845, align 8
  %p6914 = inttoptr i64 %v6912 to ptr
  %gep6915 = getelementptr i8, ptr %p6914, i64 80
  %op6913 = ptrtoint ptr %gep6915 to i64
  store i64 %op6913, ptr %slot1062, align 8
  %v6916 = load i64, ptr %slot1061, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i64, ptr %p6917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6918, ptr %slot1063, align 8
  %v6919 = load i64, ptr %slot1063, align 8
  %v6920 = load i64, ptr %slot1062, align 8
  %p6921 = inttoptr i64 %v6920 to ptr
  store i64 %v6919, ptr %p6921, align 8, !alias.scope !3, !noalias !4
  %v6922 = load i64, ptr %slot845, align 8
  %v6923 = load i64, ptr %slot68, align 8
  %p6924 = inttoptr i64 %v6923 to ptr
  store i64 %v6922, ptr %p6924, align 8, !alias.scope !3, !noalias !4
  %v6925 = load i64, ptr %slot68, align 8
  %p6926 = inttoptr i64 %v6925 to ptr
  %ld6927 = load i64, ptr %p6926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6927, ptr %slot1064, align 8
  %v6928 = load i64, ptr %slot34, align 8
  store i64 %v6928, ptr %slot1065, align 8
  %v6929 = load i64, ptr %slot1064, align 8
  %v6930 = load i64, ptr %slot1065, align 8
  %p6931 = inttoptr i64 %v6929 to ptr
  %p6932 = inttoptr i64 %v6930 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6932, ptr %p6931, i64 88, i1 false)
  %v6933 = load i64, ptr %slot24, align 8
  %p6934 = inttoptr i64 %v6933 to ptr
  store i32 2, ptr %p6934, align 4, !alias.scope !3, !noalias !4
  %v6935 = load i64, ptr %slot23, align 8
  %p6936 = inttoptr i64 %v6935 to ptr
  store i32 1, ptr %p6936, align 4, !alias.scope !3, !noalias !4
  %v6937 = load i64, ptr %slot1065, align 8
  %v6938 = load i64, ptr %slot68, align 8
  %p6939 = inttoptr i64 %v6938 to ptr
  store i64 %v6937, ptr %p6939, align 8, !alias.scope !3, !noalias !4
  %v6940 = load i64, ptr %slot68, align 8
  %p6941 = inttoptr i64 %v6940 to ptr
  %ld6942 = load i64, ptr %p6941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6942, ptr %slot1066, align 8
  %v6943 = load i64, ptr %slot42, align 8
  store i64 %v6943, ptr %slot1067, align 8
  %v6944 = load i64, ptr %slot89, align 8
  store i64 %v6944, ptr %slot1068, align 8
  %v6945 = load i64, ptr %slot88, align 8
  %v6946 = load i64, ptr %slot1067, align 8
  %v6947 = load i64, ptr %slot1066, align 8
  %v6948 = load i64, ptr %slot1068, align 8
  %cv6949 = trunc i64 %v6948 to i32
  %call6950 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v6945, i64 %v6946, i64 %v6947, i32 %cv6949) nomerge, !dbg !146
  store i32 %call6950, ptr %slot1069, align 8
  %v6951 = load i32, ptr %slot1069, align 8
  %cv6952 = zext i32 %v6951 to i64
  %cond6953 = icmp ne i64 %cv6952, 0
  br i1 %cond6953, label %bb_rcsuccess1326, label %bb_rcfailure1326
bb_rcfailure1326:
  %v6954 = load i64, ptr %slot88, align 8
  %p6955 = inttoptr i64 %v6954 to ptr
  %call6956 = call i32 @myl_rc_take_failure(ptr %p6955) nomerge, !dbg !146
  store i32 %call6956, ptr %slot1070, align 8
  %v6957 = load i64, ptr %slot1, align 8
  %p6958 = inttoptr i64 %v6957 to ptr
  %v6959 = load i32, ptr %slot1070, align 8
  %call6960 = call i32 @myl_qbe_rc_status(ptr %p6958, i32 %v6959) nomerge, !dbg !146
  store i32 %call6960, ptr %slot1071, align 8
  br label %bb_failure
bb_rcsuccess1326:
  %v6961 = load i64, ptr %slot23, align 8
  %p6962 = inttoptr i64 %v6961 to ptr
  store i32 0, ptr %p6962, align 4, !alias.scope !3, !noalias !4
  %v6963 = load i64, ptr %slot32, align 8
  %p6964 = inttoptr i64 %v6963 to ptr
  store i32 2, ptr %p6964, align 4, !alias.scope !3, !noalias !4
  %v6965 = load i64, ptr %slot31, align 8
  %p6966 = inttoptr i64 %v6965 to ptr
  store i32 1, ptr %p6966, align 4, !alias.scope !3, !noalias !4
  %v6967 = load i64, ptr %slot13, align 8
  %p6968 = inttoptr i64 %v6967 to ptr
  %ld6969 = load i32, ptr %p6968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6969, ptr %slot1072, align 8
  %v6970 = load i32, ptr %slot1072, align 8
  %cv6971 = zext i32 %v6970 to i64
  %cond6972 = icmp ne i64 %cv6971, 0
  br i1 %cond6972, label %bb_rcslotdrop1335, label %bb_rcslotdone1335
bb_rcslotdrop1335:
  %v6973 = load i64, ptr %slot13, align 8
  %p6974 = inttoptr i64 %v6973 to ptr
  store i32 0, ptr %p6974, align 4, !alias.scope !3, !noalias !4
  %v6975 = load i64, ptr %slot59, align 8
  store i64 %v6975, ptr %slot1073, align 8
  %v6976 = load i64, ptr %slot14, align 8
  %p6977 = inttoptr i64 %v6976 to ptr
  %ld6978 = load i32, ptr %p6977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6978, ptr %slot1074, align 8
  %v6979 = load i32, ptr %slot1074, align 8
  %op6980 = and i32 %v6979, 28
  store i32 %op6980, ptr %slot1075, align 8
  %v6981 = load i32, ptr %slot1075, align 8
  %cv6982 = zext i32 %v6981 to i64
  %cond6983 = icmp ne i64 %cv6982, 0
  br i1 %cond6983, label %bb_rcslotrole1335, label %bb_rcslotowner1335
bb_rcslotrole1335:
  %v6984 = load i64, ptr %slot88, align 8
  store i64 %v6984, ptr %slot1076, align 8
  %v6985 = load i64, ptr %slot1076, align 8
  %v6986 = load i64, ptr %slot1073, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6985, i64 %v6986) nomerge, !dbg !146
  br label %bb_rcslotdone1335
bb_rcslotowner1335:
  %v6987 = load i64, ptr %slot88, align 8
  store i64 %v6987, ptr %slot1077, align 8
  %v6988 = load i64, ptr %slot1077, align 8
  %v6989 = load i64, ptr %slot1073, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6988, i64 %v6989) nomerge, !dbg !146
  br label %bb_rcslotdone1335
bb_rcslotdone1335:
  %v6990 = load i64, ptr %slot59, align 8
  store i64 %v6990, ptr %slot1078, align 8
  %v6991 = load i64, ptr %slot42, align 8
  store i64 %v6991, ptr %slot1079, align 8
  %v6992 = load i64, ptr %slot1079, align 8
  %v6993 = load i64, ptr %slot1078, align 8
  %p6994 = inttoptr i64 %v6992 to ptr
  %p6995 = inttoptr i64 %v6993 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6995, ptr %p6994, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v6996 = load i64, ptr %slot31, align 8
  %p6997 = inttoptr i64 %v6996 to ptr
  store i32 0, ptr %p6997, align 4, !alias.scope !3, !noalias !4
  %v6998 = load i64, ptr %slot14, align 8
  %p6999 = inttoptr i64 %v6998 to ptr
  store i32 2, ptr %p6999, align 4, !alias.scope !3, !noalias !4
  %v7000 = load i64, ptr %slot32, align 8
  %p7001 = inttoptr i64 %v7000 to ptr
  %ld7002 = load i32, ptr %p7001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7002, ptr %slot1080, align 8
  %v7003 = load i32, ptr %slot1080, align 8
  %v7004 = load i64, ptr %slot14, align 8
  %p7005 = inttoptr i64 %v7004 to ptr
  store i32 %v7003, ptr %p7005, align 4, !alias.scope !3, !noalias !4
  %v7006 = load i64, ptr %slot13, align 8
  %p7007 = inttoptr i64 %v7006 to ptr
  store i32 1, ptr %p7007, align 4, !alias.scope !3, !noalias !4
  %v7008 = load i64, ptr %slot9, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  %ld7010 = load i32, ptr %p7009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7010, ptr %slot1081, align 8
  %v7011 = load i32, ptr %slot1081, align 8
  %cv7012 = zext i32 %v7011 to i64
  %cond7013 = icmp ne i64 %cv7012, 0
  br i1 %cond7013, label %bb_rcslotdrop1351, label %bb_rcslotdone1351
bb_rcslotdrop1351:
  %v7014 = load i64, ptr %slot9, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  store i32 0, ptr %p7015, align 4, !alias.scope !3, !noalias !4
  %v7016 = load i64, ptr %slot57, align 8
  store i64 %v7016, ptr %slot1082, align 8
  %v7017 = load i64, ptr %slot10, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  %ld7019 = load i32, ptr %p7018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7019, ptr %slot1083, align 8
  %v7020 = load i32, ptr %slot1083, align 8
  %op7021 = and i32 %v7020, 28
  store i32 %op7021, ptr %slot1084, align 8
  %v7022 = load i32, ptr %slot1084, align 8
  %cv7023 = zext i32 %v7022 to i64
  %cond7024 = icmp ne i64 %cv7023, 0
  br i1 %cond7024, label %bb_rcslotrole1351, label %bb_rcslotowner1351
bb_rcslotrole1351:
  %v7025 = load i64, ptr %slot88, align 8
  store i64 %v7025, ptr %slot1085, align 8
  %v7026 = load i64, ptr %slot1082, align 8
  %p7027 = inttoptr i64 %v7026 to ptr
  %ld7028 = load i64, ptr %p7027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7028, ptr %slot1086, align 8
  %v7029 = load i64, ptr %slot1086, align 8
  %cmp7030 = icmp ne i64 %v7029, 0
  %cv7031 = zext i1 %cmp7030 to i32
  store i32 %cv7031, ptr %slot1087, align 8
  %v7032 = load i32, ptr %slot1087, align 8
  %cv7033 = zext i32 %v7032 to i64
  %cond7034 = icmp ne i64 %cv7033, 0
  br i1 %cond7034, label %bb_rcgnn1367, label %bb_rcgdone1367
bb_rcgnn1367:
  %v7035 = load i64, ptr %slot1086, align 8
  %op7036 = sub i64 %v7035, 16
  store i64 %op7036, ptr %slot1088, align 8
  %v7037 = load i64, ptr %slot1086, align 8
  %p7038 = inttoptr i64 %v7037 to ptr
  %rgep7039 = getelementptr i8, ptr %p7038, i64 -16
  %ld7040 = load i64, ptr %rgep7039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7040, ptr %slot1089, align 8
  %v7041 = load i64, ptr %slot1089, align 8
  %op7042 = and i64 %v7041, 4611686018427387906
  store i64 %op7042, ptr %slot1090, align 8
  %v7043 = load i64, ptr %slot1090, align 8
  %cmp7044 = icmp ne i64 %v7043, 0
  %cv7045 = zext i1 %cmp7044 to i32
  store i32 %cv7045, ptr %slot1091, align 8
  %v7046 = load i32, ptr %slot1091, align 8
  %cv7047 = zext i32 %v7046 to i64
  %cond7048 = icmp ne i64 %cv7047, 0
  br i1 %cond7048, label %bb_rcgclear1367, label %bb_rcgcounted1367
bb_rcgcounted1367:
  %v7049 = load i64, ptr %slot1086, align 8
  %op7050 = sub i64 %v7049, 24
  store i64 %op7050, ptr %slot1092, align 8
  %v7051 = load i64, ptr %slot1086, align 8
  %p7052 = inttoptr i64 %v7051 to ptr
  %rgep7053 = getelementptr i8, ptr %p7052, i64 -24
  %ld7054 = load i64, ptr %rgep7053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7054, ptr %slot1093, align 8
  %v7055 = load i64, ptr %slot1093, align 8
  %op7056 = sub i64 %v7055, 1
  store i64 %op7056, ptr %slot1094, align 8
  %v7057 = load i64, ptr %slot1094, align 8
  %cmp7058 = icmp eq i64 %v7057, 0
  %cv7059 = zext i1 %cmp7058 to i32
  store i32 %cv7059, ptr %slot1095, align 8
  %v7060 = load i32, ptr %slot1095, align 8
  %cv7061 = zext i32 %v7060 to i64
  %cond7062 = icmp ne i64 %cv7061, 0
  br i1 %cond7062, label %bb_rcglast1367, label %bb_rcgdec1367
bb_rcglast1367:
  %v7063 = load i64, ptr %slot1086, align 8
  %op7064 = sub i64 %v7063, 32
  store i64 %op7064, ptr %slot1096, align 8
  %v7065 = load i64, ptr %slot1086, align 8
  %p7066 = inttoptr i64 %v7065 to ptr
  %rgep7067 = getelementptr i8, ptr %p7066, i64 -32
  %ld7068 = load i64, ptr %rgep7067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7068, ptr %slot1097, align 8
  %v7069 = load i64, ptr %slot1097, align 8
  %cmp7070 = icmp ne i64 %v7069, 0
  %cv7071 = zext i1 %cmp7070 to i32
  store i32 %cv7071, ptr %slot1098, align 8
  %v7072 = load i32, ptr %slot1098, align 8
  %cv7073 = zext i32 %v7072 to i64
  %cond7074 = icmp ne i64 %cv7073, 0
  br i1 %cond7074, label %bb_rcgdec1367, label %bb_rcgslow1367
bb_rcgslow1367:
  %v7075 = load i64, ptr %slot1085, align 8
  %v7076 = load i64, ptr %slot1082, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v7075, i64 %v7076) nomerge, !dbg !146
  br label %bb_rcgdone1367
bb_rcgdec1367:
  %v7077 = load i64, ptr %slot1094, align 8
  %v7078 = load i64, ptr %slot1086, align 8
  %p7079 = inttoptr i64 %v7078 to ptr
  %rgep7080 = getelementptr i8, ptr %p7079, i64 -24
  store i64 %v7077, ptr %rgep7080, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1367
bb_rcgclear1367:
  %v7081 = load i64, ptr %slot1082, align 8
  %p7082 = inttoptr i64 %v7081 to ptr
  store i64 0, ptr %p7082, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1367
bb_rcgdone1367:
  br label %bb_rcslotdone1351
bb_rcslotowner1351:
  %v7083 = load i64, ptr %slot88, align 8
  store i64 %v7083, ptr %slot1099, align 8
  %v7084 = load i64, ptr %slot1082, align 8
  %p7085 = inttoptr i64 %v7084 to ptr
  %ld7086 = load i64, ptr %p7085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7086, ptr %slot1100, align 8
  %v7087 = load i64, ptr %slot1100, align 8
  %cmp7088 = icmp ne i64 %v7087, 0
  %cv7089 = zext i1 %cmp7088 to i32
  store i32 %cv7089, ptr %slot1101, align 8
  %v7090 = load i32, ptr %slot1101, align 8
  %cv7091 = zext i32 %v7090 to i64
  %cond7092 = icmp ne i64 %cv7091, 0
  br i1 %cond7092, label %bb_rcgnn1382, label %bb_rcgdone1382
bb_rcgnn1382:
  %v7093 = load i64, ptr %slot1100, align 8
  %op7094 = sub i64 %v7093, 16
  store i64 %op7094, ptr %slot1102, align 8
  %v7095 = load i64, ptr %slot1100, align 8
  %p7096 = inttoptr i64 %v7095 to ptr
  %rgep7097 = getelementptr i8, ptr %p7096, i64 -16
  %ld7098 = load i64, ptr %rgep7097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7098, ptr %slot1103, align 8
  %v7099 = load i64, ptr %slot1103, align 8
  %op7100 = and i64 %v7099, 4611686018427387906
  store i64 %op7100, ptr %slot1104, align 8
  %v7101 = load i64, ptr %slot1104, align 8
  %cmp7102 = icmp ne i64 %v7101, 0
  %cv7103 = zext i1 %cmp7102 to i32
  store i32 %cv7103, ptr %slot1105, align 8
  %v7104 = load i32, ptr %slot1105, align 8
  %cv7105 = zext i32 %v7104 to i64
  %cond7106 = icmp ne i64 %cv7105, 0
  br i1 %cond7106, label %bb_rcgclear1382, label %bb_rcgcounted1382
bb_rcgcounted1382:
  %v7107 = load i64, ptr %slot1100, align 8
  %op7108 = sub i64 %v7107, 32
  store i64 %op7108, ptr %slot1106, align 8
  %v7109 = load i64, ptr %slot1100, align 8
  %p7110 = inttoptr i64 %v7109 to ptr
  %rgep7111 = getelementptr i8, ptr %p7110, i64 -32
  %ld7112 = load i64, ptr %rgep7111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7112, ptr %slot1107, align 8
  %v7113 = load i64, ptr %slot1107, align 8
  %op7114 = sub i64 %v7113, 1
  store i64 %op7114, ptr %slot1108, align 8
  %v7115 = load i64, ptr %slot1108, align 8
  %cmp7116 = icmp eq i64 %v7115, 0
  %cv7117 = zext i1 %cmp7116 to i32
  store i32 %cv7117, ptr %slot1109, align 8
  %v7118 = load i32, ptr %slot1109, align 8
  %cv7119 = zext i32 %v7118 to i64
  %cond7120 = icmp ne i64 %cv7119, 0
  br i1 %cond7120, label %bb_rcglast1382, label %bb_rcgdec1382
bb_rcglast1382:
  %v7121 = load i64, ptr %slot1100, align 8
  %op7122 = sub i64 %v7121, 24
  store i64 %op7122, ptr %slot1110, align 8
  %v7123 = load i64, ptr %slot1100, align 8
  %p7124 = inttoptr i64 %v7123 to ptr
  %rgep7125 = getelementptr i8, ptr %p7124, i64 -24
  %ld7126 = load i64, ptr %rgep7125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7126, ptr %slot1111, align 8
  %v7127 = load i64, ptr %slot1111, align 8
  %cmp7128 = icmp ne i64 %v7127, 0
  %cv7129 = zext i1 %cmp7128 to i32
  store i32 %cv7129, ptr %slot1112, align 8
  %v7130 = load i32, ptr %slot1112, align 8
  %cv7131 = zext i32 %v7130 to i64
  %cond7132 = icmp ne i64 %cv7131, 0
  br i1 %cond7132, label %bb_rcgdec1382, label %bb_rcgslow1382
bb_rcgslow1382:
  %v7133 = load i64, ptr %slot1099, align 8
  %v7134 = load i64, ptr %slot1082, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v7133, i64 %v7134) nomerge, !dbg !146
  br label %bb_rcgdone1382
bb_rcgdec1382:
  %v7135 = load i64, ptr %slot1108, align 8
  %v7136 = load i64, ptr %slot1100, align 8
  %p7137 = inttoptr i64 %v7136 to ptr
  %rgep7138 = getelementptr i8, ptr %p7137, i64 -32
  store i64 %v7135, ptr %rgep7138, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1382
bb_rcgclear1382:
  %v7139 = load i64, ptr %slot1082, align 8
  %p7140 = inttoptr i64 %v7139 to ptr
  store i64 0, ptr %p7140, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1382
bb_rcgdone1382:
  br label %bb_rcslotdone1351
bb_rcslotdone1351:
  %v7141 = load i64, ptr %slot11, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  %ld7143 = load i32, ptr %p7142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7143, ptr %slot1113, align 8
  %v7144 = load i32, ptr %slot1113, align 8
  %cv7145 = zext i32 %v7144 to i64
  %cond7146 = icmp ne i64 %cv7145, 0
  br i1 %cond7146, label %bb_rcslotdrop1388, label %bb_rcslotdone1388
bb_rcslotdrop1388:
  %v7147 = load i64, ptr %slot11, align 8
  %p7148 = inttoptr i64 %v7147 to ptr
  store i32 0, ptr %p7148, align 4, !alias.scope !3, !noalias !4
  %v7149 = load i64, ptr %slot58, align 8
  store i64 %v7149, ptr %slot1114, align 8
  %v7150 = load i64, ptr %slot12, align 8
  %p7151 = inttoptr i64 %v7150 to ptr
  %ld7152 = load i32, ptr %p7151, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7152, ptr %slot1115, align 8
  %v7153 = load i32, ptr %slot1115, align 8
  %op7154 = and i32 %v7153, 28
  store i32 %op7154, ptr %slot1116, align 8
  %v7155 = load i32, ptr %slot1116, align 8
  %cv7156 = zext i32 %v7155 to i64
  %cond7157 = icmp ne i64 %cv7156, 0
  br i1 %cond7157, label %bb_rcslotrole1388, label %bb_rcslotowner1388
bb_rcslotrole1388:
  %v7158 = load i64, ptr %slot88, align 8
  store i64 %v7158, ptr %slot1117, align 8
  %v7159 = load i64, ptr %slot1114, align 8
  %p7160 = inttoptr i64 %v7159 to ptr
  %ld7161 = load i64, ptr %p7160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7161, ptr %slot1118, align 8
  %v7162 = load i64, ptr %slot1118, align 8
  %cmp7163 = icmp ne i64 %v7162, 0
  %cv7164 = zext i1 %cmp7163 to i32
  store i32 %cv7164, ptr %slot1119, align 8
  %v7165 = load i32, ptr %slot1119, align 8
  %cv7166 = zext i32 %v7165 to i64
  %cond7167 = icmp ne i64 %cv7166, 0
  br i1 %cond7167, label %bb_rcgnn1404, label %bb_rcgdone1404
bb_rcgnn1404:
  %v7168 = load i64, ptr %slot1118, align 8
  %op7169 = sub i64 %v7168, 16
  store i64 %op7169, ptr %slot1120, align 8
  %v7170 = load i64, ptr %slot1118, align 8
  %p7171 = inttoptr i64 %v7170 to ptr
  %rgep7172 = getelementptr i8, ptr %p7171, i64 -16
  %ld7173 = load i64, ptr %rgep7172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7173, ptr %slot1121, align 8
  %v7174 = load i64, ptr %slot1121, align 8
  %op7175 = and i64 %v7174, 4611686018427387906
  store i64 %op7175, ptr %slot1122, align 8
  %v7176 = load i64, ptr %slot1122, align 8
  %cmp7177 = icmp ne i64 %v7176, 0
  %cv7178 = zext i1 %cmp7177 to i32
  store i32 %cv7178, ptr %slot1123, align 8
  %v7179 = load i32, ptr %slot1123, align 8
  %cv7180 = zext i32 %v7179 to i64
  %cond7181 = icmp ne i64 %cv7180, 0
  br i1 %cond7181, label %bb_rcgclear1404, label %bb_rcgcounted1404
bb_rcgcounted1404:
  %v7182 = load i64, ptr %slot1118, align 8
  %op7183 = sub i64 %v7182, 24
  store i64 %op7183, ptr %slot1124, align 8
  %v7184 = load i64, ptr %slot1118, align 8
  %p7185 = inttoptr i64 %v7184 to ptr
  %rgep7186 = getelementptr i8, ptr %p7185, i64 -24
  %ld7187 = load i64, ptr %rgep7186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7187, ptr %slot1125, align 8
  %v7188 = load i64, ptr %slot1125, align 8
  %op7189 = sub i64 %v7188, 1
  store i64 %op7189, ptr %slot1126, align 8
  %v7190 = load i64, ptr %slot1126, align 8
  %cmp7191 = icmp eq i64 %v7190, 0
  %cv7192 = zext i1 %cmp7191 to i32
  store i32 %cv7192, ptr %slot1127, align 8
  %v7193 = load i32, ptr %slot1127, align 8
  %cv7194 = zext i32 %v7193 to i64
  %cond7195 = icmp ne i64 %cv7194, 0
  br i1 %cond7195, label %bb_rcglast1404, label %bb_rcgdec1404
bb_rcglast1404:
  %v7196 = load i64, ptr %slot1118, align 8
  %op7197 = sub i64 %v7196, 32
  store i64 %op7197, ptr %slot1128, align 8
  %v7198 = load i64, ptr %slot1118, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  %rgep7200 = getelementptr i8, ptr %p7199, i64 -32
  %ld7201 = load i64, ptr %rgep7200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7201, ptr %slot1129, align 8
  %v7202 = load i64, ptr %slot1129, align 8
  %cmp7203 = icmp ne i64 %v7202, 0
  %cv7204 = zext i1 %cmp7203 to i32
  store i32 %cv7204, ptr %slot1130, align 8
  %v7205 = load i32, ptr %slot1130, align 8
  %cv7206 = zext i32 %v7205 to i64
  %cond7207 = icmp ne i64 %cv7206, 0
  br i1 %cond7207, label %bb_rcgdec1404, label %bb_rcgslow1404
bb_rcgslow1404:
  %v7208 = load i64, ptr %slot1117, align 8
  %v7209 = load i64, ptr %slot1114, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v7208, i64 %v7209) nomerge, !dbg !146
  br label %bb_rcgdone1404
bb_rcgdec1404:
  %v7210 = load i64, ptr %slot1126, align 8
  %v7211 = load i64, ptr %slot1118, align 8
  %p7212 = inttoptr i64 %v7211 to ptr
  %rgep7213 = getelementptr i8, ptr %p7212, i64 -24
  store i64 %v7210, ptr %rgep7213, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1404
bb_rcgclear1404:
  %v7214 = load i64, ptr %slot1114, align 8
  %p7215 = inttoptr i64 %v7214 to ptr
  store i64 0, ptr %p7215, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1404
bb_rcgdone1404:
  br label %bb_rcslotdone1388
bb_rcslotowner1388:
  %v7216 = load i64, ptr %slot88, align 8
  store i64 %v7216, ptr %slot1131, align 8
  %v7217 = load i64, ptr %slot1114, align 8
  %p7218 = inttoptr i64 %v7217 to ptr
  %ld7219 = load i64, ptr %p7218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7219, ptr %slot1132, align 8
  %v7220 = load i64, ptr %slot1132, align 8
  %cmp7221 = icmp ne i64 %v7220, 0
  %cv7222 = zext i1 %cmp7221 to i32
  store i32 %cv7222, ptr %slot1133, align 8
  %v7223 = load i32, ptr %slot1133, align 8
  %cv7224 = zext i32 %v7223 to i64
  %cond7225 = icmp ne i64 %cv7224, 0
  br i1 %cond7225, label %bb_rcgnn1419, label %bb_rcgdone1419
bb_rcgnn1419:
  %v7226 = load i64, ptr %slot1132, align 8
  %op7227 = sub i64 %v7226, 16
  store i64 %op7227, ptr %slot1134, align 8
  %v7228 = load i64, ptr %slot1132, align 8
  %p7229 = inttoptr i64 %v7228 to ptr
  %rgep7230 = getelementptr i8, ptr %p7229, i64 -16
  %ld7231 = load i64, ptr %rgep7230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7231, ptr %slot1135, align 8
  %v7232 = load i64, ptr %slot1135, align 8
  %op7233 = and i64 %v7232, 4611686018427387906
  store i64 %op7233, ptr %slot1136, align 8
  %v7234 = load i64, ptr %slot1136, align 8
  %cmp7235 = icmp ne i64 %v7234, 0
  %cv7236 = zext i1 %cmp7235 to i32
  store i32 %cv7236, ptr %slot1137, align 8
  %v7237 = load i32, ptr %slot1137, align 8
  %cv7238 = zext i32 %v7237 to i64
  %cond7239 = icmp ne i64 %cv7238, 0
  br i1 %cond7239, label %bb_rcgclear1419, label %bb_rcgcounted1419
bb_rcgcounted1419:
  %v7240 = load i64, ptr %slot1132, align 8
  %op7241 = sub i64 %v7240, 32
  store i64 %op7241, ptr %slot1138, align 8
  %v7242 = load i64, ptr %slot1132, align 8
  %p7243 = inttoptr i64 %v7242 to ptr
  %rgep7244 = getelementptr i8, ptr %p7243, i64 -32
  %ld7245 = load i64, ptr %rgep7244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7245, ptr %slot1139, align 8
  %v7246 = load i64, ptr %slot1139, align 8
  %op7247 = sub i64 %v7246, 1
  store i64 %op7247, ptr %slot1140, align 8
  %v7248 = load i64, ptr %slot1140, align 8
  %cmp7249 = icmp eq i64 %v7248, 0
  %cv7250 = zext i1 %cmp7249 to i32
  store i32 %cv7250, ptr %slot1141, align 8
  %v7251 = load i32, ptr %slot1141, align 8
  %cv7252 = zext i32 %v7251 to i64
  %cond7253 = icmp ne i64 %cv7252, 0
  br i1 %cond7253, label %bb_rcglast1419, label %bb_rcgdec1419
bb_rcglast1419:
  %v7254 = load i64, ptr %slot1132, align 8
  %op7255 = sub i64 %v7254, 24
  store i64 %op7255, ptr %slot1142, align 8
  %v7256 = load i64, ptr %slot1132, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  %rgep7258 = getelementptr i8, ptr %p7257, i64 -24
  %ld7259 = load i64, ptr %rgep7258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7259, ptr %slot1143, align 8
  %v7260 = load i64, ptr %slot1143, align 8
  %cmp7261 = icmp ne i64 %v7260, 0
  %cv7262 = zext i1 %cmp7261 to i32
  store i32 %cv7262, ptr %slot1144, align 8
  %v7263 = load i32, ptr %slot1144, align 8
  %cv7264 = zext i32 %v7263 to i64
  %cond7265 = icmp ne i64 %cv7264, 0
  br i1 %cond7265, label %bb_rcgdec1419, label %bb_rcgslow1419
bb_rcgslow1419:
  %v7266 = load i64, ptr %slot1131, align 8
  %v7267 = load i64, ptr %slot1114, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v7266, i64 %v7267) nomerge, !dbg !146
  br label %bb_rcgdone1419
bb_rcgdec1419:
  %v7268 = load i64, ptr %slot1140, align 8
  %v7269 = load i64, ptr %slot1132, align 8
  %p7270 = inttoptr i64 %v7269 to ptr
  %rgep7271 = getelementptr i8, ptr %p7270, i64 -32
  store i64 %v7268, ptr %rgep7271, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1419
bb_rcgclear1419:
  %v7272 = load i64, ptr %slot1114, align 8
  %p7273 = inttoptr i64 %v7272 to ptr
  store i64 0, ptr %p7273, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1419
bb_rcgdone1419:
  br label %bb_rcslotdone1388
bb_rcslotdone1388:
  %v7274 = load i64, ptr %slot51, align 8
  %p7275 = inttoptr i64 %v7274 to ptr
  %ld7276 = load i64, ptr %p7275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7276, ptr %slot1145, align 8
  %v7277 = load i64, ptr %slot1145, align 8
  %v7278 = load i64, ptr %slot68, align 8
  %p7279 = inttoptr i64 %v7278 to ptr
  store i64 %v7277, ptr %p7279, align 8, !alias.scope !3, !noalias !4
  %v7280 = load i64, ptr %slot68, align 8
  %p7281 = inttoptr i64 %v7280 to ptr
  %ld7282 = load i64, ptr %p7281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7282, ptr %slot1146, align 8
  %v7283 = load i64, ptr %slot1146, align 8
  %op7284 = add i64 %v7283, 376
  store i64 %op7284, ptr %slot1147, align 8
  %v7285 = load i64, ptr %slot1147, align 8
  %p7286 = inttoptr i64 %v7285 to ptr
  %ld7287 = load i64, ptr %p7286, align 8
  store i64 %ld7287, ptr %slot1148, align 8
  %v7288 = load i64, ptr %slot1148, align 8
  %v7289 = load i64, ptr %slot68, align 8
  %p7290 = inttoptr i64 %v7289 to ptr
  store i64 %v7288, ptr %p7290, align 8, !alias.scope !3, !noalias !4
  %v7291 = load i64, ptr %slot23, align 8
  %p7292 = inttoptr i64 %v7291 to ptr
  %ld7293 = load i32, ptr %p7292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7293, ptr %slot1149, align 8
  %v7294 = load i32, ptr %slot1149, align 8
  %cv7295 = zext i32 %v7294 to i64
  %cond7296 = icmp ne i64 %cv7295, 0
  br i1 %cond7296, label %bb_rcslotdrop1429, label %bb_rcslotdone1429
bb_rcslotdrop1429:
  %v7297 = load i64, ptr %slot23, align 8
  %p7298 = inttoptr i64 %v7297 to ptr
  store i32 0, ptr %p7298, align 4, !alias.scope !3, !noalias !4
  %v7299 = load i64, ptr %slot34, align 8
  store i64 %v7299, ptr %slot1150, align 8
  %v7300 = load i64, ptr %slot24, align 8
  %p7301 = inttoptr i64 %v7300 to ptr
  %ld7302 = load i32, ptr %p7301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7302, ptr %slot1151, align 8
  %v7303 = load i32, ptr %slot1151, align 8
  %op7304 = and i32 %v7303, 28
  store i32 %op7304, ptr %slot1152, align 8
  %v7305 = load i32, ptr %slot1152, align 8
  %cv7306 = zext i32 %v7305 to i64
  %cond7307 = icmp ne i64 %cv7306, 0
  br i1 %cond7307, label %bb_rcslotrole1429, label %bb_rcslotowner1429
bb_rcslotrole1429:
  %v7308 = load i64, ptr %slot88, align 8
  store i64 %v7308, ptr %slot1153, align 8
  %v7309 = load i64, ptr %slot1153, align 8
  %v7310 = load i64, ptr %slot1150, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v7309, i64 %v7310) nomerge, !dbg !148
  br label %bb_rcslotdone1429
bb_rcslotowner1429:
  %v7311 = load i64, ptr %slot88, align 8
  store i64 %v7311, ptr %slot1154, align 8
  %v7312 = load i64, ptr %slot1154, align 8
  %v7313 = load i64, ptr %slot1150, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v7312, i64 %v7313) nomerge, !dbg !148
  br label %bb_rcslotdone1429
bb_rcslotdone1429:
  %v7314 = load i64, ptr %slot68, align 8
  %p7315 = inttoptr i64 %v7314 to ptr
  %ld7316 = load i64, ptr %p7315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7316, ptr %slot1155, align 8
  %v7317 = load i64, ptr %slot51, align 8
  %p7318 = inttoptr i64 %v7317 to ptr
  %ld7319 = load i64, ptr %p7318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7319, ptr %slot1156, align 8
  %v7320 = load i64, ptr %slot23, align 8
  %p7321 = inttoptr i64 %v7320 to ptr
  %ld7322 = load i32, ptr %p7321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7322, ptr %slot1157, align 8
  %v7323 = load i32, ptr %slot1157, align 8
  %cv7324 = zext i32 %v7323 to i64
  %cond7325 = icmp ne i64 %cv7324, 0
  br i1 %cond7325, label %bb_rcslotdrop1441, label %bb_rcslotdone1441
bb_rcslotdrop1441:
  %v7326 = load i64, ptr %slot23, align 8
  %p7327 = inttoptr i64 %v7326 to ptr
  store i32 0, ptr %p7327, align 4, !alias.scope !3, !noalias !4
  %v7328 = load i64, ptr %slot34, align 8
  store i64 %v7328, ptr %slot1158, align 8
  %v7329 = load i64, ptr %slot24, align 8
  %p7330 = inttoptr i64 %v7329 to ptr
  %ld7331 = load i32, ptr %p7330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7331, ptr %slot1159, align 8
  %v7332 = load i32, ptr %slot1159, align 8
  %op7333 = and i32 %v7332, 28
  store i32 %op7333, ptr %slot1160, align 8
  %v7334 = load i32, ptr %slot1160, align 8
  %cv7335 = zext i32 %v7334 to i64
  %cond7336 = icmp ne i64 %cv7335, 0
  br i1 %cond7336, label %bb_rcslotrole1441, label %bb_rcslotowner1441
bb_rcslotrole1441:
  %v7337 = load i64, ptr %slot88, align 8
  store i64 %v7337, ptr %slot1161, align 8
  %v7338 = load i64, ptr %slot1158, align 8
  %p7339 = inttoptr i64 %v7338 to ptr
  %ld7340 = load i64, ptr %p7339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7340, ptr %slot1162, align 8
  %v7341 = load i64, ptr %slot1162, align 8
  %cmp7342 = icmp ne i64 %v7341, 0
  %cv7343 = zext i1 %cmp7342 to i32
  store i32 %cv7343, ptr %slot1163, align 8
  %v7344 = load i32, ptr %slot1163, align 8
  %cv7345 = zext i32 %v7344 to i64
  %cond7346 = icmp ne i64 %cv7345, 0
  br i1 %cond7346, label %bb_rcgnn1457, label %bb_rcgdone1457
bb_rcgnn1457:
  %v7347 = load i64, ptr %slot1162, align 8
  %op7348 = sub i64 %v7347, 16
  store i64 %op7348, ptr %slot1164, align 8
  %v7349 = load i64, ptr %slot1162, align 8
  %p7350 = inttoptr i64 %v7349 to ptr
  %rgep7351 = getelementptr i8, ptr %p7350, i64 -16
  %ld7352 = load i64, ptr %rgep7351, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7352, ptr %slot1165, align 8
  %v7353 = load i64, ptr %slot1165, align 8
  %op7354 = and i64 %v7353, 4611686018427387906
  store i64 %op7354, ptr %slot1166, align 8
  %v7355 = load i64, ptr %slot1166, align 8
  %cmp7356 = icmp ne i64 %v7355, 0
  %cv7357 = zext i1 %cmp7356 to i32
  store i32 %cv7357, ptr %slot1167, align 8
  %v7358 = load i32, ptr %slot1167, align 8
  %cv7359 = zext i32 %v7358 to i64
  %cond7360 = icmp ne i64 %cv7359, 0
  br i1 %cond7360, label %bb_rcgclear1457, label %bb_rcgcounted1457
bb_rcgcounted1457:
  %v7361 = load i64, ptr %slot1162, align 8
  %op7362 = sub i64 %v7361, 24
  store i64 %op7362, ptr %slot1168, align 8
  %v7363 = load i64, ptr %slot1162, align 8
  %p7364 = inttoptr i64 %v7363 to ptr
  %rgep7365 = getelementptr i8, ptr %p7364, i64 -24
  %ld7366 = load i64, ptr %rgep7365, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7366, ptr %slot1169, align 8
  %v7367 = load i64, ptr %slot1169, align 8
  %op7368 = sub i64 %v7367, 1
  store i64 %op7368, ptr %slot1170, align 8
  %v7369 = load i64, ptr %slot1170, align 8
  %cmp7370 = icmp eq i64 %v7369, 0
  %cv7371 = zext i1 %cmp7370 to i32
  store i32 %cv7371, ptr %slot1171, align 8
  %v7372 = load i32, ptr %slot1171, align 8
  %cv7373 = zext i32 %v7372 to i64
  %cond7374 = icmp ne i64 %cv7373, 0
  br i1 %cond7374, label %bb_rcglast1457, label %bb_rcgdec1457
bb_rcglast1457:
  %v7375 = load i64, ptr %slot1162, align 8
  %op7376 = sub i64 %v7375, 32
  store i64 %op7376, ptr %slot1172, align 8
  %v7377 = load i64, ptr %slot1162, align 8
  %p7378 = inttoptr i64 %v7377 to ptr
  %rgep7379 = getelementptr i8, ptr %p7378, i64 -32
  %ld7380 = load i64, ptr %rgep7379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7380, ptr %slot1173, align 8
  %v7381 = load i64, ptr %slot1173, align 8
  %cmp7382 = icmp ne i64 %v7381, 0
  %cv7383 = zext i1 %cmp7382 to i32
  store i32 %cv7383, ptr %slot1174, align 8
  %v7384 = load i32, ptr %slot1174, align 8
  %cv7385 = zext i32 %v7384 to i64
  %cond7386 = icmp ne i64 %cv7385, 0
  br i1 %cond7386, label %bb_rcgdec1457, label %bb_rcgslow1457
bb_rcgslow1457:
  %v7387 = load i64, ptr %slot1161, align 8
  %v7388 = load i64, ptr %slot1158, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v7387, i64 %v7388) nomerge, !dbg !150
  br label %bb_rcgdone1457
bb_rcgdec1457:
  %v7389 = load i64, ptr %slot1170, align 8
  %v7390 = load i64, ptr %slot1162, align 8
  %p7391 = inttoptr i64 %v7390 to ptr
  %rgep7392 = getelementptr i8, ptr %p7391, i64 -24
  store i64 %v7389, ptr %rgep7392, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1457
bb_rcgclear1457:
  %v7393 = load i64, ptr %slot1158, align 8
  %p7394 = inttoptr i64 %v7393 to ptr
  store i64 0, ptr %p7394, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1457
bb_rcgdone1457:
  br label %bb_rcslotdone1441
bb_rcslotowner1441:
  %v7395 = load i64, ptr %slot88, align 8
  store i64 %v7395, ptr %slot1175, align 8
  %v7396 = load i64, ptr %slot1158, align 8
  %p7397 = inttoptr i64 %v7396 to ptr
  %ld7398 = load i64, ptr %p7397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7398, ptr %slot1176, align 8
  %v7399 = load i64, ptr %slot1176, align 8
  %cmp7400 = icmp ne i64 %v7399, 0
  %cv7401 = zext i1 %cmp7400 to i32
  store i32 %cv7401, ptr %slot1177, align 8
  %v7402 = load i32, ptr %slot1177, align 8
  %cv7403 = zext i32 %v7402 to i64
  %cond7404 = icmp ne i64 %cv7403, 0
  br i1 %cond7404, label %bb_rcgnn1472, label %bb_rcgdone1472
bb_rcgnn1472:
  %v7405 = load i64, ptr %slot1176, align 8
  %op7406 = sub i64 %v7405, 16
  store i64 %op7406, ptr %slot1178, align 8
  %v7407 = load i64, ptr %slot1176, align 8
  %p7408 = inttoptr i64 %v7407 to ptr
  %rgep7409 = getelementptr i8, ptr %p7408, i64 -16
  %ld7410 = load i64, ptr %rgep7409, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7410, ptr %slot1179, align 8
  %v7411 = load i64, ptr %slot1179, align 8
  %op7412 = and i64 %v7411, 4611686018427387906
  store i64 %op7412, ptr %slot1180, align 8
  %v7413 = load i64, ptr %slot1180, align 8
  %cmp7414 = icmp ne i64 %v7413, 0
  %cv7415 = zext i1 %cmp7414 to i32
  store i32 %cv7415, ptr %slot1181, align 8
  %v7416 = load i32, ptr %slot1181, align 8
  %cv7417 = zext i32 %v7416 to i64
  %cond7418 = icmp ne i64 %cv7417, 0
  br i1 %cond7418, label %bb_rcgclear1472, label %bb_rcgcounted1472
bb_rcgcounted1472:
  %v7419 = load i64, ptr %slot1176, align 8
  %op7420 = sub i64 %v7419, 32
  store i64 %op7420, ptr %slot1182, align 8
  %v7421 = load i64, ptr %slot1176, align 8
  %p7422 = inttoptr i64 %v7421 to ptr
  %rgep7423 = getelementptr i8, ptr %p7422, i64 -32
  %ld7424 = load i64, ptr %rgep7423, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7424, ptr %slot1183, align 8
  %v7425 = load i64, ptr %slot1183, align 8
  %op7426 = sub i64 %v7425, 1
  store i64 %op7426, ptr %slot1184, align 8
  %v7427 = load i64, ptr %slot1184, align 8
  %cmp7428 = icmp eq i64 %v7427, 0
  %cv7429 = zext i1 %cmp7428 to i32
  store i32 %cv7429, ptr %slot1185, align 8
  %v7430 = load i32, ptr %slot1185, align 8
  %cv7431 = zext i32 %v7430 to i64
  %cond7432 = icmp ne i64 %cv7431, 0
  br i1 %cond7432, label %bb_rcglast1472, label %bb_rcgdec1472
bb_rcglast1472:
  %v7433 = load i64, ptr %slot1176, align 8
  %op7434 = sub i64 %v7433, 24
  store i64 %op7434, ptr %slot1186, align 8
  %v7435 = load i64, ptr %slot1176, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  %rgep7437 = getelementptr i8, ptr %p7436, i64 -24
  %ld7438 = load i64, ptr %rgep7437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7438, ptr %slot1187, align 8
  %v7439 = load i64, ptr %slot1187, align 8
  %cmp7440 = icmp ne i64 %v7439, 0
  %cv7441 = zext i1 %cmp7440 to i32
  store i32 %cv7441, ptr %slot1188, align 8
  %v7442 = load i32, ptr %slot1188, align 8
  %cv7443 = zext i32 %v7442 to i64
  %cond7444 = icmp ne i64 %cv7443, 0
  br i1 %cond7444, label %bb_rcgdec1472, label %bb_rcgslow1472
bb_rcgslow1472:
  %v7445 = load i64, ptr %slot1175, align 8
  %v7446 = load i64, ptr %slot1158, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v7445, i64 %v7446) nomerge, !dbg !150
  br label %bb_rcgdone1472
bb_rcgdec1472:
  %v7447 = load i64, ptr %slot1184, align 8
  %v7448 = load i64, ptr %slot1176, align 8
  %p7449 = inttoptr i64 %v7448 to ptr
  %rgep7450 = getelementptr i8, ptr %p7449, i64 -32
  store i64 %v7447, ptr %rgep7450, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1472
bb_rcgclear1472:
  %v7451 = load i64, ptr %slot1158, align 8
  %p7452 = inttoptr i64 %v7451 to ptr
  store i64 0, ptr %p7452, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1472
bb_rcgdone1472:
  br label %bb_rcslotdone1441
bb_rcslotdone1441:
  %v7453 = load i64, ptr %slot1156, align 8
  %op7454 = add i64 %v7453, 376
  store i64 %op7454, ptr %slot1189, align 8
  store i64 0, ptr %slot1190, align 8
  %v7455 = load i64, ptr %slot1189, align 8
  %p7456 = inttoptr i64 %v7455 to ptr
  %ld7457 = load i64, ptr %p7456, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7457, ptr %slot1191, align 8
  %v7458 = load i64, ptr %slot1191, align 8
  %cmp7459 = icmp ne i64 %v7458, 0
  %cv7460 = zext i1 %cmp7459 to i32
  store i32 %cv7460, ptr %slot1192, align 8
  %v7461 = load i32, ptr %slot1192, align 8
  %cv7462 = zext i32 %v7461 to i64
  %cond7463 = icmp ne i64 %cv7462, 0
  br i1 %cond7463, label %bb_rcguniquenn1478, label %bb_rcgunique1478
bb_rcguniquenn1478:
  %v7464 = load i64, ptr %slot1191, align 8
  %op7465 = sub i64 %v7464, 16
  store i64 %op7465, ptr %slot1193, align 8
  %v7466 = load i64, ptr %slot1191, align 8
  %p7467 = inttoptr i64 %v7466 to ptr
  %rgep7468 = getelementptr i8, ptr %p7467, i64 -16
  %ld7469 = load i64, ptr %rgep7468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7469, ptr %slot1194, align 8
  %v7470 = load i64, ptr %slot1194, align 8
  %op7471 = and i64 %v7470, 6917529027641081858
  store i64 %op7471, ptr %slot1195, align 8
  %v7472 = load i64, ptr %slot1195, align 8
  %cmp7473 = icmp ne i64 %v7472, 0
  %cv7474 = zext i1 %cmp7473 to i32
  store i32 %cv7474, ptr %slot1196, align 8
  %v7475 = load i32, ptr %slot1196, align 8
  %cv7476 = zext i32 %v7475 to i64
  %cond7477 = icmp ne i64 %cv7476, 0
  br i1 %cond7477, label %bb_rcguniqueslow1478, label %bb_rcguniquecount1478
bb_rcguniquecount1478:
  %v7478 = load i64, ptr %slot1191, align 8
  %op7479 = sub i64 %v7478, 32
  store i64 %op7479, ptr %slot1197, align 8
  %v7480 = load i64, ptr %slot1191, align 8
  %p7481 = inttoptr i64 %v7480 to ptr
  %rgep7482 = getelementptr i8, ptr %p7481, i64 -32
  %ld7483 = load i64, ptr %rgep7482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7483, ptr %slot1198, align 8
  %v7484 = load i64, ptr %slot1198, align 8
  %cmp7485 = icmp ult i64 %v7484, 2
  %cv7486 = zext i1 %cmp7485 to i32
  store i32 %cv7486, ptr %slot1199, align 8
  %v7487 = load i32, ptr %slot1199, align 8
  %cv7488 = zext i32 %v7487 to i64
  %cond7489 = icmp ne i64 %cv7488, 0
  br i1 %cond7489, label %bb_rcgunique1478, label %bb_rcguniqueslow1478
bb_rcguniqueslow1478:
  %v7490 = load i64, ptr %slot1, align 8
  %p7491 = inttoptr i64 %v7490 to ptr
  %p7492 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v7493 = load i64, ptr %slot1189, align 8
  %p7494 = inttoptr i64 %v7493 to ptr
  %v7495 = load i64, ptr %slot1190, align 8
  %p7496 = inttoptr i64 %v7495 to ptr
  %call7497 = call i32 @myl_qbe_rc_unique_field(ptr %p7491, ptr %p7492, ptr %p7494, ptr %p7496) nomerge, !dbg !150
  store i32 %call7497, ptr %slot1200, align 8
  %v7498 = load i32, ptr %slot1200, align 8
  %cv7499 = zext i32 %v7498 to i64
  %cond7500 = icmp ne i64 %cv7499, 0
  br i1 %cond7500, label %bb_rcunique1488, label %bb_failure
bb_rcunique1488:
  br label %bb_rcgunique1478
bb_rcgunique1478:
  %v7501 = load i64, ptr %slot1189, align 8
  %p7502 = inttoptr i64 %v7501 to ptr
  %ld7503 = load i64, ptr %p7502, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7503, ptr %slot1201, align 8
  %v7504 = load i64, ptr %slot1201, align 8
  %v7505 = load i64, ptr %slot68, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  store i64 %v7504, ptr %p7506, align 8, !alias.scope !3, !noalias !4
  %v7507 = load i64, ptr %slot68, align 8
  %p7508 = inttoptr i64 %v7507 to ptr
  %ld7509 = load i64, ptr %p7508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7509, ptr %slot1202, align 8
  %v7510 = load i64, ptr %slot23, align 8
  %p7511 = inttoptr i64 %v7510 to ptr
  %ld7512 = load i32, ptr %p7511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7512, ptr %slot1203, align 8
  %v7513 = load i32, ptr %slot1203, align 8
  %cv7514 = zext i32 %v7513 to i64
  %cond7515 = icmp ne i64 %cv7514, 0
  br i1 %cond7515, label %bb_rcslotdrop1493, label %bb_rcslotdone1493
bb_rcslotdrop1493:
  %v7516 = load i64, ptr %slot23, align 8
  %p7517 = inttoptr i64 %v7516 to ptr
  store i32 0, ptr %p7517, align 4, !alias.scope !3, !noalias !4
  %v7518 = load i64, ptr %slot34, align 8
  store i64 %v7518, ptr %slot1204, align 8
  %v7519 = load i64, ptr %slot24, align 8
  %p7520 = inttoptr i64 %v7519 to ptr
  %ld7521 = load i32, ptr %p7520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7521, ptr %slot1205, align 8
  %v7522 = load i32, ptr %slot1205, align 8
  %op7523 = and i32 %v7522, 28
  store i32 %op7523, ptr %slot1206, align 8
  %v7524 = load i32, ptr %slot1206, align 8
  %cv7525 = zext i32 %v7524 to i64
  %cond7526 = icmp ne i64 %cv7525, 0
  br i1 %cond7526, label %bb_rcslotrole1493, label %bb_rcslotowner1493
bb_rcslotrole1493:
  %v7527 = load i64, ptr %slot88, align 8
  store i64 %v7527, ptr %slot1207, align 8
  %v7528 = load i64, ptr %slot1204, align 8
  %p7529 = inttoptr i64 %v7528 to ptr
  %ld7530 = load i64, ptr %p7529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7530, ptr %slot1208, align 8
  %v7531 = load i64, ptr %slot1208, align 8
  %cmp7532 = icmp ne i64 %v7531, 0
  %cv7533 = zext i1 %cmp7532 to i32
  store i32 %cv7533, ptr %slot1209, align 8
  %v7534 = load i32, ptr %slot1209, align 8
  %cv7535 = zext i32 %v7534 to i64
  %cond7536 = icmp ne i64 %cv7535, 0
  br i1 %cond7536, label %bb_rcgnn1509, label %bb_rcgdone1509
bb_rcgnn1509:
  %v7537 = load i64, ptr %slot1208, align 8
  %op7538 = sub i64 %v7537, 16
  store i64 %op7538, ptr %slot1210, align 8
  %v7539 = load i64, ptr %slot1208, align 8
  %p7540 = inttoptr i64 %v7539 to ptr
  %rgep7541 = getelementptr i8, ptr %p7540, i64 -16
  %ld7542 = load i64, ptr %rgep7541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7542, ptr %slot1211, align 8
  %v7543 = load i64, ptr %slot1211, align 8
  %op7544 = and i64 %v7543, 4611686018427387906
  store i64 %op7544, ptr %slot1212, align 8
  %v7545 = load i64, ptr %slot1212, align 8
  %cmp7546 = icmp ne i64 %v7545, 0
  %cv7547 = zext i1 %cmp7546 to i32
  store i32 %cv7547, ptr %slot1213, align 8
  %v7548 = load i32, ptr %slot1213, align 8
  %cv7549 = zext i32 %v7548 to i64
  %cond7550 = icmp ne i64 %cv7549, 0
  br i1 %cond7550, label %bb_rcgclear1509, label %bb_rcgcounted1509
bb_rcgcounted1509:
  %v7551 = load i64, ptr %slot1208, align 8
  %op7552 = sub i64 %v7551, 24
  store i64 %op7552, ptr %slot1214, align 8
  %v7553 = load i64, ptr %slot1208, align 8
  %p7554 = inttoptr i64 %v7553 to ptr
  %rgep7555 = getelementptr i8, ptr %p7554, i64 -24
  %ld7556 = load i64, ptr %rgep7555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7556, ptr %slot1215, align 8
  %v7557 = load i64, ptr %slot1215, align 8
  %op7558 = sub i64 %v7557, 1
  store i64 %op7558, ptr %slot1216, align 8
  %v7559 = load i64, ptr %slot1216, align 8
  %cmp7560 = icmp eq i64 %v7559, 0
  %cv7561 = zext i1 %cmp7560 to i32
  store i32 %cv7561, ptr %slot1217, align 8
  %v7562 = load i32, ptr %slot1217, align 8
  %cv7563 = zext i32 %v7562 to i64
  %cond7564 = icmp ne i64 %cv7563, 0
  br i1 %cond7564, label %bb_rcglast1509, label %bb_rcgdec1509
bb_rcglast1509:
  %v7565 = load i64, ptr %slot1208, align 8
  %op7566 = sub i64 %v7565, 32
  store i64 %op7566, ptr %slot1218, align 8
  %v7567 = load i64, ptr %slot1208, align 8
  %p7568 = inttoptr i64 %v7567 to ptr
  %rgep7569 = getelementptr i8, ptr %p7568, i64 -32
  %ld7570 = load i64, ptr %rgep7569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7570, ptr %slot1219, align 8
  %v7571 = load i64, ptr %slot1219, align 8
  %cmp7572 = icmp ne i64 %v7571, 0
  %cv7573 = zext i1 %cmp7572 to i32
  store i32 %cv7573, ptr %slot1220, align 8
  %v7574 = load i32, ptr %slot1220, align 8
  %cv7575 = zext i32 %v7574 to i64
  %cond7576 = icmp ne i64 %cv7575, 0
  br i1 %cond7576, label %bb_rcgdec1509, label %bb_rcgslow1509
bb_rcgslow1509:
  %v7577 = load i64, ptr %slot1207, align 8
  %v7578 = load i64, ptr %slot1204, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v7577, i64 %v7578) nomerge, !dbg !150
  br label %bb_rcgdone1509
bb_rcgdec1509:
  %v7579 = load i64, ptr %slot1216, align 8
  %v7580 = load i64, ptr %slot1208, align 8
  %p7581 = inttoptr i64 %v7580 to ptr
  %rgep7582 = getelementptr i8, ptr %p7581, i64 -24
  store i64 %v7579, ptr %rgep7582, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1509
bb_rcgclear1509:
  %v7583 = load i64, ptr %slot1204, align 8
  %p7584 = inttoptr i64 %v7583 to ptr
  store i64 0, ptr %p7584, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1509
bb_rcgdone1509:
  br label %bb_rcslotdone1493
bb_rcslotowner1493:
  %v7585 = load i64, ptr %slot88, align 8
  store i64 %v7585, ptr %slot1221, align 8
  %v7586 = load i64, ptr %slot1204, align 8
  %p7587 = inttoptr i64 %v7586 to ptr
  %ld7588 = load i64, ptr %p7587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7588, ptr %slot1222, align 8
  %v7589 = load i64, ptr %slot1222, align 8
  %cmp7590 = icmp ne i64 %v7589, 0
  %cv7591 = zext i1 %cmp7590 to i32
  store i32 %cv7591, ptr %slot1223, align 8
  %v7592 = load i32, ptr %slot1223, align 8
  %cv7593 = zext i32 %v7592 to i64
  %cond7594 = icmp ne i64 %cv7593, 0
  br i1 %cond7594, label %bb_rcgnn1524, label %bb_rcgdone1524
bb_rcgnn1524:
  %v7595 = load i64, ptr %slot1222, align 8
  %op7596 = sub i64 %v7595, 16
  store i64 %op7596, ptr %slot1224, align 8
  %v7597 = load i64, ptr %slot1222, align 8
  %p7598 = inttoptr i64 %v7597 to ptr
  %rgep7599 = getelementptr i8, ptr %p7598, i64 -16
  %ld7600 = load i64, ptr %rgep7599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7600, ptr %slot1225, align 8
  %v7601 = load i64, ptr %slot1225, align 8
  %op7602 = and i64 %v7601, 4611686018427387906
  store i64 %op7602, ptr %slot1226, align 8
  %v7603 = load i64, ptr %slot1226, align 8
  %cmp7604 = icmp ne i64 %v7603, 0
  %cv7605 = zext i1 %cmp7604 to i32
  store i32 %cv7605, ptr %slot1227, align 8
  %v7606 = load i32, ptr %slot1227, align 8
  %cv7607 = zext i32 %v7606 to i64
  %cond7608 = icmp ne i64 %cv7607, 0
  br i1 %cond7608, label %bb_rcgclear1524, label %bb_rcgcounted1524
bb_rcgcounted1524:
  %v7609 = load i64, ptr %slot1222, align 8
  %op7610 = sub i64 %v7609, 32
  store i64 %op7610, ptr %slot1228, align 8
  %v7611 = load i64, ptr %slot1222, align 8
  %p7612 = inttoptr i64 %v7611 to ptr
  %rgep7613 = getelementptr i8, ptr %p7612, i64 -32
  %ld7614 = load i64, ptr %rgep7613, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7614, ptr %slot1229, align 8
  %v7615 = load i64, ptr %slot1229, align 8
  %op7616 = sub i64 %v7615, 1
  store i64 %op7616, ptr %slot1230, align 8
  %v7617 = load i64, ptr %slot1230, align 8
  %cmp7618 = icmp eq i64 %v7617, 0
  %cv7619 = zext i1 %cmp7618 to i32
  store i32 %cv7619, ptr %slot1231, align 8
  %v7620 = load i32, ptr %slot1231, align 8
  %cv7621 = zext i32 %v7620 to i64
  %cond7622 = icmp ne i64 %cv7621, 0
  br i1 %cond7622, label %bb_rcglast1524, label %bb_rcgdec1524
bb_rcglast1524:
  %v7623 = load i64, ptr %slot1222, align 8
  %op7624 = sub i64 %v7623, 24
  store i64 %op7624, ptr %slot1232, align 8
  %v7625 = load i64, ptr %slot1222, align 8
  %p7626 = inttoptr i64 %v7625 to ptr
  %rgep7627 = getelementptr i8, ptr %p7626, i64 -24
  %ld7628 = load i64, ptr %rgep7627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7628, ptr %slot1233, align 8
  %v7629 = load i64, ptr %slot1233, align 8
  %cmp7630 = icmp ne i64 %v7629, 0
  %cv7631 = zext i1 %cmp7630 to i32
  store i32 %cv7631, ptr %slot1234, align 8
  %v7632 = load i32, ptr %slot1234, align 8
  %cv7633 = zext i32 %v7632 to i64
  %cond7634 = icmp ne i64 %cv7633, 0
  br i1 %cond7634, label %bb_rcgdec1524, label %bb_rcgslow1524
bb_rcgslow1524:
  %v7635 = load i64, ptr %slot1221, align 8
  %v7636 = load i64, ptr %slot1204, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v7635, i64 %v7636) nomerge, !dbg !150
  br label %bb_rcgdone1524
bb_rcgdec1524:
  %v7637 = load i64, ptr %slot1230, align 8
  %v7638 = load i64, ptr %slot1222, align 8
  %p7639 = inttoptr i64 %v7638 to ptr
  %rgep7640 = getelementptr i8, ptr %p7639, i64 -32
  store i64 %v7637, ptr %rgep7640, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1524
bb_rcgclear1524:
  %v7641 = load i64, ptr %slot1204, align 8
  %p7642 = inttoptr i64 %v7641 to ptr
  store i64 0, ptr %p7642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1524
bb_rcgdone1524:
  br label %bb_rcslotdone1493
bb_rcslotdone1493:
  %v7643 = load i64, ptr %slot1202, align 8
  %v7644 = load i64, ptr %slot60, align 8
  %p7645 = inttoptr i64 %v7644 to ptr
  store i64 %v7643, ptr %p7645, align 8, !alias.scope !3, !noalias !4
  %v7646 = load i64, ptr %slot59, align 8
  %v7647 = load i64, ptr %slot68, align 8
  %p7648 = inttoptr i64 %v7647 to ptr
  store i64 %v7646, ptr %p7648, align 8, !alias.scope !3, !noalias !4
  %v7649 = load i64, ptr %slot68, align 8
  %p7650 = inttoptr i64 %v7649 to ptr
  %ld7651 = load i64, ptr %p7650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7651, ptr %slot1235, align 8
  %v7652 = load i64, ptr %slot23, align 8
  %p7653 = inttoptr i64 %v7652 to ptr
  %ld7654 = load i32, ptr %p7653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7654, ptr %slot1236, align 8
  %v7655 = load i64, ptr %slot24, align 8
  %p7656 = inttoptr i64 %v7655 to ptr
  %ld7657 = load i32, ptr %p7656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7657, ptr %slot1237, align 8
  %v7658 = load i32, ptr %slot1237, align 8
  %op7659 = and i32 %v7658, 24
  store i32 %op7659, ptr %slot1237, align 8
  %v7660 = load i32, ptr %slot1237, align 8
  %cmp7661 = icmp eq i32 %v7660, 0
  %cv7662 = zext i1 %cmp7661 to i32
  store i32 %cv7662, ptr %slot1238, align 8
  %v7663 = load i32, ptr %slot1236, align 8
  %v7664 = load i32, ptr %slot1238, align 8
  %op7665 = and i32 %v7663, %v7664
  store i32 %op7665, ptr %slot1239, align 8
  %v7666 = load i64, ptr %slot89, align 8
  store i64 %v7666, ptr %slot1240, align 8
  %v7667 = load i32, ptr %slot1239, align 8
  %op7668 = mul i32 %v7667, 4
  store i32 %op7668, ptr %slot1241, align 8
  %v7669 = load i32, ptr %slot1241, align 8
  %op7670 = or i32 %v7669, 0
  store i32 %op7670, ptr %slot1242, align 8
  %v7671 = load i64, ptr %slot42, align 8
  store i64 %v7671, ptr %slot1243, align 8
  %v7672 = load i64, ptr %slot88, align 8
  %v7673 = load i64, ptr %slot1243, align 8
  %v7674 = load i64, ptr %slot1235, align 8
  %v7675 = load i64, ptr %slot1240, align 8
  %cv7676 = trunc i64 %v7675 to i32
  %v7677 = load i32, ptr %slot1242, align 8
  %call7678 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v7672, i64 %v7673, i64 %v7674, i32 %cv7676, i32 %v7677) nomerge, !dbg !152
  store i32 %call7678, ptr %slot1244, align 8
  %v7679 = load i32, ptr %slot1244, align 8
  %cv7680 = zext i32 %v7679 to i64
  %cond7681 = icmp ne i64 %cv7680, 0
  br i1 %cond7681, label %bb_rcsuccess1579, label %bb_rcfailure1579
bb_rcfailure1579:
  %v7682 = load i64, ptr %slot88, align 8
  %p7683 = inttoptr i64 %v7682 to ptr
  %call7684 = call i32 @myl_rc_take_failure(ptr %p7683) nomerge, !dbg !152
  store i32 %call7684, ptr %slot1245, align 8
  %v7685 = load i64, ptr %slot1, align 8
  %p7686 = inttoptr i64 %v7685 to ptr
  %v7687 = load i32, ptr %slot1245, align 8
  %call7688 = call i32 @myl_qbe_rc_status(ptr %p7686, i32 %v7687) nomerge, !dbg !152
  store i32 %call7688, ptr %slot1246, align 8
  br label %bb_failure
bb_rcsuccess1579:
  %v7689 = load i32, ptr %slot1239, align 8
  %cv7690 = zext i32 %v7689 to i64
  %cond7691 = icmp ne i64 %cv7690, 0
  br i1 %cond7691, label %bb_rchtaken1582, label %bb_rchcopied1582
bb_rchcopied1582:
  %v7692 = load i64, ptr %slot23, align 8
  %p7693 = inttoptr i64 %v7692 to ptr
  %ld7694 = load i32, ptr %p7693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7694, ptr %slot1247, align 8
  %v7695 = load i32, ptr %slot1247, align 8
  %cv7696 = zext i32 %v7695 to i64
  %cond7697 = icmp ne i64 %cv7696, 0
  br i1 %cond7697, label %bb_rcslotdrop1585, label %bb_rcslotdone1585
bb_rcslotdrop1585:
  %v7698 = load i64, ptr %slot23, align 8
  %p7699 = inttoptr i64 %v7698 to ptr
  store i32 0, ptr %p7699, align 4, !alias.scope !3, !noalias !4
  %v7700 = load i64, ptr %slot34, align 8
  store i64 %v7700, ptr %slot1248, align 8
  %v7701 = load i64, ptr %slot24, align 8
  %p7702 = inttoptr i64 %v7701 to ptr
  %ld7703 = load i32, ptr %p7702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7703, ptr %slot1249, align 8
  %v7704 = load i32, ptr %slot1249, align 8
  %op7705 = and i32 %v7704, 28
  store i32 %op7705, ptr %slot1250, align 8
  %v7706 = load i32, ptr %slot1250, align 8
  %cv7707 = zext i32 %v7706 to i64
  %cond7708 = icmp ne i64 %cv7707, 0
  br i1 %cond7708, label %bb_rcslotrole1585, label %bb_rcslotowner1585
bb_rcslotrole1585:
  %v7709 = load i64, ptr %slot88, align 8
  store i64 %v7709, ptr %slot1251, align 8
  %v7710 = load i64, ptr %slot1251, align 8
  %v7711 = load i64, ptr %slot1248, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7710, i64 %v7711) nomerge, !dbg !152
  br label %bb_rcslotdone1585
bb_rcslotowner1585:
  %v7712 = load i64, ptr %slot88, align 8
  store i64 %v7712, ptr %slot1252, align 8
  %v7713 = load i64, ptr %slot1252, align 8
  %v7714 = load i64, ptr %slot1248, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7713, i64 %v7714) nomerge, !dbg !152
  br label %bb_rcslotdone1585
bb_rcslotdone1585:
  br label %bb_rchprepared1582
bb_rchtaken1582:
  %v7715 = load i64, ptr %slot23, align 8
  %p7716 = inttoptr i64 %v7715 to ptr
  store i32 0, ptr %p7716, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1582
bb_rchprepared1582:
  %v7717 = load i64, ptr %slot32, align 8
  %p7718 = inttoptr i64 %v7717 to ptr
  store i32 2, ptr %p7718, align 4, !alias.scope !3, !noalias !4
  %v7719 = load i64, ptr %slot31, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  store i32 1, ptr %p7720, align 4, !alias.scope !3, !noalias !4
  %v7721 = load i64, ptr %slot34, align 8
  store i64 %v7721, ptr %slot1253, align 8
  %v7722 = load i64, ptr %slot42, align 8
  store i64 %v7722, ptr %slot1254, align 8
  %v7723 = load i64, ptr %slot1254, align 8
  %v7724 = load i64, ptr %slot1253, align 8
  %p7725 = inttoptr i64 %v7723 to ptr
  %p7726 = inttoptr i64 %v7724 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7726, ptr %p7725, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v7727 = load i64, ptr %slot24, align 8
  %p7728 = inttoptr i64 %v7727 to ptr
  store i32 2, ptr %p7728, align 4, !alias.scope !3, !noalias !4
  %v7729 = load i64, ptr %slot32, align 8
  %p7730 = inttoptr i64 %v7729 to ptr
  %ld7731 = load i32, ptr %p7730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7731, ptr %slot1255, align 8
  %v7732 = load i32, ptr %slot1255, align 8
  %v7733 = load i64, ptr %slot24, align 8
  %p7734 = inttoptr i64 %v7733 to ptr
  store i32 %v7732, ptr %p7734, align 4, !alias.scope !3, !noalias !4
  %v7735 = load i64, ptr %slot31, align 8
  %p7736 = inttoptr i64 %v7735 to ptr
  store i32 0, ptr %p7736, align 4, !alias.scope !3, !noalias !4
  %v7737 = load i64, ptr %slot23, align 8
  %p7738 = inttoptr i64 %v7737 to ptr
  store i32 1, ptr %p7738, align 4, !alias.scope !3, !noalias !4
  %v7739 = load i64, ptr %slot1253, align 8
  %v7740 = load i64, ptr %slot68, align 8
  %p7741 = inttoptr i64 %v7740 to ptr
  store i64 %v7739, ptr %p7741, align 8, !alias.scope !3, !noalias !4
  %v7742 = load i64, ptr %slot60, align 8
  %p7743 = inttoptr i64 %v7742 to ptr
  %ld7744 = load i64, ptr %p7743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7744, ptr %slot1256, align 8
  %v7745 = load i64, ptr %slot68, align 8
  %p7746 = inttoptr i64 %v7745 to ptr
  %ld7747 = load i64, ptr %p7746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7747, ptr %slot1257, align 8
  %v7748 = load i64, ptr %slot88, align 8
  %v7749 = load i64, ptr %slot1256, align 8
  %v7750 = load i64, ptr %slot1257, align 8
  %call7751 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_append(i64 %v7748, i64 %v7749, i64 %v7750) nomerge, !dbg !154
  store i32 %call7751, ptr %slot1258, align 8
  %v7752 = load i32, ptr %slot1258, align 8
  %cv7753 = zext i32 %v7752 to i64
  %cond7754 = icmp ne i64 %cv7753, 0
  br i1 %cond7754, label %bb_success1606, label %bb_failed1606
bb_failed1606:
  %v7755 = load i64, ptr %slot1, align 8
  %p7756 = inttoptr i64 %v7755 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7756) nomerge, !dbg !154
  unreachable
bb_success1606:
  %v7757 = load i64, ptr %slot68, align 8
  %p7758 = inttoptr i64 %v7757 to ptr
  store i64 0, ptr %p7758, align 8, !alias.scope !3, !noalias !4
  %v7759 = load i64, ptr %slot23, align 8
  %p7760 = inttoptr i64 %v7759 to ptr
  %ld7761 = load i32, ptr %p7760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7761, ptr %slot1259, align 8
  %v7762 = load i32, ptr %slot1259, align 8
  %cv7763 = zext i32 %v7762 to i64
  %cond7764 = icmp ne i64 %cv7763, 0
  br i1 %cond7764, label %bb_rcslotdrop1609, label %bb_rcslotdone1609
bb_rcslotdrop1609:
  %v7765 = load i64, ptr %slot23, align 8
  %p7766 = inttoptr i64 %v7765 to ptr
  store i32 0, ptr %p7766, align 4, !alias.scope !3, !noalias !4
  %v7767 = load i64, ptr %slot34, align 8
  store i64 %v7767, ptr %slot1260, align 8
  %v7768 = load i64, ptr %slot24, align 8
  %p7769 = inttoptr i64 %v7768 to ptr
  %ld7770 = load i32, ptr %p7769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7770, ptr %slot1261, align 8
  %v7771 = load i32, ptr %slot1261, align 8
  %op7772 = and i32 %v7771, 28
  store i32 %op7772, ptr %slot1262, align 8
  %v7773 = load i32, ptr %slot1262, align 8
  %cv7774 = zext i32 %v7773 to i64
  %cond7775 = icmp ne i64 %cv7774, 0
  br i1 %cond7775, label %bb_rcslotrole1609, label %bb_rcslotowner1609
bb_rcslotrole1609:
  %v7776 = load i64, ptr %slot88, align 8
  store i64 %v7776, ptr %slot1263, align 8
  %v7777 = load i64, ptr %slot1263, align 8
  %v7778 = load i64, ptr %slot1260, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7777, i64 %v7778) nomerge, !dbg !154
  br label %bb_rcslotdone1609
bb_rcslotowner1609:
  %v7779 = load i64, ptr %slot88, align 8
  store i64 %v7779, ptr %slot1264, align 8
  %v7780 = load i64, ptr %slot1264, align 8
  %v7781 = load i64, ptr %slot1260, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7780, i64 %v7781) nomerge, !dbg !154
  br label %bb_rcslotdone1609
bb_rcslotdone1609:
  %v7782 = load i64, ptr %slot52, align 8
  %p7783 = inttoptr i64 %v7782 to ptr
  %ld7784 = load i64, ptr %p7783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7784, ptr %slot1265, align 8
  %v7785 = load i64, ptr %slot1265, align 8
  %v7786 = load i64, ptr %slot68, align 8
  %p7787 = inttoptr i64 %v7786 to ptr
  store i64 %v7785, ptr %p7787, align 8, !alias.scope !3, !noalias !4
  %v7788 = load i64, ptr %slot77, align 8
  store i64 %v7788, ptr %slot1266, align 8
  %v7789 = load i64, ptr %slot1266, align 8
  %p7790 = inttoptr i64 %v7789 to ptr
  store i32 0, ptr %p7790, align 4, !alias.scope !3, !noalias !4
  %v7791 = load i64, ptr %slot1266, align 8
  %p7792 = inttoptr i64 %v7791 to ptr
  store i32 3, ptr %p7792, align 4, !alias.scope !3, !noalias !4
  %v7793 = load i64, ptr %slot1266, align 8
  %v7794 = load i64, ptr %slot69, align 8
  %p7795 = inttoptr i64 %v7794 to ptr
  store i64 %v7793, ptr %p7795, align 8, !alias.scope !3, !noalias !4
  %v7796 = load i64, ptr %slot69, align 8
  %p7797 = inttoptr i64 %v7796 to ptr
  %ld7798 = load i64, ptr %p7797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7798, ptr %slot1267, align 8
  %v7799 = load i64, ptr %slot68, align 8
  %p7800 = inttoptr i64 %v7799 to ptr
  %ld7801 = load i64, ptr %p7800, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7801, ptr %slot1268, align 8
  %v7802 = load i64, ptr %slot1268, align 8
  %p7803 = inttoptr i64 %v7802 to ptr
  %ld7804 = load i32, ptr %p7803, align 4
  %ext7805 = zext i32 %ld7804 to i64
  store i64 %ext7805, ptr %slot1269, align 8
  %v7806 = load i64, ptr %slot1267, align 8
  %p7807 = inttoptr i64 %v7806 to ptr
  %ld7808 = load i32, ptr %p7807, align 4
  %ext7809 = zext i32 %ld7808 to i64
  store i64 %ext7809, ptr %slot1270, align 8
  %v7810 = load i64, ptr %slot1269, align 8
  %v7811 = load i64, ptr %slot1270, align 8
  %cmp7812 = icmp ne i64 %v7810, %v7811
  %cv7813 = zext i1 %cmp7812 to i64
  store i64 %cv7813, ptr %slot1271, align 8
  %v7814 = load i64, ptr %slot1271, align 8
  %v7815 = load i64, ptr %slot68, align 8
  %p7816 = inttoptr i64 %v7815 to ptr
  store i64 %v7814, ptr %p7816, align 8, !alias.scope !3, !noalias !4
  %v7817 = load i64, ptr %slot68, align 8
  %p7818 = inttoptr i64 %v7817 to ptr
  %ld7819 = load i64, ptr %p7818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7819, ptr %slot1272, align 8
  %v7820 = load i64, ptr %slot1272, align 8
  %cond7821 = icmp ne i64 %v7820, 0
  br i1 %cond7821, label %bb_next1624, label %bb_i95
bb_next1624:
  %v7822 = load i64, ptr %slot51, align 8
  %p7823 = inttoptr i64 %v7822 to ptr
  %ld7824 = load i64, ptr %p7823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7824, ptr %slot1273, align 8
  %v7825 = load i64, ptr %slot1273, align 8
  %v7826 = load i64, ptr %slot78, align 8
  %p7827 = inttoptr i64 %v7825 to ptr
  %p7828 = inttoptr i64 %v7826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7828, ptr %p7827, i64 392, i1 false), !alias.scope !10000000
  %v7829 = load i64, ptr %slot78, align 8
  %v7830 = load i64, ptr %slot68, align 8
  %p7831 = inttoptr i64 %v7830 to ptr
  store i64 %v7829, ptr %p7831, align 8, !alias.scope !3, !noalias !4
  %v7832 = load i64, ptr %slot68, align 8
  %p7833 = inttoptr i64 %v7832 to ptr
  %ld7834 = load i64, ptr %p7833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7834, ptr %slot1274, align 8
  %v7835 = load i64, ptr %slot1274, align 8
  %op7836 = add i64 %v7835, 0
  store i64 %op7836, ptr %slot1275, align 8
  %v7837 = load i64, ptr %slot1275, align 8
  %v7838 = load i64, ptr %slot68, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  store i64 %v7837, ptr %p7839, align 8, !alias.scope !3, !noalias !4
  %v7840 = load i64, ptr %slot15, align 8
  %p7841 = inttoptr i64 %v7840 to ptr
  %ld7842 = load i32, ptr %p7841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7842, ptr %slot1276, align 8
  %v7843 = load i32, ptr %slot1276, align 8
  %cv7844 = zext i32 %v7843 to i64
  %cond7845 = icmp ne i64 %cv7844, 0
  br i1 %cond7845, label %bb_rcslotdrop1629, label %bb_rcslotdone1629
bb_rcslotdrop1629:
  %v7846 = load i64, ptr %slot15, align 8
  %p7847 = inttoptr i64 %v7846 to ptr
  store i32 0, ptr %p7847, align 4, !alias.scope !3, !noalias !4
  %v7848 = load i64, ptr %slot61, align 8
  store i64 %v7848, ptr %slot1277, align 8
  %v7849 = load i64, ptr %slot16, align 8
  %p7850 = inttoptr i64 %v7849 to ptr
  %ld7851 = load i32, ptr %p7850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7851, ptr %slot1278, align 8
  %v7852 = load i32, ptr %slot1278, align 8
  %op7853 = and i32 %v7852, 28
  store i32 %op7853, ptr %slot1279, align 8
  %v7854 = load i32, ptr %slot1279, align 8
  %cv7855 = zext i32 %v7854 to i64
  %cond7856 = icmp ne i64 %cv7855, 0
  br i1 %cond7856, label %bb_rcslotrole1629, label %bb_rcslotowner1629
bb_rcslotrole1629:
  %v7857 = load i64, ptr %slot88, align 8
  store i64 %v7857, ptr %slot1280, align 8
  %v7858 = load i64, ptr %slot1280, align 8
  %v7859 = load i64, ptr %slot1277, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7858, i64 %v7859) nomerge, !dbg !156
  br label %bb_rcslotdone1629
bb_rcslotowner1629:
  %v7860 = load i64, ptr %slot88, align 8
  store i64 %v7860, ptr %slot1281, align 8
  %v7861 = load i64, ptr %slot1281, align 8
  %v7862 = load i64, ptr %slot1277, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7861, i64 %v7862) nomerge, !dbg !156
  br label %bb_rcslotdone1629
bb_rcslotdone1629:
  %v7863 = load i64, ptr %slot51, align 8
  %p7864 = inttoptr i64 %v7863 to ptr
  %ld7865 = load i64, ptr %p7864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7865, ptr %slot1282, align 8
  %v7866 = load i64, ptr %slot1282, align 8
  %op7867 = add i64 %v7866, 0
  store i64 %op7867, ptr %slot1283, align 8
  %v7868 = load i64, ptr %slot61, align 8
  store i64 %v7868, ptr %slot1284, align 8
  %v7869 = load i64, ptr %slot1283, align 8
  %v7870 = load i64, ptr %slot1284, align 8
  %p7871 = inttoptr i64 %v7869 to ptr
  %p7872 = inttoptr i64 %v7870 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7872, ptr %p7871, i64 208, i1 false), !alias.scope !10000000
  %v7873 = load i64, ptr %slot1283, align 8
  %p7874 = inttoptr i64 %v7873 to ptr
  call void @llvm.memset.p0.i64(ptr %p7874, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !156
  %v7875 = load i64, ptr %slot15, align 8
  %p7876 = inttoptr i64 %v7875 to ptr
  store i32 1, ptr %p7876, align 4, !alias.scope !3, !noalias !4
  %v7877 = load i64, ptr %slot61, align 8
  %v7878 = load i64, ptr %slot68, align 8
  %p7879 = inttoptr i64 %v7878 to ptr
  store i64 %v7877, ptr %p7879, align 8, !alias.scope !3, !noalias !4
  %v7880 = load i64, ptr %slot51, align 8
  %p7881 = inttoptr i64 %v7880 to ptr
  %ld7882 = load i64, ptr %p7881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7882, ptr %slot1285, align 8
  %v7883 = load i64, ptr %slot1285, align 8
  %v7884 = load i64, ptr %slot69, align 8
  %p7885 = inttoptr i64 %v7884 to ptr
  store i64 %v7883, ptr %p7885, align 8, !alias.scope !3, !noalias !4
  %v7886 = load i64, ptr %slot69, align 8
  %p7887 = inttoptr i64 %v7886 to ptr
  %ld7888 = load i64, ptr %p7887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7888, ptr %slot1286, align 8
  %v7889 = load i64, ptr %slot1286, align 8
  %op7890 = add i64 %v7889, 248
  store i64 %op7890, ptr %slot1287, align 8
  %v7891 = load i64, ptr %slot1287, align 8
  %p7892 = inttoptr i64 %v7891 to ptr
  %ld7893 = load i64, ptr %p7892, align 8
  store i64 %ld7893, ptr %slot1288, align 8
  %v7894 = load i64, ptr %slot1288, align 8
  %v7895 = load i64, ptr %slot69, align 8
  %p7896 = inttoptr i64 %v7895 to ptr
  store i64 %v7894, ptr %p7896, align 8, !alias.scope !3, !noalias !4
  %v7897 = load i64, ptr %slot25, align 8
  %p7898 = inttoptr i64 %v7897 to ptr
  %ld7899 = load i32, ptr %p7898, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7899, ptr %slot1289, align 8
  %v7900 = load i32, ptr %slot1289, align 8
  %cv7901 = zext i32 %v7900 to i64
  %cond7902 = icmp ne i64 %cv7901, 0
  br i1 %cond7902, label %bb_rcslotdrop1646, label %bb_rcslotdone1646
bb_rcslotdrop1646:
  %v7903 = load i64, ptr %slot25, align 8
  %p7904 = inttoptr i64 %v7903 to ptr
  store i32 0, ptr %p7904, align 4, !alias.scope !3, !noalias !4
  %v7905 = load i64, ptr %slot35, align 8
  store i64 %v7905, ptr %slot1290, align 8
  %v7906 = load i64, ptr %slot26, align 8
  %p7907 = inttoptr i64 %v7906 to ptr
  %ld7908 = load i32, ptr %p7907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7908, ptr %slot1291, align 8
  %v7909 = load i32, ptr %slot1291, align 8
  %op7910 = and i32 %v7909, 28
  store i32 %op7910, ptr %slot1292, align 8
  %v7911 = load i32, ptr %slot1292, align 8
  %cv7912 = zext i32 %v7911 to i64
  %cond7913 = icmp ne i64 %cv7912, 0
  br i1 %cond7913, label %bb_rcslotrole1646, label %bb_rcslotowner1646
bb_rcslotrole1646:
  %v7914 = load i64, ptr %slot88, align 8
  store i64 %v7914, ptr %slot1293, align 8
  %v7915 = load i64, ptr %slot1293, align 8
  %v7916 = load i64, ptr %slot1290, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v7915, i64 %v7916) nomerge, !dbg !158
  br label %bb_rcslotdone1646
bb_rcslotowner1646:
  %v7917 = load i64, ptr %slot88, align 8
  store i64 %v7917, ptr %slot1294, align 8
  %v7918 = load i64, ptr %slot1294, align 8
  %v7919 = load i64, ptr %slot1290, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v7918, i64 %v7919) nomerge, !dbg !158
  br label %bb_rcslotdone1646
bb_rcslotdone1646:
  %v7920 = load i64, ptr %slot51, align 8
  %p7921 = inttoptr i64 %v7920 to ptr
  %ld7922 = load i64, ptr %p7921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7922, ptr %slot1295, align 8
  %v7923 = load i64, ptr %slot1295, align 8
  %v7924 = load i64, ptr %slot70, align 8
  %p7925 = inttoptr i64 %v7924 to ptr
  store i64 %v7923, ptr %p7925, align 8, !alias.scope !3, !noalias !4
  %v7926 = load i64, ptr %slot70, align 8
  %p7927 = inttoptr i64 %v7926 to ptr
  %ld7928 = load i64, ptr %p7927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7928, ptr %slot1296, align 8
  %v7929 = load i64, ptr %slot1296, align 8
  %op7930 = add i64 %v7929, 328
  store i64 %op7930, ptr %slot1297, align 8
  %v7931 = load i64, ptr %slot1297, align 8
  %v7932 = load i64, ptr %slot70, align 8
  %p7933 = inttoptr i64 %v7932 to ptr
  store i64 %v7931, ptr %p7933, align 8, !alias.scope !3, !noalias !4
  %v7934 = load i64, ptr %slot69, align 8
  %p7935 = inttoptr i64 %v7934 to ptr
  %ld7936 = load i64, ptr %p7935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7936, ptr %slot1298, align 8
  %v7937 = load i64, ptr %slot70, align 8
  %p7938 = inttoptr i64 %v7937 to ptr
  %ld7939 = load i64, ptr %p7938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7939, ptr %slot1299, align 8
  %v7940 = load i64, ptr %slot1, align 8
  %v7941 = load i64, ptr %slot1298, align 8
  %v7942 = load i64, ptr %slot1299, align 8
  %call7943 = call i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %v7940, i64 %v7941, i64 %v7942) nomerge, !dbg !160
  store i64 %call7943, ptr %slot1300, align 8
  %v7944 = load i64, ptr %slot1300, align 8
  %v7945 = load i64, ptr %slot69, align 8
  %p7946 = inttoptr i64 %v7945 to ptr
  store i64 %v7944, ptr %p7946, align 8, !alias.scope !3, !noalias !4
  %v7947 = load i64, ptr %slot69, align 8
  %p7948 = inttoptr i64 %v7947 to ptr
  %ld7949 = load i64, ptr %p7948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7949, ptr %slot1301, align 8
  %v7950 = load i64, ptr %slot1301, align 8
  %v7951 = load i64, ptr %slot39, align 8
  %p7952 = inttoptr i64 %v7951 to ptr
  store i64 %v7950, ptr %p7952, align 8, !alias.scope !3, !noalias !4
  %v7953 = load i64, ptr %slot39, align 8
  store i64 %v7953, ptr %slot1302, align 8
  %v7954 = load i64, ptr %slot42, align 8
  store i64 %v7954, ptr %slot1303, align 8
  %v7955 = load i64, ptr %slot1302, align 8
  %v7956 = load i64, ptr %slot1303, align 8
  %p7957 = inttoptr i64 %v7955 to ptr
  %p7958 = inttoptr i64 %v7956 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7958, ptr %p7957, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7959 = load i64, ptr %slot32, align 8
  %p7960 = inttoptr i64 %v7959 to ptr
  store i32 2, ptr %p7960, align 4, !alias.scope !3, !noalias !4
  %v7961 = load i64, ptr %slot31, align 8
  %p7962 = inttoptr i64 %v7961 to ptr
  store i32 1, ptr %p7962, align 4, !alias.scope !3, !noalias !4
  %v7963 = load i64, ptr %slot25, align 8
  %p7964 = inttoptr i64 %v7963 to ptr
  %ld7965 = load i32, ptr %p7964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7965, ptr %slot1304, align 8
  %v7966 = load i32, ptr %slot1304, align 8
  %cv7967 = zext i32 %v7966 to i64
  %cond7968 = icmp ne i64 %cv7967, 0
  br i1 %cond7968, label %bb_rcslotdrop1675, label %bb_rcslotdone1675
bb_rcslotdrop1675:
  %v7969 = load i64, ptr %slot25, align 8
  %p7970 = inttoptr i64 %v7969 to ptr
  store i32 0, ptr %p7970, align 4, !alias.scope !3, !noalias !4
  %v7971 = load i64, ptr %slot35, align 8
  store i64 %v7971, ptr %slot1305, align 8
  %v7972 = load i64, ptr %slot26, align 8
  %p7973 = inttoptr i64 %v7972 to ptr
  %ld7974 = load i32, ptr %p7973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7974, ptr %slot1306, align 8
  %v7975 = load i32, ptr %slot1306, align 8
  %op7976 = and i32 %v7975, 28
  store i32 %op7976, ptr %slot1307, align 8
  %v7977 = load i32, ptr %slot1307, align 8
  %cv7978 = zext i32 %v7977 to i64
  %cond7979 = icmp ne i64 %cv7978, 0
  br i1 %cond7979, label %bb_rcslotrole1675, label %bb_rcslotowner1675
bb_rcslotrole1675:
  %v7980 = load i64, ptr %slot88, align 8
  store i64 %v7980, ptr %slot1308, align 8
  %v7981 = load i64, ptr %slot1305, align 8
  %p7982 = inttoptr i64 %v7981 to ptr
  %ld7983 = load i64, ptr %p7982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7983, ptr %slot1309, align 8
  %v7984 = load i64, ptr %slot1309, align 8
  %cmp7985 = icmp ne i64 %v7984, 0
  %cv7986 = zext i1 %cmp7985 to i32
  store i32 %cv7986, ptr %slot1310, align 8
  %v7987 = load i32, ptr %slot1310, align 8
  %cv7988 = zext i32 %v7987 to i64
  %cond7989 = icmp ne i64 %cv7988, 0
  br i1 %cond7989, label %bb_rcgnn1691, label %bb_rcgdone1691
bb_rcgnn1691:
  %v7990 = load i64, ptr %slot1309, align 8
  %op7991 = sub i64 %v7990, 16
  store i64 %op7991, ptr %slot1311, align 8
  %v7992 = load i64, ptr %slot1309, align 8
  %p7993 = inttoptr i64 %v7992 to ptr
  %rgep7994 = getelementptr i8, ptr %p7993, i64 -16
  %ld7995 = load i64, ptr %rgep7994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7995, ptr %slot1312, align 8
  %v7996 = load i64, ptr %slot1312, align 8
  %op7997 = and i64 %v7996, 4611686018427387906
  store i64 %op7997, ptr %slot1313, align 8
  %v7998 = load i64, ptr %slot1313, align 8
  %cmp7999 = icmp ne i64 %v7998, 0
  %cv8000 = zext i1 %cmp7999 to i32
  store i32 %cv8000, ptr %slot1314, align 8
  %v8001 = load i32, ptr %slot1314, align 8
  %cv8002 = zext i32 %v8001 to i64
  %cond8003 = icmp ne i64 %cv8002, 0
  br i1 %cond8003, label %bb_rcgclear1691, label %bb_rcgcounted1691
bb_rcgcounted1691:
  %v8004 = load i64, ptr %slot1309, align 8
  %op8005 = sub i64 %v8004, 24
  store i64 %op8005, ptr %slot1315, align 8
  %v8006 = load i64, ptr %slot1309, align 8
  %p8007 = inttoptr i64 %v8006 to ptr
  %rgep8008 = getelementptr i8, ptr %p8007, i64 -24
  %ld8009 = load i64, ptr %rgep8008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8009, ptr %slot1316, align 8
  %v8010 = load i64, ptr %slot1316, align 8
  %op8011 = sub i64 %v8010, 1
  store i64 %op8011, ptr %slot1317, align 8
  %v8012 = load i64, ptr %slot1317, align 8
  %cmp8013 = icmp eq i64 %v8012, 0
  %cv8014 = zext i1 %cmp8013 to i32
  store i32 %cv8014, ptr %slot1318, align 8
  %v8015 = load i32, ptr %slot1318, align 8
  %cv8016 = zext i32 %v8015 to i64
  %cond8017 = icmp ne i64 %cv8016, 0
  br i1 %cond8017, label %bb_rcglast1691, label %bb_rcgdec1691
bb_rcglast1691:
  %v8018 = load i64, ptr %slot1309, align 8
  %op8019 = sub i64 %v8018, 32
  store i64 %op8019, ptr %slot1319, align 8
  %v8020 = load i64, ptr %slot1309, align 8
  %p8021 = inttoptr i64 %v8020 to ptr
  %rgep8022 = getelementptr i8, ptr %p8021, i64 -32
  %ld8023 = load i64, ptr %rgep8022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8023, ptr %slot1320, align 8
  %v8024 = load i64, ptr %slot1320, align 8
  %cmp8025 = icmp ne i64 %v8024, 0
  %cv8026 = zext i1 %cmp8025 to i32
  store i32 %cv8026, ptr %slot1321, align 8
  %v8027 = load i32, ptr %slot1321, align 8
  %cv8028 = zext i32 %v8027 to i64
  %cond8029 = icmp ne i64 %cv8028, 0
  br i1 %cond8029, label %bb_rcgdec1691, label %bb_rcgslow1691
bb_rcgslow1691:
  %v8030 = load i64, ptr %slot1308, align 8
  %v8031 = load i64, ptr %slot1305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8030, i64 %v8031) nomerge, !dbg !160
  br label %bb_rcgdone1691
bb_rcgdec1691:
  %v8032 = load i64, ptr %slot1317, align 8
  %v8033 = load i64, ptr %slot1309, align 8
  %p8034 = inttoptr i64 %v8033 to ptr
  %rgep8035 = getelementptr i8, ptr %p8034, i64 -24
  store i64 %v8032, ptr %rgep8035, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1691
bb_rcgclear1691:
  %v8036 = load i64, ptr %slot1305, align 8
  %p8037 = inttoptr i64 %v8036 to ptr
  store i64 0, ptr %p8037, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1691
bb_rcgdone1691:
  br label %bb_rcslotdone1675
bb_rcslotowner1675:
  %v8038 = load i64, ptr %slot88, align 8
  store i64 %v8038, ptr %slot1322, align 8
  %v8039 = load i64, ptr %slot1305, align 8
  %p8040 = inttoptr i64 %v8039 to ptr
  %ld8041 = load i64, ptr %p8040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8041, ptr %slot1323, align 8
  %v8042 = load i64, ptr %slot1323, align 8
  %cmp8043 = icmp ne i64 %v8042, 0
  %cv8044 = zext i1 %cmp8043 to i32
  store i32 %cv8044, ptr %slot1324, align 8
  %v8045 = load i32, ptr %slot1324, align 8
  %cv8046 = zext i32 %v8045 to i64
  %cond8047 = icmp ne i64 %cv8046, 0
  br i1 %cond8047, label %bb_rcgnn1706, label %bb_rcgdone1706
bb_rcgnn1706:
  %v8048 = load i64, ptr %slot1323, align 8
  %op8049 = sub i64 %v8048, 16
  store i64 %op8049, ptr %slot1325, align 8
  %v8050 = load i64, ptr %slot1323, align 8
  %p8051 = inttoptr i64 %v8050 to ptr
  %rgep8052 = getelementptr i8, ptr %p8051, i64 -16
  %ld8053 = load i64, ptr %rgep8052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8053, ptr %slot1326, align 8
  %v8054 = load i64, ptr %slot1326, align 8
  %op8055 = and i64 %v8054, 4611686018427387906
  store i64 %op8055, ptr %slot1327, align 8
  %v8056 = load i64, ptr %slot1327, align 8
  %cmp8057 = icmp ne i64 %v8056, 0
  %cv8058 = zext i1 %cmp8057 to i32
  store i32 %cv8058, ptr %slot1328, align 8
  %v8059 = load i32, ptr %slot1328, align 8
  %cv8060 = zext i32 %v8059 to i64
  %cond8061 = icmp ne i64 %cv8060, 0
  br i1 %cond8061, label %bb_rcgclear1706, label %bb_rcgcounted1706
bb_rcgcounted1706:
  %v8062 = load i64, ptr %slot1323, align 8
  %op8063 = sub i64 %v8062, 32
  store i64 %op8063, ptr %slot1329, align 8
  %v8064 = load i64, ptr %slot1323, align 8
  %p8065 = inttoptr i64 %v8064 to ptr
  %rgep8066 = getelementptr i8, ptr %p8065, i64 -32
  %ld8067 = load i64, ptr %rgep8066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8067, ptr %slot1330, align 8
  %v8068 = load i64, ptr %slot1330, align 8
  %op8069 = sub i64 %v8068, 1
  store i64 %op8069, ptr %slot1331, align 8
  %v8070 = load i64, ptr %slot1331, align 8
  %cmp8071 = icmp eq i64 %v8070, 0
  %cv8072 = zext i1 %cmp8071 to i32
  store i32 %cv8072, ptr %slot1332, align 8
  %v8073 = load i32, ptr %slot1332, align 8
  %cv8074 = zext i32 %v8073 to i64
  %cond8075 = icmp ne i64 %cv8074, 0
  br i1 %cond8075, label %bb_rcglast1706, label %bb_rcgdec1706
bb_rcglast1706:
  %v8076 = load i64, ptr %slot1323, align 8
  %op8077 = sub i64 %v8076, 24
  store i64 %op8077, ptr %slot1333, align 8
  %v8078 = load i64, ptr %slot1323, align 8
  %p8079 = inttoptr i64 %v8078 to ptr
  %rgep8080 = getelementptr i8, ptr %p8079, i64 -24
  %ld8081 = load i64, ptr %rgep8080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8081, ptr %slot1334, align 8
  %v8082 = load i64, ptr %slot1334, align 8
  %cmp8083 = icmp ne i64 %v8082, 0
  %cv8084 = zext i1 %cmp8083 to i32
  store i32 %cv8084, ptr %slot1335, align 8
  %v8085 = load i32, ptr %slot1335, align 8
  %cv8086 = zext i32 %v8085 to i64
  %cond8087 = icmp ne i64 %cv8086, 0
  br i1 %cond8087, label %bb_rcgdec1706, label %bb_rcgslow1706
bb_rcgslow1706:
  %v8088 = load i64, ptr %slot1322, align 8
  %v8089 = load i64, ptr %slot1305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8088, i64 %v8089) nomerge, !dbg !160
  br label %bb_rcgdone1706
bb_rcgdec1706:
  %v8090 = load i64, ptr %slot1331, align 8
  %v8091 = load i64, ptr %slot1323, align 8
  %p8092 = inttoptr i64 %v8091 to ptr
  %rgep8093 = getelementptr i8, ptr %p8092, i64 -32
  store i64 %v8090, ptr %rgep8093, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1706
bb_rcgclear1706:
  %v8094 = load i64, ptr %slot1305, align 8
  %p8095 = inttoptr i64 %v8094 to ptr
  store i64 0, ptr %p8095, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1706
bb_rcgdone1706:
  br label %bb_rcslotdone1675
bb_rcslotdone1675:
  %v8096 = load i64, ptr %slot35, align 8
  store i64 %v8096, ptr %slot1336, align 8
  %v8097 = load i64, ptr %slot42, align 8
  store i64 %v8097, ptr %slot1337, align 8
  %v8098 = load i64, ptr %slot1337, align 8
  %v8099 = load i64, ptr %slot1336, align 8
  %p8100 = inttoptr i64 %v8098 to ptr
  %p8101 = inttoptr i64 %v8099 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8101, ptr %p8100, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8102 = load i64, ptr %slot26, align 8
  %p8103 = inttoptr i64 %v8102 to ptr
  store i32 2, ptr %p8103, align 4, !alias.scope !3, !noalias !4
  %v8104 = load i64, ptr %slot32, align 8
  %p8105 = inttoptr i64 %v8104 to ptr
  %ld8106 = load i32, ptr %p8105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8106, ptr %slot1338, align 8
  %v8107 = load i32, ptr %slot1338, align 8
  %v8108 = load i64, ptr %slot26, align 8
  %p8109 = inttoptr i64 %v8108 to ptr
  store i32 %v8107, ptr %p8109, align 4, !alias.scope !3, !noalias !4
  %v8110 = load i64, ptr %slot31, align 8
  %p8111 = inttoptr i64 %v8110 to ptr
  store i32 0, ptr %p8111, align 4, !alias.scope !3, !noalias !4
  %v8112 = load i64, ptr %slot25, align 8
  %p8113 = inttoptr i64 %v8112 to ptr
  store i32 1, ptr %p8113, align 4, !alias.scope !3, !noalias !4
  %v8114 = load i64, ptr %slot1336, align 8
  %p8115 = inttoptr i64 %v8114 to ptr
  %ld8116 = load i64, ptr %p8115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8116, ptr %slot1339, align 8
  %v8117 = load i64, ptr %slot1339, align 8
  %v8118 = load i64, ptr %slot69, align 8
  %p8119 = inttoptr i64 %v8118 to ptr
  store i64 %v8117, ptr %p8119, align 8, !alias.scope !3, !noalias !4
  %v8120 = load i64, ptr %slot68, align 8
  %p8121 = inttoptr i64 %v8120 to ptr
  %ld8122 = load i64, ptr %p8121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8122, ptr %slot1340, align 8
  %v8123 = load i64, ptr %slot69, align 8
  %p8124 = inttoptr i64 %v8123 to ptr
  %ld8125 = load i64, ptr %p8124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8125, ptr %slot1341, align 8
  %v8126 = load i64, ptr %slot1, align 8
  %v8127 = load i64, ptr %slot1340, align 8
  %v8128 = load i64, ptr %slot1341, align 8
  %call8129 = call i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64 %v8126, i64 %v8127, i64 %v8128) nomerge, !dbg !162
  store i64 %call8129, ptr %slot1342, align 8
  %v8130 = load i64, ptr %slot1342, align 8
  %v8131 = load i64, ptr %slot68, align 8
  %p8132 = inttoptr i64 %v8131 to ptr
  store i64 %v8130, ptr %p8132, align 8, !alias.scope !3, !noalias !4
  %v8133 = load i64, ptr %slot23, align 8
  %p8134 = inttoptr i64 %v8133 to ptr
  %ld8135 = load i32, ptr %p8134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8135, ptr %slot1343, align 8
  %v8136 = load i32, ptr %slot1343, align 8
  %cv8137 = zext i32 %v8136 to i64
  %cond8138 = icmp ne i64 %cv8137, 0
  br i1 %cond8138, label %bb_rcslotdrop1733, label %bb_rcslotdone1733
bb_rcslotdrop1733:
  %v8139 = load i64, ptr %slot23, align 8
  %p8140 = inttoptr i64 %v8139 to ptr
  store i32 0, ptr %p8140, align 4, !alias.scope !3, !noalias !4
  %v8141 = load i64, ptr %slot34, align 8
  store i64 %v8141, ptr %slot1344, align 8
  %v8142 = load i64, ptr %slot24, align 8
  %p8143 = inttoptr i64 %v8142 to ptr
  %ld8144 = load i32, ptr %p8143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8144, ptr %slot1345, align 8
  %v8145 = load i32, ptr %slot1345, align 8
  %op8146 = and i32 %v8145, 28
  store i32 %op8146, ptr %slot1346, align 8
  %v8147 = load i32, ptr %slot1346, align 8
  %cv8148 = zext i32 %v8147 to i64
  %cond8149 = icmp ne i64 %cv8148, 0
  br i1 %cond8149, label %bb_rcslotrole1733, label %bb_rcslotowner1733
bb_rcslotrole1733:
  %v8150 = load i64, ptr %slot88, align 8
  store i64 %v8150, ptr %slot1347, align 8
  %v8151 = load i64, ptr %slot1347, align 8
  %v8152 = load i64, ptr %slot1344, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8151, i64 %v8152) nomerge, !dbg !162
  br label %bb_rcslotdone1733
bb_rcslotowner1733:
  %v8153 = load i64, ptr %slot88, align 8
  store i64 %v8153, ptr %slot1348, align 8
  %v8154 = load i64, ptr %slot1348, align 8
  %v8155 = load i64, ptr %slot1344, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8154, i64 %v8155) nomerge, !dbg !162
  br label %bb_rcslotdone1733
bb_rcslotdone1733:
  %v8156 = load i64, ptr %slot25, align 8
  %p8157 = inttoptr i64 %v8156 to ptr
  %ld8158 = load i32, ptr %p8157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8158, ptr %slot1349, align 8
  %v8159 = load i32, ptr %slot1349, align 8
  %cv8160 = zext i32 %v8159 to i64
  %cond8161 = icmp ne i64 %cv8160, 0
  br i1 %cond8161, label %bb_rcslotdrop1742, label %bb_rcslotdone1742
bb_rcslotdrop1742:
  %v8162 = load i64, ptr %slot25, align 8
  %p8163 = inttoptr i64 %v8162 to ptr
  store i32 0, ptr %p8163, align 4, !alias.scope !3, !noalias !4
  %v8164 = load i64, ptr %slot35, align 8
  store i64 %v8164, ptr %slot1350, align 8
  %v8165 = load i64, ptr %slot26, align 8
  %p8166 = inttoptr i64 %v8165 to ptr
  %ld8167 = load i32, ptr %p8166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8167, ptr %slot1351, align 8
  %v8168 = load i32, ptr %slot1351, align 8
  %op8169 = and i32 %v8168, 28
  store i32 %op8169, ptr %slot1352, align 8
  %v8170 = load i32, ptr %slot1352, align 8
  %cv8171 = zext i32 %v8170 to i64
  %cond8172 = icmp ne i64 %cv8171, 0
  br i1 %cond8172, label %bb_rcslotrole1742, label %bb_rcslotowner1742
bb_rcslotrole1742:
  %v8173 = load i64, ptr %slot88, align 8
  store i64 %v8173, ptr %slot1353, align 8
  %v8174 = load i64, ptr %slot1350, align 8
  %p8175 = inttoptr i64 %v8174 to ptr
  %ld8176 = load i64, ptr %p8175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8176, ptr %slot1354, align 8
  %v8177 = load i64, ptr %slot1354, align 8
  %cmp8178 = icmp ne i64 %v8177, 0
  %cv8179 = zext i1 %cmp8178 to i32
  store i32 %cv8179, ptr %slot1355, align 8
  %v8180 = load i32, ptr %slot1355, align 8
  %cv8181 = zext i32 %v8180 to i64
  %cond8182 = icmp ne i64 %cv8181, 0
  br i1 %cond8182, label %bb_rcgnn1758, label %bb_rcgdone1758
bb_rcgnn1758:
  %v8183 = load i64, ptr %slot1354, align 8
  %op8184 = sub i64 %v8183, 16
  store i64 %op8184, ptr %slot1356, align 8
  %v8185 = load i64, ptr %slot1354, align 8
  %p8186 = inttoptr i64 %v8185 to ptr
  %rgep8187 = getelementptr i8, ptr %p8186, i64 -16
  %ld8188 = load i64, ptr %rgep8187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8188, ptr %slot1357, align 8
  %v8189 = load i64, ptr %slot1357, align 8
  %op8190 = and i64 %v8189, 4611686018427387906
  store i64 %op8190, ptr %slot1358, align 8
  %v8191 = load i64, ptr %slot1358, align 8
  %cmp8192 = icmp ne i64 %v8191, 0
  %cv8193 = zext i1 %cmp8192 to i32
  store i32 %cv8193, ptr %slot1359, align 8
  %v8194 = load i32, ptr %slot1359, align 8
  %cv8195 = zext i32 %v8194 to i64
  %cond8196 = icmp ne i64 %cv8195, 0
  br i1 %cond8196, label %bb_rcgclear1758, label %bb_rcgcounted1758
bb_rcgcounted1758:
  %v8197 = load i64, ptr %slot1354, align 8
  %op8198 = sub i64 %v8197, 24
  store i64 %op8198, ptr %slot1360, align 8
  %v8199 = load i64, ptr %slot1354, align 8
  %p8200 = inttoptr i64 %v8199 to ptr
  %rgep8201 = getelementptr i8, ptr %p8200, i64 -24
  %ld8202 = load i64, ptr %rgep8201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8202, ptr %slot1361, align 8
  %v8203 = load i64, ptr %slot1361, align 8
  %op8204 = sub i64 %v8203, 1
  store i64 %op8204, ptr %slot1362, align 8
  %v8205 = load i64, ptr %slot1362, align 8
  %cmp8206 = icmp eq i64 %v8205, 0
  %cv8207 = zext i1 %cmp8206 to i32
  store i32 %cv8207, ptr %slot1363, align 8
  %v8208 = load i32, ptr %slot1363, align 8
  %cv8209 = zext i32 %v8208 to i64
  %cond8210 = icmp ne i64 %cv8209, 0
  br i1 %cond8210, label %bb_rcglast1758, label %bb_rcgdec1758
bb_rcglast1758:
  %v8211 = load i64, ptr %slot1354, align 8
  %op8212 = sub i64 %v8211, 32
  store i64 %op8212, ptr %slot1364, align 8
  %v8213 = load i64, ptr %slot1354, align 8
  %p8214 = inttoptr i64 %v8213 to ptr
  %rgep8215 = getelementptr i8, ptr %p8214, i64 -32
  %ld8216 = load i64, ptr %rgep8215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8216, ptr %slot1365, align 8
  %v8217 = load i64, ptr %slot1365, align 8
  %cmp8218 = icmp ne i64 %v8217, 0
  %cv8219 = zext i1 %cmp8218 to i32
  store i32 %cv8219, ptr %slot1366, align 8
  %v8220 = load i32, ptr %slot1366, align 8
  %cv8221 = zext i32 %v8220 to i64
  %cond8222 = icmp ne i64 %cv8221, 0
  br i1 %cond8222, label %bb_rcgdec1758, label %bb_rcgslow1758
bb_rcgslow1758:
  %v8223 = load i64, ptr %slot1353, align 8
  %v8224 = load i64, ptr %slot1350, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8223, i64 %v8224) nomerge, !dbg !162
  br label %bb_rcgdone1758
bb_rcgdec1758:
  %v8225 = load i64, ptr %slot1362, align 8
  %v8226 = load i64, ptr %slot1354, align 8
  %p8227 = inttoptr i64 %v8226 to ptr
  %rgep8228 = getelementptr i8, ptr %p8227, i64 -24
  store i64 %v8225, ptr %rgep8228, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1758
bb_rcgclear1758:
  %v8229 = load i64, ptr %slot1350, align 8
  %p8230 = inttoptr i64 %v8229 to ptr
  store i64 0, ptr %p8230, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1758
bb_rcgdone1758:
  br label %bb_rcslotdone1742
bb_rcslotowner1742:
  %v8231 = load i64, ptr %slot88, align 8
  store i64 %v8231, ptr %slot1367, align 8
  %v8232 = load i64, ptr %slot1350, align 8
  %p8233 = inttoptr i64 %v8232 to ptr
  %ld8234 = load i64, ptr %p8233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8234, ptr %slot1368, align 8
  %v8235 = load i64, ptr %slot1368, align 8
  %cmp8236 = icmp ne i64 %v8235, 0
  %cv8237 = zext i1 %cmp8236 to i32
  store i32 %cv8237, ptr %slot1369, align 8
  %v8238 = load i32, ptr %slot1369, align 8
  %cv8239 = zext i32 %v8238 to i64
  %cond8240 = icmp ne i64 %cv8239, 0
  br i1 %cond8240, label %bb_rcgnn1773, label %bb_rcgdone1773
bb_rcgnn1773:
  %v8241 = load i64, ptr %slot1368, align 8
  %op8242 = sub i64 %v8241, 16
  store i64 %op8242, ptr %slot1370, align 8
  %v8243 = load i64, ptr %slot1368, align 8
  %p8244 = inttoptr i64 %v8243 to ptr
  %rgep8245 = getelementptr i8, ptr %p8244, i64 -16
  %ld8246 = load i64, ptr %rgep8245, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8246, ptr %slot1371, align 8
  %v8247 = load i64, ptr %slot1371, align 8
  %op8248 = and i64 %v8247, 4611686018427387906
  store i64 %op8248, ptr %slot1372, align 8
  %v8249 = load i64, ptr %slot1372, align 8
  %cmp8250 = icmp ne i64 %v8249, 0
  %cv8251 = zext i1 %cmp8250 to i32
  store i32 %cv8251, ptr %slot1373, align 8
  %v8252 = load i32, ptr %slot1373, align 8
  %cv8253 = zext i32 %v8252 to i64
  %cond8254 = icmp ne i64 %cv8253, 0
  br i1 %cond8254, label %bb_rcgclear1773, label %bb_rcgcounted1773
bb_rcgcounted1773:
  %v8255 = load i64, ptr %slot1368, align 8
  %op8256 = sub i64 %v8255, 32
  store i64 %op8256, ptr %slot1374, align 8
  %v8257 = load i64, ptr %slot1368, align 8
  %p8258 = inttoptr i64 %v8257 to ptr
  %rgep8259 = getelementptr i8, ptr %p8258, i64 -32
  %ld8260 = load i64, ptr %rgep8259, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8260, ptr %slot1375, align 8
  %v8261 = load i64, ptr %slot1375, align 8
  %op8262 = sub i64 %v8261, 1
  store i64 %op8262, ptr %slot1376, align 8
  %v8263 = load i64, ptr %slot1376, align 8
  %cmp8264 = icmp eq i64 %v8263, 0
  %cv8265 = zext i1 %cmp8264 to i32
  store i32 %cv8265, ptr %slot1377, align 8
  %v8266 = load i32, ptr %slot1377, align 8
  %cv8267 = zext i32 %v8266 to i64
  %cond8268 = icmp ne i64 %cv8267, 0
  br i1 %cond8268, label %bb_rcglast1773, label %bb_rcgdec1773
bb_rcglast1773:
  %v8269 = load i64, ptr %slot1368, align 8
  %op8270 = sub i64 %v8269, 24
  store i64 %op8270, ptr %slot1378, align 8
  %v8271 = load i64, ptr %slot1368, align 8
  %p8272 = inttoptr i64 %v8271 to ptr
  %rgep8273 = getelementptr i8, ptr %p8272, i64 -24
  %ld8274 = load i64, ptr %rgep8273, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8274, ptr %slot1379, align 8
  %v8275 = load i64, ptr %slot1379, align 8
  %cmp8276 = icmp ne i64 %v8275, 0
  %cv8277 = zext i1 %cmp8276 to i32
  store i32 %cv8277, ptr %slot1380, align 8
  %v8278 = load i32, ptr %slot1380, align 8
  %cv8279 = zext i32 %v8278 to i64
  %cond8280 = icmp ne i64 %cv8279, 0
  br i1 %cond8280, label %bb_rcgdec1773, label %bb_rcgslow1773
bb_rcgslow1773:
  %v8281 = load i64, ptr %slot1367, align 8
  %v8282 = load i64, ptr %slot1350, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8281, i64 %v8282) nomerge, !dbg !162
  br label %bb_rcgdone1773
bb_rcgdec1773:
  %v8283 = load i64, ptr %slot1376, align 8
  %v8284 = load i64, ptr %slot1368, align 8
  %p8285 = inttoptr i64 %v8284 to ptr
  %rgep8286 = getelementptr i8, ptr %p8285, i64 -32
  store i64 %v8283, ptr %rgep8286, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1773
bb_rcgclear1773:
  %v8287 = load i64, ptr %slot1350, align 8
  %p8288 = inttoptr i64 %v8287 to ptr
  store i64 0, ptr %p8288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1773
bb_rcgdone1773:
  br label %bb_rcslotdone1742
bb_rcslotdone1742:
  %v8289 = load i64, ptr %slot68, align 8
  %p8290 = inttoptr i64 %v8289 to ptr
  %ld8291 = load i64, ptr %p8290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8291, ptr %slot1381, align 8
  %v8292 = load i64, ptr %slot1381, align 8
  %v8293 = load i64, ptr %slot62, align 8
  %p8294 = inttoptr i64 %v8293 to ptr
  store i64 %v8292, ptr %p8294, align 8, !alias.scope !3, !noalias !4
  %v8295 = load i64, ptr %slot53, align 8
  %v8296 = load i64, ptr %slot68, align 8
  %p8297 = inttoptr i64 %v8296 to ptr
  store i64 %v8295, ptr %p8297, align 8, !alias.scope !3, !noalias !4
  %v8298 = load i64, ptr %slot53, align 8
  %v8299 = load i64, ptr %slot68, align 8
  %p8300 = inttoptr i64 %v8299 to ptr
  store i64 %v8298, ptr %p8300, align 8, !alias.scope !3, !noalias !4
  %v8301 = load i64, ptr %slot53, align 8
  store i64 %v8301, ptr %slot1382, align 8
  %v8302 = load i64, ptr %slot1382, align 8
  %v8303 = load i64, ptr %slot68, align 8
  %p8304 = inttoptr i64 %v8303 to ptr
  store i64 %v8302, ptr %p8304, align 8, !alias.scope !3, !noalias !4
  %v8305 = load i64, ptr %slot62, align 8
  %p8306 = inttoptr i64 %v8305 to ptr
  %ld8307 = load i64, ptr %p8306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8307, ptr %slot1383, align 8
  %v8308 = load i64, ptr %slot1383, align 8
  %v8309 = load i64, ptr %slot69, align 8
  %p8310 = inttoptr i64 %v8309 to ptr
  store i64 %v8308, ptr %p8310, align 8, !alias.scope !3, !noalias !4
  %v8311 = load i64, ptr %slot53, align 8
  store i64 %v8311, ptr %slot1384, align 8
  %v8312 = load i64, ptr %slot1384, align 8
  %v8313 = load i64, ptr %slot68, align 8
  %p8314 = inttoptr i64 %v8313 to ptr
  store i64 %v8312, ptr %p8314, align 8, !alias.scope !3, !noalias !4
  %v8315 = load i64, ptr %slot62, align 8
  %p8316 = inttoptr i64 %v8315 to ptr
  %ld8317 = load i64, ptr %p8316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8317, ptr %slot1385, align 8
  %v8318 = load i64, ptr %slot53, align 8
  store i64 %v8318, ptr %slot1386, align 8
  %v8319 = load i64, ptr %slot1386, align 8
  %p8321 = inttoptr i64 %v8319 to ptr
  %gep8322 = getelementptr i8, ptr %p8321, i64 40
  %op8320 = ptrtoint ptr %gep8322 to i64
  store i64 %op8320, ptr %slot1387, align 8
  %v8323 = load i64, ptr %slot1385, align 8
  %v8324 = load i64, ptr %slot1387, align 8
  %p8325 = inttoptr i64 %v8324 to ptr
  store i64 %v8323, ptr %p8325, align 8, !alias.scope !3, !noalias !4
  %v8326 = load i64, ptr %slot68, align 8
  %p8327 = inttoptr i64 %v8326 to ptr
  store i64 0, ptr %p8327, align 8, !alias.scope !3, !noalias !4
  %v8328 = load i64, ptr %slot51, align 8
  %p8329 = inttoptr i64 %v8328 to ptr
  %ld8330 = load i64, ptr %p8329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8330, ptr %slot1388, align 8
  %v8331 = load i64, ptr %slot1388, align 8
  %op8332 = add i64 %v8331, 0
  store i64 %op8332, ptr %slot1389, align 8
  %v8333 = load i64, ptr %slot61, align 8
  store i64 %v8333, ptr %slot1390, align 8
  %v8334 = load i64, ptr %slot1390, align 8
  %v8335 = load i64, ptr %slot1389, align 8
  %p8336 = inttoptr i64 %v8334 to ptr
  %p8337 = inttoptr i64 %v8335 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8337, ptr %p8336, i64 208, i1 false), !alias.scope !10000000
  %v8338 = load i64, ptr %slot1390, align 8
  %p8339 = inttoptr i64 %v8338 to ptr
  call void @llvm.memset.p0.i64(ptr %p8339, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !164
  %v8340 = load i64, ptr %slot15, align 8
  %p8341 = inttoptr i64 %v8340 to ptr
  store i32 0, ptr %p8341, align 4, !alias.scope !3, !noalias !4
  %v8342 = load i64, ptr %slot68, align 8
  %p8343 = inttoptr i64 %v8342 to ptr
  store i64 0, ptr %p8343, align 8, !alias.scope !3, !noalias !4
  br label %bb_i95
bb_i95:
  %p8344 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld8345 = load i64, ptr %p8344, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8345, ptr %slot1391, align 8
  %v8346 = load i64, ptr %slot1391, align 8
  %v8347 = load i64, ptr %slot68, align 8
  %p8348 = inttoptr i64 %v8347 to ptr
  store i64 %v8346, ptr %p8348, align 8, !alias.scope !3, !noalias !4
  %v8349 = load i64, ptr %slot68, align 8
  %p8350 = inttoptr i64 %v8349 to ptr
  %ld8351 = load i64, ptr %p8350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8351, ptr %slot1392, align 8
  %v8352 = load i64, ptr %slot1392, align 8
  %v8353 = load i64, ptr %slot38, align 8
  %p8354 = inttoptr i64 %v8353 to ptr
  store i64 %v8352, ptr %p8354, align 8, !alias.scope !3, !noalias !4
  %v8355 = load i64, ptr %slot38, align 8
  store i64 %v8355, ptr %slot1393, align 8
  %v8356 = load i64, ptr %slot42, align 8
  store i64 %v8356, ptr %slot1394, align 8
  %v8357 = load i64, ptr %slot1393, align 8
  %v8358 = load i64, ptr %slot1394, align 8
  %p8359 = inttoptr i64 %v8357 to ptr
  %p8360 = inttoptr i64 %v8358 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8360, ptr %p8359, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8361 = load i64, ptr %slot32, align 8
  %p8362 = inttoptr i64 %v8361 to ptr
  store i32 2, ptr %p8362, align 4, !alias.scope !3, !noalias !4
  %v8363 = load i64, ptr %slot31, align 8
  %p8364 = inttoptr i64 %v8363 to ptr
  store i32 1, ptr %p8364, align 4, !alias.scope !3, !noalias !4
  %v8365 = load i64, ptr %slot34, align 8
  store i64 %v8365, ptr %slot1395, align 8
  %v8366 = load i64, ptr %slot42, align 8
  store i64 %v8366, ptr %slot1396, align 8
  %v8367 = load i64, ptr %slot1396, align 8
  %v8368 = load i64, ptr %slot1395, align 8
  %p8369 = inttoptr i64 %v8367 to ptr
  %p8370 = inttoptr i64 %v8368 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8370, ptr %p8369, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8371 = load i64, ptr %slot24, align 8
  %p8372 = inttoptr i64 %v8371 to ptr
  store i32 2, ptr %p8372, align 4, !alias.scope !3, !noalias !4
  %v8373 = load i64, ptr %slot32, align 8
  %p8374 = inttoptr i64 %v8373 to ptr
  %ld8375 = load i32, ptr %p8374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8375, ptr %slot1397, align 8
  %v8376 = load i32, ptr %slot1397, align 8
  %v8377 = load i64, ptr %slot24, align 8
  %p8378 = inttoptr i64 %v8377 to ptr
  store i32 %v8376, ptr %p8378, align 4, !alias.scope !3, !noalias !4
  %v8379 = load i64, ptr %slot31, align 8
  %p8380 = inttoptr i64 %v8379 to ptr
  store i32 0, ptr %p8380, align 4, !alias.scope !3, !noalias !4
  %v8381 = load i64, ptr %slot23, align 8
  %p8382 = inttoptr i64 %v8381 to ptr
  store i32 1, ptr %p8382, align 4, !alias.scope !3, !noalias !4
  %v8383 = load i64, ptr %slot1395, align 8
  %p8384 = inttoptr i64 %v8383 to ptr
  %ld8385 = load i64, ptr %p8384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8385, ptr %slot1398, align 8
  %v8386 = load i64, ptr %slot1398, align 8
  %v8387 = load i64, ptr %slot68, align 8
  %p8388 = inttoptr i64 %v8387 to ptr
  store i64 %v8386, ptr %p8388, align 8, !alias.scope !3, !noalias !4
  %v8389 = load i64, ptr %slot68, align 8
  %p8390 = inttoptr i64 %v8389 to ptr
  %ld8391 = load i64, ptr %p8390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8391, ptr %slot1399, align 8
  %v8392 = load i64, ptr %slot1399, align 8
  %v8393 = load i64, ptr %slot38, align 8
  %p8394 = inttoptr i64 %v8393 to ptr
  store i64 %v8392, ptr %p8394, align 8, !alias.scope !3, !noalias !4
  %v8395 = load i64, ptr %slot38, align 8
  store i64 %v8395, ptr %slot1400, align 8
  %v8396 = load i64, ptr %slot42, align 8
  store i64 %v8396, ptr %slot1401, align 8
  %v8397 = load i64, ptr %slot89, align 8
  store i64 %v8397, ptr %slot1402, align 8
  %v8398 = load i64, ptr %slot1400, align 8
  %p8400 = inttoptr i64 %v8398 to ptr
  %gep8401 = getelementptr i8, ptr %p8400, i64 0
  %op8399 = ptrtoint ptr %gep8401 to i64
  store i64 %op8399, ptr %slot1403, align 8
  %v8402 = load i64, ptr %slot1403, align 8
  %p8403 = inttoptr i64 %v8402 to ptr
  %ld8404 = load i64, ptr %p8403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8404, ptr %slot1404, align 8
  %v8405 = load i64, ptr %slot1404, align 8
  %cmp8406 = icmp ne i64 %v8405, 0
  %cv8407 = zext i1 %cmp8406 to i32
  store i32 %cv8407, ptr %slot1405, align 8
  %v8408 = load i32, ptr %slot1405, align 8
  %cv8409 = zext i32 %v8408 to i64
  %cond8410 = icmp ne i64 %cv8409, 0
  br i1 %cond8410, label %bb_rcmoveheader1811, label %bb_rcmovenext1811
bb_rcmoveheader1811:
  %v8411 = load i64, ptr %slot1404, align 8
  %op8412 = sub i64 %v8411, 16
  store i64 %op8412, ptr %slot1406, align 8
  %v8413 = load i64, ptr %slot1404, align 8
  %p8414 = inttoptr i64 %v8413 to ptr
  %rgep8415 = getelementptr i8, ptr %p8414, i64 -16
  %ld8416 = load i64, ptr %rgep8415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8416, ptr %slot1407, align 8
  %v8417 = load i64, ptr %slot1407, align 8
  %op8418 = and i64 %v8417, 5764607523034234881
  store i64 %op8418, ptr %slot1408, align 8
  %v8419 = load i64, ptr %slot1408, align 8
  %cmp8420 = icmp ne i64 %v8419, 0
  %cv8421 = zext i1 %cmp8420 to i32
  store i32 %cv8421, ptr %slot1409, align 8
  %v8422 = load i32, ptr %slot1409, align 8
  %cv8423 = zext i32 %v8422 to i64
  %cond8424 = icmp ne i64 %cv8423, 0
  br i1 %cond8424, label %bb_rcmoveslow1808, label %bb_rcmovenext1811
bb_rcmovenext1811:
  %v8425 = load i64, ptr %slot1400, align 8
  %v8426 = load i64, ptr %slot1401, align 8
  %p8427 = inttoptr i64 %v8425 to ptr
  %p8428 = inttoptr i64 %v8426 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8428, ptr %p8427, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8429 = load i64, ptr %slot1400, align 8
  %p8430 = inttoptr i64 %v8429 to ptr
  store i64 0, ptr %p8430, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1808
bb_rcmoveslow1808:
  %v8431 = load i64, ptr %slot88, align 8
  %v8432 = load i64, ptr %slot1401, align 8
  %v8433 = load i64, ptr %slot1400, align 8
  %v8434 = load i64, ptr %slot1402, align 8
  %cv8435 = trunc i64 %v8434 to i32
  %call8436 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v8431, i64 %v8432, i64 %v8433, i32 %cv8435) nomerge, !dbg !166
  store i32 %call8436, ptr %slot1410, align 8
  %v8437 = load i32, ptr %slot1410, align 8
  %cv8438 = zext i32 %v8437 to i64
  %cond8439 = icmp ne i64 %cv8438, 0
  br i1 %cond8439, label %bb_rcsuccess1818, label %bb_rcfailure1818
bb_rcfailure1818:
  %v8440 = load i64, ptr %slot88, align 8
  %p8441 = inttoptr i64 %v8440 to ptr
  %call8442 = call i32 @myl_rc_take_failure(ptr %p8441) nomerge, !dbg !166
  store i32 %call8442, ptr %slot1411, align 8
  %v8443 = load i64, ptr %slot1, align 8
  %p8444 = inttoptr i64 %v8443 to ptr
  %v8445 = load i32, ptr %slot1411, align 8
  %call8446 = call i32 @myl_qbe_rc_status(ptr %p8444, i32 %v8445) nomerge, !dbg !166
  store i32 %call8446, ptr %slot1412, align 8
  br label %bb_failure
bb_rcsuccess1818:
  br label %bb_rcmoved1808
bb_rcmoved1808:
  %v8447 = load i64, ptr %slot23, align 8
  %p8448 = inttoptr i64 %v8447 to ptr
  store i32 0, ptr %p8448, align 4, !alias.scope !3, !noalias !4
  %v8449 = load i64, ptr %slot32, align 8
  %p8450 = inttoptr i64 %v8449 to ptr
  store i32 2, ptr %p8450, align 4, !alias.scope !3, !noalias !4
  %v8451 = load i64, ptr %slot31, align 8
  %p8452 = inttoptr i64 %v8451 to ptr
  store i32 1, ptr %p8452, align 4, !alias.scope !3, !noalias !4
  %v8453 = load i64, ptr %slot17, align 8
  %p8454 = inttoptr i64 %v8453 to ptr
  %ld8455 = load i32, ptr %p8454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8455, ptr %slot1413, align 8
  %v8456 = load i32, ptr %slot1413, align 8
  %cv8457 = zext i32 %v8456 to i64
  %cond8458 = icmp ne i64 %cv8457, 0
  br i1 %cond8458, label %bb_rcslotdrop1827, label %bb_rcslotdone1827
bb_rcslotdrop1827:
  %v8459 = load i64, ptr %slot17, align 8
  %p8460 = inttoptr i64 %v8459 to ptr
  store i32 0, ptr %p8460, align 4, !alias.scope !3, !noalias !4
  %v8461 = load i64, ptr %slot63, align 8
  store i64 %v8461, ptr %slot1414, align 8
  %v8462 = load i64, ptr %slot18, align 8
  %p8463 = inttoptr i64 %v8462 to ptr
  %ld8464 = load i32, ptr %p8463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8464, ptr %slot1415, align 8
  %v8465 = load i32, ptr %slot1415, align 8
  %op8466 = and i32 %v8465, 28
  store i32 %op8466, ptr %slot1416, align 8
  %v8467 = load i32, ptr %slot1416, align 8
  %cv8468 = zext i32 %v8467 to i64
  %cond8469 = icmp ne i64 %cv8468, 0
  br i1 %cond8469, label %bb_rcslotrole1827, label %bb_rcslotowner1827
bb_rcslotrole1827:
  %v8470 = load i64, ptr %slot88, align 8
  store i64 %v8470, ptr %slot1417, align 8
  %v8471 = load i64, ptr %slot1414, align 8
  %p8472 = inttoptr i64 %v8471 to ptr
  %ld8473 = load i64, ptr %p8472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8473, ptr %slot1418, align 8
  %v8474 = load i64, ptr %slot1418, align 8
  %cmp8475 = icmp ne i64 %v8474, 0
  %cv8476 = zext i1 %cmp8475 to i32
  store i32 %cv8476, ptr %slot1419, align 8
  %v8477 = load i32, ptr %slot1419, align 8
  %cv8478 = zext i32 %v8477 to i64
  %cond8479 = icmp ne i64 %cv8478, 0
  br i1 %cond8479, label %bb_rcgnn1843, label %bb_rcgdone1843
bb_rcgnn1843:
  %v8480 = load i64, ptr %slot1418, align 8
  %op8481 = sub i64 %v8480, 16
  store i64 %op8481, ptr %slot1420, align 8
  %v8482 = load i64, ptr %slot1418, align 8
  %p8483 = inttoptr i64 %v8482 to ptr
  %rgep8484 = getelementptr i8, ptr %p8483, i64 -16
  %ld8485 = load i64, ptr %rgep8484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8485, ptr %slot1421, align 8
  %v8486 = load i64, ptr %slot1421, align 8
  %op8487 = and i64 %v8486, 4611686018427387906
  store i64 %op8487, ptr %slot1422, align 8
  %v8488 = load i64, ptr %slot1422, align 8
  %cmp8489 = icmp ne i64 %v8488, 0
  %cv8490 = zext i1 %cmp8489 to i32
  store i32 %cv8490, ptr %slot1423, align 8
  %v8491 = load i32, ptr %slot1423, align 8
  %cv8492 = zext i32 %v8491 to i64
  %cond8493 = icmp ne i64 %cv8492, 0
  br i1 %cond8493, label %bb_rcgclear1843, label %bb_rcgcounted1843
bb_rcgcounted1843:
  %v8494 = load i64, ptr %slot1418, align 8
  %op8495 = sub i64 %v8494, 24
  store i64 %op8495, ptr %slot1424, align 8
  %v8496 = load i64, ptr %slot1418, align 8
  %p8497 = inttoptr i64 %v8496 to ptr
  %rgep8498 = getelementptr i8, ptr %p8497, i64 -24
  %ld8499 = load i64, ptr %rgep8498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8499, ptr %slot1425, align 8
  %v8500 = load i64, ptr %slot1425, align 8
  %op8501 = sub i64 %v8500, 1
  store i64 %op8501, ptr %slot1426, align 8
  %v8502 = load i64, ptr %slot1426, align 8
  %cmp8503 = icmp eq i64 %v8502, 0
  %cv8504 = zext i1 %cmp8503 to i32
  store i32 %cv8504, ptr %slot1427, align 8
  %v8505 = load i32, ptr %slot1427, align 8
  %cv8506 = zext i32 %v8505 to i64
  %cond8507 = icmp ne i64 %cv8506, 0
  br i1 %cond8507, label %bb_rcglast1843, label %bb_rcgdec1843
bb_rcglast1843:
  %v8508 = load i64, ptr %slot1418, align 8
  %op8509 = sub i64 %v8508, 32
  store i64 %op8509, ptr %slot1428, align 8
  %v8510 = load i64, ptr %slot1418, align 8
  %p8511 = inttoptr i64 %v8510 to ptr
  %rgep8512 = getelementptr i8, ptr %p8511, i64 -32
  %ld8513 = load i64, ptr %rgep8512, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8513, ptr %slot1429, align 8
  %v8514 = load i64, ptr %slot1429, align 8
  %cmp8515 = icmp ne i64 %v8514, 0
  %cv8516 = zext i1 %cmp8515 to i32
  store i32 %cv8516, ptr %slot1430, align 8
  %v8517 = load i32, ptr %slot1430, align 8
  %cv8518 = zext i32 %v8517 to i64
  %cond8519 = icmp ne i64 %cv8518, 0
  br i1 %cond8519, label %bb_rcgdec1843, label %bb_rcgslow1843
bb_rcgslow1843:
  %v8520 = load i64, ptr %slot1417, align 8
  %v8521 = load i64, ptr %slot1414, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8520, i64 %v8521) nomerge, !dbg !166
  br label %bb_rcgdone1843
bb_rcgdec1843:
  %v8522 = load i64, ptr %slot1426, align 8
  %v8523 = load i64, ptr %slot1418, align 8
  %p8524 = inttoptr i64 %v8523 to ptr
  %rgep8525 = getelementptr i8, ptr %p8524, i64 -24
  store i64 %v8522, ptr %rgep8525, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1843
bb_rcgclear1843:
  %v8526 = load i64, ptr %slot1414, align 8
  %p8527 = inttoptr i64 %v8526 to ptr
  store i64 0, ptr %p8527, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1843
bb_rcgdone1843:
  br label %bb_rcslotdone1827
bb_rcslotowner1827:
  %v8528 = load i64, ptr %slot88, align 8
  store i64 %v8528, ptr %slot1431, align 8
  %v8529 = load i64, ptr %slot1414, align 8
  %p8530 = inttoptr i64 %v8529 to ptr
  %ld8531 = load i64, ptr %p8530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8531, ptr %slot1432, align 8
  %v8532 = load i64, ptr %slot1432, align 8
  %cmp8533 = icmp ne i64 %v8532, 0
  %cv8534 = zext i1 %cmp8533 to i32
  store i32 %cv8534, ptr %slot1433, align 8
  %v8535 = load i32, ptr %slot1433, align 8
  %cv8536 = zext i32 %v8535 to i64
  %cond8537 = icmp ne i64 %cv8536, 0
  br i1 %cond8537, label %bb_rcgnn1858, label %bb_rcgdone1858
bb_rcgnn1858:
  %v8538 = load i64, ptr %slot1432, align 8
  %op8539 = sub i64 %v8538, 16
  store i64 %op8539, ptr %slot1434, align 8
  %v8540 = load i64, ptr %slot1432, align 8
  %p8541 = inttoptr i64 %v8540 to ptr
  %rgep8542 = getelementptr i8, ptr %p8541, i64 -16
  %ld8543 = load i64, ptr %rgep8542, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8543, ptr %slot1435, align 8
  %v8544 = load i64, ptr %slot1435, align 8
  %op8545 = and i64 %v8544, 4611686018427387906
  store i64 %op8545, ptr %slot1436, align 8
  %v8546 = load i64, ptr %slot1436, align 8
  %cmp8547 = icmp ne i64 %v8546, 0
  %cv8548 = zext i1 %cmp8547 to i32
  store i32 %cv8548, ptr %slot1437, align 8
  %v8549 = load i32, ptr %slot1437, align 8
  %cv8550 = zext i32 %v8549 to i64
  %cond8551 = icmp ne i64 %cv8550, 0
  br i1 %cond8551, label %bb_rcgclear1858, label %bb_rcgcounted1858
bb_rcgcounted1858:
  %v8552 = load i64, ptr %slot1432, align 8
  %op8553 = sub i64 %v8552, 32
  store i64 %op8553, ptr %slot1438, align 8
  %v8554 = load i64, ptr %slot1432, align 8
  %p8555 = inttoptr i64 %v8554 to ptr
  %rgep8556 = getelementptr i8, ptr %p8555, i64 -32
  %ld8557 = load i64, ptr %rgep8556, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8557, ptr %slot1439, align 8
  %v8558 = load i64, ptr %slot1439, align 8
  %op8559 = sub i64 %v8558, 1
  store i64 %op8559, ptr %slot1440, align 8
  %v8560 = load i64, ptr %slot1440, align 8
  %cmp8561 = icmp eq i64 %v8560, 0
  %cv8562 = zext i1 %cmp8561 to i32
  store i32 %cv8562, ptr %slot1441, align 8
  %v8563 = load i32, ptr %slot1441, align 8
  %cv8564 = zext i32 %v8563 to i64
  %cond8565 = icmp ne i64 %cv8564, 0
  br i1 %cond8565, label %bb_rcglast1858, label %bb_rcgdec1858
bb_rcglast1858:
  %v8566 = load i64, ptr %slot1432, align 8
  %op8567 = sub i64 %v8566, 24
  store i64 %op8567, ptr %slot1442, align 8
  %v8568 = load i64, ptr %slot1432, align 8
  %p8569 = inttoptr i64 %v8568 to ptr
  %rgep8570 = getelementptr i8, ptr %p8569, i64 -24
  %ld8571 = load i64, ptr %rgep8570, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8571, ptr %slot1443, align 8
  %v8572 = load i64, ptr %slot1443, align 8
  %cmp8573 = icmp ne i64 %v8572, 0
  %cv8574 = zext i1 %cmp8573 to i32
  store i32 %cv8574, ptr %slot1444, align 8
  %v8575 = load i32, ptr %slot1444, align 8
  %cv8576 = zext i32 %v8575 to i64
  %cond8577 = icmp ne i64 %cv8576, 0
  br i1 %cond8577, label %bb_rcgdec1858, label %bb_rcgslow1858
bb_rcgslow1858:
  %v8578 = load i64, ptr %slot1431, align 8
  %v8579 = load i64, ptr %slot1414, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8578, i64 %v8579) nomerge, !dbg !166
  br label %bb_rcgdone1858
bb_rcgdec1858:
  %v8580 = load i64, ptr %slot1440, align 8
  %v8581 = load i64, ptr %slot1432, align 8
  %p8582 = inttoptr i64 %v8581 to ptr
  %rgep8583 = getelementptr i8, ptr %p8582, i64 -32
  store i64 %v8580, ptr %rgep8583, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1858
bb_rcgclear1858:
  %v8584 = load i64, ptr %slot1414, align 8
  %p8585 = inttoptr i64 %v8584 to ptr
  store i64 0, ptr %p8585, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1858
bb_rcgdone1858:
  br label %bb_rcslotdone1827
bb_rcslotdone1827:
  %v8586 = load i64, ptr %slot63, align 8
  store i64 %v8586, ptr %slot1445, align 8
  %v8587 = load i64, ptr %slot42, align 8
  store i64 %v8587, ptr %slot1446, align 8
  %v8588 = load i64, ptr %slot1446, align 8
  %v8589 = load i64, ptr %slot1445, align 8
  %p8590 = inttoptr i64 %v8588 to ptr
  %p8591 = inttoptr i64 %v8589 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8591, ptr %p8590, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8592 = load i64, ptr %slot31, align 8
  %p8593 = inttoptr i64 %v8592 to ptr
  store i32 0, ptr %p8593, align 4, !alias.scope !3, !noalias !4
  %v8594 = load i64, ptr %slot18, align 8
  %p8595 = inttoptr i64 %v8594 to ptr
  store i32 2, ptr %p8595, align 4, !alias.scope !3, !noalias !4
  %v8596 = load i64, ptr %slot32, align 8
  %p8597 = inttoptr i64 %v8596 to ptr
  %ld8598 = load i32, ptr %p8597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8598, ptr %slot1447, align 8
  %v8599 = load i32, ptr %slot1447, align 8
  %v8600 = load i64, ptr %slot18, align 8
  %p8601 = inttoptr i64 %v8600 to ptr
  store i32 %v8599, ptr %p8601, align 4, !alias.scope !3, !noalias !4
  %v8602 = load i64, ptr %slot17, align 8
  %p8603 = inttoptr i64 %v8602 to ptr
  store i32 1, ptr %p8603, align 4, !alias.scope !3, !noalias !4
  %v8604 = load i64, ptr %slot52, align 8
  %p8605 = inttoptr i64 %v8604 to ptr
  %ld8606 = load i64, ptr %p8605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8606, ptr %slot1448, align 8
  %v8607 = load i64, ptr %slot1448, align 8
  %v8608 = load i64, ptr %slot68, align 8
  %p8609 = inttoptr i64 %v8608 to ptr
  store i64 %v8607, ptr %p8609, align 8, !alias.scope !3, !noalias !4
  %v8610 = load i64, ptr %slot79, align 8
  store i64 %v8610, ptr %slot1449, align 8
  %v8611 = load i64, ptr %slot1449, align 8
  %p8612 = inttoptr i64 %v8611 to ptr
  store i32 0, ptr %p8612, align 4, !alias.scope !3, !noalias !4
  %v8613 = load i64, ptr %slot1449, align 8
  %p8614 = inttoptr i64 %v8613 to ptr
  store i32 0, ptr %p8614, align 4, !alias.scope !3, !noalias !4
  %v8615 = load i64, ptr %slot1449, align 8
  %v8616 = load i64, ptr %slot69, align 8
  %p8617 = inttoptr i64 %v8616 to ptr
  store i64 %v8615, ptr %p8617, align 8, !alias.scope !3, !noalias !4
  %v8618 = load i64, ptr %slot69, align 8
  %p8619 = inttoptr i64 %v8618 to ptr
  %ld8620 = load i64, ptr %p8619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8620, ptr %slot1450, align 8
  %v8621 = load i64, ptr %slot68, align 8
  %p8622 = inttoptr i64 %v8621 to ptr
  %ld8623 = load i64, ptr %p8622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8623, ptr %slot1451, align 8
  %v8624 = load i64, ptr %slot1451, align 8
  %p8625 = inttoptr i64 %v8624 to ptr
  %ld8626 = load i32, ptr %p8625, align 4
  %ext8627 = zext i32 %ld8626 to i64
  store i64 %ext8627, ptr %slot1452, align 8
  %v8628 = load i64, ptr %slot1450, align 8
  %p8629 = inttoptr i64 %v8628 to ptr
  %ld8630 = load i32, ptr %p8629, align 4
  %ext8631 = zext i32 %ld8630 to i64
  store i64 %ext8631, ptr %slot1453, align 8
  %v8632 = load i64, ptr %slot1452, align 8
  %v8633 = load i64, ptr %slot1453, align 8
  %cmp8634 = icmp ne i64 %v8632, %v8633
  %cv8635 = zext i1 %cmp8634 to i64
  store i64 %cv8635, ptr %slot1454, align 8
  %v8636 = load i64, ptr %slot1454, align 8
  %v8637 = load i64, ptr %slot68, align 8
  %p8638 = inttoptr i64 %v8637 to ptr
  store i64 %v8636, ptr %p8638, align 8, !alias.scope !3, !noalias !4
  %v8639 = load i64, ptr %slot68, align 8
  %p8640 = inttoptr i64 %v8639 to ptr
  %ld8641 = load i64, ptr %p8640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8641, ptr %slot1455, align 8
  %v8642 = load i64, ptr %slot1455, align 8
  %cond8643 = icmp ne i64 %v8642, 0
  br i1 %cond8643, label %bb_next1877, label %bb_i103
bb_next1877:
  %p8644 = inttoptr i64 ptrtoint (ptr @myl_lit_ed133bb812ff429a6b7dcbb02ede97d61758e4fccb6ee5bb60d1ca8585bdd842 to i64) to ptr
  %ld8645 = load i64, ptr %p8644, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8645, ptr %slot1456, align 8
  %v8646 = load i64, ptr %slot1456, align 8
  %v8647 = load i64, ptr %slot68, align 8
  %p8648 = inttoptr i64 %v8647 to ptr
  store i64 %v8646, ptr %p8648, align 8, !alias.scope !3, !noalias !4
  %v8649 = load i64, ptr %slot68, align 8
  %p8650 = inttoptr i64 %v8649 to ptr
  %ld8651 = load i64, ptr %p8650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8651, ptr %slot1457, align 8
  %v8652 = load i64, ptr %slot1457, align 8
  %v8653 = load i64, ptr %slot38, align 8
  %p8654 = inttoptr i64 %v8653 to ptr
  store i64 %v8652, ptr %p8654, align 8, !alias.scope !3, !noalias !4
  %v8655 = load i64, ptr %slot38, align 8
  store i64 %v8655, ptr %slot1458, align 8
  %v8656 = load i64, ptr %slot42, align 8
  store i64 %v8656, ptr %slot1459, align 8
  %v8657 = load i64, ptr %slot1458, align 8
  %v8658 = load i64, ptr %slot1459, align 8
  %p8659 = inttoptr i64 %v8657 to ptr
  %p8660 = inttoptr i64 %v8658 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8660, ptr %p8659, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8661 = load i64, ptr %slot32, align 8
  %p8662 = inttoptr i64 %v8661 to ptr
  store i32 2, ptr %p8662, align 4, !alias.scope !3, !noalias !4
  %v8663 = load i64, ptr %slot31, align 8
  %p8664 = inttoptr i64 %v8663 to ptr
  store i32 1, ptr %p8664, align 4, !alias.scope !3, !noalias !4
  %v8665 = load i64, ptr %slot34, align 8
  store i64 %v8665, ptr %slot1460, align 8
  %v8666 = load i64, ptr %slot42, align 8
  store i64 %v8666, ptr %slot1461, align 8
  %v8667 = load i64, ptr %slot1461, align 8
  %v8668 = load i64, ptr %slot1460, align 8
  %p8669 = inttoptr i64 %v8667 to ptr
  %p8670 = inttoptr i64 %v8668 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8670, ptr %p8669, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8671 = load i64, ptr %slot24, align 8
  %p8672 = inttoptr i64 %v8671 to ptr
  store i32 2, ptr %p8672, align 4, !alias.scope !3, !noalias !4
  %v8673 = load i64, ptr %slot32, align 8
  %p8674 = inttoptr i64 %v8673 to ptr
  %ld8675 = load i32, ptr %p8674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8675, ptr %slot1462, align 8
  %v8676 = load i32, ptr %slot1462, align 8
  %v8677 = load i64, ptr %slot24, align 8
  %p8678 = inttoptr i64 %v8677 to ptr
  store i32 %v8676, ptr %p8678, align 4, !alias.scope !3, !noalias !4
  %v8679 = load i64, ptr %slot31, align 8
  %p8680 = inttoptr i64 %v8679 to ptr
  store i32 0, ptr %p8680, align 4, !alias.scope !3, !noalias !4
  %v8681 = load i64, ptr %slot23, align 8
  %p8682 = inttoptr i64 %v8681 to ptr
  store i32 1, ptr %p8682, align 4, !alias.scope !3, !noalias !4
  %v8683 = load i64, ptr %slot1460, align 8
  %p8684 = inttoptr i64 %v8683 to ptr
  %ld8685 = load i64, ptr %p8684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8685, ptr %slot1463, align 8
  %v8686 = load i64, ptr %slot1463, align 8
  %v8687 = load i64, ptr %slot68, align 8
  %p8688 = inttoptr i64 %v8687 to ptr
  store i64 %v8686, ptr %p8688, align 8, !alias.scope !3, !noalias !4
  %v8689 = load i64, ptr %slot68, align 8
  %p8690 = inttoptr i64 %v8689 to ptr
  %ld8691 = load i64, ptr %p8690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8691, ptr %slot1464, align 8
  %v8692 = load i64, ptr %slot1464, align 8
  %v8693 = load i64, ptr %slot38, align 8
  %p8694 = inttoptr i64 %v8693 to ptr
  store i64 %v8692, ptr %p8694, align 8, !alias.scope !3, !noalias !4
  %v8695 = load i64, ptr %slot38, align 8
  store i64 %v8695, ptr %slot1465, align 8
  %v8696 = load i64, ptr %slot42, align 8
  store i64 %v8696, ptr %slot1466, align 8
  %v8697 = load i64, ptr %slot89, align 8
  store i64 %v8697, ptr %slot1467, align 8
  %v8698 = load i64, ptr %slot1465, align 8
  %p8700 = inttoptr i64 %v8698 to ptr
  %gep8701 = getelementptr i8, ptr %p8700, i64 0
  %op8699 = ptrtoint ptr %gep8701 to i64
  store i64 %op8699, ptr %slot1468, align 8
  %v8702 = load i64, ptr %slot1468, align 8
  %p8703 = inttoptr i64 %v8702 to ptr
  %ld8704 = load i64, ptr %p8703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8704, ptr %slot1469, align 8
  %v8705 = load i64, ptr %slot1469, align 8
  %cmp8706 = icmp ne i64 %v8705, 0
  %cv8707 = zext i1 %cmp8706 to i32
  store i32 %cv8707, ptr %slot1470, align 8
  %v8708 = load i32, ptr %slot1470, align 8
  %cv8709 = zext i32 %v8708 to i64
  %cond8710 = icmp ne i64 %cv8709, 0
  br i1 %cond8710, label %bb_rcmoveheader1900, label %bb_rcmovenext1900
bb_rcmoveheader1900:
  %v8711 = load i64, ptr %slot1469, align 8
  %op8712 = sub i64 %v8711, 16
  store i64 %op8712, ptr %slot1471, align 8
  %v8713 = load i64, ptr %slot1469, align 8
  %p8714 = inttoptr i64 %v8713 to ptr
  %rgep8715 = getelementptr i8, ptr %p8714, i64 -16
  %ld8716 = load i64, ptr %rgep8715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8716, ptr %slot1472, align 8
  %v8717 = load i64, ptr %slot1472, align 8
  %op8718 = and i64 %v8717, 5764607523034234881
  store i64 %op8718, ptr %slot1473, align 8
  %v8719 = load i64, ptr %slot1473, align 8
  %cmp8720 = icmp ne i64 %v8719, 0
  %cv8721 = zext i1 %cmp8720 to i32
  store i32 %cv8721, ptr %slot1474, align 8
  %v8722 = load i32, ptr %slot1474, align 8
  %cv8723 = zext i32 %v8722 to i64
  %cond8724 = icmp ne i64 %cv8723, 0
  br i1 %cond8724, label %bb_rcmoveslow1897, label %bb_rcmovenext1900
bb_rcmovenext1900:
  %v8725 = load i64, ptr %slot1465, align 8
  %v8726 = load i64, ptr %slot1466, align 8
  %p8727 = inttoptr i64 %v8725 to ptr
  %p8728 = inttoptr i64 %v8726 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8728, ptr %p8727, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8729 = load i64, ptr %slot1465, align 8
  %p8730 = inttoptr i64 %v8729 to ptr
  store i64 0, ptr %p8730, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1897
bb_rcmoveslow1897:
  %v8731 = load i64, ptr %slot88, align 8
  %v8732 = load i64, ptr %slot1466, align 8
  %v8733 = load i64, ptr %slot1465, align 8
  %v8734 = load i64, ptr %slot1467, align 8
  %cv8735 = trunc i64 %v8734 to i32
  %call8736 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v8731, i64 %v8732, i64 %v8733, i32 %cv8735) nomerge, !dbg !168
  store i32 %call8736, ptr %slot1475, align 8
  %v8737 = load i32, ptr %slot1475, align 8
  %cv8738 = zext i32 %v8737 to i64
  %cond8739 = icmp ne i64 %cv8738, 0
  br i1 %cond8739, label %bb_rcsuccess1907, label %bb_rcfailure1907
bb_rcfailure1907:
  %v8740 = load i64, ptr %slot88, align 8
  %p8741 = inttoptr i64 %v8740 to ptr
  %call8742 = call i32 @myl_rc_take_failure(ptr %p8741) nomerge, !dbg !168
  store i32 %call8742, ptr %slot1476, align 8
  %v8743 = load i64, ptr %slot1, align 8
  %p8744 = inttoptr i64 %v8743 to ptr
  %v8745 = load i32, ptr %slot1476, align 8
  %call8746 = call i32 @myl_qbe_rc_status(ptr %p8744, i32 %v8745) nomerge, !dbg !168
  store i32 %call8746, ptr %slot1477, align 8
  br label %bb_failure
bb_rcsuccess1907:
  br label %bb_rcmoved1897
bb_rcmoved1897:
  %v8747 = load i64, ptr %slot23, align 8
  %p8748 = inttoptr i64 %v8747 to ptr
  store i32 0, ptr %p8748, align 4, !alias.scope !3, !noalias !4
  %v8749 = load i64, ptr %slot32, align 8
  %p8750 = inttoptr i64 %v8749 to ptr
  store i32 2, ptr %p8750, align 4, !alias.scope !3, !noalias !4
  %v8751 = load i64, ptr %slot31, align 8
  %p8752 = inttoptr i64 %v8751 to ptr
  store i32 1, ptr %p8752, align 4, !alias.scope !3, !noalias !4
  %v8753 = load i64, ptr %slot17, align 8
  %p8754 = inttoptr i64 %v8753 to ptr
  %ld8755 = load i32, ptr %p8754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8755, ptr %slot1478, align 8
  %v8756 = load i32, ptr %slot1478, align 8
  %cv8757 = zext i32 %v8756 to i64
  %cond8758 = icmp ne i64 %cv8757, 0
  br i1 %cond8758, label %bb_rcslotdrop1916, label %bb_rcslotdone1916
bb_rcslotdrop1916:
  %v8759 = load i64, ptr %slot17, align 8
  %p8760 = inttoptr i64 %v8759 to ptr
  store i32 0, ptr %p8760, align 4, !alias.scope !3, !noalias !4
  %v8761 = load i64, ptr %slot63, align 8
  store i64 %v8761, ptr %slot1479, align 8
  %v8762 = load i64, ptr %slot18, align 8
  %p8763 = inttoptr i64 %v8762 to ptr
  %ld8764 = load i32, ptr %p8763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8764, ptr %slot1480, align 8
  %v8765 = load i32, ptr %slot1480, align 8
  %op8766 = and i32 %v8765, 28
  store i32 %op8766, ptr %slot1481, align 8
  %v8767 = load i32, ptr %slot1481, align 8
  %cv8768 = zext i32 %v8767 to i64
  %cond8769 = icmp ne i64 %cv8768, 0
  br i1 %cond8769, label %bb_rcslotrole1916, label %bb_rcslotowner1916
bb_rcslotrole1916:
  %v8770 = load i64, ptr %slot88, align 8
  store i64 %v8770, ptr %slot1482, align 8
  %v8771 = load i64, ptr %slot1479, align 8
  %p8772 = inttoptr i64 %v8771 to ptr
  %ld8773 = load i64, ptr %p8772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8773, ptr %slot1483, align 8
  %v8774 = load i64, ptr %slot1483, align 8
  %cmp8775 = icmp ne i64 %v8774, 0
  %cv8776 = zext i1 %cmp8775 to i32
  store i32 %cv8776, ptr %slot1484, align 8
  %v8777 = load i32, ptr %slot1484, align 8
  %cv8778 = zext i32 %v8777 to i64
  %cond8779 = icmp ne i64 %cv8778, 0
  br i1 %cond8779, label %bb_rcgnn1932, label %bb_rcgdone1932
bb_rcgnn1932:
  %v8780 = load i64, ptr %slot1483, align 8
  %op8781 = sub i64 %v8780, 16
  store i64 %op8781, ptr %slot1485, align 8
  %v8782 = load i64, ptr %slot1483, align 8
  %p8783 = inttoptr i64 %v8782 to ptr
  %rgep8784 = getelementptr i8, ptr %p8783, i64 -16
  %ld8785 = load i64, ptr %rgep8784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8785, ptr %slot1486, align 8
  %v8786 = load i64, ptr %slot1486, align 8
  %op8787 = and i64 %v8786, 4611686018427387906
  store i64 %op8787, ptr %slot1487, align 8
  %v8788 = load i64, ptr %slot1487, align 8
  %cmp8789 = icmp ne i64 %v8788, 0
  %cv8790 = zext i1 %cmp8789 to i32
  store i32 %cv8790, ptr %slot1488, align 8
  %v8791 = load i32, ptr %slot1488, align 8
  %cv8792 = zext i32 %v8791 to i64
  %cond8793 = icmp ne i64 %cv8792, 0
  br i1 %cond8793, label %bb_rcgclear1932, label %bb_rcgcounted1932
bb_rcgcounted1932:
  %v8794 = load i64, ptr %slot1483, align 8
  %op8795 = sub i64 %v8794, 24
  store i64 %op8795, ptr %slot1489, align 8
  %v8796 = load i64, ptr %slot1483, align 8
  %p8797 = inttoptr i64 %v8796 to ptr
  %rgep8798 = getelementptr i8, ptr %p8797, i64 -24
  %ld8799 = load i64, ptr %rgep8798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8799, ptr %slot1490, align 8
  %v8800 = load i64, ptr %slot1490, align 8
  %op8801 = sub i64 %v8800, 1
  store i64 %op8801, ptr %slot1491, align 8
  %v8802 = load i64, ptr %slot1491, align 8
  %cmp8803 = icmp eq i64 %v8802, 0
  %cv8804 = zext i1 %cmp8803 to i32
  store i32 %cv8804, ptr %slot1492, align 8
  %v8805 = load i32, ptr %slot1492, align 8
  %cv8806 = zext i32 %v8805 to i64
  %cond8807 = icmp ne i64 %cv8806, 0
  br i1 %cond8807, label %bb_rcglast1932, label %bb_rcgdec1932
bb_rcglast1932:
  %v8808 = load i64, ptr %slot1483, align 8
  %op8809 = sub i64 %v8808, 32
  store i64 %op8809, ptr %slot1493, align 8
  %v8810 = load i64, ptr %slot1483, align 8
  %p8811 = inttoptr i64 %v8810 to ptr
  %rgep8812 = getelementptr i8, ptr %p8811, i64 -32
  %ld8813 = load i64, ptr %rgep8812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8813, ptr %slot1494, align 8
  %v8814 = load i64, ptr %slot1494, align 8
  %cmp8815 = icmp ne i64 %v8814, 0
  %cv8816 = zext i1 %cmp8815 to i32
  store i32 %cv8816, ptr %slot1495, align 8
  %v8817 = load i32, ptr %slot1495, align 8
  %cv8818 = zext i32 %v8817 to i64
  %cond8819 = icmp ne i64 %cv8818, 0
  br i1 %cond8819, label %bb_rcgdec1932, label %bb_rcgslow1932
bb_rcgslow1932:
  %v8820 = load i64, ptr %slot1482, align 8
  %v8821 = load i64, ptr %slot1479, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8820, i64 %v8821) nomerge, !dbg !168
  br label %bb_rcgdone1932
bb_rcgdec1932:
  %v8822 = load i64, ptr %slot1491, align 8
  %v8823 = load i64, ptr %slot1483, align 8
  %p8824 = inttoptr i64 %v8823 to ptr
  %rgep8825 = getelementptr i8, ptr %p8824, i64 -24
  store i64 %v8822, ptr %rgep8825, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1932
bb_rcgclear1932:
  %v8826 = load i64, ptr %slot1479, align 8
  %p8827 = inttoptr i64 %v8826 to ptr
  store i64 0, ptr %p8827, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1932
bb_rcgdone1932:
  br label %bb_rcslotdone1916
bb_rcslotowner1916:
  %v8828 = load i64, ptr %slot88, align 8
  store i64 %v8828, ptr %slot1496, align 8
  %v8829 = load i64, ptr %slot1479, align 8
  %p8830 = inttoptr i64 %v8829 to ptr
  %ld8831 = load i64, ptr %p8830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8831, ptr %slot1497, align 8
  %v8832 = load i64, ptr %slot1497, align 8
  %cmp8833 = icmp ne i64 %v8832, 0
  %cv8834 = zext i1 %cmp8833 to i32
  store i32 %cv8834, ptr %slot1498, align 8
  %v8835 = load i32, ptr %slot1498, align 8
  %cv8836 = zext i32 %v8835 to i64
  %cond8837 = icmp ne i64 %cv8836, 0
  br i1 %cond8837, label %bb_rcgnn1947, label %bb_rcgdone1947
bb_rcgnn1947:
  %v8838 = load i64, ptr %slot1497, align 8
  %op8839 = sub i64 %v8838, 16
  store i64 %op8839, ptr %slot1499, align 8
  %v8840 = load i64, ptr %slot1497, align 8
  %p8841 = inttoptr i64 %v8840 to ptr
  %rgep8842 = getelementptr i8, ptr %p8841, i64 -16
  %ld8843 = load i64, ptr %rgep8842, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8843, ptr %slot1500, align 8
  %v8844 = load i64, ptr %slot1500, align 8
  %op8845 = and i64 %v8844, 4611686018427387906
  store i64 %op8845, ptr %slot1501, align 8
  %v8846 = load i64, ptr %slot1501, align 8
  %cmp8847 = icmp ne i64 %v8846, 0
  %cv8848 = zext i1 %cmp8847 to i32
  store i32 %cv8848, ptr %slot1502, align 8
  %v8849 = load i32, ptr %slot1502, align 8
  %cv8850 = zext i32 %v8849 to i64
  %cond8851 = icmp ne i64 %cv8850, 0
  br i1 %cond8851, label %bb_rcgclear1947, label %bb_rcgcounted1947
bb_rcgcounted1947:
  %v8852 = load i64, ptr %slot1497, align 8
  %op8853 = sub i64 %v8852, 32
  store i64 %op8853, ptr %slot1503, align 8
  %v8854 = load i64, ptr %slot1497, align 8
  %p8855 = inttoptr i64 %v8854 to ptr
  %rgep8856 = getelementptr i8, ptr %p8855, i64 -32
  %ld8857 = load i64, ptr %rgep8856, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8857, ptr %slot1504, align 8
  %v8858 = load i64, ptr %slot1504, align 8
  %op8859 = sub i64 %v8858, 1
  store i64 %op8859, ptr %slot1505, align 8
  %v8860 = load i64, ptr %slot1505, align 8
  %cmp8861 = icmp eq i64 %v8860, 0
  %cv8862 = zext i1 %cmp8861 to i32
  store i32 %cv8862, ptr %slot1506, align 8
  %v8863 = load i32, ptr %slot1506, align 8
  %cv8864 = zext i32 %v8863 to i64
  %cond8865 = icmp ne i64 %cv8864, 0
  br i1 %cond8865, label %bb_rcglast1947, label %bb_rcgdec1947
bb_rcglast1947:
  %v8866 = load i64, ptr %slot1497, align 8
  %op8867 = sub i64 %v8866, 24
  store i64 %op8867, ptr %slot1507, align 8
  %v8868 = load i64, ptr %slot1497, align 8
  %p8869 = inttoptr i64 %v8868 to ptr
  %rgep8870 = getelementptr i8, ptr %p8869, i64 -24
  %ld8871 = load i64, ptr %rgep8870, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8871, ptr %slot1508, align 8
  %v8872 = load i64, ptr %slot1508, align 8
  %cmp8873 = icmp ne i64 %v8872, 0
  %cv8874 = zext i1 %cmp8873 to i32
  store i32 %cv8874, ptr %slot1509, align 8
  %v8875 = load i32, ptr %slot1509, align 8
  %cv8876 = zext i32 %v8875 to i64
  %cond8877 = icmp ne i64 %cv8876, 0
  br i1 %cond8877, label %bb_rcgdec1947, label %bb_rcgslow1947
bb_rcgslow1947:
  %v8878 = load i64, ptr %slot1496, align 8
  %v8879 = load i64, ptr %slot1479, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8878, i64 %v8879) nomerge, !dbg !168
  br label %bb_rcgdone1947
bb_rcgdec1947:
  %v8880 = load i64, ptr %slot1505, align 8
  %v8881 = load i64, ptr %slot1497, align 8
  %p8882 = inttoptr i64 %v8881 to ptr
  %rgep8883 = getelementptr i8, ptr %p8882, i64 -32
  store i64 %v8880, ptr %rgep8883, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1947
bb_rcgclear1947:
  %v8884 = load i64, ptr %slot1479, align 8
  %p8885 = inttoptr i64 %v8884 to ptr
  store i64 0, ptr %p8885, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1947
bb_rcgdone1947:
  br label %bb_rcslotdone1916
bb_rcslotdone1916:
  %v8886 = load i64, ptr %slot63, align 8
  store i64 %v8886, ptr %slot1510, align 8
  %v8887 = load i64, ptr %slot42, align 8
  store i64 %v8887, ptr %slot1511, align 8
  %v8888 = load i64, ptr %slot1511, align 8
  %v8889 = load i64, ptr %slot1510, align 8
  %p8890 = inttoptr i64 %v8888 to ptr
  %p8891 = inttoptr i64 %v8889 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8891, ptr %p8890, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8892 = load i64, ptr %slot31, align 8
  %p8893 = inttoptr i64 %v8892 to ptr
  store i32 0, ptr %p8893, align 4, !alias.scope !3, !noalias !4
  %v8894 = load i64, ptr %slot18, align 8
  %p8895 = inttoptr i64 %v8894 to ptr
  store i32 2, ptr %p8895, align 4, !alias.scope !3, !noalias !4
  %v8896 = load i64, ptr %slot32, align 8
  %p8897 = inttoptr i64 %v8896 to ptr
  %ld8898 = load i32, ptr %p8897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8898, ptr %slot1512, align 8
  %v8899 = load i32, ptr %slot1512, align 8
  %v8900 = load i64, ptr %slot18, align 8
  %p8901 = inttoptr i64 %v8900 to ptr
  store i32 %v8899, ptr %p8901, align 4, !alias.scope !3, !noalias !4
  %v8902 = load i64, ptr %slot17, align 8
  %p8903 = inttoptr i64 %v8902 to ptr
  store i32 1, ptr %p8903, align 4, !alias.scope !3, !noalias !4
  br label %bb_i103
bb_i103:
  %v8904 = load i64, ptr %slot59, align 8
  %v8905 = load i64, ptr %slot68, align 8
  %p8906 = inttoptr i64 %v8905 to ptr
  store i64 %v8904, ptr %p8906, align 8, !alias.scope !3, !noalias !4
  %v8907 = load i64, ptr %slot68, align 8
  %p8908 = inttoptr i64 %v8907 to ptr
  %ld8909 = load i64, ptr %p8908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8909, ptr %slot1513, align 8
  %v8910 = load i64, ptr %slot1513, align 8
  %op8911 = add i64 %v8910, 64
  store i64 %op8911, ptr %slot1514, align 8
  %v8912 = load i64, ptr %slot1514, align 8
  %p8913 = inttoptr i64 %v8912 to ptr
  %ld8914 = load i64, ptr %p8913, align 8
  store i64 %ld8914, ptr %slot1515, align 8
  %v8915 = load i64, ptr %slot1515, align 8
  %v8916 = load i64, ptr %slot68, align 8
  %p8917 = inttoptr i64 %v8916 to ptr
  store i64 %v8915, ptr %p8917, align 8, !alias.scope !3, !noalias !4
  %v8918 = load i64, ptr %slot68, align 8
  %p8919 = inttoptr i64 %v8918 to ptr
  %ld8920 = load i64, ptr %p8919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8920, ptr %slot1516, align 8
  %v8921 = load i64, ptr %slot1516, align 8
  %v8922 = load i64, ptr %slot38, align 8
  %p8923 = inttoptr i64 %v8922 to ptr
  store i64 %v8921, ptr %p8923, align 8, !alias.scope !3, !noalias !4
  %v8924 = load i64, ptr %slot38, align 8
  store i64 %v8924, ptr %slot1517, align 8
  %v8925 = load i64, ptr %slot42, align 8
  store i64 %v8925, ptr %slot1518, align 8
  %v8926 = load i64, ptr %slot1517, align 8
  %p8927 = inttoptr i64 %v8926 to ptr
  %ld8928 = load i64, ptr %p8927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8928, ptr %slot1519, align 8
  %v8929 = load i64, ptr %slot1519, align 8
  %cmp8930 = icmp ne i64 %v8929, 0
  %cv8931 = zext i1 %cmp8930 to i32
  store i32 %cv8931, ptr %slot1520, align 8
  %v8932 = load i32, ptr %slot1520, align 8
  %cv8933 = zext i32 %v8932 to i64
  %cond8934 = icmp ne i64 %cv8933, 0
  br i1 %cond8934, label %bb_rcgnn1965, label %bb_rcgstore1965
bb_rcgnn1965:
  %v8935 = load i64, ptr %slot1519, align 8
  %op8936 = sub i64 %v8935, 16
  store i64 %op8936, ptr %slot1521, align 8
  %v8937 = load i64, ptr %slot1519, align 8
  %p8938 = inttoptr i64 %v8937 to ptr
  %rgep8939 = getelementptr i8, ptr %p8938, i64 -16
  %ld8940 = load i64, ptr %rgep8939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8940, ptr %slot1522, align 8
  %v8941 = load i64, ptr %slot1522, align 8
  %op8942 = and i64 %v8941, 4611686018427387906
  store i64 %op8942, ptr %slot1523, align 8
  %v8943 = load i64, ptr %slot1523, align 8
  %cmp8944 = icmp ne i64 %v8943, 0
  %cv8945 = zext i1 %cmp8944 to i32
  store i32 %cv8945, ptr %slot1524, align 8
  %v8946 = load i32, ptr %slot1524, align 8
  %cv8947 = zext i32 %v8946 to i64
  %cond8948 = icmp ne i64 %cv8947, 0
  br i1 %cond8948, label %bb_rcgstore1965, label %bb_rcginc1965
bb_rcginc1965:
  %v8949 = load i64, ptr %slot1519, align 8
  %op8950 = sub i64 %v8949, 24
  store i64 %op8950, ptr %slot1525, align 8
  %v8951 = load i64, ptr %slot1519, align 8
  %p8952 = inttoptr i64 %v8951 to ptr
  %rgep8953 = getelementptr i8, ptr %p8952, i64 -24
  %ld8954 = load i64, ptr %rgep8953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8954, ptr %slot1526, align 8
  %v8955 = load i64, ptr %slot1526, align 8
  %op8956 = add i64 %v8955, 1
  store i64 %op8956, ptr %slot1527, align 8
  %v8957 = load i64, ptr %slot1527, align 8
  %cmp8958 = icmp eq i64 %v8957, 0
  %cv8959 = zext i1 %cmp8958 to i32
  store i32 %cv8959, ptr %slot1528, align 8
  %v8960 = load i32, ptr %slot1528, align 8
  %cv8961 = zext i32 %v8960 to i64
  %cond8962 = icmp ne i64 %cv8961, 0
  br i1 %cond8962, label %bb_rcglimit1965, label %bb_rcgcapacity1965
bb_rcglimit1965:
  %v8963 = load i64, ptr %slot1, align 8
  %p8964 = inttoptr i64 %v8963 to ptr
  %call8965 = call i32 @myl_qbe_rc_status(ptr %p8964, i32 2) nomerge, !dbg !170
  store i32 %call8965, ptr %slot1529, align 8
  br label %bb_failure
bb_rcgcapacity1965:
  %v8966 = load i64, ptr %slot1527, align 8
  %v8967 = load i64, ptr %slot1519, align 8
  %p8968 = inttoptr i64 %v8967 to ptr
  %rgep8969 = getelementptr i8, ptr %p8968, i64 -24
  store i64 %v8966, ptr %rgep8969, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1965
bb_rcgstore1965:
  %v8970 = load i64, ptr %slot1519, align 8
  %v8971 = load i64, ptr %slot1518, align 8
  %p8972 = inttoptr i64 %v8971 to ptr
  store i64 %v8970, ptr %p8972, align 8, !alias.scope !3, !noalias !4
  %v8973 = load i64, ptr %slot32, align 8
  %p8974 = inttoptr i64 %v8973 to ptr
  store i32 2, ptr %p8974, align 4, !alias.scope !3, !noalias !4
  %v8975 = load i64, ptr %slot32, align 8
  %p8976 = inttoptr i64 %v8975 to ptr
  store i32 16, ptr %p8976, align 4, !alias.scope !3, !noalias !4
  %v8977 = load i64, ptr %slot31, align 8
  %p8978 = inttoptr i64 %v8977 to ptr
  store i32 1, ptr %p8978, align 4, !alias.scope !3, !noalias !4
  %v8979 = load i64, ptr %slot23, align 8
  %p8980 = inttoptr i64 %v8979 to ptr
  %ld8981 = load i32, ptr %p8980, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8981, ptr %slot1530, align 8
  %v8982 = load i32, ptr %slot1530, align 8
  %cv8983 = zext i32 %v8982 to i64
  %cond8984 = icmp ne i64 %cv8983, 0
  br i1 %cond8984, label %bb_rcslotdrop1981, label %bb_rcslotdone1981
bb_rcslotdrop1981:
  %v8985 = load i64, ptr %slot23, align 8
  %p8986 = inttoptr i64 %v8985 to ptr
  store i32 0, ptr %p8986, align 4, !alias.scope !3, !noalias !4
  %v8987 = load i64, ptr %slot34, align 8
  store i64 %v8987, ptr %slot1531, align 8
  %v8988 = load i64, ptr %slot24, align 8
  %p8989 = inttoptr i64 %v8988 to ptr
  %ld8990 = load i32, ptr %p8989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8990, ptr %slot1532, align 8
  %v8991 = load i32, ptr %slot1532, align 8
  %op8992 = and i32 %v8991, 28
  store i32 %op8992, ptr %slot1533, align 8
  %v8993 = load i32, ptr %slot1533, align 8
  %cv8994 = zext i32 %v8993 to i64
  %cond8995 = icmp ne i64 %cv8994, 0
  br i1 %cond8995, label %bb_rcslotrole1981, label %bb_rcslotowner1981
bb_rcslotrole1981:
  %v8996 = load i64, ptr %slot88, align 8
  store i64 %v8996, ptr %slot1534, align 8
  %v8997 = load i64, ptr %slot1534, align 8
  %v8998 = load i64, ptr %slot1531, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v8997, i64 %v8998) nomerge, !dbg !170
  br label %bb_rcslotdone1981
bb_rcslotowner1981:
  %v8999 = load i64, ptr %slot88, align 8
  store i64 %v8999, ptr %slot1535, align 8
  %v9000 = load i64, ptr %slot1535, align 8
  %v9001 = load i64, ptr %slot1531, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v9000, i64 %v9001) nomerge, !dbg !170
  br label %bb_rcslotdone1981
bb_rcslotdone1981:
  %v9002 = load i64, ptr %slot34, align 8
  store i64 %v9002, ptr %slot1536, align 8
  %v9003 = load i64, ptr %slot42, align 8
  store i64 %v9003, ptr %slot1537, align 8
  %v9004 = load i64, ptr %slot1537, align 8
  %v9005 = load i64, ptr %slot1536, align 8
  %p9006 = inttoptr i64 %v9004 to ptr
  %p9007 = inttoptr i64 %v9005 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9007, ptr %p9006, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9008 = load i64, ptr %slot24, align 8
  %p9009 = inttoptr i64 %v9008 to ptr
  store i32 2, ptr %p9009, align 4, !alias.scope !3, !noalias !4
  %v9010 = load i64, ptr %slot32, align 8
  %p9011 = inttoptr i64 %v9010 to ptr
  %ld9012 = load i32, ptr %p9011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9012, ptr %slot1538, align 8
  %v9013 = load i32, ptr %slot1538, align 8
  %v9014 = load i64, ptr %slot24, align 8
  %p9015 = inttoptr i64 %v9014 to ptr
  store i32 %v9013, ptr %p9015, align 4, !alias.scope !3, !noalias !4
  %v9016 = load i64, ptr %slot31, align 8
  %p9017 = inttoptr i64 %v9016 to ptr
  store i32 0, ptr %p9017, align 4, !alias.scope !3, !noalias !4
  %v9018 = load i64, ptr %slot23, align 8
  %p9019 = inttoptr i64 %v9018 to ptr
  store i32 1, ptr %p9019, align 4, !alias.scope !3, !noalias !4
  %v9020 = load i64, ptr %slot1536, align 8
  %p9021 = inttoptr i64 %v9020 to ptr
  %ld9022 = load i64, ptr %p9021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9022, ptr %slot1539, align 8
  %v9023 = load i64, ptr %slot1539, align 8
  %v9024 = load i64, ptr %slot68, align 8
  %p9025 = inttoptr i64 %v9024 to ptr
  store i64 %v9023, ptr %p9025, align 8, !alias.scope !3, !noalias !4
  %v9026 = load i64, ptr %slot68, align 8
  %p9027 = inttoptr i64 %v9026 to ptr
  %ld9028 = load i64, ptr %p9027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9028, ptr %slot1540, align 8
  %v9029 = load i64, ptr %slot59, align 8
  store i64 %v9029, ptr %slot1541, align 8
  %v9030 = load i64, ptr %slot23, align 8
  %p9031 = inttoptr i64 %v9030 to ptr
  %ld9032 = load i32, ptr %p9031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9032, ptr %slot1542, align 8
  %v9033 = load i32, ptr %slot1542, align 8
  %cv9034 = zext i32 %v9033 to i64
  %cond9035 = icmp ne i64 %cv9034, 0
  br i1 %cond9035, label %bb_rcslotdrop2002, label %bb_rcslotdone2002
bb_rcslotdrop2002:
  %v9036 = load i64, ptr %slot23, align 8
  %p9037 = inttoptr i64 %v9036 to ptr
  store i32 0, ptr %p9037, align 4, !alias.scope !3, !noalias !4
  %v9038 = load i64, ptr %slot34, align 8
  store i64 %v9038, ptr %slot1543, align 8
  %v9039 = load i64, ptr %slot24, align 8
  %p9040 = inttoptr i64 %v9039 to ptr
  %ld9041 = load i32, ptr %p9040, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9041, ptr %slot1544, align 8
  %v9042 = load i32, ptr %slot1544, align 8
  %op9043 = and i32 %v9042, 28
  store i32 %op9043, ptr %slot1545, align 8
  %v9044 = load i32, ptr %slot1545, align 8
  %cv9045 = zext i32 %v9044 to i64
  %cond9046 = icmp ne i64 %cv9045, 0
  br i1 %cond9046, label %bb_rcslotrole2002, label %bb_rcslotowner2002
bb_rcslotrole2002:
  %v9047 = load i64, ptr %slot88, align 8
  store i64 %v9047, ptr %slot1546, align 8
  %v9048 = load i64, ptr %slot1543, align 8
  %p9049 = inttoptr i64 %v9048 to ptr
  %ld9050 = load i64, ptr %p9049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9050, ptr %slot1547, align 8
  %v9051 = load i64, ptr %slot1547, align 8
  %cmp9052 = icmp ne i64 %v9051, 0
  %cv9053 = zext i1 %cmp9052 to i32
  store i32 %cv9053, ptr %slot1548, align 8
  %v9054 = load i32, ptr %slot1548, align 8
  %cv9055 = zext i32 %v9054 to i64
  %cond9056 = icmp ne i64 %cv9055, 0
  br i1 %cond9056, label %bb_rcgnn2018, label %bb_rcgdone2018
bb_rcgnn2018:
  %v9057 = load i64, ptr %slot1547, align 8
  %op9058 = sub i64 %v9057, 16
  store i64 %op9058, ptr %slot1549, align 8
  %v9059 = load i64, ptr %slot1547, align 8
  %p9060 = inttoptr i64 %v9059 to ptr
  %rgep9061 = getelementptr i8, ptr %p9060, i64 -16
  %ld9062 = load i64, ptr %rgep9061, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9062, ptr %slot1550, align 8
  %v9063 = load i64, ptr %slot1550, align 8
  %op9064 = and i64 %v9063, 4611686018427387906
  store i64 %op9064, ptr %slot1551, align 8
  %v9065 = load i64, ptr %slot1551, align 8
  %cmp9066 = icmp ne i64 %v9065, 0
  %cv9067 = zext i1 %cmp9066 to i32
  store i32 %cv9067, ptr %slot1552, align 8
  %v9068 = load i32, ptr %slot1552, align 8
  %cv9069 = zext i32 %v9068 to i64
  %cond9070 = icmp ne i64 %cv9069, 0
  br i1 %cond9070, label %bb_rcgclear2018, label %bb_rcgcounted2018
bb_rcgcounted2018:
  %v9071 = load i64, ptr %slot1547, align 8
  %op9072 = sub i64 %v9071, 24
  store i64 %op9072, ptr %slot1553, align 8
  %v9073 = load i64, ptr %slot1547, align 8
  %p9074 = inttoptr i64 %v9073 to ptr
  %rgep9075 = getelementptr i8, ptr %p9074, i64 -24
  %ld9076 = load i64, ptr %rgep9075, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9076, ptr %slot1554, align 8
  %v9077 = load i64, ptr %slot1554, align 8
  %op9078 = sub i64 %v9077, 1
  store i64 %op9078, ptr %slot1555, align 8
  %v9079 = load i64, ptr %slot1555, align 8
  %cmp9080 = icmp eq i64 %v9079, 0
  %cv9081 = zext i1 %cmp9080 to i32
  store i32 %cv9081, ptr %slot1556, align 8
  %v9082 = load i32, ptr %slot1556, align 8
  %cv9083 = zext i32 %v9082 to i64
  %cond9084 = icmp ne i64 %cv9083, 0
  br i1 %cond9084, label %bb_rcglast2018, label %bb_rcgdec2018
bb_rcglast2018:
  %v9085 = load i64, ptr %slot1547, align 8
  %op9086 = sub i64 %v9085, 32
  store i64 %op9086, ptr %slot1557, align 8
  %v9087 = load i64, ptr %slot1547, align 8
  %p9088 = inttoptr i64 %v9087 to ptr
  %rgep9089 = getelementptr i8, ptr %p9088, i64 -32
  %ld9090 = load i64, ptr %rgep9089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9090, ptr %slot1558, align 8
  %v9091 = load i64, ptr %slot1558, align 8
  %cmp9092 = icmp ne i64 %v9091, 0
  %cv9093 = zext i1 %cmp9092 to i32
  store i32 %cv9093, ptr %slot1559, align 8
  %v9094 = load i32, ptr %slot1559, align 8
  %cv9095 = zext i32 %v9094 to i64
  %cond9096 = icmp ne i64 %cv9095, 0
  br i1 %cond9096, label %bb_rcgdec2018, label %bb_rcgslow2018
bb_rcgslow2018:
  %v9097 = load i64, ptr %slot1546, align 8
  %v9098 = load i64, ptr %slot1543, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v9097, i64 %v9098) nomerge, !dbg !172
  br label %bb_rcgdone2018
bb_rcgdec2018:
  %v9099 = load i64, ptr %slot1555, align 8
  %v9100 = load i64, ptr %slot1547, align 8
  %p9101 = inttoptr i64 %v9100 to ptr
  %rgep9102 = getelementptr i8, ptr %p9101, i64 -24
  store i64 %v9099, ptr %rgep9102, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2018
bb_rcgclear2018:
  %v9103 = load i64, ptr %slot1543, align 8
  %p9104 = inttoptr i64 %v9103 to ptr
  store i64 0, ptr %p9104, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2018
bb_rcgdone2018:
  br label %bb_rcslotdone2002
bb_rcslotowner2002:
  %v9105 = load i64, ptr %slot88, align 8
  store i64 %v9105, ptr %slot1560, align 8
  %v9106 = load i64, ptr %slot1543, align 8
  %p9107 = inttoptr i64 %v9106 to ptr
  %ld9108 = load i64, ptr %p9107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9108, ptr %slot1561, align 8
  %v9109 = load i64, ptr %slot1561, align 8
  %cmp9110 = icmp ne i64 %v9109, 0
  %cv9111 = zext i1 %cmp9110 to i32
  store i32 %cv9111, ptr %slot1562, align 8
  %v9112 = load i32, ptr %slot1562, align 8
  %cv9113 = zext i32 %v9112 to i64
  %cond9114 = icmp ne i64 %cv9113, 0
  br i1 %cond9114, label %bb_rcgnn2033, label %bb_rcgdone2033
bb_rcgnn2033:
  %v9115 = load i64, ptr %slot1561, align 8
  %op9116 = sub i64 %v9115, 16
  store i64 %op9116, ptr %slot1563, align 8
  %v9117 = load i64, ptr %slot1561, align 8
  %p9118 = inttoptr i64 %v9117 to ptr
  %rgep9119 = getelementptr i8, ptr %p9118, i64 -16
  %ld9120 = load i64, ptr %rgep9119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9120, ptr %slot1564, align 8
  %v9121 = load i64, ptr %slot1564, align 8
  %op9122 = and i64 %v9121, 4611686018427387906
  store i64 %op9122, ptr %slot1565, align 8
  %v9123 = load i64, ptr %slot1565, align 8
  %cmp9124 = icmp ne i64 %v9123, 0
  %cv9125 = zext i1 %cmp9124 to i32
  store i32 %cv9125, ptr %slot1566, align 8
  %v9126 = load i32, ptr %slot1566, align 8
  %cv9127 = zext i32 %v9126 to i64
  %cond9128 = icmp ne i64 %cv9127, 0
  br i1 %cond9128, label %bb_rcgclear2033, label %bb_rcgcounted2033
bb_rcgcounted2033:
  %v9129 = load i64, ptr %slot1561, align 8
  %op9130 = sub i64 %v9129, 32
  store i64 %op9130, ptr %slot1567, align 8
  %v9131 = load i64, ptr %slot1561, align 8
  %p9132 = inttoptr i64 %v9131 to ptr
  %rgep9133 = getelementptr i8, ptr %p9132, i64 -32
  %ld9134 = load i64, ptr %rgep9133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9134, ptr %slot1568, align 8
  %v9135 = load i64, ptr %slot1568, align 8
  %op9136 = sub i64 %v9135, 1
  store i64 %op9136, ptr %slot1569, align 8
  %v9137 = load i64, ptr %slot1569, align 8
  %cmp9138 = icmp eq i64 %v9137, 0
  %cv9139 = zext i1 %cmp9138 to i32
  store i32 %cv9139, ptr %slot1570, align 8
  %v9140 = load i32, ptr %slot1570, align 8
  %cv9141 = zext i32 %v9140 to i64
  %cond9142 = icmp ne i64 %cv9141, 0
  br i1 %cond9142, label %bb_rcglast2033, label %bb_rcgdec2033
bb_rcglast2033:
  %v9143 = load i64, ptr %slot1561, align 8
  %op9144 = sub i64 %v9143, 24
  store i64 %op9144, ptr %slot1571, align 8
  %v9145 = load i64, ptr %slot1561, align 8
  %p9146 = inttoptr i64 %v9145 to ptr
  %rgep9147 = getelementptr i8, ptr %p9146, i64 -24
  %ld9148 = load i64, ptr %rgep9147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9148, ptr %slot1572, align 8
  %v9149 = load i64, ptr %slot1572, align 8
  %cmp9150 = icmp ne i64 %v9149, 0
  %cv9151 = zext i1 %cmp9150 to i32
  store i32 %cv9151, ptr %slot1573, align 8
  %v9152 = load i32, ptr %slot1573, align 8
  %cv9153 = zext i32 %v9152 to i64
  %cond9154 = icmp ne i64 %cv9153, 0
  br i1 %cond9154, label %bb_rcgdec2033, label %bb_rcgslow2033
bb_rcgslow2033:
  %v9155 = load i64, ptr %slot1560, align 8
  %v9156 = load i64, ptr %slot1543, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v9155, i64 %v9156) nomerge, !dbg !172
  br label %bb_rcgdone2033
bb_rcgdec2033:
  %v9157 = load i64, ptr %slot1569, align 8
  %v9158 = load i64, ptr %slot1561, align 8
  %p9159 = inttoptr i64 %v9158 to ptr
  %rgep9160 = getelementptr i8, ptr %p9159, i64 -32
  store i64 %v9157, ptr %rgep9160, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2033
bb_rcgclear2033:
  %v9161 = load i64, ptr %slot1543, align 8
  %p9162 = inttoptr i64 %v9161 to ptr
  store i64 0, ptr %p9162, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2033
bb_rcgdone2033:
  br label %bb_rcslotdone2002
bb_rcslotdone2002:
  %v9163 = load i64, ptr %slot1541, align 8
  %p9165 = inttoptr i64 %v9163 to ptr
  %gep9166 = getelementptr i8, ptr %p9165, i64 64
  %op9164 = ptrtoint ptr %gep9166 to i64
  store i64 %op9164, ptr %slot1574, align 8
  store i64 0, ptr %slot1575, align 8
  %v9167 = load i64, ptr %slot1574, align 8
  %p9168 = inttoptr i64 %v9167 to ptr
  %ld9169 = load i64, ptr %p9168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9169, ptr %slot1576, align 8
  %v9170 = load i64, ptr %slot1576, align 8
  %cmp9171 = icmp ne i64 %v9170, 0
  %cv9172 = zext i1 %cmp9171 to i32
  store i32 %cv9172, ptr %slot1577, align 8
  %v9173 = load i32, ptr %slot1577, align 8
  %cv9174 = zext i32 %v9173 to i64
  %cond9175 = icmp ne i64 %cv9174, 0
  br i1 %cond9175, label %bb_rcguniquenn2039, label %bb_rcgunique2039
bb_rcguniquenn2039:
  %v9176 = load i64, ptr %slot1576, align 8
  %op9177 = sub i64 %v9176, 16
  store i64 %op9177, ptr %slot1578, align 8
  %v9178 = load i64, ptr %slot1576, align 8
  %p9179 = inttoptr i64 %v9178 to ptr
  %rgep9180 = getelementptr i8, ptr %p9179, i64 -16
  %ld9181 = load i64, ptr %rgep9180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9181, ptr %slot1579, align 8
  %v9182 = load i64, ptr %slot1579, align 8
  %op9183 = and i64 %v9182, 6917529027641081858
  store i64 %op9183, ptr %slot1580, align 8
  %v9184 = load i64, ptr %slot1580, align 8
  %cmp9185 = icmp ne i64 %v9184, 0
  %cv9186 = zext i1 %cmp9185 to i32
  store i32 %cv9186, ptr %slot1581, align 8
  %v9187 = load i32, ptr %slot1581, align 8
  %cv9188 = zext i32 %v9187 to i64
  %cond9189 = icmp ne i64 %cv9188, 0
  br i1 %cond9189, label %bb_rcguniqueslow2039, label %bb_rcguniquecount2039
bb_rcguniquecount2039:
  %v9190 = load i64, ptr %slot1576, align 8
  %op9191 = sub i64 %v9190, 32
  store i64 %op9191, ptr %slot1582, align 8
  %v9192 = load i64, ptr %slot1576, align 8
  %p9193 = inttoptr i64 %v9192 to ptr
  %rgep9194 = getelementptr i8, ptr %p9193, i64 -32
  %ld9195 = load i64, ptr %rgep9194, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9195, ptr %slot1583, align 8
  %v9196 = load i64, ptr %slot1583, align 8
  %cmp9197 = icmp ult i64 %v9196, 2
  %cv9198 = zext i1 %cmp9197 to i32
  store i32 %cv9198, ptr %slot1584, align 8
  %v9199 = load i32, ptr %slot1584, align 8
  %cv9200 = zext i32 %v9199 to i64
  %cond9201 = icmp ne i64 %cv9200, 0
  br i1 %cond9201, label %bb_rcgunique2039, label %bb_rcguniqueslow2039
bb_rcguniqueslow2039:
  %v9202 = load i64, ptr %slot1, align 8
  %p9203 = inttoptr i64 %v9202 to ptr
  %p9204 = inttoptr i64 ptrtoint (ptr @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f to i64) to ptr
  %v9205 = load i64, ptr %slot1574, align 8
  %p9206 = inttoptr i64 %v9205 to ptr
  %v9207 = load i64, ptr %slot1575, align 8
  %p9208 = inttoptr i64 %v9207 to ptr
  %call9209 = call i32 @myl_qbe_rc_unique_field(ptr %p9203, ptr %p9204, ptr %p9206, ptr %p9208) nomerge, !dbg !172
  store i32 %call9209, ptr %slot1585, align 8
  %v9210 = load i32, ptr %slot1585, align 8
  %cv9211 = zext i32 %v9210 to i64
  %cond9212 = icmp ne i64 %cv9211, 0
  br i1 %cond9212, label %bb_rcunique2049, label %bb_failure
bb_rcunique2049:
  br label %bb_rcgunique2039
bb_rcgunique2039:
  %v9213 = load i64, ptr %slot1574, align 8
  %p9214 = inttoptr i64 %v9213 to ptr
  %ld9215 = load i64, ptr %p9214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9215, ptr %slot1586, align 8
  %v9216 = load i64, ptr %slot1586, align 8
  %v9217 = load i64, ptr %slot68, align 8
  %p9218 = inttoptr i64 %v9217 to ptr
  store i64 %v9216, ptr %p9218, align 8, !alias.scope !3, !noalias !4
  %v9219 = load i64, ptr %slot68, align 8
  %p9220 = inttoptr i64 %v9219 to ptr
  %ld9221 = load i64, ptr %p9220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9221, ptr %slot1587, align 8
  %v9222 = load i64, ptr %slot23, align 8
  %p9223 = inttoptr i64 %v9222 to ptr
  %ld9224 = load i32, ptr %p9223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9224, ptr %slot1588, align 8
  %v9225 = load i32, ptr %slot1588, align 8
  %cv9226 = zext i32 %v9225 to i64
  %cond9227 = icmp ne i64 %cv9226, 0
  br i1 %cond9227, label %bb_rcslotdrop2054, label %bb_rcslotdone2054
bb_rcslotdrop2054:
  %v9228 = load i64, ptr %slot23, align 8
  %p9229 = inttoptr i64 %v9228 to ptr
  store i32 0, ptr %p9229, align 4, !alias.scope !3, !noalias !4
  %v9230 = load i64, ptr %slot34, align 8
  store i64 %v9230, ptr %slot1589, align 8
  %v9231 = load i64, ptr %slot24, align 8
  %p9232 = inttoptr i64 %v9231 to ptr
  %ld9233 = load i32, ptr %p9232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9233, ptr %slot1590, align 8
  %v9234 = load i32, ptr %slot1590, align 8
  %op9235 = and i32 %v9234, 28
  store i32 %op9235, ptr %slot1591, align 8
  %v9236 = load i32, ptr %slot1591, align 8
  %cv9237 = zext i32 %v9236 to i64
  %cond9238 = icmp ne i64 %cv9237, 0
  br i1 %cond9238, label %bb_rcslotrole2054, label %bb_rcslotowner2054
bb_rcslotrole2054:
  %v9239 = load i64, ptr %slot88, align 8
  store i64 %v9239, ptr %slot1592, align 8
  %v9240 = load i64, ptr %slot1589, align 8
  %p9241 = inttoptr i64 %v9240 to ptr
  %ld9242 = load i64, ptr %p9241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9242, ptr %slot1593, align 8
  %v9243 = load i64, ptr %slot1593, align 8
  %cmp9244 = icmp ne i64 %v9243, 0
  %cv9245 = zext i1 %cmp9244 to i32
  store i32 %cv9245, ptr %slot1594, align 8
  %v9246 = load i32, ptr %slot1594, align 8
  %cv9247 = zext i32 %v9246 to i64
  %cond9248 = icmp ne i64 %cv9247, 0
  br i1 %cond9248, label %bb_rcgnn2070, label %bb_rcgdone2070
bb_rcgnn2070:
  %v9249 = load i64, ptr %slot1593, align 8
  %op9250 = sub i64 %v9249, 16
  store i64 %op9250, ptr %slot1595, align 8
  %v9251 = load i64, ptr %slot1593, align 8
  %p9252 = inttoptr i64 %v9251 to ptr
  %rgep9253 = getelementptr i8, ptr %p9252, i64 -16
  %ld9254 = load i64, ptr %rgep9253, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9254, ptr %slot1596, align 8
  %v9255 = load i64, ptr %slot1596, align 8
  %op9256 = and i64 %v9255, 4611686018427387906
  store i64 %op9256, ptr %slot1597, align 8
  %v9257 = load i64, ptr %slot1597, align 8
  %cmp9258 = icmp ne i64 %v9257, 0
  %cv9259 = zext i1 %cmp9258 to i32
  store i32 %cv9259, ptr %slot1598, align 8
  %v9260 = load i32, ptr %slot1598, align 8
  %cv9261 = zext i32 %v9260 to i64
  %cond9262 = icmp ne i64 %cv9261, 0
  br i1 %cond9262, label %bb_rcgclear2070, label %bb_rcgcounted2070
bb_rcgcounted2070:
  %v9263 = load i64, ptr %slot1593, align 8
  %op9264 = sub i64 %v9263, 24
  store i64 %op9264, ptr %slot1599, align 8
  %v9265 = load i64, ptr %slot1593, align 8
  %p9266 = inttoptr i64 %v9265 to ptr
  %rgep9267 = getelementptr i8, ptr %p9266, i64 -24
  %ld9268 = load i64, ptr %rgep9267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9268, ptr %slot1600, align 8
  %v9269 = load i64, ptr %slot1600, align 8
  %op9270 = sub i64 %v9269, 1
  store i64 %op9270, ptr %slot1601, align 8
  %v9271 = load i64, ptr %slot1601, align 8
  %cmp9272 = icmp eq i64 %v9271, 0
  %cv9273 = zext i1 %cmp9272 to i32
  store i32 %cv9273, ptr %slot1602, align 8
  %v9274 = load i32, ptr %slot1602, align 8
  %cv9275 = zext i32 %v9274 to i64
  %cond9276 = icmp ne i64 %cv9275, 0
  br i1 %cond9276, label %bb_rcglast2070, label %bb_rcgdec2070
bb_rcglast2070:
  %v9277 = load i64, ptr %slot1593, align 8
  %op9278 = sub i64 %v9277, 32
  store i64 %op9278, ptr %slot1603, align 8
  %v9279 = load i64, ptr %slot1593, align 8
  %p9280 = inttoptr i64 %v9279 to ptr
  %rgep9281 = getelementptr i8, ptr %p9280, i64 -32
  %ld9282 = load i64, ptr %rgep9281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9282, ptr %slot1604, align 8
  %v9283 = load i64, ptr %slot1604, align 8
  %cmp9284 = icmp ne i64 %v9283, 0
  %cv9285 = zext i1 %cmp9284 to i32
  store i32 %cv9285, ptr %slot1605, align 8
  %v9286 = load i32, ptr %slot1605, align 8
  %cv9287 = zext i32 %v9286 to i64
  %cond9288 = icmp ne i64 %cv9287, 0
  br i1 %cond9288, label %bb_rcgdec2070, label %bb_rcgslow2070
bb_rcgslow2070:
  %v9289 = load i64, ptr %slot1592, align 8
  %v9290 = load i64, ptr %slot1589, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v9289, i64 %v9290) nomerge, !dbg !172
  br label %bb_rcgdone2070
bb_rcgdec2070:
  %v9291 = load i64, ptr %slot1601, align 8
  %v9292 = load i64, ptr %slot1593, align 8
  %p9293 = inttoptr i64 %v9292 to ptr
  %rgep9294 = getelementptr i8, ptr %p9293, i64 -24
  store i64 %v9291, ptr %rgep9294, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2070
bb_rcgclear2070:
  %v9295 = load i64, ptr %slot1589, align 8
  %p9296 = inttoptr i64 %v9295 to ptr
  store i64 0, ptr %p9296, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2070
bb_rcgdone2070:
  br label %bb_rcslotdone2054
bb_rcslotowner2054:
  %v9297 = load i64, ptr %slot88, align 8
  store i64 %v9297, ptr %slot1606, align 8
  %v9298 = load i64, ptr %slot1589, align 8
  %p9299 = inttoptr i64 %v9298 to ptr
  %ld9300 = load i64, ptr %p9299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9300, ptr %slot1607, align 8
  %v9301 = load i64, ptr %slot1607, align 8
  %cmp9302 = icmp ne i64 %v9301, 0
  %cv9303 = zext i1 %cmp9302 to i32
  store i32 %cv9303, ptr %slot1608, align 8
  %v9304 = load i32, ptr %slot1608, align 8
  %cv9305 = zext i32 %v9304 to i64
  %cond9306 = icmp ne i64 %cv9305, 0
  br i1 %cond9306, label %bb_rcgnn2085, label %bb_rcgdone2085
bb_rcgnn2085:
  %v9307 = load i64, ptr %slot1607, align 8
  %op9308 = sub i64 %v9307, 16
  store i64 %op9308, ptr %slot1609, align 8
  %v9309 = load i64, ptr %slot1607, align 8
  %p9310 = inttoptr i64 %v9309 to ptr
  %rgep9311 = getelementptr i8, ptr %p9310, i64 -16
  %ld9312 = load i64, ptr %rgep9311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9312, ptr %slot1610, align 8
  %v9313 = load i64, ptr %slot1610, align 8
  %op9314 = and i64 %v9313, 4611686018427387906
  store i64 %op9314, ptr %slot1611, align 8
  %v9315 = load i64, ptr %slot1611, align 8
  %cmp9316 = icmp ne i64 %v9315, 0
  %cv9317 = zext i1 %cmp9316 to i32
  store i32 %cv9317, ptr %slot1612, align 8
  %v9318 = load i32, ptr %slot1612, align 8
  %cv9319 = zext i32 %v9318 to i64
  %cond9320 = icmp ne i64 %cv9319, 0
  br i1 %cond9320, label %bb_rcgclear2085, label %bb_rcgcounted2085
bb_rcgcounted2085:
  %v9321 = load i64, ptr %slot1607, align 8
  %op9322 = sub i64 %v9321, 32
  store i64 %op9322, ptr %slot1613, align 8
  %v9323 = load i64, ptr %slot1607, align 8
  %p9324 = inttoptr i64 %v9323 to ptr
  %rgep9325 = getelementptr i8, ptr %p9324, i64 -32
  %ld9326 = load i64, ptr %rgep9325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9326, ptr %slot1614, align 8
  %v9327 = load i64, ptr %slot1614, align 8
  %op9328 = sub i64 %v9327, 1
  store i64 %op9328, ptr %slot1615, align 8
  %v9329 = load i64, ptr %slot1615, align 8
  %cmp9330 = icmp eq i64 %v9329, 0
  %cv9331 = zext i1 %cmp9330 to i32
  store i32 %cv9331, ptr %slot1616, align 8
  %v9332 = load i32, ptr %slot1616, align 8
  %cv9333 = zext i32 %v9332 to i64
  %cond9334 = icmp ne i64 %cv9333, 0
  br i1 %cond9334, label %bb_rcglast2085, label %bb_rcgdec2085
bb_rcglast2085:
  %v9335 = load i64, ptr %slot1607, align 8
  %op9336 = sub i64 %v9335, 24
  store i64 %op9336, ptr %slot1617, align 8
  %v9337 = load i64, ptr %slot1607, align 8
  %p9338 = inttoptr i64 %v9337 to ptr
  %rgep9339 = getelementptr i8, ptr %p9338, i64 -24
  %ld9340 = load i64, ptr %rgep9339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9340, ptr %slot1618, align 8
  %v9341 = load i64, ptr %slot1618, align 8
  %cmp9342 = icmp ne i64 %v9341, 0
  %cv9343 = zext i1 %cmp9342 to i32
  store i32 %cv9343, ptr %slot1619, align 8
  %v9344 = load i32, ptr %slot1619, align 8
  %cv9345 = zext i32 %v9344 to i64
  %cond9346 = icmp ne i64 %cv9345, 0
  br i1 %cond9346, label %bb_rcgdec2085, label %bb_rcgslow2085
bb_rcgslow2085:
  %v9347 = load i64, ptr %slot1606, align 8
  %v9348 = load i64, ptr %slot1589, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v9347, i64 %v9348) nomerge, !dbg !172
  br label %bb_rcgdone2085
bb_rcgdec2085:
  %v9349 = load i64, ptr %slot1615, align 8
  %v9350 = load i64, ptr %slot1607, align 8
  %p9351 = inttoptr i64 %v9350 to ptr
  %rgep9352 = getelementptr i8, ptr %p9351, i64 -32
  store i64 %v9349, ptr %rgep9352, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2085
bb_rcgclear2085:
  %v9353 = load i64, ptr %slot1589, align 8
  %p9354 = inttoptr i64 %v9353 to ptr
  store i64 0, ptr %p9354, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2085
bb_rcgdone2085:
  br label %bb_rcslotdone2054
bb_rcslotdone2054:
  %v9355 = load i64, ptr %slot48, align 8
  store i64 %v9355, ptr %slot1620, align 8
  %v9356 = load i64, ptr %slot88, align 8
  %v9357 = load i64, ptr %slot1620, align 8
  %p9358 = inttoptr i64 %v9357 to ptr
  store i64 %v9356, ptr %p9358, align 8, !alias.scope !3, !noalias !4
  %v9359 = load i64, ptr %slot88, align 8
  %p9361 = inttoptr i64 %v9359 to ptr
  %gep9362 = getelementptr i8, ptr %p9361, i64 5640
  %op9360 = ptrtoint ptr %gep9362 to i64
  store i64 %op9360, ptr %slot1621, align 8
  %v9363 = load i64, ptr %slot1621, align 8
  %p9364 = inttoptr i64 %v9363 to ptr
  %ld9365 = load i64, ptr %p9364, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9365, ptr %slot1622, align 8
  %v9366 = load i64, ptr %slot1622, align 8
  %op9367 = add i64 %v9366, 248
  store i64 %op9367, ptr %slot1623, align 8
  %v9368 = load i64, ptr %slot1623, align 8
  %p9369 = inttoptr i64 %v9368 to ptr
  %ld9370 = load i64, ptr %p9369, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9370, ptr %slot1624, align 8
  %v9371 = load i64, ptr %slot1620, align 8
  %p9373 = inttoptr i64 %v9371 to ptr
  %gep9374 = getelementptr i8, ptr %p9373, i64 8
  %op9372 = ptrtoint ptr %gep9374 to i64
  store i64 %op9372, ptr %slot1625, align 8
  %v9375 = load i64, ptr %slot1624, align 8
  %v9376 = load i64, ptr %slot1625, align 8
  %p9377 = inttoptr i64 %v9376 to ptr
  store i64 %v9375, ptr %p9377, align 8, !alias.scope !3, !noalias !4
  %v9378 = load i64, ptr %slot1620, align 8
  %p9380 = inttoptr i64 %v9378 to ptr
  %gep9381 = getelementptr i8, ptr %p9380, i64 16
  %op9379 = ptrtoint ptr %gep9381 to i64
  store i64 %op9379, ptr %slot1626, align 8
  %v9382 = load i64, ptr %slot1626, align 8
  %p9383 = inttoptr i64 %v9382 to ptr
  store i64 0, ptr %p9383, align 8, !alias.scope !3, !noalias !4
  %v9384 = load i64, ptr %slot88, align 8
  %p9386 = inttoptr i64 %v9384 to ptr
  %gep9387 = getelementptr i8, ptr %p9386, i64 112
  %op9385 = ptrtoint ptr %gep9387 to i64
  store i64 %op9385, ptr %slot1627, align 8
  %v9388 = load i64, ptr %slot1620, align 8
  %p9390 = inttoptr i64 %v9388 to ptr
  %gep9391 = getelementptr i8, ptr %p9390, i64 24
  %op9389 = ptrtoint ptr %gep9391 to i64
  store i64 %op9389, ptr %slot1628, align 8
  %v9392 = load i64, ptr %slot1620, align 8
  %p9394 = inttoptr i64 %v9392 to ptr
  %gep9395 = getelementptr i8, ptr %p9394, i64 28
  %op9393 = ptrtoint ptr %gep9395 to i64
  store i64 %op9393, ptr %slot1629, align 8
  %v9396 = load i64, ptr %slot1627, align 8
  %p9397 = inttoptr i64 %v9396 to ptr
  %ld9398 = load i32, ptr %p9397, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld9398, ptr %slot1630, align 8
  %v9399 = load i64, ptr %slot1628, align 8
  %p9400 = inttoptr i64 %v9399 to ptr
  store i32 1, ptr %p9400, align 4, !alias.scope !3, !noalias !4
  %v9401 = load i32, ptr %slot1630, align 8
  %v9402 = load i64, ptr %slot1629, align 8
  %p9403 = inttoptr i64 %v9402 to ptr
  store i32 %v9401, ptr %p9403, align 4, !alias.scope !3, !noalias !4
  %v9404 = load i64, ptr %slot1620, align 8
  %v9405 = load i64, ptr %slot1623, align 8
  %p9406 = inttoptr i64 %v9405 to ptr
  store i64 %v9404, ptr %p9406, align 8, !alias.scope !9999998, !noalias !9999999
  %v9407 = load i64, ptr %slot1587, align 8
  %cmp9408 = icmp ne i64 %v9407, 0
  %cv9409 = zext i1 %cmp9408 to i32
  store i32 %cv9409, ptr %slot1631, align 8
  %v9410 = load i32, ptr %slot1631, align 8
  %cv9411 = zext i32 %v9410 to i64
  %cond9412 = icmp ne i64 %cv9411, 0
  br i1 %cond9412, label %bb_rcspinmark2137, label %bb_rcspindone2137
bb_rcspinmark2137:
  %v9413 = load i64, ptr %slot1587, align 8
  %op9414 = sub i64 %v9413, 16
  store i64 %op9414, ptr %slot1632, align 8
  %v9415 = load i64, ptr %slot1587, align 8
  %p9416 = inttoptr i64 %v9415 to ptr
  %rgep9417 = getelementptr i8, ptr %p9416, i64 -16
  %ld9418 = load i64, ptr %rgep9417, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9418, ptr %slot1633, align 8
  %v9419 = load i64, ptr %slot1633, align 8
  %op9420 = and i64 %v9419, 2
  store i64 %op9420, ptr %slot1634, align 8
  %v9421 = load i64, ptr %slot1634, align 8
  %cmp9422 = icmp ne i64 %v9421, 0
  %cv9423 = zext i1 %cmp9422 to i32
  store i32 %cv9423, ptr %slot1635, align 8
  %v9424 = load i32, ptr %slot1635, align 8
  %cv9425 = zext i32 %v9424 to i64
  %cond9426 = icmp ne i64 %cv9425, 0
  br i1 %cond9426, label %bb_rcspindone2137, label %bb_rcspintype2137
bb_rcspintype2137:
  %v9427 = load i64, ptr %slot1633, align 8
  %op9428 = and i64 %v9427, 4611686018427387907
  store i64 %op9428, ptr %slot1636, align 8
  %v9429 = load i64, ptr %slot1636, align 8
  %cmp9430 = icmp eq i64 %v9429, 0
  %cv9431 = zext i1 %cmp9430 to i32
  store i32 %cv9431, ptr %slot1637, align 8
  %v9432 = load i32, ptr %slot1637, align 8
  %cv9433 = zext i32 %v9432 to i64
  %cond9434 = icmp ne i64 %cv9433, 0
  br i1 %cond9434, label %bb_rcs2145, label %bb_rcspinslow2137
bb_rcs2145:
  %v9435 = load i64, ptr %slot1587, align 8
  %op9436 = sub i64 %v9435, 8
  store i64 %op9436, ptr %slot1638, align 8
  %v9437 = load i64, ptr %slot1587, align 8
  %p9438 = inttoptr i64 %v9437 to ptr
  %rgep9439 = getelementptr i8, ptr %p9438, i64 -8
  %ld9440 = load i64, ptr %rgep9439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9440, ptr %slot1639, align 8
  %p9441 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld9442 = load i64, ptr %p9441, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9442, ptr %slot1640, align 8
  %v9443 = load i64, ptr %slot1639, align 8
  %v9444 = load i64, ptr %slot1640, align 8
  %cmp9445 = icmp eq i64 %v9443, %v9444
  %cv9446 = zext i1 %cmp9445 to i32
  store i32 %cv9446, ptr %slot1641, align 8
  %v9447 = load i32, ptr %slot1641, align 8
  %cv9448 = zext i32 %v9447 to i64
  %cond9449 = icmp ne i64 %cv9448, 0
  br i1 %cond9449, label %bb_rcs2150, label %bb_rcspinslow2137
bb_rcs2150:
  %v9450 = load i64, ptr %slot88, align 8
  %p9452 = inttoptr i64 %v9450 to ptr
  %gep9453 = getelementptr i8, ptr %p9452, i64 5640
  %op9451 = ptrtoint ptr %gep9453 to i64
  store i64 %op9451, ptr %slot1642, align 8
  %v9454 = load i64, ptr %slot1642, align 8
  %p9455 = inttoptr i64 %v9454 to ptr
  %ld9456 = load i64, ptr %p9455, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9456, ptr %slot1643, align 8
  %v9457 = load i64, ptr %slot1643, align 8
  %op9458 = add i64 %v9457, 256
  store i64 %op9458, ptr %slot1644, align 8
  %v9459 = load i64, ptr %slot1644, align 8
  %p9460 = inttoptr i64 %v9459 to ptr
  %ld9461 = load i64, ptr %p9460, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9461, ptr %slot1645, align 8
  %v9462 = load i64, ptr %slot1645, align 8
  %cmp9463 = icmp ne i64 %v9462, 0
  %cv9464 = zext i1 %cmp9463 to i32
  store i32 %cv9464, ptr %slot1646, align 8
  %v9465 = load i32, ptr %slot1646, align 8
  %cv9466 = zext i32 %v9465 to i64
  %cond9467 = icmp ne i64 %cv9466, 0
  br i1 %cond9467, label %bb_rcs2156, label %bb_rcspinslow2137
bb_rcs2156:
  %v9468 = load i64, ptr %slot88, align 8
  %p9470 = inttoptr i64 %v9468 to ptr
  %gep9471 = getelementptr i8, ptr %p9470, i64 24
  %op9469 = ptrtoint ptr %gep9471 to i64
  store i64 %op9469, ptr %slot1647, align 8
  %v9472 = load i64, ptr %slot1647, align 8
  %p9473 = inttoptr i64 %v9472 to ptr
  %ld9474 = load i64, ptr %p9473, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9474, ptr %slot1648, align 8
  %v9475 = load i64, ptr %slot1648, align 8
  %op9476 = add i64 %v9475, 40
  store i64 %op9476, ptr %slot1649, align 8
  %v9477 = load i64, ptr %slot1649, align 8
  %v9478 = load i64, ptr %slot1648, align 8
  %cmp9479 = icmp uge i64 %v9477, %v9478
  %cv9480 = zext i1 %cmp9479 to i32
  store i32 %cv9480, ptr %slot1650, align 8
  %v9481 = load i32, ptr %slot1650, align 8
  %cv9482 = zext i32 %v9481 to i64
  %cond9483 = icmp ne i64 %cv9482, 0
  br i1 %cond9483, label %bb_rcs2161, label %bb_rcspinslow2137
bb_rcs2161:
  %v9484 = load i64, ptr %slot88, align 8
  %p9486 = inttoptr i64 %v9484 to ptr
  %gep9487 = getelementptr i8, ptr %p9486, i64 88
  %op9485 = ptrtoint ptr %gep9487 to i64
  store i64 %op9485, ptr %slot1651, align 8
  %v9488 = load i64, ptr %slot1651, align 8
  %p9489 = inttoptr i64 %v9488 to ptr
  %ld9490 = load i64, ptr %p9489, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9490, ptr %slot1652, align 8
  %v9491 = load i64, ptr %slot1652, align 8
  %cmp9492 = icmp eq i64 %v9491, 0
  %cv9493 = zext i1 %cmp9492 to i32
  store i32 %cv9493, ptr %slot1653, align 8
  %v9494 = load i64, ptr %slot1649, align 8
  %v9495 = load i64, ptr %slot1652, align 8
  %cmp9496 = icmp ule i64 %v9494, %v9495
  %cv9497 = zext i1 %cmp9496 to i32
  store i32 %cv9497, ptr %slot1654, align 8
  %v9498 = load i32, ptr %slot1653, align 8
  %v9499 = load i32, ptr %slot1654, align 8
  %op9500 = or i32 %v9498, %v9499
  store i32 %op9500, ptr %slot1655, align 8
  %v9501 = load i32, ptr %slot1655, align 8
  %cv9502 = zext i32 %v9501 to i64
  %cond9503 = icmp ne i64 %cv9502, 0
  br i1 %cond9503, label %bb_rcs2167, label %bb_rcspinslow2137
bb_rcs2167:
  %v9504 = load i64, ptr %slot1587, align 8
  %op9505 = sub i64 %v9504, 24
  store i64 %op9505, ptr %slot1656, align 8
  %v9506 = load i64, ptr %slot1587, align 8
  %p9507 = inttoptr i64 %v9506 to ptr
  %rgep9508 = getelementptr i8, ptr %p9507, i64 -24
  %ld9509 = load i64, ptr %rgep9508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9509, ptr %slot1657, align 8
  %v9510 = load i64, ptr %slot1657, align 8
  %cmp9511 = icmp ne i64 %v9510, 18446744073709551615
  %cv9512 = zext i1 %cmp9511 to i32
  store i32 %cv9512, ptr %slot1658, align 8
  %v9513 = load i32, ptr %slot1658, align 8
  %cv9514 = zext i32 %v9513 to i64
  %cond9515 = icmp ne i64 %cv9514, 0
  br i1 %cond9515, label %bb_rcs2171, label %bb_rcspinslow2137
bb_rcs2171:
  %v9516 = load i64, ptr %slot1587, align 8
  %op9517 = add i64 %v9516, 32
  store i64 %op9517, ptr %slot1659, align 8
  %v9518 = load i64, ptr %slot1659, align 8
  %p9519 = inttoptr i64 %v9518 to ptr
  %ld9520 = load i64, ptr %p9519, align 8
  store i64 %ld9520, ptr %slot1660, align 8
  %v9521 = load i64, ptr %slot1660, align 8
  %cmp9522 = icmp ne i64 %v9521, 0
  %cv9523 = zext i1 %cmp9522 to i32
  store i32 %cv9523, ptr %slot1661, align 8
  %v9524 = load i32, ptr %slot1661, align 8
  %cv9525 = zext i32 %v9524 to i64
  %cond9526 = icmp ne i64 %cv9525, 0
  br i1 %cond9526, label %bb_rcspinbacking2137, label %bb_rcspincommit2137
bb_rcspinbacking2137:
  %v9527 = load i64, ptr %slot1660, align 8
  %op9528 = sub i64 %v9527, 16
  store i64 %op9528, ptr %slot1662, align 8
  %v9529 = load i64, ptr %slot1660, align 8
  %p9530 = inttoptr i64 %v9529 to ptr
  %rgep9531 = getelementptr i8, ptr %p9530, i64 -16
  %ld9532 = load i64, ptr %rgep9531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9532, ptr %slot1663, align 8
  %v9533 = load i64, ptr %slot1663, align 8
  %op9534 = and i64 %v9533, 4611686018427387907
  store i64 %op9534, ptr %slot1664, align 8
  %v9535 = load i64, ptr %slot1664, align 8
  %cmp9536 = icmp eq i64 %v9535, 0
  %cv9537 = zext i1 %cmp9536 to i32
  store i32 %cv9537, ptr %slot1665, align 8
  %v9538 = load i32, ptr %slot1665, align 8
  %cv9539 = zext i32 %v9538 to i64
  %cond9540 = icmp ne i64 %cv9539, 0
  br i1 %cond9540, label %bb_rcs2179, label %bb_rcspinslow2137
bb_rcs2179:
  %v9541 = load i64, ptr %slot1660, align 8
  %op9542 = sub i64 %v9541, 24
  store i64 %op9542, ptr %slot1666, align 8
  %v9543 = load i64, ptr %slot1660, align 8
  %p9544 = inttoptr i64 %v9543 to ptr
  %rgep9545 = getelementptr i8, ptr %p9544, i64 -24
  %ld9546 = load i64, ptr %rgep9545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9546, ptr %slot1667, align 8
  %v9547 = load i64, ptr %slot1667, align 8
  %cmp9548 = icmp ne i64 %v9547, 18446744073709551615
  %cv9549 = zext i1 %cmp9548 to i32
  store i32 %cv9549, ptr %slot1668, align 8
  %v9550 = load i32, ptr %slot1668, align 8
  %cv9551 = zext i32 %v9550 to i64
  %cond9552 = icmp ne i64 %cv9551, 0
  br i1 %cond9552, label %bb_rcs2183, label %bb_rcspinslow2137
bb_rcs2183:
  br label %bb_rcspincommit2137
bb_rcspincommit2137:
  %v9553 = load i64, ptr %slot1645, align 8
  %p9554 = inttoptr i64 %v9553 to ptr
  %ld9555 = load i64, ptr %p9554, align 8
  store i64 %ld9555, ptr %slot1669, align 8
  %v9556 = load i64, ptr %slot1643, align 8
  %op9557 = add i64 %v9556, 256
  store i64 %op9557, ptr %slot1670, align 8
  %v9558 = load i64, ptr %slot1669, align 8
  %v9559 = load i64, ptr %slot1670, align 8
  %p9560 = inttoptr i64 %v9559 to ptr
  store i64 %v9558, ptr %p9560, align 8, !alias.scope !9999998, !noalias !9999999
  %v9561 = load i64, ptr %slot1643, align 8
  %op9562 = add i64 %v9561, 264
  store i64 %op9562, ptr %slot1671, align 8
  %v9563 = load i64, ptr %slot1671, align 8
  %p9564 = inttoptr i64 %v9563 to ptr
  %ld9565 = load i64, ptr %p9564, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9565, ptr %slot1672, align 8
  %v9566 = load i64, ptr %slot1672, align 8
  %op9567 = add i64 %v9566, 18446744073709551615
  store i64 %op9567, ptr %slot1673, align 8
  %v9568 = load i64, ptr %slot1673, align 8
  %v9569 = load i64, ptr %slot1671, align 8
  %p9570 = inttoptr i64 %v9569 to ptr
  store i64 %v9568, ptr %p9570, align 8, !alias.scope !9999998, !noalias !9999999
  %v9571 = load i64, ptr %slot88, align 8
  %p9573 = inttoptr i64 %v9571 to ptr
  %gep9574 = getelementptr i8, ptr %p9573, i64 24
  %op9572 = ptrtoint ptr %gep9574 to i64
  store i64 %op9572, ptr %slot1674, align 8
  %v9575 = load i64, ptr %slot1674, align 8
  %p9576 = inttoptr i64 %v9575 to ptr
  %ld9577 = load i64, ptr %p9576, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9577, ptr %slot1675, align 8
  %v9578 = load i64, ptr %slot1675, align 8
  %op9579 = add i64 %v9578, 40
  store i64 %op9579, ptr %slot1676, align 8
  %v9580 = load i64, ptr %slot1676, align 8
  %v9581 = load i64, ptr %slot1674, align 8
  %p9582 = inttoptr i64 %v9581 to ptr
  store i64 %v9580, ptr %p9582, align 8, !alias.scope !9999998, !noalias !9999999
  %v9583 = load i64, ptr %slot1643, align 8
  %op9584 = add i64 %v9583, 48
  store i64 %op9584, ptr %slot1677, align 8
  %v9585 = load i64, ptr %slot1677, align 8
  %p9586 = inttoptr i64 %v9585 to ptr
  %ld9587 = load i64, ptr %p9586, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld9587, ptr %slot1678, align 8
  %v9588 = load i64, ptr %slot1678, align 8
  %op9589 = add i64 %v9588, 40
  store i64 %op9589, ptr %slot1679, align 8
  %v9590 = load i64, ptr %slot1679, align 8
  %v9591 = load i64, ptr %slot1677, align 8
  %p9592 = inttoptr i64 %v9591 to ptr
  store i64 %v9590, ptr %p9592, align 8, !alias.scope !9999998, !noalias !9999999
  %v9593 = load i64, ptr %slot1587, align 8
  %op9594 = sub i64 %v9593, 24
  store i64 %op9594, ptr %slot1680, align 8
  %v9595 = load i64, ptr %slot1587, align 8
  %p9596 = inttoptr i64 %v9595 to ptr
  %rgep9597 = getelementptr i8, ptr %p9596, i64 -24
  %ld9598 = load i64, ptr %rgep9597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9598, ptr %slot1681, align 8
  %v9599 = load i64, ptr %slot1681, align 8
  %op9600 = add i64 %v9599, 1
  store i64 %op9600, ptr %slot1682, align 8
  %v9601 = load i64, ptr %slot1682, align 8
  %v9602 = load i64, ptr %slot1587, align 8
  %p9603 = inttoptr i64 %v9602 to ptr
  %rgep9604 = getelementptr i8, ptr %p9603, i64 -24
  store i64 %v9601, ptr %rgep9604, align 8, !alias.scope !9, !noalias !10
  %v9605 = load i64, ptr %slot1660, align 8
  %cmp9606 = icmp ne i64 %v9605, 0
  %cv9607 = zext i1 %cmp9606 to i32
  store i32 %cv9607, ptr %slot1683, align 8
  %v9608 = load i32, ptr %slot1683, align 8
  %cv9609 = zext i32 %v9608 to i64
  %cond9610 = icmp ne i64 %cv9609, 0
  br i1 %cond9610, label %bb_rcspinhold2137, label %bb_rcspinjournal2137
bb_rcspinhold2137:
  %v9611 = load i64, ptr %slot1660, align 8
  %op9612 = sub i64 %v9611, 24
  store i64 %op9612, ptr %slot1684, align 8
  %v9613 = load i64, ptr %slot1660, align 8
  %p9614 = inttoptr i64 %v9613 to ptr
  %rgep9615 = getelementptr i8, ptr %p9614, i64 -24
  %ld9616 = load i64, ptr %rgep9615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9616, ptr %slot1685, align 8
  %v9617 = load i64, ptr %slot1685, align 8
  %op9618 = add i64 %v9617, 1
  store i64 %op9618, ptr %slot1686, align 8
  %v9619 = load i64, ptr %slot1686, align 8
  %v9620 = load i64, ptr %slot1660, align 8
  %p9621 = inttoptr i64 %v9620 to ptr
  %rgep9622 = getelementptr i8, ptr %p9621, i64 -24
  store i64 %v9619, ptr %rgep9622, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal2137
bb_rcspinjournal2137:
  %v9623 = load i64, ptr %slot1633, align 8
  %op9624 = and i64 %v9623, 1152921504606846976
  store i64 %op9624, ptr %slot1687, align 8
  %v9625 = load i64, ptr %slot1633, align 8
  %op9626 = or i64 %v9625, 1152921504606846976
  store i64 %op9626, ptr %slot1688, align 8
  %v9627 = load i64, ptr %slot1587, align 8
  %op9628 = sub i64 %v9627, 16
  store i64 %op9628, ptr %slot1689, align 8
  %v9629 = load i64, ptr %slot1688, align 8
  %v9630 = load i64, ptr %slot1587, align 8
  %p9631 = inttoptr i64 %v9630 to ptr
  %rgep9632 = getelementptr i8, ptr %p9631, i64 -16
  store i64 %v9629, ptr %rgep9632, align 8, !alias.scope !9, !noalias !10
  %v9633 = load i64, ptr %slot1620, align 8
  %p9635 = inttoptr i64 %v9633 to ptr
  %gep9636 = getelementptr i8, ptr %p9635, i64 16
  %op9634 = ptrtoint ptr %gep9636 to i64
  store i64 %op9634, ptr %slot1690, align 8
  %v9637 = load i64, ptr %slot1690, align 8
  %p9638 = inttoptr i64 %v9637 to ptr
  %ld9639 = load i64, ptr %p9638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9639, ptr %slot1691, align 8
  %v9640 = load i64, ptr %slot1645, align 8
  %op9641 = add i64 %v9640, 0
  store i64 %op9641, ptr %slot1692, align 8
  %v9642 = load i64, ptr %slot1691, align 8
  %v9643 = load i64, ptr %slot1692, align 8
  %p9644 = inttoptr i64 %v9643 to ptr
  store i64 %v9642, ptr %p9644, align 8, !alias.scope !9999998, !noalias !9999999
  %v9645 = load i64, ptr %slot1645, align 8
  %op9646 = add i64 %v9645, 8
  store i64 %op9646, ptr %slot1693, align 8
  %v9647 = load i64, ptr %slot1587, align 8
  %v9648 = load i64, ptr %slot1693, align 8
  %p9649 = inttoptr i64 %v9648 to ptr
  store i64 %v9647, ptr %p9649, align 8, !alias.scope !9999998, !noalias !9999999
  %v9650 = load i64, ptr %slot1645, align 8
  %op9651 = add i64 %v9650, 16
  store i64 %op9651, ptr %slot1694, align 8
  %v9652 = load i64, ptr %slot1687, align 8
  %v9653 = load i64, ptr %slot1694, align 8
  %p9654 = inttoptr i64 %v9653 to ptr
  store i64 %v9652, ptr %p9654, align 8, !alias.scope !9999998, !noalias !9999999
  %v9655 = load i64, ptr %slot1645, align 8
  %op9656 = add i64 %v9655, 24
  store i64 %op9656, ptr %slot1695, align 8
  %v9657 = load i64, ptr %slot1695, align 8
  %p9658 = inttoptr i64 %v9657 to ptr
  store i32 1, ptr %p9658, align 4, !alias.scope !9999998, !noalias !9999999
  %v9659 = load i64, ptr %slot1645, align 8
  %op9660 = add i64 %v9659, 32
  store i64 %op9660, ptr %slot1696, align 8
  %v9661 = load i64, ptr %slot1660, align 8
  %v9662 = load i64, ptr %slot1696, align 8
  %p9663 = inttoptr i64 %v9662 to ptr
  store i64 %v9661, ptr %p9663, align 8, !alias.scope !9999998, !noalias !9999999
  %v9664 = load i64, ptr %slot1620, align 8
  %p9666 = inttoptr i64 %v9664 to ptr
  %gep9667 = getelementptr i8, ptr %p9666, i64 16
  %op9665 = ptrtoint ptr %gep9667 to i64
  store i64 %op9665, ptr %slot1697, align 8
  %v9668 = load i64, ptr %slot1645, align 8
  %v9669 = load i64, ptr %slot1697, align 8
  %p9670 = inttoptr i64 %v9669 to ptr
  store i64 %v9668, ptr %p9670, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone2137
bb_rcspinslow2137:
  %v9671 = load i64, ptr %slot1, align 8
  %p9672 = inttoptr i64 %v9671 to ptr
  %v9673 = load i64, ptr %slot1620, align 8
  %p9674 = inttoptr i64 %v9673 to ptr
  %v9675 = load i64, ptr %slot1587, align 8
  %p9676 = inttoptr i64 %v9675 to ptr
  %call9677 = call i32 @myl_qbe_rc_scope_pin(ptr %p9672, ptr %p9674, ptr %p9676) nomerge, !dbg !172
  store i32 %call9677, ptr %slot1698, align 8
  %v9678 = load i32, ptr %slot1698, align 8
  %cv9679 = zext i32 %v9678 to i64
  %cond9680 = icmp ne i64 %cv9679, 0
  br i1 %cond9680, label %bb_rcunique2214, label %bb_failure
bb_rcunique2214:
  br label %bb_rcspindone2137
bb_rcspindone2137:
  %v9681 = load i64, ptr %slot1587, align 8
  %v9682 = load i64, ptr %slot64, align 8
  %p9683 = inttoptr i64 %v9682 to ptr
  store i64 %v9681, ptr %p9683, align 8, !alias.scope !3, !noalias !4
  %v9684 = load i64, ptr %slot63, align 8
  %p9685 = inttoptr i64 %v9684 to ptr
  %ld9686 = load i64, ptr %p9685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9686, ptr %slot1699, align 8
  %v9687 = load i64, ptr %slot1699, align 8
  %v9688 = load i64, ptr %slot68, align 8
  %p9689 = inttoptr i64 %v9688 to ptr
  store i64 %v9687, ptr %p9689, align 8, !alias.scope !3, !noalias !4
  %v9690 = load i64, ptr %slot69, align 8
  %p9691 = inttoptr i64 %v9690 to ptr
  store i64 0, ptr %p9691, align 8, !alias.scope !3, !noalias !4
  %v9692 = load i64, ptr %slot70, align 8
  %p9693 = inttoptr i64 %v9692 to ptr
  store i64 0, ptr %p9693, align 8, !alias.scope !3, !noalias !4
  %v9694 = load i64, ptr %slot80, align 8
  store i64 %v9694, ptr %slot1700, align 8
  %v9695 = load i64, ptr %slot1700, align 8
  %p9696 = inttoptr i64 %v9695 to ptr
  store i64 0, ptr %p9696, align 8, !alias.scope !3, !noalias !4
  %v9697 = load i64, ptr %slot1700, align 8
  %p9699 = inttoptr i64 %v9697 to ptr
  %gep9700 = getelementptr i8, ptr %p9699, i64 8
  %op9698 = ptrtoint ptr %gep9700 to i64
  store i64 %op9698, ptr %slot1701, align 8
  %v9701 = load i64, ptr %slot1701, align 8
  %p9702 = inttoptr i64 %v9701 to ptr
  store i64 0, ptr %p9702, align 8, !alias.scope !3, !noalias !4
  %v9703 = load i64, ptr %slot1700, align 8
  %p9705 = inttoptr i64 %v9703 to ptr
  %gep9706 = getelementptr i8, ptr %p9705, i64 16
  %op9704 = ptrtoint ptr %gep9706 to i64
  store i64 %op9704, ptr %slot1702, align 8
  %v9707 = load i64, ptr %slot1702, align 8
  %p9708 = inttoptr i64 %v9707 to ptr
  store i64 0, ptr %p9708, align 8, !alias.scope !3, !noalias !4
  %v9709 = load i64, ptr %slot33, align 8
  %p9710 = inttoptr i64 %v9709 to ptr
  store i32 1, ptr %p9710, align 4, !alias.scope !3, !noalias !4
  %v9711 = load i64, ptr %slot89, align 8
  store i64 %v9711, ptr %slot1703, align 8
  %v9712 = load i64, ptr %slot68, align 8
  %p9713 = inttoptr i64 %v9712 to ptr
  %ld9714 = load i64, ptr %p9713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9714, ptr %slot1704, align 8
  %v9715 = load i64, ptr %slot1704, align 8
  %v9716 = load i64, ptr %slot38, align 8
  %p9717 = inttoptr i64 %v9716 to ptr
  store i64 %v9715, ptr %p9717, align 8, !alias.scope !3, !noalias !4
  %v9718 = load i64, ptr %slot38, align 8
  store i64 %v9718, ptr %slot1705, align 8
  %v9719 = load i64, ptr %slot1700, align 8
  %p9721 = inttoptr i64 %v9719 to ptr
  %gep9722 = getelementptr i8, ptr %p9721, i64 0
  %op9720 = ptrtoint ptr %gep9722 to i64
  store i64 %op9720, ptr %slot1706, align 8
  %v9723 = load i64, ptr %slot68, align 8
  %p9724 = inttoptr i64 %v9723 to ptr
  %ld9725 = load i64, ptr %p9724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9725, ptr %slot1707, align 8
  %v9726 = load i64, ptr %slot1707, align 8
  %v9727 = load i64, ptr %slot38, align 8
  %p9728 = inttoptr i64 %v9727 to ptr
  store i64 %v9726, ptr %p9728, align 8, !alias.scope !3, !noalias !4
  %v9729 = load i64, ptr %slot38, align 8
  store i64 %v9729, ptr %slot1708, align 8
  %v9730 = load i64, ptr %slot23, align 8
  %p9731 = inttoptr i64 %v9730 to ptr
  %ld9732 = load i32, ptr %p9731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9732, ptr %slot1709, align 8
  %v9733 = load i64, ptr %slot24, align 8
  %p9734 = inttoptr i64 %v9733 to ptr
  %ld9735 = load i32, ptr %p9734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9735, ptr %slot1710, align 8
  %v9736 = load i32, ptr %slot1710, align 8
  %op9737 = and i32 %v9736, 24
  store i32 %op9737, ptr %slot1710, align 8
  %v9738 = load i32, ptr %slot1710, align 8
  %cmp9739 = icmp eq i32 %v9738, 0
  %cv9740 = zext i1 %cmp9739 to i32
  store i32 %cv9740, ptr %slot1711, align 8
  %v9741 = load i32, ptr %slot1709, align 8
  %v9742 = load i32, ptr %slot1711, align 8
  %op9743 = and i32 %v9741, %v9742
  store i32 %op9743, ptr %slot1712, align 8
  %v9744 = load i32, ptr %slot1712, align 8
  %cv9745 = zext i32 %v9744 to i64
  %cond9746 = icmp ne i64 %cv9745, 0
  br i1 %cond9746, label %bb_rctake2227, label %bb_rccopy2227
bb_rctake2227:
  %v9747 = load i64, ptr %slot42, align 8
  store i64 %v9747, ptr %slot1713, align 8
  %v9748 = load i64, ptr %slot89, align 8
  store i64 %v9748, ptr %slot1714, align 8
  %v9749 = load i64, ptr %slot1708, align 8
  %v9750 = load i64, ptr %slot1713, align 8
  %op9751 = sub i64 %v9749, %v9750
  store i64 %op9751, ptr %slot1715, align 8
  %v9752 = load i64, ptr %slot1713, align 8
  %v9753 = load i64, ptr %slot1708, align 8
  %op9754 = sub i64 %v9752, %v9753
  store i64 %op9754, ptr %slot1716, align 8
  %v9755 = load i64, ptr %slot1715, align 8
  %cmp9756 = icmp ult i64 %v9755, 8
  %cv9757 = zext i1 %cmp9756 to i32
  store i32 %cv9757, ptr %slot1717, align 8
  %v9758 = load i64, ptr %slot1716, align 8
  %cmp9759 = icmp ult i64 %v9758, 8
  %cv9760 = zext i1 %cmp9759 to i32
  store i32 %cv9760, ptr %slot1718, align 8
  %v9761 = load i32, ptr %slot1717, align 8
  %v9762 = load i32, ptr %slot1718, align 8
  %op9763 = or i32 %v9761, %v9762
  store i32 %op9763, ptr %slot1719, align 8
  %v9764 = load i32, ptr %slot1719, align 8
  %cv9765 = zext i32 %v9764 to i64
  %cond9766 = icmp ne i64 %cv9765, 0
  br i1 %cond9766, label %bb_rcmoveslow2236, label %bb_rcmovecheck2236
bb_rcmovecheck2236:
  %v9767 = load i64, ptr %slot1708, align 8
  %p9769 = inttoptr i64 %v9767 to ptr
  %gep9770 = getelementptr i8, ptr %p9769, i64 0
  %op9768 = ptrtoint ptr %gep9770 to i64
  store i64 %op9768, ptr %slot1720, align 8
  %v9771 = load i64, ptr %slot1720, align 8
  %p9772 = inttoptr i64 %v9771 to ptr
  %ld9773 = load i64, ptr %p9772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9773, ptr %slot1721, align 8
  %v9774 = load i64, ptr %slot1721, align 8
  %cmp9775 = icmp ne i64 %v9774, 0
  %cv9776 = zext i1 %cmp9775 to i32
  store i32 %cv9776, ptr %slot1722, align 8
  %v9777 = load i32, ptr %slot1722, align 8
  %cv9778 = zext i32 %v9777 to i64
  %cond9779 = icmp ne i64 %cv9778, 0
  br i1 %cond9779, label %bb_rcmoveheader2244, label %bb_rcmovenext2244
bb_rcmoveheader2244:
  %v9780 = load i64, ptr %slot1721, align 8
  %op9781 = sub i64 %v9780, 16
  store i64 %op9781, ptr %slot1723, align 8
  %v9782 = load i64, ptr %slot1721, align 8
  %p9783 = inttoptr i64 %v9782 to ptr
  %rgep9784 = getelementptr i8, ptr %p9783, i64 -16
  %ld9785 = load i64, ptr %rgep9784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9785, ptr %slot1724, align 8
  %v9786 = load i64, ptr %slot1724, align 8
  %op9787 = and i64 %v9786, 5764607523034234881
  store i64 %op9787, ptr %slot1725, align 8
  %v9788 = load i64, ptr %slot1725, align 8
  %cmp9789 = icmp ne i64 %v9788, 0
  %cv9790 = zext i1 %cmp9789 to i32
  store i32 %cv9790, ptr %slot1726, align 8
  %v9791 = load i32, ptr %slot1726, align 8
  %cv9792 = zext i32 %v9791 to i64
  %cond9793 = icmp ne i64 %cv9792, 0
  br i1 %cond9793, label %bb_rcmoveslow2236, label %bb_rcmovenext2244
bb_rcmovenext2244:
  %v9794 = load i64, ptr %slot1708, align 8
  %v9795 = load i64, ptr %slot1713, align 8
  %p9796 = inttoptr i64 %v9794 to ptr
  %p9797 = inttoptr i64 %v9795 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9797, ptr %p9796, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9798 = load i64, ptr %slot1708, align 8
  %p9799 = inttoptr i64 %v9798 to ptr
  store i64 0, ptr %p9799, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2236
bb_rcmoveslow2236:
  %v9800 = load i64, ptr %slot88, align 8
  %v9801 = load i64, ptr %slot1713, align 8
  %v9802 = load i64, ptr %slot1708, align 8
  %v9803 = load i64, ptr %slot1714, align 8
  %cv9804 = trunc i64 %v9803 to i32
  %call9805 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v9800, i64 %v9801, i64 %v9802, i32 %cv9804) nomerge, !dbg !174
  store i32 %call9805, ptr %slot1727, align 8
  %v9806 = load i32, ptr %slot1727, align 8
  %cv9807 = zext i32 %v9806 to i64
  %cond9808 = icmp ne i64 %cv9807, 0
  br i1 %cond9808, label %bb_rcsuccess2251, label %bb_rcfailure2251
bb_rcfailure2251:
  %v9809 = load i64, ptr %slot88, align 8
  %p9810 = inttoptr i64 %v9809 to ptr
  %call9811 = call i32 @myl_rc_take_failure(ptr %p9810) nomerge, !dbg !174
  store i32 %call9811, ptr %slot1728, align 8
  %v9812 = load i64, ptr %slot1, align 8
  %p9813 = inttoptr i64 %v9812 to ptr
  %v9814 = load i32, ptr %slot1728, align 8
  %call9815 = call i32 @myl_qbe_rc_status(ptr %p9813, i32 %v9814) nomerge, !dbg !174
  store i32 %call9815, ptr %slot1729, align 8
  br label %bb_failure
bb_rcsuccess2251:
  br label %bb_rcmoved2236
bb_rcmoved2236:
  %v9816 = load i64, ptr %slot23, align 8
  %p9817 = inttoptr i64 %v9816 to ptr
  store i32 0, ptr %p9817, align 4, !alias.scope !3, !noalias !4
  %v9818 = load i64, ptr %slot32, align 8
  %p9819 = inttoptr i64 %v9818 to ptr
  store i32 2, ptr %p9819, align 4, !alias.scope !3, !noalias !4
  %v9820 = load i64, ptr %slot31, align 8
  %p9821 = inttoptr i64 %v9820 to ptr
  store i32 1, ptr %p9821, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2227
bb_rccopy2227:
  %v9822 = load i64, ptr %slot42, align 8
  store i64 %v9822, ptr %slot1730, align 8
  %v9823 = load i64, ptr %slot89, align 8
  store i64 %v9823, ptr %slot1731, align 8
  %v9824 = load i64, ptr %slot1708, align 8
  %p9825 = inttoptr i64 %v9824 to ptr
  %ld9826 = load i64, ptr %p9825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9826, ptr %slot1732, align 8
  %v9827 = load i64, ptr %slot1732, align 8
  %cmp9828 = icmp ne i64 %v9827, 0
  %cv9829 = zext i1 %cmp9828 to i32
  store i32 %cv9829, ptr %slot1733, align 8
  %v9830 = load i32, ptr %slot1733, align 8
  %cv9831 = zext i32 %v9830 to i64
  %cond9832 = icmp ne i64 %cv9831, 0
  br i1 %cond9832, label %bb_rcgnn2260, label %bb_rcgplain2260
bb_rcgnn2260:
  %v9833 = load i64, ptr %slot1732, align 8
  %op9834 = sub i64 %v9833, 16
  store i64 %op9834, ptr %slot1734, align 8
  %v9835 = load i64, ptr %slot1732, align 8
  %p9836 = inttoptr i64 %v9835 to ptr
  %rgep9837 = getelementptr i8, ptr %p9836, i64 -16
  %ld9838 = load i64, ptr %rgep9837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9838, ptr %slot1735, align 8
  %v9839 = load i64, ptr %slot1735, align 8
  %op9840 = and i64 %v9839, 4611686018427387906
  store i64 %op9840, ptr %slot1736, align 8
  %v9841 = load i64, ptr %slot1736, align 8
  %cmp9842 = icmp ne i64 %v9841, 0
  %cv9843 = zext i1 %cmp9842 to i32
  store i32 %cv9843, ptr %slot1737, align 8
  %v9844 = load i32, ptr %slot1737, align 8
  %cv9845 = zext i32 %v9844 to i64
  %cond9846 = icmp ne i64 %cv9845, 0
  br i1 %cond9846, label %bb_rcgspecial2260, label %bb_rcginc2260
bb_rcginc2260:
  %v9847 = load i64, ptr %slot1732, align 8
  %op9848 = sub i64 %v9847, 32
  store i64 %op9848, ptr %slot1738, align 8
  %v9849 = load i64, ptr %slot1732, align 8
  %p9850 = inttoptr i64 %v9849 to ptr
  %rgep9851 = getelementptr i8, ptr %p9850, i64 -32
  %ld9852 = load i64, ptr %rgep9851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9852, ptr %slot1739, align 8
  %v9853 = load i64, ptr %slot1739, align 8
  %op9854 = add i64 %v9853, 1
  store i64 %op9854, ptr %slot1740, align 8
  %v9855 = load i64, ptr %slot1740, align 8
  %cmp9856 = icmp eq i64 %v9855, 0
  %cv9857 = zext i1 %cmp9856 to i32
  store i32 %cv9857, ptr %slot1741, align 8
  %v9858 = load i32, ptr %slot1741, align 8
  %cv9859 = zext i32 %v9858 to i64
  %cond9860 = icmp ne i64 %cv9859, 0
  br i1 %cond9860, label %bb_rcglimit2260, label %bb_rcgcapacity2260
bb_rcglimit2260:
  %v9861 = load i64, ptr %slot1, align 8
  %p9862 = inttoptr i64 %v9861 to ptr
  %call9863 = call i32 @myl_qbe_rc_status(ptr %p9862, i32 2) nomerge, !dbg !174
  store i32 %call9863, ptr %slot1742, align 8
  br label %bb_failure
bb_rcgcapacity2260:
  %v9864 = load i64, ptr %slot1740, align 8
  %v9865 = load i64, ptr %slot1732, align 8
  %p9866 = inttoptr i64 %v9865 to ptr
  %rgep9867 = getelementptr i8, ptr %p9866, i64 -32
  store i64 %v9864, ptr %rgep9867, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2260
bb_rcgspecial2260:
  %v9868 = load i64, ptr %slot1735, align 8
  %op9869 = and i64 %v9868, 4611686018427387904
  store i64 %op9869, ptr %slot1743, align 8
  %v9870 = load i64, ptr %slot1743, align 8
  %cmp9871 = icmp ne i64 %v9870, 0
  %cv9872 = zext i1 %cmp9871 to i32
  store i32 %cv9872, ptr %slot1744, align 8
  %v9873 = load i32, ptr %slot1744, align 8
  %cv9874 = zext i32 %v9873 to i64
  %cond9875 = icmp ne i64 %cv9874, 0
  br i1 %cond9875, label %bb_rcgslow2260, label %bb_rcgplain2260
bb_rcgslow2260:
  %v9876 = load i64, ptr %slot88, align 8
  %v9877 = load i64, ptr %slot1730, align 8
  %v9878 = load i64, ptr %slot1708, align 8
  %v9879 = load i64, ptr %slot1731, align 8
  %cv9880 = trunc i64 %v9879 to i32
  %call9881 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v9876, i64 %v9877, i64 %v9878, i32 %cv9880) nomerge, !dbg !174
  store i32 %call9881, ptr %slot1745, align 8
  %v9882 = load i32, ptr %slot1745, align 8
  %cv9883 = zext i32 %v9882 to i64
  %cond9884 = icmp ne i64 %cv9883, 0
  br i1 %cond9884, label %bb_rcsuccess2274, label %bb_rcfailure2274
bb_rcfailure2274:
  %v9885 = load i64, ptr %slot88, align 8
  %p9886 = inttoptr i64 %v9885 to ptr
  %call9887 = call i32 @myl_rc_take_failure(ptr %p9886) nomerge, !dbg !174
  store i32 %call9887, ptr %slot1746, align 8
  %v9888 = load i64, ptr %slot1, align 8
  %p9889 = inttoptr i64 %v9888 to ptr
  %v9890 = load i32, ptr %slot1746, align 8
  %call9891 = call i32 @myl_qbe_rc_status(ptr %p9889, i32 %v9890) nomerge, !dbg !174
  store i32 %call9891, ptr %slot1747, align 8
  br label %bb_failure
bb_rcsuccess2274:
  br label %bb_rcgdone2260
bb_rcgplain2260:
  %v9892 = load i64, ptr %slot1732, align 8
  %v9893 = load i64, ptr %slot1730, align 8
  %p9894 = inttoptr i64 %v9893 to ptr
  store i64 %v9892, ptr %p9894, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2260
bb_rcgdone2260:
  %v9895 = load i64, ptr %slot32, align 8
  %p9896 = inttoptr i64 %v9895 to ptr
  store i32 2, ptr %p9896, align 4, !alias.scope !3, !noalias !4
  %v9897 = load i64, ptr %slot31, align 8
  %p9898 = inttoptr i64 %v9897 to ptr
  store i32 1, ptr %p9898, align 4, !alias.scope !3, !noalias !4
  %v9899 = load i64, ptr %slot23, align 8
  %p9900 = inttoptr i64 %v9899 to ptr
  %ld9901 = load i32, ptr %p9900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9901, ptr %slot1748, align 8
  %v9902 = load i32, ptr %slot1748, align 8
  %cv9903 = zext i32 %v9902 to i64
  %cond9904 = icmp ne i64 %cv9903, 0
  br i1 %cond9904, label %bb_rcslotdrop2281, label %bb_rcslotdone2281
bb_rcslotdrop2281:
  %v9905 = load i64, ptr %slot23, align 8
  %p9906 = inttoptr i64 %v9905 to ptr
  store i32 0, ptr %p9906, align 4, !alias.scope !3, !noalias !4
  %v9907 = load i64, ptr %slot34, align 8
  store i64 %v9907, ptr %slot1749, align 8
  %v9908 = load i64, ptr %slot24, align 8
  %p9909 = inttoptr i64 %v9908 to ptr
  %ld9910 = load i32, ptr %p9909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9910, ptr %slot1750, align 8
  %v9911 = load i32, ptr %slot1750, align 8
  %op9912 = and i32 %v9911, 28
  store i32 %op9912, ptr %slot1751, align 8
  %v9913 = load i32, ptr %slot1751, align 8
  %cv9914 = zext i32 %v9913 to i64
  %cond9915 = icmp ne i64 %cv9914, 0
  br i1 %cond9915, label %bb_rcslotrole2281, label %bb_rcslotowner2281
bb_rcslotrole2281:
  %v9916 = load i64, ptr %slot88, align 8
  store i64 %v9916, ptr %slot1752, align 8
  %v9917 = load i64, ptr %slot1749, align 8
  %p9918 = inttoptr i64 %v9917 to ptr
  %ld9919 = load i64, ptr %p9918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9919, ptr %slot1753, align 8
  %v9920 = load i64, ptr %slot1753, align 8
  %cmp9921 = icmp ne i64 %v9920, 0
  %cv9922 = zext i1 %cmp9921 to i32
  store i32 %cv9922, ptr %slot1754, align 8
  %v9923 = load i32, ptr %slot1754, align 8
  %cv9924 = zext i32 %v9923 to i64
  %cond9925 = icmp ne i64 %cv9924, 0
  br i1 %cond9925, label %bb_rcgnn2297, label %bb_rcgdone2297
bb_rcgnn2297:
  %v9926 = load i64, ptr %slot1753, align 8
  %op9927 = sub i64 %v9926, 16
  store i64 %op9927, ptr %slot1755, align 8
  %v9928 = load i64, ptr %slot1753, align 8
  %p9929 = inttoptr i64 %v9928 to ptr
  %rgep9930 = getelementptr i8, ptr %p9929, i64 -16
  %ld9931 = load i64, ptr %rgep9930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9931, ptr %slot1756, align 8
  %v9932 = load i64, ptr %slot1756, align 8
  %op9933 = and i64 %v9932, 4611686018427387906
  store i64 %op9933, ptr %slot1757, align 8
  %v9934 = load i64, ptr %slot1757, align 8
  %cmp9935 = icmp ne i64 %v9934, 0
  %cv9936 = zext i1 %cmp9935 to i32
  store i32 %cv9936, ptr %slot1758, align 8
  %v9937 = load i32, ptr %slot1758, align 8
  %cv9938 = zext i32 %v9937 to i64
  %cond9939 = icmp ne i64 %cv9938, 0
  br i1 %cond9939, label %bb_rcgclear2297, label %bb_rcgcounted2297
bb_rcgcounted2297:
  %v9940 = load i64, ptr %slot1753, align 8
  %op9941 = sub i64 %v9940, 24
  store i64 %op9941, ptr %slot1759, align 8
  %v9942 = load i64, ptr %slot1753, align 8
  %p9943 = inttoptr i64 %v9942 to ptr
  %rgep9944 = getelementptr i8, ptr %p9943, i64 -24
  %ld9945 = load i64, ptr %rgep9944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9945, ptr %slot1760, align 8
  %v9946 = load i64, ptr %slot1760, align 8
  %op9947 = sub i64 %v9946, 1
  store i64 %op9947, ptr %slot1761, align 8
  %v9948 = load i64, ptr %slot1761, align 8
  %cmp9949 = icmp eq i64 %v9948, 0
  %cv9950 = zext i1 %cmp9949 to i32
  store i32 %cv9950, ptr %slot1762, align 8
  %v9951 = load i32, ptr %slot1762, align 8
  %cv9952 = zext i32 %v9951 to i64
  %cond9953 = icmp ne i64 %cv9952, 0
  br i1 %cond9953, label %bb_rcglast2297, label %bb_rcgdec2297
bb_rcglast2297:
  %v9954 = load i64, ptr %slot1753, align 8
  %op9955 = sub i64 %v9954, 32
  store i64 %op9955, ptr %slot1763, align 8
  %v9956 = load i64, ptr %slot1753, align 8
  %p9957 = inttoptr i64 %v9956 to ptr
  %rgep9958 = getelementptr i8, ptr %p9957, i64 -32
  %ld9959 = load i64, ptr %rgep9958, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9959, ptr %slot1764, align 8
  %v9960 = load i64, ptr %slot1764, align 8
  %cmp9961 = icmp ne i64 %v9960, 0
  %cv9962 = zext i1 %cmp9961 to i32
  store i32 %cv9962, ptr %slot1765, align 8
  %v9963 = load i32, ptr %slot1765, align 8
  %cv9964 = zext i32 %v9963 to i64
  %cond9965 = icmp ne i64 %cv9964, 0
  br i1 %cond9965, label %bb_rcgdec2297, label %bb_rcgslow2297
bb_rcgslow2297:
  %v9966 = load i64, ptr %slot1752, align 8
  %v9967 = load i64, ptr %slot1749, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9966, i64 %v9967) nomerge, !dbg !174
  br label %bb_rcgdone2297
bb_rcgdec2297:
  %v9968 = load i64, ptr %slot1761, align 8
  %v9969 = load i64, ptr %slot1753, align 8
  %p9970 = inttoptr i64 %v9969 to ptr
  %rgep9971 = getelementptr i8, ptr %p9970, i64 -24
  store i64 %v9968, ptr %rgep9971, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2297
bb_rcgclear2297:
  %v9972 = load i64, ptr %slot1749, align 8
  %p9973 = inttoptr i64 %v9972 to ptr
  store i64 0, ptr %p9973, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2297
bb_rcgdone2297:
  br label %bb_rcslotdone2281
bb_rcslotowner2281:
  %v9974 = load i64, ptr %slot88, align 8
  store i64 %v9974, ptr %slot1766, align 8
  %v9975 = load i64, ptr %slot1749, align 8
  %p9976 = inttoptr i64 %v9975 to ptr
  %ld9977 = load i64, ptr %p9976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9977, ptr %slot1767, align 8
  %v9978 = load i64, ptr %slot1767, align 8
  %cmp9979 = icmp ne i64 %v9978, 0
  %cv9980 = zext i1 %cmp9979 to i32
  store i32 %cv9980, ptr %slot1768, align 8
  %v9981 = load i32, ptr %slot1768, align 8
  %cv9982 = zext i32 %v9981 to i64
  %cond9983 = icmp ne i64 %cv9982, 0
  br i1 %cond9983, label %bb_rcgnn2312, label %bb_rcgdone2312
bb_rcgnn2312:
  %v9984 = load i64, ptr %slot1767, align 8
  %op9985 = sub i64 %v9984, 16
  store i64 %op9985, ptr %slot1769, align 8
  %v9986 = load i64, ptr %slot1767, align 8
  %p9987 = inttoptr i64 %v9986 to ptr
  %rgep9988 = getelementptr i8, ptr %p9987, i64 -16
  %ld9989 = load i64, ptr %rgep9988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9989, ptr %slot1770, align 8
  %v9990 = load i64, ptr %slot1770, align 8
  %op9991 = and i64 %v9990, 4611686018427387906
  store i64 %op9991, ptr %slot1771, align 8
  %v9992 = load i64, ptr %slot1771, align 8
  %cmp9993 = icmp ne i64 %v9992, 0
  %cv9994 = zext i1 %cmp9993 to i32
  store i32 %cv9994, ptr %slot1772, align 8
  %v9995 = load i32, ptr %slot1772, align 8
  %cv9996 = zext i32 %v9995 to i64
  %cond9997 = icmp ne i64 %cv9996, 0
  br i1 %cond9997, label %bb_rcgclear2312, label %bb_rcgcounted2312
bb_rcgcounted2312:
  %v9998 = load i64, ptr %slot1767, align 8
  %op9999 = sub i64 %v9998, 32
  store i64 %op9999, ptr %slot1773, align 8
  %v10000 = load i64, ptr %slot1767, align 8
  %p10001 = inttoptr i64 %v10000 to ptr
  %rgep10002 = getelementptr i8, ptr %p10001, i64 -32
  %ld10003 = load i64, ptr %rgep10002, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10003, ptr %slot1774, align 8
  %v10004 = load i64, ptr %slot1774, align 8
  %op10005 = sub i64 %v10004, 1
  store i64 %op10005, ptr %slot1775, align 8
  %v10006 = load i64, ptr %slot1775, align 8
  %cmp10007 = icmp eq i64 %v10006, 0
  %cv10008 = zext i1 %cmp10007 to i32
  store i32 %cv10008, ptr %slot1776, align 8
  %v10009 = load i32, ptr %slot1776, align 8
  %cv10010 = zext i32 %v10009 to i64
  %cond10011 = icmp ne i64 %cv10010, 0
  br i1 %cond10011, label %bb_rcglast2312, label %bb_rcgdec2312
bb_rcglast2312:
  %v10012 = load i64, ptr %slot1767, align 8
  %op10013 = sub i64 %v10012, 24
  store i64 %op10013, ptr %slot1777, align 8
  %v10014 = load i64, ptr %slot1767, align 8
  %p10015 = inttoptr i64 %v10014 to ptr
  %rgep10016 = getelementptr i8, ptr %p10015, i64 -24
  %ld10017 = load i64, ptr %rgep10016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10017, ptr %slot1778, align 8
  %v10018 = load i64, ptr %slot1778, align 8
  %cmp10019 = icmp ne i64 %v10018, 0
  %cv10020 = zext i1 %cmp10019 to i32
  store i32 %cv10020, ptr %slot1779, align 8
  %v10021 = load i32, ptr %slot1779, align 8
  %cv10022 = zext i32 %v10021 to i64
  %cond10023 = icmp ne i64 %cv10022, 0
  br i1 %cond10023, label %bb_rcgdec2312, label %bb_rcgslow2312
bb_rcgslow2312:
  %v10024 = load i64, ptr %slot1766, align 8
  %v10025 = load i64, ptr %slot1749, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v10024, i64 %v10025) nomerge, !dbg !174
  br label %bb_rcgdone2312
bb_rcgdec2312:
  %v10026 = load i64, ptr %slot1775, align 8
  %v10027 = load i64, ptr %slot1767, align 8
  %p10028 = inttoptr i64 %v10027 to ptr
  %rgep10029 = getelementptr i8, ptr %p10028, i64 -32
  store i64 %v10026, ptr %rgep10029, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2312
bb_rcgclear2312:
  %v10030 = load i64, ptr %slot1749, align 8
  %p10031 = inttoptr i64 %v10030 to ptr
  store i64 0, ptr %p10031, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2312
bb_rcgdone2312:
  br label %bb_rcslotdone2281
bb_rcslotdone2281:
  br label %bb_rcprepared2227
bb_rcprepared2227:
  %v10032 = load i64, ptr %slot42, align 8
  store i64 %v10032, ptr %slot1780, align 8
  %v10033 = load i64, ptr %slot1780, align 8
  %v10034 = load i64, ptr %slot1706, align 8
  %p10035 = inttoptr i64 %v10033 to ptr
  %p10036 = inttoptr i64 %v10034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10036, ptr %p10035, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10037 = load i64, ptr %slot31, align 8
  %p10038 = inttoptr i64 %v10037 to ptr
  store i32 0, ptr %p10038, align 4, !alias.scope !3, !noalias !4
  %v10039 = load i64, ptr %slot69, align 8
  store i64 %v10039, ptr %slot1781, align 8
  %v10040 = load i64, ptr %slot1700, align 8
  %p10042 = inttoptr i64 %v10040 to ptr
  %gep10043 = getelementptr i8, ptr %p10042, i64 8
  %op10041 = ptrtoint ptr %gep10043 to i64
  store i64 %op10041, ptr %slot1782, align 8
  %v10044 = load i64, ptr %slot1781, align 8
  %p10045 = inttoptr i64 %v10044 to ptr
  %ld10046 = load i64, ptr %p10045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10046, ptr %slot1783, align 8
  %v10047 = load i64, ptr %slot1783, align 8
  %v10048 = load i64, ptr %slot1782, align 8
  %p10049 = inttoptr i64 %v10048 to ptr
  store i64 %v10047, ptr %p10049, align 8, !alias.scope !3, !noalias !4
  %v10050 = load i64, ptr %slot70, align 8
  store i64 %v10050, ptr %slot1784, align 8
  %v10051 = load i64, ptr %slot1700, align 8
  %p10053 = inttoptr i64 %v10051 to ptr
  %gep10054 = getelementptr i8, ptr %p10053, i64 16
  %op10052 = ptrtoint ptr %gep10054 to i64
  store i64 %op10052, ptr %slot1785, align 8
  %v10055 = load i64, ptr %slot1784, align 8
  %p10056 = inttoptr i64 %v10055 to ptr
  %ld10057 = load i8, ptr %p10056, align 1, !alias.scope !3, !noalias !4
  %ext10058 = zext i8 %ld10057 to i64
  store i64 %ext10058, ptr %slot1786, align 8
  %v10059 = load i64, ptr %slot1786, align 8
  %cv10060 = trunc i64 %v10059 to i8
  %v10061 = load i64, ptr %slot1785, align 8
  %p10062 = inttoptr i64 %v10061 to ptr
  store i8 %cv10060, ptr %p10062, align 1, !alias.scope !3, !noalias !4
  %v10063 = load i64, ptr %slot1700, align 8
  %v10064 = load i64, ptr %slot68, align 8
  %p10065 = inttoptr i64 %v10064 to ptr
  store i64 %v10063, ptr %p10065, align 8, !alias.scope !3, !noalias !4
  %v10066 = load i64, ptr %slot68, align 8
  %p10067 = inttoptr i64 %v10066 to ptr
  %ld10068 = load i64, ptr %p10067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10068, ptr %slot1787, align 8
  %v10069 = load i64, ptr %slot34, align 8
  store i64 %v10069, ptr %slot1788, align 8
  %v10070 = load i64, ptr %slot1787, align 8
  %v10071 = load i64, ptr %slot1788, align 8
  %p10072 = inttoptr i64 %v10070 to ptr
  %p10073 = inttoptr i64 %v10071 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10073, ptr %p10072, i64 24, i1 false)
  %v10074 = load i64, ptr %slot24, align 8
  %p10075 = inttoptr i64 %v10074 to ptr
  store i32 2, ptr %p10075, align 4, !alias.scope !3, !noalias !4
  %v10076 = load i64, ptr %slot23, align 8
  %p10077 = inttoptr i64 %v10076 to ptr
  store i32 1, ptr %p10077, align 4, !alias.scope !3, !noalias !4
  %v10078 = load i64, ptr %slot1788, align 8
  %v10079 = load i64, ptr %slot68, align 8
  %p10080 = inttoptr i64 %v10079 to ptr
  store i64 %v10078, ptr %p10080, align 8, !alias.scope !3, !noalias !4
  %v10081 = load i64, ptr %slot64, align 8
  %p10082 = inttoptr i64 %v10081 to ptr
  %ld10083 = load i64, ptr %p10082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10083, ptr %slot1789, align 8
  %v10084 = load i64, ptr %slot68, align 8
  %p10085 = inttoptr i64 %v10084 to ptr
  %ld10086 = load i64, ptr %p10085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10086, ptr %slot1790, align 8
  %v10087 = load i64, ptr %slot88, align 8
  %v10088 = load i64, ptr %slot1789, align 8
  %v10089 = load i64, ptr %slot1790, align 8
  %call10090 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_list_append(i64 %v10087, i64 %v10088, i64 %v10089) nomerge, !dbg !176
  store i32 %call10090, ptr %slot1791, align 8
  %v10091 = load i32, ptr %slot1791, align 8
  %cv10092 = zext i32 %v10091 to i64
  %cond10093 = icmp ne i64 %cv10092, 0
  br i1 %cond10093, label %bb_success2331, label %bb_failed2331
bb_failed2331:
  %v10094 = load i64, ptr %slot1, align 8
  %p10095 = inttoptr i64 %v10094 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10095) nomerge, !dbg !176
  unreachable
bb_success2331:
  %v10096 = load i64, ptr %slot68, align 8
  %p10097 = inttoptr i64 %v10096 to ptr
  store i64 0, ptr %p10097, align 8, !alias.scope !3, !noalias !4
  %v10098 = load i64, ptr %slot23, align 8
  %p10099 = inttoptr i64 %v10098 to ptr
  %ld10100 = load i32, ptr %p10099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10100, ptr %slot1792, align 8
  %v10101 = load i32, ptr %slot1792, align 8
  %cv10102 = zext i32 %v10101 to i64
  %cond10103 = icmp ne i64 %cv10102, 0
  br i1 %cond10103, label %bb_rcslotdrop2334, label %bb_rcslotdone2334
bb_rcslotdrop2334:
  %v10104 = load i64, ptr %slot23, align 8
  %p10105 = inttoptr i64 %v10104 to ptr
  store i32 0, ptr %p10105, align 4, !alias.scope !3, !noalias !4
  %v10106 = load i64, ptr %slot34, align 8
  store i64 %v10106, ptr %slot1793, align 8
  %v10107 = load i64, ptr %slot24, align 8
  %p10108 = inttoptr i64 %v10107 to ptr
  %ld10109 = load i32, ptr %p10108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10109, ptr %slot1794, align 8
  %v10110 = load i32, ptr %slot1794, align 8
  %op10111 = and i32 %v10110, 28
  store i32 %op10111, ptr %slot1795, align 8
  %v10112 = load i32, ptr %slot1795, align 8
  %cv10113 = zext i32 %v10112 to i64
  %cond10114 = icmp ne i64 %cv10113, 0
  br i1 %cond10114, label %bb_rcslotrole2334, label %bb_rcslotowner2334
bb_rcslotrole2334:
  %v10115 = load i64, ptr %slot88, align 8
  store i64 %v10115, ptr %slot1796, align 8
  %v10116 = load i64, ptr %slot1796, align 8
  %v10117 = load i64, ptr %slot1793, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v10116, i64 %v10117) nomerge, !dbg !176
  br label %bb_rcslotdone2334
bb_rcslotowner2334:
  %v10118 = load i64, ptr %slot88, align 8
  store i64 %v10118, ptr %slot1797, align 8
  %v10119 = load i64, ptr %slot1797, align 8
  %v10120 = load i64, ptr %slot1793, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v10119, i64 %v10120) nomerge, !dbg !176
  br label %bb_rcslotdone2334
bb_rcslotdone2334:
  %v10121 = load i64, ptr %slot48, align 8
  store i64 %v10121, ptr %slot1798, align 8
  %v10122 = load i64, ptr %slot1798, align 8
  %p10124 = inttoptr i64 %v10122 to ptr
  %gep10125 = getelementptr i8, ptr %p10124, i64 24
  %op10123 = ptrtoint ptr %gep10125 to i64
  store i64 %op10123, ptr %slot1799, align 8
  %v10126 = load i64, ptr %slot1799, align 8
  %p10127 = inttoptr i64 %v10126 to ptr
  %ld10128 = load i32, ptr %p10127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10128, ptr %slot1800, align 8
  %v10129 = load i32, ptr %slot1800, align 8
  %cv10130 = zext i32 %v10129 to i64
  %cond10131 = icmp ne i64 %cv10130, 0
  br i1 %cond10131, label %bb_rcsendactive2342, label %bb_rcsenddone2342
bb_rcsendactive2342:
  %v10132 = load i64, ptr %slot88, align 8
  %p10134 = inttoptr i64 %v10132 to ptr
  %gep10135 = getelementptr i8, ptr %p10134, i64 5640
  %op10133 = ptrtoint ptr %gep10135 to i64
  store i64 %op10133, ptr %slot1801, align 8
  %v10136 = load i64, ptr %slot1801, align 8
  %p10137 = inttoptr i64 %v10136 to ptr
  %ld10138 = load i64, ptr %p10137, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10138, ptr %slot1802, align 8
  %v10139 = load i64, ptr %slot1802, align 8
  %op10140 = add i64 %v10139, 248
  store i64 %op10140, ptr %slot1803, align 8
  %v10141 = load i64, ptr %slot1803, align 8
  %p10142 = inttoptr i64 %v10141 to ptr
  %ld10143 = load i64, ptr %p10142, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10143, ptr %slot1804, align 8
  %v10144 = load i64, ptr %slot1804, align 8
  %v10145 = load i64, ptr %slot1798, align 8
  %cmp10146 = icmp eq i64 %v10144, %v10145
  %cv10147 = zext i1 %cmp10146 to i32
  store i32 %cv10147, ptr %slot1805, align 8
  %v10148 = load i32, ptr %slot1805, align 8
  %cv10149 = zext i32 %v10148 to i64
  %cond10150 = icmp ne i64 %cv10149, 0
  br i1 %cond10150, label %bb_rcs2350, label %bb_rcsendslow2342
bb_rcs2350:
  %v10151 = load i64, ptr %slot1802, align 8
  %op10152 = add i64 %v10151, 200
  store i64 %op10152, ptr %slot1806, align 8
  %v10153 = load i64, ptr %slot1806, align 8
  %p10154 = inttoptr i64 %v10153 to ptr
  %ld10155 = load i64, ptr %p10154, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10155, ptr %slot1807, align 8
  %v10156 = load i64, ptr %slot1807, align 8
  %cmp10157 = icmp eq i64 %v10156, 0
  %cv10158 = zext i1 %cmp10157 to i32
  store i32 %cv10158, ptr %slot1808, align 8
  %v10159 = load i32, ptr %slot1808, align 8
  %cv10160 = zext i32 %v10159 to i64
  %cond10161 = icmp ne i64 %cv10160, 0
  br i1 %cond10161, label %bb_rcs2354, label %bb_rcsendslow2342
bb_rcs2354:
  %v10162 = load i64, ptr %slot1798, align 8
  %p10164 = inttoptr i64 %v10162 to ptr
  %gep10165 = getelementptr i8, ptr %p10164, i64 16
  %op10163 = ptrtoint ptr %gep10165 to i64
  store i64 %op10163, ptr %slot1809, align 8
  %v10166 = load i64, ptr %slot1809, align 8
  %p10167 = inttoptr i64 %v10166 to ptr
  %ld10168 = load i64, ptr %p10167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10168, ptr %slot1810, align 8
  %v10169 = load i64, ptr %slot1810, align 8
  %cmp10170 = icmp ne i64 %v10169, 0
  %cv10171 = zext i1 %cmp10170 to i32
  store i32 %cv10171, ptr %slot1811, align 8
  %v10172 = load i32, ptr %slot1811, align 8
  %cv10173 = zext i32 %v10172 to i64
  %cond10174 = icmp ne i64 %cv10173, 0
  br i1 %cond10174, label %bb_rcsendnode2342, label %bb_rcsendunlink2342
bb_rcsendnode2342:
  %v10175 = load i64, ptr %slot1810, align 8
  %op10176 = add i64 %v10175, 0
  store i64 %op10176, ptr %slot1812, align 8
  %v10177 = load i64, ptr %slot1812, align 8
  %p10178 = inttoptr i64 %v10177 to ptr
  %ld10179 = load i64, ptr %p10178, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10179, ptr %slot1813, align 8
  %v10180 = load i64, ptr %slot1813, align 8
  %cmp10181 = icmp eq i64 %v10180, 0
  %cv10182 = zext i1 %cmp10181 to i32
  store i32 %cv10182, ptr %slot1814, align 8
  %v10183 = load i32, ptr %slot1814, align 8
  %cv10184 = zext i32 %v10183 to i64
  %cond10185 = icmp ne i64 %cv10184, 0
  br i1 %cond10185, label %bb_rcs2361, label %bb_rcsendslow2342
bb_rcs2361:
  %v10186 = load i64, ptr %slot1802, align 8
  %op10187 = add i64 %v10186, 264
  store i64 %op10187, ptr %slot1815, align 8
  %v10188 = load i64, ptr %slot1815, align 8
  %p10189 = inttoptr i64 %v10188 to ptr
  %ld10190 = load i64, ptr %p10189, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10190, ptr %slot1816, align 8
  %v10191 = load i64, ptr %slot1816, align 8
  %cmp10192 = icmp ult i64 %v10191, 32
  %cv10193 = zext i1 %cmp10192 to i32
  store i32 %cv10193, ptr %slot1817, align 8
  %v10194 = load i32, ptr %slot1817, align 8
  %cv10195 = zext i32 %v10194 to i64
  %cond10196 = icmp ne i64 %cv10195, 0
  br i1 %cond10196, label %bb_rcs2365, label %bb_rcsendslow2342
bb_rcs2365:
  %v10197 = load i64, ptr %slot1810, align 8
  %op10198 = add i64 %v10197, 8
  store i64 %op10198, ptr %slot1818, align 8
  %v10199 = load i64, ptr %slot1818, align 8
  %p10200 = inttoptr i64 %v10199 to ptr
  %ld10201 = load i64, ptr %p10200, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10201, ptr %slot1819, align 8
  %v10202 = load i64, ptr %slot1819, align 8
  %cmp10203 = icmp ne i64 %v10202, 0
  %cv10204 = zext i1 %cmp10203 to i32
  store i32 %cv10204, ptr %slot1820, align 8
  %v10205 = load i32, ptr %slot1820, align 8
  %cv10206 = zext i32 %v10205 to i64
  %cond10207 = icmp ne i64 %cv10206, 0
  br i1 %cond10207, label %bb_rcs2369, label %bb_rcsendslow2342
bb_rcs2369:
  %v10208 = load i64, ptr %slot1819, align 8
  %op10209 = sub i64 %v10208, 16
  store i64 %op10209, ptr %slot1821, align 8
  %v10210 = load i64, ptr %slot1819, align 8
  %p10211 = inttoptr i64 %v10210 to ptr
  %rgep10212 = getelementptr i8, ptr %p10211, i64 -16
  %ld10213 = load i64, ptr %rgep10212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10213, ptr %slot1822, align 8
  %v10214 = load i64, ptr %slot1822, align 8
  %op10215 = and i64 %v10214, 4611686018427387907
  store i64 %op10215, ptr %slot1823, align 8
  %v10216 = load i64, ptr %slot1823, align 8
  %cmp10217 = icmp eq i64 %v10216, 0
  %cv10218 = zext i1 %cmp10217 to i32
  store i32 %cv10218, ptr %slot1824, align 8
  %v10219 = load i32, ptr %slot1824, align 8
  %cv10220 = zext i32 %v10219 to i64
  %cond10221 = icmp ne i64 %cv10220, 0
  br i1 %cond10221, label %bb_rcs2374, label %bb_rcsendslow2342
bb_rcs2374:
  %v10222 = load i64, ptr %slot1819, align 8
  %op10223 = sub i64 %v10222, 24
  store i64 %op10223, ptr %slot1825, align 8
  %v10224 = load i64, ptr %slot1819, align 8
  %p10225 = inttoptr i64 %v10224 to ptr
  %rgep10226 = getelementptr i8, ptr %p10225, i64 -24
  %ld10227 = load i64, ptr %rgep10226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10227, ptr %slot1826, align 8
  %v10228 = load i64, ptr %slot1826, align 8
  %cmp10229 = icmp ne i64 %v10228, 0
  %cv10230 = zext i1 %cmp10229 to i32
  store i32 %cv10230, ptr %slot1827, align 8
  %v10231 = load i32, ptr %slot1827, align 8
  %cv10232 = zext i32 %v10231 to i64
  %cond10233 = icmp ne i64 %cv10232, 0
  br i1 %cond10233, label %bb_rcs2378, label %bb_rcsendslow2342
bb_rcs2378:
  %v10234 = load i64, ptr %slot1819, align 8
  %op10235 = sub i64 %v10234, 32
  store i64 %op10235, ptr %slot1828, align 8
  %v10236 = load i64, ptr %slot1819, align 8
  %p10237 = inttoptr i64 %v10236 to ptr
  %rgep10238 = getelementptr i8, ptr %p10237, i64 -32
  %ld10239 = load i64, ptr %rgep10238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10239, ptr %slot1829, align 8
  %v10240 = load i64, ptr %slot1826, align 8
  %cmp10241 = icmp ugt i64 %v10240, 1
  %cv10242 = zext i1 %cmp10241 to i32
  store i32 %cv10242, ptr %slot1830, align 8
  %v10243 = load i64, ptr %slot1829, align 8
  %cmp10244 = icmp ne i64 %v10243, 0
  %cv10245 = zext i1 %cmp10244 to i32
  store i32 %cv10245, ptr %slot1831, align 8
  %v10246 = load i32, ptr %slot1830, align 8
  %v10247 = load i32, ptr %slot1831, align 8
  %op10248 = or i32 %v10246, %v10247
  store i32 %op10248, ptr %slot1832, align 8
  %v10249 = load i32, ptr %slot1832, align 8
  %cv10250 = zext i32 %v10249 to i64
  %cond10251 = icmp ne i64 %cv10250, 0
  br i1 %cond10251, label %bb_rcs2384, label %bb_rcsendslow2342
bb_rcs2384:
  %v10252 = load i64, ptr %slot1810, align 8
  %op10253 = add i64 %v10252, 32
  store i64 %op10253, ptr %slot1833, align 8
  %v10254 = load i64, ptr %slot1833, align 8
  %p10255 = inttoptr i64 %v10254 to ptr
  %ld10256 = load i64, ptr %p10255, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10256, ptr %slot1834, align 8
  %v10257 = load i64, ptr %slot1834, align 8
  %cmp10258 = icmp ne i64 %v10257, 0
  %cv10259 = zext i1 %cmp10258 to i32
  store i32 %cv10259, ptr %slot1835, align 8
  %v10260 = load i32, ptr %slot1835, align 8
  %cv10261 = zext i32 %v10260 to i64
  %cond10262 = icmp ne i64 %cv10261, 0
  br i1 %cond10262, label %bb_rcsendbacking2342, label %bb_rcsendcommit2342
bb_rcsendbacking2342:
  %v10263 = load i64, ptr %slot1834, align 8
  %op10264 = sub i64 %v10263, 16
  store i64 %op10264, ptr %slot1836, align 8
  %v10265 = load i64, ptr %slot1834, align 8
  %p10266 = inttoptr i64 %v10265 to ptr
  %rgep10267 = getelementptr i8, ptr %p10266, i64 -16
  %ld10268 = load i64, ptr %rgep10267, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10268, ptr %slot1837, align 8
  %v10269 = load i64, ptr %slot1837, align 8
  %op10270 = and i64 %v10269, 4611686018427387907
  store i64 %op10270, ptr %slot1838, align 8
  %v10271 = load i64, ptr %slot1838, align 8
  %cmp10272 = icmp eq i64 %v10271, 0
  %cv10273 = zext i1 %cmp10272 to i32
  store i32 %cv10273, ptr %slot1839, align 8
  %v10274 = load i32, ptr %slot1839, align 8
  %cv10275 = zext i32 %v10274 to i64
  %cond10276 = icmp ne i64 %cv10275, 0
  br i1 %cond10276, label %bb_rcs2392, label %bb_rcsendslow2342
bb_rcs2392:
  %v10277 = load i64, ptr %slot1834, align 8
  %op10278 = sub i64 %v10277, 24
  store i64 %op10278, ptr %slot1840, align 8
  %v10279 = load i64, ptr %slot1834, align 8
  %p10280 = inttoptr i64 %v10279 to ptr
  %rgep10281 = getelementptr i8, ptr %p10280, i64 -24
  %ld10282 = load i64, ptr %rgep10281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10282, ptr %slot1841, align 8
  %v10283 = load i64, ptr %slot1841, align 8
  %cmp10284 = icmp ne i64 %v10283, 0
  %cv10285 = zext i1 %cmp10284 to i32
  store i32 %cv10285, ptr %slot1842, align 8
  %v10286 = load i32, ptr %slot1842, align 8
  %cv10287 = zext i32 %v10286 to i64
  %cond10288 = icmp ne i64 %cv10287, 0
  br i1 %cond10288, label %bb_rcs2396, label %bb_rcsendslow2342
bb_rcs2396:
  %v10289 = load i64, ptr %slot1834, align 8
  %op10290 = sub i64 %v10289, 32
  store i64 %op10290, ptr %slot1843, align 8
  %v10291 = load i64, ptr %slot1834, align 8
  %p10292 = inttoptr i64 %v10291 to ptr
  %rgep10293 = getelementptr i8, ptr %p10292, i64 -32
  %ld10294 = load i64, ptr %rgep10293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10294, ptr %slot1844, align 8
  %v10295 = load i64, ptr %slot1841, align 8
  %cmp10296 = icmp ugt i64 %v10295, 1
  %cv10297 = zext i1 %cmp10296 to i32
  store i32 %cv10297, ptr %slot1845, align 8
  %v10298 = load i64, ptr %slot1844, align 8
  %cmp10299 = icmp ne i64 %v10298, 0
  %cv10300 = zext i1 %cmp10299 to i32
  store i32 %cv10300, ptr %slot1846, align 8
  %v10301 = load i32, ptr %slot1845, align 8
  %v10302 = load i32, ptr %slot1846, align 8
  %op10303 = or i32 %v10301, %v10302
  store i32 %op10303, ptr %slot1847, align 8
  %v10304 = load i32, ptr %slot1847, align 8
  %cv10305 = zext i32 %v10304 to i64
  %cond10306 = icmp ne i64 %cv10305, 0
  br i1 %cond10306, label %bb_rcs2402, label %bb_rcsendslow2342
bb_rcs2402:
  br label %bb_rcsendcommit2342
bb_rcsendcommit2342:
  %v10307 = load i64, ptr %slot1810, align 8
  %op10308 = add i64 %v10307, 24
  store i64 %op10308, ptr %slot1848, align 8
  %v10309 = load i64, ptr %slot1848, align 8
  %p10310 = inttoptr i64 %v10309 to ptr
  %ld10311 = load i32, ptr %p10310, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld10311, ptr %slot1849, align 8
  %v10312 = load i32, ptr %slot1849, align 8
  %cv10313 = zext i32 %v10312 to i64
  %cond10314 = icmp ne i64 %cv10313, 0
  br i1 %cond10314, label %bb_rcsendrestore2342, label %bb_rcsendreturned2342
bb_rcsendrestore2342:
  %v10315 = load i64, ptr %slot1810, align 8
  %op10316 = add i64 %v10315, 16
  store i64 %op10316, ptr %slot1850, align 8
  %v10317 = load i64, ptr %slot1850, align 8
  %p10318 = inttoptr i64 %v10317 to ptr
  %ld10319 = load i64, ptr %p10318, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10319, ptr %slot1851, align 8
  %v10320 = load i64, ptr %slot1822, align 8
  %op10321 = and i64 %v10320, 17293822569102704639
  store i64 %op10321, ptr %slot1852, align 8
  %v10322 = load i64, ptr %slot1852, align 8
  %v10323 = load i64, ptr %slot1851, align 8
  %op10324 = or i64 %v10322, %v10323
  store i64 %op10324, ptr %slot1853, align 8
  %v10325 = load i64, ptr %slot1819, align 8
  %op10326 = sub i64 %v10325, 16
  store i64 %op10326, ptr %slot1854, align 8
  %v10327 = load i64, ptr %slot1853, align 8
  %v10328 = load i64, ptr %slot1819, align 8
  %p10329 = inttoptr i64 %v10328 to ptr
  %rgep10330 = getelementptr i8, ptr %p10329, i64 -16
  store i64 %v10327, ptr %rgep10330, align 8, !alias.scope !9, !noalias !10
  %v10331 = load i64, ptr %slot1798, align 8
  %p10333 = inttoptr i64 %v10331 to ptr
  %gep10334 = getelementptr i8, ptr %p10333, i64 16
  %op10332 = ptrtoint ptr %gep10334 to i64
  store i64 %op10332, ptr %slot1855, align 8
  br label %bb_rcsendreturned2342
bb_rcsendreturned2342:
  %v10335 = load i64, ptr %slot1855, align 8
  %p10336 = inttoptr i64 %v10335 to ptr
  store i64 0, ptr %p10336, align 8, !alias.scope !3, !noalias !4
  %v10337 = load i64, ptr %slot1802, align 8
  %op10338 = add i64 %v10337, 256
  store i64 %op10338, ptr %slot1856, align 8
  %v10339 = load i64, ptr %slot1856, align 8
  %p10340 = inttoptr i64 %v10339 to ptr
  %ld10341 = load i64, ptr %p10340, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10341, ptr %slot1857, align 8
  %v10342 = load i64, ptr %slot1810, align 8
  %op10343 = add i64 %v10342, 0
  store i64 %op10343, ptr %slot1858, align 8
  %v10344 = load i64, ptr %slot1857, align 8
  %v10345 = load i64, ptr %slot1858, align 8
  %p10346 = inttoptr i64 %v10345 to ptr
  store i64 %v10344, ptr %p10346, align 8, !alias.scope !9999998, !noalias !9999999
  %v10347 = load i64, ptr %slot1802, align 8
  %op10348 = add i64 %v10347, 256
  store i64 %op10348, ptr %slot1859, align 8
  %v10349 = load i64, ptr %slot1810, align 8
  %v10350 = load i64, ptr %slot1859, align 8
  %p10351 = inttoptr i64 %v10350 to ptr
  store i64 %v10349, ptr %p10351, align 8, !alias.scope !9999998, !noalias !9999999
  %v10352 = load i64, ptr %slot1802, align 8
  %op10353 = add i64 %v10352, 264
  store i64 %op10353, ptr %slot1860, align 8
  %v10354 = load i64, ptr %slot1860, align 8
  %p10355 = inttoptr i64 %v10354 to ptr
  %ld10356 = load i64, ptr %p10355, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10356, ptr %slot1861, align 8
  %v10357 = load i64, ptr %slot1861, align 8
  %op10358 = add i64 %v10357, 1
  store i64 %op10358, ptr %slot1862, align 8
  %v10359 = load i64, ptr %slot1862, align 8
  %v10360 = load i64, ptr %slot1860, align 8
  %p10361 = inttoptr i64 %v10360 to ptr
  store i64 %v10359, ptr %p10361, align 8, !alias.scope !9999998, !noalias !9999999
  %v10362 = load i64, ptr %slot88, align 8
  %p10364 = inttoptr i64 %v10362 to ptr
  %gep10365 = getelementptr i8, ptr %p10364, i64 24
  %op10363 = ptrtoint ptr %gep10365 to i64
  store i64 %op10363, ptr %slot1863, align 8
  %v10366 = load i64, ptr %slot1863, align 8
  %p10367 = inttoptr i64 %v10366 to ptr
  %ld10368 = load i64, ptr %p10367, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10368, ptr %slot1864, align 8
  %v10369 = load i64, ptr %slot1864, align 8
  %op10370 = add i64 %v10369, 18446744073709551576
  store i64 %op10370, ptr %slot1865, align 8
  %v10371 = load i64, ptr %slot1865, align 8
  %v10372 = load i64, ptr %slot1863, align 8
  %p10373 = inttoptr i64 %v10372 to ptr
  store i64 %v10371, ptr %p10373, align 8, !alias.scope !9999998, !noalias !9999999
  %v10374 = load i64, ptr %slot1802, align 8
  %op10375 = add i64 %v10374, 48
  store i64 %op10375, ptr %slot1866, align 8
  %v10376 = load i64, ptr %slot1866, align 8
  %p10377 = inttoptr i64 %v10376 to ptr
  %ld10378 = load i64, ptr %p10377, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld10378, ptr %slot1867, align 8
  %v10379 = load i64, ptr %slot1867, align 8
  %op10380 = add i64 %v10379, 18446744073709551576
  store i64 %op10380, ptr %slot1868, align 8
  %v10381 = load i64, ptr %slot1868, align 8
  %v10382 = load i64, ptr %slot1866, align 8
  %p10383 = inttoptr i64 %v10382 to ptr
  store i64 %v10381, ptr %p10383, align 8, !alias.scope !9999998, !noalias !9999999
  %v10384 = load i64, ptr %slot1834, align 8
  %cmp10385 = icmp ne i64 %v10384, 0
  %cv10386 = zext i1 %cmp10385 to i32
  store i32 %cv10386, ptr %slot1869, align 8
  %v10387 = load i32, ptr %slot1869, align 8
  %cv10388 = zext i32 %v10387 to i64
  %cond10389 = icmp ne i64 %cv10388, 0
  br i1 %cond10389, label %bb_rcsenddropbacking2342, label %bb_rcsenddroppayload2342
bb_rcsenddropbacking2342:
  %v10390 = load i64, ptr %slot1834, align 8
  %op10391 = sub i64 %v10390, 24
  store i64 %op10391, ptr %slot1870, align 8
  %v10392 = load i64, ptr %slot1834, align 8
  %p10393 = inttoptr i64 %v10392 to ptr
  %rgep10394 = getelementptr i8, ptr %p10393, i64 -24
  %ld10395 = load i64, ptr %rgep10394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10395, ptr %slot1871, align 8
  %v10396 = load i64, ptr %slot1871, align 8
  %op10397 = add i64 %v10396, 18446744073709551615
  store i64 %op10397, ptr %slot1872, align 8
  %v10398 = load i64, ptr %slot1872, align 8
  %v10399 = load i64, ptr %slot1834, align 8
  %p10400 = inttoptr i64 %v10399 to ptr
  %rgep10401 = getelementptr i8, ptr %p10400, i64 -24
  store i64 %v10398, ptr %rgep10401, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload2342
bb_rcsenddroppayload2342:
  %v10402 = load i64, ptr %slot1819, align 8
  %op10403 = sub i64 %v10402, 24
  store i64 %op10403, ptr %slot1873, align 8
  %v10404 = load i64, ptr %slot1819, align 8
  %p10405 = inttoptr i64 %v10404 to ptr
  %rgep10406 = getelementptr i8, ptr %p10405, i64 -24
  %ld10407 = load i64, ptr %rgep10406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10407, ptr %slot1874, align 8
  %v10408 = load i64, ptr %slot1874, align 8
  %op10409 = add i64 %v10408, 18446744073709551615
  store i64 %op10409, ptr %slot1875, align 8
  %v10410 = load i64, ptr %slot1875, align 8
  %v10411 = load i64, ptr %slot1819, align 8
  %p10412 = inttoptr i64 %v10411 to ptr
  %rgep10413 = getelementptr i8, ptr %p10412, i64 -24
  store i64 %v10410, ptr %rgep10413, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink2342
bb_rcsendunlink2342:
  %v10414 = load i64, ptr %slot1798, align 8
  %p10416 = inttoptr i64 %v10414 to ptr
  %gep10417 = getelementptr i8, ptr %p10416, i64 8
  %op10415 = ptrtoint ptr %gep10417 to i64
  store i64 %op10415, ptr %slot1876, align 8
  %v10418 = load i64, ptr %slot1876, align 8
  %p10419 = inttoptr i64 %v10418 to ptr
  %ld10420 = load i64, ptr %p10419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10420, ptr %slot1877, align 8
  %v10421 = load i64, ptr %slot1802, align 8
  %op10422 = add i64 %v10421, 248
  store i64 %op10422, ptr %slot1878, align 8
  %v10423 = load i64, ptr %slot1877, align 8
  %v10424 = load i64, ptr %slot1878, align 8
  %p10425 = inttoptr i64 %v10424 to ptr
  store i64 %v10423, ptr %p10425, align 8, !alias.scope !9999998, !noalias !9999999
  %v10426 = load i64, ptr %slot1798, align 8
  %p10428 = inttoptr i64 %v10426 to ptr
  %gep10429 = getelementptr i8, ptr %p10428, i64 24
  %op10427 = ptrtoint ptr %gep10429 to i64
  store i64 %op10427, ptr %slot1879, align 8
  %v10430 = load i64, ptr %slot1798, align 8
  %p10432 = inttoptr i64 %v10430 to ptr
  %gep10433 = getelementptr i8, ptr %p10432, i64 8
  %op10431 = ptrtoint ptr %gep10433 to i64
  store i64 %op10431, ptr %slot1880, align 8
  %v10434 = load i64, ptr %slot1879, align 8
  %p10435 = inttoptr i64 %v10434 to ptr
  store i32 0, ptr %p10435, align 4, !alias.scope !3, !noalias !4
  %v10436 = load i64, ptr %slot1880, align 8
  %p10437 = inttoptr i64 %v10436 to ptr
  store i64 0, ptr %p10437, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone2342
bb_rcsendslow2342:
  %v10438 = load i64, ptr %slot1, align 8
  %p10439 = inttoptr i64 %v10438 to ptr
  %v10440 = load i64, ptr %slot1798, align 8
  %p10441 = inttoptr i64 %v10440 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p10439, ptr %p10441) nomerge, !dbg !176
  br label %bb_rcsenddone2342
bb_rcsenddone2342:
  %v10442 = load i64, ptr %slot53, align 8
  %v10443 = load i64, ptr %slot68, align 8
  %p10444 = inttoptr i64 %v10443 to ptr
  store i64 %v10442, ptr %p10444, align 8, !alias.scope !3, !noalias !4
  %v10445 = load i64, ptr %slot68, align 8
  %p10446 = inttoptr i64 %v10445 to ptr
  %ld10447 = load i64, ptr %p10446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10447, ptr %slot1881, align 8
  %v10448 = load i64, ptr %slot23, align 8
  %p10449 = inttoptr i64 %v10448 to ptr
  %ld10450 = load i32, ptr %p10449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10450, ptr %slot1882, align 8
  %v10451 = load i64, ptr %slot24, align 8
  %p10452 = inttoptr i64 %v10451 to ptr
  %ld10453 = load i32, ptr %p10452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10453, ptr %slot1883, align 8
  %v10454 = load i32, ptr %slot1883, align 8
  %op10455 = and i32 %v10454, 24
  store i32 %op10455, ptr %slot1883, align 8
  %v10456 = load i32, ptr %slot1883, align 8
  %cmp10457 = icmp eq i32 %v10456, 0
  %cv10458 = zext i1 %cmp10457 to i32
  store i32 %cv10458, ptr %slot1884, align 8
  %v10459 = load i32, ptr %slot1882, align 8
  %v10460 = load i32, ptr %slot1884, align 8
  %op10461 = and i32 %v10459, %v10460
  store i32 %op10461, ptr %slot1885, align 8
  %v10462 = load i32, ptr %slot1885, align 8
  %cv10463 = zext i32 %v10462 to i64
  %cond10464 = icmp ne i64 %cv10463, 0
  br i1 %cond10464, label %bb_rcprivateown2443, label %bb_rcprivateloan2443
bb_rcprivateown2443:
  %v10465 = load i64, ptr %slot42, align 8
  store i64 %v10465, ptr %slot1886, align 8
  %v10466 = load i64, ptr %slot89, align 8
  store i64 %v10466, ptr %slot1887, align 8
  %v10467 = load i64, ptr %slot1881, align 8
  %v10468 = load i64, ptr %slot1886, align 8
  %op10469 = sub i64 %v10467, %v10468
  store i64 %op10469, ptr %slot1888, align 8
  %v10470 = load i64, ptr %slot1886, align 8
  %v10471 = load i64, ptr %slot1881, align 8
  %op10472 = sub i64 %v10470, %v10471
  store i64 %op10472, ptr %slot1889, align 8
  %v10473 = load i64, ptr %slot1888, align 8
  %cmp10474 = icmp ult i64 %v10473, 48
  %cv10475 = zext i1 %cmp10474 to i32
  store i32 %cv10475, ptr %slot1890, align 8
  %v10476 = load i64, ptr %slot1889, align 8
  %cmp10477 = icmp ult i64 %v10476, 48
  %cv10478 = zext i1 %cmp10477 to i32
  store i32 %cv10478, ptr %slot1891, align 8
  %v10479 = load i32, ptr %slot1890, align 8
  %v10480 = load i32, ptr %slot1891, align 8
  %op10481 = or i32 %v10479, %v10480
  store i32 %op10481, ptr %slot1892, align 8
  %v10482 = load i32, ptr %slot1892, align 8
  %cv10483 = zext i32 %v10482 to i64
  %cond10484 = icmp ne i64 %cv10483, 0
  br i1 %cond10484, label %bb_rcmoveslow2446, label %bb_rcmovecheck2446
bb_rcmovecheck2446:
  %v10485 = load i64, ptr %slot1881, align 8
  %op10486 = add i64 %v10485, 16
  store i64 %op10486, ptr %slot1893, align 8
  %v10487 = load i64, ptr %slot1893, align 8
  %p10488 = inttoptr i64 %v10487 to ptr
  %ld10489 = load i64, ptr %p10488, align 8
  store i64 %ld10489, ptr %slot1894, align 8
  %v10490 = load i64, ptr %slot1894, align 8
  %cmp10491 = icmp ne i64 %v10490, 0
  %cv10492 = zext i1 %cmp10491 to i32
  store i32 %cv10492, ptr %slot1895, align 8
  %v10493 = load i32, ptr %slot1895, align 8
  %cv10494 = zext i32 %v10493 to i64
  %cond10495 = icmp ne i64 %cv10494, 0
  br i1 %cond10495, label %bb_rcmoveheader2454, label %bb_rcmovenext2454
bb_rcmoveheader2454:
  %v10496 = load i64, ptr %slot1894, align 8
  %op10497 = sub i64 %v10496, 16
  store i64 %op10497, ptr %slot1896, align 8
  %v10498 = load i64, ptr %slot1894, align 8
  %p10499 = inttoptr i64 %v10498 to ptr
  %rgep10500 = getelementptr i8, ptr %p10499, i64 -16
  %ld10501 = load i64, ptr %rgep10500, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10501, ptr %slot1897, align 8
  %v10502 = load i64, ptr %slot1897, align 8
  %op10503 = and i64 %v10502, 5764607523034234881
  store i64 %op10503, ptr %slot1898, align 8
  %v10504 = load i64, ptr %slot1898, align 8
  %cmp10505 = icmp ne i64 %v10504, 0
  %cv10506 = zext i1 %cmp10505 to i32
  store i32 %cv10506, ptr %slot1899, align 8
  %v10507 = load i32, ptr %slot1899, align 8
  %cv10508 = zext i32 %v10507 to i64
  %cond10509 = icmp ne i64 %cv10508, 0
  br i1 %cond10509, label %bb_rcmoveslow2446, label %bb_rcmovenext2454
bb_rcmovenext2454:
  %v10510 = load i64, ptr %slot1881, align 8
  %op10511 = add i64 %v10510, 24
  store i64 %op10511, ptr %slot1900, align 8
  %v10512 = load i64, ptr %slot1900, align 8
  %p10513 = inttoptr i64 %v10512 to ptr
  %ld10514 = load i64, ptr %p10513, align 8
  store i64 %ld10514, ptr %slot1901, align 8
  %v10515 = load i64, ptr %slot1901, align 8
  %cmp10516 = icmp ne i64 %v10515, 0
  %cv10517 = zext i1 %cmp10516 to i32
  store i32 %cv10517, ptr %slot1902, align 8
  %v10518 = load i32, ptr %slot1902, align 8
  %cv10519 = zext i32 %v10518 to i64
  %cond10520 = icmp ne i64 %cv10519, 0
  br i1 %cond10520, label %bb_rcmoveheader2462, label %bb_rcmovenext2462
bb_rcmoveheader2462:
  %v10521 = load i64, ptr %slot1901, align 8
  %op10522 = sub i64 %v10521, 16
  store i64 %op10522, ptr %slot1903, align 8
  %v10523 = load i64, ptr %slot1901, align 8
  %p10524 = inttoptr i64 %v10523 to ptr
  %rgep10525 = getelementptr i8, ptr %p10524, i64 -16
  %ld10526 = load i64, ptr %rgep10525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10526, ptr %slot1904, align 8
  %v10527 = load i64, ptr %slot1904, align 8
  %op10528 = and i64 %v10527, 5764607523034234881
  store i64 %op10528, ptr %slot1905, align 8
  %v10529 = load i64, ptr %slot1905, align 8
  %cmp10530 = icmp ne i64 %v10529, 0
  %cv10531 = zext i1 %cmp10530 to i32
  store i32 %cv10531, ptr %slot1906, align 8
  %v10532 = load i32, ptr %slot1906, align 8
  %cv10533 = zext i32 %v10532 to i64
  %cond10534 = icmp ne i64 %cv10533, 0
  br i1 %cond10534, label %bb_rcmoveslow2446, label %bb_rcmovenext2462
bb_rcmovenext2462:
  %v10535 = load i64, ptr %slot1881, align 8
  %op10536 = add i64 %v10535, 32
  store i64 %op10536, ptr %slot1907, align 8
  %v10537 = load i64, ptr %slot1907, align 8
  %p10538 = inttoptr i64 %v10537 to ptr
  %ld10539 = load i64, ptr %p10538, align 8
  store i64 %ld10539, ptr %slot1908, align 8
  %v10540 = load i64, ptr %slot1908, align 8
  %cmp10541 = icmp ne i64 %v10540, 0
  %cv10542 = zext i1 %cmp10541 to i32
  store i32 %cv10542, ptr %slot1909, align 8
  %v10543 = load i32, ptr %slot1909, align 8
  %cv10544 = zext i32 %v10543 to i64
  %cond10545 = icmp ne i64 %cv10544, 0
  br i1 %cond10545, label %bb_rcmoveheader2470, label %bb_rcmovenext2470
bb_rcmoveheader2470:
  %v10546 = load i64, ptr %slot1908, align 8
  %op10547 = sub i64 %v10546, 16
  store i64 %op10547, ptr %slot1910, align 8
  %v10548 = load i64, ptr %slot1908, align 8
  %p10549 = inttoptr i64 %v10548 to ptr
  %rgep10550 = getelementptr i8, ptr %p10549, i64 -16
  %ld10551 = load i64, ptr %rgep10550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10551, ptr %slot1911, align 8
  %v10552 = load i64, ptr %slot1911, align 8
  %op10553 = and i64 %v10552, 5764607523034234881
  store i64 %op10553, ptr %slot1912, align 8
  %v10554 = load i64, ptr %slot1912, align 8
  %cmp10555 = icmp ne i64 %v10554, 0
  %cv10556 = zext i1 %cmp10555 to i32
  store i32 %cv10556, ptr %slot1913, align 8
  %v10557 = load i32, ptr %slot1913, align 8
  %cv10558 = zext i32 %v10557 to i64
  %cond10559 = icmp ne i64 %cv10558, 0
  br i1 %cond10559, label %bb_rcmoveslow2446, label %bb_rcmovenext2470
bb_rcmovenext2470:
  %v10560 = load i64, ptr %slot1881, align 8
  %v10561 = load i64, ptr %slot1886, align 8
  %p10562 = inttoptr i64 %v10560 to ptr
  %p10563 = inttoptr i64 %v10561 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10563, ptr %p10562, i64 48, i1 false)
  %v10564 = load i64, ptr %slot1881, align 8
  %p10565 = inttoptr i64 %v10564 to ptr
  store i64 0, ptr %p10565, align 8
  %v10566 = load i64, ptr %slot1881, align 8
  %op10567 = add i64 %v10566, 8
  store i64 %op10567, ptr %slot1914, align 8
  %v10568 = load i64, ptr %slot1914, align 8
  %p10569 = inttoptr i64 %v10568 to ptr
  store i64 0, ptr %p10569, align 8
  %v10570 = load i64, ptr %slot1881, align 8
  %op10571 = add i64 %v10570, 16
  store i64 %op10571, ptr %slot1915, align 8
  %v10572 = load i64, ptr %slot1915, align 8
  %p10573 = inttoptr i64 %v10572 to ptr
  store i64 0, ptr %p10573, align 8
  %v10574 = load i64, ptr %slot1881, align 8
  %op10575 = add i64 %v10574, 24
  store i64 %op10575, ptr %slot1916, align 8
  %v10576 = load i64, ptr %slot1916, align 8
  %p10577 = inttoptr i64 %v10576 to ptr
  store i64 0, ptr %p10577, align 8
  %v10578 = load i64, ptr %slot1881, align 8
  %op10579 = add i64 %v10578, 32
  store i64 %op10579, ptr %slot1917, align 8
  %v10580 = load i64, ptr %slot1917, align 8
  %p10581 = inttoptr i64 %v10580 to ptr
  store i64 0, ptr %p10581, align 8
  %v10582 = load i64, ptr %slot1881, align 8
  %op10583 = add i64 %v10582, 40
  store i64 %op10583, ptr %slot1918, align 8
  %v10584 = load i64, ptr %slot1918, align 8
  %p10585 = inttoptr i64 %v10584 to ptr
  store i64 0, ptr %p10585, align 8
  br label %bb_rcmoved2446
bb_rcmoveslow2446:
  %v10586 = load i64, ptr %slot88, align 8
  %v10587 = load i64, ptr %slot1886, align 8
  %v10588 = load i64, ptr %slot1881, align 8
  %v10589 = load i64, ptr %slot1887, align 8
  %cv10590 = trunc i64 %v10589 to i32
  %call10591 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v10586, i64 %v10587, i64 %v10588, i32 %cv10590) nomerge, !dbg !178
  store i32 %call10591, ptr %slot1919, align 8
  %v10592 = load i32, ptr %slot1919, align 8
  %cv10593 = zext i32 %v10592 to i64
  %cond10594 = icmp ne i64 %cv10593, 0
  br i1 %cond10594, label %bb_rcsuccess2482, label %bb_rcfailure2482
bb_rcfailure2482:
  %v10595 = load i64, ptr %slot88, align 8
  %p10596 = inttoptr i64 %v10595 to ptr
  %call10597 = call i32 @myl_rc_take_failure(ptr %p10596) nomerge, !dbg !178
  store i32 %call10597, ptr %slot1920, align 8
  %v10598 = load i64, ptr %slot1, align 8
  %p10599 = inttoptr i64 %v10598 to ptr
  %v10600 = load i32, ptr %slot1920, align 8
  %call10601 = call i32 @myl_qbe_rc_status(ptr %p10599, i32 %v10600) nomerge, !dbg !178
  store i32 %call10601, ptr %slot1921, align 8
  br label %bb_failure
bb_rcsuccess2482:
  br label %bb_rcmoved2446
bb_rcmoved2446:
  %v10602 = load i64, ptr %slot23, align 8
  %p10603 = inttoptr i64 %v10602 to ptr
  store i32 0, ptr %p10603, align 4, !alias.scope !3, !noalias !4
  %v10604 = load i64, ptr %slot32, align 8
  %p10605 = inttoptr i64 %v10604 to ptr
  store i32 2, ptr %p10605, align 4, !alias.scope !3, !noalias !4
  %v10606 = load i64, ptr %slot31, align 8
  %p10607 = inttoptr i64 %v10606 to ptr
  store i32 1, ptr %p10607, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2443
bb_rcprivateloan2443:
  %v10608 = load i64, ptr %slot42, align 8
  store i64 %v10608, ptr %slot1922, align 8
  %v10609 = load i64, ptr %slot88, align 8
  %v10610 = load i64, ptr %slot1922, align 8
  %v10611 = load i64, ptr %slot1881, align 8
  %call10612 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v10609, i64 %v10610, i64 %v10611) nomerge, !dbg !178
  store i32 %call10612, ptr %slot1923, align 8
  %v10613 = load i32, ptr %slot1923, align 8
  %cv10614 = zext i32 %v10613 to i64
  %cond10615 = icmp ne i64 %cv10614, 0
  br i1 %cond10615, label %bb_rcsuccess2490, label %bb_rcfailure2490
bb_rcfailure2490:
  %v10616 = load i64, ptr %slot88, align 8
  %p10617 = inttoptr i64 %v10616 to ptr
  %call10618 = call i32 @myl_rc_take_failure(ptr %p10617) nomerge, !dbg !178
  store i32 %call10618, ptr %slot1924, align 8
  %v10619 = load i64, ptr %slot1, align 8
  %p10620 = inttoptr i64 %v10619 to ptr
  %v10621 = load i32, ptr %slot1924, align 8
  %call10622 = call i32 @myl_qbe_rc_status(ptr %p10620, i32 %v10621) nomerge, !dbg !178
  store i32 %call10622, ptr %slot1925, align 8
  br label %bb_failure
bb_rcsuccess2490:
  %v10623 = load i64, ptr %slot32, align 8
  %p10624 = inttoptr i64 %v10623 to ptr
  store i32 2, ptr %p10624, align 4, !alias.scope !3, !noalias !4
  %v10625 = load i64, ptr %slot32, align 8
  %p10626 = inttoptr i64 %v10625 to ptr
  store i32 16, ptr %p10626, align 4, !alias.scope !3, !noalias !4
  %v10627 = load i64, ptr %slot31, align 8
  %p10628 = inttoptr i64 %v10627 to ptr
  store i32 1, ptr %p10628, align 4, !alias.scope !3, !noalias !4
  %v10629 = load i64, ptr %slot23, align 8
  %p10630 = inttoptr i64 %v10629 to ptr
  %ld10631 = load i32, ptr %p10630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10631, ptr %slot1926, align 8
  %v10632 = load i32, ptr %slot1926, align 8
  %cv10633 = zext i32 %v10632 to i64
  %cond10634 = icmp ne i64 %cv10633, 0
  br i1 %cond10634, label %bb_rcslotdrop2498, label %bb_rcslotdone2498
bb_rcslotdrop2498:
  %v10635 = load i64, ptr %slot23, align 8
  %p10636 = inttoptr i64 %v10635 to ptr
  store i32 0, ptr %p10636, align 4, !alias.scope !3, !noalias !4
  %v10637 = load i64, ptr %slot34, align 8
  store i64 %v10637, ptr %slot1927, align 8
  %v10638 = load i64, ptr %slot24, align 8
  %p10639 = inttoptr i64 %v10638 to ptr
  %ld10640 = load i32, ptr %p10639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10640, ptr %slot1928, align 8
  %v10641 = load i32, ptr %slot1928, align 8
  %op10642 = and i32 %v10641, 28
  store i32 %op10642, ptr %slot1929, align 8
  %v10643 = load i32, ptr %slot1929, align 8
  %cv10644 = zext i32 %v10643 to i64
  %cond10645 = icmp ne i64 %cv10644, 0
  br i1 %cond10645, label %bb_rcslotrole2498, label %bb_rcslotowner2498
bb_rcslotrole2498:
  %v10646 = load i64, ptr %slot88, align 8
  store i64 %v10646, ptr %slot1930, align 8
  %v10647 = load i64, ptr %slot1930, align 8
  %v10648 = load i64, ptr %slot1927, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v10647, i64 %v10648) nomerge, !dbg !178
  br label %bb_rcslotdone2498
bb_rcslotowner2498:
  %v10649 = load i64, ptr %slot1927, align 8
  %p10651 = inttoptr i64 %v10649 to ptr
  %gep10652 = getelementptr i8, ptr %p10651, i64 16
  %op10650 = ptrtoint ptr %gep10652 to i64
  store i64 %op10650, ptr %slot1931, align 8
  %v10653 = load i64, ptr %slot88, align 8
  store i64 %v10653, ptr %slot1932, align 8
  %v10654 = load i64, ptr %slot1931, align 8
  %p10655 = inttoptr i64 %v10654 to ptr
  %ld10656 = load i64, ptr %p10655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10656, ptr %slot1933, align 8
  %v10657 = load i64, ptr %slot1933, align 8
  %cmp10658 = icmp ne i64 %v10657, 0
  %cv10659 = zext i1 %cmp10658 to i32
  store i32 %cv10659, ptr %slot1934, align 8
  %v10660 = load i32, ptr %slot1934, align 8
  %cv10661 = zext i32 %v10660 to i64
  %cond10662 = icmp ne i64 %cv10661, 0
  br i1 %cond10662, label %bb_rcgnn2516, label %bb_rcgdone2516
bb_rcgnn2516:
  %v10663 = load i64, ptr %slot1933, align 8
  %op10664 = sub i64 %v10663, 16
  store i64 %op10664, ptr %slot1935, align 8
  %v10665 = load i64, ptr %slot1933, align 8
  %p10666 = inttoptr i64 %v10665 to ptr
  %rgep10667 = getelementptr i8, ptr %p10666, i64 -16
  %ld10668 = load i64, ptr %rgep10667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10668, ptr %slot1936, align 8
  %v10669 = load i64, ptr %slot1936, align 8
  %op10670 = and i64 %v10669, 4611686018427387906
  store i64 %op10670, ptr %slot1937, align 8
  %v10671 = load i64, ptr %slot1937, align 8
  %cmp10672 = icmp ne i64 %v10671, 0
  %cv10673 = zext i1 %cmp10672 to i32
  store i32 %cv10673, ptr %slot1938, align 8
  %v10674 = load i32, ptr %slot1938, align 8
  %cv10675 = zext i32 %v10674 to i64
  %cond10676 = icmp ne i64 %cv10675, 0
  br i1 %cond10676, label %bb_rcgclear2516, label %bb_rcgcounted2516
bb_rcgcounted2516:
  %v10677 = load i64, ptr %slot1933, align 8
  %op10678 = sub i64 %v10677, 32
  store i64 %op10678, ptr %slot1939, align 8
  %v10679 = load i64, ptr %slot1933, align 8
  %p10680 = inttoptr i64 %v10679 to ptr
  %rgep10681 = getelementptr i8, ptr %p10680, i64 -32
  %ld10682 = load i64, ptr %rgep10681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10682, ptr %slot1940, align 8
  %v10683 = load i64, ptr %slot1940, align 8
  %op10684 = sub i64 %v10683, 1
  store i64 %op10684, ptr %slot1941, align 8
  %v10685 = load i64, ptr %slot1941, align 8
  %cmp10686 = icmp eq i64 %v10685, 0
  %cv10687 = zext i1 %cmp10686 to i32
  store i32 %cv10687, ptr %slot1942, align 8
  %v10688 = load i32, ptr %slot1942, align 8
  %cv10689 = zext i32 %v10688 to i64
  %cond10690 = icmp ne i64 %cv10689, 0
  br i1 %cond10690, label %bb_rcglast2516, label %bb_rcgdec2516
bb_rcglast2516:
  %v10691 = load i64, ptr %slot1933, align 8
  %op10692 = sub i64 %v10691, 24
  store i64 %op10692, ptr %slot1943, align 8
  %v10693 = load i64, ptr %slot1933, align 8
  %p10694 = inttoptr i64 %v10693 to ptr
  %rgep10695 = getelementptr i8, ptr %p10694, i64 -24
  %ld10696 = load i64, ptr %rgep10695, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10696, ptr %slot1944, align 8
  %v10697 = load i64, ptr %slot1944, align 8
  %cmp10698 = icmp ne i64 %v10697, 0
  %cv10699 = zext i1 %cmp10698 to i32
  store i32 %cv10699, ptr %slot1945, align 8
  %v10700 = load i32, ptr %slot1945, align 8
  %cv10701 = zext i32 %v10700 to i64
  %cond10702 = icmp ne i64 %cv10701, 0
  br i1 %cond10702, label %bb_rcgdec2516, label %bb_rcgslow2516
bb_rcgslow2516:
  %v10703 = load i64, ptr %slot1932, align 8
  %v10704 = load i64, ptr %slot1931, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v10703, i64 %v10704) nomerge, !dbg !178
  br label %bb_rcgdone2516
bb_rcgdec2516:
  %v10705 = load i64, ptr %slot1941, align 8
  %v10706 = load i64, ptr %slot1933, align 8
  %p10707 = inttoptr i64 %v10706 to ptr
  %rgep10708 = getelementptr i8, ptr %p10707, i64 -32
  store i64 %v10705, ptr %rgep10708, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2516
bb_rcgclear2516:
  %v10709 = load i64, ptr %slot1931, align 8
  %p10710 = inttoptr i64 %v10709 to ptr
  store i64 0, ptr %p10710, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2516
bb_rcgdone2516:
  %v10711 = load i64, ptr %slot1927, align 8
  %p10713 = inttoptr i64 %v10711 to ptr
  %gep10714 = getelementptr i8, ptr %p10713, i64 24
  %op10712 = ptrtoint ptr %gep10714 to i64
  store i64 %op10712, ptr %slot1946, align 8
  %v10715 = load i64, ptr %slot88, align 8
  store i64 %v10715, ptr %slot1947, align 8
  %v10716 = load i64, ptr %slot1946, align 8
  %p10717 = inttoptr i64 %v10716 to ptr
  %ld10718 = load i64, ptr %p10717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10718, ptr %slot1948, align 8
  %v10719 = load i64, ptr %slot1948, align 8
  %cmp10720 = icmp ne i64 %v10719, 0
  %cv10721 = zext i1 %cmp10720 to i32
  store i32 %cv10721, ptr %slot1949, align 8
  %v10722 = load i32, ptr %slot1949, align 8
  %cv10723 = zext i32 %v10722 to i64
  %cond10724 = icmp ne i64 %cv10723, 0
  br i1 %cond10724, label %bb_rcgnn2532, label %bb_rcgdone2532
bb_rcgnn2532:
  %v10725 = load i64, ptr %slot1948, align 8
  %op10726 = sub i64 %v10725, 16
  store i64 %op10726, ptr %slot1950, align 8
  %v10727 = load i64, ptr %slot1948, align 8
  %p10728 = inttoptr i64 %v10727 to ptr
  %rgep10729 = getelementptr i8, ptr %p10728, i64 -16
  %ld10730 = load i64, ptr %rgep10729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10730, ptr %slot1951, align 8
  %v10731 = load i64, ptr %slot1951, align 8
  %op10732 = and i64 %v10731, 4611686018427387906
  store i64 %op10732, ptr %slot1952, align 8
  %v10733 = load i64, ptr %slot1952, align 8
  %cmp10734 = icmp ne i64 %v10733, 0
  %cv10735 = zext i1 %cmp10734 to i32
  store i32 %cv10735, ptr %slot1953, align 8
  %v10736 = load i32, ptr %slot1953, align 8
  %cv10737 = zext i32 %v10736 to i64
  %cond10738 = icmp ne i64 %cv10737, 0
  br i1 %cond10738, label %bb_rcgclear2532, label %bb_rcgcounted2532
bb_rcgcounted2532:
  %v10739 = load i64, ptr %slot1948, align 8
  %op10740 = sub i64 %v10739, 32
  store i64 %op10740, ptr %slot1954, align 8
  %v10741 = load i64, ptr %slot1948, align 8
  %p10742 = inttoptr i64 %v10741 to ptr
  %rgep10743 = getelementptr i8, ptr %p10742, i64 -32
  %ld10744 = load i64, ptr %rgep10743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10744, ptr %slot1955, align 8
  %v10745 = load i64, ptr %slot1955, align 8
  %op10746 = sub i64 %v10745, 1
  store i64 %op10746, ptr %slot1956, align 8
  %v10747 = load i64, ptr %slot1956, align 8
  %cmp10748 = icmp eq i64 %v10747, 0
  %cv10749 = zext i1 %cmp10748 to i32
  store i32 %cv10749, ptr %slot1957, align 8
  %v10750 = load i32, ptr %slot1957, align 8
  %cv10751 = zext i32 %v10750 to i64
  %cond10752 = icmp ne i64 %cv10751, 0
  br i1 %cond10752, label %bb_rcglast2532, label %bb_rcgdec2532
bb_rcglast2532:
  %v10753 = load i64, ptr %slot1948, align 8
  %op10754 = sub i64 %v10753, 24
  store i64 %op10754, ptr %slot1958, align 8
  %v10755 = load i64, ptr %slot1948, align 8
  %p10756 = inttoptr i64 %v10755 to ptr
  %rgep10757 = getelementptr i8, ptr %p10756, i64 -24
  %ld10758 = load i64, ptr %rgep10757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10758, ptr %slot1959, align 8
  %v10759 = load i64, ptr %slot1959, align 8
  %cmp10760 = icmp ne i64 %v10759, 0
  %cv10761 = zext i1 %cmp10760 to i32
  store i32 %cv10761, ptr %slot1960, align 8
  %v10762 = load i32, ptr %slot1960, align 8
  %cv10763 = zext i32 %v10762 to i64
  %cond10764 = icmp ne i64 %cv10763, 0
  br i1 %cond10764, label %bb_rcgdec2532, label %bb_rcgslow2532
bb_rcgslow2532:
  %v10765 = load i64, ptr %slot1947, align 8
  %v10766 = load i64, ptr %slot1946, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v10765, i64 %v10766) nomerge, !dbg !178
  br label %bb_rcgdone2532
bb_rcgdec2532:
  %v10767 = load i64, ptr %slot1956, align 8
  %v10768 = load i64, ptr %slot1948, align 8
  %p10769 = inttoptr i64 %v10768 to ptr
  %rgep10770 = getelementptr i8, ptr %p10769, i64 -32
  store i64 %v10767, ptr %rgep10770, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2532
bb_rcgclear2532:
  %v10771 = load i64, ptr %slot1946, align 8
  %p10772 = inttoptr i64 %v10771 to ptr
  store i64 0, ptr %p10772, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2532
bb_rcgdone2532:
  %v10773 = load i64, ptr %slot1927, align 8
  %p10775 = inttoptr i64 %v10773 to ptr
  %gep10776 = getelementptr i8, ptr %p10775, i64 32
  %op10774 = ptrtoint ptr %gep10776 to i64
  store i64 %op10774, ptr %slot1961, align 8
  %v10777 = load i64, ptr %slot88, align 8
  store i64 %v10777, ptr %slot1962, align 8
  %v10778 = load i64, ptr %slot1961, align 8
  %p10779 = inttoptr i64 %v10778 to ptr
  %ld10780 = load i64, ptr %p10779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10780, ptr %slot1963, align 8
  %v10781 = load i64, ptr %slot1963, align 8
  %cmp10782 = icmp ne i64 %v10781, 0
  %cv10783 = zext i1 %cmp10782 to i32
  store i32 %cv10783, ptr %slot1964, align 8
  %v10784 = load i32, ptr %slot1964, align 8
  %cv10785 = zext i32 %v10784 to i64
  %cond10786 = icmp ne i64 %cv10785, 0
  br i1 %cond10786, label %bb_rcgnn2548, label %bb_rcgdone2548
bb_rcgnn2548:
  %v10787 = load i64, ptr %slot1963, align 8
  %op10788 = sub i64 %v10787, 16
  store i64 %op10788, ptr %slot1965, align 8
  %v10789 = load i64, ptr %slot1963, align 8
  %p10790 = inttoptr i64 %v10789 to ptr
  %rgep10791 = getelementptr i8, ptr %p10790, i64 -16
  %ld10792 = load i64, ptr %rgep10791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10792, ptr %slot1966, align 8
  %v10793 = load i64, ptr %slot1966, align 8
  %op10794 = and i64 %v10793, 4611686018427387906
  store i64 %op10794, ptr %slot1967, align 8
  %v10795 = load i64, ptr %slot1967, align 8
  %cmp10796 = icmp ne i64 %v10795, 0
  %cv10797 = zext i1 %cmp10796 to i32
  store i32 %cv10797, ptr %slot1968, align 8
  %v10798 = load i32, ptr %slot1968, align 8
  %cv10799 = zext i32 %v10798 to i64
  %cond10800 = icmp ne i64 %cv10799, 0
  br i1 %cond10800, label %bb_rcgclear2548, label %bb_rcgcounted2548
bb_rcgcounted2548:
  %v10801 = load i64, ptr %slot1963, align 8
  %op10802 = sub i64 %v10801, 32
  store i64 %op10802, ptr %slot1969, align 8
  %v10803 = load i64, ptr %slot1963, align 8
  %p10804 = inttoptr i64 %v10803 to ptr
  %rgep10805 = getelementptr i8, ptr %p10804, i64 -32
  %ld10806 = load i64, ptr %rgep10805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10806, ptr %slot1970, align 8
  %v10807 = load i64, ptr %slot1970, align 8
  %op10808 = sub i64 %v10807, 1
  store i64 %op10808, ptr %slot1971, align 8
  %v10809 = load i64, ptr %slot1971, align 8
  %cmp10810 = icmp eq i64 %v10809, 0
  %cv10811 = zext i1 %cmp10810 to i32
  store i32 %cv10811, ptr %slot1972, align 8
  %v10812 = load i32, ptr %slot1972, align 8
  %cv10813 = zext i32 %v10812 to i64
  %cond10814 = icmp ne i64 %cv10813, 0
  br i1 %cond10814, label %bb_rcglast2548, label %bb_rcgdec2548
bb_rcglast2548:
  %v10815 = load i64, ptr %slot1963, align 8
  %op10816 = sub i64 %v10815, 24
  store i64 %op10816, ptr %slot1973, align 8
  %v10817 = load i64, ptr %slot1963, align 8
  %p10818 = inttoptr i64 %v10817 to ptr
  %rgep10819 = getelementptr i8, ptr %p10818, i64 -24
  %ld10820 = load i64, ptr %rgep10819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10820, ptr %slot1974, align 8
  %v10821 = load i64, ptr %slot1974, align 8
  %cmp10822 = icmp ne i64 %v10821, 0
  %cv10823 = zext i1 %cmp10822 to i32
  store i32 %cv10823, ptr %slot1975, align 8
  %v10824 = load i32, ptr %slot1975, align 8
  %cv10825 = zext i32 %v10824 to i64
  %cond10826 = icmp ne i64 %cv10825, 0
  br i1 %cond10826, label %bb_rcgdec2548, label %bb_rcgslow2548
bb_rcgslow2548:
  %v10827 = load i64, ptr %slot1962, align 8
  %v10828 = load i64, ptr %slot1961, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v10827, i64 %v10828) nomerge, !dbg !178
  br label %bb_rcgdone2548
bb_rcgdec2548:
  %v10829 = load i64, ptr %slot1971, align 8
  %v10830 = load i64, ptr %slot1963, align 8
  %p10831 = inttoptr i64 %v10830 to ptr
  %rgep10832 = getelementptr i8, ptr %p10831, i64 -32
  store i64 %v10829, ptr %rgep10832, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2548
bb_rcgclear2548:
  %v10833 = load i64, ptr %slot1961, align 8
  %p10834 = inttoptr i64 %v10833 to ptr
  store i64 0, ptr %p10834, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2548
bb_rcgdone2548:
  %v10835 = load i64, ptr %slot1927, align 8
  %p10836 = inttoptr i64 %v10835 to ptr
  store i64 0, ptr %p10836, align 8, !alias.scope !3, !noalias !4
  %v10837 = load i64, ptr %slot1927, align 8
  %p10839 = inttoptr i64 %v10837 to ptr
  %gep10840 = getelementptr i8, ptr %p10839, i64 8
  %op10838 = ptrtoint ptr %gep10840 to i64
  store i64 %op10838, ptr %slot1976, align 8
  %v10841 = load i64, ptr %slot1976, align 8
  %p10842 = inttoptr i64 %v10841 to ptr
  store i64 0, ptr %p10842, align 8, !alias.scope !3, !noalias !4
  %v10843 = load i64, ptr %slot1927, align 8
  %p10845 = inttoptr i64 %v10843 to ptr
  %gep10846 = getelementptr i8, ptr %p10845, i64 16
  %op10844 = ptrtoint ptr %gep10846 to i64
  store i64 %op10844, ptr %slot1977, align 8
  %v10847 = load i64, ptr %slot1977, align 8
  %p10848 = inttoptr i64 %v10847 to ptr
  store i64 0, ptr %p10848, align 8, !alias.scope !3, !noalias !4
  %v10849 = load i64, ptr %slot1927, align 8
  %p10851 = inttoptr i64 %v10849 to ptr
  %gep10852 = getelementptr i8, ptr %p10851, i64 24
  %op10850 = ptrtoint ptr %gep10852 to i64
  store i64 %op10850, ptr %slot1978, align 8
  %v10853 = load i64, ptr %slot1978, align 8
  %p10854 = inttoptr i64 %v10853 to ptr
  store i64 0, ptr %p10854, align 8, !alias.scope !3, !noalias !4
  %v10855 = load i64, ptr %slot1927, align 8
  %p10857 = inttoptr i64 %v10855 to ptr
  %gep10858 = getelementptr i8, ptr %p10857, i64 32
  %op10856 = ptrtoint ptr %gep10858 to i64
  store i64 %op10856, ptr %slot1979, align 8
  %v10859 = load i64, ptr %slot1979, align 8
  %p10860 = inttoptr i64 %v10859 to ptr
  store i64 0, ptr %p10860, align 8, !alias.scope !3, !noalias !4
  %v10861 = load i64, ptr %slot1927, align 8
  %p10863 = inttoptr i64 %v10861 to ptr
  %gep10864 = getelementptr i8, ptr %p10863, i64 40
  %op10862 = ptrtoint ptr %gep10864 to i64
  store i64 %op10862, ptr %slot1980, align 8
  %v10865 = load i64, ptr %slot1980, align 8
  %p10866 = inttoptr i64 %v10865 to ptr
  store i64 0, ptr %p10866, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2498
bb_rcslotdone2498:
  br label %bb_rcprivateprepared2443
bb_rcprivateprepared2443:
  %v10867 = load i64, ptr %slot21, align 8
  %p10868 = inttoptr i64 %v10867 to ptr
  %ld10869 = load i32, ptr %p10868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10869, ptr %slot1981, align 8
  %v10870 = load i32, ptr %slot1981, align 8
  %cv10871 = zext i32 %v10870 to i64
  %cond10872 = icmp ne i64 %cv10871, 0
  br i1 %cond10872, label %bb_rcslotdrop2560, label %bb_rcslotdone2560
bb_rcslotdrop2560:
  %v10873 = load i64, ptr %slot21, align 8
  %p10874 = inttoptr i64 %v10873 to ptr
  store i32 0, ptr %p10874, align 4, !alias.scope !3, !noalias !4
  %v10875 = load i64, ptr %slot66, align 8
  store i64 %v10875, ptr %slot1982, align 8
  %v10876 = load i64, ptr %slot22, align 8
  %p10877 = inttoptr i64 %v10876 to ptr
  %ld10878 = load i32, ptr %p10877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10878, ptr %slot1983, align 8
  %v10879 = load i32, ptr %slot1983, align 8
  %op10880 = and i32 %v10879, 28
  store i32 %op10880, ptr %slot1984, align 8
  %v10881 = load i32, ptr %slot1984, align 8
  %cv10882 = zext i32 %v10881 to i64
  %cond10883 = icmp ne i64 %cv10882, 0
  br i1 %cond10883, label %bb_rcslotrole2560, label %bb_rcslotowner2560
bb_rcslotrole2560:
  %v10884 = load i64, ptr %slot88, align 8
  store i64 %v10884, ptr %slot1985, align 8
  %v10885 = load i64, ptr %slot1985, align 8
  %v10886 = load i64, ptr %slot1982, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v10885, i64 %v10886) nomerge, !dbg !178
  br label %bb_rcslotdone2560
bb_rcslotowner2560:
  %v10887 = load i64, ptr %slot1982, align 8
  %p10889 = inttoptr i64 %v10887 to ptr
  %gep10890 = getelementptr i8, ptr %p10889, i64 16
  %op10888 = ptrtoint ptr %gep10890 to i64
  store i64 %op10888, ptr %slot1986, align 8
  %v10891 = load i64, ptr %slot88, align 8
  store i64 %v10891, ptr %slot1987, align 8
  %v10892 = load i64, ptr %slot1986, align 8
  %p10893 = inttoptr i64 %v10892 to ptr
  %ld10894 = load i64, ptr %p10893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10894, ptr %slot1988, align 8
  %v10895 = load i64, ptr %slot1988, align 8
  %cmp10896 = icmp ne i64 %v10895, 0
  %cv10897 = zext i1 %cmp10896 to i32
  store i32 %cv10897, ptr %slot1989, align 8
  %v10898 = load i32, ptr %slot1989, align 8
  %cv10899 = zext i32 %v10898 to i64
  %cond10900 = icmp ne i64 %cv10899, 0
  br i1 %cond10900, label %bb_rcgnn2578, label %bb_rcgdone2578
bb_rcgnn2578:
  %v10901 = load i64, ptr %slot1988, align 8
  %op10902 = sub i64 %v10901, 16
  store i64 %op10902, ptr %slot1990, align 8
  %v10903 = load i64, ptr %slot1988, align 8
  %p10904 = inttoptr i64 %v10903 to ptr
  %rgep10905 = getelementptr i8, ptr %p10904, i64 -16
  %ld10906 = load i64, ptr %rgep10905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10906, ptr %slot1991, align 8
  %v10907 = load i64, ptr %slot1991, align 8
  %op10908 = and i64 %v10907, 4611686018427387906
  store i64 %op10908, ptr %slot1992, align 8
  %v10909 = load i64, ptr %slot1992, align 8
  %cmp10910 = icmp ne i64 %v10909, 0
  %cv10911 = zext i1 %cmp10910 to i32
  store i32 %cv10911, ptr %slot1993, align 8
  %v10912 = load i32, ptr %slot1993, align 8
  %cv10913 = zext i32 %v10912 to i64
  %cond10914 = icmp ne i64 %cv10913, 0
  br i1 %cond10914, label %bb_rcgclear2578, label %bb_rcgcounted2578
bb_rcgcounted2578:
  %v10915 = load i64, ptr %slot1988, align 8
  %op10916 = sub i64 %v10915, 32
  store i64 %op10916, ptr %slot1994, align 8
  %v10917 = load i64, ptr %slot1988, align 8
  %p10918 = inttoptr i64 %v10917 to ptr
  %rgep10919 = getelementptr i8, ptr %p10918, i64 -32
  %ld10920 = load i64, ptr %rgep10919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10920, ptr %slot1995, align 8
  %v10921 = load i64, ptr %slot1995, align 8
  %op10922 = sub i64 %v10921, 1
  store i64 %op10922, ptr %slot1996, align 8
  %v10923 = load i64, ptr %slot1996, align 8
  %cmp10924 = icmp eq i64 %v10923, 0
  %cv10925 = zext i1 %cmp10924 to i32
  store i32 %cv10925, ptr %slot1997, align 8
  %v10926 = load i32, ptr %slot1997, align 8
  %cv10927 = zext i32 %v10926 to i64
  %cond10928 = icmp ne i64 %cv10927, 0
  br i1 %cond10928, label %bb_rcglast2578, label %bb_rcgdec2578
bb_rcglast2578:
  %v10929 = load i64, ptr %slot1988, align 8
  %op10930 = sub i64 %v10929, 24
  store i64 %op10930, ptr %slot1998, align 8
  %v10931 = load i64, ptr %slot1988, align 8
  %p10932 = inttoptr i64 %v10931 to ptr
  %rgep10933 = getelementptr i8, ptr %p10932, i64 -24
  %ld10934 = load i64, ptr %rgep10933, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10934, ptr %slot1999, align 8
  %v10935 = load i64, ptr %slot1999, align 8
  %cmp10936 = icmp ne i64 %v10935, 0
  %cv10937 = zext i1 %cmp10936 to i32
  store i32 %cv10937, ptr %slot2000, align 8
  %v10938 = load i32, ptr %slot2000, align 8
  %cv10939 = zext i32 %v10938 to i64
  %cond10940 = icmp ne i64 %cv10939, 0
  br i1 %cond10940, label %bb_rcgdec2578, label %bb_rcgslow2578
bb_rcgslow2578:
  %v10941 = load i64, ptr %slot1987, align 8
  %v10942 = load i64, ptr %slot1986, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v10941, i64 %v10942) nomerge, !dbg !178
  br label %bb_rcgdone2578
bb_rcgdec2578:
  %v10943 = load i64, ptr %slot1996, align 8
  %v10944 = load i64, ptr %slot1988, align 8
  %p10945 = inttoptr i64 %v10944 to ptr
  %rgep10946 = getelementptr i8, ptr %p10945, i64 -32
  store i64 %v10943, ptr %rgep10946, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2578
bb_rcgclear2578:
  %v10947 = load i64, ptr %slot1986, align 8
  %p10948 = inttoptr i64 %v10947 to ptr
  store i64 0, ptr %p10948, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2578
bb_rcgdone2578:
  %v10949 = load i64, ptr %slot1982, align 8
  %p10951 = inttoptr i64 %v10949 to ptr
  %gep10952 = getelementptr i8, ptr %p10951, i64 24
  %op10950 = ptrtoint ptr %gep10952 to i64
  store i64 %op10950, ptr %slot2001, align 8
  %v10953 = load i64, ptr %slot88, align 8
  store i64 %v10953, ptr %slot2002, align 8
  %v10954 = load i64, ptr %slot2001, align 8
  %p10955 = inttoptr i64 %v10954 to ptr
  %ld10956 = load i64, ptr %p10955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10956, ptr %slot2003, align 8
  %v10957 = load i64, ptr %slot2003, align 8
  %cmp10958 = icmp ne i64 %v10957, 0
  %cv10959 = zext i1 %cmp10958 to i32
  store i32 %cv10959, ptr %slot2004, align 8
  %v10960 = load i32, ptr %slot2004, align 8
  %cv10961 = zext i32 %v10960 to i64
  %cond10962 = icmp ne i64 %cv10961, 0
  br i1 %cond10962, label %bb_rcgnn2594, label %bb_rcgdone2594
bb_rcgnn2594:
  %v10963 = load i64, ptr %slot2003, align 8
  %op10964 = sub i64 %v10963, 16
  store i64 %op10964, ptr %slot2005, align 8
  %v10965 = load i64, ptr %slot2003, align 8
  %p10966 = inttoptr i64 %v10965 to ptr
  %rgep10967 = getelementptr i8, ptr %p10966, i64 -16
  %ld10968 = load i64, ptr %rgep10967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10968, ptr %slot2006, align 8
  %v10969 = load i64, ptr %slot2006, align 8
  %op10970 = and i64 %v10969, 4611686018427387906
  store i64 %op10970, ptr %slot2007, align 8
  %v10971 = load i64, ptr %slot2007, align 8
  %cmp10972 = icmp ne i64 %v10971, 0
  %cv10973 = zext i1 %cmp10972 to i32
  store i32 %cv10973, ptr %slot2008, align 8
  %v10974 = load i32, ptr %slot2008, align 8
  %cv10975 = zext i32 %v10974 to i64
  %cond10976 = icmp ne i64 %cv10975, 0
  br i1 %cond10976, label %bb_rcgclear2594, label %bb_rcgcounted2594
bb_rcgcounted2594:
  %v10977 = load i64, ptr %slot2003, align 8
  %op10978 = sub i64 %v10977, 32
  store i64 %op10978, ptr %slot2009, align 8
  %v10979 = load i64, ptr %slot2003, align 8
  %p10980 = inttoptr i64 %v10979 to ptr
  %rgep10981 = getelementptr i8, ptr %p10980, i64 -32
  %ld10982 = load i64, ptr %rgep10981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10982, ptr %slot2010, align 8
  %v10983 = load i64, ptr %slot2010, align 8
  %op10984 = sub i64 %v10983, 1
  store i64 %op10984, ptr %slot2011, align 8
  %v10985 = load i64, ptr %slot2011, align 8
  %cmp10986 = icmp eq i64 %v10985, 0
  %cv10987 = zext i1 %cmp10986 to i32
  store i32 %cv10987, ptr %slot2012, align 8
  %v10988 = load i32, ptr %slot2012, align 8
  %cv10989 = zext i32 %v10988 to i64
  %cond10990 = icmp ne i64 %cv10989, 0
  br i1 %cond10990, label %bb_rcglast2594, label %bb_rcgdec2594
bb_rcglast2594:
  %v10991 = load i64, ptr %slot2003, align 8
  %op10992 = sub i64 %v10991, 24
  store i64 %op10992, ptr %slot2013, align 8
  %v10993 = load i64, ptr %slot2003, align 8
  %p10994 = inttoptr i64 %v10993 to ptr
  %rgep10995 = getelementptr i8, ptr %p10994, i64 -24
  %ld10996 = load i64, ptr %rgep10995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10996, ptr %slot2014, align 8
  %v10997 = load i64, ptr %slot2014, align 8
  %cmp10998 = icmp ne i64 %v10997, 0
  %cv10999 = zext i1 %cmp10998 to i32
  store i32 %cv10999, ptr %slot2015, align 8
  %v11000 = load i32, ptr %slot2015, align 8
  %cv11001 = zext i32 %v11000 to i64
  %cond11002 = icmp ne i64 %cv11001, 0
  br i1 %cond11002, label %bb_rcgdec2594, label %bb_rcgslow2594
bb_rcgslow2594:
  %v11003 = load i64, ptr %slot2002, align 8
  %v11004 = load i64, ptr %slot2001, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v11003, i64 %v11004) nomerge, !dbg !178
  br label %bb_rcgdone2594
bb_rcgdec2594:
  %v11005 = load i64, ptr %slot2011, align 8
  %v11006 = load i64, ptr %slot2003, align 8
  %p11007 = inttoptr i64 %v11006 to ptr
  %rgep11008 = getelementptr i8, ptr %p11007, i64 -32
  store i64 %v11005, ptr %rgep11008, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2594
bb_rcgclear2594:
  %v11009 = load i64, ptr %slot2001, align 8
  %p11010 = inttoptr i64 %v11009 to ptr
  store i64 0, ptr %p11010, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2594
bb_rcgdone2594:
  %v11011 = load i64, ptr %slot1982, align 8
  %p11013 = inttoptr i64 %v11011 to ptr
  %gep11014 = getelementptr i8, ptr %p11013, i64 32
  %op11012 = ptrtoint ptr %gep11014 to i64
  store i64 %op11012, ptr %slot2016, align 8
  %v11015 = load i64, ptr %slot88, align 8
  store i64 %v11015, ptr %slot2017, align 8
  %v11016 = load i64, ptr %slot2016, align 8
  %p11017 = inttoptr i64 %v11016 to ptr
  %ld11018 = load i64, ptr %p11017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11018, ptr %slot2018, align 8
  %v11019 = load i64, ptr %slot2018, align 8
  %cmp11020 = icmp ne i64 %v11019, 0
  %cv11021 = zext i1 %cmp11020 to i32
  store i32 %cv11021, ptr %slot2019, align 8
  %v11022 = load i32, ptr %slot2019, align 8
  %cv11023 = zext i32 %v11022 to i64
  %cond11024 = icmp ne i64 %cv11023, 0
  br i1 %cond11024, label %bb_rcgnn2610, label %bb_rcgdone2610
bb_rcgnn2610:
  %v11025 = load i64, ptr %slot2018, align 8
  %op11026 = sub i64 %v11025, 16
  store i64 %op11026, ptr %slot2020, align 8
  %v11027 = load i64, ptr %slot2018, align 8
  %p11028 = inttoptr i64 %v11027 to ptr
  %rgep11029 = getelementptr i8, ptr %p11028, i64 -16
  %ld11030 = load i64, ptr %rgep11029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11030, ptr %slot2021, align 8
  %v11031 = load i64, ptr %slot2021, align 8
  %op11032 = and i64 %v11031, 4611686018427387906
  store i64 %op11032, ptr %slot2022, align 8
  %v11033 = load i64, ptr %slot2022, align 8
  %cmp11034 = icmp ne i64 %v11033, 0
  %cv11035 = zext i1 %cmp11034 to i32
  store i32 %cv11035, ptr %slot2023, align 8
  %v11036 = load i32, ptr %slot2023, align 8
  %cv11037 = zext i32 %v11036 to i64
  %cond11038 = icmp ne i64 %cv11037, 0
  br i1 %cond11038, label %bb_rcgclear2610, label %bb_rcgcounted2610
bb_rcgcounted2610:
  %v11039 = load i64, ptr %slot2018, align 8
  %op11040 = sub i64 %v11039, 32
  store i64 %op11040, ptr %slot2024, align 8
  %v11041 = load i64, ptr %slot2018, align 8
  %p11042 = inttoptr i64 %v11041 to ptr
  %rgep11043 = getelementptr i8, ptr %p11042, i64 -32
  %ld11044 = load i64, ptr %rgep11043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11044, ptr %slot2025, align 8
  %v11045 = load i64, ptr %slot2025, align 8
  %op11046 = sub i64 %v11045, 1
  store i64 %op11046, ptr %slot2026, align 8
  %v11047 = load i64, ptr %slot2026, align 8
  %cmp11048 = icmp eq i64 %v11047, 0
  %cv11049 = zext i1 %cmp11048 to i32
  store i32 %cv11049, ptr %slot2027, align 8
  %v11050 = load i32, ptr %slot2027, align 8
  %cv11051 = zext i32 %v11050 to i64
  %cond11052 = icmp ne i64 %cv11051, 0
  br i1 %cond11052, label %bb_rcglast2610, label %bb_rcgdec2610
bb_rcglast2610:
  %v11053 = load i64, ptr %slot2018, align 8
  %op11054 = sub i64 %v11053, 24
  store i64 %op11054, ptr %slot2028, align 8
  %v11055 = load i64, ptr %slot2018, align 8
  %p11056 = inttoptr i64 %v11055 to ptr
  %rgep11057 = getelementptr i8, ptr %p11056, i64 -24
  %ld11058 = load i64, ptr %rgep11057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11058, ptr %slot2029, align 8
  %v11059 = load i64, ptr %slot2029, align 8
  %cmp11060 = icmp ne i64 %v11059, 0
  %cv11061 = zext i1 %cmp11060 to i32
  store i32 %cv11061, ptr %slot2030, align 8
  %v11062 = load i32, ptr %slot2030, align 8
  %cv11063 = zext i32 %v11062 to i64
  %cond11064 = icmp ne i64 %cv11063, 0
  br i1 %cond11064, label %bb_rcgdec2610, label %bb_rcgslow2610
bb_rcgslow2610:
  %v11065 = load i64, ptr %slot2017, align 8
  %v11066 = load i64, ptr %slot2016, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v11065, i64 %v11066) nomerge, !dbg !178
  br label %bb_rcgdone2610
bb_rcgdec2610:
  %v11067 = load i64, ptr %slot2026, align 8
  %v11068 = load i64, ptr %slot2018, align 8
  %p11069 = inttoptr i64 %v11068 to ptr
  %rgep11070 = getelementptr i8, ptr %p11069, i64 -32
  store i64 %v11067, ptr %rgep11070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2610
bb_rcgclear2610:
  %v11071 = load i64, ptr %slot2016, align 8
  %p11072 = inttoptr i64 %v11071 to ptr
  store i64 0, ptr %p11072, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2610
bb_rcgdone2610:
  %v11073 = load i64, ptr %slot1982, align 8
  %p11074 = inttoptr i64 %v11073 to ptr
  store i64 0, ptr %p11074, align 8, !alias.scope !3, !noalias !4
  %v11075 = load i64, ptr %slot1982, align 8
  %p11077 = inttoptr i64 %v11075 to ptr
  %gep11078 = getelementptr i8, ptr %p11077, i64 8
  %op11076 = ptrtoint ptr %gep11078 to i64
  store i64 %op11076, ptr %slot2031, align 8
  %v11079 = load i64, ptr %slot2031, align 8
  %p11080 = inttoptr i64 %v11079 to ptr
  store i64 0, ptr %p11080, align 8, !alias.scope !3, !noalias !4
  %v11081 = load i64, ptr %slot1982, align 8
  %p11083 = inttoptr i64 %v11081 to ptr
  %gep11084 = getelementptr i8, ptr %p11083, i64 16
  %op11082 = ptrtoint ptr %gep11084 to i64
  store i64 %op11082, ptr %slot2032, align 8
  %v11085 = load i64, ptr %slot2032, align 8
  %p11086 = inttoptr i64 %v11085 to ptr
  store i64 0, ptr %p11086, align 8, !alias.scope !3, !noalias !4
  %v11087 = load i64, ptr %slot1982, align 8
  %p11089 = inttoptr i64 %v11087 to ptr
  %gep11090 = getelementptr i8, ptr %p11089, i64 24
  %op11088 = ptrtoint ptr %gep11090 to i64
  store i64 %op11088, ptr %slot2033, align 8
  %v11091 = load i64, ptr %slot2033, align 8
  %p11092 = inttoptr i64 %v11091 to ptr
  store i64 0, ptr %p11092, align 8, !alias.scope !3, !noalias !4
  %v11093 = load i64, ptr %slot1982, align 8
  %p11095 = inttoptr i64 %v11093 to ptr
  %gep11096 = getelementptr i8, ptr %p11095, i64 32
  %op11094 = ptrtoint ptr %gep11096 to i64
  store i64 %op11094, ptr %slot2034, align 8
  %v11097 = load i64, ptr %slot2034, align 8
  %p11098 = inttoptr i64 %v11097 to ptr
  store i64 0, ptr %p11098, align 8, !alias.scope !3, !noalias !4
  %v11099 = load i64, ptr %slot1982, align 8
  %p11101 = inttoptr i64 %v11099 to ptr
  %gep11102 = getelementptr i8, ptr %p11101, i64 40
  %op11100 = ptrtoint ptr %gep11102 to i64
  store i64 %op11100, ptr %slot2035, align 8
  %v11103 = load i64, ptr %slot2035, align 8
  %p11104 = inttoptr i64 %v11103 to ptr
  store i64 0, ptr %p11104, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2560
bb_rcslotdone2560:
  %v11105 = load i64, ptr %slot66, align 8
  store i64 %v11105, ptr %slot2036, align 8
  %v11106 = load i64, ptr %slot42, align 8
  store i64 %v11106, ptr %slot2037, align 8
  %v11107 = load i64, ptr %slot2037, align 8
  %v11108 = load i64, ptr %slot2036, align 8
  %p11109 = inttoptr i64 %v11107 to ptr
  %p11110 = inttoptr i64 %v11108 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11110, ptr %p11109, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v11111 = load i64, ptr %slot31, align 8
  %p11112 = inttoptr i64 %v11111 to ptr
  store i32 0, ptr %p11112, align 4, !alias.scope !3, !noalias !4
  %v11113 = load i64, ptr %slot22, align 8
  %p11114 = inttoptr i64 %v11113 to ptr
  store i32 2, ptr %p11114, align 4, !alias.scope !3, !noalias !4
  %v11115 = load i64, ptr %slot32, align 8
  %p11116 = inttoptr i64 %v11115 to ptr
  %ld11117 = load i32, ptr %p11116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11117, ptr %slot2038, align 8
  %v11118 = load i32, ptr %slot2038, align 8
  %v11119 = load i64, ptr %slot22, align 8
  %p11120 = inttoptr i64 %v11119 to ptr
  store i32 %v11118, ptr %p11120, align 4, !alias.scope !3, !noalias !4
  %v11121 = load i64, ptr %slot21, align 8
  %p11122 = inttoptr i64 %v11121 to ptr
  store i32 1, ptr %p11122, align 4, !alias.scope !3, !noalias !4
  %v11123 = load i64, ptr %slot17, align 8
  %p11124 = inttoptr i64 %v11123 to ptr
  %ld11125 = load i32, ptr %p11124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11125, ptr %slot2039, align 8
  %v11126 = load i32, ptr %slot2039, align 8
  %cv11127 = zext i32 %v11126 to i64
  %cond11128 = icmp ne i64 %cv11127, 0
  br i1 %cond11128, label %bb_rcslotdrop2628, label %bb_rcslotdone2628
bb_rcslotdrop2628:
  %v11129 = load i64, ptr %slot17, align 8
  %p11130 = inttoptr i64 %v11129 to ptr
  store i32 0, ptr %p11130, align 4, !alias.scope !3, !noalias !4
  %v11131 = load i64, ptr %slot63, align 8
  store i64 %v11131, ptr %slot2040, align 8
  %v11132 = load i64, ptr %slot18, align 8
  %p11133 = inttoptr i64 %v11132 to ptr
  %ld11134 = load i32, ptr %p11133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11134, ptr %slot2041, align 8
  %v11135 = load i32, ptr %slot2041, align 8
  %op11136 = and i32 %v11135, 28
  store i32 %op11136, ptr %slot2042, align 8
  %v11137 = load i32, ptr %slot2042, align 8
  %cv11138 = zext i32 %v11137 to i64
  %cond11139 = icmp ne i64 %cv11138, 0
  br i1 %cond11139, label %bb_rcslotrole2628, label %bb_rcslotowner2628
bb_rcslotrole2628:
  %v11140 = load i64, ptr %slot88, align 8
  store i64 %v11140, ptr %slot2043, align 8
  %v11141 = load i64, ptr %slot2040, align 8
  %p11142 = inttoptr i64 %v11141 to ptr
  %ld11143 = load i64, ptr %p11142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11143, ptr %slot2044, align 8
  %v11144 = load i64, ptr %slot2044, align 8
  %cmp11145 = icmp ne i64 %v11144, 0
  %cv11146 = zext i1 %cmp11145 to i32
  store i32 %cv11146, ptr %slot2045, align 8
  %v11147 = load i32, ptr %slot2045, align 8
  %cv11148 = zext i32 %v11147 to i64
  %cond11149 = icmp ne i64 %cv11148, 0
  br i1 %cond11149, label %bb_rcgnn2644, label %bb_rcgdone2644
bb_rcgnn2644:
  %v11150 = load i64, ptr %slot2044, align 8
  %op11151 = sub i64 %v11150, 16
  store i64 %op11151, ptr %slot2046, align 8
  %v11152 = load i64, ptr %slot2044, align 8
  %p11153 = inttoptr i64 %v11152 to ptr
  %rgep11154 = getelementptr i8, ptr %p11153, i64 -16
  %ld11155 = load i64, ptr %rgep11154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11155, ptr %slot2047, align 8
  %v11156 = load i64, ptr %slot2047, align 8
  %op11157 = and i64 %v11156, 4611686018427387906
  store i64 %op11157, ptr %slot2048, align 8
  %v11158 = load i64, ptr %slot2048, align 8
  %cmp11159 = icmp ne i64 %v11158, 0
  %cv11160 = zext i1 %cmp11159 to i32
  store i32 %cv11160, ptr %slot2049, align 8
  %v11161 = load i32, ptr %slot2049, align 8
  %cv11162 = zext i32 %v11161 to i64
  %cond11163 = icmp ne i64 %cv11162, 0
  br i1 %cond11163, label %bb_rcgclear2644, label %bb_rcgcounted2644
bb_rcgcounted2644:
  %v11164 = load i64, ptr %slot2044, align 8
  %op11165 = sub i64 %v11164, 24
  store i64 %op11165, ptr %slot2050, align 8
  %v11166 = load i64, ptr %slot2044, align 8
  %p11167 = inttoptr i64 %v11166 to ptr
  %rgep11168 = getelementptr i8, ptr %p11167, i64 -24
  %ld11169 = load i64, ptr %rgep11168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11169, ptr %slot2051, align 8
  %v11170 = load i64, ptr %slot2051, align 8
  %op11171 = sub i64 %v11170, 1
  store i64 %op11171, ptr %slot2052, align 8
  %v11172 = load i64, ptr %slot2052, align 8
  %cmp11173 = icmp eq i64 %v11172, 0
  %cv11174 = zext i1 %cmp11173 to i32
  store i32 %cv11174, ptr %slot2053, align 8
  %v11175 = load i32, ptr %slot2053, align 8
  %cv11176 = zext i32 %v11175 to i64
  %cond11177 = icmp ne i64 %cv11176, 0
  br i1 %cond11177, label %bb_rcglast2644, label %bb_rcgdec2644
bb_rcglast2644:
  %v11178 = load i64, ptr %slot2044, align 8
  %op11179 = sub i64 %v11178, 32
  store i64 %op11179, ptr %slot2054, align 8
  %v11180 = load i64, ptr %slot2044, align 8
  %p11181 = inttoptr i64 %v11180 to ptr
  %rgep11182 = getelementptr i8, ptr %p11181, i64 -32
  %ld11183 = load i64, ptr %rgep11182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11183, ptr %slot2055, align 8
  %v11184 = load i64, ptr %slot2055, align 8
  %cmp11185 = icmp ne i64 %v11184, 0
  %cv11186 = zext i1 %cmp11185 to i32
  store i32 %cv11186, ptr %slot2056, align 8
  %v11187 = load i32, ptr %slot2056, align 8
  %cv11188 = zext i32 %v11187 to i64
  %cond11189 = icmp ne i64 %cv11188, 0
  br i1 %cond11189, label %bb_rcgdec2644, label %bb_rcgslow2644
bb_rcgslow2644:
  %v11190 = load i64, ptr %slot2043, align 8
  %v11191 = load i64, ptr %slot2040, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11190, i64 %v11191) nomerge, !dbg !178
  br label %bb_rcgdone2644
bb_rcgdec2644:
  %v11192 = load i64, ptr %slot2052, align 8
  %v11193 = load i64, ptr %slot2044, align 8
  %p11194 = inttoptr i64 %v11193 to ptr
  %rgep11195 = getelementptr i8, ptr %p11194, i64 -24
  store i64 %v11192, ptr %rgep11195, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2644
bb_rcgclear2644:
  %v11196 = load i64, ptr %slot2040, align 8
  %p11197 = inttoptr i64 %v11196 to ptr
  store i64 0, ptr %p11197, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2644
bb_rcgdone2644:
  br label %bb_rcslotdone2628
bb_rcslotowner2628:
  %v11198 = load i64, ptr %slot88, align 8
  store i64 %v11198, ptr %slot2057, align 8
  %v11199 = load i64, ptr %slot2040, align 8
  %p11200 = inttoptr i64 %v11199 to ptr
  %ld11201 = load i64, ptr %p11200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11201, ptr %slot2058, align 8
  %v11202 = load i64, ptr %slot2058, align 8
  %cmp11203 = icmp ne i64 %v11202, 0
  %cv11204 = zext i1 %cmp11203 to i32
  store i32 %cv11204, ptr %slot2059, align 8
  %v11205 = load i32, ptr %slot2059, align 8
  %cv11206 = zext i32 %v11205 to i64
  %cond11207 = icmp ne i64 %cv11206, 0
  br i1 %cond11207, label %bb_rcgnn2659, label %bb_rcgdone2659
bb_rcgnn2659:
  %v11208 = load i64, ptr %slot2058, align 8
  %op11209 = sub i64 %v11208, 16
  store i64 %op11209, ptr %slot2060, align 8
  %v11210 = load i64, ptr %slot2058, align 8
  %p11211 = inttoptr i64 %v11210 to ptr
  %rgep11212 = getelementptr i8, ptr %p11211, i64 -16
  %ld11213 = load i64, ptr %rgep11212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11213, ptr %slot2061, align 8
  %v11214 = load i64, ptr %slot2061, align 8
  %op11215 = and i64 %v11214, 4611686018427387906
  store i64 %op11215, ptr %slot2062, align 8
  %v11216 = load i64, ptr %slot2062, align 8
  %cmp11217 = icmp ne i64 %v11216, 0
  %cv11218 = zext i1 %cmp11217 to i32
  store i32 %cv11218, ptr %slot2063, align 8
  %v11219 = load i32, ptr %slot2063, align 8
  %cv11220 = zext i32 %v11219 to i64
  %cond11221 = icmp ne i64 %cv11220, 0
  br i1 %cond11221, label %bb_rcgclear2659, label %bb_rcgcounted2659
bb_rcgcounted2659:
  %v11222 = load i64, ptr %slot2058, align 8
  %op11223 = sub i64 %v11222, 32
  store i64 %op11223, ptr %slot2064, align 8
  %v11224 = load i64, ptr %slot2058, align 8
  %p11225 = inttoptr i64 %v11224 to ptr
  %rgep11226 = getelementptr i8, ptr %p11225, i64 -32
  %ld11227 = load i64, ptr %rgep11226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11227, ptr %slot2065, align 8
  %v11228 = load i64, ptr %slot2065, align 8
  %op11229 = sub i64 %v11228, 1
  store i64 %op11229, ptr %slot2066, align 8
  %v11230 = load i64, ptr %slot2066, align 8
  %cmp11231 = icmp eq i64 %v11230, 0
  %cv11232 = zext i1 %cmp11231 to i32
  store i32 %cv11232, ptr %slot2067, align 8
  %v11233 = load i32, ptr %slot2067, align 8
  %cv11234 = zext i32 %v11233 to i64
  %cond11235 = icmp ne i64 %cv11234, 0
  br i1 %cond11235, label %bb_rcglast2659, label %bb_rcgdec2659
bb_rcglast2659:
  %v11236 = load i64, ptr %slot2058, align 8
  %op11237 = sub i64 %v11236, 24
  store i64 %op11237, ptr %slot2068, align 8
  %v11238 = load i64, ptr %slot2058, align 8
  %p11239 = inttoptr i64 %v11238 to ptr
  %rgep11240 = getelementptr i8, ptr %p11239, i64 -24
  %ld11241 = load i64, ptr %rgep11240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11241, ptr %slot2069, align 8
  %v11242 = load i64, ptr %slot2069, align 8
  %cmp11243 = icmp ne i64 %v11242, 0
  %cv11244 = zext i1 %cmp11243 to i32
  store i32 %cv11244, ptr %slot2070, align 8
  %v11245 = load i32, ptr %slot2070, align 8
  %cv11246 = zext i32 %v11245 to i64
  %cond11247 = icmp ne i64 %cv11246, 0
  br i1 %cond11247, label %bb_rcgdec2659, label %bb_rcgslow2659
bb_rcgslow2659:
  %v11248 = load i64, ptr %slot2057, align 8
  %v11249 = load i64, ptr %slot2040, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11248, i64 %v11249) nomerge, !dbg !178
  br label %bb_rcgdone2659
bb_rcgdec2659:
  %v11250 = load i64, ptr %slot2066, align 8
  %v11251 = load i64, ptr %slot2058, align 8
  %p11252 = inttoptr i64 %v11251 to ptr
  %rgep11253 = getelementptr i8, ptr %p11252, i64 -32
  store i64 %v11250, ptr %rgep11253, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2659
bb_rcgclear2659:
  %v11254 = load i64, ptr %slot2040, align 8
  %p11255 = inttoptr i64 %v11254 to ptr
  store i64 0, ptr %p11255, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2659
bb_rcgdone2659:
  br label %bb_rcslotdone2628
bb_rcslotdone2628:
  %v11256 = load i64, ptr %slot59, align 8
  %v11257 = load i64, ptr %slot68, align 8
  %p11258 = inttoptr i64 %v11257 to ptr
  store i64 %v11256, ptr %p11258, align 8, !alias.scope !3, !noalias !4
  %v11259 = load i64, ptr %slot68, align 8
  %p11260 = inttoptr i64 %v11259 to ptr
  %ld11261 = load i64, ptr %p11260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11261, ptr %slot2071, align 8
  %v11262 = load i64, ptr %slot23, align 8
  %p11263 = inttoptr i64 %v11262 to ptr
  %ld11264 = load i32, ptr %p11263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11264, ptr %slot2072, align 8
  %v11265 = load i64, ptr %slot24, align 8
  %p11266 = inttoptr i64 %v11265 to ptr
  %ld11267 = load i32, ptr %p11266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11267, ptr %slot2073, align 8
  %v11268 = load i32, ptr %slot2073, align 8
  %op11269 = and i32 %v11268, 24
  store i32 %op11269, ptr %slot2073, align 8
  %v11270 = load i32, ptr %slot2073, align 8
  %cmp11271 = icmp eq i32 %v11270, 0
  %cv11272 = zext i1 %cmp11271 to i32
  store i32 %cv11272, ptr %slot2074, align 8
  %v11273 = load i32, ptr %slot2072, align 8
  %v11274 = load i32, ptr %slot2074, align 8
  %op11275 = and i32 %v11273, %v11274
  store i32 %op11275, ptr %slot2075, align 8
  %v11276 = load i32, ptr %slot2075, align 8
  %cv11277 = zext i32 %v11276 to i64
  %cond11278 = icmp ne i64 %cv11277, 0
  br i1 %cond11278, label %bb_rcprivateown2670, label %bb_rcprivateloan2670
bb_rcprivateown2670:
  %v11279 = load i64, ptr %slot42, align 8
  store i64 %v11279, ptr %slot2076, align 8
  %v11280 = load i64, ptr %slot89, align 8
  store i64 %v11280, ptr %slot2077, align 8
  %v11281 = load i64, ptr %slot88, align 8
  %v11282 = load i64, ptr %slot2076, align 8
  %v11283 = load i64, ptr %slot2071, align 8
  %v11284 = load i64, ptr %slot2077, align 8
  %cv11285 = trunc i64 %v11284 to i32
  %call11286 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v11281, i64 %v11282, i64 %v11283, i32 %cv11285) nomerge, !dbg !180
  store i32 %call11286, ptr %slot2078, align 8
  %v11287 = load i32, ptr %slot2078, align 8
  %cv11288 = zext i32 %v11287 to i64
  %cond11289 = icmp ne i64 %cv11288, 0
  br i1 %cond11289, label %bb_rcsuccess2674, label %bb_rcfailure2674
bb_rcfailure2674:
  %v11290 = load i64, ptr %slot88, align 8
  %p11291 = inttoptr i64 %v11290 to ptr
  %call11292 = call i32 @myl_rc_take_failure(ptr %p11291) nomerge, !dbg !180
  store i32 %call11292, ptr %slot2079, align 8
  %v11293 = load i64, ptr %slot1, align 8
  %p11294 = inttoptr i64 %v11293 to ptr
  %v11295 = load i32, ptr %slot2079, align 8
  %call11296 = call i32 @myl_qbe_rc_status(ptr %p11294, i32 %v11295) nomerge, !dbg !180
  store i32 %call11296, ptr %slot2080, align 8
  br label %bb_failure
bb_rcsuccess2674:
  %v11297 = load i64, ptr %slot23, align 8
  %p11298 = inttoptr i64 %v11297 to ptr
  store i32 0, ptr %p11298, align 4, !alias.scope !3, !noalias !4
  %v11299 = load i64, ptr %slot32, align 8
  %p11300 = inttoptr i64 %v11299 to ptr
  store i32 2, ptr %p11300, align 4, !alias.scope !3, !noalias !4
  %v11301 = load i64, ptr %slot31, align 8
  %p11302 = inttoptr i64 %v11301 to ptr
  store i32 1, ptr %p11302, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2670
bb_rcprivateloan2670:
  %v11303 = load i64, ptr %slot42, align 8
  store i64 %v11303, ptr %slot2081, align 8
  %v11304 = load i64, ptr %slot88, align 8
  %v11305 = load i64, ptr %slot2081, align 8
  %v11306 = load i64, ptr %slot2071, align 8
  %call11307 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v11304, i64 %v11305, i64 %v11306) nomerge, !dbg !180
  store i32 %call11307, ptr %slot2082, align 8
  %v11308 = load i32, ptr %slot2082, align 8
  %cv11309 = zext i32 %v11308 to i64
  %cond11310 = icmp ne i64 %cv11309, 0
  br i1 %cond11310, label %bb_rcsuccess2682, label %bb_rcfailure2682
bb_rcfailure2682:
  %v11311 = load i64, ptr %slot88, align 8
  %p11312 = inttoptr i64 %v11311 to ptr
  %call11313 = call i32 @myl_rc_take_failure(ptr %p11312) nomerge, !dbg !180
  store i32 %call11313, ptr %slot2083, align 8
  %v11314 = load i64, ptr %slot1, align 8
  %p11315 = inttoptr i64 %v11314 to ptr
  %v11316 = load i32, ptr %slot2083, align 8
  %call11317 = call i32 @myl_qbe_rc_status(ptr %p11315, i32 %v11316) nomerge, !dbg !180
  store i32 %call11317, ptr %slot2084, align 8
  br label %bb_failure
bb_rcsuccess2682:
  %v11318 = load i64, ptr %slot32, align 8
  %p11319 = inttoptr i64 %v11318 to ptr
  store i32 2, ptr %p11319, align 4, !alias.scope !3, !noalias !4
  %v11320 = load i64, ptr %slot32, align 8
  %p11321 = inttoptr i64 %v11320 to ptr
  store i32 16, ptr %p11321, align 4, !alias.scope !3, !noalias !4
  %v11322 = load i64, ptr %slot31, align 8
  %p11323 = inttoptr i64 %v11322 to ptr
  store i32 1, ptr %p11323, align 4, !alias.scope !3, !noalias !4
  %v11324 = load i64, ptr %slot23, align 8
  %p11325 = inttoptr i64 %v11324 to ptr
  %ld11326 = load i32, ptr %p11325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11326, ptr %slot2085, align 8
  %v11327 = load i32, ptr %slot2085, align 8
  %cv11328 = zext i32 %v11327 to i64
  %cond11329 = icmp ne i64 %cv11328, 0
  br i1 %cond11329, label %bb_rcslotdrop2690, label %bb_rcslotdone2690
bb_rcslotdrop2690:
  %v11330 = load i64, ptr %slot23, align 8
  %p11331 = inttoptr i64 %v11330 to ptr
  store i32 0, ptr %p11331, align 4, !alias.scope !3, !noalias !4
  %v11332 = load i64, ptr %slot34, align 8
  store i64 %v11332, ptr %slot2086, align 8
  %v11333 = load i64, ptr %slot24, align 8
  %p11334 = inttoptr i64 %v11333 to ptr
  %ld11335 = load i32, ptr %p11334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11335, ptr %slot2087, align 8
  %v11336 = load i32, ptr %slot2087, align 8
  %op11337 = and i32 %v11336, 28
  store i32 %op11337, ptr %slot2088, align 8
  %v11338 = load i32, ptr %slot2088, align 8
  %cv11339 = zext i32 %v11338 to i64
  %cond11340 = icmp ne i64 %cv11339, 0
  br i1 %cond11340, label %bb_rcslotrole2690, label %bb_rcslotowner2690
bb_rcslotrole2690:
  %v11341 = load i64, ptr %slot88, align 8
  store i64 %v11341, ptr %slot2089, align 8
  %v11342 = load i64, ptr %slot2089, align 8
  %v11343 = load i64, ptr %slot2086, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11342, i64 %v11343) nomerge, !dbg !180
  br label %bb_rcslotdone2690
bb_rcslotowner2690:
  %v11344 = load i64, ptr %slot88, align 8
  store i64 %v11344, ptr %slot2090, align 8
  %v11345 = load i64, ptr %slot2090, align 8
  %v11346 = load i64, ptr %slot2086, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11345, i64 %v11346) nomerge, !dbg !180
  br label %bb_rcslotdone2690
bb_rcslotdone2690:
  br label %bb_rcprivateprepared2670
bb_rcprivateprepared2670:
  %v11347 = load i64, ptr %slot19, align 8
  %p11348 = inttoptr i64 %v11347 to ptr
  %ld11349 = load i32, ptr %p11348, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11349, ptr %slot2091, align 8
  %v11350 = load i32, ptr %slot2091, align 8
  %cv11351 = zext i32 %v11350 to i64
  %cond11352 = icmp ne i64 %cv11351, 0
  br i1 %cond11352, label %bb_rcslotdrop2700, label %bb_rcslotdone2700
bb_rcslotdrop2700:
  %v11353 = load i64, ptr %slot19, align 8
  %p11354 = inttoptr i64 %v11353 to ptr
  store i32 0, ptr %p11354, align 4, !alias.scope !3, !noalias !4
  %v11355 = load i64, ptr %slot65, align 8
  store i64 %v11355, ptr %slot2092, align 8
  %v11356 = load i64, ptr %slot20, align 8
  %p11357 = inttoptr i64 %v11356 to ptr
  %ld11358 = load i32, ptr %p11357, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11358, ptr %slot2093, align 8
  %v11359 = load i32, ptr %slot2093, align 8
  %op11360 = and i32 %v11359, 28
  store i32 %op11360, ptr %slot2094, align 8
  %v11361 = load i32, ptr %slot2094, align 8
  %cv11362 = zext i32 %v11361 to i64
  %cond11363 = icmp ne i64 %cv11362, 0
  br i1 %cond11363, label %bb_rcslotrole2700, label %bb_rcslotowner2700
bb_rcslotrole2700:
  %v11364 = load i64, ptr %slot88, align 8
  store i64 %v11364, ptr %slot2095, align 8
  %v11365 = load i64, ptr %slot2095, align 8
  %v11366 = load i64, ptr %slot2092, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11365, i64 %v11366) nomerge, !dbg !180
  br label %bb_rcslotdone2700
bb_rcslotowner2700:
  %v11367 = load i64, ptr %slot88, align 8
  store i64 %v11367, ptr %slot2096, align 8
  %v11368 = load i64, ptr %slot2096, align 8
  %v11369 = load i64, ptr %slot2092, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11368, i64 %v11369) nomerge, !dbg !180
  br label %bb_rcslotdone2700
bb_rcslotdone2700:
  %v11370 = load i64, ptr %slot65, align 8
  store i64 %v11370, ptr %slot2097, align 8
  %v11371 = load i64, ptr %slot42, align 8
  store i64 %v11371, ptr %slot2098, align 8
  %v11372 = load i64, ptr %slot2098, align 8
  %v11373 = load i64, ptr %slot2097, align 8
  %p11374 = inttoptr i64 %v11372 to ptr
  %p11375 = inttoptr i64 %v11373 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11375, ptr %p11374, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v11376 = load i64, ptr %slot31, align 8
  %p11377 = inttoptr i64 %v11376 to ptr
  store i32 0, ptr %p11377, align 4, !alias.scope !3, !noalias !4
  %v11378 = load i64, ptr %slot20, align 8
  %p11379 = inttoptr i64 %v11378 to ptr
  store i32 2, ptr %p11379, align 4, !alias.scope !3, !noalias !4
  %v11380 = load i64, ptr %slot32, align 8
  %p11381 = inttoptr i64 %v11380 to ptr
  %ld11382 = load i32, ptr %p11381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11382, ptr %slot2099, align 8
  %v11383 = load i32, ptr %slot2099, align 8
  %v11384 = load i64, ptr %slot20, align 8
  %p11385 = inttoptr i64 %v11384 to ptr
  store i32 %v11383, ptr %p11385, align 4, !alias.scope !3, !noalias !4
  %v11386 = load i64, ptr %slot19, align 8
  %p11387 = inttoptr i64 %v11386 to ptr
  store i32 1, ptr %p11387, align 4, !alias.scope !3, !noalias !4
  %v11388 = load i64, ptr %slot59, align 8
  %v11389 = load i64, ptr %slot68, align 8
  %p11390 = inttoptr i64 %v11389 to ptr
  store i64 %v11388, ptr %p11390, align 8, !alias.scope !3, !noalias !4
  %v11391 = load i64, ptr %slot68, align 8
  %p11392 = inttoptr i64 %v11391 to ptr
  %ld11393 = load i64, ptr %p11392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11393, ptr %slot2100, align 8
  %v11394 = load i64, ptr %slot23, align 8
  %p11395 = inttoptr i64 %v11394 to ptr
  %ld11396 = load i32, ptr %p11395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11396, ptr %slot2101, align 8
  %v11397 = load i64, ptr %slot24, align 8
  %p11398 = inttoptr i64 %v11397 to ptr
  %ld11399 = load i32, ptr %p11398, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11399, ptr %slot2102, align 8
  %v11400 = load i32, ptr %slot2102, align 8
  %op11401 = and i32 %v11400, 24
  store i32 %op11401, ptr %slot2102, align 8
  %v11402 = load i32, ptr %slot2102, align 8
  %cmp11403 = icmp eq i32 %v11402, 0
  %cv11404 = zext i1 %cmp11403 to i32
  store i32 %cv11404, ptr %slot2103, align 8
  %v11405 = load i32, ptr %slot2101, align 8
  %v11406 = load i32, ptr %slot2103, align 8
  %op11407 = and i32 %v11405, %v11406
  store i32 %op11407, ptr %slot2104, align 8
  %v11408 = load i32, ptr %slot2104, align 8
  %cv11409 = zext i32 %v11408 to i64
  %cond11410 = icmp ne i64 %cv11409, 0
  br i1 %cond11410, label %bb_rcprivateown2721, label %bb_rcprivateloan2721
bb_rcprivateown2721:
  %v11411 = load i64, ptr %slot42, align 8
  store i64 %v11411, ptr %slot2105, align 8
  %v11412 = load i64, ptr %slot89, align 8
  store i64 %v11412, ptr %slot2106, align 8
  %v11413 = load i64, ptr %slot88, align 8
  %v11414 = load i64, ptr %slot2105, align 8
  %v11415 = load i64, ptr %slot2100, align 8
  %v11416 = load i64, ptr %slot2106, align 8
  %cv11417 = trunc i64 %v11416 to i32
  %call11418 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v11413, i64 %v11414, i64 %v11415, i32 %cv11417) nomerge, !dbg !182
  store i32 %call11418, ptr %slot2107, align 8
  %v11419 = load i32, ptr %slot2107, align 8
  %cv11420 = zext i32 %v11419 to i64
  %cond11421 = icmp ne i64 %cv11420, 0
  br i1 %cond11421, label %bb_rcsuccess2725, label %bb_rcfailure2725
bb_rcfailure2725:
  %v11422 = load i64, ptr %slot88, align 8
  %p11423 = inttoptr i64 %v11422 to ptr
  %call11424 = call i32 @myl_rc_take_failure(ptr %p11423) nomerge, !dbg !182
  store i32 %call11424, ptr %slot2108, align 8
  %v11425 = load i64, ptr %slot1, align 8
  %p11426 = inttoptr i64 %v11425 to ptr
  %v11427 = load i32, ptr %slot2108, align 8
  %call11428 = call i32 @myl_qbe_rc_status(ptr %p11426, i32 %v11427) nomerge, !dbg !182
  store i32 %call11428, ptr %slot2109, align 8
  br label %bb_failure
bb_rcsuccess2725:
  %v11429 = load i64, ptr %slot23, align 8
  %p11430 = inttoptr i64 %v11429 to ptr
  store i32 0, ptr %p11430, align 4, !alias.scope !3, !noalias !4
  %v11431 = load i64, ptr %slot32, align 8
  %p11432 = inttoptr i64 %v11431 to ptr
  store i32 2, ptr %p11432, align 4, !alias.scope !3, !noalias !4
  %v11433 = load i64, ptr %slot31, align 8
  %p11434 = inttoptr i64 %v11433 to ptr
  store i32 1, ptr %p11434, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2721
bb_rcprivateloan2721:
  %v11435 = load i64, ptr %slot42, align 8
  store i64 %v11435, ptr %slot2110, align 8
  %v11436 = load i64, ptr %slot88, align 8
  %v11437 = load i64, ptr %slot2110, align 8
  %v11438 = load i64, ptr %slot2100, align 8
  %call11439 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v11436, i64 %v11437, i64 %v11438) nomerge, !dbg !182
  store i32 %call11439, ptr %slot2111, align 8
  %v11440 = load i32, ptr %slot2111, align 8
  %cv11441 = zext i32 %v11440 to i64
  %cond11442 = icmp ne i64 %cv11441, 0
  br i1 %cond11442, label %bb_rcsuccess2733, label %bb_rcfailure2733
bb_rcfailure2733:
  %v11443 = load i64, ptr %slot88, align 8
  %p11444 = inttoptr i64 %v11443 to ptr
  %call11445 = call i32 @myl_rc_take_failure(ptr %p11444) nomerge, !dbg !182
  store i32 %call11445, ptr %slot2112, align 8
  %v11446 = load i64, ptr %slot1, align 8
  %p11447 = inttoptr i64 %v11446 to ptr
  %v11448 = load i32, ptr %slot2112, align 8
  %call11449 = call i32 @myl_qbe_rc_status(ptr %p11447, i32 %v11448) nomerge, !dbg !182
  store i32 %call11449, ptr %slot2113, align 8
  br label %bb_failure
bb_rcsuccess2733:
  %v11450 = load i64, ptr %slot32, align 8
  %p11451 = inttoptr i64 %v11450 to ptr
  store i32 2, ptr %p11451, align 4, !alias.scope !3, !noalias !4
  %v11452 = load i64, ptr %slot32, align 8
  %p11453 = inttoptr i64 %v11452 to ptr
  store i32 16, ptr %p11453, align 4, !alias.scope !3, !noalias !4
  %v11454 = load i64, ptr %slot31, align 8
  %p11455 = inttoptr i64 %v11454 to ptr
  store i32 1, ptr %p11455, align 4, !alias.scope !3, !noalias !4
  %v11456 = load i64, ptr %slot23, align 8
  %p11457 = inttoptr i64 %v11456 to ptr
  %ld11458 = load i32, ptr %p11457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11458, ptr %slot2114, align 8
  %v11459 = load i32, ptr %slot2114, align 8
  %cv11460 = zext i32 %v11459 to i64
  %cond11461 = icmp ne i64 %cv11460, 0
  br i1 %cond11461, label %bb_rcslotdrop2741, label %bb_rcslotdone2741
bb_rcslotdrop2741:
  %v11462 = load i64, ptr %slot23, align 8
  %p11463 = inttoptr i64 %v11462 to ptr
  store i32 0, ptr %p11463, align 4, !alias.scope !3, !noalias !4
  %v11464 = load i64, ptr %slot34, align 8
  store i64 %v11464, ptr %slot2115, align 8
  %v11465 = load i64, ptr %slot24, align 8
  %p11466 = inttoptr i64 %v11465 to ptr
  %ld11467 = load i32, ptr %p11466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11467, ptr %slot2116, align 8
  %v11468 = load i32, ptr %slot2116, align 8
  %op11469 = and i32 %v11468, 28
  store i32 %op11469, ptr %slot2117, align 8
  %v11470 = load i32, ptr %slot2117, align 8
  %cv11471 = zext i32 %v11470 to i64
  %cond11472 = icmp ne i64 %cv11471, 0
  br i1 %cond11472, label %bb_rcslotrole2741, label %bb_rcslotowner2741
bb_rcslotrole2741:
  %v11473 = load i64, ptr %slot88, align 8
  store i64 %v11473, ptr %slot2118, align 8
  %v11474 = load i64, ptr %slot2118, align 8
  %v11475 = load i64, ptr %slot2115, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11474, i64 %v11475) nomerge, !dbg !182
  br label %bb_rcslotdone2741
bb_rcslotowner2741:
  %v11476 = load i64, ptr %slot88, align 8
  store i64 %v11476, ptr %slot2119, align 8
  %v11477 = load i64, ptr %slot2119, align 8
  %v11478 = load i64, ptr %slot2115, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11477, i64 %v11478) nomerge, !dbg !182
  br label %bb_rcslotdone2741
bb_rcslotdone2741:
  br label %bb_rcprivateprepared2721
bb_rcprivateprepared2721:
  %v11479 = load i64, ptr %slot19, align 8
  %p11480 = inttoptr i64 %v11479 to ptr
  %ld11481 = load i32, ptr %p11480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11481, ptr %slot2120, align 8
  %v11482 = load i32, ptr %slot2120, align 8
  %cv11483 = zext i32 %v11482 to i64
  %cond11484 = icmp ne i64 %cv11483, 0
  br i1 %cond11484, label %bb_rcslotdrop2751, label %bb_rcslotdone2751
bb_rcslotdrop2751:
  %v11485 = load i64, ptr %slot19, align 8
  %p11486 = inttoptr i64 %v11485 to ptr
  store i32 0, ptr %p11486, align 4, !alias.scope !3, !noalias !4
  %v11487 = load i64, ptr %slot65, align 8
  store i64 %v11487, ptr %slot2121, align 8
  %v11488 = load i64, ptr %slot20, align 8
  %p11489 = inttoptr i64 %v11488 to ptr
  %ld11490 = load i32, ptr %p11489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11490, ptr %slot2122, align 8
  %v11491 = load i32, ptr %slot2122, align 8
  %op11492 = and i32 %v11491, 28
  store i32 %op11492, ptr %slot2123, align 8
  %v11493 = load i32, ptr %slot2123, align 8
  %cv11494 = zext i32 %v11493 to i64
  %cond11495 = icmp ne i64 %cv11494, 0
  br i1 %cond11495, label %bb_rcslotrole2751, label %bb_rcslotowner2751
bb_rcslotrole2751:
  %v11496 = load i64, ptr %slot88, align 8
  store i64 %v11496, ptr %slot2124, align 8
  %v11497 = load i64, ptr %slot2124, align 8
  %v11498 = load i64, ptr %slot2121, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11497, i64 %v11498) nomerge, !dbg !182
  br label %bb_rcslotdone2751
bb_rcslotowner2751:
  %v11499 = load i64, ptr %slot88, align 8
  store i64 %v11499, ptr %slot2125, align 8
  %v11500 = load i64, ptr %slot2125, align 8
  %v11501 = load i64, ptr %slot2121, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11500, i64 %v11501) nomerge, !dbg !182
  br label %bb_rcslotdone2751
bb_rcslotdone2751:
  %v11502 = load i64, ptr %slot65, align 8
  store i64 %v11502, ptr %slot2126, align 8
  %v11503 = load i64, ptr %slot42, align 8
  store i64 %v11503, ptr %slot2127, align 8
  %v11504 = load i64, ptr %slot2127, align 8
  %v11505 = load i64, ptr %slot2126, align 8
  %p11506 = inttoptr i64 %v11504 to ptr
  %p11507 = inttoptr i64 %v11505 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11507, ptr %p11506, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v11508 = load i64, ptr %slot31, align 8
  %p11509 = inttoptr i64 %v11508 to ptr
  store i32 0, ptr %p11509, align 4, !alias.scope !3, !noalias !4
  %v11510 = load i64, ptr %slot20, align 8
  %p11511 = inttoptr i64 %v11510 to ptr
  store i32 2, ptr %p11511, align 4, !alias.scope !3, !noalias !4
  %v11512 = load i64, ptr %slot32, align 8
  %p11513 = inttoptr i64 %v11512 to ptr
  %ld11514 = load i32, ptr %p11513, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11514, ptr %slot2128, align 8
  %v11515 = load i32, ptr %slot2128, align 8
  %v11516 = load i64, ptr %slot20, align 8
  %p11517 = inttoptr i64 %v11516 to ptr
  store i32 %v11515, ptr %p11517, align 4, !alias.scope !3, !noalias !4
  %v11518 = load i64, ptr %slot19, align 8
  %p11519 = inttoptr i64 %v11518 to ptr
  store i32 1, ptr %p11519, align 4, !alias.scope !3, !noalias !4
  %v11520 = load i64, ptr %slot65, align 8
  %v11521 = load i64, ptr %slot68, align 8
  %p11522 = inttoptr i64 %v11521 to ptr
  store i64 %v11520, ptr %p11522, align 8, !alias.scope !3, !noalias !4
  %v11523 = load i64, ptr %slot66, align 8
  %v11524 = load i64, ptr %slot81, align 8
  %p11525 = inttoptr i64 %v11523 to ptr
  %p11526 = inttoptr i64 %v11524 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11526, ptr %p11525, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v11527 = load i64, ptr %slot81, align 8
  %v11528 = load i64, ptr %slot69, align 8
  %p11529 = inttoptr i64 %v11528 to ptr
  store i64 %v11527, ptr %p11529, align 8, !alias.scope !3, !noalias !4
  %v11530 = load i64, ptr %slot68, align 8
  %p11531 = inttoptr i64 %v11530 to ptr
  %ld11532 = load i64, ptr %p11531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11532, ptr %slot2129, align 8
  %v11533 = load i64, ptr %slot23, align 8
  %p11534 = inttoptr i64 %v11533 to ptr
  %ld11535 = load i32, ptr %p11534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11535, ptr %slot2130, align 8
  %v11536 = load i64, ptr %slot24, align 8
  %p11537 = inttoptr i64 %v11536 to ptr
  %ld11538 = load i32, ptr %p11537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11538, ptr %slot2131, align 8
  %v11539 = load i32, ptr %slot2131, align 8
  %op11540 = and i32 %v11539, 24
  store i32 %op11540, ptr %slot2131, align 8
  %v11541 = load i32, ptr %slot2131, align 8
  %cmp11542 = icmp eq i32 %v11541, 0
  %cv11543 = zext i1 %cmp11542 to i32
  store i32 %cv11543, ptr %slot2132, align 8
  %v11544 = load i32, ptr %slot2130, align 8
  %v11545 = load i32, ptr %slot2132, align 8
  %op11546 = and i32 %v11544, %v11545
  store i32 %op11546, ptr %slot2133, align 8
  %v11547 = load i32, ptr %slot2133, align 8
  %cv11548 = zext i32 %v11547 to i64
  %cond11549 = icmp ne i64 %cv11548, 0
  br i1 %cond11549, label %bb_rctake2766, label %bb_rccopy2766
bb_rctake2766:
  %v11550 = load i64, ptr %slot42, align 8
  store i64 %v11550, ptr %slot2134, align 8
  %v11551 = load i64, ptr %slot89, align 8
  store i64 %v11551, ptr %slot2135, align 8
  %v11552 = load i64, ptr %slot88, align 8
  %v11553 = load i64, ptr %slot2134, align 8
  %v11554 = load i64, ptr %slot2129, align 8
  %v11555 = load i64, ptr %slot2135, align 8
  %cv11556 = trunc i64 %v11555 to i32
  %call11557 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v11552, i64 %v11553, i64 %v11554, i32 %cv11556) nomerge, !dbg !184
  store i32 %call11557, ptr %slot2136, align 8
  %v11558 = load i32, ptr %slot2136, align 8
  %cv11559 = zext i32 %v11558 to i64
  %cond11560 = icmp ne i64 %cv11559, 0
  br i1 %cond11560, label %bb_rcsuccess2776, label %bb_rcfailure2776
bb_rcfailure2776:
  %v11561 = load i64, ptr %slot88, align 8
  %p11562 = inttoptr i64 %v11561 to ptr
  %call11563 = call i32 @myl_rc_take_failure(ptr %p11562) nomerge, !dbg !184
  store i32 %call11563, ptr %slot2137, align 8
  %v11564 = load i64, ptr %slot1, align 8
  %p11565 = inttoptr i64 %v11564 to ptr
  %v11566 = load i32, ptr %slot2137, align 8
  %call11567 = call i32 @myl_qbe_rc_status(ptr %p11565, i32 %v11566) nomerge, !dbg !184
  store i32 %call11567, ptr %slot2138, align 8
  br label %bb_failure
bb_rcsuccess2776:
  %v11568 = load i64, ptr %slot23, align 8
  %p11569 = inttoptr i64 %v11568 to ptr
  store i32 0, ptr %p11569, align 4, !alias.scope !3, !noalias !4
  %v11570 = load i64, ptr %slot32, align 8
  %p11571 = inttoptr i64 %v11570 to ptr
  store i32 2, ptr %p11571, align 4, !alias.scope !3, !noalias !4
  %v11572 = load i64, ptr %slot31, align 8
  %p11573 = inttoptr i64 %v11572 to ptr
  store i32 1, ptr %p11573, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2766
bb_rccopy2766:
  %v11574 = load i64, ptr %slot42, align 8
  store i64 %v11574, ptr %slot2139, align 8
  %v11575 = load i64, ptr %slot89, align 8
  store i64 %v11575, ptr %slot2140, align 8
  %v11576 = load i64, ptr %slot88, align 8
  %v11577 = load i64, ptr %slot2139, align 8
  %v11578 = load i64, ptr %slot2129, align 8
  %v11579 = load i64, ptr %slot2140, align 8
  %cv11580 = trunc i64 %v11579 to i32
  %call11581 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v11576, i64 %v11577, i64 %v11578, i32 %cv11580) nomerge, !dbg !184
  store i32 %call11581, ptr %slot2141, align 8
  %v11582 = load i32, ptr %slot2141, align 8
  %cv11583 = zext i32 %v11582 to i64
  %cond11584 = icmp ne i64 %cv11583, 0
  br i1 %cond11584, label %bb_rcsuccess2785, label %bb_rcfailure2785
bb_rcfailure2785:
  %v11585 = load i64, ptr %slot88, align 8
  %p11586 = inttoptr i64 %v11585 to ptr
  %call11587 = call i32 @myl_rc_take_failure(ptr %p11586) nomerge, !dbg !184
  store i32 %call11587, ptr %slot2142, align 8
  %v11588 = load i64, ptr %slot1, align 8
  %p11589 = inttoptr i64 %v11588 to ptr
  %v11590 = load i32, ptr %slot2142, align 8
  %call11591 = call i32 @myl_qbe_rc_status(ptr %p11589, i32 %v11590) nomerge, !dbg !184
  store i32 %call11591, ptr %slot2143, align 8
  br label %bb_failure
bb_rcsuccess2785:
  %v11592 = load i64, ptr %slot32, align 8
  %p11593 = inttoptr i64 %v11592 to ptr
  store i32 2, ptr %p11593, align 4, !alias.scope !3, !noalias !4
  %v11594 = load i64, ptr %slot31, align 8
  %p11595 = inttoptr i64 %v11594 to ptr
  store i32 1, ptr %p11595, align 4, !alias.scope !3, !noalias !4
  %v11596 = load i64, ptr %slot23, align 8
  %p11597 = inttoptr i64 %v11596 to ptr
  %ld11598 = load i32, ptr %p11597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11598, ptr %slot2144, align 8
  %v11599 = load i32, ptr %slot2144, align 8
  %cv11600 = zext i32 %v11599 to i64
  %cond11601 = icmp ne i64 %cv11600, 0
  br i1 %cond11601, label %bb_rcslotdrop2792, label %bb_rcslotdone2792
bb_rcslotdrop2792:
  %v11602 = load i64, ptr %slot23, align 8
  %p11603 = inttoptr i64 %v11602 to ptr
  store i32 0, ptr %p11603, align 4, !alias.scope !3, !noalias !4
  %v11604 = load i64, ptr %slot34, align 8
  store i64 %v11604, ptr %slot2145, align 8
  %v11605 = load i64, ptr %slot24, align 8
  %p11606 = inttoptr i64 %v11605 to ptr
  %ld11607 = load i32, ptr %p11606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11607, ptr %slot2146, align 8
  %v11608 = load i32, ptr %slot2146, align 8
  %op11609 = and i32 %v11608, 28
  store i32 %op11609, ptr %slot2147, align 8
  %v11610 = load i32, ptr %slot2147, align 8
  %cv11611 = zext i32 %v11610 to i64
  %cond11612 = icmp ne i64 %cv11611, 0
  br i1 %cond11612, label %bb_rcslotrole2792, label %bb_rcslotowner2792
bb_rcslotrole2792:
  %v11613 = load i64, ptr %slot88, align 8
  store i64 %v11613, ptr %slot2148, align 8
  %v11614 = load i64, ptr %slot2148, align 8
  %v11615 = load i64, ptr %slot2145, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11614, i64 %v11615) nomerge, !dbg !184
  br label %bb_rcslotdone2792
bb_rcslotowner2792:
  %v11616 = load i64, ptr %slot88, align 8
  store i64 %v11616, ptr %slot2149, align 8
  %v11617 = load i64, ptr %slot2149, align 8
  %v11618 = load i64, ptr %slot2145, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11617, i64 %v11618) nomerge, !dbg !184
  br label %bb_rcslotdone2792
bb_rcslotdone2792:
  br label %bb_rcprepared2766
bb_rcprepared2766:
  %v11619 = load i64, ptr %slot42, align 8
  store i64 %v11619, ptr %slot2150, align 8
  %v11620 = load i64, ptr %slot82, align 8
  store i64 %v11620, ptr %slot2151, align 8
  %v11621 = load i64, ptr %slot2150, align 8
  %v11622 = load i64, ptr %slot2151, align 8
  %p11623 = inttoptr i64 %v11621 to ptr
  %p11624 = inttoptr i64 %v11622 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11624, ptr %p11623, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v11625 = load i64, ptr %slot31, align 8
  %p11626 = inttoptr i64 %v11625 to ptr
  store i32 0, ptr %p11626, align 4, !alias.scope !3, !noalias !4
  %v11627 = load i64, ptr %slot33, align 8
  %p11628 = inttoptr i64 %v11627 to ptr
  store i32 1, ptr %p11628, align 4, !alias.scope !3, !noalias !4
  %v11629 = load i64, ptr %slot89, align 8
  store i64 %v11629, ptr %slot2152, align 8
  %v11630 = load i64, ptr %slot69, align 8
  %p11631 = inttoptr i64 %v11630 to ptr
  %ld11632 = load i64, ptr %p11631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11632, ptr %slot2153, align 8
  %v11633 = load i64, ptr %slot2151, align 8
  %p11635 = inttoptr i64 %v11633 to ptr
  %gep11636 = getelementptr i8, ptr %p11635, i64 0
  %op11634 = ptrtoint ptr %gep11636 to i64
  store i64 %op11634, ptr %slot2154, align 8
  %v11637 = load i64, ptr %slot42, align 8
  store i64 %v11637, ptr %slot2155, align 8
  %v11638 = load i64, ptr %slot69, align 8
  %p11639 = inttoptr i64 %v11638 to ptr
  %ld11640 = load i64, ptr %p11639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11640, ptr %slot2156, align 8
  %v11641 = load i64, ptr %slot25, align 8
  %p11642 = inttoptr i64 %v11641 to ptr
  %ld11643 = load i32, ptr %p11642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11643, ptr %slot2157, align 8
  %v11644 = load i64, ptr %slot26, align 8
  %p11645 = inttoptr i64 %v11644 to ptr
  %ld11646 = load i32, ptr %p11645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11646, ptr %slot2158, align 8
  %v11647 = load i32, ptr %slot2158, align 8
  %op11648 = and i32 %v11647, 24
  store i32 %op11648, ptr %slot2158, align 8
  %v11649 = load i32, ptr %slot2158, align 8
  %cmp11650 = icmp eq i32 %v11649, 0
  %cv11651 = zext i1 %cmp11650 to i32
  store i32 %cv11651, ptr %slot2159, align 8
  %v11652 = load i32, ptr %slot2157, align 8
  %v11653 = load i32, ptr %slot2159, align 8
  %op11654 = and i32 %v11652, %v11653
  store i32 %op11654, ptr %slot2160, align 8
  %v11655 = load i32, ptr %slot2160, align 8
  %cv11656 = zext i32 %v11655 to i64
  %cond11657 = icmp ne i64 %cv11656, 0
  br i1 %cond11657, label %bb_rctake2809, label %bb_rccopy2809
bb_rctake2809:
  %v11658 = load i64, ptr %slot42, align 8
  store i64 %v11658, ptr %slot2161, align 8
  %v11659 = load i64, ptr %slot89, align 8
  store i64 %v11659, ptr %slot2162, align 8
  %v11660 = load i64, ptr %slot2156, align 8
  %v11661 = load i64, ptr %slot2161, align 8
  %op11662 = sub i64 %v11660, %v11661
  store i64 %op11662, ptr %slot2163, align 8
  %v11663 = load i64, ptr %slot2161, align 8
  %v11664 = load i64, ptr %slot2156, align 8
  %op11665 = sub i64 %v11663, %v11664
  store i64 %op11665, ptr %slot2164, align 8
  %v11666 = load i64, ptr %slot2163, align 8
  %cmp11667 = icmp ult i64 %v11666, 48
  %cv11668 = zext i1 %cmp11667 to i32
  store i32 %cv11668, ptr %slot2165, align 8
  %v11669 = load i64, ptr %slot2164, align 8
  %cmp11670 = icmp ult i64 %v11669, 48
  %cv11671 = zext i1 %cmp11670 to i32
  store i32 %cv11671, ptr %slot2166, align 8
  %v11672 = load i32, ptr %slot2165, align 8
  %v11673 = load i32, ptr %slot2166, align 8
  %op11674 = or i32 %v11672, %v11673
  store i32 %op11674, ptr %slot2167, align 8
  %v11675 = load i32, ptr %slot2167, align 8
  %cv11676 = zext i32 %v11675 to i64
  %cond11677 = icmp ne i64 %cv11676, 0
  br i1 %cond11677, label %bb_rcmoveslow2818, label %bb_rcmovecheck2818
bb_rcmovecheck2818:
  %v11678 = load i64, ptr %slot2156, align 8
  %op11679 = add i64 %v11678, 16
  store i64 %op11679, ptr %slot2168, align 8
  %v11680 = load i64, ptr %slot2168, align 8
  %p11681 = inttoptr i64 %v11680 to ptr
  %ld11682 = load i64, ptr %p11681, align 8
  store i64 %ld11682, ptr %slot2169, align 8
  %v11683 = load i64, ptr %slot2169, align 8
  %cmp11684 = icmp ne i64 %v11683, 0
  %cv11685 = zext i1 %cmp11684 to i32
  store i32 %cv11685, ptr %slot2170, align 8
  %v11686 = load i32, ptr %slot2170, align 8
  %cv11687 = zext i32 %v11686 to i64
  %cond11688 = icmp ne i64 %cv11687, 0
  br i1 %cond11688, label %bb_rcmoveheader2826, label %bb_rcmovenext2826
bb_rcmoveheader2826:
  %v11689 = load i64, ptr %slot2169, align 8
  %op11690 = sub i64 %v11689, 16
  store i64 %op11690, ptr %slot2171, align 8
  %v11691 = load i64, ptr %slot2169, align 8
  %p11692 = inttoptr i64 %v11691 to ptr
  %rgep11693 = getelementptr i8, ptr %p11692, i64 -16
  %ld11694 = load i64, ptr %rgep11693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11694, ptr %slot2172, align 8
  %v11695 = load i64, ptr %slot2172, align 8
  %op11696 = and i64 %v11695, 5764607523034234881
  store i64 %op11696, ptr %slot2173, align 8
  %v11697 = load i64, ptr %slot2173, align 8
  %cmp11698 = icmp ne i64 %v11697, 0
  %cv11699 = zext i1 %cmp11698 to i32
  store i32 %cv11699, ptr %slot2174, align 8
  %v11700 = load i32, ptr %slot2174, align 8
  %cv11701 = zext i32 %v11700 to i64
  %cond11702 = icmp ne i64 %cv11701, 0
  br i1 %cond11702, label %bb_rcmoveslow2818, label %bb_rcmovenext2826
bb_rcmovenext2826:
  %v11703 = load i64, ptr %slot2156, align 8
  %op11704 = add i64 %v11703, 24
  store i64 %op11704, ptr %slot2175, align 8
  %v11705 = load i64, ptr %slot2175, align 8
  %p11706 = inttoptr i64 %v11705 to ptr
  %ld11707 = load i64, ptr %p11706, align 8
  store i64 %ld11707, ptr %slot2176, align 8
  %v11708 = load i64, ptr %slot2176, align 8
  %cmp11709 = icmp ne i64 %v11708, 0
  %cv11710 = zext i1 %cmp11709 to i32
  store i32 %cv11710, ptr %slot2177, align 8
  %v11711 = load i32, ptr %slot2177, align 8
  %cv11712 = zext i32 %v11711 to i64
  %cond11713 = icmp ne i64 %cv11712, 0
  br i1 %cond11713, label %bb_rcmoveheader2834, label %bb_rcmovenext2834
bb_rcmoveheader2834:
  %v11714 = load i64, ptr %slot2176, align 8
  %op11715 = sub i64 %v11714, 16
  store i64 %op11715, ptr %slot2178, align 8
  %v11716 = load i64, ptr %slot2176, align 8
  %p11717 = inttoptr i64 %v11716 to ptr
  %rgep11718 = getelementptr i8, ptr %p11717, i64 -16
  %ld11719 = load i64, ptr %rgep11718, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11719, ptr %slot2179, align 8
  %v11720 = load i64, ptr %slot2179, align 8
  %op11721 = and i64 %v11720, 5764607523034234881
  store i64 %op11721, ptr %slot2180, align 8
  %v11722 = load i64, ptr %slot2180, align 8
  %cmp11723 = icmp ne i64 %v11722, 0
  %cv11724 = zext i1 %cmp11723 to i32
  store i32 %cv11724, ptr %slot2181, align 8
  %v11725 = load i32, ptr %slot2181, align 8
  %cv11726 = zext i32 %v11725 to i64
  %cond11727 = icmp ne i64 %cv11726, 0
  br i1 %cond11727, label %bb_rcmoveslow2818, label %bb_rcmovenext2834
bb_rcmovenext2834:
  %v11728 = load i64, ptr %slot2156, align 8
  %op11729 = add i64 %v11728, 32
  store i64 %op11729, ptr %slot2182, align 8
  %v11730 = load i64, ptr %slot2182, align 8
  %p11731 = inttoptr i64 %v11730 to ptr
  %ld11732 = load i64, ptr %p11731, align 8
  store i64 %ld11732, ptr %slot2183, align 8
  %v11733 = load i64, ptr %slot2183, align 8
  %cmp11734 = icmp ne i64 %v11733, 0
  %cv11735 = zext i1 %cmp11734 to i32
  store i32 %cv11735, ptr %slot2184, align 8
  %v11736 = load i32, ptr %slot2184, align 8
  %cv11737 = zext i32 %v11736 to i64
  %cond11738 = icmp ne i64 %cv11737, 0
  br i1 %cond11738, label %bb_rcmoveheader2842, label %bb_rcmovenext2842
bb_rcmoveheader2842:
  %v11739 = load i64, ptr %slot2183, align 8
  %op11740 = sub i64 %v11739, 16
  store i64 %op11740, ptr %slot2185, align 8
  %v11741 = load i64, ptr %slot2183, align 8
  %p11742 = inttoptr i64 %v11741 to ptr
  %rgep11743 = getelementptr i8, ptr %p11742, i64 -16
  %ld11744 = load i64, ptr %rgep11743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11744, ptr %slot2186, align 8
  %v11745 = load i64, ptr %slot2186, align 8
  %op11746 = and i64 %v11745, 5764607523034234881
  store i64 %op11746, ptr %slot2187, align 8
  %v11747 = load i64, ptr %slot2187, align 8
  %cmp11748 = icmp ne i64 %v11747, 0
  %cv11749 = zext i1 %cmp11748 to i32
  store i32 %cv11749, ptr %slot2188, align 8
  %v11750 = load i32, ptr %slot2188, align 8
  %cv11751 = zext i32 %v11750 to i64
  %cond11752 = icmp ne i64 %cv11751, 0
  br i1 %cond11752, label %bb_rcmoveslow2818, label %bb_rcmovenext2842
bb_rcmovenext2842:
  %v11753 = load i64, ptr %slot2156, align 8
  %v11754 = load i64, ptr %slot2161, align 8
  %p11755 = inttoptr i64 %v11753 to ptr
  %p11756 = inttoptr i64 %v11754 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11756, ptr %p11755, i64 48, i1 false)
  %v11757 = load i64, ptr %slot2156, align 8
  %p11758 = inttoptr i64 %v11757 to ptr
  store i64 0, ptr %p11758, align 8
  %v11759 = load i64, ptr %slot2156, align 8
  %op11760 = add i64 %v11759, 8
  store i64 %op11760, ptr %slot2189, align 8
  %v11761 = load i64, ptr %slot2189, align 8
  %p11762 = inttoptr i64 %v11761 to ptr
  store i64 0, ptr %p11762, align 8
  %v11763 = load i64, ptr %slot2156, align 8
  %op11764 = add i64 %v11763, 16
  store i64 %op11764, ptr %slot2190, align 8
  %v11765 = load i64, ptr %slot2190, align 8
  %p11766 = inttoptr i64 %v11765 to ptr
  store i64 0, ptr %p11766, align 8
  %v11767 = load i64, ptr %slot2156, align 8
  %op11768 = add i64 %v11767, 24
  store i64 %op11768, ptr %slot2191, align 8
  %v11769 = load i64, ptr %slot2191, align 8
  %p11770 = inttoptr i64 %v11769 to ptr
  store i64 0, ptr %p11770, align 8
  %v11771 = load i64, ptr %slot2156, align 8
  %op11772 = add i64 %v11771, 32
  store i64 %op11772, ptr %slot2192, align 8
  %v11773 = load i64, ptr %slot2192, align 8
  %p11774 = inttoptr i64 %v11773 to ptr
  store i64 0, ptr %p11774, align 8
  %v11775 = load i64, ptr %slot2156, align 8
  %op11776 = add i64 %v11775, 40
  store i64 %op11776, ptr %slot2193, align 8
  %v11777 = load i64, ptr %slot2193, align 8
  %p11778 = inttoptr i64 %v11777 to ptr
  store i64 0, ptr %p11778, align 8
  br label %bb_rcmoved2818
bb_rcmoveslow2818:
  %v11779 = load i64, ptr %slot88, align 8
  %v11780 = load i64, ptr %slot2161, align 8
  %v11781 = load i64, ptr %slot2156, align 8
  %v11782 = load i64, ptr %slot2162, align 8
  %cv11783 = trunc i64 %v11782 to i32
  %call11784 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v11779, i64 %v11780, i64 %v11781, i32 %cv11783) nomerge, !dbg !184
  store i32 %call11784, ptr %slot2194, align 8
  %v11785 = load i32, ptr %slot2194, align 8
  %cv11786 = zext i32 %v11785 to i64
  %cond11787 = icmp ne i64 %cv11786, 0
  br i1 %cond11787, label %bb_rcsuccess2854, label %bb_rcfailure2854
bb_rcfailure2854:
  %v11788 = load i64, ptr %slot88, align 8
  %p11789 = inttoptr i64 %v11788 to ptr
  %call11790 = call i32 @myl_rc_take_failure(ptr %p11789) nomerge, !dbg !184
  store i32 %call11790, ptr %slot2195, align 8
  %v11791 = load i64, ptr %slot1, align 8
  %p11792 = inttoptr i64 %v11791 to ptr
  %v11793 = load i32, ptr %slot2195, align 8
  %call11794 = call i32 @myl_qbe_rc_status(ptr %p11792, i32 %v11793) nomerge, !dbg !184
  store i32 %call11794, ptr %slot2196, align 8
  br label %bb_failure
bb_rcsuccess2854:
  br label %bb_rcmoved2818
bb_rcmoved2818:
  %v11795 = load i64, ptr %slot25, align 8
  %p11796 = inttoptr i64 %v11795 to ptr
  store i32 0, ptr %p11796, align 4, !alias.scope !3, !noalias !4
  %v11797 = load i64, ptr %slot32, align 8
  %p11798 = inttoptr i64 %v11797 to ptr
  store i32 2, ptr %p11798, align 4, !alias.scope !3, !noalias !4
  %v11799 = load i64, ptr %slot31, align 8
  %p11800 = inttoptr i64 %v11799 to ptr
  store i32 1, ptr %p11800, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2809
bb_rccopy2809:
  %v11801 = load i64, ptr %slot42, align 8
  store i64 %v11801, ptr %slot2197, align 8
  %v11802 = load i64, ptr %slot89, align 8
  store i64 %v11802, ptr %slot2198, align 8
  %v11803 = load i64, ptr %slot88, align 8
  %v11804 = load i64, ptr %slot2197, align 8
  %v11805 = load i64, ptr %slot2156, align 8
  %v11806 = load i64, ptr %slot2198, align 8
  %cv11807 = trunc i64 %v11806 to i32
  %call11808 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v11803, i64 %v11804, i64 %v11805, i32 %cv11807) nomerge, !dbg !184
  store i32 %call11808, ptr %slot2199, align 8
  %v11809 = load i32, ptr %slot2199, align 8
  %cv11810 = zext i32 %v11809 to i64
  %cond11811 = icmp ne i64 %cv11810, 0
  br i1 %cond11811, label %bb_rcsuccess2863, label %bb_rcfailure2863
bb_rcfailure2863:
  %v11812 = load i64, ptr %slot88, align 8
  %p11813 = inttoptr i64 %v11812 to ptr
  %call11814 = call i32 @myl_rc_take_failure(ptr %p11813) nomerge, !dbg !184
  store i32 %call11814, ptr %slot2200, align 8
  %v11815 = load i64, ptr %slot1, align 8
  %p11816 = inttoptr i64 %v11815 to ptr
  %v11817 = load i32, ptr %slot2200, align 8
  %call11818 = call i32 @myl_qbe_rc_status(ptr %p11816, i32 %v11817) nomerge, !dbg !184
  store i32 %call11818, ptr %slot2201, align 8
  br label %bb_failure
bb_rcsuccess2863:
  %v11819 = load i64, ptr %slot32, align 8
  %p11820 = inttoptr i64 %v11819 to ptr
  store i32 2, ptr %p11820, align 4, !alias.scope !3, !noalias !4
  %v11821 = load i64, ptr %slot31, align 8
  %p11822 = inttoptr i64 %v11821 to ptr
  store i32 1, ptr %p11822, align 4, !alias.scope !3, !noalias !4
  %v11823 = load i64, ptr %slot25, align 8
  %p11824 = inttoptr i64 %v11823 to ptr
  %ld11825 = load i32, ptr %p11824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11825, ptr %slot2202, align 8
  %v11826 = load i32, ptr %slot2202, align 8
  %cv11827 = zext i32 %v11826 to i64
  %cond11828 = icmp ne i64 %cv11827, 0
  br i1 %cond11828, label %bb_rcslotdrop2870, label %bb_rcslotdone2870
bb_rcslotdrop2870:
  %v11829 = load i64, ptr %slot25, align 8
  %p11830 = inttoptr i64 %v11829 to ptr
  store i32 0, ptr %p11830, align 4, !alias.scope !3, !noalias !4
  %v11831 = load i64, ptr %slot35, align 8
  store i64 %v11831, ptr %slot2203, align 8
  %v11832 = load i64, ptr %slot26, align 8
  %p11833 = inttoptr i64 %v11832 to ptr
  %ld11834 = load i32, ptr %p11833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11834, ptr %slot2204, align 8
  %v11835 = load i32, ptr %slot2204, align 8
  %op11836 = and i32 %v11835, 28
  store i32 %op11836, ptr %slot2205, align 8
  %v11837 = load i32, ptr %slot2205, align 8
  %cv11838 = zext i32 %v11837 to i64
  %cond11839 = icmp ne i64 %cv11838, 0
  br i1 %cond11839, label %bb_rcslotrole2870, label %bb_rcslotowner2870
bb_rcslotrole2870:
  %v11840 = load i64, ptr %slot88, align 8
  store i64 %v11840, ptr %slot2206, align 8
  %v11841 = load i64, ptr %slot2206, align 8
  %v11842 = load i64, ptr %slot2203, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v11841, i64 %v11842) nomerge, !dbg !184
  br label %bb_rcslotdone2870
bb_rcslotowner2870:
  %v11843 = load i64, ptr %slot88, align 8
  store i64 %v11843, ptr %slot2207, align 8
  %v11844 = load i64, ptr %slot2207, align 8
  %v11845 = load i64, ptr %slot2203, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v11844, i64 %v11845) nomerge, !dbg !184
  br label %bb_rcslotdone2870
bb_rcslotdone2870:
  br label %bb_rcprepared2809
bb_rcprepared2809:
  %v11846 = load i64, ptr %slot42, align 8
  store i64 %v11846, ptr %slot2208, align 8
  %v11847 = load i64, ptr %slot2208, align 8
  %v11848 = load i64, ptr %slot2155, align 8
  %p11849 = inttoptr i64 %v11847 to ptr
  %p11850 = inttoptr i64 %v11848 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11850, ptr %p11849, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v11851 = load i64, ptr %slot31, align 8
  %p11852 = inttoptr i64 %v11851 to ptr
  store i32 0, ptr %p11852, align 4, !alias.scope !3, !noalias !4
  %v11853 = load i64, ptr %slot32, align 8
  %p11854 = inttoptr i64 %v11853 to ptr
  store i32 2, ptr %p11854, align 4, !alias.scope !3, !noalias !4
  %v11855 = load i64, ptr %slot31, align 8
  %p11856 = inttoptr i64 %v11855 to ptr
  store i32 1, ptr %p11856, align 4, !alias.scope !3, !noalias !4
  %v11857 = load i64, ptr %slot88, align 8
  store i64 %v11857, ptr %slot2209, align 8
  %v11858 = load i64, ptr %slot2209, align 8
  %v11859 = load i64, ptr %slot2154, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v11858, i64 %v11859) nomerge, !dbg !184
  %v11860 = load i64, ptr %slot2155, align 8
  %v11861 = load i64, ptr %slot2154, align 8
  %p11862 = inttoptr i64 %v11860 to ptr
  %p11863 = inttoptr i64 %v11861 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11863, ptr %p11862, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v11864 = load i64, ptr %slot31, align 8
  %p11865 = inttoptr i64 %v11864 to ptr
  store i32 0, ptr %p11865, align 4, !alias.scope !3, !noalias !4
  %v11866 = load i64, ptr %slot2151, align 8
  %v11867 = load i64, ptr %slot68, align 8
  %p11868 = inttoptr i64 %v11867 to ptr
  store i64 %v11866, ptr %p11868, align 8, !alias.scope !3, !noalias !4
  %v11869 = load i64, ptr %slot68, align 8
  %p11870 = inttoptr i64 %v11869 to ptr
  %ld11871 = load i64, ptr %p11870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11871, ptr %slot2210, align 8
  %v11872 = load i64, ptr %slot42, align 8
  store i64 %v11872, ptr %slot2211, align 8
  %v11873 = load i64, ptr %slot2210, align 8
  %v11874 = load i64, ptr %slot2211, align 8
  %p11875 = inttoptr i64 %v11873 to ptr
  %p11876 = inttoptr i64 %v11874 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11876, ptr %p11875, i64 88, i1 false)
  %v11877 = load i64, ptr %slot32, align 8
  %p11878 = inttoptr i64 %v11877 to ptr
  store i32 2, ptr %p11878, align 4, !alias.scope !3, !noalias !4
  %v11879 = load i64, ptr %slot31, align 8
  %p11880 = inttoptr i64 %v11879 to ptr
  store i32 1, ptr %p11880, align 4, !alias.scope !3, !noalias !4
  %v11881 = load i64, ptr %slot23, align 8
  %p11882 = inttoptr i64 %v11881 to ptr
  %ld11883 = load i32, ptr %p11882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11883, ptr %slot2212, align 8
  %v11884 = load i32, ptr %slot2212, align 8
  %cv11885 = zext i32 %v11884 to i64
  %cond11886 = icmp ne i64 %cv11885, 0
  br i1 %cond11886, label %bb_rcslotdrop2889, label %bb_rcslotdone2889
bb_rcslotdrop2889:
  %v11887 = load i64, ptr %slot23, align 8
  %p11888 = inttoptr i64 %v11887 to ptr
  store i32 0, ptr %p11888, align 4, !alias.scope !3, !noalias !4
  %v11889 = load i64, ptr %slot34, align 8
  store i64 %v11889, ptr %slot2213, align 8
  %v11890 = load i64, ptr %slot24, align 8
  %p11891 = inttoptr i64 %v11890 to ptr
  %ld11892 = load i32, ptr %p11891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11892, ptr %slot2214, align 8
  %v11893 = load i32, ptr %slot2214, align 8
  %op11894 = and i32 %v11893, 28
  store i32 %op11894, ptr %slot2215, align 8
  %v11895 = load i32, ptr %slot2215, align 8
  %cv11896 = zext i32 %v11895 to i64
  %cond11897 = icmp ne i64 %cv11896, 0
  br i1 %cond11897, label %bb_rcslotrole2889, label %bb_rcslotowner2889
bb_rcslotrole2889:
  %v11898 = load i64, ptr %slot88, align 8
  store i64 %v11898, ptr %slot2216, align 8
  %v11899 = load i64, ptr %slot2216, align 8
  %v11900 = load i64, ptr %slot2213, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v11899, i64 %v11900) nomerge, !dbg !184
  br label %bb_rcslotdone2889
bb_rcslotowner2889:
  %v11901 = load i64, ptr %slot88, align 8
  store i64 %v11901, ptr %slot2217, align 8
  %v11902 = load i64, ptr %slot2217, align 8
  %v11903 = load i64, ptr %slot2213, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v11902, i64 %v11903) nomerge, !dbg !184
  br label %bb_rcslotdone2889
bb_rcslotdone2889:
  %v11904 = load i64, ptr %slot25, align 8
  %p11905 = inttoptr i64 %v11904 to ptr
  %ld11906 = load i32, ptr %p11905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11906, ptr %slot2218, align 8
  %v11907 = load i32, ptr %slot2218, align 8
  %cv11908 = zext i32 %v11907 to i64
  %cond11909 = icmp ne i64 %cv11908, 0
  br i1 %cond11909, label %bb_rcslotdrop2898, label %bb_rcslotdone2898
bb_rcslotdrop2898:
  %v11910 = load i64, ptr %slot25, align 8
  %p11911 = inttoptr i64 %v11910 to ptr
  store i32 0, ptr %p11911, align 4, !alias.scope !3, !noalias !4
  %v11912 = load i64, ptr %slot35, align 8
  store i64 %v11912, ptr %slot2219, align 8
  %v11913 = load i64, ptr %slot26, align 8
  %p11914 = inttoptr i64 %v11913 to ptr
  %ld11915 = load i32, ptr %p11914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11915, ptr %slot2220, align 8
  %v11916 = load i32, ptr %slot2220, align 8
  %op11917 = and i32 %v11916, 28
  store i32 %op11917, ptr %slot2221, align 8
  %v11918 = load i32, ptr %slot2221, align 8
  %cv11919 = zext i32 %v11918 to i64
  %cond11920 = icmp ne i64 %cv11919, 0
  br i1 %cond11920, label %bb_rcslotrole2898, label %bb_rcslotowner2898
bb_rcslotrole2898:
  %v11921 = load i64, ptr %slot88, align 8
  store i64 %v11921, ptr %slot2222, align 8
  %v11922 = load i64, ptr %slot2222, align 8
  %v11923 = load i64, ptr %slot2219, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v11922, i64 %v11923) nomerge, !dbg !184
  br label %bb_rcslotdone2898
bb_rcslotowner2898:
  %v11924 = load i64, ptr %slot88, align 8
  store i64 %v11924, ptr %slot2223, align 8
  %v11925 = load i64, ptr %slot2223, align 8
  %v11926 = load i64, ptr %slot2219, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v11925, i64 %v11926) nomerge, !dbg !184
  br label %bb_rcslotdone2898
bb_rcslotdone2898:
  %v11927 = load i64, ptr %slot34, align 8
  store i64 %v11927, ptr %slot2224, align 8
  %v11928 = load i64, ptr %slot42, align 8
  store i64 %v11928, ptr %slot2225, align 8
  %v11929 = load i64, ptr %slot2225, align 8
  %v11930 = load i64, ptr %slot2224, align 8
  %p11931 = inttoptr i64 %v11929 to ptr
  %p11932 = inttoptr i64 %v11930 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11932, ptr %p11931, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v11933 = load i64, ptr %slot24, align 8
  %p11934 = inttoptr i64 %v11933 to ptr
  store i32 2, ptr %p11934, align 4, !alias.scope !3, !noalias !4
  %v11935 = load i64, ptr %slot32, align 8
  %p11936 = inttoptr i64 %v11935 to ptr
  %ld11937 = load i32, ptr %p11936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11937, ptr %slot2226, align 8
  %v11938 = load i32, ptr %slot2226, align 8
  %v11939 = load i64, ptr %slot24, align 8
  %p11940 = inttoptr i64 %v11939 to ptr
  store i32 %v11938, ptr %p11940, align 4, !alias.scope !3, !noalias !4
  %v11941 = load i64, ptr %slot31, align 8
  %p11942 = inttoptr i64 %v11941 to ptr
  store i32 0, ptr %p11942, align 4, !alias.scope !3, !noalias !4
  %v11943 = load i64, ptr %slot23, align 8
  %p11944 = inttoptr i64 %v11943 to ptr
  store i32 1, ptr %p11944, align 4, !alias.scope !3, !noalias !4
  %v11945 = load i64, ptr %slot2224, align 8
  %v11946 = load i64, ptr %slot68, align 8
  %p11947 = inttoptr i64 %v11946 to ptr
  store i64 %v11945, ptr %p11947, align 8, !alias.scope !3, !noalias !4
  %v11948 = load i64, ptr %slot68, align 8
  %p11949 = inttoptr i64 %v11948 to ptr
  %ld11950 = load i64, ptr %p11949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11950, ptr %slot2227, align 8
  %v11951 = load i64, ptr %slot23, align 8
  %p11952 = inttoptr i64 %v11951 to ptr
  %ld11953 = load i32, ptr %p11952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11953, ptr %slot2228, align 8
  %v11954 = load i64, ptr %slot24, align 8
  %p11955 = inttoptr i64 %v11954 to ptr
  %ld11956 = load i32, ptr %p11955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11956, ptr %slot2229, align 8
  %v11957 = load i32, ptr %slot2229, align 8
  %op11958 = and i32 %v11957, 24
  store i32 %op11958, ptr %slot2229, align 8
  %v11959 = load i32, ptr %slot2229, align 8
  %cmp11960 = icmp eq i32 %v11959, 0
  %cv11961 = zext i1 %cmp11960 to i32
  store i32 %cv11961, ptr %slot2230, align 8
  %v11962 = load i32, ptr %slot2228, align 8
  %v11963 = load i32, ptr %slot2230, align 8
  %op11964 = and i32 %v11962, %v11963
  store i32 %op11964, ptr %slot2231, align 8
  %v11965 = load i32, ptr %slot2231, align 8
  %cv11966 = zext i32 %v11965 to i64
  %cond11967 = icmp ne i64 %cv11966, 0
  br i1 %cond11967, label %bb_rctake2914, label %bb_rccopy2914
bb_rctake2914:
  %v11968 = load i64, ptr %slot42, align 8
  store i64 %v11968, ptr %slot2232, align 8
  %v11969 = load i64, ptr %slot89, align 8
  store i64 %v11969, ptr %slot2233, align 8
  %v11970 = load i64, ptr %slot88, align 8
  %v11971 = load i64, ptr %slot2232, align 8
  %v11972 = load i64, ptr %slot2227, align 8
  %v11973 = load i64, ptr %slot2233, align 8
  %cv11974 = trunc i64 %v11973 to i32
  %call11975 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v11970, i64 %v11971, i64 %v11972, i32 %cv11974) nomerge, !dbg !186
  store i32 %call11975, ptr %slot2234, align 8
  %v11976 = load i32, ptr %slot2234, align 8
  %cv11977 = zext i32 %v11976 to i64
  %cond11978 = icmp ne i64 %cv11977, 0
  br i1 %cond11978, label %bb_rcsuccess2924, label %bb_rcfailure2924
bb_rcfailure2924:
  %v11979 = load i64, ptr %slot88, align 8
  %p11980 = inttoptr i64 %v11979 to ptr
  %call11981 = call i32 @myl_rc_take_failure(ptr %p11980) nomerge, !dbg !186
  store i32 %call11981, ptr %slot2235, align 8
  %v11982 = load i64, ptr %slot1, align 8
  %p11983 = inttoptr i64 %v11982 to ptr
  %v11984 = load i32, ptr %slot2235, align 8
  %call11985 = call i32 @myl_qbe_rc_status(ptr %p11983, i32 %v11984) nomerge, !dbg !186
  store i32 %call11985, ptr %slot2236, align 8
  br label %bb_failure
bb_rcsuccess2924:
  %v11986 = load i64, ptr %slot23, align 8
  %p11987 = inttoptr i64 %v11986 to ptr
  store i32 0, ptr %p11987, align 4, !alias.scope !3, !noalias !4
  %v11988 = load i64, ptr %slot32, align 8
  %p11989 = inttoptr i64 %v11988 to ptr
  store i32 2, ptr %p11989, align 4, !alias.scope !3, !noalias !4
  %v11990 = load i64, ptr %slot31, align 8
  %p11991 = inttoptr i64 %v11990 to ptr
  store i32 1, ptr %p11991, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2914
bb_rccopy2914:
  %v11992 = load i64, ptr %slot42, align 8
  store i64 %v11992, ptr %slot2237, align 8
  %v11993 = load i64, ptr %slot89, align 8
  store i64 %v11993, ptr %slot2238, align 8
  %v11994 = load i64, ptr %slot88, align 8
  %v11995 = load i64, ptr %slot2237, align 8
  %v11996 = load i64, ptr %slot2227, align 8
  %v11997 = load i64, ptr %slot2238, align 8
  %cv11998 = trunc i64 %v11997 to i32
  %call11999 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v11994, i64 %v11995, i64 %v11996, i32 %cv11998) nomerge, !dbg !186
  store i32 %call11999, ptr %slot2239, align 8
  %v12000 = load i32, ptr %slot2239, align 8
  %cv12001 = zext i32 %v12000 to i64
  %cond12002 = icmp ne i64 %cv12001, 0
  br i1 %cond12002, label %bb_rcsuccess2933, label %bb_rcfailure2933
bb_rcfailure2933:
  %v12003 = load i64, ptr %slot88, align 8
  %p12004 = inttoptr i64 %v12003 to ptr
  %call12005 = call i32 @myl_rc_take_failure(ptr %p12004) nomerge, !dbg !186
  store i32 %call12005, ptr %slot2240, align 8
  %v12006 = load i64, ptr %slot1, align 8
  %p12007 = inttoptr i64 %v12006 to ptr
  %v12008 = load i32, ptr %slot2240, align 8
  %call12009 = call i32 @myl_qbe_rc_status(ptr %p12007, i32 %v12008) nomerge, !dbg !186
  store i32 %call12009, ptr %slot2241, align 8
  br label %bb_failure
bb_rcsuccess2933:
  %v12010 = load i64, ptr %slot32, align 8
  %p12011 = inttoptr i64 %v12010 to ptr
  store i32 2, ptr %p12011, align 4, !alias.scope !3, !noalias !4
  %v12012 = load i64, ptr %slot31, align 8
  %p12013 = inttoptr i64 %v12012 to ptr
  store i32 1, ptr %p12013, align 4, !alias.scope !3, !noalias !4
  %v12014 = load i64, ptr %slot23, align 8
  %p12015 = inttoptr i64 %v12014 to ptr
  %ld12016 = load i32, ptr %p12015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12016, ptr %slot2242, align 8
  %v12017 = load i32, ptr %slot2242, align 8
  %cv12018 = zext i32 %v12017 to i64
  %cond12019 = icmp ne i64 %cv12018, 0
  br i1 %cond12019, label %bb_rcslotdrop2940, label %bb_rcslotdone2940
bb_rcslotdrop2940:
  %v12020 = load i64, ptr %slot23, align 8
  %p12021 = inttoptr i64 %v12020 to ptr
  store i32 0, ptr %p12021, align 4, !alias.scope !3, !noalias !4
  %v12022 = load i64, ptr %slot34, align 8
  store i64 %v12022, ptr %slot2243, align 8
  %v12023 = load i64, ptr %slot24, align 8
  %p12024 = inttoptr i64 %v12023 to ptr
  %ld12025 = load i32, ptr %p12024, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12025, ptr %slot2244, align 8
  %v12026 = load i32, ptr %slot2244, align 8
  %op12027 = and i32 %v12026, 28
  store i32 %op12027, ptr %slot2245, align 8
  %v12028 = load i32, ptr %slot2245, align 8
  %cv12029 = zext i32 %v12028 to i64
  %cond12030 = icmp ne i64 %cv12029, 0
  br i1 %cond12030, label %bb_rcslotrole2940, label %bb_rcslotowner2940
bb_rcslotrole2940:
  %v12031 = load i64, ptr %slot88, align 8
  store i64 %v12031, ptr %slot2246, align 8
  %v12032 = load i64, ptr %slot2246, align 8
  %v12033 = load i64, ptr %slot2243, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v12032, i64 %v12033) nomerge, !dbg !186
  br label %bb_rcslotdone2940
bb_rcslotowner2940:
  %v12034 = load i64, ptr %slot88, align 8
  store i64 %v12034, ptr %slot2247, align 8
  %v12035 = load i64, ptr %slot2247, align 8
  %v12036 = load i64, ptr %slot2243, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v12035, i64 %v12036) nomerge, !dbg !186
  br label %bb_rcslotdone2940
bb_rcslotdone2940:
  br label %bb_rcprepared2914
bb_rcprepared2914:
  %v12037 = load i64, ptr %slot13, align 8
  %p12038 = inttoptr i64 %v12037 to ptr
  %ld12039 = load i32, ptr %p12038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12039, ptr %slot2248, align 8
  %v12040 = load i32, ptr %slot2248, align 8
  %cv12041 = zext i32 %v12040 to i64
  %cond12042 = icmp ne i64 %cv12041, 0
  br i1 %cond12042, label %bb_rcslotdrop2950, label %bb_rcslotdone2950
bb_rcslotdrop2950:
  %v12043 = load i64, ptr %slot13, align 8
  %p12044 = inttoptr i64 %v12043 to ptr
  store i32 0, ptr %p12044, align 4, !alias.scope !3, !noalias !4
  %v12045 = load i64, ptr %slot59, align 8
  store i64 %v12045, ptr %slot2249, align 8
  %v12046 = load i64, ptr %slot14, align 8
  %p12047 = inttoptr i64 %v12046 to ptr
  %ld12048 = load i32, ptr %p12047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12048, ptr %slot2250, align 8
  %v12049 = load i32, ptr %slot2250, align 8
  %op12050 = and i32 %v12049, 28
  store i32 %op12050, ptr %slot2251, align 8
  %v12051 = load i32, ptr %slot2251, align 8
  %cv12052 = zext i32 %v12051 to i64
  %cond12053 = icmp ne i64 %cv12052, 0
  br i1 %cond12053, label %bb_rcslotrole2950, label %bb_rcslotowner2950
bb_rcslotrole2950:
  %v12054 = load i64, ptr %slot88, align 8
  store i64 %v12054, ptr %slot2252, align 8
  %v12055 = load i64, ptr %slot2252, align 8
  %v12056 = load i64, ptr %slot2249, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v12055, i64 %v12056) nomerge, !dbg !186
  br label %bb_rcslotdone2950
bb_rcslotowner2950:
  %v12057 = load i64, ptr %slot88, align 8
  store i64 %v12057, ptr %slot2253, align 8
  %v12058 = load i64, ptr %slot2253, align 8
  %v12059 = load i64, ptr %slot2249, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v12058, i64 %v12059) nomerge, !dbg !186
  br label %bb_rcslotdone2950
bb_rcslotdone2950:
  %v12060 = load i64, ptr %slot59, align 8
  store i64 %v12060, ptr %slot2254, align 8
  %v12061 = load i64, ptr %slot42, align 8
  store i64 %v12061, ptr %slot2255, align 8
  %v12062 = load i64, ptr %slot2255, align 8
  %v12063 = load i64, ptr %slot2254, align 8
  %p12064 = inttoptr i64 %v12062 to ptr
  %p12065 = inttoptr i64 %v12063 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12065, ptr %p12064, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v12066 = load i64, ptr %slot31, align 8
  %p12067 = inttoptr i64 %v12066 to ptr
  store i32 0, ptr %p12067, align 4, !alias.scope !3, !noalias !4
  %v12068 = load i64, ptr %slot14, align 8
  %p12069 = inttoptr i64 %v12068 to ptr
  store i32 2, ptr %p12069, align 4, !alias.scope !3, !noalias !4
  %v12070 = load i64, ptr %slot32, align 8
  %p12071 = inttoptr i64 %v12070 to ptr
  %ld12072 = load i32, ptr %p12071, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12072, ptr %slot2256, align 8
  %v12073 = load i32, ptr %slot2256, align 8
  %v12074 = load i64, ptr %slot14, align 8
  %p12075 = inttoptr i64 %v12074 to ptr
  store i32 %v12073, ptr %p12075, align 4, !alias.scope !3, !noalias !4
  %v12076 = load i64, ptr %slot13, align 8
  %p12077 = inttoptr i64 %v12076 to ptr
  store i32 1, ptr %p12077, align 4, !alias.scope !3, !noalias !4
  %v12078 = load i64, ptr %slot68, align 8
  %p12079 = inttoptr i64 %v12078 to ptr
  store i64 0, ptr %p12079, align 8, !alias.scope !3, !noalias !4
  %v12080 = load i64, ptr %slot51, align 8
  %p12081 = inttoptr i64 %v12080 to ptr
  %ld12082 = load i64, ptr %p12081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12082, ptr %slot2257, align 8
  %v12083 = load i64, ptr %slot2257, align 8
  %v12084 = load i64, ptr %slot68, align 8
  %p12085 = inttoptr i64 %v12084 to ptr
  store i64 %v12083, ptr %p12085, align 8, !alias.scope !3, !noalias !4
  %v12086 = load i64, ptr %slot51, align 8
  %p12087 = inttoptr i64 %v12086 to ptr
  %ld12088 = load i64, ptr %p12087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12088, ptr %slot2258, align 8
  %v12089 = load i64, ptr %slot2258, align 8
  %v12090 = load i64, ptr %slot83, align 8
  %p12091 = inttoptr i64 %v12089 to ptr
  %p12092 = inttoptr i64 %v12090 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12092, ptr %p12091, i64 392, i1 false), !alias.scope !10000000
  %v12093 = load i64, ptr %slot83, align 8
  %v12094 = load i64, ptr %slot69, align 8
  %p12095 = inttoptr i64 %v12094 to ptr
  store i64 %v12093, ptr %p12095, align 8, !alias.scope !3, !noalias !4
  %v12096 = load i64, ptr %slot69, align 8
  %p12097 = inttoptr i64 %v12096 to ptr
  %ld12098 = load i64, ptr %p12097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12098, ptr %slot2259, align 8
  %v12099 = load i64, ptr %slot2259, align 8
  %op12100 = add i64 %v12099, 376
  store i64 %op12100, ptr %slot2260, align 8
  %v12101 = load i64, ptr %slot2260, align 8
  %p12102 = inttoptr i64 %v12101 to ptr
  %ld12103 = load i64, ptr %p12102, align 8
  store i64 %ld12103, ptr %slot2261, align 8
  %v12104 = load i64, ptr %slot2261, align 8
  %v12105 = load i64, ptr %slot69, align 8
  %p12106 = inttoptr i64 %v12105 to ptr
  store i64 %v12104, ptr %p12106, align 8, !alias.scope !3, !noalias !4
  %v12107 = load i64, ptr %slot25, align 8
  %p12108 = inttoptr i64 %v12107 to ptr
  %ld12109 = load i32, ptr %p12108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12109, ptr %slot2262, align 8
  %v12110 = load i32, ptr %slot2262, align 8
  %cv12111 = zext i32 %v12110 to i64
  %cond12112 = icmp ne i64 %cv12111, 0
  br i1 %cond12112, label %bb_rcslotdrop2971, label %bb_rcslotdone2971
bb_rcslotdrop2971:
  %v12113 = load i64, ptr %slot25, align 8
  %p12114 = inttoptr i64 %v12113 to ptr
  store i32 0, ptr %p12114, align 4, !alias.scope !3, !noalias !4
  %v12115 = load i64, ptr %slot35, align 8
  store i64 %v12115, ptr %slot2263, align 8
  %v12116 = load i64, ptr %slot26, align 8
  %p12117 = inttoptr i64 %v12116 to ptr
  %ld12118 = load i32, ptr %p12117, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12118, ptr %slot2264, align 8
  %v12119 = load i32, ptr %slot2264, align 8
  %op12120 = and i32 %v12119, 28
  store i32 %op12120, ptr %slot2265, align 8
  %v12121 = load i32, ptr %slot2265, align 8
  %cv12122 = zext i32 %v12121 to i64
  %cond12123 = icmp ne i64 %cv12122, 0
  br i1 %cond12123, label %bb_rcslotrole2971, label %bb_rcslotowner2971
bb_rcslotrole2971:
  %v12124 = load i64, ptr %slot88, align 8
  store i64 %v12124, ptr %slot2266, align 8
  %v12125 = load i64, ptr %slot2266, align 8
  %v12126 = load i64, ptr %slot2263, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v12125, i64 %v12126) nomerge, !dbg !188
  br label %bb_rcslotdone2971
bb_rcslotowner2971:
  %v12127 = load i64, ptr %slot88, align 8
  store i64 %v12127, ptr %slot2267, align 8
  %v12128 = load i64, ptr %slot2267, align 8
  %v12129 = load i64, ptr %slot2263, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v12128, i64 %v12129) nomerge, !dbg !188
  br label %bb_rcslotdone2971
bb_rcslotdone2971:
  %v12130 = load i64, ptr %slot69, align 8
  %p12131 = inttoptr i64 %v12130 to ptr
  %ld12132 = load i64, ptr %p12131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12132, ptr %slot2268, align 8
  %v12133 = load i64, ptr %slot2268, align 8
  %v12134 = load i64, ptr %slot67, align 8
  %p12135 = inttoptr i64 %v12134 to ptr
  store i64 %v12133, ptr %p12135, align 8, !alias.scope !3, !noalias !4
  %v12136 = load i64, ptr %slot67, align 8
  %p12137 = inttoptr i64 %v12136 to ptr
  %ld12138 = load i64, ptr %p12137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12138, ptr %slot2269, align 8
  %v12139 = load i64, ptr %slot2269, align 8
  %op12140 = add i64 %v12139, 0
  store i64 %op12140, ptr %slot2270, align 8
  %v12141 = load i64, ptr %slot2270, align 8
  %p12142 = inttoptr i64 %v12141 to ptr
  %ld12143 = load i64, ptr %p12142, align 8, !alias.scope !6, !noalias !7
  store i64 %ld12143, ptr %slot2271, align 8
  %v12144 = load i64, ptr %slot2271, align 8
  %v12145 = load i64, ptr %slot69, align 8
  %p12146 = inttoptr i64 %v12145 to ptr
  store i64 %v12144, ptr %p12146, align 8, !alias.scope !3, !noalias !4
  %v12147 = load i64, ptr %slot69, align 8
  %p12148 = inttoptr i64 %v12147 to ptr
  %ld12149 = load i64, ptr %p12148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12149, ptr %slot2272, align 8
  %v12150 = load i64, ptr %slot2272, align 8
  %cmp12151 = icmp ugt i64 %v12150, 9223372036854775807
  %cv12152 = zext i1 %cmp12151 to i64
  store i64 %cv12152, ptr %slot2273, align 8
  %v12153 = load i64, ptr %slot2273, align 8
  %cond12154 = icmp ne i64 %v12153, 0
  br i1 %cond12154, label %bb_cast_overflow2984, label %bb_cast_ok2984
bb_cast_overflow2984:
  %v12155 = load i64, ptr %slot1, align 8
  %p12156 = inttoptr i64 %v12155 to ptr
  %v12157 = load i64, ptr %slot2272, align 8
  call void @myl_qbe_fail_cast(ptr %p12156, i64 %v12157, i64 320) nomerge, !dbg !190
  unreachable
bb_cast_ok2984:
  %v12158 = load i64, ptr %slot2272, align 8
  %v12159 = load i64, ptr %slot69, align 8
  %p12160 = inttoptr i64 %v12159 to ptr
  store i64 %v12158, ptr %p12160, align 8, !alias.scope !3, !noalias !4
  %v12161 = load i64, ptr %slot70, align 8
  %p12162 = inttoptr i64 %v12161 to ptr
  store i64 1, ptr %p12162, align 8, !alias.scope !3, !noalias !4
  %v12163 = load i64, ptr %slot70, align 8
  %p12164 = inttoptr i64 %v12163 to ptr
  %ld12165 = load i64, ptr %p12164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12165, ptr %slot2274, align 8
  %v12166 = load i64, ptr %slot69, align 8
  %p12167 = inttoptr i64 %v12166 to ptr
  %ld12168 = load i64, ptr %p12167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12168, ptr %slot2275, align 8
  %v12169 = load i64, ptr %slot2275, align 8
  %v12170 = load i64, ptr %slot2274, align 8
  %ovpair12172 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v12169, i64 %v12170)
  %op12171 = extractvalue { i64, i1 } %ovpair12172, 0
  %ov12173 = extractvalue { i64, i1 } %ovpair12172, 1
  store i64 %op12171, ptr %slot2276, align 8
  %cv12174 = zext i1 %ov12173 to i64
  store i64 %cv12174, ptr %slot2277, align 8
  %v12175 = load i64, ptr %slot2277, align 8
  %cond12176 = icmp ne i64 %v12175, 0
  br i1 %cond12176, label %bb_overflow2987, label %bb_checked2987
bb_overflow2987:
  %v12177 = load i64, ptr %slot1, align 8
  %p12178 = inttoptr i64 %v12177 to ptr
  %v12179 = load i64, ptr %slot2275, align 8
  %v12180 = load i64, ptr %slot2274, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p12178, i64 1, i64 %v12179, i64 %v12180, i64 64) nomerge, !dbg !192
  unreachable
bb_checked2987:
  %v12181 = load i64, ptr %slot2276, align 8
  %v12182 = load i64, ptr %slot69, align 8
  %p12183 = inttoptr i64 %v12182 to ptr
  store i64 %v12181, ptr %p12183, align 8, !alias.scope !3, !noalias !4
  %v12184 = load i64, ptr %slot59, align 8
  %v12185 = load i64, ptr %slot70, align 8
  %p12186 = inttoptr i64 %v12185 to ptr
  store i64 %v12184, ptr %p12186, align 8, !alias.scope !3, !noalias !4
  %v12187 = load i64, ptr %slot68, align 8
  %p12188 = inttoptr i64 %v12187 to ptr
  %ld12189 = load i64, ptr %p12188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12189, ptr %slot2278, align 8
  %v12190 = load i64, ptr %slot69, align 8
  %p12191 = inttoptr i64 %v12190 to ptr
  %ld12192 = load i64, ptr %p12191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12192, ptr %slot2279, align 8
  %v12193 = load i64, ptr %slot70, align 8
  %p12194 = inttoptr i64 %v12193 to ptr
  %ld12195 = load i64, ptr %p12194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12195, ptr %slot2280, align 8
  %v12196 = load i64, ptr %slot1, align 8
  %v12197 = load i64, ptr %slot2278, align 8
  %v12198 = load i64, ptr %slot2279, align 8
  %v12199 = load i64, ptr %slot2280, align 8
  %call12200 = call i64 @myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328(i64 %v12196, i64 %v12197, i64 %v12198, i64 %v12199) nomerge, !dbg !194
  store i64 %call12200, ptr %slot2281, align 8
  %v12201 = load i64, ptr %slot2281, align 8
  %v12202 = load i64, ptr %slot68, align 8
  %p12203 = inttoptr i64 %v12202 to ptr
  store i64 %v12201, ptr %p12203, align 8, !alias.scope !3, !noalias !4
  %v12204 = load i64, ptr %slot23, align 8
  %p12205 = inttoptr i64 %v12204 to ptr
  %ld12206 = load i32, ptr %p12205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12206, ptr %slot2282, align 8
  %v12207 = load i32, ptr %slot2282, align 8
  %cv12208 = zext i32 %v12207 to i64
  %cond12209 = icmp ne i64 %cv12208, 0
  br i1 %cond12209, label %bb_rcslotdrop2995, label %bb_rcslotdone2995
bb_rcslotdrop2995:
  %v12210 = load i64, ptr %slot23, align 8
  %p12211 = inttoptr i64 %v12210 to ptr
  store i32 0, ptr %p12211, align 4, !alias.scope !3, !noalias !4
  %v12212 = load i64, ptr %slot34, align 8
  store i64 %v12212, ptr %slot2283, align 8
  %v12213 = load i64, ptr %slot24, align 8
  %p12214 = inttoptr i64 %v12213 to ptr
  %ld12215 = load i32, ptr %p12214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12215, ptr %slot2284, align 8
  %v12216 = load i32, ptr %slot2284, align 8
  %op12217 = and i32 %v12216, 28
  store i32 %op12217, ptr %slot2285, align 8
  %v12218 = load i32, ptr %slot2285, align 8
  %cv12219 = zext i32 %v12218 to i64
  %cond12220 = icmp ne i64 %cv12219, 0
  br i1 %cond12220, label %bb_rcslotrole2995, label %bb_rcslotowner2995
bb_rcslotrole2995:
  %v12221 = load i64, ptr %slot88, align 8
  store i64 %v12221, ptr %slot2286, align 8
  %v12222 = load i64, ptr %slot2286, align 8
  %v12223 = load i64, ptr %slot2283, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v12222, i64 %v12223) nomerge, !dbg !194
  br label %bb_rcslotdone2995
bb_rcslotowner2995:
  %v12224 = load i64, ptr %slot88, align 8
  store i64 %v12224, ptr %slot2287, align 8
  %v12225 = load i64, ptr %slot2287, align 8
  %v12226 = load i64, ptr %slot2283, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v12225, i64 %v12226) nomerge, !dbg !194
  br label %bb_rcslotdone2995
bb_rcslotdone2995:
  %v12227 = load i64, ptr %slot68, align 8
  %p12228 = inttoptr i64 %v12227 to ptr
  store i64 0, ptr %p12228, align 8, !alias.scope !3, !noalias !4
  %v12229 = load i64, ptr %slot68, align 8
  %p12230 = inttoptr i64 %v12229 to ptr
  %ld12231 = load i64, ptr %p12230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12231, ptr %slot2288, align 8
  %v12232 = load i64, ptr %slot44, align 8
  %p12234 = inttoptr i64 %v12232 to ptr
  %gep12235 = getelementptr i8, ptr %p12234, i64 24
  %op12233 = ptrtoint ptr %gep12235 to i64
  store i64 %op12233, ptr %slot2289, align 8
  %v12236 = load i64, ptr %slot2289, align 8
  %p12237 = inttoptr i64 %v12236 to ptr
  %ld12238 = load i32, ptr %p12237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12238, ptr %slot2290, align 8
  %v12239 = load i64, ptr %slot46, align 8
  %p12241 = inttoptr i64 %v12239 to ptr
  %gep12242 = getelementptr i8, ptr %p12241, i64 24
  %op12240 = ptrtoint ptr %gep12242 to i64
  store i64 %op12240, ptr %slot2291, align 8
  %v12243 = load i64, ptr %slot2291, align 8
  %p12244 = inttoptr i64 %v12243 to ptr
  %ld12245 = load i32, ptr %p12244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12245, ptr %slot2292, align 8
  %v12246 = load i32, ptr %slot2290, align 8
  %v12247 = load i32, ptr %slot2292, align 8
  %op12248 = or i32 %v12246, %v12247
  store i32 %op12248, ptr %slot2293, align 8
  %v12249 = load i64, ptr %slot48, align 8
  %p12251 = inttoptr i64 %v12249 to ptr
  %gep12252 = getelementptr i8, ptr %p12251, i64 24
  %op12250 = ptrtoint ptr %gep12252 to i64
  store i64 %op12250, ptr %slot2294, align 8
  %v12253 = load i64, ptr %slot2294, align 8
  %p12254 = inttoptr i64 %v12253 to ptr
  %ld12255 = load i32, ptr %p12254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12255, ptr %slot2295, align 8
  %v12256 = load i32, ptr %slot2293, align 8
  %v12257 = load i32, ptr %slot2295, align 8
  %op12258 = or i32 %v12256, %v12257
  store i32 %op12258, ptr %slot2296, align 8
  %v12259 = load i32, ptr %slot2296, align 8
  %cv12260 = zext i32 %v12259 to i64
  %cond12261 = icmp ne i64 %cv12260, 0
  br i1 %cond12261, label %bb_rcscopesopen3020, label %bb_rcscopesclosed3020
bb_rcscopesopen3020:
  %v12262 = load i64, ptr %slot50, align 8
  %p12264 = inttoptr i64 %v12262 to ptr
  %gep12265 = getelementptr i8, ptr %p12264, i64 0
  %op12263 = ptrtoint ptr %gep12265 to i64
  store i64 %op12263, ptr %slot2297, align 8
  %v12266 = load i64, ptr %slot44, align 8
  %v12267 = load i64, ptr %slot2297, align 8
  %p12268 = inttoptr i64 %v12267 to ptr
  store i64 %v12266, ptr %p12268, align 8, !alias.scope !3, !noalias !4
  %v12269 = load i64, ptr %slot50, align 8
  %p12271 = inttoptr i64 %v12269 to ptr
  %gep12272 = getelementptr i8, ptr %p12271, i64 8
  %op12270 = ptrtoint ptr %gep12272 to i64
  store i64 %op12270, ptr %slot2298, align 8
  %v12273 = load i64, ptr %slot46, align 8
  %v12274 = load i64, ptr %slot2298, align 8
  %p12275 = inttoptr i64 %v12274 to ptr
  store i64 %v12273, ptr %p12275, align 8, !alias.scope !3, !noalias !4
  %v12276 = load i64, ptr %slot50, align 8
  %p12278 = inttoptr i64 %v12276 to ptr
  %gep12279 = getelementptr i8, ptr %p12278, i64 16
  %op12277 = ptrtoint ptr %gep12279 to i64
  store i64 %op12277, ptr %slot2299, align 8
  %v12280 = load i64, ptr %slot48, align 8
  %v12281 = load i64, ptr %slot2299, align 8
  %p12282 = inttoptr i64 %v12281 to ptr
  store i64 %v12280, ptr %p12282, align 8, !alias.scope !3, !noalias !4
  %v12283 = load i64, ptr %slot1, align 8
  %p12284 = inttoptr i64 %v12283 to ptr
  %v12285 = load i64, ptr %slot50, align 8
  %p12286 = inttoptr i64 %v12285 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p12284, ptr %p12286, i64 3) nomerge, !dbg !196
  br label %bb_rcscopesclosed3020
bb_rcscopesclosed3020:
  %v12287 = load i64, ptr %slot23, align 8
  %p12288 = inttoptr i64 %v12287 to ptr
  %ld12289 = load i32, ptr %p12288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12289, ptr %slot2300, align 8
  %v12290 = load i32, ptr %slot2300, align 8
  %cv12291 = zext i32 %v12290 to i64
  %cond12292 = icmp ne i64 %cv12291, 0
  br i1 %cond12292, label %bb_rcslotdrop3026, label %bb_rcslotdone3026
bb_rcslotdrop3026:
  %v12293 = load i64, ptr %slot23, align 8
  %p12294 = inttoptr i64 %v12293 to ptr
  store i32 0, ptr %p12294, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone3026
bb_rcslotdone3026:
  %v12295 = load i64, ptr %slot21, align 8
  %p12296 = inttoptr i64 %v12295 to ptr
  %ld12297 = load i32, ptr %p12296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12297, ptr %slot2301, align 8
  %v12298 = load i32, ptr %slot2301, align 8
  %cv12299 = zext i32 %v12298 to i64
  %cond12300 = icmp ne i64 %cv12299, 0
  br i1 %cond12300, label %bb_rcslotdrop3066, label %bb_rcslotdone3066
bb_rcslotdrop3066:
  %v12301 = load i64, ptr %slot21, align 8
  %p12302 = inttoptr i64 %v12301 to ptr
  store i32 0, ptr %p12302, align 4, !alias.scope !3, !noalias !4
  %v12303 = load i64, ptr %slot66, align 8
  store i64 %v12303, ptr %slot2302, align 8
  %v12304 = load i64, ptr %slot22, align 8
  %p12305 = inttoptr i64 %v12304 to ptr
  %ld12306 = load i32, ptr %p12305, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12306, ptr %slot2303, align 8
  %v12307 = load i32, ptr %slot2303, align 8
  %op12308 = and i32 %v12307, 28
  store i32 %op12308, ptr %slot2304, align 8
  %v12309 = load i32, ptr %slot2304, align 8
  %cv12310 = zext i32 %v12309 to i64
  %cond12311 = icmp ne i64 %cv12310, 0
  br i1 %cond12311, label %bb_rcslotrole3066, label %bb_rcslotowner3066
bb_rcslotrole3066:
  %v12312 = load i64, ptr %slot88, align 8
  store i64 %v12312, ptr %slot2305, align 8
  %v12313 = load i64, ptr %slot2305, align 8
  %v12314 = load i64, ptr %slot2302, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v12313, i64 %v12314) nomerge, !dbg !196
  br label %bb_rcslotdone3066
bb_rcslotowner3066:
  %v12315 = load i64, ptr %slot88, align 8
  store i64 %v12315, ptr %slot2306, align 8
  %v12316 = load i64, ptr %slot2306, align 8
  %v12317 = load i64, ptr %slot2302, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v12316, i64 %v12317) nomerge, !dbg !196
  br label %bb_rcslotdone3066
bb_rcslotdone3066:
  %v12318 = load i64, ptr %slot19, align 8
  %p12319 = inttoptr i64 %v12318 to ptr
  %ld12320 = load i32, ptr %p12319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12320, ptr %slot2307, align 8
  %v12321 = load i32, ptr %slot2307, align 8
  %cv12322 = zext i32 %v12321 to i64
  %cond12323 = icmp ne i64 %cv12322, 0
  br i1 %cond12323, label %bb_rcslotdrop3075, label %bb_rcslotdone3075
bb_rcslotdrop3075:
  %v12324 = load i64, ptr %slot19, align 8
  %p12325 = inttoptr i64 %v12324 to ptr
  store i32 0, ptr %p12325, align 4, !alias.scope !3, !noalias !4
  %v12326 = load i64, ptr %slot65, align 8
  store i64 %v12326, ptr %slot2308, align 8
  %v12327 = load i64, ptr %slot20, align 8
  %p12328 = inttoptr i64 %v12327 to ptr
  %ld12329 = load i32, ptr %p12328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12329, ptr %slot2309, align 8
  %v12330 = load i32, ptr %slot2309, align 8
  %op12331 = and i32 %v12330, 28
  store i32 %op12331, ptr %slot2310, align 8
  %v12332 = load i32, ptr %slot2310, align 8
  %cv12333 = zext i32 %v12332 to i64
  %cond12334 = icmp ne i64 %cv12333, 0
  br i1 %cond12334, label %bb_rcslotrole3075, label %bb_rcslotowner3075
bb_rcslotrole3075:
  %v12335 = load i64, ptr %slot88, align 8
  store i64 %v12335, ptr %slot2311, align 8
  %v12336 = load i64, ptr %slot2311, align 8
  %v12337 = load i64, ptr %slot2308, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v12336, i64 %v12337) nomerge, !dbg !196
  br label %bb_rcslotdone3075
bb_rcslotowner3075:
  %v12338 = load i64, ptr %slot88, align 8
  store i64 %v12338, ptr %slot2312, align 8
  %v12339 = load i64, ptr %slot2312, align 8
  %v12340 = load i64, ptr %slot2308, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v12339, i64 %v12340) nomerge, !dbg !196
  br label %bb_rcslotdone3075
bb_rcslotdone3075:
  %v12341 = load i64, ptr %slot17, align 8
  %p12342 = inttoptr i64 %v12341 to ptr
  %ld12343 = load i32, ptr %p12342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12343, ptr %slot2313, align 8
  %v12344 = load i32, ptr %slot2313, align 8
  %cv12345 = zext i32 %v12344 to i64
  %cond12346 = icmp ne i64 %cv12345, 0
  br i1 %cond12346, label %bb_rcslotdrop3121, label %bb_rcslotdone3121
bb_rcslotdrop3121:
  %v12347 = load i64, ptr %slot17, align 8
  %p12348 = inttoptr i64 %v12347 to ptr
  store i32 0, ptr %p12348, align 4, !alias.scope !3, !noalias !4
  %v12349 = load i64, ptr %slot63, align 8
  store i64 %v12349, ptr %slot2314, align 8
  %v12350 = load i64, ptr %slot18, align 8
  %p12351 = inttoptr i64 %v12350 to ptr
  %ld12352 = load i32, ptr %p12351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12352, ptr %slot2315, align 8
  %v12353 = load i32, ptr %slot2315, align 8
  %op12354 = and i32 %v12353, 28
  store i32 %op12354, ptr %slot2316, align 8
  %v12355 = load i32, ptr %slot2316, align 8
  %cv12356 = zext i32 %v12355 to i64
  %cond12357 = icmp ne i64 %cv12356, 0
  br i1 %cond12357, label %bb_rcslotrole3121, label %bb_rcslotowner3121
bb_rcslotrole3121:
  %v12358 = load i64, ptr %slot88, align 8
  store i64 %v12358, ptr %slot2317, align 8
  %v12359 = load i64, ptr %slot2314, align 8
  %p12360 = inttoptr i64 %v12359 to ptr
  %ld12361 = load i64, ptr %p12360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12361, ptr %slot2318, align 8
  %v12362 = load i64, ptr %slot2318, align 8
  %cmp12363 = icmp ne i64 %v12362, 0
  %cv12364 = zext i1 %cmp12363 to i32
  store i32 %cv12364, ptr %slot2319, align 8
  %v12365 = load i32, ptr %slot2319, align 8
  %cv12366 = zext i32 %v12365 to i64
  %cond12367 = icmp ne i64 %cv12366, 0
  br i1 %cond12367, label %bb_rcgnn3137, label %bb_rcgdone3137
bb_rcgnn3137:
  %v12368 = load i64, ptr %slot2318, align 8
  %op12369 = sub i64 %v12368, 16
  store i64 %op12369, ptr %slot2320, align 8
  %v12370 = load i64, ptr %slot2318, align 8
  %p12371 = inttoptr i64 %v12370 to ptr
  %rgep12372 = getelementptr i8, ptr %p12371, i64 -16
  %ld12373 = load i64, ptr %rgep12372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12373, ptr %slot2321, align 8
  %v12374 = load i64, ptr %slot2321, align 8
  %op12375 = and i64 %v12374, 4611686018427387906
  store i64 %op12375, ptr %slot2322, align 8
  %v12376 = load i64, ptr %slot2322, align 8
  %cmp12377 = icmp ne i64 %v12376, 0
  %cv12378 = zext i1 %cmp12377 to i32
  store i32 %cv12378, ptr %slot2323, align 8
  %v12379 = load i32, ptr %slot2323, align 8
  %cv12380 = zext i32 %v12379 to i64
  %cond12381 = icmp ne i64 %cv12380, 0
  br i1 %cond12381, label %bb_rcgclear3137, label %bb_rcgcounted3137
bb_rcgcounted3137:
  %v12382 = load i64, ptr %slot2318, align 8
  %op12383 = sub i64 %v12382, 24
  store i64 %op12383, ptr %slot2324, align 8
  %v12384 = load i64, ptr %slot2318, align 8
  %p12385 = inttoptr i64 %v12384 to ptr
  %rgep12386 = getelementptr i8, ptr %p12385, i64 -24
  %ld12387 = load i64, ptr %rgep12386, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12387, ptr %slot2325, align 8
  %v12388 = load i64, ptr %slot2325, align 8
  %op12389 = sub i64 %v12388, 1
  store i64 %op12389, ptr %slot2326, align 8
  %v12390 = load i64, ptr %slot2326, align 8
  %cmp12391 = icmp eq i64 %v12390, 0
  %cv12392 = zext i1 %cmp12391 to i32
  store i32 %cv12392, ptr %slot2327, align 8
  %v12393 = load i32, ptr %slot2327, align 8
  %cv12394 = zext i32 %v12393 to i64
  %cond12395 = icmp ne i64 %cv12394, 0
  br i1 %cond12395, label %bb_rcglast3137, label %bb_rcgdec3137
bb_rcglast3137:
  %v12396 = load i64, ptr %slot2318, align 8
  %op12397 = sub i64 %v12396, 32
  store i64 %op12397, ptr %slot2328, align 8
  %v12398 = load i64, ptr %slot2318, align 8
  %p12399 = inttoptr i64 %v12398 to ptr
  %rgep12400 = getelementptr i8, ptr %p12399, i64 -32
  %ld12401 = load i64, ptr %rgep12400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12401, ptr %slot2329, align 8
  %v12402 = load i64, ptr %slot2329, align 8
  %cmp12403 = icmp ne i64 %v12402, 0
  %cv12404 = zext i1 %cmp12403 to i32
  store i32 %cv12404, ptr %slot2330, align 8
  %v12405 = load i32, ptr %slot2330, align 8
  %cv12406 = zext i32 %v12405 to i64
  %cond12407 = icmp ne i64 %cv12406, 0
  br i1 %cond12407, label %bb_rcgdec3137, label %bb_rcgslow3137
bb_rcgslow3137:
  %v12408 = load i64, ptr %slot2317, align 8
  %v12409 = load i64, ptr %slot2314, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v12408, i64 %v12409) nomerge, !dbg !196
  br label %bb_rcgdone3137
bb_rcgdec3137:
  %v12410 = load i64, ptr %slot2326, align 8
  %v12411 = load i64, ptr %slot2318, align 8
  %p12412 = inttoptr i64 %v12411 to ptr
  %rgep12413 = getelementptr i8, ptr %p12412, i64 -24
  store i64 %v12410, ptr %rgep12413, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3137
bb_rcgclear3137:
  %v12414 = load i64, ptr %slot2314, align 8
  %p12415 = inttoptr i64 %v12414 to ptr
  store i64 0, ptr %p12415, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3137
bb_rcgdone3137:
  br label %bb_rcslotdone3121
bb_rcslotowner3121:
  %v12416 = load i64, ptr %slot88, align 8
  store i64 %v12416, ptr %slot2331, align 8
  %v12417 = load i64, ptr %slot2314, align 8
  %p12418 = inttoptr i64 %v12417 to ptr
  %ld12419 = load i64, ptr %p12418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12419, ptr %slot2332, align 8
  %v12420 = load i64, ptr %slot2332, align 8
  %cmp12421 = icmp ne i64 %v12420, 0
  %cv12422 = zext i1 %cmp12421 to i32
  store i32 %cv12422, ptr %slot2333, align 8
  %v12423 = load i32, ptr %slot2333, align 8
  %cv12424 = zext i32 %v12423 to i64
  %cond12425 = icmp ne i64 %cv12424, 0
  br i1 %cond12425, label %bb_rcgnn3152, label %bb_rcgdone3152
bb_rcgnn3152:
  %v12426 = load i64, ptr %slot2332, align 8
  %op12427 = sub i64 %v12426, 16
  store i64 %op12427, ptr %slot2334, align 8
  %v12428 = load i64, ptr %slot2332, align 8
  %p12429 = inttoptr i64 %v12428 to ptr
  %rgep12430 = getelementptr i8, ptr %p12429, i64 -16
  %ld12431 = load i64, ptr %rgep12430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12431, ptr %slot2335, align 8
  %v12432 = load i64, ptr %slot2335, align 8
  %op12433 = and i64 %v12432, 4611686018427387906
  store i64 %op12433, ptr %slot2336, align 8
  %v12434 = load i64, ptr %slot2336, align 8
  %cmp12435 = icmp ne i64 %v12434, 0
  %cv12436 = zext i1 %cmp12435 to i32
  store i32 %cv12436, ptr %slot2337, align 8
  %v12437 = load i32, ptr %slot2337, align 8
  %cv12438 = zext i32 %v12437 to i64
  %cond12439 = icmp ne i64 %cv12438, 0
  br i1 %cond12439, label %bb_rcgclear3152, label %bb_rcgcounted3152
bb_rcgcounted3152:
  %v12440 = load i64, ptr %slot2332, align 8
  %op12441 = sub i64 %v12440, 32
  store i64 %op12441, ptr %slot2338, align 8
  %v12442 = load i64, ptr %slot2332, align 8
  %p12443 = inttoptr i64 %v12442 to ptr
  %rgep12444 = getelementptr i8, ptr %p12443, i64 -32
  %ld12445 = load i64, ptr %rgep12444, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12445, ptr %slot2339, align 8
  %v12446 = load i64, ptr %slot2339, align 8
  %op12447 = sub i64 %v12446, 1
  store i64 %op12447, ptr %slot2340, align 8
  %v12448 = load i64, ptr %slot2340, align 8
  %cmp12449 = icmp eq i64 %v12448, 0
  %cv12450 = zext i1 %cmp12449 to i32
  store i32 %cv12450, ptr %slot2341, align 8
  %v12451 = load i32, ptr %slot2341, align 8
  %cv12452 = zext i32 %v12451 to i64
  %cond12453 = icmp ne i64 %cv12452, 0
  br i1 %cond12453, label %bb_rcglast3152, label %bb_rcgdec3152
bb_rcglast3152:
  %v12454 = load i64, ptr %slot2332, align 8
  %op12455 = sub i64 %v12454, 24
  store i64 %op12455, ptr %slot2342, align 8
  %v12456 = load i64, ptr %slot2332, align 8
  %p12457 = inttoptr i64 %v12456 to ptr
  %rgep12458 = getelementptr i8, ptr %p12457, i64 -24
  %ld12459 = load i64, ptr %rgep12458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12459, ptr %slot2343, align 8
  %v12460 = load i64, ptr %slot2343, align 8
  %cmp12461 = icmp ne i64 %v12460, 0
  %cv12462 = zext i1 %cmp12461 to i32
  store i32 %cv12462, ptr %slot2344, align 8
  %v12463 = load i32, ptr %slot2344, align 8
  %cv12464 = zext i32 %v12463 to i64
  %cond12465 = icmp ne i64 %cv12464, 0
  br i1 %cond12465, label %bb_rcgdec3152, label %bb_rcgslow3152
bb_rcgslow3152:
  %v12466 = load i64, ptr %slot2331, align 8
  %v12467 = load i64, ptr %slot2314, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v12466, i64 %v12467) nomerge, !dbg !196
  br label %bb_rcgdone3152
bb_rcgdec3152:
  %v12468 = load i64, ptr %slot2340, align 8
  %v12469 = load i64, ptr %slot2332, align 8
  %p12470 = inttoptr i64 %v12469 to ptr
  %rgep12471 = getelementptr i8, ptr %p12470, i64 -32
  store i64 %v12468, ptr %rgep12471, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3152
bb_rcgclear3152:
  %v12472 = load i64, ptr %slot2314, align 8
  %p12473 = inttoptr i64 %v12472 to ptr
  store i64 0, ptr %p12473, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3152
bb_rcgdone3152:
  br label %bb_rcslotdone3121
bb_rcslotdone3121:
  %v12474 = load i64, ptr %slot15, align 8
  %p12475 = inttoptr i64 %v12474 to ptr
  %ld12476 = load i32, ptr %p12475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12476, ptr %slot2345, align 8
  %v12477 = load i32, ptr %slot2345, align 8
  %cv12478 = zext i32 %v12477 to i64
  %cond12479 = icmp ne i64 %cv12478, 0
  br i1 %cond12479, label %bb_rcslotdrop3185, label %bb_rcslotdone3185
bb_rcslotdrop3185:
  %v12480 = load i64, ptr %slot15, align 8
  %p12481 = inttoptr i64 %v12480 to ptr
  store i32 0, ptr %p12481, align 4, !alias.scope !3, !noalias !4
  %v12482 = load i64, ptr %slot61, align 8
  store i64 %v12482, ptr %slot2346, align 8
  %v12483 = load i64, ptr %slot16, align 8
  %p12484 = inttoptr i64 %v12483 to ptr
  %ld12485 = load i32, ptr %p12484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12485, ptr %slot2347, align 8
  %v12486 = load i32, ptr %slot2347, align 8
  %op12487 = and i32 %v12486, 28
  store i32 %op12487, ptr %slot2348, align 8
  %v12488 = load i32, ptr %slot2348, align 8
  %cv12489 = zext i32 %v12488 to i64
  %cond12490 = icmp ne i64 %cv12489, 0
  br i1 %cond12490, label %bb_rcslotrole3185, label %bb_rcslotowner3185
bb_rcslotrole3185:
  %v12491 = load i64, ptr %slot88, align 8
  store i64 %v12491, ptr %slot2349, align 8
  %v12492 = load i64, ptr %slot2349, align 8
  %v12493 = load i64, ptr %slot2346, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12492, i64 %v12493) nomerge, !dbg !196
  br label %bb_rcslotdone3185
bb_rcslotowner3185:
  %v12494 = load i64, ptr %slot88, align 8
  store i64 %v12494, ptr %slot2350, align 8
  %v12495 = load i64, ptr %slot2350, align 8
  %v12496 = load i64, ptr %slot2346, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12495, i64 %v12496) nomerge, !dbg !196
  br label %bb_rcslotdone3185
bb_rcslotdone3185:
  %v12497 = load i64, ptr %slot13, align 8
  %p12498 = inttoptr i64 %v12497 to ptr
  %ld12499 = load i32, ptr %p12498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12499, ptr %slot2351, align 8
  %v12500 = load i32, ptr %slot2351, align 8
  %cv12501 = zext i32 %v12500 to i64
  %cond12502 = icmp ne i64 %cv12501, 0
  br i1 %cond12502, label %bb_rcslotdrop3231, label %bb_rcslotdone3231
bb_rcslotdrop3231:
  %v12503 = load i64, ptr %slot13, align 8
  %p12504 = inttoptr i64 %v12503 to ptr
  store i32 0, ptr %p12504, align 4, !alias.scope !3, !noalias !4
  %v12505 = load i64, ptr %slot59, align 8
  store i64 %v12505, ptr %slot2352, align 8
  %v12506 = load i64, ptr %slot14, align 8
  %p12507 = inttoptr i64 %v12506 to ptr
  %ld12508 = load i32, ptr %p12507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12508, ptr %slot2353, align 8
  %v12509 = load i32, ptr %slot2353, align 8
  %op12510 = and i32 %v12509, 28
  store i32 %op12510, ptr %slot2354, align 8
  %v12511 = load i32, ptr %slot2354, align 8
  %cv12512 = zext i32 %v12511 to i64
  %cond12513 = icmp ne i64 %cv12512, 0
  br i1 %cond12513, label %bb_rcslotrole3231, label %bb_rcslotowner3231
bb_rcslotrole3231:
  %v12514 = load i64, ptr %slot88, align 8
  store i64 %v12514, ptr %slot2355, align 8
  %v12515 = load i64, ptr %slot2355, align 8
  %v12516 = load i64, ptr %slot2352, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v12515, i64 %v12516) nomerge, !dbg !196
  br label %bb_rcslotdone3231
bb_rcslotowner3231:
  %v12517 = load i64, ptr %slot88, align 8
  store i64 %v12517, ptr %slot2356, align 8
  %v12518 = load i64, ptr %slot2356, align 8
  %v12519 = load i64, ptr %slot2352, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v12518, i64 %v12519) nomerge, !dbg !196
  br label %bb_rcslotdone3231
bb_rcslotdone3231:
  %v12520 = load i64, ptr %slot11, align 8
  %p12521 = inttoptr i64 %v12520 to ptr
  %ld12522 = load i32, ptr %p12521, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12522, ptr %slot2357, align 8
  %v12523 = load i32, ptr %slot2357, align 8
  %cv12524 = zext i32 %v12523 to i64
  %cond12525 = icmp ne i64 %cv12524, 0
  br i1 %cond12525, label %bb_rcslotdrop3240, label %bb_rcslotdone3240
bb_rcslotdrop3240:
  %v12526 = load i64, ptr %slot11, align 8
  %p12527 = inttoptr i64 %v12526 to ptr
  store i32 0, ptr %p12527, align 4, !alias.scope !3, !noalias !4
  %v12528 = load i64, ptr %slot58, align 8
  store i64 %v12528, ptr %slot2358, align 8
  %v12529 = load i64, ptr %slot12, align 8
  %p12530 = inttoptr i64 %v12529 to ptr
  %ld12531 = load i32, ptr %p12530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12531, ptr %slot2359, align 8
  %v12532 = load i32, ptr %slot2359, align 8
  %op12533 = and i32 %v12532, 28
  store i32 %op12533, ptr %slot2360, align 8
  %v12534 = load i32, ptr %slot2360, align 8
  %cv12535 = zext i32 %v12534 to i64
  %cond12536 = icmp ne i64 %cv12535, 0
  br i1 %cond12536, label %bb_rcslotrole3240, label %bb_rcslotowner3240
bb_rcslotrole3240:
  %v12537 = load i64, ptr %slot88, align 8
  store i64 %v12537, ptr %slot2361, align 8
  %v12538 = load i64, ptr %slot2358, align 8
  %p12539 = inttoptr i64 %v12538 to ptr
  %ld12540 = load i64, ptr %p12539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12540, ptr %slot2362, align 8
  %v12541 = load i64, ptr %slot2362, align 8
  %cmp12542 = icmp ne i64 %v12541, 0
  %cv12543 = zext i1 %cmp12542 to i32
  store i32 %cv12543, ptr %slot2363, align 8
  %v12544 = load i32, ptr %slot2363, align 8
  %cv12545 = zext i32 %v12544 to i64
  %cond12546 = icmp ne i64 %cv12545, 0
  br i1 %cond12546, label %bb_rcgnn3256, label %bb_rcgdone3256
bb_rcgnn3256:
  %v12547 = load i64, ptr %slot2362, align 8
  %op12548 = sub i64 %v12547, 16
  store i64 %op12548, ptr %slot2364, align 8
  %v12549 = load i64, ptr %slot2362, align 8
  %p12550 = inttoptr i64 %v12549 to ptr
  %rgep12551 = getelementptr i8, ptr %p12550, i64 -16
  %ld12552 = load i64, ptr %rgep12551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12552, ptr %slot2365, align 8
  %v12553 = load i64, ptr %slot2365, align 8
  %op12554 = and i64 %v12553, 4611686018427387906
  store i64 %op12554, ptr %slot2366, align 8
  %v12555 = load i64, ptr %slot2366, align 8
  %cmp12556 = icmp ne i64 %v12555, 0
  %cv12557 = zext i1 %cmp12556 to i32
  store i32 %cv12557, ptr %slot2367, align 8
  %v12558 = load i32, ptr %slot2367, align 8
  %cv12559 = zext i32 %v12558 to i64
  %cond12560 = icmp ne i64 %cv12559, 0
  br i1 %cond12560, label %bb_rcgclear3256, label %bb_rcgcounted3256
bb_rcgcounted3256:
  %v12561 = load i64, ptr %slot2362, align 8
  %op12562 = sub i64 %v12561, 24
  store i64 %op12562, ptr %slot2368, align 8
  %v12563 = load i64, ptr %slot2362, align 8
  %p12564 = inttoptr i64 %v12563 to ptr
  %rgep12565 = getelementptr i8, ptr %p12564, i64 -24
  %ld12566 = load i64, ptr %rgep12565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12566, ptr %slot2369, align 8
  %v12567 = load i64, ptr %slot2369, align 8
  %op12568 = sub i64 %v12567, 1
  store i64 %op12568, ptr %slot2370, align 8
  %v12569 = load i64, ptr %slot2370, align 8
  %cmp12570 = icmp eq i64 %v12569, 0
  %cv12571 = zext i1 %cmp12570 to i32
  store i32 %cv12571, ptr %slot2371, align 8
  %v12572 = load i32, ptr %slot2371, align 8
  %cv12573 = zext i32 %v12572 to i64
  %cond12574 = icmp ne i64 %cv12573, 0
  br i1 %cond12574, label %bb_rcglast3256, label %bb_rcgdec3256
bb_rcglast3256:
  %v12575 = load i64, ptr %slot2362, align 8
  %op12576 = sub i64 %v12575, 32
  store i64 %op12576, ptr %slot2372, align 8
  %v12577 = load i64, ptr %slot2362, align 8
  %p12578 = inttoptr i64 %v12577 to ptr
  %rgep12579 = getelementptr i8, ptr %p12578, i64 -32
  %ld12580 = load i64, ptr %rgep12579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12580, ptr %slot2373, align 8
  %v12581 = load i64, ptr %slot2373, align 8
  %cmp12582 = icmp ne i64 %v12581, 0
  %cv12583 = zext i1 %cmp12582 to i32
  store i32 %cv12583, ptr %slot2374, align 8
  %v12584 = load i32, ptr %slot2374, align 8
  %cv12585 = zext i32 %v12584 to i64
  %cond12586 = icmp ne i64 %cv12585, 0
  br i1 %cond12586, label %bb_rcgdec3256, label %bb_rcgslow3256
bb_rcgslow3256:
  %v12587 = load i64, ptr %slot2361, align 8
  %v12588 = load i64, ptr %slot2358, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64 %v12587, i64 %v12588) nomerge, !dbg !196
  br label %bb_rcgdone3256
bb_rcgdec3256:
  %v12589 = load i64, ptr %slot2370, align 8
  %v12590 = load i64, ptr %slot2362, align 8
  %p12591 = inttoptr i64 %v12590 to ptr
  %rgep12592 = getelementptr i8, ptr %p12591, i64 -24
  store i64 %v12589, ptr %rgep12592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3256
bb_rcgclear3256:
  %v12593 = load i64, ptr %slot2358, align 8
  %p12594 = inttoptr i64 %v12593 to ptr
  store i64 0, ptr %p12594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3256
bb_rcgdone3256:
  br label %bb_rcslotdone3240
bb_rcslotowner3240:
  %v12595 = load i64, ptr %slot88, align 8
  store i64 %v12595, ptr %slot2375, align 8
  %v12596 = load i64, ptr %slot2358, align 8
  %p12597 = inttoptr i64 %v12596 to ptr
  %ld12598 = load i64, ptr %p12597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12598, ptr %slot2376, align 8
  %v12599 = load i64, ptr %slot2376, align 8
  %cmp12600 = icmp ne i64 %v12599, 0
  %cv12601 = zext i1 %cmp12600 to i32
  store i32 %cv12601, ptr %slot2377, align 8
  %v12602 = load i32, ptr %slot2377, align 8
  %cv12603 = zext i32 %v12602 to i64
  %cond12604 = icmp ne i64 %cv12603, 0
  br i1 %cond12604, label %bb_rcgnn3271, label %bb_rcgdone3271
bb_rcgnn3271:
  %v12605 = load i64, ptr %slot2376, align 8
  %op12606 = sub i64 %v12605, 16
  store i64 %op12606, ptr %slot2378, align 8
  %v12607 = load i64, ptr %slot2376, align 8
  %p12608 = inttoptr i64 %v12607 to ptr
  %rgep12609 = getelementptr i8, ptr %p12608, i64 -16
  %ld12610 = load i64, ptr %rgep12609, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12610, ptr %slot2379, align 8
  %v12611 = load i64, ptr %slot2379, align 8
  %op12612 = and i64 %v12611, 4611686018427387906
  store i64 %op12612, ptr %slot2380, align 8
  %v12613 = load i64, ptr %slot2380, align 8
  %cmp12614 = icmp ne i64 %v12613, 0
  %cv12615 = zext i1 %cmp12614 to i32
  store i32 %cv12615, ptr %slot2381, align 8
  %v12616 = load i32, ptr %slot2381, align 8
  %cv12617 = zext i32 %v12616 to i64
  %cond12618 = icmp ne i64 %cv12617, 0
  br i1 %cond12618, label %bb_rcgclear3271, label %bb_rcgcounted3271
bb_rcgcounted3271:
  %v12619 = load i64, ptr %slot2376, align 8
  %op12620 = sub i64 %v12619, 32
  store i64 %op12620, ptr %slot2382, align 8
  %v12621 = load i64, ptr %slot2376, align 8
  %p12622 = inttoptr i64 %v12621 to ptr
  %rgep12623 = getelementptr i8, ptr %p12622, i64 -32
  %ld12624 = load i64, ptr %rgep12623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12624, ptr %slot2383, align 8
  %v12625 = load i64, ptr %slot2383, align 8
  %op12626 = sub i64 %v12625, 1
  store i64 %op12626, ptr %slot2384, align 8
  %v12627 = load i64, ptr %slot2384, align 8
  %cmp12628 = icmp eq i64 %v12627, 0
  %cv12629 = zext i1 %cmp12628 to i32
  store i32 %cv12629, ptr %slot2385, align 8
  %v12630 = load i32, ptr %slot2385, align 8
  %cv12631 = zext i32 %v12630 to i64
  %cond12632 = icmp ne i64 %cv12631, 0
  br i1 %cond12632, label %bb_rcglast3271, label %bb_rcgdec3271
bb_rcglast3271:
  %v12633 = load i64, ptr %slot2376, align 8
  %op12634 = sub i64 %v12633, 24
  store i64 %op12634, ptr %slot2386, align 8
  %v12635 = load i64, ptr %slot2376, align 8
  %p12636 = inttoptr i64 %v12635 to ptr
  %rgep12637 = getelementptr i8, ptr %p12636, i64 -24
  %ld12638 = load i64, ptr %rgep12637, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12638, ptr %slot2387, align 8
  %v12639 = load i64, ptr %slot2387, align 8
  %cmp12640 = icmp ne i64 %v12639, 0
  %cv12641 = zext i1 %cmp12640 to i32
  store i32 %cv12641, ptr %slot2388, align 8
  %v12642 = load i32, ptr %slot2388, align 8
  %cv12643 = zext i32 %v12642 to i64
  %cond12644 = icmp ne i64 %cv12643, 0
  br i1 %cond12644, label %bb_rcgdec3271, label %bb_rcgslow3271
bb_rcgslow3271:
  %v12645 = load i64, ptr %slot2375, align 8
  %v12646 = load i64, ptr %slot2358, align 8
  call void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64 %v12645, i64 %v12646) nomerge, !dbg !196
  br label %bb_rcgdone3271
bb_rcgdec3271:
  %v12647 = load i64, ptr %slot2384, align 8
  %v12648 = load i64, ptr %slot2376, align 8
  %p12649 = inttoptr i64 %v12648 to ptr
  %rgep12650 = getelementptr i8, ptr %p12649, i64 -32
  store i64 %v12647, ptr %rgep12650, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3271
bb_rcgclear3271:
  %v12651 = load i64, ptr %slot2358, align 8
  %p12652 = inttoptr i64 %v12651 to ptr
  store i64 0, ptr %p12652, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3271
bb_rcgdone3271:
  br label %bb_rcslotdone3240
bb_rcslotdone3240:
  %v12653 = load i64, ptr %slot9, align 8
  %p12654 = inttoptr i64 %v12653 to ptr
  %ld12655 = load i32, ptr %p12654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12655, ptr %slot2389, align 8
  %v12656 = load i32, ptr %slot2389, align 8
  %cv12657 = zext i32 %v12656 to i64
  %cond12658 = icmp ne i64 %cv12657, 0
  br i1 %cond12658, label %bb_rcslotdrop3277, label %bb_rcslotdone3277
bb_rcslotdrop3277:
  %v12659 = load i64, ptr %slot9, align 8
  %p12660 = inttoptr i64 %v12659 to ptr
  store i32 0, ptr %p12660, align 4, !alias.scope !3, !noalias !4
  %v12661 = load i64, ptr %slot57, align 8
  store i64 %v12661, ptr %slot2390, align 8
  %v12662 = load i64, ptr %slot10, align 8
  %p12663 = inttoptr i64 %v12662 to ptr
  %ld12664 = load i32, ptr %p12663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12664, ptr %slot2391, align 8
  %v12665 = load i32, ptr %slot2391, align 8
  %op12666 = and i32 %v12665, 28
  store i32 %op12666, ptr %slot2392, align 8
  %v12667 = load i32, ptr %slot2392, align 8
  %cv12668 = zext i32 %v12667 to i64
  %cond12669 = icmp ne i64 %cv12668, 0
  br i1 %cond12669, label %bb_rcslotrole3277, label %bb_rcslotowner3277
bb_rcslotrole3277:
  %v12670 = load i64, ptr %slot88, align 8
  store i64 %v12670, ptr %slot2393, align 8
  %v12671 = load i64, ptr %slot2390, align 8
  %p12672 = inttoptr i64 %v12671 to ptr
  %ld12673 = load i64, ptr %p12672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12673, ptr %slot2394, align 8
  %v12674 = load i64, ptr %slot2394, align 8
  %cmp12675 = icmp ne i64 %v12674, 0
  %cv12676 = zext i1 %cmp12675 to i32
  store i32 %cv12676, ptr %slot2395, align 8
  %v12677 = load i32, ptr %slot2395, align 8
  %cv12678 = zext i32 %v12677 to i64
  %cond12679 = icmp ne i64 %cv12678, 0
  br i1 %cond12679, label %bb_rcgnn3293, label %bb_rcgdone3293
bb_rcgnn3293:
  %v12680 = load i64, ptr %slot2394, align 8
  %op12681 = sub i64 %v12680, 16
  store i64 %op12681, ptr %slot2396, align 8
  %v12682 = load i64, ptr %slot2394, align 8
  %p12683 = inttoptr i64 %v12682 to ptr
  %rgep12684 = getelementptr i8, ptr %p12683, i64 -16
  %ld12685 = load i64, ptr %rgep12684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12685, ptr %slot2397, align 8
  %v12686 = load i64, ptr %slot2397, align 8
  %op12687 = and i64 %v12686, 4611686018427387906
  store i64 %op12687, ptr %slot2398, align 8
  %v12688 = load i64, ptr %slot2398, align 8
  %cmp12689 = icmp ne i64 %v12688, 0
  %cv12690 = zext i1 %cmp12689 to i32
  store i32 %cv12690, ptr %slot2399, align 8
  %v12691 = load i32, ptr %slot2399, align 8
  %cv12692 = zext i32 %v12691 to i64
  %cond12693 = icmp ne i64 %cv12692, 0
  br i1 %cond12693, label %bb_rcgclear3293, label %bb_rcgcounted3293
bb_rcgcounted3293:
  %v12694 = load i64, ptr %slot2394, align 8
  %op12695 = sub i64 %v12694, 24
  store i64 %op12695, ptr %slot2400, align 8
  %v12696 = load i64, ptr %slot2394, align 8
  %p12697 = inttoptr i64 %v12696 to ptr
  %rgep12698 = getelementptr i8, ptr %p12697, i64 -24
  %ld12699 = load i64, ptr %rgep12698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12699, ptr %slot2401, align 8
  %v12700 = load i64, ptr %slot2401, align 8
  %op12701 = sub i64 %v12700, 1
  store i64 %op12701, ptr %slot2402, align 8
  %v12702 = load i64, ptr %slot2402, align 8
  %cmp12703 = icmp eq i64 %v12702, 0
  %cv12704 = zext i1 %cmp12703 to i32
  store i32 %cv12704, ptr %slot2403, align 8
  %v12705 = load i32, ptr %slot2403, align 8
  %cv12706 = zext i32 %v12705 to i64
  %cond12707 = icmp ne i64 %cv12706, 0
  br i1 %cond12707, label %bb_rcglast3293, label %bb_rcgdec3293
bb_rcglast3293:
  %v12708 = load i64, ptr %slot2394, align 8
  %op12709 = sub i64 %v12708, 32
  store i64 %op12709, ptr %slot2404, align 8
  %v12710 = load i64, ptr %slot2394, align 8
  %p12711 = inttoptr i64 %v12710 to ptr
  %rgep12712 = getelementptr i8, ptr %p12711, i64 -32
  %ld12713 = load i64, ptr %rgep12712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12713, ptr %slot2405, align 8
  %v12714 = load i64, ptr %slot2405, align 8
  %cmp12715 = icmp ne i64 %v12714, 0
  %cv12716 = zext i1 %cmp12715 to i32
  store i32 %cv12716, ptr %slot2406, align 8
  %v12717 = load i32, ptr %slot2406, align 8
  %cv12718 = zext i32 %v12717 to i64
  %cond12719 = icmp ne i64 %cv12718, 0
  br i1 %cond12719, label %bb_rcgdec3293, label %bb_rcgslow3293
bb_rcgslow3293:
  %v12720 = load i64, ptr %slot2393, align 8
  %v12721 = load i64, ptr %slot2390, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v12720, i64 %v12721) nomerge, !dbg !196
  br label %bb_rcgdone3293
bb_rcgdec3293:
  %v12722 = load i64, ptr %slot2402, align 8
  %v12723 = load i64, ptr %slot2394, align 8
  %p12724 = inttoptr i64 %v12723 to ptr
  %rgep12725 = getelementptr i8, ptr %p12724, i64 -24
  store i64 %v12722, ptr %rgep12725, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3293
bb_rcgclear3293:
  %v12726 = load i64, ptr %slot2390, align 8
  %p12727 = inttoptr i64 %v12726 to ptr
  store i64 0, ptr %p12727, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3293
bb_rcgdone3293:
  br label %bb_rcslotdone3277
bb_rcslotowner3277:
  %v12728 = load i64, ptr %slot88, align 8
  store i64 %v12728, ptr %slot2407, align 8
  %v12729 = load i64, ptr %slot2390, align 8
  %p12730 = inttoptr i64 %v12729 to ptr
  %ld12731 = load i64, ptr %p12730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12731, ptr %slot2408, align 8
  %v12732 = load i64, ptr %slot2408, align 8
  %cmp12733 = icmp ne i64 %v12732, 0
  %cv12734 = zext i1 %cmp12733 to i32
  store i32 %cv12734, ptr %slot2409, align 8
  %v12735 = load i32, ptr %slot2409, align 8
  %cv12736 = zext i32 %v12735 to i64
  %cond12737 = icmp ne i64 %cv12736, 0
  br i1 %cond12737, label %bb_rcgnn3308, label %bb_rcgdone3308
bb_rcgnn3308:
  %v12738 = load i64, ptr %slot2408, align 8
  %op12739 = sub i64 %v12738, 16
  store i64 %op12739, ptr %slot2410, align 8
  %v12740 = load i64, ptr %slot2408, align 8
  %p12741 = inttoptr i64 %v12740 to ptr
  %rgep12742 = getelementptr i8, ptr %p12741, i64 -16
  %ld12743 = load i64, ptr %rgep12742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12743, ptr %slot2411, align 8
  %v12744 = load i64, ptr %slot2411, align 8
  %op12745 = and i64 %v12744, 4611686018427387906
  store i64 %op12745, ptr %slot2412, align 8
  %v12746 = load i64, ptr %slot2412, align 8
  %cmp12747 = icmp ne i64 %v12746, 0
  %cv12748 = zext i1 %cmp12747 to i32
  store i32 %cv12748, ptr %slot2413, align 8
  %v12749 = load i32, ptr %slot2413, align 8
  %cv12750 = zext i32 %v12749 to i64
  %cond12751 = icmp ne i64 %cv12750, 0
  br i1 %cond12751, label %bb_rcgclear3308, label %bb_rcgcounted3308
bb_rcgcounted3308:
  %v12752 = load i64, ptr %slot2408, align 8
  %op12753 = sub i64 %v12752, 32
  store i64 %op12753, ptr %slot2414, align 8
  %v12754 = load i64, ptr %slot2408, align 8
  %p12755 = inttoptr i64 %v12754 to ptr
  %rgep12756 = getelementptr i8, ptr %p12755, i64 -32
  %ld12757 = load i64, ptr %rgep12756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12757, ptr %slot2415, align 8
  %v12758 = load i64, ptr %slot2415, align 8
  %op12759 = sub i64 %v12758, 1
  store i64 %op12759, ptr %slot2416, align 8
  %v12760 = load i64, ptr %slot2416, align 8
  %cmp12761 = icmp eq i64 %v12760, 0
  %cv12762 = zext i1 %cmp12761 to i32
  store i32 %cv12762, ptr %slot2417, align 8
  %v12763 = load i32, ptr %slot2417, align 8
  %cv12764 = zext i32 %v12763 to i64
  %cond12765 = icmp ne i64 %cv12764, 0
  br i1 %cond12765, label %bb_rcglast3308, label %bb_rcgdec3308
bb_rcglast3308:
  %v12766 = load i64, ptr %slot2408, align 8
  %op12767 = sub i64 %v12766, 24
  store i64 %op12767, ptr %slot2418, align 8
  %v12768 = load i64, ptr %slot2408, align 8
  %p12769 = inttoptr i64 %v12768 to ptr
  %rgep12770 = getelementptr i8, ptr %p12769, i64 -24
  %ld12771 = load i64, ptr %rgep12770, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12771, ptr %slot2419, align 8
  %v12772 = load i64, ptr %slot2419, align 8
  %cmp12773 = icmp ne i64 %v12772, 0
  %cv12774 = zext i1 %cmp12773 to i32
  store i32 %cv12774, ptr %slot2420, align 8
  %v12775 = load i32, ptr %slot2420, align 8
  %cv12776 = zext i32 %v12775 to i64
  %cond12777 = icmp ne i64 %cv12776, 0
  br i1 %cond12777, label %bb_rcgdec3308, label %bb_rcgslow3308
bb_rcgslow3308:
  %v12778 = load i64, ptr %slot2407, align 8
  %v12779 = load i64, ptr %slot2390, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v12778, i64 %v12779) nomerge, !dbg !196
  br label %bb_rcgdone3308
bb_rcgdec3308:
  %v12780 = load i64, ptr %slot2416, align 8
  %v12781 = load i64, ptr %slot2408, align 8
  %p12782 = inttoptr i64 %v12781 to ptr
  %rgep12783 = getelementptr i8, ptr %p12782, i64 -32
  store i64 %v12780, ptr %rgep12783, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3308
bb_rcgclear3308:
  %v12784 = load i64, ptr %slot2390, align 8
  %p12785 = inttoptr i64 %v12784 to ptr
  store i64 0, ptr %p12785, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3308
bb_rcgdone3308:
  br label %bb_rcslotdone3277
bb_rcslotdone3277:
  %v12786 = load i64, ptr %slot7, align 8
  %p12787 = inttoptr i64 %v12786 to ptr
  %ld12788 = load i32, ptr %p12787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12788, ptr %slot2421, align 8
  %v12789 = load i32, ptr %slot2421, align 8
  %cv12790 = zext i32 %v12789 to i64
  %cond12791 = icmp ne i64 %cv12790, 0
  br i1 %cond12791, label %bb_rcslotdrop3369, label %bb_rcslotdone3369
bb_rcslotdrop3369:
  %v12792 = load i64, ptr %slot7, align 8
  %p12793 = inttoptr i64 %v12792 to ptr
  store i32 0, ptr %p12793, align 4, !alias.scope !3, !noalias !4
  %v12794 = load i64, ptr %slot54, align 8
  store i64 %v12794, ptr %slot2422, align 8
  %v12795 = load i64, ptr %slot8, align 8
  %p12796 = inttoptr i64 %v12795 to ptr
  %ld12797 = load i32, ptr %p12796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12797, ptr %slot2423, align 8
  %v12798 = load i32, ptr %slot2423, align 8
  %op12799 = and i32 %v12798, 28
  store i32 %op12799, ptr %slot2424, align 8
  %v12800 = load i32, ptr %slot2424, align 8
  %cv12801 = zext i32 %v12800 to i64
  %cond12802 = icmp ne i64 %cv12801, 0
  br i1 %cond12802, label %bb_rcslotrole3369, label %bb_rcslotowner3369
bb_rcslotrole3369:
  %v12803 = load i64, ptr %slot88, align 8
  store i64 %v12803, ptr %slot2425, align 8
  %v12804 = load i64, ptr %slot2425, align 8
  %v12805 = load i64, ptr %slot2422, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12804, i64 %v12805) nomerge, !dbg !196
  br label %bb_rcslotdone3369
bb_rcslotowner3369:
  %v12806 = load i64, ptr %slot88, align 8
  store i64 %v12806, ptr %slot2426, align 8
  %v12807 = load i64, ptr %slot2426, align 8
  %v12808 = load i64, ptr %slot2422, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12807, i64 %v12808) nomerge, !dbg !196
  br label %bb_rcslotdone3369
bb_rcslotdone3369:
  %v12809 = load i64, ptr %slot5, align 8
  %p12810 = inttoptr i64 %v12809 to ptr
  %ld12811 = load i32, ptr %p12810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12811, ptr %slot2427, align 8
  %v12812 = load i32, ptr %slot2427, align 8
  %cv12813 = zext i32 %v12812 to i64
  %cond12814 = icmp ne i64 %cv12813, 0
  br i1 %cond12814, label %bb_rcslotdrop3378, label %bb_rcslotdone3378
bb_rcslotdrop3378:
  %v12815 = load i64, ptr %slot5, align 8
  %p12816 = inttoptr i64 %v12815 to ptr
  store i32 0, ptr %p12816, align 4, !alias.scope !3, !noalias !4
  %v12817 = load i64, ptr %slot53, align 8
  store i64 %v12817, ptr %slot2428, align 8
  %v12818 = load i64, ptr %slot6, align 8
  %p12819 = inttoptr i64 %v12818 to ptr
  %ld12820 = load i32, ptr %p12819, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12820, ptr %slot2429, align 8
  %v12821 = load i32, ptr %slot2429, align 8
  %op12822 = and i32 %v12821, 28
  store i32 %op12822, ptr %slot2430, align 8
  %v12823 = load i32, ptr %slot2430, align 8
  %cv12824 = zext i32 %v12823 to i64
  %cond12825 = icmp ne i64 %cv12824, 0
  br i1 %cond12825, label %bb_rcslotrole3378, label %bb_rcslotowner3378
bb_rcslotrole3378:
  %v12826 = load i64, ptr %slot88, align 8
  store i64 %v12826, ptr %slot2431, align 8
  %v12827 = load i64, ptr %slot2431, align 8
  %v12828 = load i64, ptr %slot2428, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v12827, i64 %v12828) nomerge, !dbg !196
  br label %bb_rcslotdone3378
bb_rcslotowner3378:
  %v12829 = load i64, ptr %slot88, align 8
  store i64 %v12829, ptr %slot2432, align 8
  %v12830 = load i64, ptr %slot2432, align 8
  %v12831 = load i64, ptr %slot2428, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v12830, i64 %v12831) nomerge, !dbg !196
  br label %bb_rcslotdone3378
bb_rcslotdone3378:
  %v12832 = load i64, ptr %slot2288, align 8
  ret i64 %v12832
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8
@myl_lit_ed133bb812ff429a6b7dcbb02ede97d61758e4fccb6ee5bb60d1ca8585bdd842 = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88 = external global i8, align 8
@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8
@myl_t_c0235a2002b47316e7055cdcc9950d30a5168fa64698c21e07a3f1d907870193 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_1e01c9335d0634d9063d610ba73cf2fdfc28a5d0b652ec062eb0966366f67d8c(ptr sret([48 x i8]) align 8, i64)
declare i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64, i64, i64)
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64, i64, i64)
declare i64 @myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328(i64, i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_list_append(i64, i64, i64)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64, i64)
declare i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_drop(i64, i64)
declare i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_take(i64, i64, i64, i32)
declare void @myl_t_ad1124829fe6597dae37f57b4438de8420083edff87591558d51863c1515c3ee_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3", linkageName: "myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8277273538551584371, i64 0, !"myl_f_d0f0fd2ebc58c2edfb4f79ef4b78cc0dec904f09b2ad13c907ec77d7bf9667f3"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!122 = !DILocation(line: 11, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!124 = !DILocation(line: 23, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!126 = !DILocation(line: 27, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!128 = !DILocation(line: 28, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!130 = !DILocation(line: 29, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!132 = !DILocation(line: 31, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!134 = !DILocation(line: 34, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!136 = !DILocation(line: 38, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!140 = !DILocation(line: 43, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!142 = !DILocation(line: 44, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!144 = !DILocation(line: 48, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!146 = !DILocation(line: 49, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!148 = !DILocation(line: 51, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!150 = !DILocation(line: 52, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!152 = !DILocation(line: 54, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!154 = !DILocation(line: 55, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!156 = !DILocation(line: 62, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!158 = !DILocation(line: 67, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!160 = !DILocation(line: 70, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!162 = !DILocation(line: 71, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!164 = !DILocation(line: 93, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!166 = !DILocation(line: 97, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647359)
!168 = !DILocation(line: 103, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!170 = !DILocation(line: 105, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!172 = !DILocation(line: 106, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!174 = !DILocation(line: 110, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!176 = !DILocation(line: 111, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!178 = !DILocation(line: 114, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647463)
!180 = !DILocation(line: 116, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647479)
!182 = !DILocation(line: 118, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647511)
!184 = !DILocation(line: 122, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647519)
!186 = !DILocation(line: 123, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!188 = !DILocation(line: 128, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647583)
!190 = !DILocation(line: 131, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!192 = !DILocation(line: 133, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647615)
!194 = !DILocation(line: 135, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647639)
!196 = !DILocation(line: 138, column: 0, scope: !197)
