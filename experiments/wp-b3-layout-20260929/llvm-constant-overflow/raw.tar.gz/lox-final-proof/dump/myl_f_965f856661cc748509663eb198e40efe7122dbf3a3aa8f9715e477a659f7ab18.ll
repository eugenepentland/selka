target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v60 = load i64, ptr %slot1, align 8
  %op61 = add i64 %v60, 32
  store i64 %op61, ptr %slot4, align 8
  %mem62 = alloca i8, i64 8, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot5, align 8
  %mem64 = alloca i8, i64 8, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot6, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot7, align 8
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot8, align 8
  %mem70 = alloca i8, i64 8, align 8
  %ptr71 = ptrtoint ptr %mem70 to i64
  store i64 %ptr71, ptr %slot9, align 8
  %mem72 = alloca i8, i64 208, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot10, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot11, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot12, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot13, align 8
  %mem80 = alloca i8, i64 392, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot14, align 8
  %mem82 = alloca i8, i64 392, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot16, align 8
  %v86 = load i64, ptr %slot1, align 8
  %op87 = add i64 %v86, 64
  store i64 %op87, ptr %slot17, align 8
  %v88 = load i64, ptr %slot17, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !4, !noalias !3
  store i64 %ld90, ptr %slot18, align 8
  %stack91 = call ptr @llvm.stacksave()
  %stackaddr92 = ptrtoint ptr %stack91 to i64
  %v93 = load i64, ptr %slot18, align 8
  %cmp94 = icmp ult i64 %stackaddr92, %v93
  %cv95 = zext i1 %cmp94 to i64
  store i64 %cv95, ptr %slot19, align 8
  %v96 = load i64, ptr %slot19, align 8
  %cond97 = icmp ne i64 %v96, 0
  br i1 %cond97, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v98 = load i64, ptr %slot1, align 8
  %p99 = inttoptr i64 %v98 to ptr
  call void @myl_qbe_fail_frame(ptr %p99) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v100 = load i64, ptr %slot2, align 8
  %v101 = load i64, ptr %slot8, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 %v100, ptr %p102, align 8, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot3, align 8
  %v104 = load i64, ptr %slot9, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 %v103, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot1, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %call108 = call ptr @myl_qbe_heap(ptr %p107) nomerge, !dbg !112
  %calladdr109 = ptrtoint ptr %call108 to i64
  store i64 %calladdr109, ptr %slot20, align 8
  %v110 = load i64, ptr %slot1, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %call112 = call i64 @myl_qbe_region_mark(ptr %p111) nomerge, !dbg !112
  store i64 %call112, ptr %slot21, align 8
  %v113 = load i64, ptr %slot5, align 8
  %p114 = inttoptr i64 %v113 to ptr
  store i32 0, ptr %p114, align 4, !alias.scope !3, !noalias !4
  %v115 = load i64, ptr %slot6, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i32 0, ptr %p116, align 4, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot7, align 8
  %p118 = inttoptr i64 %v117 to ptr
  store i32 0, ptr %p118, align 4, !alias.scope !3, !noalias !4
  %v119 = load i64, ptr %slot6, align 8
  %p120 = inttoptr i64 %v119 to ptr
  store i32 2, ptr %p120, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v121 = load i64, ptr %slot8, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot22, align 8
  %v124 = load i64, ptr %slot22, align 8
  %v125 = load i64, ptr %slot14, align 8
  %p126 = inttoptr i64 %v124 to ptr
  %p127 = inttoptr i64 %v125 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p127, ptr %p126, i64 392, i1 false), !alias.scope !10000000
  %v128 = load i64, ptr %slot14, align 8
  %v129 = load i64, ptr %slot12, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot12, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld133, ptr %slot23, align 8
  %v134 = load i64, ptr %slot23, align 8
  %op135 = add i64 %v134, 0
  store i64 %op135, ptr %slot24, align 8
  %v136 = load i64, ptr %slot24, align 8
  %v137 = load i64, ptr %slot12, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot5, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i32, ptr %p140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld141, ptr %slot25, align 8
  %v142 = load i32, ptr %slot25, align 8
  %cv143 = zext i32 %v142 to i64
  %cond144 = icmp ne i64 %cv143, 0
  br i1 %cond144, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v145 = load i64, ptr %slot5, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i32 0, ptr %p146, align 4, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot10, align 8
  store i64 %v147, ptr %slot26, align 8
  %v148 = load i64, ptr %slot6, align 8
  %p149 = inttoptr i64 %v148 to ptr
  %ld150 = load i32, ptr %p149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld150, ptr %slot27, align 8
  %v151 = load i32, ptr %slot27, align 8
  %op152 = and i32 %v151, 28
  store i32 %op152, ptr %slot28, align 8
  %v153 = load i32, ptr %slot28, align 8
  %cv154 = zext i32 %v153 to i64
  %cond155 = icmp ne i64 %cv154, 0
  br i1 %cond155, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v156 = load i64, ptr %slot20, align 8
  store i64 %v156, ptr %slot29, align 8
  %v157 = load i64, ptr %slot29, align 8
  %v158 = load i64, ptr %slot26, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v157, i64 %v158) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v159 = load i64, ptr %slot20, align 8
  store i64 %v159, ptr %slot30, align 8
  %v160 = load i64, ptr %slot30, align 8
  %v161 = load i64, ptr %slot26, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v160, i64 %v161) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v162 = load i64, ptr %slot8, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot31, align 8
  %v165 = load i64, ptr %slot31, align 8
  %op166 = add i64 %v165, 0
  store i64 %op166, ptr %slot32, align 8
  %v167 = load i64, ptr %slot10, align 8
  store i64 %v167, ptr %slot33, align 8
  %v168 = load i64, ptr %slot32, align 8
  %v169 = load i64, ptr %slot33, align 8
  %p170 = inttoptr i64 %v168 to ptr
  %p171 = inttoptr i64 %v169 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p171, ptr %p170, i64 208, i1 false), !alias.scope !10000000
  %v172 = load i64, ptr %slot32, align 8
  %p173 = inttoptr i64 %v172 to ptr
  call void @llvm.memset.p0.i64(ptr %p173, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !114
  %v174 = load i64, ptr %slot5, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 1, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot10, align 8
  %v177 = load i64, ptr %slot12, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot9, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot34, align 8
  %v182 = load i64, ptr %slot34, align 8
  %v183 = load i64, ptr %slot13, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot12, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i64, ptr %p186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld187, ptr %slot35, align 8
  %v188 = load i64, ptr %slot13, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot36, align 8
  %v191 = load i64, ptr %slot1, align 8
  %v192 = load i64, ptr %slot35, align 8
  %v193 = load i64, ptr %slot36, align 8
  %call194 = call i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64 %v191, i64 %v192, i64 %v193) nomerge, !dbg !116
  store i64 %call194, ptr %slot37, align 8
  %v195 = load i64, ptr %slot37, align 8
  %v196 = load i64, ptr %slot12, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot12, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot38, align 8
  %v201 = load i64, ptr %slot38, align 8
  %v202 = load i64, ptr %slot11, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot8, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot39, align 8
  %v207 = load i64, ptr %slot39, align 8
  %op208 = add i64 %v207, 0
  store i64 %op208, ptr %slot40, align 8
  %v209 = load i64, ptr %slot10, align 8
  store i64 %v209, ptr %slot41, align 8
  %v210 = load i64, ptr %slot41, align 8
  %v211 = load i64, ptr %slot40, align 8
  %p212 = inttoptr i64 %v210 to ptr
  %p213 = inttoptr i64 %v211 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p213, ptr %p212, i64 208, i1 false), !alias.scope !10000000
  %v214 = load i64, ptr %slot41, align 8
  %p215 = inttoptr i64 %v214 to ptr
  call void @llvm.memset.p0.i64(ptr %p215, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v216 = load i64, ptr %slot5, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i32 0, ptr %p217, align 4, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot12, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 0, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot8, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot42, align 8
  %v223 = load i64, ptr %slot42, align 8
  %v224 = load i64, ptr %slot12, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot11, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot43, align 8
  %v229 = load i64, ptr %slot43, align 8
  %v230 = load i64, ptr %slot13, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot15, align 8
  store i64 %v232, ptr %slot44, align 8
  %v233 = load i64, ptr %slot44, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i64 0, ptr %p234, align 8, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot44, align 8
  %p237 = inttoptr i64 %v235 to ptr
  %gep238 = getelementptr i8, ptr %p237, i64 8
  %op236 = ptrtoint ptr %gep238 to i64
  store i64 %op236, ptr %slot45, align 8
  %v239 = load i64, ptr %slot45, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i64 0, ptr %p240, align 8, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot44, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i32 3, ptr %p242, align 4, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot7, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 1, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot13, align 8
  store i64 %v245, ptr %slot46, align 8
  %v246 = load i64, ptr %slot44, align 8
  %p248 = inttoptr i64 %v246 to ptr
  %gep249 = getelementptr i8, ptr %p248, i64 8
  %op247 = ptrtoint ptr %gep249 to i64
  store i64 %op247, ptr %slot47, align 8
  %v250 = load i64, ptr %slot21, align 8
  store i64 %v250, ptr %slot48, align 8
  %v251 = load i64, ptr %slot46, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot49, align 8
  %v254 = load i64, ptr %slot49, align 8
  %v255 = load i64, ptr %slot47, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i64 %v254, ptr %p256, align 8, !alias.scope !3, !noalias !4
  %v257 = load i64, ptr %slot44, align 8
  %v258 = load i64, ptr %slot13, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot12, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot50, align 8
  %v263 = load i64, ptr %slot13, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot51, align 8
  %v266 = load i64, ptr %slot1, align 8
  %v267 = load i64, ptr %slot50, align 8
  %v268 = load i64, ptr %slot51, align 8
  %call269 = call i64 @myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f(i64 %v266, i64 %v267, i64 %v268) nomerge, !dbg !120
  store i64 %call269, ptr %slot52, align 8
  %v270 = load i64, ptr %slot52, align 8
  %v271 = load i64, ptr %slot12, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i64 %v270, ptr %p272, align 8, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot12, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot53, align 8
  %v276 = load i64, ptr %slot5, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i32, ptr %p277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld278, ptr %slot54, align 8
  %v279 = load i32, ptr %slot54, align 8
  %cv280 = zext i32 %v279 to i64
  %cond281 = icmp ne i64 %cv280, 0
  br i1 %cond281, label %bb_rcslotdrop129, label %bb_rcslotdone129
bb_rcslotdrop129:
  %v282 = load i64, ptr %slot5, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i32 0, ptr %p283, align 4, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot10, align 8
  store i64 %v284, ptr %slot55, align 8
  %v285 = load i64, ptr %slot6, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i32, ptr %p286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld287, ptr %slot56, align 8
  %v288 = load i32, ptr %slot56, align 8
  %op289 = and i32 %v288, 28
  store i32 %op289, ptr %slot57, align 8
  %v290 = load i32, ptr %slot57, align 8
  %cv291 = zext i32 %v290 to i64
  %cond292 = icmp ne i64 %cv291, 0
  br i1 %cond292, label %bb_rcslotrole129, label %bb_rcslotowner129
bb_rcslotrole129:
  %v293 = load i64, ptr %slot20, align 8
  store i64 %v293, ptr %slot58, align 8
  %v294 = load i64, ptr %slot58, align 8
  %v295 = load i64, ptr %slot55, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v294, i64 %v295) nomerge, !dbg !122
  br label %bb_rcslotdone129
bb_rcslotowner129:
  %v296 = load i64, ptr %slot20, align 8
  store i64 %v296, ptr %slot59, align 8
  %v297 = load i64, ptr %slot59, align 8
  %v298 = load i64, ptr %slot55, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v297, i64 %v298) nomerge, !dbg !122
  br label %bb_rcslotdone129
bb_rcslotdone129:
  %v299 = load i64, ptr %slot53, align 8
  ret i64 %v299
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f(i64, i64, i64)
declare i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_region_mark(ptr)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18", linkageName: "myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8696887343963321717, i64 0, !"myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!118 = !DILocation(line: 19, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!120 = !DILocation(line: 25, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!122 = !DILocation(line: 26, column: 0, scope: !123)
