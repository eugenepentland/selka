target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_765a4e7fba842652f08bd096aee9774e4d1abd4bfff41376fcf8988cbf0b51ea(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i32, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i32, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i32, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i32, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i32, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i32, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i32, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i32, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i32, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i32, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i32, align 8
  %slot1319 = alloca i32, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i32, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i32, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i32, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i32, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i32, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i32, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i32, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i32, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i32, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v1424 = load i64, ptr %slot1, align 8
  %op1425 = add i64 %v1424, 32
  store i64 %op1425, ptr %slot5, align 8
  %mem1426 = alloca i8, i64 8, align 8
  %ptr1427 = ptrtoint ptr %mem1426 to i64
  store i64 %ptr1427, ptr %slot6, align 8
  %mem1428 = alloca i8, i64 8, align 8
  %ptr1429 = ptrtoint ptr %mem1428 to i64
  store i64 %ptr1429, ptr %slot7, align 8
  %mem1430 = alloca i8, i64 8, align 8
  %ptr1431 = ptrtoint ptr %mem1430 to i64
  store i64 %ptr1431, ptr %slot8, align 8
  %mem1432 = alloca i8, i64 8, align 8
  %ptr1433 = ptrtoint ptr %mem1432 to i64
  store i64 %ptr1433, ptr %slot9, align 8
  %mem1434 = alloca i8, i64 8, align 8
  %ptr1435 = ptrtoint ptr %mem1434 to i64
  store i64 %ptr1435, ptr %slot10, align 8
  %mem1436 = alloca i8, i64 8, align 8
  %ptr1437 = ptrtoint ptr %mem1436 to i64
  store i64 %ptr1437, ptr %slot11, align 8
  %mem1438 = alloca i8, i64 8, align 8
  %ptr1439 = ptrtoint ptr %mem1438 to i64
  store i64 %ptr1439, ptr %slot12, align 8
  %mem1440 = alloca i8, i64 8, align 8
  %ptr1441 = ptrtoint ptr %mem1440 to i64
  store i64 %ptr1441, ptr %slot13, align 8
  %mem1442 = alloca i8, i64 8, align 8
  %ptr1443 = ptrtoint ptr %mem1442 to i64
  store i64 %ptr1443, ptr %slot14, align 8
  %mem1444 = alloca i8, i64 8, align 8
  %ptr1445 = ptrtoint ptr %mem1444 to i64
  store i64 %ptr1445, ptr %slot15, align 8
  %mem1446 = alloca i8, i64 8, align 8
  %ptr1447 = ptrtoint ptr %mem1446 to i64
  store i64 %ptr1447, ptr %slot16, align 8
  %mem1448 = alloca i8, i64 8, align 8
  %ptr1449 = ptrtoint ptr %mem1448 to i64
  store i64 %ptr1449, ptr %slot17, align 8
  %mem1450 = alloca i8, i64 8, align 8
  %ptr1451 = ptrtoint ptr %mem1450 to i64
  store i64 %ptr1451, ptr %slot18, align 8
  %mem1452 = alloca i8, i64 8, align 8
  %ptr1453 = ptrtoint ptr %mem1452 to i64
  store i64 %ptr1453, ptr %slot19, align 8
  %mem1454 = alloca i8, i64 8, align 8
  %ptr1455 = ptrtoint ptr %mem1454 to i64
  store i64 %ptr1455, ptr %slot20, align 8
  %mem1456 = alloca i8, i64 8, align 8
  %ptr1457 = ptrtoint ptr %mem1456 to i64
  store i64 %ptr1457, ptr %slot21, align 8
  %mem1458 = alloca i8, i64 8, align 8
  %ptr1459 = ptrtoint ptr %mem1458 to i64
  store i64 %ptr1459, ptr %slot22, align 8
  %mem1460 = alloca i8, i64 8, align 8
  %ptr1461 = ptrtoint ptr %mem1460 to i64
  store i64 %ptr1461, ptr %slot23, align 8
  %mem1462 = alloca i8, i64 8, align 8
  %ptr1463 = ptrtoint ptr %mem1462 to i64
  store i64 %ptr1463, ptr %slot24, align 8
  %mem1464 = alloca i8, i64 8, align 8
  %ptr1465 = ptrtoint ptr %mem1464 to i64
  store i64 %ptr1465, ptr %slot25, align 8
  %mem1466 = alloca i8, i64 8, align 8
  %ptr1467 = ptrtoint ptr %mem1466 to i64
  store i64 %ptr1467, ptr %slot26, align 8
  %mem1468 = alloca i8, i64 104, align 8
  %ptr1469 = ptrtoint ptr %mem1468 to i64
  store i64 %ptr1469, ptr %slot27, align 8
  %mem1470 = alloca i8, i64 80, align 8
  %ptr1471 = ptrtoint ptr %mem1470 to i64
  store i64 %ptr1471, ptr %slot28, align 8
  %mem1472 = alloca i8, i64 8, align 8
  %ptr1473 = ptrtoint ptr %mem1472 to i64
  store i64 %ptr1473, ptr %slot29, align 8
  %mem1474 = alloca i8, i64 104, align 8
  %ptr1475 = ptrtoint ptr %mem1474 to i64
  store i64 %ptr1475, ptr %slot30, align 8
  %mem1476 = alloca i8, i64 32, align 8
  %ptr1477 = ptrtoint ptr %mem1476 to i64
  store i64 %ptr1477, ptr %slot31, align 8
  %v1478 = load i64, ptr %slot31, align 8
  %p1480 = inttoptr i64 %v1478 to ptr
  %gep1481 = getelementptr i8, ptr %p1480, i64 24
  %op1479 = ptrtoint ptr %gep1481 to i64
  store i64 %op1479, ptr %slot32, align 8
  %v1482 = load i64, ptr %slot32, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i64 0, ptr %p1483, align 8, !alias.scope !3, !noalias !4
  %mem1484 = alloca i8, i64 8, align 8
  %ptr1485 = ptrtoint ptr %mem1484 to i64
  store i64 %ptr1485, ptr %slot33, align 8
  %mem1486 = alloca i8, i64 8, align 8
  %ptr1487 = ptrtoint ptr %mem1486 to i64
  store i64 %ptr1487, ptr %slot34, align 8
  %mem1488 = alloca i8, i64 8, align 8
  %ptr1489 = ptrtoint ptr %mem1488 to i64
  store i64 %ptr1489, ptr %slot35, align 8
  %mem1490 = alloca i8, i64 8, align 8
  %ptr1491 = ptrtoint ptr %mem1490 to i64
  store i64 %ptr1491, ptr %slot36, align 8
  %mem1492 = alloca i8, i64 8, align 8
  %ptr1493 = ptrtoint ptr %mem1492 to i64
  store i64 %ptr1493, ptr %slot37, align 8
  %mem1494 = alloca i8, i64 104, align 8
  %ptr1495 = ptrtoint ptr %mem1494 to i64
  store i64 %ptr1495, ptr %slot38, align 8
  %mem1496 = alloca i8, i64 8, align 8
  %ptr1497 = ptrtoint ptr %mem1496 to i64
  store i64 %ptr1497, ptr %slot39, align 8
  %mem1498 = alloca i8, i64 8, align 8
  %ptr1499 = ptrtoint ptr %mem1498 to i64
  store i64 %ptr1499, ptr %slot40, align 8
  %mem1500 = alloca i8, i64 8, align 8
  %ptr1501 = ptrtoint ptr %mem1500 to i64
  store i64 %ptr1501, ptr %slot41, align 8
  %mem1502 = alloca i8, i64 80, align 8
  %ptr1503 = ptrtoint ptr %mem1502 to i64
  store i64 %ptr1503, ptr %slot42, align 8
  %mem1504 = alloca i8, i64 8, align 8
  %ptr1505 = ptrtoint ptr %mem1504 to i64
  store i64 %ptr1505, ptr %slot43, align 8
  %mem1506 = alloca i8, i64 8, align 8
  %ptr1507 = ptrtoint ptr %mem1506 to i64
  store i64 %ptr1507, ptr %slot44, align 8
  %mem1508 = alloca i8, i64 8, align 8
  %ptr1509 = ptrtoint ptr %mem1508 to i64
  store i64 %ptr1509, ptr %slot45, align 8
  %mem1510 = alloca i8, i64 48, align 8
  %ptr1511 = ptrtoint ptr %mem1510 to i64
  store i64 %ptr1511, ptr %slot46, align 8
  %mem1512 = alloca i8, i64 8, align 8
  %ptr1513 = ptrtoint ptr %mem1512 to i64
  store i64 %ptr1513, ptr %slot47, align 8
  %mem1514 = alloca i8, i64 8, align 8
  %ptr1515 = ptrtoint ptr %mem1514 to i64
  store i64 %ptr1515, ptr %slot48, align 8
  %mem1516 = alloca i8, i64 8, align 8
  %ptr1517 = ptrtoint ptr %mem1516 to i64
  store i64 %ptr1517, ptr %slot49, align 8
  %mem1518 = alloca i8, i64 8, align 8
  %ptr1519 = ptrtoint ptr %mem1518 to i64
  store i64 %ptr1519, ptr %slot50, align 8
  %mem1520 = alloca i8, i64 8, align 8
  %ptr1521 = ptrtoint ptr %mem1520 to i64
  store i64 %ptr1521, ptr %slot51, align 8
  %mem1522 = alloca i8, i64 8, align 8
  %ptr1523 = ptrtoint ptr %mem1522 to i64
  store i64 %ptr1523, ptr %slot52, align 8
  %mem1524 = alloca i8, i64 8, align 8
  %ptr1525 = ptrtoint ptr %mem1524 to i64
  store i64 %ptr1525, ptr %slot53, align 8
  %mem1526 = alloca i8, i64 80, align 8
  %ptr1527 = ptrtoint ptr %mem1526 to i64
  store i64 %ptr1527, ptr %slot54, align 8
  %mem1528 = alloca i8, i64 8, align 8
  %ptr1529 = ptrtoint ptr %mem1528 to i64
  store i64 %ptr1529, ptr %slot55, align 8
  %mem1530 = alloca i8, i64 104, align 8
  %ptr1531 = ptrtoint ptr %mem1530 to i64
  store i64 %ptr1531, ptr %slot56, align 8
  %mem1532 = alloca i8, i64 8, align 8
  %ptr1533 = ptrtoint ptr %mem1532 to i64
  store i64 %ptr1533, ptr %slot57, align 8
  %mem1534 = alloca i8, i64 8, align 8
  %ptr1535 = ptrtoint ptr %mem1534 to i64
  store i64 %ptr1535, ptr %slot58, align 8
  %mem1536 = alloca i8, i64 8, align 8
  %ptr1537 = ptrtoint ptr %mem1536 to i64
  store i64 %ptr1537, ptr %slot59, align 8
  %mem1538 = alloca i8, i64 8, align 8
  %ptr1539 = ptrtoint ptr %mem1538 to i64
  store i64 %ptr1539, ptr %slot60, align 8
  %mem1540 = alloca i8, i64 8, align 8
  %ptr1541 = ptrtoint ptr %mem1540 to i64
  store i64 %ptr1541, ptr %slot61, align 8
  %mem1542 = alloca i8, i64 8, align 8
  %ptr1543 = ptrtoint ptr %mem1542 to i64
  store i64 %ptr1543, ptr %slot62, align 8
  %mem1544 = alloca i8, i64 104, align 8
  %ptr1545 = ptrtoint ptr %mem1544 to i64
  store i64 %ptr1545, ptr %slot63, align 8
  %mem1546 = alloca i8, i64 80, align 8
  %ptr1547 = ptrtoint ptr %mem1546 to i64
  store i64 %ptr1547, ptr %slot64, align 8
  %mem1548 = alloca i8, i64 104, align 8
  %ptr1549 = ptrtoint ptr %mem1548 to i64
  store i64 %ptr1549, ptr %slot65, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem1550 = alloca i8, i64 8, align 8
  %ptr1551 = ptrtoint ptr %mem1550 to i64
  store i64 %ptr1551, ptr %slot66, align 8
  %v1552 = load i64, ptr %slot1, align 8
  %op1553 = add i64 %v1552, 64
  store i64 %op1553, ptr %slot67, align 8
  %v1554 = load i64, ptr %slot67, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i64, ptr %p1555, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1556, ptr %slot68, align 8
  %stack1557 = call ptr @llvm.stacksave()
  %stackaddr1558 = ptrtoint ptr %stack1557 to i64
  %v1559 = load i64, ptr %slot68, align 8
  %cmp1560 = icmp ult i64 %stackaddr1558, %v1559
  %cv1561 = zext i1 %cmp1560 to i64
  store i64 %cv1561, ptr %slot69, align 8
  %v1562 = load i64, ptr %slot69, align 8
  %cond1563 = icmp ne i64 %v1562, 0
  br i1 %cond1563, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v1564 = load i64, ptr %slot1, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  call void @myl_qbe_fail_frame(ptr %p1565) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %mem1566 = alloca i8, i64 80, align 8
  %ptr1567 = ptrtoint ptr %mem1566 to i64
  store i64 %ptr1567, ptr %slot70, align 8
  %v1568 = load i64, ptr %slot40, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  store i64 0, ptr %p1569, align 8, !alias.scope !3, !noalias !4
  %v1570 = load i64, ptr %slot43, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  store i64 0, ptr %p1571, align 8, !alias.scope !3, !noalias !4
  %v1572 = load i64, ptr %slot47, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i64 0, ptr %p1573, align 8, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot51, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 0, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot2, align 8
  %v1577 = load i64, ptr %slot34, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i64 %v1576, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot3, align 8
  %v1580 = load i64, ptr %slot35, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  store i64 %v1579, ptr %p1581, align 8, !alias.scope !3, !noalias !4
  %v1582 = load i64, ptr %slot4, align 8
  %v1583 = load i64, ptr %slot36, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i64 %v1582, ptr %p1584, align 8, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot1, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %call1587 = call ptr @myl_qbe_heap(ptr %p1586) nomerge, !dbg !112
  %calladdr1588 = ptrtoint ptr %call1587 to i64
  store i64 %calladdr1588, ptr %slot71, align 8
  %v1589 = load i64, ptr %slot1, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %call1591 = call i64 @myl_qbe_region_mark(ptr %p1590) nomerge, !dbg !112
  store i64 %call1591, ptr %slot72, align 8
  %v1592 = load i64, ptr %slot6, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i32 0, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  %v1594 = load i64, ptr %slot7, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  store i32 0, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  %v1596 = load i64, ptr %slot8, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  store i32 0, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  %v1598 = load i64, ptr %slot9, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i32 0, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot10, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i32 0, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot11, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i32 0, ptr %p1603, align 4, !alias.scope !3, !noalias !4
  %v1604 = load i64, ptr %slot12, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i32 0, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot13, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i32 0, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  %v1608 = load i64, ptr %slot14, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  store i32 0, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  %v1610 = load i64, ptr %slot15, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i32 0, ptr %p1611, align 4, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot16, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot17, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot18, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i32 0, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot19, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 0, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot20, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 0, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot21, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot22, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 0, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot23, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 0, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot24, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 0, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot25, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 0, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot26, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  store i32 0, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  %v1634 = load i64, ptr %slot7, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i32 2, ptr %p1635, align 4, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot9, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i32 2, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot11, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 2, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot13, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i32 2, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot15, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 2, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot17, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  store i32 2, ptr %p1645, align 4, !alias.scope !3, !noalias !4
  %v1646 = load i64, ptr %slot19, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i32 2, ptr %p1647, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1648 = load i64, ptr %slot34, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot73, align 8
  %v1651 = load i64, ptr %slot73, align 8
  %v1652 = load i64, ptr %slot58, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  store i64 %v1651, ptr %p1653, align 8, !alias.scope !3, !noalias !4
  %v1654 = load i64, ptr %slot58, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i64, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1656, ptr %slot74, align 8
  %v1657 = load i64, ptr %slot74, align 8
  %op1658 = add i64 %v1657, 88
  store i64 %op1658, ptr %slot75, align 8
  %v1659 = load i64, ptr %slot75, align 8
  %v1660 = load i64, ptr %slot58, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  store i64 %v1659, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  %v1662 = load i64, ptr %slot20, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %ld1664 = load i32, ptr %p1663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1664, ptr %slot76, align 8
  %v1665 = load i32, ptr %slot76, align 8
  %cv1666 = zext i32 %v1665 to i64
  %cond1667 = icmp ne i64 %cv1666, 0
  br i1 %cond1667, label %bb_rcslotdrop23, label %bb_rcslotdone23
bb_rcslotdrop23:
  %v1668 = load i64, ptr %slot20, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  store i32 0, ptr %p1669, align 4, !alias.scope !3, !noalias !4
  %v1670 = load i64, ptr %slot27, align 8
  store i64 %v1670, ptr %slot77, align 8
  %v1671 = load i64, ptr %slot21, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i32, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1673, ptr %slot78, align 8
  %v1674 = load i32, ptr %slot78, align 8
  %op1675 = and i32 %v1674, 28
  store i32 %op1675, ptr %slot79, align 8
  %v1676 = load i32, ptr %slot79, align 8
  %cv1677 = zext i32 %v1676 to i64
  %cond1678 = icmp ne i64 %cv1677, 0
  br i1 %cond1678, label %bb_rcslotrole23, label %bb_rcslotowner23
bb_rcslotrole23:
  %v1679 = load i64, ptr %slot71, align 8
  store i64 %v1679, ptr %slot80, align 8
  %v1680 = load i64, ptr %slot80, align 8
  %v1681 = load i64, ptr %slot77, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1680, i64 %v1681) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotowner23:
  %v1682 = load i64, ptr %slot71, align 8
  store i64 %v1682, ptr %slot81, align 8
  %v1683 = load i64, ptr %slot81, align 8
  %v1684 = load i64, ptr %slot77, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1683, i64 %v1684) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotdone23:
  %v1685 = load i64, ptr %slot58, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %ld1687 = load i64, ptr %p1686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1687, ptr %slot82, align 8
  %v1688 = load i64, ptr %slot82, align 8
  %v1689 = load i64, ptr %slot37, align 8
  %p1690 = inttoptr i64 %v1688 to ptr
  %p1691 = inttoptr i64 %v1689 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1691, ptr %p1690, i64 4, i1 false), !alias.scope !10000000
  %v1692 = load i64, ptr %slot36, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i64, ptr %p1693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1694, ptr %slot83, align 8
  %v1695 = load i64, ptr %slot83, align 8
  %v1696 = load i64, ptr %slot58, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i64 %v1695, ptr %p1697, align 8, !alias.scope !3, !noalias !4
  %v1698 = load i64, ptr %slot58, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i64, ptr %p1699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1700, ptr %slot84, align 8
  %v1701 = load i64, ptr %slot84, align 8
  %v1702 = load i64, ptr %slot39, align 8
  %p1703 = inttoptr i64 %v1701 to ptr
  %p1704 = inttoptr i64 %v1702 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1704, ptr %p1703, i64 4, i1 false), !alias.scope !10000000
  %v1705 = load i64, ptr %slot34, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %ld1707 = load i64, ptr %p1706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1707, ptr %slot85, align 8
  %v1708 = load i64, ptr %slot85, align 8
  %v1709 = load i64, ptr %slot58, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i64 %v1708, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot58, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i64, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1713, ptr %slot86, align 8
  %v1714 = load i64, ptr %slot20, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  %ld1716 = load i32, ptr %p1715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1716, ptr %slot87, align 8
  %v1717 = load i64, ptr %slot21, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i32, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1719, ptr %slot88, align 8
  %v1720 = load i32, ptr %slot88, align 8
  %op1721 = and i32 %v1720, 24
  store i32 %op1721, ptr %slot88, align 8
  %v1722 = load i32, ptr %slot88, align 8
  %cmp1723 = icmp eq i32 %v1722, 0
  %cv1724 = zext i1 %cmp1723 to i32
  store i32 %cv1724, ptr %slot89, align 8
  %v1725 = load i32, ptr %slot87, align 8
  %v1726 = load i32, ptr %slot89, align 8
  %op1727 = and i32 %v1725, %v1726
  store i32 %op1727, ptr %slot90, align 8
  %v1728 = load i32, ptr %slot90, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcprivateown41, label %bb_rcprivateloan41
bb_rcprivateown41:
  %v1731 = load i64, ptr %slot30, align 8
  store i64 %v1731, ptr %slot91, align 8
  %v1732 = load i64, ptr %slot72, align 8
  store i64 %v1732, ptr %slot92, align 8
  %v1733 = load i64, ptr %slot71, align 8
  %v1734 = load i64, ptr %slot91, align 8
  %v1735 = load i64, ptr %slot86, align 8
  %v1736 = load i64, ptr %slot92, align 8
  %cv1737 = trunc i64 %v1736 to i32
  %call1738 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v1733, i64 %v1734, i64 %v1735, i32 %cv1737) nomerge, !dbg !116
  store i32 %call1738, ptr %slot93, align 8
  %v1739 = load i32, ptr %slot93, align 8
  %cv1740 = zext i32 %v1739 to i64
  %cond1741 = icmp ne i64 %cv1740, 0
  br i1 %cond1741, label %bb_rcsuccess45, label %bb_rcfailure45
bb_rcfailure45:
  %v1742 = load i64, ptr %slot71, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %call1744 = call i32 @myl_rc_take_failure(ptr %p1743) nomerge, !dbg !116
  store i32 %call1744, ptr %slot94, align 8
  %v1745 = load i64, ptr %slot1, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  %v1747 = load i32, ptr %slot94, align 8
  %call1748 = call i32 @myl_qbe_rc_status(ptr %p1746, i32 %v1747) nomerge, !dbg !116
  store i32 %call1748, ptr %slot95, align 8
  br label %bb_failure
bb_rcsuccess45:
  %v1749 = load i64, ptr %slot20, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i32 0, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot25, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  store i32 2, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  %v1753 = load i64, ptr %slot24, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i32 1, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared41
bb_rcprivateloan41:
  %v1755 = load i64, ptr %slot30, align 8
  store i64 %v1755, ptr %slot96, align 8
  %v1756 = load i64, ptr %slot71, align 8
  %v1757 = load i64, ptr %slot96, align 8
  %v1758 = load i64, ptr %slot86, align 8
  %call1759 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_loan(i64 %v1756, i64 %v1757, i64 %v1758) nomerge, !dbg !116
  store i32 %call1759, ptr %slot97, align 8
  %v1760 = load i32, ptr %slot97, align 8
  %cv1761 = zext i32 %v1760 to i64
  %cond1762 = icmp ne i64 %cv1761, 0
  br i1 %cond1762, label %bb_rcsuccess53, label %bb_rcfailure53
bb_rcfailure53:
  %v1763 = load i64, ptr %slot71, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %call1765 = call i32 @myl_rc_take_failure(ptr %p1764) nomerge, !dbg !116
  store i32 %call1765, ptr %slot98, align 8
  %v1766 = load i64, ptr %slot1, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %v1768 = load i32, ptr %slot98, align 8
  %call1769 = call i32 @myl_qbe_rc_status(ptr %p1767, i32 %v1768) nomerge, !dbg !116
  store i32 %call1769, ptr %slot99, align 8
  br label %bb_failure
bb_rcsuccess53:
  %v1770 = load i64, ptr %slot25, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  store i32 2, ptr %p1771, align 4, !alias.scope !3, !noalias !4
  %v1772 = load i64, ptr %slot25, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  store i32 16, ptr %p1773, align 4, !alias.scope !3, !noalias !4
  %v1774 = load i64, ptr %slot24, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  store i32 1, ptr %p1775, align 4, !alias.scope !3, !noalias !4
  %v1776 = load i64, ptr %slot20, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %ld1778 = load i32, ptr %p1777, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1778, ptr %slot100, align 8
  %v1779 = load i32, ptr %slot100, align 8
  %cv1780 = zext i32 %v1779 to i64
  %cond1781 = icmp ne i64 %cv1780, 0
  br i1 %cond1781, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v1782 = load i64, ptr %slot20, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  store i32 0, ptr %p1783, align 4, !alias.scope !3, !noalias !4
  %v1784 = load i64, ptr %slot27, align 8
  store i64 %v1784, ptr %slot101, align 8
  %v1785 = load i64, ptr %slot21, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  %ld1787 = load i32, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1787, ptr %slot102, align 8
  %v1788 = load i32, ptr %slot102, align 8
  %op1789 = and i32 %v1788, 28
  store i32 %op1789, ptr %slot103, align 8
  %v1790 = load i32, ptr %slot103, align 8
  %cv1791 = zext i32 %v1790 to i64
  %cond1792 = icmp ne i64 %cv1791, 0
  br i1 %cond1792, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v1793 = load i64, ptr %slot71, align 8
  store i64 %v1793, ptr %slot104, align 8
  %v1794 = load i64, ptr %slot104, align 8
  %v1795 = load i64, ptr %slot101, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1794, i64 %v1795) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v1796 = load i64, ptr %slot71, align 8
  store i64 %v1796, ptr %slot105, align 8
  %v1797 = load i64, ptr %slot105, align 8
  %v1798 = load i64, ptr %slot101, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1797, i64 %v1798) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotdone61:
  br label %bb_rcprivateprepared41
bb_rcprivateprepared41:
  %v1799 = load i64, ptr %slot6, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %ld1801 = load i32, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1801, ptr %slot106, align 8
  %v1802 = load i32, ptr %slot106, align 8
  %cv1803 = zext i32 %v1802 to i64
  %cond1804 = icmp ne i64 %cv1803, 0
  br i1 %cond1804, label %bb_rcslotdrop71, label %bb_rcslotdone71
bb_rcslotdrop71:
  %v1805 = load i64, ptr %slot6, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i32 0, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot38, align 8
  store i64 %v1807, ptr %slot107, align 8
  %v1808 = load i64, ptr %slot7, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %ld1810 = load i32, ptr %p1809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1810, ptr %slot108, align 8
  %v1811 = load i32, ptr %slot108, align 8
  %op1812 = and i32 %v1811, 28
  store i32 %op1812, ptr %slot109, align 8
  %v1813 = load i32, ptr %slot109, align 8
  %cv1814 = zext i32 %v1813 to i64
  %cond1815 = icmp ne i64 %cv1814, 0
  br i1 %cond1815, label %bb_rcslotrole71, label %bb_rcslotowner71
bb_rcslotrole71:
  %v1816 = load i64, ptr %slot71, align 8
  store i64 %v1816, ptr %slot110, align 8
  %v1817 = load i64, ptr %slot110, align 8
  %v1818 = load i64, ptr %slot107, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1817, i64 %v1818) nomerge, !dbg !116
  br label %bb_rcslotdone71
bb_rcslotowner71:
  %v1819 = load i64, ptr %slot71, align 8
  store i64 %v1819, ptr %slot111, align 8
  %v1820 = load i64, ptr %slot111, align 8
  %v1821 = load i64, ptr %slot107, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1820, i64 %v1821) nomerge, !dbg !116
  br label %bb_rcslotdone71
bb_rcslotdone71:
  %v1822 = load i64, ptr %slot38, align 8
  store i64 %v1822, ptr %slot112, align 8
  %v1823 = load i64, ptr %slot30, align 8
  store i64 %v1823, ptr %slot113, align 8
  %v1824 = load i64, ptr %slot113, align 8
  %v1825 = load i64, ptr %slot112, align 8
  %p1826 = inttoptr i64 %v1824 to ptr
  %p1827 = inttoptr i64 %v1825 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1827, ptr %p1826, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v1828 = load i64, ptr %slot24, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i32 0, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot7, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  store i32 2, ptr %p1831, align 4, !alias.scope !3, !noalias !4
  %v1832 = load i64, ptr %slot25, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %ld1834 = load i32, ptr %p1833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1834, ptr %slot114, align 8
  %v1835 = load i32, ptr %slot114, align 8
  %v1836 = load i64, ptr %slot7, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i32 %v1835, ptr %p1837, align 4, !alias.scope !3, !noalias !4
  %v1838 = load i64, ptr %slot6, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  store i32 1, ptr %p1839, align 4, !alias.scope !3, !noalias !4
  %v1840 = load i64, ptr %slot34, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %ld1842 = load i64, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1842, ptr %slot115, align 8
  %v1843 = load i64, ptr %slot115, align 8
  %v1844 = load i64, ptr %slot58, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  store i64 %v1843, ptr %p1845, align 8, !alias.scope !3, !noalias !4
  %v1846 = load i64, ptr %slot58, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %ld1848 = load i64, ptr %p1847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1848, ptr %slot116, align 8
  %v1849 = load i64, ptr %slot20, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i32, ptr %p1850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1851, ptr %slot117, align 8
  %v1852 = load i64, ptr %slot21, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i32, ptr %p1853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1854, ptr %slot118, align 8
  %v1855 = load i32, ptr %slot118, align 8
  %op1856 = and i32 %v1855, 24
  store i32 %op1856, ptr %slot118, align 8
  %v1857 = load i32, ptr %slot118, align 8
  %cmp1858 = icmp eq i32 %v1857, 0
  %cv1859 = zext i1 %cmp1858 to i32
  store i32 %cv1859, ptr %slot119, align 8
  %v1860 = load i32, ptr %slot117, align 8
  %v1861 = load i32, ptr %slot119, align 8
  %op1862 = and i32 %v1860, %v1861
  store i32 %op1862, ptr %slot120, align 8
  %v1863 = load i32, ptr %slot120, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcprivateown93, label %bb_rcprivateloan93
bb_rcprivateown93:
  %v1866 = load i64, ptr %slot30, align 8
  store i64 %v1866, ptr %slot121, align 8
  %v1867 = load i64, ptr %slot72, align 8
  store i64 %v1867, ptr %slot122, align 8
  %v1868 = load i64, ptr %slot71, align 8
  %v1869 = load i64, ptr %slot121, align 8
  %v1870 = load i64, ptr %slot116, align 8
  %v1871 = load i64, ptr %slot122, align 8
  %cv1872 = trunc i64 %v1871 to i32
  %call1873 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v1868, i64 %v1869, i64 %v1870, i32 %cv1872) nomerge, !dbg !118
  store i32 %call1873, ptr %slot123, align 8
  %v1874 = load i32, ptr %slot123, align 8
  %cv1875 = zext i32 %v1874 to i64
  %cond1876 = icmp ne i64 %cv1875, 0
  br i1 %cond1876, label %bb_rcsuccess97, label %bb_rcfailure97
bb_rcfailure97:
  %v1877 = load i64, ptr %slot71, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %call1879 = call i32 @myl_rc_take_failure(ptr %p1878) nomerge, !dbg !118
  store i32 %call1879, ptr %slot124, align 8
  %v1880 = load i64, ptr %slot1, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %v1882 = load i32, ptr %slot124, align 8
  %call1883 = call i32 @myl_qbe_rc_status(ptr %p1881, i32 %v1882) nomerge, !dbg !118
  store i32 %call1883, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess97:
  %v1884 = load i64, ptr %slot20, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 0, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot25, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 2, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot24, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 1, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared93
bb_rcprivateloan93:
  %v1890 = load i64, ptr %slot30, align 8
  store i64 %v1890, ptr %slot126, align 8
  %v1891 = load i64, ptr %slot71, align 8
  %v1892 = load i64, ptr %slot126, align 8
  %v1893 = load i64, ptr %slot116, align 8
  %call1894 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_loan(i64 %v1891, i64 %v1892, i64 %v1893) nomerge, !dbg !118
  store i32 %call1894, ptr %slot127, align 8
  %v1895 = load i32, ptr %slot127, align 8
  %cv1896 = zext i32 %v1895 to i64
  %cond1897 = icmp ne i64 %cv1896, 0
  br i1 %cond1897, label %bb_rcsuccess105, label %bb_rcfailure105
bb_rcfailure105:
  %v1898 = load i64, ptr %slot71, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %call1900 = call i32 @myl_rc_take_failure(ptr %p1899) nomerge, !dbg !118
  store i32 %call1900, ptr %slot128, align 8
  %v1901 = load i64, ptr %slot1, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  %v1903 = load i32, ptr %slot128, align 8
  %call1904 = call i32 @myl_qbe_rc_status(ptr %p1902, i32 %v1903) nomerge, !dbg !118
  store i32 %call1904, ptr %slot129, align 8
  br label %bb_failure
bb_rcsuccess105:
  %v1905 = load i64, ptr %slot25, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i32 2, ptr %p1906, align 4, !alias.scope !3, !noalias !4
  %v1907 = load i64, ptr %slot25, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i32 16, ptr %p1908, align 4, !alias.scope !3, !noalias !4
  %v1909 = load i64, ptr %slot24, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i32 1, ptr %p1910, align 4, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot20, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %ld1913 = load i32, ptr %p1912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1913, ptr %slot130, align 8
  %v1914 = load i32, ptr %slot130, align 8
  %cv1915 = zext i32 %v1914 to i64
  %cond1916 = icmp ne i64 %cv1915, 0
  br i1 %cond1916, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v1917 = load i64, ptr %slot20, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i32 0, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot27, align 8
  store i64 %v1919, ptr %slot131, align 8
  %v1920 = load i64, ptr %slot21, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  %ld1922 = load i32, ptr %p1921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1922, ptr %slot132, align 8
  %v1923 = load i32, ptr %slot132, align 8
  %op1924 = and i32 %v1923, 28
  store i32 %op1924, ptr %slot133, align 8
  %v1925 = load i32, ptr %slot133, align 8
  %cv1926 = zext i32 %v1925 to i64
  %cond1927 = icmp ne i64 %cv1926, 0
  br i1 %cond1927, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v1928 = load i64, ptr %slot71, align 8
  store i64 %v1928, ptr %slot134, align 8
  %v1929 = load i64, ptr %slot134, align 8
  %v1930 = load i64, ptr %slot131, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1929, i64 %v1930) nomerge, !dbg !118
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v1931 = load i64, ptr %slot71, align 8
  store i64 %v1931, ptr %slot135, align 8
  %v1932 = load i64, ptr %slot135, align 8
  %v1933 = load i64, ptr %slot131, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1932, i64 %v1933) nomerge, !dbg !118
  br label %bb_rcslotdone113
bb_rcslotdone113:
  br label %bb_rcprivateprepared93
bb_rcprivateprepared93:
  %v1934 = load i64, ptr %slot6, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  %ld1936 = load i32, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1936, ptr %slot136, align 8
  %v1937 = load i32, ptr %slot136, align 8
  %cv1938 = zext i32 %v1937 to i64
  %cond1939 = icmp ne i64 %cv1938, 0
  br i1 %cond1939, label %bb_rcslotdrop123, label %bb_rcslotdone123
bb_rcslotdrop123:
  %v1940 = load i64, ptr %slot6, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i32 0, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot38, align 8
  store i64 %v1942, ptr %slot137, align 8
  %v1943 = load i64, ptr %slot7, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %ld1945 = load i32, ptr %p1944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1945, ptr %slot138, align 8
  %v1946 = load i32, ptr %slot138, align 8
  %op1947 = and i32 %v1946, 28
  store i32 %op1947, ptr %slot139, align 8
  %v1948 = load i32, ptr %slot139, align 8
  %cv1949 = zext i32 %v1948 to i64
  %cond1950 = icmp ne i64 %cv1949, 0
  br i1 %cond1950, label %bb_rcslotrole123, label %bb_rcslotowner123
bb_rcslotrole123:
  %v1951 = load i64, ptr %slot71, align 8
  store i64 %v1951, ptr %slot140, align 8
  %v1952 = load i64, ptr %slot140, align 8
  %v1953 = load i64, ptr %slot137, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v1952, i64 %v1953) nomerge, !dbg !118
  br label %bb_rcslotdone123
bb_rcslotowner123:
  %v1954 = load i64, ptr %slot71, align 8
  store i64 %v1954, ptr %slot141, align 8
  %v1955 = load i64, ptr %slot141, align 8
  %v1956 = load i64, ptr %slot137, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v1955, i64 %v1956) nomerge, !dbg !118
  br label %bb_rcslotdone123
bb_rcslotdone123:
  %v1957 = load i64, ptr %slot38, align 8
  store i64 %v1957, ptr %slot142, align 8
  %v1958 = load i64, ptr %slot30, align 8
  store i64 %v1958, ptr %slot143, align 8
  %v1959 = load i64, ptr %slot143, align 8
  %v1960 = load i64, ptr %slot142, align 8
  %p1961 = inttoptr i64 %v1959 to ptr
  %p1962 = inttoptr i64 %v1960 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1962, ptr %p1961, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v1963 = load i64, ptr %slot24, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  store i32 0, ptr %p1964, align 4, !alias.scope !3, !noalias !4
  %v1965 = load i64, ptr %slot7, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i32 2, ptr %p1966, align 4, !alias.scope !3, !noalias !4
  %v1967 = load i64, ptr %slot25, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %ld1969 = load i32, ptr %p1968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1969, ptr %slot144, align 8
  %v1970 = load i32, ptr %slot144, align 8
  %v1971 = load i64, ptr %slot7, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  store i32 %v1970, ptr %p1972, align 4, !alias.scope !3, !noalias !4
  %v1973 = load i64, ptr %slot6, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  store i32 1, ptr %p1974, align 4, !alias.scope !3, !noalias !4
  %v1975 = load i64, ptr %slot38, align 8
  %v1976 = load i64, ptr %slot58, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  store i64 %v1975, ptr %p1977, align 8, !alias.scope !3, !noalias !4
  %v1978 = load i64, ptr %slot39, align 8
  %v1979 = load i64, ptr %slot59, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  store i64 %v1978, ptr %p1980, align 8, !alias.scope !3, !noalias !4
  %v1981 = load i64, ptr %slot58, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %ld1983 = load i64, ptr %p1982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1983, ptr %slot145, align 8
  %v1984 = load i64, ptr %slot20, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i32, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1986, ptr %slot146, align 8
  %v1987 = load i64, ptr %slot21, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %ld1989 = load i32, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1989, ptr %slot147, align 8
  %v1990 = load i32, ptr %slot147, align 8
  %op1991 = and i32 %v1990, 24
  store i32 %op1991, ptr %slot147, align 8
  %v1992 = load i32, ptr %slot147, align 8
  %cmp1993 = icmp eq i32 %v1992, 0
  %cv1994 = zext i1 %cmp1993 to i32
  store i32 %cv1994, ptr %slot148, align 8
  %v1995 = load i32, ptr %slot146, align 8
  %v1996 = load i32, ptr %slot148, align 8
  %op1997 = and i32 %v1995, %v1996
  store i32 %op1997, ptr %slot149, align 8
  %v1998 = load i32, ptr %slot149, align 8
  %cv1999 = zext i32 %v1998 to i64
  %cond2000 = icmp ne i64 %cv1999, 0
  br i1 %cond2000, label %bb_rctake138, label %bb_rccopy138
bb_rctake138:
  %v2001 = load i64, ptr %slot30, align 8
  store i64 %v2001, ptr %slot150, align 8
  %v2002 = load i64, ptr %slot72, align 8
  store i64 %v2002, ptr %slot151, align 8
  %v2003 = load i64, ptr %slot71, align 8
  %v2004 = load i64, ptr %slot150, align 8
  %v2005 = load i64, ptr %slot145, align 8
  %v2006 = load i64, ptr %slot151, align 8
  %cv2007 = trunc i64 %v2006 to i32
  %call2008 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v2003, i64 %v2004, i64 %v2005, i32 %cv2007) nomerge, !dbg !120
  store i32 %call2008, ptr %slot152, align 8
  %v2009 = load i32, ptr %slot152, align 8
  %cv2010 = zext i32 %v2009 to i64
  %cond2011 = icmp ne i64 %cv2010, 0
  br i1 %cond2011, label %bb_rcsuccess148, label %bb_rcfailure148
bb_rcfailure148:
  %v2012 = load i64, ptr %slot71, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %call2014 = call i32 @myl_rc_take_failure(ptr %p2013) nomerge, !dbg !120
  store i32 %call2014, ptr %slot153, align 8
  %v2015 = load i64, ptr %slot1, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  %v2017 = load i32, ptr %slot153, align 8
  %call2018 = call i32 @myl_qbe_rc_status(ptr %p2016, i32 %v2017) nomerge, !dbg !120
  store i32 %call2018, ptr %slot154, align 8
  br label %bb_failure
bb_rcsuccess148:
  %v2019 = load i64, ptr %slot20, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i32 0, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot25, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  store i32 2, ptr %p2022, align 4, !alias.scope !3, !noalias !4
  %v2023 = load i64, ptr %slot24, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 1, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared138
bb_rccopy138:
  %v2025 = load i64, ptr %slot30, align 8
  store i64 %v2025, ptr %slot155, align 8
  %v2026 = load i64, ptr %slot72, align 8
  store i64 %v2026, ptr %slot156, align 8
  %v2027 = load i64, ptr %slot71, align 8
  %v2028 = load i64, ptr %slot155, align 8
  %v2029 = load i64, ptr %slot145, align 8
  %v2030 = load i64, ptr %slot156, align 8
  %cv2031 = trunc i64 %v2030 to i32
  %call2032 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_retain(i64 %v2027, i64 %v2028, i64 %v2029, i32 %cv2031) nomerge, !dbg !120
  store i32 %call2032, ptr %slot157, align 8
  %v2033 = load i32, ptr %slot157, align 8
  %cv2034 = zext i32 %v2033 to i64
  %cond2035 = icmp ne i64 %cv2034, 0
  br i1 %cond2035, label %bb_rcsuccess157, label %bb_rcfailure157
bb_rcfailure157:
  %v2036 = load i64, ptr %slot71, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %call2038 = call i32 @myl_rc_take_failure(ptr %p2037) nomerge, !dbg !120
  store i32 %call2038, ptr %slot158, align 8
  %v2039 = load i64, ptr %slot1, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %v2041 = load i32, ptr %slot158, align 8
  %call2042 = call i32 @myl_qbe_rc_status(ptr %p2040, i32 %v2041) nomerge, !dbg !120
  store i32 %call2042, ptr %slot159, align 8
  br label %bb_failure
bb_rcsuccess157:
  %v2043 = load i64, ptr %slot25, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  store i32 2, ptr %p2044, align 4, !alias.scope !3, !noalias !4
  %v2045 = load i64, ptr %slot24, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i32 1, ptr %p2046, align 4, !alias.scope !3, !noalias !4
  %v2047 = load i64, ptr %slot20, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  %ld2049 = load i32, ptr %p2048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2049, ptr %slot160, align 8
  %v2050 = load i32, ptr %slot160, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v2053 = load i64, ptr %slot20, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i32 0, ptr %p2054, align 4, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot27, align 8
  store i64 %v2055, ptr %slot161, align 8
  %v2056 = load i64, ptr %slot21, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  %ld2058 = load i32, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2058, ptr %slot162, align 8
  %v2059 = load i32, ptr %slot162, align 8
  %op2060 = and i32 %v2059, 28
  store i32 %op2060, ptr %slot163, align 8
  %v2061 = load i32, ptr %slot163, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v2064 = load i64, ptr %slot71, align 8
  store i64 %v2064, ptr %slot164, align 8
  %v2065 = load i64, ptr %slot164, align 8
  %v2066 = load i64, ptr %slot161, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2065, i64 %v2066) nomerge, !dbg !120
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v2067 = load i64, ptr %slot71, align 8
  store i64 %v2067, ptr %slot165, align 8
  %v2068 = load i64, ptr %slot165, align 8
  %v2069 = load i64, ptr %slot161, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2068, i64 %v2069) nomerge, !dbg !120
  br label %bb_rcslotdone164
bb_rcslotdone164:
  br label %bb_rcprepared138
bb_rcprepared138:
  %v2070 = load i64, ptr %slot30, align 8
  store i64 %v2070, ptr %slot166, align 8
  %v2071 = load i64, ptr %slot63, align 8
  store i64 %v2071, ptr %slot167, align 8
  %v2072 = load i64, ptr %slot166, align 8
  %v2073 = load i64, ptr %slot167, align 8
  %p2074 = inttoptr i64 %v2072 to ptr
  %p2075 = inttoptr i64 %v2073 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2075, ptr %p2074, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot24, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i32 0, ptr %p2077, align 4, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot26, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i32 1, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot72, align 8
  store i64 %v2080, ptr %slot168, align 8
  %v2081 = load i64, ptr %slot59, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  %ld2083 = load i64, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2083, ptr %slot169, align 8
  %v2084 = load i64, ptr %slot167, align 8
  %p2086 = inttoptr i64 %v2084 to ptr
  %gep2087 = getelementptr i8, ptr %p2086, i64 88
  %op2085 = ptrtoint ptr %gep2087 to i64
  store i64 %op2085, ptr %slot170, align 8
  %v2088 = load i64, ptr %slot30, align 8
  store i64 %v2088, ptr %slot171, align 8
  %v2089 = load i64, ptr %slot169, align 8
  %v2090 = load i64, ptr %slot171, align 8
  %p2091 = inttoptr i64 %v2089 to ptr
  %p2092 = inttoptr i64 %v2090 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2092, ptr %p2091, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2093 = load i64, ptr %slot25, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  store i32 0, ptr %p2094, align 4, !alias.scope !3, !noalias !4
  %v2095 = load i64, ptr %slot24, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  store i32 1, ptr %p2096, align 4, !alias.scope !3, !noalias !4
  %v2097 = load i64, ptr %slot171, align 8
  %v2098 = load i64, ptr %slot170, align 8
  %p2099 = inttoptr i64 %v2097 to ptr
  %p2100 = inttoptr i64 %v2098 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2100, ptr %p2099, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot24, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 0, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot167, align 8
  %v2104 = load i64, ptr %slot58, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i64 %v2103, ptr %p2105, align 8, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot58, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  %ld2108 = load i64, ptr %p2107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2108, ptr %slot172, align 8
  %v2109 = load i64, ptr %slot30, align 8
  store i64 %v2109, ptr %slot173, align 8
  %v2110 = load i64, ptr %slot172, align 8
  %v2111 = load i64, ptr %slot173, align 8
  %p2112 = inttoptr i64 %v2110 to ptr
  %p2113 = inttoptr i64 %v2111 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2113, ptr %p2112, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot25, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  store i32 2, ptr %p2115, align 4, !alias.scope !3, !noalias !4
  %v2116 = load i64, ptr %slot24, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  store i32 1, ptr %p2117, align 4, !alias.scope !3, !noalias !4
  %v2118 = load i64, ptr %slot20, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %ld2120 = load i32, ptr %p2119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2120, ptr %slot174, align 8
  %v2121 = load i32, ptr %slot174, align 8
  %cv2122 = zext i32 %v2121 to i64
  %cond2123 = icmp ne i64 %cv2122, 0
  br i1 %cond2123, label %bb_rcslotdrop189, label %bb_rcslotdone189
bb_rcslotdrop189:
  %v2124 = load i64, ptr %slot20, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  store i32 0, ptr %p2125, align 4, !alias.scope !3, !noalias !4
  %v2126 = load i64, ptr %slot27, align 8
  store i64 %v2126, ptr %slot175, align 8
  %v2127 = load i64, ptr %slot21, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %ld2129 = load i32, ptr %p2128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2129, ptr %slot176, align 8
  %v2130 = load i32, ptr %slot176, align 8
  %op2131 = and i32 %v2130, 28
  store i32 %op2131, ptr %slot177, align 8
  %v2132 = load i32, ptr %slot177, align 8
  %cv2133 = zext i32 %v2132 to i64
  %cond2134 = icmp ne i64 %cv2133, 0
  br i1 %cond2134, label %bb_rcslotrole189, label %bb_rcslotowner189
bb_rcslotrole189:
  %v2135 = load i64, ptr %slot71, align 8
  store i64 %v2135, ptr %slot178, align 8
  %v2136 = load i64, ptr %slot178, align 8
  %v2137 = load i64, ptr %slot175, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2136, i64 %v2137) nomerge, !dbg !120
  br label %bb_rcslotdone189
bb_rcslotowner189:
  %v2138 = load i64, ptr %slot71, align 8
  store i64 %v2138, ptr %slot179, align 8
  %v2139 = load i64, ptr %slot179, align 8
  %v2140 = load i64, ptr %slot175, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2139, i64 %v2140) nomerge, !dbg !120
  br label %bb_rcslotdone189
bb_rcslotdone189:
  %v2141 = load i64, ptr %slot27, align 8
  store i64 %v2141, ptr %slot180, align 8
  %v2142 = load i64, ptr %slot30, align 8
  store i64 %v2142, ptr %slot181, align 8
  %v2143 = load i64, ptr %slot181, align 8
  %v2144 = load i64, ptr %slot180, align 8
  %p2145 = inttoptr i64 %v2143 to ptr
  %p2146 = inttoptr i64 %v2144 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2146, ptr %p2145, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v2147 = load i64, ptr %slot21, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  store i32 2, ptr %p2148, align 4, !alias.scope !3, !noalias !4
  %v2149 = load i64, ptr %slot25, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  %ld2151 = load i32, ptr %p2150, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2151, ptr %slot182, align 8
  %v2152 = load i32, ptr %slot182, align 8
  %v2153 = load i64, ptr %slot21, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  store i32 %v2152, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  %v2155 = load i64, ptr %slot24, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  store i32 0, ptr %p2156, align 4, !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot20, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i32 1, ptr %p2158, align 4, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot180, align 8
  %v2160 = load i64, ptr %slot58, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i64 %v2159, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot58, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  %ld2164 = load i64, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2164, ptr %slot183, align 8
  %v2165 = load i64, ptr %slot20, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i32, ptr %p2166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2167, ptr %slot184, align 8
  %v2168 = load i64, ptr %slot21, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i32, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2170, ptr %slot185, align 8
  %v2171 = load i32, ptr %slot185, align 8
  %op2172 = and i32 %v2171, 24
  store i32 %op2172, ptr %slot185, align 8
  %v2173 = load i32, ptr %slot185, align 8
  %cmp2174 = icmp eq i32 %v2173, 0
  %cv2175 = zext i1 %cmp2174 to i32
  store i32 %cv2175, ptr %slot186, align 8
  %v2176 = load i32, ptr %slot184, align 8
  %v2177 = load i32, ptr %slot186, align 8
  %op2178 = and i32 %v2176, %v2177
  store i32 %op2178, ptr %slot187, align 8
  %v2179 = load i32, ptr %slot187, align 8
  %cv2180 = zext i32 %v2179 to i64
  %cond2181 = icmp ne i64 %cv2180, 0
  br i1 %cond2181, label %bb_rctake205, label %bb_rccopy205
bb_rctake205:
  %v2182 = load i64, ptr %slot30, align 8
  store i64 %v2182, ptr %slot188, align 8
  %v2183 = load i64, ptr %slot72, align 8
  store i64 %v2183, ptr %slot189, align 8
  %v2184 = load i64, ptr %slot71, align 8
  %v2185 = load i64, ptr %slot188, align 8
  %v2186 = load i64, ptr %slot183, align 8
  %v2187 = load i64, ptr %slot189, align 8
  %cv2188 = trunc i64 %v2187 to i32
  %call2189 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v2184, i64 %v2185, i64 %v2186, i32 %cv2188) nomerge, !dbg !122
  store i32 %call2189, ptr %slot190, align 8
  %v2190 = load i32, ptr %slot190, align 8
  %cv2191 = zext i32 %v2190 to i64
  %cond2192 = icmp ne i64 %cv2191, 0
  br i1 %cond2192, label %bb_rcsuccess215, label %bb_rcfailure215
bb_rcfailure215:
  %v2193 = load i64, ptr %slot71, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %call2195 = call i32 @myl_rc_take_failure(ptr %p2194) nomerge, !dbg !122
  store i32 %call2195, ptr %slot191, align 8
  %v2196 = load i64, ptr %slot1, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %v2198 = load i32, ptr %slot191, align 8
  %call2199 = call i32 @myl_qbe_rc_status(ptr %p2197, i32 %v2198) nomerge, !dbg !122
  store i32 %call2199, ptr %slot192, align 8
  br label %bb_failure
bb_rcsuccess215:
  %v2200 = load i64, ptr %slot20, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i32 0, ptr %p2201, align 4, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot25, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  store i32 2, ptr %p2203, align 4, !alias.scope !3, !noalias !4
  %v2204 = load i64, ptr %slot24, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  store i32 1, ptr %p2205, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared205
bb_rccopy205:
  %v2206 = load i64, ptr %slot30, align 8
  store i64 %v2206, ptr %slot193, align 8
  %v2207 = load i64, ptr %slot72, align 8
  store i64 %v2207, ptr %slot194, align 8
  %v2208 = load i64, ptr %slot71, align 8
  %v2209 = load i64, ptr %slot193, align 8
  %v2210 = load i64, ptr %slot183, align 8
  %v2211 = load i64, ptr %slot194, align 8
  %cv2212 = trunc i64 %v2211 to i32
  %call2213 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_retain(i64 %v2208, i64 %v2209, i64 %v2210, i32 %cv2212) nomerge, !dbg !122
  store i32 %call2213, ptr %slot195, align 8
  %v2214 = load i32, ptr %slot195, align 8
  %cv2215 = zext i32 %v2214 to i64
  %cond2216 = icmp ne i64 %cv2215, 0
  br i1 %cond2216, label %bb_rcsuccess224, label %bb_rcfailure224
bb_rcfailure224:
  %v2217 = load i64, ptr %slot71, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  %call2219 = call i32 @myl_rc_take_failure(ptr %p2218) nomerge, !dbg !122
  store i32 %call2219, ptr %slot196, align 8
  %v2220 = load i64, ptr %slot1, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %v2222 = load i32, ptr %slot196, align 8
  %call2223 = call i32 @myl_qbe_rc_status(ptr %p2221, i32 %v2222) nomerge, !dbg !122
  store i32 %call2223, ptr %slot197, align 8
  br label %bb_failure
bb_rcsuccess224:
  %v2224 = load i64, ptr %slot25, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  store i32 2, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  %v2226 = load i64, ptr %slot24, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  store i32 1, ptr %p2227, align 4, !alias.scope !3, !noalias !4
  %v2228 = load i64, ptr %slot20, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  %ld2230 = load i32, ptr %p2229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2230, ptr %slot198, align 8
  %v2231 = load i32, ptr %slot198, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcslotdrop231, label %bb_rcslotdone231
bb_rcslotdrop231:
  %v2234 = load i64, ptr %slot20, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i32 0, ptr %p2235, align 4, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot27, align 8
  store i64 %v2236, ptr %slot199, align 8
  %v2237 = load i64, ptr %slot21, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %ld2239 = load i32, ptr %p2238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2239, ptr %slot200, align 8
  %v2240 = load i32, ptr %slot200, align 8
  %op2241 = and i32 %v2240, 28
  store i32 %op2241, ptr %slot201, align 8
  %v2242 = load i32, ptr %slot201, align 8
  %cv2243 = zext i32 %v2242 to i64
  %cond2244 = icmp ne i64 %cv2243, 0
  br i1 %cond2244, label %bb_rcslotrole231, label %bb_rcslotowner231
bb_rcslotrole231:
  %v2245 = load i64, ptr %slot71, align 8
  store i64 %v2245, ptr %slot202, align 8
  %v2246 = load i64, ptr %slot202, align 8
  %v2247 = load i64, ptr %slot199, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2246, i64 %v2247) nomerge, !dbg !122
  br label %bb_rcslotdone231
bb_rcslotowner231:
  %v2248 = load i64, ptr %slot71, align 8
  store i64 %v2248, ptr %slot203, align 8
  %v2249 = load i64, ptr %slot203, align 8
  %v2250 = load i64, ptr %slot199, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2249, i64 %v2250) nomerge, !dbg !122
  br label %bb_rcslotdone231
bb_rcslotdone231:
  br label %bb_rcprepared205
bb_rcprepared205:
  %v2251 = load i64, ptr %slot34, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %ld2253 = load i64, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2253, ptr %slot204, align 8
  %v2254 = load i64, ptr %slot71, align 8
  store i64 %v2254, ptr %slot205, align 8
  %v2255 = load i64, ptr %slot205, align 8
  %v2256 = load i64, ptr %slot204, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2255, i64 %v2256) nomerge, !dbg !122
  %v2257 = load i64, ptr %slot30, align 8
  store i64 %v2257, ptr %slot206, align 8
  %v2258 = load i64, ptr %slot206, align 8
  %v2259 = load i64, ptr %slot204, align 8
  %p2260 = inttoptr i64 %v2258 to ptr
  %p2261 = inttoptr i64 %v2259 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2261, ptr %p2260, i64 104, i1 false), !alias.scope !10000000
  %v2262 = load i64, ptr %slot24, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i32 0, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot58, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i64 0, ptr %p2265, align 8, !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot34, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %ld2268 = load i64, ptr %p2267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2268, ptr %slot207, align 8
  %v2269 = load i64, ptr %slot207, align 8
  %v2270 = load i64, ptr %slot58, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  store i64 %v2269, ptr %p2271, align 8, !alias.scope !3, !noalias !4
  %v2272 = load i64, ptr %slot58, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  %ld2274 = load i64, ptr %p2273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2274, ptr %slot208, align 8
  %v2275 = load i64, ptr %slot1, align 8
  %v2276 = load i64, ptr %slot208, align 8
  %call2277 = call i64 @myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577(i64 %v2275, i64 %v2276) nomerge, !dbg !124
  store i64 %call2277, ptr %slot209, align 8
  %v2278 = load i64, ptr %slot209, align 8
  %v2279 = load i64, ptr %slot58, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  store i64 %v2278, ptr %p2280, align 8, !alias.scope !3, !noalias !4
  %v2281 = load i64, ptr %slot20, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %ld2283 = load i32, ptr %p2282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2283, ptr %slot210, align 8
  %v2284 = load i32, ptr %slot210, align 8
  %cv2285 = zext i32 %v2284 to i64
  %cond2286 = icmp ne i64 %cv2285, 0
  br i1 %cond2286, label %bb_rcslotdrop247, label %bb_rcslotdone247
bb_rcslotdrop247:
  %v2287 = load i64, ptr %slot20, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i32 0, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot27, align 8
  store i64 %v2289, ptr %slot211, align 8
  %v2290 = load i64, ptr %slot21, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i32, ptr %p2291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2292, ptr %slot212, align 8
  %v2293 = load i32, ptr %slot212, align 8
  %op2294 = and i32 %v2293, 28
  store i32 %op2294, ptr %slot213, align 8
  %v2295 = load i32, ptr %slot213, align 8
  %cv2296 = zext i32 %v2295 to i64
  %cond2297 = icmp ne i64 %cv2296, 0
  br i1 %cond2297, label %bb_rcslotrole247, label %bb_rcslotowner247
bb_rcslotrole247:
  %v2298 = load i64, ptr %slot71, align 8
  store i64 %v2298, ptr %slot214, align 8
  %v2299 = load i64, ptr %slot214, align 8
  %v2300 = load i64, ptr %slot211, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2299, i64 %v2300) nomerge, !dbg !124
  br label %bb_rcslotdone247
bb_rcslotowner247:
  %v2301 = load i64, ptr %slot71, align 8
  store i64 %v2301, ptr %slot215, align 8
  %v2302 = load i64, ptr %slot215, align 8
  %v2303 = load i64, ptr %slot211, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2302, i64 %v2303) nomerge, !dbg !124
  br label %bb_rcslotdone247
bb_rcslotdone247:
  %v2304 = load i64, ptr %slot34, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  %ld2306 = load i64, ptr %p2305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2306, ptr %slot216, align 8
  %v2307 = load i64, ptr %slot216, align 8
  %v2308 = load i64, ptr %slot58, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  store i64 %v2307, ptr %p2309, align 8, !alias.scope !3, !noalias !4
  %v2310 = load i64, ptr %slot58, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %ld2312 = load i64, ptr %p2311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2312, ptr %slot217, align 8
  %v2313 = load i64, ptr %slot217, align 8
  %op2314 = add i64 %v2313, 0
  store i64 %op2314, ptr %slot218, align 8
  %v2315 = load i64, ptr %slot218, align 8
  %v2316 = load i64, ptr %slot58, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  store i64 %v2315, ptr %p2317, align 8, !alias.scope !3, !noalias !4
  %v2318 = load i64, ptr %slot20, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  %ld2320 = load i32, ptr %p2319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2320, ptr %slot219, align 8
  %v2321 = load i32, ptr %slot219, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcslotdrop259, label %bb_rcslotdone259
bb_rcslotdrop259:
  %v2324 = load i64, ptr %slot20, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  store i32 0, ptr %p2325, align 4, !alias.scope !3, !noalias !4
  %v2326 = load i64, ptr %slot27, align 8
  store i64 %v2326, ptr %slot220, align 8
  %v2327 = load i64, ptr %slot21, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i32, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2329, ptr %slot221, align 8
  %v2330 = load i32, ptr %slot221, align 8
  %op2331 = and i32 %v2330, 28
  store i32 %op2331, ptr %slot222, align 8
  %v2332 = load i32, ptr %slot222, align 8
  %cv2333 = zext i32 %v2332 to i64
  %cond2334 = icmp ne i64 %cv2333, 0
  br i1 %cond2334, label %bb_rcslotrole259, label %bb_rcslotowner259
bb_rcslotrole259:
  %v2335 = load i64, ptr %slot71, align 8
  store i64 %v2335, ptr %slot223, align 8
  %v2336 = load i64, ptr %slot223, align 8
  %v2337 = load i64, ptr %slot220, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v2336, i64 %v2337) nomerge, !dbg !126
  br label %bb_rcslotdone259
bb_rcslotowner259:
  %v2338 = load i64, ptr %slot71, align 8
  store i64 %v2338, ptr %slot224, align 8
  %v2339 = load i64, ptr %slot224, align 8
  %v2340 = load i64, ptr %slot220, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v2339, i64 %v2340) nomerge, !dbg !126
  br label %bb_rcslotdone259
bb_rcslotdone259:
  %v2341 = load i64, ptr %slot58, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %ld2343 = load i64, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2343, ptr %slot225, align 8
  %v2344 = load i64, ptr %slot225, align 8
  %op2345 = add i64 %v2344, 16
  store i64 %op2345, ptr %slot226, align 8
  %v2346 = load i64, ptr %slot226, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %ld2348 = load i64, ptr %p2347, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2348, ptr %slot227, align 8
  %v2349 = load i64, ptr %slot227, align 8
  %v2350 = load i64, ptr %slot58, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  store i64 %v2349, ptr %p2351, align 8, !alias.scope !3, !noalias !4
  %v2352 = load i64, ptr %slot20, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %ld2354 = load i32, ptr %p2353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2354, ptr %slot228, align 8
  %v2355 = load i32, ptr %slot228, align 8
  %cv2356 = zext i32 %v2355 to i64
  %cond2357 = icmp ne i64 %cv2356, 0
  br i1 %cond2357, label %bb_rcslotdrop271, label %bb_rcslotdone271
bb_rcslotdrop271:
  %v2358 = load i64, ptr %slot20, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i32 0, ptr %p2359, align 4, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot27, align 8
  store i64 %v2360, ptr %slot229, align 8
  %v2361 = load i64, ptr %slot21, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %ld2363 = load i32, ptr %p2362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2363, ptr %slot230, align 8
  %v2364 = load i32, ptr %slot230, align 8
  %op2365 = and i32 %v2364, 28
  store i32 %op2365, ptr %slot231, align 8
  %v2366 = load i32, ptr %slot231, align 8
  %cv2367 = zext i32 %v2366 to i64
  %cond2368 = icmp ne i64 %cv2367, 0
  br i1 %cond2368, label %bb_rcslotrole271, label %bb_rcslotowner271
bb_rcslotrole271:
  %v2369 = load i64, ptr %slot71, align 8
  store i64 %v2369, ptr %slot232, align 8
  %v2370 = load i64, ptr %slot232, align 8
  %v2371 = load i64, ptr %slot229, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v2370, i64 %v2371) nomerge, !dbg !128
  br label %bb_rcslotdone271
bb_rcslotowner271:
  %v2372 = load i64, ptr %slot71, align 8
  store i64 %v2372, ptr %slot233, align 8
  %v2373 = load i64, ptr %slot233, align 8
  %v2374 = load i64, ptr %slot229, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v2373, i64 %v2374) nomerge, !dbg !128
  br label %bb_rcslotdone271
bb_rcslotdone271:
  %v2375 = load i64, ptr %slot58, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %ld2377 = load i64, ptr %p2376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2377, ptr %slot234, align 8
  %v2378 = load i64, ptr %slot234, align 8
  %v2379 = load i64, ptr %slot40, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i64 %v2378, ptr %p2380, align 8, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot35, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i64, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2383, ptr %slot235, align 8
  %v2384 = load i64, ptr %slot235, align 8
  %v2385 = load i64, ptr %slot58, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  store i64 %v2384, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  %v2387 = load i64, ptr %slot58, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %ld2389 = load i64, ptr %p2388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2389, ptr %slot236, align 8
  %v2390 = load i64, ptr %slot236, align 8
  %v2391 = load i64, ptr %slot41, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i64 %v2390, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  %v2393 = load i64, ptr %slot41, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i64, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2395, ptr %slot237, align 8
  %v2396 = load i64, ptr %slot237, align 8
  %v2397 = load i64, ptr %slot58, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i64 %v2396, ptr %p2398, align 8, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot59, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  store i64 0, ptr %p2400, align 8, !alias.scope !3, !noalias !4
  %v2401 = load i64, ptr %slot59, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  %ld2403 = load i64, ptr %p2402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2403, ptr %slot238, align 8
  %v2404 = load i64, ptr %slot58, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %ld2406 = load i64, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2406, ptr %slot239, align 8
  %v2407 = load i64, ptr %slot239, align 8
  %v2408 = load i64, ptr %slot238, align 8
  %cmp2409 = icmp slt i64 %v2407, %v2408
  %cv2410 = zext i1 %cmp2409 to i64
  store i64 %cv2410, ptr %slot240, align 8
  %v2411 = load i64, ptr %slot240, align 8
  %v2412 = load i64, ptr %slot58, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i64 %v2411, ptr %p2413, align 8, !alias.scope !3, !noalias !4
  %v2414 = load i64, ptr %slot58, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  %ld2416 = load i64, ptr %p2415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2416, ptr %slot241, align 8
  %v2417 = load i64, ptr %slot241, align 8
  %cond2418 = icmp ne i64 %v2417, 0
  br i1 %cond2418, label %bb_next286, label %bb_i33
bb_next286:
  %v2419 = load i64, ptr %slot40, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i64, ptr %p2420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2421, ptr %slot242, align 8
  %v2422 = load i64, ptr %slot242, align 8
  %op2423 = add i64 %v2422, 0
  store i64 %op2423, ptr %slot243, align 8
  %v2424 = load i64, ptr %slot243, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  %ld2426 = load i64, ptr %p2425, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2426, ptr %slot244, align 8
  %v2427 = load i64, ptr %slot244, align 8
  %v2428 = load i64, ptr %slot58, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  store i64 %v2427, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  %v2430 = load i64, ptr %slot58, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i64, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2432, ptr %slot245, align 8
  %v2433 = load i64, ptr %slot245, align 8
  %cmp2434 = icmp ugt i64 %v2433, 9223372036854775807
  %cv2435 = zext i1 %cmp2434 to i64
  store i64 %cv2435, ptr %slot246, align 8
  %v2436 = load i64, ptr %slot246, align 8
  %cond2437 = icmp ne i64 %v2436, 0
  br i1 %cond2437, label %bb_cast_overflow291, label %bb_cast_ok291
bb_cast_overflow291:
  %v2438 = load i64, ptr %slot1, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  %v2440 = load i64, ptr %slot245, align 8
  call void @myl_qbe_fail_cast(ptr %p2439, i64 %v2440, i64 320) nomerge, !dbg !130
  unreachable
bb_cast_ok291:
  %v2441 = load i64, ptr %slot245, align 8
  %v2442 = load i64, ptr %slot58, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i64 %v2441, ptr %p2443, align 8, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot41, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %ld2446 = load i64, ptr %p2445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2446, ptr %slot247, align 8
  %v2447 = load i64, ptr %slot247, align 8
  %v2448 = load i64, ptr %slot59, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  store i64 %v2447, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  %v2450 = load i64, ptr %slot59, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  %ld2452 = load i64, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2452, ptr %slot248, align 8
  %v2453 = load i64, ptr %slot58, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2455, ptr %slot249, align 8
  %v2456 = load i64, ptr %slot249, align 8
  %v2457 = load i64, ptr %slot248, align 8
  %ovpair2459 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2456, i64 %v2457)
  %op2458 = extractvalue { i64, i1 } %ovpair2459, 0
  %ov2460 = extractvalue { i64, i1 } %ovpair2459, 1
  store i64 %op2458, ptr %slot250, align 8
  %v2461 = load i64, ptr %slot249, align 8
  %v2462 = load i64, ptr %slot250, align 8
  %op2463 = xor i64 %v2461, %v2462
  store i64 %op2463, ptr %slot251, align 8
  %v2464 = load i64, ptr %slot248, align 8
  %v2465 = load i64, ptr %slot250, align 8
  %op2466 = xor i64 %v2464, %v2465
  store i64 %op2466, ptr %slot252, align 8
  %v2467 = load i64, ptr %slot251, align 8
  %v2468 = load i64, ptr %slot252, align 8
  %op2469 = and i64 %v2467, %v2468
  store i64 %op2469, ptr %slot253, align 8
  %cv2470 = zext i1 %ov2460 to i64
  store i64 %cv2470, ptr %slot254, align 8
  %v2471 = load i64, ptr %slot254, align 8
  %cond2472 = icmp ne i64 %v2471, 0
  br i1 %cond2472, label %bb_overflow295, label %bb_checked295
bb_overflow295:
  %v2473 = load i64, ptr %slot1, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %v2475 = load i64, ptr %slot249, align 8
  %v2476 = load i64, ptr %slot248, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2474, i64 0, i64 %v2475, i64 %v2476, i64 64) nomerge, !dbg !132
  unreachable
bb_checked295:
  %v2477 = load i64, ptr %slot250, align 8
  %v2478 = load i64, ptr %slot58, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  store i64 %v2477, ptr %p2479, align 8, !alias.scope !3, !noalias !4
  %v2480 = load i64, ptr %slot58, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %ld2482 = load i64, ptr %p2481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2482, ptr %slot255, align 8
  %v2483 = load i64, ptr %slot255, align 8
  %v2484 = load i64, ptr %slot41, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i64 %v2483, ptr %p2485, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i33:
  %v2486 = load i64, ptr %slot41, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %ld2488 = load i64, ptr %p2487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2488, ptr %slot256, align 8
  %v2489 = load i64, ptr %slot256, align 8
  %v2490 = load i64, ptr %slot58, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  store i64 %v2489, ptr %p2491, align 8, !alias.scope !3, !noalias !4
  %v2492 = load i64, ptr %slot40, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %ld2494 = load i64, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2494, ptr %slot257, align 8
  %v2495 = load i64, ptr %slot58, align 8
  %p2496 = inttoptr i64 %v2495 to ptr
  %ld2497 = load i64, ptr %p2496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2497, ptr %slot258, align 8
  %v2498 = load i64, ptr %slot257, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  %ld2500 = load i64, ptr %p2499, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2500, ptr %slot259, align 8
  %v2501 = load i64, ptr %slot258, align 8
  %v2502 = load i64, ptr %slot259, align 8
  %cmp2503 = icmp ult i64 %v2501, %v2502
  %cv2504 = zext i1 %cmp2503 to i64
  store i64 %cv2504, ptr %slot260, align 8
  %v2505 = load i64, ptr %slot260, align 8
  %cond2506 = icmp ne i64 %v2505, 0
  br i1 %cond2506, label %bb_success307, label %bb_failed307
bb_failed307:
  %v2507 = load i64, ptr %slot1, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %v2509 = load i64, ptr %slot258, align 8
  %v2510 = load i64, ptr %slot259, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2508, i64 %v2509, i64 %v2510) nomerge, !dbg !134
  unreachable
bb_success307:
  %v2511 = load i64, ptr %slot257, align 8
  %op2512 = add i64 %v2511, 32
  store i64 %op2512, ptr %slot261, align 8
  %v2513 = load i64, ptr %slot261, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %ld2515 = load i64, ptr %p2514, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2515, ptr %slot262, align 8
  %v2516 = load i64, ptr %slot258, align 8
  %op2517 = mul i64 %v2516, 80
  store i64 %op2517, ptr %slot263, align 8
  %v2518 = load i64, ptr %slot262, align 8
  %v2519 = load i64, ptr %slot263, align 8
  %op2520 = add i64 %v2518, %v2519
  store i64 %op2520, ptr %slot264, align 8
  %v2521 = load i64, ptr %slot70, align 8
  store i64 %v2521, ptr %slot265, align 8
  %v2522 = load i64, ptr %slot264, align 8
  %v2523 = load i64, ptr %slot265, align 8
  %p2524 = inttoptr i64 %v2522 to ptr
  %p2525 = inttoptr i64 %v2523 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2525, ptr %p2524, i64 80, i1 false), !alias.scope !10000001
  %v2526 = load i64, ptr %slot265, align 8
  %v2527 = load i64, ptr %slot58, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i64 %v2526, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot58, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i64, ptr %p2530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2531, ptr %slot266, align 8
  %v2532 = load i64, ptr %slot30, align 8
  store i64 %v2532, ptr %slot267, align 8
  %v2533 = load i64, ptr %slot71, align 8
  %v2534 = load i64, ptr %slot267, align 8
  %v2535 = load i64, ptr %slot266, align 8
  %call2536 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v2533, i64 %v2534, i64 %v2535) nomerge, !dbg !134
  store i32 %call2536, ptr %slot268, align 8
  %v2537 = load i32, ptr %slot268, align 8
  %cv2538 = zext i32 %v2537 to i64
  %cond2539 = icmp ne i64 %cv2538, 0
  br i1 %cond2539, label %bb_rcsuccess316, label %bb_rcfailure316
bb_rcfailure316:
  %v2540 = load i64, ptr %slot71, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %call2542 = call i32 @myl_rc_take_failure(ptr %p2541) nomerge, !dbg !134
  store i32 %call2542, ptr %slot269, align 8
  %v2543 = load i64, ptr %slot1, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  %v2545 = load i32, ptr %slot269, align 8
  %call2546 = call i32 @myl_qbe_rc_status(ptr %p2544, i32 %v2545) nomerge, !dbg !134
  store i32 %call2546, ptr %slot270, align 8
  br label %bb_failure
bb_rcsuccess316:
  %v2547 = load i64, ptr %slot25, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i32 2, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot25, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i32 16, ptr %p2550, align 4, !alias.scope !3, !noalias !4
  %v2551 = load i64, ptr %slot24, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  store i32 1, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  %v2553 = load i64, ptr %slot27, align 8
  store i64 %v2553, ptr %slot271, align 8
  %v2554 = load i64, ptr %slot30, align 8
  store i64 %v2554, ptr %slot272, align 8
  %v2555 = load i64, ptr %slot272, align 8
  %v2556 = load i64, ptr %slot271, align 8
  %p2557 = inttoptr i64 %v2555 to ptr
  %p2558 = inttoptr i64 %v2556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2558, ptr %p2557, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v2559 = load i64, ptr %slot21, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  store i32 2, ptr %p2560, align 4, !alias.scope !3, !noalias !4
  %v2561 = load i64, ptr %slot25, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  %ld2563 = load i32, ptr %p2562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2563, ptr %slot273, align 8
  %v2564 = load i32, ptr %slot273, align 8
  %v2565 = load i64, ptr %slot21, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  store i32 %v2564, ptr %p2566, align 4, !alias.scope !3, !noalias !4
  %v2567 = load i64, ptr %slot24, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  store i32 0, ptr %p2568, align 4, !alias.scope !3, !noalias !4
  %v2569 = load i64, ptr %slot20, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 1, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot271, align 8
  %v2572 = load i64, ptr %slot58, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  store i64 %v2571, ptr %p2573, align 8, !alias.scope !3, !noalias !4
  %v2574 = load i64, ptr %slot58, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  %ld2576 = load i64, ptr %p2575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2576, ptr %slot274, align 8
  %v2577 = load i64, ptr %slot20, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i32, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2579, ptr %slot275, align 8
  %v2580 = load i64, ptr %slot21, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %ld2582 = load i32, ptr %p2581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2582, ptr %slot276, align 8
  %v2583 = load i32, ptr %slot276, align 8
  %op2584 = and i32 %v2583, 24
  store i32 %op2584, ptr %slot276, align 8
  %v2585 = load i32, ptr %slot276, align 8
  %cmp2586 = icmp eq i32 %v2585, 0
  %cv2587 = zext i1 %cmp2586 to i32
  store i32 %cv2587, ptr %slot277, align 8
  %v2588 = load i32, ptr %slot275, align 8
  %v2589 = load i32, ptr %slot277, align 8
  %op2590 = and i32 %v2588, %v2589
  store i32 %op2590, ptr %slot278, align 8
  %v2591 = load i64, ptr %slot72, align 8
  store i64 %v2591, ptr %slot279, align 8
  %v2592 = load i32, ptr %slot278, align 8
  %op2593 = mul i32 %v2592, 4
  store i32 %op2593, ptr %slot280, align 8
  %v2594 = load i32, ptr %slot280, align 8
  %op2595 = or i32 %v2594, 0
  store i32 %op2595, ptr %slot281, align 8
  %v2596 = load i64, ptr %slot30, align 8
  store i64 %v2596, ptr %slot282, align 8
  %v2597 = load i64, ptr %slot71, align 8
  %v2598 = load i64, ptr %slot282, align 8
  %v2599 = load i64, ptr %slot274, align 8
  %v2600 = load i64, ptr %slot279, align 8
  %cv2601 = trunc i64 %v2600 to i32
  %v2602 = load i32, ptr %slot281, align 8
  %call2603 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_publish(i64 %v2597, i64 %v2598, i64 %v2599, i32 %cv2601, i32 %v2602) nomerge, !dbg !136
  store i32 %call2603, ptr %slot283, align 8
  %v2604 = load i32, ptr %slot283, align 8
  %cv2605 = zext i32 %v2604 to i64
  %cond2606 = icmp ne i64 %cv2605, 0
  br i1 %cond2606, label %bb_rcsuccess344, label %bb_rcfailure344
bb_rcfailure344:
  %v2607 = load i64, ptr %slot71, align 8
  %p2608 = inttoptr i64 %v2607 to ptr
  %call2609 = call i32 @myl_rc_take_failure(ptr %p2608) nomerge, !dbg !136
  store i32 %call2609, ptr %slot284, align 8
  %v2610 = load i64, ptr %slot1, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  %v2612 = load i32, ptr %slot284, align 8
  %call2613 = call i32 @myl_qbe_rc_status(ptr %p2611, i32 %v2612) nomerge, !dbg !136
  store i32 %call2613, ptr %slot285, align 8
  br label %bb_failure
bb_rcsuccess344:
  %v2614 = load i32, ptr %slot278, align 8
  %cv2615 = zext i32 %v2614 to i64
  %cond2616 = icmp ne i64 %cv2615, 0
  br i1 %cond2616, label %bb_rchtaken347, label %bb_rchcopied347
bb_rchcopied347:
  %v2617 = load i64, ptr %slot20, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i32, ptr %p2618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2619, ptr %slot286, align 8
  %v2620 = load i32, ptr %slot286, align 8
  %cv2621 = zext i32 %v2620 to i64
  %cond2622 = icmp ne i64 %cv2621, 0
  br i1 %cond2622, label %bb_rcslotdrop350, label %bb_rcslotdone350
bb_rcslotdrop350:
  %v2623 = load i64, ptr %slot20, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  store i32 0, ptr %p2624, align 4, !alias.scope !3, !noalias !4
  %v2625 = load i64, ptr %slot27, align 8
  store i64 %v2625, ptr %slot287, align 8
  %v2626 = load i64, ptr %slot21, align 8
  %p2627 = inttoptr i64 %v2626 to ptr
  %ld2628 = load i32, ptr %p2627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2628, ptr %slot288, align 8
  %v2629 = load i32, ptr %slot288, align 8
  %op2630 = and i32 %v2629, 28
  store i32 %op2630, ptr %slot289, align 8
  %v2631 = load i32, ptr %slot289, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcslotrole350, label %bb_rcslotowner350
bb_rcslotrole350:
  %v2634 = load i64, ptr %slot71, align 8
  store i64 %v2634, ptr %slot290, align 8
  %v2635 = load i64, ptr %slot290, align 8
  %v2636 = load i64, ptr %slot287, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v2635, i64 %v2636) nomerge, !dbg !136
  br label %bb_rcslotdone350
bb_rcslotowner350:
  %v2637 = load i64, ptr %slot71, align 8
  store i64 %v2637, ptr %slot291, align 8
  %v2638 = load i64, ptr %slot291, align 8
  %v2639 = load i64, ptr %slot287, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v2638, i64 %v2639) nomerge, !dbg !136
  br label %bb_rcslotdone350
bb_rcslotdone350:
  br label %bb_rchprepared347
bb_rchtaken347:
  %v2640 = load i64, ptr %slot20, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  store i32 0, ptr %p2641, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared347
bb_rchprepared347:
  %v2642 = load i64, ptr %slot25, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  store i32 2, ptr %p2643, align 4, !alias.scope !3, !noalias !4
  %v2644 = load i64, ptr %slot24, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i32 1, ptr %p2645, align 4, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot27, align 8
  store i64 %v2646, ptr %slot292, align 8
  %v2647 = load i64, ptr %slot30, align 8
  store i64 %v2647, ptr %slot293, align 8
  %v2648 = load i64, ptr %slot293, align 8
  %v2649 = load i64, ptr %slot292, align 8
  %p2650 = inttoptr i64 %v2648 to ptr
  %p2651 = inttoptr i64 %v2649 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2651, ptr %p2650, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot21, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i32 2, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  %v2654 = load i64, ptr %slot25, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %ld2656 = load i32, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2656, ptr %slot294, align 8
  %v2657 = load i32, ptr %slot294, align 8
  %v2658 = load i64, ptr %slot21, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  store i32 %v2657, ptr %p2659, align 4, !alias.scope !3, !noalias !4
  %v2660 = load i64, ptr %slot24, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  store i32 0, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  %v2662 = load i64, ptr %slot20, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  store i32 1, ptr %p2663, align 4, !alias.scope !3, !noalias !4
  %v2664 = load i64, ptr %slot292, align 8
  %v2665 = load i64, ptr %slot58, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i64 %v2664, ptr %p2666, align 8, !alias.scope !3, !noalias !4
  %v2667 = load i64, ptr %slot58, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %ld2669 = load i64, ptr %p2668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2669, ptr %slot295, align 8
  %v2670 = load i64, ptr %slot30, align 8
  store i64 %v2670, ptr %slot296, align 8
  %v2671 = load i64, ptr %slot72, align 8
  store i64 %v2671, ptr %slot297, align 8
  %v2672 = load i64, ptr %slot71, align 8
  %v2673 = load i64, ptr %slot296, align 8
  %v2674 = load i64, ptr %slot295, align 8
  %v2675 = load i64, ptr %slot297, align 8
  %cv2676 = trunc i64 %v2675 to i32
  %call2677 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64 %v2672, i64 %v2673, i64 %v2674, i32 %cv2676) nomerge, !dbg !138
  store i32 %call2677, ptr %slot298, align 8
  %v2678 = load i32, ptr %slot298, align 8
  %cv2679 = zext i32 %v2678 to i64
  %cond2680 = icmp ne i64 %cv2679, 0
  br i1 %cond2680, label %bb_rcsuccess372, label %bb_rcfailure372
bb_rcfailure372:
  %v2681 = load i64, ptr %slot71, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  %call2683 = call i32 @myl_rc_take_failure(ptr %p2682) nomerge, !dbg !138
  store i32 %call2683, ptr %slot299, align 8
  %v2684 = load i64, ptr %slot1, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  %v2686 = load i32, ptr %slot299, align 8
  %call2687 = call i32 @myl_qbe_rc_status(ptr %p2685, i32 %v2686) nomerge, !dbg !138
  store i32 %call2687, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess372:
  %v2688 = load i64, ptr %slot20, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i32 0, ptr %p2689, align 4, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot25, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i32 2, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot24, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i32 1, ptr %p2693, align 4, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot8, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i32, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2696, ptr %slot301, align 8
  %v2697 = load i32, ptr %slot301, align 8
  %cv2698 = zext i32 %v2697 to i64
  %cond2699 = icmp ne i64 %cv2698, 0
  br i1 %cond2699, label %bb_rcslotdrop381, label %bb_rcslotdone381
bb_rcslotdrop381:
  %v2700 = load i64, ptr %slot8, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  store i32 0, ptr %p2701, align 4, !alias.scope !3, !noalias !4
  %v2702 = load i64, ptr %slot42, align 8
  store i64 %v2702, ptr %slot302, align 8
  %v2703 = load i64, ptr %slot9, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  %ld2705 = load i32, ptr %p2704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2705, ptr %slot303, align 8
  %v2706 = load i32, ptr %slot303, align 8
  %op2707 = and i32 %v2706, 28
  store i32 %op2707, ptr %slot304, align 8
  %v2708 = load i32, ptr %slot304, align 8
  %cv2709 = zext i32 %v2708 to i64
  %cond2710 = icmp ne i64 %cv2709, 0
  br i1 %cond2710, label %bb_rcslotrole381, label %bb_rcslotowner381
bb_rcslotrole381:
  %v2711 = load i64, ptr %slot71, align 8
  store i64 %v2711, ptr %slot305, align 8
  %v2712 = load i64, ptr %slot305, align 8
  %v2713 = load i64, ptr %slot302, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v2712, i64 %v2713) nomerge, !dbg !138
  br label %bb_rcslotdone381
bb_rcslotowner381:
  %v2714 = load i64, ptr %slot71, align 8
  store i64 %v2714, ptr %slot306, align 8
  %v2715 = load i64, ptr %slot306, align 8
  %v2716 = load i64, ptr %slot302, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v2715, i64 %v2716) nomerge, !dbg !138
  br label %bb_rcslotdone381
bb_rcslotdone381:
  %v2717 = load i64, ptr %slot42, align 8
  store i64 %v2717, ptr %slot307, align 8
  %v2718 = load i64, ptr %slot30, align 8
  store i64 %v2718, ptr %slot308, align 8
  %v2719 = load i64, ptr %slot308, align 8
  %v2720 = load i64, ptr %slot307, align 8
  %p2721 = inttoptr i64 %v2719 to ptr
  %p2722 = inttoptr i64 %v2720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2722, ptr %p2721, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot24, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  store i32 0, ptr %p2724, align 4, !alias.scope !3, !noalias !4
  %v2725 = load i64, ptr %slot9, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i32 2, ptr %p2726, align 4, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot25, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i32, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2729, ptr %slot309, align 8
  %v2730 = load i32, ptr %slot309, align 8
  %v2731 = load i64, ptr %slot9, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  store i32 %v2730, ptr %p2732, align 4, !alias.scope !3, !noalias !4
  %v2733 = load i64, ptr %slot8, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i32 1, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot42, align 8
  %v2736 = load i64, ptr %slot58, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  store i64 %v2735, ptr %p2737, align 8, !alias.scope !3, !noalias !4
  %v2738 = load i64, ptr %slot58, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %ld2740 = load i64, ptr %p2739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2740, ptr %slot310, align 8
  %v2741 = load i64, ptr %slot310, align 8
  %op2742 = add i64 %v2741, 48
  store i64 %op2742, ptr %slot311, align 8
  %v2743 = load i64, ptr %slot311, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %ld2745 = load i64, ptr %p2744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2745, ptr %slot312, align 8
  %v2746 = load i64, ptr %slot312, align 8
  %v2747 = load i64, ptr %slot58, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i64 %v2746, ptr %p2748, align 8, !alias.scope !3, !noalias !4
  %v2749 = load i64, ptr %slot58, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %ld2751 = load i64, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2751, ptr %slot313, align 8
  %v2752 = load i64, ptr %slot313, align 8
  %v2753 = load i64, ptr %slot29, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i64 %v2752, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot29, align 8
  store i64 %v2755, ptr %slot314, align 8
  %v2756 = load i64, ptr %slot30, align 8
  store i64 %v2756, ptr %slot315, align 8
  %v2757 = load i64, ptr %slot314, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %ld2759 = load i64, ptr %p2758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2759, ptr %slot316, align 8
  %v2760 = load i64, ptr %slot316, align 8
  %cmp2761 = icmp ne i64 %v2760, 0
  %cv2762 = zext i1 %cmp2761 to i32
  store i32 %cv2762, ptr %slot317, align 8
  %v2763 = load i32, ptr %slot317, align 8
  %cv2764 = zext i32 %v2763 to i64
  %cond2765 = icmp ne i64 %cv2764, 0
  br i1 %cond2765, label %bb_rcgnn402, label %bb_rcgstore402
bb_rcgnn402:
  %v2766 = load i64, ptr %slot316, align 8
  %op2767 = sub i64 %v2766, 16
  store i64 %op2767, ptr %slot318, align 8
  %v2768 = load i64, ptr %slot316, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  %rgep2770 = getelementptr i8, ptr %p2769, i64 -16
  %ld2771 = load i64, ptr %rgep2770, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2771, ptr %slot319, align 8
  %v2772 = load i64, ptr %slot319, align 8
  %op2773 = and i64 %v2772, 4611686018427387906
  store i64 %op2773, ptr %slot320, align 8
  %v2774 = load i64, ptr %slot320, align 8
  %cmp2775 = icmp ne i64 %v2774, 0
  %cv2776 = zext i1 %cmp2775 to i32
  store i32 %cv2776, ptr %slot321, align 8
  %v2777 = load i32, ptr %slot321, align 8
  %cv2778 = zext i32 %v2777 to i64
  %cond2779 = icmp ne i64 %cv2778, 0
  br i1 %cond2779, label %bb_rcgstore402, label %bb_rcginc402
bb_rcginc402:
  %v2780 = load i64, ptr %slot316, align 8
  %op2781 = sub i64 %v2780, 24
  store i64 %op2781, ptr %slot322, align 8
  %v2782 = load i64, ptr %slot316, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %rgep2784 = getelementptr i8, ptr %p2783, i64 -24
  %ld2785 = load i64, ptr %rgep2784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2785, ptr %slot323, align 8
  %v2786 = load i64, ptr %slot323, align 8
  %op2787 = add i64 %v2786, 1
  store i64 %op2787, ptr %slot324, align 8
  %v2788 = load i64, ptr %slot324, align 8
  %cmp2789 = icmp eq i64 %v2788, 0
  %cv2790 = zext i1 %cmp2789 to i32
  store i32 %cv2790, ptr %slot325, align 8
  %v2791 = load i32, ptr %slot325, align 8
  %cv2792 = zext i32 %v2791 to i64
  %cond2793 = icmp ne i64 %cv2792, 0
  br i1 %cond2793, label %bb_rcglimit402, label %bb_rcgcapacity402
bb_rcglimit402:
  %v2794 = load i64, ptr %slot1, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %call2796 = call i32 @myl_qbe_rc_status(ptr %p2795, i32 2) nomerge, !dbg !140
  store i32 %call2796, ptr %slot326, align 8
  br label %bb_failure
bb_rcgcapacity402:
  %v2797 = load i64, ptr %slot324, align 8
  %v2798 = load i64, ptr %slot316, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  %rgep2800 = getelementptr i8, ptr %p2799, i64 -24
  store i64 %v2797, ptr %rgep2800, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore402
bb_rcgstore402:
  %v2801 = load i64, ptr %slot316, align 8
  %v2802 = load i64, ptr %slot315, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  store i64 %v2801, ptr %p2803, align 8, !alias.scope !3, !noalias !4
  %v2804 = load i64, ptr %slot25, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i32 2, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot25, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 16, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot24, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i32 1, ptr %p2809, align 4, !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot20, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  %ld2812 = load i32, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2812, ptr %slot327, align 8
  %v2813 = load i32, ptr %slot327, align 8
  %cv2814 = zext i32 %v2813 to i64
  %cond2815 = icmp ne i64 %cv2814, 0
  br i1 %cond2815, label %bb_rcslotdrop418, label %bb_rcslotdone418
bb_rcslotdrop418:
  %v2816 = load i64, ptr %slot20, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i32 0, ptr %p2817, align 4, !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot27, align 8
  store i64 %v2818, ptr %slot328, align 8
  %v2819 = load i64, ptr %slot21, align 8
  %p2820 = inttoptr i64 %v2819 to ptr
  %ld2821 = load i32, ptr %p2820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2821, ptr %slot329, align 8
  %v2822 = load i32, ptr %slot329, align 8
  %op2823 = and i32 %v2822, 28
  store i32 %op2823, ptr %slot330, align 8
  %v2824 = load i32, ptr %slot330, align 8
  %cv2825 = zext i32 %v2824 to i64
  %cond2826 = icmp ne i64 %cv2825, 0
  br i1 %cond2826, label %bb_rcslotrole418, label %bb_rcslotowner418
bb_rcslotrole418:
  %v2827 = load i64, ptr %slot71, align 8
  store i64 %v2827, ptr %slot331, align 8
  %v2828 = load i64, ptr %slot331, align 8
  %v2829 = load i64, ptr %slot328, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v2828, i64 %v2829) nomerge, !dbg !140
  br label %bb_rcslotdone418
bb_rcslotowner418:
  %v2830 = load i64, ptr %slot71, align 8
  store i64 %v2830, ptr %slot332, align 8
  %v2831 = load i64, ptr %slot332, align 8
  %v2832 = load i64, ptr %slot328, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v2831, i64 %v2832) nomerge, !dbg !140
  br label %bb_rcslotdone418
bb_rcslotdone418:
  %v2833 = load i64, ptr %slot27, align 8
  store i64 %v2833, ptr %slot333, align 8
  %v2834 = load i64, ptr %slot30, align 8
  store i64 %v2834, ptr %slot334, align 8
  %v2835 = load i64, ptr %slot334, align 8
  %v2836 = load i64, ptr %slot333, align 8
  %p2837 = inttoptr i64 %v2835 to ptr
  %p2838 = inttoptr i64 %v2836 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2838, ptr %p2837, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2839 = load i64, ptr %slot21, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 2, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot25, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  %ld2843 = load i32, ptr %p2842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2843, ptr %slot335, align 8
  %v2844 = load i32, ptr %slot335, align 8
  %v2845 = load i64, ptr %slot21, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  store i32 %v2844, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  %v2847 = load i64, ptr %slot24, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  store i32 0, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  %v2849 = load i64, ptr %slot20, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  store i32 1, ptr %p2850, align 4, !alias.scope !3, !noalias !4
  %v2851 = load i64, ptr %slot333, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  %ld2853 = load i64, ptr %p2852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2853, ptr %slot336, align 8
  %v2854 = load i64, ptr %slot336, align 8
  %v2855 = load i64, ptr %slot58, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i64 %v2854, ptr %p2856, align 8, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot58, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %ld2859 = load i64, ptr %p2858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2859, ptr %slot337, align 8
  %v2860 = load i64, ptr %slot30, align 8
  store i64 %v2860, ptr %slot338, align 8
  %v2861 = load i64, ptr %slot337, align 8
  %cmp2862 = icmp ne i64 %v2861, 0
  %cv2863 = zext i1 %cmp2862 to i32
  store i32 %cv2863, ptr %slot339, align 8
  %v2864 = load i32, ptr %slot339, align 8
  %cv2865 = zext i32 %v2864 to i64
  %cond2866 = icmp ne i64 %cv2865, 0
  br i1 %cond2866, label %bb_rcgnn438, label %bb_rcgstore438
bb_rcgnn438:
  %v2867 = load i64, ptr %slot337, align 8
  %op2868 = sub i64 %v2867, 16
  store i64 %op2868, ptr %slot340, align 8
  %v2869 = load i64, ptr %slot337, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  %rgep2871 = getelementptr i8, ptr %p2870, i64 -16
  %ld2872 = load i64, ptr %rgep2871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2872, ptr %slot341, align 8
  %v2873 = load i64, ptr %slot341, align 8
  %op2874 = and i64 %v2873, 4611686018427387906
  store i64 %op2874, ptr %slot342, align 8
  %v2875 = load i64, ptr %slot342, align 8
  %cmp2876 = icmp ne i64 %v2875, 0
  %cv2877 = zext i1 %cmp2876 to i32
  store i32 %cv2877, ptr %slot343, align 8
  %v2878 = load i32, ptr %slot343, align 8
  %cv2879 = zext i32 %v2878 to i64
  %cond2880 = icmp ne i64 %cv2879, 0
  br i1 %cond2880, label %bb_rcgstore438, label %bb_rcginc438
bb_rcginc438:
  %v2881 = load i64, ptr %slot337, align 8
  %op2882 = sub i64 %v2881, 24
  store i64 %op2882, ptr %slot344, align 8
  %v2883 = load i64, ptr %slot337, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %rgep2885 = getelementptr i8, ptr %p2884, i64 -24
  %ld2886 = load i64, ptr %rgep2885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2886, ptr %slot345, align 8
  %v2887 = load i64, ptr %slot345, align 8
  %op2888 = add i64 %v2887, 1
  store i64 %op2888, ptr %slot346, align 8
  %v2889 = load i64, ptr %slot346, align 8
  %cmp2890 = icmp eq i64 %v2889, 0
  %cv2891 = zext i1 %cmp2890 to i32
  store i32 %cv2891, ptr %slot347, align 8
  %v2892 = load i32, ptr %slot347, align 8
  %cv2893 = zext i32 %v2892 to i64
  %cond2894 = icmp ne i64 %cv2893, 0
  br i1 %cond2894, label %bb_rcglimit438, label %bb_rcgcapacity438
bb_rcglimit438:
  %v2895 = load i64, ptr %slot1, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  %call2897 = call i32 @myl_qbe_rc_status(ptr %p2896, i32 2) nomerge, !dbg !142
  store i32 %call2897, ptr %slot348, align 8
  br label %bb_failure
bb_rcgcapacity438:
  %v2898 = load i64, ptr %slot346, align 8
  %v2899 = load i64, ptr %slot337, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %rgep2901 = getelementptr i8, ptr %p2900, i64 -24
  store i64 %v2898, ptr %rgep2901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore438
bb_rcgstore438:
  %v2902 = load i64, ptr %slot337, align 8
  %v2903 = load i64, ptr %slot338, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  store i64 %v2902, ptr %p2904, align 8, !alias.scope !3, !noalias !4
  %v2905 = load i64, ptr %slot25, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  store i32 2, ptr %p2906, align 4, !alias.scope !3, !noalias !4
  %v2907 = load i64, ptr %slot25, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  store i32 8, ptr %p2908, align 4, !alias.scope !3, !noalias !4
  %v2909 = load i64, ptr %slot24, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  store i32 1, ptr %p2910, align 4, !alias.scope !3, !noalias !4
  %v2911 = load i64, ptr %slot20, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  %ld2913 = load i32, ptr %p2912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2913, ptr %slot349, align 8
  %v2914 = load i32, ptr %slot349, align 8
  %cv2915 = zext i32 %v2914 to i64
  %cond2916 = icmp ne i64 %cv2915, 0
  br i1 %cond2916, label %bb_rcslotdrop454, label %bb_rcslotdone454
bb_rcslotdrop454:
  %v2917 = load i64, ptr %slot20, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  store i32 0, ptr %p2918, align 4, !alias.scope !3, !noalias !4
  %v2919 = load i64, ptr %slot27, align 8
  store i64 %v2919, ptr %slot350, align 8
  %v2920 = load i64, ptr %slot21, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  %ld2922 = load i32, ptr %p2921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2922, ptr %slot351, align 8
  %v2923 = load i32, ptr %slot351, align 8
  %op2924 = and i32 %v2923, 28
  store i32 %op2924, ptr %slot352, align 8
  %v2925 = load i32, ptr %slot352, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcslotrole454, label %bb_rcslotowner454
bb_rcslotrole454:
  %v2928 = load i64, ptr %slot71, align 8
  store i64 %v2928, ptr %slot353, align 8
  %v2929 = load i64, ptr %slot350, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %ld2931 = load i64, ptr %p2930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2931, ptr %slot354, align 8
  %v2932 = load i64, ptr %slot354, align 8
  %cmp2933 = icmp ne i64 %v2932, 0
  %cv2934 = zext i1 %cmp2933 to i32
  store i32 %cv2934, ptr %slot355, align 8
  %v2935 = load i32, ptr %slot355, align 8
  %cv2936 = zext i32 %v2935 to i64
  %cond2937 = icmp ne i64 %cv2936, 0
  br i1 %cond2937, label %bb_rcgnn470, label %bb_rcgdone470
bb_rcgnn470:
  %v2938 = load i64, ptr %slot354, align 8
  %op2939 = sub i64 %v2938, 16
  store i64 %op2939, ptr %slot356, align 8
  %v2940 = load i64, ptr %slot354, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %rgep2942 = getelementptr i8, ptr %p2941, i64 -16
  %ld2943 = load i64, ptr %rgep2942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2943, ptr %slot357, align 8
  %v2944 = load i64, ptr %slot357, align 8
  %op2945 = and i64 %v2944, 4611686018427387906
  store i64 %op2945, ptr %slot358, align 8
  %v2946 = load i64, ptr %slot358, align 8
  %cmp2947 = icmp ne i64 %v2946, 0
  %cv2948 = zext i1 %cmp2947 to i32
  store i32 %cv2948, ptr %slot359, align 8
  %v2949 = load i32, ptr %slot359, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcgclear470, label %bb_rcgcounted470
bb_rcgcounted470:
  %v2952 = load i64, ptr %slot354, align 8
  %op2953 = sub i64 %v2952, 24
  store i64 %op2953, ptr %slot360, align 8
  %v2954 = load i64, ptr %slot354, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %rgep2956 = getelementptr i8, ptr %p2955, i64 -24
  %ld2957 = load i64, ptr %rgep2956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2957, ptr %slot361, align 8
  %v2958 = load i64, ptr %slot361, align 8
  %op2959 = sub i64 %v2958, 1
  store i64 %op2959, ptr %slot362, align 8
  %v2960 = load i64, ptr %slot362, align 8
  %cmp2961 = icmp eq i64 %v2960, 0
  %cv2962 = zext i1 %cmp2961 to i32
  store i32 %cv2962, ptr %slot363, align 8
  %v2963 = load i32, ptr %slot363, align 8
  %cv2964 = zext i32 %v2963 to i64
  %cond2965 = icmp ne i64 %cv2964, 0
  br i1 %cond2965, label %bb_rcglast470, label %bb_rcgdec470
bb_rcglast470:
  %v2966 = load i64, ptr %slot354, align 8
  %op2967 = sub i64 %v2966, 32
  store i64 %op2967, ptr %slot364, align 8
  %v2968 = load i64, ptr %slot354, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %rgep2970 = getelementptr i8, ptr %p2969, i64 -32
  %ld2971 = load i64, ptr %rgep2970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2971, ptr %slot365, align 8
  %v2972 = load i64, ptr %slot365, align 8
  %cmp2973 = icmp ne i64 %v2972, 0
  %cv2974 = zext i1 %cmp2973 to i32
  store i32 %cv2974, ptr %slot366, align 8
  %v2975 = load i32, ptr %slot366, align 8
  %cv2976 = zext i32 %v2975 to i64
  %cond2977 = icmp ne i64 %cv2976, 0
  br i1 %cond2977, label %bb_rcgdec470, label %bb_rcgslow470
bb_rcgslow470:
  %v2978 = load i64, ptr %slot353, align 8
  %v2979 = load i64, ptr %slot350, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_unloan(i64 %v2978, i64 %v2979) nomerge, !dbg !142
  br label %bb_rcgdone470
bb_rcgdec470:
  %v2980 = load i64, ptr %slot362, align 8
  %v2981 = load i64, ptr %slot354, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %rgep2983 = getelementptr i8, ptr %p2982, i64 -24
  store i64 %v2980, ptr %rgep2983, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear470
bb_rcgclear470:
  %v2984 = load i64, ptr %slot350, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i64 0, ptr %p2985, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone470
bb_rcgdone470:
  br label %bb_rcslotdone454
bb_rcslotowner454:
  %v2986 = load i64, ptr %slot71, align 8
  store i64 %v2986, ptr %slot367, align 8
  %v2987 = load i64, ptr %slot350, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  %ld2989 = load i64, ptr %p2988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2989, ptr %slot368, align 8
  %v2990 = load i64, ptr %slot368, align 8
  %cmp2991 = icmp ne i64 %v2990, 0
  %cv2992 = zext i1 %cmp2991 to i32
  store i32 %cv2992, ptr %slot369, align 8
  %v2993 = load i32, ptr %slot369, align 8
  %cv2994 = zext i32 %v2993 to i64
  %cond2995 = icmp ne i64 %cv2994, 0
  br i1 %cond2995, label %bb_rcgnn485, label %bb_rcgdone485
bb_rcgnn485:
  %v2996 = load i64, ptr %slot368, align 8
  %op2997 = sub i64 %v2996, 16
  store i64 %op2997, ptr %slot370, align 8
  %v2998 = load i64, ptr %slot368, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  %rgep3000 = getelementptr i8, ptr %p2999, i64 -16
  %ld3001 = load i64, ptr %rgep3000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3001, ptr %slot371, align 8
  %v3002 = load i64, ptr %slot371, align 8
  %op3003 = and i64 %v3002, 4611686018427387906
  store i64 %op3003, ptr %slot372, align 8
  %v3004 = load i64, ptr %slot372, align 8
  %cmp3005 = icmp ne i64 %v3004, 0
  %cv3006 = zext i1 %cmp3005 to i32
  store i32 %cv3006, ptr %slot373, align 8
  %v3007 = load i32, ptr %slot373, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcgclear485, label %bb_rcgcounted485
bb_rcgcounted485:
  %v3010 = load i64, ptr %slot368, align 8
  %op3011 = sub i64 %v3010, 32
  store i64 %op3011, ptr %slot374, align 8
  %v3012 = load i64, ptr %slot368, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  %rgep3014 = getelementptr i8, ptr %p3013, i64 -32
  %ld3015 = load i64, ptr %rgep3014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3015, ptr %slot375, align 8
  %v3016 = load i64, ptr %slot375, align 8
  %op3017 = sub i64 %v3016, 1
  store i64 %op3017, ptr %slot376, align 8
  %v3018 = load i64, ptr %slot376, align 8
  %cmp3019 = icmp eq i64 %v3018, 0
  %cv3020 = zext i1 %cmp3019 to i32
  store i32 %cv3020, ptr %slot377, align 8
  %v3021 = load i32, ptr %slot377, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcglast485, label %bb_rcgdec485
bb_rcglast485:
  %v3024 = load i64, ptr %slot368, align 8
  %op3025 = sub i64 %v3024, 24
  store i64 %op3025, ptr %slot378, align 8
  %v3026 = load i64, ptr %slot368, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %rgep3028 = getelementptr i8, ptr %p3027, i64 -24
  %ld3029 = load i64, ptr %rgep3028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3029, ptr %slot379, align 8
  %v3030 = load i64, ptr %slot379, align 8
  %cmp3031 = icmp ne i64 %v3030, 0
  %cv3032 = zext i1 %cmp3031 to i32
  store i32 %cv3032, ptr %slot380, align 8
  %v3033 = load i32, ptr %slot380, align 8
  %cv3034 = zext i32 %v3033 to i64
  %cond3035 = icmp ne i64 %cv3034, 0
  br i1 %cond3035, label %bb_rcgdec485, label %bb_rcgslow485
bb_rcgslow485:
  %v3036 = load i64, ptr %slot367, align 8
  %v3037 = load i64, ptr %slot350, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_drop(i64 %v3036, i64 %v3037) nomerge, !dbg !142
  br label %bb_rcgdone485
bb_rcgdec485:
  %v3038 = load i64, ptr %slot376, align 8
  %v3039 = load i64, ptr %slot368, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  %rgep3041 = getelementptr i8, ptr %p3040, i64 -32
  store i64 %v3038, ptr %rgep3041, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear485
bb_rcgclear485:
  %v3042 = load i64, ptr %slot350, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  store i64 0, ptr %p3043, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone485
bb_rcgdone485:
  br label %bb_rcslotdone454
bb_rcslotdone454:
  %v3044 = load i64, ptr %slot27, align 8
  store i64 %v3044, ptr %slot381, align 8
  %v3045 = load i64, ptr %slot30, align 8
  store i64 %v3045, ptr %slot382, align 8
  %v3046 = load i64, ptr %slot382, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  %ld3048 = load i64, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3048, ptr %slot383, align 8
  %v3049 = load i64, ptr %slot383, align 8
  %v3050 = load i64, ptr %slot381, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  store i64 %v3049, ptr %p3051, align 8, !alias.scope !3, !noalias !4
  %v3052 = load i64, ptr %slot21, align 8
  %p3053 = inttoptr i64 %v3052 to ptr
  store i32 2, ptr %p3053, align 4, !alias.scope !3, !noalias !4
  %v3054 = load i64, ptr %slot21, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i32 8, ptr %p3055, align 4, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot20, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 1, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot24, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  store i32 0, ptr %p3059, align 4, !alias.scope !3, !noalias !4
  %v3060 = load i64, ptr %slot383, align 8
  %v3061 = load i64, ptr %slot58, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  store i64 %v3060, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  %v3063 = load i64, ptr %slot30, align 8
  store i64 %v3063, ptr %slot384, align 8
  %v3064 = load i64, ptr %slot58, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %ld3066 = load i64, ptr %p3065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3066, ptr %slot385, align 8
  %v3067 = load i64, ptr %slot385, align 8
  %v3068 = load i64, ptr %slot384, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i64 %v3067, ptr %p3069, align 8, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot25, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i32 2, ptr %p3071, align 4, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot25, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i32 8, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  %v3074 = load i64, ptr %slot24, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i32 1, ptr %p3075, align 4, !alias.scope !3, !noalias !4
  %v3076 = load i64, ptr %slot20, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i32 0, ptr %p3077, align 4, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot10, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %ld3080 = load i32, ptr %p3079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3080, ptr %slot386, align 8
  %v3081 = load i32, ptr %slot386, align 8
  %cv3082 = zext i32 %v3081 to i64
  %cond3083 = icmp ne i64 %cv3082, 0
  br i1 %cond3083, label %bb_rcslotdrop504, label %bb_rcslotdone504
bb_rcslotdrop504:
  %v3084 = load i64, ptr %slot10, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i32 0, ptr %p3085, align 4, !alias.scope !3, !noalias !4
  %v3086 = load i64, ptr %slot43, align 8
  store i64 %v3086, ptr %slot387, align 8
  %v3087 = load i64, ptr %slot11, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i32, ptr %p3088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3089, ptr %slot388, align 8
  %v3090 = load i32, ptr %slot388, align 8
  %op3091 = and i32 %v3090, 28
  store i32 %op3091, ptr %slot389, align 8
  %v3092 = load i32, ptr %slot389, align 8
  %cv3093 = zext i32 %v3092 to i64
  %cond3094 = icmp ne i64 %cv3093, 0
  br i1 %cond3094, label %bb_rcslotrole504, label %bb_rcslotowner504
bb_rcslotrole504:
  %v3095 = load i64, ptr %slot71, align 8
  store i64 %v3095, ptr %slot390, align 8
  %v3096 = load i64, ptr %slot387, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i64, ptr %p3097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3098, ptr %slot391, align 8
  %v3099 = load i64, ptr %slot391, align 8
  %cmp3100 = icmp ne i64 %v3099, 0
  %cv3101 = zext i1 %cmp3100 to i32
  store i32 %cv3101, ptr %slot392, align 8
  %v3102 = load i32, ptr %slot392, align 8
  %cv3103 = zext i32 %v3102 to i64
  %cond3104 = icmp ne i64 %cv3103, 0
  br i1 %cond3104, label %bb_rcgnn520, label %bb_rcgdone520
bb_rcgnn520:
  %v3105 = load i64, ptr %slot391, align 8
  %op3106 = sub i64 %v3105, 16
  store i64 %op3106, ptr %slot393, align 8
  %v3107 = load i64, ptr %slot391, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %rgep3109 = getelementptr i8, ptr %p3108, i64 -16
  %ld3110 = load i64, ptr %rgep3109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3110, ptr %slot394, align 8
  %v3111 = load i64, ptr %slot394, align 8
  %op3112 = and i64 %v3111, 4611686018427387906
  store i64 %op3112, ptr %slot395, align 8
  %v3113 = load i64, ptr %slot395, align 8
  %cmp3114 = icmp ne i64 %v3113, 0
  %cv3115 = zext i1 %cmp3114 to i32
  store i32 %cv3115, ptr %slot396, align 8
  %v3116 = load i32, ptr %slot396, align 8
  %cv3117 = zext i32 %v3116 to i64
  %cond3118 = icmp ne i64 %cv3117, 0
  br i1 %cond3118, label %bb_rcgclear520, label %bb_rcgcounted520
bb_rcgcounted520:
  %v3119 = load i64, ptr %slot391, align 8
  %op3120 = sub i64 %v3119, 24
  store i64 %op3120, ptr %slot397, align 8
  %v3121 = load i64, ptr %slot391, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %rgep3123 = getelementptr i8, ptr %p3122, i64 -24
  %ld3124 = load i64, ptr %rgep3123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3124, ptr %slot398, align 8
  %v3125 = load i64, ptr %slot398, align 8
  %op3126 = sub i64 %v3125, 1
  store i64 %op3126, ptr %slot399, align 8
  %v3127 = load i64, ptr %slot399, align 8
  %cmp3128 = icmp eq i64 %v3127, 0
  %cv3129 = zext i1 %cmp3128 to i32
  store i32 %cv3129, ptr %slot400, align 8
  %v3130 = load i32, ptr %slot400, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcglast520, label %bb_rcgdec520
bb_rcglast520:
  %v3133 = load i64, ptr %slot391, align 8
  %op3134 = sub i64 %v3133, 32
  store i64 %op3134, ptr %slot401, align 8
  %v3135 = load i64, ptr %slot391, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %rgep3137 = getelementptr i8, ptr %p3136, i64 -32
  %ld3138 = load i64, ptr %rgep3137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3138, ptr %slot402, align 8
  %v3139 = load i64, ptr %slot402, align 8
  %cmp3140 = icmp ne i64 %v3139, 0
  %cv3141 = zext i1 %cmp3140 to i32
  store i32 %cv3141, ptr %slot403, align 8
  %v3142 = load i32, ptr %slot403, align 8
  %cv3143 = zext i32 %v3142 to i64
  %cond3144 = icmp ne i64 %cv3143, 0
  br i1 %cond3144, label %bb_rcgdec520, label %bb_rcgslow520
bb_rcgslow520:
  %v3145 = load i64, ptr %slot390, align 8
  %v3146 = load i64, ptr %slot387, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_unloan(i64 %v3145, i64 %v3146) nomerge, !dbg !142
  br label %bb_rcgdone520
bb_rcgdec520:
  %v3147 = load i64, ptr %slot399, align 8
  %v3148 = load i64, ptr %slot391, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  %rgep3150 = getelementptr i8, ptr %p3149, i64 -24
  store i64 %v3147, ptr %rgep3150, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear520
bb_rcgclear520:
  %v3151 = load i64, ptr %slot387, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i64 0, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone520
bb_rcgdone520:
  br label %bb_rcslotdone504
bb_rcslotowner504:
  %v3153 = load i64, ptr %slot71, align 8
  store i64 %v3153, ptr %slot404, align 8
  %v3154 = load i64, ptr %slot387, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i64, ptr %p3155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3156, ptr %slot405, align 8
  %v3157 = load i64, ptr %slot405, align 8
  %cmp3158 = icmp ne i64 %v3157, 0
  %cv3159 = zext i1 %cmp3158 to i32
  store i32 %cv3159, ptr %slot406, align 8
  %v3160 = load i32, ptr %slot406, align 8
  %cv3161 = zext i32 %v3160 to i64
  %cond3162 = icmp ne i64 %cv3161, 0
  br i1 %cond3162, label %bb_rcgnn535, label %bb_rcgdone535
bb_rcgnn535:
  %v3163 = load i64, ptr %slot405, align 8
  %op3164 = sub i64 %v3163, 16
  store i64 %op3164, ptr %slot407, align 8
  %v3165 = load i64, ptr %slot405, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %rgep3167 = getelementptr i8, ptr %p3166, i64 -16
  %ld3168 = load i64, ptr %rgep3167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3168, ptr %slot408, align 8
  %v3169 = load i64, ptr %slot408, align 8
  %op3170 = and i64 %v3169, 4611686018427387906
  store i64 %op3170, ptr %slot409, align 8
  %v3171 = load i64, ptr %slot409, align 8
  %cmp3172 = icmp ne i64 %v3171, 0
  %cv3173 = zext i1 %cmp3172 to i32
  store i32 %cv3173, ptr %slot410, align 8
  %v3174 = load i32, ptr %slot410, align 8
  %cv3175 = zext i32 %v3174 to i64
  %cond3176 = icmp ne i64 %cv3175, 0
  br i1 %cond3176, label %bb_rcgclear535, label %bb_rcgcounted535
bb_rcgcounted535:
  %v3177 = load i64, ptr %slot405, align 8
  %op3178 = sub i64 %v3177, 32
  store i64 %op3178, ptr %slot411, align 8
  %v3179 = load i64, ptr %slot405, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  %rgep3181 = getelementptr i8, ptr %p3180, i64 -32
  %ld3182 = load i64, ptr %rgep3181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3182, ptr %slot412, align 8
  %v3183 = load i64, ptr %slot412, align 8
  %op3184 = sub i64 %v3183, 1
  store i64 %op3184, ptr %slot413, align 8
  %v3185 = load i64, ptr %slot413, align 8
  %cmp3186 = icmp eq i64 %v3185, 0
  %cv3187 = zext i1 %cmp3186 to i32
  store i32 %cv3187, ptr %slot414, align 8
  %v3188 = load i32, ptr %slot414, align 8
  %cv3189 = zext i32 %v3188 to i64
  %cond3190 = icmp ne i64 %cv3189, 0
  br i1 %cond3190, label %bb_rcglast535, label %bb_rcgdec535
bb_rcglast535:
  %v3191 = load i64, ptr %slot405, align 8
  %op3192 = sub i64 %v3191, 24
  store i64 %op3192, ptr %slot415, align 8
  %v3193 = load i64, ptr %slot405, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  %rgep3195 = getelementptr i8, ptr %p3194, i64 -24
  %ld3196 = load i64, ptr %rgep3195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3196, ptr %slot416, align 8
  %v3197 = load i64, ptr %slot416, align 8
  %cmp3198 = icmp ne i64 %v3197, 0
  %cv3199 = zext i1 %cmp3198 to i32
  store i32 %cv3199, ptr %slot417, align 8
  %v3200 = load i32, ptr %slot417, align 8
  %cv3201 = zext i32 %v3200 to i64
  %cond3202 = icmp ne i64 %cv3201, 0
  br i1 %cond3202, label %bb_rcgdec535, label %bb_rcgslow535
bb_rcgslow535:
  %v3203 = load i64, ptr %slot404, align 8
  %v3204 = load i64, ptr %slot387, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_drop(i64 %v3203, i64 %v3204) nomerge, !dbg !142
  br label %bb_rcgdone535
bb_rcgdec535:
  %v3205 = load i64, ptr %slot413, align 8
  %v3206 = load i64, ptr %slot405, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %rgep3208 = getelementptr i8, ptr %p3207, i64 -32
  store i64 %v3205, ptr %rgep3208, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear535
bb_rcgclear535:
  %v3209 = load i64, ptr %slot387, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 0, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone535
bb_rcgdone535:
  br label %bb_rcslotdone504
bb_rcslotdone504:
  %v3211 = load i64, ptr %slot43, align 8
  store i64 %v3211, ptr %slot418, align 8
  %v3212 = load i64, ptr %slot384, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot419, align 8
  %v3215 = load i64, ptr %slot419, align 8
  %v3216 = load i64, ptr %slot418, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i64 %v3215, ptr %p3217, align 8, !alias.scope !3, !noalias !4
  %v3218 = load i64, ptr %slot11, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  store i32 2, ptr %p3219, align 4, !alias.scope !3, !noalias !4
  %v3220 = load i64, ptr %slot11, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  store i32 8, ptr %p3221, align 4, !alias.scope !3, !noalias !4
  %v3222 = load i64, ptr %slot10, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  store i32 1, ptr %p3223, align 4, !alias.scope !3, !noalias !4
  %v3224 = load i64, ptr %slot24, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  store i32 0, ptr %p3225, align 4, !alias.scope !3, !noalias !4
  %v3226 = load i64, ptr %slot58, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  store i64 0, ptr %p3227, align 8, !alias.scope !3, !noalias !4
  %v3228 = load i64, ptr %slot58, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  %ld3230 = load i64, ptr %p3229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3230, ptr %slot420, align 8
  %v3231 = load i64, ptr %slot420, align 8
  %v3232 = load i64, ptr %slot44, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i64 %v3231, ptr %p3233, align 8, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot43, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  %ld3236 = load i64, ptr %p3235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3236, ptr %slot421, align 8
  %v3237 = load i64, ptr %slot421, align 8
  %op3238 = add i64 %v3237, 0
  store i64 %op3238, ptr %slot422, align 8
  %v3239 = load i64, ptr %slot422, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %ld3241 = load i64, ptr %p3240, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3241, ptr %slot423, align 8
  %v3242 = load i64, ptr %slot423, align 8
  %v3243 = load i64, ptr %slot58, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i64 %v3242, ptr %p3244, align 8, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot58, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  %ld3247 = load i64, ptr %p3246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3247, ptr %slot424, align 8
  %v3248 = load i64, ptr %slot424, align 8
  %cmp3249 = icmp ugt i64 %v3248, 9223372036854775807
  %cv3250 = zext i1 %cmp3249 to i64
  store i64 %cv3250, ptr %slot425, align 8
  %v3251 = load i64, ptr %slot425, align 8
  %cond3252 = icmp ne i64 %v3251, 0
  br i1 %cond3252, label %bb_cast_overflow551, label %bb_cast_ok551
bb_cast_overflow551:
  %v3253 = load i64, ptr %slot1, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %v3255 = load i64, ptr %slot424, align 8
  call void @myl_qbe_fail_cast(ptr %p3254, i64 %v3255, i64 320) nomerge, !dbg !144
  unreachable
bb_cast_ok551:
  %v3256 = load i64, ptr %slot424, align 8
  %v3257 = load i64, ptr %slot58, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  store i64 %v3256, ptr %p3258, align 8, !alias.scope !3, !noalias !4
  %v3259 = load i64, ptr %slot58, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i64, ptr %p3260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3261, ptr %slot426, align 8
  %v3262 = load i64, ptr %slot426, align 8
  %v3263 = load i64, ptr %slot45, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  store i64 %v3262, ptr %p3264, align 8, !alias.scope !3, !noalias !4
  br label %bb_i45
bb_i45:
  %v3265 = load i64, ptr %slot44, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  %ld3267 = load i64, ptr %p3266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3267, ptr %slot427, align 8
  %v3268 = load i64, ptr %slot427, align 8
  %v3269 = load i64, ptr %slot58, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  store i64 %v3268, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  %v3271 = load i64, ptr %slot45, align 8
  %p3272 = inttoptr i64 %v3271 to ptr
  %ld3273 = load i64, ptr %p3272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3273, ptr %slot428, align 8
  %v3274 = load i64, ptr %slot428, align 8
  %v3275 = load i64, ptr %slot59, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  store i64 %v3274, ptr %p3276, align 8, !alias.scope !3, !noalias !4
  %v3277 = load i64, ptr %slot59, align 8
  %p3278 = inttoptr i64 %v3277 to ptr
  %ld3279 = load i64, ptr %p3278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3279, ptr %slot429, align 8
  %v3280 = load i64, ptr %slot58, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %ld3282 = load i64, ptr %p3281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3282, ptr %slot430, align 8
  %v3283 = load i64, ptr %slot430, align 8
  %v3284 = load i64, ptr %slot429, align 8
  %cmp3285 = icmp slt i64 %v3283, %v3284
  %cv3286 = zext i1 %cmp3285 to i64
  store i64 %cv3286, ptr %slot431, align 8
  %v3287 = load i64, ptr %slot431, align 8
  %v3288 = load i64, ptr %slot58, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i64 %v3287, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot58, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ld3292 = load i64, ptr %p3291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3292, ptr %slot432, align 8
  %v3293 = load i64, ptr %slot432, align 8
  %cond3294 = icmp ne i64 %v3293, 0
  br i1 %cond3294, label %bb_next559, label %bb_i82
bb_next559:
  %v3295 = load i64, ptr %slot45, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %ld3297 = load i64, ptr %p3296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3297, ptr %slot433, align 8
  %v3298 = load i64, ptr %slot433, align 8
  %v3299 = load i64, ptr %slot58, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  store i64 %v3298, ptr %p3300, align 8, !alias.scope !3, !noalias !4
  %v3301 = load i64, ptr %slot43, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  %ld3303 = load i64, ptr %p3302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3303, ptr %slot434, align 8
  %v3304 = load i64, ptr %slot58, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  %ld3306 = load i64, ptr %p3305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3306, ptr %slot435, align 8
  %v3307 = load i64, ptr %slot434, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %ld3309 = load i64, ptr %p3308, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3309, ptr %slot436, align 8
  %v3310 = load i64, ptr %slot436, align 8
  %v3311 = load i64, ptr %slot435, align 8
  %cmp3312 = icmp eq i64 %v3310, %v3311
  %cv3313 = zext i1 %cmp3312 to i64
  store i64 %cv3313, ptr %slot437, align 8
  %v3314 = load i64, ptr %slot437, align 8
  %cond3315 = icmp ne i64 %v3314, 0
  br i1 %cond3315, label %bb_success564, label %bb_failed564
bb_failed564:
  %v3316 = load i64, ptr %slot1, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  call void @myl_qbe_fail_iteration(ptr %p3317) nomerge, !dbg !146
  unreachable
bb_success564:
  %v3318 = load i64, ptr %slot58, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i64 0, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot44, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %ld3322 = load i64, ptr %p3321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3322, ptr %slot438, align 8
  %v3323 = load i64, ptr %slot438, align 8
  %v3324 = load i64, ptr %slot58, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  store i64 %v3323, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot43, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %ld3328 = load i64, ptr %p3327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3328, ptr %slot439, align 8
  %v3329 = load i64, ptr %slot58, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %ld3331 = load i64, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3331, ptr %slot440, align 8
  %v3332 = load i64, ptr %slot439, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3334, ptr %slot441, align 8
  %v3335 = load i64, ptr %slot440, align 8
  %v3336 = load i64, ptr %slot441, align 8
  %cmp3337 = icmp ult i64 %v3335, %v3336
  %cv3338 = zext i1 %cmp3337 to i64
  store i64 %cv3338, ptr %slot442, align 8
  %v3339 = load i64, ptr %slot442, align 8
  %cond3340 = icmp ne i64 %v3339, 0
  br i1 %cond3340, label %bb_success571, label %bb_failed571
bb_failed571:
  %v3341 = load i64, ptr %slot1, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %v3343 = load i64, ptr %slot440, align 8
  %v3344 = load i64, ptr %slot441, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3342, i64 %v3343, i64 %v3344) nomerge, !dbg !148
  unreachable
bb_success571:
  %v3345 = load i64, ptr %slot439, align 8
  %op3346 = add i64 %v3345, 32
  store i64 %op3346, ptr %slot443, align 8
  %v3347 = load i64, ptr %slot443, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  %ld3349 = load i64, ptr %p3348, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3349, ptr %slot444, align 8
  %v3350 = load i64, ptr %slot440, align 8
  %op3351 = mul i64 %v3350, 48
  store i64 %op3351, ptr %slot445, align 8
  %v3352 = load i64, ptr %slot444, align 8
  %v3353 = load i64, ptr %slot445, align 8
  %op3354 = add i64 %v3352, %v3353
  store i64 %op3354, ptr %slot446, align 8
  %v3355 = load i64, ptr %slot446, align 8
  %v3356 = load i64, ptr %slot58, align 8
  %p3357 = inttoptr i64 %v3356 to ptr
  store i64 %v3355, ptr %p3357, align 8, !alias.scope !3, !noalias !4
  %v3358 = load i64, ptr %slot58, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3360, ptr %slot447, align 8
  %v3361 = load i64, ptr %slot30, align 8
  store i64 %v3361, ptr %slot448, align 8
  %v3362 = load i64, ptr %slot71, align 8
  %v3363 = load i64, ptr %slot448, align 8
  %v3364 = load i64, ptr %slot447, align 8
  %call3365 = call i32 @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_loan(i64 %v3362, i64 %v3363, i64 %v3364) nomerge, !dbg !148
  store i32 %call3365, ptr %slot449, align 8
  %v3366 = load i32, ptr %slot449, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcsuccess579, label %bb_rcfailure579
bb_rcfailure579:
  %v3369 = load i64, ptr %slot71, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %call3371 = call i32 @myl_rc_take_failure(ptr %p3370) nomerge, !dbg !148
  store i32 %call3371, ptr %slot450, align 8
  %v3372 = load i64, ptr %slot1, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %v3374 = load i32, ptr %slot450, align 8
  %call3375 = call i32 @myl_qbe_rc_status(ptr %p3373, i32 %v3374) nomerge, !dbg !148
  store i32 %call3375, ptr %slot451, align 8
  br label %bb_failure
bb_rcsuccess579:
  %v3376 = load i64, ptr %slot25, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  store i32 2, ptr %p3377, align 4, !alias.scope !3, !noalias !4
  %v3378 = load i64, ptr %slot25, align 8
  %p3379 = inttoptr i64 %v3378 to ptr
  store i32 16, ptr %p3379, align 4, !alias.scope !3, !noalias !4
  %v3380 = load i64, ptr %slot24, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  store i32 1, ptr %p3381, align 4, !alias.scope !3, !noalias !4
  %v3382 = load i64, ptr %slot27, align 8
  store i64 %v3382, ptr %slot452, align 8
  %v3383 = load i64, ptr %slot30, align 8
  store i64 %v3383, ptr %slot453, align 8
  %v3384 = load i64, ptr %slot453, align 8
  %v3385 = load i64, ptr %slot452, align 8
  %p3386 = inttoptr i64 %v3384 to ptr
  %p3387 = inttoptr i64 %v3385 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3387, ptr %p3386, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3388 = load i64, ptr %slot21, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  store i32 2, ptr %p3389, align 4, !alias.scope !3, !noalias !4
  %v3390 = load i64, ptr %slot25, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %ld3392 = load i32, ptr %p3391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3392, ptr %slot454, align 8
  %v3393 = load i32, ptr %slot454, align 8
  %v3394 = load i64, ptr %slot21, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  store i32 %v3393, ptr %p3395, align 4, !alias.scope !3, !noalias !4
  %v3396 = load i64, ptr %slot24, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  store i32 0, ptr %p3397, align 4, !alias.scope !3, !noalias !4
  %v3398 = load i64, ptr %slot20, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  store i32 1, ptr %p3399, align 4, !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot452, align 8
  %v3401 = load i64, ptr %slot58, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  store i64 %v3400, ptr %p3402, align 8, !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot58, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %ld3405 = load i64, ptr %p3404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3405, ptr %slot455, align 8
  %v3406 = load i64, ptr %slot20, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  %ld3408 = load i32, ptr %p3407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3408, ptr %slot456, align 8
  %v3409 = load i64, ptr %slot21, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i32, ptr %p3410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3411, ptr %slot457, align 8
  %v3412 = load i32, ptr %slot457, align 8
  %op3413 = and i32 %v3412, 24
  store i32 %op3413, ptr %slot457, align 8
  %v3414 = load i32, ptr %slot457, align 8
  %cmp3415 = icmp eq i32 %v3414, 0
  %cv3416 = zext i1 %cmp3415 to i32
  store i32 %cv3416, ptr %slot458, align 8
  %v3417 = load i32, ptr %slot456, align 8
  %v3418 = load i32, ptr %slot458, align 8
  %op3419 = and i32 %v3417, %v3418
  store i32 %op3419, ptr %slot459, align 8
  %v3420 = load i32, ptr %slot459, align 8
  %cv3421 = zext i32 %v3420 to i64
  %cond3422 = icmp ne i64 %cv3421, 0
  br i1 %cond3422, label %bb_rcprivateown600, label %bb_rcprivateloan600
bb_rcprivateown600:
  %v3423 = load i64, ptr %slot30, align 8
  store i64 %v3423, ptr %slot460, align 8
  %v3424 = load i64, ptr %slot72, align 8
  store i64 %v3424, ptr %slot461, align 8
  %v3425 = load i64, ptr %slot71, align 8
  %v3426 = load i64, ptr %slot460, align 8
  %v3427 = load i64, ptr %slot455, align 8
  %v3428 = load i64, ptr %slot461, align 8
  %cv3429 = trunc i64 %v3428 to i32
  %call3430 = call i32 @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_take(i64 %v3425, i64 %v3426, i64 %v3427, i32 %cv3429) nomerge, !dbg !150
  store i32 %call3430, ptr %slot462, align 8
  %v3431 = load i32, ptr %slot462, align 8
  %cv3432 = zext i32 %v3431 to i64
  %cond3433 = icmp ne i64 %cv3432, 0
  br i1 %cond3433, label %bb_rcsuccess604, label %bb_rcfailure604
bb_rcfailure604:
  %v3434 = load i64, ptr %slot71, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %call3436 = call i32 @myl_rc_take_failure(ptr %p3435) nomerge, !dbg !150
  store i32 %call3436, ptr %slot463, align 8
  %v3437 = load i64, ptr %slot1, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  %v3439 = load i32, ptr %slot463, align 8
  %call3440 = call i32 @myl_qbe_rc_status(ptr %p3438, i32 %v3439) nomerge, !dbg !150
  store i32 %call3440, ptr %slot464, align 8
  br label %bb_failure
bb_rcsuccess604:
  %v3441 = load i64, ptr %slot20, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  store i32 0, ptr %p3442, align 4, !alias.scope !3, !noalias !4
  %v3443 = load i64, ptr %slot25, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  store i32 2, ptr %p3444, align 4, !alias.scope !3, !noalias !4
  %v3445 = load i64, ptr %slot24, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  store i32 1, ptr %p3446, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared600
bb_rcprivateloan600:
  %v3447 = load i64, ptr %slot20, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  %ld3449 = load i32, ptr %p3448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3449, ptr %slot465, align 8
  %v3450 = load i64, ptr %slot21, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i32, ptr %p3451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3452, ptr %slot466, align 8
  %v3453 = load i32, ptr %slot466, align 8
  %cmp3454 = icmp eq i32 %v3453, 16
  %cv3455 = zext i1 %cmp3454 to i32
  store i32 %cv3455, ptr %slot467, align 8
  %v3456 = load i32, ptr %slot467, align 8
  %v3457 = load i32, ptr %slot465, align 8
  %op3458 = and i32 %v3456, %v3457
  store i32 %op3458, ptr %slot467, align 8
  %v3459 = load i32, ptr %slot467, align 8
  %cv3460 = zext i32 %v3459 to i64
  %cond3461 = icmp ne i64 %cv3460, 0
  br i1 %cond3461, label %bb_rcprivatemove600, label %bb_rcprivatenew600
bb_rcprivatemove600:
  %v3462 = load i64, ptr %slot30, align 8
  store i64 %v3462, ptr %slot468, align 8
  %v3463 = load i64, ptr %slot455, align 8
  %v3464 = load i64, ptr %slot468, align 8
  %p3465 = inttoptr i64 %v3463 to ptr
  %p3466 = inttoptr i64 %v3464 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3466, ptr %p3465, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3467 = load i64, ptr %slot455, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  call void @llvm.memset.p0.i64(ptr %p3468, i8 0, i64 48, i1 false), !alias.scope !3, !noalias !4, !dbg !150
  %v3469 = load i64, ptr %slot25, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  store i32 2, ptr %p3470, align 4, !alias.scope !3, !noalias !4
  %v3471 = load i64, ptr %slot25, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i32 16, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot24, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i32 1, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot20, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i32 0, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared600
bb_rcprivatenew600:
  %v3477 = load i64, ptr %slot30, align 8
  store i64 %v3477, ptr %slot469, align 8
  %v3478 = load i64, ptr %slot71, align 8
  %v3479 = load i64, ptr %slot469, align 8
  %v3480 = load i64, ptr %slot455, align 8
  %call3481 = call i32 @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_loan(i64 %v3478, i64 %v3479, i64 %v3480) nomerge, !dbg !150
  store i32 %call3481, ptr %slot470, align 8
  %v3482 = load i32, ptr %slot470, align 8
  %cv3483 = zext i32 %v3482 to i64
  %cond3484 = icmp ne i64 %cv3483, 0
  br i1 %cond3484, label %bb_rcsuccess622, label %bb_rcfailure622
bb_rcfailure622:
  %v3485 = load i64, ptr %slot71, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  %call3487 = call i32 @myl_rc_take_failure(ptr %p3486) nomerge, !dbg !150
  store i32 %call3487, ptr %slot471, align 8
  %v3488 = load i64, ptr %slot1, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %v3490 = load i32, ptr %slot471, align 8
  %call3491 = call i32 @myl_qbe_rc_status(ptr %p3489, i32 %v3490) nomerge, !dbg !150
  store i32 %call3491, ptr %slot472, align 8
  br label %bb_failure
bb_rcsuccess622:
  %v3492 = load i64, ptr %slot25, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i32 2, ptr %p3493, align 4, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot25, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  store i32 16, ptr %p3495, align 4, !alias.scope !3, !noalias !4
  %v3496 = load i64, ptr %slot24, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  store i32 1, ptr %p3497, align 4, !alias.scope !3, !noalias !4
  %v3498 = load i64, ptr %slot20, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  %ld3500 = load i32, ptr %p3499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3500, ptr %slot473, align 8
  %v3501 = load i32, ptr %slot473, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcslotdrop630, label %bb_rcslotdone630
bb_rcslotdrop630:
  %v3504 = load i64, ptr %slot20, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i32 0, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  %v3506 = load i64, ptr %slot27, align 8
  store i64 %v3506, ptr %slot474, align 8
  %v3507 = load i64, ptr %slot21, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i32, ptr %p3508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3509, ptr %slot475, align 8
  %v3510 = load i32, ptr %slot475, align 8
  %op3511 = and i32 %v3510, 28
  store i32 %op3511, ptr %slot476, align 8
  %v3512 = load i32, ptr %slot476, align 8
  %cv3513 = zext i32 %v3512 to i64
  %cond3514 = icmp ne i64 %cv3513, 0
  br i1 %cond3514, label %bb_rcslotrole630, label %bb_rcslotowner630
bb_rcslotrole630:
  %v3515 = load i64, ptr %slot71, align 8
  store i64 %v3515, ptr %slot477, align 8
  %v3516 = load i64, ptr %slot477, align 8
  %v3517 = load i64, ptr %slot474, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64 %v3516, i64 %v3517) nomerge, !dbg !150
  br label %bb_rcslotdone630
bb_rcslotowner630:
  %v3518 = load i64, ptr %slot71, align 8
  store i64 %v3518, ptr %slot478, align 8
  %v3519 = load i64, ptr %slot478, align 8
  %v3520 = load i64, ptr %slot474, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64 %v3519, i64 %v3520) nomerge, !dbg !150
  br label %bb_rcslotdone630
bb_rcslotdone630:
  br label %bb_rcprivateprepared600
bb_rcprivateprepared600:
  %v3521 = load i64, ptr %slot12, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %ld3523 = load i32, ptr %p3522, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3523, ptr %slot479, align 8
  %v3524 = load i32, ptr %slot479, align 8
  %cv3525 = zext i32 %v3524 to i64
  %cond3526 = icmp ne i64 %cv3525, 0
  br i1 %cond3526, label %bb_rcslotdrop640, label %bb_rcslotdone640
bb_rcslotdrop640:
  %v3527 = load i64, ptr %slot12, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  store i32 0, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  %v3529 = load i64, ptr %slot46, align 8
  store i64 %v3529, ptr %slot480, align 8
  %v3530 = load i64, ptr %slot13, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %ld3532 = load i32, ptr %p3531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3532, ptr %slot481, align 8
  %v3533 = load i32, ptr %slot481, align 8
  %op3534 = and i32 %v3533, 28
  store i32 %op3534, ptr %slot482, align 8
  %v3535 = load i32, ptr %slot482, align 8
  %cv3536 = zext i32 %v3535 to i64
  %cond3537 = icmp ne i64 %cv3536, 0
  br i1 %cond3537, label %bb_rcslotrole640, label %bb_rcslotowner640
bb_rcslotrole640:
  %v3538 = load i64, ptr %slot71, align 8
  store i64 %v3538, ptr %slot483, align 8
  %v3539 = load i64, ptr %slot483, align 8
  %v3540 = load i64, ptr %slot480, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64 %v3539, i64 %v3540) nomerge, !dbg !150
  br label %bb_rcslotdone640
bb_rcslotowner640:
  %v3541 = load i64, ptr %slot71, align 8
  store i64 %v3541, ptr %slot484, align 8
  %v3542 = load i64, ptr %slot484, align 8
  %v3543 = load i64, ptr %slot480, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64 %v3542, i64 %v3543) nomerge, !dbg !150
  br label %bb_rcslotdone640
bb_rcslotdone640:
  %v3544 = load i64, ptr %slot46, align 8
  store i64 %v3544, ptr %slot485, align 8
  %v3545 = load i64, ptr %slot30, align 8
  store i64 %v3545, ptr %slot486, align 8
  %v3546 = load i64, ptr %slot486, align 8
  %v3547 = load i64, ptr %slot485, align 8
  %p3548 = inttoptr i64 %v3546 to ptr
  %p3549 = inttoptr i64 %v3547 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3549, ptr %p3548, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3550 = load i64, ptr %slot24, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  store i32 0, ptr %p3551, align 4, !alias.scope !3, !noalias !4
  %v3552 = load i64, ptr %slot13, align 8
  %p3553 = inttoptr i64 %v3552 to ptr
  store i32 2, ptr %p3553, align 4, !alias.scope !3, !noalias !4
  %v3554 = load i64, ptr %slot25, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  %ld3556 = load i32, ptr %p3555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3556, ptr %slot487, align 8
  %v3557 = load i32, ptr %slot487, align 8
  %v3558 = load i64, ptr %slot13, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  store i32 %v3557, ptr %p3559, align 4, !alias.scope !3, !noalias !4
  %v3560 = load i64, ptr %slot12, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i32 1, ptr %p3561, align 4, !alias.scope !3, !noalias !4
  %v3562 = load i64, ptr %slot34, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  %ld3564 = load i64, ptr %p3563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3564, ptr %slot488, align 8
  %v3565 = load i64, ptr %slot488, align 8
  %v3566 = load i64, ptr %slot58, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  store i64 %v3565, ptr %p3567, align 8, !alias.scope !3, !noalias !4
  %v3568 = load i64, ptr %slot46, align 8
  %v3569 = load i64, ptr %slot59, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  store i64 %v3568, ptr %p3570, align 8, !alias.scope !3, !noalias !4
  %v3571 = load i64, ptr %slot59, align 8
  %p3572 = inttoptr i64 %v3571 to ptr
  %ld3573 = load i64, ptr %p3572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3573, ptr %slot489, align 8
  %v3574 = load i64, ptr %slot489, align 8
  %op3575 = add i64 %v3574, 40
  store i64 %op3575, ptr %slot490, align 8
  %v3576 = load i64, ptr %slot490, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %ld3578 = load i64, ptr %p3577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3578, ptr %slot491, align 8
  %v3579 = load i64, ptr %slot491, align 8
  %v3580 = load i64, ptr %slot59, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  store i64 %v3579, ptr %p3581, align 8, !alias.scope !3, !noalias !4
  %v3582 = load i64, ptr %slot22, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  %ld3584 = load i32, ptr %p3583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3584, ptr %slot492, align 8
  %v3585 = load i32, ptr %slot492, align 8
  %cv3586 = zext i32 %v3585 to i64
  %cond3587 = icmp ne i64 %cv3586, 0
  br i1 %cond3587, label %bb_rcslotdrop660, label %bb_rcslotdone660
bb_rcslotdrop660:
  %v3588 = load i64, ptr %slot22, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  store i32 0, ptr %p3589, align 4, !alias.scope !3, !noalias !4
  %v3590 = load i64, ptr %slot28, align 8
  store i64 %v3590, ptr %slot493, align 8
  %v3591 = load i64, ptr %slot23, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  %ld3593 = load i32, ptr %p3592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3593, ptr %slot494, align 8
  %v3594 = load i32, ptr %slot494, align 8
  %op3595 = and i32 %v3594, 28
  store i32 %op3595, ptr %slot495, align 8
  %v3596 = load i32, ptr %slot495, align 8
  %cv3597 = zext i32 %v3596 to i64
  %cond3598 = icmp ne i64 %cv3597, 0
  br i1 %cond3598, label %bb_rcslotrole660, label %bb_rcslotowner660
bb_rcslotrole660:
  %v3599 = load i64, ptr %slot71, align 8
  store i64 %v3599, ptr %slot496, align 8
  %v3600 = load i64, ptr %slot496, align 8
  %v3601 = load i64, ptr %slot493, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64 %v3600, i64 %v3601) nomerge, !dbg !152
  br label %bb_rcslotdone660
bb_rcslotowner660:
  %v3602 = load i64, ptr %slot71, align 8
  store i64 %v3602, ptr %slot497, align 8
  %v3603 = load i64, ptr %slot497, align 8
  %v3604 = load i64, ptr %slot493, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64 %v3603, i64 %v3604) nomerge, !dbg !152
  br label %bb_rcslotdone660
bb_rcslotdone660:
  %v3605 = load i64, ptr %slot46, align 8
  %v3606 = load i64, ptr %slot60, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  store i64 %v3605, ptr %p3607, align 8, !alias.scope !3, !noalias !4
  %v3608 = load i64, ptr %slot60, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i64, ptr %p3609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3610, ptr %slot498, align 8
  %v3611 = load i64, ptr %slot498, align 8
  %op3612 = add i64 %v3611, 0
  store i64 %op3612, ptr %slot499, align 8
  %v3613 = load i64, ptr %slot499, align 8
  %v3614 = load i64, ptr %slot60, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i64 %v3613, ptr %p3615, align 8, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot60, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  %ld3618 = load i64, ptr %p3617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3618, ptr %slot500, align 8
  %v3619 = load i64, ptr %slot500, align 8
  %op3620 = add i64 %v3619, 24
  store i64 %op3620, ptr %slot501, align 8
  %v3621 = load i64, ptr %slot501, align 8
  %p3622 = inttoptr i64 %v3621 to ptr
  %ld3623 = load i64, ptr %p3622, align 8
  store i64 %ld3623, ptr %slot502, align 8
  %v3624 = load i64, ptr %slot502, align 8
  %v3625 = load i64, ptr %slot60, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i64 %v3624, ptr %p3626, align 8, !alias.scope !3, !noalias !4
  %v3627 = load i64, ptr %slot46, align 8
  %v3628 = load i64, ptr %slot61, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  store i64 %v3627, ptr %p3629, align 8, !alias.scope !3, !noalias !4
  %v3630 = load i64, ptr %slot61, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  %ld3632 = load i64, ptr %p3631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3632, ptr %slot503, align 8
  %v3633 = load i64, ptr %slot503, align 8
  %op3634 = add i64 %v3633, 0
  store i64 %op3634, ptr %slot504, align 8
  %v3635 = load i64, ptr %slot504, align 8
  %v3636 = load i64, ptr %slot61, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  store i64 %v3635, ptr %p3637, align 8, !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot61, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  %ld3640 = load i64, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3640, ptr %slot505, align 8
  %v3641 = load i64, ptr %slot505, align 8
  %op3642 = add i64 %v3641, 8
  store i64 %op3642, ptr %slot506, align 8
  %v3643 = load i64, ptr %slot506, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %ld3645 = load i64, ptr %p3644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3645, ptr %slot507, align 8
  %v3646 = load i64, ptr %slot507, align 8
  %v3647 = load i64, ptr %slot61, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  store i64 %v3646, ptr %p3648, align 8, !alias.scope !3, !noalias !4
  %v3649 = load i64, ptr %slot46, align 8
  %v3650 = load i64, ptr %slot62, align 8
  %p3651 = inttoptr i64 %v3650 to ptr
  store i64 %v3649, ptr %p3651, align 8, !alias.scope !3, !noalias !4
  %v3652 = load i64, ptr %slot62, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %ld3654 = load i64, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3654, ptr %slot508, align 8
  %v3655 = load i64, ptr %slot508, align 8
  %op3656 = add i64 %v3655, 0
  store i64 %op3656, ptr %slot509, align 8
  %v3657 = load i64, ptr %slot509, align 8
  %v3658 = load i64, ptr %slot62, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  store i64 %v3657, ptr %p3659, align 8, !alias.scope !3, !noalias !4
  %v3660 = load i64, ptr %slot62, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  %ld3662 = load i64, ptr %p3661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3662, ptr %slot510, align 8
  %v3663 = load i64, ptr %slot510, align 8
  %op3664 = add i64 %v3663, 16
  store i64 %op3664, ptr %slot511, align 8
  %v3665 = load i64, ptr %slot511, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  %ld3667 = load i64, ptr %p3666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3667, ptr %slot512, align 8
  %v3668 = load i64, ptr %slot512, align 8
  %v3669 = load i64, ptr %slot62, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  store i64 %v3668, ptr %p3670, align 8, !alias.scope !3, !noalias !4
  %v3671 = load i64, ptr %slot58, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  %ld3673 = load i64, ptr %p3672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3673, ptr %slot513, align 8
  %v3674 = load i64, ptr %slot59, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  %ld3676 = load i64, ptr %p3675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3676, ptr %slot514, align 8
  %v3677 = load i64, ptr %slot60, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %ld3679 = load i64, ptr %p3678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3679, ptr %slot515, align 8
  %v3680 = load i64, ptr %slot61, align 8
  %p3681 = inttoptr i64 %v3680 to ptr
  %ld3682 = load i64, ptr %p3681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3682, ptr %slot516, align 8
  %v3683 = load i64, ptr %slot62, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  %ld3685 = load i64, ptr %p3684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3685, ptr %slot517, align 8
  %v3686 = load i64, ptr %slot1, align 8
  %v3687 = load i64, ptr %slot513, align 8
  %v3688 = load i64, ptr %slot514, align 8
  %v3689 = load i64, ptr %slot515, align 8
  %v3690 = load i64, ptr %slot516, align 8
  %v3691 = load i64, ptr %slot517, align 8
  %call3692 = call i64 @myl_f_6c20f2e9fdceb7f443853563e8f4b2f8857cebc813cc7546dd2353da4642f0e3(i64 %v3686, i64 %v3687, i64 %v3688, i64 %v3689, i64 %v3690, i64 %v3691) nomerge, !dbg !154
  store i64 %call3692, ptr %slot518, align 8
  %v3693 = load i64, ptr %slot518, align 8
  %v3694 = load i64, ptr %slot58, align 8
  %p3695 = inttoptr i64 %v3694 to ptr
  store i64 %v3693, ptr %p3695, align 8, !alias.scope !3, !noalias !4
  %v3696 = load i64, ptr %slot20, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i32, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3698, ptr %slot519, align 8
  %v3699 = load i32, ptr %slot519, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcslotdrop744, label %bb_rcslotdone744
bb_rcslotdrop744:
  %v3702 = load i64, ptr %slot20, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  store i32 0, ptr %p3703, align 4, !alias.scope !3, !noalias !4
  %v3704 = load i64, ptr %slot27, align 8
  store i64 %v3704, ptr %slot520, align 8
  %v3705 = load i64, ptr %slot21, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %ld3707 = load i32, ptr %p3706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3707, ptr %slot521, align 8
  %v3708 = load i32, ptr %slot521, align 8
  %op3709 = and i32 %v3708, 28
  store i32 %op3709, ptr %slot522, align 8
  %v3710 = load i32, ptr %slot522, align 8
  %cv3711 = zext i32 %v3710 to i64
  %cond3712 = icmp ne i64 %cv3711, 0
  br i1 %cond3712, label %bb_rcslotrole744, label %bb_rcslotowner744
bb_rcslotrole744:
  %v3713 = load i64, ptr %slot71, align 8
  store i64 %v3713, ptr %slot523, align 8
  %v3714 = load i64, ptr %slot523, align 8
  %v3715 = load i64, ptr %slot520, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3714, i64 %v3715) nomerge, !dbg !154
  br label %bb_rcslotdone744
bb_rcslotowner744:
  %v3716 = load i64, ptr %slot71, align 8
  store i64 %v3716, ptr %slot524, align 8
  %v3717 = load i64, ptr %slot524, align 8
  %v3718 = load i64, ptr %slot520, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3717, i64 %v3718) nomerge, !dbg !154
  br label %bb_rcslotdone744
bb_rcslotdone744:
  %v3719 = load i64, ptr %slot34, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i64, ptr %p3720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3721, ptr %slot525, align 8
  %v3722 = load i64, ptr %slot525, align 8
  %v3723 = load i64, ptr %slot58, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  store i64 %v3722, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  %v3725 = load i64, ptr %slot46, align 8
  %v3726 = load i64, ptr %slot59, align 8
  %p3727 = inttoptr i64 %v3726 to ptr
  store i64 %v3725, ptr %p3727, align 8, !alias.scope !3, !noalias !4
  %v3728 = load i64, ptr %slot59, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  %ld3730 = load i64, ptr %p3729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3730, ptr %slot526, align 8
  %v3731 = load i64, ptr %slot526, align 8
  %op3732 = add i64 %v3731, 40
  store i64 %op3732, ptr %slot527, align 8
  %v3733 = load i64, ptr %slot527, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  %ld3735 = load i64, ptr %p3734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3735, ptr %slot528, align 8
  %v3736 = load i64, ptr %slot528, align 8
  %v3737 = load i64, ptr %slot59, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  store i64 %v3736, ptr %p3738, align 8, !alias.scope !3, !noalias !4
  %v3739 = load i64, ptr %slot22, align 8
  %p3740 = inttoptr i64 %v3739 to ptr
  %ld3741 = load i32, ptr %p3740, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3741, ptr %slot529, align 8
  %v3742 = load i32, ptr %slot529, align 8
  %cv3743 = zext i32 %v3742 to i64
  %cond3744 = icmp ne i64 %cv3743, 0
  br i1 %cond3744, label %bb_rcslotdrop757, label %bb_rcslotdone757
bb_rcslotdrop757:
  %v3745 = load i64, ptr %slot22, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  store i32 0, ptr %p3746, align 4, !alias.scope !3, !noalias !4
  %v3747 = load i64, ptr %slot28, align 8
  store i64 %v3747, ptr %slot530, align 8
  %v3748 = load i64, ptr %slot23, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %ld3750 = load i32, ptr %p3749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3750, ptr %slot531, align 8
  %v3751 = load i32, ptr %slot531, align 8
  %op3752 = and i32 %v3751, 28
  store i32 %op3752, ptr %slot532, align 8
  %v3753 = load i32, ptr %slot532, align 8
  %cv3754 = zext i32 %v3753 to i64
  %cond3755 = icmp ne i64 %cv3754, 0
  br i1 %cond3755, label %bb_rcslotrole757, label %bb_rcslotowner757
bb_rcslotrole757:
  %v3756 = load i64, ptr %slot71, align 8
  store i64 %v3756, ptr %slot533, align 8
  %v3757 = load i64, ptr %slot533, align 8
  %v3758 = load i64, ptr %slot530, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64 %v3757, i64 %v3758) nomerge, !dbg !156
  br label %bb_rcslotdone757
bb_rcslotowner757:
  %v3759 = load i64, ptr %slot71, align 8
  store i64 %v3759, ptr %slot534, align 8
  %v3760 = load i64, ptr %slot534, align 8
  %v3761 = load i64, ptr %slot530, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64 %v3760, i64 %v3761) nomerge, !dbg !156
  br label %bb_rcslotdone757
bb_rcslotdone757:
  %v3762 = load i64, ptr %slot58, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i64, ptr %p3763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3764, ptr %slot535, align 8
  %v3765 = load i64, ptr %slot59, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  %ld3767 = load i64, ptr %p3766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3767, ptr %slot536, align 8
  %v3768 = load i64, ptr %slot1, align 8
  %v3769 = load i64, ptr %slot535, align 8
  %v3770 = load i64, ptr %slot536, align 8
  %call3771 = call i64 @myl_f_def2c666f56e2a58d1d9c20e576b253ae4c59134494ab501e84450cede719ab2(i64 %v3768, i64 %v3769, i64 %v3770) nomerge, !dbg !158
  store i64 %call3771, ptr %slot537, align 8
  %v3772 = load i64, ptr %slot537, align 8
  %v3773 = load i64, ptr %slot58, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  store i64 %v3772, ptr %p3774, align 8, !alias.scope !3, !noalias !4
  %v3775 = load i64, ptr %slot20, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %ld3777 = load i32, ptr %p3776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3777, ptr %slot538, align 8
  %v3778 = load i32, ptr %slot538, align 8
  %cv3779 = zext i32 %v3778 to i64
  %cond3780 = icmp ne i64 %cv3779, 0
  br i1 %cond3780, label %bb_rcslotdrop769, label %bb_rcslotdone769
bb_rcslotdrop769:
  %v3781 = load i64, ptr %slot20, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  store i32 0, ptr %p3782, align 4, !alias.scope !3, !noalias !4
  %v3783 = load i64, ptr %slot27, align 8
  store i64 %v3783, ptr %slot539, align 8
  %v3784 = load i64, ptr %slot21, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %ld3786 = load i32, ptr %p3785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3786, ptr %slot540, align 8
  %v3787 = load i32, ptr %slot540, align 8
  %op3788 = and i32 %v3787, 28
  store i32 %op3788, ptr %slot541, align 8
  %v3789 = load i32, ptr %slot541, align 8
  %cv3790 = zext i32 %v3789 to i64
  %cond3791 = icmp ne i64 %cv3790, 0
  br i1 %cond3791, label %bb_rcslotrole769, label %bb_rcslotowner769
bb_rcslotrole769:
  %v3792 = load i64, ptr %slot71, align 8
  store i64 %v3792, ptr %slot542, align 8
  %v3793 = load i64, ptr %slot542, align 8
  %v3794 = load i64, ptr %slot539, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v3793, i64 %v3794) nomerge, !dbg !158
  br label %bb_rcslotdone769
bb_rcslotowner769:
  %v3795 = load i64, ptr %slot71, align 8
  store i64 %v3795, ptr %slot543, align 8
  %v3796 = load i64, ptr %slot543, align 8
  %v3797 = load i64, ptr %slot539, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v3796, i64 %v3797) nomerge, !dbg !158
  br label %bb_rcslotdone769
bb_rcslotdone769:
  %v3798 = load i64, ptr %slot45, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i64, ptr %p3799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3800, ptr %slot544, align 8
  %v3801 = load i64, ptr %slot544, align 8
  %v3802 = load i64, ptr %slot58, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  store i64 %v3801, ptr %p3803, align 8, !alias.scope !3, !noalias !4
  %v3804 = load i64, ptr %slot43, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %ld3806 = load i64, ptr %p3805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3806, ptr %slot545, align 8
  %v3807 = load i64, ptr %slot58, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %ld3809 = load i64, ptr %p3808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3809, ptr %slot546, align 8
  %v3810 = load i64, ptr %slot545, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %ld3812 = load i64, ptr %p3811, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3812, ptr %slot547, align 8
  %v3813 = load i64, ptr %slot547, align 8
  %v3814 = load i64, ptr %slot546, align 8
  %cmp3815 = icmp eq i64 %v3813, %v3814
  %cv3816 = zext i1 %cmp3815 to i64
  store i64 %cv3816, ptr %slot548, align 8
  %v3817 = load i64, ptr %slot548, align 8
  %cond3818 = icmp ne i64 %v3817, 0
  br i1 %cond3818, label %bb_success781, label %bb_failed781
bb_failed781:
  %v3819 = load i64, ptr %slot1, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  call void @myl_qbe_fail_iteration(ptr %p3820) nomerge, !dbg !160
  unreachable
bb_success781:
  %v3821 = load i64, ptr %slot58, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  store i64 0, ptr %p3822, align 8, !alias.scope !3, !noalias !4
  %v3823 = load i64, ptr %slot44, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  %ld3825 = load i64, ptr %p3824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3825, ptr %slot549, align 8
  %v3826 = load i64, ptr %slot549, align 8
  %v3827 = load i64, ptr %slot58, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  store i64 %v3826, ptr %p3828, align 8, !alias.scope !3, !noalias !4
  %v3829 = load i64, ptr %slot59, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i64 1, ptr %p3830, align 8, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot59, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i64, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3833, ptr %slot550, align 8
  %v3834 = load i64, ptr %slot58, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  %ld3836 = load i64, ptr %p3835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3836, ptr %slot551, align 8
  %v3837 = load i64, ptr %slot551, align 8
  %v3838 = load i64, ptr %slot550, align 8
  %ovpair3840 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3837, i64 %v3838)
  %op3839 = extractvalue { i64, i1 } %ovpair3840, 0
  %ov3841 = extractvalue { i64, i1 } %ovpair3840, 1
  store i64 %op3839, ptr %slot552, align 8
  %cv3842 = zext i1 %ov3841 to i64
  store i64 %cv3842, ptr %slot553, align 8
  %v3843 = load i64, ptr %slot553, align 8
  %cond3844 = icmp ne i64 %v3843, 0
  br i1 %cond3844, label %bb_overflow785, label %bb_checked785
bb_overflow785:
  %v3845 = load i64, ptr %slot1, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  %v3847 = load i64, ptr %slot551, align 8
  %v3848 = load i64, ptr %slot550, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3846, i64 0, i64 %v3847, i64 %v3848, i64 64) nomerge, !dbg !162
  unreachable
bb_checked785:
  %v3849 = load i64, ptr %slot552, align 8
  %v3850 = load i64, ptr %slot58, align 8
  %p3851 = inttoptr i64 %v3850 to ptr
  store i64 %v3849, ptr %p3851, align 8, !alias.scope !3, !noalias !4
  %v3852 = load i64, ptr %slot58, align 8
  %p3853 = inttoptr i64 %v3852 to ptr
  %ld3854 = load i64, ptr %p3853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3854, ptr %slot554, align 8
  %v3855 = load i64, ptr %slot554, align 8
  %v3856 = load i64, ptr %slot44, align 8
  %p3857 = inttoptr i64 %v3856 to ptr
  store i64 %v3855, ptr %p3857, align 8, !alias.scope !3, !noalias !4
  br label %bb_i45
bb_i82:
  %v3858 = load i64, ptr %slot42, align 8
  %v3859 = load i64, ptr %slot58, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i64 %v3858, ptr %p3860, align 8, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot58, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot555, align 8
  %v3864 = load i64, ptr %slot555, align 8
  %op3865 = add i64 %v3864, 56
  store i64 %op3865, ptr %slot556, align 8
  %v3866 = load i64, ptr %slot556, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  %ld3868 = load i64, ptr %p3867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3868, ptr %slot557, align 8
  %v3869 = load i64, ptr %slot557, align 8
  %v3870 = load i64, ptr %slot58, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  store i64 %v3869, ptr %p3871, align 8, !alias.scope !3, !noalias !4
  %v3872 = load i64, ptr %slot58, align 8
  %p3873 = inttoptr i64 %v3872 to ptr
  %ld3874 = load i64, ptr %p3873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3874, ptr %slot558, align 8
  %v3875 = load i64, ptr %slot558, align 8
  %v3876 = load i64, ptr %slot29, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  store i64 %v3875, ptr %p3877, align 8, !alias.scope !3, !noalias !4
  %v3878 = load i64, ptr %slot29, align 8
  store i64 %v3878, ptr %slot559, align 8
  %v3879 = load i64, ptr %slot30, align 8
  store i64 %v3879, ptr %slot560, align 8
  %v3880 = load i64, ptr %slot559, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  %ld3882 = load i64, ptr %p3881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3882, ptr %slot561, align 8
  %v3883 = load i64, ptr %slot561, align 8
  %cmp3884 = icmp ne i64 %v3883, 0
  %cv3885 = zext i1 %cmp3884 to i32
  store i32 %cv3885, ptr %slot562, align 8
  %v3886 = load i32, ptr %slot562, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcgnn795, label %bb_rcgstore795
bb_rcgnn795:
  %v3889 = load i64, ptr %slot561, align 8
  %op3890 = sub i64 %v3889, 16
  store i64 %op3890, ptr %slot563, align 8
  %v3891 = load i64, ptr %slot561, align 8
  %p3892 = inttoptr i64 %v3891 to ptr
  %rgep3893 = getelementptr i8, ptr %p3892, i64 -16
  %ld3894 = load i64, ptr %rgep3893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3894, ptr %slot564, align 8
  %v3895 = load i64, ptr %slot564, align 8
  %op3896 = and i64 %v3895, 4611686018427387906
  store i64 %op3896, ptr %slot565, align 8
  %v3897 = load i64, ptr %slot565, align 8
  %cmp3898 = icmp ne i64 %v3897, 0
  %cv3899 = zext i1 %cmp3898 to i32
  store i32 %cv3899, ptr %slot566, align 8
  %v3900 = load i32, ptr %slot566, align 8
  %cv3901 = zext i32 %v3900 to i64
  %cond3902 = icmp ne i64 %cv3901, 0
  br i1 %cond3902, label %bb_rcgstore795, label %bb_rcginc795
bb_rcginc795:
  %v3903 = load i64, ptr %slot561, align 8
  %op3904 = sub i64 %v3903, 24
  store i64 %op3904, ptr %slot567, align 8
  %v3905 = load i64, ptr %slot561, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %rgep3907 = getelementptr i8, ptr %p3906, i64 -24
  %ld3908 = load i64, ptr %rgep3907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3908, ptr %slot568, align 8
  %v3909 = load i64, ptr %slot568, align 8
  %op3910 = add i64 %v3909, 1
  store i64 %op3910, ptr %slot569, align 8
  %v3911 = load i64, ptr %slot569, align 8
  %cmp3912 = icmp eq i64 %v3911, 0
  %cv3913 = zext i1 %cmp3912 to i32
  store i32 %cv3913, ptr %slot570, align 8
  %v3914 = load i32, ptr %slot570, align 8
  %cv3915 = zext i32 %v3914 to i64
  %cond3916 = icmp ne i64 %cv3915, 0
  br i1 %cond3916, label %bb_rcglimit795, label %bb_rcgcapacity795
bb_rcglimit795:
  %v3917 = load i64, ptr %slot1, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  %call3919 = call i32 @myl_qbe_rc_status(ptr %p3918, i32 2) nomerge, !dbg !164
  store i32 %call3919, ptr %slot571, align 8
  br label %bb_failure
bb_rcgcapacity795:
  %v3920 = load i64, ptr %slot569, align 8
  %v3921 = load i64, ptr %slot561, align 8
  %p3922 = inttoptr i64 %v3921 to ptr
  %rgep3923 = getelementptr i8, ptr %p3922, i64 -24
  store i64 %v3920, ptr %rgep3923, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore795
bb_rcgstore795:
  %v3924 = load i64, ptr %slot561, align 8
  %v3925 = load i64, ptr %slot560, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  store i64 %v3924, ptr %p3926, align 8, !alias.scope !3, !noalias !4
  %v3927 = load i64, ptr %slot25, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  store i32 2, ptr %p3928, align 4, !alias.scope !3, !noalias !4
  %v3929 = load i64, ptr %slot25, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i32 16, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  %v3931 = load i64, ptr %slot24, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  store i32 1, ptr %p3932, align 4, !alias.scope !3, !noalias !4
  %v3933 = load i64, ptr %slot20, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %ld3935 = load i32, ptr %p3934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3935, ptr %slot572, align 8
  %v3936 = load i32, ptr %slot572, align 8
  %cv3937 = zext i32 %v3936 to i64
  %cond3938 = icmp ne i64 %cv3937, 0
  br i1 %cond3938, label %bb_rcslotdrop811, label %bb_rcslotdone811
bb_rcslotdrop811:
  %v3939 = load i64, ptr %slot20, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i32 0, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  %v3941 = load i64, ptr %slot27, align 8
  store i64 %v3941, ptr %slot573, align 8
  %v3942 = load i64, ptr %slot21, align 8
  %p3943 = inttoptr i64 %v3942 to ptr
  %ld3944 = load i32, ptr %p3943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3944, ptr %slot574, align 8
  %v3945 = load i32, ptr %slot574, align 8
  %op3946 = and i32 %v3945, 28
  store i32 %op3946, ptr %slot575, align 8
  %v3947 = load i32, ptr %slot575, align 8
  %cv3948 = zext i32 %v3947 to i64
  %cond3949 = icmp ne i64 %cv3948, 0
  br i1 %cond3949, label %bb_rcslotrole811, label %bb_rcslotowner811
bb_rcslotrole811:
  %v3950 = load i64, ptr %slot71, align 8
  store i64 %v3950, ptr %slot576, align 8
  %v3951 = load i64, ptr %slot576, align 8
  %v3952 = load i64, ptr %slot573, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v3951, i64 %v3952) nomerge, !dbg !164
  br label %bb_rcslotdone811
bb_rcslotowner811:
  %v3953 = load i64, ptr %slot71, align 8
  store i64 %v3953, ptr %slot577, align 8
  %v3954 = load i64, ptr %slot577, align 8
  %v3955 = load i64, ptr %slot573, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v3954, i64 %v3955) nomerge, !dbg !164
  br label %bb_rcslotdone811
bb_rcslotdone811:
  %v3956 = load i64, ptr %slot27, align 8
  store i64 %v3956, ptr %slot578, align 8
  %v3957 = load i64, ptr %slot30, align 8
  store i64 %v3957, ptr %slot579, align 8
  %v3958 = load i64, ptr %slot579, align 8
  %v3959 = load i64, ptr %slot578, align 8
  %p3960 = inttoptr i64 %v3958 to ptr
  %p3961 = inttoptr i64 %v3959 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3961, ptr %p3960, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3962 = load i64, ptr %slot21, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  store i32 2, ptr %p3963, align 4, !alias.scope !3, !noalias !4
  %v3964 = load i64, ptr %slot25, align 8
  %p3965 = inttoptr i64 %v3964 to ptr
  %ld3966 = load i32, ptr %p3965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3966, ptr %slot580, align 8
  %v3967 = load i32, ptr %slot580, align 8
  %v3968 = load i64, ptr %slot21, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i32 %v3967, ptr %p3969, align 4, !alias.scope !3, !noalias !4
  %v3970 = load i64, ptr %slot24, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i32 0, ptr %p3971, align 4, !alias.scope !3, !noalias !4
  %v3972 = load i64, ptr %slot20, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  store i32 1, ptr %p3973, align 4, !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot578, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  %ld3976 = load i64, ptr %p3975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3976, ptr %slot581, align 8
  %v3977 = load i64, ptr %slot581, align 8
  %v3978 = load i64, ptr %slot58, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  store i64 %v3977, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  %v3980 = load i64, ptr %slot58, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  %ld3982 = load i64, ptr %p3981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3982, ptr %slot582, align 8
  %v3983 = load i64, ptr %slot30, align 8
  store i64 %v3983, ptr %slot583, align 8
  %v3984 = load i64, ptr %slot582, align 8
  %cmp3985 = icmp ne i64 %v3984, 0
  %cv3986 = zext i1 %cmp3985 to i32
  store i32 %cv3986, ptr %slot584, align 8
  %v3987 = load i32, ptr %slot584, align 8
  %cv3988 = zext i32 %v3987 to i64
  %cond3989 = icmp ne i64 %cv3988, 0
  br i1 %cond3989, label %bb_rcgnn831, label %bb_rcgstore831
bb_rcgnn831:
  %v3990 = load i64, ptr %slot582, align 8
  %op3991 = sub i64 %v3990, 16
  store i64 %op3991, ptr %slot585, align 8
  %v3992 = load i64, ptr %slot582, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  %rgep3994 = getelementptr i8, ptr %p3993, i64 -16
  %ld3995 = load i64, ptr %rgep3994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3995, ptr %slot586, align 8
  %v3996 = load i64, ptr %slot586, align 8
  %op3997 = and i64 %v3996, 4611686018427387906
  store i64 %op3997, ptr %slot587, align 8
  %v3998 = load i64, ptr %slot587, align 8
  %cmp3999 = icmp ne i64 %v3998, 0
  %cv4000 = zext i1 %cmp3999 to i32
  store i32 %cv4000, ptr %slot588, align 8
  %v4001 = load i32, ptr %slot588, align 8
  %cv4002 = zext i32 %v4001 to i64
  %cond4003 = icmp ne i64 %cv4002, 0
  br i1 %cond4003, label %bb_rcgstore831, label %bb_rcginc831
bb_rcginc831:
  %v4004 = load i64, ptr %slot582, align 8
  %op4005 = sub i64 %v4004, 24
  store i64 %op4005, ptr %slot589, align 8
  %v4006 = load i64, ptr %slot582, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %rgep4008 = getelementptr i8, ptr %p4007, i64 -24
  %ld4009 = load i64, ptr %rgep4008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4009, ptr %slot590, align 8
  %v4010 = load i64, ptr %slot590, align 8
  %op4011 = add i64 %v4010, 1
  store i64 %op4011, ptr %slot591, align 8
  %v4012 = load i64, ptr %slot591, align 8
  %cmp4013 = icmp eq i64 %v4012, 0
  %cv4014 = zext i1 %cmp4013 to i32
  store i32 %cv4014, ptr %slot592, align 8
  %v4015 = load i32, ptr %slot592, align 8
  %cv4016 = zext i32 %v4015 to i64
  %cond4017 = icmp ne i64 %cv4016, 0
  br i1 %cond4017, label %bb_rcglimit831, label %bb_rcgcapacity831
bb_rcglimit831:
  %v4018 = load i64, ptr %slot1, align 8
  %p4019 = inttoptr i64 %v4018 to ptr
  %call4020 = call i32 @myl_qbe_rc_status(ptr %p4019, i32 2) nomerge, !dbg !166
  store i32 %call4020, ptr %slot593, align 8
  br label %bb_failure
bb_rcgcapacity831:
  %v4021 = load i64, ptr %slot591, align 8
  %v4022 = load i64, ptr %slot582, align 8
  %p4023 = inttoptr i64 %v4022 to ptr
  %rgep4024 = getelementptr i8, ptr %p4023, i64 -24
  store i64 %v4021, ptr %rgep4024, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore831
bb_rcgstore831:
  %v4025 = load i64, ptr %slot582, align 8
  %v4026 = load i64, ptr %slot583, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  store i64 %v4025, ptr %p4027, align 8, !alias.scope !3, !noalias !4
  %v4028 = load i64, ptr %slot25, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  store i32 2, ptr %p4029, align 4, !alias.scope !3, !noalias !4
  %v4030 = load i64, ptr %slot25, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  store i32 8, ptr %p4031, align 4, !alias.scope !3, !noalias !4
  %v4032 = load i64, ptr %slot24, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  store i32 1, ptr %p4033, align 4, !alias.scope !3, !noalias !4
  %v4034 = load i64, ptr %slot20, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  %ld4036 = load i32, ptr %p4035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4036, ptr %slot594, align 8
  %v4037 = load i32, ptr %slot594, align 8
  %cv4038 = zext i32 %v4037 to i64
  %cond4039 = icmp ne i64 %cv4038, 0
  br i1 %cond4039, label %bb_rcslotdrop847, label %bb_rcslotdone847
bb_rcslotdrop847:
  %v4040 = load i64, ptr %slot20, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  store i32 0, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  %v4042 = load i64, ptr %slot27, align 8
  store i64 %v4042, ptr %slot595, align 8
  %v4043 = load i64, ptr %slot21, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  %ld4045 = load i32, ptr %p4044, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4045, ptr %slot596, align 8
  %v4046 = load i32, ptr %slot596, align 8
  %op4047 = and i32 %v4046, 28
  store i32 %op4047, ptr %slot597, align 8
  %v4048 = load i32, ptr %slot597, align 8
  %cv4049 = zext i32 %v4048 to i64
  %cond4050 = icmp ne i64 %cv4049, 0
  br i1 %cond4050, label %bb_rcslotrole847, label %bb_rcslotowner847
bb_rcslotrole847:
  %v4051 = load i64, ptr %slot71, align 8
  store i64 %v4051, ptr %slot598, align 8
  %v4052 = load i64, ptr %slot595, align 8
  %p4053 = inttoptr i64 %v4052 to ptr
  %ld4054 = load i64, ptr %p4053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4054, ptr %slot599, align 8
  %v4055 = load i64, ptr %slot599, align 8
  %cmp4056 = icmp ne i64 %v4055, 0
  %cv4057 = zext i1 %cmp4056 to i32
  store i32 %cv4057, ptr %slot600, align 8
  %v4058 = load i32, ptr %slot600, align 8
  %cv4059 = zext i32 %v4058 to i64
  %cond4060 = icmp ne i64 %cv4059, 0
  br i1 %cond4060, label %bb_rcgnn863, label %bb_rcgdone863
bb_rcgnn863:
  %v4061 = load i64, ptr %slot599, align 8
  %op4062 = sub i64 %v4061, 16
  store i64 %op4062, ptr %slot601, align 8
  %v4063 = load i64, ptr %slot599, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  %rgep4065 = getelementptr i8, ptr %p4064, i64 -16
  %ld4066 = load i64, ptr %rgep4065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4066, ptr %slot602, align 8
  %v4067 = load i64, ptr %slot602, align 8
  %op4068 = and i64 %v4067, 4611686018427387906
  store i64 %op4068, ptr %slot603, align 8
  %v4069 = load i64, ptr %slot603, align 8
  %cmp4070 = icmp ne i64 %v4069, 0
  %cv4071 = zext i1 %cmp4070 to i32
  store i32 %cv4071, ptr %slot604, align 8
  %v4072 = load i32, ptr %slot604, align 8
  %cv4073 = zext i32 %v4072 to i64
  %cond4074 = icmp ne i64 %cv4073, 0
  br i1 %cond4074, label %bb_rcgclear863, label %bb_rcgcounted863
bb_rcgcounted863:
  %v4075 = load i64, ptr %slot599, align 8
  %op4076 = sub i64 %v4075, 24
  store i64 %op4076, ptr %slot605, align 8
  %v4077 = load i64, ptr %slot599, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %rgep4079 = getelementptr i8, ptr %p4078, i64 -24
  %ld4080 = load i64, ptr %rgep4079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4080, ptr %slot606, align 8
  %v4081 = load i64, ptr %slot606, align 8
  %op4082 = sub i64 %v4081, 1
  store i64 %op4082, ptr %slot607, align 8
  %v4083 = load i64, ptr %slot607, align 8
  %cmp4084 = icmp eq i64 %v4083, 0
  %cv4085 = zext i1 %cmp4084 to i32
  store i32 %cv4085, ptr %slot608, align 8
  %v4086 = load i32, ptr %slot608, align 8
  %cv4087 = zext i32 %v4086 to i64
  %cond4088 = icmp ne i64 %cv4087, 0
  br i1 %cond4088, label %bb_rcglast863, label %bb_rcgdec863
bb_rcglast863:
  %v4089 = load i64, ptr %slot599, align 8
  %op4090 = sub i64 %v4089, 32
  store i64 %op4090, ptr %slot609, align 8
  %v4091 = load i64, ptr %slot599, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  %rgep4093 = getelementptr i8, ptr %p4092, i64 -32
  %ld4094 = load i64, ptr %rgep4093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4094, ptr %slot610, align 8
  %v4095 = load i64, ptr %slot610, align 8
  %cmp4096 = icmp ne i64 %v4095, 0
  %cv4097 = zext i1 %cmp4096 to i32
  store i32 %cv4097, ptr %slot611, align 8
  %v4098 = load i32, ptr %slot611, align 8
  %cv4099 = zext i32 %v4098 to i64
  %cond4100 = icmp ne i64 %cv4099, 0
  br i1 %cond4100, label %bb_rcgdec863, label %bb_rcgslow863
bb_rcgslow863:
  %v4101 = load i64, ptr %slot598, align 8
  %v4102 = load i64, ptr %slot595, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4101, i64 %v4102) nomerge, !dbg !166
  br label %bb_rcgdone863
bb_rcgdec863:
  %v4103 = load i64, ptr %slot607, align 8
  %v4104 = load i64, ptr %slot599, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  %rgep4106 = getelementptr i8, ptr %p4105, i64 -24
  store i64 %v4103, ptr %rgep4106, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear863
bb_rcgclear863:
  %v4107 = load i64, ptr %slot595, align 8
  %p4108 = inttoptr i64 %v4107 to ptr
  store i64 0, ptr %p4108, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone863
bb_rcgdone863:
  br label %bb_rcslotdone847
bb_rcslotowner847:
  %v4109 = load i64, ptr %slot71, align 8
  store i64 %v4109, ptr %slot612, align 8
  %v4110 = load i64, ptr %slot595, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  %ld4112 = load i64, ptr %p4111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4112, ptr %slot613, align 8
  %v4113 = load i64, ptr %slot613, align 8
  %cmp4114 = icmp ne i64 %v4113, 0
  %cv4115 = zext i1 %cmp4114 to i32
  store i32 %cv4115, ptr %slot614, align 8
  %v4116 = load i32, ptr %slot614, align 8
  %cv4117 = zext i32 %v4116 to i64
  %cond4118 = icmp ne i64 %cv4117, 0
  br i1 %cond4118, label %bb_rcgnn878, label %bb_rcgdone878
bb_rcgnn878:
  %v4119 = load i64, ptr %slot613, align 8
  %op4120 = sub i64 %v4119, 16
  store i64 %op4120, ptr %slot615, align 8
  %v4121 = load i64, ptr %slot613, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  %rgep4123 = getelementptr i8, ptr %p4122, i64 -16
  %ld4124 = load i64, ptr %rgep4123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4124, ptr %slot616, align 8
  %v4125 = load i64, ptr %slot616, align 8
  %op4126 = and i64 %v4125, 4611686018427387906
  store i64 %op4126, ptr %slot617, align 8
  %v4127 = load i64, ptr %slot617, align 8
  %cmp4128 = icmp ne i64 %v4127, 0
  %cv4129 = zext i1 %cmp4128 to i32
  store i32 %cv4129, ptr %slot618, align 8
  %v4130 = load i32, ptr %slot618, align 8
  %cv4131 = zext i32 %v4130 to i64
  %cond4132 = icmp ne i64 %cv4131, 0
  br i1 %cond4132, label %bb_rcgclear878, label %bb_rcgcounted878
bb_rcgcounted878:
  %v4133 = load i64, ptr %slot613, align 8
  %op4134 = sub i64 %v4133, 32
  store i64 %op4134, ptr %slot619, align 8
  %v4135 = load i64, ptr %slot613, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %rgep4137 = getelementptr i8, ptr %p4136, i64 -32
  %ld4138 = load i64, ptr %rgep4137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4138, ptr %slot620, align 8
  %v4139 = load i64, ptr %slot620, align 8
  %op4140 = sub i64 %v4139, 1
  store i64 %op4140, ptr %slot621, align 8
  %v4141 = load i64, ptr %slot621, align 8
  %cmp4142 = icmp eq i64 %v4141, 0
  %cv4143 = zext i1 %cmp4142 to i32
  store i32 %cv4143, ptr %slot622, align 8
  %v4144 = load i32, ptr %slot622, align 8
  %cv4145 = zext i32 %v4144 to i64
  %cond4146 = icmp ne i64 %cv4145, 0
  br i1 %cond4146, label %bb_rcglast878, label %bb_rcgdec878
bb_rcglast878:
  %v4147 = load i64, ptr %slot613, align 8
  %op4148 = sub i64 %v4147, 24
  store i64 %op4148, ptr %slot623, align 8
  %v4149 = load i64, ptr %slot613, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  %rgep4151 = getelementptr i8, ptr %p4150, i64 -24
  %ld4152 = load i64, ptr %rgep4151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4152, ptr %slot624, align 8
  %v4153 = load i64, ptr %slot624, align 8
  %cmp4154 = icmp ne i64 %v4153, 0
  %cv4155 = zext i1 %cmp4154 to i32
  store i32 %cv4155, ptr %slot625, align 8
  %v4156 = load i32, ptr %slot625, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcgdec878, label %bb_rcgslow878
bb_rcgslow878:
  %v4159 = load i64, ptr %slot612, align 8
  %v4160 = load i64, ptr %slot595, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4159, i64 %v4160) nomerge, !dbg !166
  br label %bb_rcgdone878
bb_rcgdec878:
  %v4161 = load i64, ptr %slot621, align 8
  %v4162 = load i64, ptr %slot613, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  %rgep4164 = getelementptr i8, ptr %p4163, i64 -32
  store i64 %v4161, ptr %rgep4164, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear878
bb_rcgclear878:
  %v4165 = load i64, ptr %slot595, align 8
  %p4166 = inttoptr i64 %v4165 to ptr
  store i64 0, ptr %p4166, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone878
bb_rcgdone878:
  br label %bb_rcslotdone847
bb_rcslotdone847:
  %v4167 = load i64, ptr %slot27, align 8
  store i64 %v4167, ptr %slot626, align 8
  %v4168 = load i64, ptr %slot30, align 8
  store i64 %v4168, ptr %slot627, align 8
  %v4169 = load i64, ptr %slot627, align 8
  %p4170 = inttoptr i64 %v4169 to ptr
  %ld4171 = load i64, ptr %p4170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4171, ptr %slot628, align 8
  %v4172 = load i64, ptr %slot628, align 8
  %v4173 = load i64, ptr %slot626, align 8
  %p4174 = inttoptr i64 %v4173 to ptr
  store i64 %v4172, ptr %p4174, align 8, !alias.scope !3, !noalias !4
  %v4175 = load i64, ptr %slot21, align 8
  %p4176 = inttoptr i64 %v4175 to ptr
  store i32 2, ptr %p4176, align 4, !alias.scope !3, !noalias !4
  %v4177 = load i64, ptr %slot21, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  store i32 8, ptr %p4178, align 4, !alias.scope !3, !noalias !4
  %v4179 = load i64, ptr %slot20, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  store i32 1, ptr %p4180, align 4, !alias.scope !3, !noalias !4
  %v4181 = load i64, ptr %slot24, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  store i32 0, ptr %p4182, align 4, !alias.scope !3, !noalias !4
  %v4183 = load i64, ptr %slot628, align 8
  %v4184 = load i64, ptr %slot58, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  store i64 %v4183, ptr %p4185, align 8, !alias.scope !3, !noalias !4
  %v4186 = load i64, ptr %slot30, align 8
  store i64 %v4186, ptr %slot629, align 8
  %v4187 = load i64, ptr %slot58, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %ld4189 = load i64, ptr %p4188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4189, ptr %slot630, align 8
  %v4190 = load i64, ptr %slot630, align 8
  %v4191 = load i64, ptr %slot629, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  store i64 %v4190, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  %v4193 = load i64, ptr %slot25, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  store i32 2, ptr %p4194, align 4, !alias.scope !3, !noalias !4
  %v4195 = load i64, ptr %slot25, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  store i32 8, ptr %p4196, align 4, !alias.scope !3, !noalias !4
  %v4197 = load i64, ptr %slot24, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  store i32 1, ptr %p4198, align 4, !alias.scope !3, !noalias !4
  %v4199 = load i64, ptr %slot20, align 8
  %p4200 = inttoptr i64 %v4199 to ptr
  store i32 0, ptr %p4200, align 4, !alias.scope !3, !noalias !4
  %v4201 = load i64, ptr %slot14, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  %ld4203 = load i32, ptr %p4202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4203, ptr %slot631, align 8
  %v4204 = load i32, ptr %slot631, align 8
  %cv4205 = zext i32 %v4204 to i64
  %cond4206 = icmp ne i64 %cv4205, 0
  br i1 %cond4206, label %bb_rcslotdrop897, label %bb_rcslotdone897
bb_rcslotdrop897:
  %v4207 = load i64, ptr %slot14, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  store i32 0, ptr %p4208, align 4, !alias.scope !3, !noalias !4
  %v4209 = load i64, ptr %slot47, align 8
  store i64 %v4209, ptr %slot632, align 8
  %v4210 = load i64, ptr %slot15, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  %ld4212 = load i32, ptr %p4211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4212, ptr %slot633, align 8
  %v4213 = load i32, ptr %slot633, align 8
  %op4214 = and i32 %v4213, 28
  store i32 %op4214, ptr %slot634, align 8
  %v4215 = load i32, ptr %slot634, align 8
  %cv4216 = zext i32 %v4215 to i64
  %cond4217 = icmp ne i64 %cv4216, 0
  br i1 %cond4217, label %bb_rcslotrole897, label %bb_rcslotowner897
bb_rcslotrole897:
  %v4218 = load i64, ptr %slot71, align 8
  store i64 %v4218, ptr %slot635, align 8
  %v4219 = load i64, ptr %slot632, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  %ld4221 = load i64, ptr %p4220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4221, ptr %slot636, align 8
  %v4222 = load i64, ptr %slot636, align 8
  %cmp4223 = icmp ne i64 %v4222, 0
  %cv4224 = zext i1 %cmp4223 to i32
  store i32 %cv4224, ptr %slot637, align 8
  %v4225 = load i32, ptr %slot637, align 8
  %cv4226 = zext i32 %v4225 to i64
  %cond4227 = icmp ne i64 %cv4226, 0
  br i1 %cond4227, label %bb_rcgnn913, label %bb_rcgdone913
bb_rcgnn913:
  %v4228 = load i64, ptr %slot636, align 8
  %op4229 = sub i64 %v4228, 16
  store i64 %op4229, ptr %slot638, align 8
  %v4230 = load i64, ptr %slot636, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %rgep4232 = getelementptr i8, ptr %p4231, i64 -16
  %ld4233 = load i64, ptr %rgep4232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4233, ptr %slot639, align 8
  %v4234 = load i64, ptr %slot639, align 8
  %op4235 = and i64 %v4234, 4611686018427387906
  store i64 %op4235, ptr %slot640, align 8
  %v4236 = load i64, ptr %slot640, align 8
  %cmp4237 = icmp ne i64 %v4236, 0
  %cv4238 = zext i1 %cmp4237 to i32
  store i32 %cv4238, ptr %slot641, align 8
  %v4239 = load i32, ptr %slot641, align 8
  %cv4240 = zext i32 %v4239 to i64
  %cond4241 = icmp ne i64 %cv4240, 0
  br i1 %cond4241, label %bb_rcgclear913, label %bb_rcgcounted913
bb_rcgcounted913:
  %v4242 = load i64, ptr %slot636, align 8
  %op4243 = sub i64 %v4242, 24
  store i64 %op4243, ptr %slot642, align 8
  %v4244 = load i64, ptr %slot636, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %rgep4246 = getelementptr i8, ptr %p4245, i64 -24
  %ld4247 = load i64, ptr %rgep4246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4247, ptr %slot643, align 8
  %v4248 = load i64, ptr %slot643, align 8
  %op4249 = sub i64 %v4248, 1
  store i64 %op4249, ptr %slot644, align 8
  %v4250 = load i64, ptr %slot644, align 8
  %cmp4251 = icmp eq i64 %v4250, 0
  %cv4252 = zext i1 %cmp4251 to i32
  store i32 %cv4252, ptr %slot645, align 8
  %v4253 = load i32, ptr %slot645, align 8
  %cv4254 = zext i32 %v4253 to i64
  %cond4255 = icmp ne i64 %cv4254, 0
  br i1 %cond4255, label %bb_rcglast913, label %bb_rcgdec913
bb_rcglast913:
  %v4256 = load i64, ptr %slot636, align 8
  %op4257 = sub i64 %v4256, 32
  store i64 %op4257, ptr %slot646, align 8
  %v4258 = load i64, ptr %slot636, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  %rgep4260 = getelementptr i8, ptr %p4259, i64 -32
  %ld4261 = load i64, ptr %rgep4260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4261, ptr %slot647, align 8
  %v4262 = load i64, ptr %slot647, align 8
  %cmp4263 = icmp ne i64 %v4262, 0
  %cv4264 = zext i1 %cmp4263 to i32
  store i32 %cv4264, ptr %slot648, align 8
  %v4265 = load i32, ptr %slot648, align 8
  %cv4266 = zext i32 %v4265 to i64
  %cond4267 = icmp ne i64 %cv4266, 0
  br i1 %cond4267, label %bb_rcgdec913, label %bb_rcgslow913
bb_rcgslow913:
  %v4268 = load i64, ptr %slot635, align 8
  %v4269 = load i64, ptr %slot632, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4268, i64 %v4269) nomerge, !dbg !166
  br label %bb_rcgdone913
bb_rcgdec913:
  %v4270 = load i64, ptr %slot644, align 8
  %v4271 = load i64, ptr %slot636, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  %rgep4273 = getelementptr i8, ptr %p4272, i64 -24
  store i64 %v4270, ptr %rgep4273, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear913
bb_rcgclear913:
  %v4274 = load i64, ptr %slot632, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  store i64 0, ptr %p4275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone913
bb_rcgdone913:
  br label %bb_rcslotdone897
bb_rcslotowner897:
  %v4276 = load i64, ptr %slot71, align 8
  store i64 %v4276, ptr %slot649, align 8
  %v4277 = load i64, ptr %slot632, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %ld4279 = load i64, ptr %p4278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4279, ptr %slot650, align 8
  %v4280 = load i64, ptr %slot650, align 8
  %cmp4281 = icmp ne i64 %v4280, 0
  %cv4282 = zext i1 %cmp4281 to i32
  store i32 %cv4282, ptr %slot651, align 8
  %v4283 = load i32, ptr %slot651, align 8
  %cv4284 = zext i32 %v4283 to i64
  %cond4285 = icmp ne i64 %cv4284, 0
  br i1 %cond4285, label %bb_rcgnn928, label %bb_rcgdone928
bb_rcgnn928:
  %v4286 = load i64, ptr %slot650, align 8
  %op4287 = sub i64 %v4286, 16
  store i64 %op4287, ptr %slot652, align 8
  %v4288 = load i64, ptr %slot650, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  %rgep4290 = getelementptr i8, ptr %p4289, i64 -16
  %ld4291 = load i64, ptr %rgep4290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4291, ptr %slot653, align 8
  %v4292 = load i64, ptr %slot653, align 8
  %op4293 = and i64 %v4292, 4611686018427387906
  store i64 %op4293, ptr %slot654, align 8
  %v4294 = load i64, ptr %slot654, align 8
  %cmp4295 = icmp ne i64 %v4294, 0
  %cv4296 = zext i1 %cmp4295 to i32
  store i32 %cv4296, ptr %slot655, align 8
  %v4297 = load i32, ptr %slot655, align 8
  %cv4298 = zext i32 %v4297 to i64
  %cond4299 = icmp ne i64 %cv4298, 0
  br i1 %cond4299, label %bb_rcgclear928, label %bb_rcgcounted928
bb_rcgcounted928:
  %v4300 = load i64, ptr %slot650, align 8
  %op4301 = sub i64 %v4300, 32
  store i64 %op4301, ptr %slot656, align 8
  %v4302 = load i64, ptr %slot650, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  %rgep4304 = getelementptr i8, ptr %p4303, i64 -32
  %ld4305 = load i64, ptr %rgep4304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4305, ptr %slot657, align 8
  %v4306 = load i64, ptr %slot657, align 8
  %op4307 = sub i64 %v4306, 1
  store i64 %op4307, ptr %slot658, align 8
  %v4308 = load i64, ptr %slot658, align 8
  %cmp4309 = icmp eq i64 %v4308, 0
  %cv4310 = zext i1 %cmp4309 to i32
  store i32 %cv4310, ptr %slot659, align 8
  %v4311 = load i32, ptr %slot659, align 8
  %cv4312 = zext i32 %v4311 to i64
  %cond4313 = icmp ne i64 %cv4312, 0
  br i1 %cond4313, label %bb_rcglast928, label %bb_rcgdec928
bb_rcglast928:
  %v4314 = load i64, ptr %slot650, align 8
  %op4315 = sub i64 %v4314, 24
  store i64 %op4315, ptr %slot660, align 8
  %v4316 = load i64, ptr %slot650, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  %rgep4318 = getelementptr i8, ptr %p4317, i64 -24
  %ld4319 = load i64, ptr %rgep4318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4319, ptr %slot661, align 8
  %v4320 = load i64, ptr %slot661, align 8
  %cmp4321 = icmp ne i64 %v4320, 0
  %cv4322 = zext i1 %cmp4321 to i32
  store i32 %cv4322, ptr %slot662, align 8
  %v4323 = load i32, ptr %slot662, align 8
  %cv4324 = zext i32 %v4323 to i64
  %cond4325 = icmp ne i64 %cv4324, 0
  br i1 %cond4325, label %bb_rcgdec928, label %bb_rcgslow928
bb_rcgslow928:
  %v4326 = load i64, ptr %slot649, align 8
  %v4327 = load i64, ptr %slot632, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4326, i64 %v4327) nomerge, !dbg !166
  br label %bb_rcgdone928
bb_rcgdec928:
  %v4328 = load i64, ptr %slot658, align 8
  %v4329 = load i64, ptr %slot650, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  %rgep4331 = getelementptr i8, ptr %p4330, i64 -32
  store i64 %v4328, ptr %rgep4331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear928
bb_rcgclear928:
  %v4332 = load i64, ptr %slot632, align 8
  %p4333 = inttoptr i64 %v4332 to ptr
  store i64 0, ptr %p4333, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone928
bb_rcgdone928:
  br label %bb_rcslotdone897
bb_rcslotdone897:
  %v4334 = load i64, ptr %slot47, align 8
  store i64 %v4334, ptr %slot663, align 8
  %v4335 = load i64, ptr %slot629, align 8
  %p4336 = inttoptr i64 %v4335 to ptr
  %ld4337 = load i64, ptr %p4336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4337, ptr %slot664, align 8
  %v4338 = load i64, ptr %slot664, align 8
  %v4339 = load i64, ptr %slot663, align 8
  %p4340 = inttoptr i64 %v4339 to ptr
  store i64 %v4338, ptr %p4340, align 8, !alias.scope !3, !noalias !4
  %v4341 = load i64, ptr %slot15, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  store i32 2, ptr %p4342, align 4, !alias.scope !3, !noalias !4
  %v4343 = load i64, ptr %slot15, align 8
  %p4344 = inttoptr i64 %v4343 to ptr
  store i32 8, ptr %p4344, align 4, !alias.scope !3, !noalias !4
  %v4345 = load i64, ptr %slot14, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  store i32 1, ptr %p4346, align 4, !alias.scope !3, !noalias !4
  %v4347 = load i64, ptr %slot24, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  store i32 0, ptr %p4348, align 4, !alias.scope !3, !noalias !4
  %v4349 = load i64, ptr %slot58, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  store i64 0, ptr %p4350, align 8, !alias.scope !3, !noalias !4
  %v4351 = load i64, ptr %slot58, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %ld4353 = load i64, ptr %p4352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4353, ptr %slot665, align 8
  %v4354 = load i64, ptr %slot665, align 8
  %v4355 = load i64, ptr %slot48, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  store i64 %v4354, ptr %p4356, align 8, !alias.scope !3, !noalias !4
  %v4357 = load i64, ptr %slot47, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  %ld4359 = load i64, ptr %p4358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4359, ptr %slot666, align 8
  %v4360 = load i64, ptr %slot666, align 8
  %op4361 = add i64 %v4360, 0
  store i64 %op4361, ptr %slot667, align 8
  %v4362 = load i64, ptr %slot667, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %ld4364 = load i64, ptr %p4363, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4364, ptr %slot668, align 8
  %v4365 = load i64, ptr %slot668, align 8
  %v4366 = load i64, ptr %slot58, align 8
  %p4367 = inttoptr i64 %v4366 to ptr
  store i64 %v4365, ptr %p4367, align 8, !alias.scope !3, !noalias !4
  %v4368 = load i64, ptr %slot58, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  %ld4370 = load i64, ptr %p4369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4370, ptr %slot669, align 8
  %v4371 = load i64, ptr %slot669, align 8
  %cmp4372 = icmp ugt i64 %v4371, 9223372036854775807
  %cv4373 = zext i1 %cmp4372 to i64
  store i64 %cv4373, ptr %slot670, align 8
  %v4374 = load i64, ptr %slot670, align 8
  %cond4375 = icmp ne i64 %v4374, 0
  br i1 %cond4375, label %bb_cast_overflow944, label %bb_cast_ok944
bb_cast_overflow944:
  %v4376 = load i64, ptr %slot1, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %v4378 = load i64, ptr %slot669, align 8
  call void @myl_qbe_fail_cast(ptr %p4377, i64 %v4378, i64 320) nomerge, !dbg !168
  unreachable
bb_cast_ok944:
  %v4379 = load i64, ptr %slot669, align 8
  %v4380 = load i64, ptr %slot58, align 8
  %p4381 = inttoptr i64 %v4380 to ptr
  store i64 %v4379, ptr %p4381, align 8, !alias.scope !3, !noalias !4
  %v4382 = load i64, ptr %slot58, align 8
  %p4383 = inttoptr i64 %v4382 to ptr
  %ld4384 = load i64, ptr %p4383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4384, ptr %slot671, align 8
  %v4385 = load i64, ptr %slot671, align 8
  %v4386 = load i64, ptr %slot49, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  store i64 %v4385, ptr %p4387, align 8, !alias.scope !3, !noalias !4
  br label %bb_i90
bb_i90:
  %v4388 = load i64, ptr %slot48, align 8
  %p4389 = inttoptr i64 %v4388 to ptr
  %ld4390 = load i64, ptr %p4389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4390, ptr %slot672, align 8
  %v4391 = load i64, ptr %slot672, align 8
  %v4392 = load i64, ptr %slot58, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  store i64 %v4391, ptr %p4393, align 8, !alias.scope !3, !noalias !4
  %v4394 = load i64, ptr %slot49, align 8
  %p4395 = inttoptr i64 %v4394 to ptr
  %ld4396 = load i64, ptr %p4395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4396, ptr %slot673, align 8
  %v4397 = load i64, ptr %slot673, align 8
  %v4398 = load i64, ptr %slot59, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  store i64 %v4397, ptr %p4399, align 8, !alias.scope !3, !noalias !4
  %v4400 = load i64, ptr %slot59, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %ld4402 = load i64, ptr %p4401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4402, ptr %slot674, align 8
  %v4403 = load i64, ptr %slot58, align 8
  %p4404 = inttoptr i64 %v4403 to ptr
  %ld4405 = load i64, ptr %p4404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4405, ptr %slot675, align 8
  %v4406 = load i64, ptr %slot675, align 8
  %v4407 = load i64, ptr %slot674, align 8
  %cmp4408 = icmp slt i64 %v4406, %v4407
  %cv4409 = zext i1 %cmp4408 to i64
  store i64 %cv4409, ptr %slot676, align 8
  %v4410 = load i64, ptr %slot676, align 8
  %v4411 = load i64, ptr %slot58, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  store i64 %v4410, ptr %p4412, align 8, !alias.scope !3, !noalias !4
  %v4413 = load i64, ptr %slot58, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  %ld4415 = load i64, ptr %p4414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4415, ptr %slot677, align 8
  %v4416 = load i64, ptr %slot677, align 8
  %cond4417 = icmp ne i64 %v4416, 0
  br i1 %cond4417, label %bb_next952, label %bb_i112
bb_next952:
  %v4418 = load i64, ptr %slot49, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %ld4420 = load i64, ptr %p4419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4420, ptr %slot678, align 8
  %v4421 = load i64, ptr %slot678, align 8
  %v4422 = load i64, ptr %slot58, align 8
  %p4423 = inttoptr i64 %v4422 to ptr
  store i64 %v4421, ptr %p4423, align 8, !alias.scope !3, !noalias !4
  %v4424 = load i64, ptr %slot47, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %ld4426 = load i64, ptr %p4425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4426, ptr %slot679, align 8
  %v4427 = load i64, ptr %slot58, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  %ld4429 = load i64, ptr %p4428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4429, ptr %slot680, align 8
  %v4430 = load i64, ptr %slot679, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  %ld4432 = load i64, ptr %p4431, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4432, ptr %slot681, align 8
  %v4433 = load i64, ptr %slot681, align 8
  %v4434 = load i64, ptr %slot680, align 8
  %cmp4435 = icmp eq i64 %v4433, %v4434
  %cv4436 = zext i1 %cmp4435 to i64
  store i64 %cv4436, ptr %slot682, align 8
  %v4437 = load i64, ptr %slot682, align 8
  %cond4438 = icmp ne i64 %v4437, 0
  br i1 %cond4438, label %bb_success957, label %bb_failed957
bb_failed957:
  %v4439 = load i64, ptr %slot1, align 8
  %p4440 = inttoptr i64 %v4439 to ptr
  call void @myl_qbe_fail_iteration(ptr %p4440) nomerge, !dbg !170
  unreachable
bb_success957:
  %v4441 = load i64, ptr %slot58, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i64 0, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot48, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i64, ptr %p4444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4445, ptr %slot683, align 8
  %v4446 = load i64, ptr %slot683, align 8
  %v4447 = load i64, ptr %slot58, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  store i64 %v4446, ptr %p4448, align 8, !alias.scope !3, !noalias !4
  %v4449 = load i64, ptr %slot47, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  %ld4451 = load i64, ptr %p4450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4451, ptr %slot684, align 8
  %v4452 = load i64, ptr %slot58, align 8
  %p4453 = inttoptr i64 %v4452 to ptr
  %ld4454 = load i64, ptr %p4453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4454, ptr %slot685, align 8
  %v4455 = load i64, ptr %slot684, align 8
  %p4456 = inttoptr i64 %v4455 to ptr
  %ld4457 = load i64, ptr %p4456, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4457, ptr %slot686, align 8
  %v4458 = load i64, ptr %slot685, align 8
  %v4459 = load i64, ptr %slot686, align 8
  %cmp4460 = icmp ult i64 %v4458, %v4459
  %cv4461 = zext i1 %cmp4460 to i64
  store i64 %cv4461, ptr %slot687, align 8
  %v4462 = load i64, ptr %slot687, align 8
  %cond4463 = icmp ne i64 %v4462, 0
  br i1 %cond4463, label %bb_success964, label %bb_failed964
bb_failed964:
  %v4464 = load i64, ptr %slot1, align 8
  %p4465 = inttoptr i64 %v4464 to ptr
  %v4466 = load i64, ptr %slot685, align 8
  %v4467 = load i64, ptr %slot686, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4465, i64 %v4466, i64 %v4467) nomerge, !dbg !172
  unreachable
bb_success964:
  %v4468 = load i64, ptr %slot684, align 8
  %op4469 = add i64 %v4468, 32
  store i64 %op4469, ptr %slot688, align 8
  %v4470 = load i64, ptr %slot688, align 8
  %p4471 = inttoptr i64 %v4470 to ptr
  %ld4472 = load i64, ptr %p4471, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4472, ptr %slot689, align 8
  %v4473 = load i64, ptr %slot685, align 8
  %op4474 = mul i64 %v4473, 8
  store i64 %op4474, ptr %slot690, align 8
  %v4475 = load i64, ptr %slot689, align 8
  %v4476 = load i64, ptr %slot690, align 8
  %op4477 = add i64 %v4475, %v4476
  store i64 %op4477, ptr %slot691, align 8
  %v4478 = load i64, ptr %slot689, align 8
  %p4479 = inttoptr i64 %v4478 to ptr
  %v4480 = load i64, ptr %slot690, align 8
  %egep4481 = getelementptr i8, ptr %p4479, i64 %v4480
  %ld4482 = load i64, ptr %egep4481, align 8, !alias.scope !15, !noalias !16
  store i64 %ld4482, ptr %slot692, align 8
  %v4483 = load i64, ptr %slot692, align 8
  %v4484 = load i64, ptr %slot58, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  store i64 %v4483, ptr %p4485, align 8, !alias.scope !3, !noalias !4
  %v4486 = load i64, ptr %slot58, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %ld4488 = load i64, ptr %p4487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4488, ptr %slot693, align 8
  %v4489 = load i64, ptr %slot693, align 8
  %v4490 = load i64, ptr %slot50, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i64 %v4489, ptr %p4491, align 8, !alias.scope !3, !noalias !4
  %v4492 = load i64, ptr %slot34, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  %ld4494 = load i64, ptr %p4493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4494, ptr %slot694, align 8
  %v4495 = load i64, ptr %slot694, align 8
  %v4496 = load i64, ptr %slot58, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  store i64 %v4495, ptr %p4497, align 8, !alias.scope !3, !noalias !4
  %v4498 = load i64, ptr %slot50, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  %ld4500 = load i64, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4500, ptr %slot695, align 8
  %v4501 = load i64, ptr %slot695, align 8
  %v4502 = load i64, ptr %slot59, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  store i64 %v4501, ptr %p4503, align 8, !alias.scope !3, !noalias !4
  %v4504 = load i64, ptr %slot58, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  %ld4506 = load i64, ptr %p4505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4506, ptr %slot696, align 8
  %v4507 = load i64, ptr %slot59, align 8
  %p4508 = inttoptr i64 %v4507 to ptr
  %ld4509 = load i64, ptr %p4508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4509, ptr %slot697, align 8
  %v4510 = load i64, ptr %slot1, align 8
  %v4511 = load i64, ptr %slot696, align 8
  %v4512 = load i64, ptr %slot697, align 8
  %call4513 = call i64 @myl_f_cb8ba6198d12c121b91c6eca86ed4537aaff0ed5acaf8eda6f904a4b0d563a06(i64 %v4510, i64 %v4511, i64 %v4512) nomerge, !dbg !174
  store i64 %call4513, ptr %slot698, align 8
  %v4514 = load i64, ptr %slot698, align 8
  %v4515 = load i64, ptr %slot58, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  store i64 %v4514, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  %v4517 = load i64, ptr %slot20, align 8
  %p4518 = inttoptr i64 %v4517 to ptr
  %ld4519 = load i32, ptr %p4518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4519, ptr %slot699, align 8
  %v4520 = load i32, ptr %slot699, align 8
  %cv4521 = zext i32 %v4520 to i64
  %cond4522 = icmp ne i64 %cv4521, 0
  br i1 %cond4522, label %bb_rcslotdrop978, label %bb_rcslotdone978
bb_rcslotdrop978:
  %v4523 = load i64, ptr %slot20, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  store i32 0, ptr %p4524, align 4, !alias.scope !3, !noalias !4
  %v4525 = load i64, ptr %slot27, align 8
  store i64 %v4525, ptr %slot700, align 8
  %v4526 = load i64, ptr %slot21, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %ld4528 = load i32, ptr %p4527, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4528, ptr %slot701, align 8
  %v4529 = load i32, ptr %slot701, align 8
  %op4530 = and i32 %v4529, 28
  store i32 %op4530, ptr %slot702, align 8
  %v4531 = load i32, ptr %slot702, align 8
  %cv4532 = zext i32 %v4531 to i64
  %cond4533 = icmp ne i64 %cv4532, 0
  br i1 %cond4533, label %bb_rcslotrole978, label %bb_rcslotowner978
bb_rcslotrole978:
  %v4534 = load i64, ptr %slot71, align 8
  store i64 %v4534, ptr %slot703, align 8
  %v4535 = load i64, ptr %slot703, align 8
  %v4536 = load i64, ptr %slot700, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v4535, i64 %v4536) nomerge, !dbg !174
  br label %bb_rcslotdone978
bb_rcslotowner978:
  %v4537 = load i64, ptr %slot71, align 8
  store i64 %v4537, ptr %slot704, align 8
  %v4538 = load i64, ptr %slot704, align 8
  %v4539 = load i64, ptr %slot700, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v4538, i64 %v4539) nomerge, !dbg !174
  br label %bb_rcslotdone978
bb_rcslotdone978:
  %v4540 = load i64, ptr %slot49, align 8
  %p4541 = inttoptr i64 %v4540 to ptr
  %ld4542 = load i64, ptr %p4541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4542, ptr %slot705, align 8
  %v4543 = load i64, ptr %slot705, align 8
  %v4544 = load i64, ptr %slot58, align 8
  %p4545 = inttoptr i64 %v4544 to ptr
  store i64 %v4543, ptr %p4545, align 8, !alias.scope !3, !noalias !4
  %v4546 = load i64, ptr %slot47, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  %ld4548 = load i64, ptr %p4547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4548, ptr %slot706, align 8
  %v4549 = load i64, ptr %slot58, align 8
  %p4550 = inttoptr i64 %v4549 to ptr
  %ld4551 = load i64, ptr %p4550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4551, ptr %slot707, align 8
  %v4552 = load i64, ptr %slot706, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %ld4554 = load i64, ptr %p4553, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4554, ptr %slot708, align 8
  %v4555 = load i64, ptr %slot708, align 8
  %v4556 = load i64, ptr %slot707, align 8
  %cmp4557 = icmp eq i64 %v4555, %v4556
  %cv4558 = zext i1 %cmp4557 to i64
  store i64 %cv4558, ptr %slot709, align 8
  %v4559 = load i64, ptr %slot709, align 8
  %cond4560 = icmp ne i64 %v4559, 0
  br i1 %cond4560, label %bb_success990, label %bb_failed990
bb_failed990:
  %v4561 = load i64, ptr %slot1, align 8
  %p4562 = inttoptr i64 %v4561 to ptr
  call void @myl_qbe_fail_iteration(ptr %p4562) nomerge, !dbg !176
  unreachable
bb_success990:
  %v4563 = load i64, ptr %slot58, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  store i64 0, ptr %p4564, align 8, !alias.scope !3, !noalias !4
  %v4565 = load i64, ptr %slot48, align 8
  %p4566 = inttoptr i64 %v4565 to ptr
  %ld4567 = load i64, ptr %p4566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4567, ptr %slot710, align 8
  %v4568 = load i64, ptr %slot710, align 8
  %v4569 = load i64, ptr %slot58, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  store i64 %v4568, ptr %p4570, align 8, !alias.scope !3, !noalias !4
  %v4571 = load i64, ptr %slot59, align 8
  %p4572 = inttoptr i64 %v4571 to ptr
  store i64 1, ptr %p4572, align 8, !alias.scope !3, !noalias !4
  %v4573 = load i64, ptr %slot59, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  %ld4575 = load i64, ptr %p4574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4575, ptr %slot711, align 8
  %v4576 = load i64, ptr %slot58, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %ld4578 = load i64, ptr %p4577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4578, ptr %slot712, align 8
  %v4579 = load i64, ptr %slot712, align 8
  %v4580 = load i64, ptr %slot711, align 8
  %ovpair4582 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4579, i64 %v4580)
  %op4581 = extractvalue { i64, i1 } %ovpair4582, 0
  %ov4583 = extractvalue { i64, i1 } %ovpair4582, 1
  store i64 %op4581, ptr %slot713, align 8
  %cv4584 = zext i1 %ov4583 to i64
  store i64 %cv4584, ptr %slot714, align 8
  %v4585 = load i64, ptr %slot714, align 8
  %cond4586 = icmp ne i64 %v4585, 0
  br i1 %cond4586, label %bb_overflow994, label %bb_checked994
bb_overflow994:
  %v4587 = load i64, ptr %slot1, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  %v4589 = load i64, ptr %slot712, align 8
  %v4590 = load i64, ptr %slot711, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4588, i64 0, i64 %v4589, i64 %v4590, i64 64) nomerge, !dbg !178
  unreachable
bb_checked994:
  %v4591 = load i64, ptr %slot713, align 8
  %v4592 = load i64, ptr %slot58, align 8
  %p4593 = inttoptr i64 %v4592 to ptr
  store i64 %v4591, ptr %p4593, align 8, !alias.scope !3, !noalias !4
  %v4594 = load i64, ptr %slot58, align 8
  %p4595 = inttoptr i64 %v4594 to ptr
  %ld4596 = load i64, ptr %p4595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4596, ptr %slot715, align 8
  %v4597 = load i64, ptr %slot715, align 8
  %v4598 = load i64, ptr %slot48, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  store i64 %v4597, ptr %p4599, align 8, !alias.scope !3, !noalias !4
  br label %bb_i90
bb_i112:
  %v4600 = load i64, ptr %slot34, align 8
  %p4601 = inttoptr i64 %v4600 to ptr
  %ld4602 = load i64, ptr %p4601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4602, ptr %slot716, align 8
  %v4603 = load i64, ptr %slot716, align 8
  %v4604 = load i64, ptr %slot58, align 8
  %p4605 = inttoptr i64 %v4604 to ptr
  store i64 %v4603, ptr %p4605, align 8, !alias.scope !3, !noalias !4
  %v4606 = load i64, ptr %slot58, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  %ld4608 = load i64, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4608, ptr %slot717, align 8
  %v4609 = load i64, ptr %slot1, align 8
  %v4610 = load i64, ptr %slot717, align 8
  %call4611 = call i64 @myl_f_fa0b1953e8cd9a109ffbfa6357a620ad23550d479633b6aae1a336955a026eac(i64 %v4609, i64 %v4610) nomerge, !dbg !180
  store i64 %call4611, ptr %slot718, align 8
  %v4612 = load i64, ptr %slot718, align 8
  %v4613 = load i64, ptr %slot58, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  store i64 %v4612, ptr %p4614, align 8, !alias.scope !3, !noalias !4
  %v4615 = load i64, ptr %slot20, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  %ld4617 = load i32, ptr %p4616, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4617, ptr %slot719, align 8
  %v4618 = load i32, ptr %slot719, align 8
  %cv4619 = zext i32 %v4618 to i64
  %cond4620 = icmp ne i64 %cv4619, 0
  br i1 %cond4620, label %bb_rcslotdrop1002, label %bb_rcslotdone1002
bb_rcslotdrop1002:
  %v4621 = load i64, ptr %slot20, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  store i32 0, ptr %p4622, align 4, !alias.scope !3, !noalias !4
  %v4623 = load i64, ptr %slot27, align 8
  store i64 %v4623, ptr %slot720, align 8
  %v4624 = load i64, ptr %slot21, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  %ld4626 = load i32, ptr %p4625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4626, ptr %slot721, align 8
  %v4627 = load i32, ptr %slot721, align 8
  %op4628 = and i32 %v4627, 28
  store i32 %op4628, ptr %slot722, align 8
  %v4629 = load i32, ptr %slot722, align 8
  %cv4630 = zext i32 %v4629 to i64
  %cond4631 = icmp ne i64 %cv4630, 0
  br i1 %cond4631, label %bb_rcslotrole1002, label %bb_rcslotowner1002
bb_rcslotrole1002:
  %v4632 = load i64, ptr %slot71, align 8
  store i64 %v4632, ptr %slot723, align 8
  %v4633 = load i64, ptr %slot723, align 8
  %v4634 = load i64, ptr %slot720, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v4633, i64 %v4634) nomerge, !dbg !180
  br label %bb_rcslotdone1002
bb_rcslotowner1002:
  %v4635 = load i64, ptr %slot71, align 8
  store i64 %v4635, ptr %slot724, align 8
  %v4636 = load i64, ptr %slot724, align 8
  %v4637 = load i64, ptr %slot720, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v4636, i64 %v4637) nomerge, !dbg !180
  br label %bb_rcslotdone1002
bb_rcslotdone1002:
  %v4638 = load i64, ptr %slot58, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %ld4640 = load i64, ptr %p4639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4640, ptr %slot725, align 8
  %v4641 = load i64, ptr %slot725, align 8
  %v4642 = load i64, ptr %slot55, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  store i64 %v4641, ptr %p4643, align 8, !alias.scope !3, !noalias !4
  %v4644 = load i64, ptr %slot34, align 8
  %p4645 = inttoptr i64 %v4644 to ptr
  %ld4646 = load i64, ptr %p4645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4646, ptr %slot726, align 8
  %v4647 = load i64, ptr %slot726, align 8
  %v4648 = load i64, ptr %slot58, align 8
  %p4649 = inttoptr i64 %v4648 to ptr
  store i64 %v4647, ptr %p4649, align 8, !alias.scope !3, !noalias !4
  %v4650 = load i64, ptr %slot58, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %ld4652 = load i64, ptr %p4651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4652, ptr %slot727, align 8
  %v4653 = load i64, ptr %slot727, align 8
  %op4654 = add i64 %v4653, 0
  store i64 %op4654, ptr %slot728, align 8
  %v4655 = load i64, ptr %slot728, align 8
  %v4656 = load i64, ptr %slot58, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  store i64 %v4655, ptr %p4657, align 8, !alias.scope !3, !noalias !4
  %v4658 = load i64, ptr %slot20, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %ld4660 = load i32, ptr %p4659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4660, ptr %slot729, align 8
  %v4661 = load i32, ptr %slot729, align 8
  %cv4662 = zext i32 %v4661 to i64
  %cond4663 = icmp ne i64 %cv4662, 0
  br i1 %cond4663, label %bb_rcslotdrop1015, label %bb_rcslotdone1015
bb_rcslotdrop1015:
  %v4664 = load i64, ptr %slot20, align 8
  %p4665 = inttoptr i64 %v4664 to ptr
  store i32 0, ptr %p4665, align 4, !alias.scope !3, !noalias !4
  %v4666 = load i64, ptr %slot27, align 8
  store i64 %v4666, ptr %slot730, align 8
  %v4667 = load i64, ptr %slot21, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %ld4669 = load i32, ptr %p4668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4669, ptr %slot731, align 8
  %v4670 = load i32, ptr %slot731, align 8
  %op4671 = and i32 %v4670, 28
  store i32 %op4671, ptr %slot732, align 8
  %v4672 = load i32, ptr %slot732, align 8
  %cv4673 = zext i32 %v4672 to i64
  %cond4674 = icmp ne i64 %cv4673, 0
  br i1 %cond4674, label %bb_rcslotrole1015, label %bb_rcslotowner1015
bb_rcslotrole1015:
  %v4675 = load i64, ptr %slot71, align 8
  store i64 %v4675, ptr %slot733, align 8
  %v4676 = load i64, ptr %slot733, align 8
  %v4677 = load i64, ptr %slot730, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v4676, i64 %v4677) nomerge, !dbg !182
  br label %bb_rcslotdone1015
bb_rcslotowner1015:
  %v4678 = load i64, ptr %slot71, align 8
  store i64 %v4678, ptr %slot734, align 8
  %v4679 = load i64, ptr %slot734, align 8
  %v4680 = load i64, ptr %slot730, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v4679, i64 %v4680) nomerge, !dbg !182
  br label %bb_rcslotdone1015
bb_rcslotdone1015:
  %v4681 = load i64, ptr %slot58, align 8
  %p4682 = inttoptr i64 %v4681 to ptr
  %ld4683 = load i64, ptr %p4682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4683, ptr %slot735, align 8
  %v4684 = load i64, ptr %slot735, align 8
  %op4685 = add i64 %v4684, 16
  store i64 %op4685, ptr %slot736, align 8
  %v4686 = load i64, ptr %slot736, align 8
  %p4687 = inttoptr i64 %v4686 to ptr
  %ld4688 = load i64, ptr %p4687, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4688, ptr %slot737, align 8
  %v4689 = load i64, ptr %slot737, align 8
  %v4690 = load i64, ptr %slot58, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  store i64 %v4689, ptr %p4691, align 8, !alias.scope !3, !noalias !4
  %v4692 = load i64, ptr %slot58, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i64, ptr %p4693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4694, ptr %slot738, align 8
  %v4695 = load i64, ptr %slot738, align 8
  %v4696 = load i64, ptr %slot29, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  store i64 %v4695, ptr %p4697, align 8, !alias.scope !3, !noalias !4
  %v4698 = load i64, ptr %slot29, align 8
  store i64 %v4698, ptr %slot739, align 8
  %v4699 = load i64, ptr %slot30, align 8
  store i64 %v4699, ptr %slot740, align 8
  %v4700 = load i64, ptr %slot739, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  %ld4702 = load i64, ptr %p4701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4702, ptr %slot741, align 8
  %v4703 = load i64, ptr %slot741, align 8
  %cmp4704 = icmp ne i64 %v4703, 0
  %cv4705 = zext i1 %cmp4704 to i32
  store i32 %cv4705, ptr %slot742, align 8
  %v4706 = load i32, ptr %slot742, align 8
  %cv4707 = zext i32 %v4706 to i64
  %cond4708 = icmp ne i64 %cv4707, 0
  br i1 %cond4708, label %bb_rcgnn1029, label %bb_rcgstore1029
bb_rcgnn1029:
  %v4709 = load i64, ptr %slot741, align 8
  %op4710 = sub i64 %v4709, 16
  store i64 %op4710, ptr %slot743, align 8
  %v4711 = load i64, ptr %slot741, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %rgep4713 = getelementptr i8, ptr %p4712, i64 -16
  %ld4714 = load i64, ptr %rgep4713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4714, ptr %slot744, align 8
  %v4715 = load i64, ptr %slot744, align 8
  %op4716 = and i64 %v4715, 4611686018427387906
  store i64 %op4716, ptr %slot745, align 8
  %v4717 = load i64, ptr %slot745, align 8
  %cmp4718 = icmp ne i64 %v4717, 0
  %cv4719 = zext i1 %cmp4718 to i32
  store i32 %cv4719, ptr %slot746, align 8
  %v4720 = load i32, ptr %slot746, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcgstore1029, label %bb_rcginc1029
bb_rcginc1029:
  %v4723 = load i64, ptr %slot741, align 8
  %op4724 = sub i64 %v4723, 24
  store i64 %op4724, ptr %slot747, align 8
  %v4725 = load i64, ptr %slot741, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %rgep4727 = getelementptr i8, ptr %p4726, i64 -24
  %ld4728 = load i64, ptr %rgep4727, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4728, ptr %slot748, align 8
  %v4729 = load i64, ptr %slot748, align 8
  %op4730 = add i64 %v4729, 1
  store i64 %op4730, ptr %slot749, align 8
  %v4731 = load i64, ptr %slot749, align 8
  %cmp4732 = icmp eq i64 %v4731, 0
  %cv4733 = zext i1 %cmp4732 to i32
  store i32 %cv4733, ptr %slot750, align 8
  %v4734 = load i32, ptr %slot750, align 8
  %cv4735 = zext i32 %v4734 to i64
  %cond4736 = icmp ne i64 %cv4735, 0
  br i1 %cond4736, label %bb_rcglimit1029, label %bb_rcgcapacity1029
bb_rcglimit1029:
  %v4737 = load i64, ptr %slot1, align 8
  %p4738 = inttoptr i64 %v4737 to ptr
  %call4739 = call i32 @myl_qbe_rc_status(ptr %p4738, i32 2) nomerge, !dbg !184
  store i32 %call4739, ptr %slot751, align 8
  br label %bb_failure
bb_rcgcapacity1029:
  %v4740 = load i64, ptr %slot749, align 8
  %v4741 = load i64, ptr %slot741, align 8
  %p4742 = inttoptr i64 %v4741 to ptr
  %rgep4743 = getelementptr i8, ptr %p4742, i64 -24
  store i64 %v4740, ptr %rgep4743, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1029
bb_rcgstore1029:
  %v4744 = load i64, ptr %slot741, align 8
  %v4745 = load i64, ptr %slot740, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  store i64 %v4744, ptr %p4746, align 8, !alias.scope !3, !noalias !4
  %v4747 = load i64, ptr %slot25, align 8
  %p4748 = inttoptr i64 %v4747 to ptr
  store i32 2, ptr %p4748, align 4, !alias.scope !3, !noalias !4
  %v4749 = load i64, ptr %slot25, align 8
  %p4750 = inttoptr i64 %v4749 to ptr
  store i32 16, ptr %p4750, align 4, !alias.scope !3, !noalias !4
  %v4751 = load i64, ptr %slot24, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  store i32 1, ptr %p4752, align 4, !alias.scope !3, !noalias !4
  %v4753 = load i64, ptr %slot20, align 8
  %p4754 = inttoptr i64 %v4753 to ptr
  %ld4755 = load i32, ptr %p4754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4755, ptr %slot752, align 8
  %v4756 = load i32, ptr %slot752, align 8
  %cv4757 = zext i32 %v4756 to i64
  %cond4758 = icmp ne i64 %cv4757, 0
  br i1 %cond4758, label %bb_rcslotdrop1045, label %bb_rcslotdone1045
bb_rcslotdrop1045:
  %v4759 = load i64, ptr %slot20, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  store i32 0, ptr %p4760, align 4, !alias.scope !3, !noalias !4
  %v4761 = load i64, ptr %slot27, align 8
  store i64 %v4761, ptr %slot753, align 8
  %v4762 = load i64, ptr %slot21, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %ld4764 = load i32, ptr %p4763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4764, ptr %slot754, align 8
  %v4765 = load i32, ptr %slot754, align 8
  %op4766 = and i32 %v4765, 28
  store i32 %op4766, ptr %slot755, align 8
  %v4767 = load i32, ptr %slot755, align 8
  %cv4768 = zext i32 %v4767 to i64
  %cond4769 = icmp ne i64 %cv4768, 0
  br i1 %cond4769, label %bb_rcslotrole1045, label %bb_rcslotowner1045
bb_rcslotrole1045:
  %v4770 = load i64, ptr %slot71, align 8
  store i64 %v4770, ptr %slot756, align 8
  %v4771 = load i64, ptr %slot756, align 8
  %v4772 = load i64, ptr %slot753, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v4771, i64 %v4772) nomerge, !dbg !184
  br label %bb_rcslotdone1045
bb_rcslotowner1045:
  %v4773 = load i64, ptr %slot71, align 8
  store i64 %v4773, ptr %slot757, align 8
  %v4774 = load i64, ptr %slot757, align 8
  %v4775 = load i64, ptr %slot753, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v4774, i64 %v4775) nomerge, !dbg !184
  br label %bb_rcslotdone1045
bb_rcslotdone1045:
  %v4776 = load i64, ptr %slot27, align 8
  store i64 %v4776, ptr %slot758, align 8
  %v4777 = load i64, ptr %slot30, align 8
  store i64 %v4777, ptr %slot759, align 8
  %v4778 = load i64, ptr %slot759, align 8
  %v4779 = load i64, ptr %slot758, align 8
  %p4780 = inttoptr i64 %v4778 to ptr
  %p4781 = inttoptr i64 %v4779 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4781, ptr %p4780, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4782 = load i64, ptr %slot21, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  store i32 2, ptr %p4783, align 4, !alias.scope !3, !noalias !4
  %v4784 = load i64, ptr %slot25, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  %ld4786 = load i32, ptr %p4785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4786, ptr %slot760, align 8
  %v4787 = load i32, ptr %slot760, align 8
  %v4788 = load i64, ptr %slot21, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  store i32 %v4787, ptr %p4789, align 4, !alias.scope !3, !noalias !4
  %v4790 = load i64, ptr %slot24, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  store i32 0, ptr %p4791, align 4, !alias.scope !3, !noalias !4
  %v4792 = load i64, ptr %slot20, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i32 1, ptr %p4793, align 4, !alias.scope !3, !noalias !4
  %v4794 = load i64, ptr %slot758, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %ld4796 = load i64, ptr %p4795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4796, ptr %slot761, align 8
  %v4797 = load i64, ptr %slot761, align 8
  %v4798 = load i64, ptr %slot58, align 8
  %p4799 = inttoptr i64 %v4798 to ptr
  store i64 %v4797, ptr %p4799, align 8, !alias.scope !3, !noalias !4
  %v4800 = load i64, ptr %slot58, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %ld4802 = load i64, ptr %p4801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4802, ptr %slot762, align 8
  %v4803 = load i64, ptr %slot34, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %ld4805 = load i64, ptr %p4804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4805, ptr %slot763, align 8
  %v4806 = load i64, ptr %slot20, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  %ld4808 = load i32, ptr %p4807, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4808, ptr %slot764, align 8
  %v4809 = load i32, ptr %slot764, align 8
  %cv4810 = zext i32 %v4809 to i64
  %cond4811 = icmp ne i64 %cv4810, 0
  br i1 %cond4811, label %bb_rcslotdrop1066, label %bb_rcslotdone1066
bb_rcslotdrop1066:
  %v4812 = load i64, ptr %slot20, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  store i32 0, ptr %p4813, align 4, !alias.scope !3, !noalias !4
  %v4814 = load i64, ptr %slot27, align 8
  store i64 %v4814, ptr %slot765, align 8
  %v4815 = load i64, ptr %slot21, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %ld4817 = load i32, ptr %p4816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4817, ptr %slot766, align 8
  %v4818 = load i32, ptr %slot766, align 8
  %op4819 = and i32 %v4818, 28
  store i32 %op4819, ptr %slot767, align 8
  %v4820 = load i32, ptr %slot767, align 8
  %cv4821 = zext i32 %v4820 to i64
  %cond4822 = icmp ne i64 %cv4821, 0
  br i1 %cond4822, label %bb_rcslotrole1066, label %bb_rcslotowner1066
bb_rcslotrole1066:
  %v4823 = load i64, ptr %slot71, align 8
  store i64 %v4823, ptr %slot768, align 8
  %v4824 = load i64, ptr %slot765, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %ld4826 = load i64, ptr %p4825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4826, ptr %slot769, align 8
  %v4827 = load i64, ptr %slot769, align 8
  %cmp4828 = icmp ne i64 %v4827, 0
  %cv4829 = zext i1 %cmp4828 to i32
  store i32 %cv4829, ptr %slot770, align 8
  %v4830 = load i32, ptr %slot770, align 8
  %cv4831 = zext i32 %v4830 to i64
  %cond4832 = icmp ne i64 %cv4831, 0
  br i1 %cond4832, label %bb_rcgnn1082, label %bb_rcgdone1082
bb_rcgnn1082:
  %v4833 = load i64, ptr %slot769, align 8
  %op4834 = sub i64 %v4833, 16
  store i64 %op4834, ptr %slot771, align 8
  %v4835 = load i64, ptr %slot769, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  %rgep4837 = getelementptr i8, ptr %p4836, i64 -16
  %ld4838 = load i64, ptr %rgep4837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4838, ptr %slot772, align 8
  %v4839 = load i64, ptr %slot772, align 8
  %op4840 = and i64 %v4839, 4611686018427387906
  store i64 %op4840, ptr %slot773, align 8
  %v4841 = load i64, ptr %slot773, align 8
  %cmp4842 = icmp ne i64 %v4841, 0
  %cv4843 = zext i1 %cmp4842 to i32
  store i32 %cv4843, ptr %slot774, align 8
  %v4844 = load i32, ptr %slot774, align 8
  %cv4845 = zext i32 %v4844 to i64
  %cond4846 = icmp ne i64 %cv4845, 0
  br i1 %cond4846, label %bb_rcgclear1082, label %bb_rcgcounted1082
bb_rcgcounted1082:
  %v4847 = load i64, ptr %slot769, align 8
  %op4848 = sub i64 %v4847, 24
  store i64 %op4848, ptr %slot775, align 8
  %v4849 = load i64, ptr %slot769, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  %rgep4851 = getelementptr i8, ptr %p4850, i64 -24
  %ld4852 = load i64, ptr %rgep4851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4852, ptr %slot776, align 8
  %v4853 = load i64, ptr %slot776, align 8
  %op4854 = sub i64 %v4853, 1
  store i64 %op4854, ptr %slot777, align 8
  %v4855 = load i64, ptr %slot777, align 8
  %cmp4856 = icmp eq i64 %v4855, 0
  %cv4857 = zext i1 %cmp4856 to i32
  store i32 %cv4857, ptr %slot778, align 8
  %v4858 = load i32, ptr %slot778, align 8
  %cv4859 = zext i32 %v4858 to i64
  %cond4860 = icmp ne i64 %cv4859, 0
  br i1 %cond4860, label %bb_rcglast1082, label %bb_rcgdec1082
bb_rcglast1082:
  %v4861 = load i64, ptr %slot769, align 8
  %op4862 = sub i64 %v4861, 32
  store i64 %op4862, ptr %slot779, align 8
  %v4863 = load i64, ptr %slot769, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  %rgep4865 = getelementptr i8, ptr %p4864, i64 -32
  %ld4866 = load i64, ptr %rgep4865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4866, ptr %slot780, align 8
  %v4867 = load i64, ptr %slot780, align 8
  %cmp4868 = icmp ne i64 %v4867, 0
  %cv4869 = zext i1 %cmp4868 to i32
  store i32 %cv4869, ptr %slot781, align 8
  %v4870 = load i32, ptr %slot781, align 8
  %cv4871 = zext i32 %v4870 to i64
  %cond4872 = icmp ne i64 %cv4871, 0
  br i1 %cond4872, label %bb_rcgdec1082, label %bb_rcgslow1082
bb_rcgslow1082:
  %v4873 = load i64, ptr %slot768, align 8
  %v4874 = load i64, ptr %slot765, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v4873, i64 %v4874) nomerge, !dbg !186
  br label %bb_rcgdone1082
bb_rcgdec1082:
  %v4875 = load i64, ptr %slot777, align 8
  %v4876 = load i64, ptr %slot769, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %rgep4878 = getelementptr i8, ptr %p4877, i64 -24
  store i64 %v4875, ptr %rgep4878, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1082
bb_rcgclear1082:
  %v4879 = load i64, ptr %slot765, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  store i64 0, ptr %p4880, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1082
bb_rcgdone1082:
  br label %bb_rcslotdone1066
bb_rcslotowner1066:
  %v4881 = load i64, ptr %slot71, align 8
  store i64 %v4881, ptr %slot782, align 8
  %v4882 = load i64, ptr %slot765, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  %ld4884 = load i64, ptr %p4883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4884, ptr %slot783, align 8
  %v4885 = load i64, ptr %slot783, align 8
  %cmp4886 = icmp ne i64 %v4885, 0
  %cv4887 = zext i1 %cmp4886 to i32
  store i32 %cv4887, ptr %slot784, align 8
  %v4888 = load i32, ptr %slot784, align 8
  %cv4889 = zext i32 %v4888 to i64
  %cond4890 = icmp ne i64 %cv4889, 0
  br i1 %cond4890, label %bb_rcgnn1097, label %bb_rcgdone1097
bb_rcgnn1097:
  %v4891 = load i64, ptr %slot783, align 8
  %op4892 = sub i64 %v4891, 16
  store i64 %op4892, ptr %slot785, align 8
  %v4893 = load i64, ptr %slot783, align 8
  %p4894 = inttoptr i64 %v4893 to ptr
  %rgep4895 = getelementptr i8, ptr %p4894, i64 -16
  %ld4896 = load i64, ptr %rgep4895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4896, ptr %slot786, align 8
  %v4897 = load i64, ptr %slot786, align 8
  %op4898 = and i64 %v4897, 4611686018427387906
  store i64 %op4898, ptr %slot787, align 8
  %v4899 = load i64, ptr %slot787, align 8
  %cmp4900 = icmp ne i64 %v4899, 0
  %cv4901 = zext i1 %cmp4900 to i32
  store i32 %cv4901, ptr %slot788, align 8
  %v4902 = load i32, ptr %slot788, align 8
  %cv4903 = zext i32 %v4902 to i64
  %cond4904 = icmp ne i64 %cv4903, 0
  br i1 %cond4904, label %bb_rcgclear1097, label %bb_rcgcounted1097
bb_rcgcounted1097:
  %v4905 = load i64, ptr %slot783, align 8
  %op4906 = sub i64 %v4905, 32
  store i64 %op4906, ptr %slot789, align 8
  %v4907 = load i64, ptr %slot783, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  %rgep4909 = getelementptr i8, ptr %p4908, i64 -32
  %ld4910 = load i64, ptr %rgep4909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4910, ptr %slot790, align 8
  %v4911 = load i64, ptr %slot790, align 8
  %op4912 = sub i64 %v4911, 1
  store i64 %op4912, ptr %slot791, align 8
  %v4913 = load i64, ptr %slot791, align 8
  %cmp4914 = icmp eq i64 %v4913, 0
  %cv4915 = zext i1 %cmp4914 to i32
  store i32 %cv4915, ptr %slot792, align 8
  %v4916 = load i32, ptr %slot792, align 8
  %cv4917 = zext i32 %v4916 to i64
  %cond4918 = icmp ne i64 %cv4917, 0
  br i1 %cond4918, label %bb_rcglast1097, label %bb_rcgdec1097
bb_rcglast1097:
  %v4919 = load i64, ptr %slot783, align 8
  %op4920 = sub i64 %v4919, 24
  store i64 %op4920, ptr %slot793, align 8
  %v4921 = load i64, ptr %slot783, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %rgep4923 = getelementptr i8, ptr %p4922, i64 -24
  %ld4924 = load i64, ptr %rgep4923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4924, ptr %slot794, align 8
  %v4925 = load i64, ptr %slot794, align 8
  %cmp4926 = icmp ne i64 %v4925, 0
  %cv4927 = zext i1 %cmp4926 to i32
  store i32 %cv4927, ptr %slot795, align 8
  %v4928 = load i32, ptr %slot795, align 8
  %cv4929 = zext i32 %v4928 to i64
  %cond4930 = icmp ne i64 %cv4929, 0
  br i1 %cond4930, label %bb_rcgdec1097, label %bb_rcgslow1097
bb_rcgslow1097:
  %v4931 = load i64, ptr %slot782, align 8
  %v4932 = load i64, ptr %slot765, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v4931, i64 %v4932) nomerge, !dbg !186
  br label %bb_rcgdone1097
bb_rcgdec1097:
  %v4933 = load i64, ptr %slot791, align 8
  %v4934 = load i64, ptr %slot783, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %rgep4936 = getelementptr i8, ptr %p4935, i64 -32
  store i64 %v4933, ptr %rgep4936, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1097
bb_rcgclear1097:
  %v4937 = load i64, ptr %slot765, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  store i64 0, ptr %p4938, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1097
bb_rcgdone1097:
  br label %bb_rcslotdone1066
bb_rcslotdone1066:
  %v4939 = load i64, ptr %slot763, align 8
  %op4940 = add i64 %v4939, 0
  store i64 %op4940, ptr %slot796, align 8
  %v4941 = load i64, ptr %slot796, align 8
  %op4942 = add i64 %v4941, 16
  store i64 %op4942, ptr %slot797, align 8
  store i64 0, ptr %slot798, align 8
  %v4943 = load i64, ptr %slot797, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  %ld4945 = load i64, ptr %p4944, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4945, ptr %slot799, align 8
  %v4946 = load i64, ptr %slot799, align 8
  %cmp4947 = icmp ne i64 %v4946, 0
  %cv4948 = zext i1 %cmp4947 to i32
  store i32 %cv4948, ptr %slot800, align 8
  %v4949 = load i32, ptr %slot800, align 8
  %cv4950 = zext i32 %v4949 to i64
  %cond4951 = icmp ne i64 %cv4950, 0
  br i1 %cond4951, label %bb_rcguniquenn1104, label %bb_rcgunique1104
bb_rcguniquenn1104:
  %v4952 = load i64, ptr %slot799, align 8
  %op4953 = sub i64 %v4952, 16
  store i64 %op4953, ptr %slot801, align 8
  %v4954 = load i64, ptr %slot799, align 8
  %p4955 = inttoptr i64 %v4954 to ptr
  %rgep4956 = getelementptr i8, ptr %p4955, i64 -16
  %ld4957 = load i64, ptr %rgep4956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4957, ptr %slot802, align 8
  %v4958 = load i64, ptr %slot802, align 8
  %op4959 = and i64 %v4958, 6917529027641081858
  store i64 %op4959, ptr %slot803, align 8
  %v4960 = load i64, ptr %slot803, align 8
  %cmp4961 = icmp ne i64 %v4960, 0
  %cv4962 = zext i1 %cmp4961 to i32
  store i32 %cv4962, ptr %slot804, align 8
  %v4963 = load i32, ptr %slot804, align 8
  %cv4964 = zext i32 %v4963 to i64
  %cond4965 = icmp ne i64 %cv4964, 0
  br i1 %cond4965, label %bb_rcguniqueslow1104, label %bb_rcguniquecount1104
bb_rcguniquecount1104:
  %v4966 = load i64, ptr %slot799, align 8
  %op4967 = sub i64 %v4966, 32
  store i64 %op4967, ptr %slot805, align 8
  %v4968 = load i64, ptr %slot799, align 8
  %p4969 = inttoptr i64 %v4968 to ptr
  %rgep4970 = getelementptr i8, ptr %p4969, i64 -32
  %ld4971 = load i64, ptr %rgep4970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4971, ptr %slot806, align 8
  %v4972 = load i64, ptr %slot806, align 8
  %cmp4973 = icmp ult i64 %v4972, 2
  %cv4974 = zext i1 %cmp4973 to i32
  store i32 %cv4974, ptr %slot807, align 8
  %v4975 = load i32, ptr %slot807, align 8
  %cv4976 = zext i32 %v4975 to i64
  %cond4977 = icmp ne i64 %cv4976, 0
  br i1 %cond4977, label %bb_rcgunique1104, label %bb_rcguniqueslow1104
bb_rcguniqueslow1104:
  %v4978 = load i64, ptr %slot1, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %p4980 = inttoptr i64 ptrtoint (ptr @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb to i64) to ptr
  %v4981 = load i64, ptr %slot797, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  %v4983 = load i64, ptr %slot798, align 8
  %p4984 = inttoptr i64 %v4983 to ptr
  %call4985 = call i32 @myl_qbe_rc_unique_field(ptr %p4979, ptr %p4980, ptr %p4982, ptr %p4984) nomerge, !dbg !186
  store i32 %call4985, ptr %slot808, align 8
  %v4986 = load i32, ptr %slot808, align 8
  %cv4987 = zext i32 %v4986 to i64
  %cond4988 = icmp ne i64 %cv4987, 0
  br i1 %cond4988, label %bb_rcunique1114, label %bb_failure
bb_rcunique1114:
  br label %bb_rcgunique1104
bb_rcgunique1104:
  %v4989 = load i64, ptr %slot797, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %ld4991 = load i64, ptr %p4990, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4991, ptr %slot809, align 8
  %v4992 = load i64, ptr %slot809, align 8
  %v4993 = load i64, ptr %slot58, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  store i64 %v4992, ptr %p4994, align 8, !alias.scope !3, !noalias !4
  %v4995 = load i64, ptr %slot58, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %ld4997 = load i64, ptr %p4996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4997, ptr %slot810, align 8
  %v4998 = load i64, ptr %slot20, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  %ld5000 = load i32, ptr %p4999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5000, ptr %slot811, align 8
  %v5001 = load i32, ptr %slot811, align 8
  %cv5002 = zext i32 %v5001 to i64
  %cond5003 = icmp ne i64 %cv5002, 0
  br i1 %cond5003, label %bb_rcslotdrop1119, label %bb_rcslotdone1119
bb_rcslotdrop1119:
  %v5004 = load i64, ptr %slot20, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  store i32 0, ptr %p5005, align 4, !alias.scope !3, !noalias !4
  %v5006 = load i64, ptr %slot27, align 8
  store i64 %v5006, ptr %slot812, align 8
  %v5007 = load i64, ptr %slot21, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  %ld5009 = load i32, ptr %p5008, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5009, ptr %slot813, align 8
  %v5010 = load i32, ptr %slot813, align 8
  %op5011 = and i32 %v5010, 28
  store i32 %op5011, ptr %slot814, align 8
  %v5012 = load i32, ptr %slot814, align 8
  %cv5013 = zext i32 %v5012 to i64
  %cond5014 = icmp ne i64 %cv5013, 0
  br i1 %cond5014, label %bb_rcslotrole1119, label %bb_rcslotowner1119
bb_rcslotrole1119:
  %v5015 = load i64, ptr %slot71, align 8
  store i64 %v5015, ptr %slot815, align 8
  %v5016 = load i64, ptr %slot812, align 8
  %p5017 = inttoptr i64 %v5016 to ptr
  %ld5018 = load i64, ptr %p5017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5018, ptr %slot816, align 8
  %v5019 = load i64, ptr %slot816, align 8
  %cmp5020 = icmp ne i64 %v5019, 0
  %cv5021 = zext i1 %cmp5020 to i32
  store i32 %cv5021, ptr %slot817, align 8
  %v5022 = load i32, ptr %slot817, align 8
  %cv5023 = zext i32 %v5022 to i64
  %cond5024 = icmp ne i64 %cv5023, 0
  br i1 %cond5024, label %bb_rcgnn1135, label %bb_rcgdone1135
bb_rcgnn1135:
  %v5025 = load i64, ptr %slot816, align 8
  %op5026 = sub i64 %v5025, 16
  store i64 %op5026, ptr %slot818, align 8
  %v5027 = load i64, ptr %slot816, align 8
  %p5028 = inttoptr i64 %v5027 to ptr
  %rgep5029 = getelementptr i8, ptr %p5028, i64 -16
  %ld5030 = load i64, ptr %rgep5029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5030, ptr %slot819, align 8
  %v5031 = load i64, ptr %slot819, align 8
  %op5032 = and i64 %v5031, 4611686018427387906
  store i64 %op5032, ptr %slot820, align 8
  %v5033 = load i64, ptr %slot820, align 8
  %cmp5034 = icmp ne i64 %v5033, 0
  %cv5035 = zext i1 %cmp5034 to i32
  store i32 %cv5035, ptr %slot821, align 8
  %v5036 = load i32, ptr %slot821, align 8
  %cv5037 = zext i32 %v5036 to i64
  %cond5038 = icmp ne i64 %cv5037, 0
  br i1 %cond5038, label %bb_rcgclear1135, label %bb_rcgcounted1135
bb_rcgcounted1135:
  %v5039 = load i64, ptr %slot816, align 8
  %op5040 = sub i64 %v5039, 24
  store i64 %op5040, ptr %slot822, align 8
  %v5041 = load i64, ptr %slot816, align 8
  %p5042 = inttoptr i64 %v5041 to ptr
  %rgep5043 = getelementptr i8, ptr %p5042, i64 -24
  %ld5044 = load i64, ptr %rgep5043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5044, ptr %slot823, align 8
  %v5045 = load i64, ptr %slot823, align 8
  %op5046 = sub i64 %v5045, 1
  store i64 %op5046, ptr %slot824, align 8
  %v5047 = load i64, ptr %slot824, align 8
  %cmp5048 = icmp eq i64 %v5047, 0
  %cv5049 = zext i1 %cmp5048 to i32
  store i32 %cv5049, ptr %slot825, align 8
  %v5050 = load i32, ptr %slot825, align 8
  %cv5051 = zext i32 %v5050 to i64
  %cond5052 = icmp ne i64 %cv5051, 0
  br i1 %cond5052, label %bb_rcglast1135, label %bb_rcgdec1135
bb_rcglast1135:
  %v5053 = load i64, ptr %slot816, align 8
  %op5054 = sub i64 %v5053, 32
  store i64 %op5054, ptr %slot826, align 8
  %v5055 = load i64, ptr %slot816, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  %rgep5057 = getelementptr i8, ptr %p5056, i64 -32
  %ld5058 = load i64, ptr %rgep5057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5058, ptr %slot827, align 8
  %v5059 = load i64, ptr %slot827, align 8
  %cmp5060 = icmp ne i64 %v5059, 0
  %cv5061 = zext i1 %cmp5060 to i32
  store i32 %cv5061, ptr %slot828, align 8
  %v5062 = load i32, ptr %slot828, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcgdec1135, label %bb_rcgslow1135
bb_rcgslow1135:
  %v5065 = load i64, ptr %slot815, align 8
  %v5066 = load i64, ptr %slot812, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v5065, i64 %v5066) nomerge, !dbg !186
  br label %bb_rcgdone1135
bb_rcgdec1135:
  %v5067 = load i64, ptr %slot824, align 8
  %v5068 = load i64, ptr %slot816, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  %rgep5070 = getelementptr i8, ptr %p5069, i64 -24
  store i64 %v5067, ptr %rgep5070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1135
bb_rcgclear1135:
  %v5071 = load i64, ptr %slot812, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  store i64 0, ptr %p5072, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1135
bb_rcgdone1135:
  br label %bb_rcslotdone1119
bb_rcslotowner1119:
  %v5073 = load i64, ptr %slot71, align 8
  store i64 %v5073, ptr %slot829, align 8
  %v5074 = load i64, ptr %slot812, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  %ld5076 = load i64, ptr %p5075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5076, ptr %slot830, align 8
  %v5077 = load i64, ptr %slot830, align 8
  %cmp5078 = icmp ne i64 %v5077, 0
  %cv5079 = zext i1 %cmp5078 to i32
  store i32 %cv5079, ptr %slot831, align 8
  %v5080 = load i32, ptr %slot831, align 8
  %cv5081 = zext i32 %v5080 to i64
  %cond5082 = icmp ne i64 %cv5081, 0
  br i1 %cond5082, label %bb_rcgnn1150, label %bb_rcgdone1150
bb_rcgnn1150:
  %v5083 = load i64, ptr %slot830, align 8
  %op5084 = sub i64 %v5083, 16
  store i64 %op5084, ptr %slot832, align 8
  %v5085 = load i64, ptr %slot830, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %rgep5087 = getelementptr i8, ptr %p5086, i64 -16
  %ld5088 = load i64, ptr %rgep5087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5088, ptr %slot833, align 8
  %v5089 = load i64, ptr %slot833, align 8
  %op5090 = and i64 %v5089, 4611686018427387906
  store i64 %op5090, ptr %slot834, align 8
  %v5091 = load i64, ptr %slot834, align 8
  %cmp5092 = icmp ne i64 %v5091, 0
  %cv5093 = zext i1 %cmp5092 to i32
  store i32 %cv5093, ptr %slot835, align 8
  %v5094 = load i32, ptr %slot835, align 8
  %cv5095 = zext i32 %v5094 to i64
  %cond5096 = icmp ne i64 %cv5095, 0
  br i1 %cond5096, label %bb_rcgclear1150, label %bb_rcgcounted1150
bb_rcgcounted1150:
  %v5097 = load i64, ptr %slot830, align 8
  %op5098 = sub i64 %v5097, 32
  store i64 %op5098, ptr %slot836, align 8
  %v5099 = load i64, ptr %slot830, align 8
  %p5100 = inttoptr i64 %v5099 to ptr
  %rgep5101 = getelementptr i8, ptr %p5100, i64 -32
  %ld5102 = load i64, ptr %rgep5101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5102, ptr %slot837, align 8
  %v5103 = load i64, ptr %slot837, align 8
  %op5104 = sub i64 %v5103, 1
  store i64 %op5104, ptr %slot838, align 8
  %v5105 = load i64, ptr %slot838, align 8
  %cmp5106 = icmp eq i64 %v5105, 0
  %cv5107 = zext i1 %cmp5106 to i32
  store i32 %cv5107, ptr %slot839, align 8
  %v5108 = load i32, ptr %slot839, align 8
  %cv5109 = zext i32 %v5108 to i64
  %cond5110 = icmp ne i64 %cv5109, 0
  br i1 %cond5110, label %bb_rcglast1150, label %bb_rcgdec1150
bb_rcglast1150:
  %v5111 = load i64, ptr %slot830, align 8
  %op5112 = sub i64 %v5111, 24
  store i64 %op5112, ptr %slot840, align 8
  %v5113 = load i64, ptr %slot830, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  %rgep5115 = getelementptr i8, ptr %p5114, i64 -24
  %ld5116 = load i64, ptr %rgep5115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5116, ptr %slot841, align 8
  %v5117 = load i64, ptr %slot841, align 8
  %cmp5118 = icmp ne i64 %v5117, 0
  %cv5119 = zext i1 %cmp5118 to i32
  store i32 %cv5119, ptr %slot842, align 8
  %v5120 = load i32, ptr %slot842, align 8
  %cv5121 = zext i32 %v5120 to i64
  %cond5122 = icmp ne i64 %cv5121, 0
  br i1 %cond5122, label %bb_rcgdec1150, label %bb_rcgslow1150
bb_rcgslow1150:
  %v5123 = load i64, ptr %slot829, align 8
  %v5124 = load i64, ptr %slot812, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v5123, i64 %v5124) nomerge, !dbg !186
  br label %bb_rcgdone1150
bb_rcgdec1150:
  %v5125 = load i64, ptr %slot838, align 8
  %v5126 = load i64, ptr %slot830, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  %rgep5128 = getelementptr i8, ptr %p5127, i64 -32
  store i64 %v5125, ptr %rgep5128, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1150
bb_rcgclear1150:
  %v5129 = load i64, ptr %slot812, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  store i64 0, ptr %p5130, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1150
bb_rcgdone1150:
  br label %bb_rcslotdone1119
bb_rcslotdone1119:
  %v5131 = load i64, ptr %slot31, align 8
  store i64 %v5131, ptr %slot843, align 8
  %v5132 = load i64, ptr %slot71, align 8
  %v5133 = load i64, ptr %slot843, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  store i64 %v5132, ptr %p5134, align 8, !alias.scope !3, !noalias !4
  %v5135 = load i64, ptr %slot71, align 8
  %p5137 = inttoptr i64 %v5135 to ptr
  %gep5138 = getelementptr i8, ptr %p5137, i64 5640
  %op5136 = ptrtoint ptr %gep5138 to i64
  store i64 %op5136, ptr %slot844, align 8
  %v5139 = load i64, ptr %slot844, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  %ld5141 = load i64, ptr %p5140, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5141, ptr %slot845, align 8
  %v5142 = load i64, ptr %slot845, align 8
  %op5143 = add i64 %v5142, 248
  store i64 %op5143, ptr %slot846, align 8
  %v5144 = load i64, ptr %slot846, align 8
  %p5145 = inttoptr i64 %v5144 to ptr
  %ld5146 = load i64, ptr %p5145, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5146, ptr %slot847, align 8
  %v5147 = load i64, ptr %slot843, align 8
  %p5149 = inttoptr i64 %v5147 to ptr
  %gep5150 = getelementptr i8, ptr %p5149, i64 8
  %op5148 = ptrtoint ptr %gep5150 to i64
  store i64 %op5148, ptr %slot848, align 8
  %v5151 = load i64, ptr %slot847, align 8
  %v5152 = load i64, ptr %slot848, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  store i64 %v5151, ptr %p5153, align 8, !alias.scope !3, !noalias !4
  %v5154 = load i64, ptr %slot843, align 8
  %p5156 = inttoptr i64 %v5154 to ptr
  %gep5157 = getelementptr i8, ptr %p5156, i64 16
  %op5155 = ptrtoint ptr %gep5157 to i64
  store i64 %op5155, ptr %slot849, align 8
  %v5158 = load i64, ptr %slot849, align 8
  %p5159 = inttoptr i64 %v5158 to ptr
  store i64 0, ptr %p5159, align 8, !alias.scope !3, !noalias !4
  %v5160 = load i64, ptr %slot71, align 8
  %p5162 = inttoptr i64 %v5160 to ptr
  %gep5163 = getelementptr i8, ptr %p5162, i64 112
  %op5161 = ptrtoint ptr %gep5163 to i64
  store i64 %op5161, ptr %slot850, align 8
  %v5164 = load i64, ptr %slot843, align 8
  %p5166 = inttoptr i64 %v5164 to ptr
  %gep5167 = getelementptr i8, ptr %p5166, i64 24
  %op5165 = ptrtoint ptr %gep5167 to i64
  store i64 %op5165, ptr %slot851, align 8
  %v5168 = load i64, ptr %slot843, align 8
  %p5170 = inttoptr i64 %v5168 to ptr
  %gep5171 = getelementptr i8, ptr %p5170, i64 28
  %op5169 = ptrtoint ptr %gep5171 to i64
  store i64 %op5169, ptr %slot852, align 8
  %v5172 = load i64, ptr %slot850, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  %ld5174 = load i32, ptr %p5173, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld5174, ptr %slot853, align 8
  %v5175 = load i64, ptr %slot851, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  store i32 1, ptr %p5176, align 4, !alias.scope !3, !noalias !4
  %v5177 = load i32, ptr %slot853, align 8
  %v5178 = load i64, ptr %slot852, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  store i32 %v5177, ptr %p5179, align 4, !alias.scope !3, !noalias !4
  %v5180 = load i64, ptr %slot843, align 8
  %v5181 = load i64, ptr %slot846, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  store i64 %v5180, ptr %p5182, align 8, !alias.scope !9999998, !noalias !9999999
  %v5183 = load i64, ptr %slot810, align 8
  %cmp5184 = icmp ne i64 %v5183, 0
  %cv5185 = zext i1 %cmp5184 to i32
  store i32 %cv5185, ptr %slot854, align 8
  %v5186 = load i32, ptr %slot854, align 8
  %cv5187 = zext i32 %v5186 to i64
  %cond5188 = icmp ne i64 %cv5187, 0
  br i1 %cond5188, label %bb_rcspinmark1202, label %bb_rcspindone1202
bb_rcspinmark1202:
  %v5189 = load i64, ptr %slot810, align 8
  %op5190 = sub i64 %v5189, 16
  store i64 %op5190, ptr %slot855, align 8
  %v5191 = load i64, ptr %slot810, align 8
  %p5192 = inttoptr i64 %v5191 to ptr
  %rgep5193 = getelementptr i8, ptr %p5192, i64 -16
  %ld5194 = load i64, ptr %rgep5193, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5194, ptr %slot856, align 8
  %v5195 = load i64, ptr %slot856, align 8
  %op5196 = and i64 %v5195, 2
  store i64 %op5196, ptr %slot857, align 8
  %v5197 = load i64, ptr %slot857, align 8
  %cmp5198 = icmp ne i64 %v5197, 0
  %cv5199 = zext i1 %cmp5198 to i32
  store i32 %cv5199, ptr %slot858, align 8
  %v5200 = load i32, ptr %slot858, align 8
  %cv5201 = zext i32 %v5200 to i64
  %cond5202 = icmp ne i64 %cv5201, 0
  br i1 %cond5202, label %bb_rcspindone1202, label %bb_rcspintype1202
bb_rcspintype1202:
  %v5203 = load i64, ptr %slot856, align 8
  %op5204 = and i64 %v5203, 4611686018427387907
  store i64 %op5204, ptr %slot859, align 8
  %v5205 = load i64, ptr %slot859, align 8
  %cmp5206 = icmp eq i64 %v5205, 0
  %cv5207 = zext i1 %cmp5206 to i32
  store i32 %cv5207, ptr %slot860, align 8
  %v5208 = load i32, ptr %slot860, align 8
  %cv5209 = zext i32 %v5208 to i64
  %cond5210 = icmp ne i64 %cv5209, 0
  br i1 %cond5210, label %bb_rcs1210, label %bb_rcspinslow1202
bb_rcs1210:
  %v5211 = load i64, ptr %slot810, align 8
  %op5212 = sub i64 %v5211, 8
  store i64 %op5212, ptr %slot861, align 8
  %v5213 = load i64, ptr %slot810, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %rgep5215 = getelementptr i8, ptr %p5214, i64 -8
  %ld5216 = load i64, ptr %rgep5215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5216, ptr %slot862, align 8
  %p5217 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld5218 = load i64, ptr %p5217, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5218, ptr %slot863, align 8
  %v5219 = load i64, ptr %slot862, align 8
  %v5220 = load i64, ptr %slot863, align 8
  %cmp5221 = icmp eq i64 %v5219, %v5220
  %cv5222 = zext i1 %cmp5221 to i32
  store i32 %cv5222, ptr %slot864, align 8
  %v5223 = load i32, ptr %slot864, align 8
  %cv5224 = zext i32 %v5223 to i64
  %cond5225 = icmp ne i64 %cv5224, 0
  br i1 %cond5225, label %bb_rcs1215, label %bb_rcspinslow1202
bb_rcs1215:
  %v5226 = load i64, ptr %slot71, align 8
  %p5228 = inttoptr i64 %v5226 to ptr
  %gep5229 = getelementptr i8, ptr %p5228, i64 5640
  %op5227 = ptrtoint ptr %gep5229 to i64
  store i64 %op5227, ptr %slot865, align 8
  %v5230 = load i64, ptr %slot865, align 8
  %p5231 = inttoptr i64 %v5230 to ptr
  %ld5232 = load i64, ptr %p5231, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5232, ptr %slot866, align 8
  %v5233 = load i64, ptr %slot866, align 8
  %op5234 = add i64 %v5233, 256
  store i64 %op5234, ptr %slot867, align 8
  %v5235 = load i64, ptr %slot867, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %ld5237 = load i64, ptr %p5236, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5237, ptr %slot868, align 8
  %v5238 = load i64, ptr %slot868, align 8
  %cmp5239 = icmp ne i64 %v5238, 0
  %cv5240 = zext i1 %cmp5239 to i32
  store i32 %cv5240, ptr %slot869, align 8
  %v5241 = load i32, ptr %slot869, align 8
  %cv5242 = zext i32 %v5241 to i64
  %cond5243 = icmp ne i64 %cv5242, 0
  br i1 %cond5243, label %bb_rcs1221, label %bb_rcspinslow1202
bb_rcs1221:
  %v5244 = load i64, ptr %slot71, align 8
  %p5246 = inttoptr i64 %v5244 to ptr
  %gep5247 = getelementptr i8, ptr %p5246, i64 24
  %op5245 = ptrtoint ptr %gep5247 to i64
  store i64 %op5245, ptr %slot870, align 8
  %v5248 = load i64, ptr %slot870, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  %ld5250 = load i64, ptr %p5249, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5250, ptr %slot871, align 8
  %v5251 = load i64, ptr %slot871, align 8
  %op5252 = add i64 %v5251, 40
  store i64 %op5252, ptr %slot872, align 8
  %v5253 = load i64, ptr %slot872, align 8
  %v5254 = load i64, ptr %slot871, align 8
  %cmp5255 = icmp uge i64 %v5253, %v5254
  %cv5256 = zext i1 %cmp5255 to i32
  store i32 %cv5256, ptr %slot873, align 8
  %v5257 = load i32, ptr %slot873, align 8
  %cv5258 = zext i32 %v5257 to i64
  %cond5259 = icmp ne i64 %cv5258, 0
  br i1 %cond5259, label %bb_rcs1226, label %bb_rcspinslow1202
bb_rcs1226:
  %v5260 = load i64, ptr %slot71, align 8
  %p5262 = inttoptr i64 %v5260 to ptr
  %gep5263 = getelementptr i8, ptr %p5262, i64 88
  %op5261 = ptrtoint ptr %gep5263 to i64
  store i64 %op5261, ptr %slot874, align 8
  %v5264 = load i64, ptr %slot874, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  %ld5266 = load i64, ptr %p5265, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5266, ptr %slot875, align 8
  %v5267 = load i64, ptr %slot875, align 8
  %cmp5268 = icmp eq i64 %v5267, 0
  %cv5269 = zext i1 %cmp5268 to i32
  store i32 %cv5269, ptr %slot876, align 8
  %v5270 = load i64, ptr %slot872, align 8
  %v5271 = load i64, ptr %slot875, align 8
  %cmp5272 = icmp ule i64 %v5270, %v5271
  %cv5273 = zext i1 %cmp5272 to i32
  store i32 %cv5273, ptr %slot877, align 8
  %v5274 = load i32, ptr %slot876, align 8
  %v5275 = load i32, ptr %slot877, align 8
  %op5276 = or i32 %v5274, %v5275
  store i32 %op5276, ptr %slot878, align 8
  %v5277 = load i32, ptr %slot878, align 8
  %cv5278 = zext i32 %v5277 to i64
  %cond5279 = icmp ne i64 %cv5278, 0
  br i1 %cond5279, label %bb_rcs1232, label %bb_rcspinslow1202
bb_rcs1232:
  %v5280 = load i64, ptr %slot810, align 8
  %op5281 = sub i64 %v5280, 24
  store i64 %op5281, ptr %slot879, align 8
  %v5282 = load i64, ptr %slot810, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  %rgep5284 = getelementptr i8, ptr %p5283, i64 -24
  %ld5285 = load i64, ptr %rgep5284, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5285, ptr %slot880, align 8
  %v5286 = load i64, ptr %slot880, align 8
  %cmp5287 = icmp ne i64 %v5286, 18446744073709551615
  %cv5288 = zext i1 %cmp5287 to i32
  store i32 %cv5288, ptr %slot881, align 8
  %v5289 = load i32, ptr %slot881, align 8
  %cv5290 = zext i32 %v5289 to i64
  %cond5291 = icmp ne i64 %cv5290, 0
  br i1 %cond5291, label %bb_rcs1236, label %bb_rcspinslow1202
bb_rcs1236:
  %v5292 = load i64, ptr %slot810, align 8
  %op5293 = add i64 %v5292, 32
  store i64 %op5293, ptr %slot882, align 8
  %v5294 = load i64, ptr %slot882, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %ld5296 = load i64, ptr %p5295, align 8
  store i64 %ld5296, ptr %slot883, align 8
  %v5297 = load i64, ptr %slot883, align 8
  %cmp5298 = icmp ne i64 %v5297, 0
  %cv5299 = zext i1 %cmp5298 to i32
  store i32 %cv5299, ptr %slot884, align 8
  %v5300 = load i32, ptr %slot884, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcspinbacking1202, label %bb_rcspincommit1202
bb_rcspinbacking1202:
  %v5303 = load i64, ptr %slot883, align 8
  %op5304 = sub i64 %v5303, 16
  store i64 %op5304, ptr %slot885, align 8
  %v5305 = load i64, ptr %slot883, align 8
  %p5306 = inttoptr i64 %v5305 to ptr
  %rgep5307 = getelementptr i8, ptr %p5306, i64 -16
  %ld5308 = load i64, ptr %rgep5307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5308, ptr %slot886, align 8
  %v5309 = load i64, ptr %slot886, align 8
  %op5310 = and i64 %v5309, 4611686018427387907
  store i64 %op5310, ptr %slot887, align 8
  %v5311 = load i64, ptr %slot887, align 8
  %cmp5312 = icmp eq i64 %v5311, 0
  %cv5313 = zext i1 %cmp5312 to i32
  store i32 %cv5313, ptr %slot888, align 8
  %v5314 = load i32, ptr %slot888, align 8
  %cv5315 = zext i32 %v5314 to i64
  %cond5316 = icmp ne i64 %cv5315, 0
  br i1 %cond5316, label %bb_rcs1244, label %bb_rcspinslow1202
bb_rcs1244:
  %v5317 = load i64, ptr %slot883, align 8
  %op5318 = sub i64 %v5317, 24
  store i64 %op5318, ptr %slot889, align 8
  %v5319 = load i64, ptr %slot883, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %rgep5321 = getelementptr i8, ptr %p5320, i64 -24
  %ld5322 = load i64, ptr %rgep5321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5322, ptr %slot890, align 8
  %v5323 = load i64, ptr %slot890, align 8
  %cmp5324 = icmp ne i64 %v5323, 18446744073709551615
  %cv5325 = zext i1 %cmp5324 to i32
  store i32 %cv5325, ptr %slot891, align 8
  %v5326 = load i32, ptr %slot891, align 8
  %cv5327 = zext i32 %v5326 to i64
  %cond5328 = icmp ne i64 %cv5327, 0
  br i1 %cond5328, label %bb_rcs1248, label %bb_rcspinslow1202
bb_rcs1248:
  br label %bb_rcspincommit1202
bb_rcspincommit1202:
  %v5329 = load i64, ptr %slot868, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i64, ptr %p5330, align 8
  store i64 %ld5331, ptr %slot892, align 8
  %v5332 = load i64, ptr %slot866, align 8
  %op5333 = add i64 %v5332, 256
  store i64 %op5333, ptr %slot893, align 8
  %v5334 = load i64, ptr %slot892, align 8
  %v5335 = load i64, ptr %slot893, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  store i64 %v5334, ptr %p5336, align 8, !alias.scope !9999998, !noalias !9999999
  %v5337 = load i64, ptr %slot866, align 8
  %op5338 = add i64 %v5337, 264
  store i64 %op5338, ptr %slot894, align 8
  %v5339 = load i64, ptr %slot894, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  %ld5341 = load i64, ptr %p5340, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5341, ptr %slot895, align 8
  %v5342 = load i64, ptr %slot895, align 8
  %op5343 = add i64 %v5342, 18446744073709551615
  store i64 %op5343, ptr %slot896, align 8
  %v5344 = load i64, ptr %slot896, align 8
  %v5345 = load i64, ptr %slot894, align 8
  %p5346 = inttoptr i64 %v5345 to ptr
  store i64 %v5344, ptr %p5346, align 8, !alias.scope !9999998, !noalias !9999999
  %v5347 = load i64, ptr %slot71, align 8
  %p5349 = inttoptr i64 %v5347 to ptr
  %gep5350 = getelementptr i8, ptr %p5349, i64 24
  %op5348 = ptrtoint ptr %gep5350 to i64
  store i64 %op5348, ptr %slot897, align 8
  %v5351 = load i64, ptr %slot897, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i64, ptr %p5352, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5353, ptr %slot898, align 8
  %v5354 = load i64, ptr %slot898, align 8
  %op5355 = add i64 %v5354, 40
  store i64 %op5355, ptr %slot899, align 8
  %v5356 = load i64, ptr %slot899, align 8
  %v5357 = load i64, ptr %slot897, align 8
  %p5358 = inttoptr i64 %v5357 to ptr
  store i64 %v5356, ptr %p5358, align 8, !alias.scope !9999998, !noalias !9999999
  %v5359 = load i64, ptr %slot866, align 8
  %op5360 = add i64 %v5359, 48
  store i64 %op5360, ptr %slot900, align 8
  %v5361 = load i64, ptr %slot900, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  %ld5363 = load i64, ptr %p5362, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5363, ptr %slot901, align 8
  %v5364 = load i64, ptr %slot901, align 8
  %op5365 = add i64 %v5364, 40
  store i64 %op5365, ptr %slot902, align 8
  %v5366 = load i64, ptr %slot902, align 8
  %v5367 = load i64, ptr %slot900, align 8
  %p5368 = inttoptr i64 %v5367 to ptr
  store i64 %v5366, ptr %p5368, align 8, !alias.scope !9999998, !noalias !9999999
  %v5369 = load i64, ptr %slot810, align 8
  %op5370 = sub i64 %v5369, 24
  store i64 %op5370, ptr %slot903, align 8
  %v5371 = load i64, ptr %slot810, align 8
  %p5372 = inttoptr i64 %v5371 to ptr
  %rgep5373 = getelementptr i8, ptr %p5372, i64 -24
  %ld5374 = load i64, ptr %rgep5373, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5374, ptr %slot904, align 8
  %v5375 = load i64, ptr %slot904, align 8
  %op5376 = add i64 %v5375, 1
  store i64 %op5376, ptr %slot905, align 8
  %v5377 = load i64, ptr %slot905, align 8
  %v5378 = load i64, ptr %slot810, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  %rgep5380 = getelementptr i8, ptr %p5379, i64 -24
  store i64 %v5377, ptr %rgep5380, align 8, !alias.scope !9, !noalias !10
  %v5381 = load i64, ptr %slot883, align 8
  %cmp5382 = icmp ne i64 %v5381, 0
  %cv5383 = zext i1 %cmp5382 to i32
  store i32 %cv5383, ptr %slot906, align 8
  %v5384 = load i32, ptr %slot906, align 8
  %cv5385 = zext i32 %v5384 to i64
  %cond5386 = icmp ne i64 %cv5385, 0
  br i1 %cond5386, label %bb_rcspinhold1202, label %bb_rcspinjournal1202
bb_rcspinhold1202:
  %v5387 = load i64, ptr %slot883, align 8
  %op5388 = sub i64 %v5387, 24
  store i64 %op5388, ptr %slot907, align 8
  %v5389 = load i64, ptr %slot883, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  %rgep5391 = getelementptr i8, ptr %p5390, i64 -24
  %ld5392 = load i64, ptr %rgep5391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5392, ptr %slot908, align 8
  %v5393 = load i64, ptr %slot908, align 8
  %op5394 = add i64 %v5393, 1
  store i64 %op5394, ptr %slot909, align 8
  %v5395 = load i64, ptr %slot909, align 8
  %v5396 = load i64, ptr %slot883, align 8
  %p5397 = inttoptr i64 %v5396 to ptr
  %rgep5398 = getelementptr i8, ptr %p5397, i64 -24
  store i64 %v5395, ptr %rgep5398, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal1202
bb_rcspinjournal1202:
  %v5399 = load i64, ptr %slot856, align 8
  %op5400 = and i64 %v5399, 1152921504606846976
  store i64 %op5400, ptr %slot910, align 8
  %v5401 = load i64, ptr %slot856, align 8
  %op5402 = or i64 %v5401, 1152921504606846976
  store i64 %op5402, ptr %slot911, align 8
  %v5403 = load i64, ptr %slot810, align 8
  %op5404 = sub i64 %v5403, 16
  store i64 %op5404, ptr %slot912, align 8
  %v5405 = load i64, ptr %slot911, align 8
  %v5406 = load i64, ptr %slot810, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  %rgep5408 = getelementptr i8, ptr %p5407, i64 -16
  store i64 %v5405, ptr %rgep5408, align 8, !alias.scope !9, !noalias !10
  %v5409 = load i64, ptr %slot843, align 8
  %p5411 = inttoptr i64 %v5409 to ptr
  %gep5412 = getelementptr i8, ptr %p5411, i64 16
  %op5410 = ptrtoint ptr %gep5412 to i64
  store i64 %op5410, ptr %slot913, align 8
  %v5413 = load i64, ptr %slot913, align 8
  %p5414 = inttoptr i64 %v5413 to ptr
  %ld5415 = load i64, ptr %p5414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5415, ptr %slot914, align 8
  %v5416 = load i64, ptr %slot868, align 8
  %op5417 = add i64 %v5416, 0
  store i64 %op5417, ptr %slot915, align 8
  %v5418 = load i64, ptr %slot914, align 8
  %v5419 = load i64, ptr %slot915, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  store i64 %v5418, ptr %p5420, align 8, !alias.scope !9999998, !noalias !9999999
  %v5421 = load i64, ptr %slot868, align 8
  %op5422 = add i64 %v5421, 8
  store i64 %op5422, ptr %slot916, align 8
  %v5423 = load i64, ptr %slot810, align 8
  %v5424 = load i64, ptr %slot916, align 8
  %p5425 = inttoptr i64 %v5424 to ptr
  store i64 %v5423, ptr %p5425, align 8, !alias.scope !9999998, !noalias !9999999
  %v5426 = load i64, ptr %slot868, align 8
  %op5427 = add i64 %v5426, 16
  store i64 %op5427, ptr %slot917, align 8
  %v5428 = load i64, ptr %slot910, align 8
  %v5429 = load i64, ptr %slot917, align 8
  %p5430 = inttoptr i64 %v5429 to ptr
  store i64 %v5428, ptr %p5430, align 8, !alias.scope !9999998, !noalias !9999999
  %v5431 = load i64, ptr %slot868, align 8
  %op5432 = add i64 %v5431, 24
  store i64 %op5432, ptr %slot918, align 8
  %v5433 = load i64, ptr %slot918, align 8
  %p5434 = inttoptr i64 %v5433 to ptr
  store i32 1, ptr %p5434, align 4, !alias.scope !9999998, !noalias !9999999
  %v5435 = load i64, ptr %slot868, align 8
  %op5436 = add i64 %v5435, 32
  store i64 %op5436, ptr %slot919, align 8
  %v5437 = load i64, ptr %slot883, align 8
  %v5438 = load i64, ptr %slot919, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  store i64 %v5437, ptr %p5439, align 8, !alias.scope !9999998, !noalias !9999999
  %v5440 = load i64, ptr %slot843, align 8
  %p5442 = inttoptr i64 %v5440 to ptr
  %gep5443 = getelementptr i8, ptr %p5442, i64 16
  %op5441 = ptrtoint ptr %gep5443 to i64
  store i64 %op5441, ptr %slot920, align 8
  %v5444 = load i64, ptr %slot868, align 8
  %v5445 = load i64, ptr %slot920, align 8
  %p5446 = inttoptr i64 %v5445 to ptr
  store i64 %v5444, ptr %p5446, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone1202
bb_rcspinslow1202:
  %v5447 = load i64, ptr %slot1, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  %v5449 = load i64, ptr %slot843, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  %v5451 = load i64, ptr %slot810, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  %call5453 = call i32 @myl_qbe_rc_scope_pin(ptr %p5448, ptr %p5450, ptr %p5452) nomerge, !dbg !186
  store i32 %call5453, ptr %slot921, align 8
  %v5454 = load i32, ptr %slot921, align 8
  %cv5455 = zext i32 %v5454 to i64
  %cond5456 = icmp ne i64 %cv5455, 0
  br i1 %cond5456, label %bb_rcunique1279, label %bb_failure
bb_rcunique1279:
  br label %bb_rcspindone1202
bb_rcspindone1202:
  %v5457 = load i64, ptr %slot810, align 8
  %v5458 = load i64, ptr %slot51, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  store i64 %v5457, ptr %p5459, align 8, !alias.scope !3, !noalias !4
  %v5460 = load i64, ptr %slot35, align 8
  %p5461 = inttoptr i64 %v5460 to ptr
  %ld5462 = load i64, ptr %p5461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5462, ptr %slot922, align 8
  %v5463 = load i64, ptr %slot922, align 8
  %v5464 = load i64, ptr %slot58, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i64 %v5463, ptr %p5465, align 8, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot58, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %ld5468 = load i64, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5468, ptr %slot923, align 8
  %v5469 = load i64, ptr %slot923, align 8
  %v5470 = load i64, ptr %slot53, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  store i64 %v5469, ptr %p5471, align 8, !alias.scope !3, !noalias !4
  %v5472 = load i64, ptr %slot53, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  %ld5474 = load i64, ptr %p5473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5474, ptr %slot924, align 8
  %v5475 = load i64, ptr %slot924, align 8
  %v5476 = load i64, ptr %slot58, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  store i64 %v5475, ptr %p5477, align 8, !alias.scope !3, !noalias !4
  %v5478 = load i64, ptr %slot59, align 8
  %p5479 = inttoptr i64 %v5478 to ptr
  store i64 0, ptr %p5479, align 8, !alias.scope !3, !noalias !4
  %v5480 = load i64, ptr %slot59, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  %ld5482 = load i64, ptr %p5481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5482, ptr %slot925, align 8
  %v5483 = load i64, ptr %slot58, align 8
  %p5484 = inttoptr i64 %v5483 to ptr
  %ld5485 = load i64, ptr %p5484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5485, ptr %slot926, align 8
  %v5486 = load i64, ptr %slot926, align 8
  %v5487 = load i64, ptr %slot925, align 8
  %cmp5488 = icmp slt i64 %v5486, %v5487
  %cv5489 = zext i1 %cmp5488 to i64
  store i64 %cv5489, ptr %slot927, align 8
  %v5490 = load i64, ptr %slot927, align 8
  %v5491 = load i64, ptr %slot58, align 8
  %p5492 = inttoptr i64 %v5491 to ptr
  store i64 %v5490, ptr %p5492, align 8, !alias.scope !3, !noalias !4
  %v5493 = load i64, ptr %slot58, align 8
  %p5494 = inttoptr i64 %v5493 to ptr
  %ld5495 = load i64, ptr %p5494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5495, ptr %slot928, align 8
  %v5496 = load i64, ptr %slot928, align 8
  %cond5497 = icmp ne i64 %v5496, 0
  br i1 %cond5497, label %bb_next1287, label %bb_i130
bb_next1287:
  %v5498 = load i64, ptr %slot51, align 8
  %p5499 = inttoptr i64 %v5498 to ptr
  %ld5500 = load i64, ptr %p5499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5500, ptr %slot929, align 8
  %v5501 = load i64, ptr %slot929, align 8
  %op5502 = add i64 %v5501, 0
  store i64 %op5502, ptr %slot930, align 8
  %v5503 = load i64, ptr %slot930, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  %ld5505 = load i64, ptr %p5504, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5505, ptr %slot931, align 8
  %v5506 = load i64, ptr %slot931, align 8
  %v5507 = load i64, ptr %slot58, align 8
  %p5508 = inttoptr i64 %v5507 to ptr
  store i64 %v5506, ptr %p5508, align 8, !alias.scope !3, !noalias !4
  %v5509 = load i64, ptr %slot58, align 8
  %p5510 = inttoptr i64 %v5509 to ptr
  %ld5511 = load i64, ptr %p5510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5511, ptr %slot932, align 8
  %v5512 = load i64, ptr %slot932, align 8
  %cmp5513 = icmp ugt i64 %v5512, 9223372036854775807
  %cv5514 = zext i1 %cmp5513 to i64
  store i64 %cv5514, ptr %slot933, align 8
  %v5515 = load i64, ptr %slot933, align 8
  %cond5516 = icmp ne i64 %v5515, 0
  br i1 %cond5516, label %bb_cast_overflow1292, label %bb_cast_ok1292
bb_cast_overflow1292:
  %v5517 = load i64, ptr %slot1, align 8
  %p5518 = inttoptr i64 %v5517 to ptr
  %v5519 = load i64, ptr %slot932, align 8
  call void @myl_qbe_fail_cast(ptr %p5518, i64 %v5519, i64 320) nomerge, !dbg !188
  unreachable
bb_cast_ok1292:
  %v5520 = load i64, ptr %slot932, align 8
  %v5521 = load i64, ptr %slot58, align 8
  %p5522 = inttoptr i64 %v5521 to ptr
  store i64 %v5520, ptr %p5522, align 8, !alias.scope !3, !noalias !4
  %v5523 = load i64, ptr %slot53, align 8
  %p5524 = inttoptr i64 %v5523 to ptr
  %ld5525 = load i64, ptr %p5524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5525, ptr %slot934, align 8
  %v5526 = load i64, ptr %slot934, align 8
  %v5527 = load i64, ptr %slot59, align 8
  %p5528 = inttoptr i64 %v5527 to ptr
  store i64 %v5526, ptr %p5528, align 8, !alias.scope !3, !noalias !4
  %v5529 = load i64, ptr %slot59, align 8
  %p5530 = inttoptr i64 %v5529 to ptr
  %ld5531 = load i64, ptr %p5530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5531, ptr %slot935, align 8
  %v5532 = load i64, ptr %slot58, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  %ld5534 = load i64, ptr %p5533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5534, ptr %slot936, align 8
  %v5535 = load i64, ptr %slot936, align 8
  %v5536 = load i64, ptr %slot935, align 8
  %ovpair5538 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5535, i64 %v5536)
  %op5537 = extractvalue { i64, i1 } %ovpair5538, 0
  %ov5539 = extractvalue { i64, i1 } %ovpair5538, 1
  store i64 %op5537, ptr %slot937, align 8
  %v5540 = load i64, ptr %slot936, align 8
  %v5541 = load i64, ptr %slot937, align 8
  %op5542 = xor i64 %v5540, %v5541
  store i64 %op5542, ptr %slot938, align 8
  %v5543 = load i64, ptr %slot935, align 8
  %v5544 = load i64, ptr %slot937, align 8
  %op5545 = xor i64 %v5543, %v5544
  store i64 %op5545, ptr %slot939, align 8
  %v5546 = load i64, ptr %slot938, align 8
  %v5547 = load i64, ptr %slot939, align 8
  %op5548 = and i64 %v5546, %v5547
  store i64 %op5548, ptr %slot940, align 8
  %cv5549 = zext i1 %ov5539 to i64
  store i64 %cv5549, ptr %slot941, align 8
  %v5550 = load i64, ptr %slot941, align 8
  %cond5551 = icmp ne i64 %v5550, 0
  br i1 %cond5551, label %bb_overflow1296, label %bb_checked1296
bb_overflow1296:
  %v5552 = load i64, ptr %slot1, align 8
  %p5553 = inttoptr i64 %v5552 to ptr
  %v5554 = load i64, ptr %slot936, align 8
  %v5555 = load i64, ptr %slot935, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5553, i64 0, i64 %v5554, i64 %v5555, i64 64) nomerge, !dbg !190
  unreachable
bb_checked1296:
  %v5556 = load i64, ptr %slot937, align 8
  %v5557 = load i64, ptr %slot58, align 8
  %p5558 = inttoptr i64 %v5557 to ptr
  store i64 %v5556, ptr %p5558, align 8, !alias.scope !3, !noalias !4
  %v5559 = load i64, ptr %slot58, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %ld5561 = load i64, ptr %p5560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5561, ptr %slot942, align 8
  %v5562 = load i64, ptr %slot942, align 8
  %v5563 = load i64, ptr %slot53, align 8
  %p5564 = inttoptr i64 %v5563 to ptr
  store i64 %v5562, ptr %p5564, align 8, !alias.scope !3, !noalias !4
  br label %bb_i130
bb_i130:
  %v5565 = load i64, ptr %slot53, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %ld5567 = load i64, ptr %p5566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5567, ptr %slot943, align 8
  %v5568 = load i64, ptr %slot943, align 8
  %v5569 = load i64, ptr %slot58, align 8
  %p5570 = inttoptr i64 %v5569 to ptr
  store i64 %v5568, ptr %p5570, align 8, !alias.scope !3, !noalias !4
  %v5571 = load i64, ptr %slot58, align 8
  %p5572 = inttoptr i64 %v5571 to ptr
  %ld5573 = load i64, ptr %p5572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5573, ptr %slot944, align 8
  %v5574 = load i64, ptr %slot944, align 8
  %v5575 = load i64, ptr %slot52, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  store i64 %v5574, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  %v5577 = load i64, ptr %slot52, align 8
  %p5578 = inttoptr i64 %v5577 to ptr
  %ld5579 = load i64, ptr %p5578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5579, ptr %slot945, align 8
  %v5580 = load i64, ptr %slot945, align 8
  %v5581 = load i64, ptr %slot58, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  store i64 %v5580, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  %v5583 = load i64, ptr %slot51, align 8
  %p5584 = inttoptr i64 %v5583 to ptr
  %ld5585 = load i64, ptr %p5584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5585, ptr %slot946, align 8
  %v5586 = load i64, ptr %slot58, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i64, ptr %p5587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5588, ptr %slot947, align 8
  %v5589 = load i64, ptr %slot946, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %ld5591 = load i64, ptr %p5590, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5591, ptr %slot948, align 8
  %v5592 = load i64, ptr %slot947, align 8
  %v5593 = load i64, ptr %slot948, align 8
  %cmp5594 = icmp ult i64 %v5592, %v5593
  %cv5595 = zext i1 %cmp5594 to i64
  store i64 %cv5595, ptr %slot949, align 8
  %v5596 = load i64, ptr %slot949, align 8
  %cond5597 = icmp ne i64 %v5596, 0
  br i1 %cond5597, label %bb_success1310, label %bb_failed1310
bb_failed1310:
  %v5598 = load i64, ptr %slot1, align 8
  %p5599 = inttoptr i64 %v5598 to ptr
  %v5600 = load i64, ptr %slot947, align 8
  %v5601 = load i64, ptr %slot948, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5599, i64 %v5600, i64 %v5601) nomerge, !dbg !192
  unreachable
bb_success1310:
  %v5602 = load i64, ptr %slot946, align 8
  %op5603 = add i64 %v5602, 32
  store i64 %op5603, ptr %slot950, align 8
  %v5604 = load i64, ptr %slot950, align 8
  %p5605 = inttoptr i64 %v5604 to ptr
  %ld5606 = load i64, ptr %p5605, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5606, ptr %slot951, align 8
  %v5607 = load i64, ptr %slot947, align 8
  %op5608 = mul i64 %v5607, 80
  store i64 %op5608, ptr %slot952, align 8
  %v5609 = load i64, ptr %slot951, align 8
  %v5610 = load i64, ptr %slot952, align 8
  %op5611 = add i64 %v5609, %v5610
  store i64 %op5611, ptr %slot953, align 8
  %v5612 = load i64, ptr %slot953, align 8
  %v5613 = load i64, ptr %slot58, align 8
  %p5614 = inttoptr i64 %v5613 to ptr
  store i64 %v5612, ptr %p5614, align 8, !alias.scope !3, !noalias !4
  %v5615 = load i64, ptr %slot58, align 8
  %p5616 = inttoptr i64 %v5615 to ptr
  %ld5617 = load i64, ptr %p5616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5617, ptr %slot954, align 8
  %v5618 = load i64, ptr %slot30, align 8
  store i64 %v5618, ptr %slot955, align 8
  %v5619 = load i64, ptr %slot71, align 8
  %v5620 = load i64, ptr %slot955, align 8
  %v5621 = load i64, ptr %slot954, align 8
  %call5622 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v5619, i64 %v5620, i64 %v5621) nomerge, !dbg !192
  store i32 %call5622, ptr %slot956, align 8
  %v5623 = load i32, ptr %slot956, align 8
  %cv5624 = zext i32 %v5623 to i64
  %cond5625 = icmp ne i64 %cv5624, 0
  br i1 %cond5625, label %bb_rcsuccess1318, label %bb_rcfailure1318
bb_rcfailure1318:
  %v5626 = load i64, ptr %slot71, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  %call5628 = call i32 @myl_rc_take_failure(ptr %p5627) nomerge, !dbg !192
  store i32 %call5628, ptr %slot957, align 8
  %v5629 = load i64, ptr %slot1, align 8
  %p5630 = inttoptr i64 %v5629 to ptr
  %v5631 = load i32, ptr %slot957, align 8
  %call5632 = call i32 @myl_qbe_rc_status(ptr %p5630, i32 %v5631) nomerge, !dbg !192
  store i32 %call5632, ptr %slot958, align 8
  br label %bb_failure
bb_rcsuccess1318:
  %v5633 = load i64, ptr %slot25, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  store i32 2, ptr %p5634, align 4, !alias.scope !3, !noalias !4
  %v5635 = load i64, ptr %slot25, align 8
  %p5636 = inttoptr i64 %v5635 to ptr
  store i32 16, ptr %p5636, align 4, !alias.scope !3, !noalias !4
  %v5637 = load i64, ptr %slot24, align 8
  %p5638 = inttoptr i64 %v5637 to ptr
  store i32 1, ptr %p5638, align 4, !alias.scope !3, !noalias !4
  %v5639 = load i64, ptr %slot27, align 8
  store i64 %v5639, ptr %slot959, align 8
  %v5640 = load i64, ptr %slot30, align 8
  store i64 %v5640, ptr %slot960, align 8
  %v5641 = load i64, ptr %slot960, align 8
  %v5642 = load i64, ptr %slot959, align 8
  %p5643 = inttoptr i64 %v5641 to ptr
  %p5644 = inttoptr i64 %v5642 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5644, ptr %p5643, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v5645 = load i64, ptr %slot21, align 8
  %p5646 = inttoptr i64 %v5645 to ptr
  store i32 2, ptr %p5646, align 4, !alias.scope !3, !noalias !4
  %v5647 = load i64, ptr %slot25, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  %ld5649 = load i32, ptr %p5648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5649, ptr %slot961, align 8
  %v5650 = load i32, ptr %slot961, align 8
  %v5651 = load i64, ptr %slot21, align 8
  %p5652 = inttoptr i64 %v5651 to ptr
  store i32 %v5650, ptr %p5652, align 4, !alias.scope !3, !noalias !4
  %v5653 = load i64, ptr %slot24, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  store i32 0, ptr %p5654, align 4, !alias.scope !3, !noalias !4
  %v5655 = load i64, ptr %slot20, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  store i32 1, ptr %p5656, align 4, !alias.scope !3, !noalias !4
  %v5657 = load i64, ptr %slot959, align 8
  %v5658 = load i64, ptr %slot58, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  store i64 %v5657, ptr %p5659, align 8, !alias.scope !3, !noalias !4
  %v5660 = load i64, ptr %slot58, align 8
  %p5661 = inttoptr i64 %v5660 to ptr
  %ld5662 = load i64, ptr %p5661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5662, ptr %slot962, align 8
  %v5663 = load i64, ptr %slot20, align 8
  %p5664 = inttoptr i64 %v5663 to ptr
  %ld5665 = load i32, ptr %p5664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5665, ptr %slot963, align 8
  %v5666 = load i64, ptr %slot21, align 8
  %p5667 = inttoptr i64 %v5666 to ptr
  %ld5668 = load i32, ptr %p5667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5668, ptr %slot964, align 8
  %v5669 = load i32, ptr %slot964, align 8
  %op5670 = and i32 %v5669, 24
  store i32 %op5670, ptr %slot964, align 8
  %v5671 = load i32, ptr %slot964, align 8
  %cmp5672 = icmp eq i32 %v5671, 0
  %cv5673 = zext i1 %cmp5672 to i32
  store i32 %cv5673, ptr %slot965, align 8
  %v5674 = load i32, ptr %slot963, align 8
  %v5675 = load i32, ptr %slot965, align 8
  %op5676 = and i32 %v5674, %v5675
  store i32 %op5676, ptr %slot966, align 8
  %v5677 = load i32, ptr %slot966, align 8
  %cv5678 = zext i32 %v5677 to i64
  %cond5679 = icmp ne i64 %cv5678, 0
  br i1 %cond5679, label %bb_rcprivateown1339, label %bb_rcprivateloan1339
bb_rcprivateown1339:
  %v5680 = load i64, ptr %slot30, align 8
  store i64 %v5680, ptr %slot967, align 8
  %v5681 = load i64, ptr %slot72, align 8
  store i64 %v5681, ptr %slot968, align 8
  %v5682 = load i64, ptr %slot71, align 8
  %v5683 = load i64, ptr %slot967, align 8
  %v5684 = load i64, ptr %slot962, align 8
  %v5685 = load i64, ptr %slot968, align 8
  %cv5686 = trunc i64 %v5685 to i32
  %call5687 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64 %v5682, i64 %v5683, i64 %v5684, i32 %cv5686) nomerge, !dbg !194
  store i32 %call5687, ptr %slot969, align 8
  %v5688 = load i32, ptr %slot969, align 8
  %cv5689 = zext i32 %v5688 to i64
  %cond5690 = icmp ne i64 %cv5689, 0
  br i1 %cond5690, label %bb_rcsuccess1343, label %bb_rcfailure1343
bb_rcfailure1343:
  %v5691 = load i64, ptr %slot71, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  %call5693 = call i32 @myl_rc_take_failure(ptr %p5692) nomerge, !dbg !194
  store i32 %call5693, ptr %slot970, align 8
  %v5694 = load i64, ptr %slot1, align 8
  %p5695 = inttoptr i64 %v5694 to ptr
  %v5696 = load i32, ptr %slot970, align 8
  %call5697 = call i32 @myl_qbe_rc_status(ptr %p5695, i32 %v5696) nomerge, !dbg !194
  store i32 %call5697, ptr %slot971, align 8
  br label %bb_failure
bb_rcsuccess1343:
  %v5698 = load i64, ptr %slot20, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  store i32 0, ptr %p5699, align 4, !alias.scope !3, !noalias !4
  %v5700 = load i64, ptr %slot25, align 8
  %p5701 = inttoptr i64 %v5700 to ptr
  store i32 2, ptr %p5701, align 4, !alias.scope !3, !noalias !4
  %v5702 = load i64, ptr %slot24, align 8
  %p5703 = inttoptr i64 %v5702 to ptr
  store i32 1, ptr %p5703, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1339
bb_rcprivateloan1339:
  %v5704 = load i64, ptr %slot20, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  %ld5706 = load i32, ptr %p5705, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5706, ptr %slot972, align 8
  %v5707 = load i64, ptr %slot21, align 8
  %p5708 = inttoptr i64 %v5707 to ptr
  %ld5709 = load i32, ptr %p5708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5709, ptr %slot973, align 8
  %v5710 = load i32, ptr %slot973, align 8
  %cmp5711 = icmp eq i32 %v5710, 16
  %cv5712 = zext i1 %cmp5711 to i32
  store i32 %cv5712, ptr %slot974, align 8
  %v5713 = load i32, ptr %slot974, align 8
  %v5714 = load i32, ptr %slot972, align 8
  %op5715 = and i32 %v5713, %v5714
  store i32 %op5715, ptr %slot974, align 8
  %v5716 = load i32, ptr %slot974, align 8
  %cv5717 = zext i32 %v5716 to i64
  %cond5718 = icmp ne i64 %cv5717, 0
  br i1 %cond5718, label %bb_rcprivatemove1339, label %bb_rcprivatenew1339
bb_rcprivatemove1339:
  %v5719 = load i64, ptr %slot30, align 8
  store i64 %v5719, ptr %slot975, align 8
  %v5720 = load i64, ptr %slot962, align 8
  %v5721 = load i64, ptr %slot975, align 8
  %p5722 = inttoptr i64 %v5720 to ptr
  %p5723 = inttoptr i64 %v5721 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5723, ptr %p5722, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v5724 = load i64, ptr %slot962, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  call void @llvm.memset.p0.i64(ptr %p5725, i8 0, i64 80, i1 false), !alias.scope !3, !noalias !4, !dbg !194
  %v5726 = load i64, ptr %slot25, align 8
  %p5727 = inttoptr i64 %v5726 to ptr
  store i32 2, ptr %p5727, align 4, !alias.scope !3, !noalias !4
  %v5728 = load i64, ptr %slot25, align 8
  %p5729 = inttoptr i64 %v5728 to ptr
  store i32 16, ptr %p5729, align 4, !alias.scope !3, !noalias !4
  %v5730 = load i64, ptr %slot24, align 8
  %p5731 = inttoptr i64 %v5730 to ptr
  store i32 1, ptr %p5731, align 4, !alias.scope !3, !noalias !4
  %v5732 = load i64, ptr %slot20, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  store i32 0, ptr %p5733, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1339
bb_rcprivatenew1339:
  %v5734 = load i64, ptr %slot30, align 8
  store i64 %v5734, ptr %slot976, align 8
  %v5735 = load i64, ptr %slot71, align 8
  %v5736 = load i64, ptr %slot976, align 8
  %v5737 = load i64, ptr %slot962, align 8
  %call5738 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v5735, i64 %v5736, i64 %v5737) nomerge, !dbg !194
  store i32 %call5738, ptr %slot977, align 8
  %v5739 = load i32, ptr %slot977, align 8
  %cv5740 = zext i32 %v5739 to i64
  %cond5741 = icmp ne i64 %cv5740, 0
  br i1 %cond5741, label %bb_rcsuccess1361, label %bb_rcfailure1361
bb_rcfailure1361:
  %v5742 = load i64, ptr %slot71, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  %call5744 = call i32 @myl_rc_take_failure(ptr %p5743) nomerge, !dbg !194
  store i32 %call5744, ptr %slot978, align 8
  %v5745 = load i64, ptr %slot1, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %v5747 = load i32, ptr %slot978, align 8
  %call5748 = call i32 @myl_qbe_rc_status(ptr %p5746, i32 %v5747) nomerge, !dbg !194
  store i32 %call5748, ptr %slot979, align 8
  br label %bb_failure
bb_rcsuccess1361:
  %v5749 = load i64, ptr %slot25, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  store i32 2, ptr %p5750, align 4, !alias.scope !3, !noalias !4
  %v5751 = load i64, ptr %slot25, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  store i32 16, ptr %p5752, align 4, !alias.scope !3, !noalias !4
  %v5753 = load i64, ptr %slot24, align 8
  %p5754 = inttoptr i64 %v5753 to ptr
  store i32 1, ptr %p5754, align 4, !alias.scope !3, !noalias !4
  %v5755 = load i64, ptr %slot20, align 8
  %p5756 = inttoptr i64 %v5755 to ptr
  %ld5757 = load i32, ptr %p5756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5757, ptr %slot980, align 8
  %v5758 = load i32, ptr %slot980, align 8
  %cv5759 = zext i32 %v5758 to i64
  %cond5760 = icmp ne i64 %cv5759, 0
  br i1 %cond5760, label %bb_rcslotdrop1369, label %bb_rcslotdone1369
bb_rcslotdrop1369:
  %v5761 = load i64, ptr %slot20, align 8
  %p5762 = inttoptr i64 %v5761 to ptr
  store i32 0, ptr %p5762, align 4, !alias.scope !3, !noalias !4
  %v5763 = load i64, ptr %slot27, align 8
  store i64 %v5763, ptr %slot981, align 8
  %v5764 = load i64, ptr %slot21, align 8
  %p5765 = inttoptr i64 %v5764 to ptr
  %ld5766 = load i32, ptr %p5765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5766, ptr %slot982, align 8
  %v5767 = load i32, ptr %slot982, align 8
  %op5768 = and i32 %v5767, 28
  store i32 %op5768, ptr %slot983, align 8
  %v5769 = load i32, ptr %slot983, align 8
  %cv5770 = zext i32 %v5769 to i64
  %cond5771 = icmp ne i64 %cv5770, 0
  br i1 %cond5771, label %bb_rcslotrole1369, label %bb_rcslotowner1369
bb_rcslotrole1369:
  %v5772 = load i64, ptr %slot71, align 8
  store i64 %v5772, ptr %slot984, align 8
  %v5773 = load i64, ptr %slot984, align 8
  %v5774 = load i64, ptr %slot981, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v5773, i64 %v5774) nomerge, !dbg !194
  br label %bb_rcslotdone1369
bb_rcslotowner1369:
  %v5775 = load i64, ptr %slot71, align 8
  store i64 %v5775, ptr %slot985, align 8
  %v5776 = load i64, ptr %slot985, align 8
  %v5777 = load i64, ptr %slot981, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v5776, i64 %v5777) nomerge, !dbg !194
  br label %bb_rcslotdone1369
bb_rcslotdone1369:
  br label %bb_rcprivateprepared1339
bb_rcprivateprepared1339:
  %v5778 = load i64, ptr %slot16, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  %ld5780 = load i32, ptr %p5779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5780, ptr %slot986, align 8
  %v5781 = load i32, ptr %slot986, align 8
  %cv5782 = zext i32 %v5781 to i64
  %cond5783 = icmp ne i64 %cv5782, 0
  br i1 %cond5783, label %bb_rcslotdrop1379, label %bb_rcslotdone1379
bb_rcslotdrop1379:
  %v5784 = load i64, ptr %slot16, align 8
  %p5785 = inttoptr i64 %v5784 to ptr
  store i32 0, ptr %p5785, align 4, !alias.scope !3, !noalias !4
  %v5786 = load i64, ptr %slot54, align 8
  store i64 %v5786, ptr %slot987, align 8
  %v5787 = load i64, ptr %slot17, align 8
  %p5788 = inttoptr i64 %v5787 to ptr
  %ld5789 = load i32, ptr %p5788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5789, ptr %slot988, align 8
  %v5790 = load i32, ptr %slot988, align 8
  %op5791 = and i32 %v5790, 28
  store i32 %op5791, ptr %slot989, align 8
  %v5792 = load i32, ptr %slot989, align 8
  %cv5793 = zext i32 %v5792 to i64
  %cond5794 = icmp ne i64 %cv5793, 0
  br i1 %cond5794, label %bb_rcslotrole1379, label %bb_rcslotowner1379
bb_rcslotrole1379:
  %v5795 = load i64, ptr %slot71, align 8
  store i64 %v5795, ptr %slot990, align 8
  %v5796 = load i64, ptr %slot990, align 8
  %v5797 = load i64, ptr %slot987, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v5796, i64 %v5797) nomerge, !dbg !194
  br label %bb_rcslotdone1379
bb_rcslotowner1379:
  %v5798 = load i64, ptr %slot71, align 8
  store i64 %v5798, ptr %slot991, align 8
  %v5799 = load i64, ptr %slot991, align 8
  %v5800 = load i64, ptr %slot987, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v5799, i64 %v5800) nomerge, !dbg !194
  br label %bb_rcslotdone1379
bb_rcslotdone1379:
  %v5801 = load i64, ptr %slot54, align 8
  store i64 %v5801, ptr %slot992, align 8
  %v5802 = load i64, ptr %slot30, align 8
  store i64 %v5802, ptr %slot993, align 8
  %v5803 = load i64, ptr %slot993, align 8
  %v5804 = load i64, ptr %slot992, align 8
  %p5805 = inttoptr i64 %v5803 to ptr
  %p5806 = inttoptr i64 %v5804 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5806, ptr %p5805, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v5807 = load i64, ptr %slot24, align 8
  %p5808 = inttoptr i64 %v5807 to ptr
  store i32 0, ptr %p5808, align 4, !alias.scope !3, !noalias !4
  %v5809 = load i64, ptr %slot17, align 8
  %p5810 = inttoptr i64 %v5809 to ptr
  store i32 2, ptr %p5810, align 4, !alias.scope !3, !noalias !4
  %v5811 = load i64, ptr %slot25, align 8
  %p5812 = inttoptr i64 %v5811 to ptr
  %ld5813 = load i32, ptr %p5812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5813, ptr %slot994, align 8
  %v5814 = load i32, ptr %slot994, align 8
  %v5815 = load i64, ptr %slot17, align 8
  %p5816 = inttoptr i64 %v5815 to ptr
  store i32 %v5814, ptr %p5816, align 4, !alias.scope !3, !noalias !4
  %v5817 = load i64, ptr %slot16, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i32 1, ptr %p5818, align 4, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot52, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  %ld5821 = load i64, ptr %p5820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5821, ptr %slot995, align 8
  %v5822 = load i64, ptr %slot995, align 8
  %v5823 = load i64, ptr %slot58, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  store i64 %v5822, ptr %p5824, align 8, !alias.scope !3, !noalias !4
  %v5825 = load i64, ptr %slot51, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  %ld5827 = load i64, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5827, ptr %slot996, align 8
  %v5828 = load i64, ptr %slot58, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  %ld5830 = load i64, ptr %p5829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5830, ptr %slot997, align 8
  %v5831 = load i64, ptr %slot996, align 8
  %p5832 = inttoptr i64 %v5831 to ptr
  %ld5833 = load i64, ptr %p5832, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5833, ptr %slot998, align 8
  %v5834 = load i64, ptr %slot997, align 8
  %v5835 = load i64, ptr %slot998, align 8
  %cmp5836 = icmp ult i64 %v5834, %v5835
  %cv5837 = zext i1 %cmp5836 to i64
  store i64 %cv5837, ptr %slot999, align 8
  %v5838 = load i64, ptr %slot999, align 8
  %cond5839 = icmp ne i64 %v5838, 0
  br i1 %cond5839, label %bb_success1399, label %bb_failed1399
bb_failed1399:
  %v5840 = load i64, ptr %slot1, align 8
  %p5841 = inttoptr i64 %v5840 to ptr
  %v5842 = load i64, ptr %slot997, align 8
  %v5843 = load i64, ptr %slot998, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5841, i64 %v5842, i64 %v5843) nomerge, !dbg !196
  unreachable
bb_success1399:
  %v5844 = load i64, ptr %slot996, align 8
  %op5845 = add i64 %v5844, 32
  store i64 %op5845, ptr %slot1000, align 8
  %v5846 = load i64, ptr %slot1000, align 8
  %p5847 = inttoptr i64 %v5846 to ptr
  %ld5848 = load i64, ptr %p5847, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5848, ptr %slot1001, align 8
  %v5849 = load i64, ptr %slot997, align 8
  %op5850 = mul i64 %v5849, 80
  store i64 %op5850, ptr %slot1002, align 8
  %v5851 = load i64, ptr %slot1001, align 8
  %v5852 = load i64, ptr %slot1002, align 8
  %op5853 = add i64 %v5851, %v5852
  store i64 %op5853, ptr %slot1003, align 8
  %v5854 = load i64, ptr %slot1003, align 8
  %v5855 = load i64, ptr %slot58, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  store i64 %v5854, ptr %p5856, align 8, !alias.scope !3, !noalias !4
  %v5857 = load i64, ptr %slot58, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  %ld5859 = load i64, ptr %p5858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5859, ptr %slot1004, align 8
  %v5860 = load i64, ptr %slot30, align 8
  store i64 %v5860, ptr %slot1005, align 8
  %v5861 = load i64, ptr %slot71, align 8
  %v5862 = load i64, ptr %slot1005, align 8
  %v5863 = load i64, ptr %slot1004, align 8
  %call5864 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v5861, i64 %v5862, i64 %v5863) nomerge, !dbg !196
  store i32 %call5864, ptr %slot1006, align 8
  %v5865 = load i32, ptr %slot1006, align 8
  %cv5866 = zext i32 %v5865 to i64
  %cond5867 = icmp ne i64 %cv5866, 0
  br i1 %cond5867, label %bb_rcsuccess1407, label %bb_rcfailure1407
bb_rcfailure1407:
  %v5868 = load i64, ptr %slot71, align 8
  %p5869 = inttoptr i64 %v5868 to ptr
  %call5870 = call i32 @myl_rc_take_failure(ptr %p5869) nomerge, !dbg !196
  store i32 %call5870, ptr %slot1007, align 8
  %v5871 = load i64, ptr %slot1, align 8
  %p5872 = inttoptr i64 %v5871 to ptr
  %v5873 = load i32, ptr %slot1007, align 8
  %call5874 = call i32 @myl_qbe_rc_status(ptr %p5872, i32 %v5873) nomerge, !dbg !196
  store i32 %call5874, ptr %slot1008, align 8
  br label %bb_failure
bb_rcsuccess1407:
  %v5875 = load i64, ptr %slot25, align 8
  %p5876 = inttoptr i64 %v5875 to ptr
  store i32 2, ptr %p5876, align 4, !alias.scope !3, !noalias !4
  %v5877 = load i64, ptr %slot25, align 8
  %p5878 = inttoptr i64 %v5877 to ptr
  store i32 16, ptr %p5878, align 4, !alias.scope !3, !noalias !4
  %v5879 = load i64, ptr %slot24, align 8
  %p5880 = inttoptr i64 %v5879 to ptr
  store i32 1, ptr %p5880, align 4, !alias.scope !3, !noalias !4
  %v5881 = load i64, ptr %slot27, align 8
  store i64 %v5881, ptr %slot1009, align 8
  %v5882 = load i64, ptr %slot30, align 8
  store i64 %v5882, ptr %slot1010, align 8
  %v5883 = load i64, ptr %slot1010, align 8
  %v5884 = load i64, ptr %slot1009, align 8
  %p5885 = inttoptr i64 %v5883 to ptr
  %p5886 = inttoptr i64 %v5884 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5886, ptr %p5885, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v5887 = load i64, ptr %slot21, align 8
  %p5888 = inttoptr i64 %v5887 to ptr
  store i32 2, ptr %p5888, align 4, !alias.scope !3, !noalias !4
  %v5889 = load i64, ptr %slot25, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %ld5891 = load i32, ptr %p5890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5891, ptr %slot1011, align 8
  %v5892 = load i32, ptr %slot1011, align 8
  %v5893 = load i64, ptr %slot21, align 8
  %p5894 = inttoptr i64 %v5893 to ptr
  store i32 %v5892, ptr %p5894, align 4, !alias.scope !3, !noalias !4
  %v5895 = load i64, ptr %slot24, align 8
  %p5896 = inttoptr i64 %v5895 to ptr
  store i32 0, ptr %p5896, align 4, !alias.scope !3, !noalias !4
  %v5897 = load i64, ptr %slot20, align 8
  %p5898 = inttoptr i64 %v5897 to ptr
  store i32 1, ptr %p5898, align 4, !alias.scope !3, !noalias !4
  %v5899 = load i64, ptr %slot1009, align 8
  %v5900 = load i64, ptr %slot58, align 8
  %p5901 = inttoptr i64 %v5900 to ptr
  store i64 %v5899, ptr %p5901, align 8, !alias.scope !3, !noalias !4
  %v5902 = load i64, ptr %slot58, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  %ld5904 = load i64, ptr %p5903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5904, ptr %slot1012, align 8
  %v5905 = load i64, ptr %slot20, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  %ld5907 = load i32, ptr %p5906, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5907, ptr %slot1013, align 8
  %v5908 = load i64, ptr %slot21, align 8
  %p5909 = inttoptr i64 %v5908 to ptr
  %ld5910 = load i32, ptr %p5909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5910, ptr %slot1014, align 8
  %v5911 = load i32, ptr %slot1014, align 8
  %op5912 = and i32 %v5911, 24
  store i32 %op5912, ptr %slot1014, align 8
  %v5913 = load i32, ptr %slot1014, align 8
  %cmp5914 = icmp eq i32 %v5913, 0
  %cv5915 = zext i1 %cmp5914 to i32
  store i32 %cv5915, ptr %slot1015, align 8
  %v5916 = load i32, ptr %slot1013, align 8
  %v5917 = load i32, ptr %slot1015, align 8
  %op5918 = and i32 %v5916, %v5917
  store i32 %op5918, ptr %slot1016, align 8
  %v5919 = load i32, ptr %slot1016, align 8
  %cv5920 = zext i32 %v5919 to i64
  %cond5921 = icmp ne i64 %cv5920, 0
  br i1 %cond5921, label %bb_rcprivateown1428, label %bb_rcprivateloan1428
bb_rcprivateown1428:
  %v5922 = load i64, ptr %slot30, align 8
  store i64 %v5922, ptr %slot1017, align 8
  %v5923 = load i64, ptr %slot72, align 8
  store i64 %v5923, ptr %slot1018, align 8
  %v5924 = load i64, ptr %slot71, align 8
  %v5925 = load i64, ptr %slot1017, align 8
  %v5926 = load i64, ptr %slot1012, align 8
  %v5927 = load i64, ptr %slot1018, align 8
  %cv5928 = trunc i64 %v5927 to i32
  %call5929 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64 %v5924, i64 %v5925, i64 %v5926, i32 %cv5928) nomerge, !dbg !198
  store i32 %call5929, ptr %slot1019, align 8
  %v5930 = load i32, ptr %slot1019, align 8
  %cv5931 = zext i32 %v5930 to i64
  %cond5932 = icmp ne i64 %cv5931, 0
  br i1 %cond5932, label %bb_rcsuccess1432, label %bb_rcfailure1432
bb_rcfailure1432:
  %v5933 = load i64, ptr %slot71, align 8
  %p5934 = inttoptr i64 %v5933 to ptr
  %call5935 = call i32 @myl_rc_take_failure(ptr %p5934) nomerge, !dbg !198
  store i32 %call5935, ptr %slot1020, align 8
  %v5936 = load i64, ptr %slot1, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  %v5938 = load i32, ptr %slot1020, align 8
  %call5939 = call i32 @myl_qbe_rc_status(ptr %p5937, i32 %v5938) nomerge, !dbg !198
  store i32 %call5939, ptr %slot1021, align 8
  br label %bb_failure
bb_rcsuccess1432:
  %v5940 = load i64, ptr %slot20, align 8
  %p5941 = inttoptr i64 %v5940 to ptr
  store i32 0, ptr %p5941, align 4, !alias.scope !3, !noalias !4
  %v5942 = load i64, ptr %slot25, align 8
  %p5943 = inttoptr i64 %v5942 to ptr
  store i32 2, ptr %p5943, align 4, !alias.scope !3, !noalias !4
  %v5944 = load i64, ptr %slot24, align 8
  %p5945 = inttoptr i64 %v5944 to ptr
  store i32 1, ptr %p5945, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1428
bb_rcprivateloan1428:
  %v5946 = load i64, ptr %slot20, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  %ld5948 = load i32, ptr %p5947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5948, ptr %slot1022, align 8
  %v5949 = load i64, ptr %slot21, align 8
  %p5950 = inttoptr i64 %v5949 to ptr
  %ld5951 = load i32, ptr %p5950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5951, ptr %slot1023, align 8
  %v5952 = load i32, ptr %slot1023, align 8
  %cmp5953 = icmp eq i32 %v5952, 16
  %cv5954 = zext i1 %cmp5953 to i32
  store i32 %cv5954, ptr %slot1024, align 8
  %v5955 = load i32, ptr %slot1024, align 8
  %v5956 = load i32, ptr %slot1022, align 8
  %op5957 = and i32 %v5955, %v5956
  store i32 %op5957, ptr %slot1024, align 8
  %v5958 = load i32, ptr %slot1024, align 8
  %cv5959 = zext i32 %v5958 to i64
  %cond5960 = icmp ne i64 %cv5959, 0
  br i1 %cond5960, label %bb_rcprivatemove1428, label %bb_rcprivatenew1428
bb_rcprivatemove1428:
  %v5961 = load i64, ptr %slot30, align 8
  store i64 %v5961, ptr %slot1025, align 8
  %v5962 = load i64, ptr %slot1012, align 8
  %v5963 = load i64, ptr %slot1025, align 8
  %p5964 = inttoptr i64 %v5962 to ptr
  %p5965 = inttoptr i64 %v5963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5965, ptr %p5964, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v5966 = load i64, ptr %slot1012, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  call void @llvm.memset.p0.i64(ptr %p5967, i8 0, i64 80, i1 false), !alias.scope !3, !noalias !4, !dbg !198
  %v5968 = load i64, ptr %slot25, align 8
  %p5969 = inttoptr i64 %v5968 to ptr
  store i32 2, ptr %p5969, align 4, !alias.scope !3, !noalias !4
  %v5970 = load i64, ptr %slot25, align 8
  %p5971 = inttoptr i64 %v5970 to ptr
  store i32 16, ptr %p5971, align 4, !alias.scope !3, !noalias !4
  %v5972 = load i64, ptr %slot24, align 8
  %p5973 = inttoptr i64 %v5972 to ptr
  store i32 1, ptr %p5973, align 4, !alias.scope !3, !noalias !4
  %v5974 = load i64, ptr %slot20, align 8
  %p5975 = inttoptr i64 %v5974 to ptr
  store i32 0, ptr %p5975, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1428
bb_rcprivatenew1428:
  %v5976 = load i64, ptr %slot30, align 8
  store i64 %v5976, ptr %slot1026, align 8
  %v5977 = load i64, ptr %slot71, align 8
  %v5978 = load i64, ptr %slot1026, align 8
  %v5979 = load i64, ptr %slot1012, align 8
  %call5980 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v5977, i64 %v5978, i64 %v5979) nomerge, !dbg !198
  store i32 %call5980, ptr %slot1027, align 8
  %v5981 = load i32, ptr %slot1027, align 8
  %cv5982 = zext i32 %v5981 to i64
  %cond5983 = icmp ne i64 %cv5982, 0
  br i1 %cond5983, label %bb_rcsuccess1450, label %bb_rcfailure1450
bb_rcfailure1450:
  %v5984 = load i64, ptr %slot71, align 8
  %p5985 = inttoptr i64 %v5984 to ptr
  %call5986 = call i32 @myl_rc_take_failure(ptr %p5985) nomerge, !dbg !198
  store i32 %call5986, ptr %slot1028, align 8
  %v5987 = load i64, ptr %slot1, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  %v5989 = load i32, ptr %slot1028, align 8
  %call5990 = call i32 @myl_qbe_rc_status(ptr %p5988, i32 %v5989) nomerge, !dbg !198
  store i32 %call5990, ptr %slot1029, align 8
  br label %bb_failure
bb_rcsuccess1450:
  %v5991 = load i64, ptr %slot25, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  store i32 2, ptr %p5992, align 4, !alias.scope !3, !noalias !4
  %v5993 = load i64, ptr %slot25, align 8
  %p5994 = inttoptr i64 %v5993 to ptr
  store i32 16, ptr %p5994, align 4, !alias.scope !3, !noalias !4
  %v5995 = load i64, ptr %slot24, align 8
  %p5996 = inttoptr i64 %v5995 to ptr
  store i32 1, ptr %p5996, align 4, !alias.scope !3, !noalias !4
  %v5997 = load i64, ptr %slot20, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %ld5999 = load i32, ptr %p5998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5999, ptr %slot1030, align 8
  %v6000 = load i32, ptr %slot1030, align 8
  %cv6001 = zext i32 %v6000 to i64
  %cond6002 = icmp ne i64 %cv6001, 0
  br i1 %cond6002, label %bb_rcslotdrop1458, label %bb_rcslotdone1458
bb_rcslotdrop1458:
  %v6003 = load i64, ptr %slot20, align 8
  %p6004 = inttoptr i64 %v6003 to ptr
  store i32 0, ptr %p6004, align 4, !alias.scope !3, !noalias !4
  %v6005 = load i64, ptr %slot27, align 8
  store i64 %v6005, ptr %slot1031, align 8
  %v6006 = load i64, ptr %slot21, align 8
  %p6007 = inttoptr i64 %v6006 to ptr
  %ld6008 = load i32, ptr %p6007, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6008, ptr %slot1032, align 8
  %v6009 = load i32, ptr %slot1032, align 8
  %op6010 = and i32 %v6009, 28
  store i32 %op6010, ptr %slot1033, align 8
  %v6011 = load i32, ptr %slot1033, align 8
  %cv6012 = zext i32 %v6011 to i64
  %cond6013 = icmp ne i64 %cv6012, 0
  br i1 %cond6013, label %bb_rcslotrole1458, label %bb_rcslotowner1458
bb_rcslotrole1458:
  %v6014 = load i64, ptr %slot71, align 8
  store i64 %v6014, ptr %slot1034, align 8
  %v6015 = load i64, ptr %slot1034, align 8
  %v6016 = load i64, ptr %slot1031, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6015, i64 %v6016) nomerge, !dbg !198
  br label %bb_rcslotdone1458
bb_rcslotowner1458:
  %v6017 = load i64, ptr %slot71, align 8
  store i64 %v6017, ptr %slot1035, align 8
  %v6018 = load i64, ptr %slot1035, align 8
  %v6019 = load i64, ptr %slot1031, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6018, i64 %v6019) nomerge, !dbg !198
  br label %bb_rcslotdone1458
bb_rcslotdone1458:
  br label %bb_rcprivateprepared1428
bb_rcprivateprepared1428:
  %v6020 = load i64, ptr %slot16, align 8
  %p6021 = inttoptr i64 %v6020 to ptr
  %ld6022 = load i32, ptr %p6021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6022, ptr %slot1036, align 8
  %v6023 = load i32, ptr %slot1036, align 8
  %cv6024 = zext i32 %v6023 to i64
  %cond6025 = icmp ne i64 %cv6024, 0
  br i1 %cond6025, label %bb_rcslotdrop1468, label %bb_rcslotdone1468
bb_rcslotdrop1468:
  %v6026 = load i64, ptr %slot16, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  store i32 0, ptr %p6027, align 4, !alias.scope !3, !noalias !4
  %v6028 = load i64, ptr %slot54, align 8
  store i64 %v6028, ptr %slot1037, align 8
  %v6029 = load i64, ptr %slot17, align 8
  %p6030 = inttoptr i64 %v6029 to ptr
  %ld6031 = load i32, ptr %p6030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6031, ptr %slot1038, align 8
  %v6032 = load i32, ptr %slot1038, align 8
  %op6033 = and i32 %v6032, 28
  store i32 %op6033, ptr %slot1039, align 8
  %v6034 = load i32, ptr %slot1039, align 8
  %cv6035 = zext i32 %v6034 to i64
  %cond6036 = icmp ne i64 %cv6035, 0
  br i1 %cond6036, label %bb_rcslotrole1468, label %bb_rcslotowner1468
bb_rcslotrole1468:
  %v6037 = load i64, ptr %slot71, align 8
  store i64 %v6037, ptr %slot1040, align 8
  %v6038 = load i64, ptr %slot1040, align 8
  %v6039 = load i64, ptr %slot1037, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6038, i64 %v6039) nomerge, !dbg !198
  br label %bb_rcslotdone1468
bb_rcslotowner1468:
  %v6040 = load i64, ptr %slot71, align 8
  store i64 %v6040, ptr %slot1041, align 8
  %v6041 = load i64, ptr %slot1041, align 8
  %v6042 = load i64, ptr %slot1037, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6041, i64 %v6042) nomerge, !dbg !198
  br label %bb_rcslotdone1468
bb_rcslotdone1468:
  %v6043 = load i64, ptr %slot54, align 8
  store i64 %v6043, ptr %slot1042, align 8
  %v6044 = load i64, ptr %slot30, align 8
  store i64 %v6044, ptr %slot1043, align 8
  %v6045 = load i64, ptr %slot1043, align 8
  %v6046 = load i64, ptr %slot1042, align 8
  %p6047 = inttoptr i64 %v6045 to ptr
  %p6048 = inttoptr i64 %v6046 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6048, ptr %p6047, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v6049 = load i64, ptr %slot24, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  store i32 0, ptr %p6050, align 4, !alias.scope !3, !noalias !4
  %v6051 = load i64, ptr %slot17, align 8
  %p6052 = inttoptr i64 %v6051 to ptr
  store i32 2, ptr %p6052, align 4, !alias.scope !3, !noalias !4
  %v6053 = load i64, ptr %slot25, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  %ld6055 = load i32, ptr %p6054, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6055, ptr %slot1044, align 8
  %v6056 = load i32, ptr %slot1044, align 8
  %v6057 = load i64, ptr %slot17, align 8
  %p6058 = inttoptr i64 %v6057 to ptr
  store i32 %v6056, ptr %p6058, align 4, !alias.scope !3, !noalias !4
  %v6059 = load i64, ptr %slot16, align 8
  %p6060 = inttoptr i64 %v6059 to ptr
  store i32 1, ptr %p6060, align 4, !alias.scope !3, !noalias !4
  %v6061 = load i64, ptr %slot52, align 8
  %p6062 = inttoptr i64 %v6061 to ptr
  %ld6063 = load i64, ptr %p6062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6063, ptr %slot1045, align 8
  %v6064 = load i64, ptr %slot1045, align 8
  %v6065 = load i64, ptr %slot58, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  store i64 %v6064, ptr %p6066, align 8, !alias.scope !3, !noalias !4
  %v6067 = load i64, ptr %slot54, align 8
  %v6068 = load i64, ptr %slot59, align 8
  %p6069 = inttoptr i64 %v6068 to ptr
  store i64 %v6067, ptr %p6069, align 8, !alias.scope !3, !noalias !4
  %v6070 = load i64, ptr %slot55, align 8
  %p6071 = inttoptr i64 %v6070 to ptr
  %ld6072 = load i64, ptr %p6071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6072, ptr %slot1046, align 8
  %v6073 = load i64, ptr %slot1046, align 8
  %v6074 = load i64, ptr %slot60, align 8
  %p6075 = inttoptr i64 %v6074 to ptr
  store i64 %v6073, ptr %p6075, align 8, !alias.scope !3, !noalias !4
  %v6076 = load i64, ptr %slot59, align 8
  %p6077 = inttoptr i64 %v6076 to ptr
  %ld6078 = load i64, ptr %p6077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6078, ptr %slot1047, align 8
  %v6079 = load i64, ptr %slot22, align 8
  %p6080 = inttoptr i64 %v6079 to ptr
  %ld6081 = load i32, ptr %p6080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6081, ptr %slot1048, align 8
  %v6082 = load i64, ptr %slot23, align 8
  %p6083 = inttoptr i64 %v6082 to ptr
  %ld6084 = load i32, ptr %p6083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6084, ptr %slot1049, align 8
  %v6085 = load i32, ptr %slot1049, align 8
  %op6086 = and i32 %v6085, 24
  store i32 %op6086, ptr %slot1049, align 8
  %v6087 = load i32, ptr %slot1049, align 8
  %cmp6088 = icmp eq i32 %v6087, 0
  %cv6089 = zext i1 %cmp6088 to i32
  store i32 %cv6089, ptr %slot1050, align 8
  %v6090 = load i32, ptr %slot1048, align 8
  %v6091 = load i32, ptr %slot1050, align 8
  %op6092 = and i32 %v6090, %v6091
  store i32 %op6092, ptr %slot1051, align 8
  %v6093 = load i32, ptr %slot1051, align 8
  %cv6094 = zext i32 %v6093 to i64
  %cond6095 = icmp ne i64 %cv6094, 0
  br i1 %cond6095, label %bb_rctake1485, label %bb_rccopy1485
bb_rctake1485:
  %v6096 = load i64, ptr %slot30, align 8
  store i64 %v6096, ptr %slot1052, align 8
  %v6097 = load i64, ptr %slot72, align 8
  store i64 %v6097, ptr %slot1053, align 8
  %v6098 = load i64, ptr %slot71, align 8
  %v6099 = load i64, ptr %slot1052, align 8
  %v6100 = load i64, ptr %slot1047, align 8
  %v6101 = load i64, ptr %slot1053, align 8
  %cv6102 = trunc i64 %v6101 to i32
  %call6103 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64 %v6098, i64 %v6099, i64 %v6100, i32 %cv6102) nomerge, !dbg !200
  store i32 %call6103, ptr %slot1054, align 8
  %v6104 = load i32, ptr %slot1054, align 8
  %cv6105 = zext i32 %v6104 to i64
  %cond6106 = icmp ne i64 %cv6105, 0
  br i1 %cond6106, label %bb_rcsuccess1495, label %bb_rcfailure1495
bb_rcfailure1495:
  %v6107 = load i64, ptr %slot71, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %call6109 = call i32 @myl_rc_take_failure(ptr %p6108) nomerge, !dbg !200
  store i32 %call6109, ptr %slot1055, align 8
  %v6110 = load i64, ptr %slot1, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  %v6112 = load i32, ptr %slot1055, align 8
  %call6113 = call i32 @myl_qbe_rc_status(ptr %p6111, i32 %v6112) nomerge, !dbg !200
  store i32 %call6113, ptr %slot1056, align 8
  br label %bb_failure
bb_rcsuccess1495:
  %v6114 = load i64, ptr %slot22, align 8
  %p6115 = inttoptr i64 %v6114 to ptr
  store i32 0, ptr %p6115, align 4, !alias.scope !3, !noalias !4
  %v6116 = load i64, ptr %slot25, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  store i32 2, ptr %p6117, align 4, !alias.scope !3, !noalias !4
  %v6118 = load i64, ptr %slot24, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  store i32 1, ptr %p6119, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1485
bb_rccopy1485:
  %v6120 = load i64, ptr %slot30, align 8
  store i64 %v6120, ptr %slot1057, align 8
  %v6121 = load i64, ptr %slot72, align 8
  store i64 %v6121, ptr %slot1058, align 8
  %v6122 = load i64, ptr %slot71, align 8
  %v6123 = load i64, ptr %slot1057, align 8
  %v6124 = load i64, ptr %slot1047, align 8
  %v6125 = load i64, ptr %slot1058, align 8
  %cv6126 = trunc i64 %v6125 to i32
  %call6127 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_retain(i64 %v6122, i64 %v6123, i64 %v6124, i32 %cv6126) nomerge, !dbg !200
  store i32 %call6127, ptr %slot1059, align 8
  %v6128 = load i32, ptr %slot1059, align 8
  %cv6129 = zext i32 %v6128 to i64
  %cond6130 = icmp ne i64 %cv6129, 0
  br i1 %cond6130, label %bb_rcsuccess1504, label %bb_rcfailure1504
bb_rcfailure1504:
  %v6131 = load i64, ptr %slot71, align 8
  %p6132 = inttoptr i64 %v6131 to ptr
  %call6133 = call i32 @myl_rc_take_failure(ptr %p6132) nomerge, !dbg !200
  store i32 %call6133, ptr %slot1060, align 8
  %v6134 = load i64, ptr %slot1, align 8
  %p6135 = inttoptr i64 %v6134 to ptr
  %v6136 = load i32, ptr %slot1060, align 8
  %call6137 = call i32 @myl_qbe_rc_status(ptr %p6135, i32 %v6136) nomerge, !dbg !200
  store i32 %call6137, ptr %slot1061, align 8
  br label %bb_failure
bb_rcsuccess1504:
  %v6138 = load i64, ptr %slot25, align 8
  %p6139 = inttoptr i64 %v6138 to ptr
  store i32 2, ptr %p6139, align 4, !alias.scope !3, !noalias !4
  %v6140 = load i64, ptr %slot24, align 8
  %p6141 = inttoptr i64 %v6140 to ptr
  store i32 1, ptr %p6141, align 4, !alias.scope !3, !noalias !4
  %v6142 = load i64, ptr %slot22, align 8
  %p6143 = inttoptr i64 %v6142 to ptr
  %ld6144 = load i32, ptr %p6143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6144, ptr %slot1062, align 8
  %v6145 = load i32, ptr %slot1062, align 8
  %cv6146 = zext i32 %v6145 to i64
  %cond6147 = icmp ne i64 %cv6146, 0
  br i1 %cond6147, label %bb_rcslotdrop1511, label %bb_rcslotdone1511
bb_rcslotdrop1511:
  %v6148 = load i64, ptr %slot22, align 8
  %p6149 = inttoptr i64 %v6148 to ptr
  store i32 0, ptr %p6149, align 4, !alias.scope !3, !noalias !4
  %v6150 = load i64, ptr %slot28, align 8
  store i64 %v6150, ptr %slot1063, align 8
  %v6151 = load i64, ptr %slot23, align 8
  %p6152 = inttoptr i64 %v6151 to ptr
  %ld6153 = load i32, ptr %p6152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6153, ptr %slot1064, align 8
  %v6154 = load i32, ptr %slot1064, align 8
  %op6155 = and i32 %v6154, 28
  store i32 %op6155, ptr %slot1065, align 8
  %v6156 = load i32, ptr %slot1065, align 8
  %cv6157 = zext i32 %v6156 to i64
  %cond6158 = icmp ne i64 %cv6157, 0
  br i1 %cond6158, label %bb_rcslotrole1511, label %bb_rcslotowner1511
bb_rcslotrole1511:
  %v6159 = load i64, ptr %slot71, align 8
  store i64 %v6159, ptr %slot1066, align 8
  %v6160 = load i64, ptr %slot1066, align 8
  %v6161 = load i64, ptr %slot1063, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6160, i64 %v6161) nomerge, !dbg !200
  br label %bb_rcslotdone1511
bb_rcslotowner1511:
  %v6162 = load i64, ptr %slot71, align 8
  store i64 %v6162, ptr %slot1067, align 8
  %v6163 = load i64, ptr %slot1067, align 8
  %v6164 = load i64, ptr %slot1063, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6163, i64 %v6164) nomerge, !dbg !200
  br label %bb_rcslotdone1511
bb_rcslotdone1511:
  br label %bb_rcprepared1485
bb_rcprepared1485:
  %v6165 = load i64, ptr %slot30, align 8
  store i64 %v6165, ptr %slot1068, align 8
  %v6166 = load i64, ptr %slot64, align 8
  store i64 %v6166, ptr %slot1069, align 8
  %v6167 = load i64, ptr %slot1068, align 8
  %v6168 = load i64, ptr %slot1069, align 8
  %p6169 = inttoptr i64 %v6167 to ptr
  %p6170 = inttoptr i64 %v6168 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6170, ptr %p6169, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v6171 = load i64, ptr %slot24, align 8
  %p6172 = inttoptr i64 %v6171 to ptr
  store i32 0, ptr %p6172, align 4, !alias.scope !3, !noalias !4
  %v6173 = load i64, ptr %slot26, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  store i32 1, ptr %p6174, align 4, !alias.scope !3, !noalias !4
  %v6175 = load i64, ptr %slot72, align 8
  store i64 %v6175, ptr %slot1070, align 8
  %v6176 = load i64, ptr %slot60, align 8
  store i64 %v6176, ptr %slot1071, align 8
  %v6177 = load i64, ptr %slot1069, align 8
  %p6179 = inttoptr i64 %v6177 to ptr
  %gep6180 = getelementptr i8, ptr %p6179, i64 72
  %op6178 = ptrtoint ptr %gep6180 to i64
  store i64 %op6178, ptr %slot1072, align 8
  %v6181 = load i64, ptr %slot1071, align 8
  %p6182 = inttoptr i64 %v6181 to ptr
  %ld6183 = load i64, ptr %p6182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6183, ptr %slot1073, align 8
  %v6184 = load i64, ptr %slot1073, align 8
  %v6185 = load i64, ptr %slot1072, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  store i64 %v6184, ptr %p6186, align 8, !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot1069, align 8
  %v6188 = load i64, ptr %slot59, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  store i64 %v6187, ptr %p6189, align 8, !alias.scope !3, !noalias !4
  %v6190 = load i64, ptr %slot59, align 8
  %p6191 = inttoptr i64 %v6190 to ptr
  %ld6192 = load i64, ptr %p6191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6192, ptr %slot1074, align 8
  %v6193 = load i64, ptr %slot30, align 8
  store i64 %v6193, ptr %slot1075, align 8
  %v6194 = load i64, ptr %slot1074, align 8
  %v6195 = load i64, ptr %slot1075, align 8
  %p6196 = inttoptr i64 %v6194 to ptr
  %p6197 = inttoptr i64 %v6195 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6197, ptr %p6196, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v6198 = load i64, ptr %slot25, align 8
  %p6199 = inttoptr i64 %v6198 to ptr
  store i32 2, ptr %p6199, align 4, !alias.scope !3, !noalias !4
  %v6200 = load i64, ptr %slot24, align 8
  %p6201 = inttoptr i64 %v6200 to ptr
  store i32 1, ptr %p6201, align 4, !alias.scope !3, !noalias !4
  %v6202 = load i64, ptr %slot22, align 8
  %p6203 = inttoptr i64 %v6202 to ptr
  %ld6204 = load i32, ptr %p6203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6204, ptr %slot1076, align 8
  %v6205 = load i32, ptr %slot1076, align 8
  %cv6206 = zext i32 %v6205 to i64
  %cond6207 = icmp ne i64 %cv6206, 0
  br i1 %cond6207, label %bb_rcslotdrop1533, label %bb_rcslotdone1533
bb_rcslotdrop1533:
  %v6208 = load i64, ptr %slot22, align 8
  %p6209 = inttoptr i64 %v6208 to ptr
  store i32 0, ptr %p6209, align 4, !alias.scope !3, !noalias !4
  %v6210 = load i64, ptr %slot28, align 8
  store i64 %v6210, ptr %slot1077, align 8
  %v6211 = load i64, ptr %slot23, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %ld6213 = load i32, ptr %p6212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6213, ptr %slot1078, align 8
  %v6214 = load i32, ptr %slot1078, align 8
  %op6215 = and i32 %v6214, 28
  store i32 %op6215, ptr %slot1079, align 8
  %v6216 = load i32, ptr %slot1079, align 8
  %cv6217 = zext i32 %v6216 to i64
  %cond6218 = icmp ne i64 %cv6217, 0
  br i1 %cond6218, label %bb_rcslotrole1533, label %bb_rcslotowner1533
bb_rcslotrole1533:
  %v6219 = load i64, ptr %slot71, align 8
  store i64 %v6219, ptr %slot1080, align 8
  %v6220 = load i64, ptr %slot1080, align 8
  %v6221 = load i64, ptr %slot1077, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6220, i64 %v6221) nomerge, !dbg !200
  br label %bb_rcslotdone1533
bb_rcslotowner1533:
  %v6222 = load i64, ptr %slot71, align 8
  store i64 %v6222, ptr %slot1081, align 8
  %v6223 = load i64, ptr %slot1081, align 8
  %v6224 = load i64, ptr %slot1077, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6223, i64 %v6224) nomerge, !dbg !200
  br label %bb_rcslotdone1533
bb_rcslotdone1533:
  %v6225 = load i64, ptr %slot28, align 8
  store i64 %v6225, ptr %slot1082, align 8
  %v6226 = load i64, ptr %slot30, align 8
  store i64 %v6226, ptr %slot1083, align 8
  %v6227 = load i64, ptr %slot1083, align 8
  %v6228 = load i64, ptr %slot1082, align 8
  %p6229 = inttoptr i64 %v6227 to ptr
  %p6230 = inttoptr i64 %v6228 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6230, ptr %p6229, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v6231 = load i64, ptr %slot23, align 8
  %p6232 = inttoptr i64 %v6231 to ptr
  store i32 2, ptr %p6232, align 4, !alias.scope !3, !noalias !4
  %v6233 = load i64, ptr %slot25, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  %ld6235 = load i32, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6235, ptr %slot1084, align 8
  %v6236 = load i32, ptr %slot1084, align 8
  %v6237 = load i64, ptr %slot23, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  store i32 %v6236, ptr %p6238, align 4, !alias.scope !3, !noalias !4
  %v6239 = load i64, ptr %slot24, align 8
  %p6240 = inttoptr i64 %v6239 to ptr
  store i32 0, ptr %p6240, align 4, !alias.scope !3, !noalias !4
  %v6241 = load i64, ptr %slot22, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  store i32 1, ptr %p6242, align 4, !alias.scope !3, !noalias !4
  %v6243 = load i64, ptr %slot1082, align 8
  %v6244 = load i64, ptr %slot59, align 8
  %p6245 = inttoptr i64 %v6244 to ptr
  store i64 %v6243, ptr %p6245, align 8, !alias.scope !3, !noalias !4
  %v6246 = load i64, ptr %slot59, align 8
  %p6247 = inttoptr i64 %v6246 to ptr
  %ld6248 = load i64, ptr %p6247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6248, ptr %slot1085, align 8
  %v6249 = load i64, ptr %slot22, align 8
  %p6250 = inttoptr i64 %v6249 to ptr
  %ld6251 = load i32, ptr %p6250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6251, ptr %slot1086, align 8
  %v6252 = load i64, ptr %slot23, align 8
  %p6253 = inttoptr i64 %v6252 to ptr
  %ld6254 = load i32, ptr %p6253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6254, ptr %slot1087, align 8
  %v6255 = load i32, ptr %slot1087, align 8
  %op6256 = and i32 %v6255, 24
  store i32 %op6256, ptr %slot1087, align 8
  %v6257 = load i32, ptr %slot1087, align 8
  %cmp6258 = icmp eq i32 %v6257, 0
  %cv6259 = zext i1 %cmp6258 to i32
  store i32 %cv6259, ptr %slot1088, align 8
  %v6260 = load i32, ptr %slot1086, align 8
  %v6261 = load i32, ptr %slot1088, align 8
  %op6262 = and i32 %v6260, %v6261
  store i32 %op6262, ptr %slot1089, align 8
  %v6263 = load i64, ptr %slot72, align 8
  store i64 %v6263, ptr %slot1090, align 8
  %v6264 = load i32, ptr %slot1089, align 8
  %op6265 = mul i32 %v6264, 4
  store i32 %op6265, ptr %slot1091, align 8
  %v6266 = load i32, ptr %slot1091, align 8
  %op6267 = or i32 %v6266, 0
  store i32 %op6267, ptr %slot1092, align 8
  %v6268 = load i64, ptr %slot30, align 8
  store i64 %v6268, ptr %slot1093, align 8
  %v6269 = load i64, ptr %slot71, align 8
  %v6270 = load i64, ptr %slot1093, align 8
  %v6271 = load i64, ptr %slot1085, align 8
  %v6272 = load i64, ptr %slot1090, align 8
  %cv6273 = trunc i64 %v6272 to i32
  %v6274 = load i32, ptr %slot1092, align 8
  %call6275 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_publish(i64 %v6269, i64 %v6270, i64 %v6271, i32 %cv6273, i32 %v6274) nomerge, !dbg !202
  store i32 %call6275, ptr %slot1094, align 8
  %v6276 = load i32, ptr %slot1094, align 8
  %cv6277 = zext i32 %v6276 to i64
  %cond6278 = icmp ne i64 %cv6277, 0
  br i1 %cond6278, label %bb_rcsuccess1562, label %bb_rcfailure1562
bb_rcfailure1562:
  %v6279 = load i64, ptr %slot71, align 8
  %p6280 = inttoptr i64 %v6279 to ptr
  %call6281 = call i32 @myl_rc_take_failure(ptr %p6280) nomerge, !dbg !202
  store i32 %call6281, ptr %slot1095, align 8
  %v6282 = load i64, ptr %slot1, align 8
  %p6283 = inttoptr i64 %v6282 to ptr
  %v6284 = load i32, ptr %slot1095, align 8
  %call6285 = call i32 @myl_qbe_rc_status(ptr %p6283, i32 %v6284) nomerge, !dbg !202
  store i32 %call6285, ptr %slot1096, align 8
  br label %bb_failure
bb_rcsuccess1562:
  %v6286 = load i32, ptr %slot1089, align 8
  %cv6287 = zext i32 %v6286 to i64
  %cond6288 = icmp ne i64 %cv6287, 0
  br i1 %cond6288, label %bb_rchtaken1565, label %bb_rchcopied1565
bb_rchcopied1565:
  %v6289 = load i64, ptr %slot22, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %ld6291 = load i32, ptr %p6290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6291, ptr %slot1097, align 8
  %v6292 = load i32, ptr %slot1097, align 8
  %cv6293 = zext i32 %v6292 to i64
  %cond6294 = icmp ne i64 %cv6293, 0
  br i1 %cond6294, label %bb_rcslotdrop1568, label %bb_rcslotdone1568
bb_rcslotdrop1568:
  %v6295 = load i64, ptr %slot22, align 8
  %p6296 = inttoptr i64 %v6295 to ptr
  store i32 0, ptr %p6296, align 4, !alias.scope !3, !noalias !4
  %v6297 = load i64, ptr %slot28, align 8
  store i64 %v6297, ptr %slot1098, align 8
  %v6298 = load i64, ptr %slot23, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %ld6300 = load i32, ptr %p6299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6300, ptr %slot1099, align 8
  %v6301 = load i32, ptr %slot1099, align 8
  %op6302 = and i32 %v6301, 28
  store i32 %op6302, ptr %slot1100, align 8
  %v6303 = load i32, ptr %slot1100, align 8
  %cv6304 = zext i32 %v6303 to i64
  %cond6305 = icmp ne i64 %cv6304, 0
  br i1 %cond6305, label %bb_rcslotrole1568, label %bb_rcslotowner1568
bb_rcslotrole1568:
  %v6306 = load i64, ptr %slot71, align 8
  store i64 %v6306, ptr %slot1101, align 8
  %v6307 = load i64, ptr %slot1101, align 8
  %v6308 = load i64, ptr %slot1098, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6307, i64 %v6308) nomerge, !dbg !202
  br label %bb_rcslotdone1568
bb_rcslotowner1568:
  %v6309 = load i64, ptr %slot71, align 8
  store i64 %v6309, ptr %slot1102, align 8
  %v6310 = load i64, ptr %slot1102, align 8
  %v6311 = load i64, ptr %slot1098, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6310, i64 %v6311) nomerge, !dbg !202
  br label %bb_rcslotdone1568
bb_rcslotdone1568:
  br label %bb_rchprepared1565
bb_rchtaken1565:
  %v6312 = load i64, ptr %slot22, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  store i32 0, ptr %p6313, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1565
bb_rchprepared1565:
  %v6314 = load i64, ptr %slot25, align 8
  %p6315 = inttoptr i64 %v6314 to ptr
  store i32 2, ptr %p6315, align 4, !alias.scope !3, !noalias !4
  %v6316 = load i64, ptr %slot24, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  store i32 1, ptr %p6317, align 4, !alias.scope !3, !noalias !4
  %v6318 = load i64, ptr %slot28, align 8
  store i64 %v6318, ptr %slot1103, align 8
  %v6319 = load i64, ptr %slot30, align 8
  store i64 %v6319, ptr %slot1104, align 8
  %v6320 = load i64, ptr %slot1104, align 8
  %v6321 = load i64, ptr %slot1103, align 8
  %p6322 = inttoptr i64 %v6320 to ptr
  %p6323 = inttoptr i64 %v6321 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6323, ptr %p6322, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v6324 = load i64, ptr %slot23, align 8
  %p6325 = inttoptr i64 %v6324 to ptr
  store i32 2, ptr %p6325, align 4, !alias.scope !3, !noalias !4
  %v6326 = load i64, ptr %slot25, align 8
  %p6327 = inttoptr i64 %v6326 to ptr
  %ld6328 = load i32, ptr %p6327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6328, ptr %slot1105, align 8
  %v6329 = load i32, ptr %slot1105, align 8
  %v6330 = load i64, ptr %slot23, align 8
  %p6331 = inttoptr i64 %v6330 to ptr
  store i32 %v6329, ptr %p6331, align 4, !alias.scope !3, !noalias !4
  %v6332 = load i64, ptr %slot24, align 8
  %p6333 = inttoptr i64 %v6332 to ptr
  store i32 0, ptr %p6333, align 4, !alias.scope !3, !noalias !4
  %v6334 = load i64, ptr %slot22, align 8
  %p6335 = inttoptr i64 %v6334 to ptr
  store i32 1, ptr %p6335, align 4, !alias.scope !3, !noalias !4
  %v6336 = load i64, ptr %slot1103, align 8
  %v6337 = load i64, ptr %slot59, align 8
  %p6338 = inttoptr i64 %v6337 to ptr
  store i64 %v6336, ptr %p6338, align 8, !alias.scope !3, !noalias !4
  %v6339 = load i64, ptr %slot51, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %ld6341 = load i64, ptr %p6340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6341, ptr %slot1106, align 8
  %v6342 = load i64, ptr %slot59, align 8
  %p6343 = inttoptr i64 %v6342 to ptr
  %ld6344 = load i64, ptr %p6343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6344, ptr %slot1107, align 8
  %v6345 = load i64, ptr %slot58, align 8
  %p6346 = inttoptr i64 %v6345 to ptr
  %ld6347 = load i64, ptr %p6346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6347, ptr %slot1108, align 8
  %v6348 = load i64, ptr %slot1106, align 8
  %p6349 = inttoptr i64 %v6348 to ptr
  %ld6350 = load i64, ptr %p6349, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6350, ptr %slot1109, align 8
  %v6351 = load i64, ptr %slot1108, align 8
  %v6352 = load i64, ptr %slot1109, align 8
  %cmp6353 = icmp ult i64 %v6351, %v6352
  %cv6354 = zext i1 %cmp6353 to i64
  store i64 %cv6354, ptr %slot1110, align 8
  %v6355 = load i64, ptr %slot1110, align 8
  %cond6356 = icmp ne i64 %v6355, 0
  br i1 %cond6356, label %bb_success1592, label %bb_failed1592
bb_failed1592:
  %v6357 = load i64, ptr %slot1, align 8
  %p6358 = inttoptr i64 %v6357 to ptr
  %v6359 = load i64, ptr %slot1108, align 8
  %v6360 = load i64, ptr %slot1109, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p6358, i64 %v6359, i64 %v6360) nomerge, !dbg !204
  unreachable
bb_success1592:
  %v6361 = load i64, ptr %slot59, align 8
  %p6362 = inttoptr i64 %v6361 to ptr
  %ld6363 = load i64, ptr %p6362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6363, ptr %slot1111, align 8
  %v6364 = load i64, ptr %slot71, align 8
  %v6365 = load i64, ptr %slot1106, align 8
  %v6366 = load i64, ptr %slot1108, align 8
  %v6367 = load i64, ptr %slot1111, align 8
  %call6368 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_list_set(i64 %v6364, i64 %v6365, i64 %v6366, i64 %v6367) nomerge, !dbg !204
  store i32 %call6368, ptr %slot1112, align 8
  %v6369 = load i32, ptr %slot1112, align 8
  %cv6370 = zext i32 %v6369 to i64
  %cond6371 = icmp ne i64 %cv6370, 0
  br i1 %cond6371, label %bb_success1595, label %bb_failed1595
bb_failed1595:
  %v6372 = load i64, ptr %slot1, align 8
  %p6373 = inttoptr i64 %v6372 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6373) nomerge, !dbg !204
  unreachable
bb_success1595:
  %v6374 = load i64, ptr %slot58, align 8
  %p6375 = inttoptr i64 %v6374 to ptr
  store i64 0, ptr %p6375, align 8, !alias.scope !3, !noalias !4
  %v6376 = load i64, ptr %slot22, align 8
  %p6377 = inttoptr i64 %v6376 to ptr
  %ld6378 = load i32, ptr %p6377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6378, ptr %slot1113, align 8
  %v6379 = load i32, ptr %slot1113, align 8
  %cv6380 = zext i32 %v6379 to i64
  %cond6381 = icmp ne i64 %cv6380, 0
  br i1 %cond6381, label %bb_rcslotdrop1598, label %bb_rcslotdone1598
bb_rcslotdrop1598:
  %v6382 = load i64, ptr %slot22, align 8
  %p6383 = inttoptr i64 %v6382 to ptr
  store i32 0, ptr %p6383, align 4, !alias.scope !3, !noalias !4
  %v6384 = load i64, ptr %slot28, align 8
  store i64 %v6384, ptr %slot1114, align 8
  %v6385 = load i64, ptr %slot23, align 8
  %p6386 = inttoptr i64 %v6385 to ptr
  %ld6387 = load i32, ptr %p6386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6387, ptr %slot1115, align 8
  %v6388 = load i32, ptr %slot1115, align 8
  %op6389 = and i32 %v6388, 28
  store i32 %op6389, ptr %slot1116, align 8
  %v6390 = load i32, ptr %slot1116, align 8
  %cv6391 = zext i32 %v6390 to i64
  %cond6392 = icmp ne i64 %cv6391, 0
  br i1 %cond6392, label %bb_rcslotrole1598, label %bb_rcslotowner1598
bb_rcslotrole1598:
  %v6393 = load i64, ptr %slot71, align 8
  store i64 %v6393, ptr %slot1117, align 8
  %v6394 = load i64, ptr %slot1117, align 8
  %v6395 = load i64, ptr %slot1114, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v6394, i64 %v6395) nomerge, !dbg !204
  br label %bb_rcslotdone1598
bb_rcslotowner1598:
  %v6396 = load i64, ptr %slot71, align 8
  store i64 %v6396, ptr %slot1118, align 8
  %v6397 = load i64, ptr %slot1118, align 8
  %v6398 = load i64, ptr %slot1114, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v6397, i64 %v6398) nomerge, !dbg !204
  br label %bb_rcslotdone1598
bb_rcslotdone1598:
  %v6399 = load i64, ptr %slot31, align 8
  store i64 %v6399, ptr %slot1119, align 8
  %v6400 = load i64, ptr %slot1119, align 8
  %p6402 = inttoptr i64 %v6400 to ptr
  %gep6403 = getelementptr i8, ptr %p6402, i64 24
  %op6401 = ptrtoint ptr %gep6403 to i64
  store i64 %op6401, ptr %slot1120, align 8
  %v6404 = load i64, ptr %slot1120, align 8
  %p6405 = inttoptr i64 %v6404 to ptr
  %ld6406 = load i32, ptr %p6405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6406, ptr %slot1121, align 8
  %v6407 = load i32, ptr %slot1121, align 8
  %cv6408 = zext i32 %v6407 to i64
  %cond6409 = icmp ne i64 %cv6408, 0
  br i1 %cond6409, label %bb_rcsendactive1606, label %bb_rcsenddone1606
bb_rcsendactive1606:
  %v6410 = load i64, ptr %slot71, align 8
  %p6412 = inttoptr i64 %v6410 to ptr
  %gep6413 = getelementptr i8, ptr %p6412, i64 5640
  %op6411 = ptrtoint ptr %gep6413 to i64
  store i64 %op6411, ptr %slot1122, align 8
  %v6414 = load i64, ptr %slot1122, align 8
  %p6415 = inttoptr i64 %v6414 to ptr
  %ld6416 = load i64, ptr %p6415, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6416, ptr %slot1123, align 8
  %v6417 = load i64, ptr %slot1123, align 8
  %op6418 = add i64 %v6417, 248
  store i64 %op6418, ptr %slot1124, align 8
  %v6419 = load i64, ptr %slot1124, align 8
  %p6420 = inttoptr i64 %v6419 to ptr
  %ld6421 = load i64, ptr %p6420, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6421, ptr %slot1125, align 8
  %v6422 = load i64, ptr %slot1125, align 8
  %v6423 = load i64, ptr %slot1119, align 8
  %cmp6424 = icmp eq i64 %v6422, %v6423
  %cv6425 = zext i1 %cmp6424 to i32
  store i32 %cv6425, ptr %slot1126, align 8
  %v6426 = load i32, ptr %slot1126, align 8
  %cv6427 = zext i32 %v6426 to i64
  %cond6428 = icmp ne i64 %cv6427, 0
  br i1 %cond6428, label %bb_rcs1614, label %bb_rcsendslow1606
bb_rcs1614:
  %v6429 = load i64, ptr %slot1123, align 8
  %op6430 = add i64 %v6429, 200
  store i64 %op6430, ptr %slot1127, align 8
  %v6431 = load i64, ptr %slot1127, align 8
  %p6432 = inttoptr i64 %v6431 to ptr
  %ld6433 = load i64, ptr %p6432, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6433, ptr %slot1128, align 8
  %v6434 = load i64, ptr %slot1128, align 8
  %cmp6435 = icmp eq i64 %v6434, 0
  %cv6436 = zext i1 %cmp6435 to i32
  store i32 %cv6436, ptr %slot1129, align 8
  %v6437 = load i32, ptr %slot1129, align 8
  %cv6438 = zext i32 %v6437 to i64
  %cond6439 = icmp ne i64 %cv6438, 0
  br i1 %cond6439, label %bb_rcs1618, label %bb_rcsendslow1606
bb_rcs1618:
  %v6440 = load i64, ptr %slot1119, align 8
  %p6442 = inttoptr i64 %v6440 to ptr
  %gep6443 = getelementptr i8, ptr %p6442, i64 16
  %op6441 = ptrtoint ptr %gep6443 to i64
  store i64 %op6441, ptr %slot1130, align 8
  %v6444 = load i64, ptr %slot1130, align 8
  %p6445 = inttoptr i64 %v6444 to ptr
  %ld6446 = load i64, ptr %p6445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6446, ptr %slot1131, align 8
  %v6447 = load i64, ptr %slot1131, align 8
  %cmp6448 = icmp ne i64 %v6447, 0
  %cv6449 = zext i1 %cmp6448 to i32
  store i32 %cv6449, ptr %slot1132, align 8
  %v6450 = load i32, ptr %slot1132, align 8
  %cv6451 = zext i32 %v6450 to i64
  %cond6452 = icmp ne i64 %cv6451, 0
  br i1 %cond6452, label %bb_rcsendnode1606, label %bb_rcsendunlink1606
bb_rcsendnode1606:
  %v6453 = load i64, ptr %slot1131, align 8
  %op6454 = add i64 %v6453, 0
  store i64 %op6454, ptr %slot1133, align 8
  %v6455 = load i64, ptr %slot1133, align 8
  %p6456 = inttoptr i64 %v6455 to ptr
  %ld6457 = load i64, ptr %p6456, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6457, ptr %slot1134, align 8
  %v6458 = load i64, ptr %slot1134, align 8
  %cmp6459 = icmp eq i64 %v6458, 0
  %cv6460 = zext i1 %cmp6459 to i32
  store i32 %cv6460, ptr %slot1135, align 8
  %v6461 = load i32, ptr %slot1135, align 8
  %cv6462 = zext i32 %v6461 to i64
  %cond6463 = icmp ne i64 %cv6462, 0
  br i1 %cond6463, label %bb_rcs1625, label %bb_rcsendslow1606
bb_rcs1625:
  %v6464 = load i64, ptr %slot1123, align 8
  %op6465 = add i64 %v6464, 264
  store i64 %op6465, ptr %slot1136, align 8
  %v6466 = load i64, ptr %slot1136, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  %ld6468 = load i64, ptr %p6467, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6468, ptr %slot1137, align 8
  %v6469 = load i64, ptr %slot1137, align 8
  %cmp6470 = icmp ult i64 %v6469, 32
  %cv6471 = zext i1 %cmp6470 to i32
  store i32 %cv6471, ptr %slot1138, align 8
  %v6472 = load i32, ptr %slot1138, align 8
  %cv6473 = zext i32 %v6472 to i64
  %cond6474 = icmp ne i64 %cv6473, 0
  br i1 %cond6474, label %bb_rcs1629, label %bb_rcsendslow1606
bb_rcs1629:
  %v6475 = load i64, ptr %slot1131, align 8
  %op6476 = add i64 %v6475, 8
  store i64 %op6476, ptr %slot1139, align 8
  %v6477 = load i64, ptr %slot1139, align 8
  %p6478 = inttoptr i64 %v6477 to ptr
  %ld6479 = load i64, ptr %p6478, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6479, ptr %slot1140, align 8
  %v6480 = load i64, ptr %slot1140, align 8
  %cmp6481 = icmp ne i64 %v6480, 0
  %cv6482 = zext i1 %cmp6481 to i32
  store i32 %cv6482, ptr %slot1141, align 8
  %v6483 = load i32, ptr %slot1141, align 8
  %cv6484 = zext i32 %v6483 to i64
  %cond6485 = icmp ne i64 %cv6484, 0
  br i1 %cond6485, label %bb_rcs1633, label %bb_rcsendslow1606
bb_rcs1633:
  %v6486 = load i64, ptr %slot1140, align 8
  %op6487 = sub i64 %v6486, 16
  store i64 %op6487, ptr %slot1142, align 8
  %v6488 = load i64, ptr %slot1140, align 8
  %p6489 = inttoptr i64 %v6488 to ptr
  %rgep6490 = getelementptr i8, ptr %p6489, i64 -16
  %ld6491 = load i64, ptr %rgep6490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6491, ptr %slot1143, align 8
  %v6492 = load i64, ptr %slot1143, align 8
  %op6493 = and i64 %v6492, 4611686018427387907
  store i64 %op6493, ptr %slot1144, align 8
  %v6494 = load i64, ptr %slot1144, align 8
  %cmp6495 = icmp eq i64 %v6494, 0
  %cv6496 = zext i1 %cmp6495 to i32
  store i32 %cv6496, ptr %slot1145, align 8
  %v6497 = load i32, ptr %slot1145, align 8
  %cv6498 = zext i32 %v6497 to i64
  %cond6499 = icmp ne i64 %cv6498, 0
  br i1 %cond6499, label %bb_rcs1638, label %bb_rcsendslow1606
bb_rcs1638:
  %v6500 = load i64, ptr %slot1140, align 8
  %op6501 = sub i64 %v6500, 24
  store i64 %op6501, ptr %slot1146, align 8
  %v6502 = load i64, ptr %slot1140, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  %rgep6504 = getelementptr i8, ptr %p6503, i64 -24
  %ld6505 = load i64, ptr %rgep6504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6505, ptr %slot1147, align 8
  %v6506 = load i64, ptr %slot1147, align 8
  %cmp6507 = icmp ne i64 %v6506, 0
  %cv6508 = zext i1 %cmp6507 to i32
  store i32 %cv6508, ptr %slot1148, align 8
  %v6509 = load i32, ptr %slot1148, align 8
  %cv6510 = zext i32 %v6509 to i64
  %cond6511 = icmp ne i64 %cv6510, 0
  br i1 %cond6511, label %bb_rcs1642, label %bb_rcsendslow1606
bb_rcs1642:
  %v6512 = load i64, ptr %slot1140, align 8
  %op6513 = sub i64 %v6512, 32
  store i64 %op6513, ptr %slot1149, align 8
  %v6514 = load i64, ptr %slot1140, align 8
  %p6515 = inttoptr i64 %v6514 to ptr
  %rgep6516 = getelementptr i8, ptr %p6515, i64 -32
  %ld6517 = load i64, ptr %rgep6516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6517, ptr %slot1150, align 8
  %v6518 = load i64, ptr %slot1147, align 8
  %cmp6519 = icmp ugt i64 %v6518, 1
  %cv6520 = zext i1 %cmp6519 to i32
  store i32 %cv6520, ptr %slot1151, align 8
  %v6521 = load i64, ptr %slot1150, align 8
  %cmp6522 = icmp ne i64 %v6521, 0
  %cv6523 = zext i1 %cmp6522 to i32
  store i32 %cv6523, ptr %slot1152, align 8
  %v6524 = load i32, ptr %slot1151, align 8
  %v6525 = load i32, ptr %slot1152, align 8
  %op6526 = or i32 %v6524, %v6525
  store i32 %op6526, ptr %slot1153, align 8
  %v6527 = load i32, ptr %slot1153, align 8
  %cv6528 = zext i32 %v6527 to i64
  %cond6529 = icmp ne i64 %cv6528, 0
  br i1 %cond6529, label %bb_rcs1648, label %bb_rcsendslow1606
bb_rcs1648:
  %v6530 = load i64, ptr %slot1131, align 8
  %op6531 = add i64 %v6530, 32
  store i64 %op6531, ptr %slot1154, align 8
  %v6532 = load i64, ptr %slot1154, align 8
  %p6533 = inttoptr i64 %v6532 to ptr
  %ld6534 = load i64, ptr %p6533, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6534, ptr %slot1155, align 8
  %v6535 = load i64, ptr %slot1155, align 8
  %cmp6536 = icmp ne i64 %v6535, 0
  %cv6537 = zext i1 %cmp6536 to i32
  store i32 %cv6537, ptr %slot1156, align 8
  %v6538 = load i32, ptr %slot1156, align 8
  %cv6539 = zext i32 %v6538 to i64
  %cond6540 = icmp ne i64 %cv6539, 0
  br i1 %cond6540, label %bb_rcsendbacking1606, label %bb_rcsendcommit1606
bb_rcsendbacking1606:
  %v6541 = load i64, ptr %slot1155, align 8
  %op6542 = sub i64 %v6541, 16
  store i64 %op6542, ptr %slot1157, align 8
  %v6543 = load i64, ptr %slot1155, align 8
  %p6544 = inttoptr i64 %v6543 to ptr
  %rgep6545 = getelementptr i8, ptr %p6544, i64 -16
  %ld6546 = load i64, ptr %rgep6545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6546, ptr %slot1158, align 8
  %v6547 = load i64, ptr %slot1158, align 8
  %op6548 = and i64 %v6547, 4611686018427387907
  store i64 %op6548, ptr %slot1159, align 8
  %v6549 = load i64, ptr %slot1159, align 8
  %cmp6550 = icmp eq i64 %v6549, 0
  %cv6551 = zext i1 %cmp6550 to i32
  store i32 %cv6551, ptr %slot1160, align 8
  %v6552 = load i32, ptr %slot1160, align 8
  %cv6553 = zext i32 %v6552 to i64
  %cond6554 = icmp ne i64 %cv6553, 0
  br i1 %cond6554, label %bb_rcs1656, label %bb_rcsendslow1606
bb_rcs1656:
  %v6555 = load i64, ptr %slot1155, align 8
  %op6556 = sub i64 %v6555, 24
  store i64 %op6556, ptr %slot1161, align 8
  %v6557 = load i64, ptr %slot1155, align 8
  %p6558 = inttoptr i64 %v6557 to ptr
  %rgep6559 = getelementptr i8, ptr %p6558, i64 -24
  %ld6560 = load i64, ptr %rgep6559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6560, ptr %slot1162, align 8
  %v6561 = load i64, ptr %slot1162, align 8
  %cmp6562 = icmp ne i64 %v6561, 0
  %cv6563 = zext i1 %cmp6562 to i32
  store i32 %cv6563, ptr %slot1163, align 8
  %v6564 = load i32, ptr %slot1163, align 8
  %cv6565 = zext i32 %v6564 to i64
  %cond6566 = icmp ne i64 %cv6565, 0
  br i1 %cond6566, label %bb_rcs1660, label %bb_rcsendslow1606
bb_rcs1660:
  %v6567 = load i64, ptr %slot1155, align 8
  %op6568 = sub i64 %v6567, 32
  store i64 %op6568, ptr %slot1164, align 8
  %v6569 = load i64, ptr %slot1155, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  %rgep6571 = getelementptr i8, ptr %p6570, i64 -32
  %ld6572 = load i64, ptr %rgep6571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6572, ptr %slot1165, align 8
  %v6573 = load i64, ptr %slot1162, align 8
  %cmp6574 = icmp ugt i64 %v6573, 1
  %cv6575 = zext i1 %cmp6574 to i32
  store i32 %cv6575, ptr %slot1166, align 8
  %v6576 = load i64, ptr %slot1165, align 8
  %cmp6577 = icmp ne i64 %v6576, 0
  %cv6578 = zext i1 %cmp6577 to i32
  store i32 %cv6578, ptr %slot1167, align 8
  %v6579 = load i32, ptr %slot1166, align 8
  %v6580 = load i32, ptr %slot1167, align 8
  %op6581 = or i32 %v6579, %v6580
  store i32 %op6581, ptr %slot1168, align 8
  %v6582 = load i32, ptr %slot1168, align 8
  %cv6583 = zext i32 %v6582 to i64
  %cond6584 = icmp ne i64 %cv6583, 0
  br i1 %cond6584, label %bb_rcs1666, label %bb_rcsendslow1606
bb_rcs1666:
  br label %bb_rcsendcommit1606
bb_rcsendcommit1606:
  %v6585 = load i64, ptr %slot1131, align 8
  %op6586 = add i64 %v6585, 24
  store i64 %op6586, ptr %slot1169, align 8
  %v6587 = load i64, ptr %slot1169, align 8
  %p6588 = inttoptr i64 %v6587 to ptr
  %ld6589 = load i32, ptr %p6588, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld6589, ptr %slot1170, align 8
  %v6590 = load i32, ptr %slot1170, align 8
  %cv6591 = zext i32 %v6590 to i64
  %cond6592 = icmp ne i64 %cv6591, 0
  br i1 %cond6592, label %bb_rcsendrestore1606, label %bb_rcsendreturned1606
bb_rcsendrestore1606:
  %v6593 = load i64, ptr %slot1131, align 8
  %op6594 = add i64 %v6593, 16
  store i64 %op6594, ptr %slot1171, align 8
  %v6595 = load i64, ptr %slot1171, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %ld6597 = load i64, ptr %p6596, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6597, ptr %slot1172, align 8
  %v6598 = load i64, ptr %slot1143, align 8
  %op6599 = and i64 %v6598, 17293822569102704639
  store i64 %op6599, ptr %slot1173, align 8
  %v6600 = load i64, ptr %slot1173, align 8
  %v6601 = load i64, ptr %slot1172, align 8
  %op6602 = or i64 %v6600, %v6601
  store i64 %op6602, ptr %slot1174, align 8
  %v6603 = load i64, ptr %slot1140, align 8
  %op6604 = sub i64 %v6603, 16
  store i64 %op6604, ptr %slot1175, align 8
  %v6605 = load i64, ptr %slot1174, align 8
  %v6606 = load i64, ptr %slot1140, align 8
  %p6607 = inttoptr i64 %v6606 to ptr
  %rgep6608 = getelementptr i8, ptr %p6607, i64 -16
  store i64 %v6605, ptr %rgep6608, align 8, !alias.scope !9, !noalias !10
  %v6609 = load i64, ptr %slot1119, align 8
  %p6611 = inttoptr i64 %v6609 to ptr
  %gep6612 = getelementptr i8, ptr %p6611, i64 16
  %op6610 = ptrtoint ptr %gep6612 to i64
  store i64 %op6610, ptr %slot1176, align 8
  br label %bb_rcsendreturned1606
bb_rcsendreturned1606:
  %v6613 = load i64, ptr %slot1176, align 8
  %p6614 = inttoptr i64 %v6613 to ptr
  store i64 0, ptr %p6614, align 8, !alias.scope !3, !noalias !4
  %v6615 = load i64, ptr %slot1123, align 8
  %op6616 = add i64 %v6615, 256
  store i64 %op6616, ptr %slot1177, align 8
  %v6617 = load i64, ptr %slot1177, align 8
  %p6618 = inttoptr i64 %v6617 to ptr
  %ld6619 = load i64, ptr %p6618, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6619, ptr %slot1178, align 8
  %v6620 = load i64, ptr %slot1131, align 8
  %op6621 = add i64 %v6620, 0
  store i64 %op6621, ptr %slot1179, align 8
  %v6622 = load i64, ptr %slot1178, align 8
  %v6623 = load i64, ptr %slot1179, align 8
  %p6624 = inttoptr i64 %v6623 to ptr
  store i64 %v6622, ptr %p6624, align 8, !alias.scope !9999998, !noalias !9999999
  %v6625 = load i64, ptr %slot1123, align 8
  %op6626 = add i64 %v6625, 256
  store i64 %op6626, ptr %slot1180, align 8
  %v6627 = load i64, ptr %slot1131, align 8
  %v6628 = load i64, ptr %slot1180, align 8
  %p6629 = inttoptr i64 %v6628 to ptr
  store i64 %v6627, ptr %p6629, align 8, !alias.scope !9999998, !noalias !9999999
  %v6630 = load i64, ptr %slot1123, align 8
  %op6631 = add i64 %v6630, 264
  store i64 %op6631, ptr %slot1181, align 8
  %v6632 = load i64, ptr %slot1181, align 8
  %p6633 = inttoptr i64 %v6632 to ptr
  %ld6634 = load i64, ptr %p6633, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6634, ptr %slot1182, align 8
  %v6635 = load i64, ptr %slot1182, align 8
  %op6636 = add i64 %v6635, 1
  store i64 %op6636, ptr %slot1183, align 8
  %v6637 = load i64, ptr %slot1183, align 8
  %v6638 = load i64, ptr %slot1181, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  store i64 %v6637, ptr %p6639, align 8, !alias.scope !9999998, !noalias !9999999
  %v6640 = load i64, ptr %slot71, align 8
  %p6642 = inttoptr i64 %v6640 to ptr
  %gep6643 = getelementptr i8, ptr %p6642, i64 24
  %op6641 = ptrtoint ptr %gep6643 to i64
  store i64 %op6641, ptr %slot1184, align 8
  %v6644 = load i64, ptr %slot1184, align 8
  %p6645 = inttoptr i64 %v6644 to ptr
  %ld6646 = load i64, ptr %p6645, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6646, ptr %slot1185, align 8
  %v6647 = load i64, ptr %slot1185, align 8
  %op6648 = add i64 %v6647, 18446744073709551576
  store i64 %op6648, ptr %slot1186, align 8
  %v6649 = load i64, ptr %slot1186, align 8
  %v6650 = load i64, ptr %slot1184, align 8
  %p6651 = inttoptr i64 %v6650 to ptr
  store i64 %v6649, ptr %p6651, align 8, !alias.scope !9999998, !noalias !9999999
  %v6652 = load i64, ptr %slot1123, align 8
  %op6653 = add i64 %v6652, 48
  store i64 %op6653, ptr %slot1187, align 8
  %v6654 = load i64, ptr %slot1187, align 8
  %p6655 = inttoptr i64 %v6654 to ptr
  %ld6656 = load i64, ptr %p6655, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6656, ptr %slot1188, align 8
  %v6657 = load i64, ptr %slot1188, align 8
  %op6658 = add i64 %v6657, 18446744073709551576
  store i64 %op6658, ptr %slot1189, align 8
  %v6659 = load i64, ptr %slot1189, align 8
  %v6660 = load i64, ptr %slot1187, align 8
  %p6661 = inttoptr i64 %v6660 to ptr
  store i64 %v6659, ptr %p6661, align 8, !alias.scope !9999998, !noalias !9999999
  %v6662 = load i64, ptr %slot1155, align 8
  %cmp6663 = icmp ne i64 %v6662, 0
  %cv6664 = zext i1 %cmp6663 to i32
  store i32 %cv6664, ptr %slot1190, align 8
  %v6665 = load i32, ptr %slot1190, align 8
  %cv6666 = zext i32 %v6665 to i64
  %cond6667 = icmp ne i64 %cv6666, 0
  br i1 %cond6667, label %bb_rcsenddropbacking1606, label %bb_rcsenddroppayload1606
bb_rcsenddropbacking1606:
  %v6668 = load i64, ptr %slot1155, align 8
  %op6669 = sub i64 %v6668, 24
  store i64 %op6669, ptr %slot1191, align 8
  %v6670 = load i64, ptr %slot1155, align 8
  %p6671 = inttoptr i64 %v6670 to ptr
  %rgep6672 = getelementptr i8, ptr %p6671, i64 -24
  %ld6673 = load i64, ptr %rgep6672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6673, ptr %slot1192, align 8
  %v6674 = load i64, ptr %slot1192, align 8
  %op6675 = add i64 %v6674, 18446744073709551615
  store i64 %op6675, ptr %slot1193, align 8
  %v6676 = load i64, ptr %slot1193, align 8
  %v6677 = load i64, ptr %slot1155, align 8
  %p6678 = inttoptr i64 %v6677 to ptr
  %rgep6679 = getelementptr i8, ptr %p6678, i64 -24
  store i64 %v6676, ptr %rgep6679, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1606
bb_rcsenddroppayload1606:
  %v6680 = load i64, ptr %slot1140, align 8
  %op6681 = sub i64 %v6680, 24
  store i64 %op6681, ptr %slot1194, align 8
  %v6682 = load i64, ptr %slot1140, align 8
  %p6683 = inttoptr i64 %v6682 to ptr
  %rgep6684 = getelementptr i8, ptr %p6683, i64 -24
  %ld6685 = load i64, ptr %rgep6684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6685, ptr %slot1195, align 8
  %v6686 = load i64, ptr %slot1195, align 8
  %op6687 = add i64 %v6686, 18446744073709551615
  store i64 %op6687, ptr %slot1196, align 8
  %v6688 = load i64, ptr %slot1196, align 8
  %v6689 = load i64, ptr %slot1140, align 8
  %p6690 = inttoptr i64 %v6689 to ptr
  %rgep6691 = getelementptr i8, ptr %p6690, i64 -24
  store i64 %v6688, ptr %rgep6691, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1606
bb_rcsendunlink1606:
  %v6692 = load i64, ptr %slot1119, align 8
  %p6694 = inttoptr i64 %v6692 to ptr
  %gep6695 = getelementptr i8, ptr %p6694, i64 8
  %op6693 = ptrtoint ptr %gep6695 to i64
  store i64 %op6693, ptr %slot1197, align 8
  %v6696 = load i64, ptr %slot1197, align 8
  %p6697 = inttoptr i64 %v6696 to ptr
  %ld6698 = load i64, ptr %p6697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6698, ptr %slot1198, align 8
  %v6699 = load i64, ptr %slot1123, align 8
  %op6700 = add i64 %v6699, 248
  store i64 %op6700, ptr %slot1199, align 8
  %v6701 = load i64, ptr %slot1198, align 8
  %v6702 = load i64, ptr %slot1199, align 8
  %p6703 = inttoptr i64 %v6702 to ptr
  store i64 %v6701, ptr %p6703, align 8, !alias.scope !9999998, !noalias !9999999
  %v6704 = load i64, ptr %slot1119, align 8
  %p6706 = inttoptr i64 %v6704 to ptr
  %gep6707 = getelementptr i8, ptr %p6706, i64 24
  %op6705 = ptrtoint ptr %gep6707 to i64
  store i64 %op6705, ptr %slot1200, align 8
  %v6708 = load i64, ptr %slot1119, align 8
  %p6710 = inttoptr i64 %v6708 to ptr
  %gep6711 = getelementptr i8, ptr %p6710, i64 8
  %op6709 = ptrtoint ptr %gep6711 to i64
  store i64 %op6709, ptr %slot1201, align 8
  %v6712 = load i64, ptr %slot1200, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  store i32 0, ptr %p6713, align 4, !alias.scope !3, !noalias !4
  %v6714 = load i64, ptr %slot1201, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  store i64 0, ptr %p6715, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1606
bb_rcsendslow1606:
  %v6716 = load i64, ptr %slot1, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  %v6718 = load i64, ptr %slot1119, align 8
  %p6719 = inttoptr i64 %v6718 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p6717, ptr %p6719) nomerge, !dbg !204
  br label %bb_rcsenddone1606
bb_rcsenddone1606:
  %v6720 = load i64, ptr %slot58, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  store i64 0, ptr %p6721, align 8, !alias.scope !3, !noalias !4
  %v6722 = load i64, ptr %slot37, align 8
  %v6723 = load i64, ptr %slot58, align 8
  %p6724 = inttoptr i64 %v6723 to ptr
  store i64 %v6722, ptr %p6724, align 8, !alias.scope !3, !noalias !4
  %v6725 = load i64, ptr %slot58, align 8
  %p6726 = inttoptr i64 %v6725 to ptr
  %ld6727 = load i64, ptr %p6726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6727, ptr %slot1202, align 8
  %v6728 = load i64, ptr %slot1202, align 8
  %v6729 = load i64, ptr %slot57, align 8
  %p6730 = inttoptr i64 %v6728 to ptr
  %p6731 = inttoptr i64 %v6729 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6731, ptr %p6730, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v6732 = load i64, ptr %slot34, align 8
  %p6733 = inttoptr i64 %v6732 to ptr
  %ld6734 = load i64, ptr %p6733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6734, ptr %slot1203, align 8
  %v6735 = load i64, ptr %slot1203, align 8
  %v6736 = load i64, ptr %slot58, align 8
  %p6737 = inttoptr i64 %v6736 to ptr
  store i64 %v6735, ptr %p6737, align 8, !alias.scope !3, !noalias !4
  %v6738 = load i64, ptr %slot58, align 8
  %p6739 = inttoptr i64 %v6738 to ptr
  %ld6740 = load i64, ptr %p6739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6740, ptr %slot1204, align 8
  %v6741 = load i64, ptr %slot20, align 8
  %p6742 = inttoptr i64 %v6741 to ptr
  %ld6743 = load i32, ptr %p6742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6743, ptr %slot1205, align 8
  %v6744 = load i64, ptr %slot21, align 8
  %p6745 = inttoptr i64 %v6744 to ptr
  %ld6746 = load i32, ptr %p6745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6746, ptr %slot1206, align 8
  %v6747 = load i32, ptr %slot1206, align 8
  %op6748 = and i32 %v6747, 24
  store i32 %op6748, ptr %slot1206, align 8
  %v6749 = load i32, ptr %slot1206, align 8
  %cmp6750 = icmp eq i32 %v6749, 0
  %cv6751 = zext i1 %cmp6750 to i32
  store i32 %cv6751, ptr %slot1207, align 8
  %v6752 = load i32, ptr %slot1205, align 8
  %v6753 = load i32, ptr %slot1207, align 8
  %op6754 = and i32 %v6752, %v6753
  store i32 %op6754, ptr %slot1208, align 8
  %v6755 = load i32, ptr %slot1208, align 8
  %cv6756 = zext i32 %v6755 to i64
  %cond6757 = icmp ne i64 %cv6756, 0
  br i1 %cond6757, label %bb_rcprivateown1709, label %bb_rcprivateloan1709
bb_rcprivateown1709:
  %v6758 = load i64, ptr %slot30, align 8
  store i64 %v6758, ptr %slot1209, align 8
  %v6759 = load i64, ptr %slot72, align 8
  store i64 %v6759, ptr %slot1210, align 8
  %v6760 = load i64, ptr %slot71, align 8
  %v6761 = load i64, ptr %slot1209, align 8
  %v6762 = load i64, ptr %slot1204, align 8
  %v6763 = load i64, ptr %slot1210, align 8
  %cv6764 = trunc i64 %v6763 to i32
  %call6765 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v6760, i64 %v6761, i64 %v6762, i32 %cv6764) nomerge, !dbg !206
  store i32 %call6765, ptr %slot1211, align 8
  %v6766 = load i32, ptr %slot1211, align 8
  %cv6767 = zext i32 %v6766 to i64
  %cond6768 = icmp ne i64 %cv6767, 0
  br i1 %cond6768, label %bb_rcsuccess1713, label %bb_rcfailure1713
bb_rcfailure1713:
  %v6769 = load i64, ptr %slot71, align 8
  %p6770 = inttoptr i64 %v6769 to ptr
  %call6771 = call i32 @myl_rc_take_failure(ptr %p6770) nomerge, !dbg !206
  store i32 %call6771, ptr %slot1212, align 8
  %v6772 = load i64, ptr %slot1, align 8
  %p6773 = inttoptr i64 %v6772 to ptr
  %v6774 = load i32, ptr %slot1212, align 8
  %call6775 = call i32 @myl_qbe_rc_status(ptr %p6773, i32 %v6774) nomerge, !dbg !206
  store i32 %call6775, ptr %slot1213, align 8
  br label %bb_failure
bb_rcsuccess1713:
  %v6776 = load i64, ptr %slot20, align 8
  %p6777 = inttoptr i64 %v6776 to ptr
  store i32 0, ptr %p6777, align 4, !alias.scope !3, !noalias !4
  %v6778 = load i64, ptr %slot25, align 8
  %p6779 = inttoptr i64 %v6778 to ptr
  store i32 2, ptr %p6779, align 4, !alias.scope !3, !noalias !4
  %v6780 = load i64, ptr %slot24, align 8
  %p6781 = inttoptr i64 %v6780 to ptr
  store i32 1, ptr %p6781, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1709
bb_rcprivateloan1709:
  %v6782 = load i64, ptr %slot30, align 8
  store i64 %v6782, ptr %slot1214, align 8
  %v6783 = load i64, ptr %slot71, align 8
  %v6784 = load i64, ptr %slot1214, align 8
  %v6785 = load i64, ptr %slot1204, align 8
  %call6786 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_loan(i64 %v6783, i64 %v6784, i64 %v6785) nomerge, !dbg !206
  store i32 %call6786, ptr %slot1215, align 8
  %v6787 = load i32, ptr %slot1215, align 8
  %cv6788 = zext i32 %v6787 to i64
  %cond6789 = icmp ne i64 %cv6788, 0
  br i1 %cond6789, label %bb_rcsuccess1721, label %bb_rcfailure1721
bb_rcfailure1721:
  %v6790 = load i64, ptr %slot71, align 8
  %p6791 = inttoptr i64 %v6790 to ptr
  %call6792 = call i32 @myl_rc_take_failure(ptr %p6791) nomerge, !dbg !206
  store i32 %call6792, ptr %slot1216, align 8
  %v6793 = load i64, ptr %slot1, align 8
  %p6794 = inttoptr i64 %v6793 to ptr
  %v6795 = load i32, ptr %slot1216, align 8
  %call6796 = call i32 @myl_qbe_rc_status(ptr %p6794, i32 %v6795) nomerge, !dbg !206
  store i32 %call6796, ptr %slot1217, align 8
  br label %bb_failure
bb_rcsuccess1721:
  %v6797 = load i64, ptr %slot25, align 8
  %p6798 = inttoptr i64 %v6797 to ptr
  store i32 2, ptr %p6798, align 4, !alias.scope !3, !noalias !4
  %v6799 = load i64, ptr %slot25, align 8
  %p6800 = inttoptr i64 %v6799 to ptr
  store i32 16, ptr %p6800, align 4, !alias.scope !3, !noalias !4
  %v6801 = load i64, ptr %slot24, align 8
  %p6802 = inttoptr i64 %v6801 to ptr
  store i32 1, ptr %p6802, align 4, !alias.scope !3, !noalias !4
  %v6803 = load i64, ptr %slot20, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  %ld6805 = load i32, ptr %p6804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6805, ptr %slot1218, align 8
  %v6806 = load i32, ptr %slot1218, align 8
  %cv6807 = zext i32 %v6806 to i64
  %cond6808 = icmp ne i64 %cv6807, 0
  br i1 %cond6808, label %bb_rcslotdrop1729, label %bb_rcslotdone1729
bb_rcslotdrop1729:
  %v6809 = load i64, ptr %slot20, align 8
  %p6810 = inttoptr i64 %v6809 to ptr
  store i32 0, ptr %p6810, align 4, !alias.scope !3, !noalias !4
  %v6811 = load i64, ptr %slot27, align 8
  store i64 %v6811, ptr %slot1219, align 8
  %v6812 = load i64, ptr %slot21, align 8
  %p6813 = inttoptr i64 %v6812 to ptr
  %ld6814 = load i32, ptr %p6813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6814, ptr %slot1220, align 8
  %v6815 = load i32, ptr %slot1220, align 8
  %op6816 = and i32 %v6815, 28
  store i32 %op6816, ptr %slot1221, align 8
  %v6817 = load i32, ptr %slot1221, align 8
  %cv6818 = zext i32 %v6817 to i64
  %cond6819 = icmp ne i64 %cv6818, 0
  br i1 %cond6819, label %bb_rcslotrole1729, label %bb_rcslotowner1729
bb_rcslotrole1729:
  %v6820 = load i64, ptr %slot71, align 8
  store i64 %v6820, ptr %slot1222, align 8
  %v6821 = load i64, ptr %slot1222, align 8
  %v6822 = load i64, ptr %slot1219, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v6821, i64 %v6822) nomerge, !dbg !206
  br label %bb_rcslotdone1729
bb_rcslotowner1729:
  %v6823 = load i64, ptr %slot71, align 8
  store i64 %v6823, ptr %slot1223, align 8
  %v6824 = load i64, ptr %slot1223, align 8
  %v6825 = load i64, ptr %slot1219, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v6824, i64 %v6825) nomerge, !dbg !206
  br label %bb_rcslotdone1729
bb_rcslotdone1729:
  br label %bb_rcprivateprepared1709
bb_rcprivateprepared1709:
  %v6826 = load i64, ptr %slot18, align 8
  %p6827 = inttoptr i64 %v6826 to ptr
  %ld6828 = load i32, ptr %p6827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6828, ptr %slot1224, align 8
  %v6829 = load i32, ptr %slot1224, align 8
  %cv6830 = zext i32 %v6829 to i64
  %cond6831 = icmp ne i64 %cv6830, 0
  br i1 %cond6831, label %bb_rcslotdrop1739, label %bb_rcslotdone1739
bb_rcslotdrop1739:
  %v6832 = load i64, ptr %slot18, align 8
  %p6833 = inttoptr i64 %v6832 to ptr
  store i32 0, ptr %p6833, align 4, !alias.scope !3, !noalias !4
  %v6834 = load i64, ptr %slot56, align 8
  store i64 %v6834, ptr %slot1225, align 8
  %v6835 = load i64, ptr %slot19, align 8
  %p6836 = inttoptr i64 %v6835 to ptr
  %ld6837 = load i32, ptr %p6836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6837, ptr %slot1226, align 8
  %v6838 = load i32, ptr %slot1226, align 8
  %op6839 = and i32 %v6838, 28
  store i32 %op6839, ptr %slot1227, align 8
  %v6840 = load i32, ptr %slot1227, align 8
  %cv6841 = zext i32 %v6840 to i64
  %cond6842 = icmp ne i64 %cv6841, 0
  br i1 %cond6842, label %bb_rcslotrole1739, label %bb_rcslotowner1739
bb_rcslotrole1739:
  %v6843 = load i64, ptr %slot71, align 8
  store i64 %v6843, ptr %slot1228, align 8
  %v6844 = load i64, ptr %slot1228, align 8
  %v6845 = load i64, ptr %slot1225, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v6844, i64 %v6845) nomerge, !dbg !206
  br label %bb_rcslotdone1739
bb_rcslotowner1739:
  %v6846 = load i64, ptr %slot71, align 8
  store i64 %v6846, ptr %slot1229, align 8
  %v6847 = load i64, ptr %slot1229, align 8
  %v6848 = load i64, ptr %slot1225, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v6847, i64 %v6848) nomerge, !dbg !206
  br label %bb_rcslotdone1739
bb_rcslotdone1739:
  %v6849 = load i64, ptr %slot56, align 8
  store i64 %v6849, ptr %slot1230, align 8
  %v6850 = load i64, ptr %slot30, align 8
  store i64 %v6850, ptr %slot1231, align 8
  %v6851 = load i64, ptr %slot1231, align 8
  %v6852 = load i64, ptr %slot1230, align 8
  %p6853 = inttoptr i64 %v6851 to ptr
  %p6854 = inttoptr i64 %v6852 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6854, ptr %p6853, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v6855 = load i64, ptr %slot24, align 8
  %p6856 = inttoptr i64 %v6855 to ptr
  store i32 0, ptr %p6856, align 4, !alias.scope !3, !noalias !4
  %v6857 = load i64, ptr %slot19, align 8
  %p6858 = inttoptr i64 %v6857 to ptr
  store i32 2, ptr %p6858, align 4, !alias.scope !3, !noalias !4
  %v6859 = load i64, ptr %slot25, align 8
  %p6860 = inttoptr i64 %v6859 to ptr
  %ld6861 = load i32, ptr %p6860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6861, ptr %slot1232, align 8
  %v6862 = load i32, ptr %slot1232, align 8
  %v6863 = load i64, ptr %slot19, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  store i32 %v6862, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  %v6865 = load i64, ptr %slot18, align 8
  %p6866 = inttoptr i64 %v6865 to ptr
  store i32 1, ptr %p6866, align 4, !alias.scope !3, !noalias !4
  %v6867 = load i64, ptr %slot34, align 8
  %p6868 = inttoptr i64 %v6867 to ptr
  %ld6869 = load i64, ptr %p6868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6869, ptr %slot1233, align 8
  %v6870 = load i64, ptr %slot1233, align 8
  %v6871 = load i64, ptr %slot58, align 8
  %p6872 = inttoptr i64 %v6871 to ptr
  store i64 %v6870, ptr %p6872, align 8, !alias.scope !3, !noalias !4
  %v6873 = load i64, ptr %slot58, align 8
  %p6874 = inttoptr i64 %v6873 to ptr
  %ld6875 = load i64, ptr %p6874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6875, ptr %slot1234, align 8
  %v6876 = load i64, ptr %slot20, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  %ld6878 = load i32, ptr %p6877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6878, ptr %slot1235, align 8
  %v6879 = load i64, ptr %slot21, align 8
  %p6880 = inttoptr i64 %v6879 to ptr
  %ld6881 = load i32, ptr %p6880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6881, ptr %slot1236, align 8
  %v6882 = load i32, ptr %slot1236, align 8
  %op6883 = and i32 %v6882, 24
  store i32 %op6883, ptr %slot1236, align 8
  %v6884 = load i32, ptr %slot1236, align 8
  %cmp6885 = icmp eq i32 %v6884, 0
  %cv6886 = zext i1 %cmp6885 to i32
  store i32 %cv6886, ptr %slot1237, align 8
  %v6887 = load i32, ptr %slot1235, align 8
  %v6888 = load i32, ptr %slot1237, align 8
  %op6889 = and i32 %v6887, %v6888
  store i32 %op6889, ptr %slot1238, align 8
  %v6890 = load i32, ptr %slot1238, align 8
  %cv6891 = zext i32 %v6890 to i64
  %cond6892 = icmp ne i64 %cv6891, 0
  br i1 %cond6892, label %bb_rcprivateown1761, label %bb_rcprivateloan1761
bb_rcprivateown1761:
  %v6893 = load i64, ptr %slot30, align 8
  store i64 %v6893, ptr %slot1239, align 8
  %v6894 = load i64, ptr %slot72, align 8
  store i64 %v6894, ptr %slot1240, align 8
  %v6895 = load i64, ptr %slot71, align 8
  %v6896 = load i64, ptr %slot1239, align 8
  %v6897 = load i64, ptr %slot1234, align 8
  %v6898 = load i64, ptr %slot1240, align 8
  %cv6899 = trunc i64 %v6898 to i32
  %call6900 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v6895, i64 %v6896, i64 %v6897, i32 %cv6899) nomerge, !dbg !208
  store i32 %call6900, ptr %slot1241, align 8
  %v6901 = load i32, ptr %slot1241, align 8
  %cv6902 = zext i32 %v6901 to i64
  %cond6903 = icmp ne i64 %cv6902, 0
  br i1 %cond6903, label %bb_rcsuccess1765, label %bb_rcfailure1765
bb_rcfailure1765:
  %v6904 = load i64, ptr %slot71, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  %call6906 = call i32 @myl_rc_take_failure(ptr %p6905) nomerge, !dbg !208
  store i32 %call6906, ptr %slot1242, align 8
  %v6907 = load i64, ptr %slot1, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  %v6909 = load i32, ptr %slot1242, align 8
  %call6910 = call i32 @myl_qbe_rc_status(ptr %p6908, i32 %v6909) nomerge, !dbg !208
  store i32 %call6910, ptr %slot1243, align 8
  br label %bb_failure
bb_rcsuccess1765:
  %v6911 = load i64, ptr %slot20, align 8
  %p6912 = inttoptr i64 %v6911 to ptr
  store i32 0, ptr %p6912, align 4, !alias.scope !3, !noalias !4
  %v6913 = load i64, ptr %slot25, align 8
  %p6914 = inttoptr i64 %v6913 to ptr
  store i32 2, ptr %p6914, align 4, !alias.scope !3, !noalias !4
  %v6915 = load i64, ptr %slot24, align 8
  %p6916 = inttoptr i64 %v6915 to ptr
  store i32 1, ptr %p6916, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1761
bb_rcprivateloan1761:
  %v6917 = load i64, ptr %slot30, align 8
  store i64 %v6917, ptr %slot1244, align 8
  %v6918 = load i64, ptr %slot71, align 8
  %v6919 = load i64, ptr %slot1244, align 8
  %v6920 = load i64, ptr %slot1234, align 8
  %call6921 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_loan(i64 %v6918, i64 %v6919, i64 %v6920) nomerge, !dbg !208
  store i32 %call6921, ptr %slot1245, align 8
  %v6922 = load i32, ptr %slot1245, align 8
  %cv6923 = zext i32 %v6922 to i64
  %cond6924 = icmp ne i64 %cv6923, 0
  br i1 %cond6924, label %bb_rcsuccess1773, label %bb_rcfailure1773
bb_rcfailure1773:
  %v6925 = load i64, ptr %slot71, align 8
  %p6926 = inttoptr i64 %v6925 to ptr
  %call6927 = call i32 @myl_rc_take_failure(ptr %p6926) nomerge, !dbg !208
  store i32 %call6927, ptr %slot1246, align 8
  %v6928 = load i64, ptr %slot1, align 8
  %p6929 = inttoptr i64 %v6928 to ptr
  %v6930 = load i32, ptr %slot1246, align 8
  %call6931 = call i32 @myl_qbe_rc_status(ptr %p6929, i32 %v6930) nomerge, !dbg !208
  store i32 %call6931, ptr %slot1247, align 8
  br label %bb_failure
bb_rcsuccess1773:
  %v6932 = load i64, ptr %slot25, align 8
  %p6933 = inttoptr i64 %v6932 to ptr
  store i32 2, ptr %p6933, align 4, !alias.scope !3, !noalias !4
  %v6934 = load i64, ptr %slot25, align 8
  %p6935 = inttoptr i64 %v6934 to ptr
  store i32 16, ptr %p6935, align 4, !alias.scope !3, !noalias !4
  %v6936 = load i64, ptr %slot24, align 8
  %p6937 = inttoptr i64 %v6936 to ptr
  store i32 1, ptr %p6937, align 4, !alias.scope !3, !noalias !4
  %v6938 = load i64, ptr %slot20, align 8
  %p6939 = inttoptr i64 %v6938 to ptr
  %ld6940 = load i32, ptr %p6939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6940, ptr %slot1248, align 8
  %v6941 = load i32, ptr %slot1248, align 8
  %cv6942 = zext i32 %v6941 to i64
  %cond6943 = icmp ne i64 %cv6942, 0
  br i1 %cond6943, label %bb_rcslotdrop1781, label %bb_rcslotdone1781
bb_rcslotdrop1781:
  %v6944 = load i64, ptr %slot20, align 8
  %p6945 = inttoptr i64 %v6944 to ptr
  store i32 0, ptr %p6945, align 4, !alias.scope !3, !noalias !4
  %v6946 = load i64, ptr %slot27, align 8
  store i64 %v6946, ptr %slot1249, align 8
  %v6947 = load i64, ptr %slot21, align 8
  %p6948 = inttoptr i64 %v6947 to ptr
  %ld6949 = load i32, ptr %p6948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6949, ptr %slot1250, align 8
  %v6950 = load i32, ptr %slot1250, align 8
  %op6951 = and i32 %v6950, 28
  store i32 %op6951, ptr %slot1251, align 8
  %v6952 = load i32, ptr %slot1251, align 8
  %cv6953 = zext i32 %v6952 to i64
  %cond6954 = icmp ne i64 %cv6953, 0
  br i1 %cond6954, label %bb_rcslotrole1781, label %bb_rcslotowner1781
bb_rcslotrole1781:
  %v6955 = load i64, ptr %slot71, align 8
  store i64 %v6955, ptr %slot1252, align 8
  %v6956 = load i64, ptr %slot1252, align 8
  %v6957 = load i64, ptr %slot1249, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v6956, i64 %v6957) nomerge, !dbg !208
  br label %bb_rcslotdone1781
bb_rcslotowner1781:
  %v6958 = load i64, ptr %slot71, align 8
  store i64 %v6958, ptr %slot1253, align 8
  %v6959 = load i64, ptr %slot1253, align 8
  %v6960 = load i64, ptr %slot1249, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v6959, i64 %v6960) nomerge, !dbg !208
  br label %bb_rcslotdone1781
bb_rcslotdone1781:
  br label %bb_rcprivateprepared1761
bb_rcprivateprepared1761:
  %v6961 = load i64, ptr %slot18, align 8
  %p6962 = inttoptr i64 %v6961 to ptr
  %ld6963 = load i32, ptr %p6962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6963, ptr %slot1254, align 8
  %v6964 = load i32, ptr %slot1254, align 8
  %cv6965 = zext i32 %v6964 to i64
  %cond6966 = icmp ne i64 %cv6965, 0
  br i1 %cond6966, label %bb_rcslotdrop1791, label %bb_rcslotdone1791
bb_rcslotdrop1791:
  %v6967 = load i64, ptr %slot18, align 8
  %p6968 = inttoptr i64 %v6967 to ptr
  store i32 0, ptr %p6968, align 4, !alias.scope !3, !noalias !4
  %v6969 = load i64, ptr %slot56, align 8
  store i64 %v6969, ptr %slot1255, align 8
  %v6970 = load i64, ptr %slot19, align 8
  %p6971 = inttoptr i64 %v6970 to ptr
  %ld6972 = load i32, ptr %p6971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6972, ptr %slot1256, align 8
  %v6973 = load i32, ptr %slot1256, align 8
  %op6974 = and i32 %v6973, 28
  store i32 %op6974, ptr %slot1257, align 8
  %v6975 = load i32, ptr %slot1257, align 8
  %cv6976 = zext i32 %v6975 to i64
  %cond6977 = icmp ne i64 %cv6976, 0
  br i1 %cond6977, label %bb_rcslotrole1791, label %bb_rcslotowner1791
bb_rcslotrole1791:
  %v6978 = load i64, ptr %slot71, align 8
  store i64 %v6978, ptr %slot1258, align 8
  %v6979 = load i64, ptr %slot1258, align 8
  %v6980 = load i64, ptr %slot1255, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v6979, i64 %v6980) nomerge, !dbg !208
  br label %bb_rcslotdone1791
bb_rcslotowner1791:
  %v6981 = load i64, ptr %slot71, align 8
  store i64 %v6981, ptr %slot1259, align 8
  %v6982 = load i64, ptr %slot1259, align 8
  %v6983 = load i64, ptr %slot1255, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v6982, i64 %v6983) nomerge, !dbg !208
  br label %bb_rcslotdone1791
bb_rcslotdone1791:
  %v6984 = load i64, ptr %slot56, align 8
  store i64 %v6984, ptr %slot1260, align 8
  %v6985 = load i64, ptr %slot30, align 8
  store i64 %v6985, ptr %slot1261, align 8
  %v6986 = load i64, ptr %slot1261, align 8
  %v6987 = load i64, ptr %slot1260, align 8
  %p6988 = inttoptr i64 %v6986 to ptr
  %p6989 = inttoptr i64 %v6987 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6989, ptr %p6988, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v6990 = load i64, ptr %slot24, align 8
  %p6991 = inttoptr i64 %v6990 to ptr
  store i32 0, ptr %p6991, align 4, !alias.scope !3, !noalias !4
  %v6992 = load i64, ptr %slot19, align 8
  %p6993 = inttoptr i64 %v6992 to ptr
  store i32 2, ptr %p6993, align 4, !alias.scope !3, !noalias !4
  %v6994 = load i64, ptr %slot25, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %ld6996 = load i32, ptr %p6995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6996, ptr %slot1262, align 8
  %v6997 = load i32, ptr %slot1262, align 8
  %v6998 = load i64, ptr %slot19, align 8
  %p6999 = inttoptr i64 %v6998 to ptr
  store i32 %v6997, ptr %p6999, align 4, !alias.scope !3, !noalias !4
  %v7000 = load i64, ptr %slot18, align 8
  %p7001 = inttoptr i64 %v7000 to ptr
  store i32 1, ptr %p7001, align 4, !alias.scope !3, !noalias !4
  %v7002 = load i64, ptr %slot56, align 8
  %v7003 = load i64, ptr %slot58, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  store i64 %v7002, ptr %p7004, align 8, !alias.scope !3, !noalias !4
  %v7005 = load i64, ptr %slot57, align 8
  %v7006 = load i64, ptr %slot59, align 8
  %p7007 = inttoptr i64 %v7006 to ptr
  store i64 %v7005, ptr %p7007, align 8, !alias.scope !3, !noalias !4
  %v7008 = load i64, ptr %slot58, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  %ld7010 = load i64, ptr %p7009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7010, ptr %slot1263, align 8
  %v7011 = load i64, ptr %slot20, align 8
  %p7012 = inttoptr i64 %v7011 to ptr
  %ld7013 = load i32, ptr %p7012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7013, ptr %slot1264, align 8
  %v7014 = load i64, ptr %slot21, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  %ld7016 = load i32, ptr %p7015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7016, ptr %slot1265, align 8
  %v7017 = load i32, ptr %slot1265, align 8
  %op7018 = and i32 %v7017, 24
  store i32 %op7018, ptr %slot1265, align 8
  %v7019 = load i32, ptr %slot1265, align 8
  %cmp7020 = icmp eq i32 %v7019, 0
  %cv7021 = zext i1 %cmp7020 to i32
  store i32 %cv7021, ptr %slot1266, align 8
  %v7022 = load i32, ptr %slot1264, align 8
  %v7023 = load i32, ptr %slot1266, align 8
  %op7024 = and i32 %v7022, %v7023
  store i32 %op7024, ptr %slot1267, align 8
  %v7025 = load i32, ptr %slot1267, align 8
  %cv7026 = zext i32 %v7025 to i64
  %cond7027 = icmp ne i64 %cv7026, 0
  br i1 %cond7027, label %bb_rctake1806, label %bb_rccopy1806
bb_rctake1806:
  %v7028 = load i64, ptr %slot30, align 8
  store i64 %v7028, ptr %slot1268, align 8
  %v7029 = load i64, ptr %slot72, align 8
  store i64 %v7029, ptr %slot1269, align 8
  %v7030 = load i64, ptr %slot71, align 8
  %v7031 = load i64, ptr %slot1268, align 8
  %v7032 = load i64, ptr %slot1263, align 8
  %v7033 = load i64, ptr %slot1269, align 8
  %cv7034 = trunc i64 %v7033 to i32
  %call7035 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v7030, i64 %v7031, i64 %v7032, i32 %cv7034) nomerge, !dbg !210
  store i32 %call7035, ptr %slot1270, align 8
  %v7036 = load i32, ptr %slot1270, align 8
  %cv7037 = zext i32 %v7036 to i64
  %cond7038 = icmp ne i64 %cv7037, 0
  br i1 %cond7038, label %bb_rcsuccess1816, label %bb_rcfailure1816
bb_rcfailure1816:
  %v7039 = load i64, ptr %slot71, align 8
  %p7040 = inttoptr i64 %v7039 to ptr
  %call7041 = call i32 @myl_rc_take_failure(ptr %p7040) nomerge, !dbg !210
  store i32 %call7041, ptr %slot1271, align 8
  %v7042 = load i64, ptr %slot1, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  %v7044 = load i32, ptr %slot1271, align 8
  %call7045 = call i32 @myl_qbe_rc_status(ptr %p7043, i32 %v7044) nomerge, !dbg !210
  store i32 %call7045, ptr %slot1272, align 8
  br label %bb_failure
bb_rcsuccess1816:
  %v7046 = load i64, ptr %slot20, align 8
  %p7047 = inttoptr i64 %v7046 to ptr
  store i32 0, ptr %p7047, align 4, !alias.scope !3, !noalias !4
  %v7048 = load i64, ptr %slot25, align 8
  %p7049 = inttoptr i64 %v7048 to ptr
  store i32 2, ptr %p7049, align 4, !alias.scope !3, !noalias !4
  %v7050 = load i64, ptr %slot24, align 8
  %p7051 = inttoptr i64 %v7050 to ptr
  store i32 1, ptr %p7051, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1806
bb_rccopy1806:
  %v7052 = load i64, ptr %slot30, align 8
  store i64 %v7052, ptr %slot1273, align 8
  %v7053 = load i64, ptr %slot72, align 8
  store i64 %v7053, ptr %slot1274, align 8
  %v7054 = load i64, ptr %slot71, align 8
  %v7055 = load i64, ptr %slot1273, align 8
  %v7056 = load i64, ptr %slot1263, align 8
  %v7057 = load i64, ptr %slot1274, align 8
  %cv7058 = trunc i64 %v7057 to i32
  %call7059 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_retain(i64 %v7054, i64 %v7055, i64 %v7056, i32 %cv7058) nomerge, !dbg !210
  store i32 %call7059, ptr %slot1275, align 8
  %v7060 = load i32, ptr %slot1275, align 8
  %cv7061 = zext i32 %v7060 to i64
  %cond7062 = icmp ne i64 %cv7061, 0
  br i1 %cond7062, label %bb_rcsuccess1825, label %bb_rcfailure1825
bb_rcfailure1825:
  %v7063 = load i64, ptr %slot71, align 8
  %p7064 = inttoptr i64 %v7063 to ptr
  %call7065 = call i32 @myl_rc_take_failure(ptr %p7064) nomerge, !dbg !210
  store i32 %call7065, ptr %slot1276, align 8
  %v7066 = load i64, ptr %slot1, align 8
  %p7067 = inttoptr i64 %v7066 to ptr
  %v7068 = load i32, ptr %slot1276, align 8
  %call7069 = call i32 @myl_qbe_rc_status(ptr %p7067, i32 %v7068) nomerge, !dbg !210
  store i32 %call7069, ptr %slot1277, align 8
  br label %bb_failure
bb_rcsuccess1825:
  %v7070 = load i64, ptr %slot25, align 8
  %p7071 = inttoptr i64 %v7070 to ptr
  store i32 2, ptr %p7071, align 4, !alias.scope !3, !noalias !4
  %v7072 = load i64, ptr %slot24, align 8
  %p7073 = inttoptr i64 %v7072 to ptr
  store i32 1, ptr %p7073, align 4, !alias.scope !3, !noalias !4
  %v7074 = load i64, ptr %slot20, align 8
  %p7075 = inttoptr i64 %v7074 to ptr
  %ld7076 = load i32, ptr %p7075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7076, ptr %slot1278, align 8
  %v7077 = load i32, ptr %slot1278, align 8
  %cv7078 = zext i32 %v7077 to i64
  %cond7079 = icmp ne i64 %cv7078, 0
  br i1 %cond7079, label %bb_rcslotdrop1832, label %bb_rcslotdone1832
bb_rcslotdrop1832:
  %v7080 = load i64, ptr %slot20, align 8
  %p7081 = inttoptr i64 %v7080 to ptr
  store i32 0, ptr %p7081, align 4, !alias.scope !3, !noalias !4
  %v7082 = load i64, ptr %slot27, align 8
  store i64 %v7082, ptr %slot1279, align 8
  %v7083 = load i64, ptr %slot21, align 8
  %p7084 = inttoptr i64 %v7083 to ptr
  %ld7085 = load i32, ptr %p7084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7085, ptr %slot1280, align 8
  %v7086 = load i32, ptr %slot1280, align 8
  %op7087 = and i32 %v7086, 28
  store i32 %op7087, ptr %slot1281, align 8
  %v7088 = load i32, ptr %slot1281, align 8
  %cv7089 = zext i32 %v7088 to i64
  %cond7090 = icmp ne i64 %cv7089, 0
  br i1 %cond7090, label %bb_rcslotrole1832, label %bb_rcslotowner1832
bb_rcslotrole1832:
  %v7091 = load i64, ptr %slot71, align 8
  store i64 %v7091, ptr %slot1282, align 8
  %v7092 = load i64, ptr %slot1282, align 8
  %v7093 = load i64, ptr %slot1279, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v7092, i64 %v7093) nomerge, !dbg !210
  br label %bb_rcslotdone1832
bb_rcslotowner1832:
  %v7094 = load i64, ptr %slot71, align 8
  store i64 %v7094, ptr %slot1283, align 8
  %v7095 = load i64, ptr %slot1283, align 8
  %v7096 = load i64, ptr %slot1279, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7095, i64 %v7096) nomerge, !dbg !210
  br label %bb_rcslotdone1832
bb_rcslotdone1832:
  br label %bb_rcprepared1806
bb_rcprepared1806:
  %v7097 = load i64, ptr %slot30, align 8
  store i64 %v7097, ptr %slot1284, align 8
  %v7098 = load i64, ptr %slot65, align 8
  store i64 %v7098, ptr %slot1285, align 8
  %v7099 = load i64, ptr %slot1284, align 8
  %v7100 = load i64, ptr %slot1285, align 8
  %p7101 = inttoptr i64 %v7099 to ptr
  %p7102 = inttoptr i64 %v7100 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7102, ptr %p7101, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v7103 = load i64, ptr %slot24, align 8
  %p7104 = inttoptr i64 %v7103 to ptr
  store i32 0, ptr %p7104, align 4, !alias.scope !3, !noalias !4
  %v7105 = load i64, ptr %slot26, align 8
  %p7106 = inttoptr i64 %v7105 to ptr
  store i32 1, ptr %p7106, align 4, !alias.scope !3, !noalias !4
  %v7107 = load i64, ptr %slot72, align 8
  store i64 %v7107, ptr %slot1286, align 8
  %v7108 = load i64, ptr %slot59, align 8
  %p7109 = inttoptr i64 %v7108 to ptr
  %ld7110 = load i64, ptr %p7109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7110, ptr %slot1287, align 8
  %v7111 = load i64, ptr %slot1285, align 8
  %p7113 = inttoptr i64 %v7111 to ptr
  %gep7114 = getelementptr i8, ptr %p7113, i64 88
  %op7112 = ptrtoint ptr %gep7114 to i64
  store i64 %op7112, ptr %slot1288, align 8
  %v7115 = load i64, ptr %slot30, align 8
  store i64 %v7115, ptr %slot1289, align 8
  %v7116 = load i64, ptr %slot1287, align 8
  %v7117 = load i64, ptr %slot1289, align 8
  %p7118 = inttoptr i64 %v7116 to ptr
  %p7119 = inttoptr i64 %v7117 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7119, ptr %p7118, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v7120 = load i64, ptr %slot25, align 8
  %p7121 = inttoptr i64 %v7120 to ptr
  store i32 0, ptr %p7121, align 4, !alias.scope !3, !noalias !4
  %v7122 = load i64, ptr %slot24, align 8
  %p7123 = inttoptr i64 %v7122 to ptr
  store i32 1, ptr %p7123, align 4, !alias.scope !3, !noalias !4
  %v7124 = load i64, ptr %slot1289, align 8
  %v7125 = load i64, ptr %slot1288, align 8
  %p7126 = inttoptr i64 %v7124 to ptr
  %p7127 = inttoptr i64 %v7125 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7127, ptr %p7126, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v7128 = load i64, ptr %slot24, align 8
  %p7129 = inttoptr i64 %v7128 to ptr
  store i32 0, ptr %p7129, align 4, !alias.scope !3, !noalias !4
  %v7130 = load i64, ptr %slot1285, align 8
  %v7131 = load i64, ptr %slot58, align 8
  %p7132 = inttoptr i64 %v7131 to ptr
  store i64 %v7130, ptr %p7132, align 8, !alias.scope !3, !noalias !4
  %v7133 = load i64, ptr %slot58, align 8
  %p7134 = inttoptr i64 %v7133 to ptr
  %ld7135 = load i64, ptr %p7134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7135, ptr %slot1290, align 8
  %v7136 = load i64, ptr %slot30, align 8
  store i64 %v7136, ptr %slot1291, align 8
  %v7137 = load i64, ptr %slot1290, align 8
  %v7138 = load i64, ptr %slot1291, align 8
  %p7139 = inttoptr i64 %v7137 to ptr
  %p7140 = inttoptr i64 %v7138 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7140, ptr %p7139, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v7141 = load i64, ptr %slot25, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  store i32 2, ptr %p7142, align 4, !alias.scope !3, !noalias !4
  %v7143 = load i64, ptr %slot24, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  store i32 1, ptr %p7144, align 4, !alias.scope !3, !noalias !4
  %v7145 = load i64, ptr %slot20, align 8
  %p7146 = inttoptr i64 %v7145 to ptr
  %ld7147 = load i32, ptr %p7146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7147, ptr %slot1292, align 8
  %v7148 = load i32, ptr %slot1292, align 8
  %cv7149 = zext i32 %v7148 to i64
  %cond7150 = icmp ne i64 %cv7149, 0
  br i1 %cond7150, label %bb_rcslotdrop1857, label %bb_rcslotdone1857
bb_rcslotdrop1857:
  %v7151 = load i64, ptr %slot20, align 8
  %p7152 = inttoptr i64 %v7151 to ptr
  store i32 0, ptr %p7152, align 4, !alias.scope !3, !noalias !4
  %v7153 = load i64, ptr %slot27, align 8
  store i64 %v7153, ptr %slot1293, align 8
  %v7154 = load i64, ptr %slot21, align 8
  %p7155 = inttoptr i64 %v7154 to ptr
  %ld7156 = load i32, ptr %p7155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7156, ptr %slot1294, align 8
  %v7157 = load i32, ptr %slot1294, align 8
  %op7158 = and i32 %v7157, 28
  store i32 %op7158, ptr %slot1295, align 8
  %v7159 = load i32, ptr %slot1295, align 8
  %cv7160 = zext i32 %v7159 to i64
  %cond7161 = icmp ne i64 %cv7160, 0
  br i1 %cond7161, label %bb_rcslotrole1857, label %bb_rcslotowner1857
bb_rcslotrole1857:
  %v7162 = load i64, ptr %slot71, align 8
  store i64 %v7162, ptr %slot1296, align 8
  %v7163 = load i64, ptr %slot1296, align 8
  %v7164 = load i64, ptr %slot1293, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v7163, i64 %v7164) nomerge, !dbg !210
  br label %bb_rcslotdone1857
bb_rcslotowner1857:
  %v7165 = load i64, ptr %slot71, align 8
  store i64 %v7165, ptr %slot1297, align 8
  %v7166 = load i64, ptr %slot1297, align 8
  %v7167 = load i64, ptr %slot1293, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7166, i64 %v7167) nomerge, !dbg !210
  br label %bb_rcslotdone1857
bb_rcslotdone1857:
  %v7168 = load i64, ptr %slot27, align 8
  store i64 %v7168, ptr %slot1298, align 8
  %v7169 = load i64, ptr %slot30, align 8
  store i64 %v7169, ptr %slot1299, align 8
  %v7170 = load i64, ptr %slot1299, align 8
  %v7171 = load i64, ptr %slot1298, align 8
  %p7172 = inttoptr i64 %v7170 to ptr
  %p7173 = inttoptr i64 %v7171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7173, ptr %p7172, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v7174 = load i64, ptr %slot21, align 8
  %p7175 = inttoptr i64 %v7174 to ptr
  store i32 2, ptr %p7175, align 4, !alias.scope !3, !noalias !4
  %v7176 = load i64, ptr %slot25, align 8
  %p7177 = inttoptr i64 %v7176 to ptr
  %ld7178 = load i32, ptr %p7177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7178, ptr %slot1300, align 8
  %v7179 = load i32, ptr %slot1300, align 8
  %v7180 = load i64, ptr %slot21, align 8
  %p7181 = inttoptr i64 %v7180 to ptr
  store i32 %v7179, ptr %p7181, align 4, !alias.scope !3, !noalias !4
  %v7182 = load i64, ptr %slot24, align 8
  %p7183 = inttoptr i64 %v7182 to ptr
  store i32 0, ptr %p7183, align 4, !alias.scope !3, !noalias !4
  %v7184 = load i64, ptr %slot20, align 8
  %p7185 = inttoptr i64 %v7184 to ptr
  store i32 1, ptr %p7185, align 4, !alias.scope !3, !noalias !4
  %v7186 = load i64, ptr %slot1298, align 8
  %v7187 = load i64, ptr %slot58, align 8
  %p7188 = inttoptr i64 %v7187 to ptr
  store i64 %v7186, ptr %p7188, align 8, !alias.scope !3, !noalias !4
  %v7189 = load i64, ptr %slot58, align 8
  %p7190 = inttoptr i64 %v7189 to ptr
  %ld7191 = load i64, ptr %p7190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7191, ptr %slot1301, align 8
  %v7192 = load i64, ptr %slot20, align 8
  %p7193 = inttoptr i64 %v7192 to ptr
  %ld7194 = load i32, ptr %p7193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7194, ptr %slot1302, align 8
  %v7195 = load i64, ptr %slot21, align 8
  %p7196 = inttoptr i64 %v7195 to ptr
  %ld7197 = load i32, ptr %p7196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7197, ptr %slot1303, align 8
  %v7198 = load i32, ptr %slot1303, align 8
  %op7199 = and i32 %v7198, 24
  store i32 %op7199, ptr %slot1303, align 8
  %v7200 = load i32, ptr %slot1303, align 8
  %cmp7201 = icmp eq i32 %v7200, 0
  %cv7202 = zext i1 %cmp7201 to i32
  store i32 %cv7202, ptr %slot1304, align 8
  %v7203 = load i32, ptr %slot1302, align 8
  %v7204 = load i32, ptr %slot1304, align 8
  %op7205 = and i32 %v7203, %v7204
  store i32 %op7205, ptr %slot1305, align 8
  %v7206 = load i32, ptr %slot1305, align 8
  %cv7207 = zext i32 %v7206 to i64
  %cond7208 = icmp ne i64 %cv7207, 0
  br i1 %cond7208, label %bb_rctake1873, label %bb_rccopy1873
bb_rctake1873:
  %v7209 = load i64, ptr %slot30, align 8
  store i64 %v7209, ptr %slot1306, align 8
  %v7210 = load i64, ptr %slot72, align 8
  store i64 %v7210, ptr %slot1307, align 8
  %v7211 = load i64, ptr %slot71, align 8
  %v7212 = load i64, ptr %slot1306, align 8
  %v7213 = load i64, ptr %slot1301, align 8
  %v7214 = load i64, ptr %slot1307, align 8
  %cv7215 = trunc i64 %v7214 to i32
  %call7216 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64 %v7211, i64 %v7212, i64 %v7213, i32 %cv7215) nomerge, !dbg !212
  store i32 %call7216, ptr %slot1308, align 8
  %v7217 = load i32, ptr %slot1308, align 8
  %cv7218 = zext i32 %v7217 to i64
  %cond7219 = icmp ne i64 %cv7218, 0
  br i1 %cond7219, label %bb_rcsuccess1883, label %bb_rcfailure1883
bb_rcfailure1883:
  %v7220 = load i64, ptr %slot71, align 8
  %p7221 = inttoptr i64 %v7220 to ptr
  %call7222 = call i32 @myl_rc_take_failure(ptr %p7221) nomerge, !dbg !212
  store i32 %call7222, ptr %slot1309, align 8
  %v7223 = load i64, ptr %slot1, align 8
  %p7224 = inttoptr i64 %v7223 to ptr
  %v7225 = load i32, ptr %slot1309, align 8
  %call7226 = call i32 @myl_qbe_rc_status(ptr %p7224, i32 %v7225) nomerge, !dbg !212
  store i32 %call7226, ptr %slot1310, align 8
  br label %bb_failure
bb_rcsuccess1883:
  %v7227 = load i64, ptr %slot20, align 8
  %p7228 = inttoptr i64 %v7227 to ptr
  store i32 0, ptr %p7228, align 4, !alias.scope !3, !noalias !4
  %v7229 = load i64, ptr %slot25, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  store i32 2, ptr %p7230, align 4, !alias.scope !3, !noalias !4
  %v7231 = load i64, ptr %slot24, align 8
  %p7232 = inttoptr i64 %v7231 to ptr
  store i32 1, ptr %p7232, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1873
bb_rccopy1873:
  %v7233 = load i64, ptr %slot30, align 8
  store i64 %v7233, ptr %slot1311, align 8
  %v7234 = load i64, ptr %slot72, align 8
  store i64 %v7234, ptr %slot1312, align 8
  %v7235 = load i64, ptr %slot71, align 8
  %v7236 = load i64, ptr %slot1311, align 8
  %v7237 = load i64, ptr %slot1301, align 8
  %v7238 = load i64, ptr %slot1312, align 8
  %cv7239 = trunc i64 %v7238 to i32
  %call7240 = call i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_retain(i64 %v7235, i64 %v7236, i64 %v7237, i32 %cv7239) nomerge, !dbg !212
  store i32 %call7240, ptr %slot1313, align 8
  %v7241 = load i32, ptr %slot1313, align 8
  %cv7242 = zext i32 %v7241 to i64
  %cond7243 = icmp ne i64 %cv7242, 0
  br i1 %cond7243, label %bb_rcsuccess1892, label %bb_rcfailure1892
bb_rcfailure1892:
  %v7244 = load i64, ptr %slot71, align 8
  %p7245 = inttoptr i64 %v7244 to ptr
  %call7246 = call i32 @myl_rc_take_failure(ptr %p7245) nomerge, !dbg !212
  store i32 %call7246, ptr %slot1314, align 8
  %v7247 = load i64, ptr %slot1, align 8
  %p7248 = inttoptr i64 %v7247 to ptr
  %v7249 = load i32, ptr %slot1314, align 8
  %call7250 = call i32 @myl_qbe_rc_status(ptr %p7248, i32 %v7249) nomerge, !dbg !212
  store i32 %call7250, ptr %slot1315, align 8
  br label %bb_failure
bb_rcsuccess1892:
  %v7251 = load i64, ptr %slot25, align 8
  %p7252 = inttoptr i64 %v7251 to ptr
  store i32 2, ptr %p7252, align 4, !alias.scope !3, !noalias !4
  %v7253 = load i64, ptr %slot24, align 8
  %p7254 = inttoptr i64 %v7253 to ptr
  store i32 1, ptr %p7254, align 4, !alias.scope !3, !noalias !4
  %v7255 = load i64, ptr %slot20, align 8
  %p7256 = inttoptr i64 %v7255 to ptr
  %ld7257 = load i32, ptr %p7256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7257, ptr %slot1316, align 8
  %v7258 = load i32, ptr %slot1316, align 8
  %cv7259 = zext i32 %v7258 to i64
  %cond7260 = icmp ne i64 %cv7259, 0
  br i1 %cond7260, label %bb_rcslotdrop1899, label %bb_rcslotdone1899
bb_rcslotdrop1899:
  %v7261 = load i64, ptr %slot20, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  store i32 0, ptr %p7262, align 4, !alias.scope !3, !noalias !4
  %v7263 = load i64, ptr %slot27, align 8
  store i64 %v7263, ptr %slot1317, align 8
  %v7264 = load i64, ptr %slot21, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  %ld7266 = load i32, ptr %p7265, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7266, ptr %slot1318, align 8
  %v7267 = load i32, ptr %slot1318, align 8
  %op7268 = and i32 %v7267, 28
  store i32 %op7268, ptr %slot1319, align 8
  %v7269 = load i32, ptr %slot1319, align 8
  %cv7270 = zext i32 %v7269 to i64
  %cond7271 = icmp ne i64 %cv7270, 0
  br i1 %cond7271, label %bb_rcslotrole1899, label %bb_rcslotowner1899
bb_rcslotrole1899:
  %v7272 = load i64, ptr %slot71, align 8
  store i64 %v7272, ptr %slot1320, align 8
  %v7273 = load i64, ptr %slot1320, align 8
  %v7274 = load i64, ptr %slot1317, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v7273, i64 %v7274) nomerge, !dbg !212
  br label %bb_rcslotdone1899
bb_rcslotowner1899:
  %v7275 = load i64, ptr %slot71, align 8
  store i64 %v7275, ptr %slot1321, align 8
  %v7276 = load i64, ptr %slot1321, align 8
  %v7277 = load i64, ptr %slot1317, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7276, i64 %v7277) nomerge, !dbg !212
  br label %bb_rcslotdone1899
bb_rcslotdone1899:
  br label %bb_rcprepared1873
bb_rcprepared1873:
  %v7278 = load i64, ptr %slot34, align 8
  %p7279 = inttoptr i64 %v7278 to ptr
  %ld7280 = load i64, ptr %p7279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7280, ptr %slot1322, align 8
  %v7281 = load i64, ptr %slot71, align 8
  store i64 %v7281, ptr %slot1323, align 8
  %v7282 = load i64, ptr %slot1323, align 8
  %v7283 = load i64, ptr %slot1322, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7282, i64 %v7283) nomerge, !dbg !212
  %v7284 = load i64, ptr %slot30, align 8
  store i64 %v7284, ptr %slot1324, align 8
  %v7285 = load i64, ptr %slot1324, align 8
  %v7286 = load i64, ptr %slot1322, align 8
  %p7287 = inttoptr i64 %v7285 to ptr
  %p7288 = inttoptr i64 %v7286 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7288, ptr %p7287, i64 104, i1 false), !alias.scope !10000000
  %v7289 = load i64, ptr %slot24, align 8
  %p7290 = inttoptr i64 %v7289 to ptr
  store i32 0, ptr %p7290, align 4, !alias.scope !3, !noalias !4
  %v7291 = load i64, ptr %slot58, align 8
  %p7292 = inttoptr i64 %v7291 to ptr
  store i64 0, ptr %p7292, align 8, !alias.scope !3, !noalias !4
  %v7293 = load i64, ptr %slot58, align 8
  %p7294 = inttoptr i64 %v7293 to ptr
  store i64 0, ptr %p7294, align 8, !alias.scope !3, !noalias !4
  %v7295 = load i64, ptr %slot58, align 8
  %p7296 = inttoptr i64 %v7295 to ptr
  %ld7297 = load i64, ptr %p7296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7297, ptr %slot1325, align 8
  %v7298 = load i64, ptr %slot31, align 8
  %p7300 = inttoptr i64 %v7298 to ptr
  %gep7301 = getelementptr i8, ptr %p7300, i64 24
  %op7299 = ptrtoint ptr %gep7301 to i64
  store i64 %op7299, ptr %slot1326, align 8
  %v7302 = load i64, ptr %slot1326, align 8
  %p7303 = inttoptr i64 %v7302 to ptr
  %ld7304 = load i32, ptr %p7303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7304, ptr %slot1327, align 8
  %v7305 = load i32, ptr %slot1327, align 8
  %cv7306 = zext i32 %v7305 to i64
  %cond7307 = icmp ne i64 %cv7306, 0
  br i1 %cond7307, label %bb_rcscopesopen1913, label %bb_rcscopesclosed1913
bb_rcscopesopen1913:
  %v7308 = load i64, ptr %slot33, align 8
  %p7310 = inttoptr i64 %v7308 to ptr
  %gep7311 = getelementptr i8, ptr %p7310, i64 0
  %op7309 = ptrtoint ptr %gep7311 to i64
  store i64 %op7309, ptr %slot1328, align 8
  %v7312 = load i64, ptr %slot31, align 8
  %v7313 = load i64, ptr %slot1328, align 8
  %p7314 = inttoptr i64 %v7313 to ptr
  store i64 %v7312, ptr %p7314, align 8, !alias.scope !3, !noalias !4
  %v7315 = load i64, ptr %slot1, align 8
  %p7316 = inttoptr i64 %v7315 to ptr
  %v7317 = load i64, ptr %slot33, align 8
  %p7318 = inttoptr i64 %v7317 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7316, ptr %p7318, i64 1) nomerge, !dbg !214
  br label %bb_rcscopesclosed1913
bb_rcscopesclosed1913:
  %v7319 = load i64, ptr %slot20, align 8
  %p7320 = inttoptr i64 %v7319 to ptr
  %ld7321 = load i32, ptr %p7320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7321, ptr %slot1329, align 8
  %v7322 = load i32, ptr %slot1329, align 8
  %cv7323 = zext i32 %v7322 to i64
  %cond7324 = icmp ne i64 %cv7323, 0
  br i1 %cond7324, label %bb_rcslotdrop1917, label %bb_rcslotdone1917
bb_rcslotdrop1917:
  %v7325 = load i64, ptr %slot20, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  store i32 0, ptr %p7326, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1917
bb_rcslotdone1917:
  %v7327 = load i64, ptr %slot18, align 8
  %p7328 = inttoptr i64 %v7327 to ptr
  %ld7329 = load i32, ptr %p7328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7329, ptr %slot1330, align 8
  %v7330 = load i32, ptr %slot1330, align 8
  %cv7331 = zext i32 %v7330 to i64
  %cond7332 = icmp ne i64 %cv7331, 0
  br i1 %cond7332, label %bb_rcslotdrop1920, label %bb_rcslotdone1920
bb_rcslotdrop1920:
  %v7333 = load i64, ptr %slot18, align 8
  %p7334 = inttoptr i64 %v7333 to ptr
  store i32 0, ptr %p7334, align 4, !alias.scope !3, !noalias !4
  %v7335 = load i64, ptr %slot56, align 8
  store i64 %v7335, ptr %slot1331, align 8
  %v7336 = load i64, ptr %slot19, align 8
  %p7337 = inttoptr i64 %v7336 to ptr
  %ld7338 = load i32, ptr %p7337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7338, ptr %slot1332, align 8
  %v7339 = load i32, ptr %slot1332, align 8
  %op7340 = and i32 %v7339, 28
  store i32 %op7340, ptr %slot1333, align 8
  %v7341 = load i32, ptr %slot1333, align 8
  %cv7342 = zext i32 %v7341 to i64
  %cond7343 = icmp ne i64 %cv7342, 0
  br i1 %cond7343, label %bb_rcslotrole1920, label %bb_rcslotowner1920
bb_rcslotrole1920:
  %v7344 = load i64, ptr %slot71, align 8
  store i64 %v7344, ptr %slot1334, align 8
  %v7345 = load i64, ptr %slot1334, align 8
  %v7346 = load i64, ptr %slot1331, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v7345, i64 %v7346) nomerge, !dbg !214
  br label %bb_rcslotdone1920
bb_rcslotowner1920:
  %v7347 = load i64, ptr %slot71, align 8
  store i64 %v7347, ptr %slot1335, align 8
  %v7348 = load i64, ptr %slot1335, align 8
  %v7349 = load i64, ptr %slot1331, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7348, i64 %v7349) nomerge, !dbg !214
  br label %bb_rcslotdone1920
bb_rcslotdone1920:
  %v7350 = load i64, ptr %slot16, align 8
  %p7351 = inttoptr i64 %v7350 to ptr
  %ld7352 = load i32, ptr %p7351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7352, ptr %slot1336, align 8
  %v7353 = load i32, ptr %slot1336, align 8
  %cv7354 = zext i32 %v7353 to i64
  %cond7355 = icmp ne i64 %cv7354, 0
  br i1 %cond7355, label %bb_rcslotdrop1929, label %bb_rcslotdone1929
bb_rcslotdrop1929:
  %v7356 = load i64, ptr %slot16, align 8
  %p7357 = inttoptr i64 %v7356 to ptr
  store i32 0, ptr %p7357, align 4, !alias.scope !3, !noalias !4
  %v7358 = load i64, ptr %slot54, align 8
  store i64 %v7358, ptr %slot1337, align 8
  %v7359 = load i64, ptr %slot17, align 8
  %p7360 = inttoptr i64 %v7359 to ptr
  %ld7361 = load i32, ptr %p7360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7361, ptr %slot1338, align 8
  %v7362 = load i32, ptr %slot1338, align 8
  %op7363 = and i32 %v7362, 28
  store i32 %op7363, ptr %slot1339, align 8
  %v7364 = load i32, ptr %slot1339, align 8
  %cv7365 = zext i32 %v7364 to i64
  %cond7366 = icmp ne i64 %cv7365, 0
  br i1 %cond7366, label %bb_rcslotrole1929, label %bb_rcslotowner1929
bb_rcslotrole1929:
  %v7367 = load i64, ptr %slot71, align 8
  store i64 %v7367, ptr %slot1340, align 8
  %v7368 = load i64, ptr %slot1340, align 8
  %v7369 = load i64, ptr %slot1337, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v7368, i64 %v7369) nomerge, !dbg !214
  br label %bb_rcslotdone1929
bb_rcslotowner1929:
  %v7370 = load i64, ptr %slot71, align 8
  store i64 %v7370, ptr %slot1341, align 8
  %v7371 = load i64, ptr %slot1341, align 8
  %v7372 = load i64, ptr %slot1337, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v7371, i64 %v7372) nomerge, !dbg !214
  br label %bb_rcslotdone1929
bb_rcslotdone1929:
  %v7373 = load i64, ptr %slot14, align 8
  %p7374 = inttoptr i64 %v7373 to ptr
  %ld7375 = load i32, ptr %p7374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7375, ptr %slot1342, align 8
  %v7376 = load i32, ptr %slot1342, align 8
  %cv7377 = zext i32 %v7376 to i64
  %cond7378 = icmp ne i64 %cv7377, 0
  br i1 %cond7378, label %bb_rcslotdrop1975, label %bb_rcslotdone1975
bb_rcslotdrop1975:
  %v7379 = load i64, ptr %slot14, align 8
  %p7380 = inttoptr i64 %v7379 to ptr
  store i32 0, ptr %p7380, align 4, !alias.scope !3, !noalias !4
  %v7381 = load i64, ptr %slot47, align 8
  store i64 %v7381, ptr %slot1343, align 8
  %v7382 = load i64, ptr %slot15, align 8
  %p7383 = inttoptr i64 %v7382 to ptr
  %ld7384 = load i32, ptr %p7383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7384, ptr %slot1344, align 8
  %v7385 = load i32, ptr %slot1344, align 8
  %op7386 = and i32 %v7385, 28
  store i32 %op7386, ptr %slot1345, align 8
  %v7387 = load i32, ptr %slot1345, align 8
  %cv7388 = zext i32 %v7387 to i64
  %cond7389 = icmp ne i64 %cv7388, 0
  br i1 %cond7389, label %bb_rcslotrole1975, label %bb_rcslotowner1975
bb_rcslotrole1975:
  %v7390 = load i64, ptr %slot71, align 8
  store i64 %v7390, ptr %slot1346, align 8
  %v7391 = load i64, ptr %slot1343, align 8
  %p7392 = inttoptr i64 %v7391 to ptr
  %ld7393 = load i64, ptr %p7392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7393, ptr %slot1347, align 8
  %v7394 = load i64, ptr %slot1347, align 8
  %cmp7395 = icmp ne i64 %v7394, 0
  %cv7396 = zext i1 %cmp7395 to i32
  store i32 %cv7396, ptr %slot1348, align 8
  %v7397 = load i32, ptr %slot1348, align 8
  %cv7398 = zext i32 %v7397 to i64
  %cond7399 = icmp ne i64 %cv7398, 0
  br i1 %cond7399, label %bb_rcgnn1991, label %bb_rcgdone1991
bb_rcgnn1991:
  %v7400 = load i64, ptr %slot1347, align 8
  %op7401 = sub i64 %v7400, 16
  store i64 %op7401, ptr %slot1349, align 8
  %v7402 = load i64, ptr %slot1347, align 8
  %p7403 = inttoptr i64 %v7402 to ptr
  %rgep7404 = getelementptr i8, ptr %p7403, i64 -16
  %ld7405 = load i64, ptr %rgep7404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7405, ptr %slot1350, align 8
  %v7406 = load i64, ptr %slot1350, align 8
  %op7407 = and i64 %v7406, 4611686018427387906
  store i64 %op7407, ptr %slot1351, align 8
  %v7408 = load i64, ptr %slot1351, align 8
  %cmp7409 = icmp ne i64 %v7408, 0
  %cv7410 = zext i1 %cmp7409 to i32
  store i32 %cv7410, ptr %slot1352, align 8
  %v7411 = load i32, ptr %slot1352, align 8
  %cv7412 = zext i32 %v7411 to i64
  %cond7413 = icmp ne i64 %cv7412, 0
  br i1 %cond7413, label %bb_rcgclear1991, label %bb_rcgcounted1991
bb_rcgcounted1991:
  %v7414 = load i64, ptr %slot1347, align 8
  %op7415 = sub i64 %v7414, 24
  store i64 %op7415, ptr %slot1353, align 8
  %v7416 = load i64, ptr %slot1347, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  %rgep7418 = getelementptr i8, ptr %p7417, i64 -24
  %ld7419 = load i64, ptr %rgep7418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7419, ptr %slot1354, align 8
  %v7420 = load i64, ptr %slot1354, align 8
  %op7421 = sub i64 %v7420, 1
  store i64 %op7421, ptr %slot1355, align 8
  %v7422 = load i64, ptr %slot1355, align 8
  %cmp7423 = icmp eq i64 %v7422, 0
  %cv7424 = zext i1 %cmp7423 to i32
  store i32 %cv7424, ptr %slot1356, align 8
  %v7425 = load i32, ptr %slot1356, align 8
  %cv7426 = zext i32 %v7425 to i64
  %cond7427 = icmp ne i64 %cv7426, 0
  br i1 %cond7427, label %bb_rcglast1991, label %bb_rcgdec1991
bb_rcglast1991:
  %v7428 = load i64, ptr %slot1347, align 8
  %op7429 = sub i64 %v7428, 32
  store i64 %op7429, ptr %slot1357, align 8
  %v7430 = load i64, ptr %slot1347, align 8
  %p7431 = inttoptr i64 %v7430 to ptr
  %rgep7432 = getelementptr i8, ptr %p7431, i64 -32
  %ld7433 = load i64, ptr %rgep7432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7433, ptr %slot1358, align 8
  %v7434 = load i64, ptr %slot1358, align 8
  %cmp7435 = icmp ne i64 %v7434, 0
  %cv7436 = zext i1 %cmp7435 to i32
  store i32 %cv7436, ptr %slot1359, align 8
  %v7437 = load i32, ptr %slot1359, align 8
  %cv7438 = zext i32 %v7437 to i64
  %cond7439 = icmp ne i64 %cv7438, 0
  br i1 %cond7439, label %bb_rcgdec1991, label %bb_rcgslow1991
bb_rcgslow1991:
  %v7440 = load i64, ptr %slot1346, align 8
  %v7441 = load i64, ptr %slot1343, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7440, i64 %v7441) nomerge, !dbg !214
  br label %bb_rcgdone1991
bb_rcgdec1991:
  %v7442 = load i64, ptr %slot1355, align 8
  %v7443 = load i64, ptr %slot1347, align 8
  %p7444 = inttoptr i64 %v7443 to ptr
  %rgep7445 = getelementptr i8, ptr %p7444, i64 -24
  store i64 %v7442, ptr %rgep7445, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1991
bb_rcgclear1991:
  %v7446 = load i64, ptr %slot1343, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  store i64 0, ptr %p7447, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1991
bb_rcgdone1991:
  br label %bb_rcslotdone1975
bb_rcslotowner1975:
  %v7448 = load i64, ptr %slot71, align 8
  store i64 %v7448, ptr %slot1360, align 8
  %v7449 = load i64, ptr %slot1343, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  %ld7451 = load i64, ptr %p7450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7451, ptr %slot1361, align 8
  %v7452 = load i64, ptr %slot1361, align 8
  %cmp7453 = icmp ne i64 %v7452, 0
  %cv7454 = zext i1 %cmp7453 to i32
  store i32 %cv7454, ptr %slot1362, align 8
  %v7455 = load i32, ptr %slot1362, align 8
  %cv7456 = zext i32 %v7455 to i64
  %cond7457 = icmp ne i64 %cv7456, 0
  br i1 %cond7457, label %bb_rcgnn2006, label %bb_rcgdone2006
bb_rcgnn2006:
  %v7458 = load i64, ptr %slot1361, align 8
  %op7459 = sub i64 %v7458, 16
  store i64 %op7459, ptr %slot1363, align 8
  %v7460 = load i64, ptr %slot1361, align 8
  %p7461 = inttoptr i64 %v7460 to ptr
  %rgep7462 = getelementptr i8, ptr %p7461, i64 -16
  %ld7463 = load i64, ptr %rgep7462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7463, ptr %slot1364, align 8
  %v7464 = load i64, ptr %slot1364, align 8
  %op7465 = and i64 %v7464, 4611686018427387906
  store i64 %op7465, ptr %slot1365, align 8
  %v7466 = load i64, ptr %slot1365, align 8
  %cmp7467 = icmp ne i64 %v7466, 0
  %cv7468 = zext i1 %cmp7467 to i32
  store i32 %cv7468, ptr %slot1366, align 8
  %v7469 = load i32, ptr %slot1366, align 8
  %cv7470 = zext i32 %v7469 to i64
  %cond7471 = icmp ne i64 %cv7470, 0
  br i1 %cond7471, label %bb_rcgclear2006, label %bb_rcgcounted2006
bb_rcgcounted2006:
  %v7472 = load i64, ptr %slot1361, align 8
  %op7473 = sub i64 %v7472, 32
  store i64 %op7473, ptr %slot1367, align 8
  %v7474 = load i64, ptr %slot1361, align 8
  %p7475 = inttoptr i64 %v7474 to ptr
  %rgep7476 = getelementptr i8, ptr %p7475, i64 -32
  %ld7477 = load i64, ptr %rgep7476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7477, ptr %slot1368, align 8
  %v7478 = load i64, ptr %slot1368, align 8
  %op7479 = sub i64 %v7478, 1
  store i64 %op7479, ptr %slot1369, align 8
  %v7480 = load i64, ptr %slot1369, align 8
  %cmp7481 = icmp eq i64 %v7480, 0
  %cv7482 = zext i1 %cmp7481 to i32
  store i32 %cv7482, ptr %slot1370, align 8
  %v7483 = load i32, ptr %slot1370, align 8
  %cv7484 = zext i32 %v7483 to i64
  %cond7485 = icmp ne i64 %cv7484, 0
  br i1 %cond7485, label %bb_rcglast2006, label %bb_rcgdec2006
bb_rcglast2006:
  %v7486 = load i64, ptr %slot1361, align 8
  %op7487 = sub i64 %v7486, 24
  store i64 %op7487, ptr %slot1371, align 8
  %v7488 = load i64, ptr %slot1361, align 8
  %p7489 = inttoptr i64 %v7488 to ptr
  %rgep7490 = getelementptr i8, ptr %p7489, i64 -24
  %ld7491 = load i64, ptr %rgep7490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7491, ptr %slot1372, align 8
  %v7492 = load i64, ptr %slot1372, align 8
  %cmp7493 = icmp ne i64 %v7492, 0
  %cv7494 = zext i1 %cmp7493 to i32
  store i32 %cv7494, ptr %slot1373, align 8
  %v7495 = load i32, ptr %slot1373, align 8
  %cv7496 = zext i32 %v7495 to i64
  %cond7497 = icmp ne i64 %cv7496, 0
  br i1 %cond7497, label %bb_rcgdec2006, label %bb_rcgslow2006
bb_rcgslow2006:
  %v7498 = load i64, ptr %slot1360, align 8
  %v7499 = load i64, ptr %slot1343, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7498, i64 %v7499) nomerge, !dbg !214
  br label %bb_rcgdone2006
bb_rcgdec2006:
  %v7500 = load i64, ptr %slot1369, align 8
  %v7501 = load i64, ptr %slot1361, align 8
  %p7502 = inttoptr i64 %v7501 to ptr
  %rgep7503 = getelementptr i8, ptr %p7502, i64 -32
  store i64 %v7500, ptr %rgep7503, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2006
bb_rcgclear2006:
  %v7504 = load i64, ptr %slot1343, align 8
  %p7505 = inttoptr i64 %v7504 to ptr
  store i64 0, ptr %p7505, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2006
bb_rcgdone2006:
  br label %bb_rcslotdone1975
bb_rcslotdone1975:
  %v7506 = load i64, ptr %slot12, align 8
  %p7507 = inttoptr i64 %v7506 to ptr
  %ld7508 = load i32, ptr %p7507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7508, ptr %slot1374, align 8
  %v7509 = load i32, ptr %slot1374, align 8
  %cv7510 = zext i32 %v7509 to i64
  %cond7511 = icmp ne i64 %cv7510, 0
  br i1 %cond7511, label %bb_rcslotdrop2012, label %bb_rcslotdone2012
bb_rcslotdrop2012:
  %v7512 = load i64, ptr %slot12, align 8
  %p7513 = inttoptr i64 %v7512 to ptr
  store i32 0, ptr %p7513, align 4, !alias.scope !3, !noalias !4
  %v7514 = load i64, ptr %slot46, align 8
  store i64 %v7514, ptr %slot1375, align 8
  %v7515 = load i64, ptr %slot13, align 8
  %p7516 = inttoptr i64 %v7515 to ptr
  %ld7517 = load i32, ptr %p7516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7517, ptr %slot1376, align 8
  %v7518 = load i32, ptr %slot1376, align 8
  %op7519 = and i32 %v7518, 28
  store i32 %op7519, ptr %slot1377, align 8
  %v7520 = load i32, ptr %slot1377, align 8
  %cv7521 = zext i32 %v7520 to i64
  %cond7522 = icmp ne i64 %cv7521, 0
  br i1 %cond7522, label %bb_rcslotrole2012, label %bb_rcslotowner2012
bb_rcslotrole2012:
  %v7523 = load i64, ptr %slot71, align 8
  store i64 %v7523, ptr %slot1378, align 8
  %v7524 = load i64, ptr %slot1378, align 8
  %v7525 = load i64, ptr %slot1375, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64 %v7524, i64 %v7525) nomerge, !dbg !214
  br label %bb_rcslotdone2012
bb_rcslotowner2012:
  %v7526 = load i64, ptr %slot71, align 8
  store i64 %v7526, ptr %slot1379, align 8
  %v7527 = load i64, ptr %slot1379, align 8
  %v7528 = load i64, ptr %slot1375, align 8
  call void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64 %v7527, i64 %v7528) nomerge, !dbg !214
  br label %bb_rcslotdone2012
bb_rcslotdone2012:
  %v7529 = load i64, ptr %slot10, align 8
  %p7530 = inttoptr i64 %v7529 to ptr
  %ld7531 = load i32, ptr %p7530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7531, ptr %slot1380, align 8
  %v7532 = load i32, ptr %slot1380, align 8
  %cv7533 = zext i32 %v7532 to i64
  %cond7534 = icmp ne i64 %cv7533, 0
  br i1 %cond7534, label %bb_rcslotdrop2021, label %bb_rcslotdone2021
bb_rcslotdrop2021:
  %v7535 = load i64, ptr %slot10, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  store i32 0, ptr %p7536, align 4, !alias.scope !3, !noalias !4
  %v7537 = load i64, ptr %slot43, align 8
  store i64 %v7537, ptr %slot1381, align 8
  %v7538 = load i64, ptr %slot11, align 8
  %p7539 = inttoptr i64 %v7538 to ptr
  %ld7540 = load i32, ptr %p7539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7540, ptr %slot1382, align 8
  %v7541 = load i32, ptr %slot1382, align 8
  %op7542 = and i32 %v7541, 28
  store i32 %op7542, ptr %slot1383, align 8
  %v7543 = load i32, ptr %slot1383, align 8
  %cv7544 = zext i32 %v7543 to i64
  %cond7545 = icmp ne i64 %cv7544, 0
  br i1 %cond7545, label %bb_rcslotrole2021, label %bb_rcslotowner2021
bb_rcslotrole2021:
  %v7546 = load i64, ptr %slot71, align 8
  store i64 %v7546, ptr %slot1384, align 8
  %v7547 = load i64, ptr %slot1381, align 8
  %p7548 = inttoptr i64 %v7547 to ptr
  %ld7549 = load i64, ptr %p7548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7549, ptr %slot1385, align 8
  %v7550 = load i64, ptr %slot1385, align 8
  %cmp7551 = icmp ne i64 %v7550, 0
  %cv7552 = zext i1 %cmp7551 to i32
  store i32 %cv7552, ptr %slot1386, align 8
  %v7553 = load i32, ptr %slot1386, align 8
  %cv7554 = zext i32 %v7553 to i64
  %cond7555 = icmp ne i64 %cv7554, 0
  br i1 %cond7555, label %bb_rcgnn2037, label %bb_rcgdone2037
bb_rcgnn2037:
  %v7556 = load i64, ptr %slot1385, align 8
  %op7557 = sub i64 %v7556, 16
  store i64 %op7557, ptr %slot1387, align 8
  %v7558 = load i64, ptr %slot1385, align 8
  %p7559 = inttoptr i64 %v7558 to ptr
  %rgep7560 = getelementptr i8, ptr %p7559, i64 -16
  %ld7561 = load i64, ptr %rgep7560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7561, ptr %slot1388, align 8
  %v7562 = load i64, ptr %slot1388, align 8
  %op7563 = and i64 %v7562, 4611686018427387906
  store i64 %op7563, ptr %slot1389, align 8
  %v7564 = load i64, ptr %slot1389, align 8
  %cmp7565 = icmp ne i64 %v7564, 0
  %cv7566 = zext i1 %cmp7565 to i32
  store i32 %cv7566, ptr %slot1390, align 8
  %v7567 = load i32, ptr %slot1390, align 8
  %cv7568 = zext i32 %v7567 to i64
  %cond7569 = icmp ne i64 %cv7568, 0
  br i1 %cond7569, label %bb_rcgclear2037, label %bb_rcgcounted2037
bb_rcgcounted2037:
  %v7570 = load i64, ptr %slot1385, align 8
  %op7571 = sub i64 %v7570, 24
  store i64 %op7571, ptr %slot1391, align 8
  %v7572 = load i64, ptr %slot1385, align 8
  %p7573 = inttoptr i64 %v7572 to ptr
  %rgep7574 = getelementptr i8, ptr %p7573, i64 -24
  %ld7575 = load i64, ptr %rgep7574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7575, ptr %slot1392, align 8
  %v7576 = load i64, ptr %slot1392, align 8
  %op7577 = sub i64 %v7576, 1
  store i64 %op7577, ptr %slot1393, align 8
  %v7578 = load i64, ptr %slot1393, align 8
  %cmp7579 = icmp eq i64 %v7578, 0
  %cv7580 = zext i1 %cmp7579 to i32
  store i32 %cv7580, ptr %slot1394, align 8
  %v7581 = load i32, ptr %slot1394, align 8
  %cv7582 = zext i32 %v7581 to i64
  %cond7583 = icmp ne i64 %cv7582, 0
  br i1 %cond7583, label %bb_rcglast2037, label %bb_rcgdec2037
bb_rcglast2037:
  %v7584 = load i64, ptr %slot1385, align 8
  %op7585 = sub i64 %v7584, 32
  store i64 %op7585, ptr %slot1395, align 8
  %v7586 = load i64, ptr %slot1385, align 8
  %p7587 = inttoptr i64 %v7586 to ptr
  %rgep7588 = getelementptr i8, ptr %p7587, i64 -32
  %ld7589 = load i64, ptr %rgep7588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7589, ptr %slot1396, align 8
  %v7590 = load i64, ptr %slot1396, align 8
  %cmp7591 = icmp ne i64 %v7590, 0
  %cv7592 = zext i1 %cmp7591 to i32
  store i32 %cv7592, ptr %slot1397, align 8
  %v7593 = load i32, ptr %slot1397, align 8
  %cv7594 = zext i32 %v7593 to i64
  %cond7595 = icmp ne i64 %cv7594, 0
  br i1 %cond7595, label %bb_rcgdec2037, label %bb_rcgslow2037
bb_rcgslow2037:
  %v7596 = load i64, ptr %slot1384, align 8
  %v7597 = load i64, ptr %slot1381, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_unloan(i64 %v7596, i64 %v7597) nomerge, !dbg !214
  br label %bb_rcgdone2037
bb_rcgdec2037:
  %v7598 = load i64, ptr %slot1393, align 8
  %v7599 = load i64, ptr %slot1385, align 8
  %p7600 = inttoptr i64 %v7599 to ptr
  %rgep7601 = getelementptr i8, ptr %p7600, i64 -24
  store i64 %v7598, ptr %rgep7601, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2037
bb_rcgclear2037:
  %v7602 = load i64, ptr %slot1381, align 8
  %p7603 = inttoptr i64 %v7602 to ptr
  store i64 0, ptr %p7603, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2037
bb_rcgdone2037:
  br label %bb_rcslotdone2021
bb_rcslotowner2021:
  %v7604 = load i64, ptr %slot71, align 8
  store i64 %v7604, ptr %slot1398, align 8
  %v7605 = load i64, ptr %slot1381, align 8
  %p7606 = inttoptr i64 %v7605 to ptr
  %ld7607 = load i64, ptr %p7606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7607, ptr %slot1399, align 8
  %v7608 = load i64, ptr %slot1399, align 8
  %cmp7609 = icmp ne i64 %v7608, 0
  %cv7610 = zext i1 %cmp7609 to i32
  store i32 %cv7610, ptr %slot1400, align 8
  %v7611 = load i32, ptr %slot1400, align 8
  %cv7612 = zext i32 %v7611 to i64
  %cond7613 = icmp ne i64 %cv7612, 0
  br i1 %cond7613, label %bb_rcgnn2052, label %bb_rcgdone2052
bb_rcgnn2052:
  %v7614 = load i64, ptr %slot1399, align 8
  %op7615 = sub i64 %v7614, 16
  store i64 %op7615, ptr %slot1401, align 8
  %v7616 = load i64, ptr %slot1399, align 8
  %p7617 = inttoptr i64 %v7616 to ptr
  %rgep7618 = getelementptr i8, ptr %p7617, i64 -16
  %ld7619 = load i64, ptr %rgep7618, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7619, ptr %slot1402, align 8
  %v7620 = load i64, ptr %slot1402, align 8
  %op7621 = and i64 %v7620, 4611686018427387906
  store i64 %op7621, ptr %slot1403, align 8
  %v7622 = load i64, ptr %slot1403, align 8
  %cmp7623 = icmp ne i64 %v7622, 0
  %cv7624 = zext i1 %cmp7623 to i32
  store i32 %cv7624, ptr %slot1404, align 8
  %v7625 = load i32, ptr %slot1404, align 8
  %cv7626 = zext i32 %v7625 to i64
  %cond7627 = icmp ne i64 %cv7626, 0
  br i1 %cond7627, label %bb_rcgclear2052, label %bb_rcgcounted2052
bb_rcgcounted2052:
  %v7628 = load i64, ptr %slot1399, align 8
  %op7629 = sub i64 %v7628, 32
  store i64 %op7629, ptr %slot1405, align 8
  %v7630 = load i64, ptr %slot1399, align 8
  %p7631 = inttoptr i64 %v7630 to ptr
  %rgep7632 = getelementptr i8, ptr %p7631, i64 -32
  %ld7633 = load i64, ptr %rgep7632, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7633, ptr %slot1406, align 8
  %v7634 = load i64, ptr %slot1406, align 8
  %op7635 = sub i64 %v7634, 1
  store i64 %op7635, ptr %slot1407, align 8
  %v7636 = load i64, ptr %slot1407, align 8
  %cmp7637 = icmp eq i64 %v7636, 0
  %cv7638 = zext i1 %cmp7637 to i32
  store i32 %cv7638, ptr %slot1408, align 8
  %v7639 = load i32, ptr %slot1408, align 8
  %cv7640 = zext i32 %v7639 to i64
  %cond7641 = icmp ne i64 %cv7640, 0
  br i1 %cond7641, label %bb_rcglast2052, label %bb_rcgdec2052
bb_rcglast2052:
  %v7642 = load i64, ptr %slot1399, align 8
  %op7643 = sub i64 %v7642, 24
  store i64 %op7643, ptr %slot1409, align 8
  %v7644 = load i64, ptr %slot1399, align 8
  %p7645 = inttoptr i64 %v7644 to ptr
  %rgep7646 = getelementptr i8, ptr %p7645, i64 -24
  %ld7647 = load i64, ptr %rgep7646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7647, ptr %slot1410, align 8
  %v7648 = load i64, ptr %slot1410, align 8
  %cmp7649 = icmp ne i64 %v7648, 0
  %cv7650 = zext i1 %cmp7649 to i32
  store i32 %cv7650, ptr %slot1411, align 8
  %v7651 = load i32, ptr %slot1411, align 8
  %cv7652 = zext i32 %v7651 to i64
  %cond7653 = icmp ne i64 %cv7652, 0
  br i1 %cond7653, label %bb_rcgdec2052, label %bb_rcgslow2052
bb_rcgslow2052:
  %v7654 = load i64, ptr %slot1398, align 8
  %v7655 = load i64, ptr %slot1381, align 8
  call void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_drop(i64 %v7654, i64 %v7655) nomerge, !dbg !214
  br label %bb_rcgdone2052
bb_rcgdec2052:
  %v7656 = load i64, ptr %slot1407, align 8
  %v7657 = load i64, ptr %slot1399, align 8
  %p7658 = inttoptr i64 %v7657 to ptr
  %rgep7659 = getelementptr i8, ptr %p7658, i64 -32
  store i64 %v7656, ptr %rgep7659, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2052
bb_rcgclear2052:
  %v7660 = load i64, ptr %slot1381, align 8
  %p7661 = inttoptr i64 %v7660 to ptr
  store i64 0, ptr %p7661, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2052
bb_rcgdone2052:
  br label %bb_rcslotdone2021
bb_rcslotdone2021:
  %v7662 = load i64, ptr %slot8, align 8
  %p7663 = inttoptr i64 %v7662 to ptr
  %ld7664 = load i32, ptr %p7663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7664, ptr %slot1412, align 8
  %v7665 = load i32, ptr %slot1412, align 8
  %cv7666 = zext i32 %v7665 to i64
  %cond7667 = icmp ne i64 %cv7666, 0
  br i1 %cond7667, label %bb_rcslotdrop2058, label %bb_rcslotdone2058
bb_rcslotdrop2058:
  %v7668 = load i64, ptr %slot8, align 8
  %p7669 = inttoptr i64 %v7668 to ptr
  store i32 0, ptr %p7669, align 4, !alias.scope !3, !noalias !4
  %v7670 = load i64, ptr %slot42, align 8
  store i64 %v7670, ptr %slot1413, align 8
  %v7671 = load i64, ptr %slot9, align 8
  %p7672 = inttoptr i64 %v7671 to ptr
  %ld7673 = load i32, ptr %p7672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7673, ptr %slot1414, align 8
  %v7674 = load i32, ptr %slot1414, align 8
  %op7675 = and i32 %v7674, 28
  store i32 %op7675, ptr %slot1415, align 8
  %v7676 = load i32, ptr %slot1415, align 8
  %cv7677 = zext i32 %v7676 to i64
  %cond7678 = icmp ne i64 %cv7677, 0
  br i1 %cond7678, label %bb_rcslotrole2058, label %bb_rcslotowner2058
bb_rcslotrole2058:
  %v7679 = load i64, ptr %slot71, align 8
  store i64 %v7679, ptr %slot1416, align 8
  %v7680 = load i64, ptr %slot1416, align 8
  %v7681 = load i64, ptr %slot1413, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v7680, i64 %v7681) nomerge, !dbg !214
  br label %bb_rcslotdone2058
bb_rcslotowner2058:
  %v7682 = load i64, ptr %slot71, align 8
  store i64 %v7682, ptr %slot1417, align 8
  %v7683 = load i64, ptr %slot1417, align 8
  %v7684 = load i64, ptr %slot1413, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v7683, i64 %v7684) nomerge, !dbg !214
  br label %bb_rcslotdone2058
bb_rcslotdone2058:
  %v7685 = load i64, ptr %slot6, align 8
  %p7686 = inttoptr i64 %v7685 to ptr
  %ld7687 = load i32, ptr %p7686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7687, ptr %slot1418, align 8
  %v7688 = load i32, ptr %slot1418, align 8
  %cv7689 = zext i32 %v7688 to i64
  %cond7690 = icmp ne i64 %cv7689, 0
  br i1 %cond7690, label %bb_rcslotdrop2104, label %bb_rcslotdone2104
bb_rcslotdrop2104:
  %v7691 = load i64, ptr %slot6, align 8
  %p7692 = inttoptr i64 %v7691 to ptr
  store i32 0, ptr %p7692, align 4, !alias.scope !3, !noalias !4
  %v7693 = load i64, ptr %slot38, align 8
  store i64 %v7693, ptr %slot1419, align 8
  %v7694 = load i64, ptr %slot7, align 8
  %p7695 = inttoptr i64 %v7694 to ptr
  %ld7696 = load i32, ptr %p7695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7696, ptr %slot1420, align 8
  %v7697 = load i32, ptr %slot1420, align 8
  %op7698 = and i32 %v7697, 28
  store i32 %op7698, ptr %slot1421, align 8
  %v7699 = load i32, ptr %slot1421, align 8
  %cv7700 = zext i32 %v7699 to i64
  %cond7701 = icmp ne i64 %cv7700, 0
  br i1 %cond7701, label %bb_rcslotrole2104, label %bb_rcslotowner2104
bb_rcslotrole2104:
  %v7702 = load i64, ptr %slot71, align 8
  store i64 %v7702, ptr %slot1422, align 8
  %v7703 = load i64, ptr %slot1422, align 8
  %v7704 = load i64, ptr %slot1419, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64 %v7703, i64 %v7704) nomerge, !dbg !214
  br label %bb_rcslotdone2104
bb_rcslotowner2104:
  %v7705 = load i64, ptr %slot71, align 8
  store i64 %v7705, ptr %slot1423, align 8
  %v7706 = load i64, ptr %slot1423, align 8
  %v7707 = load i64, ptr %slot1419, align 8
  call void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64 %v7706, i64 %v7707) nomerge, !dbg !214
  br label %bb_rcslotdone2104
bb_rcslotdone2104:
  %v7708 = load i64, ptr %slot1325, align 8
  ret i64 %v7708
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6c20f2e9fdceb7f443853563e8f4b2f8857cebc813cc7546dd2353da4642f0e3(i64, i64, i64, i64, i64, i64)
declare i64 @myl_f_6c451ed7783819339d6a97e09e92dab80bed1c7f916652951c948a247067c577(i64, i64)
declare i64 @myl_f_cb8ba6198d12c121b91c6eca86ed4537aaff0ed5acaf8eda6f904a4b0d563a06(i64, i64, i64)
declare i64 @myl_f_def2c666f56e2a58d1d9c20e576b253ae4c59134494ab501e84450cede719ab2(i64, i64, i64)
declare i64 @myl_f_fa0b1953e8cd9a109ffbfa6357a620ad23550d479633b6aae1a336955a026eac(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64, i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64, i64)
declare void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64, i64)
declare void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_drop(i64, i64)
declare void @myl_t_a10eb91fc861f232848ef533f4e2fa9d781cc529abf2107c912ee4dd2100ccc6_rcg_unloan(i64, i64)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_drop(i64, i64)
declare i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_loan(i64, i64, i64)
declare i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_take(i64, i64, i64, i32)
declare void @myl_t_eeb4cb563f98af677e03c283ca4c16d38534011be2beff837b30ca2a0e72b4a3_rcg_unloan(i64, i64)
declare void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_drop(i64, i64)
declare i32 @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_loan(i64, i64, i64)
declare i32 @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_take(i64, i64, i64, i32)
declare void @myl_t_f7a9f551d46985a8c229f58c4088a6a2e4423769d5e28077464f6b2fcddff0ce_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11, !14}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11, !14}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11, !14}
!11 = distinct !{!11, !0, !"element 80v"}
!12 = !{!11}
!13 = !{!1, !5, !14}
!14 = distinct !{!14, !0, !"element 8v"}
!15 = !{!14}
!16 = !{!1, !5, !11}
!10000000 = !{!1, !2}
!10000001 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_765a4e7fba842652f08bd096aee9774e4d1abd4bfff41376fcf8988cbf0b51ea", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_765a4e7fba842652f08bd096aee9774e4d1abd4bfff41376fcf8988cbf0b51ea", linkageName: "myl_f_765a4e7fba842652f08bd096aee9774e4d1abd4bfff41376fcf8988cbf0b51ea", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7106473997084926686, i64 0, !"myl_f_765a4e7fba842652f08bd096aee9774e4d1abd4bfff41376fcf8988cbf0b51ea"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!130 = !DILocation(line: 30, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!134 = !DILocation(line: 35, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!138 = !DILocation(line: 37, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!140 = !DILocation(line: 39, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!142 = !DILocation(line: 40, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!144 = !DILocation(line: 44, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!146 = !DILocation(line: 51, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!148 = !DILocation(line: 54, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!150 = !DILocation(line: 55, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!152 = !DILocation(line: 58, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!154 = !DILocation(line: 68, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!156 = !DILocation(line: 72, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!158 = !DILocation(line: 73, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!160 = !DILocation(line: 76, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!162 = !DILocation(line: 80, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647207)
!164 = !DILocation(line: 84, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!166 = !DILocation(line: 85, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!168 = !DILocation(line: 89, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!170 = !DILocation(line: 96, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!172 = !DILocation(line: 99, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647359)
!174 = !DILocation(line: 103, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!176 = !DILocation(line: 106, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!178 = !DILocation(line: 110, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!180 = !DILocation(line: 114, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!182 = !DILocation(line: 117, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647479)
!184 = !DILocation(line: 118, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647487)
!186 = !DILocation(line: 119, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647551)
!188 = !DILocation(line: 127, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647567)
!190 = !DILocation(line: 129, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647607)
!192 = !DILocation(line: 134, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647615)
!194 = !DILocation(line: 135, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647631)
!196 = !DILocation(line: 137, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647639)
!198 = !DILocation(line: 138, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647671)
!200 = !DILocation(line: 142, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647679)
!202 = !DILocation(line: 143, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647687)
!204 = !DILocation(line: 144, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647743)
!206 = !DILocation(line: 151, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647759)
!208 = !DILocation(line: 153, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647783)
!210 = !DILocation(line: 156, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647791)
!212 = !DILocation(line: 157, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647823)
!214 = !DILocation(line: 161, column: 0, scope: !215)
