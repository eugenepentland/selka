target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_0cfc6485219ed7d9417414c1e26227712e5f12f332f6c4bd39a23ea4ecbf023e(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v979 = load i64, ptr %slot1, align 8
  %op980 = add i64 %v979, 32
  store i64 %op980, ptr %slot5, align 8
  %mem981 = alloca i8, i64 8, align 8
  %ptr982 = ptrtoint ptr %mem981 to i64
  store i64 %ptr982, ptr %slot6, align 8
  %mem983 = alloca i8, i64 8, align 8
  %ptr984 = ptrtoint ptr %mem983 to i64
  store i64 %ptr984, ptr %slot7, align 8
  %mem985 = alloca i8, i64 8, align 8
  %ptr986 = ptrtoint ptr %mem985 to i64
  store i64 %ptr986, ptr %slot8, align 8
  %mem987 = alloca i8, i64 8, align 8
  %ptr988 = ptrtoint ptr %mem987 to i64
  store i64 %ptr988, ptr %slot9, align 8
  %mem989 = alloca i8, i64 8, align 8
  %ptr990 = ptrtoint ptr %mem989 to i64
  store i64 %ptr990, ptr %slot10, align 8
  %mem991 = alloca i8, i64 8, align 8
  %ptr992 = ptrtoint ptr %mem991 to i64
  store i64 %ptr992, ptr %slot11, align 8
  %mem993 = alloca i8, i64 8, align 8
  %ptr994 = ptrtoint ptr %mem993 to i64
  store i64 %ptr994, ptr %slot12, align 8
  %mem995 = alloca i8, i64 8, align 8
  %ptr996 = ptrtoint ptr %mem995 to i64
  store i64 %ptr996, ptr %slot13, align 8
  %mem997 = alloca i8, i64 8, align 8
  %ptr998 = ptrtoint ptr %mem997 to i64
  store i64 %ptr998, ptr %slot14, align 8
  %mem999 = alloca i8, i64 8, align 8
  %ptr1000 = ptrtoint ptr %mem999 to i64
  store i64 %ptr1000, ptr %slot15, align 8
  %mem1001 = alloca i8, i64 8, align 8
  %ptr1002 = ptrtoint ptr %mem1001 to i64
  store i64 %ptr1002, ptr %slot16, align 8
  %mem1003 = alloca i8, i64 8, align 8
  %ptr1004 = ptrtoint ptr %mem1003 to i64
  store i64 %ptr1004, ptr %slot17, align 8
  %mem1005 = alloca i8, i64 32, align 8
  %ptr1006 = ptrtoint ptr %mem1005 to i64
  store i64 %ptr1006, ptr %slot18, align 8
  %mem1007 = alloca i8, i64 32, align 8
  %ptr1008 = ptrtoint ptr %mem1007 to i64
  store i64 %ptr1008, ptr %slot19, align 8
  %mem1009 = alloca i8, i64 8, align 8
  %ptr1010 = ptrtoint ptr %mem1009 to i64
  store i64 %ptr1010, ptr %slot20, align 8
  %mem1011 = alloca i8, i64 8, align 8
  %ptr1012 = ptrtoint ptr %mem1011 to i64
  store i64 %ptr1012, ptr %slot21, align 8
  %mem1013 = alloca i8, i64 8, align 8
  %ptr1014 = ptrtoint ptr %mem1013 to i64
  store i64 %ptr1014, ptr %slot22, align 8
  %mem1015 = alloca i8, i64 8, align 8
  %ptr1016 = ptrtoint ptr %mem1015 to i64
  store i64 %ptr1016, ptr %slot23, align 8
  %mem1017 = alloca i8, i64 8, align 8
  %ptr1018 = ptrtoint ptr %mem1017 to i64
  store i64 %ptr1018, ptr %slot24, align 8
  %mem1019 = alloca i8, i64 8, align 8
  %ptr1020 = ptrtoint ptr %mem1019 to i64
  store i64 %ptr1020, ptr %slot25, align 8
  %mem1021 = alloca i8, i64 8, align 8
  %ptr1022 = ptrtoint ptr %mem1021 to i64
  store i64 %ptr1022, ptr %slot26, align 8
  %mem1023 = alloca i8, i64 8, align 8
  %ptr1024 = ptrtoint ptr %mem1023 to i64
  store i64 %ptr1024, ptr %slot27, align 8
  %mem1025 = alloca i8, i64 8, align 8
  %ptr1026 = ptrtoint ptr %mem1025 to i64
  store i64 %ptr1026, ptr %slot28, align 8
  %mem1027 = alloca i8, i64 8, align 8
  %ptr1028 = ptrtoint ptr %mem1027 to i64
  store i64 %ptr1028, ptr %slot29, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1029 = alloca i8, i64 8, align 8
  %ptr1030 = ptrtoint ptr %mem1029 to i64
  store i64 %ptr1030, ptr %slot30, align 8
  %v1031 = load i64, ptr %slot1, align 8
  %op1032 = add i64 %v1031, 64
  store i64 %op1032, ptr %slot31, align 8
  %v1033 = load i64, ptr %slot31, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  %ld1035 = load i64, ptr %p1034, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1035, ptr %slot32, align 8
  %stack1036 = call ptr @llvm.stacksave()
  %stackaddr1037 = ptrtoint ptr %stack1036 to i64
  %v1038 = load i64, ptr %slot32, align 8
  %cmp1039 = icmp ult i64 %stackaddr1037, %v1038
  %cv1040 = zext i1 %cmp1039 to i64
  store i64 %cv1040, ptr %slot33, align 8
  %v1041 = load i64, ptr %slot33, align 8
  %cond1042 = icmp ne i64 %v1041, 0
  br i1 %cond1042, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1043 = load i64, ptr %slot1, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  call void @myl_qbe_fail_frame(ptr %p1044) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1045 = load i64, ptr %slot23, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i64 0, ptr %p1046, align 8, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot24, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i64 0, ptr %p1048, align 8, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot25, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i64 0, ptr %p1050, align 8, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot2, align 8
  %v1052 = load i64, ptr %slot20, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i64 %v1051, ptr %p1053, align 8, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot3, align 8
  %v1055 = load i64, ptr %slot21, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  store i64 %v1054, ptr %p1056, align 8, !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot4, align 8
  %v1058 = load i64, ptr %slot22, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i64 %v1057, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot1, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %call1062 = call ptr @myl_qbe_heap(ptr %p1061) nomerge, !dbg !112
  %calladdr1063 = ptrtoint ptr %call1062 to i64
  store i64 %calladdr1063, ptr %slot34, align 8
  %v1064 = load i64, ptr %slot1, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %call1066 = call i64 @myl_qbe_region_mark(ptr %p1065) nomerge, !dbg !112
  store i64 %call1066, ptr %slot35, align 8
  %v1067 = load i64, ptr %slot6, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i32 0, ptr %p1068, align 4, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot7, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i32 0, ptr %p1070, align 4, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot8, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  store i32 0, ptr %p1072, align 4, !alias.scope !3, !noalias !4
  %v1073 = load i64, ptr %slot9, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  store i32 0, ptr %p1074, align 4, !alias.scope !3, !noalias !4
  %v1075 = load i64, ptr %slot10, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i32 0, ptr %p1076, align 4, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot11, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  store i32 0, ptr %p1078, align 4, !alias.scope !3, !noalias !4
  %v1079 = load i64, ptr %slot12, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i32 0, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  %v1081 = load i64, ptr %slot13, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i32 0, ptr %p1082, align 4, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot14, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i32 0, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot15, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i32 0, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot7, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  store i32 2, ptr %p1088, align 4, !alias.scope !3, !noalias !4
  %v1089 = load i64, ptr %slot9, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  store i32 2, ptr %p1090, align 4, !alias.scope !3, !noalias !4
  %v1091 = load i64, ptr %slot11, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  store i32 2, ptr %p1092, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1093 = load i64, ptr %slot26, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  store i64 0, ptr %p1094, align 8, !alias.scope !3, !noalias !4
  %v1095 = load i64, ptr %slot26, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %ld1097 = load i64, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1097, ptr %slot36, align 8
  %v1098 = load i64, ptr %slot36, align 8
  %cmp1099 = icmp sge i64 %v1098, 0
  %cv1100 = zext i1 %cmp1099 to i64
  store i64 %cv1100, ptr %slot37, align 8
  %v1101 = load i64, ptr %slot37, align 8
  %cond1102 = icmp ne i64 %v1101, 0
  br i1 %cond1102, label %bb_success14, label %bb_failed14
bb_failed14:
  %v1103 = load i64, ptr %slot1, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1104) nomerge, !dbg !114
  unreachable
bb_success14:
  %v1105 = load i64, ptr %slot34, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  %p1107 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v1108 = load i64, ptr %slot36, align 8
  %call1109 = call ptr @myl_native_list_new(ptr %p1106, ptr %p1107, i64 %v1108) nomerge, !dbg !114
  %calladdr1110 = ptrtoint ptr %call1109 to i64
  store i64 %calladdr1110, ptr %slot38, align 8
  %v1111 = load i64, ptr %slot38, align 8
  %cond1112 = icmp ne i64 %v1111, 0
  br i1 %cond1112, label %bb_success16, label %bb_failed16
bb_failed16:
  %v1113 = load i64, ptr %slot1, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1114) nomerge, !dbg !114
  unreachable
bb_success16:
  %v1115 = load i64, ptr %slot38, align 8
  %v1116 = load i64, ptr %slot26, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  store i64 %v1115, ptr %p1117, align 8, !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot26, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  %ld1120 = load i64, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1120, ptr %slot39, align 8
  %v1121 = load i64, ptr %slot39, align 8
  %v1122 = load i64, ptr %slot17, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  store i64 %v1121, ptr %p1123, align 8, !alias.scope !3, !noalias !4
  %v1124 = load i64, ptr %slot17, align 8
  store i64 %v1124, ptr %slot40, align 8
  %v1125 = load i64, ptr %slot18, align 8
  store i64 %v1125, ptr %slot41, align 8
  %v1126 = load i64, ptr %slot40, align 8
  %v1127 = load i64, ptr %slot41, align 8
  %p1128 = inttoptr i64 %v1126 to ptr
  %p1129 = inttoptr i64 %v1127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1129, ptr %p1128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot15, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i32 2, ptr %p1131, align 4, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot14, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i32 1, ptr %p1133, align 4, !alias.scope !3, !noalias !4
  %v1134 = load i64, ptr %slot16, align 8
  store i64 %v1134, ptr %slot42, align 8
  %v1135 = load i64, ptr %slot18, align 8
  store i64 %v1135, ptr %slot43, align 8
  %v1136 = load i64, ptr %slot43, align 8
  %v1137 = load i64, ptr %slot42, align 8
  %p1138 = inttoptr i64 %v1136 to ptr
  %p1139 = inttoptr i64 %v1137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1139, ptr %p1138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot13, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 2, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot15, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i32, ptr %p1143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1144, ptr %slot44, align 8
  %v1145 = load i32, ptr %slot44, align 8
  %v1146 = load i64, ptr %slot13, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 %v1145, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot14, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i32 0, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot12, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i32 1, ptr %p1151, align 4, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot42, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i64, ptr %p1153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1154, ptr %slot45, align 8
  %v1155 = load i64, ptr %slot45, align 8
  %v1156 = load i64, ptr %slot26, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i64 %v1155, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot26, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %ld1160 = load i64, ptr %p1159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1160, ptr %slot46, align 8
  %v1161 = load i64, ptr %slot46, align 8
  %v1162 = load i64, ptr %slot17, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i64 %v1161, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot17, align 8
  store i64 %v1164, ptr %slot47, align 8
  %v1165 = load i64, ptr %slot12, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i32, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1167, ptr %slot48, align 8
  %v1168 = load i64, ptr %slot13, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i32, ptr %p1169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1170, ptr %slot49, align 8
  %v1171 = load i32, ptr %slot49, align 8
  %op1172 = and i32 %v1171, 24
  store i32 %op1172, ptr %slot49, align 8
  %v1173 = load i32, ptr %slot49, align 8
  %cmp1174 = icmp eq i32 %v1173, 0
  %cv1175 = zext i1 %cmp1174 to i32
  store i32 %cv1175, ptr %slot50, align 8
  %v1176 = load i32, ptr %slot48, align 8
  %v1177 = load i32, ptr %slot50, align 8
  %op1178 = and i32 %v1176, %v1177
  store i32 %op1178, ptr %slot51, align 8
  %v1179 = load i32, ptr %slot51, align 8
  %cv1180 = zext i32 %v1179 to i64
  %cond1181 = icmp ne i64 %cv1180, 0
  br i1 %cond1181, label %bb_rcprivateown39, label %bb_rcprivateloan39
bb_rcprivateown39:
  %v1182 = load i64, ptr %slot18, align 8
  store i64 %v1182, ptr %slot52, align 8
  %v1183 = load i64, ptr %slot35, align 8
  store i64 %v1183, ptr %slot53, align 8
  %v1184 = load i64, ptr %slot47, align 8
  %v1185 = load i64, ptr %slot52, align 8
  %op1186 = sub i64 %v1184, %v1185
  store i64 %op1186, ptr %slot54, align 8
  %v1187 = load i64, ptr %slot52, align 8
  %v1188 = load i64, ptr %slot47, align 8
  %op1189 = sub i64 %v1187, %v1188
  store i64 %op1189, ptr %slot55, align 8
  %v1190 = load i64, ptr %slot54, align 8
  %cmp1191 = icmp ult i64 %v1190, 8
  %cv1192 = zext i1 %cmp1191 to i32
  store i32 %cv1192, ptr %slot56, align 8
  %v1193 = load i64, ptr %slot55, align 8
  %cmp1194 = icmp ult i64 %v1193, 8
  %cv1195 = zext i1 %cmp1194 to i32
  store i32 %cv1195, ptr %slot57, align 8
  %v1196 = load i32, ptr %slot56, align 8
  %v1197 = load i32, ptr %slot57, align 8
  %op1198 = or i32 %v1196, %v1197
  store i32 %op1198, ptr %slot58, align 8
  %v1199 = load i32, ptr %slot58, align 8
  %cv1200 = zext i32 %v1199 to i64
  %cond1201 = icmp ne i64 %cv1200, 0
  br i1 %cond1201, label %bb_rcmoveslow42, label %bb_rcmovecheck42
bb_rcmovecheck42:
  %v1202 = load i64, ptr %slot47, align 8
  %p1204 = inttoptr i64 %v1202 to ptr
  %gep1205 = getelementptr i8, ptr %p1204, i64 0
  %op1203 = ptrtoint ptr %gep1205 to i64
  store i64 %op1203, ptr %slot59, align 8
  %v1206 = load i64, ptr %slot59, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  %ld1208 = load i64, ptr %p1207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1208, ptr %slot60, align 8
  %v1209 = load i64, ptr %slot60, align 8
  %cmp1210 = icmp ne i64 %v1209, 0
  %cv1211 = zext i1 %cmp1210 to i32
  store i32 %cv1211, ptr %slot61, align 8
  %v1212 = load i32, ptr %slot61, align 8
  %cv1213 = zext i32 %v1212 to i64
  %cond1214 = icmp ne i64 %cv1213, 0
  br i1 %cond1214, label %bb_rcmoveheader50, label %bb_rcmovenext50
bb_rcmoveheader50:
  %v1215 = load i64, ptr %slot60, align 8
  %op1216 = sub i64 %v1215, 16
  store i64 %op1216, ptr %slot62, align 8
  %v1217 = load i64, ptr %slot60, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %rgep1219 = getelementptr i8, ptr %p1218, i64 -16
  %ld1220 = load i64, ptr %rgep1219, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1220, ptr %slot63, align 8
  %v1221 = load i64, ptr %slot63, align 8
  %op1222 = and i64 %v1221, 5764607523034234881
  store i64 %op1222, ptr %slot64, align 8
  %v1223 = load i64, ptr %slot64, align 8
  %cmp1224 = icmp ne i64 %v1223, 0
  %cv1225 = zext i1 %cmp1224 to i32
  store i32 %cv1225, ptr %slot65, align 8
  %v1226 = load i32, ptr %slot65, align 8
  %cv1227 = zext i32 %v1226 to i64
  %cond1228 = icmp ne i64 %cv1227, 0
  br i1 %cond1228, label %bb_rcmoveslow42, label %bb_rcmovenext50
bb_rcmovenext50:
  %v1229 = load i64, ptr %slot47, align 8
  %v1230 = load i64, ptr %slot52, align 8
  %p1231 = inttoptr i64 %v1229 to ptr
  %p1232 = inttoptr i64 %v1230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1232, ptr %p1231, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot47, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i64 0, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved42
bb_rcmoveslow42:
  %v1235 = load i64, ptr %slot34, align 8
  %v1236 = load i64, ptr %slot52, align 8
  %v1237 = load i64, ptr %slot47, align 8
  %v1238 = load i64, ptr %slot53, align 8
  %cv1239 = trunc i64 %v1238 to i32
  %call1240 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1235, i64 %v1236, i64 %v1237, i32 %cv1239) nomerge, !dbg !116
  store i32 %call1240, ptr %slot66, align 8
  %v1241 = load i32, ptr %slot66, align 8
  %cv1242 = zext i32 %v1241 to i64
  %cond1243 = icmp ne i64 %cv1242, 0
  br i1 %cond1243, label %bb_rcsuccess57, label %bb_rcfailure57
bb_rcfailure57:
  %v1244 = load i64, ptr %slot34, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %call1246 = call i32 @myl_rc_take_failure(ptr %p1245) nomerge, !dbg !116
  store i32 %call1246, ptr %slot67, align 8
  %v1247 = load i64, ptr %slot1, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %v1249 = load i32, ptr %slot67, align 8
  %call1250 = call i32 @myl_qbe_rc_status(ptr %p1248, i32 %v1249) nomerge, !dbg !116
  store i32 %call1250, ptr %slot68, align 8
  br label %bb_failure
bb_rcsuccess57:
  br label %bb_rcmoved42
bb_rcmoved42:
  %v1251 = load i64, ptr %slot12, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  store i32 0, ptr %p1252, align 4, !alias.scope !3, !noalias !4
  %v1253 = load i64, ptr %slot15, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i32 2, ptr %p1254, align 4, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot14, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i32 1, ptr %p1256, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared39
bb_rcprivateloan39:
  %v1257 = load i64, ptr %slot12, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i32, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1259, ptr %slot69, align 8
  %v1260 = load i64, ptr %slot13, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %ld1262 = load i32, ptr %p1261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1262, ptr %slot70, align 8
  %v1263 = load i32, ptr %slot70, align 8
  %cmp1264 = icmp eq i32 %v1263, 16
  %cv1265 = zext i1 %cmp1264 to i32
  store i32 %cv1265, ptr %slot71, align 8
  %v1266 = load i32, ptr %slot71, align 8
  %v1267 = load i32, ptr %slot69, align 8
  %op1268 = and i32 %v1266, %v1267
  store i32 %op1268, ptr %slot71, align 8
  %v1269 = load i32, ptr %slot71, align 8
  %cv1270 = zext i32 %v1269 to i64
  %cond1271 = icmp ne i64 %cv1270, 0
  br i1 %cond1271, label %bb_rcprivatemove39, label %bb_rcprivatenew39
bb_rcprivatemove39:
  %v1272 = load i64, ptr %slot18, align 8
  store i64 %v1272, ptr %slot72, align 8
  %v1273 = load i64, ptr %slot47, align 8
  %v1274 = load i64, ptr %slot72, align 8
  %p1275 = inttoptr i64 %v1273 to ptr
  %p1276 = inttoptr i64 %v1274 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1276, ptr %p1275, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1277 = load i64, ptr %slot47, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  store i64 0, ptr %p1278, align 8, !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot15, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i32 2, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot15, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 16, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot14, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  store i32 1, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  %v1285 = load i64, ptr %slot12, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  store i32 0, ptr %p1286, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared39
bb_rcprivatenew39:
  %v1287 = load i64, ptr %slot18, align 8
  store i64 %v1287, ptr %slot73, align 8
  %v1288 = load i64, ptr %slot47, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i64, ptr %p1289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1290, ptr %slot74, align 8
  %v1291 = load i64, ptr %slot74, align 8
  %cmp1292 = icmp ne i64 %v1291, 0
  %cv1293 = zext i1 %cmp1292 to i32
  store i32 %cv1293, ptr %slot75, align 8
  %v1294 = load i32, ptr %slot75, align 8
  %cv1295 = zext i32 %v1294 to i64
  %cond1296 = icmp ne i64 %cv1295, 0
  br i1 %cond1296, label %bb_rcgnn75, label %bb_rcgstore75
bb_rcgnn75:
  %v1297 = load i64, ptr %slot74, align 8
  %op1298 = sub i64 %v1297, 16
  store i64 %op1298, ptr %slot76, align 8
  %v1299 = load i64, ptr %slot74, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  %rgep1301 = getelementptr i8, ptr %p1300, i64 -16
  %ld1302 = load i64, ptr %rgep1301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1302, ptr %slot77, align 8
  %v1303 = load i64, ptr %slot77, align 8
  %op1304 = and i64 %v1303, 4611686018427387906
  store i64 %op1304, ptr %slot78, align 8
  %v1305 = load i64, ptr %slot78, align 8
  %cmp1306 = icmp ne i64 %v1305, 0
  %cv1307 = zext i1 %cmp1306 to i32
  store i32 %cv1307, ptr %slot79, align 8
  %v1308 = load i32, ptr %slot79, align 8
  %cv1309 = zext i32 %v1308 to i64
  %cond1310 = icmp ne i64 %cv1309, 0
  br i1 %cond1310, label %bb_rcgstore75, label %bb_rcginc75
bb_rcginc75:
  %v1311 = load i64, ptr %slot74, align 8
  %op1312 = sub i64 %v1311, 24
  store i64 %op1312, ptr %slot80, align 8
  %v1313 = load i64, ptr %slot74, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %rgep1315 = getelementptr i8, ptr %p1314, i64 -24
  %ld1316 = load i64, ptr %rgep1315, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1316, ptr %slot81, align 8
  %v1317 = load i64, ptr %slot81, align 8
  %op1318 = add i64 %v1317, 1
  store i64 %op1318, ptr %slot82, align 8
  %v1319 = load i64, ptr %slot82, align 8
  %cmp1320 = icmp eq i64 %v1319, 0
  %cv1321 = zext i1 %cmp1320 to i32
  store i32 %cv1321, ptr %slot83, align 8
  %v1322 = load i32, ptr %slot83, align 8
  %cv1323 = zext i32 %v1322 to i64
  %cond1324 = icmp ne i64 %cv1323, 0
  br i1 %cond1324, label %bb_rcglimit75, label %bb_rcgcapacity75
bb_rcglimit75:
  %v1325 = load i64, ptr %slot1, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  %call1327 = call i32 @myl_qbe_rc_status(ptr %p1326, i32 2) nomerge, !dbg !116
  store i32 %call1327, ptr %slot84, align 8
  br label %bb_failure
bb_rcgcapacity75:
  %v1328 = load i64, ptr %slot82, align 8
  %v1329 = load i64, ptr %slot74, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %rgep1331 = getelementptr i8, ptr %p1330, i64 -24
  store i64 %v1328, ptr %rgep1331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore75
bb_rcgstore75:
  %v1332 = load i64, ptr %slot74, align 8
  %v1333 = load i64, ptr %slot73, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  store i64 %v1332, ptr %p1334, align 8, !alias.scope !3, !noalias !4
  %v1335 = load i64, ptr %slot15, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i32 2, ptr %p1336, align 4, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot15, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  store i32 16, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  %v1339 = load i64, ptr %slot14, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i32 1, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot12, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i32, ptr %p1342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1343, ptr %slot85, align 8
  %v1344 = load i32, ptr %slot85, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v1347 = load i64, ptr %slot12, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  store i32 0, ptr %p1348, align 4, !alias.scope !3, !noalias !4
  %v1349 = load i64, ptr %slot16, align 8
  store i64 %v1349, ptr %slot86, align 8
  %v1350 = load i64, ptr %slot13, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %ld1352 = load i32, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1352, ptr %slot87, align 8
  %v1353 = load i32, ptr %slot87, align 8
  %op1354 = and i32 %v1353, 28
  store i32 %op1354, ptr %slot88, align 8
  %v1355 = load i32, ptr %slot88, align 8
  %cv1356 = zext i32 %v1355 to i64
  %cond1357 = icmp ne i64 %cv1356, 0
  br i1 %cond1357, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v1358 = load i64, ptr %slot34, align 8
  store i64 %v1358, ptr %slot89, align 8
  %v1359 = load i64, ptr %slot86, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %ld1361 = load i64, ptr %p1360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1361, ptr %slot90, align 8
  %v1362 = load i64, ptr %slot90, align 8
  %cmp1363 = icmp ne i64 %v1362, 0
  %cv1364 = zext i1 %cmp1363 to i32
  store i32 %cv1364, ptr %slot91, align 8
  %v1365 = load i32, ptr %slot91, align 8
  %cv1366 = zext i32 %v1365 to i64
  %cond1367 = icmp ne i64 %cv1366, 0
  br i1 %cond1367, label %bb_rcgnn107, label %bb_rcgdone107
bb_rcgnn107:
  %v1368 = load i64, ptr %slot90, align 8
  %op1369 = sub i64 %v1368, 16
  store i64 %op1369, ptr %slot92, align 8
  %v1370 = load i64, ptr %slot90, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %rgep1372 = getelementptr i8, ptr %p1371, i64 -16
  %ld1373 = load i64, ptr %rgep1372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1373, ptr %slot93, align 8
  %v1374 = load i64, ptr %slot93, align 8
  %op1375 = and i64 %v1374, 4611686018427387906
  store i64 %op1375, ptr %slot94, align 8
  %v1376 = load i64, ptr %slot94, align 8
  %cmp1377 = icmp ne i64 %v1376, 0
  %cv1378 = zext i1 %cmp1377 to i32
  store i32 %cv1378, ptr %slot95, align 8
  %v1379 = load i32, ptr %slot95, align 8
  %cv1380 = zext i32 %v1379 to i64
  %cond1381 = icmp ne i64 %cv1380, 0
  br i1 %cond1381, label %bb_rcgclear107, label %bb_rcgcounted107
bb_rcgcounted107:
  %v1382 = load i64, ptr %slot90, align 8
  %op1383 = sub i64 %v1382, 24
  store i64 %op1383, ptr %slot96, align 8
  %v1384 = load i64, ptr %slot90, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %rgep1386 = getelementptr i8, ptr %p1385, i64 -24
  %ld1387 = load i64, ptr %rgep1386, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1387, ptr %slot97, align 8
  %v1388 = load i64, ptr %slot97, align 8
  %op1389 = sub i64 %v1388, 1
  store i64 %op1389, ptr %slot98, align 8
  %v1390 = load i64, ptr %slot98, align 8
  %cmp1391 = icmp eq i64 %v1390, 0
  %cv1392 = zext i1 %cmp1391 to i32
  store i32 %cv1392, ptr %slot99, align 8
  %v1393 = load i32, ptr %slot99, align 8
  %cv1394 = zext i32 %v1393 to i64
  %cond1395 = icmp ne i64 %cv1394, 0
  br i1 %cond1395, label %bb_rcglast107, label %bb_rcgdec107
bb_rcglast107:
  %v1396 = load i64, ptr %slot90, align 8
  %op1397 = sub i64 %v1396, 32
  store i64 %op1397, ptr %slot100, align 8
  %v1398 = load i64, ptr %slot90, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %rgep1400 = getelementptr i8, ptr %p1399, i64 -32
  %ld1401 = load i64, ptr %rgep1400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1401, ptr %slot101, align 8
  %v1402 = load i64, ptr %slot101, align 8
  %cmp1403 = icmp ne i64 %v1402, 0
  %cv1404 = zext i1 %cmp1403 to i32
  store i32 %cv1404, ptr %slot102, align 8
  %v1405 = load i32, ptr %slot102, align 8
  %cv1406 = zext i32 %v1405 to i64
  %cond1407 = icmp ne i64 %cv1406, 0
  br i1 %cond1407, label %bb_rcgdec107, label %bb_rcgslow107
bb_rcgslow107:
  %v1408 = load i64, ptr %slot89, align 8
  %v1409 = load i64, ptr %slot86, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1408, i64 %v1409) nomerge, !dbg !116
  br label %bb_rcgdone107
bb_rcgdec107:
  %v1410 = load i64, ptr %slot98, align 8
  %v1411 = load i64, ptr %slot90, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %rgep1413 = getelementptr i8, ptr %p1412, i64 -24
  store i64 %v1410, ptr %rgep1413, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear107
bb_rcgclear107:
  %v1414 = load i64, ptr %slot86, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  store i64 0, ptr %p1415, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone107
bb_rcgdone107:
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v1416 = load i64, ptr %slot34, align 8
  store i64 %v1416, ptr %slot103, align 8
  %v1417 = load i64, ptr %slot86, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %ld1419 = load i64, ptr %p1418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1419, ptr %slot104, align 8
  %v1420 = load i64, ptr %slot104, align 8
  %cmp1421 = icmp ne i64 %v1420, 0
  %cv1422 = zext i1 %cmp1421 to i32
  store i32 %cv1422, ptr %slot105, align 8
  %v1423 = load i32, ptr %slot105, align 8
  %cv1424 = zext i32 %v1423 to i64
  %cond1425 = icmp ne i64 %cv1424, 0
  br i1 %cond1425, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v1426 = load i64, ptr %slot104, align 8
  %op1427 = sub i64 %v1426, 16
  store i64 %op1427, ptr %slot106, align 8
  %v1428 = load i64, ptr %slot104, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %rgep1430 = getelementptr i8, ptr %p1429, i64 -16
  %ld1431 = load i64, ptr %rgep1430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1431, ptr %slot107, align 8
  %v1432 = load i64, ptr %slot107, align 8
  %op1433 = and i64 %v1432, 4611686018427387906
  store i64 %op1433, ptr %slot108, align 8
  %v1434 = load i64, ptr %slot108, align 8
  %cmp1435 = icmp ne i64 %v1434, 0
  %cv1436 = zext i1 %cmp1435 to i32
  store i32 %cv1436, ptr %slot109, align 8
  %v1437 = load i32, ptr %slot109, align 8
  %cv1438 = zext i32 %v1437 to i64
  %cond1439 = icmp ne i64 %cv1438, 0
  br i1 %cond1439, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v1440 = load i64, ptr %slot104, align 8
  %op1441 = sub i64 %v1440, 32
  store i64 %op1441, ptr %slot110, align 8
  %v1442 = load i64, ptr %slot104, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %rgep1444 = getelementptr i8, ptr %p1443, i64 -32
  %ld1445 = load i64, ptr %rgep1444, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1445, ptr %slot111, align 8
  %v1446 = load i64, ptr %slot111, align 8
  %op1447 = sub i64 %v1446, 1
  store i64 %op1447, ptr %slot112, align 8
  %v1448 = load i64, ptr %slot112, align 8
  %cmp1449 = icmp eq i64 %v1448, 0
  %cv1450 = zext i1 %cmp1449 to i32
  store i32 %cv1450, ptr %slot113, align 8
  %v1451 = load i32, ptr %slot113, align 8
  %cv1452 = zext i32 %v1451 to i64
  %cond1453 = icmp ne i64 %cv1452, 0
  br i1 %cond1453, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v1454 = load i64, ptr %slot104, align 8
  %op1455 = sub i64 %v1454, 24
  store i64 %op1455, ptr %slot114, align 8
  %v1456 = load i64, ptr %slot104, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %rgep1458 = getelementptr i8, ptr %p1457, i64 -24
  %ld1459 = load i64, ptr %rgep1458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1459, ptr %slot115, align 8
  %v1460 = load i64, ptr %slot115, align 8
  %cmp1461 = icmp ne i64 %v1460, 0
  %cv1462 = zext i1 %cmp1461 to i32
  store i32 %cv1462, ptr %slot116, align 8
  %v1463 = load i32, ptr %slot116, align 8
  %cv1464 = zext i32 %v1463 to i64
  %cond1465 = icmp ne i64 %cv1464, 0
  br i1 %cond1465, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v1466 = load i64, ptr %slot103, align 8
  %v1467 = load i64, ptr %slot86, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1466, i64 %v1467) nomerge, !dbg !116
  br label %bb_rcgdone122
bb_rcgdec122:
  %v1468 = load i64, ptr %slot112, align 8
  %v1469 = load i64, ptr %slot104, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %rgep1471 = getelementptr i8, ptr %p1470, i64 -32
  store i64 %v1468, ptr %rgep1471, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v1472 = load i64, ptr %slot86, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  store i64 0, ptr %p1473, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone91
bb_rcslotdone91:
  br label %bb_rcprivateprepared39
bb_rcprivateprepared39:
  %v1474 = load i64, ptr %slot6, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  %ld1476 = load i32, ptr %p1475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1476, ptr %slot117, align 8
  %v1477 = load i32, ptr %slot117, align 8
  %cv1478 = zext i32 %v1477 to i64
  %cond1479 = icmp ne i64 %cv1478, 0
  br i1 %cond1479, label %bb_rcslotdrop129, label %bb_rcslotdone129
bb_rcslotdrop129:
  %v1480 = load i64, ptr %slot6, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i32 0, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  %v1482 = load i64, ptr %slot23, align 8
  store i64 %v1482, ptr %slot118, align 8
  %v1483 = load i64, ptr %slot7, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %ld1485 = load i32, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1485, ptr %slot119, align 8
  %v1486 = load i32, ptr %slot119, align 8
  %op1487 = and i32 %v1486, 28
  store i32 %op1487, ptr %slot120, align 8
  %v1488 = load i32, ptr %slot120, align 8
  %cv1489 = zext i32 %v1488 to i64
  %cond1490 = icmp ne i64 %cv1489, 0
  br i1 %cond1490, label %bb_rcslotrole129, label %bb_rcslotowner129
bb_rcslotrole129:
  %v1491 = load i64, ptr %slot34, align 8
  store i64 %v1491, ptr %slot121, align 8
  %v1492 = load i64, ptr %slot118, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %ld1494 = load i64, ptr %p1493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1494, ptr %slot122, align 8
  %v1495 = load i64, ptr %slot122, align 8
  %cmp1496 = icmp ne i64 %v1495, 0
  %cv1497 = zext i1 %cmp1496 to i32
  store i32 %cv1497, ptr %slot123, align 8
  %v1498 = load i32, ptr %slot123, align 8
  %cv1499 = zext i32 %v1498 to i64
  %cond1500 = icmp ne i64 %cv1499, 0
  br i1 %cond1500, label %bb_rcgnn145, label %bb_rcgdone145
bb_rcgnn145:
  %v1501 = load i64, ptr %slot122, align 8
  %op1502 = sub i64 %v1501, 16
  store i64 %op1502, ptr %slot124, align 8
  %v1503 = load i64, ptr %slot122, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  %rgep1505 = getelementptr i8, ptr %p1504, i64 -16
  %ld1506 = load i64, ptr %rgep1505, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1506, ptr %slot125, align 8
  %v1507 = load i64, ptr %slot125, align 8
  %op1508 = and i64 %v1507, 4611686018427387906
  store i64 %op1508, ptr %slot126, align 8
  %v1509 = load i64, ptr %slot126, align 8
  %cmp1510 = icmp ne i64 %v1509, 0
  %cv1511 = zext i1 %cmp1510 to i32
  store i32 %cv1511, ptr %slot127, align 8
  %v1512 = load i32, ptr %slot127, align 8
  %cv1513 = zext i32 %v1512 to i64
  %cond1514 = icmp ne i64 %cv1513, 0
  br i1 %cond1514, label %bb_rcgclear145, label %bb_rcgcounted145
bb_rcgcounted145:
  %v1515 = load i64, ptr %slot122, align 8
  %op1516 = sub i64 %v1515, 24
  store i64 %op1516, ptr %slot128, align 8
  %v1517 = load i64, ptr %slot122, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  %rgep1519 = getelementptr i8, ptr %p1518, i64 -24
  %ld1520 = load i64, ptr %rgep1519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1520, ptr %slot129, align 8
  %v1521 = load i64, ptr %slot129, align 8
  %op1522 = sub i64 %v1521, 1
  store i64 %op1522, ptr %slot130, align 8
  %v1523 = load i64, ptr %slot130, align 8
  %cmp1524 = icmp eq i64 %v1523, 0
  %cv1525 = zext i1 %cmp1524 to i32
  store i32 %cv1525, ptr %slot131, align 8
  %v1526 = load i32, ptr %slot131, align 8
  %cv1527 = zext i32 %v1526 to i64
  %cond1528 = icmp ne i64 %cv1527, 0
  br i1 %cond1528, label %bb_rcglast145, label %bb_rcgdec145
bb_rcglast145:
  %v1529 = load i64, ptr %slot122, align 8
  %op1530 = sub i64 %v1529, 32
  store i64 %op1530, ptr %slot132, align 8
  %v1531 = load i64, ptr %slot122, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %rgep1533 = getelementptr i8, ptr %p1532, i64 -32
  %ld1534 = load i64, ptr %rgep1533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1534, ptr %slot133, align 8
  %v1535 = load i64, ptr %slot133, align 8
  %cmp1536 = icmp ne i64 %v1535, 0
  %cv1537 = zext i1 %cmp1536 to i32
  store i32 %cv1537, ptr %slot134, align 8
  %v1538 = load i32, ptr %slot134, align 8
  %cv1539 = zext i32 %v1538 to i64
  %cond1540 = icmp ne i64 %cv1539, 0
  br i1 %cond1540, label %bb_rcgdec145, label %bb_rcgslow145
bb_rcgslow145:
  %v1541 = load i64, ptr %slot121, align 8
  %v1542 = load i64, ptr %slot118, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1541, i64 %v1542) nomerge, !dbg !116
  br label %bb_rcgdone145
bb_rcgdec145:
  %v1543 = load i64, ptr %slot130, align 8
  %v1544 = load i64, ptr %slot122, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %rgep1546 = getelementptr i8, ptr %p1545, i64 -24
  store i64 %v1543, ptr %rgep1546, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear145
bb_rcgclear145:
  %v1547 = load i64, ptr %slot118, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i64 0, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone145
bb_rcgdone145:
  br label %bb_rcslotdone129
bb_rcslotowner129:
  %v1549 = load i64, ptr %slot34, align 8
  store i64 %v1549, ptr %slot135, align 8
  %v1550 = load i64, ptr %slot118, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  %ld1552 = load i64, ptr %p1551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1552, ptr %slot136, align 8
  %v1553 = load i64, ptr %slot136, align 8
  %cmp1554 = icmp ne i64 %v1553, 0
  %cv1555 = zext i1 %cmp1554 to i32
  store i32 %cv1555, ptr %slot137, align 8
  %v1556 = load i32, ptr %slot137, align 8
  %cv1557 = zext i32 %v1556 to i64
  %cond1558 = icmp ne i64 %cv1557, 0
  br i1 %cond1558, label %bb_rcgnn160, label %bb_rcgdone160
bb_rcgnn160:
  %v1559 = load i64, ptr %slot136, align 8
  %op1560 = sub i64 %v1559, 16
  store i64 %op1560, ptr %slot138, align 8
  %v1561 = load i64, ptr %slot136, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %rgep1563 = getelementptr i8, ptr %p1562, i64 -16
  %ld1564 = load i64, ptr %rgep1563, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1564, ptr %slot139, align 8
  %v1565 = load i64, ptr %slot139, align 8
  %op1566 = and i64 %v1565, 4611686018427387906
  store i64 %op1566, ptr %slot140, align 8
  %v1567 = load i64, ptr %slot140, align 8
  %cmp1568 = icmp ne i64 %v1567, 0
  %cv1569 = zext i1 %cmp1568 to i32
  store i32 %cv1569, ptr %slot141, align 8
  %v1570 = load i32, ptr %slot141, align 8
  %cv1571 = zext i32 %v1570 to i64
  %cond1572 = icmp ne i64 %cv1571, 0
  br i1 %cond1572, label %bb_rcgclear160, label %bb_rcgcounted160
bb_rcgcounted160:
  %v1573 = load i64, ptr %slot136, align 8
  %op1574 = sub i64 %v1573, 32
  store i64 %op1574, ptr %slot142, align 8
  %v1575 = load i64, ptr %slot136, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  %rgep1577 = getelementptr i8, ptr %p1576, i64 -32
  %ld1578 = load i64, ptr %rgep1577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1578, ptr %slot143, align 8
  %v1579 = load i64, ptr %slot143, align 8
  %op1580 = sub i64 %v1579, 1
  store i64 %op1580, ptr %slot144, align 8
  %v1581 = load i64, ptr %slot144, align 8
  %cmp1582 = icmp eq i64 %v1581, 0
  %cv1583 = zext i1 %cmp1582 to i32
  store i32 %cv1583, ptr %slot145, align 8
  %v1584 = load i32, ptr %slot145, align 8
  %cv1585 = zext i32 %v1584 to i64
  %cond1586 = icmp ne i64 %cv1585, 0
  br i1 %cond1586, label %bb_rcglast160, label %bb_rcgdec160
bb_rcglast160:
  %v1587 = load i64, ptr %slot136, align 8
  %op1588 = sub i64 %v1587, 24
  store i64 %op1588, ptr %slot146, align 8
  %v1589 = load i64, ptr %slot136, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %rgep1591 = getelementptr i8, ptr %p1590, i64 -24
  %ld1592 = load i64, ptr %rgep1591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1592, ptr %slot147, align 8
  %v1593 = load i64, ptr %slot147, align 8
  %cmp1594 = icmp ne i64 %v1593, 0
  %cv1595 = zext i1 %cmp1594 to i32
  store i32 %cv1595, ptr %slot148, align 8
  %v1596 = load i32, ptr %slot148, align 8
  %cv1597 = zext i32 %v1596 to i64
  %cond1598 = icmp ne i64 %cv1597, 0
  br i1 %cond1598, label %bb_rcgdec160, label %bb_rcgslow160
bb_rcgslow160:
  %v1599 = load i64, ptr %slot135, align 8
  %v1600 = load i64, ptr %slot118, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1599, i64 %v1600) nomerge, !dbg !116
  br label %bb_rcgdone160
bb_rcgdec160:
  %v1601 = load i64, ptr %slot144, align 8
  %v1602 = load i64, ptr %slot136, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  %rgep1604 = getelementptr i8, ptr %p1603, i64 -32
  store i64 %v1601, ptr %rgep1604, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear160
bb_rcgclear160:
  %v1605 = load i64, ptr %slot118, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i64 0, ptr %p1606, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone160
bb_rcgdone160:
  br label %bb_rcslotdone129
bb_rcslotdone129:
  %v1607 = load i64, ptr %slot23, align 8
  store i64 %v1607, ptr %slot149, align 8
  %v1608 = load i64, ptr %slot18, align 8
  store i64 %v1608, ptr %slot150, align 8
  %v1609 = load i64, ptr %slot150, align 8
  %v1610 = load i64, ptr %slot149, align 8
  %p1611 = inttoptr i64 %v1609 to ptr
  %p1612 = inttoptr i64 %v1610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1612, ptr %p1611, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1613 = load i64, ptr %slot14, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i32 0, ptr %p1614, align 4, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot7, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  store i32 2, ptr %p1616, align 4, !alias.scope !3, !noalias !4
  %v1617 = load i64, ptr %slot15, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i32, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1619, ptr %slot151, align 8
  %v1620 = load i32, ptr %slot151, align 8
  %v1621 = load i64, ptr %slot7, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i32 %v1620, ptr %p1622, align 4, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot6, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  store i32 1, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  %v1625 = load i64, ptr %slot23, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %ld1627 = load i64, ptr %p1626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1627, ptr %slot152, align 8
  %v1628 = load i64, ptr %slot152, align 8
  %v1629 = load i64, ptr %slot26, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  store i64 %v1628, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  %v1631 = load i64, ptr %slot26, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  %ld1633 = load i64, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1633, ptr %slot153, align 8
  %v1634 = load i64, ptr %slot153, align 8
  %v1635 = load i64, ptr %slot17, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  store i64 %v1634, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  %v1637 = load i64, ptr %slot17, align 8
  store i64 %v1637, ptr %slot154, align 8
  %v1638 = load i64, ptr %slot12, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  %ld1640 = load i32, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1640, ptr %slot155, align 8
  %v1641 = load i64, ptr %slot13, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i32, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1643, ptr %slot156, align 8
  %v1644 = load i32, ptr %slot156, align 8
  %op1645 = and i32 %v1644, 24
  store i32 %op1645, ptr %slot156, align 8
  %v1646 = load i32, ptr %slot156, align 8
  %cmp1647 = icmp eq i32 %v1646, 0
  %cv1648 = zext i1 %cmp1647 to i32
  store i32 %cv1648, ptr %slot157, align 8
  %v1649 = load i32, ptr %slot155, align 8
  %v1650 = load i32, ptr %slot157, align 8
  %op1651 = and i32 %v1649, %v1650
  store i32 %op1651, ptr %slot158, align 8
  %v1652 = load i32, ptr %slot158, align 8
  %cv1653 = zext i32 %v1652 to i64
  %cond1654 = icmp ne i64 %cv1653, 0
  br i1 %cond1654, label %bb_rctake174, label %bb_rccopy174
bb_rctake174:
  %v1655 = load i64, ptr %slot18, align 8
  store i64 %v1655, ptr %slot159, align 8
  %v1656 = load i64, ptr %slot35, align 8
  store i64 %v1656, ptr %slot160, align 8
  %v1657 = load i64, ptr %slot154, align 8
  %v1658 = load i64, ptr %slot159, align 8
  %op1659 = sub i64 %v1657, %v1658
  store i64 %op1659, ptr %slot161, align 8
  %v1660 = load i64, ptr %slot159, align 8
  %v1661 = load i64, ptr %slot154, align 8
  %op1662 = sub i64 %v1660, %v1661
  store i64 %op1662, ptr %slot162, align 8
  %v1663 = load i64, ptr %slot161, align 8
  %cmp1664 = icmp ult i64 %v1663, 8
  %cv1665 = zext i1 %cmp1664 to i32
  store i32 %cv1665, ptr %slot163, align 8
  %v1666 = load i64, ptr %slot162, align 8
  %cmp1667 = icmp ult i64 %v1666, 8
  %cv1668 = zext i1 %cmp1667 to i32
  store i32 %cv1668, ptr %slot164, align 8
  %v1669 = load i32, ptr %slot163, align 8
  %v1670 = load i32, ptr %slot164, align 8
  %op1671 = or i32 %v1669, %v1670
  store i32 %op1671, ptr %slot165, align 8
  %v1672 = load i32, ptr %slot165, align 8
  %cv1673 = zext i32 %v1672 to i64
  %cond1674 = icmp ne i64 %cv1673, 0
  br i1 %cond1674, label %bb_rcmoveslow183, label %bb_rcmovecheck183
bb_rcmovecheck183:
  %v1675 = load i64, ptr %slot154, align 8
  %p1677 = inttoptr i64 %v1675 to ptr
  %gep1678 = getelementptr i8, ptr %p1677, i64 0
  %op1676 = ptrtoint ptr %gep1678 to i64
  store i64 %op1676, ptr %slot166, align 8
  %v1679 = load i64, ptr %slot166, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i64, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1681, ptr %slot167, align 8
  %v1682 = load i64, ptr %slot167, align 8
  %cmp1683 = icmp ne i64 %v1682, 0
  %cv1684 = zext i1 %cmp1683 to i32
  store i32 %cv1684, ptr %slot168, align 8
  %v1685 = load i32, ptr %slot168, align 8
  %cv1686 = zext i32 %v1685 to i64
  %cond1687 = icmp ne i64 %cv1686, 0
  br i1 %cond1687, label %bb_rcmoveheader191, label %bb_rcmovenext191
bb_rcmoveheader191:
  %v1688 = load i64, ptr %slot167, align 8
  %op1689 = sub i64 %v1688, 16
  store i64 %op1689, ptr %slot169, align 8
  %v1690 = load i64, ptr %slot167, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  %rgep1692 = getelementptr i8, ptr %p1691, i64 -16
  %ld1693 = load i64, ptr %rgep1692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1693, ptr %slot170, align 8
  %v1694 = load i64, ptr %slot170, align 8
  %op1695 = and i64 %v1694, 5764607523034234881
  store i64 %op1695, ptr %slot171, align 8
  %v1696 = load i64, ptr %slot171, align 8
  %cmp1697 = icmp ne i64 %v1696, 0
  %cv1698 = zext i1 %cmp1697 to i32
  store i32 %cv1698, ptr %slot172, align 8
  %v1699 = load i32, ptr %slot172, align 8
  %cv1700 = zext i32 %v1699 to i64
  %cond1701 = icmp ne i64 %cv1700, 0
  br i1 %cond1701, label %bb_rcmoveslow183, label %bb_rcmovenext191
bb_rcmovenext191:
  %v1702 = load i64, ptr %slot154, align 8
  %v1703 = load i64, ptr %slot159, align 8
  %p1704 = inttoptr i64 %v1702 to ptr
  %p1705 = inttoptr i64 %v1703 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1705, ptr %p1704, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot154, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  store i64 0, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved183
bb_rcmoveslow183:
  %v1708 = load i64, ptr %slot34, align 8
  %v1709 = load i64, ptr %slot159, align 8
  %v1710 = load i64, ptr %slot154, align 8
  %v1711 = load i64, ptr %slot160, align 8
  %cv1712 = trunc i64 %v1711 to i32
  %call1713 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1708, i64 %v1709, i64 %v1710, i32 %cv1712) nomerge, !dbg !118
  store i32 %call1713, ptr %slot173, align 8
  %v1714 = load i32, ptr %slot173, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcsuccess198, label %bb_rcfailure198
bb_rcfailure198:
  %v1717 = load i64, ptr %slot34, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %call1719 = call i32 @myl_rc_take_failure(ptr %p1718) nomerge, !dbg !118
  store i32 %call1719, ptr %slot174, align 8
  %v1720 = load i64, ptr %slot1, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  %v1722 = load i32, ptr %slot174, align 8
  %call1723 = call i32 @myl_qbe_rc_status(ptr %p1721, i32 %v1722) nomerge, !dbg !118
  store i32 %call1723, ptr %slot175, align 8
  br label %bb_failure
bb_rcsuccess198:
  br label %bb_rcmoved183
bb_rcmoved183:
  %v1724 = load i64, ptr %slot12, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 0, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot15, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 2, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot14, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  store i32 1, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared174
bb_rccopy174:
  %v1730 = load i64, ptr %slot18, align 8
  store i64 %v1730, ptr %slot176, align 8
  %v1731 = load i64, ptr %slot35, align 8
  store i64 %v1731, ptr %slot177, align 8
  %v1732 = load i64, ptr %slot154, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  %ld1734 = load i64, ptr %p1733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1734, ptr %slot178, align 8
  %v1735 = load i64, ptr %slot178, align 8
  %cmp1736 = icmp ne i64 %v1735, 0
  %cv1737 = zext i1 %cmp1736 to i32
  store i32 %cv1737, ptr %slot179, align 8
  %v1738 = load i32, ptr %slot179, align 8
  %cv1739 = zext i32 %v1738 to i64
  %cond1740 = icmp ne i64 %cv1739, 0
  br i1 %cond1740, label %bb_rcgnn207, label %bb_rcgplain207
bb_rcgnn207:
  %v1741 = load i64, ptr %slot178, align 8
  %op1742 = sub i64 %v1741, 16
  store i64 %op1742, ptr %slot180, align 8
  %v1743 = load i64, ptr %slot178, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %rgep1745 = getelementptr i8, ptr %p1744, i64 -16
  %ld1746 = load i64, ptr %rgep1745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1746, ptr %slot181, align 8
  %v1747 = load i64, ptr %slot181, align 8
  %op1748 = and i64 %v1747, 4611686018427387906
  store i64 %op1748, ptr %slot182, align 8
  %v1749 = load i64, ptr %slot182, align 8
  %cmp1750 = icmp ne i64 %v1749, 0
  %cv1751 = zext i1 %cmp1750 to i32
  store i32 %cv1751, ptr %slot183, align 8
  %v1752 = load i32, ptr %slot183, align 8
  %cv1753 = zext i32 %v1752 to i64
  %cond1754 = icmp ne i64 %cv1753, 0
  br i1 %cond1754, label %bb_rcgspecial207, label %bb_rcginc207
bb_rcginc207:
  %v1755 = load i64, ptr %slot178, align 8
  %op1756 = sub i64 %v1755, 32
  store i64 %op1756, ptr %slot184, align 8
  %v1757 = load i64, ptr %slot178, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  %rgep1759 = getelementptr i8, ptr %p1758, i64 -32
  %ld1760 = load i64, ptr %rgep1759, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1760, ptr %slot185, align 8
  %v1761 = load i64, ptr %slot185, align 8
  %op1762 = add i64 %v1761, 1
  store i64 %op1762, ptr %slot186, align 8
  %v1763 = load i64, ptr %slot186, align 8
  %cmp1764 = icmp eq i64 %v1763, 0
  %cv1765 = zext i1 %cmp1764 to i32
  store i32 %cv1765, ptr %slot187, align 8
  %v1766 = load i32, ptr %slot187, align 8
  %cv1767 = zext i32 %v1766 to i64
  %cond1768 = icmp ne i64 %cv1767, 0
  br i1 %cond1768, label %bb_rcglimit207, label %bb_rcgcapacity207
bb_rcglimit207:
  %v1769 = load i64, ptr %slot1, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %call1771 = call i32 @myl_qbe_rc_status(ptr %p1770, i32 2) nomerge, !dbg !118
  store i32 %call1771, ptr %slot188, align 8
  br label %bb_failure
bb_rcgcapacity207:
  %v1772 = load i64, ptr %slot186, align 8
  %v1773 = load i64, ptr %slot178, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  %rgep1775 = getelementptr i8, ptr %p1774, i64 -32
  store i64 %v1772, ptr %rgep1775, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain207
bb_rcgspecial207:
  %v1776 = load i64, ptr %slot181, align 8
  %op1777 = and i64 %v1776, 4611686018427387904
  store i64 %op1777, ptr %slot189, align 8
  %v1778 = load i64, ptr %slot189, align 8
  %cmp1779 = icmp ne i64 %v1778, 0
  %cv1780 = zext i1 %cmp1779 to i32
  store i32 %cv1780, ptr %slot190, align 8
  %v1781 = load i32, ptr %slot190, align 8
  %cv1782 = zext i32 %v1781 to i64
  %cond1783 = icmp ne i64 %cv1782, 0
  br i1 %cond1783, label %bb_rcgslow207, label %bb_rcgplain207
bb_rcgslow207:
  %v1784 = load i64, ptr %slot34, align 8
  %v1785 = load i64, ptr %slot176, align 8
  %v1786 = load i64, ptr %slot154, align 8
  %v1787 = load i64, ptr %slot177, align 8
  %cv1788 = trunc i64 %v1787 to i32
  %call1789 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1784, i64 %v1785, i64 %v1786, i32 %cv1788) nomerge, !dbg !118
  store i32 %call1789, ptr %slot191, align 8
  %v1790 = load i32, ptr %slot191, align 8
  %cv1791 = zext i32 %v1790 to i64
  %cond1792 = icmp ne i64 %cv1791, 0
  br i1 %cond1792, label %bb_rcsuccess221, label %bb_rcfailure221
bb_rcfailure221:
  %v1793 = load i64, ptr %slot34, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  %call1795 = call i32 @myl_rc_take_failure(ptr %p1794) nomerge, !dbg !118
  store i32 %call1795, ptr %slot192, align 8
  %v1796 = load i64, ptr %slot1, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  %v1798 = load i32, ptr %slot192, align 8
  %call1799 = call i32 @myl_qbe_rc_status(ptr %p1797, i32 %v1798) nomerge, !dbg !118
  store i32 %call1799, ptr %slot193, align 8
  br label %bb_failure
bb_rcsuccess221:
  br label %bb_rcgdone207
bb_rcgplain207:
  %v1800 = load i64, ptr %slot178, align 8
  %v1801 = load i64, ptr %slot176, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i64 %v1800, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone207
bb_rcgdone207:
  %v1803 = load i64, ptr %slot15, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 2, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot14, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i32 1, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot12, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %ld1809 = load i32, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1809, ptr %slot194, align 8
  %v1810 = load i32, ptr %slot194, align 8
  %cv1811 = zext i32 %v1810 to i64
  %cond1812 = icmp ne i64 %cv1811, 0
  br i1 %cond1812, label %bb_rcslotdrop228, label %bb_rcslotdone228
bb_rcslotdrop228:
  %v1813 = load i64, ptr %slot12, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 0, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot16, align 8
  store i64 %v1815, ptr %slot195, align 8
  %v1816 = load i64, ptr %slot13, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %ld1818 = load i32, ptr %p1817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1818, ptr %slot196, align 8
  %v1819 = load i32, ptr %slot196, align 8
  %op1820 = and i32 %v1819, 28
  store i32 %op1820, ptr %slot197, align 8
  %v1821 = load i32, ptr %slot197, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcslotrole228, label %bb_rcslotowner228
bb_rcslotrole228:
  %v1824 = load i64, ptr %slot34, align 8
  store i64 %v1824, ptr %slot198, align 8
  %v1825 = load i64, ptr %slot195, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i64, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1827, ptr %slot199, align 8
  %v1828 = load i64, ptr %slot199, align 8
  %cmp1829 = icmp ne i64 %v1828, 0
  %cv1830 = zext i1 %cmp1829 to i32
  store i32 %cv1830, ptr %slot200, align 8
  %v1831 = load i32, ptr %slot200, align 8
  %cv1832 = zext i32 %v1831 to i64
  %cond1833 = icmp ne i64 %cv1832, 0
  br i1 %cond1833, label %bb_rcgnn244, label %bb_rcgdone244
bb_rcgnn244:
  %v1834 = load i64, ptr %slot199, align 8
  %op1835 = sub i64 %v1834, 16
  store i64 %op1835, ptr %slot201, align 8
  %v1836 = load i64, ptr %slot199, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %rgep1838 = getelementptr i8, ptr %p1837, i64 -16
  %ld1839 = load i64, ptr %rgep1838, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1839, ptr %slot202, align 8
  %v1840 = load i64, ptr %slot202, align 8
  %op1841 = and i64 %v1840, 4611686018427387906
  store i64 %op1841, ptr %slot203, align 8
  %v1842 = load i64, ptr %slot203, align 8
  %cmp1843 = icmp ne i64 %v1842, 0
  %cv1844 = zext i1 %cmp1843 to i32
  store i32 %cv1844, ptr %slot204, align 8
  %v1845 = load i32, ptr %slot204, align 8
  %cv1846 = zext i32 %v1845 to i64
  %cond1847 = icmp ne i64 %cv1846, 0
  br i1 %cond1847, label %bb_rcgclear244, label %bb_rcgcounted244
bb_rcgcounted244:
  %v1848 = load i64, ptr %slot199, align 8
  %op1849 = sub i64 %v1848, 24
  store i64 %op1849, ptr %slot205, align 8
  %v1850 = load i64, ptr %slot199, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %rgep1852 = getelementptr i8, ptr %p1851, i64 -24
  %ld1853 = load i64, ptr %rgep1852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1853, ptr %slot206, align 8
  %v1854 = load i64, ptr %slot206, align 8
  %op1855 = sub i64 %v1854, 1
  store i64 %op1855, ptr %slot207, align 8
  %v1856 = load i64, ptr %slot207, align 8
  %cmp1857 = icmp eq i64 %v1856, 0
  %cv1858 = zext i1 %cmp1857 to i32
  store i32 %cv1858, ptr %slot208, align 8
  %v1859 = load i32, ptr %slot208, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcglast244, label %bb_rcgdec244
bb_rcglast244:
  %v1862 = load i64, ptr %slot199, align 8
  %op1863 = sub i64 %v1862, 32
  store i64 %op1863, ptr %slot209, align 8
  %v1864 = load i64, ptr %slot199, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %rgep1866 = getelementptr i8, ptr %p1865, i64 -32
  %ld1867 = load i64, ptr %rgep1866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1867, ptr %slot210, align 8
  %v1868 = load i64, ptr %slot210, align 8
  %cmp1869 = icmp ne i64 %v1868, 0
  %cv1870 = zext i1 %cmp1869 to i32
  store i32 %cv1870, ptr %slot211, align 8
  %v1871 = load i32, ptr %slot211, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcgdec244, label %bb_rcgslow244
bb_rcgslow244:
  %v1874 = load i64, ptr %slot198, align 8
  %v1875 = load i64, ptr %slot195, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1874, i64 %v1875) nomerge, !dbg !118
  br label %bb_rcgdone244
bb_rcgdec244:
  %v1876 = load i64, ptr %slot207, align 8
  %v1877 = load i64, ptr %slot199, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -24
  store i64 %v1876, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear244
bb_rcgclear244:
  %v1880 = load i64, ptr %slot195, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i64 0, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone244
bb_rcgdone244:
  br label %bb_rcslotdone228
bb_rcslotowner228:
  %v1882 = load i64, ptr %slot34, align 8
  store i64 %v1882, ptr %slot212, align 8
  %v1883 = load i64, ptr %slot195, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %ld1885 = load i64, ptr %p1884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1885, ptr %slot213, align 8
  %v1886 = load i64, ptr %slot213, align 8
  %cmp1887 = icmp ne i64 %v1886, 0
  %cv1888 = zext i1 %cmp1887 to i32
  store i32 %cv1888, ptr %slot214, align 8
  %v1889 = load i32, ptr %slot214, align 8
  %cv1890 = zext i32 %v1889 to i64
  %cond1891 = icmp ne i64 %cv1890, 0
  br i1 %cond1891, label %bb_rcgnn259, label %bb_rcgdone259
bb_rcgnn259:
  %v1892 = load i64, ptr %slot213, align 8
  %op1893 = sub i64 %v1892, 16
  store i64 %op1893, ptr %slot215, align 8
  %v1894 = load i64, ptr %slot213, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %rgep1896 = getelementptr i8, ptr %p1895, i64 -16
  %ld1897 = load i64, ptr %rgep1896, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1897, ptr %slot216, align 8
  %v1898 = load i64, ptr %slot216, align 8
  %op1899 = and i64 %v1898, 4611686018427387906
  store i64 %op1899, ptr %slot217, align 8
  %v1900 = load i64, ptr %slot217, align 8
  %cmp1901 = icmp ne i64 %v1900, 0
  %cv1902 = zext i1 %cmp1901 to i32
  store i32 %cv1902, ptr %slot218, align 8
  %v1903 = load i32, ptr %slot218, align 8
  %cv1904 = zext i32 %v1903 to i64
  %cond1905 = icmp ne i64 %cv1904, 0
  br i1 %cond1905, label %bb_rcgclear259, label %bb_rcgcounted259
bb_rcgcounted259:
  %v1906 = load i64, ptr %slot213, align 8
  %op1907 = sub i64 %v1906, 32
  store i64 %op1907, ptr %slot219, align 8
  %v1908 = load i64, ptr %slot213, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %rgep1910 = getelementptr i8, ptr %p1909, i64 -32
  %ld1911 = load i64, ptr %rgep1910, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1911, ptr %slot220, align 8
  %v1912 = load i64, ptr %slot220, align 8
  %op1913 = sub i64 %v1912, 1
  store i64 %op1913, ptr %slot221, align 8
  %v1914 = load i64, ptr %slot221, align 8
  %cmp1915 = icmp eq i64 %v1914, 0
  %cv1916 = zext i1 %cmp1915 to i32
  store i32 %cv1916, ptr %slot222, align 8
  %v1917 = load i32, ptr %slot222, align 8
  %cv1918 = zext i32 %v1917 to i64
  %cond1919 = icmp ne i64 %cv1918, 0
  br i1 %cond1919, label %bb_rcglast259, label %bb_rcgdec259
bb_rcglast259:
  %v1920 = load i64, ptr %slot213, align 8
  %op1921 = sub i64 %v1920, 24
  store i64 %op1921, ptr %slot223, align 8
  %v1922 = load i64, ptr %slot213, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %rgep1924 = getelementptr i8, ptr %p1923, i64 -24
  %ld1925 = load i64, ptr %rgep1924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1925, ptr %slot224, align 8
  %v1926 = load i64, ptr %slot224, align 8
  %cmp1927 = icmp ne i64 %v1926, 0
  %cv1928 = zext i1 %cmp1927 to i32
  store i32 %cv1928, ptr %slot225, align 8
  %v1929 = load i32, ptr %slot225, align 8
  %cv1930 = zext i32 %v1929 to i64
  %cond1931 = icmp ne i64 %cv1930, 0
  br i1 %cond1931, label %bb_rcgdec259, label %bb_rcgslow259
bb_rcgslow259:
  %v1932 = load i64, ptr %slot212, align 8
  %v1933 = load i64, ptr %slot195, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1932, i64 %v1933) nomerge, !dbg !118
  br label %bb_rcgdone259
bb_rcgdec259:
  %v1934 = load i64, ptr %slot221, align 8
  %v1935 = load i64, ptr %slot213, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %rgep1937 = getelementptr i8, ptr %p1936, i64 -32
  store i64 %v1934, ptr %rgep1937, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear259
bb_rcgclear259:
  %v1938 = load i64, ptr %slot195, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i64 0, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone259
bb_rcgdone259:
  br label %bb_rcslotdone228
bb_rcslotdone228:
  br label %bb_rcprepared174
bb_rcprepared174:
  %v1940 = load i64, ptr %slot8, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i32, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1942, ptr %slot226, align 8
  %v1943 = load i32, ptr %slot226, align 8
  %cv1944 = zext i32 %v1943 to i64
  %cond1945 = icmp ne i64 %cv1944, 0
  br i1 %cond1945, label %bb_rcslotdrop266, label %bb_rcslotdone266
bb_rcslotdrop266:
  %v1946 = load i64, ptr %slot8, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  store i32 0, ptr %p1947, align 4, !alias.scope !3, !noalias !4
  %v1948 = load i64, ptr %slot24, align 8
  store i64 %v1948, ptr %slot227, align 8
  %v1949 = load i64, ptr %slot9, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %ld1951 = load i32, ptr %p1950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1951, ptr %slot228, align 8
  %v1952 = load i32, ptr %slot228, align 8
  %op1953 = and i32 %v1952, 28
  store i32 %op1953, ptr %slot229, align 8
  %v1954 = load i32, ptr %slot229, align 8
  %cv1955 = zext i32 %v1954 to i64
  %cond1956 = icmp ne i64 %cv1955, 0
  br i1 %cond1956, label %bb_rcslotrole266, label %bb_rcslotowner266
bb_rcslotrole266:
  %v1957 = load i64, ptr %slot34, align 8
  store i64 %v1957, ptr %slot230, align 8
  %v1958 = load i64, ptr %slot227, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %ld1960 = load i64, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1960, ptr %slot231, align 8
  %v1961 = load i64, ptr %slot231, align 8
  %cmp1962 = icmp ne i64 %v1961, 0
  %cv1963 = zext i1 %cmp1962 to i32
  store i32 %cv1963, ptr %slot232, align 8
  %v1964 = load i32, ptr %slot232, align 8
  %cv1965 = zext i32 %v1964 to i64
  %cond1966 = icmp ne i64 %cv1965, 0
  br i1 %cond1966, label %bb_rcgnn282, label %bb_rcgdone282
bb_rcgnn282:
  %v1967 = load i64, ptr %slot231, align 8
  %op1968 = sub i64 %v1967, 16
  store i64 %op1968, ptr %slot233, align 8
  %v1969 = load i64, ptr %slot231, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  %rgep1971 = getelementptr i8, ptr %p1970, i64 -16
  %ld1972 = load i64, ptr %rgep1971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1972, ptr %slot234, align 8
  %v1973 = load i64, ptr %slot234, align 8
  %op1974 = and i64 %v1973, 4611686018427387906
  store i64 %op1974, ptr %slot235, align 8
  %v1975 = load i64, ptr %slot235, align 8
  %cmp1976 = icmp ne i64 %v1975, 0
  %cv1977 = zext i1 %cmp1976 to i32
  store i32 %cv1977, ptr %slot236, align 8
  %v1978 = load i32, ptr %slot236, align 8
  %cv1979 = zext i32 %v1978 to i64
  %cond1980 = icmp ne i64 %cv1979, 0
  br i1 %cond1980, label %bb_rcgclear282, label %bb_rcgcounted282
bb_rcgcounted282:
  %v1981 = load i64, ptr %slot231, align 8
  %op1982 = sub i64 %v1981, 24
  store i64 %op1982, ptr %slot237, align 8
  %v1983 = load i64, ptr %slot231, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %rgep1985 = getelementptr i8, ptr %p1984, i64 -24
  %ld1986 = load i64, ptr %rgep1985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1986, ptr %slot238, align 8
  %v1987 = load i64, ptr %slot238, align 8
  %op1988 = sub i64 %v1987, 1
  store i64 %op1988, ptr %slot239, align 8
  %v1989 = load i64, ptr %slot239, align 8
  %cmp1990 = icmp eq i64 %v1989, 0
  %cv1991 = zext i1 %cmp1990 to i32
  store i32 %cv1991, ptr %slot240, align 8
  %v1992 = load i32, ptr %slot240, align 8
  %cv1993 = zext i32 %v1992 to i64
  %cond1994 = icmp ne i64 %cv1993, 0
  br i1 %cond1994, label %bb_rcglast282, label %bb_rcgdec282
bb_rcglast282:
  %v1995 = load i64, ptr %slot231, align 8
  %op1996 = sub i64 %v1995, 32
  store i64 %op1996, ptr %slot241, align 8
  %v1997 = load i64, ptr %slot231, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %rgep1999 = getelementptr i8, ptr %p1998, i64 -32
  %ld2000 = load i64, ptr %rgep1999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2000, ptr %slot242, align 8
  %v2001 = load i64, ptr %slot242, align 8
  %cmp2002 = icmp ne i64 %v2001, 0
  %cv2003 = zext i1 %cmp2002 to i32
  store i32 %cv2003, ptr %slot243, align 8
  %v2004 = load i32, ptr %slot243, align 8
  %cv2005 = zext i32 %v2004 to i64
  %cond2006 = icmp ne i64 %cv2005, 0
  br i1 %cond2006, label %bb_rcgdec282, label %bb_rcgslow282
bb_rcgslow282:
  %v2007 = load i64, ptr %slot230, align 8
  %v2008 = load i64, ptr %slot227, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2007, i64 %v2008) nomerge, !dbg !118
  br label %bb_rcgdone282
bb_rcgdec282:
  %v2009 = load i64, ptr %slot239, align 8
  %v2010 = load i64, ptr %slot231, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  %rgep2012 = getelementptr i8, ptr %p2011, i64 -24
  store i64 %v2009, ptr %rgep2012, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear282
bb_rcgclear282:
  %v2013 = load i64, ptr %slot227, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  store i64 0, ptr %p2014, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone282
bb_rcgdone282:
  br label %bb_rcslotdone266
bb_rcslotowner266:
  %v2015 = load i64, ptr %slot34, align 8
  store i64 %v2015, ptr %slot244, align 8
  %v2016 = load i64, ptr %slot227, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %ld2018 = load i64, ptr %p2017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2018, ptr %slot245, align 8
  %v2019 = load i64, ptr %slot245, align 8
  %cmp2020 = icmp ne i64 %v2019, 0
  %cv2021 = zext i1 %cmp2020 to i32
  store i32 %cv2021, ptr %slot246, align 8
  %v2022 = load i32, ptr %slot246, align 8
  %cv2023 = zext i32 %v2022 to i64
  %cond2024 = icmp ne i64 %cv2023, 0
  br i1 %cond2024, label %bb_rcgnn297, label %bb_rcgdone297
bb_rcgnn297:
  %v2025 = load i64, ptr %slot245, align 8
  %op2026 = sub i64 %v2025, 16
  store i64 %op2026, ptr %slot247, align 8
  %v2027 = load i64, ptr %slot245, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %rgep2029 = getelementptr i8, ptr %p2028, i64 -16
  %ld2030 = load i64, ptr %rgep2029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2030, ptr %slot248, align 8
  %v2031 = load i64, ptr %slot248, align 8
  %op2032 = and i64 %v2031, 4611686018427387906
  store i64 %op2032, ptr %slot249, align 8
  %v2033 = load i64, ptr %slot249, align 8
  %cmp2034 = icmp ne i64 %v2033, 0
  %cv2035 = zext i1 %cmp2034 to i32
  store i32 %cv2035, ptr %slot250, align 8
  %v2036 = load i32, ptr %slot250, align 8
  %cv2037 = zext i32 %v2036 to i64
  %cond2038 = icmp ne i64 %cv2037, 0
  br i1 %cond2038, label %bb_rcgclear297, label %bb_rcgcounted297
bb_rcgcounted297:
  %v2039 = load i64, ptr %slot245, align 8
  %op2040 = sub i64 %v2039, 32
  store i64 %op2040, ptr %slot251, align 8
  %v2041 = load i64, ptr %slot245, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  %rgep2043 = getelementptr i8, ptr %p2042, i64 -32
  %ld2044 = load i64, ptr %rgep2043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2044, ptr %slot252, align 8
  %v2045 = load i64, ptr %slot252, align 8
  %op2046 = sub i64 %v2045, 1
  store i64 %op2046, ptr %slot253, align 8
  %v2047 = load i64, ptr %slot253, align 8
  %cmp2048 = icmp eq i64 %v2047, 0
  %cv2049 = zext i1 %cmp2048 to i32
  store i32 %cv2049, ptr %slot254, align 8
  %v2050 = load i32, ptr %slot254, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcglast297, label %bb_rcgdec297
bb_rcglast297:
  %v2053 = load i64, ptr %slot245, align 8
  %op2054 = sub i64 %v2053, 24
  store i64 %op2054, ptr %slot255, align 8
  %v2055 = load i64, ptr %slot245, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %rgep2057 = getelementptr i8, ptr %p2056, i64 -24
  %ld2058 = load i64, ptr %rgep2057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2058, ptr %slot256, align 8
  %v2059 = load i64, ptr %slot256, align 8
  %cmp2060 = icmp ne i64 %v2059, 0
  %cv2061 = zext i1 %cmp2060 to i32
  store i32 %cv2061, ptr %slot257, align 8
  %v2062 = load i32, ptr %slot257, align 8
  %cv2063 = zext i32 %v2062 to i64
  %cond2064 = icmp ne i64 %cv2063, 0
  br i1 %cond2064, label %bb_rcgdec297, label %bb_rcgslow297
bb_rcgslow297:
  %v2065 = load i64, ptr %slot244, align 8
  %v2066 = load i64, ptr %slot227, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2065, i64 %v2066) nomerge, !dbg !118
  br label %bb_rcgdone297
bb_rcgdec297:
  %v2067 = load i64, ptr %slot253, align 8
  %v2068 = load i64, ptr %slot245, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %rgep2070 = getelementptr i8, ptr %p2069, i64 -32
  store i64 %v2067, ptr %rgep2070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear297
bb_rcgclear297:
  %v2071 = load i64, ptr %slot227, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i64 0, ptr %p2072, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone297
bb_rcgdone297:
  br label %bb_rcslotdone266
bb_rcslotdone266:
  %v2073 = load i64, ptr %slot24, align 8
  store i64 %v2073, ptr %slot258, align 8
  %v2074 = load i64, ptr %slot18, align 8
  store i64 %v2074, ptr %slot259, align 8
  %v2075 = load i64, ptr %slot259, align 8
  %v2076 = load i64, ptr %slot258, align 8
  %p2077 = inttoptr i64 %v2075 to ptr
  %p2078 = inttoptr i64 %v2076 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2078, ptr %p2077, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2079 = load i64, ptr %slot14, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i32 0, ptr %p2080, align 4, !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot9, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 2, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot15, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i32, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2085, ptr %slot260, align 8
  %v2086 = load i32, ptr %slot260, align 8
  %v2087 = load i64, ptr %slot9, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i32 %v2086, ptr %p2088, align 4, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot8, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 1, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot6, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i32, ptr %p2092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2093, ptr %slot261, align 8
  %v2094 = load i32, ptr %slot261, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcslotdrop310, label %bb_rcslotdone310
bb_rcslotdrop310:
  %v2097 = load i64, ptr %slot6, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  store i32 0, ptr %p2098, align 4, !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot23, align 8
  store i64 %v2099, ptr %slot262, align 8
  %v2100 = load i64, ptr %slot7, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %ld2102 = load i32, ptr %p2101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2102, ptr %slot263, align 8
  %v2103 = load i32, ptr %slot263, align 8
  %op2104 = and i32 %v2103, 28
  store i32 %op2104, ptr %slot264, align 8
  %v2105 = load i32, ptr %slot264, align 8
  %cv2106 = zext i32 %v2105 to i64
  %cond2107 = icmp ne i64 %cv2106, 0
  br i1 %cond2107, label %bb_rcslotrole310, label %bb_rcslotowner310
bb_rcslotrole310:
  %v2108 = load i64, ptr %slot34, align 8
  store i64 %v2108, ptr %slot265, align 8
  %v2109 = load i64, ptr %slot262, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  %ld2111 = load i64, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2111, ptr %slot266, align 8
  %v2112 = load i64, ptr %slot266, align 8
  %cmp2113 = icmp ne i64 %v2112, 0
  %cv2114 = zext i1 %cmp2113 to i32
  store i32 %cv2114, ptr %slot267, align 8
  %v2115 = load i32, ptr %slot267, align 8
  %cv2116 = zext i32 %v2115 to i64
  %cond2117 = icmp ne i64 %cv2116, 0
  br i1 %cond2117, label %bb_rcgnn326, label %bb_rcgdone326
bb_rcgnn326:
  %v2118 = load i64, ptr %slot266, align 8
  %op2119 = sub i64 %v2118, 16
  store i64 %op2119, ptr %slot268, align 8
  %v2120 = load i64, ptr %slot266, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  %rgep2122 = getelementptr i8, ptr %p2121, i64 -16
  %ld2123 = load i64, ptr %rgep2122, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2123, ptr %slot269, align 8
  %v2124 = load i64, ptr %slot269, align 8
  %op2125 = and i64 %v2124, 4611686018427387906
  store i64 %op2125, ptr %slot270, align 8
  %v2126 = load i64, ptr %slot270, align 8
  %cmp2127 = icmp ne i64 %v2126, 0
  %cv2128 = zext i1 %cmp2127 to i32
  store i32 %cv2128, ptr %slot271, align 8
  %v2129 = load i32, ptr %slot271, align 8
  %cv2130 = zext i32 %v2129 to i64
  %cond2131 = icmp ne i64 %cv2130, 0
  br i1 %cond2131, label %bb_rcgclear326, label %bb_rcgcounted326
bb_rcgcounted326:
  %v2132 = load i64, ptr %slot266, align 8
  %op2133 = sub i64 %v2132, 24
  store i64 %op2133, ptr %slot272, align 8
  %v2134 = load i64, ptr %slot266, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  %rgep2136 = getelementptr i8, ptr %p2135, i64 -24
  %ld2137 = load i64, ptr %rgep2136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2137, ptr %slot273, align 8
  %v2138 = load i64, ptr %slot273, align 8
  %op2139 = sub i64 %v2138, 1
  store i64 %op2139, ptr %slot274, align 8
  %v2140 = load i64, ptr %slot274, align 8
  %cmp2141 = icmp eq i64 %v2140, 0
  %cv2142 = zext i1 %cmp2141 to i32
  store i32 %cv2142, ptr %slot275, align 8
  %v2143 = load i32, ptr %slot275, align 8
  %cv2144 = zext i32 %v2143 to i64
  %cond2145 = icmp ne i64 %cv2144, 0
  br i1 %cond2145, label %bb_rcglast326, label %bb_rcgdec326
bb_rcglast326:
  %v2146 = load i64, ptr %slot266, align 8
  %op2147 = sub i64 %v2146, 32
  store i64 %op2147, ptr %slot276, align 8
  %v2148 = load i64, ptr %slot266, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  %rgep2150 = getelementptr i8, ptr %p2149, i64 -32
  %ld2151 = load i64, ptr %rgep2150, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2151, ptr %slot277, align 8
  %v2152 = load i64, ptr %slot277, align 8
  %cmp2153 = icmp ne i64 %v2152, 0
  %cv2154 = zext i1 %cmp2153 to i32
  store i32 %cv2154, ptr %slot278, align 8
  %v2155 = load i32, ptr %slot278, align 8
  %cv2156 = zext i32 %v2155 to i64
  %cond2157 = icmp ne i64 %cv2156, 0
  br i1 %cond2157, label %bb_rcgdec326, label %bb_rcgslow326
bb_rcgslow326:
  %v2158 = load i64, ptr %slot265, align 8
  %v2159 = load i64, ptr %slot262, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2158, i64 %v2159) nomerge, !dbg !118
  br label %bb_rcgdone326
bb_rcgdec326:
  %v2160 = load i64, ptr %slot274, align 8
  %v2161 = load i64, ptr %slot266, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  %rgep2163 = getelementptr i8, ptr %p2162, i64 -24
  store i64 %v2160, ptr %rgep2163, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear326
bb_rcgclear326:
  %v2164 = load i64, ptr %slot262, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i64 0, ptr %p2165, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone326
bb_rcgdone326:
  br label %bb_rcslotdone310
bb_rcslotowner310:
  %v2166 = load i64, ptr %slot34, align 8
  store i64 %v2166, ptr %slot279, align 8
  %v2167 = load i64, ptr %slot262, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %ld2169 = load i64, ptr %p2168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2169, ptr %slot280, align 8
  %v2170 = load i64, ptr %slot280, align 8
  %cmp2171 = icmp ne i64 %v2170, 0
  %cv2172 = zext i1 %cmp2171 to i32
  store i32 %cv2172, ptr %slot281, align 8
  %v2173 = load i32, ptr %slot281, align 8
  %cv2174 = zext i32 %v2173 to i64
  %cond2175 = icmp ne i64 %cv2174, 0
  br i1 %cond2175, label %bb_rcgnn341, label %bb_rcgdone341
bb_rcgnn341:
  %v2176 = load i64, ptr %slot280, align 8
  %op2177 = sub i64 %v2176, 16
  store i64 %op2177, ptr %slot282, align 8
  %v2178 = load i64, ptr %slot280, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %rgep2180 = getelementptr i8, ptr %p2179, i64 -16
  %ld2181 = load i64, ptr %rgep2180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2181, ptr %slot283, align 8
  %v2182 = load i64, ptr %slot283, align 8
  %op2183 = and i64 %v2182, 4611686018427387906
  store i64 %op2183, ptr %slot284, align 8
  %v2184 = load i64, ptr %slot284, align 8
  %cmp2185 = icmp ne i64 %v2184, 0
  %cv2186 = zext i1 %cmp2185 to i32
  store i32 %cv2186, ptr %slot285, align 8
  %v2187 = load i32, ptr %slot285, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcgclear341, label %bb_rcgcounted341
bb_rcgcounted341:
  %v2190 = load i64, ptr %slot280, align 8
  %op2191 = sub i64 %v2190, 32
  store i64 %op2191, ptr %slot286, align 8
  %v2192 = load i64, ptr %slot280, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %rgep2194 = getelementptr i8, ptr %p2193, i64 -32
  %ld2195 = load i64, ptr %rgep2194, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2195, ptr %slot287, align 8
  %v2196 = load i64, ptr %slot287, align 8
  %op2197 = sub i64 %v2196, 1
  store i64 %op2197, ptr %slot288, align 8
  %v2198 = load i64, ptr %slot288, align 8
  %cmp2199 = icmp eq i64 %v2198, 0
  %cv2200 = zext i1 %cmp2199 to i32
  store i32 %cv2200, ptr %slot289, align 8
  %v2201 = load i32, ptr %slot289, align 8
  %cv2202 = zext i32 %v2201 to i64
  %cond2203 = icmp ne i64 %cv2202, 0
  br i1 %cond2203, label %bb_rcglast341, label %bb_rcgdec341
bb_rcglast341:
  %v2204 = load i64, ptr %slot280, align 8
  %op2205 = sub i64 %v2204, 24
  store i64 %op2205, ptr %slot290, align 8
  %v2206 = load i64, ptr %slot280, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  %rgep2208 = getelementptr i8, ptr %p2207, i64 -24
  %ld2209 = load i64, ptr %rgep2208, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2209, ptr %slot291, align 8
  %v2210 = load i64, ptr %slot291, align 8
  %cmp2211 = icmp ne i64 %v2210, 0
  %cv2212 = zext i1 %cmp2211 to i32
  store i32 %cv2212, ptr %slot292, align 8
  %v2213 = load i32, ptr %slot292, align 8
  %cv2214 = zext i32 %v2213 to i64
  %cond2215 = icmp ne i64 %cv2214, 0
  br i1 %cond2215, label %bb_rcgdec341, label %bb_rcgslow341
bb_rcgslow341:
  %v2216 = load i64, ptr %slot279, align 8
  %v2217 = load i64, ptr %slot262, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2216, i64 %v2217) nomerge, !dbg !118
  br label %bb_rcgdone341
bb_rcgdec341:
  %v2218 = load i64, ptr %slot288, align 8
  %v2219 = load i64, ptr %slot280, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  %rgep2221 = getelementptr i8, ptr %p2220, i64 -32
  store i64 %v2218, ptr %rgep2221, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear341
bb_rcgclear341:
  %v2222 = load i64, ptr %slot262, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i64 0, ptr %p2223, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone341
bb_rcgdone341:
  br label %bb_rcslotdone310
bb_rcslotdone310:
  %v2224 = load i64, ptr %slot24, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i64, ptr %p2225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2226, ptr %slot293, align 8
  %v2227 = load i64, ptr %slot293, align 8
  %v2228 = load i64, ptr %slot26, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  store i64 %v2227, ptr %p2229, align 8, !alias.scope !3, !noalias !4
  %v2230 = load i64, ptr %slot26, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  %ld2232 = load i64, ptr %p2231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2232, ptr %slot294, align 8
  %v2233 = load i64, ptr %slot1, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %v2235 = load i64, ptr %slot294, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %call2237 = call ptr @myl_qbe_bytes_from_list(ptr %p2234, ptr %p2236) nomerge, !dbg !120
  %calladdr2238 = ptrtoint ptr %call2237 to i64
  store i64 %calladdr2238, ptr %slot295, align 8
  %v2239 = load i64, ptr %slot295, align 8
  %v2240 = load i64, ptr %slot26, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i64 %v2239, ptr %p2241, align 8, !alias.scope !3, !noalias !4
  %v2242 = load i64, ptr %slot26, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %ld2244 = load i64, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2244, ptr %slot296, align 8
  %v2245 = load i64, ptr %slot296, align 8
  %v2246 = load i64, ptr %slot17, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  store i64 %v2245, ptr %p2247, align 8, !alias.scope !3, !noalias !4
  %v2248 = load i64, ptr %slot17, align 8
  store i64 %v2248, ptr %slot297, align 8
  %v2249 = load i64, ptr %slot18, align 8
  store i64 %v2249, ptr %slot298, align 8
  %v2250 = load i64, ptr %slot297, align 8
  %v2251 = load i64, ptr %slot298, align 8
  %p2252 = inttoptr i64 %v2250 to ptr
  %p2253 = inttoptr i64 %v2251 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2253, ptr %p2252, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2254 = load i64, ptr %slot15, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i32 2, ptr %p2255, align 4, !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot14, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i32 1, ptr %p2257, align 4, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot12, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i32, ptr %p2259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2260, ptr %slot299, align 8
  %v2261 = load i32, ptr %slot299, align 8
  %cv2262 = zext i32 %v2261 to i64
  %cond2263 = icmp ne i64 %cv2262, 0
  br i1 %cond2263, label %bb_rcslotdrop355, label %bb_rcslotdone355
bb_rcslotdrop355:
  %v2264 = load i64, ptr %slot12, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i32 0, ptr %p2265, align 4, !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot16, align 8
  store i64 %v2266, ptr %slot300, align 8
  %v2267 = load i64, ptr %slot13, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i32, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2269, ptr %slot301, align 8
  %v2270 = load i32, ptr %slot301, align 8
  %op2271 = and i32 %v2270, 28
  store i32 %op2271, ptr %slot302, align 8
  %v2272 = load i32, ptr %slot302, align 8
  %cv2273 = zext i32 %v2272 to i64
  %cond2274 = icmp ne i64 %cv2273, 0
  br i1 %cond2274, label %bb_rcslotrole355, label %bb_rcslotowner355
bb_rcslotrole355:
  %v2275 = load i64, ptr %slot34, align 8
  store i64 %v2275, ptr %slot303, align 8
  %v2276 = load i64, ptr %slot300, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i64, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2278, ptr %slot304, align 8
  %v2279 = load i64, ptr %slot304, align 8
  %cmp2280 = icmp ne i64 %v2279, 0
  %cv2281 = zext i1 %cmp2280 to i32
  store i32 %cv2281, ptr %slot305, align 8
  %v2282 = load i32, ptr %slot305, align 8
  %cv2283 = zext i32 %v2282 to i64
  %cond2284 = icmp ne i64 %cv2283, 0
  br i1 %cond2284, label %bb_rcgnn371, label %bb_rcgdone371
bb_rcgnn371:
  %v2285 = load i64, ptr %slot304, align 8
  %op2286 = sub i64 %v2285, 16
  store i64 %op2286, ptr %slot306, align 8
  %v2287 = load i64, ptr %slot304, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  %rgep2289 = getelementptr i8, ptr %p2288, i64 -16
  %ld2290 = load i64, ptr %rgep2289, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2290, ptr %slot307, align 8
  %v2291 = load i64, ptr %slot307, align 8
  %op2292 = and i64 %v2291, 4611686018427387906
  store i64 %op2292, ptr %slot308, align 8
  %v2293 = load i64, ptr %slot308, align 8
  %cmp2294 = icmp ne i64 %v2293, 0
  %cv2295 = zext i1 %cmp2294 to i32
  store i32 %cv2295, ptr %slot309, align 8
  %v2296 = load i32, ptr %slot309, align 8
  %cv2297 = zext i32 %v2296 to i64
  %cond2298 = icmp ne i64 %cv2297, 0
  br i1 %cond2298, label %bb_rcgclear371, label %bb_rcgcounted371
bb_rcgcounted371:
  %v2299 = load i64, ptr %slot304, align 8
  %op2300 = sub i64 %v2299, 24
  store i64 %op2300, ptr %slot310, align 8
  %v2301 = load i64, ptr %slot304, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %rgep2303 = getelementptr i8, ptr %p2302, i64 -24
  %ld2304 = load i64, ptr %rgep2303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2304, ptr %slot311, align 8
  %v2305 = load i64, ptr %slot311, align 8
  %op2306 = sub i64 %v2305, 1
  store i64 %op2306, ptr %slot312, align 8
  %v2307 = load i64, ptr %slot312, align 8
  %cmp2308 = icmp eq i64 %v2307, 0
  %cv2309 = zext i1 %cmp2308 to i32
  store i32 %cv2309, ptr %slot313, align 8
  %v2310 = load i32, ptr %slot313, align 8
  %cv2311 = zext i32 %v2310 to i64
  %cond2312 = icmp ne i64 %cv2311, 0
  br i1 %cond2312, label %bb_rcglast371, label %bb_rcgdec371
bb_rcglast371:
  %v2313 = load i64, ptr %slot304, align 8
  %op2314 = sub i64 %v2313, 32
  store i64 %op2314, ptr %slot314, align 8
  %v2315 = load i64, ptr %slot304, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  %rgep2317 = getelementptr i8, ptr %p2316, i64 -32
  %ld2318 = load i64, ptr %rgep2317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2318, ptr %slot315, align 8
  %v2319 = load i64, ptr %slot315, align 8
  %cmp2320 = icmp ne i64 %v2319, 0
  %cv2321 = zext i1 %cmp2320 to i32
  store i32 %cv2321, ptr %slot316, align 8
  %v2322 = load i32, ptr %slot316, align 8
  %cv2323 = zext i32 %v2322 to i64
  %cond2324 = icmp ne i64 %cv2323, 0
  br i1 %cond2324, label %bb_rcgdec371, label %bb_rcgslow371
bb_rcgslow371:
  %v2325 = load i64, ptr %slot303, align 8
  %v2326 = load i64, ptr %slot300, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2325, i64 %v2326) nomerge, !dbg !120
  br label %bb_rcgdone371
bb_rcgdec371:
  %v2327 = load i64, ptr %slot312, align 8
  %v2328 = load i64, ptr %slot304, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  %rgep2330 = getelementptr i8, ptr %p2329, i64 -24
  store i64 %v2327, ptr %rgep2330, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear371
bb_rcgclear371:
  %v2331 = load i64, ptr %slot300, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i64 0, ptr %p2332, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone371
bb_rcgdone371:
  br label %bb_rcslotdone355
bb_rcslotowner355:
  %v2333 = load i64, ptr %slot34, align 8
  store i64 %v2333, ptr %slot317, align 8
  %v2334 = load i64, ptr %slot300, align 8
  %p2335 = inttoptr i64 %v2334 to ptr
  %ld2336 = load i64, ptr %p2335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2336, ptr %slot318, align 8
  %v2337 = load i64, ptr %slot318, align 8
  %cmp2338 = icmp ne i64 %v2337, 0
  %cv2339 = zext i1 %cmp2338 to i32
  store i32 %cv2339, ptr %slot319, align 8
  %v2340 = load i32, ptr %slot319, align 8
  %cv2341 = zext i32 %v2340 to i64
  %cond2342 = icmp ne i64 %cv2341, 0
  br i1 %cond2342, label %bb_rcgnn386, label %bb_rcgdone386
bb_rcgnn386:
  %v2343 = load i64, ptr %slot318, align 8
  %op2344 = sub i64 %v2343, 16
  store i64 %op2344, ptr %slot320, align 8
  %v2345 = load i64, ptr %slot318, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %rgep2347 = getelementptr i8, ptr %p2346, i64 -16
  %ld2348 = load i64, ptr %rgep2347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2348, ptr %slot321, align 8
  %v2349 = load i64, ptr %slot321, align 8
  %op2350 = and i64 %v2349, 4611686018427387906
  store i64 %op2350, ptr %slot322, align 8
  %v2351 = load i64, ptr %slot322, align 8
  %cmp2352 = icmp ne i64 %v2351, 0
  %cv2353 = zext i1 %cmp2352 to i32
  store i32 %cv2353, ptr %slot323, align 8
  %v2354 = load i32, ptr %slot323, align 8
  %cv2355 = zext i32 %v2354 to i64
  %cond2356 = icmp ne i64 %cv2355, 0
  br i1 %cond2356, label %bb_rcgclear386, label %bb_rcgcounted386
bb_rcgcounted386:
  %v2357 = load i64, ptr %slot318, align 8
  %op2358 = sub i64 %v2357, 32
  store i64 %op2358, ptr %slot324, align 8
  %v2359 = load i64, ptr %slot318, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %rgep2361 = getelementptr i8, ptr %p2360, i64 -32
  %ld2362 = load i64, ptr %rgep2361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2362, ptr %slot325, align 8
  %v2363 = load i64, ptr %slot325, align 8
  %op2364 = sub i64 %v2363, 1
  store i64 %op2364, ptr %slot326, align 8
  %v2365 = load i64, ptr %slot326, align 8
  %cmp2366 = icmp eq i64 %v2365, 0
  %cv2367 = zext i1 %cmp2366 to i32
  store i32 %cv2367, ptr %slot327, align 8
  %v2368 = load i32, ptr %slot327, align 8
  %cv2369 = zext i32 %v2368 to i64
  %cond2370 = icmp ne i64 %cv2369, 0
  br i1 %cond2370, label %bb_rcglast386, label %bb_rcgdec386
bb_rcglast386:
  %v2371 = load i64, ptr %slot318, align 8
  %op2372 = sub i64 %v2371, 24
  store i64 %op2372, ptr %slot328, align 8
  %v2373 = load i64, ptr %slot318, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %rgep2375 = getelementptr i8, ptr %p2374, i64 -24
  %ld2376 = load i64, ptr %rgep2375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2376, ptr %slot329, align 8
  %v2377 = load i64, ptr %slot329, align 8
  %cmp2378 = icmp ne i64 %v2377, 0
  %cv2379 = zext i1 %cmp2378 to i32
  store i32 %cv2379, ptr %slot330, align 8
  %v2380 = load i32, ptr %slot330, align 8
  %cv2381 = zext i32 %v2380 to i64
  %cond2382 = icmp ne i64 %cv2381, 0
  br i1 %cond2382, label %bb_rcgdec386, label %bb_rcgslow386
bb_rcgslow386:
  %v2383 = load i64, ptr %slot317, align 8
  %v2384 = load i64, ptr %slot300, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2383, i64 %v2384) nomerge, !dbg !120
  br label %bb_rcgdone386
bb_rcgdec386:
  %v2385 = load i64, ptr %slot326, align 8
  %v2386 = load i64, ptr %slot318, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %rgep2388 = getelementptr i8, ptr %p2387, i64 -32
  store i64 %v2385, ptr %rgep2388, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear386
bb_rcgclear386:
  %v2389 = load i64, ptr %slot300, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  store i64 0, ptr %p2390, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone386
bb_rcgdone386:
  br label %bb_rcslotdone355
bb_rcslotdone355:
  %v2391 = load i64, ptr %slot16, align 8
  store i64 %v2391, ptr %slot331, align 8
  %v2392 = load i64, ptr %slot18, align 8
  store i64 %v2392, ptr %slot332, align 8
  %v2393 = load i64, ptr %slot332, align 8
  %v2394 = load i64, ptr %slot331, align 8
  %p2395 = inttoptr i64 %v2393 to ptr
  %p2396 = inttoptr i64 %v2394 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2396, ptr %p2395, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2397 = load i64, ptr %slot13, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i32 2, ptr %p2398, align 4, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot15, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i32, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2401, ptr %slot333, align 8
  %v2402 = load i32, ptr %slot333, align 8
  %v2403 = load i64, ptr %slot13, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i32 %v2402, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot14, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 0, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot12, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  store i32 1, ptr %p2408, align 4, !alias.scope !3, !noalias !4
  %v2409 = load i64, ptr %slot331, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  %ld2411 = load i64, ptr %p2410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2411, ptr %slot334, align 8
  %v2412 = load i64, ptr %slot334, align 8
  %v2413 = load i64, ptr %slot26, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i64 %v2412, ptr %p2414, align 8, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot26, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i64, ptr %p2416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2417, ptr %slot335, align 8
  %v2418 = load i64, ptr %slot335, align 8
  %v2419 = load i64, ptr %slot17, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i64 %v2418, ptr %p2420, align 8, !alias.scope !3, !noalias !4
  %v2421 = load i64, ptr %slot17, align 8
  store i64 %v2421, ptr %slot336, align 8
  %v2422 = load i64, ptr %slot12, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %ld2424 = load i32, ptr %p2423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2424, ptr %slot337, align 8
  %v2425 = load i64, ptr %slot13, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %ld2427 = load i32, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2427, ptr %slot338, align 8
  %v2428 = load i32, ptr %slot338, align 8
  %op2429 = and i32 %v2428, 24
  store i32 %op2429, ptr %slot338, align 8
  %v2430 = load i32, ptr %slot338, align 8
  %cmp2431 = icmp eq i32 %v2430, 0
  %cv2432 = zext i1 %cmp2431 to i32
  store i32 %cv2432, ptr %slot339, align 8
  %v2433 = load i32, ptr %slot337, align 8
  %v2434 = load i32, ptr %slot339, align 8
  %op2435 = and i32 %v2433, %v2434
  store i32 %op2435, ptr %slot340, align 8
  %v2436 = load i32, ptr %slot340, align 8
  %cv2437 = zext i32 %v2436 to i64
  %cond2438 = icmp ne i64 %cv2437, 0
  br i1 %cond2438, label %bb_rctake401, label %bb_rccopy401
bb_rctake401:
  %v2439 = load i64, ptr %slot18, align 8
  store i64 %v2439, ptr %slot341, align 8
  %v2440 = load i64, ptr %slot35, align 8
  store i64 %v2440, ptr %slot342, align 8
  %v2441 = load i64, ptr %slot336, align 8
  %v2442 = load i64, ptr %slot341, align 8
  %op2443 = sub i64 %v2441, %v2442
  store i64 %op2443, ptr %slot343, align 8
  %v2444 = load i64, ptr %slot341, align 8
  %v2445 = load i64, ptr %slot336, align 8
  %op2446 = sub i64 %v2444, %v2445
  store i64 %op2446, ptr %slot344, align 8
  %v2447 = load i64, ptr %slot343, align 8
  %cmp2448 = icmp ult i64 %v2447, 8
  %cv2449 = zext i1 %cmp2448 to i32
  store i32 %cv2449, ptr %slot345, align 8
  %v2450 = load i64, ptr %slot344, align 8
  %cmp2451 = icmp ult i64 %v2450, 8
  %cv2452 = zext i1 %cmp2451 to i32
  store i32 %cv2452, ptr %slot346, align 8
  %v2453 = load i32, ptr %slot345, align 8
  %v2454 = load i32, ptr %slot346, align 8
  %op2455 = or i32 %v2453, %v2454
  store i32 %op2455, ptr %slot347, align 8
  %v2456 = load i32, ptr %slot347, align 8
  %cv2457 = zext i32 %v2456 to i64
  %cond2458 = icmp ne i64 %cv2457, 0
  br i1 %cond2458, label %bb_rcmoveslow410, label %bb_rcmovecheck410
bb_rcmovecheck410:
  %v2459 = load i64, ptr %slot336, align 8
  %p2461 = inttoptr i64 %v2459 to ptr
  %gep2462 = getelementptr i8, ptr %p2461, i64 0
  %op2460 = ptrtoint ptr %gep2462 to i64
  store i64 %op2460, ptr %slot348, align 8
  %v2463 = load i64, ptr %slot348, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %ld2465 = load i64, ptr %p2464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2465, ptr %slot349, align 8
  %v2466 = load i64, ptr %slot349, align 8
  %cmp2467 = icmp ne i64 %v2466, 0
  %cv2468 = zext i1 %cmp2467 to i32
  store i32 %cv2468, ptr %slot350, align 8
  %v2469 = load i32, ptr %slot350, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rcmoveheader418, label %bb_rcmovenext418
bb_rcmoveheader418:
  %v2472 = load i64, ptr %slot349, align 8
  %op2473 = sub i64 %v2472, 16
  store i64 %op2473, ptr %slot351, align 8
  %v2474 = load i64, ptr %slot349, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %rgep2476 = getelementptr i8, ptr %p2475, i64 -16
  %ld2477 = load i64, ptr %rgep2476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2477, ptr %slot352, align 8
  %v2478 = load i64, ptr %slot352, align 8
  %op2479 = and i64 %v2478, 5764607523034234881
  store i64 %op2479, ptr %slot353, align 8
  %v2480 = load i64, ptr %slot353, align 8
  %cmp2481 = icmp ne i64 %v2480, 0
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot354, align 8
  %v2483 = load i32, ptr %slot354, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcmoveslow410, label %bb_rcmovenext418
bb_rcmovenext418:
  %v2486 = load i64, ptr %slot336, align 8
  %v2487 = load i64, ptr %slot341, align 8
  %p2488 = inttoptr i64 %v2486 to ptr
  %p2489 = inttoptr i64 %v2487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2489, ptr %p2488, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot336, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  store i64 0, ptr %p2491, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved410
bb_rcmoveslow410:
  %v2492 = load i64, ptr %slot34, align 8
  %v2493 = load i64, ptr %slot341, align 8
  %v2494 = load i64, ptr %slot336, align 8
  %v2495 = load i64, ptr %slot342, align 8
  %cv2496 = trunc i64 %v2495 to i32
  %call2497 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v2492, i64 %v2493, i64 %v2494, i32 %cv2496) nomerge, !dbg !122
  store i32 %call2497, ptr %slot355, align 8
  %v2498 = load i32, ptr %slot355, align 8
  %cv2499 = zext i32 %v2498 to i64
  %cond2500 = icmp ne i64 %cv2499, 0
  br i1 %cond2500, label %bb_rcsuccess425, label %bb_rcfailure425
bb_rcfailure425:
  %v2501 = load i64, ptr %slot34, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  %call2503 = call i32 @myl_rc_take_failure(ptr %p2502) nomerge, !dbg !122
  store i32 %call2503, ptr %slot356, align 8
  %v2504 = load i64, ptr %slot1, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  %v2506 = load i32, ptr %slot356, align 8
  %call2507 = call i32 @myl_qbe_rc_status(ptr %p2505, i32 %v2506) nomerge, !dbg !122
  store i32 %call2507, ptr %slot357, align 8
  br label %bb_failure
bb_rcsuccess425:
  br label %bb_rcmoved410
bb_rcmoved410:
  %v2508 = load i64, ptr %slot12, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  store i32 0, ptr %p2509, align 4, !alias.scope !3, !noalias !4
  %v2510 = load i64, ptr %slot15, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  store i32 2, ptr %p2511, align 4, !alias.scope !3, !noalias !4
  %v2512 = load i64, ptr %slot14, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i32 1, ptr %p2513, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared401
bb_rccopy401:
  %v2514 = load i64, ptr %slot18, align 8
  store i64 %v2514, ptr %slot358, align 8
  %v2515 = load i64, ptr %slot35, align 8
  store i64 %v2515, ptr %slot359, align 8
  %v2516 = load i64, ptr %slot336, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  %ld2518 = load i64, ptr %p2517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2518, ptr %slot360, align 8
  %v2519 = load i64, ptr %slot360, align 8
  %cmp2520 = icmp ne i64 %v2519, 0
  %cv2521 = zext i1 %cmp2520 to i32
  store i32 %cv2521, ptr %slot361, align 8
  %v2522 = load i32, ptr %slot361, align 8
  %cv2523 = zext i32 %v2522 to i64
  %cond2524 = icmp ne i64 %cv2523, 0
  br i1 %cond2524, label %bb_rcgnn434, label %bb_rcgplain434
bb_rcgnn434:
  %v2525 = load i64, ptr %slot360, align 8
  %op2526 = sub i64 %v2525, 16
  store i64 %op2526, ptr %slot362, align 8
  %v2527 = load i64, ptr %slot360, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  %rgep2529 = getelementptr i8, ptr %p2528, i64 -16
  %ld2530 = load i64, ptr %rgep2529, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2530, ptr %slot363, align 8
  %v2531 = load i64, ptr %slot363, align 8
  %op2532 = and i64 %v2531, 4611686018427387906
  store i64 %op2532, ptr %slot364, align 8
  %v2533 = load i64, ptr %slot364, align 8
  %cmp2534 = icmp ne i64 %v2533, 0
  %cv2535 = zext i1 %cmp2534 to i32
  store i32 %cv2535, ptr %slot365, align 8
  %v2536 = load i32, ptr %slot365, align 8
  %cv2537 = zext i32 %v2536 to i64
  %cond2538 = icmp ne i64 %cv2537, 0
  br i1 %cond2538, label %bb_rcgspecial434, label %bb_rcginc434
bb_rcginc434:
  %v2539 = load i64, ptr %slot360, align 8
  %op2540 = sub i64 %v2539, 32
  store i64 %op2540, ptr %slot366, align 8
  %v2541 = load i64, ptr %slot360, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %rgep2543 = getelementptr i8, ptr %p2542, i64 -32
  %ld2544 = load i64, ptr %rgep2543, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2544, ptr %slot367, align 8
  %v2545 = load i64, ptr %slot367, align 8
  %op2546 = add i64 %v2545, 1
  store i64 %op2546, ptr %slot368, align 8
  %v2547 = load i64, ptr %slot368, align 8
  %cmp2548 = icmp eq i64 %v2547, 0
  %cv2549 = zext i1 %cmp2548 to i32
  store i32 %cv2549, ptr %slot369, align 8
  %v2550 = load i32, ptr %slot369, align 8
  %cv2551 = zext i32 %v2550 to i64
  %cond2552 = icmp ne i64 %cv2551, 0
  br i1 %cond2552, label %bb_rcglimit434, label %bb_rcgcapacity434
bb_rcglimit434:
  %v2553 = load i64, ptr %slot1, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  %call2555 = call i32 @myl_qbe_rc_status(ptr %p2554, i32 2) nomerge, !dbg !122
  store i32 %call2555, ptr %slot370, align 8
  br label %bb_failure
bb_rcgcapacity434:
  %v2556 = load i64, ptr %slot368, align 8
  %v2557 = load i64, ptr %slot360, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  %rgep2559 = getelementptr i8, ptr %p2558, i64 -32
  store i64 %v2556, ptr %rgep2559, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain434
bb_rcgspecial434:
  %v2560 = load i64, ptr %slot363, align 8
  %op2561 = and i64 %v2560, 4611686018427387904
  store i64 %op2561, ptr %slot371, align 8
  %v2562 = load i64, ptr %slot371, align 8
  %cmp2563 = icmp ne i64 %v2562, 0
  %cv2564 = zext i1 %cmp2563 to i32
  store i32 %cv2564, ptr %slot372, align 8
  %v2565 = load i32, ptr %slot372, align 8
  %cv2566 = zext i32 %v2565 to i64
  %cond2567 = icmp ne i64 %cv2566, 0
  br i1 %cond2567, label %bb_rcgslow434, label %bb_rcgplain434
bb_rcgslow434:
  %v2568 = load i64, ptr %slot34, align 8
  %v2569 = load i64, ptr %slot358, align 8
  %v2570 = load i64, ptr %slot336, align 8
  %v2571 = load i64, ptr %slot359, align 8
  %cv2572 = trunc i64 %v2571 to i32
  %call2573 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v2568, i64 %v2569, i64 %v2570, i32 %cv2572) nomerge, !dbg !122
  store i32 %call2573, ptr %slot373, align 8
  %v2574 = load i32, ptr %slot373, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcsuccess448, label %bb_rcfailure448
bb_rcfailure448:
  %v2577 = load i64, ptr %slot34, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %call2579 = call i32 @myl_rc_take_failure(ptr %p2578) nomerge, !dbg !122
  store i32 %call2579, ptr %slot374, align 8
  %v2580 = load i64, ptr %slot1, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %v2582 = load i32, ptr %slot374, align 8
  %call2583 = call i32 @myl_qbe_rc_status(ptr %p2581, i32 %v2582) nomerge, !dbg !122
  store i32 %call2583, ptr %slot375, align 8
  br label %bb_failure
bb_rcsuccess448:
  br label %bb_rcgdone434
bb_rcgplain434:
  %v2584 = load i64, ptr %slot360, align 8
  %v2585 = load i64, ptr %slot358, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i64 %v2584, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone434
bb_rcgdone434:
  %v2587 = load i64, ptr %slot15, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  store i32 2, ptr %p2588, align 4, !alias.scope !3, !noalias !4
  %v2589 = load i64, ptr %slot14, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  store i32 1, ptr %p2590, align 4, !alias.scope !3, !noalias !4
  %v2591 = load i64, ptr %slot12, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  %ld2593 = load i32, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2593, ptr %slot376, align 8
  %v2594 = load i32, ptr %slot376, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rcslotdrop455, label %bb_rcslotdone455
bb_rcslotdrop455:
  %v2597 = load i64, ptr %slot12, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i32 0, ptr %p2598, align 4, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot16, align 8
  store i64 %v2599, ptr %slot377, align 8
  %v2600 = load i64, ptr %slot13, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %ld2602 = load i32, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2602, ptr %slot378, align 8
  %v2603 = load i32, ptr %slot378, align 8
  %op2604 = and i32 %v2603, 28
  store i32 %op2604, ptr %slot379, align 8
  %v2605 = load i32, ptr %slot379, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcslotrole455, label %bb_rcslotowner455
bb_rcslotrole455:
  %v2608 = load i64, ptr %slot34, align 8
  store i64 %v2608, ptr %slot380, align 8
  %v2609 = load i64, ptr %slot377, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %ld2611 = load i64, ptr %p2610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2611, ptr %slot381, align 8
  %v2612 = load i64, ptr %slot381, align 8
  %cmp2613 = icmp ne i64 %v2612, 0
  %cv2614 = zext i1 %cmp2613 to i32
  store i32 %cv2614, ptr %slot382, align 8
  %v2615 = load i32, ptr %slot382, align 8
  %cv2616 = zext i32 %v2615 to i64
  %cond2617 = icmp ne i64 %cv2616, 0
  br i1 %cond2617, label %bb_rcgnn471, label %bb_rcgdone471
bb_rcgnn471:
  %v2618 = load i64, ptr %slot381, align 8
  %op2619 = sub i64 %v2618, 16
  store i64 %op2619, ptr %slot383, align 8
  %v2620 = load i64, ptr %slot381, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %rgep2622 = getelementptr i8, ptr %p2621, i64 -16
  %ld2623 = load i64, ptr %rgep2622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2623, ptr %slot384, align 8
  %v2624 = load i64, ptr %slot384, align 8
  %op2625 = and i64 %v2624, 4611686018427387906
  store i64 %op2625, ptr %slot385, align 8
  %v2626 = load i64, ptr %slot385, align 8
  %cmp2627 = icmp ne i64 %v2626, 0
  %cv2628 = zext i1 %cmp2627 to i32
  store i32 %cv2628, ptr %slot386, align 8
  %v2629 = load i32, ptr %slot386, align 8
  %cv2630 = zext i32 %v2629 to i64
  %cond2631 = icmp ne i64 %cv2630, 0
  br i1 %cond2631, label %bb_rcgclear471, label %bb_rcgcounted471
bb_rcgcounted471:
  %v2632 = load i64, ptr %slot381, align 8
  %op2633 = sub i64 %v2632, 24
  store i64 %op2633, ptr %slot387, align 8
  %v2634 = load i64, ptr %slot381, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %rgep2636 = getelementptr i8, ptr %p2635, i64 -24
  %ld2637 = load i64, ptr %rgep2636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2637, ptr %slot388, align 8
  %v2638 = load i64, ptr %slot388, align 8
  %op2639 = sub i64 %v2638, 1
  store i64 %op2639, ptr %slot389, align 8
  %v2640 = load i64, ptr %slot389, align 8
  %cmp2641 = icmp eq i64 %v2640, 0
  %cv2642 = zext i1 %cmp2641 to i32
  store i32 %cv2642, ptr %slot390, align 8
  %v2643 = load i32, ptr %slot390, align 8
  %cv2644 = zext i32 %v2643 to i64
  %cond2645 = icmp ne i64 %cv2644, 0
  br i1 %cond2645, label %bb_rcglast471, label %bb_rcgdec471
bb_rcglast471:
  %v2646 = load i64, ptr %slot381, align 8
  %op2647 = sub i64 %v2646, 32
  store i64 %op2647, ptr %slot391, align 8
  %v2648 = load i64, ptr %slot381, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %rgep2650 = getelementptr i8, ptr %p2649, i64 -32
  %ld2651 = load i64, ptr %rgep2650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2651, ptr %slot392, align 8
  %v2652 = load i64, ptr %slot392, align 8
  %cmp2653 = icmp ne i64 %v2652, 0
  %cv2654 = zext i1 %cmp2653 to i32
  store i32 %cv2654, ptr %slot393, align 8
  %v2655 = load i32, ptr %slot393, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcgdec471, label %bb_rcgslow471
bb_rcgslow471:
  %v2658 = load i64, ptr %slot380, align 8
  %v2659 = load i64, ptr %slot377, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2658, i64 %v2659) nomerge, !dbg !122
  br label %bb_rcgdone471
bb_rcgdec471:
  %v2660 = load i64, ptr %slot389, align 8
  %v2661 = load i64, ptr %slot381, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -24
  store i64 %v2660, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear471
bb_rcgclear471:
  %v2664 = load i64, ptr %slot377, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  store i64 0, ptr %p2665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone471
bb_rcgdone471:
  br label %bb_rcslotdone455
bb_rcslotowner455:
  %v2666 = load i64, ptr %slot34, align 8
  store i64 %v2666, ptr %slot394, align 8
  %v2667 = load i64, ptr %slot377, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  %ld2669 = load i64, ptr %p2668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2669, ptr %slot395, align 8
  %v2670 = load i64, ptr %slot395, align 8
  %cmp2671 = icmp ne i64 %v2670, 0
  %cv2672 = zext i1 %cmp2671 to i32
  store i32 %cv2672, ptr %slot396, align 8
  %v2673 = load i32, ptr %slot396, align 8
  %cv2674 = zext i32 %v2673 to i64
  %cond2675 = icmp ne i64 %cv2674, 0
  br i1 %cond2675, label %bb_rcgnn486, label %bb_rcgdone486
bb_rcgnn486:
  %v2676 = load i64, ptr %slot395, align 8
  %op2677 = sub i64 %v2676, 16
  store i64 %op2677, ptr %slot397, align 8
  %v2678 = load i64, ptr %slot395, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  %rgep2680 = getelementptr i8, ptr %p2679, i64 -16
  %ld2681 = load i64, ptr %rgep2680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2681, ptr %slot398, align 8
  %v2682 = load i64, ptr %slot398, align 8
  %op2683 = and i64 %v2682, 4611686018427387906
  store i64 %op2683, ptr %slot399, align 8
  %v2684 = load i64, ptr %slot399, align 8
  %cmp2685 = icmp ne i64 %v2684, 0
  %cv2686 = zext i1 %cmp2685 to i32
  store i32 %cv2686, ptr %slot400, align 8
  %v2687 = load i32, ptr %slot400, align 8
  %cv2688 = zext i32 %v2687 to i64
  %cond2689 = icmp ne i64 %cv2688, 0
  br i1 %cond2689, label %bb_rcgclear486, label %bb_rcgcounted486
bb_rcgcounted486:
  %v2690 = load i64, ptr %slot395, align 8
  %op2691 = sub i64 %v2690, 32
  store i64 %op2691, ptr %slot401, align 8
  %v2692 = load i64, ptr %slot395, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  %rgep2694 = getelementptr i8, ptr %p2693, i64 -32
  %ld2695 = load i64, ptr %rgep2694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2695, ptr %slot402, align 8
  %v2696 = load i64, ptr %slot402, align 8
  %op2697 = sub i64 %v2696, 1
  store i64 %op2697, ptr %slot403, align 8
  %v2698 = load i64, ptr %slot403, align 8
  %cmp2699 = icmp eq i64 %v2698, 0
  %cv2700 = zext i1 %cmp2699 to i32
  store i32 %cv2700, ptr %slot404, align 8
  %v2701 = load i32, ptr %slot404, align 8
  %cv2702 = zext i32 %v2701 to i64
  %cond2703 = icmp ne i64 %cv2702, 0
  br i1 %cond2703, label %bb_rcglast486, label %bb_rcgdec486
bb_rcglast486:
  %v2704 = load i64, ptr %slot395, align 8
  %op2705 = sub i64 %v2704, 24
  store i64 %op2705, ptr %slot405, align 8
  %v2706 = load i64, ptr %slot395, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %rgep2708 = getelementptr i8, ptr %p2707, i64 -24
  %ld2709 = load i64, ptr %rgep2708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2709, ptr %slot406, align 8
  %v2710 = load i64, ptr %slot406, align 8
  %cmp2711 = icmp ne i64 %v2710, 0
  %cv2712 = zext i1 %cmp2711 to i32
  store i32 %cv2712, ptr %slot407, align 8
  %v2713 = load i32, ptr %slot407, align 8
  %cv2714 = zext i32 %v2713 to i64
  %cond2715 = icmp ne i64 %cv2714, 0
  br i1 %cond2715, label %bb_rcgdec486, label %bb_rcgslow486
bb_rcgslow486:
  %v2716 = load i64, ptr %slot394, align 8
  %v2717 = load i64, ptr %slot377, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2716, i64 %v2717) nomerge, !dbg !122
  br label %bb_rcgdone486
bb_rcgdec486:
  %v2718 = load i64, ptr %slot403, align 8
  %v2719 = load i64, ptr %slot395, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %rgep2721 = getelementptr i8, ptr %p2720, i64 -32
  store i64 %v2718, ptr %rgep2721, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear486
bb_rcgclear486:
  %v2722 = load i64, ptr %slot377, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  store i64 0, ptr %p2723, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone486
bb_rcgdone486:
  br label %bb_rcslotdone455
bb_rcslotdone455:
  br label %bb_rcprepared401
bb_rcprepared401:
  %v2724 = load i64, ptr %slot10, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  %ld2726 = load i32, ptr %p2725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2726, ptr %slot408, align 8
  %v2727 = load i32, ptr %slot408, align 8
  %cv2728 = zext i32 %v2727 to i64
  %cond2729 = icmp ne i64 %cv2728, 0
  br i1 %cond2729, label %bb_rcslotdrop493, label %bb_rcslotdone493
bb_rcslotdrop493:
  %v2730 = load i64, ptr %slot10, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  store i32 0, ptr %p2731, align 4, !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot25, align 8
  store i64 %v2732, ptr %slot409, align 8
  %v2733 = load i64, ptr %slot11, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %ld2735 = load i32, ptr %p2734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2735, ptr %slot410, align 8
  %v2736 = load i32, ptr %slot410, align 8
  %op2737 = and i32 %v2736, 28
  store i32 %op2737, ptr %slot411, align 8
  %v2738 = load i32, ptr %slot411, align 8
  %cv2739 = zext i32 %v2738 to i64
  %cond2740 = icmp ne i64 %cv2739, 0
  br i1 %cond2740, label %bb_rcslotrole493, label %bb_rcslotowner493
bb_rcslotrole493:
  %v2741 = load i64, ptr %slot34, align 8
  store i64 %v2741, ptr %slot412, align 8
  %v2742 = load i64, ptr %slot409, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %ld2744 = load i64, ptr %p2743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2744, ptr %slot413, align 8
  %v2745 = load i64, ptr %slot413, align 8
  %cmp2746 = icmp ne i64 %v2745, 0
  %cv2747 = zext i1 %cmp2746 to i32
  store i32 %cv2747, ptr %slot414, align 8
  %v2748 = load i32, ptr %slot414, align 8
  %cv2749 = zext i32 %v2748 to i64
  %cond2750 = icmp ne i64 %cv2749, 0
  br i1 %cond2750, label %bb_rcgnn509, label %bb_rcgdone509
bb_rcgnn509:
  %v2751 = load i64, ptr %slot413, align 8
  %op2752 = sub i64 %v2751, 16
  store i64 %op2752, ptr %slot415, align 8
  %v2753 = load i64, ptr %slot413, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %rgep2755 = getelementptr i8, ptr %p2754, i64 -16
  %ld2756 = load i64, ptr %rgep2755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2756, ptr %slot416, align 8
  %v2757 = load i64, ptr %slot416, align 8
  %op2758 = and i64 %v2757, 4611686018427387906
  store i64 %op2758, ptr %slot417, align 8
  %v2759 = load i64, ptr %slot417, align 8
  %cmp2760 = icmp ne i64 %v2759, 0
  %cv2761 = zext i1 %cmp2760 to i32
  store i32 %cv2761, ptr %slot418, align 8
  %v2762 = load i32, ptr %slot418, align 8
  %cv2763 = zext i32 %v2762 to i64
  %cond2764 = icmp ne i64 %cv2763, 0
  br i1 %cond2764, label %bb_rcgclear509, label %bb_rcgcounted509
bb_rcgcounted509:
  %v2765 = load i64, ptr %slot413, align 8
  %op2766 = sub i64 %v2765, 24
  store i64 %op2766, ptr %slot419, align 8
  %v2767 = load i64, ptr %slot413, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  %rgep2769 = getelementptr i8, ptr %p2768, i64 -24
  %ld2770 = load i64, ptr %rgep2769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2770, ptr %slot420, align 8
  %v2771 = load i64, ptr %slot420, align 8
  %op2772 = sub i64 %v2771, 1
  store i64 %op2772, ptr %slot421, align 8
  %v2773 = load i64, ptr %slot421, align 8
  %cmp2774 = icmp eq i64 %v2773, 0
  %cv2775 = zext i1 %cmp2774 to i32
  store i32 %cv2775, ptr %slot422, align 8
  %v2776 = load i32, ptr %slot422, align 8
  %cv2777 = zext i32 %v2776 to i64
  %cond2778 = icmp ne i64 %cv2777, 0
  br i1 %cond2778, label %bb_rcglast509, label %bb_rcgdec509
bb_rcglast509:
  %v2779 = load i64, ptr %slot413, align 8
  %op2780 = sub i64 %v2779, 32
  store i64 %op2780, ptr %slot423, align 8
  %v2781 = load i64, ptr %slot413, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  %rgep2783 = getelementptr i8, ptr %p2782, i64 -32
  %ld2784 = load i64, ptr %rgep2783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2784, ptr %slot424, align 8
  %v2785 = load i64, ptr %slot424, align 8
  %cmp2786 = icmp ne i64 %v2785, 0
  %cv2787 = zext i1 %cmp2786 to i32
  store i32 %cv2787, ptr %slot425, align 8
  %v2788 = load i32, ptr %slot425, align 8
  %cv2789 = zext i32 %v2788 to i64
  %cond2790 = icmp ne i64 %cv2789, 0
  br i1 %cond2790, label %bb_rcgdec509, label %bb_rcgslow509
bb_rcgslow509:
  %v2791 = load i64, ptr %slot412, align 8
  %v2792 = load i64, ptr %slot409, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2791, i64 %v2792) nomerge, !dbg !122
  br label %bb_rcgdone509
bb_rcgdec509:
  %v2793 = load i64, ptr %slot421, align 8
  %v2794 = load i64, ptr %slot413, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %rgep2796 = getelementptr i8, ptr %p2795, i64 -24
  store i64 %v2793, ptr %rgep2796, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear509
bb_rcgclear509:
  %v2797 = load i64, ptr %slot409, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  store i64 0, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone509
bb_rcgdone509:
  br label %bb_rcslotdone493
bb_rcslotowner493:
  %v2799 = load i64, ptr %slot34, align 8
  store i64 %v2799, ptr %slot426, align 8
  %v2800 = load i64, ptr %slot409, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2802, ptr %slot427, align 8
  %v2803 = load i64, ptr %slot427, align 8
  %cmp2804 = icmp ne i64 %v2803, 0
  %cv2805 = zext i1 %cmp2804 to i32
  store i32 %cv2805, ptr %slot428, align 8
  %v2806 = load i32, ptr %slot428, align 8
  %cv2807 = zext i32 %v2806 to i64
  %cond2808 = icmp ne i64 %cv2807, 0
  br i1 %cond2808, label %bb_rcgnn524, label %bb_rcgdone524
bb_rcgnn524:
  %v2809 = load i64, ptr %slot427, align 8
  %op2810 = sub i64 %v2809, 16
  store i64 %op2810, ptr %slot429, align 8
  %v2811 = load i64, ptr %slot427, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %rgep2813 = getelementptr i8, ptr %p2812, i64 -16
  %ld2814 = load i64, ptr %rgep2813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2814, ptr %slot430, align 8
  %v2815 = load i64, ptr %slot430, align 8
  %op2816 = and i64 %v2815, 4611686018427387906
  store i64 %op2816, ptr %slot431, align 8
  %v2817 = load i64, ptr %slot431, align 8
  %cmp2818 = icmp ne i64 %v2817, 0
  %cv2819 = zext i1 %cmp2818 to i32
  store i32 %cv2819, ptr %slot432, align 8
  %v2820 = load i32, ptr %slot432, align 8
  %cv2821 = zext i32 %v2820 to i64
  %cond2822 = icmp ne i64 %cv2821, 0
  br i1 %cond2822, label %bb_rcgclear524, label %bb_rcgcounted524
bb_rcgcounted524:
  %v2823 = load i64, ptr %slot427, align 8
  %op2824 = sub i64 %v2823, 32
  store i64 %op2824, ptr %slot433, align 8
  %v2825 = load i64, ptr %slot427, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  %rgep2827 = getelementptr i8, ptr %p2826, i64 -32
  %ld2828 = load i64, ptr %rgep2827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2828, ptr %slot434, align 8
  %v2829 = load i64, ptr %slot434, align 8
  %op2830 = sub i64 %v2829, 1
  store i64 %op2830, ptr %slot435, align 8
  %v2831 = load i64, ptr %slot435, align 8
  %cmp2832 = icmp eq i64 %v2831, 0
  %cv2833 = zext i1 %cmp2832 to i32
  store i32 %cv2833, ptr %slot436, align 8
  %v2834 = load i32, ptr %slot436, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcglast524, label %bb_rcgdec524
bb_rcglast524:
  %v2837 = load i64, ptr %slot427, align 8
  %op2838 = sub i64 %v2837, 24
  store i64 %op2838, ptr %slot437, align 8
  %v2839 = load i64, ptr %slot427, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  %rgep2841 = getelementptr i8, ptr %p2840, i64 -24
  %ld2842 = load i64, ptr %rgep2841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2842, ptr %slot438, align 8
  %v2843 = load i64, ptr %slot438, align 8
  %cmp2844 = icmp ne i64 %v2843, 0
  %cv2845 = zext i1 %cmp2844 to i32
  store i32 %cv2845, ptr %slot439, align 8
  %v2846 = load i32, ptr %slot439, align 8
  %cv2847 = zext i32 %v2846 to i64
  %cond2848 = icmp ne i64 %cv2847, 0
  br i1 %cond2848, label %bb_rcgdec524, label %bb_rcgslow524
bb_rcgslow524:
  %v2849 = load i64, ptr %slot426, align 8
  %v2850 = load i64, ptr %slot409, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2849, i64 %v2850) nomerge, !dbg !122
  br label %bb_rcgdone524
bb_rcgdec524:
  %v2851 = load i64, ptr %slot435, align 8
  %v2852 = load i64, ptr %slot427, align 8
  %p2853 = inttoptr i64 %v2852 to ptr
  %rgep2854 = getelementptr i8, ptr %p2853, i64 -32
  store i64 %v2851, ptr %rgep2854, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear524
bb_rcgclear524:
  %v2855 = load i64, ptr %slot409, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i64 0, ptr %p2856, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone524
bb_rcgdone524:
  br label %bb_rcslotdone493
bb_rcslotdone493:
  %v2857 = load i64, ptr %slot25, align 8
  store i64 %v2857, ptr %slot440, align 8
  %v2858 = load i64, ptr %slot18, align 8
  store i64 %v2858, ptr %slot441, align 8
  %v2859 = load i64, ptr %slot441, align 8
  %v2860 = load i64, ptr %slot440, align 8
  %p2861 = inttoptr i64 %v2859 to ptr
  %p2862 = inttoptr i64 %v2860 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2862, ptr %p2861, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2863 = load i64, ptr %slot14, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  store i32 0, ptr %p2864, align 4, !alias.scope !3, !noalias !4
  %v2865 = load i64, ptr %slot11, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  store i32 2, ptr %p2866, align 4, !alias.scope !3, !noalias !4
  %v2867 = load i64, ptr %slot15, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %ld2869 = load i32, ptr %p2868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2869, ptr %slot442, align 8
  %v2870 = load i32, ptr %slot442, align 8
  %v2871 = load i64, ptr %slot11, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  store i32 %v2870, ptr %p2872, align 4, !alias.scope !3, !noalias !4
  %v2873 = load i64, ptr %slot10, align 8
  %p2874 = inttoptr i64 %v2873 to ptr
  store i32 1, ptr %p2874, align 4, !alias.scope !3, !noalias !4
  %v2875 = load i64, ptr %slot8, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %ld2877 = load i32, ptr %p2876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2877, ptr %slot443, align 8
  %v2878 = load i32, ptr %slot443, align 8
  %cv2879 = zext i32 %v2878 to i64
  %cond2880 = icmp ne i64 %cv2879, 0
  br i1 %cond2880, label %bb_rcslotdrop537, label %bb_rcslotdone537
bb_rcslotdrop537:
  %v2881 = load i64, ptr %slot8, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  store i32 0, ptr %p2882, align 4, !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot24, align 8
  store i64 %v2883, ptr %slot444, align 8
  %v2884 = load i64, ptr %slot9, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  %ld2886 = load i32, ptr %p2885, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2886, ptr %slot445, align 8
  %v2887 = load i32, ptr %slot445, align 8
  %op2888 = and i32 %v2887, 28
  store i32 %op2888, ptr %slot446, align 8
  %v2889 = load i32, ptr %slot446, align 8
  %cv2890 = zext i32 %v2889 to i64
  %cond2891 = icmp ne i64 %cv2890, 0
  br i1 %cond2891, label %bb_rcslotrole537, label %bb_rcslotowner537
bb_rcslotrole537:
  %v2892 = load i64, ptr %slot34, align 8
  store i64 %v2892, ptr %slot447, align 8
  %v2893 = load i64, ptr %slot444, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  %ld2895 = load i64, ptr %p2894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2895, ptr %slot448, align 8
  %v2896 = load i64, ptr %slot448, align 8
  %cmp2897 = icmp ne i64 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot449, align 8
  %v2899 = load i32, ptr %slot449, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcgnn553, label %bb_rcgdone553
bb_rcgnn553:
  %v2902 = load i64, ptr %slot448, align 8
  %op2903 = sub i64 %v2902, 16
  store i64 %op2903, ptr %slot450, align 8
  %v2904 = load i64, ptr %slot448, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %rgep2906 = getelementptr i8, ptr %p2905, i64 -16
  %ld2907 = load i64, ptr %rgep2906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2907, ptr %slot451, align 8
  %v2908 = load i64, ptr %slot451, align 8
  %op2909 = and i64 %v2908, 4611686018427387906
  store i64 %op2909, ptr %slot452, align 8
  %v2910 = load i64, ptr %slot452, align 8
  %cmp2911 = icmp ne i64 %v2910, 0
  %cv2912 = zext i1 %cmp2911 to i32
  store i32 %cv2912, ptr %slot453, align 8
  %v2913 = load i32, ptr %slot453, align 8
  %cv2914 = zext i32 %v2913 to i64
  %cond2915 = icmp ne i64 %cv2914, 0
  br i1 %cond2915, label %bb_rcgclear553, label %bb_rcgcounted553
bb_rcgcounted553:
  %v2916 = load i64, ptr %slot448, align 8
  %op2917 = sub i64 %v2916, 24
  store i64 %op2917, ptr %slot454, align 8
  %v2918 = load i64, ptr %slot448, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  %rgep2920 = getelementptr i8, ptr %p2919, i64 -24
  %ld2921 = load i64, ptr %rgep2920, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2921, ptr %slot455, align 8
  %v2922 = load i64, ptr %slot455, align 8
  %op2923 = sub i64 %v2922, 1
  store i64 %op2923, ptr %slot456, align 8
  %v2924 = load i64, ptr %slot456, align 8
  %cmp2925 = icmp eq i64 %v2924, 0
  %cv2926 = zext i1 %cmp2925 to i32
  store i32 %cv2926, ptr %slot457, align 8
  %v2927 = load i32, ptr %slot457, align 8
  %cv2928 = zext i32 %v2927 to i64
  %cond2929 = icmp ne i64 %cv2928, 0
  br i1 %cond2929, label %bb_rcglast553, label %bb_rcgdec553
bb_rcglast553:
  %v2930 = load i64, ptr %slot448, align 8
  %op2931 = sub i64 %v2930, 32
  store i64 %op2931, ptr %slot458, align 8
  %v2932 = load i64, ptr %slot448, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %rgep2934 = getelementptr i8, ptr %p2933, i64 -32
  %ld2935 = load i64, ptr %rgep2934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2935, ptr %slot459, align 8
  %v2936 = load i64, ptr %slot459, align 8
  %cmp2937 = icmp ne i64 %v2936, 0
  %cv2938 = zext i1 %cmp2937 to i32
  store i32 %cv2938, ptr %slot460, align 8
  %v2939 = load i32, ptr %slot460, align 8
  %cv2940 = zext i32 %v2939 to i64
  %cond2941 = icmp ne i64 %cv2940, 0
  br i1 %cond2941, label %bb_rcgdec553, label %bb_rcgslow553
bb_rcgslow553:
  %v2942 = load i64, ptr %slot447, align 8
  %v2943 = load i64, ptr %slot444, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2942, i64 %v2943) nomerge, !dbg !122
  br label %bb_rcgdone553
bb_rcgdec553:
  %v2944 = load i64, ptr %slot456, align 8
  %v2945 = load i64, ptr %slot448, align 8
  %p2946 = inttoptr i64 %v2945 to ptr
  %rgep2947 = getelementptr i8, ptr %p2946, i64 -24
  store i64 %v2944, ptr %rgep2947, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear553
bb_rcgclear553:
  %v2948 = load i64, ptr %slot444, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  store i64 0, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone553
bb_rcgdone553:
  br label %bb_rcslotdone537
bb_rcslotowner537:
  %v2950 = load i64, ptr %slot34, align 8
  store i64 %v2950, ptr %slot461, align 8
  %v2951 = load i64, ptr %slot444, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot462, align 8
  %v2954 = load i64, ptr %slot462, align 8
  %cmp2955 = icmp ne i64 %v2954, 0
  %cv2956 = zext i1 %cmp2955 to i32
  store i32 %cv2956, ptr %slot463, align 8
  %v2957 = load i32, ptr %slot463, align 8
  %cv2958 = zext i32 %v2957 to i64
  %cond2959 = icmp ne i64 %cv2958, 0
  br i1 %cond2959, label %bb_rcgnn568, label %bb_rcgdone568
bb_rcgnn568:
  %v2960 = load i64, ptr %slot462, align 8
  %op2961 = sub i64 %v2960, 16
  store i64 %op2961, ptr %slot464, align 8
  %v2962 = load i64, ptr %slot462, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  %rgep2964 = getelementptr i8, ptr %p2963, i64 -16
  %ld2965 = load i64, ptr %rgep2964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2965, ptr %slot465, align 8
  %v2966 = load i64, ptr %slot465, align 8
  %op2967 = and i64 %v2966, 4611686018427387906
  store i64 %op2967, ptr %slot466, align 8
  %v2968 = load i64, ptr %slot466, align 8
  %cmp2969 = icmp ne i64 %v2968, 0
  %cv2970 = zext i1 %cmp2969 to i32
  store i32 %cv2970, ptr %slot467, align 8
  %v2971 = load i32, ptr %slot467, align 8
  %cv2972 = zext i32 %v2971 to i64
  %cond2973 = icmp ne i64 %cv2972, 0
  br i1 %cond2973, label %bb_rcgclear568, label %bb_rcgcounted568
bb_rcgcounted568:
  %v2974 = load i64, ptr %slot462, align 8
  %op2975 = sub i64 %v2974, 32
  store i64 %op2975, ptr %slot468, align 8
  %v2976 = load i64, ptr %slot462, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %rgep2978 = getelementptr i8, ptr %p2977, i64 -32
  %ld2979 = load i64, ptr %rgep2978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2979, ptr %slot469, align 8
  %v2980 = load i64, ptr %slot469, align 8
  %op2981 = sub i64 %v2980, 1
  store i64 %op2981, ptr %slot470, align 8
  %v2982 = load i64, ptr %slot470, align 8
  %cmp2983 = icmp eq i64 %v2982, 0
  %cv2984 = zext i1 %cmp2983 to i32
  store i32 %cv2984, ptr %slot471, align 8
  %v2985 = load i32, ptr %slot471, align 8
  %cv2986 = zext i32 %v2985 to i64
  %cond2987 = icmp ne i64 %cv2986, 0
  br i1 %cond2987, label %bb_rcglast568, label %bb_rcgdec568
bb_rcglast568:
  %v2988 = load i64, ptr %slot462, align 8
  %op2989 = sub i64 %v2988, 24
  store i64 %op2989, ptr %slot472, align 8
  %v2990 = load i64, ptr %slot462, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  %rgep2992 = getelementptr i8, ptr %p2991, i64 -24
  %ld2993 = load i64, ptr %rgep2992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2993, ptr %slot473, align 8
  %v2994 = load i64, ptr %slot473, align 8
  %cmp2995 = icmp ne i64 %v2994, 0
  %cv2996 = zext i1 %cmp2995 to i32
  store i32 %cv2996, ptr %slot474, align 8
  %v2997 = load i32, ptr %slot474, align 8
  %cv2998 = zext i32 %v2997 to i64
  %cond2999 = icmp ne i64 %cv2998, 0
  br i1 %cond2999, label %bb_rcgdec568, label %bb_rcgslow568
bb_rcgslow568:
  %v3000 = load i64, ptr %slot461, align 8
  %v3001 = load i64, ptr %slot444, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3000, i64 %v3001) nomerge, !dbg !122
  br label %bb_rcgdone568
bb_rcgdec568:
  %v3002 = load i64, ptr %slot470, align 8
  %v3003 = load i64, ptr %slot462, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  %rgep3005 = getelementptr i8, ptr %p3004, i64 -32
  store i64 %v3002, ptr %rgep3005, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear568
bb_rcgclear568:
  %v3006 = load i64, ptr %slot444, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i64 0, ptr %p3007, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone568
bb_rcgdone568:
  br label %bb_rcslotdone537
bb_rcslotdone537:
  %v3008 = load i64, ptr %slot25, align 8
  store i64 %v3008, ptr %slot475, align 8
  %v3009 = load i64, ptr %slot11, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  store i32 2, ptr %p3010, align 4, !alias.scope !3, !noalias !4
  %v3011 = load i64, ptr %slot475, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  %ld3013 = load i64, ptr %p3012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3013, ptr %slot476, align 8
  %v3014 = load i64, ptr %slot476, align 8
  %cmp3015 = icmp ne i64 %v3014, 0
  %cv3016 = zext i1 %cmp3015 to i32
  store i32 %cv3016, ptr %slot477, align 8
  %v3017 = load i32, ptr %slot477, align 8
  %cv3018 = zext i32 %v3017 to i64
  %cond3019 = icmp ne i64 %cv3018, 0
  br i1 %cond3019, label %bb_rcguniquenn575, label %bb_rcgunique575
bb_rcguniquenn575:
  %v3020 = load i64, ptr %slot476, align 8
  %op3021 = sub i64 %v3020, 16
  store i64 %op3021, ptr %slot478, align 8
  %v3022 = load i64, ptr %slot476, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %rgep3024 = getelementptr i8, ptr %p3023, i64 -16
  %ld3025 = load i64, ptr %rgep3024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3025, ptr %slot479, align 8
  %v3026 = load i64, ptr %slot479, align 8
  %op3027 = and i64 %v3026, 6917529027641081858
  store i64 %op3027, ptr %slot480, align 8
  %v3028 = load i64, ptr %slot480, align 8
  %cmp3029 = icmp ne i64 %v3028, 0
  %cv3030 = zext i1 %cmp3029 to i32
  store i32 %cv3030, ptr %slot481, align 8
  %v3031 = load i32, ptr %slot481, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcguniqueslow575, label %bb_rcguniquecount575
bb_rcguniquecount575:
  %v3034 = load i64, ptr %slot476, align 8
  %op3035 = sub i64 %v3034, 32
  store i64 %op3035, ptr %slot482, align 8
  %v3036 = load i64, ptr %slot476, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %rgep3038 = getelementptr i8, ptr %p3037, i64 -32
  %ld3039 = load i64, ptr %rgep3038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3039, ptr %slot483, align 8
  %v3040 = load i64, ptr %slot483, align 8
  %cmp3041 = icmp ult i64 %v3040, 2
  %cv3042 = zext i1 %cmp3041 to i32
  store i32 %cv3042, ptr %slot484, align 8
  %v3043 = load i32, ptr %slot484, align 8
  %cv3044 = zext i32 %v3043 to i64
  %cond3045 = icmp ne i64 %cv3044, 0
  br i1 %cond3045, label %bb_rcgunique575, label %bb_rcguniqueslow575
bb_rcguniqueslow575:
  %v3046 = load i64, ptr %slot1, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  %p3048 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3049 = load i64, ptr %slot475, align 8
  %p3050 = inttoptr i64 %v3049 to ptr
  %v3051 = load i64, ptr %slot10, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %call3053 = call i32 @myl_qbe_rc_unique_local(ptr %p3047, ptr %p3048, ptr %p3050, ptr %p3052) nomerge, !dbg !124
  store i32 %call3053, ptr %slot485, align 8
  %v3054 = load i32, ptr %slot485, align 8
  %cv3055 = zext i32 %v3054 to i64
  %cond3056 = icmp ne i64 %cv3055, 0
  br i1 %cond3056, label %bb_rcunique586, label %bb_failure
bb_rcunique586:
  br label %bb_rcgunique575
bb_rcgunique575:
  %v3057 = load i64, ptr %slot25, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %ld3059 = load i64, ptr %p3058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3059, ptr %slot486, align 8
  %v3060 = load i64, ptr %slot486, align 8
  %v3061 = load i64, ptr %slot26, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  store i64 %v3060, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  %v3063 = load i64, ptr %slot20, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  %ld3065 = load i64, ptr %p3064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3065, ptr %slot487, align 8
  %v3066 = load i64, ptr %slot487, align 8
  %v3067 = load i64, ptr %slot27, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  store i64 %v3066, ptr %p3068, align 8, !alias.scope !3, !noalias !4
  %v3069 = load i64, ptr %slot21, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %ld3071 = load i64, ptr %p3070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3071, ptr %slot488, align 8
  %v3072 = load i64, ptr %slot488, align 8
  %v3073 = load i64, ptr %slot28, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  store i64 %v3072, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  %v3075 = load i64, ptr %slot22, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  %ld3077 = load i64, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3077, ptr %slot489, align 8
  %v3078 = load i64, ptr %slot489, align 8
  %v3079 = load i64, ptr %slot29, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i64 %v3078, ptr %p3080, align 8, !alias.scope !3, !noalias !4
  %v3081 = load i64, ptr %slot26, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %ld3083 = load i64, ptr %p3082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3083, ptr %slot490, align 8
  %v3084 = load i64, ptr %slot27, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  %ld3086 = load i64, ptr %p3085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3086, ptr %slot491, align 8
  %v3087 = load i64, ptr %slot28, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i64, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3089, ptr %slot492, align 8
  %v3090 = load i64, ptr %slot29, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %ld3092 = load i64, ptr %p3091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3092, ptr %slot493, align 8
  %v3093 = load i64, ptr %slot19, align 8
  store i64 %v3093, ptr %slot494, align 8
  %v3094 = load i64, ptr %slot34, align 8
  %v3095 = load i64, ptr %slot494, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  store i64 %v3094, ptr %p3096, align 8, !alias.scope !3, !noalias !4
  %v3097 = load i64, ptr %slot34, align 8
  %p3099 = inttoptr i64 %v3097 to ptr
  %gep3100 = getelementptr i8, ptr %p3099, i64 5640
  %op3098 = ptrtoint ptr %gep3100 to i64
  store i64 %op3098, ptr %slot495, align 8
  %v3101 = load i64, ptr %slot495, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i64, ptr %p3102, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3103, ptr %slot496, align 8
  %v3104 = load i64, ptr %slot496, align 8
  %op3105 = add i64 %v3104, 248
  store i64 %op3105, ptr %slot497, align 8
  %v3106 = load i64, ptr %slot497, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  %ld3108 = load i64, ptr %p3107, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3108, ptr %slot498, align 8
  %v3109 = load i64, ptr %slot494, align 8
  %p3111 = inttoptr i64 %v3109 to ptr
  %gep3112 = getelementptr i8, ptr %p3111, i64 8
  %op3110 = ptrtoint ptr %gep3112 to i64
  store i64 %op3110, ptr %slot499, align 8
  %v3113 = load i64, ptr %slot498, align 8
  %v3114 = load i64, ptr %slot499, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  store i64 %v3113, ptr %p3115, align 8, !alias.scope !3, !noalias !4
  %v3116 = load i64, ptr %slot494, align 8
  %p3118 = inttoptr i64 %v3116 to ptr
  %gep3119 = getelementptr i8, ptr %p3118, i64 16
  %op3117 = ptrtoint ptr %gep3119 to i64
  store i64 %op3117, ptr %slot500, align 8
  %v3120 = load i64, ptr %slot500, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i64 0, ptr %p3121, align 8, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot34, align 8
  %p3124 = inttoptr i64 %v3122 to ptr
  %gep3125 = getelementptr i8, ptr %p3124, i64 112
  %op3123 = ptrtoint ptr %gep3125 to i64
  store i64 %op3123, ptr %slot501, align 8
  %v3126 = load i64, ptr %slot494, align 8
  %p3128 = inttoptr i64 %v3126 to ptr
  %gep3129 = getelementptr i8, ptr %p3128, i64 24
  %op3127 = ptrtoint ptr %gep3129 to i64
  store i64 %op3127, ptr %slot502, align 8
  %v3130 = load i64, ptr %slot494, align 8
  %p3132 = inttoptr i64 %v3130 to ptr
  %gep3133 = getelementptr i8, ptr %p3132, i64 28
  %op3131 = ptrtoint ptr %gep3133 to i64
  store i64 %op3131, ptr %slot503, align 8
  %v3134 = load i64, ptr %slot501, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  %ld3136 = load i32, ptr %p3135, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld3136, ptr %slot504, align 8
  %v3137 = load i64, ptr %slot502, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  store i32 1, ptr %p3138, align 4, !alias.scope !3, !noalias !4
  %v3139 = load i32, ptr %slot504, align 8
  %v3140 = load i64, ptr %slot503, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i32 %v3139, ptr %p3141, align 4, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot494, align 8
  %v3143 = load i64, ptr %slot497, align 8
  %p3144 = inttoptr i64 %v3143 to ptr
  store i64 %v3142, ptr %p3144, align 8, !alias.scope !9999998, !noalias !9999999
  %v3145 = load i64, ptr %slot12, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %ld3147 = load i32, ptr %p3146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3147, ptr %slot505, align 8
  %v3148 = load i32, ptr %slot505, align 8
  %cv3149 = zext i32 %v3148 to i64
  %cond3150 = icmp ne i64 %cv3149, 0
  br i1 %cond3150, label %bb_rcslotdrop608, label %bb_rcslotdone608
bb_rcslotdrop608:
  %v3151 = load i64, ptr %slot12, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i32 0, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot16, align 8
  store i64 %v3153, ptr %slot506, align 8
  %v3154 = load i64, ptr %slot13, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i32, ptr %p3155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3156, ptr %slot507, align 8
  %v3157 = load i32, ptr %slot507, align 8
  %op3158 = and i32 %v3157, 28
  store i32 %op3158, ptr %slot508, align 8
  %v3159 = load i32, ptr %slot508, align 8
  %cv3160 = zext i32 %v3159 to i64
  %cond3161 = icmp ne i64 %cv3160, 0
  br i1 %cond3161, label %bb_rcslotrole608, label %bb_rcslotowner608
bb_rcslotrole608:
  %v3162 = load i64, ptr %slot34, align 8
  store i64 %v3162, ptr %slot509, align 8
  %v3163 = load i64, ptr %slot506, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i64, ptr %p3164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3165, ptr %slot510, align 8
  %v3166 = load i64, ptr %slot510, align 8
  %cmp3167 = icmp ne i64 %v3166, 0
  %cv3168 = zext i1 %cmp3167 to i32
  store i32 %cv3168, ptr %slot511, align 8
  %v3169 = load i32, ptr %slot511, align 8
  %cv3170 = zext i32 %v3169 to i64
  %cond3171 = icmp ne i64 %cv3170, 0
  br i1 %cond3171, label %bb_rcgnn624, label %bb_rcgdone624
bb_rcgnn624:
  %v3172 = load i64, ptr %slot510, align 8
  %op3173 = sub i64 %v3172, 16
  store i64 %op3173, ptr %slot512, align 8
  %v3174 = load i64, ptr %slot510, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %rgep3176 = getelementptr i8, ptr %p3175, i64 -16
  %ld3177 = load i64, ptr %rgep3176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3177, ptr %slot513, align 8
  %v3178 = load i64, ptr %slot513, align 8
  %op3179 = and i64 %v3178, 4611686018427387906
  store i64 %op3179, ptr %slot514, align 8
  %v3180 = load i64, ptr %slot514, align 8
  %cmp3181 = icmp ne i64 %v3180, 0
  %cv3182 = zext i1 %cmp3181 to i32
  store i32 %cv3182, ptr %slot515, align 8
  %v3183 = load i32, ptr %slot515, align 8
  %cv3184 = zext i32 %v3183 to i64
  %cond3185 = icmp ne i64 %cv3184, 0
  br i1 %cond3185, label %bb_rcgclear624, label %bb_rcgcounted624
bb_rcgcounted624:
  %v3186 = load i64, ptr %slot510, align 8
  %op3187 = sub i64 %v3186, 24
  store i64 %op3187, ptr %slot516, align 8
  %v3188 = load i64, ptr %slot510, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %rgep3190 = getelementptr i8, ptr %p3189, i64 -24
  %ld3191 = load i64, ptr %rgep3190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3191, ptr %slot517, align 8
  %v3192 = load i64, ptr %slot517, align 8
  %op3193 = sub i64 %v3192, 1
  store i64 %op3193, ptr %slot518, align 8
  %v3194 = load i64, ptr %slot518, align 8
  %cmp3195 = icmp eq i64 %v3194, 0
  %cv3196 = zext i1 %cmp3195 to i32
  store i32 %cv3196, ptr %slot519, align 8
  %v3197 = load i32, ptr %slot519, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcglast624, label %bb_rcgdec624
bb_rcglast624:
  %v3200 = load i64, ptr %slot510, align 8
  %op3201 = sub i64 %v3200, 32
  store i64 %op3201, ptr %slot520, align 8
  %v3202 = load i64, ptr %slot510, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %rgep3204 = getelementptr i8, ptr %p3203, i64 -32
  %ld3205 = load i64, ptr %rgep3204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3205, ptr %slot521, align 8
  %v3206 = load i64, ptr %slot521, align 8
  %cmp3207 = icmp ne i64 %v3206, 0
  %cv3208 = zext i1 %cmp3207 to i32
  store i32 %cv3208, ptr %slot522, align 8
  %v3209 = load i32, ptr %slot522, align 8
  %cv3210 = zext i32 %v3209 to i64
  %cond3211 = icmp ne i64 %cv3210, 0
  br i1 %cond3211, label %bb_rcgdec624, label %bb_rcgslow624
bb_rcgslow624:
  %v3212 = load i64, ptr %slot509, align 8
  %v3213 = load i64, ptr %slot506, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v3212, i64 %v3213) nomerge, !dbg !126
  br label %bb_rcgdone624
bb_rcgdec624:
  %v3214 = load i64, ptr %slot518, align 8
  %v3215 = load i64, ptr %slot510, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %rgep3217 = getelementptr i8, ptr %p3216, i64 -24
  store i64 %v3214, ptr %rgep3217, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear624
bb_rcgclear624:
  %v3218 = load i64, ptr %slot506, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  store i64 0, ptr %p3219, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone624
bb_rcgdone624:
  br label %bb_rcslotdone608
bb_rcslotowner608:
  %v3220 = load i64, ptr %slot34, align 8
  store i64 %v3220, ptr %slot523, align 8
  %v3221 = load i64, ptr %slot506, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  %ld3223 = load i64, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3223, ptr %slot524, align 8
  %v3224 = load i64, ptr %slot524, align 8
  %cmp3225 = icmp ne i64 %v3224, 0
  %cv3226 = zext i1 %cmp3225 to i32
  store i32 %cv3226, ptr %slot525, align 8
  %v3227 = load i32, ptr %slot525, align 8
  %cv3228 = zext i32 %v3227 to i64
  %cond3229 = icmp ne i64 %cv3228, 0
  br i1 %cond3229, label %bb_rcgnn639, label %bb_rcgdone639
bb_rcgnn639:
  %v3230 = load i64, ptr %slot524, align 8
  %op3231 = sub i64 %v3230, 16
  store i64 %op3231, ptr %slot526, align 8
  %v3232 = load i64, ptr %slot524, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  %rgep3234 = getelementptr i8, ptr %p3233, i64 -16
  %ld3235 = load i64, ptr %rgep3234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3235, ptr %slot527, align 8
  %v3236 = load i64, ptr %slot527, align 8
  %op3237 = and i64 %v3236, 4611686018427387906
  store i64 %op3237, ptr %slot528, align 8
  %v3238 = load i64, ptr %slot528, align 8
  %cmp3239 = icmp ne i64 %v3238, 0
  %cv3240 = zext i1 %cmp3239 to i32
  store i32 %cv3240, ptr %slot529, align 8
  %v3241 = load i32, ptr %slot529, align 8
  %cv3242 = zext i32 %v3241 to i64
  %cond3243 = icmp ne i64 %cv3242, 0
  br i1 %cond3243, label %bb_rcgclear639, label %bb_rcgcounted639
bb_rcgcounted639:
  %v3244 = load i64, ptr %slot524, align 8
  %op3245 = sub i64 %v3244, 32
  store i64 %op3245, ptr %slot530, align 8
  %v3246 = load i64, ptr %slot524, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  %rgep3248 = getelementptr i8, ptr %p3247, i64 -32
  %ld3249 = load i64, ptr %rgep3248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3249, ptr %slot531, align 8
  %v3250 = load i64, ptr %slot531, align 8
  %op3251 = sub i64 %v3250, 1
  store i64 %op3251, ptr %slot532, align 8
  %v3252 = load i64, ptr %slot532, align 8
  %cmp3253 = icmp eq i64 %v3252, 0
  %cv3254 = zext i1 %cmp3253 to i32
  store i32 %cv3254, ptr %slot533, align 8
  %v3255 = load i32, ptr %slot533, align 8
  %cv3256 = zext i32 %v3255 to i64
  %cond3257 = icmp ne i64 %cv3256, 0
  br i1 %cond3257, label %bb_rcglast639, label %bb_rcgdec639
bb_rcglast639:
  %v3258 = load i64, ptr %slot524, align 8
  %op3259 = sub i64 %v3258, 24
  store i64 %op3259, ptr %slot534, align 8
  %v3260 = load i64, ptr %slot524, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  %rgep3262 = getelementptr i8, ptr %p3261, i64 -24
  %ld3263 = load i64, ptr %rgep3262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3263, ptr %slot535, align 8
  %v3264 = load i64, ptr %slot535, align 8
  %cmp3265 = icmp ne i64 %v3264, 0
  %cv3266 = zext i1 %cmp3265 to i32
  store i32 %cv3266, ptr %slot536, align 8
  %v3267 = load i32, ptr %slot536, align 8
  %cv3268 = zext i32 %v3267 to i64
  %cond3269 = icmp ne i64 %cv3268, 0
  br i1 %cond3269, label %bb_rcgdec639, label %bb_rcgslow639
bb_rcgslow639:
  %v3270 = load i64, ptr %slot523, align 8
  %v3271 = load i64, ptr %slot506, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3270, i64 %v3271) nomerge, !dbg !126
  br label %bb_rcgdone639
bb_rcgdec639:
  %v3272 = load i64, ptr %slot532, align 8
  %v3273 = load i64, ptr %slot524, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  %rgep3275 = getelementptr i8, ptr %p3274, i64 -32
  store i64 %v3272, ptr %rgep3275, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear639
bb_rcgclear639:
  %v3276 = load i64, ptr %slot506, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  store i64 0, ptr %p3277, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone639
bb_rcgdone639:
  br label %bb_rcslotdone608
bb_rcslotdone608:
  %v3278 = load i64, ptr %slot25, align 8
  store i64 %v3278, ptr %slot537, align 8
  %v3279 = load i64, ptr %slot11, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  store i32 2, ptr %p3280, align 4, !alias.scope !3, !noalias !4
  %v3281 = load i64, ptr %slot537, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  %ld3283 = load i64, ptr %p3282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3283, ptr %slot538, align 8
  %v3284 = load i64, ptr %slot538, align 8
  %cmp3285 = icmp ne i64 %v3284, 0
  %cv3286 = zext i1 %cmp3285 to i32
  store i32 %cv3286, ptr %slot539, align 8
  %v3287 = load i32, ptr %slot539, align 8
  %cv3288 = zext i32 %v3287 to i64
  %cond3289 = icmp ne i64 %cv3288, 0
  br i1 %cond3289, label %bb_rcguniquenn646, label %bb_rcgunique646
bb_rcguniquenn646:
  %v3290 = load i64, ptr %slot538, align 8
  %op3291 = sub i64 %v3290, 16
  store i64 %op3291, ptr %slot540, align 8
  %v3292 = load i64, ptr %slot538, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %rgep3294 = getelementptr i8, ptr %p3293, i64 -16
  %ld3295 = load i64, ptr %rgep3294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3295, ptr %slot541, align 8
  %v3296 = load i64, ptr %slot541, align 8
  %op3297 = and i64 %v3296, 6917529027641081858
  store i64 %op3297, ptr %slot542, align 8
  %v3298 = load i64, ptr %slot542, align 8
  %cmp3299 = icmp ne i64 %v3298, 0
  %cv3300 = zext i1 %cmp3299 to i32
  store i32 %cv3300, ptr %slot543, align 8
  %v3301 = load i32, ptr %slot543, align 8
  %cv3302 = zext i32 %v3301 to i64
  %cond3303 = icmp ne i64 %cv3302, 0
  br i1 %cond3303, label %bb_rcguniqueslow646, label %bb_rcguniquecount646
bb_rcguniquecount646:
  %v3304 = load i64, ptr %slot538, align 8
  %op3305 = sub i64 %v3304, 32
  store i64 %op3305, ptr %slot544, align 8
  %v3306 = load i64, ptr %slot538, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  %rgep3308 = getelementptr i8, ptr %p3307, i64 -32
  %ld3309 = load i64, ptr %rgep3308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3309, ptr %slot545, align 8
  %v3310 = load i64, ptr %slot545, align 8
  %cmp3311 = icmp ult i64 %v3310, 2
  %cv3312 = zext i1 %cmp3311 to i32
  store i32 %cv3312, ptr %slot546, align 8
  %v3313 = load i32, ptr %slot546, align 8
  %cv3314 = zext i32 %v3313 to i64
  %cond3315 = icmp ne i64 %cv3314, 0
  br i1 %cond3315, label %bb_rcgunique646, label %bb_rcguniqueslow646
bb_rcguniqueslow646:
  %v3316 = load i64, ptr %slot1, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  %p3318 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v3319 = load i64, ptr %slot537, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  %v3321 = load i64, ptr %slot10, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %call3323 = call i32 @myl_qbe_rc_unique_local(ptr %p3317, ptr %p3318, ptr %p3320, ptr %p3322) nomerge, !dbg !126
  store i32 %call3323, ptr %slot547, align 8
  %v3324 = load i32, ptr %slot547, align 8
  %cv3325 = zext i32 %v3324 to i64
  %cond3326 = icmp ne i64 %cv3325, 0
  br i1 %cond3326, label %bb_rcunique657, label %bb_failure
bb_rcunique657:
  br label %bb_rcgunique646
bb_rcgunique646:
  %v3327 = load i64, ptr %slot25, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  %ld3329 = load i64, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3329, ptr %slot548, align 8
  %v3330 = load i64, ptr %slot548, align 8
  %v3331 = load i64, ptr %slot26, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i64 %v3330, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot26, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i64, ptr %p3334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3335, ptr %slot549, align 8
  %v3336 = load i64, ptr %slot549, align 8
  %cmp3337 = icmp ne i64 %v3336, 0
  %cv3338 = zext i1 %cmp3337 to i32
  store i32 %cv3338, ptr %slot550, align 8
  %v3339 = load i32, ptr %slot550, align 8
  %cv3340 = zext i32 %v3339 to i64
  %cond3341 = icmp ne i64 %cv3340, 0
  br i1 %cond3341, label %bb_rcspinmark660, label %bb_rcspindone660
bb_rcspinmark660:
  %v3342 = load i64, ptr %slot549, align 8
  %op3343 = sub i64 %v3342, 16
  store i64 %op3343, ptr %slot551, align 8
  %v3344 = load i64, ptr %slot549, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %rgep3346 = getelementptr i8, ptr %p3345, i64 -16
  %ld3347 = load i64, ptr %rgep3346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3347, ptr %slot552, align 8
  %v3348 = load i64, ptr %slot552, align 8
  %op3349 = and i64 %v3348, 2
  store i64 %op3349, ptr %slot553, align 8
  %v3350 = load i64, ptr %slot553, align 8
  %cmp3351 = icmp ne i64 %v3350, 0
  %cv3352 = zext i1 %cmp3351 to i32
  store i32 %cv3352, ptr %slot554, align 8
  %v3353 = load i32, ptr %slot554, align 8
  %cv3354 = zext i32 %v3353 to i64
  %cond3355 = icmp ne i64 %cv3354, 0
  br i1 %cond3355, label %bb_rcspindone660, label %bb_rcspintype660
bb_rcspintype660:
  %v3356 = load i64, ptr %slot552, align 8
  %op3357 = and i64 %v3356, 4611686018427387907
  store i64 %op3357, ptr %slot555, align 8
  %v3358 = load i64, ptr %slot555, align 8
  %cmp3359 = icmp eq i64 %v3358, 0
  %cv3360 = zext i1 %cmp3359 to i32
  store i32 %cv3360, ptr %slot556, align 8
  %v3361 = load i32, ptr %slot556, align 8
  %cv3362 = zext i32 %v3361 to i64
  %cond3363 = icmp ne i64 %cv3362, 0
  br i1 %cond3363, label %bb_rcs668, label %bb_rcspinslow660
bb_rcs668:
  %v3364 = load i64, ptr %slot549, align 8
  %op3365 = sub i64 %v3364, 8
  store i64 %op3365, ptr %slot557, align 8
  %v3366 = load i64, ptr %slot549, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  %rgep3368 = getelementptr i8, ptr %p3367, i64 -8
  %ld3369 = load i64, ptr %rgep3368, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3369, ptr %slot558, align 8
  %p3370 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld3371 = load i64, ptr %p3370, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3371, ptr %slot559, align 8
  %v3372 = load i64, ptr %slot558, align 8
  %v3373 = load i64, ptr %slot559, align 8
  %cmp3374 = icmp eq i64 %v3372, %v3373
  %cv3375 = zext i1 %cmp3374 to i32
  store i32 %cv3375, ptr %slot560, align 8
  %v3376 = load i32, ptr %slot560, align 8
  %cv3377 = zext i32 %v3376 to i64
  %cond3378 = icmp ne i64 %cv3377, 0
  br i1 %cond3378, label %bb_rcs673, label %bb_rcspinslow660
bb_rcs673:
  %v3379 = load i64, ptr %slot34, align 8
  %p3381 = inttoptr i64 %v3379 to ptr
  %gep3382 = getelementptr i8, ptr %p3381, i64 5640
  %op3380 = ptrtoint ptr %gep3382 to i64
  store i64 %op3380, ptr %slot561, align 8
  %v3383 = load i64, ptr %slot561, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %ld3385 = load i64, ptr %p3384, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3385, ptr %slot562, align 8
  %v3386 = load i64, ptr %slot562, align 8
  %op3387 = add i64 %v3386, 256
  store i64 %op3387, ptr %slot563, align 8
  %v3388 = load i64, ptr %slot563, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  %ld3390 = load i64, ptr %p3389, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3390, ptr %slot564, align 8
  %v3391 = load i64, ptr %slot564, align 8
  %cmp3392 = icmp ne i64 %v3391, 0
  %cv3393 = zext i1 %cmp3392 to i32
  store i32 %cv3393, ptr %slot565, align 8
  %v3394 = load i32, ptr %slot565, align 8
  %cv3395 = zext i32 %v3394 to i64
  %cond3396 = icmp ne i64 %cv3395, 0
  br i1 %cond3396, label %bb_rcs679, label %bb_rcspinslow660
bb_rcs679:
  %v3397 = load i64, ptr %slot34, align 8
  %p3399 = inttoptr i64 %v3397 to ptr
  %gep3400 = getelementptr i8, ptr %p3399, i64 24
  %op3398 = ptrtoint ptr %gep3400 to i64
  store i64 %op3398, ptr %slot566, align 8
  %v3401 = load i64, ptr %slot566, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  %ld3403 = load i64, ptr %p3402, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3403, ptr %slot567, align 8
  %v3404 = load i64, ptr %slot567, align 8
  %op3405 = add i64 %v3404, 40
  store i64 %op3405, ptr %slot568, align 8
  %v3406 = load i64, ptr %slot568, align 8
  %v3407 = load i64, ptr %slot567, align 8
  %cmp3408 = icmp uge i64 %v3406, %v3407
  %cv3409 = zext i1 %cmp3408 to i32
  store i32 %cv3409, ptr %slot569, align 8
  %v3410 = load i32, ptr %slot569, align 8
  %cv3411 = zext i32 %v3410 to i64
  %cond3412 = icmp ne i64 %cv3411, 0
  br i1 %cond3412, label %bb_rcs684, label %bb_rcspinslow660
bb_rcs684:
  %v3413 = load i64, ptr %slot34, align 8
  %p3415 = inttoptr i64 %v3413 to ptr
  %gep3416 = getelementptr i8, ptr %p3415, i64 88
  %op3414 = ptrtoint ptr %gep3416 to i64
  store i64 %op3414, ptr %slot570, align 8
  %v3417 = load i64, ptr %slot570, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  %ld3419 = load i64, ptr %p3418, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3419, ptr %slot571, align 8
  %v3420 = load i64, ptr %slot571, align 8
  %cmp3421 = icmp eq i64 %v3420, 0
  %cv3422 = zext i1 %cmp3421 to i32
  store i32 %cv3422, ptr %slot572, align 8
  %v3423 = load i64, ptr %slot568, align 8
  %v3424 = load i64, ptr %slot571, align 8
  %cmp3425 = icmp ule i64 %v3423, %v3424
  %cv3426 = zext i1 %cmp3425 to i32
  store i32 %cv3426, ptr %slot573, align 8
  %v3427 = load i32, ptr %slot572, align 8
  %v3428 = load i32, ptr %slot573, align 8
  %op3429 = or i32 %v3427, %v3428
  store i32 %op3429, ptr %slot574, align 8
  %v3430 = load i32, ptr %slot574, align 8
  %cv3431 = zext i32 %v3430 to i64
  %cond3432 = icmp ne i64 %cv3431, 0
  br i1 %cond3432, label %bb_rcs690, label %bb_rcspinslow660
bb_rcs690:
  %v3433 = load i64, ptr %slot549, align 8
  %op3434 = sub i64 %v3433, 24
  store i64 %op3434, ptr %slot575, align 8
  %v3435 = load i64, ptr %slot549, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %rgep3437 = getelementptr i8, ptr %p3436, i64 -24
  %ld3438 = load i64, ptr %rgep3437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3438, ptr %slot576, align 8
  %v3439 = load i64, ptr %slot576, align 8
  %cmp3440 = icmp ne i64 %v3439, 18446744073709551615
  %cv3441 = zext i1 %cmp3440 to i32
  store i32 %cv3441, ptr %slot577, align 8
  %v3442 = load i32, ptr %slot577, align 8
  %cv3443 = zext i32 %v3442 to i64
  %cond3444 = icmp ne i64 %cv3443, 0
  br i1 %cond3444, label %bb_rcs694, label %bb_rcspinslow660
bb_rcs694:
  %v3445 = load i64, ptr %slot549, align 8
  %op3446 = add i64 %v3445, 32
  store i64 %op3446, ptr %slot578, align 8
  %v3447 = load i64, ptr %slot578, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  %ld3449 = load i64, ptr %p3448, align 8
  store i64 %ld3449, ptr %slot579, align 8
  %v3450 = load i64, ptr %slot579, align 8
  %cmp3451 = icmp ne i64 %v3450, 0
  %cv3452 = zext i1 %cmp3451 to i32
  store i32 %cv3452, ptr %slot580, align 8
  %v3453 = load i32, ptr %slot580, align 8
  %cv3454 = zext i32 %v3453 to i64
  %cond3455 = icmp ne i64 %cv3454, 0
  br i1 %cond3455, label %bb_rcspinbacking660, label %bb_rcspincommit660
bb_rcspinbacking660:
  %v3456 = load i64, ptr %slot579, align 8
  %op3457 = sub i64 %v3456, 16
  store i64 %op3457, ptr %slot581, align 8
  %v3458 = load i64, ptr %slot579, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %rgep3460 = getelementptr i8, ptr %p3459, i64 -16
  %ld3461 = load i64, ptr %rgep3460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3461, ptr %slot582, align 8
  %v3462 = load i64, ptr %slot582, align 8
  %op3463 = and i64 %v3462, 4611686018427387907
  store i64 %op3463, ptr %slot583, align 8
  %v3464 = load i64, ptr %slot583, align 8
  %cmp3465 = icmp eq i64 %v3464, 0
  %cv3466 = zext i1 %cmp3465 to i32
  store i32 %cv3466, ptr %slot584, align 8
  %v3467 = load i32, ptr %slot584, align 8
  %cv3468 = zext i32 %v3467 to i64
  %cond3469 = icmp ne i64 %cv3468, 0
  br i1 %cond3469, label %bb_rcs702, label %bb_rcspinslow660
bb_rcs702:
  %v3470 = load i64, ptr %slot579, align 8
  %op3471 = sub i64 %v3470, 24
  store i64 %op3471, ptr %slot585, align 8
  %v3472 = load i64, ptr %slot579, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %rgep3474 = getelementptr i8, ptr %p3473, i64 -24
  %ld3475 = load i64, ptr %rgep3474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3475, ptr %slot586, align 8
  %v3476 = load i64, ptr %slot586, align 8
  %cmp3477 = icmp ne i64 %v3476, 18446744073709551615
  %cv3478 = zext i1 %cmp3477 to i32
  store i32 %cv3478, ptr %slot587, align 8
  %v3479 = load i32, ptr %slot587, align 8
  %cv3480 = zext i32 %v3479 to i64
  %cond3481 = icmp ne i64 %cv3480, 0
  br i1 %cond3481, label %bb_rcs706, label %bb_rcspinslow660
bb_rcs706:
  br label %bb_rcspincommit660
bb_rcspincommit660:
  %v3482 = load i64, ptr %slot564, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i64, ptr %p3483, align 8
  store i64 %ld3484, ptr %slot588, align 8
  %v3485 = load i64, ptr %slot562, align 8
  %op3486 = add i64 %v3485, 256
  store i64 %op3486, ptr %slot589, align 8
  %v3487 = load i64, ptr %slot588, align 8
  %v3488 = load i64, ptr %slot589, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i64 %v3487, ptr %p3489, align 8, !alias.scope !9999998, !noalias !9999999
  %v3490 = load i64, ptr %slot562, align 8
  %op3491 = add i64 %v3490, 264
  store i64 %op3491, ptr %slot590, align 8
  %v3492 = load i64, ptr %slot590, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  %ld3494 = load i64, ptr %p3493, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3494, ptr %slot591, align 8
  %v3495 = load i64, ptr %slot591, align 8
  %op3496 = add i64 %v3495, 18446744073709551615
  store i64 %op3496, ptr %slot592, align 8
  %v3497 = load i64, ptr %slot592, align 8
  %v3498 = load i64, ptr %slot590, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  store i64 %v3497, ptr %p3499, align 8, !alias.scope !9999998, !noalias !9999999
  %v3500 = load i64, ptr %slot34, align 8
  %p3502 = inttoptr i64 %v3500 to ptr
  %gep3503 = getelementptr i8, ptr %p3502, i64 24
  %op3501 = ptrtoint ptr %gep3503 to i64
  store i64 %op3501, ptr %slot593, align 8
  %v3504 = load i64, ptr %slot593, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i64, ptr %p3505, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3506, ptr %slot594, align 8
  %v3507 = load i64, ptr %slot594, align 8
  %op3508 = add i64 %v3507, 40
  store i64 %op3508, ptr %slot595, align 8
  %v3509 = load i64, ptr %slot595, align 8
  %v3510 = load i64, ptr %slot593, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i64 %v3509, ptr %p3511, align 8, !alias.scope !9999998, !noalias !9999999
  %v3512 = load i64, ptr %slot562, align 8
  %op3513 = add i64 %v3512, 48
  store i64 %op3513, ptr %slot596, align 8
  %v3514 = load i64, ptr %slot596, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  %ld3516 = load i64, ptr %p3515, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3516, ptr %slot597, align 8
  %v3517 = load i64, ptr %slot597, align 8
  %op3518 = add i64 %v3517, 40
  store i64 %op3518, ptr %slot598, align 8
  %v3519 = load i64, ptr %slot598, align 8
  %v3520 = load i64, ptr %slot596, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  store i64 %v3519, ptr %p3521, align 8, !alias.scope !9999998, !noalias !9999999
  %v3522 = load i64, ptr %slot549, align 8
  %op3523 = sub i64 %v3522, 24
  store i64 %op3523, ptr %slot599, align 8
  %v3524 = load i64, ptr %slot549, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  %rgep3526 = getelementptr i8, ptr %p3525, i64 -24
  %ld3527 = load i64, ptr %rgep3526, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3527, ptr %slot600, align 8
  %v3528 = load i64, ptr %slot600, align 8
  %op3529 = add i64 %v3528, 1
  store i64 %op3529, ptr %slot601, align 8
  %v3530 = load i64, ptr %slot601, align 8
  %v3531 = load i64, ptr %slot549, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  %rgep3533 = getelementptr i8, ptr %p3532, i64 -24
  store i64 %v3530, ptr %rgep3533, align 8, !alias.scope !9, !noalias !10
  %v3534 = load i64, ptr %slot579, align 8
  %cmp3535 = icmp ne i64 %v3534, 0
  %cv3536 = zext i1 %cmp3535 to i32
  store i32 %cv3536, ptr %slot602, align 8
  %v3537 = load i32, ptr %slot602, align 8
  %cv3538 = zext i32 %v3537 to i64
  %cond3539 = icmp ne i64 %cv3538, 0
  br i1 %cond3539, label %bb_rcspinhold660, label %bb_rcspinjournal660
bb_rcspinhold660:
  %v3540 = load i64, ptr %slot579, align 8
  %op3541 = sub i64 %v3540, 24
  store i64 %op3541, ptr %slot603, align 8
  %v3542 = load i64, ptr %slot579, align 8
  %p3543 = inttoptr i64 %v3542 to ptr
  %rgep3544 = getelementptr i8, ptr %p3543, i64 -24
  %ld3545 = load i64, ptr %rgep3544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3545, ptr %slot604, align 8
  %v3546 = load i64, ptr %slot604, align 8
  %op3547 = add i64 %v3546, 1
  store i64 %op3547, ptr %slot605, align 8
  %v3548 = load i64, ptr %slot605, align 8
  %v3549 = load i64, ptr %slot579, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %rgep3551 = getelementptr i8, ptr %p3550, i64 -24
  store i64 %v3548, ptr %rgep3551, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal660
bb_rcspinjournal660:
  %v3552 = load i64, ptr %slot552, align 8
  %op3553 = and i64 %v3552, 1152921504606846976
  store i64 %op3553, ptr %slot606, align 8
  %v3554 = load i64, ptr %slot552, align 8
  %op3555 = or i64 %v3554, 1152921504606846976
  store i64 %op3555, ptr %slot607, align 8
  %v3556 = load i64, ptr %slot549, align 8
  %op3557 = sub i64 %v3556, 16
  store i64 %op3557, ptr %slot608, align 8
  %v3558 = load i64, ptr %slot607, align 8
  %v3559 = load i64, ptr %slot549, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  %rgep3561 = getelementptr i8, ptr %p3560, i64 -16
  store i64 %v3558, ptr %rgep3561, align 8, !alias.scope !9, !noalias !10
  %v3562 = load i64, ptr %slot494, align 8
  %p3564 = inttoptr i64 %v3562 to ptr
  %gep3565 = getelementptr i8, ptr %p3564, i64 16
  %op3563 = ptrtoint ptr %gep3565 to i64
  store i64 %op3563, ptr %slot609, align 8
  %v3566 = load i64, ptr %slot609, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %ld3568 = load i64, ptr %p3567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3568, ptr %slot610, align 8
  %v3569 = load i64, ptr %slot564, align 8
  %op3570 = add i64 %v3569, 0
  store i64 %op3570, ptr %slot611, align 8
  %v3571 = load i64, ptr %slot610, align 8
  %v3572 = load i64, ptr %slot611, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i64 %v3571, ptr %p3573, align 8, !alias.scope !9999998, !noalias !9999999
  %v3574 = load i64, ptr %slot564, align 8
  %op3575 = add i64 %v3574, 8
  store i64 %op3575, ptr %slot612, align 8
  %v3576 = load i64, ptr %slot549, align 8
  %v3577 = load i64, ptr %slot612, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  store i64 %v3576, ptr %p3578, align 8, !alias.scope !9999998, !noalias !9999999
  %v3579 = load i64, ptr %slot564, align 8
  %op3580 = add i64 %v3579, 16
  store i64 %op3580, ptr %slot613, align 8
  %v3581 = load i64, ptr %slot606, align 8
  %v3582 = load i64, ptr %slot613, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  store i64 %v3581, ptr %p3583, align 8, !alias.scope !9999998, !noalias !9999999
  %v3584 = load i64, ptr %slot564, align 8
  %op3585 = add i64 %v3584, 24
  store i64 %op3585, ptr %slot614, align 8
  %v3586 = load i64, ptr %slot614, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  store i32 1, ptr %p3587, align 4, !alias.scope !9999998, !noalias !9999999
  %v3588 = load i64, ptr %slot564, align 8
  %op3589 = add i64 %v3588, 32
  store i64 %op3589, ptr %slot615, align 8
  %v3590 = load i64, ptr %slot579, align 8
  %v3591 = load i64, ptr %slot615, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  store i64 %v3590, ptr %p3592, align 8, !alias.scope !9999998, !noalias !9999999
  %v3593 = load i64, ptr %slot494, align 8
  %p3595 = inttoptr i64 %v3593 to ptr
  %gep3596 = getelementptr i8, ptr %p3595, i64 16
  %op3594 = ptrtoint ptr %gep3596 to i64
  store i64 %op3594, ptr %slot616, align 8
  %v3597 = load i64, ptr %slot564, align 8
  %v3598 = load i64, ptr %slot616, align 8
  %p3599 = inttoptr i64 %v3598 to ptr
  store i64 %v3597, ptr %p3599, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone660
bb_rcspinslow660:
  %v3600 = load i64, ptr %slot1, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %v3602 = load i64, ptr %slot494, align 8
  %p3603 = inttoptr i64 %v3602 to ptr
  %v3604 = load i64, ptr %slot549, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  %call3606 = call i32 @myl_qbe_rc_scope_pin(ptr %p3601, ptr %p3603, ptr %p3605) nomerge, !dbg !126
  store i32 %call3606, ptr %slot617, align 8
  %v3607 = load i32, ptr %slot617, align 8
  %cv3608 = zext i32 %v3607 to i64
  %cond3609 = icmp ne i64 %cv3608, 0
  br i1 %cond3609, label %bb_rcunique737, label %bb_failure
bb_rcunique737:
  br label %bb_rcspindone660
bb_rcspindone660:
  %v3610 = load i64, ptr %slot1, align 8
  %v3611 = load i64, ptr %slot549, align 8
  %v3612 = load i64, ptr %slot491, align 8
  %v3613 = load i64, ptr %slot492, align 8
  %v3614 = load i64, ptr %slot493, align 8
  %call3615 = call i64 @myl_f_2024d487f7864351abc7d15d971065e0526631795088f3dd3ec8df6fc11f6bf3(i64 %v3610, i64 %v3611, i64 %v3612, i64 %v3613, i64 %v3614) nomerge, !dbg !126
  store i64 %call3615, ptr %slot618, align 8
  %v3616 = load i64, ptr %slot494, align 8
  %p3618 = inttoptr i64 %v3616 to ptr
  %gep3619 = getelementptr i8, ptr %p3618, i64 24
  %op3617 = ptrtoint ptr %gep3619 to i64
  store i64 %op3617, ptr %slot619, align 8
  %v3620 = load i64, ptr %slot619, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot620, align 8
  %v3623 = load i32, ptr %slot620, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcsendactive739, label %bb_rcsenddone739
bb_rcsendactive739:
  %v3626 = load i64, ptr %slot34, align 8
  %p3628 = inttoptr i64 %v3626 to ptr
  %gep3629 = getelementptr i8, ptr %p3628, i64 5640
  %op3627 = ptrtoint ptr %gep3629 to i64
  store i64 %op3627, ptr %slot621, align 8
  %v3630 = load i64, ptr %slot621, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  %ld3632 = load i64, ptr %p3631, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3632, ptr %slot622, align 8
  %v3633 = load i64, ptr %slot622, align 8
  %op3634 = add i64 %v3633, 248
  store i64 %op3634, ptr %slot623, align 8
  %v3635 = load i64, ptr %slot623, align 8
  %p3636 = inttoptr i64 %v3635 to ptr
  %ld3637 = load i64, ptr %p3636, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3637, ptr %slot624, align 8
  %v3638 = load i64, ptr %slot624, align 8
  %v3639 = load i64, ptr %slot494, align 8
  %cmp3640 = icmp eq i64 %v3638, %v3639
  %cv3641 = zext i1 %cmp3640 to i32
  store i32 %cv3641, ptr %slot625, align 8
  %v3642 = load i32, ptr %slot625, align 8
  %cv3643 = zext i32 %v3642 to i64
  %cond3644 = icmp ne i64 %cv3643, 0
  br i1 %cond3644, label %bb_rcs747, label %bb_rcsendslow739
bb_rcs747:
  %v3645 = load i64, ptr %slot622, align 8
  %op3646 = add i64 %v3645, 200
  store i64 %op3646, ptr %slot626, align 8
  %v3647 = load i64, ptr %slot626, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %ld3649 = load i64, ptr %p3648, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3649, ptr %slot627, align 8
  %v3650 = load i64, ptr %slot627, align 8
  %cmp3651 = icmp eq i64 %v3650, 0
  %cv3652 = zext i1 %cmp3651 to i32
  store i32 %cv3652, ptr %slot628, align 8
  %v3653 = load i32, ptr %slot628, align 8
  %cv3654 = zext i32 %v3653 to i64
  %cond3655 = icmp ne i64 %cv3654, 0
  br i1 %cond3655, label %bb_rcs751, label %bb_rcsendslow739
bb_rcs751:
  %v3656 = load i64, ptr %slot494, align 8
  %p3658 = inttoptr i64 %v3656 to ptr
  %gep3659 = getelementptr i8, ptr %p3658, i64 16
  %op3657 = ptrtoint ptr %gep3659 to i64
  store i64 %op3657, ptr %slot629, align 8
  %v3660 = load i64, ptr %slot629, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  %ld3662 = load i64, ptr %p3661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3662, ptr %slot630, align 8
  %v3663 = load i64, ptr %slot630, align 8
  %cmp3664 = icmp ne i64 %v3663, 0
  %cv3665 = zext i1 %cmp3664 to i32
  store i32 %cv3665, ptr %slot631, align 8
  %v3666 = load i32, ptr %slot631, align 8
  %cv3667 = zext i32 %v3666 to i64
  %cond3668 = icmp ne i64 %cv3667, 0
  br i1 %cond3668, label %bb_rcsendnode739, label %bb_rcsendunlink739
bb_rcsendnode739:
  %v3669 = load i64, ptr %slot630, align 8
  %op3670 = add i64 %v3669, 0
  store i64 %op3670, ptr %slot632, align 8
  %v3671 = load i64, ptr %slot632, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  %ld3673 = load i64, ptr %p3672, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3673, ptr %slot633, align 8
  %v3674 = load i64, ptr %slot633, align 8
  %cmp3675 = icmp eq i64 %v3674, 0
  %cv3676 = zext i1 %cmp3675 to i32
  store i32 %cv3676, ptr %slot634, align 8
  %v3677 = load i32, ptr %slot634, align 8
  %cv3678 = zext i32 %v3677 to i64
  %cond3679 = icmp ne i64 %cv3678, 0
  br i1 %cond3679, label %bb_rcs758, label %bb_rcsendslow739
bb_rcs758:
  %v3680 = load i64, ptr %slot622, align 8
  %op3681 = add i64 %v3680, 264
  store i64 %op3681, ptr %slot635, align 8
  %v3682 = load i64, ptr %slot635, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  %ld3684 = load i64, ptr %p3683, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3684, ptr %slot636, align 8
  %v3685 = load i64, ptr %slot636, align 8
  %cmp3686 = icmp ult i64 %v3685, 32
  %cv3687 = zext i1 %cmp3686 to i32
  store i32 %cv3687, ptr %slot637, align 8
  %v3688 = load i32, ptr %slot637, align 8
  %cv3689 = zext i32 %v3688 to i64
  %cond3690 = icmp ne i64 %cv3689, 0
  br i1 %cond3690, label %bb_rcs762, label %bb_rcsendslow739
bb_rcs762:
  %v3691 = load i64, ptr %slot630, align 8
  %op3692 = add i64 %v3691, 8
  store i64 %op3692, ptr %slot638, align 8
  %v3693 = load i64, ptr %slot638, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  %ld3695 = load i64, ptr %p3694, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3695, ptr %slot639, align 8
  %v3696 = load i64, ptr %slot639, align 8
  %cmp3697 = icmp ne i64 %v3696, 0
  %cv3698 = zext i1 %cmp3697 to i32
  store i32 %cv3698, ptr %slot640, align 8
  %v3699 = load i32, ptr %slot640, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcs766, label %bb_rcsendslow739
bb_rcs766:
  %v3702 = load i64, ptr %slot639, align 8
  %op3703 = sub i64 %v3702, 16
  store i64 %op3703, ptr %slot641, align 8
  %v3704 = load i64, ptr %slot639, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %rgep3706 = getelementptr i8, ptr %p3705, i64 -16
  %ld3707 = load i64, ptr %rgep3706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3707, ptr %slot642, align 8
  %v3708 = load i64, ptr %slot642, align 8
  %op3709 = and i64 %v3708, 4611686018427387907
  store i64 %op3709, ptr %slot643, align 8
  %v3710 = load i64, ptr %slot643, align 8
  %cmp3711 = icmp eq i64 %v3710, 0
  %cv3712 = zext i1 %cmp3711 to i32
  store i32 %cv3712, ptr %slot644, align 8
  %v3713 = load i32, ptr %slot644, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcs771, label %bb_rcsendslow739
bb_rcs771:
  %v3716 = load i64, ptr %slot639, align 8
  %op3717 = sub i64 %v3716, 24
  store i64 %op3717, ptr %slot645, align 8
  %v3718 = load i64, ptr %slot639, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %rgep3720 = getelementptr i8, ptr %p3719, i64 -24
  %ld3721 = load i64, ptr %rgep3720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3721, ptr %slot646, align 8
  %v3722 = load i64, ptr %slot646, align 8
  %cmp3723 = icmp ne i64 %v3722, 0
  %cv3724 = zext i1 %cmp3723 to i32
  store i32 %cv3724, ptr %slot647, align 8
  %v3725 = load i32, ptr %slot647, align 8
  %cv3726 = zext i32 %v3725 to i64
  %cond3727 = icmp ne i64 %cv3726, 0
  br i1 %cond3727, label %bb_rcs775, label %bb_rcsendslow739
bb_rcs775:
  %v3728 = load i64, ptr %slot639, align 8
  %op3729 = sub i64 %v3728, 32
  store i64 %op3729, ptr %slot648, align 8
  %v3730 = load i64, ptr %slot639, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %rgep3732 = getelementptr i8, ptr %p3731, i64 -32
  %ld3733 = load i64, ptr %rgep3732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3733, ptr %slot649, align 8
  %v3734 = load i64, ptr %slot646, align 8
  %cmp3735 = icmp ugt i64 %v3734, 1
  %cv3736 = zext i1 %cmp3735 to i32
  store i32 %cv3736, ptr %slot650, align 8
  %v3737 = load i64, ptr %slot649, align 8
  %cmp3738 = icmp ne i64 %v3737, 0
  %cv3739 = zext i1 %cmp3738 to i32
  store i32 %cv3739, ptr %slot651, align 8
  %v3740 = load i32, ptr %slot650, align 8
  %v3741 = load i32, ptr %slot651, align 8
  %op3742 = or i32 %v3740, %v3741
  store i32 %op3742, ptr %slot652, align 8
  %v3743 = load i32, ptr %slot652, align 8
  %cv3744 = zext i32 %v3743 to i64
  %cond3745 = icmp ne i64 %cv3744, 0
  br i1 %cond3745, label %bb_rcs781, label %bb_rcsendslow739
bb_rcs781:
  %v3746 = load i64, ptr %slot630, align 8
  %op3747 = add i64 %v3746, 32
  store i64 %op3747, ptr %slot653, align 8
  %v3748 = load i64, ptr %slot653, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %ld3750 = load i64, ptr %p3749, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3750, ptr %slot654, align 8
  %v3751 = load i64, ptr %slot654, align 8
  %cmp3752 = icmp ne i64 %v3751, 0
  %cv3753 = zext i1 %cmp3752 to i32
  store i32 %cv3753, ptr %slot655, align 8
  %v3754 = load i32, ptr %slot655, align 8
  %cv3755 = zext i32 %v3754 to i64
  %cond3756 = icmp ne i64 %cv3755, 0
  br i1 %cond3756, label %bb_rcsendbacking739, label %bb_rcsendcommit739
bb_rcsendbacking739:
  %v3757 = load i64, ptr %slot654, align 8
  %op3758 = sub i64 %v3757, 16
  store i64 %op3758, ptr %slot656, align 8
  %v3759 = load i64, ptr %slot654, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %rgep3761 = getelementptr i8, ptr %p3760, i64 -16
  %ld3762 = load i64, ptr %rgep3761, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3762, ptr %slot657, align 8
  %v3763 = load i64, ptr %slot657, align 8
  %op3764 = and i64 %v3763, 4611686018427387907
  store i64 %op3764, ptr %slot658, align 8
  %v3765 = load i64, ptr %slot658, align 8
  %cmp3766 = icmp eq i64 %v3765, 0
  %cv3767 = zext i1 %cmp3766 to i32
  store i32 %cv3767, ptr %slot659, align 8
  %v3768 = load i32, ptr %slot659, align 8
  %cv3769 = zext i32 %v3768 to i64
  %cond3770 = icmp ne i64 %cv3769, 0
  br i1 %cond3770, label %bb_rcs789, label %bb_rcsendslow739
bb_rcs789:
  %v3771 = load i64, ptr %slot654, align 8
  %op3772 = sub i64 %v3771, 24
  store i64 %op3772, ptr %slot660, align 8
  %v3773 = load i64, ptr %slot654, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  %rgep3775 = getelementptr i8, ptr %p3774, i64 -24
  %ld3776 = load i64, ptr %rgep3775, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3776, ptr %slot661, align 8
  %v3777 = load i64, ptr %slot661, align 8
  %cmp3778 = icmp ne i64 %v3777, 0
  %cv3779 = zext i1 %cmp3778 to i32
  store i32 %cv3779, ptr %slot662, align 8
  %v3780 = load i32, ptr %slot662, align 8
  %cv3781 = zext i32 %v3780 to i64
  %cond3782 = icmp ne i64 %cv3781, 0
  br i1 %cond3782, label %bb_rcs793, label %bb_rcsendslow739
bb_rcs793:
  %v3783 = load i64, ptr %slot654, align 8
  %op3784 = sub i64 %v3783, 32
  store i64 %op3784, ptr %slot663, align 8
  %v3785 = load i64, ptr %slot654, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %rgep3787 = getelementptr i8, ptr %p3786, i64 -32
  %ld3788 = load i64, ptr %rgep3787, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3788, ptr %slot664, align 8
  %v3789 = load i64, ptr %slot661, align 8
  %cmp3790 = icmp ugt i64 %v3789, 1
  %cv3791 = zext i1 %cmp3790 to i32
  store i32 %cv3791, ptr %slot665, align 8
  %v3792 = load i64, ptr %slot664, align 8
  %cmp3793 = icmp ne i64 %v3792, 0
  %cv3794 = zext i1 %cmp3793 to i32
  store i32 %cv3794, ptr %slot666, align 8
  %v3795 = load i32, ptr %slot665, align 8
  %v3796 = load i32, ptr %slot666, align 8
  %op3797 = or i32 %v3795, %v3796
  store i32 %op3797, ptr %slot667, align 8
  %v3798 = load i32, ptr %slot667, align 8
  %cv3799 = zext i32 %v3798 to i64
  %cond3800 = icmp ne i64 %cv3799, 0
  br i1 %cond3800, label %bb_rcs799, label %bb_rcsendslow739
bb_rcs799:
  br label %bb_rcsendcommit739
bb_rcsendcommit739:
  %v3801 = load i64, ptr %slot630, align 8
  %op3802 = add i64 %v3801, 24
  store i64 %op3802, ptr %slot668, align 8
  %v3803 = load i64, ptr %slot668, align 8
  %p3804 = inttoptr i64 %v3803 to ptr
  %ld3805 = load i32, ptr %p3804, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld3805, ptr %slot669, align 8
  %v3806 = load i32, ptr %slot669, align 8
  %cv3807 = zext i32 %v3806 to i64
  %cond3808 = icmp ne i64 %cv3807, 0
  br i1 %cond3808, label %bb_rcsendrestore739, label %bb_rcsendreturned739
bb_rcsendrestore739:
  %v3809 = load i64, ptr %slot630, align 8
  %op3810 = add i64 %v3809, 16
  store i64 %op3810, ptr %slot670, align 8
  %v3811 = load i64, ptr %slot670, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  %ld3813 = load i64, ptr %p3812, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3813, ptr %slot671, align 8
  %v3814 = load i64, ptr %slot642, align 8
  %op3815 = and i64 %v3814, 17293822569102704639
  store i64 %op3815, ptr %slot672, align 8
  %v3816 = load i64, ptr %slot672, align 8
  %v3817 = load i64, ptr %slot671, align 8
  %op3818 = or i64 %v3816, %v3817
  store i64 %op3818, ptr %slot673, align 8
  %v3819 = load i64, ptr %slot639, align 8
  %op3820 = sub i64 %v3819, 16
  store i64 %op3820, ptr %slot674, align 8
  %v3821 = load i64, ptr %slot673, align 8
  %v3822 = load i64, ptr %slot639, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %rgep3824 = getelementptr i8, ptr %p3823, i64 -16
  store i64 %v3821, ptr %rgep3824, align 8, !alias.scope !9, !noalias !10
  %v3825 = load i64, ptr %slot494, align 8
  %p3827 = inttoptr i64 %v3825 to ptr
  %gep3828 = getelementptr i8, ptr %p3827, i64 16
  %op3826 = ptrtoint ptr %gep3828 to i64
  store i64 %op3826, ptr %slot675, align 8
  br label %bb_rcsendreturned739
bb_rcsendreturned739:
  %v3829 = load i64, ptr %slot675, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i64 0, ptr %p3830, align 8, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot622, align 8
  %op3832 = add i64 %v3831, 256
  store i64 %op3832, ptr %slot676, align 8
  %v3833 = load i64, ptr %slot676, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %ld3835 = load i64, ptr %p3834, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3835, ptr %slot677, align 8
  %v3836 = load i64, ptr %slot630, align 8
  %op3837 = add i64 %v3836, 0
  store i64 %op3837, ptr %slot678, align 8
  %v3838 = load i64, ptr %slot677, align 8
  %v3839 = load i64, ptr %slot678, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  store i64 %v3838, ptr %p3840, align 8, !alias.scope !9999998, !noalias !9999999
  %v3841 = load i64, ptr %slot622, align 8
  %op3842 = add i64 %v3841, 256
  store i64 %op3842, ptr %slot679, align 8
  %v3843 = load i64, ptr %slot630, align 8
  %v3844 = load i64, ptr %slot679, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  store i64 %v3843, ptr %p3845, align 8, !alias.scope !9999998, !noalias !9999999
  %v3846 = load i64, ptr %slot622, align 8
  %op3847 = add i64 %v3846, 264
  store i64 %op3847, ptr %slot680, align 8
  %v3848 = load i64, ptr %slot680, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %ld3850 = load i64, ptr %p3849, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3850, ptr %slot681, align 8
  %v3851 = load i64, ptr %slot681, align 8
  %op3852 = add i64 %v3851, 1
  store i64 %op3852, ptr %slot682, align 8
  %v3853 = load i64, ptr %slot682, align 8
  %v3854 = load i64, ptr %slot680, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  store i64 %v3853, ptr %p3855, align 8, !alias.scope !9999998, !noalias !9999999
  %v3856 = load i64, ptr %slot34, align 8
  %p3858 = inttoptr i64 %v3856 to ptr
  %gep3859 = getelementptr i8, ptr %p3858, i64 24
  %op3857 = ptrtoint ptr %gep3859 to i64
  store i64 %op3857, ptr %slot683, align 8
  %v3860 = load i64, ptr %slot683, align 8
  %p3861 = inttoptr i64 %v3860 to ptr
  %ld3862 = load i64, ptr %p3861, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3862, ptr %slot684, align 8
  %v3863 = load i64, ptr %slot684, align 8
  %op3864 = add i64 %v3863, 18446744073709551576
  store i64 %op3864, ptr %slot685, align 8
  %v3865 = load i64, ptr %slot685, align 8
  %v3866 = load i64, ptr %slot683, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  store i64 %v3865, ptr %p3867, align 8, !alias.scope !9999998, !noalias !9999999
  %v3868 = load i64, ptr %slot622, align 8
  %op3869 = add i64 %v3868, 48
  store i64 %op3869, ptr %slot686, align 8
  %v3870 = load i64, ptr %slot686, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  %ld3872 = load i64, ptr %p3871, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3872, ptr %slot687, align 8
  %v3873 = load i64, ptr %slot687, align 8
  %op3874 = add i64 %v3873, 18446744073709551576
  store i64 %op3874, ptr %slot688, align 8
  %v3875 = load i64, ptr %slot688, align 8
  %v3876 = load i64, ptr %slot686, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  store i64 %v3875, ptr %p3877, align 8, !alias.scope !9999998, !noalias !9999999
  %v3878 = load i64, ptr %slot654, align 8
  %cmp3879 = icmp ne i64 %v3878, 0
  %cv3880 = zext i1 %cmp3879 to i32
  store i32 %cv3880, ptr %slot689, align 8
  %v3881 = load i32, ptr %slot689, align 8
  %cv3882 = zext i32 %v3881 to i64
  %cond3883 = icmp ne i64 %cv3882, 0
  br i1 %cond3883, label %bb_rcsenddropbacking739, label %bb_rcsenddroppayload739
bb_rcsenddropbacking739:
  %v3884 = load i64, ptr %slot654, align 8
  %op3885 = sub i64 %v3884, 24
  store i64 %op3885, ptr %slot690, align 8
  %v3886 = load i64, ptr %slot654, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %rgep3888 = getelementptr i8, ptr %p3887, i64 -24
  %ld3889 = load i64, ptr %rgep3888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3889, ptr %slot691, align 8
  %v3890 = load i64, ptr %slot691, align 8
  %op3891 = add i64 %v3890, 18446744073709551615
  store i64 %op3891, ptr %slot692, align 8
  %v3892 = load i64, ptr %slot692, align 8
  %v3893 = load i64, ptr %slot654, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  %rgep3895 = getelementptr i8, ptr %p3894, i64 -24
  store i64 %v3892, ptr %rgep3895, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload739
bb_rcsenddroppayload739:
  %v3896 = load i64, ptr %slot639, align 8
  %op3897 = sub i64 %v3896, 24
  store i64 %op3897, ptr %slot693, align 8
  %v3898 = load i64, ptr %slot639, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %rgep3900 = getelementptr i8, ptr %p3899, i64 -24
  %ld3901 = load i64, ptr %rgep3900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3901, ptr %slot694, align 8
  %v3902 = load i64, ptr %slot694, align 8
  %op3903 = add i64 %v3902, 18446744073709551615
  store i64 %op3903, ptr %slot695, align 8
  %v3904 = load i64, ptr %slot695, align 8
  %v3905 = load i64, ptr %slot639, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %rgep3907 = getelementptr i8, ptr %p3906, i64 -24
  store i64 %v3904, ptr %rgep3907, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink739
bb_rcsendunlink739:
  %v3908 = load i64, ptr %slot494, align 8
  %p3910 = inttoptr i64 %v3908 to ptr
  %gep3911 = getelementptr i8, ptr %p3910, i64 8
  %op3909 = ptrtoint ptr %gep3911 to i64
  store i64 %op3909, ptr %slot696, align 8
  %v3912 = load i64, ptr %slot696, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i64, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3914, ptr %slot697, align 8
  %v3915 = load i64, ptr %slot622, align 8
  %op3916 = add i64 %v3915, 248
  store i64 %op3916, ptr %slot698, align 8
  %v3917 = load i64, ptr %slot697, align 8
  %v3918 = load i64, ptr %slot698, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  store i64 %v3917, ptr %p3919, align 8, !alias.scope !9999998, !noalias !9999999
  %v3920 = load i64, ptr %slot494, align 8
  %p3922 = inttoptr i64 %v3920 to ptr
  %gep3923 = getelementptr i8, ptr %p3922, i64 24
  %op3921 = ptrtoint ptr %gep3923 to i64
  store i64 %op3921, ptr %slot699, align 8
  %v3924 = load i64, ptr %slot494, align 8
  %p3926 = inttoptr i64 %v3924 to ptr
  %gep3927 = getelementptr i8, ptr %p3926, i64 8
  %op3925 = ptrtoint ptr %gep3927 to i64
  store i64 %op3925, ptr %slot700, align 8
  %v3928 = load i64, ptr %slot699, align 8
  %p3929 = inttoptr i64 %v3928 to ptr
  store i32 0, ptr %p3929, align 4, !alias.scope !3, !noalias !4
  %v3930 = load i64, ptr %slot700, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  store i64 0, ptr %p3931, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone739
bb_rcsendslow739:
  %v3932 = load i64, ptr %slot1, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  %v3934 = load i64, ptr %slot494, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p3933, ptr %p3935) nomerge, !dbg !126
  br label %bb_rcsenddone739
bb_rcsenddone739:
  %v3936 = load i64, ptr %slot618, align 8
  %v3937 = load i64, ptr %slot26, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  store i64 %v3936, ptr %p3938, align 8, !alias.scope !3, !noalias !4
  %v3939 = load i64, ptr %slot12, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  %ld3941 = load i32, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3941, ptr %slot701, align 8
  %v3942 = load i32, ptr %slot701, align 8
  %cv3943 = zext i32 %v3942 to i64
  %cond3944 = icmp ne i64 %cv3943, 0
  br i1 %cond3944, label %bb_rcslotdrop835, label %bb_rcslotdone835
bb_rcslotdrop835:
  %v3945 = load i64, ptr %slot12, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  store i32 0, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  %v3947 = load i64, ptr %slot16, align 8
  store i64 %v3947, ptr %slot702, align 8
  %v3948 = load i64, ptr %slot13, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  %ld3950 = load i32, ptr %p3949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3950, ptr %slot703, align 8
  %v3951 = load i32, ptr %slot703, align 8
  %op3952 = and i32 %v3951, 28
  store i32 %op3952, ptr %slot704, align 8
  %v3953 = load i32, ptr %slot704, align 8
  %cv3954 = zext i32 %v3953 to i64
  %cond3955 = icmp ne i64 %cv3954, 0
  br i1 %cond3955, label %bb_rcslotrole835, label %bb_rcslotowner835
bb_rcslotrole835:
  %v3956 = load i64, ptr %slot34, align 8
  store i64 %v3956, ptr %slot705, align 8
  %v3957 = load i64, ptr %slot702, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i64, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3959, ptr %slot706, align 8
  %v3960 = load i64, ptr %slot706, align 8
  %cmp3961 = icmp ne i64 %v3960, 0
  %cv3962 = zext i1 %cmp3961 to i32
  store i32 %cv3962, ptr %slot707, align 8
  %v3963 = load i32, ptr %slot707, align 8
  %cv3964 = zext i32 %v3963 to i64
  %cond3965 = icmp ne i64 %cv3964, 0
  br i1 %cond3965, label %bb_rcgnn851, label %bb_rcgdone851
bb_rcgnn851:
  %v3966 = load i64, ptr %slot706, align 8
  %op3967 = sub i64 %v3966, 16
  store i64 %op3967, ptr %slot708, align 8
  %v3968 = load i64, ptr %slot706, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %rgep3970 = getelementptr i8, ptr %p3969, i64 -16
  %ld3971 = load i64, ptr %rgep3970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3971, ptr %slot709, align 8
  %v3972 = load i64, ptr %slot709, align 8
  %op3973 = and i64 %v3972, 4611686018427387906
  store i64 %op3973, ptr %slot710, align 8
  %v3974 = load i64, ptr %slot710, align 8
  %cmp3975 = icmp ne i64 %v3974, 0
  %cv3976 = zext i1 %cmp3975 to i32
  store i32 %cv3976, ptr %slot711, align 8
  %v3977 = load i32, ptr %slot711, align 8
  %cv3978 = zext i32 %v3977 to i64
  %cond3979 = icmp ne i64 %cv3978, 0
  br i1 %cond3979, label %bb_rcgclear851, label %bb_rcgcounted851
bb_rcgcounted851:
  %v3980 = load i64, ptr %slot706, align 8
  %op3981 = sub i64 %v3980, 24
  store i64 %op3981, ptr %slot712, align 8
  %v3982 = load i64, ptr %slot706, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %rgep3984 = getelementptr i8, ptr %p3983, i64 -24
  %ld3985 = load i64, ptr %rgep3984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3985, ptr %slot713, align 8
  %v3986 = load i64, ptr %slot713, align 8
  %op3987 = sub i64 %v3986, 1
  store i64 %op3987, ptr %slot714, align 8
  %v3988 = load i64, ptr %slot714, align 8
  %cmp3989 = icmp eq i64 %v3988, 0
  %cv3990 = zext i1 %cmp3989 to i32
  store i32 %cv3990, ptr %slot715, align 8
  %v3991 = load i32, ptr %slot715, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcglast851, label %bb_rcgdec851
bb_rcglast851:
  %v3994 = load i64, ptr %slot706, align 8
  %op3995 = sub i64 %v3994, 32
  store i64 %op3995, ptr %slot716, align 8
  %v3996 = load i64, ptr %slot706, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %rgep3998 = getelementptr i8, ptr %p3997, i64 -32
  %ld3999 = load i64, ptr %rgep3998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3999, ptr %slot717, align 8
  %v4000 = load i64, ptr %slot717, align 8
  %cmp4001 = icmp ne i64 %v4000, 0
  %cv4002 = zext i1 %cmp4001 to i32
  store i32 %cv4002, ptr %slot718, align 8
  %v4003 = load i32, ptr %slot718, align 8
  %cv4004 = zext i32 %v4003 to i64
  %cond4005 = icmp ne i64 %cv4004, 0
  br i1 %cond4005, label %bb_rcgdec851, label %bb_rcgslow851
bb_rcgslow851:
  %v4006 = load i64, ptr %slot705, align 8
  %v4007 = load i64, ptr %slot702, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4006, i64 %v4007) nomerge, !dbg !126
  br label %bb_rcgdone851
bb_rcgdec851:
  %v4008 = load i64, ptr %slot714, align 8
  %v4009 = load i64, ptr %slot706, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %rgep4011 = getelementptr i8, ptr %p4010, i64 -24
  store i64 %v4008, ptr %rgep4011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear851
bb_rcgclear851:
  %v4012 = load i64, ptr %slot702, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  store i64 0, ptr %p4013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone851
bb_rcgdone851:
  br label %bb_rcslotdone835
bb_rcslotowner835:
  %v4014 = load i64, ptr %slot34, align 8
  store i64 %v4014, ptr %slot719, align 8
  %v4015 = load i64, ptr %slot702, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  %ld4017 = load i64, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4017, ptr %slot720, align 8
  %v4018 = load i64, ptr %slot720, align 8
  %cmp4019 = icmp ne i64 %v4018, 0
  %cv4020 = zext i1 %cmp4019 to i32
  store i32 %cv4020, ptr %slot721, align 8
  %v4021 = load i32, ptr %slot721, align 8
  %cv4022 = zext i32 %v4021 to i64
  %cond4023 = icmp ne i64 %cv4022, 0
  br i1 %cond4023, label %bb_rcgnn866, label %bb_rcgdone866
bb_rcgnn866:
  %v4024 = load i64, ptr %slot720, align 8
  %op4025 = sub i64 %v4024, 16
  store i64 %op4025, ptr %slot722, align 8
  %v4026 = load i64, ptr %slot720, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  %rgep4028 = getelementptr i8, ptr %p4027, i64 -16
  %ld4029 = load i64, ptr %rgep4028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4029, ptr %slot723, align 8
  %v4030 = load i64, ptr %slot723, align 8
  %op4031 = and i64 %v4030, 4611686018427387906
  store i64 %op4031, ptr %slot724, align 8
  %v4032 = load i64, ptr %slot724, align 8
  %cmp4033 = icmp ne i64 %v4032, 0
  %cv4034 = zext i1 %cmp4033 to i32
  store i32 %cv4034, ptr %slot725, align 8
  %v4035 = load i32, ptr %slot725, align 8
  %cv4036 = zext i32 %v4035 to i64
  %cond4037 = icmp ne i64 %cv4036, 0
  br i1 %cond4037, label %bb_rcgclear866, label %bb_rcgcounted866
bb_rcgcounted866:
  %v4038 = load i64, ptr %slot720, align 8
  %op4039 = sub i64 %v4038, 32
  store i64 %op4039, ptr %slot726, align 8
  %v4040 = load i64, ptr %slot720, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %rgep4042 = getelementptr i8, ptr %p4041, i64 -32
  %ld4043 = load i64, ptr %rgep4042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4043, ptr %slot727, align 8
  %v4044 = load i64, ptr %slot727, align 8
  %op4045 = sub i64 %v4044, 1
  store i64 %op4045, ptr %slot728, align 8
  %v4046 = load i64, ptr %slot728, align 8
  %cmp4047 = icmp eq i64 %v4046, 0
  %cv4048 = zext i1 %cmp4047 to i32
  store i32 %cv4048, ptr %slot729, align 8
  %v4049 = load i32, ptr %slot729, align 8
  %cv4050 = zext i32 %v4049 to i64
  %cond4051 = icmp ne i64 %cv4050, 0
  br i1 %cond4051, label %bb_rcglast866, label %bb_rcgdec866
bb_rcglast866:
  %v4052 = load i64, ptr %slot720, align 8
  %op4053 = sub i64 %v4052, 24
  store i64 %op4053, ptr %slot730, align 8
  %v4054 = load i64, ptr %slot720, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  %rgep4056 = getelementptr i8, ptr %p4055, i64 -24
  %ld4057 = load i64, ptr %rgep4056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4057, ptr %slot731, align 8
  %v4058 = load i64, ptr %slot731, align 8
  %cmp4059 = icmp ne i64 %v4058, 0
  %cv4060 = zext i1 %cmp4059 to i32
  store i32 %cv4060, ptr %slot732, align 8
  %v4061 = load i32, ptr %slot732, align 8
  %cv4062 = zext i32 %v4061 to i64
  %cond4063 = icmp ne i64 %cv4062, 0
  br i1 %cond4063, label %bb_rcgdec866, label %bb_rcgslow866
bb_rcgslow866:
  %v4064 = load i64, ptr %slot719, align 8
  %v4065 = load i64, ptr %slot702, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4064, i64 %v4065) nomerge, !dbg !126
  br label %bb_rcgdone866
bb_rcgdec866:
  %v4066 = load i64, ptr %slot728, align 8
  %v4067 = load i64, ptr %slot720, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  %rgep4069 = getelementptr i8, ptr %p4068, i64 -32
  store i64 %v4066, ptr %rgep4069, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear866
bb_rcgclear866:
  %v4070 = load i64, ptr %slot702, align 8
  %p4071 = inttoptr i64 %v4070 to ptr
  store i64 0, ptr %p4071, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone866
bb_rcgdone866:
  br label %bb_rcslotdone835
bb_rcslotdone835:
  %v4072 = load i64, ptr %slot25, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  %ld4074 = load i64, ptr %p4073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4074, ptr %slot733, align 8
  %v4075 = load i64, ptr %slot733, align 8
  %v4076 = load i64, ptr %slot26, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i64 %v4075, ptr %p4077, align 8, !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot26, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i64, ptr %p4079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4080, ptr %slot734, align 8
  %v4081 = load i64, ptr %slot1, align 8
  %p4082 = inttoptr i64 %v4081 to ptr
  %v4083 = load i64, ptr %slot734, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  %call4085 = call ptr @myl_qbe_bytes_snapshot(ptr %p4082, ptr %p4084) nomerge, !dbg !128
  %calladdr4086 = ptrtoint ptr %call4085 to i64
  store i64 %calladdr4086, ptr %slot735, align 8
  %v4087 = load i64, ptr %slot735, align 8
  %v4088 = load i64, ptr %slot26, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  store i64 %v4087, ptr %p4089, align 8, !alias.scope !3, !noalias !4
  %v4090 = load i64, ptr %slot26, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %ld4092 = load i64, ptr %p4091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4092, ptr %slot736, align 8
  %v4093 = load i64, ptr %slot736, align 8
  %v4094 = load i64, ptr %slot17, align 8
  %p4095 = inttoptr i64 %v4094 to ptr
  store i64 %v4093, ptr %p4095, align 8, !alias.scope !3, !noalias !4
  %v4096 = load i64, ptr %slot17, align 8
  store i64 %v4096, ptr %slot737, align 8
  %v4097 = load i64, ptr %slot18, align 8
  store i64 %v4097, ptr %slot738, align 8
  %v4098 = load i64, ptr %slot737, align 8
  %v4099 = load i64, ptr %slot738, align 8
  %p4100 = inttoptr i64 %v4098 to ptr
  %p4101 = inttoptr i64 %v4099 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4101, ptr %p4100, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4102 = load i64, ptr %slot15, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  store i32 2, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  %v4104 = load i64, ptr %slot14, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  store i32 1, ptr %p4105, align 4, !alias.scope !3, !noalias !4
  %v4106 = load i64, ptr %slot12, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  %ld4108 = load i32, ptr %p4107, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4108, ptr %slot739, align 8
  %v4109 = load i32, ptr %slot739, align 8
  %cv4110 = zext i32 %v4109 to i64
  %cond4111 = icmp ne i64 %cv4110, 0
  br i1 %cond4111, label %bb_rcslotdrop926, label %bb_rcslotdone926
bb_rcslotdrop926:
  %v4112 = load i64, ptr %slot12, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i32 0, ptr %p4113, align 4, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot16, align 8
  store i64 %v4114, ptr %slot740, align 8
  %v4115 = load i64, ptr %slot13, align 8
  %p4116 = inttoptr i64 %v4115 to ptr
  %ld4117 = load i32, ptr %p4116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4117, ptr %slot741, align 8
  %v4118 = load i32, ptr %slot741, align 8
  %op4119 = and i32 %v4118, 28
  store i32 %op4119, ptr %slot742, align 8
  %v4120 = load i32, ptr %slot742, align 8
  %cv4121 = zext i32 %v4120 to i64
  %cond4122 = icmp ne i64 %cv4121, 0
  br i1 %cond4122, label %bb_rcslotrole926, label %bb_rcslotowner926
bb_rcslotrole926:
  %v4123 = load i64, ptr %slot34, align 8
  store i64 %v4123, ptr %slot743, align 8
  %v4124 = load i64, ptr %slot740, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  %ld4126 = load i64, ptr %p4125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4126, ptr %slot744, align 8
  %v4127 = load i64, ptr %slot744, align 8
  %cmp4128 = icmp ne i64 %v4127, 0
  %cv4129 = zext i1 %cmp4128 to i32
  store i32 %cv4129, ptr %slot745, align 8
  %v4130 = load i32, ptr %slot745, align 8
  %cv4131 = zext i32 %v4130 to i64
  %cond4132 = icmp ne i64 %cv4131, 0
  br i1 %cond4132, label %bb_rcgnn942, label %bb_rcgdone942
bb_rcgnn942:
  %v4133 = load i64, ptr %slot744, align 8
  %op4134 = sub i64 %v4133, 16
  store i64 %op4134, ptr %slot746, align 8
  %v4135 = load i64, ptr %slot744, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %rgep4137 = getelementptr i8, ptr %p4136, i64 -16
  %ld4138 = load i64, ptr %rgep4137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4138, ptr %slot747, align 8
  %v4139 = load i64, ptr %slot747, align 8
  %op4140 = and i64 %v4139, 4611686018427387906
  store i64 %op4140, ptr %slot748, align 8
  %v4141 = load i64, ptr %slot748, align 8
  %cmp4142 = icmp ne i64 %v4141, 0
  %cv4143 = zext i1 %cmp4142 to i32
  store i32 %cv4143, ptr %slot749, align 8
  %v4144 = load i32, ptr %slot749, align 8
  %cv4145 = zext i32 %v4144 to i64
  %cond4146 = icmp ne i64 %cv4145, 0
  br i1 %cond4146, label %bb_rcgclear942, label %bb_rcgcounted942
bb_rcgcounted942:
  %v4147 = load i64, ptr %slot744, align 8
  %op4148 = sub i64 %v4147, 24
  store i64 %op4148, ptr %slot750, align 8
  %v4149 = load i64, ptr %slot744, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  %rgep4151 = getelementptr i8, ptr %p4150, i64 -24
  %ld4152 = load i64, ptr %rgep4151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4152, ptr %slot751, align 8
  %v4153 = load i64, ptr %slot751, align 8
  %op4154 = sub i64 %v4153, 1
  store i64 %op4154, ptr %slot752, align 8
  %v4155 = load i64, ptr %slot752, align 8
  %cmp4156 = icmp eq i64 %v4155, 0
  %cv4157 = zext i1 %cmp4156 to i32
  store i32 %cv4157, ptr %slot753, align 8
  %v4158 = load i32, ptr %slot753, align 8
  %cv4159 = zext i32 %v4158 to i64
  %cond4160 = icmp ne i64 %cv4159, 0
  br i1 %cond4160, label %bb_rcglast942, label %bb_rcgdec942
bb_rcglast942:
  %v4161 = load i64, ptr %slot744, align 8
  %op4162 = sub i64 %v4161, 32
  store i64 %op4162, ptr %slot754, align 8
  %v4163 = load i64, ptr %slot744, align 8
  %p4164 = inttoptr i64 %v4163 to ptr
  %rgep4165 = getelementptr i8, ptr %p4164, i64 -32
  %ld4166 = load i64, ptr %rgep4165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4166, ptr %slot755, align 8
  %v4167 = load i64, ptr %slot755, align 8
  %cmp4168 = icmp ne i64 %v4167, 0
  %cv4169 = zext i1 %cmp4168 to i32
  store i32 %cv4169, ptr %slot756, align 8
  %v4170 = load i32, ptr %slot756, align 8
  %cv4171 = zext i32 %v4170 to i64
  %cond4172 = icmp ne i64 %cv4171, 0
  br i1 %cond4172, label %bb_rcgdec942, label %bb_rcgslow942
bb_rcgslow942:
  %v4173 = load i64, ptr %slot743, align 8
  %v4174 = load i64, ptr %slot740, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4173, i64 %v4174) nomerge, !dbg !128
  br label %bb_rcgdone942
bb_rcgdec942:
  %v4175 = load i64, ptr %slot752, align 8
  %v4176 = load i64, ptr %slot744, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  %rgep4178 = getelementptr i8, ptr %p4177, i64 -24
  store i64 %v4175, ptr %rgep4178, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear942
bb_rcgclear942:
  %v4179 = load i64, ptr %slot740, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  store i64 0, ptr %p4180, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone942
bb_rcgdone942:
  br label %bb_rcslotdone926
bb_rcslotowner926:
  %v4181 = load i64, ptr %slot34, align 8
  store i64 %v4181, ptr %slot757, align 8
  %v4182 = load i64, ptr %slot740, align 8
  %p4183 = inttoptr i64 %v4182 to ptr
  %ld4184 = load i64, ptr %p4183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4184, ptr %slot758, align 8
  %v4185 = load i64, ptr %slot758, align 8
  %cmp4186 = icmp ne i64 %v4185, 0
  %cv4187 = zext i1 %cmp4186 to i32
  store i32 %cv4187, ptr %slot759, align 8
  %v4188 = load i32, ptr %slot759, align 8
  %cv4189 = zext i32 %v4188 to i64
  %cond4190 = icmp ne i64 %cv4189, 0
  br i1 %cond4190, label %bb_rcgnn957, label %bb_rcgdone957
bb_rcgnn957:
  %v4191 = load i64, ptr %slot758, align 8
  %op4192 = sub i64 %v4191, 16
  store i64 %op4192, ptr %slot760, align 8
  %v4193 = load i64, ptr %slot758, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  %rgep4195 = getelementptr i8, ptr %p4194, i64 -16
  %ld4196 = load i64, ptr %rgep4195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4196, ptr %slot761, align 8
  %v4197 = load i64, ptr %slot761, align 8
  %op4198 = and i64 %v4197, 4611686018427387906
  store i64 %op4198, ptr %slot762, align 8
  %v4199 = load i64, ptr %slot762, align 8
  %cmp4200 = icmp ne i64 %v4199, 0
  %cv4201 = zext i1 %cmp4200 to i32
  store i32 %cv4201, ptr %slot763, align 8
  %v4202 = load i32, ptr %slot763, align 8
  %cv4203 = zext i32 %v4202 to i64
  %cond4204 = icmp ne i64 %cv4203, 0
  br i1 %cond4204, label %bb_rcgclear957, label %bb_rcgcounted957
bb_rcgcounted957:
  %v4205 = load i64, ptr %slot758, align 8
  %op4206 = sub i64 %v4205, 32
  store i64 %op4206, ptr %slot764, align 8
  %v4207 = load i64, ptr %slot758, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  %rgep4209 = getelementptr i8, ptr %p4208, i64 -32
  %ld4210 = load i64, ptr %rgep4209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4210, ptr %slot765, align 8
  %v4211 = load i64, ptr %slot765, align 8
  %op4212 = sub i64 %v4211, 1
  store i64 %op4212, ptr %slot766, align 8
  %v4213 = load i64, ptr %slot766, align 8
  %cmp4214 = icmp eq i64 %v4213, 0
  %cv4215 = zext i1 %cmp4214 to i32
  store i32 %cv4215, ptr %slot767, align 8
  %v4216 = load i32, ptr %slot767, align 8
  %cv4217 = zext i32 %v4216 to i64
  %cond4218 = icmp ne i64 %cv4217, 0
  br i1 %cond4218, label %bb_rcglast957, label %bb_rcgdec957
bb_rcglast957:
  %v4219 = load i64, ptr %slot758, align 8
  %op4220 = sub i64 %v4219, 24
  store i64 %op4220, ptr %slot768, align 8
  %v4221 = load i64, ptr %slot758, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  %rgep4223 = getelementptr i8, ptr %p4222, i64 -24
  %ld4224 = load i64, ptr %rgep4223, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4224, ptr %slot769, align 8
  %v4225 = load i64, ptr %slot769, align 8
  %cmp4226 = icmp ne i64 %v4225, 0
  %cv4227 = zext i1 %cmp4226 to i32
  store i32 %cv4227, ptr %slot770, align 8
  %v4228 = load i32, ptr %slot770, align 8
  %cv4229 = zext i32 %v4228 to i64
  %cond4230 = icmp ne i64 %cv4229, 0
  br i1 %cond4230, label %bb_rcgdec957, label %bb_rcgslow957
bb_rcgslow957:
  %v4231 = load i64, ptr %slot757, align 8
  %v4232 = load i64, ptr %slot740, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4231, i64 %v4232) nomerge, !dbg !128
  br label %bb_rcgdone957
bb_rcgdec957:
  %v4233 = load i64, ptr %slot766, align 8
  %v4234 = load i64, ptr %slot758, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  %rgep4236 = getelementptr i8, ptr %p4235, i64 -32
  store i64 %v4233, ptr %rgep4236, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear957
bb_rcgclear957:
  %v4237 = load i64, ptr %slot740, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  store i64 0, ptr %p4238, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone957
bb_rcgdone957:
  br label %bb_rcslotdone926
bb_rcslotdone926:
  %v4239 = load i64, ptr %slot16, align 8
  store i64 %v4239, ptr %slot771, align 8
  %v4240 = load i64, ptr %slot18, align 8
  store i64 %v4240, ptr %slot772, align 8
  %v4241 = load i64, ptr %slot772, align 8
  %v4242 = load i64, ptr %slot771, align 8
  %p4243 = inttoptr i64 %v4241 to ptr
  %p4244 = inttoptr i64 %v4242 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4244, ptr %p4243, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4245 = load i64, ptr %slot13, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  store i32 2, ptr %p4246, align 4, !alias.scope !3, !noalias !4
  %v4247 = load i64, ptr %slot15, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %ld4249 = load i32, ptr %p4248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4249, ptr %slot773, align 8
  %v4250 = load i32, ptr %slot773, align 8
  %v4251 = load i64, ptr %slot13, align 8
  %p4252 = inttoptr i64 %v4251 to ptr
  store i32 %v4250, ptr %p4252, align 4, !alias.scope !3, !noalias !4
  %v4253 = load i64, ptr %slot14, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  store i32 0, ptr %p4254, align 4, !alias.scope !3, !noalias !4
  %v4255 = load i64, ptr %slot12, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  store i32 1, ptr %p4256, align 4, !alias.scope !3, !noalias !4
  %v4257 = load i64, ptr %slot771, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  %ld4259 = load i64, ptr %p4258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4259, ptr %slot774, align 8
  %v4260 = load i64, ptr %slot774, align 8
  %v4261 = load i64, ptr %slot26, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  store i64 %v4260, ptr %p4262, align 8, !alias.scope !3, !noalias !4
  %v4263 = load i64, ptr %slot26, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %ld4265 = load i64, ptr %p4264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4265, ptr %slot775, align 8
  %v4266 = load i64, ptr %slot26, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  %ld4268 = load i64, ptr %p4267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4268, ptr %slot776, align 8
  %v4269 = load i64, ptr %slot776, align 8
  %v4270 = load i64, ptr %slot17, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  store i64 %v4269, ptr %p4271, align 8, !alias.scope !3, !noalias !4
  %v4272 = load i64, ptr %slot17, align 8
  store i64 %v4272, ptr %slot777, align 8
  %v4273 = load i64, ptr %slot12, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %ld4275 = load i32, ptr %p4274, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4275, ptr %slot778, align 8
  %v4276 = load i64, ptr %slot13, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  %ld4278 = load i32, ptr %p4277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4278, ptr %slot779, align 8
  %v4279 = load i32, ptr %slot779, align 8
  %op4280 = and i32 %v4279, 24
  store i32 %op4280, ptr %slot779, align 8
  %v4281 = load i32, ptr %slot779, align 8
  %cmp4282 = icmp eq i32 %v4281, 0
  %cv4283 = zext i1 %cmp4282 to i32
  store i32 %cv4283, ptr %slot780, align 8
  %v4284 = load i32, ptr %slot778, align 8
  %v4285 = load i32, ptr %slot780, align 8
  %op4286 = and i32 %v4284, %v4285
  store i32 %op4286, ptr %slot781, align 8
  %v4287 = load i32, ptr %slot781, align 8
  %cv4288 = zext i32 %v4287 to i64
  %cond4289 = icmp ne i64 %cv4288, 0
  br i1 %cond4289, label %bb_rctake973, label %bb_rccopy973
bb_rctake973:
  %v4290 = load i64, ptr %slot18, align 8
  store i64 %v4290, ptr %slot782, align 8
  %v4291 = load i64, ptr %slot35, align 8
  store i64 %v4291, ptr %slot783, align 8
  %v4292 = load i64, ptr %slot777, align 8
  %v4293 = load i64, ptr %slot782, align 8
  %op4294 = sub i64 %v4292, %v4293
  store i64 %op4294, ptr %slot784, align 8
  %v4295 = load i64, ptr %slot782, align 8
  %v4296 = load i64, ptr %slot777, align 8
  %op4297 = sub i64 %v4295, %v4296
  store i64 %op4297, ptr %slot785, align 8
  %v4298 = load i64, ptr %slot784, align 8
  %cmp4299 = icmp ult i64 %v4298, 8
  %cv4300 = zext i1 %cmp4299 to i32
  store i32 %cv4300, ptr %slot786, align 8
  %v4301 = load i64, ptr %slot785, align 8
  %cmp4302 = icmp ult i64 %v4301, 8
  %cv4303 = zext i1 %cmp4302 to i32
  store i32 %cv4303, ptr %slot787, align 8
  %v4304 = load i32, ptr %slot786, align 8
  %v4305 = load i32, ptr %slot787, align 8
  %op4306 = or i32 %v4304, %v4305
  store i32 %op4306, ptr %slot788, align 8
  %v4307 = load i32, ptr %slot788, align 8
  %cv4308 = zext i32 %v4307 to i64
  %cond4309 = icmp ne i64 %cv4308, 0
  br i1 %cond4309, label %bb_rcmoveslow982, label %bb_rcmovecheck982
bb_rcmovecheck982:
  %v4310 = load i64, ptr %slot777, align 8
  %p4312 = inttoptr i64 %v4310 to ptr
  %gep4313 = getelementptr i8, ptr %p4312, i64 0
  %op4311 = ptrtoint ptr %gep4313 to i64
  store i64 %op4311, ptr %slot789, align 8
  %v4314 = load i64, ptr %slot789, align 8
  %p4315 = inttoptr i64 %v4314 to ptr
  %ld4316 = load i64, ptr %p4315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4316, ptr %slot790, align 8
  %v4317 = load i64, ptr %slot790, align 8
  %cmp4318 = icmp ne i64 %v4317, 0
  %cv4319 = zext i1 %cmp4318 to i32
  store i32 %cv4319, ptr %slot791, align 8
  %v4320 = load i32, ptr %slot791, align 8
  %cv4321 = zext i32 %v4320 to i64
  %cond4322 = icmp ne i64 %cv4321, 0
  br i1 %cond4322, label %bb_rcmoveheader990, label %bb_rcmovenext990
bb_rcmoveheader990:
  %v4323 = load i64, ptr %slot790, align 8
  %op4324 = sub i64 %v4323, 16
  store i64 %op4324, ptr %slot792, align 8
  %v4325 = load i64, ptr %slot790, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  %rgep4327 = getelementptr i8, ptr %p4326, i64 -16
  %ld4328 = load i64, ptr %rgep4327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4328, ptr %slot793, align 8
  %v4329 = load i64, ptr %slot793, align 8
  %op4330 = and i64 %v4329, 5764607523034234881
  store i64 %op4330, ptr %slot794, align 8
  %v4331 = load i64, ptr %slot794, align 8
  %cmp4332 = icmp ne i64 %v4331, 0
  %cv4333 = zext i1 %cmp4332 to i32
  store i32 %cv4333, ptr %slot795, align 8
  %v4334 = load i32, ptr %slot795, align 8
  %cv4335 = zext i32 %v4334 to i64
  %cond4336 = icmp ne i64 %cv4335, 0
  br i1 %cond4336, label %bb_rcmoveslow982, label %bb_rcmovenext990
bb_rcmovenext990:
  %v4337 = load i64, ptr %slot777, align 8
  %v4338 = load i64, ptr %slot782, align 8
  %p4339 = inttoptr i64 %v4337 to ptr
  %p4340 = inttoptr i64 %v4338 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4340, ptr %p4339, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4341 = load i64, ptr %slot777, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  store i64 0, ptr %p4342, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved982
bb_rcmoveslow982:
  %v4343 = load i64, ptr %slot34, align 8
  %v4344 = load i64, ptr %slot782, align 8
  %v4345 = load i64, ptr %slot777, align 8
  %v4346 = load i64, ptr %slot783, align 8
  %cv4347 = trunc i64 %v4346 to i32
  %call4348 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v4343, i64 %v4344, i64 %v4345, i32 %cv4347) nomerge, !dbg !130
  store i32 %call4348, ptr %slot796, align 8
  %v4349 = load i32, ptr %slot796, align 8
  %cv4350 = zext i32 %v4349 to i64
  %cond4351 = icmp ne i64 %cv4350, 0
  br i1 %cond4351, label %bb_rcsuccess997, label %bb_rcfailure997
bb_rcfailure997:
  %v4352 = load i64, ptr %slot34, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  %call4354 = call i32 @myl_rc_take_failure(ptr %p4353) nomerge, !dbg !130
  store i32 %call4354, ptr %slot797, align 8
  %v4355 = load i64, ptr %slot1, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  %v4357 = load i32, ptr %slot797, align 8
  %call4358 = call i32 @myl_qbe_rc_status(ptr %p4356, i32 %v4357) nomerge, !dbg !130
  store i32 %call4358, ptr %slot798, align 8
  br label %bb_failure
bb_rcsuccess997:
  br label %bb_rcmoved982
bb_rcmoved982:
  %v4359 = load i64, ptr %slot12, align 8
  %p4360 = inttoptr i64 %v4359 to ptr
  store i32 0, ptr %p4360, align 4, !alias.scope !3, !noalias !4
  %v4361 = load i64, ptr %slot15, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  store i32 2, ptr %p4362, align 4, !alias.scope !3, !noalias !4
  %v4363 = load i64, ptr %slot14, align 8
  %p4364 = inttoptr i64 %v4363 to ptr
  store i32 1, ptr %p4364, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared973
bb_rccopy973:
  %v4365 = load i64, ptr %slot18, align 8
  store i64 %v4365, ptr %slot799, align 8
  %v4366 = load i64, ptr %slot35, align 8
  store i64 %v4366, ptr %slot800, align 8
  %v4367 = load i64, ptr %slot777, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i64, ptr %p4368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4369, ptr %slot801, align 8
  %v4370 = load i64, ptr %slot801, align 8
  %cmp4371 = icmp ne i64 %v4370, 0
  %cv4372 = zext i1 %cmp4371 to i32
  store i32 %cv4372, ptr %slot802, align 8
  %v4373 = load i32, ptr %slot802, align 8
  %cv4374 = zext i32 %v4373 to i64
  %cond4375 = icmp ne i64 %cv4374, 0
  br i1 %cond4375, label %bb_rcgnn1006, label %bb_rcgplain1006
bb_rcgnn1006:
  %v4376 = load i64, ptr %slot801, align 8
  %op4377 = sub i64 %v4376, 16
  store i64 %op4377, ptr %slot803, align 8
  %v4378 = load i64, ptr %slot801, align 8
  %p4379 = inttoptr i64 %v4378 to ptr
  %rgep4380 = getelementptr i8, ptr %p4379, i64 -16
  %ld4381 = load i64, ptr %rgep4380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4381, ptr %slot804, align 8
  %v4382 = load i64, ptr %slot804, align 8
  %op4383 = and i64 %v4382, 4611686018427387906
  store i64 %op4383, ptr %slot805, align 8
  %v4384 = load i64, ptr %slot805, align 8
  %cmp4385 = icmp ne i64 %v4384, 0
  %cv4386 = zext i1 %cmp4385 to i32
  store i32 %cv4386, ptr %slot806, align 8
  %v4387 = load i32, ptr %slot806, align 8
  %cv4388 = zext i32 %v4387 to i64
  %cond4389 = icmp ne i64 %cv4388, 0
  br i1 %cond4389, label %bb_rcgspecial1006, label %bb_rcginc1006
bb_rcginc1006:
  %v4390 = load i64, ptr %slot801, align 8
  %op4391 = sub i64 %v4390, 32
  store i64 %op4391, ptr %slot807, align 8
  %v4392 = load i64, ptr %slot801, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %rgep4394 = getelementptr i8, ptr %p4393, i64 -32
  %ld4395 = load i64, ptr %rgep4394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4395, ptr %slot808, align 8
  %v4396 = load i64, ptr %slot808, align 8
  %op4397 = add i64 %v4396, 1
  store i64 %op4397, ptr %slot809, align 8
  %v4398 = load i64, ptr %slot809, align 8
  %cmp4399 = icmp eq i64 %v4398, 0
  %cv4400 = zext i1 %cmp4399 to i32
  store i32 %cv4400, ptr %slot810, align 8
  %v4401 = load i32, ptr %slot810, align 8
  %cv4402 = zext i32 %v4401 to i64
  %cond4403 = icmp ne i64 %cv4402, 0
  br i1 %cond4403, label %bb_rcglimit1006, label %bb_rcgcapacity1006
bb_rcglimit1006:
  %v4404 = load i64, ptr %slot1, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  %call4406 = call i32 @myl_qbe_rc_status(ptr %p4405, i32 2) nomerge, !dbg !130
  store i32 %call4406, ptr %slot811, align 8
  br label %bb_failure
bb_rcgcapacity1006:
  %v4407 = load i64, ptr %slot809, align 8
  %v4408 = load i64, ptr %slot801, align 8
  %p4409 = inttoptr i64 %v4408 to ptr
  %rgep4410 = getelementptr i8, ptr %p4409, i64 -32
  store i64 %v4407, ptr %rgep4410, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1006
bb_rcgspecial1006:
  %v4411 = load i64, ptr %slot804, align 8
  %op4412 = and i64 %v4411, 4611686018427387904
  store i64 %op4412, ptr %slot812, align 8
  %v4413 = load i64, ptr %slot812, align 8
  %cmp4414 = icmp ne i64 %v4413, 0
  %cv4415 = zext i1 %cmp4414 to i32
  store i32 %cv4415, ptr %slot813, align 8
  %v4416 = load i32, ptr %slot813, align 8
  %cv4417 = zext i32 %v4416 to i64
  %cond4418 = icmp ne i64 %cv4417, 0
  br i1 %cond4418, label %bb_rcgslow1006, label %bb_rcgplain1006
bb_rcgslow1006:
  %v4419 = load i64, ptr %slot34, align 8
  %v4420 = load i64, ptr %slot799, align 8
  %v4421 = load i64, ptr %slot777, align 8
  %v4422 = load i64, ptr %slot800, align 8
  %cv4423 = trunc i64 %v4422 to i32
  %call4424 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v4419, i64 %v4420, i64 %v4421, i32 %cv4423) nomerge, !dbg !130
  store i32 %call4424, ptr %slot814, align 8
  %v4425 = load i32, ptr %slot814, align 8
  %cv4426 = zext i32 %v4425 to i64
  %cond4427 = icmp ne i64 %cv4426, 0
  br i1 %cond4427, label %bb_rcsuccess1020, label %bb_rcfailure1020
bb_rcfailure1020:
  %v4428 = load i64, ptr %slot34, align 8
  %p4429 = inttoptr i64 %v4428 to ptr
  %call4430 = call i32 @myl_rc_take_failure(ptr %p4429) nomerge, !dbg !130
  store i32 %call4430, ptr %slot815, align 8
  %v4431 = load i64, ptr %slot1, align 8
  %p4432 = inttoptr i64 %v4431 to ptr
  %v4433 = load i32, ptr %slot815, align 8
  %call4434 = call i32 @myl_qbe_rc_status(ptr %p4432, i32 %v4433) nomerge, !dbg !130
  store i32 %call4434, ptr %slot816, align 8
  br label %bb_failure
bb_rcsuccess1020:
  br label %bb_rcgdone1006
bb_rcgplain1006:
  %v4435 = load i64, ptr %slot801, align 8
  %v4436 = load i64, ptr %slot799, align 8
  %p4437 = inttoptr i64 %v4436 to ptr
  store i64 %v4435, ptr %p4437, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1006
bb_rcgdone1006:
  %v4438 = load i64, ptr %slot15, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  store i32 2, ptr %p4439, align 4, !alias.scope !3, !noalias !4
  %v4440 = load i64, ptr %slot14, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  store i32 1, ptr %p4441, align 4, !alias.scope !3, !noalias !4
  %v4442 = load i64, ptr %slot12, align 8
  %p4443 = inttoptr i64 %v4442 to ptr
  %ld4444 = load i32, ptr %p4443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4444, ptr %slot817, align 8
  %v4445 = load i32, ptr %slot817, align 8
  %cv4446 = zext i32 %v4445 to i64
  %cond4447 = icmp ne i64 %cv4446, 0
  br i1 %cond4447, label %bb_rcslotdrop1027, label %bb_rcslotdone1027
bb_rcslotdrop1027:
  %v4448 = load i64, ptr %slot12, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  store i32 0, ptr %p4449, align 4, !alias.scope !3, !noalias !4
  %v4450 = load i64, ptr %slot16, align 8
  store i64 %v4450, ptr %slot818, align 8
  %v4451 = load i64, ptr %slot13, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  %ld4453 = load i32, ptr %p4452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4453, ptr %slot819, align 8
  %v4454 = load i32, ptr %slot819, align 8
  %op4455 = and i32 %v4454, 28
  store i32 %op4455, ptr %slot820, align 8
  %v4456 = load i32, ptr %slot820, align 8
  %cv4457 = zext i32 %v4456 to i64
  %cond4458 = icmp ne i64 %cv4457, 0
  br i1 %cond4458, label %bb_rcslotrole1027, label %bb_rcslotowner1027
bb_rcslotrole1027:
  %v4459 = load i64, ptr %slot34, align 8
  store i64 %v4459, ptr %slot821, align 8
  %v4460 = load i64, ptr %slot818, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  %ld4462 = load i64, ptr %p4461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4462, ptr %slot822, align 8
  %v4463 = load i64, ptr %slot822, align 8
  %cmp4464 = icmp ne i64 %v4463, 0
  %cv4465 = zext i1 %cmp4464 to i32
  store i32 %cv4465, ptr %slot823, align 8
  %v4466 = load i32, ptr %slot823, align 8
  %cv4467 = zext i32 %v4466 to i64
  %cond4468 = icmp ne i64 %cv4467, 0
  br i1 %cond4468, label %bb_rcgnn1043, label %bb_rcgdone1043
bb_rcgnn1043:
  %v4469 = load i64, ptr %slot822, align 8
  %op4470 = sub i64 %v4469, 16
  store i64 %op4470, ptr %slot824, align 8
  %v4471 = load i64, ptr %slot822, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %rgep4473 = getelementptr i8, ptr %p4472, i64 -16
  %ld4474 = load i64, ptr %rgep4473, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4474, ptr %slot825, align 8
  %v4475 = load i64, ptr %slot825, align 8
  %op4476 = and i64 %v4475, 4611686018427387906
  store i64 %op4476, ptr %slot826, align 8
  %v4477 = load i64, ptr %slot826, align 8
  %cmp4478 = icmp ne i64 %v4477, 0
  %cv4479 = zext i1 %cmp4478 to i32
  store i32 %cv4479, ptr %slot827, align 8
  %v4480 = load i32, ptr %slot827, align 8
  %cv4481 = zext i32 %v4480 to i64
  %cond4482 = icmp ne i64 %cv4481, 0
  br i1 %cond4482, label %bb_rcgclear1043, label %bb_rcgcounted1043
bb_rcgcounted1043:
  %v4483 = load i64, ptr %slot822, align 8
  %op4484 = sub i64 %v4483, 24
  store i64 %op4484, ptr %slot828, align 8
  %v4485 = load i64, ptr %slot822, align 8
  %p4486 = inttoptr i64 %v4485 to ptr
  %rgep4487 = getelementptr i8, ptr %p4486, i64 -24
  %ld4488 = load i64, ptr %rgep4487, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4488, ptr %slot829, align 8
  %v4489 = load i64, ptr %slot829, align 8
  %op4490 = sub i64 %v4489, 1
  store i64 %op4490, ptr %slot830, align 8
  %v4491 = load i64, ptr %slot830, align 8
  %cmp4492 = icmp eq i64 %v4491, 0
  %cv4493 = zext i1 %cmp4492 to i32
  store i32 %cv4493, ptr %slot831, align 8
  %v4494 = load i32, ptr %slot831, align 8
  %cv4495 = zext i32 %v4494 to i64
  %cond4496 = icmp ne i64 %cv4495, 0
  br i1 %cond4496, label %bb_rcglast1043, label %bb_rcgdec1043
bb_rcglast1043:
  %v4497 = load i64, ptr %slot822, align 8
  %op4498 = sub i64 %v4497, 32
  store i64 %op4498, ptr %slot832, align 8
  %v4499 = load i64, ptr %slot822, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %rgep4501 = getelementptr i8, ptr %p4500, i64 -32
  %ld4502 = load i64, ptr %rgep4501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4502, ptr %slot833, align 8
  %v4503 = load i64, ptr %slot833, align 8
  %cmp4504 = icmp ne i64 %v4503, 0
  %cv4505 = zext i1 %cmp4504 to i32
  store i32 %cv4505, ptr %slot834, align 8
  %v4506 = load i32, ptr %slot834, align 8
  %cv4507 = zext i32 %v4506 to i64
  %cond4508 = icmp ne i64 %cv4507, 0
  br i1 %cond4508, label %bb_rcgdec1043, label %bb_rcgslow1043
bb_rcgslow1043:
  %v4509 = load i64, ptr %slot821, align 8
  %v4510 = load i64, ptr %slot818, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4509, i64 %v4510) nomerge, !dbg !130
  br label %bb_rcgdone1043
bb_rcgdec1043:
  %v4511 = load i64, ptr %slot830, align 8
  %v4512 = load i64, ptr %slot822, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  %rgep4514 = getelementptr i8, ptr %p4513, i64 -24
  store i64 %v4511, ptr %rgep4514, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1043
bb_rcgclear1043:
  %v4515 = load i64, ptr %slot818, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  store i64 0, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1043
bb_rcgdone1043:
  br label %bb_rcslotdone1027
bb_rcslotowner1027:
  %v4517 = load i64, ptr %slot34, align 8
  store i64 %v4517, ptr %slot835, align 8
  %v4518 = load i64, ptr %slot818, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  %ld4520 = load i64, ptr %p4519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4520, ptr %slot836, align 8
  %v4521 = load i64, ptr %slot836, align 8
  %cmp4522 = icmp ne i64 %v4521, 0
  %cv4523 = zext i1 %cmp4522 to i32
  store i32 %cv4523, ptr %slot837, align 8
  %v4524 = load i32, ptr %slot837, align 8
  %cv4525 = zext i32 %v4524 to i64
  %cond4526 = icmp ne i64 %cv4525, 0
  br i1 %cond4526, label %bb_rcgnn1058, label %bb_rcgdone1058
bb_rcgnn1058:
  %v4527 = load i64, ptr %slot836, align 8
  %op4528 = sub i64 %v4527, 16
  store i64 %op4528, ptr %slot838, align 8
  %v4529 = load i64, ptr %slot836, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  %rgep4531 = getelementptr i8, ptr %p4530, i64 -16
  %ld4532 = load i64, ptr %rgep4531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4532, ptr %slot839, align 8
  %v4533 = load i64, ptr %slot839, align 8
  %op4534 = and i64 %v4533, 4611686018427387906
  store i64 %op4534, ptr %slot840, align 8
  %v4535 = load i64, ptr %slot840, align 8
  %cmp4536 = icmp ne i64 %v4535, 0
  %cv4537 = zext i1 %cmp4536 to i32
  store i32 %cv4537, ptr %slot841, align 8
  %v4538 = load i32, ptr %slot841, align 8
  %cv4539 = zext i32 %v4538 to i64
  %cond4540 = icmp ne i64 %cv4539, 0
  br i1 %cond4540, label %bb_rcgclear1058, label %bb_rcgcounted1058
bb_rcgcounted1058:
  %v4541 = load i64, ptr %slot836, align 8
  %op4542 = sub i64 %v4541, 32
  store i64 %op4542, ptr %slot842, align 8
  %v4543 = load i64, ptr %slot836, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %rgep4545 = getelementptr i8, ptr %p4544, i64 -32
  %ld4546 = load i64, ptr %rgep4545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4546, ptr %slot843, align 8
  %v4547 = load i64, ptr %slot843, align 8
  %op4548 = sub i64 %v4547, 1
  store i64 %op4548, ptr %slot844, align 8
  %v4549 = load i64, ptr %slot844, align 8
  %cmp4550 = icmp eq i64 %v4549, 0
  %cv4551 = zext i1 %cmp4550 to i32
  store i32 %cv4551, ptr %slot845, align 8
  %v4552 = load i32, ptr %slot845, align 8
  %cv4553 = zext i32 %v4552 to i64
  %cond4554 = icmp ne i64 %cv4553, 0
  br i1 %cond4554, label %bb_rcglast1058, label %bb_rcgdec1058
bb_rcglast1058:
  %v4555 = load i64, ptr %slot836, align 8
  %op4556 = sub i64 %v4555, 24
  store i64 %op4556, ptr %slot846, align 8
  %v4557 = load i64, ptr %slot836, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  %rgep4559 = getelementptr i8, ptr %p4558, i64 -24
  %ld4560 = load i64, ptr %rgep4559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4560, ptr %slot847, align 8
  %v4561 = load i64, ptr %slot847, align 8
  %cmp4562 = icmp ne i64 %v4561, 0
  %cv4563 = zext i1 %cmp4562 to i32
  store i32 %cv4563, ptr %slot848, align 8
  %v4564 = load i32, ptr %slot848, align 8
  %cv4565 = zext i32 %v4564 to i64
  %cond4566 = icmp ne i64 %cv4565, 0
  br i1 %cond4566, label %bb_rcgdec1058, label %bb_rcgslow1058
bb_rcgslow1058:
  %v4567 = load i64, ptr %slot835, align 8
  %v4568 = load i64, ptr %slot818, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4567, i64 %v4568) nomerge, !dbg !130
  br label %bb_rcgdone1058
bb_rcgdec1058:
  %v4569 = load i64, ptr %slot844, align 8
  %v4570 = load i64, ptr %slot836, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  %rgep4572 = getelementptr i8, ptr %p4571, i64 -32
  store i64 %v4569, ptr %rgep4572, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1058
bb_rcgclear1058:
  %v4573 = load i64, ptr %slot818, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  store i64 0, ptr %p4574, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1058
bb_rcgdone1058:
  br label %bb_rcslotdone1027
bb_rcslotdone1027:
  br label %bb_rcprepared973
bb_rcprepared973:
  %v4575 = load i64, ptr %slot18, align 8
  store i64 %v4575, ptr %slot849, align 8
  %v4576 = load i64, ptr %slot849, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %ld4578 = load i64, ptr %p4577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4578, ptr %slot850, align 8
  %v4579 = load i64, ptr %slot14, align 8
  %p4580 = inttoptr i64 %v4579 to ptr
  store i32 0, ptr %p4580, align 4, !alias.scope !3, !noalias !4
  %v4581 = load i64, ptr %slot12, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  %ld4583 = load i32, ptr %p4582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4583, ptr %slot851, align 8
  %v4584 = load i32, ptr %slot851, align 8
  %cv4585 = zext i32 %v4584 to i64
  %cond4586 = icmp ne i64 %cv4585, 0
  br i1 %cond4586, label %bb_rcslotdrop1067, label %bb_rcslotdone1067
bb_rcslotdrop1067:
  %v4587 = load i64, ptr %slot12, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  store i32 0, ptr %p4588, align 4, !alias.scope !3, !noalias !4
  %v4589 = load i64, ptr %slot16, align 8
  store i64 %v4589, ptr %slot852, align 8
  %v4590 = load i64, ptr %slot13, align 8
  %p4591 = inttoptr i64 %v4590 to ptr
  %ld4592 = load i32, ptr %p4591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4592, ptr %slot853, align 8
  %v4593 = load i32, ptr %slot853, align 8
  %op4594 = and i32 %v4593, 28
  store i32 %op4594, ptr %slot854, align 8
  %v4595 = load i32, ptr %slot854, align 8
  %cv4596 = zext i32 %v4595 to i64
  %cond4597 = icmp ne i64 %cv4596, 0
  br i1 %cond4597, label %bb_rcslotrole1067, label %bb_rcslotowner1067
bb_rcslotrole1067:
  %v4598 = load i64, ptr %slot34, align 8
  store i64 %v4598, ptr %slot855, align 8
  %v4599 = load i64, ptr %slot852, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  %ld4601 = load i64, ptr %p4600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4601, ptr %slot856, align 8
  %v4602 = load i64, ptr %slot856, align 8
  %cmp4603 = icmp ne i64 %v4602, 0
  %cv4604 = zext i1 %cmp4603 to i32
  store i32 %cv4604, ptr %slot857, align 8
  %v4605 = load i32, ptr %slot857, align 8
  %cv4606 = zext i32 %v4605 to i64
  %cond4607 = icmp ne i64 %cv4606, 0
  br i1 %cond4607, label %bb_rcgnn1083, label %bb_rcgdone1083
bb_rcgnn1083:
  %v4608 = load i64, ptr %slot856, align 8
  %op4609 = sub i64 %v4608, 16
  store i64 %op4609, ptr %slot858, align 8
  %v4610 = load i64, ptr %slot856, align 8
  %p4611 = inttoptr i64 %v4610 to ptr
  %rgep4612 = getelementptr i8, ptr %p4611, i64 -16
  %ld4613 = load i64, ptr %rgep4612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4613, ptr %slot859, align 8
  %v4614 = load i64, ptr %slot859, align 8
  %op4615 = and i64 %v4614, 4611686018427387906
  store i64 %op4615, ptr %slot860, align 8
  %v4616 = load i64, ptr %slot860, align 8
  %cmp4617 = icmp ne i64 %v4616, 0
  %cv4618 = zext i1 %cmp4617 to i32
  store i32 %cv4618, ptr %slot861, align 8
  %v4619 = load i32, ptr %slot861, align 8
  %cv4620 = zext i32 %v4619 to i64
  %cond4621 = icmp ne i64 %cv4620, 0
  br i1 %cond4621, label %bb_rcgclear1083, label %bb_rcgcounted1083
bb_rcgcounted1083:
  %v4622 = load i64, ptr %slot856, align 8
  %op4623 = sub i64 %v4622, 24
  store i64 %op4623, ptr %slot862, align 8
  %v4624 = load i64, ptr %slot856, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  %rgep4626 = getelementptr i8, ptr %p4625, i64 -24
  %ld4627 = load i64, ptr %rgep4626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4627, ptr %slot863, align 8
  %v4628 = load i64, ptr %slot863, align 8
  %op4629 = sub i64 %v4628, 1
  store i64 %op4629, ptr %slot864, align 8
  %v4630 = load i64, ptr %slot864, align 8
  %cmp4631 = icmp eq i64 %v4630, 0
  %cv4632 = zext i1 %cmp4631 to i32
  store i32 %cv4632, ptr %slot865, align 8
  %v4633 = load i32, ptr %slot865, align 8
  %cv4634 = zext i32 %v4633 to i64
  %cond4635 = icmp ne i64 %cv4634, 0
  br i1 %cond4635, label %bb_rcglast1083, label %bb_rcgdec1083
bb_rcglast1083:
  %v4636 = load i64, ptr %slot856, align 8
  %op4637 = sub i64 %v4636, 32
  store i64 %op4637, ptr %slot866, align 8
  %v4638 = load i64, ptr %slot856, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %rgep4640 = getelementptr i8, ptr %p4639, i64 -32
  %ld4641 = load i64, ptr %rgep4640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4641, ptr %slot867, align 8
  %v4642 = load i64, ptr %slot867, align 8
  %cmp4643 = icmp ne i64 %v4642, 0
  %cv4644 = zext i1 %cmp4643 to i32
  store i32 %cv4644, ptr %slot868, align 8
  %v4645 = load i32, ptr %slot868, align 8
  %cv4646 = zext i32 %v4645 to i64
  %cond4647 = icmp ne i64 %cv4646, 0
  br i1 %cond4647, label %bb_rcgdec1083, label %bb_rcgslow1083
bb_rcgslow1083:
  %v4648 = load i64, ptr %slot855, align 8
  %v4649 = load i64, ptr %slot852, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4648, i64 %v4649) nomerge, !dbg !130
  br label %bb_rcgdone1083
bb_rcgdec1083:
  %v4650 = load i64, ptr %slot864, align 8
  %v4651 = load i64, ptr %slot856, align 8
  %p4652 = inttoptr i64 %v4651 to ptr
  %rgep4653 = getelementptr i8, ptr %p4652, i64 -24
  store i64 %v4650, ptr %rgep4653, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1083
bb_rcgclear1083:
  %v4654 = load i64, ptr %slot852, align 8
  %p4655 = inttoptr i64 %v4654 to ptr
  store i64 0, ptr %p4655, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1083
bb_rcgdone1083:
  br label %bb_rcslotdone1067
bb_rcslotowner1067:
  %v4656 = load i64, ptr %slot34, align 8
  store i64 %v4656, ptr %slot869, align 8
  %v4657 = load i64, ptr %slot852, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  %ld4659 = load i64, ptr %p4658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4659, ptr %slot870, align 8
  %v4660 = load i64, ptr %slot870, align 8
  %cmp4661 = icmp ne i64 %v4660, 0
  %cv4662 = zext i1 %cmp4661 to i32
  store i32 %cv4662, ptr %slot871, align 8
  %v4663 = load i32, ptr %slot871, align 8
  %cv4664 = zext i32 %v4663 to i64
  %cond4665 = icmp ne i64 %cv4664, 0
  br i1 %cond4665, label %bb_rcgnn1098, label %bb_rcgdone1098
bb_rcgnn1098:
  %v4666 = load i64, ptr %slot870, align 8
  %op4667 = sub i64 %v4666, 16
  store i64 %op4667, ptr %slot872, align 8
  %v4668 = load i64, ptr %slot870, align 8
  %p4669 = inttoptr i64 %v4668 to ptr
  %rgep4670 = getelementptr i8, ptr %p4669, i64 -16
  %ld4671 = load i64, ptr %rgep4670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4671, ptr %slot873, align 8
  %v4672 = load i64, ptr %slot873, align 8
  %op4673 = and i64 %v4672, 4611686018427387906
  store i64 %op4673, ptr %slot874, align 8
  %v4674 = load i64, ptr %slot874, align 8
  %cmp4675 = icmp ne i64 %v4674, 0
  %cv4676 = zext i1 %cmp4675 to i32
  store i32 %cv4676, ptr %slot875, align 8
  %v4677 = load i32, ptr %slot875, align 8
  %cv4678 = zext i32 %v4677 to i64
  %cond4679 = icmp ne i64 %cv4678, 0
  br i1 %cond4679, label %bb_rcgclear1098, label %bb_rcgcounted1098
bb_rcgcounted1098:
  %v4680 = load i64, ptr %slot870, align 8
  %op4681 = sub i64 %v4680, 32
  store i64 %op4681, ptr %slot876, align 8
  %v4682 = load i64, ptr %slot870, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  %rgep4684 = getelementptr i8, ptr %p4683, i64 -32
  %ld4685 = load i64, ptr %rgep4684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4685, ptr %slot877, align 8
  %v4686 = load i64, ptr %slot877, align 8
  %op4687 = sub i64 %v4686, 1
  store i64 %op4687, ptr %slot878, align 8
  %v4688 = load i64, ptr %slot878, align 8
  %cmp4689 = icmp eq i64 %v4688, 0
  %cv4690 = zext i1 %cmp4689 to i32
  store i32 %cv4690, ptr %slot879, align 8
  %v4691 = load i32, ptr %slot879, align 8
  %cv4692 = zext i32 %v4691 to i64
  %cond4693 = icmp ne i64 %cv4692, 0
  br i1 %cond4693, label %bb_rcglast1098, label %bb_rcgdec1098
bb_rcglast1098:
  %v4694 = load i64, ptr %slot870, align 8
  %op4695 = sub i64 %v4694, 24
  store i64 %op4695, ptr %slot880, align 8
  %v4696 = load i64, ptr %slot870, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %rgep4698 = getelementptr i8, ptr %p4697, i64 -24
  %ld4699 = load i64, ptr %rgep4698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4699, ptr %slot881, align 8
  %v4700 = load i64, ptr %slot881, align 8
  %cmp4701 = icmp ne i64 %v4700, 0
  %cv4702 = zext i1 %cmp4701 to i32
  store i32 %cv4702, ptr %slot882, align 8
  %v4703 = load i32, ptr %slot882, align 8
  %cv4704 = zext i32 %v4703 to i64
  %cond4705 = icmp ne i64 %cv4704, 0
  br i1 %cond4705, label %bb_rcgdec1098, label %bb_rcgslow1098
bb_rcgslow1098:
  %v4706 = load i64, ptr %slot869, align 8
  %v4707 = load i64, ptr %slot852, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4706, i64 %v4707) nomerge, !dbg !130
  br label %bb_rcgdone1098
bb_rcgdec1098:
  %v4708 = load i64, ptr %slot878, align 8
  %v4709 = load i64, ptr %slot870, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  %rgep4711 = getelementptr i8, ptr %p4710, i64 -32
  store i64 %v4708, ptr %rgep4711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1098
bb_rcgclear1098:
  %v4712 = load i64, ptr %slot852, align 8
  %p4713 = inttoptr i64 %v4712 to ptr
  store i64 0, ptr %p4713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1098
bb_rcgdone1098:
  br label %bb_rcslotdone1067
bb_rcslotdone1067:
  %v4714 = load i64, ptr %slot10, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  %ld4716 = load i32, ptr %p4715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4716, ptr %slot883, align 8
  %v4717 = load i32, ptr %slot883, align 8
  %cv4718 = zext i32 %v4717 to i64
  %cond4719 = icmp ne i64 %cv4718, 0
  br i1 %cond4719, label %bb_rcslotdrop1104, label %bb_rcslotdone1104
bb_rcslotdrop1104:
  %v4720 = load i64, ptr %slot10, align 8
  %p4721 = inttoptr i64 %v4720 to ptr
  store i32 0, ptr %p4721, align 4, !alias.scope !3, !noalias !4
  %v4722 = load i64, ptr %slot25, align 8
  store i64 %v4722, ptr %slot884, align 8
  %v4723 = load i64, ptr %slot11, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  %ld4725 = load i32, ptr %p4724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4725, ptr %slot885, align 8
  %v4726 = load i32, ptr %slot885, align 8
  %op4727 = and i32 %v4726, 28
  store i32 %op4727, ptr %slot886, align 8
  %v4728 = load i32, ptr %slot886, align 8
  %cv4729 = zext i32 %v4728 to i64
  %cond4730 = icmp ne i64 %cv4729, 0
  br i1 %cond4730, label %bb_rcslotrole1104, label %bb_rcslotowner1104
bb_rcslotrole1104:
  %v4731 = load i64, ptr %slot34, align 8
  store i64 %v4731, ptr %slot887, align 8
  %v4732 = load i64, ptr %slot884, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  %ld4734 = load i64, ptr %p4733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4734, ptr %slot888, align 8
  %v4735 = load i64, ptr %slot888, align 8
  %cmp4736 = icmp ne i64 %v4735, 0
  %cv4737 = zext i1 %cmp4736 to i32
  store i32 %cv4737, ptr %slot889, align 8
  %v4738 = load i32, ptr %slot889, align 8
  %cv4739 = zext i32 %v4738 to i64
  %cond4740 = icmp ne i64 %cv4739, 0
  br i1 %cond4740, label %bb_rcgnn1120, label %bb_rcgdone1120
bb_rcgnn1120:
  %v4741 = load i64, ptr %slot888, align 8
  %op4742 = sub i64 %v4741, 16
  store i64 %op4742, ptr %slot890, align 8
  %v4743 = load i64, ptr %slot888, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  %rgep4745 = getelementptr i8, ptr %p4744, i64 -16
  %ld4746 = load i64, ptr %rgep4745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4746, ptr %slot891, align 8
  %v4747 = load i64, ptr %slot891, align 8
  %op4748 = and i64 %v4747, 4611686018427387906
  store i64 %op4748, ptr %slot892, align 8
  %v4749 = load i64, ptr %slot892, align 8
  %cmp4750 = icmp ne i64 %v4749, 0
  %cv4751 = zext i1 %cmp4750 to i32
  store i32 %cv4751, ptr %slot893, align 8
  %v4752 = load i32, ptr %slot893, align 8
  %cv4753 = zext i32 %v4752 to i64
  %cond4754 = icmp ne i64 %cv4753, 0
  br i1 %cond4754, label %bb_rcgclear1120, label %bb_rcgcounted1120
bb_rcgcounted1120:
  %v4755 = load i64, ptr %slot888, align 8
  %op4756 = sub i64 %v4755, 24
  store i64 %op4756, ptr %slot894, align 8
  %v4757 = load i64, ptr %slot888, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  %rgep4759 = getelementptr i8, ptr %p4758, i64 -24
  %ld4760 = load i64, ptr %rgep4759, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4760, ptr %slot895, align 8
  %v4761 = load i64, ptr %slot895, align 8
  %op4762 = sub i64 %v4761, 1
  store i64 %op4762, ptr %slot896, align 8
  %v4763 = load i64, ptr %slot896, align 8
  %cmp4764 = icmp eq i64 %v4763, 0
  %cv4765 = zext i1 %cmp4764 to i32
  store i32 %cv4765, ptr %slot897, align 8
  %v4766 = load i32, ptr %slot897, align 8
  %cv4767 = zext i32 %v4766 to i64
  %cond4768 = icmp ne i64 %cv4767, 0
  br i1 %cond4768, label %bb_rcglast1120, label %bb_rcgdec1120
bb_rcglast1120:
  %v4769 = load i64, ptr %slot888, align 8
  %op4770 = sub i64 %v4769, 32
  store i64 %op4770, ptr %slot898, align 8
  %v4771 = load i64, ptr %slot888, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  %rgep4773 = getelementptr i8, ptr %p4772, i64 -32
  %ld4774 = load i64, ptr %rgep4773, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4774, ptr %slot899, align 8
  %v4775 = load i64, ptr %slot899, align 8
  %cmp4776 = icmp ne i64 %v4775, 0
  %cv4777 = zext i1 %cmp4776 to i32
  store i32 %cv4777, ptr %slot900, align 8
  %v4778 = load i32, ptr %slot900, align 8
  %cv4779 = zext i32 %v4778 to i64
  %cond4780 = icmp ne i64 %cv4779, 0
  br i1 %cond4780, label %bb_rcgdec1120, label %bb_rcgslow1120
bb_rcgslow1120:
  %v4781 = load i64, ptr %slot887, align 8
  %v4782 = load i64, ptr %slot884, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4781, i64 %v4782) nomerge, !dbg !130
  br label %bb_rcgdone1120
bb_rcgdec1120:
  %v4783 = load i64, ptr %slot896, align 8
  %v4784 = load i64, ptr %slot888, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  %rgep4786 = getelementptr i8, ptr %p4785, i64 -24
  store i64 %v4783, ptr %rgep4786, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1120
bb_rcgclear1120:
  %v4787 = load i64, ptr %slot884, align 8
  %p4788 = inttoptr i64 %v4787 to ptr
  store i64 0, ptr %p4788, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1120
bb_rcgdone1120:
  br label %bb_rcslotdone1104
bb_rcslotowner1104:
  %v4789 = load i64, ptr %slot34, align 8
  store i64 %v4789, ptr %slot901, align 8
  %v4790 = load i64, ptr %slot884, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  %ld4792 = load i64, ptr %p4791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4792, ptr %slot902, align 8
  %v4793 = load i64, ptr %slot902, align 8
  %cmp4794 = icmp ne i64 %v4793, 0
  %cv4795 = zext i1 %cmp4794 to i32
  store i32 %cv4795, ptr %slot903, align 8
  %v4796 = load i32, ptr %slot903, align 8
  %cv4797 = zext i32 %v4796 to i64
  %cond4798 = icmp ne i64 %cv4797, 0
  br i1 %cond4798, label %bb_rcgnn1135, label %bb_rcgdone1135
bb_rcgnn1135:
  %v4799 = load i64, ptr %slot902, align 8
  %op4800 = sub i64 %v4799, 16
  store i64 %op4800, ptr %slot904, align 8
  %v4801 = load i64, ptr %slot902, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  %rgep4803 = getelementptr i8, ptr %p4802, i64 -16
  %ld4804 = load i64, ptr %rgep4803, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4804, ptr %slot905, align 8
  %v4805 = load i64, ptr %slot905, align 8
  %op4806 = and i64 %v4805, 4611686018427387906
  store i64 %op4806, ptr %slot906, align 8
  %v4807 = load i64, ptr %slot906, align 8
  %cmp4808 = icmp ne i64 %v4807, 0
  %cv4809 = zext i1 %cmp4808 to i32
  store i32 %cv4809, ptr %slot907, align 8
  %v4810 = load i32, ptr %slot907, align 8
  %cv4811 = zext i32 %v4810 to i64
  %cond4812 = icmp ne i64 %cv4811, 0
  br i1 %cond4812, label %bb_rcgclear1135, label %bb_rcgcounted1135
bb_rcgcounted1135:
  %v4813 = load i64, ptr %slot902, align 8
  %op4814 = sub i64 %v4813, 32
  store i64 %op4814, ptr %slot908, align 8
  %v4815 = load i64, ptr %slot902, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %rgep4817 = getelementptr i8, ptr %p4816, i64 -32
  %ld4818 = load i64, ptr %rgep4817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4818, ptr %slot909, align 8
  %v4819 = load i64, ptr %slot909, align 8
  %op4820 = sub i64 %v4819, 1
  store i64 %op4820, ptr %slot910, align 8
  %v4821 = load i64, ptr %slot910, align 8
  %cmp4822 = icmp eq i64 %v4821, 0
  %cv4823 = zext i1 %cmp4822 to i32
  store i32 %cv4823, ptr %slot911, align 8
  %v4824 = load i32, ptr %slot911, align 8
  %cv4825 = zext i32 %v4824 to i64
  %cond4826 = icmp ne i64 %cv4825, 0
  br i1 %cond4826, label %bb_rcglast1135, label %bb_rcgdec1135
bb_rcglast1135:
  %v4827 = load i64, ptr %slot902, align 8
  %op4828 = sub i64 %v4827, 24
  store i64 %op4828, ptr %slot912, align 8
  %v4829 = load i64, ptr %slot902, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  %rgep4831 = getelementptr i8, ptr %p4830, i64 -24
  %ld4832 = load i64, ptr %rgep4831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4832, ptr %slot913, align 8
  %v4833 = load i64, ptr %slot913, align 8
  %cmp4834 = icmp ne i64 %v4833, 0
  %cv4835 = zext i1 %cmp4834 to i32
  store i32 %cv4835, ptr %slot914, align 8
  %v4836 = load i32, ptr %slot914, align 8
  %cv4837 = zext i32 %v4836 to i64
  %cond4838 = icmp ne i64 %cv4837, 0
  br i1 %cond4838, label %bb_rcgdec1135, label %bb_rcgslow1135
bb_rcgslow1135:
  %v4839 = load i64, ptr %slot901, align 8
  %v4840 = load i64, ptr %slot884, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4839, i64 %v4840) nomerge, !dbg !130
  br label %bb_rcgdone1135
bb_rcgdec1135:
  %v4841 = load i64, ptr %slot910, align 8
  %v4842 = load i64, ptr %slot902, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  %rgep4844 = getelementptr i8, ptr %p4843, i64 -32
  store i64 %v4841, ptr %rgep4844, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1135
bb_rcgclear1135:
  %v4845 = load i64, ptr %slot884, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  store i64 0, ptr %p4846, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1135
bb_rcgdone1135:
  br label %bb_rcslotdone1104
bb_rcslotdone1104:
  %v4847 = load i64, ptr %slot8, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  %ld4849 = load i32, ptr %p4848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4849, ptr %slot915, align 8
  %v4850 = load i32, ptr %slot915, align 8
  %cv4851 = zext i32 %v4850 to i64
  %cond4852 = icmp ne i64 %cv4851, 0
  br i1 %cond4852, label %bb_rcslotdrop1141, label %bb_rcslotdone1141
bb_rcslotdrop1141:
  %v4853 = load i64, ptr %slot8, align 8
  %p4854 = inttoptr i64 %v4853 to ptr
  store i32 0, ptr %p4854, align 4, !alias.scope !3, !noalias !4
  %v4855 = load i64, ptr %slot24, align 8
  store i64 %v4855, ptr %slot916, align 8
  %v4856 = load i64, ptr %slot9, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  %ld4858 = load i32, ptr %p4857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4858, ptr %slot917, align 8
  %v4859 = load i32, ptr %slot917, align 8
  %op4860 = and i32 %v4859, 28
  store i32 %op4860, ptr %slot918, align 8
  %v4861 = load i32, ptr %slot918, align 8
  %cv4862 = zext i32 %v4861 to i64
  %cond4863 = icmp ne i64 %cv4862, 0
  br i1 %cond4863, label %bb_rcslotrole1141, label %bb_rcslotowner1141
bb_rcslotrole1141:
  %v4864 = load i64, ptr %slot34, align 8
  store i64 %v4864, ptr %slot919, align 8
  %v4865 = load i64, ptr %slot916, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %ld4867 = load i64, ptr %p4866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4867, ptr %slot920, align 8
  %v4868 = load i64, ptr %slot920, align 8
  %cmp4869 = icmp ne i64 %v4868, 0
  %cv4870 = zext i1 %cmp4869 to i32
  store i32 %cv4870, ptr %slot921, align 8
  %v4871 = load i32, ptr %slot921, align 8
  %cv4872 = zext i32 %v4871 to i64
  %cond4873 = icmp ne i64 %cv4872, 0
  br i1 %cond4873, label %bb_rcgnn1157, label %bb_rcgdone1157
bb_rcgnn1157:
  %v4874 = load i64, ptr %slot920, align 8
  %op4875 = sub i64 %v4874, 16
  store i64 %op4875, ptr %slot922, align 8
  %v4876 = load i64, ptr %slot920, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %rgep4878 = getelementptr i8, ptr %p4877, i64 -16
  %ld4879 = load i64, ptr %rgep4878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4879, ptr %slot923, align 8
  %v4880 = load i64, ptr %slot923, align 8
  %op4881 = and i64 %v4880, 4611686018427387906
  store i64 %op4881, ptr %slot924, align 8
  %v4882 = load i64, ptr %slot924, align 8
  %cmp4883 = icmp ne i64 %v4882, 0
  %cv4884 = zext i1 %cmp4883 to i32
  store i32 %cv4884, ptr %slot925, align 8
  %v4885 = load i32, ptr %slot925, align 8
  %cv4886 = zext i32 %v4885 to i64
  %cond4887 = icmp ne i64 %cv4886, 0
  br i1 %cond4887, label %bb_rcgclear1157, label %bb_rcgcounted1157
bb_rcgcounted1157:
  %v4888 = load i64, ptr %slot920, align 8
  %op4889 = sub i64 %v4888, 24
  store i64 %op4889, ptr %slot926, align 8
  %v4890 = load i64, ptr %slot920, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  %rgep4892 = getelementptr i8, ptr %p4891, i64 -24
  %ld4893 = load i64, ptr %rgep4892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4893, ptr %slot927, align 8
  %v4894 = load i64, ptr %slot927, align 8
  %op4895 = sub i64 %v4894, 1
  store i64 %op4895, ptr %slot928, align 8
  %v4896 = load i64, ptr %slot928, align 8
  %cmp4897 = icmp eq i64 %v4896, 0
  %cv4898 = zext i1 %cmp4897 to i32
  store i32 %cv4898, ptr %slot929, align 8
  %v4899 = load i32, ptr %slot929, align 8
  %cv4900 = zext i32 %v4899 to i64
  %cond4901 = icmp ne i64 %cv4900, 0
  br i1 %cond4901, label %bb_rcglast1157, label %bb_rcgdec1157
bb_rcglast1157:
  %v4902 = load i64, ptr %slot920, align 8
  %op4903 = sub i64 %v4902, 32
  store i64 %op4903, ptr %slot930, align 8
  %v4904 = load i64, ptr %slot920, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  %rgep4906 = getelementptr i8, ptr %p4905, i64 -32
  %ld4907 = load i64, ptr %rgep4906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4907, ptr %slot931, align 8
  %v4908 = load i64, ptr %slot931, align 8
  %cmp4909 = icmp ne i64 %v4908, 0
  %cv4910 = zext i1 %cmp4909 to i32
  store i32 %cv4910, ptr %slot932, align 8
  %v4911 = load i32, ptr %slot932, align 8
  %cv4912 = zext i32 %v4911 to i64
  %cond4913 = icmp ne i64 %cv4912, 0
  br i1 %cond4913, label %bb_rcgdec1157, label %bb_rcgslow1157
bb_rcgslow1157:
  %v4914 = load i64, ptr %slot919, align 8
  %v4915 = load i64, ptr %slot916, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4914, i64 %v4915) nomerge, !dbg !130
  br label %bb_rcgdone1157
bb_rcgdec1157:
  %v4916 = load i64, ptr %slot928, align 8
  %v4917 = load i64, ptr %slot920, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %rgep4919 = getelementptr i8, ptr %p4918, i64 -24
  store i64 %v4916, ptr %rgep4919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1157
bb_rcgclear1157:
  %v4920 = load i64, ptr %slot916, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  store i64 0, ptr %p4921, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1157
bb_rcgdone1157:
  br label %bb_rcslotdone1141
bb_rcslotowner1141:
  %v4922 = load i64, ptr %slot34, align 8
  store i64 %v4922, ptr %slot933, align 8
  %v4923 = load i64, ptr %slot916, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  %ld4925 = load i64, ptr %p4924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4925, ptr %slot934, align 8
  %v4926 = load i64, ptr %slot934, align 8
  %cmp4927 = icmp ne i64 %v4926, 0
  %cv4928 = zext i1 %cmp4927 to i32
  store i32 %cv4928, ptr %slot935, align 8
  %v4929 = load i32, ptr %slot935, align 8
  %cv4930 = zext i32 %v4929 to i64
  %cond4931 = icmp ne i64 %cv4930, 0
  br i1 %cond4931, label %bb_rcgnn1172, label %bb_rcgdone1172
bb_rcgnn1172:
  %v4932 = load i64, ptr %slot934, align 8
  %op4933 = sub i64 %v4932, 16
  store i64 %op4933, ptr %slot936, align 8
  %v4934 = load i64, ptr %slot934, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %rgep4936 = getelementptr i8, ptr %p4935, i64 -16
  %ld4937 = load i64, ptr %rgep4936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4937, ptr %slot937, align 8
  %v4938 = load i64, ptr %slot937, align 8
  %op4939 = and i64 %v4938, 4611686018427387906
  store i64 %op4939, ptr %slot938, align 8
  %v4940 = load i64, ptr %slot938, align 8
  %cmp4941 = icmp ne i64 %v4940, 0
  %cv4942 = zext i1 %cmp4941 to i32
  store i32 %cv4942, ptr %slot939, align 8
  %v4943 = load i32, ptr %slot939, align 8
  %cv4944 = zext i32 %v4943 to i64
  %cond4945 = icmp ne i64 %cv4944, 0
  br i1 %cond4945, label %bb_rcgclear1172, label %bb_rcgcounted1172
bb_rcgcounted1172:
  %v4946 = load i64, ptr %slot934, align 8
  %op4947 = sub i64 %v4946, 32
  store i64 %op4947, ptr %slot940, align 8
  %v4948 = load i64, ptr %slot934, align 8
  %p4949 = inttoptr i64 %v4948 to ptr
  %rgep4950 = getelementptr i8, ptr %p4949, i64 -32
  %ld4951 = load i64, ptr %rgep4950, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4951, ptr %slot941, align 8
  %v4952 = load i64, ptr %slot941, align 8
  %op4953 = sub i64 %v4952, 1
  store i64 %op4953, ptr %slot942, align 8
  %v4954 = load i64, ptr %slot942, align 8
  %cmp4955 = icmp eq i64 %v4954, 0
  %cv4956 = zext i1 %cmp4955 to i32
  store i32 %cv4956, ptr %slot943, align 8
  %v4957 = load i32, ptr %slot943, align 8
  %cv4958 = zext i32 %v4957 to i64
  %cond4959 = icmp ne i64 %cv4958, 0
  br i1 %cond4959, label %bb_rcglast1172, label %bb_rcgdec1172
bb_rcglast1172:
  %v4960 = load i64, ptr %slot934, align 8
  %op4961 = sub i64 %v4960, 24
  store i64 %op4961, ptr %slot944, align 8
  %v4962 = load i64, ptr %slot934, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  %rgep4964 = getelementptr i8, ptr %p4963, i64 -24
  %ld4965 = load i64, ptr %rgep4964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4965, ptr %slot945, align 8
  %v4966 = load i64, ptr %slot945, align 8
  %cmp4967 = icmp ne i64 %v4966, 0
  %cv4968 = zext i1 %cmp4967 to i32
  store i32 %cv4968, ptr %slot946, align 8
  %v4969 = load i32, ptr %slot946, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rcgdec1172, label %bb_rcgslow1172
bb_rcgslow1172:
  %v4972 = load i64, ptr %slot933, align 8
  %v4973 = load i64, ptr %slot916, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4972, i64 %v4973) nomerge, !dbg !130
  br label %bb_rcgdone1172
bb_rcgdec1172:
  %v4974 = load i64, ptr %slot942, align 8
  %v4975 = load i64, ptr %slot934, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %rgep4977 = getelementptr i8, ptr %p4976, i64 -32
  store i64 %v4974, ptr %rgep4977, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1172
bb_rcgclear1172:
  %v4978 = load i64, ptr %slot916, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  store i64 0, ptr %p4979, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1172
bb_rcgdone1172:
  br label %bb_rcslotdone1141
bb_rcslotdone1141:
  %v4980 = load i64, ptr %slot6, align 8
  %p4981 = inttoptr i64 %v4980 to ptr
  %ld4982 = load i32, ptr %p4981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4982, ptr %slot947, align 8
  %v4983 = load i32, ptr %slot947, align 8
  %cv4984 = zext i32 %v4983 to i64
  %cond4985 = icmp ne i64 %cv4984, 0
  br i1 %cond4985, label %bb_rcslotdrop1178, label %bb_rcslotdone1178
bb_rcslotdrop1178:
  %v4986 = load i64, ptr %slot6, align 8
  %p4987 = inttoptr i64 %v4986 to ptr
  store i32 0, ptr %p4987, align 4, !alias.scope !3, !noalias !4
  %v4988 = load i64, ptr %slot23, align 8
  store i64 %v4988, ptr %slot948, align 8
  %v4989 = load i64, ptr %slot7, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %ld4991 = load i32, ptr %p4990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4991, ptr %slot949, align 8
  %v4992 = load i32, ptr %slot949, align 8
  %op4993 = and i32 %v4992, 28
  store i32 %op4993, ptr %slot950, align 8
  %v4994 = load i32, ptr %slot950, align 8
  %cv4995 = zext i32 %v4994 to i64
  %cond4996 = icmp ne i64 %cv4995, 0
  br i1 %cond4996, label %bb_rcslotrole1178, label %bb_rcslotowner1178
bb_rcslotrole1178:
  %v4997 = load i64, ptr %slot34, align 8
  store i64 %v4997, ptr %slot951, align 8
  %v4998 = load i64, ptr %slot948, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  %ld5000 = load i64, ptr %p4999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5000, ptr %slot952, align 8
  %v5001 = load i64, ptr %slot952, align 8
  %cmp5002 = icmp ne i64 %v5001, 0
  %cv5003 = zext i1 %cmp5002 to i32
  store i32 %cv5003, ptr %slot953, align 8
  %v5004 = load i32, ptr %slot953, align 8
  %cv5005 = zext i32 %v5004 to i64
  %cond5006 = icmp ne i64 %cv5005, 0
  br i1 %cond5006, label %bb_rcgnn1194, label %bb_rcgdone1194
bb_rcgnn1194:
  %v5007 = load i64, ptr %slot952, align 8
  %op5008 = sub i64 %v5007, 16
  store i64 %op5008, ptr %slot954, align 8
  %v5009 = load i64, ptr %slot952, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  %rgep5011 = getelementptr i8, ptr %p5010, i64 -16
  %ld5012 = load i64, ptr %rgep5011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5012, ptr %slot955, align 8
  %v5013 = load i64, ptr %slot955, align 8
  %op5014 = and i64 %v5013, 4611686018427387906
  store i64 %op5014, ptr %slot956, align 8
  %v5015 = load i64, ptr %slot956, align 8
  %cmp5016 = icmp ne i64 %v5015, 0
  %cv5017 = zext i1 %cmp5016 to i32
  store i32 %cv5017, ptr %slot957, align 8
  %v5018 = load i32, ptr %slot957, align 8
  %cv5019 = zext i32 %v5018 to i64
  %cond5020 = icmp ne i64 %cv5019, 0
  br i1 %cond5020, label %bb_rcgclear1194, label %bb_rcgcounted1194
bb_rcgcounted1194:
  %v5021 = load i64, ptr %slot952, align 8
  %op5022 = sub i64 %v5021, 24
  store i64 %op5022, ptr %slot958, align 8
  %v5023 = load i64, ptr %slot952, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %rgep5025 = getelementptr i8, ptr %p5024, i64 -24
  %ld5026 = load i64, ptr %rgep5025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5026, ptr %slot959, align 8
  %v5027 = load i64, ptr %slot959, align 8
  %op5028 = sub i64 %v5027, 1
  store i64 %op5028, ptr %slot960, align 8
  %v5029 = load i64, ptr %slot960, align 8
  %cmp5030 = icmp eq i64 %v5029, 0
  %cv5031 = zext i1 %cmp5030 to i32
  store i32 %cv5031, ptr %slot961, align 8
  %v5032 = load i32, ptr %slot961, align 8
  %cv5033 = zext i32 %v5032 to i64
  %cond5034 = icmp ne i64 %cv5033, 0
  br i1 %cond5034, label %bb_rcglast1194, label %bb_rcgdec1194
bb_rcglast1194:
  %v5035 = load i64, ptr %slot952, align 8
  %op5036 = sub i64 %v5035, 32
  store i64 %op5036, ptr %slot962, align 8
  %v5037 = load i64, ptr %slot952, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  %rgep5039 = getelementptr i8, ptr %p5038, i64 -32
  %ld5040 = load i64, ptr %rgep5039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5040, ptr %slot963, align 8
  %v5041 = load i64, ptr %slot963, align 8
  %cmp5042 = icmp ne i64 %v5041, 0
  %cv5043 = zext i1 %cmp5042 to i32
  store i32 %cv5043, ptr %slot964, align 8
  %v5044 = load i32, ptr %slot964, align 8
  %cv5045 = zext i32 %v5044 to i64
  %cond5046 = icmp ne i64 %cv5045, 0
  br i1 %cond5046, label %bb_rcgdec1194, label %bb_rcgslow1194
bb_rcgslow1194:
  %v5047 = load i64, ptr %slot951, align 8
  %v5048 = load i64, ptr %slot948, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5047, i64 %v5048) nomerge, !dbg !130
  br label %bb_rcgdone1194
bb_rcgdec1194:
  %v5049 = load i64, ptr %slot960, align 8
  %v5050 = load i64, ptr %slot952, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  %rgep5052 = getelementptr i8, ptr %p5051, i64 -24
  store i64 %v5049, ptr %rgep5052, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1194
bb_rcgclear1194:
  %v5053 = load i64, ptr %slot948, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  store i64 0, ptr %p5054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1194
bb_rcgdone1194:
  br label %bb_rcslotdone1178
bb_rcslotowner1178:
  %v5055 = load i64, ptr %slot34, align 8
  store i64 %v5055, ptr %slot965, align 8
  %v5056 = load i64, ptr %slot948, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %ld5058 = load i64, ptr %p5057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5058, ptr %slot966, align 8
  %v5059 = load i64, ptr %slot966, align 8
  %cmp5060 = icmp ne i64 %v5059, 0
  %cv5061 = zext i1 %cmp5060 to i32
  store i32 %cv5061, ptr %slot967, align 8
  %v5062 = load i32, ptr %slot967, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcgnn1209, label %bb_rcgdone1209
bb_rcgnn1209:
  %v5065 = load i64, ptr %slot966, align 8
  %op5066 = sub i64 %v5065, 16
  store i64 %op5066, ptr %slot968, align 8
  %v5067 = load i64, ptr %slot966, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  %rgep5069 = getelementptr i8, ptr %p5068, i64 -16
  %ld5070 = load i64, ptr %rgep5069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5070, ptr %slot969, align 8
  %v5071 = load i64, ptr %slot969, align 8
  %op5072 = and i64 %v5071, 4611686018427387906
  store i64 %op5072, ptr %slot970, align 8
  %v5073 = load i64, ptr %slot970, align 8
  %cmp5074 = icmp ne i64 %v5073, 0
  %cv5075 = zext i1 %cmp5074 to i32
  store i32 %cv5075, ptr %slot971, align 8
  %v5076 = load i32, ptr %slot971, align 8
  %cv5077 = zext i32 %v5076 to i64
  %cond5078 = icmp ne i64 %cv5077, 0
  br i1 %cond5078, label %bb_rcgclear1209, label %bb_rcgcounted1209
bb_rcgcounted1209:
  %v5079 = load i64, ptr %slot966, align 8
  %op5080 = sub i64 %v5079, 32
  store i64 %op5080, ptr %slot972, align 8
  %v5081 = load i64, ptr %slot966, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  %rgep5083 = getelementptr i8, ptr %p5082, i64 -32
  %ld5084 = load i64, ptr %rgep5083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5084, ptr %slot973, align 8
  %v5085 = load i64, ptr %slot973, align 8
  %op5086 = sub i64 %v5085, 1
  store i64 %op5086, ptr %slot974, align 8
  %v5087 = load i64, ptr %slot974, align 8
  %cmp5088 = icmp eq i64 %v5087, 0
  %cv5089 = zext i1 %cmp5088 to i32
  store i32 %cv5089, ptr %slot975, align 8
  %v5090 = load i32, ptr %slot975, align 8
  %cv5091 = zext i32 %v5090 to i64
  %cond5092 = icmp ne i64 %cv5091, 0
  br i1 %cond5092, label %bb_rcglast1209, label %bb_rcgdec1209
bb_rcglast1209:
  %v5093 = load i64, ptr %slot966, align 8
  %op5094 = sub i64 %v5093, 24
  store i64 %op5094, ptr %slot976, align 8
  %v5095 = load i64, ptr %slot966, align 8
  %p5096 = inttoptr i64 %v5095 to ptr
  %rgep5097 = getelementptr i8, ptr %p5096, i64 -24
  %ld5098 = load i64, ptr %rgep5097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5098, ptr %slot977, align 8
  %v5099 = load i64, ptr %slot977, align 8
  %cmp5100 = icmp ne i64 %v5099, 0
  %cv5101 = zext i1 %cmp5100 to i32
  store i32 %cv5101, ptr %slot978, align 8
  %v5102 = load i32, ptr %slot978, align 8
  %cv5103 = zext i32 %v5102 to i64
  %cond5104 = icmp ne i64 %cv5103, 0
  br i1 %cond5104, label %bb_rcgdec1209, label %bb_rcgslow1209
bb_rcgslow1209:
  %v5105 = load i64, ptr %slot965, align 8
  %v5106 = load i64, ptr %slot948, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5105, i64 %v5106) nomerge, !dbg !130
  br label %bb_rcgdone1209
bb_rcgdec1209:
  %v5107 = load i64, ptr %slot974, align 8
  %v5108 = load i64, ptr %slot966, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %rgep5110 = getelementptr i8, ptr %p5109, i64 -32
  store i64 %v5107, ptr %rgep5110, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1209
bb_rcgclear1209:
  %v5111 = load i64, ptr %slot948, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  store i64 0, ptr %p5112, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1209
bb_rcgdone1209:
  br label %bb_rcslotdone1178
bb_rcslotdone1178:
  %v5113 = load i64, ptr %slot850, align 8
  ret i64 %v5113
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_2024d487f7864351abc7d15d971065e0526631795088f3dd3ec8df6fc11f6bf3(i64, i64, i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_qbe_bytes_from_list(ptr, ptr)
declare ptr @myl_qbe_bytes_snapshot(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0cfc6485219ed7d9417414c1e26227712e5f12f332f6c4bd39a23ea4ecbf023e", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0cfc6485219ed7d9417414c1e26227712e5f12f332f6c4bd39a23ea4ecbf023e", linkageName: "myl_f_0cfc6485219ed7d9417414c1e26227712e5f12f332f6c4bd39a23ea4ecbf023e", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1868401893044380539, i64 0, !"myl_f_0cfc6485219ed7d9417414c1e26227712e5f12f332f6c4bd39a23ea4ecbf023e"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!124 = !DILocation(line: 10, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
