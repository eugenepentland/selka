target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v101 = load i64, ptr %slot1, align 8
  %op102 = add i64 %v101, 32
  store i64 %op102, ptr %slot5, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot6, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot7, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot8, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot9, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot10, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot11, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot12, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot13, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot14, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot15, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot16, align 8
  %mem125 = alloca i8, i64 392, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot17, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot18, align 8
  %v129 = load i64, ptr %slot1, align 8
  %op130 = add i64 %v129, 64
  store i64 %op130, ptr %slot19, align 8
  %v131 = load i64, ptr %slot19, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !4, !noalias !3
  store i64 %ld133, ptr %slot20, align 8
  %stack134 = call ptr @llvm.stacksave()
  %stackaddr135 = ptrtoint ptr %stack134 to i64
  %v136 = load i64, ptr %slot20, align 8
  %cmp137 = icmp ult i64 %stackaddr135, %v136
  %cv138 = zext i1 %cmp137 to i64
  store i64 %cv138, ptr %slot21, align 8
  %v139 = load i64, ptr %slot21, align 8
  %cond140 = icmp ne i64 %v139, 0
  br i1 %cond140, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v141 = load i64, ptr %slot1, align 8
  %p142 = inttoptr i64 %v141 to ptr
  call void @myl_qbe_fail_frame(ptr %p142) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v143 = load i64, ptr %slot9, align 8
  %p144 = inttoptr i64 %v143 to ptr
  store i64 0, ptr %p144, align 8, !alias.scope !3, !noalias !4
  %v145 = load i64, ptr %slot2, align 8
  %v146 = load i64, ptr %slot6, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i64 %v145, ptr %p147, align 8, !alias.scope !3, !noalias !4
  %v148 = load i64, ptr %slot3, align 8
  %v149 = load i64, ptr %slot7, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i64 %v148, ptr %p150, align 8, !alias.scope !3, !noalias !4
  %v151 = load i64, ptr %slot4, align 8
  %v152 = load i64, ptr %slot8, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v154 = load i64, ptr %slot6, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot22, align 8
  %v157 = load i64, ptr %slot22, align 8
  %v158 = load i64, ptr %slot14, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot14, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot23, align 8
  %v163 = load i64, ptr %slot23, align 8
  %op164 = add i64 %v163, 376
  store i64 %op164, ptr %slot24, align 8
  %v165 = load i64, ptr %slot24, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !4, !noalias !3
  store i64 %ld167, ptr %slot25, align 8
  %v168 = load i64, ptr %slot25, align 8
  %v169 = load i64, ptr %slot14, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot14, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot26, align 8
  %v174 = load i64, ptr %slot26, align 8
  %v175 = load i64, ptr %slot9, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot9, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot27, align 8
  %v180 = load i64, ptr %slot27, align 8
  %op181 = add i64 %v180, 0
  store i64 %op181, ptr %slot28, align 8
  %v182 = load i64, ptr %slot28, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !6, !noalias !7
  store i64 %ld184, ptr %slot29, align 8
  %v185 = load i64, ptr %slot29, align 8
  %v186 = load i64, ptr %slot14, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot14, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot30, align 8
  %v191 = load i64, ptr %slot30, align 8
  %cmp192 = icmp ugt i64 %v191, 9223372036854775807
  %cv193 = zext i1 %cmp192 to i64
  store i64 %cv193, ptr %slot31, align 8
  %v194 = load i64, ptr %slot31, align 8
  %cond195 = icmp ne i64 %v194, 0
  br i1 %cond195, label %bb_cast_overflow29, label %bb_cast_ok29
bb_cast_overflow29:
  %v196 = load i64, ptr %slot1, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %v198 = load i64, ptr %slot30, align 8
  call void @myl_qbe_fail_cast(ptr %p197, i64 %v198, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok29:
  %v199 = load i64, ptr %slot30, align 8
  %v200 = load i64, ptr %slot14, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot15, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 1, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot15, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot32, align 8
  %v207 = load i64, ptr %slot14, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot33, align 8
  %v210 = load i64, ptr %slot33, align 8
  %v211 = load i64, ptr %slot32, align 8
  %ovpair213 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v210, i64 %v211)
  %op212 = extractvalue { i64, i1 } %ovpair213, 0
  %ov214 = extractvalue { i64, i1 } %ovpair213, 1
  store i64 %op212, ptr %slot34, align 8
  %cv215 = zext i1 %ov214 to i64
  store i64 %cv215, ptr %slot35, align 8
  %v216 = load i64, ptr %slot35, align 8
  %cond217 = icmp ne i64 %v216, 0
  br i1 %cond217, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v218 = load i64, ptr %slot1, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %v220 = load i64, ptr %slot33, align 8
  %v221 = load i64, ptr %slot32, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p219, i64 1, i64 %v220, i64 %v221, i64 64) nomerge, !dbg !114
  unreachable
bb_checked32:
  %v222 = load i64, ptr %slot34, align 8
  %v223 = load i64, ptr %slot14, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot14, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot36, align 8
  %v228 = load i64, ptr %slot36, align 8
  %v229 = load i64, ptr %slot10, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot14, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 5, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot14, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot37, align 8
  %v236 = load i64, ptr %slot37, align 8
  %v237 = load i64, ptr %slot11, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot14, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i64 6, ptr %p240, align 8, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot14, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot38, align 8
  %v244 = load i64, ptr %slot38, align 8
  %v245 = load i64, ptr %slot12, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i64 %v244, ptr %p246, align 8, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot6, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot39, align 8
  %v250 = load i64, ptr %slot39, align 8
  %v251 = load i64, ptr %slot14, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot10, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot40, align 8
  %v256 = load i64, ptr %slot40, align 8
  %v257 = load i64, ptr %slot15, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i64 %v256, ptr %p258, align 8, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot7, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot41, align 8
  %v262 = load i64, ptr %slot41, align 8
  %v263 = load i64, ptr %slot16, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot14, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot42, align 8
  %v268 = load i64, ptr %slot15, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot43, align 8
  %v271 = load i64, ptr %slot16, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot44, align 8
  %v274 = load i64, ptr %slot1, align 8
  %v275 = load i64, ptr %slot42, align 8
  %v276 = load i64, ptr %slot43, align 8
  %v277 = load i64, ptr %slot44, align 8
  %call278 = call i64 @myl_f_fb17c5f35998f28d890791c7c29c3b4d8861f8b82ea8c43160c8fd46bb1ae1af(i64 %v274, i64 %v275, i64 %v276, i64 %v277) nomerge, !dbg !116
  store i64 %call278, ptr %slot45, align 8
  %v279 = load i64, ptr %slot45, align 8
  %v280 = load i64, ptr %slot14, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot14, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot46, align 8
  %v285 = load i64, ptr %slot46, align 8
  %v286 = load i64, ptr %slot13, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot13, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot47, align 8
  %v291 = load i64, ptr %slot47, align 8
  %v292 = load i64, ptr %slot14, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot15, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 18446744073709551615, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot15, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot48, align 8
  %v299 = load i64, ptr %slot14, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot49, align 8
  %v302 = load i64, ptr %slot49, align 8
  %v303 = load i64, ptr %slot48, align 8
  %cmp304 = icmp eq i64 %v302, %v303
  %cv305 = zext i1 %cmp304 to i64
  store i64 %cv305, ptr %slot50, align 8
  %v306 = load i64, ptr %slot50, align 8
  %v307 = load i64, ptr %slot14, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i64 %v306, ptr %p308, align 8, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot14, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot51, align 8
  %v312 = load i64, ptr %slot51, align 8
  %cond313 = icmp ne i64 %v312, 0
  br i1 %cond313, label %bb_next96, label %bb_i43
bb_next96:
  %v314 = load i64, ptr %slot6, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot52, align 8
  %v317 = load i64, ptr %slot52, align 8
  %v318 = load i64, ptr %slot14, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i64 %v317, ptr %p319, align 8, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot10, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot53, align 8
  %v323 = load i64, ptr %slot53, align 8
  %v324 = load i64, ptr %slot15, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot7, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot54, align 8
  %v329 = load i64, ptr %slot54, align 8
  %v330 = load i64, ptr %slot16, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i64 %v329, ptr %p331, align 8, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot14, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i64, ptr %p333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld334, ptr %slot55, align 8
  %v335 = load i64, ptr %slot15, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot56, align 8
  %v338 = load i64, ptr %slot16, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %ld340 = load i64, ptr %p339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld340, ptr %slot57, align 8
  %v341 = load i64, ptr %slot1, align 8
  %v342 = load i64, ptr %slot55, align 8
  %v343 = load i64, ptr %slot56, align 8
  %v344 = load i64, ptr %slot57, align 8
  %call345 = call i64 @myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69(i64 %v341, i64 %v342, i64 %v343, i64 %v344) nomerge, !dbg !118
  store i64 %call345, ptr %slot58, align 8
  %v346 = load i64, ptr %slot58, align 8
  %v347 = load i64, ptr %slot14, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot14, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i64, ptr %p350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld351, ptr %slot59, align 8
  %v352 = load i64, ptr %slot59, align 8
  %v353 = load i64, ptr %slot13, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i64 %v352, ptr %p354, align 8, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot13, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot60, align 8
  %v358 = load i64, ptr %slot60, align 8
  %v359 = load i64, ptr %slot14, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot15, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 18446744073709551615, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot15, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot61, align 8
  %v366 = load i64, ptr %slot14, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot62, align 8
  %v369 = load i64, ptr %slot62, align 8
  %v370 = load i64, ptr %slot61, align 8
  %cmp371 = icmp ne i64 %v369, %v370
  %cv372 = zext i1 %cmp371 to i64
  store i64 %cv372, ptr %slot63, align 8
  %v373 = load i64, ptr %slot63, align 8
  %v374 = load i64, ptr %slot14, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 %v373, ptr %p375, align 8, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot14, align 8
  %p377 = inttoptr i64 %v376 to ptr
  %ld378 = load i64, ptr %p377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld378, ptr %slot64, align 8
  %v379 = load i64, ptr %slot64, align 8
  %cond380 = icmp ne i64 %v379, 0
  br i1 %cond380, label %bb_next155, label %bb_i35
bb_next155:
  %v381 = load i64, ptr %slot14, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 10, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot14, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot65, align 8
  %v386 = load i64, ptr %slot65, align 8
  %v387 = load i64, ptr %slot11, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i64 %v386, ptr %p388, align 8, !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot14, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 11, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot14, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld393, ptr %slot66, align 8
  %v394 = load i64, ptr %slot66, align 8
  %v395 = load i64, ptr %slot12, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 %v394, ptr %p396, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i35:
  %v397 = load i64, ptr %slot6, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot67, align 8
  %v400 = load i64, ptr %slot67, align 8
  %v401 = load i64, ptr %slot14, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 %v400, ptr %p402, align 8, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot7, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot68, align 8
  %v406 = load i64, ptr %slot68, align 8
  %v407 = load i64, ptr %slot15, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 %v406, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot14, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i64, ptr %p410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot69, align 8
  %v412 = load i64, ptr %slot15, align 8
  %p413 = inttoptr i64 %v412 to ptr
  %ld414 = load i64, ptr %p413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld414, ptr %slot70, align 8
  %v415 = load i64, ptr %slot1, align 8
  %v416 = load i64, ptr %slot69, align 8
  %v417 = load i64, ptr %slot70, align 8
  %call418 = call i64 @myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18(i64 %v415, i64 %v416, i64 %v417) nomerge, !dbg !120
  store i64 %call418, ptr %slot71, align 8
  %v419 = load i64, ptr %slot71, align 8
  %v420 = load i64, ptr %slot14, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 %v419, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot14, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot72, align 8
  %v425 = load i64, ptr %slot72, align 8
  %v426 = load i64, ptr %slot13, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i64 %v425, ptr %p427, align 8, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot14, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 7, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot14, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot73, align 8
  %v433 = load i64, ptr %slot73, align 8
  %v434 = load i64, ptr %slot11, align 8
  %p435 = inttoptr i64 %v434 to ptr
  store i64 %v433, ptr %p435, align 8, !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot14, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i64 9, ptr %p437, align 8, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot14, align 8
  %p439 = inttoptr i64 %v438 to ptr
  %ld440 = load i64, ptr %p439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld440, ptr %slot74, align 8
  %v441 = load i64, ptr %slot74, align 8
  %v442 = load i64, ptr %slot12, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i64 %v441, ptr %p443, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i43:
  %v444 = load i64, ptr %slot8, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot75, align 8
  %v447 = load i64, ptr %slot75, align 8
  %v448 = load i64, ptr %slot14, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 %v447, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot14, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i64, ptr %p451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot76, align 8
  %v453 = load i64, ptr %slot76, align 8
  %cond454 = icmp ne i64 %v453, 0
  br i1 %cond454, label %bb_next213, label %bb_i49
bb_next213:
  %v455 = load i64, ptr %slot6, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot77, align 8
  %v458 = load i64, ptr %slot77, align 8
  %v459 = load i64, ptr %slot14, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 %v458, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot17, align 8
  store i64 %v461, ptr %slot78, align 8
  %v462 = load i64, ptr %slot78, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i32 0, ptr %p463, align 4, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot78, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i32 13, ptr %p465, align 4, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot78, align 8
  %v467 = load i64, ptr %slot15, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i64 %v466, ptr %p468, align 8, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot14, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ld471 = load i64, ptr %p470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld471, ptr %slot79, align 8
  %v472 = load i64, ptr %slot15, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %ld474 = load i64, ptr %p473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld474, ptr %slot80, align 8
  %v475 = load i64, ptr %slot1, align 8
  %v476 = load i64, ptr %slot79, align 8
  %v477 = load i64, ptr %slot80, align 8
  %call478 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v475, i64 %v476, i64 %v477) nomerge, !dbg !122
  store i64 %call478, ptr %slot81, align 8
  %v479 = load i64, ptr %slot81, align 8
  %v480 = load i64, ptr %slot14, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i64 %v479, ptr %p481, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i49:
  %v482 = load i64, ptr %slot14, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i64 0, ptr %p483, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i50:
  %v484 = load i64, ptr %slot14, align 8
  %p485 = inttoptr i64 %v484 to ptr
  %ld486 = load i64, ptr %p485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld486, ptr %slot82, align 8
  %v487 = load i64, ptr %slot82, align 8
  %cond488 = icmp ne i64 %v487, 0
  br i1 %cond488, label %bb_next228, label %bb_i60
bb_next228:
  %v489 = load i64, ptr %slot6, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld491, ptr %slot83, align 8
  %v492 = load i64, ptr %slot83, align 8
  %v493 = load i64, ptr %slot14, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i64 %v492, ptr %p494, align 8, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot14, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i64, ptr %p496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld497, ptr %slot84, align 8
  %v498 = load i64, ptr %slot1, align 8
  %v499 = load i64, ptr %slot84, align 8
  %call500 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v498, i64 %v499) nomerge, !dbg !124
  store i64 %call500, ptr %slot85, align 8
  %v501 = load i64, ptr %slot85, align 8
  %v502 = load i64, ptr %slot14, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot6, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot86, align 8
  %v507 = load i64, ptr %slot86, align 8
  %v508 = load i64, ptr %slot14, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot12, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot87, align 8
  %v513 = load i64, ptr %slot87, align 8
  %v514 = load i64, ptr %slot15, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 %v513, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot13, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot88, align 8
  %v519 = load i64, ptr %slot88, align 8
  %v520 = load i64, ptr %slot16, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 %v519, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot14, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld524, ptr %slot89, align 8
  %v525 = load i64, ptr %slot15, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld527, ptr %slot90, align 8
  %v528 = load i64, ptr %slot16, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot91, align 8
  %v531 = load i64, ptr %slot1, align 8
  %v532 = load i64, ptr %slot89, align 8
  %v533 = load i64, ptr %slot90, align 8
  %v534 = load i64, ptr %slot91, align 8
  %call535 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v531, i64 %v532, i64 %v533, i64 %v534) nomerge, !dbg !126
  store i64 %call535, ptr %slot92, align 8
  %v536 = load i64, ptr %slot92, align 8
  %v537 = load i64, ptr %slot14, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i64 %v536, ptr %p538, align 8, !alias.scope !3, !noalias !4
  br label %bb_i65
bb_i60:
  %v539 = load i64, ptr %slot6, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %ld541 = load i64, ptr %p540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld541, ptr %slot93, align 8
  %v542 = load i64, ptr %slot93, align 8
  %v543 = load i64, ptr %slot14, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i64 %v542, ptr %p544, align 8, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot11, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot94, align 8
  %v548 = load i64, ptr %slot94, align 8
  %v549 = load i64, ptr %slot15, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i64 %v548, ptr %p550, align 8, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot13, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i64, ptr %p552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld553, ptr %slot95, align 8
  %v554 = load i64, ptr %slot95, align 8
  %v555 = load i64, ptr %slot16, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot14, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot96, align 8
  %v560 = load i64, ptr %slot15, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot97, align 8
  %v563 = load i64, ptr %slot16, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot98, align 8
  %v566 = load i64, ptr %slot1, align 8
  %v567 = load i64, ptr %slot96, align 8
  %v568 = load i64, ptr %slot97, align 8
  %v569 = load i64, ptr %slot98, align 8
  %call570 = call i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64 %v566, i64 %v567, i64 %v568, i64 %v569) nomerge, !dbg !128
  store i64 %call570, ptr %slot99, align 8
  %v571 = load i64, ptr %slot99, align 8
  %v572 = load i64, ptr %slot14, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i64 %v571, ptr %p573, align 8, !alias.scope !3, !noalias !4
  br label %bb_i65
bb_i65:
  %v574 = load i64, ptr %slot14, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i64 0, ptr %p575, align 8, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot14, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i64, ptr %p577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld578, ptr %slot100, align 8
  %v579 = load i64, ptr %slot100, align 8
  ret i64 %v579
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare i64 @myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18(i64, i64, i64)
declare i64 @myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69(i64, i64, i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare i64 @myl_f_ec0baa176a2812e98d58f10c511b2b677aeb70640586b7918da09e395181210c(i64, i64, i64, i64)
declare i64 @myl_f_fb17c5f35998f28d890791c7c29c3b4d8861f8b82ea8c43160c8fd46bb1ae1af(i64, i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701", linkageName: "myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14139952981116885944, i64 0, !"myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!116 = !DILocation(line: 16, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!118 = !DILocation(line: 25, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!120 = !DILocation(line: 38, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!122 = !DILocation(line: 48, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!124 = !DILocation(line: 53, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!126 = !DILocation(line: 58, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!128 = !DILocation(line: 64, column: 0, scope: !129)
