target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %callresult62 = alloca [40 x i8], align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %callresult110 = alloca [16 x i8], align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %callresult222 = alloca [16 x i8], align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v239 = load i64, ptr %slot1, align 8
  %op240 = add i64 %v239, 32
  store i64 %op240, ptr %slot3, align 8
  %mem241 = alloca i8, i64 16, align 8
  %ptr242 = ptrtoint ptr %mem241 to i64
  store i64 %ptr242, ptr %slot4, align 8
  %mem243 = alloca i8, i64 8, align 8
  %ptr244 = ptrtoint ptr %mem243 to i64
  store i64 %ptr244, ptr %slot5, align 8
  %mem245 = alloca i8, i64 8, align 8
  %ptr246 = ptrtoint ptr %mem245 to i64
  store i64 %ptr246, ptr %slot6, align 8
  %mem247 = alloca i8, i64 8, align 8
  %ptr248 = ptrtoint ptr %mem247 to i64
  store i64 %ptr248, ptr %slot7, align 8
  %mem249 = alloca i8, i64 8, align 8
  %ptr250 = ptrtoint ptr %mem249 to i64
  store i64 %ptr250, ptr %slot8, align 8
  %mem251 = alloca i8, i64 8, align 8
  %ptr252 = ptrtoint ptr %mem251 to i64
  store i64 %ptr252, ptr %slot9, align 8
  %mem253 = alloca i8, i64 8, align 8
  %ptr254 = ptrtoint ptr %mem253 to i64
  store i64 %ptr254, ptr %slot10, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot11, align 8
  %mem257 = alloca i8, i64 8, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot12, align 8
  %mem259 = alloca i8, i64 8, align 8
  %ptr260 = ptrtoint ptr %mem259 to i64
  store i64 %ptr260, ptr %slot13, align 8
  %mem261 = alloca i8, i64 312, align 8
  %ptr262 = ptrtoint ptr %mem261 to i64
  store i64 %ptr262, ptr %slot14, align 8
  %mem263 = alloca i8, i64 112, align 8
  %ptr264 = ptrtoint ptr %mem263 to i64
  store i64 %ptr264, ptr %slot15, align 8
  %mem265 = alloca i8, i64 312, align 8
  %ptr266 = ptrtoint ptr %mem265 to i64
  store i64 %ptr266, ptr %slot16, align 8
  %mem267 = alloca i8, i64 8, align 8
  %ptr268 = ptrtoint ptr %mem267 to i64
  store i64 %ptr268, ptr %slot17, align 8
  %mem269 = alloca i8, i64 40, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot18, align 8
  %mem271 = alloca i8, i64 8, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot19, align 8
  %mem273 = alloca i8, i64 8, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot20, align 8
  %mem275 = alloca i8, i64 8, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot21, align 8
  %mem277 = alloca i8, i64 8, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot22, align 8
  %mem279 = alloca i8, i64 312, align 8
  %ptr280 = ptrtoint ptr %mem279 to i64
  store i64 %ptr280, ptr %slot23, align 8
  %mem281 = alloca i8, i64 312, align 8
  %ptr282 = ptrtoint ptr %mem281 to i64
  store i64 %ptr282, ptr %slot24, align 8
  %mem283 = alloca i8, i64 16, align 8
  %ptr284 = ptrtoint ptr %mem283 to i64
  store i64 %ptr284, ptr %slot25, align 8
  %mem285 = alloca i8, i64 312, align 8
  %ptr286 = ptrtoint ptr %mem285 to i64
  store i64 %ptr286, ptr %slot26, align 8
  %mem287 = alloca i8, i64 312, align 8
  %ptr288 = ptrtoint ptr %mem287 to i64
  store i64 %ptr288, ptr %slot27, align 8
  %mem289 = alloca i8, i64 16, align 8
  %ptr290 = ptrtoint ptr %mem289 to i64
  store i64 %ptr290, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem291 = alloca i8, i64 8, align 8
  %ptr292 = ptrtoint ptr %mem291 to i64
  store i64 %ptr292, ptr %slot29, align 8
  %v293 = load i64, ptr %slot1, align 8
  %op294 = add i64 %v293, 64
  store i64 %op294, ptr %slot30, align 8
  %v295 = load i64, ptr %slot30, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %ld297 = load i64, ptr %p296, align 8, !alias.scope !4, !noalias !3
  store i64 %ld297, ptr %slot31, align 8
  %stack298 = call ptr @llvm.stacksave()
  %stackaddr299 = ptrtoint ptr %stack298 to i64
  %v300 = load i64, ptr %slot31, align 8
  %cmp301 = icmp ult i64 %stackaddr299, %v300
  %cv302 = zext i1 %cmp301 to i64
  store i64 %cv302, ptr %slot32, align 8
  %v303 = load i64, ptr %slot32, align 8
  %cond304 = icmp ne i64 %v303, 0
  br i1 %cond304, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v305 = load i64, ptr %slot1, align 8
  %p306 = inttoptr i64 %v305 to ptr
  call void @myl_qbe_fail_frame(ptr %p306) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v307 = load i64, ptr %slot2, align 8
  %v308 = load i64, ptr %slot17, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot1, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %call312 = call ptr @myl_qbe_heap(ptr %p311) nomerge, !dbg !112
  %calladdr313 = ptrtoint ptr %call312 to i64
  store i64 %calladdr313, ptr %slot33, align 8
  %v314 = load i64, ptr %slot1, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %call316 = call i64 @myl_qbe_region_mark(ptr %p315) nomerge, !dbg !112
  store i64 %call316, ptr %slot34, align 8
  %v317 = load i64, ptr %slot5, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 0, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot6, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot7, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 0, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot8, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 0, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot9, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 0, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot10, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 0, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot11, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i32 0, ptr %p330, align 4, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot12, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 0, ptr %p332, align 4, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot13, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i32 0, ptr %p334, align 4, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot6, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 2, ptr %p336, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v337 = load i64, ptr %slot17, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot35, align 8
  %v340 = load i64, ptr %slot35, align 8
  %v341 = load i64, ptr %slot20, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 %v340, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot23, align 8
  store i64 %v343, ptr %slot36, align 8
  %v344 = load i64, ptr %slot36, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i32 0, ptr %p345, align 4, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot36, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i32 11, ptr %p347, align 4, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot36, align 8
  %v349 = load i64, ptr %slot21, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i64 %v348, ptr %p350, align 8, !alias.scope !3, !noalias !4
  %v351 = load i64, ptr %slot20, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot37, align 8
  %v354 = load i64, ptr %slot21, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot38, align 8
  %v357 = load i64, ptr %slot1, align 8
  %v358 = load i64, ptr %slot37, align 8
  %v359 = load i64, ptr %slot38, align 8
  %call360 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v357, i64 %v358, i64 %v359) nomerge, !dbg !114
  store i64 %call360, ptr %slot39, align 8
  %v361 = load i64, ptr %slot39, align 8
  %v362 = load i64, ptr %slot20, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot7, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i32, ptr %p365, align 4, !alias.scope !3, !noalias !4
  store i32 %ld366, ptr %slot40, align 8
  %v367 = load i32, ptr %slot40, align 8
  %cv368 = zext i32 %v367 to i64
  %cond369 = icmp ne i64 %cv368, 0
  br i1 %cond369, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v370 = load i64, ptr %slot7, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i32 0, ptr %p371, align 4, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot14, align 8
  store i64 %v372, ptr %slot41, align 8
  %v373 = load i64, ptr %slot8, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i32, ptr %p374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld375, ptr %slot42, align 8
  %v376 = load i32, ptr %slot42, align 8
  %op377 = and i32 %v376, 28
  store i32 %op377, ptr %slot43, align 8
  %v378 = load i32, ptr %slot43, align 8
  %cv379 = zext i32 %v378 to i64
  %cond380 = icmp ne i64 %cv379, 0
  br i1 %cond380, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v381 = load i64, ptr %slot33, align 8
  store i64 %v381, ptr %slot44, align 8
  %v382 = load i64, ptr %slot44, align 8
  %v383 = load i64, ptr %slot41, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v382, i64 %v383) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v384 = load i64, ptr %slot33, align 8
  store i64 %v384, ptr %slot45, align 8
  %v385 = load i64, ptr %slot45, align 8
  %v386 = load i64, ptr %slot41, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v385, i64 %v386) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v387 = load i64, ptr %slot20, align 8
  %p388 = inttoptr i64 %v387 to ptr
  %ld389 = load i64, ptr %p388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld389, ptr %slot46, align 8
  %v390 = load i64, ptr %slot46, align 8
  %cond391 = icmp ne i64 %v390, 0
  br i1 %cond391, label %bb_next24, label %bb_i6
bb_next24:
  %v392 = load i64, ptr %slot20, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 1, ptr %p393, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i6:
  %v394 = load i64, ptr %slot17, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot47, align 8
  %v397 = load i64, ptr %slot47, align 8
  %v398 = load i64, ptr %slot20, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 %v397, ptr %p399, align 8, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot24, align 8
  store i64 %v400, ptr %slot48, align 8
  %v401 = load i64, ptr %slot48, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i32 0, ptr %p402, align 4, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot48, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i32 6, ptr %p404, align 4, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot48, align 8
  %v406 = load i64, ptr %slot21, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot20, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot49, align 8
  %v411 = load i64, ptr %slot21, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot50, align 8
  %v414 = load i64, ptr %slot1, align 8
  %v415 = load i64, ptr %slot49, align 8
  %v416 = load i64, ptr %slot50, align 8
  %call417 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v414, i64 %v415, i64 %v416) nomerge, !dbg !116
  store i64 %call417, ptr %slot51, align 8
  %v418 = load i64, ptr %slot51, align 8
  %v419 = load i64, ptr %slot20, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i64 %v418, ptr %p420, align 8, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot7, align 8
  %p422 = inttoptr i64 %v421 to ptr
  %ld423 = load i32, ptr %p422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld423, ptr %slot52, align 8
  %v424 = load i32, ptr %slot52, align 8
  %cv425 = zext i32 %v424 to i64
  %cond426 = icmp ne i64 %cv425, 0
  br i1 %cond426, label %bb_rcslotdrop31, label %bb_rcslotdone31
bb_rcslotdrop31:
  %v427 = load i64, ptr %slot7, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i32 0, ptr %p428, align 4, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot14, align 8
  store i64 %v429, ptr %slot53, align 8
  %v430 = load i64, ptr %slot8, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i32, ptr %p431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld432, ptr %slot54, align 8
  %v433 = load i32, ptr %slot54, align 8
  %op434 = and i32 %v433, 28
  store i32 %op434, ptr %slot55, align 8
  %v435 = load i32, ptr %slot55, align 8
  %cv436 = zext i32 %v435 to i64
  %cond437 = icmp ne i64 %cv436, 0
  br i1 %cond437, label %bb_rcslotrole31, label %bb_rcslotowner31
bb_rcslotrole31:
  %v438 = load i64, ptr %slot33, align 8
  store i64 %v438, ptr %slot56, align 8
  %v439 = load i64, ptr %slot56, align 8
  %v440 = load i64, ptr %slot53, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v439, i64 %v440) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotowner31:
  %v441 = load i64, ptr %slot33, align 8
  store i64 %v441, ptr %slot57, align 8
  %v442 = load i64, ptr %slot57, align 8
  %v443 = load i64, ptr %slot53, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v442, i64 %v443) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotdone31:
  br label %bb_i9
bb_i9:
  %v444 = load i64, ptr %slot20, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot58, align 8
  %v447 = load i64, ptr %slot58, align 8
  %cond448 = icmp ne i64 %v447, 0
  br i1 %cond448, label %bb_next39, label %bb_i27
bb_next39:
  %v449 = load i64, ptr %slot17, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot59, align 8
  %v452 = load i64, ptr %slot59, align 8
  %v453 = load i64, ptr %slot20, align 8
  %p454 = inttoptr i64 %v453 to ptr
  store i64 %v452, ptr %p454, align 8, !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot20, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot60, align 8
  %v458 = load i64, ptr %slot1, align 8
  %v459 = load i64, ptr %slot60, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult62, i64 %v458, i64 %v459) nomerge, !dbg !118
  %addr460 = ptrtoint ptr %callresult62 to i64
  store i64 %addr460, ptr %slot61, align 8
  %v461 = load i64, ptr %slot61, align 8
  %v462 = load i64, ptr %slot20, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 %v461, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot20, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot63, align 8
  %v467 = load i64, ptr %slot16, align 8
  store i64 %v467, ptr %slot64, align 8
  %v468 = load i64, ptr %slot33, align 8
  %v469 = load i64, ptr %slot64, align 8
  %v470 = load i64, ptr %slot63, align 8
  %call471 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v468, i64 %v469, i64 %v470) nomerge, !dbg !118
  store i32 %call471, ptr %slot65, align 8
  %v472 = load i32, ptr %slot65, align 8
  %cv473 = zext i32 %v472 to i64
  %cond474 = icmp ne i64 %cv473, 0
  br i1 %cond474, label %bb_rcsuccess45, label %bb_rcfailure45
bb_rcfailure45:
  %v475 = load i64, ptr %slot33, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %call477 = call i32 @myl_rc_take_failure(ptr %p476) nomerge, !dbg !118
  store i32 %call477, ptr %slot66, align 8
  %v478 = load i64, ptr %slot1, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %v480 = load i32, ptr %slot66, align 8
  %call481 = call i32 @myl_qbe_rc_status(ptr %p479, i32 %v480) nomerge, !dbg !118
  store i32 %call481, ptr %slot67, align 8
  br label %bb_failure
bb_rcsuccess45:
  %v482 = load i64, ptr %slot12, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 2, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot12, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 16, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot11, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 1, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot7, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %ld490 = load i32, ptr %p489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld490, ptr %slot68, align 8
  %v491 = load i32, ptr %slot68, align 8
  %cv492 = zext i32 %v491 to i64
  %cond493 = icmp ne i64 %cv492, 0
  br i1 %cond493, label %bb_rcslotdrop53, label %bb_rcslotdone53
bb_rcslotdrop53:
  %v494 = load i64, ptr %slot7, align 8
  %p495 = inttoptr i64 %v494 to ptr
  store i32 0, ptr %p495, align 4, !alias.scope !3, !noalias !4
  %v496 = load i64, ptr %slot14, align 8
  store i64 %v496, ptr %slot69, align 8
  %v497 = load i64, ptr %slot8, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i32, ptr %p498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld499, ptr %slot70, align 8
  %v500 = load i32, ptr %slot70, align 8
  %op501 = and i32 %v500, 28
  store i32 %op501, ptr %slot71, align 8
  %v502 = load i32, ptr %slot71, align 8
  %cv503 = zext i32 %v502 to i64
  %cond504 = icmp ne i64 %cv503, 0
  br i1 %cond504, label %bb_rcslotrole53, label %bb_rcslotowner53
bb_rcslotrole53:
  %v505 = load i64, ptr %slot33, align 8
  store i64 %v505, ptr %slot72, align 8
  %v506 = load i64, ptr %slot72, align 8
  %v507 = load i64, ptr %slot69, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v506, i64 %v507) nomerge, !dbg !118
  br label %bb_rcslotdone53
bb_rcslotowner53:
  %v508 = load i64, ptr %slot33, align 8
  store i64 %v508, ptr %slot73, align 8
  %v509 = load i64, ptr %slot73, align 8
  %v510 = load i64, ptr %slot69, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v509, i64 %v510) nomerge, !dbg !118
  br label %bb_rcslotdone53
bb_rcslotdone53:
  %v511 = load i64, ptr %slot14, align 8
  store i64 %v511, ptr %slot74, align 8
  %v512 = load i64, ptr %slot16, align 8
  store i64 %v512, ptr %slot75, align 8
  %v513 = load i64, ptr %slot75, align 8
  %v514 = load i64, ptr %slot74, align 8
  %p515 = inttoptr i64 %v513 to ptr
  %p516 = inttoptr i64 %v514 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p516, ptr %p515, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot8, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i32 2, ptr %p518, align 4, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot12, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i32, ptr %p520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld521, ptr %slot76, align 8
  %v522 = load i32, ptr %slot76, align 8
  %v523 = load i64, ptr %slot8, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 %v522, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot11, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 0, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot7, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 1, ptr %p528, align 4, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot74, align 8
  %v530 = load i64, ptr %slot20, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot20, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot77, align 8
  %v535 = load i64, ptr %slot7, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i32, ptr %p536, align 4, !alias.scope !3, !noalias !4
  store i32 %ld537, ptr %slot78, align 8
  %v538 = load i64, ptr %slot8, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i32, ptr %p539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld540, ptr %slot79, align 8
  %v541 = load i32, ptr %slot79, align 8
  %op542 = and i32 %v541, 24
  store i32 %op542, ptr %slot79, align 8
  %v543 = load i32, ptr %slot79, align 8
  %cmp544 = icmp eq i32 %v543, 0
  %cv545 = zext i1 %cmp544 to i32
  store i32 %cv545, ptr %slot80, align 8
  %v546 = load i32, ptr %slot78, align 8
  %v547 = load i32, ptr %slot80, align 8
  %op548 = and i32 %v546, %v547
  store i32 %op548, ptr %slot81, align 8
  %v549 = load i32, ptr %slot81, align 8
  %cv550 = zext i32 %v549 to i64
  %cond551 = icmp ne i64 %cv550, 0
  br i1 %cond551, label %bb_rctake69, label %bb_rccopy69
bb_rctake69:
  %v552 = load i64, ptr %slot16, align 8
  store i64 %v552, ptr %slot82, align 8
  %v553 = load i64, ptr %slot34, align 8
  store i64 %v553, ptr %slot83, align 8
  %v554 = load i64, ptr %slot33, align 8
  %v555 = load i64, ptr %slot82, align 8
  %v556 = load i64, ptr %slot77, align 8
  %v557 = load i64, ptr %slot83, align 8
  %cv558 = trunc i64 %v557 to i32
  %call559 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v554, i64 %v555, i64 %v556, i32 %cv558) nomerge, !dbg !120
  store i32 %call559, ptr %slot84, align 8
  %v560 = load i32, ptr %slot84, align 8
  %cv561 = zext i32 %v560 to i64
  %cond562 = icmp ne i64 %cv561, 0
  br i1 %cond562, label %bb_rcsuccess79, label %bb_rcfailure79
bb_rcfailure79:
  %v563 = load i64, ptr %slot33, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %call565 = call i32 @myl_rc_take_failure(ptr %p564) nomerge, !dbg !120
  store i32 %call565, ptr %slot85, align 8
  %v566 = load i64, ptr %slot1, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %v568 = load i32, ptr %slot85, align 8
  %call569 = call i32 @myl_qbe_rc_status(ptr %p567, i32 %v568) nomerge, !dbg !120
  store i32 %call569, ptr %slot86, align 8
  br label %bb_failure
bb_rcsuccess79:
  %v570 = load i64, ptr %slot7, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i32 0, ptr %p571, align 4, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot12, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 2, ptr %p573, align 4, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot11, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i32 1, ptr %p575, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared69
bb_rccopy69:
  %v576 = load i64, ptr %slot16, align 8
  store i64 %v576, ptr %slot87, align 8
  %v577 = load i64, ptr %slot34, align 8
  store i64 %v577, ptr %slot88, align 8
  %v578 = load i64, ptr %slot33, align 8
  %v579 = load i64, ptr %slot87, align 8
  %v580 = load i64, ptr %slot77, align 8
  %v581 = load i64, ptr %slot88, align 8
  %cv582 = trunc i64 %v581 to i32
  %call583 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v578, i64 %v579, i64 %v580, i32 %cv582) nomerge, !dbg !120
  store i32 %call583, ptr %slot89, align 8
  %v584 = load i32, ptr %slot89, align 8
  %cv585 = zext i32 %v584 to i64
  %cond586 = icmp ne i64 %cv585, 0
  br i1 %cond586, label %bb_rcsuccess88, label %bb_rcfailure88
bb_rcfailure88:
  %v587 = load i64, ptr %slot33, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %call589 = call i32 @myl_rc_take_failure(ptr %p588) nomerge, !dbg !120
  store i32 %call589, ptr %slot90, align 8
  %v590 = load i64, ptr %slot1, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %v592 = load i32, ptr %slot90, align 8
  %call593 = call i32 @myl_qbe_rc_status(ptr %p591, i32 %v592) nomerge, !dbg !120
  store i32 %call593, ptr %slot91, align 8
  br label %bb_failure
bb_rcsuccess88:
  %v594 = load i64, ptr %slot12, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i32 2, ptr %p595, align 4, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot11, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i32 1, ptr %p597, align 4, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot7, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i32, ptr %p599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld600, ptr %slot92, align 8
  %v601 = load i32, ptr %slot92, align 8
  %cv602 = zext i32 %v601 to i64
  %cond603 = icmp ne i64 %cv602, 0
  br i1 %cond603, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v604 = load i64, ptr %slot7, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot14, align 8
  store i64 %v606, ptr %slot93, align 8
  %v607 = load i64, ptr %slot8, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i32, ptr %p608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld609, ptr %slot94, align 8
  %v610 = load i32, ptr %slot94, align 8
  %op611 = and i32 %v610, 28
  store i32 %op611, ptr %slot95, align 8
  %v612 = load i32, ptr %slot95, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v615 = load i64, ptr %slot33, align 8
  store i64 %v615, ptr %slot96, align 8
  %v616 = load i64, ptr %slot96, align 8
  %v617 = load i64, ptr %slot93, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v616, i64 %v617) nomerge, !dbg !120
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v618 = load i64, ptr %slot33, align 8
  store i64 %v618, ptr %slot97, align 8
  %v619 = load i64, ptr %slot97, align 8
  %v620 = load i64, ptr %slot93, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v619, i64 %v620) nomerge, !dbg !120
  br label %bb_rcslotdone95
bb_rcslotdone95:
  br label %bb_rcprepared69
bb_rcprepared69:
  %v621 = load i64, ptr %slot5, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ld623 = load i32, ptr %p622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld623, ptr %slot98, align 8
  %v624 = load i32, ptr %slot98, align 8
  %cv625 = zext i32 %v624 to i64
  %cond626 = icmp ne i64 %cv625, 0
  br i1 %cond626, label %bb_rcslotdrop105, label %bb_rcslotdone105
bb_rcslotdrop105:
  %v627 = load i64, ptr %slot5, align 8
  %p628 = inttoptr i64 %v627 to ptr
  store i32 0, ptr %p628, align 4, !alias.scope !3, !noalias !4
  %v629 = load i64, ptr %slot18, align 8
  store i64 %v629, ptr %slot99, align 8
  %v630 = load i64, ptr %slot6, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i32, ptr %p631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld632, ptr %slot100, align 8
  %v633 = load i32, ptr %slot100, align 8
  %op634 = and i32 %v633, 28
  store i32 %op634, ptr %slot101, align 8
  %v635 = load i32, ptr %slot101, align 8
  %cv636 = zext i32 %v635 to i64
  %cond637 = icmp ne i64 %cv636, 0
  br i1 %cond637, label %bb_rcslotrole105, label %bb_rcslotowner105
bb_rcslotrole105:
  %v638 = load i64, ptr %slot33, align 8
  store i64 %v638, ptr %slot102, align 8
  %v639 = load i64, ptr %slot102, align 8
  %v640 = load i64, ptr %slot99, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v639, i64 %v640) nomerge, !dbg !120
  br label %bb_rcslotdone105
bb_rcslotowner105:
  %v641 = load i64, ptr %slot33, align 8
  store i64 %v641, ptr %slot103, align 8
  %v642 = load i64, ptr %slot103, align 8
  %v643 = load i64, ptr %slot99, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v642, i64 %v643) nomerge, !dbg !120
  br label %bb_rcslotdone105
bb_rcslotdone105:
  %v644 = load i64, ptr %slot18, align 8
  store i64 %v644, ptr %slot104, align 8
  %v645 = load i64, ptr %slot16, align 8
  store i64 %v645, ptr %slot105, align 8
  %v646 = load i64, ptr %slot105, align 8
  %v647 = load i64, ptr %slot104, align 8
  %p648 = inttoptr i64 %v646 to ptr
  %p649 = inttoptr i64 %v647 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p649, ptr %p648, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v650 = load i64, ptr %slot11, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i32 0, ptr %p651, align 4, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot6, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i32 2, ptr %p653, align 4, !alias.scope !3, !noalias !4
  %v654 = load i64, ptr %slot12, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i32, ptr %p655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld656, ptr %slot106, align 8
  %v657 = load i32, ptr %slot106, align 8
  %v658 = load i64, ptr %slot6, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i32 %v657, ptr %p659, align 4, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot5, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i32 1, ptr %p661, align 4, !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot17, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %ld664 = load i64, ptr %p663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld664, ptr %slot107, align 8
  %v665 = load i64, ptr %slot107, align 8
  %v666 = load i64, ptr %slot20, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i64 %v665, ptr %p667, align 8, !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot20, align 8
  %p669 = inttoptr i64 %v668 to ptr
  %ld670 = load i64, ptr %p669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld670, ptr %slot108, align 8
  %v671 = load i64, ptr %slot1, align 8
  %v672 = load i64, ptr %slot108, align 8
  %call673 = call { i64, i64 } @myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7(i64 %v671, i64 %v672) nomerge, !dbg !122
  store { i64, i64 } %call673, ptr %callresult110, align 8
  %addr674 = ptrtoint ptr %callresult110 to i64
  store i64 %addr674, ptr %slot109, align 8
  %v675 = load i64, ptr %slot109, align 8
  %v676 = load i64, ptr %slot20, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i64 %v675, ptr %p677, align 8, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot7, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i32, ptr %p679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld680, ptr %slot111, align 8
  %v681 = load i32, ptr %slot111, align 8
  %cv682 = zext i32 %v681 to i64
  %cond683 = icmp ne i64 %cv682, 0
  br i1 %cond683, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v684 = load i64, ptr %slot7, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i32 0, ptr %p685, align 4, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot14, align 8
  store i64 %v686, ptr %slot112, align 8
  %v687 = load i64, ptr %slot8, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i32, ptr %p688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld689, ptr %slot113, align 8
  %v690 = load i32, ptr %slot113, align 8
  %op691 = and i32 %v690, 28
  store i32 %op691, ptr %slot114, align 8
  %v692 = load i32, ptr %slot114, align 8
  %cv693 = zext i32 %v692 to i64
  %cond694 = icmp ne i64 %cv693, 0
  br i1 %cond694, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v695 = load i64, ptr %slot33, align 8
  store i64 %v695, ptr %slot115, align 8
  %v696 = load i64, ptr %slot115, align 8
  %v697 = load i64, ptr %slot112, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v696, i64 %v697) nomerge, !dbg !122
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v698 = load i64, ptr %slot33, align 8
  store i64 %v698, ptr %slot116, align 8
  %v699 = load i64, ptr %slot116, align 8
  %v700 = load i64, ptr %slot112, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v699, i64 %v700) nomerge, !dbg !122
  br label %bb_rcslotdone124
bb_rcslotdone124:
  %v701 = load i64, ptr %slot20, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %ld703 = load i64, ptr %p702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld703, ptr %slot117, align 8
  %v704 = load i64, ptr %slot117, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %ld706 = load i32, ptr %p705, align 4
  %ext707 = zext i32 %ld706 to i64
  store i64 %ext707, ptr %slot118, align 8
  %v708 = load i64, ptr %slot118, align 8
  %cmp709 = icmp eq i64 %v708, 0
  %cv710 = zext i1 %cmp709 to i64
  store i64 %cv710, ptr %slot119, align 8
  %v711 = load i64, ptr %slot119, align 8
  %cond712 = icmp ne i64 %v711, 0
  br i1 %cond712, label %bb_rctryok132, label %bb_rctryerror132
bb_rctryerror132:
  %p713 = inttoptr i64 ptrtoint (ptr @myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p713, i64 12884901903) "call-inline-cost"="0", !dbg !124
  %v714 = load i64, ptr %slot117, align 8
  %op715 = add i64 %v714, 8
  store i64 %op715, ptr %slot120, align 8
  %v716 = load i64, ptr %slot25, align 8
  store i64 %v716, ptr %slot121, align 8
  %v717 = load i64, ptr %slot121, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i64 0, ptr %p718, align 8, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot121, align 8
  %p721 = inttoptr i64 %v719 to ptr
  %gep722 = getelementptr i8, ptr %p721, i64 8
  %op720 = ptrtoint ptr %gep722 to i64
  store i64 %op720, ptr %slot122, align 8
  %v723 = load i64, ptr %slot122, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i64 0, ptr %p724, align 8, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot121, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 1, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot121, align 8
  %p729 = inttoptr i64 %v727 to ptr
  %gep730 = getelementptr i8, ptr %p729, i64 8
  %op728 = ptrtoint ptr %gep730 to i64
  store i64 %op728, ptr %slot123, align 8
  %v731 = load i64, ptr %slot13, align 8
  %p732 = inttoptr i64 %v731 to ptr
  store i32 1, ptr %p732, align 4, !alias.scope !3, !noalias !4
  %v733 = load i64, ptr %slot34, align 8
  store i64 %v733, ptr %slot124, align 8
  %v734 = load i64, ptr %slot121, align 8
  %v735 = load i64, ptr %slot20, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i64 %v734, ptr %p736, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_rctryok132:
  %v737 = load i64, ptr %slot25, align 8
  store i64 %v737, ptr %slot125, align 8
  %v738 = load i64, ptr %slot125, align 8
  %p739 = inttoptr i64 %v738 to ptr
  store i64 0, ptr %p739, align 8, !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot13, align 8
  %p741 = inttoptr i64 %v740 to ptr
  store i32 1, ptr %p741, align 4, !alias.scope !3, !noalias !4
  %v742 = load i64, ptr %slot117, align 8
  %op743 = add i64 %v742, 8
  store i64 %op743, ptr %slot126, align 8
  %v744 = load i64, ptr %slot34, align 8
  store i64 %v744, ptr %slot127, align 8
  %v745 = load i64, ptr %slot126, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8
  store i64 %ld747, ptr %slot128, align 8
  %v748 = load i64, ptr %slot128, align 8
  %v749 = load i64, ptr %slot125, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 %v748, ptr %p750, align 8, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot125, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i64, ptr %p752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld753, ptr %slot129, align 8
  %v754 = load i64, ptr %slot129, align 8
  %v755 = load i64, ptr %slot20, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i64 %v754, ptr %p756, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i17:
  %v757 = load i64, ptr %slot20, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %ld759 = load i64, ptr %p758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld759, ptr %slot130, align 8
  %v760 = load i64, ptr %slot7, align 8
  %p761 = inttoptr i64 %v760 to ptr
  %ld762 = load i32, ptr %p761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld762, ptr %slot131, align 8
  %v763 = load i32, ptr %slot131, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcslotdrop151, label %bb_rcslotdone151
bb_rcslotdrop151:
  %v766 = load i64, ptr %slot7, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 0, ptr %p767, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone151
bb_rcslotdone151:
  %v768 = load i64, ptr %slot5, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i32, ptr %p769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld770, ptr %slot132, align 8
  %v771 = load i32, ptr %slot132, align 8
  %cv772 = zext i32 %v771 to i64
  %cond773 = icmp ne i64 %cv772, 0
  br i1 %cond773, label %bb_rcslotdrop154, label %bb_rcslotdone154
bb_rcslotdrop154:
  %v774 = load i64, ptr %slot5, align 8
  %p775 = inttoptr i64 %v774 to ptr
  store i32 0, ptr %p775, align 4, !alias.scope !3, !noalias !4
  %v776 = load i64, ptr %slot18, align 8
  store i64 %v776, ptr %slot133, align 8
  %v777 = load i64, ptr %slot6, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot134, align 8
  %v780 = load i32, ptr %slot134, align 8
  %op781 = and i32 %v780, 28
  store i32 %op781, ptr %slot135, align 8
  %v782 = load i32, ptr %slot135, align 8
  %cv783 = zext i32 %v782 to i64
  %cond784 = icmp ne i64 %cv783, 0
  br i1 %cond784, label %bb_rcslotrole154, label %bb_rcslotowner154
bb_rcslotrole154:
  %v785 = load i64, ptr %slot33, align 8
  store i64 %v785, ptr %slot136, align 8
  %v786 = load i64, ptr %slot136, align 8
  %v787 = load i64, ptr %slot133, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v786, i64 %v787) nomerge, !dbg !126
  br label %bb_rcslotdone154
bb_rcslotowner154:
  %v788 = load i64, ptr %slot33, align 8
  store i64 %v788, ptr %slot137, align 8
  %v789 = load i64, ptr %slot137, align 8
  %v790 = load i64, ptr %slot133, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v789, i64 %v790) nomerge, !dbg !126
  br label %bb_rcslotdone154
bb_rcslotdone154:
  %v791 = load i64, ptr %slot130, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %ret793 = load { i64, i64 }, ptr %p792, align 8
  ret { i64, i64 } %ret793
bb_i18:
  %v794 = load i64, ptr %slot20, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld796, ptr %slot138, align 8
  %v797 = load i64, ptr %slot138, align 8
  %v798 = load i64, ptr %slot19, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot17, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot139, align 8
  %v803 = load i64, ptr %slot139, align 8
  %v804 = load i64, ptr %slot20, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i64 %v803, ptr %p805, align 8, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot18, align 8
  %v807 = load i64, ptr %slot21, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i64 %v806, ptr %p808, align 8, !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot19, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i64, ptr %p810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld811, ptr %slot140, align 8
  %v812 = load i64, ptr %slot140, align 8
  %v813 = load i64, ptr %slot22, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i64 %v812, ptr %p814, align 8, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot26, align 8
  store i64 %v815, ptr %slot141, align 8
  %v816 = load i64, ptr %slot141, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 0, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot141, align 8
  %p820 = inttoptr i64 %v818 to ptr
  %gep821 = getelementptr i8, ptr %p820, i64 8
  %op819 = ptrtoint ptr %gep821 to i64
  store i64 %op819, ptr %slot142, align 8
  %v822 = load i64, ptr %slot142, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 0, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot141, align 8
  %p826 = inttoptr i64 %v824 to ptr
  %gep827 = getelementptr i8, ptr %p826, i64 16
  %op825 = ptrtoint ptr %gep827 to i64
  store i64 %op825, ptr %slot143, align 8
  %v828 = load i64, ptr %slot143, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 0, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot141, align 8
  %p832 = inttoptr i64 %v830 to ptr
  %gep833 = getelementptr i8, ptr %p832, i64 24
  %op831 = ptrtoint ptr %gep833 to i64
  store i64 %op831, ptr %slot144, align 8
  %v834 = load i64, ptr %slot144, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 0, ptr %p835, align 8, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot141, align 8
  %p838 = inttoptr i64 %v836 to ptr
  %gep839 = getelementptr i8, ptr %p838, i64 32
  %op837 = ptrtoint ptr %gep839 to i64
  store i64 %op837, ptr %slot145, align 8
  %v840 = load i64, ptr %slot145, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i64 0, ptr %p841, align 8, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot141, align 8
  %p844 = inttoptr i64 %v842 to ptr
  %gep845 = getelementptr i8, ptr %p844, i64 40
  %op843 = ptrtoint ptr %gep845 to i64
  store i64 %op843, ptr %slot146, align 8
  %v846 = load i64, ptr %slot146, align 8
  %p847 = inttoptr i64 %v846 to ptr
  store i64 0, ptr %p847, align 8, !alias.scope !3, !noalias !4
  %v848 = load i64, ptr %slot13, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i32 1, ptr %p849, align 4, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot34, align 8
  store i64 %v850, ptr %slot147, align 8
  %v851 = load i64, ptr %slot21, align 8
  %p852 = inttoptr i64 %v851 to ptr
  %ld853 = load i64, ptr %p852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld853, ptr %slot148, align 8
  %v854 = load i64, ptr %slot141, align 8
  %p856 = inttoptr i64 %v854 to ptr
  %gep857 = getelementptr i8, ptr %p856, i64 0
  %op855 = ptrtoint ptr %gep857 to i64
  store i64 %op855, ptr %slot149, align 8
  %v858 = load i64, ptr %slot21, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i64, ptr %p859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld860, ptr %slot150, align 8
  %v861 = load i64, ptr %slot9, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i32, ptr %p862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld863, ptr %slot151, align 8
  %v864 = load i64, ptr %slot10, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %ld866 = load i32, ptr %p865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld866, ptr %slot152, align 8
  %v867 = load i32, ptr %slot152, align 8
  %op868 = and i32 %v867, 24
  store i32 %op868, ptr %slot152, align 8
  %v869 = load i32, ptr %slot152, align 8
  %cmp870 = icmp eq i32 %v869, 0
  %cv871 = zext i1 %cmp870 to i32
  store i32 %cv871, ptr %slot153, align 8
  %v872 = load i32, ptr %slot151, align 8
  %v873 = load i32, ptr %slot153, align 8
  %op874 = and i32 %v872, %v873
  store i32 %op874, ptr %slot154, align 8
  %v875 = load i32, ptr %slot154, align 8
  %cv876 = zext i32 %v875 to i64
  %cond877 = icmp ne i64 %cv876, 0
  br i1 %cond877, label %bb_rctake185, label %bb_rccopy185
bb_rctake185:
  %v878 = load i64, ptr %slot16, align 8
  store i64 %v878, ptr %slot155, align 8
  %v879 = load i64, ptr %slot34, align 8
  store i64 %v879, ptr %slot156, align 8
  %v880 = load i64, ptr %slot33, align 8
  %v881 = load i64, ptr %slot155, align 8
  %v882 = load i64, ptr %slot150, align 8
  %v883 = load i64, ptr %slot156, align 8
  %cv884 = trunc i64 %v883 to i32
  %call885 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v880, i64 %v881, i64 %v882, i32 %cv884) nomerge, !dbg !128
  store i32 %call885, ptr %slot157, align 8
  %v886 = load i32, ptr %slot157, align 8
  %cv887 = zext i32 %v886 to i64
  %cond888 = icmp ne i64 %cv887, 0
  br i1 %cond888, label %bb_rcsuccess195, label %bb_rcfailure195
bb_rcfailure195:
  %v889 = load i64, ptr %slot33, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %call891 = call i32 @myl_rc_take_failure(ptr %p890) nomerge, !dbg !128
  store i32 %call891, ptr %slot158, align 8
  %v892 = load i64, ptr %slot1, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %v894 = load i32, ptr %slot158, align 8
  %call895 = call i32 @myl_qbe_rc_status(ptr %p893, i32 %v894) nomerge, !dbg !128
  store i32 %call895, ptr %slot159, align 8
  br label %bb_failure
bb_rcsuccess195:
  %v896 = load i64, ptr %slot9, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 0, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot12, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 2, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot11, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i32 1, ptr %p901, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared185
bb_rccopy185:
  %v902 = load i64, ptr %slot16, align 8
  store i64 %v902, ptr %slot160, align 8
  %v903 = load i64, ptr %slot34, align 8
  store i64 %v903, ptr %slot161, align 8
  %v904 = load i64, ptr %slot33, align 8
  %v905 = load i64, ptr %slot160, align 8
  %v906 = load i64, ptr %slot150, align 8
  %v907 = load i64, ptr %slot161, align 8
  %cv908 = trunc i64 %v907 to i32
  %call909 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v904, i64 %v905, i64 %v906, i32 %cv908) nomerge, !dbg !128
  store i32 %call909, ptr %slot162, align 8
  %v910 = load i32, ptr %slot162, align 8
  %cv911 = zext i32 %v910 to i64
  %cond912 = icmp ne i64 %cv911, 0
  br i1 %cond912, label %bb_rcsuccess204, label %bb_rcfailure204
bb_rcfailure204:
  %v913 = load i64, ptr %slot33, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %call915 = call i32 @myl_rc_take_failure(ptr %p914) nomerge, !dbg !128
  store i32 %call915, ptr %slot163, align 8
  %v916 = load i64, ptr %slot1, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %v918 = load i32, ptr %slot163, align 8
  %call919 = call i32 @myl_qbe_rc_status(ptr %p917, i32 %v918) nomerge, !dbg !128
  store i32 %call919, ptr %slot164, align 8
  br label %bb_failure
bb_rcsuccess204:
  %v920 = load i64, ptr %slot12, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 2, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot11, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i32 1, ptr %p923, align 4, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot9, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i32, ptr %p925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld926, ptr %slot165, align 8
  %v927 = load i32, ptr %slot165, align 8
  %cv928 = zext i32 %v927 to i64
  %cond929 = icmp ne i64 %cv928, 0
  br i1 %cond929, label %bb_rcslotdrop211, label %bb_rcslotdone211
bb_rcslotdrop211:
  %v930 = load i64, ptr %slot9, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot15, align 8
  store i64 %v932, ptr %slot166, align 8
  %v933 = load i64, ptr %slot10, align 8
  %p934 = inttoptr i64 %v933 to ptr
  %ld935 = load i32, ptr %p934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld935, ptr %slot167, align 8
  %v936 = load i32, ptr %slot167, align 8
  %op937 = and i32 %v936, 28
  store i32 %op937, ptr %slot168, align 8
  %v938 = load i32, ptr %slot168, align 8
  %cv939 = zext i32 %v938 to i64
  %cond940 = icmp ne i64 %cv939, 0
  br i1 %cond940, label %bb_rcslotrole211, label %bb_rcslotowner211
bb_rcslotrole211:
  %v941 = load i64, ptr %slot33, align 8
  store i64 %v941, ptr %slot169, align 8
  %v942 = load i64, ptr %slot169, align 8
  %v943 = load i64, ptr %slot166, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v942, i64 %v943) nomerge, !dbg !128
  br label %bb_rcslotdone211
bb_rcslotowner211:
  %v944 = load i64, ptr %slot33, align 8
  store i64 %v944, ptr %slot170, align 8
  %v945 = load i64, ptr %slot170, align 8
  %v946 = load i64, ptr %slot166, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v945, i64 %v946) nomerge, !dbg !128
  br label %bb_rcslotdone211
bb_rcslotdone211:
  br label %bb_rcprepared185
bb_rcprepared185:
  %v947 = load i64, ptr %slot16, align 8
  store i64 %v947, ptr %slot171, align 8
  %v948 = load i64, ptr %slot171, align 8
  %v949 = load i64, ptr %slot149, align 8
  %p950 = inttoptr i64 %v948 to ptr
  %p951 = inttoptr i64 %v949 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p951, ptr %p950, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v952 = load i64, ptr %slot11, align 8
  %p953 = inttoptr i64 %v952 to ptr
  store i32 0, ptr %p953, align 4, !alias.scope !3, !noalias !4
  %v954 = load i64, ptr %slot22, align 8
  store i64 %v954, ptr %slot172, align 8
  %v955 = load i64, ptr %slot141, align 8
  %p957 = inttoptr i64 %v955 to ptr
  %gep958 = getelementptr i8, ptr %p957, i64 40
  %op956 = ptrtoint ptr %gep958 to i64
  store i64 %op956, ptr %slot173, align 8
  %v959 = load i64, ptr %slot172, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %ld961 = load i64, ptr %p960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld961, ptr %slot174, align 8
  %v962 = load i64, ptr %slot174, align 8
  %v963 = load i64, ptr %slot173, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i64 %v962, ptr %p964, align 8, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot141, align 8
  %v966 = load i64, ptr %slot21, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i64 %v965, ptr %p967, align 8, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot21, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %ld970 = load i64, ptr %p969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld970, ptr %slot175, align 8
  %v971 = load i64, ptr %slot15, align 8
  store i64 %v971, ptr %slot176, align 8
  %v972 = load i64, ptr %slot175, align 8
  %v973 = load i64, ptr %slot176, align 8
  %p974 = inttoptr i64 %v972 to ptr
  %p975 = inttoptr i64 %v973 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p975, ptr %p974, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot10, align 8
  %p977 = inttoptr i64 %v976 to ptr
  store i32 2, ptr %p977, align 4, !alias.scope !3, !noalias !4
  %v978 = load i64, ptr %slot9, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i32 1, ptr %p979, align 4, !alias.scope !3, !noalias !4
  %v980 = load i64, ptr %slot176, align 8
  %v981 = load i64, ptr %slot21, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i64 %v980, ptr %p982, align 8, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot27, align 8
  store i64 %v983, ptr %slot177, align 8
  %v984 = load i64, ptr %slot177, align 8
  %p985 = inttoptr i64 %v984 to ptr
  call void @llvm.memset.p0.i64(ptr %p985, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v986 = load i64, ptr %slot177, align 8
  %p987 = inttoptr i64 %v986 to ptr
  store i32 10, ptr %p987, align 4, !alias.scope !3, !noalias !4
  %v988 = load i64, ptr %slot13, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i32 1, ptr %p989, align 4, !alias.scope !3, !noalias !4
  %v990 = load i64, ptr %slot21, align 8
  %p991 = inttoptr i64 %v990 to ptr
  %ld992 = load i64, ptr %p991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld992, ptr %slot178, align 8
  %v993 = load i64, ptr %slot177, align 8
  %p995 = inttoptr i64 %v993 to ptr
  %gep996 = getelementptr i8, ptr %p995, i64 8
  %op994 = ptrtoint ptr %gep996 to i64
  store i64 %op994, ptr %slot179, align 8
  %v997 = load i64, ptr %slot34, align 8
  store i64 %v997, ptr %slot180, align 8
  %v998 = load i64, ptr %slot21, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %ld1000 = load i64, ptr %p999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1000, ptr %slot181, align 8
  %v1001 = load i64, ptr %slot16, align 8
  store i64 %v1001, ptr %slot182, align 8
  %v1002 = load i64, ptr %slot34, align 8
  store i64 %v1002, ptr %slot183, align 8
  %v1003 = load i64, ptr %slot33, align 8
  %v1004 = load i64, ptr %slot182, align 8
  %v1005 = load i64, ptr %slot181, align 8
  %v1006 = load i64, ptr %slot183, align 8
  %cv1007 = trunc i64 %v1006 to i32
  %call1008 = call i32 @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_take(i64 %v1003, i64 %v1004, i64 %v1005, i32 %cv1007) nomerge, !dbg !130
  store i32 %call1008, ptr %slot184, align 8
  %v1009 = load i32, ptr %slot184, align 8
  %cv1010 = zext i32 %v1009 to i64
  %cond1011 = icmp ne i64 %cv1010, 0
  br i1 %cond1011, label %bb_rcsuccess237, label %bb_rcfailure237
bb_rcfailure237:
  %v1012 = load i64, ptr %slot33, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %call1014 = call i32 @myl_rc_take_failure(ptr %p1013) nomerge, !dbg !130
  store i32 %call1014, ptr %slot185, align 8
  %v1015 = load i64, ptr %slot1, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %v1017 = load i32, ptr %slot185, align 8
  %call1018 = call i32 @myl_qbe_rc_status(ptr %p1016, i32 %v1017) nomerge, !dbg !130
  store i32 %call1018, ptr %slot186, align 8
  br label %bb_failure
bb_rcsuccess237:
  %v1019 = load i64, ptr %slot9, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i32 0, ptr %p1020, align 4, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot12, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i32 2, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  %v1023 = load i64, ptr %slot11, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 1, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot16, align 8
  store i64 %v1025, ptr %slot187, align 8
  %v1026 = load i64, ptr %slot187, align 8
  %v1027 = load i64, ptr %slot179, align 8
  %p1028 = inttoptr i64 %v1026 to ptr
  %p1029 = inttoptr i64 %v1027 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1029, ptr %p1028, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot11, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  store i32 0, ptr %p1031, align 4, !alias.scope !3, !noalias !4
  %v1032 = load i64, ptr %slot177, align 8
  %v1033 = load i64, ptr %slot21, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  store i64 %v1032, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  %v1035 = load i64, ptr %slot21, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i64, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1037, ptr %slot188, align 8
  %v1038 = load i64, ptr %slot15, align 8
  store i64 %v1038, ptr %slot189, align 8
  %v1039 = load i64, ptr %slot188, align 8
  %v1040 = load i64, ptr %slot189, align 8
  %p1041 = inttoptr i64 %v1039 to ptr
  %p1042 = inttoptr i64 %v1040 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1042, ptr %p1041, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v1043 = load i64, ptr %slot10, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  store i32 2, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  %v1045 = load i64, ptr %slot9, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i32 1, ptr %p1046, align 4, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot189, align 8
  %v1048 = load i64, ptr %slot21, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  store i64 %v1047, ptr %p1049, align 8, !alias.scope !3, !noalias !4
  %v1050 = load i64, ptr %slot20, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %ld1052 = load i64, ptr %p1051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1052, ptr %slot190, align 8
  %v1053 = load i64, ptr %slot21, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  %ld1055 = load i64, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1055, ptr %slot191, align 8
  %v1056 = load i64, ptr %slot1, align 8
  %v1057 = load i64, ptr %slot190, align 8
  %v1058 = load i64, ptr %slot191, align 8
  %call1059 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v1056, i64 %v1057, i64 %v1058) nomerge, !dbg !132
  store i64 %call1059, ptr %slot192, align 8
  %v1060 = load i64, ptr %slot192, align 8
  %v1061 = load i64, ptr %slot20, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i64 %v1060, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot7, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %ld1065 = load i32, ptr %p1064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1065, ptr %slot193, align 8
  %v1066 = load i32, ptr %slot193, align 8
  %cv1067 = zext i32 %v1066 to i64
  %cond1068 = icmp ne i64 %cv1067, 0
  br i1 %cond1068, label %bb_rcslotdrop254, label %bb_rcslotdone254
bb_rcslotdrop254:
  %v1069 = load i64, ptr %slot7, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i32 0, ptr %p1070, align 4, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot14, align 8
  store i64 %v1071, ptr %slot194, align 8
  %v1072 = load i64, ptr %slot8, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i32, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1074, ptr %slot195, align 8
  %v1075 = load i32, ptr %slot195, align 8
  %op1076 = and i32 %v1075, 28
  store i32 %op1076, ptr %slot196, align 8
  %v1077 = load i32, ptr %slot196, align 8
  %cv1078 = zext i32 %v1077 to i64
  %cond1079 = icmp ne i64 %cv1078, 0
  br i1 %cond1079, label %bb_rcslotrole254, label %bb_rcslotowner254
bb_rcslotrole254:
  %v1080 = load i64, ptr %slot33, align 8
  store i64 %v1080, ptr %slot197, align 8
  %v1081 = load i64, ptr %slot197, align 8
  %v1082 = load i64, ptr %slot194, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1081, i64 %v1082) nomerge, !dbg !132
  br label %bb_rcslotdone254
bb_rcslotowner254:
  %v1083 = load i64, ptr %slot33, align 8
  store i64 %v1083, ptr %slot198, align 8
  %v1084 = load i64, ptr %slot198, align 8
  %v1085 = load i64, ptr %slot194, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1084, i64 %v1085) nomerge, !dbg !132
  br label %bb_rcslotdone254
bb_rcslotdone254:
  %v1086 = load i64, ptr %slot9, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  %ld1088 = load i32, ptr %p1087, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1088, ptr %slot199, align 8
  %v1089 = load i32, ptr %slot199, align 8
  %cv1090 = zext i32 %v1089 to i64
  %cond1091 = icmp ne i64 %cv1090, 0
  br i1 %cond1091, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v1092 = load i64, ptr %slot9, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  store i32 0, ptr %p1093, align 4, !alias.scope !3, !noalias !4
  %v1094 = load i64, ptr %slot15, align 8
  store i64 %v1094, ptr %slot200, align 8
  %v1095 = load i64, ptr %slot10, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %ld1097 = load i32, ptr %p1096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1097, ptr %slot201, align 8
  %v1098 = load i32, ptr %slot201, align 8
  %op1099 = and i32 %v1098, 28
  store i32 %op1099, ptr %slot202, align 8
  %v1100 = load i32, ptr %slot202, align 8
  %cv1101 = zext i32 %v1100 to i64
  %cond1102 = icmp ne i64 %cv1101, 0
  br i1 %cond1102, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v1103 = load i64, ptr %slot33, align 8
  store i64 %v1103, ptr %slot203, align 8
  %v1104 = load i64, ptr %slot203, align 8
  %v1105 = load i64, ptr %slot200, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1104, i64 %v1105) nomerge, !dbg !132
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v1106 = load i64, ptr %slot33, align 8
  store i64 %v1106, ptr %slot204, align 8
  %v1107 = load i64, ptr %slot204, align 8
  %v1108 = load i64, ptr %slot200, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1107, i64 %v1108) nomerge, !dbg !132
  br label %bb_rcslotdone263
bb_rcslotdone263:
  %v1109 = load i64, ptr %slot28, align 8
  store i64 %v1109, ptr %slot205, align 8
  %v1110 = load i64, ptr %slot205, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i64 0, ptr %p1111, align 8, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot205, align 8
  %p1114 = inttoptr i64 %v1112 to ptr
  %gep1115 = getelementptr i8, ptr %p1114, i64 8
  %op1113 = ptrtoint ptr %gep1115 to i64
  store i64 %op1113, ptr %slot206, align 8
  %v1116 = load i64, ptr %slot206, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  store i64 0, ptr %p1117, align 8, !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot205, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i32 0, ptr %p1119, align 4, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot13, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i32 1, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  %v1122 = load i64, ptr %slot20, align 8
  store i64 %v1122, ptr %slot207, align 8
  %v1123 = load i64, ptr %slot205, align 8
  %p1125 = inttoptr i64 %v1123 to ptr
  %gep1126 = getelementptr i8, ptr %p1125, i64 8
  %op1124 = ptrtoint ptr %gep1126 to i64
  store i64 %op1124, ptr %slot208, align 8
  %v1127 = load i64, ptr %slot34, align 8
  store i64 %v1127, ptr %slot209, align 8
  %v1128 = load i64, ptr %slot207, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i64, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1130, ptr %slot210, align 8
  %v1131 = load i64, ptr %slot210, align 8
  %v1132 = load i64, ptr %slot208, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i64 %v1131, ptr %p1133, align 8, !alias.scope !3, !noalias !4
  %v1134 = load i64, ptr %slot205, align 8
  %v1135 = load i64, ptr %slot20, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  store i64 %v1134, ptr %p1136, align 8, !alias.scope !3, !noalias !4
  %v1137 = load i64, ptr %slot20, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %ld1139 = load i64, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1139, ptr %slot211, align 8
  %v1140 = load i64, ptr %slot7, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot212, align 8
  %v1143 = load i32, ptr %slot212, align 8
  %cv1144 = zext i32 %v1143 to i64
  %cond1145 = icmp ne i64 %cv1144, 0
  br i1 %cond1145, label %bb_rcslotdrop281, label %bb_rcslotdone281
bb_rcslotdrop281:
  %v1146 = load i64, ptr %slot7, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 0, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone281
bb_rcslotdone281:
  %v1148 = load i64, ptr %slot5, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i32, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1150, ptr %slot213, align 8
  %v1151 = load i32, ptr %slot213, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcslotdrop284, label %bb_rcslotdone284
bb_rcslotdrop284:
  %v1154 = load i64, ptr %slot5, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i32 0, ptr %p1155, align 4, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot18, align 8
  store i64 %v1156, ptr %slot214, align 8
  %v1157 = load i64, ptr %slot6, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  %ld1159 = load i32, ptr %p1158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1159, ptr %slot215, align 8
  %v1160 = load i32, ptr %slot215, align 8
  %op1161 = and i32 %v1160, 28
  store i32 %op1161, ptr %slot216, align 8
  %v1162 = load i32, ptr %slot216, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcslotrole284, label %bb_rcslotowner284
bb_rcslotrole284:
  %v1165 = load i64, ptr %slot33, align 8
  store i64 %v1165, ptr %slot217, align 8
  %v1166 = load i64, ptr %slot217, align 8
  %v1167 = load i64, ptr %slot214, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1166, i64 %v1167) nomerge, !dbg !134
  br label %bb_rcslotdone284
bb_rcslotowner284:
  %v1168 = load i64, ptr %slot33, align 8
  store i64 %v1168, ptr %slot218, align 8
  %v1169 = load i64, ptr %slot218, align 8
  %v1170 = load i64, ptr %slot214, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1169, i64 %v1170) nomerge, !dbg !134
  br label %bb_rcslotdone284
bb_rcslotdone284:
  %v1171 = load i64, ptr %slot211, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  %ret1173 = load { i64, i64 }, ptr %p1172, align 8
  ret { i64, i64 } %ret1173
bb_i27:
  %v1174 = load i64, ptr %slot17, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot219, align 8
  %v1177 = load i64, ptr %slot219, align 8
  %v1178 = load i64, ptr %slot20, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i64 %v1177, ptr %p1179, align 8, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot20, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  %ld1182 = load i64, ptr %p1181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1182, ptr %slot220, align 8
  %v1183 = load i64, ptr %slot1, align 8
  %v1184 = load i64, ptr %slot220, align 8
  %call1185 = call { i64, i64 } @myl_f_aa651125ed1419784028686670fefe608324300d2757b0601fa06cae66ce5408(i64 %v1183, i64 %v1184) nomerge, !dbg !136
  store { i64, i64 } %call1185, ptr %callresult222, align 8
  %addr1186 = ptrtoint ptr %callresult222 to i64
  store i64 %addr1186, ptr %slot221, align 8
  %v1187 = load i64, ptr %slot221, align 8
  %v1188 = load i64, ptr %slot20, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i64 %v1187, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  %v1190 = load i64, ptr %slot7, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  %ld1192 = load i32, ptr %p1191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1192, ptr %slot223, align 8
  %v1193 = load i32, ptr %slot223, align 8
  %cv1194 = zext i32 %v1193 to i64
  %cond1195 = icmp ne i64 %cv1194, 0
  br i1 %cond1195, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v1196 = load i64, ptr %slot7, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  store i32 0, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  %v1198 = load i64, ptr %slot14, align 8
  store i64 %v1198, ptr %slot224, align 8
  %v1199 = load i64, ptr %slot8, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %ld1201 = load i32, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1201, ptr %slot225, align 8
  %v1202 = load i32, ptr %slot225, align 8
  %op1203 = and i32 %v1202, 28
  store i32 %op1203, ptr %slot226, align 8
  %v1204 = load i32, ptr %slot226, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcslotrole305, label %bb_rcslotowner305
bb_rcslotrole305:
  %v1207 = load i64, ptr %slot33, align 8
  store i64 %v1207, ptr %slot227, align 8
  %v1208 = load i64, ptr %slot227, align 8
  %v1209 = load i64, ptr %slot224, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1208, i64 %v1209) nomerge, !dbg !136
  br label %bb_rcslotdone305
bb_rcslotowner305:
  %v1210 = load i64, ptr %slot33, align 8
  store i64 %v1210, ptr %slot228, align 8
  %v1211 = load i64, ptr %slot228, align 8
  %v1212 = load i64, ptr %slot224, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1211, i64 %v1212) nomerge, !dbg !136
  br label %bb_rcslotdone305
bb_rcslotdone305:
  %v1213 = load i64, ptr %slot20, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i64, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1215, ptr %slot229, align 8
  %v1216 = load i64, ptr %slot229, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %ld1218 = load i32, ptr %p1217, align 4
  %ext1219 = zext i32 %ld1218 to i64
  store i64 %ext1219, ptr %slot230, align 8
  %v1220 = load i64, ptr %slot230, align 8
  %cmp1221 = icmp eq i64 %v1220, 1
  %cv1222 = zext i1 %cmp1221 to i64
  store i64 %cv1222, ptr %slot231, align 8
  %v1223 = load i64, ptr %slot231, align 8
  %cond1224 = icmp ne i64 %v1223, 0
  br i1 %cond1224, label %bb_errtrace314, label %bb_errtraced314
bb_errtrace314:
  %p1225 = inttoptr i64 ptrtoint (ptr @myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1225, i64 8589934621) "call-inline-cost"="0", !dbg !138
  br label %bb_errtraced314
bb_errtraced314:
  %v1226 = load i64, ptr %slot7, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %ld1228 = load i32, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1228, ptr %slot232, align 8
  %v1229 = load i32, ptr %slot232, align 8
  %cv1230 = zext i32 %v1229 to i64
  %cond1231 = icmp ne i64 %cv1230, 0
  br i1 %cond1231, label %bb_rcslotdrop317, label %bb_rcslotdone317
bb_rcslotdrop317:
  %v1232 = load i64, ptr %slot7, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i32 0, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone317
bb_rcslotdone317:
  %v1234 = load i64, ptr %slot5, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  %ld1236 = load i32, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1236, ptr %slot233, align 8
  %v1237 = load i32, ptr %slot233, align 8
  %cv1238 = zext i32 %v1237 to i64
  %cond1239 = icmp ne i64 %cv1238, 0
  br i1 %cond1239, label %bb_rcslotdrop320, label %bb_rcslotdone320
bb_rcslotdrop320:
  %v1240 = load i64, ptr %slot5, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i32 0, ptr %p1241, align 4, !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot18, align 8
  store i64 %v1242, ptr %slot234, align 8
  %v1243 = load i64, ptr %slot6, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %ld1245 = load i32, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1245, ptr %slot235, align 8
  %v1246 = load i32, ptr %slot235, align 8
  %op1247 = and i32 %v1246, 28
  store i32 %op1247, ptr %slot236, align 8
  %v1248 = load i32, ptr %slot236, align 8
  %cv1249 = zext i32 %v1248 to i64
  %cond1250 = icmp ne i64 %cv1249, 0
  br i1 %cond1250, label %bb_rcslotrole320, label %bb_rcslotowner320
bb_rcslotrole320:
  %v1251 = load i64, ptr %slot33, align 8
  store i64 %v1251, ptr %slot237, align 8
  %v1252 = load i64, ptr %slot237, align 8
  %v1253 = load i64, ptr %slot234, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1252, i64 %v1253) nomerge, !dbg !138
  br label %bb_rcslotdone320
bb_rcslotowner320:
  %v1254 = load i64, ptr %slot33, align 8
  store i64 %v1254, ptr %slot238, align 8
  %v1255 = load i64, ptr %slot238, align 8
  %v1256 = load i64, ptr %slot234, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1255, i64 %v1256) nomerge, !dbg !138
  br label %bb_rcslotdone320
bb_rcslotdone320:
  %v1257 = load i64, ptr %slot229, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ret1259 = load { i64, i64 }, ptr %p1258, align 8
  ret { i64, i64 } %ret1259
bb_failure:
  %v1260 = load i64, ptr %slot4, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  call void @llvm.memset.p0.i64(ptr %p1261, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !138
  %v1262 = load i64, ptr %slot4, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ret1264 = load { i64, i64 }, ptr %p1263, align 8
  ret { i64, i64 } %ret1264
bb_entry_failure:
  %v1265 = load i64, ptr %slot4, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  call void @llvm.memset.p0.i64(ptr %p1266, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !138
  %v1267 = load i64, ptr %slot4, align 8
  %p1268 = inttoptr i64 %v1267 to ptr
  %ret1269 = load { i64, i64 }, ptr %p1268, align 8
  ret { i64, i64 } %ret1269
}

@myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64, i64, i64)
declare { i64, i64 } @myl_f_aa651125ed1419784028686670fefe608324300d2757b0601fa06cae66ce5408(i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)
declare i32 @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7", linkageName: "myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5697256573151855721, i64 0, !"myl_f_9cef08ae8b89723dc460b4eb5b6f6b942ceec1be2d3d69972fd63f8d784cfef7"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!116 = !DILocation(line: 9, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!120 = !DILocation(line: 13, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!128 = !DILocation(line: 23, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!130 = !DILocation(line: 24, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!132 = !DILocation(line: 25, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!134 = !DILocation(line: 27, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!136 = !DILocation(line: 29, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!138 = !DILocation(line: 30, column: 0, scope: !139)
