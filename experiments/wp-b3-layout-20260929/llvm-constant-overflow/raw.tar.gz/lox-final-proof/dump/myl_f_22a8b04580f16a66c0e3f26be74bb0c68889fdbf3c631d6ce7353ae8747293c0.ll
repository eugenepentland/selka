target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %callresult22 = alloca [88 x i8], align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v123 = load i64, ptr %slot1, align 8
  %op124 = add i64 %v123, 32
  store i64 %op124, ptr %slot3, align 8
  %mem125 = alloca i8, i64 24, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot4, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot5, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot6, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot7, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot8, align 8
  %mem135 = alloca i8, i64 392, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot9, align 8
  %mem137 = alloca i8, i64 392, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot10, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot11, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot12, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot13, align 8
  %v145 = load i64, ptr %slot1, align 8
  %op146 = add i64 %v145, 64
  store i64 %op146, ptr %slot14, align 8
  %v147 = load i64, ptr %slot14, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !4, !noalias !3
  store i64 %ld149, ptr %slot15, align 8
  %stack150 = call ptr @llvm.stacksave()
  %stackaddr151 = ptrtoint ptr %stack150 to i64
  %v152 = load i64, ptr %slot15, align 8
  %cmp153 = icmp ult i64 %stackaddr151, %v152
  %cv154 = zext i1 %cmp153 to i64
  store i64 %cv154, ptr %slot16, align 8
  %v155 = load i64, ptr %slot16, align 8
  %cond156 = icmp ne i64 %v155, 0
  br i1 %cond156, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v157 = load i64, ptr %slot1, align 8
  %p158 = inttoptr i64 %v157 to ptr
  call void @myl_qbe_fail_frame(ptr %p158) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v159 = load i64, ptr %slot2, align 8
  %v160 = load i64, ptr %slot11, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot1, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %call164 = call ptr @myl_qbe_heap(ptr %p163) nomerge, !dbg !112
  %calladdr165 = ptrtoint ptr %call164 to i64
  store i64 %calladdr165, ptr %slot17, align 8
  %v166 = load i64, ptr %slot1, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %call168 = call i64 @myl_qbe_region_mark(ptr %p167) nomerge, !dbg !112
  store i64 %call168, ptr %slot18, align 8
  %v169 = load i64, ptr %slot5, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i32 0, ptr %p170, align 4, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot6, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i32 0, ptr %p172, align 4, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot7, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i32 0, ptr %p174, align 4, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot8, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i32 0, ptr %p176, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v177 = load i64, ptr %slot11, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot19, align 8
  %v180 = load i64, ptr %slot19, align 8
  %v181 = load i64, ptr %slot12, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot12, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot20, align 8
  %v186 = load i64, ptr %slot1, align 8
  %v187 = load i64, ptr %slot20, align 8
  call void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %callresult22, i64 %v186, i64 %v187) nomerge, !dbg !114
  %addr188 = ptrtoint ptr %callresult22 to i64
  store i64 %addr188, ptr %slot21, align 8
  %v189 = load i64, ptr %slot21, align 8
  %v190 = load i64, ptr %slot12, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 %v189, ptr %p191, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot12, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ld194 = load i64, ptr %p193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld194, ptr %slot23, align 8
  %v195 = load i64, ptr %slot10, align 8
  store i64 %v195, ptr %slot24, align 8
  %v196 = load i64, ptr %slot23, align 8
  %v197 = load i64, ptr %slot24, align 8
  %p198 = inttoptr i64 %v196 to ptr
  %p199 = inttoptr i64 %v197 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p199, ptr %p198, i64 88, i1 false)
  %v200 = load i64, ptr %slot8, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i32 2, ptr %p201, align 4, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot7, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i32 1, ptr %p203, align 4, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot5, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i32, ptr %p205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld206, ptr %slot25, align 8
  %v207 = load i32, ptr %slot25, align 8
  %cv208 = zext i32 %v207 to i64
  %cond209 = icmp ne i64 %cv208, 0
  br i1 %cond209, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v210 = load i64, ptr %slot5, align 8
  %p211 = inttoptr i64 %v210 to ptr
  store i32 0, ptr %p211, align 4, !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot9, align 8
  store i64 %v212, ptr %slot26, align 8
  %v213 = load i64, ptr %slot6, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i32, ptr %p214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld215, ptr %slot27, align 8
  %v216 = load i32, ptr %slot27, align 8
  %op217 = and i32 %v216, 28
  store i32 %op217, ptr %slot28, align 8
  %v218 = load i32, ptr %slot28, align 8
  %cv219 = zext i32 %v218 to i64
  %cond220 = icmp ne i64 %cv219, 0
  br i1 %cond220, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v221 = load i64, ptr %slot17, align 8
  store i64 %v221, ptr %slot29, align 8
  %v222 = load i64, ptr %slot29, align 8
  %v223 = load i64, ptr %slot26, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v222, i64 %v223) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v224 = load i64, ptr %slot17, align 8
  store i64 %v224, ptr %slot30, align 8
  %v225 = load i64, ptr %slot30, align 8
  %v226 = load i64, ptr %slot26, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v225, i64 %v226) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v227 = load i64, ptr %slot9, align 8
  store i64 %v227, ptr %slot31, align 8
  %v228 = load i64, ptr %slot10, align 8
  store i64 %v228, ptr %slot32, align 8
  %v229 = load i64, ptr %slot32, align 8
  %v230 = load i64, ptr %slot31, align 8
  %p231 = inttoptr i64 %v229 to ptr
  %p232 = inttoptr i64 %v230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p232, ptr %p231, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot6, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i32 2, ptr %p234, align 4, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot8, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i32, ptr %p236, align 4, !alias.scope !3, !noalias !4
  store i32 %ld237, ptr %slot33, align 8
  %v238 = load i32, ptr %slot33, align 8
  %v239 = load i64, ptr %slot6, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i32 %v238, ptr %p240, align 4, !alias.scope !3, !noalias !4
  %v241 = load i64, ptr %slot7, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i32 0, ptr %p242, align 4, !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 1, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot31, align 8
  %v246 = load i64, ptr %slot12, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 %v245, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot12, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot34, align 8
  %v251 = load i64, ptr %slot34, align 8
  %op252 = add i64 %v251, 0
  store i64 %op252, ptr %slot35, align 8
  %v253 = load i64, ptr %slot35, align 8
  %v254 = load i64, ptr %slot12, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot12, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot36, align 8
  %v259 = load i64, ptr %slot10, align 8
  store i64 %v259, ptr %slot37, align 8
  %v260 = load i64, ptr %slot17, align 8
  %v261 = load i64, ptr %slot37, align 8
  %v262 = load i64, ptr %slot36, align 8
  %call263 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v260, i64 %v261, i64 %v262) nomerge, !dbg !116
  store i32 %call263, ptr %slot38, align 8
  %v264 = load i32, ptr %slot38, align 8
  %cv265 = zext i32 %v264 to i64
  %cond266 = icmp ne i64 %cv265, 0
  br i1 %cond266, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %v267 = load i64, ptr %slot17, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %call269 = call i32 @myl_rc_take_failure(ptr %p268) nomerge, !dbg !116
  store i32 %call269, ptr %slot39, align 8
  %v270 = load i64, ptr %slot1, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %v272 = load i32, ptr %slot39, align 8
  %call273 = call i32 @myl_qbe_rc_status(ptr %p271, i32 %v272) nomerge, !dbg !116
  store i32 %call273, ptr %slot40, align 8
  br label %bb_failure
bb_rcsuccess37:
  %v274 = load i64, ptr %slot8, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i32 2, ptr %p275, align 4, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot8, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i32 16, ptr %p277, align 4, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot7, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i32 1, ptr %p279, align 4, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot5, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i32, ptr %p281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld282, ptr %slot41, align 8
  %v283 = load i32, ptr %slot41, align 8
  %cv284 = zext i32 %v283 to i64
  %cond285 = icmp ne i64 %cv284, 0
  br i1 %cond285, label %bb_rcslotdrop45, label %bb_rcslotdone45
bb_rcslotdrop45:
  %v286 = load i64, ptr %slot5, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i32 0, ptr %p287, align 4, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot9, align 8
  store i64 %v288, ptr %slot42, align 8
  %v289 = load i64, ptr %slot6, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i32, ptr %p290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld291, ptr %slot43, align 8
  %v292 = load i32, ptr %slot43, align 8
  %op293 = and i32 %v292, 28
  store i32 %op293, ptr %slot44, align 8
  %v294 = load i32, ptr %slot44, align 8
  %cv295 = zext i32 %v294 to i64
  %cond296 = icmp ne i64 %cv295, 0
  br i1 %cond296, label %bb_rcslotrole45, label %bb_rcslotowner45
bb_rcslotrole45:
  %v297 = load i64, ptr %slot17, align 8
  store i64 %v297, ptr %slot45, align 8
  %v298 = load i64, ptr %slot45, align 8
  %v299 = load i64, ptr %slot42, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v298, i64 %v299) nomerge, !dbg !116
  br label %bb_rcslotdone45
bb_rcslotowner45:
  %v300 = load i64, ptr %slot17, align 8
  store i64 %v300, ptr %slot46, align 8
  %v301 = load i64, ptr %slot46, align 8
  %v302 = load i64, ptr %slot42, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v301, i64 %v302) nomerge, !dbg !116
  br label %bb_rcslotdone45
bb_rcslotdone45:
  %v303 = load i64, ptr %slot9, align 8
  store i64 %v303, ptr %slot47, align 8
  %v304 = load i64, ptr %slot10, align 8
  store i64 %v304, ptr %slot48, align 8
  %v305 = load i64, ptr %slot48, align 8
  %v306 = load i64, ptr %slot47, align 8
  %p307 = inttoptr i64 %v305 to ptr
  %p308 = inttoptr i64 %v306 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p308, ptr %p307, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot6, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i32 2, ptr %p310, align 4, !alias.scope !3, !noalias !4
  %v311 = load i64, ptr %slot8, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %ld313 = load i32, ptr %p312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld313, ptr %slot49, align 8
  %v314 = load i32, ptr %slot49, align 8
  %v315 = load i64, ptr %slot6, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i32 %v314, ptr %p316, align 4, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot7, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 0, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot5, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 1, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot47, align 8
  %v322 = load i64, ptr %slot12, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i64 %v321, ptr %p323, align 8, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot12, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %ld326 = load i64, ptr %p325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld326, ptr %slot50, align 8
  %v327 = load i64, ptr %slot50, align 8
  %op328 = add i64 %v327, 16
  store i64 %op328, ptr %slot51, align 8
  %v329 = load i64, ptr %slot51, align 8
  %v330 = load i64, ptr %slot12, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i64 %v329, ptr %p331, align 8, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot12, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i64, ptr %p333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld334, ptr %slot52, align 8
  %v335 = load i64, ptr %slot10, align 8
  store i64 %v335, ptr %slot53, align 8
  %v336 = load i64, ptr %slot17, align 8
  %v337 = load i64, ptr %slot53, align 8
  %v338 = load i64, ptr %slot52, align 8
  %call339 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64 %v336, i64 %v337, i64 %v338) nomerge, !dbg !118
  store i32 %call339, ptr %slot54, align 8
  %v340 = load i32, ptr %slot54, align 8
  %cv341 = zext i32 %v340 to i64
  %cond342 = icmp ne i64 %cv341, 0
  br i1 %cond342, label %bb_rcsuccess65, label %bb_rcfailure65
bb_rcfailure65:
  %v343 = load i64, ptr %slot17, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %call345 = call i32 @myl_rc_take_failure(ptr %p344) nomerge, !dbg !118
  store i32 %call345, ptr %slot55, align 8
  %v346 = load i64, ptr %slot1, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %v348 = load i32, ptr %slot55, align 8
  %call349 = call i32 @myl_qbe_rc_status(ptr %p347, i32 %v348) nomerge, !dbg !118
  store i32 %call349, ptr %slot56, align 8
  br label %bb_failure
bb_rcsuccess65:
  %v350 = load i64, ptr %slot8, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 2, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot8, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 16, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot7, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i32 1, ptr %p355, align 4, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot5, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i32, ptr %p357, align 4, !alias.scope !3, !noalias !4
  store i32 %ld358, ptr %slot57, align 8
  %v359 = load i32, ptr %slot57, align 8
  %cv360 = zext i32 %v359 to i64
  %cond361 = icmp ne i64 %cv360, 0
  br i1 %cond361, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v362 = load i64, ptr %slot5, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i32 0, ptr %p363, align 4, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot9, align 8
  store i64 %v364, ptr %slot58, align 8
  %v365 = load i64, ptr %slot6, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i32, ptr %p366, align 4, !alias.scope !3, !noalias !4
  store i32 %ld367, ptr %slot59, align 8
  %v368 = load i32, ptr %slot59, align 8
  %op369 = and i32 %v368, 28
  store i32 %op369, ptr %slot60, align 8
  %v370 = load i32, ptr %slot60, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v373 = load i64, ptr %slot17, align 8
  store i64 %v373, ptr %slot61, align 8
  %v374 = load i64, ptr %slot61, align 8
  %v375 = load i64, ptr %slot58, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v374, i64 %v375) nomerge, !dbg !118
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v376 = load i64, ptr %slot17, align 8
  store i64 %v376, ptr %slot62, align 8
  %v377 = load i64, ptr %slot62, align 8
  %v378 = load i64, ptr %slot58, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v377, i64 %v378) nomerge, !dbg !118
  br label %bb_rcslotdone73
bb_rcslotdone73:
  %v379 = load i64, ptr %slot9, align 8
  store i64 %v379, ptr %slot63, align 8
  %v380 = load i64, ptr %slot10, align 8
  store i64 %v380, ptr %slot64, align 8
  %v381 = load i64, ptr %slot64, align 8
  %v382 = load i64, ptr %slot63, align 8
  %p383 = inttoptr i64 %v381 to ptr
  %p384 = inttoptr i64 %v382 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p384, ptr %p383, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot6, align 8
  %p386 = inttoptr i64 %v385 to ptr
  store i32 2, ptr %p386, align 4, !alias.scope !3, !noalias !4
  %v387 = load i64, ptr %slot8, align 8
  %p388 = inttoptr i64 %v387 to ptr
  %ld389 = load i32, ptr %p388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld389, ptr %slot65, align 8
  %v390 = load i32, ptr %slot65, align 8
  %v391 = load i64, ptr %slot6, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i32 %v390, ptr %p392, align 4, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot7, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i32 0, ptr %p394, align 4, !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot5, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i32 1, ptr %p396, align 4, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot63, align 8
  %v398 = load i64, ptr %slot12, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 %v397, ptr %p399, align 8, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot12, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i64, ptr %p401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld402, ptr %slot66, align 8
  %v403 = load i64, ptr %slot12, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot67, align 8
  %v406 = load i64, ptr %slot5, align 8
  %p407 = inttoptr i64 %v406 to ptr
  %ld408 = load i32, ptr %p407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld408, ptr %slot68, align 8
  %v409 = load i64, ptr %slot6, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i32, ptr %p410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld411, ptr %slot69, align 8
  %v412 = load i32, ptr %slot69, align 8
  %op413 = and i32 %v412, 24
  store i32 %op413, ptr %slot69, align 8
  %v414 = load i32, ptr %slot69, align 8
  %cmp415 = icmp eq i32 %v414, 0
  %cv416 = zext i1 %cmp415 to i32
  store i32 %cv416, ptr %slot70, align 8
  %v417 = load i32, ptr %slot68, align 8
  %v418 = load i32, ptr %slot70, align 8
  %op419 = and i32 %v417, %v418
  store i32 %op419, ptr %slot71, align 8
  %v420 = load i32, ptr %slot71, align 8
  %cv421 = zext i32 %v420 to i64
  %cond422 = icmp ne i64 %cv421, 0
  br i1 %cond422, label %bb_rctake90, label %bb_rccopy90
bb_rctake90:
  %v423 = load i64, ptr %slot10, align 8
  store i64 %v423, ptr %slot72, align 8
  %v424 = load i64, ptr %slot18, align 8
  store i64 %v424, ptr %slot73, align 8
  %v425 = load i64, ptr %slot67, align 8
  %v426 = load i64, ptr %slot72, align 8
  %op427 = sub i64 %v425, %v426
  store i64 %op427, ptr %slot74, align 8
  %v428 = load i64, ptr %slot72, align 8
  %v429 = load i64, ptr %slot67, align 8
  %op430 = sub i64 %v428, %v429
  store i64 %op430, ptr %slot75, align 8
  %v431 = load i64, ptr %slot74, align 8
  %cmp432 = icmp ult i64 %v431, 24
  %cv433 = zext i1 %cmp432 to i32
  store i32 %cv433, ptr %slot76, align 8
  %v434 = load i64, ptr %slot75, align 8
  %cmp435 = icmp ult i64 %v434, 24
  %cv436 = zext i1 %cmp435 to i32
  store i32 %cv436, ptr %slot77, align 8
  %v437 = load i32, ptr %slot76, align 8
  %v438 = load i32, ptr %slot77, align 8
  %op439 = or i32 %v437, %v438
  store i32 %op439, ptr %slot78, align 8
  %v440 = load i32, ptr %slot78, align 8
  %cv441 = zext i32 %v440 to i64
  %cond442 = icmp ne i64 %cv441, 0
  br i1 %cond442, label %bb_rcmoveslow99, label %bb_rcmovecheck99
bb_rcmovecheck99:
  %v443 = load i64, ptr %slot67, align 8
  %op444 = add i64 %v443, 0
  store i64 %op444, ptr %slot79, align 8
  %v445 = load i64, ptr %slot79, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ld447 = load i64, ptr %p446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld447, ptr %slot80, align 8
  %v448 = load i64, ptr %slot80, align 8
  %cmp449 = icmp ne i64 %v448, 0
  %cv450 = zext i1 %cmp449 to i32
  store i32 %cv450, ptr %slot81, align 8
  %v451 = load i32, ptr %slot81, align 8
  %cv452 = zext i32 %v451 to i64
  %cond453 = icmp ne i64 %cv452, 0
  br i1 %cond453, label %bb_rcmoveheader107, label %bb_rcmovenext107
bb_rcmoveheader107:
  %v454 = load i64, ptr %slot80, align 8
  %op455 = sub i64 %v454, 16
  store i64 %op455, ptr %slot82, align 8
  %v456 = load i64, ptr %slot80, align 8
  %p457 = inttoptr i64 %v456 to ptr
  %rgep458 = getelementptr i8, ptr %p457, i64 -16
  %ld459 = load i64, ptr %rgep458, align 8, !alias.scope !9, !noalias !10
  store i64 %ld459, ptr %slot83, align 8
  %v460 = load i64, ptr %slot83, align 8
  %op461 = and i64 %v460, 5764607523034234881
  store i64 %op461, ptr %slot84, align 8
  %v462 = load i64, ptr %slot84, align 8
  %cmp463 = icmp ne i64 %v462, 0
  %cv464 = zext i1 %cmp463 to i32
  store i32 %cv464, ptr %slot85, align 8
  %v465 = load i32, ptr %slot85, align 8
  %cv466 = zext i32 %v465 to i64
  %cond467 = icmp ne i64 %cv466, 0
  br i1 %cond467, label %bb_rcmoveslow99, label %bb_rcmovenext107
bb_rcmovenext107:
  %v468 = load i64, ptr %slot67, align 8
  %op469 = add i64 %v468, 8
  store i64 %op469, ptr %slot86, align 8
  %v470 = load i64, ptr %slot86, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %ld472 = load i64, ptr %p471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld472, ptr %slot87, align 8
  %v473 = load i64, ptr %slot87, align 8
  %cmp474 = icmp ne i64 %v473, 0
  %cv475 = zext i1 %cmp474 to i32
  store i32 %cv475, ptr %slot88, align 8
  %v476 = load i32, ptr %slot88, align 8
  %cv477 = zext i32 %v476 to i64
  %cond478 = icmp ne i64 %cv477, 0
  br i1 %cond478, label %bb_rcmoveheader115, label %bb_rcmovenext115
bb_rcmoveheader115:
  %v479 = load i64, ptr %slot87, align 8
  %op480 = sub i64 %v479, 16
  store i64 %op480, ptr %slot89, align 8
  %v481 = load i64, ptr %slot87, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %rgep483 = getelementptr i8, ptr %p482, i64 -16
  %ld484 = load i64, ptr %rgep483, align 8, !alias.scope !9, !noalias !10
  store i64 %ld484, ptr %slot90, align 8
  %v485 = load i64, ptr %slot90, align 8
  %op486 = and i64 %v485, 5764607523034234881
  store i64 %op486, ptr %slot91, align 8
  %v487 = load i64, ptr %slot91, align 8
  %cmp488 = icmp ne i64 %v487, 0
  %cv489 = zext i1 %cmp488 to i32
  store i32 %cv489, ptr %slot92, align 8
  %v490 = load i32, ptr %slot92, align 8
  %cv491 = zext i32 %v490 to i64
  %cond492 = icmp ne i64 %cv491, 0
  br i1 %cond492, label %bb_rcmoveslow99, label %bb_rcmovenext115
bb_rcmovenext115:
  %v493 = load i64, ptr %slot67, align 8
  %op494 = add i64 %v493, 16
  store i64 %op494, ptr %slot93, align 8
  %v495 = load i64, ptr %slot93, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %ld497 = load i64, ptr %p496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld497, ptr %slot94, align 8
  %v498 = load i64, ptr %slot94, align 8
  %cmp499 = icmp ne i64 %v498, 0
  %cv500 = zext i1 %cmp499 to i32
  store i32 %cv500, ptr %slot95, align 8
  %v501 = load i32, ptr %slot95, align 8
  %cv502 = zext i32 %v501 to i64
  %cond503 = icmp ne i64 %cv502, 0
  br i1 %cond503, label %bb_rcmoveheader123, label %bb_rcmovenext123
bb_rcmoveheader123:
  %v504 = load i64, ptr %slot94, align 8
  %op505 = sub i64 %v504, 16
  store i64 %op505, ptr %slot96, align 8
  %v506 = load i64, ptr %slot94, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %rgep508 = getelementptr i8, ptr %p507, i64 -16
  %ld509 = load i64, ptr %rgep508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld509, ptr %slot97, align 8
  %v510 = load i64, ptr %slot97, align 8
  %op511 = and i64 %v510, 5764607523034234881
  store i64 %op511, ptr %slot98, align 8
  %v512 = load i64, ptr %slot98, align 8
  %cmp513 = icmp ne i64 %v512, 0
  %cv514 = zext i1 %cmp513 to i32
  store i32 %cv514, ptr %slot99, align 8
  %v515 = load i32, ptr %slot99, align 8
  %cv516 = zext i32 %v515 to i64
  %cond517 = icmp ne i64 %cv516, 0
  br i1 %cond517, label %bb_rcmoveslow99, label %bb_rcmovenext123
bb_rcmovenext123:
  %v518 = load i64, ptr %slot67, align 8
  %v519 = load i64, ptr %slot72, align 8
  %p520 = inttoptr i64 %v518 to ptr
  %p521 = inttoptr i64 %v519 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p521, ptr %p520, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot67, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i64 0, ptr %p523, align 8, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot67, align 8
  %op525 = add i64 %v524, 8
  store i64 %op525, ptr %slot100, align 8
  %v526 = load i64, ptr %slot100, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 0, ptr %p527, align 8, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot67, align 8
  %op529 = add i64 %v528, 16
  store i64 %op529, ptr %slot101, align 8
  %v530 = load i64, ptr %slot101, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 0, ptr %p531, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved99
bb_rcmoveslow99:
  %v532 = load i64, ptr %slot17, align 8
  %v533 = load i64, ptr %slot72, align 8
  %v534 = load i64, ptr %slot67, align 8
  %v535 = load i64, ptr %slot73, align 8
  %cv536 = trunc i64 %v535 to i32
  %call537 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v532, i64 %v533, i64 %v534, i32 %cv536) nomerge, !dbg !120
  store i32 %call537, ptr %slot102, align 8
  %v538 = load i32, ptr %slot102, align 8
  %cv539 = zext i32 %v538 to i64
  %cond540 = icmp ne i64 %cv539, 0
  br i1 %cond540, label %bb_rcsuccess132, label %bb_rcfailure132
bb_rcfailure132:
  %v541 = load i64, ptr %slot17, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %call543 = call i32 @myl_rc_take_failure(ptr %p542) nomerge, !dbg !120
  store i32 %call543, ptr %slot103, align 8
  %v544 = load i64, ptr %slot1, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %v546 = load i32, ptr %slot103, align 8
  %call547 = call i32 @myl_qbe_rc_status(ptr %p545, i32 %v546) nomerge, !dbg !120
  store i32 %call547, ptr %slot104, align 8
  br label %bb_failure
bb_rcsuccess132:
  br label %bb_rcmoved99
bb_rcmoved99:
  %v548 = load i64, ptr %slot5, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i32 0, ptr %p549, align 4, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot8, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i32 2, ptr %p551, align 4, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot7, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i32 1, ptr %p553, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared90
bb_rccopy90:
  %v554 = load i64, ptr %slot10, align 8
  store i64 %v554, ptr %slot105, align 8
  %v555 = load i64, ptr %slot18, align 8
  store i64 %v555, ptr %slot106, align 8
  %v556 = load i64, ptr %slot17, align 8
  %v557 = load i64, ptr %slot105, align 8
  %v558 = load i64, ptr %slot67, align 8
  %v559 = load i64, ptr %slot106, align 8
  %cv560 = trunc i64 %v559 to i32
  %call561 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_retain(i64 %v556, i64 %v557, i64 %v558, i32 %cv560) nomerge, !dbg !120
  store i32 %call561, ptr %slot107, align 8
  %v562 = load i32, ptr %slot107, align 8
  %cv563 = zext i32 %v562 to i64
  %cond564 = icmp ne i64 %cv563, 0
  br i1 %cond564, label %bb_rcsuccess141, label %bb_rcfailure141
bb_rcfailure141:
  %v565 = load i64, ptr %slot17, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %call567 = call i32 @myl_rc_take_failure(ptr %p566) nomerge, !dbg !120
  store i32 %call567, ptr %slot108, align 8
  %v568 = load i64, ptr %slot1, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %v570 = load i32, ptr %slot108, align 8
  %call571 = call i32 @myl_qbe_rc_status(ptr %p569, i32 %v570) nomerge, !dbg !120
  store i32 %call571, ptr %slot109, align 8
  br label %bb_failure
bb_rcsuccess141:
  %v572 = load i64, ptr %slot8, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 2, ptr %p573, align 4, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot7, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i32 1, ptr %p575, align 4, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot5, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i32, ptr %p577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld578, ptr %slot110, align 8
  %v579 = load i32, ptr %slot110, align 8
  %cv580 = zext i32 %v579 to i64
  %cond581 = icmp ne i64 %cv580, 0
  br i1 %cond581, label %bb_rcslotdrop148, label %bb_rcslotdone148
bb_rcslotdrop148:
  %v582 = load i64, ptr %slot5, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i32 0, ptr %p583, align 4, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot9, align 8
  store i64 %v584, ptr %slot111, align 8
  %v585 = load i64, ptr %slot6, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i32, ptr %p586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld587, ptr %slot112, align 8
  %v588 = load i32, ptr %slot112, align 8
  %op589 = and i32 %v588, 28
  store i32 %op589, ptr %slot113, align 8
  %v590 = load i32, ptr %slot113, align 8
  %cv591 = zext i32 %v590 to i64
  %cond592 = icmp ne i64 %cv591, 0
  br i1 %cond592, label %bb_rcslotrole148, label %bb_rcslotowner148
bb_rcslotrole148:
  %v593 = load i64, ptr %slot17, align 8
  store i64 %v593, ptr %slot114, align 8
  %v594 = load i64, ptr %slot114, align 8
  %v595 = load i64, ptr %slot111, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v594, i64 %v595) nomerge, !dbg !120
  br label %bb_rcslotdone148
bb_rcslotowner148:
  %v596 = load i64, ptr %slot17, align 8
  store i64 %v596, ptr %slot115, align 8
  %v597 = load i64, ptr %slot115, align 8
  %v598 = load i64, ptr %slot111, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v597, i64 %v598) nomerge, !dbg !120
  br label %bb_rcslotdone148
bb_rcslotdone148:
  br label %bb_rcprepared90
bb_rcprepared90:
  %v599 = load i64, ptr %slot10, align 8
  store i64 %v599, ptr %slot116, align 8
  %v600 = load i64, ptr %slot7, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i32 0, ptr %p601, align 4, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot5, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i32, ptr %p603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld604, ptr %slot117, align 8
  %v605 = load i32, ptr %slot117, align 8
  %cv606 = zext i32 %v605 to i64
  %cond607 = icmp ne i64 %cv606, 0
  br i1 %cond607, label %bb_rcslotdrop159, label %bb_rcslotdone159
bb_rcslotdrop159:
  %v608 = load i64, ptr %slot5, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 0, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot9, align 8
  store i64 %v610, ptr %slot118, align 8
  %v611 = load i64, ptr %slot6, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i32, ptr %p612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld613, ptr %slot119, align 8
  %v614 = load i32, ptr %slot119, align 8
  %op615 = and i32 %v614, 28
  store i32 %op615, ptr %slot120, align 8
  %v616 = load i32, ptr %slot120, align 8
  %cv617 = zext i32 %v616 to i64
  %cond618 = icmp ne i64 %cv617, 0
  br i1 %cond618, label %bb_rcslotrole159, label %bb_rcslotowner159
bb_rcslotrole159:
  %v619 = load i64, ptr %slot17, align 8
  store i64 %v619, ptr %slot121, align 8
  %v620 = load i64, ptr %slot121, align 8
  %v621 = load i64, ptr %slot118, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v620, i64 %v621) nomerge, !dbg !120
  br label %bb_rcslotdone159
bb_rcslotowner159:
  %v622 = load i64, ptr %slot17, align 8
  store i64 %v622, ptr %slot122, align 8
  %v623 = load i64, ptr %slot122, align 8
  %v624 = load i64, ptr %slot118, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v623, i64 %v624) nomerge, !dbg !120
  br label %bb_rcslotdone159
bb_rcslotdone159:
  %v625 = load i64, ptr %slot116, align 8
  %p626 = inttoptr i64 %v625 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p626, i64 24, i1 false)
  ret void
bb_failure:
  %v627 = load i64, ptr %slot4, align 8
  %p628 = inttoptr i64 %v627 to ptr
  call void @llvm.memset.p0.i64(ptr %p628, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v629 = load i64, ptr %slot4, align 8
  %p630 = inttoptr i64 %v629 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p630, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v631 = load i64, ptr %slot4, align 8
  %p632 = inttoptr i64 %v631 to ptr
  call void @llvm.memset.p0.i64(ptr %p632, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v633 = load i64, ptr %slot4, align 8
  %p634 = inttoptr i64 %v633 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p634, i64 24, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0", linkageName: "myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1878645957804698817, i64 0, !"myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!118 = !DILocation(line: 4, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!120 = !DILocation(line: 5, column: 0, scope: !121)
