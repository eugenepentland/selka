target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_79660bd341bc9b50ab49ac4f20489237247b8fc00e2519ad08a896cefc3baeab(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %callresult24 = alloca [40 x i8], align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %callresult57 = alloca [40 x i8], align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %callresult94 = alloca [40 x i8], align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %callresult180 = alloca [40 x i8], align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v200 = load i64, ptr %slot1, align 8
  %op201 = add i64 %v200, 32
  store i64 %op201, ptr %slot3, align 8
  %mem202 = alloca i8, i64 8, align 8
  %ptr203 = ptrtoint ptr %mem202 to i64
  store i64 %ptr203, ptr %slot4, align 8
  %mem204 = alloca i8, i64 8, align 8
  %ptr205 = ptrtoint ptr %mem204 to i64
  store i64 %ptr205, ptr %slot5, align 8
  %mem206 = alloca i8, i64 8, align 8
  %ptr207 = ptrtoint ptr %mem206 to i64
  store i64 %ptr207, ptr %slot6, align 8
  %mem208 = alloca i8, i64 8, align 8
  %ptr209 = ptrtoint ptr %mem208 to i64
  store i64 %ptr209, ptr %slot7, align 8
  %mem210 = alloca i8, i64 312, align 8
  %ptr211 = ptrtoint ptr %mem210 to i64
  store i64 %ptr211, ptr %slot8, align 8
  %mem212 = alloca i8, i64 312, align 8
  %ptr213 = ptrtoint ptr %mem212 to i64
  store i64 %ptr213, ptr %slot9, align 8
  %mem214 = alloca i8, i64 8, align 8
  %ptr215 = ptrtoint ptr %mem214 to i64
  store i64 %ptr215, ptr %slot10, align 8
  %mem216 = alloca i8, i64 8, align 8
  %ptr217 = ptrtoint ptr %mem216 to i64
  store i64 %ptr217, ptr %slot11, align 8
  %mem218 = alloca i8, i64 8, align 8
  %ptr219 = ptrtoint ptr %mem218 to i64
  store i64 %ptr219, ptr %slot12, align 8
  %mem220 = alloca i8, i64 40, align 8
  %ptr221 = ptrtoint ptr %mem220 to i64
  store i64 %ptr221, ptr %slot13, align 8
  %mem222 = alloca i8, i64 8, align 8
  %ptr223 = ptrtoint ptr %mem222 to i64
  store i64 %ptr223, ptr %slot14, align 8
  %mem224 = alloca i8, i64 40, align 8
  %ptr225 = ptrtoint ptr %mem224 to i64
  store i64 %ptr225, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem226 = alloca i8, i64 8, align 8
  %ptr227 = ptrtoint ptr %mem226 to i64
  store i64 %ptr227, ptr %slot16, align 8
  %v228 = load i64, ptr %slot1, align 8
  %op229 = add i64 %v228, 64
  store i64 %op229, ptr %slot17, align 8
  %v230 = load i64, ptr %slot17, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !4, !noalias !3
  store i64 %ld232, ptr %slot18, align 8
  %stack233 = call ptr @llvm.stacksave()
  %stackaddr234 = ptrtoint ptr %stack233 to i64
  %v235 = load i64, ptr %slot18, align 8
  %cmp236 = icmp ult i64 %stackaddr234, %v235
  %cv237 = zext i1 %cmp236 to i64
  store i64 %cv237, ptr %slot19, align 8
  %v238 = load i64, ptr %slot19, align 8
  %cond239 = icmp ne i64 %v238, 0
  br i1 %cond239, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v240 = load i64, ptr %slot1, align 8
  %p241 = inttoptr i64 %v240 to ptr
  call void @myl_qbe_fail_frame(ptr %p241) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v242 = load i64, ptr %slot2, align 8
  %v243 = load i64, ptr %slot10, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 %v242, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot1, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %call247 = call ptr @myl_qbe_heap(ptr %p246) nomerge, !dbg !112
  %calladdr248 = ptrtoint ptr %call247 to i64
  store i64 %calladdr248, ptr %slot20, align 8
  %v249 = load i64, ptr %slot4, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i32 0, ptr %p250, align 4, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot5, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 0, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot6, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 0, ptr %p254, align 4, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot7, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i32 0, ptr %p256, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v257 = load i64, ptr %slot10, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot21, align 8
  %v260 = load i64, ptr %slot21, align 8
  %v261 = load i64, ptr %slot11, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i64 %v260, ptr %p262, align 8, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot11, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot22, align 8
  %v266 = load i64, ptr %slot1, align 8
  %v267 = load i64, ptr %slot22, align 8
  call void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8 %callresult24, i64 %v266, i64 %v267) nomerge, !dbg !114
  %addr268 = ptrtoint ptr %callresult24 to i64
  store i64 %addr268, ptr %slot23, align 8
  %v269 = load i64, ptr %slot23, align 8
  %v270 = load i64, ptr %slot11, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i64 %v269, ptr %p271, align 8, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot11, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld274, ptr %slot25, align 8
  %v275 = load i64, ptr %slot9, align 8
  store i64 %v275, ptr %slot26, align 8
  %v276 = load i64, ptr %slot25, align 8
  %v277 = load i64, ptr %slot26, align 8
  %p278 = inttoptr i64 %v276 to ptr
  %p279 = inttoptr i64 %v277 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p279, ptr %p278, i64 40, i1 false)
  %v280 = load i64, ptr %slot7, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 2, ptr %p281, align 4, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot6, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i32 1, ptr %p283, align 4, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot4, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i32, ptr %p285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld286, ptr %slot27, align 8
  %v287 = load i32, ptr %slot27, align 8
  %cv288 = zext i32 %v287 to i64
  %cond289 = icmp ne i64 %cv288, 0
  br i1 %cond289, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v290 = load i64, ptr %slot4, align 8
  %p291 = inttoptr i64 %v290 to ptr
  store i32 0, ptr %p291, align 4, !alias.scope !3, !noalias !4
  %v292 = load i64, ptr %slot8, align 8
  store i64 %v292, ptr %slot28, align 8
  %v293 = load i64, ptr %slot5, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i32, ptr %p294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld295, ptr %slot29, align 8
  %v296 = load i32, ptr %slot29, align 8
  %op297 = and i32 %v296, 28
  store i32 %op297, ptr %slot30, align 8
  %v298 = load i32, ptr %slot30, align 8
  %cv299 = zext i32 %v298 to i64
  %cond300 = icmp ne i64 %cv299, 0
  br i1 %cond300, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v301 = load i64, ptr %slot20, align 8
  store i64 %v301, ptr %slot31, align 8
  %v302 = load i64, ptr %slot31, align 8
  %v303 = load i64, ptr %slot28, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v302, i64 %v303) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v304 = load i64, ptr %slot20, align 8
  store i64 %v304, ptr %slot32, align 8
  %v305 = load i64, ptr %slot32, align 8
  %v306 = load i64, ptr %slot28, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v305, i64 %v306) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v307 = load i64, ptr %slot8, align 8
  store i64 %v307, ptr %slot33, align 8
  %v308 = load i64, ptr %slot9, align 8
  store i64 %v308, ptr %slot34, align 8
  %v309 = load i64, ptr %slot34, align 8
  %v310 = load i64, ptr %slot33, align 8
  %p311 = inttoptr i64 %v309 to ptr
  %p312 = inttoptr i64 %v310 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p312, ptr %p311, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot5, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i32 2, ptr %p314, align 4, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot7, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i32, ptr %p316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld317, ptr %slot35, align 8
  %v318 = load i32, ptr %slot35, align 8
  %v319 = load i64, ptr %slot5, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 %v318, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot6, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 0, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot4, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 1, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot33, align 8
  %v326 = load i64, ptr %slot11, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot4, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i32, ptr %p329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld330, ptr %slot36, align 8
  %v331 = load i32, ptr %slot36, align 8
  %cv332 = zext i32 %v331 to i64
  %cond333 = icmp ne i64 %cv332, 0
  br i1 %cond333, label %bb_rcslotdrop34, label %bb_rcslotdone34
bb_rcslotdrop34:
  %v334 = load i64, ptr %slot4, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i32 0, ptr %p335, align 4, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot8, align 8
  store i64 %v336, ptr %slot37, align 8
  %v337 = load i64, ptr %slot5, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i32, ptr %p338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld339, ptr %slot38, align 8
  %v340 = load i32, ptr %slot38, align 8
  %op341 = and i32 %v340, 28
  store i32 %op341, ptr %slot39, align 8
  %v342 = load i32, ptr %slot39, align 8
  %cv343 = zext i32 %v342 to i64
  %cond344 = icmp ne i64 %cv343, 0
  br i1 %cond344, label %bb_rcslotrole34, label %bb_rcslotowner34
bb_rcslotrole34:
  %v345 = load i64, ptr %slot20, align 8
  store i64 %v345, ptr %slot40, align 8
  %v346 = load i64, ptr %slot40, align 8
  %v347 = load i64, ptr %slot37, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v346, i64 %v347) nomerge, !dbg !116
  br label %bb_rcslotdone34
bb_rcslotowner34:
  %v348 = load i64, ptr %slot20, align 8
  store i64 %v348, ptr %slot41, align 8
  %v349 = load i64, ptr %slot41, align 8
  %v350 = load i64, ptr %slot37, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v349, i64 %v350) nomerge, !dbg !116
  br label %bb_rcslotdone34
bb_rcslotdone34:
  br label %bb_i3
bb_i3:
  %v351 = load i64, ptr %slot10, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot42, align 8
  %v354 = load i64, ptr %slot42, align 8
  %v355 = load i64, ptr %slot11, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i64 %v354, ptr %p356, align 8, !alias.scope !3, !noalias !4
  %v357 = load i64, ptr %slot11, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot43, align 8
  %v360 = load i64, ptr %slot1, align 8
  %v361 = load i64, ptr %slot43, align 8
  %call362 = call i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64 %v360, i64 %v361) nomerge, !dbg !118
  store i64 %call362, ptr %slot44, align 8
  %v363 = load i64, ptr %slot44, align 8
  %v364 = load i64, ptr %slot11, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot4, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i32, ptr %p367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld368, ptr %slot45, align 8
  %v369 = load i32, ptr %slot45, align 8
  %cv370 = zext i32 %v369 to i64
  %cond371 = icmp ne i64 %cv370, 0
  br i1 %cond371, label %bb_rcslotdrop46, label %bb_rcslotdone46
bb_rcslotdrop46:
  %v372 = load i64, ptr %slot4, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i32 0, ptr %p373, align 4, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot8, align 8
  store i64 %v374, ptr %slot46, align 8
  %v375 = load i64, ptr %slot5, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %ld377 = load i32, ptr %p376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld377, ptr %slot47, align 8
  %v378 = load i32, ptr %slot47, align 8
  %op379 = and i32 %v378, 28
  store i32 %op379, ptr %slot48, align 8
  %v380 = load i32, ptr %slot48, align 8
  %cv381 = zext i32 %v380 to i64
  %cond382 = icmp ne i64 %cv381, 0
  br i1 %cond382, label %bb_rcslotrole46, label %bb_rcslotowner46
bb_rcslotrole46:
  %v383 = load i64, ptr %slot20, align 8
  store i64 %v383, ptr %slot49, align 8
  %v384 = load i64, ptr %slot49, align 8
  %v385 = load i64, ptr %slot46, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v384, i64 %v385) nomerge, !dbg !118
  br label %bb_rcslotdone46
bb_rcslotowner46:
  %v386 = load i64, ptr %slot20, align 8
  store i64 %v386, ptr %slot50, align 8
  %v387 = load i64, ptr %slot50, align 8
  %v388 = load i64, ptr %slot46, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v387, i64 %v388) nomerge, !dbg !118
  br label %bb_rcslotdone46
bb_rcslotdone46:
  %v389 = load i64, ptr %slot11, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i64, ptr %p390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld391, ptr %slot51, align 8
  %v392 = load i64, ptr %slot51, align 8
  %op393 = xor i64 %v392, 1
  store i64 %op393, ptr %slot52, align 8
  %v394 = load i64, ptr %slot52, align 8
  %v395 = load i64, ptr %slot11, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 %v394, ptr %p396, align 8, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot11, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot53, align 8
  %v400 = load i64, ptr %slot53, align 8
  %cond401 = icmp ne i64 %v400, 0
  br i1 %cond401, label %bb_next56, label %bb_i71
bb_next56:
  %v402 = load i64, ptr %slot10, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot54, align 8
  %v405 = load i64, ptr %slot54, align 8
  %v406 = load i64, ptr %slot11, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot11, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot55, align 8
  %v411 = load i64, ptr %slot1, align 8
  %v412 = load i64, ptr %slot55, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult57, i64 %v411, i64 %v412) nomerge, !dbg !120
  %addr413 = ptrtoint ptr %callresult57 to i64
  store i64 %addr413, ptr %slot56, align 8
  %v414 = load i64, ptr %slot56, align 8
  %v415 = load i64, ptr %slot11, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot11, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot58, align 8
  %v420 = load i64, ptr %slot9, align 8
  store i64 %v420, ptr %slot59, align 8
  %v421 = load i64, ptr %slot20, align 8
  %v422 = load i64, ptr %slot59, align 8
  %v423 = load i64, ptr %slot58, align 8
  %call424 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v421, i64 %v422, i64 %v423) nomerge, !dbg !120
  store i32 %call424, ptr %slot60, align 8
  %v425 = load i32, ptr %slot60, align 8
  %cv426 = zext i32 %v425 to i64
  %cond427 = icmp ne i64 %cv426, 0
  br i1 %cond427, label %bb_rcsuccess62, label %bb_rcfailure62
bb_rcfailure62:
  %v428 = load i64, ptr %slot20, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %call430 = call i32 @myl_rc_take_failure(ptr %p429) nomerge, !dbg !120
  store i32 %call430, ptr %slot61, align 8
  %v431 = load i64, ptr %slot1, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %v433 = load i32, ptr %slot61, align 8
  %call434 = call i32 @myl_qbe_rc_status(ptr %p432, i32 %v433) nomerge, !dbg !120
  store i32 %call434, ptr %slot62, align 8
  br label %bb_failure
bb_rcsuccess62:
  %v435 = load i64, ptr %slot7, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i32 2, ptr %p436, align 4, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot7, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 16, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot6, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 1, ptr %p440, align 4, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot4, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i32, ptr %p442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld443, ptr %slot63, align 8
  %v444 = load i32, ptr %slot63, align 8
  %cv445 = zext i32 %v444 to i64
  %cond446 = icmp ne i64 %cv445, 0
  br i1 %cond446, label %bb_rcslotdrop70, label %bb_rcslotdone70
bb_rcslotdrop70:
  %v447 = load i64, ptr %slot4, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 0, ptr %p448, align 4, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot8, align 8
  store i64 %v449, ptr %slot64, align 8
  %v450 = load i64, ptr %slot5, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i32, ptr %p451, align 4, !alias.scope !3, !noalias !4
  store i32 %ld452, ptr %slot65, align 8
  %v453 = load i32, ptr %slot65, align 8
  %op454 = and i32 %v453, 28
  store i32 %op454, ptr %slot66, align 8
  %v455 = load i32, ptr %slot66, align 8
  %cv456 = zext i32 %v455 to i64
  %cond457 = icmp ne i64 %cv456, 0
  br i1 %cond457, label %bb_rcslotrole70, label %bb_rcslotowner70
bb_rcslotrole70:
  %v458 = load i64, ptr %slot20, align 8
  store i64 %v458, ptr %slot67, align 8
  %v459 = load i64, ptr %slot67, align 8
  %v460 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v459, i64 %v460) nomerge, !dbg !120
  br label %bb_rcslotdone70
bb_rcslotowner70:
  %v461 = load i64, ptr %slot20, align 8
  store i64 %v461, ptr %slot68, align 8
  %v462 = load i64, ptr %slot68, align 8
  %v463 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v462, i64 %v463) nomerge, !dbg !120
  br label %bb_rcslotdone70
bb_rcslotdone70:
  %v464 = load i64, ptr %slot8, align 8
  store i64 %v464, ptr %slot69, align 8
  %v465 = load i64, ptr %slot9, align 8
  store i64 %v465, ptr %slot70, align 8
  %v466 = load i64, ptr %slot70, align 8
  %v467 = load i64, ptr %slot69, align 8
  %p468 = inttoptr i64 %v466 to ptr
  %p469 = inttoptr i64 %v467 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p469, ptr %p468, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot5, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 2, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot7, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %ld474 = load i32, ptr %p473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld474, ptr %slot71, align 8
  %v475 = load i32, ptr %slot71, align 8
  %v476 = load i64, ptr %slot5, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 %v475, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot6, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 0, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot4, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 1, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot69, align 8
  %v483 = load i64, ptr %slot11, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i64 %v482, ptr %p484, align 8, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot11, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i64, ptr %p486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot72, align 8
  %v488 = load i64, ptr %slot72, align 8
  %op489 = add i64 %v488, 0
  store i64 %op489, ptr %slot73, align 8
  %v490 = load i64, ptr %slot73, align 8
  %v491 = load i64, ptr %slot11, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i64 %v490, ptr %p492, align 8, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot11, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i64, ptr %p494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld495, ptr %slot74, align 8
  %v496 = load i64, ptr %slot13, align 8
  store i64 %v496, ptr %slot75, align 8
  %v497 = load i64, ptr %slot74, align 8
  %v498 = load i64, ptr %slot75, align 8
  %p499 = inttoptr i64 %v497 to ptr
  %p500 = inttoptr i64 %v498 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p500, ptr %p499, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot75, align 8
  %v502 = load i64, ptr %slot11, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot4, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i32, ptr %p505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld506, ptr %slot76, align 8
  %v507 = load i32, ptr %slot76, align 8
  %cv508 = zext i32 %v507 to i64
  %cond509 = icmp ne i64 %cv508, 0
  br i1 %cond509, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v510 = load i64, ptr %slot4, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i32 0, ptr %p511, align 4, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot8, align 8
  store i64 %v512, ptr %slot77, align 8
  %v513 = load i64, ptr %slot5, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %ld515 = load i32, ptr %p514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld515, ptr %slot78, align 8
  %v516 = load i32, ptr %slot78, align 8
  %op517 = and i32 %v516, 28
  store i32 %op517, ptr %slot79, align 8
  %v518 = load i32, ptr %slot79, align 8
  %cv519 = zext i32 %v518 to i64
  %cond520 = icmp ne i64 %cv519, 0
  br i1 %cond520, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v521 = load i64, ptr %slot20, align 8
  store i64 %v521, ptr %slot80, align 8
  %v522 = load i64, ptr %slot80, align 8
  %v523 = load i64, ptr %slot77, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v522, i64 %v523) nomerge, !dbg !122
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v524 = load i64, ptr %slot20, align 8
  store i64 %v524, ptr %slot81, align 8
  %v525 = load i64, ptr %slot81, align 8
  %v526 = load i64, ptr %slot77, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v525, i64 %v526) nomerge, !dbg !122
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v527 = load i64, ptr %slot14, align 8
  store i64 %v527, ptr %slot82, align 8
  %v528 = load i64, ptr %slot82, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i32 0, ptr %p529, align 4, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot82, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 8, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot82, align 8
  %v533 = load i64, ptr %slot12, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i64 %v532, ptr %p534, align 8, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot12, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot83, align 8
  %v538 = load i64, ptr %slot11, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot84, align 8
  %v541 = load i64, ptr %slot84, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i32, ptr %p542, align 4, !alias.scope !3, !noalias !4
  %ext544 = zext i32 %ld543 to i64
  store i64 %ext544, ptr %slot85, align 8
  %v545 = load i64, ptr %slot83, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i32, ptr %p546, align 4, !alias.scope !3, !noalias !4
  %ext548 = zext i32 %ld547 to i64
  store i64 %ext548, ptr %slot86, align 8
  %v549 = load i64, ptr %slot85, align 8
  %v550 = load i64, ptr %slot86, align 8
  %cmp551 = icmp eq i64 %v549, %v550
  %cv552 = zext i1 %cmp551 to i64
  store i64 %cv552, ptr %slot87, align 8
  %v553 = load i64, ptr %slot87, align 8
  %v554 = load i64, ptr %slot11, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i64 %v553, ptr %p555, align 8, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot11, align 8
  %p557 = inttoptr i64 %v556 to ptr
  %ld558 = load i64, ptr %p557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld558, ptr %slot88, align 8
  %v559 = load i64, ptr %slot88, align 8
  %cond560 = icmp ne i64 %v559, 0
  br i1 %cond560, label %bb_next105, label %bb_i15
bb_next105:
  %v561 = load i64, ptr %slot11, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 0, ptr %p562, align 8, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot11, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot89, align 8
  %v566 = load i64, ptr %slot4, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i32, ptr %p567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld568, ptr %slot90, align 8
  %v569 = load i32, ptr %slot90, align 8
  %cv570 = zext i32 %v569 to i64
  %cond571 = icmp ne i64 %cv570, 0
  br i1 %cond571, label %bb_rcslotdrop108, label %bb_rcslotdone108
bb_rcslotdrop108:
  %v572 = load i64, ptr %slot4, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 0, ptr %p573, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone108
bb_rcslotdone108:
  %v574 = load i64, ptr %slot89, align 8
  ret i64 %v574
bb_i15:
  %v575 = load i64, ptr %slot10, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot91, align 8
  %v578 = load i64, ptr %slot91, align 8
  %v579 = load i64, ptr %slot11, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i64 %v578, ptr %p580, align 8, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot11, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %ld583 = load i64, ptr %p582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld583, ptr %slot92, align 8
  %v584 = load i64, ptr %slot1, align 8
  %v585 = load i64, ptr %slot92, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult94, i64 %v584, i64 %v585) nomerge, !dbg !124
  %addr586 = ptrtoint ptr %callresult94 to i64
  store i64 %addr586, ptr %slot93, align 8
  %v587 = load i64, ptr %slot93, align 8
  %v588 = load i64, ptr %slot11, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i64 %v587, ptr %p589, align 8, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot11, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %ld592 = load i64, ptr %p591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld592, ptr %slot95, align 8
  %v593 = load i64, ptr %slot9, align 8
  store i64 %v593, ptr %slot96, align 8
  %v594 = load i64, ptr %slot20, align 8
  %v595 = load i64, ptr %slot96, align 8
  %v596 = load i64, ptr %slot95, align 8
  %call597 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v594, i64 %v595, i64 %v596) nomerge, !dbg !124
  store i32 %call597, ptr %slot97, align 8
  %v598 = load i32, ptr %slot97, align 8
  %cv599 = zext i32 %v598 to i64
  %cond600 = icmp ne i64 %cv599, 0
  br i1 %cond600, label %bb_rcsuccess124, label %bb_rcfailure124
bb_rcfailure124:
  %v601 = load i64, ptr %slot20, align 8
  %p602 = inttoptr i64 %v601 to ptr
  %call603 = call i32 @myl_rc_take_failure(ptr %p602) nomerge, !dbg !124
  store i32 %call603, ptr %slot98, align 8
  %v604 = load i64, ptr %slot1, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %v606 = load i32, ptr %slot98, align 8
  %call607 = call i32 @myl_qbe_rc_status(ptr %p605, i32 %v606) nomerge, !dbg !124
  store i32 %call607, ptr %slot99, align 8
  br label %bb_failure
bb_rcsuccess124:
  %v608 = load i64, ptr %slot7, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 2, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot7, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i32 16, ptr %p611, align 4, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot6, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i32 1, ptr %p613, align 4, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot4, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i32, ptr %p615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld616, ptr %slot100, align 8
  %v617 = load i32, ptr %slot100, align 8
  %cv618 = zext i32 %v617 to i64
  %cond619 = icmp ne i64 %cv618, 0
  br i1 %cond619, label %bb_rcslotdrop132, label %bb_rcslotdone132
bb_rcslotdrop132:
  %v620 = load i64, ptr %slot4, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i32 0, ptr %p621, align 4, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot8, align 8
  store i64 %v622, ptr %slot101, align 8
  %v623 = load i64, ptr %slot5, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i32, ptr %p624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld625, ptr %slot102, align 8
  %v626 = load i32, ptr %slot102, align 8
  %op627 = and i32 %v626, 28
  store i32 %op627, ptr %slot103, align 8
  %v628 = load i32, ptr %slot103, align 8
  %cv629 = zext i32 %v628 to i64
  %cond630 = icmp ne i64 %cv629, 0
  br i1 %cond630, label %bb_rcslotrole132, label %bb_rcslotowner132
bb_rcslotrole132:
  %v631 = load i64, ptr %slot20, align 8
  store i64 %v631, ptr %slot104, align 8
  %v632 = load i64, ptr %slot104, align 8
  %v633 = load i64, ptr %slot101, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v632, i64 %v633) nomerge, !dbg !124
  br label %bb_rcslotdone132
bb_rcslotowner132:
  %v634 = load i64, ptr %slot20, align 8
  store i64 %v634, ptr %slot105, align 8
  %v635 = load i64, ptr %slot105, align 8
  %v636 = load i64, ptr %slot101, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v635, i64 %v636) nomerge, !dbg !124
  br label %bb_rcslotdone132
bb_rcslotdone132:
  %v637 = load i64, ptr %slot8, align 8
  store i64 %v637, ptr %slot106, align 8
  %v638 = load i64, ptr %slot9, align 8
  store i64 %v638, ptr %slot107, align 8
  %v639 = load i64, ptr %slot107, align 8
  %v640 = load i64, ptr %slot106, align 8
  %p641 = inttoptr i64 %v639 to ptr
  %p642 = inttoptr i64 %v640 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p642, ptr %p641, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v643 = load i64, ptr %slot5, align 8
  %p644 = inttoptr i64 %v643 to ptr
  store i32 2, ptr %p644, align 4, !alias.scope !3, !noalias !4
  %v645 = load i64, ptr %slot7, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i32, ptr %p646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld647, ptr %slot108, align 8
  %v648 = load i32, ptr %slot108, align 8
  %v649 = load i64, ptr %slot5, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i32 %v648, ptr %p650, align 4, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot6, align 8
  %p652 = inttoptr i64 %v651 to ptr
  store i32 0, ptr %p652, align 4, !alias.scope !3, !noalias !4
  %v653 = load i64, ptr %slot4, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i32 1, ptr %p654, align 4, !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot106, align 8
  %v656 = load i64, ptr %slot11, align 8
  %p657 = inttoptr i64 %v656 to ptr
  store i64 %v655, ptr %p657, align 8, !alias.scope !3, !noalias !4
  %v658 = load i64, ptr %slot11, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %ld660 = load i64, ptr %p659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld660, ptr %slot109, align 8
  %v661 = load i64, ptr %slot109, align 8
  %op662 = add i64 %v661, 0
  store i64 %op662, ptr %slot110, align 8
  %v663 = load i64, ptr %slot110, align 8
  %v664 = load i64, ptr %slot11, align 8
  %p665 = inttoptr i64 %v664 to ptr
  store i64 %v663, ptr %p665, align 8, !alias.scope !3, !noalias !4
  %v666 = load i64, ptr %slot11, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %ld668 = load i64, ptr %p667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld668, ptr %slot111, align 8
  %v669 = load i64, ptr %slot15, align 8
  store i64 %v669, ptr %slot112, align 8
  %v670 = load i64, ptr %slot111, align 8
  %v671 = load i64, ptr %slot112, align 8
  %p672 = inttoptr i64 %v670 to ptr
  %p673 = inttoptr i64 %v671 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p673, ptr %p672, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v674 = load i64, ptr %slot112, align 8
  %v675 = load i64, ptr %slot11, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i64 %v674, ptr %p676, align 8, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot4, align 8
  %p678 = inttoptr i64 %v677 to ptr
  %ld679 = load i32, ptr %p678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld679, ptr %slot113, align 8
  %v680 = load i32, ptr %slot113, align 8
  %cv681 = zext i32 %v680 to i64
  %cond682 = icmp ne i64 %cv681, 0
  br i1 %cond682, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v683 = load i64, ptr %slot4, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 0, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot8, align 8
  store i64 %v685, ptr %slot114, align 8
  %v686 = load i64, ptr %slot5, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i32, ptr %p687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld688, ptr %slot115, align 8
  %v689 = load i32, ptr %slot115, align 8
  %op690 = and i32 %v689, 28
  store i32 %op690, ptr %slot116, align 8
  %v691 = load i32, ptr %slot116, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v694 = load i64, ptr %slot20, align 8
  store i64 %v694, ptr %slot117, align 8
  %v695 = load i64, ptr %slot117, align 8
  %v696 = load i64, ptr %slot114, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v695, i64 %v696) nomerge, !dbg !126
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v697 = load i64, ptr %slot20, align 8
  store i64 %v697, ptr %slot118, align 8
  %v698 = load i64, ptr %slot118, align 8
  %v699 = load i64, ptr %slot114, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v698, i64 %v699) nomerge, !dbg !126
  br label %bb_rcslotdone153
bb_rcslotdone153:
  %v700 = load i64, ptr %slot11, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot119, align 8
  %v703 = load i64, ptr %slot119, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i32, ptr %p704, align 4, !alias.scope !3, !noalias !4
  %ext706 = zext i32 %ld705 to i64
  store i64 %ext706, ptr %slot120, align 8
  %v707 = load i64, ptr %slot120, align 8
  %cmp708 = icmp eq i64 %v707, 0
  %cv709 = zext i1 %cmp708 to i64
  store i64 %cv709, ptr %slot121, align 8
  %v710 = load i64, ptr %slot121, align 8
  %cond711 = icmp ne i64 %v710, 0
  br i1 %cond711, label %bb_rcarm162, label %bb_rcarmnext162
bb_rcarm162:
  br label %bb_i35
bb_rcarmnext162:
  %v712 = load i64, ptr %slot120, align 8
  %cmp713 = icmp eq i64 %v712, 1
  %cv714 = zext i1 %cmp713 to i64
  store i64 %cv714, ptr %slot122, align 8
  %v715 = load i64, ptr %slot122, align 8
  %cond716 = icmp ne i64 %v715, 0
  br i1 %cond716, label %bb_rcarm163, label %bb_rcarmnext163
bb_rcarm163:
  br label %bb_i36
bb_rcarmnext163:
  %v717 = load i64, ptr %slot120, align 8
  %cmp718 = icmp eq i64 %v717, 2
  %cv719 = zext i1 %cmp718 to i64
  store i64 %cv719, ptr %slot123, align 8
  %v720 = load i64, ptr %slot123, align 8
  %cond721 = icmp ne i64 %v720, 0
  br i1 %cond721, label %bb_rcarm164, label %bb_rcarmnext164
bb_rcarm164:
  br label %bb_i37
bb_rcarmnext164:
  %v722 = load i64, ptr %slot120, align 8
  %cmp723 = icmp eq i64 %v722, 3
  %cv724 = zext i1 %cmp723 to i64
  store i64 %cv724, ptr %slot124, align 8
  %v725 = load i64, ptr %slot124, align 8
  %cond726 = icmp ne i64 %v725, 0
  br i1 %cond726, label %bb_rcarm165, label %bb_rcarmnext165
bb_rcarm165:
  br label %bb_i38
bb_rcarmnext165:
  %v727 = load i64, ptr %slot120, align 8
  %cmp728 = icmp eq i64 %v727, 4
  %cv729 = zext i1 %cmp728 to i64
  store i64 %cv729, ptr %slot125, align 8
  %v730 = load i64, ptr %slot125, align 8
  %cond731 = icmp ne i64 %v730, 0
  br i1 %cond731, label %bb_rcarm166, label %bb_rcarmnext166
bb_rcarm166:
  br label %bb_i39
bb_rcarmnext166:
  %v732 = load i64, ptr %slot120, align 8
  %cmp733 = icmp eq i64 %v732, 5
  %cv734 = zext i1 %cmp733 to i64
  store i64 %cv734, ptr %slot126, align 8
  %v735 = load i64, ptr %slot126, align 8
  %cond736 = icmp ne i64 %v735, 0
  br i1 %cond736, label %bb_rcarm167, label %bb_rcarmnext167
bb_rcarm167:
  br label %bb_i40
bb_rcarmnext167:
  %v737 = load i64, ptr %slot120, align 8
  %cmp738 = icmp eq i64 %v737, 6
  %cv739 = zext i1 %cmp738 to i64
  store i64 %cv739, ptr %slot127, align 8
  %v740 = load i64, ptr %slot127, align 8
  %cond741 = icmp ne i64 %v740, 0
  br i1 %cond741, label %bb_rcarm168, label %bb_rcarmnext168
bb_rcarm168:
  br label %bb_i41
bb_rcarmnext168:
  %v742 = load i64, ptr %slot120, align 8
  %cmp743 = icmp eq i64 %v742, 7
  %cv744 = zext i1 %cmp743 to i64
  store i64 %cv744, ptr %slot128, align 8
  %v745 = load i64, ptr %slot128, align 8
  %cond746 = icmp ne i64 %v745, 0
  br i1 %cond746, label %bb_rcarm169, label %bb_rcarmnext169
bb_rcarm169:
  br label %bb_i42
bb_rcarmnext169:
  %v747 = load i64, ptr %slot120, align 8
  %cmp748 = icmp eq i64 %v747, 8
  %cv749 = zext i1 %cmp748 to i64
  store i64 %cv749, ptr %slot129, align 8
  %v750 = load i64, ptr %slot129, align 8
  %cond751 = icmp ne i64 %v750, 0
  br i1 %cond751, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  br label %bb_i43
bb_rcarmnext170:
  %v752 = load i64, ptr %slot120, align 8
  %cmp753 = icmp eq i64 %v752, 9
  %cv754 = zext i1 %cmp753 to i64
  store i64 %cv754, ptr %slot130, align 8
  %v755 = load i64, ptr %slot130, align 8
  %cond756 = icmp ne i64 %v755, 0
  br i1 %cond756, label %bb_rcarm171, label %bb_rcarmnext171
bb_rcarm171:
  br label %bb_i44
bb_rcarmnext171:
  %v757 = load i64, ptr %slot120, align 8
  %cmp758 = icmp eq i64 %v757, 10
  %cv759 = zext i1 %cmp758 to i64
  store i64 %cv759, ptr %slot131, align 8
  %v760 = load i64, ptr %slot131, align 8
  %cond761 = icmp ne i64 %v760, 0
  br i1 %cond761, label %bb_rcarm172, label %bb_rcarmnext172
bb_rcarm172:
  br label %bb_i45
bb_rcarmnext172:
  %v762 = load i64, ptr %slot120, align 8
  %cmp763 = icmp eq i64 %v762, 11
  %cv764 = zext i1 %cmp763 to i64
  store i64 %cv764, ptr %slot132, align 8
  %v765 = load i64, ptr %slot132, align 8
  %cond766 = icmp ne i64 %v765, 0
  br i1 %cond766, label %bb_rcarm173, label %bb_rcarmnext173
bb_rcarm173:
  br label %bb_i46
bb_rcarmnext173:
  %v767 = load i64, ptr %slot120, align 8
  %cmp768 = icmp eq i64 %v767, 12
  %cv769 = zext i1 %cmp768 to i64
  store i64 %cv769, ptr %slot133, align 8
  %v770 = load i64, ptr %slot133, align 8
  %cond771 = icmp ne i64 %v770, 0
  br i1 %cond771, label %bb_rcarm174, label %bb_rcarmnext174
bb_rcarm174:
  br label %bb_i47
bb_rcarmnext174:
  %v772 = load i64, ptr %slot120, align 8
  %cmp773 = icmp eq i64 %v772, 13
  %cv774 = zext i1 %cmp773 to i64
  store i64 %cv774, ptr %slot134, align 8
  %v775 = load i64, ptr %slot134, align 8
  %cond776 = icmp ne i64 %v775, 0
  br i1 %cond776, label %bb_rcarm175, label %bb_rcarmnext175
bb_rcarm175:
  br label %bb_i48
bb_rcarmnext175:
  %v777 = load i64, ptr %slot120, align 8
  %cmp778 = icmp eq i64 %v777, 14
  %cv779 = zext i1 %cmp778 to i64
  store i64 %cv779, ptr %slot135, align 8
  %v780 = load i64, ptr %slot135, align 8
  %cond781 = icmp ne i64 %v780, 0
  br i1 %cond781, label %bb_rcarm176, label %bb_rcarmnext176
bb_rcarm176:
  br label %bb_i49
bb_rcarmnext176:
  %v782 = load i64, ptr %slot120, align 8
  %cmp783 = icmp eq i64 %v782, 15
  %cv784 = zext i1 %cmp783 to i64
  store i64 %cv784, ptr %slot136, align 8
  %v785 = load i64, ptr %slot136, align 8
  %cond786 = icmp ne i64 %v785, 0
  br i1 %cond786, label %bb_rcarm177, label %bb_rcarmnext177
bb_rcarm177:
  br label %bb_i50
bb_rcarmnext177:
  %v787 = load i64, ptr %slot120, align 8
  %cmp788 = icmp eq i64 %v787, 16
  %cv789 = zext i1 %cmp788 to i64
  store i64 %cv789, ptr %slot137, align 8
  %v790 = load i64, ptr %slot137, align 8
  %cond791 = icmp ne i64 %v790, 0
  br i1 %cond791, label %bb_rcarm178, label %bb_rcarmnext178
bb_rcarm178:
  br label %bb_i51
bb_rcarmnext178:
  %v792 = load i64, ptr %slot120, align 8
  %cmp793 = icmp eq i64 %v792, 17
  %cv794 = zext i1 %cmp793 to i64
  store i64 %cv794, ptr %slot138, align 8
  %v795 = load i64, ptr %slot138, align 8
  %cond796 = icmp ne i64 %v795, 0
  br i1 %cond796, label %bb_rcarm179, label %bb_rcarmnext179
bb_rcarm179:
  br label %bb_i52
bb_rcarmnext179:
  %v797 = load i64, ptr %slot120, align 8
  %cmp798 = icmp eq i64 %v797, 18
  %cv799 = zext i1 %cmp798 to i64
  store i64 %cv799, ptr %slot139, align 8
  %v800 = load i64, ptr %slot139, align 8
  %cond801 = icmp ne i64 %v800, 0
  br i1 %cond801, label %bb_rcarm180, label %bb_rcarmnext180
bb_rcarm180:
  br label %bb_i53
bb_rcarmnext180:
  %v802 = load i64, ptr %slot120, align 8
  %cmp803 = icmp eq i64 %v802, 19
  %cv804 = zext i1 %cmp803 to i64
  store i64 %cv804, ptr %slot140, align 8
  %v805 = load i64, ptr %slot140, align 8
  %cond806 = icmp ne i64 %v805, 0
  br i1 %cond806, label %bb_rcarm181, label %bb_rcarmnext181
bb_rcarm181:
  br label %bb_i54
bb_rcarmnext181:
  %v807 = load i64, ptr %slot120, align 8
  %cmp808 = icmp eq i64 %v807, 20
  %cv809 = zext i1 %cmp808 to i64
  store i64 %cv809, ptr %slot141, align 8
  %v810 = load i64, ptr %slot141, align 8
  %cond811 = icmp ne i64 %v810, 0
  br i1 %cond811, label %bb_rcarm182, label %bb_rcarmnext182
bb_rcarm182:
  br label %bb_i55
bb_rcarmnext182:
  %v812 = load i64, ptr %slot120, align 8
  %cmp813 = icmp eq i64 %v812, 21
  %cv814 = zext i1 %cmp813 to i64
  store i64 %cv814, ptr %slot142, align 8
  %v815 = load i64, ptr %slot142, align 8
  %cond816 = icmp ne i64 %v815, 0
  br i1 %cond816, label %bb_rcarm183, label %bb_rcarmnext183
bb_rcarm183:
  br label %bb_i56
bb_rcarmnext183:
  %v817 = load i64, ptr %slot120, align 8
  %cmp818 = icmp eq i64 %v817, 22
  %cv819 = zext i1 %cmp818 to i64
  store i64 %cv819, ptr %slot143, align 8
  %v820 = load i64, ptr %slot143, align 8
  %cond821 = icmp ne i64 %v820, 0
  br i1 %cond821, label %bb_rcarm184, label %bb_rcarmnext184
bb_rcarm184:
  br label %bb_i57
bb_rcarmnext184:
  %v822 = load i64, ptr %slot120, align 8
  %cmp823 = icmp eq i64 %v822, 23
  %cv824 = zext i1 %cmp823 to i64
  store i64 %cv824, ptr %slot144, align 8
  %v825 = load i64, ptr %slot144, align 8
  %cond826 = icmp ne i64 %v825, 0
  br i1 %cond826, label %bb_rcarm185, label %bb_rcarmnext185
bb_rcarm185:
  br label %bb_i19
bb_rcarmnext185:
  %v827 = load i64, ptr %slot120, align 8
  %cmp828 = icmp eq i64 %v827, 24
  %cv829 = zext i1 %cmp828 to i64
  store i64 %cv829, ptr %slot145, align 8
  %v830 = load i64, ptr %slot145, align 8
  %cond831 = icmp ne i64 %v830, 0
  br i1 %cond831, label %bb_rcarm186, label %bb_rcarmnext186
bb_rcarm186:
  br label %bb_i58
bb_rcarmnext186:
  %v832 = load i64, ptr %slot120, align 8
  %cmp833 = icmp eq i64 %v832, 25
  %cv834 = zext i1 %cmp833 to i64
  store i64 %cv834, ptr %slot146, align 8
  %v835 = load i64, ptr %slot146, align 8
  %cond836 = icmp ne i64 %v835, 0
  br i1 %cond836, label %bb_rcarm187, label %bb_rcarmnext187
bb_rcarm187:
  br label %bb_i59
bb_rcarmnext187:
  %v837 = load i64, ptr %slot120, align 8
  %cmp838 = icmp eq i64 %v837, 26
  %cv839 = zext i1 %cmp838 to i64
  store i64 %cv839, ptr %slot147, align 8
  %v840 = load i64, ptr %slot147, align 8
  %cond841 = icmp ne i64 %v840, 0
  br i1 %cond841, label %bb_rcarm188, label %bb_rcarmnext188
bb_rcarm188:
  br label %bb_i25
bb_rcarmnext188:
  %v842 = load i64, ptr %slot120, align 8
  %cmp843 = icmp eq i64 %v842, 27
  %cv844 = zext i1 %cmp843 to i64
  store i64 %cv844, ptr %slot148, align 8
  %v845 = load i64, ptr %slot148, align 8
  %cond846 = icmp ne i64 %v845, 0
  br i1 %cond846, label %bb_rcarm189, label %bb_rcarmnext189
bb_rcarm189:
  br label %bb_i21
bb_rcarmnext189:
  %v847 = load i64, ptr %slot120, align 8
  %cmp848 = icmp eq i64 %v847, 28
  %cv849 = zext i1 %cmp848 to i64
  store i64 %cv849, ptr %slot149, align 8
  %v850 = load i64, ptr %slot149, align 8
  %cond851 = icmp ne i64 %v850, 0
  br i1 %cond851, label %bb_rcarm190, label %bb_rcarmnext190
bb_rcarm190:
  br label %bb_i27
bb_rcarmnext190:
  %v852 = load i64, ptr %slot120, align 8
  %cmp853 = icmp eq i64 %v852, 29
  %cv854 = zext i1 %cmp853 to i64
  store i64 %cv854, ptr %slot150, align 8
  %v855 = load i64, ptr %slot150, align 8
  %cond856 = icmp ne i64 %v855, 0
  br i1 %cond856, label %bb_rcarm191, label %bb_rcarmnext191
bb_rcarm191:
  br label %bb_i60
bb_rcarmnext191:
  %v857 = load i64, ptr %slot120, align 8
  %cmp858 = icmp eq i64 %v857, 30
  %cv859 = zext i1 %cmp858 to i64
  store i64 %cv859, ptr %slot151, align 8
  %v860 = load i64, ptr %slot151, align 8
  %cond861 = icmp ne i64 %v860, 0
  br i1 %cond861, label %bb_rcarm192, label %bb_rcarmnext192
bb_rcarm192:
  br label %bb_i61
bb_rcarmnext192:
  %v862 = load i64, ptr %slot120, align 8
  %cmp863 = icmp eq i64 %v862, 31
  %cv864 = zext i1 %cmp863 to i64
  store i64 %cv864, ptr %slot152, align 8
  %v865 = load i64, ptr %slot152, align 8
  %cond866 = icmp ne i64 %v865, 0
  br i1 %cond866, label %bb_rcarm193, label %bb_rcarmnext193
bb_rcarm193:
  br label %bb_i31
bb_rcarmnext193:
  %v867 = load i64, ptr %slot120, align 8
  %cmp868 = icmp eq i64 %v867, 32
  %cv869 = zext i1 %cmp868 to i64
  store i64 %cv869, ptr %slot153, align 8
  %v870 = load i64, ptr %slot153, align 8
  %cond871 = icmp ne i64 %v870, 0
  br i1 %cond871, label %bb_rcarm194, label %bb_rcarmnext194
bb_rcarm194:
  br label %bb_i33
bb_rcarmnext194:
  %v872 = load i64, ptr %slot120, align 8
  %cmp873 = icmp eq i64 %v872, 33
  %cv874 = zext i1 %cmp873 to i64
  store i64 %cv874, ptr %slot154, align 8
  %v875 = load i64, ptr %slot154, align 8
  %cond876 = icmp ne i64 %v875, 0
  br i1 %cond876, label %bb_rcarm195, label %bb_rcarmnext195
bb_rcarm195:
  br label %bb_i62
bb_rcarmnext195:
  %v877 = load i64, ptr %slot120, align 8
  %cmp878 = icmp eq i64 %v877, 34
  %cv879 = zext i1 %cmp878 to i64
  store i64 %cv879, ptr %slot155, align 8
  %v880 = load i64, ptr %slot155, align 8
  %cond881 = icmp ne i64 %v880, 0
  br i1 %cond881, label %bb_rcarm196, label %bb_rcarmnext196
bb_rcarm196:
  br label %bb_i63
bb_rcarmnext196:
  %v882 = load i64, ptr %slot120, align 8
  %cmp883 = icmp eq i64 %v882, 35
  %cv884 = zext i1 %cmp883 to i64
  store i64 %cv884, ptr %slot156, align 8
  %v885 = load i64, ptr %slot156, align 8
  %cond886 = icmp ne i64 %v885, 0
  br i1 %cond886, label %bb_rcarm197, label %bb_rcarmnext197
bb_rcarm197:
  br label %bb_i64
bb_rcarmnext197:
  %v887 = load i64, ptr %slot120, align 8
  %cmp888 = icmp eq i64 %v887, 36
  %cv889 = zext i1 %cmp888 to i64
  store i64 %cv889, ptr %slot157, align 8
  %v890 = load i64, ptr %slot157, align 8
  %cond891 = icmp ne i64 %v890, 0
  br i1 %cond891, label %bb_rcarm198, label %bb_rcarmnext198
bb_rcarm198:
  br label %bb_i23
bb_rcarmnext198:
  %v892 = load i64, ptr %slot120, align 8
  %cmp893 = icmp eq i64 %v892, 37
  %cv894 = zext i1 %cmp893 to i64
  store i64 %cv894, ptr %slot158, align 8
  %v895 = load i64, ptr %slot158, align 8
  %cond896 = icmp ne i64 %v895, 0
  br i1 %cond896, label %bb_rcarm199, label %bb_rcarmnext199
bb_rcarm199:
  br label %bb_i29
bb_rcarmnext199:
  %v897 = load i64, ptr %slot120, align 8
  %cmp898 = icmp eq i64 %v897, 38
  %cv899 = zext i1 %cmp898 to i64
  store i64 %cv899, ptr %slot159, align 8
  %v900 = load i64, ptr %slot159, align 8
  %cond901 = icmp ne i64 %v900, 0
  br i1 %cond901, label %bb_rcarm200, label %bb_rcarmnext200
bb_rcarm200:
  br label %bb_i65
bb_rcarmnext200:
  %v902 = load i64, ptr %slot120, align 8
  %cmp903 = icmp eq i64 %v902, 39
  %cv904 = zext i1 %cmp903 to i64
  store i64 %cv904, ptr %slot160, align 8
  %v905 = load i64, ptr %slot160, align 8
  %cond906 = icmp ne i64 %v905, 0
  br i1 %cond906, label %bb_rcarm201, label %bb_rcarmnext201
bb_rcarm201:
  br label %bb_i66
bb_rcarmnext201:
  br label %bb_failure
bb_i19:
  %v907 = load i64, ptr %slot11, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i64 0, ptr %p908, align 8, !alias.scope !3, !noalias !4
  %v909 = load i64, ptr %slot11, align 8
  %p910 = inttoptr i64 %v909 to ptr
  %ld911 = load i64, ptr %p910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld911, ptr %slot161, align 8
  %v912 = load i64, ptr %slot4, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i32, ptr %p913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld914, ptr %slot162, align 8
  %v915 = load i32, ptr %slot162, align 8
  %cv916 = zext i32 %v915 to i64
  %cond917 = icmp ne i64 %cv916, 0
  br i1 %cond917, label %bb_rcslotdrop205, label %bb_rcslotdone205
bb_rcslotdrop205:
  %v918 = load i64, ptr %slot4, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 0, ptr %p919, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone205
bb_rcslotdone205:
  %v920 = load i64, ptr %slot161, align 8
  ret i64 %v920
bb_i21:
  %v921 = load i64, ptr %slot11, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i64 0, ptr %p922, align 8, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot11, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i64, ptr %p924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld925, ptr %slot163, align 8
  %v926 = load i64, ptr %slot4, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot164, align 8
  %v929 = load i32, ptr %slot164, align 8
  %cv930 = zext i32 %v929 to i64
  %cond931 = icmp ne i64 %cv930, 0
  br i1 %cond931, label %bb_rcslotdrop218, label %bb_rcslotdone218
bb_rcslotdrop218:
  %v932 = load i64, ptr %slot4, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 0, ptr %p933, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone218
bb_rcslotdone218:
  %v934 = load i64, ptr %slot163, align 8
  ret i64 %v934
bb_i23:
  %v935 = load i64, ptr %slot11, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i64 0, ptr %p936, align 8, !alias.scope !3, !noalias !4
  %v937 = load i64, ptr %slot11, align 8
  %p938 = inttoptr i64 %v937 to ptr
  %ld939 = load i64, ptr %p938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld939, ptr %slot165, align 8
  %v940 = load i64, ptr %slot4, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i32, ptr %p941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld942, ptr %slot166, align 8
  %v943 = load i32, ptr %slot166, align 8
  %cv944 = zext i32 %v943 to i64
  %cond945 = icmp ne i64 %cv944, 0
  br i1 %cond945, label %bb_rcslotdrop231, label %bb_rcslotdone231
bb_rcslotdrop231:
  %v946 = load i64, ptr %slot4, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 0, ptr %p947, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone231
bb_rcslotdone231:
  %v948 = load i64, ptr %slot165, align 8
  ret i64 %v948
bb_i25:
  %v949 = load i64, ptr %slot11, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i64 0, ptr %p950, align 8, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot11, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %ld953 = load i64, ptr %p952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld953, ptr %slot167, align 8
  %v954 = load i64, ptr %slot4, align 8
  %p955 = inttoptr i64 %v954 to ptr
  %ld956 = load i32, ptr %p955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld956, ptr %slot168, align 8
  %v957 = load i32, ptr %slot168, align 8
  %cv958 = zext i32 %v957 to i64
  %cond959 = icmp ne i64 %cv958, 0
  br i1 %cond959, label %bb_rcslotdrop244, label %bb_rcslotdone244
bb_rcslotdrop244:
  %v960 = load i64, ptr %slot4, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 0, ptr %p961, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone244
bb_rcslotdone244:
  %v962 = load i64, ptr %slot167, align 8
  ret i64 %v962
bb_i27:
  %v963 = load i64, ptr %slot11, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i64 0, ptr %p964, align 8, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot11, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %ld967 = load i64, ptr %p966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld967, ptr %slot169, align 8
  %v968 = load i64, ptr %slot4, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %ld970 = load i32, ptr %p969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld970, ptr %slot170, align 8
  %v971 = load i32, ptr %slot170, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v974 = load i64, ptr %slot4, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 0, ptr %p975, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone257
bb_rcslotdone257:
  %v976 = load i64, ptr %slot169, align 8
  ret i64 %v976
bb_i29:
  %v977 = load i64, ptr %slot11, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i64 0, ptr %p978, align 8, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot11, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %ld981 = load i64, ptr %p980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld981, ptr %slot171, align 8
  %v982 = load i64, ptr %slot4, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %ld984 = load i32, ptr %p983, align 4, !alias.scope !3, !noalias !4
  store i32 %ld984, ptr %slot172, align 8
  %v985 = load i32, ptr %slot172, align 8
  %cv986 = zext i32 %v985 to i64
  %cond987 = icmp ne i64 %cv986, 0
  br i1 %cond987, label %bb_rcslotdrop270, label %bb_rcslotdone270
bb_rcslotdrop270:
  %v988 = load i64, ptr %slot4, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i32 0, ptr %p989, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone270
bb_rcslotdone270:
  %v990 = load i64, ptr %slot171, align 8
  ret i64 %v990
bb_i31:
  %v991 = load i64, ptr %slot11, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i64 0, ptr %p992, align 8, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot11, align 8
  %p994 = inttoptr i64 %v993 to ptr
  %ld995 = load i64, ptr %p994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld995, ptr %slot173, align 8
  %v996 = load i64, ptr %slot4, align 8
  %p997 = inttoptr i64 %v996 to ptr
  %ld998 = load i32, ptr %p997, align 4, !alias.scope !3, !noalias !4
  store i32 %ld998, ptr %slot174, align 8
  %v999 = load i32, ptr %slot174, align 8
  %cv1000 = zext i32 %v999 to i64
  %cond1001 = icmp ne i64 %cv1000, 0
  br i1 %cond1001, label %bb_rcslotdrop283, label %bb_rcslotdone283
bb_rcslotdrop283:
  %v1002 = load i64, ptr %slot4, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  store i32 0, ptr %p1003, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone283
bb_rcslotdone283:
  %v1004 = load i64, ptr %slot173, align 8
  ret i64 %v1004
bb_i33:
  %v1005 = load i64, ptr %slot11, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i64 0, ptr %p1006, align 8, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot11, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %ld1009 = load i64, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1009, ptr %slot175, align 8
  %v1010 = load i64, ptr %slot4, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %ld1012 = load i32, ptr %p1011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1012, ptr %slot176, align 8
  %v1013 = load i32, ptr %slot176, align 8
  %cv1014 = zext i32 %v1013 to i64
  %cond1015 = icmp ne i64 %cv1014, 0
  br i1 %cond1015, label %bb_rcslotdrop296, label %bb_rcslotdone296
bb_rcslotdrop296:
  %v1016 = load i64, ptr %slot4, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  store i32 0, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone296
bb_rcslotdone296:
  %v1018 = load i64, ptr %slot175, align 8
  ret i64 %v1018
bb_i35:
  br label %bb_i67
bb_i36:
  br label %bb_i67
bb_i37:
  br label %bb_i67
bb_i38:
  br label %bb_i67
bb_i39:
  br label %bb_i67
bb_i40:
  br label %bb_i67
bb_i41:
  br label %bb_i67
bb_i42:
  br label %bb_i67
bb_i43:
  br label %bb_i67
bb_i44:
  br label %bb_i67
bb_i45:
  br label %bb_i67
bb_i46:
  br label %bb_i67
bb_i47:
  br label %bb_i67
bb_i48:
  br label %bb_i67
bb_i49:
  br label %bb_i67
bb_i50:
  br label %bb_i67
bb_i51:
  br label %bb_i67
bb_i52:
  br label %bb_i67
bb_i53:
  br label %bb_i67
bb_i54:
  br label %bb_i67
bb_i55:
  br label %bb_i67
bb_i56:
  br label %bb_i67
bb_i57:
  br label %bb_i67
bb_i58:
  br label %bb_i67
bb_i59:
  br label %bb_i67
bb_i60:
  br label %bb_i67
bb_i61:
  br label %bb_i67
bb_i62:
  br label %bb_i67
bb_i63:
  br label %bb_i67
bb_i64:
  br label %bb_i67
bb_i65:
  br label %bb_i67
bb_i66:
  br label %bb_i67
bb_i67:
  %v1019 = load i64, ptr %slot10, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  %ld1021 = load i64, ptr %p1020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1021, ptr %slot177, align 8
  %v1022 = load i64, ptr %slot177, align 8
  %v1023 = load i64, ptr %slot11, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i64 %v1022, ptr %p1024, align 8, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot11, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i64, ptr %p1026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1027, ptr %slot178, align 8
  %v1028 = load i64, ptr %slot1, align 8
  %v1029 = load i64, ptr %slot178, align 8
  call void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8 %callresult180, i64 %v1028, i64 %v1029) nomerge, !dbg !128
  %addr1030 = ptrtoint ptr %callresult180 to i64
  store i64 %addr1030, ptr %slot179, align 8
  %v1031 = load i64, ptr %slot179, align 8
  %v1032 = load i64, ptr %slot11, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i64 %v1031, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  %v1034 = load i64, ptr %slot11, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i64, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1036, ptr %slot181, align 8
  %v1037 = load i64, ptr %slot9, align 8
  store i64 %v1037, ptr %slot182, align 8
  %v1038 = load i64, ptr %slot181, align 8
  %v1039 = load i64, ptr %slot182, align 8
  %p1040 = inttoptr i64 %v1038 to ptr
  %p1041 = inttoptr i64 %v1039 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1041, ptr %p1040, i64 40, i1 false)
  %v1042 = load i64, ptr %slot7, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 2, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot6, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 1, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot4, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i32, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1048, ptr %slot183, align 8
  %v1049 = load i32, ptr %slot183, align 8
  %cv1050 = zext i32 %v1049 to i64
  %cond1051 = icmp ne i64 %cv1050, 0
  br i1 %cond1051, label %bb_rcslotdrop315, label %bb_rcslotdone315
bb_rcslotdrop315:
  %v1052 = load i64, ptr %slot4, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 0, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot8, align 8
  store i64 %v1054, ptr %slot184, align 8
  %v1055 = load i64, ptr %slot5, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i32, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1057, ptr %slot185, align 8
  %v1058 = load i32, ptr %slot185, align 8
  %op1059 = and i32 %v1058, 28
  store i32 %op1059, ptr %slot186, align 8
  %v1060 = load i32, ptr %slot186, align 8
  %cv1061 = zext i32 %v1060 to i64
  %cond1062 = icmp ne i64 %cv1061, 0
  br i1 %cond1062, label %bb_rcslotrole315, label %bb_rcslotowner315
bb_rcslotrole315:
  %v1063 = load i64, ptr %slot20, align 8
  store i64 %v1063, ptr %slot187, align 8
  %v1064 = load i64, ptr %slot187, align 8
  %v1065 = load i64, ptr %slot184, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1064, i64 %v1065) nomerge, !dbg !128
  br label %bb_rcslotdone315
bb_rcslotowner315:
  %v1066 = load i64, ptr %slot20, align 8
  store i64 %v1066, ptr %slot188, align 8
  %v1067 = load i64, ptr %slot188, align 8
  %v1068 = load i64, ptr %slot184, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1067, i64 %v1068) nomerge, !dbg !128
  br label %bb_rcslotdone315
bb_rcslotdone315:
  %v1069 = load i64, ptr %slot8, align 8
  store i64 %v1069, ptr %slot189, align 8
  %v1070 = load i64, ptr %slot9, align 8
  store i64 %v1070, ptr %slot190, align 8
  %v1071 = load i64, ptr %slot190, align 8
  %v1072 = load i64, ptr %slot189, align 8
  %p1073 = inttoptr i64 %v1071 to ptr
  %p1074 = inttoptr i64 %v1072 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1074, ptr %p1073, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1075 = load i64, ptr %slot5, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i32 2, ptr %p1076, align 4, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot7, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  %ld1079 = load i32, ptr %p1078, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1079, ptr %slot191, align 8
  %v1080 = load i32, ptr %slot191, align 8
  %v1081 = load i64, ptr %slot5, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i32 %v1080, ptr %p1082, align 4, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot6, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i32 0, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot4, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i32 1, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot189, align 8
  %v1088 = load i64, ptr %slot11, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  store i64 %v1087, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  %v1090 = load i64, ptr %slot4, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %ld1092 = load i32, ptr %p1091, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1092, ptr %slot192, align 8
  %v1093 = load i32, ptr %slot192, align 8
  %cv1094 = zext i32 %v1093 to i64
  %cond1095 = icmp ne i64 %cv1094, 0
  br i1 %cond1095, label %bb_rcslotdrop332, label %bb_rcslotdone332
bb_rcslotdrop332:
  %v1096 = load i64, ptr %slot4, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  store i32 0, ptr %p1097, align 4, !alias.scope !3, !noalias !4
  %v1098 = load i64, ptr %slot8, align 8
  store i64 %v1098, ptr %slot193, align 8
  %v1099 = load i64, ptr %slot5, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i32, ptr %p1100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1101, ptr %slot194, align 8
  %v1102 = load i32, ptr %slot194, align 8
  %op1103 = and i32 %v1102, 28
  store i32 %op1103, ptr %slot195, align 8
  %v1104 = load i32, ptr %slot195, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcslotrole332, label %bb_rcslotowner332
bb_rcslotrole332:
  %v1107 = load i64, ptr %slot20, align 8
  store i64 %v1107, ptr %slot196, align 8
  %v1108 = load i64, ptr %slot196, align 8
  %v1109 = load i64, ptr %slot193, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1108, i64 %v1109) nomerge, !dbg !130
  br label %bb_rcslotdone332
bb_rcslotowner332:
  %v1110 = load i64, ptr %slot20, align 8
  store i64 %v1110, ptr %slot197, align 8
  %v1111 = load i64, ptr %slot197, align 8
  %v1112 = load i64, ptr %slot193, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1111, i64 %v1112) nomerge, !dbg !130
  br label %bb_rcslotdone332
bb_rcslotdone332:
  br label %bb_i3
bb_i71:
  %v1113 = load i64, ptr %slot11, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i64 0, ptr %p1114, align 8, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot11, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %ld1117 = load i64, ptr %p1116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1117, ptr %slot198, align 8
  %v1118 = load i64, ptr %slot4, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  %ld1120 = load i32, ptr %p1119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1120, ptr %slot199, align 8
  %v1121 = load i32, ptr %slot199, align 8
  %cv1122 = zext i32 %v1121 to i64
  %cond1123 = icmp ne i64 %cv1122, 0
  br i1 %cond1123, label %bb_rcslotdrop342, label %bb_rcslotdone342
bb_rcslotdrop342:
  %v1124 = load i64, ptr %slot4, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  store i32 0, ptr %p1125, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone342
bb_rcslotdone342:
  %v1126 = load i64, ptr %slot198, align 8
  ret i64 %v1126
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64, i64)
declare void @myl_f_f7fe184bbb33727cb8df44fff0ff97b55eaf2aa52245a898b3583a04dc30e80b(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_79660bd341bc9b50ab49ac4f20489237247b8fc00e2519ad08a896cefc3baeab", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_79660bd341bc9b50ab49ac4f20489237247b8fc00e2519ad08a896cefc3baeab", linkageName: "myl_f_79660bd341bc9b50ab49ac4f20489237247b8fc00e2519ad08a896cefc3baeab", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 77351936134691551, i64 0, !"myl_f_79660bd341bc9b50ab49ac4f20489237247b8fc00e2519ad08a896cefc3baeab"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!128 = !DILocation(line: 69, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!130 = !DILocation(line: 70, column: 0, scope: !131)
