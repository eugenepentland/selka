target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v388 = load i64, ptr %slot1, align 8
  %op389 = add i64 %v388, 32
  store i64 %op389, ptr %slot4, align 8
  %mem390 = alloca i8, i64 8, align 8
  %ptr391 = ptrtoint ptr %mem390 to i64
  store i64 %ptr391, ptr %slot5, align 8
  %mem392 = alloca i8, i64 8, align 8
  %ptr393 = ptrtoint ptr %mem392 to i64
  store i64 %ptr393, ptr %slot6, align 8
  %mem394 = alloca i8, i64 8, align 8
  %ptr395 = ptrtoint ptr %mem394 to i64
  store i64 %ptr395, ptr %slot7, align 8
  %mem396 = alloca i8, i64 8, align 8
  %ptr397 = ptrtoint ptr %mem396 to i64
  store i64 %ptr397, ptr %slot8, align 8
  %mem398 = alloca i8, i64 8, align 8
  %ptr399 = ptrtoint ptr %mem398 to i64
  store i64 %ptr399, ptr %slot9, align 8
  %mem400 = alloca i8, i64 8, align 8
  %ptr401 = ptrtoint ptr %mem400 to i64
  store i64 %ptr401, ptr %slot10, align 8
  %mem402 = alloca i8, i64 48, align 8
  %ptr403 = ptrtoint ptr %mem402 to i64
  store i64 %ptr403, ptr %slot11, align 8
  %mem404 = alloca i8, i64 208, align 8
  %ptr405 = ptrtoint ptr %mem404 to i64
  store i64 %ptr405, ptr %slot12, align 8
  %mem406 = alloca i8, i64 8, align 8
  %ptr407 = ptrtoint ptr %mem406 to i64
  store i64 %ptr407, ptr %slot13, align 8
  %mem408 = alloca i8, i64 8, align 8
  %ptr409 = ptrtoint ptr %mem408 to i64
  store i64 %ptr409, ptr %slot14, align 8
  %mem410 = alloca i8, i64 208, align 8
  %ptr411 = ptrtoint ptr %mem410 to i64
  store i64 %ptr411, ptr %slot15, align 8
  %mem412 = alloca i8, i64 8, align 8
  %ptr413 = ptrtoint ptr %mem412 to i64
  store i64 %ptr413, ptr %slot16, align 8
  %mem414 = alloca i8, i64 8, align 8
  %ptr415 = ptrtoint ptr %mem414 to i64
  store i64 %ptr415, ptr %slot17, align 8
  %mem416 = alloca i8, i64 8, align 8
  %ptr417 = ptrtoint ptr %mem416 to i64
  store i64 %ptr417, ptr %slot18, align 8
  %mem418 = alloca i8, i64 8, align 8
  %ptr419 = ptrtoint ptr %mem418 to i64
  store i64 %ptr419, ptr %slot19, align 8
  %mem420 = alloca i8, i64 8, align 8
  %ptr421 = ptrtoint ptr %mem420 to i64
  store i64 %ptr421, ptr %slot20, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem422 = alloca i8, i64 8, align 8
  %ptr423 = ptrtoint ptr %mem422 to i64
  store i64 %ptr423, ptr %slot21, align 8
  %v424 = load i64, ptr %slot1, align 8
  %op425 = add i64 %v424, 64
  store i64 %op425, ptr %slot22, align 8
  %v426 = load i64, ptr %slot22, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !4, !noalias !3
  store i64 %ld428, ptr %slot23, align 8
  %stack429 = call ptr @llvm.stacksave()
  %stackaddr430 = ptrtoint ptr %stack429 to i64
  %v431 = load i64, ptr %slot23, align 8
  %cmp432 = icmp ult i64 %stackaddr430, %v431
  %cv433 = zext i1 %cmp432 to i64
  store i64 %cv433, ptr %slot24, align 8
  %v434 = load i64, ptr %slot24, align 8
  %cond435 = icmp ne i64 %v434, 0
  br i1 %cond435, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v436 = load i64, ptr %slot1, align 8
  %p437 = inttoptr i64 %v436 to ptr
  call void @myl_qbe_fail_frame(ptr %p437) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v438 = load i64, ptr %slot2, align 8
  %v439 = load i64, ptr %slot16, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i64 %v438, ptr %p440, align 8, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot3, align 8
  %v442 = load i64, ptr %slot17, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i64 %v441, ptr %p443, align 8, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot1, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %call446 = call ptr @myl_qbe_heap(ptr %p445) nomerge, !dbg !112
  %calladdr447 = ptrtoint ptr %call446 to i64
  store i64 %calladdr447, ptr %slot25, align 8
  %v448 = load i64, ptr %slot1, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %call450 = call i64 @myl_qbe_region_mark(ptr %p449) nomerge, !dbg !112
  store i64 %call450, ptr %slot26, align 8
  %v451 = load i64, ptr %slot5, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i32 0, ptr %p452, align 4, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot6, align 8
  %p454 = inttoptr i64 %v453 to ptr
  store i32 0, ptr %p454, align 4, !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot7, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i32 0, ptr %p456, align 4, !alias.scope !3, !noalias !4
  %v457 = load i64, ptr %slot8, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i32 0, ptr %p458, align 4, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot9, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i32 0, ptr %p460, align 4, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot10, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i32 0, ptr %p462, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v463 = load i64, ptr %slot17, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %ld465 = load i64, ptr %p464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld465, ptr %slot27, align 8
  %v466 = load i64, ptr %slot27, align 8
  %v467 = load i64, ptr %slot18, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i64 %v466, ptr %p468, align 8, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot18, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ld471 = load i64, ptr %p470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld471, ptr %slot28, align 8
  %v472 = load i64, ptr %slot28, align 8
  %op473 = add i64 %v472, 40
  store i64 %op473, ptr %slot29, align 8
  %v474 = load i64, ptr %slot29, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !4, !noalias !3
  store i64 %ld476, ptr %slot30, align 8
  %v477 = load i64, ptr %slot30, align 8
  %v478 = load i64, ptr %slot18, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i64 %v477, ptr %p479, align 8, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot5, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i32, ptr %p481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld482, ptr %slot31, align 8
  %v483 = load i32, ptr %slot31, align 8
  %cv484 = zext i32 %v483 to i64
  %cond485 = icmp ne i64 %cv484, 0
  br i1 %cond485, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v486 = load i64, ptr %slot5, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 0, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot11, align 8
  store i64 %v488, ptr %slot32, align 8
  %v489 = load i64, ptr %slot6, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i32, ptr %p490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld491, ptr %slot33, align 8
  %v492 = load i32, ptr %slot33, align 8
  %op493 = and i32 %v492, 28
  store i32 %op493, ptr %slot34, align 8
  %v494 = load i32, ptr %slot34, align 8
  %cv495 = zext i32 %v494 to i64
  %cond496 = icmp ne i64 %cv495, 0
  br i1 %cond496, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v497 = load i64, ptr %slot25, align 8
  store i64 %v497, ptr %slot35, align 8
  %v498 = load i64, ptr %slot35, align 8
  %v499 = load i64, ptr %slot32, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v498, i64 %v499) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v500 = load i64, ptr %slot25, align 8
  store i64 %v500, ptr %slot36, align 8
  %v501 = load i64, ptr %slot36, align 8
  %v502 = load i64, ptr %slot32, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v501, i64 %v502) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v503 = load i64, ptr %slot19, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i64 18446744073709551615, ptr %p504, align 8, !alias.scope !3, !noalias !4
  %v505 = load i64, ptr %slot19, align 8
  %p506 = inttoptr i64 %v505 to ptr
  %ld507 = load i64, ptr %p506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld507, ptr %slot37, align 8
  %v508 = load i64, ptr %slot18, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i64, ptr %p509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld510, ptr %slot38, align 8
  %v511 = load i64, ptr %slot38, align 8
  %v512 = load i64, ptr %slot37, align 8
  %cmp513 = icmp eq i64 %v511, %v512
  %cv514 = zext i1 %cmp513 to i64
  store i64 %cv514, ptr %slot39, align 8
  %v515 = load i64, ptr %slot39, align 8
  %v516 = load i64, ptr %slot18, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i64 %v515, ptr %p517, align 8, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot18, align 8
  %p519 = inttoptr i64 %v518 to ptr
  %ld520 = load i64, ptr %p519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld520, ptr %slot40, align 8
  %v521 = load i64, ptr %slot40, align 8
  %cond522 = icmp ne i64 %v521, 0
  br i1 %cond522, label %bb_next26, label %bb_i7
bb_next26:
  %p523 = inttoptr i64 ptrtoint (ptr @myl_lit_f65c774382e8464e62d85b25bc3a05a9ed3170e99614fb9f4289e109b0f73715 to i64) to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !4, !noalias !3
  store i64 %ld524, ptr %slot41, align 8
  %v525 = load i64, ptr %slot41, align 8
  %v526 = load i64, ptr %slot18, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 %v525, ptr %p527, align 8, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot18, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot42, align 8
  %v531 = load i64, ptr %slot42, align 8
  %v532 = load i64, ptr %slot13, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 %v531, ptr %p533, align 8, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot13, align 8
  store i64 %v534, ptr %slot43, align 8
  %v535 = load i64, ptr %slot15, align 8
  store i64 %v535, ptr %slot44, align 8
  %v536 = load i64, ptr %slot43, align 8
  %v537 = load i64, ptr %slot44, align 8
  %p538 = inttoptr i64 %v536 to ptr
  %p539 = inttoptr i64 %v537 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p539, ptr %p538, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot10, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i32 2, ptr %p541, align 4, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot9, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i32 1, ptr %p543, align 4, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot11, align 8
  store i64 %v544, ptr %slot45, align 8
  %v545 = load i64, ptr %slot15, align 8
  store i64 %v545, ptr %slot46, align 8
  %v546 = load i64, ptr %slot46, align 8
  %v547 = load i64, ptr %slot45, align 8
  %p548 = inttoptr i64 %v546 to ptr
  %p549 = inttoptr i64 %v547 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p549, ptr %p548, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot6, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i32 2, ptr %p551, align 4, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot10, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i32, ptr %p553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld554, ptr %slot47, align 8
  %v555 = load i32, ptr %slot47, align 8
  %v556 = load i64, ptr %slot6, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i32 %v555, ptr %p557, align 4, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot9, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 0, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot5, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i32 1, ptr %p561, align 4, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot45, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %ld564 = load i64, ptr %p563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot48, align 8
  %v565 = load i64, ptr %slot48, align 8
  %v566 = load i64, ptr %slot18, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 %v565, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot18, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot49, align 8
  %v571 = load i64, ptr %slot18, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot50, align 8
  %v574 = load i64, ptr %slot50, align 8
  %v575 = load i64, ptr %slot13, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot13, align 8
  store i64 %v577, ptr %slot51, align 8
  %v578 = load i64, ptr %slot15, align 8
  store i64 %v578, ptr %slot52, align 8
  %v579 = load i64, ptr %slot26, align 8
  store i64 %v579, ptr %slot53, align 8
  %v580 = load i64, ptr %slot51, align 8
  %p582 = inttoptr i64 %v580 to ptr
  %gep583 = getelementptr i8, ptr %p582, i64 0
  %op581 = ptrtoint ptr %gep583 to i64
  store i64 %op581, ptr %slot54, align 8
  %v584 = load i64, ptr %slot54, align 8
  %p585 = inttoptr i64 %v584 to ptr
  %ld586 = load i64, ptr %p585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld586, ptr %slot55, align 8
  %v587 = load i64, ptr %slot55, align 8
  %cmp588 = icmp ne i64 %v587, 0
  %cv589 = zext i1 %cmp588 to i32
  store i32 %cv589, ptr %slot56, align 8
  %v590 = load i32, ptr %slot56, align 8
  %cv591 = zext i32 %v590 to i64
  %cond592 = icmp ne i64 %cv591, 0
  br i1 %cond592, label %bb_rcmoveheader50, label %bb_rcmovenext50
bb_rcmoveheader50:
  %v593 = load i64, ptr %slot55, align 8
  %op594 = sub i64 %v593, 16
  store i64 %op594, ptr %slot57, align 8
  %v595 = load i64, ptr %slot55, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %rgep597 = getelementptr i8, ptr %p596, i64 -16
  %ld598 = load i64, ptr %rgep597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld598, ptr %slot58, align 8
  %v599 = load i64, ptr %slot58, align 8
  %op600 = and i64 %v599, 5764607523034234881
  store i64 %op600, ptr %slot59, align 8
  %v601 = load i64, ptr %slot59, align 8
  %cmp602 = icmp ne i64 %v601, 0
  %cv603 = zext i1 %cmp602 to i32
  store i32 %cv603, ptr %slot60, align 8
  %v604 = load i32, ptr %slot60, align 8
  %cv605 = zext i32 %v604 to i64
  %cond606 = icmp ne i64 %cv605, 0
  br i1 %cond606, label %bb_rcmoveslow47, label %bb_rcmovenext50
bb_rcmovenext50:
  %v607 = load i64, ptr %slot51, align 8
  %v608 = load i64, ptr %slot52, align 8
  %p609 = inttoptr i64 %v607 to ptr
  %p610 = inttoptr i64 %v608 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p610, ptr %p609, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v611 = load i64, ptr %slot51, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i64 0, ptr %p612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved47
bb_rcmoveslow47:
  %v613 = load i64, ptr %slot25, align 8
  %v614 = load i64, ptr %slot52, align 8
  %v615 = load i64, ptr %slot51, align 8
  %v616 = load i64, ptr %slot53, align 8
  %cv617 = trunc i64 %v616 to i32
  %call618 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v613, i64 %v614, i64 %v615, i32 %cv617) nomerge, !dbg !116
  store i32 %call618, ptr %slot61, align 8
  %v619 = load i32, ptr %slot61, align 8
  %cv620 = zext i32 %v619 to i64
  %cond621 = icmp ne i64 %cv620, 0
  br i1 %cond621, label %bb_rcsuccess57, label %bb_rcfailure57
bb_rcfailure57:
  %v622 = load i64, ptr %slot25, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %call624 = call i32 @myl_rc_take_failure(ptr %p623) nomerge, !dbg !116
  store i32 %call624, ptr %slot62, align 8
  %v625 = load i64, ptr %slot1, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %v627 = load i32, ptr %slot62, align 8
  %call628 = call i32 @myl_qbe_rc_status(ptr %p626, i32 %v627) nomerge, !dbg !116
  store i32 %call628, ptr %slot63, align 8
  br label %bb_failure
bb_rcsuccess57:
  br label %bb_rcmoved47
bb_rcmoved47:
  %v629 = load i64, ptr %slot5, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i32 0, ptr %p630, align 4, !alias.scope !3, !noalias !4
  %v631 = load i64, ptr %slot10, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i32 2, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot9, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i32 1, ptr %p634, align 4, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot15, align 8
  store i64 %v635, ptr %slot64, align 8
  %v636 = load i64, ptr %slot64, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot65, align 8
  %v639 = load i64, ptr %slot9, align 8
  %p640 = inttoptr i64 %v639 to ptr
  store i32 0, ptr %p640, align 4, !alias.scope !3, !noalias !4
  %v641 = load i64, ptr %slot5, align 8
  %p642 = inttoptr i64 %v641 to ptr
  %ld643 = load i32, ptr %p642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld643, ptr %slot66, align 8
  %v644 = load i32, ptr %slot66, align 8
  %cv645 = zext i32 %v644 to i64
  %cond646 = icmp ne i64 %cv645, 0
  br i1 %cond646, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v647 = load i64, ptr %slot5, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i32 0, ptr %p648, align 4, !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot11, align 8
  store i64 %v649, ptr %slot67, align 8
  %v650 = load i64, ptr %slot6, align 8
  %p651 = inttoptr i64 %v650 to ptr
  %ld652 = load i32, ptr %p651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld652, ptr %slot68, align 8
  %v653 = load i32, ptr %slot68, align 8
  %op654 = and i32 %v653, 28
  store i32 %op654, ptr %slot69, align 8
  %v655 = load i32, ptr %slot69, align 8
  %cv656 = zext i32 %v655 to i64
  %cond657 = icmp ne i64 %cv656, 0
  br i1 %cond657, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v658 = load i64, ptr %slot25, align 8
  store i64 %v658, ptr %slot70, align 8
  %v659 = load i64, ptr %slot67, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %ld661 = load i64, ptr %p660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld661, ptr %slot71, align 8
  %v662 = load i64, ptr %slot71, align 8
  %cmp663 = icmp ne i64 %v662, 0
  %cv664 = zext i1 %cmp663 to i32
  store i32 %cv664, ptr %slot72, align 8
  %v665 = load i32, ptr %slot72, align 8
  %cv666 = zext i32 %v665 to i64
  %cond667 = icmp ne i64 %cv666, 0
  br i1 %cond667, label %bb_rcgnn84, label %bb_rcgdone84
bb_rcgnn84:
  %v668 = load i64, ptr %slot71, align 8
  %op669 = sub i64 %v668, 16
  store i64 %op669, ptr %slot73, align 8
  %v670 = load i64, ptr %slot71, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %rgep672 = getelementptr i8, ptr %p671, i64 -16
  %ld673 = load i64, ptr %rgep672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld673, ptr %slot74, align 8
  %v674 = load i64, ptr %slot74, align 8
  %op675 = and i64 %v674, 4611686018427387906
  store i64 %op675, ptr %slot75, align 8
  %v676 = load i64, ptr %slot75, align 8
  %cmp677 = icmp ne i64 %v676, 0
  %cv678 = zext i1 %cmp677 to i32
  store i32 %cv678, ptr %slot76, align 8
  %v679 = load i32, ptr %slot76, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcgclear84, label %bb_rcgcounted84
bb_rcgcounted84:
  %v682 = load i64, ptr %slot71, align 8
  %op683 = sub i64 %v682, 24
  store i64 %op683, ptr %slot77, align 8
  %v684 = load i64, ptr %slot71, align 8
  %p685 = inttoptr i64 %v684 to ptr
  %rgep686 = getelementptr i8, ptr %p685, i64 -24
  %ld687 = load i64, ptr %rgep686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld687, ptr %slot78, align 8
  %v688 = load i64, ptr %slot78, align 8
  %op689 = sub i64 %v688, 1
  store i64 %op689, ptr %slot79, align 8
  %v690 = load i64, ptr %slot79, align 8
  %cmp691 = icmp eq i64 %v690, 0
  %cv692 = zext i1 %cmp691 to i32
  store i32 %cv692, ptr %slot80, align 8
  %v693 = load i32, ptr %slot80, align 8
  %cv694 = zext i32 %v693 to i64
  %cond695 = icmp ne i64 %cv694, 0
  br i1 %cond695, label %bb_rcglast84, label %bb_rcgdec84
bb_rcglast84:
  %v696 = load i64, ptr %slot71, align 8
  %op697 = sub i64 %v696, 32
  store i64 %op697, ptr %slot81, align 8
  %v698 = load i64, ptr %slot71, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %rgep700 = getelementptr i8, ptr %p699, i64 -32
  %ld701 = load i64, ptr %rgep700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld701, ptr %slot82, align 8
  %v702 = load i64, ptr %slot82, align 8
  %cmp703 = icmp ne i64 %v702, 0
  %cv704 = zext i1 %cmp703 to i32
  store i32 %cv704, ptr %slot83, align 8
  %v705 = load i32, ptr %slot83, align 8
  %cv706 = zext i32 %v705 to i64
  %cond707 = icmp ne i64 %cv706, 0
  br i1 %cond707, label %bb_rcgdec84, label %bb_rcgslow84
bb_rcgslow84:
  %v708 = load i64, ptr %slot70, align 8
  %v709 = load i64, ptr %slot67, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v708, i64 %v709) nomerge, !dbg !116
  br label %bb_rcgdone84
bb_rcgdec84:
  %v710 = load i64, ptr %slot79, align 8
  %v711 = load i64, ptr %slot71, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %rgep713 = getelementptr i8, ptr %p712, i64 -24
  store i64 %v710, ptr %rgep713, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear84
bb_rcgclear84:
  %v714 = load i64, ptr %slot67, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i64 0, ptr %p715, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone84
bb_rcgdone84:
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v716 = load i64, ptr %slot25, align 8
  store i64 %v716, ptr %slot84, align 8
  %v717 = load i64, ptr %slot67, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot85, align 8
  %v720 = load i64, ptr %slot85, align 8
  %cmp721 = icmp ne i64 %v720, 0
  %cv722 = zext i1 %cmp721 to i32
  store i32 %cv722, ptr %slot86, align 8
  %v723 = load i32, ptr %slot86, align 8
  %cv724 = zext i32 %v723 to i64
  %cond725 = icmp ne i64 %cv724, 0
  br i1 %cond725, label %bb_rcgnn99, label %bb_rcgdone99
bb_rcgnn99:
  %v726 = load i64, ptr %slot85, align 8
  %op727 = sub i64 %v726, 16
  store i64 %op727, ptr %slot87, align 8
  %v728 = load i64, ptr %slot85, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %rgep730 = getelementptr i8, ptr %p729, i64 -16
  %ld731 = load i64, ptr %rgep730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld731, ptr %slot88, align 8
  %v732 = load i64, ptr %slot88, align 8
  %op733 = and i64 %v732, 4611686018427387906
  store i64 %op733, ptr %slot89, align 8
  %v734 = load i64, ptr %slot89, align 8
  %cmp735 = icmp ne i64 %v734, 0
  %cv736 = zext i1 %cmp735 to i32
  store i32 %cv736, ptr %slot90, align 8
  %v737 = load i32, ptr %slot90, align 8
  %cv738 = zext i32 %v737 to i64
  %cond739 = icmp ne i64 %cv738, 0
  br i1 %cond739, label %bb_rcgclear99, label %bb_rcgcounted99
bb_rcgcounted99:
  %v740 = load i64, ptr %slot85, align 8
  %op741 = sub i64 %v740, 32
  store i64 %op741, ptr %slot91, align 8
  %v742 = load i64, ptr %slot85, align 8
  %p743 = inttoptr i64 %v742 to ptr
  %rgep744 = getelementptr i8, ptr %p743, i64 -32
  %ld745 = load i64, ptr %rgep744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld745, ptr %slot92, align 8
  %v746 = load i64, ptr %slot92, align 8
  %op747 = sub i64 %v746, 1
  store i64 %op747, ptr %slot93, align 8
  %v748 = load i64, ptr %slot93, align 8
  %cmp749 = icmp eq i64 %v748, 0
  %cv750 = zext i1 %cmp749 to i32
  store i32 %cv750, ptr %slot94, align 8
  %v751 = load i32, ptr %slot94, align 8
  %cv752 = zext i32 %v751 to i64
  %cond753 = icmp ne i64 %cv752, 0
  br i1 %cond753, label %bb_rcglast99, label %bb_rcgdec99
bb_rcglast99:
  %v754 = load i64, ptr %slot85, align 8
  %op755 = sub i64 %v754, 24
  store i64 %op755, ptr %slot95, align 8
  %v756 = load i64, ptr %slot85, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %rgep758 = getelementptr i8, ptr %p757, i64 -24
  %ld759 = load i64, ptr %rgep758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld759, ptr %slot96, align 8
  %v760 = load i64, ptr %slot96, align 8
  %cmp761 = icmp ne i64 %v760, 0
  %cv762 = zext i1 %cmp761 to i32
  store i32 %cv762, ptr %slot97, align 8
  %v763 = load i32, ptr %slot97, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcgdec99, label %bb_rcgslow99
bb_rcgslow99:
  %v766 = load i64, ptr %slot84, align 8
  %v767 = load i64, ptr %slot67, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v766, i64 %v767) nomerge, !dbg !116
  br label %bb_rcgdone99
bb_rcgdec99:
  %v768 = load i64, ptr %slot93, align 8
  %v769 = load i64, ptr %slot85, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %rgep771 = getelementptr i8, ptr %p770, i64 -32
  store i64 %v768, ptr %rgep771, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear99
bb_rcgclear99:
  %v772 = load i64, ptr %slot67, align 8
  %p773 = inttoptr i64 %v772 to ptr
  store i64 0, ptr %p773, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone99
bb_rcgdone99:
  br label %bb_rcslotdone68
bb_rcslotdone68:
  %v774 = load i64, ptr %slot65, align 8
  ret i64 %v774
bb_i7:
  %p775 = inttoptr i64 ptrtoint (ptr @myl_lit_6fed35e3009e497ab580214c876d7a746f7a24cf38303b15909afebc8b6b79d5 to i64) to ptr
  %ld776 = load i64, ptr %p775, align 8, !alias.scope !4, !noalias !3
  store i64 %ld776, ptr %slot98, align 8
  %v777 = load i64, ptr %slot98, align 8
  %v778 = load i64, ptr %slot18, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i64 %v777, ptr %p779, align 8, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot18, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %ld782 = load i64, ptr %p781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld782, ptr %slot99, align 8
  %v783 = load i64, ptr %slot99, align 8
  %v784 = load i64, ptr %slot13, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i64 %v783, ptr %p785, align 8, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot13, align 8
  store i64 %v786, ptr %slot100, align 8
  %v787 = load i64, ptr %slot15, align 8
  store i64 %v787, ptr %slot101, align 8
  %v788 = load i64, ptr %slot100, align 8
  %v789 = load i64, ptr %slot101, align 8
  %p790 = inttoptr i64 %v788 to ptr
  %p791 = inttoptr i64 %v789 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p791, ptr %p790, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot10, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i32 2, ptr %p793, align 4, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot9, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i32 1, ptr %p795, align 4, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot11, align 8
  store i64 %v796, ptr %slot102, align 8
  %v797 = load i64, ptr %slot15, align 8
  store i64 %v797, ptr %slot103, align 8
  %v798 = load i64, ptr %slot103, align 8
  %v799 = load i64, ptr %slot102, align 8
  %p800 = inttoptr i64 %v798 to ptr
  %p801 = inttoptr i64 %v799 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p801, ptr %p800, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot6, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i32 2, ptr %p803, align 4, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot10, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i32, ptr %p805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld806, ptr %slot104, align 8
  %v807 = load i32, ptr %slot104, align 8
  %v808 = load i64, ptr %slot6, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 %v807, ptr %p809, align 4, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot9, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 0, ptr %p811, align 4, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot5, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i32 1, ptr %p813, align 4, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot102, align 8
  %p815 = inttoptr i64 %v814 to ptr
  %ld816 = load i64, ptr %p815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld816, ptr %slot105, align 8
  %v817 = load i64, ptr %slot105, align 8
  %v818 = load i64, ptr %slot18, align 8
  %p819 = inttoptr i64 %v818 to ptr
  store i64 %v817, ptr %p819, align 8, !alias.scope !3, !noalias !4
  %v820 = load i64, ptr %slot16, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %ld822 = load i64, ptr %p821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld822, ptr %slot106, align 8
  %v823 = load i64, ptr %slot106, align 8
  %v824 = load i64, ptr %slot19, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i64 %v823, ptr %p825, align 8, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot17, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld828, ptr %slot107, align 8
  %v829 = load i64, ptr %slot107, align 8
  %v830 = load i64, ptr %slot20, align 8
  %p831 = inttoptr i64 %v830 to ptr
  store i64 %v829, ptr %p831, align 8, !alias.scope !3, !noalias !4
  %v832 = load i64, ptr %slot20, align 8
  %p833 = inttoptr i64 %v832 to ptr
  %ld834 = load i64, ptr %p833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld834, ptr %slot108, align 8
  %v835 = load i64, ptr %slot108, align 8
  %op836 = add i64 %v835, 40
  store i64 %op836, ptr %slot109, align 8
  %v837 = load i64, ptr %slot109, align 8
  %p838 = inttoptr i64 %v837 to ptr
  %ld839 = load i64, ptr %p838, align 8, !alias.scope !4, !noalias !3
  store i64 %ld839, ptr %slot110, align 8
  %v840 = load i64, ptr %slot110, align 8
  %v841 = load i64, ptr %slot20, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i64 %v840, ptr %p842, align 8, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot19, align 8
  %p844 = inttoptr i64 %v843 to ptr
  %ld845 = load i64, ptr %p844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld845, ptr %slot111, align 8
  %v846 = load i64, ptr %slot20, align 8
  %p847 = inttoptr i64 %v846 to ptr
  %ld848 = load i64, ptr %p847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld848, ptr %slot112, align 8
  %v849 = load i64, ptr %slot1, align 8
  %v850 = load i64, ptr %slot111, align 8
  %v851 = load i64, ptr %slot112, align 8
  %call852 = call i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64 %v849, i64 %v850, i64 %v851) nomerge, !dbg !118
  store i64 %call852, ptr %slot113, align 8
  %v853 = load i64, ptr %slot113, align 8
  %v854 = load i64, ptr %slot19, align 8
  %p855 = inttoptr i64 %v854 to ptr
  store i64 %v853, ptr %p855, align 8, !alias.scope !3, !noalias !4
  %v856 = load i64, ptr %slot7, align 8
  %p857 = inttoptr i64 %v856 to ptr
  %ld858 = load i32, ptr %p857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld858, ptr %slot114, align 8
  %v859 = load i32, ptr %slot114, align 8
  %cv860 = zext i32 %v859 to i64
  %cond861 = icmp ne i64 %cv860, 0
  br i1 %cond861, label %bb_rcslotdrop156, label %bb_rcslotdone156
bb_rcslotdrop156:
  %v862 = load i64, ptr %slot7, align 8
  %p863 = inttoptr i64 %v862 to ptr
  store i32 0, ptr %p863, align 4, !alias.scope !3, !noalias !4
  %v864 = load i64, ptr %slot12, align 8
  store i64 %v864, ptr %slot115, align 8
  %v865 = load i64, ptr %slot8, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i32, ptr %p866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld867, ptr %slot116, align 8
  %v868 = load i32, ptr %slot116, align 8
  %op869 = and i32 %v868, 28
  store i32 %op869, ptr %slot117, align 8
  %v870 = load i32, ptr %slot117, align 8
  %cv871 = zext i32 %v870 to i64
  %cond872 = icmp ne i64 %cv871, 0
  br i1 %cond872, label %bb_rcslotrole156, label %bb_rcslotowner156
bb_rcslotrole156:
  %v873 = load i64, ptr %slot25, align 8
  store i64 %v873, ptr %slot118, align 8
  %v874 = load i64, ptr %slot118, align 8
  %v875 = load i64, ptr %slot115, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v874, i64 %v875) nomerge, !dbg !118
  br label %bb_rcslotdone156
bb_rcslotowner156:
  %v876 = load i64, ptr %slot25, align 8
  store i64 %v876, ptr %slot119, align 8
  %v877 = load i64, ptr %slot119, align 8
  %v878 = load i64, ptr %slot115, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v877, i64 %v878) nomerge, !dbg !118
  br label %bb_rcslotdone156
bb_rcslotdone156:
  %v879 = load i64, ptr %slot18, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot120, align 8
  %v882 = load i64, ptr %slot19, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %ld884 = load i64, ptr %p883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld884, ptr %slot121, align 8
  %v885 = load i64, ptr %slot18, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i64, ptr %p886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld887, ptr %slot122, align 8
  %v888 = load i64, ptr %slot19, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %ld890 = load i64, ptr %p889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld890, ptr %slot123, align 8
  %v891 = load i64, ptr %slot25, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %v893 = load i64, ptr %slot122, align 8
  %p894 = inttoptr i64 %v893 to ptr
  %v895 = load i64, ptr %slot123, align 8
  %p896 = inttoptr i64 %v895 to ptr
  %call897 = call ptr @myl_native_bytes_concat(ptr %p892, ptr %p894, ptr %p896) nomerge, !dbg !120
  %calladdr898 = ptrtoint ptr %call897 to i64
  store i64 %calladdr898, ptr %slot124, align 8
  %v899 = load i64, ptr %slot124, align 8
  %cond900 = icmp ne i64 %v899, 0
  br i1 %cond900, label %bb_success169, label %bb_failed169
bb_failed169:
  %v901 = load i64, ptr %slot1, align 8
  %p902 = inttoptr i64 %v901 to ptr
  call void @myl_qbe_fail_allocation(ptr %p902) nomerge, !dbg !120
  unreachable
bb_success169:
  %v903 = load i64, ptr %slot124, align 8
  %v904 = load i64, ptr %slot18, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i64 %v903, ptr %p905, align 8, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot18, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i64, ptr %p907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld908, ptr %slot125, align 8
  %v909 = load i64, ptr %slot125, align 8
  %v910 = load i64, ptr %slot13, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i64 %v909, ptr %p911, align 8, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot13, align 8
  store i64 %v912, ptr %slot126, align 8
  %v913 = load i64, ptr %slot15, align 8
  store i64 %v913, ptr %slot127, align 8
  %v914 = load i64, ptr %slot126, align 8
  %v915 = load i64, ptr %slot127, align 8
  %p916 = inttoptr i64 %v914 to ptr
  %p917 = inttoptr i64 %v915 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p917, ptr %p916, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v918 = load i64, ptr %slot10, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 2, ptr %p919, align 4, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot9, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i32 1, ptr %p921, align 4, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot5, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i32, ptr %p923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld924, ptr %slot128, align 8
  %v925 = load i32, ptr %slot128, align 8
  %cv926 = zext i32 %v925 to i64
  %cond927 = icmp ne i64 %cv926, 0
  br i1 %cond927, label %bb_rcslotdrop177, label %bb_rcslotdone177
bb_rcslotdrop177:
  %v928 = load i64, ptr %slot5, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i32 0, ptr %p929, align 4, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot11, align 8
  store i64 %v930, ptr %slot129, align 8
  %v931 = load i64, ptr %slot6, align 8
  %p932 = inttoptr i64 %v931 to ptr
  %ld933 = load i32, ptr %p932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld933, ptr %slot130, align 8
  %v934 = load i32, ptr %slot130, align 8
  %op935 = and i32 %v934, 28
  store i32 %op935, ptr %slot131, align 8
  %v936 = load i32, ptr %slot131, align 8
  %cv937 = zext i32 %v936 to i64
  %cond938 = icmp ne i64 %cv937, 0
  br i1 %cond938, label %bb_rcslotrole177, label %bb_rcslotowner177
bb_rcslotrole177:
  %v939 = load i64, ptr %slot25, align 8
  store i64 %v939, ptr %slot132, align 8
  %v940 = load i64, ptr %slot129, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i64, ptr %p941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld942, ptr %slot133, align 8
  %v943 = load i64, ptr %slot133, align 8
  %cmp944 = icmp ne i64 %v943, 0
  %cv945 = zext i1 %cmp944 to i32
  store i32 %cv945, ptr %slot134, align 8
  %v946 = load i32, ptr %slot134, align 8
  %cv947 = zext i32 %v946 to i64
  %cond948 = icmp ne i64 %cv947, 0
  br i1 %cond948, label %bb_rcgnn193, label %bb_rcgdone193
bb_rcgnn193:
  %v949 = load i64, ptr %slot133, align 8
  %op950 = sub i64 %v949, 16
  store i64 %op950, ptr %slot135, align 8
  %v951 = load i64, ptr %slot133, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %rgep953 = getelementptr i8, ptr %p952, i64 -16
  %ld954 = load i64, ptr %rgep953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld954, ptr %slot136, align 8
  %v955 = load i64, ptr %slot136, align 8
  %op956 = and i64 %v955, 4611686018427387906
  store i64 %op956, ptr %slot137, align 8
  %v957 = load i64, ptr %slot137, align 8
  %cmp958 = icmp ne i64 %v957, 0
  %cv959 = zext i1 %cmp958 to i32
  store i32 %cv959, ptr %slot138, align 8
  %v960 = load i32, ptr %slot138, align 8
  %cv961 = zext i32 %v960 to i64
  %cond962 = icmp ne i64 %cv961, 0
  br i1 %cond962, label %bb_rcgclear193, label %bb_rcgcounted193
bb_rcgcounted193:
  %v963 = load i64, ptr %slot133, align 8
  %op964 = sub i64 %v963, 24
  store i64 %op964, ptr %slot139, align 8
  %v965 = load i64, ptr %slot133, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %rgep967 = getelementptr i8, ptr %p966, i64 -24
  %ld968 = load i64, ptr %rgep967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld968, ptr %slot140, align 8
  %v969 = load i64, ptr %slot140, align 8
  %op970 = sub i64 %v969, 1
  store i64 %op970, ptr %slot141, align 8
  %v971 = load i64, ptr %slot141, align 8
  %cmp972 = icmp eq i64 %v971, 0
  %cv973 = zext i1 %cmp972 to i32
  store i32 %cv973, ptr %slot142, align 8
  %v974 = load i32, ptr %slot142, align 8
  %cv975 = zext i32 %v974 to i64
  %cond976 = icmp ne i64 %cv975, 0
  br i1 %cond976, label %bb_rcglast193, label %bb_rcgdec193
bb_rcglast193:
  %v977 = load i64, ptr %slot133, align 8
  %op978 = sub i64 %v977, 32
  store i64 %op978, ptr %slot143, align 8
  %v979 = load i64, ptr %slot133, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %rgep981 = getelementptr i8, ptr %p980, i64 -32
  %ld982 = load i64, ptr %rgep981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld982, ptr %slot144, align 8
  %v983 = load i64, ptr %slot144, align 8
  %cmp984 = icmp ne i64 %v983, 0
  %cv985 = zext i1 %cmp984 to i32
  store i32 %cv985, ptr %slot145, align 8
  %v986 = load i32, ptr %slot145, align 8
  %cv987 = zext i32 %v986 to i64
  %cond988 = icmp ne i64 %cv987, 0
  br i1 %cond988, label %bb_rcgdec193, label %bb_rcgslow193
bb_rcgslow193:
  %v989 = load i64, ptr %slot132, align 8
  %v990 = load i64, ptr %slot129, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v989, i64 %v990) nomerge, !dbg !120
  br label %bb_rcgdone193
bb_rcgdec193:
  %v991 = load i64, ptr %slot141, align 8
  %v992 = load i64, ptr %slot133, align 8
  %p993 = inttoptr i64 %v992 to ptr
  %rgep994 = getelementptr i8, ptr %p993, i64 -24
  store i64 %v991, ptr %rgep994, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear193
bb_rcgclear193:
  %v995 = load i64, ptr %slot129, align 8
  %p996 = inttoptr i64 %v995 to ptr
  store i64 0, ptr %p996, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone193
bb_rcgdone193:
  br label %bb_rcslotdone177
bb_rcslotowner177:
  %v997 = load i64, ptr %slot25, align 8
  store i64 %v997, ptr %slot146, align 8
  %v998 = load i64, ptr %slot129, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %ld1000 = load i64, ptr %p999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1000, ptr %slot147, align 8
  %v1001 = load i64, ptr %slot147, align 8
  %cmp1002 = icmp ne i64 %v1001, 0
  %cv1003 = zext i1 %cmp1002 to i32
  store i32 %cv1003, ptr %slot148, align 8
  %v1004 = load i32, ptr %slot148, align 8
  %cv1005 = zext i32 %v1004 to i64
  %cond1006 = icmp ne i64 %cv1005, 0
  br i1 %cond1006, label %bb_rcgnn208, label %bb_rcgdone208
bb_rcgnn208:
  %v1007 = load i64, ptr %slot147, align 8
  %op1008 = sub i64 %v1007, 16
  store i64 %op1008, ptr %slot149, align 8
  %v1009 = load i64, ptr %slot147, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %rgep1011 = getelementptr i8, ptr %p1010, i64 -16
  %ld1012 = load i64, ptr %rgep1011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1012, ptr %slot150, align 8
  %v1013 = load i64, ptr %slot150, align 8
  %op1014 = and i64 %v1013, 4611686018427387906
  store i64 %op1014, ptr %slot151, align 8
  %v1015 = load i64, ptr %slot151, align 8
  %cmp1016 = icmp ne i64 %v1015, 0
  %cv1017 = zext i1 %cmp1016 to i32
  store i32 %cv1017, ptr %slot152, align 8
  %v1018 = load i32, ptr %slot152, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcgclear208, label %bb_rcgcounted208
bb_rcgcounted208:
  %v1021 = load i64, ptr %slot147, align 8
  %op1022 = sub i64 %v1021, 32
  store i64 %op1022, ptr %slot153, align 8
  %v1023 = load i64, ptr %slot147, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %rgep1025 = getelementptr i8, ptr %p1024, i64 -32
  %ld1026 = load i64, ptr %rgep1025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1026, ptr %slot154, align 8
  %v1027 = load i64, ptr %slot154, align 8
  %op1028 = sub i64 %v1027, 1
  store i64 %op1028, ptr %slot155, align 8
  %v1029 = load i64, ptr %slot155, align 8
  %cmp1030 = icmp eq i64 %v1029, 0
  %cv1031 = zext i1 %cmp1030 to i32
  store i32 %cv1031, ptr %slot156, align 8
  %v1032 = load i32, ptr %slot156, align 8
  %cv1033 = zext i32 %v1032 to i64
  %cond1034 = icmp ne i64 %cv1033, 0
  br i1 %cond1034, label %bb_rcglast208, label %bb_rcgdec208
bb_rcglast208:
  %v1035 = load i64, ptr %slot147, align 8
  %op1036 = sub i64 %v1035, 24
  store i64 %op1036, ptr %slot157, align 8
  %v1037 = load i64, ptr %slot147, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %rgep1039 = getelementptr i8, ptr %p1038, i64 -24
  %ld1040 = load i64, ptr %rgep1039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1040, ptr %slot158, align 8
  %v1041 = load i64, ptr %slot158, align 8
  %cmp1042 = icmp ne i64 %v1041, 0
  %cv1043 = zext i1 %cmp1042 to i32
  store i32 %cv1043, ptr %slot159, align 8
  %v1044 = load i32, ptr %slot159, align 8
  %cv1045 = zext i32 %v1044 to i64
  %cond1046 = icmp ne i64 %cv1045, 0
  br i1 %cond1046, label %bb_rcgdec208, label %bb_rcgslow208
bb_rcgslow208:
  %v1047 = load i64, ptr %slot146, align 8
  %v1048 = load i64, ptr %slot129, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1047, i64 %v1048) nomerge, !dbg !120
  br label %bb_rcgdone208
bb_rcgdec208:
  %v1049 = load i64, ptr %slot155, align 8
  %v1050 = load i64, ptr %slot147, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %rgep1052 = getelementptr i8, ptr %p1051, i64 -32
  store i64 %v1049, ptr %rgep1052, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear208
bb_rcgclear208:
  %v1053 = load i64, ptr %slot129, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 0, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone208
bb_rcgdone208:
  br label %bb_rcslotdone177
bb_rcslotdone177:
  %v1055 = load i64, ptr %slot7, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i32, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1057, ptr %slot160, align 8
  %v1058 = load i32, ptr %slot160, align 8
  %cv1059 = zext i32 %v1058 to i64
  %cond1060 = icmp ne i64 %cv1059, 0
  br i1 %cond1060, label %bb_rcslotdrop214, label %bb_rcslotdone214
bb_rcslotdrop214:
  %v1061 = load i64, ptr %slot7, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i32 0, ptr %p1062, align 4, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot12, align 8
  store i64 %v1063, ptr %slot161, align 8
  %v1064 = load i64, ptr %slot8, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i32, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1066, ptr %slot162, align 8
  %v1067 = load i32, ptr %slot162, align 8
  %op1068 = and i32 %v1067, 28
  store i32 %op1068, ptr %slot163, align 8
  %v1069 = load i32, ptr %slot163, align 8
  %cv1070 = zext i32 %v1069 to i64
  %cond1071 = icmp ne i64 %cv1070, 0
  br i1 %cond1071, label %bb_rcslotrole214, label %bb_rcslotowner214
bb_rcslotrole214:
  %v1072 = load i64, ptr %slot25, align 8
  store i64 %v1072, ptr %slot164, align 8
  %v1073 = load i64, ptr %slot161, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %ld1075 = load i64, ptr %p1074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1075, ptr %slot165, align 8
  %v1076 = load i64, ptr %slot165, align 8
  %cmp1077 = icmp ne i64 %v1076, 0
  %cv1078 = zext i1 %cmp1077 to i32
  store i32 %cv1078, ptr %slot166, align 8
  %v1079 = load i32, ptr %slot166, align 8
  %cv1080 = zext i32 %v1079 to i64
  %cond1081 = icmp ne i64 %cv1080, 0
  br i1 %cond1081, label %bb_rcgnn230, label %bb_rcgdone230
bb_rcgnn230:
  %v1082 = load i64, ptr %slot165, align 8
  %op1083 = sub i64 %v1082, 16
  store i64 %op1083, ptr %slot167, align 8
  %v1084 = load i64, ptr %slot165, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %rgep1086 = getelementptr i8, ptr %p1085, i64 -16
  %ld1087 = load i64, ptr %rgep1086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1087, ptr %slot168, align 8
  %v1088 = load i64, ptr %slot168, align 8
  %op1089 = and i64 %v1088, 4611686018427387906
  store i64 %op1089, ptr %slot169, align 8
  %v1090 = load i64, ptr %slot169, align 8
  %cmp1091 = icmp ne i64 %v1090, 0
  %cv1092 = zext i1 %cmp1091 to i32
  store i32 %cv1092, ptr %slot170, align 8
  %v1093 = load i32, ptr %slot170, align 8
  %cv1094 = zext i32 %v1093 to i64
  %cond1095 = icmp ne i64 %cv1094, 0
  br i1 %cond1095, label %bb_rcgclear230, label %bb_rcgcounted230
bb_rcgcounted230:
  %v1096 = load i64, ptr %slot165, align 8
  %op1097 = sub i64 %v1096, 24
  store i64 %op1097, ptr %slot171, align 8
  %v1098 = load i64, ptr %slot165, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %rgep1100 = getelementptr i8, ptr %p1099, i64 -24
  %ld1101 = load i64, ptr %rgep1100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1101, ptr %slot172, align 8
  %v1102 = load i64, ptr %slot172, align 8
  %op1103 = sub i64 %v1102, 1
  store i64 %op1103, ptr %slot173, align 8
  %v1104 = load i64, ptr %slot173, align 8
  %cmp1105 = icmp eq i64 %v1104, 0
  %cv1106 = zext i1 %cmp1105 to i32
  store i32 %cv1106, ptr %slot174, align 8
  %v1107 = load i32, ptr %slot174, align 8
  %cv1108 = zext i32 %v1107 to i64
  %cond1109 = icmp ne i64 %cv1108, 0
  br i1 %cond1109, label %bb_rcglast230, label %bb_rcgdec230
bb_rcglast230:
  %v1110 = load i64, ptr %slot165, align 8
  %op1111 = sub i64 %v1110, 32
  store i64 %op1111, ptr %slot175, align 8
  %v1112 = load i64, ptr %slot165, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %rgep1114 = getelementptr i8, ptr %p1113, i64 -32
  %ld1115 = load i64, ptr %rgep1114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1115, ptr %slot176, align 8
  %v1116 = load i64, ptr %slot176, align 8
  %cmp1117 = icmp ne i64 %v1116, 0
  %cv1118 = zext i1 %cmp1117 to i32
  store i32 %cv1118, ptr %slot177, align 8
  %v1119 = load i32, ptr %slot177, align 8
  %cv1120 = zext i32 %v1119 to i64
  %cond1121 = icmp ne i64 %cv1120, 0
  br i1 %cond1121, label %bb_rcgdec230, label %bb_rcgslow230
bb_rcgslow230:
  %v1122 = load i64, ptr %slot164, align 8
  %v1123 = load i64, ptr %slot161, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1122, i64 %v1123) nomerge, !dbg !120
  br label %bb_rcgdone230
bb_rcgdec230:
  %v1124 = load i64, ptr %slot173, align 8
  %v1125 = load i64, ptr %slot165, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  %rgep1127 = getelementptr i8, ptr %p1126, i64 -24
  store i64 %v1124, ptr %rgep1127, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear230
bb_rcgclear230:
  %v1128 = load i64, ptr %slot161, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i64 0, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone230
bb_rcgdone230:
  br label %bb_rcslotdone214
bb_rcslotowner214:
  %v1130 = load i64, ptr %slot25, align 8
  store i64 %v1130, ptr %slot178, align 8
  %v1131 = load i64, ptr %slot161, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %ld1133 = load i64, ptr %p1132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1133, ptr %slot179, align 8
  %v1134 = load i64, ptr %slot179, align 8
  %cmp1135 = icmp ne i64 %v1134, 0
  %cv1136 = zext i1 %cmp1135 to i32
  store i32 %cv1136, ptr %slot180, align 8
  %v1137 = load i32, ptr %slot180, align 8
  %cv1138 = zext i32 %v1137 to i64
  %cond1139 = icmp ne i64 %cv1138, 0
  br i1 %cond1139, label %bb_rcgnn245, label %bb_rcgdone245
bb_rcgnn245:
  %v1140 = load i64, ptr %slot179, align 8
  %op1141 = sub i64 %v1140, 16
  store i64 %op1141, ptr %slot181, align 8
  %v1142 = load i64, ptr %slot179, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %rgep1144 = getelementptr i8, ptr %p1143, i64 -16
  %ld1145 = load i64, ptr %rgep1144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1145, ptr %slot182, align 8
  %v1146 = load i64, ptr %slot182, align 8
  %op1147 = and i64 %v1146, 4611686018427387906
  store i64 %op1147, ptr %slot183, align 8
  %v1148 = load i64, ptr %slot183, align 8
  %cmp1149 = icmp ne i64 %v1148, 0
  %cv1150 = zext i1 %cmp1149 to i32
  store i32 %cv1150, ptr %slot184, align 8
  %v1151 = load i32, ptr %slot184, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcgclear245, label %bb_rcgcounted245
bb_rcgcounted245:
  %v1154 = load i64, ptr %slot179, align 8
  %op1155 = sub i64 %v1154, 32
  store i64 %op1155, ptr %slot185, align 8
  %v1156 = load i64, ptr %slot179, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %rgep1158 = getelementptr i8, ptr %p1157, i64 -32
  %ld1159 = load i64, ptr %rgep1158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1159, ptr %slot186, align 8
  %v1160 = load i64, ptr %slot186, align 8
  %op1161 = sub i64 %v1160, 1
  store i64 %op1161, ptr %slot187, align 8
  %v1162 = load i64, ptr %slot187, align 8
  %cmp1163 = icmp eq i64 %v1162, 0
  %cv1164 = zext i1 %cmp1163 to i32
  store i32 %cv1164, ptr %slot188, align 8
  %v1165 = load i32, ptr %slot188, align 8
  %cv1166 = zext i32 %v1165 to i64
  %cond1167 = icmp ne i64 %cv1166, 0
  br i1 %cond1167, label %bb_rcglast245, label %bb_rcgdec245
bb_rcglast245:
  %v1168 = load i64, ptr %slot179, align 8
  %op1169 = sub i64 %v1168, 24
  store i64 %op1169, ptr %slot189, align 8
  %v1170 = load i64, ptr %slot179, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  %rgep1172 = getelementptr i8, ptr %p1171, i64 -24
  %ld1173 = load i64, ptr %rgep1172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1173, ptr %slot190, align 8
  %v1174 = load i64, ptr %slot190, align 8
  %cmp1175 = icmp ne i64 %v1174, 0
  %cv1176 = zext i1 %cmp1175 to i32
  store i32 %cv1176, ptr %slot191, align 8
  %v1177 = load i32, ptr %slot191, align 8
  %cv1178 = zext i32 %v1177 to i64
  %cond1179 = icmp ne i64 %cv1178, 0
  br i1 %cond1179, label %bb_rcgdec245, label %bb_rcgslow245
bb_rcgslow245:
  %v1180 = load i64, ptr %slot178, align 8
  %v1181 = load i64, ptr %slot161, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1180, i64 %v1181) nomerge, !dbg !120
  br label %bb_rcgdone245
bb_rcgdec245:
  %v1182 = load i64, ptr %slot187, align 8
  %v1183 = load i64, ptr %slot179, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %rgep1185 = getelementptr i8, ptr %p1184, i64 -32
  store i64 %v1182, ptr %rgep1185, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear245
bb_rcgclear245:
  %v1186 = load i64, ptr %slot161, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i64 0, ptr %p1187, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone245
bb_rcgdone245:
  br label %bb_rcslotdone214
bb_rcslotdone214:
  %v1188 = load i64, ptr %slot11, align 8
  store i64 %v1188, ptr %slot192, align 8
  %v1189 = load i64, ptr %slot15, align 8
  store i64 %v1189, ptr %slot193, align 8
  %v1190 = load i64, ptr %slot193, align 8
  %v1191 = load i64, ptr %slot192, align 8
  %p1192 = inttoptr i64 %v1190 to ptr
  %p1193 = inttoptr i64 %v1191 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1193, ptr %p1192, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot6, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i32 2, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot10, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i32, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1198, ptr %slot194, align 8
  %v1199 = load i32, ptr %slot194, align 8
  %v1200 = load i64, ptr %slot6, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i32 %v1199, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot9, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 0, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot5, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i32 1, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot192, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  %ld1208 = load i64, ptr %p1207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1208, ptr %slot195, align 8
  %v1209 = load i64, ptr %slot195, align 8
  %v1210 = load i64, ptr %slot18, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i64 %v1209, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  %p1212 = inttoptr i64 ptrtoint (ptr @myl_lit_d6b006dd0b769e0e5a8bb806c60978be91d208b60a28fe604b56cb4713aa8698 to i64) to ptr
  %ld1213 = load i64, ptr %p1212, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1213, ptr %slot196, align 8
  %v1214 = load i64, ptr %slot196, align 8
  %v1215 = load i64, ptr %slot19, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  store i64 %v1214, ptr %p1216, align 8, !alias.scope !3, !noalias !4
  %v1217 = load i64, ptr %slot19, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ld1219 = load i64, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1219, ptr %slot197, align 8
  %v1220 = load i64, ptr %slot197, align 8
  %v1221 = load i64, ptr %slot14, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i64 %v1220, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot14, align 8
  store i64 %v1223, ptr %slot198, align 8
  %v1224 = load i64, ptr %slot15, align 8
  store i64 %v1224, ptr %slot199, align 8
  %v1225 = load i64, ptr %slot198, align 8
  %v1226 = load i64, ptr %slot199, align 8
  %p1227 = inttoptr i64 %v1225 to ptr
  %p1228 = inttoptr i64 %v1226 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1228, ptr %p1227, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot10, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i32 2, ptr %p1230, align 4, !alias.scope !3, !noalias !4
  %v1231 = load i64, ptr %slot9, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  store i32 1, ptr %p1232, align 4, !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot12, align 8
  store i64 %v1233, ptr %slot200, align 8
  %v1234 = load i64, ptr %slot15, align 8
  store i64 %v1234, ptr %slot201, align 8
  %v1235 = load i64, ptr %slot201, align 8
  %v1236 = load i64, ptr %slot200, align 8
  %p1237 = inttoptr i64 %v1235 to ptr
  %p1238 = inttoptr i64 %v1236 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1238, ptr %p1237, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot8, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i32 2, ptr %p1240, align 4, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot10, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i32, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1243, ptr %slot202, align 8
  %v1244 = load i32, ptr %slot202, align 8
  %v1245 = load i64, ptr %slot8, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i32 %v1244, ptr %p1246, align 4, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot9, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  store i32 0, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  %v1249 = load i64, ptr %slot7, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  store i32 1, ptr %p1250, align 4, !alias.scope !3, !noalias !4
  %v1251 = load i64, ptr %slot200, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  %ld1253 = load i64, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1253, ptr %slot203, align 8
  %v1254 = load i64, ptr %slot203, align 8
  %v1255 = load i64, ptr %slot19, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i64 %v1254, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  %v1257 = load i64, ptr %slot18, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i64, ptr %p1258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1259, ptr %slot204, align 8
  %v1260 = load i64, ptr %slot19, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  %ld1262 = load i64, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1262, ptr %slot205, align 8
  %v1263 = load i64, ptr %slot18, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %ld1265 = load i64, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1265, ptr %slot206, align 8
  %v1266 = load i64, ptr %slot19, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i64, ptr %p1267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1268, ptr %slot207, align 8
  %v1269 = load i64, ptr %slot25, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  %v1271 = load i64, ptr %slot206, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  %v1273 = load i64, ptr %slot207, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  %call1275 = call ptr @myl_native_bytes_concat(ptr %p1270, ptr %p1272, ptr %p1274) nomerge, !dbg !122
  %calladdr1276 = ptrtoint ptr %call1275 to i64
  store i64 %calladdr1276, ptr %slot208, align 8
  %v1277 = load i64, ptr %slot208, align 8
  %cond1278 = icmp ne i64 %v1277, 0
  br i1 %cond1278, label %bb_success280, label %bb_failed280
bb_failed280:
  %v1279 = load i64, ptr %slot1, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1280) nomerge, !dbg !122
  unreachable
bb_success280:
  %v1281 = load i64, ptr %slot208, align 8
  %v1282 = load i64, ptr %slot18, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  store i64 %v1281, ptr %p1283, align 8, !alias.scope !3, !noalias !4
  %v1284 = load i64, ptr %slot18, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i64, ptr %p1285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1286, ptr %slot209, align 8
  %v1287 = load i64, ptr %slot209, align 8
  %v1288 = load i64, ptr %slot13, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  store i64 %v1287, ptr %p1289, align 8, !alias.scope !3, !noalias !4
  %v1290 = load i64, ptr %slot13, align 8
  store i64 %v1290, ptr %slot210, align 8
  %v1291 = load i64, ptr %slot15, align 8
  store i64 %v1291, ptr %slot211, align 8
  %v1292 = load i64, ptr %slot210, align 8
  %v1293 = load i64, ptr %slot211, align 8
  %p1294 = inttoptr i64 %v1292 to ptr
  %p1295 = inttoptr i64 %v1293 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1295, ptr %p1294, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1296 = load i64, ptr %slot10, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i32 2, ptr %p1297, align 4, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot9, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  store i32 1, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  %v1300 = load i64, ptr %slot5, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  %ld1302 = load i32, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1302, ptr %slot212, align 8
  %v1303 = load i32, ptr %slot212, align 8
  %cv1304 = zext i32 %v1303 to i64
  %cond1305 = icmp ne i64 %cv1304, 0
  br i1 %cond1305, label %bb_rcslotdrop288, label %bb_rcslotdone288
bb_rcslotdrop288:
  %v1306 = load i64, ptr %slot5, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  store i32 0, ptr %p1307, align 4, !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot11, align 8
  store i64 %v1308, ptr %slot213, align 8
  %v1309 = load i64, ptr %slot6, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot214, align 8
  %v1312 = load i32, ptr %slot214, align 8
  %op1313 = and i32 %v1312, 28
  store i32 %op1313, ptr %slot215, align 8
  %v1314 = load i32, ptr %slot215, align 8
  %cv1315 = zext i32 %v1314 to i64
  %cond1316 = icmp ne i64 %cv1315, 0
  br i1 %cond1316, label %bb_rcslotrole288, label %bb_rcslotowner288
bb_rcslotrole288:
  %v1317 = load i64, ptr %slot25, align 8
  store i64 %v1317, ptr %slot216, align 8
  %v1318 = load i64, ptr %slot213, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %ld1320 = load i64, ptr %p1319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1320, ptr %slot217, align 8
  %v1321 = load i64, ptr %slot217, align 8
  %cmp1322 = icmp ne i64 %v1321, 0
  %cv1323 = zext i1 %cmp1322 to i32
  store i32 %cv1323, ptr %slot218, align 8
  %v1324 = load i32, ptr %slot218, align 8
  %cv1325 = zext i32 %v1324 to i64
  %cond1326 = icmp ne i64 %cv1325, 0
  br i1 %cond1326, label %bb_rcgnn304, label %bb_rcgdone304
bb_rcgnn304:
  %v1327 = load i64, ptr %slot217, align 8
  %op1328 = sub i64 %v1327, 16
  store i64 %op1328, ptr %slot219, align 8
  %v1329 = load i64, ptr %slot217, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %rgep1331 = getelementptr i8, ptr %p1330, i64 -16
  %ld1332 = load i64, ptr %rgep1331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1332, ptr %slot220, align 8
  %v1333 = load i64, ptr %slot220, align 8
  %op1334 = and i64 %v1333, 4611686018427387906
  store i64 %op1334, ptr %slot221, align 8
  %v1335 = load i64, ptr %slot221, align 8
  %cmp1336 = icmp ne i64 %v1335, 0
  %cv1337 = zext i1 %cmp1336 to i32
  store i32 %cv1337, ptr %slot222, align 8
  %v1338 = load i32, ptr %slot222, align 8
  %cv1339 = zext i32 %v1338 to i64
  %cond1340 = icmp ne i64 %cv1339, 0
  br i1 %cond1340, label %bb_rcgclear304, label %bb_rcgcounted304
bb_rcgcounted304:
  %v1341 = load i64, ptr %slot217, align 8
  %op1342 = sub i64 %v1341, 24
  store i64 %op1342, ptr %slot223, align 8
  %v1343 = load i64, ptr %slot217, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  %rgep1345 = getelementptr i8, ptr %p1344, i64 -24
  %ld1346 = load i64, ptr %rgep1345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1346, ptr %slot224, align 8
  %v1347 = load i64, ptr %slot224, align 8
  %op1348 = sub i64 %v1347, 1
  store i64 %op1348, ptr %slot225, align 8
  %v1349 = load i64, ptr %slot225, align 8
  %cmp1350 = icmp eq i64 %v1349, 0
  %cv1351 = zext i1 %cmp1350 to i32
  store i32 %cv1351, ptr %slot226, align 8
  %v1352 = load i32, ptr %slot226, align 8
  %cv1353 = zext i32 %v1352 to i64
  %cond1354 = icmp ne i64 %cv1353, 0
  br i1 %cond1354, label %bb_rcglast304, label %bb_rcgdec304
bb_rcglast304:
  %v1355 = load i64, ptr %slot217, align 8
  %op1356 = sub i64 %v1355, 32
  store i64 %op1356, ptr %slot227, align 8
  %v1357 = load i64, ptr %slot217, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  %rgep1359 = getelementptr i8, ptr %p1358, i64 -32
  %ld1360 = load i64, ptr %rgep1359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1360, ptr %slot228, align 8
  %v1361 = load i64, ptr %slot228, align 8
  %cmp1362 = icmp ne i64 %v1361, 0
  %cv1363 = zext i1 %cmp1362 to i32
  store i32 %cv1363, ptr %slot229, align 8
  %v1364 = load i32, ptr %slot229, align 8
  %cv1365 = zext i32 %v1364 to i64
  %cond1366 = icmp ne i64 %cv1365, 0
  br i1 %cond1366, label %bb_rcgdec304, label %bb_rcgslow304
bb_rcgslow304:
  %v1367 = load i64, ptr %slot216, align 8
  %v1368 = load i64, ptr %slot213, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1367, i64 %v1368) nomerge, !dbg !122
  br label %bb_rcgdone304
bb_rcgdec304:
  %v1369 = load i64, ptr %slot225, align 8
  %v1370 = load i64, ptr %slot217, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %rgep1372 = getelementptr i8, ptr %p1371, i64 -24
  store i64 %v1369, ptr %rgep1372, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear304
bb_rcgclear304:
  %v1373 = load i64, ptr %slot213, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i64 0, ptr %p1374, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone304
bb_rcgdone304:
  br label %bb_rcslotdone288
bb_rcslotowner288:
  %v1375 = load i64, ptr %slot25, align 8
  store i64 %v1375, ptr %slot230, align 8
  %v1376 = load i64, ptr %slot213, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  %ld1378 = load i64, ptr %p1377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1378, ptr %slot231, align 8
  %v1379 = load i64, ptr %slot231, align 8
  %cmp1380 = icmp ne i64 %v1379, 0
  %cv1381 = zext i1 %cmp1380 to i32
  store i32 %cv1381, ptr %slot232, align 8
  %v1382 = load i32, ptr %slot232, align 8
  %cv1383 = zext i32 %v1382 to i64
  %cond1384 = icmp ne i64 %cv1383, 0
  br i1 %cond1384, label %bb_rcgnn319, label %bb_rcgdone319
bb_rcgnn319:
  %v1385 = load i64, ptr %slot231, align 8
  %op1386 = sub i64 %v1385, 16
  store i64 %op1386, ptr %slot233, align 8
  %v1387 = load i64, ptr %slot231, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  %rgep1389 = getelementptr i8, ptr %p1388, i64 -16
  %ld1390 = load i64, ptr %rgep1389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1390, ptr %slot234, align 8
  %v1391 = load i64, ptr %slot234, align 8
  %op1392 = and i64 %v1391, 4611686018427387906
  store i64 %op1392, ptr %slot235, align 8
  %v1393 = load i64, ptr %slot235, align 8
  %cmp1394 = icmp ne i64 %v1393, 0
  %cv1395 = zext i1 %cmp1394 to i32
  store i32 %cv1395, ptr %slot236, align 8
  %v1396 = load i32, ptr %slot236, align 8
  %cv1397 = zext i32 %v1396 to i64
  %cond1398 = icmp ne i64 %cv1397, 0
  br i1 %cond1398, label %bb_rcgclear319, label %bb_rcgcounted319
bb_rcgcounted319:
  %v1399 = load i64, ptr %slot231, align 8
  %op1400 = sub i64 %v1399, 32
  store i64 %op1400, ptr %slot237, align 8
  %v1401 = load i64, ptr %slot231, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %rgep1403 = getelementptr i8, ptr %p1402, i64 -32
  %ld1404 = load i64, ptr %rgep1403, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1404, ptr %slot238, align 8
  %v1405 = load i64, ptr %slot238, align 8
  %op1406 = sub i64 %v1405, 1
  store i64 %op1406, ptr %slot239, align 8
  %v1407 = load i64, ptr %slot239, align 8
  %cmp1408 = icmp eq i64 %v1407, 0
  %cv1409 = zext i1 %cmp1408 to i32
  store i32 %cv1409, ptr %slot240, align 8
  %v1410 = load i32, ptr %slot240, align 8
  %cv1411 = zext i32 %v1410 to i64
  %cond1412 = icmp ne i64 %cv1411, 0
  br i1 %cond1412, label %bb_rcglast319, label %bb_rcgdec319
bb_rcglast319:
  %v1413 = load i64, ptr %slot231, align 8
  %op1414 = sub i64 %v1413, 24
  store i64 %op1414, ptr %slot241, align 8
  %v1415 = load i64, ptr %slot231, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %rgep1417 = getelementptr i8, ptr %p1416, i64 -24
  %ld1418 = load i64, ptr %rgep1417, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1418, ptr %slot242, align 8
  %v1419 = load i64, ptr %slot242, align 8
  %cmp1420 = icmp ne i64 %v1419, 0
  %cv1421 = zext i1 %cmp1420 to i32
  store i32 %cv1421, ptr %slot243, align 8
  %v1422 = load i32, ptr %slot243, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcgdec319, label %bb_rcgslow319
bb_rcgslow319:
  %v1425 = load i64, ptr %slot230, align 8
  %v1426 = load i64, ptr %slot213, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1425, i64 %v1426) nomerge, !dbg !122
  br label %bb_rcgdone319
bb_rcgdec319:
  %v1427 = load i64, ptr %slot239, align 8
  %v1428 = load i64, ptr %slot231, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %rgep1430 = getelementptr i8, ptr %p1429, i64 -32
  store i64 %v1427, ptr %rgep1430, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear319
bb_rcgclear319:
  %v1431 = load i64, ptr %slot213, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  store i64 0, ptr %p1432, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone319
bb_rcgdone319:
  br label %bb_rcslotdone288
bb_rcslotdone288:
  %v1433 = load i64, ptr %slot7, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  %ld1435 = load i32, ptr %p1434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1435, ptr %slot244, align 8
  %v1436 = load i32, ptr %slot244, align 8
  %cv1437 = zext i32 %v1436 to i64
  %cond1438 = icmp ne i64 %cv1437, 0
  br i1 %cond1438, label %bb_rcslotdrop325, label %bb_rcslotdone325
bb_rcslotdrop325:
  %v1439 = load i64, ptr %slot7, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  store i32 0, ptr %p1440, align 4, !alias.scope !3, !noalias !4
  %v1441 = load i64, ptr %slot12, align 8
  store i64 %v1441, ptr %slot245, align 8
  %v1442 = load i64, ptr %slot8, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i32, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1444, ptr %slot246, align 8
  %v1445 = load i32, ptr %slot246, align 8
  %op1446 = and i32 %v1445, 28
  store i32 %op1446, ptr %slot247, align 8
  %v1447 = load i32, ptr %slot247, align 8
  %cv1448 = zext i32 %v1447 to i64
  %cond1449 = icmp ne i64 %cv1448, 0
  br i1 %cond1449, label %bb_rcslotrole325, label %bb_rcslotowner325
bb_rcslotrole325:
  %v1450 = load i64, ptr %slot25, align 8
  store i64 %v1450, ptr %slot248, align 8
  %v1451 = load i64, ptr %slot245, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  %ld1453 = load i64, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1453, ptr %slot249, align 8
  %v1454 = load i64, ptr %slot249, align 8
  %cmp1455 = icmp ne i64 %v1454, 0
  %cv1456 = zext i1 %cmp1455 to i32
  store i32 %cv1456, ptr %slot250, align 8
  %v1457 = load i32, ptr %slot250, align 8
  %cv1458 = zext i32 %v1457 to i64
  %cond1459 = icmp ne i64 %cv1458, 0
  br i1 %cond1459, label %bb_rcgnn341, label %bb_rcgdone341
bb_rcgnn341:
  %v1460 = load i64, ptr %slot249, align 8
  %op1461 = sub i64 %v1460, 16
  store i64 %op1461, ptr %slot251, align 8
  %v1462 = load i64, ptr %slot249, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %rgep1464 = getelementptr i8, ptr %p1463, i64 -16
  %ld1465 = load i64, ptr %rgep1464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1465, ptr %slot252, align 8
  %v1466 = load i64, ptr %slot252, align 8
  %op1467 = and i64 %v1466, 4611686018427387906
  store i64 %op1467, ptr %slot253, align 8
  %v1468 = load i64, ptr %slot253, align 8
  %cmp1469 = icmp ne i64 %v1468, 0
  %cv1470 = zext i1 %cmp1469 to i32
  store i32 %cv1470, ptr %slot254, align 8
  %v1471 = load i32, ptr %slot254, align 8
  %cv1472 = zext i32 %v1471 to i64
  %cond1473 = icmp ne i64 %cv1472, 0
  br i1 %cond1473, label %bb_rcgclear341, label %bb_rcgcounted341
bb_rcgcounted341:
  %v1474 = load i64, ptr %slot249, align 8
  %op1475 = sub i64 %v1474, 24
  store i64 %op1475, ptr %slot255, align 8
  %v1476 = load i64, ptr %slot249, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %rgep1478 = getelementptr i8, ptr %p1477, i64 -24
  %ld1479 = load i64, ptr %rgep1478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1479, ptr %slot256, align 8
  %v1480 = load i64, ptr %slot256, align 8
  %op1481 = sub i64 %v1480, 1
  store i64 %op1481, ptr %slot257, align 8
  %v1482 = load i64, ptr %slot257, align 8
  %cmp1483 = icmp eq i64 %v1482, 0
  %cv1484 = zext i1 %cmp1483 to i32
  store i32 %cv1484, ptr %slot258, align 8
  %v1485 = load i32, ptr %slot258, align 8
  %cv1486 = zext i32 %v1485 to i64
  %cond1487 = icmp ne i64 %cv1486, 0
  br i1 %cond1487, label %bb_rcglast341, label %bb_rcgdec341
bb_rcglast341:
  %v1488 = load i64, ptr %slot249, align 8
  %op1489 = sub i64 %v1488, 32
  store i64 %op1489, ptr %slot259, align 8
  %v1490 = load i64, ptr %slot249, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  %rgep1492 = getelementptr i8, ptr %p1491, i64 -32
  %ld1493 = load i64, ptr %rgep1492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1493, ptr %slot260, align 8
  %v1494 = load i64, ptr %slot260, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot261, align 8
  %v1497 = load i32, ptr %slot261, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcgdec341, label %bb_rcgslow341
bb_rcgslow341:
  %v1500 = load i64, ptr %slot248, align 8
  %v1501 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1500, i64 %v1501) nomerge, !dbg !122
  br label %bb_rcgdone341
bb_rcgdec341:
  %v1502 = load i64, ptr %slot257, align 8
  %v1503 = load i64, ptr %slot249, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  %rgep1505 = getelementptr i8, ptr %p1504, i64 -24
  store i64 %v1502, ptr %rgep1505, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear341
bb_rcgclear341:
  %v1506 = load i64, ptr %slot245, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  store i64 0, ptr %p1507, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone341
bb_rcgdone341:
  br label %bb_rcslotdone325
bb_rcslotowner325:
  %v1508 = load i64, ptr %slot25, align 8
  store i64 %v1508, ptr %slot262, align 8
  %v1509 = load i64, ptr %slot245, align 8
  %p1510 = inttoptr i64 %v1509 to ptr
  %ld1511 = load i64, ptr %p1510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1511, ptr %slot263, align 8
  %v1512 = load i64, ptr %slot263, align 8
  %cmp1513 = icmp ne i64 %v1512, 0
  %cv1514 = zext i1 %cmp1513 to i32
  store i32 %cv1514, ptr %slot264, align 8
  %v1515 = load i32, ptr %slot264, align 8
  %cv1516 = zext i32 %v1515 to i64
  %cond1517 = icmp ne i64 %cv1516, 0
  br i1 %cond1517, label %bb_rcgnn356, label %bb_rcgdone356
bb_rcgnn356:
  %v1518 = load i64, ptr %slot263, align 8
  %op1519 = sub i64 %v1518, 16
  store i64 %op1519, ptr %slot265, align 8
  %v1520 = load i64, ptr %slot263, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %rgep1522 = getelementptr i8, ptr %p1521, i64 -16
  %ld1523 = load i64, ptr %rgep1522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1523, ptr %slot266, align 8
  %v1524 = load i64, ptr %slot266, align 8
  %op1525 = and i64 %v1524, 4611686018427387906
  store i64 %op1525, ptr %slot267, align 8
  %v1526 = load i64, ptr %slot267, align 8
  %cmp1527 = icmp ne i64 %v1526, 0
  %cv1528 = zext i1 %cmp1527 to i32
  store i32 %cv1528, ptr %slot268, align 8
  %v1529 = load i32, ptr %slot268, align 8
  %cv1530 = zext i32 %v1529 to i64
  %cond1531 = icmp ne i64 %cv1530, 0
  br i1 %cond1531, label %bb_rcgclear356, label %bb_rcgcounted356
bb_rcgcounted356:
  %v1532 = load i64, ptr %slot263, align 8
  %op1533 = sub i64 %v1532, 32
  store i64 %op1533, ptr %slot269, align 8
  %v1534 = load i64, ptr %slot263, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  %rgep1536 = getelementptr i8, ptr %p1535, i64 -32
  %ld1537 = load i64, ptr %rgep1536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1537, ptr %slot270, align 8
  %v1538 = load i64, ptr %slot270, align 8
  %op1539 = sub i64 %v1538, 1
  store i64 %op1539, ptr %slot271, align 8
  %v1540 = load i64, ptr %slot271, align 8
  %cmp1541 = icmp eq i64 %v1540, 0
  %cv1542 = zext i1 %cmp1541 to i32
  store i32 %cv1542, ptr %slot272, align 8
  %v1543 = load i32, ptr %slot272, align 8
  %cv1544 = zext i32 %v1543 to i64
  %cond1545 = icmp ne i64 %cv1544, 0
  br i1 %cond1545, label %bb_rcglast356, label %bb_rcgdec356
bb_rcglast356:
  %v1546 = load i64, ptr %slot263, align 8
  %op1547 = sub i64 %v1546, 24
  store i64 %op1547, ptr %slot273, align 8
  %v1548 = load i64, ptr %slot263, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %rgep1550 = getelementptr i8, ptr %p1549, i64 -24
  %ld1551 = load i64, ptr %rgep1550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1551, ptr %slot274, align 8
  %v1552 = load i64, ptr %slot274, align 8
  %cmp1553 = icmp ne i64 %v1552, 0
  %cv1554 = zext i1 %cmp1553 to i32
  store i32 %cv1554, ptr %slot275, align 8
  %v1555 = load i32, ptr %slot275, align 8
  %cv1556 = zext i32 %v1555 to i64
  %cond1557 = icmp ne i64 %cv1556, 0
  br i1 %cond1557, label %bb_rcgdec356, label %bb_rcgslow356
bb_rcgslow356:
  %v1558 = load i64, ptr %slot262, align 8
  %v1559 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1558, i64 %v1559) nomerge, !dbg !122
  br label %bb_rcgdone356
bb_rcgdec356:
  %v1560 = load i64, ptr %slot271, align 8
  %v1561 = load i64, ptr %slot263, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %rgep1563 = getelementptr i8, ptr %p1562, i64 -32
  store i64 %v1560, ptr %rgep1563, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear356
bb_rcgclear356:
  %v1564 = load i64, ptr %slot245, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 0, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone356
bb_rcgdone356:
  br label %bb_rcslotdone325
bb_rcslotdone325:
  %v1566 = load i64, ptr %slot11, align 8
  store i64 %v1566, ptr %slot276, align 8
  %v1567 = load i64, ptr %slot15, align 8
  store i64 %v1567, ptr %slot277, align 8
  %v1568 = load i64, ptr %slot277, align 8
  %v1569 = load i64, ptr %slot276, align 8
  %p1570 = inttoptr i64 %v1568 to ptr
  %p1571 = inttoptr i64 %v1569 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1571, ptr %p1570, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1572 = load i64, ptr %slot6, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i32 2, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot10, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %ld1576 = load i32, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1576, ptr %slot278, align 8
  %v1577 = load i32, ptr %slot278, align 8
  %v1578 = load i64, ptr %slot6, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i32 %v1577, ptr %p1579, align 4, !alias.scope !3, !noalias !4
  %v1580 = load i64, ptr %slot9, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  store i32 0, ptr %p1581, align 4, !alias.scope !3, !noalias !4
  %v1582 = load i64, ptr %slot5, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i32 1, ptr %p1583, align 4, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot276, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %ld1586 = load i64, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1586, ptr %slot279, align 8
  %v1587 = load i64, ptr %slot279, align 8
  %v1588 = load i64, ptr %slot18, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i64 %v1587, ptr %p1589, align 8, !alias.scope !3, !noalias !4
  %v1590 = load i64, ptr %slot18, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  %ld1592 = load i64, ptr %p1591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1592, ptr %slot280, align 8
  %v1593 = load i64, ptr %slot18, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i64, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1595, ptr %slot281, align 8
  %v1596 = load i64, ptr %slot281, align 8
  %v1597 = load i64, ptr %slot13, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i64 %v1596, ptr %p1598, align 8, !alias.scope !3, !noalias !4
  %v1599 = load i64, ptr %slot13, align 8
  store i64 %v1599, ptr %slot282, align 8
  %v1600 = load i64, ptr %slot5, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %ld1602 = load i32, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1602, ptr %slot283, align 8
  %v1603 = load i64, ptr %slot6, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i32, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1605, ptr %slot284, align 8
  %v1606 = load i32, ptr %slot284, align 8
  %op1607 = and i32 %v1606, 24
  store i32 %op1607, ptr %slot284, align 8
  %v1608 = load i32, ptr %slot284, align 8
  %cmp1609 = icmp eq i32 %v1608, 0
  %cv1610 = zext i1 %cmp1609 to i32
  store i32 %cv1610, ptr %slot285, align 8
  %v1611 = load i32, ptr %slot283, align 8
  %v1612 = load i32, ptr %slot285, align 8
  %op1613 = and i32 %v1611, %v1612
  store i32 %op1613, ptr %slot286, align 8
  %v1614 = load i32, ptr %slot286, align 8
  %cv1615 = zext i32 %v1614 to i64
  %cond1616 = icmp ne i64 %cv1615, 0
  br i1 %cond1616, label %bb_rctake372, label %bb_rccopy372
bb_rctake372:
  %v1617 = load i64, ptr %slot15, align 8
  store i64 %v1617, ptr %slot287, align 8
  %v1618 = load i64, ptr %slot26, align 8
  store i64 %v1618, ptr %slot288, align 8
  %v1619 = load i64, ptr %slot282, align 8
  %v1620 = load i64, ptr %slot287, align 8
  %op1621 = sub i64 %v1619, %v1620
  store i64 %op1621, ptr %slot289, align 8
  %v1622 = load i64, ptr %slot287, align 8
  %v1623 = load i64, ptr %slot282, align 8
  %op1624 = sub i64 %v1622, %v1623
  store i64 %op1624, ptr %slot290, align 8
  %v1625 = load i64, ptr %slot289, align 8
  %cmp1626 = icmp ult i64 %v1625, 8
  %cv1627 = zext i1 %cmp1626 to i32
  store i32 %cv1627, ptr %slot291, align 8
  %v1628 = load i64, ptr %slot290, align 8
  %cmp1629 = icmp ult i64 %v1628, 8
  %cv1630 = zext i1 %cmp1629 to i32
  store i32 %cv1630, ptr %slot292, align 8
  %v1631 = load i32, ptr %slot291, align 8
  %v1632 = load i32, ptr %slot292, align 8
  %op1633 = or i32 %v1631, %v1632
  store i32 %op1633, ptr %slot293, align 8
  %v1634 = load i32, ptr %slot293, align 8
  %cv1635 = zext i32 %v1634 to i64
  %cond1636 = icmp ne i64 %cv1635, 0
  br i1 %cond1636, label %bb_rcmoveslow381, label %bb_rcmovecheck381
bb_rcmovecheck381:
  %v1637 = load i64, ptr %slot282, align 8
  %p1639 = inttoptr i64 %v1637 to ptr
  %gep1640 = getelementptr i8, ptr %p1639, i64 0
  %op1638 = ptrtoint ptr %gep1640 to i64
  store i64 %op1638, ptr %slot294, align 8
  %v1641 = load i64, ptr %slot294, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i64, ptr %p1642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1643, ptr %slot295, align 8
  %v1644 = load i64, ptr %slot295, align 8
  %cmp1645 = icmp ne i64 %v1644, 0
  %cv1646 = zext i1 %cmp1645 to i32
  store i32 %cv1646, ptr %slot296, align 8
  %v1647 = load i32, ptr %slot296, align 8
  %cv1648 = zext i32 %v1647 to i64
  %cond1649 = icmp ne i64 %cv1648, 0
  br i1 %cond1649, label %bb_rcmoveheader389, label %bb_rcmovenext389
bb_rcmoveheader389:
  %v1650 = load i64, ptr %slot295, align 8
  %op1651 = sub i64 %v1650, 16
  store i64 %op1651, ptr %slot297, align 8
  %v1652 = load i64, ptr %slot295, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  %rgep1654 = getelementptr i8, ptr %p1653, i64 -16
  %ld1655 = load i64, ptr %rgep1654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1655, ptr %slot298, align 8
  %v1656 = load i64, ptr %slot298, align 8
  %op1657 = and i64 %v1656, 5764607523034234881
  store i64 %op1657, ptr %slot299, align 8
  %v1658 = load i64, ptr %slot299, align 8
  %cmp1659 = icmp ne i64 %v1658, 0
  %cv1660 = zext i1 %cmp1659 to i32
  store i32 %cv1660, ptr %slot300, align 8
  %v1661 = load i32, ptr %slot300, align 8
  %cv1662 = zext i32 %v1661 to i64
  %cond1663 = icmp ne i64 %cv1662, 0
  br i1 %cond1663, label %bb_rcmoveslow381, label %bb_rcmovenext389
bb_rcmovenext389:
  %v1664 = load i64, ptr %slot282, align 8
  %v1665 = load i64, ptr %slot287, align 8
  %p1666 = inttoptr i64 %v1664 to ptr
  %p1667 = inttoptr i64 %v1665 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1667, ptr %p1666, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot282, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  store i64 0, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved381
bb_rcmoveslow381:
  %v1670 = load i64, ptr %slot25, align 8
  %v1671 = load i64, ptr %slot287, align 8
  %v1672 = load i64, ptr %slot282, align 8
  %v1673 = load i64, ptr %slot288, align 8
  %cv1674 = trunc i64 %v1673 to i32
  %call1675 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1670, i64 %v1671, i64 %v1672, i32 %cv1674) nomerge, !dbg !124
  store i32 %call1675, ptr %slot301, align 8
  %v1676 = load i32, ptr %slot301, align 8
  %cv1677 = zext i32 %v1676 to i64
  %cond1678 = icmp ne i64 %cv1677, 0
  br i1 %cond1678, label %bb_rcsuccess396, label %bb_rcfailure396
bb_rcfailure396:
  %v1679 = load i64, ptr %slot25, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %call1681 = call i32 @myl_rc_take_failure(ptr %p1680) nomerge, !dbg !124
  store i32 %call1681, ptr %slot302, align 8
  %v1682 = load i64, ptr %slot1, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %v1684 = load i32, ptr %slot302, align 8
  %call1685 = call i32 @myl_qbe_rc_status(ptr %p1683, i32 %v1684) nomerge, !dbg !124
  store i32 %call1685, ptr %slot303, align 8
  br label %bb_failure
bb_rcsuccess396:
  br label %bb_rcmoved381
bb_rcmoved381:
  %v1686 = load i64, ptr %slot5, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i32 0, ptr %p1687, align 4, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot10, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  store i32 2, ptr %p1689, align 4, !alias.scope !3, !noalias !4
  %v1690 = load i64, ptr %slot9, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i32 1, ptr %p1691, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared372
bb_rccopy372:
  %v1692 = load i64, ptr %slot15, align 8
  store i64 %v1692, ptr %slot304, align 8
  %v1693 = load i64, ptr %slot26, align 8
  store i64 %v1693, ptr %slot305, align 8
  %v1694 = load i64, ptr %slot282, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i64, ptr %p1695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1696, ptr %slot306, align 8
  %v1697 = load i64, ptr %slot306, align 8
  %cmp1698 = icmp ne i64 %v1697, 0
  %cv1699 = zext i1 %cmp1698 to i32
  store i32 %cv1699, ptr %slot307, align 8
  %v1700 = load i32, ptr %slot307, align 8
  %cv1701 = zext i32 %v1700 to i64
  %cond1702 = icmp ne i64 %cv1701, 0
  br i1 %cond1702, label %bb_rcgnn405, label %bb_rcgplain405
bb_rcgnn405:
  %v1703 = load i64, ptr %slot306, align 8
  %op1704 = sub i64 %v1703, 16
  store i64 %op1704, ptr %slot308, align 8
  %v1705 = load i64, ptr %slot306, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %rgep1707 = getelementptr i8, ptr %p1706, i64 -16
  %ld1708 = load i64, ptr %rgep1707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1708, ptr %slot309, align 8
  %v1709 = load i64, ptr %slot309, align 8
  %op1710 = and i64 %v1709, 4611686018427387906
  store i64 %op1710, ptr %slot310, align 8
  %v1711 = load i64, ptr %slot310, align 8
  %cmp1712 = icmp ne i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot311, align 8
  %v1714 = load i32, ptr %slot311, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcgspecial405, label %bb_rcginc405
bb_rcginc405:
  %v1717 = load i64, ptr %slot306, align 8
  %op1718 = sub i64 %v1717, 32
  store i64 %op1718, ptr %slot312, align 8
  %v1719 = load i64, ptr %slot306, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %rgep1721 = getelementptr i8, ptr %p1720, i64 -32
  %ld1722 = load i64, ptr %rgep1721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1722, ptr %slot313, align 8
  %v1723 = load i64, ptr %slot313, align 8
  %op1724 = add i64 %v1723, 1
  store i64 %op1724, ptr %slot314, align 8
  %v1725 = load i64, ptr %slot314, align 8
  %cmp1726 = icmp eq i64 %v1725, 0
  %cv1727 = zext i1 %cmp1726 to i32
  store i32 %cv1727, ptr %slot315, align 8
  %v1728 = load i32, ptr %slot315, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcglimit405, label %bb_rcgcapacity405
bb_rcglimit405:
  %v1731 = load i64, ptr %slot1, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %call1733 = call i32 @myl_qbe_rc_status(ptr %p1732, i32 2) nomerge, !dbg !124
  store i32 %call1733, ptr %slot316, align 8
  br label %bb_failure
bb_rcgcapacity405:
  %v1734 = load i64, ptr %slot314, align 8
  %v1735 = load i64, ptr %slot306, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  %rgep1737 = getelementptr i8, ptr %p1736, i64 -32
  store i64 %v1734, ptr %rgep1737, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain405
bb_rcgspecial405:
  %v1738 = load i64, ptr %slot309, align 8
  %op1739 = and i64 %v1738, 4611686018427387904
  store i64 %op1739, ptr %slot317, align 8
  %v1740 = load i64, ptr %slot317, align 8
  %cmp1741 = icmp ne i64 %v1740, 0
  %cv1742 = zext i1 %cmp1741 to i32
  store i32 %cv1742, ptr %slot318, align 8
  %v1743 = load i32, ptr %slot318, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcgslow405, label %bb_rcgplain405
bb_rcgslow405:
  %v1746 = load i64, ptr %slot25, align 8
  %v1747 = load i64, ptr %slot304, align 8
  %v1748 = load i64, ptr %slot282, align 8
  %v1749 = load i64, ptr %slot305, align 8
  %cv1750 = trunc i64 %v1749 to i32
  %call1751 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v1746, i64 %v1747, i64 %v1748, i32 %cv1750) nomerge, !dbg !124
  store i32 %call1751, ptr %slot319, align 8
  %v1752 = load i32, ptr %slot319, align 8
  %cv1753 = zext i32 %v1752 to i64
  %cond1754 = icmp ne i64 %cv1753, 0
  br i1 %cond1754, label %bb_rcsuccess419, label %bb_rcfailure419
bb_rcfailure419:
  %v1755 = load i64, ptr %slot25, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %call1757 = call i32 @myl_rc_take_failure(ptr %p1756) nomerge, !dbg !124
  store i32 %call1757, ptr %slot320, align 8
  %v1758 = load i64, ptr %slot1, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %v1760 = load i32, ptr %slot320, align 8
  %call1761 = call i32 @myl_qbe_rc_status(ptr %p1759, i32 %v1760) nomerge, !dbg !124
  store i32 %call1761, ptr %slot321, align 8
  br label %bb_failure
bb_rcsuccess419:
  br label %bb_rcgdone405
bb_rcgplain405:
  %v1762 = load i64, ptr %slot306, align 8
  %v1763 = load i64, ptr %slot304, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  store i64 %v1762, ptr %p1764, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone405
bb_rcgdone405:
  %v1765 = load i64, ptr %slot10, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  store i32 2, ptr %p1766, align 4, !alias.scope !3, !noalias !4
  %v1767 = load i64, ptr %slot9, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  store i32 1, ptr %p1768, align 4, !alias.scope !3, !noalias !4
  %v1769 = load i64, ptr %slot5, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %ld1771 = load i32, ptr %p1770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1771, ptr %slot322, align 8
  %v1772 = load i32, ptr %slot322, align 8
  %cv1773 = zext i32 %v1772 to i64
  %cond1774 = icmp ne i64 %cv1773, 0
  br i1 %cond1774, label %bb_rcslotdrop426, label %bb_rcslotdone426
bb_rcslotdrop426:
  %v1775 = load i64, ptr %slot5, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  store i32 0, ptr %p1776, align 4, !alias.scope !3, !noalias !4
  %v1777 = load i64, ptr %slot11, align 8
  store i64 %v1777, ptr %slot323, align 8
  %v1778 = load i64, ptr %slot6, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %ld1780 = load i32, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1780, ptr %slot324, align 8
  %v1781 = load i32, ptr %slot324, align 8
  %op1782 = and i32 %v1781, 28
  store i32 %op1782, ptr %slot325, align 8
  %v1783 = load i32, ptr %slot325, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rcslotrole426, label %bb_rcslotowner426
bb_rcslotrole426:
  %v1786 = load i64, ptr %slot25, align 8
  store i64 %v1786, ptr %slot326, align 8
  %v1787 = load i64, ptr %slot323, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i64, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1789, ptr %slot327, align 8
  %v1790 = load i64, ptr %slot327, align 8
  %cmp1791 = icmp ne i64 %v1790, 0
  %cv1792 = zext i1 %cmp1791 to i32
  store i32 %cv1792, ptr %slot328, align 8
  %v1793 = load i32, ptr %slot328, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcgnn442, label %bb_rcgdone442
bb_rcgnn442:
  %v1796 = load i64, ptr %slot327, align 8
  %op1797 = sub i64 %v1796, 16
  store i64 %op1797, ptr %slot329, align 8
  %v1798 = load i64, ptr %slot327, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  %rgep1800 = getelementptr i8, ptr %p1799, i64 -16
  %ld1801 = load i64, ptr %rgep1800, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1801, ptr %slot330, align 8
  %v1802 = load i64, ptr %slot330, align 8
  %op1803 = and i64 %v1802, 4611686018427387906
  store i64 %op1803, ptr %slot331, align 8
  %v1804 = load i64, ptr %slot331, align 8
  %cmp1805 = icmp ne i64 %v1804, 0
  %cv1806 = zext i1 %cmp1805 to i32
  store i32 %cv1806, ptr %slot332, align 8
  %v1807 = load i32, ptr %slot332, align 8
  %cv1808 = zext i32 %v1807 to i64
  %cond1809 = icmp ne i64 %cv1808, 0
  br i1 %cond1809, label %bb_rcgclear442, label %bb_rcgcounted442
bb_rcgcounted442:
  %v1810 = load i64, ptr %slot327, align 8
  %op1811 = sub i64 %v1810, 24
  store i64 %op1811, ptr %slot333, align 8
  %v1812 = load i64, ptr %slot327, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %rgep1814 = getelementptr i8, ptr %p1813, i64 -24
  %ld1815 = load i64, ptr %rgep1814, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1815, ptr %slot334, align 8
  %v1816 = load i64, ptr %slot334, align 8
  %op1817 = sub i64 %v1816, 1
  store i64 %op1817, ptr %slot335, align 8
  %v1818 = load i64, ptr %slot335, align 8
  %cmp1819 = icmp eq i64 %v1818, 0
  %cv1820 = zext i1 %cmp1819 to i32
  store i32 %cv1820, ptr %slot336, align 8
  %v1821 = load i32, ptr %slot336, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcglast442, label %bb_rcgdec442
bb_rcglast442:
  %v1824 = load i64, ptr %slot327, align 8
  %op1825 = sub i64 %v1824, 32
  store i64 %op1825, ptr %slot337, align 8
  %v1826 = load i64, ptr %slot327, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  %rgep1828 = getelementptr i8, ptr %p1827, i64 -32
  %ld1829 = load i64, ptr %rgep1828, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1829, ptr %slot338, align 8
  %v1830 = load i64, ptr %slot338, align 8
  %cmp1831 = icmp ne i64 %v1830, 0
  %cv1832 = zext i1 %cmp1831 to i32
  store i32 %cv1832, ptr %slot339, align 8
  %v1833 = load i32, ptr %slot339, align 8
  %cv1834 = zext i32 %v1833 to i64
  %cond1835 = icmp ne i64 %cv1834, 0
  br i1 %cond1835, label %bb_rcgdec442, label %bb_rcgslow442
bb_rcgslow442:
  %v1836 = load i64, ptr %slot326, align 8
  %v1837 = load i64, ptr %slot323, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1836, i64 %v1837) nomerge, !dbg !124
  br label %bb_rcgdone442
bb_rcgdec442:
  %v1838 = load i64, ptr %slot335, align 8
  %v1839 = load i64, ptr %slot327, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  %rgep1841 = getelementptr i8, ptr %p1840, i64 -24
  store i64 %v1838, ptr %rgep1841, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear442
bb_rcgclear442:
  %v1842 = load i64, ptr %slot323, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  store i64 0, ptr %p1843, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone442
bb_rcgdone442:
  br label %bb_rcslotdone426
bb_rcslotowner426:
  %v1844 = load i64, ptr %slot25, align 8
  store i64 %v1844, ptr %slot340, align 8
  %v1845 = load i64, ptr %slot323, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i64, ptr %p1846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1847, ptr %slot341, align 8
  %v1848 = load i64, ptr %slot341, align 8
  %cmp1849 = icmp ne i64 %v1848, 0
  %cv1850 = zext i1 %cmp1849 to i32
  store i32 %cv1850, ptr %slot342, align 8
  %v1851 = load i32, ptr %slot342, align 8
  %cv1852 = zext i32 %v1851 to i64
  %cond1853 = icmp ne i64 %cv1852, 0
  br i1 %cond1853, label %bb_rcgnn457, label %bb_rcgdone457
bb_rcgnn457:
  %v1854 = load i64, ptr %slot341, align 8
  %op1855 = sub i64 %v1854, 16
  store i64 %op1855, ptr %slot343, align 8
  %v1856 = load i64, ptr %slot341, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %rgep1858 = getelementptr i8, ptr %p1857, i64 -16
  %ld1859 = load i64, ptr %rgep1858, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1859, ptr %slot344, align 8
  %v1860 = load i64, ptr %slot344, align 8
  %op1861 = and i64 %v1860, 4611686018427387906
  store i64 %op1861, ptr %slot345, align 8
  %v1862 = load i64, ptr %slot345, align 8
  %cmp1863 = icmp ne i64 %v1862, 0
  %cv1864 = zext i1 %cmp1863 to i32
  store i32 %cv1864, ptr %slot346, align 8
  %v1865 = load i32, ptr %slot346, align 8
  %cv1866 = zext i32 %v1865 to i64
  %cond1867 = icmp ne i64 %cv1866, 0
  br i1 %cond1867, label %bb_rcgclear457, label %bb_rcgcounted457
bb_rcgcounted457:
  %v1868 = load i64, ptr %slot341, align 8
  %op1869 = sub i64 %v1868, 32
  store i64 %op1869, ptr %slot347, align 8
  %v1870 = load i64, ptr %slot341, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  %rgep1872 = getelementptr i8, ptr %p1871, i64 -32
  %ld1873 = load i64, ptr %rgep1872, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1873, ptr %slot348, align 8
  %v1874 = load i64, ptr %slot348, align 8
  %op1875 = sub i64 %v1874, 1
  store i64 %op1875, ptr %slot349, align 8
  %v1876 = load i64, ptr %slot349, align 8
  %cmp1877 = icmp eq i64 %v1876, 0
  %cv1878 = zext i1 %cmp1877 to i32
  store i32 %cv1878, ptr %slot350, align 8
  %v1879 = load i32, ptr %slot350, align 8
  %cv1880 = zext i32 %v1879 to i64
  %cond1881 = icmp ne i64 %cv1880, 0
  br i1 %cond1881, label %bb_rcglast457, label %bb_rcgdec457
bb_rcglast457:
  %v1882 = load i64, ptr %slot341, align 8
  %op1883 = sub i64 %v1882, 24
  store i64 %op1883, ptr %slot351, align 8
  %v1884 = load i64, ptr %slot341, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  %rgep1886 = getelementptr i8, ptr %p1885, i64 -24
  %ld1887 = load i64, ptr %rgep1886, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1887, ptr %slot352, align 8
  %v1888 = load i64, ptr %slot352, align 8
  %cmp1889 = icmp ne i64 %v1888, 0
  %cv1890 = zext i1 %cmp1889 to i32
  store i32 %cv1890, ptr %slot353, align 8
  %v1891 = load i32, ptr %slot353, align 8
  %cv1892 = zext i32 %v1891 to i64
  %cond1893 = icmp ne i64 %cv1892, 0
  br i1 %cond1893, label %bb_rcgdec457, label %bb_rcgslow457
bb_rcgslow457:
  %v1894 = load i64, ptr %slot340, align 8
  %v1895 = load i64, ptr %slot323, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1894, i64 %v1895) nomerge, !dbg !124
  br label %bb_rcgdone457
bb_rcgdec457:
  %v1896 = load i64, ptr %slot349, align 8
  %v1897 = load i64, ptr %slot341, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  %rgep1899 = getelementptr i8, ptr %p1898, i64 -32
  store i64 %v1896, ptr %rgep1899, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear457
bb_rcgclear457:
  %v1900 = load i64, ptr %slot323, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  store i64 0, ptr %p1901, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone457
bb_rcgdone457:
  br label %bb_rcslotdone426
bb_rcslotdone426:
  br label %bb_rcprepared372
bb_rcprepared372:
  %v1902 = load i64, ptr %slot15, align 8
  store i64 %v1902, ptr %slot354, align 8
  %v1903 = load i64, ptr %slot354, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  %ld1905 = load i64, ptr %p1904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1905, ptr %slot355, align 8
  %v1906 = load i64, ptr %slot9, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 0, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot5, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %ld1910 = load i32, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1910, ptr %slot356, align 8
  %v1911 = load i32, ptr %slot356, align 8
  %cv1912 = zext i32 %v1911 to i64
  %cond1913 = icmp ne i64 %cv1912, 0
  br i1 %cond1913, label %bb_rcslotdrop466, label %bb_rcslotdone466
bb_rcslotdrop466:
  %v1914 = load i64, ptr %slot5, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i32 0, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot11, align 8
  store i64 %v1916, ptr %slot357, align 8
  %v1917 = load i64, ptr %slot6, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i32, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1919, ptr %slot358, align 8
  %v1920 = load i32, ptr %slot358, align 8
  %op1921 = and i32 %v1920, 28
  store i32 %op1921, ptr %slot359, align 8
  %v1922 = load i32, ptr %slot359, align 8
  %cv1923 = zext i32 %v1922 to i64
  %cond1924 = icmp ne i64 %cv1923, 0
  br i1 %cond1924, label %bb_rcslotrole466, label %bb_rcslotowner466
bb_rcslotrole466:
  %v1925 = load i64, ptr %slot25, align 8
  store i64 %v1925, ptr %slot360, align 8
  %v1926 = load i64, ptr %slot357, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  %ld1928 = load i64, ptr %p1927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1928, ptr %slot361, align 8
  %v1929 = load i64, ptr %slot361, align 8
  %cmp1930 = icmp ne i64 %v1929, 0
  %cv1931 = zext i1 %cmp1930 to i32
  store i32 %cv1931, ptr %slot362, align 8
  %v1932 = load i32, ptr %slot362, align 8
  %cv1933 = zext i32 %v1932 to i64
  %cond1934 = icmp ne i64 %cv1933, 0
  br i1 %cond1934, label %bb_rcgnn482, label %bb_rcgdone482
bb_rcgnn482:
  %v1935 = load i64, ptr %slot361, align 8
  %op1936 = sub i64 %v1935, 16
  store i64 %op1936, ptr %slot363, align 8
  %v1937 = load i64, ptr %slot361, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %rgep1939 = getelementptr i8, ptr %p1938, i64 -16
  %ld1940 = load i64, ptr %rgep1939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1940, ptr %slot364, align 8
  %v1941 = load i64, ptr %slot364, align 8
  %op1942 = and i64 %v1941, 4611686018427387906
  store i64 %op1942, ptr %slot365, align 8
  %v1943 = load i64, ptr %slot365, align 8
  %cmp1944 = icmp ne i64 %v1943, 0
  %cv1945 = zext i1 %cmp1944 to i32
  store i32 %cv1945, ptr %slot366, align 8
  %v1946 = load i32, ptr %slot366, align 8
  %cv1947 = zext i32 %v1946 to i64
  %cond1948 = icmp ne i64 %cv1947, 0
  br i1 %cond1948, label %bb_rcgclear482, label %bb_rcgcounted482
bb_rcgcounted482:
  %v1949 = load i64, ptr %slot361, align 8
  %op1950 = sub i64 %v1949, 24
  store i64 %op1950, ptr %slot367, align 8
  %v1951 = load i64, ptr %slot361, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %rgep1953 = getelementptr i8, ptr %p1952, i64 -24
  %ld1954 = load i64, ptr %rgep1953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1954, ptr %slot368, align 8
  %v1955 = load i64, ptr %slot368, align 8
  %op1956 = sub i64 %v1955, 1
  store i64 %op1956, ptr %slot369, align 8
  %v1957 = load i64, ptr %slot369, align 8
  %cmp1958 = icmp eq i64 %v1957, 0
  %cv1959 = zext i1 %cmp1958 to i32
  store i32 %cv1959, ptr %slot370, align 8
  %v1960 = load i32, ptr %slot370, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcglast482, label %bb_rcgdec482
bb_rcglast482:
  %v1963 = load i64, ptr %slot361, align 8
  %op1964 = sub i64 %v1963, 32
  store i64 %op1964, ptr %slot371, align 8
  %v1965 = load i64, ptr %slot361, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  %rgep1967 = getelementptr i8, ptr %p1966, i64 -32
  %ld1968 = load i64, ptr %rgep1967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1968, ptr %slot372, align 8
  %v1969 = load i64, ptr %slot372, align 8
  %cmp1970 = icmp ne i64 %v1969, 0
  %cv1971 = zext i1 %cmp1970 to i32
  store i32 %cv1971, ptr %slot373, align 8
  %v1972 = load i32, ptr %slot373, align 8
  %cv1973 = zext i32 %v1972 to i64
  %cond1974 = icmp ne i64 %cv1973, 0
  br i1 %cond1974, label %bb_rcgdec482, label %bb_rcgslow482
bb_rcgslow482:
  %v1975 = load i64, ptr %slot360, align 8
  %v1976 = load i64, ptr %slot357, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1975, i64 %v1976) nomerge, !dbg !124
  br label %bb_rcgdone482
bb_rcgdec482:
  %v1977 = load i64, ptr %slot369, align 8
  %v1978 = load i64, ptr %slot361, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  %rgep1980 = getelementptr i8, ptr %p1979, i64 -24
  store i64 %v1977, ptr %rgep1980, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear482
bb_rcgclear482:
  %v1981 = load i64, ptr %slot357, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  store i64 0, ptr %p1982, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone482
bb_rcgdone482:
  br label %bb_rcslotdone466
bb_rcslotowner466:
  %v1983 = load i64, ptr %slot25, align 8
  store i64 %v1983, ptr %slot374, align 8
  %v1984 = load i64, ptr %slot357, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i64, ptr %p1985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1986, ptr %slot375, align 8
  %v1987 = load i64, ptr %slot375, align 8
  %cmp1988 = icmp ne i64 %v1987, 0
  %cv1989 = zext i1 %cmp1988 to i32
  store i32 %cv1989, ptr %slot376, align 8
  %v1990 = load i32, ptr %slot376, align 8
  %cv1991 = zext i32 %v1990 to i64
  %cond1992 = icmp ne i64 %cv1991, 0
  br i1 %cond1992, label %bb_rcgnn497, label %bb_rcgdone497
bb_rcgnn497:
  %v1993 = load i64, ptr %slot375, align 8
  %op1994 = sub i64 %v1993, 16
  store i64 %op1994, ptr %slot377, align 8
  %v1995 = load i64, ptr %slot375, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  %rgep1997 = getelementptr i8, ptr %p1996, i64 -16
  %ld1998 = load i64, ptr %rgep1997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1998, ptr %slot378, align 8
  %v1999 = load i64, ptr %slot378, align 8
  %op2000 = and i64 %v1999, 4611686018427387906
  store i64 %op2000, ptr %slot379, align 8
  %v2001 = load i64, ptr %slot379, align 8
  %cmp2002 = icmp ne i64 %v2001, 0
  %cv2003 = zext i1 %cmp2002 to i32
  store i32 %cv2003, ptr %slot380, align 8
  %v2004 = load i32, ptr %slot380, align 8
  %cv2005 = zext i32 %v2004 to i64
  %cond2006 = icmp ne i64 %cv2005, 0
  br i1 %cond2006, label %bb_rcgclear497, label %bb_rcgcounted497
bb_rcgcounted497:
  %v2007 = load i64, ptr %slot375, align 8
  %op2008 = sub i64 %v2007, 32
  store i64 %op2008, ptr %slot381, align 8
  %v2009 = load i64, ptr %slot375, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %rgep2011 = getelementptr i8, ptr %p2010, i64 -32
  %ld2012 = load i64, ptr %rgep2011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2012, ptr %slot382, align 8
  %v2013 = load i64, ptr %slot382, align 8
  %op2014 = sub i64 %v2013, 1
  store i64 %op2014, ptr %slot383, align 8
  %v2015 = load i64, ptr %slot383, align 8
  %cmp2016 = icmp eq i64 %v2015, 0
  %cv2017 = zext i1 %cmp2016 to i32
  store i32 %cv2017, ptr %slot384, align 8
  %v2018 = load i32, ptr %slot384, align 8
  %cv2019 = zext i32 %v2018 to i64
  %cond2020 = icmp ne i64 %cv2019, 0
  br i1 %cond2020, label %bb_rcglast497, label %bb_rcgdec497
bb_rcglast497:
  %v2021 = load i64, ptr %slot375, align 8
  %op2022 = sub i64 %v2021, 24
  store i64 %op2022, ptr %slot385, align 8
  %v2023 = load i64, ptr %slot375, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  %rgep2025 = getelementptr i8, ptr %p2024, i64 -24
  %ld2026 = load i64, ptr %rgep2025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2026, ptr %slot386, align 8
  %v2027 = load i64, ptr %slot386, align 8
  %cmp2028 = icmp ne i64 %v2027, 0
  %cv2029 = zext i1 %cmp2028 to i32
  store i32 %cv2029, ptr %slot387, align 8
  %v2030 = load i32, ptr %slot387, align 8
  %cv2031 = zext i32 %v2030 to i64
  %cond2032 = icmp ne i64 %cv2031, 0
  br i1 %cond2032, label %bb_rcgdec497, label %bb_rcgslow497
bb_rcgslow497:
  %v2033 = load i64, ptr %slot374, align 8
  %v2034 = load i64, ptr %slot357, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2033, i64 %v2034) nomerge, !dbg !124
  br label %bb_rcgdone497
bb_rcgdec497:
  %v2035 = load i64, ptr %slot383, align 8
  %v2036 = load i64, ptr %slot375, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %rgep2038 = getelementptr i8, ptr %p2037, i64 -32
  store i64 %v2035, ptr %rgep2038, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear497
bb_rcgclear497:
  %v2039 = load i64, ptr %slot357, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i64 0, ptr %p2040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone497
bb_rcgdone497:
  br label %bb_rcslotdone466
bb_rcslotdone466:
  %v2041 = load i64, ptr %slot355, align 8
  ret i64 %v2041
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_6fed35e3009e497ab580214c876d7a746f7a24cf38303b15909afebc8b6b79d5 = external global i8, align 8
@myl_lit_d6b006dd0b769e0e5a8bb806c60978be91d208b60a28fe604b56cb4713aa8698 = external global i8, align 8
@myl_lit_f65c774382e8464e62d85b25bc3a05a9ed3170e99614fb9f4289e109b0f73715 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93", linkageName: "myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8739635905151805232, i64 0, !"myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!120 = !DILocation(line: 13, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
