target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %callresult670 = alloca [24 x i8], align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i32, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i32, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i32, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i32, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i32, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i32, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i32, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i32, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i32, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i32, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1365 = load i64, ptr %slot1, align 8
  %op1366 = add i64 %v1365, 32
  store i64 %op1366, ptr %slot4, align 8
  %mem1367 = alloca i8, i64 8, align 8
  %ptr1368 = ptrtoint ptr %mem1367 to i64
  store i64 %ptr1368, ptr %slot5, align 8
  %mem1369 = alloca i8, i64 8, align 8
  %ptr1370 = ptrtoint ptr %mem1369 to i64
  store i64 %ptr1370, ptr %slot6, align 8
  %mem1371 = alloca i8, i64 8, align 8
  %ptr1372 = ptrtoint ptr %mem1371 to i64
  store i64 %ptr1372, ptr %slot7, align 8
  %mem1373 = alloca i8, i64 8, align 8
  %ptr1374 = ptrtoint ptr %mem1373 to i64
  store i64 %ptr1374, ptr %slot8, align 8
  %mem1375 = alloca i8, i64 8, align 8
  %ptr1376 = ptrtoint ptr %mem1375 to i64
  store i64 %ptr1376, ptr %slot9, align 8
  %mem1377 = alloca i8, i64 8, align 8
  %ptr1378 = ptrtoint ptr %mem1377 to i64
  store i64 %ptr1378, ptr %slot10, align 8
  %mem1379 = alloca i8, i64 208, align 8
  %ptr1380 = ptrtoint ptr %mem1379 to i64
  store i64 %ptr1380, ptr %slot11, align 8
  %mem1381 = alloca i8, i64 208, align 8
  %ptr1382 = ptrtoint ptr %mem1381 to i64
  store i64 %ptr1382, ptr %slot12, align 8
  %mem1383 = alloca i8, i64 8, align 8
  %ptr1384 = ptrtoint ptr %mem1383 to i64
  store i64 %ptr1384, ptr %slot13, align 8
  %mem1385 = alloca i8, i64 8, align 8
  %ptr1386 = ptrtoint ptr %mem1385 to i64
  store i64 %ptr1386, ptr %slot14, align 8
  %mem1387 = alloca i8, i64 208, align 8
  %ptr1388 = ptrtoint ptr %mem1387 to i64
  store i64 %ptr1388, ptr %slot15, align 8
  %mem1389 = alloca i8, i64 8, align 8
  %ptr1390 = ptrtoint ptr %mem1389 to i64
  store i64 %ptr1390, ptr %slot16, align 8
  %mem1391 = alloca i8, i64 8, align 8
  %ptr1392 = ptrtoint ptr %mem1391 to i64
  store i64 %ptr1392, ptr %slot17, align 8
  %mem1393 = alloca i8, i64 8, align 8
  %ptr1394 = ptrtoint ptr %mem1393 to i64
  store i64 %ptr1394, ptr %slot18, align 8
  %mem1395 = alloca i8, i64 8, align 8
  %ptr1396 = ptrtoint ptr %mem1395 to i64
  store i64 %ptr1396, ptr %slot19, align 8
  %mem1397 = alloca i8, i64 16, align 8
  %ptr1398 = ptrtoint ptr %mem1397 to i64
  store i64 %ptr1398, ptr %slot20, align 8
  %mem1399 = alloca i8, i64 48, align 8
  %ptr1400 = ptrtoint ptr %mem1399 to i64
  store i64 %ptr1400, ptr %slot21, align 8
  %mem1401 = alloca i8, i64 24, align 8
  %ptr1402 = ptrtoint ptr %mem1401 to i64
  store i64 %ptr1402, ptr %slot22, align 8
  %mem1403 = alloca i8, i64 24, align 8
  %ptr1404 = ptrtoint ptr %mem1403 to i64
  store i64 %ptr1404, ptr %slot23, align 8
  %mem1405 = alloca i8, i64 24, align 8
  %ptr1406 = ptrtoint ptr %mem1405 to i64
  store i64 %ptr1406, ptr %slot24, align 8
  %mem1407 = alloca i8, i64 32, align 8
  %ptr1408 = ptrtoint ptr %mem1407 to i64
  store i64 %ptr1408, ptr %slot25, align 8
  %mem1409 = alloca i8, i64 8, align 8
  %ptr1410 = ptrtoint ptr %mem1409 to i64
  store i64 %ptr1410, ptr %slot26, align 8
  %mem1411 = alloca i8, i64 8, align 8
  %ptr1412 = ptrtoint ptr %mem1411 to i64
  store i64 %ptr1412, ptr %slot27, align 8
  %mem1413 = alloca i8, i64 8, align 8
  %ptr1414 = ptrtoint ptr %mem1413 to i64
  store i64 %ptr1414, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1415 = alloca i8, i64 8, align 8
  %ptr1416 = ptrtoint ptr %mem1415 to i64
  store i64 %ptr1416, ptr %slot29, align 8
  %v1417 = load i64, ptr %slot1, align 8
  %op1418 = add i64 %v1417, 64
  store i64 %op1418, ptr %slot30, align 8
  %v1419 = load i64, ptr %slot30, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i64, ptr %p1420, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1421, ptr %slot31, align 8
  %stack1422 = call ptr @llvm.stacksave()
  %stackaddr1423 = ptrtoint ptr %stack1422 to i64
  %v1424 = load i64, ptr %slot31, align 8
  %cmp1425 = icmp ult i64 %stackaddr1423, %v1424
  %cv1426 = zext i1 %cmp1425 to i64
  store i64 %cv1426, ptr %slot32, align 8
  %v1427 = load i64, ptr %slot32, align 8
  %cond1428 = icmp ne i64 %v1427, 0
  br i1 %cond1428, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1429 = load i64, ptr %slot1, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  call void @myl_qbe_fail_frame(ptr %p1430) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1431 = load i64, ptr %slot18, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  store i64 0, ptr %p1432, align 8, !alias.scope !3, !noalias !4
  %v1433 = load i64, ptr %slot2, align 8
  %v1434 = load i64, ptr %slot16, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  store i64 %v1433, ptr %p1435, align 8, !alias.scope !3, !noalias !4
  %v1436 = load i64, ptr %slot3, align 8
  %v1437 = load i64, ptr %slot17, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  store i64 %v1436, ptr %p1438, align 8, !alias.scope !3, !noalias !4
  %v1439 = load i64, ptr %slot1, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  %call1441 = call ptr @myl_qbe_heap(ptr %p1440) nomerge, !dbg !112
  %calladdr1442 = ptrtoint ptr %call1441 to i64
  store i64 %calladdr1442, ptr %slot33, align 8
  %v1443 = load i64, ptr %slot1, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  %call1445 = call i64 @myl_qbe_region_mark(ptr %p1444) nomerge, !dbg !112
  store i64 %call1445, ptr %slot34, align 8
  %v1446 = load i64, ptr %slot5, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i32 0, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot6, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i32 0, ptr %p1449, align 4, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot7, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i32 0, ptr %p1451, align 4, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot8, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 0, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot9, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  store i32 0, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  %v1456 = load i64, ptr %slot10, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  store i32 0, ptr %p1457, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1458 = load i64, ptr %slot16, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %ld1460 = load i64, ptr %p1459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1460, ptr %slot35, align 8
  %v1461 = load i64, ptr %slot35, align 8
  %v1462 = load i64, ptr %slot26, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i64 %v1461, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot26, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i64, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1466, ptr %slot36, align 8
  %v1467 = load i64, ptr %slot36, align 8
  %op1468 = add i64 %v1467, 0
  store i64 %op1468, ptr %slot37, align 8
  %v1469 = load i64, ptr %slot37, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1471, ptr %slot38, align 8
  %v1472 = load i64, ptr %slot38, align 8
  %v1473 = load i64, ptr %slot26, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i64 %v1472, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot5, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i32, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1477, ptr %slot39, align 8
  %v1478 = load i32, ptr %slot39, align 8
  %cv1479 = zext i32 %v1478 to i64
  %cond1480 = icmp ne i64 %cv1479, 0
  br i1 %cond1480, label %bb_rcslotdrop19, label %bb_rcslotdone19
bb_rcslotdrop19:
  %v1481 = load i64, ptr %slot5, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 0, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot11, align 8
  store i64 %v1483, ptr %slot40, align 8
  %v1484 = load i64, ptr %slot6, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i32, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1486, ptr %slot41, align 8
  %v1487 = load i32, ptr %slot41, align 8
  %op1488 = and i32 %v1487, 28
  store i32 %op1488, ptr %slot42, align 8
  %v1489 = load i32, ptr %slot42, align 8
  %cv1490 = zext i32 %v1489 to i64
  %cond1491 = icmp ne i64 %cv1490, 0
  br i1 %cond1491, label %bb_rcslotrole19, label %bb_rcslotowner19
bb_rcslotrole19:
  %v1492 = load i64, ptr %slot33, align 8
  store i64 %v1492, ptr %slot43, align 8
  %v1493 = load i64, ptr %slot43, align 8
  %v1494 = load i64, ptr %slot40, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1493, i64 %v1494) nomerge, !dbg !114
  br label %bb_rcslotdone19
bb_rcslotowner19:
  %v1495 = load i64, ptr %slot33, align 8
  store i64 %v1495, ptr %slot44, align 8
  %v1496 = load i64, ptr %slot44, align 8
  %v1497 = load i64, ptr %slot40, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1496, i64 %v1497) nomerge, !dbg !114
  br label %bb_rcslotdone19
bb_rcslotdone19:
  %v1498 = load i64, ptr %slot26, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  %ld1500 = load i64, ptr %p1499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1500, ptr %slot45, align 8
  %v1501 = load i64, ptr %slot45, align 8
  %v1502 = load i64, ptr %slot18, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i64 %v1501, ptr %p1503, align 8, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot17, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  %ld1506 = load i64, ptr %p1505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1506, ptr %slot46, align 8
  %v1507 = load i64, ptr %slot46, align 8
  %v1508 = load i64, ptr %slot26, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i64 %v1507, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot26, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i64, ptr %p1511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1512, ptr %slot47, align 8
  %v1513 = load i64, ptr %slot47, align 8
  %v1514 = load i64, ptr %slot19, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  store i64 %v1513, ptr %p1515, align 8, !alias.scope !3, !noalias !4
  %v1516 = load i64, ptr %slot19, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %ld1518 = load i64, ptr %p1517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1518, ptr %slot48, align 8
  %v1519 = load i64, ptr %slot48, align 8
  %v1520 = load i64, ptr %slot26, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  store i64 %v1519, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  %v1522 = load i64, ptr %slot27, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i64 0, ptr %p1523, align 8, !alias.scope !3, !noalias !4
  %v1524 = load i64, ptr %slot27, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  %ld1526 = load i64, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1526, ptr %slot49, align 8
  %v1527 = load i64, ptr %slot26, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %ld1529 = load i64, ptr %p1528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1529, ptr %slot50, align 8
  %v1530 = load i64, ptr %slot50, align 8
  %v1531 = load i64, ptr %slot49, align 8
  %cmp1532 = icmp slt i64 %v1530, %v1531
  %cv1533 = zext i1 %cmp1532 to i64
  store i64 %cv1533, ptr %slot51, align 8
  %v1534 = load i64, ptr %slot51, align 8
  %v1535 = load i64, ptr %slot26, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i64 %v1534, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot26, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %ld1539 = load i64, ptr %p1538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1539, ptr %slot52, align 8
  %v1540 = load i64, ptr %slot52, align 8
  %cond1541 = icmp ne i64 %v1540, 0
  br i1 %cond1541, label %bb_next34, label %bb_i14
bb_next34:
  %v1542 = load i64, ptr %slot18, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %ld1544 = load i64, ptr %p1543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1544, ptr %slot53, align 8
  %v1545 = load i64, ptr %slot53, align 8
  %op1546 = add i64 %v1545, 0
  store i64 %op1546, ptr %slot54, align 8
  %v1547 = load i64, ptr %slot54, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  %ld1549 = load i64, ptr %p1548, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1549, ptr %slot55, align 8
  %v1550 = load i64, ptr %slot55, align 8
  %v1551 = load i64, ptr %slot26, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  store i64 %v1550, ptr %p1552, align 8, !alias.scope !3, !noalias !4
  %v1553 = load i64, ptr %slot26, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  %ld1555 = load i64, ptr %p1554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1555, ptr %slot56, align 8
  %v1556 = load i64, ptr %slot56, align 8
  %cmp1557 = icmp ugt i64 %v1556, 9223372036854775807
  %cv1558 = zext i1 %cmp1557 to i64
  store i64 %cv1558, ptr %slot57, align 8
  %v1559 = load i64, ptr %slot57, align 8
  %cond1560 = icmp ne i64 %v1559, 0
  br i1 %cond1560, label %bb_cast_overflow39, label %bb_cast_ok39
bb_cast_overflow39:
  %v1561 = load i64, ptr %slot1, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %v1563 = load i64, ptr %slot56, align 8
  call void @myl_qbe_fail_cast(ptr %p1562, i64 %v1563, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok39:
  %v1564 = load i64, ptr %slot56, align 8
  %v1565 = load i64, ptr %slot26, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  store i64 %v1564, ptr %p1566, align 8, !alias.scope !3, !noalias !4
  %v1567 = load i64, ptr %slot19, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  %ld1569 = load i64, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1569, ptr %slot58, align 8
  %v1570 = load i64, ptr %slot58, align 8
  %v1571 = load i64, ptr %slot27, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i64 %v1570, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot27, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %ld1575 = load i64, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1575, ptr %slot59, align 8
  %v1576 = load i64, ptr %slot26, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %ld1578 = load i64, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1578, ptr %slot60, align 8
  %v1579 = load i64, ptr %slot60, align 8
  %v1580 = load i64, ptr %slot59, align 8
  %ovpair1582 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1579, i64 %v1580)
  %op1581 = extractvalue { i64, i1 } %ovpair1582, 0
  %ov1583 = extractvalue { i64, i1 } %ovpair1582, 1
  store i64 %op1581, ptr %slot61, align 8
  %v1584 = load i64, ptr %slot60, align 8
  %v1585 = load i64, ptr %slot61, align 8
  %op1586 = xor i64 %v1584, %v1585
  store i64 %op1586, ptr %slot62, align 8
  %v1587 = load i64, ptr %slot59, align 8
  %v1588 = load i64, ptr %slot61, align 8
  %op1589 = xor i64 %v1587, %v1588
  store i64 %op1589, ptr %slot63, align 8
  %v1590 = load i64, ptr %slot62, align 8
  %v1591 = load i64, ptr %slot63, align 8
  %op1592 = and i64 %v1590, %v1591
  store i64 %op1592, ptr %slot64, align 8
  %cv1593 = zext i1 %ov1583 to i64
  store i64 %cv1593, ptr %slot65, align 8
  %v1594 = load i64, ptr %slot65, align 8
  %cond1595 = icmp ne i64 %v1594, 0
  br i1 %cond1595, label %bb_overflow43, label %bb_checked43
bb_overflow43:
  %v1596 = load i64, ptr %slot1, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %v1598 = load i64, ptr %slot60, align 8
  %v1599 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1597, i64 0, i64 %v1598, i64 %v1599, i64 64) nomerge, !dbg !118
  unreachable
bb_checked43:
  %v1600 = load i64, ptr %slot61, align 8
  %v1601 = load i64, ptr %slot26, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i64 %v1600, ptr %p1602, align 8, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot26, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i64, ptr %p1604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1605, ptr %slot66, align 8
  %v1606 = load i64, ptr %slot66, align 8
  %v1607 = load i64, ptr %slot19, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  store i64 %v1606, ptr %p1608, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v1609 = load i64, ptr %slot19, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  %ld1611 = load i64, ptr %p1610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1611, ptr %slot67, align 8
  %v1612 = load i64, ptr %slot67, align 8
  %v1613 = load i64, ptr %slot26, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 %v1612, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot18, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i64, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1617, ptr %slot68, align 8
  %v1618 = load i64, ptr %slot26, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ld1620 = load i64, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1620, ptr %slot69, align 8
  %v1621 = load i64, ptr %slot68, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %ld1623 = load i64, ptr %p1622, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1623, ptr %slot70, align 8
  %v1624 = load i64, ptr %slot69, align 8
  %v1625 = load i64, ptr %slot70, align 8
  %cmp1626 = icmp ult i64 %v1624, %v1625
  %cv1627 = zext i1 %cmp1626 to i64
  store i64 %cv1627, ptr %slot71, align 8
  %v1628 = load i64, ptr %slot71, align 8
  %cond1629 = icmp ne i64 %v1628, 0
  br i1 %cond1629, label %bb_success55, label %bb_failed55
bb_failed55:
  %v1630 = load i64, ptr %slot1, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  %v1632 = load i64, ptr %slot69, align 8
  %v1633 = load i64, ptr %slot70, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1631, i64 %v1632, i64 %v1633) nomerge, !dbg !120
  unreachable
bb_success55:
  %v1634 = load i64, ptr %slot68, align 8
  %op1635 = add i64 %v1634, 32
  store i64 %op1635, ptr %slot72, align 8
  %v1636 = load i64, ptr %slot72, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i64, ptr %p1637, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1638, ptr %slot73, align 8
  %v1639 = load i64, ptr %slot69, align 8
  %op1640 = mul i64 %v1639, 56
  store i64 %op1640, ptr %slot74, align 8
  %v1641 = load i64, ptr %slot73, align 8
  %v1642 = load i64, ptr %slot74, align 8
  %op1643 = add i64 %v1641, %v1642
  store i64 %op1643, ptr %slot75, align 8
  %v1644 = load i64, ptr %slot75, align 8
  %v1645 = load i64, ptr %slot26, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i64 %v1644, ptr %p1646, align 8, !alias.scope !3, !noalias !4
  %v1647 = load i64, ptr %slot26, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %ld1649 = load i64, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1649, ptr %slot76, align 8
  %v1650 = load i64, ptr %slot76, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  %ld1652 = load i32, ptr %p1651, align 4, !alias.scope !12, !noalias !13
  %ext1653 = zext i32 %ld1652 to i64
  store i64 %ext1653, ptr %slot77, align 8
  %v1654 = load i64, ptr %slot77, align 8
  %cmp1655 = icmp eq i64 %v1654, 0
  %cv1656 = zext i1 %cmp1655 to i64
  store i64 %cv1656, ptr %slot78, align 8
  %v1657 = load i64, ptr %slot78, align 8
  %cond1658 = icmp ne i64 %v1657, 0
  br i1 %cond1658, label %bb_rcarm62, label %bb_rcarmnext62
bb_rcarm62:
  %v1659 = load i64, ptr %slot5, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i32, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1661, ptr %slot79, align 8
  %v1662 = load i32, ptr %slot79, align 8
  %cv1663 = zext i32 %v1662 to i64
  %cond1664 = icmp ne i64 %cv1663, 0
  br i1 %cond1664, label %bb_rcslotdrop65, label %bb_rcslotdone65
bb_rcslotdrop65:
  %v1665 = load i64, ptr %slot5, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  store i32 0, ptr %p1666, align 4, !alias.scope !3, !noalias !4
  %v1667 = load i64, ptr %slot11, align 8
  store i64 %v1667, ptr %slot80, align 8
  %v1668 = load i64, ptr %slot6, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i32, ptr %p1669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1670, ptr %slot81, align 8
  %v1671 = load i32, ptr %slot81, align 8
  %op1672 = and i32 %v1671, 28
  store i32 %op1672, ptr %slot82, align 8
  %v1673 = load i32, ptr %slot82, align 8
  %cv1674 = zext i32 %v1673 to i64
  %cond1675 = icmp ne i64 %cv1674, 0
  br i1 %cond1675, label %bb_rcslotrole65, label %bb_rcslotowner65
bb_rcslotrole65:
  %v1676 = load i64, ptr %slot33, align 8
  store i64 %v1676, ptr %slot83, align 8
  %v1677 = load i64, ptr %slot83, align 8
  %v1678 = load i64, ptr %slot80, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1677, i64 %v1678) nomerge, !dbg !122
  br label %bb_rcslotdone65
bb_rcslotowner65:
  %v1679 = load i64, ptr %slot33, align 8
  store i64 %v1679, ptr %slot84, align 8
  %v1680 = load i64, ptr %slot84, align 8
  %v1681 = load i64, ptr %slot80, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1680, i64 %v1681) nomerge, !dbg !122
  br label %bb_rcslotdone65
bb_rcslotdone65:
  br label %bb_i72
bb_rcarmnext62:
  %v1682 = load i64, ptr %slot77, align 8
  %cmp1683 = icmp eq i64 %v1682, 1
  %cv1684 = zext i1 %cmp1683 to i64
  store i64 %cv1684, ptr %slot85, align 8
  %v1685 = load i64, ptr %slot85, align 8
  %cond1686 = icmp ne i64 %v1685, 0
  br i1 %cond1686, label %bb_rcarm72, label %bb_rcarmnext72
bb_rcarm72:
  %v1687 = load i64, ptr %slot76, align 8
  %op1688 = add i64 %v1687, 8
  store i64 %op1688, ptr %slot86, align 8
  %v1689 = load i64, ptr %slot86, align 8
  %v1690 = load i64, ptr %slot20, align 8
  %p1691 = inttoptr i64 %v1689 to ptr
  %p1692 = inttoptr i64 %v1690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1692, ptr %p1691, i64 16, i1 false), !alias.scope !10000000
  %v1693 = load i64, ptr %slot5, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %ld1695 = load i32, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1695, ptr %slot87, align 8
  %v1696 = load i32, ptr %slot87, align 8
  %cv1697 = zext i32 %v1696 to i64
  %cond1698 = icmp ne i64 %cv1697, 0
  br i1 %cond1698, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v1699 = load i64, ptr %slot5, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 0, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot11, align 8
  store i64 %v1701, ptr %slot88, align 8
  %v1702 = load i64, ptr %slot6, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %ld1704 = load i32, ptr %p1703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1704, ptr %slot89, align 8
  %v1705 = load i32, ptr %slot89, align 8
  %op1706 = and i32 %v1705, 28
  store i32 %op1706, ptr %slot90, align 8
  %v1707 = load i32, ptr %slot90, align 8
  %cv1708 = zext i32 %v1707 to i64
  %cond1709 = icmp ne i64 %cv1708, 0
  br i1 %cond1709, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v1710 = load i64, ptr %slot33, align 8
  store i64 %v1710, ptr %slot91, align 8
  %v1711 = load i64, ptr %slot91, align 8
  %v1712 = load i64, ptr %slot88, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1711, i64 %v1712) nomerge, !dbg !122
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1713 = load i64, ptr %slot33, align 8
  store i64 %v1713, ptr %slot92, align 8
  %v1714 = load i64, ptr %slot92, align 8
  %v1715 = load i64, ptr %slot88, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1714, i64 %v1715) nomerge, !dbg !122
  br label %bb_rcslotdone86
bb_rcslotdone86:
  br label %bb_i17
bb_rcarmnext72:
  %v1716 = load i64, ptr %slot77, align 8
  %cmp1717 = icmp eq i64 %v1716, 2
  %cv1718 = zext i1 %cmp1717 to i64
  store i64 %cv1718, ptr %slot93, align 8
  %v1719 = load i64, ptr %slot93, align 8
  %cond1720 = icmp ne i64 %v1719, 0
  br i1 %cond1720, label %bb_rcarm93, label %bb_rcarmnext93
bb_rcarm93:
  %v1721 = load i64, ptr %slot76, align 8
  %op1722 = add i64 %v1721, 8
  store i64 %op1722, ptr %slot94, align 8
  %v1723 = load i64, ptr %slot94, align 8
  %v1724 = load i64, ptr %slot21, align 8
  %p1725 = inttoptr i64 %v1723 to ptr
  %p1726 = inttoptr i64 %v1724 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1726, ptr %p1725, i64 48, i1 false), !alias.scope !10000000
  %v1727 = load i64, ptr %slot5, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %ld1729 = load i32, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1729, ptr %slot95, align 8
  %v1730 = load i32, ptr %slot95, align 8
  %cv1731 = zext i32 %v1730 to i64
  %cond1732 = icmp ne i64 %cv1731, 0
  br i1 %cond1732, label %bb_rcslotdrop107, label %bb_rcslotdone107
bb_rcslotdrop107:
  %v1733 = load i64, ptr %slot5, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 0, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot11, align 8
  store i64 %v1735, ptr %slot96, align 8
  %v1736 = load i64, ptr %slot6, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i32, ptr %p1737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1738, ptr %slot97, align 8
  %v1739 = load i32, ptr %slot97, align 8
  %op1740 = and i32 %v1739, 28
  store i32 %op1740, ptr %slot98, align 8
  %v1741 = load i32, ptr %slot98, align 8
  %cv1742 = zext i32 %v1741 to i64
  %cond1743 = icmp ne i64 %cv1742, 0
  br i1 %cond1743, label %bb_rcslotrole107, label %bb_rcslotowner107
bb_rcslotrole107:
  %v1744 = load i64, ptr %slot33, align 8
  store i64 %v1744, ptr %slot99, align 8
  %v1745 = load i64, ptr %slot99, align 8
  %v1746 = load i64, ptr %slot96, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1745, i64 %v1746) nomerge, !dbg !122
  br label %bb_rcslotdone107
bb_rcslotowner107:
  %v1747 = load i64, ptr %slot33, align 8
  store i64 %v1747, ptr %slot100, align 8
  %v1748 = load i64, ptr %slot100, align 8
  %v1749 = load i64, ptr %slot96, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1748, i64 %v1749) nomerge, !dbg !122
  br label %bb_rcslotdone107
bb_rcslotdone107:
  br label %bb_i20
bb_rcarmnext93:
  %v1750 = load i64, ptr %slot77, align 8
  %cmp1751 = icmp eq i64 %v1750, 3
  %cv1752 = zext i1 %cmp1751 to i64
  store i64 %cv1752, ptr %slot101, align 8
  %v1753 = load i64, ptr %slot101, align 8
  %cond1754 = icmp ne i64 %v1753, 0
  br i1 %cond1754, label %bb_rcarm114, label %bb_rcarmnext114
bb_rcarm114:
  %v1755 = load i64, ptr %slot5, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i32, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1757, ptr %slot102, align 8
  %v1758 = load i32, ptr %slot102, align 8
  %cv1759 = zext i32 %v1758 to i64
  %cond1760 = icmp ne i64 %cv1759, 0
  br i1 %cond1760, label %bb_rcslotdrop117, label %bb_rcslotdone117
bb_rcslotdrop117:
  %v1761 = load i64, ptr %slot5, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  store i32 0, ptr %p1762, align 4, !alias.scope !3, !noalias !4
  %v1763 = load i64, ptr %slot11, align 8
  store i64 %v1763, ptr %slot103, align 8
  %v1764 = load i64, ptr %slot6, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i32, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1766, ptr %slot104, align 8
  %v1767 = load i32, ptr %slot104, align 8
  %op1768 = and i32 %v1767, 28
  store i32 %op1768, ptr %slot105, align 8
  %v1769 = load i32, ptr %slot105, align 8
  %cv1770 = zext i32 %v1769 to i64
  %cond1771 = icmp ne i64 %cv1770, 0
  br i1 %cond1771, label %bb_rcslotrole117, label %bb_rcslotowner117
bb_rcslotrole117:
  %v1772 = load i64, ptr %slot33, align 8
  store i64 %v1772, ptr %slot106, align 8
  %v1773 = load i64, ptr %slot106, align 8
  %v1774 = load i64, ptr %slot103, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1773, i64 %v1774) nomerge, !dbg !122
  br label %bb_rcslotdone117
bb_rcslotowner117:
  %v1775 = load i64, ptr %slot33, align 8
  store i64 %v1775, ptr %slot107, align 8
  %v1776 = load i64, ptr %slot107, align 8
  %v1777 = load i64, ptr %slot103, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1776, i64 %v1777) nomerge, !dbg !122
  br label %bb_rcslotdone117
bb_rcslotdone117:
  br label %bb_i27
bb_rcarmnext114:
  %v1778 = load i64, ptr %slot77, align 8
  %cmp1779 = icmp eq i64 %v1778, 4
  %cv1780 = zext i1 %cmp1779 to i64
  store i64 %cv1780, ptr %slot108, align 8
  %v1781 = load i64, ptr %slot108, align 8
  %cond1782 = icmp ne i64 %v1781, 0
  br i1 %cond1782, label %bb_rcarm124, label %bb_rcarmnext124
bb_rcarm124:
  %v1783 = load i64, ptr %slot5, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %ld1785 = load i32, ptr %p1784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1785, ptr %slot109, align 8
  %v1786 = load i32, ptr %slot109, align 8
  %cv1787 = zext i32 %v1786 to i64
  %cond1788 = icmp ne i64 %cv1787, 0
  br i1 %cond1788, label %bb_rcslotdrop127, label %bb_rcslotdone127
bb_rcslotdrop127:
  %v1789 = load i64, ptr %slot5, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i32 0, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot11, align 8
  store i64 %v1791, ptr %slot110, align 8
  %v1792 = load i64, ptr %slot6, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %ld1794 = load i32, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1794, ptr %slot111, align 8
  %v1795 = load i32, ptr %slot111, align 8
  %op1796 = and i32 %v1795, 28
  store i32 %op1796, ptr %slot112, align 8
  %v1797 = load i32, ptr %slot112, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcslotrole127, label %bb_rcslotowner127
bb_rcslotrole127:
  %v1800 = load i64, ptr %slot33, align 8
  store i64 %v1800, ptr %slot113, align 8
  %v1801 = load i64, ptr %slot113, align 8
  %v1802 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1801, i64 %v1802) nomerge, !dbg !122
  br label %bb_rcslotdone127
bb_rcslotowner127:
  %v1803 = load i64, ptr %slot33, align 8
  store i64 %v1803, ptr %slot114, align 8
  %v1804 = load i64, ptr %slot114, align 8
  %v1805 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1804, i64 %v1805) nomerge, !dbg !122
  br label %bb_rcslotdone127
bb_rcslotdone127:
  br label %bb_i29
bb_rcarmnext124:
  %v1806 = load i64, ptr %slot77, align 8
  %cmp1807 = icmp eq i64 %v1806, 5
  %cv1808 = zext i1 %cmp1807 to i64
  store i64 %cv1808, ptr %slot115, align 8
  %v1809 = load i64, ptr %slot115, align 8
  %cond1810 = icmp ne i64 %v1809, 0
  br i1 %cond1810, label %bb_rcarm134, label %bb_rcarmnext134
bb_rcarm134:
  %v1811 = load i64, ptr %slot5, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i32, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1813, ptr %slot116, align 8
  %v1814 = load i32, ptr %slot116, align 8
  %cv1815 = zext i32 %v1814 to i64
  %cond1816 = icmp ne i64 %cv1815, 0
  br i1 %cond1816, label %bb_rcslotdrop137, label %bb_rcslotdone137
bb_rcslotdrop137:
  %v1817 = load i64, ptr %slot5, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot11, align 8
  store i64 %v1819, ptr %slot117, align 8
  %v1820 = load i64, ptr %slot6, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i32, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1822, ptr %slot118, align 8
  %v1823 = load i32, ptr %slot118, align 8
  %op1824 = and i32 %v1823, 28
  store i32 %op1824, ptr %slot119, align 8
  %v1825 = load i32, ptr %slot119, align 8
  %cv1826 = zext i32 %v1825 to i64
  %cond1827 = icmp ne i64 %cv1826, 0
  br i1 %cond1827, label %bb_rcslotrole137, label %bb_rcslotowner137
bb_rcslotrole137:
  %v1828 = load i64, ptr %slot33, align 8
  store i64 %v1828, ptr %slot120, align 8
  %v1829 = load i64, ptr %slot120, align 8
  %v1830 = load i64, ptr %slot117, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1829, i64 %v1830) nomerge, !dbg !122
  br label %bb_rcslotdone137
bb_rcslotowner137:
  %v1831 = load i64, ptr %slot33, align 8
  store i64 %v1831, ptr %slot121, align 8
  %v1832 = load i64, ptr %slot121, align 8
  %v1833 = load i64, ptr %slot117, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1832, i64 %v1833) nomerge, !dbg !122
  br label %bb_rcslotdone137
bb_rcslotdone137:
  br label %bb_i33
bb_rcarmnext134:
  %v1834 = load i64, ptr %slot77, align 8
  %cmp1835 = icmp eq i64 %v1834, 6
  %cv1836 = zext i1 %cmp1835 to i64
  store i64 %cv1836, ptr %slot122, align 8
  %v1837 = load i64, ptr %slot122, align 8
  %cond1838 = icmp ne i64 %v1837, 0
  br i1 %cond1838, label %bb_rcarm144, label %bb_rcarmnext144
bb_rcarm144:
  %v1839 = load i64, ptr %slot76, align 8
  %op1840 = add i64 %v1839, 8
  store i64 %op1840, ptr %slot123, align 8
  %v1841 = load i64, ptr %slot123, align 8
  %v1842 = load i64, ptr %slot22, align 8
  %p1843 = inttoptr i64 %v1841 to ptr
  %p1844 = inttoptr i64 %v1842 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1844, ptr %p1843, i64 24, i1 false), !alias.scope !10000000
  %v1845 = load i64, ptr %slot5, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i32, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1847, ptr %slot124, align 8
  %v1848 = load i32, ptr %slot124, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcslotdrop158, label %bb_rcslotdone158
bb_rcslotdrop158:
  %v1851 = load i64, ptr %slot5, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  store i32 0, ptr %p1852, align 4, !alias.scope !3, !noalias !4
  %v1853 = load i64, ptr %slot11, align 8
  store i64 %v1853, ptr %slot125, align 8
  %v1854 = load i64, ptr %slot6, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %ld1856 = load i32, ptr %p1855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1856, ptr %slot126, align 8
  %v1857 = load i32, ptr %slot126, align 8
  %op1858 = and i32 %v1857, 28
  store i32 %op1858, ptr %slot127, align 8
  %v1859 = load i32, ptr %slot127, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcslotrole158, label %bb_rcslotowner158
bb_rcslotrole158:
  %v1862 = load i64, ptr %slot33, align 8
  store i64 %v1862, ptr %slot128, align 8
  %v1863 = load i64, ptr %slot128, align 8
  %v1864 = load i64, ptr %slot125, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1863, i64 %v1864) nomerge, !dbg !122
  br label %bb_rcslotdone158
bb_rcslotowner158:
  %v1865 = load i64, ptr %slot33, align 8
  store i64 %v1865, ptr %slot129, align 8
  %v1866 = load i64, ptr %slot129, align 8
  %v1867 = load i64, ptr %slot125, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1866, i64 %v1867) nomerge, !dbg !122
  br label %bb_rcslotdone158
bb_rcslotdone158:
  br label %bb_i35
bb_rcarmnext144:
  %v1868 = load i64, ptr %slot77, align 8
  %cmp1869 = icmp eq i64 %v1868, 7
  %cv1870 = zext i1 %cmp1869 to i64
  store i64 %cv1870, ptr %slot130, align 8
  %v1871 = load i64, ptr %slot130, align 8
  %cond1872 = icmp ne i64 %v1871, 0
  br i1 %cond1872, label %bb_rcarm165, label %bb_rcarmnext165
bb_rcarm165:
  %v1873 = load i64, ptr %slot76, align 8
  %op1874 = add i64 %v1873, 8
  store i64 %op1874, ptr %slot131, align 8
  %v1875 = load i64, ptr %slot131, align 8
  %v1876 = load i64, ptr %slot23, align 8
  %p1877 = inttoptr i64 %v1875 to ptr
  %p1878 = inttoptr i64 %v1876 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1878, ptr %p1877, i64 24, i1 false), !alias.scope !10000000
  %v1879 = load i64, ptr %slot5, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  %ld1881 = load i32, ptr %p1880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1881, ptr %slot132, align 8
  %v1882 = load i32, ptr %slot132, align 8
  %cv1883 = zext i32 %v1882 to i64
  %cond1884 = icmp ne i64 %cv1883, 0
  br i1 %cond1884, label %bb_rcslotdrop179, label %bb_rcslotdone179
bb_rcslotdrop179:
  %v1885 = load i64, ptr %slot5, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i32 0, ptr %p1886, align 4, !alias.scope !3, !noalias !4
  %v1887 = load i64, ptr %slot11, align 8
  store i64 %v1887, ptr %slot133, align 8
  %v1888 = load i64, ptr %slot6, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %ld1890 = load i32, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1890, ptr %slot134, align 8
  %v1891 = load i32, ptr %slot134, align 8
  %op1892 = and i32 %v1891, 28
  store i32 %op1892, ptr %slot135, align 8
  %v1893 = load i32, ptr %slot135, align 8
  %cv1894 = zext i32 %v1893 to i64
  %cond1895 = icmp ne i64 %cv1894, 0
  br i1 %cond1895, label %bb_rcslotrole179, label %bb_rcslotowner179
bb_rcslotrole179:
  %v1896 = load i64, ptr %slot33, align 8
  store i64 %v1896, ptr %slot136, align 8
  %v1897 = load i64, ptr %slot136, align 8
  %v1898 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1897, i64 %v1898) nomerge, !dbg !122
  br label %bb_rcslotdone179
bb_rcslotowner179:
  %v1899 = load i64, ptr %slot33, align 8
  store i64 %v1899, ptr %slot137, align 8
  %v1900 = load i64, ptr %slot137, align 8
  %v1901 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1900, i64 %v1901) nomerge, !dbg !122
  br label %bb_rcslotdone179
bb_rcslotdone179:
  br label %bb_i43
bb_rcarmnext165:
  %v1902 = load i64, ptr %slot77, align 8
  %cmp1903 = icmp eq i64 %v1902, 8
  %cv1904 = zext i1 %cmp1903 to i64
  store i64 %cv1904, ptr %slot138, align 8
  %v1905 = load i64, ptr %slot138, align 8
  %cond1906 = icmp ne i64 %v1905, 0
  br i1 %cond1906, label %bb_rcarm186, label %bb_rcarmnext186
bb_rcarm186:
  %v1907 = load i64, ptr %slot15, align 8
  store i64 %v1907, ptr %slot139, align 8
  %v1908 = load i64, ptr %slot76, align 8
  %op1909 = add i64 %v1908, 8
  store i64 %op1909, ptr %slot140, align 8
  %v1910 = load i64, ptr %slot34, align 8
  store i64 %v1910, ptr %slot141, align 8
  %v1911 = load i64, ptr %slot140, align 8
  %v1912 = load i64, ptr %slot139, align 8
  %p1913 = inttoptr i64 %v1911 to ptr
  %p1914 = inttoptr i64 %v1912 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1914, ptr %p1913, i64 24, i1 false), !alias.scope !10000000
  %v1915 = load i64, ptr %slot10, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  store i32 0, ptr %p1916, align 4, !alias.scope !3, !noalias !4
  %v1917 = load i64, ptr %slot9, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i32 1, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot139, align 8
  %v1920 = load i64, ptr %slot24, align 8
  %p1921 = inttoptr i64 %v1919 to ptr
  %p1922 = inttoptr i64 %v1920 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1922, ptr %p1921, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot9, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i32 0, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot5, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i32, ptr %p1926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1927, ptr %slot142, align 8
  %v1928 = load i32, ptr %slot142, align 8
  %cv1929 = zext i32 %v1928 to i64
  %cond1930 = icmp ne i64 %cv1929, 0
  br i1 %cond1930, label %bb_rcslotdrop195, label %bb_rcslotdone195
bb_rcslotdrop195:
  %v1931 = load i64, ptr %slot5, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i32 0, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot11, align 8
  store i64 %v1933, ptr %slot143, align 8
  %v1934 = load i64, ptr %slot6, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  %ld1936 = load i32, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1936, ptr %slot144, align 8
  %v1937 = load i32, ptr %slot144, align 8
  %op1938 = and i32 %v1937, 28
  store i32 %op1938, ptr %slot145, align 8
  %v1939 = load i32, ptr %slot145, align 8
  %cv1940 = zext i32 %v1939 to i64
  %cond1941 = icmp ne i64 %cv1940, 0
  br i1 %cond1941, label %bb_rcslotrole195, label %bb_rcslotowner195
bb_rcslotrole195:
  %v1942 = load i64, ptr %slot33, align 8
  store i64 %v1942, ptr %slot146, align 8
  %v1943 = load i64, ptr %slot146, align 8
  %v1944 = load i64, ptr %slot143, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1943, i64 %v1944) nomerge, !dbg !122
  br label %bb_rcslotdone195
bb_rcslotowner195:
  %v1945 = load i64, ptr %slot33, align 8
  store i64 %v1945, ptr %slot147, align 8
  %v1946 = load i64, ptr %slot147, align 8
  %v1947 = load i64, ptr %slot143, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1946, i64 %v1947) nomerge, !dbg !122
  br label %bb_rcslotdone195
bb_rcslotdone195:
  br label %bb_i56
bb_rcarmnext186:
  %v1948 = load i64, ptr %slot77, align 8
  %cmp1949 = icmp eq i64 %v1948, 9
  %cv1950 = zext i1 %cmp1949 to i64
  store i64 %cv1950, ptr %slot148, align 8
  %v1951 = load i64, ptr %slot148, align 8
  %cond1952 = icmp ne i64 %v1951, 0
  br i1 %cond1952, label %bb_rcarm202, label %bb_rcarmnext202
bb_rcarm202:
  %v1953 = load i64, ptr %slot5, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %ld1955 = load i32, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1955, ptr %slot149, align 8
  %v1956 = load i32, ptr %slot149, align 8
  %cv1957 = zext i32 %v1956 to i64
  %cond1958 = icmp ne i64 %cv1957, 0
  br i1 %cond1958, label %bb_rcslotdrop205, label %bb_rcslotdone205
bb_rcslotdrop205:
  %v1959 = load i64, ptr %slot5, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  store i32 0, ptr %p1960, align 4, !alias.scope !3, !noalias !4
  %v1961 = load i64, ptr %slot11, align 8
  store i64 %v1961, ptr %slot150, align 8
  %v1962 = load i64, ptr %slot6, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  %ld1964 = load i32, ptr %p1963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1964, ptr %slot151, align 8
  %v1965 = load i32, ptr %slot151, align 8
  %op1966 = and i32 %v1965, 28
  store i32 %op1966, ptr %slot152, align 8
  %v1967 = load i32, ptr %slot152, align 8
  %cv1968 = zext i32 %v1967 to i64
  %cond1969 = icmp ne i64 %cv1968, 0
  br i1 %cond1969, label %bb_rcslotrole205, label %bb_rcslotowner205
bb_rcslotrole205:
  %v1970 = load i64, ptr %slot33, align 8
  store i64 %v1970, ptr %slot153, align 8
  %v1971 = load i64, ptr %slot153, align 8
  %v1972 = load i64, ptr %slot150, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1971, i64 %v1972) nomerge, !dbg !122
  br label %bb_rcslotdone205
bb_rcslotowner205:
  %v1973 = load i64, ptr %slot33, align 8
  store i64 %v1973, ptr %slot154, align 8
  %v1974 = load i64, ptr %slot154, align 8
  %v1975 = load i64, ptr %slot150, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1974, i64 %v1975) nomerge, !dbg !122
  br label %bb_rcslotdone205
bb_rcslotdone205:
  br label %bb_i61
bb_rcarmnext202:
  %v1976 = load i64, ptr %slot77, align 8
  %cmp1977 = icmp eq i64 %v1976, 10
  %cv1978 = zext i1 %cmp1977 to i64
  store i64 %cv1978, ptr %slot155, align 8
  %v1979 = load i64, ptr %slot155, align 8
  %cond1980 = icmp ne i64 %v1979, 0
  br i1 %cond1980, label %bb_rcarm212, label %bb_rcarmnext212
bb_rcarm212:
  %v1981 = load i64, ptr %slot15, align 8
  store i64 %v1981, ptr %slot156, align 8
  %v1982 = load i64, ptr %slot76, align 8
  %op1983 = add i64 %v1982, 8
  store i64 %op1983, ptr %slot157, align 8
  %v1984 = load i64, ptr %slot34, align 8
  store i64 %v1984, ptr %slot158, align 8
  %v1985 = load i64, ptr %slot157, align 8
  %v1986 = load i64, ptr %slot156, align 8
  %p1987 = inttoptr i64 %v1985 to ptr
  %p1988 = inttoptr i64 %v1986 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1988, ptr %p1987, i64 32, i1 false), !alias.scope !10000000
  %v1989 = load i64, ptr %slot10, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i32 0, ptr %p1990, align 4, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot9, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i32 1, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot156, align 8
  %v1994 = load i64, ptr %slot25, align 8
  %p1995 = inttoptr i64 %v1993 to ptr
  %p1996 = inttoptr i64 %v1994 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1996, ptr %p1995, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot9, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i32 0, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  %v1999 = load i64, ptr %slot5, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %ld2001 = load i32, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2001, ptr %slot159, align 8
  %v2002 = load i32, ptr %slot159, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcslotdrop221, label %bb_rcslotdone221
bb_rcslotdrop221:
  %v2005 = load i64, ptr %slot5, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i32 0, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot11, align 8
  store i64 %v2007, ptr %slot160, align 8
  %v2008 = load i64, ptr %slot6, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i32, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2010, ptr %slot161, align 8
  %v2011 = load i32, ptr %slot161, align 8
  %op2012 = and i32 %v2011, 28
  store i32 %op2012, ptr %slot162, align 8
  %v2013 = load i32, ptr %slot162, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcslotrole221, label %bb_rcslotowner221
bb_rcslotrole221:
  %v2016 = load i64, ptr %slot33, align 8
  store i64 %v2016, ptr %slot163, align 8
  %v2017 = load i64, ptr %slot163, align 8
  %v2018 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2017, i64 %v2018) nomerge, !dbg !122
  br label %bb_rcslotdone221
bb_rcslotowner221:
  %v2019 = load i64, ptr %slot33, align 8
  store i64 %v2019, ptr %slot164, align 8
  %v2020 = load i64, ptr %slot164, align 8
  %v2021 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2020, i64 %v2021) nomerge, !dbg !122
  br label %bb_rcslotdone221
bb_rcslotdone221:
  br label %bb_i63
bb_rcarmnext212:
  br label %bb_failure
bb_i17:
  %v2022 = load i64, ptr %slot20, align 8
  %v2023 = load i64, ptr %slot26, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 %v2022, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot26, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i64, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2027, ptr %slot165, align 8
  %v2028 = load i64, ptr %slot165, align 8
  %op2029 = add i64 %v2028, 0
  store i64 %op2029, ptr %slot166, align 8
  %v2030 = load i64, ptr %slot166, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i64, ptr %p2031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2032, ptr %slot167, align 8
  %v2033 = load i64, ptr %slot167, align 8
  %v2034 = load i64, ptr %slot26, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  store i64 %v2033, ptr %p2035, align 8, !alias.scope !3, !noalias !4
  %v2036 = load i64, ptr %slot5, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %ld2038 = load i32, ptr %p2037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2038, ptr %slot168, align 8
  %v2039 = load i32, ptr %slot168, align 8
  %cv2040 = zext i32 %v2039 to i64
  %cond2041 = icmp ne i64 %cv2040, 0
  br i1 %cond2041, label %bb_rcslotdrop233, label %bb_rcslotdone233
bb_rcslotdrop233:
  %v2042 = load i64, ptr %slot5, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  store i32 0, ptr %p2043, align 4, !alias.scope !3, !noalias !4
  %v2044 = load i64, ptr %slot11, align 8
  store i64 %v2044, ptr %slot169, align 8
  %v2045 = load i64, ptr %slot6, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  %ld2047 = load i32, ptr %p2046, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2047, ptr %slot170, align 8
  %v2048 = load i32, ptr %slot170, align 8
  %op2049 = and i32 %v2048, 28
  store i32 %op2049, ptr %slot171, align 8
  %v2050 = load i32, ptr %slot171, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcslotrole233, label %bb_rcslotowner233
bb_rcslotrole233:
  %v2053 = load i64, ptr %slot33, align 8
  store i64 %v2053, ptr %slot172, align 8
  %v2054 = load i64, ptr %slot172, align 8
  %v2055 = load i64, ptr %slot169, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64 %v2054, i64 %v2055) nomerge, !dbg !124
  br label %bb_rcslotdone233
bb_rcslotowner233:
  %v2056 = load i64, ptr %slot33, align 8
  store i64 %v2056, ptr %slot173, align 8
  %v2057 = load i64, ptr %slot173, align 8
  %v2058 = load i64, ptr %slot169, align 8
  call void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64 %v2057, i64 %v2058) nomerge, !dbg !124
  br label %bb_rcslotdone233
bb_rcslotdone233:
  %v2059 = load i64, ptr %slot26, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  %ld2061 = load i64, ptr %p2060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2061, ptr %slot174, align 8
  %v2062 = load i64, ptr %slot26, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2064, ptr %slot175, align 8
  %v2065 = load i64, ptr %slot175, align 8
  %v2066 = load i64, ptr %slot13, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i64 %v2065, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot13, align 8
  store i64 %v2068, ptr %slot176, align 8
  %v2069 = load i64, ptr %slot5, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  %ld2071 = load i32, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2071, ptr %slot177, align 8
  %v2072 = load i64, ptr %slot6, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %ld2074 = load i32, ptr %p2073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2074, ptr %slot178, align 8
  %v2075 = load i32, ptr %slot178, align 8
  %op2076 = and i32 %v2075, 24
  store i32 %op2076, ptr %slot178, align 8
  %v2077 = load i32, ptr %slot178, align 8
  %cmp2078 = icmp eq i32 %v2077, 0
  %cv2079 = zext i1 %cmp2078 to i32
  store i32 %cv2079, ptr %slot179, align 8
  %v2080 = load i32, ptr %slot177, align 8
  %v2081 = load i32, ptr %slot179, align 8
  %op2082 = and i32 %v2080, %v2081
  store i32 %op2082, ptr %slot180, align 8
  %v2083 = load i32, ptr %slot180, align 8
  %cv2084 = zext i32 %v2083 to i64
  %cond2085 = icmp ne i64 %cv2084, 0
  br i1 %cond2085, label %bb_rctake243, label %bb_rccopy243
bb_rctake243:
  %v2086 = load i64, ptr %slot15, align 8
  store i64 %v2086, ptr %slot181, align 8
  %v2087 = load i64, ptr %slot34, align 8
  store i64 %v2087, ptr %slot182, align 8
  %v2088 = load i64, ptr %slot176, align 8
  %v2089 = load i64, ptr %slot181, align 8
  %op2090 = sub i64 %v2088, %v2089
  store i64 %op2090, ptr %slot183, align 8
  %v2091 = load i64, ptr %slot181, align 8
  %v2092 = load i64, ptr %slot176, align 8
  %op2093 = sub i64 %v2091, %v2092
  store i64 %op2093, ptr %slot184, align 8
  %v2094 = load i64, ptr %slot183, align 8
  %cmp2095 = icmp ult i64 %v2094, 8
  %cv2096 = zext i1 %cmp2095 to i32
  store i32 %cv2096, ptr %slot185, align 8
  %v2097 = load i64, ptr %slot184, align 8
  %cmp2098 = icmp ult i64 %v2097, 8
  %cv2099 = zext i1 %cmp2098 to i32
  store i32 %cv2099, ptr %slot186, align 8
  %v2100 = load i32, ptr %slot185, align 8
  %v2101 = load i32, ptr %slot186, align 8
  %op2102 = or i32 %v2100, %v2101
  store i32 %op2102, ptr %slot187, align 8
  %v2103 = load i32, ptr %slot187, align 8
  %cv2104 = zext i32 %v2103 to i64
  %cond2105 = icmp ne i64 %cv2104, 0
  br i1 %cond2105, label %bb_rcmoveslow252, label %bb_rcmovecheck252
bb_rcmovecheck252:
  %v2106 = load i64, ptr %slot176, align 8
  %p2108 = inttoptr i64 %v2106 to ptr
  %gep2109 = getelementptr i8, ptr %p2108, i64 0
  %op2107 = ptrtoint ptr %gep2109 to i64
  store i64 %op2107, ptr %slot188, align 8
  %v2110 = load i64, ptr %slot188, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i64, ptr %p2111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2112, ptr %slot189, align 8
  %v2113 = load i64, ptr %slot189, align 8
  %cmp2114 = icmp ne i64 %v2113, 0
  %cv2115 = zext i1 %cmp2114 to i32
  store i32 %cv2115, ptr %slot190, align 8
  %v2116 = load i32, ptr %slot190, align 8
  %cv2117 = zext i32 %v2116 to i64
  %cond2118 = icmp ne i64 %cv2117, 0
  br i1 %cond2118, label %bb_rcmoveheader260, label %bb_rcmovenext260
bb_rcmoveheader260:
  %v2119 = load i64, ptr %slot189, align 8
  %op2120 = sub i64 %v2119, 16
  store i64 %op2120, ptr %slot191, align 8
  %v2121 = load i64, ptr %slot189, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  %rgep2123 = getelementptr i8, ptr %p2122, i64 -16
  %ld2124 = load i64, ptr %rgep2123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2124, ptr %slot192, align 8
  %v2125 = load i64, ptr %slot192, align 8
  %op2126 = and i64 %v2125, 5764607523034234881
  store i64 %op2126, ptr %slot193, align 8
  %v2127 = load i64, ptr %slot193, align 8
  %cmp2128 = icmp ne i64 %v2127, 0
  %cv2129 = zext i1 %cmp2128 to i32
  store i32 %cv2129, ptr %slot194, align 8
  %v2130 = load i32, ptr %slot194, align 8
  %cv2131 = zext i32 %v2130 to i64
  %cond2132 = icmp ne i64 %cv2131, 0
  br i1 %cond2132, label %bb_rcmoveslow252, label %bb_rcmovenext260
bb_rcmovenext260:
  %v2133 = load i64, ptr %slot176, align 8
  %v2134 = load i64, ptr %slot181, align 8
  %p2135 = inttoptr i64 %v2133 to ptr
  %p2136 = inttoptr i64 %v2134 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2136, ptr %p2135, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot176, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  store i64 0, ptr %p2138, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved252
bb_rcmoveslow252:
  %v2139 = load i64, ptr %slot33, align 8
  %v2140 = load i64, ptr %slot181, align 8
  %v2141 = load i64, ptr %slot176, align 8
  %v2142 = load i64, ptr %slot182, align 8
  %cv2143 = trunc i64 %v2142 to i32
  %call2144 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2139, i64 %v2140, i64 %v2141, i32 %cv2143) nomerge, !dbg !126
  store i32 %call2144, ptr %slot195, align 8
  %v2145 = load i32, ptr %slot195, align 8
  %cv2146 = zext i32 %v2145 to i64
  %cond2147 = icmp ne i64 %cv2146, 0
  br i1 %cond2147, label %bb_rcsuccess267, label %bb_rcfailure267
bb_rcfailure267:
  %v2148 = load i64, ptr %slot33, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  %call2150 = call i32 @myl_rc_take_failure(ptr %p2149) nomerge, !dbg !126
  store i32 %call2150, ptr %slot196, align 8
  %v2151 = load i64, ptr %slot1, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %v2153 = load i32, ptr %slot196, align 8
  %call2154 = call i32 @myl_qbe_rc_status(ptr %p2152, i32 %v2153) nomerge, !dbg !126
  store i32 %call2154, ptr %slot197, align 8
  br label %bb_failure
bb_rcsuccess267:
  br label %bb_rcmoved252
bb_rcmoved252:
  %v2155 = load i64, ptr %slot5, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  store i32 0, ptr %p2156, align 4, !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot10, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i32 2, ptr %p2158, align 4, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot9, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  store i32 1, ptr %p2160, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared243
bb_rccopy243:
  %v2161 = load i64, ptr %slot15, align 8
  store i64 %v2161, ptr %slot198, align 8
  %v2162 = load i64, ptr %slot34, align 8
  store i64 %v2162, ptr %slot199, align 8
  %v2163 = load i64, ptr %slot176, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %ld2165 = load i64, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2165, ptr %slot200, align 8
  %v2166 = load i64, ptr %slot200, align 8
  %cmp2167 = icmp ne i64 %v2166, 0
  %cv2168 = zext i1 %cmp2167 to i32
  store i32 %cv2168, ptr %slot201, align 8
  %v2169 = load i32, ptr %slot201, align 8
  %cv2170 = zext i32 %v2169 to i64
  %cond2171 = icmp ne i64 %cv2170, 0
  br i1 %cond2171, label %bb_rcgnn276, label %bb_rcgplain276
bb_rcgnn276:
  %v2172 = load i64, ptr %slot200, align 8
  %op2173 = sub i64 %v2172, 16
  store i64 %op2173, ptr %slot202, align 8
  %v2174 = load i64, ptr %slot200, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %rgep2176 = getelementptr i8, ptr %p2175, i64 -16
  %ld2177 = load i64, ptr %rgep2176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2177, ptr %slot203, align 8
  %v2178 = load i64, ptr %slot203, align 8
  %op2179 = and i64 %v2178, 4611686018427387906
  store i64 %op2179, ptr %slot204, align 8
  %v2180 = load i64, ptr %slot204, align 8
  %cmp2181 = icmp ne i64 %v2180, 0
  %cv2182 = zext i1 %cmp2181 to i32
  store i32 %cv2182, ptr %slot205, align 8
  %v2183 = load i32, ptr %slot205, align 8
  %cv2184 = zext i32 %v2183 to i64
  %cond2185 = icmp ne i64 %cv2184, 0
  br i1 %cond2185, label %bb_rcgspecial276, label %bb_rcginc276
bb_rcginc276:
  %v2186 = load i64, ptr %slot200, align 8
  %op2187 = sub i64 %v2186, 32
  store i64 %op2187, ptr %slot206, align 8
  %v2188 = load i64, ptr %slot200, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  %rgep2190 = getelementptr i8, ptr %p2189, i64 -32
  %ld2191 = load i64, ptr %rgep2190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2191, ptr %slot207, align 8
  %v2192 = load i64, ptr %slot207, align 8
  %op2193 = add i64 %v2192, 1
  store i64 %op2193, ptr %slot208, align 8
  %v2194 = load i64, ptr %slot208, align 8
  %cmp2195 = icmp eq i64 %v2194, 0
  %cv2196 = zext i1 %cmp2195 to i32
  store i32 %cv2196, ptr %slot209, align 8
  %v2197 = load i32, ptr %slot209, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rcglimit276, label %bb_rcgcapacity276
bb_rcglimit276:
  %v2200 = load i64, ptr %slot1, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %call2202 = call i32 @myl_qbe_rc_status(ptr %p2201, i32 2) nomerge, !dbg !126
  store i32 %call2202, ptr %slot210, align 8
  br label %bb_failure
bb_rcgcapacity276:
  %v2203 = load i64, ptr %slot208, align 8
  %v2204 = load i64, ptr %slot200, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %rgep2206 = getelementptr i8, ptr %p2205, i64 -32
  store i64 %v2203, ptr %rgep2206, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain276
bb_rcgspecial276:
  %v2207 = load i64, ptr %slot203, align 8
  %op2208 = and i64 %v2207, 4611686018427387904
  store i64 %op2208, ptr %slot211, align 8
  %v2209 = load i64, ptr %slot211, align 8
  %cmp2210 = icmp ne i64 %v2209, 0
  %cv2211 = zext i1 %cmp2210 to i32
  store i32 %cv2211, ptr %slot212, align 8
  %v2212 = load i32, ptr %slot212, align 8
  %cv2213 = zext i32 %v2212 to i64
  %cond2214 = icmp ne i64 %cv2213, 0
  br i1 %cond2214, label %bb_rcgslow276, label %bb_rcgplain276
bb_rcgslow276:
  %v2215 = load i64, ptr %slot33, align 8
  %v2216 = load i64, ptr %slot198, align 8
  %v2217 = load i64, ptr %slot176, align 8
  %v2218 = load i64, ptr %slot199, align 8
  %cv2219 = trunc i64 %v2218 to i32
  %call2220 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2215, i64 %v2216, i64 %v2217, i32 %cv2219) nomerge, !dbg !126
  store i32 %call2220, ptr %slot213, align 8
  %v2221 = load i32, ptr %slot213, align 8
  %cv2222 = zext i32 %v2221 to i64
  %cond2223 = icmp ne i64 %cv2222, 0
  br i1 %cond2223, label %bb_rcsuccess290, label %bb_rcfailure290
bb_rcfailure290:
  %v2224 = load i64, ptr %slot33, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %call2226 = call i32 @myl_rc_take_failure(ptr %p2225) nomerge, !dbg !126
  store i32 %call2226, ptr %slot214, align 8
  %v2227 = load i64, ptr %slot1, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %v2229 = load i32, ptr %slot214, align 8
  %call2230 = call i32 @myl_qbe_rc_status(ptr %p2228, i32 %v2229) nomerge, !dbg !126
  store i32 %call2230, ptr %slot215, align 8
  br label %bb_failure
bb_rcsuccess290:
  br label %bb_rcgdone276
bb_rcgplain276:
  %v2231 = load i64, ptr %slot200, align 8
  %v2232 = load i64, ptr %slot198, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  store i64 %v2231, ptr %p2233, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone276
bb_rcgdone276:
  %v2234 = load i64, ptr %slot10, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i32 2, ptr %p2235, align 4, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot9, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  store i32 1, ptr %p2237, align 4, !alias.scope !3, !noalias !4
  %v2238 = load i64, ptr %slot5, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %ld2240 = load i32, ptr %p2239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2240, ptr %slot216, align 8
  %v2241 = load i32, ptr %slot216, align 8
  %cv2242 = zext i32 %v2241 to i64
  %cond2243 = icmp ne i64 %cv2242, 0
  br i1 %cond2243, label %bb_rcslotdrop297, label %bb_rcslotdone297
bb_rcslotdrop297:
  %v2244 = load i64, ptr %slot5, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  store i32 0, ptr %p2245, align 4, !alias.scope !3, !noalias !4
  %v2246 = load i64, ptr %slot11, align 8
  store i64 %v2246, ptr %slot217, align 8
  %v2247 = load i64, ptr %slot6, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i32, ptr %p2248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2249, ptr %slot218, align 8
  %v2250 = load i32, ptr %slot218, align 8
  %op2251 = and i32 %v2250, 28
  store i32 %op2251, ptr %slot219, align 8
  %v2252 = load i32, ptr %slot219, align 8
  %cv2253 = zext i32 %v2252 to i64
  %cond2254 = icmp ne i64 %cv2253, 0
  br i1 %cond2254, label %bb_rcslotrole297, label %bb_rcslotowner297
bb_rcslotrole297:
  %v2255 = load i64, ptr %slot33, align 8
  store i64 %v2255, ptr %slot220, align 8
  %v2256 = load i64, ptr %slot217, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %ld2258 = load i64, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2258, ptr %slot221, align 8
  %v2259 = load i64, ptr %slot221, align 8
  %cmp2260 = icmp ne i64 %v2259, 0
  %cv2261 = zext i1 %cmp2260 to i32
  store i32 %cv2261, ptr %slot222, align 8
  %v2262 = load i32, ptr %slot222, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcgnn313, label %bb_rcgdone313
bb_rcgnn313:
  %v2265 = load i64, ptr %slot221, align 8
  %op2266 = sub i64 %v2265, 16
  store i64 %op2266, ptr %slot223, align 8
  %v2267 = load i64, ptr %slot221, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %rgep2269 = getelementptr i8, ptr %p2268, i64 -16
  %ld2270 = load i64, ptr %rgep2269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2270, ptr %slot224, align 8
  %v2271 = load i64, ptr %slot224, align 8
  %op2272 = and i64 %v2271, 4611686018427387906
  store i64 %op2272, ptr %slot225, align 8
  %v2273 = load i64, ptr %slot225, align 8
  %cmp2274 = icmp ne i64 %v2273, 0
  %cv2275 = zext i1 %cmp2274 to i32
  store i32 %cv2275, ptr %slot226, align 8
  %v2276 = load i32, ptr %slot226, align 8
  %cv2277 = zext i32 %v2276 to i64
  %cond2278 = icmp ne i64 %cv2277, 0
  br i1 %cond2278, label %bb_rcgclear313, label %bb_rcgcounted313
bb_rcgcounted313:
  %v2279 = load i64, ptr %slot221, align 8
  %op2280 = sub i64 %v2279, 24
  store i64 %op2280, ptr %slot227, align 8
  %v2281 = load i64, ptr %slot221, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %rgep2283 = getelementptr i8, ptr %p2282, i64 -24
  %ld2284 = load i64, ptr %rgep2283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2284, ptr %slot228, align 8
  %v2285 = load i64, ptr %slot228, align 8
  %op2286 = sub i64 %v2285, 1
  store i64 %op2286, ptr %slot229, align 8
  %v2287 = load i64, ptr %slot229, align 8
  %cmp2288 = icmp eq i64 %v2287, 0
  %cv2289 = zext i1 %cmp2288 to i32
  store i32 %cv2289, ptr %slot230, align 8
  %v2290 = load i32, ptr %slot230, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcglast313, label %bb_rcgdec313
bb_rcglast313:
  %v2293 = load i64, ptr %slot221, align 8
  %op2294 = sub i64 %v2293, 32
  store i64 %op2294, ptr %slot231, align 8
  %v2295 = load i64, ptr %slot221, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  %rgep2297 = getelementptr i8, ptr %p2296, i64 -32
  %ld2298 = load i64, ptr %rgep2297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2298, ptr %slot232, align 8
  %v2299 = load i64, ptr %slot232, align 8
  %cmp2300 = icmp ne i64 %v2299, 0
  %cv2301 = zext i1 %cmp2300 to i32
  store i32 %cv2301, ptr %slot233, align 8
  %v2302 = load i32, ptr %slot233, align 8
  %cv2303 = zext i32 %v2302 to i64
  %cond2304 = icmp ne i64 %cv2303, 0
  br i1 %cond2304, label %bb_rcgdec313, label %bb_rcgslow313
bb_rcgslow313:
  %v2305 = load i64, ptr %slot220, align 8
  %v2306 = load i64, ptr %slot217, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2305, i64 %v2306) nomerge, !dbg !126
  br label %bb_rcgdone313
bb_rcgdec313:
  %v2307 = load i64, ptr %slot229, align 8
  %v2308 = load i64, ptr %slot221, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %rgep2310 = getelementptr i8, ptr %p2309, i64 -24
  store i64 %v2307, ptr %rgep2310, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear313
bb_rcgclear313:
  %v2311 = load i64, ptr %slot217, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  store i64 0, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone313
bb_rcgdone313:
  br label %bb_rcslotdone297
bb_rcslotowner297:
  %v2313 = load i64, ptr %slot33, align 8
  store i64 %v2313, ptr %slot234, align 8
  %v2314 = load i64, ptr %slot217, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %ld2316 = load i64, ptr %p2315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2316, ptr %slot235, align 8
  %v2317 = load i64, ptr %slot235, align 8
  %cmp2318 = icmp ne i64 %v2317, 0
  %cv2319 = zext i1 %cmp2318 to i32
  store i32 %cv2319, ptr %slot236, align 8
  %v2320 = load i32, ptr %slot236, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcgnn328, label %bb_rcgdone328
bb_rcgnn328:
  %v2323 = load i64, ptr %slot235, align 8
  %op2324 = sub i64 %v2323, 16
  store i64 %op2324, ptr %slot237, align 8
  %v2325 = load i64, ptr %slot235, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %rgep2327 = getelementptr i8, ptr %p2326, i64 -16
  %ld2328 = load i64, ptr %rgep2327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2328, ptr %slot238, align 8
  %v2329 = load i64, ptr %slot238, align 8
  %op2330 = and i64 %v2329, 4611686018427387906
  store i64 %op2330, ptr %slot239, align 8
  %v2331 = load i64, ptr %slot239, align 8
  %cmp2332 = icmp ne i64 %v2331, 0
  %cv2333 = zext i1 %cmp2332 to i32
  store i32 %cv2333, ptr %slot240, align 8
  %v2334 = load i32, ptr %slot240, align 8
  %cv2335 = zext i32 %v2334 to i64
  %cond2336 = icmp ne i64 %cv2335, 0
  br i1 %cond2336, label %bb_rcgclear328, label %bb_rcgcounted328
bb_rcgcounted328:
  %v2337 = load i64, ptr %slot235, align 8
  %op2338 = sub i64 %v2337, 32
  store i64 %op2338, ptr %slot241, align 8
  %v2339 = load i64, ptr %slot235, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %rgep2341 = getelementptr i8, ptr %p2340, i64 -32
  %ld2342 = load i64, ptr %rgep2341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2342, ptr %slot242, align 8
  %v2343 = load i64, ptr %slot242, align 8
  %op2344 = sub i64 %v2343, 1
  store i64 %op2344, ptr %slot243, align 8
  %v2345 = load i64, ptr %slot243, align 8
  %cmp2346 = icmp eq i64 %v2345, 0
  %cv2347 = zext i1 %cmp2346 to i32
  store i32 %cv2347, ptr %slot244, align 8
  %v2348 = load i32, ptr %slot244, align 8
  %cv2349 = zext i32 %v2348 to i64
  %cond2350 = icmp ne i64 %cv2349, 0
  br i1 %cond2350, label %bb_rcglast328, label %bb_rcgdec328
bb_rcglast328:
  %v2351 = load i64, ptr %slot235, align 8
  %op2352 = sub i64 %v2351, 24
  store i64 %op2352, ptr %slot245, align 8
  %v2353 = load i64, ptr %slot235, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %rgep2355 = getelementptr i8, ptr %p2354, i64 -24
  %ld2356 = load i64, ptr %rgep2355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2356, ptr %slot246, align 8
  %v2357 = load i64, ptr %slot246, align 8
  %cmp2358 = icmp ne i64 %v2357, 0
  %cv2359 = zext i1 %cmp2358 to i32
  store i32 %cv2359, ptr %slot247, align 8
  %v2360 = load i32, ptr %slot247, align 8
  %cv2361 = zext i32 %v2360 to i64
  %cond2362 = icmp ne i64 %cv2361, 0
  br i1 %cond2362, label %bb_rcgdec328, label %bb_rcgslow328
bb_rcgslow328:
  %v2363 = load i64, ptr %slot234, align 8
  %v2364 = load i64, ptr %slot217, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2363, i64 %v2364) nomerge, !dbg !126
  br label %bb_rcgdone328
bb_rcgdec328:
  %v2365 = load i64, ptr %slot243, align 8
  %v2366 = load i64, ptr %slot235, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %rgep2368 = getelementptr i8, ptr %p2367, i64 -32
  store i64 %v2365, ptr %rgep2368, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear328
bb_rcgclear328:
  %v2369 = load i64, ptr %slot217, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  store i64 0, ptr %p2370, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone328
bb_rcgdone328:
  br label %bb_rcslotdone297
bb_rcslotdone297:
  br label %bb_rcprepared243
bb_rcprepared243:
  %v2371 = load i64, ptr %slot15, align 8
  store i64 %v2371, ptr %slot248, align 8
  %v2372 = load i64, ptr %slot248, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %ld2374 = load i64, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2374, ptr %slot249, align 8
  %v2375 = load i64, ptr %slot9, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  store i32 0, ptr %p2376, align 4, !alias.scope !3, !noalias !4
  %v2377 = load i64, ptr %slot5, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  %ld2379 = load i32, ptr %p2378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2379, ptr %slot250, align 8
  %v2380 = load i32, ptr %slot250, align 8
  %cv2381 = zext i32 %v2380 to i64
  %cond2382 = icmp ne i64 %cv2381, 0
  br i1 %cond2382, label %bb_rcslotdrop337, label %bb_rcslotdone337
bb_rcslotdrop337:
  %v2383 = load i64, ptr %slot5, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  store i32 0, ptr %p2384, align 4, !alias.scope !3, !noalias !4
  %v2385 = load i64, ptr %slot11, align 8
  store i64 %v2385, ptr %slot251, align 8
  %v2386 = load i64, ptr %slot6, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %ld2388 = load i32, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2388, ptr %slot252, align 8
  %v2389 = load i32, ptr %slot252, align 8
  %op2390 = and i32 %v2389, 28
  store i32 %op2390, ptr %slot253, align 8
  %v2391 = load i32, ptr %slot253, align 8
  %cv2392 = zext i32 %v2391 to i64
  %cond2393 = icmp ne i64 %cv2392, 0
  br i1 %cond2393, label %bb_rcslotrole337, label %bb_rcslotowner337
bb_rcslotrole337:
  %v2394 = load i64, ptr %slot33, align 8
  store i64 %v2394, ptr %slot254, align 8
  %v2395 = load i64, ptr %slot251, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  %ld2397 = load i64, ptr %p2396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2397, ptr %slot255, align 8
  %v2398 = load i64, ptr %slot255, align 8
  %cmp2399 = icmp ne i64 %v2398, 0
  %cv2400 = zext i1 %cmp2399 to i32
  store i32 %cv2400, ptr %slot256, align 8
  %v2401 = load i32, ptr %slot256, align 8
  %cv2402 = zext i32 %v2401 to i64
  %cond2403 = icmp ne i64 %cv2402, 0
  br i1 %cond2403, label %bb_rcgnn353, label %bb_rcgdone353
bb_rcgnn353:
  %v2404 = load i64, ptr %slot255, align 8
  %op2405 = sub i64 %v2404, 16
  store i64 %op2405, ptr %slot257, align 8
  %v2406 = load i64, ptr %slot255, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  %rgep2408 = getelementptr i8, ptr %p2407, i64 -16
  %ld2409 = load i64, ptr %rgep2408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2409, ptr %slot258, align 8
  %v2410 = load i64, ptr %slot258, align 8
  %op2411 = and i64 %v2410, 4611686018427387906
  store i64 %op2411, ptr %slot259, align 8
  %v2412 = load i64, ptr %slot259, align 8
  %cmp2413 = icmp ne i64 %v2412, 0
  %cv2414 = zext i1 %cmp2413 to i32
  store i32 %cv2414, ptr %slot260, align 8
  %v2415 = load i32, ptr %slot260, align 8
  %cv2416 = zext i32 %v2415 to i64
  %cond2417 = icmp ne i64 %cv2416, 0
  br i1 %cond2417, label %bb_rcgclear353, label %bb_rcgcounted353
bb_rcgcounted353:
  %v2418 = load i64, ptr %slot255, align 8
  %op2419 = sub i64 %v2418, 24
  store i64 %op2419, ptr %slot261, align 8
  %v2420 = load i64, ptr %slot255, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %rgep2422 = getelementptr i8, ptr %p2421, i64 -24
  %ld2423 = load i64, ptr %rgep2422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2423, ptr %slot262, align 8
  %v2424 = load i64, ptr %slot262, align 8
  %op2425 = sub i64 %v2424, 1
  store i64 %op2425, ptr %slot263, align 8
  %v2426 = load i64, ptr %slot263, align 8
  %cmp2427 = icmp eq i64 %v2426, 0
  %cv2428 = zext i1 %cmp2427 to i32
  store i32 %cv2428, ptr %slot264, align 8
  %v2429 = load i32, ptr %slot264, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcglast353, label %bb_rcgdec353
bb_rcglast353:
  %v2432 = load i64, ptr %slot255, align 8
  %op2433 = sub i64 %v2432, 32
  store i64 %op2433, ptr %slot265, align 8
  %v2434 = load i64, ptr %slot255, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %rgep2436 = getelementptr i8, ptr %p2435, i64 -32
  %ld2437 = load i64, ptr %rgep2436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2437, ptr %slot266, align 8
  %v2438 = load i64, ptr %slot266, align 8
  %cmp2439 = icmp ne i64 %v2438, 0
  %cv2440 = zext i1 %cmp2439 to i32
  store i32 %cv2440, ptr %slot267, align 8
  %v2441 = load i32, ptr %slot267, align 8
  %cv2442 = zext i32 %v2441 to i64
  %cond2443 = icmp ne i64 %cv2442, 0
  br i1 %cond2443, label %bb_rcgdec353, label %bb_rcgslow353
bb_rcgslow353:
  %v2444 = load i64, ptr %slot254, align 8
  %v2445 = load i64, ptr %slot251, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2444, i64 %v2445) nomerge, !dbg !126
  br label %bb_rcgdone353
bb_rcgdec353:
  %v2446 = load i64, ptr %slot263, align 8
  %v2447 = load i64, ptr %slot255, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  %rgep2449 = getelementptr i8, ptr %p2448, i64 -24
  store i64 %v2446, ptr %rgep2449, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear353
bb_rcgclear353:
  %v2450 = load i64, ptr %slot251, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  store i64 0, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone353
bb_rcgdone353:
  br label %bb_rcslotdone337
bb_rcslotowner337:
  %v2452 = load i64, ptr %slot33, align 8
  store i64 %v2452, ptr %slot268, align 8
  %v2453 = load i64, ptr %slot251, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2455, ptr %slot269, align 8
  %v2456 = load i64, ptr %slot269, align 8
  %cmp2457 = icmp ne i64 %v2456, 0
  %cv2458 = zext i1 %cmp2457 to i32
  store i32 %cv2458, ptr %slot270, align 8
  %v2459 = load i32, ptr %slot270, align 8
  %cv2460 = zext i32 %v2459 to i64
  %cond2461 = icmp ne i64 %cv2460, 0
  br i1 %cond2461, label %bb_rcgnn368, label %bb_rcgdone368
bb_rcgnn368:
  %v2462 = load i64, ptr %slot269, align 8
  %op2463 = sub i64 %v2462, 16
  store i64 %op2463, ptr %slot271, align 8
  %v2464 = load i64, ptr %slot269, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  %rgep2466 = getelementptr i8, ptr %p2465, i64 -16
  %ld2467 = load i64, ptr %rgep2466, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2467, ptr %slot272, align 8
  %v2468 = load i64, ptr %slot272, align 8
  %op2469 = and i64 %v2468, 4611686018427387906
  store i64 %op2469, ptr %slot273, align 8
  %v2470 = load i64, ptr %slot273, align 8
  %cmp2471 = icmp ne i64 %v2470, 0
  %cv2472 = zext i1 %cmp2471 to i32
  store i32 %cv2472, ptr %slot274, align 8
  %v2473 = load i32, ptr %slot274, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcgclear368, label %bb_rcgcounted368
bb_rcgcounted368:
  %v2476 = load i64, ptr %slot269, align 8
  %op2477 = sub i64 %v2476, 32
  store i64 %op2477, ptr %slot275, align 8
  %v2478 = load i64, ptr %slot269, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %rgep2480 = getelementptr i8, ptr %p2479, i64 -32
  %ld2481 = load i64, ptr %rgep2480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2481, ptr %slot276, align 8
  %v2482 = load i64, ptr %slot276, align 8
  %op2483 = sub i64 %v2482, 1
  store i64 %op2483, ptr %slot277, align 8
  %v2484 = load i64, ptr %slot277, align 8
  %cmp2485 = icmp eq i64 %v2484, 0
  %cv2486 = zext i1 %cmp2485 to i32
  store i32 %cv2486, ptr %slot278, align 8
  %v2487 = load i32, ptr %slot278, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcglast368, label %bb_rcgdec368
bb_rcglast368:
  %v2490 = load i64, ptr %slot269, align 8
  %op2491 = sub i64 %v2490, 24
  store i64 %op2491, ptr %slot279, align 8
  %v2492 = load i64, ptr %slot269, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %rgep2494 = getelementptr i8, ptr %p2493, i64 -24
  %ld2495 = load i64, ptr %rgep2494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2495, ptr %slot280, align 8
  %v2496 = load i64, ptr %slot280, align 8
  %cmp2497 = icmp ne i64 %v2496, 0
  %cv2498 = zext i1 %cmp2497 to i32
  store i32 %cv2498, ptr %slot281, align 8
  %v2499 = load i32, ptr %slot281, align 8
  %cv2500 = zext i32 %v2499 to i64
  %cond2501 = icmp ne i64 %cv2500, 0
  br i1 %cond2501, label %bb_rcgdec368, label %bb_rcgslow368
bb_rcgslow368:
  %v2502 = load i64, ptr %slot268, align 8
  %v2503 = load i64, ptr %slot251, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2502, i64 %v2503) nomerge, !dbg !126
  br label %bb_rcgdone368
bb_rcgdec368:
  %v2504 = load i64, ptr %slot277, align 8
  %v2505 = load i64, ptr %slot269, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -32
  store i64 %v2504, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear368
bb_rcgclear368:
  %v2508 = load i64, ptr %slot251, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  store i64 0, ptr %p2509, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone368
bb_rcgdone368:
  br label %bb_rcslotdone337
bb_rcslotdone337:
  %v2510 = load i64, ptr %slot249, align 8
  ret i64 %v2510
bb_i20:
  %v2511 = load i64, ptr %slot21, align 8
  %v2512 = load i64, ptr %slot26, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i64 %v2511, ptr %p2513, align 8, !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot16, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %ld2516 = load i64, ptr %p2515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2516, ptr %slot282, align 8
  %v2517 = load i64, ptr %slot282, align 8
  %v2518 = load i64, ptr %slot26, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  store i64 %v2517, ptr %p2519, align 8, !alias.scope !3, !noalias !4
  %v2520 = load i64, ptr %slot21, align 8
  %v2521 = load i64, ptr %slot27, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i64 %v2520, ptr %p2522, align 8, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot26, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  %ld2525 = load i64, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2525, ptr %slot283, align 8
  %v2526 = load i64, ptr %slot27, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %ld2528 = load i64, ptr %p2527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2528, ptr %slot284, align 8
  %v2529 = load i64, ptr %slot1, align 8
  %v2530 = load i64, ptr %slot283, align 8
  %v2531 = load i64, ptr %slot284, align 8
  %call2532 = call i64 @myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93(i64 %v2529, i64 %v2530, i64 %v2531) nomerge, !dbg !128
  store i64 %call2532, ptr %slot285, align 8
  %v2533 = load i64, ptr %slot285, align 8
  %v2534 = load i64, ptr %slot26, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  store i64 %v2533, ptr %p2535, align 8, !alias.scope !3, !noalias !4
  %v2536 = load i64, ptr %slot26, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %ld2538 = load i64, ptr %p2537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2538, ptr %slot286, align 8
  %v2539 = load i64, ptr %slot286, align 8
  %v2540 = load i64, ptr %slot13, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  store i64 %v2539, ptr %p2541, align 8, !alias.scope !3, !noalias !4
  %v2542 = load i64, ptr %slot13, align 8
  store i64 %v2542, ptr %slot287, align 8
  %v2543 = load i64, ptr %slot15, align 8
  store i64 %v2543, ptr %slot288, align 8
  %v2544 = load i64, ptr %slot287, align 8
  %v2545 = load i64, ptr %slot288, align 8
  %p2546 = inttoptr i64 %v2544 to ptr
  %p2547 = inttoptr i64 %v2545 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2547, ptr %p2546, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2548 = load i64, ptr %slot10, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  store i32 2, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  %v2550 = load i64, ptr %slot9, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  store i32 1, ptr %p2551, align 4, !alias.scope !3, !noalias !4
  %v2552 = load i64, ptr %slot5, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %ld2554 = load i32, ptr %p2553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2554, ptr %slot289, align 8
  %v2555 = load i32, ptr %slot289, align 8
  %cv2556 = zext i32 %v2555 to i64
  %cond2557 = icmp ne i64 %cv2556, 0
  br i1 %cond2557, label %bb_rcslotdrop465, label %bb_rcslotdone465
bb_rcslotdrop465:
  %v2558 = load i64, ptr %slot5, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i32 0, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  %v2560 = load i64, ptr %slot11, align 8
  store i64 %v2560, ptr %slot290, align 8
  %v2561 = load i64, ptr %slot6, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  %ld2563 = load i32, ptr %p2562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2563, ptr %slot291, align 8
  %v2564 = load i32, ptr %slot291, align 8
  %op2565 = and i32 %v2564, 28
  store i32 %op2565, ptr %slot292, align 8
  %v2566 = load i32, ptr %slot292, align 8
  %cv2567 = zext i32 %v2566 to i64
  %cond2568 = icmp ne i64 %cv2567, 0
  br i1 %cond2568, label %bb_rcslotrole465, label %bb_rcslotowner465
bb_rcslotrole465:
  %v2569 = load i64, ptr %slot33, align 8
  store i64 %v2569, ptr %slot293, align 8
  %v2570 = load i64, ptr %slot293, align 8
  %v2571 = load i64, ptr %slot290, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2570, i64 %v2571) nomerge, !dbg !128
  br label %bb_rcslotdone465
bb_rcslotowner465:
  %v2572 = load i64, ptr %slot33, align 8
  store i64 %v2572, ptr %slot294, align 8
  %v2573 = load i64, ptr %slot294, align 8
  %v2574 = load i64, ptr %slot290, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2573, i64 %v2574) nomerge, !dbg !128
  br label %bb_rcslotdone465
bb_rcslotdone465:
  %v2575 = load i64, ptr %slot7, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  %ld2577 = load i32, ptr %p2576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2577, ptr %slot295, align 8
  %v2578 = load i32, ptr %slot295, align 8
  %cv2579 = zext i32 %v2578 to i64
  %cond2580 = icmp ne i64 %cv2579, 0
  br i1 %cond2580, label %bb_rcslotdrop474, label %bb_rcslotdone474
bb_rcslotdrop474:
  %v2581 = load i64, ptr %slot7, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i32 0, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot12, align 8
  store i64 %v2583, ptr %slot296, align 8
  %v2584 = load i64, ptr %slot8, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  %ld2586 = load i32, ptr %p2585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2586, ptr %slot297, align 8
  %v2587 = load i32, ptr %slot297, align 8
  %op2588 = and i32 %v2587, 28
  store i32 %op2588, ptr %slot298, align 8
  %v2589 = load i32, ptr %slot298, align 8
  %cv2590 = zext i32 %v2589 to i64
  %cond2591 = icmp ne i64 %cv2590, 0
  br i1 %cond2591, label %bb_rcslotrole474, label %bb_rcslotowner474
bb_rcslotrole474:
  %v2592 = load i64, ptr %slot33, align 8
  store i64 %v2592, ptr %slot299, align 8
  %v2593 = load i64, ptr %slot299, align 8
  %v2594 = load i64, ptr %slot296, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2593, i64 %v2594) nomerge, !dbg !128
  br label %bb_rcslotdone474
bb_rcslotowner474:
  %v2595 = load i64, ptr %slot33, align 8
  store i64 %v2595, ptr %slot300, align 8
  %v2596 = load i64, ptr %slot300, align 8
  %v2597 = load i64, ptr %slot296, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2596, i64 %v2597) nomerge, !dbg !128
  br label %bb_rcslotdone474
bb_rcslotdone474:
  %v2598 = load i64, ptr %slot11, align 8
  store i64 %v2598, ptr %slot301, align 8
  %v2599 = load i64, ptr %slot15, align 8
  store i64 %v2599, ptr %slot302, align 8
  %v2600 = load i64, ptr %slot302, align 8
  %v2601 = load i64, ptr %slot301, align 8
  %p2602 = inttoptr i64 %v2600 to ptr
  %p2603 = inttoptr i64 %v2601 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2603, ptr %p2602, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2604 = load i64, ptr %slot6, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i32 2, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  %v2606 = load i64, ptr %slot10, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  %ld2608 = load i32, ptr %p2607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2608, ptr %slot303, align 8
  %v2609 = load i32, ptr %slot303, align 8
  %v2610 = load i64, ptr %slot6, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 %v2609, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot9, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i32 0, ptr %p2613, align 4, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot5, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  store i32 1, ptr %p2615, align 4, !alias.scope !3, !noalias !4
  %v2616 = load i64, ptr %slot301, align 8
  %p2617 = inttoptr i64 %v2616 to ptr
  %ld2618 = load i64, ptr %p2617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2618, ptr %slot304, align 8
  %v2619 = load i64, ptr %slot304, align 8
  %v2620 = load i64, ptr %slot26, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  store i64 %v2619, ptr %p2621, align 8, !alias.scope !3, !noalias !4
  %v2622 = load i64, ptr %slot26, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %ld2624 = load i64, ptr %p2623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2624, ptr %slot305, align 8
  %v2625 = load i64, ptr %slot26, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  %ld2627 = load i64, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2627, ptr %slot306, align 8
  %v2628 = load i64, ptr %slot306, align 8
  %v2629 = load i64, ptr %slot13, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i64 %v2628, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot13, align 8
  store i64 %v2631, ptr %slot307, align 8
  %v2632 = load i64, ptr %slot15, align 8
  store i64 %v2632, ptr %slot308, align 8
  %v2633 = load i64, ptr %slot34, align 8
  store i64 %v2633, ptr %slot309, align 8
  %v2634 = load i64, ptr %slot307, align 8
  %p2636 = inttoptr i64 %v2634 to ptr
  %gep2637 = getelementptr i8, ptr %p2636, i64 0
  %op2635 = ptrtoint ptr %gep2637 to i64
  store i64 %op2635, ptr %slot310, align 8
  %v2638 = load i64, ptr %slot310, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %ld2640 = load i64, ptr %p2639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2640, ptr %slot311, align 8
  %v2641 = load i64, ptr %slot311, align 8
  %cmp2642 = icmp ne i64 %v2641, 0
  %cv2643 = zext i1 %cmp2642 to i32
  store i32 %cv2643, ptr %slot312, align 8
  %v2644 = load i32, ptr %slot312, align 8
  %cv2645 = zext i32 %v2644 to i64
  %cond2646 = icmp ne i64 %cv2645, 0
  br i1 %cond2646, label %bb_rcmoveheader498, label %bb_rcmovenext498
bb_rcmoveheader498:
  %v2647 = load i64, ptr %slot311, align 8
  %op2648 = sub i64 %v2647, 16
  store i64 %op2648, ptr %slot313, align 8
  %v2649 = load i64, ptr %slot311, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  %rgep2651 = getelementptr i8, ptr %p2650, i64 -16
  %ld2652 = load i64, ptr %rgep2651, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2652, ptr %slot314, align 8
  %v2653 = load i64, ptr %slot314, align 8
  %op2654 = and i64 %v2653, 5764607523034234881
  store i64 %op2654, ptr %slot315, align 8
  %v2655 = load i64, ptr %slot315, align 8
  %cmp2656 = icmp ne i64 %v2655, 0
  %cv2657 = zext i1 %cmp2656 to i32
  store i32 %cv2657, ptr %slot316, align 8
  %v2658 = load i32, ptr %slot316, align 8
  %cv2659 = zext i32 %v2658 to i64
  %cond2660 = icmp ne i64 %cv2659, 0
  br i1 %cond2660, label %bb_rcmoveslow495, label %bb_rcmovenext498
bb_rcmovenext498:
  %v2661 = load i64, ptr %slot307, align 8
  %v2662 = load i64, ptr %slot308, align 8
  %p2663 = inttoptr i64 %v2661 to ptr
  %p2664 = inttoptr i64 %v2662 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2664, ptr %p2663, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2665 = load i64, ptr %slot307, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i64 0, ptr %p2666, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved495
bb_rcmoveslow495:
  %v2667 = load i64, ptr %slot33, align 8
  %v2668 = load i64, ptr %slot308, align 8
  %v2669 = load i64, ptr %slot307, align 8
  %v2670 = load i64, ptr %slot309, align 8
  %cv2671 = trunc i64 %v2670 to i32
  %call2672 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2667, i64 %v2668, i64 %v2669, i32 %cv2671) nomerge, !dbg !130
  store i32 %call2672, ptr %slot317, align 8
  %v2673 = load i32, ptr %slot317, align 8
  %cv2674 = zext i32 %v2673 to i64
  %cond2675 = icmp ne i64 %cv2674, 0
  br i1 %cond2675, label %bb_rcsuccess505, label %bb_rcfailure505
bb_rcfailure505:
  %v2676 = load i64, ptr %slot33, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  %call2678 = call i32 @myl_rc_take_failure(ptr %p2677) nomerge, !dbg !130
  store i32 %call2678, ptr %slot318, align 8
  %v2679 = load i64, ptr %slot1, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %v2681 = load i32, ptr %slot318, align 8
  %call2682 = call i32 @myl_qbe_rc_status(ptr %p2680, i32 %v2681) nomerge, !dbg !130
  store i32 %call2682, ptr %slot319, align 8
  br label %bb_failure
bb_rcsuccess505:
  br label %bb_rcmoved495
bb_rcmoved495:
  %v2683 = load i64, ptr %slot5, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i32 0, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot10, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  store i32 2, ptr %p2686, align 4, !alias.scope !3, !noalias !4
  %v2687 = load i64, ptr %slot9, align 8
  %p2688 = inttoptr i64 %v2687 to ptr
  store i32 1, ptr %p2688, align 4, !alias.scope !3, !noalias !4
  %v2689 = load i64, ptr %slot15, align 8
  store i64 %v2689, ptr %slot320, align 8
  %v2690 = load i64, ptr %slot320, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i64, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2692, ptr %slot321, align 8
  %v2693 = load i64, ptr %slot9, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  store i32 0, ptr %p2694, align 4, !alias.scope !3, !noalias !4
  %v2695 = load i64, ptr %slot5, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %ld2697 = load i32, ptr %p2696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2697, ptr %slot322, align 8
  %v2698 = load i32, ptr %slot322, align 8
  %cv2699 = zext i32 %v2698 to i64
  %cond2700 = icmp ne i64 %cv2699, 0
  br i1 %cond2700, label %bb_rcslotdrop516, label %bb_rcslotdone516
bb_rcslotdrop516:
  %v2701 = load i64, ptr %slot5, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i32 0, ptr %p2702, align 4, !alias.scope !3, !noalias !4
  %v2703 = load i64, ptr %slot11, align 8
  store i64 %v2703, ptr %slot323, align 8
  %v2704 = load i64, ptr %slot6, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  %ld2706 = load i32, ptr %p2705, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2706, ptr %slot324, align 8
  %v2707 = load i32, ptr %slot324, align 8
  %op2708 = and i32 %v2707, 28
  store i32 %op2708, ptr %slot325, align 8
  %v2709 = load i32, ptr %slot325, align 8
  %cv2710 = zext i32 %v2709 to i64
  %cond2711 = icmp ne i64 %cv2710, 0
  br i1 %cond2711, label %bb_rcslotrole516, label %bb_rcslotowner516
bb_rcslotrole516:
  %v2712 = load i64, ptr %slot33, align 8
  store i64 %v2712, ptr %slot326, align 8
  %v2713 = load i64, ptr %slot323, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  %ld2715 = load i64, ptr %p2714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2715, ptr %slot327, align 8
  %v2716 = load i64, ptr %slot327, align 8
  %cmp2717 = icmp ne i64 %v2716, 0
  %cv2718 = zext i1 %cmp2717 to i32
  store i32 %cv2718, ptr %slot328, align 8
  %v2719 = load i32, ptr %slot328, align 8
  %cv2720 = zext i32 %v2719 to i64
  %cond2721 = icmp ne i64 %cv2720, 0
  br i1 %cond2721, label %bb_rcgnn532, label %bb_rcgdone532
bb_rcgnn532:
  %v2722 = load i64, ptr %slot327, align 8
  %op2723 = sub i64 %v2722, 16
  store i64 %op2723, ptr %slot329, align 8
  %v2724 = load i64, ptr %slot327, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  %rgep2726 = getelementptr i8, ptr %p2725, i64 -16
  %ld2727 = load i64, ptr %rgep2726, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2727, ptr %slot330, align 8
  %v2728 = load i64, ptr %slot330, align 8
  %op2729 = and i64 %v2728, 4611686018427387906
  store i64 %op2729, ptr %slot331, align 8
  %v2730 = load i64, ptr %slot331, align 8
  %cmp2731 = icmp ne i64 %v2730, 0
  %cv2732 = zext i1 %cmp2731 to i32
  store i32 %cv2732, ptr %slot332, align 8
  %v2733 = load i32, ptr %slot332, align 8
  %cv2734 = zext i32 %v2733 to i64
  %cond2735 = icmp ne i64 %cv2734, 0
  br i1 %cond2735, label %bb_rcgclear532, label %bb_rcgcounted532
bb_rcgcounted532:
  %v2736 = load i64, ptr %slot327, align 8
  %op2737 = sub i64 %v2736, 24
  store i64 %op2737, ptr %slot333, align 8
  %v2738 = load i64, ptr %slot327, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %rgep2740 = getelementptr i8, ptr %p2739, i64 -24
  %ld2741 = load i64, ptr %rgep2740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2741, ptr %slot334, align 8
  %v2742 = load i64, ptr %slot334, align 8
  %op2743 = sub i64 %v2742, 1
  store i64 %op2743, ptr %slot335, align 8
  %v2744 = load i64, ptr %slot335, align 8
  %cmp2745 = icmp eq i64 %v2744, 0
  %cv2746 = zext i1 %cmp2745 to i32
  store i32 %cv2746, ptr %slot336, align 8
  %v2747 = load i32, ptr %slot336, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcglast532, label %bb_rcgdec532
bb_rcglast532:
  %v2750 = load i64, ptr %slot327, align 8
  %op2751 = sub i64 %v2750, 32
  store i64 %op2751, ptr %slot337, align 8
  %v2752 = load i64, ptr %slot327, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %rgep2754 = getelementptr i8, ptr %p2753, i64 -32
  %ld2755 = load i64, ptr %rgep2754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2755, ptr %slot338, align 8
  %v2756 = load i64, ptr %slot338, align 8
  %cmp2757 = icmp ne i64 %v2756, 0
  %cv2758 = zext i1 %cmp2757 to i32
  store i32 %cv2758, ptr %slot339, align 8
  %v2759 = load i32, ptr %slot339, align 8
  %cv2760 = zext i32 %v2759 to i64
  %cond2761 = icmp ne i64 %cv2760, 0
  br i1 %cond2761, label %bb_rcgdec532, label %bb_rcgslow532
bb_rcgslow532:
  %v2762 = load i64, ptr %slot326, align 8
  %v2763 = load i64, ptr %slot323, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2762, i64 %v2763) nomerge, !dbg !130
  br label %bb_rcgdone532
bb_rcgdec532:
  %v2764 = load i64, ptr %slot335, align 8
  %v2765 = load i64, ptr %slot327, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %rgep2767 = getelementptr i8, ptr %p2766, i64 -24
  store i64 %v2764, ptr %rgep2767, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear532
bb_rcgclear532:
  %v2768 = load i64, ptr %slot323, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  store i64 0, ptr %p2769, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone532
bb_rcgdone532:
  br label %bb_rcslotdone516
bb_rcslotowner516:
  %v2770 = load i64, ptr %slot33, align 8
  store i64 %v2770, ptr %slot340, align 8
  %v2771 = load i64, ptr %slot323, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  %ld2773 = load i64, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2773, ptr %slot341, align 8
  %v2774 = load i64, ptr %slot341, align 8
  %cmp2775 = icmp ne i64 %v2774, 0
  %cv2776 = zext i1 %cmp2775 to i32
  store i32 %cv2776, ptr %slot342, align 8
  %v2777 = load i32, ptr %slot342, align 8
  %cv2778 = zext i32 %v2777 to i64
  %cond2779 = icmp ne i64 %cv2778, 0
  br i1 %cond2779, label %bb_rcgnn547, label %bb_rcgdone547
bb_rcgnn547:
  %v2780 = load i64, ptr %slot341, align 8
  %op2781 = sub i64 %v2780, 16
  store i64 %op2781, ptr %slot343, align 8
  %v2782 = load i64, ptr %slot341, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %rgep2784 = getelementptr i8, ptr %p2783, i64 -16
  %ld2785 = load i64, ptr %rgep2784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2785, ptr %slot344, align 8
  %v2786 = load i64, ptr %slot344, align 8
  %op2787 = and i64 %v2786, 4611686018427387906
  store i64 %op2787, ptr %slot345, align 8
  %v2788 = load i64, ptr %slot345, align 8
  %cmp2789 = icmp ne i64 %v2788, 0
  %cv2790 = zext i1 %cmp2789 to i32
  store i32 %cv2790, ptr %slot346, align 8
  %v2791 = load i32, ptr %slot346, align 8
  %cv2792 = zext i32 %v2791 to i64
  %cond2793 = icmp ne i64 %cv2792, 0
  br i1 %cond2793, label %bb_rcgclear547, label %bb_rcgcounted547
bb_rcgcounted547:
  %v2794 = load i64, ptr %slot341, align 8
  %op2795 = sub i64 %v2794, 32
  store i64 %op2795, ptr %slot347, align 8
  %v2796 = load i64, ptr %slot341, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %rgep2798 = getelementptr i8, ptr %p2797, i64 -32
  %ld2799 = load i64, ptr %rgep2798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2799, ptr %slot348, align 8
  %v2800 = load i64, ptr %slot348, align 8
  %op2801 = sub i64 %v2800, 1
  store i64 %op2801, ptr %slot349, align 8
  %v2802 = load i64, ptr %slot349, align 8
  %cmp2803 = icmp eq i64 %v2802, 0
  %cv2804 = zext i1 %cmp2803 to i32
  store i32 %cv2804, ptr %slot350, align 8
  %v2805 = load i32, ptr %slot350, align 8
  %cv2806 = zext i32 %v2805 to i64
  %cond2807 = icmp ne i64 %cv2806, 0
  br i1 %cond2807, label %bb_rcglast547, label %bb_rcgdec547
bb_rcglast547:
  %v2808 = load i64, ptr %slot341, align 8
  %op2809 = sub i64 %v2808, 24
  store i64 %op2809, ptr %slot351, align 8
  %v2810 = load i64, ptr %slot341, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  %rgep2812 = getelementptr i8, ptr %p2811, i64 -24
  %ld2813 = load i64, ptr %rgep2812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2813, ptr %slot352, align 8
  %v2814 = load i64, ptr %slot352, align 8
  %cmp2815 = icmp ne i64 %v2814, 0
  %cv2816 = zext i1 %cmp2815 to i32
  store i32 %cv2816, ptr %slot353, align 8
  %v2817 = load i32, ptr %slot353, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcgdec547, label %bb_rcgslow547
bb_rcgslow547:
  %v2820 = load i64, ptr %slot340, align 8
  %v2821 = load i64, ptr %slot323, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2820, i64 %v2821) nomerge, !dbg !130
  br label %bb_rcgdone547
bb_rcgdec547:
  %v2822 = load i64, ptr %slot349, align 8
  %v2823 = load i64, ptr %slot341, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %rgep2825 = getelementptr i8, ptr %p2824, i64 -32
  store i64 %v2822, ptr %rgep2825, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear547
bb_rcgclear547:
  %v2826 = load i64, ptr %slot323, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i64 0, ptr %p2827, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone547
bb_rcgdone547:
  br label %bb_rcslotdone516
bb_rcslotdone516:
  %v2828 = load i64, ptr %slot321, align 8
  ret i64 %v2828
bb_i27:
  %p2829 = inttoptr i64 ptrtoint (ptr @myl_lit_6852c1228bf663edc32c60c4f34b0e76845ba0a899fe6006aae97bb03c5b6adb to i64) to ptr
  %ld2830 = load i64, ptr %p2829, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2830, ptr %slot354, align 8
  %v2831 = load i64, ptr %slot354, align 8
  %v2832 = load i64, ptr %slot26, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  store i64 %v2831, ptr %p2833, align 8, !alias.scope !3, !noalias !4
  %v2834 = load i64, ptr %slot26, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  %ld2836 = load i64, ptr %p2835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2836, ptr %slot355, align 8
  %v2837 = load i64, ptr %slot355, align 8
  %v2838 = load i64, ptr %slot13, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i64 %v2837, ptr %p2839, align 8, !alias.scope !3, !noalias !4
  %v2840 = load i64, ptr %slot13, align 8
  store i64 %v2840, ptr %slot356, align 8
  %v2841 = load i64, ptr %slot15, align 8
  store i64 %v2841, ptr %slot357, align 8
  %v2842 = load i64, ptr %slot356, align 8
  %v2843 = load i64, ptr %slot357, align 8
  %p2844 = inttoptr i64 %v2842 to ptr
  %p2845 = inttoptr i64 %v2843 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2845, ptr %p2844, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2846 = load i64, ptr %slot10, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i32 2, ptr %p2847, align 4, !alias.scope !3, !noalias !4
  %v2848 = load i64, ptr %slot9, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  store i32 1, ptr %p2849, align 4, !alias.scope !3, !noalias !4
  %v2850 = load i64, ptr %slot11, align 8
  store i64 %v2850, ptr %slot358, align 8
  %v2851 = load i64, ptr %slot15, align 8
  store i64 %v2851, ptr %slot359, align 8
  %v2852 = load i64, ptr %slot359, align 8
  %v2853 = load i64, ptr %slot358, align 8
  %p2854 = inttoptr i64 %v2852 to ptr
  %p2855 = inttoptr i64 %v2853 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2855, ptr %p2854, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2856 = load i64, ptr %slot6, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i32 2, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot10, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %ld2860 = load i32, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2860, ptr %slot360, align 8
  %v2861 = load i32, ptr %slot360, align 8
  %v2862 = load i64, ptr %slot6, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i32 %v2861, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot9, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i32 0, ptr %p2865, align 4, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot5, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i32 1, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  %v2868 = load i64, ptr %slot358, align 8
  %p2869 = inttoptr i64 %v2868 to ptr
  %ld2870 = load i64, ptr %p2869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2870, ptr %slot361, align 8
  %v2871 = load i64, ptr %slot361, align 8
  %v2872 = load i64, ptr %slot26, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  store i64 %v2871, ptr %p2873, align 8, !alias.scope !3, !noalias !4
  %v2874 = load i64, ptr %slot26, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %ld2876 = load i64, ptr %p2875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2876, ptr %slot362, align 8
  %v2877 = load i64, ptr %slot26, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i64, ptr %p2878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2879, ptr %slot363, align 8
  %v2880 = load i64, ptr %slot363, align 8
  %v2881 = load i64, ptr %slot13, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  store i64 %v2880, ptr %p2882, align 8, !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot13, align 8
  store i64 %v2883, ptr %slot364, align 8
  %v2884 = load i64, ptr %slot15, align 8
  store i64 %v2884, ptr %slot365, align 8
  %v2885 = load i64, ptr %slot34, align 8
  store i64 %v2885, ptr %slot366, align 8
  %v2886 = load i64, ptr %slot364, align 8
  %p2888 = inttoptr i64 %v2886 to ptr
  %gep2889 = getelementptr i8, ptr %p2888, i64 0
  %op2887 = ptrtoint ptr %gep2889 to i64
  store i64 %op2887, ptr %slot367, align 8
  %v2890 = load i64, ptr %slot367, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %ld2892 = load i64, ptr %p2891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2892, ptr %slot368, align 8
  %v2893 = load i64, ptr %slot368, align 8
  %cmp2894 = icmp ne i64 %v2893, 0
  %cv2895 = zext i1 %cmp2894 to i32
  store i32 %cv2895, ptr %slot369, align 8
  %v2896 = load i32, ptr %slot369, align 8
  %cv2897 = zext i32 %v2896 to i64
  %cond2898 = icmp ne i64 %cv2897, 0
  br i1 %cond2898, label %bb_rcmoveheader657, label %bb_rcmovenext657
bb_rcmoveheader657:
  %v2899 = load i64, ptr %slot368, align 8
  %op2900 = sub i64 %v2899, 16
  store i64 %op2900, ptr %slot370, align 8
  %v2901 = load i64, ptr %slot368, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  %rgep2903 = getelementptr i8, ptr %p2902, i64 -16
  %ld2904 = load i64, ptr %rgep2903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2904, ptr %slot371, align 8
  %v2905 = load i64, ptr %slot371, align 8
  %op2906 = and i64 %v2905, 5764607523034234881
  store i64 %op2906, ptr %slot372, align 8
  %v2907 = load i64, ptr %slot372, align 8
  %cmp2908 = icmp ne i64 %v2907, 0
  %cv2909 = zext i1 %cmp2908 to i32
  store i32 %cv2909, ptr %slot373, align 8
  %v2910 = load i32, ptr %slot373, align 8
  %cv2911 = zext i32 %v2910 to i64
  %cond2912 = icmp ne i64 %cv2911, 0
  br i1 %cond2912, label %bb_rcmoveslow654, label %bb_rcmovenext657
bb_rcmovenext657:
  %v2913 = load i64, ptr %slot364, align 8
  %v2914 = load i64, ptr %slot365, align 8
  %p2915 = inttoptr i64 %v2913 to ptr
  %p2916 = inttoptr i64 %v2914 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2916, ptr %p2915, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2917 = load i64, ptr %slot364, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  store i64 0, ptr %p2918, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved654
bb_rcmoveslow654:
  %v2919 = load i64, ptr %slot33, align 8
  %v2920 = load i64, ptr %slot365, align 8
  %v2921 = load i64, ptr %slot364, align 8
  %v2922 = load i64, ptr %slot366, align 8
  %cv2923 = trunc i64 %v2922 to i32
  %call2924 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2919, i64 %v2920, i64 %v2921, i32 %cv2923) nomerge, !dbg !132
  store i32 %call2924, ptr %slot374, align 8
  %v2925 = load i32, ptr %slot374, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcsuccess664, label %bb_rcfailure664
bb_rcfailure664:
  %v2928 = load i64, ptr %slot33, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %call2930 = call i32 @myl_rc_take_failure(ptr %p2929) nomerge, !dbg !132
  store i32 %call2930, ptr %slot375, align 8
  %v2931 = load i64, ptr %slot1, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  %v2933 = load i32, ptr %slot375, align 8
  %call2934 = call i32 @myl_qbe_rc_status(ptr %p2932, i32 %v2933) nomerge, !dbg !132
  store i32 %call2934, ptr %slot376, align 8
  br label %bb_failure
bb_rcsuccess664:
  br label %bb_rcmoved654
bb_rcmoved654:
  %v2935 = load i64, ptr %slot5, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i32 0, ptr %p2936, align 4, !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot10, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  store i32 2, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  %v2939 = load i64, ptr %slot9, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i32 1, ptr %p2940, align 4, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot15, align 8
  store i64 %v2941, ptr %slot377, align 8
  %v2942 = load i64, ptr %slot377, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %ld2944 = load i64, ptr %p2943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2944, ptr %slot378, align 8
  %v2945 = load i64, ptr %slot9, align 8
  %p2946 = inttoptr i64 %v2945 to ptr
  store i32 0, ptr %p2946, align 4, !alias.scope !3, !noalias !4
  %v2947 = load i64, ptr %slot5, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %ld2949 = load i32, ptr %p2948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2949, ptr %slot379, align 8
  %v2950 = load i32, ptr %slot379, align 8
  %cv2951 = zext i32 %v2950 to i64
  %cond2952 = icmp ne i64 %cv2951, 0
  br i1 %cond2952, label %bb_rcslotdrop675, label %bb_rcslotdone675
bb_rcslotdrop675:
  %v2953 = load i64, ptr %slot5, align 8
  %p2954 = inttoptr i64 %v2953 to ptr
  store i32 0, ptr %p2954, align 4, !alias.scope !3, !noalias !4
  %v2955 = load i64, ptr %slot11, align 8
  store i64 %v2955, ptr %slot380, align 8
  %v2956 = load i64, ptr %slot6, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  %ld2958 = load i32, ptr %p2957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2958, ptr %slot381, align 8
  %v2959 = load i32, ptr %slot381, align 8
  %op2960 = and i32 %v2959, 28
  store i32 %op2960, ptr %slot382, align 8
  %v2961 = load i32, ptr %slot382, align 8
  %cv2962 = zext i32 %v2961 to i64
  %cond2963 = icmp ne i64 %cv2962, 0
  br i1 %cond2963, label %bb_rcslotrole675, label %bb_rcslotowner675
bb_rcslotrole675:
  %v2964 = load i64, ptr %slot33, align 8
  store i64 %v2964, ptr %slot383, align 8
  %v2965 = load i64, ptr %slot380, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %ld2967 = load i64, ptr %p2966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2967, ptr %slot384, align 8
  %v2968 = load i64, ptr %slot384, align 8
  %cmp2969 = icmp ne i64 %v2968, 0
  %cv2970 = zext i1 %cmp2969 to i32
  store i32 %cv2970, ptr %slot385, align 8
  %v2971 = load i32, ptr %slot385, align 8
  %cv2972 = zext i32 %v2971 to i64
  %cond2973 = icmp ne i64 %cv2972, 0
  br i1 %cond2973, label %bb_rcgnn691, label %bb_rcgdone691
bb_rcgnn691:
  %v2974 = load i64, ptr %slot384, align 8
  %op2975 = sub i64 %v2974, 16
  store i64 %op2975, ptr %slot386, align 8
  %v2976 = load i64, ptr %slot384, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %rgep2978 = getelementptr i8, ptr %p2977, i64 -16
  %ld2979 = load i64, ptr %rgep2978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2979, ptr %slot387, align 8
  %v2980 = load i64, ptr %slot387, align 8
  %op2981 = and i64 %v2980, 4611686018427387906
  store i64 %op2981, ptr %slot388, align 8
  %v2982 = load i64, ptr %slot388, align 8
  %cmp2983 = icmp ne i64 %v2982, 0
  %cv2984 = zext i1 %cmp2983 to i32
  store i32 %cv2984, ptr %slot389, align 8
  %v2985 = load i32, ptr %slot389, align 8
  %cv2986 = zext i32 %v2985 to i64
  %cond2987 = icmp ne i64 %cv2986, 0
  br i1 %cond2987, label %bb_rcgclear691, label %bb_rcgcounted691
bb_rcgcounted691:
  %v2988 = load i64, ptr %slot384, align 8
  %op2989 = sub i64 %v2988, 24
  store i64 %op2989, ptr %slot390, align 8
  %v2990 = load i64, ptr %slot384, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  %rgep2992 = getelementptr i8, ptr %p2991, i64 -24
  %ld2993 = load i64, ptr %rgep2992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2993, ptr %slot391, align 8
  %v2994 = load i64, ptr %slot391, align 8
  %op2995 = sub i64 %v2994, 1
  store i64 %op2995, ptr %slot392, align 8
  %v2996 = load i64, ptr %slot392, align 8
  %cmp2997 = icmp eq i64 %v2996, 0
  %cv2998 = zext i1 %cmp2997 to i32
  store i32 %cv2998, ptr %slot393, align 8
  %v2999 = load i32, ptr %slot393, align 8
  %cv3000 = zext i32 %v2999 to i64
  %cond3001 = icmp ne i64 %cv3000, 0
  br i1 %cond3001, label %bb_rcglast691, label %bb_rcgdec691
bb_rcglast691:
  %v3002 = load i64, ptr %slot384, align 8
  %op3003 = sub i64 %v3002, 32
  store i64 %op3003, ptr %slot394, align 8
  %v3004 = load i64, ptr %slot384, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  %rgep3006 = getelementptr i8, ptr %p3005, i64 -32
  %ld3007 = load i64, ptr %rgep3006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3007, ptr %slot395, align 8
  %v3008 = load i64, ptr %slot395, align 8
  %cmp3009 = icmp ne i64 %v3008, 0
  %cv3010 = zext i1 %cmp3009 to i32
  store i32 %cv3010, ptr %slot396, align 8
  %v3011 = load i32, ptr %slot396, align 8
  %cv3012 = zext i32 %v3011 to i64
  %cond3013 = icmp ne i64 %cv3012, 0
  br i1 %cond3013, label %bb_rcgdec691, label %bb_rcgslow691
bb_rcgslow691:
  %v3014 = load i64, ptr %slot383, align 8
  %v3015 = load i64, ptr %slot380, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3014, i64 %v3015) nomerge, !dbg !132
  br label %bb_rcgdone691
bb_rcgdec691:
  %v3016 = load i64, ptr %slot392, align 8
  %v3017 = load i64, ptr %slot384, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  %rgep3019 = getelementptr i8, ptr %p3018, i64 -24
  store i64 %v3016, ptr %rgep3019, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear691
bb_rcgclear691:
  %v3020 = load i64, ptr %slot380, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  store i64 0, ptr %p3021, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone691
bb_rcgdone691:
  br label %bb_rcslotdone675
bb_rcslotowner675:
  %v3022 = load i64, ptr %slot33, align 8
  store i64 %v3022, ptr %slot397, align 8
  %v3023 = load i64, ptr %slot380, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  %ld3025 = load i64, ptr %p3024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3025, ptr %slot398, align 8
  %v3026 = load i64, ptr %slot398, align 8
  %cmp3027 = icmp ne i64 %v3026, 0
  %cv3028 = zext i1 %cmp3027 to i32
  store i32 %cv3028, ptr %slot399, align 8
  %v3029 = load i32, ptr %slot399, align 8
  %cv3030 = zext i32 %v3029 to i64
  %cond3031 = icmp ne i64 %cv3030, 0
  br i1 %cond3031, label %bb_rcgnn706, label %bb_rcgdone706
bb_rcgnn706:
  %v3032 = load i64, ptr %slot398, align 8
  %op3033 = sub i64 %v3032, 16
  store i64 %op3033, ptr %slot400, align 8
  %v3034 = load i64, ptr %slot398, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %rgep3036 = getelementptr i8, ptr %p3035, i64 -16
  %ld3037 = load i64, ptr %rgep3036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3037, ptr %slot401, align 8
  %v3038 = load i64, ptr %slot401, align 8
  %op3039 = and i64 %v3038, 4611686018427387906
  store i64 %op3039, ptr %slot402, align 8
  %v3040 = load i64, ptr %slot402, align 8
  %cmp3041 = icmp ne i64 %v3040, 0
  %cv3042 = zext i1 %cmp3041 to i32
  store i32 %cv3042, ptr %slot403, align 8
  %v3043 = load i32, ptr %slot403, align 8
  %cv3044 = zext i32 %v3043 to i64
  %cond3045 = icmp ne i64 %cv3044, 0
  br i1 %cond3045, label %bb_rcgclear706, label %bb_rcgcounted706
bb_rcgcounted706:
  %v3046 = load i64, ptr %slot398, align 8
  %op3047 = sub i64 %v3046, 32
  store i64 %op3047, ptr %slot404, align 8
  %v3048 = load i64, ptr %slot398, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %rgep3050 = getelementptr i8, ptr %p3049, i64 -32
  %ld3051 = load i64, ptr %rgep3050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3051, ptr %slot405, align 8
  %v3052 = load i64, ptr %slot405, align 8
  %op3053 = sub i64 %v3052, 1
  store i64 %op3053, ptr %slot406, align 8
  %v3054 = load i64, ptr %slot406, align 8
  %cmp3055 = icmp eq i64 %v3054, 0
  %cv3056 = zext i1 %cmp3055 to i32
  store i32 %cv3056, ptr %slot407, align 8
  %v3057 = load i32, ptr %slot407, align 8
  %cv3058 = zext i32 %v3057 to i64
  %cond3059 = icmp ne i64 %cv3058, 0
  br i1 %cond3059, label %bb_rcglast706, label %bb_rcgdec706
bb_rcglast706:
  %v3060 = load i64, ptr %slot398, align 8
  %op3061 = sub i64 %v3060, 24
  store i64 %op3061, ptr %slot408, align 8
  %v3062 = load i64, ptr %slot398, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %rgep3064 = getelementptr i8, ptr %p3063, i64 -24
  %ld3065 = load i64, ptr %rgep3064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3065, ptr %slot409, align 8
  %v3066 = load i64, ptr %slot409, align 8
  %cmp3067 = icmp ne i64 %v3066, 0
  %cv3068 = zext i1 %cmp3067 to i32
  store i32 %cv3068, ptr %slot410, align 8
  %v3069 = load i32, ptr %slot410, align 8
  %cv3070 = zext i32 %v3069 to i64
  %cond3071 = icmp ne i64 %cv3070, 0
  br i1 %cond3071, label %bb_rcgdec706, label %bb_rcgslow706
bb_rcgslow706:
  %v3072 = load i64, ptr %slot397, align 8
  %v3073 = load i64, ptr %slot380, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3072, i64 %v3073) nomerge, !dbg !132
  br label %bb_rcgdone706
bb_rcgdec706:
  %v3074 = load i64, ptr %slot406, align 8
  %v3075 = load i64, ptr %slot398, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  %rgep3077 = getelementptr i8, ptr %p3076, i64 -32
  store i64 %v3074, ptr %rgep3077, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear706
bb_rcgclear706:
  %v3078 = load i64, ptr %slot380, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i64 0, ptr %p3079, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone706
bb_rcgdone706:
  br label %bb_rcslotdone675
bb_rcslotdone675:
  %v3080 = load i64, ptr %slot378, align 8
  ret i64 %v3080
bb_i29:
  %v3081 = load i64, ptr %slot16, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %ld3083 = load i64, ptr %p3082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3083, ptr %slot411, align 8
  %v3084 = load i64, ptr %slot411, align 8
  %v3085 = load i64, ptr %slot26, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  store i64 %v3084, ptr %p3086, align 8, !alias.scope !3, !noalias !4
  %v3087 = load i64, ptr %slot17, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %ld3089 = load i64, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3089, ptr %slot412, align 8
  %v3090 = load i64, ptr %slot412, align 8
  %v3091 = load i64, ptr %slot27, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  store i64 %v3090, ptr %p3092, align 8, !alias.scope !3, !noalias !4
  %v3093 = load i64, ptr %slot26, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  %ld3095 = load i64, ptr %p3094, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3095, ptr %slot413, align 8
  %v3096 = load i64, ptr %slot27, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i64, ptr %p3097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3098, ptr %slot414, align 8
  %v3099 = load i64, ptr %slot1, align 8
  %v3100 = load i64, ptr %slot413, align 8
  %v3101 = load i64, ptr %slot414, align 8
  %call3102 = call i64 @myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686(i64 %v3099, i64 %v3100, i64 %v3101) nomerge, !dbg !134
  store i64 %call3102, ptr %slot415, align 8
  %v3103 = load i64, ptr %slot415, align 8
  %v3104 = load i64, ptr %slot26, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  store i64 %v3103, ptr %p3105, align 8, !alias.scope !3, !noalias !4
  %v3106 = load i64, ptr %slot26, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  %ld3108 = load i64, ptr %p3107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3108, ptr %slot416, align 8
  %v3109 = load i64, ptr %slot416, align 8
  %v3110 = load i64, ptr %slot13, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  store i64 %v3109, ptr %p3111, align 8, !alias.scope !3, !noalias !4
  %v3112 = load i64, ptr %slot13, align 8
  store i64 %v3112, ptr %slot417, align 8
  %v3113 = load i64, ptr %slot15, align 8
  store i64 %v3113, ptr %slot418, align 8
  %v3114 = load i64, ptr %slot417, align 8
  %v3115 = load i64, ptr %slot418, align 8
  %p3116 = inttoptr i64 %v3114 to ptr
  %p3117 = inttoptr i64 %v3115 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3117, ptr %p3116, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3118 = load i64, ptr %slot10, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  store i32 2, ptr %p3119, align 4, !alias.scope !3, !noalias !4
  %v3120 = load i64, ptr %slot9, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i32 1, ptr %p3121, align 4, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot5, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  %ld3124 = load i32, ptr %p3123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3124, ptr %slot419, align 8
  %v3125 = load i32, ptr %slot419, align 8
  %cv3126 = zext i32 %v3125 to i64
  %cond3127 = icmp ne i64 %cv3126, 0
  br i1 %cond3127, label %bb_rcslotdrop804, label %bb_rcslotdone804
bb_rcslotdrop804:
  %v3128 = load i64, ptr %slot5, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  store i32 0, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot11, align 8
  store i64 %v3130, ptr %slot420, align 8
  %v3131 = load i64, ptr %slot6, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  %ld3133 = load i32, ptr %p3132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3133, ptr %slot421, align 8
  %v3134 = load i32, ptr %slot421, align 8
  %op3135 = and i32 %v3134, 28
  store i32 %op3135, ptr %slot422, align 8
  %v3136 = load i32, ptr %slot422, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcslotrole804, label %bb_rcslotowner804
bb_rcslotrole804:
  %v3139 = load i64, ptr %slot33, align 8
  store i64 %v3139, ptr %slot423, align 8
  %v3140 = load i64, ptr %slot423, align 8
  %v3141 = load i64, ptr %slot420, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3140, i64 %v3141) nomerge, !dbg !134
  br label %bb_rcslotdone804
bb_rcslotowner804:
  %v3142 = load i64, ptr %slot33, align 8
  store i64 %v3142, ptr %slot424, align 8
  %v3143 = load i64, ptr %slot424, align 8
  %v3144 = load i64, ptr %slot420, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3143, i64 %v3144) nomerge, !dbg !134
  br label %bb_rcslotdone804
bb_rcslotdone804:
  %v3145 = load i64, ptr %slot11, align 8
  store i64 %v3145, ptr %slot425, align 8
  %v3146 = load i64, ptr %slot15, align 8
  store i64 %v3146, ptr %slot426, align 8
  %v3147 = load i64, ptr %slot426, align 8
  %v3148 = load i64, ptr %slot425, align 8
  %p3149 = inttoptr i64 %v3147 to ptr
  %p3150 = inttoptr i64 %v3148 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3150, ptr %p3149, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot6, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i32 2, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot10, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %ld3155 = load i32, ptr %p3154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3155, ptr %slot427, align 8
  %v3156 = load i32, ptr %slot427, align 8
  %v3157 = load i64, ptr %slot6, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i32 %v3156, ptr %p3158, align 4, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot9, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  store i32 0, ptr %p3160, align 4, !alias.scope !3, !noalias !4
  %v3161 = load i64, ptr %slot5, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  store i32 1, ptr %p3162, align 4, !alias.scope !3, !noalias !4
  %v3163 = load i64, ptr %slot425, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i64, ptr %p3164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3165, ptr %slot428, align 8
  %v3166 = load i64, ptr %slot428, align 8
  %v3167 = load i64, ptr %slot26, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  store i64 %v3166, ptr %p3168, align 8, !alias.scope !3, !noalias !4
  %v3169 = load i64, ptr %slot26, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %ld3171 = load i64, ptr %p3170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3171, ptr %slot429, align 8
  %v3172 = load i64, ptr %slot26, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %ld3174 = load i64, ptr %p3173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3174, ptr %slot430, align 8
  %v3175 = load i64, ptr %slot430, align 8
  %v3176 = load i64, ptr %slot13, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  store i64 %v3175, ptr %p3177, align 8, !alias.scope !3, !noalias !4
  %v3178 = load i64, ptr %slot13, align 8
  store i64 %v3178, ptr %slot431, align 8
  %v3179 = load i64, ptr %slot15, align 8
  store i64 %v3179, ptr %slot432, align 8
  %v3180 = load i64, ptr %slot34, align 8
  store i64 %v3180, ptr %slot433, align 8
  %v3181 = load i64, ptr %slot431, align 8
  %p3183 = inttoptr i64 %v3181 to ptr
  %gep3184 = getelementptr i8, ptr %p3183, i64 0
  %op3182 = ptrtoint ptr %gep3184 to i64
  store i64 %op3182, ptr %slot434, align 8
  %v3185 = load i64, ptr %slot434, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %ld3187 = load i64, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3187, ptr %slot435, align 8
  %v3188 = load i64, ptr %slot435, align 8
  %cmp3189 = icmp ne i64 %v3188, 0
  %cv3190 = zext i1 %cmp3189 to i32
  store i32 %cv3190, ptr %slot436, align 8
  %v3191 = load i32, ptr %slot436, align 8
  %cv3192 = zext i32 %v3191 to i64
  %cond3193 = icmp ne i64 %cv3192, 0
  br i1 %cond3193, label %bb_rcmoveheader828, label %bb_rcmovenext828
bb_rcmoveheader828:
  %v3194 = load i64, ptr %slot435, align 8
  %op3195 = sub i64 %v3194, 16
  store i64 %op3195, ptr %slot437, align 8
  %v3196 = load i64, ptr %slot435, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  %rgep3198 = getelementptr i8, ptr %p3197, i64 -16
  %ld3199 = load i64, ptr %rgep3198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3199, ptr %slot438, align 8
  %v3200 = load i64, ptr %slot438, align 8
  %op3201 = and i64 %v3200, 5764607523034234881
  store i64 %op3201, ptr %slot439, align 8
  %v3202 = load i64, ptr %slot439, align 8
  %cmp3203 = icmp ne i64 %v3202, 0
  %cv3204 = zext i1 %cmp3203 to i32
  store i32 %cv3204, ptr %slot440, align 8
  %v3205 = load i32, ptr %slot440, align 8
  %cv3206 = zext i32 %v3205 to i64
  %cond3207 = icmp ne i64 %cv3206, 0
  br i1 %cond3207, label %bb_rcmoveslow825, label %bb_rcmovenext828
bb_rcmovenext828:
  %v3208 = load i64, ptr %slot431, align 8
  %v3209 = load i64, ptr %slot432, align 8
  %p3210 = inttoptr i64 %v3208 to ptr
  %p3211 = inttoptr i64 %v3209 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3211, ptr %p3210, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot431, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i64 0, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved825
bb_rcmoveslow825:
  %v3214 = load i64, ptr %slot33, align 8
  %v3215 = load i64, ptr %slot432, align 8
  %v3216 = load i64, ptr %slot431, align 8
  %v3217 = load i64, ptr %slot433, align 8
  %cv3218 = trunc i64 %v3217 to i32
  %call3219 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3214, i64 %v3215, i64 %v3216, i32 %cv3218) nomerge, !dbg !136
  store i32 %call3219, ptr %slot441, align 8
  %v3220 = load i32, ptr %slot441, align 8
  %cv3221 = zext i32 %v3220 to i64
  %cond3222 = icmp ne i64 %cv3221, 0
  br i1 %cond3222, label %bb_rcsuccess835, label %bb_rcfailure835
bb_rcfailure835:
  %v3223 = load i64, ptr %slot33, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %call3225 = call i32 @myl_rc_take_failure(ptr %p3224) nomerge, !dbg !136
  store i32 %call3225, ptr %slot442, align 8
  %v3226 = load i64, ptr %slot1, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  %v3228 = load i32, ptr %slot442, align 8
  %call3229 = call i32 @myl_qbe_rc_status(ptr %p3227, i32 %v3228) nomerge, !dbg !136
  store i32 %call3229, ptr %slot443, align 8
  br label %bb_failure
bb_rcsuccess835:
  br label %bb_rcmoved825
bb_rcmoved825:
  %v3230 = load i64, ptr %slot5, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  store i32 0, ptr %p3231, align 4, !alias.scope !3, !noalias !4
  %v3232 = load i64, ptr %slot10, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i32 2, ptr %p3233, align 4, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot9, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  store i32 1, ptr %p3235, align 4, !alias.scope !3, !noalias !4
  %v3236 = load i64, ptr %slot15, align 8
  store i64 %v3236, ptr %slot444, align 8
  %v3237 = load i64, ptr %slot444, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  %ld3239 = load i64, ptr %p3238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3239, ptr %slot445, align 8
  %v3240 = load i64, ptr %slot9, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i32 0, ptr %p3241, align 4, !alias.scope !3, !noalias !4
  %v3242 = load i64, ptr %slot5, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %ld3244 = load i32, ptr %p3243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3244, ptr %slot446, align 8
  %v3245 = load i32, ptr %slot446, align 8
  %cv3246 = zext i32 %v3245 to i64
  %cond3247 = icmp ne i64 %cv3246, 0
  br i1 %cond3247, label %bb_rcslotdrop846, label %bb_rcslotdone846
bb_rcslotdrop846:
  %v3248 = load i64, ptr %slot5, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i32 0, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  %v3250 = load i64, ptr %slot11, align 8
  store i64 %v3250, ptr %slot447, align 8
  %v3251 = load i64, ptr %slot6, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %ld3253 = load i32, ptr %p3252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3253, ptr %slot448, align 8
  %v3254 = load i32, ptr %slot448, align 8
  %op3255 = and i32 %v3254, 28
  store i32 %op3255, ptr %slot449, align 8
  %v3256 = load i32, ptr %slot449, align 8
  %cv3257 = zext i32 %v3256 to i64
  %cond3258 = icmp ne i64 %cv3257, 0
  br i1 %cond3258, label %bb_rcslotrole846, label %bb_rcslotowner846
bb_rcslotrole846:
  %v3259 = load i64, ptr %slot33, align 8
  store i64 %v3259, ptr %slot450, align 8
  %v3260 = load i64, ptr %slot447, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  %ld3262 = load i64, ptr %p3261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3262, ptr %slot451, align 8
  %v3263 = load i64, ptr %slot451, align 8
  %cmp3264 = icmp ne i64 %v3263, 0
  %cv3265 = zext i1 %cmp3264 to i32
  store i32 %cv3265, ptr %slot452, align 8
  %v3266 = load i32, ptr %slot452, align 8
  %cv3267 = zext i32 %v3266 to i64
  %cond3268 = icmp ne i64 %cv3267, 0
  br i1 %cond3268, label %bb_rcgnn862, label %bb_rcgdone862
bb_rcgnn862:
  %v3269 = load i64, ptr %slot451, align 8
  %op3270 = sub i64 %v3269, 16
  store i64 %op3270, ptr %slot453, align 8
  %v3271 = load i64, ptr %slot451, align 8
  %p3272 = inttoptr i64 %v3271 to ptr
  %rgep3273 = getelementptr i8, ptr %p3272, i64 -16
  %ld3274 = load i64, ptr %rgep3273, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3274, ptr %slot454, align 8
  %v3275 = load i64, ptr %slot454, align 8
  %op3276 = and i64 %v3275, 4611686018427387906
  store i64 %op3276, ptr %slot455, align 8
  %v3277 = load i64, ptr %slot455, align 8
  %cmp3278 = icmp ne i64 %v3277, 0
  %cv3279 = zext i1 %cmp3278 to i32
  store i32 %cv3279, ptr %slot456, align 8
  %v3280 = load i32, ptr %slot456, align 8
  %cv3281 = zext i32 %v3280 to i64
  %cond3282 = icmp ne i64 %cv3281, 0
  br i1 %cond3282, label %bb_rcgclear862, label %bb_rcgcounted862
bb_rcgcounted862:
  %v3283 = load i64, ptr %slot451, align 8
  %op3284 = sub i64 %v3283, 24
  store i64 %op3284, ptr %slot457, align 8
  %v3285 = load i64, ptr %slot451, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  %rgep3287 = getelementptr i8, ptr %p3286, i64 -24
  %ld3288 = load i64, ptr %rgep3287, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3288, ptr %slot458, align 8
  %v3289 = load i64, ptr %slot458, align 8
  %op3290 = sub i64 %v3289, 1
  store i64 %op3290, ptr %slot459, align 8
  %v3291 = load i64, ptr %slot459, align 8
  %cmp3292 = icmp eq i64 %v3291, 0
  %cv3293 = zext i1 %cmp3292 to i32
  store i32 %cv3293, ptr %slot460, align 8
  %v3294 = load i32, ptr %slot460, align 8
  %cv3295 = zext i32 %v3294 to i64
  %cond3296 = icmp ne i64 %cv3295, 0
  br i1 %cond3296, label %bb_rcglast862, label %bb_rcgdec862
bb_rcglast862:
  %v3297 = load i64, ptr %slot451, align 8
  %op3298 = sub i64 %v3297, 32
  store i64 %op3298, ptr %slot461, align 8
  %v3299 = load i64, ptr %slot451, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %rgep3301 = getelementptr i8, ptr %p3300, i64 -32
  %ld3302 = load i64, ptr %rgep3301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3302, ptr %slot462, align 8
  %v3303 = load i64, ptr %slot462, align 8
  %cmp3304 = icmp ne i64 %v3303, 0
  %cv3305 = zext i1 %cmp3304 to i32
  store i32 %cv3305, ptr %slot463, align 8
  %v3306 = load i32, ptr %slot463, align 8
  %cv3307 = zext i32 %v3306 to i64
  %cond3308 = icmp ne i64 %cv3307, 0
  br i1 %cond3308, label %bb_rcgdec862, label %bb_rcgslow862
bb_rcgslow862:
  %v3309 = load i64, ptr %slot450, align 8
  %v3310 = load i64, ptr %slot447, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3309, i64 %v3310) nomerge, !dbg !136
  br label %bb_rcgdone862
bb_rcgdec862:
  %v3311 = load i64, ptr %slot459, align 8
  %v3312 = load i64, ptr %slot451, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  %rgep3314 = getelementptr i8, ptr %p3313, i64 -24
  store i64 %v3311, ptr %rgep3314, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear862
bb_rcgclear862:
  %v3315 = load i64, ptr %slot447, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i64 0, ptr %p3316, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone862
bb_rcgdone862:
  br label %bb_rcslotdone846
bb_rcslotowner846:
  %v3317 = load i64, ptr %slot33, align 8
  store i64 %v3317, ptr %slot464, align 8
  %v3318 = load i64, ptr %slot447, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  %ld3320 = load i64, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3320, ptr %slot465, align 8
  %v3321 = load i64, ptr %slot465, align 8
  %cmp3322 = icmp ne i64 %v3321, 0
  %cv3323 = zext i1 %cmp3322 to i32
  store i32 %cv3323, ptr %slot466, align 8
  %v3324 = load i32, ptr %slot466, align 8
  %cv3325 = zext i32 %v3324 to i64
  %cond3326 = icmp ne i64 %cv3325, 0
  br i1 %cond3326, label %bb_rcgnn877, label %bb_rcgdone877
bb_rcgnn877:
  %v3327 = load i64, ptr %slot465, align 8
  %op3328 = sub i64 %v3327, 16
  store i64 %op3328, ptr %slot467, align 8
  %v3329 = load i64, ptr %slot465, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %rgep3331 = getelementptr i8, ptr %p3330, i64 -16
  %ld3332 = load i64, ptr %rgep3331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3332, ptr %slot468, align 8
  %v3333 = load i64, ptr %slot468, align 8
  %op3334 = and i64 %v3333, 4611686018427387906
  store i64 %op3334, ptr %slot469, align 8
  %v3335 = load i64, ptr %slot469, align 8
  %cmp3336 = icmp ne i64 %v3335, 0
  %cv3337 = zext i1 %cmp3336 to i32
  store i32 %cv3337, ptr %slot470, align 8
  %v3338 = load i32, ptr %slot470, align 8
  %cv3339 = zext i32 %v3338 to i64
  %cond3340 = icmp ne i64 %cv3339, 0
  br i1 %cond3340, label %bb_rcgclear877, label %bb_rcgcounted877
bb_rcgcounted877:
  %v3341 = load i64, ptr %slot465, align 8
  %op3342 = sub i64 %v3341, 32
  store i64 %op3342, ptr %slot471, align 8
  %v3343 = load i64, ptr %slot465, align 8
  %p3344 = inttoptr i64 %v3343 to ptr
  %rgep3345 = getelementptr i8, ptr %p3344, i64 -32
  %ld3346 = load i64, ptr %rgep3345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3346, ptr %slot472, align 8
  %v3347 = load i64, ptr %slot472, align 8
  %op3348 = sub i64 %v3347, 1
  store i64 %op3348, ptr %slot473, align 8
  %v3349 = load i64, ptr %slot473, align 8
  %cmp3350 = icmp eq i64 %v3349, 0
  %cv3351 = zext i1 %cmp3350 to i32
  store i32 %cv3351, ptr %slot474, align 8
  %v3352 = load i32, ptr %slot474, align 8
  %cv3353 = zext i32 %v3352 to i64
  %cond3354 = icmp ne i64 %cv3353, 0
  br i1 %cond3354, label %bb_rcglast877, label %bb_rcgdec877
bb_rcglast877:
  %v3355 = load i64, ptr %slot465, align 8
  %op3356 = sub i64 %v3355, 24
  store i64 %op3356, ptr %slot475, align 8
  %v3357 = load i64, ptr %slot465, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  %rgep3359 = getelementptr i8, ptr %p3358, i64 -24
  %ld3360 = load i64, ptr %rgep3359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3360, ptr %slot476, align 8
  %v3361 = load i64, ptr %slot476, align 8
  %cmp3362 = icmp ne i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot477, align 8
  %v3364 = load i32, ptr %slot477, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcgdec877, label %bb_rcgslow877
bb_rcgslow877:
  %v3367 = load i64, ptr %slot464, align 8
  %v3368 = load i64, ptr %slot447, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3367, i64 %v3368) nomerge, !dbg !136
  br label %bb_rcgdone877
bb_rcgdec877:
  %v3369 = load i64, ptr %slot473, align 8
  %v3370 = load i64, ptr %slot465, align 8
  %p3371 = inttoptr i64 %v3370 to ptr
  %rgep3372 = getelementptr i8, ptr %p3371, i64 -32
  store i64 %v3369, ptr %rgep3372, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear877
bb_rcgclear877:
  %v3373 = load i64, ptr %slot447, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i64 0, ptr %p3374, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone877
bb_rcgdone877:
  br label %bb_rcslotdone846
bb_rcslotdone846:
  %v3375 = load i64, ptr %slot445, align 8
  ret i64 %v3375
bb_i33:
  %p3376 = inttoptr i64 ptrtoint (ptr @myl_lit_1aca0d6090acebe519e6585d6572c624809ab30b249e864b7ef1c235b02f902a to i64) to ptr
  %ld3377 = load i64, ptr %p3376, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3377, ptr %slot478, align 8
  %v3378 = load i64, ptr %slot478, align 8
  %v3379 = load i64, ptr %slot26, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i64 %v3378, ptr %p3380, align 8, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot26, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i64, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3383, ptr %slot479, align 8
  %v3384 = load i64, ptr %slot479, align 8
  %v3385 = load i64, ptr %slot13, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i64 %v3384, ptr %p3386, align 8, !alias.scope !3, !noalias !4
  %v3387 = load i64, ptr %slot13, align 8
  store i64 %v3387, ptr %slot480, align 8
  %v3388 = load i64, ptr %slot15, align 8
  store i64 %v3388, ptr %slot481, align 8
  %v3389 = load i64, ptr %slot480, align 8
  %v3390 = load i64, ptr %slot481, align 8
  %p3391 = inttoptr i64 %v3389 to ptr
  %p3392 = inttoptr i64 %v3390 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3392, ptr %p3391, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot10, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 2, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot9, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  store i32 1, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  %v3397 = load i64, ptr %slot11, align 8
  store i64 %v3397, ptr %slot482, align 8
  %v3398 = load i64, ptr %slot15, align 8
  store i64 %v3398, ptr %slot483, align 8
  %v3399 = load i64, ptr %slot483, align 8
  %v3400 = load i64, ptr %slot482, align 8
  %p3401 = inttoptr i64 %v3399 to ptr
  %p3402 = inttoptr i64 %v3400 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3402, ptr %p3401, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot6, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i32 2, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot10, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %ld3407 = load i32, ptr %p3406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3407, ptr %slot484, align 8
  %v3408 = load i32, ptr %slot484, align 8
  %v3409 = load i64, ptr %slot6, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  store i32 %v3408, ptr %p3410, align 4, !alias.scope !3, !noalias !4
  %v3411 = load i64, ptr %slot9, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  store i32 0, ptr %p3412, align 4, !alias.scope !3, !noalias !4
  %v3413 = load i64, ptr %slot5, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i32 1, ptr %p3414, align 4, !alias.scope !3, !noalias !4
  %v3415 = load i64, ptr %slot482, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %ld3417 = load i64, ptr %p3416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3417, ptr %slot485, align 8
  %v3418 = load i64, ptr %slot485, align 8
  %v3419 = load i64, ptr %slot26, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  store i64 %v3418, ptr %p3420, align 8, !alias.scope !3, !noalias !4
  %v3421 = load i64, ptr %slot26, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %ld3423 = load i64, ptr %p3422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3423, ptr %slot486, align 8
  %v3424 = load i64, ptr %slot26, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  %ld3426 = load i64, ptr %p3425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3426, ptr %slot487, align 8
  %v3427 = load i64, ptr %slot487, align 8
  %v3428 = load i64, ptr %slot13, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  store i64 %v3427, ptr %p3429, align 8, !alias.scope !3, !noalias !4
  %v3430 = load i64, ptr %slot13, align 8
  store i64 %v3430, ptr %slot488, align 8
  %v3431 = load i64, ptr %slot15, align 8
  store i64 %v3431, ptr %slot489, align 8
  %v3432 = load i64, ptr %slot34, align 8
  store i64 %v3432, ptr %slot490, align 8
  %v3433 = load i64, ptr %slot488, align 8
  %p3435 = inttoptr i64 %v3433 to ptr
  %gep3436 = getelementptr i8, ptr %p3435, i64 0
  %op3434 = ptrtoint ptr %gep3436 to i64
  store i64 %op3434, ptr %slot491, align 8
  %v3437 = load i64, ptr %slot491, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  %ld3439 = load i64, ptr %p3438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3439, ptr %slot492, align 8
  %v3440 = load i64, ptr %slot492, align 8
  %cmp3441 = icmp ne i64 %v3440, 0
  %cv3442 = zext i1 %cmp3441 to i32
  store i32 %cv3442, ptr %slot493, align 8
  %v3443 = load i32, ptr %slot493, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcmoveheader987, label %bb_rcmovenext987
bb_rcmoveheader987:
  %v3446 = load i64, ptr %slot492, align 8
  %op3447 = sub i64 %v3446, 16
  store i64 %op3447, ptr %slot494, align 8
  %v3448 = load i64, ptr %slot492, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  %rgep3450 = getelementptr i8, ptr %p3449, i64 -16
  %ld3451 = load i64, ptr %rgep3450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3451, ptr %slot495, align 8
  %v3452 = load i64, ptr %slot495, align 8
  %op3453 = and i64 %v3452, 5764607523034234881
  store i64 %op3453, ptr %slot496, align 8
  %v3454 = load i64, ptr %slot496, align 8
  %cmp3455 = icmp ne i64 %v3454, 0
  %cv3456 = zext i1 %cmp3455 to i32
  store i32 %cv3456, ptr %slot497, align 8
  %v3457 = load i32, ptr %slot497, align 8
  %cv3458 = zext i32 %v3457 to i64
  %cond3459 = icmp ne i64 %cv3458, 0
  br i1 %cond3459, label %bb_rcmoveslow984, label %bb_rcmovenext987
bb_rcmovenext987:
  %v3460 = load i64, ptr %slot488, align 8
  %v3461 = load i64, ptr %slot489, align 8
  %p3462 = inttoptr i64 %v3460 to ptr
  %p3463 = inttoptr i64 %v3461 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3463, ptr %p3462, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3464 = load i64, ptr %slot488, align 8
  %p3465 = inttoptr i64 %v3464 to ptr
  store i64 0, ptr %p3465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved984
bb_rcmoveslow984:
  %v3466 = load i64, ptr %slot33, align 8
  %v3467 = load i64, ptr %slot489, align 8
  %v3468 = load i64, ptr %slot488, align 8
  %v3469 = load i64, ptr %slot490, align 8
  %cv3470 = trunc i64 %v3469 to i32
  %call3471 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3466, i64 %v3467, i64 %v3468, i32 %cv3470) nomerge, !dbg !138
  store i32 %call3471, ptr %slot498, align 8
  %v3472 = load i32, ptr %slot498, align 8
  %cv3473 = zext i32 %v3472 to i64
  %cond3474 = icmp ne i64 %cv3473, 0
  br i1 %cond3474, label %bb_rcsuccess994, label %bb_rcfailure994
bb_rcfailure994:
  %v3475 = load i64, ptr %slot33, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %call3477 = call i32 @myl_rc_take_failure(ptr %p3476) nomerge, !dbg !138
  store i32 %call3477, ptr %slot499, align 8
  %v3478 = load i64, ptr %slot1, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  %v3480 = load i32, ptr %slot499, align 8
  %call3481 = call i32 @myl_qbe_rc_status(ptr %p3479, i32 %v3480) nomerge, !dbg !138
  store i32 %call3481, ptr %slot500, align 8
  br label %bb_failure
bb_rcsuccess994:
  br label %bb_rcmoved984
bb_rcmoved984:
  %v3482 = load i64, ptr %slot5, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  store i32 0, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  %v3484 = load i64, ptr %slot10, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  store i32 2, ptr %p3485, align 4, !alias.scope !3, !noalias !4
  %v3486 = load i64, ptr %slot9, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i32 1, ptr %p3487, align 4, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot15, align 8
  store i64 %v3488, ptr %slot501, align 8
  %v3489 = load i64, ptr %slot501, align 8
  %p3490 = inttoptr i64 %v3489 to ptr
  %ld3491 = load i64, ptr %p3490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3491, ptr %slot502, align 8
  %v3492 = load i64, ptr %slot9, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i32 0, ptr %p3493, align 4, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot5, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  %ld3496 = load i32, ptr %p3495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3496, ptr %slot503, align 8
  %v3497 = load i32, ptr %slot503, align 8
  %cv3498 = zext i32 %v3497 to i64
  %cond3499 = icmp ne i64 %cv3498, 0
  br i1 %cond3499, label %bb_rcslotdrop1005, label %bb_rcslotdone1005
bb_rcslotdrop1005:
  %v3500 = load i64, ptr %slot5, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i32 0, ptr %p3501, align 4, !alias.scope !3, !noalias !4
  %v3502 = load i64, ptr %slot11, align 8
  store i64 %v3502, ptr %slot504, align 8
  %v3503 = load i64, ptr %slot6, align 8
  %p3504 = inttoptr i64 %v3503 to ptr
  %ld3505 = load i32, ptr %p3504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3505, ptr %slot505, align 8
  %v3506 = load i32, ptr %slot505, align 8
  %op3507 = and i32 %v3506, 28
  store i32 %op3507, ptr %slot506, align 8
  %v3508 = load i32, ptr %slot506, align 8
  %cv3509 = zext i32 %v3508 to i64
  %cond3510 = icmp ne i64 %cv3509, 0
  br i1 %cond3510, label %bb_rcslotrole1005, label %bb_rcslotowner1005
bb_rcslotrole1005:
  %v3511 = load i64, ptr %slot33, align 8
  store i64 %v3511, ptr %slot507, align 8
  %v3512 = load i64, ptr %slot504, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  %ld3514 = load i64, ptr %p3513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3514, ptr %slot508, align 8
  %v3515 = load i64, ptr %slot508, align 8
  %cmp3516 = icmp ne i64 %v3515, 0
  %cv3517 = zext i1 %cmp3516 to i32
  store i32 %cv3517, ptr %slot509, align 8
  %v3518 = load i32, ptr %slot509, align 8
  %cv3519 = zext i32 %v3518 to i64
  %cond3520 = icmp ne i64 %cv3519, 0
  br i1 %cond3520, label %bb_rcgnn1021, label %bb_rcgdone1021
bb_rcgnn1021:
  %v3521 = load i64, ptr %slot508, align 8
  %op3522 = sub i64 %v3521, 16
  store i64 %op3522, ptr %slot510, align 8
  %v3523 = load i64, ptr %slot508, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %rgep3525 = getelementptr i8, ptr %p3524, i64 -16
  %ld3526 = load i64, ptr %rgep3525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3526, ptr %slot511, align 8
  %v3527 = load i64, ptr %slot511, align 8
  %op3528 = and i64 %v3527, 4611686018427387906
  store i64 %op3528, ptr %slot512, align 8
  %v3529 = load i64, ptr %slot512, align 8
  %cmp3530 = icmp ne i64 %v3529, 0
  %cv3531 = zext i1 %cmp3530 to i32
  store i32 %cv3531, ptr %slot513, align 8
  %v3532 = load i32, ptr %slot513, align 8
  %cv3533 = zext i32 %v3532 to i64
  %cond3534 = icmp ne i64 %cv3533, 0
  br i1 %cond3534, label %bb_rcgclear1021, label %bb_rcgcounted1021
bb_rcgcounted1021:
  %v3535 = load i64, ptr %slot508, align 8
  %op3536 = sub i64 %v3535, 24
  store i64 %op3536, ptr %slot514, align 8
  %v3537 = load i64, ptr %slot508, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %rgep3539 = getelementptr i8, ptr %p3538, i64 -24
  %ld3540 = load i64, ptr %rgep3539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3540, ptr %slot515, align 8
  %v3541 = load i64, ptr %slot515, align 8
  %op3542 = sub i64 %v3541, 1
  store i64 %op3542, ptr %slot516, align 8
  %v3543 = load i64, ptr %slot516, align 8
  %cmp3544 = icmp eq i64 %v3543, 0
  %cv3545 = zext i1 %cmp3544 to i32
  store i32 %cv3545, ptr %slot517, align 8
  %v3546 = load i32, ptr %slot517, align 8
  %cv3547 = zext i32 %v3546 to i64
  %cond3548 = icmp ne i64 %cv3547, 0
  br i1 %cond3548, label %bb_rcglast1021, label %bb_rcgdec1021
bb_rcglast1021:
  %v3549 = load i64, ptr %slot508, align 8
  %op3550 = sub i64 %v3549, 32
  store i64 %op3550, ptr %slot518, align 8
  %v3551 = load i64, ptr %slot508, align 8
  %p3552 = inttoptr i64 %v3551 to ptr
  %rgep3553 = getelementptr i8, ptr %p3552, i64 -32
  %ld3554 = load i64, ptr %rgep3553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3554, ptr %slot519, align 8
  %v3555 = load i64, ptr %slot519, align 8
  %cmp3556 = icmp ne i64 %v3555, 0
  %cv3557 = zext i1 %cmp3556 to i32
  store i32 %cv3557, ptr %slot520, align 8
  %v3558 = load i32, ptr %slot520, align 8
  %cv3559 = zext i32 %v3558 to i64
  %cond3560 = icmp ne i64 %cv3559, 0
  br i1 %cond3560, label %bb_rcgdec1021, label %bb_rcgslow1021
bb_rcgslow1021:
  %v3561 = load i64, ptr %slot507, align 8
  %v3562 = load i64, ptr %slot504, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3561, i64 %v3562) nomerge, !dbg !138
  br label %bb_rcgdone1021
bb_rcgdec1021:
  %v3563 = load i64, ptr %slot516, align 8
  %v3564 = load i64, ptr %slot508, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  %rgep3566 = getelementptr i8, ptr %p3565, i64 -24
  store i64 %v3563, ptr %rgep3566, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1021
bb_rcgclear1021:
  %v3567 = load i64, ptr %slot504, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  store i64 0, ptr %p3568, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1021
bb_rcgdone1021:
  br label %bb_rcslotdone1005
bb_rcslotowner1005:
  %v3569 = load i64, ptr %slot33, align 8
  store i64 %v3569, ptr %slot521, align 8
  %v3570 = load i64, ptr %slot504, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %ld3572 = load i64, ptr %p3571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3572, ptr %slot522, align 8
  %v3573 = load i64, ptr %slot522, align 8
  %cmp3574 = icmp ne i64 %v3573, 0
  %cv3575 = zext i1 %cmp3574 to i32
  store i32 %cv3575, ptr %slot523, align 8
  %v3576 = load i32, ptr %slot523, align 8
  %cv3577 = zext i32 %v3576 to i64
  %cond3578 = icmp ne i64 %cv3577, 0
  br i1 %cond3578, label %bb_rcgnn1036, label %bb_rcgdone1036
bb_rcgnn1036:
  %v3579 = load i64, ptr %slot522, align 8
  %op3580 = sub i64 %v3579, 16
  store i64 %op3580, ptr %slot524, align 8
  %v3581 = load i64, ptr %slot522, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %rgep3583 = getelementptr i8, ptr %p3582, i64 -16
  %ld3584 = load i64, ptr %rgep3583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3584, ptr %slot525, align 8
  %v3585 = load i64, ptr %slot525, align 8
  %op3586 = and i64 %v3585, 4611686018427387906
  store i64 %op3586, ptr %slot526, align 8
  %v3587 = load i64, ptr %slot526, align 8
  %cmp3588 = icmp ne i64 %v3587, 0
  %cv3589 = zext i1 %cmp3588 to i32
  store i32 %cv3589, ptr %slot527, align 8
  %v3590 = load i32, ptr %slot527, align 8
  %cv3591 = zext i32 %v3590 to i64
  %cond3592 = icmp ne i64 %cv3591, 0
  br i1 %cond3592, label %bb_rcgclear1036, label %bb_rcgcounted1036
bb_rcgcounted1036:
  %v3593 = load i64, ptr %slot522, align 8
  %op3594 = sub i64 %v3593, 32
  store i64 %op3594, ptr %slot528, align 8
  %v3595 = load i64, ptr %slot522, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %rgep3597 = getelementptr i8, ptr %p3596, i64 -32
  %ld3598 = load i64, ptr %rgep3597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3598, ptr %slot529, align 8
  %v3599 = load i64, ptr %slot529, align 8
  %op3600 = sub i64 %v3599, 1
  store i64 %op3600, ptr %slot530, align 8
  %v3601 = load i64, ptr %slot530, align 8
  %cmp3602 = icmp eq i64 %v3601, 0
  %cv3603 = zext i1 %cmp3602 to i32
  store i32 %cv3603, ptr %slot531, align 8
  %v3604 = load i32, ptr %slot531, align 8
  %cv3605 = zext i32 %v3604 to i64
  %cond3606 = icmp ne i64 %cv3605, 0
  br i1 %cond3606, label %bb_rcglast1036, label %bb_rcgdec1036
bb_rcglast1036:
  %v3607 = load i64, ptr %slot522, align 8
  %op3608 = sub i64 %v3607, 24
  store i64 %op3608, ptr %slot532, align 8
  %v3609 = load i64, ptr %slot522, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %rgep3611 = getelementptr i8, ptr %p3610, i64 -24
  %ld3612 = load i64, ptr %rgep3611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3612, ptr %slot533, align 8
  %v3613 = load i64, ptr %slot533, align 8
  %cmp3614 = icmp ne i64 %v3613, 0
  %cv3615 = zext i1 %cmp3614 to i32
  store i32 %cv3615, ptr %slot534, align 8
  %v3616 = load i32, ptr %slot534, align 8
  %cv3617 = zext i32 %v3616 to i64
  %cond3618 = icmp ne i64 %cv3617, 0
  br i1 %cond3618, label %bb_rcgdec1036, label %bb_rcgslow1036
bb_rcgslow1036:
  %v3619 = load i64, ptr %slot521, align 8
  %v3620 = load i64, ptr %slot504, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3619, i64 %v3620) nomerge, !dbg !138
  br label %bb_rcgdone1036
bb_rcgdec1036:
  %v3621 = load i64, ptr %slot530, align 8
  %v3622 = load i64, ptr %slot522, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %rgep3624 = getelementptr i8, ptr %p3623, i64 -32
  store i64 %v3621, ptr %rgep3624, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1036
bb_rcgclear1036:
  %v3625 = load i64, ptr %slot504, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i64 0, ptr %p3626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1036
bb_rcgdone1036:
  br label %bb_rcslotdone1005
bb_rcslotdone1005:
  %v3627 = load i64, ptr %slot502, align 8
  ret i64 %v3627
bb_i35:
  %v3628 = load i64, ptr %slot22, align 8
  %v3629 = load i64, ptr %slot26, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  store i64 %v3628, ptr %p3630, align 8, !alias.scope !3, !noalias !4
  %v3631 = load i64, ptr %slot16, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  %ld3633 = load i64, ptr %p3632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3633, ptr %slot535, align 8
  %v3634 = load i64, ptr %slot535, align 8
  %v3635 = load i64, ptr %slot26, align 8
  %p3636 = inttoptr i64 %v3635 to ptr
  store i64 %v3634, ptr %p3636, align 8, !alias.scope !3, !noalias !4
  %v3637 = load i64, ptr %slot22, align 8
  %v3638 = load i64, ptr %slot27, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i64 %v3637, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot27, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i64, ptr %p3641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3642, ptr %slot536, align 8
  %v3643 = load i64, ptr %slot536, align 8
  %op3644 = add i64 %v3643, 0
  store i64 %op3644, ptr %slot537, align 8
  %v3645 = load i64, ptr %slot537, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  %ld3647 = load i64, ptr %p3646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3647, ptr %slot538, align 8
  %v3648 = load i64, ptr %slot538, align 8
  %v3649 = load i64, ptr %slot27, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  store i64 %v3648, ptr %p3650, align 8, !alias.scope !3, !noalias !4
  %v3651 = load i64, ptr %slot7, align 8
  %p3652 = inttoptr i64 %v3651 to ptr
  %ld3653 = load i32, ptr %p3652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3653, ptr %slot539, align 8
  %v3654 = load i32, ptr %slot539, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcslotdrop1128, label %bb_rcslotdone1128
bb_rcslotdrop1128:
  %v3657 = load i64, ptr %slot7, align 8
  %p3658 = inttoptr i64 %v3657 to ptr
  store i32 0, ptr %p3658, align 4, !alias.scope !3, !noalias !4
  %v3659 = load i64, ptr %slot12, align 8
  store i64 %v3659, ptr %slot540, align 8
  %v3660 = load i64, ptr %slot8, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  %ld3662 = load i32, ptr %p3661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3662, ptr %slot541, align 8
  %v3663 = load i32, ptr %slot541, align 8
  %op3664 = and i32 %v3663, 28
  store i32 %op3664, ptr %slot542, align 8
  %v3665 = load i32, ptr %slot542, align 8
  %cv3666 = zext i32 %v3665 to i64
  %cond3667 = icmp ne i64 %cv3666, 0
  br i1 %cond3667, label %bb_rcslotrole1128, label %bb_rcslotowner1128
bb_rcslotrole1128:
  %v3668 = load i64, ptr %slot33, align 8
  store i64 %v3668, ptr %slot543, align 8
  %v3669 = load i64, ptr %slot543, align 8
  %v3670 = load i64, ptr %slot540, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3669, i64 %v3670) nomerge, !dbg !140
  br label %bb_rcslotdone1128
bb_rcslotowner1128:
  %v3671 = load i64, ptr %slot33, align 8
  store i64 %v3671, ptr %slot544, align 8
  %v3672 = load i64, ptr %slot544, align 8
  %v3673 = load i64, ptr %slot540, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3672, i64 %v3673) nomerge, !dbg !140
  br label %bb_rcslotdone1128
bb_rcslotdone1128:
  %v3674 = load i64, ptr %slot26, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  %ld3676 = load i64, ptr %p3675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3676, ptr %slot545, align 8
  %v3677 = load i64, ptr %slot27, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %ld3679 = load i64, ptr %p3678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3679, ptr %slot546, align 8
  %v3680 = load i64, ptr %slot1, align 8
  %v3681 = load i64, ptr %slot545, align 8
  %v3682 = load i64, ptr %slot546, align 8
  %call3683 = call i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64 %v3680, i64 %v3681, i64 %v3682) nomerge, !dbg !142
  store i64 %call3683, ptr %slot547, align 8
  %v3684 = load i64, ptr %slot547, align 8
  %v3685 = load i64, ptr %slot26, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  store i64 %v3684, ptr %p3686, align 8, !alias.scope !3, !noalias !4
  %v3687 = load i64, ptr %slot5, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %ld3689 = load i32, ptr %p3688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3689, ptr %slot548, align 8
  %v3690 = load i32, ptr %slot548, align 8
  %cv3691 = zext i32 %v3690 to i64
  %cond3692 = icmp ne i64 %cv3691, 0
  br i1 %cond3692, label %bb_rcslotdrop1140, label %bb_rcslotdone1140
bb_rcslotdrop1140:
  %v3693 = load i64, ptr %slot5, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  store i32 0, ptr %p3694, align 4, !alias.scope !3, !noalias !4
  %v3695 = load i64, ptr %slot11, align 8
  store i64 %v3695, ptr %slot549, align 8
  %v3696 = load i64, ptr %slot6, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i32, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3698, ptr %slot550, align 8
  %v3699 = load i32, ptr %slot550, align 8
  %op3700 = and i32 %v3699, 28
  store i32 %op3700, ptr %slot551, align 8
  %v3701 = load i32, ptr %slot551, align 8
  %cv3702 = zext i32 %v3701 to i64
  %cond3703 = icmp ne i64 %cv3702, 0
  br i1 %cond3703, label %bb_rcslotrole1140, label %bb_rcslotowner1140
bb_rcslotrole1140:
  %v3704 = load i64, ptr %slot33, align 8
  store i64 %v3704, ptr %slot552, align 8
  %v3705 = load i64, ptr %slot552, align 8
  %v3706 = load i64, ptr %slot549, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3705, i64 %v3706) nomerge, !dbg !142
  br label %bb_rcslotdone1140
bb_rcslotowner1140:
  %v3707 = load i64, ptr %slot33, align 8
  store i64 %v3707, ptr %slot553, align 8
  %v3708 = load i64, ptr %slot553, align 8
  %v3709 = load i64, ptr %slot549, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3708, i64 %v3709) nomerge, !dbg !142
  br label %bb_rcslotdone1140
bb_rcslotdone1140:
  %v3710 = load i64, ptr %slot26, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %ld3712 = load i64, ptr %p3711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3712, ptr %slot554, align 8
  %v3713 = load i64, ptr %slot26, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %ld3715 = load i64, ptr %p3714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3715, ptr %slot555, align 8
  %v3716 = load i64, ptr %slot555, align 8
  %v3717 = load i64, ptr %slot13, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  store i64 %v3716, ptr %p3718, align 8, !alias.scope !3, !noalias !4
  %v3719 = load i64, ptr %slot13, align 8
  store i64 %v3719, ptr %slot556, align 8
  %v3720 = load i64, ptr %slot5, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  %ld3722 = load i32, ptr %p3721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3722, ptr %slot557, align 8
  %v3723 = load i64, ptr %slot6, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i32, ptr %p3724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3725, ptr %slot558, align 8
  %v3726 = load i32, ptr %slot558, align 8
  %op3727 = and i32 %v3726, 24
  store i32 %op3727, ptr %slot558, align 8
  %v3728 = load i32, ptr %slot558, align 8
  %cmp3729 = icmp eq i32 %v3728, 0
  %cv3730 = zext i1 %cmp3729 to i32
  store i32 %cv3730, ptr %slot559, align 8
  %v3731 = load i32, ptr %slot557, align 8
  %v3732 = load i32, ptr %slot559, align 8
  %op3733 = and i32 %v3731, %v3732
  store i32 %op3733, ptr %slot560, align 8
  %v3734 = load i32, ptr %slot560, align 8
  %cv3735 = zext i32 %v3734 to i64
  %cond3736 = icmp ne i64 %cv3735, 0
  br i1 %cond3736, label %bb_rctake1150, label %bb_rccopy1150
bb_rctake1150:
  %v3737 = load i64, ptr %slot15, align 8
  store i64 %v3737, ptr %slot561, align 8
  %v3738 = load i64, ptr %slot34, align 8
  store i64 %v3738, ptr %slot562, align 8
  %v3739 = load i64, ptr %slot556, align 8
  %v3740 = load i64, ptr %slot561, align 8
  %op3741 = sub i64 %v3739, %v3740
  store i64 %op3741, ptr %slot563, align 8
  %v3742 = load i64, ptr %slot561, align 8
  %v3743 = load i64, ptr %slot556, align 8
  %op3744 = sub i64 %v3742, %v3743
  store i64 %op3744, ptr %slot564, align 8
  %v3745 = load i64, ptr %slot563, align 8
  %cmp3746 = icmp ult i64 %v3745, 8
  %cv3747 = zext i1 %cmp3746 to i32
  store i32 %cv3747, ptr %slot565, align 8
  %v3748 = load i64, ptr %slot564, align 8
  %cmp3749 = icmp ult i64 %v3748, 8
  %cv3750 = zext i1 %cmp3749 to i32
  store i32 %cv3750, ptr %slot566, align 8
  %v3751 = load i32, ptr %slot565, align 8
  %v3752 = load i32, ptr %slot566, align 8
  %op3753 = or i32 %v3751, %v3752
  store i32 %op3753, ptr %slot567, align 8
  %v3754 = load i32, ptr %slot567, align 8
  %cv3755 = zext i32 %v3754 to i64
  %cond3756 = icmp ne i64 %cv3755, 0
  br i1 %cond3756, label %bb_rcmoveslow1159, label %bb_rcmovecheck1159
bb_rcmovecheck1159:
  %v3757 = load i64, ptr %slot556, align 8
  %p3759 = inttoptr i64 %v3757 to ptr
  %gep3760 = getelementptr i8, ptr %p3759, i64 0
  %op3758 = ptrtoint ptr %gep3760 to i64
  store i64 %op3758, ptr %slot568, align 8
  %v3761 = load i64, ptr %slot568, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %ld3763 = load i64, ptr %p3762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3763, ptr %slot569, align 8
  %v3764 = load i64, ptr %slot569, align 8
  %cmp3765 = icmp ne i64 %v3764, 0
  %cv3766 = zext i1 %cmp3765 to i32
  store i32 %cv3766, ptr %slot570, align 8
  %v3767 = load i32, ptr %slot570, align 8
  %cv3768 = zext i32 %v3767 to i64
  %cond3769 = icmp ne i64 %cv3768, 0
  br i1 %cond3769, label %bb_rcmoveheader1167, label %bb_rcmovenext1167
bb_rcmoveheader1167:
  %v3770 = load i64, ptr %slot569, align 8
  %op3771 = sub i64 %v3770, 16
  store i64 %op3771, ptr %slot571, align 8
  %v3772 = load i64, ptr %slot569, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  %rgep3774 = getelementptr i8, ptr %p3773, i64 -16
  %ld3775 = load i64, ptr %rgep3774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3775, ptr %slot572, align 8
  %v3776 = load i64, ptr %slot572, align 8
  %op3777 = and i64 %v3776, 5764607523034234881
  store i64 %op3777, ptr %slot573, align 8
  %v3778 = load i64, ptr %slot573, align 8
  %cmp3779 = icmp ne i64 %v3778, 0
  %cv3780 = zext i1 %cmp3779 to i32
  store i32 %cv3780, ptr %slot574, align 8
  %v3781 = load i32, ptr %slot574, align 8
  %cv3782 = zext i32 %v3781 to i64
  %cond3783 = icmp ne i64 %cv3782, 0
  br i1 %cond3783, label %bb_rcmoveslow1159, label %bb_rcmovenext1167
bb_rcmovenext1167:
  %v3784 = load i64, ptr %slot556, align 8
  %v3785 = load i64, ptr %slot561, align 8
  %p3786 = inttoptr i64 %v3784 to ptr
  %p3787 = inttoptr i64 %v3785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3787, ptr %p3786, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3788 = load i64, ptr %slot556, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  store i64 0, ptr %p3789, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1159
bb_rcmoveslow1159:
  %v3790 = load i64, ptr %slot33, align 8
  %v3791 = load i64, ptr %slot561, align 8
  %v3792 = load i64, ptr %slot556, align 8
  %v3793 = load i64, ptr %slot562, align 8
  %cv3794 = trunc i64 %v3793 to i32
  %call3795 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v3790, i64 %v3791, i64 %v3792, i32 %cv3794) nomerge, !dbg !144
  store i32 %call3795, ptr %slot575, align 8
  %v3796 = load i32, ptr %slot575, align 8
  %cv3797 = zext i32 %v3796 to i64
  %cond3798 = icmp ne i64 %cv3797, 0
  br i1 %cond3798, label %bb_rcsuccess1174, label %bb_rcfailure1174
bb_rcfailure1174:
  %v3799 = load i64, ptr %slot33, align 8
  %p3800 = inttoptr i64 %v3799 to ptr
  %call3801 = call i32 @myl_rc_take_failure(ptr %p3800) nomerge, !dbg !144
  store i32 %call3801, ptr %slot576, align 8
  %v3802 = load i64, ptr %slot1, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  %v3804 = load i32, ptr %slot576, align 8
  %call3805 = call i32 @myl_qbe_rc_status(ptr %p3803, i32 %v3804) nomerge, !dbg !144
  store i32 %call3805, ptr %slot577, align 8
  br label %bb_failure
bb_rcsuccess1174:
  br label %bb_rcmoved1159
bb_rcmoved1159:
  %v3806 = load i64, ptr %slot5, align 8
  %p3807 = inttoptr i64 %v3806 to ptr
  store i32 0, ptr %p3807, align 4, !alias.scope !3, !noalias !4
  %v3808 = load i64, ptr %slot10, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  store i32 2, ptr %p3809, align 4, !alias.scope !3, !noalias !4
  %v3810 = load i64, ptr %slot9, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i32 1, ptr %p3811, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1150
bb_rccopy1150:
  %v3812 = load i64, ptr %slot15, align 8
  store i64 %v3812, ptr %slot578, align 8
  %v3813 = load i64, ptr %slot34, align 8
  store i64 %v3813, ptr %slot579, align 8
  %v3814 = load i64, ptr %slot556, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  %ld3816 = load i64, ptr %p3815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3816, ptr %slot580, align 8
  %v3817 = load i64, ptr %slot580, align 8
  %cmp3818 = icmp ne i64 %v3817, 0
  %cv3819 = zext i1 %cmp3818 to i32
  store i32 %cv3819, ptr %slot581, align 8
  %v3820 = load i32, ptr %slot581, align 8
  %cv3821 = zext i32 %v3820 to i64
  %cond3822 = icmp ne i64 %cv3821, 0
  br i1 %cond3822, label %bb_rcgnn1183, label %bb_rcgplain1183
bb_rcgnn1183:
  %v3823 = load i64, ptr %slot580, align 8
  %op3824 = sub i64 %v3823, 16
  store i64 %op3824, ptr %slot582, align 8
  %v3825 = load i64, ptr %slot580, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %rgep3827 = getelementptr i8, ptr %p3826, i64 -16
  %ld3828 = load i64, ptr %rgep3827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3828, ptr %slot583, align 8
  %v3829 = load i64, ptr %slot583, align 8
  %op3830 = and i64 %v3829, 4611686018427387906
  store i64 %op3830, ptr %slot584, align 8
  %v3831 = load i64, ptr %slot584, align 8
  %cmp3832 = icmp ne i64 %v3831, 0
  %cv3833 = zext i1 %cmp3832 to i32
  store i32 %cv3833, ptr %slot585, align 8
  %v3834 = load i32, ptr %slot585, align 8
  %cv3835 = zext i32 %v3834 to i64
  %cond3836 = icmp ne i64 %cv3835, 0
  br i1 %cond3836, label %bb_rcgspecial1183, label %bb_rcginc1183
bb_rcginc1183:
  %v3837 = load i64, ptr %slot580, align 8
  %op3838 = sub i64 %v3837, 32
  store i64 %op3838, ptr %slot586, align 8
  %v3839 = load i64, ptr %slot580, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %rgep3841 = getelementptr i8, ptr %p3840, i64 -32
  %ld3842 = load i64, ptr %rgep3841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3842, ptr %slot587, align 8
  %v3843 = load i64, ptr %slot587, align 8
  %op3844 = add i64 %v3843, 1
  store i64 %op3844, ptr %slot588, align 8
  %v3845 = load i64, ptr %slot588, align 8
  %cmp3846 = icmp eq i64 %v3845, 0
  %cv3847 = zext i1 %cmp3846 to i32
  store i32 %cv3847, ptr %slot589, align 8
  %v3848 = load i32, ptr %slot589, align 8
  %cv3849 = zext i32 %v3848 to i64
  %cond3850 = icmp ne i64 %cv3849, 0
  br i1 %cond3850, label %bb_rcglimit1183, label %bb_rcgcapacity1183
bb_rcglimit1183:
  %v3851 = load i64, ptr %slot1, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %call3853 = call i32 @myl_qbe_rc_status(ptr %p3852, i32 2) nomerge, !dbg !144
  store i32 %call3853, ptr %slot590, align 8
  br label %bb_failure
bb_rcgcapacity1183:
  %v3854 = load i64, ptr %slot588, align 8
  %v3855 = load i64, ptr %slot580, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %rgep3857 = getelementptr i8, ptr %p3856, i64 -32
  store i64 %v3854, ptr %rgep3857, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1183
bb_rcgspecial1183:
  %v3858 = load i64, ptr %slot583, align 8
  %op3859 = and i64 %v3858, 4611686018427387904
  store i64 %op3859, ptr %slot591, align 8
  %v3860 = load i64, ptr %slot591, align 8
  %cmp3861 = icmp ne i64 %v3860, 0
  %cv3862 = zext i1 %cmp3861 to i32
  store i32 %cv3862, ptr %slot592, align 8
  %v3863 = load i32, ptr %slot592, align 8
  %cv3864 = zext i32 %v3863 to i64
  %cond3865 = icmp ne i64 %cv3864, 0
  br i1 %cond3865, label %bb_rcgslow1183, label %bb_rcgplain1183
bb_rcgslow1183:
  %v3866 = load i64, ptr %slot33, align 8
  %v3867 = load i64, ptr %slot578, align 8
  %v3868 = load i64, ptr %slot556, align 8
  %v3869 = load i64, ptr %slot579, align 8
  %cv3870 = trunc i64 %v3869 to i32
  %call3871 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v3866, i64 %v3867, i64 %v3868, i32 %cv3870) nomerge, !dbg !144
  store i32 %call3871, ptr %slot593, align 8
  %v3872 = load i32, ptr %slot593, align 8
  %cv3873 = zext i32 %v3872 to i64
  %cond3874 = icmp ne i64 %cv3873, 0
  br i1 %cond3874, label %bb_rcsuccess1197, label %bb_rcfailure1197
bb_rcfailure1197:
  %v3875 = load i64, ptr %slot33, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  %call3877 = call i32 @myl_rc_take_failure(ptr %p3876) nomerge, !dbg !144
  store i32 %call3877, ptr %slot594, align 8
  %v3878 = load i64, ptr %slot1, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  %v3880 = load i32, ptr %slot594, align 8
  %call3881 = call i32 @myl_qbe_rc_status(ptr %p3879, i32 %v3880) nomerge, !dbg !144
  store i32 %call3881, ptr %slot595, align 8
  br label %bb_failure
bb_rcsuccess1197:
  br label %bb_rcgdone1183
bb_rcgplain1183:
  %v3882 = load i64, ptr %slot580, align 8
  %v3883 = load i64, ptr %slot578, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  store i64 %v3882, ptr %p3884, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1183
bb_rcgdone1183:
  %v3885 = load i64, ptr %slot10, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  store i32 2, ptr %p3886, align 4, !alias.scope !3, !noalias !4
  %v3887 = load i64, ptr %slot9, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  store i32 1, ptr %p3888, align 4, !alias.scope !3, !noalias !4
  %v3889 = load i64, ptr %slot5, align 8
  %p3890 = inttoptr i64 %v3889 to ptr
  %ld3891 = load i32, ptr %p3890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3891, ptr %slot596, align 8
  %v3892 = load i32, ptr %slot596, align 8
  %cv3893 = zext i32 %v3892 to i64
  %cond3894 = icmp ne i64 %cv3893, 0
  br i1 %cond3894, label %bb_rcslotdrop1204, label %bb_rcslotdone1204
bb_rcslotdrop1204:
  %v3895 = load i64, ptr %slot5, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i32 0, ptr %p3896, align 4, !alias.scope !3, !noalias !4
  %v3897 = load i64, ptr %slot11, align 8
  store i64 %v3897, ptr %slot597, align 8
  %v3898 = load i64, ptr %slot6, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %ld3900 = load i32, ptr %p3899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3900, ptr %slot598, align 8
  %v3901 = load i32, ptr %slot598, align 8
  %op3902 = and i32 %v3901, 28
  store i32 %op3902, ptr %slot599, align 8
  %v3903 = load i32, ptr %slot599, align 8
  %cv3904 = zext i32 %v3903 to i64
  %cond3905 = icmp ne i64 %cv3904, 0
  br i1 %cond3905, label %bb_rcslotrole1204, label %bb_rcslotowner1204
bb_rcslotrole1204:
  %v3906 = load i64, ptr %slot33, align 8
  store i64 %v3906, ptr %slot600, align 8
  %v3907 = load i64, ptr %slot597, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  %ld3909 = load i64, ptr %p3908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3909, ptr %slot601, align 8
  %v3910 = load i64, ptr %slot601, align 8
  %cmp3911 = icmp ne i64 %v3910, 0
  %cv3912 = zext i1 %cmp3911 to i32
  store i32 %cv3912, ptr %slot602, align 8
  %v3913 = load i32, ptr %slot602, align 8
  %cv3914 = zext i32 %v3913 to i64
  %cond3915 = icmp ne i64 %cv3914, 0
  br i1 %cond3915, label %bb_rcgnn1220, label %bb_rcgdone1220
bb_rcgnn1220:
  %v3916 = load i64, ptr %slot601, align 8
  %op3917 = sub i64 %v3916, 16
  store i64 %op3917, ptr %slot603, align 8
  %v3918 = load i64, ptr %slot601, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  %rgep3920 = getelementptr i8, ptr %p3919, i64 -16
  %ld3921 = load i64, ptr %rgep3920, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3921, ptr %slot604, align 8
  %v3922 = load i64, ptr %slot604, align 8
  %op3923 = and i64 %v3922, 4611686018427387906
  store i64 %op3923, ptr %slot605, align 8
  %v3924 = load i64, ptr %slot605, align 8
  %cmp3925 = icmp ne i64 %v3924, 0
  %cv3926 = zext i1 %cmp3925 to i32
  store i32 %cv3926, ptr %slot606, align 8
  %v3927 = load i32, ptr %slot606, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rcgclear1220, label %bb_rcgcounted1220
bb_rcgcounted1220:
  %v3930 = load i64, ptr %slot601, align 8
  %op3931 = sub i64 %v3930, 24
  store i64 %op3931, ptr %slot607, align 8
  %v3932 = load i64, ptr %slot601, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  %rgep3934 = getelementptr i8, ptr %p3933, i64 -24
  %ld3935 = load i64, ptr %rgep3934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3935, ptr %slot608, align 8
  %v3936 = load i64, ptr %slot608, align 8
  %op3937 = sub i64 %v3936, 1
  store i64 %op3937, ptr %slot609, align 8
  %v3938 = load i64, ptr %slot609, align 8
  %cmp3939 = icmp eq i64 %v3938, 0
  %cv3940 = zext i1 %cmp3939 to i32
  store i32 %cv3940, ptr %slot610, align 8
  %v3941 = load i32, ptr %slot610, align 8
  %cv3942 = zext i32 %v3941 to i64
  %cond3943 = icmp ne i64 %cv3942, 0
  br i1 %cond3943, label %bb_rcglast1220, label %bb_rcgdec1220
bb_rcglast1220:
  %v3944 = load i64, ptr %slot601, align 8
  %op3945 = sub i64 %v3944, 32
  store i64 %op3945, ptr %slot611, align 8
  %v3946 = load i64, ptr %slot601, align 8
  %p3947 = inttoptr i64 %v3946 to ptr
  %rgep3948 = getelementptr i8, ptr %p3947, i64 -32
  %ld3949 = load i64, ptr %rgep3948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3949, ptr %slot612, align 8
  %v3950 = load i64, ptr %slot612, align 8
  %cmp3951 = icmp ne i64 %v3950, 0
  %cv3952 = zext i1 %cmp3951 to i32
  store i32 %cv3952, ptr %slot613, align 8
  %v3953 = load i32, ptr %slot613, align 8
  %cv3954 = zext i32 %v3953 to i64
  %cond3955 = icmp ne i64 %cv3954, 0
  br i1 %cond3955, label %bb_rcgdec1220, label %bb_rcgslow1220
bb_rcgslow1220:
  %v3956 = load i64, ptr %slot600, align 8
  %v3957 = load i64, ptr %slot597, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3956, i64 %v3957) nomerge, !dbg !144
  br label %bb_rcgdone1220
bb_rcgdec1220:
  %v3958 = load i64, ptr %slot609, align 8
  %v3959 = load i64, ptr %slot601, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  %rgep3961 = getelementptr i8, ptr %p3960, i64 -24
  store i64 %v3958, ptr %rgep3961, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1220
bb_rcgclear1220:
  %v3962 = load i64, ptr %slot597, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  store i64 0, ptr %p3963, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1220
bb_rcgdone1220:
  br label %bb_rcslotdone1204
bb_rcslotowner1204:
  %v3964 = load i64, ptr %slot33, align 8
  store i64 %v3964, ptr %slot614, align 8
  %v3965 = load i64, ptr %slot597, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i64, ptr %p3966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3967, ptr %slot615, align 8
  %v3968 = load i64, ptr %slot615, align 8
  %cmp3969 = icmp ne i64 %v3968, 0
  %cv3970 = zext i1 %cmp3969 to i32
  store i32 %cv3970, ptr %slot616, align 8
  %v3971 = load i32, ptr %slot616, align 8
  %cv3972 = zext i32 %v3971 to i64
  %cond3973 = icmp ne i64 %cv3972, 0
  br i1 %cond3973, label %bb_rcgnn1235, label %bb_rcgdone1235
bb_rcgnn1235:
  %v3974 = load i64, ptr %slot615, align 8
  %op3975 = sub i64 %v3974, 16
  store i64 %op3975, ptr %slot617, align 8
  %v3976 = load i64, ptr %slot615, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  %rgep3978 = getelementptr i8, ptr %p3977, i64 -16
  %ld3979 = load i64, ptr %rgep3978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3979, ptr %slot618, align 8
  %v3980 = load i64, ptr %slot618, align 8
  %op3981 = and i64 %v3980, 4611686018427387906
  store i64 %op3981, ptr %slot619, align 8
  %v3982 = load i64, ptr %slot619, align 8
  %cmp3983 = icmp ne i64 %v3982, 0
  %cv3984 = zext i1 %cmp3983 to i32
  store i32 %cv3984, ptr %slot620, align 8
  %v3985 = load i32, ptr %slot620, align 8
  %cv3986 = zext i32 %v3985 to i64
  %cond3987 = icmp ne i64 %cv3986, 0
  br i1 %cond3987, label %bb_rcgclear1235, label %bb_rcgcounted1235
bb_rcgcounted1235:
  %v3988 = load i64, ptr %slot615, align 8
  %op3989 = sub i64 %v3988, 32
  store i64 %op3989, ptr %slot621, align 8
  %v3990 = load i64, ptr %slot615, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  %rgep3992 = getelementptr i8, ptr %p3991, i64 -32
  %ld3993 = load i64, ptr %rgep3992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3993, ptr %slot622, align 8
  %v3994 = load i64, ptr %slot622, align 8
  %op3995 = sub i64 %v3994, 1
  store i64 %op3995, ptr %slot623, align 8
  %v3996 = load i64, ptr %slot623, align 8
  %cmp3997 = icmp eq i64 %v3996, 0
  %cv3998 = zext i1 %cmp3997 to i32
  store i32 %cv3998, ptr %slot624, align 8
  %v3999 = load i32, ptr %slot624, align 8
  %cv4000 = zext i32 %v3999 to i64
  %cond4001 = icmp ne i64 %cv4000, 0
  br i1 %cond4001, label %bb_rcglast1235, label %bb_rcgdec1235
bb_rcglast1235:
  %v4002 = load i64, ptr %slot615, align 8
  %op4003 = sub i64 %v4002, 24
  store i64 %op4003, ptr %slot625, align 8
  %v4004 = load i64, ptr %slot615, align 8
  %p4005 = inttoptr i64 %v4004 to ptr
  %rgep4006 = getelementptr i8, ptr %p4005, i64 -24
  %ld4007 = load i64, ptr %rgep4006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4007, ptr %slot626, align 8
  %v4008 = load i64, ptr %slot626, align 8
  %cmp4009 = icmp ne i64 %v4008, 0
  %cv4010 = zext i1 %cmp4009 to i32
  store i32 %cv4010, ptr %slot627, align 8
  %v4011 = load i32, ptr %slot627, align 8
  %cv4012 = zext i32 %v4011 to i64
  %cond4013 = icmp ne i64 %cv4012, 0
  br i1 %cond4013, label %bb_rcgdec1235, label %bb_rcgslow1235
bb_rcgslow1235:
  %v4014 = load i64, ptr %slot614, align 8
  %v4015 = load i64, ptr %slot597, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4014, i64 %v4015) nomerge, !dbg !144
  br label %bb_rcgdone1235
bb_rcgdec1235:
  %v4016 = load i64, ptr %slot623, align 8
  %v4017 = load i64, ptr %slot615, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %rgep4019 = getelementptr i8, ptr %p4018, i64 -32
  store i64 %v4016, ptr %rgep4019, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1235
bb_rcgclear1235:
  %v4020 = load i64, ptr %slot597, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  store i64 0, ptr %p4021, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1235
bb_rcgdone1235:
  br label %bb_rcslotdone1204
bb_rcslotdone1204:
  br label %bb_rcprepared1150
bb_rcprepared1150:
  %v4022 = load i64, ptr %slot15, align 8
  store i64 %v4022, ptr %slot628, align 8
  %v4023 = load i64, ptr %slot628, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  %ld4025 = load i64, ptr %p4024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4025, ptr %slot629, align 8
  %v4026 = load i64, ptr %slot9, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  store i32 0, ptr %p4027, align 4, !alias.scope !3, !noalias !4
  %v4028 = load i64, ptr %slot5, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  %ld4030 = load i32, ptr %p4029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4030, ptr %slot630, align 8
  %v4031 = load i32, ptr %slot630, align 8
  %cv4032 = zext i32 %v4031 to i64
  %cond4033 = icmp ne i64 %cv4032, 0
  br i1 %cond4033, label %bb_rcslotdrop1244, label %bb_rcslotdone1244
bb_rcslotdrop1244:
  %v4034 = load i64, ptr %slot5, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  store i32 0, ptr %p4035, align 4, !alias.scope !3, !noalias !4
  %v4036 = load i64, ptr %slot11, align 8
  store i64 %v4036, ptr %slot631, align 8
  %v4037 = load i64, ptr %slot6, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %ld4039 = load i32, ptr %p4038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4039, ptr %slot632, align 8
  %v4040 = load i32, ptr %slot632, align 8
  %op4041 = and i32 %v4040, 28
  store i32 %op4041, ptr %slot633, align 8
  %v4042 = load i32, ptr %slot633, align 8
  %cv4043 = zext i32 %v4042 to i64
  %cond4044 = icmp ne i64 %cv4043, 0
  br i1 %cond4044, label %bb_rcslotrole1244, label %bb_rcslotowner1244
bb_rcslotrole1244:
  %v4045 = load i64, ptr %slot33, align 8
  store i64 %v4045, ptr %slot634, align 8
  %v4046 = load i64, ptr %slot631, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i64, ptr %p4047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4048, ptr %slot635, align 8
  %v4049 = load i64, ptr %slot635, align 8
  %cmp4050 = icmp ne i64 %v4049, 0
  %cv4051 = zext i1 %cmp4050 to i32
  store i32 %cv4051, ptr %slot636, align 8
  %v4052 = load i32, ptr %slot636, align 8
  %cv4053 = zext i32 %v4052 to i64
  %cond4054 = icmp ne i64 %cv4053, 0
  br i1 %cond4054, label %bb_rcgnn1260, label %bb_rcgdone1260
bb_rcgnn1260:
  %v4055 = load i64, ptr %slot635, align 8
  %op4056 = sub i64 %v4055, 16
  store i64 %op4056, ptr %slot637, align 8
  %v4057 = load i64, ptr %slot635, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %rgep4059 = getelementptr i8, ptr %p4058, i64 -16
  %ld4060 = load i64, ptr %rgep4059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4060, ptr %slot638, align 8
  %v4061 = load i64, ptr %slot638, align 8
  %op4062 = and i64 %v4061, 4611686018427387906
  store i64 %op4062, ptr %slot639, align 8
  %v4063 = load i64, ptr %slot639, align 8
  %cmp4064 = icmp ne i64 %v4063, 0
  %cv4065 = zext i1 %cmp4064 to i32
  store i32 %cv4065, ptr %slot640, align 8
  %v4066 = load i32, ptr %slot640, align 8
  %cv4067 = zext i32 %v4066 to i64
  %cond4068 = icmp ne i64 %cv4067, 0
  br i1 %cond4068, label %bb_rcgclear1260, label %bb_rcgcounted1260
bb_rcgcounted1260:
  %v4069 = load i64, ptr %slot635, align 8
  %op4070 = sub i64 %v4069, 24
  store i64 %op4070, ptr %slot641, align 8
  %v4071 = load i64, ptr %slot635, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %rgep4073 = getelementptr i8, ptr %p4072, i64 -24
  %ld4074 = load i64, ptr %rgep4073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4074, ptr %slot642, align 8
  %v4075 = load i64, ptr %slot642, align 8
  %op4076 = sub i64 %v4075, 1
  store i64 %op4076, ptr %slot643, align 8
  %v4077 = load i64, ptr %slot643, align 8
  %cmp4078 = icmp eq i64 %v4077, 0
  %cv4079 = zext i1 %cmp4078 to i32
  store i32 %cv4079, ptr %slot644, align 8
  %v4080 = load i32, ptr %slot644, align 8
  %cv4081 = zext i32 %v4080 to i64
  %cond4082 = icmp ne i64 %cv4081, 0
  br i1 %cond4082, label %bb_rcglast1260, label %bb_rcgdec1260
bb_rcglast1260:
  %v4083 = load i64, ptr %slot635, align 8
  %op4084 = sub i64 %v4083, 32
  store i64 %op4084, ptr %slot645, align 8
  %v4085 = load i64, ptr %slot635, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  %rgep4087 = getelementptr i8, ptr %p4086, i64 -32
  %ld4088 = load i64, ptr %rgep4087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4088, ptr %slot646, align 8
  %v4089 = load i64, ptr %slot646, align 8
  %cmp4090 = icmp ne i64 %v4089, 0
  %cv4091 = zext i1 %cmp4090 to i32
  store i32 %cv4091, ptr %slot647, align 8
  %v4092 = load i32, ptr %slot647, align 8
  %cv4093 = zext i32 %v4092 to i64
  %cond4094 = icmp ne i64 %cv4093, 0
  br i1 %cond4094, label %bb_rcgdec1260, label %bb_rcgslow1260
bb_rcgslow1260:
  %v4095 = load i64, ptr %slot634, align 8
  %v4096 = load i64, ptr %slot631, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4095, i64 %v4096) nomerge, !dbg !144
  br label %bb_rcgdone1260
bb_rcgdec1260:
  %v4097 = load i64, ptr %slot643, align 8
  %v4098 = load i64, ptr %slot635, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %rgep4100 = getelementptr i8, ptr %p4099, i64 -24
  store i64 %v4097, ptr %rgep4100, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1260
bb_rcgclear1260:
  %v4101 = load i64, ptr %slot631, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  store i64 0, ptr %p4102, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1260
bb_rcgdone1260:
  br label %bb_rcslotdone1244
bb_rcslotowner1244:
  %v4103 = load i64, ptr %slot33, align 8
  store i64 %v4103, ptr %slot648, align 8
  %v4104 = load i64, ptr %slot631, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  %ld4106 = load i64, ptr %p4105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4106, ptr %slot649, align 8
  %v4107 = load i64, ptr %slot649, align 8
  %cmp4108 = icmp ne i64 %v4107, 0
  %cv4109 = zext i1 %cmp4108 to i32
  store i32 %cv4109, ptr %slot650, align 8
  %v4110 = load i32, ptr %slot650, align 8
  %cv4111 = zext i32 %v4110 to i64
  %cond4112 = icmp ne i64 %cv4111, 0
  br i1 %cond4112, label %bb_rcgnn1275, label %bb_rcgdone1275
bb_rcgnn1275:
  %v4113 = load i64, ptr %slot649, align 8
  %op4114 = sub i64 %v4113, 16
  store i64 %op4114, ptr %slot651, align 8
  %v4115 = load i64, ptr %slot649, align 8
  %p4116 = inttoptr i64 %v4115 to ptr
  %rgep4117 = getelementptr i8, ptr %p4116, i64 -16
  %ld4118 = load i64, ptr %rgep4117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4118, ptr %slot652, align 8
  %v4119 = load i64, ptr %slot652, align 8
  %op4120 = and i64 %v4119, 4611686018427387906
  store i64 %op4120, ptr %slot653, align 8
  %v4121 = load i64, ptr %slot653, align 8
  %cmp4122 = icmp ne i64 %v4121, 0
  %cv4123 = zext i1 %cmp4122 to i32
  store i32 %cv4123, ptr %slot654, align 8
  %v4124 = load i32, ptr %slot654, align 8
  %cv4125 = zext i32 %v4124 to i64
  %cond4126 = icmp ne i64 %cv4125, 0
  br i1 %cond4126, label %bb_rcgclear1275, label %bb_rcgcounted1275
bb_rcgcounted1275:
  %v4127 = load i64, ptr %slot649, align 8
  %op4128 = sub i64 %v4127, 32
  store i64 %op4128, ptr %slot655, align 8
  %v4129 = load i64, ptr %slot649, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  %rgep4131 = getelementptr i8, ptr %p4130, i64 -32
  %ld4132 = load i64, ptr %rgep4131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4132, ptr %slot656, align 8
  %v4133 = load i64, ptr %slot656, align 8
  %op4134 = sub i64 %v4133, 1
  store i64 %op4134, ptr %slot657, align 8
  %v4135 = load i64, ptr %slot657, align 8
  %cmp4136 = icmp eq i64 %v4135, 0
  %cv4137 = zext i1 %cmp4136 to i32
  store i32 %cv4137, ptr %slot658, align 8
  %v4138 = load i32, ptr %slot658, align 8
  %cv4139 = zext i32 %v4138 to i64
  %cond4140 = icmp ne i64 %cv4139, 0
  br i1 %cond4140, label %bb_rcglast1275, label %bb_rcgdec1275
bb_rcglast1275:
  %v4141 = load i64, ptr %slot649, align 8
  %op4142 = sub i64 %v4141, 24
  store i64 %op4142, ptr %slot659, align 8
  %v4143 = load i64, ptr %slot649, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %rgep4145 = getelementptr i8, ptr %p4144, i64 -24
  %ld4146 = load i64, ptr %rgep4145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4146, ptr %slot660, align 8
  %v4147 = load i64, ptr %slot660, align 8
  %cmp4148 = icmp ne i64 %v4147, 0
  %cv4149 = zext i1 %cmp4148 to i32
  store i32 %cv4149, ptr %slot661, align 8
  %v4150 = load i32, ptr %slot661, align 8
  %cv4151 = zext i32 %v4150 to i64
  %cond4152 = icmp ne i64 %cv4151, 0
  br i1 %cond4152, label %bb_rcgdec1275, label %bb_rcgslow1275
bb_rcgslow1275:
  %v4153 = load i64, ptr %slot648, align 8
  %v4154 = load i64, ptr %slot631, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4153, i64 %v4154) nomerge, !dbg !144
  br label %bb_rcgdone1275
bb_rcgdec1275:
  %v4155 = load i64, ptr %slot657, align 8
  %v4156 = load i64, ptr %slot649, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %rgep4158 = getelementptr i8, ptr %p4157, i64 -32
  store i64 %v4155, ptr %rgep4158, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1275
bb_rcgclear1275:
  %v4159 = load i64, ptr %slot631, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  store i64 0, ptr %p4160, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1275
bb_rcgdone1275:
  br label %bb_rcslotdone1244
bb_rcslotdone1244:
  %v4161 = load i64, ptr %slot629, align 8
  ret i64 %v4161
bb_i43:
  %v4162 = load i64, ptr %slot23, align 8
  %v4163 = load i64, ptr %slot26, align 8
  %p4164 = inttoptr i64 %v4163 to ptr
  store i64 %v4162, ptr %p4164, align 8, !alias.scope !3, !noalias !4
  %v4165 = load i64, ptr %slot16, align 8
  %p4166 = inttoptr i64 %v4165 to ptr
  %ld4167 = load i64, ptr %p4166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4167, ptr %slot662, align 8
  %v4168 = load i64, ptr %slot662, align 8
  %v4169 = load i64, ptr %slot26, align 8
  %p4170 = inttoptr i64 %v4169 to ptr
  store i64 %v4168, ptr %p4170, align 8, !alias.scope !3, !noalias !4
  %v4171 = load i64, ptr %slot16, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i64, ptr %p4172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4173, ptr %slot663, align 8
  %v4174 = load i64, ptr %slot663, align 8
  %v4175 = load i64, ptr %slot27, align 8
  %p4176 = inttoptr i64 %v4175 to ptr
  store i64 %v4174, ptr %p4176, align 8, !alias.scope !3, !noalias !4
  %v4177 = load i64, ptr %slot23, align 8
  %v4178 = load i64, ptr %slot28, align 8
  %p4179 = inttoptr i64 %v4178 to ptr
  store i64 %v4177, ptr %p4179, align 8, !alias.scope !3, !noalias !4
  %v4180 = load i64, ptr %slot28, align 8
  %p4181 = inttoptr i64 %v4180 to ptr
  %ld4182 = load i64, ptr %p4181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4182, ptr %slot664, align 8
  %v4183 = load i64, ptr %slot664, align 8
  %op4184 = add i64 %v4183, 0
  store i64 %op4184, ptr %slot665, align 8
  %v4185 = load i64, ptr %slot665, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  %ld4187 = load i64, ptr %p4186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4187, ptr %slot666, align 8
  %v4188 = load i64, ptr %slot666, align 8
  %v4189 = load i64, ptr %slot28, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  store i64 %v4188, ptr %p4190, align 8, !alias.scope !3, !noalias !4
  %v4191 = load i64, ptr %slot27, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  %ld4193 = load i64, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4193, ptr %slot667, align 8
  %v4194 = load i64, ptr %slot28, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  %ld4196 = load i64, ptr %p4195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4196, ptr %slot668, align 8
  %v4197 = load i64, ptr %slot1, align 8
  %v4198 = load i64, ptr %slot667, align 8
  %v4199 = load i64, ptr %slot668, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult670, i64 %v4197, i64 %v4198, i64 %v4199) nomerge, !dbg !146
  %addr4200 = ptrtoint ptr %callresult670 to i64
  store i64 %addr4200, ptr %slot669, align 8
  %v4201 = load i64, ptr %slot669, align 8
  %v4202 = load i64, ptr %slot27, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  store i64 %v4201, ptr %p4203, align 8, !alias.scope !3, !noalias !4
  %v4204 = load i64, ptr %slot27, align 8
  %p4205 = inttoptr i64 %v4204 to ptr
  %ld4206 = load i64, ptr %p4205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4206, ptr %slot671, align 8
  %v4207 = load i64, ptr %slot15, align 8
  store i64 %v4207, ptr %slot672, align 8
  %v4208 = load i64, ptr %slot671, align 8
  %v4209 = load i64, ptr %slot672, align 8
  %p4210 = inttoptr i64 %v4208 to ptr
  %p4211 = inttoptr i64 %v4209 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4211, ptr %p4210, i64 24, i1 false)
  %v4212 = load i64, ptr %slot10, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  store i32 2, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  %v4214 = load i64, ptr %slot9, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  store i32 1, ptr %p4215, align 4, !alias.scope !3, !noalias !4
  %v4216 = load i64, ptr %slot7, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  %ld4218 = load i32, ptr %p4217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4218, ptr %slot673, align 8
  %v4219 = load i32, ptr %slot673, align 8
  %cv4220 = zext i32 %v4219 to i64
  %cond4221 = icmp ne i64 %cv4220, 0
  br i1 %cond4221, label %bb_rcslotdrop1384, label %bb_rcslotdone1384
bb_rcslotdrop1384:
  %v4222 = load i64, ptr %slot7, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  store i32 0, ptr %p4223, align 4, !alias.scope !3, !noalias !4
  %v4224 = load i64, ptr %slot12, align 8
  store i64 %v4224, ptr %slot674, align 8
  %v4225 = load i64, ptr %slot8, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  %ld4227 = load i32, ptr %p4226, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4227, ptr %slot675, align 8
  %v4228 = load i32, ptr %slot675, align 8
  %op4229 = and i32 %v4228, 28
  store i32 %op4229, ptr %slot676, align 8
  %v4230 = load i32, ptr %slot676, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcslotrole1384, label %bb_rcslotowner1384
bb_rcslotrole1384:
  %v4233 = load i64, ptr %slot33, align 8
  store i64 %v4233, ptr %slot677, align 8
  %v4234 = load i64, ptr %slot677, align 8
  %v4235 = load i64, ptr %slot674, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4234, i64 %v4235) nomerge, !dbg !146
  br label %bb_rcslotdone1384
bb_rcslotowner1384:
  %v4236 = load i64, ptr %slot33, align 8
  store i64 %v4236, ptr %slot678, align 8
  %v4237 = load i64, ptr %slot678, align 8
  %v4238 = load i64, ptr %slot674, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4237, i64 %v4238) nomerge, !dbg !146
  br label %bb_rcslotdone1384
bb_rcslotdone1384:
  %v4239 = load i64, ptr %slot12, align 8
  store i64 %v4239, ptr %slot679, align 8
  %v4240 = load i64, ptr %slot15, align 8
  store i64 %v4240, ptr %slot680, align 8
  %v4241 = load i64, ptr %slot680, align 8
  %v4242 = load i64, ptr %slot679, align 8
  %p4243 = inttoptr i64 %v4241 to ptr
  %p4244 = inttoptr i64 %v4242 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4244, ptr %p4243, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4245 = load i64, ptr %slot8, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  store i32 2, ptr %p4246, align 4, !alias.scope !3, !noalias !4
  %v4247 = load i64, ptr %slot10, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %ld4249 = load i32, ptr %p4248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4249, ptr %slot681, align 8
  %v4250 = load i32, ptr %slot681, align 8
  %v4251 = load i64, ptr %slot8, align 8
  %p4252 = inttoptr i64 %v4251 to ptr
  store i32 %v4250, ptr %p4252, align 4, !alias.scope !3, !noalias !4
  %v4253 = load i64, ptr %slot9, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  store i32 0, ptr %p4254, align 4, !alias.scope !3, !noalias !4
  %v4255 = load i64, ptr %slot7, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  store i32 1, ptr %p4256, align 4, !alias.scope !3, !noalias !4
  %v4257 = load i64, ptr %slot679, align 8
  %v4258 = load i64, ptr %slot27, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  store i64 %v4257, ptr %p4259, align 8, !alias.scope !3, !noalias !4
  %v4260 = load i64, ptr %slot27, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  %ld4262 = load i64, ptr %p4261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4262, ptr %slot682, align 8
  %v4263 = load i64, ptr %slot682, align 8
  %op4264 = add i64 %v4263, 0
  store i64 %op4264, ptr %slot683, align 8
  %v4265 = load i64, ptr %slot683, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  %ld4267 = load i64, ptr %p4266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4267, ptr %slot684, align 8
  %v4268 = load i64, ptr %slot684, align 8
  %v4269 = load i64, ptr %slot27, align 8
  %p4270 = inttoptr i64 %v4269 to ptr
  store i64 %v4268, ptr %p4270, align 8, !alias.scope !3, !noalias !4
  %v4271 = load i64, ptr %slot7, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  %ld4273 = load i32, ptr %p4272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4273, ptr %slot685, align 8
  %v4274 = load i32, ptr %slot685, align 8
  %cv4275 = zext i32 %v4274 to i64
  %cond4276 = icmp ne i64 %cv4275, 0
  br i1 %cond4276, label %bb_rcslotdrop1404, label %bb_rcslotdone1404
bb_rcslotdrop1404:
  %v4277 = load i64, ptr %slot7, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  store i32 0, ptr %p4278, align 4, !alias.scope !3, !noalias !4
  %v4279 = load i64, ptr %slot12, align 8
  store i64 %v4279, ptr %slot686, align 8
  %v4280 = load i64, ptr %slot8, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  %ld4282 = load i32, ptr %p4281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4282, ptr %slot687, align 8
  %v4283 = load i32, ptr %slot687, align 8
  %op4284 = and i32 %v4283, 28
  store i32 %op4284, ptr %slot688, align 8
  %v4285 = load i32, ptr %slot688, align 8
  %cv4286 = zext i32 %v4285 to i64
  %cond4287 = icmp ne i64 %cv4286, 0
  br i1 %cond4287, label %bb_rcslotrole1404, label %bb_rcslotowner1404
bb_rcslotrole1404:
  %v4288 = load i64, ptr %slot33, align 8
  store i64 %v4288, ptr %slot689, align 8
  %v4289 = load i64, ptr %slot689, align 8
  %v4290 = load i64, ptr %slot686, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v4289, i64 %v4290) nomerge, !dbg !148
  br label %bb_rcslotdone1404
bb_rcslotowner1404:
  %v4291 = load i64, ptr %slot33, align 8
  store i64 %v4291, ptr %slot690, align 8
  %v4292 = load i64, ptr %slot690, align 8
  %v4293 = load i64, ptr %slot686, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v4292, i64 %v4293) nomerge, !dbg !148
  br label %bb_rcslotdone1404
bb_rcslotdone1404:
  %v4294 = load i64, ptr %slot26, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  %ld4296 = load i64, ptr %p4295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4296, ptr %slot691, align 8
  %v4297 = load i64, ptr %slot27, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  %ld4299 = load i64, ptr %p4298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4299, ptr %slot692, align 8
  %v4300 = load i64, ptr %slot1, align 8
  %v4301 = load i64, ptr %slot691, align 8
  %v4302 = load i64, ptr %slot692, align 8
  %call4303 = call i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64 %v4300, i64 %v4301, i64 %v4302) nomerge, !dbg !150
  store i64 %call4303, ptr %slot693, align 8
  %v4304 = load i64, ptr %slot693, align 8
  %v4305 = load i64, ptr %slot26, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  store i64 %v4304, ptr %p4306, align 8, !alias.scope !3, !noalias !4
  %v4307 = load i64, ptr %slot5, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  %ld4309 = load i32, ptr %p4308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4309, ptr %slot694, align 8
  %v4310 = load i32, ptr %slot694, align 8
  %cv4311 = zext i32 %v4310 to i64
  %cond4312 = icmp ne i64 %cv4311, 0
  br i1 %cond4312, label %bb_rcslotdrop1416, label %bb_rcslotdone1416
bb_rcslotdrop1416:
  %v4313 = load i64, ptr %slot5, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  store i32 0, ptr %p4314, align 4, !alias.scope !3, !noalias !4
  %v4315 = load i64, ptr %slot11, align 8
  store i64 %v4315, ptr %slot695, align 8
  %v4316 = load i64, ptr %slot6, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  %ld4318 = load i32, ptr %p4317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4318, ptr %slot696, align 8
  %v4319 = load i32, ptr %slot696, align 8
  %op4320 = and i32 %v4319, 28
  store i32 %op4320, ptr %slot697, align 8
  %v4321 = load i32, ptr %slot697, align 8
  %cv4322 = zext i32 %v4321 to i64
  %cond4323 = icmp ne i64 %cv4322, 0
  br i1 %cond4323, label %bb_rcslotrole1416, label %bb_rcslotowner1416
bb_rcslotrole1416:
  %v4324 = load i64, ptr %slot33, align 8
  store i64 %v4324, ptr %slot698, align 8
  %v4325 = load i64, ptr %slot698, align 8
  %v4326 = load i64, ptr %slot695, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4325, i64 %v4326) nomerge, !dbg !150
  br label %bb_rcslotdone1416
bb_rcslotowner1416:
  %v4327 = load i64, ptr %slot33, align 8
  store i64 %v4327, ptr %slot699, align 8
  %v4328 = load i64, ptr %slot699, align 8
  %v4329 = load i64, ptr %slot695, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4328, i64 %v4329) nomerge, !dbg !150
  br label %bb_rcslotdone1416
bb_rcslotdone1416:
  %p4330 = inttoptr i64 ptrtoint (ptr @myl_lit_f2a3ab8999a0700efc12f265f5a0d76d8e59208e4e458e1b2c63f089c38a43ad to i64) to ptr
  %ld4331 = load i64, ptr %p4330, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4331, ptr %slot700, align 8
  %v4332 = load i64, ptr %slot700, align 8
  %v4333 = load i64, ptr %slot27, align 8
  %p4334 = inttoptr i64 %v4333 to ptr
  store i64 %v4332, ptr %p4334, align 8, !alias.scope !3, !noalias !4
  %v4335 = load i64, ptr %slot27, align 8
  %p4336 = inttoptr i64 %v4335 to ptr
  %ld4337 = load i64, ptr %p4336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4337, ptr %slot701, align 8
  %v4338 = load i64, ptr %slot701, align 8
  %v4339 = load i64, ptr %slot14, align 8
  %p4340 = inttoptr i64 %v4339 to ptr
  store i64 %v4338, ptr %p4340, align 8, !alias.scope !3, !noalias !4
  %v4341 = load i64, ptr %slot14, align 8
  store i64 %v4341, ptr %slot702, align 8
  %v4342 = load i64, ptr %slot15, align 8
  store i64 %v4342, ptr %slot703, align 8
  %v4343 = load i64, ptr %slot702, align 8
  %v4344 = load i64, ptr %slot703, align 8
  %p4345 = inttoptr i64 %v4343 to ptr
  %p4346 = inttoptr i64 %v4344 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4346, ptr %p4345, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4347 = load i64, ptr %slot10, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  store i32 2, ptr %p4348, align 4, !alias.scope !3, !noalias !4
  %v4349 = load i64, ptr %slot9, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  store i32 1, ptr %p4350, align 4, !alias.scope !3, !noalias !4
  %v4351 = load i64, ptr %slot12, align 8
  store i64 %v4351, ptr %slot704, align 8
  %v4352 = load i64, ptr %slot15, align 8
  store i64 %v4352, ptr %slot705, align 8
  %v4353 = load i64, ptr %slot705, align 8
  %v4354 = load i64, ptr %slot704, align 8
  %p4355 = inttoptr i64 %v4353 to ptr
  %p4356 = inttoptr i64 %v4354 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4356, ptr %p4355, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4357 = load i64, ptr %slot8, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  store i32 2, ptr %p4358, align 4, !alias.scope !3, !noalias !4
  %v4359 = load i64, ptr %slot10, align 8
  %p4360 = inttoptr i64 %v4359 to ptr
  %ld4361 = load i32, ptr %p4360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4361, ptr %slot706, align 8
  %v4362 = load i32, ptr %slot706, align 8
  %v4363 = load i64, ptr %slot8, align 8
  %p4364 = inttoptr i64 %v4363 to ptr
  store i32 %v4362, ptr %p4364, align 4, !alias.scope !3, !noalias !4
  %v4365 = load i64, ptr %slot9, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i32 0, ptr %p4366, align 4, !alias.scope !3, !noalias !4
  %v4367 = load i64, ptr %slot7, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  store i32 1, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  %v4369 = load i64, ptr %slot704, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  %ld4371 = load i64, ptr %p4370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4371, ptr %slot707, align 8
  %v4372 = load i64, ptr %slot707, align 8
  %v4373 = load i64, ptr %slot27, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  store i64 %v4372, ptr %p4374, align 8, !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot26, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  %ld4377 = load i64, ptr %p4376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4377, ptr %slot708, align 8
  %v4378 = load i64, ptr %slot27, align 8
  %p4379 = inttoptr i64 %v4378 to ptr
  %ld4380 = load i64, ptr %p4379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4380, ptr %slot709, align 8
  %v4381 = load i64, ptr %slot26, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  %ld4383 = load i64, ptr %p4382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4383, ptr %slot710, align 8
  %v4384 = load i64, ptr %slot27, align 8
  %p4385 = inttoptr i64 %v4384 to ptr
  %ld4386 = load i64, ptr %p4385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4386, ptr %slot711, align 8
  %v4387 = load i64, ptr %slot33, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  %v4389 = load i64, ptr %slot710, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  %v4391 = load i64, ptr %slot711, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  %call4393 = call ptr @myl_native_bytes_concat(ptr %p4388, ptr %p4390, ptr %p4392) nomerge, !dbg !152
  %calladdr4394 = ptrtoint ptr %call4393 to i64
  store i64 %calladdr4394, ptr %slot712, align 8
  %v4395 = load i64, ptr %slot712, align 8
  %cond4396 = icmp ne i64 %v4395, 0
  br i1 %cond4396, label %bb_success1445, label %bb_failed1445
bb_failed1445:
  %v4397 = load i64, ptr %slot1, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4398) nomerge, !dbg !152
  unreachable
bb_success1445:
  %v4399 = load i64, ptr %slot712, align 8
  %v4400 = load i64, ptr %slot26, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  store i64 %v4399, ptr %p4401, align 8, !alias.scope !3, !noalias !4
  %v4402 = load i64, ptr %slot26, align 8
  %p4403 = inttoptr i64 %v4402 to ptr
  %ld4404 = load i64, ptr %p4403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4404, ptr %slot713, align 8
  %v4405 = load i64, ptr %slot713, align 8
  %v4406 = load i64, ptr %slot13, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  store i64 %v4405, ptr %p4407, align 8, !alias.scope !3, !noalias !4
  %v4408 = load i64, ptr %slot13, align 8
  store i64 %v4408, ptr %slot714, align 8
  %v4409 = load i64, ptr %slot15, align 8
  store i64 %v4409, ptr %slot715, align 8
  %v4410 = load i64, ptr %slot714, align 8
  %v4411 = load i64, ptr %slot715, align 8
  %p4412 = inttoptr i64 %v4410 to ptr
  %p4413 = inttoptr i64 %v4411 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4413, ptr %p4412, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4414 = load i64, ptr %slot10, align 8
  %p4415 = inttoptr i64 %v4414 to ptr
  store i32 2, ptr %p4415, align 4, !alias.scope !3, !noalias !4
  %v4416 = load i64, ptr %slot9, align 8
  %p4417 = inttoptr i64 %v4416 to ptr
  store i32 1, ptr %p4417, align 4, !alias.scope !3, !noalias !4
  %v4418 = load i64, ptr %slot5, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %ld4420 = load i32, ptr %p4419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4420, ptr %slot716, align 8
  %v4421 = load i32, ptr %slot716, align 8
  %cv4422 = zext i32 %v4421 to i64
  %cond4423 = icmp ne i64 %cv4422, 0
  br i1 %cond4423, label %bb_rcslotdrop1453, label %bb_rcslotdone1453
bb_rcslotdrop1453:
  %v4424 = load i64, ptr %slot5, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  store i32 0, ptr %p4425, align 4, !alias.scope !3, !noalias !4
  %v4426 = load i64, ptr %slot11, align 8
  store i64 %v4426, ptr %slot717, align 8
  %v4427 = load i64, ptr %slot6, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  %ld4429 = load i32, ptr %p4428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4429, ptr %slot718, align 8
  %v4430 = load i32, ptr %slot718, align 8
  %op4431 = and i32 %v4430, 28
  store i32 %op4431, ptr %slot719, align 8
  %v4432 = load i32, ptr %slot719, align 8
  %cv4433 = zext i32 %v4432 to i64
  %cond4434 = icmp ne i64 %cv4433, 0
  br i1 %cond4434, label %bb_rcslotrole1453, label %bb_rcslotowner1453
bb_rcslotrole1453:
  %v4435 = load i64, ptr %slot33, align 8
  store i64 %v4435, ptr %slot720, align 8
  %v4436 = load i64, ptr %slot717, align 8
  %p4437 = inttoptr i64 %v4436 to ptr
  %ld4438 = load i64, ptr %p4437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4438, ptr %slot721, align 8
  %v4439 = load i64, ptr %slot721, align 8
  %cmp4440 = icmp ne i64 %v4439, 0
  %cv4441 = zext i1 %cmp4440 to i32
  store i32 %cv4441, ptr %slot722, align 8
  %v4442 = load i32, ptr %slot722, align 8
  %cv4443 = zext i32 %v4442 to i64
  %cond4444 = icmp ne i64 %cv4443, 0
  br i1 %cond4444, label %bb_rcgnn1469, label %bb_rcgdone1469
bb_rcgnn1469:
  %v4445 = load i64, ptr %slot721, align 8
  %op4446 = sub i64 %v4445, 16
  store i64 %op4446, ptr %slot723, align 8
  %v4447 = load i64, ptr %slot721, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  %rgep4449 = getelementptr i8, ptr %p4448, i64 -16
  %ld4450 = load i64, ptr %rgep4449, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4450, ptr %slot724, align 8
  %v4451 = load i64, ptr %slot724, align 8
  %op4452 = and i64 %v4451, 4611686018427387906
  store i64 %op4452, ptr %slot725, align 8
  %v4453 = load i64, ptr %slot725, align 8
  %cmp4454 = icmp ne i64 %v4453, 0
  %cv4455 = zext i1 %cmp4454 to i32
  store i32 %cv4455, ptr %slot726, align 8
  %v4456 = load i32, ptr %slot726, align 8
  %cv4457 = zext i32 %v4456 to i64
  %cond4458 = icmp ne i64 %cv4457, 0
  br i1 %cond4458, label %bb_rcgclear1469, label %bb_rcgcounted1469
bb_rcgcounted1469:
  %v4459 = load i64, ptr %slot721, align 8
  %op4460 = sub i64 %v4459, 24
  store i64 %op4460, ptr %slot727, align 8
  %v4461 = load i64, ptr %slot721, align 8
  %p4462 = inttoptr i64 %v4461 to ptr
  %rgep4463 = getelementptr i8, ptr %p4462, i64 -24
  %ld4464 = load i64, ptr %rgep4463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4464, ptr %slot728, align 8
  %v4465 = load i64, ptr %slot728, align 8
  %op4466 = sub i64 %v4465, 1
  store i64 %op4466, ptr %slot729, align 8
  %v4467 = load i64, ptr %slot729, align 8
  %cmp4468 = icmp eq i64 %v4467, 0
  %cv4469 = zext i1 %cmp4468 to i32
  store i32 %cv4469, ptr %slot730, align 8
  %v4470 = load i32, ptr %slot730, align 8
  %cv4471 = zext i32 %v4470 to i64
  %cond4472 = icmp ne i64 %cv4471, 0
  br i1 %cond4472, label %bb_rcglast1469, label %bb_rcgdec1469
bb_rcglast1469:
  %v4473 = load i64, ptr %slot721, align 8
  %op4474 = sub i64 %v4473, 32
  store i64 %op4474, ptr %slot731, align 8
  %v4475 = load i64, ptr %slot721, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  %rgep4477 = getelementptr i8, ptr %p4476, i64 -32
  %ld4478 = load i64, ptr %rgep4477, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4478, ptr %slot732, align 8
  %v4479 = load i64, ptr %slot732, align 8
  %cmp4480 = icmp ne i64 %v4479, 0
  %cv4481 = zext i1 %cmp4480 to i32
  store i32 %cv4481, ptr %slot733, align 8
  %v4482 = load i32, ptr %slot733, align 8
  %cv4483 = zext i32 %v4482 to i64
  %cond4484 = icmp ne i64 %cv4483, 0
  br i1 %cond4484, label %bb_rcgdec1469, label %bb_rcgslow1469
bb_rcgslow1469:
  %v4485 = load i64, ptr %slot720, align 8
  %v4486 = load i64, ptr %slot717, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4485, i64 %v4486) nomerge, !dbg !152
  br label %bb_rcgdone1469
bb_rcgdec1469:
  %v4487 = load i64, ptr %slot729, align 8
  %v4488 = load i64, ptr %slot721, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  %rgep4490 = getelementptr i8, ptr %p4489, i64 -24
  store i64 %v4487, ptr %rgep4490, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1469
bb_rcgclear1469:
  %v4491 = load i64, ptr %slot717, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  store i64 0, ptr %p4492, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1469
bb_rcgdone1469:
  br label %bb_rcslotdone1453
bb_rcslotowner1453:
  %v4493 = load i64, ptr %slot33, align 8
  store i64 %v4493, ptr %slot734, align 8
  %v4494 = load i64, ptr %slot717, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  %ld4496 = load i64, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4496, ptr %slot735, align 8
  %v4497 = load i64, ptr %slot735, align 8
  %cmp4498 = icmp ne i64 %v4497, 0
  %cv4499 = zext i1 %cmp4498 to i32
  store i32 %cv4499, ptr %slot736, align 8
  %v4500 = load i32, ptr %slot736, align 8
  %cv4501 = zext i32 %v4500 to i64
  %cond4502 = icmp ne i64 %cv4501, 0
  br i1 %cond4502, label %bb_rcgnn1484, label %bb_rcgdone1484
bb_rcgnn1484:
  %v4503 = load i64, ptr %slot735, align 8
  %op4504 = sub i64 %v4503, 16
  store i64 %op4504, ptr %slot737, align 8
  %v4505 = load i64, ptr %slot735, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  %rgep4507 = getelementptr i8, ptr %p4506, i64 -16
  %ld4508 = load i64, ptr %rgep4507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4508, ptr %slot738, align 8
  %v4509 = load i64, ptr %slot738, align 8
  %op4510 = and i64 %v4509, 4611686018427387906
  store i64 %op4510, ptr %slot739, align 8
  %v4511 = load i64, ptr %slot739, align 8
  %cmp4512 = icmp ne i64 %v4511, 0
  %cv4513 = zext i1 %cmp4512 to i32
  store i32 %cv4513, ptr %slot740, align 8
  %v4514 = load i32, ptr %slot740, align 8
  %cv4515 = zext i32 %v4514 to i64
  %cond4516 = icmp ne i64 %cv4515, 0
  br i1 %cond4516, label %bb_rcgclear1484, label %bb_rcgcounted1484
bb_rcgcounted1484:
  %v4517 = load i64, ptr %slot735, align 8
  %op4518 = sub i64 %v4517, 32
  store i64 %op4518, ptr %slot741, align 8
  %v4519 = load i64, ptr %slot735, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  %rgep4521 = getelementptr i8, ptr %p4520, i64 -32
  %ld4522 = load i64, ptr %rgep4521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4522, ptr %slot742, align 8
  %v4523 = load i64, ptr %slot742, align 8
  %op4524 = sub i64 %v4523, 1
  store i64 %op4524, ptr %slot743, align 8
  %v4525 = load i64, ptr %slot743, align 8
  %cmp4526 = icmp eq i64 %v4525, 0
  %cv4527 = zext i1 %cmp4526 to i32
  store i32 %cv4527, ptr %slot744, align 8
  %v4528 = load i32, ptr %slot744, align 8
  %cv4529 = zext i32 %v4528 to i64
  %cond4530 = icmp ne i64 %cv4529, 0
  br i1 %cond4530, label %bb_rcglast1484, label %bb_rcgdec1484
bb_rcglast1484:
  %v4531 = load i64, ptr %slot735, align 8
  %op4532 = sub i64 %v4531, 24
  store i64 %op4532, ptr %slot745, align 8
  %v4533 = load i64, ptr %slot735, align 8
  %p4534 = inttoptr i64 %v4533 to ptr
  %rgep4535 = getelementptr i8, ptr %p4534, i64 -24
  %ld4536 = load i64, ptr %rgep4535, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4536, ptr %slot746, align 8
  %v4537 = load i64, ptr %slot746, align 8
  %cmp4538 = icmp ne i64 %v4537, 0
  %cv4539 = zext i1 %cmp4538 to i32
  store i32 %cv4539, ptr %slot747, align 8
  %v4540 = load i32, ptr %slot747, align 8
  %cv4541 = zext i32 %v4540 to i64
  %cond4542 = icmp ne i64 %cv4541, 0
  br i1 %cond4542, label %bb_rcgdec1484, label %bb_rcgslow1484
bb_rcgslow1484:
  %v4543 = load i64, ptr %slot734, align 8
  %v4544 = load i64, ptr %slot717, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4543, i64 %v4544) nomerge, !dbg !152
  br label %bb_rcgdone1484
bb_rcgdec1484:
  %v4545 = load i64, ptr %slot743, align 8
  %v4546 = load i64, ptr %slot735, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  %rgep4548 = getelementptr i8, ptr %p4547, i64 -32
  store i64 %v4545, ptr %rgep4548, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1484
bb_rcgclear1484:
  %v4549 = load i64, ptr %slot717, align 8
  %p4550 = inttoptr i64 %v4549 to ptr
  store i64 0, ptr %p4550, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1484
bb_rcgdone1484:
  br label %bb_rcslotdone1453
bb_rcslotdone1453:
  %v4551 = load i64, ptr %slot7, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  %ld4553 = load i32, ptr %p4552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4553, ptr %slot748, align 8
  %v4554 = load i32, ptr %slot748, align 8
  %cv4555 = zext i32 %v4554 to i64
  %cond4556 = icmp ne i64 %cv4555, 0
  br i1 %cond4556, label %bb_rcslotdrop1490, label %bb_rcslotdone1490
bb_rcslotdrop1490:
  %v4557 = load i64, ptr %slot7, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  store i32 0, ptr %p4558, align 4, !alias.scope !3, !noalias !4
  %v4559 = load i64, ptr %slot12, align 8
  store i64 %v4559, ptr %slot749, align 8
  %v4560 = load i64, ptr %slot8, align 8
  %p4561 = inttoptr i64 %v4560 to ptr
  %ld4562 = load i32, ptr %p4561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4562, ptr %slot750, align 8
  %v4563 = load i32, ptr %slot750, align 8
  %op4564 = and i32 %v4563, 28
  store i32 %op4564, ptr %slot751, align 8
  %v4565 = load i32, ptr %slot751, align 8
  %cv4566 = zext i32 %v4565 to i64
  %cond4567 = icmp ne i64 %cv4566, 0
  br i1 %cond4567, label %bb_rcslotrole1490, label %bb_rcslotowner1490
bb_rcslotrole1490:
  %v4568 = load i64, ptr %slot33, align 8
  store i64 %v4568, ptr %slot752, align 8
  %v4569 = load i64, ptr %slot749, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  %ld4571 = load i64, ptr %p4570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4571, ptr %slot753, align 8
  %v4572 = load i64, ptr %slot753, align 8
  %cmp4573 = icmp ne i64 %v4572, 0
  %cv4574 = zext i1 %cmp4573 to i32
  store i32 %cv4574, ptr %slot754, align 8
  %v4575 = load i32, ptr %slot754, align 8
  %cv4576 = zext i32 %v4575 to i64
  %cond4577 = icmp ne i64 %cv4576, 0
  br i1 %cond4577, label %bb_rcgnn1506, label %bb_rcgdone1506
bb_rcgnn1506:
  %v4578 = load i64, ptr %slot753, align 8
  %op4579 = sub i64 %v4578, 16
  store i64 %op4579, ptr %slot755, align 8
  %v4580 = load i64, ptr %slot753, align 8
  %p4581 = inttoptr i64 %v4580 to ptr
  %rgep4582 = getelementptr i8, ptr %p4581, i64 -16
  %ld4583 = load i64, ptr %rgep4582, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4583, ptr %slot756, align 8
  %v4584 = load i64, ptr %slot756, align 8
  %op4585 = and i64 %v4584, 4611686018427387906
  store i64 %op4585, ptr %slot757, align 8
  %v4586 = load i64, ptr %slot757, align 8
  %cmp4587 = icmp ne i64 %v4586, 0
  %cv4588 = zext i1 %cmp4587 to i32
  store i32 %cv4588, ptr %slot758, align 8
  %v4589 = load i32, ptr %slot758, align 8
  %cv4590 = zext i32 %v4589 to i64
  %cond4591 = icmp ne i64 %cv4590, 0
  br i1 %cond4591, label %bb_rcgclear1506, label %bb_rcgcounted1506
bb_rcgcounted1506:
  %v4592 = load i64, ptr %slot753, align 8
  %op4593 = sub i64 %v4592, 24
  store i64 %op4593, ptr %slot759, align 8
  %v4594 = load i64, ptr %slot753, align 8
  %p4595 = inttoptr i64 %v4594 to ptr
  %rgep4596 = getelementptr i8, ptr %p4595, i64 -24
  %ld4597 = load i64, ptr %rgep4596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4597, ptr %slot760, align 8
  %v4598 = load i64, ptr %slot760, align 8
  %op4599 = sub i64 %v4598, 1
  store i64 %op4599, ptr %slot761, align 8
  %v4600 = load i64, ptr %slot761, align 8
  %cmp4601 = icmp eq i64 %v4600, 0
  %cv4602 = zext i1 %cmp4601 to i32
  store i32 %cv4602, ptr %slot762, align 8
  %v4603 = load i32, ptr %slot762, align 8
  %cv4604 = zext i32 %v4603 to i64
  %cond4605 = icmp ne i64 %cv4604, 0
  br i1 %cond4605, label %bb_rcglast1506, label %bb_rcgdec1506
bb_rcglast1506:
  %v4606 = load i64, ptr %slot753, align 8
  %op4607 = sub i64 %v4606, 32
  store i64 %op4607, ptr %slot763, align 8
  %v4608 = load i64, ptr %slot753, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  %rgep4610 = getelementptr i8, ptr %p4609, i64 -32
  %ld4611 = load i64, ptr %rgep4610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4611, ptr %slot764, align 8
  %v4612 = load i64, ptr %slot764, align 8
  %cmp4613 = icmp ne i64 %v4612, 0
  %cv4614 = zext i1 %cmp4613 to i32
  store i32 %cv4614, ptr %slot765, align 8
  %v4615 = load i32, ptr %slot765, align 8
  %cv4616 = zext i32 %v4615 to i64
  %cond4617 = icmp ne i64 %cv4616, 0
  br i1 %cond4617, label %bb_rcgdec1506, label %bb_rcgslow1506
bb_rcgslow1506:
  %v4618 = load i64, ptr %slot752, align 8
  %v4619 = load i64, ptr %slot749, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4618, i64 %v4619) nomerge, !dbg !152
  br label %bb_rcgdone1506
bb_rcgdec1506:
  %v4620 = load i64, ptr %slot761, align 8
  %v4621 = load i64, ptr %slot753, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %rgep4623 = getelementptr i8, ptr %p4622, i64 -24
  store i64 %v4620, ptr %rgep4623, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1506
bb_rcgclear1506:
  %v4624 = load i64, ptr %slot749, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  store i64 0, ptr %p4625, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1506
bb_rcgdone1506:
  br label %bb_rcslotdone1490
bb_rcslotowner1490:
  %v4626 = load i64, ptr %slot33, align 8
  store i64 %v4626, ptr %slot766, align 8
  %v4627 = load i64, ptr %slot749, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  %ld4629 = load i64, ptr %p4628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4629, ptr %slot767, align 8
  %v4630 = load i64, ptr %slot767, align 8
  %cmp4631 = icmp ne i64 %v4630, 0
  %cv4632 = zext i1 %cmp4631 to i32
  store i32 %cv4632, ptr %slot768, align 8
  %v4633 = load i32, ptr %slot768, align 8
  %cv4634 = zext i32 %v4633 to i64
  %cond4635 = icmp ne i64 %cv4634, 0
  br i1 %cond4635, label %bb_rcgnn1521, label %bb_rcgdone1521
bb_rcgnn1521:
  %v4636 = load i64, ptr %slot767, align 8
  %op4637 = sub i64 %v4636, 16
  store i64 %op4637, ptr %slot769, align 8
  %v4638 = load i64, ptr %slot767, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %rgep4640 = getelementptr i8, ptr %p4639, i64 -16
  %ld4641 = load i64, ptr %rgep4640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4641, ptr %slot770, align 8
  %v4642 = load i64, ptr %slot770, align 8
  %op4643 = and i64 %v4642, 4611686018427387906
  store i64 %op4643, ptr %slot771, align 8
  %v4644 = load i64, ptr %slot771, align 8
  %cmp4645 = icmp ne i64 %v4644, 0
  %cv4646 = zext i1 %cmp4645 to i32
  store i32 %cv4646, ptr %slot772, align 8
  %v4647 = load i32, ptr %slot772, align 8
  %cv4648 = zext i32 %v4647 to i64
  %cond4649 = icmp ne i64 %cv4648, 0
  br i1 %cond4649, label %bb_rcgclear1521, label %bb_rcgcounted1521
bb_rcgcounted1521:
  %v4650 = load i64, ptr %slot767, align 8
  %op4651 = sub i64 %v4650, 32
  store i64 %op4651, ptr %slot773, align 8
  %v4652 = load i64, ptr %slot767, align 8
  %p4653 = inttoptr i64 %v4652 to ptr
  %rgep4654 = getelementptr i8, ptr %p4653, i64 -32
  %ld4655 = load i64, ptr %rgep4654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4655, ptr %slot774, align 8
  %v4656 = load i64, ptr %slot774, align 8
  %op4657 = sub i64 %v4656, 1
  store i64 %op4657, ptr %slot775, align 8
  %v4658 = load i64, ptr %slot775, align 8
  %cmp4659 = icmp eq i64 %v4658, 0
  %cv4660 = zext i1 %cmp4659 to i32
  store i32 %cv4660, ptr %slot776, align 8
  %v4661 = load i32, ptr %slot776, align 8
  %cv4662 = zext i32 %v4661 to i64
  %cond4663 = icmp ne i64 %cv4662, 0
  br i1 %cond4663, label %bb_rcglast1521, label %bb_rcgdec1521
bb_rcglast1521:
  %v4664 = load i64, ptr %slot767, align 8
  %op4665 = sub i64 %v4664, 24
  store i64 %op4665, ptr %slot777, align 8
  %v4666 = load i64, ptr %slot767, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  %rgep4668 = getelementptr i8, ptr %p4667, i64 -24
  %ld4669 = load i64, ptr %rgep4668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4669, ptr %slot778, align 8
  %v4670 = load i64, ptr %slot778, align 8
  %cmp4671 = icmp ne i64 %v4670, 0
  %cv4672 = zext i1 %cmp4671 to i32
  store i32 %cv4672, ptr %slot779, align 8
  %v4673 = load i32, ptr %slot779, align 8
  %cv4674 = zext i32 %v4673 to i64
  %cond4675 = icmp ne i64 %cv4674, 0
  br i1 %cond4675, label %bb_rcgdec1521, label %bb_rcgslow1521
bb_rcgslow1521:
  %v4676 = load i64, ptr %slot766, align 8
  %v4677 = load i64, ptr %slot749, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4676, i64 %v4677) nomerge, !dbg !152
  br label %bb_rcgdone1521
bb_rcgdec1521:
  %v4678 = load i64, ptr %slot775, align 8
  %v4679 = load i64, ptr %slot767, align 8
  %p4680 = inttoptr i64 %v4679 to ptr
  %rgep4681 = getelementptr i8, ptr %p4680, i64 -32
  store i64 %v4678, ptr %rgep4681, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1521
bb_rcgclear1521:
  %v4682 = load i64, ptr %slot749, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  store i64 0, ptr %p4683, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1521
bb_rcgdone1521:
  br label %bb_rcslotdone1490
bb_rcslotdone1490:
  %v4684 = load i64, ptr %slot11, align 8
  store i64 %v4684, ptr %slot780, align 8
  %v4685 = load i64, ptr %slot15, align 8
  store i64 %v4685, ptr %slot781, align 8
  %v4686 = load i64, ptr %slot781, align 8
  %v4687 = load i64, ptr %slot780, align 8
  %p4688 = inttoptr i64 %v4686 to ptr
  %p4689 = inttoptr i64 %v4687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4689, ptr %p4688, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4690 = load i64, ptr %slot6, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  store i32 2, ptr %p4691, align 4, !alias.scope !3, !noalias !4
  %v4692 = load i64, ptr %slot10, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i32, ptr %p4693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4694, ptr %slot782, align 8
  %v4695 = load i32, ptr %slot782, align 8
  %v4696 = load i64, ptr %slot6, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  store i32 %v4695, ptr %p4697, align 4, !alias.scope !3, !noalias !4
  %v4698 = load i64, ptr %slot9, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  store i32 0, ptr %p4699, align 4, !alias.scope !3, !noalias !4
  %v4700 = load i64, ptr %slot5, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  store i32 1, ptr %p4701, align 4, !alias.scope !3, !noalias !4
  %v4702 = load i64, ptr %slot780, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  %ld4704 = load i64, ptr %p4703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4704, ptr %slot783, align 8
  %v4705 = load i64, ptr %slot783, align 8
  %v4706 = load i64, ptr %slot26, align 8
  %p4707 = inttoptr i64 %v4706 to ptr
  store i64 %v4705, ptr %p4707, align 8, !alias.scope !3, !noalias !4
  %v4708 = load i64, ptr %slot26, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  %ld4710 = load i64, ptr %p4709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4710, ptr %slot784, align 8
  %v4711 = load i64, ptr %slot26, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %ld4713 = load i64, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4713, ptr %slot785, align 8
  %v4714 = load i64, ptr %slot785, align 8
  %v4715 = load i64, ptr %slot13, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i64 %v4714, ptr %p4716, align 8, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot13, align 8
  store i64 %v4717, ptr %slot786, align 8
  %v4718 = load i64, ptr %slot5, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %ld4720 = load i32, ptr %p4719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4720, ptr %slot787, align 8
  %v4721 = load i64, ptr %slot6, align 8
  %p4722 = inttoptr i64 %v4721 to ptr
  %ld4723 = load i32, ptr %p4722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4723, ptr %slot788, align 8
  %v4724 = load i32, ptr %slot788, align 8
  %op4725 = and i32 %v4724, 24
  store i32 %op4725, ptr %slot788, align 8
  %v4726 = load i32, ptr %slot788, align 8
  %cmp4727 = icmp eq i32 %v4726, 0
  %cv4728 = zext i1 %cmp4727 to i32
  store i32 %cv4728, ptr %slot789, align 8
  %v4729 = load i32, ptr %slot787, align 8
  %v4730 = load i32, ptr %slot789, align 8
  %op4731 = and i32 %v4729, %v4730
  store i32 %op4731, ptr %slot790, align 8
  %v4732 = load i32, ptr %slot790, align 8
  %cv4733 = zext i32 %v4732 to i64
  %cond4734 = icmp ne i64 %cv4733, 0
  br i1 %cond4734, label %bb_rctake1537, label %bb_rccopy1537
bb_rctake1537:
  %v4735 = load i64, ptr %slot15, align 8
  store i64 %v4735, ptr %slot791, align 8
  %v4736 = load i64, ptr %slot34, align 8
  store i64 %v4736, ptr %slot792, align 8
  %v4737 = load i64, ptr %slot786, align 8
  %v4738 = load i64, ptr %slot791, align 8
  %op4739 = sub i64 %v4737, %v4738
  store i64 %op4739, ptr %slot793, align 8
  %v4740 = load i64, ptr %slot791, align 8
  %v4741 = load i64, ptr %slot786, align 8
  %op4742 = sub i64 %v4740, %v4741
  store i64 %op4742, ptr %slot794, align 8
  %v4743 = load i64, ptr %slot793, align 8
  %cmp4744 = icmp ult i64 %v4743, 8
  %cv4745 = zext i1 %cmp4744 to i32
  store i32 %cv4745, ptr %slot795, align 8
  %v4746 = load i64, ptr %slot794, align 8
  %cmp4747 = icmp ult i64 %v4746, 8
  %cv4748 = zext i1 %cmp4747 to i32
  store i32 %cv4748, ptr %slot796, align 8
  %v4749 = load i32, ptr %slot795, align 8
  %v4750 = load i32, ptr %slot796, align 8
  %op4751 = or i32 %v4749, %v4750
  store i32 %op4751, ptr %slot797, align 8
  %v4752 = load i32, ptr %slot797, align 8
  %cv4753 = zext i32 %v4752 to i64
  %cond4754 = icmp ne i64 %cv4753, 0
  br i1 %cond4754, label %bb_rcmoveslow1546, label %bb_rcmovecheck1546
bb_rcmovecheck1546:
  %v4755 = load i64, ptr %slot786, align 8
  %p4757 = inttoptr i64 %v4755 to ptr
  %gep4758 = getelementptr i8, ptr %p4757, i64 0
  %op4756 = ptrtoint ptr %gep4758 to i64
  store i64 %op4756, ptr %slot798, align 8
  %v4759 = load i64, ptr %slot798, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  %ld4761 = load i64, ptr %p4760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4761, ptr %slot799, align 8
  %v4762 = load i64, ptr %slot799, align 8
  %cmp4763 = icmp ne i64 %v4762, 0
  %cv4764 = zext i1 %cmp4763 to i32
  store i32 %cv4764, ptr %slot800, align 8
  %v4765 = load i32, ptr %slot800, align 8
  %cv4766 = zext i32 %v4765 to i64
  %cond4767 = icmp ne i64 %cv4766, 0
  br i1 %cond4767, label %bb_rcmoveheader1554, label %bb_rcmovenext1554
bb_rcmoveheader1554:
  %v4768 = load i64, ptr %slot799, align 8
  %op4769 = sub i64 %v4768, 16
  store i64 %op4769, ptr %slot801, align 8
  %v4770 = load i64, ptr %slot799, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  %rgep4772 = getelementptr i8, ptr %p4771, i64 -16
  %ld4773 = load i64, ptr %rgep4772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4773, ptr %slot802, align 8
  %v4774 = load i64, ptr %slot802, align 8
  %op4775 = and i64 %v4774, 5764607523034234881
  store i64 %op4775, ptr %slot803, align 8
  %v4776 = load i64, ptr %slot803, align 8
  %cmp4777 = icmp ne i64 %v4776, 0
  %cv4778 = zext i1 %cmp4777 to i32
  store i32 %cv4778, ptr %slot804, align 8
  %v4779 = load i32, ptr %slot804, align 8
  %cv4780 = zext i32 %v4779 to i64
  %cond4781 = icmp ne i64 %cv4780, 0
  br i1 %cond4781, label %bb_rcmoveslow1546, label %bb_rcmovenext1554
bb_rcmovenext1554:
  %v4782 = load i64, ptr %slot786, align 8
  %v4783 = load i64, ptr %slot791, align 8
  %p4784 = inttoptr i64 %v4782 to ptr
  %p4785 = inttoptr i64 %v4783 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4785, ptr %p4784, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot786, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i64 0, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1546
bb_rcmoveslow1546:
  %v4788 = load i64, ptr %slot33, align 8
  %v4789 = load i64, ptr %slot791, align 8
  %v4790 = load i64, ptr %slot786, align 8
  %v4791 = load i64, ptr %slot792, align 8
  %cv4792 = trunc i64 %v4791 to i32
  %call4793 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v4788, i64 %v4789, i64 %v4790, i32 %cv4792) nomerge, !dbg !154
  store i32 %call4793, ptr %slot805, align 8
  %v4794 = load i32, ptr %slot805, align 8
  %cv4795 = zext i32 %v4794 to i64
  %cond4796 = icmp ne i64 %cv4795, 0
  br i1 %cond4796, label %bb_rcsuccess1561, label %bb_rcfailure1561
bb_rcfailure1561:
  %v4797 = load i64, ptr %slot33, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %call4799 = call i32 @myl_rc_take_failure(ptr %p4798) nomerge, !dbg !154
  store i32 %call4799, ptr %slot806, align 8
  %v4800 = load i64, ptr %slot1, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %v4802 = load i32, ptr %slot806, align 8
  %call4803 = call i32 @myl_qbe_rc_status(ptr %p4801, i32 %v4802) nomerge, !dbg !154
  store i32 %call4803, ptr %slot807, align 8
  br label %bb_failure
bb_rcsuccess1561:
  br label %bb_rcmoved1546
bb_rcmoved1546:
  %v4804 = load i64, ptr %slot5, align 8
  %p4805 = inttoptr i64 %v4804 to ptr
  store i32 0, ptr %p4805, align 4, !alias.scope !3, !noalias !4
  %v4806 = load i64, ptr %slot10, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  store i32 2, ptr %p4807, align 4, !alias.scope !3, !noalias !4
  %v4808 = load i64, ptr %slot9, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  store i32 1, ptr %p4809, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1537
bb_rccopy1537:
  %v4810 = load i64, ptr %slot15, align 8
  store i64 %v4810, ptr %slot808, align 8
  %v4811 = load i64, ptr %slot34, align 8
  store i64 %v4811, ptr %slot809, align 8
  %v4812 = load i64, ptr %slot786, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  %ld4814 = load i64, ptr %p4813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4814, ptr %slot810, align 8
  %v4815 = load i64, ptr %slot810, align 8
  %cmp4816 = icmp ne i64 %v4815, 0
  %cv4817 = zext i1 %cmp4816 to i32
  store i32 %cv4817, ptr %slot811, align 8
  %v4818 = load i32, ptr %slot811, align 8
  %cv4819 = zext i32 %v4818 to i64
  %cond4820 = icmp ne i64 %cv4819, 0
  br i1 %cond4820, label %bb_rcgnn1570, label %bb_rcgplain1570
bb_rcgnn1570:
  %v4821 = load i64, ptr %slot810, align 8
  %op4822 = sub i64 %v4821, 16
  store i64 %op4822, ptr %slot812, align 8
  %v4823 = load i64, ptr %slot810, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  %rgep4825 = getelementptr i8, ptr %p4824, i64 -16
  %ld4826 = load i64, ptr %rgep4825, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4826, ptr %slot813, align 8
  %v4827 = load i64, ptr %slot813, align 8
  %op4828 = and i64 %v4827, 4611686018427387906
  store i64 %op4828, ptr %slot814, align 8
  %v4829 = load i64, ptr %slot814, align 8
  %cmp4830 = icmp ne i64 %v4829, 0
  %cv4831 = zext i1 %cmp4830 to i32
  store i32 %cv4831, ptr %slot815, align 8
  %v4832 = load i32, ptr %slot815, align 8
  %cv4833 = zext i32 %v4832 to i64
  %cond4834 = icmp ne i64 %cv4833, 0
  br i1 %cond4834, label %bb_rcgspecial1570, label %bb_rcginc1570
bb_rcginc1570:
  %v4835 = load i64, ptr %slot810, align 8
  %op4836 = sub i64 %v4835, 32
  store i64 %op4836, ptr %slot816, align 8
  %v4837 = load i64, ptr %slot810, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %rgep4839 = getelementptr i8, ptr %p4838, i64 -32
  %ld4840 = load i64, ptr %rgep4839, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4840, ptr %slot817, align 8
  %v4841 = load i64, ptr %slot817, align 8
  %op4842 = add i64 %v4841, 1
  store i64 %op4842, ptr %slot818, align 8
  %v4843 = load i64, ptr %slot818, align 8
  %cmp4844 = icmp eq i64 %v4843, 0
  %cv4845 = zext i1 %cmp4844 to i32
  store i32 %cv4845, ptr %slot819, align 8
  %v4846 = load i32, ptr %slot819, align 8
  %cv4847 = zext i32 %v4846 to i64
  %cond4848 = icmp ne i64 %cv4847, 0
  br i1 %cond4848, label %bb_rcglimit1570, label %bb_rcgcapacity1570
bb_rcglimit1570:
  %v4849 = load i64, ptr %slot1, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  %call4851 = call i32 @myl_qbe_rc_status(ptr %p4850, i32 2) nomerge, !dbg !154
  store i32 %call4851, ptr %slot820, align 8
  br label %bb_failure
bb_rcgcapacity1570:
  %v4852 = load i64, ptr %slot818, align 8
  %v4853 = load i64, ptr %slot810, align 8
  %p4854 = inttoptr i64 %v4853 to ptr
  %rgep4855 = getelementptr i8, ptr %p4854, i64 -32
  store i64 %v4852, ptr %rgep4855, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1570
bb_rcgspecial1570:
  %v4856 = load i64, ptr %slot813, align 8
  %op4857 = and i64 %v4856, 4611686018427387904
  store i64 %op4857, ptr %slot821, align 8
  %v4858 = load i64, ptr %slot821, align 8
  %cmp4859 = icmp ne i64 %v4858, 0
  %cv4860 = zext i1 %cmp4859 to i32
  store i32 %cv4860, ptr %slot822, align 8
  %v4861 = load i32, ptr %slot822, align 8
  %cv4862 = zext i32 %v4861 to i64
  %cond4863 = icmp ne i64 %cv4862, 0
  br i1 %cond4863, label %bb_rcgslow1570, label %bb_rcgplain1570
bb_rcgslow1570:
  %v4864 = load i64, ptr %slot33, align 8
  %v4865 = load i64, ptr %slot808, align 8
  %v4866 = load i64, ptr %slot786, align 8
  %v4867 = load i64, ptr %slot809, align 8
  %cv4868 = trunc i64 %v4867 to i32
  %call4869 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v4864, i64 %v4865, i64 %v4866, i32 %cv4868) nomerge, !dbg !154
  store i32 %call4869, ptr %slot823, align 8
  %v4870 = load i32, ptr %slot823, align 8
  %cv4871 = zext i32 %v4870 to i64
  %cond4872 = icmp ne i64 %cv4871, 0
  br i1 %cond4872, label %bb_rcsuccess1584, label %bb_rcfailure1584
bb_rcfailure1584:
  %v4873 = load i64, ptr %slot33, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  %call4875 = call i32 @myl_rc_take_failure(ptr %p4874) nomerge, !dbg !154
  store i32 %call4875, ptr %slot824, align 8
  %v4876 = load i64, ptr %slot1, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %v4878 = load i32, ptr %slot824, align 8
  %call4879 = call i32 @myl_qbe_rc_status(ptr %p4877, i32 %v4878) nomerge, !dbg !154
  store i32 %call4879, ptr %slot825, align 8
  br label %bb_failure
bb_rcsuccess1584:
  br label %bb_rcgdone1570
bb_rcgplain1570:
  %v4880 = load i64, ptr %slot810, align 8
  %v4881 = load i64, ptr %slot808, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  store i64 %v4880, ptr %p4882, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1570
bb_rcgdone1570:
  %v4883 = load i64, ptr %slot10, align 8
  %p4884 = inttoptr i64 %v4883 to ptr
  store i32 2, ptr %p4884, align 4, !alias.scope !3, !noalias !4
  %v4885 = load i64, ptr %slot9, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  store i32 1, ptr %p4886, align 4, !alias.scope !3, !noalias !4
  %v4887 = load i64, ptr %slot5, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %ld4889 = load i32, ptr %p4888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4889, ptr %slot826, align 8
  %v4890 = load i32, ptr %slot826, align 8
  %cv4891 = zext i32 %v4890 to i64
  %cond4892 = icmp ne i64 %cv4891, 0
  br i1 %cond4892, label %bb_rcslotdrop1591, label %bb_rcslotdone1591
bb_rcslotdrop1591:
  %v4893 = load i64, ptr %slot5, align 8
  %p4894 = inttoptr i64 %v4893 to ptr
  store i32 0, ptr %p4894, align 4, !alias.scope !3, !noalias !4
  %v4895 = load i64, ptr %slot11, align 8
  store i64 %v4895, ptr %slot827, align 8
  %v4896 = load i64, ptr %slot6, align 8
  %p4897 = inttoptr i64 %v4896 to ptr
  %ld4898 = load i32, ptr %p4897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4898, ptr %slot828, align 8
  %v4899 = load i32, ptr %slot828, align 8
  %op4900 = and i32 %v4899, 28
  store i32 %op4900, ptr %slot829, align 8
  %v4901 = load i32, ptr %slot829, align 8
  %cv4902 = zext i32 %v4901 to i64
  %cond4903 = icmp ne i64 %cv4902, 0
  br i1 %cond4903, label %bb_rcslotrole1591, label %bb_rcslotowner1591
bb_rcslotrole1591:
  %v4904 = load i64, ptr %slot33, align 8
  store i64 %v4904, ptr %slot830, align 8
  %v4905 = load i64, ptr %slot827, align 8
  %p4906 = inttoptr i64 %v4905 to ptr
  %ld4907 = load i64, ptr %p4906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4907, ptr %slot831, align 8
  %v4908 = load i64, ptr %slot831, align 8
  %cmp4909 = icmp ne i64 %v4908, 0
  %cv4910 = zext i1 %cmp4909 to i32
  store i32 %cv4910, ptr %slot832, align 8
  %v4911 = load i32, ptr %slot832, align 8
  %cv4912 = zext i32 %v4911 to i64
  %cond4913 = icmp ne i64 %cv4912, 0
  br i1 %cond4913, label %bb_rcgnn1607, label %bb_rcgdone1607
bb_rcgnn1607:
  %v4914 = load i64, ptr %slot831, align 8
  %op4915 = sub i64 %v4914, 16
  store i64 %op4915, ptr %slot833, align 8
  %v4916 = load i64, ptr %slot831, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  %rgep4918 = getelementptr i8, ptr %p4917, i64 -16
  %ld4919 = load i64, ptr %rgep4918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4919, ptr %slot834, align 8
  %v4920 = load i64, ptr %slot834, align 8
  %op4921 = and i64 %v4920, 4611686018427387906
  store i64 %op4921, ptr %slot835, align 8
  %v4922 = load i64, ptr %slot835, align 8
  %cmp4923 = icmp ne i64 %v4922, 0
  %cv4924 = zext i1 %cmp4923 to i32
  store i32 %cv4924, ptr %slot836, align 8
  %v4925 = load i32, ptr %slot836, align 8
  %cv4926 = zext i32 %v4925 to i64
  %cond4927 = icmp ne i64 %cv4926, 0
  br i1 %cond4927, label %bb_rcgclear1607, label %bb_rcgcounted1607
bb_rcgcounted1607:
  %v4928 = load i64, ptr %slot831, align 8
  %op4929 = sub i64 %v4928, 24
  store i64 %op4929, ptr %slot837, align 8
  %v4930 = load i64, ptr %slot831, align 8
  %p4931 = inttoptr i64 %v4930 to ptr
  %rgep4932 = getelementptr i8, ptr %p4931, i64 -24
  %ld4933 = load i64, ptr %rgep4932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4933, ptr %slot838, align 8
  %v4934 = load i64, ptr %slot838, align 8
  %op4935 = sub i64 %v4934, 1
  store i64 %op4935, ptr %slot839, align 8
  %v4936 = load i64, ptr %slot839, align 8
  %cmp4937 = icmp eq i64 %v4936, 0
  %cv4938 = zext i1 %cmp4937 to i32
  store i32 %cv4938, ptr %slot840, align 8
  %v4939 = load i32, ptr %slot840, align 8
  %cv4940 = zext i32 %v4939 to i64
  %cond4941 = icmp ne i64 %cv4940, 0
  br i1 %cond4941, label %bb_rcglast1607, label %bb_rcgdec1607
bb_rcglast1607:
  %v4942 = load i64, ptr %slot831, align 8
  %op4943 = sub i64 %v4942, 32
  store i64 %op4943, ptr %slot841, align 8
  %v4944 = load i64, ptr %slot831, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  %rgep4946 = getelementptr i8, ptr %p4945, i64 -32
  %ld4947 = load i64, ptr %rgep4946, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4947, ptr %slot842, align 8
  %v4948 = load i64, ptr %slot842, align 8
  %cmp4949 = icmp ne i64 %v4948, 0
  %cv4950 = zext i1 %cmp4949 to i32
  store i32 %cv4950, ptr %slot843, align 8
  %v4951 = load i32, ptr %slot843, align 8
  %cv4952 = zext i32 %v4951 to i64
  %cond4953 = icmp ne i64 %cv4952, 0
  br i1 %cond4953, label %bb_rcgdec1607, label %bb_rcgslow1607
bb_rcgslow1607:
  %v4954 = load i64, ptr %slot830, align 8
  %v4955 = load i64, ptr %slot827, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4954, i64 %v4955) nomerge, !dbg !154
  br label %bb_rcgdone1607
bb_rcgdec1607:
  %v4956 = load i64, ptr %slot839, align 8
  %v4957 = load i64, ptr %slot831, align 8
  %p4958 = inttoptr i64 %v4957 to ptr
  %rgep4959 = getelementptr i8, ptr %p4958, i64 -24
  store i64 %v4956, ptr %rgep4959, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1607
bb_rcgclear1607:
  %v4960 = load i64, ptr %slot827, align 8
  %p4961 = inttoptr i64 %v4960 to ptr
  store i64 0, ptr %p4961, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1607
bb_rcgdone1607:
  br label %bb_rcslotdone1591
bb_rcslotowner1591:
  %v4962 = load i64, ptr %slot33, align 8
  store i64 %v4962, ptr %slot844, align 8
  %v4963 = load i64, ptr %slot827, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  %ld4965 = load i64, ptr %p4964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4965, ptr %slot845, align 8
  %v4966 = load i64, ptr %slot845, align 8
  %cmp4967 = icmp ne i64 %v4966, 0
  %cv4968 = zext i1 %cmp4967 to i32
  store i32 %cv4968, ptr %slot846, align 8
  %v4969 = load i32, ptr %slot846, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rcgnn1622, label %bb_rcgdone1622
bb_rcgnn1622:
  %v4972 = load i64, ptr %slot845, align 8
  %op4973 = sub i64 %v4972, 16
  store i64 %op4973, ptr %slot847, align 8
  %v4974 = load i64, ptr %slot845, align 8
  %p4975 = inttoptr i64 %v4974 to ptr
  %rgep4976 = getelementptr i8, ptr %p4975, i64 -16
  %ld4977 = load i64, ptr %rgep4976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4977, ptr %slot848, align 8
  %v4978 = load i64, ptr %slot848, align 8
  %op4979 = and i64 %v4978, 4611686018427387906
  store i64 %op4979, ptr %slot849, align 8
  %v4980 = load i64, ptr %slot849, align 8
  %cmp4981 = icmp ne i64 %v4980, 0
  %cv4982 = zext i1 %cmp4981 to i32
  store i32 %cv4982, ptr %slot850, align 8
  %v4983 = load i32, ptr %slot850, align 8
  %cv4984 = zext i32 %v4983 to i64
  %cond4985 = icmp ne i64 %cv4984, 0
  br i1 %cond4985, label %bb_rcgclear1622, label %bb_rcgcounted1622
bb_rcgcounted1622:
  %v4986 = load i64, ptr %slot845, align 8
  %op4987 = sub i64 %v4986, 32
  store i64 %op4987, ptr %slot851, align 8
  %v4988 = load i64, ptr %slot845, align 8
  %p4989 = inttoptr i64 %v4988 to ptr
  %rgep4990 = getelementptr i8, ptr %p4989, i64 -32
  %ld4991 = load i64, ptr %rgep4990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4991, ptr %slot852, align 8
  %v4992 = load i64, ptr %slot852, align 8
  %op4993 = sub i64 %v4992, 1
  store i64 %op4993, ptr %slot853, align 8
  %v4994 = load i64, ptr %slot853, align 8
  %cmp4995 = icmp eq i64 %v4994, 0
  %cv4996 = zext i1 %cmp4995 to i32
  store i32 %cv4996, ptr %slot854, align 8
  %v4997 = load i32, ptr %slot854, align 8
  %cv4998 = zext i32 %v4997 to i64
  %cond4999 = icmp ne i64 %cv4998, 0
  br i1 %cond4999, label %bb_rcglast1622, label %bb_rcgdec1622
bb_rcglast1622:
  %v5000 = load i64, ptr %slot845, align 8
  %op5001 = sub i64 %v5000, 24
  store i64 %op5001, ptr %slot855, align 8
  %v5002 = load i64, ptr %slot845, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  %rgep5004 = getelementptr i8, ptr %p5003, i64 -24
  %ld5005 = load i64, ptr %rgep5004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5005, ptr %slot856, align 8
  %v5006 = load i64, ptr %slot856, align 8
  %cmp5007 = icmp ne i64 %v5006, 0
  %cv5008 = zext i1 %cmp5007 to i32
  store i32 %cv5008, ptr %slot857, align 8
  %v5009 = load i32, ptr %slot857, align 8
  %cv5010 = zext i32 %v5009 to i64
  %cond5011 = icmp ne i64 %cv5010, 0
  br i1 %cond5011, label %bb_rcgdec1622, label %bb_rcgslow1622
bb_rcgslow1622:
  %v5012 = load i64, ptr %slot844, align 8
  %v5013 = load i64, ptr %slot827, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5012, i64 %v5013) nomerge, !dbg !154
  br label %bb_rcgdone1622
bb_rcgdec1622:
  %v5014 = load i64, ptr %slot853, align 8
  %v5015 = load i64, ptr %slot845, align 8
  %p5016 = inttoptr i64 %v5015 to ptr
  %rgep5017 = getelementptr i8, ptr %p5016, i64 -32
  store i64 %v5014, ptr %rgep5017, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1622
bb_rcgclear1622:
  %v5018 = load i64, ptr %slot827, align 8
  %p5019 = inttoptr i64 %v5018 to ptr
  store i64 0, ptr %p5019, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1622
bb_rcgdone1622:
  br label %bb_rcslotdone1591
bb_rcslotdone1591:
  br label %bb_rcprepared1537
bb_rcprepared1537:
  %v5020 = load i64, ptr %slot15, align 8
  store i64 %v5020, ptr %slot858, align 8
  %v5021 = load i64, ptr %slot858, align 8
  %p5022 = inttoptr i64 %v5021 to ptr
  %ld5023 = load i64, ptr %p5022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5023, ptr %slot859, align 8
  %v5024 = load i64, ptr %slot9, align 8
  %p5025 = inttoptr i64 %v5024 to ptr
  store i32 0, ptr %p5025, align 4, !alias.scope !3, !noalias !4
  %v5026 = load i64, ptr %slot5, align 8
  %p5027 = inttoptr i64 %v5026 to ptr
  %ld5028 = load i32, ptr %p5027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5028, ptr %slot860, align 8
  %v5029 = load i32, ptr %slot860, align 8
  %cv5030 = zext i32 %v5029 to i64
  %cond5031 = icmp ne i64 %cv5030, 0
  br i1 %cond5031, label %bb_rcslotdrop1631, label %bb_rcslotdone1631
bb_rcslotdrop1631:
  %v5032 = load i64, ptr %slot5, align 8
  %p5033 = inttoptr i64 %v5032 to ptr
  store i32 0, ptr %p5033, align 4, !alias.scope !3, !noalias !4
  %v5034 = load i64, ptr %slot11, align 8
  store i64 %v5034, ptr %slot861, align 8
  %v5035 = load i64, ptr %slot6, align 8
  %p5036 = inttoptr i64 %v5035 to ptr
  %ld5037 = load i32, ptr %p5036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5037, ptr %slot862, align 8
  %v5038 = load i32, ptr %slot862, align 8
  %op5039 = and i32 %v5038, 28
  store i32 %op5039, ptr %slot863, align 8
  %v5040 = load i32, ptr %slot863, align 8
  %cv5041 = zext i32 %v5040 to i64
  %cond5042 = icmp ne i64 %cv5041, 0
  br i1 %cond5042, label %bb_rcslotrole1631, label %bb_rcslotowner1631
bb_rcslotrole1631:
  %v5043 = load i64, ptr %slot33, align 8
  store i64 %v5043, ptr %slot864, align 8
  %v5044 = load i64, ptr %slot861, align 8
  %p5045 = inttoptr i64 %v5044 to ptr
  %ld5046 = load i64, ptr %p5045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5046, ptr %slot865, align 8
  %v5047 = load i64, ptr %slot865, align 8
  %cmp5048 = icmp ne i64 %v5047, 0
  %cv5049 = zext i1 %cmp5048 to i32
  store i32 %cv5049, ptr %slot866, align 8
  %v5050 = load i32, ptr %slot866, align 8
  %cv5051 = zext i32 %v5050 to i64
  %cond5052 = icmp ne i64 %cv5051, 0
  br i1 %cond5052, label %bb_rcgnn1647, label %bb_rcgdone1647
bb_rcgnn1647:
  %v5053 = load i64, ptr %slot865, align 8
  %op5054 = sub i64 %v5053, 16
  store i64 %op5054, ptr %slot867, align 8
  %v5055 = load i64, ptr %slot865, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  %rgep5057 = getelementptr i8, ptr %p5056, i64 -16
  %ld5058 = load i64, ptr %rgep5057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5058, ptr %slot868, align 8
  %v5059 = load i64, ptr %slot868, align 8
  %op5060 = and i64 %v5059, 4611686018427387906
  store i64 %op5060, ptr %slot869, align 8
  %v5061 = load i64, ptr %slot869, align 8
  %cmp5062 = icmp ne i64 %v5061, 0
  %cv5063 = zext i1 %cmp5062 to i32
  store i32 %cv5063, ptr %slot870, align 8
  %v5064 = load i32, ptr %slot870, align 8
  %cv5065 = zext i32 %v5064 to i64
  %cond5066 = icmp ne i64 %cv5065, 0
  br i1 %cond5066, label %bb_rcgclear1647, label %bb_rcgcounted1647
bb_rcgcounted1647:
  %v5067 = load i64, ptr %slot865, align 8
  %op5068 = sub i64 %v5067, 24
  store i64 %op5068, ptr %slot871, align 8
  %v5069 = load i64, ptr %slot865, align 8
  %p5070 = inttoptr i64 %v5069 to ptr
  %rgep5071 = getelementptr i8, ptr %p5070, i64 -24
  %ld5072 = load i64, ptr %rgep5071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5072, ptr %slot872, align 8
  %v5073 = load i64, ptr %slot872, align 8
  %op5074 = sub i64 %v5073, 1
  store i64 %op5074, ptr %slot873, align 8
  %v5075 = load i64, ptr %slot873, align 8
  %cmp5076 = icmp eq i64 %v5075, 0
  %cv5077 = zext i1 %cmp5076 to i32
  store i32 %cv5077, ptr %slot874, align 8
  %v5078 = load i32, ptr %slot874, align 8
  %cv5079 = zext i32 %v5078 to i64
  %cond5080 = icmp ne i64 %cv5079, 0
  br i1 %cond5080, label %bb_rcglast1647, label %bb_rcgdec1647
bb_rcglast1647:
  %v5081 = load i64, ptr %slot865, align 8
  %op5082 = sub i64 %v5081, 32
  store i64 %op5082, ptr %slot875, align 8
  %v5083 = load i64, ptr %slot865, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  %rgep5085 = getelementptr i8, ptr %p5084, i64 -32
  %ld5086 = load i64, ptr %rgep5085, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5086, ptr %slot876, align 8
  %v5087 = load i64, ptr %slot876, align 8
  %cmp5088 = icmp ne i64 %v5087, 0
  %cv5089 = zext i1 %cmp5088 to i32
  store i32 %cv5089, ptr %slot877, align 8
  %v5090 = load i32, ptr %slot877, align 8
  %cv5091 = zext i32 %v5090 to i64
  %cond5092 = icmp ne i64 %cv5091, 0
  br i1 %cond5092, label %bb_rcgdec1647, label %bb_rcgslow1647
bb_rcgslow1647:
  %v5093 = load i64, ptr %slot864, align 8
  %v5094 = load i64, ptr %slot861, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5093, i64 %v5094) nomerge, !dbg !154
  br label %bb_rcgdone1647
bb_rcgdec1647:
  %v5095 = load i64, ptr %slot873, align 8
  %v5096 = load i64, ptr %slot865, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %rgep5098 = getelementptr i8, ptr %p5097, i64 -24
  store i64 %v5095, ptr %rgep5098, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1647
bb_rcgclear1647:
  %v5099 = load i64, ptr %slot861, align 8
  %p5100 = inttoptr i64 %v5099 to ptr
  store i64 0, ptr %p5100, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1647
bb_rcgdone1647:
  br label %bb_rcslotdone1631
bb_rcslotowner1631:
  %v5101 = load i64, ptr %slot33, align 8
  store i64 %v5101, ptr %slot878, align 8
  %v5102 = load i64, ptr %slot861, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  %ld5104 = load i64, ptr %p5103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5104, ptr %slot879, align 8
  %v5105 = load i64, ptr %slot879, align 8
  %cmp5106 = icmp ne i64 %v5105, 0
  %cv5107 = zext i1 %cmp5106 to i32
  store i32 %cv5107, ptr %slot880, align 8
  %v5108 = load i32, ptr %slot880, align 8
  %cv5109 = zext i32 %v5108 to i64
  %cond5110 = icmp ne i64 %cv5109, 0
  br i1 %cond5110, label %bb_rcgnn1662, label %bb_rcgdone1662
bb_rcgnn1662:
  %v5111 = load i64, ptr %slot879, align 8
  %op5112 = sub i64 %v5111, 16
  store i64 %op5112, ptr %slot881, align 8
  %v5113 = load i64, ptr %slot879, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  %rgep5115 = getelementptr i8, ptr %p5114, i64 -16
  %ld5116 = load i64, ptr %rgep5115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5116, ptr %slot882, align 8
  %v5117 = load i64, ptr %slot882, align 8
  %op5118 = and i64 %v5117, 4611686018427387906
  store i64 %op5118, ptr %slot883, align 8
  %v5119 = load i64, ptr %slot883, align 8
  %cmp5120 = icmp ne i64 %v5119, 0
  %cv5121 = zext i1 %cmp5120 to i32
  store i32 %cv5121, ptr %slot884, align 8
  %v5122 = load i32, ptr %slot884, align 8
  %cv5123 = zext i32 %v5122 to i64
  %cond5124 = icmp ne i64 %cv5123, 0
  br i1 %cond5124, label %bb_rcgclear1662, label %bb_rcgcounted1662
bb_rcgcounted1662:
  %v5125 = load i64, ptr %slot879, align 8
  %op5126 = sub i64 %v5125, 32
  store i64 %op5126, ptr %slot885, align 8
  %v5127 = load i64, ptr %slot879, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  %rgep5129 = getelementptr i8, ptr %p5128, i64 -32
  %ld5130 = load i64, ptr %rgep5129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5130, ptr %slot886, align 8
  %v5131 = load i64, ptr %slot886, align 8
  %op5132 = sub i64 %v5131, 1
  store i64 %op5132, ptr %slot887, align 8
  %v5133 = load i64, ptr %slot887, align 8
  %cmp5134 = icmp eq i64 %v5133, 0
  %cv5135 = zext i1 %cmp5134 to i32
  store i32 %cv5135, ptr %slot888, align 8
  %v5136 = load i32, ptr %slot888, align 8
  %cv5137 = zext i32 %v5136 to i64
  %cond5138 = icmp ne i64 %cv5137, 0
  br i1 %cond5138, label %bb_rcglast1662, label %bb_rcgdec1662
bb_rcglast1662:
  %v5139 = load i64, ptr %slot879, align 8
  %op5140 = sub i64 %v5139, 24
  store i64 %op5140, ptr %slot889, align 8
  %v5141 = load i64, ptr %slot879, align 8
  %p5142 = inttoptr i64 %v5141 to ptr
  %rgep5143 = getelementptr i8, ptr %p5142, i64 -24
  %ld5144 = load i64, ptr %rgep5143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5144, ptr %slot890, align 8
  %v5145 = load i64, ptr %slot890, align 8
  %cmp5146 = icmp ne i64 %v5145, 0
  %cv5147 = zext i1 %cmp5146 to i32
  store i32 %cv5147, ptr %slot891, align 8
  %v5148 = load i32, ptr %slot891, align 8
  %cv5149 = zext i32 %v5148 to i64
  %cond5150 = icmp ne i64 %cv5149, 0
  br i1 %cond5150, label %bb_rcgdec1662, label %bb_rcgslow1662
bb_rcgslow1662:
  %v5151 = load i64, ptr %slot878, align 8
  %v5152 = load i64, ptr %slot861, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5151, i64 %v5152) nomerge, !dbg !154
  br label %bb_rcgdone1662
bb_rcgdec1662:
  %v5153 = load i64, ptr %slot887, align 8
  %v5154 = load i64, ptr %slot879, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  %rgep5156 = getelementptr i8, ptr %p5155, i64 -32
  store i64 %v5153, ptr %rgep5156, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1662
bb_rcgclear1662:
  %v5157 = load i64, ptr %slot861, align 8
  %p5158 = inttoptr i64 %v5157 to ptr
  store i64 0, ptr %p5158, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1662
bb_rcgdone1662:
  br label %bb_rcslotdone1631
bb_rcslotdone1631:
  %v5159 = load i64, ptr %slot859, align 8
  ret i64 %v5159
bb_i56:
  %v5160 = load i64, ptr %slot16, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  %ld5162 = load i64, ptr %p5161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5162, ptr %slot892, align 8
  %v5163 = load i64, ptr %slot892, align 8
  %v5164 = load i64, ptr %slot26, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  store i64 %v5163, ptr %p5165, align 8, !alias.scope !3, !noalias !4
  %v5166 = load i64, ptr %slot24, align 8
  %v5167 = load i64, ptr %slot27, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  store i64 %v5166, ptr %p5168, align 8, !alias.scope !3, !noalias !4
  %v5169 = load i64, ptr %slot27, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  %ld5171 = load i64, ptr %p5170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5171, ptr %slot893, align 8
  %v5172 = load i64, ptr %slot893, align 8
  %op5173 = add i64 %v5172, 16
  store i64 %op5173, ptr %slot894, align 8
  %v5174 = load i64, ptr %slot894, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  %ld5176 = load i64, ptr %p5175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5176, ptr %slot895, align 8
  %v5177 = load i64, ptr %slot895, align 8
  %v5178 = load i64, ptr %slot27, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  store i64 %v5177, ptr %p5179, align 8, !alias.scope !3, !noalias !4
  %v5180 = load i64, ptr %slot26, align 8
  %p5181 = inttoptr i64 %v5180 to ptr
  %ld5182 = load i64, ptr %p5181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5182, ptr %slot896, align 8
  %v5183 = load i64, ptr %slot27, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  %ld5185 = load i64, ptr %p5184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5185, ptr %slot897, align 8
  %v5186 = load i64, ptr %slot1, align 8
  %v5187 = load i64, ptr %slot896, align 8
  %v5188 = load i64, ptr %slot897, align 8
  %call5189 = call i64 @myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686(i64 %v5186, i64 %v5187, i64 %v5188) nomerge, !dbg !156
  store i64 %call5189, ptr %slot898, align 8
  %v5190 = load i64, ptr %slot898, align 8
  %v5191 = load i64, ptr %slot26, align 8
  %p5192 = inttoptr i64 %v5191 to ptr
  store i64 %v5190, ptr %p5192, align 8, !alias.scope !3, !noalias !4
  %v5193 = load i64, ptr %slot26, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %ld5195 = load i64, ptr %p5194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5195, ptr %slot899, align 8
  %v5196 = load i64, ptr %slot899, align 8
  %v5197 = load i64, ptr %slot13, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  store i64 %v5196, ptr %p5198, align 8, !alias.scope !3, !noalias !4
  %v5199 = load i64, ptr %slot13, align 8
  store i64 %v5199, ptr %slot900, align 8
  %v5200 = load i64, ptr %slot15, align 8
  store i64 %v5200, ptr %slot901, align 8
  %v5201 = load i64, ptr %slot900, align 8
  %v5202 = load i64, ptr %slot901, align 8
  %p5203 = inttoptr i64 %v5201 to ptr
  %p5204 = inttoptr i64 %v5202 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5204, ptr %p5203, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5205 = load i64, ptr %slot10, align 8
  %p5206 = inttoptr i64 %v5205 to ptr
  store i32 2, ptr %p5206, align 4, !alias.scope !3, !noalias !4
  %v5207 = load i64, ptr %slot9, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  store i32 1, ptr %p5208, align 4, !alias.scope !3, !noalias !4
  %v5209 = load i64, ptr %slot5, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  %ld5211 = load i32, ptr %p5210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5211, ptr %slot902, align 8
  %v5212 = load i32, ptr %slot902, align 8
  %cv5213 = zext i32 %v5212 to i64
  %cond5214 = icmp ne i64 %cv5213, 0
  br i1 %cond5214, label %bb_rcslotdrop1762, label %bb_rcslotdone1762
bb_rcslotdrop1762:
  %v5215 = load i64, ptr %slot5, align 8
  %p5216 = inttoptr i64 %v5215 to ptr
  store i32 0, ptr %p5216, align 4, !alias.scope !3, !noalias !4
  %v5217 = load i64, ptr %slot11, align 8
  store i64 %v5217, ptr %slot903, align 8
  %v5218 = load i64, ptr %slot6, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %ld5220 = load i32, ptr %p5219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5220, ptr %slot904, align 8
  %v5221 = load i32, ptr %slot904, align 8
  %op5222 = and i32 %v5221, 28
  store i32 %op5222, ptr %slot905, align 8
  %v5223 = load i32, ptr %slot905, align 8
  %cv5224 = zext i32 %v5223 to i64
  %cond5225 = icmp ne i64 %cv5224, 0
  br i1 %cond5225, label %bb_rcslotrole1762, label %bb_rcslotowner1762
bb_rcslotrole1762:
  %v5226 = load i64, ptr %slot33, align 8
  store i64 %v5226, ptr %slot906, align 8
  %v5227 = load i64, ptr %slot906, align 8
  %v5228 = load i64, ptr %slot903, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5227, i64 %v5228) nomerge, !dbg !156
  br label %bb_rcslotdone1762
bb_rcslotowner1762:
  %v5229 = load i64, ptr %slot33, align 8
  store i64 %v5229, ptr %slot907, align 8
  %v5230 = load i64, ptr %slot907, align 8
  %v5231 = load i64, ptr %slot903, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5230, i64 %v5231) nomerge, !dbg !156
  br label %bb_rcslotdone1762
bb_rcslotdone1762:
  %v5232 = load i64, ptr %slot11, align 8
  store i64 %v5232, ptr %slot908, align 8
  %v5233 = load i64, ptr %slot15, align 8
  store i64 %v5233, ptr %slot909, align 8
  %v5234 = load i64, ptr %slot909, align 8
  %v5235 = load i64, ptr %slot908, align 8
  %p5236 = inttoptr i64 %v5234 to ptr
  %p5237 = inttoptr i64 %v5235 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5237, ptr %p5236, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5238 = load i64, ptr %slot6, align 8
  %p5239 = inttoptr i64 %v5238 to ptr
  store i32 2, ptr %p5239, align 4, !alias.scope !3, !noalias !4
  %v5240 = load i64, ptr %slot10, align 8
  %p5241 = inttoptr i64 %v5240 to ptr
  %ld5242 = load i32, ptr %p5241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5242, ptr %slot910, align 8
  %v5243 = load i32, ptr %slot910, align 8
  %v5244 = load i64, ptr %slot6, align 8
  %p5245 = inttoptr i64 %v5244 to ptr
  store i32 %v5243, ptr %p5245, align 4, !alias.scope !3, !noalias !4
  %v5246 = load i64, ptr %slot9, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  store i32 0, ptr %p5247, align 4, !alias.scope !3, !noalias !4
  %v5248 = load i64, ptr %slot5, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  store i32 1, ptr %p5249, align 4, !alias.scope !3, !noalias !4
  %v5250 = load i64, ptr %slot908, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  %ld5252 = load i64, ptr %p5251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5252, ptr %slot911, align 8
  %v5253 = load i64, ptr %slot911, align 8
  %v5254 = load i64, ptr %slot26, align 8
  %p5255 = inttoptr i64 %v5254 to ptr
  store i64 %v5253, ptr %p5255, align 8, !alias.scope !3, !noalias !4
  %v5256 = load i64, ptr %slot26, align 8
  %p5257 = inttoptr i64 %v5256 to ptr
  %ld5258 = load i64, ptr %p5257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5258, ptr %slot912, align 8
  %v5259 = load i64, ptr %slot26, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  %ld5261 = load i64, ptr %p5260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5261, ptr %slot913, align 8
  %v5262 = load i64, ptr %slot913, align 8
  %v5263 = load i64, ptr %slot13, align 8
  %p5264 = inttoptr i64 %v5263 to ptr
  store i64 %v5262, ptr %p5264, align 8, !alias.scope !3, !noalias !4
  %v5265 = load i64, ptr %slot13, align 8
  store i64 %v5265, ptr %slot914, align 8
  %v5266 = load i64, ptr %slot15, align 8
  store i64 %v5266, ptr %slot915, align 8
  %v5267 = load i64, ptr %slot34, align 8
  store i64 %v5267, ptr %slot916, align 8
  %v5268 = load i64, ptr %slot914, align 8
  %p5270 = inttoptr i64 %v5268 to ptr
  %gep5271 = getelementptr i8, ptr %p5270, i64 0
  %op5269 = ptrtoint ptr %gep5271 to i64
  store i64 %op5269, ptr %slot917, align 8
  %v5272 = load i64, ptr %slot917, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %ld5274 = load i64, ptr %p5273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5274, ptr %slot918, align 8
  %v5275 = load i64, ptr %slot918, align 8
  %cmp5276 = icmp ne i64 %v5275, 0
  %cv5277 = zext i1 %cmp5276 to i32
  store i32 %cv5277, ptr %slot919, align 8
  %v5278 = load i32, ptr %slot919, align 8
  %cv5279 = zext i32 %v5278 to i64
  %cond5280 = icmp ne i64 %cv5279, 0
  br i1 %cond5280, label %bb_rcmoveheader1786, label %bb_rcmovenext1786
bb_rcmoveheader1786:
  %v5281 = load i64, ptr %slot918, align 8
  %op5282 = sub i64 %v5281, 16
  store i64 %op5282, ptr %slot920, align 8
  %v5283 = load i64, ptr %slot918, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  %rgep5285 = getelementptr i8, ptr %p5284, i64 -16
  %ld5286 = load i64, ptr %rgep5285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5286, ptr %slot921, align 8
  %v5287 = load i64, ptr %slot921, align 8
  %op5288 = and i64 %v5287, 5764607523034234881
  store i64 %op5288, ptr %slot922, align 8
  %v5289 = load i64, ptr %slot922, align 8
  %cmp5290 = icmp ne i64 %v5289, 0
  %cv5291 = zext i1 %cmp5290 to i32
  store i32 %cv5291, ptr %slot923, align 8
  %v5292 = load i32, ptr %slot923, align 8
  %cv5293 = zext i32 %v5292 to i64
  %cond5294 = icmp ne i64 %cv5293, 0
  br i1 %cond5294, label %bb_rcmoveslow1783, label %bb_rcmovenext1786
bb_rcmovenext1786:
  %v5295 = load i64, ptr %slot914, align 8
  %v5296 = load i64, ptr %slot915, align 8
  %p5297 = inttoptr i64 %v5295 to ptr
  %p5298 = inttoptr i64 %v5296 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5298, ptr %p5297, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5299 = load i64, ptr %slot914, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  store i64 0, ptr %p5300, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1783
bb_rcmoveslow1783:
  %v5301 = load i64, ptr %slot33, align 8
  %v5302 = load i64, ptr %slot915, align 8
  %v5303 = load i64, ptr %slot914, align 8
  %v5304 = load i64, ptr %slot916, align 8
  %cv5305 = trunc i64 %v5304 to i32
  %call5306 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v5301, i64 %v5302, i64 %v5303, i32 %cv5305) nomerge, !dbg !158
  store i32 %call5306, ptr %slot924, align 8
  %v5307 = load i32, ptr %slot924, align 8
  %cv5308 = zext i32 %v5307 to i64
  %cond5309 = icmp ne i64 %cv5308, 0
  br i1 %cond5309, label %bb_rcsuccess1793, label %bb_rcfailure1793
bb_rcfailure1793:
  %v5310 = load i64, ptr %slot33, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %call5312 = call i32 @myl_rc_take_failure(ptr %p5311) nomerge, !dbg !158
  store i32 %call5312, ptr %slot925, align 8
  %v5313 = load i64, ptr %slot1, align 8
  %p5314 = inttoptr i64 %v5313 to ptr
  %v5315 = load i32, ptr %slot925, align 8
  %call5316 = call i32 @myl_qbe_rc_status(ptr %p5314, i32 %v5315) nomerge, !dbg !158
  store i32 %call5316, ptr %slot926, align 8
  br label %bb_failure
bb_rcsuccess1793:
  br label %bb_rcmoved1783
bb_rcmoved1783:
  %v5317 = load i64, ptr %slot5, align 8
  %p5318 = inttoptr i64 %v5317 to ptr
  store i32 0, ptr %p5318, align 4, !alias.scope !3, !noalias !4
  %v5319 = load i64, ptr %slot10, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  store i32 2, ptr %p5320, align 4, !alias.scope !3, !noalias !4
  %v5321 = load i64, ptr %slot9, align 8
  %p5322 = inttoptr i64 %v5321 to ptr
  store i32 1, ptr %p5322, align 4, !alias.scope !3, !noalias !4
  %v5323 = load i64, ptr %slot15, align 8
  store i64 %v5323, ptr %slot927, align 8
  %v5324 = load i64, ptr %slot927, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  %ld5326 = load i64, ptr %p5325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5326, ptr %slot928, align 8
  %v5327 = load i64, ptr %slot9, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  store i32 0, ptr %p5328, align 4, !alias.scope !3, !noalias !4
  %v5329 = load i64, ptr %slot5, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i32, ptr %p5330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5331, ptr %slot929, align 8
  %v5332 = load i32, ptr %slot929, align 8
  %cv5333 = zext i32 %v5332 to i64
  %cond5334 = icmp ne i64 %cv5333, 0
  br i1 %cond5334, label %bb_rcslotdrop1804, label %bb_rcslotdone1804
bb_rcslotdrop1804:
  %v5335 = load i64, ptr %slot5, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  store i32 0, ptr %p5336, align 4, !alias.scope !3, !noalias !4
  %v5337 = load i64, ptr %slot11, align 8
  store i64 %v5337, ptr %slot930, align 8
  %v5338 = load i64, ptr %slot6, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  %ld5340 = load i32, ptr %p5339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5340, ptr %slot931, align 8
  %v5341 = load i32, ptr %slot931, align 8
  %op5342 = and i32 %v5341, 28
  store i32 %op5342, ptr %slot932, align 8
  %v5343 = load i32, ptr %slot932, align 8
  %cv5344 = zext i32 %v5343 to i64
  %cond5345 = icmp ne i64 %cv5344, 0
  br i1 %cond5345, label %bb_rcslotrole1804, label %bb_rcslotowner1804
bb_rcslotrole1804:
  %v5346 = load i64, ptr %slot33, align 8
  store i64 %v5346, ptr %slot933, align 8
  %v5347 = load i64, ptr %slot930, align 8
  %p5348 = inttoptr i64 %v5347 to ptr
  %ld5349 = load i64, ptr %p5348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5349, ptr %slot934, align 8
  %v5350 = load i64, ptr %slot934, align 8
  %cmp5351 = icmp ne i64 %v5350, 0
  %cv5352 = zext i1 %cmp5351 to i32
  store i32 %cv5352, ptr %slot935, align 8
  %v5353 = load i32, ptr %slot935, align 8
  %cv5354 = zext i32 %v5353 to i64
  %cond5355 = icmp ne i64 %cv5354, 0
  br i1 %cond5355, label %bb_rcgnn1820, label %bb_rcgdone1820
bb_rcgnn1820:
  %v5356 = load i64, ptr %slot934, align 8
  %op5357 = sub i64 %v5356, 16
  store i64 %op5357, ptr %slot936, align 8
  %v5358 = load i64, ptr %slot934, align 8
  %p5359 = inttoptr i64 %v5358 to ptr
  %rgep5360 = getelementptr i8, ptr %p5359, i64 -16
  %ld5361 = load i64, ptr %rgep5360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5361, ptr %slot937, align 8
  %v5362 = load i64, ptr %slot937, align 8
  %op5363 = and i64 %v5362, 4611686018427387906
  store i64 %op5363, ptr %slot938, align 8
  %v5364 = load i64, ptr %slot938, align 8
  %cmp5365 = icmp ne i64 %v5364, 0
  %cv5366 = zext i1 %cmp5365 to i32
  store i32 %cv5366, ptr %slot939, align 8
  %v5367 = load i32, ptr %slot939, align 8
  %cv5368 = zext i32 %v5367 to i64
  %cond5369 = icmp ne i64 %cv5368, 0
  br i1 %cond5369, label %bb_rcgclear1820, label %bb_rcgcounted1820
bb_rcgcounted1820:
  %v5370 = load i64, ptr %slot934, align 8
  %op5371 = sub i64 %v5370, 24
  store i64 %op5371, ptr %slot940, align 8
  %v5372 = load i64, ptr %slot934, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  %rgep5374 = getelementptr i8, ptr %p5373, i64 -24
  %ld5375 = load i64, ptr %rgep5374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5375, ptr %slot941, align 8
  %v5376 = load i64, ptr %slot941, align 8
  %op5377 = sub i64 %v5376, 1
  store i64 %op5377, ptr %slot942, align 8
  %v5378 = load i64, ptr %slot942, align 8
  %cmp5379 = icmp eq i64 %v5378, 0
  %cv5380 = zext i1 %cmp5379 to i32
  store i32 %cv5380, ptr %slot943, align 8
  %v5381 = load i32, ptr %slot943, align 8
  %cv5382 = zext i32 %v5381 to i64
  %cond5383 = icmp ne i64 %cv5382, 0
  br i1 %cond5383, label %bb_rcglast1820, label %bb_rcgdec1820
bb_rcglast1820:
  %v5384 = load i64, ptr %slot934, align 8
  %op5385 = sub i64 %v5384, 32
  store i64 %op5385, ptr %slot944, align 8
  %v5386 = load i64, ptr %slot934, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %rgep5388 = getelementptr i8, ptr %p5387, i64 -32
  %ld5389 = load i64, ptr %rgep5388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5389, ptr %slot945, align 8
  %v5390 = load i64, ptr %slot945, align 8
  %cmp5391 = icmp ne i64 %v5390, 0
  %cv5392 = zext i1 %cmp5391 to i32
  store i32 %cv5392, ptr %slot946, align 8
  %v5393 = load i32, ptr %slot946, align 8
  %cv5394 = zext i32 %v5393 to i64
  %cond5395 = icmp ne i64 %cv5394, 0
  br i1 %cond5395, label %bb_rcgdec1820, label %bb_rcgslow1820
bb_rcgslow1820:
  %v5396 = load i64, ptr %slot933, align 8
  %v5397 = load i64, ptr %slot930, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5396, i64 %v5397) nomerge, !dbg !158
  br label %bb_rcgdone1820
bb_rcgdec1820:
  %v5398 = load i64, ptr %slot942, align 8
  %v5399 = load i64, ptr %slot934, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  %rgep5401 = getelementptr i8, ptr %p5400, i64 -24
  store i64 %v5398, ptr %rgep5401, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1820
bb_rcgclear1820:
  %v5402 = load i64, ptr %slot930, align 8
  %p5403 = inttoptr i64 %v5402 to ptr
  store i64 0, ptr %p5403, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1820
bb_rcgdone1820:
  br label %bb_rcslotdone1804
bb_rcslotowner1804:
  %v5404 = load i64, ptr %slot33, align 8
  store i64 %v5404, ptr %slot947, align 8
  %v5405 = load i64, ptr %slot930, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  %ld5407 = load i64, ptr %p5406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5407, ptr %slot948, align 8
  %v5408 = load i64, ptr %slot948, align 8
  %cmp5409 = icmp ne i64 %v5408, 0
  %cv5410 = zext i1 %cmp5409 to i32
  store i32 %cv5410, ptr %slot949, align 8
  %v5411 = load i32, ptr %slot949, align 8
  %cv5412 = zext i32 %v5411 to i64
  %cond5413 = icmp ne i64 %cv5412, 0
  br i1 %cond5413, label %bb_rcgnn1835, label %bb_rcgdone1835
bb_rcgnn1835:
  %v5414 = load i64, ptr %slot948, align 8
  %op5415 = sub i64 %v5414, 16
  store i64 %op5415, ptr %slot950, align 8
  %v5416 = load i64, ptr %slot948, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %rgep5418 = getelementptr i8, ptr %p5417, i64 -16
  %ld5419 = load i64, ptr %rgep5418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5419, ptr %slot951, align 8
  %v5420 = load i64, ptr %slot951, align 8
  %op5421 = and i64 %v5420, 4611686018427387906
  store i64 %op5421, ptr %slot952, align 8
  %v5422 = load i64, ptr %slot952, align 8
  %cmp5423 = icmp ne i64 %v5422, 0
  %cv5424 = zext i1 %cmp5423 to i32
  store i32 %cv5424, ptr %slot953, align 8
  %v5425 = load i32, ptr %slot953, align 8
  %cv5426 = zext i32 %v5425 to i64
  %cond5427 = icmp ne i64 %cv5426, 0
  br i1 %cond5427, label %bb_rcgclear1835, label %bb_rcgcounted1835
bb_rcgcounted1835:
  %v5428 = load i64, ptr %slot948, align 8
  %op5429 = sub i64 %v5428, 32
  store i64 %op5429, ptr %slot954, align 8
  %v5430 = load i64, ptr %slot948, align 8
  %p5431 = inttoptr i64 %v5430 to ptr
  %rgep5432 = getelementptr i8, ptr %p5431, i64 -32
  %ld5433 = load i64, ptr %rgep5432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5433, ptr %slot955, align 8
  %v5434 = load i64, ptr %slot955, align 8
  %op5435 = sub i64 %v5434, 1
  store i64 %op5435, ptr %slot956, align 8
  %v5436 = load i64, ptr %slot956, align 8
  %cmp5437 = icmp eq i64 %v5436, 0
  %cv5438 = zext i1 %cmp5437 to i32
  store i32 %cv5438, ptr %slot957, align 8
  %v5439 = load i32, ptr %slot957, align 8
  %cv5440 = zext i32 %v5439 to i64
  %cond5441 = icmp ne i64 %cv5440, 0
  br i1 %cond5441, label %bb_rcglast1835, label %bb_rcgdec1835
bb_rcglast1835:
  %v5442 = load i64, ptr %slot948, align 8
  %op5443 = sub i64 %v5442, 24
  store i64 %op5443, ptr %slot958, align 8
  %v5444 = load i64, ptr %slot948, align 8
  %p5445 = inttoptr i64 %v5444 to ptr
  %rgep5446 = getelementptr i8, ptr %p5445, i64 -24
  %ld5447 = load i64, ptr %rgep5446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5447, ptr %slot959, align 8
  %v5448 = load i64, ptr %slot959, align 8
  %cmp5449 = icmp ne i64 %v5448, 0
  %cv5450 = zext i1 %cmp5449 to i32
  store i32 %cv5450, ptr %slot960, align 8
  %v5451 = load i32, ptr %slot960, align 8
  %cv5452 = zext i32 %v5451 to i64
  %cond5453 = icmp ne i64 %cv5452, 0
  br i1 %cond5453, label %bb_rcgdec1835, label %bb_rcgslow1835
bb_rcgslow1835:
  %v5454 = load i64, ptr %slot947, align 8
  %v5455 = load i64, ptr %slot930, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5454, i64 %v5455) nomerge, !dbg !158
  br label %bb_rcgdone1835
bb_rcgdec1835:
  %v5456 = load i64, ptr %slot956, align 8
  %v5457 = load i64, ptr %slot948, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  %rgep5459 = getelementptr i8, ptr %p5458, i64 -32
  store i64 %v5456, ptr %rgep5459, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1835
bb_rcgclear1835:
  %v5460 = load i64, ptr %slot930, align 8
  %p5461 = inttoptr i64 %v5460 to ptr
  store i64 0, ptr %p5461, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1835
bb_rcgdone1835:
  br label %bb_rcslotdone1804
bb_rcslotdone1804:
  %v5462 = load i64, ptr %slot928, align 8
  ret i64 %v5462
bb_i61:
  %p5463 = inttoptr i64 ptrtoint (ptr @myl_lit_02537ee618e1438356c8bdec150c3ad61831da7f3bc9d35ea650823948165ff8 to i64) to ptr
  %ld5464 = load i64, ptr %p5463, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5464, ptr %slot961, align 8
  %v5465 = load i64, ptr %slot961, align 8
  %v5466 = load i64, ptr %slot26, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  store i64 %v5465, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  %v5468 = load i64, ptr %slot26, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  %ld5470 = load i64, ptr %p5469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5470, ptr %slot962, align 8
  %v5471 = load i64, ptr %slot962, align 8
  %v5472 = load i64, ptr %slot13, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  store i64 %v5471, ptr %p5473, align 8, !alias.scope !3, !noalias !4
  %v5474 = load i64, ptr %slot13, align 8
  store i64 %v5474, ptr %slot963, align 8
  %v5475 = load i64, ptr %slot15, align 8
  store i64 %v5475, ptr %slot964, align 8
  %v5476 = load i64, ptr %slot963, align 8
  %v5477 = load i64, ptr %slot964, align 8
  %p5478 = inttoptr i64 %v5476 to ptr
  %p5479 = inttoptr i64 %v5477 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5479, ptr %p5478, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5480 = load i64, ptr %slot10, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  store i32 2, ptr %p5481, align 4, !alias.scope !3, !noalias !4
  %v5482 = load i64, ptr %slot9, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  store i32 1, ptr %p5483, align 4, !alias.scope !3, !noalias !4
  %v5484 = load i64, ptr %slot11, align 8
  store i64 %v5484, ptr %slot965, align 8
  %v5485 = load i64, ptr %slot15, align 8
  store i64 %v5485, ptr %slot966, align 8
  %v5486 = load i64, ptr %slot966, align 8
  %v5487 = load i64, ptr %slot965, align 8
  %p5488 = inttoptr i64 %v5486 to ptr
  %p5489 = inttoptr i64 %v5487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5489, ptr %p5488, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5490 = load i64, ptr %slot6, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  store i32 2, ptr %p5491, align 4, !alias.scope !3, !noalias !4
  %v5492 = load i64, ptr %slot10, align 8
  %p5493 = inttoptr i64 %v5492 to ptr
  %ld5494 = load i32, ptr %p5493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5494, ptr %slot967, align 8
  %v5495 = load i32, ptr %slot967, align 8
  %v5496 = load i64, ptr %slot6, align 8
  %p5497 = inttoptr i64 %v5496 to ptr
  store i32 %v5495, ptr %p5497, align 4, !alias.scope !3, !noalias !4
  %v5498 = load i64, ptr %slot9, align 8
  %p5499 = inttoptr i64 %v5498 to ptr
  store i32 0, ptr %p5499, align 4, !alias.scope !3, !noalias !4
  %v5500 = load i64, ptr %slot5, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  store i32 1, ptr %p5501, align 4, !alias.scope !3, !noalias !4
  %v5502 = load i64, ptr %slot965, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %ld5504 = load i64, ptr %p5503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5504, ptr %slot968, align 8
  %v5505 = load i64, ptr %slot968, align 8
  %v5506 = load i64, ptr %slot26, align 8
  %p5507 = inttoptr i64 %v5506 to ptr
  store i64 %v5505, ptr %p5507, align 8, !alias.scope !3, !noalias !4
  %v5508 = load i64, ptr %slot26, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %ld5510 = load i64, ptr %p5509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5510, ptr %slot969, align 8
  %v5511 = load i64, ptr %slot26, align 8
  %p5512 = inttoptr i64 %v5511 to ptr
  %ld5513 = load i64, ptr %p5512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5513, ptr %slot970, align 8
  %v5514 = load i64, ptr %slot970, align 8
  %v5515 = load i64, ptr %slot13, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  store i64 %v5514, ptr %p5516, align 8, !alias.scope !3, !noalias !4
  %v5517 = load i64, ptr %slot13, align 8
  store i64 %v5517, ptr %slot971, align 8
  %v5518 = load i64, ptr %slot15, align 8
  store i64 %v5518, ptr %slot972, align 8
  %v5519 = load i64, ptr %slot34, align 8
  store i64 %v5519, ptr %slot973, align 8
  %v5520 = load i64, ptr %slot971, align 8
  %p5522 = inttoptr i64 %v5520 to ptr
  %gep5523 = getelementptr i8, ptr %p5522, i64 0
  %op5521 = ptrtoint ptr %gep5523 to i64
  store i64 %op5521, ptr %slot974, align 8
  %v5524 = load i64, ptr %slot974, align 8
  %p5525 = inttoptr i64 %v5524 to ptr
  %ld5526 = load i64, ptr %p5525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5526, ptr %slot975, align 8
  %v5527 = load i64, ptr %slot975, align 8
  %cmp5528 = icmp ne i64 %v5527, 0
  %cv5529 = zext i1 %cmp5528 to i32
  store i32 %cv5529, ptr %slot976, align 8
  %v5530 = load i32, ptr %slot976, align 8
  %cv5531 = zext i32 %v5530 to i64
  %cond5532 = icmp ne i64 %cv5531, 0
  br i1 %cond5532, label %bb_rcmoveheader1945, label %bb_rcmovenext1945
bb_rcmoveheader1945:
  %v5533 = load i64, ptr %slot975, align 8
  %op5534 = sub i64 %v5533, 16
  store i64 %op5534, ptr %slot977, align 8
  %v5535 = load i64, ptr %slot975, align 8
  %p5536 = inttoptr i64 %v5535 to ptr
  %rgep5537 = getelementptr i8, ptr %p5536, i64 -16
  %ld5538 = load i64, ptr %rgep5537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5538, ptr %slot978, align 8
  %v5539 = load i64, ptr %slot978, align 8
  %op5540 = and i64 %v5539, 5764607523034234881
  store i64 %op5540, ptr %slot979, align 8
  %v5541 = load i64, ptr %slot979, align 8
  %cmp5542 = icmp ne i64 %v5541, 0
  %cv5543 = zext i1 %cmp5542 to i32
  store i32 %cv5543, ptr %slot980, align 8
  %v5544 = load i32, ptr %slot980, align 8
  %cv5545 = zext i32 %v5544 to i64
  %cond5546 = icmp ne i64 %cv5545, 0
  br i1 %cond5546, label %bb_rcmoveslow1942, label %bb_rcmovenext1945
bb_rcmovenext1945:
  %v5547 = load i64, ptr %slot971, align 8
  %v5548 = load i64, ptr %slot972, align 8
  %p5549 = inttoptr i64 %v5547 to ptr
  %p5550 = inttoptr i64 %v5548 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5550, ptr %p5549, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5551 = load i64, ptr %slot971, align 8
  %p5552 = inttoptr i64 %v5551 to ptr
  store i64 0, ptr %p5552, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1942
bb_rcmoveslow1942:
  %v5553 = load i64, ptr %slot33, align 8
  %v5554 = load i64, ptr %slot972, align 8
  %v5555 = load i64, ptr %slot971, align 8
  %v5556 = load i64, ptr %slot973, align 8
  %cv5557 = trunc i64 %v5556 to i32
  %call5558 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v5553, i64 %v5554, i64 %v5555, i32 %cv5557) nomerge, !dbg !160
  store i32 %call5558, ptr %slot981, align 8
  %v5559 = load i32, ptr %slot981, align 8
  %cv5560 = zext i32 %v5559 to i64
  %cond5561 = icmp ne i64 %cv5560, 0
  br i1 %cond5561, label %bb_rcsuccess1952, label %bb_rcfailure1952
bb_rcfailure1952:
  %v5562 = load i64, ptr %slot33, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %call5564 = call i32 @myl_rc_take_failure(ptr %p5563) nomerge, !dbg !160
  store i32 %call5564, ptr %slot982, align 8
  %v5565 = load i64, ptr %slot1, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %v5567 = load i32, ptr %slot982, align 8
  %call5568 = call i32 @myl_qbe_rc_status(ptr %p5566, i32 %v5567) nomerge, !dbg !160
  store i32 %call5568, ptr %slot983, align 8
  br label %bb_failure
bb_rcsuccess1952:
  br label %bb_rcmoved1942
bb_rcmoved1942:
  %v5569 = load i64, ptr %slot5, align 8
  %p5570 = inttoptr i64 %v5569 to ptr
  store i32 0, ptr %p5570, align 4, !alias.scope !3, !noalias !4
  %v5571 = load i64, ptr %slot10, align 8
  %p5572 = inttoptr i64 %v5571 to ptr
  store i32 2, ptr %p5572, align 4, !alias.scope !3, !noalias !4
  %v5573 = load i64, ptr %slot9, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  store i32 1, ptr %p5574, align 4, !alias.scope !3, !noalias !4
  %v5575 = load i64, ptr %slot15, align 8
  store i64 %v5575, ptr %slot984, align 8
  %v5576 = load i64, ptr %slot984, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  %ld5578 = load i64, ptr %p5577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5578, ptr %slot985, align 8
  %v5579 = load i64, ptr %slot9, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i32 0, ptr %p5580, align 4, !alias.scope !3, !noalias !4
  %v5581 = load i64, ptr %slot5, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  %ld5583 = load i32, ptr %p5582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5583, ptr %slot986, align 8
  %v5584 = load i32, ptr %slot986, align 8
  %cv5585 = zext i32 %v5584 to i64
  %cond5586 = icmp ne i64 %cv5585, 0
  br i1 %cond5586, label %bb_rcslotdrop1963, label %bb_rcslotdone1963
bb_rcslotdrop1963:
  %v5587 = load i64, ptr %slot5, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  store i32 0, ptr %p5588, align 4, !alias.scope !3, !noalias !4
  %v5589 = load i64, ptr %slot11, align 8
  store i64 %v5589, ptr %slot987, align 8
  %v5590 = load i64, ptr %slot6, align 8
  %p5591 = inttoptr i64 %v5590 to ptr
  %ld5592 = load i32, ptr %p5591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5592, ptr %slot988, align 8
  %v5593 = load i32, ptr %slot988, align 8
  %op5594 = and i32 %v5593, 28
  store i32 %op5594, ptr %slot989, align 8
  %v5595 = load i32, ptr %slot989, align 8
  %cv5596 = zext i32 %v5595 to i64
  %cond5597 = icmp ne i64 %cv5596, 0
  br i1 %cond5597, label %bb_rcslotrole1963, label %bb_rcslotowner1963
bb_rcslotrole1963:
  %v5598 = load i64, ptr %slot33, align 8
  store i64 %v5598, ptr %slot990, align 8
  %v5599 = load i64, ptr %slot987, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  %ld5601 = load i64, ptr %p5600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5601, ptr %slot991, align 8
  %v5602 = load i64, ptr %slot991, align 8
  %cmp5603 = icmp ne i64 %v5602, 0
  %cv5604 = zext i1 %cmp5603 to i32
  store i32 %cv5604, ptr %slot992, align 8
  %v5605 = load i32, ptr %slot992, align 8
  %cv5606 = zext i32 %v5605 to i64
  %cond5607 = icmp ne i64 %cv5606, 0
  br i1 %cond5607, label %bb_rcgnn1979, label %bb_rcgdone1979
bb_rcgnn1979:
  %v5608 = load i64, ptr %slot991, align 8
  %op5609 = sub i64 %v5608, 16
  store i64 %op5609, ptr %slot993, align 8
  %v5610 = load i64, ptr %slot991, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  %rgep5612 = getelementptr i8, ptr %p5611, i64 -16
  %ld5613 = load i64, ptr %rgep5612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5613, ptr %slot994, align 8
  %v5614 = load i64, ptr %slot994, align 8
  %op5615 = and i64 %v5614, 4611686018427387906
  store i64 %op5615, ptr %slot995, align 8
  %v5616 = load i64, ptr %slot995, align 8
  %cmp5617 = icmp ne i64 %v5616, 0
  %cv5618 = zext i1 %cmp5617 to i32
  store i32 %cv5618, ptr %slot996, align 8
  %v5619 = load i32, ptr %slot996, align 8
  %cv5620 = zext i32 %v5619 to i64
  %cond5621 = icmp ne i64 %cv5620, 0
  br i1 %cond5621, label %bb_rcgclear1979, label %bb_rcgcounted1979
bb_rcgcounted1979:
  %v5622 = load i64, ptr %slot991, align 8
  %op5623 = sub i64 %v5622, 24
  store i64 %op5623, ptr %slot997, align 8
  %v5624 = load i64, ptr %slot991, align 8
  %p5625 = inttoptr i64 %v5624 to ptr
  %rgep5626 = getelementptr i8, ptr %p5625, i64 -24
  %ld5627 = load i64, ptr %rgep5626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5627, ptr %slot998, align 8
  %v5628 = load i64, ptr %slot998, align 8
  %op5629 = sub i64 %v5628, 1
  store i64 %op5629, ptr %slot999, align 8
  %v5630 = load i64, ptr %slot999, align 8
  %cmp5631 = icmp eq i64 %v5630, 0
  %cv5632 = zext i1 %cmp5631 to i32
  store i32 %cv5632, ptr %slot1000, align 8
  %v5633 = load i32, ptr %slot1000, align 8
  %cv5634 = zext i32 %v5633 to i64
  %cond5635 = icmp ne i64 %cv5634, 0
  br i1 %cond5635, label %bb_rcglast1979, label %bb_rcgdec1979
bb_rcglast1979:
  %v5636 = load i64, ptr %slot991, align 8
  %op5637 = sub i64 %v5636, 32
  store i64 %op5637, ptr %slot1001, align 8
  %v5638 = load i64, ptr %slot991, align 8
  %p5639 = inttoptr i64 %v5638 to ptr
  %rgep5640 = getelementptr i8, ptr %p5639, i64 -32
  %ld5641 = load i64, ptr %rgep5640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5641, ptr %slot1002, align 8
  %v5642 = load i64, ptr %slot1002, align 8
  %cmp5643 = icmp ne i64 %v5642, 0
  %cv5644 = zext i1 %cmp5643 to i32
  store i32 %cv5644, ptr %slot1003, align 8
  %v5645 = load i32, ptr %slot1003, align 8
  %cv5646 = zext i32 %v5645 to i64
  %cond5647 = icmp ne i64 %cv5646, 0
  br i1 %cond5647, label %bb_rcgdec1979, label %bb_rcgslow1979
bb_rcgslow1979:
  %v5648 = load i64, ptr %slot990, align 8
  %v5649 = load i64, ptr %slot987, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5648, i64 %v5649) nomerge, !dbg !160
  br label %bb_rcgdone1979
bb_rcgdec1979:
  %v5650 = load i64, ptr %slot999, align 8
  %v5651 = load i64, ptr %slot991, align 8
  %p5652 = inttoptr i64 %v5651 to ptr
  %rgep5653 = getelementptr i8, ptr %p5652, i64 -24
  store i64 %v5650, ptr %rgep5653, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1979
bb_rcgclear1979:
  %v5654 = load i64, ptr %slot987, align 8
  %p5655 = inttoptr i64 %v5654 to ptr
  store i64 0, ptr %p5655, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1979
bb_rcgdone1979:
  br label %bb_rcslotdone1963
bb_rcslotowner1963:
  %v5656 = load i64, ptr %slot33, align 8
  store i64 %v5656, ptr %slot1004, align 8
  %v5657 = load i64, ptr %slot987, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  %ld5659 = load i64, ptr %p5658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5659, ptr %slot1005, align 8
  %v5660 = load i64, ptr %slot1005, align 8
  %cmp5661 = icmp ne i64 %v5660, 0
  %cv5662 = zext i1 %cmp5661 to i32
  store i32 %cv5662, ptr %slot1006, align 8
  %v5663 = load i32, ptr %slot1006, align 8
  %cv5664 = zext i32 %v5663 to i64
  %cond5665 = icmp ne i64 %cv5664, 0
  br i1 %cond5665, label %bb_rcgnn1994, label %bb_rcgdone1994
bb_rcgnn1994:
  %v5666 = load i64, ptr %slot1005, align 8
  %op5667 = sub i64 %v5666, 16
  store i64 %op5667, ptr %slot1007, align 8
  %v5668 = load i64, ptr %slot1005, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  %rgep5670 = getelementptr i8, ptr %p5669, i64 -16
  %ld5671 = load i64, ptr %rgep5670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5671, ptr %slot1008, align 8
  %v5672 = load i64, ptr %slot1008, align 8
  %op5673 = and i64 %v5672, 4611686018427387906
  store i64 %op5673, ptr %slot1009, align 8
  %v5674 = load i64, ptr %slot1009, align 8
  %cmp5675 = icmp ne i64 %v5674, 0
  %cv5676 = zext i1 %cmp5675 to i32
  store i32 %cv5676, ptr %slot1010, align 8
  %v5677 = load i32, ptr %slot1010, align 8
  %cv5678 = zext i32 %v5677 to i64
  %cond5679 = icmp ne i64 %cv5678, 0
  br i1 %cond5679, label %bb_rcgclear1994, label %bb_rcgcounted1994
bb_rcgcounted1994:
  %v5680 = load i64, ptr %slot1005, align 8
  %op5681 = sub i64 %v5680, 32
  store i64 %op5681, ptr %slot1011, align 8
  %v5682 = load i64, ptr %slot1005, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  %rgep5684 = getelementptr i8, ptr %p5683, i64 -32
  %ld5685 = load i64, ptr %rgep5684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5685, ptr %slot1012, align 8
  %v5686 = load i64, ptr %slot1012, align 8
  %op5687 = sub i64 %v5686, 1
  store i64 %op5687, ptr %slot1013, align 8
  %v5688 = load i64, ptr %slot1013, align 8
  %cmp5689 = icmp eq i64 %v5688, 0
  %cv5690 = zext i1 %cmp5689 to i32
  store i32 %cv5690, ptr %slot1014, align 8
  %v5691 = load i32, ptr %slot1014, align 8
  %cv5692 = zext i32 %v5691 to i64
  %cond5693 = icmp ne i64 %cv5692, 0
  br i1 %cond5693, label %bb_rcglast1994, label %bb_rcgdec1994
bb_rcglast1994:
  %v5694 = load i64, ptr %slot1005, align 8
  %op5695 = sub i64 %v5694, 24
  store i64 %op5695, ptr %slot1015, align 8
  %v5696 = load i64, ptr %slot1005, align 8
  %p5697 = inttoptr i64 %v5696 to ptr
  %rgep5698 = getelementptr i8, ptr %p5697, i64 -24
  %ld5699 = load i64, ptr %rgep5698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5699, ptr %slot1016, align 8
  %v5700 = load i64, ptr %slot1016, align 8
  %cmp5701 = icmp ne i64 %v5700, 0
  %cv5702 = zext i1 %cmp5701 to i32
  store i32 %cv5702, ptr %slot1017, align 8
  %v5703 = load i32, ptr %slot1017, align 8
  %cv5704 = zext i32 %v5703 to i64
  %cond5705 = icmp ne i64 %cv5704, 0
  br i1 %cond5705, label %bb_rcgdec1994, label %bb_rcgslow1994
bb_rcgslow1994:
  %v5706 = load i64, ptr %slot1004, align 8
  %v5707 = load i64, ptr %slot987, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5706, i64 %v5707) nomerge, !dbg !160
  br label %bb_rcgdone1994
bb_rcgdec1994:
  %v5708 = load i64, ptr %slot1013, align 8
  %v5709 = load i64, ptr %slot1005, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  %rgep5711 = getelementptr i8, ptr %p5710, i64 -32
  store i64 %v5708, ptr %rgep5711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1994
bb_rcgclear1994:
  %v5712 = load i64, ptr %slot987, align 8
  %p5713 = inttoptr i64 %v5712 to ptr
  store i64 0, ptr %p5713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1994
bb_rcgdone1994:
  br label %bb_rcslotdone1963
bb_rcslotdone1963:
  %v5714 = load i64, ptr %slot985, align 8
  ret i64 %v5714
bb_i63:
  %p5715 = inttoptr i64 ptrtoint (ptr @myl_lit_6fed35e3009e497ab580214c876d7a746f7a24cf38303b15909afebc8b6b79d5 to i64) to ptr
  %ld5716 = load i64, ptr %p5715, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5716, ptr %slot1018, align 8
  %v5717 = load i64, ptr %slot1018, align 8
  %v5718 = load i64, ptr %slot26, align 8
  %p5719 = inttoptr i64 %v5718 to ptr
  store i64 %v5717, ptr %p5719, align 8, !alias.scope !3, !noalias !4
  %v5720 = load i64, ptr %slot26, align 8
  %p5721 = inttoptr i64 %v5720 to ptr
  %ld5722 = load i64, ptr %p5721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5722, ptr %slot1019, align 8
  %v5723 = load i64, ptr %slot1019, align 8
  %v5724 = load i64, ptr %slot13, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  store i64 %v5723, ptr %p5725, align 8, !alias.scope !3, !noalias !4
  %v5726 = load i64, ptr %slot13, align 8
  store i64 %v5726, ptr %slot1020, align 8
  %v5727 = load i64, ptr %slot15, align 8
  store i64 %v5727, ptr %slot1021, align 8
  %v5728 = load i64, ptr %slot1020, align 8
  %v5729 = load i64, ptr %slot1021, align 8
  %p5730 = inttoptr i64 %v5728 to ptr
  %p5731 = inttoptr i64 %v5729 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5731, ptr %p5730, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5732 = load i64, ptr %slot10, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  store i32 2, ptr %p5733, align 4, !alias.scope !3, !noalias !4
  %v5734 = load i64, ptr %slot9, align 8
  %p5735 = inttoptr i64 %v5734 to ptr
  store i32 1, ptr %p5735, align 4, !alias.scope !3, !noalias !4
  %v5736 = load i64, ptr %slot11, align 8
  store i64 %v5736, ptr %slot1022, align 8
  %v5737 = load i64, ptr %slot15, align 8
  store i64 %v5737, ptr %slot1023, align 8
  %v5738 = load i64, ptr %slot1023, align 8
  %v5739 = load i64, ptr %slot1022, align 8
  %p5740 = inttoptr i64 %v5738 to ptr
  %p5741 = inttoptr i64 %v5739 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5741, ptr %p5740, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5742 = load i64, ptr %slot6, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  store i32 2, ptr %p5743, align 4, !alias.scope !3, !noalias !4
  %v5744 = load i64, ptr %slot10, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %ld5746 = load i32, ptr %p5745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5746, ptr %slot1024, align 8
  %v5747 = load i32, ptr %slot1024, align 8
  %v5748 = load i64, ptr %slot6, align 8
  %p5749 = inttoptr i64 %v5748 to ptr
  store i32 %v5747, ptr %p5749, align 4, !alias.scope !3, !noalias !4
  %v5750 = load i64, ptr %slot9, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  store i32 0, ptr %p5751, align 4, !alias.scope !3, !noalias !4
  %v5752 = load i64, ptr %slot5, align 8
  %p5753 = inttoptr i64 %v5752 to ptr
  store i32 1, ptr %p5753, align 4, !alias.scope !3, !noalias !4
  %v5754 = load i64, ptr %slot1022, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  %ld5756 = load i64, ptr %p5755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5756, ptr %slot1025, align 8
  %v5757 = load i64, ptr %slot1025, align 8
  %v5758 = load i64, ptr %slot26, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  store i64 %v5757, ptr %p5759, align 8, !alias.scope !3, !noalias !4
  %v5760 = load i64, ptr %slot16, align 8
  %p5761 = inttoptr i64 %v5760 to ptr
  %ld5762 = load i64, ptr %p5761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5762, ptr %slot1026, align 8
  %v5763 = load i64, ptr %slot1026, align 8
  %v5764 = load i64, ptr %slot27, align 8
  %p5765 = inttoptr i64 %v5764 to ptr
  store i64 %v5763, ptr %p5765, align 8, !alias.scope !3, !noalias !4
  %v5766 = load i64, ptr %slot25, align 8
  %v5767 = load i64, ptr %slot28, align 8
  %p5768 = inttoptr i64 %v5767 to ptr
  store i64 %v5766, ptr %p5768, align 8, !alias.scope !3, !noalias !4
  %v5769 = load i64, ptr %slot28, align 8
  %p5770 = inttoptr i64 %v5769 to ptr
  %ld5771 = load i64, ptr %p5770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5771, ptr %slot1027, align 8
  %v5772 = load i64, ptr %slot1027, align 8
  %op5773 = add i64 %v5772, 8
  store i64 %op5773, ptr %slot1028, align 8
  %v5774 = load i64, ptr %slot1028, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  %ld5776 = load i64, ptr %p5775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5776, ptr %slot1029, align 8
  %v5777 = load i64, ptr %slot1029, align 8
  %v5778 = load i64, ptr %slot28, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  store i64 %v5777, ptr %p5779, align 8, !alias.scope !3, !noalias !4
  %v5780 = load i64, ptr %slot27, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  %ld5782 = load i64, ptr %p5781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5782, ptr %slot1030, align 8
  %v5783 = load i64, ptr %slot28, align 8
  %p5784 = inttoptr i64 %v5783 to ptr
  %ld5785 = load i64, ptr %p5784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5785, ptr %slot1031, align 8
  %v5786 = load i64, ptr %slot1, align 8
  %v5787 = load i64, ptr %slot1030, align 8
  %v5788 = load i64, ptr %slot1031, align 8
  %call5789 = call i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64 %v5786, i64 %v5787, i64 %v5788) nomerge, !dbg !162
  store i64 %call5789, ptr %slot1032, align 8
  %v5790 = load i64, ptr %slot1032, align 8
  %v5791 = load i64, ptr %slot27, align 8
  %p5792 = inttoptr i64 %v5791 to ptr
  store i64 %v5790, ptr %p5792, align 8, !alias.scope !3, !noalias !4
  %v5793 = load i64, ptr %slot7, align 8
  %p5794 = inttoptr i64 %v5793 to ptr
  %ld5795 = load i32, ptr %p5794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5795, ptr %slot1033, align 8
  %v5796 = load i32, ptr %slot1033, align 8
  %cv5797 = zext i32 %v5796 to i64
  %cond5798 = icmp ne i64 %cv5797, 0
  br i1 %cond5798, label %bb_rcslotdrop2105, label %bb_rcslotdone2105
bb_rcslotdrop2105:
  %v5799 = load i64, ptr %slot7, align 8
  %p5800 = inttoptr i64 %v5799 to ptr
  store i32 0, ptr %p5800, align 4, !alias.scope !3, !noalias !4
  %v5801 = load i64, ptr %slot12, align 8
  store i64 %v5801, ptr %slot1034, align 8
  %v5802 = load i64, ptr %slot8, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i32, ptr %p5803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5804, ptr %slot1035, align 8
  %v5805 = load i32, ptr %slot1035, align 8
  %op5806 = and i32 %v5805, 28
  store i32 %op5806, ptr %slot1036, align 8
  %v5807 = load i32, ptr %slot1036, align 8
  %cv5808 = zext i32 %v5807 to i64
  %cond5809 = icmp ne i64 %cv5808, 0
  br i1 %cond5809, label %bb_rcslotrole2105, label %bb_rcslotowner2105
bb_rcslotrole2105:
  %v5810 = load i64, ptr %slot33, align 8
  store i64 %v5810, ptr %slot1037, align 8
  %v5811 = load i64, ptr %slot1037, align 8
  %v5812 = load i64, ptr %slot1034, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5811, i64 %v5812) nomerge, !dbg !162
  br label %bb_rcslotdone2105
bb_rcslotowner2105:
  %v5813 = load i64, ptr %slot33, align 8
  store i64 %v5813, ptr %slot1038, align 8
  %v5814 = load i64, ptr %slot1038, align 8
  %v5815 = load i64, ptr %slot1034, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5814, i64 %v5815) nomerge, !dbg !162
  br label %bb_rcslotdone2105
bb_rcslotdone2105:
  %v5816 = load i64, ptr %slot26, align 8
  %p5817 = inttoptr i64 %v5816 to ptr
  %ld5818 = load i64, ptr %p5817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5818, ptr %slot1039, align 8
  %v5819 = load i64, ptr %slot27, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  %ld5821 = load i64, ptr %p5820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5821, ptr %slot1040, align 8
  %v5822 = load i64, ptr %slot26, align 8
  %p5823 = inttoptr i64 %v5822 to ptr
  %ld5824 = load i64, ptr %p5823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5824, ptr %slot1041, align 8
  %v5825 = load i64, ptr %slot27, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  %ld5827 = load i64, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5827, ptr %slot1042, align 8
  %v5828 = load i64, ptr %slot33, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  %v5830 = load i64, ptr %slot1041, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  %v5832 = load i64, ptr %slot1042, align 8
  %p5833 = inttoptr i64 %v5832 to ptr
  %call5834 = call ptr @myl_native_bytes_concat(ptr %p5829, ptr %p5831, ptr %p5833) nomerge, !dbg !164
  %calladdr5835 = ptrtoint ptr %call5834 to i64
  store i64 %calladdr5835, ptr %slot1043, align 8
  %v5836 = load i64, ptr %slot1043, align 8
  %cond5837 = icmp ne i64 %v5836, 0
  br i1 %cond5837, label %bb_success2118, label %bb_failed2118
bb_failed2118:
  %v5838 = load i64, ptr %slot1, align 8
  %p5839 = inttoptr i64 %v5838 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5839) nomerge, !dbg !164
  unreachable
bb_success2118:
  %v5840 = load i64, ptr %slot1043, align 8
  %v5841 = load i64, ptr %slot26, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i64 %v5840, ptr %p5842, align 8, !alias.scope !3, !noalias !4
  %v5843 = load i64, ptr %slot26, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  %ld5845 = load i64, ptr %p5844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5845, ptr %slot1044, align 8
  %v5846 = load i64, ptr %slot1044, align 8
  %v5847 = load i64, ptr %slot13, align 8
  %p5848 = inttoptr i64 %v5847 to ptr
  store i64 %v5846, ptr %p5848, align 8, !alias.scope !3, !noalias !4
  %v5849 = load i64, ptr %slot13, align 8
  store i64 %v5849, ptr %slot1045, align 8
  %v5850 = load i64, ptr %slot15, align 8
  store i64 %v5850, ptr %slot1046, align 8
  %v5851 = load i64, ptr %slot1045, align 8
  %v5852 = load i64, ptr %slot1046, align 8
  %p5853 = inttoptr i64 %v5851 to ptr
  %p5854 = inttoptr i64 %v5852 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5854, ptr %p5853, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5855 = load i64, ptr %slot10, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  store i32 2, ptr %p5856, align 4, !alias.scope !3, !noalias !4
  %v5857 = load i64, ptr %slot9, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  store i32 1, ptr %p5858, align 4, !alias.scope !3, !noalias !4
  %v5859 = load i64, ptr %slot5, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  %ld5861 = load i32, ptr %p5860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5861, ptr %slot1047, align 8
  %v5862 = load i32, ptr %slot1047, align 8
  %cv5863 = zext i32 %v5862 to i64
  %cond5864 = icmp ne i64 %cv5863, 0
  br i1 %cond5864, label %bb_rcslotdrop2126, label %bb_rcslotdone2126
bb_rcslotdrop2126:
  %v5865 = load i64, ptr %slot5, align 8
  %p5866 = inttoptr i64 %v5865 to ptr
  store i32 0, ptr %p5866, align 4, !alias.scope !3, !noalias !4
  %v5867 = load i64, ptr %slot11, align 8
  store i64 %v5867, ptr %slot1048, align 8
  %v5868 = load i64, ptr %slot6, align 8
  %p5869 = inttoptr i64 %v5868 to ptr
  %ld5870 = load i32, ptr %p5869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5870, ptr %slot1049, align 8
  %v5871 = load i32, ptr %slot1049, align 8
  %op5872 = and i32 %v5871, 28
  store i32 %op5872, ptr %slot1050, align 8
  %v5873 = load i32, ptr %slot1050, align 8
  %cv5874 = zext i32 %v5873 to i64
  %cond5875 = icmp ne i64 %cv5874, 0
  br i1 %cond5875, label %bb_rcslotrole2126, label %bb_rcslotowner2126
bb_rcslotrole2126:
  %v5876 = load i64, ptr %slot33, align 8
  store i64 %v5876, ptr %slot1051, align 8
  %v5877 = load i64, ptr %slot1048, align 8
  %p5878 = inttoptr i64 %v5877 to ptr
  %ld5879 = load i64, ptr %p5878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5879, ptr %slot1052, align 8
  %v5880 = load i64, ptr %slot1052, align 8
  %cmp5881 = icmp ne i64 %v5880, 0
  %cv5882 = zext i1 %cmp5881 to i32
  store i32 %cv5882, ptr %slot1053, align 8
  %v5883 = load i32, ptr %slot1053, align 8
  %cv5884 = zext i32 %v5883 to i64
  %cond5885 = icmp ne i64 %cv5884, 0
  br i1 %cond5885, label %bb_rcgnn2142, label %bb_rcgdone2142
bb_rcgnn2142:
  %v5886 = load i64, ptr %slot1052, align 8
  %op5887 = sub i64 %v5886, 16
  store i64 %op5887, ptr %slot1054, align 8
  %v5888 = load i64, ptr %slot1052, align 8
  %p5889 = inttoptr i64 %v5888 to ptr
  %rgep5890 = getelementptr i8, ptr %p5889, i64 -16
  %ld5891 = load i64, ptr %rgep5890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5891, ptr %slot1055, align 8
  %v5892 = load i64, ptr %slot1055, align 8
  %op5893 = and i64 %v5892, 4611686018427387906
  store i64 %op5893, ptr %slot1056, align 8
  %v5894 = load i64, ptr %slot1056, align 8
  %cmp5895 = icmp ne i64 %v5894, 0
  %cv5896 = zext i1 %cmp5895 to i32
  store i32 %cv5896, ptr %slot1057, align 8
  %v5897 = load i32, ptr %slot1057, align 8
  %cv5898 = zext i32 %v5897 to i64
  %cond5899 = icmp ne i64 %cv5898, 0
  br i1 %cond5899, label %bb_rcgclear2142, label %bb_rcgcounted2142
bb_rcgcounted2142:
  %v5900 = load i64, ptr %slot1052, align 8
  %op5901 = sub i64 %v5900, 24
  store i64 %op5901, ptr %slot1058, align 8
  %v5902 = load i64, ptr %slot1052, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  %rgep5904 = getelementptr i8, ptr %p5903, i64 -24
  %ld5905 = load i64, ptr %rgep5904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5905, ptr %slot1059, align 8
  %v5906 = load i64, ptr %slot1059, align 8
  %op5907 = sub i64 %v5906, 1
  store i64 %op5907, ptr %slot1060, align 8
  %v5908 = load i64, ptr %slot1060, align 8
  %cmp5909 = icmp eq i64 %v5908, 0
  %cv5910 = zext i1 %cmp5909 to i32
  store i32 %cv5910, ptr %slot1061, align 8
  %v5911 = load i32, ptr %slot1061, align 8
  %cv5912 = zext i32 %v5911 to i64
  %cond5913 = icmp ne i64 %cv5912, 0
  br i1 %cond5913, label %bb_rcglast2142, label %bb_rcgdec2142
bb_rcglast2142:
  %v5914 = load i64, ptr %slot1052, align 8
  %op5915 = sub i64 %v5914, 32
  store i64 %op5915, ptr %slot1062, align 8
  %v5916 = load i64, ptr %slot1052, align 8
  %p5917 = inttoptr i64 %v5916 to ptr
  %rgep5918 = getelementptr i8, ptr %p5917, i64 -32
  %ld5919 = load i64, ptr %rgep5918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5919, ptr %slot1063, align 8
  %v5920 = load i64, ptr %slot1063, align 8
  %cmp5921 = icmp ne i64 %v5920, 0
  %cv5922 = zext i1 %cmp5921 to i32
  store i32 %cv5922, ptr %slot1064, align 8
  %v5923 = load i32, ptr %slot1064, align 8
  %cv5924 = zext i32 %v5923 to i64
  %cond5925 = icmp ne i64 %cv5924, 0
  br i1 %cond5925, label %bb_rcgdec2142, label %bb_rcgslow2142
bb_rcgslow2142:
  %v5926 = load i64, ptr %slot1051, align 8
  %v5927 = load i64, ptr %slot1048, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5926, i64 %v5927) nomerge, !dbg !164
  br label %bb_rcgdone2142
bb_rcgdec2142:
  %v5928 = load i64, ptr %slot1060, align 8
  %v5929 = load i64, ptr %slot1052, align 8
  %p5930 = inttoptr i64 %v5929 to ptr
  %rgep5931 = getelementptr i8, ptr %p5930, i64 -24
  store i64 %v5928, ptr %rgep5931, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2142
bb_rcgclear2142:
  %v5932 = load i64, ptr %slot1048, align 8
  %p5933 = inttoptr i64 %v5932 to ptr
  store i64 0, ptr %p5933, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2142
bb_rcgdone2142:
  br label %bb_rcslotdone2126
bb_rcslotowner2126:
  %v5934 = load i64, ptr %slot33, align 8
  store i64 %v5934, ptr %slot1065, align 8
  %v5935 = load i64, ptr %slot1048, align 8
  %p5936 = inttoptr i64 %v5935 to ptr
  %ld5937 = load i64, ptr %p5936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5937, ptr %slot1066, align 8
  %v5938 = load i64, ptr %slot1066, align 8
  %cmp5939 = icmp ne i64 %v5938, 0
  %cv5940 = zext i1 %cmp5939 to i32
  store i32 %cv5940, ptr %slot1067, align 8
  %v5941 = load i32, ptr %slot1067, align 8
  %cv5942 = zext i32 %v5941 to i64
  %cond5943 = icmp ne i64 %cv5942, 0
  br i1 %cond5943, label %bb_rcgnn2157, label %bb_rcgdone2157
bb_rcgnn2157:
  %v5944 = load i64, ptr %slot1066, align 8
  %op5945 = sub i64 %v5944, 16
  store i64 %op5945, ptr %slot1068, align 8
  %v5946 = load i64, ptr %slot1066, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  %rgep5948 = getelementptr i8, ptr %p5947, i64 -16
  %ld5949 = load i64, ptr %rgep5948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5949, ptr %slot1069, align 8
  %v5950 = load i64, ptr %slot1069, align 8
  %op5951 = and i64 %v5950, 4611686018427387906
  store i64 %op5951, ptr %slot1070, align 8
  %v5952 = load i64, ptr %slot1070, align 8
  %cmp5953 = icmp ne i64 %v5952, 0
  %cv5954 = zext i1 %cmp5953 to i32
  store i32 %cv5954, ptr %slot1071, align 8
  %v5955 = load i32, ptr %slot1071, align 8
  %cv5956 = zext i32 %v5955 to i64
  %cond5957 = icmp ne i64 %cv5956, 0
  br i1 %cond5957, label %bb_rcgclear2157, label %bb_rcgcounted2157
bb_rcgcounted2157:
  %v5958 = load i64, ptr %slot1066, align 8
  %op5959 = sub i64 %v5958, 32
  store i64 %op5959, ptr %slot1072, align 8
  %v5960 = load i64, ptr %slot1066, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  %rgep5962 = getelementptr i8, ptr %p5961, i64 -32
  %ld5963 = load i64, ptr %rgep5962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5963, ptr %slot1073, align 8
  %v5964 = load i64, ptr %slot1073, align 8
  %op5965 = sub i64 %v5964, 1
  store i64 %op5965, ptr %slot1074, align 8
  %v5966 = load i64, ptr %slot1074, align 8
  %cmp5967 = icmp eq i64 %v5966, 0
  %cv5968 = zext i1 %cmp5967 to i32
  store i32 %cv5968, ptr %slot1075, align 8
  %v5969 = load i32, ptr %slot1075, align 8
  %cv5970 = zext i32 %v5969 to i64
  %cond5971 = icmp ne i64 %cv5970, 0
  br i1 %cond5971, label %bb_rcglast2157, label %bb_rcgdec2157
bb_rcglast2157:
  %v5972 = load i64, ptr %slot1066, align 8
  %op5973 = sub i64 %v5972, 24
  store i64 %op5973, ptr %slot1076, align 8
  %v5974 = load i64, ptr %slot1066, align 8
  %p5975 = inttoptr i64 %v5974 to ptr
  %rgep5976 = getelementptr i8, ptr %p5975, i64 -24
  %ld5977 = load i64, ptr %rgep5976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5977, ptr %slot1077, align 8
  %v5978 = load i64, ptr %slot1077, align 8
  %cmp5979 = icmp ne i64 %v5978, 0
  %cv5980 = zext i1 %cmp5979 to i32
  store i32 %cv5980, ptr %slot1078, align 8
  %v5981 = load i32, ptr %slot1078, align 8
  %cv5982 = zext i32 %v5981 to i64
  %cond5983 = icmp ne i64 %cv5982, 0
  br i1 %cond5983, label %bb_rcgdec2157, label %bb_rcgslow2157
bb_rcgslow2157:
  %v5984 = load i64, ptr %slot1065, align 8
  %v5985 = load i64, ptr %slot1048, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5984, i64 %v5985) nomerge, !dbg !164
  br label %bb_rcgdone2157
bb_rcgdec2157:
  %v5986 = load i64, ptr %slot1074, align 8
  %v5987 = load i64, ptr %slot1066, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  %rgep5989 = getelementptr i8, ptr %p5988, i64 -32
  store i64 %v5986, ptr %rgep5989, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2157
bb_rcgclear2157:
  %v5990 = load i64, ptr %slot1048, align 8
  %p5991 = inttoptr i64 %v5990 to ptr
  store i64 0, ptr %p5991, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2157
bb_rcgdone2157:
  br label %bb_rcslotdone2126
bb_rcslotdone2126:
  %v5992 = load i64, ptr %slot7, align 8
  %p5993 = inttoptr i64 %v5992 to ptr
  %ld5994 = load i32, ptr %p5993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5994, ptr %slot1079, align 8
  %v5995 = load i32, ptr %slot1079, align 8
  %cv5996 = zext i32 %v5995 to i64
  %cond5997 = icmp ne i64 %cv5996, 0
  br i1 %cond5997, label %bb_rcslotdrop2163, label %bb_rcslotdone2163
bb_rcslotdrop2163:
  %v5998 = load i64, ptr %slot7, align 8
  %p5999 = inttoptr i64 %v5998 to ptr
  store i32 0, ptr %p5999, align 4, !alias.scope !3, !noalias !4
  %v6000 = load i64, ptr %slot12, align 8
  store i64 %v6000, ptr %slot1080, align 8
  %v6001 = load i64, ptr %slot8, align 8
  %p6002 = inttoptr i64 %v6001 to ptr
  %ld6003 = load i32, ptr %p6002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6003, ptr %slot1081, align 8
  %v6004 = load i32, ptr %slot1081, align 8
  %op6005 = and i32 %v6004, 28
  store i32 %op6005, ptr %slot1082, align 8
  %v6006 = load i32, ptr %slot1082, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcslotrole2163, label %bb_rcslotowner2163
bb_rcslotrole2163:
  %v6009 = load i64, ptr %slot33, align 8
  store i64 %v6009, ptr %slot1083, align 8
  %v6010 = load i64, ptr %slot1080, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  %ld6012 = load i64, ptr %p6011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6012, ptr %slot1084, align 8
  %v6013 = load i64, ptr %slot1084, align 8
  %cmp6014 = icmp ne i64 %v6013, 0
  %cv6015 = zext i1 %cmp6014 to i32
  store i32 %cv6015, ptr %slot1085, align 8
  %v6016 = load i32, ptr %slot1085, align 8
  %cv6017 = zext i32 %v6016 to i64
  %cond6018 = icmp ne i64 %cv6017, 0
  br i1 %cond6018, label %bb_rcgnn2179, label %bb_rcgdone2179
bb_rcgnn2179:
  %v6019 = load i64, ptr %slot1084, align 8
  %op6020 = sub i64 %v6019, 16
  store i64 %op6020, ptr %slot1086, align 8
  %v6021 = load i64, ptr %slot1084, align 8
  %p6022 = inttoptr i64 %v6021 to ptr
  %rgep6023 = getelementptr i8, ptr %p6022, i64 -16
  %ld6024 = load i64, ptr %rgep6023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6024, ptr %slot1087, align 8
  %v6025 = load i64, ptr %slot1087, align 8
  %op6026 = and i64 %v6025, 4611686018427387906
  store i64 %op6026, ptr %slot1088, align 8
  %v6027 = load i64, ptr %slot1088, align 8
  %cmp6028 = icmp ne i64 %v6027, 0
  %cv6029 = zext i1 %cmp6028 to i32
  store i32 %cv6029, ptr %slot1089, align 8
  %v6030 = load i32, ptr %slot1089, align 8
  %cv6031 = zext i32 %v6030 to i64
  %cond6032 = icmp ne i64 %cv6031, 0
  br i1 %cond6032, label %bb_rcgclear2179, label %bb_rcgcounted2179
bb_rcgcounted2179:
  %v6033 = load i64, ptr %slot1084, align 8
  %op6034 = sub i64 %v6033, 24
  store i64 %op6034, ptr %slot1090, align 8
  %v6035 = load i64, ptr %slot1084, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  %rgep6037 = getelementptr i8, ptr %p6036, i64 -24
  %ld6038 = load i64, ptr %rgep6037, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6038, ptr %slot1091, align 8
  %v6039 = load i64, ptr %slot1091, align 8
  %op6040 = sub i64 %v6039, 1
  store i64 %op6040, ptr %slot1092, align 8
  %v6041 = load i64, ptr %slot1092, align 8
  %cmp6042 = icmp eq i64 %v6041, 0
  %cv6043 = zext i1 %cmp6042 to i32
  store i32 %cv6043, ptr %slot1093, align 8
  %v6044 = load i32, ptr %slot1093, align 8
  %cv6045 = zext i32 %v6044 to i64
  %cond6046 = icmp ne i64 %cv6045, 0
  br i1 %cond6046, label %bb_rcglast2179, label %bb_rcgdec2179
bb_rcglast2179:
  %v6047 = load i64, ptr %slot1084, align 8
  %op6048 = sub i64 %v6047, 32
  store i64 %op6048, ptr %slot1094, align 8
  %v6049 = load i64, ptr %slot1084, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  %rgep6051 = getelementptr i8, ptr %p6050, i64 -32
  %ld6052 = load i64, ptr %rgep6051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6052, ptr %slot1095, align 8
  %v6053 = load i64, ptr %slot1095, align 8
  %cmp6054 = icmp ne i64 %v6053, 0
  %cv6055 = zext i1 %cmp6054 to i32
  store i32 %cv6055, ptr %slot1096, align 8
  %v6056 = load i32, ptr %slot1096, align 8
  %cv6057 = zext i32 %v6056 to i64
  %cond6058 = icmp ne i64 %cv6057, 0
  br i1 %cond6058, label %bb_rcgdec2179, label %bb_rcgslow2179
bb_rcgslow2179:
  %v6059 = load i64, ptr %slot1083, align 8
  %v6060 = load i64, ptr %slot1080, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6059, i64 %v6060) nomerge, !dbg !164
  br label %bb_rcgdone2179
bb_rcgdec2179:
  %v6061 = load i64, ptr %slot1092, align 8
  %v6062 = load i64, ptr %slot1084, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  %rgep6064 = getelementptr i8, ptr %p6063, i64 -24
  store i64 %v6061, ptr %rgep6064, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2179
bb_rcgclear2179:
  %v6065 = load i64, ptr %slot1080, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  store i64 0, ptr %p6066, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2179
bb_rcgdone2179:
  br label %bb_rcslotdone2163
bb_rcslotowner2163:
  %v6067 = load i64, ptr %slot33, align 8
  store i64 %v6067, ptr %slot1097, align 8
  %v6068 = load i64, ptr %slot1080, align 8
  %p6069 = inttoptr i64 %v6068 to ptr
  %ld6070 = load i64, ptr %p6069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6070, ptr %slot1098, align 8
  %v6071 = load i64, ptr %slot1098, align 8
  %cmp6072 = icmp ne i64 %v6071, 0
  %cv6073 = zext i1 %cmp6072 to i32
  store i32 %cv6073, ptr %slot1099, align 8
  %v6074 = load i32, ptr %slot1099, align 8
  %cv6075 = zext i32 %v6074 to i64
  %cond6076 = icmp ne i64 %cv6075, 0
  br i1 %cond6076, label %bb_rcgnn2194, label %bb_rcgdone2194
bb_rcgnn2194:
  %v6077 = load i64, ptr %slot1098, align 8
  %op6078 = sub i64 %v6077, 16
  store i64 %op6078, ptr %slot1100, align 8
  %v6079 = load i64, ptr %slot1098, align 8
  %p6080 = inttoptr i64 %v6079 to ptr
  %rgep6081 = getelementptr i8, ptr %p6080, i64 -16
  %ld6082 = load i64, ptr %rgep6081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6082, ptr %slot1101, align 8
  %v6083 = load i64, ptr %slot1101, align 8
  %op6084 = and i64 %v6083, 4611686018427387906
  store i64 %op6084, ptr %slot1102, align 8
  %v6085 = load i64, ptr %slot1102, align 8
  %cmp6086 = icmp ne i64 %v6085, 0
  %cv6087 = zext i1 %cmp6086 to i32
  store i32 %cv6087, ptr %slot1103, align 8
  %v6088 = load i32, ptr %slot1103, align 8
  %cv6089 = zext i32 %v6088 to i64
  %cond6090 = icmp ne i64 %cv6089, 0
  br i1 %cond6090, label %bb_rcgclear2194, label %bb_rcgcounted2194
bb_rcgcounted2194:
  %v6091 = load i64, ptr %slot1098, align 8
  %op6092 = sub i64 %v6091, 32
  store i64 %op6092, ptr %slot1104, align 8
  %v6093 = load i64, ptr %slot1098, align 8
  %p6094 = inttoptr i64 %v6093 to ptr
  %rgep6095 = getelementptr i8, ptr %p6094, i64 -32
  %ld6096 = load i64, ptr %rgep6095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6096, ptr %slot1105, align 8
  %v6097 = load i64, ptr %slot1105, align 8
  %op6098 = sub i64 %v6097, 1
  store i64 %op6098, ptr %slot1106, align 8
  %v6099 = load i64, ptr %slot1106, align 8
  %cmp6100 = icmp eq i64 %v6099, 0
  %cv6101 = zext i1 %cmp6100 to i32
  store i32 %cv6101, ptr %slot1107, align 8
  %v6102 = load i32, ptr %slot1107, align 8
  %cv6103 = zext i32 %v6102 to i64
  %cond6104 = icmp ne i64 %cv6103, 0
  br i1 %cond6104, label %bb_rcglast2194, label %bb_rcgdec2194
bb_rcglast2194:
  %v6105 = load i64, ptr %slot1098, align 8
  %op6106 = sub i64 %v6105, 24
  store i64 %op6106, ptr %slot1108, align 8
  %v6107 = load i64, ptr %slot1098, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %rgep6109 = getelementptr i8, ptr %p6108, i64 -24
  %ld6110 = load i64, ptr %rgep6109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6110, ptr %slot1109, align 8
  %v6111 = load i64, ptr %slot1109, align 8
  %cmp6112 = icmp ne i64 %v6111, 0
  %cv6113 = zext i1 %cmp6112 to i32
  store i32 %cv6113, ptr %slot1110, align 8
  %v6114 = load i32, ptr %slot1110, align 8
  %cv6115 = zext i32 %v6114 to i64
  %cond6116 = icmp ne i64 %cv6115, 0
  br i1 %cond6116, label %bb_rcgdec2194, label %bb_rcgslow2194
bb_rcgslow2194:
  %v6117 = load i64, ptr %slot1097, align 8
  %v6118 = load i64, ptr %slot1080, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6117, i64 %v6118) nomerge, !dbg !164
  br label %bb_rcgdone2194
bb_rcgdec2194:
  %v6119 = load i64, ptr %slot1106, align 8
  %v6120 = load i64, ptr %slot1098, align 8
  %p6121 = inttoptr i64 %v6120 to ptr
  %rgep6122 = getelementptr i8, ptr %p6121, i64 -32
  store i64 %v6119, ptr %rgep6122, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2194
bb_rcgclear2194:
  %v6123 = load i64, ptr %slot1080, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  store i64 0, ptr %p6124, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2194
bb_rcgdone2194:
  br label %bb_rcslotdone2163
bb_rcslotdone2163:
  %v6125 = load i64, ptr %slot11, align 8
  store i64 %v6125, ptr %slot1111, align 8
  %v6126 = load i64, ptr %slot15, align 8
  store i64 %v6126, ptr %slot1112, align 8
  %v6127 = load i64, ptr %slot1112, align 8
  %v6128 = load i64, ptr %slot1111, align 8
  %p6129 = inttoptr i64 %v6127 to ptr
  %p6130 = inttoptr i64 %v6128 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6130, ptr %p6129, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6131 = load i64, ptr %slot6, align 8
  %p6132 = inttoptr i64 %v6131 to ptr
  store i32 2, ptr %p6132, align 4, !alias.scope !3, !noalias !4
  %v6133 = load i64, ptr %slot10, align 8
  %p6134 = inttoptr i64 %v6133 to ptr
  %ld6135 = load i32, ptr %p6134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6135, ptr %slot1113, align 8
  %v6136 = load i32, ptr %slot1113, align 8
  %v6137 = load i64, ptr %slot6, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  store i32 %v6136, ptr %p6138, align 4, !alias.scope !3, !noalias !4
  %v6139 = load i64, ptr %slot9, align 8
  %p6140 = inttoptr i64 %v6139 to ptr
  store i32 0, ptr %p6140, align 4, !alias.scope !3, !noalias !4
  %v6141 = load i64, ptr %slot5, align 8
  %p6142 = inttoptr i64 %v6141 to ptr
  store i32 1, ptr %p6142, align 4, !alias.scope !3, !noalias !4
  %v6143 = load i64, ptr %slot1111, align 8
  %p6144 = inttoptr i64 %v6143 to ptr
  %ld6145 = load i64, ptr %p6144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6145, ptr %slot1114, align 8
  %v6146 = load i64, ptr %slot1114, align 8
  %v6147 = load i64, ptr %slot26, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  store i64 %v6146, ptr %p6148, align 8, !alias.scope !3, !noalias !4
  %p6149 = inttoptr i64 ptrtoint (ptr @myl_lit_d6b006dd0b769e0e5a8bb806c60978be91d208b60a28fe604b56cb4713aa8698 to i64) to ptr
  %ld6150 = load i64, ptr %p6149, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6150, ptr %slot1115, align 8
  %v6151 = load i64, ptr %slot1115, align 8
  %v6152 = load i64, ptr %slot27, align 8
  %p6153 = inttoptr i64 %v6152 to ptr
  store i64 %v6151, ptr %p6153, align 8, !alias.scope !3, !noalias !4
  %v6154 = load i64, ptr %slot27, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  %ld6156 = load i64, ptr %p6155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6156, ptr %slot1116, align 8
  %v6157 = load i64, ptr %slot1116, align 8
  %v6158 = load i64, ptr %slot14, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  store i64 %v6157, ptr %p6159, align 8, !alias.scope !3, !noalias !4
  %v6160 = load i64, ptr %slot14, align 8
  store i64 %v6160, ptr %slot1117, align 8
  %v6161 = load i64, ptr %slot15, align 8
  store i64 %v6161, ptr %slot1118, align 8
  %v6162 = load i64, ptr %slot1117, align 8
  %v6163 = load i64, ptr %slot1118, align 8
  %p6164 = inttoptr i64 %v6162 to ptr
  %p6165 = inttoptr i64 %v6163 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6165, ptr %p6164, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6166 = load i64, ptr %slot10, align 8
  %p6167 = inttoptr i64 %v6166 to ptr
  store i32 2, ptr %p6167, align 4, !alias.scope !3, !noalias !4
  %v6168 = load i64, ptr %slot9, align 8
  %p6169 = inttoptr i64 %v6168 to ptr
  store i32 1, ptr %p6169, align 4, !alias.scope !3, !noalias !4
  %v6170 = load i64, ptr %slot12, align 8
  store i64 %v6170, ptr %slot1119, align 8
  %v6171 = load i64, ptr %slot15, align 8
  store i64 %v6171, ptr %slot1120, align 8
  %v6172 = load i64, ptr %slot1120, align 8
  %v6173 = load i64, ptr %slot1119, align 8
  %p6174 = inttoptr i64 %v6172 to ptr
  %p6175 = inttoptr i64 %v6173 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6175, ptr %p6174, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6176 = load i64, ptr %slot8, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  store i32 2, ptr %p6177, align 4, !alias.scope !3, !noalias !4
  %v6178 = load i64, ptr %slot10, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i32, ptr %p6179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6180, ptr %slot1121, align 8
  %v6181 = load i32, ptr %slot1121, align 8
  %v6182 = load i64, ptr %slot8, align 8
  %p6183 = inttoptr i64 %v6182 to ptr
  store i32 %v6181, ptr %p6183, align 4, !alias.scope !3, !noalias !4
  %v6184 = load i64, ptr %slot9, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  store i32 0, ptr %p6185, align 4, !alias.scope !3, !noalias !4
  %v6186 = load i64, ptr %slot7, align 8
  %p6187 = inttoptr i64 %v6186 to ptr
  store i32 1, ptr %p6187, align 4, !alias.scope !3, !noalias !4
  %v6188 = load i64, ptr %slot1119, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %ld6190 = load i64, ptr %p6189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6190, ptr %slot1122, align 8
  %v6191 = load i64, ptr %slot1122, align 8
  %v6192 = load i64, ptr %slot27, align 8
  %p6193 = inttoptr i64 %v6192 to ptr
  store i64 %v6191, ptr %p6193, align 8, !alias.scope !3, !noalias !4
  %v6194 = load i64, ptr %slot26, align 8
  %p6195 = inttoptr i64 %v6194 to ptr
  %ld6196 = load i64, ptr %p6195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6196, ptr %slot1123, align 8
  %v6197 = load i64, ptr %slot27, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  %ld6199 = load i64, ptr %p6198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6199, ptr %slot1124, align 8
  %v6200 = load i64, ptr %slot26, align 8
  %p6201 = inttoptr i64 %v6200 to ptr
  %ld6202 = load i64, ptr %p6201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6202, ptr %slot1125, align 8
  %v6203 = load i64, ptr %slot27, align 8
  %p6204 = inttoptr i64 %v6203 to ptr
  %ld6205 = load i64, ptr %p6204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6205, ptr %slot1126, align 8
  %v6206 = load i64, ptr %slot33, align 8
  %p6207 = inttoptr i64 %v6206 to ptr
  %v6208 = load i64, ptr %slot1125, align 8
  %p6209 = inttoptr i64 %v6208 to ptr
  %v6210 = load i64, ptr %slot1126, align 8
  %p6211 = inttoptr i64 %v6210 to ptr
  %call6212 = call ptr @myl_native_bytes_concat(ptr %p6207, ptr %p6209, ptr %p6211) nomerge, !dbg !166
  %calladdr6213 = ptrtoint ptr %call6212 to i64
  store i64 %calladdr6213, ptr %slot1127, align 8
  %v6214 = load i64, ptr %slot1127, align 8
  %cond6215 = icmp ne i64 %v6214, 0
  br i1 %cond6215, label %bb_success2229, label %bb_failed2229
bb_failed2229:
  %v6216 = load i64, ptr %slot1, align 8
  %p6217 = inttoptr i64 %v6216 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6217) nomerge, !dbg !166
  unreachable
bb_success2229:
  %v6218 = load i64, ptr %slot1127, align 8
  %v6219 = load i64, ptr %slot26, align 8
  %p6220 = inttoptr i64 %v6219 to ptr
  store i64 %v6218, ptr %p6220, align 8, !alias.scope !3, !noalias !4
  %v6221 = load i64, ptr %slot26, align 8
  %p6222 = inttoptr i64 %v6221 to ptr
  %ld6223 = load i64, ptr %p6222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6223, ptr %slot1128, align 8
  %v6224 = load i64, ptr %slot1128, align 8
  %v6225 = load i64, ptr %slot13, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  store i64 %v6224, ptr %p6226, align 8, !alias.scope !3, !noalias !4
  %v6227 = load i64, ptr %slot13, align 8
  store i64 %v6227, ptr %slot1129, align 8
  %v6228 = load i64, ptr %slot15, align 8
  store i64 %v6228, ptr %slot1130, align 8
  %v6229 = load i64, ptr %slot1129, align 8
  %v6230 = load i64, ptr %slot1130, align 8
  %p6231 = inttoptr i64 %v6229 to ptr
  %p6232 = inttoptr i64 %v6230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6232, ptr %p6231, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6233 = load i64, ptr %slot10, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  store i32 2, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  %v6235 = load i64, ptr %slot9, align 8
  %p6236 = inttoptr i64 %v6235 to ptr
  store i32 1, ptr %p6236, align 4, !alias.scope !3, !noalias !4
  %v6237 = load i64, ptr %slot5, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  %ld6239 = load i32, ptr %p6238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6239, ptr %slot1131, align 8
  %v6240 = load i32, ptr %slot1131, align 8
  %cv6241 = zext i32 %v6240 to i64
  %cond6242 = icmp ne i64 %cv6241, 0
  br i1 %cond6242, label %bb_rcslotdrop2237, label %bb_rcslotdone2237
bb_rcslotdrop2237:
  %v6243 = load i64, ptr %slot5, align 8
  %p6244 = inttoptr i64 %v6243 to ptr
  store i32 0, ptr %p6244, align 4, !alias.scope !3, !noalias !4
  %v6245 = load i64, ptr %slot11, align 8
  store i64 %v6245, ptr %slot1132, align 8
  %v6246 = load i64, ptr %slot6, align 8
  %p6247 = inttoptr i64 %v6246 to ptr
  %ld6248 = load i32, ptr %p6247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6248, ptr %slot1133, align 8
  %v6249 = load i32, ptr %slot1133, align 8
  %op6250 = and i32 %v6249, 28
  store i32 %op6250, ptr %slot1134, align 8
  %v6251 = load i32, ptr %slot1134, align 8
  %cv6252 = zext i32 %v6251 to i64
  %cond6253 = icmp ne i64 %cv6252, 0
  br i1 %cond6253, label %bb_rcslotrole2237, label %bb_rcslotowner2237
bb_rcslotrole2237:
  %v6254 = load i64, ptr %slot33, align 8
  store i64 %v6254, ptr %slot1135, align 8
  %v6255 = load i64, ptr %slot1132, align 8
  %p6256 = inttoptr i64 %v6255 to ptr
  %ld6257 = load i64, ptr %p6256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6257, ptr %slot1136, align 8
  %v6258 = load i64, ptr %slot1136, align 8
  %cmp6259 = icmp ne i64 %v6258, 0
  %cv6260 = zext i1 %cmp6259 to i32
  store i32 %cv6260, ptr %slot1137, align 8
  %v6261 = load i32, ptr %slot1137, align 8
  %cv6262 = zext i32 %v6261 to i64
  %cond6263 = icmp ne i64 %cv6262, 0
  br i1 %cond6263, label %bb_rcgnn2253, label %bb_rcgdone2253
bb_rcgnn2253:
  %v6264 = load i64, ptr %slot1136, align 8
  %op6265 = sub i64 %v6264, 16
  store i64 %op6265, ptr %slot1138, align 8
  %v6266 = load i64, ptr %slot1136, align 8
  %p6267 = inttoptr i64 %v6266 to ptr
  %rgep6268 = getelementptr i8, ptr %p6267, i64 -16
  %ld6269 = load i64, ptr %rgep6268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6269, ptr %slot1139, align 8
  %v6270 = load i64, ptr %slot1139, align 8
  %op6271 = and i64 %v6270, 4611686018427387906
  store i64 %op6271, ptr %slot1140, align 8
  %v6272 = load i64, ptr %slot1140, align 8
  %cmp6273 = icmp ne i64 %v6272, 0
  %cv6274 = zext i1 %cmp6273 to i32
  store i32 %cv6274, ptr %slot1141, align 8
  %v6275 = load i32, ptr %slot1141, align 8
  %cv6276 = zext i32 %v6275 to i64
  %cond6277 = icmp ne i64 %cv6276, 0
  br i1 %cond6277, label %bb_rcgclear2253, label %bb_rcgcounted2253
bb_rcgcounted2253:
  %v6278 = load i64, ptr %slot1136, align 8
  %op6279 = sub i64 %v6278, 24
  store i64 %op6279, ptr %slot1142, align 8
  %v6280 = load i64, ptr %slot1136, align 8
  %p6281 = inttoptr i64 %v6280 to ptr
  %rgep6282 = getelementptr i8, ptr %p6281, i64 -24
  %ld6283 = load i64, ptr %rgep6282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6283, ptr %slot1143, align 8
  %v6284 = load i64, ptr %slot1143, align 8
  %op6285 = sub i64 %v6284, 1
  store i64 %op6285, ptr %slot1144, align 8
  %v6286 = load i64, ptr %slot1144, align 8
  %cmp6287 = icmp eq i64 %v6286, 0
  %cv6288 = zext i1 %cmp6287 to i32
  store i32 %cv6288, ptr %slot1145, align 8
  %v6289 = load i32, ptr %slot1145, align 8
  %cv6290 = zext i32 %v6289 to i64
  %cond6291 = icmp ne i64 %cv6290, 0
  br i1 %cond6291, label %bb_rcglast2253, label %bb_rcgdec2253
bb_rcglast2253:
  %v6292 = load i64, ptr %slot1136, align 8
  %op6293 = sub i64 %v6292, 32
  store i64 %op6293, ptr %slot1146, align 8
  %v6294 = load i64, ptr %slot1136, align 8
  %p6295 = inttoptr i64 %v6294 to ptr
  %rgep6296 = getelementptr i8, ptr %p6295, i64 -32
  %ld6297 = load i64, ptr %rgep6296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6297, ptr %slot1147, align 8
  %v6298 = load i64, ptr %slot1147, align 8
  %cmp6299 = icmp ne i64 %v6298, 0
  %cv6300 = zext i1 %cmp6299 to i32
  store i32 %cv6300, ptr %slot1148, align 8
  %v6301 = load i32, ptr %slot1148, align 8
  %cv6302 = zext i32 %v6301 to i64
  %cond6303 = icmp ne i64 %cv6302, 0
  br i1 %cond6303, label %bb_rcgdec2253, label %bb_rcgslow2253
bb_rcgslow2253:
  %v6304 = load i64, ptr %slot1135, align 8
  %v6305 = load i64, ptr %slot1132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6304, i64 %v6305) nomerge, !dbg !166
  br label %bb_rcgdone2253
bb_rcgdec2253:
  %v6306 = load i64, ptr %slot1144, align 8
  %v6307 = load i64, ptr %slot1136, align 8
  %p6308 = inttoptr i64 %v6307 to ptr
  %rgep6309 = getelementptr i8, ptr %p6308, i64 -24
  store i64 %v6306, ptr %rgep6309, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2253
bb_rcgclear2253:
  %v6310 = load i64, ptr %slot1132, align 8
  %p6311 = inttoptr i64 %v6310 to ptr
  store i64 0, ptr %p6311, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2253
bb_rcgdone2253:
  br label %bb_rcslotdone2237
bb_rcslotowner2237:
  %v6312 = load i64, ptr %slot33, align 8
  store i64 %v6312, ptr %slot1149, align 8
  %v6313 = load i64, ptr %slot1132, align 8
  %p6314 = inttoptr i64 %v6313 to ptr
  %ld6315 = load i64, ptr %p6314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6315, ptr %slot1150, align 8
  %v6316 = load i64, ptr %slot1150, align 8
  %cmp6317 = icmp ne i64 %v6316, 0
  %cv6318 = zext i1 %cmp6317 to i32
  store i32 %cv6318, ptr %slot1151, align 8
  %v6319 = load i32, ptr %slot1151, align 8
  %cv6320 = zext i32 %v6319 to i64
  %cond6321 = icmp ne i64 %cv6320, 0
  br i1 %cond6321, label %bb_rcgnn2268, label %bb_rcgdone2268
bb_rcgnn2268:
  %v6322 = load i64, ptr %slot1150, align 8
  %op6323 = sub i64 %v6322, 16
  store i64 %op6323, ptr %slot1152, align 8
  %v6324 = load i64, ptr %slot1150, align 8
  %p6325 = inttoptr i64 %v6324 to ptr
  %rgep6326 = getelementptr i8, ptr %p6325, i64 -16
  %ld6327 = load i64, ptr %rgep6326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6327, ptr %slot1153, align 8
  %v6328 = load i64, ptr %slot1153, align 8
  %op6329 = and i64 %v6328, 4611686018427387906
  store i64 %op6329, ptr %slot1154, align 8
  %v6330 = load i64, ptr %slot1154, align 8
  %cmp6331 = icmp ne i64 %v6330, 0
  %cv6332 = zext i1 %cmp6331 to i32
  store i32 %cv6332, ptr %slot1155, align 8
  %v6333 = load i32, ptr %slot1155, align 8
  %cv6334 = zext i32 %v6333 to i64
  %cond6335 = icmp ne i64 %cv6334, 0
  br i1 %cond6335, label %bb_rcgclear2268, label %bb_rcgcounted2268
bb_rcgcounted2268:
  %v6336 = load i64, ptr %slot1150, align 8
  %op6337 = sub i64 %v6336, 32
  store i64 %op6337, ptr %slot1156, align 8
  %v6338 = load i64, ptr %slot1150, align 8
  %p6339 = inttoptr i64 %v6338 to ptr
  %rgep6340 = getelementptr i8, ptr %p6339, i64 -32
  %ld6341 = load i64, ptr %rgep6340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6341, ptr %slot1157, align 8
  %v6342 = load i64, ptr %slot1157, align 8
  %op6343 = sub i64 %v6342, 1
  store i64 %op6343, ptr %slot1158, align 8
  %v6344 = load i64, ptr %slot1158, align 8
  %cmp6345 = icmp eq i64 %v6344, 0
  %cv6346 = zext i1 %cmp6345 to i32
  store i32 %cv6346, ptr %slot1159, align 8
  %v6347 = load i32, ptr %slot1159, align 8
  %cv6348 = zext i32 %v6347 to i64
  %cond6349 = icmp ne i64 %cv6348, 0
  br i1 %cond6349, label %bb_rcglast2268, label %bb_rcgdec2268
bb_rcglast2268:
  %v6350 = load i64, ptr %slot1150, align 8
  %op6351 = sub i64 %v6350, 24
  store i64 %op6351, ptr %slot1160, align 8
  %v6352 = load i64, ptr %slot1150, align 8
  %p6353 = inttoptr i64 %v6352 to ptr
  %rgep6354 = getelementptr i8, ptr %p6353, i64 -24
  %ld6355 = load i64, ptr %rgep6354, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6355, ptr %slot1161, align 8
  %v6356 = load i64, ptr %slot1161, align 8
  %cmp6357 = icmp ne i64 %v6356, 0
  %cv6358 = zext i1 %cmp6357 to i32
  store i32 %cv6358, ptr %slot1162, align 8
  %v6359 = load i32, ptr %slot1162, align 8
  %cv6360 = zext i32 %v6359 to i64
  %cond6361 = icmp ne i64 %cv6360, 0
  br i1 %cond6361, label %bb_rcgdec2268, label %bb_rcgslow2268
bb_rcgslow2268:
  %v6362 = load i64, ptr %slot1149, align 8
  %v6363 = load i64, ptr %slot1132, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6362, i64 %v6363) nomerge, !dbg !166
  br label %bb_rcgdone2268
bb_rcgdec2268:
  %v6364 = load i64, ptr %slot1158, align 8
  %v6365 = load i64, ptr %slot1150, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  %rgep6367 = getelementptr i8, ptr %p6366, i64 -32
  store i64 %v6364, ptr %rgep6367, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2268
bb_rcgclear2268:
  %v6368 = load i64, ptr %slot1132, align 8
  %p6369 = inttoptr i64 %v6368 to ptr
  store i64 0, ptr %p6369, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2268
bb_rcgdone2268:
  br label %bb_rcslotdone2237
bb_rcslotdone2237:
  %v6370 = load i64, ptr %slot7, align 8
  %p6371 = inttoptr i64 %v6370 to ptr
  %ld6372 = load i32, ptr %p6371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6372, ptr %slot1163, align 8
  %v6373 = load i32, ptr %slot1163, align 8
  %cv6374 = zext i32 %v6373 to i64
  %cond6375 = icmp ne i64 %cv6374, 0
  br i1 %cond6375, label %bb_rcslotdrop2274, label %bb_rcslotdone2274
bb_rcslotdrop2274:
  %v6376 = load i64, ptr %slot7, align 8
  %p6377 = inttoptr i64 %v6376 to ptr
  store i32 0, ptr %p6377, align 4, !alias.scope !3, !noalias !4
  %v6378 = load i64, ptr %slot12, align 8
  store i64 %v6378, ptr %slot1164, align 8
  %v6379 = load i64, ptr %slot8, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  %ld6381 = load i32, ptr %p6380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6381, ptr %slot1165, align 8
  %v6382 = load i32, ptr %slot1165, align 8
  %op6383 = and i32 %v6382, 28
  store i32 %op6383, ptr %slot1166, align 8
  %v6384 = load i32, ptr %slot1166, align 8
  %cv6385 = zext i32 %v6384 to i64
  %cond6386 = icmp ne i64 %cv6385, 0
  br i1 %cond6386, label %bb_rcslotrole2274, label %bb_rcslotowner2274
bb_rcslotrole2274:
  %v6387 = load i64, ptr %slot33, align 8
  store i64 %v6387, ptr %slot1167, align 8
  %v6388 = load i64, ptr %slot1164, align 8
  %p6389 = inttoptr i64 %v6388 to ptr
  %ld6390 = load i64, ptr %p6389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6390, ptr %slot1168, align 8
  %v6391 = load i64, ptr %slot1168, align 8
  %cmp6392 = icmp ne i64 %v6391, 0
  %cv6393 = zext i1 %cmp6392 to i32
  store i32 %cv6393, ptr %slot1169, align 8
  %v6394 = load i32, ptr %slot1169, align 8
  %cv6395 = zext i32 %v6394 to i64
  %cond6396 = icmp ne i64 %cv6395, 0
  br i1 %cond6396, label %bb_rcgnn2290, label %bb_rcgdone2290
bb_rcgnn2290:
  %v6397 = load i64, ptr %slot1168, align 8
  %op6398 = sub i64 %v6397, 16
  store i64 %op6398, ptr %slot1170, align 8
  %v6399 = load i64, ptr %slot1168, align 8
  %p6400 = inttoptr i64 %v6399 to ptr
  %rgep6401 = getelementptr i8, ptr %p6400, i64 -16
  %ld6402 = load i64, ptr %rgep6401, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6402, ptr %slot1171, align 8
  %v6403 = load i64, ptr %slot1171, align 8
  %op6404 = and i64 %v6403, 4611686018427387906
  store i64 %op6404, ptr %slot1172, align 8
  %v6405 = load i64, ptr %slot1172, align 8
  %cmp6406 = icmp ne i64 %v6405, 0
  %cv6407 = zext i1 %cmp6406 to i32
  store i32 %cv6407, ptr %slot1173, align 8
  %v6408 = load i32, ptr %slot1173, align 8
  %cv6409 = zext i32 %v6408 to i64
  %cond6410 = icmp ne i64 %cv6409, 0
  br i1 %cond6410, label %bb_rcgclear2290, label %bb_rcgcounted2290
bb_rcgcounted2290:
  %v6411 = load i64, ptr %slot1168, align 8
  %op6412 = sub i64 %v6411, 24
  store i64 %op6412, ptr %slot1174, align 8
  %v6413 = load i64, ptr %slot1168, align 8
  %p6414 = inttoptr i64 %v6413 to ptr
  %rgep6415 = getelementptr i8, ptr %p6414, i64 -24
  %ld6416 = load i64, ptr %rgep6415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6416, ptr %slot1175, align 8
  %v6417 = load i64, ptr %slot1175, align 8
  %op6418 = sub i64 %v6417, 1
  store i64 %op6418, ptr %slot1176, align 8
  %v6419 = load i64, ptr %slot1176, align 8
  %cmp6420 = icmp eq i64 %v6419, 0
  %cv6421 = zext i1 %cmp6420 to i32
  store i32 %cv6421, ptr %slot1177, align 8
  %v6422 = load i32, ptr %slot1177, align 8
  %cv6423 = zext i32 %v6422 to i64
  %cond6424 = icmp ne i64 %cv6423, 0
  br i1 %cond6424, label %bb_rcglast2290, label %bb_rcgdec2290
bb_rcglast2290:
  %v6425 = load i64, ptr %slot1168, align 8
  %op6426 = sub i64 %v6425, 32
  store i64 %op6426, ptr %slot1178, align 8
  %v6427 = load i64, ptr %slot1168, align 8
  %p6428 = inttoptr i64 %v6427 to ptr
  %rgep6429 = getelementptr i8, ptr %p6428, i64 -32
  %ld6430 = load i64, ptr %rgep6429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6430, ptr %slot1179, align 8
  %v6431 = load i64, ptr %slot1179, align 8
  %cmp6432 = icmp ne i64 %v6431, 0
  %cv6433 = zext i1 %cmp6432 to i32
  store i32 %cv6433, ptr %slot1180, align 8
  %v6434 = load i32, ptr %slot1180, align 8
  %cv6435 = zext i32 %v6434 to i64
  %cond6436 = icmp ne i64 %cv6435, 0
  br i1 %cond6436, label %bb_rcgdec2290, label %bb_rcgslow2290
bb_rcgslow2290:
  %v6437 = load i64, ptr %slot1167, align 8
  %v6438 = load i64, ptr %slot1164, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6437, i64 %v6438) nomerge, !dbg !166
  br label %bb_rcgdone2290
bb_rcgdec2290:
  %v6439 = load i64, ptr %slot1176, align 8
  %v6440 = load i64, ptr %slot1168, align 8
  %p6441 = inttoptr i64 %v6440 to ptr
  %rgep6442 = getelementptr i8, ptr %p6441, i64 -24
  store i64 %v6439, ptr %rgep6442, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2290
bb_rcgclear2290:
  %v6443 = load i64, ptr %slot1164, align 8
  %p6444 = inttoptr i64 %v6443 to ptr
  store i64 0, ptr %p6444, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2290
bb_rcgdone2290:
  br label %bb_rcslotdone2274
bb_rcslotowner2274:
  %v6445 = load i64, ptr %slot33, align 8
  store i64 %v6445, ptr %slot1181, align 8
  %v6446 = load i64, ptr %slot1164, align 8
  %p6447 = inttoptr i64 %v6446 to ptr
  %ld6448 = load i64, ptr %p6447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6448, ptr %slot1182, align 8
  %v6449 = load i64, ptr %slot1182, align 8
  %cmp6450 = icmp ne i64 %v6449, 0
  %cv6451 = zext i1 %cmp6450 to i32
  store i32 %cv6451, ptr %slot1183, align 8
  %v6452 = load i32, ptr %slot1183, align 8
  %cv6453 = zext i32 %v6452 to i64
  %cond6454 = icmp ne i64 %cv6453, 0
  br i1 %cond6454, label %bb_rcgnn2305, label %bb_rcgdone2305
bb_rcgnn2305:
  %v6455 = load i64, ptr %slot1182, align 8
  %op6456 = sub i64 %v6455, 16
  store i64 %op6456, ptr %slot1184, align 8
  %v6457 = load i64, ptr %slot1182, align 8
  %p6458 = inttoptr i64 %v6457 to ptr
  %rgep6459 = getelementptr i8, ptr %p6458, i64 -16
  %ld6460 = load i64, ptr %rgep6459, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6460, ptr %slot1185, align 8
  %v6461 = load i64, ptr %slot1185, align 8
  %op6462 = and i64 %v6461, 4611686018427387906
  store i64 %op6462, ptr %slot1186, align 8
  %v6463 = load i64, ptr %slot1186, align 8
  %cmp6464 = icmp ne i64 %v6463, 0
  %cv6465 = zext i1 %cmp6464 to i32
  store i32 %cv6465, ptr %slot1187, align 8
  %v6466 = load i32, ptr %slot1187, align 8
  %cv6467 = zext i32 %v6466 to i64
  %cond6468 = icmp ne i64 %cv6467, 0
  br i1 %cond6468, label %bb_rcgclear2305, label %bb_rcgcounted2305
bb_rcgcounted2305:
  %v6469 = load i64, ptr %slot1182, align 8
  %op6470 = sub i64 %v6469, 32
  store i64 %op6470, ptr %slot1188, align 8
  %v6471 = load i64, ptr %slot1182, align 8
  %p6472 = inttoptr i64 %v6471 to ptr
  %rgep6473 = getelementptr i8, ptr %p6472, i64 -32
  %ld6474 = load i64, ptr %rgep6473, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6474, ptr %slot1189, align 8
  %v6475 = load i64, ptr %slot1189, align 8
  %op6476 = sub i64 %v6475, 1
  store i64 %op6476, ptr %slot1190, align 8
  %v6477 = load i64, ptr %slot1190, align 8
  %cmp6478 = icmp eq i64 %v6477, 0
  %cv6479 = zext i1 %cmp6478 to i32
  store i32 %cv6479, ptr %slot1191, align 8
  %v6480 = load i32, ptr %slot1191, align 8
  %cv6481 = zext i32 %v6480 to i64
  %cond6482 = icmp ne i64 %cv6481, 0
  br i1 %cond6482, label %bb_rcglast2305, label %bb_rcgdec2305
bb_rcglast2305:
  %v6483 = load i64, ptr %slot1182, align 8
  %op6484 = sub i64 %v6483, 24
  store i64 %op6484, ptr %slot1192, align 8
  %v6485 = load i64, ptr %slot1182, align 8
  %p6486 = inttoptr i64 %v6485 to ptr
  %rgep6487 = getelementptr i8, ptr %p6486, i64 -24
  %ld6488 = load i64, ptr %rgep6487, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6488, ptr %slot1193, align 8
  %v6489 = load i64, ptr %slot1193, align 8
  %cmp6490 = icmp ne i64 %v6489, 0
  %cv6491 = zext i1 %cmp6490 to i32
  store i32 %cv6491, ptr %slot1194, align 8
  %v6492 = load i32, ptr %slot1194, align 8
  %cv6493 = zext i32 %v6492 to i64
  %cond6494 = icmp ne i64 %cv6493, 0
  br i1 %cond6494, label %bb_rcgdec2305, label %bb_rcgslow2305
bb_rcgslow2305:
  %v6495 = load i64, ptr %slot1181, align 8
  %v6496 = load i64, ptr %slot1164, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6495, i64 %v6496) nomerge, !dbg !166
  br label %bb_rcgdone2305
bb_rcgdec2305:
  %v6497 = load i64, ptr %slot1190, align 8
  %v6498 = load i64, ptr %slot1182, align 8
  %p6499 = inttoptr i64 %v6498 to ptr
  %rgep6500 = getelementptr i8, ptr %p6499, i64 -32
  store i64 %v6497, ptr %rgep6500, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2305
bb_rcgclear2305:
  %v6501 = load i64, ptr %slot1164, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  store i64 0, ptr %p6502, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2305
bb_rcgdone2305:
  br label %bb_rcslotdone2274
bb_rcslotdone2274:
  %v6503 = load i64, ptr %slot11, align 8
  store i64 %v6503, ptr %slot1195, align 8
  %v6504 = load i64, ptr %slot15, align 8
  store i64 %v6504, ptr %slot1196, align 8
  %v6505 = load i64, ptr %slot1196, align 8
  %v6506 = load i64, ptr %slot1195, align 8
  %p6507 = inttoptr i64 %v6505 to ptr
  %p6508 = inttoptr i64 %v6506 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6508, ptr %p6507, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6509 = load i64, ptr %slot6, align 8
  %p6510 = inttoptr i64 %v6509 to ptr
  store i32 2, ptr %p6510, align 4, !alias.scope !3, !noalias !4
  %v6511 = load i64, ptr %slot10, align 8
  %p6512 = inttoptr i64 %v6511 to ptr
  %ld6513 = load i32, ptr %p6512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6513, ptr %slot1197, align 8
  %v6514 = load i32, ptr %slot1197, align 8
  %v6515 = load i64, ptr %slot6, align 8
  %p6516 = inttoptr i64 %v6515 to ptr
  store i32 %v6514, ptr %p6516, align 4, !alias.scope !3, !noalias !4
  %v6517 = load i64, ptr %slot9, align 8
  %p6518 = inttoptr i64 %v6517 to ptr
  store i32 0, ptr %p6518, align 4, !alias.scope !3, !noalias !4
  %v6519 = load i64, ptr %slot5, align 8
  %p6520 = inttoptr i64 %v6519 to ptr
  store i32 1, ptr %p6520, align 4, !alias.scope !3, !noalias !4
  %v6521 = load i64, ptr %slot1195, align 8
  %p6522 = inttoptr i64 %v6521 to ptr
  %ld6523 = load i64, ptr %p6522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6523, ptr %slot1198, align 8
  %v6524 = load i64, ptr %slot1198, align 8
  %v6525 = load i64, ptr %slot26, align 8
  %p6526 = inttoptr i64 %v6525 to ptr
  store i64 %v6524, ptr %p6526, align 8, !alias.scope !3, !noalias !4
  %v6527 = load i64, ptr %slot26, align 8
  %p6528 = inttoptr i64 %v6527 to ptr
  %ld6529 = load i64, ptr %p6528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6529, ptr %slot1199, align 8
  %v6530 = load i64, ptr %slot26, align 8
  %p6531 = inttoptr i64 %v6530 to ptr
  %ld6532 = load i64, ptr %p6531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6532, ptr %slot1200, align 8
  %v6533 = load i64, ptr %slot1200, align 8
  %v6534 = load i64, ptr %slot13, align 8
  %p6535 = inttoptr i64 %v6534 to ptr
  store i64 %v6533, ptr %p6535, align 8, !alias.scope !3, !noalias !4
  %v6536 = load i64, ptr %slot13, align 8
  store i64 %v6536, ptr %slot1201, align 8
  %v6537 = load i64, ptr %slot5, align 8
  %p6538 = inttoptr i64 %v6537 to ptr
  %ld6539 = load i32, ptr %p6538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6539, ptr %slot1202, align 8
  %v6540 = load i64, ptr %slot6, align 8
  %p6541 = inttoptr i64 %v6540 to ptr
  %ld6542 = load i32, ptr %p6541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6542, ptr %slot1203, align 8
  %v6543 = load i32, ptr %slot1203, align 8
  %op6544 = and i32 %v6543, 24
  store i32 %op6544, ptr %slot1203, align 8
  %v6545 = load i32, ptr %slot1203, align 8
  %cmp6546 = icmp eq i32 %v6545, 0
  %cv6547 = zext i1 %cmp6546 to i32
  store i32 %cv6547, ptr %slot1204, align 8
  %v6548 = load i32, ptr %slot1202, align 8
  %v6549 = load i32, ptr %slot1204, align 8
  %op6550 = and i32 %v6548, %v6549
  store i32 %op6550, ptr %slot1205, align 8
  %v6551 = load i32, ptr %slot1205, align 8
  %cv6552 = zext i32 %v6551 to i64
  %cond6553 = icmp ne i64 %cv6552, 0
  br i1 %cond6553, label %bb_rctake2321, label %bb_rccopy2321
bb_rctake2321:
  %v6554 = load i64, ptr %slot15, align 8
  store i64 %v6554, ptr %slot1206, align 8
  %v6555 = load i64, ptr %slot34, align 8
  store i64 %v6555, ptr %slot1207, align 8
  %v6556 = load i64, ptr %slot1201, align 8
  %v6557 = load i64, ptr %slot1206, align 8
  %op6558 = sub i64 %v6556, %v6557
  store i64 %op6558, ptr %slot1208, align 8
  %v6559 = load i64, ptr %slot1206, align 8
  %v6560 = load i64, ptr %slot1201, align 8
  %op6561 = sub i64 %v6559, %v6560
  store i64 %op6561, ptr %slot1209, align 8
  %v6562 = load i64, ptr %slot1208, align 8
  %cmp6563 = icmp ult i64 %v6562, 8
  %cv6564 = zext i1 %cmp6563 to i32
  store i32 %cv6564, ptr %slot1210, align 8
  %v6565 = load i64, ptr %slot1209, align 8
  %cmp6566 = icmp ult i64 %v6565, 8
  %cv6567 = zext i1 %cmp6566 to i32
  store i32 %cv6567, ptr %slot1211, align 8
  %v6568 = load i32, ptr %slot1210, align 8
  %v6569 = load i32, ptr %slot1211, align 8
  %op6570 = or i32 %v6568, %v6569
  store i32 %op6570, ptr %slot1212, align 8
  %v6571 = load i32, ptr %slot1212, align 8
  %cv6572 = zext i32 %v6571 to i64
  %cond6573 = icmp ne i64 %cv6572, 0
  br i1 %cond6573, label %bb_rcmoveslow2330, label %bb_rcmovecheck2330
bb_rcmovecheck2330:
  %v6574 = load i64, ptr %slot1201, align 8
  %p6576 = inttoptr i64 %v6574 to ptr
  %gep6577 = getelementptr i8, ptr %p6576, i64 0
  %op6575 = ptrtoint ptr %gep6577 to i64
  store i64 %op6575, ptr %slot1213, align 8
  %v6578 = load i64, ptr %slot1213, align 8
  %p6579 = inttoptr i64 %v6578 to ptr
  %ld6580 = load i64, ptr %p6579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6580, ptr %slot1214, align 8
  %v6581 = load i64, ptr %slot1214, align 8
  %cmp6582 = icmp ne i64 %v6581, 0
  %cv6583 = zext i1 %cmp6582 to i32
  store i32 %cv6583, ptr %slot1215, align 8
  %v6584 = load i32, ptr %slot1215, align 8
  %cv6585 = zext i32 %v6584 to i64
  %cond6586 = icmp ne i64 %cv6585, 0
  br i1 %cond6586, label %bb_rcmoveheader2338, label %bb_rcmovenext2338
bb_rcmoveheader2338:
  %v6587 = load i64, ptr %slot1214, align 8
  %op6588 = sub i64 %v6587, 16
  store i64 %op6588, ptr %slot1216, align 8
  %v6589 = load i64, ptr %slot1214, align 8
  %p6590 = inttoptr i64 %v6589 to ptr
  %rgep6591 = getelementptr i8, ptr %p6590, i64 -16
  %ld6592 = load i64, ptr %rgep6591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6592, ptr %slot1217, align 8
  %v6593 = load i64, ptr %slot1217, align 8
  %op6594 = and i64 %v6593, 5764607523034234881
  store i64 %op6594, ptr %slot1218, align 8
  %v6595 = load i64, ptr %slot1218, align 8
  %cmp6596 = icmp ne i64 %v6595, 0
  %cv6597 = zext i1 %cmp6596 to i32
  store i32 %cv6597, ptr %slot1219, align 8
  %v6598 = load i32, ptr %slot1219, align 8
  %cv6599 = zext i32 %v6598 to i64
  %cond6600 = icmp ne i64 %cv6599, 0
  br i1 %cond6600, label %bb_rcmoveslow2330, label %bb_rcmovenext2338
bb_rcmovenext2338:
  %v6601 = load i64, ptr %slot1201, align 8
  %v6602 = load i64, ptr %slot1206, align 8
  %p6603 = inttoptr i64 %v6601 to ptr
  %p6604 = inttoptr i64 %v6602 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6604, ptr %p6603, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6605 = load i64, ptr %slot1201, align 8
  %p6606 = inttoptr i64 %v6605 to ptr
  store i64 0, ptr %p6606, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2330
bb_rcmoveslow2330:
  %v6607 = load i64, ptr %slot33, align 8
  %v6608 = load i64, ptr %slot1206, align 8
  %v6609 = load i64, ptr %slot1201, align 8
  %v6610 = load i64, ptr %slot1207, align 8
  %cv6611 = trunc i64 %v6610 to i32
  %call6612 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v6607, i64 %v6608, i64 %v6609, i32 %cv6611) nomerge, !dbg !168
  store i32 %call6612, ptr %slot1220, align 8
  %v6613 = load i32, ptr %slot1220, align 8
  %cv6614 = zext i32 %v6613 to i64
  %cond6615 = icmp ne i64 %cv6614, 0
  br i1 %cond6615, label %bb_rcsuccess2345, label %bb_rcfailure2345
bb_rcfailure2345:
  %v6616 = load i64, ptr %slot33, align 8
  %p6617 = inttoptr i64 %v6616 to ptr
  %call6618 = call i32 @myl_rc_take_failure(ptr %p6617) nomerge, !dbg !168
  store i32 %call6618, ptr %slot1221, align 8
  %v6619 = load i64, ptr %slot1, align 8
  %p6620 = inttoptr i64 %v6619 to ptr
  %v6621 = load i32, ptr %slot1221, align 8
  %call6622 = call i32 @myl_qbe_rc_status(ptr %p6620, i32 %v6621) nomerge, !dbg !168
  store i32 %call6622, ptr %slot1222, align 8
  br label %bb_failure
bb_rcsuccess2345:
  br label %bb_rcmoved2330
bb_rcmoved2330:
  %v6623 = load i64, ptr %slot5, align 8
  %p6624 = inttoptr i64 %v6623 to ptr
  store i32 0, ptr %p6624, align 4, !alias.scope !3, !noalias !4
  %v6625 = load i64, ptr %slot10, align 8
  %p6626 = inttoptr i64 %v6625 to ptr
  store i32 2, ptr %p6626, align 4, !alias.scope !3, !noalias !4
  %v6627 = load i64, ptr %slot9, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  store i32 1, ptr %p6628, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2321
bb_rccopy2321:
  %v6629 = load i64, ptr %slot15, align 8
  store i64 %v6629, ptr %slot1223, align 8
  %v6630 = load i64, ptr %slot34, align 8
  store i64 %v6630, ptr %slot1224, align 8
  %v6631 = load i64, ptr %slot1201, align 8
  %p6632 = inttoptr i64 %v6631 to ptr
  %ld6633 = load i64, ptr %p6632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6633, ptr %slot1225, align 8
  %v6634 = load i64, ptr %slot1225, align 8
  %cmp6635 = icmp ne i64 %v6634, 0
  %cv6636 = zext i1 %cmp6635 to i32
  store i32 %cv6636, ptr %slot1226, align 8
  %v6637 = load i32, ptr %slot1226, align 8
  %cv6638 = zext i32 %v6637 to i64
  %cond6639 = icmp ne i64 %cv6638, 0
  br i1 %cond6639, label %bb_rcgnn2354, label %bb_rcgplain2354
bb_rcgnn2354:
  %v6640 = load i64, ptr %slot1225, align 8
  %op6641 = sub i64 %v6640, 16
  store i64 %op6641, ptr %slot1227, align 8
  %v6642 = load i64, ptr %slot1225, align 8
  %p6643 = inttoptr i64 %v6642 to ptr
  %rgep6644 = getelementptr i8, ptr %p6643, i64 -16
  %ld6645 = load i64, ptr %rgep6644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6645, ptr %slot1228, align 8
  %v6646 = load i64, ptr %slot1228, align 8
  %op6647 = and i64 %v6646, 4611686018427387906
  store i64 %op6647, ptr %slot1229, align 8
  %v6648 = load i64, ptr %slot1229, align 8
  %cmp6649 = icmp ne i64 %v6648, 0
  %cv6650 = zext i1 %cmp6649 to i32
  store i32 %cv6650, ptr %slot1230, align 8
  %v6651 = load i32, ptr %slot1230, align 8
  %cv6652 = zext i32 %v6651 to i64
  %cond6653 = icmp ne i64 %cv6652, 0
  br i1 %cond6653, label %bb_rcgspecial2354, label %bb_rcginc2354
bb_rcginc2354:
  %v6654 = load i64, ptr %slot1225, align 8
  %op6655 = sub i64 %v6654, 32
  store i64 %op6655, ptr %slot1231, align 8
  %v6656 = load i64, ptr %slot1225, align 8
  %p6657 = inttoptr i64 %v6656 to ptr
  %rgep6658 = getelementptr i8, ptr %p6657, i64 -32
  %ld6659 = load i64, ptr %rgep6658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6659, ptr %slot1232, align 8
  %v6660 = load i64, ptr %slot1232, align 8
  %op6661 = add i64 %v6660, 1
  store i64 %op6661, ptr %slot1233, align 8
  %v6662 = load i64, ptr %slot1233, align 8
  %cmp6663 = icmp eq i64 %v6662, 0
  %cv6664 = zext i1 %cmp6663 to i32
  store i32 %cv6664, ptr %slot1234, align 8
  %v6665 = load i32, ptr %slot1234, align 8
  %cv6666 = zext i32 %v6665 to i64
  %cond6667 = icmp ne i64 %cv6666, 0
  br i1 %cond6667, label %bb_rcglimit2354, label %bb_rcgcapacity2354
bb_rcglimit2354:
  %v6668 = load i64, ptr %slot1, align 8
  %p6669 = inttoptr i64 %v6668 to ptr
  %call6670 = call i32 @myl_qbe_rc_status(ptr %p6669, i32 2) nomerge, !dbg !168
  store i32 %call6670, ptr %slot1235, align 8
  br label %bb_failure
bb_rcgcapacity2354:
  %v6671 = load i64, ptr %slot1233, align 8
  %v6672 = load i64, ptr %slot1225, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  %rgep6674 = getelementptr i8, ptr %p6673, i64 -32
  store i64 %v6671, ptr %rgep6674, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2354
bb_rcgspecial2354:
  %v6675 = load i64, ptr %slot1228, align 8
  %op6676 = and i64 %v6675, 4611686018427387904
  store i64 %op6676, ptr %slot1236, align 8
  %v6677 = load i64, ptr %slot1236, align 8
  %cmp6678 = icmp ne i64 %v6677, 0
  %cv6679 = zext i1 %cmp6678 to i32
  store i32 %cv6679, ptr %slot1237, align 8
  %v6680 = load i32, ptr %slot1237, align 8
  %cv6681 = zext i32 %v6680 to i64
  %cond6682 = icmp ne i64 %cv6681, 0
  br i1 %cond6682, label %bb_rcgslow2354, label %bb_rcgplain2354
bb_rcgslow2354:
  %v6683 = load i64, ptr %slot33, align 8
  %v6684 = load i64, ptr %slot1223, align 8
  %v6685 = load i64, ptr %slot1201, align 8
  %v6686 = load i64, ptr %slot1224, align 8
  %cv6687 = trunc i64 %v6686 to i32
  %call6688 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v6683, i64 %v6684, i64 %v6685, i32 %cv6687) nomerge, !dbg !168
  store i32 %call6688, ptr %slot1238, align 8
  %v6689 = load i32, ptr %slot1238, align 8
  %cv6690 = zext i32 %v6689 to i64
  %cond6691 = icmp ne i64 %cv6690, 0
  br i1 %cond6691, label %bb_rcsuccess2368, label %bb_rcfailure2368
bb_rcfailure2368:
  %v6692 = load i64, ptr %slot33, align 8
  %p6693 = inttoptr i64 %v6692 to ptr
  %call6694 = call i32 @myl_rc_take_failure(ptr %p6693) nomerge, !dbg !168
  store i32 %call6694, ptr %slot1239, align 8
  %v6695 = load i64, ptr %slot1, align 8
  %p6696 = inttoptr i64 %v6695 to ptr
  %v6697 = load i32, ptr %slot1239, align 8
  %call6698 = call i32 @myl_qbe_rc_status(ptr %p6696, i32 %v6697) nomerge, !dbg !168
  store i32 %call6698, ptr %slot1240, align 8
  br label %bb_failure
bb_rcsuccess2368:
  br label %bb_rcgdone2354
bb_rcgplain2354:
  %v6699 = load i64, ptr %slot1225, align 8
  %v6700 = load i64, ptr %slot1223, align 8
  %p6701 = inttoptr i64 %v6700 to ptr
  store i64 %v6699, ptr %p6701, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2354
bb_rcgdone2354:
  %v6702 = load i64, ptr %slot10, align 8
  %p6703 = inttoptr i64 %v6702 to ptr
  store i32 2, ptr %p6703, align 4, !alias.scope !3, !noalias !4
  %v6704 = load i64, ptr %slot9, align 8
  %p6705 = inttoptr i64 %v6704 to ptr
  store i32 1, ptr %p6705, align 4, !alias.scope !3, !noalias !4
  %v6706 = load i64, ptr %slot5, align 8
  %p6707 = inttoptr i64 %v6706 to ptr
  %ld6708 = load i32, ptr %p6707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6708, ptr %slot1241, align 8
  %v6709 = load i32, ptr %slot1241, align 8
  %cv6710 = zext i32 %v6709 to i64
  %cond6711 = icmp ne i64 %cv6710, 0
  br i1 %cond6711, label %bb_rcslotdrop2375, label %bb_rcslotdone2375
bb_rcslotdrop2375:
  %v6712 = load i64, ptr %slot5, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  store i32 0, ptr %p6713, align 4, !alias.scope !3, !noalias !4
  %v6714 = load i64, ptr %slot11, align 8
  store i64 %v6714, ptr %slot1242, align 8
  %v6715 = load i64, ptr %slot6, align 8
  %p6716 = inttoptr i64 %v6715 to ptr
  %ld6717 = load i32, ptr %p6716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6717, ptr %slot1243, align 8
  %v6718 = load i32, ptr %slot1243, align 8
  %op6719 = and i32 %v6718, 28
  store i32 %op6719, ptr %slot1244, align 8
  %v6720 = load i32, ptr %slot1244, align 8
  %cv6721 = zext i32 %v6720 to i64
  %cond6722 = icmp ne i64 %cv6721, 0
  br i1 %cond6722, label %bb_rcslotrole2375, label %bb_rcslotowner2375
bb_rcslotrole2375:
  %v6723 = load i64, ptr %slot33, align 8
  store i64 %v6723, ptr %slot1245, align 8
  %v6724 = load i64, ptr %slot1242, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  %ld6726 = load i64, ptr %p6725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6726, ptr %slot1246, align 8
  %v6727 = load i64, ptr %slot1246, align 8
  %cmp6728 = icmp ne i64 %v6727, 0
  %cv6729 = zext i1 %cmp6728 to i32
  store i32 %cv6729, ptr %slot1247, align 8
  %v6730 = load i32, ptr %slot1247, align 8
  %cv6731 = zext i32 %v6730 to i64
  %cond6732 = icmp ne i64 %cv6731, 0
  br i1 %cond6732, label %bb_rcgnn2391, label %bb_rcgdone2391
bb_rcgnn2391:
  %v6733 = load i64, ptr %slot1246, align 8
  %op6734 = sub i64 %v6733, 16
  store i64 %op6734, ptr %slot1248, align 8
  %v6735 = load i64, ptr %slot1246, align 8
  %p6736 = inttoptr i64 %v6735 to ptr
  %rgep6737 = getelementptr i8, ptr %p6736, i64 -16
  %ld6738 = load i64, ptr %rgep6737, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6738, ptr %slot1249, align 8
  %v6739 = load i64, ptr %slot1249, align 8
  %op6740 = and i64 %v6739, 4611686018427387906
  store i64 %op6740, ptr %slot1250, align 8
  %v6741 = load i64, ptr %slot1250, align 8
  %cmp6742 = icmp ne i64 %v6741, 0
  %cv6743 = zext i1 %cmp6742 to i32
  store i32 %cv6743, ptr %slot1251, align 8
  %v6744 = load i32, ptr %slot1251, align 8
  %cv6745 = zext i32 %v6744 to i64
  %cond6746 = icmp ne i64 %cv6745, 0
  br i1 %cond6746, label %bb_rcgclear2391, label %bb_rcgcounted2391
bb_rcgcounted2391:
  %v6747 = load i64, ptr %slot1246, align 8
  %op6748 = sub i64 %v6747, 24
  store i64 %op6748, ptr %slot1252, align 8
  %v6749 = load i64, ptr %slot1246, align 8
  %p6750 = inttoptr i64 %v6749 to ptr
  %rgep6751 = getelementptr i8, ptr %p6750, i64 -24
  %ld6752 = load i64, ptr %rgep6751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6752, ptr %slot1253, align 8
  %v6753 = load i64, ptr %slot1253, align 8
  %op6754 = sub i64 %v6753, 1
  store i64 %op6754, ptr %slot1254, align 8
  %v6755 = load i64, ptr %slot1254, align 8
  %cmp6756 = icmp eq i64 %v6755, 0
  %cv6757 = zext i1 %cmp6756 to i32
  store i32 %cv6757, ptr %slot1255, align 8
  %v6758 = load i32, ptr %slot1255, align 8
  %cv6759 = zext i32 %v6758 to i64
  %cond6760 = icmp ne i64 %cv6759, 0
  br i1 %cond6760, label %bb_rcglast2391, label %bb_rcgdec2391
bb_rcglast2391:
  %v6761 = load i64, ptr %slot1246, align 8
  %op6762 = sub i64 %v6761, 32
  store i64 %op6762, ptr %slot1256, align 8
  %v6763 = load i64, ptr %slot1246, align 8
  %p6764 = inttoptr i64 %v6763 to ptr
  %rgep6765 = getelementptr i8, ptr %p6764, i64 -32
  %ld6766 = load i64, ptr %rgep6765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6766, ptr %slot1257, align 8
  %v6767 = load i64, ptr %slot1257, align 8
  %cmp6768 = icmp ne i64 %v6767, 0
  %cv6769 = zext i1 %cmp6768 to i32
  store i32 %cv6769, ptr %slot1258, align 8
  %v6770 = load i32, ptr %slot1258, align 8
  %cv6771 = zext i32 %v6770 to i64
  %cond6772 = icmp ne i64 %cv6771, 0
  br i1 %cond6772, label %bb_rcgdec2391, label %bb_rcgslow2391
bb_rcgslow2391:
  %v6773 = load i64, ptr %slot1245, align 8
  %v6774 = load i64, ptr %slot1242, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6773, i64 %v6774) nomerge, !dbg !168
  br label %bb_rcgdone2391
bb_rcgdec2391:
  %v6775 = load i64, ptr %slot1254, align 8
  %v6776 = load i64, ptr %slot1246, align 8
  %p6777 = inttoptr i64 %v6776 to ptr
  %rgep6778 = getelementptr i8, ptr %p6777, i64 -24
  store i64 %v6775, ptr %rgep6778, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2391
bb_rcgclear2391:
  %v6779 = load i64, ptr %slot1242, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  store i64 0, ptr %p6780, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2391
bb_rcgdone2391:
  br label %bb_rcslotdone2375
bb_rcslotowner2375:
  %v6781 = load i64, ptr %slot33, align 8
  store i64 %v6781, ptr %slot1259, align 8
  %v6782 = load i64, ptr %slot1242, align 8
  %p6783 = inttoptr i64 %v6782 to ptr
  %ld6784 = load i64, ptr %p6783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6784, ptr %slot1260, align 8
  %v6785 = load i64, ptr %slot1260, align 8
  %cmp6786 = icmp ne i64 %v6785, 0
  %cv6787 = zext i1 %cmp6786 to i32
  store i32 %cv6787, ptr %slot1261, align 8
  %v6788 = load i32, ptr %slot1261, align 8
  %cv6789 = zext i32 %v6788 to i64
  %cond6790 = icmp ne i64 %cv6789, 0
  br i1 %cond6790, label %bb_rcgnn2406, label %bb_rcgdone2406
bb_rcgnn2406:
  %v6791 = load i64, ptr %slot1260, align 8
  %op6792 = sub i64 %v6791, 16
  store i64 %op6792, ptr %slot1262, align 8
  %v6793 = load i64, ptr %slot1260, align 8
  %p6794 = inttoptr i64 %v6793 to ptr
  %rgep6795 = getelementptr i8, ptr %p6794, i64 -16
  %ld6796 = load i64, ptr %rgep6795, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6796, ptr %slot1263, align 8
  %v6797 = load i64, ptr %slot1263, align 8
  %op6798 = and i64 %v6797, 4611686018427387906
  store i64 %op6798, ptr %slot1264, align 8
  %v6799 = load i64, ptr %slot1264, align 8
  %cmp6800 = icmp ne i64 %v6799, 0
  %cv6801 = zext i1 %cmp6800 to i32
  store i32 %cv6801, ptr %slot1265, align 8
  %v6802 = load i32, ptr %slot1265, align 8
  %cv6803 = zext i32 %v6802 to i64
  %cond6804 = icmp ne i64 %cv6803, 0
  br i1 %cond6804, label %bb_rcgclear2406, label %bb_rcgcounted2406
bb_rcgcounted2406:
  %v6805 = load i64, ptr %slot1260, align 8
  %op6806 = sub i64 %v6805, 32
  store i64 %op6806, ptr %slot1266, align 8
  %v6807 = load i64, ptr %slot1260, align 8
  %p6808 = inttoptr i64 %v6807 to ptr
  %rgep6809 = getelementptr i8, ptr %p6808, i64 -32
  %ld6810 = load i64, ptr %rgep6809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6810, ptr %slot1267, align 8
  %v6811 = load i64, ptr %slot1267, align 8
  %op6812 = sub i64 %v6811, 1
  store i64 %op6812, ptr %slot1268, align 8
  %v6813 = load i64, ptr %slot1268, align 8
  %cmp6814 = icmp eq i64 %v6813, 0
  %cv6815 = zext i1 %cmp6814 to i32
  store i32 %cv6815, ptr %slot1269, align 8
  %v6816 = load i32, ptr %slot1269, align 8
  %cv6817 = zext i32 %v6816 to i64
  %cond6818 = icmp ne i64 %cv6817, 0
  br i1 %cond6818, label %bb_rcglast2406, label %bb_rcgdec2406
bb_rcglast2406:
  %v6819 = load i64, ptr %slot1260, align 8
  %op6820 = sub i64 %v6819, 24
  store i64 %op6820, ptr %slot1270, align 8
  %v6821 = load i64, ptr %slot1260, align 8
  %p6822 = inttoptr i64 %v6821 to ptr
  %rgep6823 = getelementptr i8, ptr %p6822, i64 -24
  %ld6824 = load i64, ptr %rgep6823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6824, ptr %slot1271, align 8
  %v6825 = load i64, ptr %slot1271, align 8
  %cmp6826 = icmp ne i64 %v6825, 0
  %cv6827 = zext i1 %cmp6826 to i32
  store i32 %cv6827, ptr %slot1272, align 8
  %v6828 = load i32, ptr %slot1272, align 8
  %cv6829 = zext i32 %v6828 to i64
  %cond6830 = icmp ne i64 %cv6829, 0
  br i1 %cond6830, label %bb_rcgdec2406, label %bb_rcgslow2406
bb_rcgslow2406:
  %v6831 = load i64, ptr %slot1259, align 8
  %v6832 = load i64, ptr %slot1242, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6831, i64 %v6832) nomerge, !dbg !168
  br label %bb_rcgdone2406
bb_rcgdec2406:
  %v6833 = load i64, ptr %slot1268, align 8
  %v6834 = load i64, ptr %slot1260, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  %rgep6836 = getelementptr i8, ptr %p6835, i64 -32
  store i64 %v6833, ptr %rgep6836, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2406
bb_rcgclear2406:
  %v6837 = load i64, ptr %slot1242, align 8
  %p6838 = inttoptr i64 %v6837 to ptr
  store i64 0, ptr %p6838, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2406
bb_rcgdone2406:
  br label %bb_rcslotdone2375
bb_rcslotdone2375:
  br label %bb_rcprepared2321
bb_rcprepared2321:
  %v6839 = load i64, ptr %slot15, align 8
  store i64 %v6839, ptr %slot1273, align 8
  %v6840 = load i64, ptr %slot1273, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  %ld6842 = load i64, ptr %p6841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6842, ptr %slot1274, align 8
  %v6843 = load i64, ptr %slot9, align 8
  %p6844 = inttoptr i64 %v6843 to ptr
  store i32 0, ptr %p6844, align 4, !alias.scope !3, !noalias !4
  %v6845 = load i64, ptr %slot5, align 8
  %p6846 = inttoptr i64 %v6845 to ptr
  %ld6847 = load i32, ptr %p6846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6847, ptr %slot1275, align 8
  %v6848 = load i32, ptr %slot1275, align 8
  %cv6849 = zext i32 %v6848 to i64
  %cond6850 = icmp ne i64 %cv6849, 0
  br i1 %cond6850, label %bb_rcslotdrop2415, label %bb_rcslotdone2415
bb_rcslotdrop2415:
  %v6851 = load i64, ptr %slot5, align 8
  %p6852 = inttoptr i64 %v6851 to ptr
  store i32 0, ptr %p6852, align 4, !alias.scope !3, !noalias !4
  %v6853 = load i64, ptr %slot11, align 8
  store i64 %v6853, ptr %slot1276, align 8
  %v6854 = load i64, ptr %slot6, align 8
  %p6855 = inttoptr i64 %v6854 to ptr
  %ld6856 = load i32, ptr %p6855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6856, ptr %slot1277, align 8
  %v6857 = load i32, ptr %slot1277, align 8
  %op6858 = and i32 %v6857, 28
  store i32 %op6858, ptr %slot1278, align 8
  %v6859 = load i32, ptr %slot1278, align 8
  %cv6860 = zext i32 %v6859 to i64
  %cond6861 = icmp ne i64 %cv6860, 0
  br i1 %cond6861, label %bb_rcslotrole2415, label %bb_rcslotowner2415
bb_rcslotrole2415:
  %v6862 = load i64, ptr %slot33, align 8
  store i64 %v6862, ptr %slot1279, align 8
  %v6863 = load i64, ptr %slot1276, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  %ld6865 = load i64, ptr %p6864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6865, ptr %slot1280, align 8
  %v6866 = load i64, ptr %slot1280, align 8
  %cmp6867 = icmp ne i64 %v6866, 0
  %cv6868 = zext i1 %cmp6867 to i32
  store i32 %cv6868, ptr %slot1281, align 8
  %v6869 = load i32, ptr %slot1281, align 8
  %cv6870 = zext i32 %v6869 to i64
  %cond6871 = icmp ne i64 %cv6870, 0
  br i1 %cond6871, label %bb_rcgnn2431, label %bb_rcgdone2431
bb_rcgnn2431:
  %v6872 = load i64, ptr %slot1280, align 8
  %op6873 = sub i64 %v6872, 16
  store i64 %op6873, ptr %slot1282, align 8
  %v6874 = load i64, ptr %slot1280, align 8
  %p6875 = inttoptr i64 %v6874 to ptr
  %rgep6876 = getelementptr i8, ptr %p6875, i64 -16
  %ld6877 = load i64, ptr %rgep6876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6877, ptr %slot1283, align 8
  %v6878 = load i64, ptr %slot1283, align 8
  %op6879 = and i64 %v6878, 4611686018427387906
  store i64 %op6879, ptr %slot1284, align 8
  %v6880 = load i64, ptr %slot1284, align 8
  %cmp6881 = icmp ne i64 %v6880, 0
  %cv6882 = zext i1 %cmp6881 to i32
  store i32 %cv6882, ptr %slot1285, align 8
  %v6883 = load i32, ptr %slot1285, align 8
  %cv6884 = zext i32 %v6883 to i64
  %cond6885 = icmp ne i64 %cv6884, 0
  br i1 %cond6885, label %bb_rcgclear2431, label %bb_rcgcounted2431
bb_rcgcounted2431:
  %v6886 = load i64, ptr %slot1280, align 8
  %op6887 = sub i64 %v6886, 24
  store i64 %op6887, ptr %slot1286, align 8
  %v6888 = load i64, ptr %slot1280, align 8
  %p6889 = inttoptr i64 %v6888 to ptr
  %rgep6890 = getelementptr i8, ptr %p6889, i64 -24
  %ld6891 = load i64, ptr %rgep6890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6891, ptr %slot1287, align 8
  %v6892 = load i64, ptr %slot1287, align 8
  %op6893 = sub i64 %v6892, 1
  store i64 %op6893, ptr %slot1288, align 8
  %v6894 = load i64, ptr %slot1288, align 8
  %cmp6895 = icmp eq i64 %v6894, 0
  %cv6896 = zext i1 %cmp6895 to i32
  store i32 %cv6896, ptr %slot1289, align 8
  %v6897 = load i32, ptr %slot1289, align 8
  %cv6898 = zext i32 %v6897 to i64
  %cond6899 = icmp ne i64 %cv6898, 0
  br i1 %cond6899, label %bb_rcglast2431, label %bb_rcgdec2431
bb_rcglast2431:
  %v6900 = load i64, ptr %slot1280, align 8
  %op6901 = sub i64 %v6900, 32
  store i64 %op6901, ptr %slot1290, align 8
  %v6902 = load i64, ptr %slot1280, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  %rgep6904 = getelementptr i8, ptr %p6903, i64 -32
  %ld6905 = load i64, ptr %rgep6904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6905, ptr %slot1291, align 8
  %v6906 = load i64, ptr %slot1291, align 8
  %cmp6907 = icmp ne i64 %v6906, 0
  %cv6908 = zext i1 %cmp6907 to i32
  store i32 %cv6908, ptr %slot1292, align 8
  %v6909 = load i32, ptr %slot1292, align 8
  %cv6910 = zext i32 %v6909 to i64
  %cond6911 = icmp ne i64 %cv6910, 0
  br i1 %cond6911, label %bb_rcgdec2431, label %bb_rcgslow2431
bb_rcgslow2431:
  %v6912 = load i64, ptr %slot1279, align 8
  %v6913 = load i64, ptr %slot1276, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6912, i64 %v6913) nomerge, !dbg !168
  br label %bb_rcgdone2431
bb_rcgdec2431:
  %v6914 = load i64, ptr %slot1288, align 8
  %v6915 = load i64, ptr %slot1280, align 8
  %p6916 = inttoptr i64 %v6915 to ptr
  %rgep6917 = getelementptr i8, ptr %p6916, i64 -24
  store i64 %v6914, ptr %rgep6917, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2431
bb_rcgclear2431:
  %v6918 = load i64, ptr %slot1276, align 8
  %p6919 = inttoptr i64 %v6918 to ptr
  store i64 0, ptr %p6919, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2431
bb_rcgdone2431:
  br label %bb_rcslotdone2415
bb_rcslotowner2415:
  %v6920 = load i64, ptr %slot33, align 8
  store i64 %v6920, ptr %slot1293, align 8
  %v6921 = load i64, ptr %slot1276, align 8
  %p6922 = inttoptr i64 %v6921 to ptr
  %ld6923 = load i64, ptr %p6922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6923, ptr %slot1294, align 8
  %v6924 = load i64, ptr %slot1294, align 8
  %cmp6925 = icmp ne i64 %v6924, 0
  %cv6926 = zext i1 %cmp6925 to i32
  store i32 %cv6926, ptr %slot1295, align 8
  %v6927 = load i32, ptr %slot1295, align 8
  %cv6928 = zext i32 %v6927 to i64
  %cond6929 = icmp ne i64 %cv6928, 0
  br i1 %cond6929, label %bb_rcgnn2446, label %bb_rcgdone2446
bb_rcgnn2446:
  %v6930 = load i64, ptr %slot1294, align 8
  %op6931 = sub i64 %v6930, 16
  store i64 %op6931, ptr %slot1296, align 8
  %v6932 = load i64, ptr %slot1294, align 8
  %p6933 = inttoptr i64 %v6932 to ptr
  %rgep6934 = getelementptr i8, ptr %p6933, i64 -16
  %ld6935 = load i64, ptr %rgep6934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6935, ptr %slot1297, align 8
  %v6936 = load i64, ptr %slot1297, align 8
  %op6937 = and i64 %v6936, 4611686018427387906
  store i64 %op6937, ptr %slot1298, align 8
  %v6938 = load i64, ptr %slot1298, align 8
  %cmp6939 = icmp ne i64 %v6938, 0
  %cv6940 = zext i1 %cmp6939 to i32
  store i32 %cv6940, ptr %slot1299, align 8
  %v6941 = load i32, ptr %slot1299, align 8
  %cv6942 = zext i32 %v6941 to i64
  %cond6943 = icmp ne i64 %cv6942, 0
  br i1 %cond6943, label %bb_rcgclear2446, label %bb_rcgcounted2446
bb_rcgcounted2446:
  %v6944 = load i64, ptr %slot1294, align 8
  %op6945 = sub i64 %v6944, 32
  store i64 %op6945, ptr %slot1300, align 8
  %v6946 = load i64, ptr %slot1294, align 8
  %p6947 = inttoptr i64 %v6946 to ptr
  %rgep6948 = getelementptr i8, ptr %p6947, i64 -32
  %ld6949 = load i64, ptr %rgep6948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6949, ptr %slot1301, align 8
  %v6950 = load i64, ptr %slot1301, align 8
  %op6951 = sub i64 %v6950, 1
  store i64 %op6951, ptr %slot1302, align 8
  %v6952 = load i64, ptr %slot1302, align 8
  %cmp6953 = icmp eq i64 %v6952, 0
  %cv6954 = zext i1 %cmp6953 to i32
  store i32 %cv6954, ptr %slot1303, align 8
  %v6955 = load i32, ptr %slot1303, align 8
  %cv6956 = zext i32 %v6955 to i64
  %cond6957 = icmp ne i64 %cv6956, 0
  br i1 %cond6957, label %bb_rcglast2446, label %bb_rcgdec2446
bb_rcglast2446:
  %v6958 = load i64, ptr %slot1294, align 8
  %op6959 = sub i64 %v6958, 24
  store i64 %op6959, ptr %slot1304, align 8
  %v6960 = load i64, ptr %slot1294, align 8
  %p6961 = inttoptr i64 %v6960 to ptr
  %rgep6962 = getelementptr i8, ptr %p6961, i64 -24
  %ld6963 = load i64, ptr %rgep6962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6963, ptr %slot1305, align 8
  %v6964 = load i64, ptr %slot1305, align 8
  %cmp6965 = icmp ne i64 %v6964, 0
  %cv6966 = zext i1 %cmp6965 to i32
  store i32 %cv6966, ptr %slot1306, align 8
  %v6967 = load i32, ptr %slot1306, align 8
  %cv6968 = zext i32 %v6967 to i64
  %cond6969 = icmp ne i64 %cv6968, 0
  br i1 %cond6969, label %bb_rcgdec2446, label %bb_rcgslow2446
bb_rcgslow2446:
  %v6970 = load i64, ptr %slot1293, align 8
  %v6971 = load i64, ptr %slot1276, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6970, i64 %v6971) nomerge, !dbg !168
  br label %bb_rcgdone2446
bb_rcgdec2446:
  %v6972 = load i64, ptr %slot1302, align 8
  %v6973 = load i64, ptr %slot1294, align 8
  %p6974 = inttoptr i64 %v6973 to ptr
  %rgep6975 = getelementptr i8, ptr %p6974, i64 -32
  store i64 %v6972, ptr %rgep6975, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2446
bb_rcgclear2446:
  %v6976 = load i64, ptr %slot1276, align 8
  %p6977 = inttoptr i64 %v6976 to ptr
  store i64 0, ptr %p6977, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2446
bb_rcgdone2446:
  br label %bb_rcslotdone2415
bb_rcslotdone2415:
  %v6978 = load i64, ptr %slot1274, align 8
  ret i64 %v6978
bb_i72:
  %v6979 = load i64, ptr %slot26, align 8
  %p6980 = inttoptr i64 %v6979 to ptr
  store i64 0, ptr %p6980, align 8, !alias.scope !3, !noalias !4
  %v6981 = load i64, ptr %slot26, align 8
  %p6982 = inttoptr i64 %v6981 to ptr
  %ld6983 = load i64, ptr %p6982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6983, ptr %slot1307, align 8
  %v6984 = load i64, ptr %slot1307, align 8
  %cond6985 = icmp ne i64 %v6984, 0
  br i1 %cond6985, label %bb_success2533, label %bb_failed2533
bb_failed2533:
  %v6986 = load i64, ptr %slot1, align 8
  %p6987 = inttoptr i64 %v6986 to ptr
  call void @myl_qbe_fail_assert(ptr %p6987) nomerge, !dbg !170
  unreachable
bb_success2533:
  %p6988 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld6989 = load i64, ptr %p6988, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6989, ptr %slot1308, align 8
  %v6990 = load i64, ptr %slot1308, align 8
  %v6991 = load i64, ptr %slot26, align 8
  %p6992 = inttoptr i64 %v6991 to ptr
  store i64 %v6990, ptr %p6992, align 8, !alias.scope !3, !noalias !4
  %v6993 = load i64, ptr %slot26, align 8
  %p6994 = inttoptr i64 %v6993 to ptr
  %ld6995 = load i64, ptr %p6994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6995, ptr %slot1309, align 8
  %v6996 = load i64, ptr %slot1309, align 8
  %v6997 = load i64, ptr %slot13, align 8
  %p6998 = inttoptr i64 %v6997 to ptr
  store i64 %v6996, ptr %p6998, align 8, !alias.scope !3, !noalias !4
  %v6999 = load i64, ptr %slot13, align 8
  store i64 %v6999, ptr %slot1310, align 8
  %v7000 = load i64, ptr %slot15, align 8
  store i64 %v7000, ptr %slot1311, align 8
  %v7001 = load i64, ptr %slot1310, align 8
  %v7002 = load i64, ptr %slot1311, align 8
  %p7003 = inttoptr i64 %v7001 to ptr
  %p7004 = inttoptr i64 %v7002 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7004, ptr %p7003, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7005 = load i64, ptr %slot10, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  store i32 2, ptr %p7006, align 4, !alias.scope !3, !noalias !4
  %v7007 = load i64, ptr %slot9, align 8
  %p7008 = inttoptr i64 %v7007 to ptr
  store i32 1, ptr %p7008, align 4, !alias.scope !3, !noalias !4
  %v7009 = load i64, ptr %slot11, align 8
  store i64 %v7009, ptr %slot1312, align 8
  %v7010 = load i64, ptr %slot15, align 8
  store i64 %v7010, ptr %slot1313, align 8
  %v7011 = load i64, ptr %slot1313, align 8
  %v7012 = load i64, ptr %slot1312, align 8
  %p7013 = inttoptr i64 %v7011 to ptr
  %p7014 = inttoptr i64 %v7012 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7014, ptr %p7013, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7015 = load i64, ptr %slot6, align 8
  %p7016 = inttoptr i64 %v7015 to ptr
  store i32 2, ptr %p7016, align 4, !alias.scope !3, !noalias !4
  %v7017 = load i64, ptr %slot10, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  %ld7019 = load i32, ptr %p7018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7019, ptr %slot1314, align 8
  %v7020 = load i32, ptr %slot1314, align 8
  %v7021 = load i64, ptr %slot6, align 8
  %p7022 = inttoptr i64 %v7021 to ptr
  store i32 %v7020, ptr %p7022, align 4, !alias.scope !3, !noalias !4
  %v7023 = load i64, ptr %slot9, align 8
  %p7024 = inttoptr i64 %v7023 to ptr
  store i32 0, ptr %p7024, align 4, !alias.scope !3, !noalias !4
  %v7025 = load i64, ptr %slot5, align 8
  %p7026 = inttoptr i64 %v7025 to ptr
  store i32 1, ptr %p7026, align 4, !alias.scope !3, !noalias !4
  %v7027 = load i64, ptr %slot1312, align 8
  %p7028 = inttoptr i64 %v7027 to ptr
  %ld7029 = load i64, ptr %p7028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7029, ptr %slot1315, align 8
  %v7030 = load i64, ptr %slot1315, align 8
  %v7031 = load i64, ptr %slot26, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  store i64 %v7030, ptr %p7032, align 8, !alias.scope !3, !noalias !4
  %v7033 = load i64, ptr %slot26, align 8
  %p7034 = inttoptr i64 %v7033 to ptr
  %ld7035 = load i64, ptr %p7034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7035, ptr %slot1316, align 8
  %v7036 = load i64, ptr %slot26, align 8
  %p7037 = inttoptr i64 %v7036 to ptr
  %ld7038 = load i64, ptr %p7037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7038, ptr %slot1317, align 8
  %v7039 = load i64, ptr %slot1317, align 8
  %v7040 = load i64, ptr %slot13, align 8
  %p7041 = inttoptr i64 %v7040 to ptr
  store i64 %v7039, ptr %p7041, align 8, !alias.scope !3, !noalias !4
  %v7042 = load i64, ptr %slot13, align 8
  store i64 %v7042, ptr %slot1318, align 8
  %v7043 = load i64, ptr %slot15, align 8
  store i64 %v7043, ptr %slot1319, align 8
  %v7044 = load i64, ptr %slot34, align 8
  store i64 %v7044, ptr %slot1320, align 8
  %v7045 = load i64, ptr %slot1318, align 8
  %p7047 = inttoptr i64 %v7045 to ptr
  %gep7048 = getelementptr i8, ptr %p7047, i64 0
  %op7046 = ptrtoint ptr %gep7048 to i64
  store i64 %op7046, ptr %slot1321, align 8
  %v7049 = load i64, ptr %slot1321, align 8
  %p7050 = inttoptr i64 %v7049 to ptr
  %ld7051 = load i64, ptr %p7050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7051, ptr %slot1322, align 8
  %v7052 = load i64, ptr %slot1322, align 8
  %cmp7053 = icmp ne i64 %v7052, 0
  %cv7054 = zext i1 %cmp7053 to i32
  store i32 %cv7054, ptr %slot1323, align 8
  %v7055 = load i32, ptr %slot1323, align 8
  %cv7056 = zext i32 %v7055 to i64
  %cond7057 = icmp ne i64 %cv7056, 0
  br i1 %cond7057, label %bb_rcmoveheader2558, label %bb_rcmovenext2558
bb_rcmoveheader2558:
  %v7058 = load i64, ptr %slot1322, align 8
  %op7059 = sub i64 %v7058, 16
  store i64 %op7059, ptr %slot1324, align 8
  %v7060 = load i64, ptr %slot1322, align 8
  %p7061 = inttoptr i64 %v7060 to ptr
  %rgep7062 = getelementptr i8, ptr %p7061, i64 -16
  %ld7063 = load i64, ptr %rgep7062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7063, ptr %slot1325, align 8
  %v7064 = load i64, ptr %slot1325, align 8
  %op7065 = and i64 %v7064, 5764607523034234881
  store i64 %op7065, ptr %slot1326, align 8
  %v7066 = load i64, ptr %slot1326, align 8
  %cmp7067 = icmp ne i64 %v7066, 0
  %cv7068 = zext i1 %cmp7067 to i32
  store i32 %cv7068, ptr %slot1327, align 8
  %v7069 = load i32, ptr %slot1327, align 8
  %cv7070 = zext i32 %v7069 to i64
  %cond7071 = icmp ne i64 %cv7070, 0
  br i1 %cond7071, label %bb_rcmoveslow2555, label %bb_rcmovenext2558
bb_rcmovenext2558:
  %v7072 = load i64, ptr %slot1318, align 8
  %v7073 = load i64, ptr %slot1319, align 8
  %p7074 = inttoptr i64 %v7072 to ptr
  %p7075 = inttoptr i64 %v7073 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7075, ptr %p7074, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7076 = load i64, ptr %slot1318, align 8
  %p7077 = inttoptr i64 %v7076 to ptr
  store i64 0, ptr %p7077, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2555
bb_rcmoveslow2555:
  %v7078 = load i64, ptr %slot33, align 8
  %v7079 = load i64, ptr %slot1319, align 8
  %v7080 = load i64, ptr %slot1318, align 8
  %v7081 = load i64, ptr %slot1320, align 8
  %cv7082 = trunc i64 %v7081 to i32
  %call7083 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v7078, i64 %v7079, i64 %v7080, i32 %cv7082) nomerge, !dbg !172
  store i32 %call7083, ptr %slot1328, align 8
  %v7084 = load i32, ptr %slot1328, align 8
  %cv7085 = zext i32 %v7084 to i64
  %cond7086 = icmp ne i64 %cv7085, 0
  br i1 %cond7086, label %bb_rcsuccess2565, label %bb_rcfailure2565
bb_rcfailure2565:
  %v7087 = load i64, ptr %slot33, align 8
  %p7088 = inttoptr i64 %v7087 to ptr
  %call7089 = call i32 @myl_rc_take_failure(ptr %p7088) nomerge, !dbg !172
  store i32 %call7089, ptr %slot1329, align 8
  %v7090 = load i64, ptr %slot1, align 8
  %p7091 = inttoptr i64 %v7090 to ptr
  %v7092 = load i32, ptr %slot1329, align 8
  %call7093 = call i32 @myl_qbe_rc_status(ptr %p7091, i32 %v7092) nomerge, !dbg !172
  store i32 %call7093, ptr %slot1330, align 8
  br label %bb_failure
bb_rcsuccess2565:
  br label %bb_rcmoved2555
bb_rcmoved2555:
  %v7094 = load i64, ptr %slot5, align 8
  %p7095 = inttoptr i64 %v7094 to ptr
  store i32 0, ptr %p7095, align 4, !alias.scope !3, !noalias !4
  %v7096 = load i64, ptr %slot10, align 8
  %p7097 = inttoptr i64 %v7096 to ptr
  store i32 2, ptr %p7097, align 4, !alias.scope !3, !noalias !4
  %v7098 = load i64, ptr %slot9, align 8
  %p7099 = inttoptr i64 %v7098 to ptr
  store i32 1, ptr %p7099, align 4, !alias.scope !3, !noalias !4
  %v7100 = load i64, ptr %slot15, align 8
  store i64 %v7100, ptr %slot1331, align 8
  %v7101 = load i64, ptr %slot1331, align 8
  %p7102 = inttoptr i64 %v7101 to ptr
  %ld7103 = load i64, ptr %p7102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7103, ptr %slot1332, align 8
  %v7104 = load i64, ptr %slot9, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  store i32 0, ptr %p7105, align 4, !alias.scope !3, !noalias !4
  %v7106 = load i64, ptr %slot5, align 8
  %p7107 = inttoptr i64 %v7106 to ptr
  %ld7108 = load i32, ptr %p7107, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7108, ptr %slot1333, align 8
  %v7109 = load i32, ptr %slot1333, align 8
  %cv7110 = zext i32 %v7109 to i64
  %cond7111 = icmp ne i64 %cv7110, 0
  br i1 %cond7111, label %bb_rcslotdrop2576, label %bb_rcslotdone2576
bb_rcslotdrop2576:
  %v7112 = load i64, ptr %slot5, align 8
  %p7113 = inttoptr i64 %v7112 to ptr
  store i32 0, ptr %p7113, align 4, !alias.scope !3, !noalias !4
  %v7114 = load i64, ptr %slot11, align 8
  store i64 %v7114, ptr %slot1334, align 8
  %v7115 = load i64, ptr %slot6, align 8
  %p7116 = inttoptr i64 %v7115 to ptr
  %ld7117 = load i32, ptr %p7116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7117, ptr %slot1335, align 8
  %v7118 = load i32, ptr %slot1335, align 8
  %op7119 = and i32 %v7118, 28
  store i32 %op7119, ptr %slot1336, align 8
  %v7120 = load i32, ptr %slot1336, align 8
  %cv7121 = zext i32 %v7120 to i64
  %cond7122 = icmp ne i64 %cv7121, 0
  br i1 %cond7122, label %bb_rcslotrole2576, label %bb_rcslotowner2576
bb_rcslotrole2576:
  %v7123 = load i64, ptr %slot33, align 8
  store i64 %v7123, ptr %slot1337, align 8
  %v7124 = load i64, ptr %slot1334, align 8
  %p7125 = inttoptr i64 %v7124 to ptr
  %ld7126 = load i64, ptr %p7125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7126, ptr %slot1338, align 8
  %v7127 = load i64, ptr %slot1338, align 8
  %cmp7128 = icmp ne i64 %v7127, 0
  %cv7129 = zext i1 %cmp7128 to i32
  store i32 %cv7129, ptr %slot1339, align 8
  %v7130 = load i32, ptr %slot1339, align 8
  %cv7131 = zext i32 %v7130 to i64
  %cond7132 = icmp ne i64 %cv7131, 0
  br i1 %cond7132, label %bb_rcgnn2592, label %bb_rcgdone2592
bb_rcgnn2592:
  %v7133 = load i64, ptr %slot1338, align 8
  %op7134 = sub i64 %v7133, 16
  store i64 %op7134, ptr %slot1340, align 8
  %v7135 = load i64, ptr %slot1338, align 8
  %p7136 = inttoptr i64 %v7135 to ptr
  %rgep7137 = getelementptr i8, ptr %p7136, i64 -16
  %ld7138 = load i64, ptr %rgep7137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7138, ptr %slot1341, align 8
  %v7139 = load i64, ptr %slot1341, align 8
  %op7140 = and i64 %v7139, 4611686018427387906
  store i64 %op7140, ptr %slot1342, align 8
  %v7141 = load i64, ptr %slot1342, align 8
  %cmp7142 = icmp ne i64 %v7141, 0
  %cv7143 = zext i1 %cmp7142 to i32
  store i32 %cv7143, ptr %slot1343, align 8
  %v7144 = load i32, ptr %slot1343, align 8
  %cv7145 = zext i32 %v7144 to i64
  %cond7146 = icmp ne i64 %cv7145, 0
  br i1 %cond7146, label %bb_rcgclear2592, label %bb_rcgcounted2592
bb_rcgcounted2592:
  %v7147 = load i64, ptr %slot1338, align 8
  %op7148 = sub i64 %v7147, 24
  store i64 %op7148, ptr %slot1344, align 8
  %v7149 = load i64, ptr %slot1338, align 8
  %p7150 = inttoptr i64 %v7149 to ptr
  %rgep7151 = getelementptr i8, ptr %p7150, i64 -24
  %ld7152 = load i64, ptr %rgep7151, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7152, ptr %slot1345, align 8
  %v7153 = load i64, ptr %slot1345, align 8
  %op7154 = sub i64 %v7153, 1
  store i64 %op7154, ptr %slot1346, align 8
  %v7155 = load i64, ptr %slot1346, align 8
  %cmp7156 = icmp eq i64 %v7155, 0
  %cv7157 = zext i1 %cmp7156 to i32
  store i32 %cv7157, ptr %slot1347, align 8
  %v7158 = load i32, ptr %slot1347, align 8
  %cv7159 = zext i32 %v7158 to i64
  %cond7160 = icmp ne i64 %cv7159, 0
  br i1 %cond7160, label %bb_rcglast2592, label %bb_rcgdec2592
bb_rcglast2592:
  %v7161 = load i64, ptr %slot1338, align 8
  %op7162 = sub i64 %v7161, 32
  store i64 %op7162, ptr %slot1348, align 8
  %v7163 = load i64, ptr %slot1338, align 8
  %p7164 = inttoptr i64 %v7163 to ptr
  %rgep7165 = getelementptr i8, ptr %p7164, i64 -32
  %ld7166 = load i64, ptr %rgep7165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7166, ptr %slot1349, align 8
  %v7167 = load i64, ptr %slot1349, align 8
  %cmp7168 = icmp ne i64 %v7167, 0
  %cv7169 = zext i1 %cmp7168 to i32
  store i32 %cv7169, ptr %slot1350, align 8
  %v7170 = load i32, ptr %slot1350, align 8
  %cv7171 = zext i32 %v7170 to i64
  %cond7172 = icmp ne i64 %cv7171, 0
  br i1 %cond7172, label %bb_rcgdec2592, label %bb_rcgslow2592
bb_rcgslow2592:
  %v7173 = load i64, ptr %slot1337, align 8
  %v7174 = load i64, ptr %slot1334, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7173, i64 %v7174) nomerge, !dbg !172
  br label %bb_rcgdone2592
bb_rcgdec2592:
  %v7175 = load i64, ptr %slot1346, align 8
  %v7176 = load i64, ptr %slot1338, align 8
  %p7177 = inttoptr i64 %v7176 to ptr
  %rgep7178 = getelementptr i8, ptr %p7177, i64 -24
  store i64 %v7175, ptr %rgep7178, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2592
bb_rcgclear2592:
  %v7179 = load i64, ptr %slot1334, align 8
  %p7180 = inttoptr i64 %v7179 to ptr
  store i64 0, ptr %p7180, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2592
bb_rcgdone2592:
  br label %bb_rcslotdone2576
bb_rcslotowner2576:
  %v7181 = load i64, ptr %slot33, align 8
  store i64 %v7181, ptr %slot1351, align 8
  %v7182 = load i64, ptr %slot1334, align 8
  %p7183 = inttoptr i64 %v7182 to ptr
  %ld7184 = load i64, ptr %p7183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7184, ptr %slot1352, align 8
  %v7185 = load i64, ptr %slot1352, align 8
  %cmp7186 = icmp ne i64 %v7185, 0
  %cv7187 = zext i1 %cmp7186 to i32
  store i32 %cv7187, ptr %slot1353, align 8
  %v7188 = load i32, ptr %slot1353, align 8
  %cv7189 = zext i32 %v7188 to i64
  %cond7190 = icmp ne i64 %cv7189, 0
  br i1 %cond7190, label %bb_rcgnn2607, label %bb_rcgdone2607
bb_rcgnn2607:
  %v7191 = load i64, ptr %slot1352, align 8
  %op7192 = sub i64 %v7191, 16
  store i64 %op7192, ptr %slot1354, align 8
  %v7193 = load i64, ptr %slot1352, align 8
  %p7194 = inttoptr i64 %v7193 to ptr
  %rgep7195 = getelementptr i8, ptr %p7194, i64 -16
  %ld7196 = load i64, ptr %rgep7195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7196, ptr %slot1355, align 8
  %v7197 = load i64, ptr %slot1355, align 8
  %op7198 = and i64 %v7197, 4611686018427387906
  store i64 %op7198, ptr %slot1356, align 8
  %v7199 = load i64, ptr %slot1356, align 8
  %cmp7200 = icmp ne i64 %v7199, 0
  %cv7201 = zext i1 %cmp7200 to i32
  store i32 %cv7201, ptr %slot1357, align 8
  %v7202 = load i32, ptr %slot1357, align 8
  %cv7203 = zext i32 %v7202 to i64
  %cond7204 = icmp ne i64 %cv7203, 0
  br i1 %cond7204, label %bb_rcgclear2607, label %bb_rcgcounted2607
bb_rcgcounted2607:
  %v7205 = load i64, ptr %slot1352, align 8
  %op7206 = sub i64 %v7205, 32
  store i64 %op7206, ptr %slot1358, align 8
  %v7207 = load i64, ptr %slot1352, align 8
  %p7208 = inttoptr i64 %v7207 to ptr
  %rgep7209 = getelementptr i8, ptr %p7208, i64 -32
  %ld7210 = load i64, ptr %rgep7209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7210, ptr %slot1359, align 8
  %v7211 = load i64, ptr %slot1359, align 8
  %op7212 = sub i64 %v7211, 1
  store i64 %op7212, ptr %slot1360, align 8
  %v7213 = load i64, ptr %slot1360, align 8
  %cmp7214 = icmp eq i64 %v7213, 0
  %cv7215 = zext i1 %cmp7214 to i32
  store i32 %cv7215, ptr %slot1361, align 8
  %v7216 = load i32, ptr %slot1361, align 8
  %cv7217 = zext i32 %v7216 to i64
  %cond7218 = icmp ne i64 %cv7217, 0
  br i1 %cond7218, label %bb_rcglast2607, label %bb_rcgdec2607
bb_rcglast2607:
  %v7219 = load i64, ptr %slot1352, align 8
  %op7220 = sub i64 %v7219, 24
  store i64 %op7220, ptr %slot1362, align 8
  %v7221 = load i64, ptr %slot1352, align 8
  %p7222 = inttoptr i64 %v7221 to ptr
  %rgep7223 = getelementptr i8, ptr %p7222, i64 -24
  %ld7224 = load i64, ptr %rgep7223, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7224, ptr %slot1363, align 8
  %v7225 = load i64, ptr %slot1363, align 8
  %cmp7226 = icmp ne i64 %v7225, 0
  %cv7227 = zext i1 %cmp7226 to i32
  store i32 %cv7227, ptr %slot1364, align 8
  %v7228 = load i32, ptr %slot1364, align 8
  %cv7229 = zext i32 %v7228 to i64
  %cond7230 = icmp ne i64 %cv7229, 0
  br i1 %cond7230, label %bb_rcgdec2607, label %bb_rcgslow2607
bb_rcgslow2607:
  %v7231 = load i64, ptr %slot1351, align 8
  %v7232 = load i64, ptr %slot1334, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7231, i64 %v7232) nomerge, !dbg !172
  br label %bb_rcgdone2607
bb_rcgdec2607:
  %v7233 = load i64, ptr %slot1360, align 8
  %v7234 = load i64, ptr %slot1352, align 8
  %p7235 = inttoptr i64 %v7234 to ptr
  %rgep7236 = getelementptr i8, ptr %p7235, i64 -32
  store i64 %v7233, ptr %rgep7236, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2607
bb_rcgclear2607:
  %v7237 = load i64, ptr %slot1334, align 8
  %p7238 = inttoptr i64 %v7237 to ptr
  store i64 0, ptr %p7238, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2607
bb_rcgdone2607:
  br label %bb_rcslotdone2576
bb_rcslotdone2576:
  %v7239 = load i64, ptr %slot1332, align 8
  ret i64 %v7239
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_02537ee618e1438356c8bdec150c3ad61831da7f3bc9d35ea650823948165ff8 = external global i8, align 8
@myl_lit_1aca0d6090acebe519e6585d6572c624809ab30b249e864b7ef1c235b02f902a = external global i8, align 8
@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8
@myl_lit_6852c1228bf663edc32c60c4f34b0e76845ba0a899fe6006aae97bb03c5b6adb = external global i8, align 8
@myl_lit_6fed35e3009e497ab580214c876d7a746f7a24cf38303b15909afebc8b6b79d5 = external global i8, align 8
@myl_lit_d6b006dd0b769e0e5a8bb806c60978be91d208b60a28fe604b56cb4713aa8698 = external global i8, align 8
@myl_lit_f2a3ab8999a0700efc12f265f5a0d76d8e59208e4e458e1b2c63f089c38a43ad = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_23292ffd96759b66f343854de59e707a4bc4862e0d17a72d535a7b342b17aa93(i64, i64, i64)
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare i64 @myl_f_8e32b2effb3ef1f06032f15176c7ea12d1243f1ccdd152632b623d7da50a8686(i64, i64, i64)
declare i64 @myl_f_c3b1c0aa0a5fe799edd45ebf9b41e663896ccd0082768a4e95dc5a4b7934e4e5_rc_borrow(i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_drop(i64, i64)
declare void @myl_t_9f20ac685dc97b126a8aa4d1adcf54837a64e2fbf04f26b6ccf5b4dcae2a3743_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0", linkageName: "myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1535707518612635487, i64 0, !"myl_f_9d1bb47309408e25a3d09a44334f41a21848293967efef1991613daa71431fc0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!124 = !DILocation(line: 19, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!134 = !DILocation(line: 32, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!140 = !DILocation(line: 41, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!144 = !DILocation(line: 43, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!146 = !DILocation(line: 51, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!148 = !DILocation(line: 52, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!150 = !DILocation(line: 53, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!152 = !DILocation(line: 55, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!154 = !DILocation(line: 56, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!156 = !DILocation(line: 60, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!158 = !DILocation(line: 61, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!160 = !DILocation(line: 63, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!162 = !DILocation(line: 68, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!164 = !DILocation(line: 69, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!166 = !DILocation(line: 71, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!168 = !DILocation(line: 72, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!170 = !DILocation(line: 74, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!172 = !DILocation(line: 76, column: 0, scope: !173)
