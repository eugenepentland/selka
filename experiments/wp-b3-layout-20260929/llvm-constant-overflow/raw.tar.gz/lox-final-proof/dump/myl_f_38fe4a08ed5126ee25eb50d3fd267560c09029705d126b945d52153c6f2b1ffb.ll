target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v91 = load i64, ptr %slot1, align 8
  %op92 = add i64 %v91, 32
  store i64 %op92, ptr %slot6, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot7, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot8, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot9, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot10, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot11, align 8
  %mem103 = alloca i8, i64 112, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot12, align 8
  %mem105 = alloca i8, i64 312, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot13, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot14, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot15, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot16, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot17, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot18, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot19, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot20, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot21, align 8
  %mem123 = alloca i8, i64 312, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot22, align 8
  %mem125 = alloca i8, i64 312, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot23, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot24, align 8
  %v129 = load i64, ptr %slot1, align 8
  %op130 = add i64 %v129, 64
  store i64 %op130, ptr %slot25, align 8
  %v131 = load i64, ptr %slot25, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !4, !noalias !3
  store i64 %ld133, ptr %slot26, align 8
  %stack134 = call ptr @llvm.stacksave()
  %stackaddr135 = ptrtoint ptr %stack134 to i64
  %v136 = load i64, ptr %slot26, align 8
  %cmp137 = icmp ult i64 %stackaddr135, %v136
  %cv138 = zext i1 %cmp137 to i64
  store i64 %cv138, ptr %slot27, align 8
  %v139 = load i64, ptr %slot27, align 8
  %cond140 = icmp ne i64 %v139, 0
  br i1 %cond140, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v141 = load i64, ptr %slot1, align 8
  %p142 = inttoptr i64 %v141 to ptr
  call void @myl_qbe_fail_frame(ptr %p142) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v143 = load i64, ptr %slot2, align 8
  %v144 = load i64, ptr %slot14, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot3, align 8
  %v147 = load i64, ptr %slot15, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot4, align 8
  %v150 = load i64, ptr %slot16, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot5, align 8
  %v153 = load i64, ptr %slot17, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot1, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %call157 = call ptr @myl_qbe_heap(ptr %p156) nomerge, !dbg !112
  %calladdr158 = ptrtoint ptr %call157 to i64
  store i64 %calladdr158, ptr %slot28, align 8
  %v159 = load i64, ptr %slot1, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %call161 = call i64 @myl_qbe_region_mark(ptr %p160) nomerge, !dbg !112
  store i64 %call161, ptr %slot29, align 8
  %v162 = load i64, ptr %slot7, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i32 0, ptr %p163, align 4, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot8, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i32 0, ptr %p165, align 4, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot9, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot10, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot11, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v172 = load i64, ptr %slot14, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld174, ptr %slot30, align 8
  %v175 = load i64, ptr %slot30, align 8
  %v176 = load i64, ptr %slot18, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot15, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot31, align 8
  %v181 = load i64, ptr %slot31, align 8
  %v182 = load i64, ptr %slot19, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot16, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot32, align 8
  %v187 = load i64, ptr %slot32, align 8
  %v188 = load i64, ptr %slot20, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot17, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot33, align 8
  %v193 = load i64, ptr %slot33, align 8
  %v194 = load i64, ptr %slot21, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 %v193, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot22, align 8
  store i64 %v196, ptr %slot34, align 8
  %v197 = load i64, ptr %slot34, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 0, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot34, align 8
  %p201 = inttoptr i64 %v199 to ptr
  %gep202 = getelementptr i8, ptr %p201, i64 8
  %op200 = ptrtoint ptr %gep202 to i64
  store i64 %op200, ptr %slot35, align 8
  %v203 = load i64, ptr %slot35, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i64 0, ptr %p204, align 8, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot34, align 8
  %p207 = inttoptr i64 %v205 to ptr
  %gep208 = getelementptr i8, ptr %p207, i64 16
  %op206 = ptrtoint ptr %gep208 to i64
  store i64 %op206, ptr %slot36, align 8
  %v209 = load i64, ptr %slot36, align 8
  %p210 = inttoptr i64 %v209 to ptr
  store i64 0, ptr %p210, align 8, !alias.scope !3, !noalias !4
  %v211 = load i64, ptr %slot34, align 8
  %p213 = inttoptr i64 %v211 to ptr
  %gep214 = getelementptr i8, ptr %p213, i64 24
  %op212 = ptrtoint ptr %gep214 to i64
  store i64 %op212, ptr %slot37, align 8
  %v215 = load i64, ptr %slot37, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i64 0, ptr %p216, align 8, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot34, align 8
  %p219 = inttoptr i64 %v217 to ptr
  %gep220 = getelementptr i8, ptr %p219, i64 32
  %op218 = ptrtoint ptr %gep220 to i64
  store i64 %op218, ptr %slot38, align 8
  %v221 = load i64, ptr %slot38, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 0, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot34, align 8
  %p225 = inttoptr i64 %v223 to ptr
  %gep226 = getelementptr i8, ptr %p225, i64 40
  %op224 = ptrtoint ptr %gep226 to i64
  store i64 %op224, ptr %slot39, align 8
  %v227 = load i64, ptr %slot39, align 8
  %p228 = inttoptr i64 %v227 to ptr
  store i64 0, ptr %p228, align 8, !alias.scope !3, !noalias !4
  %v229 = load i64, ptr %slot34, align 8
  %p231 = inttoptr i64 %v229 to ptr
  %gep232 = getelementptr i8, ptr %p231, i64 48
  %op230 = ptrtoint ptr %gep232 to i64
  store i64 %op230, ptr %slot40, align 8
  %v233 = load i64, ptr %slot40, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i64 0, ptr %p234, align 8, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot11, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i32 1, ptr %p236, align 4, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot29, align 8
  store i64 %v237, ptr %slot41, align 8
  %v238 = load i64, ptr %slot19, align 8
  store i64 %v238, ptr %slot42, align 8
  %v239 = load i64, ptr %slot34, align 8
  %p241 = inttoptr i64 %v239 to ptr
  %gep242 = getelementptr i8, ptr %p241, i64 0
  %op240 = ptrtoint ptr %gep242 to i64
  store i64 %op240, ptr %slot43, align 8
  %v243 = load i64, ptr %slot42, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot44, align 8
  %v246 = load i64, ptr %slot44, align 8
  %v247 = load i64, ptr %slot43, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot20, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot45, align 8
  %v252 = load i64, ptr %slot34, align 8
  %p254 = inttoptr i64 %v252 to ptr
  %gep255 = getelementptr i8, ptr %p254, i64 8
  %op253 = ptrtoint ptr %gep255 to i64
  store i64 %op253, ptr %slot46, align 8
  %v256 = load i64, ptr %slot20, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot47, align 8
  store i32 0, ptr %slot48, align 8
  %v259 = load i64, ptr %slot9, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i32, ptr %p260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld261, ptr %slot49, align 8
  %v262 = load i32, ptr %slot49, align 8
  %op263 = and i32 %v262, 24
  store i32 %op263, ptr %slot49, align 8
  %v264 = load i32, ptr %slot49, align 8
  %cmp265 = icmp eq i32 %v264, 0
  %cv266 = zext i1 %cmp265 to i32
  store i32 %cv266, ptr %slot50, align 8
  %v267 = load i32, ptr %slot48, align 8
  %v268 = load i32, ptr %slot50, align 8
  %op269 = and i32 %v267, %v268
  store i32 %op269, ptr %slot51, align 8
  %v270 = load i32, ptr %slot51, align 8
  %cv271 = zext i32 %v270 to i64
  %cond272 = icmp ne i64 %cv271, 0
  br i1 %cond272, label %bb_rctake29, label %bb_rccopy29
bb_rctake29:
  %v273 = load i64, ptr %slot13, align 8
  store i64 %v273, ptr %slot52, align 8
  %v274 = load i64, ptr %slot29, align 8
  store i64 %v274, ptr %slot53, align 8
  %v275 = load i64, ptr %slot28, align 8
  %v276 = load i64, ptr %slot52, align 8
  %v277 = load i64, ptr %slot47, align 8
  %v278 = load i64, ptr %slot53, align 8
  %cv279 = trunc i64 %v278 to i32
  %call280 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v275, i64 %v276, i64 %v277, i32 %cv279) nomerge, !dbg !114
  store i32 %call280, ptr %slot54, align 8
  %v281 = load i32, ptr %slot54, align 8
  %cv282 = zext i32 %v281 to i64
  %cond283 = icmp ne i64 %cv282, 0
  br i1 %cond283, label %bb_rcsuccess39, label %bb_rcfailure39
bb_rcfailure39:
  %v284 = load i64, ptr %slot28, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %call286 = call i32 @myl_rc_take_failure(ptr %p285) nomerge, !dbg !114
  store i32 %call286, ptr %slot55, align 8
  %v287 = load i64, ptr %slot1, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %v289 = load i32, ptr %slot55, align 8
  %call290 = call i32 @myl_qbe_rc_status(ptr %p288, i32 %v289) nomerge, !dbg !114
  store i32 %call290, ptr %slot56, align 8
  br label %bb_failure
bb_rcsuccess39:
  %v291 = load i64, ptr %slot10, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i32 1, ptr %p292, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared29
bb_rccopy29:
  %v293 = load i64, ptr %slot13, align 8
  store i64 %v293, ptr %slot57, align 8
  %v294 = load i64, ptr %slot29, align 8
  store i64 %v294, ptr %slot58, align 8
  %v295 = load i64, ptr %slot28, align 8
  %v296 = load i64, ptr %slot57, align 8
  %v297 = load i64, ptr %slot47, align 8
  %v298 = load i64, ptr %slot58, align 8
  %cv299 = trunc i64 %v298 to i32
  %call300 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v295, i64 %v296, i64 %v297, i32 %cv299) nomerge, !dbg !114
  store i32 %call300, ptr %slot59, align 8
  %v301 = load i32, ptr %slot59, align 8
  %cv302 = zext i32 %v301 to i64
  %cond303 = icmp ne i64 %cv302, 0
  br i1 %cond303, label %bb_rcsuccess48, label %bb_rcfailure48
bb_rcfailure48:
  %v304 = load i64, ptr %slot28, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %call306 = call i32 @myl_rc_take_failure(ptr %p305) nomerge, !dbg !114
  store i32 %call306, ptr %slot60, align 8
  %v307 = load i64, ptr %slot1, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %v309 = load i32, ptr %slot60, align 8
  %call310 = call i32 @myl_qbe_rc_status(ptr %p308, i32 %v309) nomerge, !dbg !114
  store i32 %call310, ptr %slot61, align 8
  br label %bb_failure
bb_rcsuccess48:
  %v311 = load i64, ptr %slot10, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i32 1, ptr %p312, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared29
bb_rcprepared29:
  %v313 = load i64, ptr %slot13, align 8
  store i64 %v313, ptr %slot62, align 8
  %v314 = load i64, ptr %slot62, align 8
  %v315 = load i64, ptr %slot46, align 8
  %p316 = inttoptr i64 %v314 to ptr
  %p317 = inttoptr i64 %v315 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p317, ptr %p316, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot10, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i32 0, ptr %p319, align 4, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot21, align 8
  store i64 %v320, ptr %slot63, align 8
  %v321 = load i64, ptr %slot34, align 8
  %p323 = inttoptr i64 %v321 to ptr
  %gep324 = getelementptr i8, ptr %p323, i64 48
  %op322 = ptrtoint ptr %gep324 to i64
  store i64 %op322, ptr %slot64, align 8
  %v325 = load i64, ptr %slot63, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i64, ptr %p326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld327, ptr %slot65, align 8
  %v328 = load i64, ptr %slot65, align 8
  %v329 = load i64, ptr %slot64, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 %v328, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot34, align 8
  %v332 = load i64, ptr %slot19, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot19, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot66, align 8
  %v337 = load i64, ptr %slot12, align 8
  store i64 %v337, ptr %slot67, align 8
  %v338 = load i64, ptr %slot66, align 8
  %v339 = load i64, ptr %slot67, align 8
  %p340 = inttoptr i64 %v338 to ptr
  %p341 = inttoptr i64 %v339 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p341, ptr %p340, i64 56, i1 false)
  %v342 = load i64, ptr %slot8, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i32 2, ptr %p343, align 4, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot7, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i32 1, ptr %p345, align 4, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot67, align 8
  %v347 = load i64, ptr %slot19, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot23, align 8
  store i64 %v349, ptr %slot68, align 8
  %v350 = load i64, ptr %slot68, align 8
  %p351 = inttoptr i64 %v350 to ptr
  call void @llvm.memset.p0.i64(ptr %p351, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v352 = load i64, ptr %slot68, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot11, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i32 1, ptr %p355, align 4, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot19, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot69, align 8
  %v359 = load i64, ptr %slot68, align 8
  %p361 = inttoptr i64 %v359 to ptr
  %gep362 = getelementptr i8, ptr %p361, i64 8
  %op360 = ptrtoint ptr %gep362 to i64
  store i64 %op360, ptr %slot70, align 8
  %v363 = load i64, ptr %slot29, align 8
  store i64 %v363, ptr %slot71, align 8
  %v364 = load i64, ptr %slot19, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot72, align 8
  %v367 = load i64, ptr %slot13, align 8
  store i64 %v367, ptr %slot73, align 8
  %v368 = load i64, ptr %slot29, align 8
  store i64 %v368, ptr %slot74, align 8
  %v369 = load i64, ptr %slot28, align 8
  %v370 = load i64, ptr %slot73, align 8
  %v371 = load i64, ptr %slot72, align 8
  %v372 = load i64, ptr %slot74, align 8
  %cv373 = trunc i64 %v372 to i32
  %call374 = call i32 @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_take(i64 %v369, i64 %v370, i64 %v371, i32 %cv373) nomerge, !dbg !116
  store i32 %call374, ptr %slot75, align 8
  %v375 = load i32, ptr %slot75, align 8
  %cv376 = zext i32 %v375 to i64
  %cond377 = icmp ne i64 %cv376, 0
  br i1 %cond377, label %bb_rcsuccess81, label %bb_rcfailure81
bb_rcfailure81:
  %v378 = load i64, ptr %slot28, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %call380 = call i32 @myl_rc_take_failure(ptr %p379) nomerge, !dbg !116
  store i32 %call380, ptr %slot76, align 8
  %v381 = load i64, ptr %slot1, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %v383 = load i32, ptr %slot76, align 8
  %call384 = call i32 @myl_qbe_rc_status(ptr %p382, i32 %v383) nomerge, !dbg !116
  store i32 %call384, ptr %slot77, align 8
  br label %bb_failure
bb_rcsuccess81:
  %v385 = load i64, ptr %slot7, align 8
  %p386 = inttoptr i64 %v385 to ptr
  store i32 0, ptr %p386, align 4, !alias.scope !3, !noalias !4
  %v387 = load i64, ptr %slot10, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i32 1, ptr %p388, align 4, !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot13, align 8
  store i64 %v389, ptr %slot78, align 8
  %v390 = load i64, ptr %slot78, align 8
  %v391 = load i64, ptr %slot70, align 8
  %p392 = inttoptr i64 %v390 to ptr
  %p393 = inttoptr i64 %v391 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p393, ptr %p392, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot10, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i32 0, ptr %p395, align 4, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot68, align 8
  %v397 = load i64, ptr %slot19, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i64 %v396, ptr %p398, align 8, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot19, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot79, align 8
  %v402 = load i64, ptr %slot12, align 8
  store i64 %v402, ptr %slot80, align 8
  %v403 = load i64, ptr %slot79, align 8
  %v404 = load i64, ptr %slot80, align 8
  %p405 = inttoptr i64 %v403 to ptr
  %p406 = inttoptr i64 %v404 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p406, ptr %p405, i64 112, i1 false)
  %v407 = load i64, ptr %slot8, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i32 2, ptr %p408, align 4, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot7, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i32 1, ptr %p410, align 4, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot80, align 8
  %v412 = load i64, ptr %slot19, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot18, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot81, align 8
  %v417 = load i64, ptr %slot19, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot82, align 8
  %v420 = load i64, ptr %slot1, align 8
  %v421 = load i64, ptr %slot81, align 8
  %v422 = load i64, ptr %slot82, align 8
  %call423 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v420, i64 %v421, i64 %v422) nomerge, !dbg !118
  store i64 %call423, ptr %slot83, align 8
  %v424 = load i64, ptr %slot83, align 8
  %v425 = load i64, ptr %slot18, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i64 %v424, ptr %p426, align 8, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot7, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %ld429 = load i32, ptr %p428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld429, ptr %slot84, align 8
  %v430 = load i32, ptr %slot84, align 8
  %cv431 = zext i32 %v430 to i64
  %cond432 = icmp ne i64 %cv431, 0
  br i1 %cond432, label %bb_rcslotdrop107, label %bb_rcslotdone107
bb_rcslotdrop107:
  %v433 = load i64, ptr %slot7, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i32 0, ptr %p434, align 4, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot12, align 8
  store i64 %v435, ptr %slot85, align 8
  %v436 = load i64, ptr %slot8, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i32, ptr %p437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld438, ptr %slot86, align 8
  %v439 = load i32, ptr %slot86, align 8
  %op440 = and i32 %v439, 28
  store i32 %op440, ptr %slot87, align 8
  %v441 = load i32, ptr %slot87, align 8
  %cv442 = zext i32 %v441 to i64
  %cond443 = icmp ne i64 %cv442, 0
  br i1 %cond443, label %bb_rcslotrole107, label %bb_rcslotowner107
bb_rcslotrole107:
  %v444 = load i64, ptr %slot28, align 8
  store i64 %v444, ptr %slot88, align 8
  %v445 = load i64, ptr %slot88, align 8
  %v446 = load i64, ptr %slot85, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v445, i64 %v446) nomerge, !dbg !118
  br label %bb_rcslotdone107
bb_rcslotowner107:
  %v447 = load i64, ptr %slot28, align 8
  store i64 %v447, ptr %slot89, align 8
  %v448 = load i64, ptr %slot89, align 8
  %v449 = load i64, ptr %slot85, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v448, i64 %v449) nomerge, !dbg !118
  br label %bb_rcslotdone107
bb_rcslotdone107:
  %v450 = load i64, ptr %slot18, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i64, ptr %p451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot90, align 8
  %v453 = load i64, ptr %slot90, align 8
  ret i64 %v453
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare i32 @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb", linkageName: "myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17054812554056352869, i64 0, !"myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
