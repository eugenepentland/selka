target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %callresult14 = alloca [16 x i8], align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v18 = load i64, ptr %slot1, align 8
  %op19 = add i64 %v18, 32
  store i64 %op19, ptr %slot3, align 8
  %mem20 = alloca i8, i64 16, align 8
  %ptr21 = ptrtoint ptr %mem20 to i64
  store i64 %ptr21, ptr %slot4, align 8
  %mem22 = alloca i8, i64 8, align 8
  %ptr23 = ptrtoint ptr %mem22 to i64
  store i64 %ptr23, ptr %slot5, align 8
  %mem24 = alloca i8, i64 8, align 8
  %ptr25 = ptrtoint ptr %mem24 to i64
  store i64 %ptr25, ptr %slot6, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem26 = alloca i8, i64 8, align 8
  %ptr27 = ptrtoint ptr %mem26 to i64
  store i64 %ptr27, ptr %slot7, align 8
  %v28 = load i64, ptr %slot1, align 8
  %op29 = add i64 %v28, 64
  store i64 %op29, ptr %slot8, align 8
  %v30 = load i64, ptr %slot8, align 8
  %p31 = inttoptr i64 %v30 to ptr
  %ld32 = load i64, ptr %p31, align 8, !alias.scope !4, !noalias !3
  store i64 %ld32, ptr %slot9, align 8
  %stack33 = call ptr @llvm.stacksave()
  %stackaddr34 = ptrtoint ptr %stack33 to i64
  %v35 = load i64, ptr %slot9, align 8
  %cmp36 = icmp ult i64 %stackaddr34, %v35
  %cv37 = zext i1 %cmp36 to i64
  store i64 %cv37, ptr %slot10, align 8
  %v38 = load i64, ptr %slot10, align 8
  %cond39 = icmp ne i64 %v38, 0
  br i1 %cond39, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v40 = load i64, ptr %slot1, align 8
  %p41 = inttoptr i64 %v40 to ptr
  call void @myl_qbe_fail_frame(ptr %p41) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v42 = load i64, ptr %slot2, align 8
  %v43 = load i64, ptr %slot5, align 8
  %p44 = inttoptr i64 %v43 to ptr
  store i64 %v42, ptr %p44, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v45 = load i64, ptr %slot5, align 8
  %p46 = inttoptr i64 %v45 to ptr
  %ld47 = load i64, ptr %p46, align 8, !alias.scope !3, !noalias !4
  store i64 %ld47, ptr %slot11, align 8
  %v48 = load i64, ptr %slot11, align 8
  %v49 = load i64, ptr %slot6, align 8
  %p50 = inttoptr i64 %v49 to ptr
  store i64 %v48, ptr %p50, align 8, !alias.scope !3, !noalias !4
  %v51 = load i64, ptr %slot6, align 8
  %p52 = inttoptr i64 %v51 to ptr
  %ld53 = load i64, ptr %p52, align 8, !alias.scope !3, !noalias !4
  store i64 %ld53, ptr %slot12, align 8
  %v54 = load i64, ptr %slot1, align 8
  %v55 = load i64, ptr %slot12, align 8
  %call56 = call { i64, i64 } @myl_f_05ac8a0ca542b042f3d72a124f66a4603743041d1e00505ad544e822e7300181(i64 %v54, i64 %v55) nomerge, !dbg !112
  store { i64, i64 } %call56, ptr %callresult14, align 8
  %addr57 = ptrtoint ptr %callresult14 to i64
  store i64 %addr57, ptr %slot13, align 8
  %v58 = load i64, ptr %slot13, align 8
  %v59 = load i64, ptr %slot6, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 %v58, ptr %p60, align 8, !alias.scope !3, !noalias !4
  %v61 = load i64, ptr %slot6, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot15, align 8
  %v64 = load i64, ptr %slot15, align 8
  %p65 = inttoptr i64 %v64 to ptr
  %ld66 = load i32, ptr %p65, align 4
  %ext67 = zext i32 %ld66 to i64
  store i64 %ext67, ptr %slot16, align 8
  %v68 = load i64, ptr %slot16, align 8
  %cmp69 = icmp eq i64 %v68, 1
  %cv70 = zext i1 %cmp69 to i64
  store i64 %cv70, ptr %slot17, align 8
  %v71 = load i64, ptr %slot17, align 8
  %cond72 = icmp ne i64 %v71, 0
  br i1 %cond72, label %bb_errtrace22, label %bb_errtraced22
bb_errtrace22:
  %p73 = inttoptr i64 ptrtoint (ptr @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p73, i64 8589934594) "call-inline-cost"="0", !dbg !114
  br label %bb_errtraced22
bb_errtraced22:
  %v74 = load i64, ptr %slot15, align 8
  %p75 = inttoptr i64 %v74 to ptr
  %ret76 = load { i64, i64 }, ptr %p75, align 8
  ret { i64, i64 } %ret76
bb_failure:
  %v77 = load i64, ptr %slot4, align 8
  %p78 = inttoptr i64 %v77 to ptr
  call void @llvm.memset.p0.i64(ptr %p78, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v79 = load i64, ptr %slot4, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ret81 = load { i64, i64 }, ptr %p80, align 8
  ret { i64, i64 } %ret81
bb_entry_failure:
  %v82 = load i64, ptr %slot4, align 8
  %p83 = inttoptr i64 %v82 to ptr
  call void @llvm.memset.p0.i64(ptr %p83, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v84 = load i64, ptr %slot4, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ret86 = load { i64, i64 }, ptr %p85, align 8
  ret { i64, i64 } %ret86
}

@myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e_meta = external global i8, align 8

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_05ac8a0ca542b042f3d72a124f66a4603743041d1e00505ad544e822e7300181(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e", linkageName: "myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8631655382301114625, i64 0, !"myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
