target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %callresult83 = alloca [24 x i8], align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %callresult230 = alloca [16 x i8], align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %callresult234 = alloca [32 x i8], align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %callresult298 = alloca [16 x i8], align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %callresult461 = alloca [24 x i8], align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %callresult608 = alloca [16 x i8], align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %callresult612 = alloca [32 x i8], align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %callresult740 = alloca [16 x i8], align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %callresult764 = alloca [16 x i8], align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i32, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i32, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i32, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i32, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i32, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i32, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i32, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i32, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i32, align 8
  %slot1284 = alloca i32, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i32, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i32, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i32, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i32, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i32, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i32, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i32, align 8
  %slot1384 = alloca i32, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i32, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i32, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i32, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i32, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i32, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i32, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i32, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i32, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i32, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i64, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i64, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i64, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i32, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i32, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i32, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i32, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i32, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i32, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i32, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i32, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i32, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i32, align 8
  %slot1554 = alloca i32, align 8
  %slot1555 = alloca i32, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i32, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i32, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i32, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i32, align 8
  %slot1569 = alloca i32, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i32, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i64, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i64, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i32, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i32, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i32, align 8
  %slot1610 = alloca i32, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i64, align 8
  %callresult1618 = alloca [16 x i8], align 8
  %slot1619 = alloca i32, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i32, align 8
  %slot1622 = alloca i32, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i32, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i32, align 8
  %slot1635 = alloca i32, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i32, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i32, align 8
  %slot1647 = alloca i32, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i32, align 8
  %slot1667 = alloca i32, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i64, align 8
  %slot1671 = alloca i32, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i32, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i32, align 8
  %slot1676 = alloca i32, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i32, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i32, align 8
  %slot1682 = alloca i32, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i64, align 8
  %slot1685 = alloca i32, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i32, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i32, align 8
  %slot1692 = alloca i64, align 8
  %slot1693 = alloca i32, align 8
  %slot1694 = alloca i32, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i64, align 8
  %slot1697 = alloca i32, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i32, align 8
  %slot1700 = alloca i32, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i32, align 8
  %slot1704 = alloca i64, align 8
  %slot1705 = alloca i32, align 8
  %slot1706 = alloca i32, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i64, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i32, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i64, align 8
  %slot1715 = alloca i32, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i32, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i32, align 8
  %slot1724 = alloca i32, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i32, align 8
  %slot1728 = alloca i64, align 8
  %slot1729 = alloca i32, align 8
  %slot1730 = alloca i32, align 8
  %slot1731 = alloca i64, align 8
  %slot1732 = alloca i64, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i64, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i32, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i64, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i64, align 8
  %slot1748 = alloca i64, align 8
  %slot1749 = alloca i64, align 8
  %callresult1750 = alloca [16 x i8], align 8
  %slot1751 = alloca i64, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i32, align 8
  %slot1754 = alloca i32, align 8
  %slot1755 = alloca i32, align 8
  %slot1756 = alloca i32, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i32, align 8
  %slot1759 = alloca i32, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i64, align 8
  %slot1762 = alloca i32, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i64, align 8
  %slot1766 = alloca i32, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i64, align 8
  %slot1770 = alloca i32, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i64, align 8
  %slot1773 = alloca i32, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i32, align 8
  %slot1777 = alloca i64, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i64, align 8
  %slot1780 = alloca i32, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i64, align 8
  %slot1783 = alloca i64, align 8
  %slot1784 = alloca i32, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i64, align 8
  %slot1787 = alloca i32, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i64, align 8
  %slot1790 = alloca i32, align 8
  %slot1791 = alloca i64, align 8
  %slot1792 = alloca i64, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i64, align 8
  %slot1795 = alloca i64, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i32, align 8
  %slot1799 = alloca i32, align 8
  %slot1800 = alloca i32, align 8
  %slot1801 = alloca i32, align 8
  %slot1802 = alloca i64, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i64, align 8
  %slot1805 = alloca i64, align 8
  %slot1806 = alloca i32, align 8
  %slot1807 = alloca i32, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i32, align 8
  %slot1812 = alloca i64, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i32, align 8
  %slot1816 = alloca i64, align 8
  %slot1817 = alloca i32, align 8
  %slot1818 = alloca i32, align 8
  %slot1819 = alloca i32, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i32, align 8
  %slot1823 = alloca i32, align 8
  %slot1824 = alloca i32, align 8
  %slot1825 = alloca i32, align 8
  %slot1826 = alloca i64, align 8
  %slot1827 = alloca i32, align 8
  %slot1828 = alloca i32, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i64, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i64, align 8
  %slot1833 = alloca i64, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i64, align 8
  %slot1836 = alloca i64, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i32, align 8
  %slot1839 = alloca i32, align 8
  %slot1840 = alloca i32, align 8
  %slot1841 = alloca i64, align 8
  %slot1842 = alloca i64, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i32, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i32, align 8
  %slot1848 = alloca i32, align 8
  %slot1849 = alloca i64, align 8
  %slot1850 = alloca i64, align 8
  %slot1851 = alloca i32, align 8
  %slot1852 = alloca i64, align 8
  %slot1853 = alloca i32, align 8
  %slot1854 = alloca i32, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i64, align 8
  %slot1857 = alloca i32, align 8
  %slot1858 = alloca i64, align 8
  %slot1859 = alloca i32, align 8
  %slot1860 = alloca i32, align 8
  %slot1861 = alloca i64, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i32, align 8
  %slot1864 = alloca i64, align 8
  %slot1865 = alloca i32, align 8
  %slot1866 = alloca i32, align 8
  %slot1867 = alloca i64, align 8
  %slot1868 = alloca i64, align 8
  %slot1869 = alloca i32, align 8
  %slot1870 = alloca i64, align 8
  %slot1871 = alloca i32, align 8
  %slot1872 = alloca i32, align 8
  %slot1873 = alloca i64, align 8
  %slot1874 = alloca i64, align 8
  %slot1875 = alloca i32, align 8
  %slot1876 = alloca i64, align 8
  %slot1877 = alloca i32, align 8
  %slot1878 = alloca i32, align 8
  %slot1879 = alloca i64, align 8
  %slot1880 = alloca i64, align 8
  %slot1881 = alloca i32, align 8
  %slot1882 = alloca i64, align 8
  %slot1883 = alloca i32, align 8
  %slot1884 = alloca i32, align 8
  %slot1885 = alloca i64, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i32, align 8
  %slot1888 = alloca i64, align 8
  %slot1889 = alloca i32, align 8
  %slot1890 = alloca i32, align 8
  %slot1891 = alloca i64, align 8
  %slot1892 = alloca i64, align 8
  %slot1893 = alloca i32, align 8
  %slot1894 = alloca i64, align 8
  %slot1895 = alloca i32, align 8
  %slot1896 = alloca i32, align 8
  %slot1897 = alloca i64, align 8
  %slot1898 = alloca i64, align 8
  %slot1899 = alloca i32, align 8
  %slot1900 = alloca i64, align 8
  %slot1901 = alloca i32, align 8
  %slot1902 = alloca i32, align 8
  %slot1903 = alloca i64, align 8
  %slot1904 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1905 = load i64, ptr %slot1, align 8
  %op1906 = add i64 %v1905, 32
  store i64 %op1906, ptr %slot4, align 8
  %mem1907 = alloca i8, i64 24, align 8
  %ptr1908 = ptrtoint ptr %mem1907 to i64
  store i64 %ptr1908, ptr %slot5, align 8
  %mem1909 = alloca i8, i64 8, align 8
  %ptr1910 = ptrtoint ptr %mem1909 to i64
  store i64 %ptr1910, ptr %slot6, align 8
  %mem1911 = alloca i8, i64 8, align 8
  %ptr1912 = ptrtoint ptr %mem1911 to i64
  store i64 %ptr1912, ptr %slot7, align 8
  %mem1913 = alloca i8, i64 8, align 8
  %ptr1914 = ptrtoint ptr %mem1913 to i64
  store i64 %ptr1914, ptr %slot8, align 8
  %mem1915 = alloca i8, i64 8, align 8
  %ptr1916 = ptrtoint ptr %mem1915 to i64
  store i64 %ptr1916, ptr %slot9, align 8
  %mem1917 = alloca i8, i64 8, align 8
  %ptr1918 = ptrtoint ptr %mem1917 to i64
  store i64 %ptr1918, ptr %slot10, align 8
  %mem1919 = alloca i8, i64 8, align 8
  %ptr1920 = ptrtoint ptr %mem1919 to i64
  store i64 %ptr1920, ptr %slot11, align 8
  %mem1921 = alloca i8, i64 8, align 8
  %ptr1922 = ptrtoint ptr %mem1921 to i64
  store i64 %ptr1922, ptr %slot12, align 8
  %mem1923 = alloca i8, i64 8, align 8
  %ptr1924 = ptrtoint ptr %mem1923 to i64
  store i64 %ptr1924, ptr %slot13, align 8
  %mem1925 = alloca i8, i64 8, align 8
  %ptr1926 = ptrtoint ptr %mem1925 to i64
  store i64 %ptr1926, ptr %slot14, align 8
  %mem1927 = alloca i8, i64 8, align 8
  %ptr1928 = ptrtoint ptr %mem1927 to i64
  store i64 %ptr1928, ptr %slot15, align 8
  %mem1929 = alloca i8, i64 8, align 8
  %ptr1930 = ptrtoint ptr %mem1929 to i64
  store i64 %ptr1930, ptr %slot16, align 8
  %mem1931 = alloca i8, i64 8, align 8
  %ptr1932 = ptrtoint ptr %mem1931 to i64
  store i64 %ptr1932, ptr %slot17, align 8
  %mem1933 = alloca i8, i64 8, align 8
  %ptr1934 = ptrtoint ptr %mem1933 to i64
  store i64 %ptr1934, ptr %slot18, align 8
  %mem1935 = alloca i8, i64 8, align 8
  %ptr1936 = ptrtoint ptr %mem1935 to i64
  store i64 %ptr1936, ptr %slot19, align 8
  %mem1937 = alloca i8, i64 8, align 8
  %ptr1938 = ptrtoint ptr %mem1937 to i64
  store i64 %ptr1938, ptr %slot20, align 8
  %mem1939 = alloca i8, i64 8, align 8
  %ptr1940 = ptrtoint ptr %mem1939 to i64
  store i64 %ptr1940, ptr %slot21, align 8
  %mem1941 = alloca i8, i64 8, align 8
  %ptr1942 = ptrtoint ptr %mem1941 to i64
  store i64 %ptr1942, ptr %slot22, align 8
  %mem1943 = alloca i8, i64 8, align 8
  %ptr1944 = ptrtoint ptr %mem1943 to i64
  store i64 %ptr1944, ptr %slot23, align 8
  %mem1945 = alloca i8, i64 8, align 8
  %ptr1946 = ptrtoint ptr %mem1945 to i64
  store i64 %ptr1946, ptr %slot24, align 8
  %mem1947 = alloca i8, i64 8, align 8
  %ptr1948 = ptrtoint ptr %mem1947 to i64
  store i64 %ptr1948, ptr %slot25, align 8
  %mem1949 = alloca i8, i64 8, align 8
  %ptr1950 = ptrtoint ptr %mem1949 to i64
  store i64 %ptr1950, ptr %slot26, align 8
  %mem1951 = alloca i8, i64 8, align 8
  %ptr1952 = ptrtoint ptr %mem1951 to i64
  store i64 %ptr1952, ptr %slot27, align 8
  %mem1953 = alloca i8, i64 8, align 8
  %ptr1954 = ptrtoint ptr %mem1953 to i64
  store i64 %ptr1954, ptr %slot28, align 8
  %mem1955 = alloca i8, i64 8, align 8
  %ptr1956 = ptrtoint ptr %mem1955 to i64
  store i64 %ptr1956, ptr %slot29, align 8
  %mem1957 = alloca i8, i64 304, align 8
  %ptr1958 = ptrtoint ptr %mem1957 to i64
  store i64 %ptr1958, ptr %slot30, align 8
  %mem1959 = alloca i8, i64 8, align 8
  %ptr1960 = ptrtoint ptr %mem1959 to i64
  store i64 %ptr1960, ptr %slot31, align 8
  %mem1961 = alloca i8, i64 304, align 8
  %ptr1962 = ptrtoint ptr %mem1961 to i64
  store i64 %ptr1962, ptr %slot32, align 8
  %mem1963 = alloca i8, i64 32, align 8
  %ptr1964 = ptrtoint ptr %mem1963 to i64
  store i64 %ptr1964, ptr %slot33, align 8
  %v1965 = load i64, ptr %slot33, align 8
  %p1967 = inttoptr i64 %v1965 to ptr
  %gep1968 = getelementptr i8, ptr %p1967, i64 24
  %op1966 = ptrtoint ptr %gep1968 to i64
  store i64 %op1966, ptr %slot34, align 8
  %v1969 = load i64, ptr %slot34, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  store i64 0, ptr %p1970, align 8, !alias.scope !3, !noalias !4
  %mem1971 = alloca i8, i64 8, align 8
  %ptr1972 = ptrtoint ptr %mem1971 to i64
  store i64 %ptr1972, ptr %slot35, align 8
  %mem1973 = alloca i8, i64 8, align 8
  %ptr1974 = ptrtoint ptr %mem1973 to i64
  store i64 %ptr1974, ptr %slot36, align 8
  %mem1975 = alloca i8, i64 8, align 8
  %ptr1976 = ptrtoint ptr %mem1975 to i64
  store i64 %ptr1976, ptr %slot37, align 8
  %mem1977 = alloca i8, i64 32, align 8
  %ptr1978 = ptrtoint ptr %mem1977 to i64
  store i64 %ptr1978, ptr %slot38, align 8
  %mem1979 = alloca i8, i64 8, align 8
  %ptr1980 = ptrtoint ptr %mem1979 to i64
  store i64 %ptr1980, ptr %slot39, align 8
  %mem1981 = alloca i8, i64 24, align 8
  %ptr1982 = ptrtoint ptr %mem1981 to i64
  store i64 %ptr1982, ptr %slot40, align 8
  %mem1983 = alloca i8, i64 16, align 8
  %ptr1984 = ptrtoint ptr %mem1983 to i64
  store i64 %ptr1984, ptr %slot41, align 8
  %mem1985 = alloca i8, i64 8, align 8
  %ptr1986 = ptrtoint ptr %mem1985 to i64
  store i64 %ptr1986, ptr %slot42, align 8
  %mem1987 = alloca i8, i64 24, align 8
  %ptr1988 = ptrtoint ptr %mem1987 to i64
  store i64 %ptr1988, ptr %slot43, align 8
  %mem1989 = alloca i8, i64 24, align 8
  %ptr1990 = ptrtoint ptr %mem1989 to i64
  store i64 %ptr1990, ptr %slot44, align 8
  %mem1991 = alloca i8, i64 16, align 8
  %ptr1992 = ptrtoint ptr %mem1991 to i64
  store i64 %ptr1992, ptr %slot45, align 8
  %mem1993 = alloca i8, i64 8, align 8
  %ptr1994 = ptrtoint ptr %mem1993 to i64
  store i64 %ptr1994, ptr %slot46, align 8
  %mem1995 = alloca i8, i64 56, align 8
  %ptr1996 = ptrtoint ptr %mem1995 to i64
  store i64 %ptr1996, ptr %slot47, align 8
  %mem1997 = alloca i8, i64 8, align 8
  %ptr1998 = ptrtoint ptr %mem1997 to i64
  store i64 %ptr1998, ptr %slot48, align 8
  %mem1999 = alloca i8, i64 208, align 8
  %ptr2000 = ptrtoint ptr %mem1999 to i64
  store i64 %ptr2000, ptr %slot49, align 8
  %mem2001 = alloca i8, i64 16, align 8
  %ptr2002 = ptrtoint ptr %mem2001 to i64
  store i64 %ptr2002, ptr %slot50, align 8
  %mem2003 = alloca i8, i64 208, align 8
  %ptr2004 = ptrtoint ptr %mem2003 to i64
  store i64 %ptr2004, ptr %slot51, align 8
  %mem2005 = alloca i8, i64 8, align 8
  %ptr2006 = ptrtoint ptr %mem2005 to i64
  store i64 %ptr2006, ptr %slot52, align 8
  %mem2007 = alloca i8, i64 8, align 8
  %ptr2008 = ptrtoint ptr %mem2007 to i64
  store i64 %ptr2008, ptr %slot53, align 8
  %mem2009 = alloca i8, i64 8, align 8
  %ptr2010 = ptrtoint ptr %mem2009 to i64
  store i64 %ptr2010, ptr %slot54, align 8
  %mem2011 = alloca i8, i64 8, align 8
  %ptr2012 = ptrtoint ptr %mem2011 to i64
  store i64 %ptr2012, ptr %slot55, align 8
  %mem2013 = alloca i8, i64 8, align 8
  %ptr2014 = ptrtoint ptr %mem2013 to i64
  store i64 %ptr2014, ptr %slot56, align 8
  %mem2015 = alloca i8, i64 24, align 8
  %ptr2016 = ptrtoint ptr %mem2015 to i64
  store i64 %ptr2016, ptr %slot57, align 8
  %mem2017 = alloca i8, i64 24, align 8
  %ptr2018 = ptrtoint ptr %mem2017 to i64
  store i64 %ptr2018, ptr %slot58, align 8
  %mem2019 = alloca i8, i64 24, align 8
  %ptr2020 = ptrtoint ptr %mem2019 to i64
  store i64 %ptr2020, ptr %slot59, align 8
  %mem2021 = alloca i8, i64 24, align 8
  %ptr2022 = ptrtoint ptr %mem2021 to i64
  store i64 %ptr2022, ptr %slot60, align 8
  %mem2023 = alloca i8, i64 24, align 8
  %ptr2024 = ptrtoint ptr %mem2023 to i64
  store i64 %ptr2024, ptr %slot61, align 8
  %mem2025 = alloca i8, i64 24, align 8
  %ptr2026 = ptrtoint ptr %mem2025 to i64
  store i64 %ptr2026, ptr %slot62, align 8
  %mem2027 = alloca i8, i64 56, align 8
  %ptr2028 = ptrtoint ptr %mem2027 to i64
  store i64 %ptr2028, ptr %slot63, align 8
  %mem2029 = alloca i8, i64 56, align 8
  %ptr2030 = ptrtoint ptr %mem2029 to i64
  store i64 %ptr2030, ptr %slot64, align 8
  %mem2031 = alloca i8, i64 304, align 8
  %ptr2032 = ptrtoint ptr %mem2031 to i64
  store i64 %ptr2032, ptr %slot65, align 8
  %mem2033 = alloca i8, i64 304, align 8
  %ptr2034 = ptrtoint ptr %mem2033 to i64
  store i64 %ptr2034, ptr %slot66, align 8
  %mem2035 = alloca i8, i64 24, align 8
  %ptr2036 = ptrtoint ptr %mem2035 to i64
  store i64 %ptr2036, ptr %slot67, align 8
  %mem2037 = alloca i8, i64 24, align 8
  %ptr2038 = ptrtoint ptr %mem2037 to i64
  store i64 %ptr2038, ptr %slot68, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem2039 = alloca i8, i64 8, align 8
  %ptr2040 = ptrtoint ptr %mem2039 to i64
  store i64 %ptr2040, ptr %slot69, align 8
  %v2041 = load i64, ptr %slot1, align 8
  %op2042 = add i64 %v2041, 64
  store i64 %op2042, ptr %slot70, align 8
  %v2043 = load i64, ptr %slot70, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %ld2045 = load i64, ptr %p2044, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2045, ptr %slot71, align 8
  %stack2046 = call ptr @llvm.stacksave()
  %stackaddr2047 = ptrtoint ptr %stack2046 to i64
  %v2048 = load i64, ptr %slot71, align 8
  %cmp2049 = icmp ult i64 %stackaddr2047, %v2048
  %cv2050 = zext i1 %cmp2049 to i64
  store i64 %cv2050, ptr %slot72, align 8
  %v2051 = load i64, ptr %slot72, align 8
  %cond2052 = icmp ne i64 %v2051, 0
  br i1 %cond2052, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v2053 = load i64, ptr %slot1, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  call void @myl_qbe_fail_frame(ptr %p2054) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v2055 = load i64, ptr %slot46, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 0, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot2, align 8
  %v2058 = load i64, ptr %slot36, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i64 %v2057, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  %v2060 = load i64, ptr %slot3, align 8
  %v2061 = load i64, ptr %slot37, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i64 %v2060, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot1, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %call2065 = call ptr @myl_qbe_heap(ptr %p2064) nomerge, !dbg !112
  %calladdr2066 = ptrtoint ptr %call2065 to i64
  store i64 %calladdr2066, ptr %slot73, align 8
  %v2067 = load i64, ptr %slot1, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %call2069 = call i64 @myl_qbe_region_mark(ptr %p2068) nomerge, !dbg !112
  store i64 %call2069, ptr %slot74, align 8
  %v2070 = load i64, ptr %slot6, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i32 0, ptr %p2071, align 4, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot7, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i32 0, ptr %p2073, align 4, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot8, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i32 0, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot9, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i32 0, ptr %p2077, align 4, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot10, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i32 0, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot11, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  store i32 0, ptr %p2081, align 4, !alias.scope !3, !noalias !4
  %v2082 = load i64, ptr %slot12, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i32 0, ptr %p2083, align 4, !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot13, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i32 0, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot14, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 0, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot15, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  store i32 0, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  %v2090 = load i64, ptr %slot16, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i32 0, ptr %p2091, align 4, !alias.scope !3, !noalias !4
  %v2092 = load i64, ptr %slot17, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  store i32 0, ptr %p2093, align 4, !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot18, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 0, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot19, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 0, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot20, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  store i32 0, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  %v2100 = load i64, ptr %slot21, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  store i32 0, ptr %p2101, align 4, !alias.scope !3, !noalias !4
  %v2102 = load i64, ptr %slot22, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i32 0, ptr %p2103, align 4, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot23, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 0, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot24, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 0, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot25, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i32 0, ptr %p2109, align 4, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot26, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  store i32 0, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  %v2112 = load i64, ptr %slot27, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i32 0, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot28, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  store i32 0, ptr %p2115, align 4, !alias.scope !3, !noalias !4
  %v2116 = load i64, ptr %slot29, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  store i32 0, ptr %p2117, align 4, !alias.scope !3, !noalias !4
  %v2118 = load i64, ptr %slot7, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i32 2, ptr %p2119, align 4, !alias.scope !3, !noalias !4
  %v2120 = load i64, ptr %slot9, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i32 2, ptr %p2121, align 4, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot11, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  store i32 2, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  %v2124 = load i64, ptr %slot13, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  store i32 2, ptr %p2125, align 4, !alias.scope !3, !noalias !4
  %v2126 = load i64, ptr %slot15, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  store i32 2, ptr %p2127, align 4, !alias.scope !3, !noalias !4
  %v2128 = load i64, ptr %slot17, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i32 2, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot19, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i32 2, ptr %p2131, align 4, !alias.scope !3, !noalias !4
  %v2132 = load i64, ptr %slot21, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  store i32 2, ptr %p2133, align 4, !alias.scope !3, !noalias !4
  %v2134 = load i64, ptr %slot23, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i32 2, ptr %p2135, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v2136 = load i64, ptr %slot36, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %ld2138 = load i64, ptr %p2137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2138, ptr %slot75, align 8
  %v2139 = load i64, ptr %slot75, align 8
  %v2140 = load i64, ptr %slot52, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  store i64 %v2139, ptr %p2141, align 8, !alias.scope !3, !noalias !4
  %v2142 = load i64, ptr %slot37, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  %ld2144 = load i64, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2144, ptr %slot76, align 8
  %v2145 = load i64, ptr %slot76, align 8
  %v2146 = load i64, ptr %slot53, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  store i64 %v2145, ptr %p2147, align 8, !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot53, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  %ld2150 = load i64, ptr %p2149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2150, ptr %slot77, align 8
  %v2151 = load i64, ptr %slot77, align 8
  %op2152 = add i64 %v2151, 0
  store i64 %op2152, ptr %slot78, align 8
  %v2153 = load i64, ptr %slot78, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i64, ptr %p2154, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2155, ptr %slot79, align 8
  %v2156 = load i64, ptr %slot79, align 8
  %v2157 = load i64, ptr %slot53, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 %v2156, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot52, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %ld2161 = load i64, ptr %p2160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2161, ptr %slot80, align 8
  %v2162 = load i64, ptr %slot53, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  %ld2164 = load i64, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2164, ptr %slot81, align 8
  %v2165 = load i64, ptr %slot1, align 8
  %v2166 = load i64, ptr %slot80, align 8
  %v2167 = load i64, ptr %slot81, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult83, i64 %v2165, i64 %v2166, i64 %v2167) nomerge, !dbg !114
  %addr2168 = ptrtoint ptr %callresult83 to i64
  store i64 %addr2168, ptr %slot82, align 8
  %v2169 = load i64, ptr %slot82, align 8
  %v2170 = load i64, ptr %slot52, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  store i64 %v2169, ptr %p2171, align 8, !alias.scope !3, !noalias !4
  %v2172 = load i64, ptr %slot52, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  %ld2174 = load i64, ptr %p2173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2174, ptr %slot84, align 8
  %v2175 = load i64, ptr %slot32, align 8
  store i64 %v2175, ptr %slot85, align 8
  %v2176 = load i64, ptr %slot84, align 8
  %v2177 = load i64, ptr %slot85, align 8
  %p2178 = inttoptr i64 %v2176 to ptr
  %p2179 = inttoptr i64 %v2177 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2179, ptr %p2178, i64 24, i1 false)
  %v2180 = load i64, ptr %slot28, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 2, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot27, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 1, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot24, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  %ld2186 = load i32, ptr %p2185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2186, ptr %slot86, align 8
  %v2187 = load i32, ptr %slot86, align 8
  %cv2188 = zext i32 %v2187 to i64
  %cond2189 = icmp ne i64 %cv2188, 0
  br i1 %cond2189, label %bb_rcslotdrop47, label %bb_rcslotdone47
bb_rcslotdrop47:
  %v2190 = load i64, ptr %slot24, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i32 0, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot30, align 8
  store i64 %v2192, ptr %slot87, align 8
  %v2193 = load i64, ptr %slot25, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %ld2195 = load i32, ptr %p2194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2195, ptr %slot88, align 8
  %v2196 = load i32, ptr %slot88, align 8
  %op2197 = and i32 %v2196, 28
  store i32 %op2197, ptr %slot89, align 8
  %v2198 = load i32, ptr %slot89, align 8
  %cv2199 = zext i32 %v2198 to i64
  %cond2200 = icmp ne i64 %cv2199, 0
  br i1 %cond2200, label %bb_rcslotrole47, label %bb_rcslotowner47
bb_rcslotrole47:
  %v2201 = load i64, ptr %slot73, align 8
  store i64 %v2201, ptr %slot90, align 8
  %v2202 = load i64, ptr %slot90, align 8
  %v2203 = load i64, ptr %slot87, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2202, i64 %v2203) nomerge, !dbg !114
  br label %bb_rcslotdone47
bb_rcslotowner47:
  %v2204 = load i64, ptr %slot73, align 8
  store i64 %v2204, ptr %slot91, align 8
  %v2205 = load i64, ptr %slot91, align 8
  %v2206 = load i64, ptr %slot87, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2205, i64 %v2206) nomerge, !dbg !114
  br label %bb_rcslotdone47
bb_rcslotdone47:
  %v2207 = load i64, ptr %slot30, align 8
  store i64 %v2207, ptr %slot92, align 8
  %v2208 = load i64, ptr %slot32, align 8
  store i64 %v2208, ptr %slot93, align 8
  %v2209 = load i64, ptr %slot93, align 8
  %v2210 = load i64, ptr %slot92, align 8
  %p2211 = inttoptr i64 %v2209 to ptr
  %p2212 = inttoptr i64 %v2210 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2212, ptr %p2211, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2213 = load i64, ptr %slot25, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  store i32 2, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  %v2215 = load i64, ptr %slot28, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  %ld2217 = load i32, ptr %p2216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2217, ptr %slot94, align 8
  %v2218 = load i32, ptr %slot94, align 8
  %v2219 = load i64, ptr %slot25, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  store i32 %v2218, ptr %p2220, align 4, !alias.scope !3, !noalias !4
  %v2221 = load i64, ptr %slot27, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  store i32 0, ptr %p2222, align 4, !alias.scope !3, !noalias !4
  %v2223 = load i64, ptr %slot24, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  store i32 1, ptr %p2224, align 4, !alias.scope !3, !noalias !4
  %v2225 = load i64, ptr %slot92, align 8
  %v2226 = load i64, ptr %slot52, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  store i64 %v2225, ptr %p2227, align 8, !alias.scope !3, !noalias !4
  %v2228 = load i64, ptr %slot52, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  %ld2230 = load i64, ptr %p2229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2230, ptr %slot95, align 8
  %v2231 = load i64, ptr %slot95, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %ld2233 = load i32, ptr %p2232, align 4
  %ext2234 = zext i32 %ld2233 to i64
  store i64 %ext2234, ptr %slot96, align 8
  %v2235 = load i64, ptr %slot96, align 8
  %cmp2236 = icmp eq i64 %v2235, 0
  %cv2237 = zext i1 %cmp2236 to i64
  store i64 %cv2237, ptr %slot97, align 8
  %v2238 = load i64, ptr %slot97, align 8
  %cond2239 = icmp ne i64 %v2238, 0
  br i1 %cond2239, label %bb_rctryok63, label %bb_rctryerror63
bb_rctryerror63:
  %p2240 = inttoptr i64 ptrtoint (ptr @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2240, i64 12884901892) "call-inline-cost"="0", !dbg !116
  %v2241 = load i64, ptr %slot95, align 8
  %op2242 = add i64 %v2241, 8
  store i64 %op2242, ptr %slot98, align 8
  %v2243 = load i64, ptr %slot57, align 8
  store i64 %v2243, ptr %slot99, align 8
  %v2244 = load i64, ptr %slot99, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  store i64 0, ptr %p2245, align 8, !alias.scope !3, !noalias !4
  %v2246 = load i64, ptr %slot99, align 8
  %p2248 = inttoptr i64 %v2246 to ptr
  %gep2249 = getelementptr i8, ptr %p2248, i64 8
  %op2247 = ptrtoint ptr %gep2249 to i64
  store i64 %op2247, ptr %slot100, align 8
  %v2250 = load i64, ptr %slot100, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i64 0, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot99, align 8
  %p2254 = inttoptr i64 %v2252 to ptr
  %gep2255 = getelementptr i8, ptr %p2254, i64 16
  %op2253 = ptrtoint ptr %gep2255 to i64
  store i64 %op2253, ptr %slot101, align 8
  %v2256 = load i64, ptr %slot101, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i64 0, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot99, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  store i32 1, ptr %p2259, align 4, !alias.scope !3, !noalias !4
  %v2260 = load i64, ptr %slot99, align 8
  %p2262 = inttoptr i64 %v2260 to ptr
  %gep2263 = getelementptr i8, ptr %p2262, i64 8
  %op2261 = ptrtoint ptr %gep2263 to i64
  store i64 %op2261, ptr %slot102, align 8
  %v2264 = load i64, ptr %slot29, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i32 1, ptr %p2265, align 4, !alias.scope !3, !noalias !4
  %v2266 = load i64, ptr %slot74, align 8
  store i64 %v2266, ptr %slot103, align 8
  %v2267 = load i64, ptr %slot73, align 8
  %v2268 = load i64, ptr %slot102, align 8
  %v2269 = load i64, ptr %slot98, align 8
  %v2270 = load i64, ptr %slot103, align 8
  %cv2271 = trunc i64 %v2270 to i32
  %call2272 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2267, i64 %v2268, i64 %v2269, i32 %cv2271) nomerge, !dbg !116
  store i32 %call2272, ptr %slot104, align 8
  %v2273 = load i32, ptr %slot104, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcsuccess74, label %bb_rcfailure74
bb_rcfailure74:
  %v2276 = load i64, ptr %slot73, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %call2278 = call i32 @myl_rc_take_failure(ptr %p2277) nomerge, !dbg !116
  store i32 %call2278, ptr %slot105, align 8
  %v2279 = load i64, ptr %slot1, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %v2281 = load i32, ptr %slot105, align 8
  %call2282 = call i32 @myl_qbe_rc_status(ptr %p2280, i32 %v2281) nomerge, !dbg !116
  store i32 %call2282, ptr %slot106, align 8
  br label %bb_failure
bb_rcsuccess74:
  %v2283 = load i64, ptr %slot99, align 8
  %v2284 = load i64, ptr %slot52, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i64 %v2283, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot52, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i64, ptr %p2287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2288, ptr %slot107, align 8
  %v2289 = load i64, ptr %slot32, align 8
  store i64 %v2289, ptr %slot108, align 8
  %v2290 = load i64, ptr %slot107, align 8
  %v2291 = load i64, ptr %slot108, align 8
  %p2292 = inttoptr i64 %v2290 to ptr
  %p2293 = inttoptr i64 %v2291 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2293, ptr %p2292, i64 24, i1 false)
  %v2294 = load i64, ptr %slot28, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i32 2, ptr %p2295, align 4, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot27, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i32 1, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  %v2298 = load i64, ptr %slot24, align 8
  %p2299 = inttoptr i64 %v2298 to ptr
  %ld2300 = load i32, ptr %p2299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2300, ptr %slot109, align 8
  %v2301 = load i32, ptr %slot109, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v2304 = load i64, ptr %slot24, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  store i32 0, ptr %p2305, align 4, !alias.scope !3, !noalias !4
  %v2306 = load i64, ptr %slot30, align 8
  store i64 %v2306, ptr %slot110, align 8
  %v2307 = load i64, ptr %slot25, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %ld2309 = load i32, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2309, ptr %slot111, align 8
  %v2310 = load i32, ptr %slot111, align 8
  %op2311 = and i32 %v2310, 28
  store i32 %op2311, ptr %slot112, align 8
  %v2312 = load i32, ptr %slot112, align 8
  %cv2313 = zext i32 %v2312 to i64
  %cond2314 = icmp ne i64 %cv2313, 0
  br i1 %cond2314, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v2315 = load i64, ptr %slot73, align 8
  store i64 %v2315, ptr %slot113, align 8
  %v2316 = load i64, ptr %slot113, align 8
  %v2317 = load i64, ptr %slot110, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2316, i64 %v2317) nomerge, !dbg !116
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v2318 = load i64, ptr %slot73, align 8
  store i64 %v2318, ptr %slot114, align 8
  %v2319 = load i64, ptr %slot114, align 8
  %v2320 = load i64, ptr %slot110, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2319, i64 %v2320) nomerge, !dbg !116
  br label %bb_rcslotdone83
bb_rcslotdone83:
  %v2321 = load i64, ptr %slot30, align 8
  store i64 %v2321, ptr %slot115, align 8
  %v2322 = load i64, ptr %slot32, align 8
  store i64 %v2322, ptr %slot116, align 8
  %v2323 = load i64, ptr %slot116, align 8
  %v2324 = load i64, ptr %slot115, align 8
  %p2325 = inttoptr i64 %v2323 to ptr
  %p2326 = inttoptr i64 %v2324 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2326, ptr %p2325, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2327 = load i64, ptr %slot25, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i32 2, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot28, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  %ld2331 = load i32, ptr %p2330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2331, ptr %slot117, align 8
  %v2332 = load i32, ptr %slot117, align 8
  %v2333 = load i64, ptr %slot25, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i32 %v2332, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot27, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i32 0, ptr %p2336, align 4, !alias.scope !3, !noalias !4
  %v2337 = load i64, ptr %slot24, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  store i32 1, ptr %p2338, align 4, !alias.scope !3, !noalias !4
  %v2339 = load i64, ptr %slot115, align 8
  %v2340 = load i64, ptr %slot52, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  store i64 %v2339, ptr %p2341, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_rctryok63:
  %v2342 = load i64, ptr %slot57, align 8
  store i64 %v2342, ptr %slot118, align 8
  %v2343 = load i64, ptr %slot29, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  store i32 1, ptr %p2344, align 4, !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot95, align 8
  %op2346 = add i64 %v2345, 8
  store i64 %op2346, ptr %slot119, align 8
  %v2347 = load i64, ptr %slot74, align 8
  store i64 %v2347, ptr %slot120, align 8
  store i64 0, ptr %slot121, align 8
  store i64 0, ptr %slot122, align 8
  %v2348 = load i64, ptr %slot122, align 8
  %v2349 = load i64, ptr %slot52, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot24, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i32, ptr %p2352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2353, ptr %slot123, align 8
  %v2354 = load i32, ptr %slot123, align 8
  %cv2355 = zext i32 %v2354 to i64
  %cond2356 = icmp ne i64 %cv2355, 0
  br i1 %cond2356, label %bb_rcslotdrop107, label %bb_rcslotdone107
bb_rcslotdrop107:
  %v2357 = load i64, ptr %slot24, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i32 0, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot30, align 8
  store i64 %v2359, ptr %slot124, align 8
  %v2360 = load i64, ptr %slot25, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i32, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2362, ptr %slot125, align 8
  %v2363 = load i32, ptr %slot125, align 8
  %op2364 = and i32 %v2363, 28
  store i32 %op2364, ptr %slot126, align 8
  %v2365 = load i32, ptr %slot126, align 8
  %cv2366 = zext i32 %v2365 to i64
  %cond2367 = icmp ne i64 %cv2366, 0
  br i1 %cond2367, label %bb_rcslotrole107, label %bb_rcslotowner107
bb_rcslotrole107:
  %v2368 = load i64, ptr %slot73, align 8
  store i64 %v2368, ptr %slot127, align 8
  %v2369 = load i64, ptr %slot127, align 8
  %v2370 = load i64, ptr %slot124, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2369, i64 %v2370) nomerge, !dbg !116
  br label %bb_rcslotdone107
bb_rcslotowner107:
  %v2371 = load i64, ptr %slot73, align 8
  store i64 %v2371, ptr %slot128, align 8
  %v2372 = load i64, ptr %slot128, align 8
  %v2373 = load i64, ptr %slot124, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2372, i64 %v2373) nomerge, !dbg !116
  br label %bb_rcslotdone107
bb_rcslotdone107:
  br label %bb_i7
bb_i6:
  %v2374 = load i64, ptr %slot52, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %ld2376 = load i64, ptr %p2375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2376, ptr %slot129, align 8
  %v2377 = load i64, ptr %slot52, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  %ld2379 = load i64, ptr %p2378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2379, ptr %slot130, align 8
  %v2380 = load i64, ptr %slot24, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i32, ptr %p2381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2382, ptr %slot131, align 8
  %v2383 = load i64, ptr %slot25, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i32, ptr %p2384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2385, ptr %slot132, align 8
  %v2386 = load i32, ptr %slot132, align 8
  %op2387 = and i32 %v2386, 24
  store i32 %op2387, ptr %slot132, align 8
  %v2388 = load i32, ptr %slot132, align 8
  %cmp2389 = icmp eq i32 %v2388, 0
  %cv2390 = zext i1 %cmp2389 to i32
  store i32 %cv2390, ptr %slot133, align 8
  %v2391 = load i32, ptr %slot131, align 8
  %v2392 = load i32, ptr %slot133, align 8
  %op2393 = and i32 %v2391, %v2392
  store i32 %op2393, ptr %slot134, align 8
  %v2394 = load i32, ptr %slot134, align 8
  %cv2395 = zext i32 %v2394 to i64
  %cond2396 = icmp ne i64 %cv2395, 0
  br i1 %cond2396, label %bb_rctake116, label %bb_rccopy116
bb_rctake116:
  %v2397 = load i64, ptr %slot32, align 8
  store i64 %v2397, ptr %slot135, align 8
  %v2398 = load i64, ptr %slot74, align 8
  store i64 %v2398, ptr %slot136, align 8
  %v2399 = load i64, ptr %slot73, align 8
  %v2400 = load i64, ptr %slot135, align 8
  %v2401 = load i64, ptr %slot130, align 8
  %v2402 = load i64, ptr %slot136, align 8
  %cv2403 = trunc i64 %v2402 to i32
  %call2404 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2399, i64 %v2400, i64 %v2401, i32 %cv2403) nomerge, !dbg !118
  store i32 %call2404, ptr %slot137, align 8
  %v2405 = load i32, ptr %slot137, align 8
  %cv2406 = zext i32 %v2405 to i64
  %cond2407 = icmp ne i64 %cv2406, 0
  br i1 %cond2407, label %bb_rcsuccess126, label %bb_rcfailure126
bb_rcfailure126:
  %v2408 = load i64, ptr %slot73, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %call2410 = call i32 @myl_rc_take_failure(ptr %p2409) nomerge, !dbg !118
  store i32 %call2410, ptr %slot138, align 8
  %v2411 = load i64, ptr %slot1, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %v2413 = load i32, ptr %slot138, align 8
  %call2414 = call i32 @myl_qbe_rc_status(ptr %p2412, i32 %v2413) nomerge, !dbg !118
  store i32 %call2414, ptr %slot139, align 8
  br label %bb_failure
bb_rcsuccess126:
  %v2415 = load i64, ptr %slot24, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  store i32 0, ptr %p2416, align 4, !alias.scope !3, !noalias !4
  %v2417 = load i64, ptr %slot28, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  store i32 2, ptr %p2418, align 4, !alias.scope !3, !noalias !4
  %v2419 = load i64, ptr %slot27, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i32 1, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared116
bb_rccopy116:
  %v2421 = load i64, ptr %slot32, align 8
  store i64 %v2421, ptr %slot140, align 8
  %v2422 = load i64, ptr %slot74, align 8
  store i64 %v2422, ptr %slot141, align 8
  %v2423 = load i64, ptr %slot73, align 8
  %v2424 = load i64, ptr %slot140, align 8
  %v2425 = load i64, ptr %slot130, align 8
  %v2426 = load i64, ptr %slot141, align 8
  %cv2427 = trunc i64 %v2426 to i32
  %call2428 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v2423, i64 %v2424, i64 %v2425, i32 %cv2427) nomerge, !dbg !118
  store i32 %call2428, ptr %slot142, align 8
  %v2429 = load i32, ptr %slot142, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcsuccess135, label %bb_rcfailure135
bb_rcfailure135:
  %v2432 = load i64, ptr %slot73, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  %call2434 = call i32 @myl_rc_take_failure(ptr %p2433) nomerge, !dbg !118
  store i32 %call2434, ptr %slot143, align 8
  %v2435 = load i64, ptr %slot1, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %v2437 = load i32, ptr %slot143, align 8
  %call2438 = call i32 @myl_qbe_rc_status(ptr %p2436, i32 %v2437) nomerge, !dbg !118
  store i32 %call2438, ptr %slot144, align 8
  br label %bb_failure
bb_rcsuccess135:
  %v2439 = load i64, ptr %slot28, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  store i32 2, ptr %p2440, align 4, !alias.scope !3, !noalias !4
  %v2441 = load i64, ptr %slot27, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 1, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot24, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %ld2445 = load i32, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2445, ptr %slot145, align 8
  %v2446 = load i32, ptr %slot145, align 8
  %cv2447 = zext i32 %v2446 to i64
  %cond2448 = icmp ne i64 %cv2447, 0
  br i1 %cond2448, label %bb_rcslotdrop142, label %bb_rcslotdone142
bb_rcslotdrop142:
  %v2449 = load i64, ptr %slot24, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i32 0, ptr %p2450, align 4, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot30, align 8
  store i64 %v2451, ptr %slot146, align 8
  %v2452 = load i64, ptr %slot25, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %ld2454 = load i32, ptr %p2453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2454, ptr %slot147, align 8
  %v2455 = load i32, ptr %slot147, align 8
  %op2456 = and i32 %v2455, 28
  store i32 %op2456, ptr %slot148, align 8
  %v2457 = load i32, ptr %slot148, align 8
  %cv2458 = zext i32 %v2457 to i64
  %cond2459 = icmp ne i64 %cv2458, 0
  br i1 %cond2459, label %bb_rcslotrole142, label %bb_rcslotowner142
bb_rcslotrole142:
  %v2460 = load i64, ptr %slot73, align 8
  store i64 %v2460, ptr %slot149, align 8
  %v2461 = load i64, ptr %slot149, align 8
  %v2462 = load i64, ptr %slot146, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2461, i64 %v2462) nomerge, !dbg !118
  br label %bb_rcslotdone142
bb_rcslotowner142:
  %v2463 = load i64, ptr %slot73, align 8
  store i64 %v2463, ptr %slot150, align 8
  %v2464 = load i64, ptr %slot150, align 8
  %v2465 = load i64, ptr %slot146, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2464, i64 %v2465) nomerge, !dbg !118
  br label %bb_rcslotdone142
bb_rcslotdone142:
  br label %bb_rcprepared116
bb_rcprepared116:
  %v2466 = load i64, ptr %slot32, align 8
  store i64 %v2466, ptr %slot151, align 8
  %v2467 = load i64, ptr %slot27, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  store i32 0, ptr %p2468, align 4, !alias.scope !3, !noalias !4
  %v2469 = load i64, ptr %slot33, align 8
  %p2471 = inttoptr i64 %v2469 to ptr
  %gep2472 = getelementptr i8, ptr %p2471, i64 24
  %op2470 = ptrtoint ptr %gep2472 to i64
  store i64 %op2470, ptr %slot152, align 8
  %v2473 = load i64, ptr %slot152, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %ld2475 = load i32, ptr %p2474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2475, ptr %slot153, align 8
  %v2476 = load i32, ptr %slot153, align 8
  %cv2477 = zext i32 %v2476 to i64
  %cond2478 = icmp ne i64 %cv2477, 0
  br i1 %cond2478, label %bb_rcscopesopen153, label %bb_rcscopesclosed153
bb_rcscopesopen153:
  %v2479 = load i64, ptr %slot35, align 8
  %p2481 = inttoptr i64 %v2479 to ptr
  %gep2482 = getelementptr i8, ptr %p2481, i64 0
  %op2480 = ptrtoint ptr %gep2482 to i64
  store i64 %op2480, ptr %slot154, align 8
  %v2483 = load i64, ptr %slot33, align 8
  %v2484 = load i64, ptr %slot154, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i64 %v2483, ptr %p2485, align 8, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot1, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %v2488 = load i64, ptr %slot35, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2487, ptr %p2489, i64 1) nomerge, !dbg !118
  br label %bb_rcscopesclosed153
bb_rcscopesclosed153:
  %v2490 = load i64, ptr %slot24, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %ld2492 = load i32, ptr %p2491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2492, ptr %slot155, align 8
  %v2493 = load i32, ptr %slot155, align 8
  %cv2494 = zext i32 %v2493 to i64
  %cond2495 = icmp ne i64 %cv2494, 0
  br i1 %cond2495, label %bb_rcslotdrop157, label %bb_rcslotdone157
bb_rcslotdrop157:
  %v2496 = load i64, ptr %slot24, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i32 0, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  %v2498 = load i64, ptr %slot30, align 8
  store i64 %v2498, ptr %slot156, align 8
  %v2499 = load i64, ptr %slot25, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i32, ptr %p2500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2501, ptr %slot157, align 8
  %v2502 = load i32, ptr %slot157, align 8
  %op2503 = and i32 %v2502, 28
  store i32 %op2503, ptr %slot158, align 8
  %v2504 = load i32, ptr %slot158, align 8
  %cv2505 = zext i32 %v2504 to i64
  %cond2506 = icmp ne i64 %cv2505, 0
  br i1 %cond2506, label %bb_rcslotrole157, label %bb_rcslotowner157
bb_rcslotrole157:
  %v2507 = load i64, ptr %slot73, align 8
  store i64 %v2507, ptr %slot159, align 8
  %v2508 = load i64, ptr %slot159, align 8
  %v2509 = load i64, ptr %slot156, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2508, i64 %v2509) nomerge, !dbg !118
  br label %bb_rcslotdone157
bb_rcslotowner157:
  %v2510 = load i64, ptr %slot73, align 8
  store i64 %v2510, ptr %slot160, align 8
  %v2511 = load i64, ptr %slot160, align 8
  %v2512 = load i64, ptr %slot156, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2511, i64 %v2512) nomerge, !dbg !118
  br label %bb_rcslotdone157
bb_rcslotdone157:
  %v2513 = load i64, ptr %slot22, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %ld2515 = load i32, ptr %p2514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2515, ptr %slot161, align 8
  %v2516 = load i32, ptr %slot161, align 8
  %cv2517 = zext i32 %v2516 to i64
  %cond2518 = icmp ne i64 %cv2517, 0
  br i1 %cond2518, label %bb_rcslotdrop184, label %bb_rcslotdone184
bb_rcslotdrop184:
  %v2519 = load i64, ptr %slot22, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 0, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot51, align 8
  store i64 %v2521, ptr %slot162, align 8
  %v2522 = load i64, ptr %slot23, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  %ld2524 = load i32, ptr %p2523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2524, ptr %slot163, align 8
  %v2525 = load i32, ptr %slot163, align 8
  %op2526 = and i32 %v2525, 28
  store i32 %op2526, ptr %slot164, align 8
  %v2527 = load i32, ptr %slot164, align 8
  %cv2528 = zext i32 %v2527 to i64
  %cond2529 = icmp ne i64 %cv2528, 0
  br i1 %cond2529, label %bb_rcslotrole184, label %bb_rcslotowner184
bb_rcslotrole184:
  %v2530 = load i64, ptr %slot73, align 8
  store i64 %v2530, ptr %slot165, align 8
  %v2531 = load i64, ptr %slot165, align 8
  %v2532 = load i64, ptr %slot162, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2531, i64 %v2532) nomerge, !dbg !118
  br label %bb_rcslotdone184
bb_rcslotowner184:
  %v2533 = load i64, ptr %slot73, align 8
  store i64 %v2533, ptr %slot166, align 8
  %v2534 = load i64, ptr %slot166, align 8
  %v2535 = load i64, ptr %slot162, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2534, i64 %v2535) nomerge, !dbg !118
  br label %bb_rcslotdone184
bb_rcslotdone184:
  %v2536 = load i64, ptr %slot20, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %ld2538 = load i32, ptr %p2537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2538, ptr %slot167, align 8
  %v2539 = load i32, ptr %slot167, align 8
  %cv2540 = zext i32 %v2539 to i64
  %cond2541 = icmp ne i64 %cv2540, 0
  br i1 %cond2541, label %bb_rcslotdrop211, label %bb_rcslotdone211
bb_rcslotdrop211:
  %v2542 = load i64, ptr %slot20, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  store i32 0, ptr %p2543, align 4, !alias.scope !3, !noalias !4
  %v2544 = load i64, ptr %slot49, align 8
  store i64 %v2544, ptr %slot168, align 8
  %v2545 = load i64, ptr %slot21, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i32, ptr %p2546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2547, ptr %slot169, align 8
  %v2548 = load i32, ptr %slot169, align 8
  %op2549 = and i32 %v2548, 28
  store i32 %op2549, ptr %slot170, align 8
  %v2550 = load i32, ptr %slot170, align 8
  %cv2551 = zext i32 %v2550 to i64
  %cond2552 = icmp ne i64 %cv2551, 0
  br i1 %cond2552, label %bb_rcslotrole211, label %bb_rcslotowner211
bb_rcslotrole211:
  %v2553 = load i64, ptr %slot73, align 8
  store i64 %v2553, ptr %slot171, align 8
  %v2554 = load i64, ptr %slot171, align 8
  %v2555 = load i64, ptr %slot168, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2554, i64 %v2555) nomerge, !dbg !118
  br label %bb_rcslotdone211
bb_rcslotowner211:
  %v2556 = load i64, ptr %slot73, align 8
  store i64 %v2556, ptr %slot172, align 8
  %v2557 = load i64, ptr %slot172, align 8
  %v2558 = load i64, ptr %slot168, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2557, i64 %v2558) nomerge, !dbg !118
  br label %bb_rcslotdone211
bb_rcslotdone211:
  %v2559 = load i64, ptr %slot18, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %ld2561 = load i32, ptr %p2560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2561, ptr %slot173, align 8
  %v2562 = load i32, ptr %slot173, align 8
  %cv2563 = zext i32 %v2562 to i64
  %cond2564 = icmp ne i64 %cv2563, 0
  br i1 %cond2564, label %bb_rcslotdrop220, label %bb_rcslotdone220
bb_rcslotdrop220:
  %v2565 = load i64, ptr %slot18, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  store i32 0, ptr %p2566, align 4, !alias.scope !3, !noalias !4
  %v2567 = load i64, ptr %slot47, align 8
  store i64 %v2567, ptr %slot174, align 8
  %v2568 = load i64, ptr %slot19, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  %ld2570 = load i32, ptr %p2569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2570, ptr %slot175, align 8
  %v2571 = load i32, ptr %slot175, align 8
  %op2572 = and i32 %v2571, 28
  store i32 %op2572, ptr %slot176, align 8
  %v2573 = load i32, ptr %slot176, align 8
  %cv2574 = zext i32 %v2573 to i64
  %cond2575 = icmp ne i64 %cv2574, 0
  br i1 %cond2575, label %bb_rcslotrole220, label %bb_rcslotowner220
bb_rcslotrole220:
  %v2576 = load i64, ptr %slot73, align 8
  store i64 %v2576, ptr %slot177, align 8
  %v2577 = load i64, ptr %slot177, align 8
  %v2578 = load i64, ptr %slot174, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2577, i64 %v2578) nomerge, !dbg !118
  br label %bb_rcslotdone220
bb_rcslotowner220:
  %v2579 = load i64, ptr %slot73, align 8
  store i64 %v2579, ptr %slot178, align 8
  %v2580 = load i64, ptr %slot178, align 8
  %v2581 = load i64, ptr %slot174, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2580, i64 %v2581) nomerge, !dbg !118
  br label %bb_rcslotdone220
bb_rcslotdone220:
  %v2582 = load i64, ptr %slot16, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %ld2584 = load i32, ptr %p2583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2584, ptr %slot179, align 8
  %v2585 = load i32, ptr %slot179, align 8
  %cv2586 = zext i32 %v2585 to i64
  %cond2587 = icmp ne i64 %cv2586, 0
  br i1 %cond2587, label %bb_rcslotdrop266, label %bb_rcslotdone266
bb_rcslotdrop266:
  %v2588 = load i64, ptr %slot16, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  store i32 0, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  %v2590 = load i64, ptr %slot45, align 8
  store i64 %v2590, ptr %slot180, align 8
  %v2591 = load i64, ptr %slot17, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  %ld2593 = load i32, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2593, ptr %slot181, align 8
  %v2594 = load i32, ptr %slot181, align 8
  %op2595 = and i32 %v2594, 28
  store i32 %op2595, ptr %slot182, align 8
  %v2596 = load i32, ptr %slot182, align 8
  %cv2597 = zext i32 %v2596 to i64
  %cond2598 = icmp ne i64 %cv2597, 0
  br i1 %cond2598, label %bb_rcslotrole266, label %bb_rcslotowner266
bb_rcslotrole266:
  %v2599 = load i64, ptr %slot73, align 8
  store i64 %v2599, ptr %slot183, align 8
  %v2600 = load i64, ptr %slot183, align 8
  %v2601 = load i64, ptr %slot180, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2600, i64 %v2601) nomerge, !dbg !118
  br label %bb_rcslotdone266
bb_rcslotowner266:
  %v2602 = load i64, ptr %slot73, align 8
  store i64 %v2602, ptr %slot184, align 8
  %v2603 = load i64, ptr %slot184, align 8
  %v2604 = load i64, ptr %slot180, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2603, i64 %v2604) nomerge, !dbg !118
  br label %bb_rcslotdone266
bb_rcslotdone266:
  %v2605 = load i64, ptr %slot14, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  %ld2607 = load i32, ptr %p2606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2607, ptr %slot185, align 8
  %v2608 = load i32, ptr %slot185, align 8
  %cv2609 = zext i32 %v2608 to i64
  %cond2610 = icmp ne i64 %cv2609, 0
  br i1 %cond2610, label %bb_rcslotdrop275, label %bb_rcslotdone275
bb_rcslotdrop275:
  %v2611 = load i64, ptr %slot14, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  store i32 0, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  %v2613 = load i64, ptr %slot44, align 8
  store i64 %v2613, ptr %slot186, align 8
  %v2614 = load i64, ptr %slot15, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  %ld2616 = load i32, ptr %p2615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2616, ptr %slot187, align 8
  %v2617 = load i32, ptr %slot187, align 8
  %op2618 = and i32 %v2617, 28
  store i32 %op2618, ptr %slot188, align 8
  %v2619 = load i32, ptr %slot188, align 8
  %cv2620 = zext i32 %v2619 to i64
  %cond2621 = icmp ne i64 %cv2620, 0
  br i1 %cond2621, label %bb_rcslotrole275, label %bb_rcslotowner275
bb_rcslotrole275:
  %v2622 = load i64, ptr %slot73, align 8
  store i64 %v2622, ptr %slot189, align 8
  %v2623 = load i64, ptr %slot189, align 8
  %v2624 = load i64, ptr %slot186, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2623, i64 %v2624) nomerge, !dbg !118
  br label %bb_rcslotdone275
bb_rcslotowner275:
  %v2625 = load i64, ptr %slot73, align 8
  store i64 %v2625, ptr %slot190, align 8
  %v2626 = load i64, ptr %slot190, align 8
  %v2627 = load i64, ptr %slot186, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2626, i64 %v2627) nomerge, !dbg !118
  br label %bb_rcslotdone275
bb_rcslotdone275:
  %v2628 = load i64, ptr %slot12, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %ld2630 = load i32, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2630, ptr %slot191, align 8
  %v2631 = load i32, ptr %slot191, align 8
  %cv2632 = zext i32 %v2631 to i64
  %cond2633 = icmp ne i64 %cv2632, 0
  br i1 %cond2633, label %bb_rcslotdrop284, label %bb_rcslotdone284
bb_rcslotdrop284:
  %v2634 = load i64, ptr %slot12, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  store i32 0, ptr %p2635, align 4, !alias.scope !3, !noalias !4
  %v2636 = load i64, ptr %slot43, align 8
  store i64 %v2636, ptr %slot192, align 8
  %v2637 = load i64, ptr %slot13, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i32, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2639, ptr %slot193, align 8
  %v2640 = load i32, ptr %slot193, align 8
  %op2641 = and i32 %v2640, 28
  store i32 %op2641, ptr %slot194, align 8
  %v2642 = load i32, ptr %slot194, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcslotrole284, label %bb_rcslotowner284
bb_rcslotrole284:
  %v2645 = load i64, ptr %slot73, align 8
  store i64 %v2645, ptr %slot195, align 8
  %v2646 = load i64, ptr %slot195, align 8
  %v2647 = load i64, ptr %slot192, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2646, i64 %v2647) nomerge, !dbg !118
  br label %bb_rcslotdone284
bb_rcslotowner284:
  %v2648 = load i64, ptr %slot73, align 8
  store i64 %v2648, ptr %slot196, align 8
  %v2649 = load i64, ptr %slot196, align 8
  %v2650 = load i64, ptr %slot192, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2649, i64 %v2650) nomerge, !dbg !118
  br label %bb_rcslotdone284
bb_rcslotdone284:
  %v2651 = load i64, ptr %slot10, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  %ld2653 = load i32, ptr %p2652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2653, ptr %slot197, align 8
  %v2654 = load i32, ptr %slot197, align 8
  %cv2655 = zext i32 %v2654 to i64
  %cond2656 = icmp ne i64 %cv2655, 0
  br i1 %cond2656, label %bb_rcslotdrop293, label %bb_rcslotdone293
bb_rcslotdrop293:
  %v2657 = load i64, ptr %slot10, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  store i32 0, ptr %p2658, align 4, !alias.scope !3, !noalias !4
  %v2659 = load i64, ptr %slot41, align 8
  store i64 %v2659, ptr %slot198, align 8
  %v2660 = load i64, ptr %slot11, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  %ld2662 = load i32, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2662, ptr %slot199, align 8
  %v2663 = load i32, ptr %slot199, align 8
  %op2664 = and i32 %v2663, 28
  store i32 %op2664, ptr %slot200, align 8
  %v2665 = load i32, ptr %slot200, align 8
  %cv2666 = zext i32 %v2665 to i64
  %cond2667 = icmp ne i64 %cv2666, 0
  br i1 %cond2667, label %bb_rcslotrole293, label %bb_rcslotowner293
bb_rcslotrole293:
  %v2668 = load i64, ptr %slot73, align 8
  store i64 %v2668, ptr %slot201, align 8
  %v2669 = load i64, ptr %slot201, align 8
  %v2670 = load i64, ptr %slot198, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2669, i64 %v2670) nomerge, !dbg !118
  br label %bb_rcslotdone293
bb_rcslotowner293:
  %v2671 = load i64, ptr %slot73, align 8
  store i64 %v2671, ptr %slot202, align 8
  %v2672 = load i64, ptr %slot202, align 8
  %v2673 = load i64, ptr %slot198, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2672, i64 %v2673) nomerge, !dbg !118
  br label %bb_rcslotdone293
bb_rcslotdone293:
  %v2674 = load i64, ptr %slot8, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %ld2676 = load i32, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2676, ptr %slot203, align 8
  %v2677 = load i32, ptr %slot203, align 8
  %cv2678 = zext i32 %v2677 to i64
  %cond2679 = icmp ne i64 %cv2678, 0
  br i1 %cond2679, label %bb_rcslotdrop302, label %bb_rcslotdone302
bb_rcslotdrop302:
  %v2680 = load i64, ptr %slot8, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i32 0, ptr %p2681, align 4, !alias.scope !3, !noalias !4
  %v2682 = load i64, ptr %slot40, align 8
  store i64 %v2682, ptr %slot204, align 8
  %v2683 = load i64, ptr %slot9, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  %ld2685 = load i32, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2685, ptr %slot205, align 8
  %v2686 = load i32, ptr %slot205, align 8
  %op2687 = and i32 %v2686, 28
  store i32 %op2687, ptr %slot206, align 8
  %v2688 = load i32, ptr %slot206, align 8
  %cv2689 = zext i32 %v2688 to i64
  %cond2690 = icmp ne i64 %cv2689, 0
  br i1 %cond2690, label %bb_rcslotrole302, label %bb_rcslotowner302
bb_rcslotrole302:
  %v2691 = load i64, ptr %slot73, align 8
  store i64 %v2691, ptr %slot207, align 8
  %v2692 = load i64, ptr %slot207, align 8
  %v2693 = load i64, ptr %slot204, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2692, i64 %v2693) nomerge, !dbg !118
  br label %bb_rcslotdone302
bb_rcslotowner302:
  %v2694 = load i64, ptr %slot73, align 8
  store i64 %v2694, ptr %slot208, align 8
  %v2695 = load i64, ptr %slot208, align 8
  %v2696 = load i64, ptr %slot204, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2695, i64 %v2696) nomerge, !dbg !118
  br label %bb_rcslotdone302
bb_rcslotdone302:
  %v2697 = load i64, ptr %slot6, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %ld2699 = load i32, ptr %p2698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2699, ptr %slot209, align 8
  %v2700 = load i32, ptr %slot209, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcslotdrop311, label %bb_rcslotdone311
bb_rcslotdrop311:
  %v2703 = load i64, ptr %slot6, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  store i32 0, ptr %p2704, align 4, !alias.scope !3, !noalias !4
  %v2705 = load i64, ptr %slot38, align 8
  store i64 %v2705, ptr %slot210, align 8
  %v2706 = load i64, ptr %slot7, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %ld2708 = load i32, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2708, ptr %slot211, align 8
  %v2709 = load i32, ptr %slot211, align 8
  %op2710 = and i32 %v2709, 28
  store i32 %op2710, ptr %slot212, align 8
  %v2711 = load i32, ptr %slot212, align 8
  %cv2712 = zext i32 %v2711 to i64
  %cond2713 = icmp ne i64 %cv2712, 0
  br i1 %cond2713, label %bb_rcslotrole311, label %bb_rcslotowner311
bb_rcslotrole311:
  %v2714 = load i64, ptr %slot73, align 8
  store i64 %v2714, ptr %slot213, align 8
  %v2715 = load i64, ptr %slot213, align 8
  %v2716 = load i64, ptr %slot210, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2715, i64 %v2716) nomerge, !dbg !118
  br label %bb_rcslotdone311
bb_rcslotowner311:
  %v2717 = load i64, ptr %slot73, align 8
  store i64 %v2717, ptr %slot214, align 8
  %v2718 = load i64, ptr %slot214, align 8
  %v2719 = load i64, ptr %slot210, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2718, i64 %v2719) nomerge, !dbg !118
  br label %bb_rcslotdone311
bb_rcslotdone311:
  %v2720 = load i64, ptr %slot151, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2721, i64 24, i1 false)
  ret void
bb_i7:
  %v2722 = load i64, ptr %slot36, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %ld2724 = load i64, ptr %p2723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2724, ptr %slot215, align 8
  %v2725 = load i64, ptr %slot215, align 8
  %v2726 = load i64, ptr %slot52, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i64 %v2725, ptr %p2727, align 8, !alias.scope !3, !noalias !4
  %v2728 = load i64, ptr %slot52, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2730, ptr %slot216, align 8
  %v2731 = load i64, ptr %slot216, align 8
  %op2732 = add i64 %v2731, 32
  store i64 %op2732, ptr %slot217, align 8
  %v2733 = load i64, ptr %slot217, align 8
  %v2734 = load i64, ptr %slot52, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  store i64 %v2733, ptr %p2735, align 8, !alias.scope !3, !noalias !4
  %v2736 = load i64, ptr %slot24, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  %ld2738 = load i32, ptr %p2737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2738, ptr %slot218, align 8
  %v2739 = load i32, ptr %slot218, align 8
  %cv2740 = zext i32 %v2739 to i64
  %cond2741 = icmp ne i64 %cv2740, 0
  br i1 %cond2741, label %bb_rcslotdrop341, label %bb_rcslotdone341
bb_rcslotdrop341:
  %v2742 = load i64, ptr %slot24, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  store i32 0, ptr %p2743, align 4, !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot30, align 8
  store i64 %v2744, ptr %slot219, align 8
  %v2745 = load i64, ptr %slot25, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i32, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2747, ptr %slot220, align 8
  %v2748 = load i32, ptr %slot220, align 8
  %op2749 = and i32 %v2748, 28
  store i32 %op2749, ptr %slot221, align 8
  %v2750 = load i32, ptr %slot221, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcslotrole341, label %bb_rcslotowner341
bb_rcslotrole341:
  %v2753 = load i64, ptr %slot73, align 8
  store i64 %v2753, ptr %slot222, align 8
  %v2754 = load i64, ptr %slot222, align 8
  %v2755 = load i64, ptr %slot219, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2754, i64 %v2755) nomerge, !dbg !120
  br label %bb_rcslotdone341
bb_rcslotowner341:
  %v2756 = load i64, ptr %slot73, align 8
  store i64 %v2756, ptr %slot223, align 8
  %v2757 = load i64, ptr %slot223, align 8
  %v2758 = load i64, ptr %slot219, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2757, i64 %v2758) nomerge, !dbg !120
  br label %bb_rcslotdone341
bb_rcslotdone341:
  %v2759 = load i64, ptr %slot36, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  %ld2761 = load i64, ptr %p2760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2761, ptr %slot224, align 8
  %v2762 = load i64, ptr %slot224, align 8
  %v2763 = load i64, ptr %slot53, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  store i64 %v2762, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  %v2765 = load i64, ptr %slot53, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i64, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2767, ptr %slot225, align 8
  %v2768 = load i64, ptr %slot225, align 8
  %op2769 = add i64 %v2768, 32
  store i64 %op2769, ptr %slot226, align 8
  %v2770 = load i64, ptr %slot226, align 8
  %v2771 = load i64, ptr %slot53, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 %v2770, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot54, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i64 0, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot53, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i64, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2777, ptr %slot227, align 8
  %v2778 = load i64, ptr %slot54, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %ld2780 = load i64, ptr %p2779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2780, ptr %slot228, align 8
  %v2781 = load i64, ptr %slot1, align 8
  %v2782 = load i64, ptr %slot227, align 8
  %v2783 = load i64, ptr %slot228, align 8
  %call2784 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v2781, i64 %v2782, i64 %v2783) nomerge, !dbg !122
  store { i64, i64 } %call2784, ptr %callresult230, align 8
  %addr2785 = ptrtoint ptr %callresult230 to i64
  store i64 %addr2785, ptr %slot229, align 8
  %v2786 = load i64, ptr %slot229, align 8
  %v2787 = load i64, ptr %slot53, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  store i64 %v2786, ptr %p2788, align 8, !alias.scope !3, !noalias !4
  %v2789 = load i64, ptr %slot52, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  %ld2791 = load i64, ptr %p2790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2791, ptr %slot231, align 8
  %v2792 = load i64, ptr %slot53, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  %ld2794 = load i64, ptr %p2793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2794, ptr %slot232, align 8
  %v2795 = load i64, ptr %slot1, align 8
  %v2796 = load i64, ptr %slot231, align 8
  %v2797 = load i64, ptr %slot232, align 8
  call void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8 %callresult234, i64 %v2795, i64 %v2796, i64 %v2797) nomerge, !dbg !124
  %addr2798 = ptrtoint ptr %callresult234 to i64
  store i64 %addr2798, ptr %slot233, align 8
  %v2799 = load i64, ptr %slot233, align 8
  %v2800 = load i64, ptr %slot52, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  store i64 %v2799, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  %v2802 = load i64, ptr %slot52, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %ld2804 = load i64, ptr %p2803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2804, ptr %slot235, align 8
  %v2805 = load i64, ptr %slot32, align 8
  store i64 %v2805, ptr %slot236, align 8
  %v2806 = load i64, ptr %slot235, align 8
  %v2807 = load i64, ptr %slot236, align 8
  %p2808 = inttoptr i64 %v2806 to ptr
  %p2809 = inttoptr i64 %v2807 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2809, ptr %p2808, i64 32, i1 false)
  %v2810 = load i64, ptr %slot28, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 2, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot27, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i32 1, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  %v2814 = load i64, ptr %slot24, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i32, ptr %p2815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2816, ptr %slot237, align 8
  %v2817 = load i32, ptr %slot237, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcslotdrop381, label %bb_rcslotdone381
bb_rcslotdrop381:
  %v2820 = load i64, ptr %slot24, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  store i32 0, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  %v2822 = load i64, ptr %slot30, align 8
  store i64 %v2822, ptr %slot238, align 8
  %v2823 = load i64, ptr %slot25, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %ld2825 = load i32, ptr %p2824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2825, ptr %slot239, align 8
  %v2826 = load i32, ptr %slot239, align 8
  %op2827 = and i32 %v2826, 28
  store i32 %op2827, ptr %slot240, align 8
  %v2828 = load i32, ptr %slot240, align 8
  %cv2829 = zext i32 %v2828 to i64
  %cond2830 = icmp ne i64 %cv2829, 0
  br i1 %cond2830, label %bb_rcslotrole381, label %bb_rcslotowner381
bb_rcslotrole381:
  %v2831 = load i64, ptr %slot73, align 8
  store i64 %v2831, ptr %slot241, align 8
  %v2832 = load i64, ptr %slot241, align 8
  %v2833 = load i64, ptr %slot238, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2832, i64 %v2833) nomerge, !dbg !124
  br label %bb_rcslotdone381
bb_rcslotowner381:
  %v2834 = load i64, ptr %slot73, align 8
  store i64 %v2834, ptr %slot242, align 8
  %v2835 = load i64, ptr %slot242, align 8
  %v2836 = load i64, ptr %slot238, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2835, i64 %v2836) nomerge, !dbg !124
  br label %bb_rcslotdone381
bb_rcslotdone381:
  %v2837 = load i64, ptr %slot30, align 8
  store i64 %v2837, ptr %slot243, align 8
  %v2838 = load i64, ptr %slot32, align 8
  store i64 %v2838, ptr %slot244, align 8
  %v2839 = load i64, ptr %slot244, align 8
  %v2840 = load i64, ptr %slot243, align 8
  %p2841 = inttoptr i64 %v2839 to ptr
  %p2842 = inttoptr i64 %v2840 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2842, ptr %p2841, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2843 = load i64, ptr %slot25, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i32 2, ptr %p2844, align 4, !alias.scope !3, !noalias !4
  %v2845 = load i64, ptr %slot28, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  %ld2847 = load i32, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2847, ptr %slot245, align 8
  %v2848 = load i32, ptr %slot245, align 8
  %v2849 = load i64, ptr %slot25, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  store i32 %v2848, ptr %p2850, align 4, !alias.scope !3, !noalias !4
  %v2851 = load i64, ptr %slot27, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i32 0, ptr %p2852, align 4, !alias.scope !3, !noalias !4
  %v2853 = load i64, ptr %slot24, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 1, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot243, align 8
  %v2856 = load i64, ptr %slot52, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i64 %v2855, ptr %p2857, align 8, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot52, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %ld2860 = load i64, ptr %p2859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2860, ptr %slot246, align 8
  %v2861 = load i64, ptr %slot32, align 8
  store i64 %v2861, ptr %slot247, align 8
  %v2862 = load i64, ptr %slot74, align 8
  store i64 %v2862, ptr %slot248, align 8
  %v2863 = load i64, ptr %slot73, align 8
  %v2864 = load i64, ptr %slot247, align 8
  %v2865 = load i64, ptr %slot246, align 8
  %v2866 = load i64, ptr %slot248, align 8
  %cv2867 = trunc i64 %v2866 to i32
  %call2868 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2863, i64 %v2864, i64 %v2865, i32 %cv2867) nomerge, !dbg !126
  store i32 %call2868, ptr %slot249, align 8
  %v2869 = load i32, ptr %slot249, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcsuccess400, label %bb_rcfailure400
bb_rcfailure400:
  %v2872 = load i64, ptr %slot73, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %call2874 = call i32 @myl_rc_take_failure(ptr %p2873) nomerge, !dbg !126
  store i32 %call2874, ptr %slot250, align 8
  %v2875 = load i64, ptr %slot1, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %v2877 = load i32, ptr %slot250, align 8
  %call2878 = call i32 @myl_qbe_rc_status(ptr %p2876, i32 %v2877) nomerge, !dbg !126
  store i32 %call2878, ptr %slot251, align 8
  br label %bb_failure
bb_rcsuccess400:
  %v2879 = load i64, ptr %slot24, align 8
  %p2880 = inttoptr i64 %v2879 to ptr
  store i32 0, ptr %p2880, align 4, !alias.scope !3, !noalias !4
  %v2881 = load i64, ptr %slot28, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  store i32 2, ptr %p2882, align 4, !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot27, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i32 1, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot6, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %ld2887 = load i32, ptr %p2886, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2887, ptr %slot252, align 8
  %v2888 = load i32, ptr %slot252, align 8
  %cv2889 = zext i32 %v2888 to i64
  %cond2890 = icmp ne i64 %cv2889, 0
  br i1 %cond2890, label %bb_rcslotdrop409, label %bb_rcslotdone409
bb_rcslotdrop409:
  %v2891 = load i64, ptr %slot6, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  store i32 0, ptr %p2892, align 4, !alias.scope !3, !noalias !4
  %v2893 = load i64, ptr %slot38, align 8
  store i64 %v2893, ptr %slot253, align 8
  %v2894 = load i64, ptr %slot7, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  %ld2896 = load i32, ptr %p2895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2896, ptr %slot254, align 8
  %v2897 = load i32, ptr %slot254, align 8
  %op2898 = and i32 %v2897, 28
  store i32 %op2898, ptr %slot255, align 8
  %v2899 = load i32, ptr %slot255, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcslotrole409, label %bb_rcslotowner409
bb_rcslotrole409:
  %v2902 = load i64, ptr %slot73, align 8
  store i64 %v2902, ptr %slot256, align 8
  %v2903 = load i64, ptr %slot256, align 8
  %v2904 = load i64, ptr %slot253, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2903, i64 %v2904) nomerge, !dbg !126
  br label %bb_rcslotdone409
bb_rcslotowner409:
  %v2905 = load i64, ptr %slot73, align 8
  store i64 %v2905, ptr %slot257, align 8
  %v2906 = load i64, ptr %slot257, align 8
  %v2907 = load i64, ptr %slot253, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2906, i64 %v2907) nomerge, !dbg !126
  br label %bb_rcslotdone409
bb_rcslotdone409:
  %v2908 = load i64, ptr %slot38, align 8
  store i64 %v2908, ptr %slot258, align 8
  %v2909 = load i64, ptr %slot32, align 8
  store i64 %v2909, ptr %slot259, align 8
  %v2910 = load i64, ptr %slot259, align 8
  %v2911 = load i64, ptr %slot258, align 8
  %p2912 = inttoptr i64 %v2910 to ptr
  %p2913 = inttoptr i64 %v2911 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2913, ptr %p2912, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot27, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  store i32 0, ptr %p2915, align 4, !alias.scope !3, !noalias !4
  %v2916 = load i64, ptr %slot7, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  store i32 2, ptr %p2917, align 4, !alias.scope !3, !noalias !4
  %v2918 = load i64, ptr %slot28, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  %ld2920 = load i32, ptr %p2919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2920, ptr %slot260, align 8
  %v2921 = load i32, ptr %slot260, align 8
  %v2922 = load i64, ptr %slot7, align 8
  %p2923 = inttoptr i64 %v2922 to ptr
  store i32 %v2921, ptr %p2923, align 4, !alias.scope !3, !noalias !4
  %v2924 = load i64, ptr %slot6, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  store i32 1, ptr %p2925, align 4, !alias.scope !3, !noalias !4
  %v2926 = load i64, ptr %slot38, align 8
  %v2927 = load i64, ptr %slot52, align 8
  %p2928 = inttoptr i64 %v2927 to ptr
  store i64 %v2926, ptr %p2928, align 8, !alias.scope !3, !noalias !4
  %v2929 = load i64, ptr %slot52, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %ld2931 = load i64, ptr %p2930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2931, ptr %slot261, align 8
  %v2932 = load i64, ptr %slot261, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %ld2934 = load i32, ptr %p2933, align 4
  %ext2935 = zext i32 %ld2934 to i64
  store i64 %ext2935, ptr %slot262, align 8
  %v2936 = load i64, ptr %slot262, align 8
  %cmp2937 = icmp eq i64 %v2936, 0
  %cv2938 = zext i1 %cmp2937 to i64
  store i64 %cv2938, ptr %slot263, align 8
  %v2939 = load i64, ptr %slot263, align 8
  %cond2940 = icmp ne i64 %v2939, 0
  br i1 %cond2940, label %bb_rcarm425, label %bb_rcarmnext425
bb_rcarm425:
  %v2941 = load i64, ptr %slot24, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  %ld2943 = load i32, ptr %p2942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2943, ptr %slot264, align 8
  %v2944 = load i32, ptr %slot264, align 8
  %cv2945 = zext i32 %v2944 to i64
  %cond2946 = icmp ne i64 %cv2945, 0
  br i1 %cond2946, label %bb_rcslotdrop428, label %bb_rcslotdone428
bb_rcslotdrop428:
  %v2947 = load i64, ptr %slot24, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  store i32 0, ptr %p2948, align 4, !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot30, align 8
  store i64 %v2949, ptr %slot265, align 8
  %v2950 = load i64, ptr %slot25, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  %ld2952 = load i32, ptr %p2951, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2952, ptr %slot266, align 8
  %v2953 = load i32, ptr %slot266, align 8
  %op2954 = and i32 %v2953, 28
  store i32 %op2954, ptr %slot267, align 8
  %v2955 = load i32, ptr %slot267, align 8
  %cv2956 = zext i32 %v2955 to i64
  %cond2957 = icmp ne i64 %cv2956, 0
  br i1 %cond2957, label %bb_rcslotrole428, label %bb_rcslotowner428
bb_rcslotrole428:
  %v2958 = load i64, ptr %slot73, align 8
  store i64 %v2958, ptr %slot268, align 8
  %v2959 = load i64, ptr %slot268, align 8
  %v2960 = load i64, ptr %slot265, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2959, i64 %v2960) nomerge, !dbg !128
  br label %bb_rcslotdone428
bb_rcslotowner428:
  %v2961 = load i64, ptr %slot73, align 8
  store i64 %v2961, ptr %slot269, align 8
  %v2962 = load i64, ptr %slot269, align 8
  %v2963 = load i64, ptr %slot265, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2962, i64 %v2963) nomerge, !dbg !128
  br label %bb_rcslotdone428
bb_rcslotdone428:
  br label %bb_i21
bb_rcarmnext425:
  %v2964 = load i64, ptr %slot262, align 8
  %cmp2965 = icmp eq i64 %v2964, 1
  %cv2966 = zext i1 %cmp2965 to i64
  store i64 %cv2966, ptr %slot270, align 8
  %v2967 = load i64, ptr %slot270, align 8
  %cond2968 = icmp ne i64 %v2967, 0
  br i1 %cond2968, label %bb_rcarm435, label %bb_rcarmnext435
bb_rcarm435:
  %v2969 = load i64, ptr %slot24, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  %ld2971 = load i32, ptr %p2970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2971, ptr %slot271, align 8
  %v2972 = load i32, ptr %slot271, align 8
  %cv2973 = zext i32 %v2972 to i64
  %cond2974 = icmp ne i64 %cv2973, 0
  br i1 %cond2974, label %bb_rcslotdrop438, label %bb_rcslotdone438
bb_rcslotdrop438:
  %v2975 = load i64, ptr %slot24, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  store i32 0, ptr %p2976, align 4, !alias.scope !3, !noalias !4
  %v2977 = load i64, ptr %slot30, align 8
  store i64 %v2977, ptr %slot272, align 8
  %v2978 = load i64, ptr %slot25, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %ld2980 = load i32, ptr %p2979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2980, ptr %slot273, align 8
  %v2981 = load i32, ptr %slot273, align 8
  %op2982 = and i32 %v2981, 28
  store i32 %op2982, ptr %slot274, align 8
  %v2983 = load i32, ptr %slot274, align 8
  %cv2984 = zext i32 %v2983 to i64
  %cond2985 = icmp ne i64 %cv2984, 0
  br i1 %cond2985, label %bb_rcslotrole438, label %bb_rcslotowner438
bb_rcslotrole438:
  %v2986 = load i64, ptr %slot73, align 8
  store i64 %v2986, ptr %slot275, align 8
  %v2987 = load i64, ptr %slot275, align 8
  %v2988 = load i64, ptr %slot272, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2987, i64 %v2988) nomerge, !dbg !128
  br label %bb_rcslotdone438
bb_rcslotowner438:
  %v2989 = load i64, ptr %slot73, align 8
  store i64 %v2989, ptr %slot276, align 8
  %v2990 = load i64, ptr %slot276, align 8
  %v2991 = load i64, ptr %slot272, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2990, i64 %v2991) nomerge, !dbg !128
  br label %bb_rcslotdone438
bb_rcslotdone438:
  br label %bb_i18
bb_rcarmnext435:
  br label %bb_failure
bb_i18:
  %v2992 = load i64, ptr %slot52, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i64 0, ptr %p2993, align 8, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot52, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  %ld2996 = load i64, ptr %p2995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2996, ptr %slot277, align 8
  %v2997 = load i64, ptr %slot277, align 8
  %v2998 = load i64, ptr %slot39, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i64 %v2997, ptr %p2999, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i21:
  %v3000 = load i64, ptr %slot52, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  store i64 1, ptr %p3001, align 8, !alias.scope !3, !noalias !4
  %v3002 = load i64, ptr %slot52, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  %ld3004 = load i64, ptr %p3003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3004, ptr %slot278, align 8
  %v3005 = load i64, ptr %slot278, align 8
  %v3006 = load i64, ptr %slot39, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i64 %v3005, ptr %p3007, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v3008 = load i64, ptr %slot39, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  %ld3010 = load i64, ptr %p3009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3010, ptr %slot279, align 8
  %v3011 = load i64, ptr %slot279, align 8
  %v3012 = load i64, ptr %slot52, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i64 %v3011, ptr %p3013, align 8, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot52, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  %ld3016 = load i64, ptr %p3015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3016, ptr %slot280, align 8
  %v3017 = load i64, ptr %slot280, align 8
  %cond3018 = icmp ne i64 %v3017, 0
  br i1 %cond3018, label %bb_next449, label %bb_i33
bb_next449:
  %p3019 = inttoptr i64 ptrtoint (ptr @myl_lit_ae34ea25ba6543390a4fad13083ff6a513fffab9c9bddab170c1a5122079ec98 to i64) to ptr
  %ld3020 = load i64, ptr %p3019, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3020, ptr %slot281, align 8
  %v3021 = load i64, ptr %slot281, align 8
  %v3022 = load i64, ptr %slot52, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  store i64 %v3021, ptr %p3023, align 8, !alias.scope !3, !noalias !4
  %v3024 = load i64, ptr %slot52, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  %ld3026 = load i64, ptr %p3025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3026, ptr %slot282, align 8
  %v3027 = load i64, ptr %slot282, align 8
  %v3028 = load i64, ptr %slot31, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  store i64 %v3027, ptr %p3029, align 8, !alias.scope !3, !noalias !4
  %v3030 = load i64, ptr %slot31, align 8
  store i64 %v3030, ptr %slot283, align 8
  %v3031 = load i64, ptr %slot32, align 8
  store i64 %v3031, ptr %slot284, align 8
  %v3032 = load i64, ptr %slot283, align 8
  %v3033 = load i64, ptr %slot284, align 8
  %p3034 = inttoptr i64 %v3032 to ptr
  %p3035 = inttoptr i64 %v3033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3035, ptr %p3034, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot28, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  store i32 2, ptr %p3037, align 4, !alias.scope !3, !noalias !4
  %v3038 = load i64, ptr %slot27, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  store i32 1, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  %v3040 = load i64, ptr %slot30, align 8
  store i64 %v3040, ptr %slot285, align 8
  %v3041 = load i64, ptr %slot32, align 8
  store i64 %v3041, ptr %slot286, align 8
  %v3042 = load i64, ptr %slot286, align 8
  %v3043 = load i64, ptr %slot285, align 8
  %p3044 = inttoptr i64 %v3042 to ptr
  %p3045 = inttoptr i64 %v3043 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3045, ptr %p3044, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot25, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i32 2, ptr %p3047, align 4, !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot28, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i32, ptr %p3049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3050, ptr %slot287, align 8
  %v3051 = load i32, ptr %slot287, align 8
  %v3052 = load i64, ptr %slot25, align 8
  %p3053 = inttoptr i64 %v3052 to ptr
  store i32 %v3051, ptr %p3053, align 4, !alias.scope !3, !noalias !4
  %v3054 = load i64, ptr %slot27, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i32 0, ptr %p3055, align 4, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot24, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 1, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot285, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %ld3060 = load i64, ptr %p3059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3060, ptr %slot288, align 8
  %v3061 = load i64, ptr %slot288, align 8
  %v3062 = load i64, ptr %slot52, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  store i64 %v3061, ptr %p3063, align 8, !alias.scope !3, !noalias !4
  %v3064 = load i64, ptr %slot37, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %ld3066 = load i64, ptr %p3065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3066, ptr %slot289, align 8
  %v3067 = load i64, ptr %slot289, align 8
  %v3068 = load i64, ptr %slot53, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i64 %v3067, ptr %p3069, align 8, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot53, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %ld3072 = load i64, ptr %p3071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3072, ptr %slot290, align 8
  %v3073 = load i64, ptr %slot290, align 8
  %op3074 = add i64 %v3073, 8
  store i64 %op3074, ptr %slot291, align 8
  %v3075 = load i64, ptr %slot291, align 8
  %v3076 = load i64, ptr %slot53, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i64 %v3075, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot53, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %ld3080 = load i64, ptr %p3079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3080, ptr %slot292, align 8
  %v3081 = load i64, ptr %slot292, align 8
  %op3082 = add i64 %v3081, 24
  store i64 %op3082, ptr %slot293, align 8
  %v3083 = load i64, ptr %slot293, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %ld3085 = load i64, ptr %p3084, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3085, ptr %slot294, align 8
  %v3086 = load i64, ptr %slot294, align 8
  %v3087 = load i64, ptr %slot53, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i64 %v3086, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot52, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i64, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3091, ptr %slot295, align 8
  %v3092 = load i64, ptr %slot53, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  %ld3094 = load i64, ptr %p3093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3094, ptr %slot296, align 8
  %v3095 = load i64, ptr %slot1, align 8
  %v3096 = load i64, ptr %slot295, align 8
  %v3097 = load i64, ptr %slot296, align 8
  %call3098 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v3095, i64 %v3096, i64 %v3097) nomerge, !dbg !130
  store { i64, i64 } %call3098, ptr %callresult298, align 8
  %addr3099 = ptrtoint ptr %callresult298 to i64
  store i64 %addr3099, ptr %slot297, align 8
  %v3100 = load i64, ptr %slot297, align 8
  %v3101 = load i64, ptr %slot52, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  store i64 %v3100, ptr %p3102, align 8, !alias.scope !3, !noalias !4
  %v3103 = load i64, ptr %slot52, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  %ld3105 = load i64, ptr %p3104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3105, ptr %slot299, align 8
  %v3106 = load i64, ptr %slot32, align 8
  store i64 %v3106, ptr %slot300, align 8
  %v3107 = load i64, ptr %slot73, align 8
  %v3108 = load i64, ptr %slot300, align 8
  %v3109 = load i64, ptr %slot299, align 8
  %call3110 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v3107, i64 %v3108, i64 %v3109) nomerge, !dbg !130
  store i32 %call3110, ptr %slot301, align 8
  %v3111 = load i32, ptr %slot301, align 8
  %cv3112 = zext i32 %v3111 to i64
  %cond3113 = icmp ne i64 %cv3112, 0
  br i1 %cond3113, label %bb_rcsuccess495, label %bb_rcfailure495
bb_rcfailure495:
  %v3114 = load i64, ptr %slot73, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %call3116 = call i32 @myl_rc_take_failure(ptr %p3115) nomerge, !dbg !130
  store i32 %call3116, ptr %slot302, align 8
  %v3117 = load i64, ptr %slot1, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  %v3119 = load i32, ptr %slot302, align 8
  %call3120 = call i32 @myl_qbe_rc_status(ptr %p3118, i32 %v3119) nomerge, !dbg !130
  store i32 %call3120, ptr %slot303, align 8
  br label %bb_failure
bb_rcsuccess495:
  %v3121 = load i64, ptr %slot28, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  store i32 2, ptr %p3122, align 4, !alias.scope !3, !noalias !4
  %v3123 = load i64, ptr %slot28, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  store i32 16, ptr %p3124, align 4, !alias.scope !3, !noalias !4
  %v3125 = load i64, ptr %slot27, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  store i32 1, ptr %p3126, align 4, !alias.scope !3, !noalias !4
  %v3127 = load i64, ptr %slot24, align 8
  %p3128 = inttoptr i64 %v3127 to ptr
  %ld3129 = load i32, ptr %p3128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3129, ptr %slot304, align 8
  %v3130 = load i32, ptr %slot304, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcslotdrop503, label %bb_rcslotdone503
bb_rcslotdrop503:
  %v3133 = load i64, ptr %slot24, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  store i32 0, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  %v3135 = load i64, ptr %slot30, align 8
  store i64 %v3135, ptr %slot305, align 8
  %v3136 = load i64, ptr %slot25, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %ld3138 = load i32, ptr %p3137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3138, ptr %slot306, align 8
  %v3139 = load i32, ptr %slot306, align 8
  %op3140 = and i32 %v3139, 28
  store i32 %op3140, ptr %slot307, align 8
  %v3141 = load i32, ptr %slot307, align 8
  %cv3142 = zext i32 %v3141 to i64
  %cond3143 = icmp ne i64 %cv3142, 0
  br i1 %cond3143, label %bb_rcslotrole503, label %bb_rcslotowner503
bb_rcslotrole503:
  %v3144 = load i64, ptr %slot73, align 8
  store i64 %v3144, ptr %slot308, align 8
  %v3145 = load i64, ptr %slot305, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %ld3147 = load i64, ptr %p3146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3147, ptr %slot309, align 8
  %v3148 = load i64, ptr %slot309, align 8
  %cmp3149 = icmp ne i64 %v3148, 0
  %cv3150 = zext i1 %cmp3149 to i32
  store i32 %cv3150, ptr %slot310, align 8
  %v3151 = load i32, ptr %slot310, align 8
  %cv3152 = zext i32 %v3151 to i64
  %cond3153 = icmp ne i64 %cv3152, 0
  br i1 %cond3153, label %bb_rcgnn519, label %bb_rcgdone519
bb_rcgnn519:
  %v3154 = load i64, ptr %slot309, align 8
  %op3155 = sub i64 %v3154, 16
  store i64 %op3155, ptr %slot311, align 8
  %v3156 = load i64, ptr %slot309, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  %rgep3158 = getelementptr i8, ptr %p3157, i64 -16
  %ld3159 = load i64, ptr %rgep3158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3159, ptr %slot312, align 8
  %v3160 = load i64, ptr %slot312, align 8
  %op3161 = and i64 %v3160, 4611686018427387906
  store i64 %op3161, ptr %slot313, align 8
  %v3162 = load i64, ptr %slot313, align 8
  %cmp3163 = icmp ne i64 %v3162, 0
  %cv3164 = zext i1 %cmp3163 to i32
  store i32 %cv3164, ptr %slot314, align 8
  %v3165 = load i32, ptr %slot314, align 8
  %cv3166 = zext i32 %v3165 to i64
  %cond3167 = icmp ne i64 %cv3166, 0
  br i1 %cond3167, label %bb_rcgclear519, label %bb_rcgcounted519
bb_rcgcounted519:
  %v3168 = load i64, ptr %slot309, align 8
  %op3169 = sub i64 %v3168, 24
  store i64 %op3169, ptr %slot315, align 8
  %v3170 = load i64, ptr %slot309, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  %rgep3172 = getelementptr i8, ptr %p3171, i64 -24
  %ld3173 = load i64, ptr %rgep3172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3173, ptr %slot316, align 8
  %v3174 = load i64, ptr %slot316, align 8
  %op3175 = sub i64 %v3174, 1
  store i64 %op3175, ptr %slot317, align 8
  %v3176 = load i64, ptr %slot317, align 8
  %cmp3177 = icmp eq i64 %v3176, 0
  %cv3178 = zext i1 %cmp3177 to i32
  store i32 %cv3178, ptr %slot318, align 8
  %v3179 = load i32, ptr %slot318, align 8
  %cv3180 = zext i32 %v3179 to i64
  %cond3181 = icmp ne i64 %cv3180, 0
  br i1 %cond3181, label %bb_rcglast519, label %bb_rcgdec519
bb_rcglast519:
  %v3182 = load i64, ptr %slot309, align 8
  %op3183 = sub i64 %v3182, 32
  store i64 %op3183, ptr %slot319, align 8
  %v3184 = load i64, ptr %slot309, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  %rgep3186 = getelementptr i8, ptr %p3185, i64 -32
  %ld3187 = load i64, ptr %rgep3186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3187, ptr %slot320, align 8
  %v3188 = load i64, ptr %slot320, align 8
  %cmp3189 = icmp ne i64 %v3188, 0
  %cv3190 = zext i1 %cmp3189 to i32
  store i32 %cv3190, ptr %slot321, align 8
  %v3191 = load i32, ptr %slot321, align 8
  %cv3192 = zext i32 %v3191 to i64
  %cond3193 = icmp ne i64 %cv3192, 0
  br i1 %cond3193, label %bb_rcgdec519, label %bb_rcgslow519
bb_rcgslow519:
  %v3194 = load i64, ptr %slot308, align 8
  %v3195 = load i64, ptr %slot305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3194, i64 %v3195) nomerge, !dbg !130
  br label %bb_rcgdone519
bb_rcgdec519:
  %v3196 = load i64, ptr %slot317, align 8
  %v3197 = load i64, ptr %slot309, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %rgep3199 = getelementptr i8, ptr %p3198, i64 -24
  store i64 %v3196, ptr %rgep3199, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear519
bb_rcgclear519:
  %v3200 = load i64, ptr %slot305, align 8
  %p3201 = inttoptr i64 %v3200 to ptr
  store i64 0, ptr %p3201, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone519
bb_rcgdone519:
  br label %bb_rcslotdone503
bb_rcslotowner503:
  %v3202 = load i64, ptr %slot73, align 8
  store i64 %v3202, ptr %slot322, align 8
  %v3203 = load i64, ptr %slot305, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  %ld3205 = load i64, ptr %p3204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3205, ptr %slot323, align 8
  %v3206 = load i64, ptr %slot323, align 8
  %cmp3207 = icmp ne i64 %v3206, 0
  %cv3208 = zext i1 %cmp3207 to i32
  store i32 %cv3208, ptr %slot324, align 8
  %v3209 = load i32, ptr %slot324, align 8
  %cv3210 = zext i32 %v3209 to i64
  %cond3211 = icmp ne i64 %cv3210, 0
  br i1 %cond3211, label %bb_rcgnn534, label %bb_rcgdone534
bb_rcgnn534:
  %v3212 = load i64, ptr %slot323, align 8
  %op3213 = sub i64 %v3212, 16
  store i64 %op3213, ptr %slot325, align 8
  %v3214 = load i64, ptr %slot323, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %rgep3216 = getelementptr i8, ptr %p3215, i64 -16
  %ld3217 = load i64, ptr %rgep3216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3217, ptr %slot326, align 8
  %v3218 = load i64, ptr %slot326, align 8
  %op3219 = and i64 %v3218, 4611686018427387906
  store i64 %op3219, ptr %slot327, align 8
  %v3220 = load i64, ptr %slot327, align 8
  %cmp3221 = icmp ne i64 %v3220, 0
  %cv3222 = zext i1 %cmp3221 to i32
  store i32 %cv3222, ptr %slot328, align 8
  %v3223 = load i32, ptr %slot328, align 8
  %cv3224 = zext i32 %v3223 to i64
  %cond3225 = icmp ne i64 %cv3224, 0
  br i1 %cond3225, label %bb_rcgclear534, label %bb_rcgcounted534
bb_rcgcounted534:
  %v3226 = load i64, ptr %slot323, align 8
  %op3227 = sub i64 %v3226, 32
  store i64 %op3227, ptr %slot329, align 8
  %v3228 = load i64, ptr %slot323, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  %rgep3230 = getelementptr i8, ptr %p3229, i64 -32
  %ld3231 = load i64, ptr %rgep3230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3231, ptr %slot330, align 8
  %v3232 = load i64, ptr %slot330, align 8
  %op3233 = sub i64 %v3232, 1
  store i64 %op3233, ptr %slot331, align 8
  %v3234 = load i64, ptr %slot331, align 8
  %cmp3235 = icmp eq i64 %v3234, 0
  %cv3236 = zext i1 %cmp3235 to i32
  store i32 %cv3236, ptr %slot332, align 8
  %v3237 = load i32, ptr %slot332, align 8
  %cv3238 = zext i32 %v3237 to i64
  %cond3239 = icmp ne i64 %cv3238, 0
  br i1 %cond3239, label %bb_rcglast534, label %bb_rcgdec534
bb_rcglast534:
  %v3240 = load i64, ptr %slot323, align 8
  %op3241 = sub i64 %v3240, 24
  store i64 %op3241, ptr %slot333, align 8
  %v3242 = load i64, ptr %slot323, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %rgep3244 = getelementptr i8, ptr %p3243, i64 -24
  %ld3245 = load i64, ptr %rgep3244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3245, ptr %slot334, align 8
  %v3246 = load i64, ptr %slot334, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot335, align 8
  %v3249 = load i32, ptr %slot335, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcgdec534, label %bb_rcgslow534
bb_rcgslow534:
  %v3252 = load i64, ptr %slot322, align 8
  %v3253 = load i64, ptr %slot305, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3252, i64 %v3253) nomerge, !dbg !130
  br label %bb_rcgdone534
bb_rcgdec534:
  %v3254 = load i64, ptr %slot331, align 8
  %v3255 = load i64, ptr %slot323, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %rgep3257 = getelementptr i8, ptr %p3256, i64 -32
  store i64 %v3254, ptr %rgep3257, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear534
bb_rcgclear534:
  %v3258 = load i64, ptr %slot305, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  store i64 0, ptr %p3259, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone534
bb_rcgdone534:
  br label %bb_rcslotdone503
bb_rcslotdone503:
  %v3260 = load i64, ptr %slot30, align 8
  store i64 %v3260, ptr %slot336, align 8
  %v3261 = load i64, ptr %slot32, align 8
  store i64 %v3261, ptr %slot337, align 8
  %v3262 = load i64, ptr %slot337, align 8
  %v3263 = load i64, ptr %slot336, align 8
  %p3264 = inttoptr i64 %v3262 to ptr
  %p3265 = inttoptr i64 %v3263 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3265, ptr %p3264, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3266 = load i64, ptr %slot25, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  store i32 2, ptr %p3267, align 4, !alias.scope !3, !noalias !4
  %v3268 = load i64, ptr %slot28, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %ld3270 = load i32, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3270, ptr %slot338, align 8
  %v3271 = load i32, ptr %slot338, align 8
  %v3272 = load i64, ptr %slot25, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  store i32 %v3271, ptr %p3273, align 4, !alias.scope !3, !noalias !4
  %v3274 = load i64, ptr %slot27, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  store i32 0, ptr %p3275, align 4, !alias.scope !3, !noalias !4
  %v3276 = load i64, ptr %slot24, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  store i32 1, ptr %p3277, align 4, !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot336, align 8
  %v3279 = load i64, ptr %slot52, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  store i64 %v3278, ptr %p3280, align 8, !alias.scope !3, !noalias !4
  %v3281 = load i64, ptr %slot58, align 8
  store i64 %v3281, ptr %slot339, align 8
  %v3282 = load i64, ptr %slot339, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i64 0, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  %v3284 = load i64, ptr %slot339, align 8
  %p3286 = inttoptr i64 %v3284 to ptr
  %gep3287 = getelementptr i8, ptr %p3286, i64 8
  %op3285 = ptrtoint ptr %gep3287 to i64
  store i64 %op3285, ptr %slot340, align 8
  %v3288 = load i64, ptr %slot340, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i64 0, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot339, align 8
  %p3292 = inttoptr i64 %v3290 to ptr
  %gep3293 = getelementptr i8, ptr %p3292, i64 16
  %op3291 = ptrtoint ptr %gep3293 to i64
  store i64 %op3291, ptr %slot341, align 8
  %v3294 = load i64, ptr %slot341, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  store i64 0, ptr %p3295, align 8, !alias.scope !3, !noalias !4
  %v3296 = load i64, ptr %slot339, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  store i32 1, ptr %p3297, align 4, !alias.scope !3, !noalias !4
  %v3298 = load i64, ptr %slot29, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i32 1, ptr %p3299, align 4, !alias.scope !3, !noalias !4
  %v3300 = load i64, ptr %slot52, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  %ld3302 = load i64, ptr %p3301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3302, ptr %slot342, align 8
  %v3303 = load i64, ptr %slot339, align 8
  %p3305 = inttoptr i64 %v3303 to ptr
  %gep3306 = getelementptr i8, ptr %p3305, i64 8
  %op3304 = ptrtoint ptr %gep3306 to i64
  store i64 %op3304, ptr %slot343, align 8
  %v3307 = load i64, ptr %slot74, align 8
  store i64 %v3307, ptr %slot344, align 8
  %v3308 = load i64, ptr %slot52, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  %ld3310 = load i64, ptr %p3309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3310, ptr %slot345, align 8
  %v3311 = load i64, ptr %slot24, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %ld3313 = load i32, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3313, ptr %slot346, align 8
  %v3314 = load i64, ptr %slot25, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i32, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3316, ptr %slot347, align 8
  %v3317 = load i32, ptr %slot347, align 8
  %op3318 = and i32 %v3317, 24
  store i32 %op3318, ptr %slot347, align 8
  %v3319 = load i32, ptr %slot347, align 8
  %cmp3320 = icmp eq i32 %v3319, 0
  %cv3321 = zext i1 %cmp3320 to i32
  store i32 %cv3321, ptr %slot348, align 8
  %v3322 = load i32, ptr %slot346, align 8
  %v3323 = load i32, ptr %slot348, align 8
  %op3324 = and i32 %v3322, %v3323
  store i32 %op3324, ptr %slot349, align 8
  %v3325 = load i32, ptr %slot349, align 8
  %cv3326 = zext i32 %v3325 to i64
  %cond3327 = icmp ne i64 %cv3326, 0
  br i1 %cond3327, label %bb_rctake555, label %bb_rccopy555
bb_rctake555:
  %v3328 = load i64, ptr %slot32, align 8
  store i64 %v3328, ptr %slot350, align 8
  %v3329 = load i64, ptr %slot74, align 8
  store i64 %v3329, ptr %slot351, align 8
  %v3330 = load i64, ptr %slot345, align 8
  %v3331 = load i64, ptr %slot350, align 8
  %op3332 = sub i64 %v3330, %v3331
  store i64 %op3332, ptr %slot352, align 8
  %v3333 = load i64, ptr %slot350, align 8
  %v3334 = load i64, ptr %slot345, align 8
  %op3335 = sub i64 %v3333, %v3334
  store i64 %op3335, ptr %slot353, align 8
  %v3336 = load i64, ptr %slot352, align 8
  %cmp3337 = icmp ult i64 %v3336, 16
  %cv3338 = zext i1 %cmp3337 to i32
  store i32 %cv3338, ptr %slot354, align 8
  %v3339 = load i64, ptr %slot353, align 8
  %cmp3340 = icmp ult i64 %v3339, 16
  %cv3341 = zext i1 %cmp3340 to i32
  store i32 %cv3341, ptr %slot355, align 8
  %v3342 = load i32, ptr %slot354, align 8
  %v3343 = load i32, ptr %slot355, align 8
  %op3344 = or i32 %v3342, %v3343
  store i32 %op3344, ptr %slot356, align 8
  %v3345 = load i32, ptr %slot356, align 8
  %cv3346 = zext i32 %v3345 to i64
  %cond3347 = icmp ne i64 %cv3346, 0
  br i1 %cond3347, label %bb_rcmoveslow564, label %bb_rcmovecheck564
bb_rcmovecheck564:
  %v3348 = load i64, ptr %slot345, align 8
  %op3349 = add i64 %v3348, 0
  store i64 %op3349, ptr %slot357, align 8
  %v3350 = load i64, ptr %slot357, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i64, ptr %p3351, align 8
  store i64 %ld3352, ptr %slot358, align 8
  %v3353 = load i64, ptr %slot358, align 8
  %cmp3354 = icmp ne i64 %v3353, 0
  %cv3355 = zext i1 %cmp3354 to i32
  store i32 %cv3355, ptr %slot359, align 8
  %v3356 = load i32, ptr %slot359, align 8
  %cv3357 = zext i32 %v3356 to i64
  %cond3358 = icmp ne i64 %cv3357, 0
  br i1 %cond3358, label %bb_rcmoveheader572, label %bb_rcmovenext572
bb_rcmoveheader572:
  %v3359 = load i64, ptr %slot358, align 8
  %op3360 = sub i64 %v3359, 16
  store i64 %op3360, ptr %slot360, align 8
  %v3361 = load i64, ptr %slot358, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  %rgep3363 = getelementptr i8, ptr %p3362, i64 -16
  %ld3364 = load i64, ptr %rgep3363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3364, ptr %slot361, align 8
  %v3365 = load i64, ptr %slot361, align 8
  %op3366 = and i64 %v3365, 5764607523034234881
  store i64 %op3366, ptr %slot362, align 8
  %v3367 = load i64, ptr %slot362, align 8
  %cmp3368 = icmp ne i64 %v3367, 0
  %cv3369 = zext i1 %cmp3368 to i32
  store i32 %cv3369, ptr %slot363, align 8
  %v3370 = load i32, ptr %slot363, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcmoveslow564, label %bb_rcmovenext572
bb_rcmovenext572:
  %v3373 = load i64, ptr %slot345, align 8
  %v3374 = load i64, ptr %slot350, align 8
  %p3375 = inttoptr i64 %v3373 to ptr
  %p3376 = inttoptr i64 %v3374 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3376, ptr %p3375, i64 16, i1 false)
  %v3377 = load i64, ptr %slot345, align 8
  %p3378 = inttoptr i64 %v3377 to ptr
  store i64 0, ptr %p3378, align 8
  %v3379 = load i64, ptr %slot345, align 8
  %op3380 = add i64 %v3379, 8
  store i64 %op3380, ptr %slot364, align 8
  %v3381 = load i64, ptr %slot364, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  store i64 0, ptr %p3382, align 8
  br label %bb_rcmoved564
bb_rcmoveslow564:
  %v3383 = load i64, ptr %slot73, align 8
  %v3384 = load i64, ptr %slot350, align 8
  %v3385 = load i64, ptr %slot345, align 8
  %v3386 = load i64, ptr %slot351, align 8
  %cv3387 = trunc i64 %v3386 to i32
  %call3388 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v3383, i64 %v3384, i64 %v3385, i32 %cv3387) nomerge, !dbg !132
  store i32 %call3388, ptr %slot365, align 8
  %v3389 = load i32, ptr %slot365, align 8
  %cv3390 = zext i32 %v3389 to i64
  %cond3391 = icmp ne i64 %cv3390, 0
  br i1 %cond3391, label %bb_rcsuccess580, label %bb_rcfailure580
bb_rcfailure580:
  %v3392 = load i64, ptr %slot73, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %call3394 = call i32 @myl_rc_take_failure(ptr %p3393) nomerge, !dbg !132
  store i32 %call3394, ptr %slot366, align 8
  %v3395 = load i64, ptr %slot1, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  %v3397 = load i32, ptr %slot366, align 8
  %call3398 = call i32 @myl_qbe_rc_status(ptr %p3396, i32 %v3397) nomerge, !dbg !132
  store i32 %call3398, ptr %slot367, align 8
  br label %bb_failure
bb_rcsuccess580:
  br label %bb_rcmoved564
bb_rcmoved564:
  %v3399 = load i64, ptr %slot24, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i32 0, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  %v3401 = load i64, ptr %slot28, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  store i32 2, ptr %p3402, align 4, !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot27, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i32 1, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared555
bb_rccopy555:
  %v3405 = load i64, ptr %slot32, align 8
  store i64 %v3405, ptr %slot368, align 8
  %v3406 = load i64, ptr %slot74, align 8
  store i64 %v3406, ptr %slot369, align 8
  %v3407 = load i64, ptr %slot73, align 8
  %v3408 = load i64, ptr %slot368, align 8
  %v3409 = load i64, ptr %slot345, align 8
  %v3410 = load i64, ptr %slot369, align 8
  %cv3411 = trunc i64 %v3410 to i32
  %call3412 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v3407, i64 %v3408, i64 %v3409, i32 %cv3411) nomerge, !dbg !132
  store i32 %call3412, ptr %slot370, align 8
  %v3413 = load i32, ptr %slot370, align 8
  %cv3414 = zext i32 %v3413 to i64
  %cond3415 = icmp ne i64 %cv3414, 0
  br i1 %cond3415, label %bb_rcsuccess589, label %bb_rcfailure589
bb_rcfailure589:
  %v3416 = load i64, ptr %slot73, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  %call3418 = call i32 @myl_rc_take_failure(ptr %p3417) nomerge, !dbg !132
  store i32 %call3418, ptr %slot371, align 8
  %v3419 = load i64, ptr %slot1, align 8
  %p3420 = inttoptr i64 %v3419 to ptr
  %v3421 = load i32, ptr %slot371, align 8
  %call3422 = call i32 @myl_qbe_rc_status(ptr %p3420, i32 %v3421) nomerge, !dbg !132
  store i32 %call3422, ptr %slot372, align 8
  br label %bb_failure
bb_rcsuccess589:
  %v3423 = load i64, ptr %slot28, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i32 2, ptr %p3424, align 4, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot27, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  store i32 1, ptr %p3426, align 4, !alias.scope !3, !noalias !4
  %v3427 = load i64, ptr %slot24, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %ld3429 = load i32, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3429, ptr %slot373, align 8
  %v3430 = load i32, ptr %slot373, align 8
  %cv3431 = zext i32 %v3430 to i64
  %cond3432 = icmp ne i64 %cv3431, 0
  br i1 %cond3432, label %bb_rcslotdrop596, label %bb_rcslotdone596
bb_rcslotdrop596:
  %v3433 = load i64, ptr %slot24, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  store i32 0, ptr %p3434, align 4, !alias.scope !3, !noalias !4
  %v3435 = load i64, ptr %slot30, align 8
  store i64 %v3435, ptr %slot374, align 8
  %v3436 = load i64, ptr %slot25, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %ld3438 = load i32, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3438, ptr %slot375, align 8
  %v3439 = load i32, ptr %slot375, align 8
  %op3440 = and i32 %v3439, 28
  store i32 %op3440, ptr %slot376, align 8
  %v3441 = load i32, ptr %slot376, align 8
  %cv3442 = zext i32 %v3441 to i64
  %cond3443 = icmp ne i64 %cv3442, 0
  br i1 %cond3443, label %bb_rcslotrole596, label %bb_rcslotowner596
bb_rcslotrole596:
  %v3444 = load i64, ptr %slot73, align 8
  store i64 %v3444, ptr %slot377, align 8
  %v3445 = load i64, ptr %slot377, align 8
  %v3446 = load i64, ptr %slot374, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v3445, i64 %v3446) nomerge, !dbg !132
  br label %bb_rcslotdone596
bb_rcslotowner596:
  %v3447 = load i64, ptr %slot73, align 8
  store i64 %v3447, ptr %slot378, align 8
  %v3448 = load i64, ptr %slot378, align 8
  %v3449 = load i64, ptr %slot374, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v3448, i64 %v3449) nomerge, !dbg !132
  br label %bb_rcslotdone596
bb_rcslotdone596:
  br label %bb_rcprepared555
bb_rcprepared555:
  %v3450 = load i64, ptr %slot32, align 8
  store i64 %v3450, ptr %slot379, align 8
  %v3451 = load i64, ptr %slot379, align 8
  %v3452 = load i64, ptr %slot343, align 8
  %p3453 = inttoptr i64 %v3451 to ptr
  %p3454 = inttoptr i64 %v3452 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3454, ptr %p3453, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3455 = load i64, ptr %slot27, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i32 0, ptr %p3456, align 4, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot339, align 8
  %v3458 = load i64, ptr %slot52, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  store i64 %v3457, ptr %p3459, align 8, !alias.scope !3, !noalias !4
  %p3460 = inttoptr i64 ptrtoint (ptr @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p3460, i64 31) "call-inline-cost"="0", !dbg !132
  %v3461 = load i64, ptr %slot52, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %ld3463 = load i64, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3463, ptr %slot380, align 8
  %v3464 = load i64, ptr %slot30, align 8
  store i64 %v3464, ptr %slot381, align 8
  %v3465 = load i64, ptr %slot380, align 8
  %v3466 = load i64, ptr %slot381, align 8
  %p3467 = inttoptr i64 %v3465 to ptr
  %p3468 = inttoptr i64 %v3466 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3468, ptr %p3467, i64 24, i1 false)
  %v3469 = load i64, ptr %slot25, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  store i32 2, ptr %p3470, align 4, !alias.scope !3, !noalias !4
  %v3471 = load i64, ptr %slot24, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i32 1, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot381, align 8
  %v3474 = load i64, ptr %slot52, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  store i64 %v3473, ptr %p3475, align 8, !alias.scope !3, !noalias !4
  %v3476 = load i64, ptr %slot52, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %ld3478 = load i64, ptr %p3477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3478, ptr %slot382, align 8
  %v3479 = load i64, ptr %slot52, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  %ld3481 = load i64, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3481, ptr %slot383, align 8
  %v3482 = load i64, ptr %slot32, align 8
  store i64 %v3482, ptr %slot384, align 8
  %v3483 = load i64, ptr %slot74, align 8
  store i64 %v3483, ptr %slot385, align 8
  %v3484 = load i64, ptr %slot73, align 8
  %v3485 = load i64, ptr %slot384, align 8
  %v3486 = load i64, ptr %slot383, align 8
  %v3487 = load i64, ptr %slot385, align 8
  %cv3488 = trunc i64 %v3487 to i32
  %call3489 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3484, i64 %v3485, i64 %v3486, i32 %cv3488) nomerge, !dbg !134
  store i32 %call3489, ptr %slot386, align 8
  %v3490 = load i32, ptr %slot386, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcsuccess614, label %bb_rcfailure614
bb_rcfailure614:
  %v3493 = load i64, ptr %slot73, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  %call3495 = call i32 @myl_rc_take_failure(ptr %p3494) nomerge, !dbg !134
  store i32 %call3495, ptr %slot387, align 8
  %v3496 = load i64, ptr %slot1, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %v3498 = load i32, ptr %slot387, align 8
  %call3499 = call i32 @myl_qbe_rc_status(ptr %p3497, i32 %v3498) nomerge, !dbg !134
  store i32 %call3499, ptr %slot388, align 8
  br label %bb_failure
bb_rcsuccess614:
  %v3500 = load i64, ptr %slot24, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i32 0, ptr %p3501, align 4, !alias.scope !3, !noalias !4
  %v3502 = load i64, ptr %slot28, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  store i32 2, ptr %p3503, align 4, !alias.scope !3, !noalias !4
  %v3504 = load i64, ptr %slot27, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i32 1, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  %v3506 = load i64, ptr %slot32, align 8
  store i64 %v3506, ptr %slot389, align 8
  %v3507 = load i64, ptr %slot27, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  store i32 0, ptr %p3508, align 4, !alias.scope !3, !noalias !4
  %v3509 = load i64, ptr %slot33, align 8
  %p3511 = inttoptr i64 %v3509 to ptr
  %gep3512 = getelementptr i8, ptr %p3511, i64 24
  %op3510 = ptrtoint ptr %gep3512 to i64
  store i64 %op3510, ptr %slot390, align 8
  %v3513 = load i64, ptr %slot390, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  %ld3515 = load i32, ptr %p3514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3515, ptr %slot391, align 8
  %v3516 = load i32, ptr %slot391, align 8
  %cv3517 = zext i32 %v3516 to i64
  %cond3518 = icmp ne i64 %cv3517, 0
  br i1 %cond3518, label %bb_rcscopesopen624, label %bb_rcscopesclosed624
bb_rcscopesopen624:
  %v3519 = load i64, ptr %slot35, align 8
  %p3521 = inttoptr i64 %v3519 to ptr
  %gep3522 = getelementptr i8, ptr %p3521, i64 0
  %op3520 = ptrtoint ptr %gep3522 to i64
  store i64 %op3520, ptr %slot392, align 8
  %v3523 = load i64, ptr %slot33, align 8
  %v3524 = load i64, ptr %slot392, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  store i64 %v3523, ptr %p3525, align 8, !alias.scope !3, !noalias !4
  %v3526 = load i64, ptr %slot1, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %v3528 = load i64, ptr %slot35, align 8
  %p3529 = inttoptr i64 %v3528 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p3527, ptr %p3529, i64 1) nomerge, !dbg !134
  br label %bb_rcscopesclosed624
bb_rcscopesclosed624:
  %v3530 = load i64, ptr %slot24, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %ld3532 = load i32, ptr %p3531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3532, ptr %slot393, align 8
  %v3533 = load i32, ptr %slot393, align 8
  %cv3534 = zext i32 %v3533 to i64
  %cond3535 = icmp ne i64 %cv3534, 0
  br i1 %cond3535, label %bb_rcslotdrop628, label %bb_rcslotdone628
bb_rcslotdrop628:
  %v3536 = load i64, ptr %slot24, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  store i32 0, ptr %p3537, align 4, !alias.scope !3, !noalias !4
  %v3538 = load i64, ptr %slot30, align 8
  store i64 %v3538, ptr %slot394, align 8
  %v3539 = load i64, ptr %slot25, align 8
  %p3540 = inttoptr i64 %v3539 to ptr
  %ld3541 = load i32, ptr %p3540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3541, ptr %slot395, align 8
  %v3542 = load i32, ptr %slot395, align 8
  %op3543 = and i32 %v3542, 28
  store i32 %op3543, ptr %slot396, align 8
  %v3544 = load i32, ptr %slot396, align 8
  %cv3545 = zext i32 %v3544 to i64
  %cond3546 = icmp ne i64 %cv3545, 0
  br i1 %cond3546, label %bb_rcslotrole628, label %bb_rcslotowner628
bb_rcslotrole628:
  %v3547 = load i64, ptr %slot73, align 8
  store i64 %v3547, ptr %slot397, align 8
  %v3548 = load i64, ptr %slot397, align 8
  %v3549 = load i64, ptr %slot394, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3548, i64 %v3549) nomerge, !dbg !134
  br label %bb_rcslotdone628
bb_rcslotowner628:
  %v3550 = load i64, ptr %slot73, align 8
  store i64 %v3550, ptr %slot398, align 8
  %v3551 = load i64, ptr %slot398, align 8
  %v3552 = load i64, ptr %slot394, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3551, i64 %v3552) nomerge, !dbg !134
  br label %bb_rcslotdone628
bb_rcslotdone628:
  %v3553 = load i64, ptr %slot22, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  %ld3555 = load i32, ptr %p3554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3555, ptr %slot399, align 8
  %v3556 = load i32, ptr %slot399, align 8
  %cv3557 = zext i32 %v3556 to i64
  %cond3558 = icmp ne i64 %cv3557, 0
  br i1 %cond3558, label %bb_rcslotdrop655, label %bb_rcslotdone655
bb_rcslotdrop655:
  %v3559 = load i64, ptr %slot22, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  store i32 0, ptr %p3560, align 4, !alias.scope !3, !noalias !4
  %v3561 = load i64, ptr %slot51, align 8
  store i64 %v3561, ptr %slot400, align 8
  %v3562 = load i64, ptr %slot23, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  %ld3564 = load i32, ptr %p3563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3564, ptr %slot401, align 8
  %v3565 = load i32, ptr %slot401, align 8
  %op3566 = and i32 %v3565, 28
  store i32 %op3566, ptr %slot402, align 8
  %v3567 = load i32, ptr %slot402, align 8
  %cv3568 = zext i32 %v3567 to i64
  %cond3569 = icmp ne i64 %cv3568, 0
  br i1 %cond3569, label %bb_rcslotrole655, label %bb_rcslotowner655
bb_rcslotrole655:
  %v3570 = load i64, ptr %slot73, align 8
  store i64 %v3570, ptr %slot403, align 8
  %v3571 = load i64, ptr %slot403, align 8
  %v3572 = load i64, ptr %slot400, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3571, i64 %v3572) nomerge, !dbg !134
  br label %bb_rcslotdone655
bb_rcslotowner655:
  %v3573 = load i64, ptr %slot73, align 8
  store i64 %v3573, ptr %slot404, align 8
  %v3574 = load i64, ptr %slot404, align 8
  %v3575 = load i64, ptr %slot400, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3574, i64 %v3575) nomerge, !dbg !134
  br label %bb_rcslotdone655
bb_rcslotdone655:
  %v3576 = load i64, ptr %slot20, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %ld3578 = load i32, ptr %p3577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3578, ptr %slot405, align 8
  %v3579 = load i32, ptr %slot405, align 8
  %cv3580 = zext i32 %v3579 to i64
  %cond3581 = icmp ne i64 %cv3580, 0
  br i1 %cond3581, label %bb_rcslotdrop682, label %bb_rcslotdone682
bb_rcslotdrop682:
  %v3582 = load i64, ptr %slot20, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  store i32 0, ptr %p3583, align 4, !alias.scope !3, !noalias !4
  %v3584 = load i64, ptr %slot49, align 8
  store i64 %v3584, ptr %slot406, align 8
  %v3585 = load i64, ptr %slot21, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  %ld3587 = load i32, ptr %p3586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3587, ptr %slot407, align 8
  %v3588 = load i32, ptr %slot407, align 8
  %op3589 = and i32 %v3588, 28
  store i32 %op3589, ptr %slot408, align 8
  %v3590 = load i32, ptr %slot408, align 8
  %cv3591 = zext i32 %v3590 to i64
  %cond3592 = icmp ne i64 %cv3591, 0
  br i1 %cond3592, label %bb_rcslotrole682, label %bb_rcslotowner682
bb_rcslotrole682:
  %v3593 = load i64, ptr %slot73, align 8
  store i64 %v3593, ptr %slot409, align 8
  %v3594 = load i64, ptr %slot409, align 8
  %v3595 = load i64, ptr %slot406, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3594, i64 %v3595) nomerge, !dbg !134
  br label %bb_rcslotdone682
bb_rcslotowner682:
  %v3596 = load i64, ptr %slot73, align 8
  store i64 %v3596, ptr %slot410, align 8
  %v3597 = load i64, ptr %slot410, align 8
  %v3598 = load i64, ptr %slot406, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3597, i64 %v3598) nomerge, !dbg !134
  br label %bb_rcslotdone682
bb_rcslotdone682:
  %v3599 = load i64, ptr %slot18, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  %ld3601 = load i32, ptr %p3600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3601, ptr %slot411, align 8
  %v3602 = load i32, ptr %slot411, align 8
  %cv3603 = zext i32 %v3602 to i64
  %cond3604 = icmp ne i64 %cv3603, 0
  br i1 %cond3604, label %bb_rcslotdrop691, label %bb_rcslotdone691
bb_rcslotdrop691:
  %v3605 = load i64, ptr %slot18, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  store i32 0, ptr %p3606, align 4, !alias.scope !3, !noalias !4
  %v3607 = load i64, ptr %slot47, align 8
  store i64 %v3607, ptr %slot412, align 8
  %v3608 = load i64, ptr %slot19, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i32, ptr %p3609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3610, ptr %slot413, align 8
  %v3611 = load i32, ptr %slot413, align 8
  %op3612 = and i32 %v3611, 28
  store i32 %op3612, ptr %slot414, align 8
  %v3613 = load i32, ptr %slot414, align 8
  %cv3614 = zext i32 %v3613 to i64
  %cond3615 = icmp ne i64 %cv3614, 0
  br i1 %cond3615, label %bb_rcslotrole691, label %bb_rcslotowner691
bb_rcslotrole691:
  %v3616 = load i64, ptr %slot73, align 8
  store i64 %v3616, ptr %slot415, align 8
  %v3617 = load i64, ptr %slot415, align 8
  %v3618 = load i64, ptr %slot412, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3617, i64 %v3618) nomerge, !dbg !134
  br label %bb_rcslotdone691
bb_rcslotowner691:
  %v3619 = load i64, ptr %slot73, align 8
  store i64 %v3619, ptr %slot416, align 8
  %v3620 = load i64, ptr %slot416, align 8
  %v3621 = load i64, ptr %slot412, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3620, i64 %v3621) nomerge, !dbg !134
  br label %bb_rcslotdone691
bb_rcslotdone691:
  %v3622 = load i64, ptr %slot16, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %ld3624 = load i32, ptr %p3623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3624, ptr %slot417, align 8
  %v3625 = load i32, ptr %slot417, align 8
  %cv3626 = zext i32 %v3625 to i64
  %cond3627 = icmp ne i64 %cv3626, 0
  br i1 %cond3627, label %bb_rcslotdrop737, label %bb_rcslotdone737
bb_rcslotdrop737:
  %v3628 = load i64, ptr %slot16, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  store i32 0, ptr %p3629, align 4, !alias.scope !3, !noalias !4
  %v3630 = load i64, ptr %slot45, align 8
  store i64 %v3630, ptr %slot418, align 8
  %v3631 = load i64, ptr %slot17, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  %ld3633 = load i32, ptr %p3632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3633, ptr %slot419, align 8
  %v3634 = load i32, ptr %slot419, align 8
  %op3635 = and i32 %v3634, 28
  store i32 %op3635, ptr %slot420, align 8
  %v3636 = load i32, ptr %slot420, align 8
  %cv3637 = zext i32 %v3636 to i64
  %cond3638 = icmp ne i64 %cv3637, 0
  br i1 %cond3638, label %bb_rcslotrole737, label %bb_rcslotowner737
bb_rcslotrole737:
  %v3639 = load i64, ptr %slot73, align 8
  store i64 %v3639, ptr %slot421, align 8
  %v3640 = load i64, ptr %slot421, align 8
  %v3641 = load i64, ptr %slot418, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3640, i64 %v3641) nomerge, !dbg !134
  br label %bb_rcslotdone737
bb_rcslotowner737:
  %v3642 = load i64, ptr %slot73, align 8
  store i64 %v3642, ptr %slot422, align 8
  %v3643 = load i64, ptr %slot422, align 8
  %v3644 = load i64, ptr %slot418, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3643, i64 %v3644) nomerge, !dbg !134
  br label %bb_rcslotdone737
bb_rcslotdone737:
  %v3645 = load i64, ptr %slot14, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  %ld3647 = load i32, ptr %p3646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3647, ptr %slot423, align 8
  %v3648 = load i32, ptr %slot423, align 8
  %cv3649 = zext i32 %v3648 to i64
  %cond3650 = icmp ne i64 %cv3649, 0
  br i1 %cond3650, label %bb_rcslotdrop746, label %bb_rcslotdone746
bb_rcslotdrop746:
  %v3651 = load i64, ptr %slot14, align 8
  %p3652 = inttoptr i64 %v3651 to ptr
  store i32 0, ptr %p3652, align 4, !alias.scope !3, !noalias !4
  %v3653 = load i64, ptr %slot44, align 8
  store i64 %v3653, ptr %slot424, align 8
  %v3654 = load i64, ptr %slot15, align 8
  %p3655 = inttoptr i64 %v3654 to ptr
  %ld3656 = load i32, ptr %p3655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3656, ptr %slot425, align 8
  %v3657 = load i32, ptr %slot425, align 8
  %op3658 = and i32 %v3657, 28
  store i32 %op3658, ptr %slot426, align 8
  %v3659 = load i32, ptr %slot426, align 8
  %cv3660 = zext i32 %v3659 to i64
  %cond3661 = icmp ne i64 %cv3660, 0
  br i1 %cond3661, label %bb_rcslotrole746, label %bb_rcslotowner746
bb_rcslotrole746:
  %v3662 = load i64, ptr %slot73, align 8
  store i64 %v3662, ptr %slot427, align 8
  %v3663 = load i64, ptr %slot427, align 8
  %v3664 = load i64, ptr %slot424, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3663, i64 %v3664) nomerge, !dbg !134
  br label %bb_rcslotdone746
bb_rcslotowner746:
  %v3665 = load i64, ptr %slot73, align 8
  store i64 %v3665, ptr %slot428, align 8
  %v3666 = load i64, ptr %slot428, align 8
  %v3667 = load i64, ptr %slot424, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3666, i64 %v3667) nomerge, !dbg !134
  br label %bb_rcslotdone746
bb_rcslotdone746:
  %v3668 = load i64, ptr %slot12, align 8
  %p3669 = inttoptr i64 %v3668 to ptr
  %ld3670 = load i32, ptr %p3669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3670, ptr %slot429, align 8
  %v3671 = load i32, ptr %slot429, align 8
  %cv3672 = zext i32 %v3671 to i64
  %cond3673 = icmp ne i64 %cv3672, 0
  br i1 %cond3673, label %bb_rcslotdrop755, label %bb_rcslotdone755
bb_rcslotdrop755:
  %v3674 = load i64, ptr %slot12, align 8
  %p3675 = inttoptr i64 %v3674 to ptr
  store i32 0, ptr %p3675, align 4, !alias.scope !3, !noalias !4
  %v3676 = load i64, ptr %slot43, align 8
  store i64 %v3676, ptr %slot430, align 8
  %v3677 = load i64, ptr %slot13, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %ld3679 = load i32, ptr %p3678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3679, ptr %slot431, align 8
  %v3680 = load i32, ptr %slot431, align 8
  %op3681 = and i32 %v3680, 28
  store i32 %op3681, ptr %slot432, align 8
  %v3682 = load i32, ptr %slot432, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcslotrole755, label %bb_rcslotowner755
bb_rcslotrole755:
  %v3685 = load i64, ptr %slot73, align 8
  store i64 %v3685, ptr %slot433, align 8
  %v3686 = load i64, ptr %slot433, align 8
  %v3687 = load i64, ptr %slot430, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3686, i64 %v3687) nomerge, !dbg !134
  br label %bb_rcslotdone755
bb_rcslotowner755:
  %v3688 = load i64, ptr %slot73, align 8
  store i64 %v3688, ptr %slot434, align 8
  %v3689 = load i64, ptr %slot434, align 8
  %v3690 = load i64, ptr %slot430, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3689, i64 %v3690) nomerge, !dbg !134
  br label %bb_rcslotdone755
bb_rcslotdone755:
  %v3691 = load i64, ptr %slot10, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  %ld3693 = load i32, ptr %p3692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3693, ptr %slot435, align 8
  %v3694 = load i32, ptr %slot435, align 8
  %cv3695 = zext i32 %v3694 to i64
  %cond3696 = icmp ne i64 %cv3695, 0
  br i1 %cond3696, label %bb_rcslotdrop764, label %bb_rcslotdone764
bb_rcslotdrop764:
  %v3697 = load i64, ptr %slot10, align 8
  %p3698 = inttoptr i64 %v3697 to ptr
  store i32 0, ptr %p3698, align 4, !alias.scope !3, !noalias !4
  %v3699 = load i64, ptr %slot41, align 8
  store i64 %v3699, ptr %slot436, align 8
  %v3700 = load i64, ptr %slot11, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %ld3702 = load i32, ptr %p3701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3702, ptr %slot437, align 8
  %v3703 = load i32, ptr %slot437, align 8
  %op3704 = and i32 %v3703, 28
  store i32 %op3704, ptr %slot438, align 8
  %v3705 = load i32, ptr %slot438, align 8
  %cv3706 = zext i32 %v3705 to i64
  %cond3707 = icmp ne i64 %cv3706, 0
  br i1 %cond3707, label %bb_rcslotrole764, label %bb_rcslotowner764
bb_rcslotrole764:
  %v3708 = load i64, ptr %slot73, align 8
  store i64 %v3708, ptr %slot439, align 8
  %v3709 = load i64, ptr %slot439, align 8
  %v3710 = load i64, ptr %slot436, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3709, i64 %v3710) nomerge, !dbg !134
  br label %bb_rcslotdone764
bb_rcslotowner764:
  %v3711 = load i64, ptr %slot73, align 8
  store i64 %v3711, ptr %slot440, align 8
  %v3712 = load i64, ptr %slot440, align 8
  %v3713 = load i64, ptr %slot436, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3712, i64 %v3713) nomerge, !dbg !134
  br label %bb_rcslotdone764
bb_rcslotdone764:
  %v3714 = load i64, ptr %slot8, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  %ld3716 = load i32, ptr %p3715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3716, ptr %slot441, align 8
  %v3717 = load i32, ptr %slot441, align 8
  %cv3718 = zext i32 %v3717 to i64
  %cond3719 = icmp ne i64 %cv3718, 0
  br i1 %cond3719, label %bb_rcslotdrop773, label %bb_rcslotdone773
bb_rcslotdrop773:
  %v3720 = load i64, ptr %slot8, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  store i32 0, ptr %p3721, align 4, !alias.scope !3, !noalias !4
  %v3722 = load i64, ptr %slot40, align 8
  store i64 %v3722, ptr %slot442, align 8
  %v3723 = load i64, ptr %slot9, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i32, ptr %p3724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3725, ptr %slot443, align 8
  %v3726 = load i32, ptr %slot443, align 8
  %op3727 = and i32 %v3726, 28
  store i32 %op3727, ptr %slot444, align 8
  %v3728 = load i32, ptr %slot444, align 8
  %cv3729 = zext i32 %v3728 to i64
  %cond3730 = icmp ne i64 %cv3729, 0
  br i1 %cond3730, label %bb_rcslotrole773, label %bb_rcslotowner773
bb_rcslotrole773:
  %v3731 = load i64, ptr %slot73, align 8
  store i64 %v3731, ptr %slot445, align 8
  %v3732 = load i64, ptr %slot445, align 8
  %v3733 = load i64, ptr %slot442, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3732, i64 %v3733) nomerge, !dbg !134
  br label %bb_rcslotdone773
bb_rcslotowner773:
  %v3734 = load i64, ptr %slot73, align 8
  store i64 %v3734, ptr %slot446, align 8
  %v3735 = load i64, ptr %slot446, align 8
  %v3736 = load i64, ptr %slot442, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3735, i64 %v3736) nomerge, !dbg !134
  br label %bb_rcslotdone773
bb_rcslotdone773:
  %v3737 = load i64, ptr %slot6, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  %ld3739 = load i32, ptr %p3738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3739, ptr %slot447, align 8
  %v3740 = load i32, ptr %slot447, align 8
  %cv3741 = zext i32 %v3740 to i64
  %cond3742 = icmp ne i64 %cv3741, 0
  br i1 %cond3742, label %bb_rcslotdrop782, label %bb_rcslotdone782
bb_rcslotdrop782:
  %v3743 = load i64, ptr %slot6, align 8
  %p3744 = inttoptr i64 %v3743 to ptr
  store i32 0, ptr %p3744, align 4, !alias.scope !3, !noalias !4
  %v3745 = load i64, ptr %slot38, align 8
  store i64 %v3745, ptr %slot448, align 8
  %v3746 = load i64, ptr %slot7, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %ld3748 = load i32, ptr %p3747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3748, ptr %slot449, align 8
  %v3749 = load i32, ptr %slot449, align 8
  %op3750 = and i32 %v3749, 28
  store i32 %op3750, ptr %slot450, align 8
  %v3751 = load i32, ptr %slot450, align 8
  %cv3752 = zext i32 %v3751 to i64
  %cond3753 = icmp ne i64 %cv3752, 0
  br i1 %cond3753, label %bb_rcslotrole782, label %bb_rcslotowner782
bb_rcslotrole782:
  %v3754 = load i64, ptr %slot73, align 8
  store i64 %v3754, ptr %slot451, align 8
  %v3755 = load i64, ptr %slot451, align 8
  %v3756 = load i64, ptr %slot448, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v3755, i64 %v3756) nomerge, !dbg !134
  br label %bb_rcslotdone782
bb_rcslotowner782:
  %v3757 = load i64, ptr %slot73, align 8
  store i64 %v3757, ptr %slot452, align 8
  %v3758 = load i64, ptr %slot452, align 8
  %v3759 = load i64, ptr %slot448, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v3758, i64 %v3759) nomerge, !dbg !134
  br label %bb_rcslotdone782
bb_rcslotdone782:
  %v3760 = load i64, ptr %slot389, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3761, i64 24, i1 false)
  ret void
bb_i33:
  %v3762 = load i64, ptr %slot36, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i64, ptr %p3763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3764, ptr %slot453, align 8
  %v3765 = load i64, ptr %slot453, align 8
  %v3766 = load i64, ptr %slot52, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  store i64 %v3765, ptr %p3767, align 8, !alias.scope !3, !noalias !4
  %v3768 = load i64, ptr %slot37, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  %ld3770 = load i64, ptr %p3769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3770, ptr %slot454, align 8
  %v3771 = load i64, ptr %slot454, align 8
  %v3772 = load i64, ptr %slot53, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  store i64 %v3771, ptr %p3773, align 8, !alias.scope !3, !noalias !4
  %v3774 = load i64, ptr %slot53, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  %ld3776 = load i64, ptr %p3775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3776, ptr %slot455, align 8
  %v3777 = load i64, ptr %slot455, align 8
  %op3778 = add i64 %v3777, 56
  store i64 %op3778, ptr %slot456, align 8
  %v3779 = load i64, ptr %slot456, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3781, ptr %slot457, align 8
  %v3782 = load i64, ptr %slot457, align 8
  %v3783 = load i64, ptr %slot53, align 8
  %p3784 = inttoptr i64 %v3783 to ptr
  store i64 %v3782, ptr %p3784, align 8, !alias.scope !3, !noalias !4
  %v3785 = load i64, ptr %slot52, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot458, align 8
  %v3788 = load i64, ptr %slot53, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %ld3790 = load i64, ptr %p3789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3790, ptr %slot459, align 8
  %v3791 = load i64, ptr %slot1, align 8
  %v3792 = load i64, ptr %slot458, align 8
  %v3793 = load i64, ptr %slot459, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult461, i64 %v3791, i64 %v3792, i64 %v3793) nomerge, !dbg !136
  %addr3794 = ptrtoint ptr %callresult461 to i64
  store i64 %addr3794, ptr %slot460, align 8
  %v3795 = load i64, ptr %slot460, align 8
  %v3796 = load i64, ptr %slot52, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  store i64 %v3795, ptr %p3797, align 8, !alias.scope !3, !noalias !4
  %v3798 = load i64, ptr %slot52, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i64, ptr %p3799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3800, ptr %slot462, align 8
  %v3801 = load i64, ptr %slot32, align 8
  store i64 %v3801, ptr %slot463, align 8
  %v3802 = load i64, ptr %slot462, align 8
  %v3803 = load i64, ptr %slot463, align 8
  %p3804 = inttoptr i64 %v3802 to ptr
  %p3805 = inttoptr i64 %v3803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3805, ptr %p3804, i64 24, i1 false)
  %v3806 = load i64, ptr %slot28, align 8
  %p3807 = inttoptr i64 %v3806 to ptr
  store i32 2, ptr %p3807, align 4, !alias.scope !3, !noalias !4
  %v3808 = load i64, ptr %slot27, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  store i32 1, ptr %p3809, align 4, !alias.scope !3, !noalias !4
  %v3810 = load i64, ptr %slot24, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %ld3812 = load i32, ptr %p3811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3812, ptr %slot464, align 8
  %v3813 = load i32, ptr %slot464, align 8
  %cv3814 = zext i32 %v3813 to i64
  %cond3815 = icmp ne i64 %cv3814, 0
  br i1 %cond3815, label %bb_rcslotdrop830, label %bb_rcslotdone830
bb_rcslotdrop830:
  %v3816 = load i64, ptr %slot24, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i32 0, ptr %p3817, align 4, !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot30, align 8
  store i64 %v3818, ptr %slot465, align 8
  %v3819 = load i64, ptr %slot25, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i32, ptr %p3820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3821, ptr %slot466, align 8
  %v3822 = load i32, ptr %slot466, align 8
  %op3823 = and i32 %v3822, 28
  store i32 %op3823, ptr %slot467, align 8
  %v3824 = load i32, ptr %slot467, align 8
  %cv3825 = zext i32 %v3824 to i64
  %cond3826 = icmp ne i64 %cv3825, 0
  br i1 %cond3826, label %bb_rcslotrole830, label %bb_rcslotowner830
bb_rcslotrole830:
  %v3827 = load i64, ptr %slot73, align 8
  store i64 %v3827, ptr %slot468, align 8
  %v3828 = load i64, ptr %slot468, align 8
  %v3829 = load i64, ptr %slot465, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3828, i64 %v3829) nomerge, !dbg !136
  br label %bb_rcslotdone830
bb_rcslotowner830:
  %v3830 = load i64, ptr %slot73, align 8
  store i64 %v3830, ptr %slot469, align 8
  %v3831 = load i64, ptr %slot469, align 8
  %v3832 = load i64, ptr %slot465, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3831, i64 %v3832) nomerge, !dbg !136
  br label %bb_rcslotdone830
bb_rcslotdone830:
  %v3833 = load i64, ptr %slot30, align 8
  store i64 %v3833, ptr %slot470, align 8
  %v3834 = load i64, ptr %slot32, align 8
  store i64 %v3834, ptr %slot471, align 8
  %v3835 = load i64, ptr %slot471, align 8
  %v3836 = load i64, ptr %slot470, align 8
  %p3837 = inttoptr i64 %v3835 to ptr
  %p3838 = inttoptr i64 %v3836 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3838, ptr %p3837, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3839 = load i64, ptr %slot25, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  store i32 2, ptr %p3840, align 4, !alias.scope !3, !noalias !4
  %v3841 = load i64, ptr %slot28, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %ld3843 = load i32, ptr %p3842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3843, ptr %slot472, align 8
  %v3844 = load i32, ptr %slot472, align 8
  %v3845 = load i64, ptr %slot25, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i32 %v3844, ptr %p3846, align 4, !alias.scope !3, !noalias !4
  %v3847 = load i64, ptr %slot27, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  store i32 0, ptr %p3848, align 4, !alias.scope !3, !noalias !4
  %v3849 = load i64, ptr %slot24, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  store i32 1, ptr %p3850, align 4, !alias.scope !3, !noalias !4
  %v3851 = load i64, ptr %slot470, align 8
  %v3852 = load i64, ptr %slot52, align 8
  %p3853 = inttoptr i64 %v3852 to ptr
  store i64 %v3851, ptr %p3853, align 8, !alias.scope !3, !noalias !4
  %v3854 = load i64, ptr %slot52, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  %ld3856 = load i64, ptr %p3855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3856, ptr %slot473, align 8
  %v3857 = load i64, ptr %slot473, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  %ld3859 = load i32, ptr %p3858, align 4
  %ext3860 = zext i32 %ld3859 to i64
  store i64 %ext3860, ptr %slot474, align 8
  %v3861 = load i64, ptr %slot474, align 8
  %cmp3862 = icmp eq i64 %v3861, 0
  %cv3863 = zext i1 %cmp3862 to i64
  store i64 %cv3863, ptr %slot475, align 8
  %v3864 = load i64, ptr %slot475, align 8
  %cond3865 = icmp ne i64 %v3864, 0
  br i1 %cond3865, label %bb_rctryok846, label %bb_rctryerror846
bb_rctryerror846:
  %p3866 = inttoptr i64 ptrtoint (ptr @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3866, i64 12884901925) "call-inline-cost"="0", !dbg !138
  %v3867 = load i64, ptr %slot473, align 8
  %op3868 = add i64 %v3867, 8
  store i64 %op3868, ptr %slot476, align 8
  %v3869 = load i64, ptr %slot59, align 8
  store i64 %v3869, ptr %slot477, align 8
  %v3870 = load i64, ptr %slot477, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  store i64 0, ptr %p3871, align 8, !alias.scope !3, !noalias !4
  %v3872 = load i64, ptr %slot477, align 8
  %p3874 = inttoptr i64 %v3872 to ptr
  %gep3875 = getelementptr i8, ptr %p3874, i64 8
  %op3873 = ptrtoint ptr %gep3875 to i64
  store i64 %op3873, ptr %slot478, align 8
  %v3876 = load i64, ptr %slot478, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  store i64 0, ptr %p3877, align 8, !alias.scope !3, !noalias !4
  %v3878 = load i64, ptr %slot477, align 8
  %p3880 = inttoptr i64 %v3878 to ptr
  %gep3881 = getelementptr i8, ptr %p3880, i64 16
  %op3879 = ptrtoint ptr %gep3881 to i64
  store i64 %op3879, ptr %slot479, align 8
  %v3882 = load i64, ptr %slot479, align 8
  %p3883 = inttoptr i64 %v3882 to ptr
  store i64 0, ptr %p3883, align 8, !alias.scope !3, !noalias !4
  %v3884 = load i64, ptr %slot477, align 8
  %p3885 = inttoptr i64 %v3884 to ptr
  store i32 1, ptr %p3885, align 4, !alias.scope !3, !noalias !4
  %v3886 = load i64, ptr %slot477, align 8
  %p3888 = inttoptr i64 %v3886 to ptr
  %gep3889 = getelementptr i8, ptr %p3888, i64 8
  %op3887 = ptrtoint ptr %gep3889 to i64
  store i64 %op3887, ptr %slot480, align 8
  %v3890 = load i64, ptr %slot29, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  store i32 1, ptr %p3891, align 4, !alias.scope !3, !noalias !4
  %v3892 = load i64, ptr %slot74, align 8
  store i64 %v3892, ptr %slot481, align 8
  %v3893 = load i64, ptr %slot73, align 8
  %v3894 = load i64, ptr %slot480, align 8
  %v3895 = load i64, ptr %slot476, align 8
  %v3896 = load i64, ptr %slot481, align 8
  %cv3897 = trunc i64 %v3896 to i32
  %call3898 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v3893, i64 %v3894, i64 %v3895, i32 %cv3897) nomerge, !dbg !138
  store i32 %call3898, ptr %slot482, align 8
  %v3899 = load i32, ptr %slot482, align 8
  %cv3900 = zext i32 %v3899 to i64
  %cond3901 = icmp ne i64 %cv3900, 0
  br i1 %cond3901, label %bb_rcsuccess857, label %bb_rcfailure857
bb_rcfailure857:
  %v3902 = load i64, ptr %slot73, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  %call3904 = call i32 @myl_rc_take_failure(ptr %p3903) nomerge, !dbg !138
  store i32 %call3904, ptr %slot483, align 8
  %v3905 = load i64, ptr %slot1, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %v3907 = load i32, ptr %slot483, align 8
  %call3908 = call i32 @myl_qbe_rc_status(ptr %p3906, i32 %v3907) nomerge, !dbg !138
  store i32 %call3908, ptr %slot484, align 8
  br label %bb_failure
bb_rcsuccess857:
  %v3909 = load i64, ptr %slot477, align 8
  %v3910 = load i64, ptr %slot52, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i64 %v3909, ptr %p3911, align 8, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot52, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i64, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3914, ptr %slot485, align 8
  %v3915 = load i64, ptr %slot32, align 8
  store i64 %v3915, ptr %slot486, align 8
  %v3916 = load i64, ptr %slot485, align 8
  %v3917 = load i64, ptr %slot486, align 8
  %p3918 = inttoptr i64 %v3916 to ptr
  %p3919 = inttoptr i64 %v3917 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3919, ptr %p3918, i64 24, i1 false)
  %v3920 = load i64, ptr %slot28, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i32 2, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot27, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  store i32 1, ptr %p3923, align 4, !alias.scope !3, !noalias !4
  %v3924 = load i64, ptr %slot24, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %ld3926 = load i32, ptr %p3925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3926, ptr %slot487, align 8
  %v3927 = load i32, ptr %slot487, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rcslotdrop866, label %bb_rcslotdone866
bb_rcslotdrop866:
  %v3930 = load i64, ptr %slot24, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  store i32 0, ptr %p3931, align 4, !alias.scope !3, !noalias !4
  %v3932 = load i64, ptr %slot30, align 8
  store i64 %v3932, ptr %slot488, align 8
  %v3933 = load i64, ptr %slot25, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %ld3935 = load i32, ptr %p3934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3935, ptr %slot489, align 8
  %v3936 = load i32, ptr %slot489, align 8
  %op3937 = and i32 %v3936, 28
  store i32 %op3937, ptr %slot490, align 8
  %v3938 = load i32, ptr %slot490, align 8
  %cv3939 = zext i32 %v3938 to i64
  %cond3940 = icmp ne i64 %cv3939, 0
  br i1 %cond3940, label %bb_rcslotrole866, label %bb_rcslotowner866
bb_rcslotrole866:
  %v3941 = load i64, ptr %slot73, align 8
  store i64 %v3941, ptr %slot491, align 8
  %v3942 = load i64, ptr %slot491, align 8
  %v3943 = load i64, ptr %slot488, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3942, i64 %v3943) nomerge, !dbg !138
  br label %bb_rcslotdone866
bb_rcslotowner866:
  %v3944 = load i64, ptr %slot73, align 8
  store i64 %v3944, ptr %slot492, align 8
  %v3945 = load i64, ptr %slot492, align 8
  %v3946 = load i64, ptr %slot488, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3945, i64 %v3946) nomerge, !dbg !138
  br label %bb_rcslotdone866
bb_rcslotdone866:
  %v3947 = load i64, ptr %slot30, align 8
  store i64 %v3947, ptr %slot493, align 8
  %v3948 = load i64, ptr %slot32, align 8
  store i64 %v3948, ptr %slot494, align 8
  %v3949 = load i64, ptr %slot494, align 8
  %v3950 = load i64, ptr %slot493, align 8
  %p3951 = inttoptr i64 %v3949 to ptr
  %p3952 = inttoptr i64 %v3950 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3952, ptr %p3951, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3953 = load i64, ptr %slot25, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  store i32 2, ptr %p3954, align 4, !alias.scope !3, !noalias !4
  %v3955 = load i64, ptr %slot28, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %ld3957 = load i32, ptr %p3956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3957, ptr %slot495, align 8
  %v3958 = load i32, ptr %slot495, align 8
  %v3959 = load i64, ptr %slot25, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i32 %v3958, ptr %p3960, align 4, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot27, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 0, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot24, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 1, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot493, align 8
  %v3966 = load i64, ptr %slot52, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i64 %v3965, ptr %p3967, align 8, !alias.scope !3, !noalias !4
  br label %bb_i39
bb_rctryok846:
  %v3968 = load i64, ptr %slot59, align 8
  store i64 %v3968, ptr %slot496, align 8
  %v3969 = load i64, ptr %slot29, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  store i32 1, ptr %p3970, align 4, !alias.scope !3, !noalias !4
  %v3971 = load i64, ptr %slot473, align 8
  %op3972 = add i64 %v3971, 8
  store i64 %op3972, ptr %slot497, align 8
  %v3973 = load i64, ptr %slot74, align 8
  store i64 %v3973, ptr %slot498, align 8
  store i64 0, ptr %slot499, align 8
  store i64 0, ptr %slot500, align 8
  %v3974 = load i64, ptr %slot500, align 8
  %v3975 = load i64, ptr %slot52, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  store i64 %v3974, ptr %p3976, align 8, !alias.scope !3, !noalias !4
  %v3977 = load i64, ptr %slot24, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ld3979 = load i32, ptr %p3978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3979, ptr %slot501, align 8
  %v3980 = load i32, ptr %slot501, align 8
  %cv3981 = zext i32 %v3980 to i64
  %cond3982 = icmp ne i64 %cv3981, 0
  br i1 %cond3982, label %bb_rcslotdrop890, label %bb_rcslotdone890
bb_rcslotdrop890:
  %v3983 = load i64, ptr %slot24, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  store i32 0, ptr %p3984, align 4, !alias.scope !3, !noalias !4
  %v3985 = load i64, ptr %slot30, align 8
  store i64 %v3985, ptr %slot502, align 8
  %v3986 = load i64, ptr %slot25, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %ld3988 = load i32, ptr %p3987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3988, ptr %slot503, align 8
  %v3989 = load i32, ptr %slot503, align 8
  %op3990 = and i32 %v3989, 28
  store i32 %op3990, ptr %slot504, align 8
  %v3991 = load i32, ptr %slot504, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcslotrole890, label %bb_rcslotowner890
bb_rcslotrole890:
  %v3994 = load i64, ptr %slot73, align 8
  store i64 %v3994, ptr %slot505, align 8
  %v3995 = load i64, ptr %slot505, align 8
  %v3996 = load i64, ptr %slot502, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3995, i64 %v3996) nomerge, !dbg !138
  br label %bb_rcslotdone890
bb_rcslotowner890:
  %v3997 = load i64, ptr %slot73, align 8
  store i64 %v3997, ptr %slot506, align 8
  %v3998 = load i64, ptr %slot506, align 8
  %v3999 = load i64, ptr %slot502, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3998, i64 %v3999) nomerge, !dbg !138
  br label %bb_rcslotdone890
bb_rcslotdone890:
  br label %bb_i40
bb_i39:
  %v4000 = load i64, ptr %slot52, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  %ld4002 = load i64, ptr %p4001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4002, ptr %slot507, align 8
  %v4003 = load i64, ptr %slot52, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %ld4005 = load i64, ptr %p4004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4005, ptr %slot508, align 8
  %v4006 = load i64, ptr %slot24, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %ld4008 = load i32, ptr %p4007, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4008, ptr %slot509, align 8
  %v4009 = load i64, ptr %slot25, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %ld4011 = load i32, ptr %p4010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4011, ptr %slot510, align 8
  %v4012 = load i32, ptr %slot510, align 8
  %op4013 = and i32 %v4012, 24
  store i32 %op4013, ptr %slot510, align 8
  %v4014 = load i32, ptr %slot510, align 8
  %cmp4015 = icmp eq i32 %v4014, 0
  %cv4016 = zext i1 %cmp4015 to i32
  store i32 %cv4016, ptr %slot511, align 8
  %v4017 = load i32, ptr %slot509, align 8
  %v4018 = load i32, ptr %slot511, align 8
  %op4019 = and i32 %v4017, %v4018
  store i32 %op4019, ptr %slot512, align 8
  %v4020 = load i32, ptr %slot512, align 8
  %cv4021 = zext i32 %v4020 to i64
  %cond4022 = icmp ne i64 %cv4021, 0
  br i1 %cond4022, label %bb_rctake899, label %bb_rccopy899
bb_rctake899:
  %v4023 = load i64, ptr %slot32, align 8
  store i64 %v4023, ptr %slot513, align 8
  %v4024 = load i64, ptr %slot74, align 8
  store i64 %v4024, ptr %slot514, align 8
  %v4025 = load i64, ptr %slot73, align 8
  %v4026 = load i64, ptr %slot513, align 8
  %v4027 = load i64, ptr %slot508, align 8
  %v4028 = load i64, ptr %slot514, align 8
  %cv4029 = trunc i64 %v4028 to i32
  %call4030 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4025, i64 %v4026, i64 %v4027, i32 %cv4029) nomerge, !dbg !140
  store i32 %call4030, ptr %slot515, align 8
  %v4031 = load i32, ptr %slot515, align 8
  %cv4032 = zext i32 %v4031 to i64
  %cond4033 = icmp ne i64 %cv4032, 0
  br i1 %cond4033, label %bb_rcsuccess909, label %bb_rcfailure909
bb_rcfailure909:
  %v4034 = load i64, ptr %slot73, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  %call4036 = call i32 @myl_rc_take_failure(ptr %p4035) nomerge, !dbg !140
  store i32 %call4036, ptr %slot516, align 8
  %v4037 = load i64, ptr %slot1, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %v4039 = load i32, ptr %slot516, align 8
  %call4040 = call i32 @myl_qbe_rc_status(ptr %p4038, i32 %v4039) nomerge, !dbg !140
  store i32 %call4040, ptr %slot517, align 8
  br label %bb_failure
bb_rcsuccess909:
  %v4041 = load i64, ptr %slot24, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  store i32 0, ptr %p4042, align 4, !alias.scope !3, !noalias !4
  %v4043 = load i64, ptr %slot28, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  store i32 2, ptr %p4044, align 4, !alias.scope !3, !noalias !4
  %v4045 = load i64, ptr %slot27, align 8
  %p4046 = inttoptr i64 %v4045 to ptr
  store i32 1, ptr %p4046, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared899
bb_rccopy899:
  %v4047 = load i64, ptr %slot32, align 8
  store i64 %v4047, ptr %slot518, align 8
  %v4048 = load i64, ptr %slot74, align 8
  store i64 %v4048, ptr %slot519, align 8
  %v4049 = load i64, ptr %slot73, align 8
  %v4050 = load i64, ptr %slot518, align 8
  %v4051 = load i64, ptr %slot508, align 8
  %v4052 = load i64, ptr %slot519, align 8
  %cv4053 = trunc i64 %v4052 to i32
  %call4054 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v4049, i64 %v4050, i64 %v4051, i32 %cv4053) nomerge, !dbg !140
  store i32 %call4054, ptr %slot520, align 8
  %v4055 = load i32, ptr %slot520, align 8
  %cv4056 = zext i32 %v4055 to i64
  %cond4057 = icmp ne i64 %cv4056, 0
  br i1 %cond4057, label %bb_rcsuccess918, label %bb_rcfailure918
bb_rcfailure918:
  %v4058 = load i64, ptr %slot73, align 8
  %p4059 = inttoptr i64 %v4058 to ptr
  %call4060 = call i32 @myl_rc_take_failure(ptr %p4059) nomerge, !dbg !140
  store i32 %call4060, ptr %slot521, align 8
  %v4061 = load i64, ptr %slot1, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  %v4063 = load i32, ptr %slot521, align 8
  %call4064 = call i32 @myl_qbe_rc_status(ptr %p4062, i32 %v4063) nomerge, !dbg !140
  store i32 %call4064, ptr %slot522, align 8
  br label %bb_failure
bb_rcsuccess918:
  %v4065 = load i64, ptr %slot28, align 8
  %p4066 = inttoptr i64 %v4065 to ptr
  store i32 2, ptr %p4066, align 4, !alias.scope !3, !noalias !4
  %v4067 = load i64, ptr %slot27, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  store i32 1, ptr %p4068, align 4, !alias.scope !3, !noalias !4
  %v4069 = load i64, ptr %slot24, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %ld4071 = load i32, ptr %p4070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4071, ptr %slot523, align 8
  %v4072 = load i32, ptr %slot523, align 8
  %cv4073 = zext i32 %v4072 to i64
  %cond4074 = icmp ne i64 %cv4073, 0
  br i1 %cond4074, label %bb_rcslotdrop925, label %bb_rcslotdone925
bb_rcslotdrop925:
  %v4075 = load i64, ptr %slot24, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  store i32 0, ptr %p4076, align 4, !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot30, align 8
  store i64 %v4077, ptr %slot524, align 8
  %v4078 = load i64, ptr %slot25, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i32, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4080, ptr %slot525, align 8
  %v4081 = load i32, ptr %slot525, align 8
  %op4082 = and i32 %v4081, 28
  store i32 %op4082, ptr %slot526, align 8
  %v4083 = load i32, ptr %slot526, align 8
  %cv4084 = zext i32 %v4083 to i64
  %cond4085 = icmp ne i64 %cv4084, 0
  br i1 %cond4085, label %bb_rcslotrole925, label %bb_rcslotowner925
bb_rcslotrole925:
  %v4086 = load i64, ptr %slot73, align 8
  store i64 %v4086, ptr %slot527, align 8
  %v4087 = load i64, ptr %slot527, align 8
  %v4088 = load i64, ptr %slot524, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4087, i64 %v4088) nomerge, !dbg !140
  br label %bb_rcslotdone925
bb_rcslotowner925:
  %v4089 = load i64, ptr %slot73, align 8
  store i64 %v4089, ptr %slot528, align 8
  %v4090 = load i64, ptr %slot528, align 8
  %v4091 = load i64, ptr %slot524, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4090, i64 %v4091) nomerge, !dbg !140
  br label %bb_rcslotdone925
bb_rcslotdone925:
  br label %bb_rcprepared899
bb_rcprepared899:
  %v4092 = load i64, ptr %slot32, align 8
  store i64 %v4092, ptr %slot529, align 8
  %v4093 = load i64, ptr %slot27, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i32 0, ptr %p4094, align 4, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot33, align 8
  %p4097 = inttoptr i64 %v4095 to ptr
  %gep4098 = getelementptr i8, ptr %p4097, i64 24
  %op4096 = ptrtoint ptr %gep4098 to i64
  store i64 %op4096, ptr %slot530, align 8
  %v4099 = load i64, ptr %slot530, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  %ld4101 = load i32, ptr %p4100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4101, ptr %slot531, align 8
  %v4102 = load i32, ptr %slot531, align 8
  %cv4103 = zext i32 %v4102 to i64
  %cond4104 = icmp ne i64 %cv4103, 0
  br i1 %cond4104, label %bb_rcscopesopen936, label %bb_rcscopesclosed936
bb_rcscopesopen936:
  %v4105 = load i64, ptr %slot35, align 8
  %p4107 = inttoptr i64 %v4105 to ptr
  %gep4108 = getelementptr i8, ptr %p4107, i64 0
  %op4106 = ptrtoint ptr %gep4108 to i64
  store i64 %op4106, ptr %slot532, align 8
  %v4109 = load i64, ptr %slot33, align 8
  %v4110 = load i64, ptr %slot532, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  store i64 %v4109, ptr %p4111, align 8, !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot1, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %v4114 = load i64, ptr %slot35, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p4113, ptr %p4115, i64 1) nomerge, !dbg !140
  br label %bb_rcscopesclosed936
bb_rcscopesclosed936:
  %v4116 = load i64, ptr %slot24, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %ld4118 = load i32, ptr %p4117, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4118, ptr %slot533, align 8
  %v4119 = load i32, ptr %slot533, align 8
  %cv4120 = zext i32 %v4119 to i64
  %cond4121 = icmp ne i64 %cv4120, 0
  br i1 %cond4121, label %bb_rcslotdrop940, label %bb_rcslotdone940
bb_rcslotdrop940:
  %v4122 = load i64, ptr %slot24, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  store i32 0, ptr %p4123, align 4, !alias.scope !3, !noalias !4
  %v4124 = load i64, ptr %slot30, align 8
  store i64 %v4124, ptr %slot534, align 8
  %v4125 = load i64, ptr %slot25, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %ld4127 = load i32, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4127, ptr %slot535, align 8
  %v4128 = load i32, ptr %slot535, align 8
  %op4129 = and i32 %v4128, 28
  store i32 %op4129, ptr %slot536, align 8
  %v4130 = load i32, ptr %slot536, align 8
  %cv4131 = zext i32 %v4130 to i64
  %cond4132 = icmp ne i64 %cv4131, 0
  br i1 %cond4132, label %bb_rcslotrole940, label %bb_rcslotowner940
bb_rcslotrole940:
  %v4133 = load i64, ptr %slot73, align 8
  store i64 %v4133, ptr %slot537, align 8
  %v4134 = load i64, ptr %slot537, align 8
  %v4135 = load i64, ptr %slot534, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4134, i64 %v4135) nomerge, !dbg !140
  br label %bb_rcslotdone940
bb_rcslotowner940:
  %v4136 = load i64, ptr %slot73, align 8
  store i64 %v4136, ptr %slot538, align 8
  %v4137 = load i64, ptr %slot538, align 8
  %v4138 = load i64, ptr %slot534, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4137, i64 %v4138) nomerge, !dbg !140
  br label %bb_rcslotdone940
bb_rcslotdone940:
  %v4139 = load i64, ptr %slot22, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  %ld4141 = load i32, ptr %p4140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4141, ptr %slot539, align 8
  %v4142 = load i32, ptr %slot539, align 8
  %cv4143 = zext i32 %v4142 to i64
  %cond4144 = icmp ne i64 %cv4143, 0
  br i1 %cond4144, label %bb_rcslotdrop967, label %bb_rcslotdone967
bb_rcslotdrop967:
  %v4145 = load i64, ptr %slot22, align 8
  %p4146 = inttoptr i64 %v4145 to ptr
  store i32 0, ptr %p4146, align 4, !alias.scope !3, !noalias !4
  %v4147 = load i64, ptr %slot51, align 8
  store i64 %v4147, ptr %slot540, align 8
  %v4148 = load i64, ptr %slot23, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  %ld4150 = load i32, ptr %p4149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4150, ptr %slot541, align 8
  %v4151 = load i32, ptr %slot541, align 8
  %op4152 = and i32 %v4151, 28
  store i32 %op4152, ptr %slot542, align 8
  %v4153 = load i32, ptr %slot542, align 8
  %cv4154 = zext i32 %v4153 to i64
  %cond4155 = icmp ne i64 %cv4154, 0
  br i1 %cond4155, label %bb_rcslotrole967, label %bb_rcslotowner967
bb_rcslotrole967:
  %v4156 = load i64, ptr %slot73, align 8
  store i64 %v4156, ptr %slot543, align 8
  %v4157 = load i64, ptr %slot543, align 8
  %v4158 = load i64, ptr %slot540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4157, i64 %v4158) nomerge, !dbg !140
  br label %bb_rcslotdone967
bb_rcslotowner967:
  %v4159 = load i64, ptr %slot73, align 8
  store i64 %v4159, ptr %slot544, align 8
  %v4160 = load i64, ptr %slot544, align 8
  %v4161 = load i64, ptr %slot540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4160, i64 %v4161) nomerge, !dbg !140
  br label %bb_rcslotdone967
bb_rcslotdone967:
  %v4162 = load i64, ptr %slot20, align 8
  %p4163 = inttoptr i64 %v4162 to ptr
  %ld4164 = load i32, ptr %p4163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4164, ptr %slot545, align 8
  %v4165 = load i32, ptr %slot545, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcslotdrop994, label %bb_rcslotdone994
bb_rcslotdrop994:
  %v4168 = load i64, ptr %slot20, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  store i32 0, ptr %p4169, align 4, !alias.scope !3, !noalias !4
  %v4170 = load i64, ptr %slot49, align 8
  store i64 %v4170, ptr %slot546, align 8
  %v4171 = load i64, ptr %slot21, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i32, ptr %p4172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4173, ptr %slot547, align 8
  %v4174 = load i32, ptr %slot547, align 8
  %op4175 = and i32 %v4174, 28
  store i32 %op4175, ptr %slot548, align 8
  %v4176 = load i32, ptr %slot548, align 8
  %cv4177 = zext i32 %v4176 to i64
  %cond4178 = icmp ne i64 %cv4177, 0
  br i1 %cond4178, label %bb_rcslotrole994, label %bb_rcslotowner994
bb_rcslotrole994:
  %v4179 = load i64, ptr %slot73, align 8
  store i64 %v4179, ptr %slot549, align 8
  %v4180 = load i64, ptr %slot549, align 8
  %v4181 = load i64, ptr %slot546, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4180, i64 %v4181) nomerge, !dbg !140
  br label %bb_rcslotdone994
bb_rcslotowner994:
  %v4182 = load i64, ptr %slot73, align 8
  store i64 %v4182, ptr %slot550, align 8
  %v4183 = load i64, ptr %slot550, align 8
  %v4184 = load i64, ptr %slot546, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4183, i64 %v4184) nomerge, !dbg !140
  br label %bb_rcslotdone994
bb_rcslotdone994:
  %v4185 = load i64, ptr %slot18, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  %ld4187 = load i32, ptr %p4186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4187, ptr %slot551, align 8
  %v4188 = load i32, ptr %slot551, align 8
  %cv4189 = zext i32 %v4188 to i64
  %cond4190 = icmp ne i64 %cv4189, 0
  br i1 %cond4190, label %bb_rcslotdrop1003, label %bb_rcslotdone1003
bb_rcslotdrop1003:
  %v4191 = load i64, ptr %slot18, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  store i32 0, ptr %p4192, align 4, !alias.scope !3, !noalias !4
  %v4193 = load i64, ptr %slot47, align 8
  store i64 %v4193, ptr %slot552, align 8
  %v4194 = load i64, ptr %slot19, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  %ld4196 = load i32, ptr %p4195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4196, ptr %slot553, align 8
  %v4197 = load i32, ptr %slot553, align 8
  %op4198 = and i32 %v4197, 28
  store i32 %op4198, ptr %slot554, align 8
  %v4199 = load i32, ptr %slot554, align 8
  %cv4200 = zext i32 %v4199 to i64
  %cond4201 = icmp ne i64 %cv4200, 0
  br i1 %cond4201, label %bb_rcslotrole1003, label %bb_rcslotowner1003
bb_rcslotrole1003:
  %v4202 = load i64, ptr %slot73, align 8
  store i64 %v4202, ptr %slot555, align 8
  %v4203 = load i64, ptr %slot555, align 8
  %v4204 = load i64, ptr %slot552, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4203, i64 %v4204) nomerge, !dbg !140
  br label %bb_rcslotdone1003
bb_rcslotowner1003:
  %v4205 = load i64, ptr %slot73, align 8
  store i64 %v4205, ptr %slot556, align 8
  %v4206 = load i64, ptr %slot556, align 8
  %v4207 = load i64, ptr %slot552, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4206, i64 %v4207) nomerge, !dbg !140
  br label %bb_rcslotdone1003
bb_rcslotdone1003:
  %v4208 = load i64, ptr %slot16, align 8
  %p4209 = inttoptr i64 %v4208 to ptr
  %ld4210 = load i32, ptr %p4209, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4210, ptr %slot557, align 8
  %v4211 = load i32, ptr %slot557, align 8
  %cv4212 = zext i32 %v4211 to i64
  %cond4213 = icmp ne i64 %cv4212, 0
  br i1 %cond4213, label %bb_rcslotdrop1049, label %bb_rcslotdone1049
bb_rcslotdrop1049:
  %v4214 = load i64, ptr %slot16, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  store i32 0, ptr %p4215, align 4, !alias.scope !3, !noalias !4
  %v4216 = load i64, ptr %slot45, align 8
  store i64 %v4216, ptr %slot558, align 8
  %v4217 = load i64, ptr %slot17, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  %ld4219 = load i32, ptr %p4218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4219, ptr %slot559, align 8
  %v4220 = load i32, ptr %slot559, align 8
  %op4221 = and i32 %v4220, 28
  store i32 %op4221, ptr %slot560, align 8
  %v4222 = load i32, ptr %slot560, align 8
  %cv4223 = zext i32 %v4222 to i64
  %cond4224 = icmp ne i64 %cv4223, 0
  br i1 %cond4224, label %bb_rcslotrole1049, label %bb_rcslotowner1049
bb_rcslotrole1049:
  %v4225 = load i64, ptr %slot73, align 8
  store i64 %v4225, ptr %slot561, align 8
  %v4226 = load i64, ptr %slot561, align 8
  %v4227 = load i64, ptr %slot558, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4226, i64 %v4227) nomerge, !dbg !140
  br label %bb_rcslotdone1049
bb_rcslotowner1049:
  %v4228 = load i64, ptr %slot73, align 8
  store i64 %v4228, ptr %slot562, align 8
  %v4229 = load i64, ptr %slot562, align 8
  %v4230 = load i64, ptr %slot558, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4229, i64 %v4230) nomerge, !dbg !140
  br label %bb_rcslotdone1049
bb_rcslotdone1049:
  %v4231 = load i64, ptr %slot14, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i32, ptr %p4232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4233, ptr %slot563, align 8
  %v4234 = load i32, ptr %slot563, align 8
  %cv4235 = zext i32 %v4234 to i64
  %cond4236 = icmp ne i64 %cv4235, 0
  br i1 %cond4236, label %bb_rcslotdrop1058, label %bb_rcslotdone1058
bb_rcslotdrop1058:
  %v4237 = load i64, ptr %slot14, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  store i32 0, ptr %p4238, align 4, !alias.scope !3, !noalias !4
  %v4239 = load i64, ptr %slot44, align 8
  store i64 %v4239, ptr %slot564, align 8
  %v4240 = load i64, ptr %slot15, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  %ld4242 = load i32, ptr %p4241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4242, ptr %slot565, align 8
  %v4243 = load i32, ptr %slot565, align 8
  %op4244 = and i32 %v4243, 28
  store i32 %op4244, ptr %slot566, align 8
  %v4245 = load i32, ptr %slot566, align 8
  %cv4246 = zext i32 %v4245 to i64
  %cond4247 = icmp ne i64 %cv4246, 0
  br i1 %cond4247, label %bb_rcslotrole1058, label %bb_rcslotowner1058
bb_rcslotrole1058:
  %v4248 = load i64, ptr %slot73, align 8
  store i64 %v4248, ptr %slot567, align 8
  %v4249 = load i64, ptr %slot567, align 8
  %v4250 = load i64, ptr %slot564, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4249, i64 %v4250) nomerge, !dbg !140
  br label %bb_rcslotdone1058
bb_rcslotowner1058:
  %v4251 = load i64, ptr %slot73, align 8
  store i64 %v4251, ptr %slot568, align 8
  %v4252 = load i64, ptr %slot568, align 8
  %v4253 = load i64, ptr %slot564, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4252, i64 %v4253) nomerge, !dbg !140
  br label %bb_rcslotdone1058
bb_rcslotdone1058:
  %v4254 = load i64, ptr %slot12, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  %ld4256 = load i32, ptr %p4255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4256, ptr %slot569, align 8
  %v4257 = load i32, ptr %slot569, align 8
  %cv4258 = zext i32 %v4257 to i64
  %cond4259 = icmp ne i64 %cv4258, 0
  br i1 %cond4259, label %bb_rcslotdrop1067, label %bb_rcslotdone1067
bb_rcslotdrop1067:
  %v4260 = load i64, ptr %slot12, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  store i32 0, ptr %p4261, align 4, !alias.scope !3, !noalias !4
  %v4262 = load i64, ptr %slot43, align 8
  store i64 %v4262, ptr %slot570, align 8
  %v4263 = load i64, ptr %slot13, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %ld4265 = load i32, ptr %p4264, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4265, ptr %slot571, align 8
  %v4266 = load i32, ptr %slot571, align 8
  %op4267 = and i32 %v4266, 28
  store i32 %op4267, ptr %slot572, align 8
  %v4268 = load i32, ptr %slot572, align 8
  %cv4269 = zext i32 %v4268 to i64
  %cond4270 = icmp ne i64 %cv4269, 0
  br i1 %cond4270, label %bb_rcslotrole1067, label %bb_rcslotowner1067
bb_rcslotrole1067:
  %v4271 = load i64, ptr %slot73, align 8
  store i64 %v4271, ptr %slot573, align 8
  %v4272 = load i64, ptr %slot573, align 8
  %v4273 = load i64, ptr %slot570, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4272, i64 %v4273) nomerge, !dbg !140
  br label %bb_rcslotdone1067
bb_rcslotowner1067:
  %v4274 = load i64, ptr %slot73, align 8
  store i64 %v4274, ptr %slot574, align 8
  %v4275 = load i64, ptr %slot574, align 8
  %v4276 = load i64, ptr %slot570, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4275, i64 %v4276) nomerge, !dbg !140
  br label %bb_rcslotdone1067
bb_rcslotdone1067:
  %v4277 = load i64, ptr %slot10, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %ld4279 = load i32, ptr %p4278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4279, ptr %slot575, align 8
  %v4280 = load i32, ptr %slot575, align 8
  %cv4281 = zext i32 %v4280 to i64
  %cond4282 = icmp ne i64 %cv4281, 0
  br i1 %cond4282, label %bb_rcslotdrop1076, label %bb_rcslotdone1076
bb_rcslotdrop1076:
  %v4283 = load i64, ptr %slot10, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  store i32 0, ptr %p4284, align 4, !alias.scope !3, !noalias !4
  %v4285 = load i64, ptr %slot41, align 8
  store i64 %v4285, ptr %slot576, align 8
  %v4286 = load i64, ptr %slot11, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  %ld4288 = load i32, ptr %p4287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4288, ptr %slot577, align 8
  %v4289 = load i32, ptr %slot577, align 8
  %op4290 = and i32 %v4289, 28
  store i32 %op4290, ptr %slot578, align 8
  %v4291 = load i32, ptr %slot578, align 8
  %cv4292 = zext i32 %v4291 to i64
  %cond4293 = icmp ne i64 %cv4292, 0
  br i1 %cond4293, label %bb_rcslotrole1076, label %bb_rcslotowner1076
bb_rcslotrole1076:
  %v4294 = load i64, ptr %slot73, align 8
  store i64 %v4294, ptr %slot579, align 8
  %v4295 = load i64, ptr %slot579, align 8
  %v4296 = load i64, ptr %slot576, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4295, i64 %v4296) nomerge, !dbg !140
  br label %bb_rcslotdone1076
bb_rcslotowner1076:
  %v4297 = load i64, ptr %slot73, align 8
  store i64 %v4297, ptr %slot580, align 8
  %v4298 = load i64, ptr %slot580, align 8
  %v4299 = load i64, ptr %slot576, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4298, i64 %v4299) nomerge, !dbg !140
  br label %bb_rcslotdone1076
bb_rcslotdone1076:
  %v4300 = load i64, ptr %slot8, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  %ld4302 = load i32, ptr %p4301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4302, ptr %slot581, align 8
  %v4303 = load i32, ptr %slot581, align 8
  %cv4304 = zext i32 %v4303 to i64
  %cond4305 = icmp ne i64 %cv4304, 0
  br i1 %cond4305, label %bb_rcslotdrop1085, label %bb_rcslotdone1085
bb_rcslotdrop1085:
  %v4306 = load i64, ptr %slot8, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  store i32 0, ptr %p4307, align 4, !alias.scope !3, !noalias !4
  %v4308 = load i64, ptr %slot40, align 8
  store i64 %v4308, ptr %slot582, align 8
  %v4309 = load i64, ptr %slot9, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  %ld4311 = load i32, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4311, ptr %slot583, align 8
  %v4312 = load i32, ptr %slot583, align 8
  %op4313 = and i32 %v4312, 28
  store i32 %op4313, ptr %slot584, align 8
  %v4314 = load i32, ptr %slot584, align 8
  %cv4315 = zext i32 %v4314 to i64
  %cond4316 = icmp ne i64 %cv4315, 0
  br i1 %cond4316, label %bb_rcslotrole1085, label %bb_rcslotowner1085
bb_rcslotrole1085:
  %v4317 = load i64, ptr %slot73, align 8
  store i64 %v4317, ptr %slot585, align 8
  %v4318 = load i64, ptr %slot585, align 8
  %v4319 = load i64, ptr %slot582, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4318, i64 %v4319) nomerge, !dbg !140
  br label %bb_rcslotdone1085
bb_rcslotowner1085:
  %v4320 = load i64, ptr %slot73, align 8
  store i64 %v4320, ptr %slot586, align 8
  %v4321 = load i64, ptr %slot586, align 8
  %v4322 = load i64, ptr %slot582, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4321, i64 %v4322) nomerge, !dbg !140
  br label %bb_rcslotdone1085
bb_rcslotdone1085:
  %v4323 = load i64, ptr %slot6, align 8
  %p4324 = inttoptr i64 %v4323 to ptr
  %ld4325 = load i32, ptr %p4324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4325, ptr %slot587, align 8
  %v4326 = load i32, ptr %slot587, align 8
  %cv4327 = zext i32 %v4326 to i64
  %cond4328 = icmp ne i64 %cv4327, 0
  br i1 %cond4328, label %bb_rcslotdrop1094, label %bb_rcslotdone1094
bb_rcslotdrop1094:
  %v4329 = load i64, ptr %slot6, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  store i32 0, ptr %p4330, align 4, !alias.scope !3, !noalias !4
  %v4331 = load i64, ptr %slot38, align 8
  store i64 %v4331, ptr %slot588, align 8
  %v4332 = load i64, ptr %slot7, align 8
  %p4333 = inttoptr i64 %v4332 to ptr
  %ld4334 = load i32, ptr %p4333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4334, ptr %slot589, align 8
  %v4335 = load i32, ptr %slot589, align 8
  %op4336 = and i32 %v4335, 28
  store i32 %op4336, ptr %slot590, align 8
  %v4337 = load i32, ptr %slot590, align 8
  %cv4338 = zext i32 %v4337 to i64
  %cond4339 = icmp ne i64 %cv4338, 0
  br i1 %cond4339, label %bb_rcslotrole1094, label %bb_rcslotowner1094
bb_rcslotrole1094:
  %v4340 = load i64, ptr %slot73, align 8
  store i64 %v4340, ptr %slot591, align 8
  %v4341 = load i64, ptr %slot591, align 8
  %v4342 = load i64, ptr %slot588, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v4341, i64 %v4342) nomerge, !dbg !140
  br label %bb_rcslotdone1094
bb_rcslotowner1094:
  %v4343 = load i64, ptr %slot73, align 8
  store i64 %v4343, ptr %slot592, align 8
  %v4344 = load i64, ptr %slot592, align 8
  %v4345 = load i64, ptr %slot588, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v4344, i64 %v4345) nomerge, !dbg !140
  br label %bb_rcslotdone1094
bb_rcslotdone1094:
  %v4346 = load i64, ptr %slot529, align 8
  %p4347 = inttoptr i64 %v4346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4347, i64 24, i1 false)
  ret void
bb_i40:
  %v4348 = load i64, ptr %slot36, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  %ld4350 = load i64, ptr %p4349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4350, ptr %slot593, align 8
  %v4351 = load i64, ptr %slot593, align 8
  %v4352 = load i64, ptr %slot52, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  store i64 %v4351, ptr %p4353, align 8, !alias.scope !3, !noalias !4
  %v4354 = load i64, ptr %slot52, align 8
  %p4355 = inttoptr i64 %v4354 to ptr
  %ld4356 = load i64, ptr %p4355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4356, ptr %slot594, align 8
  %v4357 = load i64, ptr %slot594, align 8
  %op4358 = add i64 %v4357, 32
  store i64 %op4358, ptr %slot595, align 8
  %v4359 = load i64, ptr %slot595, align 8
  %v4360 = load i64, ptr %slot52, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i64 %v4359, ptr %p4361, align 8, !alias.scope !3, !noalias !4
  %v4362 = load i64, ptr %slot24, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %ld4364 = load i32, ptr %p4363, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4364, ptr %slot596, align 8
  %v4365 = load i32, ptr %slot596, align 8
  %cv4366 = zext i32 %v4365 to i64
  %cond4367 = icmp ne i64 %cv4366, 0
  br i1 %cond4367, label %bb_rcslotdrop1124, label %bb_rcslotdone1124
bb_rcslotdrop1124:
  %v4368 = load i64, ptr %slot24, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  store i32 0, ptr %p4369, align 4, !alias.scope !3, !noalias !4
  %v4370 = load i64, ptr %slot30, align 8
  store i64 %v4370, ptr %slot597, align 8
  %v4371 = load i64, ptr %slot25, align 8
  %p4372 = inttoptr i64 %v4371 to ptr
  %ld4373 = load i32, ptr %p4372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4373, ptr %slot598, align 8
  %v4374 = load i32, ptr %slot598, align 8
  %op4375 = and i32 %v4374, 28
  store i32 %op4375, ptr %slot599, align 8
  %v4376 = load i32, ptr %slot599, align 8
  %cv4377 = zext i32 %v4376 to i64
  %cond4378 = icmp ne i64 %cv4377, 0
  br i1 %cond4378, label %bb_rcslotrole1124, label %bb_rcslotowner1124
bb_rcslotrole1124:
  %v4379 = load i64, ptr %slot73, align 8
  store i64 %v4379, ptr %slot600, align 8
  %v4380 = load i64, ptr %slot600, align 8
  %v4381 = load i64, ptr %slot597, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4380, i64 %v4381) nomerge, !dbg !142
  br label %bb_rcslotdone1124
bb_rcslotowner1124:
  %v4382 = load i64, ptr %slot73, align 8
  store i64 %v4382, ptr %slot601, align 8
  %v4383 = load i64, ptr %slot601, align 8
  %v4384 = load i64, ptr %slot597, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4383, i64 %v4384) nomerge, !dbg !142
  br label %bb_rcslotdone1124
bb_rcslotdone1124:
  %v4385 = load i64, ptr %slot36, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  %ld4387 = load i64, ptr %p4386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4387, ptr %slot602, align 8
  %v4388 = load i64, ptr %slot602, align 8
  %v4389 = load i64, ptr %slot53, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  store i64 %v4388, ptr %p4390, align 8, !alias.scope !3, !noalias !4
  %v4391 = load i64, ptr %slot53, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  %ld4393 = load i64, ptr %p4392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4393, ptr %slot603, align 8
  %v4394 = load i64, ptr %slot603, align 8
  %op4395 = add i64 %v4394, 32
  store i64 %op4395, ptr %slot604, align 8
  %v4396 = load i64, ptr %slot604, align 8
  %v4397 = load i64, ptr %slot53, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  store i64 %v4396, ptr %p4398, align 8, !alias.scope !3, !noalias !4
  %v4399 = load i64, ptr %slot54, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i64 1, ptr %p4400, align 8, !alias.scope !3, !noalias !4
  %v4401 = load i64, ptr %slot53, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i64, ptr %p4402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4403, ptr %slot605, align 8
  %v4404 = load i64, ptr %slot54, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  %ld4406 = load i64, ptr %p4405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4406, ptr %slot606, align 8
  %v4407 = load i64, ptr %slot1, align 8
  %v4408 = load i64, ptr %slot605, align 8
  %v4409 = load i64, ptr %slot606, align 8
  %call4410 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v4407, i64 %v4408, i64 %v4409) nomerge, !dbg !144
  store { i64, i64 } %call4410, ptr %callresult608, align 8
  %addr4411 = ptrtoint ptr %callresult608 to i64
  store i64 %addr4411, ptr %slot607, align 8
  %v4412 = load i64, ptr %slot607, align 8
  %v4413 = load i64, ptr %slot53, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  store i64 %v4412, ptr %p4414, align 8, !alias.scope !3, !noalias !4
  %v4415 = load i64, ptr %slot52, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %ld4417 = load i64, ptr %p4416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4417, ptr %slot609, align 8
  %v4418 = load i64, ptr %slot53, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %ld4420 = load i64, ptr %p4419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4420, ptr %slot610, align 8
  %v4421 = load i64, ptr %slot1, align 8
  %v4422 = load i64, ptr %slot609, align 8
  %v4423 = load i64, ptr %slot610, align 8
  call void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8 %callresult612, i64 %v4421, i64 %v4422, i64 %v4423) nomerge, !dbg !146
  %addr4424 = ptrtoint ptr %callresult612 to i64
  store i64 %addr4424, ptr %slot611, align 8
  %v4425 = load i64, ptr %slot611, align 8
  %v4426 = load i64, ptr %slot52, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  store i64 %v4425, ptr %p4427, align 8, !alias.scope !3, !noalias !4
  %v4428 = load i64, ptr %slot52, align 8
  %p4429 = inttoptr i64 %v4428 to ptr
  %ld4430 = load i64, ptr %p4429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4430, ptr %slot613, align 8
  %v4431 = load i64, ptr %slot32, align 8
  store i64 %v4431, ptr %slot614, align 8
  %v4432 = load i64, ptr %slot613, align 8
  %v4433 = load i64, ptr %slot614, align 8
  %p4434 = inttoptr i64 %v4432 to ptr
  %p4435 = inttoptr i64 %v4433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4435, ptr %p4434, i64 32, i1 false)
  %v4436 = load i64, ptr %slot28, align 8
  %p4437 = inttoptr i64 %v4436 to ptr
  store i32 2, ptr %p4437, align 4, !alias.scope !3, !noalias !4
  %v4438 = load i64, ptr %slot27, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  store i32 1, ptr %p4439, align 4, !alias.scope !3, !noalias !4
  %v4440 = load i64, ptr %slot24, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  %ld4442 = load i32, ptr %p4441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4442, ptr %slot615, align 8
  %v4443 = load i32, ptr %slot615, align 8
  %cv4444 = zext i32 %v4443 to i64
  %cond4445 = icmp ne i64 %cv4444, 0
  br i1 %cond4445, label %bb_rcslotdrop1164, label %bb_rcslotdone1164
bb_rcslotdrop1164:
  %v4446 = load i64, ptr %slot24, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  store i32 0, ptr %p4447, align 4, !alias.scope !3, !noalias !4
  %v4448 = load i64, ptr %slot30, align 8
  store i64 %v4448, ptr %slot616, align 8
  %v4449 = load i64, ptr %slot25, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  %ld4451 = load i32, ptr %p4450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4451, ptr %slot617, align 8
  %v4452 = load i32, ptr %slot617, align 8
  %op4453 = and i32 %v4452, 28
  store i32 %op4453, ptr %slot618, align 8
  %v4454 = load i32, ptr %slot618, align 8
  %cv4455 = zext i32 %v4454 to i64
  %cond4456 = icmp ne i64 %cv4455, 0
  br i1 %cond4456, label %bb_rcslotrole1164, label %bb_rcslotowner1164
bb_rcslotrole1164:
  %v4457 = load i64, ptr %slot73, align 8
  store i64 %v4457, ptr %slot619, align 8
  %v4458 = load i64, ptr %slot619, align 8
  %v4459 = load i64, ptr %slot616, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4458, i64 %v4459) nomerge, !dbg !146
  br label %bb_rcslotdone1164
bb_rcslotowner1164:
  %v4460 = load i64, ptr %slot73, align 8
  store i64 %v4460, ptr %slot620, align 8
  %v4461 = load i64, ptr %slot620, align 8
  %v4462 = load i64, ptr %slot616, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4461, i64 %v4462) nomerge, !dbg !146
  br label %bb_rcslotdone1164
bb_rcslotdone1164:
  %v4463 = load i64, ptr %slot30, align 8
  store i64 %v4463, ptr %slot621, align 8
  %v4464 = load i64, ptr %slot32, align 8
  store i64 %v4464, ptr %slot622, align 8
  %v4465 = load i64, ptr %slot622, align 8
  %v4466 = load i64, ptr %slot621, align 8
  %p4467 = inttoptr i64 %v4465 to ptr
  %p4468 = inttoptr i64 %v4466 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4468, ptr %p4467, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4469 = load i64, ptr %slot25, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  store i32 2, ptr %p4470, align 4, !alias.scope !3, !noalias !4
  %v4471 = load i64, ptr %slot28, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %ld4473 = load i32, ptr %p4472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4473, ptr %slot623, align 8
  %v4474 = load i32, ptr %slot623, align 8
  %v4475 = load i64, ptr %slot25, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  store i32 %v4474, ptr %p4476, align 4, !alias.scope !3, !noalias !4
  %v4477 = load i64, ptr %slot27, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  store i32 0, ptr %p4478, align 4, !alias.scope !3, !noalias !4
  %v4479 = load i64, ptr %slot24, align 8
  %p4480 = inttoptr i64 %v4479 to ptr
  store i32 1, ptr %p4480, align 4, !alias.scope !3, !noalias !4
  %v4481 = load i64, ptr %slot621, align 8
  %v4482 = load i64, ptr %slot52, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  store i64 %v4481, ptr %p4483, align 8, !alias.scope !3, !noalias !4
  %v4484 = load i64, ptr %slot52, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  %ld4486 = load i64, ptr %p4485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4486, ptr %slot624, align 8
  %v4487 = load i64, ptr %slot624, align 8
  %p4488 = inttoptr i64 %v4487 to ptr
  %ld4489 = load i32, ptr %p4488, align 4
  %ext4490 = zext i32 %ld4489 to i64
  store i64 %ext4490, ptr %slot625, align 8
  %v4491 = load i64, ptr %slot625, align 8
  %cmp4492 = icmp eq i64 %v4491, 0
  %cv4493 = zext i1 %cmp4492 to i64
  store i64 %cv4493, ptr %slot626, align 8
  %v4494 = load i64, ptr %slot626, align 8
  %cond4495 = icmp ne i64 %v4494, 0
  br i1 %cond4495, label %bb_rcarm1181, label %bb_rcarmnext1181
bb_rcarm1181:
  %v4496 = load i64, ptr %slot24, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  %ld4498 = load i32, ptr %p4497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4498, ptr %slot627, align 8
  %v4499 = load i32, ptr %slot627, align 8
  %cv4500 = zext i32 %v4499 to i64
  %cond4501 = icmp ne i64 %cv4500, 0
  br i1 %cond4501, label %bb_rcslotdrop1184, label %bb_rcslotdone1184
bb_rcslotdrop1184:
  %v4502 = load i64, ptr %slot24, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  store i32 0, ptr %p4503, align 4, !alias.scope !3, !noalias !4
  %v4504 = load i64, ptr %slot30, align 8
  store i64 %v4504, ptr %slot628, align 8
  %v4505 = load i64, ptr %slot25, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  %ld4507 = load i32, ptr %p4506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4507, ptr %slot629, align 8
  %v4508 = load i32, ptr %slot629, align 8
  %op4509 = and i32 %v4508, 28
  store i32 %op4509, ptr %slot630, align 8
  %v4510 = load i32, ptr %slot630, align 8
  %cv4511 = zext i32 %v4510 to i64
  %cond4512 = icmp ne i64 %cv4511, 0
  br i1 %cond4512, label %bb_rcslotrole1184, label %bb_rcslotowner1184
bb_rcslotrole1184:
  %v4513 = load i64, ptr %slot73, align 8
  store i64 %v4513, ptr %slot631, align 8
  %v4514 = load i64, ptr %slot631, align 8
  %v4515 = load i64, ptr %slot628, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v4514, i64 %v4515) nomerge, !dbg !148
  br label %bb_rcslotdone1184
bb_rcslotowner1184:
  %v4516 = load i64, ptr %slot73, align 8
  store i64 %v4516, ptr %slot632, align 8
  %v4517 = load i64, ptr %slot632, align 8
  %v4518 = load i64, ptr %slot628, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v4517, i64 %v4518) nomerge, !dbg !148
  br label %bb_rcslotdone1184
bb_rcslotdone1184:
  br label %bb_i157
bb_rcarmnext1181:
  %v4519 = load i64, ptr %slot625, align 8
  %cmp4520 = icmp eq i64 %v4519, 1
  %cv4521 = zext i1 %cmp4520 to i64
  store i64 %cv4521, ptr %slot633, align 8
  %v4522 = load i64, ptr %slot633, align 8
  %cond4523 = icmp ne i64 %v4522, 0
  br i1 %cond4523, label %bb_rcarm1191, label %bb_rcarmnext1191
bb_rcarm1191:
  %v4524 = load i64, ptr %slot32, align 8
  store i64 %v4524, ptr %slot634, align 8
  %v4525 = load i64, ptr %slot624, align 8
  %op4526 = add i64 %v4525, 8
  store i64 %op4526, ptr %slot635, align 8
  %v4527 = load i64, ptr %slot74, align 8
  store i64 %v4527, ptr %slot636, align 8
  %v4528 = load i64, ptr %slot73, align 8
  %v4529 = load i64, ptr %slot634, align 8
  %v4530 = load i64, ptr %slot635, align 8
  %v4531 = load i64, ptr %slot636, align 8
  %cv4532 = trunc i64 %v4531 to i32
  %call4533 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v4528, i64 %v4529, i64 %v4530, i32 %cv4532) nomerge, !dbg !148
  store i32 %call4533, ptr %slot637, align 8
  %v4534 = load i32, ptr %slot637, align 8
  %cv4535 = zext i32 %v4534 to i64
  %cond4536 = icmp ne i64 %cv4535, 0
  br i1 %cond4536, label %bb_rcsuccess1196, label %bb_rcfailure1196
bb_rcfailure1196:
  %v4537 = load i64, ptr %slot73, align 8
  %p4538 = inttoptr i64 %v4537 to ptr
  %call4539 = call i32 @myl_rc_take_failure(ptr %p4538) nomerge, !dbg !148
  store i32 %call4539, ptr %slot638, align 8
  %v4540 = load i64, ptr %slot1, align 8
  %p4541 = inttoptr i64 %v4540 to ptr
  %v4542 = load i32, ptr %slot638, align 8
  %call4543 = call i32 @myl_qbe_rc_status(ptr %p4541, i32 %v4542) nomerge, !dbg !148
  store i32 %call4543, ptr %slot639, align 8
  br label %bb_failure
bb_rcsuccess1196:
  %v4544 = load i64, ptr %slot28, align 8
  %p4545 = inttoptr i64 %v4544 to ptr
  store i32 2, ptr %p4545, align 4, !alias.scope !3, !noalias !4
  %v4546 = load i64, ptr %slot27, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  store i32 1, ptr %p4547, align 4, !alias.scope !3, !noalias !4
  %v4548 = load i64, ptr %slot8, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  %ld4550 = load i32, ptr %p4549, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4550, ptr %slot640, align 8
  %v4551 = load i32, ptr %slot640, align 8
  %cv4552 = zext i32 %v4551 to i64
  %cond4553 = icmp ne i64 %cv4552, 0
  br i1 %cond4553, label %bb_rcslotdrop1203, label %bb_rcslotdone1203
bb_rcslotdrop1203:
  %v4554 = load i64, ptr %slot8, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  store i32 0, ptr %p4555, align 4, !alias.scope !3, !noalias !4
  %v4556 = load i64, ptr %slot40, align 8
  store i64 %v4556, ptr %slot641, align 8
  %v4557 = load i64, ptr %slot9, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  %ld4559 = load i32, ptr %p4558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4559, ptr %slot642, align 8
  %v4560 = load i32, ptr %slot642, align 8
  %op4561 = and i32 %v4560, 28
  store i32 %op4561, ptr %slot643, align 8
  %v4562 = load i32, ptr %slot643, align 8
  %cv4563 = zext i32 %v4562 to i64
  %cond4564 = icmp ne i64 %cv4563, 0
  br i1 %cond4564, label %bb_rcslotrole1203, label %bb_rcslotowner1203
bb_rcslotrole1203:
  %v4565 = load i64, ptr %slot73, align 8
  store i64 %v4565, ptr %slot644, align 8
  %v4566 = load i64, ptr %slot644, align 8
  %v4567 = load i64, ptr %slot641, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4566, i64 %v4567) nomerge, !dbg !148
  br label %bb_rcslotdone1203
bb_rcslotowner1203:
  %v4568 = load i64, ptr %slot73, align 8
  store i64 %v4568, ptr %slot645, align 8
  %v4569 = load i64, ptr %slot645, align 8
  %v4570 = load i64, ptr %slot641, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4569, i64 %v4570) nomerge, !dbg !148
  br label %bb_rcslotdone1203
bb_rcslotdone1203:
  %v4571 = load i64, ptr %slot634, align 8
  %v4572 = load i64, ptr %slot40, align 8
  %p4573 = inttoptr i64 %v4571 to ptr
  %p4574 = inttoptr i64 %v4572 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4574, ptr %p4573, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4575 = load i64, ptr %slot27, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  store i32 0, ptr %p4576, align 4, !alias.scope !3, !noalias !4
  %v4577 = load i64, ptr %slot40, align 8
  store i64 %v4577, ptr %slot646, align 8
  %v4578 = load i64, ptr %slot9, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  store i32 2, ptr %p4579, align 4, !alias.scope !3, !noalias !4
  %v4580 = load i64, ptr %slot8, align 8
  %p4581 = inttoptr i64 %v4580 to ptr
  store i32 1, ptr %p4581, align 4, !alias.scope !3, !noalias !4
  %v4582 = load i64, ptr %slot24, align 8
  %p4583 = inttoptr i64 %v4582 to ptr
  %ld4584 = load i32, ptr %p4583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4584, ptr %slot647, align 8
  %v4585 = load i32, ptr %slot647, align 8
  %cv4586 = zext i32 %v4585 to i64
  %cond4587 = icmp ne i64 %cv4586, 0
  br i1 %cond4587, label %bb_rcslotdrop1216, label %bb_rcslotdone1216
bb_rcslotdrop1216:
  %v4588 = load i64, ptr %slot24, align 8
  %p4589 = inttoptr i64 %v4588 to ptr
  store i32 0, ptr %p4589, align 4, !alias.scope !3, !noalias !4
  %v4590 = load i64, ptr %slot30, align 8
  store i64 %v4590, ptr %slot648, align 8
  %v4591 = load i64, ptr %slot25, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  %ld4593 = load i32, ptr %p4592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4593, ptr %slot649, align 8
  %v4594 = load i32, ptr %slot649, align 8
  %op4595 = and i32 %v4594, 28
  store i32 %op4595, ptr %slot650, align 8
  %v4596 = load i32, ptr %slot650, align 8
  %cv4597 = zext i32 %v4596 to i64
  %cond4598 = icmp ne i64 %cv4597, 0
  br i1 %cond4598, label %bb_rcslotrole1216, label %bb_rcslotowner1216
bb_rcslotrole1216:
  %v4599 = load i64, ptr %slot73, align 8
  store i64 %v4599, ptr %slot651, align 8
  %v4600 = load i64, ptr %slot651, align 8
  %v4601 = load i64, ptr %slot648, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v4600, i64 %v4601) nomerge, !dbg !148
  br label %bb_rcslotdone1216
bb_rcslotowner1216:
  %v4602 = load i64, ptr %slot73, align 8
  store i64 %v4602, ptr %slot652, align 8
  %v4603 = load i64, ptr %slot652, align 8
  %v4604 = load i64, ptr %slot648, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v4603, i64 %v4604) nomerge, !dbg !148
  br label %bb_rcslotdone1216
bb_rcslotdone1216:
  br label %bb_i49
bb_rcarmnext1191:
  br label %bb_failure
bb_i49:
  %v4605 = load i64, ptr %slot40, align 8
  %v4606 = load i64, ptr %slot52, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  store i64 %v4605, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  %v4608 = load i64, ptr %slot52, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  %ld4610 = load i64, ptr %p4609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4610, ptr %slot653, align 8
  %v4611 = load i64, ptr %slot653, align 8
  %op4612 = add i64 %v4611, 8
  store i64 %op4612, ptr %slot654, align 8
  %v4613 = load i64, ptr %slot654, align 8
  %v4614 = load i64, ptr %slot52, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  store i64 %v4613, ptr %p4615, align 8, !alias.scope !3, !noalias !4
  %v4616 = load i64, ptr %slot24, align 8
  %p4617 = inttoptr i64 %v4616 to ptr
  %ld4618 = load i32, ptr %p4617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4618, ptr %slot655, align 8
  %v4619 = load i32, ptr %slot655, align 8
  %cv4620 = zext i32 %v4619 to i64
  %cond4621 = icmp ne i64 %cv4620, 0
  br i1 %cond4621, label %bb_rcslotdrop1227, label %bb_rcslotdone1227
bb_rcslotdrop1227:
  %v4622 = load i64, ptr %slot24, align 8
  %p4623 = inttoptr i64 %v4622 to ptr
  store i32 0, ptr %p4623, align 4, !alias.scope !3, !noalias !4
  %v4624 = load i64, ptr %slot30, align 8
  store i64 %v4624, ptr %slot656, align 8
  %v4625 = load i64, ptr %slot25, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %ld4627 = load i32, ptr %p4626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4627, ptr %slot657, align 8
  %v4628 = load i32, ptr %slot657, align 8
  %op4629 = and i32 %v4628, 28
  store i32 %op4629, ptr %slot658, align 8
  %v4630 = load i32, ptr %slot658, align 8
  %cv4631 = zext i32 %v4630 to i64
  %cond4632 = icmp ne i64 %cv4631, 0
  br i1 %cond4632, label %bb_rcslotrole1227, label %bb_rcslotowner1227
bb_rcslotrole1227:
  %v4633 = load i64, ptr %slot73, align 8
  store i64 %v4633, ptr %slot659, align 8
  %v4634 = load i64, ptr %slot659, align 8
  %v4635 = load i64, ptr %slot656, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4634, i64 %v4635) nomerge, !dbg !150
  br label %bb_rcslotdone1227
bb_rcslotowner1227:
  %v4636 = load i64, ptr %slot73, align 8
  store i64 %v4636, ptr %slot660, align 8
  %v4637 = load i64, ptr %slot660, align 8
  %v4638 = load i64, ptr %slot656, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4637, i64 %v4638) nomerge, !dbg !150
  br label %bb_rcslotdone1227
bb_rcslotdone1227:
  %v4639 = load i64, ptr %slot52, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %ld4641 = load i64, ptr %p4640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4641, ptr %slot661, align 8
  %v4642 = load i64, ptr %slot24, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  %ld4644 = load i32, ptr %p4643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4644, ptr %slot662, align 8
  %v4645 = load i64, ptr %slot25, align 8
  %p4646 = inttoptr i64 %v4645 to ptr
  %ld4647 = load i32, ptr %p4646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4647, ptr %slot663, align 8
  %v4648 = load i32, ptr %slot663, align 8
  %op4649 = and i32 %v4648, 24
  store i32 %op4649, ptr %slot663, align 8
  %v4650 = load i32, ptr %slot663, align 8
  %cmp4651 = icmp eq i32 %v4650, 0
  %cv4652 = zext i1 %cmp4651 to i32
  store i32 %cv4652, ptr %slot664, align 8
  %v4653 = load i32, ptr %slot662, align 8
  %v4654 = load i32, ptr %slot664, align 8
  %op4655 = and i32 %v4653, %v4654
  store i32 %op4655, ptr %slot665, align 8
  %v4656 = load i64, ptr %slot74, align 8
  store i64 %v4656, ptr %slot666, align 8
  %v4657 = load i32, ptr %slot665, align 8
  %op4658 = mul i32 %v4657, 4
  store i32 %op4658, ptr %slot667, align 8
  %v4659 = load i32, ptr %slot667, align 8
  %op4660 = or i32 %v4659, 0
  store i32 %op4660, ptr %slot668, align 8
  %v4661 = load i64, ptr %slot32, align 8
  store i64 %v4661, ptr %slot669, align 8
  %v4662 = load i64, ptr %slot73, align 8
  %v4663 = load i64, ptr %slot669, align 8
  %v4664 = load i64, ptr %slot661, align 8
  %v4665 = load i64, ptr %slot666, align 8
  %cv4666 = trunc i64 %v4665 to i32
  %v4667 = load i32, ptr %slot668, align 8
  %call4668 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64 %v4662, i64 %v4663, i64 %v4664, i32 %cv4666, i32 %v4667) nomerge, !dbg !152
  store i32 %call4668, ptr %slot670, align 8
  %v4669 = load i32, ptr %slot670, align 8
  %cv4670 = zext i32 %v4669 to i64
  %cond4671 = icmp ne i64 %cv4670, 0
  br i1 %cond4671, label %bb_rcsuccess1248, label %bb_rcfailure1248
bb_rcfailure1248:
  %v4672 = load i64, ptr %slot73, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  %call4674 = call i32 @myl_rc_take_failure(ptr %p4673) nomerge, !dbg !152
  store i32 %call4674, ptr %slot671, align 8
  %v4675 = load i64, ptr %slot1, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  %v4677 = load i32, ptr %slot671, align 8
  %call4678 = call i32 @myl_qbe_rc_status(ptr %p4676, i32 %v4677) nomerge, !dbg !152
  store i32 %call4678, ptr %slot672, align 8
  br label %bb_failure
bb_rcsuccess1248:
  %v4679 = load i32, ptr %slot665, align 8
  %cv4680 = zext i32 %v4679 to i64
  %cond4681 = icmp ne i64 %cv4680, 0
  br i1 %cond4681, label %bb_rchtaken1251, label %bb_rchcopied1251
bb_rchcopied1251:
  %v4682 = load i64, ptr %slot24, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  %ld4684 = load i32, ptr %p4683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4684, ptr %slot673, align 8
  %v4685 = load i32, ptr %slot673, align 8
  %cv4686 = zext i32 %v4685 to i64
  %cond4687 = icmp ne i64 %cv4686, 0
  br i1 %cond4687, label %bb_rcslotdrop1254, label %bb_rcslotdone1254
bb_rcslotdrop1254:
  %v4688 = load i64, ptr %slot24, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  store i32 0, ptr %p4689, align 4, !alias.scope !3, !noalias !4
  %v4690 = load i64, ptr %slot30, align 8
  store i64 %v4690, ptr %slot674, align 8
  %v4691 = load i64, ptr %slot25, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %ld4693 = load i32, ptr %p4692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4693, ptr %slot675, align 8
  %v4694 = load i32, ptr %slot675, align 8
  %op4695 = and i32 %v4694, 28
  store i32 %op4695, ptr %slot676, align 8
  %v4696 = load i32, ptr %slot676, align 8
  %cv4697 = zext i32 %v4696 to i64
  %cond4698 = icmp ne i64 %cv4697, 0
  br i1 %cond4698, label %bb_rcslotrole1254, label %bb_rcslotowner1254
bb_rcslotrole1254:
  %v4699 = load i64, ptr %slot73, align 8
  store i64 %v4699, ptr %slot677, align 8
  %v4700 = load i64, ptr %slot677, align 8
  %v4701 = load i64, ptr %slot674, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4700, i64 %v4701) nomerge, !dbg !152
  br label %bb_rcslotdone1254
bb_rcslotowner1254:
  %v4702 = load i64, ptr %slot73, align 8
  store i64 %v4702, ptr %slot678, align 8
  %v4703 = load i64, ptr %slot678, align 8
  %v4704 = load i64, ptr %slot674, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4703, i64 %v4704) nomerge, !dbg !152
  br label %bb_rcslotdone1254
bb_rcslotdone1254:
  br label %bb_rchprepared1251
bb_rchtaken1251:
  %v4705 = load i64, ptr %slot24, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  store i32 0, ptr %p4706, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1251
bb_rchprepared1251:
  %v4707 = load i64, ptr %slot28, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  store i32 2, ptr %p4708, align 4, !alias.scope !3, !noalias !4
  %v4709 = load i64, ptr %slot27, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  store i32 1, ptr %p4710, align 4, !alias.scope !3, !noalias !4
  %v4711 = load i64, ptr %slot30, align 8
  store i64 %v4711, ptr %slot679, align 8
  %v4712 = load i64, ptr %slot32, align 8
  store i64 %v4712, ptr %slot680, align 8
  %v4713 = load i64, ptr %slot680, align 8
  %v4714 = load i64, ptr %slot679, align 8
  %p4715 = inttoptr i64 %v4713 to ptr
  %p4716 = inttoptr i64 %v4714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4716, ptr %p4715, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot25, align 8
  %p4718 = inttoptr i64 %v4717 to ptr
  store i32 2, ptr %p4718, align 4, !alias.scope !3, !noalias !4
  %v4719 = load i64, ptr %slot28, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i32, ptr %p4720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4721, ptr %slot681, align 8
  %v4722 = load i32, ptr %slot681, align 8
  %v4723 = load i64, ptr %slot25, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  store i32 %v4722, ptr %p4724, align 4, !alias.scope !3, !noalias !4
  %v4725 = load i64, ptr %slot27, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  store i32 0, ptr %p4726, align 4, !alias.scope !3, !noalias !4
  %v4727 = load i64, ptr %slot24, align 8
  %p4728 = inttoptr i64 %v4727 to ptr
  store i32 1, ptr %p4728, align 4, !alias.scope !3, !noalias !4
  %v4729 = load i64, ptr %slot679, align 8
  %v4730 = load i64, ptr %slot52, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  store i64 %v4729, ptr %p4731, align 8, !alias.scope !3, !noalias !4
  %v4732 = load i64, ptr %slot52, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  %ld4734 = load i64, ptr %p4733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4734, ptr %slot682, align 8
  %v4735 = load i64, ptr %slot32, align 8
  store i64 %v4735, ptr %slot683, align 8
  %v4736 = load i64, ptr %slot74, align 8
  store i64 %v4736, ptr %slot684, align 8
  %v4737 = load i64, ptr %slot682, align 8
  %op4738 = add i64 %v4737, 0
  store i64 %op4738, ptr %slot685, align 8
  %v4739 = load i64, ptr %slot685, align 8
  %p4740 = inttoptr i64 %v4739 to ptr
  %ld4741 = load i64, ptr %p4740, align 8
  store i64 %ld4741, ptr %slot686, align 8
  %v4742 = load i64, ptr %slot686, align 8
  %cmp4743 = icmp ne i64 %v4742, 0
  %cv4744 = zext i1 %cmp4743 to i32
  store i32 %cv4744, ptr %slot687, align 8
  %v4745 = load i32, ptr %slot687, align 8
  %cv4746 = zext i32 %v4745 to i64
  %cond4747 = icmp ne i64 %cv4746, 0
  br i1 %cond4747, label %bb_rcmoveheader1278, label %bb_rcmovenext1278
bb_rcmoveheader1278:
  %v4748 = load i64, ptr %slot686, align 8
  %op4749 = sub i64 %v4748, 16
  store i64 %op4749, ptr %slot688, align 8
  %v4750 = load i64, ptr %slot686, align 8
  %p4751 = inttoptr i64 %v4750 to ptr
  %rgep4752 = getelementptr i8, ptr %p4751, i64 -16
  %ld4753 = load i64, ptr %rgep4752, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4753, ptr %slot689, align 8
  %v4754 = load i64, ptr %slot689, align 8
  %op4755 = and i64 %v4754, 5764607523034234881
  store i64 %op4755, ptr %slot690, align 8
  %v4756 = load i64, ptr %slot690, align 8
  %cmp4757 = icmp ne i64 %v4756, 0
  %cv4758 = zext i1 %cmp4757 to i32
  store i32 %cv4758, ptr %slot691, align 8
  %v4759 = load i32, ptr %slot691, align 8
  %cv4760 = zext i32 %v4759 to i64
  %cond4761 = icmp ne i64 %cv4760, 0
  br i1 %cond4761, label %bb_rcmoveslow1275, label %bb_rcmovenext1278
bb_rcmovenext1278:
  %v4762 = load i64, ptr %slot682, align 8
  %v4763 = load i64, ptr %slot683, align 8
  %p4764 = inttoptr i64 %v4762 to ptr
  %p4765 = inttoptr i64 %v4763 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4765, ptr %p4764, i64 16, i1 false)
  %v4766 = load i64, ptr %slot682, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  store i64 0, ptr %p4767, align 8
  %v4768 = load i64, ptr %slot682, align 8
  %op4769 = add i64 %v4768, 8
  store i64 %op4769, ptr %slot692, align 8
  %v4770 = load i64, ptr %slot692, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  store i64 0, ptr %p4771, align 8
  br label %bb_rcmoved1275
bb_rcmoveslow1275:
  %v4772 = load i64, ptr %slot73, align 8
  %v4773 = load i64, ptr %slot683, align 8
  %v4774 = load i64, ptr %slot682, align 8
  %v4775 = load i64, ptr %slot684, align 8
  %cv4776 = trunc i64 %v4775 to i32
  %call4777 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v4772, i64 %v4773, i64 %v4774, i32 %cv4776) nomerge, !dbg !154
  store i32 %call4777, ptr %slot693, align 8
  %v4778 = load i32, ptr %slot693, align 8
  %cv4779 = zext i32 %v4778 to i64
  %cond4780 = icmp ne i64 %cv4779, 0
  br i1 %cond4780, label %bb_rcsuccess1286, label %bb_rcfailure1286
bb_rcfailure1286:
  %v4781 = load i64, ptr %slot73, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  %call4783 = call i32 @myl_rc_take_failure(ptr %p4782) nomerge, !dbg !154
  store i32 %call4783, ptr %slot694, align 8
  %v4784 = load i64, ptr %slot1, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  %v4786 = load i32, ptr %slot694, align 8
  %call4787 = call i32 @myl_qbe_rc_status(ptr %p4785, i32 %v4786) nomerge, !dbg !154
  store i32 %call4787, ptr %slot695, align 8
  br label %bb_failure
bb_rcsuccess1286:
  br label %bb_rcmoved1275
bb_rcmoved1275:
  %v4788 = load i64, ptr %slot24, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  store i32 0, ptr %p4789, align 4, !alias.scope !3, !noalias !4
  %v4790 = load i64, ptr %slot28, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  store i32 2, ptr %p4791, align 4, !alias.scope !3, !noalias !4
  %v4792 = load i64, ptr %slot27, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i32 1, ptr %p4793, align 4, !alias.scope !3, !noalias !4
  %v4794 = load i64, ptr %slot10, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %ld4796 = load i32, ptr %p4795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4796, ptr %slot696, align 8
  %v4797 = load i32, ptr %slot696, align 8
  %cv4798 = zext i32 %v4797 to i64
  %cond4799 = icmp ne i64 %cv4798, 0
  br i1 %cond4799, label %bb_rcslotdrop1295, label %bb_rcslotdone1295
bb_rcslotdrop1295:
  %v4800 = load i64, ptr %slot10, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  store i32 0, ptr %p4801, align 4, !alias.scope !3, !noalias !4
  %v4802 = load i64, ptr %slot41, align 8
  store i64 %v4802, ptr %slot697, align 8
  %v4803 = load i64, ptr %slot11, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %ld4805 = load i32, ptr %p4804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4805, ptr %slot698, align 8
  %v4806 = load i32, ptr %slot698, align 8
  %op4807 = and i32 %v4806, 28
  store i32 %op4807, ptr %slot699, align 8
  %v4808 = load i32, ptr %slot699, align 8
  %cv4809 = zext i32 %v4808 to i64
  %cond4810 = icmp ne i64 %cv4809, 0
  br i1 %cond4810, label %bb_rcslotrole1295, label %bb_rcslotowner1295
bb_rcslotrole1295:
  %v4811 = load i64, ptr %slot73, align 8
  store i64 %v4811, ptr %slot700, align 8
  %v4812 = load i64, ptr %slot700, align 8
  %v4813 = load i64, ptr %slot697, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4812, i64 %v4813) nomerge, !dbg !154
  br label %bb_rcslotdone1295
bb_rcslotowner1295:
  %v4814 = load i64, ptr %slot697, align 8
  %p4816 = inttoptr i64 %v4814 to ptr
  %gep4817 = getelementptr i8, ptr %p4816, i64 0
  %op4815 = ptrtoint ptr %gep4817 to i64
  store i64 %op4815, ptr %slot701, align 8
  %v4818 = load i64, ptr %slot73, align 8
  store i64 %v4818, ptr %slot702, align 8
  %v4819 = load i64, ptr %slot701, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  %ld4821 = load i64, ptr %p4820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4821, ptr %slot703, align 8
  %v4822 = load i64, ptr %slot703, align 8
  %cmp4823 = icmp ne i64 %v4822, 0
  %cv4824 = zext i1 %cmp4823 to i32
  store i32 %cv4824, ptr %slot704, align 8
  %v4825 = load i32, ptr %slot704, align 8
  %cv4826 = zext i32 %v4825 to i64
  %cond4827 = icmp ne i64 %cv4826, 0
  br i1 %cond4827, label %bb_rcgnn1313, label %bb_rcgdone1313
bb_rcgnn1313:
  %v4828 = load i64, ptr %slot703, align 8
  %op4829 = sub i64 %v4828, 16
  store i64 %op4829, ptr %slot705, align 8
  %v4830 = load i64, ptr %slot703, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  %rgep4832 = getelementptr i8, ptr %p4831, i64 -16
  %ld4833 = load i64, ptr %rgep4832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4833, ptr %slot706, align 8
  %v4834 = load i64, ptr %slot706, align 8
  %op4835 = and i64 %v4834, 4611686018427387906
  store i64 %op4835, ptr %slot707, align 8
  %v4836 = load i64, ptr %slot707, align 8
  %cmp4837 = icmp ne i64 %v4836, 0
  %cv4838 = zext i1 %cmp4837 to i32
  store i32 %cv4838, ptr %slot708, align 8
  %v4839 = load i32, ptr %slot708, align 8
  %cv4840 = zext i32 %v4839 to i64
  %cond4841 = icmp ne i64 %cv4840, 0
  br i1 %cond4841, label %bb_rcgclear1313, label %bb_rcgcounted1313
bb_rcgcounted1313:
  %v4842 = load i64, ptr %slot703, align 8
  %op4843 = sub i64 %v4842, 32
  store i64 %op4843, ptr %slot709, align 8
  %v4844 = load i64, ptr %slot703, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  %rgep4846 = getelementptr i8, ptr %p4845, i64 -32
  %ld4847 = load i64, ptr %rgep4846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4847, ptr %slot710, align 8
  %v4848 = load i64, ptr %slot710, align 8
  %op4849 = sub i64 %v4848, 1
  store i64 %op4849, ptr %slot711, align 8
  %v4850 = load i64, ptr %slot711, align 8
  %cmp4851 = icmp eq i64 %v4850, 0
  %cv4852 = zext i1 %cmp4851 to i32
  store i32 %cv4852, ptr %slot712, align 8
  %v4853 = load i32, ptr %slot712, align 8
  %cv4854 = zext i32 %v4853 to i64
  %cond4855 = icmp ne i64 %cv4854, 0
  br i1 %cond4855, label %bb_rcglast1313, label %bb_rcgdec1313
bb_rcglast1313:
  %v4856 = load i64, ptr %slot703, align 8
  %op4857 = sub i64 %v4856, 24
  store i64 %op4857, ptr %slot713, align 8
  %v4858 = load i64, ptr %slot703, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  %rgep4860 = getelementptr i8, ptr %p4859, i64 -24
  %ld4861 = load i64, ptr %rgep4860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4861, ptr %slot714, align 8
  %v4862 = load i64, ptr %slot714, align 8
  %cmp4863 = icmp ne i64 %v4862, 0
  %cv4864 = zext i1 %cmp4863 to i32
  store i32 %cv4864, ptr %slot715, align 8
  %v4865 = load i32, ptr %slot715, align 8
  %cv4866 = zext i32 %v4865 to i64
  %cond4867 = icmp ne i64 %cv4866, 0
  br i1 %cond4867, label %bb_rcgdec1313, label %bb_rcgslow1313
bb_rcgslow1313:
  %v4868 = load i64, ptr %slot702, align 8
  %v4869 = load i64, ptr %slot701, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4868, i64 %v4869) nomerge, !dbg !154
  br label %bb_rcgdone1313
bb_rcgdec1313:
  %v4870 = load i64, ptr %slot711, align 8
  %v4871 = load i64, ptr %slot703, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  %rgep4873 = getelementptr i8, ptr %p4872, i64 -32
  store i64 %v4870, ptr %rgep4873, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1313
bb_rcgclear1313:
  %v4874 = load i64, ptr %slot701, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  store i64 0, ptr %p4875, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1313
bb_rcgdone1313:
  %v4876 = load i64, ptr %slot697, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  store i64 0, ptr %p4877, align 8, !alias.scope !3, !noalias !4
  %v4878 = load i64, ptr %slot697, align 8
  %p4880 = inttoptr i64 %v4878 to ptr
  %gep4881 = getelementptr i8, ptr %p4880, i64 8
  %op4879 = ptrtoint ptr %gep4881 to i64
  store i64 %op4879, ptr %slot716, align 8
  %v4882 = load i64, ptr %slot716, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  store i64 0, ptr %p4883, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1295
bb_rcslotdone1295:
  %v4884 = load i64, ptr %slot41, align 8
  store i64 %v4884, ptr %slot717, align 8
  %v4885 = load i64, ptr %slot32, align 8
  store i64 %v4885, ptr %slot718, align 8
  %v4886 = load i64, ptr %slot718, align 8
  %v4887 = load i64, ptr %slot717, align 8
  %p4888 = inttoptr i64 %v4886 to ptr
  %p4889 = inttoptr i64 %v4887 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4889, ptr %p4888, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4890 = load i64, ptr %slot27, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  store i32 0, ptr %p4891, align 4, !alias.scope !3, !noalias !4
  %v4892 = load i64, ptr %slot11, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  store i32 2, ptr %p4893, align 4, !alias.scope !3, !noalias !4
  %v4894 = load i64, ptr %slot28, align 8
  %p4895 = inttoptr i64 %v4894 to ptr
  %ld4896 = load i32, ptr %p4895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4896, ptr %slot719, align 8
  %v4897 = load i32, ptr %slot719, align 8
  %v4898 = load i64, ptr %slot11, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  store i32 %v4897, ptr %p4899, align 4, !alias.scope !3, !noalias !4
  %v4900 = load i64, ptr %slot10, align 8
  %p4901 = inttoptr i64 %v4900 to ptr
  store i32 1, ptr %p4901, align 4, !alias.scope !3, !noalias !4
  %v4902 = load i64, ptr %slot41, align 8
  %v4903 = load i64, ptr %slot52, align 8
  %p4904 = inttoptr i64 %v4903 to ptr
  store i64 %v4902, ptr %p4904, align 8, !alias.scope !3, !noalias !4
  %v4905 = load i64, ptr %slot37, align 8
  %p4906 = inttoptr i64 %v4905 to ptr
  %ld4907 = load i64, ptr %p4906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4907, ptr %slot720, align 8
  %v4908 = load i64, ptr %slot720, align 8
  %v4909 = load i64, ptr %slot53, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  store i64 %v4908, ptr %p4910, align 8, !alias.scope !3, !noalias !4
  %v4911 = load i64, ptr %slot53, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  %ld4913 = load i64, ptr %p4912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4913, ptr %slot721, align 8
  %v4914 = load i64, ptr %slot721, align 8
  %op4915 = add i64 %v4914, 48
  store i64 %op4915, ptr %slot722, align 8
  %v4916 = load i64, ptr %slot722, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  %ld4918 = load i64, ptr %p4917, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4918, ptr %slot723, align 8
  %v4919 = load i64, ptr %slot723, align 8
  %v4920 = load i64, ptr %slot53, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  store i64 %v4919, ptr %p4921, align 8, !alias.scope !3, !noalias !4
  %v4922 = load i64, ptr %slot36, align 8
  %p4923 = inttoptr i64 %v4922 to ptr
  %ld4924 = load i64, ptr %p4923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4924, ptr %slot724, align 8
  %v4925 = load i64, ptr %slot724, align 8
  %v4926 = load i64, ptr %slot54, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  store i64 %v4925, ptr %p4927, align 8, !alias.scope !3, !noalias !4
  %v4928 = load i64, ptr %slot54, align 8
  %p4929 = inttoptr i64 %v4928 to ptr
  %ld4930 = load i64, ptr %p4929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4930, ptr %slot725, align 8
  %v4931 = load i64, ptr %slot725, align 8
  %op4932 = add i64 %v4931, 32
  store i64 %op4932, ptr %slot726, align 8
  %v4933 = load i64, ptr %slot726, align 8
  %v4934 = load i64, ptr %slot54, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  store i64 %v4933, ptr %p4935, align 8, !alias.scope !3, !noalias !4
  %v4936 = load i64, ptr %slot37, align 8
  %p4937 = inttoptr i64 %v4936 to ptr
  %ld4938 = load i64, ptr %p4937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4938, ptr %slot727, align 8
  %v4939 = load i64, ptr %slot727, align 8
  %v4940 = load i64, ptr %slot55, align 8
  %p4941 = inttoptr i64 %v4940 to ptr
  store i64 %v4939, ptr %p4941, align 8, !alias.scope !3, !noalias !4
  %v4942 = load i64, ptr %slot55, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  %ld4944 = load i64, ptr %p4943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4944, ptr %slot728, align 8
  %v4945 = load i64, ptr %slot728, align 8
  %op4946 = add i64 %v4945, 48
  store i64 %op4946, ptr %slot729, align 8
  %v4947 = load i64, ptr %slot729, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  %ld4949 = load i64, ptr %p4948, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4949, ptr %slot730, align 8
  %v4950 = load i64, ptr %slot730, align 8
  %v4951 = load i64, ptr %slot55, align 8
  %p4952 = inttoptr i64 %v4951 to ptr
  store i64 %v4950, ptr %p4952, align 8, !alias.scope !3, !noalias !4
  %v4953 = load i64, ptr %slot54, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  %ld4955 = load i64, ptr %p4954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4955, ptr %slot731, align 8
  %v4956 = load i64, ptr %slot55, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %ld4958 = load i64, ptr %p4957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4958, ptr %slot732, align 8
  %v4959 = load i64, ptr %slot1, align 8
  %v4960 = load i64, ptr %slot731, align 8
  %v4961 = load i64, ptr %slot732, align 8
  %call4962 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v4959, i64 %v4960, i64 %v4961) nomerge, !dbg !156
  store i64 %call4962, ptr %slot733, align 8
  %v4963 = load i64, ptr %slot733, align 8
  %v4964 = load i64, ptr %slot54, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  store i64 %v4963, ptr %p4965, align 8, !alias.scope !3, !noalias !4
  %v4966 = load i64, ptr %slot36, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  %ld4968 = load i64, ptr %p4967, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4968, ptr %slot734, align 8
  %v4969 = load i64, ptr %slot734, align 8
  %v4970 = load i64, ptr %slot55, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  store i64 %v4969, ptr %p4971, align 8, !alias.scope !3, !noalias !4
  %v4972 = load i64, ptr %slot55, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  %ld4974 = load i64, ptr %p4973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4974, ptr %slot735, align 8
  %v4975 = load i64, ptr %slot735, align 8
  %op4976 = add i64 %v4975, 32
  store i64 %op4976, ptr %slot736, align 8
  %v4977 = load i64, ptr %slot736, align 8
  %v4978 = load i64, ptr %slot55, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  store i64 %v4977, ptr %p4979, align 8, !alias.scope !3, !noalias !4
  %v4980 = load i64, ptr %slot56, align 8
  %p4981 = inttoptr i64 %v4980 to ptr
  store i64 0, ptr %p4981, align 8, !alias.scope !3, !noalias !4
  %v4982 = load i64, ptr %slot55, align 8
  %p4983 = inttoptr i64 %v4982 to ptr
  %ld4984 = load i64, ptr %p4983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4984, ptr %slot737, align 8
  %v4985 = load i64, ptr %slot56, align 8
  %p4986 = inttoptr i64 %v4985 to ptr
  %ld4987 = load i64, ptr %p4986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4987, ptr %slot738, align 8
  %v4988 = load i64, ptr %slot1, align 8
  %v4989 = load i64, ptr %slot737, align 8
  %v4990 = load i64, ptr %slot738, align 8
  %call4991 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v4988, i64 %v4989, i64 %v4990) nomerge, !dbg !158
  store { i64, i64 } %call4991, ptr %callresult740, align 8
  %addr4992 = ptrtoint ptr %callresult740 to i64
  store i64 %addr4992, ptr %slot739, align 8
  %v4993 = load i64, ptr %slot739, align 8
  %v4994 = load i64, ptr %slot55, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  store i64 %v4993, ptr %p4995, align 8, !alias.scope !3, !noalias !4
  %v4996 = load i64, ptr %slot52, align 8
  %p4997 = inttoptr i64 %v4996 to ptr
  %ld4998 = load i64, ptr %p4997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4998, ptr %slot741, align 8
  %v4999 = load i64, ptr %slot53, align 8
  %p5000 = inttoptr i64 %v4999 to ptr
  %ld5001 = load i64, ptr %p5000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5001, ptr %slot742, align 8
  %v5002 = load i64, ptr %slot54, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  %ld5004 = load i64, ptr %p5003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5004, ptr %slot743, align 8
  %v5005 = load i64, ptr %slot55, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  %ld5007 = load i64, ptr %p5006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5007, ptr %slot744, align 8
  %v5008 = load i64, ptr %slot1, align 8
  %v5009 = load i64, ptr %slot741, align 8
  %v5010 = load i64, ptr %slot742, align 8
  %v5011 = load i64, ptr %slot743, align 8
  %v5012 = load i64, ptr %slot744, align 8
  %call5013 = call i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64 %v5008, i64 %v5009, i64 %v5010, i64 %v5011, i64 %v5012) nomerge, !dbg !160
  store i64 %call5013, ptr %slot745, align 8
  %v5014 = load i64, ptr %slot745, align 8
  %v5015 = load i64, ptr %slot52, align 8
  %p5016 = inttoptr i64 %v5015 to ptr
  store i64 %v5014, ptr %p5016, align 8, !alias.scope !3, !noalias !4
  %v5017 = load i64, ptr %slot24, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  %ld5019 = load i32, ptr %p5018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5019, ptr %slot746, align 8
  %v5020 = load i32, ptr %slot746, align 8
  %cv5021 = zext i32 %v5020 to i64
  %cond5022 = icmp ne i64 %cv5021, 0
  br i1 %cond5022, label %bb_rcslotdrop1406, label %bb_rcslotdone1406
bb_rcslotdrop1406:
  %v5023 = load i64, ptr %slot24, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  store i32 0, ptr %p5024, align 4, !alias.scope !3, !noalias !4
  %v5025 = load i64, ptr %slot30, align 8
  store i64 %v5025, ptr %slot747, align 8
  %v5026 = load i64, ptr %slot25, align 8
  %p5027 = inttoptr i64 %v5026 to ptr
  %ld5028 = load i32, ptr %p5027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5028, ptr %slot748, align 8
  %v5029 = load i32, ptr %slot748, align 8
  %op5030 = and i32 %v5029, 28
  store i32 %op5030, ptr %slot749, align 8
  %v5031 = load i32, ptr %slot749, align 8
  %cv5032 = zext i32 %v5031 to i64
  %cond5033 = icmp ne i64 %cv5032, 0
  br i1 %cond5033, label %bb_rcslotrole1406, label %bb_rcslotowner1406
bb_rcslotrole1406:
  %v5034 = load i64, ptr %slot73, align 8
  store i64 %v5034, ptr %slot750, align 8
  %v5035 = load i64, ptr %slot750, align 8
  %v5036 = load i64, ptr %slot747, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5035, i64 %v5036) nomerge, !dbg !160
  br label %bb_rcslotdone1406
bb_rcslotowner1406:
  %v5037 = load i64, ptr %slot73, align 8
  store i64 %v5037, ptr %slot751, align 8
  %v5038 = load i64, ptr %slot751, align 8
  %v5039 = load i64, ptr %slot747, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v5038, i64 %v5039) nomerge, !dbg !160
  br label %bb_rcslotdone1406
bb_rcslotdone1406:
  %v5040 = load i64, ptr %slot36, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  %ld5042 = load i64, ptr %p5041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5042, ptr %slot752, align 8
  %v5043 = load i64, ptr %slot752, align 8
  %v5044 = load i64, ptr %slot52, align 8
  %p5045 = inttoptr i64 %v5044 to ptr
  store i64 %v5043, ptr %p5045, align 8, !alias.scope !3, !noalias !4
  %v5046 = load i64, ptr %slot52, align 8
  %p5047 = inttoptr i64 %v5046 to ptr
  %ld5048 = load i64, ptr %p5047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5048, ptr %slot753, align 8
  %v5049 = load i64, ptr %slot753, align 8
  %op5050 = add i64 %v5049, 32
  store i64 %op5050, ptr %slot754, align 8
  %v5051 = load i64, ptr %slot754, align 8
  %v5052 = load i64, ptr %slot52, align 8
  %p5053 = inttoptr i64 %v5052 to ptr
  store i64 %v5051, ptr %p5053, align 8, !alias.scope !3, !noalias !4
  %v5054 = load i64, ptr %slot24, align 8
  %p5055 = inttoptr i64 %v5054 to ptr
  %ld5056 = load i32, ptr %p5055, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5056, ptr %slot755, align 8
  %v5057 = load i32, ptr %slot755, align 8
  %cv5058 = zext i32 %v5057 to i64
  %cond5059 = icmp ne i64 %cv5058, 0
  br i1 %cond5059, label %bb_rcslotdrop1418, label %bb_rcslotdone1418
bb_rcslotdrop1418:
  %v5060 = load i64, ptr %slot24, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  store i32 0, ptr %p5061, align 4, !alias.scope !3, !noalias !4
  %v5062 = load i64, ptr %slot30, align 8
  store i64 %v5062, ptr %slot756, align 8
  %v5063 = load i64, ptr %slot25, align 8
  %p5064 = inttoptr i64 %v5063 to ptr
  %ld5065 = load i32, ptr %p5064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5065, ptr %slot757, align 8
  %v5066 = load i32, ptr %slot757, align 8
  %op5067 = and i32 %v5066, 28
  store i32 %op5067, ptr %slot758, align 8
  %v5068 = load i32, ptr %slot758, align 8
  %cv5069 = zext i32 %v5068 to i64
  %cond5070 = icmp ne i64 %cv5069, 0
  br i1 %cond5070, label %bb_rcslotrole1418, label %bb_rcslotowner1418
bb_rcslotrole1418:
  %v5071 = load i64, ptr %slot73, align 8
  store i64 %v5071, ptr %slot759, align 8
  %v5072 = load i64, ptr %slot759, align 8
  %v5073 = load i64, ptr %slot756, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5072, i64 %v5073) nomerge, !dbg !162
  br label %bb_rcslotdone1418
bb_rcslotowner1418:
  %v5074 = load i64, ptr %slot73, align 8
  store i64 %v5074, ptr %slot760, align 8
  %v5075 = load i64, ptr %slot760, align 8
  %v5076 = load i64, ptr %slot756, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5075, i64 %v5076) nomerge, !dbg !162
  br label %bb_rcslotdone1418
bb_rcslotdone1418:
  %v5077 = load i64, ptr %slot53, align 8
  %p5078 = inttoptr i64 %v5077 to ptr
  store i64 1, ptr %p5078, align 8, !alias.scope !3, !noalias !4
  %v5079 = load i64, ptr %slot52, align 8
  %p5080 = inttoptr i64 %v5079 to ptr
  %ld5081 = load i64, ptr %p5080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5081, ptr %slot761, align 8
  %v5082 = load i64, ptr %slot53, align 8
  %p5083 = inttoptr i64 %v5082 to ptr
  %ld5084 = load i64, ptr %p5083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5084, ptr %slot762, align 8
  %v5085 = load i64, ptr %slot1, align 8
  %v5086 = load i64, ptr %slot761, align 8
  %v5087 = load i64, ptr %slot762, align 8
  %call5088 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v5085, i64 %v5086, i64 %v5087) nomerge, !dbg !164
  store { i64, i64 } %call5088, ptr %callresult764, align 8
  %addr5089 = ptrtoint ptr %callresult764 to i64
  store i64 %addr5089, ptr %slot763, align 8
  %v5090 = load i64, ptr %slot763, align 8
  %v5091 = load i64, ptr %slot52, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i64 %v5090, ptr %p5092, align 8, !alias.scope !3, !noalias !4
  %v5093 = load i64, ptr %slot24, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  %ld5095 = load i32, ptr %p5094, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5095, ptr %slot765, align 8
  %v5096 = load i32, ptr %slot765, align 8
  %cv5097 = zext i32 %v5096 to i64
  %cond5098 = icmp ne i64 %cv5097, 0
  br i1 %cond5098, label %bb_rcslotdrop1430, label %bb_rcslotdone1430
bb_rcslotdrop1430:
  %v5099 = load i64, ptr %slot24, align 8
  %p5100 = inttoptr i64 %v5099 to ptr
  store i32 0, ptr %p5100, align 4, !alias.scope !3, !noalias !4
  %v5101 = load i64, ptr %slot30, align 8
  store i64 %v5101, ptr %slot766, align 8
  %v5102 = load i64, ptr %slot25, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  %ld5104 = load i32, ptr %p5103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5104, ptr %slot767, align 8
  %v5105 = load i32, ptr %slot767, align 8
  %op5106 = and i32 %v5105, 28
  store i32 %op5106, ptr %slot768, align 8
  %v5107 = load i32, ptr %slot768, align 8
  %cv5108 = zext i32 %v5107 to i64
  %cond5109 = icmp ne i64 %cv5108, 0
  br i1 %cond5109, label %bb_rcslotrole1430, label %bb_rcslotowner1430
bb_rcslotrole1430:
  %v5110 = load i64, ptr %slot73, align 8
  store i64 %v5110, ptr %slot769, align 8
  %v5111 = load i64, ptr %slot769, align 8
  %v5112 = load i64, ptr %slot766, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5111, i64 %v5112) nomerge, !dbg !164
  br label %bb_rcslotdone1430
bb_rcslotowner1430:
  %v5113 = load i64, ptr %slot73, align 8
  store i64 %v5113, ptr %slot770, align 8
  %v5114 = load i64, ptr %slot770, align 8
  %v5115 = load i64, ptr %slot766, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5114, i64 %v5115) nomerge, !dbg !164
  br label %bb_rcslotdone1430
bb_rcslotdone1430:
  %v5116 = load i64, ptr %slot52, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  %ld5118 = load i64, ptr %p5117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5118, ptr %slot771, align 8
  %v5119 = load i64, ptr %slot1, align 8
  %v5120 = load i64, ptr %slot771, align 8
  %call5121 = call i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64 %v5119, i64 %v5120) nomerge, !dbg !166
  store i64 %call5121, ptr %slot772, align 8
  %v5122 = load i64, ptr %slot772, align 8
  %v5123 = load i64, ptr %slot52, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i64 %v5122, ptr %p5124, align 8, !alias.scope !3, !noalias !4
  %v5125 = load i64, ptr %slot52, align 8
  %p5126 = inttoptr i64 %v5125 to ptr
  %ld5127 = load i64, ptr %p5126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5127, ptr %slot773, align 8
  %v5128 = load i64, ptr %slot773, align 8
  %v5129 = load i64, ptr %slot42, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  store i64 %v5128, ptr %p5130, align 8, !alias.scope !3, !noalias !4
  %v5131 = load i64, ptr %slot40, align 8
  %v5132 = load i64, ptr %slot52, align 8
  %p5133 = inttoptr i64 %v5132 to ptr
  store i64 %v5131, ptr %p5133, align 8, !alias.scope !3, !noalias !4
  %v5134 = load i64, ptr %slot52, align 8
  %p5135 = inttoptr i64 %v5134 to ptr
  %ld5136 = load i64, ptr %p5135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5136, ptr %slot774, align 8
  %v5137 = load i64, ptr %slot24, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  %ld5139 = load i32, ptr %p5138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5139, ptr %slot775, align 8
  %v5140 = load i64, ptr %slot25, align 8
  %p5141 = inttoptr i64 %v5140 to ptr
  %ld5142 = load i32, ptr %p5141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5142, ptr %slot776, align 8
  %v5143 = load i32, ptr %slot776, align 8
  %op5144 = and i32 %v5143, 24
  store i32 %op5144, ptr %slot776, align 8
  %v5145 = load i32, ptr %slot776, align 8
  %cmp5146 = icmp eq i32 %v5145, 0
  %cv5147 = zext i1 %cmp5146 to i32
  store i32 %cv5147, ptr %slot777, align 8
  %v5148 = load i32, ptr %slot775, align 8
  %v5149 = load i32, ptr %slot777, align 8
  %op5150 = and i32 %v5148, %v5149
  store i32 %op5150, ptr %slot778, align 8
  %v5151 = load i64, ptr %slot74, align 8
  store i64 %v5151, ptr %slot779, align 8
  %v5152 = load i32, ptr %slot778, align 8
  %op5153 = mul i32 %v5152, 4
  store i32 %op5153, ptr %slot780, align 8
  %v5154 = load i32, ptr %slot780, align 8
  %op5155 = or i32 %v5154, 0
  store i32 %op5155, ptr %slot781, align 8
  %v5156 = load i64, ptr %slot32, align 8
  store i64 %v5156, ptr %slot782, align 8
  %v5157 = load i64, ptr %slot73, align 8
  %v5158 = load i64, ptr %slot782, align 8
  %v5159 = load i64, ptr %slot774, align 8
  %v5160 = load i64, ptr %slot779, align 8
  %cv5161 = trunc i64 %v5160 to i32
  %v5162 = load i32, ptr %slot781, align 8
  %call5163 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64 %v5157, i64 %v5158, i64 %v5159, i32 %cv5161, i32 %v5162) nomerge, !dbg !168
  store i32 %call5163, ptr %slot783, align 8
  %v5164 = load i32, ptr %slot783, align 8
  %cv5165 = zext i32 %v5164 to i64
  %cond5166 = icmp ne i64 %cv5165, 0
  br i1 %cond5166, label %bb_rcsuccess1454, label %bb_rcfailure1454
bb_rcfailure1454:
  %v5167 = load i64, ptr %slot73, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  %call5169 = call i32 @myl_rc_take_failure(ptr %p5168) nomerge, !dbg !168
  store i32 %call5169, ptr %slot784, align 8
  %v5170 = load i64, ptr %slot1, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %v5172 = load i32, ptr %slot784, align 8
  %call5173 = call i32 @myl_qbe_rc_status(ptr %p5171, i32 %v5172) nomerge, !dbg !168
  store i32 %call5173, ptr %slot785, align 8
  br label %bb_failure
bb_rcsuccess1454:
  %v5174 = load i32, ptr %slot778, align 8
  %cv5175 = zext i32 %v5174 to i64
  %cond5176 = icmp ne i64 %cv5175, 0
  br i1 %cond5176, label %bb_rchtaken1457, label %bb_rchcopied1457
bb_rchcopied1457:
  %v5177 = load i64, ptr %slot24, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  %ld5179 = load i32, ptr %p5178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5179, ptr %slot786, align 8
  %v5180 = load i32, ptr %slot786, align 8
  %cv5181 = zext i32 %v5180 to i64
  %cond5182 = icmp ne i64 %cv5181, 0
  br i1 %cond5182, label %bb_rcslotdrop1460, label %bb_rcslotdone1460
bb_rcslotdrop1460:
  %v5183 = load i64, ptr %slot24, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  store i32 0, ptr %p5184, align 4, !alias.scope !3, !noalias !4
  %v5185 = load i64, ptr %slot30, align 8
  store i64 %v5185, ptr %slot787, align 8
  %v5186 = load i64, ptr %slot25, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i32, ptr %p5187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5188, ptr %slot788, align 8
  %v5189 = load i32, ptr %slot788, align 8
  %op5190 = and i32 %v5189, 28
  store i32 %op5190, ptr %slot789, align 8
  %v5191 = load i32, ptr %slot789, align 8
  %cv5192 = zext i32 %v5191 to i64
  %cond5193 = icmp ne i64 %cv5192, 0
  br i1 %cond5193, label %bb_rcslotrole1460, label %bb_rcslotowner1460
bb_rcslotrole1460:
  %v5194 = load i64, ptr %slot73, align 8
  store i64 %v5194, ptr %slot790, align 8
  %v5195 = load i64, ptr %slot790, align 8
  %v5196 = load i64, ptr %slot787, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5195, i64 %v5196) nomerge, !dbg !168
  br label %bb_rcslotdone1460
bb_rcslotowner1460:
  %v5197 = load i64, ptr %slot73, align 8
  store i64 %v5197, ptr %slot791, align 8
  %v5198 = load i64, ptr %slot791, align 8
  %v5199 = load i64, ptr %slot787, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v5198, i64 %v5199) nomerge, !dbg !168
  br label %bb_rcslotdone1460
bb_rcslotdone1460:
  br label %bb_rchprepared1457
bb_rchtaken1457:
  %v5200 = load i64, ptr %slot24, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  store i32 0, ptr %p5201, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1457
bb_rchprepared1457:
  %v5202 = load i64, ptr %slot28, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  store i32 2, ptr %p5203, align 4, !alias.scope !3, !noalias !4
  %v5204 = load i64, ptr %slot27, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  store i32 1, ptr %p5205, align 4, !alias.scope !3, !noalias !4
  %v5206 = load i64, ptr %slot30, align 8
  store i64 %v5206, ptr %slot792, align 8
  %v5207 = load i64, ptr %slot32, align 8
  store i64 %v5207, ptr %slot793, align 8
  %v5208 = load i64, ptr %slot793, align 8
  %v5209 = load i64, ptr %slot792, align 8
  %p5210 = inttoptr i64 %v5208 to ptr
  %p5211 = inttoptr i64 %v5209 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5211, ptr %p5210, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5212 = load i64, ptr %slot25, align 8
  %p5213 = inttoptr i64 %v5212 to ptr
  store i32 2, ptr %p5213, align 4, !alias.scope !3, !noalias !4
  %v5214 = load i64, ptr %slot28, align 8
  %p5215 = inttoptr i64 %v5214 to ptr
  %ld5216 = load i32, ptr %p5215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5216, ptr %slot794, align 8
  %v5217 = load i32, ptr %slot794, align 8
  %v5218 = load i64, ptr %slot25, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  store i32 %v5217, ptr %p5219, align 4, !alias.scope !3, !noalias !4
  %v5220 = load i64, ptr %slot27, align 8
  %p5221 = inttoptr i64 %v5220 to ptr
  store i32 0, ptr %p5221, align 4, !alias.scope !3, !noalias !4
  %v5222 = load i64, ptr %slot24, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  store i32 1, ptr %p5223, align 4, !alias.scope !3, !noalias !4
  %v5224 = load i64, ptr %slot792, align 8
  %v5225 = load i64, ptr %slot52, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  store i64 %v5224, ptr %p5226, align 8, !alias.scope !3, !noalias !4
  %v5227 = load i64, ptr %slot52, align 8
  %p5228 = inttoptr i64 %v5227 to ptr
  %ld5229 = load i64, ptr %p5228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5229, ptr %slot795, align 8
  %v5230 = load i64, ptr %slot32, align 8
  store i64 %v5230, ptr %slot796, align 8
  %v5231 = load i64, ptr %slot74, align 8
  store i64 %v5231, ptr %slot797, align 8
  %v5232 = load i64, ptr %slot795, align 8
  %op5233 = add i64 %v5232, 8
  store i64 %op5233, ptr %slot798, align 8
  %v5234 = load i64, ptr %slot798, align 8
  %p5235 = inttoptr i64 %v5234 to ptr
  %ld5236 = load i64, ptr %p5235, align 8
  store i64 %ld5236, ptr %slot799, align 8
  %v5237 = load i64, ptr %slot799, align 8
  %cmp5238 = icmp ne i64 %v5237, 0
  %cv5239 = zext i1 %cmp5238 to i32
  store i32 %cv5239, ptr %slot800, align 8
  %v5240 = load i32, ptr %slot800, align 8
  %cv5241 = zext i32 %v5240 to i64
  %cond5242 = icmp ne i64 %cv5241, 0
  br i1 %cond5242, label %bb_rcmoveheader1484, label %bb_rcmovenext1484
bb_rcmoveheader1484:
  %v5243 = load i64, ptr %slot799, align 8
  %op5244 = sub i64 %v5243, 16
  store i64 %op5244, ptr %slot801, align 8
  %v5245 = load i64, ptr %slot799, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %rgep5247 = getelementptr i8, ptr %p5246, i64 -16
  %ld5248 = load i64, ptr %rgep5247, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5248, ptr %slot802, align 8
  %v5249 = load i64, ptr %slot802, align 8
  %op5250 = and i64 %v5249, 5764607523034234881
  store i64 %op5250, ptr %slot803, align 8
  %v5251 = load i64, ptr %slot803, align 8
  %cmp5252 = icmp ne i64 %v5251, 0
  %cv5253 = zext i1 %cmp5252 to i32
  store i32 %cv5253, ptr %slot804, align 8
  %v5254 = load i32, ptr %slot804, align 8
  %cv5255 = zext i32 %v5254 to i64
  %cond5256 = icmp ne i64 %cv5255, 0
  br i1 %cond5256, label %bb_rcmoveslow1481, label %bb_rcmovenext1484
bb_rcmovenext1484:
  %v5257 = load i64, ptr %slot795, align 8
  %v5258 = load i64, ptr %slot796, align 8
  %p5259 = inttoptr i64 %v5257 to ptr
  %p5260 = inttoptr i64 %v5258 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5260, ptr %p5259, i64 24, i1 false)
  %v5261 = load i64, ptr %slot795, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  store i64 0, ptr %p5262, align 8
  %v5263 = load i64, ptr %slot795, align 8
  %op5264 = add i64 %v5263, 8
  store i64 %op5264, ptr %slot805, align 8
  %v5265 = load i64, ptr %slot805, align 8
  %p5266 = inttoptr i64 %v5265 to ptr
  store i64 0, ptr %p5266, align 8
  %v5267 = load i64, ptr %slot795, align 8
  %op5268 = add i64 %v5267, 16
  store i64 %op5268, ptr %slot806, align 8
  %v5269 = load i64, ptr %slot806, align 8
  %p5270 = inttoptr i64 %v5269 to ptr
  store i64 0, ptr %p5270, align 8
  br label %bb_rcmoved1481
bb_rcmoveslow1481:
  %v5271 = load i64, ptr %slot73, align 8
  %v5272 = load i64, ptr %slot796, align 8
  %v5273 = load i64, ptr %slot795, align 8
  %v5274 = load i64, ptr %slot797, align 8
  %cv5275 = trunc i64 %v5274 to i32
  %call5276 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v5271, i64 %v5272, i64 %v5273, i32 %cv5275) nomerge, !dbg !170
  store i32 %call5276, ptr %slot807, align 8
  %v5277 = load i32, ptr %slot807, align 8
  %cv5278 = zext i32 %v5277 to i64
  %cond5279 = icmp ne i64 %cv5278, 0
  br i1 %cond5279, label %bb_rcsuccess1493, label %bb_rcfailure1493
bb_rcfailure1493:
  %v5280 = load i64, ptr %slot73, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  %call5282 = call i32 @myl_rc_take_failure(ptr %p5281) nomerge, !dbg !170
  store i32 %call5282, ptr %slot808, align 8
  %v5283 = load i64, ptr %slot1, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  %v5285 = load i32, ptr %slot808, align 8
  %call5286 = call i32 @myl_qbe_rc_status(ptr %p5284, i32 %v5285) nomerge, !dbg !170
  store i32 %call5286, ptr %slot809, align 8
  br label %bb_failure
bb_rcsuccess1493:
  br label %bb_rcmoved1481
bb_rcmoved1481:
  %v5287 = load i64, ptr %slot24, align 8
  %p5288 = inttoptr i64 %v5287 to ptr
  store i32 0, ptr %p5288, align 4, !alias.scope !3, !noalias !4
  %v5289 = load i64, ptr %slot28, align 8
  %p5290 = inttoptr i64 %v5289 to ptr
  store i32 2, ptr %p5290, align 4, !alias.scope !3, !noalias !4
  %v5291 = load i64, ptr %slot27, align 8
  %p5292 = inttoptr i64 %v5291 to ptr
  store i32 1, ptr %p5292, align 4, !alias.scope !3, !noalias !4
  %v5293 = load i64, ptr %slot12, align 8
  %p5294 = inttoptr i64 %v5293 to ptr
  %ld5295 = load i32, ptr %p5294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5295, ptr %slot810, align 8
  %v5296 = load i32, ptr %slot810, align 8
  %cv5297 = zext i32 %v5296 to i64
  %cond5298 = icmp ne i64 %cv5297, 0
  br i1 %cond5298, label %bb_rcslotdrop1502, label %bb_rcslotdone1502
bb_rcslotdrop1502:
  %v5299 = load i64, ptr %slot12, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  store i32 0, ptr %p5300, align 4, !alias.scope !3, !noalias !4
  %v5301 = load i64, ptr %slot43, align 8
  store i64 %v5301, ptr %slot811, align 8
  %v5302 = load i64, ptr %slot13, align 8
  %p5303 = inttoptr i64 %v5302 to ptr
  %ld5304 = load i32, ptr %p5303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5304, ptr %slot812, align 8
  %v5305 = load i32, ptr %slot812, align 8
  %op5306 = and i32 %v5305, 28
  store i32 %op5306, ptr %slot813, align 8
  %v5307 = load i32, ptr %slot813, align 8
  %cv5308 = zext i32 %v5307 to i64
  %cond5309 = icmp ne i64 %cv5308, 0
  br i1 %cond5309, label %bb_rcslotrole1502, label %bb_rcslotowner1502
bb_rcslotrole1502:
  %v5310 = load i64, ptr %slot73, align 8
  store i64 %v5310, ptr %slot814, align 8
  %v5311 = load i64, ptr %slot814, align 8
  %v5312 = load i64, ptr %slot811, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5311, i64 %v5312) nomerge, !dbg !170
  br label %bb_rcslotdone1502
bb_rcslotowner1502:
  %v5313 = load i64, ptr %slot811, align 8
  %p5315 = inttoptr i64 %v5313 to ptr
  %gep5316 = getelementptr i8, ptr %p5315, i64 8
  %op5314 = ptrtoint ptr %gep5316 to i64
  store i64 %op5314, ptr %slot815, align 8
  %v5317 = load i64, ptr %slot73, align 8
  store i64 %v5317, ptr %slot816, align 8
  %v5318 = load i64, ptr %slot815, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  %ld5320 = load i64, ptr %p5319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5320, ptr %slot817, align 8
  %v5321 = load i64, ptr %slot817, align 8
  %cmp5322 = icmp ne i64 %v5321, 0
  %cv5323 = zext i1 %cmp5322 to i32
  store i32 %cv5323, ptr %slot818, align 8
  %v5324 = load i32, ptr %slot818, align 8
  %cv5325 = zext i32 %v5324 to i64
  %cond5326 = icmp ne i64 %cv5325, 0
  br i1 %cond5326, label %bb_rcgnn1520, label %bb_rcgdone1520
bb_rcgnn1520:
  %v5327 = load i64, ptr %slot817, align 8
  %op5328 = sub i64 %v5327, 16
  store i64 %op5328, ptr %slot819, align 8
  %v5329 = load i64, ptr %slot817, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %rgep5331 = getelementptr i8, ptr %p5330, i64 -16
  %ld5332 = load i64, ptr %rgep5331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5332, ptr %slot820, align 8
  %v5333 = load i64, ptr %slot820, align 8
  %op5334 = and i64 %v5333, 4611686018427387906
  store i64 %op5334, ptr %slot821, align 8
  %v5335 = load i64, ptr %slot821, align 8
  %cmp5336 = icmp ne i64 %v5335, 0
  %cv5337 = zext i1 %cmp5336 to i32
  store i32 %cv5337, ptr %slot822, align 8
  %v5338 = load i32, ptr %slot822, align 8
  %cv5339 = zext i32 %v5338 to i64
  %cond5340 = icmp ne i64 %cv5339, 0
  br i1 %cond5340, label %bb_rcgclear1520, label %bb_rcgcounted1520
bb_rcgcounted1520:
  %v5341 = load i64, ptr %slot817, align 8
  %op5342 = sub i64 %v5341, 32
  store i64 %op5342, ptr %slot823, align 8
  %v5343 = load i64, ptr %slot817, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  %rgep5345 = getelementptr i8, ptr %p5344, i64 -32
  %ld5346 = load i64, ptr %rgep5345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5346, ptr %slot824, align 8
  %v5347 = load i64, ptr %slot824, align 8
  %op5348 = sub i64 %v5347, 1
  store i64 %op5348, ptr %slot825, align 8
  %v5349 = load i64, ptr %slot825, align 8
  %cmp5350 = icmp eq i64 %v5349, 0
  %cv5351 = zext i1 %cmp5350 to i32
  store i32 %cv5351, ptr %slot826, align 8
  %v5352 = load i32, ptr %slot826, align 8
  %cv5353 = zext i32 %v5352 to i64
  %cond5354 = icmp ne i64 %cv5353, 0
  br i1 %cond5354, label %bb_rcglast1520, label %bb_rcgdec1520
bb_rcglast1520:
  %v5355 = load i64, ptr %slot817, align 8
  %op5356 = sub i64 %v5355, 24
  store i64 %op5356, ptr %slot827, align 8
  %v5357 = load i64, ptr %slot817, align 8
  %p5358 = inttoptr i64 %v5357 to ptr
  %rgep5359 = getelementptr i8, ptr %p5358, i64 -24
  %ld5360 = load i64, ptr %rgep5359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5360, ptr %slot828, align 8
  %v5361 = load i64, ptr %slot828, align 8
  %cmp5362 = icmp ne i64 %v5361, 0
  %cv5363 = zext i1 %cmp5362 to i32
  store i32 %cv5363, ptr %slot829, align 8
  %v5364 = load i32, ptr %slot829, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcgdec1520, label %bb_rcgslow1520
bb_rcgslow1520:
  %v5367 = load i64, ptr %slot816, align 8
  %v5368 = load i64, ptr %slot815, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5367, i64 %v5368) nomerge, !dbg !170
  br label %bb_rcgdone1520
bb_rcgdec1520:
  %v5369 = load i64, ptr %slot825, align 8
  %v5370 = load i64, ptr %slot817, align 8
  %p5371 = inttoptr i64 %v5370 to ptr
  %rgep5372 = getelementptr i8, ptr %p5371, i64 -32
  store i64 %v5369, ptr %rgep5372, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1520
bb_rcgclear1520:
  %v5373 = load i64, ptr %slot815, align 8
  %p5374 = inttoptr i64 %v5373 to ptr
  store i64 0, ptr %p5374, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1520
bb_rcgdone1520:
  %v5375 = load i64, ptr %slot811, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  store i64 0, ptr %p5376, align 8, !alias.scope !3, !noalias !4
  %v5377 = load i64, ptr %slot811, align 8
  %p5379 = inttoptr i64 %v5377 to ptr
  %gep5380 = getelementptr i8, ptr %p5379, i64 8
  %op5378 = ptrtoint ptr %gep5380 to i64
  store i64 %op5378, ptr %slot830, align 8
  %v5381 = load i64, ptr %slot830, align 8
  %p5382 = inttoptr i64 %v5381 to ptr
  store i64 0, ptr %p5382, align 8, !alias.scope !3, !noalias !4
  %v5383 = load i64, ptr %slot811, align 8
  %p5385 = inttoptr i64 %v5383 to ptr
  %gep5386 = getelementptr i8, ptr %p5385, i64 16
  %op5384 = ptrtoint ptr %gep5386 to i64
  store i64 %op5384, ptr %slot831, align 8
  %v5387 = load i64, ptr %slot831, align 8
  %p5388 = inttoptr i64 %v5387 to ptr
  store i64 0, ptr %p5388, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1502
bb_rcslotdone1502:
  %v5389 = load i64, ptr %slot43, align 8
  store i64 %v5389, ptr %slot832, align 8
  %v5390 = load i64, ptr %slot32, align 8
  store i64 %v5390, ptr %slot833, align 8
  %v5391 = load i64, ptr %slot833, align 8
  %v5392 = load i64, ptr %slot832, align 8
  %p5393 = inttoptr i64 %v5391 to ptr
  %p5394 = inttoptr i64 %v5392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5394, ptr %p5393, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5395 = load i64, ptr %slot27, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  store i32 0, ptr %p5396, align 4, !alias.scope !3, !noalias !4
  %v5397 = load i64, ptr %slot13, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  store i32 2, ptr %p5398, align 4, !alias.scope !3, !noalias !4
  %v5399 = load i64, ptr %slot28, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  %ld5401 = load i32, ptr %p5400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5401, ptr %slot834, align 8
  %v5402 = load i32, ptr %slot834, align 8
  %v5403 = load i64, ptr %slot13, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  store i32 %v5402, ptr %p5404, align 4, !alias.scope !3, !noalias !4
  %v5405 = load i64, ptr %slot12, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  store i32 1, ptr %p5406, align 4, !alias.scope !3, !noalias !4
  %v5407 = load i64, ptr %slot41, align 8
  %v5408 = load i64, ptr %slot52, align 8
  %p5409 = inttoptr i64 %v5408 to ptr
  store i64 %v5407, ptr %p5409, align 8, !alias.scope !3, !noalias !4
  %v5410 = load i64, ptr %slot52, align 8
  %p5411 = inttoptr i64 %v5410 to ptr
  %ld5412 = load i64, ptr %p5411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5412, ptr %slot835, align 8
  %v5413 = load i64, ptr %slot24, align 8
  %p5414 = inttoptr i64 %v5413 to ptr
  %ld5415 = load i32, ptr %p5414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5415, ptr %slot836, align 8
  %v5416 = load i64, ptr %slot25, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %ld5418 = load i32, ptr %p5417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5418, ptr %slot837, align 8
  %v5419 = load i32, ptr %slot837, align 8
  %op5420 = and i32 %v5419, 24
  store i32 %op5420, ptr %slot837, align 8
  %v5421 = load i32, ptr %slot837, align 8
  %cmp5422 = icmp eq i32 %v5421, 0
  %cv5423 = zext i1 %cmp5422 to i32
  store i32 %cv5423, ptr %slot838, align 8
  %v5424 = load i32, ptr %slot836, align 8
  %v5425 = load i32, ptr %slot838, align 8
  %op5426 = and i32 %v5424, %v5425
  store i32 %op5426, ptr %slot839, align 8
  %v5427 = load i32, ptr %slot839, align 8
  %cv5428 = zext i32 %v5427 to i64
  %cond5429 = icmp ne i64 %cv5428, 0
  br i1 %cond5429, label %bb_rcprivateown1540, label %bb_rcprivateloan1540
bb_rcprivateown1540:
  %v5430 = load i64, ptr %slot32, align 8
  store i64 %v5430, ptr %slot840, align 8
  %v5431 = load i64, ptr %slot74, align 8
  store i64 %v5431, ptr %slot841, align 8
  %v5432 = load i64, ptr %slot835, align 8
  %v5433 = load i64, ptr %slot840, align 8
  %op5434 = sub i64 %v5432, %v5433
  store i64 %op5434, ptr %slot842, align 8
  %v5435 = load i64, ptr %slot840, align 8
  %v5436 = load i64, ptr %slot835, align 8
  %op5437 = sub i64 %v5435, %v5436
  store i64 %op5437, ptr %slot843, align 8
  %v5438 = load i64, ptr %slot842, align 8
  %cmp5439 = icmp ult i64 %v5438, 16
  %cv5440 = zext i1 %cmp5439 to i32
  store i32 %cv5440, ptr %slot844, align 8
  %v5441 = load i64, ptr %slot843, align 8
  %cmp5442 = icmp ult i64 %v5441, 16
  %cv5443 = zext i1 %cmp5442 to i32
  store i32 %cv5443, ptr %slot845, align 8
  %v5444 = load i32, ptr %slot844, align 8
  %v5445 = load i32, ptr %slot845, align 8
  %op5446 = or i32 %v5444, %v5445
  store i32 %op5446, ptr %slot846, align 8
  %v5447 = load i32, ptr %slot846, align 8
  %cv5448 = zext i32 %v5447 to i64
  %cond5449 = icmp ne i64 %cv5448, 0
  br i1 %cond5449, label %bb_rcmoveslow1543, label %bb_rcmovecheck1543
bb_rcmovecheck1543:
  %v5450 = load i64, ptr %slot835, align 8
  %op5451 = add i64 %v5450, 0
  store i64 %op5451, ptr %slot847, align 8
  %v5452 = load i64, ptr %slot847, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  %ld5454 = load i64, ptr %p5453, align 8
  store i64 %ld5454, ptr %slot848, align 8
  %v5455 = load i64, ptr %slot848, align 8
  %cmp5456 = icmp ne i64 %v5455, 0
  %cv5457 = zext i1 %cmp5456 to i32
  store i32 %cv5457, ptr %slot849, align 8
  %v5458 = load i32, ptr %slot849, align 8
  %cv5459 = zext i32 %v5458 to i64
  %cond5460 = icmp ne i64 %cv5459, 0
  br i1 %cond5460, label %bb_rcmoveheader1551, label %bb_rcmovenext1551
bb_rcmoveheader1551:
  %v5461 = load i64, ptr %slot848, align 8
  %op5462 = sub i64 %v5461, 16
  store i64 %op5462, ptr %slot850, align 8
  %v5463 = load i64, ptr %slot848, align 8
  %p5464 = inttoptr i64 %v5463 to ptr
  %rgep5465 = getelementptr i8, ptr %p5464, i64 -16
  %ld5466 = load i64, ptr %rgep5465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5466, ptr %slot851, align 8
  %v5467 = load i64, ptr %slot851, align 8
  %op5468 = and i64 %v5467, 5764607523034234881
  store i64 %op5468, ptr %slot852, align 8
  %v5469 = load i64, ptr %slot852, align 8
  %cmp5470 = icmp ne i64 %v5469, 0
  %cv5471 = zext i1 %cmp5470 to i32
  store i32 %cv5471, ptr %slot853, align 8
  %v5472 = load i32, ptr %slot853, align 8
  %cv5473 = zext i32 %v5472 to i64
  %cond5474 = icmp ne i64 %cv5473, 0
  br i1 %cond5474, label %bb_rcmoveslow1543, label %bb_rcmovenext1551
bb_rcmovenext1551:
  %v5475 = load i64, ptr %slot835, align 8
  %v5476 = load i64, ptr %slot840, align 8
  %p5477 = inttoptr i64 %v5475 to ptr
  %p5478 = inttoptr i64 %v5476 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5478, ptr %p5477, i64 16, i1 false)
  %v5479 = load i64, ptr %slot835, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  store i64 0, ptr %p5480, align 8
  %v5481 = load i64, ptr %slot835, align 8
  %op5482 = add i64 %v5481, 8
  store i64 %op5482, ptr %slot854, align 8
  %v5483 = load i64, ptr %slot854, align 8
  %p5484 = inttoptr i64 %v5483 to ptr
  store i64 0, ptr %p5484, align 8
  br label %bb_rcmoved1543
bb_rcmoveslow1543:
  %v5485 = load i64, ptr %slot73, align 8
  %v5486 = load i64, ptr %slot840, align 8
  %v5487 = load i64, ptr %slot835, align 8
  %v5488 = load i64, ptr %slot841, align 8
  %cv5489 = trunc i64 %v5488 to i32
  %call5490 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v5485, i64 %v5486, i64 %v5487, i32 %cv5489) nomerge, !dbg !172
  store i32 %call5490, ptr %slot855, align 8
  %v5491 = load i32, ptr %slot855, align 8
  %cv5492 = zext i32 %v5491 to i64
  %cond5493 = icmp ne i64 %cv5492, 0
  br i1 %cond5493, label %bb_rcsuccess1559, label %bb_rcfailure1559
bb_rcfailure1559:
  %v5494 = load i64, ptr %slot73, align 8
  %p5495 = inttoptr i64 %v5494 to ptr
  %call5496 = call i32 @myl_rc_take_failure(ptr %p5495) nomerge, !dbg !172
  store i32 %call5496, ptr %slot856, align 8
  %v5497 = load i64, ptr %slot1, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  %v5499 = load i32, ptr %slot856, align 8
  %call5500 = call i32 @myl_qbe_rc_status(ptr %p5498, i32 %v5499) nomerge, !dbg !172
  store i32 %call5500, ptr %slot857, align 8
  br label %bb_failure
bb_rcsuccess1559:
  br label %bb_rcmoved1543
bb_rcmoved1543:
  %v5501 = load i64, ptr %slot24, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  store i32 0, ptr %p5502, align 4, !alias.scope !3, !noalias !4
  %v5503 = load i64, ptr %slot28, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  store i32 2, ptr %p5504, align 4, !alias.scope !3, !noalias !4
  %v5505 = load i64, ptr %slot27, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  store i32 1, ptr %p5506, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1540
bb_rcprivateloan1540:
  %v5507 = load i64, ptr %slot32, align 8
  store i64 %v5507, ptr %slot858, align 8
  %v5508 = load i64, ptr %slot73, align 8
  %v5509 = load i64, ptr %slot858, align 8
  %v5510 = load i64, ptr %slot835, align 8
  %call5511 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v5508, i64 %v5509, i64 %v5510) nomerge, !dbg !172
  store i32 %call5511, ptr %slot859, align 8
  %v5512 = load i32, ptr %slot859, align 8
  %cv5513 = zext i32 %v5512 to i64
  %cond5514 = icmp ne i64 %cv5513, 0
  br i1 %cond5514, label %bb_rcsuccess1567, label %bb_rcfailure1567
bb_rcfailure1567:
  %v5515 = load i64, ptr %slot73, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %call5517 = call i32 @myl_rc_take_failure(ptr %p5516) nomerge, !dbg !172
  store i32 %call5517, ptr %slot860, align 8
  %v5518 = load i64, ptr %slot1, align 8
  %p5519 = inttoptr i64 %v5518 to ptr
  %v5520 = load i32, ptr %slot860, align 8
  %call5521 = call i32 @myl_qbe_rc_status(ptr %p5519, i32 %v5520) nomerge, !dbg !172
  store i32 %call5521, ptr %slot861, align 8
  br label %bb_failure
bb_rcsuccess1567:
  %v5522 = load i64, ptr %slot28, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  store i32 2, ptr %p5523, align 4, !alias.scope !3, !noalias !4
  %v5524 = load i64, ptr %slot28, align 8
  %p5525 = inttoptr i64 %v5524 to ptr
  store i32 16, ptr %p5525, align 4, !alias.scope !3, !noalias !4
  %v5526 = load i64, ptr %slot27, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  store i32 1, ptr %p5527, align 4, !alias.scope !3, !noalias !4
  %v5528 = load i64, ptr %slot24, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %ld5530 = load i32, ptr %p5529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5530, ptr %slot862, align 8
  %v5531 = load i32, ptr %slot862, align 8
  %cv5532 = zext i32 %v5531 to i64
  %cond5533 = icmp ne i64 %cv5532, 0
  br i1 %cond5533, label %bb_rcslotdrop1575, label %bb_rcslotdone1575
bb_rcslotdrop1575:
  %v5534 = load i64, ptr %slot24, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  store i32 0, ptr %p5535, align 4, !alias.scope !3, !noalias !4
  %v5536 = load i64, ptr %slot30, align 8
  store i64 %v5536, ptr %slot863, align 8
  %v5537 = load i64, ptr %slot25, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  %ld5539 = load i32, ptr %p5538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5539, ptr %slot864, align 8
  %v5540 = load i32, ptr %slot864, align 8
  %op5541 = and i32 %v5540, 28
  store i32 %op5541, ptr %slot865, align 8
  %v5542 = load i32, ptr %slot865, align 8
  %cv5543 = zext i32 %v5542 to i64
  %cond5544 = icmp ne i64 %cv5543, 0
  br i1 %cond5544, label %bb_rcslotrole1575, label %bb_rcslotowner1575
bb_rcslotrole1575:
  %v5545 = load i64, ptr %slot73, align 8
  store i64 %v5545, ptr %slot866, align 8
  %v5546 = load i64, ptr %slot866, align 8
  %v5547 = load i64, ptr %slot863, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5546, i64 %v5547) nomerge, !dbg !172
  br label %bb_rcslotdone1575
bb_rcslotowner1575:
  %v5548 = load i64, ptr %slot863, align 8
  %p5550 = inttoptr i64 %v5548 to ptr
  %gep5551 = getelementptr i8, ptr %p5550, i64 0
  %op5549 = ptrtoint ptr %gep5551 to i64
  store i64 %op5549, ptr %slot867, align 8
  %v5552 = load i64, ptr %slot73, align 8
  store i64 %v5552, ptr %slot868, align 8
  %v5553 = load i64, ptr %slot867, align 8
  %p5554 = inttoptr i64 %v5553 to ptr
  %ld5555 = load i64, ptr %p5554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5555, ptr %slot869, align 8
  %v5556 = load i64, ptr %slot869, align 8
  %cmp5557 = icmp ne i64 %v5556, 0
  %cv5558 = zext i1 %cmp5557 to i32
  store i32 %cv5558, ptr %slot870, align 8
  %v5559 = load i32, ptr %slot870, align 8
  %cv5560 = zext i32 %v5559 to i64
  %cond5561 = icmp ne i64 %cv5560, 0
  br i1 %cond5561, label %bb_rcgnn1593, label %bb_rcgdone1593
bb_rcgnn1593:
  %v5562 = load i64, ptr %slot869, align 8
  %op5563 = sub i64 %v5562, 16
  store i64 %op5563, ptr %slot871, align 8
  %v5564 = load i64, ptr %slot869, align 8
  %p5565 = inttoptr i64 %v5564 to ptr
  %rgep5566 = getelementptr i8, ptr %p5565, i64 -16
  %ld5567 = load i64, ptr %rgep5566, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5567, ptr %slot872, align 8
  %v5568 = load i64, ptr %slot872, align 8
  %op5569 = and i64 %v5568, 4611686018427387906
  store i64 %op5569, ptr %slot873, align 8
  %v5570 = load i64, ptr %slot873, align 8
  %cmp5571 = icmp ne i64 %v5570, 0
  %cv5572 = zext i1 %cmp5571 to i32
  store i32 %cv5572, ptr %slot874, align 8
  %v5573 = load i32, ptr %slot874, align 8
  %cv5574 = zext i32 %v5573 to i64
  %cond5575 = icmp ne i64 %cv5574, 0
  br i1 %cond5575, label %bb_rcgclear1593, label %bb_rcgcounted1593
bb_rcgcounted1593:
  %v5576 = load i64, ptr %slot869, align 8
  %op5577 = sub i64 %v5576, 32
  store i64 %op5577, ptr %slot875, align 8
  %v5578 = load i64, ptr %slot869, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %rgep5580 = getelementptr i8, ptr %p5579, i64 -32
  %ld5581 = load i64, ptr %rgep5580, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5581, ptr %slot876, align 8
  %v5582 = load i64, ptr %slot876, align 8
  %op5583 = sub i64 %v5582, 1
  store i64 %op5583, ptr %slot877, align 8
  %v5584 = load i64, ptr %slot877, align 8
  %cmp5585 = icmp eq i64 %v5584, 0
  %cv5586 = zext i1 %cmp5585 to i32
  store i32 %cv5586, ptr %slot878, align 8
  %v5587 = load i32, ptr %slot878, align 8
  %cv5588 = zext i32 %v5587 to i64
  %cond5589 = icmp ne i64 %cv5588, 0
  br i1 %cond5589, label %bb_rcglast1593, label %bb_rcgdec1593
bb_rcglast1593:
  %v5590 = load i64, ptr %slot869, align 8
  %op5591 = sub i64 %v5590, 24
  store i64 %op5591, ptr %slot879, align 8
  %v5592 = load i64, ptr %slot869, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  %rgep5594 = getelementptr i8, ptr %p5593, i64 -24
  %ld5595 = load i64, ptr %rgep5594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5595, ptr %slot880, align 8
  %v5596 = load i64, ptr %slot880, align 8
  %cmp5597 = icmp ne i64 %v5596, 0
  %cv5598 = zext i1 %cmp5597 to i32
  store i32 %cv5598, ptr %slot881, align 8
  %v5599 = load i32, ptr %slot881, align 8
  %cv5600 = zext i32 %v5599 to i64
  %cond5601 = icmp ne i64 %cv5600, 0
  br i1 %cond5601, label %bb_rcgdec1593, label %bb_rcgslow1593
bb_rcgslow1593:
  %v5602 = load i64, ptr %slot868, align 8
  %v5603 = load i64, ptr %slot867, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5602, i64 %v5603) nomerge, !dbg !172
  br label %bb_rcgdone1593
bb_rcgdec1593:
  %v5604 = load i64, ptr %slot877, align 8
  %v5605 = load i64, ptr %slot869, align 8
  %p5606 = inttoptr i64 %v5605 to ptr
  %rgep5607 = getelementptr i8, ptr %p5606, i64 -32
  store i64 %v5604, ptr %rgep5607, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1593
bb_rcgclear1593:
  %v5608 = load i64, ptr %slot867, align 8
  %p5609 = inttoptr i64 %v5608 to ptr
  store i64 0, ptr %p5609, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1593
bb_rcgdone1593:
  %v5610 = load i64, ptr %slot863, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  store i64 0, ptr %p5611, align 8, !alias.scope !3, !noalias !4
  %v5612 = load i64, ptr %slot863, align 8
  %p5614 = inttoptr i64 %v5612 to ptr
  %gep5615 = getelementptr i8, ptr %p5614, i64 8
  %op5613 = ptrtoint ptr %gep5615 to i64
  store i64 %op5613, ptr %slot882, align 8
  %v5616 = load i64, ptr %slot882, align 8
  %p5617 = inttoptr i64 %v5616 to ptr
  store i64 0, ptr %p5617, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1575
bb_rcslotdone1575:
  br label %bb_rcprivateprepared1540
bb_rcprivateprepared1540:
  %v5618 = load i64, ptr %slot16, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  %ld5620 = load i32, ptr %p5619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5620, ptr %slot883, align 8
  %v5621 = load i32, ptr %slot883, align 8
  %cv5622 = zext i32 %v5621 to i64
  %cond5623 = icmp ne i64 %cv5622, 0
  br i1 %cond5623, label %bb_rcslotdrop1601, label %bb_rcslotdone1601
bb_rcslotdrop1601:
  %v5624 = load i64, ptr %slot16, align 8
  %p5625 = inttoptr i64 %v5624 to ptr
  store i32 0, ptr %p5625, align 4, !alias.scope !3, !noalias !4
  %v5626 = load i64, ptr %slot45, align 8
  store i64 %v5626, ptr %slot884, align 8
  %v5627 = load i64, ptr %slot17, align 8
  %p5628 = inttoptr i64 %v5627 to ptr
  %ld5629 = load i32, ptr %p5628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5629, ptr %slot885, align 8
  %v5630 = load i32, ptr %slot885, align 8
  %op5631 = and i32 %v5630, 28
  store i32 %op5631, ptr %slot886, align 8
  %v5632 = load i32, ptr %slot886, align 8
  %cv5633 = zext i32 %v5632 to i64
  %cond5634 = icmp ne i64 %cv5633, 0
  br i1 %cond5634, label %bb_rcslotrole1601, label %bb_rcslotowner1601
bb_rcslotrole1601:
  %v5635 = load i64, ptr %slot73, align 8
  store i64 %v5635, ptr %slot887, align 8
  %v5636 = load i64, ptr %slot887, align 8
  %v5637 = load i64, ptr %slot884, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5636, i64 %v5637) nomerge, !dbg !172
  br label %bb_rcslotdone1601
bb_rcslotowner1601:
  %v5638 = load i64, ptr %slot884, align 8
  %p5640 = inttoptr i64 %v5638 to ptr
  %gep5641 = getelementptr i8, ptr %p5640, i64 0
  %op5639 = ptrtoint ptr %gep5641 to i64
  store i64 %op5639, ptr %slot888, align 8
  %v5642 = load i64, ptr %slot73, align 8
  store i64 %v5642, ptr %slot889, align 8
  %v5643 = load i64, ptr %slot888, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  %ld5645 = load i64, ptr %p5644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5645, ptr %slot890, align 8
  %v5646 = load i64, ptr %slot890, align 8
  %cmp5647 = icmp ne i64 %v5646, 0
  %cv5648 = zext i1 %cmp5647 to i32
  store i32 %cv5648, ptr %slot891, align 8
  %v5649 = load i32, ptr %slot891, align 8
  %cv5650 = zext i32 %v5649 to i64
  %cond5651 = icmp ne i64 %cv5650, 0
  br i1 %cond5651, label %bb_rcgnn1619, label %bb_rcgdone1619
bb_rcgnn1619:
  %v5652 = load i64, ptr %slot890, align 8
  %op5653 = sub i64 %v5652, 16
  store i64 %op5653, ptr %slot892, align 8
  %v5654 = load i64, ptr %slot890, align 8
  %p5655 = inttoptr i64 %v5654 to ptr
  %rgep5656 = getelementptr i8, ptr %p5655, i64 -16
  %ld5657 = load i64, ptr %rgep5656, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5657, ptr %slot893, align 8
  %v5658 = load i64, ptr %slot893, align 8
  %op5659 = and i64 %v5658, 4611686018427387906
  store i64 %op5659, ptr %slot894, align 8
  %v5660 = load i64, ptr %slot894, align 8
  %cmp5661 = icmp ne i64 %v5660, 0
  %cv5662 = zext i1 %cmp5661 to i32
  store i32 %cv5662, ptr %slot895, align 8
  %v5663 = load i32, ptr %slot895, align 8
  %cv5664 = zext i32 %v5663 to i64
  %cond5665 = icmp ne i64 %cv5664, 0
  br i1 %cond5665, label %bb_rcgclear1619, label %bb_rcgcounted1619
bb_rcgcounted1619:
  %v5666 = load i64, ptr %slot890, align 8
  %op5667 = sub i64 %v5666, 32
  store i64 %op5667, ptr %slot896, align 8
  %v5668 = load i64, ptr %slot890, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  %rgep5670 = getelementptr i8, ptr %p5669, i64 -32
  %ld5671 = load i64, ptr %rgep5670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5671, ptr %slot897, align 8
  %v5672 = load i64, ptr %slot897, align 8
  %op5673 = sub i64 %v5672, 1
  store i64 %op5673, ptr %slot898, align 8
  %v5674 = load i64, ptr %slot898, align 8
  %cmp5675 = icmp eq i64 %v5674, 0
  %cv5676 = zext i1 %cmp5675 to i32
  store i32 %cv5676, ptr %slot899, align 8
  %v5677 = load i32, ptr %slot899, align 8
  %cv5678 = zext i32 %v5677 to i64
  %cond5679 = icmp ne i64 %cv5678, 0
  br i1 %cond5679, label %bb_rcglast1619, label %bb_rcgdec1619
bb_rcglast1619:
  %v5680 = load i64, ptr %slot890, align 8
  %op5681 = sub i64 %v5680, 24
  store i64 %op5681, ptr %slot900, align 8
  %v5682 = load i64, ptr %slot890, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  %rgep5684 = getelementptr i8, ptr %p5683, i64 -24
  %ld5685 = load i64, ptr %rgep5684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5685, ptr %slot901, align 8
  %v5686 = load i64, ptr %slot901, align 8
  %cmp5687 = icmp ne i64 %v5686, 0
  %cv5688 = zext i1 %cmp5687 to i32
  store i32 %cv5688, ptr %slot902, align 8
  %v5689 = load i32, ptr %slot902, align 8
  %cv5690 = zext i32 %v5689 to i64
  %cond5691 = icmp ne i64 %cv5690, 0
  br i1 %cond5691, label %bb_rcgdec1619, label %bb_rcgslow1619
bb_rcgslow1619:
  %v5692 = load i64, ptr %slot889, align 8
  %v5693 = load i64, ptr %slot888, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5692, i64 %v5693) nomerge, !dbg !172
  br label %bb_rcgdone1619
bb_rcgdec1619:
  %v5694 = load i64, ptr %slot898, align 8
  %v5695 = load i64, ptr %slot890, align 8
  %p5696 = inttoptr i64 %v5695 to ptr
  %rgep5697 = getelementptr i8, ptr %p5696, i64 -32
  store i64 %v5694, ptr %rgep5697, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1619
bb_rcgclear1619:
  %v5698 = load i64, ptr %slot888, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  store i64 0, ptr %p5699, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1619
bb_rcgdone1619:
  %v5700 = load i64, ptr %slot884, align 8
  %p5701 = inttoptr i64 %v5700 to ptr
  store i64 0, ptr %p5701, align 8, !alias.scope !3, !noalias !4
  %v5702 = load i64, ptr %slot884, align 8
  %p5704 = inttoptr i64 %v5702 to ptr
  %gep5705 = getelementptr i8, ptr %p5704, i64 8
  %op5703 = ptrtoint ptr %gep5705 to i64
  store i64 %op5703, ptr %slot903, align 8
  %v5706 = load i64, ptr %slot903, align 8
  %p5707 = inttoptr i64 %v5706 to ptr
  store i64 0, ptr %p5707, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1601
bb_rcslotdone1601:
  %v5708 = load i64, ptr %slot45, align 8
  store i64 %v5708, ptr %slot904, align 8
  %v5709 = load i64, ptr %slot32, align 8
  store i64 %v5709, ptr %slot905, align 8
  %v5710 = load i64, ptr %slot905, align 8
  %v5711 = load i64, ptr %slot904, align 8
  %p5712 = inttoptr i64 %v5710 to ptr
  %p5713 = inttoptr i64 %v5711 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5713, ptr %p5712, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5714 = load i64, ptr %slot27, align 8
  %p5715 = inttoptr i64 %v5714 to ptr
  store i32 0, ptr %p5715, align 4, !alias.scope !3, !noalias !4
  %v5716 = load i64, ptr %slot17, align 8
  %p5717 = inttoptr i64 %v5716 to ptr
  store i32 2, ptr %p5717, align 4, !alias.scope !3, !noalias !4
  %v5718 = load i64, ptr %slot28, align 8
  %p5719 = inttoptr i64 %v5718 to ptr
  %ld5720 = load i32, ptr %p5719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5720, ptr %slot906, align 8
  %v5721 = load i32, ptr %slot906, align 8
  %v5722 = load i64, ptr %slot17, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  store i32 %v5721, ptr %p5723, align 4, !alias.scope !3, !noalias !4
  %v5724 = load i64, ptr %slot16, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  store i32 1, ptr %p5725, align 4, !alias.scope !3, !noalias !4
  %v5726 = load i64, ptr %slot43, align 8
  %v5727 = load i64, ptr %slot52, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  store i64 %v5726, ptr %p5728, align 8, !alias.scope !3, !noalias !4
  %v5729 = load i64, ptr %slot52, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  %ld5731 = load i64, ptr %p5730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5731, ptr %slot907, align 8
  %v5732 = load i64, ptr %slot24, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  %ld5734 = load i32, ptr %p5733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5734, ptr %slot908, align 8
  %v5735 = load i64, ptr %slot25, align 8
  %p5736 = inttoptr i64 %v5735 to ptr
  %ld5737 = load i32, ptr %p5736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5737, ptr %slot909, align 8
  %v5738 = load i32, ptr %slot909, align 8
  %op5739 = and i32 %v5738, 24
  store i32 %op5739, ptr %slot909, align 8
  %v5740 = load i32, ptr %slot909, align 8
  %cmp5741 = icmp eq i32 %v5740, 0
  %cv5742 = zext i1 %cmp5741 to i32
  store i32 %cv5742, ptr %slot910, align 8
  %v5743 = load i32, ptr %slot908, align 8
  %v5744 = load i32, ptr %slot910, align 8
  %op5745 = and i32 %v5743, %v5744
  store i32 %op5745, ptr %slot911, align 8
  %v5746 = load i32, ptr %slot911, align 8
  %cv5747 = zext i32 %v5746 to i64
  %cond5748 = icmp ne i64 %cv5747, 0
  br i1 %cond5748, label %bb_rcprivateown1638, label %bb_rcprivateloan1638
bb_rcprivateown1638:
  %v5749 = load i64, ptr %slot32, align 8
  store i64 %v5749, ptr %slot912, align 8
  %v5750 = load i64, ptr %slot74, align 8
  store i64 %v5750, ptr %slot913, align 8
  %v5751 = load i64, ptr %slot907, align 8
  %v5752 = load i64, ptr %slot912, align 8
  %op5753 = sub i64 %v5751, %v5752
  store i64 %op5753, ptr %slot914, align 8
  %v5754 = load i64, ptr %slot912, align 8
  %v5755 = load i64, ptr %slot907, align 8
  %op5756 = sub i64 %v5754, %v5755
  store i64 %op5756, ptr %slot915, align 8
  %v5757 = load i64, ptr %slot914, align 8
  %cmp5758 = icmp ult i64 %v5757, 24
  %cv5759 = zext i1 %cmp5758 to i32
  store i32 %cv5759, ptr %slot916, align 8
  %v5760 = load i64, ptr %slot915, align 8
  %cmp5761 = icmp ult i64 %v5760, 24
  %cv5762 = zext i1 %cmp5761 to i32
  store i32 %cv5762, ptr %slot917, align 8
  %v5763 = load i32, ptr %slot916, align 8
  %v5764 = load i32, ptr %slot917, align 8
  %op5765 = or i32 %v5763, %v5764
  store i32 %op5765, ptr %slot918, align 8
  %v5766 = load i32, ptr %slot918, align 8
  %cv5767 = zext i32 %v5766 to i64
  %cond5768 = icmp ne i64 %cv5767, 0
  br i1 %cond5768, label %bb_rcmoveslow1641, label %bb_rcmovecheck1641
bb_rcmovecheck1641:
  %v5769 = load i64, ptr %slot907, align 8
  %op5770 = add i64 %v5769, 8
  store i64 %op5770, ptr %slot919, align 8
  %v5771 = load i64, ptr %slot919, align 8
  %p5772 = inttoptr i64 %v5771 to ptr
  %ld5773 = load i64, ptr %p5772, align 8
  store i64 %ld5773, ptr %slot920, align 8
  %v5774 = load i64, ptr %slot920, align 8
  %cmp5775 = icmp ne i64 %v5774, 0
  %cv5776 = zext i1 %cmp5775 to i32
  store i32 %cv5776, ptr %slot921, align 8
  %v5777 = load i32, ptr %slot921, align 8
  %cv5778 = zext i32 %v5777 to i64
  %cond5779 = icmp ne i64 %cv5778, 0
  br i1 %cond5779, label %bb_rcmoveheader1649, label %bb_rcmovenext1649
bb_rcmoveheader1649:
  %v5780 = load i64, ptr %slot920, align 8
  %op5781 = sub i64 %v5780, 16
  store i64 %op5781, ptr %slot922, align 8
  %v5782 = load i64, ptr %slot920, align 8
  %p5783 = inttoptr i64 %v5782 to ptr
  %rgep5784 = getelementptr i8, ptr %p5783, i64 -16
  %ld5785 = load i64, ptr %rgep5784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5785, ptr %slot923, align 8
  %v5786 = load i64, ptr %slot923, align 8
  %op5787 = and i64 %v5786, 5764607523034234881
  store i64 %op5787, ptr %slot924, align 8
  %v5788 = load i64, ptr %slot924, align 8
  %cmp5789 = icmp ne i64 %v5788, 0
  %cv5790 = zext i1 %cmp5789 to i32
  store i32 %cv5790, ptr %slot925, align 8
  %v5791 = load i32, ptr %slot925, align 8
  %cv5792 = zext i32 %v5791 to i64
  %cond5793 = icmp ne i64 %cv5792, 0
  br i1 %cond5793, label %bb_rcmoveslow1641, label %bb_rcmovenext1649
bb_rcmovenext1649:
  %v5794 = load i64, ptr %slot907, align 8
  %v5795 = load i64, ptr %slot912, align 8
  %p5796 = inttoptr i64 %v5794 to ptr
  %p5797 = inttoptr i64 %v5795 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5797, ptr %p5796, i64 24, i1 false)
  %v5798 = load i64, ptr %slot907, align 8
  %p5799 = inttoptr i64 %v5798 to ptr
  store i64 0, ptr %p5799, align 8
  %v5800 = load i64, ptr %slot907, align 8
  %op5801 = add i64 %v5800, 8
  store i64 %op5801, ptr %slot926, align 8
  %v5802 = load i64, ptr %slot926, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  store i64 0, ptr %p5803, align 8
  %v5804 = load i64, ptr %slot907, align 8
  %op5805 = add i64 %v5804, 16
  store i64 %op5805, ptr %slot927, align 8
  %v5806 = load i64, ptr %slot927, align 8
  %p5807 = inttoptr i64 %v5806 to ptr
  store i64 0, ptr %p5807, align 8
  br label %bb_rcmoved1641
bb_rcmoveslow1641:
  %v5808 = load i64, ptr %slot73, align 8
  %v5809 = load i64, ptr %slot912, align 8
  %v5810 = load i64, ptr %slot907, align 8
  %v5811 = load i64, ptr %slot913, align 8
  %cv5812 = trunc i64 %v5811 to i32
  %call5813 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v5808, i64 %v5809, i64 %v5810, i32 %cv5812) nomerge, !dbg !174
  store i32 %call5813, ptr %slot928, align 8
  %v5814 = load i32, ptr %slot928, align 8
  %cv5815 = zext i32 %v5814 to i64
  %cond5816 = icmp ne i64 %cv5815, 0
  br i1 %cond5816, label %bb_rcsuccess1658, label %bb_rcfailure1658
bb_rcfailure1658:
  %v5817 = load i64, ptr %slot73, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  %call5819 = call i32 @myl_rc_take_failure(ptr %p5818) nomerge, !dbg !174
  store i32 %call5819, ptr %slot929, align 8
  %v5820 = load i64, ptr %slot1, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  %v5822 = load i32, ptr %slot929, align 8
  %call5823 = call i32 @myl_qbe_rc_status(ptr %p5821, i32 %v5822) nomerge, !dbg !174
  store i32 %call5823, ptr %slot930, align 8
  br label %bb_failure
bb_rcsuccess1658:
  br label %bb_rcmoved1641
bb_rcmoved1641:
  %v5824 = load i64, ptr %slot24, align 8
  %p5825 = inttoptr i64 %v5824 to ptr
  store i32 0, ptr %p5825, align 4, !alias.scope !3, !noalias !4
  %v5826 = load i64, ptr %slot28, align 8
  %p5827 = inttoptr i64 %v5826 to ptr
  store i32 2, ptr %p5827, align 4, !alias.scope !3, !noalias !4
  %v5828 = load i64, ptr %slot27, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  store i32 1, ptr %p5829, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1638
bb_rcprivateloan1638:
  %v5830 = load i64, ptr %slot32, align 8
  store i64 %v5830, ptr %slot931, align 8
  %v5831 = load i64, ptr %slot73, align 8
  %v5832 = load i64, ptr %slot931, align 8
  %v5833 = load i64, ptr %slot907, align 8
  %call5834 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64 %v5831, i64 %v5832, i64 %v5833) nomerge, !dbg !174
  store i32 %call5834, ptr %slot932, align 8
  %v5835 = load i32, ptr %slot932, align 8
  %cv5836 = zext i32 %v5835 to i64
  %cond5837 = icmp ne i64 %cv5836, 0
  br i1 %cond5837, label %bb_rcsuccess1666, label %bb_rcfailure1666
bb_rcfailure1666:
  %v5838 = load i64, ptr %slot73, align 8
  %p5839 = inttoptr i64 %v5838 to ptr
  %call5840 = call i32 @myl_rc_take_failure(ptr %p5839) nomerge, !dbg !174
  store i32 %call5840, ptr %slot933, align 8
  %v5841 = load i64, ptr %slot1, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  %v5843 = load i32, ptr %slot933, align 8
  %call5844 = call i32 @myl_qbe_rc_status(ptr %p5842, i32 %v5843) nomerge, !dbg !174
  store i32 %call5844, ptr %slot934, align 8
  br label %bb_failure
bb_rcsuccess1666:
  %v5845 = load i64, ptr %slot28, align 8
  %p5846 = inttoptr i64 %v5845 to ptr
  store i32 2, ptr %p5846, align 4, !alias.scope !3, !noalias !4
  %v5847 = load i64, ptr %slot28, align 8
  %p5848 = inttoptr i64 %v5847 to ptr
  store i32 16, ptr %p5848, align 4, !alias.scope !3, !noalias !4
  %v5849 = load i64, ptr %slot27, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  store i32 1, ptr %p5850, align 4, !alias.scope !3, !noalias !4
  %v5851 = load i64, ptr %slot24, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  %ld5853 = load i32, ptr %p5852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5853, ptr %slot935, align 8
  %v5854 = load i32, ptr %slot935, align 8
  %cv5855 = zext i32 %v5854 to i64
  %cond5856 = icmp ne i64 %cv5855, 0
  br i1 %cond5856, label %bb_rcslotdrop1674, label %bb_rcslotdone1674
bb_rcslotdrop1674:
  %v5857 = load i64, ptr %slot24, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  store i32 0, ptr %p5858, align 4, !alias.scope !3, !noalias !4
  %v5859 = load i64, ptr %slot30, align 8
  store i64 %v5859, ptr %slot936, align 8
  %v5860 = load i64, ptr %slot25, align 8
  %p5861 = inttoptr i64 %v5860 to ptr
  %ld5862 = load i32, ptr %p5861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5862, ptr %slot937, align 8
  %v5863 = load i32, ptr %slot937, align 8
  %op5864 = and i32 %v5863, 28
  store i32 %op5864, ptr %slot938, align 8
  %v5865 = load i32, ptr %slot938, align 8
  %cv5866 = zext i32 %v5865 to i64
  %cond5867 = icmp ne i64 %cv5866, 0
  br i1 %cond5867, label %bb_rcslotrole1674, label %bb_rcslotowner1674
bb_rcslotrole1674:
  %v5868 = load i64, ptr %slot73, align 8
  store i64 %v5868, ptr %slot939, align 8
  %v5869 = load i64, ptr %slot939, align 8
  %v5870 = load i64, ptr %slot936, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5869, i64 %v5870) nomerge, !dbg !174
  br label %bb_rcslotdone1674
bb_rcslotowner1674:
  %v5871 = load i64, ptr %slot936, align 8
  %p5873 = inttoptr i64 %v5871 to ptr
  %gep5874 = getelementptr i8, ptr %p5873, i64 8
  %op5872 = ptrtoint ptr %gep5874 to i64
  store i64 %op5872, ptr %slot940, align 8
  %v5875 = load i64, ptr %slot73, align 8
  store i64 %v5875, ptr %slot941, align 8
  %v5876 = load i64, ptr %slot940, align 8
  %p5877 = inttoptr i64 %v5876 to ptr
  %ld5878 = load i64, ptr %p5877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5878, ptr %slot942, align 8
  %v5879 = load i64, ptr %slot942, align 8
  %cmp5880 = icmp ne i64 %v5879, 0
  %cv5881 = zext i1 %cmp5880 to i32
  store i32 %cv5881, ptr %slot943, align 8
  %v5882 = load i32, ptr %slot943, align 8
  %cv5883 = zext i32 %v5882 to i64
  %cond5884 = icmp ne i64 %cv5883, 0
  br i1 %cond5884, label %bb_rcgnn1692, label %bb_rcgdone1692
bb_rcgnn1692:
  %v5885 = load i64, ptr %slot942, align 8
  %op5886 = sub i64 %v5885, 16
  store i64 %op5886, ptr %slot944, align 8
  %v5887 = load i64, ptr %slot942, align 8
  %p5888 = inttoptr i64 %v5887 to ptr
  %rgep5889 = getelementptr i8, ptr %p5888, i64 -16
  %ld5890 = load i64, ptr %rgep5889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5890, ptr %slot945, align 8
  %v5891 = load i64, ptr %slot945, align 8
  %op5892 = and i64 %v5891, 4611686018427387906
  store i64 %op5892, ptr %slot946, align 8
  %v5893 = load i64, ptr %slot946, align 8
  %cmp5894 = icmp ne i64 %v5893, 0
  %cv5895 = zext i1 %cmp5894 to i32
  store i32 %cv5895, ptr %slot947, align 8
  %v5896 = load i32, ptr %slot947, align 8
  %cv5897 = zext i32 %v5896 to i64
  %cond5898 = icmp ne i64 %cv5897, 0
  br i1 %cond5898, label %bb_rcgclear1692, label %bb_rcgcounted1692
bb_rcgcounted1692:
  %v5899 = load i64, ptr %slot942, align 8
  %op5900 = sub i64 %v5899, 32
  store i64 %op5900, ptr %slot948, align 8
  %v5901 = load i64, ptr %slot942, align 8
  %p5902 = inttoptr i64 %v5901 to ptr
  %rgep5903 = getelementptr i8, ptr %p5902, i64 -32
  %ld5904 = load i64, ptr %rgep5903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5904, ptr %slot949, align 8
  %v5905 = load i64, ptr %slot949, align 8
  %op5906 = sub i64 %v5905, 1
  store i64 %op5906, ptr %slot950, align 8
  %v5907 = load i64, ptr %slot950, align 8
  %cmp5908 = icmp eq i64 %v5907, 0
  %cv5909 = zext i1 %cmp5908 to i32
  store i32 %cv5909, ptr %slot951, align 8
  %v5910 = load i32, ptr %slot951, align 8
  %cv5911 = zext i32 %v5910 to i64
  %cond5912 = icmp ne i64 %cv5911, 0
  br i1 %cond5912, label %bb_rcglast1692, label %bb_rcgdec1692
bb_rcglast1692:
  %v5913 = load i64, ptr %slot942, align 8
  %op5914 = sub i64 %v5913, 24
  store i64 %op5914, ptr %slot952, align 8
  %v5915 = load i64, ptr %slot942, align 8
  %p5916 = inttoptr i64 %v5915 to ptr
  %rgep5917 = getelementptr i8, ptr %p5916, i64 -24
  %ld5918 = load i64, ptr %rgep5917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5918, ptr %slot953, align 8
  %v5919 = load i64, ptr %slot953, align 8
  %cmp5920 = icmp ne i64 %v5919, 0
  %cv5921 = zext i1 %cmp5920 to i32
  store i32 %cv5921, ptr %slot954, align 8
  %v5922 = load i32, ptr %slot954, align 8
  %cv5923 = zext i32 %v5922 to i64
  %cond5924 = icmp ne i64 %cv5923, 0
  br i1 %cond5924, label %bb_rcgdec1692, label %bb_rcgslow1692
bb_rcgslow1692:
  %v5925 = load i64, ptr %slot941, align 8
  %v5926 = load i64, ptr %slot940, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5925, i64 %v5926) nomerge, !dbg !174
  br label %bb_rcgdone1692
bb_rcgdec1692:
  %v5927 = load i64, ptr %slot950, align 8
  %v5928 = load i64, ptr %slot942, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  %rgep5930 = getelementptr i8, ptr %p5929, i64 -32
  store i64 %v5927, ptr %rgep5930, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1692
bb_rcgclear1692:
  %v5931 = load i64, ptr %slot940, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  store i64 0, ptr %p5932, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1692
bb_rcgdone1692:
  %v5933 = load i64, ptr %slot936, align 8
  %p5934 = inttoptr i64 %v5933 to ptr
  store i64 0, ptr %p5934, align 8, !alias.scope !3, !noalias !4
  %v5935 = load i64, ptr %slot936, align 8
  %p5937 = inttoptr i64 %v5935 to ptr
  %gep5938 = getelementptr i8, ptr %p5937, i64 8
  %op5936 = ptrtoint ptr %gep5938 to i64
  store i64 %op5936, ptr %slot955, align 8
  %v5939 = load i64, ptr %slot955, align 8
  %p5940 = inttoptr i64 %v5939 to ptr
  store i64 0, ptr %p5940, align 8, !alias.scope !3, !noalias !4
  %v5941 = load i64, ptr %slot936, align 8
  %p5943 = inttoptr i64 %v5941 to ptr
  %gep5944 = getelementptr i8, ptr %p5943, i64 16
  %op5942 = ptrtoint ptr %gep5944 to i64
  store i64 %op5942, ptr %slot956, align 8
  %v5945 = load i64, ptr %slot956, align 8
  %p5946 = inttoptr i64 %v5945 to ptr
  store i64 0, ptr %p5946, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1674
bb_rcslotdone1674:
  br label %bb_rcprivateprepared1638
bb_rcprivateprepared1638:
  %v5947 = load i64, ptr %slot14, align 8
  %p5948 = inttoptr i64 %v5947 to ptr
  %ld5949 = load i32, ptr %p5948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5949, ptr %slot957, align 8
  %v5950 = load i32, ptr %slot957, align 8
  %cv5951 = zext i32 %v5950 to i64
  %cond5952 = icmp ne i64 %cv5951, 0
  br i1 %cond5952, label %bb_rcslotdrop1701, label %bb_rcslotdone1701
bb_rcslotdrop1701:
  %v5953 = load i64, ptr %slot14, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  store i32 0, ptr %p5954, align 4, !alias.scope !3, !noalias !4
  %v5955 = load i64, ptr %slot44, align 8
  store i64 %v5955, ptr %slot958, align 8
  %v5956 = load i64, ptr %slot15, align 8
  %p5957 = inttoptr i64 %v5956 to ptr
  %ld5958 = load i32, ptr %p5957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5958, ptr %slot959, align 8
  %v5959 = load i32, ptr %slot959, align 8
  %op5960 = and i32 %v5959, 28
  store i32 %op5960, ptr %slot960, align 8
  %v5961 = load i32, ptr %slot960, align 8
  %cv5962 = zext i32 %v5961 to i64
  %cond5963 = icmp ne i64 %cv5962, 0
  br i1 %cond5963, label %bb_rcslotrole1701, label %bb_rcslotowner1701
bb_rcslotrole1701:
  %v5964 = load i64, ptr %slot73, align 8
  store i64 %v5964, ptr %slot961, align 8
  %v5965 = load i64, ptr %slot961, align 8
  %v5966 = load i64, ptr %slot958, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v5965, i64 %v5966) nomerge, !dbg !174
  br label %bb_rcslotdone1701
bb_rcslotowner1701:
  %v5967 = load i64, ptr %slot958, align 8
  %p5969 = inttoptr i64 %v5967 to ptr
  %gep5970 = getelementptr i8, ptr %p5969, i64 8
  %op5968 = ptrtoint ptr %gep5970 to i64
  store i64 %op5968, ptr %slot962, align 8
  %v5971 = load i64, ptr %slot73, align 8
  store i64 %v5971, ptr %slot963, align 8
  %v5972 = load i64, ptr %slot962, align 8
  %p5973 = inttoptr i64 %v5972 to ptr
  %ld5974 = load i64, ptr %p5973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5974, ptr %slot964, align 8
  %v5975 = load i64, ptr %slot964, align 8
  %cmp5976 = icmp ne i64 %v5975, 0
  %cv5977 = zext i1 %cmp5976 to i32
  store i32 %cv5977, ptr %slot965, align 8
  %v5978 = load i32, ptr %slot965, align 8
  %cv5979 = zext i32 %v5978 to i64
  %cond5980 = icmp ne i64 %cv5979, 0
  br i1 %cond5980, label %bb_rcgnn1719, label %bb_rcgdone1719
bb_rcgnn1719:
  %v5981 = load i64, ptr %slot964, align 8
  %op5982 = sub i64 %v5981, 16
  store i64 %op5982, ptr %slot966, align 8
  %v5983 = load i64, ptr %slot964, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %rgep5985 = getelementptr i8, ptr %p5984, i64 -16
  %ld5986 = load i64, ptr %rgep5985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5986, ptr %slot967, align 8
  %v5987 = load i64, ptr %slot967, align 8
  %op5988 = and i64 %v5987, 4611686018427387906
  store i64 %op5988, ptr %slot968, align 8
  %v5989 = load i64, ptr %slot968, align 8
  %cmp5990 = icmp ne i64 %v5989, 0
  %cv5991 = zext i1 %cmp5990 to i32
  store i32 %cv5991, ptr %slot969, align 8
  %v5992 = load i32, ptr %slot969, align 8
  %cv5993 = zext i32 %v5992 to i64
  %cond5994 = icmp ne i64 %cv5993, 0
  br i1 %cond5994, label %bb_rcgclear1719, label %bb_rcgcounted1719
bb_rcgcounted1719:
  %v5995 = load i64, ptr %slot964, align 8
  %op5996 = sub i64 %v5995, 32
  store i64 %op5996, ptr %slot970, align 8
  %v5997 = load i64, ptr %slot964, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %rgep5999 = getelementptr i8, ptr %p5998, i64 -32
  %ld6000 = load i64, ptr %rgep5999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6000, ptr %slot971, align 8
  %v6001 = load i64, ptr %slot971, align 8
  %op6002 = sub i64 %v6001, 1
  store i64 %op6002, ptr %slot972, align 8
  %v6003 = load i64, ptr %slot972, align 8
  %cmp6004 = icmp eq i64 %v6003, 0
  %cv6005 = zext i1 %cmp6004 to i32
  store i32 %cv6005, ptr %slot973, align 8
  %v6006 = load i32, ptr %slot973, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcglast1719, label %bb_rcgdec1719
bb_rcglast1719:
  %v6009 = load i64, ptr %slot964, align 8
  %op6010 = sub i64 %v6009, 24
  store i64 %op6010, ptr %slot974, align 8
  %v6011 = load i64, ptr %slot964, align 8
  %p6012 = inttoptr i64 %v6011 to ptr
  %rgep6013 = getelementptr i8, ptr %p6012, i64 -24
  %ld6014 = load i64, ptr %rgep6013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6014, ptr %slot975, align 8
  %v6015 = load i64, ptr %slot975, align 8
  %cmp6016 = icmp ne i64 %v6015, 0
  %cv6017 = zext i1 %cmp6016 to i32
  store i32 %cv6017, ptr %slot976, align 8
  %v6018 = load i32, ptr %slot976, align 8
  %cv6019 = zext i32 %v6018 to i64
  %cond6020 = icmp ne i64 %cv6019, 0
  br i1 %cond6020, label %bb_rcgdec1719, label %bb_rcgslow1719
bb_rcgslow1719:
  %v6021 = load i64, ptr %slot963, align 8
  %v6022 = load i64, ptr %slot962, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6021, i64 %v6022) nomerge, !dbg !174
  br label %bb_rcgdone1719
bb_rcgdec1719:
  %v6023 = load i64, ptr %slot972, align 8
  %v6024 = load i64, ptr %slot964, align 8
  %p6025 = inttoptr i64 %v6024 to ptr
  %rgep6026 = getelementptr i8, ptr %p6025, i64 -32
  store i64 %v6023, ptr %rgep6026, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1719
bb_rcgclear1719:
  %v6027 = load i64, ptr %slot962, align 8
  %p6028 = inttoptr i64 %v6027 to ptr
  store i64 0, ptr %p6028, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1719
bb_rcgdone1719:
  %v6029 = load i64, ptr %slot958, align 8
  %p6030 = inttoptr i64 %v6029 to ptr
  store i64 0, ptr %p6030, align 8, !alias.scope !3, !noalias !4
  %v6031 = load i64, ptr %slot958, align 8
  %p6033 = inttoptr i64 %v6031 to ptr
  %gep6034 = getelementptr i8, ptr %p6033, i64 8
  %op6032 = ptrtoint ptr %gep6034 to i64
  store i64 %op6032, ptr %slot977, align 8
  %v6035 = load i64, ptr %slot977, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  store i64 0, ptr %p6036, align 8, !alias.scope !3, !noalias !4
  %v6037 = load i64, ptr %slot958, align 8
  %p6039 = inttoptr i64 %v6037 to ptr
  %gep6040 = getelementptr i8, ptr %p6039, i64 16
  %op6038 = ptrtoint ptr %gep6040 to i64
  store i64 %op6038, ptr %slot978, align 8
  %v6041 = load i64, ptr %slot978, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  store i64 0, ptr %p6042, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1701
bb_rcslotdone1701:
  %v6043 = load i64, ptr %slot44, align 8
  store i64 %v6043, ptr %slot979, align 8
  %v6044 = load i64, ptr %slot32, align 8
  store i64 %v6044, ptr %slot980, align 8
  %v6045 = load i64, ptr %slot980, align 8
  %v6046 = load i64, ptr %slot979, align 8
  %p6047 = inttoptr i64 %v6045 to ptr
  %p6048 = inttoptr i64 %v6046 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6048, ptr %p6047, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6049 = load i64, ptr %slot27, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  store i32 0, ptr %p6050, align 4, !alias.scope !3, !noalias !4
  %v6051 = load i64, ptr %slot15, align 8
  %p6052 = inttoptr i64 %v6051 to ptr
  store i32 2, ptr %p6052, align 4, !alias.scope !3, !noalias !4
  %v6053 = load i64, ptr %slot28, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  %ld6055 = load i32, ptr %p6054, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6055, ptr %slot981, align 8
  %v6056 = load i32, ptr %slot981, align 8
  %v6057 = load i64, ptr %slot15, align 8
  %p6058 = inttoptr i64 %v6057 to ptr
  store i32 %v6056, ptr %p6058, align 4, !alias.scope !3, !noalias !4
  %v6059 = load i64, ptr %slot14, align 8
  %p6060 = inttoptr i64 %v6059 to ptr
  store i32 1, ptr %p6060, align 4, !alias.scope !3, !noalias !4
  %v6061 = load i64, ptr %slot43, align 8
  %v6062 = load i64, ptr %slot52, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  store i64 %v6061, ptr %p6063, align 8, !alias.scope !3, !noalias !4
  %v6064 = load i64, ptr %slot52, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  %ld6066 = load i64, ptr %p6065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6066, ptr %slot982, align 8
  %v6067 = load i64, ptr %slot24, align 8
  %p6068 = inttoptr i64 %v6067 to ptr
  %ld6069 = load i32, ptr %p6068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6069, ptr %slot983, align 8
  %v6070 = load i64, ptr %slot25, align 8
  %p6071 = inttoptr i64 %v6070 to ptr
  %ld6072 = load i32, ptr %p6071, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6072, ptr %slot984, align 8
  %v6073 = load i32, ptr %slot984, align 8
  %op6074 = and i32 %v6073, 24
  store i32 %op6074, ptr %slot984, align 8
  %v6075 = load i32, ptr %slot984, align 8
  %cmp6076 = icmp eq i32 %v6075, 0
  %cv6077 = zext i1 %cmp6076 to i32
  store i32 %cv6077, ptr %slot985, align 8
  %v6078 = load i32, ptr %slot983, align 8
  %v6079 = load i32, ptr %slot985, align 8
  %op6080 = and i32 %v6078, %v6079
  store i32 %op6080, ptr %slot986, align 8
  %v6081 = load i32, ptr %slot986, align 8
  %cv6082 = zext i32 %v6081 to i64
  %cond6083 = icmp ne i64 %cv6082, 0
  br i1 %cond6083, label %bb_rcprivateown1739, label %bb_rcprivateloan1739
bb_rcprivateown1739:
  %v6084 = load i64, ptr %slot32, align 8
  store i64 %v6084, ptr %slot987, align 8
  %v6085 = load i64, ptr %slot74, align 8
  store i64 %v6085, ptr %slot988, align 8
  %v6086 = load i64, ptr %slot982, align 8
  %v6087 = load i64, ptr %slot987, align 8
  %op6088 = sub i64 %v6086, %v6087
  store i64 %op6088, ptr %slot989, align 8
  %v6089 = load i64, ptr %slot987, align 8
  %v6090 = load i64, ptr %slot982, align 8
  %op6091 = sub i64 %v6089, %v6090
  store i64 %op6091, ptr %slot990, align 8
  %v6092 = load i64, ptr %slot989, align 8
  %cmp6093 = icmp ult i64 %v6092, 24
  %cv6094 = zext i1 %cmp6093 to i32
  store i32 %cv6094, ptr %slot991, align 8
  %v6095 = load i64, ptr %slot990, align 8
  %cmp6096 = icmp ult i64 %v6095, 24
  %cv6097 = zext i1 %cmp6096 to i32
  store i32 %cv6097, ptr %slot992, align 8
  %v6098 = load i32, ptr %slot991, align 8
  %v6099 = load i32, ptr %slot992, align 8
  %op6100 = or i32 %v6098, %v6099
  store i32 %op6100, ptr %slot993, align 8
  %v6101 = load i32, ptr %slot993, align 8
  %cv6102 = zext i32 %v6101 to i64
  %cond6103 = icmp ne i64 %cv6102, 0
  br i1 %cond6103, label %bb_rcmoveslow1742, label %bb_rcmovecheck1742
bb_rcmovecheck1742:
  %v6104 = load i64, ptr %slot982, align 8
  %op6105 = add i64 %v6104, 8
  store i64 %op6105, ptr %slot994, align 8
  %v6106 = load i64, ptr %slot994, align 8
  %p6107 = inttoptr i64 %v6106 to ptr
  %ld6108 = load i64, ptr %p6107, align 8
  store i64 %ld6108, ptr %slot995, align 8
  %v6109 = load i64, ptr %slot995, align 8
  %cmp6110 = icmp ne i64 %v6109, 0
  %cv6111 = zext i1 %cmp6110 to i32
  store i32 %cv6111, ptr %slot996, align 8
  %v6112 = load i32, ptr %slot996, align 8
  %cv6113 = zext i32 %v6112 to i64
  %cond6114 = icmp ne i64 %cv6113, 0
  br i1 %cond6114, label %bb_rcmoveheader1750, label %bb_rcmovenext1750
bb_rcmoveheader1750:
  %v6115 = load i64, ptr %slot995, align 8
  %op6116 = sub i64 %v6115, 16
  store i64 %op6116, ptr %slot997, align 8
  %v6117 = load i64, ptr %slot995, align 8
  %p6118 = inttoptr i64 %v6117 to ptr
  %rgep6119 = getelementptr i8, ptr %p6118, i64 -16
  %ld6120 = load i64, ptr %rgep6119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6120, ptr %slot998, align 8
  %v6121 = load i64, ptr %slot998, align 8
  %op6122 = and i64 %v6121, 5764607523034234881
  store i64 %op6122, ptr %slot999, align 8
  %v6123 = load i64, ptr %slot999, align 8
  %cmp6124 = icmp ne i64 %v6123, 0
  %cv6125 = zext i1 %cmp6124 to i32
  store i32 %cv6125, ptr %slot1000, align 8
  %v6126 = load i32, ptr %slot1000, align 8
  %cv6127 = zext i32 %v6126 to i64
  %cond6128 = icmp ne i64 %cv6127, 0
  br i1 %cond6128, label %bb_rcmoveslow1742, label %bb_rcmovenext1750
bb_rcmovenext1750:
  %v6129 = load i64, ptr %slot982, align 8
  %v6130 = load i64, ptr %slot987, align 8
  %p6131 = inttoptr i64 %v6129 to ptr
  %p6132 = inttoptr i64 %v6130 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6132, ptr %p6131, i64 24, i1 false)
  %v6133 = load i64, ptr %slot982, align 8
  %p6134 = inttoptr i64 %v6133 to ptr
  store i64 0, ptr %p6134, align 8
  %v6135 = load i64, ptr %slot982, align 8
  %op6136 = add i64 %v6135, 8
  store i64 %op6136, ptr %slot1001, align 8
  %v6137 = load i64, ptr %slot1001, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  store i64 0, ptr %p6138, align 8
  %v6139 = load i64, ptr %slot982, align 8
  %op6140 = add i64 %v6139, 16
  store i64 %op6140, ptr %slot1002, align 8
  %v6141 = load i64, ptr %slot1002, align 8
  %p6142 = inttoptr i64 %v6141 to ptr
  store i64 0, ptr %p6142, align 8
  br label %bb_rcmoved1742
bb_rcmoveslow1742:
  %v6143 = load i64, ptr %slot73, align 8
  %v6144 = load i64, ptr %slot987, align 8
  %v6145 = load i64, ptr %slot982, align 8
  %v6146 = load i64, ptr %slot988, align 8
  %cv6147 = trunc i64 %v6146 to i32
  %call6148 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v6143, i64 %v6144, i64 %v6145, i32 %cv6147) nomerge, !dbg !176
  store i32 %call6148, ptr %slot1003, align 8
  %v6149 = load i32, ptr %slot1003, align 8
  %cv6150 = zext i32 %v6149 to i64
  %cond6151 = icmp ne i64 %cv6150, 0
  br i1 %cond6151, label %bb_rcsuccess1759, label %bb_rcfailure1759
bb_rcfailure1759:
  %v6152 = load i64, ptr %slot73, align 8
  %p6153 = inttoptr i64 %v6152 to ptr
  %call6154 = call i32 @myl_rc_take_failure(ptr %p6153) nomerge, !dbg !176
  store i32 %call6154, ptr %slot1004, align 8
  %v6155 = load i64, ptr %slot1, align 8
  %p6156 = inttoptr i64 %v6155 to ptr
  %v6157 = load i32, ptr %slot1004, align 8
  %call6158 = call i32 @myl_qbe_rc_status(ptr %p6156, i32 %v6157) nomerge, !dbg !176
  store i32 %call6158, ptr %slot1005, align 8
  br label %bb_failure
bb_rcsuccess1759:
  br label %bb_rcmoved1742
bb_rcmoved1742:
  %v6159 = load i64, ptr %slot24, align 8
  %p6160 = inttoptr i64 %v6159 to ptr
  store i32 0, ptr %p6160, align 4, !alias.scope !3, !noalias !4
  %v6161 = load i64, ptr %slot28, align 8
  %p6162 = inttoptr i64 %v6161 to ptr
  store i32 2, ptr %p6162, align 4, !alias.scope !3, !noalias !4
  %v6163 = load i64, ptr %slot27, align 8
  %p6164 = inttoptr i64 %v6163 to ptr
  store i32 1, ptr %p6164, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1739
bb_rcprivateloan1739:
  %v6165 = load i64, ptr %slot32, align 8
  store i64 %v6165, ptr %slot1006, align 8
  %v6166 = load i64, ptr %slot73, align 8
  %v6167 = load i64, ptr %slot1006, align 8
  %v6168 = load i64, ptr %slot982, align 8
  %call6169 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64 %v6166, i64 %v6167, i64 %v6168) nomerge, !dbg !176
  store i32 %call6169, ptr %slot1007, align 8
  %v6170 = load i32, ptr %slot1007, align 8
  %cv6171 = zext i32 %v6170 to i64
  %cond6172 = icmp ne i64 %cv6171, 0
  br i1 %cond6172, label %bb_rcsuccess1767, label %bb_rcfailure1767
bb_rcfailure1767:
  %v6173 = load i64, ptr %slot73, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %call6175 = call i32 @myl_rc_take_failure(ptr %p6174) nomerge, !dbg !176
  store i32 %call6175, ptr %slot1008, align 8
  %v6176 = load i64, ptr %slot1, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  %v6178 = load i32, ptr %slot1008, align 8
  %call6179 = call i32 @myl_qbe_rc_status(ptr %p6177, i32 %v6178) nomerge, !dbg !176
  store i32 %call6179, ptr %slot1009, align 8
  br label %bb_failure
bb_rcsuccess1767:
  %v6180 = load i64, ptr %slot28, align 8
  %p6181 = inttoptr i64 %v6180 to ptr
  store i32 2, ptr %p6181, align 4, !alias.scope !3, !noalias !4
  %v6182 = load i64, ptr %slot28, align 8
  %p6183 = inttoptr i64 %v6182 to ptr
  store i32 16, ptr %p6183, align 4, !alias.scope !3, !noalias !4
  %v6184 = load i64, ptr %slot27, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  store i32 1, ptr %p6185, align 4, !alias.scope !3, !noalias !4
  %v6186 = load i64, ptr %slot24, align 8
  %p6187 = inttoptr i64 %v6186 to ptr
  %ld6188 = load i32, ptr %p6187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6188, ptr %slot1010, align 8
  %v6189 = load i32, ptr %slot1010, align 8
  %cv6190 = zext i32 %v6189 to i64
  %cond6191 = icmp ne i64 %cv6190, 0
  br i1 %cond6191, label %bb_rcslotdrop1775, label %bb_rcslotdone1775
bb_rcslotdrop1775:
  %v6192 = load i64, ptr %slot24, align 8
  %p6193 = inttoptr i64 %v6192 to ptr
  store i32 0, ptr %p6193, align 4, !alias.scope !3, !noalias !4
  %v6194 = load i64, ptr %slot30, align 8
  store i64 %v6194, ptr %slot1011, align 8
  %v6195 = load i64, ptr %slot25, align 8
  %p6196 = inttoptr i64 %v6195 to ptr
  %ld6197 = load i32, ptr %p6196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6197, ptr %slot1012, align 8
  %v6198 = load i32, ptr %slot1012, align 8
  %op6199 = and i32 %v6198, 28
  store i32 %op6199, ptr %slot1013, align 8
  %v6200 = load i32, ptr %slot1013, align 8
  %cv6201 = zext i32 %v6200 to i64
  %cond6202 = icmp ne i64 %cv6201, 0
  br i1 %cond6202, label %bb_rcslotrole1775, label %bb_rcslotowner1775
bb_rcslotrole1775:
  %v6203 = load i64, ptr %slot73, align 8
  store i64 %v6203, ptr %slot1014, align 8
  %v6204 = load i64, ptr %slot1014, align 8
  %v6205 = load i64, ptr %slot1011, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v6204, i64 %v6205) nomerge, !dbg !176
  br label %bb_rcslotdone1775
bb_rcslotowner1775:
  %v6206 = load i64, ptr %slot1011, align 8
  %p6208 = inttoptr i64 %v6206 to ptr
  %gep6209 = getelementptr i8, ptr %p6208, i64 8
  %op6207 = ptrtoint ptr %gep6209 to i64
  store i64 %op6207, ptr %slot1015, align 8
  %v6210 = load i64, ptr %slot73, align 8
  store i64 %v6210, ptr %slot1016, align 8
  %v6211 = load i64, ptr %slot1015, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %ld6213 = load i64, ptr %p6212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6213, ptr %slot1017, align 8
  %v6214 = load i64, ptr %slot1017, align 8
  %cmp6215 = icmp ne i64 %v6214, 0
  %cv6216 = zext i1 %cmp6215 to i32
  store i32 %cv6216, ptr %slot1018, align 8
  %v6217 = load i32, ptr %slot1018, align 8
  %cv6218 = zext i32 %v6217 to i64
  %cond6219 = icmp ne i64 %cv6218, 0
  br i1 %cond6219, label %bb_rcgnn1793, label %bb_rcgdone1793
bb_rcgnn1793:
  %v6220 = load i64, ptr %slot1017, align 8
  %op6221 = sub i64 %v6220, 16
  store i64 %op6221, ptr %slot1019, align 8
  %v6222 = load i64, ptr %slot1017, align 8
  %p6223 = inttoptr i64 %v6222 to ptr
  %rgep6224 = getelementptr i8, ptr %p6223, i64 -16
  %ld6225 = load i64, ptr %rgep6224, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6225, ptr %slot1020, align 8
  %v6226 = load i64, ptr %slot1020, align 8
  %op6227 = and i64 %v6226, 4611686018427387906
  store i64 %op6227, ptr %slot1021, align 8
  %v6228 = load i64, ptr %slot1021, align 8
  %cmp6229 = icmp ne i64 %v6228, 0
  %cv6230 = zext i1 %cmp6229 to i32
  store i32 %cv6230, ptr %slot1022, align 8
  %v6231 = load i32, ptr %slot1022, align 8
  %cv6232 = zext i32 %v6231 to i64
  %cond6233 = icmp ne i64 %cv6232, 0
  br i1 %cond6233, label %bb_rcgclear1793, label %bb_rcgcounted1793
bb_rcgcounted1793:
  %v6234 = load i64, ptr %slot1017, align 8
  %op6235 = sub i64 %v6234, 32
  store i64 %op6235, ptr %slot1023, align 8
  %v6236 = load i64, ptr %slot1017, align 8
  %p6237 = inttoptr i64 %v6236 to ptr
  %rgep6238 = getelementptr i8, ptr %p6237, i64 -32
  %ld6239 = load i64, ptr %rgep6238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6239, ptr %slot1024, align 8
  %v6240 = load i64, ptr %slot1024, align 8
  %op6241 = sub i64 %v6240, 1
  store i64 %op6241, ptr %slot1025, align 8
  %v6242 = load i64, ptr %slot1025, align 8
  %cmp6243 = icmp eq i64 %v6242, 0
  %cv6244 = zext i1 %cmp6243 to i32
  store i32 %cv6244, ptr %slot1026, align 8
  %v6245 = load i32, ptr %slot1026, align 8
  %cv6246 = zext i32 %v6245 to i64
  %cond6247 = icmp ne i64 %cv6246, 0
  br i1 %cond6247, label %bb_rcglast1793, label %bb_rcgdec1793
bb_rcglast1793:
  %v6248 = load i64, ptr %slot1017, align 8
  %op6249 = sub i64 %v6248, 24
  store i64 %op6249, ptr %slot1027, align 8
  %v6250 = load i64, ptr %slot1017, align 8
  %p6251 = inttoptr i64 %v6250 to ptr
  %rgep6252 = getelementptr i8, ptr %p6251, i64 -24
  %ld6253 = load i64, ptr %rgep6252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6253, ptr %slot1028, align 8
  %v6254 = load i64, ptr %slot1028, align 8
  %cmp6255 = icmp ne i64 %v6254, 0
  %cv6256 = zext i1 %cmp6255 to i32
  store i32 %cv6256, ptr %slot1029, align 8
  %v6257 = load i32, ptr %slot1029, align 8
  %cv6258 = zext i32 %v6257 to i64
  %cond6259 = icmp ne i64 %cv6258, 0
  br i1 %cond6259, label %bb_rcgdec1793, label %bb_rcgslow1793
bb_rcgslow1793:
  %v6260 = load i64, ptr %slot1016, align 8
  %v6261 = load i64, ptr %slot1015, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6260, i64 %v6261) nomerge, !dbg !176
  br label %bb_rcgdone1793
bb_rcgdec1793:
  %v6262 = load i64, ptr %slot1025, align 8
  %v6263 = load i64, ptr %slot1017, align 8
  %p6264 = inttoptr i64 %v6263 to ptr
  %rgep6265 = getelementptr i8, ptr %p6264, i64 -32
  store i64 %v6262, ptr %rgep6265, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1793
bb_rcgclear1793:
  %v6266 = load i64, ptr %slot1015, align 8
  %p6267 = inttoptr i64 %v6266 to ptr
  store i64 0, ptr %p6267, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1793
bb_rcgdone1793:
  %v6268 = load i64, ptr %slot1011, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  store i64 0, ptr %p6269, align 8, !alias.scope !3, !noalias !4
  %v6270 = load i64, ptr %slot1011, align 8
  %p6272 = inttoptr i64 %v6270 to ptr
  %gep6273 = getelementptr i8, ptr %p6272, i64 8
  %op6271 = ptrtoint ptr %gep6273 to i64
  store i64 %op6271, ptr %slot1030, align 8
  %v6274 = load i64, ptr %slot1030, align 8
  %p6275 = inttoptr i64 %v6274 to ptr
  store i64 0, ptr %p6275, align 8, !alias.scope !3, !noalias !4
  %v6276 = load i64, ptr %slot1011, align 8
  %p6278 = inttoptr i64 %v6276 to ptr
  %gep6279 = getelementptr i8, ptr %p6278, i64 16
  %op6277 = ptrtoint ptr %gep6279 to i64
  store i64 %op6277, ptr %slot1031, align 8
  %v6280 = load i64, ptr %slot1031, align 8
  %p6281 = inttoptr i64 %v6280 to ptr
  store i64 0, ptr %p6281, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1775
bb_rcslotdone1775:
  br label %bb_rcprivateprepared1739
bb_rcprivateprepared1739:
  %v6282 = load i64, ptr %slot14, align 8
  %p6283 = inttoptr i64 %v6282 to ptr
  %ld6284 = load i32, ptr %p6283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6284, ptr %slot1032, align 8
  %v6285 = load i32, ptr %slot1032, align 8
  %cv6286 = zext i32 %v6285 to i64
  %cond6287 = icmp ne i64 %cv6286, 0
  br i1 %cond6287, label %bb_rcslotdrop1802, label %bb_rcslotdone1802
bb_rcslotdrop1802:
  %v6288 = load i64, ptr %slot14, align 8
  %p6289 = inttoptr i64 %v6288 to ptr
  store i32 0, ptr %p6289, align 4, !alias.scope !3, !noalias !4
  %v6290 = load i64, ptr %slot44, align 8
  store i64 %v6290, ptr %slot1033, align 8
  %v6291 = load i64, ptr %slot15, align 8
  %p6292 = inttoptr i64 %v6291 to ptr
  %ld6293 = load i32, ptr %p6292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6293, ptr %slot1034, align 8
  %v6294 = load i32, ptr %slot1034, align 8
  %op6295 = and i32 %v6294, 28
  store i32 %op6295, ptr %slot1035, align 8
  %v6296 = load i32, ptr %slot1035, align 8
  %cv6297 = zext i32 %v6296 to i64
  %cond6298 = icmp ne i64 %cv6297, 0
  br i1 %cond6298, label %bb_rcslotrole1802, label %bb_rcslotowner1802
bb_rcslotrole1802:
  %v6299 = load i64, ptr %slot73, align 8
  store i64 %v6299, ptr %slot1036, align 8
  %v6300 = load i64, ptr %slot1036, align 8
  %v6301 = load i64, ptr %slot1033, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v6300, i64 %v6301) nomerge, !dbg !176
  br label %bb_rcslotdone1802
bb_rcslotowner1802:
  %v6302 = load i64, ptr %slot1033, align 8
  %p6304 = inttoptr i64 %v6302 to ptr
  %gep6305 = getelementptr i8, ptr %p6304, i64 8
  %op6303 = ptrtoint ptr %gep6305 to i64
  store i64 %op6303, ptr %slot1037, align 8
  %v6306 = load i64, ptr %slot73, align 8
  store i64 %v6306, ptr %slot1038, align 8
  %v6307 = load i64, ptr %slot1037, align 8
  %p6308 = inttoptr i64 %v6307 to ptr
  %ld6309 = load i64, ptr %p6308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6309, ptr %slot1039, align 8
  %v6310 = load i64, ptr %slot1039, align 8
  %cmp6311 = icmp ne i64 %v6310, 0
  %cv6312 = zext i1 %cmp6311 to i32
  store i32 %cv6312, ptr %slot1040, align 8
  %v6313 = load i32, ptr %slot1040, align 8
  %cv6314 = zext i32 %v6313 to i64
  %cond6315 = icmp ne i64 %cv6314, 0
  br i1 %cond6315, label %bb_rcgnn1820, label %bb_rcgdone1820
bb_rcgnn1820:
  %v6316 = load i64, ptr %slot1039, align 8
  %op6317 = sub i64 %v6316, 16
  store i64 %op6317, ptr %slot1041, align 8
  %v6318 = load i64, ptr %slot1039, align 8
  %p6319 = inttoptr i64 %v6318 to ptr
  %rgep6320 = getelementptr i8, ptr %p6319, i64 -16
  %ld6321 = load i64, ptr %rgep6320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6321, ptr %slot1042, align 8
  %v6322 = load i64, ptr %slot1042, align 8
  %op6323 = and i64 %v6322, 4611686018427387906
  store i64 %op6323, ptr %slot1043, align 8
  %v6324 = load i64, ptr %slot1043, align 8
  %cmp6325 = icmp ne i64 %v6324, 0
  %cv6326 = zext i1 %cmp6325 to i32
  store i32 %cv6326, ptr %slot1044, align 8
  %v6327 = load i32, ptr %slot1044, align 8
  %cv6328 = zext i32 %v6327 to i64
  %cond6329 = icmp ne i64 %cv6328, 0
  br i1 %cond6329, label %bb_rcgclear1820, label %bb_rcgcounted1820
bb_rcgcounted1820:
  %v6330 = load i64, ptr %slot1039, align 8
  %op6331 = sub i64 %v6330, 32
  store i64 %op6331, ptr %slot1045, align 8
  %v6332 = load i64, ptr %slot1039, align 8
  %p6333 = inttoptr i64 %v6332 to ptr
  %rgep6334 = getelementptr i8, ptr %p6333, i64 -32
  %ld6335 = load i64, ptr %rgep6334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6335, ptr %slot1046, align 8
  %v6336 = load i64, ptr %slot1046, align 8
  %op6337 = sub i64 %v6336, 1
  store i64 %op6337, ptr %slot1047, align 8
  %v6338 = load i64, ptr %slot1047, align 8
  %cmp6339 = icmp eq i64 %v6338, 0
  %cv6340 = zext i1 %cmp6339 to i32
  store i32 %cv6340, ptr %slot1048, align 8
  %v6341 = load i32, ptr %slot1048, align 8
  %cv6342 = zext i32 %v6341 to i64
  %cond6343 = icmp ne i64 %cv6342, 0
  br i1 %cond6343, label %bb_rcglast1820, label %bb_rcgdec1820
bb_rcglast1820:
  %v6344 = load i64, ptr %slot1039, align 8
  %op6345 = sub i64 %v6344, 24
  store i64 %op6345, ptr %slot1049, align 8
  %v6346 = load i64, ptr %slot1039, align 8
  %p6347 = inttoptr i64 %v6346 to ptr
  %rgep6348 = getelementptr i8, ptr %p6347, i64 -24
  %ld6349 = load i64, ptr %rgep6348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6349, ptr %slot1050, align 8
  %v6350 = load i64, ptr %slot1050, align 8
  %cmp6351 = icmp ne i64 %v6350, 0
  %cv6352 = zext i1 %cmp6351 to i32
  store i32 %cv6352, ptr %slot1051, align 8
  %v6353 = load i32, ptr %slot1051, align 8
  %cv6354 = zext i32 %v6353 to i64
  %cond6355 = icmp ne i64 %cv6354, 0
  br i1 %cond6355, label %bb_rcgdec1820, label %bb_rcgslow1820
bb_rcgslow1820:
  %v6356 = load i64, ptr %slot1038, align 8
  %v6357 = load i64, ptr %slot1037, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6356, i64 %v6357) nomerge, !dbg !176
  br label %bb_rcgdone1820
bb_rcgdec1820:
  %v6358 = load i64, ptr %slot1047, align 8
  %v6359 = load i64, ptr %slot1039, align 8
  %p6360 = inttoptr i64 %v6359 to ptr
  %rgep6361 = getelementptr i8, ptr %p6360, i64 -32
  store i64 %v6358, ptr %rgep6361, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1820
bb_rcgclear1820:
  %v6362 = load i64, ptr %slot1037, align 8
  %p6363 = inttoptr i64 %v6362 to ptr
  store i64 0, ptr %p6363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1820
bb_rcgdone1820:
  %v6364 = load i64, ptr %slot1033, align 8
  %p6365 = inttoptr i64 %v6364 to ptr
  store i64 0, ptr %p6365, align 8, !alias.scope !3, !noalias !4
  %v6366 = load i64, ptr %slot1033, align 8
  %p6368 = inttoptr i64 %v6366 to ptr
  %gep6369 = getelementptr i8, ptr %p6368, i64 8
  %op6367 = ptrtoint ptr %gep6369 to i64
  store i64 %op6367, ptr %slot1052, align 8
  %v6370 = load i64, ptr %slot1052, align 8
  %p6371 = inttoptr i64 %v6370 to ptr
  store i64 0, ptr %p6371, align 8, !alias.scope !3, !noalias !4
  %v6372 = load i64, ptr %slot1033, align 8
  %p6374 = inttoptr i64 %v6372 to ptr
  %gep6375 = getelementptr i8, ptr %p6374, i64 16
  %op6373 = ptrtoint ptr %gep6375 to i64
  store i64 %op6373, ptr %slot1053, align 8
  %v6376 = load i64, ptr %slot1053, align 8
  %p6377 = inttoptr i64 %v6376 to ptr
  store i64 0, ptr %p6377, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1802
bb_rcslotdone1802:
  %v6378 = load i64, ptr %slot44, align 8
  store i64 %v6378, ptr %slot1054, align 8
  %v6379 = load i64, ptr %slot32, align 8
  store i64 %v6379, ptr %slot1055, align 8
  %v6380 = load i64, ptr %slot1055, align 8
  %v6381 = load i64, ptr %slot1054, align 8
  %p6382 = inttoptr i64 %v6380 to ptr
  %p6383 = inttoptr i64 %v6381 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6383, ptr %p6382, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6384 = load i64, ptr %slot27, align 8
  %p6385 = inttoptr i64 %v6384 to ptr
  store i32 0, ptr %p6385, align 4, !alias.scope !3, !noalias !4
  %v6386 = load i64, ptr %slot15, align 8
  %p6387 = inttoptr i64 %v6386 to ptr
  store i32 2, ptr %p6387, align 4, !alias.scope !3, !noalias !4
  %v6388 = load i64, ptr %slot28, align 8
  %p6389 = inttoptr i64 %v6388 to ptr
  %ld6390 = load i32, ptr %p6389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6390, ptr %slot1056, align 8
  %v6391 = load i32, ptr %slot1056, align 8
  %v6392 = load i64, ptr %slot15, align 8
  %p6393 = inttoptr i64 %v6392 to ptr
  store i32 %v6391, ptr %p6393, align 4, !alias.scope !3, !noalias !4
  %v6394 = load i64, ptr %slot14, align 8
  %p6395 = inttoptr i64 %v6394 to ptr
  store i32 1, ptr %p6395, align 4, !alias.scope !3, !noalias !4
  %v6396 = load i64, ptr %slot44, align 8
  %v6397 = load i64, ptr %slot52, align 8
  %p6398 = inttoptr i64 %v6397 to ptr
  store i64 %v6396, ptr %p6398, align 8, !alias.scope !3, !noalias !4
  %v6399 = load i64, ptr %slot45, align 8
  %v6400 = load i64, ptr %slot60, align 8
  %p6401 = inttoptr i64 %v6399 to ptr
  %p6402 = inttoptr i64 %v6400 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6402, ptr %p6401, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6403 = load i64, ptr %slot60, align 8
  %v6404 = load i64, ptr %slot53, align 8
  %p6405 = inttoptr i64 %v6404 to ptr
  store i64 %v6403, ptr %p6405, align 8, !alias.scope !3, !noalias !4
  %v6406 = load i64, ptr %slot52, align 8
  %p6407 = inttoptr i64 %v6406 to ptr
  %ld6408 = load i64, ptr %p6407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6408, ptr %slot1057, align 8
  %v6409 = load i64, ptr %slot24, align 8
  %p6410 = inttoptr i64 %v6409 to ptr
  %ld6411 = load i32, ptr %p6410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6411, ptr %slot1058, align 8
  %v6412 = load i64, ptr %slot25, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  %ld6414 = load i32, ptr %p6413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6414, ptr %slot1059, align 8
  %v6415 = load i32, ptr %slot1059, align 8
  %op6416 = and i32 %v6415, 24
  store i32 %op6416, ptr %slot1059, align 8
  %v6417 = load i32, ptr %slot1059, align 8
  %cmp6418 = icmp eq i32 %v6417, 0
  %cv6419 = zext i1 %cmp6418 to i32
  store i32 %cv6419, ptr %slot1060, align 8
  %v6420 = load i32, ptr %slot1058, align 8
  %v6421 = load i32, ptr %slot1060, align 8
  %op6422 = and i32 %v6420, %v6421
  store i32 %op6422, ptr %slot1061, align 8
  %v6423 = load i32, ptr %slot1061, align 8
  %cv6424 = zext i32 %v6423 to i64
  %cond6425 = icmp ne i64 %cv6424, 0
  br i1 %cond6425, label %bb_rctake1834, label %bb_rccopy1834
bb_rctake1834:
  %v6426 = load i64, ptr %slot32, align 8
  store i64 %v6426, ptr %slot1062, align 8
  %v6427 = load i64, ptr %slot74, align 8
  store i64 %v6427, ptr %slot1063, align 8
  %v6428 = load i64, ptr %slot1057, align 8
  %v6429 = load i64, ptr %slot1062, align 8
  %op6430 = sub i64 %v6428, %v6429
  store i64 %op6430, ptr %slot1064, align 8
  %v6431 = load i64, ptr %slot1062, align 8
  %v6432 = load i64, ptr %slot1057, align 8
  %op6433 = sub i64 %v6431, %v6432
  store i64 %op6433, ptr %slot1065, align 8
  %v6434 = load i64, ptr %slot1064, align 8
  %cmp6435 = icmp ult i64 %v6434, 24
  %cv6436 = zext i1 %cmp6435 to i32
  store i32 %cv6436, ptr %slot1066, align 8
  %v6437 = load i64, ptr %slot1065, align 8
  %cmp6438 = icmp ult i64 %v6437, 24
  %cv6439 = zext i1 %cmp6438 to i32
  store i32 %cv6439, ptr %slot1067, align 8
  %v6440 = load i32, ptr %slot1066, align 8
  %v6441 = load i32, ptr %slot1067, align 8
  %op6442 = or i32 %v6440, %v6441
  store i32 %op6442, ptr %slot1068, align 8
  %v6443 = load i32, ptr %slot1068, align 8
  %cv6444 = zext i32 %v6443 to i64
  %cond6445 = icmp ne i64 %cv6444, 0
  br i1 %cond6445, label %bb_rcmoveslow1843, label %bb_rcmovecheck1843
bb_rcmovecheck1843:
  %v6446 = load i64, ptr %slot1057, align 8
  %op6447 = add i64 %v6446, 8
  store i64 %op6447, ptr %slot1069, align 8
  %v6448 = load i64, ptr %slot1069, align 8
  %p6449 = inttoptr i64 %v6448 to ptr
  %ld6450 = load i64, ptr %p6449, align 8
  store i64 %ld6450, ptr %slot1070, align 8
  %v6451 = load i64, ptr %slot1070, align 8
  %cmp6452 = icmp ne i64 %v6451, 0
  %cv6453 = zext i1 %cmp6452 to i32
  store i32 %cv6453, ptr %slot1071, align 8
  %v6454 = load i32, ptr %slot1071, align 8
  %cv6455 = zext i32 %v6454 to i64
  %cond6456 = icmp ne i64 %cv6455, 0
  br i1 %cond6456, label %bb_rcmoveheader1851, label %bb_rcmovenext1851
bb_rcmoveheader1851:
  %v6457 = load i64, ptr %slot1070, align 8
  %op6458 = sub i64 %v6457, 16
  store i64 %op6458, ptr %slot1072, align 8
  %v6459 = load i64, ptr %slot1070, align 8
  %p6460 = inttoptr i64 %v6459 to ptr
  %rgep6461 = getelementptr i8, ptr %p6460, i64 -16
  %ld6462 = load i64, ptr %rgep6461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6462, ptr %slot1073, align 8
  %v6463 = load i64, ptr %slot1073, align 8
  %op6464 = and i64 %v6463, 5764607523034234881
  store i64 %op6464, ptr %slot1074, align 8
  %v6465 = load i64, ptr %slot1074, align 8
  %cmp6466 = icmp ne i64 %v6465, 0
  %cv6467 = zext i1 %cmp6466 to i32
  store i32 %cv6467, ptr %slot1075, align 8
  %v6468 = load i32, ptr %slot1075, align 8
  %cv6469 = zext i32 %v6468 to i64
  %cond6470 = icmp ne i64 %cv6469, 0
  br i1 %cond6470, label %bb_rcmoveslow1843, label %bb_rcmovenext1851
bb_rcmovenext1851:
  %v6471 = load i64, ptr %slot1057, align 8
  %v6472 = load i64, ptr %slot1062, align 8
  %p6473 = inttoptr i64 %v6471 to ptr
  %p6474 = inttoptr i64 %v6472 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6474, ptr %p6473, i64 24, i1 false)
  %v6475 = load i64, ptr %slot1057, align 8
  %p6476 = inttoptr i64 %v6475 to ptr
  store i64 0, ptr %p6476, align 8
  %v6477 = load i64, ptr %slot1057, align 8
  %op6478 = add i64 %v6477, 8
  store i64 %op6478, ptr %slot1076, align 8
  %v6479 = load i64, ptr %slot1076, align 8
  %p6480 = inttoptr i64 %v6479 to ptr
  store i64 0, ptr %p6480, align 8
  %v6481 = load i64, ptr %slot1057, align 8
  %op6482 = add i64 %v6481, 16
  store i64 %op6482, ptr %slot1077, align 8
  %v6483 = load i64, ptr %slot1077, align 8
  %p6484 = inttoptr i64 %v6483 to ptr
  store i64 0, ptr %p6484, align 8
  br label %bb_rcmoved1843
bb_rcmoveslow1843:
  %v6485 = load i64, ptr %slot73, align 8
  %v6486 = load i64, ptr %slot1062, align 8
  %v6487 = load i64, ptr %slot1057, align 8
  %v6488 = load i64, ptr %slot1063, align 8
  %cv6489 = trunc i64 %v6488 to i32
  %call6490 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v6485, i64 %v6486, i64 %v6487, i32 %cv6489) nomerge, !dbg !178
  store i32 %call6490, ptr %slot1078, align 8
  %v6491 = load i32, ptr %slot1078, align 8
  %cv6492 = zext i32 %v6491 to i64
  %cond6493 = icmp ne i64 %cv6492, 0
  br i1 %cond6493, label %bb_rcsuccess1860, label %bb_rcfailure1860
bb_rcfailure1860:
  %v6494 = load i64, ptr %slot73, align 8
  %p6495 = inttoptr i64 %v6494 to ptr
  %call6496 = call i32 @myl_rc_take_failure(ptr %p6495) nomerge, !dbg !178
  store i32 %call6496, ptr %slot1079, align 8
  %v6497 = load i64, ptr %slot1, align 8
  %p6498 = inttoptr i64 %v6497 to ptr
  %v6499 = load i32, ptr %slot1079, align 8
  %call6500 = call i32 @myl_qbe_rc_status(ptr %p6498, i32 %v6499) nomerge, !dbg !178
  store i32 %call6500, ptr %slot1080, align 8
  br label %bb_failure
bb_rcsuccess1860:
  br label %bb_rcmoved1843
bb_rcmoved1843:
  %v6501 = load i64, ptr %slot24, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  store i32 0, ptr %p6502, align 4, !alias.scope !3, !noalias !4
  %v6503 = load i64, ptr %slot28, align 8
  %p6504 = inttoptr i64 %v6503 to ptr
  store i32 2, ptr %p6504, align 4, !alias.scope !3, !noalias !4
  %v6505 = load i64, ptr %slot27, align 8
  %p6506 = inttoptr i64 %v6505 to ptr
  store i32 1, ptr %p6506, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1834
bb_rccopy1834:
  %v6507 = load i64, ptr %slot32, align 8
  store i64 %v6507, ptr %slot1081, align 8
  %v6508 = load i64, ptr %slot74, align 8
  store i64 %v6508, ptr %slot1082, align 8
  %v6509 = load i64, ptr %slot73, align 8
  %v6510 = load i64, ptr %slot1081, align 8
  %v6511 = load i64, ptr %slot1057, align 8
  %v6512 = load i64, ptr %slot1082, align 8
  %cv6513 = trunc i64 %v6512 to i32
  %call6514 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v6509, i64 %v6510, i64 %v6511, i32 %cv6513) nomerge, !dbg !178
  store i32 %call6514, ptr %slot1083, align 8
  %v6515 = load i32, ptr %slot1083, align 8
  %cv6516 = zext i32 %v6515 to i64
  %cond6517 = icmp ne i64 %cv6516, 0
  br i1 %cond6517, label %bb_rcsuccess1869, label %bb_rcfailure1869
bb_rcfailure1869:
  %v6518 = load i64, ptr %slot73, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  %call6520 = call i32 @myl_rc_take_failure(ptr %p6519) nomerge, !dbg !178
  store i32 %call6520, ptr %slot1084, align 8
  %v6521 = load i64, ptr %slot1, align 8
  %p6522 = inttoptr i64 %v6521 to ptr
  %v6523 = load i32, ptr %slot1084, align 8
  %call6524 = call i32 @myl_qbe_rc_status(ptr %p6522, i32 %v6523) nomerge, !dbg !178
  store i32 %call6524, ptr %slot1085, align 8
  br label %bb_failure
bb_rcsuccess1869:
  %v6525 = load i64, ptr %slot28, align 8
  %p6526 = inttoptr i64 %v6525 to ptr
  store i32 2, ptr %p6526, align 4, !alias.scope !3, !noalias !4
  %v6527 = load i64, ptr %slot27, align 8
  %p6528 = inttoptr i64 %v6527 to ptr
  store i32 1, ptr %p6528, align 4, !alias.scope !3, !noalias !4
  %v6529 = load i64, ptr %slot24, align 8
  %p6530 = inttoptr i64 %v6529 to ptr
  %ld6531 = load i32, ptr %p6530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6531, ptr %slot1086, align 8
  %v6532 = load i32, ptr %slot1086, align 8
  %cv6533 = zext i32 %v6532 to i64
  %cond6534 = icmp ne i64 %cv6533, 0
  br i1 %cond6534, label %bb_rcslotdrop1876, label %bb_rcslotdone1876
bb_rcslotdrop1876:
  %v6535 = load i64, ptr %slot24, align 8
  %p6536 = inttoptr i64 %v6535 to ptr
  store i32 0, ptr %p6536, align 4, !alias.scope !3, !noalias !4
  %v6537 = load i64, ptr %slot30, align 8
  store i64 %v6537, ptr %slot1087, align 8
  %v6538 = load i64, ptr %slot25, align 8
  %p6539 = inttoptr i64 %v6538 to ptr
  %ld6540 = load i32, ptr %p6539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6540, ptr %slot1088, align 8
  %v6541 = load i32, ptr %slot1088, align 8
  %op6542 = and i32 %v6541, 28
  store i32 %op6542, ptr %slot1089, align 8
  %v6543 = load i32, ptr %slot1089, align 8
  %cv6544 = zext i32 %v6543 to i64
  %cond6545 = icmp ne i64 %cv6544, 0
  br i1 %cond6545, label %bb_rcslotrole1876, label %bb_rcslotowner1876
bb_rcslotrole1876:
  %v6546 = load i64, ptr %slot73, align 8
  store i64 %v6546, ptr %slot1090, align 8
  %v6547 = load i64, ptr %slot1090, align 8
  %v6548 = load i64, ptr %slot1087, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v6547, i64 %v6548) nomerge, !dbg !178
  br label %bb_rcslotdone1876
bb_rcslotowner1876:
  %v6549 = load i64, ptr %slot73, align 8
  store i64 %v6549, ptr %slot1091, align 8
  %v6550 = load i64, ptr %slot1091, align 8
  %v6551 = load i64, ptr %slot1087, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v6550, i64 %v6551) nomerge, !dbg !178
  br label %bb_rcslotdone1876
bb_rcslotdone1876:
  br label %bb_rcprepared1834
bb_rcprepared1834:
  %v6552 = load i64, ptr %slot32, align 8
  store i64 %v6552, ptr %slot1092, align 8
  %v6553 = load i64, ptr %slot61, align 8
  store i64 %v6553, ptr %slot1093, align 8
  %v6554 = load i64, ptr %slot1092, align 8
  %v6555 = load i64, ptr %slot1093, align 8
  %p6556 = inttoptr i64 %v6554 to ptr
  %p6557 = inttoptr i64 %v6555 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6557, ptr %p6556, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6558 = load i64, ptr %slot27, align 8
  %p6559 = inttoptr i64 %v6558 to ptr
  store i32 0, ptr %p6559, align 4, !alias.scope !3, !noalias !4
  %v6560 = load i64, ptr %slot29, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  store i32 1, ptr %p6561, align 4, !alias.scope !3, !noalias !4
  %v6562 = load i64, ptr %slot74, align 8
  store i64 %v6562, ptr %slot1094, align 8
  %v6563 = load i64, ptr %slot53, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  %ld6565 = load i64, ptr %p6564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6565, ptr %slot1095, align 8
  %v6566 = load i64, ptr %slot1093, align 8
  %p6568 = inttoptr i64 %v6566 to ptr
  %gep6569 = getelementptr i8, ptr %p6568, i64 8
  %op6567 = ptrtoint ptr %gep6569 to i64
  store i64 %op6567, ptr %slot1096, align 8
  %v6570 = load i64, ptr %slot32, align 8
  store i64 %v6570, ptr %slot1097, align 8
  %v6571 = load i64, ptr %slot53, align 8
  %p6572 = inttoptr i64 %v6571 to ptr
  %ld6573 = load i64, ptr %p6572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6573, ptr %slot1098, align 8
  store i32 0, ptr %slot1099, align 8
  %v6574 = load i64, ptr %slot26, align 8
  %p6575 = inttoptr i64 %v6574 to ptr
  %ld6576 = load i32, ptr %p6575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6576, ptr %slot1100, align 8
  %v6577 = load i32, ptr %slot1100, align 8
  %op6578 = and i32 %v6577, 24
  store i32 %op6578, ptr %slot1100, align 8
  %v6579 = load i32, ptr %slot1100, align 8
  %cmp6580 = icmp eq i32 %v6579, 0
  %cv6581 = zext i1 %cmp6580 to i32
  store i32 %cv6581, ptr %slot1101, align 8
  %v6582 = load i32, ptr %slot1099, align 8
  %v6583 = load i32, ptr %slot1101, align 8
  %op6584 = and i32 %v6582, %v6583
  store i32 %op6584, ptr %slot1102, align 8
  %v6585 = load i32, ptr %slot1102, align 8
  %cv6586 = zext i32 %v6585 to i64
  %cond6587 = icmp ne i64 %cv6586, 0
  br i1 %cond6587, label %bb_rctake1893, label %bb_rccopy1893
bb_rctake1893:
  %v6588 = load i64, ptr %slot32, align 8
  store i64 %v6588, ptr %slot1103, align 8
  %v6589 = load i64, ptr %slot74, align 8
  store i64 %v6589, ptr %slot1104, align 8
  %v6590 = load i64, ptr %slot1098, align 8
  %v6591 = load i64, ptr %slot1103, align 8
  %op6592 = sub i64 %v6590, %v6591
  store i64 %op6592, ptr %slot1105, align 8
  %v6593 = load i64, ptr %slot1103, align 8
  %v6594 = load i64, ptr %slot1098, align 8
  %op6595 = sub i64 %v6593, %v6594
  store i64 %op6595, ptr %slot1106, align 8
  %v6596 = load i64, ptr %slot1105, align 8
  %cmp6597 = icmp ult i64 %v6596, 16
  %cv6598 = zext i1 %cmp6597 to i32
  store i32 %cv6598, ptr %slot1107, align 8
  %v6599 = load i64, ptr %slot1106, align 8
  %cmp6600 = icmp ult i64 %v6599, 16
  %cv6601 = zext i1 %cmp6600 to i32
  store i32 %cv6601, ptr %slot1108, align 8
  %v6602 = load i32, ptr %slot1107, align 8
  %v6603 = load i32, ptr %slot1108, align 8
  %op6604 = or i32 %v6602, %v6603
  store i32 %op6604, ptr %slot1109, align 8
  %v6605 = load i32, ptr %slot1109, align 8
  %cv6606 = zext i32 %v6605 to i64
  %cond6607 = icmp ne i64 %cv6606, 0
  br i1 %cond6607, label %bb_rcmoveslow1902, label %bb_rcmovecheck1902
bb_rcmovecheck1902:
  %v6608 = load i64, ptr %slot1098, align 8
  %op6609 = add i64 %v6608, 0
  store i64 %op6609, ptr %slot1110, align 8
  %v6610 = load i64, ptr %slot1110, align 8
  %p6611 = inttoptr i64 %v6610 to ptr
  %ld6612 = load i64, ptr %p6611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6612, ptr %slot1111, align 8
  %v6613 = load i64, ptr %slot1111, align 8
  %cmp6614 = icmp ne i64 %v6613, 0
  %cv6615 = zext i1 %cmp6614 to i32
  store i32 %cv6615, ptr %slot1112, align 8
  %v6616 = load i32, ptr %slot1112, align 8
  %cv6617 = zext i32 %v6616 to i64
  %cond6618 = icmp ne i64 %cv6617, 0
  br i1 %cond6618, label %bb_rcmoveheader1910, label %bb_rcmovenext1910
bb_rcmoveheader1910:
  %v6619 = load i64, ptr %slot1111, align 8
  %op6620 = sub i64 %v6619, 16
  store i64 %op6620, ptr %slot1113, align 8
  %v6621 = load i64, ptr %slot1111, align 8
  %p6622 = inttoptr i64 %v6621 to ptr
  %rgep6623 = getelementptr i8, ptr %p6622, i64 -16
  %ld6624 = load i64, ptr %rgep6623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6624, ptr %slot1114, align 8
  %v6625 = load i64, ptr %slot1114, align 8
  %op6626 = and i64 %v6625, 5764607523034234881
  store i64 %op6626, ptr %slot1115, align 8
  %v6627 = load i64, ptr %slot1115, align 8
  %cmp6628 = icmp ne i64 %v6627, 0
  %cv6629 = zext i1 %cmp6628 to i32
  store i32 %cv6629, ptr %slot1116, align 8
  %v6630 = load i32, ptr %slot1116, align 8
  %cv6631 = zext i32 %v6630 to i64
  %cond6632 = icmp ne i64 %cv6631, 0
  br i1 %cond6632, label %bb_rcmoveslow1902, label %bb_rcmovenext1910
bb_rcmovenext1910:
  %v6633 = load i64, ptr %slot1098, align 8
  %v6634 = load i64, ptr %slot1103, align 8
  %p6635 = inttoptr i64 %v6633 to ptr
  %p6636 = inttoptr i64 %v6634 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6636, ptr %p6635, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6637 = load i64, ptr %slot1098, align 8
  %p6638 = inttoptr i64 %v6637 to ptr
  store i64 0, ptr %p6638, align 8, !alias.scope !3, !noalias !4
  %v6639 = load i64, ptr %slot1098, align 8
  %op6640 = add i64 %v6639, 8
  store i64 %op6640, ptr %slot1117, align 8
  %v6641 = load i64, ptr %slot1117, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  store i64 0, ptr %p6642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1902
bb_rcmoveslow1902:
  %v6643 = load i64, ptr %slot73, align 8
  %v6644 = load i64, ptr %slot1103, align 8
  %v6645 = load i64, ptr %slot1098, align 8
  %v6646 = load i64, ptr %slot1104, align 8
  %cv6647 = trunc i64 %v6646 to i32
  %call6648 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v6643, i64 %v6644, i64 %v6645, i32 %cv6647) nomerge, !dbg !178
  store i32 %call6648, ptr %slot1118, align 8
  %v6649 = load i32, ptr %slot1118, align 8
  %cv6650 = zext i32 %v6649 to i64
  %cond6651 = icmp ne i64 %cv6650, 0
  br i1 %cond6651, label %bb_rcsuccess1918, label %bb_rcfailure1918
bb_rcfailure1918:
  %v6652 = load i64, ptr %slot73, align 8
  %p6653 = inttoptr i64 %v6652 to ptr
  %call6654 = call i32 @myl_rc_take_failure(ptr %p6653) nomerge, !dbg !178
  store i32 %call6654, ptr %slot1119, align 8
  %v6655 = load i64, ptr %slot1, align 8
  %p6656 = inttoptr i64 %v6655 to ptr
  %v6657 = load i32, ptr %slot1119, align 8
  %call6658 = call i32 @myl_qbe_rc_status(ptr %p6656, i32 %v6657) nomerge, !dbg !178
  store i32 %call6658, ptr %slot1120, align 8
  br label %bb_failure
bb_rcsuccess1918:
  br label %bb_rcmoved1902
bb_rcmoved1902:
  %v6659 = load i64, ptr %slot28, align 8
  %p6660 = inttoptr i64 %v6659 to ptr
  store i32 2, ptr %p6660, align 4, !alias.scope !3, !noalias !4
  %v6661 = load i64, ptr %slot27, align 8
  %p6662 = inttoptr i64 %v6661 to ptr
  store i32 1, ptr %p6662, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1893
bb_rccopy1893:
  %v6663 = load i64, ptr %slot32, align 8
  store i64 %v6663, ptr %slot1121, align 8
  %v6664 = load i64, ptr %slot74, align 8
  store i64 %v6664, ptr %slot1122, align 8
  %v6665 = load i64, ptr %slot73, align 8
  %v6666 = load i64, ptr %slot1121, align 8
  %v6667 = load i64, ptr %slot1098, align 8
  %v6668 = load i64, ptr %slot1122, align 8
  %cv6669 = trunc i64 %v6668 to i32
  %call6670 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v6665, i64 %v6666, i64 %v6667, i32 %cv6669) nomerge, !dbg !178
  store i32 %call6670, ptr %slot1123, align 8
  %v6671 = load i32, ptr %slot1123, align 8
  %cv6672 = zext i32 %v6671 to i64
  %cond6673 = icmp ne i64 %cv6672, 0
  br i1 %cond6673, label %bb_rcsuccess1927, label %bb_rcfailure1927
bb_rcfailure1927:
  %v6674 = load i64, ptr %slot73, align 8
  %p6675 = inttoptr i64 %v6674 to ptr
  %call6676 = call i32 @myl_rc_take_failure(ptr %p6675) nomerge, !dbg !178
  store i32 %call6676, ptr %slot1124, align 8
  %v6677 = load i64, ptr %slot1, align 8
  %p6678 = inttoptr i64 %v6677 to ptr
  %v6679 = load i32, ptr %slot1124, align 8
  %call6680 = call i32 @myl_qbe_rc_status(ptr %p6678, i32 %v6679) nomerge, !dbg !178
  store i32 %call6680, ptr %slot1125, align 8
  br label %bb_failure
bb_rcsuccess1927:
  %v6681 = load i64, ptr %slot28, align 8
  %p6682 = inttoptr i64 %v6681 to ptr
  store i32 2, ptr %p6682, align 4, !alias.scope !3, !noalias !4
  %v6683 = load i64, ptr %slot27, align 8
  %p6684 = inttoptr i64 %v6683 to ptr
  store i32 1, ptr %p6684, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1893
bb_rcprepared1893:
  %v6685 = load i64, ptr %slot32, align 8
  store i64 %v6685, ptr %slot1126, align 8
  %v6686 = load i64, ptr %slot1126, align 8
  %v6687 = load i64, ptr %slot1097, align 8
  %p6688 = inttoptr i64 %v6686 to ptr
  %p6689 = inttoptr i64 %v6687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6689, ptr %p6688, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6690 = load i64, ptr %slot27, align 8
  %p6691 = inttoptr i64 %v6690 to ptr
  store i32 0, ptr %p6691, align 4, !alias.scope !3, !noalias !4
  %v6692 = load i64, ptr %slot28, align 8
  %p6693 = inttoptr i64 %v6692 to ptr
  store i32 2, ptr %p6693, align 4, !alias.scope !3, !noalias !4
  %v6694 = load i64, ptr %slot27, align 8
  %p6695 = inttoptr i64 %v6694 to ptr
  store i32 1, ptr %p6695, align 4, !alias.scope !3, !noalias !4
  %v6696 = load i64, ptr %slot73, align 8
  store i64 %v6696, ptr %slot1127, align 8
  %v6697 = load i64, ptr %slot1127, align 8
  %v6698 = load i64, ptr %slot1096, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v6697, i64 %v6698) nomerge, !dbg !178
  %v6699 = load i64, ptr %slot1097, align 8
  %v6700 = load i64, ptr %slot1096, align 8
  %p6701 = inttoptr i64 %v6699 to ptr
  %p6702 = inttoptr i64 %v6700 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6702, ptr %p6701, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6703 = load i64, ptr %slot27, align 8
  %p6704 = inttoptr i64 %v6703 to ptr
  store i32 0, ptr %p6704, align 4, !alias.scope !3, !noalias !4
  %v6705 = load i64, ptr %slot1093, align 8
  %v6706 = load i64, ptr %slot52, align 8
  %p6707 = inttoptr i64 %v6706 to ptr
  store i64 %v6705, ptr %p6707, align 8, !alias.scope !3, !noalias !4
  %v6708 = load i64, ptr %slot52, align 8
  %p6709 = inttoptr i64 %v6708 to ptr
  %ld6710 = load i64, ptr %p6709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6710, ptr %slot1128, align 8
  %v6711 = load i64, ptr %slot32, align 8
  store i64 %v6711, ptr %slot1129, align 8
  %v6712 = load i64, ptr %slot1128, align 8
  %v6713 = load i64, ptr %slot1129, align 8
  %p6714 = inttoptr i64 %v6712 to ptr
  %p6715 = inttoptr i64 %v6713 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6715, ptr %p6714, i64 24, i1 false)
  %v6716 = load i64, ptr %slot28, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  store i32 2, ptr %p6717, align 4, !alias.scope !3, !noalias !4
  %v6718 = load i64, ptr %slot27, align 8
  %p6719 = inttoptr i64 %v6718 to ptr
  store i32 1, ptr %p6719, align 4, !alias.scope !3, !noalias !4
  %v6720 = load i64, ptr %slot24, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  %ld6722 = load i32, ptr %p6721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6722, ptr %slot1130, align 8
  %v6723 = load i32, ptr %slot1130, align 8
  %cv6724 = zext i32 %v6723 to i64
  %cond6725 = icmp ne i64 %cv6724, 0
  br i1 %cond6725, label %bb_rcslotdrop1953, label %bb_rcslotdone1953
bb_rcslotdrop1953:
  %v6726 = load i64, ptr %slot24, align 8
  %p6727 = inttoptr i64 %v6726 to ptr
  store i32 0, ptr %p6727, align 4, !alias.scope !3, !noalias !4
  %v6728 = load i64, ptr %slot30, align 8
  store i64 %v6728, ptr %slot1131, align 8
  %v6729 = load i64, ptr %slot25, align 8
  %p6730 = inttoptr i64 %v6729 to ptr
  %ld6731 = load i32, ptr %p6730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6731, ptr %slot1132, align 8
  %v6732 = load i32, ptr %slot1132, align 8
  %op6733 = and i32 %v6732, 28
  store i32 %op6733, ptr %slot1133, align 8
  %v6734 = load i32, ptr %slot1133, align 8
  %cv6735 = zext i32 %v6734 to i64
  %cond6736 = icmp ne i64 %cv6735, 0
  br i1 %cond6736, label %bb_rcslotrole1953, label %bb_rcslotowner1953
bb_rcslotrole1953:
  %v6737 = load i64, ptr %slot73, align 8
  store i64 %v6737, ptr %slot1134, align 8
  %v6738 = load i64, ptr %slot1134, align 8
  %v6739 = load i64, ptr %slot1131, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v6738, i64 %v6739) nomerge, !dbg !178
  br label %bb_rcslotdone1953
bb_rcslotowner1953:
  %v6740 = load i64, ptr %slot73, align 8
  store i64 %v6740, ptr %slot1135, align 8
  %v6741 = load i64, ptr %slot1135, align 8
  %v6742 = load i64, ptr %slot1131, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v6741, i64 %v6742) nomerge, !dbg !178
  br label %bb_rcslotdone1953
bb_rcslotdone1953:
  %v6743 = load i64, ptr %slot30, align 8
  store i64 %v6743, ptr %slot1136, align 8
  %v6744 = load i64, ptr %slot32, align 8
  store i64 %v6744, ptr %slot1137, align 8
  %v6745 = load i64, ptr %slot1137, align 8
  %v6746 = load i64, ptr %slot1136, align 8
  %p6747 = inttoptr i64 %v6745 to ptr
  %p6748 = inttoptr i64 %v6746 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6748, ptr %p6747, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6749 = load i64, ptr %slot25, align 8
  %p6750 = inttoptr i64 %v6749 to ptr
  store i32 2, ptr %p6750, align 4, !alias.scope !3, !noalias !4
  %v6751 = load i64, ptr %slot28, align 8
  %p6752 = inttoptr i64 %v6751 to ptr
  %ld6753 = load i32, ptr %p6752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6753, ptr %slot1138, align 8
  %v6754 = load i32, ptr %slot1138, align 8
  %v6755 = load i64, ptr %slot25, align 8
  %p6756 = inttoptr i64 %v6755 to ptr
  store i32 %v6754, ptr %p6756, align 4, !alias.scope !3, !noalias !4
  %v6757 = load i64, ptr %slot27, align 8
  %p6758 = inttoptr i64 %v6757 to ptr
  store i32 0, ptr %p6758, align 4, !alias.scope !3, !noalias !4
  %v6759 = load i64, ptr %slot24, align 8
  %p6760 = inttoptr i64 %v6759 to ptr
  store i32 1, ptr %p6760, align 4, !alias.scope !3, !noalias !4
  %v6761 = load i64, ptr %slot1136, align 8
  %v6762 = load i64, ptr %slot52, align 8
  %p6763 = inttoptr i64 %v6762 to ptr
  store i64 %v6761, ptr %p6763, align 8, !alias.scope !3, !noalias !4
  %v6764 = load i64, ptr %slot52, align 8
  %p6765 = inttoptr i64 %v6764 to ptr
  %ld6766 = load i64, ptr %p6765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6766, ptr %slot1139, align 8
  %v6767 = load i64, ptr %slot24, align 8
  %p6768 = inttoptr i64 %v6767 to ptr
  %ld6769 = load i32, ptr %p6768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6769, ptr %slot1140, align 8
  %v6770 = load i64, ptr %slot25, align 8
  %p6771 = inttoptr i64 %v6770 to ptr
  %ld6772 = load i32, ptr %p6771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6772, ptr %slot1141, align 8
  %v6773 = load i32, ptr %slot1141, align 8
  %op6774 = and i32 %v6773, 24
  store i32 %op6774, ptr %slot1141, align 8
  %v6775 = load i32, ptr %slot1141, align 8
  %cmp6776 = icmp eq i32 %v6775, 0
  %cv6777 = zext i1 %cmp6776 to i32
  store i32 %cv6777, ptr %slot1142, align 8
  %v6778 = load i32, ptr %slot1140, align 8
  %v6779 = load i32, ptr %slot1142, align 8
  %op6780 = and i32 %v6778, %v6779
  store i32 %op6780, ptr %slot1143, align 8
  %v6781 = load i32, ptr %slot1143, align 8
  %cv6782 = zext i32 %v6781 to i64
  %cond6783 = icmp ne i64 %cv6782, 0
  br i1 %cond6783, label %bb_rctake1978, label %bb_rccopy1978
bb_rctake1978:
  %v6784 = load i64, ptr %slot32, align 8
  store i64 %v6784, ptr %slot1144, align 8
  %v6785 = load i64, ptr %slot74, align 8
  store i64 %v6785, ptr %slot1145, align 8
  %v6786 = load i64, ptr %slot1139, align 8
  %v6787 = load i64, ptr %slot1144, align 8
  %op6788 = sub i64 %v6786, %v6787
  store i64 %op6788, ptr %slot1146, align 8
  %v6789 = load i64, ptr %slot1144, align 8
  %v6790 = load i64, ptr %slot1139, align 8
  %op6791 = sub i64 %v6789, %v6790
  store i64 %op6791, ptr %slot1147, align 8
  %v6792 = load i64, ptr %slot1146, align 8
  %cmp6793 = icmp ult i64 %v6792, 24
  %cv6794 = zext i1 %cmp6793 to i32
  store i32 %cv6794, ptr %slot1148, align 8
  %v6795 = load i64, ptr %slot1147, align 8
  %cmp6796 = icmp ult i64 %v6795, 24
  %cv6797 = zext i1 %cmp6796 to i32
  store i32 %cv6797, ptr %slot1149, align 8
  %v6798 = load i32, ptr %slot1148, align 8
  %v6799 = load i32, ptr %slot1149, align 8
  %op6800 = or i32 %v6798, %v6799
  store i32 %op6800, ptr %slot1150, align 8
  %v6801 = load i32, ptr %slot1150, align 8
  %cv6802 = zext i32 %v6801 to i64
  %cond6803 = icmp ne i64 %cv6802, 0
  br i1 %cond6803, label %bb_rcmoveslow1987, label %bb_rcmovecheck1987
bb_rcmovecheck1987:
  %v6804 = load i64, ptr %slot1139, align 8
  %op6805 = add i64 %v6804, 8
  store i64 %op6805, ptr %slot1151, align 8
  %v6806 = load i64, ptr %slot1151, align 8
  %p6807 = inttoptr i64 %v6806 to ptr
  %ld6808 = load i64, ptr %p6807, align 8
  store i64 %ld6808, ptr %slot1152, align 8
  %v6809 = load i64, ptr %slot1152, align 8
  %cmp6810 = icmp ne i64 %v6809, 0
  %cv6811 = zext i1 %cmp6810 to i32
  store i32 %cv6811, ptr %slot1153, align 8
  %v6812 = load i32, ptr %slot1153, align 8
  %cv6813 = zext i32 %v6812 to i64
  %cond6814 = icmp ne i64 %cv6813, 0
  br i1 %cond6814, label %bb_rcmoveheader1995, label %bb_rcmovenext1995
bb_rcmoveheader1995:
  %v6815 = load i64, ptr %slot1152, align 8
  %op6816 = sub i64 %v6815, 16
  store i64 %op6816, ptr %slot1154, align 8
  %v6817 = load i64, ptr %slot1152, align 8
  %p6818 = inttoptr i64 %v6817 to ptr
  %rgep6819 = getelementptr i8, ptr %p6818, i64 -16
  %ld6820 = load i64, ptr %rgep6819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6820, ptr %slot1155, align 8
  %v6821 = load i64, ptr %slot1155, align 8
  %op6822 = and i64 %v6821, 5764607523034234881
  store i64 %op6822, ptr %slot1156, align 8
  %v6823 = load i64, ptr %slot1156, align 8
  %cmp6824 = icmp ne i64 %v6823, 0
  %cv6825 = zext i1 %cmp6824 to i32
  store i32 %cv6825, ptr %slot1157, align 8
  %v6826 = load i32, ptr %slot1157, align 8
  %cv6827 = zext i32 %v6826 to i64
  %cond6828 = icmp ne i64 %cv6827, 0
  br i1 %cond6828, label %bb_rcmoveslow1987, label %bb_rcmovenext1995
bb_rcmovenext1995:
  %v6829 = load i64, ptr %slot1139, align 8
  %v6830 = load i64, ptr %slot1144, align 8
  %p6831 = inttoptr i64 %v6829 to ptr
  %p6832 = inttoptr i64 %v6830 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6832, ptr %p6831, i64 24, i1 false)
  %v6833 = load i64, ptr %slot1139, align 8
  %p6834 = inttoptr i64 %v6833 to ptr
  store i64 0, ptr %p6834, align 8
  %v6835 = load i64, ptr %slot1139, align 8
  %op6836 = add i64 %v6835, 8
  store i64 %op6836, ptr %slot1158, align 8
  %v6837 = load i64, ptr %slot1158, align 8
  %p6838 = inttoptr i64 %v6837 to ptr
  store i64 0, ptr %p6838, align 8
  %v6839 = load i64, ptr %slot1139, align 8
  %op6840 = add i64 %v6839, 16
  store i64 %op6840, ptr %slot1159, align 8
  %v6841 = load i64, ptr %slot1159, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  store i64 0, ptr %p6842, align 8
  br label %bb_rcmoved1987
bb_rcmoveslow1987:
  %v6843 = load i64, ptr %slot73, align 8
  %v6844 = load i64, ptr %slot1144, align 8
  %v6845 = load i64, ptr %slot1139, align 8
  %v6846 = load i64, ptr %slot1145, align 8
  %cv6847 = trunc i64 %v6846 to i32
  %call6848 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v6843, i64 %v6844, i64 %v6845, i32 %cv6847) nomerge, !dbg !180
  store i32 %call6848, ptr %slot1160, align 8
  %v6849 = load i32, ptr %slot1160, align 8
  %cv6850 = zext i32 %v6849 to i64
  %cond6851 = icmp ne i64 %cv6850, 0
  br i1 %cond6851, label %bb_rcsuccess2004, label %bb_rcfailure2004
bb_rcfailure2004:
  %v6852 = load i64, ptr %slot73, align 8
  %p6853 = inttoptr i64 %v6852 to ptr
  %call6854 = call i32 @myl_rc_take_failure(ptr %p6853) nomerge, !dbg !180
  store i32 %call6854, ptr %slot1161, align 8
  %v6855 = load i64, ptr %slot1, align 8
  %p6856 = inttoptr i64 %v6855 to ptr
  %v6857 = load i32, ptr %slot1161, align 8
  %call6858 = call i32 @myl_qbe_rc_status(ptr %p6856, i32 %v6857) nomerge, !dbg !180
  store i32 %call6858, ptr %slot1162, align 8
  br label %bb_failure
bb_rcsuccess2004:
  br label %bb_rcmoved1987
bb_rcmoved1987:
  %v6859 = load i64, ptr %slot24, align 8
  %p6860 = inttoptr i64 %v6859 to ptr
  store i32 0, ptr %p6860, align 4, !alias.scope !3, !noalias !4
  %v6861 = load i64, ptr %slot28, align 8
  %p6862 = inttoptr i64 %v6861 to ptr
  store i32 2, ptr %p6862, align 4, !alias.scope !3, !noalias !4
  %v6863 = load i64, ptr %slot27, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  store i32 1, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1978
bb_rccopy1978:
  %v6865 = load i64, ptr %slot32, align 8
  store i64 %v6865, ptr %slot1163, align 8
  %v6866 = load i64, ptr %slot74, align 8
  store i64 %v6866, ptr %slot1164, align 8
  %v6867 = load i64, ptr %slot73, align 8
  %v6868 = load i64, ptr %slot1163, align 8
  %v6869 = load i64, ptr %slot1139, align 8
  %v6870 = load i64, ptr %slot1164, align 8
  %cv6871 = trunc i64 %v6870 to i32
  %call6872 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v6867, i64 %v6868, i64 %v6869, i32 %cv6871) nomerge, !dbg !180
  store i32 %call6872, ptr %slot1165, align 8
  %v6873 = load i32, ptr %slot1165, align 8
  %cv6874 = zext i32 %v6873 to i64
  %cond6875 = icmp ne i64 %cv6874, 0
  br i1 %cond6875, label %bb_rcsuccess2013, label %bb_rcfailure2013
bb_rcfailure2013:
  %v6876 = load i64, ptr %slot73, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  %call6878 = call i32 @myl_rc_take_failure(ptr %p6877) nomerge, !dbg !180
  store i32 %call6878, ptr %slot1166, align 8
  %v6879 = load i64, ptr %slot1, align 8
  %p6880 = inttoptr i64 %v6879 to ptr
  %v6881 = load i32, ptr %slot1166, align 8
  %call6882 = call i32 @myl_qbe_rc_status(ptr %p6880, i32 %v6881) nomerge, !dbg !180
  store i32 %call6882, ptr %slot1167, align 8
  br label %bb_failure
bb_rcsuccess2013:
  %v6883 = load i64, ptr %slot28, align 8
  %p6884 = inttoptr i64 %v6883 to ptr
  store i32 2, ptr %p6884, align 4, !alias.scope !3, !noalias !4
  %v6885 = load i64, ptr %slot27, align 8
  %p6886 = inttoptr i64 %v6885 to ptr
  store i32 1, ptr %p6886, align 4, !alias.scope !3, !noalias !4
  %v6887 = load i64, ptr %slot24, align 8
  %p6888 = inttoptr i64 %v6887 to ptr
  %ld6889 = load i32, ptr %p6888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6889, ptr %slot1168, align 8
  %v6890 = load i32, ptr %slot1168, align 8
  %cv6891 = zext i32 %v6890 to i64
  %cond6892 = icmp ne i64 %cv6891, 0
  br i1 %cond6892, label %bb_rcslotdrop2020, label %bb_rcslotdone2020
bb_rcslotdrop2020:
  %v6893 = load i64, ptr %slot24, align 8
  %p6894 = inttoptr i64 %v6893 to ptr
  store i32 0, ptr %p6894, align 4, !alias.scope !3, !noalias !4
  %v6895 = load i64, ptr %slot30, align 8
  store i64 %v6895, ptr %slot1169, align 8
  %v6896 = load i64, ptr %slot25, align 8
  %p6897 = inttoptr i64 %v6896 to ptr
  %ld6898 = load i32, ptr %p6897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6898, ptr %slot1170, align 8
  %v6899 = load i32, ptr %slot1170, align 8
  %op6900 = and i32 %v6899, 28
  store i32 %op6900, ptr %slot1171, align 8
  %v6901 = load i32, ptr %slot1171, align 8
  %cv6902 = zext i32 %v6901 to i64
  %cond6903 = icmp ne i64 %cv6902, 0
  br i1 %cond6903, label %bb_rcslotrole2020, label %bb_rcslotowner2020
bb_rcslotrole2020:
  %v6904 = load i64, ptr %slot73, align 8
  store i64 %v6904, ptr %slot1172, align 8
  %v6905 = load i64, ptr %slot1172, align 8
  %v6906 = load i64, ptr %slot1169, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v6905, i64 %v6906) nomerge, !dbg !180
  br label %bb_rcslotdone2020
bb_rcslotowner2020:
  %v6907 = load i64, ptr %slot1169, align 8
  %p6909 = inttoptr i64 %v6907 to ptr
  %gep6910 = getelementptr i8, ptr %p6909, i64 8
  %op6908 = ptrtoint ptr %gep6910 to i64
  store i64 %op6908, ptr %slot1173, align 8
  %v6911 = load i64, ptr %slot73, align 8
  store i64 %v6911, ptr %slot1174, align 8
  %v6912 = load i64, ptr %slot1173, align 8
  %p6913 = inttoptr i64 %v6912 to ptr
  %ld6914 = load i64, ptr %p6913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6914, ptr %slot1175, align 8
  %v6915 = load i64, ptr %slot1175, align 8
  %cmp6916 = icmp ne i64 %v6915, 0
  %cv6917 = zext i1 %cmp6916 to i32
  store i32 %cv6917, ptr %slot1176, align 8
  %v6918 = load i32, ptr %slot1176, align 8
  %cv6919 = zext i32 %v6918 to i64
  %cond6920 = icmp ne i64 %cv6919, 0
  br i1 %cond6920, label %bb_rcgnn2038, label %bb_rcgdone2038
bb_rcgnn2038:
  %v6921 = load i64, ptr %slot1175, align 8
  %op6922 = sub i64 %v6921, 16
  store i64 %op6922, ptr %slot1177, align 8
  %v6923 = load i64, ptr %slot1175, align 8
  %p6924 = inttoptr i64 %v6923 to ptr
  %rgep6925 = getelementptr i8, ptr %p6924, i64 -16
  %ld6926 = load i64, ptr %rgep6925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6926, ptr %slot1178, align 8
  %v6927 = load i64, ptr %slot1178, align 8
  %op6928 = and i64 %v6927, 4611686018427387906
  store i64 %op6928, ptr %slot1179, align 8
  %v6929 = load i64, ptr %slot1179, align 8
  %cmp6930 = icmp ne i64 %v6929, 0
  %cv6931 = zext i1 %cmp6930 to i32
  store i32 %cv6931, ptr %slot1180, align 8
  %v6932 = load i32, ptr %slot1180, align 8
  %cv6933 = zext i32 %v6932 to i64
  %cond6934 = icmp ne i64 %cv6933, 0
  br i1 %cond6934, label %bb_rcgclear2038, label %bb_rcgcounted2038
bb_rcgcounted2038:
  %v6935 = load i64, ptr %slot1175, align 8
  %op6936 = sub i64 %v6935, 32
  store i64 %op6936, ptr %slot1181, align 8
  %v6937 = load i64, ptr %slot1175, align 8
  %p6938 = inttoptr i64 %v6937 to ptr
  %rgep6939 = getelementptr i8, ptr %p6938, i64 -32
  %ld6940 = load i64, ptr %rgep6939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6940, ptr %slot1182, align 8
  %v6941 = load i64, ptr %slot1182, align 8
  %op6942 = sub i64 %v6941, 1
  store i64 %op6942, ptr %slot1183, align 8
  %v6943 = load i64, ptr %slot1183, align 8
  %cmp6944 = icmp eq i64 %v6943, 0
  %cv6945 = zext i1 %cmp6944 to i32
  store i32 %cv6945, ptr %slot1184, align 8
  %v6946 = load i32, ptr %slot1184, align 8
  %cv6947 = zext i32 %v6946 to i64
  %cond6948 = icmp ne i64 %cv6947, 0
  br i1 %cond6948, label %bb_rcglast2038, label %bb_rcgdec2038
bb_rcglast2038:
  %v6949 = load i64, ptr %slot1175, align 8
  %op6950 = sub i64 %v6949, 24
  store i64 %op6950, ptr %slot1185, align 8
  %v6951 = load i64, ptr %slot1175, align 8
  %p6952 = inttoptr i64 %v6951 to ptr
  %rgep6953 = getelementptr i8, ptr %p6952, i64 -24
  %ld6954 = load i64, ptr %rgep6953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6954, ptr %slot1186, align 8
  %v6955 = load i64, ptr %slot1186, align 8
  %cmp6956 = icmp ne i64 %v6955, 0
  %cv6957 = zext i1 %cmp6956 to i32
  store i32 %cv6957, ptr %slot1187, align 8
  %v6958 = load i32, ptr %slot1187, align 8
  %cv6959 = zext i32 %v6958 to i64
  %cond6960 = icmp ne i64 %cv6959, 0
  br i1 %cond6960, label %bb_rcgdec2038, label %bb_rcgslow2038
bb_rcgslow2038:
  %v6961 = load i64, ptr %slot1174, align 8
  %v6962 = load i64, ptr %slot1173, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6961, i64 %v6962) nomerge, !dbg !180
  br label %bb_rcgdone2038
bb_rcgdec2038:
  %v6963 = load i64, ptr %slot1183, align 8
  %v6964 = load i64, ptr %slot1175, align 8
  %p6965 = inttoptr i64 %v6964 to ptr
  %rgep6966 = getelementptr i8, ptr %p6965, i64 -32
  store i64 %v6963, ptr %rgep6966, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2038
bb_rcgclear2038:
  %v6967 = load i64, ptr %slot1173, align 8
  %p6968 = inttoptr i64 %v6967 to ptr
  store i64 0, ptr %p6968, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2038
bb_rcgdone2038:
  %v6969 = load i64, ptr %slot1169, align 8
  %p6970 = inttoptr i64 %v6969 to ptr
  store i64 0, ptr %p6970, align 8, !alias.scope !3, !noalias !4
  %v6971 = load i64, ptr %slot1169, align 8
  %p6973 = inttoptr i64 %v6971 to ptr
  %gep6974 = getelementptr i8, ptr %p6973, i64 8
  %op6972 = ptrtoint ptr %gep6974 to i64
  store i64 %op6972, ptr %slot1188, align 8
  %v6975 = load i64, ptr %slot1188, align 8
  %p6976 = inttoptr i64 %v6975 to ptr
  store i64 0, ptr %p6976, align 8, !alias.scope !3, !noalias !4
  %v6977 = load i64, ptr %slot1169, align 8
  %p6979 = inttoptr i64 %v6977 to ptr
  %gep6980 = getelementptr i8, ptr %p6979, i64 16
  %op6978 = ptrtoint ptr %gep6980 to i64
  store i64 %op6978, ptr %slot1189, align 8
  %v6981 = load i64, ptr %slot1189, align 8
  %p6982 = inttoptr i64 %v6981 to ptr
  store i64 0, ptr %p6982, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2020
bb_rcslotdone2020:
  br label %bb_rcprepared1978
bb_rcprepared1978:
  %v6983 = load i64, ptr %slot12, align 8
  %p6984 = inttoptr i64 %v6983 to ptr
  %ld6985 = load i32, ptr %p6984, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6985, ptr %slot1190, align 8
  %v6986 = load i32, ptr %slot1190, align 8
  %cv6987 = zext i32 %v6986 to i64
  %cond6988 = icmp ne i64 %cv6987, 0
  br i1 %cond6988, label %bb_rcslotdrop2047, label %bb_rcslotdone2047
bb_rcslotdrop2047:
  %v6989 = load i64, ptr %slot12, align 8
  %p6990 = inttoptr i64 %v6989 to ptr
  store i32 0, ptr %p6990, align 4, !alias.scope !3, !noalias !4
  %v6991 = load i64, ptr %slot43, align 8
  store i64 %v6991, ptr %slot1191, align 8
  %v6992 = load i64, ptr %slot13, align 8
  %p6993 = inttoptr i64 %v6992 to ptr
  %ld6994 = load i32, ptr %p6993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6994, ptr %slot1192, align 8
  %v6995 = load i32, ptr %slot1192, align 8
  %op6996 = and i32 %v6995, 28
  store i32 %op6996, ptr %slot1193, align 8
  %v6997 = load i32, ptr %slot1193, align 8
  %cv6998 = zext i32 %v6997 to i64
  %cond6999 = icmp ne i64 %cv6998, 0
  br i1 %cond6999, label %bb_rcslotrole2047, label %bb_rcslotowner2047
bb_rcslotrole2047:
  %v7000 = load i64, ptr %slot73, align 8
  store i64 %v7000, ptr %slot1194, align 8
  %v7001 = load i64, ptr %slot1194, align 8
  %v7002 = load i64, ptr %slot1191, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v7001, i64 %v7002) nomerge, !dbg !180
  br label %bb_rcslotdone2047
bb_rcslotowner2047:
  %v7003 = load i64, ptr %slot1191, align 8
  %p7005 = inttoptr i64 %v7003 to ptr
  %gep7006 = getelementptr i8, ptr %p7005, i64 8
  %op7004 = ptrtoint ptr %gep7006 to i64
  store i64 %op7004, ptr %slot1195, align 8
  %v7007 = load i64, ptr %slot73, align 8
  store i64 %v7007, ptr %slot1196, align 8
  %v7008 = load i64, ptr %slot1195, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  %ld7010 = load i64, ptr %p7009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7010, ptr %slot1197, align 8
  %v7011 = load i64, ptr %slot1197, align 8
  %cmp7012 = icmp ne i64 %v7011, 0
  %cv7013 = zext i1 %cmp7012 to i32
  store i32 %cv7013, ptr %slot1198, align 8
  %v7014 = load i32, ptr %slot1198, align 8
  %cv7015 = zext i32 %v7014 to i64
  %cond7016 = icmp ne i64 %cv7015, 0
  br i1 %cond7016, label %bb_rcgnn2065, label %bb_rcgdone2065
bb_rcgnn2065:
  %v7017 = load i64, ptr %slot1197, align 8
  %op7018 = sub i64 %v7017, 16
  store i64 %op7018, ptr %slot1199, align 8
  %v7019 = load i64, ptr %slot1197, align 8
  %p7020 = inttoptr i64 %v7019 to ptr
  %rgep7021 = getelementptr i8, ptr %p7020, i64 -16
  %ld7022 = load i64, ptr %rgep7021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7022, ptr %slot1200, align 8
  %v7023 = load i64, ptr %slot1200, align 8
  %op7024 = and i64 %v7023, 4611686018427387906
  store i64 %op7024, ptr %slot1201, align 8
  %v7025 = load i64, ptr %slot1201, align 8
  %cmp7026 = icmp ne i64 %v7025, 0
  %cv7027 = zext i1 %cmp7026 to i32
  store i32 %cv7027, ptr %slot1202, align 8
  %v7028 = load i32, ptr %slot1202, align 8
  %cv7029 = zext i32 %v7028 to i64
  %cond7030 = icmp ne i64 %cv7029, 0
  br i1 %cond7030, label %bb_rcgclear2065, label %bb_rcgcounted2065
bb_rcgcounted2065:
  %v7031 = load i64, ptr %slot1197, align 8
  %op7032 = sub i64 %v7031, 32
  store i64 %op7032, ptr %slot1203, align 8
  %v7033 = load i64, ptr %slot1197, align 8
  %p7034 = inttoptr i64 %v7033 to ptr
  %rgep7035 = getelementptr i8, ptr %p7034, i64 -32
  %ld7036 = load i64, ptr %rgep7035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7036, ptr %slot1204, align 8
  %v7037 = load i64, ptr %slot1204, align 8
  %op7038 = sub i64 %v7037, 1
  store i64 %op7038, ptr %slot1205, align 8
  %v7039 = load i64, ptr %slot1205, align 8
  %cmp7040 = icmp eq i64 %v7039, 0
  %cv7041 = zext i1 %cmp7040 to i32
  store i32 %cv7041, ptr %slot1206, align 8
  %v7042 = load i32, ptr %slot1206, align 8
  %cv7043 = zext i32 %v7042 to i64
  %cond7044 = icmp ne i64 %cv7043, 0
  br i1 %cond7044, label %bb_rcglast2065, label %bb_rcgdec2065
bb_rcglast2065:
  %v7045 = load i64, ptr %slot1197, align 8
  %op7046 = sub i64 %v7045, 24
  store i64 %op7046, ptr %slot1207, align 8
  %v7047 = load i64, ptr %slot1197, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  %rgep7049 = getelementptr i8, ptr %p7048, i64 -24
  %ld7050 = load i64, ptr %rgep7049, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7050, ptr %slot1208, align 8
  %v7051 = load i64, ptr %slot1208, align 8
  %cmp7052 = icmp ne i64 %v7051, 0
  %cv7053 = zext i1 %cmp7052 to i32
  store i32 %cv7053, ptr %slot1209, align 8
  %v7054 = load i32, ptr %slot1209, align 8
  %cv7055 = zext i32 %v7054 to i64
  %cond7056 = icmp ne i64 %cv7055, 0
  br i1 %cond7056, label %bb_rcgdec2065, label %bb_rcgslow2065
bb_rcgslow2065:
  %v7057 = load i64, ptr %slot1196, align 8
  %v7058 = load i64, ptr %slot1195, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v7057, i64 %v7058) nomerge, !dbg !180
  br label %bb_rcgdone2065
bb_rcgdec2065:
  %v7059 = load i64, ptr %slot1205, align 8
  %v7060 = load i64, ptr %slot1197, align 8
  %p7061 = inttoptr i64 %v7060 to ptr
  %rgep7062 = getelementptr i8, ptr %p7061, i64 -32
  store i64 %v7059, ptr %rgep7062, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2065
bb_rcgclear2065:
  %v7063 = load i64, ptr %slot1195, align 8
  %p7064 = inttoptr i64 %v7063 to ptr
  store i64 0, ptr %p7064, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2065
bb_rcgdone2065:
  %v7065 = load i64, ptr %slot1191, align 8
  %p7066 = inttoptr i64 %v7065 to ptr
  store i64 0, ptr %p7066, align 8, !alias.scope !3, !noalias !4
  %v7067 = load i64, ptr %slot1191, align 8
  %p7069 = inttoptr i64 %v7067 to ptr
  %gep7070 = getelementptr i8, ptr %p7069, i64 8
  %op7068 = ptrtoint ptr %gep7070 to i64
  store i64 %op7068, ptr %slot1210, align 8
  %v7071 = load i64, ptr %slot1210, align 8
  %p7072 = inttoptr i64 %v7071 to ptr
  store i64 0, ptr %p7072, align 8, !alias.scope !3, !noalias !4
  %v7073 = load i64, ptr %slot1191, align 8
  %p7075 = inttoptr i64 %v7073 to ptr
  %gep7076 = getelementptr i8, ptr %p7075, i64 16
  %op7074 = ptrtoint ptr %gep7076 to i64
  store i64 %op7074, ptr %slot1211, align 8
  %v7077 = load i64, ptr %slot1211, align 8
  %p7078 = inttoptr i64 %v7077 to ptr
  store i64 0, ptr %p7078, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2047
bb_rcslotdone2047:
  %v7079 = load i64, ptr %slot43, align 8
  store i64 %v7079, ptr %slot1212, align 8
  %v7080 = load i64, ptr %slot32, align 8
  store i64 %v7080, ptr %slot1213, align 8
  %v7081 = load i64, ptr %slot1213, align 8
  %v7082 = load i64, ptr %slot1212, align 8
  %p7083 = inttoptr i64 %v7081 to ptr
  %p7084 = inttoptr i64 %v7082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7084, ptr %p7083, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7085 = load i64, ptr %slot27, align 8
  %p7086 = inttoptr i64 %v7085 to ptr
  store i32 0, ptr %p7086, align 4, !alias.scope !3, !noalias !4
  %v7087 = load i64, ptr %slot13, align 8
  %p7088 = inttoptr i64 %v7087 to ptr
  store i32 2, ptr %p7088, align 4, !alias.scope !3, !noalias !4
  %v7089 = load i64, ptr %slot28, align 8
  %p7090 = inttoptr i64 %v7089 to ptr
  %ld7091 = load i32, ptr %p7090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7091, ptr %slot1214, align 8
  %v7092 = load i32, ptr %slot1214, align 8
  %v7093 = load i64, ptr %slot13, align 8
  %p7094 = inttoptr i64 %v7093 to ptr
  store i32 %v7092, ptr %p7094, align 4, !alias.scope !3, !noalias !4
  %v7095 = load i64, ptr %slot12, align 8
  %p7096 = inttoptr i64 %v7095 to ptr
  store i32 1, ptr %p7096, align 4, !alias.scope !3, !noalias !4
  %v7097 = load i64, ptr %slot52, align 8
  %p7098 = inttoptr i64 %v7097 to ptr
  store i64 0, ptr %p7098, align 8, !alias.scope !3, !noalias !4
  %v7099 = load i64, ptr %slot43, align 8
  %v7100 = load i64, ptr %slot62, align 8
  %p7101 = inttoptr i64 %v7099 to ptr
  %p7102 = inttoptr i64 %v7100 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7102, ptr %p7101, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7103 = load i64, ptr %slot62, align 8
  %v7104 = load i64, ptr %slot52, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  store i64 %v7103, ptr %p7105, align 8, !alias.scope !3, !noalias !4
  %v7106 = load i64, ptr %slot63, align 8
  store i64 %v7106, ptr %slot1215, align 8
  %v7107 = load i64, ptr %slot1215, align 8
  %p7108 = inttoptr i64 %v7107 to ptr
  store i64 0, ptr %p7108, align 8, !alias.scope !3, !noalias !4
  %v7109 = load i64, ptr %slot1215, align 8
  %p7111 = inttoptr i64 %v7109 to ptr
  %gep7112 = getelementptr i8, ptr %p7111, i64 8
  %op7110 = ptrtoint ptr %gep7112 to i64
  store i64 %op7110, ptr %slot1216, align 8
  %v7113 = load i64, ptr %slot1216, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  store i64 0, ptr %p7114, align 8, !alias.scope !3, !noalias !4
  %v7115 = load i64, ptr %slot1215, align 8
  %p7117 = inttoptr i64 %v7115 to ptr
  %gep7118 = getelementptr i8, ptr %p7117, i64 16
  %op7116 = ptrtoint ptr %gep7118 to i64
  store i64 %op7116, ptr %slot1217, align 8
  %v7119 = load i64, ptr %slot1217, align 8
  %p7120 = inttoptr i64 %v7119 to ptr
  store i64 0, ptr %p7120, align 8, !alias.scope !3, !noalias !4
  %v7121 = load i64, ptr %slot1215, align 8
  %p7123 = inttoptr i64 %v7121 to ptr
  %gep7124 = getelementptr i8, ptr %p7123, i64 24
  %op7122 = ptrtoint ptr %gep7124 to i64
  store i64 %op7122, ptr %slot1218, align 8
  %v7125 = load i64, ptr %slot1218, align 8
  %p7126 = inttoptr i64 %v7125 to ptr
  store i64 0, ptr %p7126, align 8, !alias.scope !3, !noalias !4
  %v7127 = load i64, ptr %slot1215, align 8
  %p7129 = inttoptr i64 %v7127 to ptr
  %gep7130 = getelementptr i8, ptr %p7129, i64 32
  %op7128 = ptrtoint ptr %gep7130 to i64
  store i64 %op7128, ptr %slot1219, align 8
  %v7131 = load i64, ptr %slot1219, align 8
  %p7132 = inttoptr i64 %v7131 to ptr
  store i64 0, ptr %p7132, align 8, !alias.scope !3, !noalias !4
  %v7133 = load i64, ptr %slot1215, align 8
  %p7135 = inttoptr i64 %v7133 to ptr
  %gep7136 = getelementptr i8, ptr %p7135, i64 40
  %op7134 = ptrtoint ptr %gep7136 to i64
  store i64 %op7134, ptr %slot1220, align 8
  %v7137 = load i64, ptr %slot1220, align 8
  %p7138 = inttoptr i64 %v7137 to ptr
  store i64 0, ptr %p7138, align 8, !alias.scope !3, !noalias !4
  %v7139 = load i64, ptr %slot1215, align 8
  %p7141 = inttoptr i64 %v7139 to ptr
  %gep7142 = getelementptr i8, ptr %p7141, i64 48
  %op7140 = ptrtoint ptr %gep7142 to i64
  store i64 %op7140, ptr %slot1221, align 8
  %v7143 = load i64, ptr %slot1221, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  store i64 0, ptr %p7144, align 8, !alias.scope !3, !noalias !4
  %v7145 = load i64, ptr %slot1215, align 8
  %p7146 = inttoptr i64 %v7145 to ptr
  store i32 7, ptr %p7146, align 4, !alias.scope !3, !noalias !4
  %v7147 = load i64, ptr %slot29, align 8
  %p7148 = inttoptr i64 %v7147 to ptr
  store i32 1, ptr %p7148, align 4, !alias.scope !3, !noalias !4
  %v7149 = load i64, ptr %slot52, align 8
  %p7150 = inttoptr i64 %v7149 to ptr
  %ld7151 = load i64, ptr %p7150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7151, ptr %slot1222, align 8
  %v7152 = load i64, ptr %slot1215, align 8
  %p7154 = inttoptr i64 %v7152 to ptr
  %gep7155 = getelementptr i8, ptr %p7154, i64 8
  %op7153 = ptrtoint ptr %gep7155 to i64
  store i64 %op7153, ptr %slot1223, align 8
  %v7156 = load i64, ptr %slot74, align 8
  store i64 %v7156, ptr %slot1224, align 8
  %v7157 = load i64, ptr %slot52, align 8
  %p7158 = inttoptr i64 %v7157 to ptr
  %ld7159 = load i64, ptr %p7158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7159, ptr %slot1225, align 8
  %v7160 = load i64, ptr %slot24, align 8
  %p7161 = inttoptr i64 %v7160 to ptr
  %ld7162 = load i32, ptr %p7161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7162, ptr %slot1226, align 8
  %v7163 = load i64, ptr %slot25, align 8
  %p7164 = inttoptr i64 %v7163 to ptr
  %ld7165 = load i32, ptr %p7164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7165, ptr %slot1227, align 8
  %v7166 = load i32, ptr %slot1227, align 8
  %op7167 = and i32 %v7166, 24
  store i32 %op7167, ptr %slot1227, align 8
  %v7168 = load i32, ptr %slot1227, align 8
  %cmp7169 = icmp eq i32 %v7168, 0
  %cv7170 = zext i1 %cmp7169 to i32
  store i32 %cv7170, ptr %slot1228, align 8
  %v7171 = load i32, ptr %slot1226, align 8
  %v7172 = load i32, ptr %slot1228, align 8
  %op7173 = and i32 %v7171, %v7172
  store i32 %op7173, ptr %slot1229, align 8
  %v7174 = load i32, ptr %slot1229, align 8
  %cv7175 = zext i32 %v7174 to i64
  %cond7176 = icmp ne i64 %cv7175, 0
  br i1 %cond7176, label %bb_rctake2091, label %bb_rccopy2091
bb_rctake2091:
  %v7177 = load i64, ptr %slot32, align 8
  store i64 %v7177, ptr %slot1230, align 8
  %v7178 = load i64, ptr %slot74, align 8
  store i64 %v7178, ptr %slot1231, align 8
  %v7179 = load i64, ptr %slot1225, align 8
  %v7180 = load i64, ptr %slot1230, align 8
  %op7181 = sub i64 %v7179, %v7180
  store i64 %op7181, ptr %slot1232, align 8
  %v7182 = load i64, ptr %slot1230, align 8
  %v7183 = load i64, ptr %slot1225, align 8
  %op7184 = sub i64 %v7182, %v7183
  store i64 %op7184, ptr %slot1233, align 8
  %v7185 = load i64, ptr %slot1232, align 8
  %cmp7186 = icmp ult i64 %v7185, 24
  %cv7187 = zext i1 %cmp7186 to i32
  store i32 %cv7187, ptr %slot1234, align 8
  %v7188 = load i64, ptr %slot1233, align 8
  %cmp7189 = icmp ult i64 %v7188, 24
  %cv7190 = zext i1 %cmp7189 to i32
  store i32 %cv7190, ptr %slot1235, align 8
  %v7191 = load i32, ptr %slot1234, align 8
  %v7192 = load i32, ptr %slot1235, align 8
  %op7193 = or i32 %v7191, %v7192
  store i32 %op7193, ptr %slot1236, align 8
  %v7194 = load i32, ptr %slot1236, align 8
  %cv7195 = zext i32 %v7194 to i64
  %cond7196 = icmp ne i64 %cv7195, 0
  br i1 %cond7196, label %bb_rcmoveslow2100, label %bb_rcmovecheck2100
bb_rcmovecheck2100:
  %v7197 = load i64, ptr %slot1225, align 8
  %op7198 = add i64 %v7197, 8
  store i64 %op7198, ptr %slot1237, align 8
  %v7199 = load i64, ptr %slot1237, align 8
  %p7200 = inttoptr i64 %v7199 to ptr
  %ld7201 = load i64, ptr %p7200, align 8
  store i64 %ld7201, ptr %slot1238, align 8
  %v7202 = load i64, ptr %slot1238, align 8
  %cmp7203 = icmp ne i64 %v7202, 0
  %cv7204 = zext i1 %cmp7203 to i32
  store i32 %cv7204, ptr %slot1239, align 8
  %v7205 = load i32, ptr %slot1239, align 8
  %cv7206 = zext i32 %v7205 to i64
  %cond7207 = icmp ne i64 %cv7206, 0
  br i1 %cond7207, label %bb_rcmoveheader2108, label %bb_rcmovenext2108
bb_rcmoveheader2108:
  %v7208 = load i64, ptr %slot1238, align 8
  %op7209 = sub i64 %v7208, 16
  store i64 %op7209, ptr %slot1240, align 8
  %v7210 = load i64, ptr %slot1238, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  %rgep7212 = getelementptr i8, ptr %p7211, i64 -16
  %ld7213 = load i64, ptr %rgep7212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7213, ptr %slot1241, align 8
  %v7214 = load i64, ptr %slot1241, align 8
  %op7215 = and i64 %v7214, 5764607523034234881
  store i64 %op7215, ptr %slot1242, align 8
  %v7216 = load i64, ptr %slot1242, align 8
  %cmp7217 = icmp ne i64 %v7216, 0
  %cv7218 = zext i1 %cmp7217 to i32
  store i32 %cv7218, ptr %slot1243, align 8
  %v7219 = load i32, ptr %slot1243, align 8
  %cv7220 = zext i32 %v7219 to i64
  %cond7221 = icmp ne i64 %cv7220, 0
  br i1 %cond7221, label %bb_rcmoveslow2100, label %bb_rcmovenext2108
bb_rcmovenext2108:
  %v7222 = load i64, ptr %slot1225, align 8
  %v7223 = load i64, ptr %slot1230, align 8
  %p7224 = inttoptr i64 %v7222 to ptr
  %p7225 = inttoptr i64 %v7223 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7225, ptr %p7224, i64 24, i1 false)
  %v7226 = load i64, ptr %slot1225, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  store i64 0, ptr %p7227, align 8
  %v7228 = load i64, ptr %slot1225, align 8
  %op7229 = add i64 %v7228, 8
  store i64 %op7229, ptr %slot1244, align 8
  %v7230 = load i64, ptr %slot1244, align 8
  %p7231 = inttoptr i64 %v7230 to ptr
  store i64 0, ptr %p7231, align 8
  %v7232 = load i64, ptr %slot1225, align 8
  %op7233 = add i64 %v7232, 16
  store i64 %op7233, ptr %slot1245, align 8
  %v7234 = load i64, ptr %slot1245, align 8
  %p7235 = inttoptr i64 %v7234 to ptr
  store i64 0, ptr %p7235, align 8
  br label %bb_rcmoved2100
bb_rcmoveslow2100:
  %v7236 = load i64, ptr %slot73, align 8
  %v7237 = load i64, ptr %slot1230, align 8
  %v7238 = load i64, ptr %slot1225, align 8
  %v7239 = load i64, ptr %slot1231, align 8
  %cv7240 = trunc i64 %v7239 to i32
  %call7241 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v7236, i64 %v7237, i64 %v7238, i32 %cv7240) nomerge, !dbg !182
  store i32 %call7241, ptr %slot1246, align 8
  %v7242 = load i32, ptr %slot1246, align 8
  %cv7243 = zext i32 %v7242 to i64
  %cond7244 = icmp ne i64 %cv7243, 0
  br i1 %cond7244, label %bb_rcsuccess2117, label %bb_rcfailure2117
bb_rcfailure2117:
  %v7245 = load i64, ptr %slot73, align 8
  %p7246 = inttoptr i64 %v7245 to ptr
  %call7247 = call i32 @myl_rc_take_failure(ptr %p7246) nomerge, !dbg !182
  store i32 %call7247, ptr %slot1247, align 8
  %v7248 = load i64, ptr %slot1, align 8
  %p7249 = inttoptr i64 %v7248 to ptr
  %v7250 = load i32, ptr %slot1247, align 8
  %call7251 = call i32 @myl_qbe_rc_status(ptr %p7249, i32 %v7250) nomerge, !dbg !182
  store i32 %call7251, ptr %slot1248, align 8
  br label %bb_failure
bb_rcsuccess2117:
  br label %bb_rcmoved2100
bb_rcmoved2100:
  %v7252 = load i64, ptr %slot24, align 8
  %p7253 = inttoptr i64 %v7252 to ptr
  store i32 0, ptr %p7253, align 4, !alias.scope !3, !noalias !4
  %v7254 = load i64, ptr %slot28, align 8
  %p7255 = inttoptr i64 %v7254 to ptr
  store i32 2, ptr %p7255, align 4, !alias.scope !3, !noalias !4
  %v7256 = load i64, ptr %slot27, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  store i32 1, ptr %p7257, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2091
bb_rccopy2091:
  %v7258 = load i64, ptr %slot32, align 8
  store i64 %v7258, ptr %slot1249, align 8
  %v7259 = load i64, ptr %slot74, align 8
  store i64 %v7259, ptr %slot1250, align 8
  %v7260 = load i64, ptr %slot73, align 8
  %v7261 = load i64, ptr %slot1249, align 8
  %v7262 = load i64, ptr %slot1225, align 8
  %v7263 = load i64, ptr %slot1250, align 8
  %cv7264 = trunc i64 %v7263 to i32
  %call7265 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v7260, i64 %v7261, i64 %v7262, i32 %cv7264) nomerge, !dbg !182
  store i32 %call7265, ptr %slot1251, align 8
  %v7266 = load i32, ptr %slot1251, align 8
  %cv7267 = zext i32 %v7266 to i64
  %cond7268 = icmp ne i64 %cv7267, 0
  br i1 %cond7268, label %bb_rcsuccess2126, label %bb_rcfailure2126
bb_rcfailure2126:
  %v7269 = load i64, ptr %slot73, align 8
  %p7270 = inttoptr i64 %v7269 to ptr
  %call7271 = call i32 @myl_rc_take_failure(ptr %p7270) nomerge, !dbg !182
  store i32 %call7271, ptr %slot1252, align 8
  %v7272 = load i64, ptr %slot1, align 8
  %p7273 = inttoptr i64 %v7272 to ptr
  %v7274 = load i32, ptr %slot1252, align 8
  %call7275 = call i32 @myl_qbe_rc_status(ptr %p7273, i32 %v7274) nomerge, !dbg !182
  store i32 %call7275, ptr %slot1253, align 8
  br label %bb_failure
bb_rcsuccess2126:
  %v7276 = load i64, ptr %slot28, align 8
  %p7277 = inttoptr i64 %v7276 to ptr
  store i32 2, ptr %p7277, align 4, !alias.scope !3, !noalias !4
  %v7278 = load i64, ptr %slot27, align 8
  %p7279 = inttoptr i64 %v7278 to ptr
  store i32 1, ptr %p7279, align 4, !alias.scope !3, !noalias !4
  %v7280 = load i64, ptr %slot24, align 8
  %p7281 = inttoptr i64 %v7280 to ptr
  %ld7282 = load i32, ptr %p7281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7282, ptr %slot1254, align 8
  %v7283 = load i32, ptr %slot1254, align 8
  %cv7284 = zext i32 %v7283 to i64
  %cond7285 = icmp ne i64 %cv7284, 0
  br i1 %cond7285, label %bb_rcslotdrop2133, label %bb_rcslotdone2133
bb_rcslotdrop2133:
  %v7286 = load i64, ptr %slot24, align 8
  %p7287 = inttoptr i64 %v7286 to ptr
  store i32 0, ptr %p7287, align 4, !alias.scope !3, !noalias !4
  %v7288 = load i64, ptr %slot30, align 8
  store i64 %v7288, ptr %slot1255, align 8
  %v7289 = load i64, ptr %slot25, align 8
  %p7290 = inttoptr i64 %v7289 to ptr
  %ld7291 = load i32, ptr %p7290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7291, ptr %slot1256, align 8
  %v7292 = load i32, ptr %slot1256, align 8
  %op7293 = and i32 %v7292, 28
  store i32 %op7293, ptr %slot1257, align 8
  %v7294 = load i32, ptr %slot1257, align 8
  %cv7295 = zext i32 %v7294 to i64
  %cond7296 = icmp ne i64 %cv7295, 0
  br i1 %cond7296, label %bb_rcslotrole2133, label %bb_rcslotowner2133
bb_rcslotrole2133:
  %v7297 = load i64, ptr %slot73, align 8
  store i64 %v7297, ptr %slot1258, align 8
  %v7298 = load i64, ptr %slot1258, align 8
  %v7299 = load i64, ptr %slot1255, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v7298, i64 %v7299) nomerge, !dbg !182
  br label %bb_rcslotdone2133
bb_rcslotowner2133:
  %v7300 = load i64, ptr %slot73, align 8
  store i64 %v7300, ptr %slot1259, align 8
  %v7301 = load i64, ptr %slot1259, align 8
  %v7302 = load i64, ptr %slot1255, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v7301, i64 %v7302) nomerge, !dbg !182
  br label %bb_rcslotdone2133
bb_rcslotdone2133:
  br label %bb_rcprepared2091
bb_rcprepared2091:
  %v7303 = load i64, ptr %slot32, align 8
  store i64 %v7303, ptr %slot1260, align 8
  %v7304 = load i64, ptr %slot1260, align 8
  %v7305 = load i64, ptr %slot1223, align 8
  %p7306 = inttoptr i64 %v7304 to ptr
  %p7307 = inttoptr i64 %v7305 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7307, ptr %p7306, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7308 = load i64, ptr %slot27, align 8
  %p7309 = inttoptr i64 %v7308 to ptr
  store i32 0, ptr %p7309, align 4, !alias.scope !3, !noalias !4
  %v7310 = load i64, ptr %slot1215, align 8
  %v7311 = load i64, ptr %slot52, align 8
  %p7312 = inttoptr i64 %v7311 to ptr
  store i64 %v7310, ptr %p7312, align 8, !alias.scope !3, !noalias !4
  %v7313 = load i64, ptr %slot52, align 8
  %p7314 = inttoptr i64 %v7313 to ptr
  %ld7315 = load i64, ptr %p7314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7315, ptr %slot1261, align 8
  %v7316 = load i64, ptr %slot30, align 8
  store i64 %v7316, ptr %slot1262, align 8
  %v7317 = load i64, ptr %slot1261, align 8
  %v7318 = load i64, ptr %slot1262, align 8
  %p7319 = inttoptr i64 %v7317 to ptr
  %p7320 = inttoptr i64 %v7318 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7320, ptr %p7319, i64 56, i1 false)
  %v7321 = load i64, ptr %slot25, align 8
  %p7322 = inttoptr i64 %v7321 to ptr
  store i32 2, ptr %p7322, align 4, !alias.scope !3, !noalias !4
  %v7323 = load i64, ptr %slot24, align 8
  %p7324 = inttoptr i64 %v7323 to ptr
  store i32 1, ptr %p7324, align 4, !alias.scope !3, !noalias !4
  %v7325 = load i64, ptr %slot1262, align 8
  %v7326 = load i64, ptr %slot52, align 8
  %p7327 = inttoptr i64 %v7326 to ptr
  store i64 %v7325, ptr %p7327, align 8, !alias.scope !3, !noalias !4
  %v7328 = load i64, ptr %slot52, align 8
  %p7329 = inttoptr i64 %v7328 to ptr
  %ld7330 = load i64, ptr %p7329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7330, ptr %slot1263, align 8
  %v7331 = load i64, ptr %slot24, align 8
  %p7332 = inttoptr i64 %v7331 to ptr
  %ld7333 = load i32, ptr %p7332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7333, ptr %slot1264, align 8
  %v7334 = load i64, ptr %slot25, align 8
  %p7335 = inttoptr i64 %v7334 to ptr
  %ld7336 = load i32, ptr %p7335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7336, ptr %slot1265, align 8
  %v7337 = load i32, ptr %slot1265, align 8
  %op7338 = and i32 %v7337, 24
  store i32 %op7338, ptr %slot1265, align 8
  %v7339 = load i32, ptr %slot1265, align 8
  %cmp7340 = icmp eq i32 %v7339, 0
  %cv7341 = zext i1 %cmp7340 to i32
  store i32 %cv7341, ptr %slot1266, align 8
  %v7342 = load i32, ptr %slot1264, align 8
  %v7343 = load i32, ptr %slot1266, align 8
  %op7344 = and i32 %v7342, %v7343
  store i32 %op7344, ptr %slot1267, align 8
  %v7345 = load i32, ptr %slot1267, align 8
  %cv7346 = zext i32 %v7345 to i64
  %cond7347 = icmp ne i64 %cv7346, 0
  br i1 %cond7347, label %bb_rcprivateown2153, label %bb_rcprivateloan2153
bb_rcprivateown2153:
  %v7348 = load i64, ptr %slot32, align 8
  store i64 %v7348, ptr %slot1268, align 8
  %v7349 = load i64, ptr %slot74, align 8
  store i64 %v7349, ptr %slot1269, align 8
  %v7350 = load i64, ptr %slot73, align 8
  %v7351 = load i64, ptr %slot1268, align 8
  %v7352 = load i64, ptr %slot1263, align 8
  %v7353 = load i64, ptr %slot1269, align 8
  %cv7354 = trunc i64 %v7353 to i32
  %call7355 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v7350, i64 %v7351, i64 %v7352, i32 %cv7354) nomerge, !dbg !184
  store i32 %call7355, ptr %slot1270, align 8
  %v7356 = load i32, ptr %slot1270, align 8
  %cv7357 = zext i32 %v7356 to i64
  %cond7358 = icmp ne i64 %cv7357, 0
  br i1 %cond7358, label %bb_rcsuccess2157, label %bb_rcfailure2157
bb_rcfailure2157:
  %v7359 = load i64, ptr %slot73, align 8
  %p7360 = inttoptr i64 %v7359 to ptr
  %call7361 = call i32 @myl_rc_take_failure(ptr %p7360) nomerge, !dbg !184
  store i32 %call7361, ptr %slot1271, align 8
  %v7362 = load i64, ptr %slot1, align 8
  %p7363 = inttoptr i64 %v7362 to ptr
  %v7364 = load i32, ptr %slot1271, align 8
  %call7365 = call i32 @myl_qbe_rc_status(ptr %p7363, i32 %v7364) nomerge, !dbg !184
  store i32 %call7365, ptr %slot1272, align 8
  br label %bb_failure
bb_rcsuccess2157:
  %v7366 = load i64, ptr %slot24, align 8
  %p7367 = inttoptr i64 %v7366 to ptr
  store i32 0, ptr %p7367, align 4, !alias.scope !3, !noalias !4
  %v7368 = load i64, ptr %slot28, align 8
  %p7369 = inttoptr i64 %v7368 to ptr
  store i32 2, ptr %p7369, align 4, !alias.scope !3, !noalias !4
  %v7370 = load i64, ptr %slot27, align 8
  %p7371 = inttoptr i64 %v7370 to ptr
  store i32 1, ptr %p7371, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2153
bb_rcprivateloan2153:
  %v7372 = load i64, ptr %slot24, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  %ld7374 = load i32, ptr %p7373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7374, ptr %slot1273, align 8
  %v7375 = load i64, ptr %slot25, align 8
  %p7376 = inttoptr i64 %v7375 to ptr
  %ld7377 = load i32, ptr %p7376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7377, ptr %slot1274, align 8
  %v7378 = load i32, ptr %slot1274, align 8
  %cmp7379 = icmp eq i32 %v7378, 16
  %cv7380 = zext i1 %cmp7379 to i32
  store i32 %cv7380, ptr %slot1275, align 8
  %v7381 = load i32, ptr %slot1275, align 8
  %v7382 = load i32, ptr %slot1273, align 8
  %op7383 = and i32 %v7381, %v7382
  store i32 %op7383, ptr %slot1275, align 8
  %v7384 = load i32, ptr %slot1275, align 8
  %cv7385 = zext i32 %v7384 to i64
  %cond7386 = icmp ne i64 %cv7385, 0
  br i1 %cond7386, label %bb_rcprivatemove2153, label %bb_rcprivatenew2153
bb_rcprivatemove2153:
  %v7387 = load i64, ptr %slot32, align 8
  store i64 %v7387, ptr %slot1276, align 8
  %v7388 = load i64, ptr %slot1263, align 8
  %v7389 = load i64, ptr %slot1276, align 8
  %p7390 = inttoptr i64 %v7388 to ptr
  %p7391 = inttoptr i64 %v7389 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7391, ptr %p7390, i64 56, i1 false)
  %v7392 = load i64, ptr %slot1263, align 8
  %p7393 = inttoptr i64 %v7392 to ptr
  call void @llvm.memset.p0.i64(ptr %p7393, i8 0, i64 56, i1 false), !dbg !184
  %v7394 = load i64, ptr %slot28, align 8
  %p7395 = inttoptr i64 %v7394 to ptr
  store i32 2, ptr %p7395, align 4, !alias.scope !3, !noalias !4
  %v7396 = load i64, ptr %slot28, align 8
  %p7397 = inttoptr i64 %v7396 to ptr
  store i32 16, ptr %p7397, align 4, !alias.scope !3, !noalias !4
  %v7398 = load i64, ptr %slot27, align 8
  %p7399 = inttoptr i64 %v7398 to ptr
  store i32 1, ptr %p7399, align 4, !alias.scope !3, !noalias !4
  %v7400 = load i64, ptr %slot24, align 8
  %p7401 = inttoptr i64 %v7400 to ptr
  store i32 0, ptr %p7401, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2153
bb_rcprivatenew2153:
  %v7402 = load i64, ptr %slot32, align 8
  store i64 %v7402, ptr %slot1277, align 8
  %v7403 = load i64, ptr %slot73, align 8
  %v7404 = load i64, ptr %slot1277, align 8
  %v7405 = load i64, ptr %slot1263, align 8
  %call7406 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v7403, i64 %v7404, i64 %v7405) nomerge, !dbg !184
  store i32 %call7406, ptr %slot1278, align 8
  %v7407 = load i32, ptr %slot1278, align 8
  %cv7408 = zext i32 %v7407 to i64
  %cond7409 = icmp ne i64 %cv7408, 0
  br i1 %cond7409, label %bb_rcsuccess2175, label %bb_rcfailure2175
bb_rcfailure2175:
  %v7410 = load i64, ptr %slot73, align 8
  %p7411 = inttoptr i64 %v7410 to ptr
  %call7412 = call i32 @myl_rc_take_failure(ptr %p7411) nomerge, !dbg !184
  store i32 %call7412, ptr %slot1279, align 8
  %v7413 = load i64, ptr %slot1, align 8
  %p7414 = inttoptr i64 %v7413 to ptr
  %v7415 = load i32, ptr %slot1279, align 8
  %call7416 = call i32 @myl_qbe_rc_status(ptr %p7414, i32 %v7415) nomerge, !dbg !184
  store i32 %call7416, ptr %slot1280, align 8
  br label %bb_failure
bb_rcsuccess2175:
  %v7417 = load i64, ptr %slot28, align 8
  %p7418 = inttoptr i64 %v7417 to ptr
  store i32 2, ptr %p7418, align 4, !alias.scope !3, !noalias !4
  %v7419 = load i64, ptr %slot28, align 8
  %p7420 = inttoptr i64 %v7419 to ptr
  store i32 16, ptr %p7420, align 4, !alias.scope !3, !noalias !4
  %v7421 = load i64, ptr %slot27, align 8
  %p7422 = inttoptr i64 %v7421 to ptr
  store i32 1, ptr %p7422, align 4, !alias.scope !3, !noalias !4
  %v7423 = load i64, ptr %slot24, align 8
  %p7424 = inttoptr i64 %v7423 to ptr
  %ld7425 = load i32, ptr %p7424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7425, ptr %slot1281, align 8
  %v7426 = load i32, ptr %slot1281, align 8
  %cv7427 = zext i32 %v7426 to i64
  %cond7428 = icmp ne i64 %cv7427, 0
  br i1 %cond7428, label %bb_rcslotdrop2183, label %bb_rcslotdone2183
bb_rcslotdrop2183:
  %v7429 = load i64, ptr %slot24, align 8
  %p7430 = inttoptr i64 %v7429 to ptr
  store i32 0, ptr %p7430, align 4, !alias.scope !3, !noalias !4
  %v7431 = load i64, ptr %slot30, align 8
  store i64 %v7431, ptr %slot1282, align 8
  %v7432 = load i64, ptr %slot25, align 8
  %p7433 = inttoptr i64 %v7432 to ptr
  %ld7434 = load i32, ptr %p7433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7434, ptr %slot1283, align 8
  %v7435 = load i32, ptr %slot1283, align 8
  %op7436 = and i32 %v7435, 28
  store i32 %op7436, ptr %slot1284, align 8
  %v7437 = load i32, ptr %slot1284, align 8
  %cv7438 = zext i32 %v7437 to i64
  %cond7439 = icmp ne i64 %cv7438, 0
  br i1 %cond7439, label %bb_rcslotrole2183, label %bb_rcslotowner2183
bb_rcslotrole2183:
  %v7440 = load i64, ptr %slot73, align 8
  store i64 %v7440, ptr %slot1285, align 8
  %v7441 = load i64, ptr %slot1285, align 8
  %v7442 = load i64, ptr %slot1282, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7441, i64 %v7442) nomerge, !dbg !184
  br label %bb_rcslotdone2183
bb_rcslotowner2183:
  %v7443 = load i64, ptr %slot73, align 8
  store i64 %v7443, ptr %slot1286, align 8
  %v7444 = load i64, ptr %slot1286, align 8
  %v7445 = load i64, ptr %slot1282, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7444, i64 %v7445) nomerge, !dbg !184
  br label %bb_rcslotdone2183
bb_rcslotdone2183:
  br label %bb_rcprivateprepared2153
bb_rcprivateprepared2153:
  %v7446 = load i64, ptr %slot18, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  %ld7448 = load i32, ptr %p7447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7448, ptr %slot1287, align 8
  %v7449 = load i32, ptr %slot1287, align 8
  %cv7450 = zext i32 %v7449 to i64
  %cond7451 = icmp ne i64 %cv7450, 0
  br i1 %cond7451, label %bb_rcslotdrop2193, label %bb_rcslotdone2193
bb_rcslotdrop2193:
  %v7452 = load i64, ptr %slot18, align 8
  %p7453 = inttoptr i64 %v7452 to ptr
  store i32 0, ptr %p7453, align 4, !alias.scope !3, !noalias !4
  %v7454 = load i64, ptr %slot47, align 8
  store i64 %v7454, ptr %slot1288, align 8
  %v7455 = load i64, ptr %slot19, align 8
  %p7456 = inttoptr i64 %v7455 to ptr
  %ld7457 = load i32, ptr %p7456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7457, ptr %slot1289, align 8
  %v7458 = load i32, ptr %slot1289, align 8
  %op7459 = and i32 %v7458, 28
  store i32 %op7459, ptr %slot1290, align 8
  %v7460 = load i32, ptr %slot1290, align 8
  %cv7461 = zext i32 %v7460 to i64
  %cond7462 = icmp ne i64 %cv7461, 0
  br i1 %cond7462, label %bb_rcslotrole2193, label %bb_rcslotowner2193
bb_rcslotrole2193:
  %v7463 = load i64, ptr %slot73, align 8
  store i64 %v7463, ptr %slot1291, align 8
  %v7464 = load i64, ptr %slot1291, align 8
  %v7465 = load i64, ptr %slot1288, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7464, i64 %v7465) nomerge, !dbg !184
  br label %bb_rcslotdone2193
bb_rcslotowner2193:
  %v7466 = load i64, ptr %slot73, align 8
  store i64 %v7466, ptr %slot1292, align 8
  %v7467 = load i64, ptr %slot1292, align 8
  %v7468 = load i64, ptr %slot1288, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7467, i64 %v7468) nomerge, !dbg !184
  br label %bb_rcslotdone2193
bb_rcslotdone2193:
  %v7469 = load i64, ptr %slot47, align 8
  store i64 %v7469, ptr %slot1293, align 8
  %v7470 = load i64, ptr %slot32, align 8
  store i64 %v7470, ptr %slot1294, align 8
  %v7471 = load i64, ptr %slot1294, align 8
  %v7472 = load i64, ptr %slot1293, align 8
  %p7473 = inttoptr i64 %v7471 to ptr
  %p7474 = inttoptr i64 %v7472 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7474, ptr %p7473, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7475 = load i64, ptr %slot27, align 8
  %p7476 = inttoptr i64 %v7475 to ptr
  store i32 0, ptr %p7476, align 4, !alias.scope !3, !noalias !4
  %v7477 = load i64, ptr %slot19, align 8
  %p7478 = inttoptr i64 %v7477 to ptr
  store i32 2, ptr %p7478, align 4, !alias.scope !3, !noalias !4
  %v7479 = load i64, ptr %slot28, align 8
  %p7480 = inttoptr i64 %v7479 to ptr
  %ld7481 = load i32, ptr %p7480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7481, ptr %slot1295, align 8
  %v7482 = load i32, ptr %slot1295, align 8
  %v7483 = load i64, ptr %slot19, align 8
  %p7484 = inttoptr i64 %v7483 to ptr
  store i32 %v7482, ptr %p7484, align 4, !alias.scope !3, !noalias !4
  %v7485 = load i64, ptr %slot18, align 8
  %p7486 = inttoptr i64 %v7485 to ptr
  store i32 1, ptr %p7486, align 4, !alias.scope !3, !noalias !4
  %v7487 = load i64, ptr %slot36, align 8
  %p7488 = inttoptr i64 %v7487 to ptr
  %ld7489 = load i64, ptr %p7488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7489, ptr %slot1296, align 8
  %v7490 = load i64, ptr %slot1296, align 8
  %v7491 = load i64, ptr %slot52, align 8
  %p7492 = inttoptr i64 %v7491 to ptr
  store i64 %v7490, ptr %p7492, align 8, !alias.scope !3, !noalias !4
  %v7493 = load i64, ptr %slot52, align 8
  %p7494 = inttoptr i64 %v7493 to ptr
  %ld7495 = load i64, ptr %p7494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7495, ptr %slot1297, align 8
  %v7496 = load i64, ptr %slot1297, align 8
  %op7497 = add i64 %v7496, 32
  store i64 %op7497, ptr %slot1298, align 8
  %v7498 = load i64, ptr %slot1298, align 8
  %v7499 = load i64, ptr %slot52, align 8
  %p7500 = inttoptr i64 %v7499 to ptr
  store i64 %v7498, ptr %p7500, align 8, !alias.scope !3, !noalias !4
  %v7501 = load i64, ptr %slot24, align 8
  %p7502 = inttoptr i64 %v7501 to ptr
  %ld7503 = load i32, ptr %p7502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7503, ptr %slot1299, align 8
  %v7504 = load i32, ptr %slot1299, align 8
  %cv7505 = zext i32 %v7504 to i64
  %cond7506 = icmp ne i64 %cv7505, 0
  br i1 %cond7506, label %bb_rcslotdrop2212, label %bb_rcslotdone2212
bb_rcslotdrop2212:
  %v7507 = load i64, ptr %slot24, align 8
  %p7508 = inttoptr i64 %v7507 to ptr
  store i32 0, ptr %p7508, align 4, !alias.scope !3, !noalias !4
  %v7509 = load i64, ptr %slot30, align 8
  store i64 %v7509, ptr %slot1300, align 8
  %v7510 = load i64, ptr %slot25, align 8
  %p7511 = inttoptr i64 %v7510 to ptr
  %ld7512 = load i32, ptr %p7511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7512, ptr %slot1301, align 8
  %v7513 = load i32, ptr %slot1301, align 8
  %op7514 = and i32 %v7513, 28
  store i32 %op7514, ptr %slot1302, align 8
  %v7515 = load i32, ptr %slot1302, align 8
  %cv7516 = zext i32 %v7515 to i64
  %cond7517 = icmp ne i64 %cv7516, 0
  br i1 %cond7517, label %bb_rcslotrole2212, label %bb_rcslotowner2212
bb_rcslotrole2212:
  %v7518 = load i64, ptr %slot73, align 8
  store i64 %v7518, ptr %slot1303, align 8
  %v7519 = load i64, ptr %slot1303, align 8
  %v7520 = load i64, ptr %slot1300, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v7519, i64 %v7520) nomerge, !dbg !186
  br label %bb_rcslotdone2212
bb_rcslotowner2212:
  %v7521 = load i64, ptr %slot73, align 8
  store i64 %v7521, ptr %slot1304, align 8
  %v7522 = load i64, ptr %slot1304, align 8
  %v7523 = load i64, ptr %slot1300, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v7522, i64 %v7523) nomerge, !dbg !186
  br label %bb_rcslotdone2212
bb_rcslotdone2212:
  %v7524 = load i64, ptr %slot52, align 8
  %p7525 = inttoptr i64 %v7524 to ptr
  %ld7526 = load i64, ptr %p7525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7526, ptr %slot1305, align 8
  %v7527 = load i64, ptr %slot1305, align 8
  %op7528 = add i64 %v7527, 0
  store i64 %op7528, ptr %slot1306, align 8
  %v7529 = load i64, ptr %slot1306, align 8
  %p7530 = inttoptr i64 %v7529 to ptr
  %ld7531 = load i64, ptr %p7530, align 8
  store i64 %ld7531, ptr %slot1307, align 8
  %v7532 = load i64, ptr %slot1307, align 8
  %v7533 = load i64, ptr %slot52, align 8
  %p7534 = inttoptr i64 %v7533 to ptr
  store i64 %v7532, ptr %p7534, align 8, !alias.scope !3, !noalias !4
  %v7535 = load i64, ptr %slot52, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  %ld7537 = load i64, ptr %p7536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7537, ptr %slot1308, align 8
  %v7538 = load i64, ptr %slot1308, align 8
  %v7539 = load i64, ptr %slot31, align 8
  %p7540 = inttoptr i64 %v7539 to ptr
  store i64 %v7538, ptr %p7540, align 8, !alias.scope !3, !noalias !4
  %v7541 = load i64, ptr %slot31, align 8
  store i64 %v7541, ptr %slot1309, align 8
  %v7542 = load i64, ptr %slot32, align 8
  store i64 %v7542, ptr %slot1310, align 8
  %v7543 = load i64, ptr %slot1309, align 8
  %p7544 = inttoptr i64 %v7543 to ptr
  %ld7545 = load i64, ptr %p7544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7545, ptr %slot1311, align 8
  %v7546 = load i64, ptr %slot1311, align 8
  %cmp7547 = icmp ne i64 %v7546, 0
  %cv7548 = zext i1 %cmp7547 to i32
  store i32 %cv7548, ptr %slot1312, align 8
  %v7549 = load i32, ptr %slot1312, align 8
  %cv7550 = zext i32 %v7549 to i64
  %cond7551 = icmp ne i64 %cv7550, 0
  br i1 %cond7551, label %bb_rcgnn2226, label %bb_rcgstore2226
bb_rcgnn2226:
  %v7552 = load i64, ptr %slot1311, align 8
  %op7553 = sub i64 %v7552, 16
  store i64 %op7553, ptr %slot1313, align 8
  %v7554 = load i64, ptr %slot1311, align 8
  %p7555 = inttoptr i64 %v7554 to ptr
  %rgep7556 = getelementptr i8, ptr %p7555, i64 -16
  %ld7557 = load i64, ptr %rgep7556, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7557, ptr %slot1314, align 8
  %v7558 = load i64, ptr %slot1314, align 8
  %op7559 = and i64 %v7558, 4611686018427387906
  store i64 %op7559, ptr %slot1315, align 8
  %v7560 = load i64, ptr %slot1315, align 8
  %cmp7561 = icmp ne i64 %v7560, 0
  %cv7562 = zext i1 %cmp7561 to i32
  store i32 %cv7562, ptr %slot1316, align 8
  %v7563 = load i32, ptr %slot1316, align 8
  %cv7564 = zext i32 %v7563 to i64
  %cond7565 = icmp ne i64 %cv7564, 0
  br i1 %cond7565, label %bb_rcgstore2226, label %bb_rcginc2226
bb_rcginc2226:
  %v7566 = load i64, ptr %slot1311, align 8
  %op7567 = sub i64 %v7566, 24
  store i64 %op7567, ptr %slot1317, align 8
  %v7568 = load i64, ptr %slot1311, align 8
  %p7569 = inttoptr i64 %v7568 to ptr
  %rgep7570 = getelementptr i8, ptr %p7569, i64 -24
  %ld7571 = load i64, ptr %rgep7570, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7571, ptr %slot1318, align 8
  %v7572 = load i64, ptr %slot1318, align 8
  %op7573 = add i64 %v7572, 1
  store i64 %op7573, ptr %slot1319, align 8
  %v7574 = load i64, ptr %slot1319, align 8
  %cmp7575 = icmp eq i64 %v7574, 0
  %cv7576 = zext i1 %cmp7575 to i32
  store i32 %cv7576, ptr %slot1320, align 8
  %v7577 = load i32, ptr %slot1320, align 8
  %cv7578 = zext i32 %v7577 to i64
  %cond7579 = icmp ne i64 %cv7578, 0
  br i1 %cond7579, label %bb_rcglimit2226, label %bb_rcgcapacity2226
bb_rcglimit2226:
  %v7580 = load i64, ptr %slot1, align 8
  %p7581 = inttoptr i64 %v7580 to ptr
  %call7582 = call i32 @myl_qbe_rc_status(ptr %p7581, i32 2) nomerge, !dbg !188
  store i32 %call7582, ptr %slot1321, align 8
  br label %bb_failure
bb_rcgcapacity2226:
  %v7583 = load i64, ptr %slot1319, align 8
  %v7584 = load i64, ptr %slot1311, align 8
  %p7585 = inttoptr i64 %v7584 to ptr
  %rgep7586 = getelementptr i8, ptr %p7585, i64 -24
  store i64 %v7583, ptr %rgep7586, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2226
bb_rcgstore2226:
  %v7587 = load i64, ptr %slot1311, align 8
  %v7588 = load i64, ptr %slot1310, align 8
  %p7589 = inttoptr i64 %v7588 to ptr
  store i64 %v7587, ptr %p7589, align 8, !alias.scope !3, !noalias !4
  %v7590 = load i64, ptr %slot28, align 8
  %p7591 = inttoptr i64 %v7590 to ptr
  store i32 2, ptr %p7591, align 4, !alias.scope !3, !noalias !4
  %v7592 = load i64, ptr %slot28, align 8
  %p7593 = inttoptr i64 %v7592 to ptr
  store i32 16, ptr %p7593, align 4, !alias.scope !3, !noalias !4
  %v7594 = load i64, ptr %slot27, align 8
  %p7595 = inttoptr i64 %v7594 to ptr
  store i32 1, ptr %p7595, align 4, !alias.scope !3, !noalias !4
  %v7596 = load i64, ptr %slot24, align 8
  %p7597 = inttoptr i64 %v7596 to ptr
  %ld7598 = load i32, ptr %p7597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7598, ptr %slot1322, align 8
  %v7599 = load i32, ptr %slot1322, align 8
  %cv7600 = zext i32 %v7599 to i64
  %cond7601 = icmp ne i64 %cv7600, 0
  br i1 %cond7601, label %bb_rcslotdrop2242, label %bb_rcslotdone2242
bb_rcslotdrop2242:
  %v7602 = load i64, ptr %slot24, align 8
  %p7603 = inttoptr i64 %v7602 to ptr
  store i32 0, ptr %p7603, align 4, !alias.scope !3, !noalias !4
  %v7604 = load i64, ptr %slot30, align 8
  store i64 %v7604, ptr %slot1323, align 8
  %v7605 = load i64, ptr %slot25, align 8
  %p7606 = inttoptr i64 %v7605 to ptr
  %ld7607 = load i32, ptr %p7606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7607, ptr %slot1324, align 8
  %v7608 = load i32, ptr %slot1324, align 8
  %op7609 = and i32 %v7608, 28
  store i32 %op7609, ptr %slot1325, align 8
  %v7610 = load i32, ptr %slot1325, align 8
  %cv7611 = zext i32 %v7610 to i64
  %cond7612 = icmp ne i64 %cv7611, 0
  br i1 %cond7612, label %bb_rcslotrole2242, label %bb_rcslotowner2242
bb_rcslotrole2242:
  %v7613 = load i64, ptr %slot73, align 8
  store i64 %v7613, ptr %slot1326, align 8
  %v7614 = load i64, ptr %slot1326, align 8
  %v7615 = load i64, ptr %slot1323, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7614, i64 %v7615) nomerge, !dbg !188
  br label %bb_rcslotdone2242
bb_rcslotowner2242:
  %v7616 = load i64, ptr %slot73, align 8
  store i64 %v7616, ptr %slot1327, align 8
  %v7617 = load i64, ptr %slot1327, align 8
  %v7618 = load i64, ptr %slot1323, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7617, i64 %v7618) nomerge, !dbg !188
  br label %bb_rcslotdone2242
bb_rcslotdone2242:
  %v7619 = load i64, ptr %slot30, align 8
  store i64 %v7619, ptr %slot1328, align 8
  %v7620 = load i64, ptr %slot32, align 8
  store i64 %v7620, ptr %slot1329, align 8
  %v7621 = load i64, ptr %slot1329, align 8
  %v7622 = load i64, ptr %slot1328, align 8
  %p7623 = inttoptr i64 %v7621 to ptr
  %p7624 = inttoptr i64 %v7622 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7624, ptr %p7623, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7625 = load i64, ptr %slot25, align 8
  %p7626 = inttoptr i64 %v7625 to ptr
  store i32 2, ptr %p7626, align 4, !alias.scope !3, !noalias !4
  %v7627 = load i64, ptr %slot28, align 8
  %p7628 = inttoptr i64 %v7627 to ptr
  %ld7629 = load i32, ptr %p7628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7629, ptr %slot1330, align 8
  %v7630 = load i32, ptr %slot1330, align 8
  %v7631 = load i64, ptr %slot25, align 8
  %p7632 = inttoptr i64 %v7631 to ptr
  store i32 %v7630, ptr %p7632, align 4, !alias.scope !3, !noalias !4
  %v7633 = load i64, ptr %slot27, align 8
  %p7634 = inttoptr i64 %v7633 to ptr
  store i32 0, ptr %p7634, align 4, !alias.scope !3, !noalias !4
  %v7635 = load i64, ptr %slot24, align 8
  %p7636 = inttoptr i64 %v7635 to ptr
  store i32 1, ptr %p7636, align 4, !alias.scope !3, !noalias !4
  %v7637 = load i64, ptr %slot1328, align 8
  %p7638 = inttoptr i64 %v7637 to ptr
  %ld7639 = load i64, ptr %p7638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7639, ptr %slot1331, align 8
  %v7640 = load i64, ptr %slot1331, align 8
  %v7641 = load i64, ptr %slot52, align 8
  %p7642 = inttoptr i64 %v7641 to ptr
  store i64 %v7640, ptr %p7642, align 8, !alias.scope !3, !noalias !4
  %v7643 = load i64, ptr %slot52, align 8
  %p7644 = inttoptr i64 %v7643 to ptr
  %ld7645 = load i64, ptr %p7644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7645, ptr %slot1332, align 8
  %v7646 = load i64, ptr %slot36, align 8
  %p7647 = inttoptr i64 %v7646 to ptr
  %ld7648 = load i64, ptr %p7647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7648, ptr %slot1333, align 8
  %v7649 = load i64, ptr %slot24, align 8
  %p7650 = inttoptr i64 %v7649 to ptr
  %ld7651 = load i32, ptr %p7650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7651, ptr %slot1334, align 8
  %v7652 = load i32, ptr %slot1334, align 8
  %cv7653 = zext i32 %v7652 to i64
  %cond7654 = icmp ne i64 %cv7653, 0
  br i1 %cond7654, label %bb_rcslotdrop2263, label %bb_rcslotdone2263
bb_rcslotdrop2263:
  %v7655 = load i64, ptr %slot24, align 8
  %p7656 = inttoptr i64 %v7655 to ptr
  store i32 0, ptr %p7656, align 4, !alias.scope !3, !noalias !4
  %v7657 = load i64, ptr %slot30, align 8
  store i64 %v7657, ptr %slot1335, align 8
  %v7658 = load i64, ptr %slot25, align 8
  %p7659 = inttoptr i64 %v7658 to ptr
  %ld7660 = load i32, ptr %p7659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7660, ptr %slot1336, align 8
  %v7661 = load i32, ptr %slot1336, align 8
  %op7662 = and i32 %v7661, 28
  store i32 %op7662, ptr %slot1337, align 8
  %v7663 = load i32, ptr %slot1337, align 8
  %cv7664 = zext i32 %v7663 to i64
  %cond7665 = icmp ne i64 %cv7664, 0
  br i1 %cond7665, label %bb_rcslotrole2263, label %bb_rcslotowner2263
bb_rcslotrole2263:
  %v7666 = load i64, ptr %slot73, align 8
  store i64 %v7666, ptr %slot1338, align 8
  %v7667 = load i64, ptr %slot1335, align 8
  %p7668 = inttoptr i64 %v7667 to ptr
  %ld7669 = load i64, ptr %p7668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7669, ptr %slot1339, align 8
  %v7670 = load i64, ptr %slot1339, align 8
  %cmp7671 = icmp ne i64 %v7670, 0
  %cv7672 = zext i1 %cmp7671 to i32
  store i32 %cv7672, ptr %slot1340, align 8
  %v7673 = load i32, ptr %slot1340, align 8
  %cv7674 = zext i32 %v7673 to i64
  %cond7675 = icmp ne i64 %cv7674, 0
  br i1 %cond7675, label %bb_rcgnn2279, label %bb_rcgdone2279
bb_rcgnn2279:
  %v7676 = load i64, ptr %slot1339, align 8
  %op7677 = sub i64 %v7676, 16
  store i64 %op7677, ptr %slot1341, align 8
  %v7678 = load i64, ptr %slot1339, align 8
  %p7679 = inttoptr i64 %v7678 to ptr
  %rgep7680 = getelementptr i8, ptr %p7679, i64 -16
  %ld7681 = load i64, ptr %rgep7680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7681, ptr %slot1342, align 8
  %v7682 = load i64, ptr %slot1342, align 8
  %op7683 = and i64 %v7682, 4611686018427387906
  store i64 %op7683, ptr %slot1343, align 8
  %v7684 = load i64, ptr %slot1343, align 8
  %cmp7685 = icmp ne i64 %v7684, 0
  %cv7686 = zext i1 %cmp7685 to i32
  store i32 %cv7686, ptr %slot1344, align 8
  %v7687 = load i32, ptr %slot1344, align 8
  %cv7688 = zext i32 %v7687 to i64
  %cond7689 = icmp ne i64 %cv7688, 0
  br i1 %cond7689, label %bb_rcgclear2279, label %bb_rcgcounted2279
bb_rcgcounted2279:
  %v7690 = load i64, ptr %slot1339, align 8
  %op7691 = sub i64 %v7690, 24
  store i64 %op7691, ptr %slot1345, align 8
  %v7692 = load i64, ptr %slot1339, align 8
  %p7693 = inttoptr i64 %v7692 to ptr
  %rgep7694 = getelementptr i8, ptr %p7693, i64 -24
  %ld7695 = load i64, ptr %rgep7694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7695, ptr %slot1346, align 8
  %v7696 = load i64, ptr %slot1346, align 8
  %op7697 = sub i64 %v7696, 1
  store i64 %op7697, ptr %slot1347, align 8
  %v7698 = load i64, ptr %slot1347, align 8
  %cmp7699 = icmp eq i64 %v7698, 0
  %cv7700 = zext i1 %cmp7699 to i32
  store i32 %cv7700, ptr %slot1348, align 8
  %v7701 = load i32, ptr %slot1348, align 8
  %cv7702 = zext i32 %v7701 to i64
  %cond7703 = icmp ne i64 %cv7702, 0
  br i1 %cond7703, label %bb_rcglast2279, label %bb_rcgdec2279
bb_rcglast2279:
  %v7704 = load i64, ptr %slot1339, align 8
  %op7705 = sub i64 %v7704, 32
  store i64 %op7705, ptr %slot1349, align 8
  %v7706 = load i64, ptr %slot1339, align 8
  %p7707 = inttoptr i64 %v7706 to ptr
  %rgep7708 = getelementptr i8, ptr %p7707, i64 -32
  %ld7709 = load i64, ptr %rgep7708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7709, ptr %slot1350, align 8
  %v7710 = load i64, ptr %slot1350, align 8
  %cmp7711 = icmp ne i64 %v7710, 0
  %cv7712 = zext i1 %cmp7711 to i32
  store i32 %cv7712, ptr %slot1351, align 8
  %v7713 = load i32, ptr %slot1351, align 8
  %cv7714 = zext i32 %v7713 to i64
  %cond7715 = icmp ne i64 %cv7714, 0
  br i1 %cond7715, label %bb_rcgdec2279, label %bb_rcgslow2279
bb_rcgslow2279:
  %v7716 = load i64, ptr %slot1338, align 8
  %v7717 = load i64, ptr %slot1335, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v7716, i64 %v7717) nomerge, !dbg !190
  br label %bb_rcgdone2279
bb_rcgdec2279:
  %v7718 = load i64, ptr %slot1347, align 8
  %v7719 = load i64, ptr %slot1339, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  %rgep7721 = getelementptr i8, ptr %p7720, i64 -24
  store i64 %v7718, ptr %rgep7721, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2279
bb_rcgclear2279:
  %v7722 = load i64, ptr %slot1335, align 8
  %p7723 = inttoptr i64 %v7722 to ptr
  store i64 0, ptr %p7723, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2279
bb_rcgdone2279:
  br label %bb_rcslotdone2263
bb_rcslotowner2263:
  %v7724 = load i64, ptr %slot73, align 8
  store i64 %v7724, ptr %slot1352, align 8
  %v7725 = load i64, ptr %slot1335, align 8
  %p7726 = inttoptr i64 %v7725 to ptr
  %ld7727 = load i64, ptr %p7726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7727, ptr %slot1353, align 8
  %v7728 = load i64, ptr %slot1353, align 8
  %cmp7729 = icmp ne i64 %v7728, 0
  %cv7730 = zext i1 %cmp7729 to i32
  store i32 %cv7730, ptr %slot1354, align 8
  %v7731 = load i32, ptr %slot1354, align 8
  %cv7732 = zext i32 %v7731 to i64
  %cond7733 = icmp ne i64 %cv7732, 0
  br i1 %cond7733, label %bb_rcgnn2294, label %bb_rcgdone2294
bb_rcgnn2294:
  %v7734 = load i64, ptr %slot1353, align 8
  %op7735 = sub i64 %v7734, 16
  store i64 %op7735, ptr %slot1355, align 8
  %v7736 = load i64, ptr %slot1353, align 8
  %p7737 = inttoptr i64 %v7736 to ptr
  %rgep7738 = getelementptr i8, ptr %p7737, i64 -16
  %ld7739 = load i64, ptr %rgep7738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7739, ptr %slot1356, align 8
  %v7740 = load i64, ptr %slot1356, align 8
  %op7741 = and i64 %v7740, 4611686018427387906
  store i64 %op7741, ptr %slot1357, align 8
  %v7742 = load i64, ptr %slot1357, align 8
  %cmp7743 = icmp ne i64 %v7742, 0
  %cv7744 = zext i1 %cmp7743 to i32
  store i32 %cv7744, ptr %slot1358, align 8
  %v7745 = load i32, ptr %slot1358, align 8
  %cv7746 = zext i32 %v7745 to i64
  %cond7747 = icmp ne i64 %cv7746, 0
  br i1 %cond7747, label %bb_rcgclear2294, label %bb_rcgcounted2294
bb_rcgcounted2294:
  %v7748 = load i64, ptr %slot1353, align 8
  %op7749 = sub i64 %v7748, 32
  store i64 %op7749, ptr %slot1359, align 8
  %v7750 = load i64, ptr %slot1353, align 8
  %p7751 = inttoptr i64 %v7750 to ptr
  %rgep7752 = getelementptr i8, ptr %p7751, i64 -32
  %ld7753 = load i64, ptr %rgep7752, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7753, ptr %slot1360, align 8
  %v7754 = load i64, ptr %slot1360, align 8
  %op7755 = sub i64 %v7754, 1
  store i64 %op7755, ptr %slot1361, align 8
  %v7756 = load i64, ptr %slot1361, align 8
  %cmp7757 = icmp eq i64 %v7756, 0
  %cv7758 = zext i1 %cmp7757 to i32
  store i32 %cv7758, ptr %slot1362, align 8
  %v7759 = load i32, ptr %slot1362, align 8
  %cv7760 = zext i32 %v7759 to i64
  %cond7761 = icmp ne i64 %cv7760, 0
  br i1 %cond7761, label %bb_rcglast2294, label %bb_rcgdec2294
bb_rcglast2294:
  %v7762 = load i64, ptr %slot1353, align 8
  %op7763 = sub i64 %v7762, 24
  store i64 %op7763, ptr %slot1363, align 8
  %v7764 = load i64, ptr %slot1353, align 8
  %p7765 = inttoptr i64 %v7764 to ptr
  %rgep7766 = getelementptr i8, ptr %p7765, i64 -24
  %ld7767 = load i64, ptr %rgep7766, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7767, ptr %slot1364, align 8
  %v7768 = load i64, ptr %slot1364, align 8
  %cmp7769 = icmp ne i64 %v7768, 0
  %cv7770 = zext i1 %cmp7769 to i32
  store i32 %cv7770, ptr %slot1365, align 8
  %v7771 = load i32, ptr %slot1365, align 8
  %cv7772 = zext i32 %v7771 to i64
  %cond7773 = icmp ne i64 %cv7772, 0
  br i1 %cond7773, label %bb_rcgdec2294, label %bb_rcgslow2294
bb_rcgslow2294:
  %v7774 = load i64, ptr %slot1352, align 8
  %v7775 = load i64, ptr %slot1335, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v7774, i64 %v7775) nomerge, !dbg !190
  br label %bb_rcgdone2294
bb_rcgdec2294:
  %v7776 = load i64, ptr %slot1361, align 8
  %v7777 = load i64, ptr %slot1353, align 8
  %p7778 = inttoptr i64 %v7777 to ptr
  %rgep7779 = getelementptr i8, ptr %p7778, i64 -32
  store i64 %v7776, ptr %rgep7779, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2294
bb_rcgclear2294:
  %v7780 = load i64, ptr %slot1335, align 8
  %p7781 = inttoptr i64 %v7780 to ptr
  store i64 0, ptr %p7781, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2294
bb_rcgdone2294:
  br label %bb_rcslotdone2263
bb_rcslotdone2263:
  %v7782 = load i64, ptr %slot1333, align 8
  %op7783 = add i64 %v7782, 32
  store i64 %op7783, ptr %slot1366, align 8
  %v7784 = load i64, ptr %slot1366, align 8
  %op7785 = add i64 %v7784, 0
  store i64 %op7785, ptr %slot1367, align 8
  store i64 0, ptr %slot1368, align 8
  %v7786 = load i64, ptr %slot1367, align 8
  %p7787 = inttoptr i64 %v7786 to ptr
  %ld7788 = load i64, ptr %p7787, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7788, ptr %slot1369, align 8
  %v7789 = load i64, ptr %slot1369, align 8
  %cmp7790 = icmp ne i64 %v7789, 0
  %cv7791 = zext i1 %cmp7790 to i32
  store i32 %cv7791, ptr %slot1370, align 8
  %v7792 = load i32, ptr %slot1370, align 8
  %cv7793 = zext i32 %v7792 to i64
  %cond7794 = icmp ne i64 %cv7793, 0
  br i1 %cond7794, label %bb_rcguniquenn2301, label %bb_rcgunique2301
bb_rcguniquenn2301:
  %v7795 = load i64, ptr %slot1369, align 8
  %op7796 = sub i64 %v7795, 16
  store i64 %op7796, ptr %slot1371, align 8
  %v7797 = load i64, ptr %slot1369, align 8
  %p7798 = inttoptr i64 %v7797 to ptr
  %rgep7799 = getelementptr i8, ptr %p7798, i64 -16
  %ld7800 = load i64, ptr %rgep7799, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7800, ptr %slot1372, align 8
  %v7801 = load i64, ptr %slot1372, align 8
  %op7802 = and i64 %v7801, 6917529027641081858
  store i64 %op7802, ptr %slot1373, align 8
  %v7803 = load i64, ptr %slot1373, align 8
  %cmp7804 = icmp ne i64 %v7803, 0
  %cv7805 = zext i1 %cmp7804 to i32
  store i32 %cv7805, ptr %slot1374, align 8
  %v7806 = load i32, ptr %slot1374, align 8
  %cv7807 = zext i32 %v7806 to i64
  %cond7808 = icmp ne i64 %cv7807, 0
  br i1 %cond7808, label %bb_rcguniqueslow2301, label %bb_rcguniquecount2301
bb_rcguniquecount2301:
  %v7809 = load i64, ptr %slot1369, align 8
  %op7810 = sub i64 %v7809, 32
  store i64 %op7810, ptr %slot1375, align 8
  %v7811 = load i64, ptr %slot1369, align 8
  %p7812 = inttoptr i64 %v7811 to ptr
  %rgep7813 = getelementptr i8, ptr %p7812, i64 -32
  %ld7814 = load i64, ptr %rgep7813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7814, ptr %slot1376, align 8
  %v7815 = load i64, ptr %slot1376, align 8
  %cmp7816 = icmp ult i64 %v7815, 2
  %cv7817 = zext i1 %cmp7816 to i32
  store i32 %cv7817, ptr %slot1377, align 8
  %v7818 = load i32, ptr %slot1377, align 8
  %cv7819 = zext i32 %v7818 to i64
  %cond7820 = icmp ne i64 %cv7819, 0
  br i1 %cond7820, label %bb_rcgunique2301, label %bb_rcguniqueslow2301
bb_rcguniqueslow2301:
  %v7821 = load i64, ptr %slot1, align 8
  %p7822 = inttoptr i64 %v7821 to ptr
  %p7823 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v7824 = load i64, ptr %slot1367, align 8
  %p7825 = inttoptr i64 %v7824 to ptr
  %v7826 = load i64, ptr %slot1368, align 8
  %p7827 = inttoptr i64 %v7826 to ptr
  %call7828 = call i32 @myl_qbe_rc_unique_field(ptr %p7822, ptr %p7823, ptr %p7825, ptr %p7827) nomerge, !dbg !190
  store i32 %call7828, ptr %slot1378, align 8
  %v7829 = load i32, ptr %slot1378, align 8
  %cv7830 = zext i32 %v7829 to i64
  %cond7831 = icmp ne i64 %cv7830, 0
  br i1 %cond7831, label %bb_rcunique2311, label %bb_failure
bb_rcunique2311:
  br label %bb_rcgunique2301
bb_rcgunique2301:
  %v7832 = load i64, ptr %slot1367, align 8
  %p7833 = inttoptr i64 %v7832 to ptr
  %ld7834 = load i64, ptr %p7833, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7834, ptr %slot1379, align 8
  %v7835 = load i64, ptr %slot1379, align 8
  %v7836 = load i64, ptr %slot52, align 8
  %p7837 = inttoptr i64 %v7836 to ptr
  store i64 %v7835, ptr %p7837, align 8, !alias.scope !3, !noalias !4
  %v7838 = load i64, ptr %slot52, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  %ld7840 = load i64, ptr %p7839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7840, ptr %slot1380, align 8
  %v7841 = load i64, ptr %slot24, align 8
  %p7842 = inttoptr i64 %v7841 to ptr
  %ld7843 = load i32, ptr %p7842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7843, ptr %slot1381, align 8
  %v7844 = load i32, ptr %slot1381, align 8
  %cv7845 = zext i32 %v7844 to i64
  %cond7846 = icmp ne i64 %cv7845, 0
  br i1 %cond7846, label %bb_rcslotdrop2316, label %bb_rcslotdone2316
bb_rcslotdrop2316:
  %v7847 = load i64, ptr %slot24, align 8
  %p7848 = inttoptr i64 %v7847 to ptr
  store i32 0, ptr %p7848, align 4, !alias.scope !3, !noalias !4
  %v7849 = load i64, ptr %slot30, align 8
  store i64 %v7849, ptr %slot1382, align 8
  %v7850 = load i64, ptr %slot25, align 8
  %p7851 = inttoptr i64 %v7850 to ptr
  %ld7852 = load i32, ptr %p7851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7852, ptr %slot1383, align 8
  %v7853 = load i32, ptr %slot1383, align 8
  %op7854 = and i32 %v7853, 28
  store i32 %op7854, ptr %slot1384, align 8
  %v7855 = load i32, ptr %slot1384, align 8
  %cv7856 = zext i32 %v7855 to i64
  %cond7857 = icmp ne i64 %cv7856, 0
  br i1 %cond7857, label %bb_rcslotrole2316, label %bb_rcslotowner2316
bb_rcslotrole2316:
  %v7858 = load i64, ptr %slot73, align 8
  store i64 %v7858, ptr %slot1385, align 8
  %v7859 = load i64, ptr %slot1382, align 8
  %p7860 = inttoptr i64 %v7859 to ptr
  %ld7861 = load i64, ptr %p7860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7861, ptr %slot1386, align 8
  %v7862 = load i64, ptr %slot1386, align 8
  %cmp7863 = icmp ne i64 %v7862, 0
  %cv7864 = zext i1 %cmp7863 to i32
  store i32 %cv7864, ptr %slot1387, align 8
  %v7865 = load i32, ptr %slot1387, align 8
  %cv7866 = zext i32 %v7865 to i64
  %cond7867 = icmp ne i64 %cv7866, 0
  br i1 %cond7867, label %bb_rcgnn2332, label %bb_rcgdone2332
bb_rcgnn2332:
  %v7868 = load i64, ptr %slot1386, align 8
  %op7869 = sub i64 %v7868, 16
  store i64 %op7869, ptr %slot1388, align 8
  %v7870 = load i64, ptr %slot1386, align 8
  %p7871 = inttoptr i64 %v7870 to ptr
  %rgep7872 = getelementptr i8, ptr %p7871, i64 -16
  %ld7873 = load i64, ptr %rgep7872, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7873, ptr %slot1389, align 8
  %v7874 = load i64, ptr %slot1389, align 8
  %op7875 = and i64 %v7874, 4611686018427387906
  store i64 %op7875, ptr %slot1390, align 8
  %v7876 = load i64, ptr %slot1390, align 8
  %cmp7877 = icmp ne i64 %v7876, 0
  %cv7878 = zext i1 %cmp7877 to i32
  store i32 %cv7878, ptr %slot1391, align 8
  %v7879 = load i32, ptr %slot1391, align 8
  %cv7880 = zext i32 %v7879 to i64
  %cond7881 = icmp ne i64 %cv7880, 0
  br i1 %cond7881, label %bb_rcgclear2332, label %bb_rcgcounted2332
bb_rcgcounted2332:
  %v7882 = load i64, ptr %slot1386, align 8
  %op7883 = sub i64 %v7882, 24
  store i64 %op7883, ptr %slot1392, align 8
  %v7884 = load i64, ptr %slot1386, align 8
  %p7885 = inttoptr i64 %v7884 to ptr
  %rgep7886 = getelementptr i8, ptr %p7885, i64 -24
  %ld7887 = load i64, ptr %rgep7886, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7887, ptr %slot1393, align 8
  %v7888 = load i64, ptr %slot1393, align 8
  %op7889 = sub i64 %v7888, 1
  store i64 %op7889, ptr %slot1394, align 8
  %v7890 = load i64, ptr %slot1394, align 8
  %cmp7891 = icmp eq i64 %v7890, 0
  %cv7892 = zext i1 %cmp7891 to i32
  store i32 %cv7892, ptr %slot1395, align 8
  %v7893 = load i32, ptr %slot1395, align 8
  %cv7894 = zext i32 %v7893 to i64
  %cond7895 = icmp ne i64 %cv7894, 0
  br i1 %cond7895, label %bb_rcglast2332, label %bb_rcgdec2332
bb_rcglast2332:
  %v7896 = load i64, ptr %slot1386, align 8
  %op7897 = sub i64 %v7896, 32
  store i64 %op7897, ptr %slot1396, align 8
  %v7898 = load i64, ptr %slot1386, align 8
  %p7899 = inttoptr i64 %v7898 to ptr
  %rgep7900 = getelementptr i8, ptr %p7899, i64 -32
  %ld7901 = load i64, ptr %rgep7900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7901, ptr %slot1397, align 8
  %v7902 = load i64, ptr %slot1397, align 8
  %cmp7903 = icmp ne i64 %v7902, 0
  %cv7904 = zext i1 %cmp7903 to i32
  store i32 %cv7904, ptr %slot1398, align 8
  %v7905 = load i32, ptr %slot1398, align 8
  %cv7906 = zext i32 %v7905 to i64
  %cond7907 = icmp ne i64 %cv7906, 0
  br i1 %cond7907, label %bb_rcgdec2332, label %bb_rcgslow2332
bb_rcgslow2332:
  %v7908 = load i64, ptr %slot1385, align 8
  %v7909 = load i64, ptr %slot1382, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v7908, i64 %v7909) nomerge, !dbg !190
  br label %bb_rcgdone2332
bb_rcgdec2332:
  %v7910 = load i64, ptr %slot1394, align 8
  %v7911 = load i64, ptr %slot1386, align 8
  %p7912 = inttoptr i64 %v7911 to ptr
  %rgep7913 = getelementptr i8, ptr %p7912, i64 -24
  store i64 %v7910, ptr %rgep7913, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2332
bb_rcgclear2332:
  %v7914 = load i64, ptr %slot1382, align 8
  %p7915 = inttoptr i64 %v7914 to ptr
  store i64 0, ptr %p7915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2332
bb_rcgdone2332:
  br label %bb_rcslotdone2316
bb_rcslotowner2316:
  %v7916 = load i64, ptr %slot73, align 8
  store i64 %v7916, ptr %slot1399, align 8
  %v7917 = load i64, ptr %slot1382, align 8
  %p7918 = inttoptr i64 %v7917 to ptr
  %ld7919 = load i64, ptr %p7918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7919, ptr %slot1400, align 8
  %v7920 = load i64, ptr %slot1400, align 8
  %cmp7921 = icmp ne i64 %v7920, 0
  %cv7922 = zext i1 %cmp7921 to i32
  store i32 %cv7922, ptr %slot1401, align 8
  %v7923 = load i32, ptr %slot1401, align 8
  %cv7924 = zext i32 %v7923 to i64
  %cond7925 = icmp ne i64 %cv7924, 0
  br i1 %cond7925, label %bb_rcgnn2347, label %bb_rcgdone2347
bb_rcgnn2347:
  %v7926 = load i64, ptr %slot1400, align 8
  %op7927 = sub i64 %v7926, 16
  store i64 %op7927, ptr %slot1402, align 8
  %v7928 = load i64, ptr %slot1400, align 8
  %p7929 = inttoptr i64 %v7928 to ptr
  %rgep7930 = getelementptr i8, ptr %p7929, i64 -16
  %ld7931 = load i64, ptr %rgep7930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7931, ptr %slot1403, align 8
  %v7932 = load i64, ptr %slot1403, align 8
  %op7933 = and i64 %v7932, 4611686018427387906
  store i64 %op7933, ptr %slot1404, align 8
  %v7934 = load i64, ptr %slot1404, align 8
  %cmp7935 = icmp ne i64 %v7934, 0
  %cv7936 = zext i1 %cmp7935 to i32
  store i32 %cv7936, ptr %slot1405, align 8
  %v7937 = load i32, ptr %slot1405, align 8
  %cv7938 = zext i32 %v7937 to i64
  %cond7939 = icmp ne i64 %cv7938, 0
  br i1 %cond7939, label %bb_rcgclear2347, label %bb_rcgcounted2347
bb_rcgcounted2347:
  %v7940 = load i64, ptr %slot1400, align 8
  %op7941 = sub i64 %v7940, 32
  store i64 %op7941, ptr %slot1406, align 8
  %v7942 = load i64, ptr %slot1400, align 8
  %p7943 = inttoptr i64 %v7942 to ptr
  %rgep7944 = getelementptr i8, ptr %p7943, i64 -32
  %ld7945 = load i64, ptr %rgep7944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7945, ptr %slot1407, align 8
  %v7946 = load i64, ptr %slot1407, align 8
  %op7947 = sub i64 %v7946, 1
  store i64 %op7947, ptr %slot1408, align 8
  %v7948 = load i64, ptr %slot1408, align 8
  %cmp7949 = icmp eq i64 %v7948, 0
  %cv7950 = zext i1 %cmp7949 to i32
  store i32 %cv7950, ptr %slot1409, align 8
  %v7951 = load i32, ptr %slot1409, align 8
  %cv7952 = zext i32 %v7951 to i64
  %cond7953 = icmp ne i64 %cv7952, 0
  br i1 %cond7953, label %bb_rcglast2347, label %bb_rcgdec2347
bb_rcglast2347:
  %v7954 = load i64, ptr %slot1400, align 8
  %op7955 = sub i64 %v7954, 24
  store i64 %op7955, ptr %slot1410, align 8
  %v7956 = load i64, ptr %slot1400, align 8
  %p7957 = inttoptr i64 %v7956 to ptr
  %rgep7958 = getelementptr i8, ptr %p7957, i64 -24
  %ld7959 = load i64, ptr %rgep7958, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7959, ptr %slot1411, align 8
  %v7960 = load i64, ptr %slot1411, align 8
  %cmp7961 = icmp ne i64 %v7960, 0
  %cv7962 = zext i1 %cmp7961 to i32
  store i32 %cv7962, ptr %slot1412, align 8
  %v7963 = load i32, ptr %slot1412, align 8
  %cv7964 = zext i32 %v7963 to i64
  %cond7965 = icmp ne i64 %cv7964, 0
  br i1 %cond7965, label %bb_rcgdec2347, label %bb_rcgslow2347
bb_rcgslow2347:
  %v7966 = load i64, ptr %slot1399, align 8
  %v7967 = load i64, ptr %slot1382, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v7966, i64 %v7967) nomerge, !dbg !190
  br label %bb_rcgdone2347
bb_rcgdec2347:
  %v7968 = load i64, ptr %slot1408, align 8
  %v7969 = load i64, ptr %slot1400, align 8
  %p7970 = inttoptr i64 %v7969 to ptr
  %rgep7971 = getelementptr i8, ptr %p7970, i64 -32
  store i64 %v7968, ptr %rgep7971, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2347
bb_rcgclear2347:
  %v7972 = load i64, ptr %slot1382, align 8
  %p7973 = inttoptr i64 %v7972 to ptr
  store i64 0, ptr %p7973, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2347
bb_rcgdone2347:
  br label %bb_rcslotdone2316
bb_rcslotdone2316:
  %v7974 = load i64, ptr %slot33, align 8
  store i64 %v7974, ptr %slot1413, align 8
  %v7975 = load i64, ptr %slot73, align 8
  %v7976 = load i64, ptr %slot1413, align 8
  %p7977 = inttoptr i64 %v7976 to ptr
  store i64 %v7975, ptr %p7977, align 8, !alias.scope !3, !noalias !4
  %v7978 = load i64, ptr %slot73, align 8
  %p7980 = inttoptr i64 %v7978 to ptr
  %gep7981 = getelementptr i8, ptr %p7980, i64 5640
  %op7979 = ptrtoint ptr %gep7981 to i64
  store i64 %op7979, ptr %slot1414, align 8
  %v7982 = load i64, ptr %slot1414, align 8
  %p7983 = inttoptr i64 %v7982 to ptr
  %ld7984 = load i64, ptr %p7983, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7984, ptr %slot1415, align 8
  %v7985 = load i64, ptr %slot1415, align 8
  %op7986 = add i64 %v7985, 248
  store i64 %op7986, ptr %slot1416, align 8
  %v7987 = load i64, ptr %slot1416, align 8
  %p7988 = inttoptr i64 %v7987 to ptr
  %ld7989 = load i64, ptr %p7988, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7989, ptr %slot1417, align 8
  %v7990 = load i64, ptr %slot1413, align 8
  %p7992 = inttoptr i64 %v7990 to ptr
  %gep7993 = getelementptr i8, ptr %p7992, i64 8
  %op7991 = ptrtoint ptr %gep7993 to i64
  store i64 %op7991, ptr %slot1418, align 8
  %v7994 = load i64, ptr %slot1417, align 8
  %v7995 = load i64, ptr %slot1418, align 8
  %p7996 = inttoptr i64 %v7995 to ptr
  store i64 %v7994, ptr %p7996, align 8, !alias.scope !3, !noalias !4
  %v7997 = load i64, ptr %slot1413, align 8
  %p7999 = inttoptr i64 %v7997 to ptr
  %gep8000 = getelementptr i8, ptr %p7999, i64 16
  %op7998 = ptrtoint ptr %gep8000 to i64
  store i64 %op7998, ptr %slot1419, align 8
  %v8001 = load i64, ptr %slot1419, align 8
  %p8002 = inttoptr i64 %v8001 to ptr
  store i64 0, ptr %p8002, align 8, !alias.scope !3, !noalias !4
  %v8003 = load i64, ptr %slot73, align 8
  %p8005 = inttoptr i64 %v8003 to ptr
  %gep8006 = getelementptr i8, ptr %p8005, i64 112
  %op8004 = ptrtoint ptr %gep8006 to i64
  store i64 %op8004, ptr %slot1420, align 8
  %v8007 = load i64, ptr %slot1413, align 8
  %p8009 = inttoptr i64 %v8007 to ptr
  %gep8010 = getelementptr i8, ptr %p8009, i64 24
  %op8008 = ptrtoint ptr %gep8010 to i64
  store i64 %op8008, ptr %slot1421, align 8
  %v8011 = load i64, ptr %slot1413, align 8
  %p8013 = inttoptr i64 %v8011 to ptr
  %gep8014 = getelementptr i8, ptr %p8013, i64 28
  %op8012 = ptrtoint ptr %gep8014 to i64
  store i64 %op8012, ptr %slot1422, align 8
  %v8015 = load i64, ptr %slot1420, align 8
  %p8016 = inttoptr i64 %v8015 to ptr
  %ld8017 = load i32, ptr %p8016, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld8017, ptr %slot1423, align 8
  %v8018 = load i64, ptr %slot1421, align 8
  %p8019 = inttoptr i64 %v8018 to ptr
  store i32 1, ptr %p8019, align 4, !alias.scope !3, !noalias !4
  %v8020 = load i32, ptr %slot1423, align 8
  %v8021 = load i64, ptr %slot1422, align 8
  %p8022 = inttoptr i64 %v8021 to ptr
  store i32 %v8020, ptr %p8022, align 4, !alias.scope !3, !noalias !4
  %v8023 = load i64, ptr %slot1413, align 8
  %v8024 = load i64, ptr %slot1416, align 8
  %p8025 = inttoptr i64 %v8024 to ptr
  store i64 %v8023, ptr %p8025, align 8, !alias.scope !9999998, !noalias !9999999
  %v8026 = load i64, ptr %slot1380, align 8
  %cmp8027 = icmp ne i64 %v8026, 0
  %cv8028 = zext i1 %cmp8027 to i32
  store i32 %cv8028, ptr %slot1424, align 8
  %v8029 = load i32, ptr %slot1424, align 8
  %cv8030 = zext i32 %v8029 to i64
  %cond8031 = icmp ne i64 %cv8030, 0
  br i1 %cond8031, label %bb_rcspinmark2399, label %bb_rcspindone2399
bb_rcspinmark2399:
  %v8032 = load i64, ptr %slot1380, align 8
  %op8033 = sub i64 %v8032, 16
  store i64 %op8033, ptr %slot1425, align 8
  %v8034 = load i64, ptr %slot1380, align 8
  %p8035 = inttoptr i64 %v8034 to ptr
  %rgep8036 = getelementptr i8, ptr %p8035, i64 -16
  %ld8037 = load i64, ptr %rgep8036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8037, ptr %slot1426, align 8
  %v8038 = load i64, ptr %slot1426, align 8
  %op8039 = and i64 %v8038, 2
  store i64 %op8039, ptr %slot1427, align 8
  %v8040 = load i64, ptr %slot1427, align 8
  %cmp8041 = icmp ne i64 %v8040, 0
  %cv8042 = zext i1 %cmp8041 to i32
  store i32 %cv8042, ptr %slot1428, align 8
  %v8043 = load i32, ptr %slot1428, align 8
  %cv8044 = zext i32 %v8043 to i64
  %cond8045 = icmp ne i64 %cv8044, 0
  br i1 %cond8045, label %bb_rcspindone2399, label %bb_rcspintype2399
bb_rcspintype2399:
  %v8046 = load i64, ptr %slot1426, align 8
  %op8047 = and i64 %v8046, 4611686018427387907
  store i64 %op8047, ptr %slot1429, align 8
  %v8048 = load i64, ptr %slot1429, align 8
  %cmp8049 = icmp eq i64 %v8048, 0
  %cv8050 = zext i1 %cmp8049 to i32
  store i32 %cv8050, ptr %slot1430, align 8
  %v8051 = load i32, ptr %slot1430, align 8
  %cv8052 = zext i32 %v8051 to i64
  %cond8053 = icmp ne i64 %cv8052, 0
  br i1 %cond8053, label %bb_rcs2407, label %bb_rcspinslow2399
bb_rcs2407:
  %v8054 = load i64, ptr %slot1380, align 8
  %op8055 = sub i64 %v8054, 8
  store i64 %op8055, ptr %slot1431, align 8
  %v8056 = load i64, ptr %slot1380, align 8
  %p8057 = inttoptr i64 %v8056 to ptr
  %rgep8058 = getelementptr i8, ptr %p8057, i64 -8
  %ld8059 = load i64, ptr %rgep8058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8059, ptr %slot1432, align 8
  %p8060 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld8061 = load i64, ptr %p8060, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8061, ptr %slot1433, align 8
  %v8062 = load i64, ptr %slot1432, align 8
  %v8063 = load i64, ptr %slot1433, align 8
  %cmp8064 = icmp eq i64 %v8062, %v8063
  %cv8065 = zext i1 %cmp8064 to i32
  store i32 %cv8065, ptr %slot1434, align 8
  %v8066 = load i32, ptr %slot1434, align 8
  %cv8067 = zext i32 %v8066 to i64
  %cond8068 = icmp ne i64 %cv8067, 0
  br i1 %cond8068, label %bb_rcs2412, label %bb_rcspinslow2399
bb_rcs2412:
  %v8069 = load i64, ptr %slot73, align 8
  %p8071 = inttoptr i64 %v8069 to ptr
  %gep8072 = getelementptr i8, ptr %p8071, i64 5640
  %op8070 = ptrtoint ptr %gep8072 to i64
  store i64 %op8070, ptr %slot1435, align 8
  %v8073 = load i64, ptr %slot1435, align 8
  %p8074 = inttoptr i64 %v8073 to ptr
  %ld8075 = load i64, ptr %p8074, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8075, ptr %slot1436, align 8
  %v8076 = load i64, ptr %slot1436, align 8
  %op8077 = add i64 %v8076, 256
  store i64 %op8077, ptr %slot1437, align 8
  %v8078 = load i64, ptr %slot1437, align 8
  %p8079 = inttoptr i64 %v8078 to ptr
  %ld8080 = load i64, ptr %p8079, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8080, ptr %slot1438, align 8
  %v8081 = load i64, ptr %slot1438, align 8
  %cmp8082 = icmp ne i64 %v8081, 0
  %cv8083 = zext i1 %cmp8082 to i32
  store i32 %cv8083, ptr %slot1439, align 8
  %v8084 = load i32, ptr %slot1439, align 8
  %cv8085 = zext i32 %v8084 to i64
  %cond8086 = icmp ne i64 %cv8085, 0
  br i1 %cond8086, label %bb_rcs2418, label %bb_rcspinslow2399
bb_rcs2418:
  %v8087 = load i64, ptr %slot73, align 8
  %p8089 = inttoptr i64 %v8087 to ptr
  %gep8090 = getelementptr i8, ptr %p8089, i64 24
  %op8088 = ptrtoint ptr %gep8090 to i64
  store i64 %op8088, ptr %slot1440, align 8
  %v8091 = load i64, ptr %slot1440, align 8
  %p8092 = inttoptr i64 %v8091 to ptr
  %ld8093 = load i64, ptr %p8092, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8093, ptr %slot1441, align 8
  %v8094 = load i64, ptr %slot1441, align 8
  %op8095 = add i64 %v8094, 40
  store i64 %op8095, ptr %slot1442, align 8
  %v8096 = load i64, ptr %slot1442, align 8
  %v8097 = load i64, ptr %slot1441, align 8
  %cmp8098 = icmp uge i64 %v8096, %v8097
  %cv8099 = zext i1 %cmp8098 to i32
  store i32 %cv8099, ptr %slot1443, align 8
  %v8100 = load i32, ptr %slot1443, align 8
  %cv8101 = zext i32 %v8100 to i64
  %cond8102 = icmp ne i64 %cv8101, 0
  br i1 %cond8102, label %bb_rcs2423, label %bb_rcspinslow2399
bb_rcs2423:
  %v8103 = load i64, ptr %slot73, align 8
  %p8105 = inttoptr i64 %v8103 to ptr
  %gep8106 = getelementptr i8, ptr %p8105, i64 88
  %op8104 = ptrtoint ptr %gep8106 to i64
  store i64 %op8104, ptr %slot1444, align 8
  %v8107 = load i64, ptr %slot1444, align 8
  %p8108 = inttoptr i64 %v8107 to ptr
  %ld8109 = load i64, ptr %p8108, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8109, ptr %slot1445, align 8
  %v8110 = load i64, ptr %slot1445, align 8
  %cmp8111 = icmp eq i64 %v8110, 0
  %cv8112 = zext i1 %cmp8111 to i32
  store i32 %cv8112, ptr %slot1446, align 8
  %v8113 = load i64, ptr %slot1442, align 8
  %v8114 = load i64, ptr %slot1445, align 8
  %cmp8115 = icmp ule i64 %v8113, %v8114
  %cv8116 = zext i1 %cmp8115 to i32
  store i32 %cv8116, ptr %slot1447, align 8
  %v8117 = load i32, ptr %slot1446, align 8
  %v8118 = load i32, ptr %slot1447, align 8
  %op8119 = or i32 %v8117, %v8118
  store i32 %op8119, ptr %slot1448, align 8
  %v8120 = load i32, ptr %slot1448, align 8
  %cv8121 = zext i32 %v8120 to i64
  %cond8122 = icmp ne i64 %cv8121, 0
  br i1 %cond8122, label %bb_rcs2429, label %bb_rcspinslow2399
bb_rcs2429:
  %v8123 = load i64, ptr %slot1380, align 8
  %op8124 = sub i64 %v8123, 24
  store i64 %op8124, ptr %slot1449, align 8
  %v8125 = load i64, ptr %slot1380, align 8
  %p8126 = inttoptr i64 %v8125 to ptr
  %rgep8127 = getelementptr i8, ptr %p8126, i64 -24
  %ld8128 = load i64, ptr %rgep8127, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8128, ptr %slot1450, align 8
  %v8129 = load i64, ptr %slot1450, align 8
  %cmp8130 = icmp ne i64 %v8129, 18446744073709551615
  %cv8131 = zext i1 %cmp8130 to i32
  store i32 %cv8131, ptr %slot1451, align 8
  %v8132 = load i32, ptr %slot1451, align 8
  %cv8133 = zext i32 %v8132 to i64
  %cond8134 = icmp ne i64 %cv8133, 0
  br i1 %cond8134, label %bb_rcs2433, label %bb_rcspinslow2399
bb_rcs2433:
  %v8135 = load i64, ptr %slot1380, align 8
  %op8136 = add i64 %v8135, 32
  store i64 %op8136, ptr %slot1452, align 8
  %v8137 = load i64, ptr %slot1452, align 8
  %p8138 = inttoptr i64 %v8137 to ptr
  %ld8139 = load i64, ptr %p8138, align 8
  store i64 %ld8139, ptr %slot1453, align 8
  %v8140 = load i64, ptr %slot1453, align 8
  %cmp8141 = icmp ne i64 %v8140, 0
  %cv8142 = zext i1 %cmp8141 to i32
  store i32 %cv8142, ptr %slot1454, align 8
  %v8143 = load i32, ptr %slot1454, align 8
  %cv8144 = zext i32 %v8143 to i64
  %cond8145 = icmp ne i64 %cv8144, 0
  br i1 %cond8145, label %bb_rcspinbacking2399, label %bb_rcspincommit2399
bb_rcspinbacking2399:
  %v8146 = load i64, ptr %slot1453, align 8
  %op8147 = sub i64 %v8146, 16
  store i64 %op8147, ptr %slot1455, align 8
  %v8148 = load i64, ptr %slot1453, align 8
  %p8149 = inttoptr i64 %v8148 to ptr
  %rgep8150 = getelementptr i8, ptr %p8149, i64 -16
  %ld8151 = load i64, ptr %rgep8150, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8151, ptr %slot1456, align 8
  %v8152 = load i64, ptr %slot1456, align 8
  %op8153 = and i64 %v8152, 4611686018427387907
  store i64 %op8153, ptr %slot1457, align 8
  %v8154 = load i64, ptr %slot1457, align 8
  %cmp8155 = icmp eq i64 %v8154, 0
  %cv8156 = zext i1 %cmp8155 to i32
  store i32 %cv8156, ptr %slot1458, align 8
  %v8157 = load i32, ptr %slot1458, align 8
  %cv8158 = zext i32 %v8157 to i64
  %cond8159 = icmp ne i64 %cv8158, 0
  br i1 %cond8159, label %bb_rcs2441, label %bb_rcspinslow2399
bb_rcs2441:
  %v8160 = load i64, ptr %slot1453, align 8
  %op8161 = sub i64 %v8160, 24
  store i64 %op8161, ptr %slot1459, align 8
  %v8162 = load i64, ptr %slot1453, align 8
  %p8163 = inttoptr i64 %v8162 to ptr
  %rgep8164 = getelementptr i8, ptr %p8163, i64 -24
  %ld8165 = load i64, ptr %rgep8164, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8165, ptr %slot1460, align 8
  %v8166 = load i64, ptr %slot1460, align 8
  %cmp8167 = icmp ne i64 %v8166, 18446744073709551615
  %cv8168 = zext i1 %cmp8167 to i32
  store i32 %cv8168, ptr %slot1461, align 8
  %v8169 = load i32, ptr %slot1461, align 8
  %cv8170 = zext i32 %v8169 to i64
  %cond8171 = icmp ne i64 %cv8170, 0
  br i1 %cond8171, label %bb_rcs2445, label %bb_rcspinslow2399
bb_rcs2445:
  br label %bb_rcspincommit2399
bb_rcspincommit2399:
  %v8172 = load i64, ptr %slot1438, align 8
  %p8173 = inttoptr i64 %v8172 to ptr
  %ld8174 = load i64, ptr %p8173, align 8
  store i64 %ld8174, ptr %slot1462, align 8
  %v8175 = load i64, ptr %slot1436, align 8
  %op8176 = add i64 %v8175, 256
  store i64 %op8176, ptr %slot1463, align 8
  %v8177 = load i64, ptr %slot1462, align 8
  %v8178 = load i64, ptr %slot1463, align 8
  %p8179 = inttoptr i64 %v8178 to ptr
  store i64 %v8177, ptr %p8179, align 8, !alias.scope !9999998, !noalias !9999999
  %v8180 = load i64, ptr %slot1436, align 8
  %op8181 = add i64 %v8180, 264
  store i64 %op8181, ptr %slot1464, align 8
  %v8182 = load i64, ptr %slot1464, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  %ld8184 = load i64, ptr %p8183, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8184, ptr %slot1465, align 8
  %v8185 = load i64, ptr %slot1465, align 8
  %op8186 = add i64 %v8185, 18446744073709551615
  store i64 %op8186, ptr %slot1466, align 8
  %v8187 = load i64, ptr %slot1466, align 8
  %v8188 = load i64, ptr %slot1464, align 8
  %p8189 = inttoptr i64 %v8188 to ptr
  store i64 %v8187, ptr %p8189, align 8, !alias.scope !9999998, !noalias !9999999
  %v8190 = load i64, ptr %slot73, align 8
  %p8192 = inttoptr i64 %v8190 to ptr
  %gep8193 = getelementptr i8, ptr %p8192, i64 24
  %op8191 = ptrtoint ptr %gep8193 to i64
  store i64 %op8191, ptr %slot1467, align 8
  %v8194 = load i64, ptr %slot1467, align 8
  %p8195 = inttoptr i64 %v8194 to ptr
  %ld8196 = load i64, ptr %p8195, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8196, ptr %slot1468, align 8
  %v8197 = load i64, ptr %slot1468, align 8
  %op8198 = add i64 %v8197, 40
  store i64 %op8198, ptr %slot1469, align 8
  %v8199 = load i64, ptr %slot1469, align 8
  %v8200 = load i64, ptr %slot1467, align 8
  %p8201 = inttoptr i64 %v8200 to ptr
  store i64 %v8199, ptr %p8201, align 8, !alias.scope !9999998, !noalias !9999999
  %v8202 = load i64, ptr %slot1436, align 8
  %op8203 = add i64 %v8202, 48
  store i64 %op8203, ptr %slot1470, align 8
  %v8204 = load i64, ptr %slot1470, align 8
  %p8205 = inttoptr i64 %v8204 to ptr
  %ld8206 = load i64, ptr %p8205, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8206, ptr %slot1471, align 8
  %v8207 = load i64, ptr %slot1471, align 8
  %op8208 = add i64 %v8207, 40
  store i64 %op8208, ptr %slot1472, align 8
  %v8209 = load i64, ptr %slot1472, align 8
  %v8210 = load i64, ptr %slot1470, align 8
  %p8211 = inttoptr i64 %v8210 to ptr
  store i64 %v8209, ptr %p8211, align 8, !alias.scope !9999998, !noalias !9999999
  %v8212 = load i64, ptr %slot1380, align 8
  %op8213 = sub i64 %v8212, 24
  store i64 %op8213, ptr %slot1473, align 8
  %v8214 = load i64, ptr %slot1380, align 8
  %p8215 = inttoptr i64 %v8214 to ptr
  %rgep8216 = getelementptr i8, ptr %p8215, i64 -24
  %ld8217 = load i64, ptr %rgep8216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8217, ptr %slot1474, align 8
  %v8218 = load i64, ptr %slot1474, align 8
  %op8219 = add i64 %v8218, 1
  store i64 %op8219, ptr %slot1475, align 8
  %v8220 = load i64, ptr %slot1475, align 8
  %v8221 = load i64, ptr %slot1380, align 8
  %p8222 = inttoptr i64 %v8221 to ptr
  %rgep8223 = getelementptr i8, ptr %p8222, i64 -24
  store i64 %v8220, ptr %rgep8223, align 8, !alias.scope !9, !noalias !10
  %v8224 = load i64, ptr %slot1453, align 8
  %cmp8225 = icmp ne i64 %v8224, 0
  %cv8226 = zext i1 %cmp8225 to i32
  store i32 %cv8226, ptr %slot1476, align 8
  %v8227 = load i32, ptr %slot1476, align 8
  %cv8228 = zext i32 %v8227 to i64
  %cond8229 = icmp ne i64 %cv8228, 0
  br i1 %cond8229, label %bb_rcspinhold2399, label %bb_rcspinjournal2399
bb_rcspinhold2399:
  %v8230 = load i64, ptr %slot1453, align 8
  %op8231 = sub i64 %v8230, 24
  store i64 %op8231, ptr %slot1477, align 8
  %v8232 = load i64, ptr %slot1453, align 8
  %p8233 = inttoptr i64 %v8232 to ptr
  %rgep8234 = getelementptr i8, ptr %p8233, i64 -24
  %ld8235 = load i64, ptr %rgep8234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8235, ptr %slot1478, align 8
  %v8236 = load i64, ptr %slot1478, align 8
  %op8237 = add i64 %v8236, 1
  store i64 %op8237, ptr %slot1479, align 8
  %v8238 = load i64, ptr %slot1479, align 8
  %v8239 = load i64, ptr %slot1453, align 8
  %p8240 = inttoptr i64 %v8239 to ptr
  %rgep8241 = getelementptr i8, ptr %p8240, i64 -24
  store i64 %v8238, ptr %rgep8241, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal2399
bb_rcspinjournal2399:
  %v8242 = load i64, ptr %slot1426, align 8
  %op8243 = and i64 %v8242, 1152921504606846976
  store i64 %op8243, ptr %slot1480, align 8
  %v8244 = load i64, ptr %slot1426, align 8
  %op8245 = or i64 %v8244, 1152921504606846976
  store i64 %op8245, ptr %slot1481, align 8
  %v8246 = load i64, ptr %slot1380, align 8
  %op8247 = sub i64 %v8246, 16
  store i64 %op8247, ptr %slot1482, align 8
  %v8248 = load i64, ptr %slot1481, align 8
  %v8249 = load i64, ptr %slot1380, align 8
  %p8250 = inttoptr i64 %v8249 to ptr
  %rgep8251 = getelementptr i8, ptr %p8250, i64 -16
  store i64 %v8248, ptr %rgep8251, align 8, !alias.scope !9, !noalias !10
  %v8252 = load i64, ptr %slot1413, align 8
  %p8254 = inttoptr i64 %v8252 to ptr
  %gep8255 = getelementptr i8, ptr %p8254, i64 16
  %op8253 = ptrtoint ptr %gep8255 to i64
  store i64 %op8253, ptr %slot1483, align 8
  %v8256 = load i64, ptr %slot1483, align 8
  %p8257 = inttoptr i64 %v8256 to ptr
  %ld8258 = load i64, ptr %p8257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8258, ptr %slot1484, align 8
  %v8259 = load i64, ptr %slot1438, align 8
  %op8260 = add i64 %v8259, 0
  store i64 %op8260, ptr %slot1485, align 8
  %v8261 = load i64, ptr %slot1484, align 8
  %v8262 = load i64, ptr %slot1485, align 8
  %p8263 = inttoptr i64 %v8262 to ptr
  store i64 %v8261, ptr %p8263, align 8, !alias.scope !9999998, !noalias !9999999
  %v8264 = load i64, ptr %slot1438, align 8
  %op8265 = add i64 %v8264, 8
  store i64 %op8265, ptr %slot1486, align 8
  %v8266 = load i64, ptr %slot1380, align 8
  %v8267 = load i64, ptr %slot1486, align 8
  %p8268 = inttoptr i64 %v8267 to ptr
  store i64 %v8266, ptr %p8268, align 8, !alias.scope !9999998, !noalias !9999999
  %v8269 = load i64, ptr %slot1438, align 8
  %op8270 = add i64 %v8269, 16
  store i64 %op8270, ptr %slot1487, align 8
  %v8271 = load i64, ptr %slot1480, align 8
  %v8272 = load i64, ptr %slot1487, align 8
  %p8273 = inttoptr i64 %v8272 to ptr
  store i64 %v8271, ptr %p8273, align 8, !alias.scope !9999998, !noalias !9999999
  %v8274 = load i64, ptr %slot1438, align 8
  %op8275 = add i64 %v8274, 24
  store i64 %op8275, ptr %slot1488, align 8
  %v8276 = load i64, ptr %slot1488, align 8
  %p8277 = inttoptr i64 %v8276 to ptr
  store i32 1, ptr %p8277, align 4, !alias.scope !9999998, !noalias !9999999
  %v8278 = load i64, ptr %slot1438, align 8
  %op8279 = add i64 %v8278, 32
  store i64 %op8279, ptr %slot1489, align 8
  %v8280 = load i64, ptr %slot1453, align 8
  %v8281 = load i64, ptr %slot1489, align 8
  %p8282 = inttoptr i64 %v8281 to ptr
  store i64 %v8280, ptr %p8282, align 8, !alias.scope !9999998, !noalias !9999999
  %v8283 = load i64, ptr %slot1413, align 8
  %p8285 = inttoptr i64 %v8283 to ptr
  %gep8286 = getelementptr i8, ptr %p8285, i64 16
  %op8284 = ptrtoint ptr %gep8286 to i64
  store i64 %op8284, ptr %slot1490, align 8
  %v8287 = load i64, ptr %slot1438, align 8
  %v8288 = load i64, ptr %slot1490, align 8
  %p8289 = inttoptr i64 %v8288 to ptr
  store i64 %v8287, ptr %p8289, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone2399
bb_rcspinslow2399:
  %v8290 = load i64, ptr %slot1, align 8
  %p8291 = inttoptr i64 %v8290 to ptr
  %v8292 = load i64, ptr %slot1413, align 8
  %p8293 = inttoptr i64 %v8292 to ptr
  %v8294 = load i64, ptr %slot1380, align 8
  %p8295 = inttoptr i64 %v8294 to ptr
  %call8296 = call i32 @myl_qbe_rc_scope_pin(ptr %p8291, ptr %p8293, ptr %p8295) nomerge, !dbg !190
  store i32 %call8296, ptr %slot1491, align 8
  %v8297 = load i32, ptr %slot1491, align 8
  %cv8298 = zext i32 %v8297 to i64
  %cond8299 = icmp ne i64 %cv8298, 0
  br i1 %cond8299, label %bb_rcunique2476, label %bb_failure
bb_rcunique2476:
  br label %bb_rcspindone2399
bb_rcspindone2399:
  %v8300 = load i64, ptr %slot1380, align 8
  %v8301 = load i64, ptr %slot46, align 8
  %p8302 = inttoptr i64 %v8301 to ptr
  store i64 %v8300, ptr %p8302, align 8, !alias.scope !3, !noalias !4
  %v8303 = load i64, ptr %slot42, align 8
  %p8304 = inttoptr i64 %v8303 to ptr
  %ld8305 = load i64, ptr %p8304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8305, ptr %slot1492, align 8
  %v8306 = load i64, ptr %slot1492, align 8
  %v8307 = load i64, ptr %slot52, align 8
  %p8308 = inttoptr i64 %v8307 to ptr
  store i64 %v8306, ptr %p8308, align 8, !alias.scope !3, !noalias !4
  %v8309 = load i64, ptr %slot52, align 8
  %p8310 = inttoptr i64 %v8309 to ptr
  %ld8311 = load i64, ptr %p8310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8311, ptr %slot1493, align 8
  %v8312 = load i64, ptr %slot1493, align 8
  %v8313 = load i64, ptr %slot48, align 8
  %p8314 = inttoptr i64 %v8313 to ptr
  store i64 %v8312, ptr %p8314, align 8, !alias.scope !3, !noalias !4
  %v8315 = load i64, ptr %slot48, align 8
  %p8316 = inttoptr i64 %v8315 to ptr
  %ld8317 = load i64, ptr %p8316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8317, ptr %slot1494, align 8
  %v8318 = load i64, ptr %slot1494, align 8
  %v8319 = load i64, ptr %slot52, align 8
  %p8320 = inttoptr i64 %v8319 to ptr
  store i64 %v8318, ptr %p8320, align 8, !alias.scope !3, !noalias !4
  %v8321 = load i64, ptr %slot53, align 8
  %p8322 = inttoptr i64 %v8321 to ptr
  store i64 0, ptr %p8322, align 8, !alias.scope !3, !noalias !4
  %v8323 = load i64, ptr %slot53, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  %ld8325 = load i64, ptr %p8324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8325, ptr %slot1495, align 8
  %v8326 = load i64, ptr %slot52, align 8
  %p8327 = inttoptr i64 %v8326 to ptr
  %ld8328 = load i64, ptr %p8327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8328, ptr %slot1496, align 8
  %v8329 = load i64, ptr %slot1496, align 8
  %v8330 = load i64, ptr %slot1495, align 8
  %cmp8331 = icmp slt i64 %v8329, %v8330
  %cv8332 = zext i1 %cmp8331 to i64
  store i64 %cv8332, ptr %slot1497, align 8
  %v8333 = load i64, ptr %slot1497, align 8
  %v8334 = load i64, ptr %slot52, align 8
  %p8335 = inttoptr i64 %v8334 to ptr
  store i64 %v8333, ptr %p8335, align 8, !alias.scope !3, !noalias !4
  %v8336 = load i64, ptr %slot52, align 8
  %p8337 = inttoptr i64 %v8336 to ptr
  %ld8338 = load i64, ptr %p8337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8338, ptr %slot1498, align 8
  %v8339 = load i64, ptr %slot1498, align 8
  %cond8340 = icmp ne i64 %v8339, 0
  br i1 %cond8340, label %bb_next2484, label %bb_i108
bb_next2484:
  %v8341 = load i64, ptr %slot46, align 8
  %p8342 = inttoptr i64 %v8341 to ptr
  %ld8343 = load i64, ptr %p8342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8343, ptr %slot1499, align 8
  %v8344 = load i64, ptr %slot1499, align 8
  %op8345 = add i64 %v8344, 0
  store i64 %op8345, ptr %slot1500, align 8
  %v8346 = load i64, ptr %slot1500, align 8
  %p8347 = inttoptr i64 %v8346 to ptr
  %ld8348 = load i64, ptr %p8347, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8348, ptr %slot1501, align 8
  %v8349 = load i64, ptr %slot1501, align 8
  %v8350 = load i64, ptr %slot52, align 8
  %p8351 = inttoptr i64 %v8350 to ptr
  store i64 %v8349, ptr %p8351, align 8, !alias.scope !3, !noalias !4
  %v8352 = load i64, ptr %slot52, align 8
  %p8353 = inttoptr i64 %v8352 to ptr
  %ld8354 = load i64, ptr %p8353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8354, ptr %slot1502, align 8
  %v8355 = load i64, ptr %slot1502, align 8
  %cmp8356 = icmp ugt i64 %v8355, 9223372036854775807
  %cv8357 = zext i1 %cmp8356 to i64
  store i64 %cv8357, ptr %slot1503, align 8
  %v8358 = load i64, ptr %slot1503, align 8
  %cond8359 = icmp ne i64 %v8358, 0
  br i1 %cond8359, label %bb_cast_overflow2489, label %bb_cast_ok2489
bb_cast_overflow2489:
  %v8360 = load i64, ptr %slot1, align 8
  %p8361 = inttoptr i64 %v8360 to ptr
  %v8362 = load i64, ptr %slot1502, align 8
  call void @myl_qbe_fail_cast(ptr %p8361, i64 %v8362, i64 320) nomerge, !dbg !192
  unreachable
bb_cast_ok2489:
  %v8363 = load i64, ptr %slot1502, align 8
  %v8364 = load i64, ptr %slot52, align 8
  %p8365 = inttoptr i64 %v8364 to ptr
  store i64 %v8363, ptr %p8365, align 8, !alias.scope !3, !noalias !4
  %v8366 = load i64, ptr %slot48, align 8
  %p8367 = inttoptr i64 %v8366 to ptr
  %ld8368 = load i64, ptr %p8367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8368, ptr %slot1504, align 8
  %v8369 = load i64, ptr %slot1504, align 8
  %v8370 = load i64, ptr %slot53, align 8
  %p8371 = inttoptr i64 %v8370 to ptr
  store i64 %v8369, ptr %p8371, align 8, !alias.scope !3, !noalias !4
  %v8372 = load i64, ptr %slot53, align 8
  %p8373 = inttoptr i64 %v8372 to ptr
  %ld8374 = load i64, ptr %p8373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8374, ptr %slot1505, align 8
  %v8375 = load i64, ptr %slot52, align 8
  %p8376 = inttoptr i64 %v8375 to ptr
  %ld8377 = load i64, ptr %p8376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8377, ptr %slot1506, align 8
  %v8378 = load i64, ptr %slot1506, align 8
  %v8379 = load i64, ptr %slot1505, align 8
  %ovpair8381 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v8378, i64 %v8379)
  %op8380 = extractvalue { i64, i1 } %ovpair8381, 0
  %ov8382 = extractvalue { i64, i1 } %ovpair8381, 1
  store i64 %op8380, ptr %slot1507, align 8
  %v8383 = load i64, ptr %slot1506, align 8
  %v8384 = load i64, ptr %slot1507, align 8
  %op8385 = xor i64 %v8383, %v8384
  store i64 %op8385, ptr %slot1508, align 8
  %v8386 = load i64, ptr %slot1505, align 8
  %v8387 = load i64, ptr %slot1507, align 8
  %op8388 = xor i64 %v8386, %v8387
  store i64 %op8388, ptr %slot1509, align 8
  %v8389 = load i64, ptr %slot1508, align 8
  %v8390 = load i64, ptr %slot1509, align 8
  %op8391 = and i64 %v8389, %v8390
  store i64 %op8391, ptr %slot1510, align 8
  %cv8392 = zext i1 %ov8382 to i64
  store i64 %cv8392, ptr %slot1511, align 8
  %v8393 = load i64, ptr %slot1511, align 8
  %cond8394 = icmp ne i64 %v8393, 0
  br i1 %cond8394, label %bb_overflow2493, label %bb_checked2493
bb_overflow2493:
  %v8395 = load i64, ptr %slot1, align 8
  %p8396 = inttoptr i64 %v8395 to ptr
  %v8397 = load i64, ptr %slot1506, align 8
  %v8398 = load i64, ptr %slot1505, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p8396, i64 0, i64 %v8397, i64 %v8398, i64 64) nomerge, !dbg !194
  unreachable
bb_checked2493:
  %v8399 = load i64, ptr %slot1507, align 8
  %v8400 = load i64, ptr %slot52, align 8
  %p8401 = inttoptr i64 %v8400 to ptr
  store i64 %v8399, ptr %p8401, align 8, !alias.scope !3, !noalias !4
  %v8402 = load i64, ptr %slot52, align 8
  %p8403 = inttoptr i64 %v8402 to ptr
  %ld8404 = load i64, ptr %p8403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8404, ptr %slot1512, align 8
  %v8405 = load i64, ptr %slot1512, align 8
  %v8406 = load i64, ptr %slot48, align 8
  %p8407 = inttoptr i64 %v8406 to ptr
  store i64 %v8405, ptr %p8407, align 8, !alias.scope !3, !noalias !4
  br label %bb_i108
bb_i108:
  %v8408 = load i64, ptr %slot48, align 8
  %p8409 = inttoptr i64 %v8408 to ptr
  %ld8410 = load i64, ptr %p8409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8410, ptr %slot1513, align 8
  %v8411 = load i64, ptr %slot1513, align 8
  %v8412 = load i64, ptr %slot52, align 8
  %p8413 = inttoptr i64 %v8412 to ptr
  store i64 %v8411, ptr %p8413, align 8, !alias.scope !3, !noalias !4
  %v8414 = load i64, ptr %slot47, align 8
  %v8415 = load i64, ptr %slot64, align 8
  %p8416 = inttoptr i64 %v8414 to ptr
  %p8417 = inttoptr i64 %v8415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8417, ptr %p8416, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v8418 = load i64, ptr %slot64, align 8
  %v8419 = load i64, ptr %slot53, align 8
  %p8420 = inttoptr i64 %v8419 to ptr
  store i64 %v8418, ptr %p8420, align 8, !alias.scope !3, !noalias !4
  %v8421 = load i64, ptr %slot46, align 8
  %p8422 = inttoptr i64 %v8421 to ptr
  %ld8423 = load i64, ptr %p8422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8423, ptr %slot1514, align 8
  %v8424 = load i64, ptr %slot53, align 8
  %p8425 = inttoptr i64 %v8424 to ptr
  %ld8426 = load i64, ptr %p8425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8426, ptr %slot1515, align 8
  %v8427 = load i64, ptr %slot52, align 8
  %p8428 = inttoptr i64 %v8427 to ptr
  %ld8429 = load i64, ptr %p8428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8429, ptr %slot1516, align 8
  %v8430 = load i64, ptr %slot1514, align 8
  %p8431 = inttoptr i64 %v8430 to ptr
  %ld8432 = load i64, ptr %p8431, align 8, !alias.scope !6, !noalias !7
  store i64 %ld8432, ptr %slot1517, align 8
  %v8433 = load i64, ptr %slot1516, align 8
  %v8434 = load i64, ptr %slot1517, align 8
  %cmp8435 = icmp ult i64 %v8433, %v8434
  %cv8436 = zext i1 %cmp8435 to i64
  store i64 %cv8436, ptr %slot1518, align 8
  %v8437 = load i64, ptr %slot1518, align 8
  %cond8438 = icmp ne i64 %v8437, 0
  br i1 %cond8438, label %bb_success2506, label %bb_failed2506
bb_failed2506:
  %v8439 = load i64, ptr %slot1, align 8
  %p8440 = inttoptr i64 %v8439 to ptr
  %v8441 = load i64, ptr %slot1516, align 8
  %v8442 = load i64, ptr %slot1517, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p8440, i64 %v8441, i64 %v8442) nomerge, !dbg !196
  unreachable
bb_success2506:
  %v8443 = load i64, ptr %slot53, align 8
  %p8444 = inttoptr i64 %v8443 to ptr
  %ld8445 = load i64, ptr %p8444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8445, ptr %slot1519, align 8
  %v8446 = load i64, ptr %slot73, align 8
  %v8447 = load i64, ptr %slot1514, align 8
  %v8448 = load i64, ptr %slot1516, align 8
  %v8449 = load i64, ptr %slot1519, align 8
  %call8450 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v8446, i64 %v8447, i64 %v8448, i64 %v8449) nomerge, !dbg !196
  store i32 %call8450, ptr %slot1520, align 8
  %v8451 = load i32, ptr %slot1520, align 8
  %cv8452 = zext i32 %v8451 to i64
  %cond8453 = icmp ne i64 %cv8452, 0
  br i1 %cond8453, label %bb_success2509, label %bb_failed2509
bb_failed2509:
  %v8454 = load i64, ptr %slot1, align 8
  %p8455 = inttoptr i64 %v8454 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8455) nomerge, !dbg !196
  unreachable
bb_success2509:
  %v8456 = load i64, ptr %slot52, align 8
  %p8457 = inttoptr i64 %v8456 to ptr
  store i64 0, ptr %p8457, align 8, !alias.scope !3, !noalias !4
  %v8458 = load i64, ptr %slot33, align 8
  store i64 %v8458, ptr %slot1521, align 8
  %v8459 = load i64, ptr %slot1521, align 8
  %p8461 = inttoptr i64 %v8459 to ptr
  %gep8462 = getelementptr i8, ptr %p8461, i64 24
  %op8460 = ptrtoint ptr %gep8462 to i64
  store i64 %op8460, ptr %slot1522, align 8
  %v8463 = load i64, ptr %slot1522, align 8
  %p8464 = inttoptr i64 %v8463 to ptr
  %ld8465 = load i32, ptr %p8464, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8465, ptr %slot1523, align 8
  %v8466 = load i32, ptr %slot1523, align 8
  %cv8467 = zext i32 %v8466 to i64
  %cond8468 = icmp ne i64 %cv8467, 0
  br i1 %cond8468, label %bb_rcsendactive2520, label %bb_rcsenddone2520
bb_rcsendactive2520:
  %v8469 = load i64, ptr %slot73, align 8
  %p8471 = inttoptr i64 %v8469 to ptr
  %gep8472 = getelementptr i8, ptr %p8471, i64 5640
  %op8470 = ptrtoint ptr %gep8472 to i64
  store i64 %op8470, ptr %slot1524, align 8
  %v8473 = load i64, ptr %slot1524, align 8
  %p8474 = inttoptr i64 %v8473 to ptr
  %ld8475 = load i64, ptr %p8474, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8475, ptr %slot1525, align 8
  %v8476 = load i64, ptr %slot1525, align 8
  %op8477 = add i64 %v8476, 248
  store i64 %op8477, ptr %slot1526, align 8
  %v8478 = load i64, ptr %slot1526, align 8
  %p8479 = inttoptr i64 %v8478 to ptr
  %ld8480 = load i64, ptr %p8479, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8480, ptr %slot1527, align 8
  %v8481 = load i64, ptr %slot1527, align 8
  %v8482 = load i64, ptr %slot1521, align 8
  %cmp8483 = icmp eq i64 %v8481, %v8482
  %cv8484 = zext i1 %cmp8483 to i32
  store i32 %cv8484, ptr %slot1528, align 8
  %v8485 = load i32, ptr %slot1528, align 8
  %cv8486 = zext i32 %v8485 to i64
  %cond8487 = icmp ne i64 %cv8486, 0
  br i1 %cond8487, label %bb_rcs2528, label %bb_rcsendslow2520
bb_rcs2528:
  %v8488 = load i64, ptr %slot1525, align 8
  %op8489 = add i64 %v8488, 200
  store i64 %op8489, ptr %slot1529, align 8
  %v8490 = load i64, ptr %slot1529, align 8
  %p8491 = inttoptr i64 %v8490 to ptr
  %ld8492 = load i64, ptr %p8491, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8492, ptr %slot1530, align 8
  %v8493 = load i64, ptr %slot1530, align 8
  %cmp8494 = icmp eq i64 %v8493, 0
  %cv8495 = zext i1 %cmp8494 to i32
  store i32 %cv8495, ptr %slot1531, align 8
  %v8496 = load i32, ptr %slot1531, align 8
  %cv8497 = zext i32 %v8496 to i64
  %cond8498 = icmp ne i64 %cv8497, 0
  br i1 %cond8498, label %bb_rcs2532, label %bb_rcsendslow2520
bb_rcs2532:
  %v8499 = load i64, ptr %slot1521, align 8
  %p8501 = inttoptr i64 %v8499 to ptr
  %gep8502 = getelementptr i8, ptr %p8501, i64 16
  %op8500 = ptrtoint ptr %gep8502 to i64
  store i64 %op8500, ptr %slot1532, align 8
  %v8503 = load i64, ptr %slot1532, align 8
  %p8504 = inttoptr i64 %v8503 to ptr
  %ld8505 = load i64, ptr %p8504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8505, ptr %slot1533, align 8
  %v8506 = load i64, ptr %slot1533, align 8
  %cmp8507 = icmp ne i64 %v8506, 0
  %cv8508 = zext i1 %cmp8507 to i32
  store i32 %cv8508, ptr %slot1534, align 8
  %v8509 = load i32, ptr %slot1534, align 8
  %cv8510 = zext i32 %v8509 to i64
  %cond8511 = icmp ne i64 %cv8510, 0
  br i1 %cond8511, label %bb_rcsendnode2520, label %bb_rcsendunlink2520
bb_rcsendnode2520:
  %v8512 = load i64, ptr %slot1533, align 8
  %op8513 = add i64 %v8512, 0
  store i64 %op8513, ptr %slot1535, align 8
  %v8514 = load i64, ptr %slot1535, align 8
  %p8515 = inttoptr i64 %v8514 to ptr
  %ld8516 = load i64, ptr %p8515, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8516, ptr %slot1536, align 8
  %v8517 = load i64, ptr %slot1536, align 8
  %cmp8518 = icmp eq i64 %v8517, 0
  %cv8519 = zext i1 %cmp8518 to i32
  store i32 %cv8519, ptr %slot1537, align 8
  %v8520 = load i32, ptr %slot1537, align 8
  %cv8521 = zext i32 %v8520 to i64
  %cond8522 = icmp ne i64 %cv8521, 0
  br i1 %cond8522, label %bb_rcs2539, label %bb_rcsendslow2520
bb_rcs2539:
  %v8523 = load i64, ptr %slot1525, align 8
  %op8524 = add i64 %v8523, 264
  store i64 %op8524, ptr %slot1538, align 8
  %v8525 = load i64, ptr %slot1538, align 8
  %p8526 = inttoptr i64 %v8525 to ptr
  %ld8527 = load i64, ptr %p8526, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8527, ptr %slot1539, align 8
  %v8528 = load i64, ptr %slot1539, align 8
  %cmp8529 = icmp ult i64 %v8528, 32
  %cv8530 = zext i1 %cmp8529 to i32
  store i32 %cv8530, ptr %slot1540, align 8
  %v8531 = load i32, ptr %slot1540, align 8
  %cv8532 = zext i32 %v8531 to i64
  %cond8533 = icmp ne i64 %cv8532, 0
  br i1 %cond8533, label %bb_rcs2543, label %bb_rcsendslow2520
bb_rcs2543:
  %v8534 = load i64, ptr %slot1533, align 8
  %op8535 = add i64 %v8534, 8
  store i64 %op8535, ptr %slot1541, align 8
  %v8536 = load i64, ptr %slot1541, align 8
  %p8537 = inttoptr i64 %v8536 to ptr
  %ld8538 = load i64, ptr %p8537, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8538, ptr %slot1542, align 8
  %v8539 = load i64, ptr %slot1542, align 8
  %cmp8540 = icmp ne i64 %v8539, 0
  %cv8541 = zext i1 %cmp8540 to i32
  store i32 %cv8541, ptr %slot1543, align 8
  %v8542 = load i32, ptr %slot1543, align 8
  %cv8543 = zext i32 %v8542 to i64
  %cond8544 = icmp ne i64 %cv8543, 0
  br i1 %cond8544, label %bb_rcs2547, label %bb_rcsendslow2520
bb_rcs2547:
  %v8545 = load i64, ptr %slot1542, align 8
  %op8546 = sub i64 %v8545, 16
  store i64 %op8546, ptr %slot1544, align 8
  %v8547 = load i64, ptr %slot1542, align 8
  %p8548 = inttoptr i64 %v8547 to ptr
  %rgep8549 = getelementptr i8, ptr %p8548, i64 -16
  %ld8550 = load i64, ptr %rgep8549, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8550, ptr %slot1545, align 8
  %v8551 = load i64, ptr %slot1545, align 8
  %op8552 = and i64 %v8551, 4611686018427387907
  store i64 %op8552, ptr %slot1546, align 8
  %v8553 = load i64, ptr %slot1546, align 8
  %cmp8554 = icmp eq i64 %v8553, 0
  %cv8555 = zext i1 %cmp8554 to i32
  store i32 %cv8555, ptr %slot1547, align 8
  %v8556 = load i32, ptr %slot1547, align 8
  %cv8557 = zext i32 %v8556 to i64
  %cond8558 = icmp ne i64 %cv8557, 0
  br i1 %cond8558, label %bb_rcs2552, label %bb_rcsendslow2520
bb_rcs2552:
  %v8559 = load i64, ptr %slot1542, align 8
  %op8560 = sub i64 %v8559, 24
  store i64 %op8560, ptr %slot1548, align 8
  %v8561 = load i64, ptr %slot1542, align 8
  %p8562 = inttoptr i64 %v8561 to ptr
  %rgep8563 = getelementptr i8, ptr %p8562, i64 -24
  %ld8564 = load i64, ptr %rgep8563, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8564, ptr %slot1549, align 8
  %v8565 = load i64, ptr %slot1549, align 8
  %cmp8566 = icmp ne i64 %v8565, 0
  %cv8567 = zext i1 %cmp8566 to i32
  store i32 %cv8567, ptr %slot1550, align 8
  %v8568 = load i32, ptr %slot1550, align 8
  %cv8569 = zext i32 %v8568 to i64
  %cond8570 = icmp ne i64 %cv8569, 0
  br i1 %cond8570, label %bb_rcs2556, label %bb_rcsendslow2520
bb_rcs2556:
  %v8571 = load i64, ptr %slot1542, align 8
  %op8572 = sub i64 %v8571, 32
  store i64 %op8572, ptr %slot1551, align 8
  %v8573 = load i64, ptr %slot1542, align 8
  %p8574 = inttoptr i64 %v8573 to ptr
  %rgep8575 = getelementptr i8, ptr %p8574, i64 -32
  %ld8576 = load i64, ptr %rgep8575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8576, ptr %slot1552, align 8
  %v8577 = load i64, ptr %slot1549, align 8
  %cmp8578 = icmp ugt i64 %v8577, 1
  %cv8579 = zext i1 %cmp8578 to i32
  store i32 %cv8579, ptr %slot1553, align 8
  %v8580 = load i64, ptr %slot1552, align 8
  %cmp8581 = icmp ne i64 %v8580, 0
  %cv8582 = zext i1 %cmp8581 to i32
  store i32 %cv8582, ptr %slot1554, align 8
  %v8583 = load i32, ptr %slot1553, align 8
  %v8584 = load i32, ptr %slot1554, align 8
  %op8585 = or i32 %v8583, %v8584
  store i32 %op8585, ptr %slot1555, align 8
  %v8586 = load i32, ptr %slot1555, align 8
  %cv8587 = zext i32 %v8586 to i64
  %cond8588 = icmp ne i64 %cv8587, 0
  br i1 %cond8588, label %bb_rcs2562, label %bb_rcsendslow2520
bb_rcs2562:
  %v8589 = load i64, ptr %slot1533, align 8
  %op8590 = add i64 %v8589, 32
  store i64 %op8590, ptr %slot1556, align 8
  %v8591 = load i64, ptr %slot1556, align 8
  %p8592 = inttoptr i64 %v8591 to ptr
  %ld8593 = load i64, ptr %p8592, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8593, ptr %slot1557, align 8
  %v8594 = load i64, ptr %slot1557, align 8
  %cmp8595 = icmp ne i64 %v8594, 0
  %cv8596 = zext i1 %cmp8595 to i32
  store i32 %cv8596, ptr %slot1558, align 8
  %v8597 = load i32, ptr %slot1558, align 8
  %cv8598 = zext i32 %v8597 to i64
  %cond8599 = icmp ne i64 %cv8598, 0
  br i1 %cond8599, label %bb_rcsendbacking2520, label %bb_rcsendcommit2520
bb_rcsendbacking2520:
  %v8600 = load i64, ptr %slot1557, align 8
  %op8601 = sub i64 %v8600, 16
  store i64 %op8601, ptr %slot1559, align 8
  %v8602 = load i64, ptr %slot1557, align 8
  %p8603 = inttoptr i64 %v8602 to ptr
  %rgep8604 = getelementptr i8, ptr %p8603, i64 -16
  %ld8605 = load i64, ptr %rgep8604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8605, ptr %slot1560, align 8
  %v8606 = load i64, ptr %slot1560, align 8
  %op8607 = and i64 %v8606, 4611686018427387907
  store i64 %op8607, ptr %slot1561, align 8
  %v8608 = load i64, ptr %slot1561, align 8
  %cmp8609 = icmp eq i64 %v8608, 0
  %cv8610 = zext i1 %cmp8609 to i32
  store i32 %cv8610, ptr %slot1562, align 8
  %v8611 = load i32, ptr %slot1562, align 8
  %cv8612 = zext i32 %v8611 to i64
  %cond8613 = icmp ne i64 %cv8612, 0
  br i1 %cond8613, label %bb_rcs2570, label %bb_rcsendslow2520
bb_rcs2570:
  %v8614 = load i64, ptr %slot1557, align 8
  %op8615 = sub i64 %v8614, 24
  store i64 %op8615, ptr %slot1563, align 8
  %v8616 = load i64, ptr %slot1557, align 8
  %p8617 = inttoptr i64 %v8616 to ptr
  %rgep8618 = getelementptr i8, ptr %p8617, i64 -24
  %ld8619 = load i64, ptr %rgep8618, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8619, ptr %slot1564, align 8
  %v8620 = load i64, ptr %slot1564, align 8
  %cmp8621 = icmp ne i64 %v8620, 0
  %cv8622 = zext i1 %cmp8621 to i32
  store i32 %cv8622, ptr %slot1565, align 8
  %v8623 = load i32, ptr %slot1565, align 8
  %cv8624 = zext i32 %v8623 to i64
  %cond8625 = icmp ne i64 %cv8624, 0
  br i1 %cond8625, label %bb_rcs2574, label %bb_rcsendslow2520
bb_rcs2574:
  %v8626 = load i64, ptr %slot1557, align 8
  %op8627 = sub i64 %v8626, 32
  store i64 %op8627, ptr %slot1566, align 8
  %v8628 = load i64, ptr %slot1557, align 8
  %p8629 = inttoptr i64 %v8628 to ptr
  %rgep8630 = getelementptr i8, ptr %p8629, i64 -32
  %ld8631 = load i64, ptr %rgep8630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8631, ptr %slot1567, align 8
  %v8632 = load i64, ptr %slot1564, align 8
  %cmp8633 = icmp ugt i64 %v8632, 1
  %cv8634 = zext i1 %cmp8633 to i32
  store i32 %cv8634, ptr %slot1568, align 8
  %v8635 = load i64, ptr %slot1567, align 8
  %cmp8636 = icmp ne i64 %v8635, 0
  %cv8637 = zext i1 %cmp8636 to i32
  store i32 %cv8637, ptr %slot1569, align 8
  %v8638 = load i32, ptr %slot1568, align 8
  %v8639 = load i32, ptr %slot1569, align 8
  %op8640 = or i32 %v8638, %v8639
  store i32 %op8640, ptr %slot1570, align 8
  %v8641 = load i32, ptr %slot1570, align 8
  %cv8642 = zext i32 %v8641 to i64
  %cond8643 = icmp ne i64 %cv8642, 0
  br i1 %cond8643, label %bb_rcs2580, label %bb_rcsendslow2520
bb_rcs2580:
  br label %bb_rcsendcommit2520
bb_rcsendcommit2520:
  %v8644 = load i64, ptr %slot1533, align 8
  %op8645 = add i64 %v8644, 24
  store i64 %op8645, ptr %slot1571, align 8
  %v8646 = load i64, ptr %slot1571, align 8
  %p8647 = inttoptr i64 %v8646 to ptr
  %ld8648 = load i32, ptr %p8647, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld8648, ptr %slot1572, align 8
  %v8649 = load i32, ptr %slot1572, align 8
  %cv8650 = zext i32 %v8649 to i64
  %cond8651 = icmp ne i64 %cv8650, 0
  br i1 %cond8651, label %bb_rcsendrestore2520, label %bb_rcsendreturned2520
bb_rcsendrestore2520:
  %v8652 = load i64, ptr %slot1533, align 8
  %op8653 = add i64 %v8652, 16
  store i64 %op8653, ptr %slot1573, align 8
  %v8654 = load i64, ptr %slot1573, align 8
  %p8655 = inttoptr i64 %v8654 to ptr
  %ld8656 = load i64, ptr %p8655, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8656, ptr %slot1574, align 8
  %v8657 = load i64, ptr %slot1545, align 8
  %op8658 = and i64 %v8657, 17293822569102704639
  store i64 %op8658, ptr %slot1575, align 8
  %v8659 = load i64, ptr %slot1575, align 8
  %v8660 = load i64, ptr %slot1574, align 8
  %op8661 = or i64 %v8659, %v8660
  store i64 %op8661, ptr %slot1576, align 8
  %v8662 = load i64, ptr %slot1542, align 8
  %op8663 = sub i64 %v8662, 16
  store i64 %op8663, ptr %slot1577, align 8
  %v8664 = load i64, ptr %slot1576, align 8
  %v8665 = load i64, ptr %slot1542, align 8
  %p8666 = inttoptr i64 %v8665 to ptr
  %rgep8667 = getelementptr i8, ptr %p8666, i64 -16
  store i64 %v8664, ptr %rgep8667, align 8, !alias.scope !9, !noalias !10
  %v8668 = load i64, ptr %slot1521, align 8
  %p8670 = inttoptr i64 %v8668 to ptr
  %gep8671 = getelementptr i8, ptr %p8670, i64 16
  %op8669 = ptrtoint ptr %gep8671 to i64
  store i64 %op8669, ptr %slot1578, align 8
  br label %bb_rcsendreturned2520
bb_rcsendreturned2520:
  %v8672 = load i64, ptr %slot1578, align 8
  %p8673 = inttoptr i64 %v8672 to ptr
  store i64 0, ptr %p8673, align 8, !alias.scope !3, !noalias !4
  %v8674 = load i64, ptr %slot1525, align 8
  %op8675 = add i64 %v8674, 256
  store i64 %op8675, ptr %slot1579, align 8
  %v8676 = load i64, ptr %slot1579, align 8
  %p8677 = inttoptr i64 %v8676 to ptr
  %ld8678 = load i64, ptr %p8677, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8678, ptr %slot1580, align 8
  %v8679 = load i64, ptr %slot1533, align 8
  %op8680 = add i64 %v8679, 0
  store i64 %op8680, ptr %slot1581, align 8
  %v8681 = load i64, ptr %slot1580, align 8
  %v8682 = load i64, ptr %slot1581, align 8
  %p8683 = inttoptr i64 %v8682 to ptr
  store i64 %v8681, ptr %p8683, align 8, !alias.scope !9999998, !noalias !9999999
  %v8684 = load i64, ptr %slot1525, align 8
  %op8685 = add i64 %v8684, 256
  store i64 %op8685, ptr %slot1582, align 8
  %v8686 = load i64, ptr %slot1533, align 8
  %v8687 = load i64, ptr %slot1582, align 8
  %p8688 = inttoptr i64 %v8687 to ptr
  store i64 %v8686, ptr %p8688, align 8, !alias.scope !9999998, !noalias !9999999
  %v8689 = load i64, ptr %slot1525, align 8
  %op8690 = add i64 %v8689, 264
  store i64 %op8690, ptr %slot1583, align 8
  %v8691 = load i64, ptr %slot1583, align 8
  %p8692 = inttoptr i64 %v8691 to ptr
  %ld8693 = load i64, ptr %p8692, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8693, ptr %slot1584, align 8
  %v8694 = load i64, ptr %slot1584, align 8
  %op8695 = add i64 %v8694, 1
  store i64 %op8695, ptr %slot1585, align 8
  %v8696 = load i64, ptr %slot1585, align 8
  %v8697 = load i64, ptr %slot1583, align 8
  %p8698 = inttoptr i64 %v8697 to ptr
  store i64 %v8696, ptr %p8698, align 8, !alias.scope !9999998, !noalias !9999999
  %v8699 = load i64, ptr %slot73, align 8
  %p8701 = inttoptr i64 %v8699 to ptr
  %gep8702 = getelementptr i8, ptr %p8701, i64 24
  %op8700 = ptrtoint ptr %gep8702 to i64
  store i64 %op8700, ptr %slot1586, align 8
  %v8703 = load i64, ptr %slot1586, align 8
  %p8704 = inttoptr i64 %v8703 to ptr
  %ld8705 = load i64, ptr %p8704, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8705, ptr %slot1587, align 8
  %v8706 = load i64, ptr %slot1587, align 8
  %op8707 = add i64 %v8706, 18446744073709551576
  store i64 %op8707, ptr %slot1588, align 8
  %v8708 = load i64, ptr %slot1588, align 8
  %v8709 = load i64, ptr %slot1586, align 8
  %p8710 = inttoptr i64 %v8709 to ptr
  store i64 %v8708, ptr %p8710, align 8, !alias.scope !9999998, !noalias !9999999
  %v8711 = load i64, ptr %slot1525, align 8
  %op8712 = add i64 %v8711, 48
  store i64 %op8712, ptr %slot1589, align 8
  %v8713 = load i64, ptr %slot1589, align 8
  %p8714 = inttoptr i64 %v8713 to ptr
  %ld8715 = load i64, ptr %p8714, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld8715, ptr %slot1590, align 8
  %v8716 = load i64, ptr %slot1590, align 8
  %op8717 = add i64 %v8716, 18446744073709551576
  store i64 %op8717, ptr %slot1591, align 8
  %v8718 = load i64, ptr %slot1591, align 8
  %v8719 = load i64, ptr %slot1589, align 8
  %p8720 = inttoptr i64 %v8719 to ptr
  store i64 %v8718, ptr %p8720, align 8, !alias.scope !9999998, !noalias !9999999
  %v8721 = load i64, ptr %slot1557, align 8
  %cmp8722 = icmp ne i64 %v8721, 0
  %cv8723 = zext i1 %cmp8722 to i32
  store i32 %cv8723, ptr %slot1592, align 8
  %v8724 = load i32, ptr %slot1592, align 8
  %cv8725 = zext i32 %v8724 to i64
  %cond8726 = icmp ne i64 %cv8725, 0
  br i1 %cond8726, label %bb_rcsenddropbacking2520, label %bb_rcsenddroppayload2520
bb_rcsenddropbacking2520:
  %v8727 = load i64, ptr %slot1557, align 8
  %op8728 = sub i64 %v8727, 24
  store i64 %op8728, ptr %slot1593, align 8
  %v8729 = load i64, ptr %slot1557, align 8
  %p8730 = inttoptr i64 %v8729 to ptr
  %rgep8731 = getelementptr i8, ptr %p8730, i64 -24
  %ld8732 = load i64, ptr %rgep8731, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8732, ptr %slot1594, align 8
  %v8733 = load i64, ptr %slot1594, align 8
  %op8734 = add i64 %v8733, 18446744073709551615
  store i64 %op8734, ptr %slot1595, align 8
  %v8735 = load i64, ptr %slot1595, align 8
  %v8736 = load i64, ptr %slot1557, align 8
  %p8737 = inttoptr i64 %v8736 to ptr
  %rgep8738 = getelementptr i8, ptr %p8737, i64 -24
  store i64 %v8735, ptr %rgep8738, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload2520
bb_rcsenddroppayload2520:
  %v8739 = load i64, ptr %slot1542, align 8
  %op8740 = sub i64 %v8739, 24
  store i64 %op8740, ptr %slot1596, align 8
  %v8741 = load i64, ptr %slot1542, align 8
  %p8742 = inttoptr i64 %v8741 to ptr
  %rgep8743 = getelementptr i8, ptr %p8742, i64 -24
  %ld8744 = load i64, ptr %rgep8743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8744, ptr %slot1597, align 8
  %v8745 = load i64, ptr %slot1597, align 8
  %op8746 = add i64 %v8745, 18446744073709551615
  store i64 %op8746, ptr %slot1598, align 8
  %v8747 = load i64, ptr %slot1598, align 8
  %v8748 = load i64, ptr %slot1542, align 8
  %p8749 = inttoptr i64 %v8748 to ptr
  %rgep8750 = getelementptr i8, ptr %p8749, i64 -24
  store i64 %v8747, ptr %rgep8750, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink2520
bb_rcsendunlink2520:
  %v8751 = load i64, ptr %slot1521, align 8
  %p8753 = inttoptr i64 %v8751 to ptr
  %gep8754 = getelementptr i8, ptr %p8753, i64 8
  %op8752 = ptrtoint ptr %gep8754 to i64
  store i64 %op8752, ptr %slot1599, align 8
  %v8755 = load i64, ptr %slot1599, align 8
  %p8756 = inttoptr i64 %v8755 to ptr
  %ld8757 = load i64, ptr %p8756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8757, ptr %slot1600, align 8
  %v8758 = load i64, ptr %slot1525, align 8
  %op8759 = add i64 %v8758, 248
  store i64 %op8759, ptr %slot1601, align 8
  %v8760 = load i64, ptr %slot1600, align 8
  %v8761 = load i64, ptr %slot1601, align 8
  %p8762 = inttoptr i64 %v8761 to ptr
  store i64 %v8760, ptr %p8762, align 8, !alias.scope !9999998, !noalias !9999999
  %v8763 = load i64, ptr %slot1521, align 8
  %p8765 = inttoptr i64 %v8763 to ptr
  %gep8766 = getelementptr i8, ptr %p8765, i64 24
  %op8764 = ptrtoint ptr %gep8766 to i64
  store i64 %op8764, ptr %slot1602, align 8
  %v8767 = load i64, ptr %slot1521, align 8
  %p8769 = inttoptr i64 %v8767 to ptr
  %gep8770 = getelementptr i8, ptr %p8769, i64 8
  %op8768 = ptrtoint ptr %gep8770 to i64
  store i64 %op8768, ptr %slot1603, align 8
  %v8771 = load i64, ptr %slot1602, align 8
  %p8772 = inttoptr i64 %v8771 to ptr
  store i32 0, ptr %p8772, align 4, !alias.scope !3, !noalias !4
  %v8773 = load i64, ptr %slot1603, align 8
  %p8774 = inttoptr i64 %v8773 to ptr
  store i64 0, ptr %p8774, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone2520
bb_rcsendslow2520:
  %v8775 = load i64, ptr %slot1, align 8
  %p8776 = inttoptr i64 %v8775 to ptr
  %v8777 = load i64, ptr %slot1521, align 8
  %p8778 = inttoptr i64 %v8777 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p8776, ptr %p8778) nomerge, !dbg !196
  br label %bb_rcsenddone2520
bb_rcsenddone2520:
  %v8779 = load i64, ptr %slot36, align 8
  %p8780 = inttoptr i64 %v8779 to ptr
  %ld8781 = load i64, ptr %p8780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8781, ptr %slot1604, align 8
  %v8782 = load i64, ptr %slot1604, align 8
  %v8783 = load i64, ptr %slot65, align 8
  %p8784 = inttoptr i64 %v8782 to ptr
  %p8785 = inttoptr i64 %v8783 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8785, ptr %p8784, i64 304, i1 false), !alias.scope !10000000
  %v8786 = load i64, ptr %slot65, align 8
  %v8787 = load i64, ptr %slot52, align 8
  %p8788 = inttoptr i64 %v8787 to ptr
  store i64 %v8786, ptr %p8788, align 8, !alias.scope !3, !noalias !4
  %v8789 = load i64, ptr %slot52, align 8
  %p8790 = inttoptr i64 %v8789 to ptr
  %ld8791 = load i64, ptr %p8790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8791, ptr %slot1605, align 8
  %v8792 = load i64, ptr %slot1605, align 8
  %op8793 = add i64 %v8792, 32
  store i64 %op8793, ptr %slot1606, align 8
  %v8794 = load i64, ptr %slot1606, align 8
  %v8795 = load i64, ptr %slot52, align 8
  %p8796 = inttoptr i64 %v8795 to ptr
  store i64 %v8794, ptr %p8796, align 8, !alias.scope !3, !noalias !4
  %v8797 = load i64, ptr %slot20, align 8
  %p8798 = inttoptr i64 %v8797 to ptr
  %ld8799 = load i32, ptr %p8798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8799, ptr %slot1607, align 8
  %v8800 = load i32, ptr %slot1607, align 8
  %cv8801 = zext i32 %v8800 to i64
  %cond8802 = icmp ne i64 %cv8801, 0
  br i1 %cond8802, label %bb_rcslotdrop2619, label %bb_rcslotdone2619
bb_rcslotdrop2619:
  %v8803 = load i64, ptr %slot20, align 8
  %p8804 = inttoptr i64 %v8803 to ptr
  store i32 0, ptr %p8804, align 4, !alias.scope !3, !noalias !4
  %v8805 = load i64, ptr %slot49, align 8
  store i64 %v8805, ptr %slot1608, align 8
  %v8806 = load i64, ptr %slot21, align 8
  %p8807 = inttoptr i64 %v8806 to ptr
  %ld8808 = load i32, ptr %p8807, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8808, ptr %slot1609, align 8
  %v8809 = load i32, ptr %slot1609, align 8
  %op8810 = and i32 %v8809, 28
  store i32 %op8810, ptr %slot1610, align 8
  %v8811 = load i32, ptr %slot1610, align 8
  %cv8812 = zext i32 %v8811 to i64
  %cond8813 = icmp ne i64 %cv8812, 0
  br i1 %cond8813, label %bb_rcslotrole2619, label %bb_rcslotowner2619
bb_rcslotrole2619:
  %v8814 = load i64, ptr %slot73, align 8
  store i64 %v8814, ptr %slot1611, align 8
  %v8815 = load i64, ptr %slot1611, align 8
  %v8816 = load i64, ptr %slot1608, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8815, i64 %v8816) nomerge, !dbg !198
  br label %bb_rcslotdone2619
bb_rcslotowner2619:
  %v8817 = load i64, ptr %slot73, align 8
  store i64 %v8817, ptr %slot1612, align 8
  %v8818 = load i64, ptr %slot1612, align 8
  %v8819 = load i64, ptr %slot1608, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8818, i64 %v8819) nomerge, !dbg !198
  br label %bb_rcslotdone2619
bb_rcslotdone2619:
  %v8820 = load i64, ptr %slot36, align 8
  %p8821 = inttoptr i64 %v8820 to ptr
  %ld8822 = load i64, ptr %p8821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8822, ptr %slot1613, align 8
  %v8823 = load i64, ptr %slot1613, align 8
  %op8824 = add i64 %v8823, 32
  store i64 %op8824, ptr %slot1614, align 8
  %v8825 = load i64, ptr %slot49, align 8
  store i64 %v8825, ptr %slot1615, align 8
  %v8826 = load i64, ptr %slot1614, align 8
  %v8827 = load i64, ptr %slot1615, align 8
  %p8828 = inttoptr i64 %v8826 to ptr
  %p8829 = inttoptr i64 %v8827 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8829, ptr %p8828, i64 208, i1 false), !alias.scope !10000000
  %v8830 = load i64, ptr %slot1614, align 8
  %p8831 = inttoptr i64 %v8830 to ptr
  call void @llvm.memset.p0.i64(ptr %p8831, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !198
  %v8832 = load i64, ptr %slot20, align 8
  %p8833 = inttoptr i64 %v8832 to ptr
  store i32 1, ptr %p8833, align 4, !alias.scope !3, !noalias !4
  %v8834 = load i64, ptr %slot49, align 8
  %v8835 = load i64, ptr %slot52, align 8
  %p8836 = inttoptr i64 %v8835 to ptr
  store i64 %v8834, ptr %p8836, align 8, !alias.scope !3, !noalias !4
  %v8837 = load i64, ptr %slot52, align 8
  %p8838 = inttoptr i64 %v8837 to ptr
  %ld8839 = load i64, ptr %p8838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8839, ptr %slot1616, align 8
  %v8840 = load i64, ptr %slot1, align 8
  %v8841 = load i64, ptr %slot1616, align 8
  %call8842 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v8840, i64 %v8841) nomerge, !dbg !200
  store { i64, i64 } %call8842, ptr %callresult1618, align 8
  %addr8843 = ptrtoint ptr %callresult1618 to i64
  store i64 %addr8843, ptr %slot1617, align 8
  %v8844 = load i64, ptr %slot1617, align 8
  %v8845 = load i64, ptr %slot52, align 8
  %p8846 = inttoptr i64 %v8845 to ptr
  store i64 %v8844, ptr %p8846, align 8, !alias.scope !3, !noalias !4
  %v8847 = load i64, ptr %slot24, align 8
  %p8848 = inttoptr i64 %v8847 to ptr
  %ld8849 = load i32, ptr %p8848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8849, ptr %slot1619, align 8
  %v8850 = load i32, ptr %slot1619, align 8
  %cv8851 = zext i32 %v8850 to i64
  %cond8852 = icmp ne i64 %cv8851, 0
  br i1 %cond8852, label %bb_rcslotdrop2634, label %bb_rcslotdone2634
bb_rcslotdrop2634:
  %v8853 = load i64, ptr %slot24, align 8
  %p8854 = inttoptr i64 %v8853 to ptr
  store i32 0, ptr %p8854, align 4, !alias.scope !3, !noalias !4
  %v8855 = load i64, ptr %slot30, align 8
  store i64 %v8855, ptr %slot1620, align 8
  %v8856 = load i64, ptr %slot25, align 8
  %p8857 = inttoptr i64 %v8856 to ptr
  %ld8858 = load i32, ptr %p8857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8858, ptr %slot1621, align 8
  %v8859 = load i32, ptr %slot1621, align 8
  %op8860 = and i32 %v8859, 28
  store i32 %op8860, ptr %slot1622, align 8
  %v8861 = load i32, ptr %slot1622, align 8
  %cv8862 = zext i32 %v8861 to i64
  %cond8863 = icmp ne i64 %cv8862, 0
  br i1 %cond8863, label %bb_rcslotrole2634, label %bb_rcslotowner2634
bb_rcslotrole2634:
  %v8864 = load i64, ptr %slot73, align 8
  store i64 %v8864, ptr %slot1623, align 8
  %v8865 = load i64, ptr %slot1623, align 8
  %v8866 = load i64, ptr %slot1620, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8865, i64 %v8866) nomerge, !dbg !200
  br label %bb_rcslotdone2634
bb_rcslotowner2634:
  %v8867 = load i64, ptr %slot73, align 8
  store i64 %v8867, ptr %slot1624, align 8
  %v8868 = load i64, ptr %slot1624, align 8
  %v8869 = load i64, ptr %slot1620, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8868, i64 %v8869) nomerge, !dbg !200
  br label %bb_rcslotdone2634
bb_rcslotdone2634:
  %v8870 = load i64, ptr %slot52, align 8
  %p8871 = inttoptr i64 %v8870 to ptr
  %ld8872 = load i64, ptr %p8871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8872, ptr %slot1625, align 8
  %v8873 = load i64, ptr %slot1625, align 8
  %v8874 = load i64, ptr %slot50, align 8
  %p8875 = inttoptr i64 %v8873 to ptr
  %p8876 = inttoptr i64 %v8874 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8876, ptr %p8875, i64 16, i1 false)
  %v8877 = load i64, ptr %slot36, align 8
  %p8878 = inttoptr i64 %v8877 to ptr
  %ld8879 = load i64, ptr %p8878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8879, ptr %slot1626, align 8
  %v8880 = load i64, ptr %slot1626, align 8
  %op8881 = add i64 %v8880, 32
  store i64 %op8881, ptr %slot1627, align 8
  %v8882 = load i64, ptr %slot49, align 8
  store i64 %v8882, ptr %slot1628, align 8
  %v8883 = load i64, ptr %slot1628, align 8
  %v8884 = load i64, ptr %slot1627, align 8
  %p8885 = inttoptr i64 %v8883 to ptr
  %p8886 = inttoptr i64 %v8884 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8886, ptr %p8885, i64 208, i1 false), !alias.scope !10000000
  %v8887 = load i64, ptr %slot1628, align 8
  %p8888 = inttoptr i64 %v8887 to ptr
  call void @llvm.memset.p0.i64(ptr %p8888, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !202
  %v8889 = load i64, ptr %slot20, align 8
  %p8890 = inttoptr i64 %v8889 to ptr
  store i32 0, ptr %p8890, align 4, !alias.scope !3, !noalias !4
  %v8891 = load i64, ptr %slot52, align 8
  %p8892 = inttoptr i64 %v8891 to ptr
  store i64 0, ptr %p8892, align 8, !alias.scope !3, !noalias !4
  %v8893 = load i64, ptr %slot36, align 8
  %p8894 = inttoptr i64 %v8893 to ptr
  %ld8895 = load i64, ptr %p8894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8895, ptr %slot1629, align 8
  %v8896 = load i64, ptr %slot1629, align 8
  %v8897 = load i64, ptr %slot66, align 8
  %p8898 = inttoptr i64 %v8896 to ptr
  %p8899 = inttoptr i64 %v8897 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8899, ptr %p8898, i64 304, i1 false), !alias.scope !10000000
  %v8900 = load i64, ptr %slot66, align 8
  %v8901 = load i64, ptr %slot52, align 8
  %p8902 = inttoptr i64 %v8901 to ptr
  store i64 %v8900, ptr %p8902, align 8, !alias.scope !3, !noalias !4
  %v8903 = load i64, ptr %slot52, align 8
  %p8904 = inttoptr i64 %v8903 to ptr
  %ld8905 = load i64, ptr %p8904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8905, ptr %slot1630, align 8
  %v8906 = load i64, ptr %slot1630, align 8
  %op8907 = add i64 %v8906, 32
  store i64 %op8907, ptr %slot1631, align 8
  %v8908 = load i64, ptr %slot1631, align 8
  %v8909 = load i64, ptr %slot52, align 8
  %p8910 = inttoptr i64 %v8909 to ptr
  store i64 %v8908, ptr %p8910, align 8, !alias.scope !3, !noalias !4
  %v8911 = load i64, ptr %slot22, align 8
  %p8912 = inttoptr i64 %v8911 to ptr
  %ld8913 = load i32, ptr %p8912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8913, ptr %slot1632, align 8
  %v8914 = load i32, ptr %slot1632, align 8
  %cv8915 = zext i32 %v8914 to i64
  %cond8916 = icmp ne i64 %cv8915, 0
  br i1 %cond8916, label %bb_rcslotdrop2651, label %bb_rcslotdone2651
bb_rcslotdrop2651:
  %v8917 = load i64, ptr %slot22, align 8
  %p8918 = inttoptr i64 %v8917 to ptr
  store i32 0, ptr %p8918, align 4, !alias.scope !3, !noalias !4
  %v8919 = load i64, ptr %slot51, align 8
  store i64 %v8919, ptr %slot1633, align 8
  %v8920 = load i64, ptr %slot23, align 8
  %p8921 = inttoptr i64 %v8920 to ptr
  %ld8922 = load i32, ptr %p8921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8922, ptr %slot1634, align 8
  %v8923 = load i32, ptr %slot1634, align 8
  %op8924 = and i32 %v8923, 28
  store i32 %op8924, ptr %slot1635, align 8
  %v8925 = load i32, ptr %slot1635, align 8
  %cv8926 = zext i32 %v8925 to i64
  %cond8927 = icmp ne i64 %cv8926, 0
  br i1 %cond8927, label %bb_rcslotrole2651, label %bb_rcslotowner2651
bb_rcslotrole2651:
  %v8928 = load i64, ptr %slot73, align 8
  store i64 %v8928, ptr %slot1636, align 8
  %v8929 = load i64, ptr %slot1636, align 8
  %v8930 = load i64, ptr %slot1633, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8929, i64 %v8930) nomerge, !dbg !204
  br label %bb_rcslotdone2651
bb_rcslotowner2651:
  %v8931 = load i64, ptr %slot73, align 8
  store i64 %v8931, ptr %slot1637, align 8
  %v8932 = load i64, ptr %slot1637, align 8
  %v8933 = load i64, ptr %slot1633, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8932, i64 %v8933) nomerge, !dbg !204
  br label %bb_rcslotdone2651
bb_rcslotdone2651:
  %v8934 = load i64, ptr %slot36, align 8
  %p8935 = inttoptr i64 %v8934 to ptr
  %ld8936 = load i64, ptr %p8935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8936, ptr %slot1638, align 8
  %v8937 = load i64, ptr %slot1638, align 8
  %op8938 = add i64 %v8937, 32
  store i64 %op8938, ptr %slot1639, align 8
  %v8939 = load i64, ptr %slot51, align 8
  store i64 %v8939, ptr %slot1640, align 8
  %v8940 = load i64, ptr %slot1639, align 8
  %v8941 = load i64, ptr %slot1640, align 8
  %p8942 = inttoptr i64 %v8940 to ptr
  %p8943 = inttoptr i64 %v8941 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8943, ptr %p8942, i64 208, i1 false), !alias.scope !10000000
  %v8944 = load i64, ptr %slot1639, align 8
  %p8945 = inttoptr i64 %v8944 to ptr
  call void @llvm.memset.p0.i64(ptr %p8945, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !204
  %v8946 = load i64, ptr %slot22, align 8
  %p8947 = inttoptr i64 %v8946 to ptr
  store i32 1, ptr %p8947, align 4, !alias.scope !3, !noalias !4
  %v8948 = load i64, ptr %slot51, align 8
  %v8949 = load i64, ptr %slot52, align 8
  %p8950 = inttoptr i64 %v8949 to ptr
  store i64 %v8948, ptr %p8950, align 8, !alias.scope !3, !noalias !4
  %v8951 = load i64, ptr %slot50, align 8
  %v8952 = load i64, ptr %slot53, align 8
  %p8953 = inttoptr i64 %v8952 to ptr
  store i64 %v8951, ptr %p8953, align 8, !alias.scope !3, !noalias !4
  %v8954 = load i64, ptr %slot52, align 8
  %p8955 = inttoptr i64 %v8954 to ptr
  %ld8956 = load i64, ptr %p8955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8956, ptr %slot1641, align 8
  %v8957 = load i64, ptr %slot53, align 8
  %p8958 = inttoptr i64 %v8957 to ptr
  %ld8959 = load i64, ptr %p8958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8959, ptr %slot1642, align 8
  %v8960 = load i64, ptr %slot1, align 8
  %v8961 = load i64, ptr %slot1641, align 8
  %v8962 = load i64, ptr %slot1642, align 8
  %call8963 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v8960, i64 %v8961, i64 %v8962) nomerge, !dbg !206
  store i64 %call8963, ptr %slot1643, align 8
  %v8964 = load i64, ptr %slot1643, align 8
  %v8965 = load i64, ptr %slot52, align 8
  %p8966 = inttoptr i64 %v8965 to ptr
  store i64 %v8964, ptr %p8966, align 8, !alias.scope !3, !noalias !4
  %v8967 = load i64, ptr %slot24, align 8
  %p8968 = inttoptr i64 %v8967 to ptr
  %ld8969 = load i32, ptr %p8968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8969, ptr %slot1644, align 8
  %v8970 = load i32, ptr %slot1644, align 8
  %cv8971 = zext i32 %v8970 to i64
  %cond8972 = icmp ne i64 %cv8971, 0
  br i1 %cond8972, label %bb_rcslotdrop2667, label %bb_rcslotdone2667
bb_rcslotdrop2667:
  %v8973 = load i64, ptr %slot24, align 8
  %p8974 = inttoptr i64 %v8973 to ptr
  store i32 0, ptr %p8974, align 4, !alias.scope !3, !noalias !4
  %v8975 = load i64, ptr %slot30, align 8
  store i64 %v8975, ptr %slot1645, align 8
  %v8976 = load i64, ptr %slot25, align 8
  %p8977 = inttoptr i64 %v8976 to ptr
  %ld8978 = load i32, ptr %p8977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8978, ptr %slot1646, align 8
  %v8979 = load i32, ptr %slot1646, align 8
  %op8980 = and i32 %v8979, 28
  store i32 %op8980, ptr %slot1647, align 8
  %v8981 = load i32, ptr %slot1647, align 8
  %cv8982 = zext i32 %v8981 to i64
  %cond8983 = icmp ne i64 %cv8982, 0
  br i1 %cond8983, label %bb_rcslotrole2667, label %bb_rcslotowner2667
bb_rcslotrole2667:
  %v8984 = load i64, ptr %slot73, align 8
  store i64 %v8984, ptr %slot1648, align 8
  %v8985 = load i64, ptr %slot1648, align 8
  %v8986 = load i64, ptr %slot1645, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8985, i64 %v8986) nomerge, !dbg !206
  br label %bb_rcslotdone2667
bb_rcslotowner2667:
  %v8987 = load i64, ptr %slot73, align 8
  store i64 %v8987, ptr %slot1649, align 8
  %v8988 = load i64, ptr %slot1649, align 8
  %v8989 = load i64, ptr %slot1645, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8988, i64 %v8989) nomerge, !dbg !206
  br label %bb_rcslotdone2667
bb_rcslotdone2667:
  %v8990 = load i64, ptr %slot36, align 8
  %p8991 = inttoptr i64 %v8990 to ptr
  %ld8992 = load i64, ptr %p8991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8992, ptr %slot1650, align 8
  %v8993 = load i64, ptr %slot1650, align 8
  %op8994 = add i64 %v8993, 32
  store i64 %op8994, ptr %slot1651, align 8
  %v8995 = load i64, ptr %slot51, align 8
  store i64 %v8995, ptr %slot1652, align 8
  %v8996 = load i64, ptr %slot1652, align 8
  %v8997 = load i64, ptr %slot1651, align 8
  %p8998 = inttoptr i64 %v8996 to ptr
  %p8999 = inttoptr i64 %v8997 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8999, ptr %p8998, i64 208, i1 false), !alias.scope !10000000
  %v9000 = load i64, ptr %slot1652, align 8
  %p9001 = inttoptr i64 %v9000 to ptr
  call void @llvm.memset.p0.i64(ptr %p9001, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v9002 = load i64, ptr %slot22, align 8
  %p9003 = inttoptr i64 %v9002 to ptr
  store i32 0, ptr %p9003, align 4, !alias.scope !3, !noalias !4
  %v9004 = load i64, ptr %slot52, align 8
  %p9005 = inttoptr i64 %v9004 to ptr
  store i64 0, ptr %p9005, align 8, !alias.scope !3, !noalias !4
  %v9006 = load i64, ptr %slot52, align 8
  %p9007 = inttoptr i64 %v9006 to ptr
  store i64 0, ptr %p9007, align 8, !alias.scope !3, !noalias !4
  %v9008 = load i64, ptr %slot67, align 8
  store i64 %v9008, ptr %slot1653, align 8
  %v9009 = load i64, ptr %slot1653, align 8
  %p9010 = inttoptr i64 %v9009 to ptr
  store i64 0, ptr %p9010, align 8, !alias.scope !3, !noalias !4
  %v9011 = load i64, ptr %slot1653, align 8
  %p9013 = inttoptr i64 %v9011 to ptr
  %gep9014 = getelementptr i8, ptr %p9013, i64 8
  %op9012 = ptrtoint ptr %gep9014 to i64
  store i64 %op9012, ptr %slot1654, align 8
  %v9015 = load i64, ptr %slot1654, align 8
  %p9016 = inttoptr i64 %v9015 to ptr
  store i64 0, ptr %p9016, align 8, !alias.scope !3, !noalias !4
  %v9017 = load i64, ptr %slot1653, align 8
  %p9019 = inttoptr i64 %v9017 to ptr
  %gep9020 = getelementptr i8, ptr %p9019, i64 16
  %op9018 = ptrtoint ptr %gep9020 to i64
  store i64 %op9018, ptr %slot1655, align 8
  %v9021 = load i64, ptr %slot1655, align 8
  %p9022 = inttoptr i64 %v9021 to ptr
  store i64 0, ptr %p9022, align 8, !alias.scope !3, !noalias !4
  %v9023 = load i64, ptr %slot1653, align 8
  %p9024 = inttoptr i64 %v9023 to ptr
  store i32 0, ptr %p9024, align 4, !alias.scope !3, !noalias !4
  %v9025 = load i64, ptr %slot29, align 8
  %p9026 = inttoptr i64 %v9025 to ptr
  store i32 1, ptr %p9026, align 4, !alias.scope !3, !noalias !4
  %v9027 = load i64, ptr %slot52, align 8
  store i64 %v9027, ptr %slot1656, align 8
  %v9028 = load i64, ptr %slot1653, align 8
  %p9030 = inttoptr i64 %v9028 to ptr
  %gep9031 = getelementptr i8, ptr %p9030, i64 8
  %op9029 = ptrtoint ptr %gep9031 to i64
  store i64 %op9029, ptr %slot1657, align 8
  %v9032 = load i64, ptr %slot74, align 8
  store i64 %v9032, ptr %slot1658, align 8
  store i64 0, ptr %slot1659, align 8
  %v9033 = load i64, ptr %slot1653, align 8
  %v9034 = load i64, ptr %slot52, align 8
  %p9035 = inttoptr i64 %v9034 to ptr
  store i64 %v9033, ptr %p9035, align 8, !alias.scope !3, !noalias !4
  %v9036 = load i64, ptr %slot52, align 8
  %p9037 = inttoptr i64 %v9036 to ptr
  %ld9038 = load i64, ptr %p9037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9038, ptr %slot1660, align 8
  %v9039 = load i64, ptr %slot30, align 8
  store i64 %v9039, ptr %slot1661, align 8
  %v9040 = load i64, ptr %slot1660, align 8
  %v9041 = load i64, ptr %slot1661, align 8
  %p9042 = inttoptr i64 %v9040 to ptr
  %p9043 = inttoptr i64 %v9041 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9043, ptr %p9042, i64 24, i1 false)
  %v9044 = load i64, ptr %slot25, align 8
  %p9045 = inttoptr i64 %v9044 to ptr
  store i32 2, ptr %p9045, align 4, !alias.scope !3, !noalias !4
  %v9046 = load i64, ptr %slot24, align 8
  %p9047 = inttoptr i64 %v9046 to ptr
  store i32 1, ptr %p9047, align 4, !alias.scope !3, !noalias !4
  %v9048 = load i64, ptr %slot1661, align 8
  %v9049 = load i64, ptr %slot52, align 8
  %p9050 = inttoptr i64 %v9049 to ptr
  store i64 %v9048, ptr %p9050, align 8, !alias.scope !3, !noalias !4
  %v9051 = load i64, ptr %slot52, align 8
  %p9052 = inttoptr i64 %v9051 to ptr
  %ld9053 = load i64, ptr %p9052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9053, ptr %slot1662, align 8
  %v9054 = load i64, ptr %slot52, align 8
  %p9055 = inttoptr i64 %v9054 to ptr
  %ld9056 = load i64, ptr %p9055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9056, ptr %slot1663, align 8
  %v9057 = load i64, ptr %slot32, align 8
  store i64 %v9057, ptr %slot1664, align 8
  %v9058 = load i64, ptr %slot74, align 8
  store i64 %v9058, ptr %slot1665, align 8
  %v9059 = load i64, ptr %slot73, align 8
  %v9060 = load i64, ptr %slot1664, align 8
  %v9061 = load i64, ptr %slot1663, align 8
  %v9062 = load i64, ptr %slot1665, align 8
  %cv9063 = trunc i64 %v9062 to i32
  %call9064 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v9059, i64 %v9060, i64 %v9061, i32 %cv9063) nomerge, !dbg !210
  store i32 %call9064, ptr %slot1666, align 8
  %v9065 = load i32, ptr %slot1666, align 8
  %cv9066 = zext i32 %v9065 to i64
  %cond9067 = icmp ne i64 %cv9066, 0
  br i1 %cond9067, label %bb_rcsuccess2696, label %bb_rcfailure2696
bb_rcfailure2696:
  %v9068 = load i64, ptr %slot73, align 8
  %p9069 = inttoptr i64 %v9068 to ptr
  %call9070 = call i32 @myl_rc_take_failure(ptr %p9069) nomerge, !dbg !210
  store i32 %call9070, ptr %slot1667, align 8
  %v9071 = load i64, ptr %slot1, align 8
  %p9072 = inttoptr i64 %v9071 to ptr
  %v9073 = load i32, ptr %slot1667, align 8
  %call9074 = call i32 @myl_qbe_rc_status(ptr %p9072, i32 %v9073) nomerge, !dbg !210
  store i32 %call9074, ptr %slot1668, align 8
  br label %bb_failure
bb_rcsuccess2696:
  %v9075 = load i64, ptr %slot24, align 8
  %p9076 = inttoptr i64 %v9075 to ptr
  store i32 0, ptr %p9076, align 4, !alias.scope !3, !noalias !4
  %v9077 = load i64, ptr %slot28, align 8
  %p9078 = inttoptr i64 %v9077 to ptr
  store i32 2, ptr %p9078, align 4, !alias.scope !3, !noalias !4
  %v9079 = load i64, ptr %slot27, align 8
  %p9080 = inttoptr i64 %v9079 to ptr
  store i32 1, ptr %p9080, align 4, !alias.scope !3, !noalias !4
  %v9081 = load i64, ptr %slot32, align 8
  store i64 %v9081, ptr %slot1669, align 8
  %v9082 = load i64, ptr %slot27, align 8
  %p9083 = inttoptr i64 %v9082 to ptr
  store i32 0, ptr %p9083, align 4, !alias.scope !3, !noalias !4
  %v9084 = load i64, ptr %slot33, align 8
  %p9086 = inttoptr i64 %v9084 to ptr
  %gep9087 = getelementptr i8, ptr %p9086, i64 24
  %op9085 = ptrtoint ptr %gep9087 to i64
  store i64 %op9085, ptr %slot1670, align 8
  %v9088 = load i64, ptr %slot1670, align 8
  %p9089 = inttoptr i64 %v9088 to ptr
  %ld9090 = load i32, ptr %p9089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9090, ptr %slot1671, align 8
  %v9091 = load i32, ptr %slot1671, align 8
  %cv9092 = zext i32 %v9091 to i64
  %cond9093 = icmp ne i64 %cv9092, 0
  br i1 %cond9093, label %bb_rcscopesopen2706, label %bb_rcscopesclosed2706
bb_rcscopesopen2706:
  %v9094 = load i64, ptr %slot35, align 8
  %p9096 = inttoptr i64 %v9094 to ptr
  %gep9097 = getelementptr i8, ptr %p9096, i64 0
  %op9095 = ptrtoint ptr %gep9097 to i64
  store i64 %op9095, ptr %slot1672, align 8
  %v9098 = load i64, ptr %slot33, align 8
  %v9099 = load i64, ptr %slot1672, align 8
  %p9100 = inttoptr i64 %v9099 to ptr
  store i64 %v9098, ptr %p9100, align 8, !alias.scope !3, !noalias !4
  %v9101 = load i64, ptr %slot1, align 8
  %p9102 = inttoptr i64 %v9101 to ptr
  %v9103 = load i64, ptr %slot35, align 8
  %p9104 = inttoptr i64 %v9103 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p9102, ptr %p9104, i64 1) nomerge, !dbg !210
  br label %bb_rcscopesclosed2706
bb_rcscopesclosed2706:
  %v9105 = load i64, ptr %slot24, align 8
  %p9106 = inttoptr i64 %v9105 to ptr
  %ld9107 = load i32, ptr %p9106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9107, ptr %slot1673, align 8
  %v9108 = load i32, ptr %slot1673, align 8
  %cv9109 = zext i32 %v9108 to i64
  %cond9110 = icmp ne i64 %cv9109, 0
  br i1 %cond9110, label %bb_rcslotdrop2710, label %bb_rcslotdone2710
bb_rcslotdrop2710:
  %v9111 = load i64, ptr %slot24, align 8
  %p9112 = inttoptr i64 %v9111 to ptr
  store i32 0, ptr %p9112, align 4, !alias.scope !3, !noalias !4
  %v9113 = load i64, ptr %slot30, align 8
  store i64 %v9113, ptr %slot1674, align 8
  %v9114 = load i64, ptr %slot25, align 8
  %p9115 = inttoptr i64 %v9114 to ptr
  %ld9116 = load i32, ptr %p9115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9116, ptr %slot1675, align 8
  %v9117 = load i32, ptr %slot1675, align 8
  %op9118 = and i32 %v9117, 28
  store i32 %op9118, ptr %slot1676, align 8
  %v9119 = load i32, ptr %slot1676, align 8
  %cv9120 = zext i32 %v9119 to i64
  %cond9121 = icmp ne i64 %cv9120, 0
  br i1 %cond9121, label %bb_rcslotrole2710, label %bb_rcslotowner2710
bb_rcslotrole2710:
  %v9122 = load i64, ptr %slot73, align 8
  store i64 %v9122, ptr %slot1677, align 8
  %v9123 = load i64, ptr %slot1677, align 8
  %v9124 = load i64, ptr %slot1674, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v9123, i64 %v9124) nomerge, !dbg !210
  br label %bb_rcslotdone2710
bb_rcslotowner2710:
  %v9125 = load i64, ptr %slot73, align 8
  store i64 %v9125, ptr %slot1678, align 8
  %v9126 = load i64, ptr %slot1678, align 8
  %v9127 = load i64, ptr %slot1674, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v9126, i64 %v9127) nomerge, !dbg !210
  br label %bb_rcslotdone2710
bb_rcslotdone2710:
  %v9128 = load i64, ptr %slot22, align 8
  %p9129 = inttoptr i64 %v9128 to ptr
  %ld9130 = load i32, ptr %p9129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9130, ptr %slot1679, align 8
  %v9131 = load i32, ptr %slot1679, align 8
  %cv9132 = zext i32 %v9131 to i64
  %cond9133 = icmp ne i64 %cv9132, 0
  br i1 %cond9133, label %bb_rcslotdrop2737, label %bb_rcslotdone2737
bb_rcslotdrop2737:
  %v9134 = load i64, ptr %slot22, align 8
  %p9135 = inttoptr i64 %v9134 to ptr
  store i32 0, ptr %p9135, align 4, !alias.scope !3, !noalias !4
  %v9136 = load i64, ptr %slot51, align 8
  store i64 %v9136, ptr %slot1680, align 8
  %v9137 = load i64, ptr %slot23, align 8
  %p9138 = inttoptr i64 %v9137 to ptr
  %ld9139 = load i32, ptr %p9138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9139, ptr %slot1681, align 8
  %v9140 = load i32, ptr %slot1681, align 8
  %op9141 = and i32 %v9140, 28
  store i32 %op9141, ptr %slot1682, align 8
  %v9142 = load i32, ptr %slot1682, align 8
  %cv9143 = zext i32 %v9142 to i64
  %cond9144 = icmp ne i64 %cv9143, 0
  br i1 %cond9144, label %bb_rcslotrole2737, label %bb_rcslotowner2737
bb_rcslotrole2737:
  %v9145 = load i64, ptr %slot73, align 8
  store i64 %v9145, ptr %slot1683, align 8
  %v9146 = load i64, ptr %slot1683, align 8
  %v9147 = load i64, ptr %slot1680, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v9146, i64 %v9147) nomerge, !dbg !210
  br label %bb_rcslotdone2737
bb_rcslotowner2737:
  %v9148 = load i64, ptr %slot73, align 8
  store i64 %v9148, ptr %slot1684, align 8
  %v9149 = load i64, ptr %slot1684, align 8
  %v9150 = load i64, ptr %slot1680, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v9149, i64 %v9150) nomerge, !dbg !210
  br label %bb_rcslotdone2737
bb_rcslotdone2737:
  %v9151 = load i64, ptr %slot20, align 8
  %p9152 = inttoptr i64 %v9151 to ptr
  %ld9153 = load i32, ptr %p9152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9153, ptr %slot1685, align 8
  %v9154 = load i32, ptr %slot1685, align 8
  %cv9155 = zext i32 %v9154 to i64
  %cond9156 = icmp ne i64 %cv9155, 0
  br i1 %cond9156, label %bb_rcslotdrop2764, label %bb_rcslotdone2764
bb_rcslotdrop2764:
  %v9157 = load i64, ptr %slot20, align 8
  %p9158 = inttoptr i64 %v9157 to ptr
  store i32 0, ptr %p9158, align 4, !alias.scope !3, !noalias !4
  %v9159 = load i64, ptr %slot49, align 8
  store i64 %v9159, ptr %slot1686, align 8
  %v9160 = load i64, ptr %slot21, align 8
  %p9161 = inttoptr i64 %v9160 to ptr
  %ld9162 = load i32, ptr %p9161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9162, ptr %slot1687, align 8
  %v9163 = load i32, ptr %slot1687, align 8
  %op9164 = and i32 %v9163, 28
  store i32 %op9164, ptr %slot1688, align 8
  %v9165 = load i32, ptr %slot1688, align 8
  %cv9166 = zext i32 %v9165 to i64
  %cond9167 = icmp ne i64 %cv9166, 0
  br i1 %cond9167, label %bb_rcslotrole2764, label %bb_rcslotowner2764
bb_rcslotrole2764:
  %v9168 = load i64, ptr %slot73, align 8
  store i64 %v9168, ptr %slot1689, align 8
  %v9169 = load i64, ptr %slot1689, align 8
  %v9170 = load i64, ptr %slot1686, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v9169, i64 %v9170) nomerge, !dbg !210
  br label %bb_rcslotdone2764
bb_rcslotowner2764:
  %v9171 = load i64, ptr %slot73, align 8
  store i64 %v9171, ptr %slot1690, align 8
  %v9172 = load i64, ptr %slot1690, align 8
  %v9173 = load i64, ptr %slot1686, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v9172, i64 %v9173) nomerge, !dbg !210
  br label %bb_rcslotdone2764
bb_rcslotdone2764:
  %v9174 = load i64, ptr %slot18, align 8
  %p9175 = inttoptr i64 %v9174 to ptr
  %ld9176 = load i32, ptr %p9175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9176, ptr %slot1691, align 8
  %v9177 = load i32, ptr %slot1691, align 8
  %cv9178 = zext i32 %v9177 to i64
  %cond9179 = icmp ne i64 %cv9178, 0
  br i1 %cond9179, label %bb_rcslotdrop2773, label %bb_rcslotdone2773
bb_rcslotdrop2773:
  %v9180 = load i64, ptr %slot18, align 8
  %p9181 = inttoptr i64 %v9180 to ptr
  store i32 0, ptr %p9181, align 4, !alias.scope !3, !noalias !4
  %v9182 = load i64, ptr %slot47, align 8
  store i64 %v9182, ptr %slot1692, align 8
  %v9183 = load i64, ptr %slot19, align 8
  %p9184 = inttoptr i64 %v9183 to ptr
  %ld9185 = load i32, ptr %p9184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9185, ptr %slot1693, align 8
  %v9186 = load i32, ptr %slot1693, align 8
  %op9187 = and i32 %v9186, 28
  store i32 %op9187, ptr %slot1694, align 8
  %v9188 = load i32, ptr %slot1694, align 8
  %cv9189 = zext i32 %v9188 to i64
  %cond9190 = icmp ne i64 %cv9189, 0
  br i1 %cond9190, label %bb_rcslotrole2773, label %bb_rcslotowner2773
bb_rcslotrole2773:
  %v9191 = load i64, ptr %slot73, align 8
  store i64 %v9191, ptr %slot1695, align 8
  %v9192 = load i64, ptr %slot1695, align 8
  %v9193 = load i64, ptr %slot1692, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v9192, i64 %v9193) nomerge, !dbg !210
  br label %bb_rcslotdone2773
bb_rcslotowner2773:
  %v9194 = load i64, ptr %slot73, align 8
  store i64 %v9194, ptr %slot1696, align 8
  %v9195 = load i64, ptr %slot1696, align 8
  %v9196 = load i64, ptr %slot1692, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v9195, i64 %v9196) nomerge, !dbg !210
  br label %bb_rcslotdone2773
bb_rcslotdone2773:
  %v9197 = load i64, ptr %slot16, align 8
  %p9198 = inttoptr i64 %v9197 to ptr
  %ld9199 = load i32, ptr %p9198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9199, ptr %slot1697, align 8
  %v9200 = load i32, ptr %slot1697, align 8
  %cv9201 = zext i32 %v9200 to i64
  %cond9202 = icmp ne i64 %cv9201, 0
  br i1 %cond9202, label %bb_rcslotdrop2819, label %bb_rcslotdone2819
bb_rcslotdrop2819:
  %v9203 = load i64, ptr %slot16, align 8
  %p9204 = inttoptr i64 %v9203 to ptr
  store i32 0, ptr %p9204, align 4, !alias.scope !3, !noalias !4
  %v9205 = load i64, ptr %slot45, align 8
  store i64 %v9205, ptr %slot1698, align 8
  %v9206 = load i64, ptr %slot17, align 8
  %p9207 = inttoptr i64 %v9206 to ptr
  %ld9208 = load i32, ptr %p9207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9208, ptr %slot1699, align 8
  %v9209 = load i32, ptr %slot1699, align 8
  %op9210 = and i32 %v9209, 28
  store i32 %op9210, ptr %slot1700, align 8
  %v9211 = load i32, ptr %slot1700, align 8
  %cv9212 = zext i32 %v9211 to i64
  %cond9213 = icmp ne i64 %cv9212, 0
  br i1 %cond9213, label %bb_rcslotrole2819, label %bb_rcslotowner2819
bb_rcslotrole2819:
  %v9214 = load i64, ptr %slot73, align 8
  store i64 %v9214, ptr %slot1701, align 8
  %v9215 = load i64, ptr %slot1701, align 8
  %v9216 = load i64, ptr %slot1698, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v9215, i64 %v9216) nomerge, !dbg !210
  br label %bb_rcslotdone2819
bb_rcslotowner2819:
  %v9217 = load i64, ptr %slot73, align 8
  store i64 %v9217, ptr %slot1702, align 8
  %v9218 = load i64, ptr %slot1702, align 8
  %v9219 = load i64, ptr %slot1698, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v9218, i64 %v9219) nomerge, !dbg !210
  br label %bb_rcslotdone2819
bb_rcslotdone2819:
  %v9220 = load i64, ptr %slot14, align 8
  %p9221 = inttoptr i64 %v9220 to ptr
  %ld9222 = load i32, ptr %p9221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9222, ptr %slot1703, align 8
  %v9223 = load i32, ptr %slot1703, align 8
  %cv9224 = zext i32 %v9223 to i64
  %cond9225 = icmp ne i64 %cv9224, 0
  br i1 %cond9225, label %bb_rcslotdrop2828, label %bb_rcslotdone2828
bb_rcslotdrop2828:
  %v9226 = load i64, ptr %slot14, align 8
  %p9227 = inttoptr i64 %v9226 to ptr
  store i32 0, ptr %p9227, align 4, !alias.scope !3, !noalias !4
  %v9228 = load i64, ptr %slot44, align 8
  store i64 %v9228, ptr %slot1704, align 8
  %v9229 = load i64, ptr %slot15, align 8
  %p9230 = inttoptr i64 %v9229 to ptr
  %ld9231 = load i32, ptr %p9230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9231, ptr %slot1705, align 8
  %v9232 = load i32, ptr %slot1705, align 8
  %op9233 = and i32 %v9232, 28
  store i32 %op9233, ptr %slot1706, align 8
  %v9234 = load i32, ptr %slot1706, align 8
  %cv9235 = zext i32 %v9234 to i64
  %cond9236 = icmp ne i64 %cv9235, 0
  br i1 %cond9236, label %bb_rcslotrole2828, label %bb_rcslotowner2828
bb_rcslotrole2828:
  %v9237 = load i64, ptr %slot73, align 8
  store i64 %v9237, ptr %slot1707, align 8
  %v9238 = load i64, ptr %slot1707, align 8
  %v9239 = load i64, ptr %slot1704, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v9238, i64 %v9239) nomerge, !dbg !210
  br label %bb_rcslotdone2828
bb_rcslotowner2828:
  %v9240 = load i64, ptr %slot73, align 8
  store i64 %v9240, ptr %slot1708, align 8
  %v9241 = load i64, ptr %slot1708, align 8
  %v9242 = load i64, ptr %slot1704, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v9241, i64 %v9242) nomerge, !dbg !210
  br label %bb_rcslotdone2828
bb_rcslotdone2828:
  %v9243 = load i64, ptr %slot12, align 8
  %p9244 = inttoptr i64 %v9243 to ptr
  %ld9245 = load i32, ptr %p9244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9245, ptr %slot1709, align 8
  %v9246 = load i32, ptr %slot1709, align 8
  %cv9247 = zext i32 %v9246 to i64
  %cond9248 = icmp ne i64 %cv9247, 0
  br i1 %cond9248, label %bb_rcslotdrop2837, label %bb_rcslotdone2837
bb_rcslotdrop2837:
  %v9249 = load i64, ptr %slot12, align 8
  %p9250 = inttoptr i64 %v9249 to ptr
  store i32 0, ptr %p9250, align 4, !alias.scope !3, !noalias !4
  %v9251 = load i64, ptr %slot43, align 8
  store i64 %v9251, ptr %slot1710, align 8
  %v9252 = load i64, ptr %slot13, align 8
  %p9253 = inttoptr i64 %v9252 to ptr
  %ld9254 = load i32, ptr %p9253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9254, ptr %slot1711, align 8
  %v9255 = load i32, ptr %slot1711, align 8
  %op9256 = and i32 %v9255, 28
  store i32 %op9256, ptr %slot1712, align 8
  %v9257 = load i32, ptr %slot1712, align 8
  %cv9258 = zext i32 %v9257 to i64
  %cond9259 = icmp ne i64 %cv9258, 0
  br i1 %cond9259, label %bb_rcslotrole2837, label %bb_rcslotowner2837
bb_rcslotrole2837:
  %v9260 = load i64, ptr %slot73, align 8
  store i64 %v9260, ptr %slot1713, align 8
  %v9261 = load i64, ptr %slot1713, align 8
  %v9262 = load i64, ptr %slot1710, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v9261, i64 %v9262) nomerge, !dbg !210
  br label %bb_rcslotdone2837
bb_rcslotowner2837:
  %v9263 = load i64, ptr %slot73, align 8
  store i64 %v9263, ptr %slot1714, align 8
  %v9264 = load i64, ptr %slot1714, align 8
  %v9265 = load i64, ptr %slot1710, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v9264, i64 %v9265) nomerge, !dbg !210
  br label %bb_rcslotdone2837
bb_rcslotdone2837:
  %v9266 = load i64, ptr %slot10, align 8
  %p9267 = inttoptr i64 %v9266 to ptr
  %ld9268 = load i32, ptr %p9267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9268, ptr %slot1715, align 8
  %v9269 = load i32, ptr %slot1715, align 8
  %cv9270 = zext i32 %v9269 to i64
  %cond9271 = icmp ne i64 %cv9270, 0
  br i1 %cond9271, label %bb_rcslotdrop2846, label %bb_rcslotdone2846
bb_rcslotdrop2846:
  %v9272 = load i64, ptr %slot10, align 8
  %p9273 = inttoptr i64 %v9272 to ptr
  store i32 0, ptr %p9273, align 4, !alias.scope !3, !noalias !4
  %v9274 = load i64, ptr %slot41, align 8
  store i64 %v9274, ptr %slot1716, align 8
  %v9275 = load i64, ptr %slot11, align 8
  %p9276 = inttoptr i64 %v9275 to ptr
  %ld9277 = load i32, ptr %p9276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9277, ptr %slot1717, align 8
  %v9278 = load i32, ptr %slot1717, align 8
  %op9279 = and i32 %v9278, 28
  store i32 %op9279, ptr %slot1718, align 8
  %v9280 = load i32, ptr %slot1718, align 8
  %cv9281 = zext i32 %v9280 to i64
  %cond9282 = icmp ne i64 %cv9281, 0
  br i1 %cond9282, label %bb_rcslotrole2846, label %bb_rcslotowner2846
bb_rcslotrole2846:
  %v9283 = load i64, ptr %slot73, align 8
  store i64 %v9283, ptr %slot1719, align 8
  %v9284 = load i64, ptr %slot1719, align 8
  %v9285 = load i64, ptr %slot1716, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v9284, i64 %v9285) nomerge, !dbg !210
  br label %bb_rcslotdone2846
bb_rcslotowner2846:
  %v9286 = load i64, ptr %slot73, align 8
  store i64 %v9286, ptr %slot1720, align 8
  %v9287 = load i64, ptr %slot1720, align 8
  %v9288 = load i64, ptr %slot1716, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v9287, i64 %v9288) nomerge, !dbg !210
  br label %bb_rcslotdone2846
bb_rcslotdone2846:
  %v9289 = load i64, ptr %slot8, align 8
  %p9290 = inttoptr i64 %v9289 to ptr
  %ld9291 = load i32, ptr %p9290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9291, ptr %slot1721, align 8
  %v9292 = load i32, ptr %slot1721, align 8
  %cv9293 = zext i32 %v9292 to i64
  %cond9294 = icmp ne i64 %cv9293, 0
  br i1 %cond9294, label %bb_rcslotdrop2855, label %bb_rcslotdone2855
bb_rcslotdrop2855:
  %v9295 = load i64, ptr %slot8, align 8
  %p9296 = inttoptr i64 %v9295 to ptr
  store i32 0, ptr %p9296, align 4, !alias.scope !3, !noalias !4
  %v9297 = load i64, ptr %slot40, align 8
  store i64 %v9297, ptr %slot1722, align 8
  %v9298 = load i64, ptr %slot9, align 8
  %p9299 = inttoptr i64 %v9298 to ptr
  %ld9300 = load i32, ptr %p9299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9300, ptr %slot1723, align 8
  %v9301 = load i32, ptr %slot1723, align 8
  %op9302 = and i32 %v9301, 28
  store i32 %op9302, ptr %slot1724, align 8
  %v9303 = load i32, ptr %slot1724, align 8
  %cv9304 = zext i32 %v9303 to i64
  %cond9305 = icmp ne i64 %cv9304, 0
  br i1 %cond9305, label %bb_rcslotrole2855, label %bb_rcslotowner2855
bb_rcslotrole2855:
  %v9306 = load i64, ptr %slot73, align 8
  store i64 %v9306, ptr %slot1725, align 8
  %v9307 = load i64, ptr %slot1725, align 8
  %v9308 = load i64, ptr %slot1722, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v9307, i64 %v9308) nomerge, !dbg !210
  br label %bb_rcslotdone2855
bb_rcslotowner2855:
  %v9309 = load i64, ptr %slot73, align 8
  store i64 %v9309, ptr %slot1726, align 8
  %v9310 = load i64, ptr %slot1726, align 8
  %v9311 = load i64, ptr %slot1722, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v9310, i64 %v9311) nomerge, !dbg !210
  br label %bb_rcslotdone2855
bb_rcslotdone2855:
  %v9312 = load i64, ptr %slot6, align 8
  %p9313 = inttoptr i64 %v9312 to ptr
  %ld9314 = load i32, ptr %p9313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9314, ptr %slot1727, align 8
  %v9315 = load i32, ptr %slot1727, align 8
  %cv9316 = zext i32 %v9315 to i64
  %cond9317 = icmp ne i64 %cv9316, 0
  br i1 %cond9317, label %bb_rcslotdrop2864, label %bb_rcslotdone2864
bb_rcslotdrop2864:
  %v9318 = load i64, ptr %slot6, align 8
  %p9319 = inttoptr i64 %v9318 to ptr
  store i32 0, ptr %p9319, align 4, !alias.scope !3, !noalias !4
  %v9320 = load i64, ptr %slot38, align 8
  store i64 %v9320, ptr %slot1728, align 8
  %v9321 = load i64, ptr %slot7, align 8
  %p9322 = inttoptr i64 %v9321 to ptr
  %ld9323 = load i32, ptr %p9322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9323, ptr %slot1729, align 8
  %v9324 = load i32, ptr %slot1729, align 8
  %op9325 = and i32 %v9324, 28
  store i32 %op9325, ptr %slot1730, align 8
  %v9326 = load i32, ptr %slot1730, align 8
  %cv9327 = zext i32 %v9326 to i64
  %cond9328 = icmp ne i64 %cv9327, 0
  br i1 %cond9328, label %bb_rcslotrole2864, label %bb_rcslotowner2864
bb_rcslotrole2864:
  %v9329 = load i64, ptr %slot73, align 8
  store i64 %v9329, ptr %slot1731, align 8
  %v9330 = load i64, ptr %slot1731, align 8
  %v9331 = load i64, ptr %slot1728, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v9330, i64 %v9331) nomerge, !dbg !210
  br label %bb_rcslotdone2864
bb_rcslotowner2864:
  %v9332 = load i64, ptr %slot73, align 8
  store i64 %v9332, ptr %slot1732, align 8
  %v9333 = load i64, ptr %slot1732, align 8
  %v9334 = load i64, ptr %slot1728, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v9333, i64 %v9334) nomerge, !dbg !210
  br label %bb_rcslotdone2864
bb_rcslotdone2864:
  %v9335 = load i64, ptr %slot1669, align 8
  %p9336 = inttoptr i64 %v9335 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p9336, i64 24, i1 false)
  ret void
bb_i157:
  %p9337 = inttoptr i64 ptrtoint (ptr @myl_lit_ae34ea25ba6543390a4fad13083ff6a513fffab9c9bddab170c1a5122079ec98 to i64) to ptr
  %ld9338 = load i64, ptr %p9337, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9338, ptr %slot1733, align 8
  %v9339 = load i64, ptr %slot1733, align 8
  %v9340 = load i64, ptr %slot52, align 8
  %p9341 = inttoptr i64 %v9340 to ptr
  store i64 %v9339, ptr %p9341, align 8, !alias.scope !3, !noalias !4
  %v9342 = load i64, ptr %slot52, align 8
  %p9343 = inttoptr i64 %v9342 to ptr
  %ld9344 = load i64, ptr %p9343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9344, ptr %slot1734, align 8
  %v9345 = load i64, ptr %slot1734, align 8
  %v9346 = load i64, ptr %slot31, align 8
  %p9347 = inttoptr i64 %v9346 to ptr
  store i64 %v9345, ptr %p9347, align 8, !alias.scope !3, !noalias !4
  %v9348 = load i64, ptr %slot31, align 8
  store i64 %v9348, ptr %slot1735, align 8
  %v9349 = load i64, ptr %slot32, align 8
  store i64 %v9349, ptr %slot1736, align 8
  %v9350 = load i64, ptr %slot1735, align 8
  %v9351 = load i64, ptr %slot1736, align 8
  %p9352 = inttoptr i64 %v9350 to ptr
  %p9353 = inttoptr i64 %v9351 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9353, ptr %p9352, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9354 = load i64, ptr %slot28, align 8
  %p9355 = inttoptr i64 %v9354 to ptr
  store i32 2, ptr %p9355, align 4, !alias.scope !3, !noalias !4
  %v9356 = load i64, ptr %slot27, align 8
  %p9357 = inttoptr i64 %v9356 to ptr
  store i32 1, ptr %p9357, align 4, !alias.scope !3, !noalias !4
  %v9358 = load i64, ptr %slot30, align 8
  store i64 %v9358, ptr %slot1737, align 8
  %v9359 = load i64, ptr %slot32, align 8
  store i64 %v9359, ptr %slot1738, align 8
  %v9360 = load i64, ptr %slot1738, align 8
  %v9361 = load i64, ptr %slot1737, align 8
  %p9362 = inttoptr i64 %v9360 to ptr
  %p9363 = inttoptr i64 %v9361 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9363, ptr %p9362, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9364 = load i64, ptr %slot25, align 8
  %p9365 = inttoptr i64 %v9364 to ptr
  store i32 2, ptr %p9365, align 4, !alias.scope !3, !noalias !4
  %v9366 = load i64, ptr %slot28, align 8
  %p9367 = inttoptr i64 %v9366 to ptr
  %ld9368 = load i32, ptr %p9367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9368, ptr %slot1739, align 8
  %v9369 = load i32, ptr %slot1739, align 8
  %v9370 = load i64, ptr %slot25, align 8
  %p9371 = inttoptr i64 %v9370 to ptr
  store i32 %v9369, ptr %p9371, align 4, !alias.scope !3, !noalias !4
  %v9372 = load i64, ptr %slot27, align 8
  %p9373 = inttoptr i64 %v9372 to ptr
  store i32 0, ptr %p9373, align 4, !alias.scope !3, !noalias !4
  %v9374 = load i64, ptr %slot24, align 8
  %p9375 = inttoptr i64 %v9374 to ptr
  store i32 1, ptr %p9375, align 4, !alias.scope !3, !noalias !4
  %v9376 = load i64, ptr %slot1737, align 8
  %p9377 = inttoptr i64 %v9376 to ptr
  %ld9378 = load i64, ptr %p9377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9378, ptr %slot1740, align 8
  %v9379 = load i64, ptr %slot1740, align 8
  %v9380 = load i64, ptr %slot52, align 8
  %p9381 = inttoptr i64 %v9380 to ptr
  store i64 %v9379, ptr %p9381, align 8, !alias.scope !3, !noalias !4
  %v9382 = load i64, ptr %slot37, align 8
  %p9383 = inttoptr i64 %v9382 to ptr
  %ld9384 = load i64, ptr %p9383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9384, ptr %slot1741, align 8
  %v9385 = load i64, ptr %slot1741, align 8
  %v9386 = load i64, ptr %slot53, align 8
  %p9387 = inttoptr i64 %v9386 to ptr
  store i64 %v9385, ptr %p9387, align 8, !alias.scope !3, !noalias !4
  %v9388 = load i64, ptr %slot53, align 8
  %p9389 = inttoptr i64 %v9388 to ptr
  %ld9390 = load i64, ptr %p9389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9390, ptr %slot1742, align 8
  %v9391 = load i64, ptr %slot1742, align 8
  %op9392 = add i64 %v9391, 8
  store i64 %op9392, ptr %slot1743, align 8
  %v9393 = load i64, ptr %slot1743, align 8
  %v9394 = load i64, ptr %slot53, align 8
  %p9395 = inttoptr i64 %v9394 to ptr
  store i64 %v9393, ptr %p9395, align 8, !alias.scope !3, !noalias !4
  %v9396 = load i64, ptr %slot53, align 8
  %p9397 = inttoptr i64 %v9396 to ptr
  %ld9398 = load i64, ptr %p9397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9398, ptr %slot1744, align 8
  %v9399 = load i64, ptr %slot1744, align 8
  %op9400 = add i64 %v9399, 24
  store i64 %op9400, ptr %slot1745, align 8
  %v9401 = load i64, ptr %slot1745, align 8
  %p9402 = inttoptr i64 %v9401 to ptr
  %ld9403 = load i64, ptr %p9402, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9403, ptr %slot1746, align 8
  %v9404 = load i64, ptr %slot1746, align 8
  %v9405 = load i64, ptr %slot53, align 8
  %p9406 = inttoptr i64 %v9405 to ptr
  store i64 %v9404, ptr %p9406, align 8, !alias.scope !3, !noalias !4
  %v9407 = load i64, ptr %slot52, align 8
  %p9408 = inttoptr i64 %v9407 to ptr
  %ld9409 = load i64, ptr %p9408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9409, ptr %slot1747, align 8
  %v9410 = load i64, ptr %slot53, align 8
  %p9411 = inttoptr i64 %v9410 to ptr
  %ld9412 = load i64, ptr %p9411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9412, ptr %slot1748, align 8
  %v9413 = load i64, ptr %slot1, align 8
  %v9414 = load i64, ptr %slot1747, align 8
  %v9415 = load i64, ptr %slot1748, align 8
  %call9416 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v9413, i64 %v9414, i64 %v9415) nomerge, !dbg !212
  store { i64, i64 } %call9416, ptr %callresult1750, align 8
  %addr9417 = ptrtoint ptr %callresult1750 to i64
  store i64 %addr9417, ptr %slot1749, align 8
  %v9418 = load i64, ptr %slot1749, align 8
  %v9419 = load i64, ptr %slot52, align 8
  %p9420 = inttoptr i64 %v9419 to ptr
  store i64 %v9418, ptr %p9420, align 8, !alias.scope !3, !noalias !4
  %v9421 = load i64, ptr %slot52, align 8
  %p9422 = inttoptr i64 %v9421 to ptr
  %ld9423 = load i64, ptr %p9422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9423, ptr %slot1751, align 8
  %v9424 = load i64, ptr %slot32, align 8
  store i64 %v9424, ptr %slot1752, align 8
  %v9425 = load i64, ptr %slot73, align 8
  %v9426 = load i64, ptr %slot1752, align 8
  %v9427 = load i64, ptr %slot1751, align 8
  %call9428 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v9425, i64 %v9426, i64 %v9427) nomerge, !dbg !212
  store i32 %call9428, ptr %slot1753, align 8
  %v9429 = load i32, ptr %slot1753, align 8
  %cv9430 = zext i32 %v9429 to i64
  %cond9431 = icmp ne i64 %cv9430, 0
  br i1 %cond9431, label %bb_rcsuccess2935, label %bb_rcfailure2935
bb_rcfailure2935:
  %v9432 = load i64, ptr %slot73, align 8
  %p9433 = inttoptr i64 %v9432 to ptr
  %call9434 = call i32 @myl_rc_take_failure(ptr %p9433) nomerge, !dbg !212
  store i32 %call9434, ptr %slot1754, align 8
  %v9435 = load i64, ptr %slot1, align 8
  %p9436 = inttoptr i64 %v9435 to ptr
  %v9437 = load i32, ptr %slot1754, align 8
  %call9438 = call i32 @myl_qbe_rc_status(ptr %p9436, i32 %v9437) nomerge, !dbg !212
  store i32 %call9438, ptr %slot1755, align 8
  br label %bb_failure
bb_rcsuccess2935:
  %v9439 = load i64, ptr %slot28, align 8
  %p9440 = inttoptr i64 %v9439 to ptr
  store i32 2, ptr %p9440, align 4, !alias.scope !3, !noalias !4
  %v9441 = load i64, ptr %slot28, align 8
  %p9442 = inttoptr i64 %v9441 to ptr
  store i32 16, ptr %p9442, align 4, !alias.scope !3, !noalias !4
  %v9443 = load i64, ptr %slot27, align 8
  %p9444 = inttoptr i64 %v9443 to ptr
  store i32 1, ptr %p9444, align 4, !alias.scope !3, !noalias !4
  %v9445 = load i64, ptr %slot24, align 8
  %p9446 = inttoptr i64 %v9445 to ptr
  %ld9447 = load i32, ptr %p9446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9447, ptr %slot1756, align 8
  %v9448 = load i32, ptr %slot1756, align 8
  %cv9449 = zext i32 %v9448 to i64
  %cond9450 = icmp ne i64 %cv9449, 0
  br i1 %cond9450, label %bb_rcslotdrop2943, label %bb_rcslotdone2943
bb_rcslotdrop2943:
  %v9451 = load i64, ptr %slot24, align 8
  %p9452 = inttoptr i64 %v9451 to ptr
  store i32 0, ptr %p9452, align 4, !alias.scope !3, !noalias !4
  %v9453 = load i64, ptr %slot30, align 8
  store i64 %v9453, ptr %slot1757, align 8
  %v9454 = load i64, ptr %slot25, align 8
  %p9455 = inttoptr i64 %v9454 to ptr
  %ld9456 = load i32, ptr %p9455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9456, ptr %slot1758, align 8
  %v9457 = load i32, ptr %slot1758, align 8
  %op9458 = and i32 %v9457, 28
  store i32 %op9458, ptr %slot1759, align 8
  %v9459 = load i32, ptr %slot1759, align 8
  %cv9460 = zext i32 %v9459 to i64
  %cond9461 = icmp ne i64 %cv9460, 0
  br i1 %cond9461, label %bb_rcslotrole2943, label %bb_rcslotowner2943
bb_rcslotrole2943:
  %v9462 = load i64, ptr %slot73, align 8
  store i64 %v9462, ptr %slot1760, align 8
  %v9463 = load i64, ptr %slot1757, align 8
  %p9464 = inttoptr i64 %v9463 to ptr
  %ld9465 = load i64, ptr %p9464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9465, ptr %slot1761, align 8
  %v9466 = load i64, ptr %slot1761, align 8
  %cmp9467 = icmp ne i64 %v9466, 0
  %cv9468 = zext i1 %cmp9467 to i32
  store i32 %cv9468, ptr %slot1762, align 8
  %v9469 = load i32, ptr %slot1762, align 8
  %cv9470 = zext i32 %v9469 to i64
  %cond9471 = icmp ne i64 %cv9470, 0
  br i1 %cond9471, label %bb_rcgnn2959, label %bb_rcgdone2959
bb_rcgnn2959:
  %v9472 = load i64, ptr %slot1761, align 8
  %op9473 = sub i64 %v9472, 16
  store i64 %op9473, ptr %slot1763, align 8
  %v9474 = load i64, ptr %slot1761, align 8
  %p9475 = inttoptr i64 %v9474 to ptr
  %rgep9476 = getelementptr i8, ptr %p9475, i64 -16
  %ld9477 = load i64, ptr %rgep9476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9477, ptr %slot1764, align 8
  %v9478 = load i64, ptr %slot1764, align 8
  %op9479 = and i64 %v9478, 4611686018427387906
  store i64 %op9479, ptr %slot1765, align 8
  %v9480 = load i64, ptr %slot1765, align 8
  %cmp9481 = icmp ne i64 %v9480, 0
  %cv9482 = zext i1 %cmp9481 to i32
  store i32 %cv9482, ptr %slot1766, align 8
  %v9483 = load i32, ptr %slot1766, align 8
  %cv9484 = zext i32 %v9483 to i64
  %cond9485 = icmp ne i64 %cv9484, 0
  br i1 %cond9485, label %bb_rcgclear2959, label %bb_rcgcounted2959
bb_rcgcounted2959:
  %v9486 = load i64, ptr %slot1761, align 8
  %op9487 = sub i64 %v9486, 24
  store i64 %op9487, ptr %slot1767, align 8
  %v9488 = load i64, ptr %slot1761, align 8
  %p9489 = inttoptr i64 %v9488 to ptr
  %rgep9490 = getelementptr i8, ptr %p9489, i64 -24
  %ld9491 = load i64, ptr %rgep9490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9491, ptr %slot1768, align 8
  %v9492 = load i64, ptr %slot1768, align 8
  %op9493 = sub i64 %v9492, 1
  store i64 %op9493, ptr %slot1769, align 8
  %v9494 = load i64, ptr %slot1769, align 8
  %cmp9495 = icmp eq i64 %v9494, 0
  %cv9496 = zext i1 %cmp9495 to i32
  store i32 %cv9496, ptr %slot1770, align 8
  %v9497 = load i32, ptr %slot1770, align 8
  %cv9498 = zext i32 %v9497 to i64
  %cond9499 = icmp ne i64 %cv9498, 0
  br i1 %cond9499, label %bb_rcglast2959, label %bb_rcgdec2959
bb_rcglast2959:
  %v9500 = load i64, ptr %slot1761, align 8
  %op9501 = sub i64 %v9500, 32
  store i64 %op9501, ptr %slot1771, align 8
  %v9502 = load i64, ptr %slot1761, align 8
  %p9503 = inttoptr i64 %v9502 to ptr
  %rgep9504 = getelementptr i8, ptr %p9503, i64 -32
  %ld9505 = load i64, ptr %rgep9504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9505, ptr %slot1772, align 8
  %v9506 = load i64, ptr %slot1772, align 8
  %cmp9507 = icmp ne i64 %v9506, 0
  %cv9508 = zext i1 %cmp9507 to i32
  store i32 %cv9508, ptr %slot1773, align 8
  %v9509 = load i32, ptr %slot1773, align 8
  %cv9510 = zext i32 %v9509 to i64
  %cond9511 = icmp ne i64 %cv9510, 0
  br i1 %cond9511, label %bb_rcgdec2959, label %bb_rcgslow2959
bb_rcgslow2959:
  %v9512 = load i64, ptr %slot1760, align 8
  %v9513 = load i64, ptr %slot1757, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9512, i64 %v9513) nomerge, !dbg !212
  br label %bb_rcgdone2959
bb_rcgdec2959:
  %v9514 = load i64, ptr %slot1769, align 8
  %v9515 = load i64, ptr %slot1761, align 8
  %p9516 = inttoptr i64 %v9515 to ptr
  %rgep9517 = getelementptr i8, ptr %p9516, i64 -24
  store i64 %v9514, ptr %rgep9517, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2959
bb_rcgclear2959:
  %v9518 = load i64, ptr %slot1757, align 8
  %p9519 = inttoptr i64 %v9518 to ptr
  store i64 0, ptr %p9519, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2959
bb_rcgdone2959:
  br label %bb_rcslotdone2943
bb_rcslotowner2943:
  %v9520 = load i64, ptr %slot73, align 8
  store i64 %v9520, ptr %slot1774, align 8
  %v9521 = load i64, ptr %slot1757, align 8
  %p9522 = inttoptr i64 %v9521 to ptr
  %ld9523 = load i64, ptr %p9522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9523, ptr %slot1775, align 8
  %v9524 = load i64, ptr %slot1775, align 8
  %cmp9525 = icmp ne i64 %v9524, 0
  %cv9526 = zext i1 %cmp9525 to i32
  store i32 %cv9526, ptr %slot1776, align 8
  %v9527 = load i32, ptr %slot1776, align 8
  %cv9528 = zext i32 %v9527 to i64
  %cond9529 = icmp ne i64 %cv9528, 0
  br i1 %cond9529, label %bb_rcgnn2974, label %bb_rcgdone2974
bb_rcgnn2974:
  %v9530 = load i64, ptr %slot1775, align 8
  %op9531 = sub i64 %v9530, 16
  store i64 %op9531, ptr %slot1777, align 8
  %v9532 = load i64, ptr %slot1775, align 8
  %p9533 = inttoptr i64 %v9532 to ptr
  %rgep9534 = getelementptr i8, ptr %p9533, i64 -16
  %ld9535 = load i64, ptr %rgep9534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9535, ptr %slot1778, align 8
  %v9536 = load i64, ptr %slot1778, align 8
  %op9537 = and i64 %v9536, 4611686018427387906
  store i64 %op9537, ptr %slot1779, align 8
  %v9538 = load i64, ptr %slot1779, align 8
  %cmp9539 = icmp ne i64 %v9538, 0
  %cv9540 = zext i1 %cmp9539 to i32
  store i32 %cv9540, ptr %slot1780, align 8
  %v9541 = load i32, ptr %slot1780, align 8
  %cv9542 = zext i32 %v9541 to i64
  %cond9543 = icmp ne i64 %cv9542, 0
  br i1 %cond9543, label %bb_rcgclear2974, label %bb_rcgcounted2974
bb_rcgcounted2974:
  %v9544 = load i64, ptr %slot1775, align 8
  %op9545 = sub i64 %v9544, 32
  store i64 %op9545, ptr %slot1781, align 8
  %v9546 = load i64, ptr %slot1775, align 8
  %p9547 = inttoptr i64 %v9546 to ptr
  %rgep9548 = getelementptr i8, ptr %p9547, i64 -32
  %ld9549 = load i64, ptr %rgep9548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9549, ptr %slot1782, align 8
  %v9550 = load i64, ptr %slot1782, align 8
  %op9551 = sub i64 %v9550, 1
  store i64 %op9551, ptr %slot1783, align 8
  %v9552 = load i64, ptr %slot1783, align 8
  %cmp9553 = icmp eq i64 %v9552, 0
  %cv9554 = zext i1 %cmp9553 to i32
  store i32 %cv9554, ptr %slot1784, align 8
  %v9555 = load i32, ptr %slot1784, align 8
  %cv9556 = zext i32 %v9555 to i64
  %cond9557 = icmp ne i64 %cv9556, 0
  br i1 %cond9557, label %bb_rcglast2974, label %bb_rcgdec2974
bb_rcglast2974:
  %v9558 = load i64, ptr %slot1775, align 8
  %op9559 = sub i64 %v9558, 24
  store i64 %op9559, ptr %slot1785, align 8
  %v9560 = load i64, ptr %slot1775, align 8
  %p9561 = inttoptr i64 %v9560 to ptr
  %rgep9562 = getelementptr i8, ptr %p9561, i64 -24
  %ld9563 = load i64, ptr %rgep9562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9563, ptr %slot1786, align 8
  %v9564 = load i64, ptr %slot1786, align 8
  %cmp9565 = icmp ne i64 %v9564, 0
  %cv9566 = zext i1 %cmp9565 to i32
  store i32 %cv9566, ptr %slot1787, align 8
  %v9567 = load i32, ptr %slot1787, align 8
  %cv9568 = zext i32 %v9567 to i64
  %cond9569 = icmp ne i64 %cv9568, 0
  br i1 %cond9569, label %bb_rcgdec2974, label %bb_rcgslow2974
bb_rcgslow2974:
  %v9570 = load i64, ptr %slot1774, align 8
  %v9571 = load i64, ptr %slot1757, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9570, i64 %v9571) nomerge, !dbg !212
  br label %bb_rcgdone2974
bb_rcgdec2974:
  %v9572 = load i64, ptr %slot1783, align 8
  %v9573 = load i64, ptr %slot1775, align 8
  %p9574 = inttoptr i64 %v9573 to ptr
  %rgep9575 = getelementptr i8, ptr %p9574, i64 -32
  store i64 %v9572, ptr %rgep9575, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2974
bb_rcgclear2974:
  %v9576 = load i64, ptr %slot1757, align 8
  %p9577 = inttoptr i64 %v9576 to ptr
  store i64 0, ptr %p9577, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2974
bb_rcgdone2974:
  br label %bb_rcslotdone2943
bb_rcslotdone2943:
  %v9578 = load i64, ptr %slot30, align 8
  store i64 %v9578, ptr %slot1788, align 8
  %v9579 = load i64, ptr %slot32, align 8
  store i64 %v9579, ptr %slot1789, align 8
  %v9580 = load i64, ptr %slot1789, align 8
  %v9581 = load i64, ptr %slot1788, align 8
  %p9582 = inttoptr i64 %v9580 to ptr
  %p9583 = inttoptr i64 %v9581 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9583, ptr %p9582, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v9584 = load i64, ptr %slot25, align 8
  %p9585 = inttoptr i64 %v9584 to ptr
  store i32 2, ptr %p9585, align 4, !alias.scope !3, !noalias !4
  %v9586 = load i64, ptr %slot28, align 8
  %p9587 = inttoptr i64 %v9586 to ptr
  %ld9588 = load i32, ptr %p9587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9588, ptr %slot1790, align 8
  %v9589 = load i32, ptr %slot1790, align 8
  %v9590 = load i64, ptr %slot25, align 8
  %p9591 = inttoptr i64 %v9590 to ptr
  store i32 %v9589, ptr %p9591, align 4, !alias.scope !3, !noalias !4
  %v9592 = load i64, ptr %slot27, align 8
  %p9593 = inttoptr i64 %v9592 to ptr
  store i32 0, ptr %p9593, align 4, !alias.scope !3, !noalias !4
  %v9594 = load i64, ptr %slot24, align 8
  %p9595 = inttoptr i64 %v9594 to ptr
  store i32 1, ptr %p9595, align 4, !alias.scope !3, !noalias !4
  %v9596 = load i64, ptr %slot1788, align 8
  %v9597 = load i64, ptr %slot52, align 8
  %p9598 = inttoptr i64 %v9597 to ptr
  store i64 %v9596, ptr %p9598, align 8, !alias.scope !3, !noalias !4
  %v9599 = load i64, ptr %slot68, align 8
  store i64 %v9599, ptr %slot1791, align 8
  %v9600 = load i64, ptr %slot1791, align 8
  %p9601 = inttoptr i64 %v9600 to ptr
  store i64 0, ptr %p9601, align 8, !alias.scope !3, !noalias !4
  %v9602 = load i64, ptr %slot1791, align 8
  %p9604 = inttoptr i64 %v9602 to ptr
  %gep9605 = getelementptr i8, ptr %p9604, i64 8
  %op9603 = ptrtoint ptr %gep9605 to i64
  store i64 %op9603, ptr %slot1792, align 8
  %v9606 = load i64, ptr %slot1792, align 8
  %p9607 = inttoptr i64 %v9606 to ptr
  store i64 0, ptr %p9607, align 8, !alias.scope !3, !noalias !4
  %v9608 = load i64, ptr %slot1791, align 8
  %p9610 = inttoptr i64 %v9608 to ptr
  %gep9611 = getelementptr i8, ptr %p9610, i64 16
  %op9609 = ptrtoint ptr %gep9611 to i64
  store i64 %op9609, ptr %slot1793, align 8
  %v9612 = load i64, ptr %slot1793, align 8
  %p9613 = inttoptr i64 %v9612 to ptr
  store i64 0, ptr %p9613, align 8, !alias.scope !3, !noalias !4
  %v9614 = load i64, ptr %slot1791, align 8
  %p9615 = inttoptr i64 %v9614 to ptr
  store i32 1, ptr %p9615, align 4, !alias.scope !3, !noalias !4
  %v9616 = load i64, ptr %slot29, align 8
  %p9617 = inttoptr i64 %v9616 to ptr
  store i32 1, ptr %p9617, align 4, !alias.scope !3, !noalias !4
  %v9618 = load i64, ptr %slot52, align 8
  %p9619 = inttoptr i64 %v9618 to ptr
  %ld9620 = load i64, ptr %p9619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9620, ptr %slot1794, align 8
  %v9621 = load i64, ptr %slot1791, align 8
  %p9623 = inttoptr i64 %v9621 to ptr
  %gep9624 = getelementptr i8, ptr %p9623, i64 8
  %op9622 = ptrtoint ptr %gep9624 to i64
  store i64 %op9622, ptr %slot1795, align 8
  %v9625 = load i64, ptr %slot74, align 8
  store i64 %v9625, ptr %slot1796, align 8
  %v9626 = load i64, ptr %slot52, align 8
  %p9627 = inttoptr i64 %v9626 to ptr
  %ld9628 = load i64, ptr %p9627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9628, ptr %slot1797, align 8
  %v9629 = load i64, ptr %slot24, align 8
  %p9630 = inttoptr i64 %v9629 to ptr
  %ld9631 = load i32, ptr %p9630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9631, ptr %slot1798, align 8
  %v9632 = load i64, ptr %slot25, align 8
  %p9633 = inttoptr i64 %v9632 to ptr
  %ld9634 = load i32, ptr %p9633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9634, ptr %slot1799, align 8
  %v9635 = load i32, ptr %slot1799, align 8
  %op9636 = and i32 %v9635, 24
  store i32 %op9636, ptr %slot1799, align 8
  %v9637 = load i32, ptr %slot1799, align 8
  %cmp9638 = icmp eq i32 %v9637, 0
  %cv9639 = zext i1 %cmp9638 to i32
  store i32 %cv9639, ptr %slot1800, align 8
  %v9640 = load i32, ptr %slot1798, align 8
  %v9641 = load i32, ptr %slot1800, align 8
  %op9642 = and i32 %v9640, %v9641
  store i32 %op9642, ptr %slot1801, align 8
  %v9643 = load i32, ptr %slot1801, align 8
  %cv9644 = zext i32 %v9643 to i64
  %cond9645 = icmp ne i64 %cv9644, 0
  br i1 %cond9645, label %bb_rctake2995, label %bb_rccopy2995
bb_rctake2995:
  %v9646 = load i64, ptr %slot32, align 8
  store i64 %v9646, ptr %slot1802, align 8
  %v9647 = load i64, ptr %slot74, align 8
  store i64 %v9647, ptr %slot1803, align 8
  %v9648 = load i64, ptr %slot1797, align 8
  %v9649 = load i64, ptr %slot1802, align 8
  %op9650 = sub i64 %v9648, %v9649
  store i64 %op9650, ptr %slot1804, align 8
  %v9651 = load i64, ptr %slot1802, align 8
  %v9652 = load i64, ptr %slot1797, align 8
  %op9653 = sub i64 %v9651, %v9652
  store i64 %op9653, ptr %slot1805, align 8
  %v9654 = load i64, ptr %slot1804, align 8
  %cmp9655 = icmp ult i64 %v9654, 16
  %cv9656 = zext i1 %cmp9655 to i32
  store i32 %cv9656, ptr %slot1806, align 8
  %v9657 = load i64, ptr %slot1805, align 8
  %cmp9658 = icmp ult i64 %v9657, 16
  %cv9659 = zext i1 %cmp9658 to i32
  store i32 %cv9659, ptr %slot1807, align 8
  %v9660 = load i32, ptr %slot1806, align 8
  %v9661 = load i32, ptr %slot1807, align 8
  %op9662 = or i32 %v9660, %v9661
  store i32 %op9662, ptr %slot1808, align 8
  %v9663 = load i32, ptr %slot1808, align 8
  %cv9664 = zext i32 %v9663 to i64
  %cond9665 = icmp ne i64 %cv9664, 0
  br i1 %cond9665, label %bb_rcmoveslow3004, label %bb_rcmovecheck3004
bb_rcmovecheck3004:
  %v9666 = load i64, ptr %slot1797, align 8
  %op9667 = add i64 %v9666, 0
  store i64 %op9667, ptr %slot1809, align 8
  %v9668 = load i64, ptr %slot1809, align 8
  %p9669 = inttoptr i64 %v9668 to ptr
  %ld9670 = load i64, ptr %p9669, align 8
  store i64 %ld9670, ptr %slot1810, align 8
  %v9671 = load i64, ptr %slot1810, align 8
  %cmp9672 = icmp ne i64 %v9671, 0
  %cv9673 = zext i1 %cmp9672 to i32
  store i32 %cv9673, ptr %slot1811, align 8
  %v9674 = load i32, ptr %slot1811, align 8
  %cv9675 = zext i32 %v9674 to i64
  %cond9676 = icmp ne i64 %cv9675, 0
  br i1 %cond9676, label %bb_rcmoveheader3012, label %bb_rcmovenext3012
bb_rcmoveheader3012:
  %v9677 = load i64, ptr %slot1810, align 8
  %op9678 = sub i64 %v9677, 16
  store i64 %op9678, ptr %slot1812, align 8
  %v9679 = load i64, ptr %slot1810, align 8
  %p9680 = inttoptr i64 %v9679 to ptr
  %rgep9681 = getelementptr i8, ptr %p9680, i64 -16
  %ld9682 = load i64, ptr %rgep9681, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9682, ptr %slot1813, align 8
  %v9683 = load i64, ptr %slot1813, align 8
  %op9684 = and i64 %v9683, 5764607523034234881
  store i64 %op9684, ptr %slot1814, align 8
  %v9685 = load i64, ptr %slot1814, align 8
  %cmp9686 = icmp ne i64 %v9685, 0
  %cv9687 = zext i1 %cmp9686 to i32
  store i32 %cv9687, ptr %slot1815, align 8
  %v9688 = load i32, ptr %slot1815, align 8
  %cv9689 = zext i32 %v9688 to i64
  %cond9690 = icmp ne i64 %cv9689, 0
  br i1 %cond9690, label %bb_rcmoveslow3004, label %bb_rcmovenext3012
bb_rcmovenext3012:
  %v9691 = load i64, ptr %slot1797, align 8
  %v9692 = load i64, ptr %slot1802, align 8
  %p9693 = inttoptr i64 %v9691 to ptr
  %p9694 = inttoptr i64 %v9692 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9694, ptr %p9693, i64 16, i1 false)
  %v9695 = load i64, ptr %slot1797, align 8
  %p9696 = inttoptr i64 %v9695 to ptr
  store i64 0, ptr %p9696, align 8
  %v9697 = load i64, ptr %slot1797, align 8
  %op9698 = add i64 %v9697, 8
  store i64 %op9698, ptr %slot1816, align 8
  %v9699 = load i64, ptr %slot1816, align 8
  %p9700 = inttoptr i64 %v9699 to ptr
  store i64 0, ptr %p9700, align 8
  br label %bb_rcmoved3004
bb_rcmoveslow3004:
  %v9701 = load i64, ptr %slot73, align 8
  %v9702 = load i64, ptr %slot1802, align 8
  %v9703 = load i64, ptr %slot1797, align 8
  %v9704 = load i64, ptr %slot1803, align 8
  %cv9705 = trunc i64 %v9704 to i32
  %call9706 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v9701, i64 %v9702, i64 %v9703, i32 %cv9705) nomerge, !dbg !214
  store i32 %call9706, ptr %slot1817, align 8
  %v9707 = load i32, ptr %slot1817, align 8
  %cv9708 = zext i32 %v9707 to i64
  %cond9709 = icmp ne i64 %cv9708, 0
  br i1 %cond9709, label %bb_rcsuccess3020, label %bb_rcfailure3020
bb_rcfailure3020:
  %v9710 = load i64, ptr %slot73, align 8
  %p9711 = inttoptr i64 %v9710 to ptr
  %call9712 = call i32 @myl_rc_take_failure(ptr %p9711) nomerge, !dbg !214
  store i32 %call9712, ptr %slot1818, align 8
  %v9713 = load i64, ptr %slot1, align 8
  %p9714 = inttoptr i64 %v9713 to ptr
  %v9715 = load i32, ptr %slot1818, align 8
  %call9716 = call i32 @myl_qbe_rc_status(ptr %p9714, i32 %v9715) nomerge, !dbg !214
  store i32 %call9716, ptr %slot1819, align 8
  br label %bb_failure
bb_rcsuccess3020:
  br label %bb_rcmoved3004
bb_rcmoved3004:
  %v9717 = load i64, ptr %slot24, align 8
  %p9718 = inttoptr i64 %v9717 to ptr
  store i32 0, ptr %p9718, align 4, !alias.scope !3, !noalias !4
  %v9719 = load i64, ptr %slot28, align 8
  %p9720 = inttoptr i64 %v9719 to ptr
  store i32 2, ptr %p9720, align 4, !alias.scope !3, !noalias !4
  %v9721 = load i64, ptr %slot27, align 8
  %p9722 = inttoptr i64 %v9721 to ptr
  store i32 1, ptr %p9722, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2995
bb_rccopy2995:
  %v9723 = load i64, ptr %slot32, align 8
  store i64 %v9723, ptr %slot1820, align 8
  %v9724 = load i64, ptr %slot74, align 8
  store i64 %v9724, ptr %slot1821, align 8
  %v9725 = load i64, ptr %slot73, align 8
  %v9726 = load i64, ptr %slot1820, align 8
  %v9727 = load i64, ptr %slot1797, align 8
  %v9728 = load i64, ptr %slot1821, align 8
  %cv9729 = trunc i64 %v9728 to i32
  %call9730 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v9725, i64 %v9726, i64 %v9727, i32 %cv9729) nomerge, !dbg !214
  store i32 %call9730, ptr %slot1822, align 8
  %v9731 = load i32, ptr %slot1822, align 8
  %cv9732 = zext i32 %v9731 to i64
  %cond9733 = icmp ne i64 %cv9732, 0
  br i1 %cond9733, label %bb_rcsuccess3029, label %bb_rcfailure3029
bb_rcfailure3029:
  %v9734 = load i64, ptr %slot73, align 8
  %p9735 = inttoptr i64 %v9734 to ptr
  %call9736 = call i32 @myl_rc_take_failure(ptr %p9735) nomerge, !dbg !214
  store i32 %call9736, ptr %slot1823, align 8
  %v9737 = load i64, ptr %slot1, align 8
  %p9738 = inttoptr i64 %v9737 to ptr
  %v9739 = load i32, ptr %slot1823, align 8
  %call9740 = call i32 @myl_qbe_rc_status(ptr %p9738, i32 %v9739) nomerge, !dbg !214
  store i32 %call9740, ptr %slot1824, align 8
  br label %bb_failure
bb_rcsuccess3029:
  %v9741 = load i64, ptr %slot28, align 8
  %p9742 = inttoptr i64 %v9741 to ptr
  store i32 2, ptr %p9742, align 4, !alias.scope !3, !noalias !4
  %v9743 = load i64, ptr %slot27, align 8
  %p9744 = inttoptr i64 %v9743 to ptr
  store i32 1, ptr %p9744, align 4, !alias.scope !3, !noalias !4
  %v9745 = load i64, ptr %slot24, align 8
  %p9746 = inttoptr i64 %v9745 to ptr
  %ld9747 = load i32, ptr %p9746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9747, ptr %slot1825, align 8
  %v9748 = load i32, ptr %slot1825, align 8
  %cv9749 = zext i32 %v9748 to i64
  %cond9750 = icmp ne i64 %cv9749, 0
  br i1 %cond9750, label %bb_rcslotdrop3036, label %bb_rcslotdone3036
bb_rcslotdrop3036:
  %v9751 = load i64, ptr %slot24, align 8
  %p9752 = inttoptr i64 %v9751 to ptr
  store i32 0, ptr %p9752, align 4, !alias.scope !3, !noalias !4
  %v9753 = load i64, ptr %slot30, align 8
  store i64 %v9753, ptr %slot1826, align 8
  %v9754 = load i64, ptr %slot25, align 8
  %p9755 = inttoptr i64 %v9754 to ptr
  %ld9756 = load i32, ptr %p9755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9756, ptr %slot1827, align 8
  %v9757 = load i32, ptr %slot1827, align 8
  %op9758 = and i32 %v9757, 28
  store i32 %op9758, ptr %slot1828, align 8
  %v9759 = load i32, ptr %slot1828, align 8
  %cv9760 = zext i32 %v9759 to i64
  %cond9761 = icmp ne i64 %cv9760, 0
  br i1 %cond9761, label %bb_rcslotrole3036, label %bb_rcslotowner3036
bb_rcslotrole3036:
  %v9762 = load i64, ptr %slot73, align 8
  store i64 %v9762, ptr %slot1829, align 8
  %v9763 = load i64, ptr %slot1829, align 8
  %v9764 = load i64, ptr %slot1826, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v9763, i64 %v9764) nomerge, !dbg !214
  br label %bb_rcslotdone3036
bb_rcslotowner3036:
  %v9765 = load i64, ptr %slot73, align 8
  store i64 %v9765, ptr %slot1830, align 8
  %v9766 = load i64, ptr %slot1830, align 8
  %v9767 = load i64, ptr %slot1826, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v9766, i64 %v9767) nomerge, !dbg !214
  br label %bb_rcslotdone3036
bb_rcslotdone3036:
  br label %bb_rcprepared2995
bb_rcprepared2995:
  %v9768 = load i64, ptr %slot32, align 8
  store i64 %v9768, ptr %slot1831, align 8
  %v9769 = load i64, ptr %slot1831, align 8
  %v9770 = load i64, ptr %slot1795, align 8
  %p9771 = inttoptr i64 %v9769 to ptr
  %p9772 = inttoptr i64 %v9770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9772, ptr %p9771, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v9773 = load i64, ptr %slot27, align 8
  %p9774 = inttoptr i64 %v9773 to ptr
  store i32 0, ptr %p9774, align 4, !alias.scope !3, !noalias !4
  %v9775 = load i64, ptr %slot1791, align 8
  %v9776 = load i64, ptr %slot52, align 8
  %p9777 = inttoptr i64 %v9776 to ptr
  store i64 %v9775, ptr %p9777, align 8, !alias.scope !3, !noalias !4
  %p9778 = inttoptr i64 ptrtoint (ptr @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p9778, i64 162) "call-inline-cost"="0", !dbg !214
  %v9779 = load i64, ptr %slot52, align 8
  %p9780 = inttoptr i64 %v9779 to ptr
  %ld9781 = load i64, ptr %p9780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9781, ptr %slot1832, align 8
  %v9782 = load i64, ptr %slot30, align 8
  store i64 %v9782, ptr %slot1833, align 8
  %v9783 = load i64, ptr %slot1832, align 8
  %v9784 = load i64, ptr %slot1833, align 8
  %p9785 = inttoptr i64 %v9783 to ptr
  %p9786 = inttoptr i64 %v9784 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9786, ptr %p9785, i64 24, i1 false)
  %v9787 = load i64, ptr %slot25, align 8
  %p9788 = inttoptr i64 %v9787 to ptr
  store i32 2, ptr %p9788, align 4, !alias.scope !3, !noalias !4
  %v9789 = load i64, ptr %slot24, align 8
  %p9790 = inttoptr i64 %v9789 to ptr
  store i32 1, ptr %p9790, align 4, !alias.scope !3, !noalias !4
  %v9791 = load i64, ptr %slot1833, align 8
  %v9792 = load i64, ptr %slot52, align 8
  %p9793 = inttoptr i64 %v9792 to ptr
  store i64 %v9791, ptr %p9793, align 8, !alias.scope !3, !noalias !4
  %v9794 = load i64, ptr %slot52, align 8
  %p9795 = inttoptr i64 %v9794 to ptr
  %ld9796 = load i64, ptr %p9795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9796, ptr %slot1834, align 8
  %v9797 = load i64, ptr %slot52, align 8
  %p9798 = inttoptr i64 %v9797 to ptr
  %ld9799 = load i64, ptr %p9798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9799, ptr %slot1835, align 8
  %v9800 = load i64, ptr %slot32, align 8
  store i64 %v9800, ptr %slot1836, align 8
  %v9801 = load i64, ptr %slot74, align 8
  store i64 %v9801, ptr %slot1837, align 8
  %v9802 = load i64, ptr %slot73, align 8
  %v9803 = load i64, ptr %slot1836, align 8
  %v9804 = load i64, ptr %slot1835, align 8
  %v9805 = load i64, ptr %slot1837, align 8
  %cv9806 = trunc i64 %v9805 to i32
  %call9807 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v9802, i64 %v9803, i64 %v9804, i32 %cv9806) nomerge, !dbg !216
  store i32 %call9807, ptr %slot1838, align 8
  %v9808 = load i32, ptr %slot1838, align 8
  %cv9809 = zext i32 %v9808 to i64
  %cond9810 = icmp ne i64 %cv9809, 0
  br i1 %cond9810, label %bb_rcsuccess3054, label %bb_rcfailure3054
bb_rcfailure3054:
  %v9811 = load i64, ptr %slot73, align 8
  %p9812 = inttoptr i64 %v9811 to ptr
  %call9813 = call i32 @myl_rc_take_failure(ptr %p9812) nomerge, !dbg !216
  store i32 %call9813, ptr %slot1839, align 8
  %v9814 = load i64, ptr %slot1, align 8
  %p9815 = inttoptr i64 %v9814 to ptr
  %v9816 = load i32, ptr %slot1839, align 8
  %call9817 = call i32 @myl_qbe_rc_status(ptr %p9815, i32 %v9816) nomerge, !dbg !216
  store i32 %call9817, ptr %slot1840, align 8
  br label %bb_failure
bb_rcsuccess3054:
  %v9818 = load i64, ptr %slot24, align 8
  %p9819 = inttoptr i64 %v9818 to ptr
  store i32 0, ptr %p9819, align 4, !alias.scope !3, !noalias !4
  %v9820 = load i64, ptr %slot28, align 8
  %p9821 = inttoptr i64 %v9820 to ptr
  store i32 2, ptr %p9821, align 4, !alias.scope !3, !noalias !4
  %v9822 = load i64, ptr %slot27, align 8
  %p9823 = inttoptr i64 %v9822 to ptr
  store i32 1, ptr %p9823, align 4, !alias.scope !3, !noalias !4
  %v9824 = load i64, ptr %slot32, align 8
  store i64 %v9824, ptr %slot1841, align 8
  %v9825 = load i64, ptr %slot27, align 8
  %p9826 = inttoptr i64 %v9825 to ptr
  store i32 0, ptr %p9826, align 4, !alias.scope !3, !noalias !4
  %v9827 = load i64, ptr %slot33, align 8
  %p9829 = inttoptr i64 %v9827 to ptr
  %gep9830 = getelementptr i8, ptr %p9829, i64 24
  %op9828 = ptrtoint ptr %gep9830 to i64
  store i64 %op9828, ptr %slot1842, align 8
  %v9831 = load i64, ptr %slot1842, align 8
  %p9832 = inttoptr i64 %v9831 to ptr
  %ld9833 = load i32, ptr %p9832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9833, ptr %slot1843, align 8
  %v9834 = load i32, ptr %slot1843, align 8
  %cv9835 = zext i32 %v9834 to i64
  %cond9836 = icmp ne i64 %cv9835, 0
  br i1 %cond9836, label %bb_rcscopesopen3064, label %bb_rcscopesclosed3064
bb_rcscopesopen3064:
  %v9837 = load i64, ptr %slot35, align 8
  %p9839 = inttoptr i64 %v9837 to ptr
  %gep9840 = getelementptr i8, ptr %p9839, i64 0
  %op9838 = ptrtoint ptr %gep9840 to i64
  store i64 %op9838, ptr %slot1844, align 8
  %v9841 = load i64, ptr %slot33, align 8
  %v9842 = load i64, ptr %slot1844, align 8
  %p9843 = inttoptr i64 %v9842 to ptr
  store i64 %v9841, ptr %p9843, align 8, !alias.scope !3, !noalias !4
  %v9844 = load i64, ptr %slot1, align 8
  %p9845 = inttoptr i64 %v9844 to ptr
  %v9846 = load i64, ptr %slot35, align 8
  %p9847 = inttoptr i64 %v9846 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p9845, ptr %p9847, i64 1) nomerge, !dbg !216
  br label %bb_rcscopesclosed3064
bb_rcscopesclosed3064:
  %v9848 = load i64, ptr %slot24, align 8
  %p9849 = inttoptr i64 %v9848 to ptr
  %ld9850 = load i32, ptr %p9849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9850, ptr %slot1845, align 8
  %v9851 = load i32, ptr %slot1845, align 8
  %cv9852 = zext i32 %v9851 to i64
  %cond9853 = icmp ne i64 %cv9852, 0
  br i1 %cond9853, label %bb_rcslotdrop3068, label %bb_rcslotdone3068
bb_rcslotdrop3068:
  %v9854 = load i64, ptr %slot24, align 8
  %p9855 = inttoptr i64 %v9854 to ptr
  store i32 0, ptr %p9855, align 4, !alias.scope !3, !noalias !4
  %v9856 = load i64, ptr %slot30, align 8
  store i64 %v9856, ptr %slot1846, align 8
  %v9857 = load i64, ptr %slot25, align 8
  %p9858 = inttoptr i64 %v9857 to ptr
  %ld9859 = load i32, ptr %p9858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9859, ptr %slot1847, align 8
  %v9860 = load i32, ptr %slot1847, align 8
  %op9861 = and i32 %v9860, 28
  store i32 %op9861, ptr %slot1848, align 8
  %v9862 = load i32, ptr %slot1848, align 8
  %cv9863 = zext i32 %v9862 to i64
  %cond9864 = icmp ne i64 %cv9863, 0
  br i1 %cond9864, label %bb_rcslotrole3068, label %bb_rcslotowner3068
bb_rcslotrole3068:
  %v9865 = load i64, ptr %slot73, align 8
  store i64 %v9865, ptr %slot1849, align 8
  %v9866 = load i64, ptr %slot1849, align 8
  %v9867 = load i64, ptr %slot1846, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v9866, i64 %v9867) nomerge, !dbg !216
  br label %bb_rcslotdone3068
bb_rcslotowner3068:
  %v9868 = load i64, ptr %slot73, align 8
  store i64 %v9868, ptr %slot1850, align 8
  %v9869 = load i64, ptr %slot1850, align 8
  %v9870 = load i64, ptr %slot1846, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v9869, i64 %v9870) nomerge, !dbg !216
  br label %bb_rcslotdone3068
bb_rcslotdone3068:
  %v9871 = load i64, ptr %slot22, align 8
  %p9872 = inttoptr i64 %v9871 to ptr
  %ld9873 = load i32, ptr %p9872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9873, ptr %slot1851, align 8
  %v9874 = load i32, ptr %slot1851, align 8
  %cv9875 = zext i32 %v9874 to i64
  %cond9876 = icmp ne i64 %cv9875, 0
  br i1 %cond9876, label %bb_rcslotdrop3095, label %bb_rcslotdone3095
bb_rcslotdrop3095:
  %v9877 = load i64, ptr %slot22, align 8
  %p9878 = inttoptr i64 %v9877 to ptr
  store i32 0, ptr %p9878, align 4, !alias.scope !3, !noalias !4
  %v9879 = load i64, ptr %slot51, align 8
  store i64 %v9879, ptr %slot1852, align 8
  %v9880 = load i64, ptr %slot23, align 8
  %p9881 = inttoptr i64 %v9880 to ptr
  %ld9882 = load i32, ptr %p9881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9882, ptr %slot1853, align 8
  %v9883 = load i32, ptr %slot1853, align 8
  %op9884 = and i32 %v9883, 28
  store i32 %op9884, ptr %slot1854, align 8
  %v9885 = load i32, ptr %slot1854, align 8
  %cv9886 = zext i32 %v9885 to i64
  %cond9887 = icmp ne i64 %cv9886, 0
  br i1 %cond9887, label %bb_rcslotrole3095, label %bb_rcslotowner3095
bb_rcslotrole3095:
  %v9888 = load i64, ptr %slot73, align 8
  store i64 %v9888, ptr %slot1855, align 8
  %v9889 = load i64, ptr %slot1855, align 8
  %v9890 = load i64, ptr %slot1852, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v9889, i64 %v9890) nomerge, !dbg !216
  br label %bb_rcslotdone3095
bb_rcslotowner3095:
  %v9891 = load i64, ptr %slot73, align 8
  store i64 %v9891, ptr %slot1856, align 8
  %v9892 = load i64, ptr %slot1856, align 8
  %v9893 = load i64, ptr %slot1852, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v9892, i64 %v9893) nomerge, !dbg !216
  br label %bb_rcslotdone3095
bb_rcslotdone3095:
  %v9894 = load i64, ptr %slot20, align 8
  %p9895 = inttoptr i64 %v9894 to ptr
  %ld9896 = load i32, ptr %p9895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9896, ptr %slot1857, align 8
  %v9897 = load i32, ptr %slot1857, align 8
  %cv9898 = zext i32 %v9897 to i64
  %cond9899 = icmp ne i64 %cv9898, 0
  br i1 %cond9899, label %bb_rcslotdrop3122, label %bb_rcslotdone3122
bb_rcslotdrop3122:
  %v9900 = load i64, ptr %slot20, align 8
  %p9901 = inttoptr i64 %v9900 to ptr
  store i32 0, ptr %p9901, align 4, !alias.scope !3, !noalias !4
  %v9902 = load i64, ptr %slot49, align 8
  store i64 %v9902, ptr %slot1858, align 8
  %v9903 = load i64, ptr %slot21, align 8
  %p9904 = inttoptr i64 %v9903 to ptr
  %ld9905 = load i32, ptr %p9904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9905, ptr %slot1859, align 8
  %v9906 = load i32, ptr %slot1859, align 8
  %op9907 = and i32 %v9906, 28
  store i32 %op9907, ptr %slot1860, align 8
  %v9908 = load i32, ptr %slot1860, align 8
  %cv9909 = zext i32 %v9908 to i64
  %cond9910 = icmp ne i64 %cv9909, 0
  br i1 %cond9910, label %bb_rcslotrole3122, label %bb_rcslotowner3122
bb_rcslotrole3122:
  %v9911 = load i64, ptr %slot73, align 8
  store i64 %v9911, ptr %slot1861, align 8
  %v9912 = load i64, ptr %slot1861, align 8
  %v9913 = load i64, ptr %slot1858, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v9912, i64 %v9913) nomerge, !dbg !216
  br label %bb_rcslotdone3122
bb_rcslotowner3122:
  %v9914 = load i64, ptr %slot73, align 8
  store i64 %v9914, ptr %slot1862, align 8
  %v9915 = load i64, ptr %slot1862, align 8
  %v9916 = load i64, ptr %slot1858, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v9915, i64 %v9916) nomerge, !dbg !216
  br label %bb_rcslotdone3122
bb_rcslotdone3122:
  %v9917 = load i64, ptr %slot18, align 8
  %p9918 = inttoptr i64 %v9917 to ptr
  %ld9919 = load i32, ptr %p9918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9919, ptr %slot1863, align 8
  %v9920 = load i32, ptr %slot1863, align 8
  %cv9921 = zext i32 %v9920 to i64
  %cond9922 = icmp ne i64 %cv9921, 0
  br i1 %cond9922, label %bb_rcslotdrop3131, label %bb_rcslotdone3131
bb_rcslotdrop3131:
  %v9923 = load i64, ptr %slot18, align 8
  %p9924 = inttoptr i64 %v9923 to ptr
  store i32 0, ptr %p9924, align 4, !alias.scope !3, !noalias !4
  %v9925 = load i64, ptr %slot47, align 8
  store i64 %v9925, ptr %slot1864, align 8
  %v9926 = load i64, ptr %slot19, align 8
  %p9927 = inttoptr i64 %v9926 to ptr
  %ld9928 = load i32, ptr %p9927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9928, ptr %slot1865, align 8
  %v9929 = load i32, ptr %slot1865, align 8
  %op9930 = and i32 %v9929, 28
  store i32 %op9930, ptr %slot1866, align 8
  %v9931 = load i32, ptr %slot1866, align 8
  %cv9932 = zext i32 %v9931 to i64
  %cond9933 = icmp ne i64 %cv9932, 0
  br i1 %cond9933, label %bb_rcslotrole3131, label %bb_rcslotowner3131
bb_rcslotrole3131:
  %v9934 = load i64, ptr %slot73, align 8
  store i64 %v9934, ptr %slot1867, align 8
  %v9935 = load i64, ptr %slot1867, align 8
  %v9936 = load i64, ptr %slot1864, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v9935, i64 %v9936) nomerge, !dbg !216
  br label %bb_rcslotdone3131
bb_rcslotowner3131:
  %v9937 = load i64, ptr %slot73, align 8
  store i64 %v9937, ptr %slot1868, align 8
  %v9938 = load i64, ptr %slot1868, align 8
  %v9939 = load i64, ptr %slot1864, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v9938, i64 %v9939) nomerge, !dbg !216
  br label %bb_rcslotdone3131
bb_rcslotdone3131:
  %v9940 = load i64, ptr %slot16, align 8
  %p9941 = inttoptr i64 %v9940 to ptr
  %ld9942 = load i32, ptr %p9941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9942, ptr %slot1869, align 8
  %v9943 = load i32, ptr %slot1869, align 8
  %cv9944 = zext i32 %v9943 to i64
  %cond9945 = icmp ne i64 %cv9944, 0
  br i1 %cond9945, label %bb_rcslotdrop3177, label %bb_rcslotdone3177
bb_rcslotdrop3177:
  %v9946 = load i64, ptr %slot16, align 8
  %p9947 = inttoptr i64 %v9946 to ptr
  store i32 0, ptr %p9947, align 4, !alias.scope !3, !noalias !4
  %v9948 = load i64, ptr %slot45, align 8
  store i64 %v9948, ptr %slot1870, align 8
  %v9949 = load i64, ptr %slot17, align 8
  %p9950 = inttoptr i64 %v9949 to ptr
  %ld9951 = load i32, ptr %p9950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9951, ptr %slot1871, align 8
  %v9952 = load i32, ptr %slot1871, align 8
  %op9953 = and i32 %v9952, 28
  store i32 %op9953, ptr %slot1872, align 8
  %v9954 = load i32, ptr %slot1872, align 8
  %cv9955 = zext i32 %v9954 to i64
  %cond9956 = icmp ne i64 %cv9955, 0
  br i1 %cond9956, label %bb_rcslotrole3177, label %bb_rcslotowner3177
bb_rcslotrole3177:
  %v9957 = load i64, ptr %slot73, align 8
  store i64 %v9957, ptr %slot1873, align 8
  %v9958 = load i64, ptr %slot1873, align 8
  %v9959 = load i64, ptr %slot1870, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v9958, i64 %v9959) nomerge, !dbg !216
  br label %bb_rcslotdone3177
bb_rcslotowner3177:
  %v9960 = load i64, ptr %slot73, align 8
  store i64 %v9960, ptr %slot1874, align 8
  %v9961 = load i64, ptr %slot1874, align 8
  %v9962 = load i64, ptr %slot1870, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v9961, i64 %v9962) nomerge, !dbg !216
  br label %bb_rcslotdone3177
bb_rcslotdone3177:
  %v9963 = load i64, ptr %slot14, align 8
  %p9964 = inttoptr i64 %v9963 to ptr
  %ld9965 = load i32, ptr %p9964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9965, ptr %slot1875, align 8
  %v9966 = load i32, ptr %slot1875, align 8
  %cv9967 = zext i32 %v9966 to i64
  %cond9968 = icmp ne i64 %cv9967, 0
  br i1 %cond9968, label %bb_rcslotdrop3186, label %bb_rcslotdone3186
bb_rcslotdrop3186:
  %v9969 = load i64, ptr %slot14, align 8
  %p9970 = inttoptr i64 %v9969 to ptr
  store i32 0, ptr %p9970, align 4, !alias.scope !3, !noalias !4
  %v9971 = load i64, ptr %slot44, align 8
  store i64 %v9971, ptr %slot1876, align 8
  %v9972 = load i64, ptr %slot15, align 8
  %p9973 = inttoptr i64 %v9972 to ptr
  %ld9974 = load i32, ptr %p9973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9974, ptr %slot1877, align 8
  %v9975 = load i32, ptr %slot1877, align 8
  %op9976 = and i32 %v9975, 28
  store i32 %op9976, ptr %slot1878, align 8
  %v9977 = load i32, ptr %slot1878, align 8
  %cv9978 = zext i32 %v9977 to i64
  %cond9979 = icmp ne i64 %cv9978, 0
  br i1 %cond9979, label %bb_rcslotrole3186, label %bb_rcslotowner3186
bb_rcslotrole3186:
  %v9980 = load i64, ptr %slot73, align 8
  store i64 %v9980, ptr %slot1879, align 8
  %v9981 = load i64, ptr %slot1879, align 8
  %v9982 = load i64, ptr %slot1876, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v9981, i64 %v9982) nomerge, !dbg !216
  br label %bb_rcslotdone3186
bb_rcslotowner3186:
  %v9983 = load i64, ptr %slot73, align 8
  store i64 %v9983, ptr %slot1880, align 8
  %v9984 = load i64, ptr %slot1880, align 8
  %v9985 = load i64, ptr %slot1876, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v9984, i64 %v9985) nomerge, !dbg !216
  br label %bb_rcslotdone3186
bb_rcslotdone3186:
  %v9986 = load i64, ptr %slot12, align 8
  %p9987 = inttoptr i64 %v9986 to ptr
  %ld9988 = load i32, ptr %p9987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9988, ptr %slot1881, align 8
  %v9989 = load i32, ptr %slot1881, align 8
  %cv9990 = zext i32 %v9989 to i64
  %cond9991 = icmp ne i64 %cv9990, 0
  br i1 %cond9991, label %bb_rcslotdrop3195, label %bb_rcslotdone3195
bb_rcslotdrop3195:
  %v9992 = load i64, ptr %slot12, align 8
  %p9993 = inttoptr i64 %v9992 to ptr
  store i32 0, ptr %p9993, align 4, !alias.scope !3, !noalias !4
  %v9994 = load i64, ptr %slot43, align 8
  store i64 %v9994, ptr %slot1882, align 8
  %v9995 = load i64, ptr %slot13, align 8
  %p9996 = inttoptr i64 %v9995 to ptr
  %ld9997 = load i32, ptr %p9996, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9997, ptr %slot1883, align 8
  %v9998 = load i32, ptr %slot1883, align 8
  %op9999 = and i32 %v9998, 28
  store i32 %op9999, ptr %slot1884, align 8
  %v10000 = load i32, ptr %slot1884, align 8
  %cv10001 = zext i32 %v10000 to i64
  %cond10002 = icmp ne i64 %cv10001, 0
  br i1 %cond10002, label %bb_rcslotrole3195, label %bb_rcslotowner3195
bb_rcslotrole3195:
  %v10003 = load i64, ptr %slot73, align 8
  store i64 %v10003, ptr %slot1885, align 8
  %v10004 = load i64, ptr %slot1885, align 8
  %v10005 = load i64, ptr %slot1882, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v10004, i64 %v10005) nomerge, !dbg !216
  br label %bb_rcslotdone3195
bb_rcslotowner3195:
  %v10006 = load i64, ptr %slot73, align 8
  store i64 %v10006, ptr %slot1886, align 8
  %v10007 = load i64, ptr %slot1886, align 8
  %v10008 = load i64, ptr %slot1882, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v10007, i64 %v10008) nomerge, !dbg !216
  br label %bb_rcslotdone3195
bb_rcslotdone3195:
  %v10009 = load i64, ptr %slot10, align 8
  %p10010 = inttoptr i64 %v10009 to ptr
  %ld10011 = load i32, ptr %p10010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10011, ptr %slot1887, align 8
  %v10012 = load i32, ptr %slot1887, align 8
  %cv10013 = zext i32 %v10012 to i64
  %cond10014 = icmp ne i64 %cv10013, 0
  br i1 %cond10014, label %bb_rcslotdrop3204, label %bb_rcslotdone3204
bb_rcslotdrop3204:
  %v10015 = load i64, ptr %slot10, align 8
  %p10016 = inttoptr i64 %v10015 to ptr
  store i32 0, ptr %p10016, align 4, !alias.scope !3, !noalias !4
  %v10017 = load i64, ptr %slot41, align 8
  store i64 %v10017, ptr %slot1888, align 8
  %v10018 = load i64, ptr %slot11, align 8
  %p10019 = inttoptr i64 %v10018 to ptr
  %ld10020 = load i32, ptr %p10019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10020, ptr %slot1889, align 8
  %v10021 = load i32, ptr %slot1889, align 8
  %op10022 = and i32 %v10021, 28
  store i32 %op10022, ptr %slot1890, align 8
  %v10023 = load i32, ptr %slot1890, align 8
  %cv10024 = zext i32 %v10023 to i64
  %cond10025 = icmp ne i64 %cv10024, 0
  br i1 %cond10025, label %bb_rcslotrole3204, label %bb_rcslotowner3204
bb_rcslotrole3204:
  %v10026 = load i64, ptr %slot73, align 8
  store i64 %v10026, ptr %slot1891, align 8
  %v10027 = load i64, ptr %slot1891, align 8
  %v10028 = load i64, ptr %slot1888, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v10027, i64 %v10028) nomerge, !dbg !216
  br label %bb_rcslotdone3204
bb_rcslotowner3204:
  %v10029 = load i64, ptr %slot73, align 8
  store i64 %v10029, ptr %slot1892, align 8
  %v10030 = load i64, ptr %slot1892, align 8
  %v10031 = load i64, ptr %slot1888, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v10030, i64 %v10031) nomerge, !dbg !216
  br label %bb_rcslotdone3204
bb_rcslotdone3204:
  %v10032 = load i64, ptr %slot8, align 8
  %p10033 = inttoptr i64 %v10032 to ptr
  %ld10034 = load i32, ptr %p10033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10034, ptr %slot1893, align 8
  %v10035 = load i32, ptr %slot1893, align 8
  %cv10036 = zext i32 %v10035 to i64
  %cond10037 = icmp ne i64 %cv10036, 0
  br i1 %cond10037, label %bb_rcslotdrop3213, label %bb_rcslotdone3213
bb_rcslotdrop3213:
  %v10038 = load i64, ptr %slot8, align 8
  %p10039 = inttoptr i64 %v10038 to ptr
  store i32 0, ptr %p10039, align 4, !alias.scope !3, !noalias !4
  %v10040 = load i64, ptr %slot40, align 8
  store i64 %v10040, ptr %slot1894, align 8
  %v10041 = load i64, ptr %slot9, align 8
  %p10042 = inttoptr i64 %v10041 to ptr
  %ld10043 = load i32, ptr %p10042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10043, ptr %slot1895, align 8
  %v10044 = load i32, ptr %slot1895, align 8
  %op10045 = and i32 %v10044, 28
  store i32 %op10045, ptr %slot1896, align 8
  %v10046 = load i32, ptr %slot1896, align 8
  %cv10047 = zext i32 %v10046 to i64
  %cond10048 = icmp ne i64 %cv10047, 0
  br i1 %cond10048, label %bb_rcslotrole3213, label %bb_rcslotowner3213
bb_rcslotrole3213:
  %v10049 = load i64, ptr %slot73, align 8
  store i64 %v10049, ptr %slot1897, align 8
  %v10050 = load i64, ptr %slot1897, align 8
  %v10051 = load i64, ptr %slot1894, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v10050, i64 %v10051) nomerge, !dbg !216
  br label %bb_rcslotdone3213
bb_rcslotowner3213:
  %v10052 = load i64, ptr %slot73, align 8
  store i64 %v10052, ptr %slot1898, align 8
  %v10053 = load i64, ptr %slot1898, align 8
  %v10054 = load i64, ptr %slot1894, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v10053, i64 %v10054) nomerge, !dbg !216
  br label %bb_rcslotdone3213
bb_rcslotdone3213:
  %v10055 = load i64, ptr %slot6, align 8
  %p10056 = inttoptr i64 %v10055 to ptr
  %ld10057 = load i32, ptr %p10056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10057, ptr %slot1899, align 8
  %v10058 = load i32, ptr %slot1899, align 8
  %cv10059 = zext i32 %v10058 to i64
  %cond10060 = icmp ne i64 %cv10059, 0
  br i1 %cond10060, label %bb_rcslotdrop3222, label %bb_rcslotdone3222
bb_rcslotdrop3222:
  %v10061 = load i64, ptr %slot6, align 8
  %p10062 = inttoptr i64 %v10061 to ptr
  store i32 0, ptr %p10062, align 4, !alias.scope !3, !noalias !4
  %v10063 = load i64, ptr %slot38, align 8
  store i64 %v10063, ptr %slot1900, align 8
  %v10064 = load i64, ptr %slot7, align 8
  %p10065 = inttoptr i64 %v10064 to ptr
  %ld10066 = load i32, ptr %p10065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10066, ptr %slot1901, align 8
  %v10067 = load i32, ptr %slot1901, align 8
  %op10068 = and i32 %v10067, 28
  store i32 %op10068, ptr %slot1902, align 8
  %v10069 = load i32, ptr %slot1902, align 8
  %cv10070 = zext i32 %v10069 to i64
  %cond10071 = icmp ne i64 %cv10070, 0
  br i1 %cond10071, label %bb_rcslotrole3222, label %bb_rcslotowner3222
bb_rcslotrole3222:
  %v10072 = load i64, ptr %slot73, align 8
  store i64 %v10072, ptr %slot1903, align 8
  %v10073 = load i64, ptr %slot1903, align 8
  %v10074 = load i64, ptr %slot1900, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v10073, i64 %v10074) nomerge, !dbg !216
  br label %bb_rcslotdone3222
bb_rcslotowner3222:
  %v10075 = load i64, ptr %slot73, align 8
  store i64 %v10075, ptr %slot1904, align 8
  %v10076 = load i64, ptr %slot1904, align 8
  %v10077 = load i64, ptr %slot1900, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v10076, i64 %v10077) nomerge, !dbg !216
  br label %bb_rcslotdone3222
bb_rcslotdone3222:
  %v10078 = load i64, ptr %slot1841, align 8
  %p10079 = inttoptr i64 %v10078 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p10079, i64 24, i1 false)
  ret void
bb_failure:
  %v10080 = load i64, ptr %slot5, align 8
  %p10081 = inttoptr i64 %v10080 to ptr
  call void @llvm.memset.p0.i64(ptr %p10081, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !216
  %v10082 = load i64, ptr %slot5, align 8
  %p10083 = inttoptr i64 %v10082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p10083, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v10084 = load i64, ptr %slot5, align 8
  %p10085 = inttoptr i64 %v10084 to ptr
  call void @llvm.memset.p0.i64(ptr %p10085, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !216
  %v10086 = load i64, ptr %slot5, align 8
  %p10087 = inttoptr i64 %v10086 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p10087, i64 24, i1 false)
  ret void
}

@myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b_meta = external global i8, align 8
@myl_lit_ae34ea25ba6543390a4fad13083ff6a513fffab9c9bddab170c1a5122079ec98 = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64, i64, i64)
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_72cbd8b3ebb02b19d0384fb691061873bba08de6d559f9babec1767adabac444(i64, i64, i64, i64, i64)
declare void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8, i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64, i64)
declare i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64, i64, i64, i32)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64, i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64, i64, i64, i32)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b", linkageName: "myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15899813002385594812, i64 0, !"myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!122 = !DILocation(line: 14, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!128 = !DILocation(line: 18, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!130 = !DILocation(line: 31, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!134 = !DILocation(line: 33, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!136 = !DILocation(line: 37, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!138 = !DILocation(line: 38, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!140 = !DILocation(line: 40, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!142 = !DILocation(line: 43, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!144 = !DILocation(line: 47, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!146 = !DILocation(line: 48, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!148 = !DILocation(line: 49, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!150 = !DILocation(line: 51, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!152 = !DILocation(line: 52, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!154 = !DILocation(line: 53, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!156 = !DILocation(line: 61, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!158 = !DILocation(line: 65, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!160 = !DILocation(line: 66, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!162 = !DILocation(line: 69, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!164 = !DILocation(line: 71, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!166 = !DILocation(line: 72, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!168 = !DILocation(line: 75, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!170 = !DILocation(line: 76, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!172 = !DILocation(line: 78, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!174 = !DILocation(line: 80, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!176 = !DILocation(line: 82, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!178 = !DILocation(line: 86, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!180 = !DILocation(line: 87, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!182 = !DILocation(line: 92, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!184 = !DILocation(line: 93, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647295)
!186 = !DILocation(line: 95, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!188 = !DILocation(line: 96, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!190 = !DILocation(line: 97, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!192 = !DILocation(line: 105, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!194 = !DILocation(line: 107, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647431)
!196 = !DILocation(line: 112, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647455)
!198 = !DILocation(line: 115, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647487)
!200 = !DILocation(line: 119, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647583)
!202 = !DILocation(line: 131, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647615)
!204 = !DILocation(line: 135, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647655)
!206 = !DILocation(line: 140, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647751)
!208 = !DILocation(line: 152, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647791)
!210 = !DILocation(line: 157, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647831)
!212 = !DILocation(line: 162, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647839)
!214 = !DILocation(line: 163, column: 0, scope: !215)
!217 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647847)
!216 = !DILocation(line: 164, column: 0, scope: !217)
