target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v86 = load i64, ptr %slot1, align 8
  %op87 = add i64 %v86, 32
  store i64 %op87, ptr %slot4, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot5, align 8
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot6, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot7, align 8
  %mem94 = alloca i8, i64 8, align 8
  %ptr95 = ptrtoint ptr %mem94 to i64
  store i64 %ptr95, ptr %slot8, align 8
  %mem96 = alloca i8, i64 8, align 8
  %ptr97 = ptrtoint ptr %mem96 to i64
  store i64 %ptr97, ptr %slot9, align 8
  %mem98 = alloca i8, i64 8, align 8
  %ptr99 = ptrtoint ptr %mem98 to i64
  store i64 %ptr99, ptr %slot10, align 8
  %mem100 = alloca i8, i64 8, align 8
  %ptr101 = ptrtoint ptr %mem100 to i64
  store i64 %ptr101, ptr %slot11, align 8
  %v102 = load i64, ptr %slot8, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 0, ptr %p103, align 8, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot2, align 8
  %v105 = load i64, ptr %slot5, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 %v104, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot3, align 8
  %v108 = load i64, ptr %slot6, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 %v107, ptr %p109, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v110 = load i64, ptr %slot6, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot12, align 8
  %v113 = load i64, ptr %slot12, align 8
  %v114 = load i64, ptr %slot10, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot10, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot13, align 8
  %v119 = load i64, ptr %slot13, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i32, ptr %p120, align 4, !alias.scope !4, !noalias !3
  %ext122 = zext i32 %ld121 to i64
  store i64 %ext122, ptr %slot14, align 8
  %v123 = load i64, ptr %slot14, align 8
  %cmp124 = icmp eq i64 %v123, 0
  %cv125 = zext i1 %cmp124 to i64
  store i64 %cv125, ptr %slot15, align 8
  %v126 = load i64, ptr %slot15, align 8
  %cond127 = icmp ne i64 %v126, 0
  br i1 %cond127, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i41
bb_armnext3:
  %v128 = load i64, ptr %slot14, align 8
  %cmp129 = icmp eq i64 %v128, 1
  %cv130 = zext i1 %cmp129 to i64
  store i64 %cv130, ptr %slot16, align 8
  %v131 = load i64, ptr %slot16, align 8
  %cond132 = icmp ne i64 %v131, 0
  br i1 %cond132, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i43
bb_armnext4:
  %v133 = load i64, ptr %slot14, align 8
  %cmp134 = icmp eq i64 %v133, 2
  %cv135 = zext i1 %cmp134 to i64
  store i64 %cv135, ptr %slot17, align 8
  %v136 = load i64, ptr %slot17, align 8
  %cond137 = icmp ne i64 %v136, 0
  br i1 %cond137, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i45
bb_armnext5:
  %v138 = load i64, ptr %slot14, align 8
  %cmp139 = icmp eq i64 %v138, 3
  %cv140 = zext i1 %cmp139 to i64
  store i64 %cv140, ptr %slot18, align 8
  %v141 = load i64, ptr %slot18, align 8
  %cond142 = icmp ne i64 %v141, 0
  br i1 %cond142, label %bb_arm6, label %bb_armnext6
bb_arm6:
  %v143 = load i64, ptr %slot13, align 8
  %op144 = add i64 %v143, 8
  store i64 %op144, ptr %slot19, align 8
  %v145 = load i64, ptr %slot19, align 8
  %p146 = inttoptr i64 %v145 to ptr
  %ld147 = load i64, ptr %p146, align 8, !alias.scope !4, !noalias !3
  store i64 %ld147, ptr %slot20, align 8
  %v148 = load i64, ptr %slot20, align 8
  %v149 = load i64, ptr %slot7, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i64 %v148, ptr %p150, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_armnext6:
  br label %bb_failure
bb_i2:
  %v151 = load i64, ptr %slot5, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i64, ptr %p152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld153, ptr %slot21, align 8
  %v154 = load i64, ptr %slot21, align 8
  %v155 = load i64, ptr %slot10, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot10, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot22, align 8
  %v160 = load i64, ptr %slot22, align 8
  %op161 = add i64 %v160, 0
  store i64 %op161, ptr %slot23, align 8
  %v162 = load i64, ptr %slot23, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !4, !noalias !3
  store i64 %ld164, ptr %slot24, align 8
  %v165 = load i64, ptr %slot24, align 8
  %v166 = load i64, ptr %slot10, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot10, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot25, align 8
  %v171 = load i64, ptr %slot8, align 8
  store i64 %v171, ptr %slot26, align 8
  %v172 = load i64, ptr %slot25, align 8
  %v173 = load i64, ptr %slot26, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot7, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld177, ptr %slot27, align 8
  %v178 = load i64, ptr %slot27, align 8
  %v179 = load i64, ptr %slot10, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 %v178, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot10, align 8
  %p182 = inttoptr i64 %v181 to ptr
  %ld183 = load i64, ptr %p182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld183, ptr %slot28, align 8
  %v184 = load i64, ptr %slot9, align 8
  store i64 %v184, ptr %slot29, align 8
  %v185 = load i64, ptr %slot28, align 8
  %v186 = load i64, ptr %slot29, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot9, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot30, align 8
  %v191 = load i64, ptr %slot30, align 8
  %v192 = load i64, ptr %slot10, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 %v191, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot11, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot11, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot31, align 8
  %v199 = load i64, ptr %slot10, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot32, align 8
  %v202 = load i64, ptr %slot32, align 8
  %v203 = load i64, ptr %slot31, align 8
  %cmp204 = icmp slt i64 %v202, %v203
  %cv205 = zext i1 %cmp204 to i64
  store i64 %cv205, ptr %slot33, align 8
  %v206 = load i64, ptr %slot33, align 8
  %v207 = load i64, ptr %slot10, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i64 %v206, ptr %p208, align 8, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot10, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld211, ptr %slot34, align 8
  %v212 = load i64, ptr %slot34, align 8
  %cond213 = icmp ne i64 %v212, 0
  br i1 %cond213, label %bb_next23, label %bb_i16
bb_next23:
  %v214 = load i64, ptr %slot8, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot35, align 8
  %v217 = load i64, ptr %slot35, align 8
  %op218 = add i64 %v217, 0
  store i64 %op218, ptr %slot36, align 8
  %v219 = load i64, ptr %slot36, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !6, !noalias !7
  store i64 %ld221, ptr %slot37, align 8
  %v222 = load i64, ptr %slot37, align 8
  %v223 = load i64, ptr %slot10, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot10, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot38, align 8
  %v228 = load i64, ptr %slot38, align 8
  %cmp229 = icmp ugt i64 %v228, 9223372036854775807
  %cv230 = zext i1 %cmp229 to i64
  store i64 %cv230, ptr %slot39, align 8
  %v231 = load i64, ptr %slot39, align 8
  %cond232 = icmp ne i64 %v231, 0
  br i1 %cond232, label %bb_cast_overflow28, label %bb_cast_ok28
bb_cast_overflow28:
  %v233 = load i64, ptr %slot1, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %v235 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_cast(ptr %p234, i64 %v235, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok28:
  %v236 = load i64, ptr %slot38, align 8
  %v237 = load i64, ptr %slot10, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot9, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot40, align 8
  %v242 = load i64, ptr %slot40, align 8
  %v243 = load i64, ptr %slot11, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 %v242, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot11, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i64, ptr %p246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld247, ptr %slot41, align 8
  %v248 = load i64, ptr %slot10, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot42, align 8
  %v251 = load i64, ptr %slot42, align 8
  %v252 = load i64, ptr %slot41, align 8
  %ovpair254 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v251, i64 %v252)
  %op253 = extractvalue { i64, i1 } %ovpair254, 0
  %ov255 = extractvalue { i64, i1 } %ovpair254, 1
  store i64 %op253, ptr %slot43, align 8
  %v256 = load i64, ptr %slot42, align 8
  %v257 = load i64, ptr %slot43, align 8
  %op258 = xor i64 %v256, %v257
  store i64 %op258, ptr %slot44, align 8
  %v259 = load i64, ptr %slot41, align 8
  %v260 = load i64, ptr %slot43, align 8
  %op261 = xor i64 %v259, %v260
  store i64 %op261, ptr %slot45, align 8
  %v262 = load i64, ptr %slot44, align 8
  %v263 = load i64, ptr %slot45, align 8
  %op264 = and i64 %v262, %v263
  store i64 %op264, ptr %slot46, align 8
  %cv265 = zext i1 %ov255 to i64
  store i64 %cv265, ptr %slot47, align 8
  %v266 = load i64, ptr %slot47, align 8
  %cond267 = icmp ne i64 %v266, 0
  br i1 %cond267, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v268 = load i64, ptr %slot1, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %v270 = load i64, ptr %slot42, align 8
  %v271 = load i64, ptr %slot41, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p269, i64 0, i64 %v270, i64 %v271, i64 64) nomerge, !dbg !112
  unreachable
bb_checked32:
  %v272 = load i64, ptr %slot43, align 8
  %v273 = load i64, ptr %slot10, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i64 %v272, ptr %p274, align 8, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot10, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot48, align 8
  %v278 = load i64, ptr %slot9, align 8
  store i64 %v278, ptr %slot49, align 8
  %v279 = load i64, ptr %slot48, align 8
  %v280 = load i64, ptr %slot49, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v282 = load i64, ptr %slot9, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot50, align 8
  %v285 = load i64, ptr %slot50, align 8
  %v286 = load i64, ptr %slot10, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot8, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot51, align 8
  %v291 = load i64, ptr %slot10, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot52, align 8
  %v294 = load i64, ptr %slot51, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %ld296 = load i64, ptr %p295, align 8, !alias.scope !6, !noalias !7
  store i64 %ld296, ptr %slot53, align 8
  %v297 = load i64, ptr %slot52, align 8
  %v298 = load i64, ptr %slot53, align 8
  %cmp299 = icmp ult i64 %v297, %v298
  %cv300 = zext i1 %cmp299 to i64
  store i64 %cv300, ptr %slot54, align 8
  %v301 = load i64, ptr %slot54, align 8
  %cond302 = icmp ne i64 %v301, 0
  br i1 %cond302, label %bb_success45, label %bb_failed45
bb_failed45:
  %v303 = load i64, ptr %slot1, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %v305 = load i64, ptr %slot52, align 8
  %v306 = load i64, ptr %slot53, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p304, i64 %v305, i64 %v306) nomerge, !dbg !114
  unreachable
bb_success45:
  %v307 = load i64, ptr %slot51, align 8
  %op308 = add i64 %v307, 32
  store i64 %op308, ptr %slot55, align 8
  %v309 = load i64, ptr %slot55, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !6, !noalias !7
  store i64 %ld311, ptr %slot56, align 8
  %v312 = load i64, ptr %slot52, align 8
  %op313 = mul i64 %v312, 56
  store i64 %op313, ptr %slot57, align 8
  %v314 = load i64, ptr %slot56, align 8
  %v315 = load i64, ptr %slot57, align 8
  %op316 = add i64 %v314, %v315
  store i64 %op316, ptr %slot58, align 8
  %v317 = load i64, ptr %slot58, align 8
  %v318 = load i64, ptr %slot10, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i64 %v317, ptr %p319, align 8, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot10, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot59, align 8
  %v323 = load i64, ptr %slot59, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i32, ptr %p324, align 4, !alias.scope !12, !noalias !13
  %ext326 = zext i32 %ld325 to i64
  store i64 %ext326, ptr %slot60, align 8
  %v327 = load i64, ptr %slot60, align 8
  %cmp328 = icmp eq i64 %v327, 0
  %cv329 = zext i1 %cmp328 to i64
  store i64 %cv329, ptr %slot61, align 8
  %v330 = load i64, ptr %slot61, align 8
  %cond331 = icmp ne i64 %v330, 0
  br i1 %cond331, label %bb_arm52, label %bb_armnext52
bb_arm52:
  br label %bb_i21
bb_armnext52:
  %v332 = load i64, ptr %slot60, align 8
  %cmp333 = icmp eq i64 %v332, 1
  %cv334 = zext i1 %cmp333 to i64
  store i64 %cv334, ptr %slot62, align 8
  %v335 = load i64, ptr %slot62, align 8
  %cond336 = icmp ne i64 %v335, 0
  br i1 %cond336, label %bb_arm53, label %bb_armnext53
bb_arm53:
  br label %bb_i19
bb_armnext53:
  %v337 = load i64, ptr %slot60, align 8
  %cmp338 = icmp eq i64 %v337, 2
  %cv339 = zext i1 %cmp338 to i64
  store i64 %cv339, ptr %slot63, align 8
  %v340 = load i64, ptr %slot63, align 8
  %cond341 = icmp ne i64 %v340, 0
  br i1 %cond341, label %bb_arm54, label %bb_armnext54
bb_arm54:
  br label %bb_i23
bb_armnext54:
  %v342 = load i64, ptr %slot60, align 8
  %cmp343 = icmp eq i64 %v342, 3
  %cv344 = zext i1 %cmp343 to i64
  store i64 %cv344, ptr %slot64, align 8
  %v345 = load i64, ptr %slot64, align 8
  %cond346 = icmp ne i64 %v345, 0
  br i1 %cond346, label %bb_arm55, label %bb_armnext55
bb_arm55:
  br label %bb_i25
bb_armnext55:
  %v347 = load i64, ptr %slot60, align 8
  %cmp348 = icmp eq i64 %v347, 4
  %cv349 = zext i1 %cmp348 to i64
  store i64 %cv349, ptr %slot65, align 8
  %v350 = load i64, ptr %slot65, align 8
  %cond351 = icmp ne i64 %v350, 0
  br i1 %cond351, label %bb_arm56, label %bb_armnext56
bb_arm56:
  br label %bb_i27
bb_armnext56:
  %v352 = load i64, ptr %slot60, align 8
  %cmp353 = icmp eq i64 %v352, 5
  %cv354 = zext i1 %cmp353 to i64
  store i64 %cv354, ptr %slot66, align 8
  %v355 = load i64, ptr %slot66, align 8
  %cond356 = icmp ne i64 %v355, 0
  br i1 %cond356, label %bb_arm57, label %bb_armnext57
bb_arm57:
  br label %bb_i29
bb_armnext57:
  %v357 = load i64, ptr %slot60, align 8
  %cmp358 = icmp eq i64 %v357, 6
  %cv359 = zext i1 %cmp358 to i64
  store i64 %cv359, ptr %slot67, align 8
  %v360 = load i64, ptr %slot67, align 8
  %cond361 = icmp ne i64 %v360, 0
  br i1 %cond361, label %bb_arm58, label %bb_armnext58
bb_arm58:
  br label %bb_i31
bb_armnext58:
  %v362 = load i64, ptr %slot60, align 8
  %cmp363 = icmp eq i64 %v362, 7
  %cv364 = zext i1 %cmp363 to i64
  store i64 %cv364, ptr %slot68, align 8
  %v365 = load i64, ptr %slot68, align 8
  %cond366 = icmp ne i64 %v365, 0
  br i1 %cond366, label %bb_arm59, label %bb_armnext59
bb_arm59:
  br label %bb_i33
bb_armnext59:
  %v367 = load i64, ptr %slot60, align 8
  %cmp368 = icmp eq i64 %v367, 8
  %cv369 = zext i1 %cmp368 to i64
  store i64 %cv369, ptr %slot69, align 8
  %v370 = load i64, ptr %slot69, align 8
  %cond371 = icmp ne i64 %v370, 0
  br i1 %cond371, label %bb_arm60, label %bb_armnext60
bb_arm60:
  br label %bb_i35
bb_armnext60:
  %v372 = load i64, ptr %slot60, align 8
  %cmp373 = icmp eq i64 %v372, 9
  %cv374 = zext i1 %cmp373 to i64
  store i64 %cv374, ptr %slot70, align 8
  %v375 = load i64, ptr %slot70, align 8
  %cond376 = icmp ne i64 %v375, 0
  br i1 %cond376, label %bb_arm61, label %bb_armnext61
bb_arm61:
  br label %bb_i37
bb_armnext61:
  %v377 = load i64, ptr %slot60, align 8
  %cmp378 = icmp eq i64 %v377, 10
  %cv379 = zext i1 %cmp378 to i64
  store i64 %cv379, ptr %slot71, align 8
  %v380 = load i64, ptr %slot71, align 8
  %cond381 = icmp ne i64 %v380, 0
  br i1 %cond381, label %bb_arm62, label %bb_armnext62
bb_arm62:
  br label %bb_i39
bb_armnext62:
  br label %bb_failure
bb_i19:
  %v382 = load i64, ptr %slot10, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 1, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot10, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %ld386 = load i64, ptr %p385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld386, ptr %slot72, align 8
  %v387 = load i64, ptr %slot72, align 8
  ret i64 %v387
bb_i21:
  %v388 = load i64, ptr %slot10, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 0, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot10, align 8
  %p391 = inttoptr i64 %v390 to ptr
  %ld392 = load i64, ptr %p391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld392, ptr %slot73, align 8
  %v393 = load i64, ptr %slot73, align 8
  ret i64 %v393
bb_i23:
  %v394 = load i64, ptr %slot10, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 0, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot10, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot74, align 8
  %v399 = load i64, ptr %slot74, align 8
  ret i64 %v399
bb_i25:
  %v400 = load i64, ptr %slot10, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 0, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot10, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot75, align 8
  %v405 = load i64, ptr %slot75, align 8
  ret i64 %v405
bb_i27:
  %v406 = load i64, ptr %slot10, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 0, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot10, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot76, align 8
  %v411 = load i64, ptr %slot76, align 8
  ret i64 %v411
bb_i29:
  %v412 = load i64, ptr %slot10, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 0, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot10, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot77, align 8
  %v417 = load i64, ptr %slot77, align 8
  ret i64 %v417
bb_i31:
  %v418 = load i64, ptr %slot10, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 0, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot10, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot78, align 8
  %v423 = load i64, ptr %slot78, align 8
  ret i64 %v423
bb_i33:
  %v424 = load i64, ptr %slot10, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i64 0, ptr %p425, align 8, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot10, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot79, align 8
  %v429 = load i64, ptr %slot79, align 8
  ret i64 %v429
bb_i35:
  %v430 = load i64, ptr %slot10, align 8
  %p431 = inttoptr i64 %v430 to ptr
  store i64 0, ptr %p431, align 8, !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot10, align 8
  %p433 = inttoptr i64 %v432 to ptr
  %ld434 = load i64, ptr %p433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld434, ptr %slot80, align 8
  %v435 = load i64, ptr %slot80, align 8
  ret i64 %v435
bb_i37:
  %v436 = load i64, ptr %slot10, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i64 0, ptr %p437, align 8, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot10, align 8
  %p439 = inttoptr i64 %v438 to ptr
  %ld440 = load i64, ptr %p439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld440, ptr %slot81, align 8
  %v441 = load i64, ptr %slot81, align 8
  ret i64 %v441
bb_i39:
  %v442 = load i64, ptr %slot10, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i64 0, ptr %p443, align 8, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot10, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot82, align 8
  %v447 = load i64, ptr %slot82, align 8
  ret i64 %v447
bb_i41:
  %v448 = load i64, ptr %slot10, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 0, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot10, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i64, ptr %p451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot83, align 8
  %v453 = load i64, ptr %slot83, align 8
  ret i64 %v453
bb_i43:
  %v454 = load i64, ptr %slot10, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i64 0, ptr %p455, align 8, !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot10, align 8
  %p457 = inttoptr i64 %v456 to ptr
  %ld458 = load i64, ptr %p457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld458, ptr %slot84, align 8
  %v459 = load i64, ptr %slot84, align 8
  ret i64 %v459
bb_i45:
  %v460 = load i64, ptr %slot10, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 0, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot10, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot85, align 8
  %v465 = load i64, ptr %slot85, align 8
  ret i64 %v465
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007", linkageName: "myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10976609374755943475, i64 0, !"myl_f_0c155c0779b8bdd25c5e93399d26b7ce8537f2f7388c677f2661e05c296c2007"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!110 = !DILocation(line: 13, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!112 = !DILocation(line: 15, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!114 = !DILocation(line: 18, column: 0, scope: !115)
