target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %callresult60 = alloca [48 x i8], align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %callresult150 = alloca [16 x i8], align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %callresult187 = alloca [48 x i8], align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %callresult277 = alloca [16 x i8], align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %callresult318 = alloca [16 x i8], align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v389 = load i64, ptr %slot1, align 8
  %op390 = add i64 %v389, 32
  store i64 %op390, ptr %slot3, align 8
  %mem391 = alloca i8, i64 16, align 8
  %ptr392 = ptrtoint ptr %mem391 to i64
  store i64 %ptr392, ptr %slot4, align 8
  %mem393 = alloca i8, i64 8, align 8
  %ptr394 = ptrtoint ptr %mem393 to i64
  store i64 %ptr394, ptr %slot5, align 8
  %mem395 = alloca i8, i64 8, align 8
  %ptr396 = ptrtoint ptr %mem395 to i64
  store i64 %ptr396, ptr %slot6, align 8
  %mem397 = alloca i8, i64 8, align 8
  %ptr398 = ptrtoint ptr %mem397 to i64
  store i64 %ptr398, ptr %slot7, align 8
  %mem399 = alloca i8, i64 8, align 8
  %ptr400 = ptrtoint ptr %mem399 to i64
  store i64 %ptr400, ptr %slot8, align 8
  %mem401 = alloca i8, i64 8, align 8
  %ptr402 = ptrtoint ptr %mem401 to i64
  store i64 %ptr402, ptr %slot9, align 8
  %mem403 = alloca i8, i64 8, align 8
  %ptr404 = ptrtoint ptr %mem403 to i64
  store i64 %ptr404, ptr %slot10, align 8
  %mem405 = alloca i8, i64 8, align 8
  %ptr406 = ptrtoint ptr %mem405 to i64
  store i64 %ptr406, ptr %slot11, align 8
  %mem407 = alloca i8, i64 8, align 8
  %ptr408 = ptrtoint ptr %mem407 to i64
  store i64 %ptr408, ptr %slot12, align 8
  %mem409 = alloca i8, i64 8, align 8
  %ptr410 = ptrtoint ptr %mem409 to i64
  store i64 %ptr410, ptr %slot13, align 8
  %mem411 = alloca i8, i64 312, align 8
  %ptr412 = ptrtoint ptr %mem411 to i64
  store i64 %ptr412, ptr %slot14, align 8
  %mem413 = alloca i8, i64 88, align 8
  %ptr414 = ptrtoint ptr %mem413 to i64
  store i64 %ptr414, ptr %slot15, align 8
  %mem415 = alloca i8, i64 8, align 8
  %ptr416 = ptrtoint ptr %mem415 to i64
  store i64 %ptr416, ptr %slot16, align 8
  %mem417 = alloca i8, i64 8, align 8
  %ptr418 = ptrtoint ptr %mem417 to i64
  store i64 %ptr418, ptr %slot17, align 8
  %mem419 = alloca i8, i64 312, align 8
  %ptr420 = ptrtoint ptr %mem419 to i64
  store i64 %ptr420, ptr %slot18, align 8
  %mem421 = alloca i8, i64 8, align 8
  %ptr422 = ptrtoint ptr %mem421 to i64
  store i64 %ptr422, ptr %slot19, align 8
  %mem423 = alloca i8, i64 8, align 8
  %ptr424 = ptrtoint ptr %mem423 to i64
  store i64 %ptr424, ptr %slot20, align 8
  %mem425 = alloca i8, i64 8, align 8
  %ptr426 = ptrtoint ptr %mem425 to i64
  store i64 %ptr426, ptr %slot21, align 8
  %mem427 = alloca i8, i64 16, align 8
  %ptr428 = ptrtoint ptr %mem427 to i64
  store i64 %ptr428, ptr %slot22, align 8
  %mem429 = alloca i8, i64 8, align 8
  %ptr430 = ptrtoint ptr %mem429 to i64
  store i64 %ptr430, ptr %slot23, align 8
  %mem431 = alloca i8, i64 8, align 8
  %ptr432 = ptrtoint ptr %mem431 to i64
  store i64 %ptr432, ptr %slot24, align 8
  %mem433 = alloca i8, i64 8, align 8
  %ptr434 = ptrtoint ptr %mem433 to i64
  store i64 %ptr434, ptr %slot25, align 8
  %mem435 = alloca i8, i64 8, align 8
  %ptr436 = ptrtoint ptr %mem435 to i64
  store i64 %ptr436, ptr %slot26, align 8
  %mem437 = alloca i8, i64 312, align 8
  %ptr438 = ptrtoint ptr %mem437 to i64
  store i64 %ptr438, ptr %slot27, align 8
  %mem439 = alloca i8, i64 48, align 8
  %ptr440 = ptrtoint ptr %mem439 to i64
  store i64 %ptr440, ptr %slot28, align 8
  %mem441 = alloca i8, i64 16, align 8
  %ptr442 = ptrtoint ptr %mem441 to i64
  store i64 %ptr442, ptr %slot29, align 8
  %mem443 = alloca i8, i64 312, align 8
  %ptr444 = ptrtoint ptr %mem443 to i64
  store i64 %ptr444, ptr %slot30, align 8
  %mem445 = alloca i8, i64 48, align 8
  %ptr446 = ptrtoint ptr %mem445 to i64
  store i64 %ptr446, ptr %slot31, align 8
  %mem447 = alloca i8, i64 16, align 8
  %ptr448 = ptrtoint ptr %mem447 to i64
  store i64 %ptr448, ptr %slot32, align 8
  %mem449 = alloca i8, i64 16, align 8
  %ptr450 = ptrtoint ptr %mem449 to i64
  store i64 %ptr450, ptr %slot33, align 8
  %mem451 = alloca i8, i64 312, align 8
  %ptr452 = ptrtoint ptr %mem451 to i64
  store i64 %ptr452, ptr %slot34, align 8
  %mem453 = alloca i8, i64 16, align 8
  %ptr454 = ptrtoint ptr %mem453 to i64
  store i64 %ptr454, ptr %slot35, align 8
  %mem455 = alloca i8, i64 16, align 8
  %ptr456 = ptrtoint ptr %mem455 to i64
  store i64 %ptr456, ptr %slot36, align 8
  %mem457 = alloca i8, i64 312, align 8
  %ptr458 = ptrtoint ptr %mem457 to i64
  store i64 %ptr458, ptr %slot37, align 8
  %mem459 = alloca i8, i64 312, align 8
  %ptr460 = ptrtoint ptr %mem459 to i64
  store i64 %ptr460, ptr %slot38, align 8
  %mem461 = alloca i8, i64 16, align 8
  %ptr462 = ptrtoint ptr %mem461 to i64
  store i64 %ptr462, ptr %slot39, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem463 = alloca i8, i64 8, align 8
  %ptr464 = ptrtoint ptr %mem463 to i64
  store i64 %ptr464, ptr %slot40, align 8
  %v465 = load i64, ptr %slot1, align 8
  %op466 = add i64 %v465, 64
  store i64 %op466, ptr %slot41, align 8
  %v467 = load i64, ptr %slot41, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %ld469 = load i64, ptr %p468, align 8, !alias.scope !4, !noalias !3
  store i64 %ld469, ptr %slot42, align 8
  %stack470 = call ptr @llvm.stacksave()
  %stackaddr471 = ptrtoint ptr %stack470 to i64
  %v472 = load i64, ptr %slot42, align 8
  %cmp473 = icmp ult i64 %stackaddr471, %v472
  %cv474 = zext i1 %cmp473 to i64
  store i64 %cv474, ptr %slot43, align 8
  %v475 = load i64, ptr %slot43, align 8
  %cond476 = icmp ne i64 %v475, 0
  br i1 %cond476, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v477 = load i64, ptr %slot1, align 8
  %p478 = inttoptr i64 %v477 to ptr
  call void @myl_qbe_fail_frame(ptr %p478) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v479 = load i64, ptr %slot2, align 8
  %v480 = load i64, ptr %slot19, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i64 %v479, ptr %p481, align 8, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot1, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %call484 = call ptr @myl_qbe_heap(ptr %p483) nomerge, !dbg !112
  %calladdr485 = ptrtoint ptr %call484 to i64
  store i64 %calladdr485, ptr %slot44, align 8
  %v486 = load i64, ptr %slot1, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %call488 = call i64 @myl_qbe_region_mark(ptr %p487) nomerge, !dbg !112
  store i64 %call488, ptr %slot45, align 8
  %v489 = load i64, ptr %slot5, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i32 0, ptr %p490, align 4, !alias.scope !3, !noalias !4
  %v491 = load i64, ptr %slot6, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 0, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot7, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i32 0, ptr %p494, align 4, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot8, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i32 0, ptr %p496, align 4, !alias.scope !3, !noalias !4
  %v497 = load i64, ptr %slot9, align 8
  %p498 = inttoptr i64 %v497 to ptr
  store i32 0, ptr %p498, align 4, !alias.scope !3, !noalias !4
  %v499 = load i64, ptr %slot10, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i32 0, ptr %p500, align 4, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot11, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i32 0, ptr %p502, align 4, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot12, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i32 0, ptr %p504, align 4, !alias.scope !3, !noalias !4
  %v505 = load i64, ptr %slot13, align 8
  %p506 = inttoptr i64 %v505 to ptr
  store i32 0, ptr %p506, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v507 = load i64, ptr %slot19, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %ld509 = load i64, ptr %p508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld509, ptr %slot46, align 8
  %v510 = load i64, ptr %slot46, align 8
  %v511 = load i64, ptr %slot23, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i64 %v510, ptr %p512, align 8, !alias.scope !3, !noalias !4
  %v513 = load i64, ptr %slot27, align 8
  store i64 %v513, ptr %slot47, align 8
  %v514 = load i64, ptr %slot47, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 0, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot47, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 0, ptr %p517, align 4, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot47, align 8
  %v519 = load i64, ptr %slot24, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i64 %v518, ptr %p520, align 8, !alias.scope !3, !noalias !4
  %p521 = inttoptr i64 ptrtoint (ptr @myl_lit_48c1b2cf871bbf29cf2339e23b6a684925b7d02da971745c51b0881c1204eafb to i64) to ptr
  %ld522 = load i64, ptr %p521, align 8, !alias.scope !4, !noalias !3
  store i64 %ld522, ptr %slot48, align 8
  %v523 = load i64, ptr %slot48, align 8
  %v524 = load i64, ptr %slot25, align 8
  %p525 = inttoptr i64 %v524 to ptr
  store i64 %v523, ptr %p525, align 8, !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot25, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot49, align 8
  %v529 = load i64, ptr %slot49, align 8
  %v530 = load i64, ptr %slot17, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot17, align 8
  store i64 %v532, ptr %slot50, align 8
  %v533 = load i64, ptr %slot18, align 8
  store i64 %v533, ptr %slot51, align 8
  %v534 = load i64, ptr %slot50, align 8
  %v535 = load i64, ptr %slot51, align 8
  %p536 = inttoptr i64 %v534 to ptr
  %p537 = inttoptr i64 %v535 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p537, ptr %p536, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot12, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i32 2, ptr %p539, align 4, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot11, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i32 1, ptr %p541, align 4, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot16, align 8
  store i64 %v542, ptr %slot52, align 8
  %v543 = load i64, ptr %slot18, align 8
  store i64 %v543, ptr %slot53, align 8
  %v544 = load i64, ptr %slot53, align 8
  %v545 = load i64, ptr %slot52, align 8
  %p546 = inttoptr i64 %v544 to ptr
  %p547 = inttoptr i64 %v545 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p547, ptr %p546, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot10, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i32 2, ptr %p549, align 4, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot12, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i32, ptr %p551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld552, ptr %slot54, align 8
  %v553 = load i32, ptr %slot54, align 8
  %v554 = load i64, ptr %slot10, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i32 %v553, ptr %p555, align 4, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot11, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i32 0, ptr %p557, align 4, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot9, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 1, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot52, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot55, align 8
  %v563 = load i64, ptr %slot55, align 8
  %v564 = load i64, ptr %slot25, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i64 %v563, ptr %p565, align 8, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot23, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot56, align 8
  %v569 = load i64, ptr %slot24, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot57, align 8
  %v572 = load i64, ptr %slot25, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot58, align 8
  %v575 = load i64, ptr %slot1, align 8
  %v576 = load i64, ptr %slot56, align 8
  %v577 = load i64, ptr %slot57, align 8
  %v578 = load i64, ptr %slot58, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult60, i64 %v575, i64 %v576, i64 %v577, i64 %v578) nomerge, !dbg !114
  %addr579 = ptrtoint ptr %callresult60 to i64
  store i64 %addr579, ptr %slot59, align 8
  %v580 = load i64, ptr %slot59, align 8
  %v581 = load i64, ptr %slot23, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot23, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot61, align 8
  %v586 = load i64, ptr %slot18, align 8
  store i64 %v586, ptr %slot62, align 8
  %v587 = load i64, ptr %slot61, align 8
  %v588 = load i64, ptr %slot62, align 8
  %p589 = inttoptr i64 %v587 to ptr
  %p590 = inttoptr i64 %v588 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p590, ptr %p589, i64 48, i1 false)
  %v591 = load i64, ptr %slot12, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 2, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot11, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 1, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot5, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i32, ptr %p596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld597, ptr %slot63, align 8
  %v598 = load i32, ptr %slot63, align 8
  %cv599 = zext i32 %v598 to i64
  %cond600 = icmp ne i64 %cv599, 0
  br i1 %cond600, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v601 = load i64, ptr %slot5, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i32 0, ptr %p602, align 4, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot14, align 8
  store i64 %v603, ptr %slot64, align 8
  %v604 = load i64, ptr %slot6, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %ld606 = load i32, ptr %p605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld606, ptr %slot65, align 8
  %v607 = load i32, ptr %slot65, align 8
  %op608 = and i32 %v607, 28
  store i32 %op608, ptr %slot66, align 8
  %v609 = load i32, ptr %slot66, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v612 = load i64, ptr %slot44, align 8
  store i64 %v612, ptr %slot67, align 8
  %v613 = load i64, ptr %slot67, align 8
  %v614 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v613, i64 %v614) nomerge, !dbg !114
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v615 = load i64, ptr %slot44, align 8
  store i64 %v615, ptr %slot68, align 8
  %v616 = load i64, ptr %slot68, align 8
  %v617 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v616, i64 %v617) nomerge, !dbg !114
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v618 = load i64, ptr %slot9, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %ld620 = load i32, ptr %p619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld620, ptr %slot69, align 8
  %v621 = load i32, ptr %slot69, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcslotdrop45, label %bb_rcslotdone45
bb_rcslotdrop45:
  %v624 = load i64, ptr %slot9, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i32 0, ptr %p625, align 4, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot16, align 8
  store i64 %v626, ptr %slot70, align 8
  %v627 = load i64, ptr %slot10, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %ld629 = load i32, ptr %p628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld629, ptr %slot71, align 8
  %v630 = load i32, ptr %slot71, align 8
  %op631 = and i32 %v630, 28
  store i32 %op631, ptr %slot72, align 8
  %v632 = load i32, ptr %slot72, align 8
  %cv633 = zext i32 %v632 to i64
  %cond634 = icmp ne i64 %cv633, 0
  br i1 %cond634, label %bb_rcslotrole45, label %bb_rcslotowner45
bb_rcslotrole45:
  %v635 = load i64, ptr %slot44, align 8
  store i64 %v635, ptr %slot73, align 8
  %v636 = load i64, ptr %slot70, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot74, align 8
  %v639 = load i64, ptr %slot74, align 8
  %cmp640 = icmp ne i64 %v639, 0
  %cv641 = zext i1 %cmp640 to i32
  store i32 %cv641, ptr %slot75, align 8
  %v642 = load i32, ptr %slot75, align 8
  %cv643 = zext i32 %v642 to i64
  %cond644 = icmp ne i64 %cv643, 0
  br i1 %cond644, label %bb_rcgnn61, label %bb_rcgdone61
bb_rcgnn61:
  %v645 = load i64, ptr %slot74, align 8
  %op646 = sub i64 %v645, 16
  store i64 %op646, ptr %slot76, align 8
  %v647 = load i64, ptr %slot74, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %rgep649 = getelementptr i8, ptr %p648, i64 -16
  %ld650 = load i64, ptr %rgep649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld650, ptr %slot77, align 8
  %v651 = load i64, ptr %slot77, align 8
  %op652 = and i64 %v651, 4611686018427387906
  store i64 %op652, ptr %slot78, align 8
  %v653 = load i64, ptr %slot78, align 8
  %cmp654 = icmp ne i64 %v653, 0
  %cv655 = zext i1 %cmp654 to i32
  store i32 %cv655, ptr %slot79, align 8
  %v656 = load i32, ptr %slot79, align 8
  %cv657 = zext i32 %v656 to i64
  %cond658 = icmp ne i64 %cv657, 0
  br i1 %cond658, label %bb_rcgclear61, label %bb_rcgcounted61
bb_rcgcounted61:
  %v659 = load i64, ptr %slot74, align 8
  %op660 = sub i64 %v659, 24
  store i64 %op660, ptr %slot80, align 8
  %v661 = load i64, ptr %slot74, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %rgep663 = getelementptr i8, ptr %p662, i64 -24
  %ld664 = load i64, ptr %rgep663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld664, ptr %slot81, align 8
  %v665 = load i64, ptr %slot81, align 8
  %op666 = sub i64 %v665, 1
  store i64 %op666, ptr %slot82, align 8
  %v667 = load i64, ptr %slot82, align 8
  %cmp668 = icmp eq i64 %v667, 0
  %cv669 = zext i1 %cmp668 to i32
  store i32 %cv669, ptr %slot83, align 8
  %v670 = load i32, ptr %slot83, align 8
  %cv671 = zext i32 %v670 to i64
  %cond672 = icmp ne i64 %cv671, 0
  br i1 %cond672, label %bb_rcglast61, label %bb_rcgdec61
bb_rcglast61:
  %v673 = load i64, ptr %slot74, align 8
  %op674 = sub i64 %v673, 32
  store i64 %op674, ptr %slot84, align 8
  %v675 = load i64, ptr %slot74, align 8
  %p676 = inttoptr i64 %v675 to ptr
  %rgep677 = getelementptr i8, ptr %p676, i64 -32
  %ld678 = load i64, ptr %rgep677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld678, ptr %slot85, align 8
  %v679 = load i64, ptr %slot85, align 8
  %cmp680 = icmp ne i64 %v679, 0
  %cv681 = zext i1 %cmp680 to i32
  store i32 %cv681, ptr %slot86, align 8
  %v682 = load i32, ptr %slot86, align 8
  %cv683 = zext i32 %v682 to i64
  %cond684 = icmp ne i64 %cv683, 0
  br i1 %cond684, label %bb_rcgdec61, label %bb_rcgslow61
bb_rcgslow61:
  %v685 = load i64, ptr %slot73, align 8
  %v686 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v685, i64 %v686) nomerge, !dbg !114
  br label %bb_rcgdone61
bb_rcgdec61:
  %v687 = load i64, ptr %slot82, align 8
  %v688 = load i64, ptr %slot74, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %rgep690 = getelementptr i8, ptr %p689, i64 -24
  store i64 %v687, ptr %rgep690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear61
bb_rcgclear61:
  %v691 = load i64, ptr %slot70, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 0, ptr %p692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone61
bb_rcgdone61:
  br label %bb_rcslotdone45
bb_rcslotowner45:
  %v693 = load i64, ptr %slot44, align 8
  store i64 %v693, ptr %slot87, align 8
  %v694 = load i64, ptr %slot70, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i64, ptr %p695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld696, ptr %slot88, align 8
  %v697 = load i64, ptr %slot88, align 8
  %cmp698 = icmp ne i64 %v697, 0
  %cv699 = zext i1 %cmp698 to i32
  store i32 %cv699, ptr %slot89, align 8
  %v700 = load i32, ptr %slot89, align 8
  %cv701 = zext i32 %v700 to i64
  %cond702 = icmp ne i64 %cv701, 0
  br i1 %cond702, label %bb_rcgnn76, label %bb_rcgdone76
bb_rcgnn76:
  %v703 = load i64, ptr %slot88, align 8
  %op704 = sub i64 %v703, 16
  store i64 %op704, ptr %slot90, align 8
  %v705 = load i64, ptr %slot88, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %rgep707 = getelementptr i8, ptr %p706, i64 -16
  %ld708 = load i64, ptr %rgep707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld708, ptr %slot91, align 8
  %v709 = load i64, ptr %slot91, align 8
  %op710 = and i64 %v709, 4611686018427387906
  store i64 %op710, ptr %slot92, align 8
  %v711 = load i64, ptr %slot92, align 8
  %cmp712 = icmp ne i64 %v711, 0
  %cv713 = zext i1 %cmp712 to i32
  store i32 %cv713, ptr %slot93, align 8
  %v714 = load i32, ptr %slot93, align 8
  %cv715 = zext i32 %v714 to i64
  %cond716 = icmp ne i64 %cv715, 0
  br i1 %cond716, label %bb_rcgclear76, label %bb_rcgcounted76
bb_rcgcounted76:
  %v717 = load i64, ptr %slot88, align 8
  %op718 = sub i64 %v717, 32
  store i64 %op718, ptr %slot94, align 8
  %v719 = load i64, ptr %slot88, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %rgep721 = getelementptr i8, ptr %p720, i64 -32
  %ld722 = load i64, ptr %rgep721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld722, ptr %slot95, align 8
  %v723 = load i64, ptr %slot95, align 8
  %op724 = sub i64 %v723, 1
  store i64 %op724, ptr %slot96, align 8
  %v725 = load i64, ptr %slot96, align 8
  %cmp726 = icmp eq i64 %v725, 0
  %cv727 = zext i1 %cmp726 to i32
  store i32 %cv727, ptr %slot97, align 8
  %v728 = load i32, ptr %slot97, align 8
  %cv729 = zext i32 %v728 to i64
  %cond730 = icmp ne i64 %cv729, 0
  br i1 %cond730, label %bb_rcglast76, label %bb_rcgdec76
bb_rcglast76:
  %v731 = load i64, ptr %slot88, align 8
  %op732 = sub i64 %v731, 24
  store i64 %op732, ptr %slot98, align 8
  %v733 = load i64, ptr %slot88, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %rgep735 = getelementptr i8, ptr %p734, i64 -24
  %ld736 = load i64, ptr %rgep735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld736, ptr %slot99, align 8
  %v737 = load i64, ptr %slot99, align 8
  %cmp738 = icmp ne i64 %v737, 0
  %cv739 = zext i1 %cmp738 to i32
  store i32 %cv739, ptr %slot100, align 8
  %v740 = load i32, ptr %slot100, align 8
  %cv741 = zext i32 %v740 to i64
  %cond742 = icmp ne i64 %cv741, 0
  br i1 %cond742, label %bb_rcgdec76, label %bb_rcgslow76
bb_rcgslow76:
  %v743 = load i64, ptr %slot87, align 8
  %v744 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v743, i64 %v744) nomerge, !dbg !114
  br label %bb_rcgdone76
bb_rcgdec76:
  %v745 = load i64, ptr %slot96, align 8
  %v746 = load i64, ptr %slot88, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %rgep748 = getelementptr i8, ptr %p747, i64 -32
  store i64 %v745, ptr %rgep748, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear76
bb_rcgclear76:
  %v749 = load i64, ptr %slot70, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 0, ptr %p750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone76
bb_rcgdone76:
  br label %bb_rcslotdone45
bb_rcslotdone45:
  %v751 = load i64, ptr %slot14, align 8
  store i64 %v751, ptr %slot101, align 8
  %v752 = load i64, ptr %slot18, align 8
  store i64 %v752, ptr %slot102, align 8
  %v753 = load i64, ptr %slot102, align 8
  %v754 = load i64, ptr %slot101, align 8
  %p755 = inttoptr i64 %v753 to ptr
  %p756 = inttoptr i64 %v754 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p756, ptr %p755, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot6, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i32 2, ptr %p758, align 4, !alias.scope !3, !noalias !4
  %v759 = load i64, ptr %slot12, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i32, ptr %p760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld761, ptr %slot103, align 8
  %v762 = load i32, ptr %slot103, align 8
  %v763 = load i64, ptr %slot6, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i32 %v762, ptr %p764, align 4, !alias.scope !3, !noalias !4
  %v765 = load i64, ptr %slot11, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i32 0, ptr %p766, align 4, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot5, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i32 1, ptr %p768, align 4, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot101, align 8
  %v770 = load i64, ptr %slot23, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i64 %v769, ptr %p771, align 8, !alias.scope !3, !noalias !4
  %v772 = load i64, ptr %slot23, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %ld774 = load i64, ptr %p773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld774, ptr %slot104, align 8
  %v775 = load i64, ptr %slot104, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %ld777 = load i32, ptr %p776, align 4
  %ext778 = zext i32 %ld777 to i64
  store i64 %ext778, ptr %slot105, align 8
  %v779 = load i64, ptr %slot105, align 8
  %cmp780 = icmp eq i64 %v779, 0
  %cv781 = zext i1 %cmp780 to i64
  store i64 %cv781, ptr %slot106, align 8
  %v782 = load i64, ptr %slot106, align 8
  %cond783 = icmp ne i64 %v782, 0
  br i1 %cond783, label %bb_rctryok89, label %bb_rctryerror89
bb_rctryerror89:
  %p784 = inttoptr i64 ptrtoint (ptr @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p784, i64 12884901892) "call-inline-cost"="0", !dbg !116
  %v785 = load i64, ptr %slot104, align 8
  %op786 = add i64 %v785, 8
  store i64 %op786, ptr %slot107, align 8
  %v787 = load i64, ptr %slot28, align 8
  store i64 %v787, ptr %slot108, align 8
  %v788 = load i64, ptr %slot108, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i64 0, ptr %p789, align 8, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot108, align 8
  %p792 = inttoptr i64 %v790 to ptr
  %gep793 = getelementptr i8, ptr %p792, i64 8
  %op791 = ptrtoint ptr %gep793 to i64
  store i64 %op791, ptr %slot109, align 8
  %v794 = load i64, ptr %slot109, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i64 0, ptr %p795, align 8, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot108, align 8
  %p797 = inttoptr i64 %v796 to ptr
  store i32 1, ptr %p797, align 4, !alias.scope !3, !noalias !4
  %v798 = load i64, ptr %slot108, align 8
  %p800 = inttoptr i64 %v798 to ptr
  %gep801 = getelementptr i8, ptr %p800, i64 8
  %op799 = ptrtoint ptr %gep801 to i64
  store i64 %op799, ptr %slot110, align 8
  %v802 = load i64, ptr %slot13, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i32 1, ptr %p803, align 4, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot45, align 8
  store i64 %v804, ptr %slot111, align 8
  %v805 = load i64, ptr %slot108, align 8
  %v806 = load i64, ptr %slot23, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i64 %v805, ptr %p807, align 8, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot5, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i32, ptr %p809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld810, ptr %slot112, align 8
  %v811 = load i32, ptr %slot112, align 8
  %cv812 = zext i32 %v811 to i64
  %cond813 = icmp ne i64 %cv812, 0
  br i1 %cond813, label %bb_rcslotdrop100, label %bb_rcslotdone100
bb_rcslotdrop100:
  %v814 = load i64, ptr %slot5, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i32 0, ptr %p815, align 4, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot14, align 8
  store i64 %v816, ptr %slot113, align 8
  %v817 = load i64, ptr %slot6, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i32, ptr %p818, align 4, !alias.scope !3, !noalias !4
  store i32 %ld819, ptr %slot114, align 8
  %v820 = load i32, ptr %slot114, align 8
  %op821 = and i32 %v820, 28
  store i32 %op821, ptr %slot115, align 8
  %v822 = load i32, ptr %slot115, align 8
  %cv823 = zext i32 %v822 to i64
  %cond824 = icmp ne i64 %cv823, 0
  br i1 %cond824, label %bb_rcslotrole100, label %bb_rcslotowner100
bb_rcslotrole100:
  %v825 = load i64, ptr %slot44, align 8
  store i64 %v825, ptr %slot116, align 8
  %v826 = load i64, ptr %slot116, align 8
  %v827 = load i64, ptr %slot113, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v826, i64 %v827) nomerge, !dbg !116
  br label %bb_rcslotdone100
bb_rcslotowner100:
  %v828 = load i64, ptr %slot44, align 8
  store i64 %v828, ptr %slot117, align 8
  %v829 = load i64, ptr %slot117, align 8
  %v830 = load i64, ptr %slot113, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v829, i64 %v830) nomerge, !dbg !116
  br label %bb_rcslotdone100
bb_rcslotdone100:
  br label %bb_i6
bb_rctryok89:
  %v831 = load i64, ptr %slot28, align 8
  store i64 %v831, ptr %slot118, align 8
  %v832 = load i64, ptr %slot118, align 8
  %p833 = inttoptr i64 %v832 to ptr
  store i64 0, ptr %p833, align 8, !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot118, align 8
  %p836 = inttoptr i64 %v834 to ptr
  %gep837 = getelementptr i8, ptr %p836, i64 8
  %op835 = ptrtoint ptr %gep837 to i64
  store i64 %op835, ptr %slot119, align 8
  %v838 = load i64, ptr %slot119, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i64 0, ptr %p839, align 8, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot118, align 8
  %p842 = inttoptr i64 %v840 to ptr
  %gep843 = getelementptr i8, ptr %p842, i64 16
  %op841 = ptrtoint ptr %gep843 to i64
  store i64 %op841, ptr %slot120, align 8
  %v844 = load i64, ptr %slot120, align 8
  %p845 = inttoptr i64 %v844 to ptr
  store i64 0, ptr %p845, align 8, !alias.scope !3, !noalias !4
  %v846 = load i64, ptr %slot118, align 8
  %p848 = inttoptr i64 %v846 to ptr
  %gep849 = getelementptr i8, ptr %p848, i64 24
  %op847 = ptrtoint ptr %gep849 to i64
  store i64 %op847, ptr %slot121, align 8
  %v850 = load i64, ptr %slot121, align 8
  %p851 = inttoptr i64 %v850 to ptr
  store i64 0, ptr %p851, align 8, !alias.scope !3, !noalias !4
  %v852 = load i64, ptr %slot118, align 8
  %p854 = inttoptr i64 %v852 to ptr
  %gep855 = getelementptr i8, ptr %p854, i64 32
  %op853 = ptrtoint ptr %gep855 to i64
  store i64 %op853, ptr %slot122, align 8
  %v856 = load i64, ptr %slot122, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i64 0, ptr %p857, align 8, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot13, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i32 1, ptr %p859, align 4, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot104, align 8
  %op861 = add i64 %v860, 8
  store i64 %op861, ptr %slot123, align 8
  %v862 = load i64, ptr %slot45, align 8
  store i64 %v862, ptr %slot124, align 8
  %v863 = load i64, ptr %slot44, align 8
  %v864 = load i64, ptr %slot118, align 8
  %v865 = load i64, ptr %slot123, align 8
  %v866 = load i64, ptr %slot124, align 8
  %cv867 = trunc i64 %v866 to i32
  %call868 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v863, i64 %v864, i64 %v865, i32 %cv867) nomerge, !dbg !116
  store i32 %call868, ptr %slot125, align 8
  %v869 = load i32, ptr %slot125, align 8
  %cv870 = zext i32 %v869 to i64
  %cond871 = icmp ne i64 %cv870, 0
  br i1 %cond871, label %bb_rcsuccess117, label %bb_rcfailure117
bb_rcfailure117:
  %v872 = load i64, ptr %slot44, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %call874 = call i32 @myl_rc_take_failure(ptr %p873) nomerge, !dbg !116
  store i32 %call874, ptr %slot126, align 8
  %v875 = load i64, ptr %slot1, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %v877 = load i32, ptr %slot126, align 8
  %call878 = call i32 @myl_qbe_rc_status(ptr %p876, i32 %v877) nomerge, !dbg !116
  store i32 %call878, ptr %slot127, align 8
  br label %bb_failure
bb_rcsuccess117:
  %v879 = load i64, ptr %slot118, align 8
  %v880 = load i64, ptr %slot23, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 %v879, ptr %p881, align 8, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot23, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %ld884 = load i64, ptr %p883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld884, ptr %slot128, align 8
  %v885 = load i64, ptr %slot18, align 8
  store i64 %v885, ptr %slot129, align 8
  %v886 = load i64, ptr %slot128, align 8
  %v887 = load i64, ptr %slot129, align 8
  %p888 = inttoptr i64 %v886 to ptr
  %p889 = inttoptr i64 %v887 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p889, ptr %p888, i64 40, i1 false)
  %v890 = load i64, ptr %slot12, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 2, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot11, align 8
  %p893 = inttoptr i64 %v892 to ptr
  store i32 1, ptr %p893, align 4, !alias.scope !3, !noalias !4
  %v894 = load i64, ptr %slot5, align 8
  %p895 = inttoptr i64 %v894 to ptr
  %ld896 = load i32, ptr %p895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld896, ptr %slot130, align 8
  %v897 = load i32, ptr %slot130, align 8
  %cv898 = zext i32 %v897 to i64
  %cond899 = icmp ne i64 %cv898, 0
  br i1 %cond899, label %bb_rcslotdrop126, label %bb_rcslotdone126
bb_rcslotdrop126:
  %v900 = load i64, ptr %slot5, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i32 0, ptr %p901, align 4, !alias.scope !3, !noalias !4
  %v902 = load i64, ptr %slot14, align 8
  store i64 %v902, ptr %slot131, align 8
  %v903 = load i64, ptr %slot6, align 8
  %p904 = inttoptr i64 %v903 to ptr
  %ld905 = load i32, ptr %p904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld905, ptr %slot132, align 8
  %v906 = load i32, ptr %slot132, align 8
  %op907 = and i32 %v906, 28
  store i32 %op907, ptr %slot133, align 8
  %v908 = load i32, ptr %slot133, align 8
  %cv909 = zext i32 %v908 to i64
  %cond910 = icmp ne i64 %cv909, 0
  br i1 %cond910, label %bb_rcslotrole126, label %bb_rcslotowner126
bb_rcslotrole126:
  %v911 = load i64, ptr %slot44, align 8
  store i64 %v911, ptr %slot134, align 8
  %v912 = load i64, ptr %slot134, align 8
  %v913 = load i64, ptr %slot131, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v912, i64 %v913) nomerge, !dbg !116
  br label %bb_rcslotdone126
bb_rcslotowner126:
  %v914 = load i64, ptr %slot44, align 8
  store i64 %v914, ptr %slot135, align 8
  %v915 = load i64, ptr %slot135, align 8
  %v916 = load i64, ptr %slot131, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v915, i64 %v916) nomerge, !dbg !116
  br label %bb_rcslotdone126
bb_rcslotdone126:
  %v917 = load i64, ptr %slot14, align 8
  store i64 %v917, ptr %slot136, align 8
  %v918 = load i64, ptr %slot18, align 8
  store i64 %v918, ptr %slot137, align 8
  %v919 = load i64, ptr %slot137, align 8
  %v920 = load i64, ptr %slot136, align 8
  %p921 = inttoptr i64 %v919 to ptr
  %p922 = inttoptr i64 %v920 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p922, ptr %p921, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot6, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i32 2, ptr %p924, align 4, !alias.scope !3, !noalias !4
  %v925 = load i64, ptr %slot12, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ld927 = load i32, ptr %p926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld927, ptr %slot138, align 8
  %v928 = load i32, ptr %slot138, align 8
  %v929 = load i64, ptr %slot6, align 8
  %p930 = inttoptr i64 %v929 to ptr
  store i32 %v928, ptr %p930, align 4, !alias.scope !3, !noalias !4
  %v931 = load i64, ptr %slot11, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i32 0, ptr %p932, align 4, !alias.scope !3, !noalias !4
  %v933 = load i64, ptr %slot5, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i32 1, ptr %p934, align 4, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot136, align 8
  %v936 = load i64, ptr %slot23, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i64 %v935, ptr %p937, align 8, !alias.scope !3, !noalias !4
  br label %bb_i7
bb_i6:
  %v938 = load i64, ptr %slot23, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot139, align 8
  %v941 = load i64, ptr %slot5, align 8
  %p942 = inttoptr i64 %v941 to ptr
  %ld943 = load i32, ptr %p942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld943, ptr %slot140, align 8
  %v944 = load i32, ptr %slot140, align 8
  %cv945 = zext i32 %v944 to i64
  %cond946 = icmp ne i64 %cv945, 0
  br i1 %cond946, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v947 = load i64, ptr %slot5, align 8
  %p948 = inttoptr i64 %v947 to ptr
  store i32 0, ptr %p948, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone144
bb_rcslotdone144:
  %v949 = load i64, ptr %slot139, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ret951 = load { i64, i64 }, ptr %p950, align 8
  ret { i64, i64 } %ret951
bb_i7:
  %v952 = load i64, ptr %slot5, align 8
  %p953 = inttoptr i64 %v952 to ptr
  %ld954 = load i32, ptr %p953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld954, ptr %slot141, align 8
  %v955 = load i32, ptr %slot141, align 8
  %cv956 = zext i32 %v955 to i64
  %cond957 = icmp ne i64 %cv956, 0
  br i1 %cond957, label %bb_rcslotdrop156, label %bb_rcslotdone156
bb_rcslotdrop156:
  %v958 = load i64, ptr %slot5, align 8
  %p959 = inttoptr i64 %v958 to ptr
  store i32 0, ptr %p959, align 4, !alias.scope !3, !noalias !4
  %v960 = load i64, ptr %slot14, align 8
  store i64 %v960, ptr %slot142, align 8
  %v961 = load i64, ptr %slot6, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i32, ptr %p962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld963, ptr %slot143, align 8
  %v964 = load i32, ptr %slot143, align 8
  %op965 = and i32 %v964, 28
  store i32 %op965, ptr %slot144, align 8
  %v966 = load i32, ptr %slot144, align 8
  %cv967 = zext i32 %v966 to i64
  %cond968 = icmp ne i64 %cv967, 0
  br i1 %cond968, label %bb_rcslotrole156, label %bb_rcslotowner156
bb_rcslotrole156:
  %v969 = load i64, ptr %slot44, align 8
  store i64 %v969, ptr %slot145, align 8
  %v970 = load i64, ptr %slot145, align 8
  %v971 = load i64, ptr %slot142, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v970, i64 %v971) nomerge, !dbg !118
  br label %bb_rcslotdone156
bb_rcslotowner156:
  %v972 = load i64, ptr %slot44, align 8
  store i64 %v972, ptr %slot146, align 8
  %v973 = load i64, ptr %slot146, align 8
  %v974 = load i64, ptr %slot142, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v973, i64 %v974) nomerge, !dbg !118
  br label %bb_rcslotdone156
bb_rcslotdone156:
  %v975 = load i64, ptr %slot19, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i64, ptr %p976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld977, ptr %slot147, align 8
  %v978 = load i64, ptr %slot147, align 8
  %v979 = load i64, ptr %slot23, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i64 %v978, ptr %p980, align 8, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot23, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %ld983 = load i64, ptr %p982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld983, ptr %slot148, align 8
  %v984 = load i64, ptr %slot1, align 8
  %v985 = load i64, ptr %slot148, align 8
  %call986 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v984, i64 %v985) nomerge, !dbg !120
  store { i64, i64 } %call986, ptr %callresult150, align 8
  %addr987 = ptrtoint ptr %callresult150 to i64
  store i64 %addr987, ptr %slot149, align 8
  %v988 = load i64, ptr %slot149, align 8
  %v989 = load i64, ptr %slot23, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 %v988, ptr %p990, align 8, !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot5, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i32, ptr %p992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld993, ptr %slot151, align 8
  %v994 = load i32, ptr %slot151, align 8
  %cv995 = zext i32 %v994 to i64
  %cond996 = icmp ne i64 %cv995, 0
  br i1 %cond996, label %bb_rcslotdrop168, label %bb_rcslotdone168
bb_rcslotdrop168:
  %v997 = load i64, ptr %slot5, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i32 0, ptr %p998, align 4, !alias.scope !3, !noalias !4
  %v999 = load i64, ptr %slot14, align 8
  store i64 %v999, ptr %slot152, align 8
  %v1000 = load i64, ptr %slot6, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i32, ptr %p1001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1002, ptr %slot153, align 8
  %v1003 = load i32, ptr %slot153, align 8
  %op1004 = and i32 %v1003, 28
  store i32 %op1004, ptr %slot154, align 8
  %v1005 = load i32, ptr %slot154, align 8
  %cv1006 = zext i32 %v1005 to i64
  %cond1007 = icmp ne i64 %cv1006, 0
  br i1 %cond1007, label %bb_rcslotrole168, label %bb_rcslotowner168
bb_rcslotrole168:
  %v1008 = load i64, ptr %slot44, align 8
  store i64 %v1008, ptr %slot155, align 8
  %v1009 = load i64, ptr %slot155, align 8
  %v1010 = load i64, ptr %slot152, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1009, i64 %v1010) nomerge, !dbg !120
  br label %bb_rcslotdone168
bb_rcslotowner168:
  %v1011 = load i64, ptr %slot44, align 8
  store i64 %v1011, ptr %slot156, align 8
  %v1012 = load i64, ptr %slot156, align 8
  %v1013 = load i64, ptr %slot152, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1012, i64 %v1013) nomerge, !dbg !120
  br label %bb_rcslotdone168
bb_rcslotdone168:
  %v1014 = load i64, ptr %slot23, align 8
  %p1015 = inttoptr i64 %v1014 to ptr
  %ld1016 = load i64, ptr %p1015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1016, ptr %slot157, align 8
  %v1017 = load i64, ptr %slot157, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %ld1019 = load i32, ptr %p1018, align 4
  %ext1020 = zext i32 %ld1019 to i64
  store i64 %ext1020, ptr %slot158, align 8
  %v1021 = load i64, ptr %slot158, align 8
  %cmp1022 = icmp eq i64 %v1021, 0
  %cv1023 = zext i1 %cmp1022 to i64
  store i64 %cv1023, ptr %slot159, align 8
  %v1024 = load i64, ptr %slot159, align 8
  %cond1025 = icmp ne i64 %v1024, 0
  br i1 %cond1025, label %bb_rctryok176, label %bb_rctryerror176
bb_rctryerror176:
  %p1026 = inttoptr i64 ptrtoint (ptr @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1026, i64 12884901898) "call-inline-cost"="0", !dbg !122
  %v1027 = load i64, ptr %slot157, align 8
  %op1028 = add i64 %v1027, 8
  store i64 %op1028, ptr %slot160, align 8
  %v1029 = load i64, ptr %slot29, align 8
  store i64 %v1029, ptr %slot161, align 8
  %v1030 = load i64, ptr %slot161, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  store i64 0, ptr %p1031, align 8, !alias.scope !3, !noalias !4
  %v1032 = load i64, ptr %slot161, align 8
  %p1034 = inttoptr i64 %v1032 to ptr
  %gep1035 = getelementptr i8, ptr %p1034, i64 8
  %op1033 = ptrtoint ptr %gep1035 to i64
  store i64 %op1033, ptr %slot162, align 8
  %v1036 = load i64, ptr %slot162, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i64 0, ptr %p1037, align 8, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot161, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i32 1, ptr %p1039, align 4, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot161, align 8
  %p1042 = inttoptr i64 %v1040 to ptr
  %gep1043 = getelementptr i8, ptr %p1042, i64 8
  %op1041 = ptrtoint ptr %gep1043 to i64
  store i64 %op1041, ptr %slot163, align 8
  %v1044 = load i64, ptr %slot13, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 1, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot45, align 8
  store i64 %v1046, ptr %slot164, align 8
  %v1047 = load i64, ptr %slot161, align 8
  %v1048 = load i64, ptr %slot23, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  store i64 %v1047, ptr %p1049, align 8, !alias.scope !3, !noalias !4
  br label %bb_i12
bb_rctryok176:
  %v1050 = load i64, ptr %slot29, align 8
  store i64 %v1050, ptr %slot165, align 8
  %v1051 = load i64, ptr %slot165, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  store i64 0, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  %v1053 = load i64, ptr %slot13, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 1, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot157, align 8
  %op1056 = add i64 %v1055, 8
  store i64 %op1056, ptr %slot166, align 8
  %v1057 = load i64, ptr %slot45, align 8
  store i64 %v1057, ptr %slot167, align 8
  %v1058 = load i64, ptr %slot166, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i64, ptr %p1059, align 8
  store i64 %ld1060, ptr %slot168, align 8
  %v1061 = load i64, ptr %slot168, align 8
  %v1062 = load i64, ptr %slot165, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i64 %v1061, ptr %p1063, align 8, !alias.scope !3, !noalias !4
  %v1064 = load i64, ptr %slot165, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i64, ptr %p1065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1066, ptr %slot169, align 8
  %v1067 = load i64, ptr %slot169, align 8
  %v1068 = load i64, ptr %slot23, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i64 %v1067, ptr %p1069, align 8, !alias.scope !3, !noalias !4
  br label %bb_i13
bb_i12:
  %v1070 = load i64, ptr %slot23, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %ld1072 = load i64, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1072, ptr %slot170, align 8
  %v1073 = load i64, ptr %slot5, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %ld1075 = load i32, ptr %p1074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1075, ptr %slot171, align 8
  %v1076 = load i32, ptr %slot171, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcslotdrop195, label %bb_rcslotdone195
bb_rcslotdrop195:
  %v1079 = load i64, ptr %slot5, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i32 0, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone195
bb_rcslotdone195:
  %v1081 = load i64, ptr %slot170, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %ret1083 = load { i64, i64 }, ptr %p1082, align 8
  ret { i64, i64 } %ret1083
bb_i13:
  %v1084 = load i64, ptr %slot23, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i64, ptr %p1085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1086, ptr %slot172, align 8
  %v1087 = load i64, ptr %slot172, align 8
  %v1088 = load i64, ptr %slot20, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  store i64 %v1087, ptr %p1089, align 8, !alias.scope !3, !noalias !4
  %v1090 = load i64, ptr %slot19, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %ld1092 = load i64, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1092, ptr %slot173, align 8
  %v1093 = load i64, ptr %slot173, align 8
  %v1094 = load i64, ptr %slot23, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  store i64 %v1093, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  %v1096 = load i64, ptr %slot30, align 8
  store i64 %v1096, ptr %slot174, align 8
  %v1097 = load i64, ptr %slot174, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i32 0, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot174, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  store i32 1, ptr %p1100, align 4, !alias.scope !3, !noalias !4
  %v1101 = load i64, ptr %slot174, align 8
  %v1102 = load i64, ptr %slot24, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  store i64 %v1101, ptr %p1103, align 8, !alias.scope !3, !noalias !4
  %p1104 = inttoptr i64 ptrtoint (ptr @myl_lit_ae95ccd4f4fa503023e0e12571b49ac0a774d7359e9bb6d464c7aa7c975f9c74 to i64) to ptr
  %ld1105 = load i64, ptr %p1104, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1105, ptr %slot175, align 8
  %v1106 = load i64, ptr %slot175, align 8
  %v1107 = load i64, ptr %slot25, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  store i64 %v1106, ptr %p1108, align 8, !alias.scope !3, !noalias !4
  %v1109 = load i64, ptr %slot25, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  %ld1111 = load i64, ptr %p1110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1111, ptr %slot176, align 8
  %v1112 = load i64, ptr %slot176, align 8
  %v1113 = load i64, ptr %slot17, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i64 %v1112, ptr %p1114, align 8, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot17, align 8
  store i64 %v1115, ptr %slot177, align 8
  %v1116 = load i64, ptr %slot18, align 8
  store i64 %v1116, ptr %slot178, align 8
  %v1117 = load i64, ptr %slot177, align 8
  %v1118 = load i64, ptr %slot178, align 8
  %p1119 = inttoptr i64 %v1117 to ptr
  %p1120 = inttoptr i64 %v1118 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1120, ptr %p1119, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1121 = load i64, ptr %slot12, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  store i32 2, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  %v1123 = load i64, ptr %slot11, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i32 1, ptr %p1124, align 4, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot16, align 8
  store i64 %v1125, ptr %slot179, align 8
  %v1126 = load i64, ptr %slot18, align 8
  store i64 %v1126, ptr %slot180, align 8
  %v1127 = load i64, ptr %slot180, align 8
  %v1128 = load i64, ptr %slot179, align 8
  %p1129 = inttoptr i64 %v1127 to ptr
  %p1130 = inttoptr i64 %v1128 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1130, ptr %p1129, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1131 = load i64, ptr %slot10, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  store i32 2, ptr %p1132, align 4, !alias.scope !3, !noalias !4
  %v1133 = load i64, ptr %slot12, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %ld1135 = load i32, ptr %p1134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1135, ptr %slot181, align 8
  %v1136 = load i32, ptr %slot181, align 8
  %v1137 = load i64, ptr %slot10, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i32 %v1136, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot11, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  store i32 0, ptr %p1140, align 4, !alias.scope !3, !noalias !4
  %v1141 = load i64, ptr %slot9, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i32 1, ptr %p1142, align 4, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot179, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i64, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1145, ptr %slot182, align 8
  %v1146 = load i64, ptr %slot182, align 8
  %v1147 = load i64, ptr %slot25, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 %v1146, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  %v1149 = load i64, ptr %slot23, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i64, ptr %p1150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1151, ptr %slot183, align 8
  %v1152 = load i64, ptr %slot24, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i64, ptr %p1153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1154, ptr %slot184, align 8
  %v1155 = load i64, ptr %slot25, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %ld1157 = load i64, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1157, ptr %slot185, align 8
  %v1158 = load i64, ptr %slot1, align 8
  %v1159 = load i64, ptr %slot183, align 8
  %v1160 = load i64, ptr %slot184, align 8
  %v1161 = load i64, ptr %slot185, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult187, i64 %v1158, i64 %v1159, i64 %v1160, i64 %v1161) nomerge, !dbg !124
  %addr1162 = ptrtoint ptr %callresult187 to i64
  store i64 %addr1162, ptr %slot186, align 8
  %v1163 = load i64, ptr %slot186, align 8
  %v1164 = load i64, ptr %slot23, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  store i64 %v1163, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  %v1166 = load i64, ptr %slot23, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i64, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1168, ptr %slot188, align 8
  %v1169 = load i64, ptr %slot18, align 8
  store i64 %v1169, ptr %slot189, align 8
  %v1170 = load i64, ptr %slot188, align 8
  %v1171 = load i64, ptr %slot189, align 8
  %p1172 = inttoptr i64 %v1170 to ptr
  %p1173 = inttoptr i64 %v1171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1173, ptr %p1172, i64 48, i1 false)
  %v1174 = load i64, ptr %slot12, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i32 2, ptr %p1175, align 4, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot11, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 1, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot5, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i32, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1180, ptr %slot190, align 8
  %v1181 = load i32, ptr %slot190, align 8
  %cv1182 = zext i32 %v1181 to i64
  %cond1183 = icmp ne i64 %cv1182, 0
  br i1 %cond1183, label %bb_rcslotdrop234, label %bb_rcslotdone234
bb_rcslotdrop234:
  %v1184 = load i64, ptr %slot5, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i32 0, ptr %p1185, align 4, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot14, align 8
  store i64 %v1186, ptr %slot191, align 8
  %v1187 = load i64, ptr %slot6, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot192, align 8
  %v1190 = load i32, ptr %slot192, align 8
  %op1191 = and i32 %v1190, 28
  store i32 %op1191, ptr %slot193, align 8
  %v1192 = load i32, ptr %slot193, align 8
  %cv1193 = zext i32 %v1192 to i64
  %cond1194 = icmp ne i64 %cv1193, 0
  br i1 %cond1194, label %bb_rcslotrole234, label %bb_rcslotowner234
bb_rcslotrole234:
  %v1195 = load i64, ptr %slot44, align 8
  store i64 %v1195, ptr %slot194, align 8
  %v1196 = load i64, ptr %slot194, align 8
  %v1197 = load i64, ptr %slot191, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1196, i64 %v1197) nomerge, !dbg !124
  br label %bb_rcslotdone234
bb_rcslotowner234:
  %v1198 = load i64, ptr %slot44, align 8
  store i64 %v1198, ptr %slot195, align 8
  %v1199 = load i64, ptr %slot195, align 8
  %v1200 = load i64, ptr %slot191, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1199, i64 %v1200) nomerge, !dbg !124
  br label %bb_rcslotdone234
bb_rcslotdone234:
  %v1201 = load i64, ptr %slot9, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i32, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1203, ptr %slot196, align 8
  %v1204 = load i32, ptr %slot196, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v1207 = load i64, ptr %slot9, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i32 0, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot16, align 8
  store i64 %v1209, ptr %slot197, align 8
  %v1210 = load i64, ptr %slot10, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i32, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1212, ptr %slot198, align 8
  %v1213 = load i32, ptr %slot198, align 8
  %op1214 = and i32 %v1213, 28
  store i32 %op1214, ptr %slot199, align 8
  %v1215 = load i32, ptr %slot199, align 8
  %cv1216 = zext i32 %v1215 to i64
  %cond1217 = icmp ne i64 %cv1216, 0
  br i1 %cond1217, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v1218 = load i64, ptr %slot44, align 8
  store i64 %v1218, ptr %slot200, align 8
  %v1219 = load i64, ptr %slot197, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  %ld1221 = load i64, ptr %p1220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1221, ptr %slot201, align 8
  %v1222 = load i64, ptr %slot201, align 8
  %cmp1223 = icmp ne i64 %v1222, 0
  %cv1224 = zext i1 %cmp1223 to i32
  store i32 %cv1224, ptr %slot202, align 8
  %v1225 = load i32, ptr %slot202, align 8
  %cv1226 = zext i32 %v1225 to i64
  %cond1227 = icmp ne i64 %cv1226, 0
  br i1 %cond1227, label %bb_rcgnn259, label %bb_rcgdone259
bb_rcgnn259:
  %v1228 = load i64, ptr %slot201, align 8
  %op1229 = sub i64 %v1228, 16
  store i64 %op1229, ptr %slot203, align 8
  %v1230 = load i64, ptr %slot201, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %rgep1232 = getelementptr i8, ptr %p1231, i64 -16
  %ld1233 = load i64, ptr %rgep1232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1233, ptr %slot204, align 8
  %v1234 = load i64, ptr %slot204, align 8
  %op1235 = and i64 %v1234, 4611686018427387906
  store i64 %op1235, ptr %slot205, align 8
  %v1236 = load i64, ptr %slot205, align 8
  %cmp1237 = icmp ne i64 %v1236, 0
  %cv1238 = zext i1 %cmp1237 to i32
  store i32 %cv1238, ptr %slot206, align 8
  %v1239 = load i32, ptr %slot206, align 8
  %cv1240 = zext i32 %v1239 to i64
  %cond1241 = icmp ne i64 %cv1240, 0
  br i1 %cond1241, label %bb_rcgclear259, label %bb_rcgcounted259
bb_rcgcounted259:
  %v1242 = load i64, ptr %slot201, align 8
  %op1243 = sub i64 %v1242, 24
  store i64 %op1243, ptr %slot207, align 8
  %v1244 = load i64, ptr %slot201, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %rgep1246 = getelementptr i8, ptr %p1245, i64 -24
  %ld1247 = load i64, ptr %rgep1246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1247, ptr %slot208, align 8
  %v1248 = load i64, ptr %slot208, align 8
  %op1249 = sub i64 %v1248, 1
  store i64 %op1249, ptr %slot209, align 8
  %v1250 = load i64, ptr %slot209, align 8
  %cmp1251 = icmp eq i64 %v1250, 0
  %cv1252 = zext i1 %cmp1251 to i32
  store i32 %cv1252, ptr %slot210, align 8
  %v1253 = load i32, ptr %slot210, align 8
  %cv1254 = zext i32 %v1253 to i64
  %cond1255 = icmp ne i64 %cv1254, 0
  br i1 %cond1255, label %bb_rcglast259, label %bb_rcgdec259
bb_rcglast259:
  %v1256 = load i64, ptr %slot201, align 8
  %op1257 = sub i64 %v1256, 32
  store i64 %op1257, ptr %slot211, align 8
  %v1258 = load i64, ptr %slot201, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  %rgep1260 = getelementptr i8, ptr %p1259, i64 -32
  %ld1261 = load i64, ptr %rgep1260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1261, ptr %slot212, align 8
  %v1262 = load i64, ptr %slot212, align 8
  %cmp1263 = icmp ne i64 %v1262, 0
  %cv1264 = zext i1 %cmp1263 to i32
  store i32 %cv1264, ptr %slot213, align 8
  %v1265 = load i32, ptr %slot213, align 8
  %cv1266 = zext i32 %v1265 to i64
  %cond1267 = icmp ne i64 %cv1266, 0
  br i1 %cond1267, label %bb_rcgdec259, label %bb_rcgslow259
bb_rcgslow259:
  %v1268 = load i64, ptr %slot200, align 8
  %v1269 = load i64, ptr %slot197, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1268, i64 %v1269) nomerge, !dbg !124
  br label %bb_rcgdone259
bb_rcgdec259:
  %v1270 = load i64, ptr %slot209, align 8
  %v1271 = load i64, ptr %slot201, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  %rgep1273 = getelementptr i8, ptr %p1272, i64 -24
  store i64 %v1270, ptr %rgep1273, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear259
bb_rcgclear259:
  %v1274 = load i64, ptr %slot197, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i64 0, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone259
bb_rcgdone259:
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v1276 = load i64, ptr %slot44, align 8
  store i64 %v1276, ptr %slot214, align 8
  %v1277 = load i64, ptr %slot197, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  %ld1279 = load i64, ptr %p1278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1279, ptr %slot215, align 8
  %v1280 = load i64, ptr %slot215, align 8
  %cmp1281 = icmp ne i64 %v1280, 0
  %cv1282 = zext i1 %cmp1281 to i32
  store i32 %cv1282, ptr %slot216, align 8
  %v1283 = load i32, ptr %slot216, align 8
  %cv1284 = zext i32 %v1283 to i64
  %cond1285 = icmp ne i64 %cv1284, 0
  br i1 %cond1285, label %bb_rcgnn274, label %bb_rcgdone274
bb_rcgnn274:
  %v1286 = load i64, ptr %slot215, align 8
  %op1287 = sub i64 %v1286, 16
  store i64 %op1287, ptr %slot217, align 8
  %v1288 = load i64, ptr %slot215, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %rgep1290 = getelementptr i8, ptr %p1289, i64 -16
  %ld1291 = load i64, ptr %rgep1290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1291, ptr %slot218, align 8
  %v1292 = load i64, ptr %slot218, align 8
  %op1293 = and i64 %v1292, 4611686018427387906
  store i64 %op1293, ptr %slot219, align 8
  %v1294 = load i64, ptr %slot219, align 8
  %cmp1295 = icmp ne i64 %v1294, 0
  %cv1296 = zext i1 %cmp1295 to i32
  store i32 %cv1296, ptr %slot220, align 8
  %v1297 = load i32, ptr %slot220, align 8
  %cv1298 = zext i32 %v1297 to i64
  %cond1299 = icmp ne i64 %cv1298, 0
  br i1 %cond1299, label %bb_rcgclear274, label %bb_rcgcounted274
bb_rcgcounted274:
  %v1300 = load i64, ptr %slot215, align 8
  %op1301 = sub i64 %v1300, 32
  store i64 %op1301, ptr %slot221, align 8
  %v1302 = load i64, ptr %slot215, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %rgep1304 = getelementptr i8, ptr %p1303, i64 -32
  %ld1305 = load i64, ptr %rgep1304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1305, ptr %slot222, align 8
  %v1306 = load i64, ptr %slot222, align 8
  %op1307 = sub i64 %v1306, 1
  store i64 %op1307, ptr %slot223, align 8
  %v1308 = load i64, ptr %slot223, align 8
  %cmp1309 = icmp eq i64 %v1308, 0
  %cv1310 = zext i1 %cmp1309 to i32
  store i32 %cv1310, ptr %slot224, align 8
  %v1311 = load i32, ptr %slot224, align 8
  %cv1312 = zext i32 %v1311 to i64
  %cond1313 = icmp ne i64 %cv1312, 0
  br i1 %cond1313, label %bb_rcglast274, label %bb_rcgdec274
bb_rcglast274:
  %v1314 = load i64, ptr %slot215, align 8
  %op1315 = sub i64 %v1314, 24
  store i64 %op1315, ptr %slot225, align 8
  %v1316 = load i64, ptr %slot215, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  %rgep1318 = getelementptr i8, ptr %p1317, i64 -24
  %ld1319 = load i64, ptr %rgep1318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1319, ptr %slot226, align 8
  %v1320 = load i64, ptr %slot226, align 8
  %cmp1321 = icmp ne i64 %v1320, 0
  %cv1322 = zext i1 %cmp1321 to i32
  store i32 %cv1322, ptr %slot227, align 8
  %v1323 = load i32, ptr %slot227, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcgdec274, label %bb_rcgslow274
bb_rcgslow274:
  %v1326 = load i64, ptr %slot214, align 8
  %v1327 = load i64, ptr %slot197, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1326, i64 %v1327) nomerge, !dbg !124
  br label %bb_rcgdone274
bb_rcgdec274:
  %v1328 = load i64, ptr %slot223, align 8
  %v1329 = load i64, ptr %slot215, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %rgep1331 = getelementptr i8, ptr %p1330, i64 -32
  store i64 %v1328, ptr %rgep1331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear274
bb_rcgclear274:
  %v1332 = load i64, ptr %slot197, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i64 0, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone274
bb_rcgdone274:
  br label %bb_rcslotdone243
bb_rcslotdone243:
  %v1334 = load i64, ptr %slot14, align 8
  store i64 %v1334, ptr %slot228, align 8
  %v1335 = load i64, ptr %slot18, align 8
  store i64 %v1335, ptr %slot229, align 8
  %v1336 = load i64, ptr %slot229, align 8
  %v1337 = load i64, ptr %slot228, align 8
  %p1338 = inttoptr i64 %v1336 to ptr
  %p1339 = inttoptr i64 %v1337 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1339, ptr %p1338, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot6, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 2, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot12, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i32, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1344, ptr %slot230, align 8
  %v1345 = load i32, ptr %slot230, align 8
  %v1346 = load i64, ptr %slot6, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  store i32 %v1345, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  %v1348 = load i64, ptr %slot11, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  store i32 0, ptr %p1349, align 4, !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot5, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  store i32 1, ptr %p1351, align 4, !alias.scope !3, !noalias !4
  %v1352 = load i64, ptr %slot228, align 8
  %v1353 = load i64, ptr %slot23, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  store i64 %v1352, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  %v1355 = load i64, ptr %slot23, align 8
  %p1356 = inttoptr i64 %v1355 to ptr
  %ld1357 = load i64, ptr %p1356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1357, ptr %slot231, align 8
  %v1358 = load i64, ptr %slot231, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %ld1360 = load i32, ptr %p1359, align 4
  %ext1361 = zext i32 %ld1360 to i64
  store i64 %ext1361, ptr %slot232, align 8
  %v1362 = load i64, ptr %slot232, align 8
  %cmp1363 = icmp eq i64 %v1362, 0
  %cv1364 = zext i1 %cmp1363 to i64
  store i64 %cv1364, ptr %slot233, align 8
  %v1365 = load i64, ptr %slot233, align 8
  %cond1366 = icmp ne i64 %v1365, 0
  br i1 %cond1366, label %bb_rctryok287, label %bb_rctryerror287
bb_rctryerror287:
  %p1367 = inttoptr i64 ptrtoint (ptr @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1367, i64 12884901906) "call-inline-cost"="0", !dbg !126
  %v1368 = load i64, ptr %slot231, align 8
  %op1369 = add i64 %v1368, 8
  store i64 %op1369, ptr %slot234, align 8
  %v1370 = load i64, ptr %slot31, align 8
  store i64 %v1370, ptr %slot235, align 8
  %v1371 = load i64, ptr %slot235, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 0, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot235, align 8
  %p1375 = inttoptr i64 %v1373 to ptr
  %gep1376 = getelementptr i8, ptr %p1375, i64 8
  %op1374 = ptrtoint ptr %gep1376 to i64
  store i64 %op1374, ptr %slot236, align 8
  %v1377 = load i64, ptr %slot236, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i64 0, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  %v1379 = load i64, ptr %slot235, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i32 1, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot235, align 8
  %p1383 = inttoptr i64 %v1381 to ptr
  %gep1384 = getelementptr i8, ptr %p1383, i64 8
  %op1382 = ptrtoint ptr %gep1384 to i64
  store i64 %op1382, ptr %slot237, align 8
  %v1385 = load i64, ptr %slot13, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 1, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot45, align 8
  store i64 %v1387, ptr %slot238, align 8
  %v1388 = load i64, ptr %slot235, align 8
  %v1389 = load i64, ptr %slot23, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  store i64 %v1388, ptr %p1390, align 8, !alias.scope !3, !noalias !4
  %v1391 = load i64, ptr %slot5, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i32, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1393, ptr %slot239, align 8
  %v1394 = load i32, ptr %slot239, align 8
  %cv1395 = zext i32 %v1394 to i64
  %cond1396 = icmp ne i64 %cv1395, 0
  br i1 %cond1396, label %bb_rcslotdrop298, label %bb_rcslotdone298
bb_rcslotdrop298:
  %v1397 = load i64, ptr %slot5, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 0, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot14, align 8
  store i64 %v1399, ptr %slot240, align 8
  %v1400 = load i64, ptr %slot6, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %ld1402 = load i32, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1402, ptr %slot241, align 8
  %v1403 = load i32, ptr %slot241, align 8
  %op1404 = and i32 %v1403, 28
  store i32 %op1404, ptr %slot242, align 8
  %v1405 = load i32, ptr %slot242, align 8
  %cv1406 = zext i32 %v1405 to i64
  %cond1407 = icmp ne i64 %cv1406, 0
  br i1 %cond1407, label %bb_rcslotrole298, label %bb_rcslotowner298
bb_rcslotrole298:
  %v1408 = load i64, ptr %slot44, align 8
  store i64 %v1408, ptr %slot243, align 8
  %v1409 = load i64, ptr %slot243, align 8
  %v1410 = load i64, ptr %slot240, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1409, i64 %v1410) nomerge, !dbg !126
  br label %bb_rcslotdone298
bb_rcslotowner298:
  %v1411 = load i64, ptr %slot44, align 8
  store i64 %v1411, ptr %slot244, align 8
  %v1412 = load i64, ptr %slot244, align 8
  %v1413 = load i64, ptr %slot240, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1412, i64 %v1413) nomerge, !dbg !126
  br label %bb_rcslotdone298
bb_rcslotdone298:
  br label %bb_i20
bb_rctryok287:
  %v1414 = load i64, ptr %slot31, align 8
  store i64 %v1414, ptr %slot245, align 8
  %v1415 = load i64, ptr %slot245, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i64 0, ptr %p1416, align 8, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot245, align 8
  %p1419 = inttoptr i64 %v1417 to ptr
  %gep1420 = getelementptr i8, ptr %p1419, i64 8
  %op1418 = ptrtoint ptr %gep1420 to i64
  store i64 %op1418, ptr %slot246, align 8
  %v1421 = load i64, ptr %slot246, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  store i64 0, ptr %p1422, align 8, !alias.scope !3, !noalias !4
  %v1423 = load i64, ptr %slot245, align 8
  %p1425 = inttoptr i64 %v1423 to ptr
  %gep1426 = getelementptr i8, ptr %p1425, i64 16
  %op1424 = ptrtoint ptr %gep1426 to i64
  store i64 %op1424, ptr %slot247, align 8
  %v1427 = load i64, ptr %slot247, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 0, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot245, align 8
  %p1431 = inttoptr i64 %v1429 to ptr
  %gep1432 = getelementptr i8, ptr %p1431, i64 24
  %op1430 = ptrtoint ptr %gep1432 to i64
  store i64 %op1430, ptr %slot248, align 8
  %v1433 = load i64, ptr %slot248, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i64 0, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot245, align 8
  %p1437 = inttoptr i64 %v1435 to ptr
  %gep1438 = getelementptr i8, ptr %p1437, i64 32
  %op1436 = ptrtoint ptr %gep1438 to i64
  store i64 %op1436, ptr %slot249, align 8
  %v1439 = load i64, ptr %slot249, align 8
  %p1440 = inttoptr i64 %v1439 to ptr
  store i64 0, ptr %p1440, align 8, !alias.scope !3, !noalias !4
  %v1441 = load i64, ptr %slot13, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  store i32 1, ptr %p1442, align 4, !alias.scope !3, !noalias !4
  %v1443 = load i64, ptr %slot231, align 8
  %op1444 = add i64 %v1443, 8
  store i64 %op1444, ptr %slot250, align 8
  %v1445 = load i64, ptr %slot45, align 8
  store i64 %v1445, ptr %slot251, align 8
  %v1446 = load i64, ptr %slot44, align 8
  %v1447 = load i64, ptr %slot245, align 8
  %v1448 = load i64, ptr %slot250, align 8
  %v1449 = load i64, ptr %slot251, align 8
  %cv1450 = trunc i64 %v1449 to i32
  %call1451 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1446, i64 %v1447, i64 %v1448, i32 %cv1450) nomerge, !dbg !126
  store i32 %call1451, ptr %slot252, align 8
  %v1452 = load i32, ptr %slot252, align 8
  %cv1453 = zext i32 %v1452 to i64
  %cond1454 = icmp ne i64 %cv1453, 0
  br i1 %cond1454, label %bb_rcsuccess315, label %bb_rcfailure315
bb_rcfailure315:
  %v1455 = load i64, ptr %slot44, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  %call1457 = call i32 @myl_rc_take_failure(ptr %p1456) nomerge, !dbg !126
  store i32 %call1457, ptr %slot253, align 8
  %v1458 = load i64, ptr %slot1, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  %v1460 = load i32, ptr %slot253, align 8
  %call1461 = call i32 @myl_qbe_rc_status(ptr %p1459, i32 %v1460) nomerge, !dbg !126
  store i32 %call1461, ptr %slot254, align 8
  br label %bb_failure
bb_rcsuccess315:
  %v1462 = load i64, ptr %slot245, align 8
  %v1463 = load i64, ptr %slot23, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i64 %v1462, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot23, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  %ld1467 = load i64, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1467, ptr %slot255, align 8
  %v1468 = load i64, ptr %slot18, align 8
  store i64 %v1468, ptr %slot256, align 8
  %v1469 = load i64, ptr %slot255, align 8
  %v1470 = load i64, ptr %slot256, align 8
  %p1471 = inttoptr i64 %v1469 to ptr
  %p1472 = inttoptr i64 %v1470 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1472, ptr %p1471, i64 40, i1 false)
  %v1473 = load i64, ptr %slot12, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i32 2, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot11, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  store i32 1, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  %v1477 = load i64, ptr %slot5, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i32, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1479, ptr %slot257, align 8
  %v1480 = load i32, ptr %slot257, align 8
  %cv1481 = zext i32 %v1480 to i64
  %cond1482 = icmp ne i64 %cv1481, 0
  br i1 %cond1482, label %bb_rcslotdrop324, label %bb_rcslotdone324
bb_rcslotdrop324:
  %v1483 = load i64, ptr %slot5, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i32 0, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  %v1485 = load i64, ptr %slot14, align 8
  store i64 %v1485, ptr %slot258, align 8
  %v1486 = load i64, ptr %slot6, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %ld1488 = load i32, ptr %p1487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1488, ptr %slot259, align 8
  %v1489 = load i32, ptr %slot259, align 8
  %op1490 = and i32 %v1489, 28
  store i32 %op1490, ptr %slot260, align 8
  %v1491 = load i32, ptr %slot260, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcslotrole324, label %bb_rcslotowner324
bb_rcslotrole324:
  %v1494 = load i64, ptr %slot44, align 8
  store i64 %v1494, ptr %slot261, align 8
  %v1495 = load i64, ptr %slot261, align 8
  %v1496 = load i64, ptr %slot258, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1495, i64 %v1496) nomerge, !dbg !126
  br label %bb_rcslotdone324
bb_rcslotowner324:
  %v1497 = load i64, ptr %slot44, align 8
  store i64 %v1497, ptr %slot262, align 8
  %v1498 = load i64, ptr %slot262, align 8
  %v1499 = load i64, ptr %slot258, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1498, i64 %v1499) nomerge, !dbg !126
  br label %bb_rcslotdone324
bb_rcslotdone324:
  %v1500 = load i64, ptr %slot14, align 8
  store i64 %v1500, ptr %slot263, align 8
  %v1501 = load i64, ptr %slot18, align 8
  store i64 %v1501, ptr %slot264, align 8
  %v1502 = load i64, ptr %slot264, align 8
  %v1503 = load i64, ptr %slot263, align 8
  %p1504 = inttoptr i64 %v1502 to ptr
  %p1505 = inttoptr i64 %v1503 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1505, ptr %p1504, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1506 = load i64, ptr %slot6, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  store i32 2, ptr %p1507, align 4, !alias.scope !3, !noalias !4
  %v1508 = load i64, ptr %slot12, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i32, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1510, ptr %slot265, align 8
  %v1511 = load i32, ptr %slot265, align 8
  %v1512 = load i64, ptr %slot6, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  store i32 %v1511, ptr %p1513, align 4, !alias.scope !3, !noalias !4
  %v1514 = load i64, ptr %slot11, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  store i32 0, ptr %p1515, align 4, !alias.scope !3, !noalias !4
  %v1516 = load i64, ptr %slot5, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  store i32 1, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  %v1518 = load i64, ptr %slot263, align 8
  %v1519 = load i64, ptr %slot23, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  store i64 %v1518, ptr %p1520, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i20:
  %v1521 = load i64, ptr %slot23, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  %ld1523 = load i64, ptr %p1522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1523, ptr %slot266, align 8
  %v1524 = load i64, ptr %slot5, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  %ld1526 = load i32, ptr %p1525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1526, ptr %slot267, align 8
  %v1527 = load i32, ptr %slot267, align 8
  %cv1528 = zext i32 %v1527 to i64
  %cond1529 = icmp ne i64 %cv1528, 0
  br i1 %cond1529, label %bb_rcslotdrop342, label %bb_rcslotdone342
bb_rcslotdrop342:
  %v1530 = load i64, ptr %slot5, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  store i32 0, ptr %p1531, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone342
bb_rcslotdone342:
  %v1532 = load i64, ptr %slot266, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %ret1534 = load { i64, i64 }, ptr %p1533, align 8
  ret { i64, i64 } %ret1534
bb_i21:
  %v1535 = load i64, ptr %slot5, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %ld1537 = load i32, ptr %p1536, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1537, ptr %slot268, align 8
  %v1538 = load i32, ptr %slot268, align 8
  %cv1539 = zext i32 %v1538 to i64
  %cond1540 = icmp ne i64 %cv1539, 0
  br i1 %cond1540, label %bb_rcslotdrop354, label %bb_rcslotdone354
bb_rcslotdrop354:
  %v1541 = load i64, ptr %slot5, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i32 0, ptr %p1542, align 4, !alias.scope !3, !noalias !4
  %v1543 = load i64, ptr %slot14, align 8
  store i64 %v1543, ptr %slot269, align 8
  %v1544 = load i64, ptr %slot6, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %ld1546 = load i32, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1546, ptr %slot270, align 8
  %v1547 = load i32, ptr %slot270, align 8
  %op1548 = and i32 %v1547, 28
  store i32 %op1548, ptr %slot271, align 8
  %v1549 = load i32, ptr %slot271, align 8
  %cv1550 = zext i32 %v1549 to i64
  %cond1551 = icmp ne i64 %cv1550, 0
  br i1 %cond1551, label %bb_rcslotrole354, label %bb_rcslotowner354
bb_rcslotrole354:
  %v1552 = load i64, ptr %slot44, align 8
  store i64 %v1552, ptr %slot272, align 8
  %v1553 = load i64, ptr %slot272, align 8
  %v1554 = load i64, ptr %slot269, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1553, i64 %v1554) nomerge, !dbg !128
  br label %bb_rcslotdone354
bb_rcslotowner354:
  %v1555 = load i64, ptr %slot44, align 8
  store i64 %v1555, ptr %slot273, align 8
  %v1556 = load i64, ptr %slot273, align 8
  %v1557 = load i64, ptr %slot269, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1556, i64 %v1557) nomerge, !dbg !128
  br label %bb_rcslotdone354
bb_rcslotdone354:
  %v1558 = load i64, ptr %slot19, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %ld1560 = load i64, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1560, ptr %slot274, align 8
  %v1561 = load i64, ptr %slot274, align 8
  %v1562 = load i64, ptr %slot23, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  store i64 %v1561, ptr %p1563, align 8, !alias.scope !3, !noalias !4
  %v1564 = load i64, ptr %slot23, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  %ld1566 = load i64, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1566, ptr %slot275, align 8
  %v1567 = load i64, ptr %slot1, align 8
  %v1568 = load i64, ptr %slot275, align 8
  %call1569 = call { i64, i64 } @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a(i64 %v1567, i64 %v1568) nomerge, !dbg !130
  store { i64, i64 } %call1569, ptr %callresult277, align 8
  %addr1570 = ptrtoint ptr %callresult277 to i64
  store i64 %addr1570, ptr %slot276, align 8
  %v1571 = load i64, ptr %slot276, align 8
  %v1572 = load i64, ptr %slot23, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i64 %v1571, ptr %p1573, align 8, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot5, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %ld1576 = load i32, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1576, ptr %slot278, align 8
  %v1577 = load i32, ptr %slot278, align 8
  %cv1578 = zext i32 %v1577 to i64
  %cond1579 = icmp ne i64 %cv1578, 0
  br i1 %cond1579, label %bb_rcslotdrop366, label %bb_rcslotdone366
bb_rcslotdrop366:
  %v1580 = load i64, ptr %slot5, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  store i32 0, ptr %p1581, align 4, !alias.scope !3, !noalias !4
  %v1582 = load i64, ptr %slot14, align 8
  store i64 %v1582, ptr %slot279, align 8
  %v1583 = load i64, ptr %slot6, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %ld1585 = load i32, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1585, ptr %slot280, align 8
  %v1586 = load i32, ptr %slot280, align 8
  %op1587 = and i32 %v1586, 28
  store i32 %op1587, ptr %slot281, align 8
  %v1588 = load i32, ptr %slot281, align 8
  %cv1589 = zext i32 %v1588 to i64
  %cond1590 = icmp ne i64 %cv1589, 0
  br i1 %cond1590, label %bb_rcslotrole366, label %bb_rcslotowner366
bb_rcslotrole366:
  %v1591 = load i64, ptr %slot44, align 8
  store i64 %v1591, ptr %slot282, align 8
  %v1592 = load i64, ptr %slot282, align 8
  %v1593 = load i64, ptr %slot279, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1592, i64 %v1593) nomerge, !dbg !130
  br label %bb_rcslotdone366
bb_rcslotowner366:
  %v1594 = load i64, ptr %slot44, align 8
  store i64 %v1594, ptr %slot283, align 8
  %v1595 = load i64, ptr %slot283, align 8
  %v1596 = load i64, ptr %slot279, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1595, i64 %v1596) nomerge, !dbg !130
  br label %bb_rcslotdone366
bb_rcslotdone366:
  %v1597 = load i64, ptr %slot23, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %ld1599 = load i64, ptr %p1598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1599, ptr %slot284, align 8
  %v1600 = load i64, ptr %slot284, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %ld1602 = load i32, ptr %p1601, align 4
  %ext1603 = zext i32 %ld1602 to i64
  store i64 %ext1603, ptr %slot285, align 8
  %v1604 = load i64, ptr %slot285, align 8
  %cmp1605 = icmp eq i64 %v1604, 0
  %cv1606 = zext i1 %cmp1605 to i64
  store i64 %cv1606, ptr %slot286, align 8
  %v1607 = load i64, ptr %slot286, align 8
  %cond1608 = icmp ne i64 %v1607, 0
  br i1 %cond1608, label %bb_rctryok374, label %bb_rctryerror374
bb_rctryerror374:
  %p1609 = inttoptr i64 ptrtoint (ptr @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1609, i64 12884901912) "call-inline-cost"="0", !dbg !132
  %v1610 = load i64, ptr %slot284, align 8
  %op1611 = add i64 %v1610, 8
  store i64 %op1611, ptr %slot287, align 8
  %v1612 = load i64, ptr %slot32, align 8
  store i64 %v1612, ptr %slot288, align 8
  %v1613 = load i64, ptr %slot288, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 0, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot288, align 8
  %p1617 = inttoptr i64 %v1615 to ptr
  %gep1618 = getelementptr i8, ptr %p1617, i64 8
  %op1616 = ptrtoint ptr %gep1618 to i64
  store i64 %op1616, ptr %slot289, align 8
  %v1619 = load i64, ptr %slot289, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i64 0, ptr %p1620, align 8, !alias.scope !3, !noalias !4
  %v1621 = load i64, ptr %slot288, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i32 1, ptr %p1622, align 4, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot288, align 8
  %p1625 = inttoptr i64 %v1623 to ptr
  %gep1626 = getelementptr i8, ptr %p1625, i64 8
  %op1624 = ptrtoint ptr %gep1626 to i64
  store i64 %op1624, ptr %slot290, align 8
  %v1627 = load i64, ptr %slot13, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  store i32 1, ptr %p1628, align 4, !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot45, align 8
  store i64 %v1629, ptr %slot291, align 8
  %v1630 = load i64, ptr %slot288, align 8
  %v1631 = load i64, ptr %slot23, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  store i64 %v1630, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_rctryok374:
  %v1633 = load i64, ptr %slot32, align 8
  store i64 %v1633, ptr %slot292, align 8
  %v1634 = load i64, ptr %slot292, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i64 0, ptr %p1635, align 8, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot13, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i32 1, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot284, align 8
  %op1639 = add i64 %v1638, 8
  store i64 %op1639, ptr %slot293, align 8
  %v1640 = load i64, ptr %slot45, align 8
  store i64 %v1640, ptr %slot294, align 8
  %v1641 = load i64, ptr %slot293, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i64, ptr %p1642, align 8
  store i64 %ld1643, ptr %slot295, align 8
  %v1644 = load i64, ptr %slot295, align 8
  %v1645 = load i64, ptr %slot292, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i64 %v1644, ptr %p1646, align 8, !alias.scope !3, !noalias !4
  %v1647 = load i64, ptr %slot292, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %ld1649 = load i64, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1649, ptr %slot296, align 8
  %v1650 = load i64, ptr %slot296, align 8
  %v1651 = load i64, ptr %slot23, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i64 %v1650, ptr %p1652, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i26:
  %v1653 = load i64, ptr %slot23, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %ld1655 = load i64, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1655, ptr %slot297, align 8
  %v1656 = load i64, ptr %slot5, align 8
  %p1657 = inttoptr i64 %v1656 to ptr
  %ld1658 = load i32, ptr %p1657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1658, ptr %slot298, align 8
  %v1659 = load i32, ptr %slot298, align 8
  %cv1660 = zext i32 %v1659 to i64
  %cond1661 = icmp ne i64 %cv1660, 0
  br i1 %cond1661, label %bb_rcslotdrop393, label %bb_rcslotdone393
bb_rcslotdrop393:
  %v1662 = load i64, ptr %slot5, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i32 0, ptr %p1663, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone393
bb_rcslotdone393:
  %v1664 = load i64, ptr %slot297, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  %ret1666 = load { i64, i64 }, ptr %p1665, align 8
  ret { i64, i64 } %ret1666
bb_i27:
  %v1667 = load i64, ptr %slot23, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %ld1669 = load i64, ptr %p1668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1669, ptr %slot299, align 8
  %v1670 = load i64, ptr %slot299, align 8
  %v1671 = load i64, ptr %slot21, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i64 %v1670, ptr %p1672, align 8, !alias.scope !3, !noalias !4
  %v1673 = load i64, ptr %slot33, align 8
  store i64 %v1673, ptr %slot300, align 8
  %v1674 = load i64, ptr %slot300, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot300, align 8
  %p1678 = inttoptr i64 %v1676 to ptr
  %gep1679 = getelementptr i8, ptr %p1678, i64 8
  %op1677 = ptrtoint ptr %gep1679 to i64
  store i64 %op1677, ptr %slot301, align 8
  %v1680 = load i64, ptr %slot301, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  store i64 0, ptr %p1681, align 8, !alias.scope !3, !noalias !4
  %v1682 = load i64, ptr %slot300, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i32 0, ptr %p1683, align 4, !alias.scope !3, !noalias !4
  %v1684 = load i64, ptr %slot300, align 8
  %v1685 = load i64, ptr %slot23, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i64 %v1684, ptr %p1686, align 8, !alias.scope !3, !noalias !4
  %v1687 = load i64, ptr %slot23, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  %ld1689 = load i64, ptr %p1688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1689, ptr %slot302, align 8
  %v1690 = load i64, ptr %slot302, align 8
  %v1691 = load i64, ptr %slot22, align 8
  %p1692 = inttoptr i64 %v1690 to ptr
  %p1693 = inttoptr i64 %v1691 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1693, ptr %p1692, i64 16, i1 false)
  %v1694 = load i64, ptr %slot19, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i64, ptr %p1695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1696, ptr %slot303, align 8
  %v1697 = load i64, ptr %slot303, align 8
  %v1698 = load i64, ptr %slot23, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  store i64 %v1697, ptr %p1699, align 8, !alias.scope !3, !noalias !4
  %v1700 = load i64, ptr %slot34, align 8
  store i64 %v1700, ptr %slot304, align 8
  %v1701 = load i64, ptr %slot304, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 0, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot304, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 24, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot304, align 8
  %v1706 = load i64, ptr %slot24, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  store i64 %v1705, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  %v1708 = load i64, ptr %slot23, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %ld1710 = load i64, ptr %p1709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1710, ptr %slot305, align 8
  %v1711 = load i64, ptr %slot24, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i64, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1713, ptr %slot306, align 8
  %v1714 = load i64, ptr %slot1, align 8
  %v1715 = load i64, ptr %slot305, align 8
  %v1716 = load i64, ptr %slot306, align 8
  %call1717 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1714, i64 %v1715, i64 %v1716) nomerge, !dbg !134
  store i64 %call1717, ptr %slot307, align 8
  %v1718 = load i64, ptr %slot307, align 8
  %v1719 = load i64, ptr %slot23, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i64 %v1718, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot5, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %ld1723 = load i32, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1723, ptr %slot308, align 8
  %v1724 = load i32, ptr %slot308, align 8
  %cv1725 = zext i32 %v1724 to i64
  %cond1726 = icmp ne i64 %cv1725, 0
  br i1 %cond1726, label %bb_rcslotdrop414, label %bb_rcslotdone414
bb_rcslotdrop414:
  %v1727 = load i64, ptr %slot5, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 0, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot14, align 8
  store i64 %v1729, ptr %slot309, align 8
  %v1730 = load i64, ptr %slot6, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  %ld1732 = load i32, ptr %p1731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1732, ptr %slot310, align 8
  %v1733 = load i32, ptr %slot310, align 8
  %op1734 = and i32 %v1733, 28
  store i32 %op1734, ptr %slot311, align 8
  %v1735 = load i32, ptr %slot311, align 8
  %cv1736 = zext i32 %v1735 to i64
  %cond1737 = icmp ne i64 %cv1736, 0
  br i1 %cond1737, label %bb_rcslotrole414, label %bb_rcslotowner414
bb_rcslotrole414:
  %v1738 = load i64, ptr %slot44, align 8
  store i64 %v1738, ptr %slot312, align 8
  %v1739 = load i64, ptr %slot312, align 8
  %v1740 = load i64, ptr %slot309, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1739, i64 %v1740) nomerge, !dbg !134
  br label %bb_rcslotdone414
bb_rcslotowner414:
  %v1741 = load i64, ptr %slot44, align 8
  store i64 %v1741, ptr %slot313, align 8
  %v1742 = load i64, ptr %slot313, align 8
  %v1743 = load i64, ptr %slot309, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1742, i64 %v1743) nomerge, !dbg !134
  br label %bb_rcslotdone414
bb_rcslotdone414:
  %v1744 = load i64, ptr %slot23, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %ld1746 = load i64, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1746, ptr %slot314, align 8
  %v1747 = load i64, ptr %slot314, align 8
  %cond1748 = icmp ne i64 %v1747, 0
  br i1 %cond1748, label %bb_next422, label %bb_i41
bb_next422:
  %v1749 = load i64, ptr %slot19, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot315, align 8
  %v1752 = load i64, ptr %slot315, align 8
  %v1753 = load i64, ptr %slot23, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i64 %v1752, ptr %p1754, align 8, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot23, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %ld1757 = load i64, ptr %p1756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1757, ptr %slot316, align 8
  %v1758 = load i64, ptr %slot1, align 8
  %v1759 = load i64, ptr %slot316, align 8
  %call1760 = call { i64, i64 } @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a(i64 %v1758, i64 %v1759) nomerge, !dbg !136
  store { i64, i64 } %call1760, ptr %callresult318, align 8
  %addr1761 = ptrtoint ptr %callresult318 to i64
  store i64 %addr1761, ptr %slot317, align 8
  %v1762 = load i64, ptr %slot317, align 8
  %v1763 = load i64, ptr %slot23, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  store i64 %v1762, ptr %p1764, align 8, !alias.scope !3, !noalias !4
  %v1765 = load i64, ptr %slot5, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %ld1767 = load i32, ptr %p1766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1767, ptr %slot319, align 8
  %v1768 = load i32, ptr %slot319, align 8
  %cv1769 = zext i32 %v1768 to i64
  %cond1770 = icmp ne i64 %cv1769, 0
  br i1 %cond1770, label %bb_rcslotdrop427, label %bb_rcslotdone427
bb_rcslotdrop427:
  %v1771 = load i64, ptr %slot5, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i32 0, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  %v1773 = load i64, ptr %slot14, align 8
  store i64 %v1773, ptr %slot320, align 8
  %v1774 = load i64, ptr %slot6, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i32, ptr %p1775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1776, ptr %slot321, align 8
  %v1777 = load i32, ptr %slot321, align 8
  %op1778 = and i32 %v1777, 28
  store i32 %op1778, ptr %slot322, align 8
  %v1779 = load i32, ptr %slot322, align 8
  %cv1780 = zext i32 %v1779 to i64
  %cond1781 = icmp ne i64 %cv1780, 0
  br i1 %cond1781, label %bb_rcslotrole427, label %bb_rcslotowner427
bb_rcslotrole427:
  %v1782 = load i64, ptr %slot44, align 8
  store i64 %v1782, ptr %slot323, align 8
  %v1783 = load i64, ptr %slot323, align 8
  %v1784 = load i64, ptr %slot320, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1783, i64 %v1784) nomerge, !dbg !136
  br label %bb_rcslotdone427
bb_rcslotowner427:
  %v1785 = load i64, ptr %slot44, align 8
  store i64 %v1785, ptr %slot324, align 8
  %v1786 = load i64, ptr %slot324, align 8
  %v1787 = load i64, ptr %slot320, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1786, i64 %v1787) nomerge, !dbg !136
  br label %bb_rcslotdone427
bb_rcslotdone427:
  %v1788 = load i64, ptr %slot23, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  %ld1790 = load i64, ptr %p1789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1790, ptr %slot325, align 8
  %v1791 = load i64, ptr %slot325, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %ld1793 = load i32, ptr %p1792, align 4
  %ext1794 = zext i32 %ld1793 to i64
  store i64 %ext1794, ptr %slot326, align 8
  %v1795 = load i64, ptr %slot326, align 8
  %cmp1796 = icmp eq i64 %v1795, 0
  %cv1797 = zext i1 %cmp1796 to i64
  store i64 %cv1797, ptr %slot327, align 8
  %v1798 = load i64, ptr %slot327, align 8
  %cond1799 = icmp ne i64 %v1798, 0
  br i1 %cond1799, label %bb_rctryok435, label %bb_rctryerror435
bb_rctryerror435:
  %p1800 = inttoptr i64 ptrtoint (ptr @myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1800, i64 12884901924) "call-inline-cost"="0", !dbg !138
  %v1801 = load i64, ptr %slot325, align 8
  %op1802 = add i64 %v1801, 8
  store i64 %op1802, ptr %slot328, align 8
  %v1803 = load i64, ptr %slot35, align 8
  store i64 %v1803, ptr %slot329, align 8
  %v1804 = load i64, ptr %slot329, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  store i64 0, ptr %p1805, align 8, !alias.scope !3, !noalias !4
  %v1806 = load i64, ptr %slot329, align 8
  %p1808 = inttoptr i64 %v1806 to ptr
  %gep1809 = getelementptr i8, ptr %p1808, i64 8
  %op1807 = ptrtoint ptr %gep1809 to i64
  store i64 %op1807, ptr %slot330, align 8
  %v1810 = load i64, ptr %slot330, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  store i64 0, ptr %p1811, align 8, !alias.scope !3, !noalias !4
  %v1812 = load i64, ptr %slot329, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  store i32 1, ptr %p1813, align 4, !alias.scope !3, !noalias !4
  %v1814 = load i64, ptr %slot329, align 8
  %p1816 = inttoptr i64 %v1814 to ptr
  %gep1817 = getelementptr i8, ptr %p1816, i64 8
  %op1815 = ptrtoint ptr %gep1817 to i64
  store i64 %op1815, ptr %slot331, align 8
  %v1818 = load i64, ptr %slot13, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  store i32 1, ptr %p1819, align 4, !alias.scope !3, !noalias !4
  %v1820 = load i64, ptr %slot45, align 8
  store i64 %v1820, ptr %slot332, align 8
  %v1821 = load i64, ptr %slot329, align 8
  %v1822 = load i64, ptr %slot23, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  store i64 %v1821, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  br label %bb_i38
bb_rctryok435:
  %v1824 = load i64, ptr %slot35, align 8
  store i64 %v1824, ptr %slot333, align 8
  %v1825 = load i64, ptr %slot333, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i64 0, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot13, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i32 1, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  %v1829 = load i64, ptr %slot325, align 8
  %op1830 = add i64 %v1829, 8
  store i64 %op1830, ptr %slot334, align 8
  %v1831 = load i64, ptr %slot45, align 8
  store i64 %v1831, ptr %slot335, align 8
  %v1832 = load i64, ptr %slot334, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %ld1834 = load i64, ptr %p1833, align 8
  store i64 %ld1834, ptr %slot336, align 8
  %v1835 = load i64, ptr %slot336, align 8
  %v1836 = load i64, ptr %slot333, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i64 %v1835, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  %v1838 = load i64, ptr %slot333, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  %ld1840 = load i64, ptr %p1839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1840, ptr %slot337, align 8
  %v1841 = load i64, ptr %slot337, align 8
  %v1842 = load i64, ptr %slot23, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  store i64 %v1841, ptr %p1843, align 8, !alias.scope !3, !noalias !4
  br label %bb_i39
bb_i38:
  %v1844 = load i64, ptr %slot23, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  %ld1846 = load i64, ptr %p1845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1846, ptr %slot338, align 8
  %v1847 = load i64, ptr %slot5, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %ld1849 = load i32, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1849, ptr %slot339, align 8
  %v1850 = load i32, ptr %slot339, align 8
  %cv1851 = zext i32 %v1850 to i64
  %cond1852 = icmp ne i64 %cv1851, 0
  br i1 %cond1852, label %bb_rcslotdrop454, label %bb_rcslotdone454
bb_rcslotdrop454:
  %v1853 = load i64, ptr %slot5, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i32 0, ptr %p1854, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone454
bb_rcslotdone454:
  %v1855 = load i64, ptr %slot338, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %ret1857 = load { i64, i64 }, ptr %p1856, align 8
  ret { i64, i64 } %ret1857
bb_i39:
  %v1858 = load i64, ptr %slot36, align 8
  store i64 %v1858, ptr %slot340, align 8
  %v1859 = load i64, ptr %slot340, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  store i64 0, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  %v1861 = load i64, ptr %slot340, align 8
  %p1863 = inttoptr i64 %v1861 to ptr
  %gep1864 = getelementptr i8, ptr %p1863, i64 8
  %op1862 = ptrtoint ptr %gep1864 to i64
  store i64 %op1862, ptr %slot341, align 8
  %v1865 = load i64, ptr %slot341, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  store i64 0, ptr %p1866, align 8, !alias.scope !3, !noalias !4
  %v1867 = load i64, ptr %slot340, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  store i32 1, ptr %p1868, align 4, !alias.scope !3, !noalias !4
  %v1869 = load i64, ptr %slot13, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  store i32 1, ptr %p1870, align 4, !alias.scope !3, !noalias !4
  %v1871 = load i64, ptr %slot23, align 8
  store i64 %v1871, ptr %slot342, align 8
  %v1872 = load i64, ptr %slot340, align 8
  %p1874 = inttoptr i64 %v1872 to ptr
  %gep1875 = getelementptr i8, ptr %p1874, i64 8
  %op1873 = ptrtoint ptr %gep1875 to i64
  store i64 %op1873, ptr %slot343, align 8
  %v1876 = load i64, ptr %slot45, align 8
  store i64 %v1876, ptr %slot344, align 8
  %v1877 = load i64, ptr %slot342, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %ld1879 = load i64, ptr %p1878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1879, ptr %slot345, align 8
  %v1880 = load i64, ptr %slot345, align 8
  %v1881 = load i64, ptr %slot343, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i64 %v1880, ptr %p1882, align 8, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot340, align 8
  %v1884 = load i64, ptr %slot23, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i64 %v1883, ptr %p1885, align 8, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot23, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  %ld1888 = load i64, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1888, ptr %slot346, align 8
  %v1889 = load i64, ptr %slot346, align 8
  %v1890 = load i64, ptr %slot22, align 8
  %p1891 = inttoptr i64 %v1889 to ptr
  %p1892 = inttoptr i64 %v1890 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1892, ptr %p1891, i64 16, i1 false)
  br label %bb_i41
bb_i41:
  %v1893 = load i64, ptr %slot19, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  %ld1895 = load i64, ptr %p1894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1895, ptr %slot347, align 8
  %v1896 = load i64, ptr %slot347, align 8
  %v1897 = load i64, ptr %slot23, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  store i64 %v1896, ptr %p1898, align 8, !alias.scope !3, !noalias !4
  %v1899 = load i64, ptr %slot20, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot348, align 8
  %v1902 = load i64, ptr %slot348, align 8
  %v1903 = load i64, ptr %slot24, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i64 %v1902, ptr %p1904, align 8, !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot21, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  %ld1907 = load i64, ptr %p1906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1907, ptr %slot349, align 8
  %v1908 = load i64, ptr %slot349, align 8
  %v1909 = load i64, ptr %slot25, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i64 %v1908, ptr %p1910, align 8, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot22, align 8
  %v1912 = load i64, ptr %slot26, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  store i64 %v1911, ptr %p1913, align 8, !alias.scope !3, !noalias !4
  %v1914 = load i64, ptr %slot37, align 8
  store i64 %v1914, ptr %slot350, align 8
  %v1915 = load i64, ptr %slot45, align 8
  store i64 %v1915, ptr %slot351, align 8
  %v1916 = load i64, ptr %slot24, align 8
  store i64 %v1916, ptr %slot352, align 8
  %v1917 = load i64, ptr %slot350, align 8
  %p1919 = inttoptr i64 %v1917 to ptr
  %gep1920 = getelementptr i8, ptr %p1919, i64 0
  %op1918 = ptrtoint ptr %gep1920 to i64
  store i64 %op1918, ptr %slot353, align 8
  %v1921 = load i64, ptr %slot352, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  %ld1923 = load i64, ptr %p1922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1923, ptr %slot354, align 8
  %v1924 = load i64, ptr %slot354, align 8
  %v1925 = load i64, ptr %slot353, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i64 %v1924, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot25, align 8
  store i64 %v1927, ptr %slot355, align 8
  %v1928 = load i64, ptr %slot350, align 8
  %p1930 = inttoptr i64 %v1928 to ptr
  %gep1931 = getelementptr i8, ptr %p1930, i64 8
  %op1929 = ptrtoint ptr %gep1931 to i64
  store i64 %op1929, ptr %slot356, align 8
  %v1932 = load i64, ptr %slot355, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %ld1934 = load i64, ptr %p1933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1934, ptr %slot357, align 8
  %v1935 = load i64, ptr %slot357, align 8
  %v1936 = load i64, ptr %slot356, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  store i64 %v1935, ptr %p1937, align 8, !alias.scope !3, !noalias !4
  %v1938 = load i64, ptr %slot26, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %ld1940 = load i64, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1940, ptr %slot358, align 8
  %v1941 = load i64, ptr %slot350, align 8
  %p1943 = inttoptr i64 %v1941 to ptr
  %gep1944 = getelementptr i8, ptr %p1943, i64 16
  %op1942 = ptrtoint ptr %gep1944 to i64
  store i64 %op1942, ptr %slot359, align 8
  %v1945 = load i64, ptr %slot358, align 8
  %v1946 = load i64, ptr %slot359, align 8
  %p1947 = inttoptr i64 %v1945 to ptr
  %p1948 = inttoptr i64 %v1946 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1948, ptr %p1947, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1949 = load i64, ptr %slot350, align 8
  %v1950 = load i64, ptr %slot24, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  store i64 %v1949, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot38, align 8
  store i64 %v1952, ptr %slot360, align 8
  %v1953 = load i64, ptr %slot360, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  call void @llvm.memset.p0.i64(ptr %p1954, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1955 = load i64, ptr %slot360, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i32 4, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot13, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i32 1, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot24, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i64, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1961, ptr %slot361, align 8
  %v1962 = load i64, ptr %slot360, align 8
  %p1964 = inttoptr i64 %v1962 to ptr
  %gep1965 = getelementptr i8, ptr %p1964, i64 8
  %op1963 = ptrtoint ptr %gep1965 to i64
  store i64 %op1963, ptr %slot362, align 8
  %v1966 = load i64, ptr %slot45, align 8
  store i64 %v1966, ptr %slot363, align 8
  %v1967 = load i64, ptr %slot361, align 8
  %v1968 = load i64, ptr %slot362, align 8
  %p1969 = inttoptr i64 %v1967 to ptr
  %p1970 = inttoptr i64 %v1968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1970, ptr %p1969, i64 32, i1 false)
  %v1971 = load i64, ptr %slot360, align 8
  %v1972 = load i64, ptr %slot24, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i64 %v1971, ptr %p1973, align 8, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot24, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  %ld1976 = load i64, ptr %p1975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1976, ptr %slot364, align 8
  %v1977 = load i64, ptr %slot15, align 8
  store i64 %v1977, ptr %slot365, align 8
  %v1978 = load i64, ptr %slot364, align 8
  %v1979 = load i64, ptr %slot365, align 8
  %p1980 = inttoptr i64 %v1978 to ptr
  %p1981 = inttoptr i64 %v1979 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1981, ptr %p1980, i64 88, i1 false)
  %v1982 = load i64, ptr %slot8, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 2, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot7, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  store i32 1, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  %v1986 = load i64, ptr %slot365, align 8
  %v1987 = load i64, ptr %slot24, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i64 %v1986, ptr %p1988, align 8, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot23, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  %ld1991 = load i64, ptr %p1990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1991, ptr %slot366, align 8
  %v1992 = load i64, ptr %slot24, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %ld1994 = load i64, ptr %p1993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1994, ptr %slot367, align 8
  %v1995 = load i64, ptr %slot1, align 8
  %v1996 = load i64, ptr %slot366, align 8
  %v1997 = load i64, ptr %slot367, align 8
  %call1998 = call i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64 %v1995, i64 %v1996, i64 %v1997) nomerge, !dbg !142
  store i64 %call1998, ptr %slot368, align 8
  %v1999 = load i64, ptr %slot368, align 8
  %v2000 = load i64, ptr %slot23, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i64 %v1999, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot5, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i32, ptr %p2003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2004, ptr %slot369, align 8
  %v2005 = load i32, ptr %slot369, align 8
  %cv2006 = zext i32 %v2005 to i64
  %cond2007 = icmp ne i64 %cv2006, 0
  br i1 %cond2007, label %bb_rcslotdrop501, label %bb_rcslotdone501
bb_rcslotdrop501:
  %v2008 = load i64, ptr %slot5, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  store i32 0, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  %v2010 = load i64, ptr %slot14, align 8
  store i64 %v2010, ptr %slot370, align 8
  %v2011 = load i64, ptr %slot6, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %ld2013 = load i32, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2013, ptr %slot371, align 8
  %v2014 = load i32, ptr %slot371, align 8
  %op2015 = and i32 %v2014, 28
  store i32 %op2015, ptr %slot372, align 8
  %v2016 = load i32, ptr %slot372, align 8
  %cv2017 = zext i32 %v2016 to i64
  %cond2018 = icmp ne i64 %cv2017, 0
  br i1 %cond2018, label %bb_rcslotrole501, label %bb_rcslotowner501
bb_rcslotrole501:
  %v2019 = load i64, ptr %slot44, align 8
  store i64 %v2019, ptr %slot373, align 8
  %v2020 = load i64, ptr %slot373, align 8
  %v2021 = load i64, ptr %slot370, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2020, i64 %v2021) nomerge, !dbg !142
  br label %bb_rcslotdone501
bb_rcslotowner501:
  %v2022 = load i64, ptr %slot44, align 8
  store i64 %v2022, ptr %slot374, align 8
  %v2023 = load i64, ptr %slot374, align 8
  %v2024 = load i64, ptr %slot370, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2023, i64 %v2024) nomerge, !dbg !142
  br label %bb_rcslotdone501
bb_rcslotdone501:
  %v2025 = load i64, ptr %slot7, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i32, ptr %p2026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2027, ptr %slot375, align 8
  %v2028 = load i32, ptr %slot375, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcslotdrop510, label %bb_rcslotdone510
bb_rcslotdrop510:
  %v2031 = load i64, ptr %slot7, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i32 0, ptr %p2032, align 4, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot15, align 8
  store i64 %v2033, ptr %slot376, align 8
  %v2034 = load i64, ptr %slot8, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %ld2036 = load i32, ptr %p2035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2036, ptr %slot377, align 8
  %v2037 = load i32, ptr %slot377, align 8
  %op2038 = and i32 %v2037, 28
  store i32 %op2038, ptr %slot378, align 8
  %v2039 = load i32, ptr %slot378, align 8
  %cv2040 = zext i32 %v2039 to i64
  %cond2041 = icmp ne i64 %cv2040, 0
  br i1 %cond2041, label %bb_rcslotrole510, label %bb_rcslotowner510
bb_rcslotrole510:
  %v2042 = load i64, ptr %slot44, align 8
  store i64 %v2042, ptr %slot379, align 8
  %v2043 = load i64, ptr %slot379, align 8
  %v2044 = load i64, ptr %slot376, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v2043, i64 %v2044) nomerge, !dbg !142
  br label %bb_rcslotdone510
bb_rcslotowner510:
  %v2045 = load i64, ptr %slot44, align 8
  store i64 %v2045, ptr %slot380, align 8
  %v2046 = load i64, ptr %slot380, align 8
  %v2047 = load i64, ptr %slot376, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v2046, i64 %v2047) nomerge, !dbg !142
  br label %bb_rcslotdone510
bb_rcslotdone510:
  %v2048 = load i64, ptr %slot39, align 8
  store i64 %v2048, ptr %slot381, align 8
  %v2049 = load i64, ptr %slot381, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i64 0, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot381, align 8
  %p2053 = inttoptr i64 %v2051 to ptr
  %gep2054 = getelementptr i8, ptr %p2053, i64 8
  %op2052 = ptrtoint ptr %gep2054 to i64
  store i64 %op2052, ptr %slot382, align 8
  %v2055 = load i64, ptr %slot382, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 0, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot381, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i32 0, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot13, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  store i32 1, ptr %p2060, align 4, !alias.scope !3, !noalias !4
  %v2061 = load i64, ptr %slot23, align 8
  store i64 %v2061, ptr %slot383, align 8
  %v2062 = load i64, ptr %slot381, align 8
  %p2064 = inttoptr i64 %v2062 to ptr
  %gep2065 = getelementptr i8, ptr %p2064, i64 8
  %op2063 = ptrtoint ptr %gep2065 to i64
  store i64 %op2063, ptr %slot384, align 8
  %v2066 = load i64, ptr %slot45, align 8
  store i64 %v2066, ptr %slot385, align 8
  %v2067 = load i64, ptr %slot383, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i64, ptr %p2068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2069, ptr %slot386, align 8
  %v2070 = load i64, ptr %slot386, align 8
  %v2071 = load i64, ptr %slot384, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i64 %v2070, ptr %p2072, align 8, !alias.scope !3, !noalias !4
  %v2073 = load i64, ptr %slot381, align 8
  %v2074 = load i64, ptr %slot23, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i64 %v2073, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot23, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %ld2078 = load i64, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2078, ptr %slot387, align 8
  %v2079 = load i64, ptr %slot5, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %ld2081 = load i32, ptr %p2080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2081, ptr %slot388, align 8
  %v2082 = load i32, ptr %slot388, align 8
  %cv2083 = zext i32 %v2082 to i64
  %cond2084 = icmp ne i64 %cv2083, 0
  br i1 %cond2084, label %bb_rcslotdrop528, label %bb_rcslotdone528
bb_rcslotdrop528:
  %v2085 = load i64, ptr %slot5, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i32 0, ptr %p2086, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone528
bb_rcslotdone528:
  %v2087 = load i64, ptr %slot387, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  %ret2089 = load { i64, i64 }, ptr %p2088, align 8
  ret { i64, i64 } %ret2089
bb_failure:
  %v2090 = load i64, ptr %slot4, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  call void @llvm.memset.p0.i64(ptr %p2091, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !144
  %v2092 = load i64, ptr %slot4, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %ret2094 = load { i64, i64 }, ptr %p2093, align 8
  ret { i64, i64 } %ret2094
bb_entry_failure:
  %v2095 = load i64, ptr %slot4, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  call void @llvm.memset.p0.i64(ptr %p2096, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !144
  %v2097 = load i64, ptr %slot4, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ret2099 = load { i64, i64 }, ptr %p2098, align 8
  ret { i64, i64 } %ret2099
}

@myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0_meta = external global i8, align 8
@myl_lit_48c1b2cf871bbf29cf2339e23b6a684925b7d02da971745c51b0881c1204eafb = external global i8, align 8
@myl_lit_ae95ccd4f4fa503023e0e12571b49ac0a774d7359e9bb6d464c7aa7c975f9c74 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64, i64, i64)
declare { i64, i64 } @myl_f_b13f4ab9daf64ead55e487db26091940a8962e953a64ff9ffb47533439115d1a(i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0", linkageName: "myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9325181426686799892, i64 0, !"myl_f_26ab0c8d32fe7f71fa8b801746c32315544aef4c5e30e5b34f645067f43409b0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!122 = !DILocation(line: 11, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!126 = !DILocation(line: 19, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!128 = !DILocation(line: 22, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!130 = !DILocation(line: 24, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!132 = !DILocation(line: 25, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!134 = !DILocation(line: 33, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!138 = !DILocation(line: 37, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!140 = !DILocation(line: 47, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!142 = !DILocation(line: 48, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!144 = !DILocation(line: 50, column: 0, scope: !145)
