target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_393b03e6e8000a2be3bf0bb432f9197ce3fbfd4c525e561e0f9e9b1b3cc38f9b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca double, align 8
  %slot79 = alloca double, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v103 = load i64, ptr %slot1, align 8
  %op104 = add i64 %v103, 32
  store i64 %op104, ptr %slot4, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot5, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot6, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot7, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot8, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot9, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot10, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot11, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot12, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot13, align 8
  %mem123 = alloca i8, i64 8, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot14, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot15, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot16, align 8
  %v129 = load i64, ptr %slot2, align 8
  %v130 = load i64, ptr %slot5, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i64 %v129, ptr %p131, align 8, !alias.scope !3, !noalias !4
  %v132 = load i64, ptr %slot3, align 8
  %v133 = load i64, ptr %slot6, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v135 = load i64, ptr %slot5, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot17, align 8
  %v138 = load i64, ptr %slot17, align 8
  %v139 = load i64, ptr %slot15, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i64 %v138, ptr %p140, align 8, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot15, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld143, ptr %slot18, align 8
  %v144 = load i64, ptr %slot18, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i32, ptr %p145, align 4, !alias.scope !4, !noalias !3
  %ext147 = zext i32 %ld146 to i64
  store i64 %ext147, ptr %slot19, align 8
  %v148 = load i64, ptr %slot19, align 8
  %cmp149 = icmp eq i64 %v148, 0
  %cv150 = zext i1 %cmp149 to i64
  store i64 %cv150, ptr %slot20, align 8
  %v151 = load i64, ptr %slot20, align 8
  %cond152 = icmp ne i64 %v151, 0
  br i1 %cond152, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i2
bb_armnext3:
  %v153 = load i64, ptr %slot19, align 8
  %cmp154 = icmp eq i64 %v153, 1
  %cv155 = zext i1 %cmp154 to i64
  store i64 %cv155, ptr %slot21, align 8
  %v156 = load i64, ptr %slot21, align 8
  %cond157 = icmp ne i64 %v156, 0
  br i1 %cond157, label %bb_arm4, label %bb_armnext4
bb_arm4:
  %v158 = load i64, ptr %slot18, align 8
  %op159 = add i64 %v158, 8
  store i64 %op159, ptr %slot22, align 8
  %v160 = load i64, ptr %slot22, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i8, ptr %p161, align 1, !alias.scope !4, !noalias !3
  %ext163 = zext i8 %ld162 to i64
  store i64 %ext163, ptr %slot23, align 8
  %v164 = load i64, ptr %slot23, align 8
  %v165 = load i64, ptr %slot7, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 %v164, ptr %p166, align 8, !alias.scope !3, !noalias !4
  br label %bb_i12
bb_armnext4:
  %v167 = load i64, ptr %slot19, align 8
  %cmp168 = icmp eq i64 %v167, 2
  %cv169 = zext i1 %cmp168 to i64
  store i64 %cv169, ptr %slot24, align 8
  %v170 = load i64, ptr %slot24, align 8
  %cond171 = icmp ne i64 %v170, 0
  br i1 %cond171, label %bb_arm7, label %bb_armnext7
bb_arm7:
  %v172 = load i64, ptr %slot18, align 8
  %op173 = add i64 %v172, 8
  store i64 %op173, ptr %slot25, align 8
  %v174 = load i64, ptr %slot25, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !4, !noalias !3
  store i64 %ld176, ptr %slot26, align 8
  %v177 = load i64, ptr %slot26, align 8
  %v178 = load i64, ptr %slot9, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_armnext7:
  %v180 = load i64, ptr %slot19, align 8
  %cmp181 = icmp eq i64 %v180, 3
  %cv182 = zext i1 %cmp181 to i64
  store i64 %cv182, ptr %slot27, align 8
  %v183 = load i64, ptr %slot27, align 8
  %cond184 = icmp ne i64 %v183, 0
  br i1 %cond184, label %bb_arm10, label %bb_armnext10
bb_arm10:
  %v185 = load i64, ptr %slot18, align 8
  %op186 = add i64 %v185, 8
  store i64 %op186, ptr %slot28, align 8
  %v187 = load i64, ptr %slot28, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !4, !noalias !3
  store i64 %ld189, ptr %slot29, align 8
  %v190 = load i64, ptr %slot29, align 8
  %v191 = load i64, ptr %slot13, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 %v190, ptr %p192, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_armnext10:
  br label %bb_failure
bb_i2:
  %v193 = load i64, ptr %slot6, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %ld195 = load i64, ptr %p194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld195, ptr %slot30, align 8
  %v196 = load i64, ptr %slot30, align 8
  %v197 = load i64, ptr %slot15, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot15, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i64, ptr %p200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld201, ptr %slot31, align 8
  %v202 = load i64, ptr %slot31, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i32, ptr %p203, align 4, !alias.scope !4, !noalias !3
  %ext205 = zext i32 %ld204 to i64
  store i64 %ext205, ptr %slot32, align 8
  %v206 = load i64, ptr %slot32, align 8
  %cmp207 = icmp eq i64 %v206, 0
  %cv208 = zext i1 %cmp207 to i64
  store i64 %cv208, ptr %slot33, align 8
  %v209 = load i64, ptr %slot33, align 8
  %cond210 = icmp ne i64 %v209, 0
  br i1 %cond210, label %bb_arm16, label %bb_armnext16
bb_arm16:
  br label %bb_i4
bb_armnext16:
  %v211 = load i64, ptr %slot32, align 8
  %cmp212 = icmp eq i64 %v211, 1
  %cv213 = zext i1 %cmp212 to i64
  store i64 %cv213, ptr %slot34, align 8
  %v214 = load i64, ptr %slot34, align 8
  %cond215 = icmp ne i64 %v214, 0
  br i1 %cond215, label %bb_arm17, label %bb_armnext17
bb_arm17:
  br label %bb_i6
bb_armnext17:
  %v216 = load i64, ptr %slot32, align 8
  %cmp217 = icmp eq i64 %v216, 2
  %cv218 = zext i1 %cmp217 to i64
  store i64 %cv218, ptr %slot35, align 8
  %v219 = load i64, ptr %slot35, align 8
  %cond220 = icmp ne i64 %v219, 0
  br i1 %cond220, label %bb_arm18, label %bb_armnext18
bb_arm18:
  br label %bb_i8
bb_armnext18:
  %v221 = load i64, ptr %slot32, align 8
  %cmp222 = icmp eq i64 %v221, 3
  %cv223 = zext i1 %cmp222 to i64
  store i64 %cv223, ptr %slot36, align 8
  %v224 = load i64, ptr %slot36, align 8
  %cond225 = icmp ne i64 %v224, 0
  br i1 %cond225, label %bb_arm19, label %bb_armnext19
bb_arm19:
  br label %bb_i10
bb_armnext19:
  br label %bb_failure
bb_i4:
  %v226 = load i64, ptr %slot15, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 1, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot15, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld230, ptr %slot37, align 8
  %v231 = load i64, ptr %slot37, align 8
  ret i64 %v231
bb_i6:
  %v232 = load i64, ptr %slot15, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i64 0, ptr %p233, align 8, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot15, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot38, align 8
  %v237 = load i64, ptr %slot38, align 8
  ret i64 %v237
bb_i8:
  %v238 = load i64, ptr %slot15, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 0, ptr %p239, align 8, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot15, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot39, align 8
  %v243 = load i64, ptr %slot39, align 8
  ret i64 %v243
bb_i10:
  %v244 = load i64, ptr %slot15, align 8
  %p245 = inttoptr i64 %v244 to ptr
  store i64 0, ptr %p245, align 8, !alias.scope !3, !noalias !4
  %v246 = load i64, ptr %slot15, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot40, align 8
  %v249 = load i64, ptr %slot40, align 8
  ret i64 %v249
bb_i12:
  %v250 = load i64, ptr %slot6, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot41, align 8
  %v253 = load i64, ptr %slot41, align 8
  %v254 = load i64, ptr %slot15, align 8
  %p255 = inttoptr i64 %v254 to ptr
  store i64 %v253, ptr %p255, align 8, !alias.scope !3, !noalias !4
  %v256 = load i64, ptr %slot15, align 8
  %p257 = inttoptr i64 %v256 to ptr
  %ld258 = load i64, ptr %p257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld258, ptr %slot42, align 8
  %v259 = load i64, ptr %slot42, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i32, ptr %p260, align 4, !alias.scope !4, !noalias !3
  %ext262 = zext i32 %ld261 to i64
  store i64 %ext262, ptr %slot43, align 8
  %v263 = load i64, ptr %slot43, align 8
  %cmp264 = icmp eq i64 %v263, 0
  %cv265 = zext i1 %cmp264 to i64
  store i64 %cv265, ptr %slot44, align 8
  %v266 = load i64, ptr %slot44, align 8
  %cond267 = icmp ne i64 %v266, 0
  br i1 %cond267, label %bb_arm27, label %bb_armnext27
bb_arm27:
  br label %bb_i18
bb_armnext27:
  %v268 = load i64, ptr %slot43, align 8
  %cmp269 = icmp eq i64 %v268, 1
  %cv270 = zext i1 %cmp269 to i64
  store i64 %cv270, ptr %slot45, align 8
  %v271 = load i64, ptr %slot45, align 8
  %cond272 = icmp ne i64 %v271, 0
  br i1 %cond272, label %bb_arm28, label %bb_armnext28
bb_arm28:
  %v273 = load i64, ptr %slot42, align 8
  %op274 = add i64 %v273, 8
  store i64 %op274, ptr %slot46, align 8
  %v275 = load i64, ptr %slot46, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i8, ptr %p276, align 1, !alias.scope !4, !noalias !3
  %ext278 = zext i8 %ld277 to i64
  store i64 %ext278, ptr %slot47, align 8
  %v279 = load i64, ptr %slot47, align 8
  %v280 = load i64, ptr %slot8, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_armnext28:
  %v282 = load i64, ptr %slot43, align 8
  %cmp283 = icmp eq i64 %v282, 2
  %cv284 = zext i1 %cmp283 to i64
  store i64 %cv284, ptr %slot48, align 8
  %v285 = load i64, ptr %slot48, align 8
  %cond286 = icmp ne i64 %v285, 0
  br i1 %cond286, label %bb_arm31, label %bb_armnext31
bb_arm31:
  br label %bb_i20
bb_armnext31:
  %v287 = load i64, ptr %slot43, align 8
  %cmp288 = icmp eq i64 %v287, 3
  %cv289 = zext i1 %cmp288 to i64
  store i64 %cv289, ptr %slot49, align 8
  %v290 = load i64, ptr %slot49, align 8
  %cond291 = icmp ne i64 %v290, 0
  br i1 %cond291, label %bb_arm32, label %bb_armnext32
bb_arm32:
  br label %bb_i22
bb_armnext32:
  br label %bb_failure
bb_i14:
  %v292 = load i64, ptr %slot7, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld294, ptr %slot50, align 8
  %v295 = load i64, ptr %slot50, align 8
  %v296 = load i64, ptr %slot15, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 %v295, ptr %p297, align 8, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot8, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %ld300 = load i64, ptr %p299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld300, ptr %slot51, align 8
  %v301 = load i64, ptr %slot51, align 8
  %v302 = load i64, ptr %slot16, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 %v301, ptr %p303, align 8, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot16, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot52, align 8
  %v307 = load i64, ptr %slot15, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %ld309 = load i64, ptr %p308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld309, ptr %slot53, align 8
  %v310 = load i64, ptr %slot53, align 8
  %v311 = load i64, ptr %slot52, align 8
  %cmp312 = icmp eq i64 %v310, %v311
  %cv313 = zext i1 %cmp312 to i64
  store i64 %cv313, ptr %slot54, align 8
  %v314 = load i64, ptr %slot54, align 8
  %v315 = load i64, ptr %slot15, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 %v314, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot15, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot55, align 8
  %v320 = load i64, ptr %slot55, align 8
  ret i64 %v320
bb_i18:
  %v321 = load i64, ptr %slot15, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 0, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot15, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot56, align 8
  %v326 = load i64, ptr %slot56, align 8
  ret i64 %v326
bb_i20:
  %v327 = load i64, ptr %slot15, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 0, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot15, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot57, align 8
  %v332 = load i64, ptr %slot57, align 8
  ret i64 %v332
bb_i22:
  %v333 = load i64, ptr %slot15, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 0, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot15, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot58, align 8
  %v338 = load i64, ptr %slot58, align 8
  ret i64 %v338
bb_i24:
  %v339 = load i64, ptr %slot6, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %ld341 = load i64, ptr %p340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld341, ptr %slot59, align 8
  %v342 = load i64, ptr %slot59, align 8
  %v343 = load i64, ptr %slot15, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 %v342, ptr %p344, align 8, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot15, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot60, align 8
  %v348 = load i64, ptr %slot60, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i32, ptr %p349, align 4, !alias.scope !4, !noalias !3
  %ext351 = zext i32 %ld350 to i64
  store i64 %ext351, ptr %slot61, align 8
  %v352 = load i64, ptr %slot61, align 8
  %cmp353 = icmp eq i64 %v352, 0
  %cv354 = zext i1 %cmp353 to i64
  store i64 %cv354, ptr %slot62, align 8
  %v355 = load i64, ptr %slot62, align 8
  %cond356 = icmp ne i64 %v355, 0
  br i1 %cond356, label %bb_arm45, label %bb_armnext45
bb_arm45:
  br label %bb_i36
bb_armnext45:
  %v357 = load i64, ptr %slot61, align 8
  %cmp358 = icmp eq i64 %v357, 1
  %cv359 = zext i1 %cmp358 to i64
  store i64 %cv359, ptr %slot63, align 8
  %v360 = load i64, ptr %slot63, align 8
  %cond361 = icmp ne i64 %v360, 0
  br i1 %cond361, label %bb_arm46, label %bb_armnext46
bb_arm46:
  br label %bb_i38
bb_armnext46:
  %v362 = load i64, ptr %slot61, align 8
  %cmp363 = icmp eq i64 %v362, 2
  %cv364 = zext i1 %cmp363 to i64
  store i64 %cv364, ptr %slot64, align 8
  %v365 = load i64, ptr %slot64, align 8
  %cond366 = icmp ne i64 %v365, 0
  br i1 %cond366, label %bb_arm47, label %bb_armnext47
bb_arm47:
  %v367 = load i64, ptr %slot60, align 8
  %op368 = add i64 %v367, 8
  store i64 %op368, ptr %slot65, align 8
  %v369 = load i64, ptr %slot65, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !4, !noalias !3
  store i64 %ld371, ptr %slot66, align 8
  %v372 = load i64, ptr %slot66, align 8
  %v373 = load i64, ptr %slot10, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i64 %v372, ptr %p374, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_armnext47:
  %v375 = load i64, ptr %slot61, align 8
  %cmp376 = icmp eq i64 %v375, 3
  %cv377 = zext i1 %cmp376 to i64
  store i64 %cv377, ptr %slot67, align 8
  %v378 = load i64, ptr %slot67, align 8
  %cond379 = icmp ne i64 %v378, 0
  br i1 %cond379, label %bb_arm50, label %bb_armnext50
bb_arm50:
  br label %bb_i40
bb_armnext50:
  br label %bb_failure
bb_i26:
  %v380 = load i64, ptr %slot9, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i64, ptr %p381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld382, ptr %slot68, align 8
  %v383 = load i64, ptr %slot68, align 8
  %v384 = load i64, ptr %slot15, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 %v383, ptr %p385, align 8, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot15, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot69, align 8
  %v389 = load i64, ptr %slot11, align 8
  store i64 %v389, ptr %slot70, align 8
  %v390 = load i64, ptr %slot69, align 8
  %v391 = load i64, ptr %slot70, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 %v390, ptr %p392, align 8, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot10, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %ld395 = load i64, ptr %p394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld395, ptr %slot71, align 8
  %v396 = load i64, ptr %slot71, align 8
  %v397 = load i64, ptr %slot15, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i64 %v396, ptr %p398, align 8, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot15, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot72, align 8
  %v402 = load i64, ptr %slot12, align 8
  store i64 %v402, ptr %slot73, align 8
  %v403 = load i64, ptr %slot72, align 8
  %v404 = load i64, ptr %slot73, align 8
  %p405 = inttoptr i64 %v404 to ptr
  store i64 %v403, ptr %p405, align 8, !alias.scope !3, !noalias !4
  %v406 = load i64, ptr %slot11, align 8
  %p407 = inttoptr i64 %v406 to ptr
  %ld408 = load i64, ptr %p407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld408, ptr %slot74, align 8
  %v409 = load i64, ptr %slot74, align 8
  %v410 = load i64, ptr %slot15, align 8
  %p411 = inttoptr i64 %v410 to ptr
  store i64 %v409, ptr %p411, align 8, !alias.scope !3, !noalias !4
  %v412 = load i64, ptr %slot12, align 8
  %p413 = inttoptr i64 %v412 to ptr
  %ld414 = load i64, ptr %p413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld414, ptr %slot75, align 8
  %v415 = load i64, ptr %slot75, align 8
  %v416 = load i64, ptr %slot16, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i64 %v415, ptr %p417, align 8, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot16, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld420, ptr %slot76, align 8
  %v421 = load i64, ptr %slot15, align 8
  %p422 = inttoptr i64 %v421 to ptr
  %ld423 = load i64, ptr %p422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld423, ptr %slot77, align 8
  %v424 = load i64, ptr %slot77, align 8
  %cast425 = bitcast i64 %v424 to double
  store double %cast425, ptr %slot78, align 8
  %v426 = load i64, ptr %slot76, align 8
  %cast427 = bitcast i64 %v426 to double
  store double %cast427, ptr %slot79, align 8
  %v428 = load double, ptr %slot78, align 8
  %v429 = load double, ptr %slot79, align 8
  %cmp430 = fcmp oeq double %v428, %v429
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot80, align 8
  %v432 = load i64, ptr %slot80, align 8
  %v433 = load i64, ptr %slot15, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot15, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i64, ptr %p436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld437, ptr %slot81, align 8
  %v438 = load i64, ptr %slot81, align 8
  ret i64 %v438
bb_i36:
  %v439 = load i64, ptr %slot15, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i64 0, ptr %p440, align 8, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot15, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i64, ptr %p442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld443, ptr %slot82, align 8
  %v444 = load i64, ptr %slot82, align 8
  ret i64 %v444
bb_i38:
  %v445 = load i64, ptr %slot15, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 0, ptr %p446, align 8, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot15, align 8
  %p448 = inttoptr i64 %v447 to ptr
  %ld449 = load i64, ptr %p448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld449, ptr %slot83, align 8
  %v450 = load i64, ptr %slot83, align 8
  ret i64 %v450
bb_i40:
  %v451 = load i64, ptr %slot15, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i64 0, ptr %p452, align 8, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot15, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i64, ptr %p454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot84, align 8
  %v456 = load i64, ptr %slot84, align 8
  ret i64 %v456
bb_i42:
  %v457 = load i64, ptr %slot6, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot85, align 8
  %v460 = load i64, ptr %slot85, align 8
  %v461 = load i64, ptr %slot15, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i64 %v460, ptr %p462, align 8, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot15, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %ld465 = load i64, ptr %p464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld465, ptr %slot86, align 8
  %v466 = load i64, ptr %slot86, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %ld468 = load i32, ptr %p467, align 4, !alias.scope !4, !noalias !3
  %ext469 = zext i32 %ld468 to i64
  store i64 %ext469, ptr %slot87, align 8
  %v470 = load i64, ptr %slot87, align 8
  %cmp471 = icmp eq i64 %v470, 0
  %cv472 = zext i1 %cmp471 to i64
  store i64 %cv472, ptr %slot88, align 8
  %v473 = load i64, ptr %slot88, align 8
  %cond474 = icmp ne i64 %v473, 0
  br i1 %cond474, label %bb_arm71, label %bb_armnext71
bb_arm71:
  br label %bb_i48
bb_armnext71:
  %v475 = load i64, ptr %slot87, align 8
  %cmp476 = icmp eq i64 %v475, 1
  %cv477 = zext i1 %cmp476 to i64
  store i64 %cv477, ptr %slot89, align 8
  %v478 = load i64, ptr %slot89, align 8
  %cond479 = icmp ne i64 %v478, 0
  br i1 %cond479, label %bb_arm72, label %bb_armnext72
bb_arm72:
  br label %bb_i50
bb_armnext72:
  %v480 = load i64, ptr %slot87, align 8
  %cmp481 = icmp eq i64 %v480, 2
  %cv482 = zext i1 %cmp481 to i64
  store i64 %cv482, ptr %slot90, align 8
  %v483 = load i64, ptr %slot90, align 8
  %cond484 = icmp ne i64 %v483, 0
  br i1 %cond484, label %bb_arm73, label %bb_armnext73
bb_arm73:
  br label %bb_i52
bb_armnext73:
  %v485 = load i64, ptr %slot87, align 8
  %cmp486 = icmp eq i64 %v485, 3
  %cv487 = zext i1 %cmp486 to i64
  store i64 %cv487, ptr %slot91, align 8
  %v488 = load i64, ptr %slot91, align 8
  %cond489 = icmp ne i64 %v488, 0
  br i1 %cond489, label %bb_arm74, label %bb_armnext74
bb_arm74:
  %v490 = load i64, ptr %slot86, align 8
  %op491 = add i64 %v490, 8
  store i64 %op491, ptr %slot92, align 8
  %v492 = load i64, ptr %slot92, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !4, !noalias !3
  store i64 %ld494, ptr %slot93, align 8
  %v495 = load i64, ptr %slot93, align 8
  %v496 = load i64, ptr %slot14, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 %v495, ptr %p497, align 8, !alias.scope !3, !noalias !4
  br label %bb_i44
bb_armnext74:
  br label %bb_failure
bb_i44:
  %v498 = load i64, ptr %slot13, align 8
  %p499 = inttoptr i64 %v498 to ptr
  %ld500 = load i64, ptr %p499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld500, ptr %slot94, align 8
  %v501 = load i64, ptr %slot94, align 8
  %v502 = load i64, ptr %slot15, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot14, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot95, align 8
  %v507 = load i64, ptr %slot95, align 8
  %v508 = load i64, ptr %slot16, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot16, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot96, align 8
  %v513 = load i64, ptr %slot15, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %ld515 = load i64, ptr %p514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld515, ptr %slot97, align 8
  %v516 = load i64, ptr %slot97, align 8
  %v517 = load i64, ptr %slot96, align 8
  %cmp518 = icmp eq i64 %v516, %v517
  %cv519 = zext i1 %cmp518 to i64
  store i64 %cv519, ptr %slot98, align 8
  %v520 = load i64, ptr %slot98, align 8
  %v521 = load i64, ptr %slot15, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot15, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i64, ptr %p524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld525, ptr %slot99, align 8
  %v526 = load i64, ptr %slot99, align 8
  ret i64 %v526
bb_i48:
  %v527 = load i64, ptr %slot15, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i64 0, ptr %p528, align 8, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot15, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ld531 = load i64, ptr %p530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld531, ptr %slot100, align 8
  %v532 = load i64, ptr %slot100, align 8
  ret i64 %v532
bb_i50:
  %v533 = load i64, ptr %slot15, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i64 0, ptr %p534, align 8, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot15, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot101, align 8
  %v538 = load i64, ptr %slot101, align 8
  ret i64 %v538
bb_i52:
  %v539 = load i64, ptr %slot15, align 8
  %p540 = inttoptr i64 %v539 to ptr
  store i64 0, ptr %p540, align 8, !alias.scope !3, !noalias !4
  %v541 = load i64, ptr %slot15, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot102, align 8
  %v544 = load i64, ptr %slot102, align 8
  ret i64 %v544
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
