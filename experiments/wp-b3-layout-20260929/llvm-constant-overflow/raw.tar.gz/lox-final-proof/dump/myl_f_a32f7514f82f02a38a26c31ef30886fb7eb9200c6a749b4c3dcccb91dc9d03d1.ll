target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %callresult69 = alloca [24 x i8], align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i32, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i32, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i32, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i32, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i32, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i64, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i32, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i32, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i32, align 8
  %slot1389 = alloca i32, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i32, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i32, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i32, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1429 = load i64, ptr %slot1, align 8
  %op1430 = add i64 %v1429, 32
  store i64 %op1430, ptr %slot4, align 8
  %mem1431 = alloca i8, i64 8, align 8
  %ptr1432 = ptrtoint ptr %mem1431 to i64
  store i64 %ptr1432, ptr %slot5, align 8
  %mem1433 = alloca i8, i64 8, align 8
  %ptr1434 = ptrtoint ptr %mem1433 to i64
  store i64 %ptr1434, ptr %slot6, align 8
  %mem1435 = alloca i8, i64 8, align 8
  %ptr1436 = ptrtoint ptr %mem1435 to i64
  store i64 %ptr1436, ptr %slot7, align 8
  %mem1437 = alloca i8, i64 8, align 8
  %ptr1438 = ptrtoint ptr %mem1437 to i64
  store i64 %ptr1438, ptr %slot8, align 8
  %mem1439 = alloca i8, i64 8, align 8
  %ptr1440 = ptrtoint ptr %mem1439 to i64
  store i64 %ptr1440, ptr %slot9, align 8
  %mem1441 = alloca i8, i64 8, align 8
  %ptr1442 = ptrtoint ptr %mem1441 to i64
  store i64 %ptr1442, ptr %slot10, align 8
  %mem1443 = alloca i8, i64 8, align 8
  %ptr1444 = ptrtoint ptr %mem1443 to i64
  store i64 %ptr1444, ptr %slot11, align 8
  %mem1445 = alloca i8, i64 8, align 8
  %ptr1446 = ptrtoint ptr %mem1445 to i64
  store i64 %ptr1446, ptr %slot12, align 8
  %mem1447 = alloca i8, i64 8, align 8
  %ptr1448 = ptrtoint ptr %mem1447 to i64
  store i64 %ptr1448, ptr %slot13, align 8
  %mem1449 = alloca i8, i64 8, align 8
  %ptr1450 = ptrtoint ptr %mem1449 to i64
  store i64 %ptr1450, ptr %slot14, align 8
  %mem1451 = alloca i8, i64 8, align 8
  %ptr1452 = ptrtoint ptr %mem1451 to i64
  store i64 %ptr1452, ptr %slot15, align 8
  %mem1453 = alloca i8, i64 8, align 8
  %ptr1454 = ptrtoint ptr %mem1453 to i64
  store i64 %ptr1454, ptr %slot16, align 8
  %mem1455 = alloca i8, i64 8, align 8
  %ptr1456 = ptrtoint ptr %mem1455 to i64
  store i64 %ptr1456, ptr %slot17, align 8
  %mem1457 = alloca i8, i64 8, align 8
  %ptr1458 = ptrtoint ptr %mem1457 to i64
  store i64 %ptr1458, ptr %slot18, align 8
  %mem1459 = alloca i8, i64 8, align 8
  %ptr1460 = ptrtoint ptr %mem1459 to i64
  store i64 %ptr1460, ptr %slot19, align 8
  %mem1461 = alloca i8, i64 8, align 8
  %ptr1462 = ptrtoint ptr %mem1461 to i64
  store i64 %ptr1462, ptr %slot20, align 8
  %mem1463 = alloca i8, i64 8, align 8
  %ptr1464 = ptrtoint ptr %mem1463 to i64
  store i64 %ptr1464, ptr %slot21, align 8
  %mem1465 = alloca i8, i64 8, align 8
  %ptr1466 = ptrtoint ptr %mem1465 to i64
  store i64 %ptr1466, ptr %slot22, align 8
  %mem1467 = alloca i8, i64 8, align 8
  %ptr1468 = ptrtoint ptr %mem1467 to i64
  store i64 %ptr1468, ptr %slot23, align 8
  %mem1469 = alloca i8, i64 8, align 8
  %ptr1470 = ptrtoint ptr %mem1469 to i64
  store i64 %ptr1470, ptr %slot24, align 8
  %mem1471 = alloca i8, i64 8, align 8
  %ptr1472 = ptrtoint ptr %mem1471 to i64
  store i64 %ptr1472, ptr %slot25, align 8
  %mem1473 = alloca i8, i64 392, align 8
  %ptr1474 = ptrtoint ptr %mem1473 to i64
  store i64 %ptr1474, ptr %slot26, align 8
  %mem1475 = alloca i8, i64 88, align 8
  %ptr1476 = ptrtoint ptr %mem1475 to i64
  store i64 %ptr1476, ptr %slot27, align 8
  %mem1477 = alloca i8, i64 392, align 8
  %ptr1478 = ptrtoint ptr %mem1477 to i64
  store i64 %ptr1478, ptr %slot28, align 8
  %mem1479 = alloca i8, i64 8, align 8
  %ptr1480 = ptrtoint ptr %mem1479 to i64
  store i64 %ptr1480, ptr %slot29, align 8
  %mem1481 = alloca i8, i64 392, align 8
  %ptr1482 = ptrtoint ptr %mem1481 to i64
  store i64 %ptr1482, ptr %slot30, align 8
  %mem1483 = alloca i8, i64 32, align 8
  %ptr1484 = ptrtoint ptr %mem1483 to i64
  store i64 %ptr1484, ptr %slot31, align 8
  %v1485 = load i64, ptr %slot31, align 8
  %p1487 = inttoptr i64 %v1485 to ptr
  %gep1488 = getelementptr i8, ptr %p1487, i64 24
  %op1486 = ptrtoint ptr %gep1488 to i64
  store i64 %op1486, ptr %slot32, align 8
  %v1489 = load i64, ptr %slot32, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i64 0, ptr %p1490, align 8, !alias.scope !3, !noalias !4
  %mem1491 = alloca i8, i64 32, align 8
  %ptr1492 = ptrtoint ptr %mem1491 to i64
  store i64 %ptr1492, ptr %slot33, align 8
  %v1493 = load i64, ptr %slot33, align 8
  %p1495 = inttoptr i64 %v1493 to ptr
  %gep1496 = getelementptr i8, ptr %p1495, i64 24
  %op1494 = ptrtoint ptr %gep1496 to i64
  store i64 %op1494, ptr %slot34, align 8
  %v1497 = load i64, ptr %slot34, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i64 0, ptr %p1498, align 8, !alias.scope !3, !noalias !4
  %mem1499 = alloca i8, i64 16, align 8
  %ptr1500 = ptrtoint ptr %mem1499 to i64
  store i64 %ptr1500, ptr %slot35, align 8
  %mem1501 = alloca i8, i64 8, align 8
  %ptr1502 = ptrtoint ptr %mem1501 to i64
  store i64 %ptr1502, ptr %slot36, align 8
  %mem1503 = alloca i8, i64 8, align 8
  %ptr1504 = ptrtoint ptr %mem1503 to i64
  store i64 %ptr1504, ptr %slot37, align 8
  %mem1505 = alloca i8, i64 24, align 8
  %ptr1506 = ptrtoint ptr %mem1505 to i64
  store i64 %ptr1506, ptr %slot38, align 8
  %mem1507 = alloca i8, i64 8, align 8
  %ptr1508 = ptrtoint ptr %mem1507 to i64
  store i64 %ptr1508, ptr %slot39, align 8
  %mem1509 = alloca i8, i64 8, align 8
  %ptr1510 = ptrtoint ptr %mem1509 to i64
  store i64 %ptr1510, ptr %slot40, align 8
  %mem1511 = alloca i8, i64 8, align 8
  %ptr1512 = ptrtoint ptr %mem1511 to i64
  store i64 %ptr1512, ptr %slot41, align 8
  %mem1513 = alloca i8, i64 8, align 8
  %ptr1514 = ptrtoint ptr %mem1513 to i64
  store i64 %ptr1514, ptr %slot42, align 8
  %mem1515 = alloca i8, i64 88, align 8
  %ptr1516 = ptrtoint ptr %mem1515 to i64
  store i64 %ptr1516, ptr %slot43, align 8
  %mem1517 = alloca i8, i64 88, align 8
  %ptr1518 = ptrtoint ptr %mem1517 to i64
  store i64 %ptr1518, ptr %slot44, align 8
  %mem1519 = alloca i8, i64 24, align 8
  %ptr1520 = ptrtoint ptr %mem1519 to i64
  store i64 %ptr1520, ptr %slot45, align 8
  %mem1521 = alloca i8, i64 8, align 8
  %ptr1522 = ptrtoint ptr %mem1521 to i64
  store i64 %ptr1522, ptr %slot46, align 8
  %mem1523 = alloca i8, i64 88, align 8
  %ptr1524 = ptrtoint ptr %mem1523 to i64
  store i64 %ptr1524, ptr %slot47, align 8
  %mem1525 = alloca i8, i64 8, align 8
  %ptr1526 = ptrtoint ptr %mem1525 to i64
  store i64 %ptr1526, ptr %slot48, align 8
  %mem1527 = alloca i8, i64 8, align 8
  %ptr1528 = ptrtoint ptr %mem1527 to i64
  store i64 %ptr1528, ptr %slot49, align 8
  %mem1529 = alloca i8, i64 56, align 8
  %ptr1530 = ptrtoint ptr %mem1529 to i64
  store i64 %ptr1530, ptr %slot50, align 8
  %mem1531 = alloca i8, i64 8, align 8
  %ptr1532 = ptrtoint ptr %mem1531 to i64
  store i64 %ptr1532, ptr %slot51, align 8
  %mem1533 = alloca i8, i64 8, align 8
  %ptr1534 = ptrtoint ptr %mem1533 to i64
  store i64 %ptr1534, ptr %slot52, align 8
  %mem1535 = alloca i8, i64 8, align 8
  %ptr1536 = ptrtoint ptr %mem1535 to i64
  store i64 %ptr1536, ptr %slot53, align 8
  %mem1537 = alloca i8, i64 8, align 8
  %ptr1538 = ptrtoint ptr %mem1537 to i64
  store i64 %ptr1538, ptr %slot54, align 8
  %mem1539 = alloca i8, i64 88, align 8
  %ptr1540 = ptrtoint ptr %mem1539 to i64
  store i64 %ptr1540, ptr %slot55, align 8
  %mem1541 = alloca i8, i64 88, align 8
  %ptr1542 = ptrtoint ptr %mem1541 to i64
  store i64 %ptr1542, ptr %slot56, align 8
  %mem1543 = alloca i8, i64 56, align 8
  %ptr1544 = ptrtoint ptr %mem1543 to i64
  store i64 %ptr1544, ptr %slot57, align 8
  %mem1545 = alloca i8, i64 56, align 8
  %ptr1546 = ptrtoint ptr %mem1545 to i64
  store i64 %ptr1546, ptr %slot58, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem1547 = alloca i8, i64 8, align 8
  %ptr1548 = ptrtoint ptr %mem1547 to i64
  store i64 %ptr1548, ptr %slot59, align 8
  %v1549 = load i64, ptr %slot1, align 8
  %op1550 = add i64 %v1549, 64
  store i64 %op1550, ptr %slot60, align 8
  %v1551 = load i64, ptr %slot60, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1553, ptr %slot61, align 8
  %stack1554 = call ptr @llvm.stacksave()
  %stackaddr1555 = ptrtoint ptr %stack1554 to i64
  %v1556 = load i64, ptr %slot61, align 8
  %cmp1557 = icmp ult i64 %stackaddr1555, %v1556
  %cv1558 = zext i1 %cmp1557 to i64
  store i64 %cv1558, ptr %slot62, align 8
  %v1559 = load i64, ptr %slot62, align 8
  %cond1560 = icmp ne i64 %v1559, 0
  br i1 %cond1560, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v1561 = load i64, ptr %slot1, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  call void @myl_qbe_fail_frame(ptr %p1562) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %mem1563 = alloca i8, i64 88, align 8
  %ptr1564 = ptrtoint ptr %mem1563 to i64
  store i64 %ptr1564, ptr %slot63, align 8
  %v1565 = load i64, ptr %slot39, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  store i64 0, ptr %p1566, align 8, !alias.scope !3, !noalias !4
  %v1567 = load i64, ptr %slot41, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i64 0, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot46, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i64 0, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot49, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i64 0, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot2, align 8
  %v1574 = load i64, ptr %slot36, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 %v1573, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot3, align 8
  %v1577 = load i64, ptr %slot37, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i64 %v1576, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot1, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  %call1581 = call ptr @myl_qbe_heap(ptr %p1580) nomerge, !dbg !112
  %calladdr1582 = ptrtoint ptr %call1581 to i64
  store i64 %calladdr1582, ptr %slot64, align 8
  %v1583 = load i64, ptr %slot1, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %call1585 = call i64 @myl_qbe_region_mark(ptr %p1584) nomerge, !dbg !112
  store i64 %call1585, ptr %slot65, align 8
  %v1586 = load i64, ptr %slot5, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  store i32 0, ptr %p1587, align 4, !alias.scope !3, !noalias !4
  %v1588 = load i64, ptr %slot6, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i32 0, ptr %p1589, align 4, !alias.scope !3, !noalias !4
  %v1590 = load i64, ptr %slot7, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i32 0, ptr %p1591, align 4, !alias.scope !3, !noalias !4
  %v1592 = load i64, ptr %slot8, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i32 0, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  %v1594 = load i64, ptr %slot9, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  store i32 0, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  %v1596 = load i64, ptr %slot10, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  store i32 0, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  %v1598 = load i64, ptr %slot11, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i32 0, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot12, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i32 0, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot13, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i32 0, ptr %p1603, align 4, !alias.scope !3, !noalias !4
  %v1604 = load i64, ptr %slot14, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i32 0, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot15, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i32 0, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  %v1608 = load i64, ptr %slot16, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  store i32 0, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  %v1610 = load i64, ptr %slot17, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i32 0, ptr %p1611, align 4, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot18, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot19, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot20, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i32 0, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot21, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 0, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot22, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 0, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot23, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot24, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 0, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot25, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 0, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot6, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 2, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot8, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 2, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot10, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  store i32 2, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  %v1634 = load i64, ptr %slot12, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i32 2, ptr %p1635, align 4, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot14, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i32 2, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot16, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 2, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1640 = load i64, ptr %slot36, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  %ld1642 = load i64, ptr %p1641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1642, ptr %slot66, align 8
  %v1643 = load i64, ptr %slot66, align 8
  %v1644 = load i64, ptr %slot52, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  store i64 %v1643, ptr %p1645, align 8, !alias.scope !3, !noalias !4
  %v1646 = load i64, ptr %slot52, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %ld1648 = load i64, ptr %p1647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1648, ptr %slot67, align 8
  %v1649 = load i64, ptr %slot1, align 8
  %v1650 = load i64, ptr %slot67, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult69, i64 %v1649, i64 %v1650) nomerge, !dbg !114
  %addr1651 = ptrtoint ptr %callresult69 to i64
  store i64 %addr1651, ptr %slot68, align 8
  %v1652 = load i64, ptr %slot68, align 8
  %v1653 = load i64, ptr %slot52, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  store i64 %v1652, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  %v1655 = load i64, ptr %slot52, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %ld1657 = load i64, ptr %p1656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1657, ptr %slot70, align 8
  %v1658 = load i64, ptr %slot30, align 8
  store i64 %v1658, ptr %slot71, align 8
  %v1659 = load i64, ptr %slot70, align 8
  %v1660 = load i64, ptr %slot71, align 8
  %p1661 = inttoptr i64 %v1659 to ptr
  %p1662 = inttoptr i64 %v1660 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1662, ptr %p1661, i64 24, i1 false)
  %v1663 = load i64, ptr %slot24, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i32 2, ptr %p1664, align 4, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot23, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  store i32 1, ptr %p1666, align 4, !alias.scope !3, !noalias !4
  %v1667 = load i64, ptr %slot17, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %ld1669 = load i32, ptr %p1668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1669, ptr %slot72, align 8
  %v1670 = load i32, ptr %slot72, align 8
  %cv1671 = zext i32 %v1670 to i64
  %cond1672 = icmp ne i64 %cv1671, 0
  br i1 %cond1672, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v1673 = load i64, ptr %slot17, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  store i32 0, ptr %p1674, align 4, !alias.scope !3, !noalias !4
  %v1675 = load i64, ptr %slot26, align 8
  store i64 %v1675, ptr %slot73, align 8
  %v1676 = load i64, ptr %slot18, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %ld1678 = load i32, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1678, ptr %slot74, align 8
  %v1679 = load i32, ptr %slot74, align 8
  %op1680 = and i32 %v1679, 28
  store i32 %op1680, ptr %slot75, align 8
  %v1681 = load i32, ptr %slot75, align 8
  %cv1682 = zext i32 %v1681 to i64
  %cond1683 = icmp ne i64 %cv1682, 0
  br i1 %cond1683, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v1684 = load i64, ptr %slot64, align 8
  store i64 %v1684, ptr %slot76, align 8
  %v1685 = load i64, ptr %slot76, align 8
  %v1686 = load i64, ptr %slot73, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1685, i64 %v1686) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v1687 = load i64, ptr %slot64, align 8
  store i64 %v1687, ptr %slot77, align 8
  %v1688 = load i64, ptr %slot77, align 8
  %v1689 = load i64, ptr %slot73, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1688, i64 %v1689) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v1690 = load i64, ptr %slot26, align 8
  store i64 %v1690, ptr %slot78, align 8
  %v1691 = load i64, ptr %slot30, align 8
  store i64 %v1691, ptr %slot79, align 8
  %v1692 = load i64, ptr %slot79, align 8
  %v1693 = load i64, ptr %slot78, align 8
  %p1694 = inttoptr i64 %v1692 to ptr
  %p1695 = inttoptr i64 %v1693 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1695, ptr %p1694, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1696 = load i64, ptr %slot18, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i32 2, ptr %p1697, align 4, !alias.scope !3, !noalias !4
  %v1698 = load i64, ptr %slot24, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i32, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1700, ptr %slot80, align 8
  %v1701 = load i32, ptr %slot80, align 8
  %v1702 = load i64, ptr %slot18, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  store i32 %v1701, ptr %p1703, align 4, !alias.scope !3, !noalias !4
  %v1704 = load i64, ptr %slot23, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i32 0, ptr %p1705, align 4, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot17, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  store i32 1, ptr %p1707, align 4, !alias.scope !3, !noalias !4
  %v1708 = load i64, ptr %slot78, align 8
  %v1709 = load i64, ptr %slot52, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i64 %v1708, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot52, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i64, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1713, ptr %slot81, align 8
  %v1714 = load i64, ptr %slot30, align 8
  store i64 %v1714, ptr %slot82, align 8
  %v1715 = load i64, ptr %slot65, align 8
  store i64 %v1715, ptr %slot83, align 8
  %v1716 = load i64, ptr %slot81, align 8
  %op1717 = add i64 %v1716, 0
  store i64 %op1717, ptr %slot84, align 8
  %v1718 = load i64, ptr %slot84, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %ld1720 = load i64, ptr %p1719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1720, ptr %slot85, align 8
  %v1721 = load i64, ptr %slot85, align 8
  %cmp1722 = icmp ne i64 %v1721, 0
  %cv1723 = zext i1 %cmp1722 to i32
  store i32 %cv1723, ptr %slot86, align 8
  %v1724 = load i32, ptr %slot86, align 8
  %cv1725 = zext i32 %v1724 to i64
  %cond1726 = icmp ne i64 %cv1725, 0
  br i1 %cond1726, label %bb_rcmoveheader50, label %bb_rcmovenext50
bb_rcmoveheader50:
  %v1727 = load i64, ptr %slot85, align 8
  %op1728 = sub i64 %v1727, 16
  store i64 %op1728, ptr %slot87, align 8
  %v1729 = load i64, ptr %slot85, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %rgep1731 = getelementptr i8, ptr %p1730, i64 -16
  %ld1732 = load i64, ptr %rgep1731, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1732, ptr %slot88, align 8
  %v1733 = load i64, ptr %slot88, align 8
  %op1734 = and i64 %v1733, 5764607523034234881
  store i64 %op1734, ptr %slot89, align 8
  %v1735 = load i64, ptr %slot89, align 8
  %cmp1736 = icmp ne i64 %v1735, 0
  %cv1737 = zext i1 %cmp1736 to i32
  store i32 %cv1737, ptr %slot90, align 8
  %v1738 = load i32, ptr %slot90, align 8
  %cv1739 = zext i32 %v1738 to i64
  %cond1740 = icmp ne i64 %cv1739, 0
  br i1 %cond1740, label %bb_rcmoveslow47, label %bb_rcmovenext50
bb_rcmovenext50:
  %v1741 = load i64, ptr %slot81, align 8
  %op1742 = add i64 %v1741, 8
  store i64 %op1742, ptr %slot91, align 8
  %v1743 = load i64, ptr %slot91, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot92, align 8
  %v1746 = load i64, ptr %slot92, align 8
  %cmp1747 = icmp ne i64 %v1746, 0
  %cv1748 = zext i1 %cmp1747 to i32
  store i32 %cv1748, ptr %slot93, align 8
  %v1749 = load i32, ptr %slot93, align 8
  %cv1750 = zext i32 %v1749 to i64
  %cond1751 = icmp ne i64 %cv1750, 0
  br i1 %cond1751, label %bb_rcmoveheader58, label %bb_rcmovenext58
bb_rcmoveheader58:
  %v1752 = load i64, ptr %slot92, align 8
  %op1753 = sub i64 %v1752, 16
  store i64 %op1753, ptr %slot94, align 8
  %v1754 = load i64, ptr %slot92, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %rgep1756 = getelementptr i8, ptr %p1755, i64 -16
  %ld1757 = load i64, ptr %rgep1756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1757, ptr %slot95, align 8
  %v1758 = load i64, ptr %slot95, align 8
  %op1759 = and i64 %v1758, 5764607523034234881
  store i64 %op1759, ptr %slot96, align 8
  %v1760 = load i64, ptr %slot96, align 8
  %cmp1761 = icmp ne i64 %v1760, 0
  %cv1762 = zext i1 %cmp1761 to i32
  store i32 %cv1762, ptr %slot97, align 8
  %v1763 = load i32, ptr %slot97, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcmoveslow47, label %bb_rcmovenext58
bb_rcmovenext58:
  %v1766 = load i64, ptr %slot81, align 8
  %op1767 = add i64 %v1766, 16
  store i64 %op1767, ptr %slot98, align 8
  %v1768 = load i64, ptr %slot98, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %ld1770 = load i64, ptr %p1769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1770, ptr %slot99, align 8
  %v1771 = load i64, ptr %slot99, align 8
  %cmp1772 = icmp ne i64 %v1771, 0
  %cv1773 = zext i1 %cmp1772 to i32
  store i32 %cv1773, ptr %slot100, align 8
  %v1774 = load i32, ptr %slot100, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcmoveheader66, label %bb_rcmovenext66
bb_rcmoveheader66:
  %v1777 = load i64, ptr %slot99, align 8
  %op1778 = sub i64 %v1777, 16
  store i64 %op1778, ptr %slot101, align 8
  %v1779 = load i64, ptr %slot99, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %rgep1781 = getelementptr i8, ptr %p1780, i64 -16
  %ld1782 = load i64, ptr %rgep1781, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1782, ptr %slot102, align 8
  %v1783 = load i64, ptr %slot102, align 8
  %op1784 = and i64 %v1783, 5764607523034234881
  store i64 %op1784, ptr %slot103, align 8
  %v1785 = load i64, ptr %slot103, align 8
  %cmp1786 = icmp ne i64 %v1785, 0
  %cv1787 = zext i1 %cmp1786 to i32
  store i32 %cv1787, ptr %slot104, align 8
  %v1788 = load i32, ptr %slot104, align 8
  %cv1789 = zext i32 %v1788 to i64
  %cond1790 = icmp ne i64 %cv1789, 0
  br i1 %cond1790, label %bb_rcmoveslow47, label %bb_rcmovenext66
bb_rcmovenext66:
  %v1791 = load i64, ptr %slot81, align 8
  %v1792 = load i64, ptr %slot82, align 8
  %p1793 = inttoptr i64 %v1791 to ptr
  %p1794 = inttoptr i64 %v1792 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1794, ptr %p1793, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot81, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i64 0, ptr %p1796, align 8, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot81, align 8
  %op1798 = add i64 %v1797, 8
  store i64 %op1798, ptr %slot105, align 8
  %v1799 = load i64, ptr %slot105, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i64 0, ptr %p1800, align 8, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot81, align 8
  %op1802 = add i64 %v1801, 16
  store i64 %op1802, ptr %slot106, align 8
  %v1803 = load i64, ptr %slot106, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i64 0, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved47
bb_rcmoveslow47:
  %v1805 = load i64, ptr %slot64, align 8
  %v1806 = load i64, ptr %slot82, align 8
  %v1807 = load i64, ptr %slot81, align 8
  %v1808 = load i64, ptr %slot83, align 8
  %cv1809 = trunc i64 %v1808 to i32
  %call1810 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v1805, i64 %v1806, i64 %v1807, i32 %cv1809) nomerge, !dbg !116
  store i32 %call1810, ptr %slot107, align 8
  %v1811 = load i32, ptr %slot107, align 8
  %cv1812 = zext i32 %v1811 to i64
  %cond1813 = icmp ne i64 %cv1812, 0
  br i1 %cond1813, label %bb_rcsuccess75, label %bb_rcfailure75
bb_rcfailure75:
  %v1814 = load i64, ptr %slot64, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  %call1816 = call i32 @myl_rc_take_failure(ptr %p1815) nomerge, !dbg !116
  store i32 %call1816, ptr %slot108, align 8
  %v1817 = load i64, ptr %slot1, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  %v1819 = load i32, ptr %slot108, align 8
  %call1820 = call i32 @myl_qbe_rc_status(ptr %p1818, i32 %v1819) nomerge, !dbg !116
  store i32 %call1820, ptr %slot109, align 8
  br label %bb_failure
bb_rcsuccess75:
  br label %bb_rcmoved47
bb_rcmoved47:
  %v1821 = load i64, ptr %slot17, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i32 0, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot24, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  store i32 2, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  %v1825 = load i64, ptr %slot23, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i32 1, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot5, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i32, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1829, ptr %slot110, align 8
  %v1830 = load i32, ptr %slot110, align 8
  %cv1831 = zext i32 %v1830 to i64
  %cond1832 = icmp ne i64 %cv1831, 0
  br i1 %cond1832, label %bb_rcslotdrop84, label %bb_rcslotdone84
bb_rcslotdrop84:
  %v1833 = load i64, ptr %slot5, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i32 0, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  %v1835 = load i64, ptr %slot38, align 8
  store i64 %v1835, ptr %slot111, align 8
  %v1836 = load i64, ptr %slot6, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i32, ptr %p1837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1838, ptr %slot112, align 8
  %v1839 = load i32, ptr %slot112, align 8
  %op1840 = and i32 %v1839, 28
  store i32 %op1840, ptr %slot113, align 8
  %v1841 = load i32, ptr %slot113, align 8
  %cv1842 = zext i32 %v1841 to i64
  %cond1843 = icmp ne i64 %cv1842, 0
  br i1 %cond1843, label %bb_rcslotrole84, label %bb_rcslotowner84
bb_rcslotrole84:
  %v1844 = load i64, ptr %slot64, align 8
  store i64 %v1844, ptr %slot114, align 8
  %v1845 = load i64, ptr %slot114, align 8
  %v1846 = load i64, ptr %slot111, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v1845, i64 %v1846) nomerge, !dbg !116
  br label %bb_rcslotdone84
bb_rcslotowner84:
  %v1847 = load i64, ptr %slot111, align 8
  %p1849 = inttoptr i64 %v1847 to ptr
  %gep1850 = getelementptr i8, ptr %p1849, i64 0
  %op1848 = ptrtoint ptr %gep1850 to i64
  store i64 %op1848, ptr %slot115, align 8
  %v1851 = load i64, ptr %slot64, align 8
  store i64 %v1851, ptr %slot116, align 8
  %v1852 = load i64, ptr %slot115, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i64, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1854, ptr %slot117, align 8
  %v1855 = load i64, ptr %slot117, align 8
  %cmp1856 = icmp ne i64 %v1855, 0
  %cv1857 = zext i1 %cmp1856 to i32
  store i32 %cv1857, ptr %slot118, align 8
  %v1858 = load i32, ptr %slot118, align 8
  %cv1859 = zext i32 %v1858 to i64
  %cond1860 = icmp ne i64 %cv1859, 0
  br i1 %cond1860, label %bb_rcgnn102, label %bb_rcgdone102
bb_rcgnn102:
  %v1861 = load i64, ptr %slot117, align 8
  %op1862 = sub i64 %v1861, 16
  store i64 %op1862, ptr %slot119, align 8
  %v1863 = load i64, ptr %slot117, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %rgep1865 = getelementptr i8, ptr %p1864, i64 -16
  %ld1866 = load i64, ptr %rgep1865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1866, ptr %slot120, align 8
  %v1867 = load i64, ptr %slot120, align 8
  %op1868 = and i64 %v1867, 4611686018427387906
  store i64 %op1868, ptr %slot121, align 8
  %v1869 = load i64, ptr %slot121, align 8
  %cmp1870 = icmp ne i64 %v1869, 0
  %cv1871 = zext i1 %cmp1870 to i32
  store i32 %cv1871, ptr %slot122, align 8
  %v1872 = load i32, ptr %slot122, align 8
  %cv1873 = zext i32 %v1872 to i64
  %cond1874 = icmp ne i64 %cv1873, 0
  br i1 %cond1874, label %bb_rcgclear102, label %bb_rcgcounted102
bb_rcgcounted102:
  %v1875 = load i64, ptr %slot117, align 8
  %op1876 = sub i64 %v1875, 32
  store i64 %op1876, ptr %slot123, align 8
  %v1877 = load i64, ptr %slot117, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -32
  %ld1880 = load i64, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1880, ptr %slot124, align 8
  %v1881 = load i64, ptr %slot124, align 8
  %op1882 = sub i64 %v1881, 1
  store i64 %op1882, ptr %slot125, align 8
  %v1883 = load i64, ptr %slot125, align 8
  %cmp1884 = icmp eq i64 %v1883, 0
  %cv1885 = zext i1 %cmp1884 to i32
  store i32 %cv1885, ptr %slot126, align 8
  %v1886 = load i32, ptr %slot126, align 8
  %cv1887 = zext i32 %v1886 to i64
  %cond1888 = icmp ne i64 %cv1887, 0
  br i1 %cond1888, label %bb_rcglast102, label %bb_rcgdec102
bb_rcglast102:
  %v1889 = load i64, ptr %slot117, align 8
  %op1890 = sub i64 %v1889, 24
  store i64 %op1890, ptr %slot127, align 8
  %v1891 = load i64, ptr %slot117, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %rgep1893 = getelementptr i8, ptr %p1892, i64 -24
  %ld1894 = load i64, ptr %rgep1893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1894, ptr %slot128, align 8
  %v1895 = load i64, ptr %slot128, align 8
  %cmp1896 = icmp ne i64 %v1895, 0
  %cv1897 = zext i1 %cmp1896 to i32
  store i32 %cv1897, ptr %slot129, align 8
  %v1898 = load i32, ptr %slot129, align 8
  %cv1899 = zext i32 %v1898 to i64
  %cond1900 = icmp ne i64 %cv1899, 0
  br i1 %cond1900, label %bb_rcgdec102, label %bb_rcgslow102
bb_rcgslow102:
  %v1901 = load i64, ptr %slot116, align 8
  %v1902 = load i64, ptr %slot115, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1901, i64 %v1902) nomerge, !dbg !116
  br label %bb_rcgdone102
bb_rcgdec102:
  %v1903 = load i64, ptr %slot125, align 8
  %v1904 = load i64, ptr %slot117, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %rgep1906 = getelementptr i8, ptr %p1905, i64 -32
  store i64 %v1903, ptr %rgep1906, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear102
bb_rcgclear102:
  %v1907 = load i64, ptr %slot115, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i64 0, ptr %p1908, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone102
bb_rcgdone102:
  %v1909 = load i64, ptr %slot111, align 8
  %p1911 = inttoptr i64 %v1909 to ptr
  %gep1912 = getelementptr i8, ptr %p1911, i64 8
  %op1910 = ptrtoint ptr %gep1912 to i64
  store i64 %op1910, ptr %slot130, align 8
  %v1913 = load i64, ptr %slot64, align 8
  store i64 %v1913, ptr %slot131, align 8
  %v1914 = load i64, ptr %slot130, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %ld1916 = load i64, ptr %p1915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1916, ptr %slot132, align 8
  %v1917 = load i64, ptr %slot132, align 8
  %cmp1918 = icmp ne i64 %v1917, 0
  %cv1919 = zext i1 %cmp1918 to i32
  store i32 %cv1919, ptr %slot133, align 8
  %v1920 = load i32, ptr %slot133, align 8
  %cv1921 = zext i32 %v1920 to i64
  %cond1922 = icmp ne i64 %cv1921, 0
  br i1 %cond1922, label %bb_rcgnn118, label %bb_rcgdone118
bb_rcgnn118:
  %v1923 = load i64, ptr %slot132, align 8
  %op1924 = sub i64 %v1923, 16
  store i64 %op1924, ptr %slot134, align 8
  %v1925 = load i64, ptr %slot132, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %rgep1927 = getelementptr i8, ptr %p1926, i64 -16
  %ld1928 = load i64, ptr %rgep1927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1928, ptr %slot135, align 8
  %v1929 = load i64, ptr %slot135, align 8
  %op1930 = and i64 %v1929, 4611686018427387906
  store i64 %op1930, ptr %slot136, align 8
  %v1931 = load i64, ptr %slot136, align 8
  %cmp1932 = icmp ne i64 %v1931, 0
  %cv1933 = zext i1 %cmp1932 to i32
  store i32 %cv1933, ptr %slot137, align 8
  %v1934 = load i32, ptr %slot137, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcgclear118, label %bb_rcgcounted118
bb_rcgcounted118:
  %v1937 = load i64, ptr %slot132, align 8
  %op1938 = sub i64 %v1937, 32
  store i64 %op1938, ptr %slot138, align 8
  %v1939 = load i64, ptr %slot132, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  %rgep1941 = getelementptr i8, ptr %p1940, i64 -32
  %ld1942 = load i64, ptr %rgep1941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1942, ptr %slot139, align 8
  %v1943 = load i64, ptr %slot139, align 8
  %op1944 = sub i64 %v1943, 1
  store i64 %op1944, ptr %slot140, align 8
  %v1945 = load i64, ptr %slot140, align 8
  %cmp1946 = icmp eq i64 %v1945, 0
  %cv1947 = zext i1 %cmp1946 to i32
  store i32 %cv1947, ptr %slot141, align 8
  %v1948 = load i32, ptr %slot141, align 8
  %cv1949 = zext i32 %v1948 to i64
  %cond1950 = icmp ne i64 %cv1949, 0
  br i1 %cond1950, label %bb_rcglast118, label %bb_rcgdec118
bb_rcglast118:
  %v1951 = load i64, ptr %slot132, align 8
  %op1952 = sub i64 %v1951, 24
  store i64 %op1952, ptr %slot142, align 8
  %v1953 = load i64, ptr %slot132, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %rgep1955 = getelementptr i8, ptr %p1954, i64 -24
  %ld1956 = load i64, ptr %rgep1955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1956, ptr %slot143, align 8
  %v1957 = load i64, ptr %slot143, align 8
  %cmp1958 = icmp ne i64 %v1957, 0
  %cv1959 = zext i1 %cmp1958 to i32
  store i32 %cv1959, ptr %slot144, align 8
  %v1960 = load i32, ptr %slot144, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcgdec118, label %bb_rcgslow118
bb_rcgslow118:
  %v1963 = load i64, ptr %slot131, align 8
  %v1964 = load i64, ptr %slot130, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1963, i64 %v1964) nomerge, !dbg !116
  br label %bb_rcgdone118
bb_rcgdec118:
  %v1965 = load i64, ptr %slot140, align 8
  %v1966 = load i64, ptr %slot132, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %rgep1968 = getelementptr i8, ptr %p1967, i64 -32
  store i64 %v1965, ptr %rgep1968, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear118
bb_rcgclear118:
  %v1969 = load i64, ptr %slot130, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  store i64 0, ptr %p1970, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone118
bb_rcgdone118:
  %v1971 = load i64, ptr %slot111, align 8
  %p1973 = inttoptr i64 %v1971 to ptr
  %gep1974 = getelementptr i8, ptr %p1973, i64 16
  %op1972 = ptrtoint ptr %gep1974 to i64
  store i64 %op1972, ptr %slot145, align 8
  %v1975 = load i64, ptr %slot64, align 8
  store i64 %v1975, ptr %slot146, align 8
  %v1976 = load i64, ptr %slot145, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %ld1978 = load i64, ptr %p1977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1978, ptr %slot147, align 8
  %v1979 = load i64, ptr %slot147, align 8
  %cmp1980 = icmp ne i64 %v1979, 0
  %cv1981 = zext i1 %cmp1980 to i32
  store i32 %cv1981, ptr %slot148, align 8
  %v1982 = load i32, ptr %slot148, align 8
  %cv1983 = zext i32 %v1982 to i64
  %cond1984 = icmp ne i64 %cv1983, 0
  br i1 %cond1984, label %bb_rcgnn134, label %bb_rcgdone134
bb_rcgnn134:
  %v1985 = load i64, ptr %slot147, align 8
  %op1986 = sub i64 %v1985, 16
  store i64 %op1986, ptr %slot149, align 8
  %v1987 = load i64, ptr %slot147, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %rgep1989 = getelementptr i8, ptr %p1988, i64 -16
  %ld1990 = load i64, ptr %rgep1989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1990, ptr %slot150, align 8
  %v1991 = load i64, ptr %slot150, align 8
  %op1992 = and i64 %v1991, 4611686018427387906
  store i64 %op1992, ptr %slot151, align 8
  %v1993 = load i64, ptr %slot151, align 8
  %cmp1994 = icmp ne i64 %v1993, 0
  %cv1995 = zext i1 %cmp1994 to i32
  store i32 %cv1995, ptr %slot152, align 8
  %v1996 = load i32, ptr %slot152, align 8
  %cv1997 = zext i32 %v1996 to i64
  %cond1998 = icmp ne i64 %cv1997, 0
  br i1 %cond1998, label %bb_rcgclear134, label %bb_rcgcounted134
bb_rcgcounted134:
  %v1999 = load i64, ptr %slot147, align 8
  %op2000 = sub i64 %v1999, 32
  store i64 %op2000, ptr %slot153, align 8
  %v2001 = load i64, ptr %slot147, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %rgep2003 = getelementptr i8, ptr %p2002, i64 -32
  %ld2004 = load i64, ptr %rgep2003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2004, ptr %slot154, align 8
  %v2005 = load i64, ptr %slot154, align 8
  %op2006 = sub i64 %v2005, 1
  store i64 %op2006, ptr %slot155, align 8
  %v2007 = load i64, ptr %slot155, align 8
  %cmp2008 = icmp eq i64 %v2007, 0
  %cv2009 = zext i1 %cmp2008 to i32
  store i32 %cv2009, ptr %slot156, align 8
  %v2010 = load i32, ptr %slot156, align 8
  %cv2011 = zext i32 %v2010 to i64
  %cond2012 = icmp ne i64 %cv2011, 0
  br i1 %cond2012, label %bb_rcglast134, label %bb_rcgdec134
bb_rcglast134:
  %v2013 = load i64, ptr %slot147, align 8
  %op2014 = sub i64 %v2013, 24
  store i64 %op2014, ptr %slot157, align 8
  %v2015 = load i64, ptr %slot147, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  %rgep2017 = getelementptr i8, ptr %p2016, i64 -24
  %ld2018 = load i64, ptr %rgep2017, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2018, ptr %slot158, align 8
  %v2019 = load i64, ptr %slot158, align 8
  %cmp2020 = icmp ne i64 %v2019, 0
  %cv2021 = zext i1 %cmp2020 to i32
  store i32 %cv2021, ptr %slot159, align 8
  %v2022 = load i32, ptr %slot159, align 8
  %cv2023 = zext i32 %v2022 to i64
  %cond2024 = icmp ne i64 %cv2023, 0
  br i1 %cond2024, label %bb_rcgdec134, label %bb_rcgslow134
bb_rcgslow134:
  %v2025 = load i64, ptr %slot146, align 8
  %v2026 = load i64, ptr %slot145, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v2025, i64 %v2026) nomerge, !dbg !116
  br label %bb_rcgdone134
bb_rcgdec134:
  %v2027 = load i64, ptr %slot155, align 8
  %v2028 = load i64, ptr %slot147, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %rgep2030 = getelementptr i8, ptr %p2029, i64 -32
  store i64 %v2027, ptr %rgep2030, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear134
bb_rcgclear134:
  %v2031 = load i64, ptr %slot145, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i64 0, ptr %p2032, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone134
bb_rcgdone134:
  %v2033 = load i64, ptr %slot111, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  store i64 0, ptr %p2034, align 8, !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot111, align 8
  %p2037 = inttoptr i64 %v2035 to ptr
  %gep2038 = getelementptr i8, ptr %p2037, i64 8
  %op2036 = ptrtoint ptr %gep2038 to i64
  store i64 %op2036, ptr %slot160, align 8
  %v2039 = load i64, ptr %slot160, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i64 0, ptr %p2040, align 8, !alias.scope !3, !noalias !4
  %v2041 = load i64, ptr %slot111, align 8
  %p2043 = inttoptr i64 %v2041 to ptr
  %gep2044 = getelementptr i8, ptr %p2043, i64 16
  %op2042 = ptrtoint ptr %gep2044 to i64
  store i64 %op2042, ptr %slot161, align 8
  %v2045 = load i64, ptr %slot161, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  store i64 0, ptr %p2046, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone84
bb_rcslotdone84:
  %v2047 = load i64, ptr %slot38, align 8
  store i64 %v2047, ptr %slot162, align 8
  %v2048 = load i64, ptr %slot30, align 8
  store i64 %v2048, ptr %slot163, align 8
  %v2049 = load i64, ptr %slot163, align 8
  %v2050 = load i64, ptr %slot162, align 8
  %p2051 = inttoptr i64 %v2049 to ptr
  %p2052 = inttoptr i64 %v2050 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2052, ptr %p2051, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2053 = load i64, ptr %slot23, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i32 0, ptr %p2054, align 4, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot6, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i32 2, ptr %p2056, align 4, !alias.scope !3, !noalias !4
  %v2057 = load i64, ptr %slot24, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i32, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2059, ptr %slot164, align 8
  %v2060 = load i32, ptr %slot164, align 8
  %v2061 = load i64, ptr %slot6, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i32 %v2060, ptr %p2062, align 4, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot5, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  store i32 1, ptr %p2064, align 4, !alias.scope !3, !noalias !4
  %v2065 = load i64, ptr %slot38, align 8
  %v2066 = load i64, ptr %slot52, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i64 %v2065, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot37, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %ld2070 = load i64, ptr %p2069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2070, ptr %slot165, align 8
  %v2071 = load i64, ptr %slot165, align 8
  %v2072 = load i64, ptr %slot53, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i64 %v2071, ptr %p2073, align 8, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot36, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i64, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2076, ptr %slot166, align 8
  %v2077 = load i64, ptr %slot166, align 8
  %v2078 = load i64, ptr %slot54, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i64 %v2077, ptr %p2079, align 8, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot54, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %ld2082 = load i64, ptr %p2081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2082, ptr %slot167, align 8
  %v2083 = load i64, ptr %slot167, align 8
  %op2084 = add i64 %v2083, 328
  store i64 %op2084, ptr %slot168, align 8
  %v2085 = load i64, ptr %slot168, align 8
  %v2086 = load i64, ptr %slot54, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i64 %v2085, ptr %p2087, align 8, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot21, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i32, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2090, ptr %slot169, align 8
  %v2091 = load i32, ptr %slot169, align 8
  %cv2092 = zext i32 %v2091 to i64
  %cond2093 = icmp ne i64 %cv2092, 0
  br i1 %cond2093, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v2094 = load i64, ptr %slot21, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 0, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot28, align 8
  store i64 %v2096, ptr %slot170, align 8
  %v2097 = load i64, ptr %slot22, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ld2099 = load i32, ptr %p2098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2099, ptr %slot171, align 8
  %v2100 = load i32, ptr %slot171, align 8
  %op2101 = and i32 %v2100, 28
  store i32 %op2101, ptr %slot172, align 8
  %v2102 = load i32, ptr %slot172, align 8
  %cv2103 = zext i32 %v2102 to i64
  %cond2104 = icmp ne i64 %cv2103, 0
  br i1 %cond2104, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v2105 = load i64, ptr %slot64, align 8
  store i64 %v2105, ptr %slot173, align 8
  %v2106 = load i64, ptr %slot173, align 8
  %v2107 = load i64, ptr %slot170, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2106, i64 %v2107) nomerge, !dbg !118
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v2108 = load i64, ptr %slot64, align 8
  store i64 %v2108, ptr %slot174, align 8
  %v2109 = load i64, ptr %slot174, align 8
  %v2110 = load i64, ptr %slot170, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2109, i64 %v2110) nomerge, !dbg !118
  br label %bb_rcslotdone153
bb_rcslotdone153:
  %v2111 = load i64, ptr %slot54, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot175, align 8
  %v2114 = load i64, ptr %slot175, align 8
  %op2115 = add i64 %v2114, 24
  store i64 %op2115, ptr %slot176, align 8
  %v2116 = load i64, ptr %slot176, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2118, ptr %slot177, align 8
  %v2119 = load i64, ptr %slot177, align 8
  %v2120 = load i64, ptr %slot54, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i64 %v2119, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot21, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i32, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2124, ptr %slot178, align 8
  %v2125 = load i32, ptr %slot178, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcslotdrop165, label %bb_rcslotdone165
bb_rcslotdrop165:
  %v2128 = load i64, ptr %slot21, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i32 0, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot28, align 8
  store i64 %v2130, ptr %slot179, align 8
  %v2131 = load i64, ptr %slot22, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i32, ptr %p2132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2133, ptr %slot180, align 8
  %v2134 = load i32, ptr %slot180, align 8
  %op2135 = and i32 %v2134, 28
  store i32 %op2135, ptr %slot181, align 8
  %v2136 = load i32, ptr %slot181, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcslotrole165, label %bb_rcslotowner165
bb_rcslotrole165:
  %v2139 = load i64, ptr %slot64, align 8
  store i64 %v2139, ptr %slot182, align 8
  %v2140 = load i64, ptr %slot182, align 8
  %v2141 = load i64, ptr %slot179, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2140, i64 %v2141) nomerge, !dbg !120
  br label %bb_rcslotdone165
bb_rcslotowner165:
  %v2142 = load i64, ptr %slot64, align 8
  store i64 %v2142, ptr %slot183, align 8
  %v2143 = load i64, ptr %slot183, align 8
  %v2144 = load i64, ptr %slot179, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2143, i64 %v2144) nomerge, !dbg !120
  br label %bb_rcslotdone165
bb_rcslotdone165:
  %v2145 = load i64, ptr %slot52, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %ld2147 = load i64, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2147, ptr %slot184, align 8
  %v2148 = load i64, ptr %slot53, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  %ld2150 = load i64, ptr %p2149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2150, ptr %slot185, align 8
  %v2151 = load i64, ptr %slot54, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %ld2153 = load i64, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2153, ptr %slot186, align 8
  %v2154 = load i64, ptr %slot1, align 8
  %v2155 = load i64, ptr %slot184, align 8
  %v2156 = load i64, ptr %slot185, align 8
  %v2157 = load i64, ptr %slot186, align 8
  %call2158 = call i64 @myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d(i64 %v2154, i64 %v2155, i64 %v2156, i64 %v2157) nomerge, !dbg !122
  store i64 %call2158, ptr %slot187, align 8
  %v2159 = load i64, ptr %slot187, align 8
  %v2160 = load i64, ptr %slot52, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i64 %v2159, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot17, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  %ld2164 = load i32, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2164, ptr %slot188, align 8
  %v2165 = load i32, ptr %slot188, align 8
  %cv2166 = zext i32 %v2165 to i64
  %cond2167 = icmp ne i64 %cv2166, 0
  br i1 %cond2167, label %bb_rcslotdrop178, label %bb_rcslotdone178
bb_rcslotdrop178:
  %v2168 = load i64, ptr %slot17, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  store i32 0, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  %v2170 = load i64, ptr %slot26, align 8
  store i64 %v2170, ptr %slot189, align 8
  %v2171 = load i64, ptr %slot18, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i32, ptr %p2172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2173, ptr %slot190, align 8
  %v2174 = load i32, ptr %slot190, align 8
  %op2175 = and i32 %v2174, 28
  store i32 %op2175, ptr %slot191, align 8
  %v2176 = load i32, ptr %slot191, align 8
  %cv2177 = zext i32 %v2176 to i64
  %cond2178 = icmp ne i64 %cv2177, 0
  br i1 %cond2178, label %bb_rcslotrole178, label %bb_rcslotowner178
bb_rcslotrole178:
  %v2179 = load i64, ptr %slot64, align 8
  store i64 %v2179, ptr %slot192, align 8
  %v2180 = load i64, ptr %slot192, align 8
  %v2181 = load i64, ptr %slot189, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2180, i64 %v2181) nomerge, !dbg !122
  br label %bb_rcslotdone178
bb_rcslotowner178:
  %v2182 = load i64, ptr %slot64, align 8
  store i64 %v2182, ptr %slot193, align 8
  %v2183 = load i64, ptr %slot193, align 8
  %v2184 = load i64, ptr %slot189, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v2183, i64 %v2184) nomerge, !dbg !122
  br label %bb_rcslotdone178
bb_rcslotdone178:
  %v2185 = load i64, ptr %slot36, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot194, align 8
  %v2188 = load i64, ptr %slot194, align 8
  %v2189 = load i64, ptr %slot52, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i64 %v2188, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  %v2191 = load i64, ptr %slot52, align 8
  %p2192 = inttoptr i64 %v2191 to ptr
  %ld2193 = load i64, ptr %p2192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2193, ptr %slot195, align 8
  %v2194 = load i64, ptr %slot195, align 8
  %op2195 = add i64 %v2194, 376
  store i64 %op2195, ptr %slot196, align 8
  %v2196 = load i64, ptr %slot196, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %ld2198 = load i64, ptr %p2197, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2198, ptr %slot197, align 8
  %v2199 = load i64, ptr %slot197, align 8
  %v2200 = load i64, ptr %slot52, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i64 %v2199, ptr %p2201, align 8, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot17, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i32, ptr %p2203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2204, ptr %slot198, align 8
  %v2205 = load i32, ptr %slot198, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v2208 = load i64, ptr %slot17, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  store i32 0, ptr %p2209, align 4, !alias.scope !3, !noalias !4
  %v2210 = load i64, ptr %slot26, align 8
  store i64 %v2210, ptr %slot199, align 8
  %v2211 = load i64, ptr %slot18, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  %ld2213 = load i32, ptr %p2212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2213, ptr %slot200, align 8
  %v2214 = load i32, ptr %slot200, align 8
  %op2215 = and i32 %v2214, 28
  store i32 %op2215, ptr %slot201, align 8
  %v2216 = load i32, ptr %slot201, align 8
  %cv2217 = zext i32 %v2216 to i64
  %cond2218 = icmp ne i64 %cv2217, 0
  br i1 %cond2218, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v2219 = load i64, ptr %slot64, align 8
  store i64 %v2219, ptr %slot202, align 8
  %v2220 = load i64, ptr %slot202, align 8
  %v2221 = load i64, ptr %slot199, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2220, i64 %v2221) nomerge, !dbg !124
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v2222 = load i64, ptr %slot64, align 8
  store i64 %v2222, ptr %slot203, align 8
  %v2223 = load i64, ptr %slot203, align 8
  %v2224 = load i64, ptr %slot199, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2223, i64 %v2224) nomerge, !dbg !124
  br label %bb_rcslotdone191
bb_rcslotdone191:
  %v2225 = load i64, ptr %slot52, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  %ld2227 = load i64, ptr %p2226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2227, ptr %slot204, align 8
  %v2228 = load i64, ptr %slot204, align 8
  %v2229 = load i64, ptr %slot39, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  store i64 %v2228, ptr %p2230, align 8, !alias.scope !3, !noalias !4
  %v2231 = load i64, ptr %slot39, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %ld2233 = load i64, ptr %p2232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2233, ptr %slot205, align 8
  %v2234 = load i64, ptr %slot205, align 8
  %op2235 = add i64 %v2234, 0
  store i64 %op2235, ptr %slot206, align 8
  %v2236 = load i64, ptr %slot206, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %ld2238 = load i64, ptr %p2237, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2238, ptr %slot207, align 8
  %v2239 = load i64, ptr %slot207, align 8
  %v2240 = load i64, ptr %slot52, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i64 %v2239, ptr %p2241, align 8, !alias.scope !3, !noalias !4
  %v2242 = load i64, ptr %slot52, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %ld2244 = load i64, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2244, ptr %slot208, align 8
  %v2245 = load i64, ptr %slot208, align 8
  %cmp2246 = icmp ugt i64 %v2245, 9223372036854775807
  %cv2247 = zext i1 %cmp2246 to i64
  store i64 %cv2247, ptr %slot209, align 8
  %v2248 = load i64, ptr %slot209, align 8
  %cond2249 = icmp ne i64 %v2248, 0
  br i1 %cond2249, label %bb_cast_overflow204, label %bb_cast_ok204
bb_cast_overflow204:
  %v2250 = load i64, ptr %slot1, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %v2252 = load i64, ptr %slot208, align 8
  call void @myl_qbe_fail_cast(ptr %p2251, i64 %v2252, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok204:
  %v2253 = load i64, ptr %slot208, align 8
  %v2254 = load i64, ptr %slot52, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 %v2253, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot53, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i64 1, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot53, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i64, ptr %p2259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2260, ptr %slot210, align 8
  %v2261 = load i64, ptr %slot52, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %ld2263 = load i64, ptr %p2262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2263, ptr %slot211, align 8
  %v2264 = load i64, ptr %slot211, align 8
  %v2265 = load i64, ptr %slot210, align 8
  %ovpair2267 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2264, i64 %v2265)
  %op2266 = extractvalue { i64, i1 } %ovpair2267, 0
  %ov2268 = extractvalue { i64, i1 } %ovpair2267, 1
  store i64 %op2266, ptr %slot212, align 8
  %cv2269 = zext i1 %ov2268 to i64
  store i64 %cv2269, ptr %slot213, align 8
  %v2270 = load i64, ptr %slot213, align 8
  %cond2271 = icmp ne i64 %v2270, 0
  br i1 %cond2271, label %bb_overflow207, label %bb_checked207
bb_overflow207:
  %v2272 = load i64, ptr %slot1, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  %v2274 = load i64, ptr %slot211, align 8
  %v2275 = load i64, ptr %slot210, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2273, i64 1, i64 %v2274, i64 %v2275, i64 64) nomerge, !dbg !128
  unreachable
bb_checked207:
  %v2276 = load i64, ptr %slot212, align 8
  %v2277 = load i64, ptr %slot52, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i64 %v2276, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot52, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %ld2281 = load i64, ptr %p2280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2281, ptr %slot214, align 8
  %v2282 = load i64, ptr %slot214, align 8
  %v2283 = load i64, ptr %slot40, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i64 %v2282, ptr %p2284, align 8, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot36, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %ld2287 = load i64, ptr %p2286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2287, ptr %slot215, align 8
  %v2288 = load i64, ptr %slot215, align 8
  %v2289 = load i64, ptr %slot52, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i64 %v2288, ptr %p2290, align 8, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot52, align 8
  %p2292 = inttoptr i64 %v2291 to ptr
  %ld2293 = load i64, ptr %p2292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2293, ptr %slot216, align 8
  %v2294 = load i64, ptr %slot216, align 8
  %op2295 = add i64 %v2294, 376
  store i64 %op2295, ptr %slot217, align 8
  %v2296 = load i64, ptr %slot217, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i64, ptr %p2297, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2298, ptr %slot218, align 8
  %v2299 = load i64, ptr %slot218, align 8
  %v2300 = load i64, ptr %slot52, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  store i64 %v2299, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  %v2302 = load i64, ptr %slot17, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %ld2304 = load i32, ptr %p2303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2304, ptr %slot219, align 8
  %v2305 = load i32, ptr %slot219, align 8
  %cv2306 = zext i32 %v2305 to i64
  %cond2307 = icmp ne i64 %cv2306, 0
  br i1 %cond2307, label %bb_rcslotdrop216, label %bb_rcslotdone216
bb_rcslotdrop216:
  %v2308 = load i64, ptr %slot17, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  store i32 0, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  %v2310 = load i64, ptr %slot26, align 8
  store i64 %v2310, ptr %slot220, align 8
  %v2311 = load i64, ptr %slot18, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i32, ptr %p2312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2313, ptr %slot221, align 8
  %v2314 = load i32, ptr %slot221, align 8
  %op2315 = and i32 %v2314, 28
  store i32 %op2315, ptr %slot222, align 8
  %v2316 = load i32, ptr %slot222, align 8
  %cv2317 = zext i32 %v2316 to i64
  %cond2318 = icmp ne i64 %cv2317, 0
  br i1 %cond2318, label %bb_rcslotrole216, label %bb_rcslotowner216
bb_rcslotrole216:
  %v2319 = load i64, ptr %slot64, align 8
  store i64 %v2319, ptr %slot223, align 8
  %v2320 = load i64, ptr %slot223, align 8
  %v2321 = load i64, ptr %slot220, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2320, i64 %v2321) nomerge, !dbg !130
  br label %bb_rcslotdone216
bb_rcslotowner216:
  %v2322 = load i64, ptr %slot64, align 8
  store i64 %v2322, ptr %slot224, align 8
  %v2323 = load i64, ptr %slot224, align 8
  %v2324 = load i64, ptr %slot220, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2323, i64 %v2324) nomerge, !dbg !130
  br label %bb_rcslotdone216
bb_rcslotdone216:
  %v2325 = load i64, ptr %slot52, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %ld2327 = load i64, ptr %p2326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2327, ptr %slot225, align 8
  %v2328 = load i64, ptr %slot225, align 8
  %v2329 = load i64, ptr %slot41, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  store i64 %v2328, ptr %p2330, align 8, !alias.scope !3, !noalias !4
  %v2331 = load i64, ptr %slot40, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i64, ptr %p2332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2333, ptr %slot226, align 8
  %v2334 = load i64, ptr %slot226, align 8
  %v2335 = load i64, ptr %slot52, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i64 %v2334, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  %v2337 = load i64, ptr %slot52, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  %ld2339 = load i64, ptr %p2338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2339, ptr %slot227, align 8
  %v2340 = load i64, ptr %slot227, align 8
  %v2341 = load i64, ptr %slot42, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i64 %v2340, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot42, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i64, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2345, ptr %slot228, align 8
  %v2346 = load i64, ptr %slot228, align 8
  %v2347 = load i64, ptr %slot52, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  store i64 %v2346, ptr %p2348, align 8, !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot53, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 0, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot53, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i64, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2353, ptr %slot229, align 8
  %v2354 = load i64, ptr %slot52, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %ld2356 = load i64, ptr %p2355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2356, ptr %slot230, align 8
  %v2357 = load i64, ptr %slot230, align 8
  %v2358 = load i64, ptr %slot229, align 8
  %cmp2359 = icmp slt i64 %v2357, %v2358
  %cv2360 = zext i1 %cmp2359 to i64
  store i64 %cv2360, ptr %slot231, align 8
  %v2361 = load i64, ptr %slot231, align 8
  %v2362 = load i64, ptr %slot52, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  store i64 %v2361, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  %v2364 = load i64, ptr %slot52, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %ld2366 = load i64, ptr %p2365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2366, ptr %slot232, align 8
  %v2367 = load i64, ptr %slot232, align 8
  %cond2368 = icmp ne i64 %v2367, 0
  br i1 %cond2368, label %bb_next231, label %bb_i32
bb_next231:
  %v2369 = load i64, ptr %slot41, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  %ld2371 = load i64, ptr %p2370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2371, ptr %slot233, align 8
  %v2372 = load i64, ptr %slot233, align 8
  %op2373 = add i64 %v2372, 0
  store i64 %op2373, ptr %slot234, align 8
  %v2374 = load i64, ptr %slot234, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %ld2376 = load i64, ptr %p2375, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2376, ptr %slot235, align 8
  %v2377 = load i64, ptr %slot235, align 8
  %v2378 = load i64, ptr %slot52, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  store i64 %v2377, ptr %p2379, align 8, !alias.scope !3, !noalias !4
  %v2380 = load i64, ptr %slot52, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i64, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2382, ptr %slot236, align 8
  %v2383 = load i64, ptr %slot236, align 8
  %cmp2384 = icmp ugt i64 %v2383, 9223372036854775807
  %cv2385 = zext i1 %cmp2384 to i64
  store i64 %cv2385, ptr %slot237, align 8
  %v2386 = load i64, ptr %slot237, align 8
  %cond2387 = icmp ne i64 %v2386, 0
  br i1 %cond2387, label %bb_cast_overflow236, label %bb_cast_ok236
bb_cast_overflow236:
  %v2388 = load i64, ptr %slot1, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  %v2390 = load i64, ptr %slot236, align 8
  call void @myl_qbe_fail_cast(ptr %p2389, i64 %v2390, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok236:
  %v2391 = load i64, ptr %slot236, align 8
  %v2392 = load i64, ptr %slot52, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i64 %v2391, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot42, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2396, ptr %slot238, align 8
  %v2397 = load i64, ptr %slot238, align 8
  %v2398 = load i64, ptr %slot53, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot53, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot239, align 8
  %v2403 = load i64, ptr %slot52, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %ld2405 = load i64, ptr %p2404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2405, ptr %slot240, align 8
  %v2406 = load i64, ptr %slot240, align 8
  %v2407 = load i64, ptr %slot239, align 8
  %ovpair2409 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2406, i64 %v2407)
  %op2408 = extractvalue { i64, i1 } %ovpair2409, 0
  %ov2410 = extractvalue { i64, i1 } %ovpair2409, 1
  store i64 %op2408, ptr %slot241, align 8
  %v2411 = load i64, ptr %slot240, align 8
  %v2412 = load i64, ptr %slot241, align 8
  %op2413 = xor i64 %v2411, %v2412
  store i64 %op2413, ptr %slot242, align 8
  %v2414 = load i64, ptr %slot239, align 8
  %v2415 = load i64, ptr %slot241, align 8
  %op2416 = xor i64 %v2414, %v2415
  store i64 %op2416, ptr %slot243, align 8
  %v2417 = load i64, ptr %slot242, align 8
  %v2418 = load i64, ptr %slot243, align 8
  %op2419 = and i64 %v2417, %v2418
  store i64 %op2419, ptr %slot244, align 8
  %cv2420 = zext i1 %ov2410 to i64
  store i64 %cv2420, ptr %slot245, align 8
  %v2421 = load i64, ptr %slot245, align 8
  %cond2422 = icmp ne i64 %v2421, 0
  br i1 %cond2422, label %bb_overflow240, label %bb_checked240
bb_overflow240:
  %v2423 = load i64, ptr %slot1, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %v2425 = load i64, ptr %slot240, align 8
  %v2426 = load i64, ptr %slot239, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2424, i64 0, i64 %v2425, i64 %v2426, i64 64) nomerge, !dbg !134
  unreachable
bb_checked240:
  %v2427 = load i64, ptr %slot241, align 8
  %v2428 = load i64, ptr %slot52, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  store i64 %v2427, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  %v2430 = load i64, ptr %slot52, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i64, ptr %p2431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2432, ptr %slot246, align 8
  %v2433 = load i64, ptr %slot246, align 8
  %v2434 = load i64, ptr %slot42, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  store i64 %v2433, ptr %p2435, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_i32:
  %v2436 = load i64, ptr %slot42, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %ld2438 = load i64, ptr %p2437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2438, ptr %slot247, align 8
  %v2439 = load i64, ptr %slot247, align 8
  %v2440 = load i64, ptr %slot52, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  store i64 %v2439, ptr %p2441, align 8, !alias.scope !3, !noalias !4
  %v2442 = load i64, ptr %slot41, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %ld2444 = load i64, ptr %p2443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2444, ptr %slot248, align 8
  %v2445 = load i64, ptr %slot52, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  %ld2447 = load i64, ptr %p2446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2447, ptr %slot249, align 8
  %v2448 = load i64, ptr %slot248, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %ld2450 = load i64, ptr %p2449, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2450, ptr %slot250, align 8
  %v2451 = load i64, ptr %slot249, align 8
  %v2452 = load i64, ptr %slot250, align 8
  %cmp2453 = icmp ult i64 %v2451, %v2452
  %cv2454 = zext i1 %cmp2453 to i64
  store i64 %cv2454, ptr %slot251, align 8
  %v2455 = load i64, ptr %slot251, align 8
  %cond2456 = icmp ne i64 %v2455, 0
  br i1 %cond2456, label %bb_success252, label %bb_failed252
bb_failed252:
  %v2457 = load i64, ptr %slot1, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %v2459 = load i64, ptr %slot249, align 8
  %v2460 = load i64, ptr %slot250, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2458, i64 %v2459, i64 %v2460) nomerge, !dbg !136
  unreachable
bb_success252:
  %v2461 = load i64, ptr %slot248, align 8
  %op2462 = add i64 %v2461, 32
  store i64 %op2462, ptr %slot252, align 8
  %v2463 = load i64, ptr %slot252, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %ld2465 = load i64, ptr %p2464, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2465, ptr %slot253, align 8
  %v2466 = load i64, ptr %slot249, align 8
  %op2467 = mul i64 %v2466, 88
  store i64 %op2467, ptr %slot254, align 8
  %v2468 = load i64, ptr %slot253, align 8
  %v2469 = load i64, ptr %slot254, align 8
  %op2470 = add i64 %v2468, %v2469
  store i64 %op2470, ptr %slot255, align 8
  %v2471 = load i64, ptr %slot63, align 8
  store i64 %v2471, ptr %slot256, align 8
  %v2472 = load i64, ptr %slot255, align 8
  %v2473 = load i64, ptr %slot256, align 8
  %p2474 = inttoptr i64 %v2472 to ptr
  %p2475 = inttoptr i64 %v2473 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2475, ptr %p2474, i64 88, i1 false), !alias.scope !10000000
  %v2476 = load i64, ptr %slot256, align 8
  %v2477 = load i64, ptr %slot52, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  store i64 %v2476, ptr %p2478, align 8, !alias.scope !3, !noalias !4
  %v2479 = load i64, ptr %slot52, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  %ld2481 = load i64, ptr %p2480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2481, ptr %slot257, align 8
  %v2482 = load i64, ptr %slot30, align 8
  store i64 %v2482, ptr %slot258, align 8
  %v2483 = load i64, ptr %slot64, align 8
  %v2484 = load i64, ptr %slot258, align 8
  %v2485 = load i64, ptr %slot257, align 8
  %call2486 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v2483, i64 %v2484, i64 %v2485) nomerge, !dbg !136
  store i32 %call2486, ptr %slot259, align 8
  %v2487 = load i32, ptr %slot259, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcsuccess261, label %bb_rcfailure261
bb_rcfailure261:
  %v2490 = load i64, ptr %slot64, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %call2492 = call i32 @myl_rc_take_failure(ptr %p2491) nomerge, !dbg !136
  store i32 %call2492, ptr %slot260, align 8
  %v2493 = load i64, ptr %slot1, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %v2495 = load i32, ptr %slot260, align 8
  %call2496 = call i32 @myl_qbe_rc_status(ptr %p2494, i32 %v2495) nomerge, !dbg !136
  store i32 %call2496, ptr %slot261, align 8
  br label %bb_failure
bb_rcsuccess261:
  %v2497 = load i64, ptr %slot24, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i32 2, ptr %p2498, align 4, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot24, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  store i32 16, ptr %p2500, align 4, !alias.scope !3, !noalias !4
  %v2501 = load i64, ptr %slot23, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  store i32 1, ptr %p2502, align 4, !alias.scope !3, !noalias !4
  %v2503 = load i64, ptr %slot26, align 8
  store i64 %v2503, ptr %slot262, align 8
  %v2504 = load i64, ptr %slot30, align 8
  store i64 %v2504, ptr %slot263, align 8
  %v2505 = load i64, ptr %slot263, align 8
  %v2506 = load i64, ptr %slot262, align 8
  %p2507 = inttoptr i64 %v2505 to ptr
  %p2508 = inttoptr i64 %v2506 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2508, ptr %p2507, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2509 = load i64, ptr %slot18, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i32 2, ptr %p2510, align 4, !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot24, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %ld2513 = load i32, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2513, ptr %slot264, align 8
  %v2514 = load i32, ptr %slot264, align 8
  %v2515 = load i64, ptr %slot18, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  store i32 %v2514, ptr %p2516, align 4, !alias.scope !3, !noalias !4
  %v2517 = load i64, ptr %slot23, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 0, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot17, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 1, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot262, align 8
  %v2522 = load i64, ptr %slot52, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i64 %v2521, ptr %p2523, align 8, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot52, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %ld2526 = load i64, ptr %p2525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2526, ptr %slot265, align 8
  %v2527 = load i64, ptr %slot17, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  %ld2529 = load i32, ptr %p2528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2529, ptr %slot266, align 8
  %v2530 = load i64, ptr %slot18, align 8
  %p2531 = inttoptr i64 %v2530 to ptr
  %ld2532 = load i32, ptr %p2531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2532, ptr %slot267, align 8
  %v2533 = load i32, ptr %slot267, align 8
  %op2534 = and i32 %v2533, 24
  store i32 %op2534, ptr %slot267, align 8
  %v2535 = load i32, ptr %slot267, align 8
  %cmp2536 = icmp eq i32 %v2535, 0
  %cv2537 = zext i1 %cmp2536 to i32
  store i32 %cv2537, ptr %slot268, align 8
  %v2538 = load i32, ptr %slot266, align 8
  %v2539 = load i32, ptr %slot268, align 8
  %op2540 = and i32 %v2538, %v2539
  store i32 %op2540, ptr %slot269, align 8
  %v2541 = load i64, ptr %slot65, align 8
  store i64 %v2541, ptr %slot270, align 8
  %v2542 = load i32, ptr %slot269, align 8
  %op2543 = mul i32 %v2542, 4
  store i32 %op2543, ptr %slot271, align 8
  %v2544 = load i32, ptr %slot271, align 8
  %op2545 = or i32 %v2544, 0
  store i32 %op2545, ptr %slot272, align 8
  %v2546 = load i64, ptr %slot30, align 8
  store i64 %v2546, ptr %slot273, align 8
  %v2547 = load i64, ptr %slot64, align 8
  %v2548 = load i64, ptr %slot273, align 8
  %v2549 = load i64, ptr %slot265, align 8
  %v2550 = load i64, ptr %slot270, align 8
  %cv2551 = trunc i64 %v2550 to i32
  %v2552 = load i32, ptr %slot272, align 8
  %call2553 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v2547, i64 %v2548, i64 %v2549, i32 %cv2551, i32 %v2552) nomerge, !dbg !138
  store i32 %call2553, ptr %slot274, align 8
  %v2554 = load i32, ptr %slot274, align 8
  %cv2555 = zext i32 %v2554 to i64
  %cond2556 = icmp ne i64 %cv2555, 0
  br i1 %cond2556, label %bb_rcsuccess289, label %bb_rcfailure289
bb_rcfailure289:
  %v2557 = load i64, ptr %slot64, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  %call2559 = call i32 @myl_rc_take_failure(ptr %p2558) nomerge, !dbg !138
  store i32 %call2559, ptr %slot275, align 8
  %v2560 = load i64, ptr %slot1, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %v2562 = load i32, ptr %slot275, align 8
  %call2563 = call i32 @myl_qbe_rc_status(ptr %p2561, i32 %v2562) nomerge, !dbg !138
  store i32 %call2563, ptr %slot276, align 8
  br label %bb_failure
bb_rcsuccess289:
  %v2564 = load i32, ptr %slot269, align 8
  %cv2565 = zext i32 %v2564 to i64
  %cond2566 = icmp ne i64 %cv2565, 0
  br i1 %cond2566, label %bb_rchtaken292, label %bb_rchcopied292
bb_rchcopied292:
  %v2567 = load i64, ptr %slot17, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  %ld2569 = load i32, ptr %p2568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2569, ptr %slot277, align 8
  %v2570 = load i32, ptr %slot277, align 8
  %cv2571 = zext i32 %v2570 to i64
  %cond2572 = icmp ne i64 %cv2571, 0
  br i1 %cond2572, label %bb_rcslotdrop295, label %bb_rcslotdone295
bb_rcslotdrop295:
  %v2573 = load i64, ptr %slot17, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  store i32 0, ptr %p2574, align 4, !alias.scope !3, !noalias !4
  %v2575 = load i64, ptr %slot26, align 8
  store i64 %v2575, ptr %slot278, align 8
  %v2576 = load i64, ptr %slot18, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i32, ptr %p2577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2578, ptr %slot279, align 8
  %v2579 = load i32, ptr %slot279, align 8
  %op2580 = and i32 %v2579, 28
  store i32 %op2580, ptr %slot280, align 8
  %v2581 = load i32, ptr %slot280, align 8
  %cv2582 = zext i32 %v2581 to i64
  %cond2583 = icmp ne i64 %cv2582, 0
  br i1 %cond2583, label %bb_rcslotrole295, label %bb_rcslotowner295
bb_rcslotrole295:
  %v2584 = load i64, ptr %slot64, align 8
  store i64 %v2584, ptr %slot281, align 8
  %v2585 = load i64, ptr %slot281, align 8
  %v2586 = load i64, ptr %slot278, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2585, i64 %v2586) nomerge, !dbg !138
  br label %bb_rcslotdone295
bb_rcslotowner295:
  %v2587 = load i64, ptr %slot64, align 8
  store i64 %v2587, ptr %slot282, align 8
  %v2588 = load i64, ptr %slot282, align 8
  %v2589 = load i64, ptr %slot278, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2588, i64 %v2589) nomerge, !dbg !138
  br label %bb_rcslotdone295
bb_rcslotdone295:
  br label %bb_rchprepared292
bb_rchtaken292:
  %v2590 = load i64, ptr %slot17, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  store i32 0, ptr %p2591, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared292
bb_rchprepared292:
  %v2592 = load i64, ptr %slot24, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  store i32 2, ptr %p2593, align 4, !alias.scope !3, !noalias !4
  %v2594 = load i64, ptr %slot23, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  store i32 1, ptr %p2595, align 4, !alias.scope !3, !noalias !4
  %v2596 = load i64, ptr %slot26, align 8
  store i64 %v2596, ptr %slot283, align 8
  %v2597 = load i64, ptr %slot30, align 8
  store i64 %v2597, ptr %slot284, align 8
  %v2598 = load i64, ptr %slot284, align 8
  %v2599 = load i64, ptr %slot283, align 8
  %p2600 = inttoptr i64 %v2598 to ptr
  %p2601 = inttoptr i64 %v2599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2601, ptr %p2600, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot18, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  store i32 2, ptr %p2603, align 4, !alias.scope !3, !noalias !4
  %v2604 = load i64, ptr %slot24, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i32, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2606, ptr %slot285, align 8
  %v2607 = load i32, ptr %slot285, align 8
  %v2608 = load i64, ptr %slot18, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i32 %v2607, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot23, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 0, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot17, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i32 1, ptr %p2613, align 4, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot283, align 8
  %v2615 = load i64, ptr %slot52, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i64 %v2614, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot52, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %ld2619 = load i64, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2619, ptr %slot286, align 8
  %v2620 = load i64, ptr %slot30, align 8
  store i64 %v2620, ptr %slot287, align 8
  %v2621 = load i64, ptr %slot65, align 8
  store i64 %v2621, ptr %slot288, align 8
  %v2622 = load i64, ptr %slot64, align 8
  %v2623 = load i64, ptr %slot287, align 8
  %v2624 = load i64, ptr %slot286, align 8
  %v2625 = load i64, ptr %slot288, align 8
  %cv2626 = trunc i64 %v2625 to i32
  %call2627 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2622, i64 %v2623, i64 %v2624, i32 %cv2626) nomerge, !dbg !140
  store i32 %call2627, ptr %slot289, align 8
  %v2628 = load i32, ptr %slot289, align 8
  %cv2629 = zext i32 %v2628 to i64
  %cond2630 = icmp ne i64 %cv2629, 0
  br i1 %cond2630, label %bb_rcsuccess317, label %bb_rcfailure317
bb_rcfailure317:
  %v2631 = load i64, ptr %slot64, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %call2633 = call i32 @myl_rc_take_failure(ptr %p2632) nomerge, !dbg !140
  store i32 %call2633, ptr %slot290, align 8
  %v2634 = load i64, ptr %slot1, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %v2636 = load i32, ptr %slot290, align 8
  %call2637 = call i32 @myl_qbe_rc_status(ptr %p2635, i32 %v2636) nomerge, !dbg !140
  store i32 %call2637, ptr %slot291, align 8
  br label %bb_failure
bb_rcsuccess317:
  %v2638 = load i64, ptr %slot17, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  store i32 0, ptr %p2639, align 4, !alias.scope !3, !noalias !4
  %v2640 = load i64, ptr %slot24, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  store i32 2, ptr %p2641, align 4, !alias.scope !3, !noalias !4
  %v2642 = load i64, ptr %slot23, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  store i32 1, ptr %p2643, align 4, !alias.scope !3, !noalias !4
  %v2644 = load i64, ptr %slot7, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  %ld2646 = load i32, ptr %p2645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2646, ptr %slot292, align 8
  %v2647 = load i32, ptr %slot292, align 8
  %cv2648 = zext i32 %v2647 to i64
  %cond2649 = icmp ne i64 %cv2648, 0
  br i1 %cond2649, label %bb_rcslotdrop326, label %bb_rcslotdone326
bb_rcslotdrop326:
  %v2650 = load i64, ptr %slot7, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i32 0, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot43, align 8
  store i64 %v2652, ptr %slot293, align 8
  %v2653 = load i64, ptr %slot8, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  %ld2655 = load i32, ptr %p2654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2655, ptr %slot294, align 8
  %v2656 = load i32, ptr %slot294, align 8
  %op2657 = and i32 %v2656, 28
  store i32 %op2657, ptr %slot295, align 8
  %v2658 = load i32, ptr %slot295, align 8
  %cv2659 = zext i32 %v2658 to i64
  %cond2660 = icmp ne i64 %cv2659, 0
  br i1 %cond2660, label %bb_rcslotrole326, label %bb_rcslotowner326
bb_rcslotrole326:
  %v2661 = load i64, ptr %slot64, align 8
  store i64 %v2661, ptr %slot296, align 8
  %v2662 = load i64, ptr %slot296, align 8
  %v2663 = load i64, ptr %slot293, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2662, i64 %v2663) nomerge, !dbg !140
  br label %bb_rcslotdone326
bb_rcslotowner326:
  %v2664 = load i64, ptr %slot64, align 8
  store i64 %v2664, ptr %slot297, align 8
  %v2665 = load i64, ptr %slot297, align 8
  %v2666 = load i64, ptr %slot293, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2665, i64 %v2666) nomerge, !dbg !140
  br label %bb_rcslotdone326
bb_rcslotdone326:
  %v2667 = load i64, ptr %slot43, align 8
  store i64 %v2667, ptr %slot298, align 8
  %v2668 = load i64, ptr %slot30, align 8
  store i64 %v2668, ptr %slot299, align 8
  %v2669 = load i64, ptr %slot299, align 8
  %v2670 = load i64, ptr %slot298, align 8
  %p2671 = inttoptr i64 %v2669 to ptr
  %p2672 = inttoptr i64 %v2670 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2672, ptr %p2671, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot23, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  store i32 0, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  %v2675 = load i64, ptr %slot8, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i32 2, ptr %p2676, align 4, !alias.scope !3, !noalias !4
  %v2677 = load i64, ptr %slot24, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  %ld2679 = load i32, ptr %p2678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2679, ptr %slot300, align 8
  %v2680 = load i32, ptr %slot300, align 8
  %v2681 = load i64, ptr %slot8, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  store i32 %v2680, ptr %p2682, align 4, !alias.scope !3, !noalias !4
  %v2683 = load i64, ptr %slot7, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i32 1, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot38, align 8
  %v2686 = load i64, ptr %slot52, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  store i64 %v2685, ptr %p2687, align 8, !alias.scope !3, !noalias !4
  %v2688 = load i64, ptr %slot52, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %ld2690 = load i64, ptr %p2689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2690, ptr %slot301, align 8
  %v2691 = load i64, ptr %slot17, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %ld2693 = load i32, ptr %p2692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2693, ptr %slot302, align 8
  %v2694 = load i64, ptr %slot18, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i32, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2696, ptr %slot303, align 8
  %v2697 = load i32, ptr %slot303, align 8
  %op2698 = and i32 %v2697, 24
  store i32 %op2698, ptr %slot303, align 8
  %v2699 = load i32, ptr %slot303, align 8
  %cmp2700 = icmp eq i32 %v2699, 0
  %cv2701 = zext i1 %cmp2700 to i32
  store i32 %cv2701, ptr %slot304, align 8
  %v2702 = load i32, ptr %slot302, align 8
  %v2703 = load i32, ptr %slot304, align 8
  %op2704 = and i32 %v2702, %v2703
  store i32 %op2704, ptr %slot305, align 8
  %v2705 = load i32, ptr %slot305, align 8
  %cv2706 = zext i32 %v2705 to i64
  %cond2707 = icmp ne i64 %cv2706, 0
  br i1 %cond2707, label %bb_rcprivateown347, label %bb_rcprivateloan347
bb_rcprivateown347:
  %v2708 = load i64, ptr %slot30, align 8
  store i64 %v2708, ptr %slot306, align 8
  %v2709 = load i64, ptr %slot65, align 8
  store i64 %v2709, ptr %slot307, align 8
  %v2710 = load i64, ptr %slot301, align 8
  %v2711 = load i64, ptr %slot306, align 8
  %op2712 = sub i64 %v2710, %v2711
  store i64 %op2712, ptr %slot308, align 8
  %v2713 = load i64, ptr %slot306, align 8
  %v2714 = load i64, ptr %slot301, align 8
  %op2715 = sub i64 %v2713, %v2714
  store i64 %op2715, ptr %slot309, align 8
  %v2716 = load i64, ptr %slot308, align 8
  %cmp2717 = icmp ult i64 %v2716, 24
  %cv2718 = zext i1 %cmp2717 to i32
  store i32 %cv2718, ptr %slot310, align 8
  %v2719 = load i64, ptr %slot309, align 8
  %cmp2720 = icmp ult i64 %v2719, 24
  %cv2721 = zext i1 %cmp2720 to i32
  store i32 %cv2721, ptr %slot311, align 8
  %v2722 = load i32, ptr %slot310, align 8
  %v2723 = load i32, ptr %slot311, align 8
  %op2724 = or i32 %v2722, %v2723
  store i32 %op2724, ptr %slot312, align 8
  %v2725 = load i32, ptr %slot312, align 8
  %cv2726 = zext i32 %v2725 to i64
  %cond2727 = icmp ne i64 %cv2726, 0
  br i1 %cond2727, label %bb_rcmoveslow350, label %bb_rcmovecheck350
bb_rcmovecheck350:
  %v2728 = load i64, ptr %slot301, align 8
  %op2729 = add i64 %v2728, 0
  store i64 %op2729, ptr %slot313, align 8
  %v2730 = load i64, ptr %slot313, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  %ld2732 = load i64, ptr %p2731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2732, ptr %slot314, align 8
  %v2733 = load i64, ptr %slot314, align 8
  %cmp2734 = icmp ne i64 %v2733, 0
  %cv2735 = zext i1 %cmp2734 to i32
  store i32 %cv2735, ptr %slot315, align 8
  %v2736 = load i32, ptr %slot315, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcmoveheader358, label %bb_rcmovenext358
bb_rcmoveheader358:
  %v2739 = load i64, ptr %slot314, align 8
  %op2740 = sub i64 %v2739, 16
  store i64 %op2740, ptr %slot316, align 8
  %v2741 = load i64, ptr %slot314, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  %rgep2743 = getelementptr i8, ptr %p2742, i64 -16
  %ld2744 = load i64, ptr %rgep2743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2744, ptr %slot317, align 8
  %v2745 = load i64, ptr %slot317, align 8
  %op2746 = and i64 %v2745, 5764607523034234881
  store i64 %op2746, ptr %slot318, align 8
  %v2747 = load i64, ptr %slot318, align 8
  %cmp2748 = icmp ne i64 %v2747, 0
  %cv2749 = zext i1 %cmp2748 to i32
  store i32 %cv2749, ptr %slot319, align 8
  %v2750 = load i32, ptr %slot319, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcmoveslow350, label %bb_rcmovenext358
bb_rcmovenext358:
  %v2753 = load i64, ptr %slot301, align 8
  %op2754 = add i64 %v2753, 8
  store i64 %op2754, ptr %slot320, align 8
  %v2755 = load i64, ptr %slot320, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  %ld2757 = load i64, ptr %p2756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2757, ptr %slot321, align 8
  %v2758 = load i64, ptr %slot321, align 8
  %cmp2759 = icmp ne i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot322, align 8
  %v2761 = load i32, ptr %slot322, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcmoveheader366, label %bb_rcmovenext366
bb_rcmoveheader366:
  %v2764 = load i64, ptr %slot321, align 8
  %op2765 = sub i64 %v2764, 16
  store i64 %op2765, ptr %slot323, align 8
  %v2766 = load i64, ptr %slot321, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %rgep2768 = getelementptr i8, ptr %p2767, i64 -16
  %ld2769 = load i64, ptr %rgep2768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2769, ptr %slot324, align 8
  %v2770 = load i64, ptr %slot324, align 8
  %op2771 = and i64 %v2770, 5764607523034234881
  store i64 %op2771, ptr %slot325, align 8
  %v2772 = load i64, ptr %slot325, align 8
  %cmp2773 = icmp ne i64 %v2772, 0
  %cv2774 = zext i1 %cmp2773 to i32
  store i32 %cv2774, ptr %slot326, align 8
  %v2775 = load i32, ptr %slot326, align 8
  %cv2776 = zext i32 %v2775 to i64
  %cond2777 = icmp ne i64 %cv2776, 0
  br i1 %cond2777, label %bb_rcmoveslow350, label %bb_rcmovenext366
bb_rcmovenext366:
  %v2778 = load i64, ptr %slot301, align 8
  %op2779 = add i64 %v2778, 16
  store i64 %op2779, ptr %slot327, align 8
  %v2780 = load i64, ptr %slot327, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  %ld2782 = load i64, ptr %p2781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2782, ptr %slot328, align 8
  %v2783 = load i64, ptr %slot328, align 8
  %cmp2784 = icmp ne i64 %v2783, 0
  %cv2785 = zext i1 %cmp2784 to i32
  store i32 %cv2785, ptr %slot329, align 8
  %v2786 = load i32, ptr %slot329, align 8
  %cv2787 = zext i32 %v2786 to i64
  %cond2788 = icmp ne i64 %cv2787, 0
  br i1 %cond2788, label %bb_rcmoveheader374, label %bb_rcmovenext374
bb_rcmoveheader374:
  %v2789 = load i64, ptr %slot328, align 8
  %op2790 = sub i64 %v2789, 16
  store i64 %op2790, ptr %slot330, align 8
  %v2791 = load i64, ptr %slot328, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %rgep2793 = getelementptr i8, ptr %p2792, i64 -16
  %ld2794 = load i64, ptr %rgep2793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2794, ptr %slot331, align 8
  %v2795 = load i64, ptr %slot331, align 8
  %op2796 = and i64 %v2795, 5764607523034234881
  store i64 %op2796, ptr %slot332, align 8
  %v2797 = load i64, ptr %slot332, align 8
  %cmp2798 = icmp ne i64 %v2797, 0
  %cv2799 = zext i1 %cmp2798 to i32
  store i32 %cv2799, ptr %slot333, align 8
  %v2800 = load i32, ptr %slot333, align 8
  %cv2801 = zext i32 %v2800 to i64
  %cond2802 = icmp ne i64 %cv2801, 0
  br i1 %cond2802, label %bb_rcmoveslow350, label %bb_rcmovenext374
bb_rcmovenext374:
  %v2803 = load i64, ptr %slot301, align 8
  %v2804 = load i64, ptr %slot306, align 8
  %p2805 = inttoptr i64 %v2803 to ptr
  %p2806 = inttoptr i64 %v2804 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2806, ptr %p2805, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2807 = load i64, ptr %slot301, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  store i64 0, ptr %p2808, align 8, !alias.scope !3, !noalias !4
  %v2809 = load i64, ptr %slot301, align 8
  %op2810 = add i64 %v2809, 8
  store i64 %op2810, ptr %slot334, align 8
  %v2811 = load i64, ptr %slot334, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  store i64 0, ptr %p2812, align 8, !alias.scope !3, !noalias !4
  %v2813 = load i64, ptr %slot301, align 8
  %op2814 = add i64 %v2813, 16
  store i64 %op2814, ptr %slot335, align 8
  %v2815 = load i64, ptr %slot335, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  store i64 0, ptr %p2816, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved350
bb_rcmoveslow350:
  %v2817 = load i64, ptr %slot64, align 8
  %v2818 = load i64, ptr %slot306, align 8
  %v2819 = load i64, ptr %slot301, align 8
  %v2820 = load i64, ptr %slot307, align 8
  %cv2821 = trunc i64 %v2820 to i32
  %call2822 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v2817, i64 %v2818, i64 %v2819, i32 %cv2821) nomerge, !dbg !142
  store i32 %call2822, ptr %slot336, align 8
  %v2823 = load i32, ptr %slot336, align 8
  %cv2824 = zext i32 %v2823 to i64
  %cond2825 = icmp ne i64 %cv2824, 0
  br i1 %cond2825, label %bb_rcsuccess383, label %bb_rcfailure383
bb_rcfailure383:
  %v2826 = load i64, ptr %slot64, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  %call2828 = call i32 @myl_rc_take_failure(ptr %p2827) nomerge, !dbg !142
  store i32 %call2828, ptr %slot337, align 8
  %v2829 = load i64, ptr %slot1, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  %v2831 = load i32, ptr %slot337, align 8
  %call2832 = call i32 @myl_qbe_rc_status(ptr %p2830, i32 %v2831) nomerge, !dbg !142
  store i32 %call2832, ptr %slot338, align 8
  br label %bb_failure
bb_rcsuccess383:
  br label %bb_rcmoved350
bb_rcmoved350:
  %v2833 = load i64, ptr %slot17, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  store i32 0, ptr %p2834, align 4, !alias.scope !3, !noalias !4
  %v2835 = load i64, ptr %slot24, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i32 2, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  %v2837 = load i64, ptr %slot23, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  store i32 1, ptr %p2838, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared347
bb_rcprivateloan347:
  %v2839 = load i64, ptr %slot30, align 8
  store i64 %v2839, ptr %slot339, align 8
  %v2840 = load i64, ptr %slot64, align 8
  %v2841 = load i64, ptr %slot339, align 8
  %v2842 = load i64, ptr %slot301, align 8
  %call2843 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64 %v2840, i64 %v2841, i64 %v2842) nomerge, !dbg !142
  store i32 %call2843, ptr %slot340, align 8
  %v2844 = load i32, ptr %slot340, align 8
  %cv2845 = zext i32 %v2844 to i64
  %cond2846 = icmp ne i64 %cv2845, 0
  br i1 %cond2846, label %bb_rcsuccess391, label %bb_rcfailure391
bb_rcfailure391:
  %v2847 = load i64, ptr %slot64, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %call2849 = call i32 @myl_rc_take_failure(ptr %p2848) nomerge, !dbg !142
  store i32 %call2849, ptr %slot341, align 8
  %v2850 = load i64, ptr %slot1, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %v2852 = load i32, ptr %slot341, align 8
  %call2853 = call i32 @myl_qbe_rc_status(ptr %p2851, i32 %v2852) nomerge, !dbg !142
  store i32 %call2853, ptr %slot342, align 8
  br label %bb_failure
bb_rcsuccess391:
  %v2854 = load i64, ptr %slot24, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  store i32 2, ptr %p2855, align 4, !alias.scope !3, !noalias !4
  %v2856 = load i64, ptr %slot24, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i32 16, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot23, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i32 1, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot17, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %ld2862 = load i32, ptr %p2861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2862, ptr %slot343, align 8
  %v2863 = load i32, ptr %slot343, align 8
  %cv2864 = zext i32 %v2863 to i64
  %cond2865 = icmp ne i64 %cv2864, 0
  br i1 %cond2865, label %bb_rcslotdrop399, label %bb_rcslotdone399
bb_rcslotdrop399:
  %v2866 = load i64, ptr %slot17, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  store i32 0, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  %v2868 = load i64, ptr %slot26, align 8
  store i64 %v2868, ptr %slot344, align 8
  %v2869 = load i64, ptr %slot18, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  %ld2871 = load i32, ptr %p2870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2871, ptr %slot345, align 8
  %v2872 = load i32, ptr %slot345, align 8
  %op2873 = and i32 %v2872, 28
  store i32 %op2873, ptr %slot346, align 8
  %v2874 = load i32, ptr %slot346, align 8
  %cv2875 = zext i32 %v2874 to i64
  %cond2876 = icmp ne i64 %cv2875, 0
  br i1 %cond2876, label %bb_rcslotrole399, label %bb_rcslotowner399
bb_rcslotrole399:
  %v2877 = load i64, ptr %slot64, align 8
  store i64 %v2877, ptr %slot347, align 8
  %v2878 = load i64, ptr %slot347, align 8
  %v2879 = load i64, ptr %slot344, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2878, i64 %v2879) nomerge, !dbg !142
  br label %bb_rcslotdone399
bb_rcslotowner399:
  %v2880 = load i64, ptr %slot344, align 8
  %p2882 = inttoptr i64 %v2880 to ptr
  %gep2883 = getelementptr i8, ptr %p2882, i64 0
  %op2881 = ptrtoint ptr %gep2883 to i64
  store i64 %op2881, ptr %slot348, align 8
  %v2884 = load i64, ptr %slot64, align 8
  store i64 %v2884, ptr %slot349, align 8
  %v2885 = load i64, ptr %slot348, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %ld2887 = load i64, ptr %p2886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2887, ptr %slot350, align 8
  %v2888 = load i64, ptr %slot350, align 8
  %cmp2889 = icmp ne i64 %v2888, 0
  %cv2890 = zext i1 %cmp2889 to i32
  store i32 %cv2890, ptr %slot351, align 8
  %v2891 = load i32, ptr %slot351, align 8
  %cv2892 = zext i32 %v2891 to i64
  %cond2893 = icmp ne i64 %cv2892, 0
  br i1 %cond2893, label %bb_rcgnn417, label %bb_rcgdone417
bb_rcgnn417:
  %v2894 = load i64, ptr %slot350, align 8
  %op2895 = sub i64 %v2894, 16
  store i64 %op2895, ptr %slot352, align 8
  %v2896 = load i64, ptr %slot350, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %rgep2898 = getelementptr i8, ptr %p2897, i64 -16
  %ld2899 = load i64, ptr %rgep2898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2899, ptr %slot353, align 8
  %v2900 = load i64, ptr %slot353, align 8
  %op2901 = and i64 %v2900, 4611686018427387906
  store i64 %op2901, ptr %slot354, align 8
  %v2902 = load i64, ptr %slot354, align 8
  %cmp2903 = icmp ne i64 %v2902, 0
  %cv2904 = zext i1 %cmp2903 to i32
  store i32 %cv2904, ptr %slot355, align 8
  %v2905 = load i32, ptr %slot355, align 8
  %cv2906 = zext i32 %v2905 to i64
  %cond2907 = icmp ne i64 %cv2906, 0
  br i1 %cond2907, label %bb_rcgclear417, label %bb_rcgcounted417
bb_rcgcounted417:
  %v2908 = load i64, ptr %slot350, align 8
  %op2909 = sub i64 %v2908, 32
  store i64 %op2909, ptr %slot356, align 8
  %v2910 = load i64, ptr %slot350, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  %rgep2912 = getelementptr i8, ptr %p2911, i64 -32
  %ld2913 = load i64, ptr %rgep2912, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2913, ptr %slot357, align 8
  %v2914 = load i64, ptr %slot357, align 8
  %op2915 = sub i64 %v2914, 1
  store i64 %op2915, ptr %slot358, align 8
  %v2916 = load i64, ptr %slot358, align 8
  %cmp2917 = icmp eq i64 %v2916, 0
  %cv2918 = zext i1 %cmp2917 to i32
  store i32 %cv2918, ptr %slot359, align 8
  %v2919 = load i32, ptr %slot359, align 8
  %cv2920 = zext i32 %v2919 to i64
  %cond2921 = icmp ne i64 %cv2920, 0
  br i1 %cond2921, label %bb_rcglast417, label %bb_rcgdec417
bb_rcglast417:
  %v2922 = load i64, ptr %slot350, align 8
  %op2923 = sub i64 %v2922, 24
  store i64 %op2923, ptr %slot360, align 8
  %v2924 = load i64, ptr %slot350, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  %rgep2926 = getelementptr i8, ptr %p2925, i64 -24
  %ld2927 = load i64, ptr %rgep2926, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2927, ptr %slot361, align 8
  %v2928 = load i64, ptr %slot361, align 8
  %cmp2929 = icmp ne i64 %v2928, 0
  %cv2930 = zext i1 %cmp2929 to i32
  store i32 %cv2930, ptr %slot362, align 8
  %v2931 = load i32, ptr %slot362, align 8
  %cv2932 = zext i32 %v2931 to i64
  %cond2933 = icmp ne i64 %cv2932, 0
  br i1 %cond2933, label %bb_rcgdec417, label %bb_rcgslow417
bb_rcgslow417:
  %v2934 = load i64, ptr %slot349, align 8
  %v2935 = load i64, ptr %slot348, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2934, i64 %v2935) nomerge, !dbg !142
  br label %bb_rcgdone417
bb_rcgdec417:
  %v2936 = load i64, ptr %slot358, align 8
  %v2937 = load i64, ptr %slot350, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %rgep2939 = getelementptr i8, ptr %p2938, i64 -32
  store i64 %v2936, ptr %rgep2939, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear417
bb_rcgclear417:
  %v2940 = load i64, ptr %slot348, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  store i64 0, ptr %p2941, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone417
bb_rcgdone417:
  %v2942 = load i64, ptr %slot344, align 8
  %p2944 = inttoptr i64 %v2942 to ptr
  %gep2945 = getelementptr i8, ptr %p2944, i64 8
  %op2943 = ptrtoint ptr %gep2945 to i64
  store i64 %op2943, ptr %slot363, align 8
  %v2946 = load i64, ptr %slot64, align 8
  store i64 %v2946, ptr %slot364, align 8
  %v2947 = load i64, ptr %slot363, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %ld2949 = load i64, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2949, ptr %slot365, align 8
  %v2950 = load i64, ptr %slot365, align 8
  %cmp2951 = icmp ne i64 %v2950, 0
  %cv2952 = zext i1 %cmp2951 to i32
  store i32 %cv2952, ptr %slot366, align 8
  %v2953 = load i32, ptr %slot366, align 8
  %cv2954 = zext i32 %v2953 to i64
  %cond2955 = icmp ne i64 %cv2954, 0
  br i1 %cond2955, label %bb_rcgnn433, label %bb_rcgdone433
bb_rcgnn433:
  %v2956 = load i64, ptr %slot365, align 8
  %op2957 = sub i64 %v2956, 16
  store i64 %op2957, ptr %slot367, align 8
  %v2958 = load i64, ptr %slot365, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  %rgep2960 = getelementptr i8, ptr %p2959, i64 -16
  %ld2961 = load i64, ptr %rgep2960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2961, ptr %slot368, align 8
  %v2962 = load i64, ptr %slot368, align 8
  %op2963 = and i64 %v2962, 4611686018427387906
  store i64 %op2963, ptr %slot369, align 8
  %v2964 = load i64, ptr %slot369, align 8
  %cmp2965 = icmp ne i64 %v2964, 0
  %cv2966 = zext i1 %cmp2965 to i32
  store i32 %cv2966, ptr %slot370, align 8
  %v2967 = load i32, ptr %slot370, align 8
  %cv2968 = zext i32 %v2967 to i64
  %cond2969 = icmp ne i64 %cv2968, 0
  br i1 %cond2969, label %bb_rcgclear433, label %bb_rcgcounted433
bb_rcgcounted433:
  %v2970 = load i64, ptr %slot365, align 8
  %op2971 = sub i64 %v2970, 32
  store i64 %op2971, ptr %slot371, align 8
  %v2972 = load i64, ptr %slot365, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %rgep2974 = getelementptr i8, ptr %p2973, i64 -32
  %ld2975 = load i64, ptr %rgep2974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2975, ptr %slot372, align 8
  %v2976 = load i64, ptr %slot372, align 8
  %op2977 = sub i64 %v2976, 1
  store i64 %op2977, ptr %slot373, align 8
  %v2978 = load i64, ptr %slot373, align 8
  %cmp2979 = icmp eq i64 %v2978, 0
  %cv2980 = zext i1 %cmp2979 to i32
  store i32 %cv2980, ptr %slot374, align 8
  %v2981 = load i32, ptr %slot374, align 8
  %cv2982 = zext i32 %v2981 to i64
  %cond2983 = icmp ne i64 %cv2982, 0
  br i1 %cond2983, label %bb_rcglast433, label %bb_rcgdec433
bb_rcglast433:
  %v2984 = load i64, ptr %slot365, align 8
  %op2985 = sub i64 %v2984, 24
  store i64 %op2985, ptr %slot375, align 8
  %v2986 = load i64, ptr %slot365, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %rgep2988 = getelementptr i8, ptr %p2987, i64 -24
  %ld2989 = load i64, ptr %rgep2988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2989, ptr %slot376, align 8
  %v2990 = load i64, ptr %slot376, align 8
  %cmp2991 = icmp ne i64 %v2990, 0
  %cv2992 = zext i1 %cmp2991 to i32
  store i32 %cv2992, ptr %slot377, align 8
  %v2993 = load i32, ptr %slot377, align 8
  %cv2994 = zext i32 %v2993 to i64
  %cond2995 = icmp ne i64 %cv2994, 0
  br i1 %cond2995, label %bb_rcgdec433, label %bb_rcgslow433
bb_rcgslow433:
  %v2996 = load i64, ptr %slot364, align 8
  %v2997 = load i64, ptr %slot363, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2996, i64 %v2997) nomerge, !dbg !142
  br label %bb_rcgdone433
bb_rcgdec433:
  %v2998 = load i64, ptr %slot373, align 8
  %v2999 = load i64, ptr %slot365, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  %rgep3001 = getelementptr i8, ptr %p3000, i64 -32
  store i64 %v2998, ptr %rgep3001, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear433
bb_rcgclear433:
  %v3002 = load i64, ptr %slot363, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  store i64 0, ptr %p3003, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone433
bb_rcgdone433:
  %v3004 = load i64, ptr %slot344, align 8
  %p3006 = inttoptr i64 %v3004 to ptr
  %gep3007 = getelementptr i8, ptr %p3006, i64 16
  %op3005 = ptrtoint ptr %gep3007 to i64
  store i64 %op3005, ptr %slot378, align 8
  %v3008 = load i64, ptr %slot64, align 8
  store i64 %v3008, ptr %slot379, align 8
  %v3009 = load i64, ptr %slot378, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %ld3011 = load i64, ptr %p3010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3011, ptr %slot380, align 8
  %v3012 = load i64, ptr %slot380, align 8
  %cmp3013 = icmp ne i64 %v3012, 0
  %cv3014 = zext i1 %cmp3013 to i32
  store i32 %cv3014, ptr %slot381, align 8
  %v3015 = load i32, ptr %slot381, align 8
  %cv3016 = zext i32 %v3015 to i64
  %cond3017 = icmp ne i64 %cv3016, 0
  br i1 %cond3017, label %bb_rcgnn449, label %bb_rcgdone449
bb_rcgnn449:
  %v3018 = load i64, ptr %slot380, align 8
  %op3019 = sub i64 %v3018, 16
  store i64 %op3019, ptr %slot382, align 8
  %v3020 = load i64, ptr %slot380, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  %rgep3022 = getelementptr i8, ptr %p3021, i64 -16
  %ld3023 = load i64, ptr %rgep3022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3023, ptr %slot383, align 8
  %v3024 = load i64, ptr %slot383, align 8
  %op3025 = and i64 %v3024, 4611686018427387906
  store i64 %op3025, ptr %slot384, align 8
  %v3026 = load i64, ptr %slot384, align 8
  %cmp3027 = icmp ne i64 %v3026, 0
  %cv3028 = zext i1 %cmp3027 to i32
  store i32 %cv3028, ptr %slot385, align 8
  %v3029 = load i32, ptr %slot385, align 8
  %cv3030 = zext i32 %v3029 to i64
  %cond3031 = icmp ne i64 %cv3030, 0
  br i1 %cond3031, label %bb_rcgclear449, label %bb_rcgcounted449
bb_rcgcounted449:
  %v3032 = load i64, ptr %slot380, align 8
  %op3033 = sub i64 %v3032, 32
  store i64 %op3033, ptr %slot386, align 8
  %v3034 = load i64, ptr %slot380, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %rgep3036 = getelementptr i8, ptr %p3035, i64 -32
  %ld3037 = load i64, ptr %rgep3036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3037, ptr %slot387, align 8
  %v3038 = load i64, ptr %slot387, align 8
  %op3039 = sub i64 %v3038, 1
  store i64 %op3039, ptr %slot388, align 8
  %v3040 = load i64, ptr %slot388, align 8
  %cmp3041 = icmp eq i64 %v3040, 0
  %cv3042 = zext i1 %cmp3041 to i32
  store i32 %cv3042, ptr %slot389, align 8
  %v3043 = load i32, ptr %slot389, align 8
  %cv3044 = zext i32 %v3043 to i64
  %cond3045 = icmp ne i64 %cv3044, 0
  br i1 %cond3045, label %bb_rcglast449, label %bb_rcgdec449
bb_rcglast449:
  %v3046 = load i64, ptr %slot380, align 8
  %op3047 = sub i64 %v3046, 24
  store i64 %op3047, ptr %slot390, align 8
  %v3048 = load i64, ptr %slot380, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %rgep3050 = getelementptr i8, ptr %p3049, i64 -24
  %ld3051 = load i64, ptr %rgep3050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3051, ptr %slot391, align 8
  %v3052 = load i64, ptr %slot391, align 8
  %cmp3053 = icmp ne i64 %v3052, 0
  %cv3054 = zext i1 %cmp3053 to i32
  store i32 %cv3054, ptr %slot392, align 8
  %v3055 = load i32, ptr %slot392, align 8
  %cv3056 = zext i32 %v3055 to i64
  %cond3057 = icmp ne i64 %cv3056, 0
  br i1 %cond3057, label %bb_rcgdec449, label %bb_rcgslow449
bb_rcgslow449:
  %v3058 = load i64, ptr %slot379, align 8
  %v3059 = load i64, ptr %slot378, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3058, i64 %v3059) nomerge, !dbg !142
  br label %bb_rcgdone449
bb_rcgdec449:
  %v3060 = load i64, ptr %slot388, align 8
  %v3061 = load i64, ptr %slot380, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  %rgep3063 = getelementptr i8, ptr %p3062, i64 -32
  store i64 %v3060, ptr %rgep3063, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear449
bb_rcgclear449:
  %v3064 = load i64, ptr %slot378, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  store i64 0, ptr %p3065, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone449
bb_rcgdone449:
  %v3066 = load i64, ptr %slot344, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  store i64 0, ptr %p3067, align 8, !alias.scope !3, !noalias !4
  %v3068 = load i64, ptr %slot344, align 8
  %p3070 = inttoptr i64 %v3068 to ptr
  %gep3071 = getelementptr i8, ptr %p3070, i64 8
  %op3069 = ptrtoint ptr %gep3071 to i64
  store i64 %op3069, ptr %slot393, align 8
  %v3072 = load i64, ptr %slot393, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i64 0, ptr %p3073, align 8, !alias.scope !3, !noalias !4
  %v3074 = load i64, ptr %slot344, align 8
  %p3076 = inttoptr i64 %v3074 to ptr
  %gep3077 = getelementptr i8, ptr %p3076, i64 16
  %op3075 = ptrtoint ptr %gep3077 to i64
  store i64 %op3075, ptr %slot394, align 8
  %v3078 = load i64, ptr %slot394, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i64 0, ptr %p3079, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone399
bb_rcslotdone399:
  br label %bb_rcprivateprepared347
bb_rcprivateprepared347:
  %v3080 = load i64, ptr %slot11, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %ld3082 = load i32, ptr %p3081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3082, ptr %slot395, align 8
  %v3083 = load i32, ptr %slot395, align 8
  %cv3084 = zext i32 %v3083 to i64
  %cond3085 = icmp ne i64 %cv3084, 0
  br i1 %cond3085, label %bb_rcslotdrop458, label %bb_rcslotdone458
bb_rcslotdrop458:
  %v3086 = load i64, ptr %slot11, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i32 0, ptr %p3087, align 4, !alias.scope !3, !noalias !4
  %v3088 = load i64, ptr %slot45, align 8
  store i64 %v3088, ptr %slot396, align 8
  %v3089 = load i64, ptr %slot12, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i32, ptr %p3090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3091, ptr %slot397, align 8
  %v3092 = load i32, ptr %slot397, align 8
  %op3093 = and i32 %v3092, 28
  store i32 %op3093, ptr %slot398, align 8
  %v3094 = load i32, ptr %slot398, align 8
  %cv3095 = zext i32 %v3094 to i64
  %cond3096 = icmp ne i64 %cv3095, 0
  br i1 %cond3096, label %bb_rcslotrole458, label %bb_rcslotowner458
bb_rcslotrole458:
  %v3097 = load i64, ptr %slot64, align 8
  store i64 %v3097, ptr %slot399, align 8
  %v3098 = load i64, ptr %slot399, align 8
  %v3099 = load i64, ptr %slot396, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3098, i64 %v3099) nomerge, !dbg !142
  br label %bb_rcslotdone458
bb_rcslotowner458:
  %v3100 = load i64, ptr %slot396, align 8
  %p3102 = inttoptr i64 %v3100 to ptr
  %gep3103 = getelementptr i8, ptr %p3102, i64 0
  %op3101 = ptrtoint ptr %gep3103 to i64
  store i64 %op3101, ptr %slot400, align 8
  %v3104 = load i64, ptr %slot64, align 8
  store i64 %v3104, ptr %slot401, align 8
  %v3105 = load i64, ptr %slot400, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i64, ptr %p3106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3107, ptr %slot402, align 8
  %v3108 = load i64, ptr %slot402, align 8
  %cmp3109 = icmp ne i64 %v3108, 0
  %cv3110 = zext i1 %cmp3109 to i32
  store i32 %cv3110, ptr %slot403, align 8
  %v3111 = load i32, ptr %slot403, align 8
  %cv3112 = zext i32 %v3111 to i64
  %cond3113 = icmp ne i64 %cv3112, 0
  br i1 %cond3113, label %bb_rcgnn476, label %bb_rcgdone476
bb_rcgnn476:
  %v3114 = load i64, ptr %slot402, align 8
  %op3115 = sub i64 %v3114, 16
  store i64 %op3115, ptr %slot404, align 8
  %v3116 = load i64, ptr %slot402, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  %rgep3118 = getelementptr i8, ptr %p3117, i64 -16
  %ld3119 = load i64, ptr %rgep3118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3119, ptr %slot405, align 8
  %v3120 = load i64, ptr %slot405, align 8
  %op3121 = and i64 %v3120, 4611686018427387906
  store i64 %op3121, ptr %slot406, align 8
  %v3122 = load i64, ptr %slot406, align 8
  %cmp3123 = icmp ne i64 %v3122, 0
  %cv3124 = zext i1 %cmp3123 to i32
  store i32 %cv3124, ptr %slot407, align 8
  %v3125 = load i32, ptr %slot407, align 8
  %cv3126 = zext i32 %v3125 to i64
  %cond3127 = icmp ne i64 %cv3126, 0
  br i1 %cond3127, label %bb_rcgclear476, label %bb_rcgcounted476
bb_rcgcounted476:
  %v3128 = load i64, ptr %slot402, align 8
  %op3129 = sub i64 %v3128, 32
  store i64 %op3129, ptr %slot408, align 8
  %v3130 = load i64, ptr %slot402, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %rgep3132 = getelementptr i8, ptr %p3131, i64 -32
  %ld3133 = load i64, ptr %rgep3132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3133, ptr %slot409, align 8
  %v3134 = load i64, ptr %slot409, align 8
  %op3135 = sub i64 %v3134, 1
  store i64 %op3135, ptr %slot410, align 8
  %v3136 = load i64, ptr %slot410, align 8
  %cmp3137 = icmp eq i64 %v3136, 0
  %cv3138 = zext i1 %cmp3137 to i32
  store i32 %cv3138, ptr %slot411, align 8
  %v3139 = load i32, ptr %slot411, align 8
  %cv3140 = zext i32 %v3139 to i64
  %cond3141 = icmp ne i64 %cv3140, 0
  br i1 %cond3141, label %bb_rcglast476, label %bb_rcgdec476
bb_rcglast476:
  %v3142 = load i64, ptr %slot402, align 8
  %op3143 = sub i64 %v3142, 24
  store i64 %op3143, ptr %slot412, align 8
  %v3144 = load i64, ptr %slot402, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  %rgep3146 = getelementptr i8, ptr %p3145, i64 -24
  %ld3147 = load i64, ptr %rgep3146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3147, ptr %slot413, align 8
  %v3148 = load i64, ptr %slot413, align 8
  %cmp3149 = icmp ne i64 %v3148, 0
  %cv3150 = zext i1 %cmp3149 to i32
  store i32 %cv3150, ptr %slot414, align 8
  %v3151 = load i32, ptr %slot414, align 8
  %cv3152 = zext i32 %v3151 to i64
  %cond3153 = icmp ne i64 %cv3152, 0
  br i1 %cond3153, label %bb_rcgdec476, label %bb_rcgslow476
bb_rcgslow476:
  %v3154 = load i64, ptr %slot401, align 8
  %v3155 = load i64, ptr %slot400, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3154, i64 %v3155) nomerge, !dbg !142
  br label %bb_rcgdone476
bb_rcgdec476:
  %v3156 = load i64, ptr %slot410, align 8
  %v3157 = load i64, ptr %slot402, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  %rgep3159 = getelementptr i8, ptr %p3158, i64 -32
  store i64 %v3156, ptr %rgep3159, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear476
bb_rcgclear476:
  %v3160 = load i64, ptr %slot400, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  store i64 0, ptr %p3161, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone476
bb_rcgdone476:
  %v3162 = load i64, ptr %slot396, align 8
  %p3164 = inttoptr i64 %v3162 to ptr
  %gep3165 = getelementptr i8, ptr %p3164, i64 8
  %op3163 = ptrtoint ptr %gep3165 to i64
  store i64 %op3163, ptr %slot415, align 8
  %v3166 = load i64, ptr %slot64, align 8
  store i64 %v3166, ptr %slot416, align 8
  %v3167 = load i64, ptr %slot415, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %ld3169 = load i64, ptr %p3168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3169, ptr %slot417, align 8
  %v3170 = load i64, ptr %slot417, align 8
  %cmp3171 = icmp ne i64 %v3170, 0
  %cv3172 = zext i1 %cmp3171 to i32
  store i32 %cv3172, ptr %slot418, align 8
  %v3173 = load i32, ptr %slot418, align 8
  %cv3174 = zext i32 %v3173 to i64
  %cond3175 = icmp ne i64 %cv3174, 0
  br i1 %cond3175, label %bb_rcgnn492, label %bb_rcgdone492
bb_rcgnn492:
  %v3176 = load i64, ptr %slot417, align 8
  %op3177 = sub i64 %v3176, 16
  store i64 %op3177, ptr %slot419, align 8
  %v3178 = load i64, ptr %slot417, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  %rgep3180 = getelementptr i8, ptr %p3179, i64 -16
  %ld3181 = load i64, ptr %rgep3180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3181, ptr %slot420, align 8
  %v3182 = load i64, ptr %slot420, align 8
  %op3183 = and i64 %v3182, 4611686018427387906
  store i64 %op3183, ptr %slot421, align 8
  %v3184 = load i64, ptr %slot421, align 8
  %cmp3185 = icmp ne i64 %v3184, 0
  %cv3186 = zext i1 %cmp3185 to i32
  store i32 %cv3186, ptr %slot422, align 8
  %v3187 = load i32, ptr %slot422, align 8
  %cv3188 = zext i32 %v3187 to i64
  %cond3189 = icmp ne i64 %cv3188, 0
  br i1 %cond3189, label %bb_rcgclear492, label %bb_rcgcounted492
bb_rcgcounted492:
  %v3190 = load i64, ptr %slot417, align 8
  %op3191 = sub i64 %v3190, 32
  store i64 %op3191, ptr %slot423, align 8
  %v3192 = load i64, ptr %slot417, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  %rgep3194 = getelementptr i8, ptr %p3193, i64 -32
  %ld3195 = load i64, ptr %rgep3194, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3195, ptr %slot424, align 8
  %v3196 = load i64, ptr %slot424, align 8
  %op3197 = sub i64 %v3196, 1
  store i64 %op3197, ptr %slot425, align 8
  %v3198 = load i64, ptr %slot425, align 8
  %cmp3199 = icmp eq i64 %v3198, 0
  %cv3200 = zext i1 %cmp3199 to i32
  store i32 %cv3200, ptr %slot426, align 8
  %v3201 = load i32, ptr %slot426, align 8
  %cv3202 = zext i32 %v3201 to i64
  %cond3203 = icmp ne i64 %cv3202, 0
  br i1 %cond3203, label %bb_rcglast492, label %bb_rcgdec492
bb_rcglast492:
  %v3204 = load i64, ptr %slot417, align 8
  %op3205 = sub i64 %v3204, 24
  store i64 %op3205, ptr %slot427, align 8
  %v3206 = load i64, ptr %slot417, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %rgep3208 = getelementptr i8, ptr %p3207, i64 -24
  %ld3209 = load i64, ptr %rgep3208, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3209, ptr %slot428, align 8
  %v3210 = load i64, ptr %slot428, align 8
  %cmp3211 = icmp ne i64 %v3210, 0
  %cv3212 = zext i1 %cmp3211 to i32
  store i32 %cv3212, ptr %slot429, align 8
  %v3213 = load i32, ptr %slot429, align 8
  %cv3214 = zext i32 %v3213 to i64
  %cond3215 = icmp ne i64 %cv3214, 0
  br i1 %cond3215, label %bb_rcgdec492, label %bb_rcgslow492
bb_rcgslow492:
  %v3216 = load i64, ptr %slot416, align 8
  %v3217 = load i64, ptr %slot415, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3216, i64 %v3217) nomerge, !dbg !142
  br label %bb_rcgdone492
bb_rcgdec492:
  %v3218 = load i64, ptr %slot425, align 8
  %v3219 = load i64, ptr %slot417, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  %rgep3221 = getelementptr i8, ptr %p3220, i64 -32
  store i64 %v3218, ptr %rgep3221, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear492
bb_rcgclear492:
  %v3222 = load i64, ptr %slot415, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  store i64 0, ptr %p3223, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone492
bb_rcgdone492:
  %v3224 = load i64, ptr %slot396, align 8
  %p3226 = inttoptr i64 %v3224 to ptr
  %gep3227 = getelementptr i8, ptr %p3226, i64 16
  %op3225 = ptrtoint ptr %gep3227 to i64
  store i64 %op3225, ptr %slot430, align 8
  %v3228 = load i64, ptr %slot64, align 8
  store i64 %v3228, ptr %slot431, align 8
  %v3229 = load i64, ptr %slot430, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %ld3231 = load i64, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3231, ptr %slot432, align 8
  %v3232 = load i64, ptr %slot432, align 8
  %cmp3233 = icmp ne i64 %v3232, 0
  %cv3234 = zext i1 %cmp3233 to i32
  store i32 %cv3234, ptr %slot433, align 8
  %v3235 = load i32, ptr %slot433, align 8
  %cv3236 = zext i32 %v3235 to i64
  %cond3237 = icmp ne i64 %cv3236, 0
  br i1 %cond3237, label %bb_rcgnn508, label %bb_rcgdone508
bb_rcgnn508:
  %v3238 = load i64, ptr %slot432, align 8
  %op3239 = sub i64 %v3238, 16
  store i64 %op3239, ptr %slot434, align 8
  %v3240 = load i64, ptr %slot432, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  %rgep3242 = getelementptr i8, ptr %p3241, i64 -16
  %ld3243 = load i64, ptr %rgep3242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3243, ptr %slot435, align 8
  %v3244 = load i64, ptr %slot435, align 8
  %op3245 = and i64 %v3244, 4611686018427387906
  store i64 %op3245, ptr %slot436, align 8
  %v3246 = load i64, ptr %slot436, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot437, align 8
  %v3249 = load i32, ptr %slot437, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcgclear508, label %bb_rcgcounted508
bb_rcgcounted508:
  %v3252 = load i64, ptr %slot432, align 8
  %op3253 = sub i64 %v3252, 32
  store i64 %op3253, ptr %slot438, align 8
  %v3254 = load i64, ptr %slot432, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %rgep3256 = getelementptr i8, ptr %p3255, i64 -32
  %ld3257 = load i64, ptr %rgep3256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3257, ptr %slot439, align 8
  %v3258 = load i64, ptr %slot439, align 8
  %op3259 = sub i64 %v3258, 1
  store i64 %op3259, ptr %slot440, align 8
  %v3260 = load i64, ptr %slot440, align 8
  %cmp3261 = icmp eq i64 %v3260, 0
  %cv3262 = zext i1 %cmp3261 to i32
  store i32 %cv3262, ptr %slot441, align 8
  %v3263 = load i32, ptr %slot441, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcglast508, label %bb_rcgdec508
bb_rcglast508:
  %v3266 = load i64, ptr %slot432, align 8
  %op3267 = sub i64 %v3266, 24
  store i64 %op3267, ptr %slot442, align 8
  %v3268 = load i64, ptr %slot432, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %rgep3270 = getelementptr i8, ptr %p3269, i64 -24
  %ld3271 = load i64, ptr %rgep3270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3271, ptr %slot443, align 8
  %v3272 = load i64, ptr %slot443, align 8
  %cmp3273 = icmp ne i64 %v3272, 0
  %cv3274 = zext i1 %cmp3273 to i32
  store i32 %cv3274, ptr %slot444, align 8
  %v3275 = load i32, ptr %slot444, align 8
  %cv3276 = zext i32 %v3275 to i64
  %cond3277 = icmp ne i64 %cv3276, 0
  br i1 %cond3277, label %bb_rcgdec508, label %bb_rcgslow508
bb_rcgslow508:
  %v3278 = load i64, ptr %slot431, align 8
  %v3279 = load i64, ptr %slot430, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3278, i64 %v3279) nomerge, !dbg !142
  br label %bb_rcgdone508
bb_rcgdec508:
  %v3280 = load i64, ptr %slot440, align 8
  %v3281 = load i64, ptr %slot432, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  %rgep3283 = getelementptr i8, ptr %p3282, i64 -32
  store i64 %v3280, ptr %rgep3283, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear508
bb_rcgclear508:
  %v3284 = load i64, ptr %slot430, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  store i64 0, ptr %p3285, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone508
bb_rcgdone508:
  %v3286 = load i64, ptr %slot396, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i64 0, ptr %p3287, align 8, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot396, align 8
  %p3290 = inttoptr i64 %v3288 to ptr
  %gep3291 = getelementptr i8, ptr %p3290, i64 8
  %op3289 = ptrtoint ptr %gep3291 to i64
  store i64 %op3289, ptr %slot445, align 8
  %v3292 = load i64, ptr %slot445, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  store i64 0, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  %v3294 = load i64, ptr %slot396, align 8
  %p3296 = inttoptr i64 %v3294 to ptr
  %gep3297 = getelementptr i8, ptr %p3296, i64 16
  %op3295 = ptrtoint ptr %gep3297 to i64
  store i64 %op3295, ptr %slot446, align 8
  %v3298 = load i64, ptr %slot446, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i64 0, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone458
bb_rcslotdone458:
  %v3300 = load i64, ptr %slot45, align 8
  store i64 %v3300, ptr %slot447, align 8
  %v3301 = load i64, ptr %slot30, align 8
  store i64 %v3301, ptr %slot448, align 8
  %v3302 = load i64, ptr %slot448, align 8
  %v3303 = load i64, ptr %slot447, align 8
  %p3304 = inttoptr i64 %v3302 to ptr
  %p3305 = inttoptr i64 %v3303 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3305, ptr %p3304, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot23, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i32 0, ptr %p3307, align 4, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot12, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  store i32 2, ptr %p3309, align 4, !alias.scope !3, !noalias !4
  %v3310 = load i64, ptr %slot24, align 8
  %p3311 = inttoptr i64 %v3310 to ptr
  %ld3312 = load i32, ptr %p3311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3312, ptr %slot449, align 8
  %v3313 = load i32, ptr %slot449, align 8
  %v3314 = load i64, ptr %slot12, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  store i32 %v3313, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot11, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  store i32 1, ptr %p3317, align 4, !alias.scope !3, !noalias !4
  %v3318 = load i64, ptr %slot43, align 8
  %v3319 = load i64, ptr %slot52, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i64 %v3318, ptr %p3320, align 8, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot52, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %ld3323 = load i64, ptr %p3322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3323, ptr %slot450, align 8
  %v3324 = load i64, ptr %slot17, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %ld3326 = load i32, ptr %p3325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3326, ptr %slot451, align 8
  %v3327 = load i64, ptr %slot18, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  %ld3329 = load i32, ptr %p3328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3329, ptr %slot452, align 8
  %v3330 = load i32, ptr %slot452, align 8
  %op3331 = and i32 %v3330, 24
  store i32 %op3331, ptr %slot452, align 8
  %v3332 = load i32, ptr %slot452, align 8
  %cmp3333 = icmp eq i32 %v3332, 0
  %cv3334 = zext i1 %cmp3333 to i32
  store i32 %cv3334, ptr %slot453, align 8
  %v3335 = load i32, ptr %slot451, align 8
  %v3336 = load i32, ptr %slot453, align 8
  %op3337 = and i32 %v3335, %v3336
  store i32 %op3337, ptr %slot454, align 8
  %v3338 = load i32, ptr %slot454, align 8
  %cv3339 = zext i32 %v3338 to i64
  %cond3340 = icmp ne i64 %cv3339, 0
  br i1 %cond3340, label %bb_rcprivateown528, label %bb_rcprivateloan528
bb_rcprivateown528:
  %v3341 = load i64, ptr %slot30, align 8
  store i64 %v3341, ptr %slot455, align 8
  %v3342 = load i64, ptr %slot65, align 8
  store i64 %v3342, ptr %slot456, align 8
  %v3343 = load i64, ptr %slot64, align 8
  %v3344 = load i64, ptr %slot455, align 8
  %v3345 = load i64, ptr %slot450, align 8
  %v3346 = load i64, ptr %slot456, align 8
  %cv3347 = trunc i64 %v3346 to i32
  %call3348 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3343, i64 %v3344, i64 %v3345, i32 %cv3347) nomerge, !dbg !144
  store i32 %call3348, ptr %slot457, align 8
  %v3349 = load i32, ptr %slot457, align 8
  %cv3350 = zext i32 %v3349 to i64
  %cond3351 = icmp ne i64 %cv3350, 0
  br i1 %cond3351, label %bb_rcsuccess532, label %bb_rcfailure532
bb_rcfailure532:
  %v3352 = load i64, ptr %slot64, align 8
  %p3353 = inttoptr i64 %v3352 to ptr
  %call3354 = call i32 @myl_rc_take_failure(ptr %p3353) nomerge, !dbg !144
  store i32 %call3354, ptr %slot458, align 8
  %v3355 = load i64, ptr %slot1, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %v3357 = load i32, ptr %slot458, align 8
  %call3358 = call i32 @myl_qbe_rc_status(ptr %p3356, i32 %v3357) nomerge, !dbg !144
  store i32 %call3358, ptr %slot459, align 8
  br label %bb_failure
bb_rcsuccess532:
  %v3359 = load i64, ptr %slot17, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  store i32 0, ptr %p3360, align 4, !alias.scope !3, !noalias !4
  %v3361 = load i64, ptr %slot24, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  store i32 2, ptr %p3362, align 4, !alias.scope !3, !noalias !4
  %v3363 = load i64, ptr %slot23, align 8
  %p3364 = inttoptr i64 %v3363 to ptr
  store i32 1, ptr %p3364, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared528
bb_rcprivateloan528:
  %v3365 = load i64, ptr %slot30, align 8
  store i64 %v3365, ptr %slot460, align 8
  %v3366 = load i64, ptr %slot64, align 8
  %v3367 = load i64, ptr %slot460, align 8
  %v3368 = load i64, ptr %slot450, align 8
  %call3369 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v3366, i64 %v3367, i64 %v3368) nomerge, !dbg !144
  store i32 %call3369, ptr %slot461, align 8
  %v3370 = load i32, ptr %slot461, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcsuccess540, label %bb_rcfailure540
bb_rcfailure540:
  %v3373 = load i64, ptr %slot64, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  %call3375 = call i32 @myl_rc_take_failure(ptr %p3374) nomerge, !dbg !144
  store i32 %call3375, ptr %slot462, align 8
  %v3376 = load i64, ptr %slot1, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  %v3378 = load i32, ptr %slot462, align 8
  %call3379 = call i32 @myl_qbe_rc_status(ptr %p3377, i32 %v3378) nomerge, !dbg !144
  store i32 %call3379, ptr %slot463, align 8
  br label %bb_failure
bb_rcsuccess540:
  %v3380 = load i64, ptr %slot24, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  store i32 2, ptr %p3381, align 4, !alias.scope !3, !noalias !4
  %v3382 = load i64, ptr %slot24, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  store i32 16, ptr %p3383, align 4, !alias.scope !3, !noalias !4
  %v3384 = load i64, ptr %slot23, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  store i32 1, ptr %p3385, align 4, !alias.scope !3, !noalias !4
  %v3386 = load i64, ptr %slot17, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  %ld3388 = load i32, ptr %p3387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3388, ptr %slot464, align 8
  %v3389 = load i32, ptr %slot464, align 8
  %cv3390 = zext i32 %v3389 to i64
  %cond3391 = icmp ne i64 %cv3390, 0
  br i1 %cond3391, label %bb_rcslotdrop548, label %bb_rcslotdone548
bb_rcslotdrop548:
  %v3392 = load i64, ptr %slot17, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  store i32 0, ptr %p3393, align 4, !alias.scope !3, !noalias !4
  %v3394 = load i64, ptr %slot26, align 8
  store i64 %v3394, ptr %slot465, align 8
  %v3395 = load i64, ptr %slot18, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  %ld3397 = load i32, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3397, ptr %slot466, align 8
  %v3398 = load i32, ptr %slot466, align 8
  %op3399 = and i32 %v3398, 28
  store i32 %op3399, ptr %slot467, align 8
  %v3400 = load i32, ptr %slot467, align 8
  %cv3401 = zext i32 %v3400 to i64
  %cond3402 = icmp ne i64 %cv3401, 0
  br i1 %cond3402, label %bb_rcslotrole548, label %bb_rcslotowner548
bb_rcslotrole548:
  %v3403 = load i64, ptr %slot64, align 8
  store i64 %v3403, ptr %slot468, align 8
  %v3404 = load i64, ptr %slot468, align 8
  %v3405 = load i64, ptr %slot465, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3404, i64 %v3405) nomerge, !dbg !144
  br label %bb_rcslotdone548
bb_rcslotowner548:
  %v3406 = load i64, ptr %slot64, align 8
  store i64 %v3406, ptr %slot469, align 8
  %v3407 = load i64, ptr %slot469, align 8
  %v3408 = load i64, ptr %slot465, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3407, i64 %v3408) nomerge, !dbg !144
  br label %bb_rcslotdone548
bb_rcslotdone548:
  br label %bb_rcprivateprepared528
bb_rcprivateprepared528:
  %v3409 = load i64, ptr %slot9, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %ld3411 = load i32, ptr %p3410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3411, ptr %slot470, align 8
  %v3412 = load i32, ptr %slot470, align 8
  %cv3413 = zext i32 %v3412 to i64
  %cond3414 = icmp ne i64 %cv3413, 0
  br i1 %cond3414, label %bb_rcslotdrop558, label %bb_rcslotdone558
bb_rcslotdrop558:
  %v3415 = load i64, ptr %slot9, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  store i32 0, ptr %p3416, align 4, !alias.scope !3, !noalias !4
  %v3417 = load i64, ptr %slot44, align 8
  store i64 %v3417, ptr %slot471, align 8
  %v3418 = load i64, ptr %slot10, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %ld3420 = load i32, ptr %p3419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3420, ptr %slot472, align 8
  %v3421 = load i32, ptr %slot472, align 8
  %op3422 = and i32 %v3421, 28
  store i32 %op3422, ptr %slot473, align 8
  %v3423 = load i32, ptr %slot473, align 8
  %cv3424 = zext i32 %v3423 to i64
  %cond3425 = icmp ne i64 %cv3424, 0
  br i1 %cond3425, label %bb_rcslotrole558, label %bb_rcslotowner558
bb_rcslotrole558:
  %v3426 = load i64, ptr %slot64, align 8
  store i64 %v3426, ptr %slot474, align 8
  %v3427 = load i64, ptr %slot474, align 8
  %v3428 = load i64, ptr %slot471, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3427, i64 %v3428) nomerge, !dbg !144
  br label %bb_rcslotdone558
bb_rcslotowner558:
  %v3429 = load i64, ptr %slot64, align 8
  store i64 %v3429, ptr %slot475, align 8
  %v3430 = load i64, ptr %slot475, align 8
  %v3431 = load i64, ptr %slot471, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3430, i64 %v3431) nomerge, !dbg !144
  br label %bb_rcslotdone558
bb_rcslotdone558:
  %v3432 = load i64, ptr %slot44, align 8
  store i64 %v3432, ptr %slot476, align 8
  %v3433 = load i64, ptr %slot30, align 8
  store i64 %v3433, ptr %slot477, align 8
  %v3434 = load i64, ptr %slot477, align 8
  %v3435 = load i64, ptr %slot476, align 8
  %p3436 = inttoptr i64 %v3434 to ptr
  %p3437 = inttoptr i64 %v3435 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3437, ptr %p3436, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3438 = load i64, ptr %slot23, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  store i32 0, ptr %p3439, align 4, !alias.scope !3, !noalias !4
  %v3440 = load i64, ptr %slot10, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  store i32 2, ptr %p3441, align 4, !alias.scope !3, !noalias !4
  %v3442 = load i64, ptr %slot24, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  %ld3444 = load i32, ptr %p3443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3444, ptr %slot478, align 8
  %v3445 = load i32, ptr %slot478, align 8
  %v3446 = load i64, ptr %slot10, align 8
  %p3447 = inttoptr i64 %v3446 to ptr
  store i32 %v3445, ptr %p3447, align 4, !alias.scope !3, !noalias !4
  %v3448 = load i64, ptr %slot9, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  store i32 1, ptr %p3449, align 4, !alias.scope !3, !noalias !4
  %v3450 = load i64, ptr %slot43, align 8
  %v3451 = load i64, ptr %slot52, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  store i64 %v3450, ptr %p3452, align 8, !alias.scope !3, !noalias !4
  %v3453 = load i64, ptr %slot52, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  %ld3455 = load i64, ptr %p3454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3455, ptr %slot479, align 8
  %v3456 = load i64, ptr %slot17, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  %ld3458 = load i32, ptr %p3457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3458, ptr %slot480, align 8
  %v3459 = load i64, ptr %slot18, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  %ld3461 = load i32, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3461, ptr %slot481, align 8
  %v3462 = load i32, ptr %slot481, align 8
  %op3463 = and i32 %v3462, 24
  store i32 %op3463, ptr %slot481, align 8
  %v3464 = load i32, ptr %slot481, align 8
  %cmp3465 = icmp eq i32 %v3464, 0
  %cv3466 = zext i1 %cmp3465 to i32
  store i32 %cv3466, ptr %slot482, align 8
  %v3467 = load i32, ptr %slot480, align 8
  %v3468 = load i32, ptr %slot482, align 8
  %op3469 = and i32 %v3467, %v3468
  store i32 %op3469, ptr %slot483, align 8
  %v3470 = load i32, ptr %slot483, align 8
  %cv3471 = zext i32 %v3470 to i64
  %cond3472 = icmp ne i64 %cv3471, 0
  br i1 %cond3472, label %bb_rcprivateown579, label %bb_rcprivateloan579
bb_rcprivateown579:
  %v3473 = load i64, ptr %slot30, align 8
  store i64 %v3473, ptr %slot484, align 8
  %v3474 = load i64, ptr %slot65, align 8
  store i64 %v3474, ptr %slot485, align 8
  %v3475 = load i64, ptr %slot64, align 8
  %v3476 = load i64, ptr %slot484, align 8
  %v3477 = load i64, ptr %slot479, align 8
  %v3478 = load i64, ptr %slot485, align 8
  %cv3479 = trunc i64 %v3478 to i32
  %call3480 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3475, i64 %v3476, i64 %v3477, i32 %cv3479) nomerge, !dbg !146
  store i32 %call3480, ptr %slot486, align 8
  %v3481 = load i32, ptr %slot486, align 8
  %cv3482 = zext i32 %v3481 to i64
  %cond3483 = icmp ne i64 %cv3482, 0
  br i1 %cond3483, label %bb_rcsuccess583, label %bb_rcfailure583
bb_rcfailure583:
  %v3484 = load i64, ptr %slot64, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %call3486 = call i32 @myl_rc_take_failure(ptr %p3485) nomerge, !dbg !146
  store i32 %call3486, ptr %slot487, align 8
  %v3487 = load i64, ptr %slot1, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  %v3489 = load i32, ptr %slot487, align 8
  %call3490 = call i32 @myl_qbe_rc_status(ptr %p3488, i32 %v3489) nomerge, !dbg !146
  store i32 %call3490, ptr %slot488, align 8
  br label %bb_failure
bb_rcsuccess583:
  %v3491 = load i64, ptr %slot17, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  store i32 0, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  %v3493 = load i64, ptr %slot24, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  store i32 2, ptr %p3494, align 4, !alias.scope !3, !noalias !4
  %v3495 = load i64, ptr %slot23, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  store i32 1, ptr %p3496, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared579
bb_rcprivateloan579:
  %v3497 = load i64, ptr %slot30, align 8
  store i64 %v3497, ptr %slot489, align 8
  %v3498 = load i64, ptr %slot64, align 8
  %v3499 = load i64, ptr %slot489, align 8
  %v3500 = load i64, ptr %slot479, align 8
  %call3501 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v3498, i64 %v3499, i64 %v3500) nomerge, !dbg !146
  store i32 %call3501, ptr %slot490, align 8
  %v3502 = load i32, ptr %slot490, align 8
  %cv3503 = zext i32 %v3502 to i64
  %cond3504 = icmp ne i64 %cv3503, 0
  br i1 %cond3504, label %bb_rcsuccess591, label %bb_rcfailure591
bb_rcfailure591:
  %v3505 = load i64, ptr %slot64, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %call3507 = call i32 @myl_rc_take_failure(ptr %p3506) nomerge, !dbg !146
  store i32 %call3507, ptr %slot491, align 8
  %v3508 = load i64, ptr %slot1, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %v3510 = load i32, ptr %slot491, align 8
  %call3511 = call i32 @myl_qbe_rc_status(ptr %p3509, i32 %v3510) nomerge, !dbg !146
  store i32 %call3511, ptr %slot492, align 8
  br label %bb_failure
bb_rcsuccess591:
  %v3512 = load i64, ptr %slot24, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  store i32 2, ptr %p3513, align 4, !alias.scope !3, !noalias !4
  %v3514 = load i64, ptr %slot24, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i32 16, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot23, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  store i32 1, ptr %p3517, align 4, !alias.scope !3, !noalias !4
  %v3518 = load i64, ptr %slot17, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  %ld3520 = load i32, ptr %p3519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3520, ptr %slot493, align 8
  %v3521 = load i32, ptr %slot493, align 8
  %cv3522 = zext i32 %v3521 to i64
  %cond3523 = icmp ne i64 %cv3522, 0
  br i1 %cond3523, label %bb_rcslotdrop599, label %bb_rcslotdone599
bb_rcslotdrop599:
  %v3524 = load i64, ptr %slot17, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  store i32 0, ptr %p3525, align 4, !alias.scope !3, !noalias !4
  %v3526 = load i64, ptr %slot26, align 8
  store i64 %v3526, ptr %slot494, align 8
  %v3527 = load i64, ptr %slot18, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i32, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3529, ptr %slot495, align 8
  %v3530 = load i32, ptr %slot495, align 8
  %op3531 = and i32 %v3530, 28
  store i32 %op3531, ptr %slot496, align 8
  %v3532 = load i32, ptr %slot496, align 8
  %cv3533 = zext i32 %v3532 to i64
  %cond3534 = icmp ne i64 %cv3533, 0
  br i1 %cond3534, label %bb_rcslotrole599, label %bb_rcslotowner599
bb_rcslotrole599:
  %v3535 = load i64, ptr %slot64, align 8
  store i64 %v3535, ptr %slot497, align 8
  %v3536 = load i64, ptr %slot497, align 8
  %v3537 = load i64, ptr %slot494, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3536, i64 %v3537) nomerge, !dbg !146
  br label %bb_rcslotdone599
bb_rcslotowner599:
  %v3538 = load i64, ptr %slot64, align 8
  store i64 %v3538, ptr %slot498, align 8
  %v3539 = load i64, ptr %slot498, align 8
  %v3540 = load i64, ptr %slot494, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3539, i64 %v3540) nomerge, !dbg !146
  br label %bb_rcslotdone599
bb_rcslotdone599:
  br label %bb_rcprivateprepared579
bb_rcprivateprepared579:
  %v3541 = load i64, ptr %slot9, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  %ld3543 = load i32, ptr %p3542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3543, ptr %slot499, align 8
  %v3544 = load i32, ptr %slot499, align 8
  %cv3545 = zext i32 %v3544 to i64
  %cond3546 = icmp ne i64 %cv3545, 0
  br i1 %cond3546, label %bb_rcslotdrop609, label %bb_rcslotdone609
bb_rcslotdrop609:
  %v3547 = load i64, ptr %slot9, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  store i32 0, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  %v3549 = load i64, ptr %slot44, align 8
  store i64 %v3549, ptr %slot500, align 8
  %v3550 = load i64, ptr %slot10, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  %ld3552 = load i32, ptr %p3551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3552, ptr %slot501, align 8
  %v3553 = load i32, ptr %slot501, align 8
  %op3554 = and i32 %v3553, 28
  store i32 %op3554, ptr %slot502, align 8
  %v3555 = load i32, ptr %slot502, align 8
  %cv3556 = zext i32 %v3555 to i64
  %cond3557 = icmp ne i64 %cv3556, 0
  br i1 %cond3557, label %bb_rcslotrole609, label %bb_rcslotowner609
bb_rcslotrole609:
  %v3558 = load i64, ptr %slot64, align 8
  store i64 %v3558, ptr %slot503, align 8
  %v3559 = load i64, ptr %slot503, align 8
  %v3560 = load i64, ptr %slot500, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3559, i64 %v3560) nomerge, !dbg !146
  br label %bb_rcslotdone609
bb_rcslotowner609:
  %v3561 = load i64, ptr %slot64, align 8
  store i64 %v3561, ptr %slot504, align 8
  %v3562 = load i64, ptr %slot504, align 8
  %v3563 = load i64, ptr %slot500, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3562, i64 %v3563) nomerge, !dbg !146
  br label %bb_rcslotdone609
bb_rcslotdone609:
  %v3564 = load i64, ptr %slot44, align 8
  store i64 %v3564, ptr %slot505, align 8
  %v3565 = load i64, ptr %slot30, align 8
  store i64 %v3565, ptr %slot506, align 8
  %v3566 = load i64, ptr %slot506, align 8
  %v3567 = load i64, ptr %slot505, align 8
  %p3568 = inttoptr i64 %v3566 to ptr
  %p3569 = inttoptr i64 %v3567 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3569, ptr %p3568, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3570 = load i64, ptr %slot23, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 0, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot10, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i32 2, ptr %p3573, align 4, !alias.scope !3, !noalias !4
  %v3574 = load i64, ptr %slot24, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %ld3576 = load i32, ptr %p3575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3576, ptr %slot507, align 8
  %v3577 = load i32, ptr %slot507, align 8
  %v3578 = load i64, ptr %slot10, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  store i32 %v3577, ptr %p3579, align 4, !alias.scope !3, !noalias !4
  %v3580 = load i64, ptr %slot9, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  store i32 1, ptr %p3581, align 4, !alias.scope !3, !noalias !4
  %v3582 = load i64, ptr %slot44, align 8
  %v3583 = load i64, ptr %slot52, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i64 %v3582, ptr %p3584, align 8, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot44, align 8
  %v3586 = load i64, ptr %slot53, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  store i64 %v3585, ptr %p3587, align 8, !alias.scope !3, !noalias !4
  %v3588 = load i64, ptr %slot53, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  %ld3590 = load i64, ptr %p3589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3590, ptr %slot508, align 8
  %v3591 = load i64, ptr %slot508, align 8
  %op3592 = add i64 %v3591, 0
  store i64 %op3592, ptr %slot509, align 8
  %v3593 = load i64, ptr %slot509, align 8
  %v3594 = load i64, ptr %slot53, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  store i64 %v3593, ptr %p3595, align 8, !alias.scope !3, !noalias !4
  %v3596 = load i64, ptr %slot53, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  %ld3598 = load i64, ptr %p3597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3598, ptr %slot510, align 8
  %v3599 = load i64, ptr %slot30, align 8
  store i64 %v3599, ptr %slot511, align 8
  %v3600 = load i64, ptr %slot64, align 8
  %v3601 = load i64, ptr %slot511, align 8
  %v3602 = load i64, ptr %slot510, align 8
  %call3603 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v3600, i64 %v3601, i64 %v3602) nomerge, !dbg !148
  store i32 %call3603, ptr %slot512, align 8
  %v3604 = load i32, ptr %slot512, align 8
  %cv3605 = zext i32 %v3604 to i64
  %cond3606 = icmp ne i64 %cv3605, 0
  br i1 %cond3606, label %bb_rcsuccess628, label %bb_rcfailure628
bb_rcfailure628:
  %v3607 = load i64, ptr %slot64, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  %call3609 = call i32 @myl_rc_take_failure(ptr %p3608) nomerge, !dbg !148
  store i32 %call3609, ptr %slot513, align 8
  %v3610 = load i64, ptr %slot1, align 8
  %p3611 = inttoptr i64 %v3610 to ptr
  %v3612 = load i32, ptr %slot513, align 8
  %call3613 = call i32 @myl_qbe_rc_status(ptr %p3611, i32 %v3612) nomerge, !dbg !148
  store i32 %call3613, ptr %slot514, align 8
  br label %bb_failure
bb_rcsuccess628:
  %v3614 = load i64, ptr %slot24, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i32 2, ptr %p3615, align 4, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot24, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  store i32 16, ptr %p3617, align 4, !alias.scope !3, !noalias !4
  %v3618 = load i64, ptr %slot23, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i32 1, ptr %p3619, align 4, !alias.scope !3, !noalias !4
  %v3620 = load i64, ptr %slot19, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot515, align 8
  %v3623 = load i32, ptr %slot515, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcslotdrop636, label %bb_rcslotdone636
bb_rcslotdrop636:
  %v3626 = load i64, ptr %slot19, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i32 0, ptr %p3627, align 4, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot27, align 8
  store i64 %v3628, ptr %slot516, align 8
  %v3629 = load i64, ptr %slot20, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %ld3631 = load i32, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3631, ptr %slot517, align 8
  %v3632 = load i32, ptr %slot517, align 8
  %op3633 = and i32 %v3632, 28
  store i32 %op3633, ptr %slot518, align 8
  %v3634 = load i32, ptr %slot518, align 8
  %cv3635 = zext i32 %v3634 to i64
  %cond3636 = icmp ne i64 %cv3635, 0
  br i1 %cond3636, label %bb_rcslotrole636, label %bb_rcslotowner636
bb_rcslotrole636:
  %v3637 = load i64, ptr %slot64, align 8
  store i64 %v3637, ptr %slot519, align 8
  %v3638 = load i64, ptr %slot519, align 8
  %v3639 = load i64, ptr %slot516, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3638, i64 %v3639) nomerge, !dbg !148
  br label %bb_rcslotdone636
bb_rcslotowner636:
  %v3640 = load i64, ptr %slot64, align 8
  store i64 %v3640, ptr %slot520, align 8
  %v3641 = load i64, ptr %slot520, align 8
  %v3642 = load i64, ptr %slot516, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3641, i64 %v3642) nomerge, !dbg !148
  br label %bb_rcslotdone636
bb_rcslotdone636:
  %v3643 = load i64, ptr %slot27, align 8
  store i64 %v3643, ptr %slot521, align 8
  %v3644 = load i64, ptr %slot30, align 8
  store i64 %v3644, ptr %slot522, align 8
  %v3645 = load i64, ptr %slot522, align 8
  %v3646 = load i64, ptr %slot521, align 8
  %p3647 = inttoptr i64 %v3645 to ptr
  %p3648 = inttoptr i64 %v3646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3648, ptr %p3647, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3649 = load i64, ptr %slot20, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  store i32 2, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  %v3651 = load i64, ptr %slot24, align 8
  %p3652 = inttoptr i64 %v3651 to ptr
  %ld3653 = load i32, ptr %p3652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3653, ptr %slot523, align 8
  %v3654 = load i32, ptr %slot523, align 8
  %v3655 = load i64, ptr %slot20, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  store i32 %v3654, ptr %p3656, align 4, !alias.scope !3, !noalias !4
  %v3657 = load i64, ptr %slot23, align 8
  %p3658 = inttoptr i64 %v3657 to ptr
  store i32 0, ptr %p3658, align 4, !alias.scope !3, !noalias !4
  %v3659 = load i64, ptr %slot19, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  store i32 1, ptr %p3660, align 4, !alias.scope !3, !noalias !4
  %v3661 = load i64, ptr %slot521, align 8
  %v3662 = load i64, ptr %slot53, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  store i64 %v3661, ptr %p3663, align 8, !alias.scope !3, !noalias !4
  %v3664 = load i64, ptr %slot45, align 8
  %v3665 = load i64, ptr %slot54, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  store i64 %v3664, ptr %p3666, align 8, !alias.scope !3, !noalias !4
  %v3667 = load i64, ptr %slot54, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  %ld3669 = load i64, ptr %p3668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3669, ptr %slot524, align 8
  %v3670 = load i64, ptr %slot21, align 8
  %p3671 = inttoptr i64 %v3670 to ptr
  %ld3672 = load i32, ptr %p3671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3672, ptr %slot525, align 8
  %v3673 = load i64, ptr %slot22, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i32, ptr %p3674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3675, ptr %slot526, align 8
  %v3676 = load i32, ptr %slot526, align 8
  %op3677 = and i32 %v3676, 24
  store i32 %op3677, ptr %slot526, align 8
  %v3678 = load i32, ptr %slot526, align 8
  %cmp3679 = icmp eq i32 %v3678, 0
  %cv3680 = zext i1 %cmp3679 to i32
  store i32 %cv3680, ptr %slot527, align 8
  %v3681 = load i32, ptr %slot525, align 8
  %v3682 = load i32, ptr %slot527, align 8
  %op3683 = and i32 %v3681, %v3682
  store i32 %op3683, ptr %slot528, align 8
  %v3684 = load i64, ptr %slot65, align 8
  store i64 %v3684, ptr %slot529, align 8
  %v3685 = load i32, ptr %slot528, align 8
  %op3686 = mul i32 %v3685, 4
  store i32 %op3686, ptr %slot530, align 8
  %v3687 = load i32, ptr %slot530, align 8
  %op3688 = or i32 %v3687, 0
  store i32 %op3688, ptr %slot531, align 8
  %v3689 = load i64, ptr %slot30, align 8
  store i64 %v3689, ptr %slot532, align 8
  %v3690 = load i64, ptr %slot64, align 8
  %v3691 = load i64, ptr %slot532, align 8
  %v3692 = load i64, ptr %slot524, align 8
  %v3693 = load i64, ptr %slot529, align 8
  %cv3694 = trunc i64 %v3693 to i32
  %v3695 = load i32, ptr %slot531, align 8
  %call3696 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_publish(i64 %v3690, i64 %v3691, i64 %v3692, i32 %cv3694, i32 %v3695) nomerge, !dbg !150
  store i32 %call3696, ptr %slot533, align 8
  %v3697 = load i32, ptr %slot533, align 8
  %cv3698 = zext i32 %v3697 to i64
  %cond3699 = icmp ne i64 %cv3698, 0
  br i1 %cond3699, label %bb_rcsuccess665, label %bb_rcfailure665
bb_rcfailure665:
  %v3700 = load i64, ptr %slot64, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %call3702 = call i32 @myl_rc_take_failure(ptr %p3701) nomerge, !dbg !150
  store i32 %call3702, ptr %slot534, align 8
  %v3703 = load i64, ptr %slot1, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  %v3705 = load i32, ptr %slot534, align 8
  %call3706 = call i32 @myl_qbe_rc_status(ptr %p3704, i32 %v3705) nomerge, !dbg !150
  store i32 %call3706, ptr %slot535, align 8
  br label %bb_failure
bb_rcsuccess665:
  %v3707 = load i32, ptr %slot528, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rchtaken668, label %bb_rchcopied668
bb_rchcopied668:
  %v3710 = load i64, ptr %slot21, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %ld3712 = load i32, ptr %p3711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3712, ptr %slot536, align 8
  %v3713 = load i32, ptr %slot536, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcslotdrop671, label %bb_rcslotdone671
bb_rcslotdrop671:
  %v3716 = load i64, ptr %slot21, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  store i32 0, ptr %p3717, align 4, !alias.scope !3, !noalias !4
  %v3718 = load i64, ptr %slot28, align 8
  store i64 %v3718, ptr %slot537, align 8
  %v3719 = load i64, ptr %slot22, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i32, ptr %p3720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3721, ptr %slot538, align 8
  %v3722 = load i32, ptr %slot538, align 8
  %op3723 = and i32 %v3722, 28
  store i32 %op3723, ptr %slot539, align 8
  %v3724 = load i32, ptr %slot539, align 8
  %cv3725 = zext i32 %v3724 to i64
  %cond3726 = icmp ne i64 %cv3725, 0
  br i1 %cond3726, label %bb_rcslotrole671, label %bb_rcslotowner671
bb_rcslotrole671:
  %v3727 = load i64, ptr %slot64, align 8
  store i64 %v3727, ptr %slot540, align 8
  %v3728 = load i64, ptr %slot540, align 8
  %v3729 = load i64, ptr %slot537, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3728, i64 %v3729) nomerge, !dbg !150
  br label %bb_rcslotdone671
bb_rcslotowner671:
  %v3730 = load i64, ptr %slot64, align 8
  store i64 %v3730, ptr %slot541, align 8
  %v3731 = load i64, ptr %slot541, align 8
  %v3732 = load i64, ptr %slot537, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v3731, i64 %v3732) nomerge, !dbg !150
  br label %bb_rcslotdone671
bb_rcslotdone671:
  br label %bb_rchprepared668
bb_rchtaken668:
  %v3733 = load i64, ptr %slot21, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  store i32 0, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared668
bb_rchprepared668:
  %v3735 = load i64, ptr %slot24, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  store i32 2, ptr %p3736, align 4, !alias.scope !3, !noalias !4
  %v3737 = load i64, ptr %slot23, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  store i32 1, ptr %p3738, align 4, !alias.scope !3, !noalias !4
  %v3739 = load i64, ptr %slot28, align 8
  store i64 %v3739, ptr %slot542, align 8
  %v3740 = load i64, ptr %slot30, align 8
  store i64 %v3740, ptr %slot543, align 8
  %v3741 = load i64, ptr %slot543, align 8
  %v3742 = load i64, ptr %slot542, align 8
  %p3743 = inttoptr i64 %v3741 to ptr
  %p3744 = inttoptr i64 %v3742 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3744, ptr %p3743, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3745 = load i64, ptr %slot22, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  store i32 2, ptr %p3746, align 4, !alias.scope !3, !noalias !4
  %v3747 = load i64, ptr %slot24, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  %ld3749 = load i32, ptr %p3748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3749, ptr %slot544, align 8
  %v3750 = load i32, ptr %slot544, align 8
  %v3751 = load i64, ptr %slot22, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  store i32 %v3750, ptr %p3752, align 4, !alias.scope !3, !noalias !4
  %v3753 = load i64, ptr %slot23, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  store i32 0, ptr %p3754, align 4, !alias.scope !3, !noalias !4
  %v3755 = load i64, ptr %slot21, align 8
  %p3756 = inttoptr i64 %v3755 to ptr
  store i32 1, ptr %p3756, align 4, !alias.scope !3, !noalias !4
  %v3757 = load i64, ptr %slot542, align 8
  %v3758 = load i64, ptr %slot54, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i64 %v3757, ptr %p3759, align 8, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot53, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  %ld3762 = load i64, ptr %p3761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3762, ptr %slot545, align 8
  %v3763 = load i64, ptr %slot19, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  %ld3765 = load i32, ptr %p3764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3765, ptr %slot546, align 8
  %v3766 = load i64, ptr %slot20, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  %ld3768 = load i32, ptr %p3767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3768, ptr %slot547, align 8
  %v3769 = load i32, ptr %slot547, align 8
  %op3770 = and i32 %v3769, 24
  store i32 %op3770, ptr %slot547, align 8
  %v3771 = load i32, ptr %slot547, align 8
  %cmp3772 = icmp eq i32 %v3771, 0
  %cv3773 = zext i1 %cmp3772 to i32
  store i32 %cv3773, ptr %slot548, align 8
  %v3774 = load i32, ptr %slot546, align 8
  %v3775 = load i32, ptr %slot548, align 8
  %op3776 = and i32 %v3774, %v3775
  store i32 %op3776, ptr %slot549, align 8
  %v3777 = load i32, ptr %slot549, align 8
  %cv3778 = zext i32 %v3777 to i64
  %cond3779 = icmp ne i64 %cv3778, 0
  br i1 %cond3779, label %bb_rctake690, label %bb_rccopy690
bb_rctake690:
  %v3780 = load i64, ptr %slot30, align 8
  store i64 %v3780, ptr %slot550, align 8
  %v3781 = load i64, ptr %slot65, align 8
  store i64 %v3781, ptr %slot551, align 8
  %v3782 = load i64, ptr %slot545, align 8
  %v3783 = load i64, ptr %slot550, align 8
  %op3784 = sub i64 %v3782, %v3783
  store i64 %op3784, ptr %slot552, align 8
  %v3785 = load i64, ptr %slot550, align 8
  %v3786 = load i64, ptr %slot545, align 8
  %op3787 = sub i64 %v3785, %v3786
  store i64 %op3787, ptr %slot553, align 8
  %v3788 = load i64, ptr %slot552, align 8
  %cmp3789 = icmp ult i64 %v3788, 48
  %cv3790 = zext i1 %cmp3789 to i32
  store i32 %cv3790, ptr %slot554, align 8
  %v3791 = load i64, ptr %slot553, align 8
  %cmp3792 = icmp ult i64 %v3791, 48
  %cv3793 = zext i1 %cmp3792 to i32
  store i32 %cv3793, ptr %slot555, align 8
  %v3794 = load i32, ptr %slot554, align 8
  %v3795 = load i32, ptr %slot555, align 8
  %op3796 = or i32 %v3794, %v3795
  store i32 %op3796, ptr %slot556, align 8
  %v3797 = load i32, ptr %slot556, align 8
  %cv3798 = zext i32 %v3797 to i64
  %cond3799 = icmp ne i64 %cv3798, 0
  br i1 %cond3799, label %bb_rcmoveslow699, label %bb_rcmovecheck699
bb_rcmovecheck699:
  %v3800 = load i64, ptr %slot545, align 8
  %op3801 = add i64 %v3800, 16
  store i64 %op3801, ptr %slot557, align 8
  %v3802 = load i64, ptr %slot557, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  %ld3804 = load i64, ptr %p3803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3804, ptr %slot558, align 8
  %v3805 = load i64, ptr %slot558, align 8
  %cmp3806 = icmp ne i64 %v3805, 0
  %cv3807 = zext i1 %cmp3806 to i32
  store i32 %cv3807, ptr %slot559, align 8
  %v3808 = load i32, ptr %slot559, align 8
  %cv3809 = zext i32 %v3808 to i64
  %cond3810 = icmp ne i64 %cv3809, 0
  br i1 %cond3810, label %bb_rcmoveheader707, label %bb_rcmovenext707
bb_rcmoveheader707:
  %v3811 = load i64, ptr %slot558, align 8
  %op3812 = sub i64 %v3811, 16
  store i64 %op3812, ptr %slot560, align 8
  %v3813 = load i64, ptr %slot558, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  %rgep3815 = getelementptr i8, ptr %p3814, i64 -16
  %ld3816 = load i64, ptr %rgep3815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3816, ptr %slot561, align 8
  %v3817 = load i64, ptr %slot561, align 8
  %op3818 = and i64 %v3817, 5764607523034234881
  store i64 %op3818, ptr %slot562, align 8
  %v3819 = load i64, ptr %slot562, align 8
  %cmp3820 = icmp ne i64 %v3819, 0
  %cv3821 = zext i1 %cmp3820 to i32
  store i32 %cv3821, ptr %slot563, align 8
  %v3822 = load i32, ptr %slot563, align 8
  %cv3823 = zext i32 %v3822 to i64
  %cond3824 = icmp ne i64 %cv3823, 0
  br i1 %cond3824, label %bb_rcmoveslow699, label %bb_rcmovenext707
bb_rcmovenext707:
  %v3825 = load i64, ptr %slot545, align 8
  %op3826 = add i64 %v3825, 24
  store i64 %op3826, ptr %slot564, align 8
  %v3827 = load i64, ptr %slot564, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  %ld3829 = load i64, ptr %p3828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3829, ptr %slot565, align 8
  %v3830 = load i64, ptr %slot565, align 8
  %cmp3831 = icmp ne i64 %v3830, 0
  %cv3832 = zext i1 %cmp3831 to i32
  store i32 %cv3832, ptr %slot566, align 8
  %v3833 = load i32, ptr %slot566, align 8
  %cv3834 = zext i32 %v3833 to i64
  %cond3835 = icmp ne i64 %cv3834, 0
  br i1 %cond3835, label %bb_rcmoveheader715, label %bb_rcmovenext715
bb_rcmoveheader715:
  %v3836 = load i64, ptr %slot565, align 8
  %op3837 = sub i64 %v3836, 16
  store i64 %op3837, ptr %slot567, align 8
  %v3838 = load i64, ptr %slot565, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  %rgep3840 = getelementptr i8, ptr %p3839, i64 -16
  %ld3841 = load i64, ptr %rgep3840, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3841, ptr %slot568, align 8
  %v3842 = load i64, ptr %slot568, align 8
  %op3843 = and i64 %v3842, 5764607523034234881
  store i64 %op3843, ptr %slot569, align 8
  %v3844 = load i64, ptr %slot569, align 8
  %cmp3845 = icmp ne i64 %v3844, 0
  %cv3846 = zext i1 %cmp3845 to i32
  store i32 %cv3846, ptr %slot570, align 8
  %v3847 = load i32, ptr %slot570, align 8
  %cv3848 = zext i32 %v3847 to i64
  %cond3849 = icmp ne i64 %cv3848, 0
  br i1 %cond3849, label %bb_rcmoveslow699, label %bb_rcmovenext715
bb_rcmovenext715:
  %v3850 = load i64, ptr %slot545, align 8
  %op3851 = add i64 %v3850, 32
  store i64 %op3851, ptr %slot571, align 8
  %v3852 = load i64, ptr %slot571, align 8
  %p3853 = inttoptr i64 %v3852 to ptr
  %ld3854 = load i64, ptr %p3853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3854, ptr %slot572, align 8
  %v3855 = load i64, ptr %slot572, align 8
  %cmp3856 = icmp ne i64 %v3855, 0
  %cv3857 = zext i1 %cmp3856 to i32
  store i32 %cv3857, ptr %slot573, align 8
  %v3858 = load i32, ptr %slot573, align 8
  %cv3859 = zext i32 %v3858 to i64
  %cond3860 = icmp ne i64 %cv3859, 0
  br i1 %cond3860, label %bb_rcmoveheader723, label %bb_rcmovenext723
bb_rcmoveheader723:
  %v3861 = load i64, ptr %slot572, align 8
  %op3862 = sub i64 %v3861, 16
  store i64 %op3862, ptr %slot574, align 8
  %v3863 = load i64, ptr %slot572, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %rgep3865 = getelementptr i8, ptr %p3864, i64 -16
  %ld3866 = load i64, ptr %rgep3865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3866, ptr %slot575, align 8
  %v3867 = load i64, ptr %slot575, align 8
  %op3868 = and i64 %v3867, 5764607523034234881
  store i64 %op3868, ptr %slot576, align 8
  %v3869 = load i64, ptr %slot576, align 8
  %cmp3870 = icmp ne i64 %v3869, 0
  %cv3871 = zext i1 %cmp3870 to i32
  store i32 %cv3871, ptr %slot577, align 8
  %v3872 = load i32, ptr %slot577, align 8
  %cv3873 = zext i32 %v3872 to i64
  %cond3874 = icmp ne i64 %cv3873, 0
  br i1 %cond3874, label %bb_rcmoveslow699, label %bb_rcmovenext723
bb_rcmovenext723:
  %v3875 = load i64, ptr %slot545, align 8
  %v3876 = load i64, ptr %slot550, align 8
  %p3877 = inttoptr i64 %v3875 to ptr
  %p3878 = inttoptr i64 %v3876 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3878, ptr %p3877, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot545, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  store i64 0, ptr %p3880, align 8, !alias.scope !3, !noalias !4
  %v3881 = load i64, ptr %slot545, align 8
  %op3882 = add i64 %v3881, 8
  store i64 %op3882, ptr %slot578, align 8
  %v3883 = load i64, ptr %slot578, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  store i64 0, ptr %p3884, align 8, !alias.scope !3, !noalias !4
  %v3885 = load i64, ptr %slot545, align 8
  %op3886 = add i64 %v3885, 16
  store i64 %op3886, ptr %slot579, align 8
  %v3887 = load i64, ptr %slot579, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  store i64 0, ptr %p3888, align 8, !alias.scope !3, !noalias !4
  %v3889 = load i64, ptr %slot545, align 8
  %op3890 = add i64 %v3889, 24
  store i64 %op3890, ptr %slot580, align 8
  %v3891 = load i64, ptr %slot580, align 8
  %p3892 = inttoptr i64 %v3891 to ptr
  store i64 0, ptr %p3892, align 8, !alias.scope !3, !noalias !4
  %v3893 = load i64, ptr %slot545, align 8
  %op3894 = add i64 %v3893, 32
  store i64 %op3894, ptr %slot581, align 8
  %v3895 = load i64, ptr %slot581, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i64 0, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  %v3897 = load i64, ptr %slot545, align 8
  %op3898 = add i64 %v3897, 40
  store i64 %op3898, ptr %slot582, align 8
  %v3899 = load i64, ptr %slot582, align 8
  %p3900 = inttoptr i64 %v3899 to ptr
  store i64 0, ptr %p3900, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved699
bb_rcmoveslow699:
  %v3901 = load i64, ptr %slot64, align 8
  %v3902 = load i64, ptr %slot550, align 8
  %v3903 = load i64, ptr %slot545, align 8
  %v3904 = load i64, ptr %slot551, align 8
  %cv3905 = trunc i64 %v3904 to i32
  %call3906 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3901, i64 %v3902, i64 %v3903, i32 %cv3905) nomerge, !dbg !152
  store i32 %call3906, ptr %slot583, align 8
  %v3907 = load i32, ptr %slot583, align 8
  %cv3908 = zext i32 %v3907 to i64
  %cond3909 = icmp ne i64 %cv3908, 0
  br i1 %cond3909, label %bb_rcsuccess735, label %bb_rcfailure735
bb_rcfailure735:
  %v3910 = load i64, ptr %slot64, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  %call3912 = call i32 @myl_rc_take_failure(ptr %p3911) nomerge, !dbg !152
  store i32 %call3912, ptr %slot584, align 8
  %v3913 = load i64, ptr %slot1, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %v3915 = load i32, ptr %slot584, align 8
  %call3916 = call i32 @myl_qbe_rc_status(ptr %p3914, i32 %v3915) nomerge, !dbg !152
  store i32 %call3916, ptr %slot585, align 8
  br label %bb_failure
bb_rcsuccess735:
  br label %bb_rcmoved699
bb_rcmoved699:
  %v3917 = load i64, ptr %slot19, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  store i32 0, ptr %p3918, align 4, !alias.scope !3, !noalias !4
  %v3919 = load i64, ptr %slot24, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  store i32 2, ptr %p3920, align 4, !alias.scope !3, !noalias !4
  %v3921 = load i64, ptr %slot23, align 8
  %p3922 = inttoptr i64 %v3921 to ptr
  store i32 1, ptr %p3922, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared690
bb_rccopy690:
  %v3923 = load i64, ptr %slot30, align 8
  store i64 %v3923, ptr %slot586, align 8
  %v3924 = load i64, ptr %slot65, align 8
  store i64 %v3924, ptr %slot587, align 8
  %v3925 = load i64, ptr %slot64, align 8
  %v3926 = load i64, ptr %slot586, align 8
  %v3927 = load i64, ptr %slot545, align 8
  %v3928 = load i64, ptr %slot587, align 8
  %cv3929 = trunc i64 %v3928 to i32
  %call3930 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v3925, i64 %v3926, i64 %v3927, i32 %cv3929) nomerge, !dbg !152
  store i32 %call3930, ptr %slot588, align 8
  %v3931 = load i32, ptr %slot588, align 8
  %cv3932 = zext i32 %v3931 to i64
  %cond3933 = icmp ne i64 %cv3932, 0
  br i1 %cond3933, label %bb_rcsuccess744, label %bb_rcfailure744
bb_rcfailure744:
  %v3934 = load i64, ptr %slot64, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  %call3936 = call i32 @myl_rc_take_failure(ptr %p3935) nomerge, !dbg !152
  store i32 %call3936, ptr %slot589, align 8
  %v3937 = load i64, ptr %slot1, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %v3939 = load i32, ptr %slot589, align 8
  %call3940 = call i32 @myl_qbe_rc_status(ptr %p3938, i32 %v3939) nomerge, !dbg !152
  store i32 %call3940, ptr %slot590, align 8
  br label %bb_failure
bb_rcsuccess744:
  %v3941 = load i64, ptr %slot24, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  store i32 2, ptr %p3942, align 4, !alias.scope !3, !noalias !4
  %v3943 = load i64, ptr %slot23, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  store i32 1, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  %v3945 = load i64, ptr %slot19, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  %ld3947 = load i32, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3947, ptr %slot591, align 8
  %v3948 = load i32, ptr %slot591, align 8
  %cv3949 = zext i32 %v3948 to i64
  %cond3950 = icmp ne i64 %cv3949, 0
  br i1 %cond3950, label %bb_rcslotdrop751, label %bb_rcslotdone751
bb_rcslotdrop751:
  %v3951 = load i64, ptr %slot19, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  store i32 0, ptr %p3952, align 4, !alias.scope !3, !noalias !4
  %v3953 = load i64, ptr %slot27, align 8
  store i64 %v3953, ptr %slot592, align 8
  %v3954 = load i64, ptr %slot20, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %ld3956 = load i32, ptr %p3955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3956, ptr %slot593, align 8
  %v3957 = load i32, ptr %slot593, align 8
  %op3958 = and i32 %v3957, 28
  store i32 %op3958, ptr %slot594, align 8
  %v3959 = load i32, ptr %slot594, align 8
  %cv3960 = zext i32 %v3959 to i64
  %cond3961 = icmp ne i64 %cv3960, 0
  br i1 %cond3961, label %bb_rcslotrole751, label %bb_rcslotowner751
bb_rcslotrole751:
  %v3962 = load i64, ptr %slot64, align 8
  store i64 %v3962, ptr %slot595, align 8
  %v3963 = load i64, ptr %slot595, align 8
  %v3964 = load i64, ptr %slot592, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3963, i64 %v3964) nomerge, !dbg !152
  br label %bb_rcslotdone751
bb_rcslotowner751:
  %v3965 = load i64, ptr %slot64, align 8
  store i64 %v3965, ptr %slot596, align 8
  %v3966 = load i64, ptr %slot596, align 8
  %v3967 = load i64, ptr %slot592, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3966, i64 %v3967) nomerge, !dbg !152
  br label %bb_rcslotdone751
bb_rcslotdone751:
  br label %bb_rcprepared690
bb_rcprepared690:
  %v3968 = load i64, ptr %slot30, align 8
  store i64 %v3968, ptr %slot597, align 8
  %v3969 = load i64, ptr %slot55, align 8
  store i64 %v3969, ptr %slot598, align 8
  %v3970 = load i64, ptr %slot597, align 8
  %v3971 = load i64, ptr %slot598, align 8
  %p3972 = inttoptr i64 %v3970 to ptr
  %p3973 = inttoptr i64 %v3971 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3973, ptr %p3972, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot23, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  store i32 0, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  %v3976 = load i64, ptr %slot25, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  store i32 1, ptr %p3977, align 4, !alias.scope !3, !noalias !4
  %v3978 = load i64, ptr %slot65, align 8
  store i64 %v3978, ptr %slot599, align 8
  %v3979 = load i64, ptr %slot54, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  %ld3981 = load i64, ptr %p3980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3981, ptr %slot600, align 8
  %v3982 = load i64, ptr %slot598, align 8
  %p3984 = inttoptr i64 %v3982 to ptr
  %gep3985 = getelementptr i8, ptr %p3984, i64 16
  %op3983 = ptrtoint ptr %gep3985 to i64
  store i64 %op3983, ptr %slot601, align 8
  %v3986 = load i64, ptr %slot30, align 8
  store i64 %v3986, ptr %slot602, align 8
  %v3987 = load i64, ptr %slot54, align 8
  %p3988 = inttoptr i64 %v3987 to ptr
  %ld3989 = load i64, ptr %p3988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3989, ptr %slot603, align 8
  %v3990 = load i64, ptr %slot30, align 8
  store i64 %v3990, ptr %slot604, align 8
  %v3991 = load i64, ptr %slot65, align 8
  store i64 %v3991, ptr %slot605, align 8
  %v3992 = load i64, ptr %slot603, align 8
  %op3993 = add i64 %v3992, 0
  store i64 %op3993, ptr %slot606, align 8
  %v3994 = load i64, ptr %slot606, align 8
  %p3995 = inttoptr i64 %v3994 to ptr
  %ld3996 = load i64, ptr %p3995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3996, ptr %slot607, align 8
  %v3997 = load i64, ptr %slot607, align 8
  %cmp3998 = icmp ne i64 %v3997, 0
  %cv3999 = zext i1 %cmp3998 to i32
  store i32 %cv3999, ptr %slot608, align 8
  %v4000 = load i32, ptr %slot608, align 8
  %cv4001 = zext i32 %v4000 to i64
  %cond4002 = icmp ne i64 %cv4001, 0
  br i1 %cond4002, label %bb_rcmoveheader773, label %bb_rcmovenext773
bb_rcmoveheader773:
  %v4003 = load i64, ptr %slot607, align 8
  %op4004 = sub i64 %v4003, 16
  store i64 %op4004, ptr %slot609, align 8
  %v4005 = load i64, ptr %slot607, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  %rgep4007 = getelementptr i8, ptr %p4006, i64 -16
  %ld4008 = load i64, ptr %rgep4007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4008, ptr %slot610, align 8
  %v4009 = load i64, ptr %slot610, align 8
  %op4010 = and i64 %v4009, 5764607523034234881
  store i64 %op4010, ptr %slot611, align 8
  %v4011 = load i64, ptr %slot611, align 8
  %cmp4012 = icmp ne i64 %v4011, 0
  %cv4013 = zext i1 %cmp4012 to i32
  store i32 %cv4013, ptr %slot612, align 8
  %v4014 = load i32, ptr %slot612, align 8
  %cv4015 = zext i32 %v4014 to i64
  %cond4016 = icmp ne i64 %cv4015, 0
  br i1 %cond4016, label %bb_rcmoveslow770, label %bb_rcmovenext773
bb_rcmovenext773:
  %v4017 = load i64, ptr %slot603, align 8
  %op4018 = add i64 %v4017, 8
  store i64 %op4018, ptr %slot613, align 8
  %v4019 = load i64, ptr %slot613, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %ld4021 = load i64, ptr %p4020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4021, ptr %slot614, align 8
  %v4022 = load i64, ptr %slot614, align 8
  %cmp4023 = icmp ne i64 %v4022, 0
  %cv4024 = zext i1 %cmp4023 to i32
  store i32 %cv4024, ptr %slot615, align 8
  %v4025 = load i32, ptr %slot615, align 8
  %cv4026 = zext i32 %v4025 to i64
  %cond4027 = icmp ne i64 %cv4026, 0
  br i1 %cond4027, label %bb_rcmoveheader781, label %bb_rcmovenext781
bb_rcmoveheader781:
  %v4028 = load i64, ptr %slot614, align 8
  %op4029 = sub i64 %v4028, 16
  store i64 %op4029, ptr %slot616, align 8
  %v4030 = load i64, ptr %slot614, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %rgep4032 = getelementptr i8, ptr %p4031, i64 -16
  %ld4033 = load i64, ptr %rgep4032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4033, ptr %slot617, align 8
  %v4034 = load i64, ptr %slot617, align 8
  %op4035 = and i64 %v4034, 5764607523034234881
  store i64 %op4035, ptr %slot618, align 8
  %v4036 = load i64, ptr %slot618, align 8
  %cmp4037 = icmp ne i64 %v4036, 0
  %cv4038 = zext i1 %cmp4037 to i32
  store i32 %cv4038, ptr %slot619, align 8
  %v4039 = load i32, ptr %slot619, align 8
  %cv4040 = zext i32 %v4039 to i64
  %cond4041 = icmp ne i64 %cv4040, 0
  br i1 %cond4041, label %bb_rcmoveslow770, label %bb_rcmovenext781
bb_rcmovenext781:
  %v4042 = load i64, ptr %slot603, align 8
  %op4043 = add i64 %v4042, 16
  store i64 %op4043, ptr %slot620, align 8
  %v4044 = load i64, ptr %slot620, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  %ld4046 = load i64, ptr %p4045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4046, ptr %slot621, align 8
  %v4047 = load i64, ptr %slot621, align 8
  %cmp4048 = icmp ne i64 %v4047, 0
  %cv4049 = zext i1 %cmp4048 to i32
  store i32 %cv4049, ptr %slot622, align 8
  %v4050 = load i32, ptr %slot622, align 8
  %cv4051 = zext i32 %v4050 to i64
  %cond4052 = icmp ne i64 %cv4051, 0
  br i1 %cond4052, label %bb_rcmoveheader789, label %bb_rcmovenext789
bb_rcmoveheader789:
  %v4053 = load i64, ptr %slot621, align 8
  %op4054 = sub i64 %v4053, 16
  store i64 %op4054, ptr %slot623, align 8
  %v4055 = load i64, ptr %slot621, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  %rgep4057 = getelementptr i8, ptr %p4056, i64 -16
  %ld4058 = load i64, ptr %rgep4057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4058, ptr %slot624, align 8
  %v4059 = load i64, ptr %slot624, align 8
  %op4060 = and i64 %v4059, 5764607523034234881
  store i64 %op4060, ptr %slot625, align 8
  %v4061 = load i64, ptr %slot625, align 8
  %cmp4062 = icmp ne i64 %v4061, 0
  %cv4063 = zext i1 %cmp4062 to i32
  store i32 %cv4063, ptr %slot626, align 8
  %v4064 = load i32, ptr %slot626, align 8
  %cv4065 = zext i32 %v4064 to i64
  %cond4066 = icmp ne i64 %cv4065, 0
  br i1 %cond4066, label %bb_rcmoveslow770, label %bb_rcmovenext789
bb_rcmovenext789:
  %v4067 = load i64, ptr %slot603, align 8
  %v4068 = load i64, ptr %slot604, align 8
  %p4069 = inttoptr i64 %v4067 to ptr
  %p4070 = inttoptr i64 %v4068 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4070, ptr %p4069, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot603, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  store i64 0, ptr %p4072, align 8, !alias.scope !3, !noalias !4
  %v4073 = load i64, ptr %slot603, align 8
  %op4074 = add i64 %v4073, 8
  store i64 %op4074, ptr %slot627, align 8
  %v4075 = load i64, ptr %slot627, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  store i64 0, ptr %p4076, align 8, !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot603, align 8
  %op4078 = add i64 %v4077, 16
  store i64 %op4078, ptr %slot628, align 8
  %v4079 = load i64, ptr %slot628, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  store i64 0, ptr %p4080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved770
bb_rcmoveslow770:
  %v4081 = load i64, ptr %slot64, align 8
  %v4082 = load i64, ptr %slot604, align 8
  %v4083 = load i64, ptr %slot603, align 8
  %v4084 = load i64, ptr %slot605, align 8
  %cv4085 = trunc i64 %v4084 to i32
  %call4086 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v4081, i64 %v4082, i64 %v4083, i32 %cv4085) nomerge, !dbg !152
  store i32 %call4086, ptr %slot629, align 8
  %v4087 = load i32, ptr %slot629, align 8
  %cv4088 = zext i32 %v4087 to i64
  %cond4089 = icmp ne i64 %cv4088, 0
  br i1 %cond4089, label %bb_rcsuccess798, label %bb_rcfailure798
bb_rcfailure798:
  %v4090 = load i64, ptr %slot64, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %call4092 = call i32 @myl_rc_take_failure(ptr %p4091) nomerge, !dbg !152
  store i32 %call4092, ptr %slot630, align 8
  %v4093 = load i64, ptr %slot1, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  %v4095 = load i32, ptr %slot630, align 8
  %call4096 = call i32 @myl_qbe_rc_status(ptr %p4094, i32 %v4095) nomerge, !dbg !152
  store i32 %call4096, ptr %slot631, align 8
  br label %bb_failure
bb_rcsuccess798:
  br label %bb_rcmoved770
bb_rcmoved770:
  %v4097 = load i64, ptr %slot21, align 8
  %p4098 = inttoptr i64 %v4097 to ptr
  store i32 0, ptr %p4098, align 4, !alias.scope !3, !noalias !4
  %v4099 = load i64, ptr %slot24, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i32 2, ptr %p4100, align 4, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot23, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  store i32 1, ptr %p4102, align 4, !alias.scope !3, !noalias !4
  %v4103 = load i64, ptr %slot30, align 8
  store i64 %v4103, ptr %slot632, align 8
  %v4104 = load i64, ptr %slot632, align 8
  %v4105 = load i64, ptr %slot602, align 8
  %p4106 = inttoptr i64 %v4104 to ptr
  %p4107 = inttoptr i64 %v4105 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4107, ptr %p4106, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4108 = load i64, ptr %slot23, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  store i32 0, ptr %p4109, align 4, !alias.scope !3, !noalias !4
  %v4110 = load i64, ptr %slot24, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  store i32 2, ptr %p4111, align 4, !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot23, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i32 1, ptr %p4113, align 4, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot64, align 8
  store i64 %v4114, ptr %slot633, align 8
  %v4115 = load i64, ptr %slot633, align 8
  %v4116 = load i64, ptr %slot601, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v4115, i64 %v4116) nomerge, !dbg !152
  %v4117 = load i64, ptr %slot602, align 8
  %v4118 = load i64, ptr %slot601, align 8
  %p4119 = inttoptr i64 %v4117 to ptr
  %p4120 = inttoptr i64 %v4118 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4120, ptr %p4119, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4121 = load i64, ptr %slot23, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  store i32 0, ptr %p4122, align 4, !alias.scope !3, !noalias !4
  %v4123 = load i64, ptr %slot598, align 8
  %v4124 = load i64, ptr %slot53, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  store i64 %v4123, ptr %p4125, align 8, !alias.scope !3, !noalias !4
  %v4126 = load i64, ptr %slot53, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  %ld4128 = load i64, ptr %p4127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4128, ptr %slot634, align 8
  %v4129 = load i64, ptr %slot30, align 8
  store i64 %v4129, ptr %slot635, align 8
  %v4130 = load i64, ptr %slot634, align 8
  %v4131 = load i64, ptr %slot635, align 8
  %p4132 = inttoptr i64 %v4130 to ptr
  %p4133 = inttoptr i64 %v4131 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4133, ptr %p4132, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot24, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  store i32 2, ptr %p4135, align 4, !alias.scope !3, !noalias !4
  %v4136 = load i64, ptr %slot23, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  store i32 1, ptr %p4137, align 4, !alias.scope !3, !noalias !4
  %v4138 = load i64, ptr %slot19, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  %ld4140 = load i32, ptr %p4139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4140, ptr %slot636, align 8
  %v4141 = load i32, ptr %slot636, align 8
  %cv4142 = zext i32 %v4141 to i64
  %cond4143 = icmp ne i64 %cv4142, 0
  br i1 %cond4143, label %bb_rcslotdrop816, label %bb_rcslotdone816
bb_rcslotdrop816:
  %v4144 = load i64, ptr %slot19, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i32 0, ptr %p4145, align 4, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot27, align 8
  store i64 %v4146, ptr %slot637, align 8
  %v4147 = load i64, ptr %slot20, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  %ld4149 = load i32, ptr %p4148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4149, ptr %slot638, align 8
  %v4150 = load i32, ptr %slot638, align 8
  %op4151 = and i32 %v4150, 28
  store i32 %op4151, ptr %slot639, align 8
  %v4152 = load i32, ptr %slot639, align 8
  %cv4153 = zext i32 %v4152 to i64
  %cond4154 = icmp ne i64 %cv4153, 0
  br i1 %cond4154, label %bb_rcslotrole816, label %bb_rcslotowner816
bb_rcslotrole816:
  %v4155 = load i64, ptr %slot64, align 8
  store i64 %v4155, ptr %slot640, align 8
  %v4156 = load i64, ptr %slot640, align 8
  %v4157 = load i64, ptr %slot637, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4156, i64 %v4157) nomerge, !dbg !152
  br label %bb_rcslotdone816
bb_rcslotowner816:
  %v4158 = load i64, ptr %slot64, align 8
  store i64 %v4158, ptr %slot641, align 8
  %v4159 = load i64, ptr %slot641, align 8
  %v4160 = load i64, ptr %slot637, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4159, i64 %v4160) nomerge, !dbg !152
  br label %bb_rcslotdone816
bb_rcslotdone816:
  %v4161 = load i64, ptr %slot21, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %ld4163 = load i32, ptr %p4162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4163, ptr %slot642, align 8
  %v4164 = load i32, ptr %slot642, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcslotdrop825, label %bb_rcslotdone825
bb_rcslotdrop825:
  %v4167 = load i64, ptr %slot21, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  store i32 0, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  %v4169 = load i64, ptr %slot28, align 8
  store i64 %v4169, ptr %slot643, align 8
  %v4170 = load i64, ptr %slot22, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %ld4172 = load i32, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4172, ptr %slot644, align 8
  %v4173 = load i32, ptr %slot644, align 8
  %op4174 = and i32 %v4173, 28
  store i32 %op4174, ptr %slot645, align 8
  %v4175 = load i32, ptr %slot645, align 8
  %cv4176 = zext i32 %v4175 to i64
  %cond4177 = icmp ne i64 %cv4176, 0
  br i1 %cond4177, label %bb_rcslotrole825, label %bb_rcslotowner825
bb_rcslotrole825:
  %v4178 = load i64, ptr %slot64, align 8
  store i64 %v4178, ptr %slot646, align 8
  %v4179 = load i64, ptr %slot646, align 8
  %v4180 = load i64, ptr %slot643, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v4179, i64 %v4180) nomerge, !dbg !152
  br label %bb_rcslotdone825
bb_rcslotowner825:
  %v4181 = load i64, ptr %slot64, align 8
  store i64 %v4181, ptr %slot647, align 8
  %v4182 = load i64, ptr %slot647, align 8
  %v4183 = load i64, ptr %slot643, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v4182, i64 %v4183) nomerge, !dbg !152
  br label %bb_rcslotdone825
bb_rcslotdone825:
  %v4184 = load i64, ptr %slot27, align 8
  store i64 %v4184, ptr %slot648, align 8
  %v4185 = load i64, ptr %slot30, align 8
  store i64 %v4185, ptr %slot649, align 8
  %v4186 = load i64, ptr %slot649, align 8
  %v4187 = load i64, ptr %slot648, align 8
  %p4188 = inttoptr i64 %v4186 to ptr
  %p4189 = inttoptr i64 %v4187 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4189, ptr %p4188, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4190 = load i64, ptr %slot20, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  store i32 2, ptr %p4191, align 4, !alias.scope !3, !noalias !4
  %v4192 = load i64, ptr %slot24, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  %ld4194 = load i32, ptr %p4193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4194, ptr %slot650, align 8
  %v4195 = load i32, ptr %slot650, align 8
  %v4196 = load i64, ptr %slot20, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  store i32 %v4195, ptr %p4197, align 4, !alias.scope !3, !noalias !4
  %v4198 = load i64, ptr %slot23, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  store i32 0, ptr %p4199, align 4, !alias.scope !3, !noalias !4
  %v4200 = load i64, ptr %slot19, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  store i32 1, ptr %p4201, align 4, !alias.scope !3, !noalias !4
  %v4202 = load i64, ptr %slot648, align 8
  %v4203 = load i64, ptr %slot53, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  store i64 %v4202, ptr %p4204, align 8, !alias.scope !3, !noalias !4
  %v4205 = load i64, ptr %slot53, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %ld4207 = load i64, ptr %p4206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4207, ptr %slot651, align 8
  %v4208 = load i64, ptr %slot19, align 8
  %p4209 = inttoptr i64 %v4208 to ptr
  %ld4210 = load i32, ptr %p4209, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4210, ptr %slot652, align 8
  %v4211 = load i64, ptr %slot20, align 8
  %p4212 = inttoptr i64 %v4211 to ptr
  %ld4213 = load i32, ptr %p4212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4213, ptr %slot653, align 8
  %v4214 = load i32, ptr %slot653, align 8
  %op4215 = and i32 %v4214, 24
  store i32 %op4215, ptr %slot653, align 8
  %v4216 = load i32, ptr %slot653, align 8
  %cmp4217 = icmp eq i32 %v4216, 0
  %cv4218 = zext i1 %cmp4217 to i32
  store i32 %cv4218, ptr %slot654, align 8
  %v4219 = load i32, ptr %slot652, align 8
  %v4220 = load i32, ptr %slot654, align 8
  %op4221 = and i32 %v4219, %v4220
  store i32 %op4221, ptr %slot655, align 8
  %v4222 = load i64, ptr %slot65, align 8
  store i64 %v4222, ptr %slot656, align 8
  %v4223 = load i32, ptr %slot655, align 8
  %op4224 = mul i32 %v4223, 4
  store i32 %op4224, ptr %slot657, align 8
  %v4225 = load i32, ptr %slot657, align 8
  %op4226 = or i32 %v4225, 0
  store i32 %op4226, ptr %slot658, align 8
  %v4227 = load i64, ptr %slot30, align 8
  store i64 %v4227, ptr %slot659, align 8
  %v4228 = load i64, ptr %slot64, align 8
  %v4229 = load i64, ptr %slot659, align 8
  %v4230 = load i64, ptr %slot651, align 8
  %v4231 = load i64, ptr %slot656, align 8
  %cv4232 = trunc i64 %v4231 to i32
  %v4233 = load i32, ptr %slot658, align 8
  %call4234 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v4228, i64 %v4229, i64 %v4230, i32 %cv4232, i32 %v4233) nomerge, !dbg !154
  store i32 %call4234, ptr %slot660, align 8
  %v4235 = load i32, ptr %slot660, align 8
  %cv4236 = zext i32 %v4235 to i64
  %cond4237 = icmp ne i64 %cv4236, 0
  br i1 %cond4237, label %bb_rcsuccess854, label %bb_rcfailure854
bb_rcfailure854:
  %v4238 = load i64, ptr %slot64, align 8
  %p4239 = inttoptr i64 %v4238 to ptr
  %call4240 = call i32 @myl_rc_take_failure(ptr %p4239) nomerge, !dbg !154
  store i32 %call4240, ptr %slot661, align 8
  %v4241 = load i64, ptr %slot1, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %v4243 = load i32, ptr %slot661, align 8
  %call4244 = call i32 @myl_qbe_rc_status(ptr %p4242, i32 %v4243) nomerge, !dbg !154
  store i32 %call4244, ptr %slot662, align 8
  br label %bb_failure
bb_rcsuccess854:
  %v4245 = load i32, ptr %slot655, align 8
  %cv4246 = zext i32 %v4245 to i64
  %cond4247 = icmp ne i64 %cv4246, 0
  br i1 %cond4247, label %bb_rchtaken857, label %bb_rchcopied857
bb_rchcopied857:
  %v4248 = load i64, ptr %slot19, align 8
  %p4249 = inttoptr i64 %v4248 to ptr
  %ld4250 = load i32, ptr %p4249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4250, ptr %slot663, align 8
  %v4251 = load i32, ptr %slot663, align 8
  %cv4252 = zext i32 %v4251 to i64
  %cond4253 = icmp ne i64 %cv4252, 0
  br i1 %cond4253, label %bb_rcslotdrop860, label %bb_rcslotdone860
bb_rcslotdrop860:
  %v4254 = load i64, ptr %slot19, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  store i32 0, ptr %p4255, align 4, !alias.scope !3, !noalias !4
  %v4256 = load i64, ptr %slot27, align 8
  store i64 %v4256, ptr %slot664, align 8
  %v4257 = load i64, ptr %slot20, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  %ld4259 = load i32, ptr %p4258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4259, ptr %slot665, align 8
  %v4260 = load i32, ptr %slot665, align 8
  %op4261 = and i32 %v4260, 28
  store i32 %op4261, ptr %slot666, align 8
  %v4262 = load i32, ptr %slot666, align 8
  %cv4263 = zext i32 %v4262 to i64
  %cond4264 = icmp ne i64 %cv4263, 0
  br i1 %cond4264, label %bb_rcslotrole860, label %bb_rcslotowner860
bb_rcslotrole860:
  %v4265 = load i64, ptr %slot64, align 8
  store i64 %v4265, ptr %slot667, align 8
  %v4266 = load i64, ptr %slot667, align 8
  %v4267 = load i64, ptr %slot664, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4266, i64 %v4267) nomerge, !dbg !154
  br label %bb_rcslotdone860
bb_rcslotowner860:
  %v4268 = load i64, ptr %slot64, align 8
  store i64 %v4268, ptr %slot668, align 8
  %v4269 = load i64, ptr %slot668, align 8
  %v4270 = load i64, ptr %slot664, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4269, i64 %v4270) nomerge, !dbg !154
  br label %bb_rcslotdone860
bb_rcslotdone860:
  br label %bb_rchprepared857
bb_rchtaken857:
  %v4271 = load i64, ptr %slot19, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  store i32 0, ptr %p4272, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared857
bb_rchprepared857:
  %v4273 = load i64, ptr %slot24, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  store i32 2, ptr %p4274, align 4, !alias.scope !3, !noalias !4
  %v4275 = load i64, ptr %slot23, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  store i32 1, ptr %p4276, align 4, !alias.scope !3, !noalias !4
  %v4277 = load i64, ptr %slot27, align 8
  store i64 %v4277, ptr %slot669, align 8
  %v4278 = load i64, ptr %slot30, align 8
  store i64 %v4278, ptr %slot670, align 8
  %v4279 = load i64, ptr %slot670, align 8
  %v4280 = load i64, ptr %slot669, align 8
  %p4281 = inttoptr i64 %v4279 to ptr
  %p4282 = inttoptr i64 %v4280 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4282, ptr %p4281, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4283 = load i64, ptr %slot20, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  store i32 2, ptr %p4284, align 4, !alias.scope !3, !noalias !4
  %v4285 = load i64, ptr %slot24, align 8
  %p4286 = inttoptr i64 %v4285 to ptr
  %ld4287 = load i32, ptr %p4286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4287, ptr %slot671, align 8
  %v4288 = load i32, ptr %slot671, align 8
  %v4289 = load i64, ptr %slot20, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  store i32 %v4288, ptr %p4290, align 4, !alias.scope !3, !noalias !4
  %v4291 = load i64, ptr %slot23, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i32 0, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot19, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 1, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot669, align 8
  %v4296 = load i64, ptr %slot53, align 8
  %p4297 = inttoptr i64 %v4296 to ptr
  store i64 %v4295, ptr %p4297, align 8, !alias.scope !3, !noalias !4
  %v4298 = load i64, ptr %slot52, align 8
  %p4299 = inttoptr i64 %v4298 to ptr
  %ld4300 = load i64, ptr %p4299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4300, ptr %slot672, align 8
  %v4301 = load i64, ptr %slot17, align 8
  %p4302 = inttoptr i64 %v4301 to ptr
  %ld4303 = load i32, ptr %p4302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4303, ptr %slot673, align 8
  %v4304 = load i64, ptr %slot18, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %ld4306 = load i32, ptr %p4305, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4306, ptr %slot674, align 8
  %v4307 = load i32, ptr %slot674, align 8
  %op4308 = and i32 %v4307, 24
  store i32 %op4308, ptr %slot674, align 8
  %v4309 = load i32, ptr %slot674, align 8
  %cmp4310 = icmp eq i32 %v4309, 0
  %cv4311 = zext i1 %cmp4310 to i32
  store i32 %cv4311, ptr %slot675, align 8
  %v4312 = load i32, ptr %slot673, align 8
  %v4313 = load i32, ptr %slot675, align 8
  %op4314 = and i32 %v4312, %v4313
  store i32 %op4314, ptr %slot676, align 8
  %v4315 = load i32, ptr %slot676, align 8
  %cv4316 = zext i32 %v4315 to i64
  %cond4317 = icmp ne i64 %cv4316, 0
  br i1 %cond4317, label %bb_rctake879, label %bb_rccopy879
bb_rctake879:
  %v4318 = load i64, ptr %slot30, align 8
  store i64 %v4318, ptr %slot677, align 8
  %v4319 = load i64, ptr %slot65, align 8
  store i64 %v4319, ptr %slot678, align 8
  %v4320 = load i64, ptr %slot64, align 8
  %v4321 = load i64, ptr %slot677, align 8
  %v4322 = load i64, ptr %slot672, align 8
  %v4323 = load i64, ptr %slot678, align 8
  %cv4324 = trunc i64 %v4323 to i32
  %call4325 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4320, i64 %v4321, i64 %v4322, i32 %cv4324) nomerge, !dbg !156
  store i32 %call4325, ptr %slot679, align 8
  %v4326 = load i32, ptr %slot679, align 8
  %cv4327 = zext i32 %v4326 to i64
  %cond4328 = icmp ne i64 %cv4327, 0
  br i1 %cond4328, label %bb_rcsuccess889, label %bb_rcfailure889
bb_rcfailure889:
  %v4329 = load i64, ptr %slot64, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  %call4331 = call i32 @myl_rc_take_failure(ptr %p4330) nomerge, !dbg !156
  store i32 %call4331, ptr %slot680, align 8
  %v4332 = load i64, ptr %slot1, align 8
  %p4333 = inttoptr i64 %v4332 to ptr
  %v4334 = load i32, ptr %slot680, align 8
  %call4335 = call i32 @myl_qbe_rc_status(ptr %p4333, i32 %v4334) nomerge, !dbg !156
  store i32 %call4335, ptr %slot681, align 8
  br label %bb_failure
bb_rcsuccess889:
  %v4336 = load i64, ptr %slot17, align 8
  %p4337 = inttoptr i64 %v4336 to ptr
  store i32 0, ptr %p4337, align 4, !alias.scope !3, !noalias !4
  %v4338 = load i64, ptr %slot24, align 8
  %p4339 = inttoptr i64 %v4338 to ptr
  store i32 2, ptr %p4339, align 4, !alias.scope !3, !noalias !4
  %v4340 = load i64, ptr %slot23, align 8
  %p4341 = inttoptr i64 %v4340 to ptr
  store i32 1, ptr %p4341, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared879
bb_rccopy879:
  %v4342 = load i64, ptr %slot30, align 8
  store i64 %v4342, ptr %slot682, align 8
  %v4343 = load i64, ptr %slot65, align 8
  store i64 %v4343, ptr %slot683, align 8
  %v4344 = load i64, ptr %slot64, align 8
  %v4345 = load i64, ptr %slot682, align 8
  %v4346 = load i64, ptr %slot672, align 8
  %v4347 = load i64, ptr %slot683, align 8
  %cv4348 = trunc i64 %v4347 to i32
  %call4349 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v4344, i64 %v4345, i64 %v4346, i32 %cv4348) nomerge, !dbg !156
  store i32 %call4349, ptr %slot684, align 8
  %v4350 = load i32, ptr %slot684, align 8
  %cv4351 = zext i32 %v4350 to i64
  %cond4352 = icmp ne i64 %cv4351, 0
  br i1 %cond4352, label %bb_rcsuccess898, label %bb_rcfailure898
bb_rcfailure898:
  %v4353 = load i64, ptr %slot64, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %call4355 = call i32 @myl_rc_take_failure(ptr %p4354) nomerge, !dbg !156
  store i32 %call4355, ptr %slot685, align 8
  %v4356 = load i64, ptr %slot1, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  %v4358 = load i32, ptr %slot685, align 8
  %call4359 = call i32 @myl_qbe_rc_status(ptr %p4357, i32 %v4358) nomerge, !dbg !156
  store i32 %call4359, ptr %slot686, align 8
  br label %bb_failure
bb_rcsuccess898:
  %v4360 = load i64, ptr %slot24, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i32 2, ptr %p4361, align 4, !alias.scope !3, !noalias !4
  %v4362 = load i64, ptr %slot23, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  store i32 1, ptr %p4363, align 4, !alias.scope !3, !noalias !4
  %v4364 = load i64, ptr %slot17, align 8
  %p4365 = inttoptr i64 %v4364 to ptr
  %ld4366 = load i32, ptr %p4365, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4366, ptr %slot687, align 8
  %v4367 = load i32, ptr %slot687, align 8
  %cv4368 = zext i32 %v4367 to i64
  %cond4369 = icmp ne i64 %cv4368, 0
  br i1 %cond4369, label %bb_rcslotdrop905, label %bb_rcslotdone905
bb_rcslotdrop905:
  %v4370 = load i64, ptr %slot17, align 8
  %p4371 = inttoptr i64 %v4370 to ptr
  store i32 0, ptr %p4371, align 4, !alias.scope !3, !noalias !4
  %v4372 = load i64, ptr %slot26, align 8
  store i64 %v4372, ptr %slot688, align 8
  %v4373 = load i64, ptr %slot18, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  %ld4375 = load i32, ptr %p4374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4375, ptr %slot689, align 8
  %v4376 = load i32, ptr %slot689, align 8
  %op4377 = and i32 %v4376, 28
  store i32 %op4377, ptr %slot690, align 8
  %v4378 = load i32, ptr %slot690, align 8
  %cv4379 = zext i32 %v4378 to i64
  %cond4380 = icmp ne i64 %cv4379, 0
  br i1 %cond4380, label %bb_rcslotrole905, label %bb_rcslotowner905
bb_rcslotrole905:
  %v4381 = load i64, ptr %slot64, align 8
  store i64 %v4381, ptr %slot691, align 8
  %v4382 = load i64, ptr %slot691, align 8
  %v4383 = load i64, ptr %slot688, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4382, i64 %v4383) nomerge, !dbg !156
  br label %bb_rcslotdone905
bb_rcslotowner905:
  %v4384 = load i64, ptr %slot64, align 8
  store i64 %v4384, ptr %slot692, align 8
  %v4385 = load i64, ptr %slot692, align 8
  %v4386 = load i64, ptr %slot688, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4385, i64 %v4386) nomerge, !dbg !156
  br label %bb_rcslotdone905
bb_rcslotdone905:
  br label %bb_rcprepared879
bb_rcprepared879:
  %v4387 = load i64, ptr %slot30, align 8
  store i64 %v4387, ptr %slot693, align 8
  %v4388 = load i64, ptr %slot56, align 8
  store i64 %v4388, ptr %slot694, align 8
  %v4389 = load i64, ptr %slot693, align 8
  %v4390 = load i64, ptr %slot694, align 8
  %p4391 = inttoptr i64 %v4389 to ptr
  %p4392 = inttoptr i64 %v4390 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4392, ptr %p4391, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4393 = load i64, ptr %slot23, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  store i32 0, ptr %p4394, align 4, !alias.scope !3, !noalias !4
  %v4395 = load i64, ptr %slot25, align 8
  %p4396 = inttoptr i64 %v4395 to ptr
  store i32 1, ptr %p4396, align 4, !alias.scope !3, !noalias !4
  %v4397 = load i64, ptr %slot65, align 8
  store i64 %v4397, ptr %slot695, align 8
  %v4398 = load i64, ptr %slot53, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  %ld4400 = load i64, ptr %p4399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4400, ptr %slot696, align 8
  %v4401 = load i64, ptr %slot694, align 8
  %p4403 = inttoptr i64 %v4401 to ptr
  %gep4404 = getelementptr i8, ptr %p4403, i64 0
  %op4402 = ptrtoint ptr %gep4404 to i64
  store i64 %op4402, ptr %slot697, align 8
  %v4405 = load i64, ptr %slot30, align 8
  store i64 %v4405, ptr %slot698, align 8
  %v4406 = load i64, ptr %slot53, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  %ld4408 = load i64, ptr %p4407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4408, ptr %slot699, align 8
  %v4409 = load i64, ptr %slot30, align 8
  store i64 %v4409, ptr %slot700, align 8
  %v4410 = load i64, ptr %slot65, align 8
  store i64 %v4410, ptr %slot701, align 8
  %v4411 = load i64, ptr %slot699, align 8
  %op4412 = add i64 %v4411, 16
  store i64 %op4412, ptr %slot702, align 8
  %v4413 = load i64, ptr %slot702, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  %ld4415 = load i64, ptr %p4414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4415, ptr %slot703, align 8
  %v4416 = load i64, ptr %slot703, align 8
  %cmp4417 = icmp ne i64 %v4416, 0
  %cv4418 = zext i1 %cmp4417 to i32
  store i32 %cv4418, ptr %slot704, align 8
  %v4419 = load i32, ptr %slot704, align 8
  %cv4420 = zext i32 %v4419 to i64
  %cond4421 = icmp ne i64 %cv4420, 0
  br i1 %cond4421, label %bb_rcmoveheader927, label %bb_rcmovenext927
bb_rcmoveheader927:
  %v4422 = load i64, ptr %slot703, align 8
  %op4423 = sub i64 %v4422, 16
  store i64 %op4423, ptr %slot705, align 8
  %v4424 = load i64, ptr %slot703, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %rgep4426 = getelementptr i8, ptr %p4425, i64 -16
  %ld4427 = load i64, ptr %rgep4426, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4427, ptr %slot706, align 8
  %v4428 = load i64, ptr %slot706, align 8
  %op4429 = and i64 %v4428, 5764607523034234881
  store i64 %op4429, ptr %slot707, align 8
  %v4430 = load i64, ptr %slot707, align 8
  %cmp4431 = icmp ne i64 %v4430, 0
  %cv4432 = zext i1 %cmp4431 to i32
  store i32 %cv4432, ptr %slot708, align 8
  %v4433 = load i32, ptr %slot708, align 8
  %cv4434 = zext i32 %v4433 to i64
  %cond4435 = icmp ne i64 %cv4434, 0
  br i1 %cond4435, label %bb_rcmoveslow924, label %bb_rcmovenext927
bb_rcmovenext927:
  %v4436 = load i64, ptr %slot699, align 8
  %op4437 = add i64 %v4436, 24
  store i64 %op4437, ptr %slot709, align 8
  %v4438 = load i64, ptr %slot709, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  %ld4440 = load i64, ptr %p4439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4440, ptr %slot710, align 8
  %v4441 = load i64, ptr %slot710, align 8
  %cmp4442 = icmp ne i64 %v4441, 0
  %cv4443 = zext i1 %cmp4442 to i32
  store i32 %cv4443, ptr %slot711, align 8
  %v4444 = load i32, ptr %slot711, align 8
  %cv4445 = zext i32 %v4444 to i64
  %cond4446 = icmp ne i64 %cv4445, 0
  br i1 %cond4446, label %bb_rcmoveheader935, label %bb_rcmovenext935
bb_rcmoveheader935:
  %v4447 = load i64, ptr %slot710, align 8
  %op4448 = sub i64 %v4447, 16
  store i64 %op4448, ptr %slot712, align 8
  %v4449 = load i64, ptr %slot710, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  %rgep4451 = getelementptr i8, ptr %p4450, i64 -16
  %ld4452 = load i64, ptr %rgep4451, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4452, ptr %slot713, align 8
  %v4453 = load i64, ptr %slot713, align 8
  %op4454 = and i64 %v4453, 5764607523034234881
  store i64 %op4454, ptr %slot714, align 8
  %v4455 = load i64, ptr %slot714, align 8
  %cmp4456 = icmp ne i64 %v4455, 0
  %cv4457 = zext i1 %cmp4456 to i32
  store i32 %cv4457, ptr %slot715, align 8
  %v4458 = load i32, ptr %slot715, align 8
  %cv4459 = zext i32 %v4458 to i64
  %cond4460 = icmp ne i64 %cv4459, 0
  br i1 %cond4460, label %bb_rcmoveslow924, label %bb_rcmovenext935
bb_rcmovenext935:
  %v4461 = load i64, ptr %slot699, align 8
  %op4462 = add i64 %v4461, 32
  store i64 %op4462, ptr %slot716, align 8
  %v4463 = load i64, ptr %slot716, align 8
  %p4464 = inttoptr i64 %v4463 to ptr
  %ld4465 = load i64, ptr %p4464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4465, ptr %slot717, align 8
  %v4466 = load i64, ptr %slot717, align 8
  %cmp4467 = icmp ne i64 %v4466, 0
  %cv4468 = zext i1 %cmp4467 to i32
  store i32 %cv4468, ptr %slot718, align 8
  %v4469 = load i32, ptr %slot718, align 8
  %cv4470 = zext i32 %v4469 to i64
  %cond4471 = icmp ne i64 %cv4470, 0
  br i1 %cond4471, label %bb_rcmoveheader943, label %bb_rcmovenext943
bb_rcmoveheader943:
  %v4472 = load i64, ptr %slot717, align 8
  %op4473 = sub i64 %v4472, 16
  store i64 %op4473, ptr %slot719, align 8
  %v4474 = load i64, ptr %slot717, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  %rgep4476 = getelementptr i8, ptr %p4475, i64 -16
  %ld4477 = load i64, ptr %rgep4476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4477, ptr %slot720, align 8
  %v4478 = load i64, ptr %slot720, align 8
  %op4479 = and i64 %v4478, 5764607523034234881
  store i64 %op4479, ptr %slot721, align 8
  %v4480 = load i64, ptr %slot721, align 8
  %cmp4481 = icmp ne i64 %v4480, 0
  %cv4482 = zext i1 %cmp4481 to i32
  store i32 %cv4482, ptr %slot722, align 8
  %v4483 = load i32, ptr %slot722, align 8
  %cv4484 = zext i32 %v4483 to i64
  %cond4485 = icmp ne i64 %cv4484, 0
  br i1 %cond4485, label %bb_rcmoveslow924, label %bb_rcmovenext943
bb_rcmovenext943:
  %v4486 = load i64, ptr %slot699, align 8
  %v4487 = load i64, ptr %slot700, align 8
  %p4488 = inttoptr i64 %v4486 to ptr
  %p4489 = inttoptr i64 %v4487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4489, ptr %p4488, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4490 = load i64, ptr %slot699, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i64 0, ptr %p4491, align 8, !alias.scope !3, !noalias !4
  %v4492 = load i64, ptr %slot699, align 8
  %op4493 = add i64 %v4492, 8
  store i64 %op4493, ptr %slot723, align 8
  %v4494 = load i64, ptr %slot723, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  store i64 0, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  %v4496 = load i64, ptr %slot699, align 8
  %op4497 = add i64 %v4496, 16
  store i64 %op4497, ptr %slot724, align 8
  %v4498 = load i64, ptr %slot724, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  store i64 0, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  %v4500 = load i64, ptr %slot699, align 8
  %op4501 = add i64 %v4500, 24
  store i64 %op4501, ptr %slot725, align 8
  %v4502 = load i64, ptr %slot725, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  store i64 0, ptr %p4503, align 8, !alias.scope !3, !noalias !4
  %v4504 = load i64, ptr %slot699, align 8
  %op4505 = add i64 %v4504, 32
  store i64 %op4505, ptr %slot726, align 8
  %v4506 = load i64, ptr %slot726, align 8
  %p4507 = inttoptr i64 %v4506 to ptr
  store i64 0, ptr %p4507, align 8, !alias.scope !3, !noalias !4
  %v4508 = load i64, ptr %slot699, align 8
  %op4509 = add i64 %v4508, 40
  store i64 %op4509, ptr %slot727, align 8
  %v4510 = load i64, ptr %slot727, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  store i64 0, ptr %p4511, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved924
bb_rcmoveslow924:
  %v4512 = load i64, ptr %slot64, align 8
  %v4513 = load i64, ptr %slot700, align 8
  %v4514 = load i64, ptr %slot699, align 8
  %v4515 = load i64, ptr %slot701, align 8
  %cv4516 = trunc i64 %v4515 to i32
  %call4517 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v4512, i64 %v4513, i64 %v4514, i32 %cv4516) nomerge, !dbg !156
  store i32 %call4517, ptr %slot728, align 8
  %v4518 = load i32, ptr %slot728, align 8
  %cv4519 = zext i32 %v4518 to i64
  %cond4520 = icmp ne i64 %cv4519, 0
  br i1 %cond4520, label %bb_rcsuccess955, label %bb_rcfailure955
bb_rcfailure955:
  %v4521 = load i64, ptr %slot64, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  %call4523 = call i32 @myl_rc_take_failure(ptr %p4522) nomerge, !dbg !156
  store i32 %call4523, ptr %slot729, align 8
  %v4524 = load i64, ptr %slot1, align 8
  %p4525 = inttoptr i64 %v4524 to ptr
  %v4526 = load i32, ptr %slot729, align 8
  %call4527 = call i32 @myl_qbe_rc_status(ptr %p4525, i32 %v4526) nomerge, !dbg !156
  store i32 %call4527, ptr %slot730, align 8
  br label %bb_failure
bb_rcsuccess955:
  br label %bb_rcmoved924
bb_rcmoved924:
  %v4528 = load i64, ptr %slot19, align 8
  %p4529 = inttoptr i64 %v4528 to ptr
  store i32 0, ptr %p4529, align 4, !alias.scope !3, !noalias !4
  %v4530 = load i64, ptr %slot24, align 8
  %p4531 = inttoptr i64 %v4530 to ptr
  store i32 2, ptr %p4531, align 4, !alias.scope !3, !noalias !4
  %v4532 = load i64, ptr %slot23, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  store i32 1, ptr %p4533, align 4, !alias.scope !3, !noalias !4
  %v4534 = load i64, ptr %slot30, align 8
  store i64 %v4534, ptr %slot731, align 8
  %v4535 = load i64, ptr %slot731, align 8
  %v4536 = load i64, ptr %slot698, align 8
  %p4537 = inttoptr i64 %v4535 to ptr
  %p4538 = inttoptr i64 %v4536 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4538, ptr %p4537, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4539 = load i64, ptr %slot23, align 8
  %p4540 = inttoptr i64 %v4539 to ptr
  store i32 0, ptr %p4540, align 4, !alias.scope !3, !noalias !4
  %v4541 = load i64, ptr %slot24, align 8
  %p4542 = inttoptr i64 %v4541 to ptr
  store i32 2, ptr %p4542, align 4, !alias.scope !3, !noalias !4
  %v4543 = load i64, ptr %slot23, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  store i32 1, ptr %p4544, align 4, !alias.scope !3, !noalias !4
  %v4545 = load i64, ptr %slot64, align 8
  store i64 %v4545, ptr %slot732, align 8
  %v4546 = load i64, ptr %slot732, align 8
  %v4547 = load i64, ptr %slot697, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4546, i64 %v4547) nomerge, !dbg !156
  %v4548 = load i64, ptr %slot698, align 8
  %v4549 = load i64, ptr %slot697, align 8
  %p4550 = inttoptr i64 %v4548 to ptr
  %p4551 = inttoptr i64 %v4549 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4551, ptr %p4550, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4552 = load i64, ptr %slot23, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  store i32 0, ptr %p4553, align 4, !alias.scope !3, !noalias !4
  %v4554 = load i64, ptr %slot694, align 8
  %v4555 = load i64, ptr %slot52, align 8
  %p4556 = inttoptr i64 %v4555 to ptr
  store i64 %v4554, ptr %p4556, align 8, !alias.scope !3, !noalias !4
  %v4557 = load i64, ptr %slot52, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  %ld4559 = load i64, ptr %p4558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4559, ptr %slot733, align 8
  %v4560 = load i64, ptr %slot30, align 8
  store i64 %v4560, ptr %slot734, align 8
  %v4561 = load i64, ptr %slot733, align 8
  %v4562 = load i64, ptr %slot734, align 8
  %p4563 = inttoptr i64 %v4561 to ptr
  %p4564 = inttoptr i64 %v4562 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4564, ptr %p4563, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4565 = load i64, ptr %slot24, align 8
  %p4566 = inttoptr i64 %v4565 to ptr
  store i32 2, ptr %p4566, align 4, !alias.scope !3, !noalias !4
  %v4567 = load i64, ptr %slot23, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  store i32 1, ptr %p4568, align 4, !alias.scope !3, !noalias !4
  %v4569 = load i64, ptr %slot17, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  %ld4571 = load i32, ptr %p4570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4571, ptr %slot735, align 8
  %v4572 = load i32, ptr %slot735, align 8
  %cv4573 = zext i32 %v4572 to i64
  %cond4574 = icmp ne i64 %cv4573, 0
  br i1 %cond4574, label %bb_rcslotdrop973, label %bb_rcslotdone973
bb_rcslotdrop973:
  %v4575 = load i64, ptr %slot17, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  store i32 0, ptr %p4576, align 4, !alias.scope !3, !noalias !4
  %v4577 = load i64, ptr %slot26, align 8
  store i64 %v4577, ptr %slot736, align 8
  %v4578 = load i64, ptr %slot18, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  %ld4580 = load i32, ptr %p4579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4580, ptr %slot737, align 8
  %v4581 = load i32, ptr %slot737, align 8
  %op4582 = and i32 %v4581, 28
  store i32 %op4582, ptr %slot738, align 8
  %v4583 = load i32, ptr %slot738, align 8
  %cv4584 = zext i32 %v4583 to i64
  %cond4585 = icmp ne i64 %cv4584, 0
  br i1 %cond4585, label %bb_rcslotrole973, label %bb_rcslotowner973
bb_rcslotrole973:
  %v4586 = load i64, ptr %slot64, align 8
  store i64 %v4586, ptr %slot739, align 8
  %v4587 = load i64, ptr %slot739, align 8
  %v4588 = load i64, ptr %slot736, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4587, i64 %v4588) nomerge, !dbg !156
  br label %bb_rcslotdone973
bb_rcslotowner973:
  %v4589 = load i64, ptr %slot64, align 8
  store i64 %v4589, ptr %slot740, align 8
  %v4590 = load i64, ptr %slot740, align 8
  %v4591 = load i64, ptr %slot736, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4590, i64 %v4591) nomerge, !dbg !156
  br label %bb_rcslotdone973
bb_rcslotdone973:
  %v4592 = load i64, ptr %slot19, align 8
  %p4593 = inttoptr i64 %v4592 to ptr
  %ld4594 = load i32, ptr %p4593, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4594, ptr %slot741, align 8
  %v4595 = load i32, ptr %slot741, align 8
  %cv4596 = zext i32 %v4595 to i64
  %cond4597 = icmp ne i64 %cv4596, 0
  br i1 %cond4597, label %bb_rcslotdrop982, label %bb_rcslotdone982
bb_rcslotdrop982:
  %v4598 = load i64, ptr %slot19, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  store i32 0, ptr %p4599, align 4, !alias.scope !3, !noalias !4
  %v4600 = load i64, ptr %slot27, align 8
  store i64 %v4600, ptr %slot742, align 8
  %v4601 = load i64, ptr %slot20, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  %ld4603 = load i32, ptr %p4602, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4603, ptr %slot743, align 8
  %v4604 = load i32, ptr %slot743, align 8
  %op4605 = and i32 %v4604, 28
  store i32 %op4605, ptr %slot744, align 8
  %v4606 = load i32, ptr %slot744, align 8
  %cv4607 = zext i32 %v4606 to i64
  %cond4608 = icmp ne i64 %cv4607, 0
  br i1 %cond4608, label %bb_rcslotrole982, label %bb_rcslotowner982
bb_rcslotrole982:
  %v4609 = load i64, ptr %slot64, align 8
  store i64 %v4609, ptr %slot745, align 8
  %v4610 = load i64, ptr %slot745, align 8
  %v4611 = load i64, ptr %slot742, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4610, i64 %v4611) nomerge, !dbg !156
  br label %bb_rcslotdone982
bb_rcslotowner982:
  %v4612 = load i64, ptr %slot64, align 8
  store i64 %v4612, ptr %slot746, align 8
  %v4613 = load i64, ptr %slot746, align 8
  %v4614 = load i64, ptr %slot742, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4613, i64 %v4614) nomerge, !dbg !156
  br label %bb_rcslotdone982
bb_rcslotdone982:
  %v4615 = load i64, ptr %slot26, align 8
  store i64 %v4615, ptr %slot747, align 8
  %v4616 = load i64, ptr %slot30, align 8
  store i64 %v4616, ptr %slot748, align 8
  %v4617 = load i64, ptr %slot748, align 8
  %v4618 = load i64, ptr %slot747, align 8
  %p4619 = inttoptr i64 %v4617 to ptr
  %p4620 = inttoptr i64 %v4618 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4620, ptr %p4619, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4621 = load i64, ptr %slot18, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  store i32 2, ptr %p4622, align 4, !alias.scope !3, !noalias !4
  %v4623 = load i64, ptr %slot24, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  %ld4625 = load i32, ptr %p4624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4625, ptr %slot749, align 8
  %v4626 = load i32, ptr %slot749, align 8
  %v4627 = load i64, ptr %slot18, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  store i32 %v4626, ptr %p4628, align 4, !alias.scope !3, !noalias !4
  %v4629 = load i64, ptr %slot23, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  store i32 0, ptr %p4630, align 4, !alias.scope !3, !noalias !4
  %v4631 = load i64, ptr %slot17, align 8
  %p4632 = inttoptr i64 %v4631 to ptr
  store i32 1, ptr %p4632, align 4, !alias.scope !3, !noalias !4
  %v4633 = load i64, ptr %slot747, align 8
  %v4634 = load i64, ptr %slot52, align 8
  %p4635 = inttoptr i64 %v4634 to ptr
  store i64 %v4633, ptr %p4635, align 8, !alias.scope !3, !noalias !4
  %v4636 = load i64, ptr %slot52, align 8
  %p4637 = inttoptr i64 %v4636 to ptr
  %ld4638 = load i64, ptr %p4637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4638, ptr %slot750, align 8
  %v4639 = load i64, ptr %slot17, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %ld4641 = load i32, ptr %p4640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4641, ptr %slot751, align 8
  %v4642 = load i64, ptr %slot18, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  %ld4644 = load i32, ptr %p4643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4644, ptr %slot752, align 8
  %v4645 = load i32, ptr %slot752, align 8
  %op4646 = and i32 %v4645, 24
  store i32 %op4646, ptr %slot752, align 8
  %v4647 = load i32, ptr %slot752, align 8
  %cmp4648 = icmp eq i32 %v4647, 0
  %cv4649 = zext i1 %cmp4648 to i32
  store i32 %cv4649, ptr %slot753, align 8
  %v4650 = load i32, ptr %slot751, align 8
  %v4651 = load i32, ptr %slot753, align 8
  %op4652 = and i32 %v4650, %v4651
  store i32 %op4652, ptr %slot754, align 8
  %v4653 = load i32, ptr %slot754, align 8
  %cv4654 = zext i32 %v4653 to i64
  %cond4655 = icmp ne i64 %cv4654, 0
  br i1 %cond4655, label %bb_rctake998, label %bb_rccopy998
bb_rctake998:
  %v4656 = load i64, ptr %slot30, align 8
  store i64 %v4656, ptr %slot755, align 8
  %v4657 = load i64, ptr %slot65, align 8
  store i64 %v4657, ptr %slot756, align 8
  %v4658 = load i64, ptr %slot64, align 8
  %v4659 = load i64, ptr %slot755, align 8
  %v4660 = load i64, ptr %slot750, align 8
  %v4661 = load i64, ptr %slot756, align 8
  %cv4662 = trunc i64 %v4661 to i32
  %call4663 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4658, i64 %v4659, i64 %v4660, i32 %cv4662) nomerge, !dbg !158
  store i32 %call4663, ptr %slot757, align 8
  %v4664 = load i32, ptr %slot757, align 8
  %cv4665 = zext i32 %v4664 to i64
  %cond4666 = icmp ne i64 %cv4665, 0
  br i1 %cond4666, label %bb_rcsuccess1008, label %bb_rcfailure1008
bb_rcfailure1008:
  %v4667 = load i64, ptr %slot64, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %call4669 = call i32 @myl_rc_take_failure(ptr %p4668) nomerge, !dbg !158
  store i32 %call4669, ptr %slot758, align 8
  %v4670 = load i64, ptr %slot1, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  %v4672 = load i32, ptr %slot758, align 8
  %call4673 = call i32 @myl_qbe_rc_status(ptr %p4671, i32 %v4672) nomerge, !dbg !158
  store i32 %call4673, ptr %slot759, align 8
  br label %bb_failure
bb_rcsuccess1008:
  %v4674 = load i64, ptr %slot17, align 8
  %p4675 = inttoptr i64 %v4674 to ptr
  store i32 0, ptr %p4675, align 4, !alias.scope !3, !noalias !4
  %v4676 = load i64, ptr %slot24, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  store i32 2, ptr %p4677, align 4, !alias.scope !3, !noalias !4
  %v4678 = load i64, ptr %slot23, align 8
  %p4679 = inttoptr i64 %v4678 to ptr
  store i32 1, ptr %p4679, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared998
bb_rccopy998:
  %v4680 = load i64, ptr %slot30, align 8
  store i64 %v4680, ptr %slot760, align 8
  %v4681 = load i64, ptr %slot65, align 8
  store i64 %v4681, ptr %slot761, align 8
  %v4682 = load i64, ptr %slot64, align 8
  %v4683 = load i64, ptr %slot760, align 8
  %v4684 = load i64, ptr %slot750, align 8
  %v4685 = load i64, ptr %slot761, align 8
  %cv4686 = trunc i64 %v4685 to i32
  %call4687 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v4682, i64 %v4683, i64 %v4684, i32 %cv4686) nomerge, !dbg !158
  store i32 %call4687, ptr %slot762, align 8
  %v4688 = load i32, ptr %slot762, align 8
  %cv4689 = zext i32 %v4688 to i64
  %cond4690 = icmp ne i64 %cv4689, 0
  br i1 %cond4690, label %bb_rcsuccess1017, label %bb_rcfailure1017
bb_rcfailure1017:
  %v4691 = load i64, ptr %slot64, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %call4693 = call i32 @myl_rc_take_failure(ptr %p4692) nomerge, !dbg !158
  store i32 %call4693, ptr %slot763, align 8
  %v4694 = load i64, ptr %slot1, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  %v4696 = load i32, ptr %slot763, align 8
  %call4697 = call i32 @myl_qbe_rc_status(ptr %p4695, i32 %v4696) nomerge, !dbg !158
  store i32 %call4697, ptr %slot764, align 8
  br label %bb_failure
bb_rcsuccess1017:
  %v4698 = load i64, ptr %slot24, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  store i32 2, ptr %p4699, align 4, !alias.scope !3, !noalias !4
  %v4700 = load i64, ptr %slot23, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  store i32 1, ptr %p4701, align 4, !alias.scope !3, !noalias !4
  %v4702 = load i64, ptr %slot17, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  %ld4704 = load i32, ptr %p4703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4704, ptr %slot765, align 8
  %v4705 = load i32, ptr %slot765, align 8
  %cv4706 = zext i32 %v4705 to i64
  %cond4707 = icmp ne i64 %cv4706, 0
  br i1 %cond4707, label %bb_rcslotdrop1024, label %bb_rcslotdone1024
bb_rcslotdrop1024:
  %v4708 = load i64, ptr %slot17, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  store i32 0, ptr %p4709, align 4, !alias.scope !3, !noalias !4
  %v4710 = load i64, ptr %slot26, align 8
  store i64 %v4710, ptr %slot766, align 8
  %v4711 = load i64, ptr %slot18, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %ld4713 = load i32, ptr %p4712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4713, ptr %slot767, align 8
  %v4714 = load i32, ptr %slot767, align 8
  %op4715 = and i32 %v4714, 28
  store i32 %op4715, ptr %slot768, align 8
  %v4716 = load i32, ptr %slot768, align 8
  %cv4717 = zext i32 %v4716 to i64
  %cond4718 = icmp ne i64 %cv4717, 0
  br i1 %cond4718, label %bb_rcslotrole1024, label %bb_rcslotowner1024
bb_rcslotrole1024:
  %v4719 = load i64, ptr %slot64, align 8
  store i64 %v4719, ptr %slot769, align 8
  %v4720 = load i64, ptr %slot769, align 8
  %v4721 = load i64, ptr %slot766, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4720, i64 %v4721) nomerge, !dbg !158
  br label %bb_rcslotdone1024
bb_rcslotowner1024:
  %v4722 = load i64, ptr %slot64, align 8
  store i64 %v4722, ptr %slot770, align 8
  %v4723 = load i64, ptr %slot770, align 8
  %v4724 = load i64, ptr %slot766, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4723, i64 %v4724) nomerge, !dbg !158
  br label %bb_rcslotdone1024
bb_rcslotdone1024:
  br label %bb_rcprepared998
bb_rcprepared998:
  %v4725 = load i64, ptr %slot7, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %ld4727 = load i32, ptr %p4726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4727, ptr %slot771, align 8
  %v4728 = load i32, ptr %slot771, align 8
  %cv4729 = zext i32 %v4728 to i64
  %cond4730 = icmp ne i64 %cv4729, 0
  br i1 %cond4730, label %bb_rcslotdrop1034, label %bb_rcslotdone1034
bb_rcslotdrop1034:
  %v4731 = load i64, ptr %slot7, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  store i32 0, ptr %p4732, align 4, !alias.scope !3, !noalias !4
  %v4733 = load i64, ptr %slot43, align 8
  store i64 %v4733, ptr %slot772, align 8
  %v4734 = load i64, ptr %slot8, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  %ld4736 = load i32, ptr %p4735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4736, ptr %slot773, align 8
  %v4737 = load i32, ptr %slot773, align 8
  %op4738 = and i32 %v4737, 28
  store i32 %op4738, ptr %slot774, align 8
  %v4739 = load i32, ptr %slot774, align 8
  %cv4740 = zext i32 %v4739 to i64
  %cond4741 = icmp ne i64 %cv4740, 0
  br i1 %cond4741, label %bb_rcslotrole1034, label %bb_rcslotowner1034
bb_rcslotrole1034:
  %v4742 = load i64, ptr %slot64, align 8
  store i64 %v4742, ptr %slot775, align 8
  %v4743 = load i64, ptr %slot775, align 8
  %v4744 = load i64, ptr %slot772, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4743, i64 %v4744) nomerge, !dbg !158
  br label %bb_rcslotdone1034
bb_rcslotowner1034:
  %v4745 = load i64, ptr %slot64, align 8
  store i64 %v4745, ptr %slot776, align 8
  %v4746 = load i64, ptr %slot776, align 8
  %v4747 = load i64, ptr %slot772, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4746, i64 %v4747) nomerge, !dbg !158
  br label %bb_rcslotdone1034
bb_rcslotdone1034:
  %v4748 = load i64, ptr %slot43, align 8
  store i64 %v4748, ptr %slot777, align 8
  %v4749 = load i64, ptr %slot30, align 8
  store i64 %v4749, ptr %slot778, align 8
  %v4750 = load i64, ptr %slot778, align 8
  %v4751 = load i64, ptr %slot777, align 8
  %p4752 = inttoptr i64 %v4750 to ptr
  %p4753 = inttoptr i64 %v4751 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4753, ptr %p4752, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4754 = load i64, ptr %slot23, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  store i32 0, ptr %p4755, align 4, !alias.scope !3, !noalias !4
  %v4756 = load i64, ptr %slot8, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  store i32 2, ptr %p4757, align 4, !alias.scope !3, !noalias !4
  %v4758 = load i64, ptr %slot24, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  %ld4760 = load i32, ptr %p4759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4760, ptr %slot779, align 8
  %v4761 = load i32, ptr %slot779, align 8
  %v4762 = load i64, ptr %slot8, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  store i32 %v4761, ptr %p4763, align 4, !alias.scope !3, !noalias !4
  %v4764 = load i64, ptr %slot7, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  store i32 1, ptr %p4765, align 4, !alias.scope !3, !noalias !4
  %v4766 = load i64, ptr %slot52, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  store i64 0, ptr %p4767, align 8, !alias.scope !3, !noalias !4
  %v4768 = load i64, ptr %slot43, align 8
  %v4769 = load i64, ptr %slot52, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  store i64 %v4768, ptr %p4770, align 8, !alias.scope !3, !noalias !4
  %v4771 = load i64, ptr %slot52, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  %ld4773 = load i64, ptr %p4772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4773, ptr %slot780, align 8
  %v4774 = load i64, ptr %slot17, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  %ld4776 = load i32, ptr %p4775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4776, ptr %slot781, align 8
  %v4777 = load i64, ptr %slot18, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  %ld4779 = load i32, ptr %p4778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4779, ptr %slot782, align 8
  %v4780 = load i32, ptr %slot782, align 8
  %op4781 = and i32 %v4780, 24
  store i32 %op4781, ptr %slot782, align 8
  %v4782 = load i32, ptr %slot782, align 8
  %cmp4783 = icmp eq i32 %v4782, 0
  %cv4784 = zext i1 %cmp4783 to i32
  store i32 %cv4784, ptr %slot783, align 8
  %v4785 = load i32, ptr %slot781, align 8
  %v4786 = load i32, ptr %slot783, align 8
  %op4787 = and i32 %v4785, %v4786
  store i32 %op4787, ptr %slot784, align 8
  %v4788 = load i32, ptr %slot784, align 8
  %cv4789 = zext i32 %v4788 to i64
  %cond4790 = icmp ne i64 %cv4789, 0
  br i1 %cond4790, label %bb_rcprivateown1055, label %bb_rcprivateloan1055
bb_rcprivateown1055:
  %v4791 = load i64, ptr %slot30, align 8
  store i64 %v4791, ptr %slot785, align 8
  %v4792 = load i64, ptr %slot65, align 8
  store i64 %v4792, ptr %slot786, align 8
  %v4793 = load i64, ptr %slot64, align 8
  %v4794 = load i64, ptr %slot785, align 8
  %v4795 = load i64, ptr %slot780, align 8
  %v4796 = load i64, ptr %slot786, align 8
  %cv4797 = trunc i64 %v4796 to i32
  %call4798 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4793, i64 %v4794, i64 %v4795, i32 %cv4797) nomerge, !dbg !160
  store i32 %call4798, ptr %slot787, align 8
  %v4799 = load i32, ptr %slot787, align 8
  %cv4800 = zext i32 %v4799 to i64
  %cond4801 = icmp ne i64 %cv4800, 0
  br i1 %cond4801, label %bb_rcsuccess1059, label %bb_rcfailure1059
bb_rcfailure1059:
  %v4802 = load i64, ptr %slot64, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  %call4804 = call i32 @myl_rc_take_failure(ptr %p4803) nomerge, !dbg !160
  store i32 %call4804, ptr %slot788, align 8
  %v4805 = load i64, ptr %slot1, align 8
  %p4806 = inttoptr i64 %v4805 to ptr
  %v4807 = load i32, ptr %slot788, align 8
  %call4808 = call i32 @myl_qbe_rc_status(ptr %p4806, i32 %v4807) nomerge, !dbg !160
  store i32 %call4808, ptr %slot789, align 8
  br label %bb_failure
bb_rcsuccess1059:
  %v4809 = load i64, ptr %slot17, align 8
  %p4810 = inttoptr i64 %v4809 to ptr
  store i32 0, ptr %p4810, align 4, !alias.scope !3, !noalias !4
  %v4811 = load i64, ptr %slot24, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  store i32 2, ptr %p4812, align 4, !alias.scope !3, !noalias !4
  %v4813 = load i64, ptr %slot23, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  store i32 1, ptr %p4814, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1055
bb_rcprivateloan1055:
  %v4815 = load i64, ptr %slot30, align 8
  store i64 %v4815, ptr %slot790, align 8
  %v4816 = load i64, ptr %slot64, align 8
  %v4817 = load i64, ptr %slot790, align 8
  %v4818 = load i64, ptr %slot780, align 8
  %call4819 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v4816, i64 %v4817, i64 %v4818) nomerge, !dbg !160
  store i32 %call4819, ptr %slot791, align 8
  %v4820 = load i32, ptr %slot791, align 8
  %cv4821 = zext i32 %v4820 to i64
  %cond4822 = icmp ne i64 %cv4821, 0
  br i1 %cond4822, label %bb_rcsuccess1067, label %bb_rcfailure1067
bb_rcfailure1067:
  %v4823 = load i64, ptr %slot64, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  %call4825 = call i32 @myl_rc_take_failure(ptr %p4824) nomerge, !dbg !160
  store i32 %call4825, ptr %slot792, align 8
  %v4826 = load i64, ptr %slot1, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  %v4828 = load i32, ptr %slot792, align 8
  %call4829 = call i32 @myl_qbe_rc_status(ptr %p4827, i32 %v4828) nomerge, !dbg !160
  store i32 %call4829, ptr %slot793, align 8
  br label %bb_failure
bb_rcsuccess1067:
  %v4830 = load i64, ptr %slot24, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  store i32 2, ptr %p4831, align 4, !alias.scope !3, !noalias !4
  %v4832 = load i64, ptr %slot24, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  store i32 16, ptr %p4833, align 4, !alias.scope !3, !noalias !4
  %v4834 = load i64, ptr %slot23, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  store i32 1, ptr %p4835, align 4, !alias.scope !3, !noalias !4
  %v4836 = load i64, ptr %slot17, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  %ld4838 = load i32, ptr %p4837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4838, ptr %slot794, align 8
  %v4839 = load i32, ptr %slot794, align 8
  %cv4840 = zext i32 %v4839 to i64
  %cond4841 = icmp ne i64 %cv4840, 0
  br i1 %cond4841, label %bb_rcslotdrop1075, label %bb_rcslotdone1075
bb_rcslotdrop1075:
  %v4842 = load i64, ptr %slot17, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  store i32 0, ptr %p4843, align 4, !alias.scope !3, !noalias !4
  %v4844 = load i64, ptr %slot26, align 8
  store i64 %v4844, ptr %slot795, align 8
  %v4845 = load i64, ptr %slot18, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  %ld4847 = load i32, ptr %p4846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4847, ptr %slot796, align 8
  %v4848 = load i32, ptr %slot796, align 8
  %op4849 = and i32 %v4848, 28
  store i32 %op4849, ptr %slot797, align 8
  %v4850 = load i32, ptr %slot797, align 8
  %cv4851 = zext i32 %v4850 to i64
  %cond4852 = icmp ne i64 %cv4851, 0
  br i1 %cond4852, label %bb_rcslotrole1075, label %bb_rcslotowner1075
bb_rcslotrole1075:
  %v4853 = load i64, ptr %slot64, align 8
  store i64 %v4853, ptr %slot798, align 8
  %v4854 = load i64, ptr %slot798, align 8
  %v4855 = load i64, ptr %slot795, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4854, i64 %v4855) nomerge, !dbg !160
  br label %bb_rcslotdone1075
bb_rcslotowner1075:
  %v4856 = load i64, ptr %slot64, align 8
  store i64 %v4856, ptr %slot799, align 8
  %v4857 = load i64, ptr %slot799, align 8
  %v4858 = load i64, ptr %slot795, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4857, i64 %v4858) nomerge, !dbg !160
  br label %bb_rcslotdone1075
bb_rcslotdone1075:
  br label %bb_rcprivateprepared1055
bb_rcprivateprepared1055:
  %v4859 = load i64, ptr %slot13, align 8
  %p4860 = inttoptr i64 %v4859 to ptr
  %ld4861 = load i32, ptr %p4860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4861, ptr %slot800, align 8
  %v4862 = load i32, ptr %slot800, align 8
  %cv4863 = zext i32 %v4862 to i64
  %cond4864 = icmp ne i64 %cv4863, 0
  br i1 %cond4864, label %bb_rcslotdrop1085, label %bb_rcslotdone1085
bb_rcslotdrop1085:
  %v4865 = load i64, ptr %slot13, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  store i32 0, ptr %p4866, align 4, !alias.scope !3, !noalias !4
  %v4867 = load i64, ptr %slot47, align 8
  store i64 %v4867, ptr %slot801, align 8
  %v4868 = load i64, ptr %slot14, align 8
  %p4869 = inttoptr i64 %v4868 to ptr
  %ld4870 = load i32, ptr %p4869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4870, ptr %slot802, align 8
  %v4871 = load i32, ptr %slot802, align 8
  %op4872 = and i32 %v4871, 28
  store i32 %op4872, ptr %slot803, align 8
  %v4873 = load i32, ptr %slot803, align 8
  %cv4874 = zext i32 %v4873 to i64
  %cond4875 = icmp ne i64 %cv4874, 0
  br i1 %cond4875, label %bb_rcslotrole1085, label %bb_rcslotowner1085
bb_rcslotrole1085:
  %v4876 = load i64, ptr %slot64, align 8
  store i64 %v4876, ptr %slot804, align 8
  %v4877 = load i64, ptr %slot804, align 8
  %v4878 = load i64, ptr %slot801, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4877, i64 %v4878) nomerge, !dbg !160
  br label %bb_rcslotdone1085
bb_rcslotowner1085:
  %v4879 = load i64, ptr %slot64, align 8
  store i64 %v4879, ptr %slot805, align 8
  %v4880 = load i64, ptr %slot805, align 8
  %v4881 = load i64, ptr %slot801, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4880, i64 %v4881) nomerge, !dbg !160
  br label %bb_rcslotdone1085
bb_rcslotdone1085:
  %v4882 = load i64, ptr %slot47, align 8
  store i64 %v4882, ptr %slot806, align 8
  %v4883 = load i64, ptr %slot30, align 8
  store i64 %v4883, ptr %slot807, align 8
  %v4884 = load i64, ptr %slot807, align 8
  %v4885 = load i64, ptr %slot806, align 8
  %p4886 = inttoptr i64 %v4884 to ptr
  %p4887 = inttoptr i64 %v4885 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4887, ptr %p4886, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4888 = load i64, ptr %slot23, align 8
  %p4889 = inttoptr i64 %v4888 to ptr
  store i32 0, ptr %p4889, align 4, !alias.scope !3, !noalias !4
  %v4890 = load i64, ptr %slot14, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  store i32 2, ptr %p4891, align 4, !alias.scope !3, !noalias !4
  %v4892 = load i64, ptr %slot24, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  %ld4894 = load i32, ptr %p4893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4894, ptr %slot808, align 8
  %v4895 = load i32, ptr %slot808, align 8
  %v4896 = load i64, ptr %slot14, align 8
  %p4897 = inttoptr i64 %v4896 to ptr
  store i32 %v4895, ptr %p4897, align 4, !alias.scope !3, !noalias !4
  %v4898 = load i64, ptr %slot13, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  store i32 1, ptr %p4899, align 4, !alias.scope !3, !noalias !4
  %v4900 = load i64, ptr %slot36, align 8
  %p4901 = inttoptr i64 %v4900 to ptr
  %ld4902 = load i64, ptr %p4901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4902, ptr %slot809, align 8
  %v4903 = load i64, ptr %slot809, align 8
  %v4904 = load i64, ptr %slot52, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  store i64 %v4903, ptr %p4905, align 8, !alias.scope !3, !noalias !4
  %v4906 = load i64, ptr %slot52, align 8
  %p4907 = inttoptr i64 %v4906 to ptr
  %ld4908 = load i64, ptr %p4907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4908, ptr %slot810, align 8
  %v4909 = load i64, ptr %slot810, align 8
  %op4910 = add i64 %v4909, 376
  store i64 %op4910, ptr %slot811, align 8
  %v4911 = load i64, ptr %slot811, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  %ld4913 = load i64, ptr %p4912, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4913, ptr %slot812, align 8
  %v4914 = load i64, ptr %slot812, align 8
  %v4915 = load i64, ptr %slot52, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  store i64 %v4914, ptr %p4916, align 8, !alias.scope !3, !noalias !4
  %v4917 = load i64, ptr %slot17, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %ld4919 = load i32, ptr %p4918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4919, ptr %slot813, align 8
  %v4920 = load i32, ptr %slot813, align 8
  %cv4921 = zext i32 %v4920 to i64
  %cond4922 = icmp ne i64 %cv4921, 0
  br i1 %cond4922, label %bb_rcslotdrop1105, label %bb_rcslotdone1105
bb_rcslotdrop1105:
  %v4923 = load i64, ptr %slot17, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  store i32 0, ptr %p4924, align 4, !alias.scope !3, !noalias !4
  %v4925 = load i64, ptr %slot26, align 8
  store i64 %v4925, ptr %slot814, align 8
  %v4926 = load i64, ptr %slot18, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  %ld4928 = load i32, ptr %p4927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4928, ptr %slot815, align 8
  %v4929 = load i32, ptr %slot815, align 8
  %op4930 = and i32 %v4929, 28
  store i32 %op4930, ptr %slot816, align 8
  %v4931 = load i32, ptr %slot816, align 8
  %cv4932 = zext i32 %v4931 to i64
  %cond4933 = icmp ne i64 %cv4932, 0
  br i1 %cond4933, label %bb_rcslotrole1105, label %bb_rcslotowner1105
bb_rcslotrole1105:
  %v4934 = load i64, ptr %slot64, align 8
  store i64 %v4934, ptr %slot817, align 8
  %v4935 = load i64, ptr %slot817, align 8
  %v4936 = load i64, ptr %slot814, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4935, i64 %v4936) nomerge, !dbg !162
  br label %bb_rcslotdone1105
bb_rcslotowner1105:
  %v4937 = load i64, ptr %slot64, align 8
  store i64 %v4937, ptr %slot818, align 8
  %v4938 = load i64, ptr %slot818, align 8
  %v4939 = load i64, ptr %slot814, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4938, i64 %v4939) nomerge, !dbg !162
  br label %bb_rcslotdone1105
bb_rcslotdone1105:
  %v4940 = load i64, ptr %slot52, align 8
  %p4941 = inttoptr i64 %v4940 to ptr
  %ld4942 = load i64, ptr %p4941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4942, ptr %slot819, align 8
  %v4943 = load i64, ptr %slot36, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  %ld4945 = load i64, ptr %p4944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4945, ptr %slot820, align 8
  %v4946 = load i64, ptr %slot17, align 8
  %p4947 = inttoptr i64 %v4946 to ptr
  %ld4948 = load i32, ptr %p4947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4948, ptr %slot821, align 8
  %v4949 = load i32, ptr %slot821, align 8
  %cv4950 = zext i32 %v4949 to i64
  %cond4951 = icmp ne i64 %cv4950, 0
  br i1 %cond4951, label %bb_rcslotdrop1117, label %bb_rcslotdone1117
bb_rcslotdrop1117:
  %v4952 = load i64, ptr %slot17, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  store i32 0, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  %v4954 = load i64, ptr %slot26, align 8
  store i64 %v4954, ptr %slot822, align 8
  %v4955 = load i64, ptr %slot18, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %ld4957 = load i32, ptr %p4956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4957, ptr %slot823, align 8
  %v4958 = load i32, ptr %slot823, align 8
  %op4959 = and i32 %v4958, 28
  store i32 %op4959, ptr %slot824, align 8
  %v4960 = load i32, ptr %slot824, align 8
  %cv4961 = zext i32 %v4960 to i64
  %cond4962 = icmp ne i64 %cv4961, 0
  br i1 %cond4962, label %bb_rcslotrole1117, label %bb_rcslotowner1117
bb_rcslotrole1117:
  %v4963 = load i64, ptr %slot64, align 8
  store i64 %v4963, ptr %slot825, align 8
  %v4964 = load i64, ptr %slot822, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %ld4966 = load i64, ptr %p4965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4966, ptr %slot826, align 8
  %v4967 = load i64, ptr %slot826, align 8
  %cmp4968 = icmp ne i64 %v4967, 0
  %cv4969 = zext i1 %cmp4968 to i32
  store i32 %cv4969, ptr %slot827, align 8
  %v4970 = load i32, ptr %slot827, align 8
  %cv4971 = zext i32 %v4970 to i64
  %cond4972 = icmp ne i64 %cv4971, 0
  br i1 %cond4972, label %bb_rcgnn1133, label %bb_rcgdone1133
bb_rcgnn1133:
  %v4973 = load i64, ptr %slot826, align 8
  %op4974 = sub i64 %v4973, 16
  store i64 %op4974, ptr %slot828, align 8
  %v4975 = load i64, ptr %slot826, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %rgep4977 = getelementptr i8, ptr %p4976, i64 -16
  %ld4978 = load i64, ptr %rgep4977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4978, ptr %slot829, align 8
  %v4979 = load i64, ptr %slot829, align 8
  %op4980 = and i64 %v4979, 4611686018427387906
  store i64 %op4980, ptr %slot830, align 8
  %v4981 = load i64, ptr %slot830, align 8
  %cmp4982 = icmp ne i64 %v4981, 0
  %cv4983 = zext i1 %cmp4982 to i32
  store i32 %cv4983, ptr %slot831, align 8
  %v4984 = load i32, ptr %slot831, align 8
  %cv4985 = zext i32 %v4984 to i64
  %cond4986 = icmp ne i64 %cv4985, 0
  br i1 %cond4986, label %bb_rcgclear1133, label %bb_rcgcounted1133
bb_rcgcounted1133:
  %v4987 = load i64, ptr %slot826, align 8
  %op4988 = sub i64 %v4987, 24
  store i64 %op4988, ptr %slot832, align 8
  %v4989 = load i64, ptr %slot826, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %rgep4991 = getelementptr i8, ptr %p4990, i64 -24
  %ld4992 = load i64, ptr %rgep4991, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4992, ptr %slot833, align 8
  %v4993 = load i64, ptr %slot833, align 8
  %op4994 = sub i64 %v4993, 1
  store i64 %op4994, ptr %slot834, align 8
  %v4995 = load i64, ptr %slot834, align 8
  %cmp4996 = icmp eq i64 %v4995, 0
  %cv4997 = zext i1 %cmp4996 to i32
  store i32 %cv4997, ptr %slot835, align 8
  %v4998 = load i32, ptr %slot835, align 8
  %cv4999 = zext i32 %v4998 to i64
  %cond5000 = icmp ne i64 %cv4999, 0
  br i1 %cond5000, label %bb_rcglast1133, label %bb_rcgdec1133
bb_rcglast1133:
  %v5001 = load i64, ptr %slot826, align 8
  %op5002 = sub i64 %v5001, 32
  store i64 %op5002, ptr %slot836, align 8
  %v5003 = load i64, ptr %slot826, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %rgep5005 = getelementptr i8, ptr %p5004, i64 -32
  %ld5006 = load i64, ptr %rgep5005, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5006, ptr %slot837, align 8
  %v5007 = load i64, ptr %slot837, align 8
  %cmp5008 = icmp ne i64 %v5007, 0
  %cv5009 = zext i1 %cmp5008 to i32
  store i32 %cv5009, ptr %slot838, align 8
  %v5010 = load i32, ptr %slot838, align 8
  %cv5011 = zext i32 %v5010 to i64
  %cond5012 = icmp ne i64 %cv5011, 0
  br i1 %cond5012, label %bb_rcgdec1133, label %bb_rcgslow1133
bb_rcgslow1133:
  %v5013 = load i64, ptr %slot825, align 8
  %v5014 = load i64, ptr %slot822, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v5013, i64 %v5014) nomerge, !dbg !164
  br label %bb_rcgdone1133
bb_rcgdec1133:
  %v5015 = load i64, ptr %slot834, align 8
  %v5016 = load i64, ptr %slot826, align 8
  %p5017 = inttoptr i64 %v5016 to ptr
  %rgep5018 = getelementptr i8, ptr %p5017, i64 -24
  store i64 %v5015, ptr %rgep5018, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1133
bb_rcgclear1133:
  %v5019 = load i64, ptr %slot822, align 8
  %p5020 = inttoptr i64 %v5019 to ptr
  store i64 0, ptr %p5020, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1133
bb_rcgdone1133:
  br label %bb_rcslotdone1117
bb_rcslotowner1117:
  %v5021 = load i64, ptr %slot64, align 8
  store i64 %v5021, ptr %slot839, align 8
  %v5022 = load i64, ptr %slot822, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i64, ptr %p5023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5024, ptr %slot840, align 8
  %v5025 = load i64, ptr %slot840, align 8
  %cmp5026 = icmp ne i64 %v5025, 0
  %cv5027 = zext i1 %cmp5026 to i32
  store i32 %cv5027, ptr %slot841, align 8
  %v5028 = load i32, ptr %slot841, align 8
  %cv5029 = zext i32 %v5028 to i64
  %cond5030 = icmp ne i64 %cv5029, 0
  br i1 %cond5030, label %bb_rcgnn1148, label %bb_rcgdone1148
bb_rcgnn1148:
  %v5031 = load i64, ptr %slot840, align 8
  %op5032 = sub i64 %v5031, 16
  store i64 %op5032, ptr %slot842, align 8
  %v5033 = load i64, ptr %slot840, align 8
  %p5034 = inttoptr i64 %v5033 to ptr
  %rgep5035 = getelementptr i8, ptr %p5034, i64 -16
  %ld5036 = load i64, ptr %rgep5035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5036, ptr %slot843, align 8
  %v5037 = load i64, ptr %slot843, align 8
  %op5038 = and i64 %v5037, 4611686018427387906
  store i64 %op5038, ptr %slot844, align 8
  %v5039 = load i64, ptr %slot844, align 8
  %cmp5040 = icmp ne i64 %v5039, 0
  %cv5041 = zext i1 %cmp5040 to i32
  store i32 %cv5041, ptr %slot845, align 8
  %v5042 = load i32, ptr %slot845, align 8
  %cv5043 = zext i32 %v5042 to i64
  %cond5044 = icmp ne i64 %cv5043, 0
  br i1 %cond5044, label %bb_rcgclear1148, label %bb_rcgcounted1148
bb_rcgcounted1148:
  %v5045 = load i64, ptr %slot840, align 8
  %op5046 = sub i64 %v5045, 32
  store i64 %op5046, ptr %slot846, align 8
  %v5047 = load i64, ptr %slot840, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %rgep5049 = getelementptr i8, ptr %p5048, i64 -32
  %ld5050 = load i64, ptr %rgep5049, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5050, ptr %slot847, align 8
  %v5051 = load i64, ptr %slot847, align 8
  %op5052 = sub i64 %v5051, 1
  store i64 %op5052, ptr %slot848, align 8
  %v5053 = load i64, ptr %slot848, align 8
  %cmp5054 = icmp eq i64 %v5053, 0
  %cv5055 = zext i1 %cmp5054 to i32
  store i32 %cv5055, ptr %slot849, align 8
  %v5056 = load i32, ptr %slot849, align 8
  %cv5057 = zext i32 %v5056 to i64
  %cond5058 = icmp ne i64 %cv5057, 0
  br i1 %cond5058, label %bb_rcglast1148, label %bb_rcgdec1148
bb_rcglast1148:
  %v5059 = load i64, ptr %slot840, align 8
  %op5060 = sub i64 %v5059, 24
  store i64 %op5060, ptr %slot850, align 8
  %v5061 = load i64, ptr %slot840, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %rgep5063 = getelementptr i8, ptr %p5062, i64 -24
  %ld5064 = load i64, ptr %rgep5063, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5064, ptr %slot851, align 8
  %v5065 = load i64, ptr %slot851, align 8
  %cmp5066 = icmp ne i64 %v5065, 0
  %cv5067 = zext i1 %cmp5066 to i32
  store i32 %cv5067, ptr %slot852, align 8
  %v5068 = load i32, ptr %slot852, align 8
  %cv5069 = zext i32 %v5068 to i64
  %cond5070 = icmp ne i64 %cv5069, 0
  br i1 %cond5070, label %bb_rcgdec1148, label %bb_rcgslow1148
bb_rcgslow1148:
  %v5071 = load i64, ptr %slot839, align 8
  %v5072 = load i64, ptr %slot822, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v5071, i64 %v5072) nomerge, !dbg !164
  br label %bb_rcgdone1148
bb_rcgdec1148:
  %v5073 = load i64, ptr %slot848, align 8
  %v5074 = load i64, ptr %slot840, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  %rgep5076 = getelementptr i8, ptr %p5075, i64 -32
  store i64 %v5073, ptr %rgep5076, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1148
bb_rcgclear1148:
  %v5077 = load i64, ptr %slot822, align 8
  %p5078 = inttoptr i64 %v5077 to ptr
  store i64 0, ptr %p5078, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1148
bb_rcgdone1148:
  br label %bb_rcslotdone1117
bb_rcslotdone1117:
  %v5079 = load i64, ptr %slot820, align 8
  %op5080 = add i64 %v5079, 376
  store i64 %op5080, ptr %slot853, align 8
  store i64 0, ptr %slot854, align 8
  %v5081 = load i64, ptr %slot853, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  %ld5083 = load i64, ptr %p5082, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5083, ptr %slot855, align 8
  %v5084 = load i64, ptr %slot855, align 8
  %cmp5085 = icmp ne i64 %v5084, 0
  %cv5086 = zext i1 %cmp5085 to i32
  store i32 %cv5086, ptr %slot856, align 8
  %v5087 = load i32, ptr %slot856, align 8
  %cv5088 = zext i32 %v5087 to i64
  %cond5089 = icmp ne i64 %cv5088, 0
  br i1 %cond5089, label %bb_rcguniquenn1154, label %bb_rcgunique1154
bb_rcguniquenn1154:
  %v5090 = load i64, ptr %slot855, align 8
  %op5091 = sub i64 %v5090, 16
  store i64 %op5091, ptr %slot857, align 8
  %v5092 = load i64, ptr %slot855, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  %rgep5094 = getelementptr i8, ptr %p5093, i64 -16
  %ld5095 = load i64, ptr %rgep5094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5095, ptr %slot858, align 8
  %v5096 = load i64, ptr %slot858, align 8
  %op5097 = and i64 %v5096, 6917529027641081858
  store i64 %op5097, ptr %slot859, align 8
  %v5098 = load i64, ptr %slot859, align 8
  %cmp5099 = icmp ne i64 %v5098, 0
  %cv5100 = zext i1 %cmp5099 to i32
  store i32 %cv5100, ptr %slot860, align 8
  %v5101 = load i32, ptr %slot860, align 8
  %cv5102 = zext i32 %v5101 to i64
  %cond5103 = icmp ne i64 %cv5102, 0
  br i1 %cond5103, label %bb_rcguniqueslow1154, label %bb_rcguniquecount1154
bb_rcguniquecount1154:
  %v5104 = load i64, ptr %slot855, align 8
  %op5105 = sub i64 %v5104, 32
  store i64 %op5105, ptr %slot861, align 8
  %v5106 = load i64, ptr %slot855, align 8
  %p5107 = inttoptr i64 %v5106 to ptr
  %rgep5108 = getelementptr i8, ptr %p5107, i64 -32
  %ld5109 = load i64, ptr %rgep5108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5109, ptr %slot862, align 8
  %v5110 = load i64, ptr %slot862, align 8
  %cmp5111 = icmp ult i64 %v5110, 2
  %cv5112 = zext i1 %cmp5111 to i32
  store i32 %cv5112, ptr %slot863, align 8
  %v5113 = load i32, ptr %slot863, align 8
  %cv5114 = zext i32 %v5113 to i64
  %cond5115 = icmp ne i64 %cv5114, 0
  br i1 %cond5115, label %bb_rcgunique1154, label %bb_rcguniqueslow1154
bb_rcguniqueslow1154:
  %v5116 = load i64, ptr %slot1, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  %p5118 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v5119 = load i64, ptr %slot853, align 8
  %p5120 = inttoptr i64 %v5119 to ptr
  %v5121 = load i64, ptr %slot854, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  %call5123 = call i32 @myl_qbe_rc_unique_field(ptr %p5117, ptr %p5118, ptr %p5120, ptr %p5122) nomerge, !dbg !164
  store i32 %call5123, ptr %slot864, align 8
  %v5124 = load i32, ptr %slot864, align 8
  %cv5125 = zext i32 %v5124 to i64
  %cond5126 = icmp ne i64 %cv5125, 0
  br i1 %cond5126, label %bb_rcunique1164, label %bb_failure
bb_rcunique1164:
  br label %bb_rcgunique1154
bb_rcgunique1154:
  %v5127 = load i64, ptr %slot853, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  %ld5129 = load i64, ptr %p5128, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5129, ptr %slot865, align 8
  %v5130 = load i64, ptr %slot865, align 8
  %v5131 = load i64, ptr %slot52, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  store i64 %v5130, ptr %p5132, align 8, !alias.scope !3, !noalias !4
  %v5133 = load i64, ptr %slot52, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  %ld5135 = load i64, ptr %p5134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5135, ptr %slot866, align 8
  %v5136 = load i64, ptr %slot17, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  %ld5138 = load i32, ptr %p5137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5138, ptr %slot867, align 8
  %v5139 = load i32, ptr %slot867, align 8
  %cv5140 = zext i32 %v5139 to i64
  %cond5141 = icmp ne i64 %cv5140, 0
  br i1 %cond5141, label %bb_rcslotdrop1169, label %bb_rcslotdone1169
bb_rcslotdrop1169:
  %v5142 = load i64, ptr %slot17, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  store i32 0, ptr %p5143, align 4, !alias.scope !3, !noalias !4
  %v5144 = load i64, ptr %slot26, align 8
  store i64 %v5144, ptr %slot868, align 8
  %v5145 = load i64, ptr %slot18, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  %ld5147 = load i32, ptr %p5146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5147, ptr %slot869, align 8
  %v5148 = load i32, ptr %slot869, align 8
  %op5149 = and i32 %v5148, 28
  store i32 %op5149, ptr %slot870, align 8
  %v5150 = load i32, ptr %slot870, align 8
  %cv5151 = zext i32 %v5150 to i64
  %cond5152 = icmp ne i64 %cv5151, 0
  br i1 %cond5152, label %bb_rcslotrole1169, label %bb_rcslotowner1169
bb_rcslotrole1169:
  %v5153 = load i64, ptr %slot64, align 8
  store i64 %v5153, ptr %slot871, align 8
  %v5154 = load i64, ptr %slot868, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  %ld5156 = load i64, ptr %p5155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5156, ptr %slot872, align 8
  %v5157 = load i64, ptr %slot872, align 8
  %cmp5158 = icmp ne i64 %v5157, 0
  %cv5159 = zext i1 %cmp5158 to i32
  store i32 %cv5159, ptr %slot873, align 8
  %v5160 = load i32, ptr %slot873, align 8
  %cv5161 = zext i32 %v5160 to i64
  %cond5162 = icmp ne i64 %cv5161, 0
  br i1 %cond5162, label %bb_rcgnn1185, label %bb_rcgdone1185
bb_rcgnn1185:
  %v5163 = load i64, ptr %slot872, align 8
  %op5164 = sub i64 %v5163, 16
  store i64 %op5164, ptr %slot874, align 8
  %v5165 = load i64, ptr %slot872, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  %rgep5167 = getelementptr i8, ptr %p5166, i64 -16
  %ld5168 = load i64, ptr %rgep5167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5168, ptr %slot875, align 8
  %v5169 = load i64, ptr %slot875, align 8
  %op5170 = and i64 %v5169, 4611686018427387906
  store i64 %op5170, ptr %slot876, align 8
  %v5171 = load i64, ptr %slot876, align 8
  %cmp5172 = icmp ne i64 %v5171, 0
  %cv5173 = zext i1 %cmp5172 to i32
  store i32 %cv5173, ptr %slot877, align 8
  %v5174 = load i32, ptr %slot877, align 8
  %cv5175 = zext i32 %v5174 to i64
  %cond5176 = icmp ne i64 %cv5175, 0
  br i1 %cond5176, label %bb_rcgclear1185, label %bb_rcgcounted1185
bb_rcgcounted1185:
  %v5177 = load i64, ptr %slot872, align 8
  %op5178 = sub i64 %v5177, 24
  store i64 %op5178, ptr %slot878, align 8
  %v5179 = load i64, ptr %slot872, align 8
  %p5180 = inttoptr i64 %v5179 to ptr
  %rgep5181 = getelementptr i8, ptr %p5180, i64 -24
  %ld5182 = load i64, ptr %rgep5181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5182, ptr %slot879, align 8
  %v5183 = load i64, ptr %slot879, align 8
  %op5184 = sub i64 %v5183, 1
  store i64 %op5184, ptr %slot880, align 8
  %v5185 = load i64, ptr %slot880, align 8
  %cmp5186 = icmp eq i64 %v5185, 0
  %cv5187 = zext i1 %cmp5186 to i32
  store i32 %cv5187, ptr %slot881, align 8
  %v5188 = load i32, ptr %slot881, align 8
  %cv5189 = zext i32 %v5188 to i64
  %cond5190 = icmp ne i64 %cv5189, 0
  br i1 %cond5190, label %bb_rcglast1185, label %bb_rcgdec1185
bb_rcglast1185:
  %v5191 = load i64, ptr %slot872, align 8
  %op5192 = sub i64 %v5191, 32
  store i64 %op5192, ptr %slot882, align 8
  %v5193 = load i64, ptr %slot872, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %rgep5195 = getelementptr i8, ptr %p5194, i64 -32
  %ld5196 = load i64, ptr %rgep5195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5196, ptr %slot883, align 8
  %v5197 = load i64, ptr %slot883, align 8
  %cmp5198 = icmp ne i64 %v5197, 0
  %cv5199 = zext i1 %cmp5198 to i32
  store i32 %cv5199, ptr %slot884, align 8
  %v5200 = load i32, ptr %slot884, align 8
  %cv5201 = zext i32 %v5200 to i64
  %cond5202 = icmp ne i64 %cv5201, 0
  br i1 %cond5202, label %bb_rcgdec1185, label %bb_rcgslow1185
bb_rcgslow1185:
  %v5203 = load i64, ptr %slot871, align 8
  %v5204 = load i64, ptr %slot868, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v5203, i64 %v5204) nomerge, !dbg !164
  br label %bb_rcgdone1185
bb_rcgdec1185:
  %v5205 = load i64, ptr %slot880, align 8
  %v5206 = load i64, ptr %slot872, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  %rgep5208 = getelementptr i8, ptr %p5207, i64 -24
  store i64 %v5205, ptr %rgep5208, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1185
bb_rcgclear1185:
  %v5209 = load i64, ptr %slot868, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  store i64 0, ptr %p5210, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1185
bb_rcgdone1185:
  br label %bb_rcslotdone1169
bb_rcslotowner1169:
  %v5211 = load i64, ptr %slot64, align 8
  store i64 %v5211, ptr %slot885, align 8
  %v5212 = load i64, ptr %slot868, align 8
  %p5213 = inttoptr i64 %v5212 to ptr
  %ld5214 = load i64, ptr %p5213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5214, ptr %slot886, align 8
  %v5215 = load i64, ptr %slot886, align 8
  %cmp5216 = icmp ne i64 %v5215, 0
  %cv5217 = zext i1 %cmp5216 to i32
  store i32 %cv5217, ptr %slot887, align 8
  %v5218 = load i32, ptr %slot887, align 8
  %cv5219 = zext i32 %v5218 to i64
  %cond5220 = icmp ne i64 %cv5219, 0
  br i1 %cond5220, label %bb_rcgnn1200, label %bb_rcgdone1200
bb_rcgnn1200:
  %v5221 = load i64, ptr %slot886, align 8
  %op5222 = sub i64 %v5221, 16
  store i64 %op5222, ptr %slot888, align 8
  %v5223 = load i64, ptr %slot886, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  %rgep5225 = getelementptr i8, ptr %p5224, i64 -16
  %ld5226 = load i64, ptr %rgep5225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5226, ptr %slot889, align 8
  %v5227 = load i64, ptr %slot889, align 8
  %op5228 = and i64 %v5227, 4611686018427387906
  store i64 %op5228, ptr %slot890, align 8
  %v5229 = load i64, ptr %slot890, align 8
  %cmp5230 = icmp ne i64 %v5229, 0
  %cv5231 = zext i1 %cmp5230 to i32
  store i32 %cv5231, ptr %slot891, align 8
  %v5232 = load i32, ptr %slot891, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcgclear1200, label %bb_rcgcounted1200
bb_rcgcounted1200:
  %v5235 = load i64, ptr %slot886, align 8
  %op5236 = sub i64 %v5235, 32
  store i64 %op5236, ptr %slot892, align 8
  %v5237 = load i64, ptr %slot886, align 8
  %p5238 = inttoptr i64 %v5237 to ptr
  %rgep5239 = getelementptr i8, ptr %p5238, i64 -32
  %ld5240 = load i64, ptr %rgep5239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5240, ptr %slot893, align 8
  %v5241 = load i64, ptr %slot893, align 8
  %op5242 = sub i64 %v5241, 1
  store i64 %op5242, ptr %slot894, align 8
  %v5243 = load i64, ptr %slot894, align 8
  %cmp5244 = icmp eq i64 %v5243, 0
  %cv5245 = zext i1 %cmp5244 to i32
  store i32 %cv5245, ptr %slot895, align 8
  %v5246 = load i32, ptr %slot895, align 8
  %cv5247 = zext i32 %v5246 to i64
  %cond5248 = icmp ne i64 %cv5247, 0
  br i1 %cond5248, label %bb_rcglast1200, label %bb_rcgdec1200
bb_rcglast1200:
  %v5249 = load i64, ptr %slot886, align 8
  %op5250 = sub i64 %v5249, 24
  store i64 %op5250, ptr %slot896, align 8
  %v5251 = load i64, ptr %slot886, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  %rgep5253 = getelementptr i8, ptr %p5252, i64 -24
  %ld5254 = load i64, ptr %rgep5253, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5254, ptr %slot897, align 8
  %v5255 = load i64, ptr %slot897, align 8
  %cmp5256 = icmp ne i64 %v5255, 0
  %cv5257 = zext i1 %cmp5256 to i32
  store i32 %cv5257, ptr %slot898, align 8
  %v5258 = load i32, ptr %slot898, align 8
  %cv5259 = zext i32 %v5258 to i64
  %cond5260 = icmp ne i64 %cv5259, 0
  br i1 %cond5260, label %bb_rcgdec1200, label %bb_rcgslow1200
bb_rcgslow1200:
  %v5261 = load i64, ptr %slot885, align 8
  %v5262 = load i64, ptr %slot868, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v5261, i64 %v5262) nomerge, !dbg !164
  br label %bb_rcgdone1200
bb_rcgdec1200:
  %v5263 = load i64, ptr %slot894, align 8
  %v5264 = load i64, ptr %slot886, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  %rgep5266 = getelementptr i8, ptr %p5265, i64 -32
  store i64 %v5263, ptr %rgep5266, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1200
bb_rcgclear1200:
  %v5267 = load i64, ptr %slot868, align 8
  %p5268 = inttoptr i64 %v5267 to ptr
  store i64 0, ptr %p5268, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1200
bb_rcgdone1200:
  br label %bb_rcslotdone1169
bb_rcslotdone1169:
  %v5269 = load i64, ptr %slot866, align 8
  %v5270 = load i64, ptr %slot46, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  store i64 %v5269, ptr %p5271, align 8, !alias.scope !3, !noalias !4
  %v5272 = load i64, ptr %slot40, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %ld5274 = load i64, ptr %p5273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5274, ptr %slot899, align 8
  %v5275 = load i64, ptr %slot899, align 8
  %v5276 = load i64, ptr %slot52, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  store i64 %v5275, ptr %p5277, align 8, !alias.scope !3, !noalias !4
  %v5278 = load i64, ptr %slot52, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %ld5280 = load i64, ptr %p5279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5280, ptr %slot900, align 8
  %v5281 = load i64, ptr %slot900, align 8
  %v5282 = load i64, ptr %slot48, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  store i64 %v5281, ptr %p5283, align 8, !alias.scope !3, !noalias !4
  %v5284 = load i64, ptr %slot48, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  %ld5286 = load i64, ptr %p5285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5286, ptr %slot901, align 8
  %v5287 = load i64, ptr %slot901, align 8
  %v5288 = load i64, ptr %slot52, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  store i64 %v5287, ptr %p5289, align 8, !alias.scope !3, !noalias !4
  %v5290 = load i64, ptr %slot53, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  store i64 0, ptr %p5291, align 8, !alias.scope !3, !noalias !4
  %v5292 = load i64, ptr %slot53, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %ld5294 = load i64, ptr %p5293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5294, ptr %slot902, align 8
  %v5295 = load i64, ptr %slot52, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  %ld5297 = load i64, ptr %p5296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5297, ptr %slot903, align 8
  %v5298 = load i64, ptr %slot903, align 8
  %v5299 = load i64, ptr %slot902, align 8
  %cmp5300 = icmp slt i64 %v5298, %v5299
  %cv5301 = zext i1 %cmp5300 to i64
  store i64 %cv5301, ptr %slot904, align 8
  %v5302 = load i64, ptr %slot904, align 8
  %v5303 = load i64, ptr %slot52, align 8
  %p5304 = inttoptr i64 %v5303 to ptr
  store i64 %v5302, ptr %p5304, align 8, !alias.scope !3, !noalias !4
  %v5305 = load i64, ptr %slot52, align 8
  %p5306 = inttoptr i64 %v5305 to ptr
  %ld5307 = load i64, ptr %p5306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5307, ptr %slot905, align 8
  %v5308 = load i64, ptr %slot905, align 8
  %cond5309 = icmp ne i64 %v5308, 0
  br i1 %cond5309, label %bb_next1248, label %bb_i69
bb_next1248:
  %v5310 = load i64, ptr %slot46, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %ld5312 = load i64, ptr %p5311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5312, ptr %slot906, align 8
  %v5313 = load i64, ptr %slot906, align 8
  %op5314 = add i64 %v5313, 0
  store i64 %op5314, ptr %slot907, align 8
  %v5315 = load i64, ptr %slot907, align 8
  %p5316 = inttoptr i64 %v5315 to ptr
  %ld5317 = load i64, ptr %p5316, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5317, ptr %slot908, align 8
  %v5318 = load i64, ptr %slot908, align 8
  %v5319 = load i64, ptr %slot52, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  store i64 %v5318, ptr %p5320, align 8, !alias.scope !3, !noalias !4
  %v5321 = load i64, ptr %slot52, align 8
  %p5322 = inttoptr i64 %v5321 to ptr
  %ld5323 = load i64, ptr %p5322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5323, ptr %slot909, align 8
  %v5324 = load i64, ptr %slot909, align 8
  %cmp5325 = icmp ugt i64 %v5324, 9223372036854775807
  %cv5326 = zext i1 %cmp5325 to i64
  store i64 %cv5326, ptr %slot910, align 8
  %v5327 = load i64, ptr %slot910, align 8
  %cond5328 = icmp ne i64 %v5327, 0
  br i1 %cond5328, label %bb_cast_overflow1253, label %bb_cast_ok1253
bb_cast_overflow1253:
  %v5329 = load i64, ptr %slot1, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %v5331 = load i64, ptr %slot909, align 8
  call void @myl_qbe_fail_cast(ptr %p5330, i64 %v5331, i64 320) nomerge, !dbg !166
  unreachable
bb_cast_ok1253:
  %v5332 = load i64, ptr %slot909, align 8
  %v5333 = load i64, ptr %slot52, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  store i64 %v5332, ptr %p5334, align 8, !alias.scope !3, !noalias !4
  %v5335 = load i64, ptr %slot48, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %ld5337 = load i64, ptr %p5336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5337, ptr %slot911, align 8
  %v5338 = load i64, ptr %slot911, align 8
  %v5339 = load i64, ptr %slot53, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  store i64 %v5338, ptr %p5340, align 8, !alias.scope !3, !noalias !4
  %v5341 = load i64, ptr %slot53, align 8
  %p5342 = inttoptr i64 %v5341 to ptr
  %ld5343 = load i64, ptr %p5342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5343, ptr %slot912, align 8
  %v5344 = load i64, ptr %slot52, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  %ld5346 = load i64, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5346, ptr %slot913, align 8
  %v5347 = load i64, ptr %slot913, align 8
  %v5348 = load i64, ptr %slot912, align 8
  %ovpair5350 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5347, i64 %v5348)
  %op5349 = extractvalue { i64, i1 } %ovpair5350, 0
  %ov5351 = extractvalue { i64, i1 } %ovpair5350, 1
  store i64 %op5349, ptr %slot914, align 8
  %v5352 = load i64, ptr %slot913, align 8
  %v5353 = load i64, ptr %slot914, align 8
  %op5354 = xor i64 %v5352, %v5353
  store i64 %op5354, ptr %slot915, align 8
  %v5355 = load i64, ptr %slot912, align 8
  %v5356 = load i64, ptr %slot914, align 8
  %op5357 = xor i64 %v5355, %v5356
  store i64 %op5357, ptr %slot916, align 8
  %v5358 = load i64, ptr %slot915, align 8
  %v5359 = load i64, ptr %slot916, align 8
  %op5360 = and i64 %v5358, %v5359
  store i64 %op5360, ptr %slot917, align 8
  %cv5361 = zext i1 %ov5351 to i64
  store i64 %cv5361, ptr %slot918, align 8
  %v5362 = load i64, ptr %slot918, align 8
  %cond5363 = icmp ne i64 %v5362, 0
  br i1 %cond5363, label %bb_overflow1257, label %bb_checked1257
bb_overflow1257:
  %v5364 = load i64, ptr %slot1, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %v5366 = load i64, ptr %slot913, align 8
  %v5367 = load i64, ptr %slot912, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5365, i64 0, i64 %v5366, i64 %v5367, i64 64) nomerge, !dbg !168
  unreachable
bb_checked1257:
  %v5368 = load i64, ptr %slot914, align 8
  %v5369 = load i64, ptr %slot52, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  store i64 %v5368, ptr %p5370, align 8, !alias.scope !3, !noalias !4
  %v5371 = load i64, ptr %slot52, align 8
  %p5372 = inttoptr i64 %v5371 to ptr
  %ld5373 = load i64, ptr %p5372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5373, ptr %slot919, align 8
  %v5374 = load i64, ptr %slot919, align 8
  %v5375 = load i64, ptr %slot48, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  store i64 %v5374, ptr %p5376, align 8, !alias.scope !3, !noalias !4
  br label %bb_i69
bb_i69:
  %v5377 = load i64, ptr %slot48, align 8
  %p5378 = inttoptr i64 %v5377 to ptr
  %ld5379 = load i64, ptr %p5378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5379, ptr %slot920, align 8
  %v5380 = load i64, ptr %slot920, align 8
  %v5381 = load i64, ptr %slot52, align 8
  %p5382 = inttoptr i64 %v5381 to ptr
  store i64 %v5380, ptr %p5382, align 8, !alias.scope !3, !noalias !4
  %v5383 = load i64, ptr %slot47, align 8
  %v5384 = load i64, ptr %slot53, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  store i64 %v5383, ptr %p5385, align 8, !alias.scope !3, !noalias !4
  %v5386 = load i64, ptr %slot53, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %ld5388 = load i64, ptr %p5387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5388, ptr %slot921, align 8
  %v5389 = load i64, ptr %slot19, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  %ld5391 = load i32, ptr %p5390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5391, ptr %slot922, align 8
  %v5392 = load i64, ptr %slot20, align 8
  %p5393 = inttoptr i64 %v5392 to ptr
  %ld5394 = load i32, ptr %p5393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5394, ptr %slot923, align 8
  %v5395 = load i32, ptr %slot923, align 8
  %op5396 = and i32 %v5395, 24
  store i32 %op5396, ptr %slot923, align 8
  %v5397 = load i32, ptr %slot923, align 8
  %cmp5398 = icmp eq i32 %v5397, 0
  %cv5399 = zext i1 %cmp5398 to i32
  store i32 %cv5399, ptr %slot924, align 8
  %v5400 = load i32, ptr %slot922, align 8
  %v5401 = load i32, ptr %slot924, align 8
  %op5402 = and i32 %v5400, %v5401
  store i32 %op5402, ptr %slot925, align 8
  %v5403 = load i64, ptr %slot65, align 8
  store i64 %v5403, ptr %slot926, align 8
  %v5404 = load i32, ptr %slot925, align 8
  %op5405 = mul i32 %v5404, 4
  store i32 %op5405, ptr %slot927, align 8
  %v5406 = load i32, ptr %slot927, align 8
  %op5407 = or i32 %v5406, 0
  store i32 %op5407, ptr %slot928, align 8
  %v5408 = load i64, ptr %slot30, align 8
  store i64 %v5408, ptr %slot929, align 8
  %v5409 = load i64, ptr %slot64, align 8
  %v5410 = load i64, ptr %slot929, align 8
  %v5411 = load i64, ptr %slot921, align 8
  %v5412 = load i64, ptr %slot926, align 8
  %cv5413 = trunc i64 %v5412 to i32
  %v5414 = load i32, ptr %slot928, align 8
  %call5415 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v5409, i64 %v5410, i64 %v5411, i32 %cv5413, i32 %v5414) nomerge, !dbg !170
  store i32 %call5415, ptr %slot930, align 8
  %v5416 = load i32, ptr %slot930, align 8
  %cv5417 = zext i32 %v5416 to i64
  %cond5418 = icmp ne i64 %cv5417, 0
  br i1 %cond5418, label %bb_rcsuccess1278, label %bb_rcfailure1278
bb_rcfailure1278:
  %v5419 = load i64, ptr %slot64, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  %call5421 = call i32 @myl_rc_take_failure(ptr %p5420) nomerge, !dbg !170
  store i32 %call5421, ptr %slot931, align 8
  %v5422 = load i64, ptr %slot1, align 8
  %p5423 = inttoptr i64 %v5422 to ptr
  %v5424 = load i32, ptr %slot931, align 8
  %call5425 = call i32 @myl_qbe_rc_status(ptr %p5423, i32 %v5424) nomerge, !dbg !170
  store i32 %call5425, ptr %slot932, align 8
  br label %bb_failure
bb_rcsuccess1278:
  %v5426 = load i32, ptr %slot925, align 8
  %cv5427 = zext i32 %v5426 to i64
  %cond5428 = icmp ne i64 %cv5427, 0
  br i1 %cond5428, label %bb_rchtaken1281, label %bb_rchcopied1281
bb_rchcopied1281:
  %v5429 = load i64, ptr %slot19, align 8
  %p5430 = inttoptr i64 %v5429 to ptr
  %ld5431 = load i32, ptr %p5430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5431, ptr %slot933, align 8
  %v5432 = load i32, ptr %slot933, align 8
  %cv5433 = zext i32 %v5432 to i64
  %cond5434 = icmp ne i64 %cv5433, 0
  br i1 %cond5434, label %bb_rcslotdrop1284, label %bb_rcslotdone1284
bb_rcslotdrop1284:
  %v5435 = load i64, ptr %slot19, align 8
  %p5436 = inttoptr i64 %v5435 to ptr
  store i32 0, ptr %p5436, align 4, !alias.scope !3, !noalias !4
  %v5437 = load i64, ptr %slot27, align 8
  store i64 %v5437, ptr %slot934, align 8
  %v5438 = load i64, ptr %slot20, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %ld5440 = load i32, ptr %p5439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5440, ptr %slot935, align 8
  %v5441 = load i32, ptr %slot935, align 8
  %op5442 = and i32 %v5441, 28
  store i32 %op5442, ptr %slot936, align 8
  %v5443 = load i32, ptr %slot936, align 8
  %cv5444 = zext i32 %v5443 to i64
  %cond5445 = icmp ne i64 %cv5444, 0
  br i1 %cond5445, label %bb_rcslotrole1284, label %bb_rcslotowner1284
bb_rcslotrole1284:
  %v5446 = load i64, ptr %slot64, align 8
  store i64 %v5446, ptr %slot937, align 8
  %v5447 = load i64, ptr %slot937, align 8
  %v5448 = load i64, ptr %slot934, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5447, i64 %v5448) nomerge, !dbg !170
  br label %bb_rcslotdone1284
bb_rcslotowner1284:
  %v5449 = load i64, ptr %slot64, align 8
  store i64 %v5449, ptr %slot938, align 8
  %v5450 = load i64, ptr %slot938, align 8
  %v5451 = load i64, ptr %slot934, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5450, i64 %v5451) nomerge, !dbg !170
  br label %bb_rcslotdone1284
bb_rcslotdone1284:
  br label %bb_rchprepared1281
bb_rchtaken1281:
  %v5452 = load i64, ptr %slot19, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  store i32 0, ptr %p5453, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1281
bb_rchprepared1281:
  %v5454 = load i64, ptr %slot24, align 8
  %p5455 = inttoptr i64 %v5454 to ptr
  store i32 2, ptr %p5455, align 4, !alias.scope !3, !noalias !4
  %v5456 = load i64, ptr %slot23, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  store i32 1, ptr %p5457, align 4, !alias.scope !3, !noalias !4
  %v5458 = load i64, ptr %slot27, align 8
  store i64 %v5458, ptr %slot939, align 8
  %v5459 = load i64, ptr %slot30, align 8
  store i64 %v5459, ptr %slot940, align 8
  %v5460 = load i64, ptr %slot940, align 8
  %v5461 = load i64, ptr %slot939, align 8
  %p5462 = inttoptr i64 %v5460 to ptr
  %p5463 = inttoptr i64 %v5461 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5463, ptr %p5462, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5464 = load i64, ptr %slot20, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i32 2, ptr %p5465, align 4, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot24, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %ld5468 = load i32, ptr %p5467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5468, ptr %slot941, align 8
  %v5469 = load i32, ptr %slot941, align 8
  %v5470 = load i64, ptr %slot20, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  store i32 %v5469, ptr %p5471, align 4, !alias.scope !3, !noalias !4
  %v5472 = load i64, ptr %slot23, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  store i32 0, ptr %p5473, align 4, !alias.scope !3, !noalias !4
  %v5474 = load i64, ptr %slot19, align 8
  %p5475 = inttoptr i64 %v5474 to ptr
  store i32 1, ptr %p5475, align 4, !alias.scope !3, !noalias !4
  %v5476 = load i64, ptr %slot939, align 8
  %v5477 = load i64, ptr %slot53, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  store i64 %v5476, ptr %p5478, align 8, !alias.scope !3, !noalias !4
  %v5479 = load i64, ptr %slot46, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %ld5481 = load i64, ptr %p5480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5481, ptr %slot942, align 8
  %v5482 = load i64, ptr %slot53, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  %ld5484 = load i64, ptr %p5483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5484, ptr %slot943, align 8
  %v5485 = load i64, ptr %slot52, align 8
  %p5486 = inttoptr i64 %v5485 to ptr
  %ld5487 = load i64, ptr %p5486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5487, ptr %slot944, align 8
  %v5488 = load i64, ptr %slot942, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  %ld5490 = load i64, ptr %p5489, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5490, ptr %slot945, align 8
  %v5491 = load i64, ptr %slot944, align 8
  %v5492 = load i64, ptr %slot945, align 8
  %cmp5493 = icmp ult i64 %v5491, %v5492
  %cv5494 = zext i1 %cmp5493 to i64
  store i64 %cv5494, ptr %slot946, align 8
  %v5495 = load i64, ptr %slot946, align 8
  %cond5496 = icmp ne i64 %v5495, 0
  br i1 %cond5496, label %bb_success1308, label %bb_failed1308
bb_failed1308:
  %v5497 = load i64, ptr %slot1, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  %v5499 = load i64, ptr %slot944, align 8
  %v5500 = load i64, ptr %slot945, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5498, i64 %v5499, i64 %v5500) nomerge, !dbg !172
  unreachable
bb_success1308:
  %v5501 = load i64, ptr %slot53, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %ld5503 = load i64, ptr %p5502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5503, ptr %slot947, align 8
  %v5504 = load i64, ptr %slot64, align 8
  %v5505 = load i64, ptr %slot942, align 8
  %v5506 = load i64, ptr %slot944, align 8
  %v5507 = load i64, ptr %slot947, align 8
  %call5508 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v5504, i64 %v5505, i64 %v5506, i64 %v5507) nomerge, !dbg !172
  store i32 %call5508, ptr %slot948, align 8
  %v5509 = load i32, ptr %slot948, align 8
  %cv5510 = zext i32 %v5509 to i64
  %cond5511 = icmp ne i64 %cv5510, 0
  br i1 %cond5511, label %bb_success1311, label %bb_failed1311
bb_failed1311:
  %v5512 = load i64, ptr %slot1, align 8
  %p5513 = inttoptr i64 %v5512 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5513) nomerge, !dbg !172
  unreachable
bb_success1311:
  %v5514 = load i64, ptr %slot52, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  store i64 0, ptr %p5515, align 8, !alias.scope !3, !noalias !4
  %v5516 = load i64, ptr %slot19, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %ld5518 = load i32, ptr %p5517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5518, ptr %slot949, align 8
  %v5519 = load i32, ptr %slot949, align 8
  %cv5520 = zext i32 %v5519 to i64
  %cond5521 = icmp ne i64 %cv5520, 0
  br i1 %cond5521, label %bb_rcslotdrop1314, label %bb_rcslotdone1314
bb_rcslotdrop1314:
  %v5522 = load i64, ptr %slot19, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  store i32 0, ptr %p5523, align 4, !alias.scope !3, !noalias !4
  %v5524 = load i64, ptr %slot27, align 8
  store i64 %v5524, ptr %slot950, align 8
  %v5525 = load i64, ptr %slot20, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  %ld5527 = load i32, ptr %p5526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5527, ptr %slot951, align 8
  %v5528 = load i32, ptr %slot951, align 8
  %op5529 = and i32 %v5528, 28
  store i32 %op5529, ptr %slot952, align 8
  %v5530 = load i32, ptr %slot952, align 8
  %cv5531 = zext i32 %v5530 to i64
  %cond5532 = icmp ne i64 %cv5531, 0
  br i1 %cond5532, label %bb_rcslotrole1314, label %bb_rcslotowner1314
bb_rcslotrole1314:
  %v5533 = load i64, ptr %slot64, align 8
  store i64 %v5533, ptr %slot953, align 8
  %v5534 = load i64, ptr %slot953, align 8
  %v5535 = load i64, ptr %slot950, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5534, i64 %v5535) nomerge, !dbg !172
  br label %bb_rcslotdone1314
bb_rcslotowner1314:
  %v5536 = load i64, ptr %slot64, align 8
  store i64 %v5536, ptr %slot954, align 8
  %v5537 = load i64, ptr %slot954, align 8
  %v5538 = load i64, ptr %slot950, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5537, i64 %v5538) nomerge, !dbg !172
  br label %bb_rcslotdone1314
bb_rcslotdone1314:
  %v5539 = load i64, ptr %slot43, align 8
  %v5540 = load i64, ptr %slot52, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  store i64 %v5539, ptr %p5541, align 8, !alias.scope !3, !noalias !4
  %v5542 = load i64, ptr %slot52, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %ld5544 = load i64, ptr %p5543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5544, ptr %slot955, align 8
  %v5545 = load i64, ptr %slot955, align 8
  %op5546 = add i64 %v5545, 0
  store i64 %op5546, ptr %slot956, align 8
  %v5547 = load i64, ptr %slot956, align 8
  %v5548 = load i64, ptr %slot52, align 8
  %p5549 = inttoptr i64 %v5548 to ptr
  store i64 %v5547, ptr %p5549, align 8, !alias.scope !3, !noalias !4
  %v5550 = load i64, ptr %slot17, align 8
  %p5551 = inttoptr i64 %v5550 to ptr
  %ld5552 = load i32, ptr %p5551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5552, ptr %slot957, align 8
  %v5553 = load i32, ptr %slot957, align 8
  %cv5554 = zext i32 %v5553 to i64
  %cond5555 = icmp ne i64 %cv5554, 0
  br i1 %cond5555, label %bb_rcslotdrop1325, label %bb_rcslotdone1325
bb_rcslotdrop1325:
  %v5556 = load i64, ptr %slot17, align 8
  %p5557 = inttoptr i64 %v5556 to ptr
  store i32 0, ptr %p5557, align 4, !alias.scope !3, !noalias !4
  %v5558 = load i64, ptr %slot26, align 8
  store i64 %v5558, ptr %slot958, align 8
  %v5559 = load i64, ptr %slot18, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %ld5561 = load i32, ptr %p5560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5561, ptr %slot959, align 8
  %v5562 = load i32, ptr %slot959, align 8
  %op5563 = and i32 %v5562, 28
  store i32 %op5563, ptr %slot960, align 8
  %v5564 = load i32, ptr %slot960, align 8
  %cv5565 = zext i32 %v5564 to i64
  %cond5566 = icmp ne i64 %cv5565, 0
  br i1 %cond5566, label %bb_rcslotrole1325, label %bb_rcslotowner1325
bb_rcslotrole1325:
  %v5567 = load i64, ptr %slot64, align 8
  store i64 %v5567, ptr %slot961, align 8
  %v5568 = load i64, ptr %slot961, align 8
  %v5569 = load i64, ptr %slot958, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5568, i64 %v5569) nomerge, !dbg !174
  br label %bb_rcslotdone1325
bb_rcslotowner1325:
  %v5570 = load i64, ptr %slot64, align 8
  store i64 %v5570, ptr %slot962, align 8
  %v5571 = load i64, ptr %slot962, align 8
  %v5572 = load i64, ptr %slot958, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5571, i64 %v5572) nomerge, !dbg !174
  br label %bb_rcslotdone1325
bb_rcslotdone1325:
  %v5573 = load i64, ptr %slot52, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %ld5575 = load i64, ptr %p5574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5575, ptr %slot963, align 8
  %v5576 = load i64, ptr %slot17, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  %ld5578 = load i32, ptr %p5577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5578, ptr %slot964, align 8
  %v5579 = load i64, ptr %slot18, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  %ld5581 = load i32, ptr %p5580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5581, ptr %slot965, align 8
  %v5582 = load i32, ptr %slot965, align 8
  %op5583 = and i32 %v5582, 24
  store i32 %op5583, ptr %slot965, align 8
  %v5584 = load i32, ptr %slot965, align 8
  %cmp5585 = icmp eq i32 %v5584, 0
  %cv5586 = zext i1 %cmp5585 to i32
  store i32 %cv5586, ptr %slot966, align 8
  %v5587 = load i32, ptr %slot964, align 8
  %v5588 = load i32, ptr %slot966, align 8
  %op5589 = and i32 %v5587, %v5588
  store i32 %op5589, ptr %slot967, align 8
  %v5590 = load i64, ptr %slot65, align 8
  store i64 %v5590, ptr %slot968, align 8
  %v5591 = load i32, ptr %slot967, align 8
  %op5592 = mul i32 %v5591, 4
  store i32 %op5592, ptr %slot969, align 8
  %v5593 = load i32, ptr %slot969, align 8
  %op5594 = or i32 %v5593, 0
  store i32 %op5594, ptr %slot970, align 8
  %v5595 = load i64, ptr %slot30, align 8
  store i64 %v5595, ptr %slot971, align 8
  %v5596 = load i64, ptr %slot64, align 8
  %v5597 = load i64, ptr %slot971, align 8
  %v5598 = load i64, ptr %slot963, align 8
  %v5599 = load i64, ptr %slot968, align 8
  %cv5600 = trunc i64 %v5599 to i32
  %v5601 = load i32, ptr %slot970, align 8
  %call5602 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v5596, i64 %v5597, i64 %v5598, i32 %cv5600, i32 %v5601) nomerge, !dbg !176
  store i32 %call5602, ptr %slot972, align 8
  %v5603 = load i32, ptr %slot972, align 8
  %cv5604 = zext i32 %v5603 to i64
  %cond5605 = icmp ne i64 %cv5604, 0
  br i1 %cond5605, label %bb_rcsuccess1346, label %bb_rcfailure1346
bb_rcfailure1346:
  %v5606 = load i64, ptr %slot64, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  %call5608 = call i32 @myl_rc_take_failure(ptr %p5607) nomerge, !dbg !176
  store i32 %call5608, ptr %slot973, align 8
  %v5609 = load i64, ptr %slot1, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  %v5611 = load i32, ptr %slot973, align 8
  %call5612 = call i32 @myl_qbe_rc_status(ptr %p5610, i32 %v5611) nomerge, !dbg !176
  store i32 %call5612, ptr %slot974, align 8
  br label %bb_failure
bb_rcsuccess1346:
  %v5613 = load i32, ptr %slot967, align 8
  %cv5614 = zext i32 %v5613 to i64
  %cond5615 = icmp ne i64 %cv5614, 0
  br i1 %cond5615, label %bb_rchtaken1349, label %bb_rchcopied1349
bb_rchcopied1349:
  %v5616 = load i64, ptr %slot17, align 8
  %p5617 = inttoptr i64 %v5616 to ptr
  %ld5618 = load i32, ptr %p5617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5618, ptr %slot975, align 8
  %v5619 = load i32, ptr %slot975, align 8
  %cv5620 = zext i32 %v5619 to i64
  %cond5621 = icmp ne i64 %cv5620, 0
  br i1 %cond5621, label %bb_rcslotdrop1352, label %bb_rcslotdone1352
bb_rcslotdrop1352:
  %v5622 = load i64, ptr %slot17, align 8
  %p5623 = inttoptr i64 %v5622 to ptr
  store i32 0, ptr %p5623, align 4, !alias.scope !3, !noalias !4
  %v5624 = load i64, ptr %slot26, align 8
  store i64 %v5624, ptr %slot976, align 8
  %v5625 = load i64, ptr %slot18, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  %ld5627 = load i32, ptr %p5626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5627, ptr %slot977, align 8
  %v5628 = load i32, ptr %slot977, align 8
  %op5629 = and i32 %v5628, 28
  store i32 %op5629, ptr %slot978, align 8
  %v5630 = load i32, ptr %slot978, align 8
  %cv5631 = zext i32 %v5630 to i64
  %cond5632 = icmp ne i64 %cv5631, 0
  br i1 %cond5632, label %bb_rcslotrole1352, label %bb_rcslotowner1352
bb_rcslotrole1352:
  %v5633 = load i64, ptr %slot64, align 8
  store i64 %v5633, ptr %slot979, align 8
  %v5634 = load i64, ptr %slot979, align 8
  %v5635 = load i64, ptr %slot976, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v5634, i64 %v5635) nomerge, !dbg !176
  br label %bb_rcslotdone1352
bb_rcslotowner1352:
  %v5636 = load i64, ptr %slot64, align 8
  store i64 %v5636, ptr %slot980, align 8
  %v5637 = load i64, ptr %slot980, align 8
  %v5638 = load i64, ptr %slot976, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v5637, i64 %v5638) nomerge, !dbg !176
  br label %bb_rcslotdone1352
bb_rcslotdone1352:
  br label %bb_rchprepared1349
bb_rchtaken1349:
  %v5639 = load i64, ptr %slot17, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  store i32 0, ptr %p5640, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1349
bb_rchprepared1349:
  %v5641 = load i64, ptr %slot24, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  store i32 2, ptr %p5642, align 4, !alias.scope !3, !noalias !4
  %v5643 = load i64, ptr %slot23, align 8
  %p5644 = inttoptr i64 %v5643 to ptr
  store i32 1, ptr %p5644, align 4, !alias.scope !3, !noalias !4
  %v5645 = load i64, ptr %slot26, align 8
  store i64 %v5645, ptr %slot981, align 8
  %v5646 = load i64, ptr %slot30, align 8
  store i64 %v5646, ptr %slot982, align 8
  %v5647 = load i64, ptr %slot982, align 8
  %v5648 = load i64, ptr %slot981, align 8
  %p5649 = inttoptr i64 %v5647 to ptr
  %p5650 = inttoptr i64 %v5648 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5650, ptr %p5649, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5651 = load i64, ptr %slot18, align 8
  %p5652 = inttoptr i64 %v5651 to ptr
  store i32 2, ptr %p5652, align 4, !alias.scope !3, !noalias !4
  %v5653 = load i64, ptr %slot24, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %ld5655 = load i32, ptr %p5654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5655, ptr %slot983, align 8
  %v5656 = load i32, ptr %slot983, align 8
  %v5657 = load i64, ptr %slot18, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  store i32 %v5656, ptr %p5658, align 4, !alias.scope !3, !noalias !4
  %v5659 = load i64, ptr %slot23, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  store i32 0, ptr %p5660, align 4, !alias.scope !3, !noalias !4
  %v5661 = load i64, ptr %slot17, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  store i32 1, ptr %p5662, align 4, !alias.scope !3, !noalias !4
  %v5663 = load i64, ptr %slot981, align 8
  %v5664 = load i64, ptr %slot52, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  store i64 %v5663, ptr %p5665, align 8, !alias.scope !3, !noalias !4
  %v5666 = load i64, ptr %slot57, align 8
  store i64 %v5666, ptr %slot984, align 8
  %v5667 = load i64, ptr %slot984, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  store i64 0, ptr %p5668, align 8, !alias.scope !3, !noalias !4
  %v5669 = load i64, ptr %slot984, align 8
  %p5671 = inttoptr i64 %v5669 to ptr
  %gep5672 = getelementptr i8, ptr %p5671, i64 8
  %op5670 = ptrtoint ptr %gep5672 to i64
  store i64 %op5670, ptr %slot985, align 8
  %v5673 = load i64, ptr %slot985, align 8
  %p5674 = inttoptr i64 %v5673 to ptr
  store i64 0, ptr %p5674, align 8, !alias.scope !3, !noalias !4
  %v5675 = load i64, ptr %slot984, align 8
  %p5677 = inttoptr i64 %v5675 to ptr
  %gep5678 = getelementptr i8, ptr %p5677, i64 16
  %op5676 = ptrtoint ptr %gep5678 to i64
  store i64 %op5676, ptr %slot986, align 8
  %v5679 = load i64, ptr %slot986, align 8
  %p5680 = inttoptr i64 %v5679 to ptr
  store i64 0, ptr %p5680, align 8, !alias.scope !3, !noalias !4
  %v5681 = load i64, ptr %slot984, align 8
  %p5683 = inttoptr i64 %v5681 to ptr
  %gep5684 = getelementptr i8, ptr %p5683, i64 24
  %op5682 = ptrtoint ptr %gep5684 to i64
  store i64 %op5682, ptr %slot987, align 8
  %v5685 = load i64, ptr %slot987, align 8
  %p5686 = inttoptr i64 %v5685 to ptr
  store i64 0, ptr %p5686, align 8, !alias.scope !3, !noalias !4
  %v5687 = load i64, ptr %slot984, align 8
  %p5689 = inttoptr i64 %v5687 to ptr
  %gep5690 = getelementptr i8, ptr %p5689, i64 32
  %op5688 = ptrtoint ptr %gep5690 to i64
  store i64 %op5688, ptr %slot988, align 8
  %v5691 = load i64, ptr %slot988, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  store i64 0, ptr %p5692, align 8, !alias.scope !3, !noalias !4
  %v5693 = load i64, ptr %slot984, align 8
  %p5695 = inttoptr i64 %v5693 to ptr
  %gep5696 = getelementptr i8, ptr %p5695, i64 40
  %op5694 = ptrtoint ptr %gep5696 to i64
  store i64 %op5694, ptr %slot989, align 8
  %v5697 = load i64, ptr %slot989, align 8
  %p5698 = inttoptr i64 %v5697 to ptr
  store i64 0, ptr %p5698, align 8, !alias.scope !3, !noalias !4
  %v5699 = load i64, ptr %slot984, align 8
  %p5701 = inttoptr i64 %v5699 to ptr
  %gep5702 = getelementptr i8, ptr %p5701, i64 48
  %op5700 = ptrtoint ptr %gep5702 to i64
  store i64 %op5700, ptr %slot990, align 8
  %v5703 = load i64, ptr %slot990, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  store i64 0, ptr %p5704, align 8, !alias.scope !3, !noalias !4
  %v5705 = load i64, ptr %slot984, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  store i32 2, ptr %p5706, align 4, !alias.scope !3, !noalias !4
  %v5707 = load i64, ptr %slot25, align 8
  %p5708 = inttoptr i64 %v5707 to ptr
  store i32 1, ptr %p5708, align 4, !alias.scope !3, !noalias !4
  %v5709 = load i64, ptr %slot52, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  %ld5711 = load i64, ptr %p5710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5711, ptr %slot991, align 8
  %v5712 = load i64, ptr %slot984, align 8
  %p5714 = inttoptr i64 %v5712 to ptr
  %gep5715 = getelementptr i8, ptr %p5714, i64 8
  %op5713 = ptrtoint ptr %gep5715 to i64
  store i64 %op5713, ptr %slot992, align 8
  %v5716 = load i64, ptr %slot65, align 8
  store i64 %v5716, ptr %slot993, align 8
  %v5717 = load i64, ptr %slot52, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  %ld5719 = load i64, ptr %p5718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5719, ptr %slot994, align 8
  %v5720 = load i64, ptr %slot30, align 8
  store i64 %v5720, ptr %slot995, align 8
  %v5721 = load i64, ptr %slot65, align 8
  store i64 %v5721, ptr %slot996, align 8
  %v5722 = load i64, ptr %slot994, align 8
  %op5723 = add i64 %v5722, 16
  store i64 %op5723, ptr %slot997, align 8
  %v5724 = load i64, ptr %slot997, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  %ld5726 = load i64, ptr %p5725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5726, ptr %slot998, align 8
  %v5727 = load i64, ptr %slot998, align 8
  %cmp5728 = icmp ne i64 %v5727, 0
  %cv5729 = zext i1 %cmp5728 to i32
  store i32 %cv5729, ptr %slot999, align 8
  %v5730 = load i32, ptr %slot999, align 8
  %cv5731 = zext i32 %v5730 to i64
  %cond5732 = icmp ne i64 %cv5731, 0
  br i1 %cond5732, label %bb_rcmoveheader1388, label %bb_rcmovenext1388
bb_rcmoveheader1388:
  %v5733 = load i64, ptr %slot998, align 8
  %op5734 = sub i64 %v5733, 16
  store i64 %op5734, ptr %slot1000, align 8
  %v5735 = load i64, ptr %slot998, align 8
  %p5736 = inttoptr i64 %v5735 to ptr
  %rgep5737 = getelementptr i8, ptr %p5736, i64 -16
  %ld5738 = load i64, ptr %rgep5737, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5738, ptr %slot1001, align 8
  %v5739 = load i64, ptr %slot1001, align 8
  %op5740 = and i64 %v5739, 5764607523034234881
  store i64 %op5740, ptr %slot1002, align 8
  %v5741 = load i64, ptr %slot1002, align 8
  %cmp5742 = icmp ne i64 %v5741, 0
  %cv5743 = zext i1 %cmp5742 to i32
  store i32 %cv5743, ptr %slot1003, align 8
  %v5744 = load i32, ptr %slot1003, align 8
  %cv5745 = zext i32 %v5744 to i64
  %cond5746 = icmp ne i64 %cv5745, 0
  br i1 %cond5746, label %bb_rcmoveslow1385, label %bb_rcmovenext1388
bb_rcmovenext1388:
  %v5747 = load i64, ptr %slot994, align 8
  %op5748 = add i64 %v5747, 24
  store i64 %op5748, ptr %slot1004, align 8
  %v5749 = load i64, ptr %slot1004, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  %ld5751 = load i64, ptr %p5750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5751, ptr %slot1005, align 8
  %v5752 = load i64, ptr %slot1005, align 8
  %cmp5753 = icmp ne i64 %v5752, 0
  %cv5754 = zext i1 %cmp5753 to i32
  store i32 %cv5754, ptr %slot1006, align 8
  %v5755 = load i32, ptr %slot1006, align 8
  %cv5756 = zext i32 %v5755 to i64
  %cond5757 = icmp ne i64 %cv5756, 0
  br i1 %cond5757, label %bb_rcmoveheader1396, label %bb_rcmovenext1396
bb_rcmoveheader1396:
  %v5758 = load i64, ptr %slot1005, align 8
  %op5759 = sub i64 %v5758, 16
  store i64 %op5759, ptr %slot1007, align 8
  %v5760 = load i64, ptr %slot1005, align 8
  %p5761 = inttoptr i64 %v5760 to ptr
  %rgep5762 = getelementptr i8, ptr %p5761, i64 -16
  %ld5763 = load i64, ptr %rgep5762, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5763, ptr %slot1008, align 8
  %v5764 = load i64, ptr %slot1008, align 8
  %op5765 = and i64 %v5764, 5764607523034234881
  store i64 %op5765, ptr %slot1009, align 8
  %v5766 = load i64, ptr %slot1009, align 8
  %cmp5767 = icmp ne i64 %v5766, 0
  %cv5768 = zext i1 %cmp5767 to i32
  store i32 %cv5768, ptr %slot1010, align 8
  %v5769 = load i32, ptr %slot1010, align 8
  %cv5770 = zext i32 %v5769 to i64
  %cond5771 = icmp ne i64 %cv5770, 0
  br i1 %cond5771, label %bb_rcmoveslow1385, label %bb_rcmovenext1396
bb_rcmovenext1396:
  %v5772 = load i64, ptr %slot994, align 8
  %op5773 = add i64 %v5772, 32
  store i64 %op5773, ptr %slot1011, align 8
  %v5774 = load i64, ptr %slot1011, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  %ld5776 = load i64, ptr %p5775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5776, ptr %slot1012, align 8
  %v5777 = load i64, ptr %slot1012, align 8
  %cmp5778 = icmp ne i64 %v5777, 0
  %cv5779 = zext i1 %cmp5778 to i32
  store i32 %cv5779, ptr %slot1013, align 8
  %v5780 = load i32, ptr %slot1013, align 8
  %cv5781 = zext i32 %v5780 to i64
  %cond5782 = icmp ne i64 %cv5781, 0
  br i1 %cond5782, label %bb_rcmoveheader1404, label %bb_rcmovenext1404
bb_rcmoveheader1404:
  %v5783 = load i64, ptr %slot1012, align 8
  %op5784 = sub i64 %v5783, 16
  store i64 %op5784, ptr %slot1014, align 8
  %v5785 = load i64, ptr %slot1012, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  %rgep5787 = getelementptr i8, ptr %p5786, i64 -16
  %ld5788 = load i64, ptr %rgep5787, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5788, ptr %slot1015, align 8
  %v5789 = load i64, ptr %slot1015, align 8
  %op5790 = and i64 %v5789, 5764607523034234881
  store i64 %op5790, ptr %slot1016, align 8
  %v5791 = load i64, ptr %slot1016, align 8
  %cmp5792 = icmp ne i64 %v5791, 0
  %cv5793 = zext i1 %cmp5792 to i32
  store i32 %cv5793, ptr %slot1017, align 8
  %v5794 = load i32, ptr %slot1017, align 8
  %cv5795 = zext i32 %v5794 to i64
  %cond5796 = icmp ne i64 %cv5795, 0
  br i1 %cond5796, label %bb_rcmoveslow1385, label %bb_rcmovenext1404
bb_rcmovenext1404:
  %v5797 = load i64, ptr %slot994, align 8
  %v5798 = load i64, ptr %slot995, align 8
  %p5799 = inttoptr i64 %v5797 to ptr
  %p5800 = inttoptr i64 %v5798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5800, ptr %p5799, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5801 = load i64, ptr %slot994, align 8
  %p5802 = inttoptr i64 %v5801 to ptr
  store i64 0, ptr %p5802, align 8, !alias.scope !3, !noalias !4
  %v5803 = load i64, ptr %slot994, align 8
  %op5804 = add i64 %v5803, 8
  store i64 %op5804, ptr %slot1018, align 8
  %v5805 = load i64, ptr %slot1018, align 8
  %p5806 = inttoptr i64 %v5805 to ptr
  store i64 0, ptr %p5806, align 8, !alias.scope !3, !noalias !4
  %v5807 = load i64, ptr %slot994, align 8
  %op5808 = add i64 %v5807, 16
  store i64 %op5808, ptr %slot1019, align 8
  %v5809 = load i64, ptr %slot1019, align 8
  %p5810 = inttoptr i64 %v5809 to ptr
  store i64 0, ptr %p5810, align 8, !alias.scope !3, !noalias !4
  %v5811 = load i64, ptr %slot994, align 8
  %op5812 = add i64 %v5811, 24
  store i64 %op5812, ptr %slot1020, align 8
  %v5813 = load i64, ptr %slot1020, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  store i64 0, ptr %p5814, align 8, !alias.scope !3, !noalias !4
  %v5815 = load i64, ptr %slot994, align 8
  %op5816 = add i64 %v5815, 32
  store i64 %op5816, ptr %slot1021, align 8
  %v5817 = load i64, ptr %slot1021, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i64 0, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot994, align 8
  %op5820 = add i64 %v5819, 40
  store i64 %op5820, ptr %slot1022, align 8
  %v5821 = load i64, ptr %slot1022, align 8
  %p5822 = inttoptr i64 %v5821 to ptr
  store i64 0, ptr %p5822, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1385
bb_rcmoveslow1385:
  %v5823 = load i64, ptr %slot64, align 8
  %v5824 = load i64, ptr %slot995, align 8
  %v5825 = load i64, ptr %slot994, align 8
  %v5826 = load i64, ptr %slot996, align 8
  %cv5827 = trunc i64 %v5826 to i32
  %call5828 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v5823, i64 %v5824, i64 %v5825, i32 %cv5827) nomerge, !dbg !178
  store i32 %call5828, ptr %slot1023, align 8
  %v5829 = load i32, ptr %slot1023, align 8
  %cv5830 = zext i32 %v5829 to i64
  %cond5831 = icmp ne i64 %cv5830, 0
  br i1 %cond5831, label %bb_rcsuccess1416, label %bb_rcfailure1416
bb_rcfailure1416:
  %v5832 = load i64, ptr %slot64, align 8
  %p5833 = inttoptr i64 %v5832 to ptr
  %call5834 = call i32 @myl_rc_take_failure(ptr %p5833) nomerge, !dbg !178
  store i32 %call5834, ptr %slot1024, align 8
  %v5835 = load i64, ptr %slot1, align 8
  %p5836 = inttoptr i64 %v5835 to ptr
  %v5837 = load i32, ptr %slot1024, align 8
  %call5838 = call i32 @myl_qbe_rc_status(ptr %p5836, i32 %v5837) nomerge, !dbg !178
  store i32 %call5838, ptr %slot1025, align 8
  br label %bb_failure
bb_rcsuccess1416:
  br label %bb_rcmoved1385
bb_rcmoved1385:
  %v5839 = load i64, ptr %slot17, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  store i32 0, ptr %p5840, align 4, !alias.scope !3, !noalias !4
  %v5841 = load i64, ptr %slot24, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i32 2, ptr %p5842, align 4, !alias.scope !3, !noalias !4
  %v5843 = load i64, ptr %slot23, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  store i32 1, ptr %p5844, align 4, !alias.scope !3, !noalias !4
  %v5845 = load i64, ptr %slot30, align 8
  store i64 %v5845, ptr %slot1026, align 8
  %v5846 = load i64, ptr %slot1026, align 8
  %v5847 = load i64, ptr %slot992, align 8
  %p5848 = inttoptr i64 %v5846 to ptr
  %p5849 = inttoptr i64 %v5847 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5849, ptr %p5848, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5850 = load i64, ptr %slot23, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  store i32 0, ptr %p5851, align 4, !alias.scope !3, !noalias !4
  %v5852 = load i64, ptr %slot984, align 8
  %v5853 = load i64, ptr %slot52, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  store i64 %v5852, ptr %p5854, align 8, !alias.scope !3, !noalias !4
  %v5855 = load i64, ptr %slot52, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %ld5857 = load i64, ptr %p5856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5857, ptr %slot1027, align 8
  %v5858 = load i64, ptr %slot26, align 8
  store i64 %v5858, ptr %slot1028, align 8
  %v5859 = load i64, ptr %slot1027, align 8
  %v5860 = load i64, ptr %slot1028, align 8
  %p5861 = inttoptr i64 %v5859 to ptr
  %p5862 = inttoptr i64 %v5860 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5862, ptr %p5861, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5863 = load i64, ptr %slot18, align 8
  %p5864 = inttoptr i64 %v5863 to ptr
  store i32 2, ptr %p5864, align 4, !alias.scope !3, !noalias !4
  %v5865 = load i64, ptr %slot17, align 8
  %p5866 = inttoptr i64 %v5865 to ptr
  store i32 1, ptr %p5866, align 4, !alias.scope !3, !noalias !4
  %v5867 = load i64, ptr %slot1028, align 8
  %v5868 = load i64, ptr %slot52, align 8
  %p5869 = inttoptr i64 %v5868 to ptr
  store i64 %v5867, ptr %p5869, align 8, !alias.scope !3, !noalias !4
  %v5870 = load i64, ptr %slot52, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %ld5872 = load i64, ptr %p5871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5872, ptr %slot1029, align 8
  %v5873 = load i64, ptr %slot17, align 8
  %p5874 = inttoptr i64 %v5873 to ptr
  %ld5875 = load i32, ptr %p5874, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5875, ptr %slot1030, align 8
  %v5876 = load i64, ptr %slot18, align 8
  %p5877 = inttoptr i64 %v5876 to ptr
  %ld5878 = load i32, ptr %p5877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5878, ptr %slot1031, align 8
  %v5879 = load i32, ptr %slot1031, align 8
  %op5880 = and i32 %v5879, 24
  store i32 %op5880, ptr %slot1031, align 8
  %v5881 = load i32, ptr %slot1031, align 8
  %cmp5882 = icmp eq i32 %v5881, 0
  %cv5883 = zext i1 %cmp5882 to i32
  store i32 %cv5883, ptr %slot1032, align 8
  %v5884 = load i32, ptr %slot1030, align 8
  %v5885 = load i32, ptr %slot1032, align 8
  %op5886 = and i32 %v5884, %v5885
  store i32 %op5886, ptr %slot1033, align 8
  %v5887 = load i32, ptr %slot1033, align 8
  %cv5888 = zext i32 %v5887 to i64
  %cond5889 = icmp ne i64 %cv5888, 0
  br i1 %cond5889, label %bb_rcprivateown1435, label %bb_rcprivateloan1435
bb_rcprivateown1435:
  %v5890 = load i64, ptr %slot30, align 8
  store i64 %v5890, ptr %slot1034, align 8
  %v5891 = load i64, ptr %slot65, align 8
  store i64 %v5891, ptr %slot1035, align 8
  %v5892 = load i64, ptr %slot64, align 8
  %v5893 = load i64, ptr %slot1034, align 8
  %v5894 = load i64, ptr %slot1029, align 8
  %v5895 = load i64, ptr %slot1035, align 8
  %cv5896 = trunc i64 %v5895 to i32
  %call5897 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v5892, i64 %v5893, i64 %v5894, i32 %cv5896) nomerge, !dbg !180
  store i32 %call5897, ptr %slot1036, align 8
  %v5898 = load i32, ptr %slot1036, align 8
  %cv5899 = zext i32 %v5898 to i64
  %cond5900 = icmp ne i64 %cv5899, 0
  br i1 %cond5900, label %bb_rcsuccess1439, label %bb_rcfailure1439
bb_rcfailure1439:
  %v5901 = load i64, ptr %slot64, align 8
  %p5902 = inttoptr i64 %v5901 to ptr
  %call5903 = call i32 @myl_rc_take_failure(ptr %p5902) nomerge, !dbg !180
  store i32 %call5903, ptr %slot1037, align 8
  %v5904 = load i64, ptr %slot1, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  %v5906 = load i32, ptr %slot1037, align 8
  %call5907 = call i32 @myl_qbe_rc_status(ptr %p5905, i32 %v5906) nomerge, !dbg !180
  store i32 %call5907, ptr %slot1038, align 8
  br label %bb_failure
bb_rcsuccess1439:
  %v5908 = load i64, ptr %slot17, align 8
  %p5909 = inttoptr i64 %v5908 to ptr
  store i32 0, ptr %p5909, align 4, !alias.scope !3, !noalias !4
  %v5910 = load i64, ptr %slot24, align 8
  %p5911 = inttoptr i64 %v5910 to ptr
  store i32 2, ptr %p5911, align 4, !alias.scope !3, !noalias !4
  %v5912 = load i64, ptr %slot23, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  store i32 1, ptr %p5913, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1435
bb_rcprivateloan1435:
  %v5914 = load i64, ptr %slot17, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  %ld5916 = load i32, ptr %p5915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5916, ptr %slot1039, align 8
  %v5917 = load i64, ptr %slot18, align 8
  %p5918 = inttoptr i64 %v5917 to ptr
  %ld5919 = load i32, ptr %p5918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5919, ptr %slot1040, align 8
  %v5920 = load i32, ptr %slot1040, align 8
  %cmp5921 = icmp eq i32 %v5920, 16
  %cv5922 = zext i1 %cmp5921 to i32
  store i32 %cv5922, ptr %slot1041, align 8
  %v5923 = load i32, ptr %slot1041, align 8
  %v5924 = load i32, ptr %slot1039, align 8
  %op5925 = and i32 %v5923, %v5924
  store i32 %op5925, ptr %slot1041, align 8
  %v5926 = load i32, ptr %slot1041, align 8
  %cv5927 = zext i32 %v5926 to i64
  %cond5928 = icmp ne i64 %cv5927, 0
  br i1 %cond5928, label %bb_rcprivatemove1435, label %bb_rcprivatenew1435
bb_rcprivatemove1435:
  %v5929 = load i64, ptr %slot30, align 8
  store i64 %v5929, ptr %slot1042, align 8
  %v5930 = load i64, ptr %slot1029, align 8
  %v5931 = load i64, ptr %slot1042, align 8
  %p5932 = inttoptr i64 %v5930 to ptr
  %p5933 = inttoptr i64 %v5931 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5933, ptr %p5932, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5934 = load i64, ptr %slot1029, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  call void @llvm.memset.p0.i64(ptr %p5935, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !180
  %v5936 = load i64, ptr %slot24, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  store i32 2, ptr %p5937, align 4, !alias.scope !3, !noalias !4
  %v5938 = load i64, ptr %slot24, align 8
  %p5939 = inttoptr i64 %v5938 to ptr
  store i32 16, ptr %p5939, align 4, !alias.scope !3, !noalias !4
  %v5940 = load i64, ptr %slot23, align 8
  %p5941 = inttoptr i64 %v5940 to ptr
  store i32 1, ptr %p5941, align 4, !alias.scope !3, !noalias !4
  %v5942 = load i64, ptr %slot17, align 8
  %p5943 = inttoptr i64 %v5942 to ptr
  store i32 0, ptr %p5943, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1435
bb_rcprivatenew1435:
  %v5944 = load i64, ptr %slot30, align 8
  store i64 %v5944, ptr %slot1043, align 8
  %v5945 = load i64, ptr %slot64, align 8
  %v5946 = load i64, ptr %slot1043, align 8
  %v5947 = load i64, ptr %slot1029, align 8
  %call5948 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v5945, i64 %v5946, i64 %v5947) nomerge, !dbg !180
  store i32 %call5948, ptr %slot1044, align 8
  %v5949 = load i32, ptr %slot1044, align 8
  %cv5950 = zext i32 %v5949 to i64
  %cond5951 = icmp ne i64 %cv5950, 0
  br i1 %cond5951, label %bb_rcsuccess1457, label %bb_rcfailure1457
bb_rcfailure1457:
  %v5952 = load i64, ptr %slot64, align 8
  %p5953 = inttoptr i64 %v5952 to ptr
  %call5954 = call i32 @myl_rc_take_failure(ptr %p5953) nomerge, !dbg !180
  store i32 %call5954, ptr %slot1045, align 8
  %v5955 = load i64, ptr %slot1, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  %v5957 = load i32, ptr %slot1045, align 8
  %call5958 = call i32 @myl_qbe_rc_status(ptr %p5956, i32 %v5957) nomerge, !dbg !180
  store i32 %call5958, ptr %slot1046, align 8
  br label %bb_failure
bb_rcsuccess1457:
  %v5959 = load i64, ptr %slot24, align 8
  %p5960 = inttoptr i64 %v5959 to ptr
  store i32 2, ptr %p5960, align 4, !alias.scope !3, !noalias !4
  %v5961 = load i64, ptr %slot24, align 8
  %p5962 = inttoptr i64 %v5961 to ptr
  store i32 16, ptr %p5962, align 4, !alias.scope !3, !noalias !4
  %v5963 = load i64, ptr %slot23, align 8
  %p5964 = inttoptr i64 %v5963 to ptr
  store i32 1, ptr %p5964, align 4, !alias.scope !3, !noalias !4
  %v5965 = load i64, ptr %slot17, align 8
  %p5966 = inttoptr i64 %v5965 to ptr
  %ld5967 = load i32, ptr %p5966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5967, ptr %slot1047, align 8
  %v5968 = load i32, ptr %slot1047, align 8
  %cv5969 = zext i32 %v5968 to i64
  %cond5970 = icmp ne i64 %cv5969, 0
  br i1 %cond5970, label %bb_rcslotdrop1465, label %bb_rcslotdone1465
bb_rcslotdrop1465:
  %v5971 = load i64, ptr %slot17, align 8
  %p5972 = inttoptr i64 %v5971 to ptr
  store i32 0, ptr %p5972, align 4, !alias.scope !3, !noalias !4
  %v5973 = load i64, ptr %slot26, align 8
  store i64 %v5973, ptr %slot1048, align 8
  %v5974 = load i64, ptr %slot18, align 8
  %p5975 = inttoptr i64 %v5974 to ptr
  %ld5976 = load i32, ptr %p5975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5976, ptr %slot1049, align 8
  %v5977 = load i32, ptr %slot1049, align 8
  %op5978 = and i32 %v5977, 28
  store i32 %op5978, ptr %slot1050, align 8
  %v5979 = load i32, ptr %slot1050, align 8
  %cv5980 = zext i32 %v5979 to i64
  %cond5981 = icmp ne i64 %cv5980, 0
  br i1 %cond5981, label %bb_rcslotrole1465, label %bb_rcslotowner1465
bb_rcslotrole1465:
  %v5982 = load i64, ptr %slot64, align 8
  store i64 %v5982, ptr %slot1051, align 8
  %v5983 = load i64, ptr %slot1051, align 8
  %v5984 = load i64, ptr %slot1048, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v5983, i64 %v5984) nomerge, !dbg !180
  br label %bb_rcslotdone1465
bb_rcslotowner1465:
  %v5985 = load i64, ptr %slot64, align 8
  store i64 %v5985, ptr %slot1052, align 8
  %v5986 = load i64, ptr %slot1052, align 8
  %v5987 = load i64, ptr %slot1048, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v5986, i64 %v5987) nomerge, !dbg !180
  br label %bb_rcslotdone1465
bb_rcslotdone1465:
  br label %bb_rcprivateprepared1435
bb_rcprivateprepared1435:
  %v5988 = load i64, ptr %slot15, align 8
  %p5989 = inttoptr i64 %v5988 to ptr
  %ld5990 = load i32, ptr %p5989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5990, ptr %slot1053, align 8
  %v5991 = load i32, ptr %slot1053, align 8
  %cv5992 = zext i32 %v5991 to i64
  %cond5993 = icmp ne i64 %cv5992, 0
  br i1 %cond5993, label %bb_rcslotdrop1475, label %bb_rcslotdone1475
bb_rcslotdrop1475:
  %v5994 = load i64, ptr %slot15, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  store i32 0, ptr %p5995, align 4, !alias.scope !3, !noalias !4
  %v5996 = load i64, ptr %slot50, align 8
  store i64 %v5996, ptr %slot1054, align 8
  %v5997 = load i64, ptr %slot16, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  %ld5999 = load i32, ptr %p5998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5999, ptr %slot1055, align 8
  %v6000 = load i32, ptr %slot1055, align 8
  %op6001 = and i32 %v6000, 28
  store i32 %op6001, ptr %slot1056, align 8
  %v6002 = load i32, ptr %slot1056, align 8
  %cv6003 = zext i32 %v6002 to i64
  %cond6004 = icmp ne i64 %cv6003, 0
  br i1 %cond6004, label %bb_rcslotrole1475, label %bb_rcslotowner1475
bb_rcslotrole1475:
  %v6005 = load i64, ptr %slot64, align 8
  store i64 %v6005, ptr %slot1057, align 8
  %v6006 = load i64, ptr %slot1057, align 8
  %v6007 = load i64, ptr %slot1054, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v6006, i64 %v6007) nomerge, !dbg !180
  br label %bb_rcslotdone1475
bb_rcslotowner1475:
  %v6008 = load i64, ptr %slot64, align 8
  store i64 %v6008, ptr %slot1058, align 8
  %v6009 = load i64, ptr %slot1058, align 8
  %v6010 = load i64, ptr %slot1054, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v6009, i64 %v6010) nomerge, !dbg !180
  br label %bb_rcslotdone1475
bb_rcslotdone1475:
  %v6011 = load i64, ptr %slot50, align 8
  store i64 %v6011, ptr %slot1059, align 8
  %v6012 = load i64, ptr %slot30, align 8
  store i64 %v6012, ptr %slot1060, align 8
  %v6013 = load i64, ptr %slot1060, align 8
  %v6014 = load i64, ptr %slot1059, align 8
  %p6015 = inttoptr i64 %v6013 to ptr
  %p6016 = inttoptr i64 %v6014 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6016, ptr %p6015, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v6017 = load i64, ptr %slot23, align 8
  %p6018 = inttoptr i64 %v6017 to ptr
  store i32 0, ptr %p6018, align 4, !alias.scope !3, !noalias !4
  %v6019 = load i64, ptr %slot16, align 8
  %p6020 = inttoptr i64 %v6019 to ptr
  store i32 2, ptr %p6020, align 4, !alias.scope !3, !noalias !4
  %v6021 = load i64, ptr %slot24, align 8
  %p6022 = inttoptr i64 %v6021 to ptr
  %ld6023 = load i32, ptr %p6022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6023, ptr %slot1061, align 8
  %v6024 = load i32, ptr %slot1061, align 8
  %v6025 = load i64, ptr %slot16, align 8
  %p6026 = inttoptr i64 %v6025 to ptr
  store i32 %v6024, ptr %p6026, align 4, !alias.scope !3, !noalias !4
  %v6027 = load i64, ptr %slot15, align 8
  %p6028 = inttoptr i64 %v6027 to ptr
  store i32 1, ptr %p6028, align 4, !alias.scope !3, !noalias !4
  %v6029 = load i64, ptr %slot36, align 8
  %p6030 = inttoptr i64 %v6029 to ptr
  %ld6031 = load i64, ptr %p6030, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6031, ptr %slot1062, align 8
  %v6032 = load i64, ptr %slot1062, align 8
  %v6033 = load i64, ptr %slot52, align 8
  %p6034 = inttoptr i64 %v6033 to ptr
  store i64 %v6032, ptr %p6034, align 8, !alias.scope !3, !noalias !4
  %v6035 = load i64, ptr %slot52, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  %ld6037 = load i64, ptr %p6036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6037, ptr %slot1063, align 8
  %v6038 = load i64, ptr %slot1063, align 8
  %op6039 = add i64 %v6038, 0
  store i64 %op6039, ptr %slot1064, align 8
  %v6040 = load i64, ptr %slot1064, align 8
  %v6041 = load i64, ptr %slot52, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  store i64 %v6040, ptr %p6042, align 8, !alias.scope !3, !noalias !4
  %v6043 = load i64, ptr %slot17, align 8
  %p6044 = inttoptr i64 %v6043 to ptr
  %ld6045 = load i32, ptr %p6044, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6045, ptr %slot1065, align 8
  %v6046 = load i32, ptr %slot1065, align 8
  %cv6047 = zext i32 %v6046 to i64
  %cond6048 = icmp ne i64 %cv6047, 0
  br i1 %cond6048, label %bb_rcslotdrop1494, label %bb_rcslotdone1494
bb_rcslotdrop1494:
  %v6049 = load i64, ptr %slot17, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  store i32 0, ptr %p6050, align 4, !alias.scope !3, !noalias !4
  %v6051 = load i64, ptr %slot26, align 8
  store i64 %v6051, ptr %slot1066, align 8
  %v6052 = load i64, ptr %slot18, align 8
  %p6053 = inttoptr i64 %v6052 to ptr
  %ld6054 = load i32, ptr %p6053, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6054, ptr %slot1067, align 8
  %v6055 = load i32, ptr %slot1067, align 8
  %op6056 = and i32 %v6055, 28
  store i32 %op6056, ptr %slot1068, align 8
  %v6057 = load i32, ptr %slot1068, align 8
  %cv6058 = zext i32 %v6057 to i64
  %cond6059 = icmp ne i64 %cv6058, 0
  br i1 %cond6059, label %bb_rcslotrole1494, label %bb_rcslotowner1494
bb_rcslotrole1494:
  %v6060 = load i64, ptr %slot64, align 8
  store i64 %v6060, ptr %slot1069, align 8
  %v6061 = load i64, ptr %slot1069, align 8
  %v6062 = load i64, ptr %slot1066, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6061, i64 %v6062) nomerge, !dbg !182
  br label %bb_rcslotdone1494
bb_rcslotowner1494:
  %v6063 = load i64, ptr %slot64, align 8
  store i64 %v6063, ptr %slot1070, align 8
  %v6064 = load i64, ptr %slot1070, align 8
  %v6065 = load i64, ptr %slot1066, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6064, i64 %v6065) nomerge, !dbg !182
  br label %bb_rcslotdone1494
bb_rcslotdone1494:
  %v6066 = load i64, ptr %slot52, align 8
  %p6067 = inttoptr i64 %v6066 to ptr
  %ld6068 = load i64, ptr %p6067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6068, ptr %slot1071, align 8
  %v6069 = load i64, ptr %slot1071, align 8
  %op6070 = add i64 %v6069, 0
  store i64 %op6070, ptr %slot1072, align 8
  %v6071 = load i64, ptr %slot1072, align 8
  %p6072 = inttoptr i64 %v6071 to ptr
  %ld6073 = load i64, ptr %p6072, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6073, ptr %slot1073, align 8
  %v6074 = load i64, ptr %slot1073, align 8
  %v6075 = load i64, ptr %slot52, align 8
  %p6076 = inttoptr i64 %v6075 to ptr
  store i64 %v6074, ptr %p6076, align 8, !alias.scope !3, !noalias !4
  %v6077 = load i64, ptr %slot52, align 8
  %p6078 = inttoptr i64 %v6077 to ptr
  %ld6079 = load i64, ptr %p6078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6079, ptr %slot1074, align 8
  %v6080 = load i64, ptr %slot1074, align 8
  %v6081 = load i64, ptr %slot29, align 8
  %p6082 = inttoptr i64 %v6081 to ptr
  store i64 %v6080, ptr %p6082, align 8, !alias.scope !3, !noalias !4
  %v6083 = load i64, ptr %slot29, align 8
  store i64 %v6083, ptr %slot1075, align 8
  %v6084 = load i64, ptr %slot30, align 8
  store i64 %v6084, ptr %slot1076, align 8
  %v6085 = load i64, ptr %slot1075, align 8
  %p6086 = inttoptr i64 %v6085 to ptr
  %ld6087 = load i64, ptr %p6086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6087, ptr %slot1077, align 8
  %v6088 = load i64, ptr %slot1077, align 8
  %cmp6089 = icmp ne i64 %v6088, 0
  %cv6090 = zext i1 %cmp6089 to i32
  store i32 %cv6090, ptr %slot1078, align 8
  %v6091 = load i32, ptr %slot1078, align 8
  %cv6092 = zext i32 %v6091 to i64
  %cond6093 = icmp ne i64 %cv6092, 0
  br i1 %cond6093, label %bb_rcgnn1508, label %bb_rcgstore1508
bb_rcgnn1508:
  %v6094 = load i64, ptr %slot1077, align 8
  %op6095 = sub i64 %v6094, 16
  store i64 %op6095, ptr %slot1079, align 8
  %v6096 = load i64, ptr %slot1077, align 8
  %p6097 = inttoptr i64 %v6096 to ptr
  %rgep6098 = getelementptr i8, ptr %p6097, i64 -16
  %ld6099 = load i64, ptr %rgep6098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6099, ptr %slot1080, align 8
  %v6100 = load i64, ptr %slot1080, align 8
  %op6101 = and i64 %v6100, 4611686018427387906
  store i64 %op6101, ptr %slot1081, align 8
  %v6102 = load i64, ptr %slot1081, align 8
  %cmp6103 = icmp ne i64 %v6102, 0
  %cv6104 = zext i1 %cmp6103 to i32
  store i32 %cv6104, ptr %slot1082, align 8
  %v6105 = load i32, ptr %slot1082, align 8
  %cv6106 = zext i32 %v6105 to i64
  %cond6107 = icmp ne i64 %cv6106, 0
  br i1 %cond6107, label %bb_rcgstore1508, label %bb_rcginc1508
bb_rcginc1508:
  %v6108 = load i64, ptr %slot1077, align 8
  %op6109 = sub i64 %v6108, 24
  store i64 %op6109, ptr %slot1083, align 8
  %v6110 = load i64, ptr %slot1077, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  %rgep6112 = getelementptr i8, ptr %p6111, i64 -24
  %ld6113 = load i64, ptr %rgep6112, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6113, ptr %slot1084, align 8
  %v6114 = load i64, ptr %slot1084, align 8
  %op6115 = add i64 %v6114, 1
  store i64 %op6115, ptr %slot1085, align 8
  %v6116 = load i64, ptr %slot1085, align 8
  %cmp6117 = icmp eq i64 %v6116, 0
  %cv6118 = zext i1 %cmp6117 to i32
  store i32 %cv6118, ptr %slot1086, align 8
  %v6119 = load i32, ptr %slot1086, align 8
  %cv6120 = zext i32 %v6119 to i64
  %cond6121 = icmp ne i64 %cv6120, 0
  br i1 %cond6121, label %bb_rcglimit1508, label %bb_rcgcapacity1508
bb_rcglimit1508:
  %v6122 = load i64, ptr %slot1, align 8
  %p6123 = inttoptr i64 %v6122 to ptr
  %call6124 = call i32 @myl_qbe_rc_status(ptr %p6123, i32 2) nomerge, !dbg !184
  store i32 %call6124, ptr %slot1087, align 8
  br label %bb_failure
bb_rcgcapacity1508:
  %v6125 = load i64, ptr %slot1085, align 8
  %v6126 = load i64, ptr %slot1077, align 8
  %p6127 = inttoptr i64 %v6126 to ptr
  %rgep6128 = getelementptr i8, ptr %p6127, i64 -24
  store i64 %v6125, ptr %rgep6128, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1508
bb_rcgstore1508:
  %v6129 = load i64, ptr %slot1077, align 8
  %v6130 = load i64, ptr %slot1076, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  store i64 %v6129, ptr %p6131, align 8, !alias.scope !3, !noalias !4
  %v6132 = load i64, ptr %slot24, align 8
  %p6133 = inttoptr i64 %v6132 to ptr
  store i32 2, ptr %p6133, align 4, !alias.scope !3, !noalias !4
  %v6134 = load i64, ptr %slot24, align 8
  %p6135 = inttoptr i64 %v6134 to ptr
  store i32 16, ptr %p6135, align 4, !alias.scope !3, !noalias !4
  %v6136 = load i64, ptr %slot23, align 8
  %p6137 = inttoptr i64 %v6136 to ptr
  store i32 1, ptr %p6137, align 4, !alias.scope !3, !noalias !4
  %v6138 = load i64, ptr %slot17, align 8
  %p6139 = inttoptr i64 %v6138 to ptr
  %ld6140 = load i32, ptr %p6139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6140, ptr %slot1088, align 8
  %v6141 = load i32, ptr %slot1088, align 8
  %cv6142 = zext i32 %v6141 to i64
  %cond6143 = icmp ne i64 %cv6142, 0
  br i1 %cond6143, label %bb_rcslotdrop1524, label %bb_rcslotdone1524
bb_rcslotdrop1524:
  %v6144 = load i64, ptr %slot17, align 8
  %p6145 = inttoptr i64 %v6144 to ptr
  store i32 0, ptr %p6145, align 4, !alias.scope !3, !noalias !4
  %v6146 = load i64, ptr %slot26, align 8
  store i64 %v6146, ptr %slot1089, align 8
  %v6147 = load i64, ptr %slot18, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  %ld6149 = load i32, ptr %p6148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6149, ptr %slot1090, align 8
  %v6150 = load i32, ptr %slot1090, align 8
  %op6151 = and i32 %v6150, 28
  store i32 %op6151, ptr %slot1091, align 8
  %v6152 = load i32, ptr %slot1091, align 8
  %cv6153 = zext i32 %v6152 to i64
  %cond6154 = icmp ne i64 %cv6153, 0
  br i1 %cond6154, label %bb_rcslotrole1524, label %bb_rcslotowner1524
bb_rcslotrole1524:
  %v6155 = load i64, ptr %slot64, align 8
  store i64 %v6155, ptr %slot1092, align 8
  %v6156 = load i64, ptr %slot1092, align 8
  %v6157 = load i64, ptr %slot1089, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6156, i64 %v6157) nomerge, !dbg !184
  br label %bb_rcslotdone1524
bb_rcslotowner1524:
  %v6158 = load i64, ptr %slot64, align 8
  store i64 %v6158, ptr %slot1093, align 8
  %v6159 = load i64, ptr %slot1093, align 8
  %v6160 = load i64, ptr %slot1089, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6159, i64 %v6160) nomerge, !dbg !184
  br label %bb_rcslotdone1524
bb_rcslotdone1524:
  %v6161 = load i64, ptr %slot26, align 8
  store i64 %v6161, ptr %slot1094, align 8
  %v6162 = load i64, ptr %slot30, align 8
  store i64 %v6162, ptr %slot1095, align 8
  %v6163 = load i64, ptr %slot1095, align 8
  %v6164 = load i64, ptr %slot1094, align 8
  %p6165 = inttoptr i64 %v6163 to ptr
  %p6166 = inttoptr i64 %v6164 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6166, ptr %p6165, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6167 = load i64, ptr %slot18, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  store i32 2, ptr %p6168, align 4, !alias.scope !3, !noalias !4
  %v6169 = load i64, ptr %slot24, align 8
  %p6170 = inttoptr i64 %v6169 to ptr
  %ld6171 = load i32, ptr %p6170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6171, ptr %slot1096, align 8
  %v6172 = load i32, ptr %slot1096, align 8
  %v6173 = load i64, ptr %slot18, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  store i32 %v6172, ptr %p6174, align 4, !alias.scope !3, !noalias !4
  %v6175 = load i64, ptr %slot23, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  store i32 0, ptr %p6176, align 4, !alias.scope !3, !noalias !4
  %v6177 = load i64, ptr %slot17, align 8
  %p6178 = inttoptr i64 %v6177 to ptr
  store i32 1, ptr %p6178, align 4, !alias.scope !3, !noalias !4
  %v6179 = load i64, ptr %slot1094, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  %ld6181 = load i64, ptr %p6180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6181, ptr %slot1097, align 8
  %v6182 = load i64, ptr %slot1097, align 8
  %v6183 = load i64, ptr %slot52, align 8
  %p6184 = inttoptr i64 %v6183 to ptr
  store i64 %v6182, ptr %p6184, align 8, !alias.scope !3, !noalias !4
  %v6185 = load i64, ptr %slot52, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  %ld6187 = load i64, ptr %p6186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6187, ptr %slot1098, align 8
  %v6188 = load i64, ptr %slot36, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %ld6190 = load i64, ptr %p6189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6190, ptr %slot1099, align 8
  %v6191 = load i64, ptr %slot17, align 8
  %p6192 = inttoptr i64 %v6191 to ptr
  %ld6193 = load i32, ptr %p6192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6193, ptr %slot1100, align 8
  %v6194 = load i32, ptr %slot1100, align 8
  %cv6195 = zext i32 %v6194 to i64
  %cond6196 = icmp ne i64 %cv6195, 0
  br i1 %cond6196, label %bb_rcslotdrop1545, label %bb_rcslotdone1545
bb_rcslotdrop1545:
  %v6197 = load i64, ptr %slot17, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  store i32 0, ptr %p6198, align 4, !alias.scope !3, !noalias !4
  %v6199 = load i64, ptr %slot26, align 8
  store i64 %v6199, ptr %slot1101, align 8
  %v6200 = load i64, ptr %slot18, align 8
  %p6201 = inttoptr i64 %v6200 to ptr
  %ld6202 = load i32, ptr %p6201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6202, ptr %slot1102, align 8
  %v6203 = load i32, ptr %slot1102, align 8
  %op6204 = and i32 %v6203, 28
  store i32 %op6204, ptr %slot1103, align 8
  %v6205 = load i32, ptr %slot1103, align 8
  %cv6206 = zext i32 %v6205 to i64
  %cond6207 = icmp ne i64 %cv6206, 0
  br i1 %cond6207, label %bb_rcslotrole1545, label %bb_rcslotowner1545
bb_rcslotrole1545:
  %v6208 = load i64, ptr %slot64, align 8
  store i64 %v6208, ptr %slot1104, align 8
  %v6209 = load i64, ptr %slot1101, align 8
  %p6210 = inttoptr i64 %v6209 to ptr
  %ld6211 = load i64, ptr %p6210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6211, ptr %slot1105, align 8
  %v6212 = load i64, ptr %slot1105, align 8
  %cmp6213 = icmp ne i64 %v6212, 0
  %cv6214 = zext i1 %cmp6213 to i32
  store i32 %cv6214, ptr %slot1106, align 8
  %v6215 = load i32, ptr %slot1106, align 8
  %cv6216 = zext i32 %v6215 to i64
  %cond6217 = icmp ne i64 %cv6216, 0
  br i1 %cond6217, label %bb_rcgnn1561, label %bb_rcgdone1561
bb_rcgnn1561:
  %v6218 = load i64, ptr %slot1105, align 8
  %op6219 = sub i64 %v6218, 16
  store i64 %op6219, ptr %slot1107, align 8
  %v6220 = load i64, ptr %slot1105, align 8
  %p6221 = inttoptr i64 %v6220 to ptr
  %rgep6222 = getelementptr i8, ptr %p6221, i64 -16
  %ld6223 = load i64, ptr %rgep6222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6223, ptr %slot1108, align 8
  %v6224 = load i64, ptr %slot1108, align 8
  %op6225 = and i64 %v6224, 4611686018427387906
  store i64 %op6225, ptr %slot1109, align 8
  %v6226 = load i64, ptr %slot1109, align 8
  %cmp6227 = icmp ne i64 %v6226, 0
  %cv6228 = zext i1 %cmp6227 to i32
  store i32 %cv6228, ptr %slot1110, align 8
  %v6229 = load i32, ptr %slot1110, align 8
  %cv6230 = zext i32 %v6229 to i64
  %cond6231 = icmp ne i64 %cv6230, 0
  br i1 %cond6231, label %bb_rcgclear1561, label %bb_rcgcounted1561
bb_rcgcounted1561:
  %v6232 = load i64, ptr %slot1105, align 8
  %op6233 = sub i64 %v6232, 24
  store i64 %op6233, ptr %slot1111, align 8
  %v6234 = load i64, ptr %slot1105, align 8
  %p6235 = inttoptr i64 %v6234 to ptr
  %rgep6236 = getelementptr i8, ptr %p6235, i64 -24
  %ld6237 = load i64, ptr %rgep6236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6237, ptr %slot1112, align 8
  %v6238 = load i64, ptr %slot1112, align 8
  %op6239 = sub i64 %v6238, 1
  store i64 %op6239, ptr %slot1113, align 8
  %v6240 = load i64, ptr %slot1113, align 8
  %cmp6241 = icmp eq i64 %v6240, 0
  %cv6242 = zext i1 %cmp6241 to i32
  store i32 %cv6242, ptr %slot1114, align 8
  %v6243 = load i32, ptr %slot1114, align 8
  %cv6244 = zext i32 %v6243 to i64
  %cond6245 = icmp ne i64 %cv6244, 0
  br i1 %cond6245, label %bb_rcglast1561, label %bb_rcgdec1561
bb_rcglast1561:
  %v6246 = load i64, ptr %slot1105, align 8
  %op6247 = sub i64 %v6246, 32
  store i64 %op6247, ptr %slot1115, align 8
  %v6248 = load i64, ptr %slot1105, align 8
  %p6249 = inttoptr i64 %v6248 to ptr
  %rgep6250 = getelementptr i8, ptr %p6249, i64 -32
  %ld6251 = load i64, ptr %rgep6250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6251, ptr %slot1116, align 8
  %v6252 = load i64, ptr %slot1116, align 8
  %cmp6253 = icmp ne i64 %v6252, 0
  %cv6254 = zext i1 %cmp6253 to i32
  store i32 %cv6254, ptr %slot1117, align 8
  %v6255 = load i32, ptr %slot1117, align 8
  %cv6256 = zext i32 %v6255 to i64
  %cond6257 = icmp ne i64 %cv6256, 0
  br i1 %cond6257, label %bb_rcgdec1561, label %bb_rcgslow1561
bb_rcgslow1561:
  %v6258 = load i64, ptr %slot1104, align 8
  %v6259 = load i64, ptr %slot1101, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v6258, i64 %v6259) nomerge, !dbg !186
  br label %bb_rcgdone1561
bb_rcgdec1561:
  %v6260 = load i64, ptr %slot1113, align 8
  %v6261 = load i64, ptr %slot1105, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  %rgep6263 = getelementptr i8, ptr %p6262, i64 -24
  store i64 %v6260, ptr %rgep6263, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1561
bb_rcgclear1561:
  %v6264 = load i64, ptr %slot1101, align 8
  %p6265 = inttoptr i64 %v6264 to ptr
  store i64 0, ptr %p6265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1561
bb_rcgdone1561:
  br label %bb_rcslotdone1545
bb_rcslotowner1545:
  %v6266 = load i64, ptr %slot64, align 8
  store i64 %v6266, ptr %slot1118, align 8
  %v6267 = load i64, ptr %slot1101, align 8
  %p6268 = inttoptr i64 %v6267 to ptr
  %ld6269 = load i64, ptr %p6268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6269, ptr %slot1119, align 8
  %v6270 = load i64, ptr %slot1119, align 8
  %cmp6271 = icmp ne i64 %v6270, 0
  %cv6272 = zext i1 %cmp6271 to i32
  store i32 %cv6272, ptr %slot1120, align 8
  %v6273 = load i32, ptr %slot1120, align 8
  %cv6274 = zext i32 %v6273 to i64
  %cond6275 = icmp ne i64 %cv6274, 0
  br i1 %cond6275, label %bb_rcgnn1576, label %bb_rcgdone1576
bb_rcgnn1576:
  %v6276 = load i64, ptr %slot1119, align 8
  %op6277 = sub i64 %v6276, 16
  store i64 %op6277, ptr %slot1121, align 8
  %v6278 = load i64, ptr %slot1119, align 8
  %p6279 = inttoptr i64 %v6278 to ptr
  %rgep6280 = getelementptr i8, ptr %p6279, i64 -16
  %ld6281 = load i64, ptr %rgep6280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6281, ptr %slot1122, align 8
  %v6282 = load i64, ptr %slot1122, align 8
  %op6283 = and i64 %v6282, 4611686018427387906
  store i64 %op6283, ptr %slot1123, align 8
  %v6284 = load i64, ptr %slot1123, align 8
  %cmp6285 = icmp ne i64 %v6284, 0
  %cv6286 = zext i1 %cmp6285 to i32
  store i32 %cv6286, ptr %slot1124, align 8
  %v6287 = load i32, ptr %slot1124, align 8
  %cv6288 = zext i32 %v6287 to i64
  %cond6289 = icmp ne i64 %cv6288, 0
  br i1 %cond6289, label %bb_rcgclear1576, label %bb_rcgcounted1576
bb_rcgcounted1576:
  %v6290 = load i64, ptr %slot1119, align 8
  %op6291 = sub i64 %v6290, 32
  store i64 %op6291, ptr %slot1125, align 8
  %v6292 = load i64, ptr %slot1119, align 8
  %p6293 = inttoptr i64 %v6292 to ptr
  %rgep6294 = getelementptr i8, ptr %p6293, i64 -32
  %ld6295 = load i64, ptr %rgep6294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6295, ptr %slot1126, align 8
  %v6296 = load i64, ptr %slot1126, align 8
  %op6297 = sub i64 %v6296, 1
  store i64 %op6297, ptr %slot1127, align 8
  %v6298 = load i64, ptr %slot1127, align 8
  %cmp6299 = icmp eq i64 %v6298, 0
  %cv6300 = zext i1 %cmp6299 to i32
  store i32 %cv6300, ptr %slot1128, align 8
  %v6301 = load i32, ptr %slot1128, align 8
  %cv6302 = zext i32 %v6301 to i64
  %cond6303 = icmp ne i64 %cv6302, 0
  br i1 %cond6303, label %bb_rcglast1576, label %bb_rcgdec1576
bb_rcglast1576:
  %v6304 = load i64, ptr %slot1119, align 8
  %op6305 = sub i64 %v6304, 24
  store i64 %op6305, ptr %slot1129, align 8
  %v6306 = load i64, ptr %slot1119, align 8
  %p6307 = inttoptr i64 %v6306 to ptr
  %rgep6308 = getelementptr i8, ptr %p6307, i64 -24
  %ld6309 = load i64, ptr %rgep6308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6309, ptr %slot1130, align 8
  %v6310 = load i64, ptr %slot1130, align 8
  %cmp6311 = icmp ne i64 %v6310, 0
  %cv6312 = zext i1 %cmp6311 to i32
  store i32 %cv6312, ptr %slot1131, align 8
  %v6313 = load i32, ptr %slot1131, align 8
  %cv6314 = zext i32 %v6313 to i64
  %cond6315 = icmp ne i64 %cv6314, 0
  br i1 %cond6315, label %bb_rcgdec1576, label %bb_rcgslow1576
bb_rcgslow1576:
  %v6316 = load i64, ptr %slot1118, align 8
  %v6317 = load i64, ptr %slot1101, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6316, i64 %v6317) nomerge, !dbg !186
  br label %bb_rcgdone1576
bb_rcgdec1576:
  %v6318 = load i64, ptr %slot1127, align 8
  %v6319 = load i64, ptr %slot1119, align 8
  %p6320 = inttoptr i64 %v6319 to ptr
  %rgep6321 = getelementptr i8, ptr %p6320, i64 -32
  store i64 %v6318, ptr %rgep6321, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1576
bb_rcgclear1576:
  %v6322 = load i64, ptr %slot1101, align 8
  %p6323 = inttoptr i64 %v6322 to ptr
  store i64 0, ptr %p6323, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1576
bb_rcgdone1576:
  br label %bb_rcslotdone1545
bb_rcslotdone1545:
  %v6324 = load i64, ptr %slot1099, align 8
  %op6325 = add i64 %v6324, 0
  store i64 %op6325, ptr %slot1132, align 8
  %v6326 = load i64, ptr %slot1132, align 8
  %op6327 = add i64 %v6326, 0
  store i64 %op6327, ptr %slot1133, align 8
  store i64 0, ptr %slot1134, align 8
  %v6328 = load i64, ptr %slot1133, align 8
  %p6329 = inttoptr i64 %v6328 to ptr
  %ld6330 = load i64, ptr %p6329, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6330, ptr %slot1135, align 8
  %v6331 = load i64, ptr %slot1135, align 8
  %cmp6332 = icmp ne i64 %v6331, 0
  %cv6333 = zext i1 %cmp6332 to i32
  store i32 %cv6333, ptr %slot1136, align 8
  %v6334 = load i32, ptr %slot1136, align 8
  %cv6335 = zext i32 %v6334 to i64
  %cond6336 = icmp ne i64 %cv6335, 0
  br i1 %cond6336, label %bb_rcguniquenn1583, label %bb_rcgunique1583
bb_rcguniquenn1583:
  %v6337 = load i64, ptr %slot1135, align 8
  %op6338 = sub i64 %v6337, 16
  store i64 %op6338, ptr %slot1137, align 8
  %v6339 = load i64, ptr %slot1135, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %rgep6341 = getelementptr i8, ptr %p6340, i64 -16
  %ld6342 = load i64, ptr %rgep6341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6342, ptr %slot1138, align 8
  %v6343 = load i64, ptr %slot1138, align 8
  %op6344 = and i64 %v6343, 6917529027641081858
  store i64 %op6344, ptr %slot1139, align 8
  %v6345 = load i64, ptr %slot1139, align 8
  %cmp6346 = icmp ne i64 %v6345, 0
  %cv6347 = zext i1 %cmp6346 to i32
  store i32 %cv6347, ptr %slot1140, align 8
  %v6348 = load i32, ptr %slot1140, align 8
  %cv6349 = zext i32 %v6348 to i64
  %cond6350 = icmp ne i64 %cv6349, 0
  br i1 %cond6350, label %bb_rcguniqueslow1583, label %bb_rcguniquecount1583
bb_rcguniquecount1583:
  %v6351 = load i64, ptr %slot1135, align 8
  %op6352 = sub i64 %v6351, 32
  store i64 %op6352, ptr %slot1141, align 8
  %v6353 = load i64, ptr %slot1135, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  %rgep6355 = getelementptr i8, ptr %p6354, i64 -32
  %ld6356 = load i64, ptr %rgep6355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6356, ptr %slot1142, align 8
  %v6357 = load i64, ptr %slot1142, align 8
  %cmp6358 = icmp ult i64 %v6357, 2
  %cv6359 = zext i1 %cmp6358 to i32
  store i32 %cv6359, ptr %slot1143, align 8
  %v6360 = load i32, ptr %slot1143, align 8
  %cv6361 = zext i32 %v6360 to i64
  %cond6362 = icmp ne i64 %cv6361, 0
  br i1 %cond6362, label %bb_rcgunique1583, label %bb_rcguniqueslow1583
bb_rcguniqueslow1583:
  %v6363 = load i64, ptr %slot1, align 8
  %p6364 = inttoptr i64 %v6363 to ptr
  %p6365 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v6366 = load i64, ptr %slot1133, align 8
  %p6367 = inttoptr i64 %v6366 to ptr
  %v6368 = load i64, ptr %slot1134, align 8
  %p6369 = inttoptr i64 %v6368 to ptr
  %call6370 = call i32 @myl_qbe_rc_unique_field(ptr %p6364, ptr %p6365, ptr %p6367, ptr %p6369) nomerge, !dbg !186
  store i32 %call6370, ptr %slot1144, align 8
  %v6371 = load i32, ptr %slot1144, align 8
  %cv6372 = zext i32 %v6371 to i64
  %cond6373 = icmp ne i64 %cv6372, 0
  br i1 %cond6373, label %bb_rcunique1593, label %bb_failure
bb_rcunique1593:
  br label %bb_rcgunique1583
bb_rcgunique1583:
  %v6374 = load i64, ptr %slot1133, align 8
  %p6375 = inttoptr i64 %v6374 to ptr
  %ld6376 = load i64, ptr %p6375, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6376, ptr %slot1145, align 8
  %v6377 = load i64, ptr %slot1145, align 8
  %v6378 = load i64, ptr %slot52, align 8
  %p6379 = inttoptr i64 %v6378 to ptr
  store i64 %v6377, ptr %p6379, align 8, !alias.scope !3, !noalias !4
  %v6380 = load i64, ptr %slot52, align 8
  %p6381 = inttoptr i64 %v6380 to ptr
  %ld6382 = load i64, ptr %p6381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6382, ptr %slot1146, align 8
  %v6383 = load i64, ptr %slot17, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  %ld6385 = load i32, ptr %p6384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6385, ptr %slot1147, align 8
  %v6386 = load i32, ptr %slot1147, align 8
  %cv6387 = zext i32 %v6386 to i64
  %cond6388 = icmp ne i64 %cv6387, 0
  br i1 %cond6388, label %bb_rcslotdrop1598, label %bb_rcslotdone1598
bb_rcslotdrop1598:
  %v6389 = load i64, ptr %slot17, align 8
  %p6390 = inttoptr i64 %v6389 to ptr
  store i32 0, ptr %p6390, align 4, !alias.scope !3, !noalias !4
  %v6391 = load i64, ptr %slot26, align 8
  store i64 %v6391, ptr %slot1148, align 8
  %v6392 = load i64, ptr %slot18, align 8
  %p6393 = inttoptr i64 %v6392 to ptr
  %ld6394 = load i32, ptr %p6393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6394, ptr %slot1149, align 8
  %v6395 = load i32, ptr %slot1149, align 8
  %op6396 = and i32 %v6395, 28
  store i32 %op6396, ptr %slot1150, align 8
  %v6397 = load i32, ptr %slot1150, align 8
  %cv6398 = zext i32 %v6397 to i64
  %cond6399 = icmp ne i64 %cv6398, 0
  br i1 %cond6399, label %bb_rcslotrole1598, label %bb_rcslotowner1598
bb_rcslotrole1598:
  %v6400 = load i64, ptr %slot64, align 8
  store i64 %v6400, ptr %slot1151, align 8
  %v6401 = load i64, ptr %slot1148, align 8
  %p6402 = inttoptr i64 %v6401 to ptr
  %ld6403 = load i64, ptr %p6402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6403, ptr %slot1152, align 8
  %v6404 = load i64, ptr %slot1152, align 8
  %cmp6405 = icmp ne i64 %v6404, 0
  %cv6406 = zext i1 %cmp6405 to i32
  store i32 %cv6406, ptr %slot1153, align 8
  %v6407 = load i32, ptr %slot1153, align 8
  %cv6408 = zext i32 %v6407 to i64
  %cond6409 = icmp ne i64 %cv6408, 0
  br i1 %cond6409, label %bb_rcgnn1614, label %bb_rcgdone1614
bb_rcgnn1614:
  %v6410 = load i64, ptr %slot1152, align 8
  %op6411 = sub i64 %v6410, 16
  store i64 %op6411, ptr %slot1154, align 8
  %v6412 = load i64, ptr %slot1152, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  %rgep6414 = getelementptr i8, ptr %p6413, i64 -16
  %ld6415 = load i64, ptr %rgep6414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6415, ptr %slot1155, align 8
  %v6416 = load i64, ptr %slot1155, align 8
  %op6417 = and i64 %v6416, 4611686018427387906
  store i64 %op6417, ptr %slot1156, align 8
  %v6418 = load i64, ptr %slot1156, align 8
  %cmp6419 = icmp ne i64 %v6418, 0
  %cv6420 = zext i1 %cmp6419 to i32
  store i32 %cv6420, ptr %slot1157, align 8
  %v6421 = load i32, ptr %slot1157, align 8
  %cv6422 = zext i32 %v6421 to i64
  %cond6423 = icmp ne i64 %cv6422, 0
  br i1 %cond6423, label %bb_rcgclear1614, label %bb_rcgcounted1614
bb_rcgcounted1614:
  %v6424 = load i64, ptr %slot1152, align 8
  %op6425 = sub i64 %v6424, 24
  store i64 %op6425, ptr %slot1158, align 8
  %v6426 = load i64, ptr %slot1152, align 8
  %p6427 = inttoptr i64 %v6426 to ptr
  %rgep6428 = getelementptr i8, ptr %p6427, i64 -24
  %ld6429 = load i64, ptr %rgep6428, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6429, ptr %slot1159, align 8
  %v6430 = load i64, ptr %slot1159, align 8
  %op6431 = sub i64 %v6430, 1
  store i64 %op6431, ptr %slot1160, align 8
  %v6432 = load i64, ptr %slot1160, align 8
  %cmp6433 = icmp eq i64 %v6432, 0
  %cv6434 = zext i1 %cmp6433 to i32
  store i32 %cv6434, ptr %slot1161, align 8
  %v6435 = load i32, ptr %slot1161, align 8
  %cv6436 = zext i32 %v6435 to i64
  %cond6437 = icmp ne i64 %cv6436, 0
  br i1 %cond6437, label %bb_rcglast1614, label %bb_rcgdec1614
bb_rcglast1614:
  %v6438 = load i64, ptr %slot1152, align 8
  %op6439 = sub i64 %v6438, 32
  store i64 %op6439, ptr %slot1162, align 8
  %v6440 = load i64, ptr %slot1152, align 8
  %p6441 = inttoptr i64 %v6440 to ptr
  %rgep6442 = getelementptr i8, ptr %p6441, i64 -32
  %ld6443 = load i64, ptr %rgep6442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6443, ptr %slot1163, align 8
  %v6444 = load i64, ptr %slot1163, align 8
  %cmp6445 = icmp ne i64 %v6444, 0
  %cv6446 = zext i1 %cmp6445 to i32
  store i32 %cv6446, ptr %slot1164, align 8
  %v6447 = load i32, ptr %slot1164, align 8
  %cv6448 = zext i32 %v6447 to i64
  %cond6449 = icmp ne i64 %cv6448, 0
  br i1 %cond6449, label %bb_rcgdec1614, label %bb_rcgslow1614
bb_rcgslow1614:
  %v6450 = load i64, ptr %slot1151, align 8
  %v6451 = load i64, ptr %slot1148, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v6450, i64 %v6451) nomerge, !dbg !186
  br label %bb_rcgdone1614
bb_rcgdec1614:
  %v6452 = load i64, ptr %slot1160, align 8
  %v6453 = load i64, ptr %slot1152, align 8
  %p6454 = inttoptr i64 %v6453 to ptr
  %rgep6455 = getelementptr i8, ptr %p6454, i64 -24
  store i64 %v6452, ptr %rgep6455, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1614
bb_rcgclear1614:
  %v6456 = load i64, ptr %slot1148, align 8
  %p6457 = inttoptr i64 %v6456 to ptr
  store i64 0, ptr %p6457, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1614
bb_rcgdone1614:
  br label %bb_rcslotdone1598
bb_rcslotowner1598:
  %v6458 = load i64, ptr %slot64, align 8
  store i64 %v6458, ptr %slot1165, align 8
  %v6459 = load i64, ptr %slot1148, align 8
  %p6460 = inttoptr i64 %v6459 to ptr
  %ld6461 = load i64, ptr %p6460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6461, ptr %slot1166, align 8
  %v6462 = load i64, ptr %slot1166, align 8
  %cmp6463 = icmp ne i64 %v6462, 0
  %cv6464 = zext i1 %cmp6463 to i32
  store i32 %cv6464, ptr %slot1167, align 8
  %v6465 = load i32, ptr %slot1167, align 8
  %cv6466 = zext i32 %v6465 to i64
  %cond6467 = icmp ne i64 %cv6466, 0
  br i1 %cond6467, label %bb_rcgnn1629, label %bb_rcgdone1629
bb_rcgnn1629:
  %v6468 = load i64, ptr %slot1166, align 8
  %op6469 = sub i64 %v6468, 16
  store i64 %op6469, ptr %slot1168, align 8
  %v6470 = load i64, ptr %slot1166, align 8
  %p6471 = inttoptr i64 %v6470 to ptr
  %rgep6472 = getelementptr i8, ptr %p6471, i64 -16
  %ld6473 = load i64, ptr %rgep6472, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6473, ptr %slot1169, align 8
  %v6474 = load i64, ptr %slot1169, align 8
  %op6475 = and i64 %v6474, 4611686018427387906
  store i64 %op6475, ptr %slot1170, align 8
  %v6476 = load i64, ptr %slot1170, align 8
  %cmp6477 = icmp ne i64 %v6476, 0
  %cv6478 = zext i1 %cmp6477 to i32
  store i32 %cv6478, ptr %slot1171, align 8
  %v6479 = load i32, ptr %slot1171, align 8
  %cv6480 = zext i32 %v6479 to i64
  %cond6481 = icmp ne i64 %cv6480, 0
  br i1 %cond6481, label %bb_rcgclear1629, label %bb_rcgcounted1629
bb_rcgcounted1629:
  %v6482 = load i64, ptr %slot1166, align 8
  %op6483 = sub i64 %v6482, 32
  store i64 %op6483, ptr %slot1172, align 8
  %v6484 = load i64, ptr %slot1166, align 8
  %p6485 = inttoptr i64 %v6484 to ptr
  %rgep6486 = getelementptr i8, ptr %p6485, i64 -32
  %ld6487 = load i64, ptr %rgep6486, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6487, ptr %slot1173, align 8
  %v6488 = load i64, ptr %slot1173, align 8
  %op6489 = sub i64 %v6488, 1
  store i64 %op6489, ptr %slot1174, align 8
  %v6490 = load i64, ptr %slot1174, align 8
  %cmp6491 = icmp eq i64 %v6490, 0
  %cv6492 = zext i1 %cmp6491 to i32
  store i32 %cv6492, ptr %slot1175, align 8
  %v6493 = load i32, ptr %slot1175, align 8
  %cv6494 = zext i32 %v6493 to i64
  %cond6495 = icmp ne i64 %cv6494, 0
  br i1 %cond6495, label %bb_rcglast1629, label %bb_rcgdec1629
bb_rcglast1629:
  %v6496 = load i64, ptr %slot1166, align 8
  %op6497 = sub i64 %v6496, 24
  store i64 %op6497, ptr %slot1176, align 8
  %v6498 = load i64, ptr %slot1166, align 8
  %p6499 = inttoptr i64 %v6498 to ptr
  %rgep6500 = getelementptr i8, ptr %p6499, i64 -24
  %ld6501 = load i64, ptr %rgep6500, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6501, ptr %slot1177, align 8
  %v6502 = load i64, ptr %slot1177, align 8
  %cmp6503 = icmp ne i64 %v6502, 0
  %cv6504 = zext i1 %cmp6503 to i32
  store i32 %cv6504, ptr %slot1178, align 8
  %v6505 = load i32, ptr %slot1178, align 8
  %cv6506 = zext i32 %v6505 to i64
  %cond6507 = icmp ne i64 %cv6506, 0
  br i1 %cond6507, label %bb_rcgdec1629, label %bb_rcgslow1629
bb_rcgslow1629:
  %v6508 = load i64, ptr %slot1165, align 8
  %v6509 = load i64, ptr %slot1148, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6508, i64 %v6509) nomerge, !dbg !186
  br label %bb_rcgdone1629
bb_rcgdec1629:
  %v6510 = load i64, ptr %slot1174, align 8
  %v6511 = load i64, ptr %slot1166, align 8
  %p6512 = inttoptr i64 %v6511 to ptr
  %rgep6513 = getelementptr i8, ptr %p6512, i64 -32
  store i64 %v6510, ptr %rgep6513, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1629
bb_rcgclear1629:
  %v6514 = load i64, ptr %slot1148, align 8
  %p6515 = inttoptr i64 %v6514 to ptr
  store i64 0, ptr %p6515, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1629
bb_rcgdone1629:
  br label %bb_rcslotdone1598
bb_rcslotdone1598:
  %v6516 = load i64, ptr %slot33, align 8
  store i64 %v6516, ptr %slot1179, align 8
  %v6517 = load i64, ptr %slot64, align 8
  %v6518 = load i64, ptr %slot1179, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  store i64 %v6517, ptr %p6519, align 8, !alias.scope !3, !noalias !4
  %v6520 = load i64, ptr %slot64, align 8
  %p6522 = inttoptr i64 %v6520 to ptr
  %gep6523 = getelementptr i8, ptr %p6522, i64 5640
  %op6521 = ptrtoint ptr %gep6523 to i64
  store i64 %op6521, ptr %slot1180, align 8
  %v6524 = load i64, ptr %slot1180, align 8
  %p6525 = inttoptr i64 %v6524 to ptr
  %ld6526 = load i64, ptr %p6525, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6526, ptr %slot1181, align 8
  %v6527 = load i64, ptr %slot1181, align 8
  %op6528 = add i64 %v6527, 248
  store i64 %op6528, ptr %slot1182, align 8
  %v6529 = load i64, ptr %slot1182, align 8
  %p6530 = inttoptr i64 %v6529 to ptr
  %ld6531 = load i64, ptr %p6530, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6531, ptr %slot1183, align 8
  %v6532 = load i64, ptr %slot1179, align 8
  %p6534 = inttoptr i64 %v6532 to ptr
  %gep6535 = getelementptr i8, ptr %p6534, i64 8
  %op6533 = ptrtoint ptr %gep6535 to i64
  store i64 %op6533, ptr %slot1184, align 8
  %v6536 = load i64, ptr %slot1183, align 8
  %v6537 = load i64, ptr %slot1184, align 8
  %p6538 = inttoptr i64 %v6537 to ptr
  store i64 %v6536, ptr %p6538, align 8, !alias.scope !3, !noalias !4
  %v6539 = load i64, ptr %slot1179, align 8
  %p6541 = inttoptr i64 %v6539 to ptr
  %gep6542 = getelementptr i8, ptr %p6541, i64 16
  %op6540 = ptrtoint ptr %gep6542 to i64
  store i64 %op6540, ptr %slot1185, align 8
  %v6543 = load i64, ptr %slot1185, align 8
  %p6544 = inttoptr i64 %v6543 to ptr
  store i64 0, ptr %p6544, align 8, !alias.scope !3, !noalias !4
  %v6545 = load i64, ptr %slot64, align 8
  %p6547 = inttoptr i64 %v6545 to ptr
  %gep6548 = getelementptr i8, ptr %p6547, i64 112
  %op6546 = ptrtoint ptr %gep6548 to i64
  store i64 %op6546, ptr %slot1186, align 8
  %v6549 = load i64, ptr %slot1179, align 8
  %p6551 = inttoptr i64 %v6549 to ptr
  %gep6552 = getelementptr i8, ptr %p6551, i64 24
  %op6550 = ptrtoint ptr %gep6552 to i64
  store i64 %op6550, ptr %slot1187, align 8
  %v6553 = load i64, ptr %slot1179, align 8
  %p6555 = inttoptr i64 %v6553 to ptr
  %gep6556 = getelementptr i8, ptr %p6555, i64 28
  %op6554 = ptrtoint ptr %gep6556 to i64
  store i64 %op6554, ptr %slot1188, align 8
  %v6557 = load i64, ptr %slot1186, align 8
  %p6558 = inttoptr i64 %v6557 to ptr
  %ld6559 = load i32, ptr %p6558, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld6559, ptr %slot1189, align 8
  %v6560 = load i64, ptr %slot1187, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  store i32 1, ptr %p6561, align 4, !alias.scope !3, !noalias !4
  %v6562 = load i32, ptr %slot1189, align 8
  %v6563 = load i64, ptr %slot1188, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  store i32 %v6562, ptr %p6564, align 4, !alias.scope !3, !noalias !4
  %v6565 = load i64, ptr %slot1179, align 8
  %v6566 = load i64, ptr %slot1182, align 8
  %p6567 = inttoptr i64 %v6566 to ptr
  store i64 %v6565, ptr %p6567, align 8, !alias.scope !9999998, !noalias !9999999
  %v6568 = load i64, ptr %slot1146, align 8
  %cmp6569 = icmp ne i64 %v6568, 0
  %cv6570 = zext i1 %cmp6569 to i32
  store i32 %cv6570, ptr %slot1190, align 8
  %v6571 = load i32, ptr %slot1190, align 8
  %cv6572 = zext i32 %v6571 to i64
  %cond6573 = icmp ne i64 %cv6572, 0
  br i1 %cond6573, label %bb_rcspinmark1681, label %bb_rcspindone1681
bb_rcspinmark1681:
  %v6574 = load i64, ptr %slot1146, align 8
  %op6575 = sub i64 %v6574, 16
  store i64 %op6575, ptr %slot1191, align 8
  %v6576 = load i64, ptr %slot1146, align 8
  %p6577 = inttoptr i64 %v6576 to ptr
  %rgep6578 = getelementptr i8, ptr %p6577, i64 -16
  %ld6579 = load i64, ptr %rgep6578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6579, ptr %slot1192, align 8
  %v6580 = load i64, ptr %slot1192, align 8
  %op6581 = and i64 %v6580, 2
  store i64 %op6581, ptr %slot1193, align 8
  %v6582 = load i64, ptr %slot1193, align 8
  %cmp6583 = icmp ne i64 %v6582, 0
  %cv6584 = zext i1 %cmp6583 to i32
  store i32 %cv6584, ptr %slot1194, align 8
  %v6585 = load i32, ptr %slot1194, align 8
  %cv6586 = zext i32 %v6585 to i64
  %cond6587 = icmp ne i64 %cv6586, 0
  br i1 %cond6587, label %bb_rcspindone1681, label %bb_rcspintype1681
bb_rcspintype1681:
  %v6588 = load i64, ptr %slot1192, align 8
  %op6589 = and i64 %v6588, 4611686018427387907
  store i64 %op6589, ptr %slot1195, align 8
  %v6590 = load i64, ptr %slot1195, align 8
  %cmp6591 = icmp eq i64 %v6590, 0
  %cv6592 = zext i1 %cmp6591 to i32
  store i32 %cv6592, ptr %slot1196, align 8
  %v6593 = load i32, ptr %slot1196, align 8
  %cv6594 = zext i32 %v6593 to i64
  %cond6595 = icmp ne i64 %cv6594, 0
  br i1 %cond6595, label %bb_rcs1689, label %bb_rcspinslow1681
bb_rcs1689:
  %v6596 = load i64, ptr %slot1146, align 8
  %op6597 = sub i64 %v6596, 8
  store i64 %op6597, ptr %slot1197, align 8
  %v6598 = load i64, ptr %slot1146, align 8
  %p6599 = inttoptr i64 %v6598 to ptr
  %rgep6600 = getelementptr i8, ptr %p6599, i64 -8
  %ld6601 = load i64, ptr %rgep6600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6601, ptr %slot1198, align 8
  %p6602 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld6603 = load i64, ptr %p6602, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6603, ptr %slot1199, align 8
  %v6604 = load i64, ptr %slot1198, align 8
  %v6605 = load i64, ptr %slot1199, align 8
  %cmp6606 = icmp eq i64 %v6604, %v6605
  %cv6607 = zext i1 %cmp6606 to i32
  store i32 %cv6607, ptr %slot1200, align 8
  %v6608 = load i32, ptr %slot1200, align 8
  %cv6609 = zext i32 %v6608 to i64
  %cond6610 = icmp ne i64 %cv6609, 0
  br i1 %cond6610, label %bb_rcs1694, label %bb_rcspinslow1681
bb_rcs1694:
  %v6611 = load i64, ptr %slot64, align 8
  %p6613 = inttoptr i64 %v6611 to ptr
  %gep6614 = getelementptr i8, ptr %p6613, i64 5640
  %op6612 = ptrtoint ptr %gep6614 to i64
  store i64 %op6612, ptr %slot1201, align 8
  %v6615 = load i64, ptr %slot1201, align 8
  %p6616 = inttoptr i64 %v6615 to ptr
  %ld6617 = load i64, ptr %p6616, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6617, ptr %slot1202, align 8
  %v6618 = load i64, ptr %slot1202, align 8
  %op6619 = add i64 %v6618, 256
  store i64 %op6619, ptr %slot1203, align 8
  %v6620 = load i64, ptr %slot1203, align 8
  %p6621 = inttoptr i64 %v6620 to ptr
  %ld6622 = load i64, ptr %p6621, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6622, ptr %slot1204, align 8
  %v6623 = load i64, ptr %slot1204, align 8
  %cmp6624 = icmp ne i64 %v6623, 0
  %cv6625 = zext i1 %cmp6624 to i32
  store i32 %cv6625, ptr %slot1205, align 8
  %v6626 = load i32, ptr %slot1205, align 8
  %cv6627 = zext i32 %v6626 to i64
  %cond6628 = icmp ne i64 %cv6627, 0
  br i1 %cond6628, label %bb_rcs1700, label %bb_rcspinslow1681
bb_rcs1700:
  %v6629 = load i64, ptr %slot64, align 8
  %p6631 = inttoptr i64 %v6629 to ptr
  %gep6632 = getelementptr i8, ptr %p6631, i64 24
  %op6630 = ptrtoint ptr %gep6632 to i64
  store i64 %op6630, ptr %slot1206, align 8
  %v6633 = load i64, ptr %slot1206, align 8
  %p6634 = inttoptr i64 %v6633 to ptr
  %ld6635 = load i64, ptr %p6634, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6635, ptr %slot1207, align 8
  %v6636 = load i64, ptr %slot1207, align 8
  %op6637 = add i64 %v6636, 40
  store i64 %op6637, ptr %slot1208, align 8
  %v6638 = load i64, ptr %slot1208, align 8
  %v6639 = load i64, ptr %slot1207, align 8
  %cmp6640 = icmp uge i64 %v6638, %v6639
  %cv6641 = zext i1 %cmp6640 to i32
  store i32 %cv6641, ptr %slot1209, align 8
  %v6642 = load i32, ptr %slot1209, align 8
  %cv6643 = zext i32 %v6642 to i64
  %cond6644 = icmp ne i64 %cv6643, 0
  br i1 %cond6644, label %bb_rcs1705, label %bb_rcspinslow1681
bb_rcs1705:
  %v6645 = load i64, ptr %slot64, align 8
  %p6647 = inttoptr i64 %v6645 to ptr
  %gep6648 = getelementptr i8, ptr %p6647, i64 88
  %op6646 = ptrtoint ptr %gep6648 to i64
  store i64 %op6646, ptr %slot1210, align 8
  %v6649 = load i64, ptr %slot1210, align 8
  %p6650 = inttoptr i64 %v6649 to ptr
  %ld6651 = load i64, ptr %p6650, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6651, ptr %slot1211, align 8
  %v6652 = load i64, ptr %slot1211, align 8
  %cmp6653 = icmp eq i64 %v6652, 0
  %cv6654 = zext i1 %cmp6653 to i32
  store i32 %cv6654, ptr %slot1212, align 8
  %v6655 = load i64, ptr %slot1208, align 8
  %v6656 = load i64, ptr %slot1211, align 8
  %cmp6657 = icmp ule i64 %v6655, %v6656
  %cv6658 = zext i1 %cmp6657 to i32
  store i32 %cv6658, ptr %slot1213, align 8
  %v6659 = load i32, ptr %slot1212, align 8
  %v6660 = load i32, ptr %slot1213, align 8
  %op6661 = or i32 %v6659, %v6660
  store i32 %op6661, ptr %slot1214, align 8
  %v6662 = load i32, ptr %slot1214, align 8
  %cv6663 = zext i32 %v6662 to i64
  %cond6664 = icmp ne i64 %cv6663, 0
  br i1 %cond6664, label %bb_rcs1711, label %bb_rcspinslow1681
bb_rcs1711:
  %v6665 = load i64, ptr %slot1146, align 8
  %op6666 = sub i64 %v6665, 24
  store i64 %op6666, ptr %slot1215, align 8
  %v6667 = load i64, ptr %slot1146, align 8
  %p6668 = inttoptr i64 %v6667 to ptr
  %rgep6669 = getelementptr i8, ptr %p6668, i64 -24
  %ld6670 = load i64, ptr %rgep6669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6670, ptr %slot1216, align 8
  %v6671 = load i64, ptr %slot1216, align 8
  %cmp6672 = icmp ne i64 %v6671, 18446744073709551615
  %cv6673 = zext i1 %cmp6672 to i32
  store i32 %cv6673, ptr %slot1217, align 8
  %v6674 = load i32, ptr %slot1217, align 8
  %cv6675 = zext i32 %v6674 to i64
  %cond6676 = icmp ne i64 %cv6675, 0
  br i1 %cond6676, label %bb_rcs1715, label %bb_rcspinslow1681
bb_rcs1715:
  %v6677 = load i64, ptr %slot1146, align 8
  %op6678 = add i64 %v6677, 32
  store i64 %op6678, ptr %slot1218, align 8
  %v6679 = load i64, ptr %slot1218, align 8
  %p6680 = inttoptr i64 %v6679 to ptr
  %ld6681 = load i64, ptr %p6680, align 8
  store i64 %ld6681, ptr %slot1219, align 8
  %v6682 = load i64, ptr %slot1219, align 8
  %cmp6683 = icmp ne i64 %v6682, 0
  %cv6684 = zext i1 %cmp6683 to i32
  store i32 %cv6684, ptr %slot1220, align 8
  %v6685 = load i32, ptr %slot1220, align 8
  %cv6686 = zext i32 %v6685 to i64
  %cond6687 = icmp ne i64 %cv6686, 0
  br i1 %cond6687, label %bb_rcspinbacking1681, label %bb_rcspincommit1681
bb_rcspinbacking1681:
  %v6688 = load i64, ptr %slot1219, align 8
  %op6689 = sub i64 %v6688, 16
  store i64 %op6689, ptr %slot1221, align 8
  %v6690 = load i64, ptr %slot1219, align 8
  %p6691 = inttoptr i64 %v6690 to ptr
  %rgep6692 = getelementptr i8, ptr %p6691, i64 -16
  %ld6693 = load i64, ptr %rgep6692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6693, ptr %slot1222, align 8
  %v6694 = load i64, ptr %slot1222, align 8
  %op6695 = and i64 %v6694, 4611686018427387907
  store i64 %op6695, ptr %slot1223, align 8
  %v6696 = load i64, ptr %slot1223, align 8
  %cmp6697 = icmp eq i64 %v6696, 0
  %cv6698 = zext i1 %cmp6697 to i32
  store i32 %cv6698, ptr %slot1224, align 8
  %v6699 = load i32, ptr %slot1224, align 8
  %cv6700 = zext i32 %v6699 to i64
  %cond6701 = icmp ne i64 %cv6700, 0
  br i1 %cond6701, label %bb_rcs1723, label %bb_rcspinslow1681
bb_rcs1723:
  %v6702 = load i64, ptr %slot1219, align 8
  %op6703 = sub i64 %v6702, 24
  store i64 %op6703, ptr %slot1225, align 8
  %v6704 = load i64, ptr %slot1219, align 8
  %p6705 = inttoptr i64 %v6704 to ptr
  %rgep6706 = getelementptr i8, ptr %p6705, i64 -24
  %ld6707 = load i64, ptr %rgep6706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6707, ptr %slot1226, align 8
  %v6708 = load i64, ptr %slot1226, align 8
  %cmp6709 = icmp ne i64 %v6708, 18446744073709551615
  %cv6710 = zext i1 %cmp6709 to i32
  store i32 %cv6710, ptr %slot1227, align 8
  %v6711 = load i32, ptr %slot1227, align 8
  %cv6712 = zext i32 %v6711 to i64
  %cond6713 = icmp ne i64 %cv6712, 0
  br i1 %cond6713, label %bb_rcs1727, label %bb_rcspinslow1681
bb_rcs1727:
  br label %bb_rcspincommit1681
bb_rcspincommit1681:
  %v6714 = load i64, ptr %slot1204, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  %ld6716 = load i64, ptr %p6715, align 8
  store i64 %ld6716, ptr %slot1228, align 8
  %v6717 = load i64, ptr %slot1202, align 8
  %op6718 = add i64 %v6717, 256
  store i64 %op6718, ptr %slot1229, align 8
  %v6719 = load i64, ptr %slot1228, align 8
  %v6720 = load i64, ptr %slot1229, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  store i64 %v6719, ptr %p6721, align 8, !alias.scope !9999998, !noalias !9999999
  %v6722 = load i64, ptr %slot1202, align 8
  %op6723 = add i64 %v6722, 264
  store i64 %op6723, ptr %slot1230, align 8
  %v6724 = load i64, ptr %slot1230, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  %ld6726 = load i64, ptr %p6725, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6726, ptr %slot1231, align 8
  %v6727 = load i64, ptr %slot1231, align 8
  %op6728 = add i64 %v6727, 18446744073709551615
  store i64 %op6728, ptr %slot1232, align 8
  %v6729 = load i64, ptr %slot1232, align 8
  %v6730 = load i64, ptr %slot1230, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  store i64 %v6729, ptr %p6731, align 8, !alias.scope !9999998, !noalias !9999999
  %v6732 = load i64, ptr %slot64, align 8
  %p6734 = inttoptr i64 %v6732 to ptr
  %gep6735 = getelementptr i8, ptr %p6734, i64 24
  %op6733 = ptrtoint ptr %gep6735 to i64
  store i64 %op6733, ptr %slot1233, align 8
  %v6736 = load i64, ptr %slot1233, align 8
  %p6737 = inttoptr i64 %v6736 to ptr
  %ld6738 = load i64, ptr %p6737, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6738, ptr %slot1234, align 8
  %v6739 = load i64, ptr %slot1234, align 8
  %op6740 = add i64 %v6739, 40
  store i64 %op6740, ptr %slot1235, align 8
  %v6741 = load i64, ptr %slot1235, align 8
  %v6742 = load i64, ptr %slot1233, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  store i64 %v6741, ptr %p6743, align 8, !alias.scope !9999998, !noalias !9999999
  %v6744 = load i64, ptr %slot1202, align 8
  %op6745 = add i64 %v6744, 48
  store i64 %op6745, ptr %slot1236, align 8
  %v6746 = load i64, ptr %slot1236, align 8
  %p6747 = inttoptr i64 %v6746 to ptr
  %ld6748 = load i64, ptr %p6747, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6748, ptr %slot1237, align 8
  %v6749 = load i64, ptr %slot1237, align 8
  %op6750 = add i64 %v6749, 40
  store i64 %op6750, ptr %slot1238, align 8
  %v6751 = load i64, ptr %slot1238, align 8
  %v6752 = load i64, ptr %slot1236, align 8
  %p6753 = inttoptr i64 %v6752 to ptr
  store i64 %v6751, ptr %p6753, align 8, !alias.scope !9999998, !noalias !9999999
  %v6754 = load i64, ptr %slot1146, align 8
  %op6755 = sub i64 %v6754, 24
  store i64 %op6755, ptr %slot1239, align 8
  %v6756 = load i64, ptr %slot1146, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  %rgep6758 = getelementptr i8, ptr %p6757, i64 -24
  %ld6759 = load i64, ptr %rgep6758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6759, ptr %slot1240, align 8
  %v6760 = load i64, ptr %slot1240, align 8
  %op6761 = add i64 %v6760, 1
  store i64 %op6761, ptr %slot1241, align 8
  %v6762 = load i64, ptr %slot1241, align 8
  %v6763 = load i64, ptr %slot1146, align 8
  %p6764 = inttoptr i64 %v6763 to ptr
  %rgep6765 = getelementptr i8, ptr %p6764, i64 -24
  store i64 %v6762, ptr %rgep6765, align 8, !alias.scope !9, !noalias !10
  %v6766 = load i64, ptr %slot1219, align 8
  %cmp6767 = icmp ne i64 %v6766, 0
  %cv6768 = zext i1 %cmp6767 to i32
  store i32 %cv6768, ptr %slot1242, align 8
  %v6769 = load i32, ptr %slot1242, align 8
  %cv6770 = zext i32 %v6769 to i64
  %cond6771 = icmp ne i64 %cv6770, 0
  br i1 %cond6771, label %bb_rcspinhold1681, label %bb_rcspinjournal1681
bb_rcspinhold1681:
  %v6772 = load i64, ptr %slot1219, align 8
  %op6773 = sub i64 %v6772, 24
  store i64 %op6773, ptr %slot1243, align 8
  %v6774 = load i64, ptr %slot1219, align 8
  %p6775 = inttoptr i64 %v6774 to ptr
  %rgep6776 = getelementptr i8, ptr %p6775, i64 -24
  %ld6777 = load i64, ptr %rgep6776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6777, ptr %slot1244, align 8
  %v6778 = load i64, ptr %slot1244, align 8
  %op6779 = add i64 %v6778, 1
  store i64 %op6779, ptr %slot1245, align 8
  %v6780 = load i64, ptr %slot1245, align 8
  %v6781 = load i64, ptr %slot1219, align 8
  %p6782 = inttoptr i64 %v6781 to ptr
  %rgep6783 = getelementptr i8, ptr %p6782, i64 -24
  store i64 %v6780, ptr %rgep6783, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal1681
bb_rcspinjournal1681:
  %v6784 = load i64, ptr %slot1192, align 8
  %op6785 = and i64 %v6784, 1152921504606846976
  store i64 %op6785, ptr %slot1246, align 8
  %v6786 = load i64, ptr %slot1192, align 8
  %op6787 = or i64 %v6786, 1152921504606846976
  store i64 %op6787, ptr %slot1247, align 8
  %v6788 = load i64, ptr %slot1146, align 8
  %op6789 = sub i64 %v6788, 16
  store i64 %op6789, ptr %slot1248, align 8
  %v6790 = load i64, ptr %slot1247, align 8
  %v6791 = load i64, ptr %slot1146, align 8
  %p6792 = inttoptr i64 %v6791 to ptr
  %rgep6793 = getelementptr i8, ptr %p6792, i64 -16
  store i64 %v6790, ptr %rgep6793, align 8, !alias.scope !9, !noalias !10
  %v6794 = load i64, ptr %slot1179, align 8
  %p6796 = inttoptr i64 %v6794 to ptr
  %gep6797 = getelementptr i8, ptr %p6796, i64 16
  %op6795 = ptrtoint ptr %gep6797 to i64
  store i64 %op6795, ptr %slot1249, align 8
  %v6798 = load i64, ptr %slot1249, align 8
  %p6799 = inttoptr i64 %v6798 to ptr
  %ld6800 = load i64, ptr %p6799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6800, ptr %slot1250, align 8
  %v6801 = load i64, ptr %slot1204, align 8
  %op6802 = add i64 %v6801, 0
  store i64 %op6802, ptr %slot1251, align 8
  %v6803 = load i64, ptr %slot1250, align 8
  %v6804 = load i64, ptr %slot1251, align 8
  %p6805 = inttoptr i64 %v6804 to ptr
  store i64 %v6803, ptr %p6805, align 8, !alias.scope !9999998, !noalias !9999999
  %v6806 = load i64, ptr %slot1204, align 8
  %op6807 = add i64 %v6806, 8
  store i64 %op6807, ptr %slot1252, align 8
  %v6808 = load i64, ptr %slot1146, align 8
  %v6809 = load i64, ptr %slot1252, align 8
  %p6810 = inttoptr i64 %v6809 to ptr
  store i64 %v6808, ptr %p6810, align 8, !alias.scope !9999998, !noalias !9999999
  %v6811 = load i64, ptr %slot1204, align 8
  %op6812 = add i64 %v6811, 16
  store i64 %op6812, ptr %slot1253, align 8
  %v6813 = load i64, ptr %slot1246, align 8
  %v6814 = load i64, ptr %slot1253, align 8
  %p6815 = inttoptr i64 %v6814 to ptr
  store i64 %v6813, ptr %p6815, align 8, !alias.scope !9999998, !noalias !9999999
  %v6816 = load i64, ptr %slot1204, align 8
  %op6817 = add i64 %v6816, 24
  store i64 %op6817, ptr %slot1254, align 8
  %v6818 = load i64, ptr %slot1254, align 8
  %p6819 = inttoptr i64 %v6818 to ptr
  store i32 1, ptr %p6819, align 4, !alias.scope !9999998, !noalias !9999999
  %v6820 = load i64, ptr %slot1204, align 8
  %op6821 = add i64 %v6820, 32
  store i64 %op6821, ptr %slot1255, align 8
  %v6822 = load i64, ptr %slot1219, align 8
  %v6823 = load i64, ptr %slot1255, align 8
  %p6824 = inttoptr i64 %v6823 to ptr
  store i64 %v6822, ptr %p6824, align 8, !alias.scope !9999998, !noalias !9999999
  %v6825 = load i64, ptr %slot1179, align 8
  %p6827 = inttoptr i64 %v6825 to ptr
  %gep6828 = getelementptr i8, ptr %p6827, i64 16
  %op6826 = ptrtoint ptr %gep6828 to i64
  store i64 %op6826, ptr %slot1256, align 8
  %v6829 = load i64, ptr %slot1204, align 8
  %v6830 = load i64, ptr %slot1256, align 8
  %p6831 = inttoptr i64 %v6830 to ptr
  store i64 %v6829, ptr %p6831, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone1681
bb_rcspinslow1681:
  %v6832 = load i64, ptr %slot1, align 8
  %p6833 = inttoptr i64 %v6832 to ptr
  %v6834 = load i64, ptr %slot1179, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  %v6836 = load i64, ptr %slot1146, align 8
  %p6837 = inttoptr i64 %v6836 to ptr
  %call6838 = call i32 @myl_qbe_rc_scope_pin(ptr %p6833, ptr %p6835, ptr %p6837) nomerge, !dbg !186
  store i32 %call6838, ptr %slot1257, align 8
  %v6839 = load i32, ptr %slot1257, align 8
  %cv6840 = zext i32 %v6839 to i64
  %cond6841 = icmp ne i64 %cv6840, 0
  br i1 %cond6841, label %bb_rcunique1758, label %bb_failure
bb_rcunique1758:
  br label %bb_rcspindone1681
bb_rcspindone1681:
  %v6842 = load i64, ptr %slot1146, align 8
  %v6843 = load i64, ptr %slot49, align 8
  %p6844 = inttoptr i64 %v6843 to ptr
  store i64 %v6842, ptr %p6844, align 8, !alias.scope !3, !noalias !4
  %v6845 = load i64, ptr %slot43, align 8
  %v6846 = load i64, ptr %slot52, align 8
  %p6847 = inttoptr i64 %v6846 to ptr
  store i64 %v6845, ptr %p6847, align 8, !alias.scope !3, !noalias !4
  %v6848 = load i64, ptr %slot52, align 8
  %p6849 = inttoptr i64 %v6848 to ptr
  %ld6850 = load i64, ptr %p6849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6850, ptr %slot1258, align 8
  %v6851 = load i64, ptr %slot1258, align 8
  %op6852 = add i64 %v6851, 48
  store i64 %op6852, ptr %slot1259, align 8
  %v6853 = load i64, ptr %slot1259, align 8
  %p6854 = inttoptr i64 %v6853 to ptr
  %ld6855 = load i64, ptr %p6854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6855, ptr %slot1260, align 8
  %v6856 = load i64, ptr %slot1260, align 8
  %v6857 = load i64, ptr %slot52, align 8
  %p6858 = inttoptr i64 %v6857 to ptr
  store i64 %v6856, ptr %p6858, align 8, !alias.scope !3, !noalias !4
  %v6859 = load i64, ptr %slot17, align 8
  %p6860 = inttoptr i64 %v6859 to ptr
  %ld6861 = load i32, ptr %p6860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6861, ptr %slot1261, align 8
  %v6862 = load i32, ptr %slot1261, align 8
  %cv6863 = zext i32 %v6862 to i64
  %cond6864 = icmp ne i64 %cv6863, 0
  br i1 %cond6864, label %bb_rcslotdrop1764, label %bb_rcslotdone1764
bb_rcslotdrop1764:
  %v6865 = load i64, ptr %slot17, align 8
  %p6866 = inttoptr i64 %v6865 to ptr
  store i32 0, ptr %p6866, align 4, !alias.scope !3, !noalias !4
  %v6867 = load i64, ptr %slot26, align 8
  store i64 %v6867, ptr %slot1262, align 8
  %v6868 = load i64, ptr %slot18, align 8
  %p6869 = inttoptr i64 %v6868 to ptr
  %ld6870 = load i32, ptr %p6869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6870, ptr %slot1263, align 8
  %v6871 = load i32, ptr %slot1263, align 8
  %op6872 = and i32 %v6871, 28
  store i32 %op6872, ptr %slot1264, align 8
  %v6873 = load i32, ptr %slot1264, align 8
  %cv6874 = zext i32 %v6873 to i64
  %cond6875 = icmp ne i64 %cv6874, 0
  br i1 %cond6875, label %bb_rcslotrole1764, label %bb_rcslotowner1764
bb_rcslotrole1764:
  %v6876 = load i64, ptr %slot64, align 8
  store i64 %v6876, ptr %slot1265, align 8
  %v6877 = load i64, ptr %slot1265, align 8
  %v6878 = load i64, ptr %slot1262, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6877, i64 %v6878) nomerge, !dbg !188
  br label %bb_rcslotdone1764
bb_rcslotowner1764:
  %v6879 = load i64, ptr %slot64, align 8
  store i64 %v6879, ptr %slot1266, align 8
  %v6880 = load i64, ptr %slot1266, align 8
  %v6881 = load i64, ptr %slot1262, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6880, i64 %v6881) nomerge, !dbg !188
  br label %bb_rcslotdone1764
bb_rcslotdone1764:
  %v6882 = load i64, ptr %slot52, align 8
  %p6883 = inttoptr i64 %v6882 to ptr
  %ld6884 = load i64, ptr %p6883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6884, ptr %slot1267, align 8
  %v6885 = load i64, ptr %slot1267, align 8
  %v6886 = load i64, ptr %slot51, align 8
  %p6887 = inttoptr i64 %v6886 to ptr
  store i64 %v6885, ptr %p6887, align 8, !alias.scope !3, !noalias !4
  %v6888 = load i64, ptr %slot51, align 8
  %p6889 = inttoptr i64 %v6888 to ptr
  %ld6890 = load i64, ptr %p6889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6890, ptr %slot1268, align 8
  %v6891 = load i64, ptr %slot1268, align 8
  %v6892 = load i64, ptr %slot52, align 8
  %p6893 = inttoptr i64 %v6892 to ptr
  store i64 %v6891, ptr %p6893, align 8, !alias.scope !3, !noalias !4
  %v6894 = load i64, ptr %slot53, align 8
  %p6895 = inttoptr i64 %v6894 to ptr
  store i64 0, ptr %p6895, align 8, !alias.scope !3, !noalias !4
  %v6896 = load i64, ptr %slot53, align 8
  %p6897 = inttoptr i64 %v6896 to ptr
  %ld6898 = load i64, ptr %p6897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6898, ptr %slot1269, align 8
  %v6899 = load i64, ptr %slot52, align 8
  %p6900 = inttoptr i64 %v6899 to ptr
  %ld6901 = load i64, ptr %p6900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6901, ptr %slot1270, align 8
  %v6902 = load i64, ptr %slot1270, align 8
  %v6903 = load i64, ptr %slot1269, align 8
  %cmp6904 = icmp slt i64 %v6902, %v6903
  %cv6905 = zext i1 %cmp6904 to i64
  store i64 %cv6905, ptr %slot1271, align 8
  %v6906 = load i64, ptr %slot1271, align 8
  %v6907 = load i64, ptr %slot52, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  store i64 %v6906, ptr %p6908, align 8, !alias.scope !3, !noalias !4
  %v6909 = load i64, ptr %slot52, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  %ld6911 = load i64, ptr %p6910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6911, ptr %slot1272, align 8
  %v6912 = load i64, ptr %slot1272, align 8
  %cond6913 = icmp ne i64 %v6912, 0
  br i1 %cond6913, label %bb_next1777, label %bb_i95
bb_next1777:
  %v6914 = load i64, ptr %slot49, align 8
  %p6915 = inttoptr i64 %v6914 to ptr
  %ld6916 = load i64, ptr %p6915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6916, ptr %slot1273, align 8
  %v6917 = load i64, ptr %slot1273, align 8
  %op6918 = add i64 %v6917, 0
  store i64 %op6918, ptr %slot1274, align 8
  %v6919 = load i64, ptr %slot1274, align 8
  %p6920 = inttoptr i64 %v6919 to ptr
  %ld6921 = load i64, ptr %p6920, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6921, ptr %slot1275, align 8
  %v6922 = load i64, ptr %slot1275, align 8
  %v6923 = load i64, ptr %slot52, align 8
  %p6924 = inttoptr i64 %v6923 to ptr
  store i64 %v6922, ptr %p6924, align 8, !alias.scope !3, !noalias !4
  %v6925 = load i64, ptr %slot52, align 8
  %p6926 = inttoptr i64 %v6925 to ptr
  %ld6927 = load i64, ptr %p6926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6927, ptr %slot1276, align 8
  %v6928 = load i64, ptr %slot1276, align 8
  %cmp6929 = icmp ugt i64 %v6928, 9223372036854775807
  %cv6930 = zext i1 %cmp6929 to i64
  store i64 %cv6930, ptr %slot1277, align 8
  %v6931 = load i64, ptr %slot1277, align 8
  %cond6932 = icmp ne i64 %v6931, 0
  br i1 %cond6932, label %bb_cast_overflow1782, label %bb_cast_ok1782
bb_cast_overflow1782:
  %v6933 = load i64, ptr %slot1, align 8
  %p6934 = inttoptr i64 %v6933 to ptr
  %v6935 = load i64, ptr %slot1276, align 8
  call void @myl_qbe_fail_cast(ptr %p6934, i64 %v6935, i64 320) nomerge, !dbg !190
  unreachable
bb_cast_ok1782:
  %v6936 = load i64, ptr %slot1276, align 8
  %v6937 = load i64, ptr %slot52, align 8
  %p6938 = inttoptr i64 %v6937 to ptr
  store i64 %v6936, ptr %p6938, align 8, !alias.scope !3, !noalias !4
  %v6939 = load i64, ptr %slot51, align 8
  %p6940 = inttoptr i64 %v6939 to ptr
  %ld6941 = load i64, ptr %p6940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6941, ptr %slot1278, align 8
  %v6942 = load i64, ptr %slot1278, align 8
  %v6943 = load i64, ptr %slot53, align 8
  %p6944 = inttoptr i64 %v6943 to ptr
  store i64 %v6942, ptr %p6944, align 8, !alias.scope !3, !noalias !4
  %v6945 = load i64, ptr %slot53, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  %ld6947 = load i64, ptr %p6946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6947, ptr %slot1279, align 8
  %v6948 = load i64, ptr %slot52, align 8
  %p6949 = inttoptr i64 %v6948 to ptr
  %ld6950 = load i64, ptr %p6949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6950, ptr %slot1280, align 8
  %v6951 = load i64, ptr %slot1280, align 8
  %v6952 = load i64, ptr %slot1279, align 8
  %ovpair6954 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6951, i64 %v6952)
  %op6953 = extractvalue { i64, i1 } %ovpair6954, 0
  %ov6955 = extractvalue { i64, i1 } %ovpair6954, 1
  store i64 %op6953, ptr %slot1281, align 8
  %v6956 = load i64, ptr %slot1280, align 8
  %v6957 = load i64, ptr %slot1281, align 8
  %op6958 = xor i64 %v6956, %v6957
  store i64 %op6958, ptr %slot1282, align 8
  %v6959 = load i64, ptr %slot1279, align 8
  %v6960 = load i64, ptr %slot1281, align 8
  %op6961 = xor i64 %v6959, %v6960
  store i64 %op6961, ptr %slot1283, align 8
  %v6962 = load i64, ptr %slot1282, align 8
  %v6963 = load i64, ptr %slot1283, align 8
  %op6964 = and i64 %v6962, %v6963
  store i64 %op6964, ptr %slot1284, align 8
  %cv6965 = zext i1 %ov6955 to i64
  store i64 %cv6965, ptr %slot1285, align 8
  %v6966 = load i64, ptr %slot1285, align 8
  %cond6967 = icmp ne i64 %v6966, 0
  br i1 %cond6967, label %bb_overflow1786, label %bb_checked1786
bb_overflow1786:
  %v6968 = load i64, ptr %slot1, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  %v6970 = load i64, ptr %slot1280, align 8
  %v6971 = load i64, ptr %slot1279, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p6969, i64 0, i64 %v6970, i64 %v6971, i64 64) nomerge, !dbg !192
  unreachable
bb_checked1786:
  %v6972 = load i64, ptr %slot1281, align 8
  %v6973 = load i64, ptr %slot52, align 8
  %p6974 = inttoptr i64 %v6973 to ptr
  store i64 %v6972, ptr %p6974, align 8, !alias.scope !3, !noalias !4
  %v6975 = load i64, ptr %slot52, align 8
  %p6976 = inttoptr i64 %v6975 to ptr
  %ld6977 = load i64, ptr %p6976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6977, ptr %slot1286, align 8
  %v6978 = load i64, ptr %slot1286, align 8
  %v6979 = load i64, ptr %slot51, align 8
  %p6980 = inttoptr i64 %v6979 to ptr
  store i64 %v6978, ptr %p6980, align 8, !alias.scope !3, !noalias !4
  br label %bb_i95
bb_i95:
  %v6981 = load i64, ptr %slot51, align 8
  %p6982 = inttoptr i64 %v6981 to ptr
  %ld6983 = load i64, ptr %p6982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6983, ptr %slot1287, align 8
  %v6984 = load i64, ptr %slot1287, align 8
  %v6985 = load i64, ptr %slot52, align 8
  %p6986 = inttoptr i64 %v6985 to ptr
  store i64 %v6984, ptr %p6986, align 8, !alias.scope !3, !noalias !4
  %v6987 = load i64, ptr %slot50, align 8
  %v6988 = load i64, ptr %slot58, align 8
  %p6989 = inttoptr i64 %v6987 to ptr
  %p6990 = inttoptr i64 %v6988 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6990, ptr %p6989, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v6991 = load i64, ptr %slot58, align 8
  %v6992 = load i64, ptr %slot53, align 8
  %p6993 = inttoptr i64 %v6992 to ptr
  store i64 %v6991, ptr %p6993, align 8, !alias.scope !3, !noalias !4
  %v6994 = load i64, ptr %slot49, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %ld6996 = load i64, ptr %p6995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6996, ptr %slot1288, align 8
  %v6997 = load i64, ptr %slot53, align 8
  %p6998 = inttoptr i64 %v6997 to ptr
  %ld6999 = load i64, ptr %p6998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6999, ptr %slot1289, align 8
  %v7000 = load i64, ptr %slot52, align 8
  %p7001 = inttoptr i64 %v7000 to ptr
  %ld7002 = load i64, ptr %p7001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7002, ptr %slot1290, align 8
  %v7003 = load i64, ptr %slot1288, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  %ld7005 = load i64, ptr %p7004, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7005, ptr %slot1291, align 8
  %v7006 = load i64, ptr %slot1290, align 8
  %v7007 = load i64, ptr %slot1291, align 8
  %cmp7008 = icmp ult i64 %v7006, %v7007
  %cv7009 = zext i1 %cmp7008 to i64
  store i64 %cv7009, ptr %slot1292, align 8
  %v7010 = load i64, ptr %slot1292, align 8
  %cond7011 = icmp ne i64 %v7010, 0
  br i1 %cond7011, label %bb_success1799, label %bb_failed1799
bb_failed1799:
  %v7012 = load i64, ptr %slot1, align 8
  %p7013 = inttoptr i64 %v7012 to ptr
  %v7014 = load i64, ptr %slot1290, align 8
  %v7015 = load i64, ptr %slot1291, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p7013, i64 %v7014, i64 %v7015) nomerge, !dbg !194
  unreachable
bb_success1799:
  %v7016 = load i64, ptr %slot53, align 8
  %p7017 = inttoptr i64 %v7016 to ptr
  %ld7018 = load i64, ptr %p7017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7018, ptr %slot1293, align 8
  %v7019 = load i64, ptr %slot64, align 8
  %v7020 = load i64, ptr %slot1288, align 8
  %v7021 = load i64, ptr %slot1290, align 8
  %v7022 = load i64, ptr %slot1293, align 8
  %call7023 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v7019, i64 %v7020, i64 %v7021, i64 %v7022) nomerge, !dbg !194
  store i32 %call7023, ptr %slot1294, align 8
  %v7024 = load i32, ptr %slot1294, align 8
  %cv7025 = zext i32 %v7024 to i64
  %cond7026 = icmp ne i64 %cv7025, 0
  br i1 %cond7026, label %bb_success1802, label %bb_failed1802
bb_failed1802:
  %v7027 = load i64, ptr %slot1, align 8
  %p7028 = inttoptr i64 %v7027 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7028) nomerge, !dbg !194
  unreachable
bb_success1802:
  %v7029 = load i64, ptr %slot52, align 8
  %p7030 = inttoptr i64 %v7029 to ptr
  store i64 0, ptr %p7030, align 8, !alias.scope !3, !noalias !4
  %v7031 = load i64, ptr %slot19, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  %ld7033 = load i32, ptr %p7032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7033, ptr %slot1295, align 8
  %v7034 = load i32, ptr %slot1295, align 8
  %cv7035 = zext i32 %v7034 to i64
  %cond7036 = icmp ne i64 %cv7035, 0
  br i1 %cond7036, label %bb_rcslotdrop1805, label %bb_rcslotdone1805
bb_rcslotdrop1805:
  %v7037 = load i64, ptr %slot19, align 8
  %p7038 = inttoptr i64 %v7037 to ptr
  store i32 0, ptr %p7038, align 4, !alias.scope !3, !noalias !4
  %v7039 = load i64, ptr %slot27, align 8
  store i64 %v7039, ptr %slot1296, align 8
  %v7040 = load i64, ptr %slot20, align 8
  %p7041 = inttoptr i64 %v7040 to ptr
  %ld7042 = load i32, ptr %p7041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7042, ptr %slot1297, align 8
  %v7043 = load i32, ptr %slot1297, align 8
  %op7044 = and i32 %v7043, 28
  store i32 %op7044, ptr %slot1298, align 8
  %v7045 = load i32, ptr %slot1298, align 8
  %cv7046 = zext i32 %v7045 to i64
  %cond7047 = icmp ne i64 %cv7046, 0
  br i1 %cond7047, label %bb_rcslotrole1805, label %bb_rcslotowner1805
bb_rcslotrole1805:
  %v7048 = load i64, ptr %slot64, align 8
  store i64 %v7048, ptr %slot1299, align 8
  %v7049 = load i64, ptr %slot1299, align 8
  %v7050 = load i64, ptr %slot1296, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7049, i64 %v7050) nomerge, !dbg !194
  br label %bb_rcslotdone1805
bb_rcslotowner1805:
  %v7051 = load i64, ptr %slot64, align 8
  store i64 %v7051, ptr %slot1300, align 8
  %v7052 = load i64, ptr %slot1300, align 8
  %v7053 = load i64, ptr %slot1296, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7052, i64 %v7053) nomerge, !dbg !194
  br label %bb_rcslotdone1805
bb_rcslotdone1805:
  %v7054 = load i64, ptr %slot33, align 8
  store i64 %v7054, ptr %slot1301, align 8
  %v7055 = load i64, ptr %slot1301, align 8
  %p7057 = inttoptr i64 %v7055 to ptr
  %gep7058 = getelementptr i8, ptr %p7057, i64 24
  %op7056 = ptrtoint ptr %gep7058 to i64
  store i64 %op7056, ptr %slot1302, align 8
  %v7059 = load i64, ptr %slot1302, align 8
  %p7060 = inttoptr i64 %v7059 to ptr
  %ld7061 = load i32, ptr %p7060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7061, ptr %slot1303, align 8
  %v7062 = load i32, ptr %slot1303, align 8
  %cv7063 = zext i32 %v7062 to i64
  %cond7064 = icmp ne i64 %cv7063, 0
  br i1 %cond7064, label %bb_rcsendactive1813, label %bb_rcsenddone1813
bb_rcsendactive1813:
  %v7065 = load i64, ptr %slot64, align 8
  %p7067 = inttoptr i64 %v7065 to ptr
  %gep7068 = getelementptr i8, ptr %p7067, i64 5640
  %op7066 = ptrtoint ptr %gep7068 to i64
  store i64 %op7066, ptr %slot1304, align 8
  %v7069 = load i64, ptr %slot1304, align 8
  %p7070 = inttoptr i64 %v7069 to ptr
  %ld7071 = load i64, ptr %p7070, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7071, ptr %slot1305, align 8
  %v7072 = load i64, ptr %slot1305, align 8
  %op7073 = add i64 %v7072, 248
  store i64 %op7073, ptr %slot1306, align 8
  %v7074 = load i64, ptr %slot1306, align 8
  %p7075 = inttoptr i64 %v7074 to ptr
  %ld7076 = load i64, ptr %p7075, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7076, ptr %slot1307, align 8
  %v7077 = load i64, ptr %slot1307, align 8
  %v7078 = load i64, ptr %slot1301, align 8
  %cmp7079 = icmp eq i64 %v7077, %v7078
  %cv7080 = zext i1 %cmp7079 to i32
  store i32 %cv7080, ptr %slot1308, align 8
  %v7081 = load i32, ptr %slot1308, align 8
  %cv7082 = zext i32 %v7081 to i64
  %cond7083 = icmp ne i64 %cv7082, 0
  br i1 %cond7083, label %bb_rcs1821, label %bb_rcsendslow1813
bb_rcs1821:
  %v7084 = load i64, ptr %slot1305, align 8
  %op7085 = add i64 %v7084, 200
  store i64 %op7085, ptr %slot1309, align 8
  %v7086 = load i64, ptr %slot1309, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %ld7088 = load i64, ptr %p7087, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7088, ptr %slot1310, align 8
  %v7089 = load i64, ptr %slot1310, align 8
  %cmp7090 = icmp eq i64 %v7089, 0
  %cv7091 = zext i1 %cmp7090 to i32
  store i32 %cv7091, ptr %slot1311, align 8
  %v7092 = load i32, ptr %slot1311, align 8
  %cv7093 = zext i32 %v7092 to i64
  %cond7094 = icmp ne i64 %cv7093, 0
  br i1 %cond7094, label %bb_rcs1825, label %bb_rcsendslow1813
bb_rcs1825:
  %v7095 = load i64, ptr %slot1301, align 8
  %p7097 = inttoptr i64 %v7095 to ptr
  %gep7098 = getelementptr i8, ptr %p7097, i64 16
  %op7096 = ptrtoint ptr %gep7098 to i64
  store i64 %op7096, ptr %slot1312, align 8
  %v7099 = load i64, ptr %slot1312, align 8
  %p7100 = inttoptr i64 %v7099 to ptr
  %ld7101 = load i64, ptr %p7100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7101, ptr %slot1313, align 8
  %v7102 = load i64, ptr %slot1313, align 8
  %cmp7103 = icmp ne i64 %v7102, 0
  %cv7104 = zext i1 %cmp7103 to i32
  store i32 %cv7104, ptr %slot1314, align 8
  %v7105 = load i32, ptr %slot1314, align 8
  %cv7106 = zext i32 %v7105 to i64
  %cond7107 = icmp ne i64 %cv7106, 0
  br i1 %cond7107, label %bb_rcsendnode1813, label %bb_rcsendunlink1813
bb_rcsendnode1813:
  %v7108 = load i64, ptr %slot1313, align 8
  %op7109 = add i64 %v7108, 0
  store i64 %op7109, ptr %slot1315, align 8
  %v7110 = load i64, ptr %slot1315, align 8
  %p7111 = inttoptr i64 %v7110 to ptr
  %ld7112 = load i64, ptr %p7111, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7112, ptr %slot1316, align 8
  %v7113 = load i64, ptr %slot1316, align 8
  %cmp7114 = icmp eq i64 %v7113, 0
  %cv7115 = zext i1 %cmp7114 to i32
  store i32 %cv7115, ptr %slot1317, align 8
  %v7116 = load i32, ptr %slot1317, align 8
  %cv7117 = zext i32 %v7116 to i64
  %cond7118 = icmp ne i64 %cv7117, 0
  br i1 %cond7118, label %bb_rcs1832, label %bb_rcsendslow1813
bb_rcs1832:
  %v7119 = load i64, ptr %slot1305, align 8
  %op7120 = add i64 %v7119, 264
  store i64 %op7120, ptr %slot1318, align 8
  %v7121 = load i64, ptr %slot1318, align 8
  %p7122 = inttoptr i64 %v7121 to ptr
  %ld7123 = load i64, ptr %p7122, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7123, ptr %slot1319, align 8
  %v7124 = load i64, ptr %slot1319, align 8
  %cmp7125 = icmp ult i64 %v7124, 32
  %cv7126 = zext i1 %cmp7125 to i32
  store i32 %cv7126, ptr %slot1320, align 8
  %v7127 = load i32, ptr %slot1320, align 8
  %cv7128 = zext i32 %v7127 to i64
  %cond7129 = icmp ne i64 %cv7128, 0
  br i1 %cond7129, label %bb_rcs1836, label %bb_rcsendslow1813
bb_rcs1836:
  %v7130 = load i64, ptr %slot1313, align 8
  %op7131 = add i64 %v7130, 8
  store i64 %op7131, ptr %slot1321, align 8
  %v7132 = load i64, ptr %slot1321, align 8
  %p7133 = inttoptr i64 %v7132 to ptr
  %ld7134 = load i64, ptr %p7133, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7134, ptr %slot1322, align 8
  %v7135 = load i64, ptr %slot1322, align 8
  %cmp7136 = icmp ne i64 %v7135, 0
  %cv7137 = zext i1 %cmp7136 to i32
  store i32 %cv7137, ptr %slot1323, align 8
  %v7138 = load i32, ptr %slot1323, align 8
  %cv7139 = zext i32 %v7138 to i64
  %cond7140 = icmp ne i64 %cv7139, 0
  br i1 %cond7140, label %bb_rcs1840, label %bb_rcsendslow1813
bb_rcs1840:
  %v7141 = load i64, ptr %slot1322, align 8
  %op7142 = sub i64 %v7141, 16
  store i64 %op7142, ptr %slot1324, align 8
  %v7143 = load i64, ptr %slot1322, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  %rgep7145 = getelementptr i8, ptr %p7144, i64 -16
  %ld7146 = load i64, ptr %rgep7145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7146, ptr %slot1325, align 8
  %v7147 = load i64, ptr %slot1325, align 8
  %op7148 = and i64 %v7147, 4611686018427387907
  store i64 %op7148, ptr %slot1326, align 8
  %v7149 = load i64, ptr %slot1326, align 8
  %cmp7150 = icmp eq i64 %v7149, 0
  %cv7151 = zext i1 %cmp7150 to i32
  store i32 %cv7151, ptr %slot1327, align 8
  %v7152 = load i32, ptr %slot1327, align 8
  %cv7153 = zext i32 %v7152 to i64
  %cond7154 = icmp ne i64 %cv7153, 0
  br i1 %cond7154, label %bb_rcs1845, label %bb_rcsendslow1813
bb_rcs1845:
  %v7155 = load i64, ptr %slot1322, align 8
  %op7156 = sub i64 %v7155, 24
  store i64 %op7156, ptr %slot1328, align 8
  %v7157 = load i64, ptr %slot1322, align 8
  %p7158 = inttoptr i64 %v7157 to ptr
  %rgep7159 = getelementptr i8, ptr %p7158, i64 -24
  %ld7160 = load i64, ptr %rgep7159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7160, ptr %slot1329, align 8
  %v7161 = load i64, ptr %slot1329, align 8
  %cmp7162 = icmp ne i64 %v7161, 0
  %cv7163 = zext i1 %cmp7162 to i32
  store i32 %cv7163, ptr %slot1330, align 8
  %v7164 = load i32, ptr %slot1330, align 8
  %cv7165 = zext i32 %v7164 to i64
  %cond7166 = icmp ne i64 %cv7165, 0
  br i1 %cond7166, label %bb_rcs1849, label %bb_rcsendslow1813
bb_rcs1849:
  %v7167 = load i64, ptr %slot1322, align 8
  %op7168 = sub i64 %v7167, 32
  store i64 %op7168, ptr %slot1331, align 8
  %v7169 = load i64, ptr %slot1322, align 8
  %p7170 = inttoptr i64 %v7169 to ptr
  %rgep7171 = getelementptr i8, ptr %p7170, i64 -32
  %ld7172 = load i64, ptr %rgep7171, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7172, ptr %slot1332, align 8
  %v7173 = load i64, ptr %slot1329, align 8
  %cmp7174 = icmp ugt i64 %v7173, 1
  %cv7175 = zext i1 %cmp7174 to i32
  store i32 %cv7175, ptr %slot1333, align 8
  %v7176 = load i64, ptr %slot1332, align 8
  %cmp7177 = icmp ne i64 %v7176, 0
  %cv7178 = zext i1 %cmp7177 to i32
  store i32 %cv7178, ptr %slot1334, align 8
  %v7179 = load i32, ptr %slot1333, align 8
  %v7180 = load i32, ptr %slot1334, align 8
  %op7181 = or i32 %v7179, %v7180
  store i32 %op7181, ptr %slot1335, align 8
  %v7182 = load i32, ptr %slot1335, align 8
  %cv7183 = zext i32 %v7182 to i64
  %cond7184 = icmp ne i64 %cv7183, 0
  br i1 %cond7184, label %bb_rcs1855, label %bb_rcsendslow1813
bb_rcs1855:
  %v7185 = load i64, ptr %slot1313, align 8
  %op7186 = add i64 %v7185, 32
  store i64 %op7186, ptr %slot1336, align 8
  %v7187 = load i64, ptr %slot1336, align 8
  %p7188 = inttoptr i64 %v7187 to ptr
  %ld7189 = load i64, ptr %p7188, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7189, ptr %slot1337, align 8
  %v7190 = load i64, ptr %slot1337, align 8
  %cmp7191 = icmp ne i64 %v7190, 0
  %cv7192 = zext i1 %cmp7191 to i32
  store i32 %cv7192, ptr %slot1338, align 8
  %v7193 = load i32, ptr %slot1338, align 8
  %cv7194 = zext i32 %v7193 to i64
  %cond7195 = icmp ne i64 %cv7194, 0
  br i1 %cond7195, label %bb_rcsendbacking1813, label %bb_rcsendcommit1813
bb_rcsendbacking1813:
  %v7196 = load i64, ptr %slot1337, align 8
  %op7197 = sub i64 %v7196, 16
  store i64 %op7197, ptr %slot1339, align 8
  %v7198 = load i64, ptr %slot1337, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  %rgep7200 = getelementptr i8, ptr %p7199, i64 -16
  %ld7201 = load i64, ptr %rgep7200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7201, ptr %slot1340, align 8
  %v7202 = load i64, ptr %slot1340, align 8
  %op7203 = and i64 %v7202, 4611686018427387907
  store i64 %op7203, ptr %slot1341, align 8
  %v7204 = load i64, ptr %slot1341, align 8
  %cmp7205 = icmp eq i64 %v7204, 0
  %cv7206 = zext i1 %cmp7205 to i32
  store i32 %cv7206, ptr %slot1342, align 8
  %v7207 = load i32, ptr %slot1342, align 8
  %cv7208 = zext i32 %v7207 to i64
  %cond7209 = icmp ne i64 %cv7208, 0
  br i1 %cond7209, label %bb_rcs1863, label %bb_rcsendslow1813
bb_rcs1863:
  %v7210 = load i64, ptr %slot1337, align 8
  %op7211 = sub i64 %v7210, 24
  store i64 %op7211, ptr %slot1343, align 8
  %v7212 = load i64, ptr %slot1337, align 8
  %p7213 = inttoptr i64 %v7212 to ptr
  %rgep7214 = getelementptr i8, ptr %p7213, i64 -24
  %ld7215 = load i64, ptr %rgep7214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7215, ptr %slot1344, align 8
  %v7216 = load i64, ptr %slot1344, align 8
  %cmp7217 = icmp ne i64 %v7216, 0
  %cv7218 = zext i1 %cmp7217 to i32
  store i32 %cv7218, ptr %slot1345, align 8
  %v7219 = load i32, ptr %slot1345, align 8
  %cv7220 = zext i32 %v7219 to i64
  %cond7221 = icmp ne i64 %cv7220, 0
  br i1 %cond7221, label %bb_rcs1867, label %bb_rcsendslow1813
bb_rcs1867:
  %v7222 = load i64, ptr %slot1337, align 8
  %op7223 = sub i64 %v7222, 32
  store i64 %op7223, ptr %slot1346, align 8
  %v7224 = load i64, ptr %slot1337, align 8
  %p7225 = inttoptr i64 %v7224 to ptr
  %rgep7226 = getelementptr i8, ptr %p7225, i64 -32
  %ld7227 = load i64, ptr %rgep7226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7227, ptr %slot1347, align 8
  %v7228 = load i64, ptr %slot1344, align 8
  %cmp7229 = icmp ugt i64 %v7228, 1
  %cv7230 = zext i1 %cmp7229 to i32
  store i32 %cv7230, ptr %slot1348, align 8
  %v7231 = load i64, ptr %slot1347, align 8
  %cmp7232 = icmp ne i64 %v7231, 0
  %cv7233 = zext i1 %cmp7232 to i32
  store i32 %cv7233, ptr %slot1349, align 8
  %v7234 = load i32, ptr %slot1348, align 8
  %v7235 = load i32, ptr %slot1349, align 8
  %op7236 = or i32 %v7234, %v7235
  store i32 %op7236, ptr %slot1350, align 8
  %v7237 = load i32, ptr %slot1350, align 8
  %cv7238 = zext i32 %v7237 to i64
  %cond7239 = icmp ne i64 %cv7238, 0
  br i1 %cond7239, label %bb_rcs1873, label %bb_rcsendslow1813
bb_rcs1873:
  br label %bb_rcsendcommit1813
bb_rcsendcommit1813:
  %v7240 = load i64, ptr %slot1313, align 8
  %op7241 = add i64 %v7240, 24
  store i64 %op7241, ptr %slot1351, align 8
  %v7242 = load i64, ptr %slot1351, align 8
  %p7243 = inttoptr i64 %v7242 to ptr
  %ld7244 = load i32, ptr %p7243, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld7244, ptr %slot1352, align 8
  %v7245 = load i32, ptr %slot1352, align 8
  %cv7246 = zext i32 %v7245 to i64
  %cond7247 = icmp ne i64 %cv7246, 0
  br i1 %cond7247, label %bb_rcsendrestore1813, label %bb_rcsendreturned1813
bb_rcsendrestore1813:
  %v7248 = load i64, ptr %slot1313, align 8
  %op7249 = add i64 %v7248, 16
  store i64 %op7249, ptr %slot1353, align 8
  %v7250 = load i64, ptr %slot1353, align 8
  %p7251 = inttoptr i64 %v7250 to ptr
  %ld7252 = load i64, ptr %p7251, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7252, ptr %slot1354, align 8
  %v7253 = load i64, ptr %slot1325, align 8
  %op7254 = and i64 %v7253, 17293822569102704639
  store i64 %op7254, ptr %slot1355, align 8
  %v7255 = load i64, ptr %slot1355, align 8
  %v7256 = load i64, ptr %slot1354, align 8
  %op7257 = or i64 %v7255, %v7256
  store i64 %op7257, ptr %slot1356, align 8
  %v7258 = load i64, ptr %slot1322, align 8
  %op7259 = sub i64 %v7258, 16
  store i64 %op7259, ptr %slot1357, align 8
  %v7260 = load i64, ptr %slot1356, align 8
  %v7261 = load i64, ptr %slot1322, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  %rgep7263 = getelementptr i8, ptr %p7262, i64 -16
  store i64 %v7260, ptr %rgep7263, align 8, !alias.scope !9, !noalias !10
  %v7264 = load i64, ptr %slot1301, align 8
  %p7266 = inttoptr i64 %v7264 to ptr
  %gep7267 = getelementptr i8, ptr %p7266, i64 16
  %op7265 = ptrtoint ptr %gep7267 to i64
  store i64 %op7265, ptr %slot1358, align 8
  br label %bb_rcsendreturned1813
bb_rcsendreturned1813:
  %v7268 = load i64, ptr %slot1358, align 8
  %p7269 = inttoptr i64 %v7268 to ptr
  store i64 0, ptr %p7269, align 8, !alias.scope !3, !noalias !4
  %v7270 = load i64, ptr %slot1305, align 8
  %op7271 = add i64 %v7270, 256
  store i64 %op7271, ptr %slot1359, align 8
  %v7272 = load i64, ptr %slot1359, align 8
  %p7273 = inttoptr i64 %v7272 to ptr
  %ld7274 = load i64, ptr %p7273, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7274, ptr %slot1360, align 8
  %v7275 = load i64, ptr %slot1313, align 8
  %op7276 = add i64 %v7275, 0
  store i64 %op7276, ptr %slot1361, align 8
  %v7277 = load i64, ptr %slot1360, align 8
  %v7278 = load i64, ptr %slot1361, align 8
  %p7279 = inttoptr i64 %v7278 to ptr
  store i64 %v7277, ptr %p7279, align 8, !alias.scope !9999998, !noalias !9999999
  %v7280 = load i64, ptr %slot1305, align 8
  %op7281 = add i64 %v7280, 256
  store i64 %op7281, ptr %slot1362, align 8
  %v7282 = load i64, ptr %slot1313, align 8
  %v7283 = load i64, ptr %slot1362, align 8
  %p7284 = inttoptr i64 %v7283 to ptr
  store i64 %v7282, ptr %p7284, align 8, !alias.scope !9999998, !noalias !9999999
  %v7285 = load i64, ptr %slot1305, align 8
  %op7286 = add i64 %v7285, 264
  store i64 %op7286, ptr %slot1363, align 8
  %v7287 = load i64, ptr %slot1363, align 8
  %p7288 = inttoptr i64 %v7287 to ptr
  %ld7289 = load i64, ptr %p7288, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7289, ptr %slot1364, align 8
  %v7290 = load i64, ptr %slot1364, align 8
  %op7291 = add i64 %v7290, 1
  store i64 %op7291, ptr %slot1365, align 8
  %v7292 = load i64, ptr %slot1365, align 8
  %v7293 = load i64, ptr %slot1363, align 8
  %p7294 = inttoptr i64 %v7293 to ptr
  store i64 %v7292, ptr %p7294, align 8, !alias.scope !9999998, !noalias !9999999
  %v7295 = load i64, ptr %slot64, align 8
  %p7297 = inttoptr i64 %v7295 to ptr
  %gep7298 = getelementptr i8, ptr %p7297, i64 24
  %op7296 = ptrtoint ptr %gep7298 to i64
  store i64 %op7296, ptr %slot1366, align 8
  %v7299 = load i64, ptr %slot1366, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  %ld7301 = load i64, ptr %p7300, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7301, ptr %slot1367, align 8
  %v7302 = load i64, ptr %slot1367, align 8
  %op7303 = add i64 %v7302, 18446744073709551576
  store i64 %op7303, ptr %slot1368, align 8
  %v7304 = load i64, ptr %slot1368, align 8
  %v7305 = load i64, ptr %slot1366, align 8
  %p7306 = inttoptr i64 %v7305 to ptr
  store i64 %v7304, ptr %p7306, align 8, !alias.scope !9999998, !noalias !9999999
  %v7307 = load i64, ptr %slot1305, align 8
  %op7308 = add i64 %v7307, 48
  store i64 %op7308, ptr %slot1369, align 8
  %v7309 = load i64, ptr %slot1369, align 8
  %p7310 = inttoptr i64 %v7309 to ptr
  %ld7311 = load i64, ptr %p7310, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7311, ptr %slot1370, align 8
  %v7312 = load i64, ptr %slot1370, align 8
  %op7313 = add i64 %v7312, 18446744073709551576
  store i64 %op7313, ptr %slot1371, align 8
  %v7314 = load i64, ptr %slot1371, align 8
  %v7315 = load i64, ptr %slot1369, align 8
  %p7316 = inttoptr i64 %v7315 to ptr
  store i64 %v7314, ptr %p7316, align 8, !alias.scope !9999998, !noalias !9999999
  %v7317 = load i64, ptr %slot1337, align 8
  %cmp7318 = icmp ne i64 %v7317, 0
  %cv7319 = zext i1 %cmp7318 to i32
  store i32 %cv7319, ptr %slot1372, align 8
  %v7320 = load i32, ptr %slot1372, align 8
  %cv7321 = zext i32 %v7320 to i64
  %cond7322 = icmp ne i64 %cv7321, 0
  br i1 %cond7322, label %bb_rcsenddropbacking1813, label %bb_rcsenddroppayload1813
bb_rcsenddropbacking1813:
  %v7323 = load i64, ptr %slot1337, align 8
  %op7324 = sub i64 %v7323, 24
  store i64 %op7324, ptr %slot1373, align 8
  %v7325 = load i64, ptr %slot1337, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  %rgep7327 = getelementptr i8, ptr %p7326, i64 -24
  %ld7328 = load i64, ptr %rgep7327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7328, ptr %slot1374, align 8
  %v7329 = load i64, ptr %slot1374, align 8
  %op7330 = add i64 %v7329, 18446744073709551615
  store i64 %op7330, ptr %slot1375, align 8
  %v7331 = load i64, ptr %slot1375, align 8
  %v7332 = load i64, ptr %slot1337, align 8
  %p7333 = inttoptr i64 %v7332 to ptr
  %rgep7334 = getelementptr i8, ptr %p7333, i64 -24
  store i64 %v7331, ptr %rgep7334, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1813
bb_rcsenddroppayload1813:
  %v7335 = load i64, ptr %slot1322, align 8
  %op7336 = sub i64 %v7335, 24
  store i64 %op7336, ptr %slot1376, align 8
  %v7337 = load i64, ptr %slot1322, align 8
  %p7338 = inttoptr i64 %v7337 to ptr
  %rgep7339 = getelementptr i8, ptr %p7338, i64 -24
  %ld7340 = load i64, ptr %rgep7339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7340, ptr %slot1377, align 8
  %v7341 = load i64, ptr %slot1377, align 8
  %op7342 = add i64 %v7341, 18446744073709551615
  store i64 %op7342, ptr %slot1378, align 8
  %v7343 = load i64, ptr %slot1378, align 8
  %v7344 = load i64, ptr %slot1322, align 8
  %p7345 = inttoptr i64 %v7344 to ptr
  %rgep7346 = getelementptr i8, ptr %p7345, i64 -24
  store i64 %v7343, ptr %rgep7346, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1813
bb_rcsendunlink1813:
  %v7347 = load i64, ptr %slot1301, align 8
  %p7349 = inttoptr i64 %v7347 to ptr
  %gep7350 = getelementptr i8, ptr %p7349, i64 8
  %op7348 = ptrtoint ptr %gep7350 to i64
  store i64 %op7348, ptr %slot1379, align 8
  %v7351 = load i64, ptr %slot1379, align 8
  %p7352 = inttoptr i64 %v7351 to ptr
  %ld7353 = load i64, ptr %p7352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7353, ptr %slot1380, align 8
  %v7354 = load i64, ptr %slot1305, align 8
  %op7355 = add i64 %v7354, 248
  store i64 %op7355, ptr %slot1381, align 8
  %v7356 = load i64, ptr %slot1380, align 8
  %v7357 = load i64, ptr %slot1381, align 8
  %p7358 = inttoptr i64 %v7357 to ptr
  store i64 %v7356, ptr %p7358, align 8, !alias.scope !9999998, !noalias !9999999
  %v7359 = load i64, ptr %slot1301, align 8
  %p7361 = inttoptr i64 %v7359 to ptr
  %gep7362 = getelementptr i8, ptr %p7361, i64 24
  %op7360 = ptrtoint ptr %gep7362 to i64
  store i64 %op7360, ptr %slot1382, align 8
  %v7363 = load i64, ptr %slot1301, align 8
  %p7365 = inttoptr i64 %v7363 to ptr
  %gep7366 = getelementptr i8, ptr %p7365, i64 8
  %op7364 = ptrtoint ptr %gep7366 to i64
  store i64 %op7364, ptr %slot1383, align 8
  %v7367 = load i64, ptr %slot1382, align 8
  %p7368 = inttoptr i64 %v7367 to ptr
  store i32 0, ptr %p7368, align 4, !alias.scope !3, !noalias !4
  %v7369 = load i64, ptr %slot1383, align 8
  %p7370 = inttoptr i64 %v7369 to ptr
  store i64 0, ptr %p7370, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1813
bb_rcsendslow1813:
  %v7371 = load i64, ptr %slot1, align 8
  %p7372 = inttoptr i64 %v7371 to ptr
  %v7373 = load i64, ptr %slot1301, align 8
  %p7374 = inttoptr i64 %v7373 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p7372, ptr %p7374) nomerge, !dbg !194
  br label %bb_rcsenddone1813
bb_rcsenddone1813:
  %v7375 = load i64, ptr %slot52, align 8
  %p7376 = inttoptr i64 %v7375 to ptr
  store i64 0, ptr %p7376, align 8, !alias.scope !3, !noalias !4
  %v7377 = load i64, ptr %slot52, align 8
  %p7378 = inttoptr i64 %v7377 to ptr
  %ld7379 = load i64, ptr %p7378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7379, ptr %slot1384, align 8
  %v7380 = load i64, ptr %slot31, align 8
  %p7382 = inttoptr i64 %v7380 to ptr
  %gep7383 = getelementptr i8, ptr %p7382, i64 24
  %op7381 = ptrtoint ptr %gep7383 to i64
  store i64 %op7381, ptr %slot1385, align 8
  %v7384 = load i64, ptr %slot1385, align 8
  %p7385 = inttoptr i64 %v7384 to ptr
  %ld7386 = load i32, ptr %p7385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7386, ptr %slot1386, align 8
  %v7387 = load i64, ptr %slot33, align 8
  %p7389 = inttoptr i64 %v7387 to ptr
  %gep7390 = getelementptr i8, ptr %p7389, i64 24
  %op7388 = ptrtoint ptr %gep7390 to i64
  store i64 %op7388, ptr %slot1387, align 8
  %v7391 = load i64, ptr %slot1387, align 8
  %p7392 = inttoptr i64 %v7391 to ptr
  %ld7393 = load i32, ptr %p7392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7393, ptr %slot1388, align 8
  %v7394 = load i32, ptr %slot1386, align 8
  %v7395 = load i32, ptr %slot1388, align 8
  %op7396 = or i32 %v7394, %v7395
  store i32 %op7396, ptr %slot1389, align 8
  %v7397 = load i32, ptr %slot1389, align 8
  %cv7398 = zext i32 %v7397 to i64
  %cond7399 = icmp ne i64 %cv7398, 0
  br i1 %cond7399, label %bb_rcscopesopen1913, label %bb_rcscopesclosed1913
bb_rcscopesopen1913:
  %v7400 = load i64, ptr %slot35, align 8
  %p7402 = inttoptr i64 %v7400 to ptr
  %gep7403 = getelementptr i8, ptr %p7402, i64 0
  %op7401 = ptrtoint ptr %gep7403 to i64
  store i64 %op7401, ptr %slot1390, align 8
  %v7404 = load i64, ptr %slot31, align 8
  %v7405 = load i64, ptr %slot1390, align 8
  %p7406 = inttoptr i64 %v7405 to ptr
  store i64 %v7404, ptr %p7406, align 8, !alias.scope !3, !noalias !4
  %v7407 = load i64, ptr %slot35, align 8
  %p7409 = inttoptr i64 %v7407 to ptr
  %gep7410 = getelementptr i8, ptr %p7409, i64 8
  %op7408 = ptrtoint ptr %gep7410 to i64
  store i64 %op7408, ptr %slot1391, align 8
  %v7411 = load i64, ptr %slot33, align 8
  %v7412 = load i64, ptr %slot1391, align 8
  %p7413 = inttoptr i64 %v7412 to ptr
  store i64 %v7411, ptr %p7413, align 8, !alias.scope !3, !noalias !4
  %v7414 = load i64, ptr %slot1, align 8
  %p7415 = inttoptr i64 %v7414 to ptr
  %v7416 = load i64, ptr %slot35, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7415, ptr %p7417, i64 2) nomerge, !dbg !196
  br label %bb_rcscopesclosed1913
bb_rcscopesclosed1913:
  %v7418 = load i64, ptr %slot17, align 8
  %p7419 = inttoptr i64 %v7418 to ptr
  %ld7420 = load i32, ptr %p7419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7420, ptr %slot1392, align 8
  %v7421 = load i32, ptr %slot1392, align 8
  %cv7422 = zext i32 %v7421 to i64
  %cond7423 = icmp ne i64 %cv7422, 0
  br i1 %cond7423, label %bb_rcslotdrop1918, label %bb_rcslotdone1918
bb_rcslotdrop1918:
  %v7424 = load i64, ptr %slot17, align 8
  %p7425 = inttoptr i64 %v7424 to ptr
  store i32 0, ptr %p7425, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1918
bb_rcslotdone1918:
  %v7426 = load i64, ptr %slot15, align 8
  %p7427 = inttoptr i64 %v7426 to ptr
  %ld7428 = load i32, ptr %p7427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7428, ptr %slot1393, align 8
  %v7429 = load i32, ptr %slot1393, align 8
  %cv7430 = zext i32 %v7429 to i64
  %cond7431 = icmp ne i64 %cv7430, 0
  br i1 %cond7431, label %bb_rcslotdrop1921, label %bb_rcslotdone1921
bb_rcslotdrop1921:
  %v7432 = load i64, ptr %slot15, align 8
  %p7433 = inttoptr i64 %v7432 to ptr
  store i32 0, ptr %p7433, align 4, !alias.scope !3, !noalias !4
  %v7434 = load i64, ptr %slot50, align 8
  store i64 %v7434, ptr %slot1394, align 8
  %v7435 = load i64, ptr %slot16, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  %ld7437 = load i32, ptr %p7436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7437, ptr %slot1395, align 8
  %v7438 = load i32, ptr %slot1395, align 8
  %op7439 = and i32 %v7438, 28
  store i32 %op7439, ptr %slot1396, align 8
  %v7440 = load i32, ptr %slot1396, align 8
  %cv7441 = zext i32 %v7440 to i64
  %cond7442 = icmp ne i64 %cv7441, 0
  br i1 %cond7442, label %bb_rcslotrole1921, label %bb_rcslotowner1921
bb_rcslotrole1921:
  %v7443 = load i64, ptr %slot64, align 8
  store i64 %v7443, ptr %slot1397, align 8
  %v7444 = load i64, ptr %slot1397, align 8
  %v7445 = load i64, ptr %slot1394, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7444, i64 %v7445) nomerge, !dbg !196
  br label %bb_rcslotdone1921
bb_rcslotowner1921:
  %v7446 = load i64, ptr %slot64, align 8
  store i64 %v7446, ptr %slot1398, align 8
  %v7447 = load i64, ptr %slot1398, align 8
  %v7448 = load i64, ptr %slot1394, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7447, i64 %v7448) nomerge, !dbg !196
  br label %bb_rcslotdone1921
bb_rcslotdone1921:
  %v7449 = load i64, ptr %slot13, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  %ld7451 = load i32, ptr %p7450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7451, ptr %slot1399, align 8
  %v7452 = load i32, ptr %slot1399, align 8
  %cv7453 = zext i32 %v7452 to i64
  %cond7454 = icmp ne i64 %cv7453, 0
  br i1 %cond7454, label %bb_rcslotdrop1967, label %bb_rcslotdone1967
bb_rcslotdrop1967:
  %v7455 = load i64, ptr %slot13, align 8
  %p7456 = inttoptr i64 %v7455 to ptr
  store i32 0, ptr %p7456, align 4, !alias.scope !3, !noalias !4
  %v7457 = load i64, ptr %slot47, align 8
  store i64 %v7457, ptr %slot1400, align 8
  %v7458 = load i64, ptr %slot14, align 8
  %p7459 = inttoptr i64 %v7458 to ptr
  %ld7460 = load i32, ptr %p7459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7460, ptr %slot1401, align 8
  %v7461 = load i32, ptr %slot1401, align 8
  %op7462 = and i32 %v7461, 28
  store i32 %op7462, ptr %slot1402, align 8
  %v7463 = load i32, ptr %slot1402, align 8
  %cv7464 = zext i32 %v7463 to i64
  %cond7465 = icmp ne i64 %cv7464, 0
  br i1 %cond7465, label %bb_rcslotrole1967, label %bb_rcslotowner1967
bb_rcslotrole1967:
  %v7466 = load i64, ptr %slot64, align 8
  store i64 %v7466, ptr %slot1403, align 8
  %v7467 = load i64, ptr %slot1403, align 8
  %v7468 = load i64, ptr %slot1400, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7467, i64 %v7468) nomerge, !dbg !196
  br label %bb_rcslotdone1967
bb_rcslotowner1967:
  %v7469 = load i64, ptr %slot64, align 8
  store i64 %v7469, ptr %slot1404, align 8
  %v7470 = load i64, ptr %slot1404, align 8
  %v7471 = load i64, ptr %slot1400, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7470, i64 %v7471) nomerge, !dbg !196
  br label %bb_rcslotdone1967
bb_rcslotdone1967:
  %v7472 = load i64, ptr %slot11, align 8
  %p7473 = inttoptr i64 %v7472 to ptr
  %ld7474 = load i32, ptr %p7473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7474, ptr %slot1405, align 8
  %v7475 = load i32, ptr %slot1405, align 8
  %cv7476 = zext i32 %v7475 to i64
  %cond7477 = icmp ne i64 %cv7476, 0
  br i1 %cond7477, label %bb_rcslotdrop2013, label %bb_rcslotdone2013
bb_rcslotdrop2013:
  %v7478 = load i64, ptr %slot11, align 8
  %p7479 = inttoptr i64 %v7478 to ptr
  store i32 0, ptr %p7479, align 4, !alias.scope !3, !noalias !4
  %v7480 = load i64, ptr %slot45, align 8
  store i64 %v7480, ptr %slot1406, align 8
  %v7481 = load i64, ptr %slot12, align 8
  %p7482 = inttoptr i64 %v7481 to ptr
  %ld7483 = load i32, ptr %p7482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7483, ptr %slot1407, align 8
  %v7484 = load i32, ptr %slot1407, align 8
  %op7485 = and i32 %v7484, 28
  store i32 %op7485, ptr %slot1408, align 8
  %v7486 = load i32, ptr %slot1408, align 8
  %cv7487 = zext i32 %v7486 to i64
  %cond7488 = icmp ne i64 %cv7487, 0
  br i1 %cond7488, label %bb_rcslotrole2013, label %bb_rcslotowner2013
bb_rcslotrole2013:
  %v7489 = load i64, ptr %slot64, align 8
  store i64 %v7489, ptr %slot1409, align 8
  %v7490 = load i64, ptr %slot1409, align 8
  %v7491 = load i64, ptr %slot1406, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v7490, i64 %v7491) nomerge, !dbg !196
  br label %bb_rcslotdone2013
bb_rcslotowner2013:
  %v7492 = load i64, ptr %slot64, align 8
  store i64 %v7492, ptr %slot1410, align 8
  %v7493 = load i64, ptr %slot1410, align 8
  %v7494 = load i64, ptr %slot1406, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v7493, i64 %v7494) nomerge, !dbg !196
  br label %bb_rcslotdone2013
bb_rcslotdone2013:
  %v7495 = load i64, ptr %slot9, align 8
  %p7496 = inttoptr i64 %v7495 to ptr
  %ld7497 = load i32, ptr %p7496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7497, ptr %slot1411, align 8
  %v7498 = load i32, ptr %slot1411, align 8
  %cv7499 = zext i32 %v7498 to i64
  %cond7500 = icmp ne i64 %cv7499, 0
  br i1 %cond7500, label %bb_rcslotdrop2022, label %bb_rcslotdone2022
bb_rcslotdrop2022:
  %v7501 = load i64, ptr %slot9, align 8
  %p7502 = inttoptr i64 %v7501 to ptr
  store i32 0, ptr %p7502, align 4, !alias.scope !3, !noalias !4
  %v7503 = load i64, ptr %slot44, align 8
  store i64 %v7503, ptr %slot1412, align 8
  %v7504 = load i64, ptr %slot10, align 8
  %p7505 = inttoptr i64 %v7504 to ptr
  %ld7506 = load i32, ptr %p7505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7506, ptr %slot1413, align 8
  %v7507 = load i32, ptr %slot1413, align 8
  %op7508 = and i32 %v7507, 28
  store i32 %op7508, ptr %slot1414, align 8
  %v7509 = load i32, ptr %slot1414, align 8
  %cv7510 = zext i32 %v7509 to i64
  %cond7511 = icmp ne i64 %cv7510, 0
  br i1 %cond7511, label %bb_rcslotrole2022, label %bb_rcslotowner2022
bb_rcslotrole2022:
  %v7512 = load i64, ptr %slot64, align 8
  store i64 %v7512, ptr %slot1415, align 8
  %v7513 = load i64, ptr %slot1415, align 8
  %v7514 = load i64, ptr %slot1412, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7513, i64 %v7514) nomerge, !dbg !196
  br label %bb_rcslotdone2022
bb_rcslotowner2022:
  %v7515 = load i64, ptr %slot64, align 8
  store i64 %v7515, ptr %slot1416, align 8
  %v7516 = load i64, ptr %slot1416, align 8
  %v7517 = load i64, ptr %slot1412, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7516, i64 %v7517) nomerge, !dbg !196
  br label %bb_rcslotdone2022
bb_rcslotdone2022:
  %v7518 = load i64, ptr %slot7, align 8
  %p7519 = inttoptr i64 %v7518 to ptr
  %ld7520 = load i32, ptr %p7519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7520, ptr %slot1417, align 8
  %v7521 = load i32, ptr %slot1417, align 8
  %cv7522 = zext i32 %v7521 to i64
  %cond7523 = icmp ne i64 %cv7522, 0
  br i1 %cond7523, label %bb_rcslotdrop2031, label %bb_rcslotdone2031
bb_rcslotdrop2031:
  %v7524 = load i64, ptr %slot7, align 8
  %p7525 = inttoptr i64 %v7524 to ptr
  store i32 0, ptr %p7525, align 4, !alias.scope !3, !noalias !4
  %v7526 = load i64, ptr %slot43, align 8
  store i64 %v7526, ptr %slot1418, align 8
  %v7527 = load i64, ptr %slot8, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  %ld7529 = load i32, ptr %p7528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7529, ptr %slot1419, align 8
  %v7530 = load i32, ptr %slot1419, align 8
  %op7531 = and i32 %v7530, 28
  store i32 %op7531, ptr %slot1420, align 8
  %v7532 = load i32, ptr %slot1420, align 8
  %cv7533 = zext i32 %v7532 to i64
  %cond7534 = icmp ne i64 %cv7533, 0
  br i1 %cond7534, label %bb_rcslotrole2031, label %bb_rcslotowner2031
bb_rcslotrole2031:
  %v7535 = load i64, ptr %slot64, align 8
  store i64 %v7535, ptr %slot1421, align 8
  %v7536 = load i64, ptr %slot1421, align 8
  %v7537 = load i64, ptr %slot1418, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7536, i64 %v7537) nomerge, !dbg !196
  br label %bb_rcslotdone2031
bb_rcslotowner2031:
  %v7538 = load i64, ptr %slot64, align 8
  store i64 %v7538, ptr %slot1422, align 8
  %v7539 = load i64, ptr %slot1422, align 8
  %v7540 = load i64, ptr %slot1418, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7539, i64 %v7540) nomerge, !dbg !196
  br label %bb_rcslotdone2031
bb_rcslotdone2031:
  %v7541 = load i64, ptr %slot5, align 8
  %p7542 = inttoptr i64 %v7541 to ptr
  %ld7543 = load i32, ptr %p7542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7543, ptr %slot1423, align 8
  %v7544 = load i32, ptr %slot1423, align 8
  %cv7545 = zext i32 %v7544 to i64
  %cond7546 = icmp ne i64 %cv7545, 0
  br i1 %cond7546, label %bb_rcslotdrop2114, label %bb_rcslotdone2114
bb_rcslotdrop2114:
  %v7547 = load i64, ptr %slot5, align 8
  %p7548 = inttoptr i64 %v7547 to ptr
  store i32 0, ptr %p7548, align 4, !alias.scope !3, !noalias !4
  %v7549 = load i64, ptr %slot38, align 8
  store i64 %v7549, ptr %slot1424, align 8
  %v7550 = load i64, ptr %slot6, align 8
  %p7551 = inttoptr i64 %v7550 to ptr
  %ld7552 = load i32, ptr %p7551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7552, ptr %slot1425, align 8
  %v7553 = load i32, ptr %slot1425, align 8
  %op7554 = and i32 %v7553, 28
  store i32 %op7554, ptr %slot1426, align 8
  %v7555 = load i32, ptr %slot1426, align 8
  %cv7556 = zext i32 %v7555 to i64
  %cond7557 = icmp ne i64 %cv7556, 0
  br i1 %cond7557, label %bb_rcslotrole2114, label %bb_rcslotowner2114
bb_rcslotrole2114:
  %v7558 = load i64, ptr %slot64, align 8
  store i64 %v7558, ptr %slot1427, align 8
  %v7559 = load i64, ptr %slot1427, align 8
  %v7560 = load i64, ptr %slot1424, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v7559, i64 %v7560) nomerge, !dbg !196
  br label %bb_rcslotdone2114
bb_rcslotowner2114:
  %v7561 = load i64, ptr %slot64, align 8
  store i64 %v7561, ptr %slot1428, align 8
  %v7562 = load i64, ptr %slot1428, align 8
  %v7563 = load i64, ptr %slot1424, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v7562, i64 %v7563) nomerge, !dbg !196
  br label %bb_rcslotdone2114
bb_rcslotdone2114:
  %v7564 = load i64, ptr %slot1384, align 8
  ret i64 %v7564
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8, i64, i64)
declare i64 @myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d(i64, i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1", linkageName: "myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14127160347964262053, i64 0, !"myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!122 = !DILocation(line: 9, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!124 = !DILocation(line: 12, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!136 = !DILocation(line: 34, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!140 = !DILocation(line: 36, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!142 = !DILocation(line: 38, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!144 = !DILocation(line: 40, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!146 = !DILocation(line: 42, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!148 = !DILocation(line: 45, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!150 = !DILocation(line: 47, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!152 = !DILocation(line: 48, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!154 = !DILocation(line: 49, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!156 = !DILocation(line: 50, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!158 = !DILocation(line: 51, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!160 = !DILocation(line: 55, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!162 = !DILocation(line: 57, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!164 = !DILocation(line: 58, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!166 = !DILocation(line: 66, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!168 = !DILocation(line: 68, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!170 = !DILocation(line: 72, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!172 = !DILocation(line: 73, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!174 = !DILocation(line: 76, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!176 = !DILocation(line: 77, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!178 = !DILocation(line: 78, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!180 = !DILocation(line: 79, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!182 = !DILocation(line: 81, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!184 = !DILocation(line: 82, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!186 = !DILocation(line: 83, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!188 = !DILocation(line: 85, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!190 = !DILocation(line: 92, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!192 = !DILocation(line: 94, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!194 = !DILocation(line: 99, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!196 = !DILocation(line: 102, column: 0, scope: !197)
