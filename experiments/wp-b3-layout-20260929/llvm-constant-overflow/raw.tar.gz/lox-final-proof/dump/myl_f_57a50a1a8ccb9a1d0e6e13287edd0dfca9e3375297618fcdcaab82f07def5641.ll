target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_57a50a1a8ccb9a1d0e6e13287edd0dfca9e3375297618fcdcaab82f07def5641(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %callresult148 = alloca [24 x i8], align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %callresult459 = alloca [24 x i8], align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v858 = load i64, ptr %slot1, align 8
  %op859 = add i64 %v858, 32
  store i64 %op859, ptr %slot3, align 8
  %mem860 = alloca i8, i64 8, align 8
  %ptr861 = ptrtoint ptr %mem860 to i64
  store i64 %ptr861, ptr %slot4, align 8
  %mem862 = alloca i8, i64 8, align 8
  %ptr863 = ptrtoint ptr %mem862 to i64
  store i64 %ptr863, ptr %slot5, align 8
  %mem864 = alloca i8, i64 8, align 8
  %ptr865 = ptrtoint ptr %mem864 to i64
  store i64 %ptr865, ptr %slot6, align 8
  %mem866 = alloca i8, i64 8, align 8
  %ptr867 = ptrtoint ptr %mem866 to i64
  store i64 %ptr867, ptr %slot7, align 8
  %mem868 = alloca i8, i64 8, align 8
  %ptr869 = ptrtoint ptr %mem868 to i64
  store i64 %ptr869, ptr %slot8, align 8
  %mem870 = alloca i8, i64 8, align 8
  %ptr871 = ptrtoint ptr %mem870 to i64
  store i64 %ptr871, ptr %slot9, align 8
  %mem872 = alloca i8, i64 8, align 8
  %ptr873 = ptrtoint ptr %mem872 to i64
  store i64 %ptr873, ptr %slot10, align 8
  %mem874 = alloca i8, i64 8, align 8
  %ptr875 = ptrtoint ptr %mem874 to i64
  store i64 %ptr875, ptr %slot11, align 8
  %mem876 = alloca i8, i64 8, align 8
  %ptr877 = ptrtoint ptr %mem876 to i64
  store i64 %ptr877, ptr %slot12, align 8
  %mem878 = alloca i8, i64 8, align 8
  %ptr879 = ptrtoint ptr %mem878 to i64
  store i64 %ptr879, ptr %slot13, align 8
  %mem880 = alloca i8, i64 392, align 8
  %ptr881 = ptrtoint ptr %mem880 to i64
  store i64 %ptr881, ptr %slot14, align 8
  %mem882 = alloca i8, i64 8, align 8
  %ptr883 = ptrtoint ptr %mem882 to i64
  store i64 %ptr883, ptr %slot15, align 8
  %mem884 = alloca i8, i64 8, align 8
  %ptr885 = ptrtoint ptr %mem884 to i64
  store i64 %ptr885, ptr %slot16, align 8
  %mem886 = alloca i8, i64 8, align 8
  %ptr887 = ptrtoint ptr %mem886 to i64
  store i64 %ptr887, ptr %slot17, align 8
  %mem888 = alloca i8, i64 392, align 8
  %ptr889 = ptrtoint ptr %mem888 to i64
  store i64 %ptr889, ptr %slot18, align 8
  %mem890 = alloca i8, i64 8, align 8
  %ptr891 = ptrtoint ptr %mem890 to i64
  store i64 %ptr891, ptr %slot19, align 8
  %mem892 = alloca i8, i64 8, align 8
  %ptr893 = ptrtoint ptr %mem892 to i64
  store i64 %ptr893, ptr %slot20, align 8
  %mem894 = alloca i8, i64 8, align 8
  %ptr895 = ptrtoint ptr %mem894 to i64
  store i64 %ptr895, ptr %slot21, align 8
  %mem896 = alloca i8, i64 8, align 8
  %ptr897 = ptrtoint ptr %mem896 to i64
  store i64 %ptr897, ptr %slot22, align 8
  %mem898 = alloca i8, i64 8, align 8
  %ptr899 = ptrtoint ptr %mem898 to i64
  store i64 %ptr899, ptr %slot23, align 8
  %mem900 = alloca i8, i64 8, align 8
  %ptr901 = ptrtoint ptr %mem900 to i64
  store i64 %ptr901, ptr %slot24, align 8
  %mem902 = alloca i8, i64 8, align 8
  %ptr903 = ptrtoint ptr %mem902 to i64
  store i64 %ptr903, ptr %slot25, align 8
  %mem904 = alloca i8, i64 8, align 8
  %ptr905 = ptrtoint ptr %mem904 to i64
  store i64 %ptr905, ptr %slot26, align 8
  %mem906 = alloca i8, i64 8, align 8
  %ptr907 = ptrtoint ptr %mem906 to i64
  store i64 %ptr907, ptr %slot27, align 8
  %mem908 = alloca i8, i64 8, align 8
  %ptr909 = ptrtoint ptr %mem908 to i64
  store i64 %ptr909, ptr %slot28, align 8
  %mem910 = alloca i8, i64 392, align 8
  %ptr911 = ptrtoint ptr %mem910 to i64
  store i64 %ptr911, ptr %slot29, align 8
  %mem912 = alloca i8, i64 392, align 8
  %ptr913 = ptrtoint ptr %mem912 to i64
  store i64 %ptr913, ptr %slot30, align 8
  %mem914 = alloca i8, i64 392, align 8
  %ptr915 = ptrtoint ptr %mem914 to i64
  store i64 %ptr915, ptr %slot31, align 8
  %mem916 = alloca i8, i64 392, align 8
  %ptr917 = ptrtoint ptr %mem916 to i64
  store i64 %ptr917, ptr %slot32, align 8
  %mem918 = alloca i8, i64 392, align 8
  %ptr919 = ptrtoint ptr %mem918 to i64
  store i64 %ptr919, ptr %slot33, align 8
  %mem920 = alloca i8, i64 392, align 8
  %ptr921 = ptrtoint ptr %mem920 to i64
  store i64 %ptr921, ptr %slot34, align 8
  %mem922 = alloca i8, i64 392, align 8
  %ptr923 = ptrtoint ptr %mem922 to i64
  store i64 %ptr923, ptr %slot35, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem924 = alloca i8, i64 8, align 8
  %ptr925 = ptrtoint ptr %mem924 to i64
  store i64 %ptr925, ptr %slot36, align 8
  %v926 = load i64, ptr %slot1, align 8
  %op927 = add i64 %v926, 64
  store i64 %op927, ptr %slot37, align 8
  %v928 = load i64, ptr %slot37, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %ld930 = load i64, ptr %p929, align 8, !alias.scope !4, !noalias !3
  store i64 %ld930, ptr %slot38, align 8
  %stack931 = call ptr @llvm.stacksave()
  %stackaddr932 = ptrtoint ptr %stack931 to i64
  %v933 = load i64, ptr %slot38, align 8
  %cmp934 = icmp ult i64 %stackaddr932, %v933
  %cv935 = zext i1 %cmp934 to i64
  store i64 %cv935, ptr %slot39, align 8
  %v936 = load i64, ptr %slot39, align 8
  %cond937 = icmp ne i64 %v936, 0
  br i1 %cond937, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v938 = load i64, ptr %slot1, align 8
  %p939 = inttoptr i64 %v938 to ptr
  call void @myl_qbe_fail_frame(ptr %p939) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v940 = load i64, ptr %slot20, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i64 0, ptr %p941, align 8, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot24, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i64 0, ptr %p943, align 8, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot2, align 8
  %v945 = load i64, ptr %slot19, align 8
  %p946 = inttoptr i64 %v945 to ptr
  store i64 %v944, ptr %p946, align 8, !alias.scope !3, !noalias !4
  %v947 = load i64, ptr %slot1, align 8
  %p948 = inttoptr i64 %v947 to ptr
  %call949 = call ptr @myl_qbe_heap(ptr %p948) nomerge, !dbg !112
  %calladdr950 = ptrtoint ptr %call949 to i64
  store i64 %calladdr950, ptr %slot40, align 8
  %v951 = load i64, ptr %slot1, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %call953 = call i64 @myl_qbe_region_mark(ptr %p952) nomerge, !dbg !112
  store i64 %call953, ptr %slot41, align 8
  %v954 = load i64, ptr %slot4, align 8
  %p955 = inttoptr i64 %v954 to ptr
  store i32 0, ptr %p955, align 4, !alias.scope !3, !noalias !4
  %v956 = load i64, ptr %slot5, align 8
  %p957 = inttoptr i64 %v956 to ptr
  store i32 0, ptr %p957, align 4, !alias.scope !3, !noalias !4
  %v958 = load i64, ptr %slot6, align 8
  %p959 = inttoptr i64 %v958 to ptr
  store i32 0, ptr %p959, align 4, !alias.scope !3, !noalias !4
  %v960 = load i64, ptr %slot7, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 0, ptr %p961, align 4, !alias.scope !3, !noalias !4
  %v962 = load i64, ptr %slot8, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i32 0, ptr %p963, align 4, !alias.scope !3, !noalias !4
  %v964 = load i64, ptr %slot9, align 8
  %p965 = inttoptr i64 %v964 to ptr
  store i32 0, ptr %p965, align 4, !alias.scope !3, !noalias !4
  %v966 = load i64, ptr %slot10, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i32 0, ptr %p967, align 4, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot11, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i32 0, ptr %p969, align 4, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot12, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i32 0, ptr %p971, align 4, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot13, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i32 0, ptr %p973, align 4, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot5, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 2, ptr %p975, align 4, !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot7, align 8
  %p977 = inttoptr i64 %v976 to ptr
  store i32 2, ptr %p977, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v978 = load i64, ptr %slot19, align 8
  %p979 = inttoptr i64 %v978 to ptr
  %ld980 = load i64, ptr %p979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld980, ptr %slot42, align 8
  %v981 = load i64, ptr %slot42, align 8
  %v982 = load i64, ptr %slot26, align 8
  %p983 = inttoptr i64 %v982 to ptr
  store i64 %v981, ptr %p983, align 8, !alias.scope !3, !noalias !4
  %v984 = load i64, ptr %slot26, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i64, ptr %p985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld986, ptr %slot43, align 8
  %v987 = load i64, ptr %slot1, align 8
  %v988 = load i64, ptr %slot43, align 8
  %call989 = call i64 @myl_f_2f610d65ff9d8de8448ce74fb4f0d7608052b9fdb008fde954187d627f662f71(i64 %v987, i64 %v988) nomerge, !dbg !114
  store i64 %call989, ptr %slot44, align 8
  %v990 = load i64, ptr %slot44, align 8
  %v991 = load i64, ptr %slot26, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i64 %v990, ptr %p992, align 8, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot8, align 8
  %p994 = inttoptr i64 %v993 to ptr
  %ld995 = load i32, ptr %p994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld995, ptr %slot45, align 8
  %v996 = load i32, ptr %slot45, align 8
  %cv997 = zext i32 %v996 to i64
  %cond998 = icmp ne i64 %cv997, 0
  br i1 %cond998, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v999 = load i64, ptr %slot8, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  store i32 0, ptr %p1000, align 4, !alias.scope !3, !noalias !4
  %v1001 = load i64, ptr %slot14, align 8
  store i64 %v1001, ptr %slot46, align 8
  %v1002 = load i64, ptr %slot9, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  %ld1004 = load i32, ptr %p1003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1004, ptr %slot47, align 8
  %v1005 = load i32, ptr %slot47, align 8
  %op1006 = and i32 %v1005, 28
  store i32 %op1006, ptr %slot48, align 8
  %v1007 = load i32, ptr %slot48, align 8
  %cv1008 = zext i32 %v1007 to i64
  %cond1009 = icmp ne i64 %cv1008, 0
  br i1 %cond1009, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v1010 = load i64, ptr %slot40, align 8
  store i64 %v1010, ptr %slot49, align 8
  %v1011 = load i64, ptr %slot49, align 8
  %v1012 = load i64, ptr %slot46, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1011, i64 %v1012) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v1013 = load i64, ptr %slot40, align 8
  store i64 %v1013, ptr %slot50, align 8
  %v1014 = load i64, ptr %slot50, align 8
  %v1015 = load i64, ptr %slot46, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1014, i64 %v1015) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v1016 = load i64, ptr %slot19, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i64, ptr %p1017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1018, ptr %slot51, align 8
  %v1019 = load i64, ptr %slot51, align 8
  %v1020 = load i64, ptr %slot26, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  store i64 %v1019, ptr %p1021, align 8, !alias.scope !3, !noalias !4
  %v1022 = load i64, ptr %slot29, align 8
  store i64 %v1022, ptr %slot52, align 8
  %v1023 = load i64, ptr %slot52, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 0, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot52, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i32 0, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot52, align 8
  %v1028 = load i64, ptr %slot27, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i64 %v1027, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  %p1030 = inttoptr i64 ptrtoint (ptr @myl_lit_067e6c15dd3a19c7a0dc5698a499ce7f48299235035df0ce9ae0949c3635b214 to i64) to ptr
  %ld1031 = load i64, ptr %p1030, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1031, ptr %slot53, align 8
  %v1032 = load i64, ptr %slot53, align 8
  %v1033 = load i64, ptr %slot28, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  store i64 %v1032, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  %v1035 = load i64, ptr %slot28, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i64, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1037, ptr %slot54, align 8
  %v1038 = load i64, ptr %slot54, align 8
  %v1039 = load i64, ptr %slot17, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i64 %v1038, ptr %p1040, align 8, !alias.scope !3, !noalias !4
  %v1041 = load i64, ptr %slot17, align 8
  store i64 %v1041, ptr %slot55, align 8
  %v1042 = load i64, ptr %slot18, align 8
  store i64 %v1042, ptr %slot56, align 8
  %v1043 = load i64, ptr %slot55, align 8
  %v1044 = load i64, ptr %slot56, align 8
  %p1045 = inttoptr i64 %v1043 to ptr
  %p1046 = inttoptr i64 %v1044 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1046, ptr %p1045, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot13, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i32 2, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot12, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i32 1, ptr %p1050, align 4, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot15, align 8
  store i64 %v1051, ptr %slot57, align 8
  %v1052 = load i64, ptr %slot18, align 8
  store i64 %v1052, ptr %slot58, align 8
  %v1053 = load i64, ptr %slot58, align 8
  %v1054 = load i64, ptr %slot57, align 8
  %p1055 = inttoptr i64 %v1053 to ptr
  %p1056 = inttoptr i64 %v1054 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1056, ptr %p1055, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot11, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 2, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot13, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %ld1061 = load i32, ptr %p1060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1061, ptr %slot59, align 8
  %v1062 = load i32, ptr %slot59, align 8
  %v1063 = load i64, ptr %slot11, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  store i32 %v1062, ptr %p1064, align 4, !alias.scope !3, !noalias !4
  %v1065 = load i64, ptr %slot12, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  store i32 0, ptr %p1066, align 4, !alias.scope !3, !noalias !4
  %v1067 = load i64, ptr %slot10, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i32 1, ptr %p1068, align 4, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot57, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  %ld1071 = load i64, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1071, ptr %slot60, align 8
  %v1072 = load i64, ptr %slot60, align 8
  %v1073 = load i64, ptr %slot28, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  store i64 %v1072, ptr %p1074, align 8, !alias.scope !3, !noalias !4
  %v1075 = load i64, ptr %slot26, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  %ld1077 = load i64, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1077, ptr %slot61, align 8
  %v1078 = load i64, ptr %slot27, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %ld1080 = load i64, ptr %p1079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1080, ptr %slot62, align 8
  %v1081 = load i64, ptr %slot28, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %ld1083 = load i64, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1083, ptr %slot63, align 8
  %v1084 = load i64, ptr %slot1, align 8
  %v1085 = load i64, ptr %slot61, align 8
  %v1086 = load i64, ptr %slot62, align 8
  %v1087 = load i64, ptr %slot63, align 8
  %call1088 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v1084, i64 %v1085, i64 %v1086, i64 %v1087) nomerge, !dbg !116
  store i64 %call1088, ptr %slot64, align 8
  %v1089 = load i64, ptr %slot64, align 8
  %v1090 = load i64, ptr %slot26, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  store i64 %v1089, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  %v1092 = load i64, ptr %slot8, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i32, ptr %p1093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1094, ptr %slot65, align 8
  %v1095 = load i32, ptr %slot65, align 8
  %cv1096 = zext i32 %v1095 to i64
  %cond1097 = icmp ne i64 %cv1096, 0
  br i1 %cond1097, label %bb_rcslotdrop46, label %bb_rcslotdone46
bb_rcslotdrop46:
  %v1098 = load i64, ptr %slot8, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i32 0, ptr %p1099, align 4, !alias.scope !3, !noalias !4
  %v1100 = load i64, ptr %slot14, align 8
  store i64 %v1100, ptr %slot66, align 8
  %v1101 = load i64, ptr %slot9, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %ld1103 = load i32, ptr %p1102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1103, ptr %slot67, align 8
  %v1104 = load i32, ptr %slot67, align 8
  %op1105 = and i32 %v1104, 28
  store i32 %op1105, ptr %slot68, align 8
  %v1106 = load i32, ptr %slot68, align 8
  %cv1107 = zext i32 %v1106 to i64
  %cond1108 = icmp ne i64 %cv1107, 0
  br i1 %cond1108, label %bb_rcslotrole46, label %bb_rcslotowner46
bb_rcslotrole46:
  %v1109 = load i64, ptr %slot40, align 8
  store i64 %v1109, ptr %slot69, align 8
  %v1110 = load i64, ptr %slot69, align 8
  %v1111 = load i64, ptr %slot66, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1110, i64 %v1111) nomerge, !dbg !116
  br label %bb_rcslotdone46
bb_rcslotowner46:
  %v1112 = load i64, ptr %slot40, align 8
  store i64 %v1112, ptr %slot70, align 8
  %v1113 = load i64, ptr %slot70, align 8
  %v1114 = load i64, ptr %slot66, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1113, i64 %v1114) nomerge, !dbg !116
  br label %bb_rcslotdone46
bb_rcslotdone46:
  %v1115 = load i64, ptr %slot10, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %ld1117 = load i32, ptr %p1116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1117, ptr %slot71, align 8
  %v1118 = load i32, ptr %slot71, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcslotdrop55, label %bb_rcslotdone55
bb_rcslotdrop55:
  %v1121 = load i64, ptr %slot10, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  store i32 0, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  %v1123 = load i64, ptr %slot15, align 8
  store i64 %v1123, ptr %slot72, align 8
  %v1124 = load i64, ptr %slot11, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %ld1126 = load i32, ptr %p1125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1126, ptr %slot73, align 8
  %v1127 = load i32, ptr %slot73, align 8
  %op1128 = and i32 %v1127, 28
  store i32 %op1128, ptr %slot74, align 8
  %v1129 = load i32, ptr %slot74, align 8
  %cv1130 = zext i32 %v1129 to i64
  %cond1131 = icmp ne i64 %cv1130, 0
  br i1 %cond1131, label %bb_rcslotrole55, label %bb_rcslotowner55
bb_rcslotrole55:
  %v1132 = load i64, ptr %slot40, align 8
  store i64 %v1132, ptr %slot75, align 8
  %v1133 = load i64, ptr %slot72, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %ld1135 = load i64, ptr %p1134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1135, ptr %slot76, align 8
  %v1136 = load i64, ptr %slot76, align 8
  %cmp1137 = icmp ne i64 %v1136, 0
  %cv1138 = zext i1 %cmp1137 to i32
  store i32 %cv1138, ptr %slot77, align 8
  %v1139 = load i32, ptr %slot77, align 8
  %cv1140 = zext i32 %v1139 to i64
  %cond1141 = icmp ne i64 %cv1140, 0
  br i1 %cond1141, label %bb_rcgnn71, label %bb_rcgdone71
bb_rcgnn71:
  %v1142 = load i64, ptr %slot76, align 8
  %op1143 = sub i64 %v1142, 16
  store i64 %op1143, ptr %slot78, align 8
  %v1144 = load i64, ptr %slot76, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %rgep1146 = getelementptr i8, ptr %p1145, i64 -16
  %ld1147 = load i64, ptr %rgep1146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1147, ptr %slot79, align 8
  %v1148 = load i64, ptr %slot79, align 8
  %op1149 = and i64 %v1148, 4611686018427387906
  store i64 %op1149, ptr %slot80, align 8
  %v1150 = load i64, ptr %slot80, align 8
  %cmp1151 = icmp ne i64 %v1150, 0
  %cv1152 = zext i1 %cmp1151 to i32
  store i32 %cv1152, ptr %slot81, align 8
  %v1153 = load i32, ptr %slot81, align 8
  %cv1154 = zext i32 %v1153 to i64
  %cond1155 = icmp ne i64 %cv1154, 0
  br i1 %cond1155, label %bb_rcgclear71, label %bb_rcgcounted71
bb_rcgcounted71:
  %v1156 = load i64, ptr %slot76, align 8
  %op1157 = sub i64 %v1156, 24
  store i64 %op1157, ptr %slot82, align 8
  %v1158 = load i64, ptr %slot76, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  %rgep1160 = getelementptr i8, ptr %p1159, i64 -24
  %ld1161 = load i64, ptr %rgep1160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1161, ptr %slot83, align 8
  %v1162 = load i64, ptr %slot83, align 8
  %op1163 = sub i64 %v1162, 1
  store i64 %op1163, ptr %slot84, align 8
  %v1164 = load i64, ptr %slot84, align 8
  %cmp1165 = icmp eq i64 %v1164, 0
  %cv1166 = zext i1 %cmp1165 to i32
  store i32 %cv1166, ptr %slot85, align 8
  %v1167 = load i32, ptr %slot85, align 8
  %cv1168 = zext i32 %v1167 to i64
  %cond1169 = icmp ne i64 %cv1168, 0
  br i1 %cond1169, label %bb_rcglast71, label %bb_rcgdec71
bb_rcglast71:
  %v1170 = load i64, ptr %slot76, align 8
  %op1171 = sub i64 %v1170, 32
  store i64 %op1171, ptr %slot86, align 8
  %v1172 = load i64, ptr %slot76, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  %rgep1174 = getelementptr i8, ptr %p1173, i64 -32
  %ld1175 = load i64, ptr %rgep1174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1175, ptr %slot87, align 8
  %v1176 = load i64, ptr %slot87, align 8
  %cmp1177 = icmp ne i64 %v1176, 0
  %cv1178 = zext i1 %cmp1177 to i32
  store i32 %cv1178, ptr %slot88, align 8
  %v1179 = load i32, ptr %slot88, align 8
  %cv1180 = zext i32 %v1179 to i64
  %cond1181 = icmp ne i64 %cv1180, 0
  br i1 %cond1181, label %bb_rcgdec71, label %bb_rcgslow71
bb_rcgslow71:
  %v1182 = load i64, ptr %slot75, align 8
  %v1183 = load i64, ptr %slot72, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1182, i64 %v1183) nomerge, !dbg !116
  br label %bb_rcgdone71
bb_rcgdec71:
  %v1184 = load i64, ptr %slot84, align 8
  %v1185 = load i64, ptr %slot76, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %rgep1187 = getelementptr i8, ptr %p1186, i64 -24
  store i64 %v1184, ptr %rgep1187, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear71
bb_rcgclear71:
  %v1188 = load i64, ptr %slot72, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i64 0, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone71
bb_rcgdone71:
  br label %bb_rcslotdone55
bb_rcslotowner55:
  %v1190 = load i64, ptr %slot40, align 8
  store i64 %v1190, ptr %slot89, align 8
  %v1191 = load i64, ptr %slot72, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i64, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1193, ptr %slot90, align 8
  %v1194 = load i64, ptr %slot90, align 8
  %cmp1195 = icmp ne i64 %v1194, 0
  %cv1196 = zext i1 %cmp1195 to i32
  store i32 %cv1196, ptr %slot91, align 8
  %v1197 = load i32, ptr %slot91, align 8
  %cv1198 = zext i32 %v1197 to i64
  %cond1199 = icmp ne i64 %cv1198, 0
  br i1 %cond1199, label %bb_rcgnn86, label %bb_rcgdone86
bb_rcgnn86:
  %v1200 = load i64, ptr %slot90, align 8
  %op1201 = sub i64 %v1200, 16
  store i64 %op1201, ptr %slot92, align 8
  %v1202 = load i64, ptr %slot90, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %rgep1204 = getelementptr i8, ptr %p1203, i64 -16
  %ld1205 = load i64, ptr %rgep1204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1205, ptr %slot93, align 8
  %v1206 = load i64, ptr %slot93, align 8
  %op1207 = and i64 %v1206, 4611686018427387906
  store i64 %op1207, ptr %slot94, align 8
  %v1208 = load i64, ptr %slot94, align 8
  %cmp1209 = icmp ne i64 %v1208, 0
  %cv1210 = zext i1 %cmp1209 to i32
  store i32 %cv1210, ptr %slot95, align 8
  %v1211 = load i32, ptr %slot95, align 8
  %cv1212 = zext i32 %v1211 to i64
  %cond1213 = icmp ne i64 %cv1212, 0
  br i1 %cond1213, label %bb_rcgclear86, label %bb_rcgcounted86
bb_rcgcounted86:
  %v1214 = load i64, ptr %slot90, align 8
  %op1215 = sub i64 %v1214, 32
  store i64 %op1215, ptr %slot96, align 8
  %v1216 = load i64, ptr %slot90, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %rgep1218 = getelementptr i8, ptr %p1217, i64 -32
  %ld1219 = load i64, ptr %rgep1218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1219, ptr %slot97, align 8
  %v1220 = load i64, ptr %slot97, align 8
  %op1221 = sub i64 %v1220, 1
  store i64 %op1221, ptr %slot98, align 8
  %v1222 = load i64, ptr %slot98, align 8
  %cmp1223 = icmp eq i64 %v1222, 0
  %cv1224 = zext i1 %cmp1223 to i32
  store i32 %cv1224, ptr %slot99, align 8
  %v1225 = load i32, ptr %slot99, align 8
  %cv1226 = zext i32 %v1225 to i64
  %cond1227 = icmp ne i64 %cv1226, 0
  br i1 %cond1227, label %bb_rcglast86, label %bb_rcgdec86
bb_rcglast86:
  %v1228 = load i64, ptr %slot90, align 8
  %op1229 = sub i64 %v1228, 24
  store i64 %op1229, ptr %slot100, align 8
  %v1230 = load i64, ptr %slot90, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %rgep1232 = getelementptr i8, ptr %p1231, i64 -24
  %ld1233 = load i64, ptr %rgep1232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1233, ptr %slot101, align 8
  %v1234 = load i64, ptr %slot101, align 8
  %cmp1235 = icmp ne i64 %v1234, 0
  %cv1236 = zext i1 %cmp1235 to i32
  store i32 %cv1236, ptr %slot102, align 8
  %v1237 = load i32, ptr %slot102, align 8
  %cv1238 = zext i32 %v1237 to i64
  %cond1239 = icmp ne i64 %cv1238, 0
  br i1 %cond1239, label %bb_rcgdec86, label %bb_rcgslow86
bb_rcgslow86:
  %v1240 = load i64, ptr %slot89, align 8
  %v1241 = load i64, ptr %slot72, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1240, i64 %v1241) nomerge, !dbg !116
  br label %bb_rcgdone86
bb_rcgdec86:
  %v1242 = load i64, ptr %slot98, align 8
  %v1243 = load i64, ptr %slot90, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %rgep1245 = getelementptr i8, ptr %p1244, i64 -32
  store i64 %v1242, ptr %rgep1245, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear86
bb_rcgclear86:
  %v1246 = load i64, ptr %slot72, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i64 0, ptr %p1247, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone86
bb_rcgdone86:
  br label %bb_rcslotdone55
bb_rcslotdone55:
  %v1248 = load i64, ptr %slot19, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  %ld1250 = load i64, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1250, ptr %slot103, align 8
  %v1251 = load i64, ptr %slot103, align 8
  %v1252 = load i64, ptr %slot26, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  store i64 %v1251, ptr %p1253, align 8, !alias.scope !3, !noalias !4
  %v1254 = load i64, ptr %slot30, align 8
  store i64 %v1254, ptr %slot104, align 8
  %v1255 = load i64, ptr %slot104, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i32 0, ptr %p1256, align 4, !alias.scope !3, !noalias !4
  %v1257 = load i64, ptr %slot104, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  store i32 8, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  %v1259 = load i64, ptr %slot104, align 8
  %v1260 = load i64, ptr %slot27, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i64 %v1259, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot26, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i64, ptr %p1263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1264, ptr %slot105, align 8
  %v1265 = load i64, ptr %slot27, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %ld1267 = load i64, ptr %p1266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1267, ptr %slot106, align 8
  %v1268 = load i64, ptr %slot1, align 8
  %v1269 = load i64, ptr %slot105, align 8
  %v1270 = load i64, ptr %slot106, align 8
  %call1271 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v1268, i64 %v1269, i64 %v1270) nomerge, !dbg !118
  store i64 %call1271, ptr %slot107, align 8
  %v1272 = load i64, ptr %slot107, align 8
  %v1273 = load i64, ptr %slot26, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  store i64 %v1272, ptr %p1274, align 8, !alias.scope !3, !noalias !4
  %v1275 = load i64, ptr %slot8, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i32, ptr %p1276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1277, ptr %slot108, align 8
  %v1278 = load i32, ptr %slot108, align 8
  %cv1279 = zext i32 %v1278 to i64
  %cond1280 = icmp ne i64 %cv1279, 0
  br i1 %cond1280, label %bb_rcslotdrop97, label %bb_rcslotdone97
bb_rcslotdrop97:
  %v1281 = load i64, ptr %slot8, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 0, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot14, align 8
  store i64 %v1283, ptr %slot109, align 8
  %v1284 = load i64, ptr %slot9, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i32, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1286, ptr %slot110, align 8
  %v1287 = load i32, ptr %slot110, align 8
  %op1288 = and i32 %v1287, 28
  store i32 %op1288, ptr %slot111, align 8
  %v1289 = load i32, ptr %slot111, align 8
  %cv1290 = zext i32 %v1289 to i64
  %cond1291 = icmp ne i64 %cv1290, 0
  br i1 %cond1291, label %bb_rcslotrole97, label %bb_rcslotowner97
bb_rcslotrole97:
  %v1292 = load i64, ptr %slot40, align 8
  store i64 %v1292, ptr %slot112, align 8
  %v1293 = load i64, ptr %slot112, align 8
  %v1294 = load i64, ptr %slot109, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1293, i64 %v1294) nomerge, !dbg !118
  br label %bb_rcslotdone97
bb_rcslotowner97:
  %v1295 = load i64, ptr %slot40, align 8
  store i64 %v1295, ptr %slot113, align 8
  %v1296 = load i64, ptr %slot113, align 8
  %v1297 = load i64, ptr %slot109, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1296, i64 %v1297) nomerge, !dbg !118
  br label %bb_rcslotdone97
bb_rcslotdone97:
  %v1298 = load i64, ptr %slot26, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  %ld1300 = load i64, ptr %p1299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1300, ptr %slot114, align 8
  %v1301 = load i64, ptr %slot114, align 8
  %cond1302 = icmp ne i64 %v1301, 0
  br i1 %cond1302, label %bb_next105, label %bb_i13
bb_next105:
  br label %bb_i24
bb_i13:
  %v1303 = load i64, ptr %slot19, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i64, ptr %p1304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1305, ptr %slot115, align 8
  %v1306 = load i64, ptr %slot115, align 8
  %v1307 = load i64, ptr %slot26, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i64 %v1306, ptr %p1308, align 8, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot31, align 8
  store i64 %v1309, ptr %slot116, align 8
  %v1310 = load i64, ptr %slot116, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  store i32 0, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  %v1312 = load i64, ptr %slot116, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i32 36, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot116, align 8
  %v1315 = load i64, ptr %slot27, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i64 %v1314, ptr %p1316, align 8, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot26, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  %ld1319 = load i64, ptr %p1318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1319, ptr %slot117, align 8
  %v1320 = load i64, ptr %slot27, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  %ld1322 = load i64, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1322, ptr %slot118, align 8
  %v1323 = load i64, ptr %slot1, align 8
  %v1324 = load i64, ptr %slot117, align 8
  %v1325 = load i64, ptr %slot118, align 8
  %call1326 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v1323, i64 %v1324, i64 %v1325) nomerge, !dbg !120
  store i64 %call1326, ptr %slot119, align 8
  %v1327 = load i64, ptr %slot119, align 8
  %v1328 = load i64, ptr %slot26, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i64 %v1327, ptr %p1329, align 8, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot8, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  %ld1332 = load i32, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1332, ptr %slot120, align 8
  %v1333 = load i32, ptr %slot120, align 8
  %cv1334 = zext i32 %v1333 to i64
  %cond1335 = icmp ne i64 %cv1334, 0
  br i1 %cond1335, label %bb_rcslotdrop112, label %bb_rcslotdone112
bb_rcslotdrop112:
  %v1336 = load i64, ptr %slot8, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 0, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot14, align 8
  store i64 %v1338, ptr %slot121, align 8
  %v1339 = load i64, ptr %slot9, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %ld1341 = load i32, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1341, ptr %slot122, align 8
  %v1342 = load i32, ptr %slot122, align 8
  %op1343 = and i32 %v1342, 28
  store i32 %op1343, ptr %slot123, align 8
  %v1344 = load i32, ptr %slot123, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcslotrole112, label %bb_rcslotowner112
bb_rcslotrole112:
  %v1347 = load i64, ptr %slot40, align 8
  store i64 %v1347, ptr %slot124, align 8
  %v1348 = load i64, ptr %slot124, align 8
  %v1349 = load i64, ptr %slot121, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1348, i64 %v1349) nomerge, !dbg !120
  br label %bb_rcslotdone112
bb_rcslotowner112:
  %v1350 = load i64, ptr %slot40, align 8
  store i64 %v1350, ptr %slot125, align 8
  %v1351 = load i64, ptr %slot125, align 8
  %v1352 = load i64, ptr %slot121, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1351, i64 %v1352) nomerge, !dbg !120
  br label %bb_rcslotdone112
bb_rcslotdone112:
  %v1353 = load i64, ptr %slot26, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i64, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1355, ptr %slot126, align 8
  %v1356 = load i64, ptr %slot126, align 8
  %cond1357 = icmp ne i64 %v1356, 0
  br i1 %cond1357, label %bb_next120, label %bb_i21
bb_next120:
  %v1358 = load i64, ptr %slot19, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %ld1360 = load i64, ptr %p1359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1360, ptr %slot127, align 8
  %v1361 = load i64, ptr %slot127, align 8
  %v1362 = load i64, ptr %slot26, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  store i64 %v1361, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  %v1364 = load i64, ptr %slot26, align 8
  %p1365 = inttoptr i64 %v1364 to ptr
  %ld1366 = load i64, ptr %p1365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1366, ptr %slot128, align 8
  %v1367 = load i64, ptr %slot1, align 8
  %v1368 = load i64, ptr %slot128, align 8
  %call1369 = call i64 @myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45(i64 %v1367, i64 %v1368) nomerge, !dbg !122
  store i64 %call1369, ptr %slot129, align 8
  %v1370 = load i64, ptr %slot129, align 8
  %v1371 = load i64, ptr %slot26, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 %v1370, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot8, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  %ld1375 = load i32, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1375, ptr %slot130, align 8
  %v1376 = load i32, ptr %slot130, align 8
  %cv1377 = zext i32 %v1376 to i64
  %cond1378 = icmp ne i64 %cv1377, 0
  br i1 %cond1378, label %bb_rcslotdrop125, label %bb_rcslotdone125
bb_rcslotdrop125:
  %v1379 = load i64, ptr %slot8, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i32 0, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot14, align 8
  store i64 %v1381, ptr %slot131, align 8
  %v1382 = load i64, ptr %slot9, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %ld1384 = load i32, ptr %p1383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1384, ptr %slot132, align 8
  %v1385 = load i32, ptr %slot132, align 8
  %op1386 = and i32 %v1385, 28
  store i32 %op1386, ptr %slot133, align 8
  %v1387 = load i32, ptr %slot133, align 8
  %cv1388 = zext i32 %v1387 to i64
  %cond1389 = icmp ne i64 %cv1388, 0
  br i1 %cond1389, label %bb_rcslotrole125, label %bb_rcslotowner125
bb_rcslotrole125:
  %v1390 = load i64, ptr %slot40, align 8
  store i64 %v1390, ptr %slot134, align 8
  %v1391 = load i64, ptr %slot134, align 8
  %v1392 = load i64, ptr %slot131, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1391, i64 %v1392) nomerge, !dbg !122
  br label %bb_rcslotdone125
bb_rcslotowner125:
  %v1393 = load i64, ptr %slot40, align 8
  store i64 %v1393, ptr %slot135, align 8
  %v1394 = load i64, ptr %slot135, align 8
  %v1395 = load i64, ptr %slot131, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1394, i64 %v1395) nomerge, !dbg !122
  br label %bb_rcslotdone125
bb_rcslotdone125:
  br label %bb_i24
bb_i21:
  %v1396 = load i64, ptr %slot19, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %ld1398 = load i64, ptr %p1397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1398, ptr %slot136, align 8
  %v1399 = load i64, ptr %slot136, align 8
  %v1400 = load i64, ptr %slot26, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i64 %v1399, ptr %p1401, align 8, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot26, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %ld1404 = load i64, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1404, ptr %slot137, align 8
  %v1405 = load i64, ptr %slot1, align 8
  %v1406 = load i64, ptr %slot137, align 8
  %call1407 = call i64 @myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6(i64 %v1405, i64 %v1406) nomerge, !dbg !124
  store i64 %call1407, ptr %slot138, align 8
  %v1408 = load i64, ptr %slot138, align 8
  %v1409 = load i64, ptr %slot26, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i64 %v1408, ptr %p1410, align 8, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot8, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i32, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1413, ptr %slot139, align 8
  %v1414 = load i32, ptr %slot139, align 8
  %cv1415 = zext i32 %v1414 to i64
  %cond1416 = icmp ne i64 %cv1415, 0
  br i1 %cond1416, label %bb_rcslotdrop137, label %bb_rcslotdone137
bb_rcslotdrop137:
  %v1417 = load i64, ptr %slot8, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 0, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot14, align 8
  store i64 %v1419, ptr %slot140, align 8
  %v1420 = load i64, ptr %slot9, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %ld1422 = load i32, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1422, ptr %slot141, align 8
  %v1423 = load i32, ptr %slot141, align 8
  %op1424 = and i32 %v1423, 28
  store i32 %op1424, ptr %slot142, align 8
  %v1425 = load i32, ptr %slot142, align 8
  %cv1426 = zext i32 %v1425 to i64
  %cond1427 = icmp ne i64 %cv1426, 0
  br i1 %cond1427, label %bb_rcslotrole137, label %bb_rcslotowner137
bb_rcslotrole137:
  %v1428 = load i64, ptr %slot40, align 8
  store i64 %v1428, ptr %slot143, align 8
  %v1429 = load i64, ptr %slot143, align 8
  %v1430 = load i64, ptr %slot140, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1429, i64 %v1430) nomerge, !dbg !124
  br label %bb_rcslotdone137
bb_rcslotowner137:
  %v1431 = load i64, ptr %slot40, align 8
  store i64 %v1431, ptr %slot144, align 8
  %v1432 = load i64, ptr %slot144, align 8
  %v1433 = load i64, ptr %slot140, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1432, i64 %v1433) nomerge, !dbg !124
  br label %bb_rcslotdone137
bb_rcslotdone137:
  br label %bb_i24
bb_i24:
  %v1434 = load i64, ptr %slot19, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i64, ptr %p1435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1436, ptr %slot145, align 8
  %v1437 = load i64, ptr %slot145, align 8
  %v1438 = load i64, ptr %slot26, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  store i64 %v1437, ptr %p1439, align 8, !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot26, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i64, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1442, ptr %slot146, align 8
  %v1443 = load i64, ptr %slot1, align 8
  %v1444 = load i64, ptr %slot146, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult148, i64 %v1443, i64 %v1444) nomerge, !dbg !126
  %addr1445 = ptrtoint ptr %callresult148 to i64
  store i64 %addr1445, ptr %slot147, align 8
  %v1446 = load i64, ptr %slot147, align 8
  %v1447 = load i64, ptr %slot26, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  store i64 %v1446, ptr %p1448, align 8, !alias.scope !3, !noalias !4
  %v1449 = load i64, ptr %slot26, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i64, ptr %p1450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1451, ptr %slot149, align 8
  %v1452 = load i64, ptr %slot18, align 8
  store i64 %v1452, ptr %slot150, align 8
  %v1453 = load i64, ptr %slot149, align 8
  %v1454 = load i64, ptr %slot150, align 8
  %p1455 = inttoptr i64 %v1453 to ptr
  %p1456 = inttoptr i64 %v1454 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1456, ptr %p1455, i64 24, i1 false)
  %v1457 = load i64, ptr %slot13, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i32 2, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot12, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i32 1, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  %v1461 = load i64, ptr %slot8, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i32, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1463, ptr %slot151, align 8
  %v1464 = load i32, ptr %slot151, align 8
  %cv1465 = zext i32 %v1464 to i64
  %cond1466 = icmp ne i64 %cv1465, 0
  br i1 %cond1466, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v1467 = load i64, ptr %slot8, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i32 0, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot14, align 8
  store i64 %v1469, ptr %slot152, align 8
  %v1470 = load i64, ptr %slot9, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %ld1472 = load i32, ptr %p1471, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1472, ptr %slot153, align 8
  %v1473 = load i32, ptr %slot153, align 8
  %op1474 = and i32 %v1473, 28
  store i32 %op1474, ptr %slot154, align 8
  %v1475 = load i32, ptr %slot154, align 8
  %cv1476 = zext i32 %v1475 to i64
  %cond1477 = icmp ne i64 %cv1476, 0
  br i1 %cond1477, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v1478 = load i64, ptr %slot40, align 8
  store i64 %v1478, ptr %slot155, align 8
  %v1479 = load i64, ptr %slot155, align 8
  %v1480 = load i64, ptr %slot152, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1479, i64 %v1480) nomerge, !dbg !126
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v1481 = load i64, ptr %slot40, align 8
  store i64 %v1481, ptr %slot156, align 8
  %v1482 = load i64, ptr %slot156, align 8
  %v1483 = load i64, ptr %slot152, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1482, i64 %v1483) nomerge, !dbg !126
  br label %bb_rcslotdone153
bb_rcslotdone153:
  %v1484 = load i64, ptr %slot14, align 8
  store i64 %v1484, ptr %slot157, align 8
  %v1485 = load i64, ptr %slot18, align 8
  store i64 %v1485, ptr %slot158, align 8
  %v1486 = load i64, ptr %slot158, align 8
  %v1487 = load i64, ptr %slot157, align 8
  %p1488 = inttoptr i64 %v1486 to ptr
  %p1489 = inttoptr i64 %v1487 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1489, ptr %p1488, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot9, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i32 2, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot13, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %ld1494 = load i32, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1494, ptr %slot159, align 8
  %v1495 = load i32, ptr %slot159, align 8
  %v1496 = load i64, ptr %slot9, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  store i32 %v1495, ptr %p1497, align 4, !alias.scope !3, !noalias !4
  %v1498 = load i64, ptr %slot12, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  store i32 0, ptr %p1499, align 4, !alias.scope !3, !noalias !4
  %v1500 = load i64, ptr %slot8, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i32 1, ptr %p1501, align 4, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot157, align 8
  %v1503 = load i64, ptr %slot26, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i64 %v1502, ptr %p1504, align 8, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot26, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot160, align 8
  %v1508 = load i64, ptr %slot160, align 8
  %op1509 = add i64 %v1508, 0
  store i64 %op1509, ptr %slot161, align 8
  %v1510 = load i64, ptr %slot161, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i64, ptr %p1511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1512, ptr %slot162, align 8
  %v1513 = load i64, ptr %slot162, align 8
  %v1514 = load i64, ptr %slot26, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  store i64 %v1513, ptr %p1515, align 8, !alias.scope !3, !noalias !4
  %v1516 = load i64, ptr %slot26, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %ld1518 = load i64, ptr %p1517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1518, ptr %slot163, align 8
  %v1519 = load i64, ptr %slot163, align 8
  %v1520 = load i64, ptr %slot16, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  store i64 %v1519, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  %v1522 = load i64, ptr %slot16, align 8
  store i64 %v1522, ptr %slot164, align 8
  %v1523 = load i64, ptr %slot18, align 8
  store i64 %v1523, ptr %slot165, align 8
  %v1524 = load i64, ptr %slot164, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  %ld1526 = load i64, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1526, ptr %slot166, align 8
  %v1527 = load i64, ptr %slot166, align 8
  %cmp1528 = icmp ne i64 %v1527, 0
  %cv1529 = zext i1 %cmp1528 to i32
  store i32 %cv1529, ptr %slot167, align 8
  %v1530 = load i32, ptr %slot167, align 8
  %cv1531 = zext i32 %v1530 to i64
  %cond1532 = icmp ne i64 %cv1531, 0
  br i1 %cond1532, label %bb_rcgnn175, label %bb_rcgstore175
bb_rcgnn175:
  %v1533 = load i64, ptr %slot166, align 8
  %op1534 = sub i64 %v1533, 16
  store i64 %op1534, ptr %slot168, align 8
  %v1535 = load i64, ptr %slot166, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %rgep1537 = getelementptr i8, ptr %p1536, i64 -16
  %ld1538 = load i64, ptr %rgep1537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1538, ptr %slot169, align 8
  %v1539 = load i64, ptr %slot169, align 8
  %op1540 = and i64 %v1539, 4611686018427387906
  store i64 %op1540, ptr %slot170, align 8
  %v1541 = load i64, ptr %slot170, align 8
  %cmp1542 = icmp ne i64 %v1541, 0
  %cv1543 = zext i1 %cmp1542 to i32
  store i32 %cv1543, ptr %slot171, align 8
  %v1544 = load i32, ptr %slot171, align 8
  %cv1545 = zext i32 %v1544 to i64
  %cond1546 = icmp ne i64 %cv1545, 0
  br i1 %cond1546, label %bb_rcgstore175, label %bb_rcginc175
bb_rcginc175:
  %v1547 = load i64, ptr %slot166, align 8
  %op1548 = sub i64 %v1547, 24
  store i64 %op1548, ptr %slot172, align 8
  %v1549 = load i64, ptr %slot166, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %rgep1551 = getelementptr i8, ptr %p1550, i64 -24
  %ld1552 = load i64, ptr %rgep1551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1552, ptr %slot173, align 8
  %v1553 = load i64, ptr %slot173, align 8
  %op1554 = add i64 %v1553, 1
  store i64 %op1554, ptr %slot174, align 8
  %v1555 = load i64, ptr %slot174, align 8
  %cmp1556 = icmp eq i64 %v1555, 0
  %cv1557 = zext i1 %cmp1556 to i32
  store i32 %cv1557, ptr %slot175, align 8
  %v1558 = load i32, ptr %slot175, align 8
  %cv1559 = zext i32 %v1558 to i64
  %cond1560 = icmp ne i64 %cv1559, 0
  br i1 %cond1560, label %bb_rcglimit175, label %bb_rcgcapacity175
bb_rcglimit175:
  %v1561 = load i64, ptr %slot1, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %call1563 = call i32 @myl_qbe_rc_status(ptr %p1562, i32 2) nomerge, !dbg !128
  store i32 %call1563, ptr %slot176, align 8
  br label %bb_failure
bb_rcgcapacity175:
  %v1564 = load i64, ptr %slot174, align 8
  %v1565 = load i64, ptr %slot166, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  %rgep1567 = getelementptr i8, ptr %p1566, i64 -24
  store i64 %v1564, ptr %rgep1567, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore175
bb_rcgstore175:
  %v1568 = load i64, ptr %slot166, align 8
  %v1569 = load i64, ptr %slot165, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i64 %v1568, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot13, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i32 2, ptr %p1572, align 4, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot13, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i32 16, ptr %p1574, align 4, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot12, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  store i32 1, ptr %p1576, align 4, !alias.scope !3, !noalias !4
  %v1577 = load i64, ptr %slot8, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %ld1579 = load i32, ptr %p1578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1579, ptr %slot177, align 8
  %v1580 = load i32, ptr %slot177, align 8
  %cv1581 = zext i32 %v1580 to i64
  %cond1582 = icmp ne i64 %cv1581, 0
  br i1 %cond1582, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v1583 = load i64, ptr %slot8, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 0, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot14, align 8
  store i64 %v1585, ptr %slot178, align 8
  %v1586 = load i64, ptr %slot9, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i32, ptr %p1587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1588, ptr %slot179, align 8
  %v1589 = load i32, ptr %slot179, align 8
  %op1590 = and i32 %v1589, 28
  store i32 %op1590, ptr %slot180, align 8
  %v1591 = load i32, ptr %slot180, align 8
  %cv1592 = zext i32 %v1591 to i64
  %cond1593 = icmp ne i64 %cv1592, 0
  br i1 %cond1593, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v1594 = load i64, ptr %slot40, align 8
  store i64 %v1594, ptr %slot181, align 8
  %v1595 = load i64, ptr %slot181, align 8
  %v1596 = load i64, ptr %slot178, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v1595, i64 %v1596) nomerge, !dbg !128
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v1597 = load i64, ptr %slot40, align 8
  store i64 %v1597, ptr %slot182, align 8
  %v1598 = load i64, ptr %slot182, align 8
  %v1599 = load i64, ptr %slot178, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v1598, i64 %v1599) nomerge, !dbg !128
  br label %bb_rcslotdone191
bb_rcslotdone191:
  %v1600 = load i64, ptr %slot14, align 8
  store i64 %v1600, ptr %slot183, align 8
  %v1601 = load i64, ptr %slot18, align 8
  store i64 %v1601, ptr %slot184, align 8
  %v1602 = load i64, ptr %slot184, align 8
  %v1603 = load i64, ptr %slot183, align 8
  %p1604 = inttoptr i64 %v1602 to ptr
  %p1605 = inttoptr i64 %v1603 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1605, ptr %p1604, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot9, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i32 2, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  %v1608 = load i64, ptr %slot13, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  %ld1610 = load i32, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1610, ptr %slot185, align 8
  %v1611 = load i32, ptr %slot185, align 8
  %v1612 = load i64, ptr %slot9, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 %v1611, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot12, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot8, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i32 1, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot183, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ld1620 = load i64, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1620, ptr %slot186, align 8
  %v1621 = load i64, ptr %slot186, align 8
  %v1622 = load i64, ptr %slot26, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 %v1621, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot26, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i64, ptr %p1625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1626, ptr %slot187, align 8
  %v1627 = load i64, ptr %slot187, align 8
  %v1628 = load i64, ptr %slot16, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i64 %v1627, ptr %p1629, align 8, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot16, align 8
  store i64 %v1630, ptr %slot188, align 8
  %v1631 = load i64, ptr %slot8, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  %ld1633 = load i32, ptr %p1632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1633, ptr %slot189, align 8
  %v1634 = load i64, ptr %slot9, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  %ld1636 = load i32, ptr %p1635, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1636, ptr %slot190, align 8
  %v1637 = load i32, ptr %slot190, align 8
  %op1638 = and i32 %v1637, 24
  store i32 %op1638, ptr %slot190, align 8
  %v1639 = load i32, ptr %slot190, align 8
  %cmp1640 = icmp eq i32 %v1639, 0
  %cv1641 = zext i1 %cmp1640 to i32
  store i32 %cv1641, ptr %slot191, align 8
  %v1642 = load i32, ptr %slot189, align 8
  %v1643 = load i32, ptr %slot191, align 8
  %op1644 = and i32 %v1642, %v1643
  store i32 %op1644, ptr %slot192, align 8
  %v1645 = load i32, ptr %slot192, align 8
  %cv1646 = zext i32 %v1645 to i64
  %cond1647 = icmp ne i64 %cv1646, 0
  br i1 %cond1647, label %bb_rcprivateown215, label %bb_rcprivateloan215
bb_rcprivateown215:
  %v1648 = load i64, ptr %slot18, align 8
  store i64 %v1648, ptr %slot193, align 8
  %v1649 = load i64, ptr %slot41, align 8
  store i64 %v1649, ptr %slot194, align 8
  %v1650 = load i64, ptr %slot188, align 8
  %v1651 = load i64, ptr %slot193, align 8
  %op1652 = sub i64 %v1650, %v1651
  store i64 %op1652, ptr %slot195, align 8
  %v1653 = load i64, ptr %slot193, align 8
  %v1654 = load i64, ptr %slot188, align 8
  %op1655 = sub i64 %v1653, %v1654
  store i64 %op1655, ptr %slot196, align 8
  %v1656 = load i64, ptr %slot195, align 8
  %cmp1657 = icmp ult i64 %v1656, 8
  %cv1658 = zext i1 %cmp1657 to i32
  store i32 %cv1658, ptr %slot197, align 8
  %v1659 = load i64, ptr %slot196, align 8
  %cmp1660 = icmp ult i64 %v1659, 8
  %cv1661 = zext i1 %cmp1660 to i32
  store i32 %cv1661, ptr %slot198, align 8
  %v1662 = load i32, ptr %slot197, align 8
  %v1663 = load i32, ptr %slot198, align 8
  %op1664 = or i32 %v1662, %v1663
  store i32 %op1664, ptr %slot199, align 8
  %v1665 = load i32, ptr %slot199, align 8
  %cv1666 = zext i32 %v1665 to i64
  %cond1667 = icmp ne i64 %cv1666, 0
  br i1 %cond1667, label %bb_rcmoveslow218, label %bb_rcmovecheck218
bb_rcmovecheck218:
  %v1668 = load i64, ptr %slot188, align 8
  %p1670 = inttoptr i64 %v1668 to ptr
  %gep1671 = getelementptr i8, ptr %p1670, i64 0
  %op1669 = ptrtoint ptr %gep1671 to i64
  store i64 %op1669, ptr %slot200, align 8
  %v1672 = load i64, ptr %slot200, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %ld1674 = load i64, ptr %p1673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1674, ptr %slot201, align 8
  %v1675 = load i64, ptr %slot201, align 8
  %cmp1676 = icmp ne i64 %v1675, 0
  %cv1677 = zext i1 %cmp1676 to i32
  store i32 %cv1677, ptr %slot202, align 8
  %v1678 = load i32, ptr %slot202, align 8
  %cv1679 = zext i32 %v1678 to i64
  %cond1680 = icmp ne i64 %cv1679, 0
  br i1 %cond1680, label %bb_rcmoveheader226, label %bb_rcmovenext226
bb_rcmoveheader226:
  %v1681 = load i64, ptr %slot201, align 8
  %op1682 = sub i64 %v1681, 16
  store i64 %op1682, ptr %slot203, align 8
  %v1683 = load i64, ptr %slot201, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  %rgep1685 = getelementptr i8, ptr %p1684, i64 -16
  %ld1686 = load i64, ptr %rgep1685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1686, ptr %slot204, align 8
  %v1687 = load i64, ptr %slot204, align 8
  %op1688 = and i64 %v1687, 5764607523034234881
  store i64 %op1688, ptr %slot205, align 8
  %v1689 = load i64, ptr %slot205, align 8
  %cmp1690 = icmp ne i64 %v1689, 0
  %cv1691 = zext i1 %cmp1690 to i32
  store i32 %cv1691, ptr %slot206, align 8
  %v1692 = load i32, ptr %slot206, align 8
  %cv1693 = zext i32 %v1692 to i64
  %cond1694 = icmp ne i64 %cv1693, 0
  br i1 %cond1694, label %bb_rcmoveslow218, label %bb_rcmovenext226
bb_rcmovenext226:
  %v1695 = load i64, ptr %slot188, align 8
  %v1696 = load i64, ptr %slot193, align 8
  %p1697 = inttoptr i64 %v1695 to ptr
  %p1698 = inttoptr i64 %v1696 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1698, ptr %p1697, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot188, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i64 0, ptr %p1700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved218
bb_rcmoveslow218:
  %v1701 = load i64, ptr %slot40, align 8
  %v1702 = load i64, ptr %slot193, align 8
  %v1703 = load i64, ptr %slot188, align 8
  %v1704 = load i64, ptr %slot194, align 8
  %cv1705 = trunc i64 %v1704 to i32
  %call1706 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1701, i64 %v1702, i64 %v1703, i32 %cv1705) nomerge, !dbg !130
  store i32 %call1706, ptr %slot207, align 8
  %v1707 = load i32, ptr %slot207, align 8
  %cv1708 = zext i32 %v1707 to i64
  %cond1709 = icmp ne i64 %cv1708, 0
  br i1 %cond1709, label %bb_rcsuccess233, label %bb_rcfailure233
bb_rcfailure233:
  %v1710 = load i64, ptr %slot40, align 8
  %p1711 = inttoptr i64 %v1710 to ptr
  %call1712 = call i32 @myl_rc_take_failure(ptr %p1711) nomerge, !dbg !130
  store i32 %call1712, ptr %slot208, align 8
  %v1713 = load i64, ptr %slot1, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  %v1715 = load i32, ptr %slot208, align 8
  %call1716 = call i32 @myl_qbe_rc_status(ptr %p1714, i32 %v1715) nomerge, !dbg !130
  store i32 %call1716, ptr %slot209, align 8
  br label %bb_failure
bb_rcsuccess233:
  br label %bb_rcmoved218
bb_rcmoved218:
  %v1717 = load i64, ptr %slot8, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i32 0, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot13, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i32 2, ptr %p1720, align 4, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot12, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i32 1, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared215
bb_rcprivateloan215:
  %v1723 = load i64, ptr %slot8, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %ld1725 = load i32, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1725, ptr %slot210, align 8
  %v1726 = load i64, ptr %slot9, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %ld1728 = load i32, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1728, ptr %slot211, align 8
  %v1729 = load i32, ptr %slot211, align 8
  %cmp1730 = icmp eq i32 %v1729, 16
  %cv1731 = zext i1 %cmp1730 to i32
  store i32 %cv1731, ptr %slot212, align 8
  %v1732 = load i32, ptr %slot212, align 8
  %v1733 = load i32, ptr %slot210, align 8
  %op1734 = and i32 %v1732, %v1733
  store i32 %op1734, ptr %slot212, align 8
  %v1735 = load i32, ptr %slot212, align 8
  %cv1736 = zext i32 %v1735 to i64
  %cond1737 = icmp ne i64 %cv1736, 0
  br i1 %cond1737, label %bb_rcprivatemove215, label %bb_rcprivatenew215
bb_rcprivatemove215:
  %v1738 = load i64, ptr %slot18, align 8
  store i64 %v1738, ptr %slot213, align 8
  %v1739 = load i64, ptr %slot188, align 8
  %v1740 = load i64, ptr %slot213, align 8
  %p1741 = inttoptr i64 %v1739 to ptr
  %p1742 = inttoptr i64 %v1740 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1742, ptr %p1741, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot188, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i64 0, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot13, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i32 2, ptr %p1746, align 4, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot13, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i32 16, ptr %p1748, align 4, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot12, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i32 1, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot8, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  store i32 0, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared215
bb_rcprivatenew215:
  %v1753 = load i64, ptr %slot18, align 8
  store i64 %v1753, ptr %slot214, align 8
  %v1754 = load i64, ptr %slot188, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %ld1756 = load i64, ptr %p1755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1756, ptr %slot215, align 8
  %v1757 = load i64, ptr %slot215, align 8
  %cmp1758 = icmp ne i64 %v1757, 0
  %cv1759 = zext i1 %cmp1758 to i32
  store i32 %cv1759, ptr %slot216, align 8
  %v1760 = load i32, ptr %slot216, align 8
  %cv1761 = zext i32 %v1760 to i64
  %cond1762 = icmp ne i64 %cv1761, 0
  br i1 %cond1762, label %bb_rcgnn251, label %bb_rcgstore251
bb_rcgnn251:
  %v1763 = load i64, ptr %slot215, align 8
  %op1764 = sub i64 %v1763, 16
  store i64 %op1764, ptr %slot217, align 8
  %v1765 = load i64, ptr %slot215, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %rgep1767 = getelementptr i8, ptr %p1766, i64 -16
  %ld1768 = load i64, ptr %rgep1767, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1768, ptr %slot218, align 8
  %v1769 = load i64, ptr %slot218, align 8
  %op1770 = and i64 %v1769, 4611686018427387906
  store i64 %op1770, ptr %slot219, align 8
  %v1771 = load i64, ptr %slot219, align 8
  %cmp1772 = icmp ne i64 %v1771, 0
  %cv1773 = zext i1 %cmp1772 to i32
  store i32 %cv1773, ptr %slot220, align 8
  %v1774 = load i32, ptr %slot220, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcgstore251, label %bb_rcginc251
bb_rcginc251:
  %v1777 = load i64, ptr %slot215, align 8
  %op1778 = sub i64 %v1777, 24
  store i64 %op1778, ptr %slot221, align 8
  %v1779 = load i64, ptr %slot215, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %rgep1781 = getelementptr i8, ptr %p1780, i64 -24
  %ld1782 = load i64, ptr %rgep1781, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1782, ptr %slot222, align 8
  %v1783 = load i64, ptr %slot222, align 8
  %op1784 = add i64 %v1783, 1
  store i64 %op1784, ptr %slot223, align 8
  %v1785 = load i64, ptr %slot223, align 8
  %cmp1786 = icmp eq i64 %v1785, 0
  %cv1787 = zext i1 %cmp1786 to i32
  store i32 %cv1787, ptr %slot224, align 8
  %v1788 = load i32, ptr %slot224, align 8
  %cv1789 = zext i32 %v1788 to i64
  %cond1790 = icmp ne i64 %cv1789, 0
  br i1 %cond1790, label %bb_rcglimit251, label %bb_rcgcapacity251
bb_rcglimit251:
  %v1791 = load i64, ptr %slot1, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %call1793 = call i32 @myl_qbe_rc_status(ptr %p1792, i32 2) nomerge, !dbg !130
  store i32 %call1793, ptr %slot225, align 8
  br label %bb_failure
bb_rcgcapacity251:
  %v1794 = load i64, ptr %slot223, align 8
  %v1795 = load i64, ptr %slot215, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  %rgep1797 = getelementptr i8, ptr %p1796, i64 -24
  store i64 %v1794, ptr %rgep1797, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore251
bb_rcgstore251:
  %v1798 = load i64, ptr %slot215, align 8
  %v1799 = load i64, ptr %slot214, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i64 %v1798, ptr %p1800, align 8, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot13, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i32 2, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot13, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 16, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot12, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i32 1, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot8, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %ld1809 = load i32, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1809, ptr %slot226, align 8
  %v1810 = load i32, ptr %slot226, align 8
  %cv1811 = zext i32 %v1810 to i64
  %cond1812 = icmp ne i64 %cv1811, 0
  br i1 %cond1812, label %bb_rcslotdrop267, label %bb_rcslotdone267
bb_rcslotdrop267:
  %v1813 = load i64, ptr %slot8, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 0, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot14, align 8
  store i64 %v1815, ptr %slot227, align 8
  %v1816 = load i64, ptr %slot9, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %ld1818 = load i32, ptr %p1817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1818, ptr %slot228, align 8
  %v1819 = load i32, ptr %slot228, align 8
  %op1820 = and i32 %v1819, 28
  store i32 %op1820, ptr %slot229, align 8
  %v1821 = load i32, ptr %slot229, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcslotrole267, label %bb_rcslotowner267
bb_rcslotrole267:
  %v1824 = load i64, ptr %slot40, align 8
  store i64 %v1824, ptr %slot230, align 8
  %v1825 = load i64, ptr %slot227, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i64, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1827, ptr %slot231, align 8
  %v1828 = load i64, ptr %slot231, align 8
  %cmp1829 = icmp ne i64 %v1828, 0
  %cv1830 = zext i1 %cmp1829 to i32
  store i32 %cv1830, ptr %slot232, align 8
  %v1831 = load i32, ptr %slot232, align 8
  %cv1832 = zext i32 %v1831 to i64
  %cond1833 = icmp ne i64 %cv1832, 0
  br i1 %cond1833, label %bb_rcgnn283, label %bb_rcgdone283
bb_rcgnn283:
  %v1834 = load i64, ptr %slot231, align 8
  %op1835 = sub i64 %v1834, 16
  store i64 %op1835, ptr %slot233, align 8
  %v1836 = load i64, ptr %slot231, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %rgep1838 = getelementptr i8, ptr %p1837, i64 -16
  %ld1839 = load i64, ptr %rgep1838, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1839, ptr %slot234, align 8
  %v1840 = load i64, ptr %slot234, align 8
  %op1841 = and i64 %v1840, 4611686018427387906
  store i64 %op1841, ptr %slot235, align 8
  %v1842 = load i64, ptr %slot235, align 8
  %cmp1843 = icmp ne i64 %v1842, 0
  %cv1844 = zext i1 %cmp1843 to i32
  store i32 %cv1844, ptr %slot236, align 8
  %v1845 = load i32, ptr %slot236, align 8
  %cv1846 = zext i32 %v1845 to i64
  %cond1847 = icmp ne i64 %cv1846, 0
  br i1 %cond1847, label %bb_rcgclear283, label %bb_rcgcounted283
bb_rcgcounted283:
  %v1848 = load i64, ptr %slot231, align 8
  %op1849 = sub i64 %v1848, 24
  store i64 %op1849, ptr %slot237, align 8
  %v1850 = load i64, ptr %slot231, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %rgep1852 = getelementptr i8, ptr %p1851, i64 -24
  %ld1853 = load i64, ptr %rgep1852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1853, ptr %slot238, align 8
  %v1854 = load i64, ptr %slot238, align 8
  %op1855 = sub i64 %v1854, 1
  store i64 %op1855, ptr %slot239, align 8
  %v1856 = load i64, ptr %slot239, align 8
  %cmp1857 = icmp eq i64 %v1856, 0
  %cv1858 = zext i1 %cmp1857 to i32
  store i32 %cv1858, ptr %slot240, align 8
  %v1859 = load i32, ptr %slot240, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcglast283, label %bb_rcgdec283
bb_rcglast283:
  %v1862 = load i64, ptr %slot231, align 8
  %op1863 = sub i64 %v1862, 32
  store i64 %op1863, ptr %slot241, align 8
  %v1864 = load i64, ptr %slot231, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %rgep1866 = getelementptr i8, ptr %p1865, i64 -32
  %ld1867 = load i64, ptr %rgep1866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1867, ptr %slot242, align 8
  %v1868 = load i64, ptr %slot242, align 8
  %cmp1869 = icmp ne i64 %v1868, 0
  %cv1870 = zext i1 %cmp1869 to i32
  store i32 %cv1870, ptr %slot243, align 8
  %v1871 = load i32, ptr %slot243, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcgdec283, label %bb_rcgslow283
bb_rcgslow283:
  %v1874 = load i64, ptr %slot230, align 8
  %v1875 = load i64, ptr %slot227, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1874, i64 %v1875) nomerge, !dbg !130
  br label %bb_rcgdone283
bb_rcgdec283:
  %v1876 = load i64, ptr %slot239, align 8
  %v1877 = load i64, ptr %slot231, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -24
  store i64 %v1876, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear283
bb_rcgclear283:
  %v1880 = load i64, ptr %slot227, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i64 0, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone283
bb_rcgdone283:
  br label %bb_rcslotdone267
bb_rcslotowner267:
  %v1882 = load i64, ptr %slot40, align 8
  store i64 %v1882, ptr %slot244, align 8
  %v1883 = load i64, ptr %slot227, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %ld1885 = load i64, ptr %p1884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1885, ptr %slot245, align 8
  %v1886 = load i64, ptr %slot245, align 8
  %cmp1887 = icmp ne i64 %v1886, 0
  %cv1888 = zext i1 %cmp1887 to i32
  store i32 %cv1888, ptr %slot246, align 8
  %v1889 = load i32, ptr %slot246, align 8
  %cv1890 = zext i32 %v1889 to i64
  %cond1891 = icmp ne i64 %cv1890, 0
  br i1 %cond1891, label %bb_rcgnn298, label %bb_rcgdone298
bb_rcgnn298:
  %v1892 = load i64, ptr %slot245, align 8
  %op1893 = sub i64 %v1892, 16
  store i64 %op1893, ptr %slot247, align 8
  %v1894 = load i64, ptr %slot245, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %rgep1896 = getelementptr i8, ptr %p1895, i64 -16
  %ld1897 = load i64, ptr %rgep1896, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1897, ptr %slot248, align 8
  %v1898 = load i64, ptr %slot248, align 8
  %op1899 = and i64 %v1898, 4611686018427387906
  store i64 %op1899, ptr %slot249, align 8
  %v1900 = load i64, ptr %slot249, align 8
  %cmp1901 = icmp ne i64 %v1900, 0
  %cv1902 = zext i1 %cmp1901 to i32
  store i32 %cv1902, ptr %slot250, align 8
  %v1903 = load i32, ptr %slot250, align 8
  %cv1904 = zext i32 %v1903 to i64
  %cond1905 = icmp ne i64 %cv1904, 0
  br i1 %cond1905, label %bb_rcgclear298, label %bb_rcgcounted298
bb_rcgcounted298:
  %v1906 = load i64, ptr %slot245, align 8
  %op1907 = sub i64 %v1906, 32
  store i64 %op1907, ptr %slot251, align 8
  %v1908 = load i64, ptr %slot245, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %rgep1910 = getelementptr i8, ptr %p1909, i64 -32
  %ld1911 = load i64, ptr %rgep1910, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1911, ptr %slot252, align 8
  %v1912 = load i64, ptr %slot252, align 8
  %op1913 = sub i64 %v1912, 1
  store i64 %op1913, ptr %slot253, align 8
  %v1914 = load i64, ptr %slot253, align 8
  %cmp1915 = icmp eq i64 %v1914, 0
  %cv1916 = zext i1 %cmp1915 to i32
  store i32 %cv1916, ptr %slot254, align 8
  %v1917 = load i32, ptr %slot254, align 8
  %cv1918 = zext i32 %v1917 to i64
  %cond1919 = icmp ne i64 %cv1918, 0
  br i1 %cond1919, label %bb_rcglast298, label %bb_rcgdec298
bb_rcglast298:
  %v1920 = load i64, ptr %slot245, align 8
  %op1921 = sub i64 %v1920, 24
  store i64 %op1921, ptr %slot255, align 8
  %v1922 = load i64, ptr %slot245, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %rgep1924 = getelementptr i8, ptr %p1923, i64 -24
  %ld1925 = load i64, ptr %rgep1924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1925, ptr %slot256, align 8
  %v1926 = load i64, ptr %slot256, align 8
  %cmp1927 = icmp ne i64 %v1926, 0
  %cv1928 = zext i1 %cmp1927 to i32
  store i32 %cv1928, ptr %slot257, align 8
  %v1929 = load i32, ptr %slot257, align 8
  %cv1930 = zext i32 %v1929 to i64
  %cond1931 = icmp ne i64 %cv1930, 0
  br i1 %cond1931, label %bb_rcgdec298, label %bb_rcgslow298
bb_rcgslow298:
  %v1932 = load i64, ptr %slot244, align 8
  %v1933 = load i64, ptr %slot227, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1932, i64 %v1933) nomerge, !dbg !130
  br label %bb_rcgdone298
bb_rcgdec298:
  %v1934 = load i64, ptr %slot253, align 8
  %v1935 = load i64, ptr %slot245, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %rgep1937 = getelementptr i8, ptr %p1936, i64 -32
  store i64 %v1934, ptr %rgep1937, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear298
bb_rcgclear298:
  %v1938 = load i64, ptr %slot227, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i64 0, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone298
bb_rcgdone298:
  br label %bb_rcslotdone267
bb_rcslotdone267:
  br label %bb_rcprivateprepared215
bb_rcprivateprepared215:
  %v1940 = load i64, ptr %slot4, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i32, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1942, ptr %slot258, align 8
  %v1943 = load i32, ptr %slot258, align 8
  %cv1944 = zext i32 %v1943 to i64
  %cond1945 = icmp ne i64 %cv1944, 0
  br i1 %cond1945, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v1946 = load i64, ptr %slot4, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  store i32 0, ptr %p1947, align 4, !alias.scope !3, !noalias !4
  %v1948 = load i64, ptr %slot20, align 8
  store i64 %v1948, ptr %slot259, align 8
  %v1949 = load i64, ptr %slot5, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %ld1951 = load i32, ptr %p1950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1951, ptr %slot260, align 8
  %v1952 = load i32, ptr %slot260, align 8
  %op1953 = and i32 %v1952, 28
  store i32 %op1953, ptr %slot261, align 8
  %v1954 = load i32, ptr %slot261, align 8
  %cv1955 = zext i32 %v1954 to i64
  %cond1956 = icmp ne i64 %cv1955, 0
  br i1 %cond1956, label %bb_rcslotrole305, label %bb_rcslotowner305
bb_rcslotrole305:
  %v1957 = load i64, ptr %slot40, align 8
  store i64 %v1957, ptr %slot262, align 8
  %v1958 = load i64, ptr %slot259, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %ld1960 = load i64, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1960, ptr %slot263, align 8
  %v1961 = load i64, ptr %slot263, align 8
  %cmp1962 = icmp ne i64 %v1961, 0
  %cv1963 = zext i1 %cmp1962 to i32
  store i32 %cv1963, ptr %slot264, align 8
  %v1964 = load i32, ptr %slot264, align 8
  %cv1965 = zext i32 %v1964 to i64
  %cond1966 = icmp ne i64 %cv1965, 0
  br i1 %cond1966, label %bb_rcgnn321, label %bb_rcgdone321
bb_rcgnn321:
  %v1967 = load i64, ptr %slot263, align 8
  %op1968 = sub i64 %v1967, 16
  store i64 %op1968, ptr %slot265, align 8
  %v1969 = load i64, ptr %slot263, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  %rgep1971 = getelementptr i8, ptr %p1970, i64 -16
  %ld1972 = load i64, ptr %rgep1971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1972, ptr %slot266, align 8
  %v1973 = load i64, ptr %slot266, align 8
  %op1974 = and i64 %v1973, 4611686018427387906
  store i64 %op1974, ptr %slot267, align 8
  %v1975 = load i64, ptr %slot267, align 8
  %cmp1976 = icmp ne i64 %v1975, 0
  %cv1977 = zext i1 %cmp1976 to i32
  store i32 %cv1977, ptr %slot268, align 8
  %v1978 = load i32, ptr %slot268, align 8
  %cv1979 = zext i32 %v1978 to i64
  %cond1980 = icmp ne i64 %cv1979, 0
  br i1 %cond1980, label %bb_rcgclear321, label %bb_rcgcounted321
bb_rcgcounted321:
  %v1981 = load i64, ptr %slot263, align 8
  %op1982 = sub i64 %v1981, 24
  store i64 %op1982, ptr %slot269, align 8
  %v1983 = load i64, ptr %slot263, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %rgep1985 = getelementptr i8, ptr %p1984, i64 -24
  %ld1986 = load i64, ptr %rgep1985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1986, ptr %slot270, align 8
  %v1987 = load i64, ptr %slot270, align 8
  %op1988 = sub i64 %v1987, 1
  store i64 %op1988, ptr %slot271, align 8
  %v1989 = load i64, ptr %slot271, align 8
  %cmp1990 = icmp eq i64 %v1989, 0
  %cv1991 = zext i1 %cmp1990 to i32
  store i32 %cv1991, ptr %slot272, align 8
  %v1992 = load i32, ptr %slot272, align 8
  %cv1993 = zext i32 %v1992 to i64
  %cond1994 = icmp ne i64 %cv1993, 0
  br i1 %cond1994, label %bb_rcglast321, label %bb_rcgdec321
bb_rcglast321:
  %v1995 = load i64, ptr %slot263, align 8
  %op1996 = sub i64 %v1995, 32
  store i64 %op1996, ptr %slot273, align 8
  %v1997 = load i64, ptr %slot263, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %rgep1999 = getelementptr i8, ptr %p1998, i64 -32
  %ld2000 = load i64, ptr %rgep1999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2000, ptr %slot274, align 8
  %v2001 = load i64, ptr %slot274, align 8
  %cmp2002 = icmp ne i64 %v2001, 0
  %cv2003 = zext i1 %cmp2002 to i32
  store i32 %cv2003, ptr %slot275, align 8
  %v2004 = load i32, ptr %slot275, align 8
  %cv2005 = zext i32 %v2004 to i64
  %cond2006 = icmp ne i64 %cv2005, 0
  br i1 %cond2006, label %bb_rcgdec321, label %bb_rcgslow321
bb_rcgslow321:
  %v2007 = load i64, ptr %slot262, align 8
  %v2008 = load i64, ptr %slot259, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2007, i64 %v2008) nomerge, !dbg !130
  br label %bb_rcgdone321
bb_rcgdec321:
  %v2009 = load i64, ptr %slot271, align 8
  %v2010 = load i64, ptr %slot263, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  %rgep2012 = getelementptr i8, ptr %p2011, i64 -24
  store i64 %v2009, ptr %rgep2012, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear321
bb_rcgclear321:
  %v2013 = load i64, ptr %slot259, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  store i64 0, ptr %p2014, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone321
bb_rcgdone321:
  br label %bb_rcslotdone305
bb_rcslotowner305:
  %v2015 = load i64, ptr %slot40, align 8
  store i64 %v2015, ptr %slot276, align 8
  %v2016 = load i64, ptr %slot259, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %ld2018 = load i64, ptr %p2017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2018, ptr %slot277, align 8
  %v2019 = load i64, ptr %slot277, align 8
  %cmp2020 = icmp ne i64 %v2019, 0
  %cv2021 = zext i1 %cmp2020 to i32
  store i32 %cv2021, ptr %slot278, align 8
  %v2022 = load i32, ptr %slot278, align 8
  %cv2023 = zext i32 %v2022 to i64
  %cond2024 = icmp ne i64 %cv2023, 0
  br i1 %cond2024, label %bb_rcgnn336, label %bb_rcgdone336
bb_rcgnn336:
  %v2025 = load i64, ptr %slot277, align 8
  %op2026 = sub i64 %v2025, 16
  store i64 %op2026, ptr %slot279, align 8
  %v2027 = load i64, ptr %slot277, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %rgep2029 = getelementptr i8, ptr %p2028, i64 -16
  %ld2030 = load i64, ptr %rgep2029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2030, ptr %slot280, align 8
  %v2031 = load i64, ptr %slot280, align 8
  %op2032 = and i64 %v2031, 4611686018427387906
  store i64 %op2032, ptr %slot281, align 8
  %v2033 = load i64, ptr %slot281, align 8
  %cmp2034 = icmp ne i64 %v2033, 0
  %cv2035 = zext i1 %cmp2034 to i32
  store i32 %cv2035, ptr %slot282, align 8
  %v2036 = load i32, ptr %slot282, align 8
  %cv2037 = zext i32 %v2036 to i64
  %cond2038 = icmp ne i64 %cv2037, 0
  br i1 %cond2038, label %bb_rcgclear336, label %bb_rcgcounted336
bb_rcgcounted336:
  %v2039 = load i64, ptr %slot277, align 8
  %op2040 = sub i64 %v2039, 32
  store i64 %op2040, ptr %slot283, align 8
  %v2041 = load i64, ptr %slot277, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  %rgep2043 = getelementptr i8, ptr %p2042, i64 -32
  %ld2044 = load i64, ptr %rgep2043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2044, ptr %slot284, align 8
  %v2045 = load i64, ptr %slot284, align 8
  %op2046 = sub i64 %v2045, 1
  store i64 %op2046, ptr %slot285, align 8
  %v2047 = load i64, ptr %slot285, align 8
  %cmp2048 = icmp eq i64 %v2047, 0
  %cv2049 = zext i1 %cmp2048 to i32
  store i32 %cv2049, ptr %slot286, align 8
  %v2050 = load i32, ptr %slot286, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcglast336, label %bb_rcgdec336
bb_rcglast336:
  %v2053 = load i64, ptr %slot277, align 8
  %op2054 = sub i64 %v2053, 24
  store i64 %op2054, ptr %slot287, align 8
  %v2055 = load i64, ptr %slot277, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %rgep2057 = getelementptr i8, ptr %p2056, i64 -24
  %ld2058 = load i64, ptr %rgep2057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2058, ptr %slot288, align 8
  %v2059 = load i64, ptr %slot288, align 8
  %cmp2060 = icmp ne i64 %v2059, 0
  %cv2061 = zext i1 %cmp2060 to i32
  store i32 %cv2061, ptr %slot289, align 8
  %v2062 = load i32, ptr %slot289, align 8
  %cv2063 = zext i32 %v2062 to i64
  %cond2064 = icmp ne i64 %cv2063, 0
  br i1 %cond2064, label %bb_rcgdec336, label %bb_rcgslow336
bb_rcgslow336:
  %v2065 = load i64, ptr %slot276, align 8
  %v2066 = load i64, ptr %slot259, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2065, i64 %v2066) nomerge, !dbg !130
  br label %bb_rcgdone336
bb_rcgdec336:
  %v2067 = load i64, ptr %slot285, align 8
  %v2068 = load i64, ptr %slot277, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  %rgep2070 = getelementptr i8, ptr %p2069, i64 -32
  store i64 %v2067, ptr %rgep2070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear336
bb_rcgclear336:
  %v2071 = load i64, ptr %slot259, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i64 0, ptr %p2072, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone336
bb_rcgdone336:
  br label %bb_rcslotdone305
bb_rcslotdone305:
  %v2073 = load i64, ptr %slot20, align 8
  store i64 %v2073, ptr %slot290, align 8
  %v2074 = load i64, ptr %slot18, align 8
  store i64 %v2074, ptr %slot291, align 8
  %v2075 = load i64, ptr %slot291, align 8
  %v2076 = load i64, ptr %slot290, align 8
  %p2077 = inttoptr i64 %v2075 to ptr
  %p2078 = inttoptr i64 %v2076 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2078, ptr %p2077, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2079 = load i64, ptr %slot12, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i32 0, ptr %p2080, align 4, !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot5, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 2, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot13, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i32, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2085, ptr %slot292, align 8
  %v2086 = load i32, ptr %slot292, align 8
  %v2087 = load i64, ptr %slot5, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i32 %v2086, ptr %p2088, align 4, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot4, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 1, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot20, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i64, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2093, ptr %slot293, align 8
  %v2094 = load i64, ptr %slot293, align 8
  %op2095 = add i64 %v2094, 0
  store i64 %op2095, ptr %slot294, align 8
  %v2096 = load i64, ptr %slot294, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  %ld2098 = load i64, ptr %p2097, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2098, ptr %slot295, align 8
  %v2099 = load i64, ptr %slot295, align 8
  %v2100 = load i64, ptr %slot26, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  store i64 %v2099, ptr %p2101, align 8, !alias.scope !3, !noalias !4
  %v2102 = load i64, ptr %slot26, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  %ld2104 = load i64, ptr %p2103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2104, ptr %slot296, align 8
  %v2105 = load i64, ptr %slot296, align 8
  %cmp2106 = icmp ugt i64 %v2105, 9223372036854775807
  %cv2107 = zext i1 %cmp2106 to i64
  store i64 %cv2107, ptr %slot297, align 8
  %v2108 = load i64, ptr %slot297, align 8
  %cond2109 = icmp ne i64 %v2108, 0
  br i1 %cond2109, label %bb_cast_overflow352, label %bb_cast_ok352
bb_cast_overflow352:
  %v2110 = load i64, ptr %slot1, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %v2112 = load i64, ptr %slot296, align 8
  call void @myl_qbe_fail_cast(ptr %p2111, i64 %v2112, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok352:
  %v2113 = load i64, ptr %slot296, align 8
  %v2114 = load i64, ptr %slot26, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  store i64 %v2113, ptr %p2115, align 8, !alias.scope !3, !noalias !4
  %v2116 = load i64, ptr %slot26, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2118, ptr %slot298, align 8
  %v2119 = load i64, ptr %slot298, align 8
  %v2120 = load i64, ptr %slot21, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i64 %v2119, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot4, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i32, ptr %p2123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2124, ptr %slot299, align 8
  %v2125 = load i32, ptr %slot299, align 8
  %cv2126 = zext i32 %v2125 to i64
  %cond2127 = icmp ne i64 %cv2126, 0
  br i1 %cond2127, label %bb_rcslotdrop356, label %bb_rcslotdone356
bb_rcslotdrop356:
  %v2128 = load i64, ptr %slot4, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i32 0, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot20, align 8
  store i64 %v2130, ptr %slot300, align 8
  %v2131 = load i64, ptr %slot5, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i32, ptr %p2132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2133, ptr %slot301, align 8
  %v2134 = load i32, ptr %slot301, align 8
  %op2135 = and i32 %v2134, 28
  store i32 %op2135, ptr %slot302, align 8
  %v2136 = load i32, ptr %slot302, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcslotrole356, label %bb_rcslotowner356
bb_rcslotrole356:
  %v2139 = load i64, ptr %slot40, align 8
  store i64 %v2139, ptr %slot303, align 8
  %v2140 = load i64, ptr %slot300, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i64, ptr %p2141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2142, ptr %slot304, align 8
  %v2143 = load i64, ptr %slot304, align 8
  %cmp2144 = icmp ne i64 %v2143, 0
  %cv2145 = zext i1 %cmp2144 to i32
  store i32 %cv2145, ptr %slot305, align 8
  %v2146 = load i32, ptr %slot305, align 8
  %cv2147 = zext i32 %v2146 to i64
  %cond2148 = icmp ne i64 %cv2147, 0
  br i1 %cond2148, label %bb_rcgnn372, label %bb_rcgdone372
bb_rcgnn372:
  %v2149 = load i64, ptr %slot304, align 8
  %op2150 = sub i64 %v2149, 16
  store i64 %op2150, ptr %slot306, align 8
  %v2151 = load i64, ptr %slot304, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %rgep2153 = getelementptr i8, ptr %p2152, i64 -16
  %ld2154 = load i64, ptr %rgep2153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2154, ptr %slot307, align 8
  %v2155 = load i64, ptr %slot307, align 8
  %op2156 = and i64 %v2155, 4611686018427387906
  store i64 %op2156, ptr %slot308, align 8
  %v2157 = load i64, ptr %slot308, align 8
  %cmp2158 = icmp ne i64 %v2157, 0
  %cv2159 = zext i1 %cmp2158 to i32
  store i32 %cv2159, ptr %slot309, align 8
  %v2160 = load i32, ptr %slot309, align 8
  %cv2161 = zext i32 %v2160 to i64
  %cond2162 = icmp ne i64 %cv2161, 0
  br i1 %cond2162, label %bb_rcgclear372, label %bb_rcgcounted372
bb_rcgcounted372:
  %v2163 = load i64, ptr %slot304, align 8
  %op2164 = sub i64 %v2163, 24
  store i64 %op2164, ptr %slot310, align 8
  %v2165 = load i64, ptr %slot304, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %rgep2167 = getelementptr i8, ptr %p2166, i64 -24
  %ld2168 = load i64, ptr %rgep2167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2168, ptr %slot311, align 8
  %v2169 = load i64, ptr %slot311, align 8
  %op2170 = sub i64 %v2169, 1
  store i64 %op2170, ptr %slot312, align 8
  %v2171 = load i64, ptr %slot312, align 8
  %cmp2172 = icmp eq i64 %v2171, 0
  %cv2173 = zext i1 %cmp2172 to i32
  store i32 %cv2173, ptr %slot313, align 8
  %v2174 = load i32, ptr %slot313, align 8
  %cv2175 = zext i32 %v2174 to i64
  %cond2176 = icmp ne i64 %cv2175, 0
  br i1 %cond2176, label %bb_rcglast372, label %bb_rcgdec372
bb_rcglast372:
  %v2177 = load i64, ptr %slot304, align 8
  %op2178 = sub i64 %v2177, 32
  store i64 %op2178, ptr %slot314, align 8
  %v2179 = load i64, ptr %slot304, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %rgep2181 = getelementptr i8, ptr %p2180, i64 -32
  %ld2182 = load i64, ptr %rgep2181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2182, ptr %slot315, align 8
  %v2183 = load i64, ptr %slot315, align 8
  %cmp2184 = icmp ne i64 %v2183, 0
  %cv2185 = zext i1 %cmp2184 to i32
  store i32 %cv2185, ptr %slot316, align 8
  %v2186 = load i32, ptr %slot316, align 8
  %cv2187 = zext i32 %v2186 to i64
  %cond2188 = icmp ne i64 %cv2187, 0
  br i1 %cond2188, label %bb_rcgdec372, label %bb_rcgslow372
bb_rcgslow372:
  %v2189 = load i64, ptr %slot303, align 8
  %v2190 = load i64, ptr %slot300, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2189, i64 %v2190) nomerge, !dbg !134
  br label %bb_rcgdone372
bb_rcgdec372:
  %v2191 = load i64, ptr %slot312, align 8
  %v2192 = load i64, ptr %slot304, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %rgep2194 = getelementptr i8, ptr %p2193, i64 -24
  store i64 %v2191, ptr %rgep2194, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear372
bb_rcgclear372:
  %v2195 = load i64, ptr %slot300, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i64 0, ptr %p2196, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone372
bb_rcgdone372:
  br label %bb_rcslotdone356
bb_rcslotowner356:
  %v2197 = load i64, ptr %slot40, align 8
  store i64 %v2197, ptr %slot317, align 8
  %v2198 = load i64, ptr %slot300, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  %ld2200 = load i64, ptr %p2199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2200, ptr %slot318, align 8
  %v2201 = load i64, ptr %slot318, align 8
  %cmp2202 = icmp ne i64 %v2201, 0
  %cv2203 = zext i1 %cmp2202 to i32
  store i32 %cv2203, ptr %slot319, align 8
  %v2204 = load i32, ptr %slot319, align 8
  %cv2205 = zext i32 %v2204 to i64
  %cond2206 = icmp ne i64 %cv2205, 0
  br i1 %cond2206, label %bb_rcgnn387, label %bb_rcgdone387
bb_rcgnn387:
  %v2207 = load i64, ptr %slot318, align 8
  %op2208 = sub i64 %v2207, 16
  store i64 %op2208, ptr %slot320, align 8
  %v2209 = load i64, ptr %slot318, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  %rgep2211 = getelementptr i8, ptr %p2210, i64 -16
  %ld2212 = load i64, ptr %rgep2211, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2212, ptr %slot321, align 8
  %v2213 = load i64, ptr %slot321, align 8
  %op2214 = and i64 %v2213, 4611686018427387906
  store i64 %op2214, ptr %slot322, align 8
  %v2215 = load i64, ptr %slot322, align 8
  %cmp2216 = icmp ne i64 %v2215, 0
  %cv2217 = zext i1 %cmp2216 to i32
  store i32 %cv2217, ptr %slot323, align 8
  %v2218 = load i32, ptr %slot323, align 8
  %cv2219 = zext i32 %v2218 to i64
  %cond2220 = icmp ne i64 %cv2219, 0
  br i1 %cond2220, label %bb_rcgclear387, label %bb_rcgcounted387
bb_rcgcounted387:
  %v2221 = load i64, ptr %slot318, align 8
  %op2222 = sub i64 %v2221, 32
  store i64 %op2222, ptr %slot324, align 8
  %v2223 = load i64, ptr %slot318, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %rgep2225 = getelementptr i8, ptr %p2224, i64 -32
  %ld2226 = load i64, ptr %rgep2225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2226, ptr %slot325, align 8
  %v2227 = load i64, ptr %slot325, align 8
  %op2228 = sub i64 %v2227, 1
  store i64 %op2228, ptr %slot326, align 8
  %v2229 = load i64, ptr %slot326, align 8
  %cmp2230 = icmp eq i64 %v2229, 0
  %cv2231 = zext i1 %cmp2230 to i32
  store i32 %cv2231, ptr %slot327, align 8
  %v2232 = load i32, ptr %slot327, align 8
  %cv2233 = zext i32 %v2232 to i64
  %cond2234 = icmp ne i64 %cv2233, 0
  br i1 %cond2234, label %bb_rcglast387, label %bb_rcgdec387
bb_rcglast387:
  %v2235 = load i64, ptr %slot318, align 8
  %op2236 = sub i64 %v2235, 24
  store i64 %op2236, ptr %slot328, align 8
  %v2237 = load i64, ptr %slot318, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %rgep2239 = getelementptr i8, ptr %p2238, i64 -24
  %ld2240 = load i64, ptr %rgep2239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2240, ptr %slot329, align 8
  %v2241 = load i64, ptr %slot329, align 8
  %cmp2242 = icmp ne i64 %v2241, 0
  %cv2243 = zext i1 %cmp2242 to i32
  store i32 %cv2243, ptr %slot330, align 8
  %v2244 = load i32, ptr %slot330, align 8
  %cv2245 = zext i32 %v2244 to i64
  %cond2246 = icmp ne i64 %cv2245, 0
  br i1 %cond2246, label %bb_rcgdec387, label %bb_rcgslow387
bb_rcgslow387:
  %v2247 = load i64, ptr %slot317, align 8
  %v2248 = load i64, ptr %slot300, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2247, i64 %v2248) nomerge, !dbg !134
  br label %bb_rcgdone387
bb_rcgdec387:
  %v2249 = load i64, ptr %slot326, align 8
  %v2250 = load i64, ptr %slot318, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %rgep2252 = getelementptr i8, ptr %p2251, i64 -32
  store i64 %v2249, ptr %rgep2252, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear387
bb_rcgclear387:
  %v2253 = load i64, ptr %slot300, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i64 0, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone387
bb_rcgdone387:
  br label %bb_rcslotdone356
bb_rcslotdone356:
  %v2255 = load i64, ptr %slot26, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i64 1, ptr %p2256, align 8, !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot26, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  %ld2259 = load i64, ptr %p2258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2259, ptr %slot331, align 8
  %v2260 = load i64, ptr %slot331, align 8
  %neg2261 = sub i64 0, %v2260
  store i64 %neg2261, ptr %slot332, align 8
  %v2262 = load i64, ptr %slot331, align 8
  %cmp2263 = icmp eq i64 %v2262, 9223372036854775808
  %cv2264 = zext i1 %cmp2263 to i64
  store i64 %cv2264, ptr %slot333, align 8
  %v2265 = load i64, ptr %slot333, align 8
  %cond2266 = icmp ne i64 %v2265, 0
  br i1 %cond2266, label %bb_neg_overflow392, label %bb_neg_checked392
bb_neg_overflow392:
  %v2267 = load i64, ptr %slot1, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %v2269 = load i64, ptr %slot331, align 8
  %call2270 = call i64 @myl_qbe_int_neg(ptr %p2268, i64 1, i64 64, i64 %v2269) nomerge, !dbg !136
  unreachable
bb_neg_checked392:
  %v2271 = load i64, ptr %slot332, align 8
  %v2272 = load i64, ptr %slot26, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  store i64 %v2271, ptr %p2273, align 8, !alias.scope !3, !noalias !4
  %v2274 = load i64, ptr %slot26, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  %ld2276 = load i64, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2276, ptr %slot334, align 8
  %v2277 = load i64, ptr %slot334, align 8
  %v2278 = load i64, ptr %slot22, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  store i64 %v2277, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  %v2280 = load i64, ptr %slot19, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %ld2282 = load i64, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2282, ptr %slot335, align 8
  %v2283 = load i64, ptr %slot335, align 8
  %v2284 = load i64, ptr %slot26, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i64 %v2283, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot32, align 8
  store i64 %v2286, ptr %slot336, align 8
  %v2287 = load i64, ptr %slot336, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i32 0, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot336, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i32 8, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot336, align 8
  %v2292 = load i64, ptr %slot27, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i64 %v2291, ptr %p2293, align 8, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot26, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %ld2296 = load i64, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2296, ptr %slot337, align 8
  %v2297 = load i64, ptr %slot27, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %ld2299 = load i64, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2299, ptr %slot338, align 8
  %v2300 = load i64, ptr %slot1, align 8
  %v2301 = load i64, ptr %slot337, align 8
  %v2302 = load i64, ptr %slot338, align 8
  %call2303 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v2300, i64 %v2301, i64 %v2302) nomerge, !dbg !138
  store i64 %call2303, ptr %slot339, align 8
  %v2304 = load i64, ptr %slot339, align 8
  %v2305 = load i64, ptr %slot26, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  store i64 %v2304, ptr %p2306, align 8, !alias.scope !3, !noalias !4
  %v2307 = load i64, ptr %slot8, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %ld2309 = load i32, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2309, ptr %slot340, align 8
  %v2310 = load i32, ptr %slot340, align 8
  %cv2311 = zext i32 %v2310 to i64
  %cond2312 = icmp ne i64 %cv2311, 0
  br i1 %cond2312, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v2313 = load i64, ptr %slot8, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  store i32 0, ptr %p2314, align 4, !alias.scope !3, !noalias !4
  %v2315 = load i64, ptr %slot14, align 8
  store i64 %v2315, ptr %slot341, align 8
  %v2316 = load i64, ptr %slot9, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i32, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2318, ptr %slot342, align 8
  %v2319 = load i32, ptr %slot342, align 8
  %op2320 = and i32 %v2319, 28
  store i32 %op2320, ptr %slot343, align 8
  %v2321 = load i32, ptr %slot343, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v2324 = load i64, ptr %slot40, align 8
  store i64 %v2324, ptr %slot344, align 8
  %v2325 = load i64, ptr %slot344, align 8
  %v2326 = load i64, ptr %slot341, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2325, i64 %v2326) nomerge, !dbg !138
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v2327 = load i64, ptr %slot40, align 8
  store i64 %v2327, ptr %slot345, align 8
  %v2328 = load i64, ptr %slot345, align 8
  %v2329 = load i64, ptr %slot341, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2328, i64 %v2329) nomerge, !dbg !138
  br label %bb_rcslotdone402
bb_rcslotdone402:
  %v2330 = load i64, ptr %slot26, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  %ld2332 = load i64, ptr %p2331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2332, ptr %slot346, align 8
  %v2333 = load i64, ptr %slot346, align 8
  %op2334 = xor i64 %v2333, 1
  store i64 %op2334, ptr %slot347, align 8
  %v2335 = load i64, ptr %slot347, align 8
  %v2336 = load i64, ptr %slot26, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  store i64 %v2335, ptr %p2337, align 8, !alias.scope !3, !noalias !4
  %v2338 = load i64, ptr %slot26, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %ld2340 = load i64, ptr %p2339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2340, ptr %slot348, align 8
  %v2341 = load i64, ptr %slot348, align 8
  %cond2342 = icmp ne i64 %v2341, 0
  br i1 %cond2342, label %bb_next412, label %bb_i55
bb_next412:
  %v2343 = load i64, ptr %slot19, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i64, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2345, ptr %slot349, align 8
  %v2346 = load i64, ptr %slot349, align 8
  %v2347 = load i64, ptr %slot26, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  store i64 %v2346, ptr %p2348, align 8, !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot26, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  %ld2351 = load i64, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2351, ptr %slot350, align 8
  %v2352 = load i64, ptr %slot1, align 8
  %v2353 = load i64, ptr %slot350, align 8
  %call2354 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v2352, i64 %v2353) nomerge, !dbg !140
  store i64 %call2354, ptr %slot351, align 8
  %v2355 = load i64, ptr %slot351, align 8
  %v2356 = load i64, ptr %slot26, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  store i64 %v2355, ptr %p2357, align 8, !alias.scope !3, !noalias !4
  %v2358 = load i64, ptr %slot8, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %ld2360 = load i32, ptr %p2359, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2360, ptr %slot352, align 8
  %v2361 = load i32, ptr %slot352, align 8
  %cv2362 = zext i32 %v2361 to i64
  %cond2363 = icmp ne i64 %cv2362, 0
  br i1 %cond2363, label %bb_rcslotdrop417, label %bb_rcslotdone417
bb_rcslotdrop417:
  %v2364 = load i64, ptr %slot8, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  store i32 0, ptr %p2365, align 4, !alias.scope !3, !noalias !4
  %v2366 = load i64, ptr %slot14, align 8
  store i64 %v2366, ptr %slot353, align 8
  %v2367 = load i64, ptr %slot9, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %ld2369 = load i32, ptr %p2368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2369, ptr %slot354, align 8
  %v2370 = load i32, ptr %slot354, align 8
  %op2371 = and i32 %v2370, 28
  store i32 %op2371, ptr %slot355, align 8
  %v2372 = load i32, ptr %slot355, align 8
  %cv2373 = zext i32 %v2372 to i64
  %cond2374 = icmp ne i64 %cv2373, 0
  br i1 %cond2374, label %bb_rcslotrole417, label %bb_rcslotowner417
bb_rcslotrole417:
  %v2375 = load i64, ptr %slot40, align 8
  store i64 %v2375, ptr %slot356, align 8
  %v2376 = load i64, ptr %slot356, align 8
  %v2377 = load i64, ptr %slot353, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2376, i64 %v2377) nomerge, !dbg !140
  br label %bb_rcslotdone417
bb_rcslotowner417:
  %v2378 = load i64, ptr %slot40, align 8
  store i64 %v2378, ptr %slot357, align 8
  %v2379 = load i64, ptr %slot357, align 8
  %v2380 = load i64, ptr %slot353, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2379, i64 %v2380) nomerge, !dbg !140
  br label %bb_rcslotdone417
bb_rcslotdone417:
  %v2381 = load i64, ptr %slot19, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i64, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2383, ptr %slot358, align 8
  %v2384 = load i64, ptr %slot358, align 8
  %v2385 = load i64, ptr %slot26, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  store i64 %v2384, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  %v2387 = load i64, ptr %slot33, align 8
  store i64 %v2387, ptr %slot359, align 8
  %v2388 = load i64, ptr %slot359, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  store i32 0, ptr %p2389, align 4, !alias.scope !3, !noalias !4
  %v2390 = load i64, ptr %slot359, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i32 8, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  %v2392 = load i64, ptr %slot359, align 8
  %v2393 = load i64, ptr %slot27, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  store i64 %v2392, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  %p2395 = inttoptr i64 ptrtoint (ptr @myl_lit_68ffc8926d53b76965bdbc497371091db72d87c782d401cb624f0db3a87df30d to i64) to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2396, ptr %slot360, align 8
  %v2397 = load i64, ptr %slot360, align 8
  %v2398 = load i64, ptr %slot28, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot28, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot361, align 8
  %v2403 = load i64, ptr %slot361, align 8
  %v2404 = load i64, ptr %slot17, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i64 %v2403, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot17, align 8
  store i64 %v2406, ptr %slot362, align 8
  %v2407 = load i64, ptr %slot18, align 8
  store i64 %v2407, ptr %slot363, align 8
  %v2408 = load i64, ptr %slot362, align 8
  %v2409 = load i64, ptr %slot363, align 8
  %p2410 = inttoptr i64 %v2408 to ptr
  %p2411 = inttoptr i64 %v2409 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2411, ptr %p2410, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot13, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i32 2, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  %v2414 = load i64, ptr %slot12, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  store i32 1, ptr %p2415, align 4, !alias.scope !3, !noalias !4
  %v2416 = load i64, ptr %slot15, align 8
  store i64 %v2416, ptr %slot364, align 8
  %v2417 = load i64, ptr %slot18, align 8
  store i64 %v2417, ptr %slot365, align 8
  %v2418 = load i64, ptr %slot365, align 8
  %v2419 = load i64, ptr %slot364, align 8
  %p2420 = inttoptr i64 %v2418 to ptr
  %p2421 = inttoptr i64 %v2419 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2421, ptr %p2420, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2422 = load i64, ptr %slot11, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  store i32 2, ptr %p2423, align 4, !alias.scope !3, !noalias !4
  %v2424 = load i64, ptr %slot13, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  %ld2426 = load i32, ptr %p2425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2426, ptr %slot366, align 8
  %v2427 = load i32, ptr %slot366, align 8
  %v2428 = load i64, ptr %slot11, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  store i32 %v2427, ptr %p2429, align 4, !alias.scope !3, !noalias !4
  %v2430 = load i64, ptr %slot12, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  store i32 0, ptr %p2431, align 4, !alias.scope !3, !noalias !4
  %v2432 = load i64, ptr %slot10, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i32 1, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot364, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %ld2436 = load i64, ptr %p2435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2436, ptr %slot367, align 8
  %v2437 = load i64, ptr %slot367, align 8
  %v2438 = load i64, ptr %slot28, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  store i64 %v2437, ptr %p2439, align 8, !alias.scope !3, !noalias !4
  %v2440 = load i64, ptr %slot26, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  %ld2442 = load i64, ptr %p2441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2442, ptr %slot368, align 8
  %v2443 = load i64, ptr %slot27, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %ld2445 = load i64, ptr %p2444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2445, ptr %slot369, align 8
  %v2446 = load i64, ptr %slot28, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %ld2448 = load i64, ptr %p2447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2448, ptr %slot370, align 8
  %v2449 = load i64, ptr %slot1, align 8
  %v2450 = load i64, ptr %slot368, align 8
  %v2451 = load i64, ptr %slot369, align 8
  %v2452 = load i64, ptr %slot370, align 8
  %call2453 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v2449, i64 %v2450, i64 %v2451, i64 %v2452) nomerge, !dbg !142
  store i64 %call2453, ptr %slot371, align 8
  %v2454 = load i64, ptr %slot371, align 8
  %v2455 = load i64, ptr %slot26, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  store i64 %v2454, ptr %p2456, align 8, !alias.scope !3, !noalias !4
  %v2457 = load i64, ptr %slot8, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i32, ptr %p2458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2459, ptr %slot372, align 8
  %v2460 = load i32, ptr %slot372, align 8
  %cv2461 = zext i32 %v2460 to i64
  %cond2462 = icmp ne i64 %cv2461, 0
  br i1 %cond2462, label %bb_rcslotdrop448, label %bb_rcslotdone448
bb_rcslotdrop448:
  %v2463 = load i64, ptr %slot8, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 0, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  %v2465 = load i64, ptr %slot14, align 8
  store i64 %v2465, ptr %slot373, align 8
  %v2466 = load i64, ptr %slot9, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %ld2468 = load i32, ptr %p2467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2468, ptr %slot374, align 8
  %v2469 = load i32, ptr %slot374, align 8
  %op2470 = and i32 %v2469, 28
  store i32 %op2470, ptr %slot375, align 8
  %v2471 = load i32, ptr %slot375, align 8
  %cv2472 = zext i32 %v2471 to i64
  %cond2473 = icmp ne i64 %cv2472, 0
  br i1 %cond2473, label %bb_rcslotrole448, label %bb_rcslotowner448
bb_rcslotrole448:
  %v2474 = load i64, ptr %slot40, align 8
  store i64 %v2474, ptr %slot376, align 8
  %v2475 = load i64, ptr %slot376, align 8
  %v2476 = load i64, ptr %slot373, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2475, i64 %v2476) nomerge, !dbg !142
  br label %bb_rcslotdone448
bb_rcslotowner448:
  %v2477 = load i64, ptr %slot40, align 8
  store i64 %v2477, ptr %slot377, align 8
  %v2478 = load i64, ptr %slot377, align 8
  %v2479 = load i64, ptr %slot373, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2478, i64 %v2479) nomerge, !dbg !142
  br label %bb_rcslotdone448
bb_rcslotdone448:
  %v2480 = load i64, ptr %slot10, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %ld2482 = load i32, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2482, ptr %slot378, align 8
  %v2483 = load i32, ptr %slot378, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcslotdrop457, label %bb_rcslotdone457
bb_rcslotdrop457:
  %v2486 = load i64, ptr %slot10, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i32 0, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot15, align 8
  store i64 %v2488, ptr %slot379, align 8
  %v2489 = load i64, ptr %slot11, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %ld2491 = load i32, ptr %p2490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2491, ptr %slot380, align 8
  %v2492 = load i32, ptr %slot380, align 8
  %op2493 = and i32 %v2492, 28
  store i32 %op2493, ptr %slot381, align 8
  %v2494 = load i32, ptr %slot381, align 8
  %cv2495 = zext i32 %v2494 to i64
  %cond2496 = icmp ne i64 %cv2495, 0
  br i1 %cond2496, label %bb_rcslotrole457, label %bb_rcslotowner457
bb_rcslotrole457:
  %v2497 = load i64, ptr %slot40, align 8
  store i64 %v2497, ptr %slot382, align 8
  %v2498 = load i64, ptr %slot379, align 8
  %p2499 = inttoptr i64 %v2498 to ptr
  %ld2500 = load i64, ptr %p2499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2500, ptr %slot383, align 8
  %v2501 = load i64, ptr %slot383, align 8
  %cmp2502 = icmp ne i64 %v2501, 0
  %cv2503 = zext i1 %cmp2502 to i32
  store i32 %cv2503, ptr %slot384, align 8
  %v2504 = load i32, ptr %slot384, align 8
  %cv2505 = zext i32 %v2504 to i64
  %cond2506 = icmp ne i64 %cv2505, 0
  br i1 %cond2506, label %bb_rcgnn473, label %bb_rcgdone473
bb_rcgnn473:
  %v2507 = load i64, ptr %slot383, align 8
  %op2508 = sub i64 %v2507, 16
  store i64 %op2508, ptr %slot385, align 8
  %v2509 = load i64, ptr %slot383, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  %rgep2511 = getelementptr i8, ptr %p2510, i64 -16
  %ld2512 = load i64, ptr %rgep2511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2512, ptr %slot386, align 8
  %v2513 = load i64, ptr %slot386, align 8
  %op2514 = and i64 %v2513, 4611686018427387906
  store i64 %op2514, ptr %slot387, align 8
  %v2515 = load i64, ptr %slot387, align 8
  %cmp2516 = icmp ne i64 %v2515, 0
  %cv2517 = zext i1 %cmp2516 to i32
  store i32 %cv2517, ptr %slot388, align 8
  %v2518 = load i32, ptr %slot388, align 8
  %cv2519 = zext i32 %v2518 to i64
  %cond2520 = icmp ne i64 %cv2519, 0
  br i1 %cond2520, label %bb_rcgclear473, label %bb_rcgcounted473
bb_rcgcounted473:
  %v2521 = load i64, ptr %slot383, align 8
  %op2522 = sub i64 %v2521, 24
  store i64 %op2522, ptr %slot389, align 8
  %v2523 = load i64, ptr %slot383, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  %rgep2525 = getelementptr i8, ptr %p2524, i64 -24
  %ld2526 = load i64, ptr %rgep2525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2526, ptr %slot390, align 8
  %v2527 = load i64, ptr %slot390, align 8
  %op2528 = sub i64 %v2527, 1
  store i64 %op2528, ptr %slot391, align 8
  %v2529 = load i64, ptr %slot391, align 8
  %cmp2530 = icmp eq i64 %v2529, 0
  %cv2531 = zext i1 %cmp2530 to i32
  store i32 %cv2531, ptr %slot392, align 8
  %v2532 = load i32, ptr %slot392, align 8
  %cv2533 = zext i32 %v2532 to i64
  %cond2534 = icmp ne i64 %cv2533, 0
  br i1 %cond2534, label %bb_rcglast473, label %bb_rcgdec473
bb_rcglast473:
  %v2535 = load i64, ptr %slot383, align 8
  %op2536 = sub i64 %v2535, 32
  store i64 %op2536, ptr %slot393, align 8
  %v2537 = load i64, ptr %slot383, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %rgep2539 = getelementptr i8, ptr %p2538, i64 -32
  %ld2540 = load i64, ptr %rgep2539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2540, ptr %slot394, align 8
  %v2541 = load i64, ptr %slot394, align 8
  %cmp2542 = icmp ne i64 %v2541, 0
  %cv2543 = zext i1 %cmp2542 to i32
  store i32 %cv2543, ptr %slot395, align 8
  %v2544 = load i32, ptr %slot395, align 8
  %cv2545 = zext i32 %v2544 to i64
  %cond2546 = icmp ne i64 %cv2545, 0
  br i1 %cond2546, label %bb_rcgdec473, label %bb_rcgslow473
bb_rcgslow473:
  %v2547 = load i64, ptr %slot382, align 8
  %v2548 = load i64, ptr %slot379, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2547, i64 %v2548) nomerge, !dbg !142
  br label %bb_rcgdone473
bb_rcgdec473:
  %v2549 = load i64, ptr %slot391, align 8
  %v2550 = load i64, ptr %slot383, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %rgep2552 = getelementptr i8, ptr %p2551, i64 -24
  store i64 %v2549, ptr %rgep2552, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear473
bb_rcgclear473:
  %v2553 = load i64, ptr %slot379, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  store i64 0, ptr %p2554, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone473
bb_rcgdone473:
  br label %bb_rcslotdone457
bb_rcslotowner457:
  %v2555 = load i64, ptr %slot40, align 8
  store i64 %v2555, ptr %slot396, align 8
  %v2556 = load i64, ptr %slot379, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i64, ptr %p2557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2558, ptr %slot397, align 8
  %v2559 = load i64, ptr %slot397, align 8
  %cmp2560 = icmp ne i64 %v2559, 0
  %cv2561 = zext i1 %cmp2560 to i32
  store i32 %cv2561, ptr %slot398, align 8
  %v2562 = load i32, ptr %slot398, align 8
  %cv2563 = zext i32 %v2562 to i64
  %cond2564 = icmp ne i64 %cv2563, 0
  br i1 %cond2564, label %bb_rcgnn488, label %bb_rcgdone488
bb_rcgnn488:
  %v2565 = load i64, ptr %slot397, align 8
  %op2566 = sub i64 %v2565, 16
  store i64 %op2566, ptr %slot399, align 8
  %v2567 = load i64, ptr %slot397, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  %rgep2569 = getelementptr i8, ptr %p2568, i64 -16
  %ld2570 = load i64, ptr %rgep2569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2570, ptr %slot400, align 8
  %v2571 = load i64, ptr %slot400, align 8
  %op2572 = and i64 %v2571, 4611686018427387906
  store i64 %op2572, ptr %slot401, align 8
  %v2573 = load i64, ptr %slot401, align 8
  %cmp2574 = icmp ne i64 %v2573, 0
  %cv2575 = zext i1 %cmp2574 to i32
  store i32 %cv2575, ptr %slot402, align 8
  %v2576 = load i32, ptr %slot402, align 8
  %cv2577 = zext i32 %v2576 to i64
  %cond2578 = icmp ne i64 %cv2577, 0
  br i1 %cond2578, label %bb_rcgclear488, label %bb_rcgcounted488
bb_rcgcounted488:
  %v2579 = load i64, ptr %slot397, align 8
  %op2580 = sub i64 %v2579, 32
  store i64 %op2580, ptr %slot403, align 8
  %v2581 = load i64, ptr %slot397, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %rgep2583 = getelementptr i8, ptr %p2582, i64 -32
  %ld2584 = load i64, ptr %rgep2583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2584, ptr %slot404, align 8
  %v2585 = load i64, ptr %slot404, align 8
  %op2586 = sub i64 %v2585, 1
  store i64 %op2586, ptr %slot405, align 8
  %v2587 = load i64, ptr %slot405, align 8
  %cmp2588 = icmp eq i64 %v2587, 0
  %cv2589 = zext i1 %cmp2588 to i32
  store i32 %cv2589, ptr %slot406, align 8
  %v2590 = load i32, ptr %slot406, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcglast488, label %bb_rcgdec488
bb_rcglast488:
  %v2593 = load i64, ptr %slot397, align 8
  %op2594 = sub i64 %v2593, 24
  store i64 %op2594, ptr %slot407, align 8
  %v2595 = load i64, ptr %slot397, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %rgep2597 = getelementptr i8, ptr %p2596, i64 -24
  %ld2598 = load i64, ptr %rgep2597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2598, ptr %slot408, align 8
  %v2599 = load i64, ptr %slot408, align 8
  %cmp2600 = icmp ne i64 %v2599, 0
  %cv2601 = zext i1 %cmp2600 to i32
  store i32 %cv2601, ptr %slot409, align 8
  %v2602 = load i32, ptr %slot409, align 8
  %cv2603 = zext i32 %v2602 to i64
  %cond2604 = icmp ne i64 %cv2603, 0
  br i1 %cond2604, label %bb_rcgdec488, label %bb_rcgslow488
bb_rcgslow488:
  %v2605 = load i64, ptr %slot396, align 8
  %v2606 = load i64, ptr %slot379, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2605, i64 %v2606) nomerge, !dbg !142
  br label %bb_rcgdone488
bb_rcgdec488:
  %v2607 = load i64, ptr %slot405, align 8
  %v2608 = load i64, ptr %slot397, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %rgep2610 = getelementptr i8, ptr %p2609, i64 -32
  store i64 %v2607, ptr %rgep2610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear488
bb_rcgclear488:
  %v2611 = load i64, ptr %slot379, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  store i64 0, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone488
bb_rcgdone488:
  br label %bb_rcslotdone457
bb_rcslotdone457:
  %v2613 = load i64, ptr %slot19, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i64, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2615, ptr %slot410, align 8
  %v2616 = load i64, ptr %slot410, align 8
  %v2617 = load i64, ptr %slot26, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  store i64 %v2616, ptr %p2618, align 8, !alias.scope !3, !noalias !4
  %v2619 = load i64, ptr %slot27, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i64 26, ptr %p2620, align 8, !alias.scope !3, !noalias !4
  %v2621 = load i64, ptr %slot26, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %ld2623 = load i64, ptr %p2622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2623, ptr %slot411, align 8
  %v2624 = load i64, ptr %slot27, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  %ld2626 = load i64, ptr %p2625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2626, ptr %slot412, align 8
  %v2627 = load i64, ptr %slot1, align 8
  %v2628 = load i64, ptr %slot411, align 8
  %v2629 = load i64, ptr %slot412, align 8
  %call2630 = call i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64 %v2627, i64 %v2628, i64 %v2629) nomerge, !dbg !144
  store i64 %call2630, ptr %slot413, align 8
  %v2631 = load i64, ptr %slot413, align 8
  %v2632 = load i64, ptr %slot26, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i64 %v2631, ptr %p2633, align 8, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot8, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %ld2636 = load i32, ptr %p2635, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2636, ptr %slot414, align 8
  %v2637 = load i32, ptr %slot414, align 8
  %cv2638 = zext i32 %v2637 to i64
  %cond2639 = icmp ne i64 %cv2638, 0
  br i1 %cond2639, label %bb_rcslotdrop498, label %bb_rcslotdone498
bb_rcslotdrop498:
  %v2640 = load i64, ptr %slot8, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  store i32 0, ptr %p2641, align 4, !alias.scope !3, !noalias !4
  %v2642 = load i64, ptr %slot14, align 8
  store i64 %v2642, ptr %slot415, align 8
  %v2643 = load i64, ptr %slot9, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  %ld2645 = load i32, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2645, ptr %slot416, align 8
  %v2646 = load i32, ptr %slot416, align 8
  %op2647 = and i32 %v2646, 28
  store i32 %op2647, ptr %slot417, align 8
  %v2648 = load i32, ptr %slot417, align 8
  %cv2649 = zext i32 %v2648 to i64
  %cond2650 = icmp ne i64 %cv2649, 0
  br i1 %cond2650, label %bb_rcslotrole498, label %bb_rcslotowner498
bb_rcslotrole498:
  %v2651 = load i64, ptr %slot40, align 8
  store i64 %v2651, ptr %slot418, align 8
  %v2652 = load i64, ptr %slot418, align 8
  %v2653 = load i64, ptr %slot415, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2652, i64 %v2653) nomerge, !dbg !144
  br label %bb_rcslotdone498
bb_rcslotowner498:
  %v2654 = load i64, ptr %slot40, align 8
  store i64 %v2654, ptr %slot419, align 8
  %v2655 = load i64, ptr %slot419, align 8
  %v2656 = load i64, ptr %slot415, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2655, i64 %v2656) nomerge, !dbg !144
  br label %bb_rcslotdone498
bb_rcslotdone498:
  %v2657 = load i64, ptr %slot26, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  %ld2659 = load i64, ptr %p2658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2659, ptr %slot420, align 8
  %v2660 = load i64, ptr %slot420, align 8
  %v2661 = load i64, ptr %slot22, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  store i64 %v2660, ptr %p2662, align 8, !alias.scope !3, !noalias !4
  %v2663 = load i64, ptr %slot19, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  %ld2665 = load i64, ptr %p2664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2665, ptr %slot421, align 8
  %v2666 = load i64, ptr %slot421, align 8
  %v2667 = load i64, ptr %slot26, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  store i64 %v2666, ptr %p2668, align 8, !alias.scope !3, !noalias !4
  %v2669 = load i64, ptr %slot27, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  store i64 4, ptr %p2670, align 8, !alias.scope !3, !noalias !4
  %v2671 = load i64, ptr %slot26, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  %ld2673 = load i64, ptr %p2672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2673, ptr %slot422, align 8
  %v2674 = load i64, ptr %slot27, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %ld2676 = load i64, ptr %p2675, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2676, ptr %slot423, align 8
  %v2677 = load i64, ptr %slot1, align 8
  %v2678 = load i64, ptr %slot422, align 8
  %v2679 = load i64, ptr %slot423, align 8
  %call2680 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v2677, i64 %v2678, i64 %v2679) nomerge, !dbg !146
  store i64 %call2680, ptr %slot424, align 8
  %v2681 = load i64, ptr %slot424, align 8
  %v2682 = load i64, ptr %slot26, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i64 %v2681, ptr %p2683, align 8, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot8, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  %ld2686 = load i32, ptr %p2685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2686, ptr %slot425, align 8
  %v2687 = load i32, ptr %slot425, align 8
  %cv2688 = zext i32 %v2687 to i64
  %cond2689 = icmp ne i64 %cv2688, 0
  br i1 %cond2689, label %bb_rcslotdrop512, label %bb_rcslotdone512
bb_rcslotdrop512:
  %v2690 = load i64, ptr %slot8, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i32 0, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot14, align 8
  store i64 %v2692, ptr %slot426, align 8
  %v2693 = load i64, ptr %slot9, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  %ld2695 = load i32, ptr %p2694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2695, ptr %slot427, align 8
  %v2696 = load i32, ptr %slot427, align 8
  %op2697 = and i32 %v2696, 28
  store i32 %op2697, ptr %slot428, align 8
  %v2698 = load i32, ptr %slot428, align 8
  %cv2699 = zext i32 %v2698 to i64
  %cond2700 = icmp ne i64 %cv2699, 0
  br i1 %cond2700, label %bb_rcslotrole512, label %bb_rcslotowner512
bb_rcslotrole512:
  %v2701 = load i64, ptr %slot40, align 8
  store i64 %v2701, ptr %slot429, align 8
  %v2702 = load i64, ptr %slot429, align 8
  %v2703 = load i64, ptr %slot426, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2702, i64 %v2703) nomerge, !dbg !146
  br label %bb_rcslotdone512
bb_rcslotowner512:
  %v2704 = load i64, ptr %slot40, align 8
  store i64 %v2704, ptr %slot430, align 8
  %v2705 = load i64, ptr %slot430, align 8
  %v2706 = load i64, ptr %slot426, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2705, i64 %v2706) nomerge, !dbg !146
  br label %bb_rcslotdone512
bb_rcslotdone512:
  br label %bb_i55
bb_i55:
  %v2707 = load i64, ptr %slot19, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  %ld2709 = load i64, ptr %p2708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2709, ptr %slot431, align 8
  %v2710 = load i64, ptr %slot431, align 8
  %v2711 = load i64, ptr %slot26, align 8
  %p2712 = inttoptr i64 %v2711 to ptr
  store i64 %v2710, ptr %p2712, align 8, !alias.scope !3, !noalias !4
  %v2713 = load i64, ptr %slot34, align 8
  store i64 %v2713, ptr %slot432, align 8
  %v2714 = load i64, ptr %slot432, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  store i32 0, ptr %p2715, align 4, !alias.scope !3, !noalias !4
  %v2716 = load i64, ptr %slot432, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  store i32 1, ptr %p2717, align 4, !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot432, align 8
  %v2719 = load i64, ptr %slot27, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  store i64 %v2718, ptr %p2720, align 8, !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot26, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %ld2723 = load i64, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2723, ptr %slot433, align 8
  %v2724 = load i64, ptr %slot27, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  %ld2726 = load i64, ptr %p2725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2726, ptr %slot434, align 8
  %v2727 = load i64, ptr %slot1, align 8
  %v2728 = load i64, ptr %slot433, align 8
  %v2729 = load i64, ptr %slot434, align 8
  %call2730 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v2727, i64 %v2728, i64 %v2729) nomerge, !dbg !148
  store i64 %call2730, ptr %slot435, align 8
  %v2731 = load i64, ptr %slot435, align 8
  %v2732 = load i64, ptr %slot26, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  store i64 %v2731, ptr %p2733, align 8, !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot8, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  %ld2736 = load i32, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2736, ptr %slot436, align 8
  %v2737 = load i32, ptr %slot436, align 8
  %cv2738 = zext i32 %v2737 to i64
  %cond2739 = icmp ne i64 %cv2738, 0
  br i1 %cond2739, label %bb_rcslotdrop526, label %bb_rcslotdone526
bb_rcslotdrop526:
  %v2740 = load i64, ptr %slot8, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  store i32 0, ptr %p2741, align 4, !alias.scope !3, !noalias !4
  %v2742 = load i64, ptr %slot14, align 8
  store i64 %v2742, ptr %slot437, align 8
  %v2743 = load i64, ptr %slot9, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  %ld2745 = load i32, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2745, ptr %slot438, align 8
  %v2746 = load i32, ptr %slot438, align 8
  %op2747 = and i32 %v2746, 28
  store i32 %op2747, ptr %slot439, align 8
  %v2748 = load i32, ptr %slot439, align 8
  %cv2749 = zext i32 %v2748 to i64
  %cond2750 = icmp ne i64 %cv2749, 0
  br i1 %cond2750, label %bb_rcslotrole526, label %bb_rcslotowner526
bb_rcslotrole526:
  %v2751 = load i64, ptr %slot40, align 8
  store i64 %v2751, ptr %slot440, align 8
  %v2752 = load i64, ptr %slot440, align 8
  %v2753 = load i64, ptr %slot437, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2752, i64 %v2753) nomerge, !dbg !148
  br label %bb_rcslotdone526
bb_rcslotowner526:
  %v2754 = load i64, ptr %slot40, align 8
  store i64 %v2754, ptr %slot441, align 8
  %v2755 = load i64, ptr %slot441, align 8
  %v2756 = load i64, ptr %slot437, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2755, i64 %v2756) nomerge, !dbg !148
  br label %bb_rcslotdone526
bb_rcslotdone526:
  %v2757 = load i64, ptr %slot26, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %ld2759 = load i64, ptr %p2758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2759, ptr %slot442, align 8
  %v2760 = load i64, ptr %slot442, align 8
  %op2761 = xor i64 %v2760, 1
  store i64 %op2761, ptr %slot443, align 8
  %v2762 = load i64, ptr %slot443, align 8
  %v2763 = load i64, ptr %slot26, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  store i64 %v2762, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  %v2765 = load i64, ptr %slot26, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i64, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2767, ptr %slot444, align 8
  %v2768 = load i64, ptr %slot444, align 8
  %cond2769 = icmp ne i64 %v2768, 0
  br i1 %cond2769, label %bb_next536, label %bb_i93
bb_next536:
  %v2770 = load i64, ptr %slot19, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  %ld2772 = load i64, ptr %p2771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2772, ptr %slot445, align 8
  %v2773 = load i64, ptr %slot445, align 8
  %v2774 = load i64, ptr %slot26, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  store i64 %v2773, ptr %p2775, align 8, !alias.scope !3, !noalias !4
  %v2776 = load i64, ptr %slot27, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  store i64 25, ptr %p2777, align 8, !alias.scope !3, !noalias !4
  %v2778 = load i64, ptr %slot26, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %ld2780 = load i64, ptr %p2779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2780, ptr %slot446, align 8
  %v2781 = load i64, ptr %slot27, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  %ld2783 = load i64, ptr %p2782, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2783, ptr %slot447, align 8
  %v2784 = load i64, ptr %slot1, align 8
  %v2785 = load i64, ptr %slot446, align 8
  %v2786 = load i64, ptr %slot447, align 8
  %call2787 = call i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64 %v2784, i64 %v2785, i64 %v2786) nomerge, !dbg !150
  store i64 %call2787, ptr %slot448, align 8
  %v2788 = load i64, ptr %slot448, align 8
  %v2789 = load i64, ptr %slot26, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i64 %v2788, ptr %p2790, align 8, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot8, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i32, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2793, ptr %slot449, align 8
  %v2794 = load i32, ptr %slot449, align 8
  %cv2795 = zext i32 %v2794 to i64
  %cond2796 = icmp ne i64 %cv2795, 0
  br i1 %cond2796, label %bb_rcslotdrop542, label %bb_rcslotdone542
bb_rcslotdrop542:
  %v2797 = load i64, ptr %slot8, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  store i32 0, ptr %p2798, align 4, !alias.scope !3, !noalias !4
  %v2799 = load i64, ptr %slot14, align 8
  store i64 %v2799, ptr %slot450, align 8
  %v2800 = load i64, ptr %slot9, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i32, ptr %p2801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2802, ptr %slot451, align 8
  %v2803 = load i32, ptr %slot451, align 8
  %op2804 = and i32 %v2803, 28
  store i32 %op2804, ptr %slot452, align 8
  %v2805 = load i32, ptr %slot452, align 8
  %cv2806 = zext i32 %v2805 to i64
  %cond2807 = icmp ne i64 %cv2806, 0
  br i1 %cond2807, label %bb_rcslotrole542, label %bb_rcslotowner542
bb_rcslotrole542:
  %v2808 = load i64, ptr %slot40, align 8
  store i64 %v2808, ptr %slot453, align 8
  %v2809 = load i64, ptr %slot453, align 8
  %v2810 = load i64, ptr %slot450, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2809, i64 %v2810) nomerge, !dbg !150
  br label %bb_rcslotdone542
bb_rcslotowner542:
  %v2811 = load i64, ptr %slot40, align 8
  store i64 %v2811, ptr %slot454, align 8
  %v2812 = load i64, ptr %slot454, align 8
  %v2813 = load i64, ptr %slot450, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2812, i64 %v2813) nomerge, !dbg !150
  br label %bb_rcslotdone542
bb_rcslotdone542:
  %v2814 = load i64, ptr %slot26, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i64, ptr %p2815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2816, ptr %slot455, align 8
  %v2817 = load i64, ptr %slot455, align 8
  %v2818 = load i64, ptr %slot23, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  store i64 %v2817, ptr %p2819, align 8, !alias.scope !3, !noalias !4
  %v2820 = load i64, ptr %slot19, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %ld2822 = load i64, ptr %p2821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2822, ptr %slot456, align 8
  %v2823 = load i64, ptr %slot456, align 8
  %v2824 = load i64, ptr %slot26, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i64 %v2823, ptr %p2825, align 8, !alias.scope !3, !noalias !4
  %v2826 = load i64, ptr %slot26, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  %ld2828 = load i64, ptr %p2827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2828, ptr %slot457, align 8
  %v2829 = load i64, ptr %slot1, align 8
  %v2830 = load i64, ptr %slot457, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult459, i64 %v2829, i64 %v2830) nomerge, !dbg !152
  %addr2831 = ptrtoint ptr %callresult459 to i64
  store i64 %addr2831, ptr %slot458, align 8
  %v2832 = load i64, ptr %slot458, align 8
  %v2833 = load i64, ptr %slot26, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  store i64 %v2832, ptr %p2834, align 8, !alias.scope !3, !noalias !4
  %v2835 = load i64, ptr %slot26, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  %ld2837 = load i64, ptr %p2836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2837, ptr %slot460, align 8
  %v2838 = load i64, ptr %slot18, align 8
  store i64 %v2838, ptr %slot461, align 8
  %v2839 = load i64, ptr %slot460, align 8
  %v2840 = load i64, ptr %slot461, align 8
  %p2841 = inttoptr i64 %v2839 to ptr
  %p2842 = inttoptr i64 %v2840 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2842, ptr %p2841, i64 24, i1 false)
  %v2843 = load i64, ptr %slot13, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i32 2, ptr %p2844, align 4, !alias.scope !3, !noalias !4
  %v2845 = load i64, ptr %slot12, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  store i32 1, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  %v2847 = load i64, ptr %slot8, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i32, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2849, ptr %slot462, align 8
  %v2850 = load i32, ptr %slot462, align 8
  %cv2851 = zext i32 %v2850 to i64
  %cond2852 = icmp ne i64 %cv2851, 0
  br i1 %cond2852, label %bb_rcslotdrop559, label %bb_rcslotdone559
bb_rcslotdrop559:
  %v2853 = load i64, ptr %slot8, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 0, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot14, align 8
  store i64 %v2855, ptr %slot463, align 8
  %v2856 = load i64, ptr %slot9, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  %ld2858 = load i32, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2858, ptr %slot464, align 8
  %v2859 = load i32, ptr %slot464, align 8
  %op2860 = and i32 %v2859, 28
  store i32 %op2860, ptr %slot465, align 8
  %v2861 = load i32, ptr %slot465, align 8
  %cv2862 = zext i32 %v2861 to i64
  %cond2863 = icmp ne i64 %cv2862, 0
  br i1 %cond2863, label %bb_rcslotrole559, label %bb_rcslotowner559
bb_rcslotrole559:
  %v2864 = load i64, ptr %slot40, align 8
  store i64 %v2864, ptr %slot466, align 8
  %v2865 = load i64, ptr %slot466, align 8
  %v2866 = load i64, ptr %slot463, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2865, i64 %v2866) nomerge, !dbg !152
  br label %bb_rcslotdone559
bb_rcslotowner559:
  %v2867 = load i64, ptr %slot40, align 8
  store i64 %v2867, ptr %slot467, align 8
  %v2868 = load i64, ptr %slot467, align 8
  %v2869 = load i64, ptr %slot463, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2868, i64 %v2869) nomerge, !dbg !152
  br label %bb_rcslotdone559
bb_rcslotdone559:
  %v2870 = load i64, ptr %slot14, align 8
  store i64 %v2870, ptr %slot468, align 8
  %v2871 = load i64, ptr %slot18, align 8
  store i64 %v2871, ptr %slot469, align 8
  %v2872 = load i64, ptr %slot469, align 8
  %v2873 = load i64, ptr %slot468, align 8
  %p2874 = inttoptr i64 %v2872 to ptr
  %p2875 = inttoptr i64 %v2873 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2875, ptr %p2874, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2876 = load i64, ptr %slot9, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  store i32 2, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  %v2878 = load i64, ptr %slot13, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i32, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2880, ptr %slot470, align 8
  %v2881 = load i32, ptr %slot470, align 8
  %v2882 = load i64, ptr %slot9, align 8
  %p2883 = inttoptr i64 %v2882 to ptr
  store i32 %v2881, ptr %p2883, align 4, !alias.scope !3, !noalias !4
  %v2884 = load i64, ptr %slot12, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  store i32 0, ptr %p2885, align 4, !alias.scope !3, !noalias !4
  %v2886 = load i64, ptr %slot8, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  store i32 1, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  %v2888 = load i64, ptr %slot468, align 8
  %v2889 = load i64, ptr %slot26, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i64 %v2888, ptr %p2890, align 8, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot26, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %ld2893 = load i64, ptr %p2892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2893, ptr %slot471, align 8
  %v2894 = load i64, ptr %slot471, align 8
  %op2895 = add i64 %v2894, 0
  store i64 %op2895, ptr %slot472, align 8
  %v2896 = load i64, ptr %slot472, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  %ld2898 = load i64, ptr %p2897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2898, ptr %slot473, align 8
  %v2899 = load i64, ptr %slot473, align 8
  %v2900 = load i64, ptr %slot26, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  store i64 %v2899, ptr %p2901, align 8, !alias.scope !3, !noalias !4
  %v2902 = load i64, ptr %slot26, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %ld2904 = load i64, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2904, ptr %slot474, align 8
  %v2905 = load i64, ptr %slot474, align 8
  %v2906 = load i64, ptr %slot16, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  store i64 %v2905, ptr %p2907, align 8, !alias.scope !3, !noalias !4
  %v2908 = load i64, ptr %slot16, align 8
  store i64 %v2908, ptr %slot475, align 8
  %v2909 = load i64, ptr %slot18, align 8
  store i64 %v2909, ptr %slot476, align 8
  %v2910 = load i64, ptr %slot475, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  %ld2912 = load i64, ptr %p2911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2912, ptr %slot477, align 8
  %v2913 = load i64, ptr %slot477, align 8
  %cmp2914 = icmp ne i64 %v2913, 0
  %cv2915 = zext i1 %cmp2914 to i32
  store i32 %cv2915, ptr %slot478, align 8
  %v2916 = load i32, ptr %slot478, align 8
  %cv2917 = zext i32 %v2916 to i64
  %cond2918 = icmp ne i64 %cv2917, 0
  br i1 %cond2918, label %bb_rcgnn581, label %bb_rcgstore581
bb_rcgnn581:
  %v2919 = load i64, ptr %slot477, align 8
  %op2920 = sub i64 %v2919, 16
  store i64 %op2920, ptr %slot479, align 8
  %v2921 = load i64, ptr %slot477, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  %rgep2923 = getelementptr i8, ptr %p2922, i64 -16
  %ld2924 = load i64, ptr %rgep2923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2924, ptr %slot480, align 8
  %v2925 = load i64, ptr %slot480, align 8
  %op2926 = and i64 %v2925, 4611686018427387906
  store i64 %op2926, ptr %slot481, align 8
  %v2927 = load i64, ptr %slot481, align 8
  %cmp2928 = icmp ne i64 %v2927, 0
  %cv2929 = zext i1 %cmp2928 to i32
  store i32 %cv2929, ptr %slot482, align 8
  %v2930 = load i32, ptr %slot482, align 8
  %cv2931 = zext i32 %v2930 to i64
  %cond2932 = icmp ne i64 %cv2931, 0
  br i1 %cond2932, label %bb_rcgstore581, label %bb_rcginc581
bb_rcginc581:
  %v2933 = load i64, ptr %slot477, align 8
  %op2934 = sub i64 %v2933, 24
  store i64 %op2934, ptr %slot483, align 8
  %v2935 = load i64, ptr %slot477, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  %rgep2937 = getelementptr i8, ptr %p2936, i64 -24
  %ld2938 = load i64, ptr %rgep2937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2938, ptr %slot484, align 8
  %v2939 = load i64, ptr %slot484, align 8
  %op2940 = add i64 %v2939, 1
  store i64 %op2940, ptr %slot485, align 8
  %v2941 = load i64, ptr %slot485, align 8
  %cmp2942 = icmp eq i64 %v2941, 0
  %cv2943 = zext i1 %cmp2942 to i32
  store i32 %cv2943, ptr %slot486, align 8
  %v2944 = load i32, ptr %slot486, align 8
  %cv2945 = zext i32 %v2944 to i64
  %cond2946 = icmp ne i64 %cv2945, 0
  br i1 %cond2946, label %bb_rcglimit581, label %bb_rcgcapacity581
bb_rcglimit581:
  %v2947 = load i64, ptr %slot1, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %call2949 = call i32 @myl_qbe_rc_status(ptr %p2948, i32 2) nomerge, !dbg !154
  store i32 %call2949, ptr %slot487, align 8
  br label %bb_failure
bb_rcgcapacity581:
  %v2950 = load i64, ptr %slot485, align 8
  %v2951 = load i64, ptr %slot477, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %rgep2953 = getelementptr i8, ptr %p2952, i64 -24
  store i64 %v2950, ptr %rgep2953, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore581
bb_rcgstore581:
  %v2954 = load i64, ptr %slot477, align 8
  %v2955 = load i64, ptr %slot476, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  store i64 %v2954, ptr %p2956, align 8, !alias.scope !3, !noalias !4
  %v2957 = load i64, ptr %slot13, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  store i32 2, ptr %p2958, align 4, !alias.scope !3, !noalias !4
  %v2959 = load i64, ptr %slot13, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  store i32 16, ptr %p2960, align 4, !alias.scope !3, !noalias !4
  %v2961 = load i64, ptr %slot12, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  store i32 1, ptr %p2962, align 4, !alias.scope !3, !noalias !4
  %v2963 = load i64, ptr %slot8, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %ld2965 = load i32, ptr %p2964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2965, ptr %slot488, align 8
  %v2966 = load i32, ptr %slot488, align 8
  %cv2967 = zext i32 %v2966 to i64
  %cond2968 = icmp ne i64 %cv2967, 0
  br i1 %cond2968, label %bb_rcslotdrop597, label %bb_rcslotdone597
bb_rcslotdrop597:
  %v2969 = load i64, ptr %slot8, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  store i32 0, ptr %p2970, align 4, !alias.scope !3, !noalias !4
  %v2971 = load i64, ptr %slot14, align 8
  store i64 %v2971, ptr %slot489, align 8
  %v2972 = load i64, ptr %slot9, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %ld2974 = load i32, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2974, ptr %slot490, align 8
  %v2975 = load i32, ptr %slot490, align 8
  %op2976 = and i32 %v2975, 28
  store i32 %op2976, ptr %slot491, align 8
  %v2977 = load i32, ptr %slot491, align 8
  %cv2978 = zext i32 %v2977 to i64
  %cond2979 = icmp ne i64 %cv2978, 0
  br i1 %cond2979, label %bb_rcslotrole597, label %bb_rcslotowner597
bb_rcslotrole597:
  %v2980 = load i64, ptr %slot40, align 8
  store i64 %v2980, ptr %slot492, align 8
  %v2981 = load i64, ptr %slot492, align 8
  %v2982 = load i64, ptr %slot489, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2981, i64 %v2982) nomerge, !dbg !154
  br label %bb_rcslotdone597
bb_rcslotowner597:
  %v2983 = load i64, ptr %slot40, align 8
  store i64 %v2983, ptr %slot493, align 8
  %v2984 = load i64, ptr %slot493, align 8
  %v2985 = load i64, ptr %slot489, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v2984, i64 %v2985) nomerge, !dbg !154
  br label %bb_rcslotdone597
bb_rcslotdone597:
  %v2986 = load i64, ptr %slot14, align 8
  store i64 %v2986, ptr %slot494, align 8
  %v2987 = load i64, ptr %slot18, align 8
  store i64 %v2987, ptr %slot495, align 8
  %v2988 = load i64, ptr %slot495, align 8
  %v2989 = load i64, ptr %slot494, align 8
  %p2990 = inttoptr i64 %v2988 to ptr
  %p2991 = inttoptr i64 %v2989 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2991, ptr %p2990, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot9, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i32 2, ptr %p2993, align 4, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot13, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  %ld2996 = load i32, ptr %p2995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2996, ptr %slot496, align 8
  %v2997 = load i32, ptr %slot496, align 8
  %v2998 = load i64, ptr %slot9, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i32 %v2997, ptr %p2999, align 4, !alias.scope !3, !noalias !4
  %v3000 = load i64, ptr %slot12, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  store i32 0, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  %v3002 = load i64, ptr %slot8, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  store i32 1, ptr %p3003, align 4, !alias.scope !3, !noalias !4
  %v3004 = load i64, ptr %slot494, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  %ld3006 = load i64, ptr %p3005, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3006, ptr %slot497, align 8
  %v3007 = load i64, ptr %slot497, align 8
  %v3008 = load i64, ptr %slot26, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i64 %v3007, ptr %p3009, align 8, !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot26, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %ld3012 = load i64, ptr %p3011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3012, ptr %slot498, align 8
  %v3013 = load i64, ptr %slot498, align 8
  %v3014 = load i64, ptr %slot16, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  store i64 %v3013, ptr %p3015, align 8, !alias.scope !3, !noalias !4
  %v3016 = load i64, ptr %slot16, align 8
  store i64 %v3016, ptr %slot499, align 8
  %v3017 = load i64, ptr %slot8, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  %ld3019 = load i32, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3019, ptr %slot500, align 8
  %v3020 = load i64, ptr %slot9, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  %ld3022 = load i32, ptr %p3021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3022, ptr %slot501, align 8
  %v3023 = load i32, ptr %slot501, align 8
  %op3024 = and i32 %v3023, 24
  store i32 %op3024, ptr %slot501, align 8
  %v3025 = load i32, ptr %slot501, align 8
  %cmp3026 = icmp eq i32 %v3025, 0
  %cv3027 = zext i1 %cmp3026 to i32
  store i32 %cv3027, ptr %slot502, align 8
  %v3028 = load i32, ptr %slot500, align 8
  %v3029 = load i32, ptr %slot502, align 8
  %op3030 = and i32 %v3028, %v3029
  store i32 %op3030, ptr %slot503, align 8
  %v3031 = load i32, ptr %slot503, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcprivateown621, label %bb_rcprivateloan621
bb_rcprivateown621:
  %v3034 = load i64, ptr %slot18, align 8
  store i64 %v3034, ptr %slot504, align 8
  %v3035 = load i64, ptr %slot41, align 8
  store i64 %v3035, ptr %slot505, align 8
  %v3036 = load i64, ptr %slot499, align 8
  %v3037 = load i64, ptr %slot504, align 8
  %op3038 = sub i64 %v3036, %v3037
  store i64 %op3038, ptr %slot506, align 8
  %v3039 = load i64, ptr %slot504, align 8
  %v3040 = load i64, ptr %slot499, align 8
  %op3041 = sub i64 %v3039, %v3040
  store i64 %op3041, ptr %slot507, align 8
  %v3042 = load i64, ptr %slot506, align 8
  %cmp3043 = icmp ult i64 %v3042, 8
  %cv3044 = zext i1 %cmp3043 to i32
  store i32 %cv3044, ptr %slot508, align 8
  %v3045 = load i64, ptr %slot507, align 8
  %cmp3046 = icmp ult i64 %v3045, 8
  %cv3047 = zext i1 %cmp3046 to i32
  store i32 %cv3047, ptr %slot509, align 8
  %v3048 = load i32, ptr %slot508, align 8
  %v3049 = load i32, ptr %slot509, align 8
  %op3050 = or i32 %v3048, %v3049
  store i32 %op3050, ptr %slot510, align 8
  %v3051 = load i32, ptr %slot510, align 8
  %cv3052 = zext i32 %v3051 to i64
  %cond3053 = icmp ne i64 %cv3052, 0
  br i1 %cond3053, label %bb_rcmoveslow624, label %bb_rcmovecheck624
bb_rcmovecheck624:
  %v3054 = load i64, ptr %slot499, align 8
  %p3056 = inttoptr i64 %v3054 to ptr
  %gep3057 = getelementptr i8, ptr %p3056, i64 0
  %op3055 = ptrtoint ptr %gep3057 to i64
  store i64 %op3055, ptr %slot511, align 8
  %v3058 = load i64, ptr %slot511, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  %ld3060 = load i64, ptr %p3059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3060, ptr %slot512, align 8
  %v3061 = load i64, ptr %slot512, align 8
  %cmp3062 = icmp ne i64 %v3061, 0
  %cv3063 = zext i1 %cmp3062 to i32
  store i32 %cv3063, ptr %slot513, align 8
  %v3064 = load i32, ptr %slot513, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcmoveheader632, label %bb_rcmovenext632
bb_rcmoveheader632:
  %v3067 = load i64, ptr %slot512, align 8
  %op3068 = sub i64 %v3067, 16
  store i64 %op3068, ptr %slot514, align 8
  %v3069 = load i64, ptr %slot512, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  %rgep3071 = getelementptr i8, ptr %p3070, i64 -16
  %ld3072 = load i64, ptr %rgep3071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3072, ptr %slot515, align 8
  %v3073 = load i64, ptr %slot515, align 8
  %op3074 = and i64 %v3073, 5764607523034234881
  store i64 %op3074, ptr %slot516, align 8
  %v3075 = load i64, ptr %slot516, align 8
  %cmp3076 = icmp ne i64 %v3075, 0
  %cv3077 = zext i1 %cmp3076 to i32
  store i32 %cv3077, ptr %slot517, align 8
  %v3078 = load i32, ptr %slot517, align 8
  %cv3079 = zext i32 %v3078 to i64
  %cond3080 = icmp ne i64 %cv3079, 0
  br i1 %cond3080, label %bb_rcmoveslow624, label %bb_rcmovenext632
bb_rcmovenext632:
  %v3081 = load i64, ptr %slot499, align 8
  %v3082 = load i64, ptr %slot504, align 8
  %p3083 = inttoptr i64 %v3081 to ptr
  %p3084 = inttoptr i64 %v3082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3084, ptr %p3083, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3085 = load i64, ptr %slot499, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  store i64 0, ptr %p3086, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved624
bb_rcmoveslow624:
  %v3087 = load i64, ptr %slot40, align 8
  %v3088 = load i64, ptr %slot504, align 8
  %v3089 = load i64, ptr %slot499, align 8
  %v3090 = load i64, ptr %slot505, align 8
  %cv3091 = trunc i64 %v3090 to i32
  %call3092 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3087, i64 %v3088, i64 %v3089, i32 %cv3091) nomerge, !dbg !156
  store i32 %call3092, ptr %slot518, align 8
  %v3093 = load i32, ptr %slot518, align 8
  %cv3094 = zext i32 %v3093 to i64
  %cond3095 = icmp ne i64 %cv3094, 0
  br i1 %cond3095, label %bb_rcsuccess639, label %bb_rcfailure639
bb_rcfailure639:
  %v3096 = load i64, ptr %slot40, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %call3098 = call i32 @myl_rc_take_failure(ptr %p3097) nomerge, !dbg !156
  store i32 %call3098, ptr %slot519, align 8
  %v3099 = load i64, ptr %slot1, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  %v3101 = load i32, ptr %slot519, align 8
  %call3102 = call i32 @myl_qbe_rc_status(ptr %p3100, i32 %v3101) nomerge, !dbg !156
  store i32 %call3102, ptr %slot520, align 8
  br label %bb_failure
bb_rcsuccess639:
  br label %bb_rcmoved624
bb_rcmoved624:
  %v3103 = load i64, ptr %slot8, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i32 0, ptr %p3104, align 4, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot13, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  store i32 2, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  %v3107 = load i64, ptr %slot12, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  store i32 1, ptr %p3108, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared621
bb_rcprivateloan621:
  %v3109 = load i64, ptr %slot8, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %ld3111 = load i32, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3111, ptr %slot521, align 8
  %v3112 = load i64, ptr %slot9, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  %ld3114 = load i32, ptr %p3113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3114, ptr %slot522, align 8
  %v3115 = load i32, ptr %slot522, align 8
  %cmp3116 = icmp eq i32 %v3115, 16
  %cv3117 = zext i1 %cmp3116 to i32
  store i32 %cv3117, ptr %slot523, align 8
  %v3118 = load i32, ptr %slot523, align 8
  %v3119 = load i32, ptr %slot521, align 8
  %op3120 = and i32 %v3118, %v3119
  store i32 %op3120, ptr %slot523, align 8
  %v3121 = load i32, ptr %slot523, align 8
  %cv3122 = zext i32 %v3121 to i64
  %cond3123 = icmp ne i64 %cv3122, 0
  br i1 %cond3123, label %bb_rcprivatemove621, label %bb_rcprivatenew621
bb_rcprivatemove621:
  %v3124 = load i64, ptr %slot18, align 8
  store i64 %v3124, ptr %slot524, align 8
  %v3125 = load i64, ptr %slot499, align 8
  %v3126 = load i64, ptr %slot524, align 8
  %p3127 = inttoptr i64 %v3125 to ptr
  %p3128 = inttoptr i64 %v3126 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3128, ptr %p3127, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3129 = load i64, ptr %slot499, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  store i64 0, ptr %p3130, align 8, !alias.scope !3, !noalias !4
  %v3131 = load i64, ptr %slot13, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i32 2, ptr %p3132, align 4, !alias.scope !3, !noalias !4
  %v3133 = load i64, ptr %slot13, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  store i32 16, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  %v3135 = load i64, ptr %slot12, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  store i32 1, ptr %p3136, align 4, !alias.scope !3, !noalias !4
  %v3137 = load i64, ptr %slot8, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  store i32 0, ptr %p3138, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared621
bb_rcprivatenew621:
  %v3139 = load i64, ptr %slot18, align 8
  store i64 %v3139, ptr %slot525, align 8
  %v3140 = load i64, ptr %slot499, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  %ld3142 = load i64, ptr %p3141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3142, ptr %slot526, align 8
  %v3143 = load i64, ptr %slot526, align 8
  %cmp3144 = icmp ne i64 %v3143, 0
  %cv3145 = zext i1 %cmp3144 to i32
  store i32 %cv3145, ptr %slot527, align 8
  %v3146 = load i32, ptr %slot527, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcgnn657, label %bb_rcgstore657
bb_rcgnn657:
  %v3149 = load i64, ptr %slot526, align 8
  %op3150 = sub i64 %v3149, 16
  store i64 %op3150, ptr %slot528, align 8
  %v3151 = load i64, ptr %slot526, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %rgep3153 = getelementptr i8, ptr %p3152, i64 -16
  %ld3154 = load i64, ptr %rgep3153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3154, ptr %slot529, align 8
  %v3155 = load i64, ptr %slot529, align 8
  %op3156 = and i64 %v3155, 4611686018427387906
  store i64 %op3156, ptr %slot530, align 8
  %v3157 = load i64, ptr %slot530, align 8
  %cmp3158 = icmp ne i64 %v3157, 0
  %cv3159 = zext i1 %cmp3158 to i32
  store i32 %cv3159, ptr %slot531, align 8
  %v3160 = load i32, ptr %slot531, align 8
  %cv3161 = zext i32 %v3160 to i64
  %cond3162 = icmp ne i64 %cv3161, 0
  br i1 %cond3162, label %bb_rcgstore657, label %bb_rcginc657
bb_rcginc657:
  %v3163 = load i64, ptr %slot526, align 8
  %op3164 = sub i64 %v3163, 24
  store i64 %op3164, ptr %slot532, align 8
  %v3165 = load i64, ptr %slot526, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %rgep3167 = getelementptr i8, ptr %p3166, i64 -24
  %ld3168 = load i64, ptr %rgep3167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3168, ptr %slot533, align 8
  %v3169 = load i64, ptr %slot533, align 8
  %op3170 = add i64 %v3169, 1
  store i64 %op3170, ptr %slot534, align 8
  %v3171 = load i64, ptr %slot534, align 8
  %cmp3172 = icmp eq i64 %v3171, 0
  %cv3173 = zext i1 %cmp3172 to i32
  store i32 %cv3173, ptr %slot535, align 8
  %v3174 = load i32, ptr %slot535, align 8
  %cv3175 = zext i32 %v3174 to i64
  %cond3176 = icmp ne i64 %cv3175, 0
  br i1 %cond3176, label %bb_rcglimit657, label %bb_rcgcapacity657
bb_rcglimit657:
  %v3177 = load i64, ptr %slot1, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %call3179 = call i32 @myl_qbe_rc_status(ptr %p3178, i32 2) nomerge, !dbg !156
  store i32 %call3179, ptr %slot536, align 8
  br label %bb_failure
bb_rcgcapacity657:
  %v3180 = load i64, ptr %slot534, align 8
  %v3181 = load i64, ptr %slot526, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  %rgep3183 = getelementptr i8, ptr %p3182, i64 -24
  store i64 %v3180, ptr %rgep3183, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore657
bb_rcgstore657:
  %v3184 = load i64, ptr %slot526, align 8
  %v3185 = load i64, ptr %slot525, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  store i64 %v3184, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  %v3187 = load i64, ptr %slot13, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  store i32 2, ptr %p3188, align 4, !alias.scope !3, !noalias !4
  %v3189 = load i64, ptr %slot13, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i32 16, ptr %p3190, align 4, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot12, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  store i32 1, ptr %p3192, align 4, !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot8, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  %ld3195 = load i32, ptr %p3194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3195, ptr %slot537, align 8
  %v3196 = load i32, ptr %slot537, align 8
  %cv3197 = zext i32 %v3196 to i64
  %cond3198 = icmp ne i64 %cv3197, 0
  br i1 %cond3198, label %bb_rcslotdrop673, label %bb_rcslotdone673
bb_rcslotdrop673:
  %v3199 = load i64, ptr %slot8, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i32 0, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot14, align 8
  store i64 %v3201, ptr %slot538, align 8
  %v3202 = load i64, ptr %slot9, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %ld3204 = load i32, ptr %p3203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3204, ptr %slot539, align 8
  %v3205 = load i32, ptr %slot539, align 8
  %op3206 = and i32 %v3205, 28
  store i32 %op3206, ptr %slot540, align 8
  %v3207 = load i32, ptr %slot540, align 8
  %cv3208 = zext i32 %v3207 to i64
  %cond3209 = icmp ne i64 %cv3208, 0
  br i1 %cond3209, label %bb_rcslotrole673, label %bb_rcslotowner673
bb_rcslotrole673:
  %v3210 = load i64, ptr %slot40, align 8
  store i64 %v3210, ptr %slot541, align 8
  %v3211 = load i64, ptr %slot538, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i64, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3213, ptr %slot542, align 8
  %v3214 = load i64, ptr %slot542, align 8
  %cmp3215 = icmp ne i64 %v3214, 0
  %cv3216 = zext i1 %cmp3215 to i32
  store i32 %cv3216, ptr %slot543, align 8
  %v3217 = load i32, ptr %slot543, align 8
  %cv3218 = zext i32 %v3217 to i64
  %cond3219 = icmp ne i64 %cv3218, 0
  br i1 %cond3219, label %bb_rcgnn689, label %bb_rcgdone689
bb_rcgnn689:
  %v3220 = load i64, ptr %slot542, align 8
  %op3221 = sub i64 %v3220, 16
  store i64 %op3221, ptr %slot544, align 8
  %v3222 = load i64, ptr %slot542, align 8
  %p3223 = inttoptr i64 %v3222 to ptr
  %rgep3224 = getelementptr i8, ptr %p3223, i64 -16
  %ld3225 = load i64, ptr %rgep3224, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3225, ptr %slot545, align 8
  %v3226 = load i64, ptr %slot545, align 8
  %op3227 = and i64 %v3226, 4611686018427387906
  store i64 %op3227, ptr %slot546, align 8
  %v3228 = load i64, ptr %slot546, align 8
  %cmp3229 = icmp ne i64 %v3228, 0
  %cv3230 = zext i1 %cmp3229 to i32
  store i32 %cv3230, ptr %slot547, align 8
  %v3231 = load i32, ptr %slot547, align 8
  %cv3232 = zext i32 %v3231 to i64
  %cond3233 = icmp ne i64 %cv3232, 0
  br i1 %cond3233, label %bb_rcgclear689, label %bb_rcgcounted689
bb_rcgcounted689:
  %v3234 = load i64, ptr %slot542, align 8
  %op3235 = sub i64 %v3234, 24
  store i64 %op3235, ptr %slot548, align 8
  %v3236 = load i64, ptr %slot542, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %rgep3238 = getelementptr i8, ptr %p3237, i64 -24
  %ld3239 = load i64, ptr %rgep3238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3239, ptr %slot549, align 8
  %v3240 = load i64, ptr %slot549, align 8
  %op3241 = sub i64 %v3240, 1
  store i64 %op3241, ptr %slot550, align 8
  %v3242 = load i64, ptr %slot550, align 8
  %cmp3243 = icmp eq i64 %v3242, 0
  %cv3244 = zext i1 %cmp3243 to i32
  store i32 %cv3244, ptr %slot551, align 8
  %v3245 = load i32, ptr %slot551, align 8
  %cv3246 = zext i32 %v3245 to i64
  %cond3247 = icmp ne i64 %cv3246, 0
  br i1 %cond3247, label %bb_rcglast689, label %bb_rcgdec689
bb_rcglast689:
  %v3248 = load i64, ptr %slot542, align 8
  %op3249 = sub i64 %v3248, 32
  store i64 %op3249, ptr %slot552, align 8
  %v3250 = load i64, ptr %slot542, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  %rgep3252 = getelementptr i8, ptr %p3251, i64 -32
  %ld3253 = load i64, ptr %rgep3252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3253, ptr %slot553, align 8
  %v3254 = load i64, ptr %slot553, align 8
  %cmp3255 = icmp ne i64 %v3254, 0
  %cv3256 = zext i1 %cmp3255 to i32
  store i32 %cv3256, ptr %slot554, align 8
  %v3257 = load i32, ptr %slot554, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcgdec689, label %bb_rcgslow689
bb_rcgslow689:
  %v3260 = load i64, ptr %slot541, align 8
  %v3261 = load i64, ptr %slot538, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3260, i64 %v3261) nomerge, !dbg !156
  br label %bb_rcgdone689
bb_rcgdec689:
  %v3262 = load i64, ptr %slot550, align 8
  %v3263 = load i64, ptr %slot542, align 8
  %p3264 = inttoptr i64 %v3263 to ptr
  %rgep3265 = getelementptr i8, ptr %p3264, i64 -24
  store i64 %v3262, ptr %rgep3265, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear689
bb_rcgclear689:
  %v3266 = load i64, ptr %slot538, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  store i64 0, ptr %p3267, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone689
bb_rcgdone689:
  br label %bb_rcslotdone673
bb_rcslotowner673:
  %v3268 = load i64, ptr %slot40, align 8
  store i64 %v3268, ptr %slot555, align 8
  %v3269 = load i64, ptr %slot538, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %ld3271 = load i64, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3271, ptr %slot556, align 8
  %v3272 = load i64, ptr %slot556, align 8
  %cmp3273 = icmp ne i64 %v3272, 0
  %cv3274 = zext i1 %cmp3273 to i32
  store i32 %cv3274, ptr %slot557, align 8
  %v3275 = load i32, ptr %slot557, align 8
  %cv3276 = zext i32 %v3275 to i64
  %cond3277 = icmp ne i64 %cv3276, 0
  br i1 %cond3277, label %bb_rcgnn704, label %bb_rcgdone704
bb_rcgnn704:
  %v3278 = load i64, ptr %slot556, align 8
  %op3279 = sub i64 %v3278, 16
  store i64 %op3279, ptr %slot558, align 8
  %v3280 = load i64, ptr %slot556, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %rgep3282 = getelementptr i8, ptr %p3281, i64 -16
  %ld3283 = load i64, ptr %rgep3282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3283, ptr %slot559, align 8
  %v3284 = load i64, ptr %slot559, align 8
  %op3285 = and i64 %v3284, 4611686018427387906
  store i64 %op3285, ptr %slot560, align 8
  %v3286 = load i64, ptr %slot560, align 8
  %cmp3287 = icmp ne i64 %v3286, 0
  %cv3288 = zext i1 %cmp3287 to i32
  store i32 %cv3288, ptr %slot561, align 8
  %v3289 = load i32, ptr %slot561, align 8
  %cv3290 = zext i32 %v3289 to i64
  %cond3291 = icmp ne i64 %cv3290, 0
  br i1 %cond3291, label %bb_rcgclear704, label %bb_rcgcounted704
bb_rcgcounted704:
  %v3292 = load i64, ptr %slot556, align 8
  %op3293 = sub i64 %v3292, 32
  store i64 %op3293, ptr %slot562, align 8
  %v3294 = load i64, ptr %slot556, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  %rgep3296 = getelementptr i8, ptr %p3295, i64 -32
  %ld3297 = load i64, ptr %rgep3296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3297, ptr %slot563, align 8
  %v3298 = load i64, ptr %slot563, align 8
  %op3299 = sub i64 %v3298, 1
  store i64 %op3299, ptr %slot564, align 8
  %v3300 = load i64, ptr %slot564, align 8
  %cmp3301 = icmp eq i64 %v3300, 0
  %cv3302 = zext i1 %cmp3301 to i32
  store i32 %cv3302, ptr %slot565, align 8
  %v3303 = load i32, ptr %slot565, align 8
  %cv3304 = zext i32 %v3303 to i64
  %cond3305 = icmp ne i64 %cv3304, 0
  br i1 %cond3305, label %bb_rcglast704, label %bb_rcgdec704
bb_rcglast704:
  %v3306 = load i64, ptr %slot556, align 8
  %op3307 = sub i64 %v3306, 24
  store i64 %op3307, ptr %slot566, align 8
  %v3308 = load i64, ptr %slot556, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  %rgep3310 = getelementptr i8, ptr %p3309, i64 -24
  %ld3311 = load i64, ptr %rgep3310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3311, ptr %slot567, align 8
  %v3312 = load i64, ptr %slot567, align 8
  %cmp3313 = icmp ne i64 %v3312, 0
  %cv3314 = zext i1 %cmp3313 to i32
  store i32 %cv3314, ptr %slot568, align 8
  %v3315 = load i32, ptr %slot568, align 8
  %cv3316 = zext i32 %v3315 to i64
  %cond3317 = icmp ne i64 %cv3316, 0
  br i1 %cond3317, label %bb_rcgdec704, label %bb_rcgslow704
bb_rcgslow704:
  %v3318 = load i64, ptr %slot555, align 8
  %v3319 = load i64, ptr %slot538, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3318, i64 %v3319) nomerge, !dbg !156
  br label %bb_rcgdone704
bb_rcgdec704:
  %v3320 = load i64, ptr %slot564, align 8
  %v3321 = load i64, ptr %slot556, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %rgep3323 = getelementptr i8, ptr %p3322, i64 -32
  store i64 %v3320, ptr %rgep3323, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear704
bb_rcgclear704:
  %v3324 = load i64, ptr %slot538, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  store i64 0, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone704
bb_rcgdone704:
  br label %bb_rcslotdone673
bb_rcslotdone673:
  br label %bb_rcprivateprepared621
bb_rcprivateprepared621:
  %v3326 = load i64, ptr %slot6, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %ld3328 = load i32, ptr %p3327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3328, ptr %slot569, align 8
  %v3329 = load i32, ptr %slot569, align 8
  %cv3330 = zext i32 %v3329 to i64
  %cond3331 = icmp ne i64 %cv3330, 0
  br i1 %cond3331, label %bb_rcslotdrop711, label %bb_rcslotdone711
bb_rcslotdrop711:
  %v3332 = load i64, ptr %slot6, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  store i32 0, ptr %p3333, align 4, !alias.scope !3, !noalias !4
  %v3334 = load i64, ptr %slot24, align 8
  store i64 %v3334, ptr %slot570, align 8
  %v3335 = load i64, ptr %slot7, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  %ld3337 = load i32, ptr %p3336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3337, ptr %slot571, align 8
  %v3338 = load i32, ptr %slot571, align 8
  %op3339 = and i32 %v3338, 28
  store i32 %op3339, ptr %slot572, align 8
  %v3340 = load i32, ptr %slot572, align 8
  %cv3341 = zext i32 %v3340 to i64
  %cond3342 = icmp ne i64 %cv3341, 0
  br i1 %cond3342, label %bb_rcslotrole711, label %bb_rcslotowner711
bb_rcslotrole711:
  %v3343 = load i64, ptr %slot40, align 8
  store i64 %v3343, ptr %slot573, align 8
  %v3344 = load i64, ptr %slot570, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %ld3346 = load i64, ptr %p3345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3346, ptr %slot574, align 8
  %v3347 = load i64, ptr %slot574, align 8
  %cmp3348 = icmp ne i64 %v3347, 0
  %cv3349 = zext i1 %cmp3348 to i32
  store i32 %cv3349, ptr %slot575, align 8
  %v3350 = load i32, ptr %slot575, align 8
  %cv3351 = zext i32 %v3350 to i64
  %cond3352 = icmp ne i64 %cv3351, 0
  br i1 %cond3352, label %bb_rcgnn727, label %bb_rcgdone727
bb_rcgnn727:
  %v3353 = load i64, ptr %slot574, align 8
  %op3354 = sub i64 %v3353, 16
  store i64 %op3354, ptr %slot576, align 8
  %v3355 = load i64, ptr %slot574, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %rgep3357 = getelementptr i8, ptr %p3356, i64 -16
  %ld3358 = load i64, ptr %rgep3357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3358, ptr %slot577, align 8
  %v3359 = load i64, ptr %slot577, align 8
  %op3360 = and i64 %v3359, 4611686018427387906
  store i64 %op3360, ptr %slot578, align 8
  %v3361 = load i64, ptr %slot578, align 8
  %cmp3362 = icmp ne i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot579, align 8
  %v3364 = load i32, ptr %slot579, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcgclear727, label %bb_rcgcounted727
bb_rcgcounted727:
  %v3367 = load i64, ptr %slot574, align 8
  %op3368 = sub i64 %v3367, 24
  store i64 %op3368, ptr %slot580, align 8
  %v3369 = load i64, ptr %slot574, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %rgep3371 = getelementptr i8, ptr %p3370, i64 -24
  %ld3372 = load i64, ptr %rgep3371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3372, ptr %slot581, align 8
  %v3373 = load i64, ptr %slot581, align 8
  %op3374 = sub i64 %v3373, 1
  store i64 %op3374, ptr %slot582, align 8
  %v3375 = load i64, ptr %slot582, align 8
  %cmp3376 = icmp eq i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot583, align 8
  %v3378 = load i32, ptr %slot583, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcglast727, label %bb_rcgdec727
bb_rcglast727:
  %v3381 = load i64, ptr %slot574, align 8
  %op3382 = sub i64 %v3381, 32
  store i64 %op3382, ptr %slot584, align 8
  %v3383 = load i64, ptr %slot574, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %rgep3385 = getelementptr i8, ptr %p3384, i64 -32
  %ld3386 = load i64, ptr %rgep3385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3386, ptr %slot585, align 8
  %v3387 = load i64, ptr %slot585, align 8
  %cmp3388 = icmp ne i64 %v3387, 0
  %cv3389 = zext i1 %cmp3388 to i32
  store i32 %cv3389, ptr %slot586, align 8
  %v3390 = load i32, ptr %slot586, align 8
  %cv3391 = zext i32 %v3390 to i64
  %cond3392 = icmp ne i64 %cv3391, 0
  br i1 %cond3392, label %bb_rcgdec727, label %bb_rcgslow727
bb_rcgslow727:
  %v3393 = load i64, ptr %slot573, align 8
  %v3394 = load i64, ptr %slot570, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3393, i64 %v3394) nomerge, !dbg !156
  br label %bb_rcgdone727
bb_rcgdec727:
  %v3395 = load i64, ptr %slot582, align 8
  %v3396 = load i64, ptr %slot574, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %rgep3398 = getelementptr i8, ptr %p3397, i64 -24
  store i64 %v3395, ptr %rgep3398, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear727
bb_rcgclear727:
  %v3399 = load i64, ptr %slot570, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i64 0, ptr %p3400, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone727
bb_rcgdone727:
  br label %bb_rcslotdone711
bb_rcslotowner711:
  %v3401 = load i64, ptr %slot40, align 8
  store i64 %v3401, ptr %slot587, align 8
  %v3402 = load i64, ptr %slot570, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %ld3404 = load i64, ptr %p3403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3404, ptr %slot588, align 8
  %v3405 = load i64, ptr %slot588, align 8
  %cmp3406 = icmp ne i64 %v3405, 0
  %cv3407 = zext i1 %cmp3406 to i32
  store i32 %cv3407, ptr %slot589, align 8
  %v3408 = load i32, ptr %slot589, align 8
  %cv3409 = zext i32 %v3408 to i64
  %cond3410 = icmp ne i64 %cv3409, 0
  br i1 %cond3410, label %bb_rcgnn742, label %bb_rcgdone742
bb_rcgnn742:
  %v3411 = load i64, ptr %slot588, align 8
  %op3412 = sub i64 %v3411, 16
  store i64 %op3412, ptr %slot590, align 8
  %v3413 = load i64, ptr %slot588, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  %rgep3415 = getelementptr i8, ptr %p3414, i64 -16
  %ld3416 = load i64, ptr %rgep3415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3416, ptr %slot591, align 8
  %v3417 = load i64, ptr %slot591, align 8
  %op3418 = and i64 %v3417, 4611686018427387906
  store i64 %op3418, ptr %slot592, align 8
  %v3419 = load i64, ptr %slot592, align 8
  %cmp3420 = icmp ne i64 %v3419, 0
  %cv3421 = zext i1 %cmp3420 to i32
  store i32 %cv3421, ptr %slot593, align 8
  %v3422 = load i32, ptr %slot593, align 8
  %cv3423 = zext i32 %v3422 to i64
  %cond3424 = icmp ne i64 %cv3423, 0
  br i1 %cond3424, label %bb_rcgclear742, label %bb_rcgcounted742
bb_rcgcounted742:
  %v3425 = load i64, ptr %slot588, align 8
  %op3426 = sub i64 %v3425, 32
  store i64 %op3426, ptr %slot594, align 8
  %v3427 = load i64, ptr %slot588, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %rgep3429 = getelementptr i8, ptr %p3428, i64 -32
  %ld3430 = load i64, ptr %rgep3429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3430, ptr %slot595, align 8
  %v3431 = load i64, ptr %slot595, align 8
  %op3432 = sub i64 %v3431, 1
  store i64 %op3432, ptr %slot596, align 8
  %v3433 = load i64, ptr %slot596, align 8
  %cmp3434 = icmp eq i64 %v3433, 0
  %cv3435 = zext i1 %cmp3434 to i32
  store i32 %cv3435, ptr %slot597, align 8
  %v3436 = load i32, ptr %slot597, align 8
  %cv3437 = zext i32 %v3436 to i64
  %cond3438 = icmp ne i64 %cv3437, 0
  br i1 %cond3438, label %bb_rcglast742, label %bb_rcgdec742
bb_rcglast742:
  %v3439 = load i64, ptr %slot588, align 8
  %op3440 = sub i64 %v3439, 24
  store i64 %op3440, ptr %slot598, align 8
  %v3441 = load i64, ptr %slot588, align 8
  %p3442 = inttoptr i64 %v3441 to ptr
  %rgep3443 = getelementptr i8, ptr %p3442, i64 -24
  %ld3444 = load i64, ptr %rgep3443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3444, ptr %slot599, align 8
  %v3445 = load i64, ptr %slot599, align 8
  %cmp3446 = icmp ne i64 %v3445, 0
  %cv3447 = zext i1 %cmp3446 to i32
  store i32 %cv3447, ptr %slot600, align 8
  %v3448 = load i32, ptr %slot600, align 8
  %cv3449 = zext i32 %v3448 to i64
  %cond3450 = icmp ne i64 %cv3449, 0
  br i1 %cond3450, label %bb_rcgdec742, label %bb_rcgslow742
bb_rcgslow742:
  %v3451 = load i64, ptr %slot587, align 8
  %v3452 = load i64, ptr %slot570, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3451, i64 %v3452) nomerge, !dbg !156
  br label %bb_rcgdone742
bb_rcgdec742:
  %v3453 = load i64, ptr %slot596, align 8
  %v3454 = load i64, ptr %slot588, align 8
  %p3455 = inttoptr i64 %v3454 to ptr
  %rgep3456 = getelementptr i8, ptr %p3455, i64 -32
  store i64 %v3453, ptr %rgep3456, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear742
bb_rcgclear742:
  %v3457 = load i64, ptr %slot570, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  store i64 0, ptr %p3458, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone742
bb_rcgdone742:
  br label %bb_rcslotdone711
bb_rcslotdone711:
  %v3459 = load i64, ptr %slot24, align 8
  store i64 %v3459, ptr %slot601, align 8
  %v3460 = load i64, ptr %slot18, align 8
  store i64 %v3460, ptr %slot602, align 8
  %v3461 = load i64, ptr %slot602, align 8
  %v3462 = load i64, ptr %slot601, align 8
  %p3463 = inttoptr i64 %v3461 to ptr
  %p3464 = inttoptr i64 %v3462 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3464, ptr %p3463, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3465 = load i64, ptr %slot12, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i32 0, ptr %p3466, align 4, !alias.scope !3, !noalias !4
  %v3467 = load i64, ptr %slot7, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  store i32 2, ptr %p3468, align 4, !alias.scope !3, !noalias !4
  %v3469 = load i64, ptr %slot13, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %ld3471 = load i32, ptr %p3470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3471, ptr %slot603, align 8
  %v3472 = load i32, ptr %slot603, align 8
  %v3473 = load i64, ptr %slot7, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i32 %v3472, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot6, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i32 1, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot24, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  %ld3479 = load i64, ptr %p3478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3479, ptr %slot604, align 8
  %v3480 = load i64, ptr %slot604, align 8
  %op3481 = add i64 %v3480, 0
  store i64 %op3481, ptr %slot605, align 8
  %v3482 = load i64, ptr %slot605, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i64, ptr %p3483, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3484, ptr %slot606, align 8
  %v3485 = load i64, ptr %slot606, align 8
  %v3486 = load i64, ptr %slot26, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  store i64 %v3485, ptr %p3487, align 8, !alias.scope !3, !noalias !4
  %v3488 = load i64, ptr %slot26, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %ld3490 = load i64, ptr %p3489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3490, ptr %slot607, align 8
  %v3491 = load i64, ptr %slot607, align 8
  %cmp3492 = icmp ugt i64 %v3491, 9223372036854775807
  %cv3493 = zext i1 %cmp3492 to i64
  store i64 %cv3493, ptr %slot608, align 8
  %v3494 = load i64, ptr %slot608, align 8
  %cond3495 = icmp ne i64 %v3494, 0
  br i1 %cond3495, label %bb_cast_overflow758, label %bb_cast_ok758
bb_cast_overflow758:
  %v3496 = load i64, ptr %slot1, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %v3498 = load i64, ptr %slot607, align 8
  call void @myl_qbe_fail_cast(ptr %p3497, i64 %v3498, i64 320) nomerge, !dbg !158
  unreachable
bb_cast_ok758:
  %v3499 = load i64, ptr %slot607, align 8
  %v3500 = load i64, ptr %slot26, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i64 %v3499, ptr %p3501, align 8, !alias.scope !3, !noalias !4
  %v3502 = load i64, ptr %slot26, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  %ld3504 = load i64, ptr %p3503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3504, ptr %slot609, align 8
  %v3505 = load i64, ptr %slot609, align 8
  %v3506 = load i64, ptr %slot25, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  store i64 %v3505, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  %v3508 = load i64, ptr %slot6, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %ld3510 = load i32, ptr %p3509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3510, ptr %slot610, align 8
  %v3511 = load i32, ptr %slot610, align 8
  %cv3512 = zext i32 %v3511 to i64
  %cond3513 = icmp ne i64 %cv3512, 0
  br i1 %cond3513, label %bb_rcslotdrop762, label %bb_rcslotdone762
bb_rcslotdrop762:
  %v3514 = load i64, ptr %slot6, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i32 0, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot24, align 8
  store i64 %v3516, ptr %slot611, align 8
  %v3517 = load i64, ptr %slot7, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  %ld3519 = load i32, ptr %p3518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3519, ptr %slot612, align 8
  %v3520 = load i32, ptr %slot612, align 8
  %op3521 = and i32 %v3520, 28
  store i32 %op3521, ptr %slot613, align 8
  %v3522 = load i32, ptr %slot613, align 8
  %cv3523 = zext i32 %v3522 to i64
  %cond3524 = icmp ne i64 %cv3523, 0
  br i1 %cond3524, label %bb_rcslotrole762, label %bb_rcslotowner762
bb_rcslotrole762:
  %v3525 = load i64, ptr %slot40, align 8
  store i64 %v3525, ptr %slot614, align 8
  %v3526 = load i64, ptr %slot611, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %ld3528 = load i64, ptr %p3527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3528, ptr %slot615, align 8
  %v3529 = load i64, ptr %slot615, align 8
  %cmp3530 = icmp ne i64 %v3529, 0
  %cv3531 = zext i1 %cmp3530 to i32
  store i32 %cv3531, ptr %slot616, align 8
  %v3532 = load i32, ptr %slot616, align 8
  %cv3533 = zext i32 %v3532 to i64
  %cond3534 = icmp ne i64 %cv3533, 0
  br i1 %cond3534, label %bb_rcgnn778, label %bb_rcgdone778
bb_rcgnn778:
  %v3535 = load i64, ptr %slot615, align 8
  %op3536 = sub i64 %v3535, 16
  store i64 %op3536, ptr %slot617, align 8
  %v3537 = load i64, ptr %slot615, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  %rgep3539 = getelementptr i8, ptr %p3538, i64 -16
  %ld3540 = load i64, ptr %rgep3539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3540, ptr %slot618, align 8
  %v3541 = load i64, ptr %slot618, align 8
  %op3542 = and i64 %v3541, 4611686018427387906
  store i64 %op3542, ptr %slot619, align 8
  %v3543 = load i64, ptr %slot619, align 8
  %cmp3544 = icmp ne i64 %v3543, 0
  %cv3545 = zext i1 %cmp3544 to i32
  store i32 %cv3545, ptr %slot620, align 8
  %v3546 = load i32, ptr %slot620, align 8
  %cv3547 = zext i32 %v3546 to i64
  %cond3548 = icmp ne i64 %cv3547, 0
  br i1 %cond3548, label %bb_rcgclear778, label %bb_rcgcounted778
bb_rcgcounted778:
  %v3549 = load i64, ptr %slot615, align 8
  %op3550 = sub i64 %v3549, 24
  store i64 %op3550, ptr %slot621, align 8
  %v3551 = load i64, ptr %slot615, align 8
  %p3552 = inttoptr i64 %v3551 to ptr
  %rgep3553 = getelementptr i8, ptr %p3552, i64 -24
  %ld3554 = load i64, ptr %rgep3553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3554, ptr %slot622, align 8
  %v3555 = load i64, ptr %slot622, align 8
  %op3556 = sub i64 %v3555, 1
  store i64 %op3556, ptr %slot623, align 8
  %v3557 = load i64, ptr %slot623, align 8
  %cmp3558 = icmp eq i64 %v3557, 0
  %cv3559 = zext i1 %cmp3558 to i32
  store i32 %cv3559, ptr %slot624, align 8
  %v3560 = load i32, ptr %slot624, align 8
  %cv3561 = zext i32 %v3560 to i64
  %cond3562 = icmp ne i64 %cv3561, 0
  br i1 %cond3562, label %bb_rcglast778, label %bb_rcgdec778
bb_rcglast778:
  %v3563 = load i64, ptr %slot615, align 8
  %op3564 = sub i64 %v3563, 32
  store i64 %op3564, ptr %slot625, align 8
  %v3565 = load i64, ptr %slot615, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  %rgep3567 = getelementptr i8, ptr %p3566, i64 -32
  %ld3568 = load i64, ptr %rgep3567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3568, ptr %slot626, align 8
  %v3569 = load i64, ptr %slot626, align 8
  %cmp3570 = icmp ne i64 %v3569, 0
  %cv3571 = zext i1 %cmp3570 to i32
  store i32 %cv3571, ptr %slot627, align 8
  %v3572 = load i32, ptr %slot627, align 8
  %cv3573 = zext i32 %v3572 to i64
  %cond3574 = icmp ne i64 %cv3573, 0
  br i1 %cond3574, label %bb_rcgdec778, label %bb_rcgslow778
bb_rcgslow778:
  %v3575 = load i64, ptr %slot614, align 8
  %v3576 = load i64, ptr %slot611, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3575, i64 %v3576) nomerge, !dbg !160
  br label %bb_rcgdone778
bb_rcgdec778:
  %v3577 = load i64, ptr %slot623, align 8
  %v3578 = load i64, ptr %slot615, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  %rgep3580 = getelementptr i8, ptr %p3579, i64 -24
  store i64 %v3577, ptr %rgep3580, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear778
bb_rcgclear778:
  %v3581 = load i64, ptr %slot611, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  store i64 0, ptr %p3582, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone778
bb_rcgdone778:
  br label %bb_rcslotdone762
bb_rcslotowner762:
  %v3583 = load i64, ptr %slot40, align 8
  store i64 %v3583, ptr %slot628, align 8
  %v3584 = load i64, ptr %slot611, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  %ld3586 = load i64, ptr %p3585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3586, ptr %slot629, align 8
  %v3587 = load i64, ptr %slot629, align 8
  %cmp3588 = icmp ne i64 %v3587, 0
  %cv3589 = zext i1 %cmp3588 to i32
  store i32 %cv3589, ptr %slot630, align 8
  %v3590 = load i32, ptr %slot630, align 8
  %cv3591 = zext i32 %v3590 to i64
  %cond3592 = icmp ne i64 %cv3591, 0
  br i1 %cond3592, label %bb_rcgnn793, label %bb_rcgdone793
bb_rcgnn793:
  %v3593 = load i64, ptr %slot629, align 8
  %op3594 = sub i64 %v3593, 16
  store i64 %op3594, ptr %slot631, align 8
  %v3595 = load i64, ptr %slot629, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %rgep3597 = getelementptr i8, ptr %p3596, i64 -16
  %ld3598 = load i64, ptr %rgep3597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3598, ptr %slot632, align 8
  %v3599 = load i64, ptr %slot632, align 8
  %op3600 = and i64 %v3599, 4611686018427387906
  store i64 %op3600, ptr %slot633, align 8
  %v3601 = load i64, ptr %slot633, align 8
  %cmp3602 = icmp ne i64 %v3601, 0
  %cv3603 = zext i1 %cmp3602 to i32
  store i32 %cv3603, ptr %slot634, align 8
  %v3604 = load i32, ptr %slot634, align 8
  %cv3605 = zext i32 %v3604 to i64
  %cond3606 = icmp ne i64 %cv3605, 0
  br i1 %cond3606, label %bb_rcgclear793, label %bb_rcgcounted793
bb_rcgcounted793:
  %v3607 = load i64, ptr %slot629, align 8
  %op3608 = sub i64 %v3607, 32
  store i64 %op3608, ptr %slot635, align 8
  %v3609 = load i64, ptr %slot629, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %rgep3611 = getelementptr i8, ptr %p3610, i64 -32
  %ld3612 = load i64, ptr %rgep3611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3612, ptr %slot636, align 8
  %v3613 = load i64, ptr %slot636, align 8
  %op3614 = sub i64 %v3613, 1
  store i64 %op3614, ptr %slot637, align 8
  %v3615 = load i64, ptr %slot637, align 8
  %cmp3616 = icmp eq i64 %v3615, 0
  %cv3617 = zext i1 %cmp3616 to i32
  store i32 %cv3617, ptr %slot638, align 8
  %v3618 = load i32, ptr %slot638, align 8
  %cv3619 = zext i32 %v3618 to i64
  %cond3620 = icmp ne i64 %cv3619, 0
  br i1 %cond3620, label %bb_rcglast793, label %bb_rcgdec793
bb_rcglast793:
  %v3621 = load i64, ptr %slot629, align 8
  %op3622 = sub i64 %v3621, 24
  store i64 %op3622, ptr %slot639, align 8
  %v3623 = load i64, ptr %slot629, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  %rgep3625 = getelementptr i8, ptr %p3624, i64 -24
  %ld3626 = load i64, ptr %rgep3625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3626, ptr %slot640, align 8
  %v3627 = load i64, ptr %slot640, align 8
  %cmp3628 = icmp ne i64 %v3627, 0
  %cv3629 = zext i1 %cmp3628 to i32
  store i32 %cv3629, ptr %slot641, align 8
  %v3630 = load i32, ptr %slot641, align 8
  %cv3631 = zext i32 %v3630 to i64
  %cond3632 = icmp ne i64 %cv3631, 0
  br i1 %cond3632, label %bb_rcgdec793, label %bb_rcgslow793
bb_rcgslow793:
  %v3633 = load i64, ptr %slot628, align 8
  %v3634 = load i64, ptr %slot611, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3633, i64 %v3634) nomerge, !dbg !160
  br label %bb_rcgdone793
bb_rcgdec793:
  %v3635 = load i64, ptr %slot637, align 8
  %v3636 = load i64, ptr %slot629, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  %rgep3638 = getelementptr i8, ptr %p3637, i64 -32
  store i64 %v3635, ptr %rgep3638, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear793
bb_rcgclear793:
  %v3639 = load i64, ptr %slot611, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  store i64 0, ptr %p3640, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone793
bb_rcgdone793:
  br label %bb_rcslotdone762
bb_rcslotdone762:
  %v3641 = load i64, ptr %slot19, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  %ld3643 = load i64, ptr %p3642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3643, ptr %slot642, align 8
  %v3644 = load i64, ptr %slot642, align 8
  %v3645 = load i64, ptr %slot26, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  store i64 %v3644, ptr %p3646, align 8, !alias.scope !3, !noalias !4
  %v3647 = load i64, ptr %slot26, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %ld3649 = load i64, ptr %p3648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3649, ptr %slot643, align 8
  %v3650 = load i64, ptr %slot1, align 8
  %v3651 = load i64, ptr %slot643, align 8
  %call3652 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v3650, i64 %v3651) nomerge, !dbg !162
  store i64 %call3652, ptr %slot644, align 8
  %v3653 = load i64, ptr %slot644, align 8
  %v3654 = load i64, ptr %slot26, align 8
  %p3655 = inttoptr i64 %v3654 to ptr
  store i64 %v3653, ptr %p3655, align 8, !alias.scope !3, !noalias !4
  %v3656 = load i64, ptr %slot8, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  %ld3658 = load i32, ptr %p3657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3658, ptr %slot645, align 8
  %v3659 = load i32, ptr %slot645, align 8
  %cv3660 = zext i32 %v3659 to i64
  %cond3661 = icmp ne i64 %cv3660, 0
  br i1 %cond3661, label %bb_rcslotdrop802, label %bb_rcslotdone802
bb_rcslotdrop802:
  %v3662 = load i64, ptr %slot8, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  store i32 0, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  %v3664 = load i64, ptr %slot14, align 8
  store i64 %v3664, ptr %slot646, align 8
  %v3665 = load i64, ptr %slot9, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  %ld3667 = load i32, ptr %p3666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3667, ptr %slot647, align 8
  %v3668 = load i32, ptr %slot647, align 8
  %op3669 = and i32 %v3668, 28
  store i32 %op3669, ptr %slot648, align 8
  %v3670 = load i32, ptr %slot648, align 8
  %cv3671 = zext i32 %v3670 to i64
  %cond3672 = icmp ne i64 %cv3671, 0
  br i1 %cond3672, label %bb_rcslotrole802, label %bb_rcslotowner802
bb_rcslotrole802:
  %v3673 = load i64, ptr %slot40, align 8
  store i64 %v3673, ptr %slot649, align 8
  %v3674 = load i64, ptr %slot649, align 8
  %v3675 = load i64, ptr %slot646, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3674, i64 %v3675) nomerge, !dbg !162
  br label %bb_rcslotdone802
bb_rcslotowner802:
  %v3676 = load i64, ptr %slot40, align 8
  store i64 %v3676, ptr %slot650, align 8
  %v3677 = load i64, ptr %slot650, align 8
  %v3678 = load i64, ptr %slot646, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3677, i64 %v3678) nomerge, !dbg !162
  br label %bb_rcslotdone802
bb_rcslotdone802:
  %v3679 = load i64, ptr %slot19, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  %ld3681 = load i64, ptr %p3680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3681, ptr %slot651, align 8
  %v3682 = load i64, ptr %slot651, align 8
  %v3683 = load i64, ptr %slot26, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  store i64 %v3682, ptr %p3684, align 8, !alias.scope !3, !noalias !4
  %v3685 = load i64, ptr %slot27, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  store i64 4, ptr %p3686, align 8, !alias.scope !3, !noalias !4
  %v3687 = load i64, ptr %slot26, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %ld3689 = load i64, ptr %p3688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3689, ptr %slot652, align 8
  %v3690 = load i64, ptr %slot27, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %ld3692 = load i64, ptr %p3691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3692, ptr %slot653, align 8
  %v3693 = load i64, ptr %slot1, align 8
  %v3694 = load i64, ptr %slot652, align 8
  %v3695 = load i64, ptr %slot653, align 8
  %call3696 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v3693, i64 %v3694, i64 %v3695) nomerge, !dbg !164
  store i64 %call3696, ptr %slot654, align 8
  %v3697 = load i64, ptr %slot654, align 8
  %v3698 = load i64, ptr %slot26, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  store i64 %v3697, ptr %p3699, align 8, !alias.scope !3, !noalias !4
  %v3700 = load i64, ptr %slot8, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %ld3702 = load i32, ptr %p3701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3702, ptr %slot655, align 8
  %v3703 = load i32, ptr %slot655, align 8
  %cv3704 = zext i32 %v3703 to i64
  %cond3705 = icmp ne i64 %cv3704, 0
  br i1 %cond3705, label %bb_rcslotdrop815, label %bb_rcslotdone815
bb_rcslotdrop815:
  %v3706 = load i64, ptr %slot8, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  store i32 0, ptr %p3707, align 4, !alias.scope !3, !noalias !4
  %v3708 = load i64, ptr %slot14, align 8
  store i64 %v3708, ptr %slot656, align 8
  %v3709 = load i64, ptr %slot9, align 8
  %p3710 = inttoptr i64 %v3709 to ptr
  %ld3711 = load i32, ptr %p3710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3711, ptr %slot657, align 8
  %v3712 = load i32, ptr %slot657, align 8
  %op3713 = and i32 %v3712, 28
  store i32 %op3713, ptr %slot658, align 8
  %v3714 = load i32, ptr %slot658, align 8
  %cv3715 = zext i32 %v3714 to i64
  %cond3716 = icmp ne i64 %cv3715, 0
  br i1 %cond3716, label %bb_rcslotrole815, label %bb_rcslotowner815
bb_rcslotrole815:
  %v3717 = load i64, ptr %slot40, align 8
  store i64 %v3717, ptr %slot659, align 8
  %v3718 = load i64, ptr %slot659, align 8
  %v3719 = load i64, ptr %slot656, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3718, i64 %v3719) nomerge, !dbg !164
  br label %bb_rcslotdone815
bb_rcslotowner815:
  %v3720 = load i64, ptr %slot40, align 8
  store i64 %v3720, ptr %slot660, align 8
  %v3721 = load i64, ptr %slot660, align 8
  %v3722 = load i64, ptr %slot656, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3721, i64 %v3722) nomerge, !dbg !164
  br label %bb_rcslotdone815
bb_rcslotdone815:
  %v3723 = load i64, ptr %slot19, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i64, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3725, ptr %slot661, align 8
  %v3726 = load i64, ptr %slot661, align 8
  %v3727 = load i64, ptr %slot26, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  store i64 %v3726, ptr %p3728, align 8, !alias.scope !3, !noalias !4
  %v3729 = load i64, ptr %slot35, align 8
  store i64 %v3729, ptr %slot662, align 8
  %v3730 = load i64, ptr %slot662, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  store i32 0, ptr %p3731, align 4, !alias.scope !3, !noalias !4
  %v3732 = load i64, ptr %slot662, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  store i32 1, ptr %p3733, align 4, !alias.scope !3, !noalias !4
  %v3734 = load i64, ptr %slot662, align 8
  %v3735 = load i64, ptr %slot27, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  store i64 %v3734, ptr %p3736, align 8, !alias.scope !3, !noalias !4
  %p3737 = inttoptr i64 ptrtoint (ptr @myl_lit_7f4f337a6e923b05d193f53f8564c65d6750af944141b2572482a0a0d4262aba to i64) to ptr
  %ld3738 = load i64, ptr %p3737, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3738, ptr %slot663, align 8
  %v3739 = load i64, ptr %slot663, align 8
  %v3740 = load i64, ptr %slot28, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  store i64 %v3739, ptr %p3741, align 8, !alias.scope !3, !noalias !4
  %v3742 = load i64, ptr %slot28, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  %ld3744 = load i64, ptr %p3743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3744, ptr %slot664, align 8
  %v3745 = load i64, ptr %slot664, align 8
  %v3746 = load i64, ptr %slot17, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  store i64 %v3745, ptr %p3747, align 8, !alias.scope !3, !noalias !4
  %v3748 = load i64, ptr %slot17, align 8
  store i64 %v3748, ptr %slot665, align 8
  %v3749 = load i64, ptr %slot18, align 8
  store i64 %v3749, ptr %slot666, align 8
  %v3750 = load i64, ptr %slot665, align 8
  %v3751 = load i64, ptr %slot666, align 8
  %p3752 = inttoptr i64 %v3750 to ptr
  %p3753 = inttoptr i64 %v3751 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3753, ptr %p3752, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3754 = load i64, ptr %slot13, align 8
  %p3755 = inttoptr i64 %v3754 to ptr
  store i32 2, ptr %p3755, align 4, !alias.scope !3, !noalias !4
  %v3756 = load i64, ptr %slot12, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  store i32 1, ptr %p3757, align 4, !alias.scope !3, !noalias !4
  %v3758 = load i64, ptr %slot15, align 8
  store i64 %v3758, ptr %slot667, align 8
  %v3759 = load i64, ptr %slot18, align 8
  store i64 %v3759, ptr %slot668, align 8
  %v3760 = load i64, ptr %slot668, align 8
  %v3761 = load i64, ptr %slot667, align 8
  %p3762 = inttoptr i64 %v3760 to ptr
  %p3763 = inttoptr i64 %v3761 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3763, ptr %p3762, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3764 = load i64, ptr %slot11, align 8
  %p3765 = inttoptr i64 %v3764 to ptr
  store i32 2, ptr %p3765, align 4, !alias.scope !3, !noalias !4
  %v3766 = load i64, ptr %slot13, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  %ld3768 = load i32, ptr %p3767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3768, ptr %slot669, align 8
  %v3769 = load i32, ptr %slot669, align 8
  %v3770 = load i64, ptr %slot11, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i32 %v3769, ptr %p3771, align 4, !alias.scope !3, !noalias !4
  %v3772 = load i64, ptr %slot12, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  store i32 0, ptr %p3773, align 4, !alias.scope !3, !noalias !4
  %v3774 = load i64, ptr %slot10, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i32 1, ptr %p3775, align 4, !alias.scope !3, !noalias !4
  %v3776 = load i64, ptr %slot667, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ld3778 = load i64, ptr %p3777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3778, ptr %slot670, align 8
  %v3779 = load i64, ptr %slot670, align 8
  %v3780 = load i64, ptr %slot28, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  store i64 %v3779, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  %v3782 = load i64, ptr %slot26, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %ld3784 = load i64, ptr %p3783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3784, ptr %slot671, align 8
  %v3785 = load i64, ptr %slot27, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot672, align 8
  %v3788 = load i64, ptr %slot28, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %ld3790 = load i64, ptr %p3789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3790, ptr %slot673, align 8
  %v3791 = load i64, ptr %slot1, align 8
  %v3792 = load i64, ptr %slot671, align 8
  %v3793 = load i64, ptr %slot672, align 8
  %v3794 = load i64, ptr %slot673, align 8
  %call3795 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v3791, i64 %v3792, i64 %v3793, i64 %v3794) nomerge, !dbg !166
  store i64 %call3795, ptr %slot674, align 8
  %v3796 = load i64, ptr %slot674, align 8
  %v3797 = load i64, ptr %slot26, align 8
  %p3798 = inttoptr i64 %v3797 to ptr
  store i64 %v3796, ptr %p3798, align 8, !alias.scope !3, !noalias !4
  %v3799 = load i64, ptr %slot8, align 8
  %p3800 = inttoptr i64 %v3799 to ptr
  %ld3801 = load i32, ptr %p3800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3801, ptr %slot675, align 8
  %v3802 = load i32, ptr %slot675, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcslotdrop846, label %bb_rcslotdone846
bb_rcslotdrop846:
  %v3805 = load i64, ptr %slot8, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  store i32 0, ptr %p3806, align 4, !alias.scope !3, !noalias !4
  %v3807 = load i64, ptr %slot14, align 8
  store i64 %v3807, ptr %slot676, align 8
  %v3808 = load i64, ptr %slot9, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  %ld3810 = load i32, ptr %p3809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3810, ptr %slot677, align 8
  %v3811 = load i32, ptr %slot677, align 8
  %op3812 = and i32 %v3811, 28
  store i32 %op3812, ptr %slot678, align 8
  %v3813 = load i32, ptr %slot678, align 8
  %cv3814 = zext i32 %v3813 to i64
  %cond3815 = icmp ne i64 %cv3814, 0
  br i1 %cond3815, label %bb_rcslotrole846, label %bb_rcslotowner846
bb_rcslotrole846:
  %v3816 = load i64, ptr %slot40, align 8
  store i64 %v3816, ptr %slot679, align 8
  %v3817 = load i64, ptr %slot679, align 8
  %v3818 = load i64, ptr %slot676, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3817, i64 %v3818) nomerge, !dbg !166
  br label %bb_rcslotdone846
bb_rcslotowner846:
  %v3819 = load i64, ptr %slot40, align 8
  store i64 %v3819, ptr %slot680, align 8
  %v3820 = load i64, ptr %slot680, align 8
  %v3821 = load i64, ptr %slot676, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3820, i64 %v3821) nomerge, !dbg !166
  br label %bb_rcslotdone846
bb_rcslotdone846:
  %v3822 = load i64, ptr %slot10, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i32, ptr %p3823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3824, ptr %slot681, align 8
  %v3825 = load i32, ptr %slot681, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcslotdrop855, label %bb_rcslotdone855
bb_rcslotdrop855:
  %v3828 = load i64, ptr %slot10, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i32 0, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot15, align 8
  store i64 %v3830, ptr %slot682, align 8
  %v3831 = load i64, ptr %slot11, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i32, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3833, ptr %slot683, align 8
  %v3834 = load i32, ptr %slot683, align 8
  %op3835 = and i32 %v3834, 28
  store i32 %op3835, ptr %slot684, align 8
  %v3836 = load i32, ptr %slot684, align 8
  %cv3837 = zext i32 %v3836 to i64
  %cond3838 = icmp ne i64 %cv3837, 0
  br i1 %cond3838, label %bb_rcslotrole855, label %bb_rcslotowner855
bb_rcslotrole855:
  %v3839 = load i64, ptr %slot40, align 8
  store i64 %v3839, ptr %slot685, align 8
  %v3840 = load i64, ptr %slot682, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %ld3842 = load i64, ptr %p3841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3842, ptr %slot686, align 8
  %v3843 = load i64, ptr %slot686, align 8
  %cmp3844 = icmp ne i64 %v3843, 0
  %cv3845 = zext i1 %cmp3844 to i32
  store i32 %cv3845, ptr %slot687, align 8
  %v3846 = load i32, ptr %slot687, align 8
  %cv3847 = zext i32 %v3846 to i64
  %cond3848 = icmp ne i64 %cv3847, 0
  br i1 %cond3848, label %bb_rcgnn871, label %bb_rcgdone871
bb_rcgnn871:
  %v3849 = load i64, ptr %slot686, align 8
  %op3850 = sub i64 %v3849, 16
  store i64 %op3850, ptr %slot688, align 8
  %v3851 = load i64, ptr %slot686, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %rgep3853 = getelementptr i8, ptr %p3852, i64 -16
  %ld3854 = load i64, ptr %rgep3853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3854, ptr %slot689, align 8
  %v3855 = load i64, ptr %slot689, align 8
  %op3856 = and i64 %v3855, 4611686018427387906
  store i64 %op3856, ptr %slot690, align 8
  %v3857 = load i64, ptr %slot690, align 8
  %cmp3858 = icmp ne i64 %v3857, 0
  %cv3859 = zext i1 %cmp3858 to i32
  store i32 %cv3859, ptr %slot691, align 8
  %v3860 = load i32, ptr %slot691, align 8
  %cv3861 = zext i32 %v3860 to i64
  %cond3862 = icmp ne i64 %cv3861, 0
  br i1 %cond3862, label %bb_rcgclear871, label %bb_rcgcounted871
bb_rcgcounted871:
  %v3863 = load i64, ptr %slot686, align 8
  %op3864 = sub i64 %v3863, 24
  store i64 %op3864, ptr %slot692, align 8
  %v3865 = load i64, ptr %slot686, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  %rgep3867 = getelementptr i8, ptr %p3866, i64 -24
  %ld3868 = load i64, ptr %rgep3867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3868, ptr %slot693, align 8
  %v3869 = load i64, ptr %slot693, align 8
  %op3870 = sub i64 %v3869, 1
  store i64 %op3870, ptr %slot694, align 8
  %v3871 = load i64, ptr %slot694, align 8
  %cmp3872 = icmp eq i64 %v3871, 0
  %cv3873 = zext i1 %cmp3872 to i32
  store i32 %cv3873, ptr %slot695, align 8
  %v3874 = load i32, ptr %slot695, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcglast871, label %bb_rcgdec871
bb_rcglast871:
  %v3877 = load i64, ptr %slot686, align 8
  %op3878 = sub i64 %v3877, 32
  store i64 %op3878, ptr %slot696, align 8
  %v3879 = load i64, ptr %slot686, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %rgep3881 = getelementptr i8, ptr %p3880, i64 -32
  %ld3882 = load i64, ptr %rgep3881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3882, ptr %slot697, align 8
  %v3883 = load i64, ptr %slot697, align 8
  %cmp3884 = icmp ne i64 %v3883, 0
  %cv3885 = zext i1 %cmp3884 to i32
  store i32 %cv3885, ptr %slot698, align 8
  %v3886 = load i32, ptr %slot698, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcgdec871, label %bb_rcgslow871
bb_rcgslow871:
  %v3889 = load i64, ptr %slot685, align 8
  %v3890 = load i64, ptr %slot682, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3889, i64 %v3890) nomerge, !dbg !166
  br label %bb_rcgdone871
bb_rcgdec871:
  %v3891 = load i64, ptr %slot694, align 8
  %v3892 = load i64, ptr %slot686, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %rgep3894 = getelementptr i8, ptr %p3893, i64 -24
  store i64 %v3891, ptr %rgep3894, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear871
bb_rcgclear871:
  %v3895 = load i64, ptr %slot682, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i64 0, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone871
bb_rcgdone871:
  br label %bb_rcslotdone855
bb_rcslotowner855:
  %v3897 = load i64, ptr %slot40, align 8
  store i64 %v3897, ptr %slot699, align 8
  %v3898 = load i64, ptr %slot682, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %ld3900 = load i64, ptr %p3899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3900, ptr %slot700, align 8
  %v3901 = load i64, ptr %slot700, align 8
  %cmp3902 = icmp ne i64 %v3901, 0
  %cv3903 = zext i1 %cmp3902 to i32
  store i32 %cv3903, ptr %slot701, align 8
  %v3904 = load i32, ptr %slot701, align 8
  %cv3905 = zext i32 %v3904 to i64
  %cond3906 = icmp ne i64 %cv3905, 0
  br i1 %cond3906, label %bb_rcgnn886, label %bb_rcgdone886
bb_rcgnn886:
  %v3907 = load i64, ptr %slot700, align 8
  %op3908 = sub i64 %v3907, 16
  store i64 %op3908, ptr %slot702, align 8
  %v3909 = load i64, ptr %slot700, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %rgep3911 = getelementptr i8, ptr %p3910, i64 -16
  %ld3912 = load i64, ptr %rgep3911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3912, ptr %slot703, align 8
  %v3913 = load i64, ptr %slot703, align 8
  %op3914 = and i64 %v3913, 4611686018427387906
  store i64 %op3914, ptr %slot704, align 8
  %v3915 = load i64, ptr %slot704, align 8
  %cmp3916 = icmp ne i64 %v3915, 0
  %cv3917 = zext i1 %cmp3916 to i32
  store i32 %cv3917, ptr %slot705, align 8
  %v3918 = load i32, ptr %slot705, align 8
  %cv3919 = zext i32 %v3918 to i64
  %cond3920 = icmp ne i64 %cv3919, 0
  br i1 %cond3920, label %bb_rcgclear886, label %bb_rcgcounted886
bb_rcgcounted886:
  %v3921 = load i64, ptr %slot700, align 8
  %op3922 = sub i64 %v3921, 32
  store i64 %op3922, ptr %slot706, align 8
  %v3923 = load i64, ptr %slot700, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %rgep3925 = getelementptr i8, ptr %p3924, i64 -32
  %ld3926 = load i64, ptr %rgep3925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3926, ptr %slot707, align 8
  %v3927 = load i64, ptr %slot707, align 8
  %op3928 = sub i64 %v3927, 1
  store i64 %op3928, ptr %slot708, align 8
  %v3929 = load i64, ptr %slot708, align 8
  %cmp3930 = icmp eq i64 %v3929, 0
  %cv3931 = zext i1 %cmp3930 to i32
  store i32 %cv3931, ptr %slot709, align 8
  %v3932 = load i32, ptr %slot709, align 8
  %cv3933 = zext i32 %v3932 to i64
  %cond3934 = icmp ne i64 %cv3933, 0
  br i1 %cond3934, label %bb_rcglast886, label %bb_rcgdec886
bb_rcglast886:
  %v3935 = load i64, ptr %slot700, align 8
  %op3936 = sub i64 %v3935, 24
  store i64 %op3936, ptr %slot710, align 8
  %v3937 = load i64, ptr %slot700, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %rgep3939 = getelementptr i8, ptr %p3938, i64 -24
  %ld3940 = load i64, ptr %rgep3939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3940, ptr %slot711, align 8
  %v3941 = load i64, ptr %slot711, align 8
  %cmp3942 = icmp ne i64 %v3941, 0
  %cv3943 = zext i1 %cmp3942 to i32
  store i32 %cv3943, ptr %slot712, align 8
  %v3944 = load i32, ptr %slot712, align 8
  %cv3945 = zext i32 %v3944 to i64
  %cond3946 = icmp ne i64 %cv3945, 0
  br i1 %cond3946, label %bb_rcgdec886, label %bb_rcgslow886
bb_rcgslow886:
  %v3947 = load i64, ptr %slot699, align 8
  %v3948 = load i64, ptr %slot682, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3947, i64 %v3948) nomerge, !dbg !166
  br label %bb_rcgdone886
bb_rcgdec886:
  %v3949 = load i64, ptr %slot708, align 8
  %v3950 = load i64, ptr %slot700, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  %rgep3952 = getelementptr i8, ptr %p3951, i64 -32
  store i64 %v3949, ptr %rgep3952, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear886
bb_rcgclear886:
  %v3953 = load i64, ptr %slot682, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  store i64 0, ptr %p3954, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone886
bb_rcgdone886:
  br label %bb_rcslotdone855
bb_rcslotdone855:
  %v3955 = load i64, ptr %slot19, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %ld3957 = load i64, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3957, ptr %slot713, align 8
  %v3958 = load i64, ptr %slot713, align 8
  %v3959 = load i64, ptr %slot26, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i64 %v3958, ptr %p3960, align 8, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot21, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  %ld3963 = load i64, ptr %p3962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3963, ptr %slot714, align 8
  %v3964 = load i64, ptr %slot714, align 8
  %v3965 = load i64, ptr %slot27, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  store i64 %v3964, ptr %p3966, align 8, !alias.scope !3, !noalias !4
  %v3967 = load i64, ptr %slot26, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  %ld3969 = load i64, ptr %p3968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3969, ptr %slot715, align 8
  %v3970 = load i64, ptr %slot27, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  %ld3972 = load i64, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3972, ptr %slot716, align 8
  %v3973 = load i64, ptr %slot1, align 8
  %v3974 = load i64, ptr %slot715, align 8
  %v3975 = load i64, ptr %slot716, align 8
  %call3976 = call i64 @myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b(i64 %v3973, i64 %v3974, i64 %v3975) nomerge, !dbg !168
  store i64 %call3976, ptr %slot717, align 8
  %v3977 = load i64, ptr %slot717, align 8
  %v3978 = load i64, ptr %slot26, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  store i64 %v3977, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  %v3980 = load i64, ptr %slot8, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  %ld3982 = load i32, ptr %p3981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3982, ptr %slot718, align 8
  %v3983 = load i32, ptr %slot718, align 8
  %cv3984 = zext i32 %v3983 to i64
  %cond3985 = icmp ne i64 %cv3984, 0
  br i1 %cond3985, label %bb_rcslotdrop897, label %bb_rcslotdone897
bb_rcslotdrop897:
  %v3986 = load i64, ptr %slot8, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  store i32 0, ptr %p3987, align 4, !alias.scope !3, !noalias !4
  %v3988 = load i64, ptr %slot14, align 8
  store i64 %v3988, ptr %slot719, align 8
  %v3989 = load i64, ptr %slot9, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %ld3991 = load i32, ptr %p3990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3991, ptr %slot720, align 8
  %v3992 = load i32, ptr %slot720, align 8
  %op3993 = and i32 %v3992, 28
  store i32 %op3993, ptr %slot721, align 8
  %v3994 = load i32, ptr %slot721, align 8
  %cv3995 = zext i32 %v3994 to i64
  %cond3996 = icmp ne i64 %cv3995, 0
  br i1 %cond3996, label %bb_rcslotrole897, label %bb_rcslotowner897
bb_rcslotrole897:
  %v3997 = load i64, ptr %slot40, align 8
  store i64 %v3997, ptr %slot722, align 8
  %v3998 = load i64, ptr %slot722, align 8
  %v3999 = load i64, ptr %slot719, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3998, i64 %v3999) nomerge, !dbg !168
  br label %bb_rcslotdone897
bb_rcslotowner897:
  %v4000 = load i64, ptr %slot40, align 8
  store i64 %v4000, ptr %slot723, align 8
  %v4001 = load i64, ptr %slot723, align 8
  %v4002 = load i64, ptr %slot719, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4001, i64 %v4002) nomerge, !dbg !168
  br label %bb_rcslotdone897
bb_rcslotdone897:
  %v4003 = load i64, ptr %slot25, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %ld4005 = load i64, ptr %p4004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4005, ptr %slot724, align 8
  %v4006 = load i64, ptr %slot724, align 8
  %v4007 = load i64, ptr %slot26, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  store i64 %v4006, ptr %p4008, align 8, !alias.scope !3, !noalias !4
  %v4009 = load i64, ptr %slot26, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %ld4011 = load i64, ptr %p4010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4011, ptr %slot725, align 8
  %v4012 = load i64, ptr %slot725, align 8
  %v4013 = load i64, ptr %slot21, align 8
  %p4014 = inttoptr i64 %v4013 to ptr
  store i64 %v4012, ptr %p4014, align 8, !alias.scope !3, !noalias !4
  %v4015 = load i64, ptr %slot19, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  %ld4017 = load i64, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4017, ptr %slot726, align 8
  %v4018 = load i64, ptr %slot726, align 8
  %v4019 = load i64, ptr %slot26, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  store i64 %v4018, ptr %p4020, align 8, !alias.scope !3, !noalias !4
  %v4021 = load i64, ptr %slot23, align 8
  %p4022 = inttoptr i64 %v4021 to ptr
  %ld4023 = load i64, ptr %p4022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4023, ptr %slot727, align 8
  %v4024 = load i64, ptr %slot727, align 8
  %v4025 = load i64, ptr %slot27, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  store i64 %v4024, ptr %p4026, align 8, !alias.scope !3, !noalias !4
  %v4027 = load i64, ptr %slot26, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %ld4029 = load i64, ptr %p4028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4029, ptr %slot728, align 8
  %v4030 = load i64, ptr %slot27, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %ld4032 = load i64, ptr %p4031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4032, ptr %slot729, align 8
  %v4033 = load i64, ptr %slot1, align 8
  %v4034 = load i64, ptr %slot728, align 8
  %v4035 = load i64, ptr %slot729, align 8
  %call4036 = call i64 @myl_f_c72c06ab3343e69c1ed6db828ac50a49dff722092c98b646b2bb7ddde6931cfb(i64 %v4033, i64 %v4034, i64 %v4035) nomerge, !dbg !170
  store i64 %call4036, ptr %slot730, align 8
  %v4037 = load i64, ptr %slot730, align 8
  %v4038 = load i64, ptr %slot26, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i64 %v4037, ptr %p4039, align 8, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot8, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i32, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4042, ptr %slot731, align 8
  %v4043 = load i32, ptr %slot731, align 8
  %cv4044 = zext i32 %v4043 to i64
  %cond4045 = icmp ne i64 %cv4044, 0
  br i1 %cond4045, label %bb_rcslotdrop913, label %bb_rcslotdone913
bb_rcslotdrop913:
  %v4046 = load i64, ptr %slot8, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  store i32 0, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  %v4048 = load i64, ptr %slot14, align 8
  store i64 %v4048, ptr %slot732, align 8
  %v4049 = load i64, ptr %slot9, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %ld4051 = load i32, ptr %p4050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4051, ptr %slot733, align 8
  %v4052 = load i32, ptr %slot733, align 8
  %op4053 = and i32 %v4052, 28
  store i32 %op4053, ptr %slot734, align 8
  %v4054 = load i32, ptr %slot734, align 8
  %cv4055 = zext i32 %v4054 to i64
  %cond4056 = icmp ne i64 %cv4055, 0
  br i1 %cond4056, label %bb_rcslotrole913, label %bb_rcslotowner913
bb_rcslotrole913:
  %v4057 = load i64, ptr %slot40, align 8
  store i64 %v4057, ptr %slot735, align 8
  %v4058 = load i64, ptr %slot735, align 8
  %v4059 = load i64, ptr %slot732, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4058, i64 %v4059) nomerge, !dbg !170
  br label %bb_rcslotdone913
bb_rcslotowner913:
  %v4060 = load i64, ptr %slot40, align 8
  store i64 %v4060, ptr %slot736, align 8
  %v4061 = load i64, ptr %slot736, align 8
  %v4062 = load i64, ptr %slot732, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4061, i64 %v4062) nomerge, !dbg !170
  br label %bb_rcslotdone913
bb_rcslotdone913:
  br label %bb_i93
bb_i93:
  %v4063 = load i64, ptr %slot19, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  %ld4065 = load i64, ptr %p4064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4065, ptr %slot737, align 8
  %v4066 = load i64, ptr %slot737, align 8
  %v4067 = load i64, ptr %slot26, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  store i64 %v4066, ptr %p4068, align 8, !alias.scope !3, !noalias !4
  %v4069 = load i64, ptr %slot26, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %ld4071 = load i64, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4071, ptr %slot738, align 8
  %v4072 = load i64, ptr %slot1, align 8
  %v4073 = load i64, ptr %slot738, align 8
  %call4074 = call i64 @myl_f_fc199839b3a5f5add55a3730c3eeee033e1d3abb43b3de95aed4520fd6c1c4b5(i64 %v4072, i64 %v4073) nomerge, !dbg !172
  store i64 %call4074, ptr %slot739, align 8
  %v4075 = load i64, ptr %slot739, align 8
  %v4076 = load i64, ptr %slot26, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i64 %v4075, ptr %p4077, align 8, !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot8, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i32, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4080, ptr %slot740, align 8
  %v4081 = load i32, ptr %slot740, align 8
  %cv4082 = zext i32 %v4081 to i64
  %cond4083 = icmp ne i64 %cv4082, 0
  br i1 %cond4083, label %bb_rcslotdrop925, label %bb_rcslotdone925
bb_rcslotdrop925:
  %v4084 = load i64, ptr %slot8, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  store i32 0, ptr %p4085, align 4, !alias.scope !3, !noalias !4
  %v4086 = load i64, ptr %slot14, align 8
  store i64 %v4086, ptr %slot741, align 8
  %v4087 = load i64, ptr %slot9, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  %ld4089 = load i32, ptr %p4088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4089, ptr %slot742, align 8
  %v4090 = load i32, ptr %slot742, align 8
  %op4091 = and i32 %v4090, 28
  store i32 %op4091, ptr %slot743, align 8
  %v4092 = load i32, ptr %slot743, align 8
  %cv4093 = zext i32 %v4092 to i64
  %cond4094 = icmp ne i64 %cv4093, 0
  br i1 %cond4094, label %bb_rcslotrole925, label %bb_rcslotowner925
bb_rcslotrole925:
  %v4095 = load i64, ptr %slot40, align 8
  store i64 %v4095, ptr %slot744, align 8
  %v4096 = load i64, ptr %slot744, align 8
  %v4097 = load i64, ptr %slot741, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4096, i64 %v4097) nomerge, !dbg !172
  br label %bb_rcslotdone925
bb_rcslotowner925:
  %v4098 = load i64, ptr %slot40, align 8
  store i64 %v4098, ptr %slot745, align 8
  %v4099 = load i64, ptr %slot745, align 8
  %v4100 = load i64, ptr %slot741, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4099, i64 %v4100) nomerge, !dbg !172
  br label %bb_rcslotdone925
bb_rcslotdone925:
  %v4101 = load i64, ptr %slot19, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  %ld4103 = load i64, ptr %p4102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4103, ptr %slot746, align 8
  %v4104 = load i64, ptr %slot746, align 8
  %v4105 = load i64, ptr %slot26, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i64 %v4104, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot21, align 8
  %p4108 = inttoptr i64 %v4107 to ptr
  %ld4109 = load i64, ptr %p4108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4109, ptr %slot747, align 8
  %v4110 = load i64, ptr %slot747, align 8
  %v4111 = load i64, ptr %slot27, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  store i64 %v4110, ptr %p4112, align 8, !alias.scope !3, !noalias !4
  %v4113 = load i64, ptr %slot26, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %ld4115 = load i64, ptr %p4114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4115, ptr %slot748, align 8
  %v4116 = load i64, ptr %slot27, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %ld4118 = load i64, ptr %p4117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4118, ptr %slot749, align 8
  %v4119 = load i64, ptr %slot1, align 8
  %v4120 = load i64, ptr %slot748, align 8
  %v4121 = load i64, ptr %slot749, align 8
  %call4122 = call i64 @myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b(i64 %v4119, i64 %v4120, i64 %v4121) nomerge, !dbg !174
  store i64 %call4122, ptr %slot750, align 8
  %v4123 = load i64, ptr %slot750, align 8
  %v4124 = load i64, ptr %slot26, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  store i64 %v4123, ptr %p4125, align 8, !alias.scope !3, !noalias !4
  %v4126 = load i64, ptr %slot8, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  %ld4128 = load i32, ptr %p4127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4128, ptr %slot751, align 8
  %v4129 = load i32, ptr %slot751, align 8
  %cv4130 = zext i32 %v4129 to i64
  %cond4131 = icmp ne i64 %cv4130, 0
  br i1 %cond4131, label %bb_rcslotdrop939, label %bb_rcslotdone939
bb_rcslotdrop939:
  %v4132 = load i64, ptr %slot8, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i32 0, ptr %p4133, align 4, !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot14, align 8
  store i64 %v4134, ptr %slot752, align 8
  %v4135 = load i64, ptr %slot9, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %ld4137 = load i32, ptr %p4136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4137, ptr %slot753, align 8
  %v4138 = load i32, ptr %slot753, align 8
  %op4139 = and i32 %v4138, 28
  store i32 %op4139, ptr %slot754, align 8
  %v4140 = load i32, ptr %slot754, align 8
  %cv4141 = zext i32 %v4140 to i64
  %cond4142 = icmp ne i64 %cv4141, 0
  br i1 %cond4142, label %bb_rcslotrole939, label %bb_rcslotowner939
bb_rcslotrole939:
  %v4143 = load i64, ptr %slot40, align 8
  store i64 %v4143, ptr %slot755, align 8
  %v4144 = load i64, ptr %slot755, align 8
  %v4145 = load i64, ptr %slot752, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4144, i64 %v4145) nomerge, !dbg !174
  br label %bb_rcslotdone939
bb_rcslotowner939:
  %v4146 = load i64, ptr %slot40, align 8
  store i64 %v4146, ptr %slot756, align 8
  %v4147 = load i64, ptr %slot756, align 8
  %v4148 = load i64, ptr %slot752, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4147, i64 %v4148) nomerge, !dbg !174
  br label %bb_rcslotdone939
bb_rcslotdone939:
  %v4149 = load i64, ptr %slot22, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  %ld4151 = load i64, ptr %p4150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4151, ptr %slot757, align 8
  %v4152 = load i64, ptr %slot757, align 8
  %v4153 = load i64, ptr %slot26, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  store i64 %v4152, ptr %p4154, align 8, !alias.scope !3, !noalias !4
  %v4155 = load i64, ptr %slot27, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  store i64 18446744073709551615, ptr %p4156, align 8, !alias.scope !3, !noalias !4
  %v4157 = load i64, ptr %slot27, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %ld4159 = load i64, ptr %p4158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4159, ptr %slot758, align 8
  %v4160 = load i64, ptr %slot26, align 8
  %p4161 = inttoptr i64 %v4160 to ptr
  %ld4162 = load i64, ptr %p4161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4162, ptr %slot759, align 8
  %v4163 = load i64, ptr %slot759, align 8
  %v4164 = load i64, ptr %slot758, align 8
  %cmp4165 = icmp ne i64 %v4163, %v4164
  %cv4166 = zext i1 %cmp4165 to i64
  store i64 %cv4166, ptr %slot760, align 8
  %v4167 = load i64, ptr %slot760, align 8
  %v4168 = load i64, ptr %slot26, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  store i64 %v4167, ptr %p4169, align 8, !alias.scope !3, !noalias !4
  %v4170 = load i64, ptr %slot26, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %ld4172 = load i64, ptr %p4171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4172, ptr %slot761, align 8
  %v4173 = load i64, ptr %slot761, align 8
  %cond4174 = icmp ne i64 %v4173, 0
  br i1 %cond4174, label %bb_next951, label %bb_i112
bb_next951:
  %v4175 = load i64, ptr %slot19, align 8
  %p4176 = inttoptr i64 %v4175 to ptr
  %ld4177 = load i64, ptr %p4176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4177, ptr %slot762, align 8
  %v4178 = load i64, ptr %slot762, align 8
  %v4179 = load i64, ptr %slot26, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  store i64 %v4178, ptr %p4180, align 8, !alias.scope !3, !noalias !4
  %v4181 = load i64, ptr %slot22, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i64, ptr %p4182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4183, ptr %slot763, align 8
  %v4184 = load i64, ptr %slot763, align 8
  %v4185 = load i64, ptr %slot27, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  store i64 %v4184, ptr %p4186, align 8, !alias.scope !3, !noalias !4
  %v4187 = load i64, ptr %slot26, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %ld4189 = load i64, ptr %p4188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4189, ptr %slot764, align 8
  %v4190 = load i64, ptr %slot27, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %ld4192 = load i64, ptr %p4191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4192, ptr %slot765, align 8
  %v4193 = load i64, ptr %slot1, align 8
  %v4194 = load i64, ptr %slot764, align 8
  %v4195 = load i64, ptr %slot765, align 8
  %call4196 = call i64 @myl_f_c72c06ab3343e69c1ed6db828ac50a49dff722092c98b646b2bb7ddde6931cfb(i64 %v4193, i64 %v4194, i64 %v4195) nomerge, !dbg !176
  store i64 %call4196, ptr %slot766, align 8
  %v4197 = load i64, ptr %slot766, align 8
  %v4198 = load i64, ptr %slot26, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  store i64 %v4197, ptr %p4199, align 8, !alias.scope !3, !noalias !4
  %v4200 = load i64, ptr %slot8, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  %ld4202 = load i32, ptr %p4201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4202, ptr %slot767, align 8
  %v4203 = load i32, ptr %slot767, align 8
  %cv4204 = zext i32 %v4203 to i64
  %cond4205 = icmp ne i64 %cv4204, 0
  br i1 %cond4205, label %bb_rcslotdrop958, label %bb_rcslotdone958
bb_rcslotdrop958:
  %v4206 = load i64, ptr %slot8, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  store i32 0, ptr %p4207, align 4, !alias.scope !3, !noalias !4
  %v4208 = load i64, ptr %slot14, align 8
  store i64 %v4208, ptr %slot768, align 8
  %v4209 = load i64, ptr %slot9, align 8
  %p4210 = inttoptr i64 %v4209 to ptr
  %ld4211 = load i32, ptr %p4210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4211, ptr %slot769, align 8
  %v4212 = load i32, ptr %slot769, align 8
  %op4213 = and i32 %v4212, 28
  store i32 %op4213, ptr %slot770, align 8
  %v4214 = load i32, ptr %slot770, align 8
  %cv4215 = zext i32 %v4214 to i64
  %cond4216 = icmp ne i64 %cv4215, 0
  br i1 %cond4216, label %bb_rcslotrole958, label %bb_rcslotowner958
bb_rcslotrole958:
  %v4217 = load i64, ptr %slot40, align 8
  store i64 %v4217, ptr %slot771, align 8
  %v4218 = load i64, ptr %slot771, align 8
  %v4219 = load i64, ptr %slot768, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4218, i64 %v4219) nomerge, !dbg !176
  br label %bb_rcslotdone958
bb_rcslotowner958:
  %v4220 = load i64, ptr %slot40, align 8
  store i64 %v4220, ptr %slot772, align 8
  %v4221 = load i64, ptr %slot772, align 8
  %v4222 = load i64, ptr %slot768, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4221, i64 %v4222) nomerge, !dbg !176
  br label %bb_rcslotdone958
bb_rcslotdone958:
  %v4223 = load i64, ptr %slot19, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  %ld4225 = load i64, ptr %p4224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4225, ptr %slot773, align 8
  %v4226 = load i64, ptr %slot773, align 8
  %v4227 = load i64, ptr %slot26, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  store i64 %v4226, ptr %p4228, align 8, !alias.scope !3, !noalias !4
  %v4229 = load i64, ptr %slot27, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  store i64 4, ptr %p4230, align 8, !alias.scope !3, !noalias !4
  %v4231 = load i64, ptr %slot26, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i64, ptr %p4232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4233, ptr %slot774, align 8
  %v4234 = load i64, ptr %slot27, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  %ld4236 = load i64, ptr %p4235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4236, ptr %slot775, align 8
  %v4237 = load i64, ptr %slot1, align 8
  %v4238 = load i64, ptr %slot774, align 8
  %v4239 = load i64, ptr %slot775, align 8
  %call4240 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v4237, i64 %v4238, i64 %v4239) nomerge, !dbg !178
  store i64 %call4240, ptr %slot776, align 8
  %v4241 = load i64, ptr %slot776, align 8
  %v4242 = load i64, ptr %slot26, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  store i64 %v4241, ptr %p4243, align 8, !alias.scope !3, !noalias !4
  %v4244 = load i64, ptr %slot8, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %ld4246 = load i32, ptr %p4245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4246, ptr %slot777, align 8
  %v4247 = load i32, ptr %slot777, align 8
  %cv4248 = zext i32 %v4247 to i64
  %cond4249 = icmp ne i64 %cv4248, 0
  br i1 %cond4249, label %bb_rcslotdrop971, label %bb_rcslotdone971
bb_rcslotdrop971:
  %v4250 = load i64, ptr %slot8, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  store i32 0, ptr %p4251, align 4, !alias.scope !3, !noalias !4
  %v4252 = load i64, ptr %slot14, align 8
  store i64 %v4252, ptr %slot778, align 8
  %v4253 = load i64, ptr %slot9, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  %ld4255 = load i32, ptr %p4254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4255, ptr %slot779, align 8
  %v4256 = load i32, ptr %slot779, align 8
  %op4257 = and i32 %v4256, 28
  store i32 %op4257, ptr %slot780, align 8
  %v4258 = load i32, ptr %slot780, align 8
  %cv4259 = zext i32 %v4258 to i64
  %cond4260 = icmp ne i64 %cv4259, 0
  br i1 %cond4260, label %bb_rcslotrole971, label %bb_rcslotowner971
bb_rcslotrole971:
  %v4261 = load i64, ptr %slot40, align 8
  store i64 %v4261, ptr %slot781, align 8
  %v4262 = load i64, ptr %slot781, align 8
  %v4263 = load i64, ptr %slot778, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4262, i64 %v4263) nomerge, !dbg !178
  br label %bb_rcslotdone971
bb_rcslotowner971:
  %v4264 = load i64, ptr %slot40, align 8
  store i64 %v4264, ptr %slot782, align 8
  %v4265 = load i64, ptr %slot782, align 8
  %v4266 = load i64, ptr %slot778, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4265, i64 %v4266) nomerge, !dbg !178
  br label %bb_rcslotdone971
bb_rcslotdone971:
  br label %bb_i112
bb_i112:
  %v4267 = load i64, ptr %slot19, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  %ld4269 = load i64, ptr %p4268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4269, ptr %slot783, align 8
  %v4270 = load i64, ptr %slot783, align 8
  %v4271 = load i64, ptr %slot26, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  store i64 %v4270, ptr %p4272, align 8, !alias.scope !3, !noalias !4
  %v4273 = load i64, ptr %slot26, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %ld4275 = load i64, ptr %p4274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4275, ptr %slot784, align 8
  %v4276 = load i64, ptr %slot1, align 8
  %v4277 = load i64, ptr %slot784, align 8
  %call4278 = call i64 @myl_f_224a81e5e8d25136966073a5e394df36a430ed416d49f73f69179495cdb9bb91(i64 %v4276, i64 %v4277) nomerge, !dbg !180
  store i64 %call4278, ptr %slot785, align 8
  %v4279 = load i64, ptr %slot785, align 8
  %v4280 = load i64, ptr %slot26, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  store i64 %v4279, ptr %p4281, align 8, !alias.scope !3, !noalias !4
  %v4282 = load i64, ptr %slot8, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %ld4284 = load i32, ptr %p4283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4284, ptr %slot786, align 8
  %v4285 = load i32, ptr %slot786, align 8
  %cv4286 = zext i32 %v4285 to i64
  %cond4287 = icmp ne i64 %cv4286, 0
  br i1 %cond4287, label %bb_rcslotdrop983, label %bb_rcslotdone983
bb_rcslotdrop983:
  %v4288 = load i64, ptr %slot8, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  store i32 0, ptr %p4289, align 4, !alias.scope !3, !noalias !4
  %v4290 = load i64, ptr %slot14, align 8
  store i64 %v4290, ptr %slot787, align 8
  %v4291 = load i64, ptr %slot9, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  %ld4293 = load i32, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4293, ptr %slot788, align 8
  %v4294 = load i32, ptr %slot788, align 8
  %op4295 = and i32 %v4294, 28
  store i32 %op4295, ptr %slot789, align 8
  %v4296 = load i32, ptr %slot789, align 8
  %cv4297 = zext i32 %v4296 to i64
  %cond4298 = icmp ne i64 %cv4297, 0
  br i1 %cond4298, label %bb_rcslotrole983, label %bb_rcslotowner983
bb_rcslotrole983:
  %v4299 = load i64, ptr %slot40, align 8
  store i64 %v4299, ptr %slot790, align 8
  %v4300 = load i64, ptr %slot790, align 8
  %v4301 = load i64, ptr %slot787, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4300, i64 %v4301) nomerge, !dbg !180
  br label %bb_rcslotdone983
bb_rcslotowner983:
  %v4302 = load i64, ptr %slot40, align 8
  store i64 %v4302, ptr %slot791, align 8
  %v4303 = load i64, ptr %slot791, align 8
  %v4304 = load i64, ptr %slot787, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4303, i64 %v4304) nomerge, !dbg !180
  br label %bb_rcslotdone983
bb_rcslotdone983:
  %v4305 = load i64, ptr %slot26, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  store i64 0, ptr %p4306, align 8, !alias.scope !3, !noalias !4
  %v4307 = load i64, ptr %slot26, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  %ld4309 = load i64, ptr %p4308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4309, ptr %slot792, align 8
  %v4310 = load i64, ptr %slot8, align 8
  %p4311 = inttoptr i64 %v4310 to ptr
  %ld4312 = load i32, ptr %p4311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4312, ptr %slot793, align 8
  %v4313 = load i32, ptr %slot793, align 8
  %cv4314 = zext i32 %v4313 to i64
  %cond4315 = icmp ne i64 %cv4314, 0
  br i1 %cond4315, label %bb_rcslotdrop993, label %bb_rcslotdone993
bb_rcslotdrop993:
  %v4316 = load i64, ptr %slot8, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  store i32 0, ptr %p4317, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone993
bb_rcslotdone993:
  %v4318 = load i64, ptr %slot6, align 8
  %p4319 = inttoptr i64 %v4318 to ptr
  %ld4320 = load i32, ptr %p4319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4320, ptr %slot794, align 8
  %v4321 = load i32, ptr %slot794, align 8
  %cv4322 = zext i32 %v4321 to i64
  %cond4323 = icmp ne i64 %cv4322, 0
  br i1 %cond4323, label %bb_rcslotdrop996, label %bb_rcslotdone996
bb_rcslotdrop996:
  %v4324 = load i64, ptr %slot6, align 8
  %p4325 = inttoptr i64 %v4324 to ptr
  store i32 0, ptr %p4325, align 4, !alias.scope !3, !noalias !4
  %v4326 = load i64, ptr %slot24, align 8
  store i64 %v4326, ptr %slot795, align 8
  %v4327 = load i64, ptr %slot7, align 8
  %p4328 = inttoptr i64 %v4327 to ptr
  %ld4329 = load i32, ptr %p4328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4329, ptr %slot796, align 8
  %v4330 = load i32, ptr %slot796, align 8
  %op4331 = and i32 %v4330, 28
  store i32 %op4331, ptr %slot797, align 8
  %v4332 = load i32, ptr %slot797, align 8
  %cv4333 = zext i32 %v4332 to i64
  %cond4334 = icmp ne i64 %cv4333, 0
  br i1 %cond4334, label %bb_rcslotrole996, label %bb_rcslotowner996
bb_rcslotrole996:
  %v4335 = load i64, ptr %slot40, align 8
  store i64 %v4335, ptr %slot798, align 8
  %v4336 = load i64, ptr %slot795, align 8
  %p4337 = inttoptr i64 %v4336 to ptr
  %ld4338 = load i64, ptr %p4337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4338, ptr %slot799, align 8
  %v4339 = load i64, ptr %slot799, align 8
  %cmp4340 = icmp ne i64 %v4339, 0
  %cv4341 = zext i1 %cmp4340 to i32
  store i32 %cv4341, ptr %slot800, align 8
  %v4342 = load i32, ptr %slot800, align 8
  %cv4343 = zext i32 %v4342 to i64
  %cond4344 = icmp ne i64 %cv4343, 0
  br i1 %cond4344, label %bb_rcgnn1012, label %bb_rcgdone1012
bb_rcgnn1012:
  %v4345 = load i64, ptr %slot799, align 8
  %op4346 = sub i64 %v4345, 16
  store i64 %op4346, ptr %slot801, align 8
  %v4347 = load i64, ptr %slot799, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  %rgep4349 = getelementptr i8, ptr %p4348, i64 -16
  %ld4350 = load i64, ptr %rgep4349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4350, ptr %slot802, align 8
  %v4351 = load i64, ptr %slot802, align 8
  %op4352 = and i64 %v4351, 4611686018427387906
  store i64 %op4352, ptr %slot803, align 8
  %v4353 = load i64, ptr %slot803, align 8
  %cmp4354 = icmp ne i64 %v4353, 0
  %cv4355 = zext i1 %cmp4354 to i32
  store i32 %cv4355, ptr %slot804, align 8
  %v4356 = load i32, ptr %slot804, align 8
  %cv4357 = zext i32 %v4356 to i64
  %cond4358 = icmp ne i64 %cv4357, 0
  br i1 %cond4358, label %bb_rcgclear1012, label %bb_rcgcounted1012
bb_rcgcounted1012:
  %v4359 = load i64, ptr %slot799, align 8
  %op4360 = sub i64 %v4359, 24
  store i64 %op4360, ptr %slot805, align 8
  %v4361 = load i64, ptr %slot799, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  %rgep4363 = getelementptr i8, ptr %p4362, i64 -24
  %ld4364 = load i64, ptr %rgep4363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4364, ptr %slot806, align 8
  %v4365 = load i64, ptr %slot806, align 8
  %op4366 = sub i64 %v4365, 1
  store i64 %op4366, ptr %slot807, align 8
  %v4367 = load i64, ptr %slot807, align 8
  %cmp4368 = icmp eq i64 %v4367, 0
  %cv4369 = zext i1 %cmp4368 to i32
  store i32 %cv4369, ptr %slot808, align 8
  %v4370 = load i32, ptr %slot808, align 8
  %cv4371 = zext i32 %v4370 to i64
  %cond4372 = icmp ne i64 %cv4371, 0
  br i1 %cond4372, label %bb_rcglast1012, label %bb_rcgdec1012
bb_rcglast1012:
  %v4373 = load i64, ptr %slot799, align 8
  %op4374 = sub i64 %v4373, 32
  store i64 %op4374, ptr %slot809, align 8
  %v4375 = load i64, ptr %slot799, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  %rgep4377 = getelementptr i8, ptr %p4376, i64 -32
  %ld4378 = load i64, ptr %rgep4377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4378, ptr %slot810, align 8
  %v4379 = load i64, ptr %slot810, align 8
  %cmp4380 = icmp ne i64 %v4379, 0
  %cv4381 = zext i1 %cmp4380 to i32
  store i32 %cv4381, ptr %slot811, align 8
  %v4382 = load i32, ptr %slot811, align 8
  %cv4383 = zext i32 %v4382 to i64
  %cond4384 = icmp ne i64 %cv4383, 0
  br i1 %cond4384, label %bb_rcgdec1012, label %bb_rcgslow1012
bb_rcgslow1012:
  %v4385 = load i64, ptr %slot798, align 8
  %v4386 = load i64, ptr %slot795, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4385, i64 %v4386) nomerge, !dbg !182
  br label %bb_rcgdone1012
bb_rcgdec1012:
  %v4387 = load i64, ptr %slot807, align 8
  %v4388 = load i64, ptr %slot799, align 8
  %p4389 = inttoptr i64 %v4388 to ptr
  %rgep4390 = getelementptr i8, ptr %p4389, i64 -24
  store i64 %v4387, ptr %rgep4390, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1012
bb_rcgclear1012:
  %v4391 = load i64, ptr %slot795, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  store i64 0, ptr %p4392, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1012
bb_rcgdone1012:
  br label %bb_rcslotdone996
bb_rcslotowner996:
  %v4393 = load i64, ptr %slot40, align 8
  store i64 %v4393, ptr %slot812, align 8
  %v4394 = load i64, ptr %slot795, align 8
  %p4395 = inttoptr i64 %v4394 to ptr
  %ld4396 = load i64, ptr %p4395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4396, ptr %slot813, align 8
  %v4397 = load i64, ptr %slot813, align 8
  %cmp4398 = icmp ne i64 %v4397, 0
  %cv4399 = zext i1 %cmp4398 to i32
  store i32 %cv4399, ptr %slot814, align 8
  %v4400 = load i32, ptr %slot814, align 8
  %cv4401 = zext i32 %v4400 to i64
  %cond4402 = icmp ne i64 %cv4401, 0
  br i1 %cond4402, label %bb_rcgnn1027, label %bb_rcgdone1027
bb_rcgnn1027:
  %v4403 = load i64, ptr %slot813, align 8
  %op4404 = sub i64 %v4403, 16
  store i64 %op4404, ptr %slot815, align 8
  %v4405 = load i64, ptr %slot813, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  %rgep4407 = getelementptr i8, ptr %p4406, i64 -16
  %ld4408 = load i64, ptr %rgep4407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4408, ptr %slot816, align 8
  %v4409 = load i64, ptr %slot816, align 8
  %op4410 = and i64 %v4409, 4611686018427387906
  store i64 %op4410, ptr %slot817, align 8
  %v4411 = load i64, ptr %slot817, align 8
  %cmp4412 = icmp ne i64 %v4411, 0
  %cv4413 = zext i1 %cmp4412 to i32
  store i32 %cv4413, ptr %slot818, align 8
  %v4414 = load i32, ptr %slot818, align 8
  %cv4415 = zext i32 %v4414 to i64
  %cond4416 = icmp ne i64 %cv4415, 0
  br i1 %cond4416, label %bb_rcgclear1027, label %bb_rcgcounted1027
bb_rcgcounted1027:
  %v4417 = load i64, ptr %slot813, align 8
  %op4418 = sub i64 %v4417, 32
  store i64 %op4418, ptr %slot819, align 8
  %v4419 = load i64, ptr %slot813, align 8
  %p4420 = inttoptr i64 %v4419 to ptr
  %rgep4421 = getelementptr i8, ptr %p4420, i64 -32
  %ld4422 = load i64, ptr %rgep4421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4422, ptr %slot820, align 8
  %v4423 = load i64, ptr %slot820, align 8
  %op4424 = sub i64 %v4423, 1
  store i64 %op4424, ptr %slot821, align 8
  %v4425 = load i64, ptr %slot821, align 8
  %cmp4426 = icmp eq i64 %v4425, 0
  %cv4427 = zext i1 %cmp4426 to i32
  store i32 %cv4427, ptr %slot822, align 8
  %v4428 = load i32, ptr %slot822, align 8
  %cv4429 = zext i32 %v4428 to i64
  %cond4430 = icmp ne i64 %cv4429, 0
  br i1 %cond4430, label %bb_rcglast1027, label %bb_rcgdec1027
bb_rcglast1027:
  %v4431 = load i64, ptr %slot813, align 8
  %op4432 = sub i64 %v4431, 24
  store i64 %op4432, ptr %slot823, align 8
  %v4433 = load i64, ptr %slot813, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %rgep4435 = getelementptr i8, ptr %p4434, i64 -24
  %ld4436 = load i64, ptr %rgep4435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4436, ptr %slot824, align 8
  %v4437 = load i64, ptr %slot824, align 8
  %cmp4438 = icmp ne i64 %v4437, 0
  %cv4439 = zext i1 %cmp4438 to i32
  store i32 %cv4439, ptr %slot825, align 8
  %v4440 = load i32, ptr %slot825, align 8
  %cv4441 = zext i32 %v4440 to i64
  %cond4442 = icmp ne i64 %cv4441, 0
  br i1 %cond4442, label %bb_rcgdec1027, label %bb_rcgslow1027
bb_rcgslow1027:
  %v4443 = load i64, ptr %slot812, align 8
  %v4444 = load i64, ptr %slot795, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4443, i64 %v4444) nomerge, !dbg !182
  br label %bb_rcgdone1027
bb_rcgdec1027:
  %v4445 = load i64, ptr %slot821, align 8
  %v4446 = load i64, ptr %slot813, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  %rgep4448 = getelementptr i8, ptr %p4447, i64 -32
  store i64 %v4445, ptr %rgep4448, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1027
bb_rcgclear1027:
  %v4449 = load i64, ptr %slot795, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  store i64 0, ptr %p4450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1027
bb_rcgdone1027:
  br label %bb_rcslotdone996
bb_rcslotdone996:
  %v4451 = load i64, ptr %slot4, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  %ld4453 = load i32, ptr %p4452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4453, ptr %slot826, align 8
  %v4454 = load i32, ptr %slot826, align 8
  %cv4455 = zext i32 %v4454 to i64
  %cond4456 = icmp ne i64 %cv4455, 0
  br i1 %cond4456, label %bb_rcslotdrop1033, label %bb_rcslotdone1033
bb_rcslotdrop1033:
  %v4457 = load i64, ptr %slot4, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  store i32 0, ptr %p4458, align 4, !alias.scope !3, !noalias !4
  %v4459 = load i64, ptr %slot20, align 8
  store i64 %v4459, ptr %slot827, align 8
  %v4460 = load i64, ptr %slot5, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  %ld4462 = load i32, ptr %p4461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4462, ptr %slot828, align 8
  %v4463 = load i32, ptr %slot828, align 8
  %op4464 = and i32 %v4463, 28
  store i32 %op4464, ptr %slot829, align 8
  %v4465 = load i32, ptr %slot829, align 8
  %cv4466 = zext i32 %v4465 to i64
  %cond4467 = icmp ne i64 %cv4466, 0
  br i1 %cond4467, label %bb_rcslotrole1033, label %bb_rcslotowner1033
bb_rcslotrole1033:
  %v4468 = load i64, ptr %slot40, align 8
  store i64 %v4468, ptr %slot830, align 8
  %v4469 = load i64, ptr %slot827, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  %ld4471 = load i64, ptr %p4470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4471, ptr %slot831, align 8
  %v4472 = load i64, ptr %slot831, align 8
  %cmp4473 = icmp ne i64 %v4472, 0
  %cv4474 = zext i1 %cmp4473 to i32
  store i32 %cv4474, ptr %slot832, align 8
  %v4475 = load i32, ptr %slot832, align 8
  %cv4476 = zext i32 %v4475 to i64
  %cond4477 = icmp ne i64 %cv4476, 0
  br i1 %cond4477, label %bb_rcgnn1049, label %bb_rcgdone1049
bb_rcgnn1049:
  %v4478 = load i64, ptr %slot831, align 8
  %op4479 = sub i64 %v4478, 16
  store i64 %op4479, ptr %slot833, align 8
  %v4480 = load i64, ptr %slot831, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  %rgep4482 = getelementptr i8, ptr %p4481, i64 -16
  %ld4483 = load i64, ptr %rgep4482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4483, ptr %slot834, align 8
  %v4484 = load i64, ptr %slot834, align 8
  %op4485 = and i64 %v4484, 4611686018427387906
  store i64 %op4485, ptr %slot835, align 8
  %v4486 = load i64, ptr %slot835, align 8
  %cmp4487 = icmp ne i64 %v4486, 0
  %cv4488 = zext i1 %cmp4487 to i32
  store i32 %cv4488, ptr %slot836, align 8
  %v4489 = load i32, ptr %slot836, align 8
  %cv4490 = zext i32 %v4489 to i64
  %cond4491 = icmp ne i64 %cv4490, 0
  br i1 %cond4491, label %bb_rcgclear1049, label %bb_rcgcounted1049
bb_rcgcounted1049:
  %v4492 = load i64, ptr %slot831, align 8
  %op4493 = sub i64 %v4492, 24
  store i64 %op4493, ptr %slot837, align 8
  %v4494 = load i64, ptr %slot831, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  %rgep4496 = getelementptr i8, ptr %p4495, i64 -24
  %ld4497 = load i64, ptr %rgep4496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4497, ptr %slot838, align 8
  %v4498 = load i64, ptr %slot838, align 8
  %op4499 = sub i64 %v4498, 1
  store i64 %op4499, ptr %slot839, align 8
  %v4500 = load i64, ptr %slot839, align 8
  %cmp4501 = icmp eq i64 %v4500, 0
  %cv4502 = zext i1 %cmp4501 to i32
  store i32 %cv4502, ptr %slot840, align 8
  %v4503 = load i32, ptr %slot840, align 8
  %cv4504 = zext i32 %v4503 to i64
  %cond4505 = icmp ne i64 %cv4504, 0
  br i1 %cond4505, label %bb_rcglast1049, label %bb_rcgdec1049
bb_rcglast1049:
  %v4506 = load i64, ptr %slot831, align 8
  %op4507 = sub i64 %v4506, 32
  store i64 %op4507, ptr %slot841, align 8
  %v4508 = load i64, ptr %slot831, align 8
  %p4509 = inttoptr i64 %v4508 to ptr
  %rgep4510 = getelementptr i8, ptr %p4509, i64 -32
  %ld4511 = load i64, ptr %rgep4510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4511, ptr %slot842, align 8
  %v4512 = load i64, ptr %slot842, align 8
  %cmp4513 = icmp ne i64 %v4512, 0
  %cv4514 = zext i1 %cmp4513 to i32
  store i32 %cv4514, ptr %slot843, align 8
  %v4515 = load i32, ptr %slot843, align 8
  %cv4516 = zext i32 %v4515 to i64
  %cond4517 = icmp ne i64 %cv4516, 0
  br i1 %cond4517, label %bb_rcgdec1049, label %bb_rcgslow1049
bb_rcgslow1049:
  %v4518 = load i64, ptr %slot830, align 8
  %v4519 = load i64, ptr %slot827, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4518, i64 %v4519) nomerge, !dbg !182
  br label %bb_rcgdone1049
bb_rcgdec1049:
  %v4520 = load i64, ptr %slot839, align 8
  %v4521 = load i64, ptr %slot831, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  %rgep4523 = getelementptr i8, ptr %p4522, i64 -24
  store i64 %v4520, ptr %rgep4523, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1049
bb_rcgclear1049:
  %v4524 = load i64, ptr %slot827, align 8
  %p4525 = inttoptr i64 %v4524 to ptr
  store i64 0, ptr %p4525, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1049
bb_rcgdone1049:
  br label %bb_rcslotdone1033
bb_rcslotowner1033:
  %v4526 = load i64, ptr %slot40, align 8
  store i64 %v4526, ptr %slot844, align 8
  %v4527 = load i64, ptr %slot827, align 8
  %p4528 = inttoptr i64 %v4527 to ptr
  %ld4529 = load i64, ptr %p4528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4529, ptr %slot845, align 8
  %v4530 = load i64, ptr %slot845, align 8
  %cmp4531 = icmp ne i64 %v4530, 0
  %cv4532 = zext i1 %cmp4531 to i32
  store i32 %cv4532, ptr %slot846, align 8
  %v4533 = load i32, ptr %slot846, align 8
  %cv4534 = zext i32 %v4533 to i64
  %cond4535 = icmp ne i64 %cv4534, 0
  br i1 %cond4535, label %bb_rcgnn1064, label %bb_rcgdone1064
bb_rcgnn1064:
  %v4536 = load i64, ptr %slot845, align 8
  %op4537 = sub i64 %v4536, 16
  store i64 %op4537, ptr %slot847, align 8
  %v4538 = load i64, ptr %slot845, align 8
  %p4539 = inttoptr i64 %v4538 to ptr
  %rgep4540 = getelementptr i8, ptr %p4539, i64 -16
  %ld4541 = load i64, ptr %rgep4540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4541, ptr %slot848, align 8
  %v4542 = load i64, ptr %slot848, align 8
  %op4543 = and i64 %v4542, 4611686018427387906
  store i64 %op4543, ptr %slot849, align 8
  %v4544 = load i64, ptr %slot849, align 8
  %cmp4545 = icmp ne i64 %v4544, 0
  %cv4546 = zext i1 %cmp4545 to i32
  store i32 %cv4546, ptr %slot850, align 8
  %v4547 = load i32, ptr %slot850, align 8
  %cv4548 = zext i32 %v4547 to i64
  %cond4549 = icmp ne i64 %cv4548, 0
  br i1 %cond4549, label %bb_rcgclear1064, label %bb_rcgcounted1064
bb_rcgcounted1064:
  %v4550 = load i64, ptr %slot845, align 8
  %op4551 = sub i64 %v4550, 32
  store i64 %op4551, ptr %slot851, align 8
  %v4552 = load i64, ptr %slot845, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %rgep4554 = getelementptr i8, ptr %p4553, i64 -32
  %ld4555 = load i64, ptr %rgep4554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4555, ptr %slot852, align 8
  %v4556 = load i64, ptr %slot852, align 8
  %op4557 = sub i64 %v4556, 1
  store i64 %op4557, ptr %slot853, align 8
  %v4558 = load i64, ptr %slot853, align 8
  %cmp4559 = icmp eq i64 %v4558, 0
  %cv4560 = zext i1 %cmp4559 to i32
  store i32 %cv4560, ptr %slot854, align 8
  %v4561 = load i32, ptr %slot854, align 8
  %cv4562 = zext i32 %v4561 to i64
  %cond4563 = icmp ne i64 %cv4562, 0
  br i1 %cond4563, label %bb_rcglast1064, label %bb_rcgdec1064
bb_rcglast1064:
  %v4564 = load i64, ptr %slot845, align 8
  %op4565 = sub i64 %v4564, 24
  store i64 %op4565, ptr %slot855, align 8
  %v4566 = load i64, ptr %slot845, align 8
  %p4567 = inttoptr i64 %v4566 to ptr
  %rgep4568 = getelementptr i8, ptr %p4567, i64 -24
  %ld4569 = load i64, ptr %rgep4568, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4569, ptr %slot856, align 8
  %v4570 = load i64, ptr %slot856, align 8
  %cmp4571 = icmp ne i64 %v4570, 0
  %cv4572 = zext i1 %cmp4571 to i32
  store i32 %cv4572, ptr %slot857, align 8
  %v4573 = load i32, ptr %slot857, align 8
  %cv4574 = zext i32 %v4573 to i64
  %cond4575 = icmp ne i64 %cv4574, 0
  br i1 %cond4575, label %bb_rcgdec1064, label %bb_rcgslow1064
bb_rcgslow1064:
  %v4576 = load i64, ptr %slot844, align 8
  %v4577 = load i64, ptr %slot827, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4576, i64 %v4577) nomerge, !dbg !182
  br label %bb_rcgdone1064
bb_rcgdec1064:
  %v4578 = load i64, ptr %slot853, align 8
  %v4579 = load i64, ptr %slot845, align 8
  %p4580 = inttoptr i64 %v4579 to ptr
  %rgep4581 = getelementptr i8, ptr %p4580, i64 -32
  store i64 %v4578, ptr %rgep4581, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1064
bb_rcgclear1064:
  %v4582 = load i64, ptr %slot827, align 8
  %p4583 = inttoptr i64 %v4582 to ptr
  store i64 0, ptr %p4583, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1064
bb_rcgdone1064:
  br label %bb_rcslotdone1033
bb_rcslotdone1033:
  %v4584 = load i64, ptr %slot792, align 8
  ret i64 %v4584
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_067e6c15dd3a19c7a0dc5698a499ce7f48299235035df0ce9ae0949c3635b214 = external global i8, align 8
@myl_lit_68ffc8926d53b76965bdbc497371091db72d87c782d401cb624f0db3a87df30d = external global i8, align 8
@myl_lit_7f4f337a6e923b05d193f53f8564c65d6750af944141b2572482a0a0d4262aba = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_224a81e5e8d25136966073a5e394df36a430ed416d49f73f69179495cdb9bb91(i64, i64)
declare void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8, i64, i64)
declare i64 @myl_f_2f610d65ff9d8de8448ce74fb4f0d7608052b9fdb008fde954187d627f662f71(i64, i64)
declare i64 @myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6(i64, i64)
declare i64 @myl_f_3c3113ea32e66223d42a837057841fde068d2faf3564529d972f91bef991dedd(i64, i64, i64)
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare i64 @myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45(i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare i64 @myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b(i64, i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare i64 @myl_f_c72c06ab3343e69c1ed6db828ac50a49dff722092c98b646b2bb7ddde6931cfb(i64, i64, i64)
declare i64 @myl_f_fc199839b3a5f5add55a3730c3eeee033e1d3abb43b3de95aed4520fd6c1c4b5(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_int_neg(ptr, i64, i64, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_57a50a1a8ccb9a1d0e6e13287edd0dfca9e3375297618fcdcaab82f07def5641", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_57a50a1a8ccb9a1d0e6e13287edd0dfca9e3375297618fcdcaab82f07def5641", linkageName: "myl_f_57a50a1a8ccb9a1d0e6e13287edd0dfca9e3375297618fcdcaab82f07def5641", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9803308655820800863, i64 0, !"myl_f_57a50a1a8ccb9a1d0e6e13287edd0dfca9e3375297618fcdcaab82f07def5641"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!124 = !DILocation(line: 23, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!126 = !DILocation(line: 26, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!128 = !DILocation(line: 27, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!130 = !DILocation(line: 28, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!132 = !DILocation(line: 30, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!138 = !DILocation(line: 37, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!140 = !DILocation(line: 41, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!142 = !DILocation(line: 46, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!144 = !DILocation(line: 50, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!146 = !DILocation(line: 54, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!148 = !DILocation(line: 58, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!150 = !DILocation(line: 63, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!152 = !DILocation(line: 66, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!154 = !DILocation(line: 67, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!156 = !DILocation(line: 68, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!158 = !DILocation(line: 70, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!160 = !DILocation(line: 71, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!162 = !DILocation(line: 73, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!164 = !DILocation(line: 77, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!166 = !DILocation(line: 82, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!168 = !DILocation(line: 86, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!170 = !DILocation(line: 92, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647295)
!172 = !DILocation(line: 95, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!174 = !DILocation(line: 99, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!176 = !DILocation(line: 107, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!178 = !DILocation(line: 111, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!180 = !DILocation(line: 114, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!182 = !DILocation(line: 117, column: 0, scope: !183)
