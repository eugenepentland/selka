target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %callresult24 = alloca [16 x i8], align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v72 = load i64, ptr %slot1, align 8
  %op73 = add i64 %v72, 32
  store i64 %op73, ptr %slot4, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot5, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot6, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot7, align 8
  %mem80 = alloca i8, i64 208, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot8, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot9, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot10, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot11, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot12, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot13, align 8
  %v92 = load i64, ptr %slot1, align 8
  %op93 = add i64 %v92, 64
  store i64 %op93, ptr %slot14, align 8
  %v94 = load i64, ptr %slot14, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !4, !noalias !3
  store i64 %ld96, ptr %slot15, align 8
  %stack97 = call ptr @llvm.stacksave()
  %stackaddr98 = ptrtoint ptr %stack97 to i64
  %v99 = load i64, ptr %slot15, align 8
  %cmp100 = icmp ult i64 %stackaddr98, %v99
  %cv101 = zext i1 %cmp100 to i64
  store i64 %cv101, ptr %slot16, align 8
  %v102 = load i64, ptr %slot16, align 8
  %cond103 = icmp ne i64 %v102, 0
  br i1 %cond103, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v104 = load i64, ptr %slot1, align 8
  %p105 = inttoptr i64 %v104 to ptr
  call void @myl_qbe_fail_frame(ptr %p105) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v106 = load i64, ptr %slot2, align 8
  %v107 = load i64, ptr %slot9, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 %v106, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot3, align 8
  %v110 = load i64, ptr %slot10, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot1, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %call114 = call ptr @myl_qbe_heap(ptr %p113) nomerge, !dbg !112
  %calladdr115 = ptrtoint ptr %call114 to i64
  store i64 %calladdr115, ptr %slot17, align 8
  %v116 = load i64, ptr %slot1, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %call118 = call i64 @myl_qbe_region_mark(ptr %p117) nomerge, !dbg !112
  store i64 %call118, ptr %slot18, align 8
  %v119 = load i64, ptr %slot5, align 8
  %p120 = inttoptr i64 %v119 to ptr
  store i32 0, ptr %p120, align 4, !alias.scope !3, !noalias !4
  %v121 = load i64, ptr %slot6, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i32 0, ptr %p122, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v123 = load i64, ptr %slot9, align 8
  %p124 = inttoptr i64 %v123 to ptr
  %ld125 = load i64, ptr %p124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot19, align 8
  %v126 = load i64, ptr %slot19, align 8
  %v127 = load i64, ptr %slot11, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot10, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot20, align 8
  %v132 = load i64, ptr %slot20, align 8
  %v133 = load i64, ptr %slot12, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot11, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot21, align 8
  %v138 = load i64, ptr %slot12, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot22, align 8
  %v141 = load i64, ptr %slot1, align 8
  %v142 = load i64, ptr %slot21, align 8
  %v143 = load i64, ptr %slot22, align 8
  %call144 = call { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %v141, i64 %v142, i64 %v143) nomerge, !dbg !114
  store { i64, i64 } %call144, ptr %callresult24, align 8
  %addr145 = ptrtoint ptr %callresult24 to i64
  store i64 %addr145, ptr %slot23, align 8
  %v146 = load i64, ptr %slot23, align 8
  %v147 = load i64, ptr %slot11, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot11, align 8
  %p150 = inttoptr i64 %v149 to ptr
  %ld151 = load i64, ptr %p150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld151, ptr %slot25, align 8
  %v152 = load i64, ptr %slot25, align 8
  %op153 = add i64 %v152, 0
  store i64 %op153, ptr %slot26, align 8
  %v154 = load i64, ptr %slot26, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8
  store i64 %ld156, ptr %slot27, align 8
  %v157 = load i64, ptr %slot27, align 8
  %v158 = load i64, ptr %slot11, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot11, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot28, align 8
  %v163 = load i64, ptr %slot11, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot29, align 8
  %v166 = load i64, ptr %slot29, align 8
  %v167 = load i64, ptr %slot7, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot7, align 8
  store i64 %v169, ptr %slot30, align 8
  store i32 0, ptr %slot31, align 8
  %v170 = load i64, ptr %slot5, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %ld172 = load i32, ptr %p171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld172, ptr %slot32, align 8
  %v173 = load i32, ptr %slot32, align 8
  %op174 = and i32 %v173, 24
  store i32 %op174, ptr %slot32, align 8
  %v175 = load i32, ptr %slot32, align 8
  %cmp176 = icmp eq i32 %v175, 0
  %cv177 = zext i1 %cmp176 to i32
  store i32 %cv177, ptr %slot33, align 8
  %v178 = load i32, ptr %slot31, align 8
  %v179 = load i32, ptr %slot33, align 8
  %op180 = and i32 %v178, %v179
  store i32 %op180, ptr %slot34, align 8
  %v181 = load i32, ptr %slot34, align 8
  %cv182 = zext i32 %v181 to i64
  %cond183 = icmp ne i64 %cv182, 0
  br i1 %cond183, label %bb_rctake37, label %bb_rccopy37
bb_rctake37:
  %v184 = load i64, ptr %slot8, align 8
  store i64 %v184, ptr %slot35, align 8
  %v185 = load i64, ptr %slot18, align 8
  store i64 %v185, ptr %slot36, align 8
  %v186 = load i64, ptr %slot30, align 8
  %v187 = load i64, ptr %slot35, align 8
  %op188 = sub i64 %v186, %v187
  store i64 %op188, ptr %slot37, align 8
  %v189 = load i64, ptr %slot35, align 8
  %v190 = load i64, ptr %slot30, align 8
  %op191 = sub i64 %v189, %v190
  store i64 %op191, ptr %slot38, align 8
  %v192 = load i64, ptr %slot37, align 8
  %cmp193 = icmp ult i64 %v192, 8
  %cv194 = zext i1 %cmp193 to i32
  store i32 %cv194, ptr %slot39, align 8
  %v195 = load i64, ptr %slot38, align 8
  %cmp196 = icmp ult i64 %v195, 8
  %cv197 = zext i1 %cmp196 to i32
  store i32 %cv197, ptr %slot40, align 8
  %v198 = load i32, ptr %slot39, align 8
  %v199 = load i32, ptr %slot40, align 8
  %op200 = or i32 %v198, %v199
  store i32 %op200, ptr %slot41, align 8
  %v201 = load i32, ptr %slot41, align 8
  %cv202 = zext i32 %v201 to i64
  %cond203 = icmp ne i64 %cv202, 0
  br i1 %cond203, label %bb_rcmoveslow46, label %bb_rcmovecheck46
bb_rcmovecheck46:
  %v204 = load i64, ptr %slot30, align 8
  %p206 = inttoptr i64 %v204 to ptr
  %gep207 = getelementptr i8, ptr %p206, i64 0
  %op205 = ptrtoint ptr %gep207 to i64
  store i64 %op205, ptr %slot42, align 8
  %v208 = load i64, ptr %slot42, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot43, align 8
  %v211 = load i64, ptr %slot43, align 8
  %cmp212 = icmp ne i64 %v211, 0
  %cv213 = zext i1 %cmp212 to i32
  store i32 %cv213, ptr %slot44, align 8
  %v214 = load i32, ptr %slot44, align 8
  %cv215 = zext i32 %v214 to i64
  %cond216 = icmp ne i64 %cv215, 0
  br i1 %cond216, label %bb_rcmoveheader54, label %bb_rcmovenext54
bb_rcmoveheader54:
  %v217 = load i64, ptr %slot43, align 8
  %op218 = sub i64 %v217, 16
  store i64 %op218, ptr %slot45, align 8
  %v219 = load i64, ptr %slot43, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %rgep221 = getelementptr i8, ptr %p220, i64 -16
  %ld222 = load i64, ptr %rgep221, align 8, !alias.scope !9, !noalias !10
  store i64 %ld222, ptr %slot46, align 8
  %v223 = load i64, ptr %slot46, align 8
  %op224 = and i64 %v223, 5764607523034234881
  store i64 %op224, ptr %slot47, align 8
  %v225 = load i64, ptr %slot47, align 8
  %cmp226 = icmp ne i64 %v225, 0
  %cv227 = zext i1 %cmp226 to i32
  store i32 %cv227, ptr %slot48, align 8
  %v228 = load i32, ptr %slot48, align 8
  %cv229 = zext i32 %v228 to i64
  %cond230 = icmp ne i64 %cv229, 0
  br i1 %cond230, label %bb_rcmoveslow46, label %bb_rcmovenext54
bb_rcmovenext54:
  %v231 = load i64, ptr %slot30, align 8
  %v232 = load i64, ptr %slot35, align 8
  %p233 = inttoptr i64 %v231 to ptr
  %p234 = inttoptr i64 %v232 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p234, ptr %p233, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot30, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 0, ptr %p236, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved46
bb_rcmoveslow46:
  %v237 = load i64, ptr %slot17, align 8
  %v238 = load i64, ptr %slot35, align 8
  %v239 = load i64, ptr %slot30, align 8
  %v240 = load i64, ptr %slot36, align 8
  %cv241 = trunc i64 %v240 to i32
  %call242 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v237, i64 %v238, i64 %v239, i32 %cv241) nomerge, !dbg !116
  store i32 %call242, ptr %slot49, align 8
  %v243 = load i32, ptr %slot49, align 8
  %cv244 = zext i32 %v243 to i64
  %cond245 = icmp ne i64 %cv244, 0
  br i1 %cond245, label %bb_rcsuccess61, label %bb_rcfailure61
bb_rcfailure61:
  %v246 = load i64, ptr %slot17, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %call248 = call i32 @myl_rc_take_failure(ptr %p247) nomerge, !dbg !116
  store i32 %call248, ptr %slot50, align 8
  %v249 = load i64, ptr %slot1, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %v251 = load i32, ptr %slot50, align 8
  %call252 = call i32 @myl_qbe_rc_status(ptr %p250, i32 %v251) nomerge, !dbg !116
  store i32 %call252, ptr %slot51, align 8
  br label %bb_failure
bb_rcsuccess61:
  br label %bb_rcmoved46
bb_rcmoved46:
  %v253 = load i64, ptr %slot6, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 1, ptr %p254, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared37
bb_rccopy37:
  %v255 = load i64, ptr %slot8, align 8
  store i64 %v255, ptr %slot52, align 8
  %v256 = load i64, ptr %slot18, align 8
  store i64 %v256, ptr %slot53, align 8
  %v257 = load i64, ptr %slot30, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot54, align 8
  %v260 = load i64, ptr %slot54, align 8
  %cmp261 = icmp ne i64 %v260, 0
  %cv262 = zext i1 %cmp261 to i32
  store i32 %cv262, ptr %slot55, align 8
  %v263 = load i32, ptr %slot55, align 8
  %cv264 = zext i32 %v263 to i64
  %cond265 = icmp ne i64 %cv264, 0
  br i1 %cond265, label %bb_rcgnn70, label %bb_rcgplain70
bb_rcgnn70:
  %v266 = load i64, ptr %slot54, align 8
  %op267 = sub i64 %v266, 16
  store i64 %op267, ptr %slot56, align 8
  %v268 = load i64, ptr %slot54, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %rgep270 = getelementptr i8, ptr %p269, i64 -16
  %ld271 = load i64, ptr %rgep270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld271, ptr %slot57, align 8
  %v272 = load i64, ptr %slot57, align 8
  %op273 = and i64 %v272, 4611686018427387906
  store i64 %op273, ptr %slot58, align 8
  %v274 = load i64, ptr %slot58, align 8
  %cmp275 = icmp ne i64 %v274, 0
  %cv276 = zext i1 %cmp275 to i32
  store i32 %cv276, ptr %slot59, align 8
  %v277 = load i32, ptr %slot59, align 8
  %cv278 = zext i32 %v277 to i64
  %cond279 = icmp ne i64 %cv278, 0
  br i1 %cond279, label %bb_rcgspecial70, label %bb_rcginc70
bb_rcginc70:
  %v280 = load i64, ptr %slot54, align 8
  %op281 = sub i64 %v280, 32
  store i64 %op281, ptr %slot60, align 8
  %v282 = load i64, ptr %slot54, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %rgep284 = getelementptr i8, ptr %p283, i64 -32
  %ld285 = load i64, ptr %rgep284, align 8, !alias.scope !9, !noalias !10
  store i64 %ld285, ptr %slot61, align 8
  %v286 = load i64, ptr %slot61, align 8
  %op287 = add i64 %v286, 1
  store i64 %op287, ptr %slot62, align 8
  %v288 = load i64, ptr %slot62, align 8
  %cmp289 = icmp eq i64 %v288, 0
  %cv290 = zext i1 %cmp289 to i32
  store i32 %cv290, ptr %slot63, align 8
  %v291 = load i32, ptr %slot63, align 8
  %cv292 = zext i32 %v291 to i64
  %cond293 = icmp ne i64 %cv292, 0
  br i1 %cond293, label %bb_rcglimit70, label %bb_rcgcapacity70
bb_rcglimit70:
  %v294 = load i64, ptr %slot1, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %call296 = call i32 @myl_qbe_rc_status(ptr %p295, i32 2) nomerge, !dbg !116
  store i32 %call296, ptr %slot64, align 8
  br label %bb_failure
bb_rcgcapacity70:
  %v297 = load i64, ptr %slot62, align 8
  %v298 = load i64, ptr %slot54, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %rgep300 = getelementptr i8, ptr %p299, i64 -32
  store i64 %v297, ptr %rgep300, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain70
bb_rcgspecial70:
  %v301 = load i64, ptr %slot57, align 8
  %op302 = and i64 %v301, 4611686018427387904
  store i64 %op302, ptr %slot65, align 8
  %v303 = load i64, ptr %slot65, align 8
  %cmp304 = icmp ne i64 %v303, 0
  %cv305 = zext i1 %cmp304 to i32
  store i32 %cv305, ptr %slot66, align 8
  %v306 = load i32, ptr %slot66, align 8
  %cv307 = zext i32 %v306 to i64
  %cond308 = icmp ne i64 %cv307, 0
  br i1 %cond308, label %bb_rcgslow70, label %bb_rcgplain70
bb_rcgslow70:
  %v309 = load i64, ptr %slot17, align 8
  %v310 = load i64, ptr %slot52, align 8
  %v311 = load i64, ptr %slot30, align 8
  %v312 = load i64, ptr %slot53, align 8
  %cv313 = trunc i64 %v312 to i32
  %call314 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v309, i64 %v310, i64 %v311, i32 %cv313) nomerge, !dbg !116
  store i32 %call314, ptr %slot67, align 8
  %v315 = load i32, ptr %slot67, align 8
  %cv316 = zext i32 %v315 to i64
  %cond317 = icmp ne i64 %cv316, 0
  br i1 %cond317, label %bb_rcsuccess84, label %bb_rcfailure84
bb_rcfailure84:
  %v318 = load i64, ptr %slot17, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %call320 = call i32 @myl_rc_take_failure(ptr %p319) nomerge, !dbg !116
  store i32 %call320, ptr %slot68, align 8
  %v321 = load i64, ptr %slot1, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %v323 = load i32, ptr %slot68, align 8
  %call324 = call i32 @myl_qbe_rc_status(ptr %p322, i32 %v323) nomerge, !dbg !116
  store i32 %call324, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess84:
  br label %bb_rcgdone70
bb_rcgplain70:
  %v325 = load i64, ptr %slot54, align 8
  %v326 = load i64, ptr %slot52, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone70
bb_rcgdone70:
  %v328 = load i64, ptr %slot6, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i32 1, ptr %p329, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared37
bb_rcprepared37:
  %v330 = load i64, ptr %slot8, align 8
  store i64 %v330, ptr %slot70, align 8
  %v331 = load i64, ptr %slot70, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot71, align 8
  %v334 = load i64, ptr %slot6, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i32 0, ptr %p335, align 4, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot71, align 8
  ret i64 %v336
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b", linkageName: "myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3503340683336129616, i64 0, !"myl_f_862bbbd0ed33d0a909d5ae7ef8e0856872614dbae70486b3e175ed95b756503b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
