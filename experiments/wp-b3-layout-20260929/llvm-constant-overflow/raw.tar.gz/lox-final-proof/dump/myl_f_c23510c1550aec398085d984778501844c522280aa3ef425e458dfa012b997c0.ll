target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %callresult193 = alloca [16 x i8], align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %callresult225 = alloca [16 x i8], align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %callresult257 = alloca [16 x i8], align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %callresult289 = alloca [16 x i8], align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %callresult321 = alloca [16 x i8], align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %callresult353 = alloca [16 x i8], align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %callresult385 = alloca [16 x i8], align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %callresult417 = alloca [16 x i8], align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %callresult449 = alloca [16 x i8], align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %callresult481 = alloca [16 x i8], align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v509 = load i64, ptr %slot1, align 8
  %op510 = add i64 %v509, 32
  store i64 %op510, ptr %slot4, align 8
  %mem511 = alloca i8, i64 16, align 8
  %ptr512 = ptrtoint ptr %mem511 to i64
  store i64 %ptr512, ptr %slot5, align 8
  %mem513 = alloca i8, i64 8, align 8
  %ptr514 = ptrtoint ptr %mem513 to i64
  store i64 %ptr514, ptr %slot6, align 8
  %mem515 = alloca i8, i64 8, align 8
  %ptr516 = ptrtoint ptr %mem515 to i64
  store i64 %ptr516, ptr %slot7, align 8
  %mem517 = alloca i8, i64 8, align 8
  %ptr518 = ptrtoint ptr %mem517 to i64
  store i64 %ptr518, ptr %slot8, align 8
  %mem519 = alloca i8, i64 8, align 8
  %ptr520 = ptrtoint ptr %mem519 to i64
  store i64 %ptr520, ptr %slot9, align 8
  %mem521 = alloca i8, i64 208, align 8
  %ptr522 = ptrtoint ptr %mem521 to i64
  store i64 %ptr522, ptr %slot10, align 8
  %mem523 = alloca i8, i64 208, align 8
  %ptr524 = ptrtoint ptr %mem523 to i64
  store i64 %ptr524, ptr %slot11, align 8
  %mem525 = alloca i8, i64 8, align 8
  %ptr526 = ptrtoint ptr %mem525 to i64
  store i64 %ptr526, ptr %slot12, align 8
  %mem527 = alloca i8, i64 8, align 8
  %ptr528 = ptrtoint ptr %mem527 to i64
  store i64 %ptr528, ptr %slot13, align 8
  %mem529 = alloca i8, i64 8, align 8
  %ptr530 = ptrtoint ptr %mem529 to i64
  store i64 %ptr530, ptr %slot14, align 8
  %mem531 = alloca i8, i64 8, align 8
  %ptr532 = ptrtoint ptr %mem531 to i64
  store i64 %ptr532, ptr %slot15, align 8
  %mem533 = alloca i8, i64 16, align 8
  %ptr534 = ptrtoint ptr %mem533 to i64
  store i64 %ptr534, ptr %slot16, align 8
  %mem535 = alloca i8, i64 8, align 8
  %ptr536 = ptrtoint ptr %mem535 to i64
  store i64 %ptr536, ptr %slot17, align 8
  %mem537 = alloca i8, i64 8, align 8
  %ptr538 = ptrtoint ptr %mem537 to i64
  store i64 %ptr538, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem539 = alloca i8, i64 8, align 8
  %ptr540 = ptrtoint ptr %mem539 to i64
  store i64 %ptr540, ptr %slot19, align 8
  %v541 = load i64, ptr %slot1, align 8
  %op542 = add i64 %v541, 64
  store i64 %op542, ptr %slot20, align 8
  %v543 = load i64, ptr %slot20, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i64, ptr %p544, align 8, !alias.scope !4, !noalias !3
  store i64 %ld545, ptr %slot21, align 8
  %stack546 = call ptr @llvm.stacksave()
  %stackaddr547 = ptrtoint ptr %stack546 to i64
  %v548 = load i64, ptr %slot21, align 8
  %cmp549 = icmp ult i64 %stackaddr547, %v548
  %cv550 = zext i1 %cmp549 to i64
  store i64 %cv550, ptr %slot22, align 8
  %v551 = load i64, ptr %slot22, align 8
  %cond552 = icmp ne i64 %v551, 0
  br i1 %cond552, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v553 = load i64, ptr %slot1, align 8
  %p554 = inttoptr i64 %v553 to ptr
  call void @myl_qbe_fail_frame(ptr %p554) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v555 = load i64, ptr %slot14, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 0, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot2, align 8
  %v558 = load i64, ptr %slot12, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot3, align 8
  %v561 = load i64, ptr %slot13, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 %v560, ptr %p562, align 8, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot1, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %call565 = call ptr @myl_qbe_heap(ptr %p564) nomerge, !dbg !112
  %calladdr566 = ptrtoint ptr %call565 to i64
  store i64 %calladdr566, ptr %slot23, align 8
  %v567 = load i64, ptr %slot1, align 8
  %p568 = inttoptr i64 %v567 to ptr
  %call569 = call i64 @myl_qbe_region_mark(ptr %p568) nomerge, !dbg !112
  store i64 %call569, ptr %slot24, align 8
  %v570 = load i64, ptr %slot6, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i32 0, ptr %p571, align 4, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot7, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 0, ptr %p573, align 4, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot8, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i32 0, ptr %p575, align 4, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot9, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i32 0, ptr %p577, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v578 = load i64, ptr %slot12, align 8
  %p579 = inttoptr i64 %v578 to ptr
  %ld580 = load i64, ptr %p579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld580, ptr %slot25, align 8
  %v581 = load i64, ptr %slot25, align 8
  %v582 = load i64, ptr %slot17, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i64 %v581, ptr %p583, align 8, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot17, align 8
  %p585 = inttoptr i64 %v584 to ptr
  %ld586 = load i64, ptr %p585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld586, ptr %slot26, align 8
  %v587 = load i64, ptr %slot26, align 8
  %op588 = add i64 %v587, 0
  store i64 %op588, ptr %slot27, align 8
  %v589 = load i64, ptr %slot27, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i64, ptr %p590, align 8, !alias.scope !4, !noalias !3
  store i64 %ld591, ptr %slot28, align 8
  %v592 = load i64, ptr %slot28, align 8
  %v593 = load i64, ptr %slot17, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 %v592, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot6, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i32, ptr %p596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld597, ptr %slot29, align 8
  %v598 = load i32, ptr %slot29, align 8
  %cv599 = zext i32 %v598 to i64
  %cond600 = icmp ne i64 %cv599, 0
  br i1 %cond600, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v601 = load i64, ptr %slot6, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i32 0, ptr %p602, align 4, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot10, align 8
  store i64 %v603, ptr %slot30, align 8
  %v604 = load i64, ptr %slot7, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %ld606 = load i32, ptr %p605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld606, ptr %slot31, align 8
  %v607 = load i32, ptr %slot31, align 8
  %op608 = and i32 %v607, 28
  store i32 %op608, ptr %slot32, align 8
  %v609 = load i32, ptr %slot32, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v612 = load i64, ptr %slot23, align 8
  store i64 %v612, ptr %slot33, align 8
  %v613 = load i64, ptr %slot33, align 8
  %v614 = load i64, ptr %slot30, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v613, i64 %v614) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v615 = load i64, ptr %slot23, align 8
  store i64 %v615, ptr %slot34, align 8
  %v616 = load i64, ptr %slot34, align 8
  %v617 = load i64, ptr %slot30, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v616, i64 %v617) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v618 = load i64, ptr %slot17, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %ld620 = load i64, ptr %p619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld620, ptr %slot35, align 8
  %v621 = load i64, ptr %slot35, align 8
  %v622 = load i64, ptr %slot14, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i64 %v621, ptr %p623, align 8, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot13, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %ld626 = load i64, ptr %p625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld626, ptr %slot36, align 8
  %v627 = load i64, ptr %slot36, align 8
  %v628 = load i64, ptr %slot17, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot17, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot37, align 8
  %v633 = load i64, ptr %slot37, align 8
  %v634 = load i64, ptr %slot15, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i64 %v633, ptr %p635, align 8, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot15, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %ld638 = load i64, ptr %p637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld638, ptr %slot38, align 8
  %v639 = load i64, ptr %slot38, align 8
  %v640 = load i64, ptr %slot17, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i64 %v639, ptr %p641, align 8, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot18, align 8
  %p643 = inttoptr i64 %v642 to ptr
  store i64 0, ptr %p643, align 8, !alias.scope !3, !noalias !4
  %v644 = load i64, ptr %slot18, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %ld646 = load i64, ptr %p645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld646, ptr %slot39, align 8
  %v647 = load i64, ptr %slot17, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %ld649 = load i64, ptr %p648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld649, ptr %slot40, align 8
  %v650 = load i64, ptr %slot40, align 8
  %v651 = load i64, ptr %slot39, align 8
  %cmp652 = icmp slt i64 %v650, %v651
  %cv653 = zext i1 %cmp652 to i64
  store i64 %cv653, ptr %slot41, align 8
  %v654 = load i64, ptr %slot41, align 8
  %v655 = load i64, ptr %slot17, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i64 %v654, ptr %p656, align 8, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot17, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot42, align 8
  %v660 = load i64, ptr %slot42, align 8
  %cond661 = icmp ne i64 %v660, 0
  br i1 %cond661, label %bb_next31, label %bb_i14
bb_next31:
  %v662 = load i64, ptr %slot14, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %ld664 = load i64, ptr %p663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld664, ptr %slot43, align 8
  %v665 = load i64, ptr %slot43, align 8
  %op666 = add i64 %v665, 0
  store i64 %op666, ptr %slot44, align 8
  %v667 = load i64, ptr %slot44, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !6, !noalias !7
  store i64 %ld669, ptr %slot45, align 8
  %v670 = load i64, ptr %slot45, align 8
  %v671 = load i64, ptr %slot17, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i64 %v670, ptr %p672, align 8, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot17, align 8
  %p674 = inttoptr i64 %v673 to ptr
  %ld675 = load i64, ptr %p674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld675, ptr %slot46, align 8
  %v676 = load i64, ptr %slot46, align 8
  %cmp677 = icmp ugt i64 %v676, 9223372036854775807
  %cv678 = zext i1 %cmp677 to i64
  store i64 %cv678, ptr %slot47, align 8
  %v679 = load i64, ptr %slot47, align 8
  %cond680 = icmp ne i64 %v679, 0
  br i1 %cond680, label %bb_cast_overflow36, label %bb_cast_ok36
bb_cast_overflow36:
  %v681 = load i64, ptr %slot1, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %v683 = load i64, ptr %slot46, align 8
  call void @myl_qbe_fail_cast(ptr %p682, i64 %v683, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok36:
  %v684 = load i64, ptr %slot46, align 8
  %v685 = load i64, ptr %slot17, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot15, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i64, ptr %p688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld689, ptr %slot48, align 8
  %v690 = load i64, ptr %slot48, align 8
  %v691 = load i64, ptr %slot18, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot18, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %ld695 = load i64, ptr %p694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld695, ptr %slot49, align 8
  %v696 = load i64, ptr %slot17, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %ld698 = load i64, ptr %p697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld698, ptr %slot50, align 8
  %v699 = load i64, ptr %slot50, align 8
  %v700 = load i64, ptr %slot49, align 8
  %ovpair702 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v699, i64 %v700)
  %op701 = extractvalue { i64, i1 } %ovpair702, 0
  %ov703 = extractvalue { i64, i1 } %ovpair702, 1
  store i64 %op701, ptr %slot51, align 8
  %v704 = load i64, ptr %slot50, align 8
  %v705 = load i64, ptr %slot51, align 8
  %op706 = xor i64 %v704, %v705
  store i64 %op706, ptr %slot52, align 8
  %v707 = load i64, ptr %slot49, align 8
  %v708 = load i64, ptr %slot51, align 8
  %op709 = xor i64 %v707, %v708
  store i64 %op709, ptr %slot53, align 8
  %v710 = load i64, ptr %slot52, align 8
  %v711 = load i64, ptr %slot53, align 8
  %op712 = and i64 %v710, %v711
  store i64 %op712, ptr %slot54, align 8
  %cv713 = zext i1 %ov703 to i64
  store i64 %cv713, ptr %slot55, align 8
  %v714 = load i64, ptr %slot55, align 8
  %cond715 = icmp ne i64 %v714, 0
  br i1 %cond715, label %bb_overflow40, label %bb_checked40
bb_overflow40:
  %v716 = load i64, ptr %slot1, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %v718 = load i64, ptr %slot50, align 8
  %v719 = load i64, ptr %slot49, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p717, i64 0, i64 %v718, i64 %v719, i64 64) nomerge, !dbg !118
  unreachable
bb_checked40:
  %v720 = load i64, ptr %slot51, align 8
  %v721 = load i64, ptr %slot17, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i64 %v720, ptr %p722, align 8, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot17, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %ld725 = load i64, ptr %p724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld725, ptr %slot56, align 8
  %v726 = load i64, ptr %slot56, align 8
  %v727 = load i64, ptr %slot15, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 %v726, ptr %p728, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v729 = load i64, ptr %slot15, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i64, ptr %p730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld731, ptr %slot57, align 8
  %v732 = load i64, ptr %slot57, align 8
  %v733 = load i64, ptr %slot17, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot14, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot58, align 8
  %v738 = load i64, ptr %slot17, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot59, align 8
  %v741 = load i64, ptr %slot58, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !6, !noalias !7
  store i64 %ld743, ptr %slot60, align 8
  %v744 = load i64, ptr %slot59, align 8
  %v745 = load i64, ptr %slot60, align 8
  %cmp746 = icmp ult i64 %v744, %v745
  %cv747 = zext i1 %cmp746 to i64
  store i64 %cv747, ptr %slot61, align 8
  %v748 = load i64, ptr %slot61, align 8
  %cond749 = icmp ne i64 %v748, 0
  br i1 %cond749, label %bb_success52, label %bb_failed52
bb_failed52:
  %v750 = load i64, ptr %slot1, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %v752 = load i64, ptr %slot59, align 8
  %v753 = load i64, ptr %slot60, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p751, i64 %v752, i64 %v753) nomerge, !dbg !120
  unreachable
bb_success52:
  %v754 = load i64, ptr %slot58, align 8
  %op755 = add i64 %v754, 32
  store i64 %op755, ptr %slot62, align 8
  %v756 = load i64, ptr %slot62, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %ld758 = load i64, ptr %p757, align 8, !alias.scope !6, !noalias !7
  store i64 %ld758, ptr %slot63, align 8
  %v759 = load i64, ptr %slot59, align 8
  %op760 = mul i64 %v759, 56
  store i64 %op760, ptr %slot64, align 8
  %v761 = load i64, ptr %slot63, align 8
  %v762 = load i64, ptr %slot64, align 8
  %op763 = add i64 %v761, %v762
  store i64 %op763, ptr %slot65, align 8
  %v764 = load i64, ptr %slot65, align 8
  %v765 = load i64, ptr %slot17, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i64 %v764, ptr %p766, align 8, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot17, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i64, ptr %p768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld769, ptr %slot66, align 8
  %v770 = load i64, ptr %slot66, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %ld772 = load i32, ptr %p771, align 4, !alias.scope !12, !noalias !13
  %ext773 = zext i32 %ld772 to i64
  store i64 %ext773, ptr %slot67, align 8
  %v774 = load i64, ptr %slot67, align 8
  %cmp775 = icmp eq i64 %v774, 0
  %cv776 = zext i1 %cmp775 to i64
  store i64 %cv776, ptr %slot68, align 8
  %v777 = load i64, ptr %slot68, align 8
  %cond778 = icmp ne i64 %v777, 0
  br i1 %cond778, label %bb_rcarm59, label %bb_rcarmnext59
bb_rcarm59:
  %v779 = load i64, ptr %slot6, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %ld781 = load i32, ptr %p780, align 4, !alias.scope !3, !noalias !4
  store i32 %ld781, ptr %slot69, align 8
  %v782 = load i32, ptr %slot69, align 8
  %cv783 = zext i32 %v782 to i64
  %cond784 = icmp ne i64 %cv783, 0
  br i1 %cond784, label %bb_rcslotdrop62, label %bb_rcslotdone62
bb_rcslotdrop62:
  %v785 = load i64, ptr %slot6, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i32 0, ptr %p786, align 4, !alias.scope !3, !noalias !4
  %v787 = load i64, ptr %slot10, align 8
  store i64 %v787, ptr %slot70, align 8
  %v788 = load i64, ptr %slot7, align 8
  %p789 = inttoptr i64 %v788 to ptr
  %ld790 = load i32, ptr %p789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld790, ptr %slot71, align 8
  %v791 = load i32, ptr %slot71, align 8
  %op792 = and i32 %v791, 28
  store i32 %op792, ptr %slot72, align 8
  %v793 = load i32, ptr %slot72, align 8
  %cv794 = zext i32 %v793 to i64
  %cond795 = icmp ne i64 %cv794, 0
  br i1 %cond795, label %bb_rcslotrole62, label %bb_rcslotowner62
bb_rcslotrole62:
  %v796 = load i64, ptr %slot23, align 8
  store i64 %v796, ptr %slot73, align 8
  %v797 = load i64, ptr %slot73, align 8
  %v798 = load i64, ptr %slot70, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v797, i64 %v798) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotowner62:
  %v799 = load i64, ptr %slot23, align 8
  store i64 %v799, ptr %slot74, align 8
  %v800 = load i64, ptr %slot74, align 8
  %v801 = load i64, ptr %slot70, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v800, i64 %v801) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotdone62:
  br label %bb_i23
bb_rcarmnext59:
  %v802 = load i64, ptr %slot67, align 8
  %cmp803 = icmp eq i64 %v802, 1
  %cv804 = zext i1 %cmp803 to i64
  store i64 %cv804, ptr %slot75, align 8
  %v805 = load i64, ptr %slot75, align 8
  %cond806 = icmp ne i64 %v805, 0
  br i1 %cond806, label %bb_rcarm69, label %bb_rcarmnext69
bb_rcarm69:
  %v807 = load i64, ptr %slot6, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %ld809 = load i32, ptr %p808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld809, ptr %slot76, align 8
  %v810 = load i32, ptr %slot76, align 8
  %cv811 = zext i32 %v810 to i64
  %cond812 = icmp ne i64 %cv811, 0
  br i1 %cond812, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v813 = load i64, ptr %slot6, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i32 0, ptr %p814, align 4, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot10, align 8
  store i64 %v815, ptr %slot77, align 8
  %v816 = load i64, ptr %slot7, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i32, ptr %p817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld818, ptr %slot78, align 8
  %v819 = load i32, ptr %slot78, align 8
  %op820 = and i32 %v819, 28
  store i32 %op820, ptr %slot79, align 8
  %v821 = load i32, ptr %slot79, align 8
  %cv822 = zext i32 %v821 to i64
  %cond823 = icmp ne i64 %cv822, 0
  br i1 %cond823, label %bb_rcslotrole72, label %bb_rcslotowner72
bb_rcslotrole72:
  %v824 = load i64, ptr %slot23, align 8
  store i64 %v824, ptr %slot80, align 8
  %v825 = load i64, ptr %slot80, align 8
  %v826 = load i64, ptr %slot77, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v825, i64 %v826) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotowner72:
  %v827 = load i64, ptr %slot23, align 8
  store i64 %v827, ptr %slot81, align 8
  %v828 = load i64, ptr %slot81, align 8
  %v829 = load i64, ptr %slot77, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v828, i64 %v829) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotdone72:
  br label %bb_i29
bb_rcarmnext69:
  %v830 = load i64, ptr %slot67, align 8
  %cmp831 = icmp eq i64 %v830, 2
  %cv832 = zext i1 %cmp831 to i64
  store i64 %cv832, ptr %slot82, align 8
  %v833 = load i64, ptr %slot82, align 8
  %cond834 = icmp ne i64 %v833, 0
  br i1 %cond834, label %bb_rcarm79, label %bb_rcarmnext79
bb_rcarm79:
  %v835 = load i64, ptr %slot6, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i32, ptr %p836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld837, ptr %slot83, align 8
  %v838 = load i32, ptr %slot83, align 8
  %cv839 = zext i32 %v838 to i64
  %cond840 = icmp ne i64 %cv839, 0
  br i1 %cond840, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v841 = load i64, ptr %slot6, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i32 0, ptr %p842, align 4, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot10, align 8
  store i64 %v843, ptr %slot84, align 8
  %v844 = load i64, ptr %slot7, align 8
  %p845 = inttoptr i64 %v844 to ptr
  %ld846 = load i32, ptr %p845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld846, ptr %slot85, align 8
  %v847 = load i32, ptr %slot85, align 8
  %op848 = and i32 %v847, 28
  store i32 %op848, ptr %slot86, align 8
  %v849 = load i32, ptr %slot86, align 8
  %cv850 = zext i32 %v849 to i64
  %cond851 = icmp ne i64 %cv850, 0
  br i1 %cond851, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v852 = load i64, ptr %slot23, align 8
  store i64 %v852, ptr %slot87, align 8
  %v853 = load i64, ptr %slot87, align 8
  %v854 = load i64, ptr %slot84, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v853, i64 %v854) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v855 = load i64, ptr %slot23, align 8
  store i64 %v855, ptr %slot88, align 8
  %v856 = load i64, ptr %slot88, align 8
  %v857 = load i64, ptr %slot84, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v856, i64 %v857) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotdone82:
  br label %bb_i35
bb_rcarmnext79:
  %v858 = load i64, ptr %slot67, align 8
  %cmp859 = icmp eq i64 %v858, 3
  %cv860 = zext i1 %cmp859 to i64
  store i64 %cv860, ptr %slot89, align 8
  %v861 = load i64, ptr %slot89, align 8
  %cond862 = icmp ne i64 %v861, 0
  br i1 %cond862, label %bb_rcarm89, label %bb_rcarmnext89
bb_rcarm89:
  %v863 = load i64, ptr %slot6, align 8
  %p864 = inttoptr i64 %v863 to ptr
  %ld865 = load i32, ptr %p864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld865, ptr %slot90, align 8
  %v866 = load i32, ptr %slot90, align 8
  %cv867 = zext i32 %v866 to i64
  %cond868 = icmp ne i64 %cv867, 0
  br i1 %cond868, label %bb_rcslotdrop92, label %bb_rcslotdone92
bb_rcslotdrop92:
  %v869 = load i64, ptr %slot6, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i32 0, ptr %p870, align 4, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot10, align 8
  store i64 %v871, ptr %slot91, align 8
  %v872 = load i64, ptr %slot7, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %ld874 = load i32, ptr %p873, align 4, !alias.scope !3, !noalias !4
  store i32 %ld874, ptr %slot92, align 8
  %v875 = load i32, ptr %slot92, align 8
  %op876 = and i32 %v875, 28
  store i32 %op876, ptr %slot93, align 8
  %v877 = load i32, ptr %slot93, align 8
  %cv878 = zext i32 %v877 to i64
  %cond879 = icmp ne i64 %cv878, 0
  br i1 %cond879, label %bb_rcslotrole92, label %bb_rcslotowner92
bb_rcslotrole92:
  %v880 = load i64, ptr %slot23, align 8
  store i64 %v880, ptr %slot94, align 8
  %v881 = load i64, ptr %slot94, align 8
  %v882 = load i64, ptr %slot91, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v881, i64 %v882) nomerge, !dbg !122
  br label %bb_rcslotdone92
bb_rcslotowner92:
  %v883 = load i64, ptr %slot23, align 8
  store i64 %v883, ptr %slot95, align 8
  %v884 = load i64, ptr %slot95, align 8
  %v885 = load i64, ptr %slot91, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v884, i64 %v885) nomerge, !dbg !122
  br label %bb_rcslotdone92
bb_rcslotdone92:
  br label %bb_i41
bb_rcarmnext89:
  %v886 = load i64, ptr %slot67, align 8
  %cmp887 = icmp eq i64 %v886, 4
  %cv888 = zext i1 %cmp887 to i64
  store i64 %cv888, ptr %slot96, align 8
  %v889 = load i64, ptr %slot96, align 8
  %cond890 = icmp ne i64 %v889, 0
  br i1 %cond890, label %bb_rcarm99, label %bb_rcarmnext99
bb_rcarm99:
  %v891 = load i64, ptr %slot6, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %ld893 = load i32, ptr %p892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld893, ptr %slot97, align 8
  %v894 = load i32, ptr %slot97, align 8
  %cv895 = zext i32 %v894 to i64
  %cond896 = icmp ne i64 %cv895, 0
  br i1 %cond896, label %bb_rcslotdrop102, label %bb_rcslotdone102
bb_rcslotdrop102:
  %v897 = load i64, ptr %slot6, align 8
  %p898 = inttoptr i64 %v897 to ptr
  store i32 0, ptr %p898, align 4, !alias.scope !3, !noalias !4
  %v899 = load i64, ptr %slot10, align 8
  store i64 %v899, ptr %slot98, align 8
  %v900 = load i64, ptr %slot7, align 8
  %p901 = inttoptr i64 %v900 to ptr
  %ld902 = load i32, ptr %p901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld902, ptr %slot99, align 8
  %v903 = load i32, ptr %slot99, align 8
  %op904 = and i32 %v903, 28
  store i32 %op904, ptr %slot100, align 8
  %v905 = load i32, ptr %slot100, align 8
  %cv906 = zext i32 %v905 to i64
  %cond907 = icmp ne i64 %cv906, 0
  br i1 %cond907, label %bb_rcslotrole102, label %bb_rcslotowner102
bb_rcslotrole102:
  %v908 = load i64, ptr %slot23, align 8
  store i64 %v908, ptr %slot101, align 8
  %v909 = load i64, ptr %slot101, align 8
  %v910 = load i64, ptr %slot98, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v909, i64 %v910) nomerge, !dbg !122
  br label %bb_rcslotdone102
bb_rcslotowner102:
  %v911 = load i64, ptr %slot23, align 8
  store i64 %v911, ptr %slot102, align 8
  %v912 = load i64, ptr %slot102, align 8
  %v913 = load i64, ptr %slot98, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v912, i64 %v913) nomerge, !dbg !122
  br label %bb_rcslotdone102
bb_rcslotdone102:
  br label %bb_i47
bb_rcarmnext99:
  %v914 = load i64, ptr %slot67, align 8
  %cmp915 = icmp eq i64 %v914, 5
  %cv916 = zext i1 %cmp915 to i64
  store i64 %cv916, ptr %slot103, align 8
  %v917 = load i64, ptr %slot103, align 8
  %cond918 = icmp ne i64 %v917, 0
  br i1 %cond918, label %bb_rcarm109, label %bb_rcarmnext109
bb_rcarm109:
  %v919 = load i64, ptr %slot6, align 8
  %p920 = inttoptr i64 %v919 to ptr
  %ld921 = load i32, ptr %p920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld921, ptr %slot104, align 8
  %v922 = load i32, ptr %slot104, align 8
  %cv923 = zext i32 %v922 to i64
  %cond924 = icmp ne i64 %cv923, 0
  br i1 %cond924, label %bb_rcslotdrop112, label %bb_rcslotdone112
bb_rcslotdrop112:
  %v925 = load i64, ptr %slot6, align 8
  %p926 = inttoptr i64 %v925 to ptr
  store i32 0, ptr %p926, align 4, !alias.scope !3, !noalias !4
  %v927 = load i64, ptr %slot10, align 8
  store i64 %v927, ptr %slot105, align 8
  %v928 = load i64, ptr %slot7, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %ld930 = load i32, ptr %p929, align 4, !alias.scope !3, !noalias !4
  store i32 %ld930, ptr %slot106, align 8
  %v931 = load i32, ptr %slot106, align 8
  %op932 = and i32 %v931, 28
  store i32 %op932, ptr %slot107, align 8
  %v933 = load i32, ptr %slot107, align 8
  %cv934 = zext i32 %v933 to i64
  %cond935 = icmp ne i64 %cv934, 0
  br i1 %cond935, label %bb_rcslotrole112, label %bb_rcslotowner112
bb_rcslotrole112:
  %v936 = load i64, ptr %slot23, align 8
  store i64 %v936, ptr %slot108, align 8
  %v937 = load i64, ptr %slot108, align 8
  %v938 = load i64, ptr %slot105, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v937, i64 %v938) nomerge, !dbg !122
  br label %bb_rcslotdone112
bb_rcslotowner112:
  %v939 = load i64, ptr %slot23, align 8
  store i64 %v939, ptr %slot109, align 8
  %v940 = load i64, ptr %slot109, align 8
  %v941 = load i64, ptr %slot105, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v940, i64 %v941) nomerge, !dbg !122
  br label %bb_rcslotdone112
bb_rcslotdone112:
  br label %bb_i53
bb_rcarmnext109:
  %v942 = load i64, ptr %slot67, align 8
  %cmp943 = icmp eq i64 %v942, 6
  %cv944 = zext i1 %cmp943 to i64
  store i64 %cv944, ptr %slot110, align 8
  %v945 = load i64, ptr %slot110, align 8
  %cond946 = icmp ne i64 %v945, 0
  br i1 %cond946, label %bb_rcarm119, label %bb_rcarmnext119
bb_rcarm119:
  %v947 = load i64, ptr %slot6, align 8
  %p948 = inttoptr i64 %v947 to ptr
  %ld949 = load i32, ptr %p948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld949, ptr %slot111, align 8
  %v950 = load i32, ptr %slot111, align 8
  %cv951 = zext i32 %v950 to i64
  %cond952 = icmp ne i64 %cv951, 0
  br i1 %cond952, label %bb_rcslotdrop122, label %bb_rcslotdone122
bb_rcslotdrop122:
  %v953 = load i64, ptr %slot6, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i32 0, ptr %p954, align 4, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot10, align 8
  store i64 %v955, ptr %slot112, align 8
  %v956 = load i64, ptr %slot7, align 8
  %p957 = inttoptr i64 %v956 to ptr
  %ld958 = load i32, ptr %p957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld958, ptr %slot113, align 8
  %v959 = load i32, ptr %slot113, align 8
  %op960 = and i32 %v959, 28
  store i32 %op960, ptr %slot114, align 8
  %v961 = load i32, ptr %slot114, align 8
  %cv962 = zext i32 %v961 to i64
  %cond963 = icmp ne i64 %cv962, 0
  br i1 %cond963, label %bb_rcslotrole122, label %bb_rcslotowner122
bb_rcslotrole122:
  %v964 = load i64, ptr %slot23, align 8
  store i64 %v964, ptr %slot115, align 8
  %v965 = load i64, ptr %slot115, align 8
  %v966 = load i64, ptr %slot112, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v965, i64 %v966) nomerge, !dbg !122
  br label %bb_rcslotdone122
bb_rcslotowner122:
  %v967 = load i64, ptr %slot23, align 8
  store i64 %v967, ptr %slot116, align 8
  %v968 = load i64, ptr %slot116, align 8
  %v969 = load i64, ptr %slot112, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v968, i64 %v969) nomerge, !dbg !122
  br label %bb_rcslotdone122
bb_rcslotdone122:
  br label %bb_i59
bb_rcarmnext119:
  %v970 = load i64, ptr %slot67, align 8
  %cmp971 = icmp eq i64 %v970, 7
  %cv972 = zext i1 %cmp971 to i64
  store i64 %cv972, ptr %slot117, align 8
  %v973 = load i64, ptr %slot117, align 8
  %cond974 = icmp ne i64 %v973, 0
  br i1 %cond974, label %bb_rcarm129, label %bb_rcarmnext129
bb_rcarm129:
  %v975 = load i64, ptr %slot6, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i32, ptr %p976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld977, ptr %slot118, align 8
  %v978 = load i32, ptr %slot118, align 8
  %cv979 = zext i32 %v978 to i64
  %cond980 = icmp ne i64 %cv979, 0
  br i1 %cond980, label %bb_rcslotdrop132, label %bb_rcslotdone132
bb_rcslotdrop132:
  %v981 = load i64, ptr %slot6, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i32 0, ptr %p982, align 4, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot10, align 8
  store i64 %v983, ptr %slot119, align 8
  %v984 = load i64, ptr %slot7, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i32, ptr %p985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld986, ptr %slot120, align 8
  %v987 = load i32, ptr %slot120, align 8
  %op988 = and i32 %v987, 28
  store i32 %op988, ptr %slot121, align 8
  %v989 = load i32, ptr %slot121, align 8
  %cv990 = zext i32 %v989 to i64
  %cond991 = icmp ne i64 %cv990, 0
  br i1 %cond991, label %bb_rcslotrole132, label %bb_rcslotowner132
bb_rcslotrole132:
  %v992 = load i64, ptr %slot23, align 8
  store i64 %v992, ptr %slot122, align 8
  %v993 = load i64, ptr %slot122, align 8
  %v994 = load i64, ptr %slot119, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v993, i64 %v994) nomerge, !dbg !122
  br label %bb_rcslotdone132
bb_rcslotowner132:
  %v995 = load i64, ptr %slot23, align 8
  store i64 %v995, ptr %slot123, align 8
  %v996 = load i64, ptr %slot123, align 8
  %v997 = load i64, ptr %slot119, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v996, i64 %v997) nomerge, !dbg !122
  br label %bb_rcslotdone132
bb_rcslotdone132:
  br label %bb_i65
bb_rcarmnext129:
  %v998 = load i64, ptr %slot67, align 8
  %cmp999 = icmp eq i64 %v998, 8
  %cv1000 = zext i1 %cmp999 to i64
  store i64 %cv1000, ptr %slot124, align 8
  %v1001 = load i64, ptr %slot124, align 8
  %cond1002 = icmp ne i64 %v1001, 0
  br i1 %cond1002, label %bb_rcarm139, label %bb_rcarmnext139
bb_rcarm139:
  %v1003 = load i64, ptr %slot6, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i32, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1005, ptr %slot125, align 8
  %v1006 = load i32, ptr %slot125, align 8
  %cv1007 = zext i32 %v1006 to i64
  %cond1008 = icmp ne i64 %cv1007, 0
  br i1 %cond1008, label %bb_rcslotdrop142, label %bb_rcslotdone142
bb_rcslotdrop142:
  %v1009 = load i64, ptr %slot6, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i32 0, ptr %p1010, align 4, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot10, align 8
  store i64 %v1011, ptr %slot126, align 8
  %v1012 = load i64, ptr %slot7, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %ld1014 = load i32, ptr %p1013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1014, ptr %slot127, align 8
  %v1015 = load i32, ptr %slot127, align 8
  %op1016 = and i32 %v1015, 28
  store i32 %op1016, ptr %slot128, align 8
  %v1017 = load i32, ptr %slot128, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcslotrole142, label %bb_rcslotowner142
bb_rcslotrole142:
  %v1020 = load i64, ptr %slot23, align 8
  store i64 %v1020, ptr %slot129, align 8
  %v1021 = load i64, ptr %slot129, align 8
  %v1022 = load i64, ptr %slot126, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1021, i64 %v1022) nomerge, !dbg !122
  br label %bb_rcslotdone142
bb_rcslotowner142:
  %v1023 = load i64, ptr %slot23, align 8
  store i64 %v1023, ptr %slot130, align 8
  %v1024 = load i64, ptr %slot130, align 8
  %v1025 = load i64, ptr %slot126, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1024, i64 %v1025) nomerge, !dbg !122
  br label %bb_rcslotdone142
bb_rcslotdone142:
  br label %bb_i71
bb_rcarmnext139:
  %v1026 = load i64, ptr %slot67, align 8
  %cmp1027 = icmp eq i64 %v1026, 9
  %cv1028 = zext i1 %cmp1027 to i64
  store i64 %cv1028, ptr %slot131, align 8
  %v1029 = load i64, ptr %slot131, align 8
  %cond1030 = icmp ne i64 %v1029, 0
  br i1 %cond1030, label %bb_rcarm149, label %bb_rcarmnext149
bb_rcarm149:
  %v1031 = load i64, ptr %slot66, align 8
  %op1032 = add i64 %v1031, 8
  store i64 %op1032, ptr %slot132, align 8
  %v1033 = load i64, ptr %slot132, align 8
  %v1034 = load i64, ptr %slot16, align 8
  %p1035 = inttoptr i64 %v1033 to ptr
  %p1036 = inttoptr i64 %v1034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1036, ptr %p1035, i64 16, i1 false), !alias.scope !10000000
  %v1037 = load i64, ptr %slot6, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %ld1039 = load i32, ptr %p1038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1039, ptr %slot133, align 8
  %v1040 = load i32, ptr %slot133, align 8
  %cv1041 = zext i32 %v1040 to i64
  %cond1042 = icmp ne i64 %cv1041, 0
  br i1 %cond1042, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v1043 = load i64, ptr %slot6, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  store i32 0, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  %v1045 = load i64, ptr %slot10, align 8
  store i64 %v1045, ptr %slot134, align 8
  %v1046 = load i64, ptr %slot7, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i32, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1048, ptr %slot135, align 8
  %v1049 = load i32, ptr %slot135, align 8
  %op1050 = and i32 %v1049, 28
  store i32 %op1050, ptr %slot136, align 8
  %v1051 = load i32, ptr %slot136, align 8
  %cv1052 = zext i32 %v1051 to i64
  %cond1053 = icmp ne i64 %cv1052, 0
  br i1 %cond1053, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v1054 = load i64, ptr %slot23, align 8
  store i64 %v1054, ptr %slot137, align 8
  %v1055 = load i64, ptr %slot137, align 8
  %v1056 = load i64, ptr %slot134, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1055, i64 %v1056) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v1057 = load i64, ptr %slot23, align 8
  store i64 %v1057, ptr %slot138, align 8
  %v1058 = load i64, ptr %slot138, align 8
  %v1059 = load i64, ptr %slot134, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1058, i64 %v1059) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotdone163:
  br label %bb_i17
bb_rcarmnext149:
  %v1060 = load i64, ptr %slot67, align 8
  %cmp1061 = icmp eq i64 %v1060, 10
  %cv1062 = zext i1 %cmp1061 to i64
  store i64 %cv1062, ptr %slot139, align 8
  %v1063 = load i64, ptr %slot139, align 8
  %cond1064 = icmp ne i64 %v1063, 0
  br i1 %cond1064, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  %v1065 = load i64, ptr %slot6, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  %ld1067 = load i32, ptr %p1066, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1067, ptr %slot140, align 8
  %v1068 = load i32, ptr %slot140, align 8
  %cv1069 = zext i32 %v1068 to i64
  %cond1070 = icmp ne i64 %cv1069, 0
  br i1 %cond1070, label %bb_rcslotdrop173, label %bb_rcslotdone173
bb_rcslotdrop173:
  %v1071 = load i64, ptr %slot6, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  store i32 0, ptr %p1072, align 4, !alias.scope !3, !noalias !4
  %v1073 = load i64, ptr %slot10, align 8
  store i64 %v1073, ptr %slot141, align 8
  %v1074 = load i64, ptr %slot7, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  %ld1076 = load i32, ptr %p1075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1076, ptr %slot142, align 8
  %v1077 = load i32, ptr %slot142, align 8
  %op1078 = and i32 %v1077, 28
  store i32 %op1078, ptr %slot143, align 8
  %v1079 = load i32, ptr %slot143, align 8
  %cv1080 = zext i32 %v1079 to i64
  %cond1081 = icmp ne i64 %cv1080, 0
  br i1 %cond1081, label %bb_rcslotrole173, label %bb_rcslotowner173
bb_rcslotrole173:
  %v1082 = load i64, ptr %slot23, align 8
  store i64 %v1082, ptr %slot144, align 8
  %v1083 = load i64, ptr %slot144, align 8
  %v1084 = load i64, ptr %slot141, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1083, i64 %v1084) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotowner173:
  %v1085 = load i64, ptr %slot23, align 8
  store i64 %v1085, ptr %slot145, align 8
  %v1086 = load i64, ptr %slot145, align 8
  %v1087 = load i64, ptr %slot141, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1086, i64 %v1087) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotdone173:
  br label %bb_i77
bb_rcarmnext170:
  br label %bb_failure
bb_i17:
  %v1088 = load i64, ptr %slot16, align 8
  %v1089 = load i64, ptr %slot17, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  store i64 %v1088, ptr %p1090, align 8, !alias.scope !3, !noalias !4
  %v1091 = load i64, ptr %slot16, align 8
  %v1092 = load i64, ptr %slot17, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  store i64 %v1091, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  %v1094 = load i64, ptr %slot17, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %ld1096 = load i64, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1096, ptr %slot146, align 8
  %v1097 = load i64, ptr %slot6, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  %ld1099 = load i32, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1099, ptr %slot147, align 8
  %v1100 = load i64, ptr %slot7, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i32, ptr %p1101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1102, ptr %slot148, align 8
  %v1103 = load i32, ptr %slot148, align 8
  %op1104 = and i32 %v1103, 24
  store i32 %op1104, ptr %slot148, align 8
  %v1105 = load i32, ptr %slot148, align 8
  %cmp1106 = icmp eq i32 %v1105, 0
  %cv1107 = zext i1 %cmp1106 to i32
  store i32 %cv1107, ptr %slot149, align 8
  %v1108 = load i32, ptr %slot147, align 8
  %v1109 = load i32, ptr %slot149, align 8
  %op1110 = and i32 %v1108, %v1109
  store i32 %op1110, ptr %slot150, align 8
  %v1111 = load i64, ptr %slot24, align 8
  store i64 %v1111, ptr %slot151, align 8
  %v1112 = load i32, ptr %slot150, align 8
  %op1113 = mul i32 %v1112, 4
  store i32 %op1113, ptr %slot152, align 8
  %v1114 = load i32, ptr %slot152, align 8
  %op1115 = or i32 %v1114, 0
  store i32 %op1115, ptr %slot153, align 8
  %v1116 = load i64, ptr %slot11, align 8
  store i64 %v1116, ptr %slot154, align 8
  %v1117 = load i64, ptr %slot23, align 8
  %v1118 = load i64, ptr %slot154, align 8
  %v1119 = load i64, ptr %slot146, align 8
  %v1120 = load i64, ptr %slot151, align 8
  %cv1121 = trunc i64 %v1120 to i32
  %v1122 = load i32, ptr %slot153, align 8
  %call1123 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_publish(i64 %v1117, i64 %v1118, i64 %v1119, i32 %cv1121, i32 %v1122) nomerge, !dbg !124
  store i32 %call1123, ptr %slot155, align 8
  %v1124 = load i32, ptr %slot155, align 8
  %cv1125 = zext i32 %v1124 to i64
  %cond1126 = icmp ne i64 %cv1125, 0
  br i1 %cond1126, label %bb_rcsuccess194, label %bb_rcfailure194
bb_rcfailure194:
  %v1127 = load i64, ptr %slot23, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  %call1129 = call i32 @myl_rc_take_failure(ptr %p1128) nomerge, !dbg !124
  store i32 %call1129, ptr %slot156, align 8
  %v1130 = load i64, ptr %slot1, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %v1132 = load i32, ptr %slot156, align 8
  %call1133 = call i32 @myl_qbe_rc_status(ptr %p1131, i32 %v1132) nomerge, !dbg !124
  store i32 %call1133, ptr %slot157, align 8
  br label %bb_failure
bb_rcsuccess194:
  %v1134 = load i32, ptr %slot150, align 8
  %cv1135 = zext i32 %v1134 to i64
  %cond1136 = icmp ne i64 %cv1135, 0
  br i1 %cond1136, label %bb_rchtaken197, label %bb_rchcopied197
bb_rchcopied197:
  %v1137 = load i64, ptr %slot6, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %ld1139 = load i32, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1139, ptr %slot158, align 8
  %v1140 = load i32, ptr %slot158, align 8
  %cv1141 = zext i32 %v1140 to i64
  %cond1142 = icmp ne i64 %cv1141, 0
  br i1 %cond1142, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1143 = load i64, ptr %slot6, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i32 0, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot10, align 8
  store i64 %v1145, ptr %slot159, align 8
  %v1146 = load i64, ptr %slot7, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i32, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1148, ptr %slot160, align 8
  %v1149 = load i32, ptr %slot160, align 8
  %op1150 = and i32 %v1149, 28
  store i32 %op1150, ptr %slot161, align 8
  %v1151 = load i32, ptr %slot161, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1154 = load i64, ptr %slot23, align 8
  store i64 %v1154, ptr %slot162, align 8
  %v1155 = load i64, ptr %slot162, align 8
  %v1156 = load i64, ptr %slot159, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1155, i64 %v1156) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1157 = load i64, ptr %slot23, align 8
  store i64 %v1157, ptr %slot163, align 8
  %v1158 = load i64, ptr %slot163, align 8
  %v1159 = load i64, ptr %slot159, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1158, i64 %v1159) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotdone200:
  br label %bb_rchprepared197
bb_rchtaken197:
  %v1160 = load i64, ptr %slot6, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i32 0, ptr %p1161, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared197
bb_rchprepared197:
  %v1162 = load i64, ptr %slot9, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i32 2, ptr %p1163, align 4, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot8, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  store i32 1, ptr %p1165, align 4, !alias.scope !3, !noalias !4
  %v1166 = load i64, ptr %slot10, align 8
  store i64 %v1166, ptr %slot164, align 8
  %v1167 = load i64, ptr %slot11, align 8
  store i64 %v1167, ptr %slot165, align 8
  %v1168 = load i64, ptr %slot165, align 8
  %v1169 = load i64, ptr %slot164, align 8
  %p1170 = inttoptr i64 %v1168 to ptr
  %p1171 = inttoptr i64 %v1169 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1171, ptr %p1170, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1172 = load i64, ptr %slot7, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i32 2, ptr %p1173, align 4, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot9, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i32, ptr %p1175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1176, ptr %slot166, align 8
  %v1177 = load i32, ptr %slot166, align 8
  %v1178 = load i64, ptr %slot7, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 %v1177, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot8, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  store i32 0, ptr %p1181, align 4, !alias.scope !3, !noalias !4
  %v1182 = load i64, ptr %slot6, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  store i32 1, ptr %p1183, align 4, !alias.scope !3, !noalias !4
  %v1184 = load i64, ptr %slot164, align 8
  %v1185 = load i64, ptr %slot17, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i64 %v1184, ptr %p1186, align 8, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot17, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i64, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1189, ptr %slot167, align 8
  %v1190 = load i64, ptr %slot17, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  %ld1192 = load i64, ptr %p1191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1192, ptr %slot168, align 8
  %v1193 = load i64, ptr %slot11, align 8
  store i64 %v1193, ptr %slot169, align 8
  %v1194 = load i64, ptr %slot24, align 8
  store i64 %v1194, ptr %slot170, align 8
  %v1195 = load i64, ptr %slot168, align 8
  %op1196 = add i64 %v1195, 8
  store i64 %op1196, ptr %slot171, align 8
  %v1197 = load i64, ptr %slot171, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %ld1199 = load i64, ptr %p1198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1199, ptr %slot172, align 8
  %v1200 = load i64, ptr %slot172, align 8
  %cmp1201 = icmp ne i64 %v1200, 0
  %cv1202 = zext i1 %cmp1201 to i32
  store i32 %cv1202, ptr %slot173, align 8
  %v1203 = load i32, ptr %slot173, align 8
  %cv1204 = zext i32 %v1203 to i64
  %cond1205 = icmp ne i64 %cv1204, 0
  br i1 %cond1205, label %bb_rcmoveheader225, label %bb_rcmovenext225
bb_rcmoveheader225:
  %v1206 = load i64, ptr %slot172, align 8
  %op1207 = sub i64 %v1206, 16
  store i64 %op1207, ptr %slot174, align 8
  %v1208 = load i64, ptr %slot172, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %rgep1210 = getelementptr i8, ptr %p1209, i64 -16
  %ld1211 = load i64, ptr %rgep1210, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1211, ptr %slot175, align 8
  %v1212 = load i64, ptr %slot175, align 8
  %op1213 = and i64 %v1212, 5764607523034234881
  store i64 %op1213, ptr %slot176, align 8
  %v1214 = load i64, ptr %slot176, align 8
  %cmp1215 = icmp ne i64 %v1214, 0
  %cv1216 = zext i1 %cmp1215 to i32
  store i32 %cv1216, ptr %slot177, align 8
  %v1217 = load i32, ptr %slot177, align 8
  %cv1218 = zext i32 %v1217 to i64
  %cond1219 = icmp ne i64 %cv1218, 0
  br i1 %cond1219, label %bb_rcmoveslow222, label %bb_rcmovenext225
bb_rcmovenext225:
  %v1220 = load i64, ptr %slot168, align 8
  %v1221 = load i64, ptr %slot169, align 8
  %p1222 = inttoptr i64 %v1220 to ptr
  %p1223 = inttoptr i64 %v1221 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1223, ptr %p1222, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot168, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i64 0, ptr %p1225, align 8, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot168, align 8
  %op1227 = add i64 %v1226, 8
  store i64 %op1227, ptr %slot178, align 8
  %v1228 = load i64, ptr %slot178, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  store i64 0, ptr %p1229, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved222
bb_rcmoveslow222:
  %v1230 = load i64, ptr %slot23, align 8
  %v1231 = load i64, ptr %slot169, align 8
  %v1232 = load i64, ptr %slot168, align 8
  %v1233 = load i64, ptr %slot170, align 8
  %cv1234 = trunc i64 %v1233 to i32
  %call1235 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1230, i64 %v1231, i64 %v1232, i32 %cv1234) nomerge, !dbg !126
  store i32 %call1235, ptr %slot179, align 8
  %v1236 = load i32, ptr %slot179, align 8
  %cv1237 = zext i32 %v1236 to i64
  %cond1238 = icmp ne i64 %cv1237, 0
  br i1 %cond1238, label %bb_rcsuccess233, label %bb_rcfailure233
bb_rcfailure233:
  %v1239 = load i64, ptr %slot23, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %call1241 = call i32 @myl_rc_take_failure(ptr %p1240) nomerge, !dbg !126
  store i32 %call1241, ptr %slot180, align 8
  %v1242 = load i64, ptr %slot1, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %v1244 = load i32, ptr %slot180, align 8
  %call1245 = call i32 @myl_qbe_rc_status(ptr %p1243, i32 %v1244) nomerge, !dbg !126
  store i32 %call1245, ptr %slot181, align 8
  br label %bb_failure
bb_rcsuccess233:
  br label %bb_rcmoved222
bb_rcmoved222:
  %v1246 = load i64, ptr %slot6, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i32 0, ptr %p1247, align 4, !alias.scope !3, !noalias !4
  %v1248 = load i64, ptr %slot9, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i32 2, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot8, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i32 1, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot11, align 8
  store i64 %v1252, ptr %slot182, align 8
  %v1253 = load i64, ptr %slot8, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i32 0, ptr %p1254, align 4, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot6, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i32, ptr %p1256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1257, ptr %slot183, align 8
  %v1258 = load i32, ptr %slot183, align 8
  %cv1259 = zext i32 %v1258 to i64
  %cond1260 = icmp ne i64 %cv1259, 0
  br i1 %cond1260, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v1261 = load i64, ptr %slot6, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  store i32 0, ptr %p1262, align 4, !alias.scope !3, !noalias !4
  %v1263 = load i64, ptr %slot10, align 8
  store i64 %v1263, ptr %slot184, align 8
  %v1264 = load i64, ptr %slot7, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  %ld1266 = load i32, ptr %p1265, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1266, ptr %slot185, align 8
  %v1267 = load i32, ptr %slot185, align 8
  %op1268 = and i32 %v1267, 28
  store i32 %op1268, ptr %slot186, align 8
  %v1269 = load i32, ptr %slot186, align 8
  %cv1270 = zext i32 %v1269 to i64
  %cond1271 = icmp ne i64 %cv1270, 0
  br i1 %cond1271, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v1272 = load i64, ptr %slot23, align 8
  store i64 %v1272, ptr %slot187, align 8
  %v1273 = load i64, ptr %slot187, align 8
  %v1274 = load i64, ptr %slot184, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1273, i64 %v1274) nomerge, !dbg !126
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v1275 = load i64, ptr %slot23, align 8
  store i64 %v1275, ptr %slot188, align 8
  %v1276 = load i64, ptr %slot188, align 8
  %v1277 = load i64, ptr %slot184, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1276, i64 %v1277) nomerge, !dbg !126
  br label %bb_rcslotdone243
bb_rcslotdone243:
  %v1278 = load i64, ptr %slot182, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ret1280 = load { i64, i64 }, ptr %p1279, align 8
  ret { i64, i64 } %ret1280
bb_i23:
  %v1281 = load i64, ptr %slot17, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i64 0, ptr %p1282, align 8, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot17, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %ld1285 = load i64, ptr %p1284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1285, ptr %slot189, align 8
  %v1286 = load i64, ptr %slot189, align 8
  %cond1287 = icmp ne i64 %v1286, 0
  br i1 %cond1287, label %bb_success306, label %bb_failed306
bb_failed306:
  %v1288 = load i64, ptr %slot1, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  call void @myl_qbe_fail_assert(ptr %p1289) nomerge, !dbg !128
  unreachable
bb_success306:
  %v1290 = load i64, ptr %slot17, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i64 18446744073709551615, ptr %p1291, align 8, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot18, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i64 0, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot17, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i64, ptr %p1295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1296, ptr %slot190, align 8
  %v1297 = load i64, ptr %slot18, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i64, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1299, ptr %slot191, align 8
  %v1300 = load i64, ptr %slot1, align 8
  %v1301 = load i64, ptr %slot190, align 8
  %v1302 = load i64, ptr %slot191, align 8
  %call1303 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v1300, i64 %v1301, i64 %v1302) nomerge, !dbg !130
  store { i64, i64 } %call1303, ptr %callresult193, align 8
  %addr1304 = ptrtoint ptr %callresult193 to i64
  store i64 %addr1304, ptr %slot192, align 8
  %v1305 = load i64, ptr %slot192, align 8
  %v1306 = load i64, ptr %slot17, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  store i64 %v1305, ptr %p1307, align 8, !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot17, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  %ld1310 = load i64, ptr %p1309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1310, ptr %slot194, align 8
  %v1311 = load i64, ptr %slot11, align 8
  store i64 %v1311, ptr %slot195, align 8
  %v1312 = load i64, ptr %slot194, align 8
  %v1313 = load i64, ptr %slot195, align 8
  %p1314 = inttoptr i64 %v1312 to ptr
  %p1315 = inttoptr i64 %v1313 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1315, ptr %p1314, i64 16, i1 false)
  %v1316 = load i64, ptr %slot9, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 2, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot8, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 1, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot10, align 8
  store i64 %v1320, ptr %slot196, align 8
  %v1321 = load i64, ptr %slot11, align 8
  store i64 %v1321, ptr %slot197, align 8
  %v1322 = load i64, ptr %slot197, align 8
  %v1323 = load i64, ptr %slot196, align 8
  %p1324 = inttoptr i64 %v1322 to ptr
  %p1325 = inttoptr i64 %v1323 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1325, ptr %p1324, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot7, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 2, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot9, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  %ld1330 = load i32, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1330, ptr %slot198, align 8
  %v1331 = load i32, ptr %slot198, align 8
  %v1332 = load i64, ptr %slot7, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 %v1331, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot8, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 0, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot6, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 1, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot196, align 8
  %v1339 = load i64, ptr %slot17, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i64 %v1338, ptr %p1340, align 8, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot17, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i64, ptr %p1342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1343, ptr %slot199, align 8
  %v1344 = load i64, ptr %slot17, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  %ld1346 = load i64, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1346, ptr %slot200, align 8
  %v1347 = load i64, ptr %slot11, align 8
  store i64 %v1347, ptr %slot201, align 8
  %v1348 = load i64, ptr %slot24, align 8
  store i64 %v1348, ptr %slot202, align 8
  %v1349 = load i64, ptr %slot200, align 8
  %op1350 = add i64 %v1349, 8
  store i64 %op1350, ptr %slot203, align 8
  %v1351 = load i64, ptr %slot203, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  %ld1353 = load i64, ptr %p1352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1353, ptr %slot204, align 8
  %v1354 = load i64, ptr %slot204, align 8
  %cmp1355 = icmp ne i64 %v1354, 0
  %cv1356 = zext i1 %cmp1355 to i32
  store i32 %cv1356, ptr %slot205, align 8
  %v1357 = load i32, ptr %slot205, align 8
  %cv1358 = zext i32 %v1357 to i64
  %cond1359 = icmp ne i64 %cv1358, 0
  br i1 %cond1359, label %bb_rcmoveheader329, label %bb_rcmovenext329
bb_rcmoveheader329:
  %v1360 = load i64, ptr %slot204, align 8
  %op1361 = sub i64 %v1360, 16
  store i64 %op1361, ptr %slot206, align 8
  %v1362 = load i64, ptr %slot204, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %rgep1364 = getelementptr i8, ptr %p1363, i64 -16
  %ld1365 = load i64, ptr %rgep1364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1365, ptr %slot207, align 8
  %v1366 = load i64, ptr %slot207, align 8
  %op1367 = and i64 %v1366, 5764607523034234881
  store i64 %op1367, ptr %slot208, align 8
  %v1368 = load i64, ptr %slot208, align 8
  %cmp1369 = icmp ne i64 %v1368, 0
  %cv1370 = zext i1 %cmp1369 to i32
  store i32 %cv1370, ptr %slot209, align 8
  %v1371 = load i32, ptr %slot209, align 8
  %cv1372 = zext i32 %v1371 to i64
  %cond1373 = icmp ne i64 %cv1372, 0
  br i1 %cond1373, label %bb_rcmoveslow326, label %bb_rcmovenext329
bb_rcmovenext329:
  %v1374 = load i64, ptr %slot200, align 8
  %v1375 = load i64, ptr %slot201, align 8
  %p1376 = inttoptr i64 %v1374 to ptr
  %p1377 = inttoptr i64 %v1375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1377, ptr %p1376, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot200, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 0, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot200, align 8
  %op1381 = add i64 %v1380, 8
  store i64 %op1381, ptr %slot210, align 8
  %v1382 = load i64, ptr %slot210, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i64 0, ptr %p1383, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved326
bb_rcmoveslow326:
  %v1384 = load i64, ptr %slot23, align 8
  %v1385 = load i64, ptr %slot201, align 8
  %v1386 = load i64, ptr %slot200, align 8
  %v1387 = load i64, ptr %slot202, align 8
  %cv1388 = trunc i64 %v1387 to i32
  %call1389 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1384, i64 %v1385, i64 %v1386, i32 %cv1388) nomerge, !dbg !132
  store i32 %call1389, ptr %slot211, align 8
  %v1390 = load i32, ptr %slot211, align 8
  %cv1391 = zext i32 %v1390 to i64
  %cond1392 = icmp ne i64 %cv1391, 0
  br i1 %cond1392, label %bb_rcsuccess337, label %bb_rcfailure337
bb_rcfailure337:
  %v1393 = load i64, ptr %slot23, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  %call1395 = call i32 @myl_rc_take_failure(ptr %p1394) nomerge, !dbg !132
  store i32 %call1395, ptr %slot212, align 8
  %v1396 = load i64, ptr %slot1, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %v1398 = load i32, ptr %slot212, align 8
  %call1399 = call i32 @myl_qbe_rc_status(ptr %p1397, i32 %v1398) nomerge, !dbg !132
  store i32 %call1399, ptr %slot213, align 8
  br label %bb_failure
bb_rcsuccess337:
  br label %bb_rcmoved326
bb_rcmoved326:
  %v1400 = load i64, ptr %slot6, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 0, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot9, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 2, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot8, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 1, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot11, align 8
  store i64 %v1406, ptr %slot214, align 8
  %v1407 = load i64, ptr %slot8, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i32 0, ptr %p1408, align 4, !alias.scope !3, !noalias !4
  %v1409 = load i64, ptr %slot6, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %ld1411 = load i32, ptr %p1410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1411, ptr %slot215, align 8
  %v1412 = load i32, ptr %slot215, align 8
  %cv1413 = zext i32 %v1412 to i64
  %cond1414 = icmp ne i64 %cv1413, 0
  br i1 %cond1414, label %bb_rcslotdrop347, label %bb_rcslotdone347
bb_rcslotdrop347:
  %v1415 = load i64, ptr %slot6, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i32 0, ptr %p1416, align 4, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot10, align 8
  store i64 %v1417, ptr %slot216, align 8
  %v1418 = load i64, ptr %slot7, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i32, ptr %p1419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1420, ptr %slot217, align 8
  %v1421 = load i32, ptr %slot217, align 8
  %op1422 = and i32 %v1421, 28
  store i32 %op1422, ptr %slot218, align 8
  %v1423 = load i32, ptr %slot218, align 8
  %cv1424 = zext i32 %v1423 to i64
  %cond1425 = icmp ne i64 %cv1424, 0
  br i1 %cond1425, label %bb_rcslotrole347, label %bb_rcslotowner347
bb_rcslotrole347:
  %v1426 = load i64, ptr %slot23, align 8
  store i64 %v1426, ptr %slot219, align 8
  %v1427 = load i64, ptr %slot219, align 8
  %v1428 = load i64, ptr %slot216, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1427, i64 %v1428) nomerge, !dbg !132
  br label %bb_rcslotdone347
bb_rcslotowner347:
  %v1429 = load i64, ptr %slot23, align 8
  store i64 %v1429, ptr %slot220, align 8
  %v1430 = load i64, ptr %slot220, align 8
  %v1431 = load i64, ptr %slot216, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1430, i64 %v1431) nomerge, !dbg !132
  br label %bb_rcslotdone347
bb_rcslotdone347:
  %v1432 = load i64, ptr %slot214, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ret1434 = load { i64, i64 }, ptr %p1433, align 8
  ret { i64, i64 } %ret1434
bb_i29:
  %v1435 = load i64, ptr %slot17, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  store i64 0, ptr %p1436, align 8, !alias.scope !3, !noalias !4
  %v1437 = load i64, ptr %slot17, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  %ld1439 = load i64, ptr %p1438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1439, ptr %slot221, align 8
  %v1440 = load i64, ptr %slot221, align 8
  %cond1441 = icmp ne i64 %v1440, 0
  br i1 %cond1441, label %bb_success410, label %bb_failed410
bb_failed410:
  %v1442 = load i64, ptr %slot1, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  call void @myl_qbe_fail_assert(ptr %p1443) nomerge, !dbg !134
  unreachable
bb_success410:
  %v1444 = load i64, ptr %slot17, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i64 18446744073709551615, ptr %p1445, align 8, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot18, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i64 0, ptr %p1447, align 8, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot17, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  %ld1450 = load i64, ptr %p1449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1450, ptr %slot222, align 8
  %v1451 = load i64, ptr %slot18, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  %ld1453 = load i64, ptr %p1452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1453, ptr %slot223, align 8
  %v1454 = load i64, ptr %slot1, align 8
  %v1455 = load i64, ptr %slot222, align 8
  %v1456 = load i64, ptr %slot223, align 8
  %call1457 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v1454, i64 %v1455, i64 %v1456) nomerge, !dbg !136
  store { i64, i64 } %call1457, ptr %callresult225, align 8
  %addr1458 = ptrtoint ptr %callresult225 to i64
  store i64 %addr1458, ptr %slot224, align 8
  %v1459 = load i64, ptr %slot224, align 8
  %v1460 = load i64, ptr %slot17, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  store i64 %v1459, ptr %p1461, align 8, !alias.scope !3, !noalias !4
  %v1462 = load i64, ptr %slot17, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1464, ptr %slot226, align 8
  %v1465 = load i64, ptr %slot11, align 8
  store i64 %v1465, ptr %slot227, align 8
  %v1466 = load i64, ptr %slot226, align 8
  %v1467 = load i64, ptr %slot227, align 8
  %p1468 = inttoptr i64 %v1466 to ptr
  %p1469 = inttoptr i64 %v1467 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1469, ptr %p1468, i64 16, i1 false)
  %v1470 = load i64, ptr %slot9, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  store i32 2, ptr %p1471, align 4, !alias.scope !3, !noalias !4
  %v1472 = load i64, ptr %slot8, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  store i32 1, ptr %p1473, align 4, !alias.scope !3, !noalias !4
  %v1474 = load i64, ptr %slot10, align 8
  store i64 %v1474, ptr %slot228, align 8
  %v1475 = load i64, ptr %slot11, align 8
  store i64 %v1475, ptr %slot229, align 8
  %v1476 = load i64, ptr %slot229, align 8
  %v1477 = load i64, ptr %slot228, align 8
  %p1478 = inttoptr i64 %v1476 to ptr
  %p1479 = inttoptr i64 %v1477 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1479, ptr %p1478, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1480 = load i64, ptr %slot7, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i32 2, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  %v1482 = load i64, ptr %slot9, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %ld1484 = load i32, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1484, ptr %slot230, align 8
  %v1485 = load i32, ptr %slot230, align 8
  %v1486 = load i64, ptr %slot7, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  store i32 %v1485, ptr %p1487, align 4, !alias.scope !3, !noalias !4
  %v1488 = load i64, ptr %slot8, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i32 0, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot6, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i32 1, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot228, align 8
  %v1493 = load i64, ptr %slot17, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i64 %v1492, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot17, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  %ld1497 = load i64, ptr %p1496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1497, ptr %slot231, align 8
  %v1498 = load i64, ptr %slot17, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  %ld1500 = load i64, ptr %p1499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1500, ptr %slot232, align 8
  %v1501 = load i64, ptr %slot11, align 8
  store i64 %v1501, ptr %slot233, align 8
  %v1502 = load i64, ptr %slot24, align 8
  store i64 %v1502, ptr %slot234, align 8
  %v1503 = load i64, ptr %slot232, align 8
  %op1504 = add i64 %v1503, 8
  store i64 %op1504, ptr %slot235, align 8
  %v1505 = load i64, ptr %slot235, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot236, align 8
  %v1508 = load i64, ptr %slot236, align 8
  %cmp1509 = icmp ne i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot237, align 8
  %v1511 = load i32, ptr %slot237, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcmoveheader433, label %bb_rcmovenext433
bb_rcmoveheader433:
  %v1514 = load i64, ptr %slot236, align 8
  %op1515 = sub i64 %v1514, 16
  store i64 %op1515, ptr %slot238, align 8
  %v1516 = load i64, ptr %slot236, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %rgep1518 = getelementptr i8, ptr %p1517, i64 -16
  %ld1519 = load i64, ptr %rgep1518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1519, ptr %slot239, align 8
  %v1520 = load i64, ptr %slot239, align 8
  %op1521 = and i64 %v1520, 5764607523034234881
  store i64 %op1521, ptr %slot240, align 8
  %v1522 = load i64, ptr %slot240, align 8
  %cmp1523 = icmp ne i64 %v1522, 0
  %cv1524 = zext i1 %cmp1523 to i32
  store i32 %cv1524, ptr %slot241, align 8
  %v1525 = load i32, ptr %slot241, align 8
  %cv1526 = zext i32 %v1525 to i64
  %cond1527 = icmp ne i64 %cv1526, 0
  br i1 %cond1527, label %bb_rcmoveslow430, label %bb_rcmovenext433
bb_rcmovenext433:
  %v1528 = load i64, ptr %slot232, align 8
  %v1529 = load i64, ptr %slot233, align 8
  %p1530 = inttoptr i64 %v1528 to ptr
  %p1531 = inttoptr i64 %v1529 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1531, ptr %p1530, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1532 = load i64, ptr %slot232, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i64 0, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  %v1534 = load i64, ptr %slot232, align 8
  %op1535 = add i64 %v1534, 8
  store i64 %op1535, ptr %slot242, align 8
  %v1536 = load i64, ptr %slot242, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i64 0, ptr %p1537, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved430
bb_rcmoveslow430:
  %v1538 = load i64, ptr %slot23, align 8
  %v1539 = load i64, ptr %slot233, align 8
  %v1540 = load i64, ptr %slot232, align 8
  %v1541 = load i64, ptr %slot234, align 8
  %cv1542 = trunc i64 %v1541 to i32
  %call1543 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1538, i64 %v1539, i64 %v1540, i32 %cv1542) nomerge, !dbg !138
  store i32 %call1543, ptr %slot243, align 8
  %v1544 = load i32, ptr %slot243, align 8
  %cv1545 = zext i32 %v1544 to i64
  %cond1546 = icmp ne i64 %cv1545, 0
  br i1 %cond1546, label %bb_rcsuccess441, label %bb_rcfailure441
bb_rcfailure441:
  %v1547 = load i64, ptr %slot23, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  %call1549 = call i32 @myl_rc_take_failure(ptr %p1548) nomerge, !dbg !138
  store i32 %call1549, ptr %slot244, align 8
  %v1550 = load i64, ptr %slot1, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  %v1552 = load i32, ptr %slot244, align 8
  %call1553 = call i32 @myl_qbe_rc_status(ptr %p1551, i32 %v1552) nomerge, !dbg !138
  store i32 %call1553, ptr %slot245, align 8
  br label %bb_failure
bb_rcsuccess441:
  br label %bb_rcmoved430
bb_rcmoved430:
  %v1554 = load i64, ptr %slot6, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  store i32 0, ptr %p1555, align 4, !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot9, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i32 2, ptr %p1557, align 4, !alias.scope !3, !noalias !4
  %v1558 = load i64, ptr %slot8, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i32 1, ptr %p1559, align 4, !alias.scope !3, !noalias !4
  %v1560 = load i64, ptr %slot11, align 8
  store i64 %v1560, ptr %slot246, align 8
  %v1561 = load i64, ptr %slot8, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i32 0, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot6, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i32, ptr %p1564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1565, ptr %slot247, align 8
  %v1566 = load i32, ptr %slot247, align 8
  %cv1567 = zext i32 %v1566 to i64
  %cond1568 = icmp ne i64 %cv1567, 0
  br i1 %cond1568, label %bb_rcslotdrop451, label %bb_rcslotdone451
bb_rcslotdrop451:
  %v1569 = load i64, ptr %slot6, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i32 0, ptr %p1570, align 4, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot10, align 8
  store i64 %v1571, ptr %slot248, align 8
  %v1572 = load i64, ptr %slot7, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %ld1574 = load i32, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1574, ptr %slot249, align 8
  %v1575 = load i32, ptr %slot249, align 8
  %op1576 = and i32 %v1575, 28
  store i32 %op1576, ptr %slot250, align 8
  %v1577 = load i32, ptr %slot250, align 8
  %cv1578 = zext i32 %v1577 to i64
  %cond1579 = icmp ne i64 %cv1578, 0
  br i1 %cond1579, label %bb_rcslotrole451, label %bb_rcslotowner451
bb_rcslotrole451:
  %v1580 = load i64, ptr %slot23, align 8
  store i64 %v1580, ptr %slot251, align 8
  %v1581 = load i64, ptr %slot251, align 8
  %v1582 = load i64, ptr %slot248, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1581, i64 %v1582) nomerge, !dbg !138
  br label %bb_rcslotdone451
bb_rcslotowner451:
  %v1583 = load i64, ptr %slot23, align 8
  store i64 %v1583, ptr %slot252, align 8
  %v1584 = load i64, ptr %slot252, align 8
  %v1585 = load i64, ptr %slot248, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1584, i64 %v1585) nomerge, !dbg !138
  br label %bb_rcslotdone451
bb_rcslotdone451:
  %v1586 = load i64, ptr %slot246, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ret1588 = load { i64, i64 }, ptr %p1587, align 8
  ret { i64, i64 } %ret1588
bb_i35:
  %v1589 = load i64, ptr %slot17, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i64 0, ptr %p1590, align 8, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot17, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %ld1593 = load i64, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1593, ptr %slot253, align 8
  %v1594 = load i64, ptr %slot253, align 8
  %cond1595 = icmp ne i64 %v1594, 0
  br i1 %cond1595, label %bb_success514, label %bb_failed514
bb_failed514:
  %v1596 = load i64, ptr %slot1, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  call void @myl_qbe_fail_assert(ptr %p1597) nomerge, !dbg !140
  unreachable
bb_success514:
  %v1598 = load i64, ptr %slot17, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i64 18446744073709551615, ptr %p1599, align 8, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot18, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i64 0, ptr %p1601, align 8, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot17, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  %ld1604 = load i64, ptr %p1603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1604, ptr %slot254, align 8
  %v1605 = load i64, ptr %slot18, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  %ld1607 = load i64, ptr %p1606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1607, ptr %slot255, align 8
  %v1608 = load i64, ptr %slot1, align 8
  %v1609 = load i64, ptr %slot254, align 8
  %v1610 = load i64, ptr %slot255, align 8
  %call1611 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v1608, i64 %v1609, i64 %v1610) nomerge, !dbg !142
  store { i64, i64 } %call1611, ptr %callresult257, align 8
  %addr1612 = ptrtoint ptr %callresult257 to i64
  store i64 %addr1612, ptr %slot256, align 8
  %v1613 = load i64, ptr %slot256, align 8
  %v1614 = load i64, ptr %slot17, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i64 %v1613, ptr %p1615, align 8, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot17, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  %ld1618 = load i64, ptr %p1617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1618, ptr %slot258, align 8
  %v1619 = load i64, ptr %slot11, align 8
  store i64 %v1619, ptr %slot259, align 8
  %v1620 = load i64, ptr %slot258, align 8
  %v1621 = load i64, ptr %slot259, align 8
  %p1622 = inttoptr i64 %v1620 to ptr
  %p1623 = inttoptr i64 %v1621 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1623, ptr %p1622, i64 16, i1 false)
  %v1624 = load i64, ptr %slot9, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 2, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot8, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 1, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot10, align 8
  store i64 %v1628, ptr %slot260, align 8
  %v1629 = load i64, ptr %slot11, align 8
  store i64 %v1629, ptr %slot261, align 8
  %v1630 = load i64, ptr %slot261, align 8
  %v1631 = load i64, ptr %slot260, align 8
  %p1632 = inttoptr i64 %v1630 to ptr
  %p1633 = inttoptr i64 %v1631 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1633, ptr %p1632, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1634 = load i64, ptr %slot7, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i32 2, ptr %p1635, align 4, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot9, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i32, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1638, ptr %slot262, align 8
  %v1639 = load i32, ptr %slot262, align 8
  %v1640 = load i64, ptr %slot7, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i32 %v1639, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot8, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 0, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot6, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  store i32 1, ptr %p1645, align 4, !alias.scope !3, !noalias !4
  %v1646 = load i64, ptr %slot260, align 8
  %v1647 = load i64, ptr %slot17, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  store i64 %v1646, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot17, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  %ld1651 = load i64, ptr %p1650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1651, ptr %slot263, align 8
  %v1652 = load i64, ptr %slot17, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  %ld1654 = load i64, ptr %p1653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1654, ptr %slot264, align 8
  %v1655 = load i64, ptr %slot11, align 8
  store i64 %v1655, ptr %slot265, align 8
  %v1656 = load i64, ptr %slot24, align 8
  store i64 %v1656, ptr %slot266, align 8
  %v1657 = load i64, ptr %slot264, align 8
  %op1658 = add i64 %v1657, 8
  store i64 %op1658, ptr %slot267, align 8
  %v1659 = load i64, ptr %slot267, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i64, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1661, ptr %slot268, align 8
  %v1662 = load i64, ptr %slot268, align 8
  %cmp1663 = icmp ne i64 %v1662, 0
  %cv1664 = zext i1 %cmp1663 to i32
  store i32 %cv1664, ptr %slot269, align 8
  %v1665 = load i32, ptr %slot269, align 8
  %cv1666 = zext i32 %v1665 to i64
  %cond1667 = icmp ne i64 %cv1666, 0
  br i1 %cond1667, label %bb_rcmoveheader537, label %bb_rcmovenext537
bb_rcmoveheader537:
  %v1668 = load i64, ptr %slot268, align 8
  %op1669 = sub i64 %v1668, 16
  store i64 %op1669, ptr %slot270, align 8
  %v1670 = load i64, ptr %slot268, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  %rgep1672 = getelementptr i8, ptr %p1671, i64 -16
  %ld1673 = load i64, ptr %rgep1672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1673, ptr %slot271, align 8
  %v1674 = load i64, ptr %slot271, align 8
  %op1675 = and i64 %v1674, 5764607523034234881
  store i64 %op1675, ptr %slot272, align 8
  %v1676 = load i64, ptr %slot272, align 8
  %cmp1677 = icmp ne i64 %v1676, 0
  %cv1678 = zext i1 %cmp1677 to i32
  store i32 %cv1678, ptr %slot273, align 8
  %v1679 = load i32, ptr %slot273, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcmoveslow534, label %bb_rcmovenext537
bb_rcmovenext537:
  %v1682 = load i64, ptr %slot264, align 8
  %v1683 = load i64, ptr %slot265, align 8
  %p1684 = inttoptr i64 %v1682 to ptr
  %p1685 = inttoptr i64 %v1683 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1685, ptr %p1684, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1686 = load i64, ptr %slot264, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i64 0, ptr %p1687, align 8, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot264, align 8
  %op1689 = add i64 %v1688, 8
  store i64 %op1689, ptr %slot274, align 8
  %v1690 = load i64, ptr %slot274, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i64 0, ptr %p1691, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved534
bb_rcmoveslow534:
  %v1692 = load i64, ptr %slot23, align 8
  %v1693 = load i64, ptr %slot265, align 8
  %v1694 = load i64, ptr %slot264, align 8
  %v1695 = load i64, ptr %slot266, align 8
  %cv1696 = trunc i64 %v1695 to i32
  %call1697 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1692, i64 %v1693, i64 %v1694, i32 %cv1696) nomerge, !dbg !144
  store i32 %call1697, ptr %slot275, align 8
  %v1698 = load i32, ptr %slot275, align 8
  %cv1699 = zext i32 %v1698 to i64
  %cond1700 = icmp ne i64 %cv1699, 0
  br i1 %cond1700, label %bb_rcsuccess545, label %bb_rcfailure545
bb_rcfailure545:
  %v1701 = load i64, ptr %slot23, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %call1703 = call i32 @myl_rc_take_failure(ptr %p1702) nomerge, !dbg !144
  store i32 %call1703, ptr %slot276, align 8
  %v1704 = load i64, ptr %slot1, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  %v1706 = load i32, ptr %slot276, align 8
  %call1707 = call i32 @myl_qbe_rc_status(ptr %p1705, i32 %v1706) nomerge, !dbg !144
  store i32 %call1707, ptr %slot277, align 8
  br label %bb_failure
bb_rcsuccess545:
  br label %bb_rcmoved534
bb_rcmoved534:
  %v1708 = load i64, ptr %slot6, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  store i32 0, ptr %p1709, align 4, !alias.scope !3, !noalias !4
  %v1710 = load i64, ptr %slot9, align 8
  %p1711 = inttoptr i64 %v1710 to ptr
  store i32 2, ptr %p1711, align 4, !alias.scope !3, !noalias !4
  %v1712 = load i64, ptr %slot8, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  store i32 1, ptr %p1713, align 4, !alias.scope !3, !noalias !4
  %v1714 = load i64, ptr %slot11, align 8
  store i64 %v1714, ptr %slot278, align 8
  %v1715 = load i64, ptr %slot8, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 0, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot6, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %ld1719 = load i32, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1719, ptr %slot279, align 8
  %v1720 = load i32, ptr %slot279, align 8
  %cv1721 = zext i32 %v1720 to i64
  %cond1722 = icmp ne i64 %cv1721, 0
  br i1 %cond1722, label %bb_rcslotdrop555, label %bb_rcslotdone555
bb_rcslotdrop555:
  %v1723 = load i64, ptr %slot6, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 0, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot10, align 8
  store i64 %v1725, ptr %slot280, align 8
  %v1726 = load i64, ptr %slot7, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %ld1728 = load i32, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1728, ptr %slot281, align 8
  %v1729 = load i32, ptr %slot281, align 8
  %op1730 = and i32 %v1729, 28
  store i32 %op1730, ptr %slot282, align 8
  %v1731 = load i32, ptr %slot282, align 8
  %cv1732 = zext i32 %v1731 to i64
  %cond1733 = icmp ne i64 %cv1732, 0
  br i1 %cond1733, label %bb_rcslotrole555, label %bb_rcslotowner555
bb_rcslotrole555:
  %v1734 = load i64, ptr %slot23, align 8
  store i64 %v1734, ptr %slot283, align 8
  %v1735 = load i64, ptr %slot283, align 8
  %v1736 = load i64, ptr %slot280, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1735, i64 %v1736) nomerge, !dbg !144
  br label %bb_rcslotdone555
bb_rcslotowner555:
  %v1737 = load i64, ptr %slot23, align 8
  store i64 %v1737, ptr %slot284, align 8
  %v1738 = load i64, ptr %slot284, align 8
  %v1739 = load i64, ptr %slot280, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1738, i64 %v1739) nomerge, !dbg !144
  br label %bb_rcslotdone555
bb_rcslotdone555:
  %v1740 = load i64, ptr %slot278, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  %ret1742 = load { i64, i64 }, ptr %p1741, align 8
  ret { i64, i64 } %ret1742
bb_i41:
  %v1743 = load i64, ptr %slot17, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i64 0, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot17, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  %ld1747 = load i64, ptr %p1746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1747, ptr %slot285, align 8
  %v1748 = load i64, ptr %slot285, align 8
  %cond1749 = icmp ne i64 %v1748, 0
  br i1 %cond1749, label %bb_success618, label %bb_failed618
bb_failed618:
  %v1750 = load i64, ptr %slot1, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  call void @myl_qbe_fail_assert(ptr %p1751) nomerge, !dbg !146
  unreachable
bb_success618:
  %v1752 = load i64, ptr %slot17, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i64 18446744073709551615, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot18, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i64 0, ptr %p1755, align 8, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot17, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %ld1758 = load i64, ptr %p1757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1758, ptr %slot286, align 8
  %v1759 = load i64, ptr %slot18, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %ld1761 = load i64, ptr %p1760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1761, ptr %slot287, align 8
  %v1762 = load i64, ptr %slot1, align 8
  %v1763 = load i64, ptr %slot286, align 8
  %v1764 = load i64, ptr %slot287, align 8
  %call1765 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v1762, i64 %v1763, i64 %v1764) nomerge, !dbg !148
  store { i64, i64 } %call1765, ptr %callresult289, align 8
  %addr1766 = ptrtoint ptr %callresult289 to i64
  store i64 %addr1766, ptr %slot288, align 8
  %v1767 = load i64, ptr %slot288, align 8
  %v1768 = load i64, ptr %slot17, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  store i64 %v1767, ptr %p1769, align 8, !alias.scope !3, !noalias !4
  %v1770 = load i64, ptr %slot17, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  %ld1772 = load i64, ptr %p1771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1772, ptr %slot290, align 8
  %v1773 = load i64, ptr %slot11, align 8
  store i64 %v1773, ptr %slot291, align 8
  %v1774 = load i64, ptr %slot290, align 8
  %v1775 = load i64, ptr %slot291, align 8
  %p1776 = inttoptr i64 %v1774 to ptr
  %p1777 = inttoptr i64 %v1775 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1777, ptr %p1776, i64 16, i1 false)
  %v1778 = load i64, ptr %slot9, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i32 2, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot8, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  store i32 1, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  %v1782 = load i64, ptr %slot10, align 8
  store i64 %v1782, ptr %slot292, align 8
  %v1783 = load i64, ptr %slot11, align 8
  store i64 %v1783, ptr %slot293, align 8
  %v1784 = load i64, ptr %slot293, align 8
  %v1785 = load i64, ptr %slot292, align 8
  %p1786 = inttoptr i64 %v1784 to ptr
  %p1787 = inttoptr i64 %v1785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1787, ptr %p1786, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1788 = load i64, ptr %slot7, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  store i32 2, ptr %p1789, align 4, !alias.scope !3, !noalias !4
  %v1790 = load i64, ptr %slot9, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %ld1792 = load i32, ptr %p1791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1792, ptr %slot294, align 8
  %v1793 = load i32, ptr %slot294, align 8
  %v1794 = load i64, ptr %slot7, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  store i32 %v1793, ptr %p1795, align 4, !alias.scope !3, !noalias !4
  %v1796 = load i64, ptr %slot8, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  store i32 0, ptr %p1797, align 4, !alias.scope !3, !noalias !4
  %v1798 = load i64, ptr %slot6, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  store i32 1, ptr %p1799, align 4, !alias.scope !3, !noalias !4
  %v1800 = load i64, ptr %slot292, align 8
  %v1801 = load i64, ptr %slot17, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i64 %v1800, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot17, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i64, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1805, ptr %slot295, align 8
  %v1806 = load i64, ptr %slot17, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  %ld1808 = load i64, ptr %p1807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1808, ptr %slot296, align 8
  %v1809 = load i64, ptr %slot11, align 8
  store i64 %v1809, ptr %slot297, align 8
  %v1810 = load i64, ptr %slot24, align 8
  store i64 %v1810, ptr %slot298, align 8
  %v1811 = load i64, ptr %slot296, align 8
  %op1812 = add i64 %v1811, 8
  store i64 %op1812, ptr %slot299, align 8
  %v1813 = load i64, ptr %slot299, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %ld1815 = load i64, ptr %p1814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1815, ptr %slot300, align 8
  %v1816 = load i64, ptr %slot300, align 8
  %cmp1817 = icmp ne i64 %v1816, 0
  %cv1818 = zext i1 %cmp1817 to i32
  store i32 %cv1818, ptr %slot301, align 8
  %v1819 = load i32, ptr %slot301, align 8
  %cv1820 = zext i32 %v1819 to i64
  %cond1821 = icmp ne i64 %cv1820, 0
  br i1 %cond1821, label %bb_rcmoveheader641, label %bb_rcmovenext641
bb_rcmoveheader641:
  %v1822 = load i64, ptr %slot300, align 8
  %op1823 = sub i64 %v1822, 16
  store i64 %op1823, ptr %slot302, align 8
  %v1824 = load i64, ptr %slot300, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  %rgep1826 = getelementptr i8, ptr %p1825, i64 -16
  %ld1827 = load i64, ptr %rgep1826, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1827, ptr %slot303, align 8
  %v1828 = load i64, ptr %slot303, align 8
  %op1829 = and i64 %v1828, 5764607523034234881
  store i64 %op1829, ptr %slot304, align 8
  %v1830 = load i64, ptr %slot304, align 8
  %cmp1831 = icmp ne i64 %v1830, 0
  %cv1832 = zext i1 %cmp1831 to i32
  store i32 %cv1832, ptr %slot305, align 8
  %v1833 = load i32, ptr %slot305, align 8
  %cv1834 = zext i32 %v1833 to i64
  %cond1835 = icmp ne i64 %cv1834, 0
  br i1 %cond1835, label %bb_rcmoveslow638, label %bb_rcmovenext641
bb_rcmovenext641:
  %v1836 = load i64, ptr %slot296, align 8
  %v1837 = load i64, ptr %slot297, align 8
  %p1838 = inttoptr i64 %v1836 to ptr
  %p1839 = inttoptr i64 %v1837 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1839, ptr %p1838, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1840 = load i64, ptr %slot296, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i64 0, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  %v1842 = load i64, ptr %slot296, align 8
  %op1843 = add i64 %v1842, 8
  store i64 %op1843, ptr %slot306, align 8
  %v1844 = load i64, ptr %slot306, align 8
  %p1845 = inttoptr i64 %v1844 to ptr
  store i64 0, ptr %p1845, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved638
bb_rcmoveslow638:
  %v1846 = load i64, ptr %slot23, align 8
  %v1847 = load i64, ptr %slot297, align 8
  %v1848 = load i64, ptr %slot296, align 8
  %v1849 = load i64, ptr %slot298, align 8
  %cv1850 = trunc i64 %v1849 to i32
  %call1851 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v1846, i64 %v1847, i64 %v1848, i32 %cv1850) nomerge, !dbg !150
  store i32 %call1851, ptr %slot307, align 8
  %v1852 = load i32, ptr %slot307, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcsuccess649, label %bb_rcfailure649
bb_rcfailure649:
  %v1855 = load i64, ptr %slot23, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %call1857 = call i32 @myl_rc_take_failure(ptr %p1856) nomerge, !dbg !150
  store i32 %call1857, ptr %slot308, align 8
  %v1858 = load i64, ptr %slot1, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %v1860 = load i32, ptr %slot308, align 8
  %call1861 = call i32 @myl_qbe_rc_status(ptr %p1859, i32 %v1860) nomerge, !dbg !150
  store i32 %call1861, ptr %slot309, align 8
  br label %bb_failure
bb_rcsuccess649:
  br label %bb_rcmoved638
bb_rcmoved638:
  %v1862 = load i64, ptr %slot6, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i32 0, ptr %p1863, align 4, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot9, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  store i32 2, ptr %p1865, align 4, !alias.scope !3, !noalias !4
  %v1866 = load i64, ptr %slot8, align 8
  %p1867 = inttoptr i64 %v1866 to ptr
  store i32 1, ptr %p1867, align 4, !alias.scope !3, !noalias !4
  %v1868 = load i64, ptr %slot11, align 8
  store i64 %v1868, ptr %slot310, align 8
  %v1869 = load i64, ptr %slot8, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  store i32 0, ptr %p1870, align 4, !alias.scope !3, !noalias !4
  %v1871 = load i64, ptr %slot6, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  %ld1873 = load i32, ptr %p1872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1873, ptr %slot311, align 8
  %v1874 = load i32, ptr %slot311, align 8
  %cv1875 = zext i32 %v1874 to i64
  %cond1876 = icmp ne i64 %cv1875, 0
  br i1 %cond1876, label %bb_rcslotdrop659, label %bb_rcslotdone659
bb_rcslotdrop659:
  %v1877 = load i64, ptr %slot6, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i32 0, ptr %p1878, align 4, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot10, align 8
  store i64 %v1879, ptr %slot312, align 8
  %v1880 = load i64, ptr %slot7, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %ld1882 = load i32, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1882, ptr %slot313, align 8
  %v1883 = load i32, ptr %slot313, align 8
  %op1884 = and i32 %v1883, 28
  store i32 %op1884, ptr %slot314, align 8
  %v1885 = load i32, ptr %slot314, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcslotrole659, label %bb_rcslotowner659
bb_rcslotrole659:
  %v1888 = load i64, ptr %slot23, align 8
  store i64 %v1888, ptr %slot315, align 8
  %v1889 = load i64, ptr %slot315, align 8
  %v1890 = load i64, ptr %slot312, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v1889, i64 %v1890) nomerge, !dbg !150
  br label %bb_rcslotdone659
bb_rcslotowner659:
  %v1891 = load i64, ptr %slot23, align 8
  store i64 %v1891, ptr %slot316, align 8
  %v1892 = load i64, ptr %slot316, align 8
  %v1893 = load i64, ptr %slot312, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v1892, i64 %v1893) nomerge, !dbg !150
  br label %bb_rcslotdone659
bb_rcslotdone659:
  %v1894 = load i64, ptr %slot310, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %ret1896 = load { i64, i64 }, ptr %p1895, align 8
  ret { i64, i64 } %ret1896
bb_i47:
  %v1897 = load i64, ptr %slot17, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  store i64 0, ptr %p1898, align 8, !alias.scope !3, !noalias !4
  %v1899 = load i64, ptr %slot17, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot317, align 8
  %v1902 = load i64, ptr %slot317, align 8
  %cond1903 = icmp ne i64 %v1902, 0
  br i1 %cond1903, label %bb_success722, label %bb_failed722
bb_failed722:
  %v1904 = load i64, ptr %slot1, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  call void @myl_qbe_fail_assert(ptr %p1905) nomerge, !dbg !152
  unreachable
bb_success722:
  %v1906 = load i64, ptr %slot17, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i64 18446744073709551615, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot18, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i64 0, ptr %p1909, align 8, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot17, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i64, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1912, ptr %slot318, align 8
  %v1913 = load i64, ptr %slot18, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i64, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1915, ptr %slot319, align 8
  %v1916 = load i64, ptr %slot1, align 8
  %v1917 = load i64, ptr %slot318, align 8
  %v1918 = load i64, ptr %slot319, align 8
  %call1919 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v1916, i64 %v1917, i64 %v1918) nomerge, !dbg !154
  store { i64, i64 } %call1919, ptr %callresult321, align 8
  %addr1920 = ptrtoint ptr %callresult321 to i64
  store i64 %addr1920, ptr %slot320, align 8
  %v1921 = load i64, ptr %slot320, align 8
  %v1922 = load i64, ptr %slot17, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i64 %v1921, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot17, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i64, ptr %p1925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1926, ptr %slot322, align 8
  %v1927 = load i64, ptr %slot11, align 8
  store i64 %v1927, ptr %slot323, align 8
  %v1928 = load i64, ptr %slot322, align 8
  %v1929 = load i64, ptr %slot323, align 8
  %p1930 = inttoptr i64 %v1928 to ptr
  %p1931 = inttoptr i64 %v1929 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1931, ptr %p1930, i64 16, i1 false)
  %v1932 = load i64, ptr %slot9, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i32 2, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot8, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i32 1, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot10, align 8
  store i64 %v1936, ptr %slot324, align 8
  %v1937 = load i64, ptr %slot11, align 8
  store i64 %v1937, ptr %slot325, align 8
  %v1938 = load i64, ptr %slot325, align 8
  %v1939 = load i64, ptr %slot324, align 8
  %p1940 = inttoptr i64 %v1938 to ptr
  %p1941 = inttoptr i64 %v1939 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1941, ptr %p1940, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot7, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i32 2, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot9, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %ld1946 = load i32, ptr %p1945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1946, ptr %slot326, align 8
  %v1947 = load i32, ptr %slot326, align 8
  %v1948 = load i64, ptr %slot7, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i32 %v1947, ptr %p1949, align 4, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot8, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  store i32 0, ptr %p1951, align 4, !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot6, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  store i32 1, ptr %p1953, align 4, !alias.scope !3, !noalias !4
  %v1954 = load i64, ptr %slot324, align 8
  %v1955 = load i64, ptr %slot17, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  store i64 %v1954, ptr %p1956, align 8, !alias.scope !3, !noalias !4
  %v1957 = load i64, ptr %slot17, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %ld1959 = load i64, ptr %p1958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1959, ptr %slot327, align 8
  %v1960 = load i64, ptr %slot17, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %ld1962 = load i64, ptr %p1961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1962, ptr %slot328, align 8
  %v1963 = load i64, ptr %slot11, align 8
  store i64 %v1963, ptr %slot329, align 8
  %v1964 = load i64, ptr %slot24, align 8
  store i64 %v1964, ptr %slot330, align 8
  %v1965 = load i64, ptr %slot328, align 8
  %op1966 = add i64 %v1965, 8
  store i64 %op1966, ptr %slot331, align 8
  %v1967 = load i64, ptr %slot331, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %ld1969 = load i64, ptr %p1968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1969, ptr %slot332, align 8
  %v1970 = load i64, ptr %slot332, align 8
  %cmp1971 = icmp ne i64 %v1970, 0
  %cv1972 = zext i1 %cmp1971 to i32
  store i32 %cv1972, ptr %slot333, align 8
  %v1973 = load i32, ptr %slot333, align 8
  %cv1974 = zext i32 %v1973 to i64
  %cond1975 = icmp ne i64 %cv1974, 0
  br i1 %cond1975, label %bb_rcmoveheader745, label %bb_rcmovenext745
bb_rcmoveheader745:
  %v1976 = load i64, ptr %slot332, align 8
  %op1977 = sub i64 %v1976, 16
  store i64 %op1977, ptr %slot334, align 8
  %v1978 = load i64, ptr %slot332, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  %rgep1980 = getelementptr i8, ptr %p1979, i64 -16
  %ld1981 = load i64, ptr %rgep1980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1981, ptr %slot335, align 8
  %v1982 = load i64, ptr %slot335, align 8
  %op1983 = and i64 %v1982, 5764607523034234881
  store i64 %op1983, ptr %slot336, align 8
  %v1984 = load i64, ptr %slot336, align 8
  %cmp1985 = icmp ne i64 %v1984, 0
  %cv1986 = zext i1 %cmp1985 to i32
  store i32 %cv1986, ptr %slot337, align 8
  %v1987 = load i32, ptr %slot337, align 8
  %cv1988 = zext i32 %v1987 to i64
  %cond1989 = icmp ne i64 %cv1988, 0
  br i1 %cond1989, label %bb_rcmoveslow742, label %bb_rcmovenext745
bb_rcmovenext745:
  %v1990 = load i64, ptr %slot328, align 8
  %v1991 = load i64, ptr %slot329, align 8
  %p1992 = inttoptr i64 %v1990 to ptr
  %p1993 = inttoptr i64 %v1991 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1993, ptr %p1992, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1994 = load i64, ptr %slot328, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 0, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot328, align 8
  %op1997 = add i64 %v1996, 8
  store i64 %op1997, ptr %slot338, align 8
  %v1998 = load i64, ptr %slot338, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i64 0, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved742
bb_rcmoveslow742:
  %v2000 = load i64, ptr %slot23, align 8
  %v2001 = load i64, ptr %slot329, align 8
  %v2002 = load i64, ptr %slot328, align 8
  %v2003 = load i64, ptr %slot330, align 8
  %cv2004 = trunc i64 %v2003 to i32
  %call2005 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2000, i64 %v2001, i64 %v2002, i32 %cv2004) nomerge, !dbg !156
  store i32 %call2005, ptr %slot339, align 8
  %v2006 = load i32, ptr %slot339, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcsuccess753, label %bb_rcfailure753
bb_rcfailure753:
  %v2009 = load i64, ptr %slot23, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %call2011 = call i32 @myl_rc_take_failure(ptr %p2010) nomerge, !dbg !156
  store i32 %call2011, ptr %slot340, align 8
  %v2012 = load i64, ptr %slot1, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %v2014 = load i32, ptr %slot340, align 8
  %call2015 = call i32 @myl_qbe_rc_status(ptr %p2013, i32 %v2014) nomerge, !dbg !156
  store i32 %call2015, ptr %slot341, align 8
  br label %bb_failure
bb_rcsuccess753:
  br label %bb_rcmoved742
bb_rcmoved742:
  %v2016 = load i64, ptr %slot6, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  store i32 0, ptr %p2017, align 4, !alias.scope !3, !noalias !4
  %v2018 = load i64, ptr %slot9, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i32 2, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot8, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  store i32 1, ptr %p2021, align 4, !alias.scope !3, !noalias !4
  %v2022 = load i64, ptr %slot11, align 8
  store i64 %v2022, ptr %slot342, align 8
  %v2023 = load i64, ptr %slot8, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i32 0, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot6, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i32, ptr %p2026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2027, ptr %slot343, align 8
  %v2028 = load i32, ptr %slot343, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcslotdrop763, label %bb_rcslotdone763
bb_rcslotdrop763:
  %v2031 = load i64, ptr %slot6, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i32 0, ptr %p2032, align 4, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot10, align 8
  store i64 %v2033, ptr %slot344, align 8
  %v2034 = load i64, ptr %slot7, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  %ld2036 = load i32, ptr %p2035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2036, ptr %slot345, align 8
  %v2037 = load i32, ptr %slot345, align 8
  %op2038 = and i32 %v2037, 28
  store i32 %op2038, ptr %slot346, align 8
  %v2039 = load i32, ptr %slot346, align 8
  %cv2040 = zext i32 %v2039 to i64
  %cond2041 = icmp ne i64 %cv2040, 0
  br i1 %cond2041, label %bb_rcslotrole763, label %bb_rcslotowner763
bb_rcslotrole763:
  %v2042 = load i64, ptr %slot23, align 8
  store i64 %v2042, ptr %slot347, align 8
  %v2043 = load i64, ptr %slot347, align 8
  %v2044 = load i64, ptr %slot344, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2043, i64 %v2044) nomerge, !dbg !156
  br label %bb_rcslotdone763
bb_rcslotowner763:
  %v2045 = load i64, ptr %slot23, align 8
  store i64 %v2045, ptr %slot348, align 8
  %v2046 = load i64, ptr %slot348, align 8
  %v2047 = load i64, ptr %slot344, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2046, i64 %v2047) nomerge, !dbg !156
  br label %bb_rcslotdone763
bb_rcslotdone763:
  %v2048 = load i64, ptr %slot342, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  %ret2050 = load { i64, i64 }, ptr %p2049, align 8
  ret { i64, i64 } %ret2050
bb_i53:
  %v2051 = load i64, ptr %slot17, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  store i64 0, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  %v2053 = load i64, ptr %slot17, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %ld2055 = load i64, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2055, ptr %slot349, align 8
  %v2056 = load i64, ptr %slot349, align 8
  %cond2057 = icmp ne i64 %v2056, 0
  br i1 %cond2057, label %bb_success826, label %bb_failed826
bb_failed826:
  %v2058 = load i64, ptr %slot1, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  call void @myl_qbe_fail_assert(ptr %p2059) nomerge, !dbg !158
  unreachable
bb_success826:
  %v2060 = load i64, ptr %slot17, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  store i64 18446744073709551615, ptr %p2061, align 8, !alias.scope !3, !noalias !4
  %v2062 = load i64, ptr %slot18, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  store i64 0, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  %v2064 = load i64, ptr %slot17, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  %ld2066 = load i64, ptr %p2065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2066, ptr %slot350, align 8
  %v2067 = load i64, ptr %slot18, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i64, ptr %p2068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2069, ptr %slot351, align 8
  %v2070 = load i64, ptr %slot1, align 8
  %v2071 = load i64, ptr %slot350, align 8
  %v2072 = load i64, ptr %slot351, align 8
  %call2073 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v2070, i64 %v2071, i64 %v2072) nomerge, !dbg !160
  store { i64, i64 } %call2073, ptr %callresult353, align 8
  %addr2074 = ptrtoint ptr %callresult353 to i64
  store i64 %addr2074, ptr %slot352, align 8
  %v2075 = load i64, ptr %slot352, align 8
  %v2076 = load i64, ptr %slot17, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i64 %v2075, ptr %p2077, align 8, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot17, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  %ld2080 = load i64, ptr %p2079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2080, ptr %slot354, align 8
  %v2081 = load i64, ptr %slot11, align 8
  store i64 %v2081, ptr %slot355, align 8
  %v2082 = load i64, ptr %slot354, align 8
  %v2083 = load i64, ptr %slot355, align 8
  %p2084 = inttoptr i64 %v2082 to ptr
  %p2085 = inttoptr i64 %v2083 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2085, ptr %p2084, i64 16, i1 false)
  %v2086 = load i64, ptr %slot9, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 2, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot8, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  store i32 1, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  %v2090 = load i64, ptr %slot10, align 8
  store i64 %v2090, ptr %slot356, align 8
  %v2091 = load i64, ptr %slot11, align 8
  store i64 %v2091, ptr %slot357, align 8
  %v2092 = load i64, ptr %slot357, align 8
  %v2093 = load i64, ptr %slot356, align 8
  %p2094 = inttoptr i64 %v2092 to ptr
  %p2095 = inttoptr i64 %v2093 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2095, ptr %p2094, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot7, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 2, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot9, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i32, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2100, ptr %slot358, align 8
  %v2101 = load i32, ptr %slot358, align 8
  %v2102 = load i64, ptr %slot7, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i32 %v2101, ptr %p2103, align 4, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot8, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 0, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot6, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 1, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot356, align 8
  %v2109 = load i64, ptr %slot17, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i64 %v2108, ptr %p2110, align 8, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot17, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  %ld2113 = load i64, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2113, ptr %slot359, align 8
  %v2114 = load i64, ptr %slot17, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i64, ptr %p2115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2116, ptr %slot360, align 8
  %v2117 = load i64, ptr %slot11, align 8
  store i64 %v2117, ptr %slot361, align 8
  %v2118 = load i64, ptr %slot24, align 8
  store i64 %v2118, ptr %slot362, align 8
  %v2119 = load i64, ptr %slot360, align 8
  %op2120 = add i64 %v2119, 8
  store i64 %op2120, ptr %slot363, align 8
  %v2121 = load i64, ptr %slot363, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  %ld2123 = load i64, ptr %p2122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2123, ptr %slot364, align 8
  %v2124 = load i64, ptr %slot364, align 8
  %cmp2125 = icmp ne i64 %v2124, 0
  %cv2126 = zext i1 %cmp2125 to i32
  store i32 %cv2126, ptr %slot365, align 8
  %v2127 = load i32, ptr %slot365, align 8
  %cv2128 = zext i32 %v2127 to i64
  %cond2129 = icmp ne i64 %cv2128, 0
  br i1 %cond2129, label %bb_rcmoveheader849, label %bb_rcmovenext849
bb_rcmoveheader849:
  %v2130 = load i64, ptr %slot364, align 8
  %op2131 = sub i64 %v2130, 16
  store i64 %op2131, ptr %slot366, align 8
  %v2132 = load i64, ptr %slot364, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %rgep2134 = getelementptr i8, ptr %p2133, i64 -16
  %ld2135 = load i64, ptr %rgep2134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2135, ptr %slot367, align 8
  %v2136 = load i64, ptr %slot367, align 8
  %op2137 = and i64 %v2136, 5764607523034234881
  store i64 %op2137, ptr %slot368, align 8
  %v2138 = load i64, ptr %slot368, align 8
  %cmp2139 = icmp ne i64 %v2138, 0
  %cv2140 = zext i1 %cmp2139 to i32
  store i32 %cv2140, ptr %slot369, align 8
  %v2141 = load i32, ptr %slot369, align 8
  %cv2142 = zext i32 %v2141 to i64
  %cond2143 = icmp ne i64 %cv2142, 0
  br i1 %cond2143, label %bb_rcmoveslow846, label %bb_rcmovenext849
bb_rcmovenext849:
  %v2144 = load i64, ptr %slot360, align 8
  %v2145 = load i64, ptr %slot361, align 8
  %p2146 = inttoptr i64 %v2144 to ptr
  %p2147 = inttoptr i64 %v2145 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2147, ptr %p2146, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot360, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  store i64 0, ptr %p2149, align 8, !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot360, align 8
  %op2151 = add i64 %v2150, 8
  store i64 %op2151, ptr %slot370, align 8
  %v2152 = load i64, ptr %slot370, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  store i64 0, ptr %p2153, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved846
bb_rcmoveslow846:
  %v2154 = load i64, ptr %slot23, align 8
  %v2155 = load i64, ptr %slot361, align 8
  %v2156 = load i64, ptr %slot360, align 8
  %v2157 = load i64, ptr %slot362, align 8
  %cv2158 = trunc i64 %v2157 to i32
  %call2159 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2154, i64 %v2155, i64 %v2156, i32 %cv2158) nomerge, !dbg !162
  store i32 %call2159, ptr %slot371, align 8
  %v2160 = load i32, ptr %slot371, align 8
  %cv2161 = zext i32 %v2160 to i64
  %cond2162 = icmp ne i64 %cv2161, 0
  br i1 %cond2162, label %bb_rcsuccess857, label %bb_rcfailure857
bb_rcfailure857:
  %v2163 = load i64, ptr %slot23, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %call2165 = call i32 @myl_rc_take_failure(ptr %p2164) nomerge, !dbg !162
  store i32 %call2165, ptr %slot372, align 8
  %v2166 = load i64, ptr %slot1, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %v2168 = load i32, ptr %slot372, align 8
  %call2169 = call i32 @myl_qbe_rc_status(ptr %p2167, i32 %v2168) nomerge, !dbg !162
  store i32 %call2169, ptr %slot373, align 8
  br label %bb_failure
bb_rcsuccess857:
  br label %bb_rcmoved846
bb_rcmoved846:
  %v2170 = load i64, ptr %slot6, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  store i32 0, ptr %p2171, align 4, !alias.scope !3, !noalias !4
  %v2172 = load i64, ptr %slot9, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  store i32 2, ptr %p2173, align 4, !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot8, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 1, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot11, align 8
  store i64 %v2176, ptr %slot374, align 8
  %v2177 = load i64, ptr %slot8, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  store i32 0, ptr %p2178, align 4, !alias.scope !3, !noalias !4
  %v2179 = load i64, ptr %slot6, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %ld2181 = load i32, ptr %p2180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2181, ptr %slot375, align 8
  %v2182 = load i32, ptr %slot375, align 8
  %cv2183 = zext i32 %v2182 to i64
  %cond2184 = icmp ne i64 %cv2183, 0
  br i1 %cond2184, label %bb_rcslotdrop867, label %bb_rcslotdone867
bb_rcslotdrop867:
  %v2185 = load i64, ptr %slot6, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 0, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot10, align 8
  store i64 %v2187, ptr %slot376, align 8
  %v2188 = load i64, ptr %slot7, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  %ld2190 = load i32, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2190, ptr %slot377, align 8
  %v2191 = load i32, ptr %slot377, align 8
  %op2192 = and i32 %v2191, 28
  store i32 %op2192, ptr %slot378, align 8
  %v2193 = load i32, ptr %slot378, align 8
  %cv2194 = zext i32 %v2193 to i64
  %cond2195 = icmp ne i64 %cv2194, 0
  br i1 %cond2195, label %bb_rcslotrole867, label %bb_rcslotowner867
bb_rcslotrole867:
  %v2196 = load i64, ptr %slot23, align 8
  store i64 %v2196, ptr %slot379, align 8
  %v2197 = load i64, ptr %slot379, align 8
  %v2198 = load i64, ptr %slot376, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2197, i64 %v2198) nomerge, !dbg !162
  br label %bb_rcslotdone867
bb_rcslotowner867:
  %v2199 = load i64, ptr %slot23, align 8
  store i64 %v2199, ptr %slot380, align 8
  %v2200 = load i64, ptr %slot380, align 8
  %v2201 = load i64, ptr %slot376, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2200, i64 %v2201) nomerge, !dbg !162
  br label %bb_rcslotdone867
bb_rcslotdone867:
  %v2202 = load i64, ptr %slot374, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ret2204 = load { i64, i64 }, ptr %p2203, align 8
  ret { i64, i64 } %ret2204
bb_i59:
  %v2205 = load i64, ptr %slot17, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i64 0, ptr %p2206, align 8, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot17, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %ld2209 = load i64, ptr %p2208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2209, ptr %slot381, align 8
  %v2210 = load i64, ptr %slot381, align 8
  %cond2211 = icmp ne i64 %v2210, 0
  br i1 %cond2211, label %bb_success930, label %bb_failed930
bb_failed930:
  %v2212 = load i64, ptr %slot1, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  call void @myl_qbe_fail_assert(ptr %p2213) nomerge, !dbg !164
  unreachable
bb_success930:
  %v2214 = load i64, ptr %slot17, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  store i64 18446744073709551615, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  %v2216 = load i64, ptr %slot18, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i64 0, ptr %p2217, align 8, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot17, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %ld2220 = load i64, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2220, ptr %slot382, align 8
  %v2221 = load i64, ptr %slot18, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  %ld2223 = load i64, ptr %p2222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2223, ptr %slot383, align 8
  %v2224 = load i64, ptr %slot1, align 8
  %v2225 = load i64, ptr %slot382, align 8
  %v2226 = load i64, ptr %slot383, align 8
  %call2227 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v2224, i64 %v2225, i64 %v2226) nomerge, !dbg !166
  store { i64, i64 } %call2227, ptr %callresult385, align 8
  %addr2228 = ptrtoint ptr %callresult385 to i64
  store i64 %addr2228, ptr %slot384, align 8
  %v2229 = load i64, ptr %slot384, align 8
  %v2230 = load i64, ptr %slot17, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  store i64 %v2229, ptr %p2231, align 8, !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot17, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  %ld2234 = load i64, ptr %p2233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2234, ptr %slot386, align 8
  %v2235 = load i64, ptr %slot11, align 8
  store i64 %v2235, ptr %slot387, align 8
  %v2236 = load i64, ptr %slot386, align 8
  %v2237 = load i64, ptr %slot387, align 8
  %p2238 = inttoptr i64 %v2236 to ptr
  %p2239 = inttoptr i64 %v2237 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2239, ptr %p2238, i64 16, i1 false)
  %v2240 = load i64, ptr %slot9, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  store i32 2, ptr %p2241, align 4, !alias.scope !3, !noalias !4
  %v2242 = load i64, ptr %slot8, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i32 1, ptr %p2243, align 4, !alias.scope !3, !noalias !4
  %v2244 = load i64, ptr %slot10, align 8
  store i64 %v2244, ptr %slot388, align 8
  %v2245 = load i64, ptr %slot11, align 8
  store i64 %v2245, ptr %slot389, align 8
  %v2246 = load i64, ptr %slot389, align 8
  %v2247 = load i64, ptr %slot388, align 8
  %p2248 = inttoptr i64 %v2246 to ptr
  %p2249 = inttoptr i64 %v2247 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2249, ptr %p2248, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2250 = load i64, ptr %slot7, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i32 2, ptr %p2251, align 4, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot9, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %ld2254 = load i32, ptr %p2253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2254, ptr %slot390, align 8
  %v2255 = load i32, ptr %slot390, align 8
  %v2256 = load i64, ptr %slot7, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i32 %v2255, ptr %p2257, align 4, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot8, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  store i32 0, ptr %p2259, align 4, !alias.scope !3, !noalias !4
  %v2260 = load i64, ptr %slot6, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  store i32 1, ptr %p2261, align 4, !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot388, align 8
  %v2263 = load i64, ptr %slot17, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 %v2262, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot17, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot391, align 8
  %v2268 = load i64, ptr %slot17, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %ld2270 = load i64, ptr %p2269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2270, ptr %slot392, align 8
  %v2271 = load i64, ptr %slot11, align 8
  store i64 %v2271, ptr %slot393, align 8
  %v2272 = load i64, ptr %slot24, align 8
  store i64 %v2272, ptr %slot394, align 8
  %v2273 = load i64, ptr %slot392, align 8
  %op2274 = add i64 %v2273, 8
  store i64 %op2274, ptr %slot395, align 8
  %v2275 = load i64, ptr %slot395, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %ld2277 = load i64, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2277, ptr %slot396, align 8
  %v2278 = load i64, ptr %slot396, align 8
  %cmp2279 = icmp ne i64 %v2278, 0
  %cv2280 = zext i1 %cmp2279 to i32
  store i32 %cv2280, ptr %slot397, align 8
  %v2281 = load i32, ptr %slot397, align 8
  %cv2282 = zext i32 %v2281 to i64
  %cond2283 = icmp ne i64 %cv2282, 0
  br i1 %cond2283, label %bb_rcmoveheader953, label %bb_rcmovenext953
bb_rcmoveheader953:
  %v2284 = load i64, ptr %slot396, align 8
  %op2285 = sub i64 %v2284, 16
  store i64 %op2285, ptr %slot398, align 8
  %v2286 = load i64, ptr %slot396, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %rgep2288 = getelementptr i8, ptr %p2287, i64 -16
  %ld2289 = load i64, ptr %rgep2288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2289, ptr %slot399, align 8
  %v2290 = load i64, ptr %slot399, align 8
  %op2291 = and i64 %v2290, 5764607523034234881
  store i64 %op2291, ptr %slot400, align 8
  %v2292 = load i64, ptr %slot400, align 8
  %cmp2293 = icmp ne i64 %v2292, 0
  %cv2294 = zext i1 %cmp2293 to i32
  store i32 %cv2294, ptr %slot401, align 8
  %v2295 = load i32, ptr %slot401, align 8
  %cv2296 = zext i32 %v2295 to i64
  %cond2297 = icmp ne i64 %cv2296, 0
  br i1 %cond2297, label %bb_rcmoveslow950, label %bb_rcmovenext953
bb_rcmovenext953:
  %v2298 = load i64, ptr %slot392, align 8
  %v2299 = load i64, ptr %slot393, align 8
  %p2300 = inttoptr i64 %v2298 to ptr
  %p2301 = inttoptr i64 %v2299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2301, ptr %p2300, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2302 = load i64, ptr %slot392, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  store i64 0, ptr %p2303, align 8, !alias.scope !3, !noalias !4
  %v2304 = load i64, ptr %slot392, align 8
  %op2305 = add i64 %v2304, 8
  store i64 %op2305, ptr %slot402, align 8
  %v2306 = load i64, ptr %slot402, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  store i64 0, ptr %p2307, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved950
bb_rcmoveslow950:
  %v2308 = load i64, ptr %slot23, align 8
  %v2309 = load i64, ptr %slot393, align 8
  %v2310 = load i64, ptr %slot392, align 8
  %v2311 = load i64, ptr %slot394, align 8
  %cv2312 = trunc i64 %v2311 to i32
  %call2313 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2308, i64 %v2309, i64 %v2310, i32 %cv2312) nomerge, !dbg !168
  store i32 %call2313, ptr %slot403, align 8
  %v2314 = load i32, ptr %slot403, align 8
  %cv2315 = zext i32 %v2314 to i64
  %cond2316 = icmp ne i64 %cv2315, 0
  br i1 %cond2316, label %bb_rcsuccess961, label %bb_rcfailure961
bb_rcfailure961:
  %v2317 = load i64, ptr %slot23, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %call2319 = call i32 @myl_rc_take_failure(ptr %p2318) nomerge, !dbg !168
  store i32 %call2319, ptr %slot404, align 8
  %v2320 = load i64, ptr %slot1, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  %v2322 = load i32, ptr %slot404, align 8
  %call2323 = call i32 @myl_qbe_rc_status(ptr %p2321, i32 %v2322) nomerge, !dbg !168
  store i32 %call2323, ptr %slot405, align 8
  br label %bb_failure
bb_rcsuccess961:
  br label %bb_rcmoved950
bb_rcmoved950:
  %v2324 = load i64, ptr %slot6, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  store i32 0, ptr %p2325, align 4, !alias.scope !3, !noalias !4
  %v2326 = load i64, ptr %slot9, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  store i32 2, ptr %p2327, align 4, !alias.scope !3, !noalias !4
  %v2328 = load i64, ptr %slot8, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  store i32 1, ptr %p2329, align 4, !alias.scope !3, !noalias !4
  %v2330 = load i64, ptr %slot11, align 8
  store i64 %v2330, ptr %slot406, align 8
  %v2331 = load i64, ptr %slot8, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 0, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot6, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i32, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2335, ptr %slot407, align 8
  %v2336 = load i32, ptr %slot407, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotdrop971, label %bb_rcslotdone971
bb_rcslotdrop971:
  %v2339 = load i64, ptr %slot6, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  store i32 0, ptr %p2340, align 4, !alias.scope !3, !noalias !4
  %v2341 = load i64, ptr %slot10, align 8
  store i64 %v2341, ptr %slot408, align 8
  %v2342 = load i64, ptr %slot7, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i32, ptr %p2343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2344, ptr %slot409, align 8
  %v2345 = load i32, ptr %slot409, align 8
  %op2346 = and i32 %v2345, 28
  store i32 %op2346, ptr %slot410, align 8
  %v2347 = load i32, ptr %slot410, align 8
  %cv2348 = zext i32 %v2347 to i64
  %cond2349 = icmp ne i64 %cv2348, 0
  br i1 %cond2349, label %bb_rcslotrole971, label %bb_rcslotowner971
bb_rcslotrole971:
  %v2350 = load i64, ptr %slot23, align 8
  store i64 %v2350, ptr %slot411, align 8
  %v2351 = load i64, ptr %slot411, align 8
  %v2352 = load i64, ptr %slot408, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2351, i64 %v2352) nomerge, !dbg !168
  br label %bb_rcslotdone971
bb_rcslotowner971:
  %v2353 = load i64, ptr %slot23, align 8
  store i64 %v2353, ptr %slot412, align 8
  %v2354 = load i64, ptr %slot412, align 8
  %v2355 = load i64, ptr %slot408, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2354, i64 %v2355) nomerge, !dbg !168
  br label %bb_rcslotdone971
bb_rcslotdone971:
  %v2356 = load i64, ptr %slot406, align 8
  %p2357 = inttoptr i64 %v2356 to ptr
  %ret2358 = load { i64, i64 }, ptr %p2357, align 8
  ret { i64, i64 } %ret2358
bb_i65:
  %v2359 = load i64, ptr %slot17, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  store i64 0, ptr %p2360, align 8, !alias.scope !3, !noalias !4
  %v2361 = load i64, ptr %slot17, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %ld2363 = load i64, ptr %p2362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2363, ptr %slot413, align 8
  %v2364 = load i64, ptr %slot413, align 8
  %cond2365 = icmp ne i64 %v2364, 0
  br i1 %cond2365, label %bb_success1034, label %bb_failed1034
bb_failed1034:
  %v2366 = load i64, ptr %slot1, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  call void @myl_qbe_fail_assert(ptr %p2367) nomerge, !dbg !170
  unreachable
bb_success1034:
  %v2368 = load i64, ptr %slot17, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  store i64 18446744073709551615, ptr %p2369, align 8, !alias.scope !3, !noalias !4
  %v2370 = load i64, ptr %slot18, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 0, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot17, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %ld2374 = load i64, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2374, ptr %slot414, align 8
  %v2375 = load i64, ptr %slot18, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %ld2377 = load i64, ptr %p2376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2377, ptr %slot415, align 8
  %v2378 = load i64, ptr %slot1, align 8
  %v2379 = load i64, ptr %slot414, align 8
  %v2380 = load i64, ptr %slot415, align 8
  %call2381 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v2378, i64 %v2379, i64 %v2380) nomerge, !dbg !172
  store { i64, i64 } %call2381, ptr %callresult417, align 8
  %addr2382 = ptrtoint ptr %callresult417 to i64
  store i64 %addr2382, ptr %slot416, align 8
  %v2383 = load i64, ptr %slot416, align 8
  %v2384 = load i64, ptr %slot17, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  store i64 %v2383, ptr %p2385, align 8, !alias.scope !3, !noalias !4
  %v2386 = load i64, ptr %slot17, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %ld2388 = load i64, ptr %p2387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2388, ptr %slot418, align 8
  %v2389 = load i64, ptr %slot11, align 8
  store i64 %v2389, ptr %slot419, align 8
  %v2390 = load i64, ptr %slot418, align 8
  %v2391 = load i64, ptr %slot419, align 8
  %p2392 = inttoptr i64 %v2390 to ptr
  %p2393 = inttoptr i64 %v2391 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2393, ptr %p2392, i64 16, i1 false)
  %v2394 = load i64, ptr %slot9, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  store i32 2, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  %v2396 = load i64, ptr %slot8, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  store i32 1, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  %v2398 = load i64, ptr %slot10, align 8
  store i64 %v2398, ptr %slot420, align 8
  %v2399 = load i64, ptr %slot11, align 8
  store i64 %v2399, ptr %slot421, align 8
  %v2400 = load i64, ptr %slot421, align 8
  %v2401 = load i64, ptr %slot420, align 8
  %p2402 = inttoptr i64 %v2400 to ptr
  %p2403 = inttoptr i64 %v2401 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2403, ptr %p2402, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2404 = load i64, ptr %slot7, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i32 2, ptr %p2405, align 4, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot9, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  %ld2408 = load i32, ptr %p2407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2408, ptr %slot422, align 8
  %v2409 = load i32, ptr %slot422, align 8
  %v2410 = load i64, ptr %slot7, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  store i32 %v2409, ptr %p2411, align 4, !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot8, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i32 0, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  %v2414 = load i64, ptr %slot6, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  store i32 1, ptr %p2415, align 4, !alias.scope !3, !noalias !4
  %v2416 = load i64, ptr %slot420, align 8
  %v2417 = load i64, ptr %slot17, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  store i64 %v2416, ptr %p2418, align 8, !alias.scope !3, !noalias !4
  %v2419 = load i64, ptr %slot17, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i64, ptr %p2420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2421, ptr %slot423, align 8
  %v2422 = load i64, ptr %slot17, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %ld2424 = load i64, ptr %p2423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2424, ptr %slot424, align 8
  %v2425 = load i64, ptr %slot11, align 8
  store i64 %v2425, ptr %slot425, align 8
  %v2426 = load i64, ptr %slot24, align 8
  store i64 %v2426, ptr %slot426, align 8
  %v2427 = load i64, ptr %slot424, align 8
  %op2428 = add i64 %v2427, 8
  store i64 %op2428, ptr %slot427, align 8
  %v2429 = load i64, ptr %slot427, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  %ld2431 = load i64, ptr %p2430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2431, ptr %slot428, align 8
  %v2432 = load i64, ptr %slot428, align 8
  %cmp2433 = icmp ne i64 %v2432, 0
  %cv2434 = zext i1 %cmp2433 to i32
  store i32 %cv2434, ptr %slot429, align 8
  %v2435 = load i32, ptr %slot429, align 8
  %cv2436 = zext i32 %v2435 to i64
  %cond2437 = icmp ne i64 %cv2436, 0
  br i1 %cond2437, label %bb_rcmoveheader1057, label %bb_rcmovenext1057
bb_rcmoveheader1057:
  %v2438 = load i64, ptr %slot428, align 8
  %op2439 = sub i64 %v2438, 16
  store i64 %op2439, ptr %slot430, align 8
  %v2440 = load i64, ptr %slot428, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  %rgep2442 = getelementptr i8, ptr %p2441, i64 -16
  %ld2443 = load i64, ptr %rgep2442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2443, ptr %slot431, align 8
  %v2444 = load i64, ptr %slot431, align 8
  %op2445 = and i64 %v2444, 5764607523034234881
  store i64 %op2445, ptr %slot432, align 8
  %v2446 = load i64, ptr %slot432, align 8
  %cmp2447 = icmp ne i64 %v2446, 0
  %cv2448 = zext i1 %cmp2447 to i32
  store i32 %cv2448, ptr %slot433, align 8
  %v2449 = load i32, ptr %slot433, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcmoveslow1054, label %bb_rcmovenext1057
bb_rcmovenext1057:
  %v2452 = load i64, ptr %slot424, align 8
  %v2453 = load i64, ptr %slot425, align 8
  %p2454 = inttoptr i64 %v2452 to ptr
  %p2455 = inttoptr i64 %v2453 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2455, ptr %p2454, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2456 = load i64, ptr %slot424, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  store i64 0, ptr %p2457, align 8, !alias.scope !3, !noalias !4
  %v2458 = load i64, ptr %slot424, align 8
  %op2459 = add i64 %v2458, 8
  store i64 %op2459, ptr %slot434, align 8
  %v2460 = load i64, ptr %slot434, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i64 0, ptr %p2461, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1054
bb_rcmoveslow1054:
  %v2462 = load i64, ptr %slot23, align 8
  %v2463 = load i64, ptr %slot425, align 8
  %v2464 = load i64, ptr %slot424, align 8
  %v2465 = load i64, ptr %slot426, align 8
  %cv2466 = trunc i64 %v2465 to i32
  %call2467 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2462, i64 %v2463, i64 %v2464, i32 %cv2466) nomerge, !dbg !174
  store i32 %call2467, ptr %slot435, align 8
  %v2468 = load i32, ptr %slot435, align 8
  %cv2469 = zext i32 %v2468 to i64
  %cond2470 = icmp ne i64 %cv2469, 0
  br i1 %cond2470, label %bb_rcsuccess1065, label %bb_rcfailure1065
bb_rcfailure1065:
  %v2471 = load i64, ptr %slot23, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %call2473 = call i32 @myl_rc_take_failure(ptr %p2472) nomerge, !dbg !174
  store i32 %call2473, ptr %slot436, align 8
  %v2474 = load i64, ptr %slot1, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %v2476 = load i32, ptr %slot436, align 8
  %call2477 = call i32 @myl_qbe_rc_status(ptr %p2475, i32 %v2476) nomerge, !dbg !174
  store i32 %call2477, ptr %slot437, align 8
  br label %bb_failure
bb_rcsuccess1065:
  br label %bb_rcmoved1054
bb_rcmoved1054:
  %v2478 = load i64, ptr %slot6, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  store i32 0, ptr %p2479, align 4, !alias.scope !3, !noalias !4
  %v2480 = load i64, ptr %slot9, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  store i32 2, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot8, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i32 1, ptr %p2483, align 4, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot11, align 8
  store i64 %v2484, ptr %slot438, align 8
  %v2485 = load i64, ptr %slot8, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  store i32 0, ptr %p2486, align 4, !alias.scope !3, !noalias !4
  %v2487 = load i64, ptr %slot6, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %ld2489 = load i32, ptr %p2488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2489, ptr %slot439, align 8
  %v2490 = load i32, ptr %slot439, align 8
  %cv2491 = zext i32 %v2490 to i64
  %cond2492 = icmp ne i64 %cv2491, 0
  br i1 %cond2492, label %bb_rcslotdrop1075, label %bb_rcslotdone1075
bb_rcslotdrop1075:
  %v2493 = load i64, ptr %slot6, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  store i32 0, ptr %p2494, align 4, !alias.scope !3, !noalias !4
  %v2495 = load i64, ptr %slot10, align 8
  store i64 %v2495, ptr %slot440, align 8
  %v2496 = load i64, ptr %slot7, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  %ld2498 = load i32, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2498, ptr %slot441, align 8
  %v2499 = load i32, ptr %slot441, align 8
  %op2500 = and i32 %v2499, 28
  store i32 %op2500, ptr %slot442, align 8
  %v2501 = load i32, ptr %slot442, align 8
  %cv2502 = zext i32 %v2501 to i64
  %cond2503 = icmp ne i64 %cv2502, 0
  br i1 %cond2503, label %bb_rcslotrole1075, label %bb_rcslotowner1075
bb_rcslotrole1075:
  %v2504 = load i64, ptr %slot23, align 8
  store i64 %v2504, ptr %slot443, align 8
  %v2505 = load i64, ptr %slot443, align 8
  %v2506 = load i64, ptr %slot440, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2505, i64 %v2506) nomerge, !dbg !174
  br label %bb_rcslotdone1075
bb_rcslotowner1075:
  %v2507 = load i64, ptr %slot23, align 8
  store i64 %v2507, ptr %slot444, align 8
  %v2508 = load i64, ptr %slot444, align 8
  %v2509 = load i64, ptr %slot440, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2508, i64 %v2509) nomerge, !dbg !174
  br label %bb_rcslotdone1075
bb_rcslotdone1075:
  %v2510 = load i64, ptr %slot438, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %ret2512 = load { i64, i64 }, ptr %p2511, align 8
  ret { i64, i64 } %ret2512
bb_i71:
  %v2513 = load i64, ptr %slot17, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i64 0, ptr %p2514, align 8, !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot17, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  %ld2517 = load i64, ptr %p2516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2517, ptr %slot445, align 8
  %v2518 = load i64, ptr %slot445, align 8
  %cond2519 = icmp ne i64 %v2518, 0
  br i1 %cond2519, label %bb_success1138, label %bb_failed1138
bb_failed1138:
  %v2520 = load i64, ptr %slot1, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  call void @myl_qbe_fail_assert(ptr %p2521) nomerge, !dbg !176
  unreachable
bb_success1138:
  %v2522 = load i64, ptr %slot17, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i64 18446744073709551615, ptr %p2523, align 8, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot18, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  store i64 0, ptr %p2525, align 8, !alias.scope !3, !noalias !4
  %v2526 = load i64, ptr %slot17, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %ld2528 = load i64, ptr %p2527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2528, ptr %slot446, align 8
  %v2529 = load i64, ptr %slot18, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i64, ptr %p2530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2531, ptr %slot447, align 8
  %v2532 = load i64, ptr %slot1, align 8
  %v2533 = load i64, ptr %slot446, align 8
  %v2534 = load i64, ptr %slot447, align 8
  %call2535 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v2532, i64 %v2533, i64 %v2534) nomerge, !dbg !178
  store { i64, i64 } %call2535, ptr %callresult449, align 8
  %addr2536 = ptrtoint ptr %callresult449 to i64
  store i64 %addr2536, ptr %slot448, align 8
  %v2537 = load i64, ptr %slot448, align 8
  %v2538 = load i64, ptr %slot17, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  store i64 %v2537, ptr %p2539, align 8, !alias.scope !3, !noalias !4
  %v2540 = load i64, ptr %slot17, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i64, ptr %p2541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2542, ptr %slot450, align 8
  %v2543 = load i64, ptr %slot11, align 8
  store i64 %v2543, ptr %slot451, align 8
  %v2544 = load i64, ptr %slot450, align 8
  %v2545 = load i64, ptr %slot451, align 8
  %p2546 = inttoptr i64 %v2544 to ptr
  %p2547 = inttoptr i64 %v2545 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2547, ptr %p2546, i64 16, i1 false)
  %v2548 = load i64, ptr %slot9, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  store i32 2, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  %v2550 = load i64, ptr %slot8, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  store i32 1, ptr %p2551, align 4, !alias.scope !3, !noalias !4
  %v2552 = load i64, ptr %slot10, align 8
  store i64 %v2552, ptr %slot452, align 8
  %v2553 = load i64, ptr %slot11, align 8
  store i64 %v2553, ptr %slot453, align 8
  %v2554 = load i64, ptr %slot453, align 8
  %v2555 = load i64, ptr %slot452, align 8
  %p2556 = inttoptr i64 %v2554 to ptr
  %p2557 = inttoptr i64 %v2555 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2557, ptr %p2556, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2558 = load i64, ptr %slot7, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i32 2, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  %v2560 = load i64, ptr %slot9, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot454, align 8
  %v2563 = load i32, ptr %slot454, align 8
  %v2564 = load i64, ptr %slot7, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  store i32 %v2563, ptr %p2565, align 4, !alias.scope !3, !noalias !4
  %v2566 = load i64, ptr %slot8, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i32 0, ptr %p2567, align 4, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot6, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  store i32 1, ptr %p2569, align 4, !alias.scope !3, !noalias !4
  %v2570 = load i64, ptr %slot452, align 8
  %v2571 = load i64, ptr %slot17, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i64 %v2570, ptr %p2572, align 8, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot17, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  %ld2575 = load i64, ptr %p2574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2575, ptr %slot455, align 8
  %v2576 = load i64, ptr %slot17, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i64, ptr %p2577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2578, ptr %slot456, align 8
  %v2579 = load i64, ptr %slot11, align 8
  store i64 %v2579, ptr %slot457, align 8
  %v2580 = load i64, ptr %slot24, align 8
  store i64 %v2580, ptr %slot458, align 8
  %v2581 = load i64, ptr %slot456, align 8
  %op2582 = add i64 %v2581, 8
  store i64 %op2582, ptr %slot459, align 8
  %v2583 = load i64, ptr %slot459, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i64, ptr %p2584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2585, ptr %slot460, align 8
  %v2586 = load i64, ptr %slot460, align 8
  %cmp2587 = icmp ne i64 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i32
  store i32 %cv2588, ptr %slot461, align 8
  %v2589 = load i32, ptr %slot461, align 8
  %cv2590 = zext i32 %v2589 to i64
  %cond2591 = icmp ne i64 %cv2590, 0
  br i1 %cond2591, label %bb_rcmoveheader1161, label %bb_rcmovenext1161
bb_rcmoveheader1161:
  %v2592 = load i64, ptr %slot460, align 8
  %op2593 = sub i64 %v2592, 16
  store i64 %op2593, ptr %slot462, align 8
  %v2594 = load i64, ptr %slot460, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %rgep2596 = getelementptr i8, ptr %p2595, i64 -16
  %ld2597 = load i64, ptr %rgep2596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2597, ptr %slot463, align 8
  %v2598 = load i64, ptr %slot463, align 8
  %op2599 = and i64 %v2598, 5764607523034234881
  store i64 %op2599, ptr %slot464, align 8
  %v2600 = load i64, ptr %slot464, align 8
  %cmp2601 = icmp ne i64 %v2600, 0
  %cv2602 = zext i1 %cmp2601 to i32
  store i32 %cv2602, ptr %slot465, align 8
  %v2603 = load i32, ptr %slot465, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcmoveslow1158, label %bb_rcmovenext1161
bb_rcmovenext1161:
  %v2606 = load i64, ptr %slot456, align 8
  %v2607 = load i64, ptr %slot457, align 8
  %p2608 = inttoptr i64 %v2606 to ptr
  %p2609 = inttoptr i64 %v2607 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2609, ptr %p2608, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot456, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i64 0, ptr %p2611, align 8, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot456, align 8
  %op2613 = add i64 %v2612, 8
  store i64 %op2613, ptr %slot466, align 8
  %v2614 = load i64, ptr %slot466, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  store i64 0, ptr %p2615, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1158
bb_rcmoveslow1158:
  %v2616 = load i64, ptr %slot23, align 8
  %v2617 = load i64, ptr %slot457, align 8
  %v2618 = load i64, ptr %slot456, align 8
  %v2619 = load i64, ptr %slot458, align 8
  %cv2620 = trunc i64 %v2619 to i32
  %call2621 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2616, i64 %v2617, i64 %v2618, i32 %cv2620) nomerge, !dbg !180
  store i32 %call2621, ptr %slot467, align 8
  %v2622 = load i32, ptr %slot467, align 8
  %cv2623 = zext i32 %v2622 to i64
  %cond2624 = icmp ne i64 %cv2623, 0
  br i1 %cond2624, label %bb_rcsuccess1169, label %bb_rcfailure1169
bb_rcfailure1169:
  %v2625 = load i64, ptr %slot23, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  %call2627 = call i32 @myl_rc_take_failure(ptr %p2626) nomerge, !dbg !180
  store i32 %call2627, ptr %slot468, align 8
  %v2628 = load i64, ptr %slot1, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %v2630 = load i32, ptr %slot468, align 8
  %call2631 = call i32 @myl_qbe_rc_status(ptr %p2629, i32 %v2630) nomerge, !dbg !180
  store i32 %call2631, ptr %slot469, align 8
  br label %bb_failure
bb_rcsuccess1169:
  br label %bb_rcmoved1158
bb_rcmoved1158:
  %v2632 = load i64, ptr %slot6, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i32 0, ptr %p2633, align 4, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot9, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  store i32 2, ptr %p2635, align 4, !alias.scope !3, !noalias !4
  %v2636 = load i64, ptr %slot8, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  store i32 1, ptr %p2637, align 4, !alias.scope !3, !noalias !4
  %v2638 = load i64, ptr %slot11, align 8
  store i64 %v2638, ptr %slot470, align 8
  %v2639 = load i64, ptr %slot8, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 0, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot6, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %ld2643 = load i32, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2643, ptr %slot471, align 8
  %v2644 = load i32, ptr %slot471, align 8
  %cv2645 = zext i32 %v2644 to i64
  %cond2646 = icmp ne i64 %cv2645, 0
  br i1 %cond2646, label %bb_rcslotdrop1179, label %bb_rcslotdone1179
bb_rcslotdrop1179:
  %v2647 = load i64, ptr %slot6, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  store i32 0, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  %v2649 = load i64, ptr %slot10, align 8
  store i64 %v2649, ptr %slot472, align 8
  %v2650 = load i64, ptr %slot7, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot473, align 8
  %v2653 = load i32, ptr %slot473, align 8
  %op2654 = and i32 %v2653, 28
  store i32 %op2654, ptr %slot474, align 8
  %v2655 = load i32, ptr %slot474, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcslotrole1179, label %bb_rcslotowner1179
bb_rcslotrole1179:
  %v2658 = load i64, ptr %slot23, align 8
  store i64 %v2658, ptr %slot475, align 8
  %v2659 = load i64, ptr %slot475, align 8
  %v2660 = load i64, ptr %slot472, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2659, i64 %v2660) nomerge, !dbg !180
  br label %bb_rcslotdone1179
bb_rcslotowner1179:
  %v2661 = load i64, ptr %slot23, align 8
  store i64 %v2661, ptr %slot476, align 8
  %v2662 = load i64, ptr %slot476, align 8
  %v2663 = load i64, ptr %slot472, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2662, i64 %v2663) nomerge, !dbg !180
  br label %bb_rcslotdone1179
bb_rcslotdone1179:
  %v2664 = load i64, ptr %slot470, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  %ret2666 = load { i64, i64 }, ptr %p2665, align 8
  ret { i64, i64 } %ret2666
bb_i77:
  %v2667 = load i64, ptr %slot17, align 8
  %p2668 = inttoptr i64 %v2667 to ptr
  store i64 0, ptr %p2668, align 8, !alias.scope !3, !noalias !4
  %v2669 = load i64, ptr %slot17, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %ld2671 = load i64, ptr %p2670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2671, ptr %slot477, align 8
  %v2672 = load i64, ptr %slot477, align 8
  %cond2673 = icmp ne i64 %v2672, 0
  br i1 %cond2673, label %bb_success1242, label %bb_failed1242
bb_failed1242:
  %v2674 = load i64, ptr %slot1, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  call void @myl_qbe_fail_assert(ptr %p2675) nomerge, !dbg !182
  unreachable
bb_success1242:
  %v2676 = load i64, ptr %slot17, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i64 18446744073709551615, ptr %p2677, align 8, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot18, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  store i64 0, ptr %p2679, align 8, !alias.scope !3, !noalias !4
  %v2680 = load i64, ptr %slot17, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  %ld2682 = load i64, ptr %p2681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2682, ptr %slot478, align 8
  %v2683 = load i64, ptr %slot18, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  %ld2685 = load i64, ptr %p2684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2685, ptr %slot479, align 8
  %v2686 = load i64, ptr %slot1, align 8
  %v2687 = load i64, ptr %slot478, align 8
  %v2688 = load i64, ptr %slot479, align 8
  %call2689 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v2686, i64 %v2687, i64 %v2688) nomerge, !dbg !184
  store { i64, i64 } %call2689, ptr %callresult481, align 8
  %addr2690 = ptrtoint ptr %callresult481 to i64
  store i64 %addr2690, ptr %slot480, align 8
  %v2691 = load i64, ptr %slot480, align 8
  %v2692 = load i64, ptr %slot17, align 8
  %p2693 = inttoptr i64 %v2692 to ptr
  store i64 %v2691, ptr %p2693, align 8, !alias.scope !3, !noalias !4
  %v2694 = load i64, ptr %slot17, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i64, ptr %p2695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2696, ptr %slot482, align 8
  %v2697 = load i64, ptr %slot11, align 8
  store i64 %v2697, ptr %slot483, align 8
  %v2698 = load i64, ptr %slot482, align 8
  %v2699 = load i64, ptr %slot483, align 8
  %p2700 = inttoptr i64 %v2698 to ptr
  %p2701 = inttoptr i64 %v2699 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2701, ptr %p2700, i64 16, i1 false)
  %v2702 = load i64, ptr %slot9, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  store i32 2, ptr %p2703, align 4, !alias.scope !3, !noalias !4
  %v2704 = load i64, ptr %slot8, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i32 1, ptr %p2705, align 4, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot10, align 8
  store i64 %v2706, ptr %slot484, align 8
  %v2707 = load i64, ptr %slot11, align 8
  store i64 %v2707, ptr %slot485, align 8
  %v2708 = load i64, ptr %slot485, align 8
  %v2709 = load i64, ptr %slot484, align 8
  %p2710 = inttoptr i64 %v2708 to ptr
  %p2711 = inttoptr i64 %v2709 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2711, ptr %p2710, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2712 = load i64, ptr %slot7, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  store i32 2, ptr %p2713, align 4, !alias.scope !3, !noalias !4
  %v2714 = load i64, ptr %slot9, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  %ld2716 = load i32, ptr %p2715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2716, ptr %slot486, align 8
  %v2717 = load i32, ptr %slot486, align 8
  %v2718 = load i64, ptr %slot7, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  store i32 %v2717, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  %v2720 = load i64, ptr %slot8, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  store i32 0, ptr %p2721, align 4, !alias.scope !3, !noalias !4
  %v2722 = load i64, ptr %slot6, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  store i32 1, ptr %p2723, align 4, !alias.scope !3, !noalias !4
  %v2724 = load i64, ptr %slot484, align 8
  %v2725 = load i64, ptr %slot17, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i64 %v2724, ptr %p2726, align 8, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot17, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i64, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2729, ptr %slot487, align 8
  %v2730 = load i64, ptr %slot17, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  %ld2732 = load i64, ptr %p2731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2732, ptr %slot488, align 8
  %v2733 = load i64, ptr %slot11, align 8
  store i64 %v2733, ptr %slot489, align 8
  %v2734 = load i64, ptr %slot24, align 8
  store i64 %v2734, ptr %slot490, align 8
  %v2735 = load i64, ptr %slot488, align 8
  %op2736 = add i64 %v2735, 8
  store i64 %op2736, ptr %slot491, align 8
  %v2737 = load i64, ptr %slot491, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %ld2739 = load i64, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2739, ptr %slot492, align 8
  %v2740 = load i64, ptr %slot492, align 8
  %cmp2741 = icmp ne i64 %v2740, 0
  %cv2742 = zext i1 %cmp2741 to i32
  store i32 %cv2742, ptr %slot493, align 8
  %v2743 = load i32, ptr %slot493, align 8
  %cv2744 = zext i32 %v2743 to i64
  %cond2745 = icmp ne i64 %cv2744, 0
  br i1 %cond2745, label %bb_rcmoveheader1265, label %bb_rcmovenext1265
bb_rcmoveheader1265:
  %v2746 = load i64, ptr %slot492, align 8
  %op2747 = sub i64 %v2746, 16
  store i64 %op2747, ptr %slot494, align 8
  %v2748 = load i64, ptr %slot492, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  %rgep2750 = getelementptr i8, ptr %p2749, i64 -16
  %ld2751 = load i64, ptr %rgep2750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2751, ptr %slot495, align 8
  %v2752 = load i64, ptr %slot495, align 8
  %op2753 = and i64 %v2752, 5764607523034234881
  store i64 %op2753, ptr %slot496, align 8
  %v2754 = load i64, ptr %slot496, align 8
  %cmp2755 = icmp ne i64 %v2754, 0
  %cv2756 = zext i1 %cmp2755 to i32
  store i32 %cv2756, ptr %slot497, align 8
  %v2757 = load i32, ptr %slot497, align 8
  %cv2758 = zext i32 %v2757 to i64
  %cond2759 = icmp ne i64 %cv2758, 0
  br i1 %cond2759, label %bb_rcmoveslow1262, label %bb_rcmovenext1265
bb_rcmovenext1265:
  %v2760 = load i64, ptr %slot488, align 8
  %v2761 = load i64, ptr %slot489, align 8
  %p2762 = inttoptr i64 %v2760 to ptr
  %p2763 = inttoptr i64 %v2761 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2763, ptr %p2762, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2764 = load i64, ptr %slot488, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  store i64 0, ptr %p2765, align 8, !alias.scope !3, !noalias !4
  %v2766 = load i64, ptr %slot488, align 8
  %op2767 = add i64 %v2766, 8
  store i64 %op2767, ptr %slot498, align 8
  %v2768 = load i64, ptr %slot498, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  store i64 0, ptr %p2769, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1262
bb_rcmoveslow1262:
  %v2770 = load i64, ptr %slot23, align 8
  %v2771 = load i64, ptr %slot489, align 8
  %v2772 = load i64, ptr %slot488, align 8
  %v2773 = load i64, ptr %slot490, align 8
  %cv2774 = trunc i64 %v2773 to i32
  %call2775 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v2770, i64 %v2771, i64 %v2772, i32 %cv2774) nomerge, !dbg !186
  store i32 %call2775, ptr %slot499, align 8
  %v2776 = load i32, ptr %slot499, align 8
  %cv2777 = zext i32 %v2776 to i64
  %cond2778 = icmp ne i64 %cv2777, 0
  br i1 %cond2778, label %bb_rcsuccess1273, label %bb_rcfailure1273
bb_rcfailure1273:
  %v2779 = load i64, ptr %slot23, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %call2781 = call i32 @myl_rc_take_failure(ptr %p2780) nomerge, !dbg !186
  store i32 %call2781, ptr %slot500, align 8
  %v2782 = load i64, ptr %slot1, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %v2784 = load i32, ptr %slot500, align 8
  %call2785 = call i32 @myl_qbe_rc_status(ptr %p2783, i32 %v2784) nomerge, !dbg !186
  store i32 %call2785, ptr %slot501, align 8
  br label %bb_failure
bb_rcsuccess1273:
  br label %bb_rcmoved1262
bb_rcmoved1262:
  %v2786 = load i64, ptr %slot6, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i32 0, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot9, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i32 2, ptr %p2789, align 4, !alias.scope !3, !noalias !4
  %v2790 = load i64, ptr %slot8, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  store i32 1, ptr %p2791, align 4, !alias.scope !3, !noalias !4
  %v2792 = load i64, ptr %slot11, align 8
  store i64 %v2792, ptr %slot502, align 8
  %v2793 = load i64, ptr %slot8, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i32 0, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  %v2795 = load i64, ptr %slot6, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %ld2797 = load i32, ptr %p2796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2797, ptr %slot503, align 8
  %v2798 = load i32, ptr %slot503, align 8
  %cv2799 = zext i32 %v2798 to i64
  %cond2800 = icmp ne i64 %cv2799, 0
  br i1 %cond2800, label %bb_rcslotdrop1283, label %bb_rcslotdone1283
bb_rcslotdrop1283:
  %v2801 = load i64, ptr %slot6, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i32 0, ptr %p2802, align 4, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot10, align 8
  store i64 %v2803, ptr %slot504, align 8
  %v2804 = load i64, ptr %slot7, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  %ld2806 = load i32, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2806, ptr %slot505, align 8
  %v2807 = load i32, ptr %slot505, align 8
  %op2808 = and i32 %v2807, 28
  store i32 %op2808, ptr %slot506, align 8
  %v2809 = load i32, ptr %slot506, align 8
  %cv2810 = zext i32 %v2809 to i64
  %cond2811 = icmp ne i64 %cv2810, 0
  br i1 %cond2811, label %bb_rcslotrole1283, label %bb_rcslotowner1283
bb_rcslotrole1283:
  %v2812 = load i64, ptr %slot23, align 8
  store i64 %v2812, ptr %slot507, align 8
  %v2813 = load i64, ptr %slot507, align 8
  %v2814 = load i64, ptr %slot504, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64 %v2813, i64 %v2814) nomerge, !dbg !186
  br label %bb_rcslotdone1283
bb_rcslotowner1283:
  %v2815 = load i64, ptr %slot23, align 8
  store i64 %v2815, ptr %slot508, align 8
  %v2816 = load i64, ptr %slot508, align 8
  %v2817 = load i64, ptr %slot504, align 8
  call void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64 %v2816, i64 %v2817) nomerge, !dbg !186
  br label %bb_rcslotdone1283
bb_rcslotdone1283:
  %v2818 = load i64, ptr %slot502, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  %ret2820 = load { i64, i64 }, ptr %p2819, align 8
  ret { i64, i64 } %ret2820
bb_failure:
  %v2821 = load i64, ptr %slot5, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  call void @llvm.memset.p0.i64(ptr %p2822, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !186
  %v2823 = load i64, ptr %slot5, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %ret2825 = load { i64, i64 }, ptr %p2824, align 8
  ret { i64, i64 } %ret2825
bb_entry_failure:
  %v2826 = load i64, ptr %slot5, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  call void @llvm.memset.p0.i64(ptr %p2827, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !186
  %v2828 = load i64, ptr %slot5, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  %ret2830 = load { i64, i64 }, ptr %p2829, align 8
  ret { i64, i64 } %ret2830
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64, i64, i64)
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_drop(i64, i64)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64, i64, i64, i32)
declare void @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0", linkageName: "myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3194174064038389473, i64 0, !"myl_f_c23510c1550aec398085d984778501844c522280aa3ef425e458dfa012b997c0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!130 = !DILocation(line: 28, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!132 = !DILocation(line: 29, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!136 = !DILocation(line: 34, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!142 = !DILocation(line: 40, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!144 = !DILocation(line: 41, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!146 = !DILocation(line: 43, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!148 = !DILocation(line: 46, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!150 = !DILocation(line: 47, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!152 = !DILocation(line: 49, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!154 = !DILocation(line: 52, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!156 = !DILocation(line: 53, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!158 = !DILocation(line: 55, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!160 = !DILocation(line: 58, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!162 = !DILocation(line: 59, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!164 = !DILocation(line: 61, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!166 = !DILocation(line: 64, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!168 = !DILocation(line: 65, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!170 = !DILocation(line: 67, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!172 = !DILocation(line: 70, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!174 = !DILocation(line: 71, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!176 = !DILocation(line: 73, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!178 = !DILocation(line: 76, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!180 = !DILocation(line: 77, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!182 = !DILocation(line: 79, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!184 = !DILocation(line: 82, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!186 = !DILocation(line: 83, column: 0, scope: !187)
