target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v105 = load i64, ptr %slot1, align 8
  %op106 = add i64 %v105, 32
  store i64 %op106, ptr %slot5, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot6, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot7, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot8, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot9, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot10, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot11, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot12, align 8
  %v121 = load i64, ptr %slot10, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i64 0, ptr %p122, align 8, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot11, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i64 0, ptr %p124, align 8, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot2, align 8
  %v126 = load i64, ptr %slot7, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 %v125, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot3, align 8
  %v129 = load i64, ptr %slot8, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot4, align 8
  %v132 = load i64, ptr %slot9, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot1, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %call136 = call ptr @myl_qbe_heap(ptr %p135) nomerge, !dbg !110
  %calladdr137 = ptrtoint ptr %call136 to i64
  store i64 %calladdr137, ptr %slot13, align 8
  br label %bb_i0
bb_i0:
  %v138 = load i64, ptr %slot7, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot14, align 8
  %v141 = load i64, ptr %slot14, align 8
  %v142 = load i64, ptr %slot12, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot12, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot15, align 8
  %v147 = load i64, ptr %slot15, align 8
  %op148 = add i64 %v147, 0
  store i64 %op148, ptr %slot16, align 8
  %v149 = load i64, ptr %slot16, align 8
  %p150 = inttoptr i64 %v149 to ptr
  %ld151 = load i64, ptr %p150, align 8
  store i64 %ld151, ptr %slot17, align 8
  %v152 = load i64, ptr %slot17, align 8
  %v153 = load i64, ptr %slot12, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot12, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot18, align 8
  %v158 = load i64, ptr %slot7, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot19, align 8
  %v161 = load i64, ptr %slot19, align 8
  %op162 = add i64 %v161, 0
  store i64 %op162, ptr %slot20, align 8
  store i64 0, ptr %slot21, align 8
  %v163 = load i64, ptr %slot20, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !4, !noalias !3
  store i64 %ld165, ptr %slot22, align 8
  %v166 = load i64, ptr %slot22, align 8
  %cmp167 = icmp ne i64 %v166, 0
  %cv168 = zext i1 %cmp167 to i32
  store i32 %cv168, ptr %slot23, align 8
  %v169 = load i32, ptr %slot23, align 8
  %cv170 = zext i32 %v169 to i64
  %cond171 = icmp ne i64 %cv170, 0
  br i1 %cond171, label %bb_rcguniquenn56, label %bb_rcgunique56
bb_rcguniquenn56:
  %v172 = load i64, ptr %slot22, align 8
  %op173 = sub i64 %v172, 16
  store i64 %op173, ptr %slot24, align 8
  %v174 = load i64, ptr %slot22, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %rgep176 = getelementptr i8, ptr %p175, i64 -16
  %ld177 = load i64, ptr %rgep176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld177, ptr %slot25, align 8
  %v178 = load i64, ptr %slot25, align 8
  %op179 = and i64 %v178, 6917529027641081858
  store i64 %op179, ptr %slot26, align 8
  %v180 = load i64, ptr %slot26, align 8
  %cmp181 = icmp ne i64 %v180, 0
  %cv182 = zext i1 %cmp181 to i32
  store i32 %cv182, ptr %slot27, align 8
  %v183 = load i32, ptr %slot27, align 8
  %cv184 = zext i32 %v183 to i64
  %cond185 = icmp ne i64 %cv184, 0
  br i1 %cond185, label %bb_rcguniqueslow56, label %bb_rcguniquecount56
bb_rcguniquecount56:
  %v186 = load i64, ptr %slot22, align 8
  %op187 = sub i64 %v186, 32
  store i64 %op187, ptr %slot28, align 8
  %v188 = load i64, ptr %slot22, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %rgep190 = getelementptr i8, ptr %p189, i64 -32
  %ld191 = load i64, ptr %rgep190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld191, ptr %slot29, align 8
  %v192 = load i64, ptr %slot29, align 8
  %cmp193 = icmp ult i64 %v192, 2
  %cv194 = zext i1 %cmp193 to i32
  store i32 %cv194, ptr %slot30, align 8
  %v195 = load i32, ptr %slot30, align 8
  %cv196 = zext i32 %v195 to i64
  %cond197 = icmp ne i64 %cv196, 0
  br i1 %cond197, label %bb_rcgunique56, label %bb_rcguniqueslow56
bb_rcguniqueslow56:
  %v198 = load i64, ptr %slot1, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %p200 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v201 = load i64, ptr %slot20, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %v203 = load i64, ptr %slot21, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %call205 = call i32 @myl_qbe_rc_unique_field(ptr %p199, ptr %p200, ptr %p202, ptr %p204) nomerge, !dbg !112
  store i32 %call205, ptr %slot31, align 8
  %v206 = load i32, ptr %slot31, align 8
  %cv207 = zext i32 %v206 to i64
  %cond208 = icmp ne i64 %cv207, 0
  br i1 %cond208, label %bb_rcunique66, label %bb_failure
bb_rcunique66:
  br label %bb_rcgunique56
bb_rcgunique56:
  %v209 = load i64, ptr %slot20, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !4, !noalias !3
  store i64 %ld211, ptr %slot32, align 8
  %v212 = load i64, ptr %slot32, align 8
  %v213 = load i64, ptr %slot12, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 %v212, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot12, align 8
  %p216 = inttoptr i64 %v215 to ptr
  %ld217 = load i64, ptr %p216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld217, ptr %slot33, align 8
  %v218 = load i64, ptr %slot33, align 8
  %v219 = load i64, ptr %slot10, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot8, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot34, align 8
  %v224 = load i64, ptr %slot34, align 8
  %v225 = load i64, ptr %slot12, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot10, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot35, align 8
  %v230 = load i64, ptr %slot12, align 8
  store i64 %v230, ptr %slot36, align 8
  %v231 = load i64, ptr %slot36, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot37, align 8
  %v234 = load i64, ptr %slot35, align 8
  %op235 = add i64 %v234, 0
  store i64 %op235, ptr %slot38, align 8
  %v236 = load i64, ptr %slot38, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !6, !noalias !7
  store i64 %ld238, ptr %slot39, align 8
  %v239 = load i64, ptr %slot35, align 8
  %op240 = add i64 %v239, 8
  store i64 %op240, ptr %slot40, align 8
  %v241 = load i64, ptr %slot40, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !6, !noalias !7
  store i64 %ld243, ptr %slot41, align 8
  %v244 = load i64, ptr %slot35, align 8
  %op245 = add i64 %v244, 16
  store i64 %op245, ptr %slot42, align 8
  %v246 = load i64, ptr %slot42, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !6, !noalias !7
  store i64 %ld248, ptr %slot43, align 8
  %v249 = load i64, ptr %slot39, align 8
  %v250 = load i64, ptr %slot41, align 8
  %cmp251 = icmp ult i64 %v249, %v250
  %cv252 = zext i1 %cmp251 to i32
  store i32 %cv252, ptr %slot44, align 8
  %v253 = load i64, ptr %slot43, align 8
  %cmp254 = icmp ne i64 %v253, 18446744073709551615
  %cv255 = zext i1 %cmp254 to i32
  store i32 %cv255, ptr %slot45, align 8
  %v256 = load i32, ptr %slot44, align 8
  %v257 = load i32, ptr %slot45, align 8
  %op258 = and i32 %v256, %v257
  store i32 %op258, ptr %slot46, align 8
  %v259 = load i32, ptr %slot46, align 8
  %cv260 = zext i32 %v259 to i64
  %cond261 = icmp ne i64 %cv260, 0
  br i1 %cond261, label %bb_rcappend_check74, label %bb_rcappend_slow74
bb_rcappend_check74:
  %v262 = load i64, ptr %slot13, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %v264 = load i64, ptr %slot35, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %call266 = call i32 @myl_rc_list_plain_ready(ptr %p263, ptr %p265) nomerge, !dbg !114
  store i32 %call266, ptr %slot47, align 8
  %v267 = load i32, ptr %slot47, align 8
  %cv268 = zext i32 %v267 to i64
  %cond269 = icmp ne i64 %cv268, 0
  br i1 %cond269, label %bb_rcappend_fast74, label %bb_rcappend_slow74
bb_rcappend_slow74:
  %v270 = load i64, ptr %slot36, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot48, align 8
  %v273 = load i64, ptr %slot48, align 8
  %v274 = load i64, ptr %slot6, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 %v273, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot6, align 8
  store i64 %v276, ptr %slot49, align 8
  %v277 = load i64, ptr %slot13, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %v279 = load i64, ptr %slot35, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %v281 = load i64, ptr %slot49, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %call283 = call i32 @myl_rc_list_append(ptr %p278, ptr %p280, ptr %p282) nomerge, !dbg !114
  store i32 %call283, ptr %slot50, align 8
  %v284 = load i32, ptr %slot50, align 8
  %cv285 = zext i32 %v284 to i64
  %cond286 = icmp ne i64 %cv285, 0
  br i1 %cond286, label %bb_success87, label %bb_failed87
bb_failed87:
  %v287 = load i64, ptr %slot1, align 8
  %p288 = inttoptr i64 %v287 to ptr
  call void @myl_qbe_fail_allocation(ptr %p288) nomerge, !dbg !114
  unreachable
bb_success87:
  br label %bb_rcappend_done74
bb_rcappend_fast74:
  %v289 = load i64, ptr %slot35, align 8
  %op290 = add i64 %v289, 32
  store i64 %op290, ptr %slot51, align 8
  %v291 = load i64, ptr %slot51, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !6, !noalias !7
  store i64 %ld293, ptr %slot52, align 8
  %v294 = load i64, ptr %slot39, align 8
  %op295 = mul i64 %v294, 8
  store i64 %op295, ptr %slot53, align 8
  %v296 = load i64, ptr %slot52, align 8
  %v297 = load i64, ptr %slot53, align 8
  %op298 = add i64 %v296, %v297
  store i64 %op298, ptr %slot54, align 8
  %v299 = load i64, ptr %slot37, align 8
  %v300 = load i64, ptr %slot52, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %v302 = load i64, ptr %slot53, align 8
  %egep303 = getelementptr i8, ptr %p301, i64 %v302
  store i64 %v299, ptr %egep303, align 8, !alias.scope !12, !noalias !13
  %v304 = load i64, ptr %slot35, align 8
  %op305 = add i64 %v304, 0
  store i64 %op305, ptr %slot55, align 8
  %v306 = load i64, ptr %slot39, align 8
  %op307 = add i64 %v306, 1
  store i64 %op307, ptr %slot56, align 8
  %v308 = load i64, ptr %slot56, align 8
  %v309 = load i64, ptr %slot55, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i64 %v308, ptr %p310, align 8, !alias.scope !6, !noalias !7
  %v311 = load i64, ptr %slot35, align 8
  %op312 = add i64 %v311, 16
  store i64 %op312, ptr %slot57, align 8
  %v313 = load i64, ptr %slot43, align 8
  %op314 = add i64 %v313, 1
  store i64 %op314, ptr %slot58, align 8
  %v315 = load i64, ptr %slot58, align 8
  %v316 = load i64, ptr %slot57, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 %v315, ptr %p317, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done74
bb_rcappend_done74:
  %v318 = load i64, ptr %slot12, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i64 0, ptr %p319, align 8, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot7, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %ld322 = load i64, ptr %p321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld322, ptr %slot59, align 8
  %v323 = load i64, ptr %slot59, align 8
  %v324 = load i64, ptr %slot12, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot12, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot60, align 8
  %v329 = load i64, ptr %slot60, align 8
  %op330 = add i64 %v329, 8
  store i64 %op330, ptr %slot61, align 8
  %v331 = load i64, ptr %slot61, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8
  store i64 %ld333, ptr %slot62, align 8
  %v334 = load i64, ptr %slot62, align 8
  %v335 = load i64, ptr %slot12, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 %v334, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot12, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot63, align 8
  %v340 = load i64, ptr %slot7, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld342, ptr %slot64, align 8
  %v343 = load i64, ptr %slot64, align 8
  %op344 = add i64 %v343, 8
  store i64 %op344, ptr %slot65, align 8
  store i64 0, ptr %slot66, align 8
  %v345 = load i64, ptr %slot65, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !4, !noalias !3
  store i64 %ld347, ptr %slot67, align 8
  %v348 = load i64, ptr %slot67, align 8
  %cmp349 = icmp ne i64 %v348, 0
  %cv350 = zext i1 %cmp349 to i32
  store i32 %cv350, ptr %slot68, align 8
  %v351 = load i32, ptr %slot68, align 8
  %cv352 = zext i32 %v351 to i64
  %cond353 = icmp ne i64 %cv352, 0
  br i1 %cond353, label %bb_rcguniquenn151, label %bb_rcgunique151
bb_rcguniquenn151:
  %v354 = load i64, ptr %slot67, align 8
  %op355 = sub i64 %v354, 16
  store i64 %op355, ptr %slot69, align 8
  %v356 = load i64, ptr %slot67, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %rgep358 = getelementptr i8, ptr %p357, i64 -16
  %ld359 = load i64, ptr %rgep358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld359, ptr %slot70, align 8
  %v360 = load i64, ptr %slot70, align 8
  %op361 = and i64 %v360, 6917529027641081858
  store i64 %op361, ptr %slot71, align 8
  %v362 = load i64, ptr %slot71, align 8
  %cmp363 = icmp ne i64 %v362, 0
  %cv364 = zext i1 %cmp363 to i32
  store i32 %cv364, ptr %slot72, align 8
  %v365 = load i32, ptr %slot72, align 8
  %cv366 = zext i32 %v365 to i64
  %cond367 = icmp ne i64 %cv366, 0
  br i1 %cond367, label %bb_rcguniqueslow151, label %bb_rcguniquecount151
bb_rcguniquecount151:
  %v368 = load i64, ptr %slot67, align 8
  %op369 = sub i64 %v368, 32
  store i64 %op369, ptr %slot73, align 8
  %v370 = load i64, ptr %slot67, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %rgep372 = getelementptr i8, ptr %p371, i64 -32
  %ld373 = load i64, ptr %rgep372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld373, ptr %slot74, align 8
  %v374 = load i64, ptr %slot74, align 8
  %cmp375 = icmp ult i64 %v374, 2
  %cv376 = zext i1 %cmp375 to i32
  store i32 %cv376, ptr %slot75, align 8
  %v377 = load i32, ptr %slot75, align 8
  %cv378 = zext i32 %v377 to i64
  %cond379 = icmp ne i64 %cv378, 0
  br i1 %cond379, label %bb_rcgunique151, label %bb_rcguniqueslow151
bb_rcguniqueslow151:
  %v380 = load i64, ptr %slot1, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %p382 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v383 = load i64, ptr %slot65, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %v385 = load i64, ptr %slot66, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %call387 = call i32 @myl_qbe_rc_unique_field(ptr %p381, ptr %p382, ptr %p384, ptr %p386) nomerge, !dbg !116
  store i32 %call387, ptr %slot76, align 8
  %v388 = load i32, ptr %slot76, align 8
  %cv389 = zext i32 %v388 to i64
  %cond390 = icmp ne i64 %cv389, 0
  br i1 %cond390, label %bb_rcunique161, label %bb_failure
bb_rcunique161:
  br label %bb_rcgunique151
bb_rcgunique151:
  %v391 = load i64, ptr %slot65, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i64, ptr %p392, align 8, !alias.scope !4, !noalias !3
  store i64 %ld393, ptr %slot77, align 8
  %v394 = load i64, ptr %slot77, align 8
  %v395 = load i64, ptr %slot12, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 %v394, ptr %p396, align 8, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot12, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot78, align 8
  %v400 = load i64, ptr %slot78, align 8
  %v401 = load i64, ptr %slot11, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 %v400, ptr %p402, align 8, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot9, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot79, align 8
  %v406 = load i64, ptr %slot79, align 8
  %v407 = load i64, ptr %slot12, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 %v406, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot11, align 8
  %p410 = inttoptr i64 %v409 to ptr
  %ld411 = load i64, ptr %p410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld411, ptr %slot80, align 8
  %v412 = load i64, ptr %slot12, align 8
  store i64 %v412, ptr %slot81, align 8
  %v413 = load i64, ptr %slot81, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot82, align 8
  %v416 = load i64, ptr %slot80, align 8
  %op417 = add i64 %v416, 0
  store i64 %op417, ptr %slot83, align 8
  %v418 = load i64, ptr %slot83, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !6, !noalias !7
  store i64 %ld420, ptr %slot84, align 8
  %v421 = load i64, ptr %slot80, align 8
  %op422 = add i64 %v421, 8
  store i64 %op422, ptr %slot85, align 8
  %v423 = load i64, ptr %slot85, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !6, !noalias !7
  store i64 %ld425, ptr %slot86, align 8
  %v426 = load i64, ptr %slot80, align 8
  %op427 = add i64 %v426, 16
  store i64 %op427, ptr %slot87, align 8
  %v428 = load i64, ptr %slot87, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %ld430 = load i64, ptr %p429, align 8, !alias.scope !6, !noalias !7
  store i64 %ld430, ptr %slot88, align 8
  %v431 = load i64, ptr %slot84, align 8
  %v432 = load i64, ptr %slot86, align 8
  %cmp433 = icmp ult i64 %v431, %v432
  %cv434 = zext i1 %cmp433 to i32
  store i32 %cv434, ptr %slot89, align 8
  %v435 = load i64, ptr %slot88, align 8
  %cmp436 = icmp ne i64 %v435, 18446744073709551615
  %cv437 = zext i1 %cmp436 to i32
  store i32 %cv437, ptr %slot90, align 8
  %v438 = load i32, ptr %slot89, align 8
  %v439 = load i32, ptr %slot90, align 8
  %op440 = and i32 %v438, %v439
  store i32 %op440, ptr %slot91, align 8
  %v441 = load i32, ptr %slot91, align 8
  %cv442 = zext i32 %v441 to i64
  %cond443 = icmp ne i64 %cv442, 0
  br i1 %cond443, label %bb_rcappend_check169, label %bb_rcappend_slow169
bb_rcappend_check169:
  %v444 = load i64, ptr %slot13, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %v446 = load i64, ptr %slot80, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %call448 = call i32 @myl_rc_list_plain_ready(ptr %p445, ptr %p447) nomerge, !dbg !118
  store i32 %call448, ptr %slot92, align 8
  %v449 = load i32, ptr %slot92, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcappend_fast169, label %bb_rcappend_slow169
bb_rcappend_slow169:
  %v452 = load i64, ptr %slot81, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot93, align 8
  %v455 = load i64, ptr %slot93, align 8
  %v456 = load i64, ptr %slot6, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 %v455, ptr %p457, align 8, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot6, align 8
  store i64 %v458, ptr %slot94, align 8
  %v459 = load i64, ptr %slot13, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %v461 = load i64, ptr %slot80, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %v463 = load i64, ptr %slot94, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %call465 = call i32 @myl_rc_list_append(ptr %p460, ptr %p462, ptr %p464) nomerge, !dbg !118
  store i32 %call465, ptr %slot95, align 8
  %v466 = load i32, ptr %slot95, align 8
  %cv467 = zext i32 %v466 to i64
  %cond468 = icmp ne i64 %cv467, 0
  br i1 %cond468, label %bb_success182, label %bb_failed182
bb_failed182:
  %v469 = load i64, ptr %slot1, align 8
  %p470 = inttoptr i64 %v469 to ptr
  call void @myl_qbe_fail_allocation(ptr %p470) nomerge, !dbg !118
  unreachable
bb_success182:
  br label %bb_rcappend_done169
bb_rcappend_fast169:
  %v471 = load i64, ptr %slot80, align 8
  %op472 = add i64 %v471, 32
  store i64 %op472, ptr %slot96, align 8
  %v473 = load i64, ptr %slot96, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !6, !noalias !7
  store i64 %ld475, ptr %slot97, align 8
  %v476 = load i64, ptr %slot84, align 8
  %op477 = mul i64 %v476, 8
  store i64 %op477, ptr %slot98, align 8
  %v478 = load i64, ptr %slot97, align 8
  %v479 = load i64, ptr %slot98, align 8
  %op480 = add i64 %v478, %v479
  store i64 %op480, ptr %slot99, align 8
  %v481 = load i64, ptr %slot82, align 8
  %v482 = load i64, ptr %slot97, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %v484 = load i64, ptr %slot98, align 8
  %egep485 = getelementptr i8, ptr %p483, i64 %v484
  store i64 %v481, ptr %egep485, align 8, !alias.scope !12, !noalias !13
  %v486 = load i64, ptr %slot80, align 8
  %op487 = add i64 %v486, 0
  store i64 %op487, ptr %slot100, align 8
  %v488 = load i64, ptr %slot84, align 8
  %op489 = add i64 %v488, 1
  store i64 %op489, ptr %slot101, align 8
  %v490 = load i64, ptr %slot101, align 8
  %v491 = load i64, ptr %slot100, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i64 %v490, ptr %p492, align 8, !alias.scope !6, !noalias !7
  %v493 = load i64, ptr %slot80, align 8
  %op494 = add i64 %v493, 16
  store i64 %op494, ptr %slot102, align 8
  %v495 = load i64, ptr %slot88, align 8
  %op496 = add i64 %v495, 1
  store i64 %op496, ptr %slot103, align 8
  %v497 = load i64, ptr %slot103, align 8
  %v498 = load i64, ptr %slot102, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done169
bb_rcappend_done169:
  %v500 = load i64, ptr %slot12, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i64 0, ptr %p501, align 8, !alias.scope !3, !noalias !4
  %v502 = load i64, ptr %slot12, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 0, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot12, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot104, align 8
  %v507 = load i64, ptr %slot104, align 8
  ret i64 %v507
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8

declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d", linkageName: "myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11990624466637791729, i64 0, !"myl_f_32f685763410746296333113dd101bd14691c7f1bb9a7ad4172f585a98515c8d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!116 = !DILocation(line: 9, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
