target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_338a6618a4a5efff0b2e0ab19eaa6544c1f98c3cc4a486b294b4ebbefdd3b59d(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i32, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i32, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i32, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i32, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i32, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i32, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i32, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i32, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i32, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i32, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i32, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i32, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i32, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i32, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i32, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i32, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i32, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v1439 = load i64, ptr %slot1, align 8
  %op1440 = add i64 %v1439, 32
  store i64 %op1440, ptr %slot3, align 8
  %mem1441 = alloca i8, i64 8, align 8
  %ptr1442 = ptrtoint ptr %mem1441 to i64
  store i64 %ptr1442, ptr %slot4, align 8
  %mem1443 = alloca i8, i64 8, align 8
  %ptr1444 = ptrtoint ptr %mem1443 to i64
  store i64 %ptr1444, ptr %slot5, align 8
  %mem1445 = alloca i8, i64 8, align 8
  %ptr1446 = ptrtoint ptr %mem1445 to i64
  store i64 %ptr1446, ptr %slot6, align 8
  %mem1447 = alloca i8, i64 8, align 8
  %ptr1448 = ptrtoint ptr %mem1447 to i64
  store i64 %ptr1448, ptr %slot7, align 8
  %mem1449 = alloca i8, i64 8, align 8
  %ptr1450 = ptrtoint ptr %mem1449 to i64
  store i64 %ptr1450, ptr %slot8, align 8
  %mem1451 = alloca i8, i64 8, align 8
  %ptr1452 = ptrtoint ptr %mem1451 to i64
  store i64 %ptr1452, ptr %slot9, align 8
  %mem1453 = alloca i8, i64 8, align 8
  %ptr1454 = ptrtoint ptr %mem1453 to i64
  store i64 %ptr1454, ptr %slot10, align 8
  %mem1455 = alloca i8, i64 8, align 8
  %ptr1456 = ptrtoint ptr %mem1455 to i64
  store i64 %ptr1456, ptr %slot11, align 8
  %mem1457 = alloca i8, i64 8, align 8
  %ptr1458 = ptrtoint ptr %mem1457 to i64
  store i64 %ptr1458, ptr %slot12, align 8
  %mem1459 = alloca i8, i64 8, align 8
  %ptr1460 = ptrtoint ptr %mem1459 to i64
  store i64 %ptr1460, ptr %slot13, align 8
  %mem1461 = alloca i8, i64 8, align 8
  %ptr1462 = ptrtoint ptr %mem1461 to i64
  store i64 %ptr1462, ptr %slot14, align 8
  %mem1463 = alloca i8, i64 8, align 8
  %ptr1464 = ptrtoint ptr %mem1463 to i64
  store i64 %ptr1464, ptr %slot15, align 8
  %mem1465 = alloca i8, i64 8, align 8
  %ptr1466 = ptrtoint ptr %mem1465 to i64
  store i64 %ptr1466, ptr %slot16, align 8
  %mem1467 = alloca i8, i64 8, align 8
  %ptr1468 = ptrtoint ptr %mem1467 to i64
  store i64 %ptr1468, ptr %slot17, align 8
  %mem1469 = alloca i8, i64 8, align 8
  %ptr1470 = ptrtoint ptr %mem1469 to i64
  store i64 %ptr1470, ptr %slot18, align 8
  %mem1471 = alloca i8, i64 8, align 8
  %ptr1472 = ptrtoint ptr %mem1471 to i64
  store i64 %ptr1472, ptr %slot19, align 8
  %mem1473 = alloca i8, i64 8, align 8
  %ptr1474 = ptrtoint ptr %mem1473 to i64
  store i64 %ptr1474, ptr %slot20, align 8
  %mem1475 = alloca i8, i64 8, align 8
  %ptr1476 = ptrtoint ptr %mem1475 to i64
  store i64 %ptr1476, ptr %slot21, align 8
  %mem1477 = alloca i8, i64 8, align 8
  %ptr1478 = ptrtoint ptr %mem1477 to i64
  store i64 %ptr1478, ptr %slot22, align 8
  %mem1479 = alloca i8, i64 8, align 8
  %ptr1480 = ptrtoint ptr %mem1479 to i64
  store i64 %ptr1480, ptr %slot23, align 8
  %mem1481 = alloca i8, i64 32, align 8
  %ptr1482 = ptrtoint ptr %mem1481 to i64
  store i64 %ptr1482, ptr %slot24, align 8
  %mem1483 = alloca i8, i64 32, align 8
  %ptr1484 = ptrtoint ptr %mem1483 to i64
  store i64 %ptr1484, ptr %slot25, align 8
  %mem1485 = alloca i8, i64 8, align 8
  %ptr1486 = ptrtoint ptr %mem1485 to i64
  store i64 %ptr1486, ptr %slot26, align 8
  %mem1487 = alloca i8, i64 8, align 8
  %ptr1488 = ptrtoint ptr %mem1487 to i64
  store i64 %ptr1488, ptr %slot27, align 8
  %mem1489 = alloca i8, i64 32, align 8
  %ptr1490 = ptrtoint ptr %mem1489 to i64
  store i64 %ptr1490, ptr %slot28, align 8
  %mem1491 = alloca i8, i64 8, align 8
  %ptr1492 = ptrtoint ptr %mem1491 to i64
  store i64 %ptr1492, ptr %slot29, align 8
  %mem1493 = alloca i8, i64 8, align 8
  %ptr1494 = ptrtoint ptr %mem1493 to i64
  store i64 %ptr1494, ptr %slot30, align 8
  %mem1495 = alloca i8, i64 8, align 8
  %ptr1496 = ptrtoint ptr %mem1495 to i64
  store i64 %ptr1496, ptr %slot31, align 8
  %mem1497 = alloca i8, i64 8, align 8
  %ptr1498 = ptrtoint ptr %mem1497 to i64
  store i64 %ptr1498, ptr %slot32, align 8
  %mem1499 = alloca i8, i64 8, align 8
  %ptr1500 = ptrtoint ptr %mem1499 to i64
  store i64 %ptr1500, ptr %slot33, align 8
  %mem1501 = alloca i8, i64 8, align 8
  %ptr1502 = ptrtoint ptr %mem1501 to i64
  store i64 %ptr1502, ptr %slot34, align 8
  %mem1503 = alloca i8, i64 32, align 8
  %ptr1504 = ptrtoint ptr %mem1503 to i64
  store i64 %ptr1504, ptr %slot35, align 8
  %mem1505 = alloca i8, i64 32, align 8
  %ptr1506 = ptrtoint ptr %mem1505 to i64
  store i64 %ptr1506, ptr %slot36, align 8
  %mem1507 = alloca i8, i64 32, align 8
  %ptr1508 = ptrtoint ptr %mem1507 to i64
  store i64 %ptr1508, ptr %slot37, align 8
  %mem1509 = alloca i8, i64 32, align 8
  %ptr1510 = ptrtoint ptr %mem1509 to i64
  store i64 %ptr1510, ptr %slot38, align 8
  %mem1511 = alloca i8, i64 32, align 8
  %ptr1512 = ptrtoint ptr %mem1511 to i64
  store i64 %ptr1512, ptr %slot39, align 8
  %mem1513 = alloca i8, i64 32, align 8
  %ptr1514 = ptrtoint ptr %mem1513 to i64
  store i64 %ptr1514, ptr %slot40, align 8
  %mem1515 = alloca i8, i64 32, align 8
  %ptr1516 = ptrtoint ptr %mem1515 to i64
  store i64 %ptr1516, ptr %slot41, align 8
  %mem1517 = alloca i8, i64 8, align 8
  %ptr1518 = ptrtoint ptr %mem1517 to i64
  store i64 %ptr1518, ptr %slot42, align 8
  %mem1519 = alloca i8, i64 8, align 8
  %ptr1520 = ptrtoint ptr %mem1519 to i64
  store i64 %ptr1520, ptr %slot43, align 8
  %mem1521 = alloca i8, i64 8, align 8
  %ptr1522 = ptrtoint ptr %mem1521 to i64
  store i64 %ptr1522, ptr %slot44, align 8
  %v1523 = load i64, ptr %slot2, align 8
  %v1524 = load i64, ptr %slot29, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i64 %v1523, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot1, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %call1528 = call ptr @myl_qbe_heap(ptr %p1527) nomerge, !dbg !110
  %calladdr1529 = ptrtoint ptr %call1528 to i64
  store i64 %calladdr1529, ptr %slot45, align 8
  %v1530 = load i64, ptr %slot1, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  %call1532 = call i64 @myl_qbe_region_mark(ptr %p1531) nomerge, !dbg !110
  store i64 %call1532, ptr %slot46, align 8
  %v1533 = load i64, ptr %slot4, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i32 0, ptr %p1534, align 4, !alias.scope !3, !noalias !4
  %v1535 = load i64, ptr %slot5, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i32 0, ptr %p1536, align 4, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot6, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  store i32 0, ptr %p1538, align 4, !alias.scope !3, !noalias !4
  %v1539 = load i64, ptr %slot7, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  store i32 0, ptr %p1540, align 4, !alias.scope !3, !noalias !4
  %v1541 = load i64, ptr %slot8, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i32 0, ptr %p1542, align 4, !alias.scope !3, !noalias !4
  %v1543 = load i64, ptr %slot9, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i32 0, ptr %p1544, align 4, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot10, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i32 0, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  %v1547 = load i64, ptr %slot11, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i32 0, ptr %p1548, align 4, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot12, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i32 0, ptr %p1550, align 4, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot13, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  store i32 0, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  %v1553 = load i64, ptr %slot14, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  store i32 0, ptr %p1554, align 4, !alias.scope !3, !noalias !4
  %v1555 = load i64, ptr %slot15, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i32 0, ptr %p1556, align 4, !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot16, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i32 0, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot17, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 0, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot18, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i32 0, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot19, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i32 0, ptr %p1564, align 4, !alias.scope !3, !noalias !4
  %v1565 = load i64, ptr %slot20, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  store i32 0, ptr %p1566, align 4, !alias.scope !3, !noalias !4
  %v1567 = load i64, ptr %slot21, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i32 0, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot22, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  store i32 0, ptr %p1570, align 4, !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot23, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i32 0, ptr %p1572, align 4, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot5, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i32 2, ptr %p1574, align 4, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot7, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  store i32 2, ptr %p1576, align 4, !alias.scope !3, !noalias !4
  %v1577 = load i64, ptr %slot9, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i32 2, ptr %p1578, align 4, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot11, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i32 2, ptr %p1580, align 4, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot13, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 2, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot15, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  store i32 2, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  %v1585 = load i64, ptr %slot17, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i32 2, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1587 = load i64, ptr %slot29, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %ld1589 = load i64, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1589, ptr %slot47, align 8
  %v1590 = load i64, ptr %slot47, align 8
  %v1591 = load i64, ptr %slot42, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i64 %v1590, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot42, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i64, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1595, ptr %slot48, align 8
  %v1596 = load i64, ptr %slot18, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i32, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1598, ptr %slot49, align 8
  %v1599 = load i64, ptr %slot19, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  %ld1601 = load i32, ptr %p1600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1601, ptr %slot50, align 8
  %v1602 = load i32, ptr %slot50, align 8
  %op1603 = and i32 %v1602, 24
  store i32 %op1603, ptr %slot50, align 8
  %v1604 = load i32, ptr %slot50, align 8
  %cmp1605 = icmp eq i32 %v1604, 0
  %cv1606 = zext i1 %cmp1605 to i32
  store i32 %cv1606, ptr %slot51, align 8
  %v1607 = load i32, ptr %slot49, align 8
  %v1608 = load i32, ptr %slot51, align 8
  %op1609 = and i32 %v1607, %v1608
  store i32 %op1609, ptr %slot52, align 8
  %v1610 = load i32, ptr %slot52, align 8
  %cv1611 = zext i32 %v1610 to i64
  %cond1612 = icmp ne i64 %cv1611, 0
  br i1 %cond1612, label %bb_rctake14, label %bb_rccopy14
bb_rctake14:
  %v1613 = load i64, ptr %slot28, align 8
  store i64 %v1613, ptr %slot53, align 8
  %v1614 = load i64, ptr %slot46, align 8
  store i64 %v1614, ptr %slot54, align 8
  %v1615 = load i64, ptr %slot48, align 8
  %v1616 = load i64, ptr %slot53, align 8
  %op1617 = sub i64 %v1615, %v1616
  store i64 %op1617, ptr %slot55, align 8
  %v1618 = load i64, ptr %slot53, align 8
  %v1619 = load i64, ptr %slot48, align 8
  %op1620 = sub i64 %v1618, %v1619
  store i64 %op1620, ptr %slot56, align 8
  %v1621 = load i64, ptr %slot55, align 8
  %cmp1622 = icmp ult i64 %v1621, 32
  %cv1623 = zext i1 %cmp1622 to i32
  store i32 %cv1623, ptr %slot57, align 8
  %v1624 = load i64, ptr %slot56, align 8
  %cmp1625 = icmp ult i64 %v1624, 32
  %cv1626 = zext i1 %cmp1625 to i32
  store i32 %cv1626, ptr %slot58, align 8
  %v1627 = load i32, ptr %slot57, align 8
  %v1628 = load i32, ptr %slot58, align 8
  %op1629 = or i32 %v1627, %v1628
  store i32 %op1629, ptr %slot59, align 8
  %v1630 = load i32, ptr %slot59, align 8
  %cv1631 = zext i32 %v1630 to i64
  %cond1632 = icmp ne i64 %cv1631, 0
  br i1 %cond1632, label %bb_rcmoveslow23, label %bb_rcmovecheck23
bb_rcmovecheck23:
  %v1633 = load i64, ptr %slot48, align 8
  %op1634 = add i64 %v1633, 0
  store i64 %op1634, ptr %slot60, align 8
  %v1635 = load i64, ptr %slot60, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i64, ptr %p1636, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1637, ptr %slot61, align 8
  %v1638 = load i64, ptr %slot61, align 8
  %cmp1639 = icmp ne i64 %v1638, 0
  %cv1640 = zext i1 %cmp1639 to i32
  store i32 %cv1640, ptr %slot62, align 8
  %v1641 = load i32, ptr %slot62, align 8
  %cv1642 = zext i32 %v1641 to i64
  %cond1643 = icmp ne i64 %cv1642, 0
  br i1 %cond1643, label %bb_rcmoveheader31, label %bb_rcmovenext31
bb_rcmoveheader31:
  %v1644 = load i64, ptr %slot61, align 8
  %op1645 = sub i64 %v1644, 16
  store i64 %op1645, ptr %slot63, align 8
  %v1646 = load i64, ptr %slot61, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %rgep1648 = getelementptr i8, ptr %p1647, i64 -16
  %ld1649 = load i64, ptr %rgep1648, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1649, ptr %slot64, align 8
  %v1650 = load i64, ptr %slot64, align 8
  %op1651 = and i64 %v1650, 5764607523034234881
  store i64 %op1651, ptr %slot65, align 8
  %v1652 = load i64, ptr %slot65, align 8
  %cmp1653 = icmp ne i64 %v1652, 0
  %cv1654 = zext i1 %cmp1653 to i32
  store i32 %cv1654, ptr %slot66, align 8
  %v1655 = load i32, ptr %slot66, align 8
  %cv1656 = zext i32 %v1655 to i64
  %cond1657 = icmp ne i64 %cv1656, 0
  br i1 %cond1657, label %bb_rcmoveslow23, label %bb_rcmovenext31
bb_rcmovenext31:
  %v1658 = load i64, ptr %slot48, align 8
  %v1659 = load i64, ptr %slot53, align 8
  %p1660 = inttoptr i64 %v1658 to ptr
  %p1661 = inttoptr i64 %v1659 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1661, ptr %p1660, i64 32, i1 false), !alias.scope !10000000
  %v1662 = load i64, ptr %slot48, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i64 0, ptr %p1663, align 8, !alias.scope !4, !noalias !3
  %v1664 = load i64, ptr %slot48, align 8
  %op1665 = add i64 %v1664, 8
  store i64 %op1665, ptr %slot67, align 8
  %v1666 = load i64, ptr %slot67, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 0, ptr %p1667, align 8, !alias.scope !4, !noalias !3
  %v1668 = load i64, ptr %slot48, align 8
  %op1669 = add i64 %v1668, 16
  store i64 %op1669, ptr %slot68, align 8
  %v1670 = load i64, ptr %slot68, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 0, ptr %p1671, align 8, !alias.scope !4, !noalias !3
  %v1672 = load i64, ptr %slot48, align 8
  %op1673 = add i64 %v1672, 24
  store i64 %op1673, ptr %slot69, align 8
  %v1674 = load i64, ptr %slot69, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved23
bb_rcmoveslow23:
  %v1676 = load i64, ptr %slot45, align 8
  %v1677 = load i64, ptr %slot53, align 8
  %v1678 = load i64, ptr %slot48, align 8
  %v1679 = load i64, ptr %slot54, align 8
  %cv1680 = trunc i64 %v1679 to i32
  %call1681 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1676, i64 %v1677, i64 %v1678, i32 %cv1680) nomerge, !dbg !112
  store i32 %call1681, ptr %slot70, align 8
  %v1682 = load i32, ptr %slot70, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcsuccess41, label %bb_rcfailure41
bb_rcfailure41:
  %v1685 = load i64, ptr %slot45, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %call1687 = call i32 @myl_rc_take_failure(ptr %p1686) nomerge, !dbg !112
  store i32 %call1687, ptr %slot71, align 8
  %v1688 = load i64, ptr %slot1, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %v1690 = load i32, ptr %slot71, align 8
  %call1691 = call i32 @myl_qbe_rc_status(ptr %p1689, i32 %v1690) nomerge, !dbg !112
  store i32 %call1691, ptr %slot72, align 8
  br label %bb_failure
bb_rcsuccess41:
  br label %bb_rcmoved23
bb_rcmoved23:
  %v1692 = load i64, ptr %slot18, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  store i32 0, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  %v1694 = load i64, ptr %slot23, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  store i32 2, ptr %p1695, align 4, !alias.scope !3, !noalias !4
  %v1696 = load i64, ptr %slot22, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i32 1, ptr %p1697, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rccopy14:
  %v1698 = load i64, ptr %slot28, align 8
  store i64 %v1698, ptr %slot73, align 8
  %v1699 = load i64, ptr %slot46, align 8
  store i64 %v1699, ptr %slot74, align 8
  %v1700 = load i64, ptr %slot45, align 8
  %v1701 = load i64, ptr %slot73, align 8
  %v1702 = load i64, ptr %slot48, align 8
  %v1703 = load i64, ptr %slot74, align 8
  %cv1704 = trunc i64 %v1703 to i32
  %call1705 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1700, i64 %v1701, i64 %v1702, i32 %cv1704) nomerge, !dbg !112
  store i32 %call1705, ptr %slot75, align 8
  %v1706 = load i32, ptr %slot75, align 8
  %cv1707 = zext i32 %v1706 to i64
  %cond1708 = icmp ne i64 %cv1707, 0
  br i1 %cond1708, label %bb_rcsuccess50, label %bb_rcfailure50
bb_rcfailure50:
  %v1709 = load i64, ptr %slot45, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %call1711 = call i32 @myl_rc_take_failure(ptr %p1710) nomerge, !dbg !112
  store i32 %call1711, ptr %slot76, align 8
  %v1712 = load i64, ptr %slot1, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %v1714 = load i32, ptr %slot76, align 8
  %call1715 = call i32 @myl_qbe_rc_status(ptr %p1713, i32 %v1714) nomerge, !dbg !112
  store i32 %call1715, ptr %slot77, align 8
  br label %bb_failure
bb_rcsuccess50:
  %v1716 = load i64, ptr %slot23, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  store i32 2, ptr %p1717, align 4, !alias.scope !3, !noalias !4
  %v1718 = load i64, ptr %slot22, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  store i32 1, ptr %p1719, align 4, !alias.scope !3, !noalias !4
  %v1720 = load i64, ptr %slot18, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  %ld1722 = load i32, ptr %p1721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1722, ptr %slot78, align 8
  %v1723 = load i32, ptr %slot78, align 8
  %cv1724 = zext i32 %v1723 to i64
  %cond1725 = icmp ne i64 %cv1724, 0
  br i1 %cond1725, label %bb_rcslotdrop57, label %bb_rcslotdone57
bb_rcslotdrop57:
  %v1726 = load i64, ptr %slot18, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 0, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot24, align 8
  store i64 %v1728, ptr %slot79, align 8
  %v1729 = load i64, ptr %slot19, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i32, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1731, ptr %slot80, align 8
  %v1732 = load i32, ptr %slot80, align 8
  %op1733 = and i32 %v1732, 28
  store i32 %op1733, ptr %slot81, align 8
  %v1734 = load i32, ptr %slot81, align 8
  %cv1735 = zext i32 %v1734 to i64
  %cond1736 = icmp ne i64 %cv1735, 0
  br i1 %cond1736, label %bb_rcslotrole57, label %bb_rcslotowner57
bb_rcslotrole57:
  %v1737 = load i64, ptr %slot45, align 8
  store i64 %v1737, ptr %slot82, align 8
  %v1738 = load i64, ptr %slot82, align 8
  %v1739 = load i64, ptr %slot79, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1738, i64 %v1739) nomerge, !dbg !112
  br label %bb_rcslotdone57
bb_rcslotowner57:
  %v1740 = load i64, ptr %slot79, align 8
  %p1742 = inttoptr i64 %v1740 to ptr
  %gep1743 = getelementptr i8, ptr %p1742, i64 0
  %op1741 = ptrtoint ptr %gep1743 to i64
  store i64 %op1741, ptr %slot83, align 8
  %v1744 = load i64, ptr %slot45, align 8
  store i64 %v1744, ptr %slot84, align 8
  %v1745 = load i64, ptr %slot83, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  %ld1747 = load i64, ptr %p1746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1747, ptr %slot85, align 8
  %v1748 = load i64, ptr %slot85, align 8
  %cmp1749 = icmp ne i64 %v1748, 0
  %cv1750 = zext i1 %cmp1749 to i32
  store i32 %cv1750, ptr %slot86, align 8
  %v1751 = load i32, ptr %slot86, align 8
  %cv1752 = zext i32 %v1751 to i64
  %cond1753 = icmp ne i64 %cv1752, 0
  br i1 %cond1753, label %bb_rcgnn75, label %bb_rcgdone75
bb_rcgnn75:
  %v1754 = load i64, ptr %slot85, align 8
  %op1755 = sub i64 %v1754, 16
  store i64 %op1755, ptr %slot87, align 8
  %v1756 = load i64, ptr %slot85, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %rgep1758 = getelementptr i8, ptr %p1757, i64 -16
  %ld1759 = load i64, ptr %rgep1758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1759, ptr %slot88, align 8
  %v1760 = load i64, ptr %slot88, align 8
  %op1761 = and i64 %v1760, 4611686018427387906
  store i64 %op1761, ptr %slot89, align 8
  %v1762 = load i64, ptr %slot89, align 8
  %cmp1763 = icmp ne i64 %v1762, 0
  %cv1764 = zext i1 %cmp1763 to i32
  store i32 %cv1764, ptr %slot90, align 8
  %v1765 = load i32, ptr %slot90, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcgclear75, label %bb_rcgcounted75
bb_rcgcounted75:
  %v1768 = load i64, ptr %slot85, align 8
  %op1769 = sub i64 %v1768, 32
  store i64 %op1769, ptr %slot91, align 8
  %v1770 = load i64, ptr %slot85, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  %rgep1772 = getelementptr i8, ptr %p1771, i64 -32
  %ld1773 = load i64, ptr %rgep1772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1773, ptr %slot92, align 8
  %v1774 = load i64, ptr %slot92, align 8
  %op1775 = sub i64 %v1774, 1
  store i64 %op1775, ptr %slot93, align 8
  %v1776 = load i64, ptr %slot93, align 8
  %cmp1777 = icmp eq i64 %v1776, 0
  %cv1778 = zext i1 %cmp1777 to i32
  store i32 %cv1778, ptr %slot94, align 8
  %v1779 = load i32, ptr %slot94, align 8
  %cv1780 = zext i32 %v1779 to i64
  %cond1781 = icmp ne i64 %cv1780, 0
  br i1 %cond1781, label %bb_rcglast75, label %bb_rcgdec75
bb_rcglast75:
  %v1782 = load i64, ptr %slot85, align 8
  %op1783 = sub i64 %v1782, 24
  store i64 %op1783, ptr %slot95, align 8
  %v1784 = load i64, ptr %slot85, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  %rgep1786 = getelementptr i8, ptr %p1785, i64 -24
  %ld1787 = load i64, ptr %rgep1786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1787, ptr %slot96, align 8
  %v1788 = load i64, ptr %slot96, align 8
  %cmp1789 = icmp ne i64 %v1788, 0
  %cv1790 = zext i1 %cmp1789 to i32
  store i32 %cv1790, ptr %slot97, align 8
  %v1791 = load i32, ptr %slot97, align 8
  %cv1792 = zext i32 %v1791 to i64
  %cond1793 = icmp ne i64 %cv1792, 0
  br i1 %cond1793, label %bb_rcgdec75, label %bb_rcgslow75
bb_rcgslow75:
  %v1794 = load i64, ptr %slot84, align 8
  %v1795 = load i64, ptr %slot83, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1794, i64 %v1795) nomerge, !dbg !112
  br label %bb_rcgdone75
bb_rcgdec75:
  %v1796 = load i64, ptr %slot93, align 8
  %v1797 = load i64, ptr %slot85, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %rgep1799 = getelementptr i8, ptr %p1798, i64 -32
  store i64 %v1796, ptr %rgep1799, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear75
bb_rcgclear75:
  %v1800 = load i64, ptr %slot83, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  store i64 0, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone75
bb_rcgdone75:
  %v1802 = load i64, ptr %slot79, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  store i64 0, ptr %p1803, align 8, !alias.scope !3, !noalias !4
  %v1804 = load i64, ptr %slot79, align 8
  %p1806 = inttoptr i64 %v1804 to ptr
  %gep1807 = getelementptr i8, ptr %p1806, i64 8
  %op1805 = ptrtoint ptr %gep1807 to i64
  store i64 %op1805, ptr %slot98, align 8
  %v1808 = load i64, ptr %slot98, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  store i64 0, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  %v1810 = load i64, ptr %slot79, align 8
  %p1812 = inttoptr i64 %v1810 to ptr
  %gep1813 = getelementptr i8, ptr %p1812, i64 16
  %op1811 = ptrtoint ptr %gep1813 to i64
  store i64 %op1811, ptr %slot99, align 8
  %v1814 = load i64, ptr %slot99, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  store i64 0, ptr %p1815, align 8, !alias.scope !3, !noalias !4
  %v1816 = load i64, ptr %slot79, align 8
  %p1818 = inttoptr i64 %v1816 to ptr
  %gep1819 = getelementptr i8, ptr %p1818, i64 24
  %op1817 = ptrtoint ptr %gep1819 to i64
  store i64 %op1817, ptr %slot100, align 8
  %v1820 = load i64, ptr %slot100, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i64 0, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone57
bb_rcslotdone57:
  br label %bb_rcprepared14
bb_rcprepared14:
  %v1822 = load i64, ptr %slot4, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i32, ptr %p1823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1824, ptr %slot101, align 8
  %v1825 = load i32, ptr %slot101, align 8
  %cv1826 = zext i32 %v1825 to i64
  %cond1827 = icmp ne i64 %cv1826, 0
  br i1 %cond1827, label %bb_rcslotdrop85, label %bb_rcslotdone85
bb_rcslotdrop85:
  %v1828 = load i64, ptr %slot4, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i32 0, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot35, align 8
  store i64 %v1830, ptr %slot102, align 8
  %v1831 = load i64, ptr %slot5, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  %ld1833 = load i32, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1833, ptr %slot103, align 8
  %v1834 = load i32, ptr %slot103, align 8
  %op1835 = and i32 %v1834, 28
  store i32 %op1835, ptr %slot104, align 8
  %v1836 = load i32, ptr %slot104, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcslotrole85, label %bb_rcslotowner85
bb_rcslotrole85:
  %v1839 = load i64, ptr %slot45, align 8
  store i64 %v1839, ptr %slot105, align 8
  %v1840 = load i64, ptr %slot105, align 8
  %v1841 = load i64, ptr %slot102, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1840, i64 %v1841) nomerge, !dbg !112
  br label %bb_rcslotdone85
bb_rcslotowner85:
  %v1842 = load i64, ptr %slot102, align 8
  %p1844 = inttoptr i64 %v1842 to ptr
  %gep1845 = getelementptr i8, ptr %p1844, i64 0
  %op1843 = ptrtoint ptr %gep1845 to i64
  store i64 %op1843, ptr %slot106, align 8
  %v1846 = load i64, ptr %slot45, align 8
  store i64 %v1846, ptr %slot107, align 8
  %v1847 = load i64, ptr %slot106, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %ld1849 = load i64, ptr %p1848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1849, ptr %slot108, align 8
  %v1850 = load i64, ptr %slot108, align 8
  %cmp1851 = icmp ne i64 %v1850, 0
  %cv1852 = zext i1 %cmp1851 to i32
  store i32 %cv1852, ptr %slot109, align 8
  %v1853 = load i32, ptr %slot109, align 8
  %cv1854 = zext i32 %v1853 to i64
  %cond1855 = icmp ne i64 %cv1854, 0
  br i1 %cond1855, label %bb_rcgnn103, label %bb_rcgdone103
bb_rcgnn103:
  %v1856 = load i64, ptr %slot108, align 8
  %op1857 = sub i64 %v1856, 16
  store i64 %op1857, ptr %slot110, align 8
  %v1858 = load i64, ptr %slot108, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %rgep1860 = getelementptr i8, ptr %p1859, i64 -16
  %ld1861 = load i64, ptr %rgep1860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1861, ptr %slot111, align 8
  %v1862 = load i64, ptr %slot111, align 8
  %op1863 = and i64 %v1862, 4611686018427387906
  store i64 %op1863, ptr %slot112, align 8
  %v1864 = load i64, ptr %slot112, align 8
  %cmp1865 = icmp ne i64 %v1864, 0
  %cv1866 = zext i1 %cmp1865 to i32
  store i32 %cv1866, ptr %slot113, align 8
  %v1867 = load i32, ptr %slot113, align 8
  %cv1868 = zext i32 %v1867 to i64
  %cond1869 = icmp ne i64 %cv1868, 0
  br i1 %cond1869, label %bb_rcgclear103, label %bb_rcgcounted103
bb_rcgcounted103:
  %v1870 = load i64, ptr %slot108, align 8
  %op1871 = sub i64 %v1870, 32
  store i64 %op1871, ptr %slot114, align 8
  %v1872 = load i64, ptr %slot108, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %rgep1874 = getelementptr i8, ptr %p1873, i64 -32
  %ld1875 = load i64, ptr %rgep1874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1875, ptr %slot115, align 8
  %v1876 = load i64, ptr %slot115, align 8
  %op1877 = sub i64 %v1876, 1
  store i64 %op1877, ptr %slot116, align 8
  %v1878 = load i64, ptr %slot116, align 8
  %cmp1879 = icmp eq i64 %v1878, 0
  %cv1880 = zext i1 %cmp1879 to i32
  store i32 %cv1880, ptr %slot117, align 8
  %v1881 = load i32, ptr %slot117, align 8
  %cv1882 = zext i32 %v1881 to i64
  %cond1883 = icmp ne i64 %cv1882, 0
  br i1 %cond1883, label %bb_rcglast103, label %bb_rcgdec103
bb_rcglast103:
  %v1884 = load i64, ptr %slot108, align 8
  %op1885 = sub i64 %v1884, 24
  store i64 %op1885, ptr %slot118, align 8
  %v1886 = load i64, ptr %slot108, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  %rgep1888 = getelementptr i8, ptr %p1887, i64 -24
  %ld1889 = load i64, ptr %rgep1888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1889, ptr %slot119, align 8
  %v1890 = load i64, ptr %slot119, align 8
  %cmp1891 = icmp ne i64 %v1890, 0
  %cv1892 = zext i1 %cmp1891 to i32
  store i32 %cv1892, ptr %slot120, align 8
  %v1893 = load i32, ptr %slot120, align 8
  %cv1894 = zext i32 %v1893 to i64
  %cond1895 = icmp ne i64 %cv1894, 0
  br i1 %cond1895, label %bb_rcgdec103, label %bb_rcgslow103
bb_rcgslow103:
  %v1896 = load i64, ptr %slot107, align 8
  %v1897 = load i64, ptr %slot106, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1896, i64 %v1897) nomerge, !dbg !112
  br label %bb_rcgdone103
bb_rcgdec103:
  %v1898 = load i64, ptr %slot116, align 8
  %v1899 = load i64, ptr %slot108, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %rgep1901 = getelementptr i8, ptr %p1900, i64 -32
  store i64 %v1898, ptr %rgep1901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear103
bb_rcgclear103:
  %v1902 = load i64, ptr %slot106, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i64 0, ptr %p1903, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone103
bb_rcgdone103:
  %v1904 = load i64, ptr %slot102, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i64 0, ptr %p1905, align 8, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot102, align 8
  %p1908 = inttoptr i64 %v1906 to ptr
  %gep1909 = getelementptr i8, ptr %p1908, i64 8
  %op1907 = ptrtoint ptr %gep1909 to i64
  store i64 %op1907, ptr %slot121, align 8
  %v1910 = load i64, ptr %slot121, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i64 0, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot102, align 8
  %p1914 = inttoptr i64 %v1912 to ptr
  %gep1915 = getelementptr i8, ptr %p1914, i64 16
  %op1913 = ptrtoint ptr %gep1915 to i64
  store i64 %op1913, ptr %slot122, align 8
  %v1916 = load i64, ptr %slot122, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i64 0, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot102, align 8
  %p1920 = inttoptr i64 %v1918 to ptr
  %gep1921 = getelementptr i8, ptr %p1920, i64 24
  %op1919 = ptrtoint ptr %gep1921 to i64
  store i64 %op1919, ptr %slot123, align 8
  %v1922 = load i64, ptr %slot123, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i64 0, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone85
bb_rcslotdone85:
  %v1924 = load i64, ptr %slot35, align 8
  store i64 %v1924, ptr %slot124, align 8
  %v1925 = load i64, ptr %slot28, align 8
  store i64 %v1925, ptr %slot125, align 8
  %v1926 = load i64, ptr %slot125, align 8
  %v1927 = load i64, ptr %slot124, align 8
  %p1928 = inttoptr i64 %v1926 to ptr
  %p1929 = inttoptr i64 %v1927 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1929, ptr %p1928, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1930 = load i64, ptr %slot22, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  store i32 0, ptr %p1931, align 4, !alias.scope !3, !noalias !4
  %v1932 = load i64, ptr %slot5, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i32 2, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot23, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  %ld1936 = load i32, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1936, ptr %slot126, align 8
  %v1937 = load i32, ptr %slot126, align 8
  %v1938 = load i64, ptr %slot5, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i32 %v1937, ptr %p1939, align 4, !alias.scope !3, !noalias !4
  %v1940 = load i64, ptr %slot4, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i32 1, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot35, align 8
  %v1943 = load i64, ptr %slot42, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i64 %v1942, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  %v1945 = load i64, ptr %slot42, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %ld1947 = load i64, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1947, ptr %slot127, align 8
  %v1948 = load i64, ptr %slot18, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  %ld1950 = load i32, ptr %p1949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1950, ptr %slot128, align 8
  %v1951 = load i64, ptr %slot19, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %ld1953 = load i32, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1953, ptr %slot129, align 8
  %v1954 = load i32, ptr %slot129, align 8
  %op1955 = and i32 %v1954, 24
  store i32 %op1955, ptr %slot129, align 8
  %v1956 = load i32, ptr %slot129, align 8
  %cmp1957 = icmp eq i32 %v1956, 0
  %cv1958 = zext i1 %cmp1957 to i32
  store i32 %cv1958, ptr %slot130, align 8
  %v1959 = load i32, ptr %slot128, align 8
  %v1960 = load i32, ptr %slot130, align 8
  %op1961 = and i32 %v1959, %v1960
  store i32 %op1961, ptr %slot131, align 8
  %v1962 = load i32, ptr %slot131, align 8
  %cv1963 = zext i32 %v1962 to i64
  %cond1964 = icmp ne i64 %cv1963, 0
  br i1 %cond1964, label %bb_rctake118, label %bb_rccopy118
bb_rctake118:
  %v1965 = load i64, ptr %slot28, align 8
  store i64 %v1965, ptr %slot132, align 8
  %v1966 = load i64, ptr %slot46, align 8
  store i64 %v1966, ptr %slot133, align 8
  %v1967 = load i64, ptr %slot127, align 8
  %v1968 = load i64, ptr %slot132, align 8
  %op1969 = sub i64 %v1967, %v1968
  store i64 %op1969, ptr %slot134, align 8
  %v1970 = load i64, ptr %slot132, align 8
  %v1971 = load i64, ptr %slot127, align 8
  %op1972 = sub i64 %v1970, %v1971
  store i64 %op1972, ptr %slot135, align 8
  %v1973 = load i64, ptr %slot134, align 8
  %cmp1974 = icmp ult i64 %v1973, 32
  %cv1975 = zext i1 %cmp1974 to i32
  store i32 %cv1975, ptr %slot136, align 8
  %v1976 = load i64, ptr %slot135, align 8
  %cmp1977 = icmp ult i64 %v1976, 32
  %cv1978 = zext i1 %cmp1977 to i32
  store i32 %cv1978, ptr %slot137, align 8
  %v1979 = load i32, ptr %slot136, align 8
  %v1980 = load i32, ptr %slot137, align 8
  %op1981 = or i32 %v1979, %v1980
  store i32 %op1981, ptr %slot138, align 8
  %v1982 = load i32, ptr %slot138, align 8
  %cv1983 = zext i32 %v1982 to i64
  %cond1984 = icmp ne i64 %cv1983, 0
  br i1 %cond1984, label %bb_rcmoveslow127, label %bb_rcmovecheck127
bb_rcmovecheck127:
  %v1985 = load i64, ptr %slot127, align 8
  %op1986 = add i64 %v1985, 0
  store i64 %op1986, ptr %slot139, align 8
  %v1987 = load i64, ptr %slot139, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %ld1989 = load i64, ptr %p1988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1989, ptr %slot140, align 8
  %v1990 = load i64, ptr %slot140, align 8
  %cmp1991 = icmp ne i64 %v1990, 0
  %cv1992 = zext i1 %cmp1991 to i32
  store i32 %cv1992, ptr %slot141, align 8
  %v1993 = load i32, ptr %slot141, align 8
  %cv1994 = zext i32 %v1993 to i64
  %cond1995 = icmp ne i64 %cv1994, 0
  br i1 %cond1995, label %bb_rcmoveheader135, label %bb_rcmovenext135
bb_rcmoveheader135:
  %v1996 = load i64, ptr %slot140, align 8
  %op1997 = sub i64 %v1996, 16
  store i64 %op1997, ptr %slot142, align 8
  %v1998 = load i64, ptr %slot140, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %rgep2000 = getelementptr i8, ptr %p1999, i64 -16
  %ld2001 = load i64, ptr %rgep2000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2001, ptr %slot143, align 8
  %v2002 = load i64, ptr %slot143, align 8
  %op2003 = and i64 %v2002, 5764607523034234881
  store i64 %op2003, ptr %slot144, align 8
  %v2004 = load i64, ptr %slot144, align 8
  %cmp2005 = icmp ne i64 %v2004, 0
  %cv2006 = zext i1 %cmp2005 to i32
  store i32 %cv2006, ptr %slot145, align 8
  %v2007 = load i32, ptr %slot145, align 8
  %cv2008 = zext i32 %v2007 to i64
  %cond2009 = icmp ne i64 %cv2008, 0
  br i1 %cond2009, label %bb_rcmoveslow127, label %bb_rcmovenext135
bb_rcmovenext135:
  %v2010 = load i64, ptr %slot127, align 8
  %v2011 = load i64, ptr %slot132, align 8
  %p2012 = inttoptr i64 %v2010 to ptr
  %p2013 = inttoptr i64 %v2011 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2013, ptr %p2012, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2014 = load i64, ptr %slot127, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  store i64 0, ptr %p2015, align 8, !alias.scope !3, !noalias !4
  %v2016 = load i64, ptr %slot127, align 8
  %op2017 = add i64 %v2016, 8
  store i64 %op2017, ptr %slot146, align 8
  %v2018 = load i64, ptr %slot146, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i64 0, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot127, align 8
  %op2021 = add i64 %v2020, 16
  store i64 %op2021, ptr %slot147, align 8
  %v2022 = load i64, ptr %slot147, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  store i64 0, ptr %p2023, align 8, !alias.scope !3, !noalias !4
  %v2024 = load i64, ptr %slot127, align 8
  %op2025 = add i64 %v2024, 24
  store i64 %op2025, ptr %slot148, align 8
  %v2026 = load i64, ptr %slot148, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  store i64 0, ptr %p2027, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved127
bb_rcmoveslow127:
  %v2028 = load i64, ptr %slot45, align 8
  %v2029 = load i64, ptr %slot132, align 8
  %v2030 = load i64, ptr %slot127, align 8
  %v2031 = load i64, ptr %slot133, align 8
  %cv2032 = trunc i64 %v2031 to i32
  %call2033 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2028, i64 %v2029, i64 %v2030, i32 %cv2032) nomerge, !dbg !114
  store i32 %call2033, ptr %slot149, align 8
  %v2034 = load i32, ptr %slot149, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcsuccess145, label %bb_rcfailure145
bb_rcfailure145:
  %v2037 = load i64, ptr %slot45, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %call2039 = call i32 @myl_rc_take_failure(ptr %p2038) nomerge, !dbg !114
  store i32 %call2039, ptr %slot150, align 8
  %v2040 = load i64, ptr %slot1, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %v2042 = load i32, ptr %slot150, align 8
  %call2043 = call i32 @myl_qbe_rc_status(ptr %p2041, i32 %v2042) nomerge, !dbg !114
  store i32 %call2043, ptr %slot151, align 8
  br label %bb_failure
bb_rcsuccess145:
  br label %bb_rcmoved127
bb_rcmoved127:
  %v2044 = load i64, ptr %slot18, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  store i32 0, ptr %p2045, align 4, !alias.scope !3, !noalias !4
  %v2046 = load i64, ptr %slot23, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i32 2, ptr %p2047, align 4, !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot22, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i32 1, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared118
bb_rccopy118:
  %v2050 = load i64, ptr %slot28, align 8
  store i64 %v2050, ptr %slot152, align 8
  %v2051 = load i64, ptr %slot46, align 8
  store i64 %v2051, ptr %slot153, align 8
  %v2052 = load i64, ptr %slot45, align 8
  %v2053 = load i64, ptr %slot152, align 8
  %v2054 = load i64, ptr %slot127, align 8
  %v2055 = load i64, ptr %slot153, align 8
  %cv2056 = trunc i64 %v2055 to i32
  %call2057 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v2052, i64 %v2053, i64 %v2054, i32 %cv2056) nomerge, !dbg !114
  store i32 %call2057, ptr %slot154, align 8
  %v2058 = load i32, ptr %slot154, align 8
  %cv2059 = zext i32 %v2058 to i64
  %cond2060 = icmp ne i64 %cv2059, 0
  br i1 %cond2060, label %bb_rcsuccess154, label %bb_rcfailure154
bb_rcfailure154:
  %v2061 = load i64, ptr %slot45, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %call2063 = call i32 @myl_rc_take_failure(ptr %p2062) nomerge, !dbg !114
  store i32 %call2063, ptr %slot155, align 8
  %v2064 = load i64, ptr %slot1, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  %v2066 = load i32, ptr %slot155, align 8
  %call2067 = call i32 @myl_qbe_rc_status(ptr %p2065, i32 %v2066) nomerge, !dbg !114
  store i32 %call2067, ptr %slot156, align 8
  br label %bb_failure
bb_rcsuccess154:
  %v2068 = load i64, ptr %slot23, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  store i32 2, ptr %p2069, align 4, !alias.scope !3, !noalias !4
  %v2070 = load i64, ptr %slot22, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i32 1, ptr %p2071, align 4, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot18, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %ld2074 = load i32, ptr %p2073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2074, ptr %slot157, align 8
  %v2075 = load i32, ptr %slot157, align 8
  %cv2076 = zext i32 %v2075 to i64
  %cond2077 = icmp ne i64 %cv2076, 0
  br i1 %cond2077, label %bb_rcslotdrop161, label %bb_rcslotdone161
bb_rcslotdrop161:
  %v2078 = load i64, ptr %slot18, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i32 0, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot24, align 8
  store i64 %v2080, ptr %slot158, align 8
  %v2081 = load i64, ptr %slot19, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  %ld2083 = load i32, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2083, ptr %slot159, align 8
  %v2084 = load i32, ptr %slot159, align 8
  %op2085 = and i32 %v2084, 28
  store i32 %op2085, ptr %slot160, align 8
  %v2086 = load i32, ptr %slot160, align 8
  %cv2087 = zext i32 %v2086 to i64
  %cond2088 = icmp ne i64 %cv2087, 0
  br i1 %cond2088, label %bb_rcslotrole161, label %bb_rcslotowner161
bb_rcslotrole161:
  %v2089 = load i64, ptr %slot45, align 8
  store i64 %v2089, ptr %slot161, align 8
  %v2090 = load i64, ptr %slot161, align 8
  %v2091 = load i64, ptr %slot158, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2090, i64 %v2091) nomerge, !dbg !114
  br label %bb_rcslotdone161
bb_rcslotowner161:
  %v2092 = load i64, ptr %slot158, align 8
  %p2094 = inttoptr i64 %v2092 to ptr
  %gep2095 = getelementptr i8, ptr %p2094, i64 0
  %op2093 = ptrtoint ptr %gep2095 to i64
  store i64 %op2093, ptr %slot162, align 8
  %v2096 = load i64, ptr %slot45, align 8
  store i64 %v2096, ptr %slot163, align 8
  %v2097 = load i64, ptr %slot162, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  %ld2099 = load i64, ptr %p2098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2099, ptr %slot164, align 8
  %v2100 = load i64, ptr %slot164, align 8
  %cmp2101 = icmp ne i64 %v2100, 0
  %cv2102 = zext i1 %cmp2101 to i32
  store i32 %cv2102, ptr %slot165, align 8
  %v2103 = load i32, ptr %slot165, align 8
  %cv2104 = zext i32 %v2103 to i64
  %cond2105 = icmp ne i64 %cv2104, 0
  br i1 %cond2105, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v2106 = load i64, ptr %slot164, align 8
  %op2107 = sub i64 %v2106, 16
  store i64 %op2107, ptr %slot166, align 8
  %v2108 = load i64, ptr %slot164, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %rgep2110 = getelementptr i8, ptr %p2109, i64 -16
  %ld2111 = load i64, ptr %rgep2110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2111, ptr %slot167, align 8
  %v2112 = load i64, ptr %slot167, align 8
  %op2113 = and i64 %v2112, 4611686018427387906
  store i64 %op2113, ptr %slot168, align 8
  %v2114 = load i64, ptr %slot168, align 8
  %cmp2115 = icmp ne i64 %v2114, 0
  %cv2116 = zext i1 %cmp2115 to i32
  store i32 %cv2116, ptr %slot169, align 8
  %v2117 = load i32, ptr %slot169, align 8
  %cv2118 = zext i32 %v2117 to i64
  %cond2119 = icmp ne i64 %cv2118, 0
  br i1 %cond2119, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v2120 = load i64, ptr %slot164, align 8
  %op2121 = sub i64 %v2120, 32
  store i64 %op2121, ptr %slot170, align 8
  %v2122 = load i64, ptr %slot164, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %rgep2124 = getelementptr i8, ptr %p2123, i64 -32
  %ld2125 = load i64, ptr %rgep2124, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2125, ptr %slot171, align 8
  %v2126 = load i64, ptr %slot171, align 8
  %op2127 = sub i64 %v2126, 1
  store i64 %op2127, ptr %slot172, align 8
  %v2128 = load i64, ptr %slot172, align 8
  %cmp2129 = icmp eq i64 %v2128, 0
  %cv2130 = zext i1 %cmp2129 to i32
  store i32 %cv2130, ptr %slot173, align 8
  %v2131 = load i32, ptr %slot173, align 8
  %cv2132 = zext i32 %v2131 to i64
  %cond2133 = icmp ne i64 %cv2132, 0
  br i1 %cond2133, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v2134 = load i64, ptr %slot164, align 8
  %op2135 = sub i64 %v2134, 24
  store i64 %op2135, ptr %slot174, align 8
  %v2136 = load i64, ptr %slot164, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %rgep2138 = getelementptr i8, ptr %p2137, i64 -24
  %ld2139 = load i64, ptr %rgep2138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2139, ptr %slot175, align 8
  %v2140 = load i64, ptr %slot175, align 8
  %cmp2141 = icmp ne i64 %v2140, 0
  %cv2142 = zext i1 %cmp2141 to i32
  store i32 %cv2142, ptr %slot176, align 8
  %v2143 = load i32, ptr %slot176, align 8
  %cv2144 = zext i32 %v2143 to i64
  %cond2145 = icmp ne i64 %cv2144, 0
  br i1 %cond2145, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v2146 = load i64, ptr %slot163, align 8
  %v2147 = load i64, ptr %slot162, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2146, i64 %v2147) nomerge, !dbg !114
  br label %bb_rcgdone179
bb_rcgdec179:
  %v2148 = load i64, ptr %slot172, align 8
  %v2149 = load i64, ptr %slot164, align 8
  %p2150 = inttoptr i64 %v2149 to ptr
  %rgep2151 = getelementptr i8, ptr %p2150, i64 -32
  store i64 %v2148, ptr %rgep2151, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v2152 = load i64, ptr %slot162, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  store i64 0, ptr %p2153, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  %v2154 = load i64, ptr %slot158, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  store i64 0, ptr %p2155, align 8, !alias.scope !3, !noalias !4
  %v2156 = load i64, ptr %slot158, align 8
  %p2158 = inttoptr i64 %v2156 to ptr
  %gep2159 = getelementptr i8, ptr %p2158, i64 8
  %op2157 = ptrtoint ptr %gep2159 to i64
  store i64 %op2157, ptr %slot177, align 8
  %v2160 = load i64, ptr %slot177, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i64 0, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot158, align 8
  %p2164 = inttoptr i64 %v2162 to ptr
  %gep2165 = getelementptr i8, ptr %p2164, i64 16
  %op2163 = ptrtoint ptr %gep2165 to i64
  store i64 %op2163, ptr %slot178, align 8
  %v2166 = load i64, ptr %slot178, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i64 0, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot158, align 8
  %p2170 = inttoptr i64 %v2168 to ptr
  %gep2171 = getelementptr i8, ptr %p2170, i64 24
  %op2169 = ptrtoint ptr %gep2171 to i64
  store i64 %op2169, ptr %slot179, align 8
  %v2172 = load i64, ptr %slot179, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  store i64 0, ptr %p2173, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone161
bb_rcslotdone161:
  br label %bb_rcprepared118
bb_rcprepared118:
  %v2174 = load i64, ptr %slot6, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %ld2176 = load i32, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2176, ptr %slot180, align 8
  %v2177 = load i32, ptr %slot180, align 8
  %cv2178 = zext i32 %v2177 to i64
  %cond2179 = icmp ne i64 %cv2178, 0
  br i1 %cond2179, label %bb_rcslotdrop189, label %bb_rcslotdone189
bb_rcslotdrop189:
  %v2180 = load i64, ptr %slot6, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 0, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot36, align 8
  store i64 %v2182, ptr %slot181, align 8
  %v2183 = load i64, ptr %slot7, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  %ld2185 = load i32, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2185, ptr %slot182, align 8
  %v2186 = load i32, ptr %slot182, align 8
  %op2187 = and i32 %v2186, 28
  store i32 %op2187, ptr %slot183, align 8
  %v2188 = load i32, ptr %slot183, align 8
  %cv2189 = zext i32 %v2188 to i64
  %cond2190 = icmp ne i64 %cv2189, 0
  br i1 %cond2190, label %bb_rcslotrole189, label %bb_rcslotowner189
bb_rcslotrole189:
  %v2191 = load i64, ptr %slot45, align 8
  store i64 %v2191, ptr %slot184, align 8
  %v2192 = load i64, ptr %slot184, align 8
  %v2193 = load i64, ptr %slot181, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2192, i64 %v2193) nomerge, !dbg !114
  br label %bb_rcslotdone189
bb_rcslotowner189:
  %v2194 = load i64, ptr %slot181, align 8
  %p2196 = inttoptr i64 %v2194 to ptr
  %gep2197 = getelementptr i8, ptr %p2196, i64 0
  %op2195 = ptrtoint ptr %gep2197 to i64
  store i64 %op2195, ptr %slot185, align 8
  %v2198 = load i64, ptr %slot45, align 8
  store i64 %v2198, ptr %slot186, align 8
  %v2199 = load i64, ptr %slot185, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot187, align 8
  %v2202 = load i64, ptr %slot187, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot188, align 8
  %v2205 = load i32, ptr %slot188, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcgnn207, label %bb_rcgdone207
bb_rcgnn207:
  %v2208 = load i64, ptr %slot187, align 8
  %op2209 = sub i64 %v2208, 16
  store i64 %op2209, ptr %slot189, align 8
  %v2210 = load i64, ptr %slot187, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -16
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot190, align 8
  %v2214 = load i64, ptr %slot190, align 8
  %op2215 = and i64 %v2214, 4611686018427387906
  store i64 %op2215, ptr %slot191, align 8
  %v2216 = load i64, ptr %slot191, align 8
  %cmp2217 = icmp ne i64 %v2216, 0
  %cv2218 = zext i1 %cmp2217 to i32
  store i32 %cv2218, ptr %slot192, align 8
  %v2219 = load i32, ptr %slot192, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcgclear207, label %bb_rcgcounted207
bb_rcgcounted207:
  %v2222 = load i64, ptr %slot187, align 8
  %op2223 = sub i64 %v2222, 32
  store i64 %op2223, ptr %slot193, align 8
  %v2224 = load i64, ptr %slot187, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %rgep2226 = getelementptr i8, ptr %p2225, i64 -32
  %ld2227 = load i64, ptr %rgep2226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2227, ptr %slot194, align 8
  %v2228 = load i64, ptr %slot194, align 8
  %op2229 = sub i64 %v2228, 1
  store i64 %op2229, ptr %slot195, align 8
  %v2230 = load i64, ptr %slot195, align 8
  %cmp2231 = icmp eq i64 %v2230, 0
  %cv2232 = zext i1 %cmp2231 to i32
  store i32 %cv2232, ptr %slot196, align 8
  %v2233 = load i32, ptr %slot196, align 8
  %cv2234 = zext i32 %v2233 to i64
  %cond2235 = icmp ne i64 %cv2234, 0
  br i1 %cond2235, label %bb_rcglast207, label %bb_rcgdec207
bb_rcglast207:
  %v2236 = load i64, ptr %slot187, align 8
  %op2237 = sub i64 %v2236, 24
  store i64 %op2237, ptr %slot197, align 8
  %v2238 = load i64, ptr %slot187, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %rgep2240 = getelementptr i8, ptr %p2239, i64 -24
  %ld2241 = load i64, ptr %rgep2240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2241, ptr %slot198, align 8
  %v2242 = load i64, ptr %slot198, align 8
  %cmp2243 = icmp ne i64 %v2242, 0
  %cv2244 = zext i1 %cmp2243 to i32
  store i32 %cv2244, ptr %slot199, align 8
  %v2245 = load i32, ptr %slot199, align 8
  %cv2246 = zext i32 %v2245 to i64
  %cond2247 = icmp ne i64 %cv2246, 0
  br i1 %cond2247, label %bb_rcgdec207, label %bb_rcgslow207
bb_rcgslow207:
  %v2248 = load i64, ptr %slot186, align 8
  %v2249 = load i64, ptr %slot185, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2248, i64 %v2249) nomerge, !dbg !114
  br label %bb_rcgdone207
bb_rcgdec207:
  %v2250 = load i64, ptr %slot195, align 8
  %v2251 = load i64, ptr %slot187, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %rgep2253 = getelementptr i8, ptr %p2252, i64 -32
  store i64 %v2250, ptr %rgep2253, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear207
bb_rcgclear207:
  %v2254 = load i64, ptr %slot185, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 0, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone207
bb_rcgdone207:
  %v2256 = load i64, ptr %slot181, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i64 0, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot181, align 8
  %p2260 = inttoptr i64 %v2258 to ptr
  %gep2261 = getelementptr i8, ptr %p2260, i64 8
  %op2259 = ptrtoint ptr %gep2261 to i64
  store i64 %op2259, ptr %slot200, align 8
  %v2262 = load i64, ptr %slot200, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i64 0, ptr %p2263, align 8, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot181, align 8
  %p2266 = inttoptr i64 %v2264 to ptr
  %gep2267 = getelementptr i8, ptr %p2266, i64 16
  %op2265 = ptrtoint ptr %gep2267 to i64
  store i64 %op2265, ptr %slot201, align 8
  %v2268 = load i64, ptr %slot201, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  store i64 0, ptr %p2269, align 8, !alias.scope !3, !noalias !4
  %v2270 = load i64, ptr %slot181, align 8
  %p2272 = inttoptr i64 %v2270 to ptr
  %gep2273 = getelementptr i8, ptr %p2272, i64 24
  %op2271 = ptrtoint ptr %gep2273 to i64
  store i64 %op2271, ptr %slot202, align 8
  %v2274 = load i64, ptr %slot202, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 0, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone189
bb_rcslotdone189:
  %v2276 = load i64, ptr %slot36, align 8
  store i64 %v2276, ptr %slot203, align 8
  %v2277 = load i64, ptr %slot28, align 8
  store i64 %v2277, ptr %slot204, align 8
  %v2278 = load i64, ptr %slot204, align 8
  %v2279 = load i64, ptr %slot203, align 8
  %p2280 = inttoptr i64 %v2278 to ptr
  %p2281 = inttoptr i64 %v2279 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2281, ptr %p2280, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot22, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i32 0, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  %v2284 = load i64, ptr %slot7, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 2, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot23, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i32, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2288, ptr %slot205, align 8
  %v2289 = load i32, ptr %slot205, align 8
  %v2290 = load i64, ptr %slot7, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  store i32 %v2289, ptr %p2291, align 4, !alias.scope !3, !noalias !4
  %v2292 = load i64, ptr %slot6, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  store i32 1, ptr %p2293, align 4, !alias.scope !3, !noalias !4
  %v2294 = load i64, ptr %slot36, align 8
  %v2295 = load i64, ptr %slot42, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  store i64 %v2294, ptr %p2296, align 8, !alias.scope !3, !noalias !4
  %v2297 = load i64, ptr %slot42, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %ld2299 = load i64, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2299, ptr %slot206, align 8
  %v2300 = load i64, ptr %slot206, align 8
  %op2301 = add i64 %v2300, 16
  store i64 %op2301, ptr %slot207, align 8
  %v2302 = load i64, ptr %slot207, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %ld2304 = load i64, ptr %p2303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2304, ptr %slot208, align 8
  %v2305 = load i64, ptr %slot208, align 8
  %v2306 = load i64, ptr %slot42, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  store i64 %v2305, ptr %p2307, align 8, !alias.scope !3, !noalias !4
  %v2308 = load i64, ptr %slot18, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  %ld2310 = load i32, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2310, ptr %slot209, align 8
  %v2311 = load i32, ptr %slot209, align 8
  %cv2312 = zext i32 %v2311 to i64
  %cond2313 = icmp ne i64 %cv2312, 0
  br i1 %cond2313, label %bb_rcslotdrop226, label %bb_rcslotdone226
bb_rcslotdrop226:
  %v2314 = load i64, ptr %slot18, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 0, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot24, align 8
  store i64 %v2316, ptr %slot210, align 8
  %v2317 = load i64, ptr %slot19, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %ld2319 = load i32, ptr %p2318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2319, ptr %slot211, align 8
  %v2320 = load i32, ptr %slot211, align 8
  %op2321 = and i32 %v2320, 28
  store i32 %op2321, ptr %slot212, align 8
  %v2322 = load i32, ptr %slot212, align 8
  %cv2323 = zext i32 %v2322 to i64
  %cond2324 = icmp ne i64 %cv2323, 0
  br i1 %cond2324, label %bb_rcslotrole226, label %bb_rcslotowner226
bb_rcslotrole226:
  %v2325 = load i64, ptr %slot45, align 8
  store i64 %v2325, ptr %slot213, align 8
  %v2326 = load i64, ptr %slot213, align 8
  %v2327 = load i64, ptr %slot210, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2326, i64 %v2327) nomerge, !dbg !116
  br label %bb_rcslotdone226
bb_rcslotowner226:
  %v2328 = load i64, ptr %slot45, align 8
  store i64 %v2328, ptr %slot214, align 8
  %v2329 = load i64, ptr %slot214, align 8
  %v2330 = load i64, ptr %slot210, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2329, i64 %v2330) nomerge, !dbg !116
  br label %bb_rcslotdone226
bb_rcslotdone226:
  %v2331 = load i64, ptr %slot36, align 8
  %v2332 = load i64, ptr %slot43, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  store i64 %v2331, ptr %p2333, align 8, !alias.scope !3, !noalias !4
  %v2334 = load i64, ptr %slot43, align 8
  %p2335 = inttoptr i64 %v2334 to ptr
  %ld2336 = load i64, ptr %p2335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2336, ptr %slot215, align 8
  %v2337 = load i64, ptr %slot215, align 8
  %op2338 = add i64 %v2337, 0
  store i64 %op2338, ptr %slot216, align 8
  %v2339 = load i64, ptr %slot216, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %ld2341 = load i64, ptr %p2340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2341, ptr %slot217, align 8
  %v2342 = load i64, ptr %slot217, align 8
  %v2343 = load i64, ptr %slot43, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  store i64 %v2342, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot43, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %ld2347 = load i64, ptr %p2346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2347, ptr %slot218, align 8
  %v2348 = load i64, ptr %slot218, align 8
  %v2349 = load i64, ptr %slot27, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot27, align 8
  store i64 %v2351, ptr %slot219, align 8
  %v2352 = load i64, ptr %slot28, align 8
  store i64 %v2352, ptr %slot220, align 8
  %v2353 = load i64, ptr %slot219, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  %ld2355 = load i64, ptr %p2354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2355, ptr %slot221, align 8
  %v2356 = load i64, ptr %slot221, align 8
  %cmp2357 = icmp ne i64 %v2356, 0
  %cv2358 = zext i1 %cmp2357 to i32
  store i32 %cv2358, ptr %slot222, align 8
  %v2359 = load i32, ptr %slot222, align 8
  %cv2360 = zext i32 %v2359 to i64
  %cond2361 = icmp ne i64 %cv2360, 0
  br i1 %cond2361, label %bb_rcgnn240, label %bb_rcgstore240
bb_rcgnn240:
  %v2362 = load i64, ptr %slot221, align 8
  %op2363 = sub i64 %v2362, 16
  store i64 %op2363, ptr %slot223, align 8
  %v2364 = load i64, ptr %slot221, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %rgep2366 = getelementptr i8, ptr %p2365, i64 -16
  %ld2367 = load i64, ptr %rgep2366, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2367, ptr %slot224, align 8
  %v2368 = load i64, ptr %slot224, align 8
  %op2369 = and i64 %v2368, 4611686018427387906
  store i64 %op2369, ptr %slot225, align 8
  %v2370 = load i64, ptr %slot225, align 8
  %cmp2371 = icmp ne i64 %v2370, 0
  %cv2372 = zext i1 %cmp2371 to i32
  store i32 %cv2372, ptr %slot226, align 8
  %v2373 = load i32, ptr %slot226, align 8
  %cv2374 = zext i32 %v2373 to i64
  %cond2375 = icmp ne i64 %cv2374, 0
  br i1 %cond2375, label %bb_rcgstore240, label %bb_rcginc240
bb_rcginc240:
  %v2376 = load i64, ptr %slot221, align 8
  %op2377 = sub i64 %v2376, 24
  store i64 %op2377, ptr %slot227, align 8
  %v2378 = load i64, ptr %slot221, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %rgep2380 = getelementptr i8, ptr %p2379, i64 -24
  %ld2381 = load i64, ptr %rgep2380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2381, ptr %slot228, align 8
  %v2382 = load i64, ptr %slot228, align 8
  %op2383 = add i64 %v2382, 1
  store i64 %op2383, ptr %slot229, align 8
  %v2384 = load i64, ptr %slot229, align 8
  %cmp2385 = icmp eq i64 %v2384, 0
  %cv2386 = zext i1 %cmp2385 to i32
  store i32 %cv2386, ptr %slot230, align 8
  %v2387 = load i32, ptr %slot230, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcglimit240, label %bb_rcgcapacity240
bb_rcglimit240:
  %v2390 = load i64, ptr %slot1, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %call2392 = call i32 @myl_qbe_rc_status(ptr %p2391, i32 2) nomerge, !dbg !118
  store i32 %call2392, ptr %slot231, align 8
  br label %bb_failure
bb_rcgcapacity240:
  %v2393 = load i64, ptr %slot229, align 8
  %v2394 = load i64, ptr %slot221, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %rgep2396 = getelementptr i8, ptr %p2395, i64 -24
  store i64 %v2393, ptr %rgep2396, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore240
bb_rcgstore240:
  %v2397 = load i64, ptr %slot221, align 8
  %v2398 = load i64, ptr %slot220, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot23, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i32 2, ptr %p2401, align 4, !alias.scope !3, !noalias !4
  %v2402 = load i64, ptr %slot23, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  store i32 16, ptr %p2403, align 4, !alias.scope !3, !noalias !4
  %v2404 = load i64, ptr %slot22, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i32 1, ptr %p2405, align 4, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot20, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  %ld2408 = load i32, ptr %p2407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2408, ptr %slot232, align 8
  %v2409 = load i32, ptr %slot232, align 8
  %cv2410 = zext i32 %v2409 to i64
  %cond2411 = icmp ne i64 %cv2410, 0
  br i1 %cond2411, label %bb_rcslotdrop256, label %bb_rcslotdone256
bb_rcslotdrop256:
  %v2412 = load i64, ptr %slot20, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i32 0, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  %v2414 = load i64, ptr %slot25, align 8
  store i64 %v2414, ptr %slot233, align 8
  %v2415 = load i64, ptr %slot21, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i32, ptr %p2416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2417, ptr %slot234, align 8
  %v2418 = load i32, ptr %slot234, align 8
  %op2419 = and i32 %v2418, 28
  store i32 %op2419, ptr %slot235, align 8
  %v2420 = load i32, ptr %slot235, align 8
  %cv2421 = zext i32 %v2420 to i64
  %cond2422 = icmp ne i64 %cv2421, 0
  br i1 %cond2422, label %bb_rcslotrole256, label %bb_rcslotowner256
bb_rcslotrole256:
  %v2423 = load i64, ptr %slot45, align 8
  store i64 %v2423, ptr %slot236, align 8
  %v2424 = load i64, ptr %slot236, align 8
  %v2425 = load i64, ptr %slot233, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2424, i64 %v2425) nomerge, !dbg !118
  br label %bb_rcslotdone256
bb_rcslotowner256:
  %v2426 = load i64, ptr %slot45, align 8
  store i64 %v2426, ptr %slot237, align 8
  %v2427 = load i64, ptr %slot237, align 8
  %v2428 = load i64, ptr %slot233, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2427, i64 %v2428) nomerge, !dbg !118
  br label %bb_rcslotdone256
bb_rcslotdone256:
  %v2429 = load i64, ptr %slot25, align 8
  store i64 %v2429, ptr %slot238, align 8
  %v2430 = load i64, ptr %slot28, align 8
  store i64 %v2430, ptr %slot239, align 8
  %v2431 = load i64, ptr %slot239, align 8
  %v2432 = load i64, ptr %slot238, align 8
  %p2433 = inttoptr i64 %v2431 to ptr
  %p2434 = inttoptr i64 %v2432 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2434, ptr %p2433, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot21, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  store i32 2, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  %v2437 = load i64, ptr %slot23, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i32, ptr %p2438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2439, ptr %slot240, align 8
  %v2440 = load i32, ptr %slot240, align 8
  %v2441 = load i64, ptr %slot21, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 %v2440, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot22, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  store i32 0, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  %v2445 = load i64, ptr %slot20, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  store i32 1, ptr %p2446, align 4, !alias.scope !3, !noalias !4
  %v2447 = load i64, ptr %slot238, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  %ld2449 = load i64, ptr %p2448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2449, ptr %slot241, align 8
  %v2450 = load i64, ptr %slot241, align 8
  %v2451 = load i64, ptr %slot43, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  store i64 %v2450, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  %v2453 = load i64, ptr %slot43, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2455, ptr %slot242, align 8
  %v2456 = load i64, ptr %slot242, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i64, ptr %p2457, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2458, ptr %slot243, align 8
  %v2459 = load i64, ptr %slot243, align 8
  %v2460 = load i64, ptr %slot43, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i64 %v2459, ptr %p2461, align 8, !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot20, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %ld2464 = load i32, ptr %p2463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2464, ptr %slot244, align 8
  %v2465 = load i32, ptr %slot244, align 8
  %cv2466 = zext i32 %v2465 to i64
  %cond2467 = icmp ne i64 %cv2466, 0
  br i1 %cond2467, label %bb_rcslotdrop276, label %bb_rcslotdone276
bb_rcslotdrop276:
  %v2468 = load i64, ptr %slot20, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 0, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot25, align 8
  store i64 %v2470, ptr %slot245, align 8
  %v2471 = load i64, ptr %slot21, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %ld2473 = load i32, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2473, ptr %slot246, align 8
  %v2474 = load i32, ptr %slot246, align 8
  %op2475 = and i32 %v2474, 28
  store i32 %op2475, ptr %slot247, align 8
  %v2476 = load i32, ptr %slot247, align 8
  %cv2477 = zext i32 %v2476 to i64
  %cond2478 = icmp ne i64 %cv2477, 0
  br i1 %cond2478, label %bb_rcslotrole276, label %bb_rcslotowner276
bb_rcslotrole276:
  %v2479 = load i64, ptr %slot45, align 8
  store i64 %v2479, ptr %slot248, align 8
  %v2480 = load i64, ptr %slot245, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %ld2482 = load i64, ptr %p2481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2482, ptr %slot249, align 8
  %v2483 = load i64, ptr %slot249, align 8
  %cmp2484 = icmp ne i64 %v2483, 0
  %cv2485 = zext i1 %cmp2484 to i32
  store i32 %cv2485, ptr %slot250, align 8
  %v2486 = load i32, ptr %slot250, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcgnn292, label %bb_rcgdone292
bb_rcgnn292:
  %v2489 = load i64, ptr %slot249, align 8
  %op2490 = sub i64 %v2489, 16
  store i64 %op2490, ptr %slot251, align 8
  %v2491 = load i64, ptr %slot249, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %rgep2493 = getelementptr i8, ptr %p2492, i64 -16
  %ld2494 = load i64, ptr %rgep2493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2494, ptr %slot252, align 8
  %v2495 = load i64, ptr %slot252, align 8
  %op2496 = and i64 %v2495, 4611686018427387906
  store i64 %op2496, ptr %slot253, align 8
  %v2497 = load i64, ptr %slot253, align 8
  %cmp2498 = icmp ne i64 %v2497, 0
  %cv2499 = zext i1 %cmp2498 to i32
  store i32 %cv2499, ptr %slot254, align 8
  %v2500 = load i32, ptr %slot254, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcgclear292, label %bb_rcgcounted292
bb_rcgcounted292:
  %v2503 = load i64, ptr %slot249, align 8
  %op2504 = sub i64 %v2503, 24
  store i64 %op2504, ptr %slot255, align 8
  %v2505 = load i64, ptr %slot249, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -24
  %ld2508 = load i64, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2508, ptr %slot256, align 8
  %v2509 = load i64, ptr %slot256, align 8
  %op2510 = sub i64 %v2509, 1
  store i64 %op2510, ptr %slot257, align 8
  %v2511 = load i64, ptr %slot257, align 8
  %cmp2512 = icmp eq i64 %v2511, 0
  %cv2513 = zext i1 %cmp2512 to i32
  store i32 %cv2513, ptr %slot258, align 8
  %v2514 = load i32, ptr %slot258, align 8
  %cv2515 = zext i32 %v2514 to i64
  %cond2516 = icmp ne i64 %cv2515, 0
  br i1 %cond2516, label %bb_rcglast292, label %bb_rcgdec292
bb_rcglast292:
  %v2517 = load i64, ptr %slot249, align 8
  %op2518 = sub i64 %v2517, 32
  store i64 %op2518, ptr %slot259, align 8
  %v2519 = load i64, ptr %slot249, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  %rgep2521 = getelementptr i8, ptr %p2520, i64 -32
  %ld2522 = load i64, ptr %rgep2521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2522, ptr %slot260, align 8
  %v2523 = load i64, ptr %slot260, align 8
  %cmp2524 = icmp ne i64 %v2523, 0
  %cv2525 = zext i1 %cmp2524 to i32
  store i32 %cv2525, ptr %slot261, align 8
  %v2526 = load i32, ptr %slot261, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcgdec292, label %bb_rcgslow292
bb_rcgslow292:
  %v2529 = load i64, ptr %slot248, align 8
  %v2530 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2529, i64 %v2530) nomerge, !dbg !120
  br label %bb_rcgdone292
bb_rcgdec292:
  %v2531 = load i64, ptr %slot257, align 8
  %v2532 = load i64, ptr %slot249, align 8
  %p2533 = inttoptr i64 %v2532 to ptr
  %rgep2534 = getelementptr i8, ptr %p2533, i64 -24
  store i64 %v2531, ptr %rgep2534, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear292
bb_rcgclear292:
  %v2535 = load i64, ptr %slot245, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i64 0, ptr %p2536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone292
bb_rcgdone292:
  br label %bb_rcslotdone276
bb_rcslotowner276:
  %v2537 = load i64, ptr %slot45, align 8
  store i64 %v2537, ptr %slot262, align 8
  %v2538 = load i64, ptr %slot245, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %ld2540 = load i64, ptr %p2539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2540, ptr %slot263, align 8
  %v2541 = load i64, ptr %slot263, align 8
  %cmp2542 = icmp ne i64 %v2541, 0
  %cv2543 = zext i1 %cmp2542 to i32
  store i32 %cv2543, ptr %slot264, align 8
  %v2544 = load i32, ptr %slot264, align 8
  %cv2545 = zext i32 %v2544 to i64
  %cond2546 = icmp ne i64 %cv2545, 0
  br i1 %cond2546, label %bb_rcgnn307, label %bb_rcgdone307
bb_rcgnn307:
  %v2547 = load i64, ptr %slot263, align 8
  %op2548 = sub i64 %v2547, 16
  store i64 %op2548, ptr %slot265, align 8
  %v2549 = load i64, ptr %slot263, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %rgep2551 = getelementptr i8, ptr %p2550, i64 -16
  %ld2552 = load i64, ptr %rgep2551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2552, ptr %slot266, align 8
  %v2553 = load i64, ptr %slot266, align 8
  %op2554 = and i64 %v2553, 4611686018427387906
  store i64 %op2554, ptr %slot267, align 8
  %v2555 = load i64, ptr %slot267, align 8
  %cmp2556 = icmp ne i64 %v2555, 0
  %cv2557 = zext i1 %cmp2556 to i32
  store i32 %cv2557, ptr %slot268, align 8
  %v2558 = load i32, ptr %slot268, align 8
  %cv2559 = zext i32 %v2558 to i64
  %cond2560 = icmp ne i64 %cv2559, 0
  br i1 %cond2560, label %bb_rcgclear307, label %bb_rcgcounted307
bb_rcgcounted307:
  %v2561 = load i64, ptr %slot263, align 8
  %op2562 = sub i64 %v2561, 32
  store i64 %op2562, ptr %slot269, align 8
  %v2563 = load i64, ptr %slot263, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %rgep2565 = getelementptr i8, ptr %p2564, i64 -32
  %ld2566 = load i64, ptr %rgep2565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2566, ptr %slot270, align 8
  %v2567 = load i64, ptr %slot270, align 8
  %op2568 = sub i64 %v2567, 1
  store i64 %op2568, ptr %slot271, align 8
  %v2569 = load i64, ptr %slot271, align 8
  %cmp2570 = icmp eq i64 %v2569, 0
  %cv2571 = zext i1 %cmp2570 to i32
  store i32 %cv2571, ptr %slot272, align 8
  %v2572 = load i32, ptr %slot272, align 8
  %cv2573 = zext i32 %v2572 to i64
  %cond2574 = icmp ne i64 %cv2573, 0
  br i1 %cond2574, label %bb_rcglast307, label %bb_rcgdec307
bb_rcglast307:
  %v2575 = load i64, ptr %slot263, align 8
  %op2576 = sub i64 %v2575, 24
  store i64 %op2576, ptr %slot273, align 8
  %v2577 = load i64, ptr %slot263, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %rgep2579 = getelementptr i8, ptr %p2578, i64 -24
  %ld2580 = load i64, ptr %rgep2579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2580, ptr %slot274, align 8
  %v2581 = load i64, ptr %slot274, align 8
  %cmp2582 = icmp ne i64 %v2581, 0
  %cv2583 = zext i1 %cmp2582 to i32
  store i32 %cv2583, ptr %slot275, align 8
  %v2584 = load i32, ptr %slot275, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcgdec307, label %bb_rcgslow307
bb_rcgslow307:
  %v2587 = load i64, ptr %slot262, align 8
  %v2588 = load i64, ptr %slot245, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2587, i64 %v2588) nomerge, !dbg !120
  br label %bb_rcgdone307
bb_rcgdec307:
  %v2589 = load i64, ptr %slot271, align 8
  %v2590 = load i64, ptr %slot263, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  %rgep2592 = getelementptr i8, ptr %p2591, i64 -32
  store i64 %v2589, ptr %rgep2592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear307
bb_rcgclear307:
  %v2593 = load i64, ptr %slot245, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  store i64 0, ptr %p2594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone307
bb_rcgdone307:
  br label %bb_rcslotdone276
bb_rcslotdone276:
  %v2595 = load i64, ptr %slot43, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %ld2597 = load i64, ptr %p2596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2597, ptr %slot276, align 8
  %v2598 = load i64, ptr %slot42, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  %ld2600 = load i64, ptr %p2599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2600, ptr %slot277, align 8
  %v2601 = load i64, ptr %slot277, align 8
  %v2602 = load i64, ptr %slot276, align 8
  %cmp2603 = icmp sge i64 %v2601, %v2602
  %cv2604 = zext i1 %cmp2603 to i64
  store i64 %cv2604, ptr %slot278, align 8
  %v2605 = load i64, ptr %slot278, align 8
  %v2606 = load i64, ptr %slot42, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  store i64 %v2605, ptr %p2607, align 8, !alias.scope !3, !noalias !4
  br label %bb_i11
bb_i11:
  %v2608 = load i64, ptr %slot42, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %ld2610 = load i64, ptr %p2609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2610, ptr %slot279, align 8
  %v2611 = load i64, ptr %slot279, align 8
  %cond2612 = icmp ne i64 %v2611, 0
  br i1 %cond2612, label %bb_next315, label %bb_i14
bb_next315:
  %v2613 = load i64, ptr %slot42, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i64 0, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i14:
  %v2615 = load i64, ptr %slot35, align 8
  %v2616 = load i64, ptr %slot42, align 8
  %p2617 = inttoptr i64 %v2616 to ptr
  store i64 %v2615, ptr %p2617, align 8, !alias.scope !3, !noalias !4
  %v2618 = load i64, ptr %slot42, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  %ld2620 = load i64, ptr %p2619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2620, ptr %slot280, align 8
  %v2621 = load i64, ptr %slot280, align 8
  %op2622 = add i64 %v2621, 0
  store i64 %op2622, ptr %slot281, align 8
  %v2623 = load i64, ptr %slot281, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  %ld2625 = load i64, ptr %p2624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2625, ptr %slot282, align 8
  %v2626 = load i64, ptr %slot282, align 8
  %v2627 = load i64, ptr %slot42, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  store i64 %v2626, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot42, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  %ld2631 = load i64, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2631, ptr %slot283, align 8
  %v2632 = load i64, ptr %slot283, align 8
  %v2633 = load i64, ptr %slot26, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i64 %v2632, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  %v2635 = load i64, ptr %slot26, align 8
  store i64 %v2635, ptr %slot284, align 8
  %v2636 = load i64, ptr %slot28, align 8
  store i64 %v2636, ptr %slot285, align 8
  %v2637 = load i64, ptr %slot284, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i64, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2639, ptr %slot286, align 8
  %v2640 = load i64, ptr %slot286, align 8
  %cmp2641 = icmp ne i64 %v2640, 0
  %cv2642 = zext i1 %cmp2641 to i32
  store i32 %cv2642, ptr %slot287, align 8
  %v2643 = load i32, ptr %slot287, align 8
  %cv2644 = zext i32 %v2643 to i64
  %cond2645 = icmp ne i64 %cv2644, 0
  br i1 %cond2645, label %bb_rcgnn322, label %bb_rcgstore322
bb_rcgnn322:
  %v2646 = load i64, ptr %slot286, align 8
  %op2647 = sub i64 %v2646, 16
  store i64 %op2647, ptr %slot288, align 8
  %v2648 = load i64, ptr %slot286, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %rgep2650 = getelementptr i8, ptr %p2649, i64 -16
  %ld2651 = load i64, ptr %rgep2650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2651, ptr %slot289, align 8
  %v2652 = load i64, ptr %slot289, align 8
  %op2653 = and i64 %v2652, 4611686018427387906
  store i64 %op2653, ptr %slot290, align 8
  %v2654 = load i64, ptr %slot290, align 8
  %cmp2655 = icmp ne i64 %v2654, 0
  %cv2656 = zext i1 %cmp2655 to i32
  store i32 %cv2656, ptr %slot291, align 8
  %v2657 = load i32, ptr %slot291, align 8
  %cv2658 = zext i32 %v2657 to i64
  %cond2659 = icmp ne i64 %cv2658, 0
  br i1 %cond2659, label %bb_rcgstore322, label %bb_rcginc322
bb_rcginc322:
  %v2660 = load i64, ptr %slot286, align 8
  %op2661 = sub i64 %v2660, 24
  store i64 %op2661, ptr %slot292, align 8
  %v2662 = load i64, ptr %slot286, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  %rgep2664 = getelementptr i8, ptr %p2663, i64 -24
  %ld2665 = load i64, ptr %rgep2664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2665, ptr %slot293, align 8
  %v2666 = load i64, ptr %slot293, align 8
  %op2667 = add i64 %v2666, 1
  store i64 %op2667, ptr %slot294, align 8
  %v2668 = load i64, ptr %slot294, align 8
  %cmp2669 = icmp eq i64 %v2668, 0
  %cv2670 = zext i1 %cmp2669 to i32
  store i32 %cv2670, ptr %slot295, align 8
  %v2671 = load i32, ptr %slot295, align 8
  %cv2672 = zext i32 %v2671 to i64
  %cond2673 = icmp ne i64 %cv2672, 0
  br i1 %cond2673, label %bb_rcglimit322, label %bb_rcgcapacity322
bb_rcglimit322:
  %v2674 = load i64, ptr %slot1, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %call2676 = call i32 @myl_qbe_rc_status(ptr %p2675, i32 2) nomerge, !dbg !122
  store i32 %call2676, ptr %slot296, align 8
  br label %bb_failure
bb_rcgcapacity322:
  %v2677 = load i64, ptr %slot294, align 8
  %v2678 = load i64, ptr %slot286, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  %rgep2680 = getelementptr i8, ptr %p2679, i64 -24
  store i64 %v2677, ptr %rgep2680, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore322
bb_rcgstore322:
  %v2681 = load i64, ptr %slot286, align 8
  %v2682 = load i64, ptr %slot285, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i64 %v2681, ptr %p2683, align 8, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot23, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i32 2, ptr %p2685, align 4, !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot23, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  store i32 16, ptr %p2687, align 4, !alias.scope !3, !noalias !4
  %v2688 = load i64, ptr %slot22, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i32 1, ptr %p2689, align 4, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot18, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i32, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2692, ptr %slot297, align 8
  %v2693 = load i32, ptr %slot297, align 8
  %cv2694 = zext i32 %v2693 to i64
  %cond2695 = icmp ne i64 %cv2694, 0
  br i1 %cond2695, label %bb_rcslotdrop338, label %bb_rcslotdone338
bb_rcslotdrop338:
  %v2696 = load i64, ptr %slot18, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i32 0, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot24, align 8
  store i64 %v2698, ptr %slot298, align 8
  %v2699 = load i64, ptr %slot19, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %ld2701 = load i32, ptr %p2700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2701, ptr %slot299, align 8
  %v2702 = load i32, ptr %slot299, align 8
  %op2703 = and i32 %v2702, 28
  store i32 %op2703, ptr %slot300, align 8
  %v2704 = load i32, ptr %slot300, align 8
  %cv2705 = zext i32 %v2704 to i64
  %cond2706 = icmp ne i64 %cv2705, 0
  br i1 %cond2706, label %bb_rcslotrole338, label %bb_rcslotowner338
bb_rcslotrole338:
  %v2707 = load i64, ptr %slot45, align 8
  store i64 %v2707, ptr %slot301, align 8
  %v2708 = load i64, ptr %slot301, align 8
  %v2709 = load i64, ptr %slot298, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2708, i64 %v2709) nomerge, !dbg !122
  br label %bb_rcslotdone338
bb_rcslotowner338:
  %v2710 = load i64, ptr %slot45, align 8
  store i64 %v2710, ptr %slot302, align 8
  %v2711 = load i64, ptr %slot302, align 8
  %v2712 = load i64, ptr %slot298, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2711, i64 %v2712) nomerge, !dbg !122
  br label %bb_rcslotdone338
bb_rcslotdone338:
  %v2713 = load i64, ptr %slot24, align 8
  store i64 %v2713, ptr %slot303, align 8
  %v2714 = load i64, ptr %slot28, align 8
  store i64 %v2714, ptr %slot304, align 8
  %v2715 = load i64, ptr %slot304, align 8
  %v2716 = load i64, ptr %slot303, align 8
  %p2717 = inttoptr i64 %v2715 to ptr
  %p2718 = inttoptr i64 %v2716 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2718, ptr %p2717, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2719 = load i64, ptr %slot19, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  store i32 2, ptr %p2720, align 4, !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot23, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %ld2723 = load i32, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2723, ptr %slot305, align 8
  %v2724 = load i32, ptr %slot305, align 8
  %v2725 = load i64, ptr %slot19, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i32 %v2724, ptr %p2726, align 4, !alias.scope !3, !noalias !4
  %v2727 = load i64, ptr %slot22, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  store i32 0, ptr %p2728, align 4, !alias.scope !3, !noalias !4
  %v2729 = load i64, ptr %slot18, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  store i32 1, ptr %p2730, align 4, !alias.scope !3, !noalias !4
  %v2731 = load i64, ptr %slot303, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  %ld2733 = load i64, ptr %p2732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2733, ptr %slot306, align 8
  %v2734 = load i64, ptr %slot306, align 8
  %v2735 = load i64, ptr %slot42, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i64 %v2734, ptr %p2736, align 8, !alias.scope !3, !noalias !4
  %v2737 = load i64, ptr %slot35, align 8
  %v2738 = load i64, ptr %slot43, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  store i64 %v2737, ptr %p2739, align 8, !alias.scope !3, !noalias !4
  %v2740 = load i64, ptr %slot43, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  %ld2742 = load i64, ptr %p2741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2742, ptr %slot307, align 8
  %v2743 = load i64, ptr %slot307, align 8
  %op2744 = add i64 %v2743, 16
  store i64 %op2744, ptr %slot308, align 8
  %v2745 = load i64, ptr %slot308, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i64, ptr %p2746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2747, ptr %slot309, align 8
  %v2748 = load i64, ptr %slot309, align 8
  %v2749 = load i64, ptr %slot43, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  store i64 %v2748, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  %v2751 = load i64, ptr %slot20, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  %ld2753 = load i32, ptr %p2752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2753, ptr %slot310, align 8
  %v2754 = load i32, ptr %slot310, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcslotdrop359, label %bb_rcslotdone359
bb_rcslotdrop359:
  %v2757 = load i64, ptr %slot20, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i32 0, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  %v2759 = load i64, ptr %slot25, align 8
  store i64 %v2759, ptr %slot311, align 8
  %v2760 = load i64, ptr %slot21, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %ld2762 = load i32, ptr %p2761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2762, ptr %slot312, align 8
  %v2763 = load i32, ptr %slot312, align 8
  %op2764 = and i32 %v2763, 28
  store i32 %op2764, ptr %slot313, align 8
  %v2765 = load i32, ptr %slot313, align 8
  %cv2766 = zext i32 %v2765 to i64
  %cond2767 = icmp ne i64 %cv2766, 0
  br i1 %cond2767, label %bb_rcslotrole359, label %bb_rcslotowner359
bb_rcslotrole359:
  %v2768 = load i64, ptr %slot45, align 8
  store i64 %v2768, ptr %slot314, align 8
  %v2769 = load i64, ptr %slot314, align 8
  %v2770 = load i64, ptr %slot311, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2769, i64 %v2770) nomerge, !dbg !124
  br label %bb_rcslotdone359
bb_rcslotowner359:
  %v2771 = load i64, ptr %slot45, align 8
  store i64 %v2771, ptr %slot315, align 8
  %v2772 = load i64, ptr %slot315, align 8
  %v2773 = load i64, ptr %slot311, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2772, i64 %v2773) nomerge, !dbg !124
  br label %bb_rcslotdone359
bb_rcslotdone359:
  %v2774 = load i64, ptr %slot42, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %ld2776 = load i64, ptr %p2775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2776, ptr %slot316, align 8
  %v2777 = load i64, ptr %slot43, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %ld2779 = load i64, ptr %p2778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2779, ptr %slot317, align 8
  %v2780 = load i64, ptr %slot316, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  %ld2782 = load i64, ptr %p2781, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2782, ptr %slot318, align 8
  %v2783 = load i64, ptr %slot317, align 8
  %op2784 = ashr i64 %v2783, 63
  store i64 %op2784, ptr %slot319, align 8
  %v2785 = load i64, ptr %slot319, align 8
  %v2786 = load i64, ptr %slot318, align 8
  %op2787 = and i64 %v2785, %v2786
  store i64 %op2787, ptr %slot320, align 8
  %v2788 = load i64, ptr %slot317, align 8
  %v2789 = load i64, ptr %slot320, align 8
  %op2790 = add i64 %v2788, %v2789
  store i64 %op2790, ptr %slot321, align 8
  %v2791 = load i64, ptr %slot321, align 8
  %v2792 = load i64, ptr %slot318, align 8
  %cmp2793 = icmp ult i64 %v2791, %v2792
  %cv2794 = zext i1 %cmp2793 to i64
  store i64 %cv2794, ptr %slot322, align 8
  %v2795 = load i64, ptr %slot322, align 8
  %cond2796 = icmp ne i64 %v2795, 0
  br i1 %cond2796, label %bb_success374, label %bb_failed374
bb_failed374:
  %v2797 = load i64, ptr %slot1, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %v2799 = load i64, ptr %slot317, align 8
  %v2800 = load i64, ptr %slot318, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p2798, i64 %v2799, i64 %v2800) nomerge, !dbg !126
  unreachable
bb_success374:
  %v2801 = load i64, ptr %slot316, align 8
  %op2802 = add i64 %v2801, 32
  store i64 %op2802, ptr %slot323, align 8
  %v2803 = load i64, ptr %slot323, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  %ld2805 = load i64, ptr %p2804, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2805, ptr %slot324, align 8
  %v2806 = load i64, ptr %slot324, align 8
  %v2807 = load i64, ptr %slot321, align 8
  %op2808 = add i64 %v2806, %v2807
  store i64 %op2808, ptr %slot325, align 8
  %v2809 = load i64, ptr %slot324, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  %v2811 = load i64, ptr %slot321, align 8
  %egep2812 = getelementptr i8, ptr %p2810, i64 %v2811
  %ld2813 = load i8, ptr %egep2812, align 1, !alias.scope !12, !noalias !13
  %ext2814 = zext i8 %ld2813 to i64
  store i64 %ext2814, ptr %slot326, align 8
  %v2815 = load i64, ptr %slot326, align 8
  %v2816 = load i64, ptr %slot42, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i64 %v2815, ptr %p2817, align 8, !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot18, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  %ld2820 = load i32, ptr %p2819, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2820, ptr %slot327, align 8
  %v2821 = load i32, ptr %slot327, align 8
  %cv2822 = zext i32 %v2821 to i64
  %cond2823 = icmp ne i64 %cv2822, 0
  br i1 %cond2823, label %bb_rcslotdrop382, label %bb_rcslotdone382
bb_rcslotdrop382:
  %v2824 = load i64, ptr %slot18, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i32 0, ptr %p2825, align 4, !alias.scope !3, !noalias !4
  %v2826 = load i64, ptr %slot24, align 8
  store i64 %v2826, ptr %slot328, align 8
  %v2827 = load i64, ptr %slot19, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  %ld2829 = load i32, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2829, ptr %slot329, align 8
  %v2830 = load i32, ptr %slot329, align 8
  %op2831 = and i32 %v2830, 28
  store i32 %op2831, ptr %slot330, align 8
  %v2832 = load i32, ptr %slot330, align 8
  %cv2833 = zext i32 %v2832 to i64
  %cond2834 = icmp ne i64 %cv2833, 0
  br i1 %cond2834, label %bb_rcslotrole382, label %bb_rcslotowner382
bb_rcslotrole382:
  %v2835 = load i64, ptr %slot45, align 8
  store i64 %v2835, ptr %slot331, align 8
  %v2836 = load i64, ptr %slot328, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  %ld2838 = load i64, ptr %p2837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2838, ptr %slot332, align 8
  %v2839 = load i64, ptr %slot332, align 8
  %cmp2840 = icmp ne i64 %v2839, 0
  %cv2841 = zext i1 %cmp2840 to i32
  store i32 %cv2841, ptr %slot333, align 8
  %v2842 = load i32, ptr %slot333, align 8
  %cv2843 = zext i32 %v2842 to i64
  %cond2844 = icmp ne i64 %cv2843, 0
  br i1 %cond2844, label %bb_rcgnn398, label %bb_rcgdone398
bb_rcgnn398:
  %v2845 = load i64, ptr %slot332, align 8
  %op2846 = sub i64 %v2845, 16
  store i64 %op2846, ptr %slot334, align 8
  %v2847 = load i64, ptr %slot332, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %rgep2849 = getelementptr i8, ptr %p2848, i64 -16
  %ld2850 = load i64, ptr %rgep2849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2850, ptr %slot335, align 8
  %v2851 = load i64, ptr %slot335, align 8
  %op2852 = and i64 %v2851, 4611686018427387906
  store i64 %op2852, ptr %slot336, align 8
  %v2853 = load i64, ptr %slot336, align 8
  %cmp2854 = icmp ne i64 %v2853, 0
  %cv2855 = zext i1 %cmp2854 to i32
  store i32 %cv2855, ptr %slot337, align 8
  %v2856 = load i32, ptr %slot337, align 8
  %cv2857 = zext i32 %v2856 to i64
  %cond2858 = icmp ne i64 %cv2857, 0
  br i1 %cond2858, label %bb_rcgclear398, label %bb_rcgcounted398
bb_rcgcounted398:
  %v2859 = load i64, ptr %slot332, align 8
  %op2860 = sub i64 %v2859, 24
  store i64 %op2860, ptr %slot338, align 8
  %v2861 = load i64, ptr %slot332, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %rgep2863 = getelementptr i8, ptr %p2862, i64 -24
  %ld2864 = load i64, ptr %rgep2863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2864, ptr %slot339, align 8
  %v2865 = load i64, ptr %slot339, align 8
  %op2866 = sub i64 %v2865, 1
  store i64 %op2866, ptr %slot340, align 8
  %v2867 = load i64, ptr %slot340, align 8
  %cmp2868 = icmp eq i64 %v2867, 0
  %cv2869 = zext i1 %cmp2868 to i32
  store i32 %cv2869, ptr %slot341, align 8
  %v2870 = load i32, ptr %slot341, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcglast398, label %bb_rcgdec398
bb_rcglast398:
  %v2873 = load i64, ptr %slot332, align 8
  %op2874 = sub i64 %v2873, 32
  store i64 %op2874, ptr %slot342, align 8
  %v2875 = load i64, ptr %slot332, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %rgep2877 = getelementptr i8, ptr %p2876, i64 -32
  %ld2878 = load i64, ptr %rgep2877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2878, ptr %slot343, align 8
  %v2879 = load i64, ptr %slot343, align 8
  %cmp2880 = icmp ne i64 %v2879, 0
  %cv2881 = zext i1 %cmp2880 to i32
  store i32 %cv2881, ptr %slot344, align 8
  %v2882 = load i32, ptr %slot344, align 8
  %cv2883 = zext i32 %v2882 to i64
  %cond2884 = icmp ne i64 %cv2883, 0
  br i1 %cond2884, label %bb_rcgdec398, label %bb_rcgslow398
bb_rcgslow398:
  %v2885 = load i64, ptr %slot331, align 8
  %v2886 = load i64, ptr %slot328, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2885, i64 %v2886) nomerge, !dbg !126
  br label %bb_rcgdone398
bb_rcgdec398:
  %v2887 = load i64, ptr %slot340, align 8
  %v2888 = load i64, ptr %slot332, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  %rgep2890 = getelementptr i8, ptr %p2889, i64 -24
  store i64 %v2887, ptr %rgep2890, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear398
bb_rcgclear398:
  %v2891 = load i64, ptr %slot328, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  store i64 0, ptr %p2892, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone398
bb_rcgdone398:
  br label %bb_rcslotdone382
bb_rcslotowner382:
  %v2893 = load i64, ptr %slot45, align 8
  store i64 %v2893, ptr %slot345, align 8
  %v2894 = load i64, ptr %slot328, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  %ld2896 = load i64, ptr %p2895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2896, ptr %slot346, align 8
  %v2897 = load i64, ptr %slot346, align 8
  %cmp2898 = icmp ne i64 %v2897, 0
  %cv2899 = zext i1 %cmp2898 to i32
  store i32 %cv2899, ptr %slot347, align 8
  %v2900 = load i32, ptr %slot347, align 8
  %cv2901 = zext i32 %v2900 to i64
  %cond2902 = icmp ne i64 %cv2901, 0
  br i1 %cond2902, label %bb_rcgnn413, label %bb_rcgdone413
bb_rcgnn413:
  %v2903 = load i64, ptr %slot346, align 8
  %op2904 = sub i64 %v2903, 16
  store i64 %op2904, ptr %slot348, align 8
  %v2905 = load i64, ptr %slot346, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %rgep2907 = getelementptr i8, ptr %p2906, i64 -16
  %ld2908 = load i64, ptr %rgep2907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2908, ptr %slot349, align 8
  %v2909 = load i64, ptr %slot349, align 8
  %op2910 = and i64 %v2909, 4611686018427387906
  store i64 %op2910, ptr %slot350, align 8
  %v2911 = load i64, ptr %slot350, align 8
  %cmp2912 = icmp ne i64 %v2911, 0
  %cv2913 = zext i1 %cmp2912 to i32
  store i32 %cv2913, ptr %slot351, align 8
  %v2914 = load i32, ptr %slot351, align 8
  %cv2915 = zext i32 %v2914 to i64
  %cond2916 = icmp ne i64 %cv2915, 0
  br i1 %cond2916, label %bb_rcgclear413, label %bb_rcgcounted413
bb_rcgcounted413:
  %v2917 = load i64, ptr %slot346, align 8
  %op2918 = sub i64 %v2917, 32
  store i64 %op2918, ptr %slot352, align 8
  %v2919 = load i64, ptr %slot346, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %rgep2921 = getelementptr i8, ptr %p2920, i64 -32
  %ld2922 = load i64, ptr %rgep2921, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2922, ptr %slot353, align 8
  %v2923 = load i64, ptr %slot353, align 8
  %op2924 = sub i64 %v2923, 1
  store i64 %op2924, ptr %slot354, align 8
  %v2925 = load i64, ptr %slot354, align 8
  %cmp2926 = icmp eq i64 %v2925, 0
  %cv2927 = zext i1 %cmp2926 to i32
  store i32 %cv2927, ptr %slot355, align 8
  %v2928 = load i32, ptr %slot355, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcglast413, label %bb_rcgdec413
bb_rcglast413:
  %v2931 = load i64, ptr %slot346, align 8
  %op2932 = sub i64 %v2931, 24
  store i64 %op2932, ptr %slot356, align 8
  %v2933 = load i64, ptr %slot346, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %rgep2935 = getelementptr i8, ptr %p2934, i64 -24
  %ld2936 = load i64, ptr %rgep2935, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2936, ptr %slot357, align 8
  %v2937 = load i64, ptr %slot357, align 8
  %cmp2938 = icmp ne i64 %v2937, 0
  %cv2939 = zext i1 %cmp2938 to i32
  store i32 %cv2939, ptr %slot358, align 8
  %v2940 = load i32, ptr %slot358, align 8
  %cv2941 = zext i32 %v2940 to i64
  %cond2942 = icmp ne i64 %cv2941, 0
  br i1 %cond2942, label %bb_rcgdec413, label %bb_rcgslow413
bb_rcgslow413:
  %v2943 = load i64, ptr %slot345, align 8
  %v2944 = load i64, ptr %slot328, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2943, i64 %v2944) nomerge, !dbg !126
  br label %bb_rcgdone413
bb_rcgdec413:
  %v2945 = load i64, ptr %slot354, align 8
  %v2946 = load i64, ptr %slot346, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %rgep2948 = getelementptr i8, ptr %p2947, i64 -32
  store i64 %v2945, ptr %rgep2948, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear413
bb_rcgclear413:
  %v2949 = load i64, ptr %slot328, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i64 0, ptr %p2950, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone413
bb_rcgdone413:
  br label %bb_rcslotdone382
bb_rcslotdone382:
  %v2951 = load i64, ptr %slot42, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot359, align 8
  %v2954 = load i64, ptr %slot359, align 8
  %v2955 = load i64, ptr %slot42, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  store i64 %v2954, ptr %p2956, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i21:
  %v2957 = load i64, ptr %slot42, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %ld2959 = load i64, ptr %p2958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2959, ptr %slot360, align 8
  %v2960 = load i64, ptr %slot360, align 8
  %v2961 = load i64, ptr %slot30, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  store i64 %v2960, ptr %p2962, align 8, !alias.scope !3, !noalias !4
  %v2963 = load i64, ptr %slot29, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %ld2965 = load i64, ptr %p2964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2965, ptr %slot361, align 8
  %v2966 = load i64, ptr %slot361, align 8
  %v2967 = load i64, ptr %slot42, align 8
  %p2968 = inttoptr i64 %v2967 to ptr
  store i64 %v2966, ptr %p2968, align 8, !alias.scope !3, !noalias !4
  %v2969 = load i64, ptr %slot42, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  %ld2971 = load i64, ptr %p2970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2971, ptr %slot362, align 8
  %v2972 = load i64, ptr %slot18, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %ld2974 = load i32, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2974, ptr %slot363, align 8
  %v2975 = load i64, ptr %slot19, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  %ld2977 = load i32, ptr %p2976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2977, ptr %slot364, align 8
  %v2978 = load i32, ptr %slot364, align 8
  %op2979 = and i32 %v2978, 24
  store i32 %op2979, ptr %slot364, align 8
  %v2980 = load i32, ptr %slot364, align 8
  %cmp2981 = icmp eq i32 %v2980, 0
  %cv2982 = zext i1 %cmp2981 to i32
  store i32 %cv2982, ptr %slot365, align 8
  %v2983 = load i32, ptr %slot363, align 8
  %v2984 = load i32, ptr %slot365, align 8
  %op2985 = and i32 %v2983, %v2984
  store i32 %op2985, ptr %slot366, align 8
  %v2986 = load i32, ptr %slot366, align 8
  %cv2987 = zext i32 %v2986 to i64
  %cond2988 = icmp ne i64 %cv2987, 0
  br i1 %cond2988, label %bb_rctake421, label %bb_rccopy421
bb_rctake421:
  %v2989 = load i64, ptr %slot28, align 8
  store i64 %v2989, ptr %slot367, align 8
  %v2990 = load i64, ptr %slot46, align 8
  store i64 %v2990, ptr %slot368, align 8
  %v2991 = load i64, ptr %slot362, align 8
  %v2992 = load i64, ptr %slot367, align 8
  %op2993 = sub i64 %v2991, %v2992
  store i64 %op2993, ptr %slot369, align 8
  %v2994 = load i64, ptr %slot367, align 8
  %v2995 = load i64, ptr %slot362, align 8
  %op2996 = sub i64 %v2994, %v2995
  store i64 %op2996, ptr %slot370, align 8
  %v2997 = load i64, ptr %slot369, align 8
  %cmp2998 = icmp ult i64 %v2997, 32
  %cv2999 = zext i1 %cmp2998 to i32
  store i32 %cv2999, ptr %slot371, align 8
  %v3000 = load i64, ptr %slot370, align 8
  %cmp3001 = icmp ult i64 %v3000, 32
  %cv3002 = zext i1 %cmp3001 to i32
  store i32 %cv3002, ptr %slot372, align 8
  %v3003 = load i32, ptr %slot371, align 8
  %v3004 = load i32, ptr %slot372, align 8
  %op3005 = or i32 %v3003, %v3004
  store i32 %op3005, ptr %slot373, align 8
  %v3006 = load i32, ptr %slot373, align 8
  %cv3007 = zext i32 %v3006 to i64
  %cond3008 = icmp ne i64 %cv3007, 0
  br i1 %cond3008, label %bb_rcmoveslow430, label %bb_rcmovecheck430
bb_rcmovecheck430:
  %v3009 = load i64, ptr %slot362, align 8
  %op3010 = add i64 %v3009, 0
  store i64 %op3010, ptr %slot374, align 8
  %v3011 = load i64, ptr %slot374, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  %ld3013 = load i64, ptr %p3012, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3013, ptr %slot375, align 8
  %v3014 = load i64, ptr %slot375, align 8
  %cmp3015 = icmp ne i64 %v3014, 0
  %cv3016 = zext i1 %cmp3015 to i32
  store i32 %cv3016, ptr %slot376, align 8
  %v3017 = load i32, ptr %slot376, align 8
  %cv3018 = zext i32 %v3017 to i64
  %cond3019 = icmp ne i64 %cv3018, 0
  br i1 %cond3019, label %bb_rcmoveheader438, label %bb_rcmovenext438
bb_rcmoveheader438:
  %v3020 = load i64, ptr %slot375, align 8
  %op3021 = sub i64 %v3020, 16
  store i64 %op3021, ptr %slot377, align 8
  %v3022 = load i64, ptr %slot375, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %rgep3024 = getelementptr i8, ptr %p3023, i64 -16
  %ld3025 = load i64, ptr %rgep3024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3025, ptr %slot378, align 8
  %v3026 = load i64, ptr %slot378, align 8
  %op3027 = and i64 %v3026, 5764607523034234881
  store i64 %op3027, ptr %slot379, align 8
  %v3028 = load i64, ptr %slot379, align 8
  %cmp3029 = icmp ne i64 %v3028, 0
  %cv3030 = zext i1 %cmp3029 to i32
  store i32 %cv3030, ptr %slot380, align 8
  %v3031 = load i32, ptr %slot380, align 8
  %cv3032 = zext i32 %v3031 to i64
  %cond3033 = icmp ne i64 %cv3032, 0
  br i1 %cond3033, label %bb_rcmoveslow430, label %bb_rcmovenext438
bb_rcmovenext438:
  %v3034 = load i64, ptr %slot362, align 8
  %v3035 = load i64, ptr %slot367, align 8
  %p3036 = inttoptr i64 %v3034 to ptr
  %p3037 = inttoptr i64 %v3035 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3037, ptr %p3036, i64 32, i1 false), !alias.scope !10000000
  %v3038 = load i64, ptr %slot362, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  store i64 0, ptr %p3039, align 8, !alias.scope !4, !noalias !3
  %v3040 = load i64, ptr %slot362, align 8
  %op3041 = add i64 %v3040, 8
  store i64 %op3041, ptr %slot381, align 8
  %v3042 = load i64, ptr %slot381, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  store i64 0, ptr %p3043, align 8, !alias.scope !4, !noalias !3
  %v3044 = load i64, ptr %slot362, align 8
  %op3045 = add i64 %v3044, 16
  store i64 %op3045, ptr %slot382, align 8
  %v3046 = load i64, ptr %slot382, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i64 0, ptr %p3047, align 8, !alias.scope !4, !noalias !3
  %v3048 = load i64, ptr %slot362, align 8
  %op3049 = add i64 %v3048, 24
  store i64 %op3049, ptr %slot383, align 8
  %v3050 = load i64, ptr %slot383, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  store i64 0, ptr %p3051, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved430
bb_rcmoveslow430:
  %v3052 = load i64, ptr %slot45, align 8
  %v3053 = load i64, ptr %slot367, align 8
  %v3054 = load i64, ptr %slot362, align 8
  %v3055 = load i64, ptr %slot368, align 8
  %cv3056 = trunc i64 %v3055 to i32
  %call3057 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3052, i64 %v3053, i64 %v3054, i32 %cv3056) nomerge, !dbg !128
  store i32 %call3057, ptr %slot384, align 8
  %v3058 = load i32, ptr %slot384, align 8
  %cv3059 = zext i32 %v3058 to i64
  %cond3060 = icmp ne i64 %cv3059, 0
  br i1 %cond3060, label %bb_rcsuccess448, label %bb_rcfailure448
bb_rcfailure448:
  %v3061 = load i64, ptr %slot45, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  %call3063 = call i32 @myl_rc_take_failure(ptr %p3062) nomerge, !dbg !128
  store i32 %call3063, ptr %slot385, align 8
  %v3064 = load i64, ptr %slot1, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %v3066 = load i32, ptr %slot385, align 8
  %call3067 = call i32 @myl_qbe_rc_status(ptr %p3065, i32 %v3066) nomerge, !dbg !128
  store i32 %call3067, ptr %slot386, align 8
  br label %bb_failure
bb_rcsuccess448:
  br label %bb_rcmoved430
bb_rcmoved430:
  %v3068 = load i64, ptr %slot18, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i32 0, ptr %p3069, align 4, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot23, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i32 2, ptr %p3071, align 4, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot22, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i32 1, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared421
bb_rccopy421:
  %v3074 = load i64, ptr %slot28, align 8
  store i64 %v3074, ptr %slot387, align 8
  %v3075 = load i64, ptr %slot46, align 8
  store i64 %v3075, ptr %slot388, align 8
  %v3076 = load i64, ptr %slot45, align 8
  %v3077 = load i64, ptr %slot387, align 8
  %v3078 = load i64, ptr %slot362, align 8
  %v3079 = load i64, ptr %slot388, align 8
  %cv3080 = trunc i64 %v3079 to i32
  %call3081 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3076, i64 %v3077, i64 %v3078, i32 %cv3080) nomerge, !dbg !128
  store i32 %call3081, ptr %slot389, align 8
  %v3082 = load i32, ptr %slot389, align 8
  %cv3083 = zext i32 %v3082 to i64
  %cond3084 = icmp ne i64 %cv3083, 0
  br i1 %cond3084, label %bb_rcsuccess457, label %bb_rcfailure457
bb_rcfailure457:
  %v3085 = load i64, ptr %slot45, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  %call3087 = call i32 @myl_rc_take_failure(ptr %p3086) nomerge, !dbg !128
  store i32 %call3087, ptr %slot390, align 8
  %v3088 = load i64, ptr %slot1, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  %v3090 = load i32, ptr %slot390, align 8
  %call3091 = call i32 @myl_qbe_rc_status(ptr %p3089, i32 %v3090) nomerge, !dbg !128
  store i32 %call3091, ptr %slot391, align 8
  br label %bb_failure
bb_rcsuccess457:
  %v3092 = load i64, ptr %slot23, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  store i32 2, ptr %p3093, align 4, !alias.scope !3, !noalias !4
  %v3094 = load i64, ptr %slot22, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  store i32 1, ptr %p3095, align 4, !alias.scope !3, !noalias !4
  %v3096 = load i64, ptr %slot18, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i32, ptr %p3097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3098, ptr %slot392, align 8
  %v3099 = load i32, ptr %slot392, align 8
  %cv3100 = zext i32 %v3099 to i64
  %cond3101 = icmp ne i64 %cv3100, 0
  br i1 %cond3101, label %bb_rcslotdrop464, label %bb_rcslotdone464
bb_rcslotdrop464:
  %v3102 = load i64, ptr %slot18, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  store i32 0, ptr %p3103, align 4, !alias.scope !3, !noalias !4
  %v3104 = load i64, ptr %slot24, align 8
  store i64 %v3104, ptr %slot393, align 8
  %v3105 = load i64, ptr %slot19, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i32, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3107, ptr %slot394, align 8
  %v3108 = load i32, ptr %slot394, align 8
  %op3109 = and i32 %v3108, 28
  store i32 %op3109, ptr %slot395, align 8
  %v3110 = load i32, ptr %slot395, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcslotrole464, label %bb_rcslotowner464
bb_rcslotrole464:
  %v3113 = load i64, ptr %slot45, align 8
  store i64 %v3113, ptr %slot396, align 8
  %v3114 = load i64, ptr %slot396, align 8
  %v3115 = load i64, ptr %slot393, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3114, i64 %v3115) nomerge, !dbg !128
  br label %bb_rcslotdone464
bb_rcslotowner464:
  %v3116 = load i64, ptr %slot393, align 8
  %p3118 = inttoptr i64 %v3116 to ptr
  %gep3119 = getelementptr i8, ptr %p3118, i64 0
  %op3117 = ptrtoint ptr %gep3119 to i64
  store i64 %op3117, ptr %slot397, align 8
  %v3120 = load i64, ptr %slot45, align 8
  store i64 %v3120, ptr %slot398, align 8
  %v3121 = load i64, ptr %slot397, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %ld3123 = load i64, ptr %p3122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3123, ptr %slot399, align 8
  %v3124 = load i64, ptr %slot399, align 8
  %cmp3125 = icmp ne i64 %v3124, 0
  %cv3126 = zext i1 %cmp3125 to i32
  store i32 %cv3126, ptr %slot400, align 8
  %v3127 = load i32, ptr %slot400, align 8
  %cv3128 = zext i32 %v3127 to i64
  %cond3129 = icmp ne i64 %cv3128, 0
  br i1 %cond3129, label %bb_rcgnn482, label %bb_rcgdone482
bb_rcgnn482:
  %v3130 = load i64, ptr %slot399, align 8
  %op3131 = sub i64 %v3130, 16
  store i64 %op3131, ptr %slot401, align 8
  %v3132 = load i64, ptr %slot399, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %rgep3134 = getelementptr i8, ptr %p3133, i64 -16
  %ld3135 = load i64, ptr %rgep3134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3135, ptr %slot402, align 8
  %v3136 = load i64, ptr %slot402, align 8
  %op3137 = and i64 %v3136, 4611686018427387906
  store i64 %op3137, ptr %slot403, align 8
  %v3138 = load i64, ptr %slot403, align 8
  %cmp3139 = icmp ne i64 %v3138, 0
  %cv3140 = zext i1 %cmp3139 to i32
  store i32 %cv3140, ptr %slot404, align 8
  %v3141 = load i32, ptr %slot404, align 8
  %cv3142 = zext i32 %v3141 to i64
  %cond3143 = icmp ne i64 %cv3142, 0
  br i1 %cond3143, label %bb_rcgclear482, label %bb_rcgcounted482
bb_rcgcounted482:
  %v3144 = load i64, ptr %slot399, align 8
  %op3145 = sub i64 %v3144, 32
  store i64 %op3145, ptr %slot405, align 8
  %v3146 = load i64, ptr %slot399, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  %rgep3148 = getelementptr i8, ptr %p3147, i64 -32
  %ld3149 = load i64, ptr %rgep3148, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3149, ptr %slot406, align 8
  %v3150 = load i64, ptr %slot406, align 8
  %op3151 = sub i64 %v3150, 1
  store i64 %op3151, ptr %slot407, align 8
  %v3152 = load i64, ptr %slot407, align 8
  %cmp3153 = icmp eq i64 %v3152, 0
  %cv3154 = zext i1 %cmp3153 to i32
  store i32 %cv3154, ptr %slot408, align 8
  %v3155 = load i32, ptr %slot408, align 8
  %cv3156 = zext i32 %v3155 to i64
  %cond3157 = icmp ne i64 %cv3156, 0
  br i1 %cond3157, label %bb_rcglast482, label %bb_rcgdec482
bb_rcglast482:
  %v3158 = load i64, ptr %slot399, align 8
  %op3159 = sub i64 %v3158, 24
  store i64 %op3159, ptr %slot409, align 8
  %v3160 = load i64, ptr %slot399, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  %rgep3162 = getelementptr i8, ptr %p3161, i64 -24
  %ld3163 = load i64, ptr %rgep3162, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3163, ptr %slot410, align 8
  %v3164 = load i64, ptr %slot410, align 8
  %cmp3165 = icmp ne i64 %v3164, 0
  %cv3166 = zext i1 %cmp3165 to i32
  store i32 %cv3166, ptr %slot411, align 8
  %v3167 = load i32, ptr %slot411, align 8
  %cv3168 = zext i32 %v3167 to i64
  %cond3169 = icmp ne i64 %cv3168, 0
  br i1 %cond3169, label %bb_rcgdec482, label %bb_rcgslow482
bb_rcgslow482:
  %v3170 = load i64, ptr %slot398, align 8
  %v3171 = load i64, ptr %slot397, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3170, i64 %v3171) nomerge, !dbg !128
  br label %bb_rcgdone482
bb_rcgdec482:
  %v3172 = load i64, ptr %slot407, align 8
  %v3173 = load i64, ptr %slot399, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  %rgep3175 = getelementptr i8, ptr %p3174, i64 -32
  store i64 %v3172, ptr %rgep3175, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear482
bb_rcgclear482:
  %v3176 = load i64, ptr %slot397, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  store i64 0, ptr %p3177, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone482
bb_rcgdone482:
  %v3178 = load i64, ptr %slot393, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  store i64 0, ptr %p3179, align 8, !alias.scope !3, !noalias !4
  %v3180 = load i64, ptr %slot393, align 8
  %p3182 = inttoptr i64 %v3180 to ptr
  %gep3183 = getelementptr i8, ptr %p3182, i64 8
  %op3181 = ptrtoint ptr %gep3183 to i64
  store i64 %op3181, ptr %slot412, align 8
  %v3184 = load i64, ptr %slot412, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i64 0, ptr %p3185, align 8, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot393, align 8
  %p3188 = inttoptr i64 %v3186 to ptr
  %gep3189 = getelementptr i8, ptr %p3188, i64 16
  %op3187 = ptrtoint ptr %gep3189 to i64
  store i64 %op3187, ptr %slot413, align 8
  %v3190 = load i64, ptr %slot413, align 8
  %p3191 = inttoptr i64 %v3190 to ptr
  store i64 0, ptr %p3191, align 8, !alias.scope !3, !noalias !4
  %v3192 = load i64, ptr %slot393, align 8
  %p3194 = inttoptr i64 %v3192 to ptr
  %gep3195 = getelementptr i8, ptr %p3194, i64 24
  %op3193 = ptrtoint ptr %gep3195 to i64
  store i64 %op3193, ptr %slot414, align 8
  %v3196 = load i64, ptr %slot414, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  store i64 0, ptr %p3197, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone464
bb_rcslotdone464:
  br label %bb_rcprepared421
bb_rcprepared421:
  %v3198 = load i64, ptr %slot8, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  %ld3200 = load i32, ptr %p3199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3200, ptr %slot415, align 8
  %v3201 = load i32, ptr %slot415, align 8
  %cv3202 = zext i32 %v3201 to i64
  %cond3203 = icmp ne i64 %cv3202, 0
  br i1 %cond3203, label %bb_rcslotdrop492, label %bb_rcslotdone492
bb_rcslotdrop492:
  %v3204 = load i64, ptr %slot8, align 8
  %p3205 = inttoptr i64 %v3204 to ptr
  store i32 0, ptr %p3205, align 4, !alias.scope !3, !noalias !4
  %v3206 = load i64, ptr %slot37, align 8
  store i64 %v3206, ptr %slot416, align 8
  %v3207 = load i64, ptr %slot9, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  %ld3209 = load i32, ptr %p3208, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3209, ptr %slot417, align 8
  %v3210 = load i32, ptr %slot417, align 8
  %op3211 = and i32 %v3210, 28
  store i32 %op3211, ptr %slot418, align 8
  %v3212 = load i32, ptr %slot418, align 8
  %cv3213 = zext i32 %v3212 to i64
  %cond3214 = icmp ne i64 %cv3213, 0
  br i1 %cond3214, label %bb_rcslotrole492, label %bb_rcslotowner492
bb_rcslotrole492:
  %v3215 = load i64, ptr %slot45, align 8
  store i64 %v3215, ptr %slot419, align 8
  %v3216 = load i64, ptr %slot419, align 8
  %v3217 = load i64, ptr %slot416, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3216, i64 %v3217) nomerge, !dbg !128
  br label %bb_rcslotdone492
bb_rcslotowner492:
  %v3218 = load i64, ptr %slot416, align 8
  %p3220 = inttoptr i64 %v3218 to ptr
  %gep3221 = getelementptr i8, ptr %p3220, i64 0
  %op3219 = ptrtoint ptr %gep3221 to i64
  store i64 %op3219, ptr %slot420, align 8
  %v3222 = load i64, ptr %slot45, align 8
  store i64 %v3222, ptr %slot421, align 8
  %v3223 = load i64, ptr %slot420, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i64, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3225, ptr %slot422, align 8
  %v3226 = load i64, ptr %slot422, align 8
  %cmp3227 = icmp ne i64 %v3226, 0
  %cv3228 = zext i1 %cmp3227 to i32
  store i32 %cv3228, ptr %slot423, align 8
  %v3229 = load i32, ptr %slot423, align 8
  %cv3230 = zext i32 %v3229 to i64
  %cond3231 = icmp ne i64 %cv3230, 0
  br i1 %cond3231, label %bb_rcgnn510, label %bb_rcgdone510
bb_rcgnn510:
  %v3232 = load i64, ptr %slot422, align 8
  %op3233 = sub i64 %v3232, 16
  store i64 %op3233, ptr %slot424, align 8
  %v3234 = load i64, ptr %slot422, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  %rgep3236 = getelementptr i8, ptr %p3235, i64 -16
  %ld3237 = load i64, ptr %rgep3236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3237, ptr %slot425, align 8
  %v3238 = load i64, ptr %slot425, align 8
  %op3239 = and i64 %v3238, 4611686018427387906
  store i64 %op3239, ptr %slot426, align 8
  %v3240 = load i64, ptr %slot426, align 8
  %cmp3241 = icmp ne i64 %v3240, 0
  %cv3242 = zext i1 %cmp3241 to i32
  store i32 %cv3242, ptr %slot427, align 8
  %v3243 = load i32, ptr %slot427, align 8
  %cv3244 = zext i32 %v3243 to i64
  %cond3245 = icmp ne i64 %cv3244, 0
  br i1 %cond3245, label %bb_rcgclear510, label %bb_rcgcounted510
bb_rcgcounted510:
  %v3246 = load i64, ptr %slot422, align 8
  %op3247 = sub i64 %v3246, 32
  store i64 %op3247, ptr %slot428, align 8
  %v3248 = load i64, ptr %slot422, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %rgep3250 = getelementptr i8, ptr %p3249, i64 -32
  %ld3251 = load i64, ptr %rgep3250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3251, ptr %slot429, align 8
  %v3252 = load i64, ptr %slot429, align 8
  %op3253 = sub i64 %v3252, 1
  store i64 %op3253, ptr %slot430, align 8
  %v3254 = load i64, ptr %slot430, align 8
  %cmp3255 = icmp eq i64 %v3254, 0
  %cv3256 = zext i1 %cmp3255 to i32
  store i32 %cv3256, ptr %slot431, align 8
  %v3257 = load i32, ptr %slot431, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcglast510, label %bb_rcgdec510
bb_rcglast510:
  %v3260 = load i64, ptr %slot422, align 8
  %op3261 = sub i64 %v3260, 24
  store i64 %op3261, ptr %slot432, align 8
  %v3262 = load i64, ptr %slot422, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %rgep3264 = getelementptr i8, ptr %p3263, i64 -24
  %ld3265 = load i64, ptr %rgep3264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3265, ptr %slot433, align 8
  %v3266 = load i64, ptr %slot433, align 8
  %cmp3267 = icmp ne i64 %v3266, 0
  %cv3268 = zext i1 %cmp3267 to i32
  store i32 %cv3268, ptr %slot434, align 8
  %v3269 = load i32, ptr %slot434, align 8
  %cv3270 = zext i32 %v3269 to i64
  %cond3271 = icmp ne i64 %cv3270, 0
  br i1 %cond3271, label %bb_rcgdec510, label %bb_rcgslow510
bb_rcgslow510:
  %v3272 = load i64, ptr %slot421, align 8
  %v3273 = load i64, ptr %slot420, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3272, i64 %v3273) nomerge, !dbg !128
  br label %bb_rcgdone510
bb_rcgdec510:
  %v3274 = load i64, ptr %slot430, align 8
  %v3275 = load i64, ptr %slot422, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  %rgep3277 = getelementptr i8, ptr %p3276, i64 -32
  store i64 %v3274, ptr %rgep3277, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear510
bb_rcgclear510:
  %v3278 = load i64, ptr %slot420, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i64 0, ptr %p3279, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone510
bb_rcgdone510:
  %v3280 = load i64, ptr %slot416, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i64 0, ptr %p3281, align 8, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot416, align 8
  %p3284 = inttoptr i64 %v3282 to ptr
  %gep3285 = getelementptr i8, ptr %p3284, i64 8
  %op3283 = ptrtoint ptr %gep3285 to i64
  store i64 %op3283, ptr %slot435, align 8
  %v3286 = load i64, ptr %slot435, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i64 0, ptr %p3287, align 8, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot416, align 8
  %p3290 = inttoptr i64 %v3288 to ptr
  %gep3291 = getelementptr i8, ptr %p3290, i64 16
  %op3289 = ptrtoint ptr %gep3291 to i64
  store i64 %op3289, ptr %slot436, align 8
  %v3292 = load i64, ptr %slot436, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  store i64 0, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  %v3294 = load i64, ptr %slot416, align 8
  %p3296 = inttoptr i64 %v3294 to ptr
  %gep3297 = getelementptr i8, ptr %p3296, i64 24
  %op3295 = ptrtoint ptr %gep3297 to i64
  store i64 %op3295, ptr %slot437, align 8
  %v3298 = load i64, ptr %slot437, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i64 0, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone492
bb_rcslotdone492:
  %v3300 = load i64, ptr %slot37, align 8
  store i64 %v3300, ptr %slot438, align 8
  %v3301 = load i64, ptr %slot28, align 8
  store i64 %v3301, ptr %slot439, align 8
  %v3302 = load i64, ptr %slot439, align 8
  %v3303 = load i64, ptr %slot438, align 8
  %p3304 = inttoptr i64 %v3302 to ptr
  %p3305 = inttoptr i64 %v3303 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3305, ptr %p3304, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot22, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i32 0, ptr %p3307, align 4, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot9, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  store i32 2, ptr %p3309, align 4, !alias.scope !3, !noalias !4
  %v3310 = load i64, ptr %slot23, align 8
  %p3311 = inttoptr i64 %v3310 to ptr
  %ld3312 = load i32, ptr %p3311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3312, ptr %slot440, align 8
  %v3313 = load i32, ptr %slot440, align 8
  %v3314 = load i64, ptr %slot9, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  store i32 %v3313, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot8, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  store i32 1, ptr %p3317, align 4, !alias.scope !3, !noalias !4
  %v3318 = load i64, ptr %slot37, align 8
  %v3319 = load i64, ptr %slot42, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i64 %v3318, ptr %p3320, align 8, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot42, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %ld3323 = load i64, ptr %p3322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3323, ptr %slot441, align 8
  %v3324 = load i64, ptr %slot441, align 8
  %op3325 = add i64 %v3324, 16
  store i64 %op3325, ptr %slot442, align 8
  %v3326 = load i64, ptr %slot442, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %ld3328 = load i64, ptr %p3327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3328, ptr %slot443, align 8
  %v3329 = load i64, ptr %slot443, align 8
  %v3330 = load i64, ptr %slot42, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  store i64 %v3329, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  %v3332 = load i64, ptr %slot18, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i32, ptr %p3333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3334, ptr %slot444, align 8
  %v3335 = load i32, ptr %slot444, align 8
  %cv3336 = zext i32 %v3335 to i64
  %cond3337 = icmp ne i64 %cv3336, 0
  br i1 %cond3337, label %bb_rcslotdrop529, label %bb_rcslotdone529
bb_rcslotdrop529:
  %v3338 = load i64, ptr %slot18, align 8
  %p3339 = inttoptr i64 %v3338 to ptr
  store i32 0, ptr %p3339, align 4, !alias.scope !3, !noalias !4
  %v3340 = load i64, ptr %slot24, align 8
  store i64 %v3340, ptr %slot445, align 8
  %v3341 = load i64, ptr %slot19, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i32, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3343, ptr %slot446, align 8
  %v3344 = load i32, ptr %slot446, align 8
  %op3345 = and i32 %v3344, 28
  store i32 %op3345, ptr %slot447, align 8
  %v3346 = load i32, ptr %slot447, align 8
  %cv3347 = zext i32 %v3346 to i64
  %cond3348 = icmp ne i64 %cv3347, 0
  br i1 %cond3348, label %bb_rcslotrole529, label %bb_rcslotowner529
bb_rcslotrole529:
  %v3349 = load i64, ptr %slot45, align 8
  store i64 %v3349, ptr %slot448, align 8
  %v3350 = load i64, ptr %slot448, align 8
  %v3351 = load i64, ptr %slot445, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3350, i64 %v3351) nomerge, !dbg !130
  br label %bb_rcslotdone529
bb_rcslotowner529:
  %v3352 = load i64, ptr %slot45, align 8
  store i64 %v3352, ptr %slot449, align 8
  %v3353 = load i64, ptr %slot449, align 8
  %v3354 = load i64, ptr %slot445, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3353, i64 %v3354) nomerge, !dbg !130
  br label %bb_rcslotdone529
bb_rcslotdone529:
  %v3355 = load i64, ptr %slot37, align 8
  %v3356 = load i64, ptr %slot43, align 8
  %p3357 = inttoptr i64 %v3356 to ptr
  store i64 %v3355, ptr %p3357, align 8, !alias.scope !3, !noalias !4
  %v3358 = load i64, ptr %slot43, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3360, ptr %slot450, align 8
  %v3361 = load i64, ptr %slot450, align 8
  %op3362 = add i64 %v3361, 0
  store i64 %op3362, ptr %slot451, align 8
  %v3363 = load i64, ptr %slot451, align 8
  %p3364 = inttoptr i64 %v3363 to ptr
  %ld3365 = load i64, ptr %p3364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3365, ptr %slot452, align 8
  %v3366 = load i64, ptr %slot452, align 8
  %v3367 = load i64, ptr %slot43, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  store i64 %v3366, ptr %p3368, align 8, !alias.scope !3, !noalias !4
  %v3369 = load i64, ptr %slot43, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %ld3371 = load i64, ptr %p3370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3371, ptr %slot453, align 8
  %v3372 = load i64, ptr %slot453, align 8
  %v3373 = load i64, ptr %slot27, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i64 %v3372, ptr %p3374, align 8, !alias.scope !3, !noalias !4
  %v3375 = load i64, ptr %slot27, align 8
  store i64 %v3375, ptr %slot454, align 8
  %v3376 = load i64, ptr %slot28, align 8
  store i64 %v3376, ptr %slot455, align 8
  %v3377 = load i64, ptr %slot454, align 8
  %p3378 = inttoptr i64 %v3377 to ptr
  %ld3379 = load i64, ptr %p3378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3379, ptr %slot456, align 8
  %v3380 = load i64, ptr %slot456, align 8
  %cmp3381 = icmp ne i64 %v3380, 0
  %cv3382 = zext i1 %cmp3381 to i32
  store i32 %cv3382, ptr %slot457, align 8
  %v3383 = load i32, ptr %slot457, align 8
  %cv3384 = zext i32 %v3383 to i64
  %cond3385 = icmp ne i64 %cv3384, 0
  br i1 %cond3385, label %bb_rcgnn543, label %bb_rcgstore543
bb_rcgnn543:
  %v3386 = load i64, ptr %slot456, align 8
  %op3387 = sub i64 %v3386, 16
  store i64 %op3387, ptr %slot458, align 8
  %v3388 = load i64, ptr %slot456, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  %rgep3390 = getelementptr i8, ptr %p3389, i64 -16
  %ld3391 = load i64, ptr %rgep3390, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3391, ptr %slot459, align 8
  %v3392 = load i64, ptr %slot459, align 8
  %op3393 = and i64 %v3392, 4611686018427387906
  store i64 %op3393, ptr %slot460, align 8
  %v3394 = load i64, ptr %slot460, align 8
  %cmp3395 = icmp ne i64 %v3394, 0
  %cv3396 = zext i1 %cmp3395 to i32
  store i32 %cv3396, ptr %slot461, align 8
  %v3397 = load i32, ptr %slot461, align 8
  %cv3398 = zext i32 %v3397 to i64
  %cond3399 = icmp ne i64 %cv3398, 0
  br i1 %cond3399, label %bb_rcgstore543, label %bb_rcginc543
bb_rcginc543:
  %v3400 = load i64, ptr %slot456, align 8
  %op3401 = sub i64 %v3400, 24
  store i64 %op3401, ptr %slot462, align 8
  %v3402 = load i64, ptr %slot456, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %rgep3404 = getelementptr i8, ptr %p3403, i64 -24
  %ld3405 = load i64, ptr %rgep3404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3405, ptr %slot463, align 8
  %v3406 = load i64, ptr %slot463, align 8
  %op3407 = add i64 %v3406, 1
  store i64 %op3407, ptr %slot464, align 8
  %v3408 = load i64, ptr %slot464, align 8
  %cmp3409 = icmp eq i64 %v3408, 0
  %cv3410 = zext i1 %cmp3409 to i32
  store i32 %cv3410, ptr %slot465, align 8
  %v3411 = load i32, ptr %slot465, align 8
  %cv3412 = zext i32 %v3411 to i64
  %cond3413 = icmp ne i64 %cv3412, 0
  br i1 %cond3413, label %bb_rcglimit543, label %bb_rcgcapacity543
bb_rcglimit543:
  %v3414 = load i64, ptr %slot1, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %call3416 = call i32 @myl_qbe_rc_status(ptr %p3415, i32 2) nomerge, !dbg !132
  store i32 %call3416, ptr %slot466, align 8
  br label %bb_failure
bb_rcgcapacity543:
  %v3417 = load i64, ptr %slot464, align 8
  %v3418 = load i64, ptr %slot456, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %rgep3420 = getelementptr i8, ptr %p3419, i64 -24
  store i64 %v3417, ptr %rgep3420, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore543
bb_rcgstore543:
  %v3421 = load i64, ptr %slot456, align 8
  %v3422 = load i64, ptr %slot455, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  store i64 %v3421, ptr %p3423, align 8, !alias.scope !3, !noalias !4
  %v3424 = load i64, ptr %slot23, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  store i32 2, ptr %p3425, align 4, !alias.scope !3, !noalias !4
  %v3426 = load i64, ptr %slot23, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  store i32 16, ptr %p3427, align 4, !alias.scope !3, !noalias !4
  %v3428 = load i64, ptr %slot22, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  store i32 1, ptr %p3429, align 4, !alias.scope !3, !noalias !4
  %v3430 = load i64, ptr %slot20, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i32, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3432, ptr %slot467, align 8
  %v3433 = load i32, ptr %slot467, align 8
  %cv3434 = zext i32 %v3433 to i64
  %cond3435 = icmp ne i64 %cv3434, 0
  br i1 %cond3435, label %bb_rcslotdrop559, label %bb_rcslotdone559
bb_rcslotdrop559:
  %v3436 = load i64, ptr %slot20, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  store i32 0, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  %v3438 = load i64, ptr %slot25, align 8
  store i64 %v3438, ptr %slot468, align 8
  %v3439 = load i64, ptr %slot21, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %ld3441 = load i32, ptr %p3440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3441, ptr %slot469, align 8
  %v3442 = load i32, ptr %slot469, align 8
  %op3443 = and i32 %v3442, 28
  store i32 %op3443, ptr %slot470, align 8
  %v3444 = load i32, ptr %slot470, align 8
  %cv3445 = zext i32 %v3444 to i64
  %cond3446 = icmp ne i64 %cv3445, 0
  br i1 %cond3446, label %bb_rcslotrole559, label %bb_rcslotowner559
bb_rcslotrole559:
  %v3447 = load i64, ptr %slot45, align 8
  store i64 %v3447, ptr %slot471, align 8
  %v3448 = load i64, ptr %slot471, align 8
  %v3449 = load i64, ptr %slot468, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3448, i64 %v3449) nomerge, !dbg !132
  br label %bb_rcslotdone559
bb_rcslotowner559:
  %v3450 = load i64, ptr %slot45, align 8
  store i64 %v3450, ptr %slot472, align 8
  %v3451 = load i64, ptr %slot472, align 8
  %v3452 = load i64, ptr %slot468, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3451, i64 %v3452) nomerge, !dbg !132
  br label %bb_rcslotdone559
bb_rcslotdone559:
  %v3453 = load i64, ptr %slot25, align 8
  store i64 %v3453, ptr %slot473, align 8
  %v3454 = load i64, ptr %slot28, align 8
  store i64 %v3454, ptr %slot474, align 8
  %v3455 = load i64, ptr %slot474, align 8
  %v3456 = load i64, ptr %slot473, align 8
  %p3457 = inttoptr i64 %v3455 to ptr
  %p3458 = inttoptr i64 %v3456 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3458, ptr %p3457, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3459 = load i64, ptr %slot21, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i32 2, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot23, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %ld3463 = load i32, ptr %p3462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3463, ptr %slot475, align 8
  %v3464 = load i32, ptr %slot475, align 8
  %v3465 = load i64, ptr %slot21, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  store i32 %v3464, ptr %p3466, align 4, !alias.scope !3, !noalias !4
  %v3467 = load i64, ptr %slot22, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  store i32 0, ptr %p3468, align 4, !alias.scope !3, !noalias !4
  %v3469 = load i64, ptr %slot20, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  store i32 1, ptr %p3470, align 4, !alias.scope !3, !noalias !4
  %v3471 = load i64, ptr %slot473, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  %ld3473 = load i64, ptr %p3472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3473, ptr %slot476, align 8
  %v3474 = load i64, ptr %slot476, align 8
  %v3475 = load i64, ptr %slot43, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i64 %v3474, ptr %p3476, align 8, !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot43, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  %ld3479 = load i64, ptr %p3478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3479, ptr %slot477, align 8
  %v3480 = load i64, ptr %slot477, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  %ld3482 = load i64, ptr %p3481, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3482, ptr %slot478, align 8
  %v3483 = load i64, ptr %slot478, align 8
  %v3484 = load i64, ptr %slot43, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  store i64 %v3483, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  %v3486 = load i64, ptr %slot20, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  %ld3488 = load i32, ptr %p3487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3488, ptr %slot479, align 8
  %v3489 = load i32, ptr %slot479, align 8
  %cv3490 = zext i32 %v3489 to i64
  %cond3491 = icmp ne i64 %cv3490, 0
  br i1 %cond3491, label %bb_rcslotdrop579, label %bb_rcslotdone579
bb_rcslotdrop579:
  %v3492 = load i64, ptr %slot20, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  store i32 0, ptr %p3493, align 4, !alias.scope !3, !noalias !4
  %v3494 = load i64, ptr %slot25, align 8
  store i64 %v3494, ptr %slot480, align 8
  %v3495 = load i64, ptr %slot21, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %ld3497 = load i32, ptr %p3496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3497, ptr %slot481, align 8
  %v3498 = load i32, ptr %slot481, align 8
  %op3499 = and i32 %v3498, 28
  store i32 %op3499, ptr %slot482, align 8
  %v3500 = load i32, ptr %slot482, align 8
  %cv3501 = zext i32 %v3500 to i64
  %cond3502 = icmp ne i64 %cv3501, 0
  br i1 %cond3502, label %bb_rcslotrole579, label %bb_rcslotowner579
bb_rcslotrole579:
  %v3503 = load i64, ptr %slot45, align 8
  store i64 %v3503, ptr %slot483, align 8
  %v3504 = load i64, ptr %slot480, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i64, ptr %p3505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3506, ptr %slot484, align 8
  %v3507 = load i64, ptr %slot484, align 8
  %cmp3508 = icmp ne i64 %v3507, 0
  %cv3509 = zext i1 %cmp3508 to i32
  store i32 %cv3509, ptr %slot485, align 8
  %v3510 = load i32, ptr %slot485, align 8
  %cv3511 = zext i32 %v3510 to i64
  %cond3512 = icmp ne i64 %cv3511, 0
  br i1 %cond3512, label %bb_rcgnn595, label %bb_rcgdone595
bb_rcgnn595:
  %v3513 = load i64, ptr %slot484, align 8
  %op3514 = sub i64 %v3513, 16
  store i64 %op3514, ptr %slot486, align 8
  %v3515 = load i64, ptr %slot484, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  %rgep3517 = getelementptr i8, ptr %p3516, i64 -16
  %ld3518 = load i64, ptr %rgep3517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3518, ptr %slot487, align 8
  %v3519 = load i64, ptr %slot487, align 8
  %op3520 = and i64 %v3519, 4611686018427387906
  store i64 %op3520, ptr %slot488, align 8
  %v3521 = load i64, ptr %slot488, align 8
  %cmp3522 = icmp ne i64 %v3521, 0
  %cv3523 = zext i1 %cmp3522 to i32
  store i32 %cv3523, ptr %slot489, align 8
  %v3524 = load i32, ptr %slot489, align 8
  %cv3525 = zext i32 %v3524 to i64
  %cond3526 = icmp ne i64 %cv3525, 0
  br i1 %cond3526, label %bb_rcgclear595, label %bb_rcgcounted595
bb_rcgcounted595:
  %v3527 = load i64, ptr %slot484, align 8
  %op3528 = sub i64 %v3527, 24
  store i64 %op3528, ptr %slot490, align 8
  %v3529 = load i64, ptr %slot484, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  %rgep3531 = getelementptr i8, ptr %p3530, i64 -24
  %ld3532 = load i64, ptr %rgep3531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3532, ptr %slot491, align 8
  %v3533 = load i64, ptr %slot491, align 8
  %op3534 = sub i64 %v3533, 1
  store i64 %op3534, ptr %slot492, align 8
  %v3535 = load i64, ptr %slot492, align 8
  %cmp3536 = icmp eq i64 %v3535, 0
  %cv3537 = zext i1 %cmp3536 to i32
  store i32 %cv3537, ptr %slot493, align 8
  %v3538 = load i32, ptr %slot493, align 8
  %cv3539 = zext i32 %v3538 to i64
  %cond3540 = icmp ne i64 %cv3539, 0
  br i1 %cond3540, label %bb_rcglast595, label %bb_rcgdec595
bb_rcglast595:
  %v3541 = load i64, ptr %slot484, align 8
  %op3542 = sub i64 %v3541, 32
  store i64 %op3542, ptr %slot494, align 8
  %v3543 = load i64, ptr %slot484, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %rgep3545 = getelementptr i8, ptr %p3544, i64 -32
  %ld3546 = load i64, ptr %rgep3545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3546, ptr %slot495, align 8
  %v3547 = load i64, ptr %slot495, align 8
  %cmp3548 = icmp ne i64 %v3547, 0
  %cv3549 = zext i1 %cmp3548 to i32
  store i32 %cv3549, ptr %slot496, align 8
  %v3550 = load i32, ptr %slot496, align 8
  %cv3551 = zext i32 %v3550 to i64
  %cond3552 = icmp ne i64 %cv3551, 0
  br i1 %cond3552, label %bb_rcgdec595, label %bb_rcgslow595
bb_rcgslow595:
  %v3553 = load i64, ptr %slot483, align 8
  %v3554 = load i64, ptr %slot480, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3553, i64 %v3554) nomerge, !dbg !134
  br label %bb_rcgdone595
bb_rcgdec595:
  %v3555 = load i64, ptr %slot492, align 8
  %v3556 = load i64, ptr %slot484, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  %rgep3558 = getelementptr i8, ptr %p3557, i64 -24
  store i64 %v3555, ptr %rgep3558, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear595
bb_rcgclear595:
  %v3559 = load i64, ptr %slot480, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  store i64 0, ptr %p3560, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone595
bb_rcgdone595:
  br label %bb_rcslotdone579
bb_rcslotowner579:
  %v3561 = load i64, ptr %slot45, align 8
  store i64 %v3561, ptr %slot497, align 8
  %v3562 = load i64, ptr %slot480, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  %ld3564 = load i64, ptr %p3563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3564, ptr %slot498, align 8
  %v3565 = load i64, ptr %slot498, align 8
  %cmp3566 = icmp ne i64 %v3565, 0
  %cv3567 = zext i1 %cmp3566 to i32
  store i32 %cv3567, ptr %slot499, align 8
  %v3568 = load i32, ptr %slot499, align 8
  %cv3569 = zext i32 %v3568 to i64
  %cond3570 = icmp ne i64 %cv3569, 0
  br i1 %cond3570, label %bb_rcgnn610, label %bb_rcgdone610
bb_rcgnn610:
  %v3571 = load i64, ptr %slot498, align 8
  %op3572 = sub i64 %v3571, 16
  store i64 %op3572, ptr %slot500, align 8
  %v3573 = load i64, ptr %slot498, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %rgep3575 = getelementptr i8, ptr %p3574, i64 -16
  %ld3576 = load i64, ptr %rgep3575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3576, ptr %slot501, align 8
  %v3577 = load i64, ptr %slot501, align 8
  %op3578 = and i64 %v3577, 4611686018427387906
  store i64 %op3578, ptr %slot502, align 8
  %v3579 = load i64, ptr %slot502, align 8
  %cmp3580 = icmp ne i64 %v3579, 0
  %cv3581 = zext i1 %cmp3580 to i32
  store i32 %cv3581, ptr %slot503, align 8
  %v3582 = load i32, ptr %slot503, align 8
  %cv3583 = zext i32 %v3582 to i64
  %cond3584 = icmp ne i64 %cv3583, 0
  br i1 %cond3584, label %bb_rcgclear610, label %bb_rcgcounted610
bb_rcgcounted610:
  %v3585 = load i64, ptr %slot498, align 8
  %op3586 = sub i64 %v3585, 32
  store i64 %op3586, ptr %slot504, align 8
  %v3587 = load i64, ptr %slot498, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  %rgep3589 = getelementptr i8, ptr %p3588, i64 -32
  %ld3590 = load i64, ptr %rgep3589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3590, ptr %slot505, align 8
  %v3591 = load i64, ptr %slot505, align 8
  %op3592 = sub i64 %v3591, 1
  store i64 %op3592, ptr %slot506, align 8
  %v3593 = load i64, ptr %slot506, align 8
  %cmp3594 = icmp eq i64 %v3593, 0
  %cv3595 = zext i1 %cmp3594 to i32
  store i32 %cv3595, ptr %slot507, align 8
  %v3596 = load i32, ptr %slot507, align 8
  %cv3597 = zext i32 %v3596 to i64
  %cond3598 = icmp ne i64 %cv3597, 0
  br i1 %cond3598, label %bb_rcglast610, label %bb_rcgdec610
bb_rcglast610:
  %v3599 = load i64, ptr %slot498, align 8
  %op3600 = sub i64 %v3599, 24
  store i64 %op3600, ptr %slot508, align 8
  %v3601 = load i64, ptr %slot498, align 8
  %p3602 = inttoptr i64 %v3601 to ptr
  %rgep3603 = getelementptr i8, ptr %p3602, i64 -24
  %ld3604 = load i64, ptr %rgep3603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3604, ptr %slot509, align 8
  %v3605 = load i64, ptr %slot509, align 8
  %cmp3606 = icmp ne i64 %v3605, 0
  %cv3607 = zext i1 %cmp3606 to i32
  store i32 %cv3607, ptr %slot510, align 8
  %v3608 = load i32, ptr %slot510, align 8
  %cv3609 = zext i32 %v3608 to i64
  %cond3610 = icmp ne i64 %cv3609, 0
  br i1 %cond3610, label %bb_rcgdec610, label %bb_rcgslow610
bb_rcgslow610:
  %v3611 = load i64, ptr %slot497, align 8
  %v3612 = load i64, ptr %slot480, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3611, i64 %v3612) nomerge, !dbg !134
  br label %bb_rcgdone610
bb_rcgdec610:
  %v3613 = load i64, ptr %slot506, align 8
  %v3614 = load i64, ptr %slot498, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  %rgep3616 = getelementptr i8, ptr %p3615, i64 -32
  store i64 %v3613, ptr %rgep3616, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear610
bb_rcgclear610:
  %v3617 = load i64, ptr %slot480, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  store i64 0, ptr %p3618, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone610
bb_rcgdone610:
  br label %bb_rcslotdone579
bb_rcslotdone579:
  %v3619 = load i64, ptr %slot43, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  %ld3621 = load i64, ptr %p3620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3621, ptr %slot511, align 8
  %v3622 = load i64, ptr %slot42, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %ld3624 = load i64, ptr %p3623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3624, ptr %slot512, align 8
  %v3625 = load i64, ptr %slot512, align 8
  %v3626 = load i64, ptr %slot511, align 8
  %cmp3627 = icmp sge i64 %v3625, %v3626
  %cv3628 = zext i1 %cmp3627 to i64
  store i64 %cv3628, ptr %slot513, align 8
  %v3629 = load i64, ptr %slot513, align 8
  %v3630 = load i64, ptr %slot42, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  store i64 %v3629, ptr %p3631, align 8, !alias.scope !3, !noalias !4
  br label %bb_i31
bb_i31:
  %v3632 = load i64, ptr %slot42, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  %ld3634 = load i64, ptr %p3633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3634, ptr %slot514, align 8
  %v3635 = load i64, ptr %slot514, align 8
  %cond3636 = icmp ne i64 %v3635, 0
  br i1 %cond3636, label %bb_next618, label %bb_i34
bb_next618:
  %v3637 = load i64, ptr %slot42, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i64 0, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot42, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  %ld3641 = load i64, ptr %p3640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3641, ptr %slot515, align 8
  %v3642 = load i64, ptr %slot18, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  %ld3644 = load i32, ptr %p3643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3644, ptr %slot516, align 8
  %v3645 = load i32, ptr %slot516, align 8
  %cv3646 = zext i32 %v3645 to i64
  %cond3647 = icmp ne i64 %cv3646, 0
  br i1 %cond3647, label %bb_rcslotdrop621, label %bb_rcslotdone621
bb_rcslotdrop621:
  %v3648 = load i64, ptr %slot18, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  store i32 0, ptr %p3649, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone621
bb_rcslotdone621:
  %v3650 = load i64, ptr %slot16, align 8
  %p3651 = inttoptr i64 %v3650 to ptr
  %ld3652 = load i32, ptr %p3651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3652, ptr %slot517, align 8
  %v3653 = load i32, ptr %slot517, align 8
  %cv3654 = zext i32 %v3653 to i64
  %cond3655 = icmp ne i64 %cv3654, 0
  br i1 %cond3655, label %bb_rcslotdrop624, label %bb_rcslotdone624
bb_rcslotdrop624:
  %v3656 = load i64, ptr %slot16, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  store i32 0, ptr %p3657, align 4, !alias.scope !3, !noalias !4
  %v3658 = load i64, ptr %slot41, align 8
  store i64 %v3658, ptr %slot518, align 8
  %v3659 = load i64, ptr %slot17, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %ld3661 = load i32, ptr %p3660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3661, ptr %slot519, align 8
  %v3662 = load i32, ptr %slot519, align 8
  %op3663 = and i32 %v3662, 28
  store i32 %op3663, ptr %slot520, align 8
  %v3664 = load i32, ptr %slot520, align 8
  %cv3665 = zext i32 %v3664 to i64
  %cond3666 = icmp ne i64 %cv3665, 0
  br i1 %cond3666, label %bb_rcslotrole624, label %bb_rcslotowner624
bb_rcslotrole624:
  %v3667 = load i64, ptr %slot45, align 8
  store i64 %v3667, ptr %slot521, align 8
  %v3668 = load i64, ptr %slot521, align 8
  %v3669 = load i64, ptr %slot518, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3668, i64 %v3669) nomerge, !dbg !136
  br label %bb_rcslotdone624
bb_rcslotowner624:
  %v3670 = load i64, ptr %slot45, align 8
  store i64 %v3670, ptr %slot522, align 8
  %v3671 = load i64, ptr %slot522, align 8
  %v3672 = load i64, ptr %slot518, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3671, i64 %v3672) nomerge, !dbg !136
  br label %bb_rcslotdone624
bb_rcslotdone624:
  %v3673 = load i64, ptr %slot14, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i32, ptr %p3674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3675, ptr %slot523, align 8
  %v3676 = load i32, ptr %slot523, align 8
  %cv3677 = zext i32 %v3676 to i64
  %cond3678 = icmp ne i64 %cv3677, 0
  br i1 %cond3678, label %bb_rcslotdrop633, label %bb_rcslotdone633
bb_rcslotdrop633:
  %v3679 = load i64, ptr %slot14, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  store i32 0, ptr %p3680, align 4, !alias.scope !3, !noalias !4
  %v3681 = load i64, ptr %slot40, align 8
  store i64 %v3681, ptr %slot524, align 8
  %v3682 = load i64, ptr %slot15, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  %ld3684 = load i32, ptr %p3683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3684, ptr %slot525, align 8
  %v3685 = load i32, ptr %slot525, align 8
  %op3686 = and i32 %v3685, 28
  store i32 %op3686, ptr %slot526, align 8
  %v3687 = load i32, ptr %slot526, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcslotrole633, label %bb_rcslotowner633
bb_rcslotrole633:
  %v3690 = load i64, ptr %slot45, align 8
  store i64 %v3690, ptr %slot527, align 8
  %v3691 = load i64, ptr %slot527, align 8
  %v3692 = load i64, ptr %slot524, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3691, i64 %v3692) nomerge, !dbg !136
  br label %bb_rcslotdone633
bb_rcslotowner633:
  %v3693 = load i64, ptr %slot45, align 8
  store i64 %v3693, ptr %slot528, align 8
  %v3694 = load i64, ptr %slot528, align 8
  %v3695 = load i64, ptr %slot524, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3694, i64 %v3695) nomerge, !dbg !136
  br label %bb_rcslotdone633
bb_rcslotdone633:
  %v3696 = load i64, ptr %slot12, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i32, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3698, ptr %slot529, align 8
  %v3699 = load i32, ptr %slot529, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcslotdrop642, label %bb_rcslotdone642
bb_rcslotdrop642:
  %v3702 = load i64, ptr %slot12, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  store i32 0, ptr %p3703, align 4, !alias.scope !3, !noalias !4
  %v3704 = load i64, ptr %slot39, align 8
  store i64 %v3704, ptr %slot530, align 8
  %v3705 = load i64, ptr %slot13, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %ld3707 = load i32, ptr %p3706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3707, ptr %slot531, align 8
  %v3708 = load i32, ptr %slot531, align 8
  %op3709 = and i32 %v3708, 28
  store i32 %op3709, ptr %slot532, align 8
  %v3710 = load i32, ptr %slot532, align 8
  %cv3711 = zext i32 %v3710 to i64
  %cond3712 = icmp ne i64 %cv3711, 0
  br i1 %cond3712, label %bb_rcslotrole642, label %bb_rcslotowner642
bb_rcslotrole642:
  %v3713 = load i64, ptr %slot45, align 8
  store i64 %v3713, ptr %slot533, align 8
  %v3714 = load i64, ptr %slot533, align 8
  %v3715 = load i64, ptr %slot530, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3714, i64 %v3715) nomerge, !dbg !136
  br label %bb_rcslotdone642
bb_rcslotowner642:
  %v3716 = load i64, ptr %slot45, align 8
  store i64 %v3716, ptr %slot534, align 8
  %v3717 = load i64, ptr %slot534, align 8
  %v3718 = load i64, ptr %slot530, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3717, i64 %v3718) nomerge, !dbg !136
  br label %bb_rcslotdone642
bb_rcslotdone642:
  %v3719 = load i64, ptr %slot10, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i32, ptr %p3720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3721, ptr %slot535, align 8
  %v3722 = load i32, ptr %slot535, align 8
  %cv3723 = zext i32 %v3722 to i64
  %cond3724 = icmp ne i64 %cv3723, 0
  br i1 %cond3724, label %bb_rcslotdrop651, label %bb_rcslotdone651
bb_rcslotdrop651:
  %v3725 = load i64, ptr %slot10, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  store i32 0, ptr %p3726, align 4, !alias.scope !3, !noalias !4
  %v3727 = load i64, ptr %slot38, align 8
  store i64 %v3727, ptr %slot536, align 8
  %v3728 = load i64, ptr %slot11, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  %ld3730 = load i32, ptr %p3729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3730, ptr %slot537, align 8
  %v3731 = load i32, ptr %slot537, align 8
  %op3732 = and i32 %v3731, 28
  store i32 %op3732, ptr %slot538, align 8
  %v3733 = load i32, ptr %slot538, align 8
  %cv3734 = zext i32 %v3733 to i64
  %cond3735 = icmp ne i64 %cv3734, 0
  br i1 %cond3735, label %bb_rcslotrole651, label %bb_rcslotowner651
bb_rcslotrole651:
  %v3736 = load i64, ptr %slot45, align 8
  store i64 %v3736, ptr %slot539, align 8
  %v3737 = load i64, ptr %slot539, align 8
  %v3738 = load i64, ptr %slot536, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3737, i64 %v3738) nomerge, !dbg !136
  br label %bb_rcslotdone651
bb_rcslotowner651:
  %v3739 = load i64, ptr %slot45, align 8
  store i64 %v3739, ptr %slot540, align 8
  %v3740 = load i64, ptr %slot540, align 8
  %v3741 = load i64, ptr %slot536, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3740, i64 %v3741) nomerge, !dbg !136
  br label %bb_rcslotdone651
bb_rcslotdone651:
  %v3742 = load i64, ptr %slot8, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  %ld3744 = load i32, ptr %p3743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3744, ptr %slot541, align 8
  %v3745 = load i32, ptr %slot541, align 8
  %cv3746 = zext i32 %v3745 to i64
  %cond3747 = icmp ne i64 %cv3746, 0
  br i1 %cond3747, label %bb_rcslotdrop660, label %bb_rcslotdone660
bb_rcslotdrop660:
  %v3748 = load i64, ptr %slot8, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  store i32 0, ptr %p3749, align 4, !alias.scope !3, !noalias !4
  %v3750 = load i64, ptr %slot37, align 8
  store i64 %v3750, ptr %slot542, align 8
  %v3751 = load i64, ptr %slot9, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  %ld3753 = load i32, ptr %p3752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3753, ptr %slot543, align 8
  %v3754 = load i32, ptr %slot543, align 8
  %op3755 = and i32 %v3754, 28
  store i32 %op3755, ptr %slot544, align 8
  %v3756 = load i32, ptr %slot544, align 8
  %cv3757 = zext i32 %v3756 to i64
  %cond3758 = icmp ne i64 %cv3757, 0
  br i1 %cond3758, label %bb_rcslotrole660, label %bb_rcslotowner660
bb_rcslotrole660:
  %v3759 = load i64, ptr %slot45, align 8
  store i64 %v3759, ptr %slot545, align 8
  %v3760 = load i64, ptr %slot545, align 8
  %v3761 = load i64, ptr %slot542, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3760, i64 %v3761) nomerge, !dbg !136
  br label %bb_rcslotdone660
bb_rcslotowner660:
  %v3762 = load i64, ptr %slot45, align 8
  store i64 %v3762, ptr %slot546, align 8
  %v3763 = load i64, ptr %slot546, align 8
  %v3764 = load i64, ptr %slot542, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3763, i64 %v3764) nomerge, !dbg !136
  br label %bb_rcslotdone660
bb_rcslotdone660:
  %v3765 = load i64, ptr %slot6, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  %ld3767 = load i32, ptr %p3766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3767, ptr %slot547, align 8
  %v3768 = load i32, ptr %slot547, align 8
  %cv3769 = zext i32 %v3768 to i64
  %cond3770 = icmp ne i64 %cv3769, 0
  br i1 %cond3770, label %bb_rcslotdrop669, label %bb_rcslotdone669
bb_rcslotdrop669:
  %v3771 = load i64, ptr %slot6, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  store i32 0, ptr %p3772, align 4, !alias.scope !3, !noalias !4
  %v3773 = load i64, ptr %slot36, align 8
  store i64 %v3773, ptr %slot548, align 8
  %v3774 = load i64, ptr %slot7, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  %ld3776 = load i32, ptr %p3775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3776, ptr %slot549, align 8
  %v3777 = load i32, ptr %slot549, align 8
  %op3778 = and i32 %v3777, 28
  store i32 %op3778, ptr %slot550, align 8
  %v3779 = load i32, ptr %slot550, align 8
  %cv3780 = zext i32 %v3779 to i64
  %cond3781 = icmp ne i64 %cv3780, 0
  br i1 %cond3781, label %bb_rcslotrole669, label %bb_rcslotowner669
bb_rcslotrole669:
  %v3782 = load i64, ptr %slot45, align 8
  store i64 %v3782, ptr %slot551, align 8
  %v3783 = load i64, ptr %slot551, align 8
  %v3784 = load i64, ptr %slot548, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3783, i64 %v3784) nomerge, !dbg !136
  br label %bb_rcslotdone669
bb_rcslotowner669:
  %v3785 = load i64, ptr %slot45, align 8
  store i64 %v3785, ptr %slot552, align 8
  %v3786 = load i64, ptr %slot552, align 8
  %v3787 = load i64, ptr %slot548, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3786, i64 %v3787) nomerge, !dbg !136
  br label %bb_rcslotdone669
bb_rcslotdone669:
  %v3788 = load i64, ptr %slot4, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %ld3790 = load i32, ptr %p3789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3790, ptr %slot553, align 8
  %v3791 = load i32, ptr %slot553, align 8
  %cv3792 = zext i32 %v3791 to i64
  %cond3793 = icmp ne i64 %cv3792, 0
  br i1 %cond3793, label %bb_rcslotdrop678, label %bb_rcslotdone678
bb_rcslotdrop678:
  %v3794 = load i64, ptr %slot4, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  store i32 0, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot35, align 8
  store i64 %v3796, ptr %slot554, align 8
  %v3797 = load i64, ptr %slot5, align 8
  %p3798 = inttoptr i64 %v3797 to ptr
  %ld3799 = load i32, ptr %p3798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3799, ptr %slot555, align 8
  %v3800 = load i32, ptr %slot555, align 8
  %op3801 = and i32 %v3800, 28
  store i32 %op3801, ptr %slot556, align 8
  %v3802 = load i32, ptr %slot556, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcslotrole678, label %bb_rcslotowner678
bb_rcslotrole678:
  %v3805 = load i64, ptr %slot45, align 8
  store i64 %v3805, ptr %slot557, align 8
  %v3806 = load i64, ptr %slot557, align 8
  %v3807 = load i64, ptr %slot554, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3806, i64 %v3807) nomerge, !dbg !136
  br label %bb_rcslotdone678
bb_rcslotowner678:
  %v3808 = load i64, ptr %slot45, align 8
  store i64 %v3808, ptr %slot558, align 8
  %v3809 = load i64, ptr %slot558, align 8
  %v3810 = load i64, ptr %slot554, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3809, i64 %v3810) nomerge, !dbg !136
  br label %bb_rcslotdone678
bb_rcslotdone678:
  %v3811 = load i64, ptr %slot515, align 8
  ret i64 %v3811
bb_i34:
  %v3812 = load i64, ptr %slot30, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  %ld3814 = load i64, ptr %p3813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3814, ptr %slot559, align 8
  %v3815 = load i64, ptr %slot559, align 8
  %v3816 = load i64, ptr %slot42, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i64 %v3815, ptr %p3817, align 8, !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot43, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  store i64 32, ptr %p3819, align 8, !alias.scope !3, !noalias !4
  %v3820 = load i64, ptr %slot43, align 8
  %p3821 = inttoptr i64 %v3820 to ptr
  %ld3822 = load i64, ptr %p3821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3822, ptr %slot560, align 8
  %v3823 = load i64, ptr %slot42, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  %ld3825 = load i64, ptr %p3824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3825, ptr %slot561, align 8
  %v3826 = load i64, ptr %slot561, align 8
  %v3827 = load i64, ptr %slot560, align 8
  %cmp3828 = icmp eq i64 %v3826, %v3827
  %cv3829 = zext i1 %cmp3828 to i64
  store i64 %cv3829, ptr %slot562, align 8
  %v3830 = load i64, ptr %slot562, align 8
  %v3831 = load i64, ptr %slot42, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  store i64 %v3830, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  %v3833 = load i64, ptr %slot42, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %ld3835 = load i64, ptr %p3834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3835, ptr %slot563, align 8
  %v3836 = load i64, ptr %slot563, align 8
  %cond3837 = icmp ne i64 %v3836, 0
  br i1 %cond3837, label %bb_next735, label %bb_i40
bb_next735:
  %v3838 = load i64, ptr %slot42, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  store i64 1, ptr %p3839, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i40:
  %v3840 = load i64, ptr %slot30, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %ld3842 = load i64, ptr %p3841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3842, ptr %slot564, align 8
  %v3843 = load i64, ptr %slot564, align 8
  %v3844 = load i64, ptr %slot42, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  store i64 %v3843, ptr %p3845, align 8, !alias.scope !3, !noalias !4
  %v3846 = load i64, ptr %slot43, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  store i64 13, ptr %p3847, align 8, !alias.scope !3, !noalias !4
  %v3848 = load i64, ptr %slot43, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %ld3850 = load i64, ptr %p3849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3850, ptr %slot565, align 8
  %v3851 = load i64, ptr %slot42, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %ld3853 = load i64, ptr %p3852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3853, ptr %slot566, align 8
  %v3854 = load i64, ptr %slot566, align 8
  %v3855 = load i64, ptr %slot565, align 8
  %cmp3856 = icmp eq i64 %v3854, %v3855
  %cv3857 = zext i1 %cmp3856 to i64
  store i64 %cv3857, ptr %slot567, align 8
  %v3858 = load i64, ptr %slot567, align 8
  %v3859 = load i64, ptr %slot42, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i64 %v3858, ptr %p3860, align 8, !alias.scope !3, !noalias !4
  br label %bb_i43
bb_i43:
  %v3861 = load i64, ptr %slot42, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot568, align 8
  %v3864 = load i64, ptr %slot568, align 8
  %cond3865 = icmp ne i64 %v3864, 0
  br i1 %cond3865, label %bb_next740, label %bb_i46
bb_next740:
  %v3866 = load i64, ptr %slot42, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  store i64 1, ptr %p3867, align 8, !alias.scope !3, !noalias !4
  br label %bb_i49
bb_i46:
  %v3868 = load i64, ptr %slot30, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %ld3870 = load i64, ptr %p3869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3870, ptr %slot569, align 8
  %v3871 = load i64, ptr %slot569, align 8
  %v3872 = load i64, ptr %slot42, align 8
  %p3873 = inttoptr i64 %v3872 to ptr
  store i64 %v3871, ptr %p3873, align 8, !alias.scope !3, !noalias !4
  %v3874 = load i64, ptr %slot43, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  store i64 9, ptr %p3875, align 8, !alias.scope !3, !noalias !4
  %v3876 = load i64, ptr %slot43, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  %ld3878 = load i64, ptr %p3877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3878, ptr %slot570, align 8
  %v3879 = load i64, ptr %slot42, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %ld3881 = load i64, ptr %p3880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3881, ptr %slot571, align 8
  %v3882 = load i64, ptr %slot571, align 8
  %v3883 = load i64, ptr %slot570, align 8
  %cmp3884 = icmp eq i64 %v3882, %v3883
  %cv3885 = zext i1 %cmp3884 to i64
  store i64 %cv3885, ptr %slot572, align 8
  %v3886 = load i64, ptr %slot572, align 8
  %v3887 = load i64, ptr %slot42, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  store i64 %v3886, ptr %p3888, align 8, !alias.scope !3, !noalias !4
  br label %bb_i49
bb_i49:
  %v3889 = load i64, ptr %slot42, align 8
  %p3890 = inttoptr i64 %v3889 to ptr
  %ld3891 = load i64, ptr %p3890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3891, ptr %slot573, align 8
  %v3892 = load i64, ptr %slot573, align 8
  %cond3893 = icmp ne i64 %v3892, 0
  br i1 %cond3893, label %bb_next745, label %bb_i66
bb_next745:
  %v3894 = load i64, ptr %slot29, align 8
  %p3895 = inttoptr i64 %v3894 to ptr
  %ld3896 = load i64, ptr %p3895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3896, ptr %slot574, align 8
  %v3897 = load i64, ptr %slot574, align 8
  %v3898 = load i64, ptr %slot42, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  store i64 %v3897, ptr %p3899, align 8, !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot42, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  %ld3902 = load i64, ptr %p3901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3902, ptr %slot575, align 8
  %v3903 = load i64, ptr %slot575, align 8
  %op3904 = add i64 %v3903, 16
  store i64 %op3904, ptr %slot576, align 8
  %v3905 = load i64, ptr %slot576, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %ld3907 = load i64, ptr %p3906, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3907, ptr %slot577, align 8
  %v3908 = load i64, ptr %slot577, align 8
  %v3909 = load i64, ptr %slot42, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  store i64 %v3908, ptr %p3910, align 8, !alias.scope !3, !noalias !4
  %v3911 = load i64, ptr %slot18, align 8
  %p3912 = inttoptr i64 %v3911 to ptr
  %ld3913 = load i32, ptr %p3912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3913, ptr %slot578, align 8
  %v3914 = load i32, ptr %slot578, align 8
  %cv3915 = zext i32 %v3914 to i64
  %cond3916 = icmp ne i64 %cv3915, 0
  br i1 %cond3916, label %bb_rcslotdrop751, label %bb_rcslotdone751
bb_rcslotdrop751:
  %v3917 = load i64, ptr %slot18, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  store i32 0, ptr %p3918, align 4, !alias.scope !3, !noalias !4
  %v3919 = load i64, ptr %slot24, align 8
  store i64 %v3919, ptr %slot579, align 8
  %v3920 = load i64, ptr %slot19, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  %ld3922 = load i32, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3922, ptr %slot580, align 8
  %v3923 = load i32, ptr %slot580, align 8
  %op3924 = and i32 %v3923, 28
  store i32 %op3924, ptr %slot581, align 8
  %v3925 = load i32, ptr %slot581, align 8
  %cv3926 = zext i32 %v3925 to i64
  %cond3927 = icmp ne i64 %cv3926, 0
  br i1 %cond3927, label %bb_rcslotrole751, label %bb_rcslotowner751
bb_rcslotrole751:
  %v3928 = load i64, ptr %slot45, align 8
  store i64 %v3928, ptr %slot582, align 8
  %v3929 = load i64, ptr %slot582, align 8
  %v3930 = load i64, ptr %slot579, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v3929, i64 %v3930) nomerge, !dbg !138
  br label %bb_rcslotdone751
bb_rcslotowner751:
  %v3931 = load i64, ptr %slot45, align 8
  store i64 %v3931, ptr %slot583, align 8
  %v3932 = load i64, ptr %slot583, align 8
  %v3933 = load i64, ptr %slot579, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3932, i64 %v3933) nomerge, !dbg !138
  br label %bb_rcslotdone751
bb_rcslotdone751:
  %v3934 = load i64, ptr %slot43, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  store i64 1, ptr %p3935, align 8, !alias.scope !3, !noalias !4
  %v3936 = load i64, ptr %slot43, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  %ld3938 = load i64, ptr %p3937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3938, ptr %slot584, align 8
  %v3939 = load i64, ptr %slot42, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  %ld3941 = load i64, ptr %p3940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3941, ptr %slot585, align 8
  %v3942 = load i64, ptr %slot585, align 8
  %v3943 = load i64, ptr %slot584, align 8
  %ovpair3945 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3942, i64 %v3943)
  %op3944 = extractvalue { i64, i1 } %ovpair3945, 0
  %ov3946 = extractvalue { i64, i1 } %ovpair3945, 1
  store i64 %op3944, ptr %slot586, align 8
  %cv3947 = zext i1 %ov3946 to i64
  store i64 %cv3947, ptr %slot587, align 8
  %v3948 = load i64, ptr %slot587, align 8
  %cond3949 = icmp ne i64 %v3948, 0
  br i1 %cond3949, label %bb_overflow760, label %bb_checked760
bb_overflow760:
  %v3950 = load i64, ptr %slot1, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  %v3952 = load i64, ptr %slot585, align 8
  %v3953 = load i64, ptr %slot584, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3951, i64 0, i64 %v3952, i64 %v3953, i64 64) nomerge, !dbg !140
  unreachable
bb_checked760:
  %v3954 = load i64, ptr %slot586, align 8
  %v3955 = load i64, ptr %slot42, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  store i64 %v3954, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  %v3957 = load i64, ptr %slot42, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i64, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3959, ptr %slot588, align 8
  %v3960 = load i64, ptr %slot588, align 8
  %v3961 = load i64, ptr %slot31, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i64 %v3960, ptr %p3962, align 8, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot29, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  %ld3965 = load i64, ptr %p3964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3965, ptr %slot589, align 8
  %v3966 = load i64, ptr %slot589, align 8
  %v3967 = load i64, ptr %slot42, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  store i64 %v3966, ptr %p3968, align 8, !alias.scope !3, !noalias !4
  %v3969 = load i64, ptr %slot29, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  %ld3971 = load i64, ptr %p3970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3971, ptr %slot590, align 8
  %v3972 = load i64, ptr %slot590, align 8
  %v3973 = load i64, ptr %slot42, align 8
  %p3974 = inttoptr i64 %v3973 to ptr
  store i64 %v3972, ptr %p3974, align 8, !alias.scope !3, !noalias !4
  %v3975 = load i64, ptr %slot29, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  %ld3977 = load i64, ptr %p3976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3977, ptr %slot591, align 8
  %v3978 = load i64, ptr %slot591, align 8
  %v3979 = load i64, ptr %slot42, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  store i64 %v3978, ptr %p3980, align 8, !alias.scope !3, !noalias !4
  %v3981 = load i64, ptr %slot31, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  %ld3983 = load i64, ptr %p3982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3983, ptr %slot592, align 8
  %v3984 = load i64, ptr %slot592, align 8
  %v3985 = load i64, ptr %slot43, align 8
  %p3986 = inttoptr i64 %v3985 to ptr
  store i64 %v3984, ptr %p3986, align 8, !alias.scope !3, !noalias !4
  %v3987 = load i64, ptr %slot29, align 8
  %p3988 = inttoptr i64 %v3987 to ptr
  %ld3989 = load i64, ptr %p3988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3989, ptr %slot593, align 8
  %v3990 = load i64, ptr %slot593, align 8
  %v3991 = load i64, ptr %slot42, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  store i64 %v3990, ptr %p3992, align 8, !alias.scope !3, !noalias !4
  %v3993 = load i64, ptr %slot31, align 8
  %p3994 = inttoptr i64 %v3993 to ptr
  %ld3995 = load i64, ptr %p3994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3995, ptr %slot594, align 8
  %v3996 = load i64, ptr %slot29, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %ld3998 = load i64, ptr %p3997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3998, ptr %slot595, align 8
  %v3999 = load i64, ptr %slot595, align 8
  %op4000 = add i64 %v3999, 16
  store i64 %op4000, ptr %slot596, align 8
  %v4001 = load i64, ptr %slot594, align 8
  %v4002 = load i64, ptr %slot596, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  store i64 %v4001, ptr %p4003, align 8, !alias.scope !4, !noalias !3
  %v4004 = load i64, ptr %slot42, align 8
  %p4005 = inttoptr i64 %v4004 to ptr
  store i64 0, ptr %p4005, align 8, !alias.scope !3, !noalias !4
  br label %bb_i188
bb_i66:
  %v4006 = load i64, ptr %slot30, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %ld4008 = load i64, ptr %p4007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4008, ptr %slot597, align 8
  %v4009 = load i64, ptr %slot597, align 8
  %v4010 = load i64, ptr %slot42, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  store i64 %v4009, ptr %p4011, align 8, !alias.scope !3, !noalias !4
  %v4012 = load i64, ptr %slot43, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  store i64 10, ptr %p4013, align 8, !alias.scope !3, !noalias !4
  %v4014 = load i64, ptr %slot43, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i64, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4016, ptr %slot598, align 8
  %v4017 = load i64, ptr %slot42, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %ld4019 = load i64, ptr %p4018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4019, ptr %slot599, align 8
  %v4020 = load i64, ptr %slot599, align 8
  %v4021 = load i64, ptr %slot598, align 8
  %cmp4022 = icmp eq i64 %v4020, %v4021
  %cv4023 = zext i1 %cmp4022 to i64
  store i64 %cv4023, ptr %slot600, align 8
  %v4024 = load i64, ptr %slot600, align 8
  %v4025 = load i64, ptr %slot42, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  store i64 %v4024, ptr %p4026, align 8, !alias.scope !3, !noalias !4
  %v4027 = load i64, ptr %slot42, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %ld4029 = load i64, ptr %p4028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4029, ptr %slot601, align 8
  %v4030 = load i64, ptr %slot601, align 8
  %cond4031 = icmp ne i64 %v4030, 0
  br i1 %cond4031, label %bb_next776, label %bb_i101
bb_next776:
  %v4032 = load i64, ptr %slot29, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  %ld4034 = load i64, ptr %p4033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4034, ptr %slot602, align 8
  %v4035 = load i64, ptr %slot602, align 8
  %v4036 = load i64, ptr %slot42, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  store i64 %v4035, ptr %p4037, align 8, !alias.scope !3, !noalias !4
  %v4038 = load i64, ptr %slot42, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  %ld4040 = load i64, ptr %p4039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4040, ptr %slot603, align 8
  %v4041 = load i64, ptr %slot603, align 8
  %op4042 = add i64 %v4041, 24
  store i64 %op4042, ptr %slot604, align 8
  %v4043 = load i64, ptr %slot604, align 8
  %p4044 = inttoptr i64 %v4043 to ptr
  %ld4045 = load i64, ptr %p4044, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4045, ptr %slot605, align 8
  %v4046 = load i64, ptr %slot605, align 8
  %v4047 = load i64, ptr %slot42, align 8
  %p4048 = inttoptr i64 %v4047 to ptr
  store i64 %v4046, ptr %p4048, align 8, !alias.scope !3, !noalias !4
  %v4049 = load i64, ptr %slot18, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %ld4051 = load i32, ptr %p4050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4051, ptr %slot606, align 8
  %v4052 = load i32, ptr %slot606, align 8
  %cv4053 = zext i32 %v4052 to i64
  %cond4054 = icmp ne i64 %cv4053, 0
  br i1 %cond4054, label %bb_rcslotdrop782, label %bb_rcslotdone782
bb_rcslotdrop782:
  %v4055 = load i64, ptr %slot18, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  store i32 0, ptr %p4056, align 4, !alias.scope !3, !noalias !4
  %v4057 = load i64, ptr %slot24, align 8
  store i64 %v4057, ptr %slot607, align 8
  %v4058 = load i64, ptr %slot19, align 8
  %p4059 = inttoptr i64 %v4058 to ptr
  %ld4060 = load i32, ptr %p4059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4060, ptr %slot608, align 8
  %v4061 = load i32, ptr %slot608, align 8
  %op4062 = and i32 %v4061, 28
  store i32 %op4062, ptr %slot609, align 8
  %v4063 = load i32, ptr %slot609, align 8
  %cv4064 = zext i32 %v4063 to i64
  %cond4065 = icmp ne i64 %cv4064, 0
  br i1 %cond4065, label %bb_rcslotrole782, label %bb_rcslotowner782
bb_rcslotrole782:
  %v4066 = load i64, ptr %slot45, align 8
  store i64 %v4066, ptr %slot610, align 8
  %v4067 = load i64, ptr %slot610, align 8
  %v4068 = load i64, ptr %slot607, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4067, i64 %v4068) nomerge, !dbg !142
  br label %bb_rcslotdone782
bb_rcslotowner782:
  %v4069 = load i64, ptr %slot45, align 8
  store i64 %v4069, ptr %slot611, align 8
  %v4070 = load i64, ptr %slot611, align 8
  %v4071 = load i64, ptr %slot607, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4070, i64 %v4071) nomerge, !dbg !142
  br label %bb_rcslotdone782
bb_rcslotdone782:
  %v4072 = load i64, ptr %slot43, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  store i64 1, ptr %p4073, align 8, !alias.scope !3, !noalias !4
  %v4074 = load i64, ptr %slot43, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  %ld4076 = load i64, ptr %p4075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4076, ptr %slot612, align 8
  %v4077 = load i64, ptr %slot42, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %ld4079 = load i64, ptr %p4078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4079, ptr %slot613, align 8
  %v4080 = load i64, ptr %slot613, align 8
  %v4081 = load i64, ptr %slot612, align 8
  %ovpair4083 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4080, i64 %v4081)
  %op4082 = extractvalue { i64, i1 } %ovpair4083, 0
  %ov4084 = extractvalue { i64, i1 } %ovpair4083, 1
  store i64 %op4082, ptr %slot614, align 8
  %cv4085 = zext i1 %ov4084 to i64
  store i64 %cv4085, ptr %slot615, align 8
  %v4086 = load i64, ptr %slot615, align 8
  %cond4087 = icmp ne i64 %v4086, 0
  br i1 %cond4087, label %bb_overflow791, label %bb_checked791
bb_overflow791:
  %v4088 = load i64, ptr %slot1, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %v4090 = load i64, ptr %slot613, align 8
  %v4091 = load i64, ptr %slot612, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4089, i64 0, i64 %v4090, i64 %v4091, i64 64) nomerge, !dbg !144
  unreachable
bb_checked791:
  %v4092 = load i64, ptr %slot614, align 8
  %v4093 = load i64, ptr %slot42, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i64 %v4092, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot42, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  %ld4097 = load i64, ptr %p4096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4097, ptr %slot616, align 8
  %v4098 = load i64, ptr %slot616, align 8
  %v4099 = load i64, ptr %slot32, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i64 %v4098, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot29, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  %ld4103 = load i64, ptr %p4102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4103, ptr %slot617, align 8
  %v4104 = load i64, ptr %slot617, align 8
  %v4105 = load i64, ptr %slot42, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i64 %v4104, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot29, align 8
  %p4108 = inttoptr i64 %v4107 to ptr
  %ld4109 = load i64, ptr %p4108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4109, ptr %slot618, align 8
  %v4110 = load i64, ptr %slot618, align 8
  %v4111 = load i64, ptr %slot42, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  store i64 %v4110, ptr %p4112, align 8, !alias.scope !3, !noalias !4
  %v4113 = load i64, ptr %slot29, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %ld4115 = load i64, ptr %p4114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4115, ptr %slot619, align 8
  %v4116 = load i64, ptr %slot619, align 8
  %v4117 = load i64, ptr %slot42, align 8
  %p4118 = inttoptr i64 %v4117 to ptr
  store i64 %v4116, ptr %p4118, align 8, !alias.scope !3, !noalias !4
  %v4119 = load i64, ptr %slot32, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %ld4121 = load i64, ptr %p4120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4121, ptr %slot620, align 8
  %v4122 = load i64, ptr %slot620, align 8
  %v4123 = load i64, ptr %slot43, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  store i64 %v4122, ptr %p4124, align 8, !alias.scope !3, !noalias !4
  %v4125 = load i64, ptr %slot29, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %ld4127 = load i64, ptr %p4126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4127, ptr %slot621, align 8
  %v4128 = load i64, ptr %slot621, align 8
  %v4129 = load i64, ptr %slot42, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  store i64 %v4128, ptr %p4130, align 8, !alias.scope !3, !noalias !4
  %v4131 = load i64, ptr %slot32, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ld4133 = load i64, ptr %p4132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4133, ptr %slot622, align 8
  %v4134 = load i64, ptr %slot29, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i64, ptr %p4135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4136, ptr %slot623, align 8
  %v4137 = load i64, ptr %slot623, align 8
  %op4138 = add i64 %v4137, 24
  store i64 %op4138, ptr %slot624, align 8
  %v4139 = load i64, ptr %slot622, align 8
  %v4140 = load i64, ptr %slot624, align 8
  %p4141 = inttoptr i64 %v4140 to ptr
  store i64 %v4139, ptr %p4141, align 8, !alias.scope !4, !noalias !3
  %v4142 = load i64, ptr %slot42, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  store i64 0, ptr %p4143, align 8, !alias.scope !3, !noalias !4
  %v4144 = load i64, ptr %slot29, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  %ld4146 = load i64, ptr %p4145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4146, ptr %slot625, align 8
  %v4147 = load i64, ptr %slot625, align 8
  %v4148 = load i64, ptr %slot42, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  store i64 %v4147, ptr %p4149, align 8, !alias.scope !3, !noalias !4
  %v4150 = load i64, ptr %slot42, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  %ld4152 = load i64, ptr %p4151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4152, ptr %slot626, align 8
  %v4153 = load i64, ptr %slot626, align 8
  %op4154 = add i64 %v4153, 16
  store i64 %op4154, ptr %slot627, align 8
  %v4155 = load i64, ptr %slot627, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  %ld4157 = load i64, ptr %p4156, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4157, ptr %slot628, align 8
  %v4158 = load i64, ptr %slot628, align 8
  %v4159 = load i64, ptr %slot42, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  store i64 %v4158, ptr %p4160, align 8, !alias.scope !3, !noalias !4
  %v4161 = load i64, ptr %slot18, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %ld4163 = load i32, ptr %p4162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4163, ptr %slot629, align 8
  %v4164 = load i32, ptr %slot629, align 8
  %cv4165 = zext i32 %v4164 to i64
  %cond4166 = icmp ne i64 %cv4165, 0
  br i1 %cond4166, label %bb_rcslotdrop808, label %bb_rcslotdone808
bb_rcslotdrop808:
  %v4167 = load i64, ptr %slot18, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  store i32 0, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  %v4169 = load i64, ptr %slot24, align 8
  store i64 %v4169, ptr %slot630, align 8
  %v4170 = load i64, ptr %slot19, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %ld4172 = load i32, ptr %p4171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4172, ptr %slot631, align 8
  %v4173 = load i32, ptr %slot631, align 8
  %op4174 = and i32 %v4173, 28
  store i32 %op4174, ptr %slot632, align 8
  %v4175 = load i32, ptr %slot632, align 8
  %cv4176 = zext i32 %v4175 to i64
  %cond4177 = icmp ne i64 %cv4176, 0
  br i1 %cond4177, label %bb_rcslotrole808, label %bb_rcslotowner808
bb_rcslotrole808:
  %v4178 = load i64, ptr %slot45, align 8
  store i64 %v4178, ptr %slot633, align 8
  %v4179 = load i64, ptr %slot633, align 8
  %v4180 = load i64, ptr %slot630, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4179, i64 %v4180) nomerge, !dbg !146
  br label %bb_rcslotdone808
bb_rcslotowner808:
  %v4181 = load i64, ptr %slot45, align 8
  store i64 %v4181, ptr %slot634, align 8
  %v4182 = load i64, ptr %slot634, align 8
  %v4183 = load i64, ptr %slot630, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4182, i64 %v4183) nomerge, !dbg !146
  br label %bb_rcslotdone808
bb_rcslotdone808:
  %v4184 = load i64, ptr %slot43, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  store i64 1, ptr %p4185, align 8, !alias.scope !3, !noalias !4
  %v4186 = load i64, ptr %slot43, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  %ld4188 = load i64, ptr %p4187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4188, ptr %slot635, align 8
  %v4189 = load i64, ptr %slot42, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  %ld4191 = load i64, ptr %p4190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4191, ptr %slot636, align 8
  %v4192 = load i64, ptr %slot636, align 8
  %v4193 = load i64, ptr %slot635, align 8
  %ovpair4195 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4192, i64 %v4193)
  %op4194 = extractvalue { i64, i1 } %ovpair4195, 0
  %ov4196 = extractvalue { i64, i1 } %ovpair4195, 1
  store i64 %op4194, ptr %slot637, align 8
  %cv4197 = zext i1 %ov4196 to i64
  store i64 %cv4197, ptr %slot638, align 8
  %v4198 = load i64, ptr %slot638, align 8
  %cond4199 = icmp ne i64 %v4198, 0
  br i1 %cond4199, label %bb_overflow817, label %bb_checked817
bb_overflow817:
  %v4200 = load i64, ptr %slot1, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  %v4202 = load i64, ptr %slot636, align 8
  %v4203 = load i64, ptr %slot635, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4201, i64 0, i64 %v4202, i64 %v4203, i64 64) nomerge, !dbg !148
  unreachable
bb_checked817:
  %v4204 = load i64, ptr %slot637, align 8
  %v4205 = load i64, ptr %slot42, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  store i64 %v4204, ptr %p4206, align 8, !alias.scope !3, !noalias !4
  %v4207 = load i64, ptr %slot42, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  %ld4209 = load i64, ptr %p4208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4209, ptr %slot639, align 8
  %v4210 = load i64, ptr %slot639, align 8
  %v4211 = load i64, ptr %slot33, align 8
  %p4212 = inttoptr i64 %v4211 to ptr
  store i64 %v4210, ptr %p4212, align 8, !alias.scope !3, !noalias !4
  %v4213 = load i64, ptr %slot29, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %ld4215 = load i64, ptr %p4214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4215, ptr %slot640, align 8
  %v4216 = load i64, ptr %slot640, align 8
  %v4217 = load i64, ptr %slot42, align 8
  %p4218 = inttoptr i64 %v4217 to ptr
  store i64 %v4216, ptr %p4218, align 8, !alias.scope !3, !noalias !4
  %v4219 = load i64, ptr %slot29, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  %ld4221 = load i64, ptr %p4220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4221, ptr %slot641, align 8
  %v4222 = load i64, ptr %slot641, align 8
  %v4223 = load i64, ptr %slot42, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  store i64 %v4222, ptr %p4224, align 8, !alias.scope !3, !noalias !4
  %v4225 = load i64, ptr %slot29, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  %ld4227 = load i64, ptr %p4226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4227, ptr %slot642, align 8
  %v4228 = load i64, ptr %slot642, align 8
  %v4229 = load i64, ptr %slot42, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  store i64 %v4228, ptr %p4230, align 8, !alias.scope !3, !noalias !4
  %v4231 = load i64, ptr %slot33, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i64, ptr %p4232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4233, ptr %slot643, align 8
  %v4234 = load i64, ptr %slot643, align 8
  %v4235 = load i64, ptr %slot43, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  store i64 %v4234, ptr %p4236, align 8, !alias.scope !3, !noalias !4
  %v4237 = load i64, ptr %slot29, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  %ld4239 = load i64, ptr %p4238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4239, ptr %slot644, align 8
  %v4240 = load i64, ptr %slot644, align 8
  %v4241 = load i64, ptr %slot42, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  store i64 %v4240, ptr %p4242, align 8, !alias.scope !3, !noalias !4
  %v4243 = load i64, ptr %slot33, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  %ld4245 = load i64, ptr %p4244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4245, ptr %slot645, align 8
  %v4246 = load i64, ptr %slot29, align 8
  %p4247 = inttoptr i64 %v4246 to ptr
  %ld4248 = load i64, ptr %p4247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4248, ptr %slot646, align 8
  %v4249 = load i64, ptr %slot646, align 8
  %op4250 = add i64 %v4249, 16
  store i64 %op4250, ptr %slot647, align 8
  %v4251 = load i64, ptr %slot645, align 8
  %v4252 = load i64, ptr %slot647, align 8
  %p4253 = inttoptr i64 %v4252 to ptr
  store i64 %v4251, ptr %p4253, align 8, !alias.scope !4, !noalias !3
  %v4254 = load i64, ptr %slot42, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  store i64 0, ptr %p4255, align 8, !alias.scope !3, !noalias !4
  br label %bb_i188
bb_i101:
  %v4256 = load i64, ptr %slot30, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  %ld4258 = load i64, ptr %p4257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4258, ptr %slot648, align 8
  %v4259 = load i64, ptr %slot648, align 8
  %v4260 = load i64, ptr %slot42, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  store i64 %v4259, ptr %p4261, align 8, !alias.scope !3, !noalias !4
  %v4262 = load i64, ptr %slot43, align 8
  %p4263 = inttoptr i64 %v4262 to ptr
  store i64 47, ptr %p4263, align 8, !alias.scope !3, !noalias !4
  %v4264 = load i64, ptr %slot43, align 8
  %p4265 = inttoptr i64 %v4264 to ptr
  %ld4266 = load i64, ptr %p4265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4266, ptr %slot649, align 8
  %v4267 = load i64, ptr %slot42, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  %ld4269 = load i64, ptr %p4268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4269, ptr %slot650, align 8
  %v4270 = load i64, ptr %slot650, align 8
  %v4271 = load i64, ptr %slot649, align 8
  %cmp4272 = icmp eq i64 %v4270, %v4271
  %cv4273 = zext i1 %cmp4272 to i64
  store i64 %cv4273, ptr %slot651, align 8
  %v4274 = load i64, ptr %slot651, align 8
  %v4275 = load i64, ptr %slot42, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  store i64 %v4274, ptr %p4276, align 8, !alias.scope !3, !noalias !4
  %v4277 = load i64, ptr %slot42, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %ld4279 = load i64, ptr %p4278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4279, ptr %slot652, align 8
  %v4280 = load i64, ptr %slot652, align 8
  %cond4281 = icmp ne i64 %v4280, 0
  br i1 %cond4281, label %bb_next833, label %bb_i130
bb_next833:
  %v4282 = load i64, ptr %slot29, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %ld4284 = load i64, ptr %p4283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4284, ptr %slot653, align 8
  %v4285 = load i64, ptr %slot653, align 8
  %v4286 = load i64, ptr %slot42, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i64 %v4285, ptr %p4287, align 8, !alias.scope !3, !noalias !4
  %v4288 = load i64, ptr %slot42, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  %ld4290 = load i64, ptr %p4289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4290, ptr %slot654, align 8
  %v4291 = load i64, ptr %slot18, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  %ld4293 = load i32, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4293, ptr %slot655, align 8
  %v4294 = load i64, ptr %slot19, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  %ld4296 = load i32, ptr %p4295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4296, ptr %slot656, align 8
  %v4297 = load i32, ptr %slot656, align 8
  %op4298 = and i32 %v4297, 24
  store i32 %op4298, ptr %slot656, align 8
  %v4299 = load i32, ptr %slot656, align 8
  %cmp4300 = icmp eq i32 %v4299, 0
  %cv4301 = zext i1 %cmp4300 to i32
  store i32 %cv4301, ptr %slot657, align 8
  %v4302 = load i32, ptr %slot655, align 8
  %v4303 = load i32, ptr %slot657, align 8
  %op4304 = and i32 %v4302, %v4303
  store i32 %op4304, ptr %slot658, align 8
  %v4305 = load i32, ptr %slot658, align 8
  %cv4306 = zext i32 %v4305 to i64
  %cond4307 = icmp ne i64 %cv4306, 0
  br i1 %cond4307, label %bb_rctake835, label %bb_rccopy835
bb_rctake835:
  %v4308 = load i64, ptr %slot28, align 8
  store i64 %v4308, ptr %slot659, align 8
  %v4309 = load i64, ptr %slot46, align 8
  store i64 %v4309, ptr %slot660, align 8
  %v4310 = load i64, ptr %slot654, align 8
  %v4311 = load i64, ptr %slot659, align 8
  %op4312 = sub i64 %v4310, %v4311
  store i64 %op4312, ptr %slot661, align 8
  %v4313 = load i64, ptr %slot659, align 8
  %v4314 = load i64, ptr %slot654, align 8
  %op4315 = sub i64 %v4313, %v4314
  store i64 %op4315, ptr %slot662, align 8
  %v4316 = load i64, ptr %slot661, align 8
  %cmp4317 = icmp ult i64 %v4316, 32
  %cv4318 = zext i1 %cmp4317 to i32
  store i32 %cv4318, ptr %slot663, align 8
  %v4319 = load i64, ptr %slot662, align 8
  %cmp4320 = icmp ult i64 %v4319, 32
  %cv4321 = zext i1 %cmp4320 to i32
  store i32 %cv4321, ptr %slot664, align 8
  %v4322 = load i32, ptr %slot663, align 8
  %v4323 = load i32, ptr %slot664, align 8
  %op4324 = or i32 %v4322, %v4323
  store i32 %op4324, ptr %slot665, align 8
  %v4325 = load i32, ptr %slot665, align 8
  %cv4326 = zext i32 %v4325 to i64
  %cond4327 = icmp ne i64 %cv4326, 0
  br i1 %cond4327, label %bb_rcmoveslow844, label %bb_rcmovecheck844
bb_rcmovecheck844:
  %v4328 = load i64, ptr %slot654, align 8
  %op4329 = add i64 %v4328, 0
  store i64 %op4329, ptr %slot666, align 8
  %v4330 = load i64, ptr %slot666, align 8
  %p4331 = inttoptr i64 %v4330 to ptr
  %ld4332 = load i64, ptr %p4331, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4332, ptr %slot667, align 8
  %v4333 = load i64, ptr %slot667, align 8
  %cmp4334 = icmp ne i64 %v4333, 0
  %cv4335 = zext i1 %cmp4334 to i32
  store i32 %cv4335, ptr %slot668, align 8
  %v4336 = load i32, ptr %slot668, align 8
  %cv4337 = zext i32 %v4336 to i64
  %cond4338 = icmp ne i64 %cv4337, 0
  br i1 %cond4338, label %bb_rcmoveheader852, label %bb_rcmovenext852
bb_rcmoveheader852:
  %v4339 = load i64, ptr %slot667, align 8
  %op4340 = sub i64 %v4339, 16
  store i64 %op4340, ptr %slot669, align 8
  %v4341 = load i64, ptr %slot667, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  %rgep4343 = getelementptr i8, ptr %p4342, i64 -16
  %ld4344 = load i64, ptr %rgep4343, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4344, ptr %slot670, align 8
  %v4345 = load i64, ptr %slot670, align 8
  %op4346 = and i64 %v4345, 5764607523034234881
  store i64 %op4346, ptr %slot671, align 8
  %v4347 = load i64, ptr %slot671, align 8
  %cmp4348 = icmp ne i64 %v4347, 0
  %cv4349 = zext i1 %cmp4348 to i32
  store i32 %cv4349, ptr %slot672, align 8
  %v4350 = load i32, ptr %slot672, align 8
  %cv4351 = zext i32 %v4350 to i64
  %cond4352 = icmp ne i64 %cv4351, 0
  br i1 %cond4352, label %bb_rcmoveslow844, label %bb_rcmovenext852
bb_rcmovenext852:
  %v4353 = load i64, ptr %slot654, align 8
  %v4354 = load i64, ptr %slot659, align 8
  %p4355 = inttoptr i64 %v4353 to ptr
  %p4356 = inttoptr i64 %v4354 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4356, ptr %p4355, i64 32, i1 false), !alias.scope !10000000
  %v4357 = load i64, ptr %slot654, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  store i64 0, ptr %p4358, align 8, !alias.scope !4, !noalias !3
  %v4359 = load i64, ptr %slot654, align 8
  %op4360 = add i64 %v4359, 8
  store i64 %op4360, ptr %slot673, align 8
  %v4361 = load i64, ptr %slot673, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  store i64 0, ptr %p4362, align 8, !alias.scope !4, !noalias !3
  %v4363 = load i64, ptr %slot654, align 8
  %op4364 = add i64 %v4363, 16
  store i64 %op4364, ptr %slot674, align 8
  %v4365 = load i64, ptr %slot674, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i64 0, ptr %p4366, align 8, !alias.scope !4, !noalias !3
  %v4367 = load i64, ptr %slot654, align 8
  %op4368 = add i64 %v4367, 24
  store i64 %op4368, ptr %slot675, align 8
  %v4369 = load i64, ptr %slot675, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  store i64 0, ptr %p4370, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved844
bb_rcmoveslow844:
  %v4371 = load i64, ptr %slot45, align 8
  %v4372 = load i64, ptr %slot659, align 8
  %v4373 = load i64, ptr %slot654, align 8
  %v4374 = load i64, ptr %slot660, align 8
  %cv4375 = trunc i64 %v4374 to i32
  %call4376 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v4371, i64 %v4372, i64 %v4373, i32 %cv4375) nomerge, !dbg !150
  store i32 %call4376, ptr %slot676, align 8
  %v4377 = load i32, ptr %slot676, align 8
  %cv4378 = zext i32 %v4377 to i64
  %cond4379 = icmp ne i64 %cv4378, 0
  br i1 %cond4379, label %bb_rcsuccess862, label %bb_rcfailure862
bb_rcfailure862:
  %v4380 = load i64, ptr %slot45, align 8
  %p4381 = inttoptr i64 %v4380 to ptr
  %call4382 = call i32 @myl_rc_take_failure(ptr %p4381) nomerge, !dbg !150
  store i32 %call4382, ptr %slot677, align 8
  %v4383 = load i64, ptr %slot1, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  %v4385 = load i32, ptr %slot677, align 8
  %call4386 = call i32 @myl_qbe_rc_status(ptr %p4384, i32 %v4385) nomerge, !dbg !150
  store i32 %call4386, ptr %slot678, align 8
  br label %bb_failure
bb_rcsuccess862:
  br label %bb_rcmoved844
bb_rcmoved844:
  %v4387 = load i64, ptr %slot18, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  store i32 0, ptr %p4388, align 4, !alias.scope !3, !noalias !4
  %v4389 = load i64, ptr %slot23, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  store i32 2, ptr %p4390, align 4, !alias.scope !3, !noalias !4
  %v4391 = load i64, ptr %slot22, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  store i32 1, ptr %p4392, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared835
bb_rccopy835:
  %v4393 = load i64, ptr %slot28, align 8
  store i64 %v4393, ptr %slot679, align 8
  %v4394 = load i64, ptr %slot46, align 8
  store i64 %v4394, ptr %slot680, align 8
  %v4395 = load i64, ptr %slot45, align 8
  %v4396 = load i64, ptr %slot679, align 8
  %v4397 = load i64, ptr %slot654, align 8
  %v4398 = load i64, ptr %slot680, align 8
  %cv4399 = trunc i64 %v4398 to i32
  %call4400 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v4395, i64 %v4396, i64 %v4397, i32 %cv4399) nomerge, !dbg !150
  store i32 %call4400, ptr %slot681, align 8
  %v4401 = load i32, ptr %slot681, align 8
  %cv4402 = zext i32 %v4401 to i64
  %cond4403 = icmp ne i64 %cv4402, 0
  br i1 %cond4403, label %bb_rcsuccess871, label %bb_rcfailure871
bb_rcfailure871:
  %v4404 = load i64, ptr %slot45, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  %call4406 = call i32 @myl_rc_take_failure(ptr %p4405) nomerge, !dbg !150
  store i32 %call4406, ptr %slot682, align 8
  %v4407 = load i64, ptr %slot1, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  %v4409 = load i32, ptr %slot682, align 8
  %call4410 = call i32 @myl_qbe_rc_status(ptr %p4408, i32 %v4409) nomerge, !dbg !150
  store i32 %call4410, ptr %slot683, align 8
  br label %bb_failure
bb_rcsuccess871:
  %v4411 = load i64, ptr %slot23, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  store i32 2, ptr %p4412, align 4, !alias.scope !3, !noalias !4
  %v4413 = load i64, ptr %slot22, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  store i32 1, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  %v4415 = load i64, ptr %slot18, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %ld4417 = load i32, ptr %p4416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4417, ptr %slot684, align 8
  %v4418 = load i32, ptr %slot684, align 8
  %cv4419 = zext i32 %v4418 to i64
  %cond4420 = icmp ne i64 %cv4419, 0
  br i1 %cond4420, label %bb_rcslotdrop878, label %bb_rcslotdone878
bb_rcslotdrop878:
  %v4421 = load i64, ptr %slot18, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  store i32 0, ptr %p4422, align 4, !alias.scope !3, !noalias !4
  %v4423 = load i64, ptr %slot24, align 8
  store i64 %v4423, ptr %slot685, align 8
  %v4424 = load i64, ptr %slot19, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %ld4426 = load i32, ptr %p4425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4426, ptr %slot686, align 8
  %v4427 = load i32, ptr %slot686, align 8
  %op4428 = and i32 %v4427, 28
  store i32 %op4428, ptr %slot687, align 8
  %v4429 = load i32, ptr %slot687, align 8
  %cv4430 = zext i32 %v4429 to i64
  %cond4431 = icmp ne i64 %cv4430, 0
  br i1 %cond4431, label %bb_rcslotrole878, label %bb_rcslotowner878
bb_rcslotrole878:
  %v4432 = load i64, ptr %slot45, align 8
  store i64 %v4432, ptr %slot688, align 8
  %v4433 = load i64, ptr %slot688, align 8
  %v4434 = load i64, ptr %slot685, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4433, i64 %v4434) nomerge, !dbg !150
  br label %bb_rcslotdone878
bb_rcslotowner878:
  %v4435 = load i64, ptr %slot685, align 8
  %p4437 = inttoptr i64 %v4435 to ptr
  %gep4438 = getelementptr i8, ptr %p4437, i64 0
  %op4436 = ptrtoint ptr %gep4438 to i64
  store i64 %op4436, ptr %slot689, align 8
  %v4439 = load i64, ptr %slot45, align 8
  store i64 %v4439, ptr %slot690, align 8
  %v4440 = load i64, ptr %slot689, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  %ld4442 = load i64, ptr %p4441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4442, ptr %slot691, align 8
  %v4443 = load i64, ptr %slot691, align 8
  %cmp4444 = icmp ne i64 %v4443, 0
  %cv4445 = zext i1 %cmp4444 to i32
  store i32 %cv4445, ptr %slot692, align 8
  %v4446 = load i32, ptr %slot692, align 8
  %cv4447 = zext i32 %v4446 to i64
  %cond4448 = icmp ne i64 %cv4447, 0
  br i1 %cond4448, label %bb_rcgnn896, label %bb_rcgdone896
bb_rcgnn896:
  %v4449 = load i64, ptr %slot691, align 8
  %op4450 = sub i64 %v4449, 16
  store i64 %op4450, ptr %slot693, align 8
  %v4451 = load i64, ptr %slot691, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  %rgep4453 = getelementptr i8, ptr %p4452, i64 -16
  %ld4454 = load i64, ptr %rgep4453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4454, ptr %slot694, align 8
  %v4455 = load i64, ptr %slot694, align 8
  %op4456 = and i64 %v4455, 4611686018427387906
  store i64 %op4456, ptr %slot695, align 8
  %v4457 = load i64, ptr %slot695, align 8
  %cmp4458 = icmp ne i64 %v4457, 0
  %cv4459 = zext i1 %cmp4458 to i32
  store i32 %cv4459, ptr %slot696, align 8
  %v4460 = load i32, ptr %slot696, align 8
  %cv4461 = zext i32 %v4460 to i64
  %cond4462 = icmp ne i64 %cv4461, 0
  br i1 %cond4462, label %bb_rcgclear896, label %bb_rcgcounted896
bb_rcgcounted896:
  %v4463 = load i64, ptr %slot691, align 8
  %op4464 = sub i64 %v4463, 32
  store i64 %op4464, ptr %slot697, align 8
  %v4465 = load i64, ptr %slot691, align 8
  %p4466 = inttoptr i64 %v4465 to ptr
  %rgep4467 = getelementptr i8, ptr %p4466, i64 -32
  %ld4468 = load i64, ptr %rgep4467, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4468, ptr %slot698, align 8
  %v4469 = load i64, ptr %slot698, align 8
  %op4470 = sub i64 %v4469, 1
  store i64 %op4470, ptr %slot699, align 8
  %v4471 = load i64, ptr %slot699, align 8
  %cmp4472 = icmp eq i64 %v4471, 0
  %cv4473 = zext i1 %cmp4472 to i32
  store i32 %cv4473, ptr %slot700, align 8
  %v4474 = load i32, ptr %slot700, align 8
  %cv4475 = zext i32 %v4474 to i64
  %cond4476 = icmp ne i64 %cv4475, 0
  br i1 %cond4476, label %bb_rcglast896, label %bb_rcgdec896
bb_rcglast896:
  %v4477 = load i64, ptr %slot691, align 8
  %op4478 = sub i64 %v4477, 24
  store i64 %op4478, ptr %slot701, align 8
  %v4479 = load i64, ptr %slot691, align 8
  %p4480 = inttoptr i64 %v4479 to ptr
  %rgep4481 = getelementptr i8, ptr %p4480, i64 -24
  %ld4482 = load i64, ptr %rgep4481, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4482, ptr %slot702, align 8
  %v4483 = load i64, ptr %slot702, align 8
  %cmp4484 = icmp ne i64 %v4483, 0
  %cv4485 = zext i1 %cmp4484 to i32
  store i32 %cv4485, ptr %slot703, align 8
  %v4486 = load i32, ptr %slot703, align 8
  %cv4487 = zext i32 %v4486 to i64
  %cond4488 = icmp ne i64 %cv4487, 0
  br i1 %cond4488, label %bb_rcgdec896, label %bb_rcgslow896
bb_rcgslow896:
  %v4489 = load i64, ptr %slot690, align 8
  %v4490 = load i64, ptr %slot689, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4489, i64 %v4490) nomerge, !dbg !150
  br label %bb_rcgdone896
bb_rcgdec896:
  %v4491 = load i64, ptr %slot699, align 8
  %v4492 = load i64, ptr %slot691, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  %rgep4494 = getelementptr i8, ptr %p4493, i64 -32
  store i64 %v4491, ptr %rgep4494, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear896
bb_rcgclear896:
  %v4495 = load i64, ptr %slot689, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  store i64 0, ptr %p4496, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone896
bb_rcgdone896:
  %v4497 = load i64, ptr %slot685, align 8
  %p4498 = inttoptr i64 %v4497 to ptr
  store i64 0, ptr %p4498, align 8, !alias.scope !3, !noalias !4
  %v4499 = load i64, ptr %slot685, align 8
  %p4501 = inttoptr i64 %v4499 to ptr
  %gep4502 = getelementptr i8, ptr %p4501, i64 8
  %op4500 = ptrtoint ptr %gep4502 to i64
  store i64 %op4500, ptr %slot704, align 8
  %v4503 = load i64, ptr %slot704, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  store i64 0, ptr %p4504, align 8, !alias.scope !3, !noalias !4
  %v4505 = load i64, ptr %slot685, align 8
  %p4507 = inttoptr i64 %v4505 to ptr
  %gep4508 = getelementptr i8, ptr %p4507, i64 16
  %op4506 = ptrtoint ptr %gep4508 to i64
  store i64 %op4506, ptr %slot705, align 8
  %v4509 = load i64, ptr %slot705, align 8
  %p4510 = inttoptr i64 %v4509 to ptr
  store i64 0, ptr %p4510, align 8, !alias.scope !3, !noalias !4
  %v4511 = load i64, ptr %slot685, align 8
  %p4513 = inttoptr i64 %v4511 to ptr
  %gep4514 = getelementptr i8, ptr %p4513, i64 24
  %op4512 = ptrtoint ptr %gep4514 to i64
  store i64 %op4512, ptr %slot706, align 8
  %v4515 = load i64, ptr %slot706, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  store i64 0, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone878
bb_rcslotdone878:
  br label %bb_rcprepared835
bb_rcprepared835:
  %v4517 = load i64, ptr %slot10, align 8
  %p4518 = inttoptr i64 %v4517 to ptr
  %ld4519 = load i32, ptr %p4518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4519, ptr %slot707, align 8
  %v4520 = load i32, ptr %slot707, align 8
  %cv4521 = zext i32 %v4520 to i64
  %cond4522 = icmp ne i64 %cv4521, 0
  br i1 %cond4522, label %bb_rcslotdrop906, label %bb_rcslotdone906
bb_rcslotdrop906:
  %v4523 = load i64, ptr %slot10, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  store i32 0, ptr %p4524, align 4, !alias.scope !3, !noalias !4
  %v4525 = load i64, ptr %slot38, align 8
  store i64 %v4525, ptr %slot708, align 8
  %v4526 = load i64, ptr %slot11, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %ld4528 = load i32, ptr %p4527, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4528, ptr %slot709, align 8
  %v4529 = load i32, ptr %slot709, align 8
  %op4530 = and i32 %v4529, 28
  store i32 %op4530, ptr %slot710, align 8
  %v4531 = load i32, ptr %slot710, align 8
  %cv4532 = zext i32 %v4531 to i64
  %cond4533 = icmp ne i64 %cv4532, 0
  br i1 %cond4533, label %bb_rcslotrole906, label %bb_rcslotowner906
bb_rcslotrole906:
  %v4534 = load i64, ptr %slot45, align 8
  store i64 %v4534, ptr %slot711, align 8
  %v4535 = load i64, ptr %slot711, align 8
  %v4536 = load i64, ptr %slot708, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4535, i64 %v4536) nomerge, !dbg !150
  br label %bb_rcslotdone906
bb_rcslotowner906:
  %v4537 = load i64, ptr %slot708, align 8
  %p4539 = inttoptr i64 %v4537 to ptr
  %gep4540 = getelementptr i8, ptr %p4539, i64 0
  %op4538 = ptrtoint ptr %gep4540 to i64
  store i64 %op4538, ptr %slot712, align 8
  %v4541 = load i64, ptr %slot45, align 8
  store i64 %v4541, ptr %slot713, align 8
  %v4542 = load i64, ptr %slot712, align 8
  %p4543 = inttoptr i64 %v4542 to ptr
  %ld4544 = load i64, ptr %p4543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4544, ptr %slot714, align 8
  %v4545 = load i64, ptr %slot714, align 8
  %cmp4546 = icmp ne i64 %v4545, 0
  %cv4547 = zext i1 %cmp4546 to i32
  store i32 %cv4547, ptr %slot715, align 8
  %v4548 = load i32, ptr %slot715, align 8
  %cv4549 = zext i32 %v4548 to i64
  %cond4550 = icmp ne i64 %cv4549, 0
  br i1 %cond4550, label %bb_rcgnn924, label %bb_rcgdone924
bb_rcgnn924:
  %v4551 = load i64, ptr %slot714, align 8
  %op4552 = sub i64 %v4551, 16
  store i64 %op4552, ptr %slot716, align 8
  %v4553 = load i64, ptr %slot714, align 8
  %p4554 = inttoptr i64 %v4553 to ptr
  %rgep4555 = getelementptr i8, ptr %p4554, i64 -16
  %ld4556 = load i64, ptr %rgep4555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4556, ptr %slot717, align 8
  %v4557 = load i64, ptr %slot717, align 8
  %op4558 = and i64 %v4557, 4611686018427387906
  store i64 %op4558, ptr %slot718, align 8
  %v4559 = load i64, ptr %slot718, align 8
  %cmp4560 = icmp ne i64 %v4559, 0
  %cv4561 = zext i1 %cmp4560 to i32
  store i32 %cv4561, ptr %slot719, align 8
  %v4562 = load i32, ptr %slot719, align 8
  %cv4563 = zext i32 %v4562 to i64
  %cond4564 = icmp ne i64 %cv4563, 0
  br i1 %cond4564, label %bb_rcgclear924, label %bb_rcgcounted924
bb_rcgcounted924:
  %v4565 = load i64, ptr %slot714, align 8
  %op4566 = sub i64 %v4565, 32
  store i64 %op4566, ptr %slot720, align 8
  %v4567 = load i64, ptr %slot714, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %rgep4569 = getelementptr i8, ptr %p4568, i64 -32
  %ld4570 = load i64, ptr %rgep4569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4570, ptr %slot721, align 8
  %v4571 = load i64, ptr %slot721, align 8
  %op4572 = sub i64 %v4571, 1
  store i64 %op4572, ptr %slot722, align 8
  %v4573 = load i64, ptr %slot722, align 8
  %cmp4574 = icmp eq i64 %v4573, 0
  %cv4575 = zext i1 %cmp4574 to i32
  store i32 %cv4575, ptr %slot723, align 8
  %v4576 = load i32, ptr %slot723, align 8
  %cv4577 = zext i32 %v4576 to i64
  %cond4578 = icmp ne i64 %cv4577, 0
  br i1 %cond4578, label %bb_rcglast924, label %bb_rcgdec924
bb_rcglast924:
  %v4579 = load i64, ptr %slot714, align 8
  %op4580 = sub i64 %v4579, 24
  store i64 %op4580, ptr %slot724, align 8
  %v4581 = load i64, ptr %slot714, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  %rgep4583 = getelementptr i8, ptr %p4582, i64 -24
  %ld4584 = load i64, ptr %rgep4583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4584, ptr %slot725, align 8
  %v4585 = load i64, ptr %slot725, align 8
  %cmp4586 = icmp ne i64 %v4585, 0
  %cv4587 = zext i1 %cmp4586 to i32
  store i32 %cv4587, ptr %slot726, align 8
  %v4588 = load i32, ptr %slot726, align 8
  %cv4589 = zext i32 %v4588 to i64
  %cond4590 = icmp ne i64 %cv4589, 0
  br i1 %cond4590, label %bb_rcgdec924, label %bb_rcgslow924
bb_rcgslow924:
  %v4591 = load i64, ptr %slot713, align 8
  %v4592 = load i64, ptr %slot712, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4591, i64 %v4592) nomerge, !dbg !150
  br label %bb_rcgdone924
bb_rcgdec924:
  %v4593 = load i64, ptr %slot722, align 8
  %v4594 = load i64, ptr %slot714, align 8
  %p4595 = inttoptr i64 %v4594 to ptr
  %rgep4596 = getelementptr i8, ptr %p4595, i64 -32
  store i64 %v4593, ptr %rgep4596, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear924
bb_rcgclear924:
  %v4597 = load i64, ptr %slot712, align 8
  %p4598 = inttoptr i64 %v4597 to ptr
  store i64 0, ptr %p4598, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone924
bb_rcgdone924:
  %v4599 = load i64, ptr %slot708, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  store i64 0, ptr %p4600, align 8, !alias.scope !3, !noalias !4
  %v4601 = load i64, ptr %slot708, align 8
  %p4603 = inttoptr i64 %v4601 to ptr
  %gep4604 = getelementptr i8, ptr %p4603, i64 8
  %op4602 = ptrtoint ptr %gep4604 to i64
  store i64 %op4602, ptr %slot727, align 8
  %v4605 = load i64, ptr %slot727, align 8
  %p4606 = inttoptr i64 %v4605 to ptr
  store i64 0, ptr %p4606, align 8, !alias.scope !3, !noalias !4
  %v4607 = load i64, ptr %slot708, align 8
  %p4609 = inttoptr i64 %v4607 to ptr
  %gep4610 = getelementptr i8, ptr %p4609, i64 16
  %op4608 = ptrtoint ptr %gep4610 to i64
  store i64 %op4608, ptr %slot728, align 8
  %v4611 = load i64, ptr %slot728, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  store i64 0, ptr %p4612, align 8, !alias.scope !3, !noalias !4
  %v4613 = load i64, ptr %slot708, align 8
  %p4615 = inttoptr i64 %v4613 to ptr
  %gep4616 = getelementptr i8, ptr %p4615, i64 24
  %op4614 = ptrtoint ptr %gep4616 to i64
  store i64 %op4614, ptr %slot729, align 8
  %v4617 = load i64, ptr %slot729, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  store i64 0, ptr %p4618, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone906
bb_rcslotdone906:
  %v4619 = load i64, ptr %slot38, align 8
  store i64 %v4619, ptr %slot730, align 8
  %v4620 = load i64, ptr %slot28, align 8
  store i64 %v4620, ptr %slot731, align 8
  %v4621 = load i64, ptr %slot731, align 8
  %v4622 = load i64, ptr %slot730, align 8
  %p4623 = inttoptr i64 %v4621 to ptr
  %p4624 = inttoptr i64 %v4622 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4624, ptr %p4623, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4625 = load i64, ptr %slot22, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  store i32 0, ptr %p4626, align 4, !alias.scope !3, !noalias !4
  %v4627 = load i64, ptr %slot11, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  store i32 2, ptr %p4628, align 4, !alias.scope !3, !noalias !4
  %v4629 = load i64, ptr %slot23, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  %ld4631 = load i32, ptr %p4630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4631, ptr %slot732, align 8
  %v4632 = load i32, ptr %slot732, align 8
  %v4633 = load i64, ptr %slot11, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  store i32 %v4632, ptr %p4634, align 4, !alias.scope !3, !noalias !4
  %v4635 = load i64, ptr %slot10, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i32 1, ptr %p4636, align 4, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot38, align 8
  %v4638 = load i64, ptr %slot42, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  store i64 %v4637, ptr %p4639, align 8, !alias.scope !3, !noalias !4
  %v4640 = load i64, ptr %slot42, align 8
  %p4641 = inttoptr i64 %v4640 to ptr
  %ld4642 = load i64, ptr %p4641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4642, ptr %slot733, align 8
  %v4643 = load i64, ptr %slot733, align 8
  %op4644 = add i64 %v4643, 16
  store i64 %op4644, ptr %slot734, align 8
  %v4645 = load i64, ptr %slot734, align 8
  %p4646 = inttoptr i64 %v4645 to ptr
  %ld4647 = load i64, ptr %p4646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4647, ptr %slot735, align 8
  %v4648 = load i64, ptr %slot735, align 8
  %v4649 = load i64, ptr %slot42, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  store i64 %v4648, ptr %p4650, align 8, !alias.scope !3, !noalias !4
  %v4651 = load i64, ptr %slot18, align 8
  %p4652 = inttoptr i64 %v4651 to ptr
  %ld4653 = load i32, ptr %p4652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4653, ptr %slot736, align 8
  %v4654 = load i32, ptr %slot736, align 8
  %cv4655 = zext i32 %v4654 to i64
  %cond4656 = icmp ne i64 %cv4655, 0
  br i1 %cond4656, label %bb_rcslotdrop943, label %bb_rcslotdone943
bb_rcslotdrop943:
  %v4657 = load i64, ptr %slot18, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  store i32 0, ptr %p4658, align 4, !alias.scope !3, !noalias !4
  %v4659 = load i64, ptr %slot24, align 8
  store i64 %v4659, ptr %slot737, align 8
  %v4660 = load i64, ptr %slot19, align 8
  %p4661 = inttoptr i64 %v4660 to ptr
  %ld4662 = load i32, ptr %p4661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4662, ptr %slot738, align 8
  %v4663 = load i32, ptr %slot738, align 8
  %op4664 = and i32 %v4663, 28
  store i32 %op4664, ptr %slot739, align 8
  %v4665 = load i32, ptr %slot739, align 8
  %cv4666 = zext i32 %v4665 to i64
  %cond4667 = icmp ne i64 %cv4666, 0
  br i1 %cond4667, label %bb_rcslotrole943, label %bb_rcslotowner943
bb_rcslotrole943:
  %v4668 = load i64, ptr %slot45, align 8
  store i64 %v4668, ptr %slot740, align 8
  %v4669 = load i64, ptr %slot740, align 8
  %v4670 = load i64, ptr %slot737, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4669, i64 %v4670) nomerge, !dbg !152
  br label %bb_rcslotdone943
bb_rcslotowner943:
  %v4671 = load i64, ptr %slot45, align 8
  store i64 %v4671, ptr %slot741, align 8
  %v4672 = load i64, ptr %slot741, align 8
  %v4673 = load i64, ptr %slot737, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4672, i64 %v4673) nomerge, !dbg !152
  br label %bb_rcslotdone943
bb_rcslotdone943:
  %v4674 = load i64, ptr %slot43, align 8
  %p4675 = inttoptr i64 %v4674 to ptr
  store i64 1, ptr %p4675, align 8, !alias.scope !3, !noalias !4
  %v4676 = load i64, ptr %slot43, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  %ld4678 = load i64, ptr %p4677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4678, ptr %slot742, align 8
  %v4679 = load i64, ptr %slot42, align 8
  %p4680 = inttoptr i64 %v4679 to ptr
  %ld4681 = load i64, ptr %p4680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4681, ptr %slot743, align 8
  %v4682 = load i64, ptr %slot743, align 8
  %v4683 = load i64, ptr %slot742, align 8
  %ovpair4685 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4682, i64 %v4683)
  %op4684 = extractvalue { i64, i1 } %ovpair4685, 0
  %ov4686 = extractvalue { i64, i1 } %ovpair4685, 1
  store i64 %op4684, ptr %slot744, align 8
  %cv4687 = zext i1 %ov4686 to i64
  store i64 %cv4687, ptr %slot745, align 8
  %v4688 = load i64, ptr %slot745, align 8
  %cond4689 = icmp ne i64 %v4688, 0
  br i1 %cond4689, label %bb_overflow952, label %bb_checked952
bb_overflow952:
  %v4690 = load i64, ptr %slot1, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  %v4692 = load i64, ptr %slot743, align 8
  %v4693 = load i64, ptr %slot742, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4691, i64 0, i64 %v4692, i64 %v4693, i64 64) nomerge, !dbg !154
  unreachable
bb_checked952:
  %v4694 = load i64, ptr %slot744, align 8
  %v4695 = load i64, ptr %slot42, align 8
  %p4696 = inttoptr i64 %v4695 to ptr
  store i64 %v4694, ptr %p4696, align 8, !alias.scope !3, !noalias !4
  %v4697 = load i64, ptr %slot38, align 8
  %v4698 = load i64, ptr %slot43, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  store i64 %v4697, ptr %p4699, align 8, !alias.scope !3, !noalias !4
  %v4700 = load i64, ptr %slot43, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  %ld4702 = load i64, ptr %p4701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4702, ptr %slot746, align 8
  %v4703 = load i64, ptr %slot746, align 8
  %op4704 = add i64 %v4703, 0
  store i64 %op4704, ptr %slot747, align 8
  %v4705 = load i64, ptr %slot747, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  %ld4707 = load i64, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4707, ptr %slot748, align 8
  %v4708 = load i64, ptr %slot748, align 8
  %v4709 = load i64, ptr %slot43, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  store i64 %v4708, ptr %p4710, align 8, !alias.scope !3, !noalias !4
  %v4711 = load i64, ptr %slot43, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %ld4713 = load i64, ptr %p4712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4713, ptr %slot749, align 8
  %v4714 = load i64, ptr %slot749, align 8
  %v4715 = load i64, ptr %slot27, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i64 %v4714, ptr %p4716, align 8, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot27, align 8
  store i64 %v4717, ptr %slot750, align 8
  %v4718 = load i64, ptr %slot28, align 8
  store i64 %v4718, ptr %slot751, align 8
  %v4719 = load i64, ptr %slot750, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i64, ptr %p4720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4721, ptr %slot752, align 8
  %v4722 = load i64, ptr %slot752, align 8
  %cmp4723 = icmp ne i64 %v4722, 0
  %cv4724 = zext i1 %cmp4723 to i32
  store i32 %cv4724, ptr %slot753, align 8
  %v4725 = load i32, ptr %slot753, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcgnn961, label %bb_rcgstore961
bb_rcgnn961:
  %v4728 = load i64, ptr %slot752, align 8
  %op4729 = sub i64 %v4728, 16
  store i64 %op4729, ptr %slot754, align 8
  %v4730 = load i64, ptr %slot752, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  %rgep4732 = getelementptr i8, ptr %p4731, i64 -16
  %ld4733 = load i64, ptr %rgep4732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4733, ptr %slot755, align 8
  %v4734 = load i64, ptr %slot755, align 8
  %op4735 = and i64 %v4734, 4611686018427387906
  store i64 %op4735, ptr %slot756, align 8
  %v4736 = load i64, ptr %slot756, align 8
  %cmp4737 = icmp ne i64 %v4736, 0
  %cv4738 = zext i1 %cmp4737 to i32
  store i32 %cv4738, ptr %slot757, align 8
  %v4739 = load i32, ptr %slot757, align 8
  %cv4740 = zext i32 %v4739 to i64
  %cond4741 = icmp ne i64 %cv4740, 0
  br i1 %cond4741, label %bb_rcgstore961, label %bb_rcginc961
bb_rcginc961:
  %v4742 = load i64, ptr %slot752, align 8
  %op4743 = sub i64 %v4742, 24
  store i64 %op4743, ptr %slot758, align 8
  %v4744 = load i64, ptr %slot752, align 8
  %p4745 = inttoptr i64 %v4744 to ptr
  %rgep4746 = getelementptr i8, ptr %p4745, i64 -24
  %ld4747 = load i64, ptr %rgep4746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4747, ptr %slot759, align 8
  %v4748 = load i64, ptr %slot759, align 8
  %op4749 = add i64 %v4748, 1
  store i64 %op4749, ptr %slot760, align 8
  %v4750 = load i64, ptr %slot760, align 8
  %cmp4751 = icmp eq i64 %v4750, 0
  %cv4752 = zext i1 %cmp4751 to i32
  store i32 %cv4752, ptr %slot761, align 8
  %v4753 = load i32, ptr %slot761, align 8
  %cv4754 = zext i32 %v4753 to i64
  %cond4755 = icmp ne i64 %cv4754, 0
  br i1 %cond4755, label %bb_rcglimit961, label %bb_rcgcapacity961
bb_rcglimit961:
  %v4756 = load i64, ptr %slot1, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  %call4758 = call i32 @myl_qbe_rc_status(ptr %p4757, i32 2) nomerge, !dbg !156
  store i32 %call4758, ptr %slot762, align 8
  br label %bb_failure
bb_rcgcapacity961:
  %v4759 = load i64, ptr %slot760, align 8
  %v4760 = load i64, ptr %slot752, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %rgep4762 = getelementptr i8, ptr %p4761, i64 -24
  store i64 %v4759, ptr %rgep4762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore961
bb_rcgstore961:
  %v4763 = load i64, ptr %slot752, align 8
  %v4764 = load i64, ptr %slot751, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  store i64 %v4763, ptr %p4765, align 8, !alias.scope !3, !noalias !4
  %v4766 = load i64, ptr %slot23, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  store i32 2, ptr %p4767, align 4, !alias.scope !3, !noalias !4
  %v4768 = load i64, ptr %slot23, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  store i32 16, ptr %p4769, align 4, !alias.scope !3, !noalias !4
  %v4770 = load i64, ptr %slot22, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  store i32 1, ptr %p4771, align 4, !alias.scope !3, !noalias !4
  %v4772 = load i64, ptr %slot20, align 8
  %p4773 = inttoptr i64 %v4772 to ptr
  %ld4774 = load i32, ptr %p4773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4774, ptr %slot763, align 8
  %v4775 = load i32, ptr %slot763, align 8
  %cv4776 = zext i32 %v4775 to i64
  %cond4777 = icmp ne i64 %cv4776, 0
  br i1 %cond4777, label %bb_rcslotdrop977, label %bb_rcslotdone977
bb_rcslotdrop977:
  %v4778 = load i64, ptr %slot20, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  store i32 0, ptr %p4779, align 4, !alias.scope !3, !noalias !4
  %v4780 = load i64, ptr %slot25, align 8
  store i64 %v4780, ptr %slot764, align 8
  %v4781 = load i64, ptr %slot21, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  %ld4783 = load i32, ptr %p4782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4783, ptr %slot765, align 8
  %v4784 = load i32, ptr %slot765, align 8
  %op4785 = and i32 %v4784, 28
  store i32 %op4785, ptr %slot766, align 8
  %v4786 = load i32, ptr %slot766, align 8
  %cv4787 = zext i32 %v4786 to i64
  %cond4788 = icmp ne i64 %cv4787, 0
  br i1 %cond4788, label %bb_rcslotrole977, label %bb_rcslotowner977
bb_rcslotrole977:
  %v4789 = load i64, ptr %slot45, align 8
  store i64 %v4789, ptr %slot767, align 8
  %v4790 = load i64, ptr %slot767, align 8
  %v4791 = load i64, ptr %slot764, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4790, i64 %v4791) nomerge, !dbg !156
  br label %bb_rcslotdone977
bb_rcslotowner977:
  %v4792 = load i64, ptr %slot45, align 8
  store i64 %v4792, ptr %slot768, align 8
  %v4793 = load i64, ptr %slot768, align 8
  %v4794 = load i64, ptr %slot764, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4793, i64 %v4794) nomerge, !dbg !156
  br label %bb_rcslotdone977
bb_rcslotdone977:
  %v4795 = load i64, ptr %slot25, align 8
  store i64 %v4795, ptr %slot769, align 8
  %v4796 = load i64, ptr %slot28, align 8
  store i64 %v4796, ptr %slot770, align 8
  %v4797 = load i64, ptr %slot770, align 8
  %v4798 = load i64, ptr %slot769, align 8
  %p4799 = inttoptr i64 %v4797 to ptr
  %p4800 = inttoptr i64 %v4798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4800, ptr %p4799, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4801 = load i64, ptr %slot21, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  store i32 2, ptr %p4802, align 4, !alias.scope !3, !noalias !4
  %v4803 = load i64, ptr %slot23, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %ld4805 = load i32, ptr %p4804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4805, ptr %slot771, align 8
  %v4806 = load i32, ptr %slot771, align 8
  %v4807 = load i64, ptr %slot21, align 8
  %p4808 = inttoptr i64 %v4807 to ptr
  store i32 %v4806, ptr %p4808, align 4, !alias.scope !3, !noalias !4
  %v4809 = load i64, ptr %slot22, align 8
  %p4810 = inttoptr i64 %v4809 to ptr
  store i32 0, ptr %p4810, align 4, !alias.scope !3, !noalias !4
  %v4811 = load i64, ptr %slot20, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  store i32 1, ptr %p4812, align 4, !alias.scope !3, !noalias !4
  %v4813 = load i64, ptr %slot769, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  %ld4815 = load i64, ptr %p4814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4815, ptr %slot772, align 8
  %v4816 = load i64, ptr %slot772, align 8
  %v4817 = load i64, ptr %slot43, align 8
  %p4818 = inttoptr i64 %v4817 to ptr
  store i64 %v4816, ptr %p4818, align 8, !alias.scope !3, !noalias !4
  %v4819 = load i64, ptr %slot43, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  %ld4821 = load i64, ptr %p4820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4821, ptr %slot773, align 8
  %v4822 = load i64, ptr %slot773, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  %ld4824 = load i64, ptr %p4823, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4824, ptr %slot774, align 8
  %v4825 = load i64, ptr %slot774, align 8
  %v4826 = load i64, ptr %slot43, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  store i64 %v4825, ptr %p4827, align 8, !alias.scope !3, !noalias !4
  %v4828 = load i64, ptr %slot20, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  %ld4830 = load i32, ptr %p4829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4830, ptr %slot775, align 8
  %v4831 = load i32, ptr %slot775, align 8
  %cv4832 = zext i32 %v4831 to i64
  %cond4833 = icmp ne i64 %cv4832, 0
  br i1 %cond4833, label %bb_rcslotdrop997, label %bb_rcslotdone997
bb_rcslotdrop997:
  %v4834 = load i64, ptr %slot20, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  store i32 0, ptr %p4835, align 4, !alias.scope !3, !noalias !4
  %v4836 = load i64, ptr %slot25, align 8
  store i64 %v4836, ptr %slot776, align 8
  %v4837 = load i64, ptr %slot21, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %ld4839 = load i32, ptr %p4838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4839, ptr %slot777, align 8
  %v4840 = load i32, ptr %slot777, align 8
  %op4841 = and i32 %v4840, 28
  store i32 %op4841, ptr %slot778, align 8
  %v4842 = load i32, ptr %slot778, align 8
  %cv4843 = zext i32 %v4842 to i64
  %cond4844 = icmp ne i64 %cv4843, 0
  br i1 %cond4844, label %bb_rcslotrole997, label %bb_rcslotowner997
bb_rcslotrole997:
  %v4845 = load i64, ptr %slot45, align 8
  store i64 %v4845, ptr %slot779, align 8
  %v4846 = load i64, ptr %slot776, align 8
  %p4847 = inttoptr i64 %v4846 to ptr
  %ld4848 = load i64, ptr %p4847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4848, ptr %slot780, align 8
  %v4849 = load i64, ptr %slot780, align 8
  %cmp4850 = icmp ne i64 %v4849, 0
  %cv4851 = zext i1 %cmp4850 to i32
  store i32 %cv4851, ptr %slot781, align 8
  %v4852 = load i32, ptr %slot781, align 8
  %cv4853 = zext i32 %v4852 to i64
  %cond4854 = icmp ne i64 %cv4853, 0
  br i1 %cond4854, label %bb_rcgnn1013, label %bb_rcgdone1013
bb_rcgnn1013:
  %v4855 = load i64, ptr %slot780, align 8
  %op4856 = sub i64 %v4855, 16
  store i64 %op4856, ptr %slot782, align 8
  %v4857 = load i64, ptr %slot780, align 8
  %p4858 = inttoptr i64 %v4857 to ptr
  %rgep4859 = getelementptr i8, ptr %p4858, i64 -16
  %ld4860 = load i64, ptr %rgep4859, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4860, ptr %slot783, align 8
  %v4861 = load i64, ptr %slot783, align 8
  %op4862 = and i64 %v4861, 4611686018427387906
  store i64 %op4862, ptr %slot784, align 8
  %v4863 = load i64, ptr %slot784, align 8
  %cmp4864 = icmp ne i64 %v4863, 0
  %cv4865 = zext i1 %cmp4864 to i32
  store i32 %cv4865, ptr %slot785, align 8
  %v4866 = load i32, ptr %slot785, align 8
  %cv4867 = zext i32 %v4866 to i64
  %cond4868 = icmp ne i64 %cv4867, 0
  br i1 %cond4868, label %bb_rcgclear1013, label %bb_rcgcounted1013
bb_rcgcounted1013:
  %v4869 = load i64, ptr %slot780, align 8
  %op4870 = sub i64 %v4869, 24
  store i64 %op4870, ptr %slot786, align 8
  %v4871 = load i64, ptr %slot780, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  %rgep4873 = getelementptr i8, ptr %p4872, i64 -24
  %ld4874 = load i64, ptr %rgep4873, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4874, ptr %slot787, align 8
  %v4875 = load i64, ptr %slot787, align 8
  %op4876 = sub i64 %v4875, 1
  store i64 %op4876, ptr %slot788, align 8
  %v4877 = load i64, ptr %slot788, align 8
  %cmp4878 = icmp eq i64 %v4877, 0
  %cv4879 = zext i1 %cmp4878 to i32
  store i32 %cv4879, ptr %slot789, align 8
  %v4880 = load i32, ptr %slot789, align 8
  %cv4881 = zext i32 %v4880 to i64
  %cond4882 = icmp ne i64 %cv4881, 0
  br i1 %cond4882, label %bb_rcglast1013, label %bb_rcgdec1013
bb_rcglast1013:
  %v4883 = load i64, ptr %slot780, align 8
  %op4884 = sub i64 %v4883, 32
  store i64 %op4884, ptr %slot790, align 8
  %v4885 = load i64, ptr %slot780, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  %rgep4887 = getelementptr i8, ptr %p4886, i64 -32
  %ld4888 = load i64, ptr %rgep4887, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4888, ptr %slot791, align 8
  %v4889 = load i64, ptr %slot791, align 8
  %cmp4890 = icmp ne i64 %v4889, 0
  %cv4891 = zext i1 %cmp4890 to i32
  store i32 %cv4891, ptr %slot792, align 8
  %v4892 = load i32, ptr %slot792, align 8
  %cv4893 = zext i32 %v4892 to i64
  %cond4894 = icmp ne i64 %cv4893, 0
  br i1 %cond4894, label %bb_rcgdec1013, label %bb_rcgslow1013
bb_rcgslow1013:
  %v4895 = load i64, ptr %slot779, align 8
  %v4896 = load i64, ptr %slot776, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4895, i64 %v4896) nomerge, !dbg !158
  br label %bb_rcgdone1013
bb_rcgdec1013:
  %v4897 = load i64, ptr %slot788, align 8
  %v4898 = load i64, ptr %slot780, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %rgep4900 = getelementptr i8, ptr %p4899, i64 -24
  store i64 %v4897, ptr %rgep4900, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1013
bb_rcgclear1013:
  %v4901 = load i64, ptr %slot776, align 8
  %p4902 = inttoptr i64 %v4901 to ptr
  store i64 0, ptr %p4902, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1013
bb_rcgdone1013:
  br label %bb_rcslotdone997
bb_rcslotowner997:
  %v4903 = load i64, ptr %slot45, align 8
  store i64 %v4903, ptr %slot793, align 8
  %v4904 = load i64, ptr %slot776, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  %ld4906 = load i64, ptr %p4905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4906, ptr %slot794, align 8
  %v4907 = load i64, ptr %slot794, align 8
  %cmp4908 = icmp ne i64 %v4907, 0
  %cv4909 = zext i1 %cmp4908 to i32
  store i32 %cv4909, ptr %slot795, align 8
  %v4910 = load i32, ptr %slot795, align 8
  %cv4911 = zext i32 %v4910 to i64
  %cond4912 = icmp ne i64 %cv4911, 0
  br i1 %cond4912, label %bb_rcgnn1028, label %bb_rcgdone1028
bb_rcgnn1028:
  %v4913 = load i64, ptr %slot794, align 8
  %op4914 = sub i64 %v4913, 16
  store i64 %op4914, ptr %slot796, align 8
  %v4915 = load i64, ptr %slot794, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  %rgep4917 = getelementptr i8, ptr %p4916, i64 -16
  %ld4918 = load i64, ptr %rgep4917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4918, ptr %slot797, align 8
  %v4919 = load i64, ptr %slot797, align 8
  %op4920 = and i64 %v4919, 4611686018427387906
  store i64 %op4920, ptr %slot798, align 8
  %v4921 = load i64, ptr %slot798, align 8
  %cmp4922 = icmp ne i64 %v4921, 0
  %cv4923 = zext i1 %cmp4922 to i32
  store i32 %cv4923, ptr %slot799, align 8
  %v4924 = load i32, ptr %slot799, align 8
  %cv4925 = zext i32 %v4924 to i64
  %cond4926 = icmp ne i64 %cv4925, 0
  br i1 %cond4926, label %bb_rcgclear1028, label %bb_rcgcounted1028
bb_rcgcounted1028:
  %v4927 = load i64, ptr %slot794, align 8
  %op4928 = sub i64 %v4927, 32
  store i64 %op4928, ptr %slot800, align 8
  %v4929 = load i64, ptr %slot794, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  %rgep4931 = getelementptr i8, ptr %p4930, i64 -32
  %ld4932 = load i64, ptr %rgep4931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4932, ptr %slot801, align 8
  %v4933 = load i64, ptr %slot801, align 8
  %op4934 = sub i64 %v4933, 1
  store i64 %op4934, ptr %slot802, align 8
  %v4935 = load i64, ptr %slot802, align 8
  %cmp4936 = icmp eq i64 %v4935, 0
  %cv4937 = zext i1 %cmp4936 to i32
  store i32 %cv4937, ptr %slot803, align 8
  %v4938 = load i32, ptr %slot803, align 8
  %cv4939 = zext i32 %v4938 to i64
  %cond4940 = icmp ne i64 %cv4939, 0
  br i1 %cond4940, label %bb_rcglast1028, label %bb_rcgdec1028
bb_rcglast1028:
  %v4941 = load i64, ptr %slot794, align 8
  %op4942 = sub i64 %v4941, 24
  store i64 %op4942, ptr %slot804, align 8
  %v4943 = load i64, ptr %slot794, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  %rgep4945 = getelementptr i8, ptr %p4944, i64 -24
  %ld4946 = load i64, ptr %rgep4945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4946, ptr %slot805, align 8
  %v4947 = load i64, ptr %slot805, align 8
  %cmp4948 = icmp ne i64 %v4947, 0
  %cv4949 = zext i1 %cmp4948 to i32
  store i32 %cv4949, ptr %slot806, align 8
  %v4950 = load i32, ptr %slot806, align 8
  %cv4951 = zext i32 %v4950 to i64
  %cond4952 = icmp ne i64 %cv4951, 0
  br i1 %cond4952, label %bb_rcgdec1028, label %bb_rcgslow1028
bb_rcgslow1028:
  %v4953 = load i64, ptr %slot793, align 8
  %v4954 = load i64, ptr %slot776, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4953, i64 %v4954) nomerge, !dbg !158
  br label %bb_rcgdone1028
bb_rcgdec1028:
  %v4955 = load i64, ptr %slot802, align 8
  %v4956 = load i64, ptr %slot794, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %rgep4958 = getelementptr i8, ptr %p4957, i64 -32
  store i64 %v4955, ptr %rgep4958, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1028
bb_rcgclear1028:
  %v4959 = load i64, ptr %slot776, align 8
  %p4960 = inttoptr i64 %v4959 to ptr
  store i64 0, ptr %p4960, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1028
bb_rcgdone1028:
  br label %bb_rcslotdone997
bb_rcslotdone997:
  %v4961 = load i64, ptr %slot43, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  %ld4963 = load i64, ptr %p4962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4963, ptr %slot807, align 8
  %v4964 = load i64, ptr %slot42, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %ld4966 = load i64, ptr %p4965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4966, ptr %slot808, align 8
  %v4967 = load i64, ptr %slot808, align 8
  %v4968 = load i64, ptr %slot807, align 8
  %cmp4969 = icmp sge i64 %v4967, %v4968
  %cv4970 = zext i1 %cmp4969 to i64
  store i64 %cv4970, ptr %slot809, align 8
  %v4971 = load i64, ptr %slot809, align 8
  %v4972 = load i64, ptr %slot42, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  store i64 %v4971, ptr %p4973, align 8, !alias.scope !3, !noalias !4
  %v4974 = load i64, ptr %slot42, align 8
  %p4975 = inttoptr i64 %v4974 to ptr
  %ld4976 = load i64, ptr %p4975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4976, ptr %slot810, align 8
  %v4977 = load i64, ptr %slot810, align 8
  %cond4978 = icmp ne i64 %v4977, 0
  br i1 %cond4978, label %bb_next1036, label %bb_i118
bb_next1036:
  %v4979 = load i64, ptr %slot42, align 8
  %p4980 = inttoptr i64 %v4979 to ptr
  store i64 0, ptr %p4980, align 8, !alias.scope !3, !noalias !4
  br label %bb_i127
bb_i118:
  %v4981 = load i64, ptr %slot38, align 8
  %v4982 = load i64, ptr %slot42, align 8
  %p4983 = inttoptr i64 %v4982 to ptr
  store i64 %v4981, ptr %p4983, align 8, !alias.scope !3, !noalias !4
  %v4984 = load i64, ptr %slot42, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  %ld4986 = load i64, ptr %p4985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4986, ptr %slot811, align 8
  %v4987 = load i64, ptr %slot811, align 8
  %op4988 = add i64 %v4987, 0
  store i64 %op4988, ptr %slot812, align 8
  %v4989 = load i64, ptr %slot812, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  %ld4991 = load i64, ptr %p4990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4991, ptr %slot813, align 8
  %v4992 = load i64, ptr %slot813, align 8
  %v4993 = load i64, ptr %slot42, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  store i64 %v4992, ptr %p4994, align 8, !alias.scope !3, !noalias !4
  %v4995 = load i64, ptr %slot42, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %ld4997 = load i64, ptr %p4996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4997, ptr %slot814, align 8
  %v4998 = load i64, ptr %slot814, align 8
  %v4999 = load i64, ptr %slot26, align 8
  %p5000 = inttoptr i64 %v4999 to ptr
  store i64 %v4998, ptr %p5000, align 8, !alias.scope !3, !noalias !4
  %v5001 = load i64, ptr %slot26, align 8
  store i64 %v5001, ptr %slot815, align 8
  %v5002 = load i64, ptr %slot28, align 8
  store i64 %v5002, ptr %slot816, align 8
  %v5003 = load i64, ptr %slot815, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %ld5005 = load i64, ptr %p5004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5005, ptr %slot817, align 8
  %v5006 = load i64, ptr %slot817, align 8
  %cmp5007 = icmp ne i64 %v5006, 0
  %cv5008 = zext i1 %cmp5007 to i32
  store i32 %cv5008, ptr %slot818, align 8
  %v5009 = load i32, ptr %slot818, align 8
  %cv5010 = zext i32 %v5009 to i64
  %cond5011 = icmp ne i64 %cv5010, 0
  br i1 %cond5011, label %bb_rcgnn1043, label %bb_rcgstore1043
bb_rcgnn1043:
  %v5012 = load i64, ptr %slot817, align 8
  %op5013 = sub i64 %v5012, 16
  store i64 %op5013, ptr %slot819, align 8
  %v5014 = load i64, ptr %slot817, align 8
  %p5015 = inttoptr i64 %v5014 to ptr
  %rgep5016 = getelementptr i8, ptr %p5015, i64 -16
  %ld5017 = load i64, ptr %rgep5016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5017, ptr %slot820, align 8
  %v5018 = load i64, ptr %slot820, align 8
  %op5019 = and i64 %v5018, 4611686018427387906
  store i64 %op5019, ptr %slot821, align 8
  %v5020 = load i64, ptr %slot821, align 8
  %cmp5021 = icmp ne i64 %v5020, 0
  %cv5022 = zext i1 %cmp5021 to i32
  store i32 %cv5022, ptr %slot822, align 8
  %v5023 = load i32, ptr %slot822, align 8
  %cv5024 = zext i32 %v5023 to i64
  %cond5025 = icmp ne i64 %cv5024, 0
  br i1 %cond5025, label %bb_rcgstore1043, label %bb_rcginc1043
bb_rcginc1043:
  %v5026 = load i64, ptr %slot817, align 8
  %op5027 = sub i64 %v5026, 24
  store i64 %op5027, ptr %slot823, align 8
  %v5028 = load i64, ptr %slot817, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  %rgep5030 = getelementptr i8, ptr %p5029, i64 -24
  %ld5031 = load i64, ptr %rgep5030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5031, ptr %slot824, align 8
  %v5032 = load i64, ptr %slot824, align 8
  %op5033 = add i64 %v5032, 1
  store i64 %op5033, ptr %slot825, align 8
  %v5034 = load i64, ptr %slot825, align 8
  %cmp5035 = icmp eq i64 %v5034, 0
  %cv5036 = zext i1 %cmp5035 to i32
  store i32 %cv5036, ptr %slot826, align 8
  %v5037 = load i32, ptr %slot826, align 8
  %cv5038 = zext i32 %v5037 to i64
  %cond5039 = icmp ne i64 %cv5038, 0
  br i1 %cond5039, label %bb_rcglimit1043, label %bb_rcgcapacity1043
bb_rcglimit1043:
  %v5040 = load i64, ptr %slot1, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  %call5042 = call i32 @myl_qbe_rc_status(ptr %p5041, i32 2) nomerge, !dbg !160
  store i32 %call5042, ptr %slot827, align 8
  br label %bb_failure
bb_rcgcapacity1043:
  %v5043 = load i64, ptr %slot825, align 8
  %v5044 = load i64, ptr %slot817, align 8
  %p5045 = inttoptr i64 %v5044 to ptr
  %rgep5046 = getelementptr i8, ptr %p5045, i64 -24
  store i64 %v5043, ptr %rgep5046, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1043
bb_rcgstore1043:
  %v5047 = load i64, ptr %slot817, align 8
  %v5048 = load i64, ptr %slot816, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  store i64 %v5047, ptr %p5049, align 8, !alias.scope !3, !noalias !4
  %v5050 = load i64, ptr %slot23, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  store i32 2, ptr %p5051, align 4, !alias.scope !3, !noalias !4
  %v5052 = load i64, ptr %slot23, align 8
  %p5053 = inttoptr i64 %v5052 to ptr
  store i32 16, ptr %p5053, align 4, !alias.scope !3, !noalias !4
  %v5054 = load i64, ptr %slot22, align 8
  %p5055 = inttoptr i64 %v5054 to ptr
  store i32 1, ptr %p5055, align 4, !alias.scope !3, !noalias !4
  %v5056 = load i64, ptr %slot18, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %ld5058 = load i32, ptr %p5057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5058, ptr %slot828, align 8
  %v5059 = load i32, ptr %slot828, align 8
  %cv5060 = zext i32 %v5059 to i64
  %cond5061 = icmp ne i64 %cv5060, 0
  br i1 %cond5061, label %bb_rcslotdrop1059, label %bb_rcslotdone1059
bb_rcslotdrop1059:
  %v5062 = load i64, ptr %slot18, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  store i32 0, ptr %p5063, align 4, !alias.scope !3, !noalias !4
  %v5064 = load i64, ptr %slot24, align 8
  store i64 %v5064, ptr %slot829, align 8
  %v5065 = load i64, ptr %slot19, align 8
  %p5066 = inttoptr i64 %v5065 to ptr
  %ld5067 = load i32, ptr %p5066, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5067, ptr %slot830, align 8
  %v5068 = load i32, ptr %slot830, align 8
  %op5069 = and i32 %v5068, 28
  store i32 %op5069, ptr %slot831, align 8
  %v5070 = load i32, ptr %slot831, align 8
  %cv5071 = zext i32 %v5070 to i64
  %cond5072 = icmp ne i64 %cv5071, 0
  br i1 %cond5072, label %bb_rcslotrole1059, label %bb_rcslotowner1059
bb_rcslotrole1059:
  %v5073 = load i64, ptr %slot45, align 8
  store i64 %v5073, ptr %slot832, align 8
  %v5074 = load i64, ptr %slot832, align 8
  %v5075 = load i64, ptr %slot829, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5074, i64 %v5075) nomerge, !dbg !160
  br label %bb_rcslotdone1059
bb_rcslotowner1059:
  %v5076 = load i64, ptr %slot45, align 8
  store i64 %v5076, ptr %slot833, align 8
  %v5077 = load i64, ptr %slot833, align 8
  %v5078 = load i64, ptr %slot829, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5077, i64 %v5078) nomerge, !dbg !160
  br label %bb_rcslotdone1059
bb_rcslotdone1059:
  %v5079 = load i64, ptr %slot24, align 8
  store i64 %v5079, ptr %slot834, align 8
  %v5080 = load i64, ptr %slot28, align 8
  store i64 %v5080, ptr %slot835, align 8
  %v5081 = load i64, ptr %slot835, align 8
  %v5082 = load i64, ptr %slot834, align 8
  %p5083 = inttoptr i64 %v5081 to ptr
  %p5084 = inttoptr i64 %v5082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5084, ptr %p5083, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5085 = load i64, ptr %slot19, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  store i32 2, ptr %p5086, align 4, !alias.scope !3, !noalias !4
  %v5087 = load i64, ptr %slot23, align 8
  %p5088 = inttoptr i64 %v5087 to ptr
  %ld5089 = load i32, ptr %p5088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5089, ptr %slot836, align 8
  %v5090 = load i32, ptr %slot836, align 8
  %v5091 = load i64, ptr %slot19, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i32 %v5090, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  %v5093 = load i64, ptr %slot22, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  store i32 0, ptr %p5094, align 4, !alias.scope !3, !noalias !4
  %v5095 = load i64, ptr %slot18, align 8
  %p5096 = inttoptr i64 %v5095 to ptr
  store i32 1, ptr %p5096, align 4, !alias.scope !3, !noalias !4
  %v5097 = load i64, ptr %slot834, align 8
  %p5098 = inttoptr i64 %v5097 to ptr
  %ld5099 = load i64, ptr %p5098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5099, ptr %slot837, align 8
  %v5100 = load i64, ptr %slot837, align 8
  %v5101 = load i64, ptr %slot42, align 8
  %p5102 = inttoptr i64 %v5101 to ptr
  store i64 %v5100, ptr %p5102, align 8, !alias.scope !3, !noalias !4
  %v5103 = load i64, ptr %slot38, align 8
  %v5104 = load i64, ptr %slot43, align 8
  %p5105 = inttoptr i64 %v5104 to ptr
  store i64 %v5103, ptr %p5105, align 8, !alias.scope !3, !noalias !4
  %v5106 = load i64, ptr %slot43, align 8
  %p5107 = inttoptr i64 %v5106 to ptr
  %ld5108 = load i64, ptr %p5107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5108, ptr %slot838, align 8
  %v5109 = load i64, ptr %slot838, align 8
  %op5110 = add i64 %v5109, 16
  store i64 %op5110, ptr %slot839, align 8
  %v5111 = load i64, ptr %slot839, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  %ld5113 = load i64, ptr %p5112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5113, ptr %slot840, align 8
  %v5114 = load i64, ptr %slot840, align 8
  %v5115 = load i64, ptr %slot43, align 8
  %p5116 = inttoptr i64 %v5115 to ptr
  store i64 %v5114, ptr %p5116, align 8, !alias.scope !3, !noalias !4
  %v5117 = load i64, ptr %slot20, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  %ld5119 = load i32, ptr %p5118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5119, ptr %slot841, align 8
  %v5120 = load i32, ptr %slot841, align 8
  %cv5121 = zext i32 %v5120 to i64
  %cond5122 = icmp ne i64 %cv5121, 0
  br i1 %cond5122, label %bb_rcslotdrop1080, label %bb_rcslotdone1080
bb_rcslotdrop1080:
  %v5123 = load i64, ptr %slot20, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i32 0, ptr %p5124, align 4, !alias.scope !3, !noalias !4
  %v5125 = load i64, ptr %slot25, align 8
  store i64 %v5125, ptr %slot842, align 8
  %v5126 = load i64, ptr %slot21, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  %ld5128 = load i32, ptr %p5127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5128, ptr %slot843, align 8
  %v5129 = load i32, ptr %slot843, align 8
  %op5130 = and i32 %v5129, 28
  store i32 %op5130, ptr %slot844, align 8
  %v5131 = load i32, ptr %slot844, align 8
  %cv5132 = zext i32 %v5131 to i64
  %cond5133 = icmp ne i64 %cv5132, 0
  br i1 %cond5133, label %bb_rcslotrole1080, label %bb_rcslotowner1080
bb_rcslotrole1080:
  %v5134 = load i64, ptr %slot45, align 8
  store i64 %v5134, ptr %slot845, align 8
  %v5135 = load i64, ptr %slot845, align 8
  %v5136 = load i64, ptr %slot842, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5135, i64 %v5136) nomerge, !dbg !162
  br label %bb_rcslotdone1080
bb_rcslotowner1080:
  %v5137 = load i64, ptr %slot45, align 8
  store i64 %v5137, ptr %slot846, align 8
  %v5138 = load i64, ptr %slot846, align 8
  %v5139 = load i64, ptr %slot842, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v5138, i64 %v5139) nomerge, !dbg !162
  br label %bb_rcslotdone1080
bb_rcslotdone1080:
  %v5140 = load i64, ptr %slot44, align 8
  %p5141 = inttoptr i64 %v5140 to ptr
  store i64 1, ptr %p5141, align 8, !alias.scope !3, !noalias !4
  %v5142 = load i64, ptr %slot44, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  %ld5144 = load i64, ptr %p5143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5144, ptr %slot847, align 8
  %v5145 = load i64, ptr %slot43, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  %ld5147 = load i64, ptr %p5146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5147, ptr %slot848, align 8
  %v5148 = load i64, ptr %slot848, align 8
  %v5149 = load i64, ptr %slot847, align 8
  %ovpair5151 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5148, i64 %v5149)
  %op5150 = extractvalue { i64, i1 } %ovpair5151, 0
  %ov5152 = extractvalue { i64, i1 } %ovpair5151, 1
  store i64 %op5150, ptr %slot849, align 8
  %cv5153 = zext i1 %ov5152 to i64
  store i64 %cv5153, ptr %slot850, align 8
  %v5154 = load i64, ptr %slot850, align 8
  %cond5155 = icmp ne i64 %v5154, 0
  br i1 %cond5155, label %bb_overflow1089, label %bb_checked1089
bb_overflow1089:
  %v5156 = load i64, ptr %slot1, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %v5158 = load i64, ptr %slot848, align 8
  %v5159 = load i64, ptr %slot847, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5157, i64 0, i64 %v5158, i64 %v5159, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1089:
  %v5160 = load i64, ptr %slot849, align 8
  %v5161 = load i64, ptr %slot43, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  store i64 %v5160, ptr %p5162, align 8, !alias.scope !3, !noalias !4
  %v5163 = load i64, ptr %slot42, align 8
  %p5164 = inttoptr i64 %v5163 to ptr
  %ld5165 = load i64, ptr %p5164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5165, ptr %slot851, align 8
  %v5166 = load i64, ptr %slot43, align 8
  %p5167 = inttoptr i64 %v5166 to ptr
  %ld5168 = load i64, ptr %p5167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5168, ptr %slot852, align 8
  %v5169 = load i64, ptr %slot851, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  %ld5171 = load i64, ptr %p5170, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5171, ptr %slot853, align 8
  %v5172 = load i64, ptr %slot852, align 8
  %op5173 = ashr i64 %v5172, 63
  store i64 %op5173, ptr %slot854, align 8
  %v5174 = load i64, ptr %slot854, align 8
  %v5175 = load i64, ptr %slot853, align 8
  %op5176 = and i64 %v5174, %v5175
  store i64 %op5176, ptr %slot855, align 8
  %v5177 = load i64, ptr %slot852, align 8
  %v5178 = load i64, ptr %slot855, align 8
  %op5179 = add i64 %v5177, %v5178
  store i64 %op5179, ptr %slot856, align 8
  %v5180 = load i64, ptr %slot856, align 8
  %v5181 = load i64, ptr %slot853, align 8
  %cmp5182 = icmp ult i64 %v5180, %v5181
  %cv5183 = zext i1 %cmp5182 to i64
  store i64 %cv5183, ptr %slot857, align 8
  %v5184 = load i64, ptr %slot857, align 8
  %cond5185 = icmp ne i64 %v5184, 0
  br i1 %cond5185, label %bb_success1099, label %bb_failed1099
bb_failed1099:
  %v5186 = load i64, ptr %slot1, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %v5188 = load i64, ptr %slot852, align 8
  %v5189 = load i64, ptr %slot853, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p5187, i64 %v5188, i64 %v5189) nomerge, !dbg !166
  unreachable
bb_success1099:
  %v5190 = load i64, ptr %slot851, align 8
  %op5191 = add i64 %v5190, 32
  store i64 %op5191, ptr %slot858, align 8
  %v5192 = load i64, ptr %slot858, align 8
  %p5193 = inttoptr i64 %v5192 to ptr
  %ld5194 = load i64, ptr %p5193, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5194, ptr %slot859, align 8
  %v5195 = load i64, ptr %slot859, align 8
  %v5196 = load i64, ptr %slot856, align 8
  %op5197 = add i64 %v5195, %v5196
  store i64 %op5197, ptr %slot860, align 8
  %v5198 = load i64, ptr %slot859, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  %v5200 = load i64, ptr %slot856, align 8
  %egep5201 = getelementptr i8, ptr %p5199, i64 %v5200
  %ld5202 = load i8, ptr %egep5201, align 1, !alias.scope !12, !noalias !13
  %ext5203 = zext i8 %ld5202 to i64
  store i64 %ext5203, ptr %slot861, align 8
  %v5204 = load i64, ptr %slot861, align 8
  %v5205 = load i64, ptr %slot42, align 8
  %p5206 = inttoptr i64 %v5205 to ptr
  store i64 %v5204, ptr %p5206, align 8, !alias.scope !3, !noalias !4
  %v5207 = load i64, ptr %slot18, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  %ld5209 = load i32, ptr %p5208, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5209, ptr %slot862, align 8
  %v5210 = load i32, ptr %slot862, align 8
  %cv5211 = zext i32 %v5210 to i64
  %cond5212 = icmp ne i64 %cv5211, 0
  br i1 %cond5212, label %bb_rcslotdrop1107, label %bb_rcslotdone1107
bb_rcslotdrop1107:
  %v5213 = load i64, ptr %slot18, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  store i32 0, ptr %p5214, align 4, !alias.scope !3, !noalias !4
  %v5215 = load i64, ptr %slot24, align 8
  store i64 %v5215, ptr %slot863, align 8
  %v5216 = load i64, ptr %slot19, align 8
  %p5217 = inttoptr i64 %v5216 to ptr
  %ld5218 = load i32, ptr %p5217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5218, ptr %slot864, align 8
  %v5219 = load i32, ptr %slot864, align 8
  %op5220 = and i32 %v5219, 28
  store i32 %op5220, ptr %slot865, align 8
  %v5221 = load i32, ptr %slot865, align 8
  %cv5222 = zext i32 %v5221 to i64
  %cond5223 = icmp ne i64 %cv5222, 0
  br i1 %cond5223, label %bb_rcslotrole1107, label %bb_rcslotowner1107
bb_rcslotrole1107:
  %v5224 = load i64, ptr %slot45, align 8
  store i64 %v5224, ptr %slot866, align 8
  %v5225 = load i64, ptr %slot863, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  %ld5227 = load i64, ptr %p5226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5227, ptr %slot867, align 8
  %v5228 = load i64, ptr %slot867, align 8
  %cmp5229 = icmp ne i64 %v5228, 0
  %cv5230 = zext i1 %cmp5229 to i32
  store i32 %cv5230, ptr %slot868, align 8
  %v5231 = load i32, ptr %slot868, align 8
  %cv5232 = zext i32 %v5231 to i64
  %cond5233 = icmp ne i64 %cv5232, 0
  br i1 %cond5233, label %bb_rcgnn1123, label %bb_rcgdone1123
bb_rcgnn1123:
  %v5234 = load i64, ptr %slot867, align 8
  %op5235 = sub i64 %v5234, 16
  store i64 %op5235, ptr %slot869, align 8
  %v5236 = load i64, ptr %slot867, align 8
  %p5237 = inttoptr i64 %v5236 to ptr
  %rgep5238 = getelementptr i8, ptr %p5237, i64 -16
  %ld5239 = load i64, ptr %rgep5238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5239, ptr %slot870, align 8
  %v5240 = load i64, ptr %slot870, align 8
  %op5241 = and i64 %v5240, 4611686018427387906
  store i64 %op5241, ptr %slot871, align 8
  %v5242 = load i64, ptr %slot871, align 8
  %cmp5243 = icmp ne i64 %v5242, 0
  %cv5244 = zext i1 %cmp5243 to i32
  store i32 %cv5244, ptr %slot872, align 8
  %v5245 = load i32, ptr %slot872, align 8
  %cv5246 = zext i32 %v5245 to i64
  %cond5247 = icmp ne i64 %cv5246, 0
  br i1 %cond5247, label %bb_rcgclear1123, label %bb_rcgcounted1123
bb_rcgcounted1123:
  %v5248 = load i64, ptr %slot867, align 8
  %op5249 = sub i64 %v5248, 24
  store i64 %op5249, ptr %slot873, align 8
  %v5250 = load i64, ptr %slot867, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  %rgep5252 = getelementptr i8, ptr %p5251, i64 -24
  %ld5253 = load i64, ptr %rgep5252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5253, ptr %slot874, align 8
  %v5254 = load i64, ptr %slot874, align 8
  %op5255 = sub i64 %v5254, 1
  store i64 %op5255, ptr %slot875, align 8
  %v5256 = load i64, ptr %slot875, align 8
  %cmp5257 = icmp eq i64 %v5256, 0
  %cv5258 = zext i1 %cmp5257 to i32
  store i32 %cv5258, ptr %slot876, align 8
  %v5259 = load i32, ptr %slot876, align 8
  %cv5260 = zext i32 %v5259 to i64
  %cond5261 = icmp ne i64 %cv5260, 0
  br i1 %cond5261, label %bb_rcglast1123, label %bb_rcgdec1123
bb_rcglast1123:
  %v5262 = load i64, ptr %slot867, align 8
  %op5263 = sub i64 %v5262, 32
  store i64 %op5263, ptr %slot877, align 8
  %v5264 = load i64, ptr %slot867, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  %rgep5266 = getelementptr i8, ptr %p5265, i64 -32
  %ld5267 = load i64, ptr %rgep5266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5267, ptr %slot878, align 8
  %v5268 = load i64, ptr %slot878, align 8
  %cmp5269 = icmp ne i64 %v5268, 0
  %cv5270 = zext i1 %cmp5269 to i32
  store i32 %cv5270, ptr %slot879, align 8
  %v5271 = load i32, ptr %slot879, align 8
  %cv5272 = zext i32 %v5271 to i64
  %cond5273 = icmp ne i64 %cv5272, 0
  br i1 %cond5273, label %bb_rcgdec1123, label %bb_rcgslow1123
bb_rcgslow1123:
  %v5274 = load i64, ptr %slot866, align 8
  %v5275 = load i64, ptr %slot863, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5274, i64 %v5275) nomerge, !dbg !166
  br label %bb_rcgdone1123
bb_rcgdec1123:
  %v5276 = load i64, ptr %slot875, align 8
  %v5277 = load i64, ptr %slot867, align 8
  %p5278 = inttoptr i64 %v5277 to ptr
  %rgep5279 = getelementptr i8, ptr %p5278, i64 -24
  store i64 %v5276, ptr %rgep5279, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1123
bb_rcgclear1123:
  %v5280 = load i64, ptr %slot863, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  store i64 0, ptr %p5281, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1123
bb_rcgdone1123:
  br label %bb_rcslotdone1107
bb_rcslotowner1107:
  %v5282 = load i64, ptr %slot45, align 8
  store i64 %v5282, ptr %slot880, align 8
  %v5283 = load i64, ptr %slot863, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  %ld5285 = load i64, ptr %p5284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5285, ptr %slot881, align 8
  %v5286 = load i64, ptr %slot881, align 8
  %cmp5287 = icmp ne i64 %v5286, 0
  %cv5288 = zext i1 %cmp5287 to i32
  store i32 %cv5288, ptr %slot882, align 8
  %v5289 = load i32, ptr %slot882, align 8
  %cv5290 = zext i32 %v5289 to i64
  %cond5291 = icmp ne i64 %cv5290, 0
  br i1 %cond5291, label %bb_rcgnn1138, label %bb_rcgdone1138
bb_rcgnn1138:
  %v5292 = load i64, ptr %slot881, align 8
  %op5293 = sub i64 %v5292, 16
  store i64 %op5293, ptr %slot883, align 8
  %v5294 = load i64, ptr %slot881, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %rgep5296 = getelementptr i8, ptr %p5295, i64 -16
  %ld5297 = load i64, ptr %rgep5296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5297, ptr %slot884, align 8
  %v5298 = load i64, ptr %slot884, align 8
  %op5299 = and i64 %v5298, 4611686018427387906
  store i64 %op5299, ptr %slot885, align 8
  %v5300 = load i64, ptr %slot885, align 8
  %cmp5301 = icmp ne i64 %v5300, 0
  %cv5302 = zext i1 %cmp5301 to i32
  store i32 %cv5302, ptr %slot886, align 8
  %v5303 = load i32, ptr %slot886, align 8
  %cv5304 = zext i32 %v5303 to i64
  %cond5305 = icmp ne i64 %cv5304, 0
  br i1 %cond5305, label %bb_rcgclear1138, label %bb_rcgcounted1138
bb_rcgcounted1138:
  %v5306 = load i64, ptr %slot881, align 8
  %op5307 = sub i64 %v5306, 32
  store i64 %op5307, ptr %slot887, align 8
  %v5308 = load i64, ptr %slot881, align 8
  %p5309 = inttoptr i64 %v5308 to ptr
  %rgep5310 = getelementptr i8, ptr %p5309, i64 -32
  %ld5311 = load i64, ptr %rgep5310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5311, ptr %slot888, align 8
  %v5312 = load i64, ptr %slot888, align 8
  %op5313 = sub i64 %v5312, 1
  store i64 %op5313, ptr %slot889, align 8
  %v5314 = load i64, ptr %slot889, align 8
  %cmp5315 = icmp eq i64 %v5314, 0
  %cv5316 = zext i1 %cmp5315 to i32
  store i32 %cv5316, ptr %slot890, align 8
  %v5317 = load i32, ptr %slot890, align 8
  %cv5318 = zext i32 %v5317 to i64
  %cond5319 = icmp ne i64 %cv5318, 0
  br i1 %cond5319, label %bb_rcglast1138, label %bb_rcgdec1138
bb_rcglast1138:
  %v5320 = load i64, ptr %slot881, align 8
  %op5321 = sub i64 %v5320, 24
  store i64 %op5321, ptr %slot891, align 8
  %v5322 = load i64, ptr %slot881, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  %rgep5324 = getelementptr i8, ptr %p5323, i64 -24
  %ld5325 = load i64, ptr %rgep5324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5325, ptr %slot892, align 8
  %v5326 = load i64, ptr %slot892, align 8
  %cmp5327 = icmp ne i64 %v5326, 0
  %cv5328 = zext i1 %cmp5327 to i32
  store i32 %cv5328, ptr %slot893, align 8
  %v5329 = load i32, ptr %slot893, align 8
  %cv5330 = zext i32 %v5329 to i64
  %cond5331 = icmp ne i64 %cv5330, 0
  br i1 %cond5331, label %bb_rcgdec1138, label %bb_rcgslow1138
bb_rcgslow1138:
  %v5332 = load i64, ptr %slot880, align 8
  %v5333 = load i64, ptr %slot863, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5332, i64 %v5333) nomerge, !dbg !166
  br label %bb_rcgdone1138
bb_rcgdec1138:
  %v5334 = load i64, ptr %slot889, align 8
  %v5335 = load i64, ptr %slot881, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %rgep5337 = getelementptr i8, ptr %p5336, i64 -32
  store i64 %v5334, ptr %rgep5337, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1138
bb_rcgclear1138:
  %v5338 = load i64, ptr %slot863, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  store i64 0, ptr %p5339, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1138
bb_rcgdone1138:
  br label %bb_rcslotdone1107
bb_rcslotdone1107:
  %v5340 = load i64, ptr %slot42, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %ld5342 = load i64, ptr %p5341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5342, ptr %slot894, align 8
  %v5343 = load i64, ptr %slot894, align 8
  %v5344 = load i64, ptr %slot42, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  store i64 %v5343, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  br label %bb_i127
bb_i127:
  %v5346 = load i64, ptr %slot43, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  store i64 47, ptr %p5347, align 8, !alias.scope !3, !noalias !4
  %v5348 = load i64, ptr %slot43, align 8
  %p5349 = inttoptr i64 %v5348 to ptr
  %ld5350 = load i64, ptr %p5349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5350, ptr %slot895, align 8
  %v5351 = load i64, ptr %slot42, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i64, ptr %p5352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5353, ptr %slot896, align 8
  %v5354 = load i64, ptr %slot896, align 8
  %v5355 = load i64, ptr %slot895, align 8
  %cmp5356 = icmp eq i64 %v5354, %v5355
  %cv5357 = zext i1 %cmp5356 to i64
  store i64 %cv5357, ptr %slot897, align 8
  %v5358 = load i64, ptr %slot897, align 8
  %v5359 = load i64, ptr %slot42, align 8
  %p5360 = inttoptr i64 %v5359 to ptr
  store i64 %v5358, ptr %p5360, align 8, !alias.scope !3, !noalias !4
  br label %bb_i131
bb_i130:
  %v5361 = load i64, ptr %slot42, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  store i64 0, ptr %p5362, align 8, !alias.scope !3, !noalias !4
  br label %bb_i131
bb_i131:
  %v5363 = load i64, ptr %slot42, align 8
  %p5364 = inttoptr i64 %v5363 to ptr
  %ld5365 = load i64, ptr %p5364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5365, ptr %slot898, align 8
  %v5366 = load i64, ptr %slot898, align 8
  %cond5367 = icmp ne i64 %v5366, 0
  br i1 %cond5367, label %bb_next1147, label %bb_i186
bb_next1147:
  br label %bb_i132
bb_i132:
  %v5368 = load i64, ptr %slot29, align 8
  %p5369 = inttoptr i64 %v5368 to ptr
  %ld5370 = load i64, ptr %p5369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5370, ptr %slot899, align 8
  %v5371 = load i64, ptr %slot899, align 8
  %v5372 = load i64, ptr %slot42, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  store i64 %v5371, ptr %p5373, align 8, !alias.scope !3, !noalias !4
  %v5374 = load i64, ptr %slot42, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  %ld5376 = load i64, ptr %p5375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5376, ptr %slot900, align 8
  %v5377 = load i64, ptr %slot18, align 8
  %p5378 = inttoptr i64 %v5377 to ptr
  %ld5379 = load i32, ptr %p5378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5379, ptr %slot901, align 8
  %v5380 = load i64, ptr %slot19, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %ld5382 = load i32, ptr %p5381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5382, ptr %slot902, align 8
  %v5383 = load i32, ptr %slot902, align 8
  %op5384 = and i32 %v5383, 24
  store i32 %op5384, ptr %slot902, align 8
  %v5385 = load i32, ptr %slot902, align 8
  %cmp5386 = icmp eq i32 %v5385, 0
  %cv5387 = zext i1 %cmp5386 to i32
  store i32 %cv5387, ptr %slot903, align 8
  %v5388 = load i32, ptr %slot901, align 8
  %v5389 = load i32, ptr %slot903, align 8
  %op5390 = and i32 %v5388, %v5389
  store i32 %op5390, ptr %slot904, align 8
  %v5391 = load i32, ptr %slot904, align 8
  %cv5392 = zext i32 %v5391 to i64
  %cond5393 = icmp ne i64 %cv5392, 0
  br i1 %cond5393, label %bb_rctake1149, label %bb_rccopy1149
bb_rctake1149:
  %v5394 = load i64, ptr %slot28, align 8
  store i64 %v5394, ptr %slot905, align 8
  %v5395 = load i64, ptr %slot46, align 8
  store i64 %v5395, ptr %slot906, align 8
  %v5396 = load i64, ptr %slot900, align 8
  %v5397 = load i64, ptr %slot905, align 8
  %op5398 = sub i64 %v5396, %v5397
  store i64 %op5398, ptr %slot907, align 8
  %v5399 = load i64, ptr %slot905, align 8
  %v5400 = load i64, ptr %slot900, align 8
  %op5401 = sub i64 %v5399, %v5400
  store i64 %op5401, ptr %slot908, align 8
  %v5402 = load i64, ptr %slot907, align 8
  %cmp5403 = icmp ult i64 %v5402, 32
  %cv5404 = zext i1 %cmp5403 to i32
  store i32 %cv5404, ptr %slot909, align 8
  %v5405 = load i64, ptr %slot908, align 8
  %cmp5406 = icmp ult i64 %v5405, 32
  %cv5407 = zext i1 %cmp5406 to i32
  store i32 %cv5407, ptr %slot910, align 8
  %v5408 = load i32, ptr %slot909, align 8
  %v5409 = load i32, ptr %slot910, align 8
  %op5410 = or i32 %v5408, %v5409
  store i32 %op5410, ptr %slot911, align 8
  %v5411 = load i32, ptr %slot911, align 8
  %cv5412 = zext i32 %v5411 to i64
  %cond5413 = icmp ne i64 %cv5412, 0
  br i1 %cond5413, label %bb_rcmoveslow1158, label %bb_rcmovecheck1158
bb_rcmovecheck1158:
  %v5414 = load i64, ptr %slot900, align 8
  %op5415 = add i64 %v5414, 0
  store i64 %op5415, ptr %slot912, align 8
  %v5416 = load i64, ptr %slot912, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %ld5418 = load i64, ptr %p5417, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5418, ptr %slot913, align 8
  %v5419 = load i64, ptr %slot913, align 8
  %cmp5420 = icmp ne i64 %v5419, 0
  %cv5421 = zext i1 %cmp5420 to i32
  store i32 %cv5421, ptr %slot914, align 8
  %v5422 = load i32, ptr %slot914, align 8
  %cv5423 = zext i32 %v5422 to i64
  %cond5424 = icmp ne i64 %cv5423, 0
  br i1 %cond5424, label %bb_rcmoveheader1166, label %bb_rcmovenext1166
bb_rcmoveheader1166:
  %v5425 = load i64, ptr %slot913, align 8
  %op5426 = sub i64 %v5425, 16
  store i64 %op5426, ptr %slot915, align 8
  %v5427 = load i64, ptr %slot913, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %rgep5429 = getelementptr i8, ptr %p5428, i64 -16
  %ld5430 = load i64, ptr %rgep5429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5430, ptr %slot916, align 8
  %v5431 = load i64, ptr %slot916, align 8
  %op5432 = and i64 %v5431, 5764607523034234881
  store i64 %op5432, ptr %slot917, align 8
  %v5433 = load i64, ptr %slot917, align 8
  %cmp5434 = icmp ne i64 %v5433, 0
  %cv5435 = zext i1 %cmp5434 to i32
  store i32 %cv5435, ptr %slot918, align 8
  %v5436 = load i32, ptr %slot918, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcmoveslow1158, label %bb_rcmovenext1166
bb_rcmovenext1166:
  %v5439 = load i64, ptr %slot900, align 8
  %v5440 = load i64, ptr %slot905, align 8
  %p5441 = inttoptr i64 %v5439 to ptr
  %p5442 = inttoptr i64 %v5440 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5442, ptr %p5441, i64 32, i1 false), !alias.scope !10000000
  %v5443 = load i64, ptr %slot900, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  store i64 0, ptr %p5444, align 8, !alias.scope !4, !noalias !3
  %v5445 = load i64, ptr %slot900, align 8
  %op5446 = add i64 %v5445, 8
  store i64 %op5446, ptr %slot919, align 8
  %v5447 = load i64, ptr %slot919, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  store i64 0, ptr %p5448, align 8, !alias.scope !4, !noalias !3
  %v5449 = load i64, ptr %slot900, align 8
  %op5450 = add i64 %v5449, 16
  store i64 %op5450, ptr %slot920, align 8
  %v5451 = load i64, ptr %slot920, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  store i64 0, ptr %p5452, align 8, !alias.scope !4, !noalias !3
  %v5453 = load i64, ptr %slot900, align 8
  %op5454 = add i64 %v5453, 24
  store i64 %op5454, ptr %slot921, align 8
  %v5455 = load i64, ptr %slot921, align 8
  %p5456 = inttoptr i64 %v5455 to ptr
  store i64 0, ptr %p5456, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1158
bb_rcmoveslow1158:
  %v5457 = load i64, ptr %slot45, align 8
  %v5458 = load i64, ptr %slot905, align 8
  %v5459 = load i64, ptr %slot900, align 8
  %v5460 = load i64, ptr %slot906, align 8
  %cv5461 = trunc i64 %v5460 to i32
  %call5462 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v5457, i64 %v5458, i64 %v5459, i32 %cv5461) nomerge, !dbg !168
  store i32 %call5462, ptr %slot922, align 8
  %v5463 = load i32, ptr %slot922, align 8
  %cv5464 = zext i32 %v5463 to i64
  %cond5465 = icmp ne i64 %cv5464, 0
  br i1 %cond5465, label %bb_rcsuccess1176, label %bb_rcfailure1176
bb_rcfailure1176:
  %v5466 = load i64, ptr %slot45, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  %call5468 = call i32 @myl_rc_take_failure(ptr %p5467) nomerge, !dbg !168
  store i32 %call5468, ptr %slot923, align 8
  %v5469 = load i64, ptr %slot1, align 8
  %p5470 = inttoptr i64 %v5469 to ptr
  %v5471 = load i32, ptr %slot923, align 8
  %call5472 = call i32 @myl_qbe_rc_status(ptr %p5470, i32 %v5471) nomerge, !dbg !168
  store i32 %call5472, ptr %slot924, align 8
  br label %bb_failure
bb_rcsuccess1176:
  br label %bb_rcmoved1158
bb_rcmoved1158:
  %v5473 = load i64, ptr %slot18, align 8
  %p5474 = inttoptr i64 %v5473 to ptr
  store i32 0, ptr %p5474, align 4, !alias.scope !3, !noalias !4
  %v5475 = load i64, ptr %slot23, align 8
  %p5476 = inttoptr i64 %v5475 to ptr
  store i32 2, ptr %p5476, align 4, !alias.scope !3, !noalias !4
  %v5477 = load i64, ptr %slot22, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  store i32 1, ptr %p5478, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1149
bb_rccopy1149:
  %v5479 = load i64, ptr %slot28, align 8
  store i64 %v5479, ptr %slot925, align 8
  %v5480 = load i64, ptr %slot46, align 8
  store i64 %v5480, ptr %slot926, align 8
  %v5481 = load i64, ptr %slot45, align 8
  %v5482 = load i64, ptr %slot925, align 8
  %v5483 = load i64, ptr %slot900, align 8
  %v5484 = load i64, ptr %slot926, align 8
  %cv5485 = trunc i64 %v5484 to i32
  %call5486 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v5481, i64 %v5482, i64 %v5483, i32 %cv5485) nomerge, !dbg !168
  store i32 %call5486, ptr %slot927, align 8
  %v5487 = load i32, ptr %slot927, align 8
  %cv5488 = zext i32 %v5487 to i64
  %cond5489 = icmp ne i64 %cv5488, 0
  br i1 %cond5489, label %bb_rcsuccess1185, label %bb_rcfailure1185
bb_rcfailure1185:
  %v5490 = load i64, ptr %slot45, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  %call5492 = call i32 @myl_rc_take_failure(ptr %p5491) nomerge, !dbg !168
  store i32 %call5492, ptr %slot928, align 8
  %v5493 = load i64, ptr %slot1, align 8
  %p5494 = inttoptr i64 %v5493 to ptr
  %v5495 = load i32, ptr %slot928, align 8
  %call5496 = call i32 @myl_qbe_rc_status(ptr %p5494, i32 %v5495) nomerge, !dbg !168
  store i32 %call5496, ptr %slot929, align 8
  br label %bb_failure
bb_rcsuccess1185:
  %v5497 = load i64, ptr %slot23, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  store i32 2, ptr %p5498, align 4, !alias.scope !3, !noalias !4
  %v5499 = load i64, ptr %slot22, align 8
  %p5500 = inttoptr i64 %v5499 to ptr
  store i32 1, ptr %p5500, align 4, !alias.scope !3, !noalias !4
  %v5501 = load i64, ptr %slot18, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %ld5503 = load i32, ptr %p5502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5503, ptr %slot930, align 8
  %v5504 = load i32, ptr %slot930, align 8
  %cv5505 = zext i32 %v5504 to i64
  %cond5506 = icmp ne i64 %cv5505, 0
  br i1 %cond5506, label %bb_rcslotdrop1192, label %bb_rcslotdone1192
bb_rcslotdrop1192:
  %v5507 = load i64, ptr %slot18, align 8
  %p5508 = inttoptr i64 %v5507 to ptr
  store i32 0, ptr %p5508, align 4, !alias.scope !3, !noalias !4
  %v5509 = load i64, ptr %slot24, align 8
  store i64 %v5509, ptr %slot931, align 8
  %v5510 = load i64, ptr %slot19, align 8
  %p5511 = inttoptr i64 %v5510 to ptr
  %ld5512 = load i32, ptr %p5511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5512, ptr %slot932, align 8
  %v5513 = load i32, ptr %slot932, align 8
  %op5514 = and i32 %v5513, 28
  store i32 %op5514, ptr %slot933, align 8
  %v5515 = load i32, ptr %slot933, align 8
  %cv5516 = zext i32 %v5515 to i64
  %cond5517 = icmp ne i64 %cv5516, 0
  br i1 %cond5517, label %bb_rcslotrole1192, label %bb_rcslotowner1192
bb_rcslotrole1192:
  %v5518 = load i64, ptr %slot45, align 8
  store i64 %v5518, ptr %slot934, align 8
  %v5519 = load i64, ptr %slot934, align 8
  %v5520 = load i64, ptr %slot931, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5519, i64 %v5520) nomerge, !dbg !168
  br label %bb_rcslotdone1192
bb_rcslotowner1192:
  %v5521 = load i64, ptr %slot931, align 8
  %p5523 = inttoptr i64 %v5521 to ptr
  %gep5524 = getelementptr i8, ptr %p5523, i64 0
  %op5522 = ptrtoint ptr %gep5524 to i64
  store i64 %op5522, ptr %slot935, align 8
  %v5525 = load i64, ptr %slot45, align 8
  store i64 %v5525, ptr %slot936, align 8
  %v5526 = load i64, ptr %slot935, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  %ld5528 = load i64, ptr %p5527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5528, ptr %slot937, align 8
  %v5529 = load i64, ptr %slot937, align 8
  %cmp5530 = icmp ne i64 %v5529, 0
  %cv5531 = zext i1 %cmp5530 to i32
  store i32 %cv5531, ptr %slot938, align 8
  %v5532 = load i32, ptr %slot938, align 8
  %cv5533 = zext i32 %v5532 to i64
  %cond5534 = icmp ne i64 %cv5533, 0
  br i1 %cond5534, label %bb_rcgnn1210, label %bb_rcgdone1210
bb_rcgnn1210:
  %v5535 = load i64, ptr %slot937, align 8
  %op5536 = sub i64 %v5535, 16
  store i64 %op5536, ptr %slot939, align 8
  %v5537 = load i64, ptr %slot937, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  %rgep5539 = getelementptr i8, ptr %p5538, i64 -16
  %ld5540 = load i64, ptr %rgep5539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5540, ptr %slot940, align 8
  %v5541 = load i64, ptr %slot940, align 8
  %op5542 = and i64 %v5541, 4611686018427387906
  store i64 %op5542, ptr %slot941, align 8
  %v5543 = load i64, ptr %slot941, align 8
  %cmp5544 = icmp ne i64 %v5543, 0
  %cv5545 = zext i1 %cmp5544 to i32
  store i32 %cv5545, ptr %slot942, align 8
  %v5546 = load i32, ptr %slot942, align 8
  %cv5547 = zext i32 %v5546 to i64
  %cond5548 = icmp ne i64 %cv5547, 0
  br i1 %cond5548, label %bb_rcgclear1210, label %bb_rcgcounted1210
bb_rcgcounted1210:
  %v5549 = load i64, ptr %slot937, align 8
  %op5550 = sub i64 %v5549, 32
  store i64 %op5550, ptr %slot943, align 8
  %v5551 = load i64, ptr %slot937, align 8
  %p5552 = inttoptr i64 %v5551 to ptr
  %rgep5553 = getelementptr i8, ptr %p5552, i64 -32
  %ld5554 = load i64, ptr %rgep5553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5554, ptr %slot944, align 8
  %v5555 = load i64, ptr %slot944, align 8
  %op5556 = sub i64 %v5555, 1
  store i64 %op5556, ptr %slot945, align 8
  %v5557 = load i64, ptr %slot945, align 8
  %cmp5558 = icmp eq i64 %v5557, 0
  %cv5559 = zext i1 %cmp5558 to i32
  store i32 %cv5559, ptr %slot946, align 8
  %v5560 = load i32, ptr %slot946, align 8
  %cv5561 = zext i32 %v5560 to i64
  %cond5562 = icmp ne i64 %cv5561, 0
  br i1 %cond5562, label %bb_rcglast1210, label %bb_rcgdec1210
bb_rcglast1210:
  %v5563 = load i64, ptr %slot937, align 8
  %op5564 = sub i64 %v5563, 24
  store i64 %op5564, ptr %slot947, align 8
  %v5565 = load i64, ptr %slot937, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %rgep5567 = getelementptr i8, ptr %p5566, i64 -24
  %ld5568 = load i64, ptr %rgep5567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5568, ptr %slot948, align 8
  %v5569 = load i64, ptr %slot948, align 8
  %cmp5570 = icmp ne i64 %v5569, 0
  %cv5571 = zext i1 %cmp5570 to i32
  store i32 %cv5571, ptr %slot949, align 8
  %v5572 = load i32, ptr %slot949, align 8
  %cv5573 = zext i32 %v5572 to i64
  %cond5574 = icmp ne i64 %cv5573, 0
  br i1 %cond5574, label %bb_rcgdec1210, label %bb_rcgslow1210
bb_rcgslow1210:
  %v5575 = load i64, ptr %slot936, align 8
  %v5576 = load i64, ptr %slot935, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5575, i64 %v5576) nomerge, !dbg !168
  br label %bb_rcgdone1210
bb_rcgdec1210:
  %v5577 = load i64, ptr %slot945, align 8
  %v5578 = load i64, ptr %slot937, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %rgep5580 = getelementptr i8, ptr %p5579, i64 -32
  store i64 %v5577, ptr %rgep5580, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1210
bb_rcgclear1210:
  %v5581 = load i64, ptr %slot935, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  store i64 0, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1210
bb_rcgdone1210:
  %v5583 = load i64, ptr %slot931, align 8
  %p5584 = inttoptr i64 %v5583 to ptr
  store i64 0, ptr %p5584, align 8, !alias.scope !3, !noalias !4
  %v5585 = load i64, ptr %slot931, align 8
  %p5587 = inttoptr i64 %v5585 to ptr
  %gep5588 = getelementptr i8, ptr %p5587, i64 8
  %op5586 = ptrtoint ptr %gep5588 to i64
  store i64 %op5586, ptr %slot950, align 8
  %v5589 = load i64, ptr %slot950, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  store i64 0, ptr %p5590, align 8, !alias.scope !3, !noalias !4
  %v5591 = load i64, ptr %slot931, align 8
  %p5593 = inttoptr i64 %v5591 to ptr
  %gep5594 = getelementptr i8, ptr %p5593, i64 16
  %op5592 = ptrtoint ptr %gep5594 to i64
  store i64 %op5592, ptr %slot951, align 8
  %v5595 = load i64, ptr %slot951, align 8
  %p5596 = inttoptr i64 %v5595 to ptr
  store i64 0, ptr %p5596, align 8, !alias.scope !3, !noalias !4
  %v5597 = load i64, ptr %slot931, align 8
  %p5599 = inttoptr i64 %v5597 to ptr
  %gep5600 = getelementptr i8, ptr %p5599, i64 24
  %op5598 = ptrtoint ptr %gep5600 to i64
  store i64 %op5598, ptr %slot952, align 8
  %v5601 = load i64, ptr %slot952, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  store i64 0, ptr %p5602, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1192
bb_rcslotdone1192:
  br label %bb_rcprepared1149
bb_rcprepared1149:
  %v5603 = load i64, ptr %slot12, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %ld5605 = load i32, ptr %p5604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5605, ptr %slot953, align 8
  %v5606 = load i32, ptr %slot953, align 8
  %cv5607 = zext i32 %v5606 to i64
  %cond5608 = icmp ne i64 %cv5607, 0
  br i1 %cond5608, label %bb_rcslotdrop1220, label %bb_rcslotdone1220
bb_rcslotdrop1220:
  %v5609 = load i64, ptr %slot12, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  store i32 0, ptr %p5610, align 4, !alias.scope !3, !noalias !4
  %v5611 = load i64, ptr %slot39, align 8
  store i64 %v5611, ptr %slot954, align 8
  %v5612 = load i64, ptr %slot13, align 8
  %p5613 = inttoptr i64 %v5612 to ptr
  %ld5614 = load i32, ptr %p5613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5614, ptr %slot955, align 8
  %v5615 = load i32, ptr %slot955, align 8
  %op5616 = and i32 %v5615, 28
  store i32 %op5616, ptr %slot956, align 8
  %v5617 = load i32, ptr %slot956, align 8
  %cv5618 = zext i32 %v5617 to i64
  %cond5619 = icmp ne i64 %cv5618, 0
  br i1 %cond5619, label %bb_rcslotrole1220, label %bb_rcslotowner1220
bb_rcslotrole1220:
  %v5620 = load i64, ptr %slot45, align 8
  store i64 %v5620, ptr %slot957, align 8
  %v5621 = load i64, ptr %slot957, align 8
  %v5622 = load i64, ptr %slot954, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5621, i64 %v5622) nomerge, !dbg !168
  br label %bb_rcslotdone1220
bb_rcslotowner1220:
  %v5623 = load i64, ptr %slot954, align 8
  %p5625 = inttoptr i64 %v5623 to ptr
  %gep5626 = getelementptr i8, ptr %p5625, i64 0
  %op5624 = ptrtoint ptr %gep5626 to i64
  store i64 %op5624, ptr %slot958, align 8
  %v5627 = load i64, ptr %slot45, align 8
  store i64 %v5627, ptr %slot959, align 8
  %v5628 = load i64, ptr %slot958, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %ld5630 = load i64, ptr %p5629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5630, ptr %slot960, align 8
  %v5631 = load i64, ptr %slot960, align 8
  %cmp5632 = icmp ne i64 %v5631, 0
  %cv5633 = zext i1 %cmp5632 to i32
  store i32 %cv5633, ptr %slot961, align 8
  %v5634 = load i32, ptr %slot961, align 8
  %cv5635 = zext i32 %v5634 to i64
  %cond5636 = icmp ne i64 %cv5635, 0
  br i1 %cond5636, label %bb_rcgnn1238, label %bb_rcgdone1238
bb_rcgnn1238:
  %v5637 = load i64, ptr %slot960, align 8
  %op5638 = sub i64 %v5637, 16
  store i64 %op5638, ptr %slot962, align 8
  %v5639 = load i64, ptr %slot960, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  %rgep5641 = getelementptr i8, ptr %p5640, i64 -16
  %ld5642 = load i64, ptr %rgep5641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5642, ptr %slot963, align 8
  %v5643 = load i64, ptr %slot963, align 8
  %op5644 = and i64 %v5643, 4611686018427387906
  store i64 %op5644, ptr %slot964, align 8
  %v5645 = load i64, ptr %slot964, align 8
  %cmp5646 = icmp ne i64 %v5645, 0
  %cv5647 = zext i1 %cmp5646 to i32
  store i32 %cv5647, ptr %slot965, align 8
  %v5648 = load i32, ptr %slot965, align 8
  %cv5649 = zext i32 %v5648 to i64
  %cond5650 = icmp ne i64 %cv5649, 0
  br i1 %cond5650, label %bb_rcgclear1238, label %bb_rcgcounted1238
bb_rcgcounted1238:
  %v5651 = load i64, ptr %slot960, align 8
  %op5652 = sub i64 %v5651, 32
  store i64 %op5652, ptr %slot966, align 8
  %v5653 = load i64, ptr %slot960, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %rgep5655 = getelementptr i8, ptr %p5654, i64 -32
  %ld5656 = load i64, ptr %rgep5655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5656, ptr %slot967, align 8
  %v5657 = load i64, ptr %slot967, align 8
  %op5658 = sub i64 %v5657, 1
  store i64 %op5658, ptr %slot968, align 8
  %v5659 = load i64, ptr %slot968, align 8
  %cmp5660 = icmp eq i64 %v5659, 0
  %cv5661 = zext i1 %cmp5660 to i32
  store i32 %cv5661, ptr %slot969, align 8
  %v5662 = load i32, ptr %slot969, align 8
  %cv5663 = zext i32 %v5662 to i64
  %cond5664 = icmp ne i64 %cv5663, 0
  br i1 %cond5664, label %bb_rcglast1238, label %bb_rcgdec1238
bb_rcglast1238:
  %v5665 = load i64, ptr %slot960, align 8
  %op5666 = sub i64 %v5665, 24
  store i64 %op5666, ptr %slot970, align 8
  %v5667 = load i64, ptr %slot960, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  %rgep5669 = getelementptr i8, ptr %p5668, i64 -24
  %ld5670 = load i64, ptr %rgep5669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5670, ptr %slot971, align 8
  %v5671 = load i64, ptr %slot971, align 8
  %cmp5672 = icmp ne i64 %v5671, 0
  %cv5673 = zext i1 %cmp5672 to i32
  store i32 %cv5673, ptr %slot972, align 8
  %v5674 = load i32, ptr %slot972, align 8
  %cv5675 = zext i32 %v5674 to i64
  %cond5676 = icmp ne i64 %cv5675, 0
  br i1 %cond5676, label %bb_rcgdec1238, label %bb_rcgslow1238
bb_rcgslow1238:
  %v5677 = load i64, ptr %slot959, align 8
  %v5678 = load i64, ptr %slot958, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5677, i64 %v5678) nomerge, !dbg !168
  br label %bb_rcgdone1238
bb_rcgdec1238:
  %v5679 = load i64, ptr %slot968, align 8
  %v5680 = load i64, ptr %slot960, align 8
  %p5681 = inttoptr i64 %v5680 to ptr
  %rgep5682 = getelementptr i8, ptr %p5681, i64 -32
  store i64 %v5679, ptr %rgep5682, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1238
bb_rcgclear1238:
  %v5683 = load i64, ptr %slot958, align 8
  %p5684 = inttoptr i64 %v5683 to ptr
  store i64 0, ptr %p5684, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1238
bb_rcgdone1238:
  %v5685 = load i64, ptr %slot954, align 8
  %p5686 = inttoptr i64 %v5685 to ptr
  store i64 0, ptr %p5686, align 8, !alias.scope !3, !noalias !4
  %v5687 = load i64, ptr %slot954, align 8
  %p5689 = inttoptr i64 %v5687 to ptr
  %gep5690 = getelementptr i8, ptr %p5689, i64 8
  %op5688 = ptrtoint ptr %gep5690 to i64
  store i64 %op5688, ptr %slot973, align 8
  %v5691 = load i64, ptr %slot973, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  store i64 0, ptr %p5692, align 8, !alias.scope !3, !noalias !4
  %v5693 = load i64, ptr %slot954, align 8
  %p5695 = inttoptr i64 %v5693 to ptr
  %gep5696 = getelementptr i8, ptr %p5695, i64 16
  %op5694 = ptrtoint ptr %gep5696 to i64
  store i64 %op5694, ptr %slot974, align 8
  %v5697 = load i64, ptr %slot974, align 8
  %p5698 = inttoptr i64 %v5697 to ptr
  store i64 0, ptr %p5698, align 8, !alias.scope !3, !noalias !4
  %v5699 = load i64, ptr %slot954, align 8
  %p5701 = inttoptr i64 %v5699 to ptr
  %gep5702 = getelementptr i8, ptr %p5701, i64 24
  %op5700 = ptrtoint ptr %gep5702 to i64
  store i64 %op5700, ptr %slot975, align 8
  %v5703 = load i64, ptr %slot975, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  store i64 0, ptr %p5704, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1220
bb_rcslotdone1220:
  %v5705 = load i64, ptr %slot39, align 8
  store i64 %v5705, ptr %slot976, align 8
  %v5706 = load i64, ptr %slot28, align 8
  store i64 %v5706, ptr %slot977, align 8
  %v5707 = load i64, ptr %slot977, align 8
  %v5708 = load i64, ptr %slot976, align 8
  %p5709 = inttoptr i64 %v5707 to ptr
  %p5710 = inttoptr i64 %v5708 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5710, ptr %p5709, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot22, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i32 0, ptr %p5712, align 4, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot13, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  store i32 2, ptr %p5714, align 4, !alias.scope !3, !noalias !4
  %v5715 = load i64, ptr %slot23, align 8
  %p5716 = inttoptr i64 %v5715 to ptr
  %ld5717 = load i32, ptr %p5716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5717, ptr %slot978, align 8
  %v5718 = load i32, ptr %slot978, align 8
  %v5719 = load i64, ptr %slot13, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  store i32 %v5718, ptr %p5720, align 4, !alias.scope !3, !noalias !4
  %v5721 = load i64, ptr %slot12, align 8
  %p5722 = inttoptr i64 %v5721 to ptr
  store i32 1, ptr %p5722, align 4, !alias.scope !3, !noalias !4
  %v5723 = load i64, ptr %slot39, align 8
  %v5724 = load i64, ptr %slot42, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  store i64 %v5723, ptr %p5725, align 8, !alias.scope !3, !noalias !4
  %v5726 = load i64, ptr %slot42, align 8
  %p5727 = inttoptr i64 %v5726 to ptr
  %ld5728 = load i64, ptr %p5727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5728, ptr %slot979, align 8
  %v5729 = load i64, ptr %slot18, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  %ld5731 = load i32, ptr %p5730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5731, ptr %slot980, align 8
  %v5732 = load i64, ptr %slot19, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  %ld5734 = load i32, ptr %p5733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5734, ptr %slot981, align 8
  %v5735 = load i32, ptr %slot981, align 8
  %op5736 = and i32 %v5735, 24
  store i32 %op5736, ptr %slot981, align 8
  %v5737 = load i32, ptr %slot981, align 8
  %cmp5738 = icmp eq i32 %v5737, 0
  %cv5739 = zext i1 %cmp5738 to i32
  store i32 %cv5739, ptr %slot982, align 8
  %v5740 = load i32, ptr %slot980, align 8
  %v5741 = load i32, ptr %slot982, align 8
  %op5742 = and i32 %v5740, %v5741
  store i32 %op5742, ptr %slot983, align 8
  %v5743 = load i32, ptr %slot983, align 8
  %cv5744 = zext i32 %v5743 to i64
  %cond5745 = icmp ne i64 %cv5744, 0
  br i1 %cond5745, label %bb_rctake1253, label %bb_rccopy1253
bb_rctake1253:
  %v5746 = load i64, ptr %slot28, align 8
  store i64 %v5746, ptr %slot984, align 8
  %v5747 = load i64, ptr %slot46, align 8
  store i64 %v5747, ptr %slot985, align 8
  %v5748 = load i64, ptr %slot979, align 8
  %v5749 = load i64, ptr %slot984, align 8
  %op5750 = sub i64 %v5748, %v5749
  store i64 %op5750, ptr %slot986, align 8
  %v5751 = load i64, ptr %slot984, align 8
  %v5752 = load i64, ptr %slot979, align 8
  %op5753 = sub i64 %v5751, %v5752
  store i64 %op5753, ptr %slot987, align 8
  %v5754 = load i64, ptr %slot986, align 8
  %cmp5755 = icmp ult i64 %v5754, 32
  %cv5756 = zext i1 %cmp5755 to i32
  store i32 %cv5756, ptr %slot988, align 8
  %v5757 = load i64, ptr %slot987, align 8
  %cmp5758 = icmp ult i64 %v5757, 32
  %cv5759 = zext i1 %cmp5758 to i32
  store i32 %cv5759, ptr %slot989, align 8
  %v5760 = load i32, ptr %slot988, align 8
  %v5761 = load i32, ptr %slot989, align 8
  %op5762 = or i32 %v5760, %v5761
  store i32 %op5762, ptr %slot990, align 8
  %v5763 = load i32, ptr %slot990, align 8
  %cv5764 = zext i32 %v5763 to i64
  %cond5765 = icmp ne i64 %cv5764, 0
  br i1 %cond5765, label %bb_rcmoveslow1262, label %bb_rcmovecheck1262
bb_rcmovecheck1262:
  %v5766 = load i64, ptr %slot979, align 8
  %op5767 = add i64 %v5766, 0
  store i64 %op5767, ptr %slot991, align 8
  %v5768 = load i64, ptr %slot991, align 8
  %p5769 = inttoptr i64 %v5768 to ptr
  %ld5770 = load i64, ptr %p5769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5770, ptr %slot992, align 8
  %v5771 = load i64, ptr %slot992, align 8
  %cmp5772 = icmp ne i64 %v5771, 0
  %cv5773 = zext i1 %cmp5772 to i32
  store i32 %cv5773, ptr %slot993, align 8
  %v5774 = load i32, ptr %slot993, align 8
  %cv5775 = zext i32 %v5774 to i64
  %cond5776 = icmp ne i64 %cv5775, 0
  br i1 %cond5776, label %bb_rcmoveheader1270, label %bb_rcmovenext1270
bb_rcmoveheader1270:
  %v5777 = load i64, ptr %slot992, align 8
  %op5778 = sub i64 %v5777, 16
  store i64 %op5778, ptr %slot994, align 8
  %v5779 = load i64, ptr %slot992, align 8
  %p5780 = inttoptr i64 %v5779 to ptr
  %rgep5781 = getelementptr i8, ptr %p5780, i64 -16
  %ld5782 = load i64, ptr %rgep5781, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5782, ptr %slot995, align 8
  %v5783 = load i64, ptr %slot995, align 8
  %op5784 = and i64 %v5783, 5764607523034234881
  store i64 %op5784, ptr %slot996, align 8
  %v5785 = load i64, ptr %slot996, align 8
  %cmp5786 = icmp ne i64 %v5785, 0
  %cv5787 = zext i1 %cmp5786 to i32
  store i32 %cv5787, ptr %slot997, align 8
  %v5788 = load i32, ptr %slot997, align 8
  %cv5789 = zext i32 %v5788 to i64
  %cond5790 = icmp ne i64 %cv5789, 0
  br i1 %cond5790, label %bb_rcmoveslow1262, label %bb_rcmovenext1270
bb_rcmovenext1270:
  %v5791 = load i64, ptr %slot979, align 8
  %v5792 = load i64, ptr %slot984, align 8
  %p5793 = inttoptr i64 %v5791 to ptr
  %p5794 = inttoptr i64 %v5792 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5794, ptr %p5793, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5795 = load i64, ptr %slot979, align 8
  %p5796 = inttoptr i64 %v5795 to ptr
  store i64 0, ptr %p5796, align 8, !alias.scope !3, !noalias !4
  %v5797 = load i64, ptr %slot979, align 8
  %op5798 = add i64 %v5797, 8
  store i64 %op5798, ptr %slot998, align 8
  %v5799 = load i64, ptr %slot998, align 8
  %p5800 = inttoptr i64 %v5799 to ptr
  store i64 0, ptr %p5800, align 8, !alias.scope !3, !noalias !4
  %v5801 = load i64, ptr %slot979, align 8
  %op5802 = add i64 %v5801, 16
  store i64 %op5802, ptr %slot999, align 8
  %v5803 = load i64, ptr %slot999, align 8
  %p5804 = inttoptr i64 %v5803 to ptr
  store i64 0, ptr %p5804, align 8, !alias.scope !3, !noalias !4
  %v5805 = load i64, ptr %slot979, align 8
  %op5806 = add i64 %v5805, 24
  store i64 %op5806, ptr %slot1000, align 8
  %v5807 = load i64, ptr %slot1000, align 8
  %p5808 = inttoptr i64 %v5807 to ptr
  store i64 0, ptr %p5808, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1262
bb_rcmoveslow1262:
  %v5809 = load i64, ptr %slot45, align 8
  %v5810 = load i64, ptr %slot984, align 8
  %v5811 = load i64, ptr %slot979, align 8
  %v5812 = load i64, ptr %slot985, align 8
  %cv5813 = trunc i64 %v5812 to i32
  %call5814 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v5809, i64 %v5810, i64 %v5811, i32 %cv5813) nomerge, !dbg !170
  store i32 %call5814, ptr %slot1001, align 8
  %v5815 = load i32, ptr %slot1001, align 8
  %cv5816 = zext i32 %v5815 to i64
  %cond5817 = icmp ne i64 %cv5816, 0
  br i1 %cond5817, label %bb_rcsuccess1280, label %bb_rcfailure1280
bb_rcfailure1280:
  %v5818 = load i64, ptr %slot45, align 8
  %p5819 = inttoptr i64 %v5818 to ptr
  %call5820 = call i32 @myl_rc_take_failure(ptr %p5819) nomerge, !dbg !170
  store i32 %call5820, ptr %slot1002, align 8
  %v5821 = load i64, ptr %slot1, align 8
  %p5822 = inttoptr i64 %v5821 to ptr
  %v5823 = load i32, ptr %slot1002, align 8
  %call5824 = call i32 @myl_qbe_rc_status(ptr %p5822, i32 %v5823) nomerge, !dbg !170
  store i32 %call5824, ptr %slot1003, align 8
  br label %bb_failure
bb_rcsuccess1280:
  br label %bb_rcmoved1262
bb_rcmoved1262:
  %v5825 = load i64, ptr %slot18, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  store i32 0, ptr %p5826, align 4, !alias.scope !3, !noalias !4
  %v5827 = load i64, ptr %slot23, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  store i32 2, ptr %p5828, align 4, !alias.scope !3, !noalias !4
  %v5829 = load i64, ptr %slot22, align 8
  %p5830 = inttoptr i64 %v5829 to ptr
  store i32 1, ptr %p5830, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1253
bb_rccopy1253:
  %v5831 = load i64, ptr %slot28, align 8
  store i64 %v5831, ptr %slot1004, align 8
  %v5832 = load i64, ptr %slot46, align 8
  store i64 %v5832, ptr %slot1005, align 8
  %v5833 = load i64, ptr %slot45, align 8
  %v5834 = load i64, ptr %slot1004, align 8
  %v5835 = load i64, ptr %slot979, align 8
  %v5836 = load i64, ptr %slot1005, align 8
  %cv5837 = trunc i64 %v5836 to i32
  %call5838 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v5833, i64 %v5834, i64 %v5835, i32 %cv5837) nomerge, !dbg !170
  store i32 %call5838, ptr %slot1006, align 8
  %v5839 = load i32, ptr %slot1006, align 8
  %cv5840 = zext i32 %v5839 to i64
  %cond5841 = icmp ne i64 %cv5840, 0
  br i1 %cond5841, label %bb_rcsuccess1289, label %bb_rcfailure1289
bb_rcfailure1289:
  %v5842 = load i64, ptr %slot45, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  %call5844 = call i32 @myl_rc_take_failure(ptr %p5843) nomerge, !dbg !170
  store i32 %call5844, ptr %slot1007, align 8
  %v5845 = load i64, ptr %slot1, align 8
  %p5846 = inttoptr i64 %v5845 to ptr
  %v5847 = load i32, ptr %slot1007, align 8
  %call5848 = call i32 @myl_qbe_rc_status(ptr %p5846, i32 %v5847) nomerge, !dbg !170
  store i32 %call5848, ptr %slot1008, align 8
  br label %bb_failure
bb_rcsuccess1289:
  %v5849 = load i64, ptr %slot23, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  store i32 2, ptr %p5850, align 4, !alias.scope !3, !noalias !4
  %v5851 = load i64, ptr %slot22, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  store i32 1, ptr %p5852, align 4, !alias.scope !3, !noalias !4
  %v5853 = load i64, ptr %slot18, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  %ld5855 = load i32, ptr %p5854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5855, ptr %slot1009, align 8
  %v5856 = load i32, ptr %slot1009, align 8
  %cv5857 = zext i32 %v5856 to i64
  %cond5858 = icmp ne i64 %cv5857, 0
  br i1 %cond5858, label %bb_rcslotdrop1296, label %bb_rcslotdone1296
bb_rcslotdrop1296:
  %v5859 = load i64, ptr %slot18, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  store i32 0, ptr %p5860, align 4, !alias.scope !3, !noalias !4
  %v5861 = load i64, ptr %slot24, align 8
  store i64 %v5861, ptr %slot1010, align 8
  %v5862 = load i64, ptr %slot19, align 8
  %p5863 = inttoptr i64 %v5862 to ptr
  %ld5864 = load i32, ptr %p5863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5864, ptr %slot1011, align 8
  %v5865 = load i32, ptr %slot1011, align 8
  %op5866 = and i32 %v5865, 28
  store i32 %op5866, ptr %slot1012, align 8
  %v5867 = load i32, ptr %slot1012, align 8
  %cv5868 = zext i32 %v5867 to i64
  %cond5869 = icmp ne i64 %cv5868, 0
  br i1 %cond5869, label %bb_rcslotrole1296, label %bb_rcslotowner1296
bb_rcslotrole1296:
  %v5870 = load i64, ptr %slot45, align 8
  store i64 %v5870, ptr %slot1013, align 8
  %v5871 = load i64, ptr %slot1013, align 8
  %v5872 = load i64, ptr %slot1010, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5871, i64 %v5872) nomerge, !dbg !170
  br label %bb_rcslotdone1296
bb_rcslotowner1296:
  %v5873 = load i64, ptr %slot1010, align 8
  %p5875 = inttoptr i64 %v5873 to ptr
  %gep5876 = getelementptr i8, ptr %p5875, i64 0
  %op5874 = ptrtoint ptr %gep5876 to i64
  store i64 %op5874, ptr %slot1014, align 8
  %v5877 = load i64, ptr %slot45, align 8
  store i64 %v5877, ptr %slot1015, align 8
  %v5878 = load i64, ptr %slot1014, align 8
  %p5879 = inttoptr i64 %v5878 to ptr
  %ld5880 = load i64, ptr %p5879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5880, ptr %slot1016, align 8
  %v5881 = load i64, ptr %slot1016, align 8
  %cmp5882 = icmp ne i64 %v5881, 0
  %cv5883 = zext i1 %cmp5882 to i32
  store i32 %cv5883, ptr %slot1017, align 8
  %v5884 = load i32, ptr %slot1017, align 8
  %cv5885 = zext i32 %v5884 to i64
  %cond5886 = icmp ne i64 %cv5885, 0
  br i1 %cond5886, label %bb_rcgnn1314, label %bb_rcgdone1314
bb_rcgnn1314:
  %v5887 = load i64, ptr %slot1016, align 8
  %op5888 = sub i64 %v5887, 16
  store i64 %op5888, ptr %slot1018, align 8
  %v5889 = load i64, ptr %slot1016, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %rgep5891 = getelementptr i8, ptr %p5890, i64 -16
  %ld5892 = load i64, ptr %rgep5891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5892, ptr %slot1019, align 8
  %v5893 = load i64, ptr %slot1019, align 8
  %op5894 = and i64 %v5893, 4611686018427387906
  store i64 %op5894, ptr %slot1020, align 8
  %v5895 = load i64, ptr %slot1020, align 8
  %cmp5896 = icmp ne i64 %v5895, 0
  %cv5897 = zext i1 %cmp5896 to i32
  store i32 %cv5897, ptr %slot1021, align 8
  %v5898 = load i32, ptr %slot1021, align 8
  %cv5899 = zext i32 %v5898 to i64
  %cond5900 = icmp ne i64 %cv5899, 0
  br i1 %cond5900, label %bb_rcgclear1314, label %bb_rcgcounted1314
bb_rcgcounted1314:
  %v5901 = load i64, ptr %slot1016, align 8
  %op5902 = sub i64 %v5901, 32
  store i64 %op5902, ptr %slot1022, align 8
  %v5903 = load i64, ptr %slot1016, align 8
  %p5904 = inttoptr i64 %v5903 to ptr
  %rgep5905 = getelementptr i8, ptr %p5904, i64 -32
  %ld5906 = load i64, ptr %rgep5905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5906, ptr %slot1023, align 8
  %v5907 = load i64, ptr %slot1023, align 8
  %op5908 = sub i64 %v5907, 1
  store i64 %op5908, ptr %slot1024, align 8
  %v5909 = load i64, ptr %slot1024, align 8
  %cmp5910 = icmp eq i64 %v5909, 0
  %cv5911 = zext i1 %cmp5910 to i32
  store i32 %cv5911, ptr %slot1025, align 8
  %v5912 = load i32, ptr %slot1025, align 8
  %cv5913 = zext i32 %v5912 to i64
  %cond5914 = icmp ne i64 %cv5913, 0
  br i1 %cond5914, label %bb_rcglast1314, label %bb_rcgdec1314
bb_rcglast1314:
  %v5915 = load i64, ptr %slot1016, align 8
  %op5916 = sub i64 %v5915, 24
  store i64 %op5916, ptr %slot1026, align 8
  %v5917 = load i64, ptr %slot1016, align 8
  %p5918 = inttoptr i64 %v5917 to ptr
  %rgep5919 = getelementptr i8, ptr %p5918, i64 -24
  %ld5920 = load i64, ptr %rgep5919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5920, ptr %slot1027, align 8
  %v5921 = load i64, ptr %slot1027, align 8
  %cmp5922 = icmp ne i64 %v5921, 0
  %cv5923 = zext i1 %cmp5922 to i32
  store i32 %cv5923, ptr %slot1028, align 8
  %v5924 = load i32, ptr %slot1028, align 8
  %cv5925 = zext i32 %v5924 to i64
  %cond5926 = icmp ne i64 %cv5925, 0
  br i1 %cond5926, label %bb_rcgdec1314, label %bb_rcgslow1314
bb_rcgslow1314:
  %v5927 = load i64, ptr %slot1015, align 8
  %v5928 = load i64, ptr %slot1014, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5927, i64 %v5928) nomerge, !dbg !170
  br label %bb_rcgdone1314
bb_rcgdec1314:
  %v5929 = load i64, ptr %slot1024, align 8
  %v5930 = load i64, ptr %slot1016, align 8
  %p5931 = inttoptr i64 %v5930 to ptr
  %rgep5932 = getelementptr i8, ptr %p5931, i64 -32
  store i64 %v5929, ptr %rgep5932, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1314
bb_rcgclear1314:
  %v5933 = load i64, ptr %slot1014, align 8
  %p5934 = inttoptr i64 %v5933 to ptr
  store i64 0, ptr %p5934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1314
bb_rcgdone1314:
  %v5935 = load i64, ptr %slot1010, align 8
  %p5936 = inttoptr i64 %v5935 to ptr
  store i64 0, ptr %p5936, align 8, !alias.scope !3, !noalias !4
  %v5937 = load i64, ptr %slot1010, align 8
  %p5939 = inttoptr i64 %v5937 to ptr
  %gep5940 = getelementptr i8, ptr %p5939, i64 8
  %op5938 = ptrtoint ptr %gep5940 to i64
  store i64 %op5938, ptr %slot1029, align 8
  %v5941 = load i64, ptr %slot1029, align 8
  %p5942 = inttoptr i64 %v5941 to ptr
  store i64 0, ptr %p5942, align 8, !alias.scope !3, !noalias !4
  %v5943 = load i64, ptr %slot1010, align 8
  %p5945 = inttoptr i64 %v5943 to ptr
  %gep5946 = getelementptr i8, ptr %p5945, i64 16
  %op5944 = ptrtoint ptr %gep5946 to i64
  store i64 %op5944, ptr %slot1030, align 8
  %v5947 = load i64, ptr %slot1030, align 8
  %p5948 = inttoptr i64 %v5947 to ptr
  store i64 0, ptr %p5948, align 8, !alias.scope !3, !noalias !4
  %v5949 = load i64, ptr %slot1010, align 8
  %p5951 = inttoptr i64 %v5949 to ptr
  %gep5952 = getelementptr i8, ptr %p5951, i64 24
  %op5950 = ptrtoint ptr %gep5952 to i64
  store i64 %op5950, ptr %slot1031, align 8
  %v5953 = load i64, ptr %slot1031, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  store i64 0, ptr %p5954, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1296
bb_rcslotdone1296:
  br label %bb_rcprepared1253
bb_rcprepared1253:
  %v5955 = load i64, ptr %slot14, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  %ld5957 = load i32, ptr %p5956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5957, ptr %slot1032, align 8
  %v5958 = load i32, ptr %slot1032, align 8
  %cv5959 = zext i32 %v5958 to i64
  %cond5960 = icmp ne i64 %cv5959, 0
  br i1 %cond5960, label %bb_rcslotdrop1324, label %bb_rcslotdone1324
bb_rcslotdrop1324:
  %v5961 = load i64, ptr %slot14, align 8
  %p5962 = inttoptr i64 %v5961 to ptr
  store i32 0, ptr %p5962, align 4, !alias.scope !3, !noalias !4
  %v5963 = load i64, ptr %slot40, align 8
  store i64 %v5963, ptr %slot1033, align 8
  %v5964 = load i64, ptr %slot15, align 8
  %p5965 = inttoptr i64 %v5964 to ptr
  %ld5966 = load i32, ptr %p5965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5966, ptr %slot1034, align 8
  %v5967 = load i32, ptr %slot1034, align 8
  %op5968 = and i32 %v5967, 28
  store i32 %op5968, ptr %slot1035, align 8
  %v5969 = load i32, ptr %slot1035, align 8
  %cv5970 = zext i32 %v5969 to i64
  %cond5971 = icmp ne i64 %cv5970, 0
  br i1 %cond5971, label %bb_rcslotrole1324, label %bb_rcslotowner1324
bb_rcslotrole1324:
  %v5972 = load i64, ptr %slot45, align 8
  store i64 %v5972, ptr %slot1036, align 8
  %v5973 = load i64, ptr %slot1036, align 8
  %v5974 = load i64, ptr %slot1033, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v5973, i64 %v5974) nomerge, !dbg !170
  br label %bb_rcslotdone1324
bb_rcslotowner1324:
  %v5975 = load i64, ptr %slot1033, align 8
  %p5977 = inttoptr i64 %v5975 to ptr
  %gep5978 = getelementptr i8, ptr %p5977, i64 0
  %op5976 = ptrtoint ptr %gep5978 to i64
  store i64 %op5976, ptr %slot1037, align 8
  %v5979 = load i64, ptr %slot45, align 8
  store i64 %v5979, ptr %slot1038, align 8
  %v5980 = load i64, ptr %slot1037, align 8
  %p5981 = inttoptr i64 %v5980 to ptr
  %ld5982 = load i64, ptr %p5981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5982, ptr %slot1039, align 8
  %v5983 = load i64, ptr %slot1039, align 8
  %cmp5984 = icmp ne i64 %v5983, 0
  %cv5985 = zext i1 %cmp5984 to i32
  store i32 %cv5985, ptr %slot1040, align 8
  %v5986 = load i32, ptr %slot1040, align 8
  %cv5987 = zext i32 %v5986 to i64
  %cond5988 = icmp ne i64 %cv5987, 0
  br i1 %cond5988, label %bb_rcgnn1342, label %bb_rcgdone1342
bb_rcgnn1342:
  %v5989 = load i64, ptr %slot1039, align 8
  %op5990 = sub i64 %v5989, 16
  store i64 %op5990, ptr %slot1041, align 8
  %v5991 = load i64, ptr %slot1039, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  %rgep5993 = getelementptr i8, ptr %p5992, i64 -16
  %ld5994 = load i64, ptr %rgep5993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5994, ptr %slot1042, align 8
  %v5995 = load i64, ptr %slot1042, align 8
  %op5996 = and i64 %v5995, 4611686018427387906
  store i64 %op5996, ptr %slot1043, align 8
  %v5997 = load i64, ptr %slot1043, align 8
  %cmp5998 = icmp ne i64 %v5997, 0
  %cv5999 = zext i1 %cmp5998 to i32
  store i32 %cv5999, ptr %slot1044, align 8
  %v6000 = load i32, ptr %slot1044, align 8
  %cv6001 = zext i32 %v6000 to i64
  %cond6002 = icmp ne i64 %cv6001, 0
  br i1 %cond6002, label %bb_rcgclear1342, label %bb_rcgcounted1342
bb_rcgcounted1342:
  %v6003 = load i64, ptr %slot1039, align 8
  %op6004 = sub i64 %v6003, 32
  store i64 %op6004, ptr %slot1045, align 8
  %v6005 = load i64, ptr %slot1039, align 8
  %p6006 = inttoptr i64 %v6005 to ptr
  %rgep6007 = getelementptr i8, ptr %p6006, i64 -32
  %ld6008 = load i64, ptr %rgep6007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6008, ptr %slot1046, align 8
  %v6009 = load i64, ptr %slot1046, align 8
  %op6010 = sub i64 %v6009, 1
  store i64 %op6010, ptr %slot1047, align 8
  %v6011 = load i64, ptr %slot1047, align 8
  %cmp6012 = icmp eq i64 %v6011, 0
  %cv6013 = zext i1 %cmp6012 to i32
  store i32 %cv6013, ptr %slot1048, align 8
  %v6014 = load i32, ptr %slot1048, align 8
  %cv6015 = zext i32 %v6014 to i64
  %cond6016 = icmp ne i64 %cv6015, 0
  br i1 %cond6016, label %bb_rcglast1342, label %bb_rcgdec1342
bb_rcglast1342:
  %v6017 = load i64, ptr %slot1039, align 8
  %op6018 = sub i64 %v6017, 24
  store i64 %op6018, ptr %slot1049, align 8
  %v6019 = load i64, ptr %slot1039, align 8
  %p6020 = inttoptr i64 %v6019 to ptr
  %rgep6021 = getelementptr i8, ptr %p6020, i64 -24
  %ld6022 = load i64, ptr %rgep6021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6022, ptr %slot1050, align 8
  %v6023 = load i64, ptr %slot1050, align 8
  %cmp6024 = icmp ne i64 %v6023, 0
  %cv6025 = zext i1 %cmp6024 to i32
  store i32 %cv6025, ptr %slot1051, align 8
  %v6026 = load i32, ptr %slot1051, align 8
  %cv6027 = zext i32 %v6026 to i64
  %cond6028 = icmp ne i64 %cv6027, 0
  br i1 %cond6028, label %bb_rcgdec1342, label %bb_rcgslow1342
bb_rcgslow1342:
  %v6029 = load i64, ptr %slot1038, align 8
  %v6030 = load i64, ptr %slot1037, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6029, i64 %v6030) nomerge, !dbg !170
  br label %bb_rcgdone1342
bb_rcgdec1342:
  %v6031 = load i64, ptr %slot1047, align 8
  %v6032 = load i64, ptr %slot1039, align 8
  %p6033 = inttoptr i64 %v6032 to ptr
  %rgep6034 = getelementptr i8, ptr %p6033, i64 -32
  store i64 %v6031, ptr %rgep6034, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1342
bb_rcgclear1342:
  %v6035 = load i64, ptr %slot1037, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  store i64 0, ptr %p6036, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1342
bb_rcgdone1342:
  %v6037 = load i64, ptr %slot1033, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  store i64 0, ptr %p6038, align 8, !alias.scope !3, !noalias !4
  %v6039 = load i64, ptr %slot1033, align 8
  %p6041 = inttoptr i64 %v6039 to ptr
  %gep6042 = getelementptr i8, ptr %p6041, i64 8
  %op6040 = ptrtoint ptr %gep6042 to i64
  store i64 %op6040, ptr %slot1052, align 8
  %v6043 = load i64, ptr %slot1052, align 8
  %p6044 = inttoptr i64 %v6043 to ptr
  store i64 0, ptr %p6044, align 8, !alias.scope !3, !noalias !4
  %v6045 = load i64, ptr %slot1033, align 8
  %p6047 = inttoptr i64 %v6045 to ptr
  %gep6048 = getelementptr i8, ptr %p6047, i64 16
  %op6046 = ptrtoint ptr %gep6048 to i64
  store i64 %op6046, ptr %slot1053, align 8
  %v6049 = load i64, ptr %slot1053, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  store i64 0, ptr %p6050, align 8, !alias.scope !3, !noalias !4
  %v6051 = load i64, ptr %slot1033, align 8
  %p6053 = inttoptr i64 %v6051 to ptr
  %gep6054 = getelementptr i8, ptr %p6053, i64 24
  %op6052 = ptrtoint ptr %gep6054 to i64
  store i64 %op6052, ptr %slot1054, align 8
  %v6055 = load i64, ptr %slot1054, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  store i64 0, ptr %p6056, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1324
bb_rcslotdone1324:
  %v6057 = load i64, ptr %slot40, align 8
  store i64 %v6057, ptr %slot1055, align 8
  %v6058 = load i64, ptr %slot28, align 8
  store i64 %v6058, ptr %slot1056, align 8
  %v6059 = load i64, ptr %slot1056, align 8
  %v6060 = load i64, ptr %slot1055, align 8
  %p6061 = inttoptr i64 %v6059 to ptr
  %p6062 = inttoptr i64 %v6060 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6062, ptr %p6061, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v6063 = load i64, ptr %slot22, align 8
  %p6064 = inttoptr i64 %v6063 to ptr
  store i32 0, ptr %p6064, align 4, !alias.scope !3, !noalias !4
  %v6065 = load i64, ptr %slot15, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  store i32 2, ptr %p6066, align 4, !alias.scope !3, !noalias !4
  %v6067 = load i64, ptr %slot23, align 8
  %p6068 = inttoptr i64 %v6067 to ptr
  %ld6069 = load i32, ptr %p6068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6069, ptr %slot1057, align 8
  %v6070 = load i32, ptr %slot1057, align 8
  %v6071 = load i64, ptr %slot15, align 8
  %p6072 = inttoptr i64 %v6071 to ptr
  store i32 %v6070, ptr %p6072, align 4, !alias.scope !3, !noalias !4
  %v6073 = load i64, ptr %slot14, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  store i32 1, ptr %p6074, align 4, !alias.scope !3, !noalias !4
  %v6075 = load i64, ptr %slot40, align 8
  %v6076 = load i64, ptr %slot42, align 8
  %p6077 = inttoptr i64 %v6076 to ptr
  store i64 %v6075, ptr %p6077, align 8, !alias.scope !3, !noalias !4
  %v6078 = load i64, ptr %slot42, align 8
  %p6079 = inttoptr i64 %v6078 to ptr
  %ld6080 = load i64, ptr %p6079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6080, ptr %slot1058, align 8
  %v6081 = load i64, ptr %slot1058, align 8
  %op6082 = add i64 %v6081, 16
  store i64 %op6082, ptr %slot1059, align 8
  %v6083 = load i64, ptr %slot1059, align 8
  %p6084 = inttoptr i64 %v6083 to ptr
  %ld6085 = load i64, ptr %p6084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6085, ptr %slot1060, align 8
  %v6086 = load i64, ptr %slot1060, align 8
  %v6087 = load i64, ptr %slot42, align 8
  %p6088 = inttoptr i64 %v6087 to ptr
  store i64 %v6086, ptr %p6088, align 8, !alias.scope !3, !noalias !4
  %v6089 = load i64, ptr %slot18, align 8
  %p6090 = inttoptr i64 %v6089 to ptr
  %ld6091 = load i32, ptr %p6090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6091, ptr %slot1061, align 8
  %v6092 = load i32, ptr %slot1061, align 8
  %cv6093 = zext i32 %v6092 to i64
  %cond6094 = icmp ne i64 %cv6093, 0
  br i1 %cond6094, label %bb_rcslotdrop1361, label %bb_rcslotdone1361
bb_rcslotdrop1361:
  %v6095 = load i64, ptr %slot18, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  store i32 0, ptr %p6096, align 4, !alias.scope !3, !noalias !4
  %v6097 = load i64, ptr %slot24, align 8
  store i64 %v6097, ptr %slot1062, align 8
  %v6098 = load i64, ptr %slot19, align 8
  %p6099 = inttoptr i64 %v6098 to ptr
  %ld6100 = load i32, ptr %p6099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6100, ptr %slot1063, align 8
  %v6101 = load i32, ptr %slot1063, align 8
  %op6102 = and i32 %v6101, 28
  store i32 %op6102, ptr %slot1064, align 8
  %v6103 = load i32, ptr %slot1064, align 8
  %cv6104 = zext i32 %v6103 to i64
  %cond6105 = icmp ne i64 %cv6104, 0
  br i1 %cond6105, label %bb_rcslotrole1361, label %bb_rcslotowner1361
bb_rcslotrole1361:
  %v6106 = load i64, ptr %slot45, align 8
  store i64 %v6106, ptr %slot1065, align 8
  %v6107 = load i64, ptr %slot1065, align 8
  %v6108 = load i64, ptr %slot1062, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6107, i64 %v6108) nomerge, !dbg !172
  br label %bb_rcslotdone1361
bb_rcslotowner1361:
  %v6109 = load i64, ptr %slot45, align 8
  store i64 %v6109, ptr %slot1066, align 8
  %v6110 = load i64, ptr %slot1066, align 8
  %v6111 = load i64, ptr %slot1062, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6110, i64 %v6111) nomerge, !dbg !172
  br label %bb_rcslotdone1361
bb_rcslotdone1361:
  %v6112 = load i64, ptr %slot40, align 8
  %v6113 = load i64, ptr %slot43, align 8
  %p6114 = inttoptr i64 %v6113 to ptr
  store i64 %v6112, ptr %p6114, align 8, !alias.scope !3, !noalias !4
  %v6115 = load i64, ptr %slot43, align 8
  %p6116 = inttoptr i64 %v6115 to ptr
  %ld6117 = load i64, ptr %p6116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6117, ptr %slot1067, align 8
  %v6118 = load i64, ptr %slot1067, align 8
  %op6119 = add i64 %v6118, 0
  store i64 %op6119, ptr %slot1068, align 8
  %v6120 = load i64, ptr %slot1068, align 8
  %p6121 = inttoptr i64 %v6120 to ptr
  %ld6122 = load i64, ptr %p6121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6122, ptr %slot1069, align 8
  %v6123 = load i64, ptr %slot1069, align 8
  %v6124 = load i64, ptr %slot43, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  store i64 %v6123, ptr %p6125, align 8, !alias.scope !3, !noalias !4
  %v6126 = load i64, ptr %slot43, align 8
  %p6127 = inttoptr i64 %v6126 to ptr
  %ld6128 = load i64, ptr %p6127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6128, ptr %slot1070, align 8
  %v6129 = load i64, ptr %slot1070, align 8
  %v6130 = load i64, ptr %slot27, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  store i64 %v6129, ptr %p6131, align 8, !alias.scope !3, !noalias !4
  %v6132 = load i64, ptr %slot27, align 8
  store i64 %v6132, ptr %slot1071, align 8
  %v6133 = load i64, ptr %slot28, align 8
  store i64 %v6133, ptr %slot1072, align 8
  %v6134 = load i64, ptr %slot1071, align 8
  %p6135 = inttoptr i64 %v6134 to ptr
  %ld6136 = load i64, ptr %p6135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6136, ptr %slot1073, align 8
  %v6137 = load i64, ptr %slot1073, align 8
  %cmp6138 = icmp ne i64 %v6137, 0
  %cv6139 = zext i1 %cmp6138 to i32
  store i32 %cv6139, ptr %slot1074, align 8
  %v6140 = load i32, ptr %slot1074, align 8
  %cv6141 = zext i32 %v6140 to i64
  %cond6142 = icmp ne i64 %cv6141, 0
  br i1 %cond6142, label %bb_rcgnn1375, label %bb_rcgstore1375
bb_rcgnn1375:
  %v6143 = load i64, ptr %slot1073, align 8
  %op6144 = sub i64 %v6143, 16
  store i64 %op6144, ptr %slot1075, align 8
  %v6145 = load i64, ptr %slot1073, align 8
  %p6146 = inttoptr i64 %v6145 to ptr
  %rgep6147 = getelementptr i8, ptr %p6146, i64 -16
  %ld6148 = load i64, ptr %rgep6147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6148, ptr %slot1076, align 8
  %v6149 = load i64, ptr %slot1076, align 8
  %op6150 = and i64 %v6149, 4611686018427387906
  store i64 %op6150, ptr %slot1077, align 8
  %v6151 = load i64, ptr %slot1077, align 8
  %cmp6152 = icmp ne i64 %v6151, 0
  %cv6153 = zext i1 %cmp6152 to i32
  store i32 %cv6153, ptr %slot1078, align 8
  %v6154 = load i32, ptr %slot1078, align 8
  %cv6155 = zext i32 %v6154 to i64
  %cond6156 = icmp ne i64 %cv6155, 0
  br i1 %cond6156, label %bb_rcgstore1375, label %bb_rcginc1375
bb_rcginc1375:
  %v6157 = load i64, ptr %slot1073, align 8
  %op6158 = sub i64 %v6157, 24
  store i64 %op6158, ptr %slot1079, align 8
  %v6159 = load i64, ptr %slot1073, align 8
  %p6160 = inttoptr i64 %v6159 to ptr
  %rgep6161 = getelementptr i8, ptr %p6160, i64 -24
  %ld6162 = load i64, ptr %rgep6161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6162, ptr %slot1080, align 8
  %v6163 = load i64, ptr %slot1080, align 8
  %op6164 = add i64 %v6163, 1
  store i64 %op6164, ptr %slot1081, align 8
  %v6165 = load i64, ptr %slot1081, align 8
  %cmp6166 = icmp eq i64 %v6165, 0
  %cv6167 = zext i1 %cmp6166 to i32
  store i32 %cv6167, ptr %slot1082, align 8
  %v6168 = load i32, ptr %slot1082, align 8
  %cv6169 = zext i32 %v6168 to i64
  %cond6170 = icmp ne i64 %cv6169, 0
  br i1 %cond6170, label %bb_rcglimit1375, label %bb_rcgcapacity1375
bb_rcglimit1375:
  %v6171 = load i64, ptr %slot1, align 8
  %p6172 = inttoptr i64 %v6171 to ptr
  %call6173 = call i32 @myl_qbe_rc_status(ptr %p6172, i32 2) nomerge, !dbg !174
  store i32 %call6173, ptr %slot1083, align 8
  br label %bb_failure
bb_rcgcapacity1375:
  %v6174 = load i64, ptr %slot1081, align 8
  %v6175 = load i64, ptr %slot1073, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  %rgep6177 = getelementptr i8, ptr %p6176, i64 -24
  store i64 %v6174, ptr %rgep6177, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1375
bb_rcgstore1375:
  %v6178 = load i64, ptr %slot1073, align 8
  %v6179 = load i64, ptr %slot1072, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  store i64 %v6178, ptr %p6180, align 8, !alias.scope !3, !noalias !4
  %v6181 = load i64, ptr %slot23, align 8
  %p6182 = inttoptr i64 %v6181 to ptr
  store i32 2, ptr %p6182, align 4, !alias.scope !3, !noalias !4
  %v6183 = load i64, ptr %slot23, align 8
  %p6184 = inttoptr i64 %v6183 to ptr
  store i32 16, ptr %p6184, align 4, !alias.scope !3, !noalias !4
  %v6185 = load i64, ptr %slot22, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  store i32 1, ptr %p6186, align 4, !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot20, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i32, ptr %p6188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6189, ptr %slot1084, align 8
  %v6190 = load i32, ptr %slot1084, align 8
  %cv6191 = zext i32 %v6190 to i64
  %cond6192 = icmp ne i64 %cv6191, 0
  br i1 %cond6192, label %bb_rcslotdrop1391, label %bb_rcslotdone1391
bb_rcslotdrop1391:
  %v6193 = load i64, ptr %slot20, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  store i32 0, ptr %p6194, align 4, !alias.scope !3, !noalias !4
  %v6195 = load i64, ptr %slot25, align 8
  store i64 %v6195, ptr %slot1085, align 8
  %v6196 = load i64, ptr %slot21, align 8
  %p6197 = inttoptr i64 %v6196 to ptr
  %ld6198 = load i32, ptr %p6197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6198, ptr %slot1086, align 8
  %v6199 = load i32, ptr %slot1086, align 8
  %op6200 = and i32 %v6199, 28
  store i32 %op6200, ptr %slot1087, align 8
  %v6201 = load i32, ptr %slot1087, align 8
  %cv6202 = zext i32 %v6201 to i64
  %cond6203 = icmp ne i64 %cv6202, 0
  br i1 %cond6203, label %bb_rcslotrole1391, label %bb_rcslotowner1391
bb_rcslotrole1391:
  %v6204 = load i64, ptr %slot45, align 8
  store i64 %v6204, ptr %slot1088, align 8
  %v6205 = load i64, ptr %slot1088, align 8
  %v6206 = load i64, ptr %slot1085, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6205, i64 %v6206) nomerge, !dbg !174
  br label %bb_rcslotdone1391
bb_rcslotowner1391:
  %v6207 = load i64, ptr %slot45, align 8
  store i64 %v6207, ptr %slot1089, align 8
  %v6208 = load i64, ptr %slot1089, align 8
  %v6209 = load i64, ptr %slot1085, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6208, i64 %v6209) nomerge, !dbg !174
  br label %bb_rcslotdone1391
bb_rcslotdone1391:
  %v6210 = load i64, ptr %slot25, align 8
  store i64 %v6210, ptr %slot1090, align 8
  %v6211 = load i64, ptr %slot28, align 8
  store i64 %v6211, ptr %slot1091, align 8
  %v6212 = load i64, ptr %slot1091, align 8
  %v6213 = load i64, ptr %slot1090, align 8
  %p6214 = inttoptr i64 %v6212 to ptr
  %p6215 = inttoptr i64 %v6213 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6215, ptr %p6214, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6216 = load i64, ptr %slot21, align 8
  %p6217 = inttoptr i64 %v6216 to ptr
  store i32 2, ptr %p6217, align 4, !alias.scope !3, !noalias !4
  %v6218 = load i64, ptr %slot23, align 8
  %p6219 = inttoptr i64 %v6218 to ptr
  %ld6220 = load i32, ptr %p6219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6220, ptr %slot1092, align 8
  %v6221 = load i32, ptr %slot1092, align 8
  %v6222 = load i64, ptr %slot21, align 8
  %p6223 = inttoptr i64 %v6222 to ptr
  store i32 %v6221, ptr %p6223, align 4, !alias.scope !3, !noalias !4
  %v6224 = load i64, ptr %slot22, align 8
  %p6225 = inttoptr i64 %v6224 to ptr
  store i32 0, ptr %p6225, align 4, !alias.scope !3, !noalias !4
  %v6226 = load i64, ptr %slot20, align 8
  %p6227 = inttoptr i64 %v6226 to ptr
  store i32 1, ptr %p6227, align 4, !alias.scope !3, !noalias !4
  %v6228 = load i64, ptr %slot1090, align 8
  %p6229 = inttoptr i64 %v6228 to ptr
  %ld6230 = load i64, ptr %p6229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6230, ptr %slot1093, align 8
  %v6231 = load i64, ptr %slot1093, align 8
  %v6232 = load i64, ptr %slot43, align 8
  %p6233 = inttoptr i64 %v6232 to ptr
  store i64 %v6231, ptr %p6233, align 8, !alias.scope !3, !noalias !4
  %v6234 = load i64, ptr %slot43, align 8
  %p6235 = inttoptr i64 %v6234 to ptr
  %ld6236 = load i64, ptr %p6235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6236, ptr %slot1094, align 8
  %v6237 = load i64, ptr %slot1094, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  %ld6239 = load i64, ptr %p6238, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6239, ptr %slot1095, align 8
  %v6240 = load i64, ptr %slot1095, align 8
  %v6241 = load i64, ptr %slot43, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  store i64 %v6240, ptr %p6242, align 8, !alias.scope !3, !noalias !4
  %v6243 = load i64, ptr %slot20, align 8
  %p6244 = inttoptr i64 %v6243 to ptr
  %ld6245 = load i32, ptr %p6244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6245, ptr %slot1096, align 8
  %v6246 = load i32, ptr %slot1096, align 8
  %cv6247 = zext i32 %v6246 to i64
  %cond6248 = icmp ne i64 %cv6247, 0
  br i1 %cond6248, label %bb_rcslotdrop1411, label %bb_rcslotdone1411
bb_rcslotdrop1411:
  %v6249 = load i64, ptr %slot20, align 8
  %p6250 = inttoptr i64 %v6249 to ptr
  store i32 0, ptr %p6250, align 4, !alias.scope !3, !noalias !4
  %v6251 = load i64, ptr %slot25, align 8
  store i64 %v6251, ptr %slot1097, align 8
  %v6252 = load i64, ptr %slot21, align 8
  %p6253 = inttoptr i64 %v6252 to ptr
  %ld6254 = load i32, ptr %p6253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6254, ptr %slot1098, align 8
  %v6255 = load i32, ptr %slot1098, align 8
  %op6256 = and i32 %v6255, 28
  store i32 %op6256, ptr %slot1099, align 8
  %v6257 = load i32, ptr %slot1099, align 8
  %cv6258 = zext i32 %v6257 to i64
  %cond6259 = icmp ne i64 %cv6258, 0
  br i1 %cond6259, label %bb_rcslotrole1411, label %bb_rcslotowner1411
bb_rcslotrole1411:
  %v6260 = load i64, ptr %slot45, align 8
  store i64 %v6260, ptr %slot1100, align 8
  %v6261 = load i64, ptr %slot1097, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  %ld6263 = load i64, ptr %p6262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6263, ptr %slot1101, align 8
  %v6264 = load i64, ptr %slot1101, align 8
  %cmp6265 = icmp ne i64 %v6264, 0
  %cv6266 = zext i1 %cmp6265 to i32
  store i32 %cv6266, ptr %slot1102, align 8
  %v6267 = load i32, ptr %slot1102, align 8
  %cv6268 = zext i32 %v6267 to i64
  %cond6269 = icmp ne i64 %cv6268, 0
  br i1 %cond6269, label %bb_rcgnn1427, label %bb_rcgdone1427
bb_rcgnn1427:
  %v6270 = load i64, ptr %slot1101, align 8
  %op6271 = sub i64 %v6270, 16
  store i64 %op6271, ptr %slot1103, align 8
  %v6272 = load i64, ptr %slot1101, align 8
  %p6273 = inttoptr i64 %v6272 to ptr
  %rgep6274 = getelementptr i8, ptr %p6273, i64 -16
  %ld6275 = load i64, ptr %rgep6274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6275, ptr %slot1104, align 8
  %v6276 = load i64, ptr %slot1104, align 8
  %op6277 = and i64 %v6276, 4611686018427387906
  store i64 %op6277, ptr %slot1105, align 8
  %v6278 = load i64, ptr %slot1105, align 8
  %cmp6279 = icmp ne i64 %v6278, 0
  %cv6280 = zext i1 %cmp6279 to i32
  store i32 %cv6280, ptr %slot1106, align 8
  %v6281 = load i32, ptr %slot1106, align 8
  %cv6282 = zext i32 %v6281 to i64
  %cond6283 = icmp ne i64 %cv6282, 0
  br i1 %cond6283, label %bb_rcgclear1427, label %bb_rcgcounted1427
bb_rcgcounted1427:
  %v6284 = load i64, ptr %slot1101, align 8
  %op6285 = sub i64 %v6284, 24
  store i64 %op6285, ptr %slot1107, align 8
  %v6286 = load i64, ptr %slot1101, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  %rgep6288 = getelementptr i8, ptr %p6287, i64 -24
  %ld6289 = load i64, ptr %rgep6288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6289, ptr %slot1108, align 8
  %v6290 = load i64, ptr %slot1108, align 8
  %op6291 = sub i64 %v6290, 1
  store i64 %op6291, ptr %slot1109, align 8
  %v6292 = load i64, ptr %slot1109, align 8
  %cmp6293 = icmp eq i64 %v6292, 0
  %cv6294 = zext i1 %cmp6293 to i32
  store i32 %cv6294, ptr %slot1110, align 8
  %v6295 = load i32, ptr %slot1110, align 8
  %cv6296 = zext i32 %v6295 to i64
  %cond6297 = icmp ne i64 %cv6296, 0
  br i1 %cond6297, label %bb_rcglast1427, label %bb_rcgdec1427
bb_rcglast1427:
  %v6298 = load i64, ptr %slot1101, align 8
  %op6299 = sub i64 %v6298, 32
  store i64 %op6299, ptr %slot1111, align 8
  %v6300 = load i64, ptr %slot1101, align 8
  %p6301 = inttoptr i64 %v6300 to ptr
  %rgep6302 = getelementptr i8, ptr %p6301, i64 -32
  %ld6303 = load i64, ptr %rgep6302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6303, ptr %slot1112, align 8
  %v6304 = load i64, ptr %slot1112, align 8
  %cmp6305 = icmp ne i64 %v6304, 0
  %cv6306 = zext i1 %cmp6305 to i32
  store i32 %cv6306, ptr %slot1113, align 8
  %v6307 = load i32, ptr %slot1113, align 8
  %cv6308 = zext i32 %v6307 to i64
  %cond6309 = icmp ne i64 %cv6308, 0
  br i1 %cond6309, label %bb_rcgdec1427, label %bb_rcgslow1427
bb_rcgslow1427:
  %v6310 = load i64, ptr %slot1100, align 8
  %v6311 = load i64, ptr %slot1097, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6310, i64 %v6311) nomerge, !dbg !176
  br label %bb_rcgdone1427
bb_rcgdec1427:
  %v6312 = load i64, ptr %slot1109, align 8
  %v6313 = load i64, ptr %slot1101, align 8
  %p6314 = inttoptr i64 %v6313 to ptr
  %rgep6315 = getelementptr i8, ptr %p6314, i64 -24
  store i64 %v6312, ptr %rgep6315, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1427
bb_rcgclear1427:
  %v6316 = load i64, ptr %slot1097, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  store i64 0, ptr %p6317, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1427
bb_rcgdone1427:
  br label %bb_rcslotdone1411
bb_rcslotowner1411:
  %v6318 = load i64, ptr %slot45, align 8
  store i64 %v6318, ptr %slot1114, align 8
  %v6319 = load i64, ptr %slot1097, align 8
  %p6320 = inttoptr i64 %v6319 to ptr
  %ld6321 = load i64, ptr %p6320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6321, ptr %slot1115, align 8
  %v6322 = load i64, ptr %slot1115, align 8
  %cmp6323 = icmp ne i64 %v6322, 0
  %cv6324 = zext i1 %cmp6323 to i32
  store i32 %cv6324, ptr %slot1116, align 8
  %v6325 = load i32, ptr %slot1116, align 8
  %cv6326 = zext i32 %v6325 to i64
  %cond6327 = icmp ne i64 %cv6326, 0
  br i1 %cond6327, label %bb_rcgnn1442, label %bb_rcgdone1442
bb_rcgnn1442:
  %v6328 = load i64, ptr %slot1115, align 8
  %op6329 = sub i64 %v6328, 16
  store i64 %op6329, ptr %slot1117, align 8
  %v6330 = load i64, ptr %slot1115, align 8
  %p6331 = inttoptr i64 %v6330 to ptr
  %rgep6332 = getelementptr i8, ptr %p6331, i64 -16
  %ld6333 = load i64, ptr %rgep6332, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6333, ptr %slot1118, align 8
  %v6334 = load i64, ptr %slot1118, align 8
  %op6335 = and i64 %v6334, 4611686018427387906
  store i64 %op6335, ptr %slot1119, align 8
  %v6336 = load i64, ptr %slot1119, align 8
  %cmp6337 = icmp ne i64 %v6336, 0
  %cv6338 = zext i1 %cmp6337 to i32
  store i32 %cv6338, ptr %slot1120, align 8
  %v6339 = load i32, ptr %slot1120, align 8
  %cv6340 = zext i32 %v6339 to i64
  %cond6341 = icmp ne i64 %cv6340, 0
  br i1 %cond6341, label %bb_rcgclear1442, label %bb_rcgcounted1442
bb_rcgcounted1442:
  %v6342 = load i64, ptr %slot1115, align 8
  %op6343 = sub i64 %v6342, 32
  store i64 %op6343, ptr %slot1121, align 8
  %v6344 = load i64, ptr %slot1115, align 8
  %p6345 = inttoptr i64 %v6344 to ptr
  %rgep6346 = getelementptr i8, ptr %p6345, i64 -32
  %ld6347 = load i64, ptr %rgep6346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6347, ptr %slot1122, align 8
  %v6348 = load i64, ptr %slot1122, align 8
  %op6349 = sub i64 %v6348, 1
  store i64 %op6349, ptr %slot1123, align 8
  %v6350 = load i64, ptr %slot1123, align 8
  %cmp6351 = icmp eq i64 %v6350, 0
  %cv6352 = zext i1 %cmp6351 to i32
  store i32 %cv6352, ptr %slot1124, align 8
  %v6353 = load i32, ptr %slot1124, align 8
  %cv6354 = zext i32 %v6353 to i64
  %cond6355 = icmp ne i64 %cv6354, 0
  br i1 %cond6355, label %bb_rcglast1442, label %bb_rcgdec1442
bb_rcglast1442:
  %v6356 = load i64, ptr %slot1115, align 8
  %op6357 = sub i64 %v6356, 24
  store i64 %op6357, ptr %slot1125, align 8
  %v6358 = load i64, ptr %slot1115, align 8
  %p6359 = inttoptr i64 %v6358 to ptr
  %rgep6360 = getelementptr i8, ptr %p6359, i64 -24
  %ld6361 = load i64, ptr %rgep6360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6361, ptr %slot1126, align 8
  %v6362 = load i64, ptr %slot1126, align 8
  %cmp6363 = icmp ne i64 %v6362, 0
  %cv6364 = zext i1 %cmp6363 to i32
  store i32 %cv6364, ptr %slot1127, align 8
  %v6365 = load i32, ptr %slot1127, align 8
  %cv6366 = zext i32 %v6365 to i64
  %cond6367 = icmp ne i64 %cv6366, 0
  br i1 %cond6367, label %bb_rcgdec1442, label %bb_rcgslow1442
bb_rcgslow1442:
  %v6368 = load i64, ptr %slot1114, align 8
  %v6369 = load i64, ptr %slot1097, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6368, i64 %v6369) nomerge, !dbg !176
  br label %bb_rcgdone1442
bb_rcgdec1442:
  %v6370 = load i64, ptr %slot1123, align 8
  %v6371 = load i64, ptr %slot1115, align 8
  %p6372 = inttoptr i64 %v6371 to ptr
  %rgep6373 = getelementptr i8, ptr %p6372, i64 -32
  store i64 %v6370, ptr %rgep6373, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1442
bb_rcgclear1442:
  %v6374 = load i64, ptr %slot1097, align 8
  %p6375 = inttoptr i64 %v6374 to ptr
  store i64 0, ptr %p6375, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1442
bb_rcgdone1442:
  br label %bb_rcslotdone1411
bb_rcslotdone1411:
  %v6376 = load i64, ptr %slot43, align 8
  %p6377 = inttoptr i64 %v6376 to ptr
  %ld6378 = load i64, ptr %p6377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6378, ptr %slot1128, align 8
  %v6379 = load i64, ptr %slot42, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  %ld6381 = load i64, ptr %p6380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6381, ptr %slot1129, align 8
  %v6382 = load i64, ptr %slot1129, align 8
  %v6383 = load i64, ptr %slot1128, align 8
  %cmp6384 = icmp sge i64 %v6382, %v6383
  %cv6385 = zext i1 %cmp6384 to i64
  store i64 %cv6385, ptr %slot1130, align 8
  %v6386 = load i64, ptr %slot1130, align 8
  %v6387 = load i64, ptr %slot42, align 8
  %p6388 = inttoptr i64 %v6387 to ptr
  store i64 %v6386, ptr %p6388, align 8, !alias.scope !3, !noalias !4
  br label %bb_i143
bb_i143:
  %v6389 = load i64, ptr %slot42, align 8
  %p6390 = inttoptr i64 %v6389 to ptr
  %ld6391 = load i64, ptr %p6390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6391, ptr %slot1131, align 8
  %v6392 = load i64, ptr %slot1131, align 8
  %cond6393 = icmp ne i64 %v6392, 0
  br i1 %cond6393, label %bb_next1450, label %bb_i146
bb_next1450:
  %v6394 = load i64, ptr %slot42, align 8
  %p6395 = inttoptr i64 %v6394 to ptr
  store i64 0, ptr %p6395, align 8, !alias.scope !3, !noalias !4
  br label %bb_i153
bb_i146:
  %v6396 = load i64, ptr %slot39, align 8
  %v6397 = load i64, ptr %slot42, align 8
  %p6398 = inttoptr i64 %v6397 to ptr
  store i64 %v6396, ptr %p6398, align 8, !alias.scope !3, !noalias !4
  %v6399 = load i64, ptr %slot42, align 8
  %p6400 = inttoptr i64 %v6399 to ptr
  %ld6401 = load i64, ptr %p6400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6401, ptr %slot1132, align 8
  %v6402 = load i64, ptr %slot1132, align 8
  %op6403 = add i64 %v6402, 0
  store i64 %op6403, ptr %slot1133, align 8
  %v6404 = load i64, ptr %slot1133, align 8
  %p6405 = inttoptr i64 %v6404 to ptr
  %ld6406 = load i64, ptr %p6405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6406, ptr %slot1134, align 8
  %v6407 = load i64, ptr %slot1134, align 8
  %v6408 = load i64, ptr %slot42, align 8
  %p6409 = inttoptr i64 %v6408 to ptr
  store i64 %v6407, ptr %p6409, align 8, !alias.scope !3, !noalias !4
  %v6410 = load i64, ptr %slot42, align 8
  %p6411 = inttoptr i64 %v6410 to ptr
  %ld6412 = load i64, ptr %p6411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6412, ptr %slot1135, align 8
  %v6413 = load i64, ptr %slot1135, align 8
  %v6414 = load i64, ptr %slot26, align 8
  %p6415 = inttoptr i64 %v6414 to ptr
  store i64 %v6413, ptr %p6415, align 8, !alias.scope !3, !noalias !4
  %v6416 = load i64, ptr %slot26, align 8
  store i64 %v6416, ptr %slot1136, align 8
  %v6417 = load i64, ptr %slot28, align 8
  store i64 %v6417, ptr %slot1137, align 8
  %v6418 = load i64, ptr %slot1136, align 8
  %p6419 = inttoptr i64 %v6418 to ptr
  %ld6420 = load i64, ptr %p6419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6420, ptr %slot1138, align 8
  %v6421 = load i64, ptr %slot1138, align 8
  %cmp6422 = icmp ne i64 %v6421, 0
  %cv6423 = zext i1 %cmp6422 to i32
  store i32 %cv6423, ptr %slot1139, align 8
  %v6424 = load i32, ptr %slot1139, align 8
  %cv6425 = zext i32 %v6424 to i64
  %cond6426 = icmp ne i64 %cv6425, 0
  br i1 %cond6426, label %bb_rcgnn1457, label %bb_rcgstore1457
bb_rcgnn1457:
  %v6427 = load i64, ptr %slot1138, align 8
  %op6428 = sub i64 %v6427, 16
  store i64 %op6428, ptr %slot1140, align 8
  %v6429 = load i64, ptr %slot1138, align 8
  %p6430 = inttoptr i64 %v6429 to ptr
  %rgep6431 = getelementptr i8, ptr %p6430, i64 -16
  %ld6432 = load i64, ptr %rgep6431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6432, ptr %slot1141, align 8
  %v6433 = load i64, ptr %slot1141, align 8
  %op6434 = and i64 %v6433, 4611686018427387906
  store i64 %op6434, ptr %slot1142, align 8
  %v6435 = load i64, ptr %slot1142, align 8
  %cmp6436 = icmp ne i64 %v6435, 0
  %cv6437 = zext i1 %cmp6436 to i32
  store i32 %cv6437, ptr %slot1143, align 8
  %v6438 = load i32, ptr %slot1143, align 8
  %cv6439 = zext i32 %v6438 to i64
  %cond6440 = icmp ne i64 %cv6439, 0
  br i1 %cond6440, label %bb_rcgstore1457, label %bb_rcginc1457
bb_rcginc1457:
  %v6441 = load i64, ptr %slot1138, align 8
  %op6442 = sub i64 %v6441, 24
  store i64 %op6442, ptr %slot1144, align 8
  %v6443 = load i64, ptr %slot1138, align 8
  %p6444 = inttoptr i64 %v6443 to ptr
  %rgep6445 = getelementptr i8, ptr %p6444, i64 -24
  %ld6446 = load i64, ptr %rgep6445, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6446, ptr %slot1145, align 8
  %v6447 = load i64, ptr %slot1145, align 8
  %op6448 = add i64 %v6447, 1
  store i64 %op6448, ptr %slot1146, align 8
  %v6449 = load i64, ptr %slot1146, align 8
  %cmp6450 = icmp eq i64 %v6449, 0
  %cv6451 = zext i1 %cmp6450 to i32
  store i32 %cv6451, ptr %slot1147, align 8
  %v6452 = load i32, ptr %slot1147, align 8
  %cv6453 = zext i32 %v6452 to i64
  %cond6454 = icmp ne i64 %cv6453, 0
  br i1 %cond6454, label %bb_rcglimit1457, label %bb_rcgcapacity1457
bb_rcglimit1457:
  %v6455 = load i64, ptr %slot1, align 8
  %p6456 = inttoptr i64 %v6455 to ptr
  %call6457 = call i32 @myl_qbe_rc_status(ptr %p6456, i32 2) nomerge, !dbg !178
  store i32 %call6457, ptr %slot1148, align 8
  br label %bb_failure
bb_rcgcapacity1457:
  %v6458 = load i64, ptr %slot1146, align 8
  %v6459 = load i64, ptr %slot1138, align 8
  %p6460 = inttoptr i64 %v6459 to ptr
  %rgep6461 = getelementptr i8, ptr %p6460, i64 -24
  store i64 %v6458, ptr %rgep6461, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1457
bb_rcgstore1457:
  %v6462 = load i64, ptr %slot1138, align 8
  %v6463 = load i64, ptr %slot1137, align 8
  %p6464 = inttoptr i64 %v6463 to ptr
  store i64 %v6462, ptr %p6464, align 8, !alias.scope !3, !noalias !4
  %v6465 = load i64, ptr %slot23, align 8
  %p6466 = inttoptr i64 %v6465 to ptr
  store i32 2, ptr %p6466, align 4, !alias.scope !3, !noalias !4
  %v6467 = load i64, ptr %slot23, align 8
  %p6468 = inttoptr i64 %v6467 to ptr
  store i32 16, ptr %p6468, align 4, !alias.scope !3, !noalias !4
  %v6469 = load i64, ptr %slot22, align 8
  %p6470 = inttoptr i64 %v6469 to ptr
  store i32 1, ptr %p6470, align 4, !alias.scope !3, !noalias !4
  %v6471 = load i64, ptr %slot18, align 8
  %p6472 = inttoptr i64 %v6471 to ptr
  %ld6473 = load i32, ptr %p6472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6473, ptr %slot1149, align 8
  %v6474 = load i32, ptr %slot1149, align 8
  %cv6475 = zext i32 %v6474 to i64
  %cond6476 = icmp ne i64 %cv6475, 0
  br i1 %cond6476, label %bb_rcslotdrop1473, label %bb_rcslotdone1473
bb_rcslotdrop1473:
  %v6477 = load i64, ptr %slot18, align 8
  %p6478 = inttoptr i64 %v6477 to ptr
  store i32 0, ptr %p6478, align 4, !alias.scope !3, !noalias !4
  %v6479 = load i64, ptr %slot24, align 8
  store i64 %v6479, ptr %slot1150, align 8
  %v6480 = load i64, ptr %slot19, align 8
  %p6481 = inttoptr i64 %v6480 to ptr
  %ld6482 = load i32, ptr %p6481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6482, ptr %slot1151, align 8
  %v6483 = load i32, ptr %slot1151, align 8
  %op6484 = and i32 %v6483, 28
  store i32 %op6484, ptr %slot1152, align 8
  %v6485 = load i32, ptr %slot1152, align 8
  %cv6486 = zext i32 %v6485 to i64
  %cond6487 = icmp ne i64 %cv6486, 0
  br i1 %cond6487, label %bb_rcslotrole1473, label %bb_rcslotowner1473
bb_rcslotrole1473:
  %v6488 = load i64, ptr %slot45, align 8
  store i64 %v6488, ptr %slot1153, align 8
  %v6489 = load i64, ptr %slot1153, align 8
  %v6490 = load i64, ptr %slot1150, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6489, i64 %v6490) nomerge, !dbg !178
  br label %bb_rcslotdone1473
bb_rcslotowner1473:
  %v6491 = load i64, ptr %slot45, align 8
  store i64 %v6491, ptr %slot1154, align 8
  %v6492 = load i64, ptr %slot1154, align 8
  %v6493 = load i64, ptr %slot1150, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6492, i64 %v6493) nomerge, !dbg !178
  br label %bb_rcslotdone1473
bb_rcslotdone1473:
  %v6494 = load i64, ptr %slot24, align 8
  store i64 %v6494, ptr %slot1155, align 8
  %v6495 = load i64, ptr %slot28, align 8
  store i64 %v6495, ptr %slot1156, align 8
  %v6496 = load i64, ptr %slot1156, align 8
  %v6497 = load i64, ptr %slot1155, align 8
  %p6498 = inttoptr i64 %v6496 to ptr
  %p6499 = inttoptr i64 %v6497 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6499, ptr %p6498, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6500 = load i64, ptr %slot19, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  store i32 2, ptr %p6501, align 4, !alias.scope !3, !noalias !4
  %v6502 = load i64, ptr %slot23, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  %ld6504 = load i32, ptr %p6503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6504, ptr %slot1157, align 8
  %v6505 = load i32, ptr %slot1157, align 8
  %v6506 = load i64, ptr %slot19, align 8
  %p6507 = inttoptr i64 %v6506 to ptr
  store i32 %v6505, ptr %p6507, align 4, !alias.scope !3, !noalias !4
  %v6508 = load i64, ptr %slot22, align 8
  %p6509 = inttoptr i64 %v6508 to ptr
  store i32 0, ptr %p6509, align 4, !alias.scope !3, !noalias !4
  %v6510 = load i64, ptr %slot18, align 8
  %p6511 = inttoptr i64 %v6510 to ptr
  store i32 1, ptr %p6511, align 4, !alias.scope !3, !noalias !4
  %v6512 = load i64, ptr %slot1155, align 8
  %p6513 = inttoptr i64 %v6512 to ptr
  %ld6514 = load i64, ptr %p6513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6514, ptr %slot1158, align 8
  %v6515 = load i64, ptr %slot1158, align 8
  %v6516 = load i64, ptr %slot42, align 8
  %p6517 = inttoptr i64 %v6516 to ptr
  store i64 %v6515, ptr %p6517, align 8, !alias.scope !3, !noalias !4
  %v6518 = load i64, ptr %slot39, align 8
  %v6519 = load i64, ptr %slot43, align 8
  %p6520 = inttoptr i64 %v6519 to ptr
  store i64 %v6518, ptr %p6520, align 8, !alias.scope !3, !noalias !4
  %v6521 = load i64, ptr %slot43, align 8
  %p6522 = inttoptr i64 %v6521 to ptr
  %ld6523 = load i64, ptr %p6522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6523, ptr %slot1159, align 8
  %v6524 = load i64, ptr %slot1159, align 8
  %op6525 = add i64 %v6524, 16
  store i64 %op6525, ptr %slot1160, align 8
  %v6526 = load i64, ptr %slot1160, align 8
  %p6527 = inttoptr i64 %v6526 to ptr
  %ld6528 = load i64, ptr %p6527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6528, ptr %slot1161, align 8
  %v6529 = load i64, ptr %slot1161, align 8
  %v6530 = load i64, ptr %slot43, align 8
  %p6531 = inttoptr i64 %v6530 to ptr
  store i64 %v6529, ptr %p6531, align 8, !alias.scope !3, !noalias !4
  %v6532 = load i64, ptr %slot20, align 8
  %p6533 = inttoptr i64 %v6532 to ptr
  %ld6534 = load i32, ptr %p6533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6534, ptr %slot1162, align 8
  %v6535 = load i32, ptr %slot1162, align 8
  %cv6536 = zext i32 %v6535 to i64
  %cond6537 = icmp ne i64 %cv6536, 0
  br i1 %cond6537, label %bb_rcslotdrop1494, label %bb_rcslotdone1494
bb_rcslotdrop1494:
  %v6538 = load i64, ptr %slot20, align 8
  %p6539 = inttoptr i64 %v6538 to ptr
  store i32 0, ptr %p6539, align 4, !alias.scope !3, !noalias !4
  %v6540 = load i64, ptr %slot25, align 8
  store i64 %v6540, ptr %slot1163, align 8
  %v6541 = load i64, ptr %slot21, align 8
  %p6542 = inttoptr i64 %v6541 to ptr
  %ld6543 = load i32, ptr %p6542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6543, ptr %slot1164, align 8
  %v6544 = load i32, ptr %slot1164, align 8
  %op6545 = and i32 %v6544, 28
  store i32 %op6545, ptr %slot1165, align 8
  %v6546 = load i32, ptr %slot1165, align 8
  %cv6547 = zext i32 %v6546 to i64
  %cond6548 = icmp ne i64 %cv6547, 0
  br i1 %cond6548, label %bb_rcslotrole1494, label %bb_rcslotowner1494
bb_rcslotrole1494:
  %v6549 = load i64, ptr %slot45, align 8
  store i64 %v6549, ptr %slot1166, align 8
  %v6550 = load i64, ptr %slot1166, align 8
  %v6551 = load i64, ptr %slot1163, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6550, i64 %v6551) nomerge, !dbg !180
  br label %bb_rcslotdone1494
bb_rcslotowner1494:
  %v6552 = load i64, ptr %slot45, align 8
  store i64 %v6552, ptr %slot1167, align 8
  %v6553 = load i64, ptr %slot1167, align 8
  %v6554 = load i64, ptr %slot1163, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v6553, i64 %v6554) nomerge, !dbg !180
  br label %bb_rcslotdone1494
bb_rcslotdone1494:
  %v6555 = load i64, ptr %slot42, align 8
  %p6556 = inttoptr i64 %v6555 to ptr
  %ld6557 = load i64, ptr %p6556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6557, ptr %slot1168, align 8
  %v6558 = load i64, ptr %slot43, align 8
  %p6559 = inttoptr i64 %v6558 to ptr
  %ld6560 = load i64, ptr %p6559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6560, ptr %slot1169, align 8
  %v6561 = load i64, ptr %slot1168, align 8
  %p6562 = inttoptr i64 %v6561 to ptr
  %ld6563 = load i64, ptr %p6562, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6563, ptr %slot1170, align 8
  %v6564 = load i64, ptr %slot1169, align 8
  %op6565 = ashr i64 %v6564, 63
  store i64 %op6565, ptr %slot1171, align 8
  %v6566 = load i64, ptr %slot1171, align 8
  %v6567 = load i64, ptr %slot1170, align 8
  %op6568 = and i64 %v6566, %v6567
  store i64 %op6568, ptr %slot1172, align 8
  %v6569 = load i64, ptr %slot1169, align 8
  %v6570 = load i64, ptr %slot1172, align 8
  %op6571 = add i64 %v6569, %v6570
  store i64 %op6571, ptr %slot1173, align 8
  %v6572 = load i64, ptr %slot1173, align 8
  %v6573 = load i64, ptr %slot1170, align 8
  %cmp6574 = icmp ult i64 %v6572, %v6573
  %cv6575 = zext i1 %cmp6574 to i64
  store i64 %cv6575, ptr %slot1174, align 8
  %v6576 = load i64, ptr %slot1174, align 8
  %cond6577 = icmp ne i64 %v6576, 0
  br i1 %cond6577, label %bb_success1509, label %bb_failed1509
bb_failed1509:
  %v6578 = load i64, ptr %slot1, align 8
  %p6579 = inttoptr i64 %v6578 to ptr
  %v6580 = load i64, ptr %slot1169, align 8
  %v6581 = load i64, ptr %slot1170, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p6579, i64 %v6580, i64 %v6581) nomerge, !dbg !182
  unreachable
bb_success1509:
  %v6582 = load i64, ptr %slot1168, align 8
  %op6583 = add i64 %v6582, 32
  store i64 %op6583, ptr %slot1175, align 8
  %v6584 = load i64, ptr %slot1175, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  %ld6586 = load i64, ptr %p6585, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6586, ptr %slot1176, align 8
  %v6587 = load i64, ptr %slot1176, align 8
  %v6588 = load i64, ptr %slot1173, align 8
  %op6589 = add i64 %v6587, %v6588
  store i64 %op6589, ptr %slot1177, align 8
  %v6590 = load i64, ptr %slot1176, align 8
  %p6591 = inttoptr i64 %v6590 to ptr
  %v6592 = load i64, ptr %slot1173, align 8
  %egep6593 = getelementptr i8, ptr %p6591, i64 %v6592
  %ld6594 = load i8, ptr %egep6593, align 1, !alias.scope !12, !noalias !13
  %ext6595 = zext i8 %ld6594 to i64
  store i64 %ext6595, ptr %slot1178, align 8
  %v6596 = load i64, ptr %slot1178, align 8
  %v6597 = load i64, ptr %slot42, align 8
  %p6598 = inttoptr i64 %v6597 to ptr
  store i64 %v6596, ptr %p6598, align 8, !alias.scope !3, !noalias !4
  %v6599 = load i64, ptr %slot18, align 8
  %p6600 = inttoptr i64 %v6599 to ptr
  %ld6601 = load i32, ptr %p6600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6601, ptr %slot1179, align 8
  %v6602 = load i32, ptr %slot1179, align 8
  %cv6603 = zext i32 %v6602 to i64
  %cond6604 = icmp ne i64 %cv6603, 0
  br i1 %cond6604, label %bb_rcslotdrop1517, label %bb_rcslotdone1517
bb_rcslotdrop1517:
  %v6605 = load i64, ptr %slot18, align 8
  %p6606 = inttoptr i64 %v6605 to ptr
  store i32 0, ptr %p6606, align 4, !alias.scope !3, !noalias !4
  %v6607 = load i64, ptr %slot24, align 8
  store i64 %v6607, ptr %slot1180, align 8
  %v6608 = load i64, ptr %slot19, align 8
  %p6609 = inttoptr i64 %v6608 to ptr
  %ld6610 = load i32, ptr %p6609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6610, ptr %slot1181, align 8
  %v6611 = load i32, ptr %slot1181, align 8
  %op6612 = and i32 %v6611, 28
  store i32 %op6612, ptr %slot1182, align 8
  %v6613 = load i32, ptr %slot1182, align 8
  %cv6614 = zext i32 %v6613 to i64
  %cond6615 = icmp ne i64 %cv6614, 0
  br i1 %cond6615, label %bb_rcslotrole1517, label %bb_rcslotowner1517
bb_rcslotrole1517:
  %v6616 = load i64, ptr %slot45, align 8
  store i64 %v6616, ptr %slot1183, align 8
  %v6617 = load i64, ptr %slot1180, align 8
  %p6618 = inttoptr i64 %v6617 to ptr
  %ld6619 = load i64, ptr %p6618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6619, ptr %slot1184, align 8
  %v6620 = load i64, ptr %slot1184, align 8
  %cmp6621 = icmp ne i64 %v6620, 0
  %cv6622 = zext i1 %cmp6621 to i32
  store i32 %cv6622, ptr %slot1185, align 8
  %v6623 = load i32, ptr %slot1185, align 8
  %cv6624 = zext i32 %v6623 to i64
  %cond6625 = icmp ne i64 %cv6624, 0
  br i1 %cond6625, label %bb_rcgnn1533, label %bb_rcgdone1533
bb_rcgnn1533:
  %v6626 = load i64, ptr %slot1184, align 8
  %op6627 = sub i64 %v6626, 16
  store i64 %op6627, ptr %slot1186, align 8
  %v6628 = load i64, ptr %slot1184, align 8
  %p6629 = inttoptr i64 %v6628 to ptr
  %rgep6630 = getelementptr i8, ptr %p6629, i64 -16
  %ld6631 = load i64, ptr %rgep6630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6631, ptr %slot1187, align 8
  %v6632 = load i64, ptr %slot1187, align 8
  %op6633 = and i64 %v6632, 4611686018427387906
  store i64 %op6633, ptr %slot1188, align 8
  %v6634 = load i64, ptr %slot1188, align 8
  %cmp6635 = icmp ne i64 %v6634, 0
  %cv6636 = zext i1 %cmp6635 to i32
  store i32 %cv6636, ptr %slot1189, align 8
  %v6637 = load i32, ptr %slot1189, align 8
  %cv6638 = zext i32 %v6637 to i64
  %cond6639 = icmp ne i64 %cv6638, 0
  br i1 %cond6639, label %bb_rcgclear1533, label %bb_rcgcounted1533
bb_rcgcounted1533:
  %v6640 = load i64, ptr %slot1184, align 8
  %op6641 = sub i64 %v6640, 24
  store i64 %op6641, ptr %slot1190, align 8
  %v6642 = load i64, ptr %slot1184, align 8
  %p6643 = inttoptr i64 %v6642 to ptr
  %rgep6644 = getelementptr i8, ptr %p6643, i64 -24
  %ld6645 = load i64, ptr %rgep6644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6645, ptr %slot1191, align 8
  %v6646 = load i64, ptr %slot1191, align 8
  %op6647 = sub i64 %v6646, 1
  store i64 %op6647, ptr %slot1192, align 8
  %v6648 = load i64, ptr %slot1192, align 8
  %cmp6649 = icmp eq i64 %v6648, 0
  %cv6650 = zext i1 %cmp6649 to i32
  store i32 %cv6650, ptr %slot1193, align 8
  %v6651 = load i32, ptr %slot1193, align 8
  %cv6652 = zext i32 %v6651 to i64
  %cond6653 = icmp ne i64 %cv6652, 0
  br i1 %cond6653, label %bb_rcglast1533, label %bb_rcgdec1533
bb_rcglast1533:
  %v6654 = load i64, ptr %slot1184, align 8
  %op6655 = sub i64 %v6654, 32
  store i64 %op6655, ptr %slot1194, align 8
  %v6656 = load i64, ptr %slot1184, align 8
  %p6657 = inttoptr i64 %v6656 to ptr
  %rgep6658 = getelementptr i8, ptr %p6657, i64 -32
  %ld6659 = load i64, ptr %rgep6658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6659, ptr %slot1195, align 8
  %v6660 = load i64, ptr %slot1195, align 8
  %cmp6661 = icmp ne i64 %v6660, 0
  %cv6662 = zext i1 %cmp6661 to i32
  store i32 %cv6662, ptr %slot1196, align 8
  %v6663 = load i32, ptr %slot1196, align 8
  %cv6664 = zext i32 %v6663 to i64
  %cond6665 = icmp ne i64 %cv6664, 0
  br i1 %cond6665, label %bb_rcgdec1533, label %bb_rcgslow1533
bb_rcgslow1533:
  %v6666 = load i64, ptr %slot1183, align 8
  %v6667 = load i64, ptr %slot1180, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6666, i64 %v6667) nomerge, !dbg !182
  br label %bb_rcgdone1533
bb_rcgdec1533:
  %v6668 = load i64, ptr %slot1192, align 8
  %v6669 = load i64, ptr %slot1184, align 8
  %p6670 = inttoptr i64 %v6669 to ptr
  %rgep6671 = getelementptr i8, ptr %p6670, i64 -24
  store i64 %v6668, ptr %rgep6671, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1533
bb_rcgclear1533:
  %v6672 = load i64, ptr %slot1180, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  store i64 0, ptr %p6673, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1533
bb_rcgdone1533:
  br label %bb_rcslotdone1517
bb_rcslotowner1517:
  %v6674 = load i64, ptr %slot45, align 8
  store i64 %v6674, ptr %slot1197, align 8
  %v6675 = load i64, ptr %slot1180, align 8
  %p6676 = inttoptr i64 %v6675 to ptr
  %ld6677 = load i64, ptr %p6676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6677, ptr %slot1198, align 8
  %v6678 = load i64, ptr %slot1198, align 8
  %cmp6679 = icmp ne i64 %v6678, 0
  %cv6680 = zext i1 %cmp6679 to i32
  store i32 %cv6680, ptr %slot1199, align 8
  %v6681 = load i32, ptr %slot1199, align 8
  %cv6682 = zext i32 %v6681 to i64
  %cond6683 = icmp ne i64 %cv6682, 0
  br i1 %cond6683, label %bb_rcgnn1548, label %bb_rcgdone1548
bb_rcgnn1548:
  %v6684 = load i64, ptr %slot1198, align 8
  %op6685 = sub i64 %v6684, 16
  store i64 %op6685, ptr %slot1200, align 8
  %v6686 = load i64, ptr %slot1198, align 8
  %p6687 = inttoptr i64 %v6686 to ptr
  %rgep6688 = getelementptr i8, ptr %p6687, i64 -16
  %ld6689 = load i64, ptr %rgep6688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6689, ptr %slot1201, align 8
  %v6690 = load i64, ptr %slot1201, align 8
  %op6691 = and i64 %v6690, 4611686018427387906
  store i64 %op6691, ptr %slot1202, align 8
  %v6692 = load i64, ptr %slot1202, align 8
  %cmp6693 = icmp ne i64 %v6692, 0
  %cv6694 = zext i1 %cmp6693 to i32
  store i32 %cv6694, ptr %slot1203, align 8
  %v6695 = load i32, ptr %slot1203, align 8
  %cv6696 = zext i32 %v6695 to i64
  %cond6697 = icmp ne i64 %cv6696, 0
  br i1 %cond6697, label %bb_rcgclear1548, label %bb_rcgcounted1548
bb_rcgcounted1548:
  %v6698 = load i64, ptr %slot1198, align 8
  %op6699 = sub i64 %v6698, 32
  store i64 %op6699, ptr %slot1204, align 8
  %v6700 = load i64, ptr %slot1198, align 8
  %p6701 = inttoptr i64 %v6700 to ptr
  %rgep6702 = getelementptr i8, ptr %p6701, i64 -32
  %ld6703 = load i64, ptr %rgep6702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6703, ptr %slot1205, align 8
  %v6704 = load i64, ptr %slot1205, align 8
  %op6705 = sub i64 %v6704, 1
  store i64 %op6705, ptr %slot1206, align 8
  %v6706 = load i64, ptr %slot1206, align 8
  %cmp6707 = icmp eq i64 %v6706, 0
  %cv6708 = zext i1 %cmp6707 to i32
  store i32 %cv6708, ptr %slot1207, align 8
  %v6709 = load i32, ptr %slot1207, align 8
  %cv6710 = zext i32 %v6709 to i64
  %cond6711 = icmp ne i64 %cv6710, 0
  br i1 %cond6711, label %bb_rcglast1548, label %bb_rcgdec1548
bb_rcglast1548:
  %v6712 = load i64, ptr %slot1198, align 8
  %op6713 = sub i64 %v6712, 24
  store i64 %op6713, ptr %slot1208, align 8
  %v6714 = load i64, ptr %slot1198, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  %rgep6716 = getelementptr i8, ptr %p6715, i64 -24
  %ld6717 = load i64, ptr %rgep6716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6717, ptr %slot1209, align 8
  %v6718 = load i64, ptr %slot1209, align 8
  %cmp6719 = icmp ne i64 %v6718, 0
  %cv6720 = zext i1 %cmp6719 to i32
  store i32 %cv6720, ptr %slot1210, align 8
  %v6721 = load i32, ptr %slot1210, align 8
  %cv6722 = zext i32 %v6721 to i64
  %cond6723 = icmp ne i64 %cv6722, 0
  br i1 %cond6723, label %bb_rcgdec1548, label %bb_rcgslow1548
bb_rcgslow1548:
  %v6724 = load i64, ptr %slot1197, align 8
  %v6725 = load i64, ptr %slot1180, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6724, i64 %v6725) nomerge, !dbg !182
  br label %bb_rcgdone1548
bb_rcgdec1548:
  %v6726 = load i64, ptr %slot1206, align 8
  %v6727 = load i64, ptr %slot1198, align 8
  %p6728 = inttoptr i64 %v6727 to ptr
  %rgep6729 = getelementptr i8, ptr %p6728, i64 -32
  store i64 %v6726, ptr %rgep6729, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1548
bb_rcgclear1548:
  %v6730 = load i64, ptr %slot1180, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  store i64 0, ptr %p6731, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1548
bb_rcgdone1548:
  br label %bb_rcslotdone1517
bb_rcslotdone1517:
  %v6732 = load i64, ptr %slot42, align 8
  %p6733 = inttoptr i64 %v6732 to ptr
  %ld6734 = load i64, ptr %p6733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6734, ptr %slot1211, align 8
  %v6735 = load i64, ptr %slot1211, align 8
  %v6736 = load i64, ptr %slot42, align 8
  %p6737 = inttoptr i64 %v6736 to ptr
  store i64 %v6735, ptr %p6737, align 8, !alias.scope !3, !noalias !4
  br label %bb_i153
bb_i153:
  %v6738 = load i64, ptr %slot43, align 8
  %p6739 = inttoptr i64 %v6738 to ptr
  store i64 10, ptr %p6739, align 8, !alias.scope !3, !noalias !4
  %v6740 = load i64, ptr %slot43, align 8
  %p6741 = inttoptr i64 %v6740 to ptr
  %ld6742 = load i64, ptr %p6741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6742, ptr %slot1212, align 8
  %v6743 = load i64, ptr %slot42, align 8
  %p6744 = inttoptr i64 %v6743 to ptr
  %ld6745 = load i64, ptr %p6744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6745, ptr %slot1213, align 8
  %v6746 = load i64, ptr %slot1213, align 8
  %v6747 = load i64, ptr %slot1212, align 8
  %cmp6748 = icmp ne i64 %v6746, %v6747
  %cv6749 = zext i1 %cmp6748 to i64
  store i64 %cv6749, ptr %slot1214, align 8
  %v6750 = load i64, ptr %slot1214, align 8
  %v6751 = load i64, ptr %slot42, align 8
  %p6752 = inttoptr i64 %v6751 to ptr
  store i64 %v6750, ptr %p6752, align 8, !alias.scope !3, !noalias !4
  %v6753 = load i64, ptr %slot42, align 8
  %p6754 = inttoptr i64 %v6753 to ptr
  %ld6755 = load i64, ptr %p6754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6755, ptr %slot1215, align 8
  %v6756 = load i64, ptr %slot1215, align 8
  %cond6757 = icmp ne i64 %v6756, 0
  br i1 %cond6757, label %bb_next1557, label %bb_i167
bb_next1557:
  %v6758 = load i64, ptr %slot29, align 8
  %p6759 = inttoptr i64 %v6758 to ptr
  %ld6760 = load i64, ptr %p6759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6760, ptr %slot1216, align 8
  %v6761 = load i64, ptr %slot1216, align 8
  %v6762 = load i64, ptr %slot42, align 8
  %p6763 = inttoptr i64 %v6762 to ptr
  store i64 %v6761, ptr %p6763, align 8, !alias.scope !3, !noalias !4
  %v6764 = load i64, ptr %slot42, align 8
  %p6765 = inttoptr i64 %v6764 to ptr
  %ld6766 = load i64, ptr %p6765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6766, ptr %slot1217, align 8
  %v6767 = load i64, ptr %slot18, align 8
  %p6768 = inttoptr i64 %v6767 to ptr
  %ld6769 = load i32, ptr %p6768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6769, ptr %slot1218, align 8
  %v6770 = load i64, ptr %slot19, align 8
  %p6771 = inttoptr i64 %v6770 to ptr
  %ld6772 = load i32, ptr %p6771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6772, ptr %slot1219, align 8
  %v6773 = load i32, ptr %slot1219, align 8
  %op6774 = and i32 %v6773, 24
  store i32 %op6774, ptr %slot1219, align 8
  %v6775 = load i32, ptr %slot1219, align 8
  %cmp6776 = icmp eq i32 %v6775, 0
  %cv6777 = zext i1 %cmp6776 to i32
  store i32 %cv6777, ptr %slot1220, align 8
  %v6778 = load i32, ptr %slot1218, align 8
  %v6779 = load i32, ptr %slot1220, align 8
  %op6780 = and i32 %v6778, %v6779
  store i32 %op6780, ptr %slot1221, align 8
  %v6781 = load i32, ptr %slot1221, align 8
  %cv6782 = zext i32 %v6781 to i64
  %cond6783 = icmp ne i64 %cv6782, 0
  br i1 %cond6783, label %bb_rctake1559, label %bb_rccopy1559
bb_rctake1559:
  %v6784 = load i64, ptr %slot28, align 8
  store i64 %v6784, ptr %slot1222, align 8
  %v6785 = load i64, ptr %slot46, align 8
  store i64 %v6785, ptr %slot1223, align 8
  %v6786 = load i64, ptr %slot1217, align 8
  %v6787 = load i64, ptr %slot1222, align 8
  %op6788 = sub i64 %v6786, %v6787
  store i64 %op6788, ptr %slot1224, align 8
  %v6789 = load i64, ptr %slot1222, align 8
  %v6790 = load i64, ptr %slot1217, align 8
  %op6791 = sub i64 %v6789, %v6790
  store i64 %op6791, ptr %slot1225, align 8
  %v6792 = load i64, ptr %slot1224, align 8
  %cmp6793 = icmp ult i64 %v6792, 32
  %cv6794 = zext i1 %cmp6793 to i32
  store i32 %cv6794, ptr %slot1226, align 8
  %v6795 = load i64, ptr %slot1225, align 8
  %cmp6796 = icmp ult i64 %v6795, 32
  %cv6797 = zext i1 %cmp6796 to i32
  store i32 %cv6797, ptr %slot1227, align 8
  %v6798 = load i32, ptr %slot1226, align 8
  %v6799 = load i32, ptr %slot1227, align 8
  %op6800 = or i32 %v6798, %v6799
  store i32 %op6800, ptr %slot1228, align 8
  %v6801 = load i32, ptr %slot1228, align 8
  %cv6802 = zext i32 %v6801 to i64
  %cond6803 = icmp ne i64 %cv6802, 0
  br i1 %cond6803, label %bb_rcmoveslow1568, label %bb_rcmovecheck1568
bb_rcmovecheck1568:
  %v6804 = load i64, ptr %slot1217, align 8
  %op6805 = add i64 %v6804, 0
  store i64 %op6805, ptr %slot1229, align 8
  %v6806 = load i64, ptr %slot1229, align 8
  %p6807 = inttoptr i64 %v6806 to ptr
  %ld6808 = load i64, ptr %p6807, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6808, ptr %slot1230, align 8
  %v6809 = load i64, ptr %slot1230, align 8
  %cmp6810 = icmp ne i64 %v6809, 0
  %cv6811 = zext i1 %cmp6810 to i32
  store i32 %cv6811, ptr %slot1231, align 8
  %v6812 = load i32, ptr %slot1231, align 8
  %cv6813 = zext i32 %v6812 to i64
  %cond6814 = icmp ne i64 %cv6813, 0
  br i1 %cond6814, label %bb_rcmoveheader1576, label %bb_rcmovenext1576
bb_rcmoveheader1576:
  %v6815 = load i64, ptr %slot1230, align 8
  %op6816 = sub i64 %v6815, 16
  store i64 %op6816, ptr %slot1232, align 8
  %v6817 = load i64, ptr %slot1230, align 8
  %p6818 = inttoptr i64 %v6817 to ptr
  %rgep6819 = getelementptr i8, ptr %p6818, i64 -16
  %ld6820 = load i64, ptr %rgep6819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6820, ptr %slot1233, align 8
  %v6821 = load i64, ptr %slot1233, align 8
  %op6822 = and i64 %v6821, 5764607523034234881
  store i64 %op6822, ptr %slot1234, align 8
  %v6823 = load i64, ptr %slot1234, align 8
  %cmp6824 = icmp ne i64 %v6823, 0
  %cv6825 = zext i1 %cmp6824 to i32
  store i32 %cv6825, ptr %slot1235, align 8
  %v6826 = load i32, ptr %slot1235, align 8
  %cv6827 = zext i32 %v6826 to i64
  %cond6828 = icmp ne i64 %cv6827, 0
  br i1 %cond6828, label %bb_rcmoveslow1568, label %bb_rcmovenext1576
bb_rcmovenext1576:
  %v6829 = load i64, ptr %slot1217, align 8
  %v6830 = load i64, ptr %slot1222, align 8
  %p6831 = inttoptr i64 %v6829 to ptr
  %p6832 = inttoptr i64 %v6830 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6832, ptr %p6831, i64 32, i1 false), !alias.scope !10000000
  %v6833 = load i64, ptr %slot1217, align 8
  %p6834 = inttoptr i64 %v6833 to ptr
  store i64 0, ptr %p6834, align 8, !alias.scope !4, !noalias !3
  %v6835 = load i64, ptr %slot1217, align 8
  %op6836 = add i64 %v6835, 8
  store i64 %op6836, ptr %slot1236, align 8
  %v6837 = load i64, ptr %slot1236, align 8
  %p6838 = inttoptr i64 %v6837 to ptr
  store i64 0, ptr %p6838, align 8, !alias.scope !4, !noalias !3
  %v6839 = load i64, ptr %slot1217, align 8
  %op6840 = add i64 %v6839, 16
  store i64 %op6840, ptr %slot1237, align 8
  %v6841 = load i64, ptr %slot1237, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  store i64 0, ptr %p6842, align 8, !alias.scope !4, !noalias !3
  %v6843 = load i64, ptr %slot1217, align 8
  %op6844 = add i64 %v6843, 24
  store i64 %op6844, ptr %slot1238, align 8
  %v6845 = load i64, ptr %slot1238, align 8
  %p6846 = inttoptr i64 %v6845 to ptr
  store i64 0, ptr %p6846, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved1568
bb_rcmoveslow1568:
  %v6847 = load i64, ptr %slot45, align 8
  %v6848 = load i64, ptr %slot1222, align 8
  %v6849 = load i64, ptr %slot1217, align 8
  %v6850 = load i64, ptr %slot1223, align 8
  %cv6851 = trunc i64 %v6850 to i32
  %call6852 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v6847, i64 %v6848, i64 %v6849, i32 %cv6851) nomerge, !dbg !184
  store i32 %call6852, ptr %slot1239, align 8
  %v6853 = load i32, ptr %slot1239, align 8
  %cv6854 = zext i32 %v6853 to i64
  %cond6855 = icmp ne i64 %cv6854, 0
  br i1 %cond6855, label %bb_rcsuccess1586, label %bb_rcfailure1586
bb_rcfailure1586:
  %v6856 = load i64, ptr %slot45, align 8
  %p6857 = inttoptr i64 %v6856 to ptr
  %call6858 = call i32 @myl_rc_take_failure(ptr %p6857) nomerge, !dbg !184
  store i32 %call6858, ptr %slot1240, align 8
  %v6859 = load i64, ptr %slot1, align 8
  %p6860 = inttoptr i64 %v6859 to ptr
  %v6861 = load i32, ptr %slot1240, align 8
  %call6862 = call i32 @myl_qbe_rc_status(ptr %p6860, i32 %v6861) nomerge, !dbg !184
  store i32 %call6862, ptr %slot1241, align 8
  br label %bb_failure
bb_rcsuccess1586:
  br label %bb_rcmoved1568
bb_rcmoved1568:
  %v6863 = load i64, ptr %slot18, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  store i32 0, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  %v6865 = load i64, ptr %slot23, align 8
  %p6866 = inttoptr i64 %v6865 to ptr
  store i32 2, ptr %p6866, align 4, !alias.scope !3, !noalias !4
  %v6867 = load i64, ptr %slot22, align 8
  %p6868 = inttoptr i64 %v6867 to ptr
  store i32 1, ptr %p6868, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1559
bb_rccopy1559:
  %v6869 = load i64, ptr %slot28, align 8
  store i64 %v6869, ptr %slot1242, align 8
  %v6870 = load i64, ptr %slot46, align 8
  store i64 %v6870, ptr %slot1243, align 8
  %v6871 = load i64, ptr %slot45, align 8
  %v6872 = load i64, ptr %slot1242, align 8
  %v6873 = load i64, ptr %slot1217, align 8
  %v6874 = load i64, ptr %slot1243, align 8
  %cv6875 = trunc i64 %v6874 to i32
  %call6876 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v6871, i64 %v6872, i64 %v6873, i32 %cv6875) nomerge, !dbg !184
  store i32 %call6876, ptr %slot1244, align 8
  %v6877 = load i32, ptr %slot1244, align 8
  %cv6878 = zext i32 %v6877 to i64
  %cond6879 = icmp ne i64 %cv6878, 0
  br i1 %cond6879, label %bb_rcsuccess1595, label %bb_rcfailure1595
bb_rcfailure1595:
  %v6880 = load i64, ptr %slot45, align 8
  %p6881 = inttoptr i64 %v6880 to ptr
  %call6882 = call i32 @myl_rc_take_failure(ptr %p6881) nomerge, !dbg !184
  store i32 %call6882, ptr %slot1245, align 8
  %v6883 = load i64, ptr %slot1, align 8
  %p6884 = inttoptr i64 %v6883 to ptr
  %v6885 = load i32, ptr %slot1245, align 8
  %call6886 = call i32 @myl_qbe_rc_status(ptr %p6884, i32 %v6885) nomerge, !dbg !184
  store i32 %call6886, ptr %slot1246, align 8
  br label %bb_failure
bb_rcsuccess1595:
  %v6887 = load i64, ptr %slot23, align 8
  %p6888 = inttoptr i64 %v6887 to ptr
  store i32 2, ptr %p6888, align 4, !alias.scope !3, !noalias !4
  %v6889 = load i64, ptr %slot22, align 8
  %p6890 = inttoptr i64 %v6889 to ptr
  store i32 1, ptr %p6890, align 4, !alias.scope !3, !noalias !4
  %v6891 = load i64, ptr %slot18, align 8
  %p6892 = inttoptr i64 %v6891 to ptr
  %ld6893 = load i32, ptr %p6892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6893, ptr %slot1247, align 8
  %v6894 = load i32, ptr %slot1247, align 8
  %cv6895 = zext i32 %v6894 to i64
  %cond6896 = icmp ne i64 %cv6895, 0
  br i1 %cond6896, label %bb_rcslotdrop1602, label %bb_rcslotdone1602
bb_rcslotdrop1602:
  %v6897 = load i64, ptr %slot18, align 8
  %p6898 = inttoptr i64 %v6897 to ptr
  store i32 0, ptr %p6898, align 4, !alias.scope !3, !noalias !4
  %v6899 = load i64, ptr %slot24, align 8
  store i64 %v6899, ptr %slot1248, align 8
  %v6900 = load i64, ptr %slot19, align 8
  %p6901 = inttoptr i64 %v6900 to ptr
  %ld6902 = load i32, ptr %p6901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6902, ptr %slot1249, align 8
  %v6903 = load i32, ptr %slot1249, align 8
  %op6904 = and i32 %v6903, 28
  store i32 %op6904, ptr %slot1250, align 8
  %v6905 = load i32, ptr %slot1250, align 8
  %cv6906 = zext i32 %v6905 to i64
  %cond6907 = icmp ne i64 %cv6906, 0
  br i1 %cond6907, label %bb_rcslotrole1602, label %bb_rcslotowner1602
bb_rcslotrole1602:
  %v6908 = load i64, ptr %slot45, align 8
  store i64 %v6908, ptr %slot1251, align 8
  %v6909 = load i64, ptr %slot1251, align 8
  %v6910 = load i64, ptr %slot1248, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v6909, i64 %v6910) nomerge, !dbg !184
  br label %bb_rcslotdone1602
bb_rcslotowner1602:
  %v6911 = load i64, ptr %slot1248, align 8
  %p6913 = inttoptr i64 %v6911 to ptr
  %gep6914 = getelementptr i8, ptr %p6913, i64 0
  %op6912 = ptrtoint ptr %gep6914 to i64
  store i64 %op6912, ptr %slot1252, align 8
  %v6915 = load i64, ptr %slot45, align 8
  store i64 %v6915, ptr %slot1253, align 8
  %v6916 = load i64, ptr %slot1252, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i64, ptr %p6917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6918, ptr %slot1254, align 8
  %v6919 = load i64, ptr %slot1254, align 8
  %cmp6920 = icmp ne i64 %v6919, 0
  %cv6921 = zext i1 %cmp6920 to i32
  store i32 %cv6921, ptr %slot1255, align 8
  %v6922 = load i32, ptr %slot1255, align 8
  %cv6923 = zext i32 %v6922 to i64
  %cond6924 = icmp ne i64 %cv6923, 0
  br i1 %cond6924, label %bb_rcgnn1620, label %bb_rcgdone1620
bb_rcgnn1620:
  %v6925 = load i64, ptr %slot1254, align 8
  %op6926 = sub i64 %v6925, 16
  store i64 %op6926, ptr %slot1256, align 8
  %v6927 = load i64, ptr %slot1254, align 8
  %p6928 = inttoptr i64 %v6927 to ptr
  %rgep6929 = getelementptr i8, ptr %p6928, i64 -16
  %ld6930 = load i64, ptr %rgep6929, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6930, ptr %slot1257, align 8
  %v6931 = load i64, ptr %slot1257, align 8
  %op6932 = and i64 %v6931, 4611686018427387906
  store i64 %op6932, ptr %slot1258, align 8
  %v6933 = load i64, ptr %slot1258, align 8
  %cmp6934 = icmp ne i64 %v6933, 0
  %cv6935 = zext i1 %cmp6934 to i32
  store i32 %cv6935, ptr %slot1259, align 8
  %v6936 = load i32, ptr %slot1259, align 8
  %cv6937 = zext i32 %v6936 to i64
  %cond6938 = icmp ne i64 %cv6937, 0
  br i1 %cond6938, label %bb_rcgclear1620, label %bb_rcgcounted1620
bb_rcgcounted1620:
  %v6939 = load i64, ptr %slot1254, align 8
  %op6940 = sub i64 %v6939, 32
  store i64 %op6940, ptr %slot1260, align 8
  %v6941 = load i64, ptr %slot1254, align 8
  %p6942 = inttoptr i64 %v6941 to ptr
  %rgep6943 = getelementptr i8, ptr %p6942, i64 -32
  %ld6944 = load i64, ptr %rgep6943, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6944, ptr %slot1261, align 8
  %v6945 = load i64, ptr %slot1261, align 8
  %op6946 = sub i64 %v6945, 1
  store i64 %op6946, ptr %slot1262, align 8
  %v6947 = load i64, ptr %slot1262, align 8
  %cmp6948 = icmp eq i64 %v6947, 0
  %cv6949 = zext i1 %cmp6948 to i32
  store i32 %cv6949, ptr %slot1263, align 8
  %v6950 = load i32, ptr %slot1263, align 8
  %cv6951 = zext i32 %v6950 to i64
  %cond6952 = icmp ne i64 %cv6951, 0
  br i1 %cond6952, label %bb_rcglast1620, label %bb_rcgdec1620
bb_rcglast1620:
  %v6953 = load i64, ptr %slot1254, align 8
  %op6954 = sub i64 %v6953, 24
  store i64 %op6954, ptr %slot1264, align 8
  %v6955 = load i64, ptr %slot1254, align 8
  %p6956 = inttoptr i64 %v6955 to ptr
  %rgep6957 = getelementptr i8, ptr %p6956, i64 -24
  %ld6958 = load i64, ptr %rgep6957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6958, ptr %slot1265, align 8
  %v6959 = load i64, ptr %slot1265, align 8
  %cmp6960 = icmp ne i64 %v6959, 0
  %cv6961 = zext i1 %cmp6960 to i32
  store i32 %cv6961, ptr %slot1266, align 8
  %v6962 = load i32, ptr %slot1266, align 8
  %cv6963 = zext i32 %v6962 to i64
  %cond6964 = icmp ne i64 %cv6963, 0
  br i1 %cond6964, label %bb_rcgdec1620, label %bb_rcgslow1620
bb_rcgslow1620:
  %v6965 = load i64, ptr %slot1253, align 8
  %v6966 = load i64, ptr %slot1252, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6965, i64 %v6966) nomerge, !dbg !184
  br label %bb_rcgdone1620
bb_rcgdec1620:
  %v6967 = load i64, ptr %slot1262, align 8
  %v6968 = load i64, ptr %slot1254, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  %rgep6970 = getelementptr i8, ptr %p6969, i64 -32
  store i64 %v6967, ptr %rgep6970, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1620
bb_rcgclear1620:
  %v6971 = load i64, ptr %slot1252, align 8
  %p6972 = inttoptr i64 %v6971 to ptr
  store i64 0, ptr %p6972, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1620
bb_rcgdone1620:
  %v6973 = load i64, ptr %slot1248, align 8
  %p6974 = inttoptr i64 %v6973 to ptr
  store i64 0, ptr %p6974, align 8, !alias.scope !3, !noalias !4
  %v6975 = load i64, ptr %slot1248, align 8
  %p6977 = inttoptr i64 %v6975 to ptr
  %gep6978 = getelementptr i8, ptr %p6977, i64 8
  %op6976 = ptrtoint ptr %gep6978 to i64
  store i64 %op6976, ptr %slot1267, align 8
  %v6979 = load i64, ptr %slot1267, align 8
  %p6980 = inttoptr i64 %v6979 to ptr
  store i64 0, ptr %p6980, align 8, !alias.scope !3, !noalias !4
  %v6981 = load i64, ptr %slot1248, align 8
  %p6983 = inttoptr i64 %v6981 to ptr
  %gep6984 = getelementptr i8, ptr %p6983, i64 16
  %op6982 = ptrtoint ptr %gep6984 to i64
  store i64 %op6982, ptr %slot1268, align 8
  %v6985 = load i64, ptr %slot1268, align 8
  %p6986 = inttoptr i64 %v6985 to ptr
  store i64 0, ptr %p6986, align 8, !alias.scope !3, !noalias !4
  %v6987 = load i64, ptr %slot1248, align 8
  %p6989 = inttoptr i64 %v6987 to ptr
  %gep6990 = getelementptr i8, ptr %p6989, i64 24
  %op6988 = ptrtoint ptr %gep6990 to i64
  store i64 %op6988, ptr %slot1269, align 8
  %v6991 = load i64, ptr %slot1269, align 8
  %p6992 = inttoptr i64 %v6991 to ptr
  store i64 0, ptr %p6992, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1602
bb_rcslotdone1602:
  br label %bb_rcprepared1559
bb_rcprepared1559:
  %v6993 = load i64, ptr %slot16, align 8
  %p6994 = inttoptr i64 %v6993 to ptr
  %ld6995 = load i32, ptr %p6994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6995, ptr %slot1270, align 8
  %v6996 = load i32, ptr %slot1270, align 8
  %cv6997 = zext i32 %v6996 to i64
  %cond6998 = icmp ne i64 %cv6997, 0
  br i1 %cond6998, label %bb_rcslotdrop1630, label %bb_rcslotdone1630
bb_rcslotdrop1630:
  %v6999 = load i64, ptr %slot16, align 8
  %p7000 = inttoptr i64 %v6999 to ptr
  store i32 0, ptr %p7000, align 4, !alias.scope !3, !noalias !4
  %v7001 = load i64, ptr %slot41, align 8
  store i64 %v7001, ptr %slot1271, align 8
  %v7002 = load i64, ptr %slot17, align 8
  %p7003 = inttoptr i64 %v7002 to ptr
  %ld7004 = load i32, ptr %p7003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7004, ptr %slot1272, align 8
  %v7005 = load i32, ptr %slot1272, align 8
  %op7006 = and i32 %v7005, 28
  store i32 %op7006, ptr %slot1273, align 8
  %v7007 = load i32, ptr %slot1273, align 8
  %cv7008 = zext i32 %v7007 to i64
  %cond7009 = icmp ne i64 %cv7008, 0
  br i1 %cond7009, label %bb_rcslotrole1630, label %bb_rcslotowner1630
bb_rcslotrole1630:
  %v7010 = load i64, ptr %slot45, align 8
  store i64 %v7010, ptr %slot1274, align 8
  %v7011 = load i64, ptr %slot1274, align 8
  %v7012 = load i64, ptr %slot1271, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7011, i64 %v7012) nomerge, !dbg !184
  br label %bb_rcslotdone1630
bb_rcslotowner1630:
  %v7013 = load i64, ptr %slot1271, align 8
  %p7015 = inttoptr i64 %v7013 to ptr
  %gep7016 = getelementptr i8, ptr %p7015, i64 0
  %op7014 = ptrtoint ptr %gep7016 to i64
  store i64 %op7014, ptr %slot1275, align 8
  %v7017 = load i64, ptr %slot45, align 8
  store i64 %v7017, ptr %slot1276, align 8
  %v7018 = load i64, ptr %slot1275, align 8
  %p7019 = inttoptr i64 %v7018 to ptr
  %ld7020 = load i64, ptr %p7019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7020, ptr %slot1277, align 8
  %v7021 = load i64, ptr %slot1277, align 8
  %cmp7022 = icmp ne i64 %v7021, 0
  %cv7023 = zext i1 %cmp7022 to i32
  store i32 %cv7023, ptr %slot1278, align 8
  %v7024 = load i32, ptr %slot1278, align 8
  %cv7025 = zext i32 %v7024 to i64
  %cond7026 = icmp ne i64 %cv7025, 0
  br i1 %cond7026, label %bb_rcgnn1648, label %bb_rcgdone1648
bb_rcgnn1648:
  %v7027 = load i64, ptr %slot1277, align 8
  %op7028 = sub i64 %v7027, 16
  store i64 %op7028, ptr %slot1279, align 8
  %v7029 = load i64, ptr %slot1277, align 8
  %p7030 = inttoptr i64 %v7029 to ptr
  %rgep7031 = getelementptr i8, ptr %p7030, i64 -16
  %ld7032 = load i64, ptr %rgep7031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7032, ptr %slot1280, align 8
  %v7033 = load i64, ptr %slot1280, align 8
  %op7034 = and i64 %v7033, 4611686018427387906
  store i64 %op7034, ptr %slot1281, align 8
  %v7035 = load i64, ptr %slot1281, align 8
  %cmp7036 = icmp ne i64 %v7035, 0
  %cv7037 = zext i1 %cmp7036 to i32
  store i32 %cv7037, ptr %slot1282, align 8
  %v7038 = load i32, ptr %slot1282, align 8
  %cv7039 = zext i32 %v7038 to i64
  %cond7040 = icmp ne i64 %cv7039, 0
  br i1 %cond7040, label %bb_rcgclear1648, label %bb_rcgcounted1648
bb_rcgcounted1648:
  %v7041 = load i64, ptr %slot1277, align 8
  %op7042 = sub i64 %v7041, 32
  store i64 %op7042, ptr %slot1283, align 8
  %v7043 = load i64, ptr %slot1277, align 8
  %p7044 = inttoptr i64 %v7043 to ptr
  %rgep7045 = getelementptr i8, ptr %p7044, i64 -32
  %ld7046 = load i64, ptr %rgep7045, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7046, ptr %slot1284, align 8
  %v7047 = load i64, ptr %slot1284, align 8
  %op7048 = sub i64 %v7047, 1
  store i64 %op7048, ptr %slot1285, align 8
  %v7049 = load i64, ptr %slot1285, align 8
  %cmp7050 = icmp eq i64 %v7049, 0
  %cv7051 = zext i1 %cmp7050 to i32
  store i32 %cv7051, ptr %slot1286, align 8
  %v7052 = load i32, ptr %slot1286, align 8
  %cv7053 = zext i32 %v7052 to i64
  %cond7054 = icmp ne i64 %cv7053, 0
  br i1 %cond7054, label %bb_rcglast1648, label %bb_rcgdec1648
bb_rcglast1648:
  %v7055 = load i64, ptr %slot1277, align 8
  %op7056 = sub i64 %v7055, 24
  store i64 %op7056, ptr %slot1287, align 8
  %v7057 = load i64, ptr %slot1277, align 8
  %p7058 = inttoptr i64 %v7057 to ptr
  %rgep7059 = getelementptr i8, ptr %p7058, i64 -24
  %ld7060 = load i64, ptr %rgep7059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7060, ptr %slot1288, align 8
  %v7061 = load i64, ptr %slot1288, align 8
  %cmp7062 = icmp ne i64 %v7061, 0
  %cv7063 = zext i1 %cmp7062 to i32
  store i32 %cv7063, ptr %slot1289, align 8
  %v7064 = load i32, ptr %slot1289, align 8
  %cv7065 = zext i32 %v7064 to i64
  %cond7066 = icmp ne i64 %cv7065, 0
  br i1 %cond7066, label %bb_rcgdec1648, label %bb_rcgslow1648
bb_rcgslow1648:
  %v7067 = load i64, ptr %slot1276, align 8
  %v7068 = load i64, ptr %slot1275, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7067, i64 %v7068) nomerge, !dbg !184
  br label %bb_rcgdone1648
bb_rcgdec1648:
  %v7069 = load i64, ptr %slot1285, align 8
  %v7070 = load i64, ptr %slot1277, align 8
  %p7071 = inttoptr i64 %v7070 to ptr
  %rgep7072 = getelementptr i8, ptr %p7071, i64 -32
  store i64 %v7069, ptr %rgep7072, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1648
bb_rcgclear1648:
  %v7073 = load i64, ptr %slot1275, align 8
  %p7074 = inttoptr i64 %v7073 to ptr
  store i64 0, ptr %p7074, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1648
bb_rcgdone1648:
  %v7075 = load i64, ptr %slot1271, align 8
  %p7076 = inttoptr i64 %v7075 to ptr
  store i64 0, ptr %p7076, align 8, !alias.scope !3, !noalias !4
  %v7077 = load i64, ptr %slot1271, align 8
  %p7079 = inttoptr i64 %v7077 to ptr
  %gep7080 = getelementptr i8, ptr %p7079, i64 8
  %op7078 = ptrtoint ptr %gep7080 to i64
  store i64 %op7078, ptr %slot1290, align 8
  %v7081 = load i64, ptr %slot1290, align 8
  %p7082 = inttoptr i64 %v7081 to ptr
  store i64 0, ptr %p7082, align 8, !alias.scope !3, !noalias !4
  %v7083 = load i64, ptr %slot1271, align 8
  %p7085 = inttoptr i64 %v7083 to ptr
  %gep7086 = getelementptr i8, ptr %p7085, i64 16
  %op7084 = ptrtoint ptr %gep7086 to i64
  store i64 %op7084, ptr %slot1291, align 8
  %v7087 = load i64, ptr %slot1291, align 8
  %p7088 = inttoptr i64 %v7087 to ptr
  store i64 0, ptr %p7088, align 8, !alias.scope !3, !noalias !4
  %v7089 = load i64, ptr %slot1271, align 8
  %p7091 = inttoptr i64 %v7089 to ptr
  %gep7092 = getelementptr i8, ptr %p7091, i64 24
  %op7090 = ptrtoint ptr %gep7092 to i64
  store i64 %op7090, ptr %slot1292, align 8
  %v7093 = load i64, ptr %slot1292, align 8
  %p7094 = inttoptr i64 %v7093 to ptr
  store i64 0, ptr %p7094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1630
bb_rcslotdone1630:
  %v7095 = load i64, ptr %slot41, align 8
  store i64 %v7095, ptr %slot1293, align 8
  %v7096 = load i64, ptr %slot28, align 8
  store i64 %v7096, ptr %slot1294, align 8
  %v7097 = load i64, ptr %slot1294, align 8
  %v7098 = load i64, ptr %slot1293, align 8
  %p7099 = inttoptr i64 %v7097 to ptr
  %p7100 = inttoptr i64 %v7098 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7100, ptr %p7099, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v7101 = load i64, ptr %slot22, align 8
  %p7102 = inttoptr i64 %v7101 to ptr
  store i32 0, ptr %p7102, align 4, !alias.scope !3, !noalias !4
  %v7103 = load i64, ptr %slot17, align 8
  %p7104 = inttoptr i64 %v7103 to ptr
  store i32 2, ptr %p7104, align 4, !alias.scope !3, !noalias !4
  %v7105 = load i64, ptr %slot23, align 8
  %p7106 = inttoptr i64 %v7105 to ptr
  %ld7107 = load i32, ptr %p7106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7107, ptr %slot1295, align 8
  %v7108 = load i32, ptr %slot1295, align 8
  %v7109 = load i64, ptr %slot17, align 8
  %p7110 = inttoptr i64 %v7109 to ptr
  store i32 %v7108, ptr %p7110, align 4, !alias.scope !3, !noalias !4
  %v7111 = load i64, ptr %slot16, align 8
  %p7112 = inttoptr i64 %v7111 to ptr
  store i32 1, ptr %p7112, align 4, !alias.scope !3, !noalias !4
  %v7113 = load i64, ptr %slot41, align 8
  %v7114 = load i64, ptr %slot42, align 8
  %p7115 = inttoptr i64 %v7114 to ptr
  store i64 %v7113, ptr %p7115, align 8, !alias.scope !3, !noalias !4
  %v7116 = load i64, ptr %slot42, align 8
  %p7117 = inttoptr i64 %v7116 to ptr
  %ld7118 = load i64, ptr %p7117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7118, ptr %slot1296, align 8
  %v7119 = load i64, ptr %slot1296, align 8
  %op7120 = add i64 %v7119, 16
  store i64 %op7120, ptr %slot1297, align 8
  %v7121 = load i64, ptr %slot1297, align 8
  %p7122 = inttoptr i64 %v7121 to ptr
  %ld7123 = load i64, ptr %p7122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7123, ptr %slot1298, align 8
  %v7124 = load i64, ptr %slot1298, align 8
  %v7125 = load i64, ptr %slot42, align 8
  %p7126 = inttoptr i64 %v7125 to ptr
  store i64 %v7124, ptr %p7126, align 8, !alias.scope !3, !noalias !4
  %v7127 = load i64, ptr %slot18, align 8
  %p7128 = inttoptr i64 %v7127 to ptr
  %ld7129 = load i32, ptr %p7128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7129, ptr %slot1299, align 8
  %v7130 = load i32, ptr %slot1299, align 8
  %cv7131 = zext i32 %v7130 to i64
  %cond7132 = icmp ne i64 %cv7131, 0
  br i1 %cond7132, label %bb_rcslotdrop1667, label %bb_rcslotdone1667
bb_rcslotdrop1667:
  %v7133 = load i64, ptr %slot18, align 8
  %p7134 = inttoptr i64 %v7133 to ptr
  store i32 0, ptr %p7134, align 4, !alias.scope !3, !noalias !4
  %v7135 = load i64, ptr %slot24, align 8
  store i64 %v7135, ptr %slot1300, align 8
  %v7136 = load i64, ptr %slot19, align 8
  %p7137 = inttoptr i64 %v7136 to ptr
  %ld7138 = load i32, ptr %p7137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7138, ptr %slot1301, align 8
  %v7139 = load i32, ptr %slot1301, align 8
  %op7140 = and i32 %v7139, 28
  store i32 %op7140, ptr %slot1302, align 8
  %v7141 = load i32, ptr %slot1302, align 8
  %cv7142 = zext i32 %v7141 to i64
  %cond7143 = icmp ne i64 %cv7142, 0
  br i1 %cond7143, label %bb_rcslotrole1667, label %bb_rcslotowner1667
bb_rcslotrole1667:
  %v7144 = load i64, ptr %slot45, align 8
  store i64 %v7144, ptr %slot1303, align 8
  %v7145 = load i64, ptr %slot1303, align 8
  %v7146 = load i64, ptr %slot1300, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7145, i64 %v7146) nomerge, !dbg !186
  br label %bb_rcslotdone1667
bb_rcslotowner1667:
  %v7147 = load i64, ptr %slot45, align 8
  store i64 %v7147, ptr %slot1304, align 8
  %v7148 = load i64, ptr %slot1304, align 8
  %v7149 = load i64, ptr %slot1300, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7148, i64 %v7149) nomerge, !dbg !186
  br label %bb_rcslotdone1667
bb_rcslotdone1667:
  %v7150 = load i64, ptr %slot41, align 8
  %v7151 = load i64, ptr %slot43, align 8
  %p7152 = inttoptr i64 %v7151 to ptr
  store i64 %v7150, ptr %p7152, align 8, !alias.scope !3, !noalias !4
  %v7153 = load i64, ptr %slot43, align 8
  %p7154 = inttoptr i64 %v7153 to ptr
  %ld7155 = load i64, ptr %p7154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7155, ptr %slot1305, align 8
  %v7156 = load i64, ptr %slot1305, align 8
  %op7157 = add i64 %v7156, 0
  store i64 %op7157, ptr %slot1306, align 8
  %v7158 = load i64, ptr %slot1306, align 8
  %p7159 = inttoptr i64 %v7158 to ptr
  %ld7160 = load i64, ptr %p7159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7160, ptr %slot1307, align 8
  %v7161 = load i64, ptr %slot1307, align 8
  %v7162 = load i64, ptr %slot43, align 8
  %p7163 = inttoptr i64 %v7162 to ptr
  store i64 %v7161, ptr %p7163, align 8, !alias.scope !3, !noalias !4
  %v7164 = load i64, ptr %slot43, align 8
  %p7165 = inttoptr i64 %v7164 to ptr
  %ld7166 = load i64, ptr %p7165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7166, ptr %slot1308, align 8
  %v7167 = load i64, ptr %slot1308, align 8
  %v7168 = load i64, ptr %slot27, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  store i64 %v7167, ptr %p7169, align 8, !alias.scope !3, !noalias !4
  %v7170 = load i64, ptr %slot27, align 8
  store i64 %v7170, ptr %slot1309, align 8
  %v7171 = load i64, ptr %slot28, align 8
  store i64 %v7171, ptr %slot1310, align 8
  %v7172 = load i64, ptr %slot1309, align 8
  %p7173 = inttoptr i64 %v7172 to ptr
  %ld7174 = load i64, ptr %p7173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7174, ptr %slot1311, align 8
  %v7175 = load i64, ptr %slot1311, align 8
  %cmp7176 = icmp ne i64 %v7175, 0
  %cv7177 = zext i1 %cmp7176 to i32
  store i32 %cv7177, ptr %slot1312, align 8
  %v7178 = load i32, ptr %slot1312, align 8
  %cv7179 = zext i32 %v7178 to i64
  %cond7180 = icmp ne i64 %cv7179, 0
  br i1 %cond7180, label %bb_rcgnn1681, label %bb_rcgstore1681
bb_rcgnn1681:
  %v7181 = load i64, ptr %slot1311, align 8
  %op7182 = sub i64 %v7181, 16
  store i64 %op7182, ptr %slot1313, align 8
  %v7183 = load i64, ptr %slot1311, align 8
  %p7184 = inttoptr i64 %v7183 to ptr
  %rgep7185 = getelementptr i8, ptr %p7184, i64 -16
  %ld7186 = load i64, ptr %rgep7185, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7186, ptr %slot1314, align 8
  %v7187 = load i64, ptr %slot1314, align 8
  %op7188 = and i64 %v7187, 4611686018427387906
  store i64 %op7188, ptr %slot1315, align 8
  %v7189 = load i64, ptr %slot1315, align 8
  %cmp7190 = icmp ne i64 %v7189, 0
  %cv7191 = zext i1 %cmp7190 to i32
  store i32 %cv7191, ptr %slot1316, align 8
  %v7192 = load i32, ptr %slot1316, align 8
  %cv7193 = zext i32 %v7192 to i64
  %cond7194 = icmp ne i64 %cv7193, 0
  br i1 %cond7194, label %bb_rcgstore1681, label %bb_rcginc1681
bb_rcginc1681:
  %v7195 = load i64, ptr %slot1311, align 8
  %op7196 = sub i64 %v7195, 24
  store i64 %op7196, ptr %slot1317, align 8
  %v7197 = load i64, ptr %slot1311, align 8
  %p7198 = inttoptr i64 %v7197 to ptr
  %rgep7199 = getelementptr i8, ptr %p7198, i64 -24
  %ld7200 = load i64, ptr %rgep7199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7200, ptr %slot1318, align 8
  %v7201 = load i64, ptr %slot1318, align 8
  %op7202 = add i64 %v7201, 1
  store i64 %op7202, ptr %slot1319, align 8
  %v7203 = load i64, ptr %slot1319, align 8
  %cmp7204 = icmp eq i64 %v7203, 0
  %cv7205 = zext i1 %cmp7204 to i32
  store i32 %cv7205, ptr %slot1320, align 8
  %v7206 = load i32, ptr %slot1320, align 8
  %cv7207 = zext i32 %v7206 to i64
  %cond7208 = icmp ne i64 %cv7207, 0
  br i1 %cond7208, label %bb_rcglimit1681, label %bb_rcgcapacity1681
bb_rcglimit1681:
  %v7209 = load i64, ptr %slot1, align 8
  %p7210 = inttoptr i64 %v7209 to ptr
  %call7211 = call i32 @myl_qbe_rc_status(ptr %p7210, i32 2) nomerge, !dbg !188
  store i32 %call7211, ptr %slot1321, align 8
  br label %bb_failure
bb_rcgcapacity1681:
  %v7212 = load i64, ptr %slot1319, align 8
  %v7213 = load i64, ptr %slot1311, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  %rgep7215 = getelementptr i8, ptr %p7214, i64 -24
  store i64 %v7212, ptr %rgep7215, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1681
bb_rcgstore1681:
  %v7216 = load i64, ptr %slot1311, align 8
  %v7217 = load i64, ptr %slot1310, align 8
  %p7218 = inttoptr i64 %v7217 to ptr
  store i64 %v7216, ptr %p7218, align 8, !alias.scope !3, !noalias !4
  %v7219 = load i64, ptr %slot23, align 8
  %p7220 = inttoptr i64 %v7219 to ptr
  store i32 2, ptr %p7220, align 4, !alias.scope !3, !noalias !4
  %v7221 = load i64, ptr %slot23, align 8
  %p7222 = inttoptr i64 %v7221 to ptr
  store i32 16, ptr %p7222, align 4, !alias.scope !3, !noalias !4
  %v7223 = load i64, ptr %slot22, align 8
  %p7224 = inttoptr i64 %v7223 to ptr
  store i32 1, ptr %p7224, align 4, !alias.scope !3, !noalias !4
  %v7225 = load i64, ptr %slot20, align 8
  %p7226 = inttoptr i64 %v7225 to ptr
  %ld7227 = load i32, ptr %p7226, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7227, ptr %slot1322, align 8
  %v7228 = load i32, ptr %slot1322, align 8
  %cv7229 = zext i32 %v7228 to i64
  %cond7230 = icmp ne i64 %cv7229, 0
  br i1 %cond7230, label %bb_rcslotdrop1697, label %bb_rcslotdone1697
bb_rcslotdrop1697:
  %v7231 = load i64, ptr %slot20, align 8
  %p7232 = inttoptr i64 %v7231 to ptr
  store i32 0, ptr %p7232, align 4, !alias.scope !3, !noalias !4
  %v7233 = load i64, ptr %slot25, align 8
  store i64 %v7233, ptr %slot1323, align 8
  %v7234 = load i64, ptr %slot21, align 8
  %p7235 = inttoptr i64 %v7234 to ptr
  %ld7236 = load i32, ptr %p7235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7236, ptr %slot1324, align 8
  %v7237 = load i32, ptr %slot1324, align 8
  %op7238 = and i32 %v7237, 28
  store i32 %op7238, ptr %slot1325, align 8
  %v7239 = load i32, ptr %slot1325, align 8
  %cv7240 = zext i32 %v7239 to i64
  %cond7241 = icmp ne i64 %cv7240, 0
  br i1 %cond7241, label %bb_rcslotrole1697, label %bb_rcslotowner1697
bb_rcslotrole1697:
  %v7242 = load i64, ptr %slot45, align 8
  store i64 %v7242, ptr %slot1326, align 8
  %v7243 = load i64, ptr %slot1326, align 8
  %v7244 = load i64, ptr %slot1323, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7243, i64 %v7244) nomerge, !dbg !188
  br label %bb_rcslotdone1697
bb_rcslotowner1697:
  %v7245 = load i64, ptr %slot45, align 8
  store i64 %v7245, ptr %slot1327, align 8
  %v7246 = load i64, ptr %slot1327, align 8
  %v7247 = load i64, ptr %slot1323, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7246, i64 %v7247) nomerge, !dbg !188
  br label %bb_rcslotdone1697
bb_rcslotdone1697:
  %v7248 = load i64, ptr %slot25, align 8
  store i64 %v7248, ptr %slot1328, align 8
  %v7249 = load i64, ptr %slot28, align 8
  store i64 %v7249, ptr %slot1329, align 8
  %v7250 = load i64, ptr %slot1329, align 8
  %v7251 = load i64, ptr %slot1328, align 8
  %p7252 = inttoptr i64 %v7250 to ptr
  %p7253 = inttoptr i64 %v7251 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7253, ptr %p7252, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7254 = load i64, ptr %slot21, align 8
  %p7255 = inttoptr i64 %v7254 to ptr
  store i32 2, ptr %p7255, align 4, !alias.scope !3, !noalias !4
  %v7256 = load i64, ptr %slot23, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  %ld7258 = load i32, ptr %p7257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7258, ptr %slot1330, align 8
  %v7259 = load i32, ptr %slot1330, align 8
  %v7260 = load i64, ptr %slot21, align 8
  %p7261 = inttoptr i64 %v7260 to ptr
  store i32 %v7259, ptr %p7261, align 4, !alias.scope !3, !noalias !4
  %v7262 = load i64, ptr %slot22, align 8
  %p7263 = inttoptr i64 %v7262 to ptr
  store i32 0, ptr %p7263, align 4, !alias.scope !3, !noalias !4
  %v7264 = load i64, ptr %slot20, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  store i32 1, ptr %p7265, align 4, !alias.scope !3, !noalias !4
  %v7266 = load i64, ptr %slot1328, align 8
  %p7267 = inttoptr i64 %v7266 to ptr
  %ld7268 = load i64, ptr %p7267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7268, ptr %slot1331, align 8
  %v7269 = load i64, ptr %slot1331, align 8
  %v7270 = load i64, ptr %slot43, align 8
  %p7271 = inttoptr i64 %v7270 to ptr
  store i64 %v7269, ptr %p7271, align 8, !alias.scope !3, !noalias !4
  %v7272 = load i64, ptr %slot43, align 8
  %p7273 = inttoptr i64 %v7272 to ptr
  %ld7274 = load i64, ptr %p7273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7274, ptr %slot1332, align 8
  %v7275 = load i64, ptr %slot1332, align 8
  %p7276 = inttoptr i64 %v7275 to ptr
  %ld7277 = load i64, ptr %p7276, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7277, ptr %slot1333, align 8
  %v7278 = load i64, ptr %slot1333, align 8
  %v7279 = load i64, ptr %slot43, align 8
  %p7280 = inttoptr i64 %v7279 to ptr
  store i64 %v7278, ptr %p7280, align 8, !alias.scope !3, !noalias !4
  %v7281 = load i64, ptr %slot20, align 8
  %p7282 = inttoptr i64 %v7281 to ptr
  %ld7283 = load i32, ptr %p7282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7283, ptr %slot1334, align 8
  %v7284 = load i32, ptr %slot1334, align 8
  %cv7285 = zext i32 %v7284 to i64
  %cond7286 = icmp ne i64 %cv7285, 0
  br i1 %cond7286, label %bb_rcslotdrop1717, label %bb_rcslotdone1717
bb_rcslotdrop1717:
  %v7287 = load i64, ptr %slot20, align 8
  %p7288 = inttoptr i64 %v7287 to ptr
  store i32 0, ptr %p7288, align 4, !alias.scope !3, !noalias !4
  %v7289 = load i64, ptr %slot25, align 8
  store i64 %v7289, ptr %slot1335, align 8
  %v7290 = load i64, ptr %slot21, align 8
  %p7291 = inttoptr i64 %v7290 to ptr
  %ld7292 = load i32, ptr %p7291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7292, ptr %slot1336, align 8
  %v7293 = load i32, ptr %slot1336, align 8
  %op7294 = and i32 %v7293, 28
  store i32 %op7294, ptr %slot1337, align 8
  %v7295 = load i32, ptr %slot1337, align 8
  %cv7296 = zext i32 %v7295 to i64
  %cond7297 = icmp ne i64 %cv7296, 0
  br i1 %cond7297, label %bb_rcslotrole1717, label %bb_rcslotowner1717
bb_rcslotrole1717:
  %v7298 = load i64, ptr %slot45, align 8
  store i64 %v7298, ptr %slot1338, align 8
  %v7299 = load i64, ptr %slot1335, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  %ld7301 = load i64, ptr %p7300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7301, ptr %slot1339, align 8
  %v7302 = load i64, ptr %slot1339, align 8
  %cmp7303 = icmp ne i64 %v7302, 0
  %cv7304 = zext i1 %cmp7303 to i32
  store i32 %cv7304, ptr %slot1340, align 8
  %v7305 = load i32, ptr %slot1340, align 8
  %cv7306 = zext i32 %v7305 to i64
  %cond7307 = icmp ne i64 %cv7306, 0
  br i1 %cond7307, label %bb_rcgnn1733, label %bb_rcgdone1733
bb_rcgnn1733:
  %v7308 = load i64, ptr %slot1339, align 8
  %op7309 = sub i64 %v7308, 16
  store i64 %op7309, ptr %slot1341, align 8
  %v7310 = load i64, ptr %slot1339, align 8
  %p7311 = inttoptr i64 %v7310 to ptr
  %rgep7312 = getelementptr i8, ptr %p7311, i64 -16
  %ld7313 = load i64, ptr %rgep7312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7313, ptr %slot1342, align 8
  %v7314 = load i64, ptr %slot1342, align 8
  %op7315 = and i64 %v7314, 4611686018427387906
  store i64 %op7315, ptr %slot1343, align 8
  %v7316 = load i64, ptr %slot1343, align 8
  %cmp7317 = icmp ne i64 %v7316, 0
  %cv7318 = zext i1 %cmp7317 to i32
  store i32 %cv7318, ptr %slot1344, align 8
  %v7319 = load i32, ptr %slot1344, align 8
  %cv7320 = zext i32 %v7319 to i64
  %cond7321 = icmp ne i64 %cv7320, 0
  br i1 %cond7321, label %bb_rcgclear1733, label %bb_rcgcounted1733
bb_rcgcounted1733:
  %v7322 = load i64, ptr %slot1339, align 8
  %op7323 = sub i64 %v7322, 24
  store i64 %op7323, ptr %slot1345, align 8
  %v7324 = load i64, ptr %slot1339, align 8
  %p7325 = inttoptr i64 %v7324 to ptr
  %rgep7326 = getelementptr i8, ptr %p7325, i64 -24
  %ld7327 = load i64, ptr %rgep7326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7327, ptr %slot1346, align 8
  %v7328 = load i64, ptr %slot1346, align 8
  %op7329 = sub i64 %v7328, 1
  store i64 %op7329, ptr %slot1347, align 8
  %v7330 = load i64, ptr %slot1347, align 8
  %cmp7331 = icmp eq i64 %v7330, 0
  %cv7332 = zext i1 %cmp7331 to i32
  store i32 %cv7332, ptr %slot1348, align 8
  %v7333 = load i32, ptr %slot1348, align 8
  %cv7334 = zext i32 %v7333 to i64
  %cond7335 = icmp ne i64 %cv7334, 0
  br i1 %cond7335, label %bb_rcglast1733, label %bb_rcgdec1733
bb_rcglast1733:
  %v7336 = load i64, ptr %slot1339, align 8
  %op7337 = sub i64 %v7336, 32
  store i64 %op7337, ptr %slot1349, align 8
  %v7338 = load i64, ptr %slot1339, align 8
  %p7339 = inttoptr i64 %v7338 to ptr
  %rgep7340 = getelementptr i8, ptr %p7339, i64 -32
  %ld7341 = load i64, ptr %rgep7340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7341, ptr %slot1350, align 8
  %v7342 = load i64, ptr %slot1350, align 8
  %cmp7343 = icmp ne i64 %v7342, 0
  %cv7344 = zext i1 %cmp7343 to i32
  store i32 %cv7344, ptr %slot1351, align 8
  %v7345 = load i32, ptr %slot1351, align 8
  %cv7346 = zext i32 %v7345 to i64
  %cond7347 = icmp ne i64 %cv7346, 0
  br i1 %cond7347, label %bb_rcgdec1733, label %bb_rcgslow1733
bb_rcgslow1733:
  %v7348 = load i64, ptr %slot1338, align 8
  %v7349 = load i64, ptr %slot1335, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7348, i64 %v7349) nomerge, !dbg !190
  br label %bb_rcgdone1733
bb_rcgdec1733:
  %v7350 = load i64, ptr %slot1347, align 8
  %v7351 = load i64, ptr %slot1339, align 8
  %p7352 = inttoptr i64 %v7351 to ptr
  %rgep7353 = getelementptr i8, ptr %p7352, i64 -24
  store i64 %v7350, ptr %rgep7353, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1733
bb_rcgclear1733:
  %v7354 = load i64, ptr %slot1335, align 8
  %p7355 = inttoptr i64 %v7354 to ptr
  store i64 0, ptr %p7355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1733
bb_rcgdone1733:
  br label %bb_rcslotdone1717
bb_rcslotowner1717:
  %v7356 = load i64, ptr %slot45, align 8
  store i64 %v7356, ptr %slot1352, align 8
  %v7357 = load i64, ptr %slot1335, align 8
  %p7358 = inttoptr i64 %v7357 to ptr
  %ld7359 = load i64, ptr %p7358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7359, ptr %slot1353, align 8
  %v7360 = load i64, ptr %slot1353, align 8
  %cmp7361 = icmp ne i64 %v7360, 0
  %cv7362 = zext i1 %cmp7361 to i32
  store i32 %cv7362, ptr %slot1354, align 8
  %v7363 = load i32, ptr %slot1354, align 8
  %cv7364 = zext i32 %v7363 to i64
  %cond7365 = icmp ne i64 %cv7364, 0
  br i1 %cond7365, label %bb_rcgnn1748, label %bb_rcgdone1748
bb_rcgnn1748:
  %v7366 = load i64, ptr %slot1353, align 8
  %op7367 = sub i64 %v7366, 16
  store i64 %op7367, ptr %slot1355, align 8
  %v7368 = load i64, ptr %slot1353, align 8
  %p7369 = inttoptr i64 %v7368 to ptr
  %rgep7370 = getelementptr i8, ptr %p7369, i64 -16
  %ld7371 = load i64, ptr %rgep7370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7371, ptr %slot1356, align 8
  %v7372 = load i64, ptr %slot1356, align 8
  %op7373 = and i64 %v7372, 4611686018427387906
  store i64 %op7373, ptr %slot1357, align 8
  %v7374 = load i64, ptr %slot1357, align 8
  %cmp7375 = icmp ne i64 %v7374, 0
  %cv7376 = zext i1 %cmp7375 to i32
  store i32 %cv7376, ptr %slot1358, align 8
  %v7377 = load i32, ptr %slot1358, align 8
  %cv7378 = zext i32 %v7377 to i64
  %cond7379 = icmp ne i64 %cv7378, 0
  br i1 %cond7379, label %bb_rcgclear1748, label %bb_rcgcounted1748
bb_rcgcounted1748:
  %v7380 = load i64, ptr %slot1353, align 8
  %op7381 = sub i64 %v7380, 32
  store i64 %op7381, ptr %slot1359, align 8
  %v7382 = load i64, ptr %slot1353, align 8
  %p7383 = inttoptr i64 %v7382 to ptr
  %rgep7384 = getelementptr i8, ptr %p7383, i64 -32
  %ld7385 = load i64, ptr %rgep7384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7385, ptr %slot1360, align 8
  %v7386 = load i64, ptr %slot1360, align 8
  %op7387 = sub i64 %v7386, 1
  store i64 %op7387, ptr %slot1361, align 8
  %v7388 = load i64, ptr %slot1361, align 8
  %cmp7389 = icmp eq i64 %v7388, 0
  %cv7390 = zext i1 %cmp7389 to i32
  store i32 %cv7390, ptr %slot1362, align 8
  %v7391 = load i32, ptr %slot1362, align 8
  %cv7392 = zext i32 %v7391 to i64
  %cond7393 = icmp ne i64 %cv7392, 0
  br i1 %cond7393, label %bb_rcglast1748, label %bb_rcgdec1748
bb_rcglast1748:
  %v7394 = load i64, ptr %slot1353, align 8
  %op7395 = sub i64 %v7394, 24
  store i64 %op7395, ptr %slot1363, align 8
  %v7396 = load i64, ptr %slot1353, align 8
  %p7397 = inttoptr i64 %v7396 to ptr
  %rgep7398 = getelementptr i8, ptr %p7397, i64 -24
  %ld7399 = load i64, ptr %rgep7398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7399, ptr %slot1364, align 8
  %v7400 = load i64, ptr %slot1364, align 8
  %cmp7401 = icmp ne i64 %v7400, 0
  %cv7402 = zext i1 %cmp7401 to i32
  store i32 %cv7402, ptr %slot1365, align 8
  %v7403 = load i32, ptr %slot1365, align 8
  %cv7404 = zext i32 %v7403 to i64
  %cond7405 = icmp ne i64 %cv7404, 0
  br i1 %cond7405, label %bb_rcgdec1748, label %bb_rcgslow1748
bb_rcgslow1748:
  %v7406 = load i64, ptr %slot1352, align 8
  %v7407 = load i64, ptr %slot1335, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7406, i64 %v7407) nomerge, !dbg !190
  br label %bb_rcgdone1748
bb_rcgdec1748:
  %v7408 = load i64, ptr %slot1361, align 8
  %v7409 = load i64, ptr %slot1353, align 8
  %p7410 = inttoptr i64 %v7409 to ptr
  %rgep7411 = getelementptr i8, ptr %p7410, i64 -32
  store i64 %v7408, ptr %rgep7411, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1748
bb_rcgclear1748:
  %v7412 = load i64, ptr %slot1335, align 8
  %p7413 = inttoptr i64 %v7412 to ptr
  store i64 0, ptr %p7413, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1748
bb_rcgdone1748:
  br label %bb_rcslotdone1717
bb_rcslotdone1717:
  %v7414 = load i64, ptr %slot43, align 8
  %p7415 = inttoptr i64 %v7414 to ptr
  %ld7416 = load i64, ptr %p7415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7416, ptr %slot1366, align 8
  %v7417 = load i64, ptr %slot42, align 8
  %p7418 = inttoptr i64 %v7417 to ptr
  %ld7419 = load i64, ptr %p7418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7419, ptr %slot1367, align 8
  %v7420 = load i64, ptr %slot1367, align 8
  %v7421 = load i64, ptr %slot1366, align 8
  %cmp7422 = icmp sge i64 %v7420, %v7421
  %cv7423 = zext i1 %cmp7422 to i64
  store i64 %cv7423, ptr %slot1368, align 8
  %v7424 = load i64, ptr %slot1368, align 8
  %v7425 = load i64, ptr %slot42, align 8
  %p7426 = inttoptr i64 %v7425 to ptr
  store i64 %v7424, ptr %p7426, align 8, !alias.scope !3, !noalias !4
  br label %bb_i165
bb_i165:
  %v7427 = load i64, ptr %slot42, align 8
  %p7428 = inttoptr i64 %v7427 to ptr
  %ld7429 = load i64, ptr %p7428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7429, ptr %slot1369, align 8
  %v7430 = load i64, ptr %slot1369, align 8
  %op7431 = xor i64 %v7430, 1
  store i64 %op7431, ptr %slot1370, align 8
  %v7432 = load i64, ptr %slot1370, align 8
  %v7433 = load i64, ptr %slot42, align 8
  %p7434 = inttoptr i64 %v7433 to ptr
  store i64 %v7432, ptr %p7434, align 8, !alias.scope !3, !noalias !4
  br label %bb_i168
bb_i167:
  %v7435 = load i64, ptr %slot42, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  store i64 0, ptr %p7436, align 8, !alias.scope !3, !noalias !4
  br label %bb_i168
bb_i168:
  %v7437 = load i64, ptr %slot42, align 8
  %p7438 = inttoptr i64 %v7437 to ptr
  %ld7439 = load i64, ptr %p7438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7439, ptr %slot1371, align 8
  %v7440 = load i64, ptr %slot1371, align 8
  %cond7441 = icmp ne i64 %v7440, 0
  br i1 %cond7441, label %bb_next1758, label %bb_i185
bb_next1758:
  %v7442 = load i64, ptr %slot29, align 8
  %p7443 = inttoptr i64 %v7442 to ptr
  %ld7444 = load i64, ptr %p7443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7444, ptr %slot1372, align 8
  %v7445 = load i64, ptr %slot1372, align 8
  %v7446 = load i64, ptr %slot42, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  store i64 %v7445, ptr %p7447, align 8, !alias.scope !3, !noalias !4
  %v7448 = load i64, ptr %slot42, align 8
  %p7449 = inttoptr i64 %v7448 to ptr
  %ld7450 = load i64, ptr %p7449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7450, ptr %slot1373, align 8
  %v7451 = load i64, ptr %slot1373, align 8
  %op7452 = add i64 %v7451, 16
  store i64 %op7452, ptr %slot1374, align 8
  %v7453 = load i64, ptr %slot1374, align 8
  %p7454 = inttoptr i64 %v7453 to ptr
  %ld7455 = load i64, ptr %p7454, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7455, ptr %slot1375, align 8
  %v7456 = load i64, ptr %slot1375, align 8
  %v7457 = load i64, ptr %slot42, align 8
  %p7458 = inttoptr i64 %v7457 to ptr
  store i64 %v7456, ptr %p7458, align 8, !alias.scope !3, !noalias !4
  %v7459 = load i64, ptr %slot18, align 8
  %p7460 = inttoptr i64 %v7459 to ptr
  %ld7461 = load i32, ptr %p7460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7461, ptr %slot1376, align 8
  %v7462 = load i32, ptr %slot1376, align 8
  %cv7463 = zext i32 %v7462 to i64
  %cond7464 = icmp ne i64 %cv7463, 0
  br i1 %cond7464, label %bb_rcslotdrop1764, label %bb_rcslotdone1764
bb_rcslotdrop1764:
  %v7465 = load i64, ptr %slot18, align 8
  %p7466 = inttoptr i64 %v7465 to ptr
  store i32 0, ptr %p7466, align 4, !alias.scope !3, !noalias !4
  %v7467 = load i64, ptr %slot24, align 8
  store i64 %v7467, ptr %slot1377, align 8
  %v7468 = load i64, ptr %slot19, align 8
  %p7469 = inttoptr i64 %v7468 to ptr
  %ld7470 = load i32, ptr %p7469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7470, ptr %slot1378, align 8
  %v7471 = load i32, ptr %slot1378, align 8
  %op7472 = and i32 %v7471, 28
  store i32 %op7472, ptr %slot1379, align 8
  %v7473 = load i32, ptr %slot1379, align 8
  %cv7474 = zext i32 %v7473 to i64
  %cond7475 = icmp ne i64 %cv7474, 0
  br i1 %cond7475, label %bb_rcslotrole1764, label %bb_rcslotowner1764
bb_rcslotrole1764:
  %v7476 = load i64, ptr %slot45, align 8
  store i64 %v7476, ptr %slot1380, align 8
  %v7477 = load i64, ptr %slot1380, align 8
  %v7478 = load i64, ptr %slot1377, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7477, i64 %v7478) nomerge, !dbg !192
  br label %bb_rcslotdone1764
bb_rcslotowner1764:
  %v7479 = load i64, ptr %slot45, align 8
  store i64 %v7479, ptr %slot1381, align 8
  %v7480 = load i64, ptr %slot1381, align 8
  %v7481 = load i64, ptr %slot1377, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7480, i64 %v7481) nomerge, !dbg !192
  br label %bb_rcslotdone1764
bb_rcslotdone1764:
  %v7482 = load i64, ptr %slot43, align 8
  %p7483 = inttoptr i64 %v7482 to ptr
  store i64 1, ptr %p7483, align 8, !alias.scope !3, !noalias !4
  %v7484 = load i64, ptr %slot43, align 8
  %p7485 = inttoptr i64 %v7484 to ptr
  %ld7486 = load i64, ptr %p7485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7486, ptr %slot1382, align 8
  %v7487 = load i64, ptr %slot42, align 8
  %p7488 = inttoptr i64 %v7487 to ptr
  %ld7489 = load i64, ptr %p7488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7489, ptr %slot1383, align 8
  %v7490 = load i64, ptr %slot1383, align 8
  %v7491 = load i64, ptr %slot1382, align 8
  %ovpair7493 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7490, i64 %v7491)
  %op7492 = extractvalue { i64, i1 } %ovpair7493, 0
  %ov7494 = extractvalue { i64, i1 } %ovpair7493, 1
  store i64 %op7492, ptr %slot1384, align 8
  %cv7495 = zext i1 %ov7494 to i64
  store i64 %cv7495, ptr %slot1385, align 8
  %v7496 = load i64, ptr %slot1385, align 8
  %cond7497 = icmp ne i64 %v7496, 0
  br i1 %cond7497, label %bb_overflow1773, label %bb_checked1773
bb_overflow1773:
  %v7498 = load i64, ptr %slot1, align 8
  %p7499 = inttoptr i64 %v7498 to ptr
  %v7500 = load i64, ptr %slot1383, align 8
  %v7501 = load i64, ptr %slot1382, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7499, i64 0, i64 %v7500, i64 %v7501, i64 64) nomerge, !dbg !194
  unreachable
bb_checked1773:
  %v7502 = load i64, ptr %slot1384, align 8
  %v7503 = load i64, ptr %slot42, align 8
  %p7504 = inttoptr i64 %v7503 to ptr
  store i64 %v7502, ptr %p7504, align 8, !alias.scope !3, !noalias !4
  %v7505 = load i64, ptr %slot42, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  %ld7507 = load i64, ptr %p7506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7507, ptr %slot1386, align 8
  %v7508 = load i64, ptr %slot1386, align 8
  %v7509 = load i64, ptr %slot34, align 8
  %p7510 = inttoptr i64 %v7509 to ptr
  store i64 %v7508, ptr %p7510, align 8, !alias.scope !3, !noalias !4
  %v7511 = load i64, ptr %slot29, align 8
  %p7512 = inttoptr i64 %v7511 to ptr
  %ld7513 = load i64, ptr %p7512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7513, ptr %slot1387, align 8
  %v7514 = load i64, ptr %slot1387, align 8
  %v7515 = load i64, ptr %slot42, align 8
  %p7516 = inttoptr i64 %v7515 to ptr
  store i64 %v7514, ptr %p7516, align 8, !alias.scope !3, !noalias !4
  %v7517 = load i64, ptr %slot29, align 8
  %p7518 = inttoptr i64 %v7517 to ptr
  %ld7519 = load i64, ptr %p7518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7519, ptr %slot1388, align 8
  %v7520 = load i64, ptr %slot1388, align 8
  %v7521 = load i64, ptr %slot42, align 8
  %p7522 = inttoptr i64 %v7521 to ptr
  store i64 %v7520, ptr %p7522, align 8, !alias.scope !3, !noalias !4
  %v7523 = load i64, ptr %slot29, align 8
  %p7524 = inttoptr i64 %v7523 to ptr
  %ld7525 = load i64, ptr %p7524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7525, ptr %slot1389, align 8
  %v7526 = load i64, ptr %slot1389, align 8
  %v7527 = load i64, ptr %slot42, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  store i64 %v7526, ptr %p7528, align 8, !alias.scope !3, !noalias !4
  %v7529 = load i64, ptr %slot34, align 8
  %p7530 = inttoptr i64 %v7529 to ptr
  %ld7531 = load i64, ptr %p7530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7531, ptr %slot1390, align 8
  %v7532 = load i64, ptr %slot1390, align 8
  %v7533 = load i64, ptr %slot43, align 8
  %p7534 = inttoptr i64 %v7533 to ptr
  store i64 %v7532, ptr %p7534, align 8, !alias.scope !3, !noalias !4
  %v7535 = load i64, ptr %slot29, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  %ld7537 = load i64, ptr %p7536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7537, ptr %slot1391, align 8
  %v7538 = load i64, ptr %slot1391, align 8
  %v7539 = load i64, ptr %slot42, align 8
  %p7540 = inttoptr i64 %v7539 to ptr
  store i64 %v7538, ptr %p7540, align 8, !alias.scope !3, !noalias !4
  %v7541 = load i64, ptr %slot34, align 8
  %p7542 = inttoptr i64 %v7541 to ptr
  %ld7543 = load i64, ptr %p7542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7543, ptr %slot1392, align 8
  %v7544 = load i64, ptr %slot29, align 8
  %p7545 = inttoptr i64 %v7544 to ptr
  %ld7546 = load i64, ptr %p7545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7546, ptr %slot1393, align 8
  %v7547 = load i64, ptr %slot1393, align 8
  %op7548 = add i64 %v7547, 16
  store i64 %op7548, ptr %slot1394, align 8
  %v7549 = load i64, ptr %slot1392, align 8
  %v7550 = load i64, ptr %slot1394, align 8
  %p7551 = inttoptr i64 %v7550 to ptr
  store i64 %v7549, ptr %p7551, align 8, !alias.scope !4, !noalias !3
  %v7552 = load i64, ptr %slot42, align 8
  %p7553 = inttoptr i64 %v7552 to ptr
  store i64 0, ptr %p7553, align 8, !alias.scope !3, !noalias !4
  br label %bb_i132
bb_i185:
  br label %bb_i188
bb_i186:
  %v7554 = load i64, ptr %slot42, align 8
  %p7555 = inttoptr i64 %v7554 to ptr
  store i64 0, ptr %p7555, align 8, !alias.scope !3, !noalias !4
  %v7556 = load i64, ptr %slot42, align 8
  %p7557 = inttoptr i64 %v7556 to ptr
  %ld7558 = load i64, ptr %p7557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7558, ptr %slot1395, align 8
  %v7559 = load i64, ptr %slot18, align 8
  %p7560 = inttoptr i64 %v7559 to ptr
  %ld7561 = load i32, ptr %p7560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7561, ptr %slot1396, align 8
  %v7562 = load i32, ptr %slot1396, align 8
  %cv7563 = zext i32 %v7562 to i64
  %cond7564 = icmp ne i64 %cv7563, 0
  br i1 %cond7564, label %bb_rcslotdrop1787, label %bb_rcslotdone1787
bb_rcslotdrop1787:
  %v7565 = load i64, ptr %slot18, align 8
  %p7566 = inttoptr i64 %v7565 to ptr
  store i32 0, ptr %p7566, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1787
bb_rcslotdone1787:
  %v7567 = load i64, ptr %slot16, align 8
  %p7568 = inttoptr i64 %v7567 to ptr
  %ld7569 = load i32, ptr %p7568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7569, ptr %slot1397, align 8
  %v7570 = load i32, ptr %slot1397, align 8
  %cv7571 = zext i32 %v7570 to i64
  %cond7572 = icmp ne i64 %cv7571, 0
  br i1 %cond7572, label %bb_rcslotdrop1790, label %bb_rcslotdone1790
bb_rcslotdrop1790:
  %v7573 = load i64, ptr %slot16, align 8
  %p7574 = inttoptr i64 %v7573 to ptr
  store i32 0, ptr %p7574, align 4, !alias.scope !3, !noalias !4
  %v7575 = load i64, ptr %slot41, align 8
  store i64 %v7575, ptr %slot1398, align 8
  %v7576 = load i64, ptr %slot17, align 8
  %p7577 = inttoptr i64 %v7576 to ptr
  %ld7578 = load i32, ptr %p7577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7578, ptr %slot1399, align 8
  %v7579 = load i32, ptr %slot1399, align 8
  %op7580 = and i32 %v7579, 28
  store i32 %op7580, ptr %slot1400, align 8
  %v7581 = load i32, ptr %slot1400, align 8
  %cv7582 = zext i32 %v7581 to i64
  %cond7583 = icmp ne i64 %cv7582, 0
  br i1 %cond7583, label %bb_rcslotrole1790, label %bb_rcslotowner1790
bb_rcslotrole1790:
  %v7584 = load i64, ptr %slot45, align 8
  store i64 %v7584, ptr %slot1401, align 8
  %v7585 = load i64, ptr %slot1401, align 8
  %v7586 = load i64, ptr %slot1398, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7585, i64 %v7586) nomerge, !dbg !196
  br label %bb_rcslotdone1790
bb_rcslotowner1790:
  %v7587 = load i64, ptr %slot45, align 8
  store i64 %v7587, ptr %slot1402, align 8
  %v7588 = load i64, ptr %slot1402, align 8
  %v7589 = load i64, ptr %slot1398, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7588, i64 %v7589) nomerge, !dbg !196
  br label %bb_rcslotdone1790
bb_rcslotdone1790:
  %v7590 = load i64, ptr %slot14, align 8
  %p7591 = inttoptr i64 %v7590 to ptr
  %ld7592 = load i32, ptr %p7591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7592, ptr %slot1403, align 8
  %v7593 = load i32, ptr %slot1403, align 8
  %cv7594 = zext i32 %v7593 to i64
  %cond7595 = icmp ne i64 %cv7594, 0
  br i1 %cond7595, label %bb_rcslotdrop1799, label %bb_rcslotdone1799
bb_rcslotdrop1799:
  %v7596 = load i64, ptr %slot14, align 8
  %p7597 = inttoptr i64 %v7596 to ptr
  store i32 0, ptr %p7597, align 4, !alias.scope !3, !noalias !4
  %v7598 = load i64, ptr %slot40, align 8
  store i64 %v7598, ptr %slot1404, align 8
  %v7599 = load i64, ptr %slot15, align 8
  %p7600 = inttoptr i64 %v7599 to ptr
  %ld7601 = load i32, ptr %p7600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7601, ptr %slot1405, align 8
  %v7602 = load i32, ptr %slot1405, align 8
  %op7603 = and i32 %v7602, 28
  store i32 %op7603, ptr %slot1406, align 8
  %v7604 = load i32, ptr %slot1406, align 8
  %cv7605 = zext i32 %v7604 to i64
  %cond7606 = icmp ne i64 %cv7605, 0
  br i1 %cond7606, label %bb_rcslotrole1799, label %bb_rcslotowner1799
bb_rcslotrole1799:
  %v7607 = load i64, ptr %slot45, align 8
  store i64 %v7607, ptr %slot1407, align 8
  %v7608 = load i64, ptr %slot1407, align 8
  %v7609 = load i64, ptr %slot1404, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7608, i64 %v7609) nomerge, !dbg !196
  br label %bb_rcslotdone1799
bb_rcslotowner1799:
  %v7610 = load i64, ptr %slot45, align 8
  store i64 %v7610, ptr %slot1408, align 8
  %v7611 = load i64, ptr %slot1408, align 8
  %v7612 = load i64, ptr %slot1404, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7611, i64 %v7612) nomerge, !dbg !196
  br label %bb_rcslotdone1799
bb_rcslotdone1799:
  %v7613 = load i64, ptr %slot12, align 8
  %p7614 = inttoptr i64 %v7613 to ptr
  %ld7615 = load i32, ptr %p7614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7615, ptr %slot1409, align 8
  %v7616 = load i32, ptr %slot1409, align 8
  %cv7617 = zext i32 %v7616 to i64
  %cond7618 = icmp ne i64 %cv7617, 0
  br i1 %cond7618, label %bb_rcslotdrop1808, label %bb_rcslotdone1808
bb_rcslotdrop1808:
  %v7619 = load i64, ptr %slot12, align 8
  %p7620 = inttoptr i64 %v7619 to ptr
  store i32 0, ptr %p7620, align 4, !alias.scope !3, !noalias !4
  %v7621 = load i64, ptr %slot39, align 8
  store i64 %v7621, ptr %slot1410, align 8
  %v7622 = load i64, ptr %slot13, align 8
  %p7623 = inttoptr i64 %v7622 to ptr
  %ld7624 = load i32, ptr %p7623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7624, ptr %slot1411, align 8
  %v7625 = load i32, ptr %slot1411, align 8
  %op7626 = and i32 %v7625, 28
  store i32 %op7626, ptr %slot1412, align 8
  %v7627 = load i32, ptr %slot1412, align 8
  %cv7628 = zext i32 %v7627 to i64
  %cond7629 = icmp ne i64 %cv7628, 0
  br i1 %cond7629, label %bb_rcslotrole1808, label %bb_rcslotowner1808
bb_rcslotrole1808:
  %v7630 = load i64, ptr %slot45, align 8
  store i64 %v7630, ptr %slot1413, align 8
  %v7631 = load i64, ptr %slot1413, align 8
  %v7632 = load i64, ptr %slot1410, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7631, i64 %v7632) nomerge, !dbg !196
  br label %bb_rcslotdone1808
bb_rcslotowner1808:
  %v7633 = load i64, ptr %slot45, align 8
  store i64 %v7633, ptr %slot1414, align 8
  %v7634 = load i64, ptr %slot1414, align 8
  %v7635 = load i64, ptr %slot1410, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7634, i64 %v7635) nomerge, !dbg !196
  br label %bb_rcslotdone1808
bb_rcslotdone1808:
  %v7636 = load i64, ptr %slot10, align 8
  %p7637 = inttoptr i64 %v7636 to ptr
  %ld7638 = load i32, ptr %p7637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7638, ptr %slot1415, align 8
  %v7639 = load i32, ptr %slot1415, align 8
  %cv7640 = zext i32 %v7639 to i64
  %cond7641 = icmp ne i64 %cv7640, 0
  br i1 %cond7641, label %bb_rcslotdrop1817, label %bb_rcslotdone1817
bb_rcslotdrop1817:
  %v7642 = load i64, ptr %slot10, align 8
  %p7643 = inttoptr i64 %v7642 to ptr
  store i32 0, ptr %p7643, align 4, !alias.scope !3, !noalias !4
  %v7644 = load i64, ptr %slot38, align 8
  store i64 %v7644, ptr %slot1416, align 8
  %v7645 = load i64, ptr %slot11, align 8
  %p7646 = inttoptr i64 %v7645 to ptr
  %ld7647 = load i32, ptr %p7646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7647, ptr %slot1417, align 8
  %v7648 = load i32, ptr %slot1417, align 8
  %op7649 = and i32 %v7648, 28
  store i32 %op7649, ptr %slot1418, align 8
  %v7650 = load i32, ptr %slot1418, align 8
  %cv7651 = zext i32 %v7650 to i64
  %cond7652 = icmp ne i64 %cv7651, 0
  br i1 %cond7652, label %bb_rcslotrole1817, label %bb_rcslotowner1817
bb_rcslotrole1817:
  %v7653 = load i64, ptr %slot45, align 8
  store i64 %v7653, ptr %slot1419, align 8
  %v7654 = load i64, ptr %slot1419, align 8
  %v7655 = load i64, ptr %slot1416, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7654, i64 %v7655) nomerge, !dbg !196
  br label %bb_rcslotdone1817
bb_rcslotowner1817:
  %v7656 = load i64, ptr %slot45, align 8
  store i64 %v7656, ptr %slot1420, align 8
  %v7657 = load i64, ptr %slot1420, align 8
  %v7658 = load i64, ptr %slot1416, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7657, i64 %v7658) nomerge, !dbg !196
  br label %bb_rcslotdone1817
bb_rcslotdone1817:
  %v7659 = load i64, ptr %slot8, align 8
  %p7660 = inttoptr i64 %v7659 to ptr
  %ld7661 = load i32, ptr %p7660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7661, ptr %slot1421, align 8
  %v7662 = load i32, ptr %slot1421, align 8
  %cv7663 = zext i32 %v7662 to i64
  %cond7664 = icmp ne i64 %cv7663, 0
  br i1 %cond7664, label %bb_rcslotdrop1826, label %bb_rcslotdone1826
bb_rcslotdrop1826:
  %v7665 = load i64, ptr %slot8, align 8
  %p7666 = inttoptr i64 %v7665 to ptr
  store i32 0, ptr %p7666, align 4, !alias.scope !3, !noalias !4
  %v7667 = load i64, ptr %slot37, align 8
  store i64 %v7667, ptr %slot1422, align 8
  %v7668 = load i64, ptr %slot9, align 8
  %p7669 = inttoptr i64 %v7668 to ptr
  %ld7670 = load i32, ptr %p7669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7670, ptr %slot1423, align 8
  %v7671 = load i32, ptr %slot1423, align 8
  %op7672 = and i32 %v7671, 28
  store i32 %op7672, ptr %slot1424, align 8
  %v7673 = load i32, ptr %slot1424, align 8
  %cv7674 = zext i32 %v7673 to i64
  %cond7675 = icmp ne i64 %cv7674, 0
  br i1 %cond7675, label %bb_rcslotrole1826, label %bb_rcslotowner1826
bb_rcslotrole1826:
  %v7676 = load i64, ptr %slot45, align 8
  store i64 %v7676, ptr %slot1425, align 8
  %v7677 = load i64, ptr %slot1425, align 8
  %v7678 = load i64, ptr %slot1422, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7677, i64 %v7678) nomerge, !dbg !196
  br label %bb_rcslotdone1826
bb_rcslotowner1826:
  %v7679 = load i64, ptr %slot45, align 8
  store i64 %v7679, ptr %slot1426, align 8
  %v7680 = load i64, ptr %slot1426, align 8
  %v7681 = load i64, ptr %slot1422, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7680, i64 %v7681) nomerge, !dbg !196
  br label %bb_rcslotdone1826
bb_rcslotdone1826:
  %v7682 = load i64, ptr %slot6, align 8
  %p7683 = inttoptr i64 %v7682 to ptr
  %ld7684 = load i32, ptr %p7683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7684, ptr %slot1427, align 8
  %v7685 = load i32, ptr %slot1427, align 8
  %cv7686 = zext i32 %v7685 to i64
  %cond7687 = icmp ne i64 %cv7686, 0
  br i1 %cond7687, label %bb_rcslotdrop1835, label %bb_rcslotdone1835
bb_rcslotdrop1835:
  %v7688 = load i64, ptr %slot6, align 8
  %p7689 = inttoptr i64 %v7688 to ptr
  store i32 0, ptr %p7689, align 4, !alias.scope !3, !noalias !4
  %v7690 = load i64, ptr %slot36, align 8
  store i64 %v7690, ptr %slot1428, align 8
  %v7691 = load i64, ptr %slot7, align 8
  %p7692 = inttoptr i64 %v7691 to ptr
  %ld7693 = load i32, ptr %p7692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7693, ptr %slot1429, align 8
  %v7694 = load i32, ptr %slot1429, align 8
  %op7695 = and i32 %v7694, 28
  store i32 %op7695, ptr %slot1430, align 8
  %v7696 = load i32, ptr %slot1430, align 8
  %cv7697 = zext i32 %v7696 to i64
  %cond7698 = icmp ne i64 %cv7697, 0
  br i1 %cond7698, label %bb_rcslotrole1835, label %bb_rcslotowner1835
bb_rcslotrole1835:
  %v7699 = load i64, ptr %slot45, align 8
  store i64 %v7699, ptr %slot1431, align 8
  %v7700 = load i64, ptr %slot1431, align 8
  %v7701 = load i64, ptr %slot1428, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7700, i64 %v7701) nomerge, !dbg !196
  br label %bb_rcslotdone1835
bb_rcslotowner1835:
  %v7702 = load i64, ptr %slot45, align 8
  store i64 %v7702, ptr %slot1432, align 8
  %v7703 = load i64, ptr %slot1432, align 8
  %v7704 = load i64, ptr %slot1428, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7703, i64 %v7704) nomerge, !dbg !196
  br label %bb_rcslotdone1835
bb_rcslotdone1835:
  %v7705 = load i64, ptr %slot4, align 8
  %p7706 = inttoptr i64 %v7705 to ptr
  %ld7707 = load i32, ptr %p7706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7707, ptr %slot1433, align 8
  %v7708 = load i32, ptr %slot1433, align 8
  %cv7709 = zext i32 %v7708 to i64
  %cond7710 = icmp ne i64 %cv7709, 0
  br i1 %cond7710, label %bb_rcslotdrop1844, label %bb_rcslotdone1844
bb_rcslotdrop1844:
  %v7711 = load i64, ptr %slot4, align 8
  %p7712 = inttoptr i64 %v7711 to ptr
  store i32 0, ptr %p7712, align 4, !alias.scope !3, !noalias !4
  %v7713 = load i64, ptr %slot35, align 8
  store i64 %v7713, ptr %slot1434, align 8
  %v7714 = load i64, ptr %slot5, align 8
  %p7715 = inttoptr i64 %v7714 to ptr
  %ld7716 = load i32, ptr %p7715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7716, ptr %slot1435, align 8
  %v7717 = load i32, ptr %slot1435, align 8
  %op7718 = and i32 %v7717, 28
  store i32 %op7718, ptr %slot1436, align 8
  %v7719 = load i32, ptr %slot1436, align 8
  %cv7720 = zext i32 %v7719 to i64
  %cond7721 = icmp ne i64 %cv7720, 0
  br i1 %cond7721, label %bb_rcslotrole1844, label %bb_rcslotowner1844
bb_rcslotrole1844:
  %v7722 = load i64, ptr %slot45, align 8
  store i64 %v7722, ptr %slot1437, align 8
  %v7723 = load i64, ptr %slot1437, align 8
  %v7724 = load i64, ptr %slot1434, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v7723, i64 %v7724) nomerge, !dbg !196
  br label %bb_rcslotdone1844
bb_rcslotowner1844:
  %v7725 = load i64, ptr %slot45, align 8
  store i64 %v7725, ptr %slot1438, align 8
  %v7726 = load i64, ptr %slot1438, align 8
  %v7727 = load i64, ptr %slot1434, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v7726, i64 %v7727) nomerge, !dbg !196
  br label %bb_rcslotdone1844
bb_rcslotdone1844:
  %v7728 = load i64, ptr %slot1395, align 8
  ret i64 %v7728
bb_i188:
  br label %bb_i0
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_338a6618a4a5efff0b2e0ab19eaa6544c1f98c3cc4a486b294b4ebbefdd3b59d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_338a6618a4a5efff0b2e0ab19eaa6544c1f98c3cc4a486b294b4ebbefdd3b59d", linkageName: "myl_f_338a6618a4a5efff0b2e0ab19eaa6544c1f98c3cc4a486b294b4ebbefdd3b59d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 12805748999862418910, i64 0, !"myl_f_338a6618a4a5efff0b2e0ab19eaa6544c1f98c3cc4a486b294b4ebbefdd3b59d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!122 = !DILocation(line: 16, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!126 = !DILocation(line: 19, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!128 = !DILocation(line: 24, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!136 = !DILocation(line: 34, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!138 = !DILocation(line: 52, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!140 = !DILocation(line: 54, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!142 = !DILocation(line: 72, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!144 = !DILocation(line: 74, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!146 = !DILocation(line: 87, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!148 = !DILocation(line: 89, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!150 = !DILocation(line: 107, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647407)
!152 = !DILocation(line: 109, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!154 = !DILocation(line: 111, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!156 = !DILocation(line: 113, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!158 = !DILocation(line: 114, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647495)
!160 = !DILocation(line: 120, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647511)
!162 = !DILocation(line: 122, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!164 = !DILocation(line: 124, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647535)
!166 = !DILocation(line: 125, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647607)
!168 = !DILocation(line: 134, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647623)
!170 = !DILocation(line: 136, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647639)
!172 = !DILocation(line: 138, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647655)
!174 = !DILocation(line: 140, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647663)
!176 = !DILocation(line: 141, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647719)
!178 = !DILocation(line: 148, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647735)
!180 = !DILocation(line: 150, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647743)
!182 = !DILocation(line: 151, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647799)
!184 = !DILocation(line: 158, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647815)
!186 = !DILocation(line: 160, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647831)
!188 = !DILocation(line: 162, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647839)
!190 = !DILocation(line: 163, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647903)
!192 = !DILocation(line: 171, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647919)
!194 = !DILocation(line: 173, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648039)
!196 = !DILocation(line: 188, column: 0, scope: !197)
