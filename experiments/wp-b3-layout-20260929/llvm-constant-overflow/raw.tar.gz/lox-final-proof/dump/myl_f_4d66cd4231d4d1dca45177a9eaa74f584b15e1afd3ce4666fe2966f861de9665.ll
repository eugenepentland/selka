target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_4d66cd4231d4d1dca45177a9eaa74f584b15e1afd3ce4666fe2966f861de9665(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %callresult70 = alloca [16 x i8], align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %callresult233 = alloca [16 x i8], align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %callresult245 = alloca [24 x i8], align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %callresult352 = alloca [24 x i8], align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %callresult778 = alloca [16 x i8], align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %callresult793 = alloca [24 x i8], align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i32, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i32, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i32, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i32, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i32, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i32, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i32, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i32, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i32, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i32, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i32, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i32, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i32, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i32, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i32, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i32, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i32, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i32, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i32, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i32, align 8
  %slot1439 = alloca i32, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i32, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %callresult1448 = alloca [16 x i8], align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i32, align 8
  %slot1452 = alloca i32, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i32, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i32, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i32, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i32, align 8
  %slot1469 = alloca i32, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i32, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i32, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i64, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i32, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i32, align 8
  %slot1493 = alloca i32, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i64, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i32, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i32, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i32, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i32, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i32, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i32, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i32, align 8
  %slot1522 = alloca i32, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i32, align 8
  %slot1525 = alloca i32, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i32, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i32, align 8
  %slot1531 = alloca i32, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1534 = load i64, ptr %slot1, align 8
  %op1535 = add i64 %v1534, 32
  store i64 %op1535, ptr %slot4, align 8
  %mem1536 = alloca i8, i64 8, align 8
  %ptr1537 = ptrtoint ptr %mem1536 to i64
  store i64 %ptr1537, ptr %slot5, align 8
  %mem1538 = alloca i8, i64 8, align 8
  %ptr1539 = ptrtoint ptr %mem1538 to i64
  store i64 %ptr1539, ptr %slot6, align 8
  %mem1540 = alloca i8, i64 8, align 8
  %ptr1541 = ptrtoint ptr %mem1540 to i64
  store i64 %ptr1541, ptr %slot7, align 8
  %mem1542 = alloca i8, i64 8, align 8
  %ptr1543 = ptrtoint ptr %mem1542 to i64
  store i64 %ptr1543, ptr %slot8, align 8
  %mem1544 = alloca i8, i64 8, align 8
  %ptr1545 = ptrtoint ptr %mem1544 to i64
  store i64 %ptr1545, ptr %slot9, align 8
  %mem1546 = alloca i8, i64 8, align 8
  %ptr1547 = ptrtoint ptr %mem1546 to i64
  store i64 %ptr1547, ptr %slot10, align 8
  %mem1548 = alloca i8, i64 8, align 8
  %ptr1549 = ptrtoint ptr %mem1548 to i64
  store i64 %ptr1549, ptr %slot11, align 8
  %mem1550 = alloca i8, i64 8, align 8
  %ptr1551 = ptrtoint ptr %mem1550 to i64
  store i64 %ptr1551, ptr %slot12, align 8
  %mem1552 = alloca i8, i64 8, align 8
  %ptr1553 = ptrtoint ptr %mem1552 to i64
  store i64 %ptr1553, ptr %slot13, align 8
  %mem1554 = alloca i8, i64 8, align 8
  %ptr1555 = ptrtoint ptr %mem1554 to i64
  store i64 %ptr1555, ptr %slot14, align 8
  %mem1556 = alloca i8, i64 8, align 8
  %ptr1557 = ptrtoint ptr %mem1556 to i64
  store i64 %ptr1557, ptr %slot15, align 8
  %mem1558 = alloca i8, i64 8, align 8
  %ptr1559 = ptrtoint ptr %mem1558 to i64
  store i64 %ptr1559, ptr %slot16, align 8
  %mem1560 = alloca i8, i64 8, align 8
  %ptr1561 = ptrtoint ptr %mem1560 to i64
  store i64 %ptr1561, ptr %slot17, align 8
  %mem1562 = alloca i8, i64 8, align 8
  %ptr1563 = ptrtoint ptr %mem1562 to i64
  store i64 %ptr1563, ptr %slot18, align 8
  %mem1564 = alloca i8, i64 8, align 8
  %ptr1565 = ptrtoint ptr %mem1564 to i64
  store i64 %ptr1565, ptr %slot19, align 8
  %mem1566 = alloca i8, i64 8, align 8
  %ptr1567 = ptrtoint ptr %mem1566 to i64
  store i64 %ptr1567, ptr %slot20, align 8
  %mem1568 = alloca i8, i64 8, align 8
  %ptr1569 = ptrtoint ptr %mem1568 to i64
  store i64 %ptr1569, ptr %slot21, align 8
  %mem1570 = alloca i8, i64 8, align 8
  %ptr1571 = ptrtoint ptr %mem1570 to i64
  store i64 %ptr1571, ptr %slot22, align 8
  %mem1572 = alloca i8, i64 8, align 8
  %ptr1573 = ptrtoint ptr %mem1572 to i64
  store i64 %ptr1573, ptr %slot23, align 8
  %mem1574 = alloca i8, i64 8, align 8
  %ptr1575 = ptrtoint ptr %mem1574 to i64
  store i64 %ptr1575, ptr %slot24, align 8
  %mem1576 = alloca i8, i64 8, align 8
  %ptr1577 = ptrtoint ptr %mem1576 to i64
  store i64 %ptr1577, ptr %slot25, align 8
  %mem1578 = alloca i8, i64 8, align 8
  %ptr1579 = ptrtoint ptr %mem1578 to i64
  store i64 %ptr1579, ptr %slot26, align 8
  %mem1580 = alloca i8, i64 8, align 8
  %ptr1581 = ptrtoint ptr %mem1580 to i64
  store i64 %ptr1581, ptr %slot27, align 8
  %mem1582 = alloca i8, i64 8, align 8
  %ptr1583 = ptrtoint ptr %mem1582 to i64
  store i64 %ptr1583, ptr %slot28, align 8
  %mem1584 = alloca i8, i64 8, align 8
  %ptr1585 = ptrtoint ptr %mem1584 to i64
  store i64 %ptr1585, ptr %slot29, align 8
  %mem1586 = alloca i8, i64 208, align 8
  %ptr1587 = ptrtoint ptr %mem1586 to i64
  store i64 %ptr1587, ptr %slot30, align 8
  %mem1588 = alloca i8, i64 208, align 8
  %ptr1589 = ptrtoint ptr %mem1588 to i64
  store i64 %ptr1589, ptr %slot31, align 8
  %mem1590 = alloca i8, i64 8, align 8
  %ptr1591 = ptrtoint ptr %mem1590 to i64
  store i64 %ptr1591, ptr %slot32, align 8
  %mem1592 = alloca i8, i64 8, align 8
  %ptr1593 = ptrtoint ptr %mem1592 to i64
  store i64 %ptr1593, ptr %slot33, align 8
  %mem1594 = alloca i8, i64 8, align 8
  %ptr1595 = ptrtoint ptr %mem1594 to i64
  store i64 %ptr1595, ptr %slot34, align 8
  %mem1596 = alloca i8, i64 208, align 8
  %ptr1597 = ptrtoint ptr %mem1596 to i64
  store i64 %ptr1597, ptr %slot35, align 8
  %mem1598 = alloca i8, i64 32, align 8
  %ptr1599 = ptrtoint ptr %mem1598 to i64
  store i64 %ptr1599, ptr %slot36, align 8
  %v1600 = load i64, ptr %slot36, align 8
  %p1602 = inttoptr i64 %v1600 to ptr
  %gep1603 = getelementptr i8, ptr %p1602, i64 24
  %op1601 = ptrtoint ptr %gep1603 to i64
  store i64 %op1601, ptr %slot37, align 8
  %v1604 = load i64, ptr %slot37, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i64 0, ptr %p1605, align 8, !alias.scope !3, !noalias !4
  %mem1606 = alloca i8, i64 8, align 8
  %ptr1607 = ptrtoint ptr %mem1606 to i64
  store i64 %ptr1607, ptr %slot38, align 8
  %mem1608 = alloca i8, i64 8, align 8
  %ptr1609 = ptrtoint ptr %mem1608 to i64
  store i64 %ptr1609, ptr %slot39, align 8
  %mem1610 = alloca i8, i64 8, align 8
  %ptr1611 = ptrtoint ptr %mem1610 to i64
  store i64 %ptr1611, ptr %slot40, align 8
  %mem1612 = alloca i8, i64 16, align 8
  %ptr1613 = ptrtoint ptr %mem1612 to i64
  store i64 %ptr1613, ptr %slot41, align 8
  %mem1614 = alloca i8, i64 16, align 8
  %ptr1615 = ptrtoint ptr %mem1614 to i64
  store i64 %ptr1615, ptr %slot42, align 8
  %mem1616 = alloca i8, i64 16, align 8
  %ptr1617 = ptrtoint ptr %mem1616 to i64
  store i64 %ptr1617, ptr %slot43, align 8
  %mem1618 = alloca i8, i64 8, align 8
  %ptr1619 = ptrtoint ptr %mem1618 to i64
  store i64 %ptr1619, ptr %slot44, align 8
  %mem1620 = alloca i8, i64 16, align 8
  %ptr1621 = ptrtoint ptr %mem1620 to i64
  store i64 %ptr1621, ptr %slot45, align 8
  %mem1622 = alloca i8, i64 8, align 8
  %ptr1623 = ptrtoint ptr %mem1622 to i64
  store i64 %ptr1623, ptr %slot46, align 8
  %mem1624 = alloca i8, i64 24, align 8
  %ptr1625 = ptrtoint ptr %mem1624 to i64
  store i64 %ptr1625, ptr %slot47, align 8
  %mem1626 = alloca i8, i64 24, align 8
  %ptr1627 = ptrtoint ptr %mem1626 to i64
  store i64 %ptr1627, ptr %slot48, align 8
  %mem1628 = alloca i8, i64 16, align 8
  %ptr1629 = ptrtoint ptr %mem1628 to i64
  store i64 %ptr1629, ptr %slot49, align 8
  %mem1630 = alloca i8, i64 8, align 8
  %ptr1631 = ptrtoint ptr %mem1630 to i64
  store i64 %ptr1631, ptr %slot50, align 8
  %mem1632 = alloca i8, i64 56, align 8
  %ptr1633 = ptrtoint ptr %mem1632 to i64
  store i64 %ptr1633, ptr %slot51, align 8
  %mem1634 = alloca i8, i64 8, align 8
  %ptr1635 = ptrtoint ptr %mem1634 to i64
  store i64 %ptr1635, ptr %slot52, align 8
  %mem1636 = alloca i8, i64 8, align 8
  %ptr1637 = ptrtoint ptr %mem1636 to i64
  store i64 %ptr1637, ptr %slot53, align 8
  %mem1638 = alloca i8, i64 8, align 8
  %ptr1639 = ptrtoint ptr %mem1638 to i64
  store i64 %ptr1639, ptr %slot54, align 8
  %mem1640 = alloca i8, i64 8, align 8
  %ptr1641 = ptrtoint ptr %mem1640 to i64
  store i64 %ptr1641, ptr %slot55, align 8
  %mem1642 = alloca i8, i64 16, align 8
  %ptr1643 = ptrtoint ptr %mem1642 to i64
  store i64 %ptr1643, ptr %slot56, align 8
  %mem1644 = alloca i8, i64 24, align 8
  %ptr1645 = ptrtoint ptr %mem1644 to i64
  store i64 %ptr1645, ptr %slot57, align 8
  %mem1646 = alloca i8, i64 56, align 8
  %ptr1647 = ptrtoint ptr %mem1646 to i64
  store i64 %ptr1647, ptr %slot58, align 8
  %mem1648 = alloca i8, i64 56, align 8
  %ptr1649 = ptrtoint ptr %mem1648 to i64
  store i64 %ptr1649, ptr %slot59, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem1650 = alloca i8, i64 8, align 8
  %ptr1651 = ptrtoint ptr %mem1650 to i64
  store i64 %ptr1651, ptr %slot60, align 8
  %v1652 = load i64, ptr %slot1, align 8
  %op1653 = add i64 %v1652, 64
  store i64 %op1653, ptr %slot61, align 8
  %v1654 = load i64, ptr %slot61, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i64, ptr %p1655, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1656, ptr %slot62, align 8
  %stack1657 = call ptr @llvm.stacksave()
  %stackaddr1658 = ptrtoint ptr %stack1657 to i64
  %v1659 = load i64, ptr %slot62, align 8
  %cmp1660 = icmp ult i64 %stackaddr1658, %v1659
  %cv1661 = zext i1 %cmp1660 to i64
  store i64 %cv1661, ptr %slot63, align 8
  %v1662 = load i64, ptr %slot63, align 8
  %cond1663 = icmp ne i64 %v1662, 0
  br i1 %cond1663, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v1664 = load i64, ptr %slot1, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  call void @myl_qbe_fail_frame(ptr %p1665) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v1666 = load i64, ptr %slot44, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 0, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot50, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  store i64 0, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  %v1670 = load i64, ptr %slot2, align 8
  %v1671 = load i64, ptr %slot39, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  store i64 %v1670, ptr %p1672, align 8, !alias.scope !3, !noalias !4
  %v1673 = load i64, ptr %slot3, align 8
  %v1674 = load i64, ptr %slot40, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 %v1673, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot1, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  %call1678 = call ptr @myl_qbe_heap(ptr %p1677) nomerge, !dbg !112
  %calladdr1679 = ptrtoint ptr %call1678 to i64
  store i64 %calladdr1679, ptr %slot64, align 8
  %v1680 = load i64, ptr %slot1, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %call1682 = call i64 @myl_qbe_region_mark(ptr %p1681) nomerge, !dbg !112
  store i64 %call1682, ptr %slot65, align 8
  %v1683 = load i64, ptr %slot5, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  store i32 0, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  %v1685 = load i64, ptr %slot6, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i32 0, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  %v1687 = load i64, ptr %slot7, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  store i32 0, ptr %p1688, align 4, !alias.scope !3, !noalias !4
  %v1689 = load i64, ptr %slot8, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i32 0, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot9, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i32 0, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot10, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot11, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 0, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot12, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 0, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot13, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 0, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot14, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 0, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot15, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 0, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot16, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i32 0, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot17, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 0, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot18, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i32 0, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot19, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot20, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 0, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot21, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 0, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot22, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i32 0, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot23, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i32 0, ptr %p1720, align 4, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot24, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i32 0, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot25, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 0, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot26, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i32 0, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot27, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 0, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot28, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i32 0, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot29, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 0, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot6, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 2, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot8, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i32 2, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  %v1737 = load i64, ptr %slot10, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  store i32 2, ptr %p1738, align 4, !alias.scope !3, !noalias !4
  %v1739 = load i64, ptr %slot12, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i32 2, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot14, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 2, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot16, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i32 2, ptr %p1744, align 4, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot18, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i32 2, ptr %p1746, align 4, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot20, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i32 2, ptr %p1748, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1749 = load i64, ptr %slot39, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot66, align 8
  %v1752 = load i64, ptr %slot66, align 8
  %v1753 = load i64, ptr %slot53, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i64 %v1752, ptr %p1754, align 8, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot54, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  store i64 1, ptr %p1756, align 8, !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot53, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  %ld1759 = load i64, ptr %p1758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1759, ptr %slot67, align 8
  %v1760 = load i64, ptr %slot54, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %ld1762 = load i64, ptr %p1761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1762, ptr %slot68, align 8
  %v1763 = load i64, ptr %slot1, align 8
  %v1764 = load i64, ptr %slot67, align 8
  %v1765 = load i64, ptr %slot68, align 8
  %call1766 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1763, i64 %v1764, i64 %v1765) nomerge, !dbg !114
  store { i64, i64 } %call1766, ptr %callresult70, align 8
  %addr1767 = ptrtoint ptr %callresult70 to i64
  store i64 %addr1767, ptr %slot69, align 8
  %v1768 = load i64, ptr %slot69, align 8
  %v1769 = load i64, ptr %slot53, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  store i64 %v1768, ptr %p1770, align 8, !alias.scope !3, !noalias !4
  %v1771 = load i64, ptr %slot21, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  %ld1773 = load i32, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1773, ptr %slot71, align 8
  %v1774 = load i32, ptr %slot71, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v1777 = load i64, ptr %slot21, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  store i32 0, ptr %p1778, align 4, !alias.scope !3, !noalias !4
  %v1779 = load i64, ptr %slot30, align 8
  store i64 %v1779, ptr %slot72, align 8
  %v1780 = load i64, ptr %slot22, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i32, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1782, ptr %slot73, align 8
  %v1783 = load i32, ptr %slot73, align 8
  %op1784 = and i32 %v1783, 28
  store i32 %op1784, ptr %slot74, align 8
  %v1785 = load i32, ptr %slot74, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v1788 = load i64, ptr %slot64, align 8
  store i64 %v1788, ptr %slot75, align 8
  %v1789 = load i64, ptr %slot75, align 8
  %v1790 = load i64, ptr %slot72, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1789, i64 %v1790) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v1791 = load i64, ptr %slot64, align 8
  store i64 %v1791, ptr %slot76, align 8
  %v1792 = load i64, ptr %slot76, align 8
  %v1793 = load i64, ptr %slot72, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1792, i64 %v1793) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v1794 = load i64, ptr %slot53, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %ld1796 = load i64, ptr %p1795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1796, ptr %slot77, align 8
  %v1797 = load i64, ptr %slot77, align 8
  %v1798 = load i64, ptr %slot41, align 8
  %p1799 = inttoptr i64 %v1797 to ptr
  %p1800 = inttoptr i64 %v1798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1800, ptr %p1799, i64 16, i1 false)
  %v1801 = load i64, ptr %slot39, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  %ld1803 = load i64, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1803, ptr %slot78, align 8
  %v1804 = load i64, ptr %slot78, align 8
  %v1805 = load i64, ptr %slot53, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i64 %v1804, ptr %p1806, align 8, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot41, align 8
  %v1808 = load i64, ptr %slot54, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  store i64 %v1807, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  %v1810 = load i64, ptr %slot53, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  %ld1812 = load i64, ptr %p1811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1812, ptr %slot79, align 8
  %v1813 = load i64, ptr %slot54, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %ld1815 = load i64, ptr %p1814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1815, ptr %slot80, align 8
  %v1816 = load i64, ptr %slot1, align 8
  %v1817 = load i64, ptr %slot79, align 8
  %v1818 = load i64, ptr %slot80, align 8
  %call1819 = call i64 @myl_f_4680c94320ae82d3642670f8407600cccd57188842621865ec871008bcaae5c7(i64 %v1816, i64 %v1817, i64 %v1818) nomerge, !dbg !116
  store i64 %call1819, ptr %slot81, align 8
  %v1820 = load i64, ptr %slot81, align 8
  %v1821 = load i64, ptr %slot53, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i64 %v1820, ptr %p1822, align 8, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot21, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %ld1825 = load i32, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1825, ptr %slot82, align 8
  %v1826 = load i32, ptr %slot82, align 8
  %cv1827 = zext i32 %v1826 to i64
  %cond1828 = icmp ne i64 %cv1827, 0
  br i1 %cond1828, label %bb_rcslotdrop39, label %bb_rcslotdone39
bb_rcslotdrop39:
  %v1829 = load i64, ptr %slot21, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i32 0, ptr %p1830, align 4, !alias.scope !3, !noalias !4
  %v1831 = load i64, ptr %slot30, align 8
  store i64 %v1831, ptr %slot83, align 8
  %v1832 = load i64, ptr %slot22, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %ld1834 = load i32, ptr %p1833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1834, ptr %slot84, align 8
  %v1835 = load i32, ptr %slot84, align 8
  %op1836 = and i32 %v1835, 28
  store i32 %op1836, ptr %slot85, align 8
  %v1837 = load i32, ptr %slot85, align 8
  %cv1838 = zext i32 %v1837 to i64
  %cond1839 = icmp ne i64 %cv1838, 0
  br i1 %cond1839, label %bb_rcslotrole39, label %bb_rcslotowner39
bb_rcslotrole39:
  %v1840 = load i64, ptr %slot64, align 8
  store i64 %v1840, ptr %slot86, align 8
  %v1841 = load i64, ptr %slot86, align 8
  %v1842 = load i64, ptr %slot83, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1841, i64 %v1842) nomerge, !dbg !116
  br label %bb_rcslotdone39
bb_rcslotowner39:
  %v1843 = load i64, ptr %slot64, align 8
  store i64 %v1843, ptr %slot87, align 8
  %v1844 = load i64, ptr %slot87, align 8
  %v1845 = load i64, ptr %slot83, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1844, i64 %v1845) nomerge, !dbg !116
  br label %bb_rcslotdone39
bb_rcslotdone39:
  %v1846 = load i64, ptr %slot53, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %ld1848 = load i64, ptr %p1847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1848, ptr %slot88, align 8
  %v1849 = load i64, ptr %slot88, align 8
  %op1850 = xor i64 %v1849, 1
  store i64 %op1850, ptr %slot89, align 8
  %v1851 = load i64, ptr %slot89, align 8
  %v1852 = load i64, ptr %slot53, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  store i64 %v1851, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  %v1854 = load i64, ptr %slot53, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %ld1856 = load i64, ptr %p1855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1856, ptr %slot90, align 8
  %v1857 = load i64, ptr %slot90, align 8
  %cond1858 = icmp ne i64 %v1857, 0
  br i1 %cond1858, label %bb_next49, label %bb_i14
bb_next49:
  %v1859 = load i64, ptr %slot39, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  %ld1861 = load i64, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1861, ptr %slot91, align 8
  %v1862 = load i64, ptr %slot91, align 8
  %v1863 = load i64, ptr %slot53, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  store i64 %v1862, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  %v1865 = load i64, ptr %slot40, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %ld1867 = load i64, ptr %p1866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1867, ptr %slot92, align 8
  %v1868 = load i64, ptr %slot92, align 8
  %v1869 = load i64, ptr %slot54, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  store i64 %v1868, ptr %p1870, align 8, !alias.scope !3, !noalias !4
  %p1871 = inttoptr i64 ptrtoint (ptr @myl_lit_2988f248bcf7fecf94868b447d50e1ca761d4666b8875670525fa0e5a4347a5f to i64) to ptr
  %ld1872 = load i64, ptr %p1871, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1872, ptr %slot93, align 8
  %v1873 = load i64, ptr %slot93, align 8
  %v1874 = load i64, ptr %slot55, align 8
  %p1875 = inttoptr i64 %v1874 to ptr
  store i64 %v1873, ptr %p1875, align 8, !alias.scope !3, !noalias !4
  %v1876 = load i64, ptr %slot55, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %ld1878 = load i64, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1878, ptr %slot94, align 8
  %v1879 = load i64, ptr %slot94, align 8
  %v1880 = load i64, ptr %slot34, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i64 %v1879, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  %v1882 = load i64, ptr %slot34, align 8
  store i64 %v1882, ptr %slot95, align 8
  %v1883 = load i64, ptr %slot35, align 8
  store i64 %v1883, ptr %slot96, align 8
  %v1884 = load i64, ptr %slot95, align 8
  %v1885 = load i64, ptr %slot96, align 8
  %p1886 = inttoptr i64 %v1884 to ptr
  %p1887 = inttoptr i64 %v1885 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1887, ptr %p1886, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot28, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 2, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot27, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  store i32 1, ptr %p1891, align 4, !alias.scope !3, !noalias !4
  %v1892 = load i64, ptr %slot32, align 8
  store i64 %v1892, ptr %slot97, align 8
  %v1893 = load i64, ptr %slot35, align 8
  store i64 %v1893, ptr %slot98, align 8
  %v1894 = load i64, ptr %slot98, align 8
  %v1895 = load i64, ptr %slot97, align 8
  %p1896 = inttoptr i64 %v1894 to ptr
  %p1897 = inttoptr i64 %v1895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1897, ptr %p1896, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1898 = load i64, ptr %slot26, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  store i32 2, ptr %p1899, align 4, !alias.scope !3, !noalias !4
  %v1900 = load i64, ptr %slot28, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  %ld1902 = load i32, ptr %p1901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1902, ptr %slot99, align 8
  %v1903 = load i32, ptr %slot99, align 8
  %v1904 = load i64, ptr %slot26, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 %v1903, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot27, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 0, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot25, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i32 1, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot97, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i64, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1912, ptr %slot100, align 8
  %v1913 = load i64, ptr %slot100, align 8
  %v1914 = load i64, ptr %slot55, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i64 %v1913, ptr %p1915, align 8, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot53, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i64, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1918, ptr %slot101, align 8
  %v1919 = load i64, ptr %slot54, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1921, ptr %slot102, align 8
  %v1922 = load i64, ptr %slot55, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i64, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1924, ptr %slot103, align 8
  %v1925 = load i64, ptr %slot1, align 8
  %v1926 = load i64, ptr %slot101, align 8
  %v1927 = load i64, ptr %slot102, align 8
  %v1928 = load i64, ptr %slot103, align 8
  %call1929 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v1925, i64 %v1926, i64 %v1927, i64 %v1928) nomerge, !dbg !118
  store i64 %call1929, ptr %slot104, align 8
  %v1930 = load i64, ptr %slot104, align 8
  %v1931 = load i64, ptr %slot53, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i64 %v1930, ptr %p1932, align 8, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot21, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i32, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1935, ptr %slot105, align 8
  %v1936 = load i32, ptr %slot105, align 8
  %cv1937 = zext i32 %v1936 to i64
  %cond1938 = icmp ne i64 %cv1937, 0
  br i1 %cond1938, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v1939 = load i64, ptr %slot21, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  store i32 0, ptr %p1940, align 4, !alias.scope !3, !noalias !4
  %v1941 = load i64, ptr %slot30, align 8
  store i64 %v1941, ptr %slot106, align 8
  %v1942 = load i64, ptr %slot22, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i32, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1944, ptr %slot107, align 8
  %v1945 = load i32, ptr %slot107, align 8
  %op1946 = and i32 %v1945, 28
  store i32 %op1946, ptr %slot108, align 8
  %v1947 = load i32, ptr %slot108, align 8
  %cv1948 = zext i32 %v1947 to i64
  %cond1949 = icmp ne i64 %cv1948, 0
  br i1 %cond1949, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v1950 = load i64, ptr %slot64, align 8
  store i64 %v1950, ptr %slot109, align 8
  %v1951 = load i64, ptr %slot109, align 8
  %v1952 = load i64, ptr %slot106, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1951, i64 %v1952) nomerge, !dbg !118
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v1953 = load i64, ptr %slot64, align 8
  store i64 %v1953, ptr %slot110, align 8
  %v1954 = load i64, ptr %slot110, align 8
  %v1955 = load i64, ptr %slot106, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1954, i64 %v1955) nomerge, !dbg !118
  br label %bb_rcslotdone73
bb_rcslotdone73:
  %v1956 = load i64, ptr %slot23, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  %ld1958 = load i32, ptr %p1957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1958, ptr %slot111, align 8
  %v1959 = load i32, ptr %slot111, align 8
  %cv1960 = zext i32 %v1959 to i64
  %cond1961 = icmp ne i64 %cv1960, 0
  br i1 %cond1961, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1962 = load i64, ptr %slot23, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  store i32 0, ptr %p1963, align 4, !alias.scope !3, !noalias !4
  %v1964 = load i64, ptr %slot31, align 8
  store i64 %v1964, ptr %slot112, align 8
  %v1965 = load i64, ptr %slot24, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  %ld1967 = load i32, ptr %p1966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1967, ptr %slot113, align 8
  %v1968 = load i32, ptr %slot113, align 8
  %op1969 = and i32 %v1968, 28
  store i32 %op1969, ptr %slot114, align 8
  %v1970 = load i32, ptr %slot114, align 8
  %cv1971 = zext i32 %v1970 to i64
  %cond1972 = icmp ne i64 %cv1971, 0
  br i1 %cond1972, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1973 = load i64, ptr %slot64, align 8
  store i64 %v1973, ptr %slot115, align 8
  %v1974 = load i64, ptr %slot115, align 8
  %v1975 = load i64, ptr %slot112, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1974, i64 %v1975) nomerge, !dbg !118
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1976 = load i64, ptr %slot64, align 8
  store i64 %v1976, ptr %slot116, align 8
  %v1977 = load i64, ptr %slot116, align 8
  %v1978 = load i64, ptr %slot112, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1977, i64 %v1978) nomerge, !dbg !118
  br label %bb_rcslotdone82
bb_rcslotdone82:
  %v1979 = load i64, ptr %slot25, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  %ld1981 = load i32, ptr %p1980, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1981, ptr %slot117, align 8
  %v1982 = load i32, ptr %slot117, align 8
  %cv1983 = zext i32 %v1982 to i64
  %cond1984 = icmp ne i64 %cv1983, 0
  br i1 %cond1984, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v1985 = load i64, ptr %slot25, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 0, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot32, align 8
  store i64 %v1987, ptr %slot118, align 8
  %v1988 = load i64, ptr %slot26, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %ld1990 = load i32, ptr %p1989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1990, ptr %slot119, align 8
  %v1991 = load i32, ptr %slot119, align 8
  %op1992 = and i32 %v1991, 28
  store i32 %op1992, ptr %slot120, align 8
  %v1993 = load i32, ptr %slot120, align 8
  %cv1994 = zext i32 %v1993 to i64
  %cond1995 = icmp ne i64 %cv1994, 0
  br i1 %cond1995, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v1996 = load i64, ptr %slot64, align 8
  store i64 %v1996, ptr %slot121, align 8
  %v1997 = load i64, ptr %slot118, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %ld1999 = load i64, ptr %p1998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1999, ptr %slot122, align 8
  %v2000 = load i64, ptr %slot122, align 8
  %cmp2001 = icmp ne i64 %v2000, 0
  %cv2002 = zext i1 %cmp2001 to i32
  store i32 %cv2002, ptr %slot123, align 8
  %v2003 = load i32, ptr %slot123, align 8
  %cv2004 = zext i32 %v2003 to i64
  %cond2005 = icmp ne i64 %cv2004, 0
  br i1 %cond2005, label %bb_rcgnn107, label %bb_rcgdone107
bb_rcgnn107:
  %v2006 = load i64, ptr %slot122, align 8
  %op2007 = sub i64 %v2006, 16
  store i64 %op2007, ptr %slot124, align 8
  %v2008 = load i64, ptr %slot122, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %rgep2010 = getelementptr i8, ptr %p2009, i64 -16
  %ld2011 = load i64, ptr %rgep2010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2011, ptr %slot125, align 8
  %v2012 = load i64, ptr %slot125, align 8
  %op2013 = and i64 %v2012, 4611686018427387906
  store i64 %op2013, ptr %slot126, align 8
  %v2014 = load i64, ptr %slot126, align 8
  %cmp2015 = icmp ne i64 %v2014, 0
  %cv2016 = zext i1 %cmp2015 to i32
  store i32 %cv2016, ptr %slot127, align 8
  %v2017 = load i32, ptr %slot127, align 8
  %cv2018 = zext i32 %v2017 to i64
  %cond2019 = icmp ne i64 %cv2018, 0
  br i1 %cond2019, label %bb_rcgclear107, label %bb_rcgcounted107
bb_rcgcounted107:
  %v2020 = load i64, ptr %slot122, align 8
  %op2021 = sub i64 %v2020, 24
  store i64 %op2021, ptr %slot128, align 8
  %v2022 = load i64, ptr %slot122, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  %rgep2024 = getelementptr i8, ptr %p2023, i64 -24
  %ld2025 = load i64, ptr %rgep2024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2025, ptr %slot129, align 8
  %v2026 = load i64, ptr %slot129, align 8
  %op2027 = sub i64 %v2026, 1
  store i64 %op2027, ptr %slot130, align 8
  %v2028 = load i64, ptr %slot130, align 8
  %cmp2029 = icmp eq i64 %v2028, 0
  %cv2030 = zext i1 %cmp2029 to i32
  store i32 %cv2030, ptr %slot131, align 8
  %v2031 = load i32, ptr %slot131, align 8
  %cv2032 = zext i32 %v2031 to i64
  %cond2033 = icmp ne i64 %cv2032, 0
  br i1 %cond2033, label %bb_rcglast107, label %bb_rcgdec107
bb_rcglast107:
  %v2034 = load i64, ptr %slot122, align 8
  %op2035 = sub i64 %v2034, 32
  store i64 %op2035, ptr %slot132, align 8
  %v2036 = load i64, ptr %slot122, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %rgep2038 = getelementptr i8, ptr %p2037, i64 -32
  %ld2039 = load i64, ptr %rgep2038, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2039, ptr %slot133, align 8
  %v2040 = load i64, ptr %slot133, align 8
  %cmp2041 = icmp ne i64 %v2040, 0
  %cv2042 = zext i1 %cmp2041 to i32
  store i32 %cv2042, ptr %slot134, align 8
  %v2043 = load i32, ptr %slot134, align 8
  %cv2044 = zext i32 %v2043 to i64
  %cond2045 = icmp ne i64 %cv2044, 0
  br i1 %cond2045, label %bb_rcgdec107, label %bb_rcgslow107
bb_rcgslow107:
  %v2046 = load i64, ptr %slot121, align 8
  %v2047 = load i64, ptr %slot118, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2046, i64 %v2047) nomerge, !dbg !118
  br label %bb_rcgdone107
bb_rcgdec107:
  %v2048 = load i64, ptr %slot130, align 8
  %v2049 = load i64, ptr %slot122, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  %rgep2051 = getelementptr i8, ptr %p2050, i64 -24
  store i64 %v2048, ptr %rgep2051, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear107
bb_rcgclear107:
  %v2052 = load i64, ptr %slot118, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i64 0, ptr %p2053, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone107
bb_rcgdone107:
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v2054 = load i64, ptr %slot64, align 8
  store i64 %v2054, ptr %slot135, align 8
  %v2055 = load i64, ptr %slot118, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %ld2057 = load i64, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2057, ptr %slot136, align 8
  %v2058 = load i64, ptr %slot136, align 8
  %cmp2059 = icmp ne i64 %v2058, 0
  %cv2060 = zext i1 %cmp2059 to i32
  store i32 %cv2060, ptr %slot137, align 8
  %v2061 = load i32, ptr %slot137, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcgnn122, label %bb_rcgdone122
bb_rcgnn122:
  %v2064 = load i64, ptr %slot136, align 8
  %op2065 = sub i64 %v2064, 16
  store i64 %op2065, ptr %slot138, align 8
  %v2066 = load i64, ptr %slot136, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  %rgep2068 = getelementptr i8, ptr %p2067, i64 -16
  %ld2069 = load i64, ptr %rgep2068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2069, ptr %slot139, align 8
  %v2070 = load i64, ptr %slot139, align 8
  %op2071 = and i64 %v2070, 4611686018427387906
  store i64 %op2071, ptr %slot140, align 8
  %v2072 = load i64, ptr %slot140, align 8
  %cmp2073 = icmp ne i64 %v2072, 0
  %cv2074 = zext i1 %cmp2073 to i32
  store i32 %cv2074, ptr %slot141, align 8
  %v2075 = load i32, ptr %slot141, align 8
  %cv2076 = zext i32 %v2075 to i64
  %cond2077 = icmp ne i64 %cv2076, 0
  br i1 %cond2077, label %bb_rcgclear122, label %bb_rcgcounted122
bb_rcgcounted122:
  %v2078 = load i64, ptr %slot136, align 8
  %op2079 = sub i64 %v2078, 32
  store i64 %op2079, ptr %slot142, align 8
  %v2080 = load i64, ptr %slot136, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  %rgep2082 = getelementptr i8, ptr %p2081, i64 -32
  %ld2083 = load i64, ptr %rgep2082, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2083, ptr %slot143, align 8
  %v2084 = load i64, ptr %slot143, align 8
  %op2085 = sub i64 %v2084, 1
  store i64 %op2085, ptr %slot144, align 8
  %v2086 = load i64, ptr %slot144, align 8
  %cmp2087 = icmp eq i64 %v2086, 0
  %cv2088 = zext i1 %cmp2087 to i32
  store i32 %cv2088, ptr %slot145, align 8
  %v2089 = load i32, ptr %slot145, align 8
  %cv2090 = zext i32 %v2089 to i64
  %cond2091 = icmp ne i64 %cv2090, 0
  br i1 %cond2091, label %bb_rcglast122, label %bb_rcgdec122
bb_rcglast122:
  %v2092 = load i64, ptr %slot136, align 8
  %op2093 = sub i64 %v2092, 24
  store i64 %op2093, ptr %slot146, align 8
  %v2094 = load i64, ptr %slot136, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %rgep2096 = getelementptr i8, ptr %p2095, i64 -24
  %ld2097 = load i64, ptr %rgep2096, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2097, ptr %slot147, align 8
  %v2098 = load i64, ptr %slot147, align 8
  %cmp2099 = icmp ne i64 %v2098, 0
  %cv2100 = zext i1 %cmp2099 to i32
  store i32 %cv2100, ptr %slot148, align 8
  %v2101 = load i32, ptr %slot148, align 8
  %cv2102 = zext i32 %v2101 to i64
  %cond2103 = icmp ne i64 %cv2102, 0
  br i1 %cond2103, label %bb_rcgdec122, label %bb_rcgslow122
bb_rcgslow122:
  %v2104 = load i64, ptr %slot135, align 8
  %v2105 = load i64, ptr %slot118, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2104, i64 %v2105) nomerge, !dbg !118
  br label %bb_rcgdone122
bb_rcgdec122:
  %v2106 = load i64, ptr %slot144, align 8
  %v2107 = load i64, ptr %slot136, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %rgep2109 = getelementptr i8, ptr %p2108, i64 -32
  store i64 %v2106, ptr %rgep2109, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear122
bb_rcgclear122:
  %v2110 = load i64, ptr %slot118, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  store i64 0, ptr %p2111, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone122
bb_rcgdone122:
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v2112 = load i64, ptr %slot53, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  %ld2114 = load i64, ptr %p2113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2114, ptr %slot149, align 8
  %v2115 = load i64, ptr %slot36, align 8
  %p2117 = inttoptr i64 %v2115 to ptr
  %gep2118 = getelementptr i8, ptr %p2117, i64 24
  %op2116 = ptrtoint ptr %gep2118 to i64
  store i64 %op2116, ptr %slot150, align 8
  %v2119 = load i64, ptr %slot150, align 8
  %p2120 = inttoptr i64 %v2119 to ptr
  %ld2121 = load i32, ptr %p2120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2121, ptr %slot151, align 8
  %v2122 = load i32, ptr %slot151, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcscopesopen129, label %bb_rcscopesclosed129
bb_rcscopesopen129:
  %v2125 = load i64, ptr %slot38, align 8
  %p2127 = inttoptr i64 %v2125 to ptr
  %gep2128 = getelementptr i8, ptr %p2127, i64 0
  %op2126 = ptrtoint ptr %gep2128 to i64
  store i64 %op2126, ptr %slot152, align 8
  %v2129 = load i64, ptr %slot36, align 8
  %v2130 = load i64, ptr %slot152, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i64 %v2129, ptr %p2131, align 8, !alias.scope !3, !noalias !4
  %v2132 = load i64, ptr %slot1, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %v2134 = load i64, ptr %slot38, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2133, ptr %p2135, i64 1) nomerge, !dbg !120
  br label %bb_rcscopesclosed129
bb_rcscopesclosed129:
  %v2136 = load i64, ptr %slot21, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %ld2138 = load i32, ptr %p2137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2138, ptr %slot153, align 8
  %v2139 = load i32, ptr %slot153, align 8
  %cv2140 = zext i32 %v2139 to i64
  %cond2141 = icmp ne i64 %cv2140, 0
  br i1 %cond2141, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v2142 = load i64, ptr %slot21, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i32 0, ptr %p2143, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone133
bb_rcslotdone133:
  %v2144 = load i64, ptr %slot19, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %ld2146 = load i32, ptr %p2145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2146, ptr %slot154, align 8
  %v2147 = load i32, ptr %slot154, align 8
  %cv2148 = zext i32 %v2147 to i64
  %cond2149 = icmp ne i64 %cv2148, 0
  br i1 %cond2149, label %bb_rcslotdrop136, label %bb_rcslotdone136
bb_rcslotdrop136:
  %v2150 = load i64, ptr %slot19, align 8
  %p2151 = inttoptr i64 %v2150 to ptr
  store i32 0, ptr %p2151, align 4, !alias.scope !3, !noalias !4
  %v2152 = load i64, ptr %slot51, align 8
  store i64 %v2152, ptr %slot155, align 8
  %v2153 = load i64, ptr %slot20, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i32, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2155, ptr %slot156, align 8
  %v2156 = load i32, ptr %slot156, align 8
  %op2157 = and i32 %v2156, 28
  store i32 %op2157, ptr %slot157, align 8
  %v2158 = load i32, ptr %slot157, align 8
  %cv2159 = zext i32 %v2158 to i64
  %cond2160 = icmp ne i64 %cv2159, 0
  br i1 %cond2160, label %bb_rcslotrole136, label %bb_rcslotowner136
bb_rcslotrole136:
  %v2161 = load i64, ptr %slot64, align 8
  store i64 %v2161, ptr %slot158, align 8
  %v2162 = load i64, ptr %slot158, align 8
  %v2163 = load i64, ptr %slot155, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2162, i64 %v2163) nomerge, !dbg !120
  br label %bb_rcslotdone136
bb_rcslotowner136:
  %v2164 = load i64, ptr %slot64, align 8
  store i64 %v2164, ptr %slot159, align 8
  %v2165 = load i64, ptr %slot159, align 8
  %v2166 = load i64, ptr %slot155, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2165, i64 %v2166) nomerge, !dbg !120
  br label %bb_rcslotdone136
bb_rcslotdone136:
  %v2167 = load i64, ptr %slot17, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %ld2169 = load i32, ptr %p2168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2169, ptr %slot160, align 8
  %v2170 = load i32, ptr %slot160, align 8
  %cv2171 = zext i32 %v2170 to i64
  %cond2172 = icmp ne i64 %cv2171, 0
  br i1 %cond2172, label %bb_rcslotdrop182, label %bb_rcslotdone182
bb_rcslotdrop182:
  %v2173 = load i64, ptr %slot17, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  store i32 0, ptr %p2174, align 4, !alias.scope !3, !noalias !4
  %v2175 = load i64, ptr %slot49, align 8
  store i64 %v2175, ptr %slot161, align 8
  %v2176 = load i64, ptr %slot18, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i32, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2178, ptr %slot162, align 8
  %v2179 = load i32, ptr %slot162, align 8
  %op2180 = and i32 %v2179, 28
  store i32 %op2180, ptr %slot163, align 8
  %v2181 = load i32, ptr %slot163, align 8
  %cv2182 = zext i32 %v2181 to i64
  %cond2183 = icmp ne i64 %cv2182, 0
  br i1 %cond2183, label %bb_rcslotrole182, label %bb_rcslotowner182
bb_rcslotrole182:
  %v2184 = load i64, ptr %slot64, align 8
  store i64 %v2184, ptr %slot164, align 8
  %v2185 = load i64, ptr %slot164, align 8
  %v2186 = load i64, ptr %slot161, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2185, i64 %v2186) nomerge, !dbg !120
  br label %bb_rcslotdone182
bb_rcslotowner182:
  %v2187 = load i64, ptr %slot64, align 8
  store i64 %v2187, ptr %slot165, align 8
  %v2188 = load i64, ptr %slot165, align 8
  %v2189 = load i64, ptr %slot161, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2188, i64 %v2189) nomerge, !dbg !120
  br label %bb_rcslotdone182
bb_rcslotdone182:
  %v2190 = load i64, ptr %slot15, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  %ld2192 = load i32, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2192, ptr %slot166, align 8
  %v2193 = load i32, ptr %slot166, align 8
  %cv2194 = zext i32 %v2193 to i64
  %cond2195 = icmp ne i64 %cv2194, 0
  br i1 %cond2195, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v2196 = load i64, ptr %slot15, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i32 0, ptr %p2197, align 4, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot48, align 8
  store i64 %v2198, ptr %slot167, align 8
  %v2199 = load i64, ptr %slot16, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i32, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2201, ptr %slot168, align 8
  %v2202 = load i32, ptr %slot168, align 8
  %op2203 = and i32 %v2202, 28
  store i32 %op2203, ptr %slot169, align 8
  %v2204 = load i32, ptr %slot169, align 8
  %cv2205 = zext i32 %v2204 to i64
  %cond2206 = icmp ne i64 %cv2205, 0
  br i1 %cond2206, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v2207 = load i64, ptr %slot64, align 8
  store i64 %v2207, ptr %slot170, align 8
  %v2208 = load i64, ptr %slot170, align 8
  %v2209 = load i64, ptr %slot167, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2208, i64 %v2209) nomerge, !dbg !120
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v2210 = load i64, ptr %slot64, align 8
  store i64 %v2210, ptr %slot171, align 8
  %v2211 = load i64, ptr %slot171, align 8
  %v2212 = load i64, ptr %slot167, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2211, i64 %v2212) nomerge, !dbg !120
  br label %bb_rcslotdone191
bb_rcslotdone191:
  %v2213 = load i64, ptr %slot13, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i32, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2215, ptr %slot172, align 8
  %v2216 = load i32, ptr %slot172, align 8
  %cv2217 = zext i32 %v2216 to i64
  %cond2218 = icmp ne i64 %cv2217, 0
  br i1 %cond2218, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v2219 = load i64, ptr %slot13, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  store i32 0, ptr %p2220, align 4, !alias.scope !3, !noalias !4
  %v2221 = load i64, ptr %slot47, align 8
  store i64 %v2221, ptr %slot173, align 8
  %v2222 = load i64, ptr %slot14, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  %ld2224 = load i32, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2224, ptr %slot174, align 8
  %v2225 = load i32, ptr %slot174, align 8
  %op2226 = and i32 %v2225, 28
  store i32 %op2226, ptr %slot175, align 8
  %v2227 = load i32, ptr %slot175, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v2230 = load i64, ptr %slot64, align 8
  store i64 %v2230, ptr %slot176, align 8
  %v2231 = load i64, ptr %slot176, align 8
  %v2232 = load i64, ptr %slot173, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2231, i64 %v2232) nomerge, !dbg !120
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v2233 = load i64, ptr %slot64, align 8
  store i64 %v2233, ptr %slot177, align 8
  %v2234 = load i64, ptr %slot177, align 8
  %v2235 = load i64, ptr %slot173, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2234, i64 %v2235) nomerge, !dbg !120
  br label %bb_rcslotdone200
bb_rcslotdone200:
  %v2236 = load i64, ptr %slot11, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %ld2238 = load i32, ptr %p2237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2238, ptr %slot178, align 8
  %v2239 = load i32, ptr %slot178, align 8
  %cv2240 = zext i32 %v2239 to i64
  %cond2241 = icmp ne i64 %cv2240, 0
  br i1 %cond2241, label %bb_rcslotdrop209, label %bb_rcslotdone209
bb_rcslotdrop209:
  %v2242 = load i64, ptr %slot11, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i32 0, ptr %p2243, align 4, !alias.scope !3, !noalias !4
  %v2244 = load i64, ptr %slot45, align 8
  store i64 %v2244, ptr %slot179, align 8
  %v2245 = load i64, ptr %slot12, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i32, ptr %p2246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2247, ptr %slot180, align 8
  %v2248 = load i32, ptr %slot180, align 8
  %op2249 = and i32 %v2248, 28
  store i32 %op2249, ptr %slot181, align 8
  %v2250 = load i32, ptr %slot181, align 8
  %cv2251 = zext i32 %v2250 to i64
  %cond2252 = icmp ne i64 %cv2251, 0
  br i1 %cond2252, label %bb_rcslotrole209, label %bb_rcslotowner209
bb_rcslotrole209:
  %v2253 = load i64, ptr %slot64, align 8
  store i64 %v2253, ptr %slot182, align 8
  %v2254 = load i64, ptr %slot182, align 8
  %v2255 = load i64, ptr %slot179, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2254, i64 %v2255) nomerge, !dbg !120
  br label %bb_rcslotdone209
bb_rcslotowner209:
  %v2256 = load i64, ptr %slot64, align 8
  store i64 %v2256, ptr %slot183, align 8
  %v2257 = load i64, ptr %slot183, align 8
  %v2258 = load i64, ptr %slot179, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2257, i64 %v2258) nomerge, !dbg !120
  br label %bb_rcslotdone209
bb_rcslotdone209:
  %v2259 = load i64, ptr %slot9, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %ld2261 = load i32, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2261, ptr %slot184, align 8
  %v2262 = load i32, ptr %slot184, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcslotdrop218, label %bb_rcslotdone218
bb_rcslotdrop218:
  %v2265 = load i64, ptr %slot9, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i32 0, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot44, align 8
  store i64 %v2267, ptr %slot185, align 8
  %v2268 = load i64, ptr %slot10, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %ld2270 = load i32, ptr %p2269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2270, ptr %slot186, align 8
  %v2271 = load i32, ptr %slot186, align 8
  %op2272 = and i32 %v2271, 28
  store i32 %op2272, ptr %slot187, align 8
  %v2273 = load i32, ptr %slot187, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcslotrole218, label %bb_rcslotowner218
bb_rcslotrole218:
  %v2276 = load i64, ptr %slot64, align 8
  store i64 %v2276, ptr %slot188, align 8
  %v2277 = load i64, ptr %slot185, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i64, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2279, ptr %slot189, align 8
  %v2280 = load i64, ptr %slot189, align 8
  %cmp2281 = icmp ne i64 %v2280, 0
  %cv2282 = zext i1 %cmp2281 to i32
  store i32 %cv2282, ptr %slot190, align 8
  %v2283 = load i32, ptr %slot190, align 8
  %cv2284 = zext i32 %v2283 to i64
  %cond2285 = icmp ne i64 %cv2284, 0
  br i1 %cond2285, label %bb_rcgnn234, label %bb_rcgdone234
bb_rcgnn234:
  %v2286 = load i64, ptr %slot189, align 8
  %op2287 = sub i64 %v2286, 16
  store i64 %op2287, ptr %slot191, align 8
  %v2288 = load i64, ptr %slot189, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  %rgep2290 = getelementptr i8, ptr %p2289, i64 -16
  %ld2291 = load i64, ptr %rgep2290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2291, ptr %slot192, align 8
  %v2292 = load i64, ptr %slot192, align 8
  %op2293 = and i64 %v2292, 4611686018427387906
  store i64 %op2293, ptr %slot193, align 8
  %v2294 = load i64, ptr %slot193, align 8
  %cmp2295 = icmp ne i64 %v2294, 0
  %cv2296 = zext i1 %cmp2295 to i32
  store i32 %cv2296, ptr %slot194, align 8
  %v2297 = load i32, ptr %slot194, align 8
  %cv2298 = zext i32 %v2297 to i64
  %cond2299 = icmp ne i64 %cv2298, 0
  br i1 %cond2299, label %bb_rcgclear234, label %bb_rcgcounted234
bb_rcgcounted234:
  %v2300 = load i64, ptr %slot189, align 8
  %op2301 = sub i64 %v2300, 24
  store i64 %op2301, ptr %slot195, align 8
  %v2302 = load i64, ptr %slot189, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %rgep2304 = getelementptr i8, ptr %p2303, i64 -24
  %ld2305 = load i64, ptr %rgep2304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2305, ptr %slot196, align 8
  %v2306 = load i64, ptr %slot196, align 8
  %op2307 = sub i64 %v2306, 1
  store i64 %op2307, ptr %slot197, align 8
  %v2308 = load i64, ptr %slot197, align 8
  %cmp2309 = icmp eq i64 %v2308, 0
  %cv2310 = zext i1 %cmp2309 to i32
  store i32 %cv2310, ptr %slot198, align 8
  %v2311 = load i32, ptr %slot198, align 8
  %cv2312 = zext i32 %v2311 to i64
  %cond2313 = icmp ne i64 %cv2312, 0
  br i1 %cond2313, label %bb_rcglast234, label %bb_rcgdec234
bb_rcglast234:
  %v2314 = load i64, ptr %slot189, align 8
  %op2315 = sub i64 %v2314, 32
  store i64 %op2315, ptr %slot199, align 8
  %v2316 = load i64, ptr %slot189, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %rgep2318 = getelementptr i8, ptr %p2317, i64 -32
  %ld2319 = load i64, ptr %rgep2318, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2319, ptr %slot200, align 8
  %v2320 = load i64, ptr %slot200, align 8
  %cmp2321 = icmp ne i64 %v2320, 0
  %cv2322 = zext i1 %cmp2321 to i32
  store i32 %cv2322, ptr %slot201, align 8
  %v2323 = load i32, ptr %slot201, align 8
  %cv2324 = zext i32 %v2323 to i64
  %cond2325 = icmp ne i64 %cv2324, 0
  br i1 %cond2325, label %bb_rcgdec234, label %bb_rcgslow234
bb_rcgslow234:
  %v2326 = load i64, ptr %slot188, align 8
  %v2327 = load i64, ptr %slot185, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v2326, i64 %v2327) nomerge, !dbg !120
  br label %bb_rcgdone234
bb_rcgdec234:
  %v2328 = load i64, ptr %slot197, align 8
  %v2329 = load i64, ptr %slot189, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  %rgep2331 = getelementptr i8, ptr %p2330, i64 -24
  store i64 %v2328, ptr %rgep2331, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear234
bb_rcgclear234:
  %v2332 = load i64, ptr %slot185, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  store i64 0, ptr %p2333, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone234
bb_rcgdone234:
  br label %bb_rcslotdone218
bb_rcslotowner218:
  %v2334 = load i64, ptr %slot64, align 8
  store i64 %v2334, ptr %slot202, align 8
  %v2335 = load i64, ptr %slot185, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  %ld2337 = load i64, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2337, ptr %slot203, align 8
  %v2338 = load i64, ptr %slot203, align 8
  %cmp2339 = icmp ne i64 %v2338, 0
  %cv2340 = zext i1 %cmp2339 to i32
  store i32 %cv2340, ptr %slot204, align 8
  %v2341 = load i32, ptr %slot204, align 8
  %cv2342 = zext i32 %v2341 to i64
  %cond2343 = icmp ne i64 %cv2342, 0
  br i1 %cond2343, label %bb_rcgnn249, label %bb_rcgdone249
bb_rcgnn249:
  %v2344 = load i64, ptr %slot203, align 8
  %op2345 = sub i64 %v2344, 16
  store i64 %op2345, ptr %slot205, align 8
  %v2346 = load i64, ptr %slot203, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %rgep2348 = getelementptr i8, ptr %p2347, i64 -16
  %ld2349 = load i64, ptr %rgep2348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2349, ptr %slot206, align 8
  %v2350 = load i64, ptr %slot206, align 8
  %op2351 = and i64 %v2350, 4611686018427387906
  store i64 %op2351, ptr %slot207, align 8
  %v2352 = load i64, ptr %slot207, align 8
  %cmp2353 = icmp ne i64 %v2352, 0
  %cv2354 = zext i1 %cmp2353 to i32
  store i32 %cv2354, ptr %slot208, align 8
  %v2355 = load i32, ptr %slot208, align 8
  %cv2356 = zext i32 %v2355 to i64
  %cond2357 = icmp ne i64 %cv2356, 0
  br i1 %cond2357, label %bb_rcgclear249, label %bb_rcgcounted249
bb_rcgcounted249:
  %v2358 = load i64, ptr %slot203, align 8
  %op2359 = sub i64 %v2358, 32
  store i64 %op2359, ptr %slot209, align 8
  %v2360 = load i64, ptr %slot203, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %rgep2362 = getelementptr i8, ptr %p2361, i64 -32
  %ld2363 = load i64, ptr %rgep2362, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2363, ptr %slot210, align 8
  %v2364 = load i64, ptr %slot210, align 8
  %op2365 = sub i64 %v2364, 1
  store i64 %op2365, ptr %slot211, align 8
  %v2366 = load i64, ptr %slot211, align 8
  %cmp2367 = icmp eq i64 %v2366, 0
  %cv2368 = zext i1 %cmp2367 to i32
  store i32 %cv2368, ptr %slot212, align 8
  %v2369 = load i32, ptr %slot212, align 8
  %cv2370 = zext i32 %v2369 to i64
  %cond2371 = icmp ne i64 %cv2370, 0
  br i1 %cond2371, label %bb_rcglast249, label %bb_rcgdec249
bb_rcglast249:
  %v2372 = load i64, ptr %slot203, align 8
  %op2373 = sub i64 %v2372, 24
  store i64 %op2373, ptr %slot213, align 8
  %v2374 = load i64, ptr %slot203, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %rgep2376 = getelementptr i8, ptr %p2375, i64 -24
  %ld2377 = load i64, ptr %rgep2376, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2377, ptr %slot214, align 8
  %v2378 = load i64, ptr %slot214, align 8
  %cmp2379 = icmp ne i64 %v2378, 0
  %cv2380 = zext i1 %cmp2379 to i32
  store i32 %cv2380, ptr %slot215, align 8
  %v2381 = load i32, ptr %slot215, align 8
  %cv2382 = zext i32 %v2381 to i64
  %cond2383 = icmp ne i64 %cv2382, 0
  br i1 %cond2383, label %bb_rcgdec249, label %bb_rcgslow249
bb_rcgslow249:
  %v2384 = load i64, ptr %slot202, align 8
  %v2385 = load i64, ptr %slot185, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2384, i64 %v2385) nomerge, !dbg !120
  br label %bb_rcgdone249
bb_rcgdec249:
  %v2386 = load i64, ptr %slot211, align 8
  %v2387 = load i64, ptr %slot203, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %rgep2389 = getelementptr i8, ptr %p2388, i64 -32
  store i64 %v2386, ptr %rgep2389, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear249
bb_rcgclear249:
  %v2390 = load i64, ptr %slot185, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i64 0, ptr %p2391, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone249
bb_rcgdone249:
  br label %bb_rcslotdone218
bb_rcslotdone218:
  %v2392 = load i64, ptr %slot7, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  %ld2394 = load i32, ptr %p2393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2394, ptr %slot216, align 8
  %v2395 = load i32, ptr %slot216, align 8
  %cv2396 = zext i32 %v2395 to i64
  %cond2397 = icmp ne i64 %cv2396, 0
  br i1 %cond2397, label %bb_rcslotdrop255, label %bb_rcslotdone255
bb_rcslotdrop255:
  %v2398 = load i64, ptr %slot7, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i32 0, ptr %p2399, align 4, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot43, align 8
  store i64 %v2400, ptr %slot217, align 8
  %v2401 = load i64, ptr %slot8, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  %ld2403 = load i32, ptr %p2402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2403, ptr %slot218, align 8
  %v2404 = load i32, ptr %slot218, align 8
  %op2405 = and i32 %v2404, 28
  store i32 %op2405, ptr %slot219, align 8
  %v2406 = load i32, ptr %slot219, align 8
  %cv2407 = zext i32 %v2406 to i64
  %cond2408 = icmp ne i64 %cv2407, 0
  br i1 %cond2408, label %bb_rcslotrole255, label %bb_rcslotowner255
bb_rcslotrole255:
  %v2409 = load i64, ptr %slot64, align 8
  store i64 %v2409, ptr %slot220, align 8
  %v2410 = load i64, ptr %slot220, align 8
  %v2411 = load i64, ptr %slot217, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2410, i64 %v2411) nomerge, !dbg !120
  br label %bb_rcslotdone255
bb_rcslotowner255:
  %v2412 = load i64, ptr %slot64, align 8
  store i64 %v2412, ptr %slot221, align 8
  %v2413 = load i64, ptr %slot221, align 8
  %v2414 = load i64, ptr %slot217, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2413, i64 %v2414) nomerge, !dbg !120
  br label %bb_rcslotdone255
bb_rcslotdone255:
  %v2415 = load i64, ptr %slot5, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i32, ptr %p2416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2417, ptr %slot222, align 8
  %v2418 = load i32, ptr %slot222, align 8
  %cv2419 = zext i32 %v2418 to i64
  %cond2420 = icmp ne i64 %cv2419, 0
  br i1 %cond2420, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v2421 = load i64, ptr %slot5, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i32 0, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  %v2423 = load i64, ptr %slot42, align 8
  store i64 %v2423, ptr %slot223, align 8
  %v2424 = load i64, ptr %slot6, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  %ld2426 = load i32, ptr %p2425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2426, ptr %slot224, align 8
  %v2427 = load i32, ptr %slot224, align 8
  %op2428 = and i32 %v2427, 28
  store i32 %op2428, ptr %slot225, align 8
  %v2429 = load i32, ptr %slot225, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v2432 = load i64, ptr %slot64, align 8
  store i64 %v2432, ptr %slot226, align 8
  %v2433 = load i64, ptr %slot226, align 8
  %v2434 = load i64, ptr %slot223, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2433, i64 %v2434) nomerge, !dbg !120
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v2435 = load i64, ptr %slot64, align 8
  store i64 %v2435, ptr %slot227, align 8
  %v2436 = load i64, ptr %slot227, align 8
  %v2437 = load i64, ptr %slot223, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v2436, i64 %v2437) nomerge, !dbg !120
  br label %bb_rcslotdone264
bb_rcslotdone264:
  %v2438 = load i64, ptr %slot149, align 8
  ret i64 %v2438
bb_i14:
  %v2439 = load i64, ptr %slot39, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %ld2441 = load i64, ptr %p2440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2441, ptr %slot228, align 8
  %v2442 = load i64, ptr %slot228, align 8
  %v2443 = load i64, ptr %slot53, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  store i64 %v2442, ptr %p2444, align 8, !alias.scope !3, !noalias !4
  %v2445 = load i64, ptr %slot39, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  %ld2447 = load i64, ptr %p2446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2447, ptr %slot229, align 8
  %v2448 = load i64, ptr %slot229, align 8
  %v2449 = load i64, ptr %slot54, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i64 %v2448, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot55, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  store i64 0, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  %v2453 = load i64, ptr %slot54, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2455, ptr %slot230, align 8
  %v2456 = load i64, ptr %slot55, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i64, ptr %p2457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2458, ptr %slot231, align 8
  %v2459 = load i64, ptr %slot1, align 8
  %v2460 = load i64, ptr %slot230, align 8
  %v2461 = load i64, ptr %slot231, align 8
  %call2462 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v2459, i64 %v2460, i64 %v2461) nomerge, !dbg !122
  store { i64, i64 } %call2462, ptr %callresult233, align 8
  %addr2463 = ptrtoint ptr %callresult233 to i64
  store i64 %addr2463, ptr %slot232, align 8
  %v2464 = load i64, ptr %slot232, align 8
  %v2465 = load i64, ptr %slot54, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i64 %v2464, ptr %p2466, align 8, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot23, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  %ld2469 = load i32, ptr %p2468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2469, ptr %slot234, align 8
  %v2470 = load i32, ptr %slot234, align 8
  %cv2471 = zext i32 %v2470 to i64
  %cond2472 = icmp ne i64 %cv2471, 0
  br i1 %cond2472, label %bb_rcslotdrop296, label %bb_rcslotdone296
bb_rcslotdrop296:
  %v2473 = load i64, ptr %slot23, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  store i32 0, ptr %p2474, align 4, !alias.scope !3, !noalias !4
  %v2475 = load i64, ptr %slot31, align 8
  store i64 %v2475, ptr %slot235, align 8
  %v2476 = load i64, ptr %slot24, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %ld2478 = load i32, ptr %p2477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2478, ptr %slot236, align 8
  %v2479 = load i32, ptr %slot236, align 8
  %op2480 = and i32 %v2479, 28
  store i32 %op2480, ptr %slot237, align 8
  %v2481 = load i32, ptr %slot237, align 8
  %cv2482 = zext i32 %v2481 to i64
  %cond2483 = icmp ne i64 %cv2482, 0
  br i1 %cond2483, label %bb_rcslotrole296, label %bb_rcslotowner296
bb_rcslotrole296:
  %v2484 = load i64, ptr %slot64, align 8
  store i64 %v2484, ptr %slot238, align 8
  %v2485 = load i64, ptr %slot238, align 8
  %v2486 = load i64, ptr %slot235, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2485, i64 %v2486) nomerge, !dbg !122
  br label %bb_rcslotdone296
bb_rcslotowner296:
  %v2487 = load i64, ptr %slot64, align 8
  store i64 %v2487, ptr %slot239, align 8
  %v2488 = load i64, ptr %slot239, align 8
  %v2489 = load i64, ptr %slot235, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2488, i64 %v2489) nomerge, !dbg !122
  br label %bb_rcslotdone296
bb_rcslotdone296:
  %v2490 = load i64, ptr %slot54, align 8
  %p2491 = inttoptr i64 %v2490 to ptr
  %ld2492 = load i64, ptr %p2491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2492, ptr %slot240, align 8
  %v2493 = load i64, ptr %slot1, align 8
  %v2494 = load i64, ptr %slot240, align 8
  %call2495 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v2493, i64 %v2494) nomerge, !dbg !124
  store i64 %call2495, ptr %slot241, align 8
  %v2496 = load i64, ptr %slot241, align 8
  %v2497 = load i64, ptr %slot54, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i64 %v2496, ptr %p2498, align 8, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot53, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i64, ptr %p2500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2501, ptr %slot242, align 8
  %v2502 = load i64, ptr %slot54, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %ld2504 = load i64, ptr %p2503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2504, ptr %slot243, align 8
  %v2505 = load i64, ptr %slot1, align 8
  %v2506 = load i64, ptr %slot242, align 8
  %v2507 = load i64, ptr %slot243, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult245, i64 %v2505, i64 %v2506, i64 %v2507) nomerge, !dbg !126
  %addr2508 = ptrtoint ptr %callresult245 to i64
  store i64 %addr2508, ptr %slot244, align 8
  %v2509 = load i64, ptr %slot244, align 8
  %v2510 = load i64, ptr %slot53, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  store i64 %v2509, ptr %p2511, align 8, !alias.scope !3, !noalias !4
  %v2512 = load i64, ptr %slot53, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  %ld2514 = load i64, ptr %p2513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2514, ptr %slot246, align 8
  %v2515 = load i64, ptr %slot35, align 8
  store i64 %v2515, ptr %slot247, align 8
  %v2516 = load i64, ptr %slot246, align 8
  %v2517 = load i64, ptr %slot247, align 8
  %p2518 = inttoptr i64 %v2516 to ptr
  %p2519 = inttoptr i64 %v2517 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2519, ptr %p2518, i64 24, i1 false)
  %v2520 = load i64, ptr %slot28, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  store i32 2, ptr %p2521, align 4, !alias.scope !3, !noalias !4
  %v2522 = load i64, ptr %slot27, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i32 1, ptr %p2523, align 4, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot21, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %ld2526 = load i32, ptr %p2525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2526, ptr %slot248, align 8
  %v2527 = load i32, ptr %slot248, align 8
  %cv2528 = zext i32 %v2527 to i64
  %cond2529 = icmp ne i64 %cv2528, 0
  br i1 %cond2529, label %bb_rcslotdrop314, label %bb_rcslotdone314
bb_rcslotdrop314:
  %v2530 = load i64, ptr %slot21, align 8
  %p2531 = inttoptr i64 %v2530 to ptr
  store i32 0, ptr %p2531, align 4, !alias.scope !3, !noalias !4
  %v2532 = load i64, ptr %slot30, align 8
  store i64 %v2532, ptr %slot249, align 8
  %v2533 = load i64, ptr %slot22, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i32, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2535, ptr %slot250, align 8
  %v2536 = load i32, ptr %slot250, align 8
  %op2537 = and i32 %v2536, 28
  store i32 %op2537, ptr %slot251, align 8
  %v2538 = load i32, ptr %slot251, align 8
  %cv2539 = zext i32 %v2538 to i64
  %cond2540 = icmp ne i64 %cv2539, 0
  br i1 %cond2540, label %bb_rcslotrole314, label %bb_rcslotowner314
bb_rcslotrole314:
  %v2541 = load i64, ptr %slot64, align 8
  store i64 %v2541, ptr %slot252, align 8
  %v2542 = load i64, ptr %slot252, align 8
  %v2543 = load i64, ptr %slot249, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2542, i64 %v2543) nomerge, !dbg !126
  br label %bb_rcslotdone314
bb_rcslotowner314:
  %v2544 = load i64, ptr %slot64, align 8
  store i64 %v2544, ptr %slot253, align 8
  %v2545 = load i64, ptr %slot253, align 8
  %v2546 = load i64, ptr %slot249, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2545, i64 %v2546) nomerge, !dbg !126
  br label %bb_rcslotdone314
bb_rcslotdone314:
  %v2547 = load i64, ptr %slot30, align 8
  store i64 %v2547, ptr %slot254, align 8
  %v2548 = load i64, ptr %slot35, align 8
  store i64 %v2548, ptr %slot255, align 8
  %v2549 = load i64, ptr %slot255, align 8
  %v2550 = load i64, ptr %slot254, align 8
  %p2551 = inttoptr i64 %v2549 to ptr
  %p2552 = inttoptr i64 %v2550 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2552, ptr %p2551, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2553 = load i64, ptr %slot22, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  store i32 2, ptr %p2554, align 4, !alias.scope !3, !noalias !4
  %v2555 = load i64, ptr %slot28, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %ld2557 = load i32, ptr %p2556, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2557, ptr %slot256, align 8
  %v2558 = load i32, ptr %slot256, align 8
  %v2559 = load i64, ptr %slot22, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  store i32 %v2558, ptr %p2560, align 4, !alias.scope !3, !noalias !4
  %v2561 = load i64, ptr %slot27, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  store i32 0, ptr %p2562, align 4, !alias.scope !3, !noalias !4
  %v2563 = load i64, ptr %slot21, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  store i32 1, ptr %p2564, align 4, !alias.scope !3, !noalias !4
  %v2565 = load i64, ptr %slot254, align 8
  %v2566 = load i64, ptr %slot53, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i64 %v2565, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot53, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  %ld2570 = load i64, ptr %p2569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2570, ptr %slot257, align 8
  %v2571 = load i64, ptr %slot257, align 8
  %op2572 = add i64 %v2571, 8
  store i64 %op2572, ptr %slot258, align 8
  %v2573 = load i64, ptr %slot258, align 8
  %v2574 = load i64, ptr %slot53, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  store i64 %v2573, ptr %p2575, align 8, !alias.scope !3, !noalias !4
  %v2576 = load i64, ptr %slot53, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i64, ptr %p2577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2578, ptr %slot259, align 8
  %v2579 = load i64, ptr %slot35, align 8
  store i64 %v2579, ptr %slot260, align 8
  %v2580 = load i64, ptr %slot64, align 8
  %v2581 = load i64, ptr %slot260, align 8
  %v2582 = load i64, ptr %slot259, align 8
  %call2583 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v2580, i64 %v2581, i64 %v2582) nomerge, !dbg !128
  store i32 %call2583, ptr %slot261, align 8
  %v2584 = load i32, ptr %slot261, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcsuccess334, label %bb_rcfailure334
bb_rcfailure334:
  %v2587 = load i64, ptr %slot64, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  %call2589 = call i32 @myl_rc_take_failure(ptr %p2588) nomerge, !dbg !128
  store i32 %call2589, ptr %slot262, align 8
  %v2590 = load i64, ptr %slot1, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  %v2592 = load i32, ptr %slot262, align 8
  %call2593 = call i32 @myl_qbe_rc_status(ptr %p2591, i32 %v2592) nomerge, !dbg !128
  store i32 %call2593, ptr %slot263, align 8
  br label %bb_failure
bb_rcsuccess334:
  %v2594 = load i64, ptr %slot28, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  store i32 2, ptr %p2595, align 4, !alias.scope !3, !noalias !4
  %v2596 = load i64, ptr %slot28, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  store i32 16, ptr %p2597, align 4, !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot27, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  store i32 1, ptr %p2599, align 4, !alias.scope !3, !noalias !4
  %v2600 = load i64, ptr %slot21, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %ld2602 = load i32, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2602, ptr %slot264, align 8
  %v2603 = load i32, ptr %slot264, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcslotdrop342, label %bb_rcslotdone342
bb_rcslotdrop342:
  %v2606 = load i64, ptr %slot21, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  store i32 0, ptr %p2607, align 4, !alias.scope !3, !noalias !4
  %v2608 = load i64, ptr %slot30, align 8
  store i64 %v2608, ptr %slot265, align 8
  %v2609 = load i64, ptr %slot22, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %ld2611 = load i32, ptr %p2610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2611, ptr %slot266, align 8
  %v2612 = load i32, ptr %slot266, align 8
  %op2613 = and i32 %v2612, 28
  store i32 %op2613, ptr %slot267, align 8
  %v2614 = load i32, ptr %slot267, align 8
  %cv2615 = zext i32 %v2614 to i64
  %cond2616 = icmp ne i64 %cv2615, 0
  br i1 %cond2616, label %bb_rcslotrole342, label %bb_rcslotowner342
bb_rcslotrole342:
  %v2617 = load i64, ptr %slot64, align 8
  store i64 %v2617, ptr %slot268, align 8
  %v2618 = load i64, ptr %slot268, align 8
  %v2619 = load i64, ptr %slot265, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2618, i64 %v2619) nomerge, !dbg !128
  br label %bb_rcslotdone342
bb_rcslotowner342:
  %v2620 = load i64, ptr %slot64, align 8
  store i64 %v2620, ptr %slot269, align 8
  %v2621 = load i64, ptr %slot269, align 8
  %v2622 = load i64, ptr %slot265, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2621, i64 %v2622) nomerge, !dbg !128
  br label %bb_rcslotdone342
bb_rcslotdone342:
  %v2623 = load i64, ptr %slot30, align 8
  store i64 %v2623, ptr %slot270, align 8
  %v2624 = load i64, ptr %slot35, align 8
  store i64 %v2624, ptr %slot271, align 8
  %v2625 = load i64, ptr %slot271, align 8
  %v2626 = load i64, ptr %slot270, align 8
  %p2627 = inttoptr i64 %v2625 to ptr
  %p2628 = inttoptr i64 %v2626 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2628, ptr %p2627, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot22, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i32 2, ptr %p2630, align 4, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot28, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %ld2633 = load i32, ptr %p2632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2633, ptr %slot272, align 8
  %v2634 = load i32, ptr %slot272, align 8
  %v2635 = load i64, ptr %slot22, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i32 %v2634, ptr %p2636, align 4, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot27, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 0, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot21, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 1, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot270, align 8
  %v2642 = load i64, ptr %slot53, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  store i64 %v2641, ptr %p2643, align 8, !alias.scope !3, !noalias !4
  %v2644 = load i64, ptr %slot53, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  %ld2646 = load i64, ptr %p2645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2646, ptr %slot273, align 8
  %v2647 = load i64, ptr %slot21, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %ld2649 = load i32, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2649, ptr %slot274, align 8
  %v2650 = load i64, ptr %slot22, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot275, align 8
  %v2653 = load i32, ptr %slot275, align 8
  %op2654 = and i32 %v2653, 24
  store i32 %op2654, ptr %slot275, align 8
  %v2655 = load i32, ptr %slot275, align 8
  %cmp2656 = icmp eq i32 %v2655, 0
  %cv2657 = zext i1 %cmp2656 to i32
  store i32 %cv2657, ptr %slot276, align 8
  %v2658 = load i32, ptr %slot274, align 8
  %v2659 = load i32, ptr %slot276, align 8
  %op2660 = and i32 %v2658, %v2659
  store i32 %op2660, ptr %slot277, align 8
  %v2661 = load i32, ptr %slot277, align 8
  %cv2662 = zext i32 %v2661 to i64
  %cond2663 = icmp ne i64 %cv2662, 0
  br i1 %cond2663, label %bb_rctake358, label %bb_rccopy358
bb_rctake358:
  %v2664 = load i64, ptr %slot35, align 8
  store i64 %v2664, ptr %slot278, align 8
  %v2665 = load i64, ptr %slot65, align 8
  store i64 %v2665, ptr %slot279, align 8
  %v2666 = load i64, ptr %slot273, align 8
  %v2667 = load i64, ptr %slot278, align 8
  %op2668 = sub i64 %v2666, %v2667
  store i64 %op2668, ptr %slot280, align 8
  %v2669 = load i64, ptr %slot278, align 8
  %v2670 = load i64, ptr %slot273, align 8
  %op2671 = sub i64 %v2669, %v2670
  store i64 %op2671, ptr %slot281, align 8
  %v2672 = load i64, ptr %slot280, align 8
  %cmp2673 = icmp ult i64 %v2672, 16
  %cv2674 = zext i1 %cmp2673 to i32
  store i32 %cv2674, ptr %slot282, align 8
  %v2675 = load i64, ptr %slot281, align 8
  %cmp2676 = icmp ult i64 %v2675, 16
  %cv2677 = zext i1 %cmp2676 to i32
  store i32 %cv2677, ptr %slot283, align 8
  %v2678 = load i32, ptr %slot282, align 8
  %v2679 = load i32, ptr %slot283, align 8
  %op2680 = or i32 %v2678, %v2679
  store i32 %op2680, ptr %slot284, align 8
  %v2681 = load i32, ptr %slot284, align 8
  %cv2682 = zext i32 %v2681 to i64
  %cond2683 = icmp ne i64 %cv2682, 0
  br i1 %cond2683, label %bb_rcmoveslow367, label %bb_rcmovecheck367
bb_rcmovecheck367:
  %v2684 = load i64, ptr %slot273, align 8
  %op2685 = add i64 %v2684, 0
  store i64 %op2685, ptr %slot285, align 8
  %v2686 = load i64, ptr %slot285, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  %ld2688 = load i64, ptr %p2687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2688, ptr %slot286, align 8
  %v2689 = load i64, ptr %slot286, align 8
  %cmp2690 = icmp ne i64 %v2689, 0
  %cv2691 = zext i1 %cmp2690 to i32
  store i32 %cv2691, ptr %slot287, align 8
  %v2692 = load i32, ptr %slot287, align 8
  %cv2693 = zext i32 %v2692 to i64
  %cond2694 = icmp ne i64 %cv2693, 0
  br i1 %cond2694, label %bb_rcmoveheader375, label %bb_rcmovenext375
bb_rcmoveheader375:
  %v2695 = load i64, ptr %slot286, align 8
  %op2696 = sub i64 %v2695, 16
  store i64 %op2696, ptr %slot288, align 8
  %v2697 = load i64, ptr %slot286, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %rgep2699 = getelementptr i8, ptr %p2698, i64 -16
  %ld2700 = load i64, ptr %rgep2699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2700, ptr %slot289, align 8
  %v2701 = load i64, ptr %slot289, align 8
  %op2702 = and i64 %v2701, 5764607523034234881
  store i64 %op2702, ptr %slot290, align 8
  %v2703 = load i64, ptr %slot290, align 8
  %cmp2704 = icmp ne i64 %v2703, 0
  %cv2705 = zext i1 %cmp2704 to i32
  store i32 %cv2705, ptr %slot291, align 8
  %v2706 = load i32, ptr %slot291, align 8
  %cv2707 = zext i32 %v2706 to i64
  %cond2708 = icmp ne i64 %cv2707, 0
  br i1 %cond2708, label %bb_rcmoveslow367, label %bb_rcmovenext375
bb_rcmovenext375:
  %v2709 = load i64, ptr %slot273, align 8
  %v2710 = load i64, ptr %slot278, align 8
  %p2711 = inttoptr i64 %v2709 to ptr
  %p2712 = inttoptr i64 %v2710 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2712, ptr %p2711, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2713 = load i64, ptr %slot273, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  store i64 0, ptr %p2714, align 8, !alias.scope !3, !noalias !4
  %v2715 = load i64, ptr %slot273, align 8
  %op2716 = add i64 %v2715, 8
  store i64 %op2716, ptr %slot292, align 8
  %v2717 = load i64, ptr %slot292, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  store i64 0, ptr %p2718, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved367
bb_rcmoveslow367:
  %v2719 = load i64, ptr %slot64, align 8
  %v2720 = load i64, ptr %slot278, align 8
  %v2721 = load i64, ptr %slot273, align 8
  %v2722 = load i64, ptr %slot279, align 8
  %cv2723 = trunc i64 %v2722 to i32
  %call2724 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2719, i64 %v2720, i64 %v2721, i32 %cv2723) nomerge, !dbg !130
  store i32 %call2724, ptr %slot293, align 8
  %v2725 = load i32, ptr %slot293, align 8
  %cv2726 = zext i32 %v2725 to i64
  %cond2727 = icmp ne i64 %cv2726, 0
  br i1 %cond2727, label %bb_rcsuccess383, label %bb_rcfailure383
bb_rcfailure383:
  %v2728 = load i64, ptr %slot64, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %call2730 = call i32 @myl_rc_take_failure(ptr %p2729) nomerge, !dbg !130
  store i32 %call2730, ptr %slot294, align 8
  %v2731 = load i64, ptr %slot1, align 8
  %p2732 = inttoptr i64 %v2731 to ptr
  %v2733 = load i32, ptr %slot294, align 8
  %call2734 = call i32 @myl_qbe_rc_status(ptr %p2732, i32 %v2733) nomerge, !dbg !130
  store i32 %call2734, ptr %slot295, align 8
  br label %bb_failure
bb_rcsuccess383:
  br label %bb_rcmoved367
bb_rcmoved367:
  %v2735 = load i64, ptr %slot21, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  store i32 0, ptr %p2736, align 4, !alias.scope !3, !noalias !4
  %v2737 = load i64, ptr %slot28, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i32 2, ptr %p2738, align 4, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot27, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  store i32 1, ptr %p2740, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared358
bb_rccopy358:
  %v2741 = load i64, ptr %slot35, align 8
  store i64 %v2741, ptr %slot296, align 8
  %v2742 = load i64, ptr %slot65, align 8
  store i64 %v2742, ptr %slot297, align 8
  %v2743 = load i64, ptr %slot64, align 8
  %v2744 = load i64, ptr %slot296, align 8
  %v2745 = load i64, ptr %slot273, align 8
  %v2746 = load i64, ptr %slot297, align 8
  %cv2747 = trunc i64 %v2746 to i32
  %call2748 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v2743, i64 %v2744, i64 %v2745, i32 %cv2747) nomerge, !dbg !130
  store i32 %call2748, ptr %slot298, align 8
  %v2749 = load i32, ptr %slot298, align 8
  %cv2750 = zext i32 %v2749 to i64
  %cond2751 = icmp ne i64 %cv2750, 0
  br i1 %cond2751, label %bb_rcsuccess392, label %bb_rcfailure392
bb_rcfailure392:
  %v2752 = load i64, ptr %slot64, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %call2754 = call i32 @myl_rc_take_failure(ptr %p2753) nomerge, !dbg !130
  store i32 %call2754, ptr %slot299, align 8
  %v2755 = load i64, ptr %slot1, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  %v2757 = load i32, ptr %slot299, align 8
  %call2758 = call i32 @myl_qbe_rc_status(ptr %p2756, i32 %v2757) nomerge, !dbg !130
  store i32 %call2758, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess392:
  %v2759 = load i64, ptr %slot28, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  store i32 2, ptr %p2760, align 4, !alias.scope !3, !noalias !4
  %v2761 = load i64, ptr %slot27, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  store i32 1, ptr %p2762, align 4, !alias.scope !3, !noalias !4
  %v2763 = load i64, ptr %slot21, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i32, ptr %p2764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2765, ptr %slot301, align 8
  %v2766 = load i32, ptr %slot301, align 8
  %cv2767 = zext i32 %v2766 to i64
  %cond2768 = icmp ne i64 %cv2767, 0
  br i1 %cond2768, label %bb_rcslotdrop399, label %bb_rcslotdone399
bb_rcslotdrop399:
  %v2769 = load i64, ptr %slot21, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  store i32 0, ptr %p2770, align 4, !alias.scope !3, !noalias !4
  %v2771 = load i64, ptr %slot30, align 8
  store i64 %v2771, ptr %slot302, align 8
  %v2772 = load i64, ptr %slot22, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  %ld2774 = load i32, ptr %p2773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2774, ptr %slot303, align 8
  %v2775 = load i32, ptr %slot303, align 8
  %op2776 = and i32 %v2775, 28
  store i32 %op2776, ptr %slot304, align 8
  %v2777 = load i32, ptr %slot304, align 8
  %cv2778 = zext i32 %v2777 to i64
  %cond2779 = icmp ne i64 %cv2778, 0
  br i1 %cond2779, label %bb_rcslotrole399, label %bb_rcslotowner399
bb_rcslotrole399:
  %v2780 = load i64, ptr %slot64, align 8
  store i64 %v2780, ptr %slot305, align 8
  %v2781 = load i64, ptr %slot305, align 8
  %v2782 = load i64, ptr %slot302, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2781, i64 %v2782) nomerge, !dbg !130
  br label %bb_rcslotdone399
bb_rcslotowner399:
  %v2783 = load i64, ptr %slot302, align 8
  %p2785 = inttoptr i64 %v2783 to ptr
  %gep2786 = getelementptr i8, ptr %p2785, i64 0
  %op2784 = ptrtoint ptr %gep2786 to i64
  store i64 %op2784, ptr %slot306, align 8
  %v2787 = load i64, ptr %slot64, align 8
  store i64 %v2787, ptr %slot307, align 8
  %v2788 = load i64, ptr %slot306, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2790, ptr %slot308, align 8
  %v2791 = load i64, ptr %slot308, align 8
  %cmp2792 = icmp ne i64 %v2791, 0
  %cv2793 = zext i1 %cmp2792 to i32
  store i32 %cv2793, ptr %slot309, align 8
  %v2794 = load i32, ptr %slot309, align 8
  %cv2795 = zext i32 %v2794 to i64
  %cond2796 = icmp ne i64 %cv2795, 0
  br i1 %cond2796, label %bb_rcgnn417, label %bb_rcgdone417
bb_rcgnn417:
  %v2797 = load i64, ptr %slot308, align 8
  %op2798 = sub i64 %v2797, 16
  store i64 %op2798, ptr %slot310, align 8
  %v2799 = load i64, ptr %slot308, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  %rgep2801 = getelementptr i8, ptr %p2800, i64 -16
  %ld2802 = load i64, ptr %rgep2801, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2802, ptr %slot311, align 8
  %v2803 = load i64, ptr %slot311, align 8
  %op2804 = and i64 %v2803, 4611686018427387906
  store i64 %op2804, ptr %slot312, align 8
  %v2805 = load i64, ptr %slot312, align 8
  %cmp2806 = icmp ne i64 %v2805, 0
  %cv2807 = zext i1 %cmp2806 to i32
  store i32 %cv2807, ptr %slot313, align 8
  %v2808 = load i32, ptr %slot313, align 8
  %cv2809 = zext i32 %v2808 to i64
  %cond2810 = icmp ne i64 %cv2809, 0
  br i1 %cond2810, label %bb_rcgclear417, label %bb_rcgcounted417
bb_rcgcounted417:
  %v2811 = load i64, ptr %slot308, align 8
  %op2812 = sub i64 %v2811, 32
  store i64 %op2812, ptr %slot314, align 8
  %v2813 = load i64, ptr %slot308, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  %rgep2815 = getelementptr i8, ptr %p2814, i64 -32
  %ld2816 = load i64, ptr %rgep2815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2816, ptr %slot315, align 8
  %v2817 = load i64, ptr %slot315, align 8
  %op2818 = sub i64 %v2817, 1
  store i64 %op2818, ptr %slot316, align 8
  %v2819 = load i64, ptr %slot316, align 8
  %cmp2820 = icmp eq i64 %v2819, 0
  %cv2821 = zext i1 %cmp2820 to i32
  store i32 %cv2821, ptr %slot317, align 8
  %v2822 = load i32, ptr %slot317, align 8
  %cv2823 = zext i32 %v2822 to i64
  %cond2824 = icmp ne i64 %cv2823, 0
  br i1 %cond2824, label %bb_rcglast417, label %bb_rcgdec417
bb_rcglast417:
  %v2825 = load i64, ptr %slot308, align 8
  %op2826 = sub i64 %v2825, 24
  store i64 %op2826, ptr %slot318, align 8
  %v2827 = load i64, ptr %slot308, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  %rgep2829 = getelementptr i8, ptr %p2828, i64 -24
  %ld2830 = load i64, ptr %rgep2829, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2830, ptr %slot319, align 8
  %v2831 = load i64, ptr %slot319, align 8
  %cmp2832 = icmp ne i64 %v2831, 0
  %cv2833 = zext i1 %cmp2832 to i32
  store i32 %cv2833, ptr %slot320, align 8
  %v2834 = load i32, ptr %slot320, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcgdec417, label %bb_rcgslow417
bb_rcgslow417:
  %v2837 = load i64, ptr %slot307, align 8
  %v2838 = load i64, ptr %slot306, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2837, i64 %v2838) nomerge, !dbg !130
  br label %bb_rcgdone417
bb_rcgdec417:
  %v2839 = load i64, ptr %slot316, align 8
  %v2840 = load i64, ptr %slot308, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %rgep2842 = getelementptr i8, ptr %p2841, i64 -32
  store i64 %v2839, ptr %rgep2842, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear417
bb_rcgclear417:
  %v2843 = load i64, ptr %slot306, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i64 0, ptr %p2844, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone417
bb_rcgdone417:
  %v2845 = load i64, ptr %slot302, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  store i64 0, ptr %p2846, align 8, !alias.scope !3, !noalias !4
  %v2847 = load i64, ptr %slot302, align 8
  %p2849 = inttoptr i64 %v2847 to ptr
  %gep2850 = getelementptr i8, ptr %p2849, i64 8
  %op2848 = ptrtoint ptr %gep2850 to i64
  store i64 %op2848, ptr %slot321, align 8
  %v2851 = load i64, ptr %slot321, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i64 0, ptr %p2852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone399
bb_rcslotdone399:
  br label %bb_rcprepared358
bb_rcprepared358:
  %v2853 = load i64, ptr %slot5, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  %ld2855 = load i32, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2855, ptr %slot322, align 8
  %v2856 = load i32, ptr %slot322, align 8
  %cv2857 = zext i32 %v2856 to i64
  %cond2858 = icmp ne i64 %cv2857, 0
  br i1 %cond2858, label %bb_rcslotdrop425, label %bb_rcslotdone425
bb_rcslotdrop425:
  %v2859 = load i64, ptr %slot5, align 8
  %p2860 = inttoptr i64 %v2859 to ptr
  store i32 0, ptr %p2860, align 4, !alias.scope !3, !noalias !4
  %v2861 = load i64, ptr %slot42, align 8
  store i64 %v2861, ptr %slot323, align 8
  %v2862 = load i64, ptr %slot6, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  %ld2864 = load i32, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2864, ptr %slot324, align 8
  %v2865 = load i32, ptr %slot324, align 8
  %op2866 = and i32 %v2865, 28
  store i32 %op2866, ptr %slot325, align 8
  %v2867 = load i32, ptr %slot325, align 8
  %cv2868 = zext i32 %v2867 to i64
  %cond2869 = icmp ne i64 %cv2868, 0
  br i1 %cond2869, label %bb_rcslotrole425, label %bb_rcslotowner425
bb_rcslotrole425:
  %v2870 = load i64, ptr %slot64, align 8
  store i64 %v2870, ptr %slot326, align 8
  %v2871 = load i64, ptr %slot326, align 8
  %v2872 = load i64, ptr %slot323, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v2871, i64 %v2872) nomerge, !dbg !130
  br label %bb_rcslotdone425
bb_rcslotowner425:
  %v2873 = load i64, ptr %slot323, align 8
  %p2875 = inttoptr i64 %v2873 to ptr
  %gep2876 = getelementptr i8, ptr %p2875, i64 0
  %op2874 = ptrtoint ptr %gep2876 to i64
  store i64 %op2874, ptr %slot327, align 8
  %v2877 = load i64, ptr %slot64, align 8
  store i64 %v2877, ptr %slot328, align 8
  %v2878 = load i64, ptr %slot327, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i64, ptr %p2879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2880, ptr %slot329, align 8
  %v2881 = load i64, ptr %slot329, align 8
  %cmp2882 = icmp ne i64 %v2881, 0
  %cv2883 = zext i1 %cmp2882 to i32
  store i32 %cv2883, ptr %slot330, align 8
  %v2884 = load i32, ptr %slot330, align 8
  %cv2885 = zext i32 %v2884 to i64
  %cond2886 = icmp ne i64 %cv2885, 0
  br i1 %cond2886, label %bb_rcgnn443, label %bb_rcgdone443
bb_rcgnn443:
  %v2887 = load i64, ptr %slot329, align 8
  %op2888 = sub i64 %v2887, 16
  store i64 %op2888, ptr %slot331, align 8
  %v2889 = load i64, ptr %slot329, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %rgep2891 = getelementptr i8, ptr %p2890, i64 -16
  %ld2892 = load i64, ptr %rgep2891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2892, ptr %slot332, align 8
  %v2893 = load i64, ptr %slot332, align 8
  %op2894 = and i64 %v2893, 4611686018427387906
  store i64 %op2894, ptr %slot333, align 8
  %v2895 = load i64, ptr %slot333, align 8
  %cmp2896 = icmp ne i64 %v2895, 0
  %cv2897 = zext i1 %cmp2896 to i32
  store i32 %cv2897, ptr %slot334, align 8
  %v2898 = load i32, ptr %slot334, align 8
  %cv2899 = zext i32 %v2898 to i64
  %cond2900 = icmp ne i64 %cv2899, 0
  br i1 %cond2900, label %bb_rcgclear443, label %bb_rcgcounted443
bb_rcgcounted443:
  %v2901 = load i64, ptr %slot329, align 8
  %op2902 = sub i64 %v2901, 32
  store i64 %op2902, ptr %slot335, align 8
  %v2903 = load i64, ptr %slot329, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  %rgep2905 = getelementptr i8, ptr %p2904, i64 -32
  %ld2906 = load i64, ptr %rgep2905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2906, ptr %slot336, align 8
  %v2907 = load i64, ptr %slot336, align 8
  %op2908 = sub i64 %v2907, 1
  store i64 %op2908, ptr %slot337, align 8
  %v2909 = load i64, ptr %slot337, align 8
  %cmp2910 = icmp eq i64 %v2909, 0
  %cv2911 = zext i1 %cmp2910 to i32
  store i32 %cv2911, ptr %slot338, align 8
  %v2912 = load i32, ptr %slot338, align 8
  %cv2913 = zext i32 %v2912 to i64
  %cond2914 = icmp ne i64 %cv2913, 0
  br i1 %cond2914, label %bb_rcglast443, label %bb_rcgdec443
bb_rcglast443:
  %v2915 = load i64, ptr %slot329, align 8
  %op2916 = sub i64 %v2915, 24
  store i64 %op2916, ptr %slot339, align 8
  %v2917 = load i64, ptr %slot329, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  %rgep2919 = getelementptr i8, ptr %p2918, i64 -24
  %ld2920 = load i64, ptr %rgep2919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2920, ptr %slot340, align 8
  %v2921 = load i64, ptr %slot340, align 8
  %cmp2922 = icmp ne i64 %v2921, 0
  %cv2923 = zext i1 %cmp2922 to i32
  store i32 %cv2923, ptr %slot341, align 8
  %v2924 = load i32, ptr %slot341, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcgdec443, label %bb_rcgslow443
bb_rcgslow443:
  %v2927 = load i64, ptr %slot328, align 8
  %v2928 = load i64, ptr %slot327, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2927, i64 %v2928) nomerge, !dbg !130
  br label %bb_rcgdone443
bb_rcgdec443:
  %v2929 = load i64, ptr %slot337, align 8
  %v2930 = load i64, ptr %slot329, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %rgep2932 = getelementptr i8, ptr %p2931, i64 -32
  store i64 %v2929, ptr %rgep2932, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear443
bb_rcgclear443:
  %v2933 = load i64, ptr %slot327, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  store i64 0, ptr %p2934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone443
bb_rcgdone443:
  %v2935 = load i64, ptr %slot323, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i64 0, ptr %p2936, align 8, !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot323, align 8
  %p2939 = inttoptr i64 %v2937 to ptr
  %gep2940 = getelementptr i8, ptr %p2939, i64 8
  %op2938 = ptrtoint ptr %gep2940 to i64
  store i64 %op2938, ptr %slot342, align 8
  %v2941 = load i64, ptr %slot342, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  store i64 0, ptr %p2942, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone425
bb_rcslotdone425:
  %v2943 = load i64, ptr %slot42, align 8
  store i64 %v2943, ptr %slot343, align 8
  %v2944 = load i64, ptr %slot35, align 8
  store i64 %v2944, ptr %slot344, align 8
  %v2945 = load i64, ptr %slot344, align 8
  %v2946 = load i64, ptr %slot343, align 8
  %p2947 = inttoptr i64 %v2945 to ptr
  %p2948 = inttoptr i64 %v2946 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2948, ptr %p2947, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot27, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i32 0, ptr %p2950, align 4, !alias.scope !3, !noalias !4
  %v2951 = load i64, ptr %slot6, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  store i32 2, ptr %p2952, align 4, !alias.scope !3, !noalias !4
  %v2953 = load i64, ptr %slot28, align 8
  %p2954 = inttoptr i64 %v2953 to ptr
  %ld2955 = load i32, ptr %p2954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2955, ptr %slot345, align 8
  %v2956 = load i32, ptr %slot345, align 8
  %v2957 = load i64, ptr %slot6, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  store i32 %v2956, ptr %p2958, align 4, !alias.scope !3, !noalias !4
  %v2959 = load i64, ptr %slot5, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  store i32 1, ptr %p2960, align 4, !alias.scope !3, !noalias !4
  %v2961 = load i64, ptr %slot39, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  %ld2963 = load i64, ptr %p2962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2963, ptr %slot346, align 8
  %v2964 = load i64, ptr %slot346, align 8
  %v2965 = load i64, ptr %slot53, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  store i64 %v2964, ptr %p2966, align 8, !alias.scope !3, !noalias !4
  %v2967 = load i64, ptr %slot41, align 8
  %v2968 = load i64, ptr %slot54, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i64 %v2967, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot54, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  %ld2972 = load i64, ptr %p2971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2972, ptr %slot347, align 8
  %v2973 = load i64, ptr %slot1, align 8
  %v2974 = load i64, ptr %slot347, align 8
  %call2975 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v2973, i64 %v2974) nomerge, !dbg !132
  store i64 %call2975, ptr %slot348, align 8
  %v2976 = load i64, ptr %slot348, align 8
  %v2977 = load i64, ptr %slot54, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  store i64 %v2976, ptr %p2978, align 8, !alias.scope !3, !noalias !4
  %v2979 = load i64, ptr %slot53, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  %ld2981 = load i64, ptr %p2980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2981, ptr %slot349, align 8
  %v2982 = load i64, ptr %slot54, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %ld2984 = load i64, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2984, ptr %slot350, align 8
  %v2985 = load i64, ptr %slot1, align 8
  %v2986 = load i64, ptr %slot349, align 8
  %v2987 = load i64, ptr %slot350, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult352, i64 %v2985, i64 %v2986, i64 %v2987) nomerge, !dbg !134
  %addr2988 = ptrtoint ptr %callresult352 to i64
  store i64 %addr2988, ptr %slot351, align 8
  %v2989 = load i64, ptr %slot351, align 8
  %v2990 = load i64, ptr %slot53, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  store i64 %v2989, ptr %p2991, align 8, !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot53, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  %ld2994 = load i64, ptr %p2993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2994, ptr %slot353, align 8
  %v2995 = load i64, ptr %slot35, align 8
  store i64 %v2995, ptr %slot354, align 8
  %v2996 = load i64, ptr %slot353, align 8
  %v2997 = load i64, ptr %slot354, align 8
  %p2998 = inttoptr i64 %v2996 to ptr
  %p2999 = inttoptr i64 %v2997 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2999, ptr %p2998, i64 24, i1 false)
  %v3000 = load i64, ptr %slot28, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  store i32 2, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  %v3002 = load i64, ptr %slot27, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  store i32 1, ptr %p3003, align 4, !alias.scope !3, !noalias !4
  %v3004 = load i64, ptr %slot21, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  %ld3006 = load i32, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3006, ptr %slot355, align 8
  %v3007 = load i32, ptr %slot355, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcslotdrop467, label %bb_rcslotdone467
bb_rcslotdrop467:
  %v3010 = load i64, ptr %slot21, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i32 0, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot30, align 8
  store i64 %v3012, ptr %slot356, align 8
  %v3013 = load i64, ptr %slot22, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i32, ptr %p3014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3015, ptr %slot357, align 8
  %v3016 = load i32, ptr %slot357, align 8
  %op3017 = and i32 %v3016, 28
  store i32 %op3017, ptr %slot358, align 8
  %v3018 = load i32, ptr %slot358, align 8
  %cv3019 = zext i32 %v3018 to i64
  %cond3020 = icmp ne i64 %cv3019, 0
  br i1 %cond3020, label %bb_rcslotrole467, label %bb_rcslotowner467
bb_rcslotrole467:
  %v3021 = load i64, ptr %slot64, align 8
  store i64 %v3021, ptr %slot359, align 8
  %v3022 = load i64, ptr %slot359, align 8
  %v3023 = load i64, ptr %slot356, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3022, i64 %v3023) nomerge, !dbg !134
  br label %bb_rcslotdone467
bb_rcslotowner467:
  %v3024 = load i64, ptr %slot64, align 8
  store i64 %v3024, ptr %slot360, align 8
  %v3025 = load i64, ptr %slot360, align 8
  %v3026 = load i64, ptr %slot356, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3025, i64 %v3026) nomerge, !dbg !134
  br label %bb_rcslotdone467
bb_rcslotdone467:
  %v3027 = load i64, ptr %slot30, align 8
  store i64 %v3027, ptr %slot361, align 8
  %v3028 = load i64, ptr %slot35, align 8
  store i64 %v3028, ptr %slot362, align 8
  %v3029 = load i64, ptr %slot362, align 8
  %v3030 = load i64, ptr %slot361, align 8
  %p3031 = inttoptr i64 %v3029 to ptr
  %p3032 = inttoptr i64 %v3030 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3032, ptr %p3031, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3033 = load i64, ptr %slot22, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  store i32 2, ptr %p3034, align 4, !alias.scope !3, !noalias !4
  %v3035 = load i64, ptr %slot28, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  %ld3037 = load i32, ptr %p3036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3037, ptr %slot363, align 8
  %v3038 = load i32, ptr %slot363, align 8
  %v3039 = load i64, ptr %slot22, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  store i32 %v3038, ptr %p3040, align 4, !alias.scope !3, !noalias !4
  %v3041 = load i64, ptr %slot27, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  store i32 0, ptr %p3042, align 4, !alias.scope !3, !noalias !4
  %v3043 = load i64, ptr %slot21, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  store i32 1, ptr %p3044, align 4, !alias.scope !3, !noalias !4
  %v3045 = load i64, ptr %slot361, align 8
  %v3046 = load i64, ptr %slot53, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i64 %v3045, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot53, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i64, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3050, ptr %slot364, align 8
  %v3051 = load i64, ptr %slot364, align 8
  %op3052 = add i64 %v3051, 8
  store i64 %op3052, ptr %slot365, align 8
  %v3053 = load i64, ptr %slot365, align 8
  %v3054 = load i64, ptr %slot53, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i64 %v3053, ptr %p3055, align 8, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot53, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  %ld3058 = load i64, ptr %p3057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3058, ptr %slot366, align 8
  %v3059 = load i64, ptr %slot35, align 8
  store i64 %v3059, ptr %slot367, align 8
  %v3060 = load i64, ptr %slot64, align 8
  %v3061 = load i64, ptr %slot367, align 8
  %v3062 = load i64, ptr %slot366, align 8
  %call3063 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v3060, i64 %v3061, i64 %v3062) nomerge, !dbg !136
  store i32 %call3063, ptr %slot368, align 8
  %v3064 = load i32, ptr %slot368, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcsuccess487, label %bb_rcfailure487
bb_rcfailure487:
  %v3067 = load i64, ptr %slot64, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  %call3069 = call i32 @myl_rc_take_failure(ptr %p3068) nomerge, !dbg !136
  store i32 %call3069, ptr %slot369, align 8
  %v3070 = load i64, ptr %slot1, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %v3072 = load i32, ptr %slot369, align 8
  %call3073 = call i32 @myl_qbe_rc_status(ptr %p3071, i32 %v3072) nomerge, !dbg !136
  store i32 %call3073, ptr %slot370, align 8
  br label %bb_failure
bb_rcsuccess487:
  %v3074 = load i64, ptr %slot28, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i32 2, ptr %p3075, align 4, !alias.scope !3, !noalias !4
  %v3076 = load i64, ptr %slot28, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i32 16, ptr %p3077, align 4, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot27, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i32 1, ptr %p3079, align 4, !alias.scope !3, !noalias !4
  %v3080 = load i64, ptr %slot21, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %ld3082 = load i32, ptr %p3081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3082, ptr %slot371, align 8
  %v3083 = load i32, ptr %slot371, align 8
  %cv3084 = zext i32 %v3083 to i64
  %cond3085 = icmp ne i64 %cv3084, 0
  br i1 %cond3085, label %bb_rcslotdrop495, label %bb_rcslotdone495
bb_rcslotdrop495:
  %v3086 = load i64, ptr %slot21, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i32 0, ptr %p3087, align 4, !alias.scope !3, !noalias !4
  %v3088 = load i64, ptr %slot30, align 8
  store i64 %v3088, ptr %slot372, align 8
  %v3089 = load i64, ptr %slot22, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i32, ptr %p3090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3091, ptr %slot373, align 8
  %v3092 = load i32, ptr %slot373, align 8
  %op3093 = and i32 %v3092, 28
  store i32 %op3093, ptr %slot374, align 8
  %v3094 = load i32, ptr %slot374, align 8
  %cv3095 = zext i32 %v3094 to i64
  %cond3096 = icmp ne i64 %cv3095, 0
  br i1 %cond3096, label %bb_rcslotrole495, label %bb_rcslotowner495
bb_rcslotrole495:
  %v3097 = load i64, ptr %slot64, align 8
  store i64 %v3097, ptr %slot375, align 8
  %v3098 = load i64, ptr %slot375, align 8
  %v3099 = load i64, ptr %slot372, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3098, i64 %v3099) nomerge, !dbg !136
  br label %bb_rcslotdone495
bb_rcslotowner495:
  %v3100 = load i64, ptr %slot64, align 8
  store i64 %v3100, ptr %slot376, align 8
  %v3101 = load i64, ptr %slot376, align 8
  %v3102 = load i64, ptr %slot372, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3101, i64 %v3102) nomerge, !dbg !136
  br label %bb_rcslotdone495
bb_rcslotdone495:
  %v3103 = load i64, ptr %slot30, align 8
  store i64 %v3103, ptr %slot377, align 8
  %v3104 = load i64, ptr %slot35, align 8
  store i64 %v3104, ptr %slot378, align 8
  %v3105 = load i64, ptr %slot378, align 8
  %v3106 = load i64, ptr %slot377, align 8
  %p3107 = inttoptr i64 %v3105 to ptr
  %p3108 = inttoptr i64 %v3106 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3108, ptr %p3107, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3109 = load i64, ptr %slot22, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  store i32 2, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  %v3111 = load i64, ptr %slot28, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  %ld3113 = load i32, ptr %p3112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3113, ptr %slot379, align 8
  %v3114 = load i32, ptr %slot379, align 8
  %v3115 = load i64, ptr %slot22, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  store i32 %v3114, ptr %p3116, align 4, !alias.scope !3, !noalias !4
  %v3117 = load i64, ptr %slot27, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i32 0, ptr %p3118, align 4, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot21, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  store i32 1, ptr %p3120, align 4, !alias.scope !3, !noalias !4
  %v3121 = load i64, ptr %slot377, align 8
  %v3122 = load i64, ptr %slot53, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  store i64 %v3121, ptr %p3123, align 8, !alias.scope !3, !noalias !4
  %v3124 = load i64, ptr %slot53, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %ld3126 = load i64, ptr %p3125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3126, ptr %slot380, align 8
  %v3127 = load i64, ptr %slot21, align 8
  %p3128 = inttoptr i64 %v3127 to ptr
  %ld3129 = load i32, ptr %p3128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3129, ptr %slot381, align 8
  %v3130 = load i64, ptr %slot22, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %ld3132 = load i32, ptr %p3131, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3132, ptr %slot382, align 8
  %v3133 = load i32, ptr %slot382, align 8
  %op3134 = and i32 %v3133, 24
  store i32 %op3134, ptr %slot382, align 8
  %v3135 = load i32, ptr %slot382, align 8
  %cmp3136 = icmp eq i32 %v3135, 0
  %cv3137 = zext i1 %cmp3136 to i32
  store i32 %cv3137, ptr %slot383, align 8
  %v3138 = load i32, ptr %slot381, align 8
  %v3139 = load i32, ptr %slot383, align 8
  %op3140 = and i32 %v3138, %v3139
  store i32 %op3140, ptr %slot384, align 8
  %v3141 = load i32, ptr %slot384, align 8
  %cv3142 = zext i32 %v3141 to i64
  %cond3143 = icmp ne i64 %cv3142, 0
  br i1 %cond3143, label %bb_rctake511, label %bb_rccopy511
bb_rctake511:
  %v3144 = load i64, ptr %slot35, align 8
  store i64 %v3144, ptr %slot385, align 8
  %v3145 = load i64, ptr %slot65, align 8
  store i64 %v3145, ptr %slot386, align 8
  %v3146 = load i64, ptr %slot380, align 8
  %v3147 = load i64, ptr %slot385, align 8
  %op3148 = sub i64 %v3146, %v3147
  store i64 %op3148, ptr %slot387, align 8
  %v3149 = load i64, ptr %slot385, align 8
  %v3150 = load i64, ptr %slot380, align 8
  %op3151 = sub i64 %v3149, %v3150
  store i64 %op3151, ptr %slot388, align 8
  %v3152 = load i64, ptr %slot387, align 8
  %cmp3153 = icmp ult i64 %v3152, 16
  %cv3154 = zext i1 %cmp3153 to i32
  store i32 %cv3154, ptr %slot389, align 8
  %v3155 = load i64, ptr %slot388, align 8
  %cmp3156 = icmp ult i64 %v3155, 16
  %cv3157 = zext i1 %cmp3156 to i32
  store i32 %cv3157, ptr %slot390, align 8
  %v3158 = load i32, ptr %slot389, align 8
  %v3159 = load i32, ptr %slot390, align 8
  %op3160 = or i32 %v3158, %v3159
  store i32 %op3160, ptr %slot391, align 8
  %v3161 = load i32, ptr %slot391, align 8
  %cv3162 = zext i32 %v3161 to i64
  %cond3163 = icmp ne i64 %cv3162, 0
  br i1 %cond3163, label %bb_rcmoveslow520, label %bb_rcmovecheck520
bb_rcmovecheck520:
  %v3164 = load i64, ptr %slot380, align 8
  %op3165 = add i64 %v3164, 0
  store i64 %op3165, ptr %slot392, align 8
  %v3166 = load i64, ptr %slot392, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  %ld3168 = load i64, ptr %p3167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3168, ptr %slot393, align 8
  %v3169 = load i64, ptr %slot393, align 8
  %cmp3170 = icmp ne i64 %v3169, 0
  %cv3171 = zext i1 %cmp3170 to i32
  store i32 %cv3171, ptr %slot394, align 8
  %v3172 = load i32, ptr %slot394, align 8
  %cv3173 = zext i32 %v3172 to i64
  %cond3174 = icmp ne i64 %cv3173, 0
  br i1 %cond3174, label %bb_rcmoveheader528, label %bb_rcmovenext528
bb_rcmoveheader528:
  %v3175 = load i64, ptr %slot393, align 8
  %op3176 = sub i64 %v3175, 16
  store i64 %op3176, ptr %slot395, align 8
  %v3177 = load i64, ptr %slot393, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %rgep3179 = getelementptr i8, ptr %p3178, i64 -16
  %ld3180 = load i64, ptr %rgep3179, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3180, ptr %slot396, align 8
  %v3181 = load i64, ptr %slot396, align 8
  %op3182 = and i64 %v3181, 5764607523034234881
  store i64 %op3182, ptr %slot397, align 8
  %v3183 = load i64, ptr %slot397, align 8
  %cmp3184 = icmp ne i64 %v3183, 0
  %cv3185 = zext i1 %cmp3184 to i32
  store i32 %cv3185, ptr %slot398, align 8
  %v3186 = load i32, ptr %slot398, align 8
  %cv3187 = zext i32 %v3186 to i64
  %cond3188 = icmp ne i64 %cv3187, 0
  br i1 %cond3188, label %bb_rcmoveslow520, label %bb_rcmovenext528
bb_rcmovenext528:
  %v3189 = load i64, ptr %slot380, align 8
  %v3190 = load i64, ptr %slot385, align 8
  %p3191 = inttoptr i64 %v3189 to ptr
  %p3192 = inttoptr i64 %v3190 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3192, ptr %p3191, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot380, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i64 0, ptr %p3194, align 8, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot380, align 8
  %op3196 = add i64 %v3195, 8
  store i64 %op3196, ptr %slot399, align 8
  %v3197 = load i64, ptr %slot399, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  store i64 0, ptr %p3198, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved520
bb_rcmoveslow520:
  %v3199 = load i64, ptr %slot64, align 8
  %v3200 = load i64, ptr %slot385, align 8
  %v3201 = load i64, ptr %slot380, align 8
  %v3202 = load i64, ptr %slot386, align 8
  %cv3203 = trunc i64 %v3202 to i32
  %call3204 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3199, i64 %v3200, i64 %v3201, i32 %cv3203) nomerge, !dbg !138
  store i32 %call3204, ptr %slot400, align 8
  %v3205 = load i32, ptr %slot400, align 8
  %cv3206 = zext i32 %v3205 to i64
  %cond3207 = icmp ne i64 %cv3206, 0
  br i1 %cond3207, label %bb_rcsuccess536, label %bb_rcfailure536
bb_rcfailure536:
  %v3208 = load i64, ptr %slot64, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  %call3210 = call i32 @myl_rc_take_failure(ptr %p3209) nomerge, !dbg !138
  store i32 %call3210, ptr %slot401, align 8
  %v3211 = load i64, ptr %slot1, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %v3213 = load i32, ptr %slot401, align 8
  %call3214 = call i32 @myl_qbe_rc_status(ptr %p3212, i32 %v3213) nomerge, !dbg !138
  store i32 %call3214, ptr %slot402, align 8
  br label %bb_failure
bb_rcsuccess536:
  br label %bb_rcmoved520
bb_rcmoved520:
  %v3215 = load i64, ptr %slot21, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  store i32 0, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  %v3217 = load i64, ptr %slot28, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i32 2, ptr %p3218, align 4, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot27, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  store i32 1, ptr %p3220, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared511
bb_rccopy511:
  %v3221 = load i64, ptr %slot35, align 8
  store i64 %v3221, ptr %slot403, align 8
  %v3222 = load i64, ptr %slot65, align 8
  store i64 %v3222, ptr %slot404, align 8
  %v3223 = load i64, ptr %slot64, align 8
  %v3224 = load i64, ptr %slot403, align 8
  %v3225 = load i64, ptr %slot380, align 8
  %v3226 = load i64, ptr %slot404, align 8
  %cv3227 = trunc i64 %v3226 to i32
  %call3228 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v3223, i64 %v3224, i64 %v3225, i32 %cv3227) nomerge, !dbg !138
  store i32 %call3228, ptr %slot405, align 8
  %v3229 = load i32, ptr %slot405, align 8
  %cv3230 = zext i32 %v3229 to i64
  %cond3231 = icmp ne i64 %cv3230, 0
  br i1 %cond3231, label %bb_rcsuccess545, label %bb_rcfailure545
bb_rcfailure545:
  %v3232 = load i64, ptr %slot64, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  %call3234 = call i32 @myl_rc_take_failure(ptr %p3233) nomerge, !dbg !138
  store i32 %call3234, ptr %slot406, align 8
  %v3235 = load i64, ptr %slot1, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  %v3237 = load i32, ptr %slot406, align 8
  %call3238 = call i32 @myl_qbe_rc_status(ptr %p3236, i32 %v3237) nomerge, !dbg !138
  store i32 %call3238, ptr %slot407, align 8
  br label %bb_failure
bb_rcsuccess545:
  %v3239 = load i64, ptr %slot28, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  store i32 2, ptr %p3240, align 4, !alias.scope !3, !noalias !4
  %v3241 = load i64, ptr %slot27, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  store i32 1, ptr %p3242, align 4, !alias.scope !3, !noalias !4
  %v3243 = load i64, ptr %slot21, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %ld3245 = load i32, ptr %p3244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3245, ptr %slot408, align 8
  %v3246 = load i32, ptr %slot408, align 8
  %cv3247 = zext i32 %v3246 to i64
  %cond3248 = icmp ne i64 %cv3247, 0
  br i1 %cond3248, label %bb_rcslotdrop552, label %bb_rcslotdone552
bb_rcslotdrop552:
  %v3249 = load i64, ptr %slot21, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  store i32 0, ptr %p3250, align 4, !alias.scope !3, !noalias !4
  %v3251 = load i64, ptr %slot30, align 8
  store i64 %v3251, ptr %slot409, align 8
  %v3252 = load i64, ptr %slot22, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  %ld3254 = load i32, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3254, ptr %slot410, align 8
  %v3255 = load i32, ptr %slot410, align 8
  %op3256 = and i32 %v3255, 28
  store i32 %op3256, ptr %slot411, align 8
  %v3257 = load i32, ptr %slot411, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcslotrole552, label %bb_rcslotowner552
bb_rcslotrole552:
  %v3260 = load i64, ptr %slot64, align 8
  store i64 %v3260, ptr %slot412, align 8
  %v3261 = load i64, ptr %slot412, align 8
  %v3262 = load i64, ptr %slot409, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3261, i64 %v3262) nomerge, !dbg !138
  br label %bb_rcslotdone552
bb_rcslotowner552:
  %v3263 = load i64, ptr %slot409, align 8
  %p3265 = inttoptr i64 %v3263 to ptr
  %gep3266 = getelementptr i8, ptr %p3265, i64 0
  %op3264 = ptrtoint ptr %gep3266 to i64
  store i64 %op3264, ptr %slot413, align 8
  %v3267 = load i64, ptr %slot64, align 8
  store i64 %v3267, ptr %slot414, align 8
  %v3268 = load i64, ptr %slot413, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %ld3270 = load i64, ptr %p3269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3270, ptr %slot415, align 8
  %v3271 = load i64, ptr %slot415, align 8
  %cmp3272 = icmp ne i64 %v3271, 0
  %cv3273 = zext i1 %cmp3272 to i32
  store i32 %cv3273, ptr %slot416, align 8
  %v3274 = load i32, ptr %slot416, align 8
  %cv3275 = zext i32 %v3274 to i64
  %cond3276 = icmp ne i64 %cv3275, 0
  br i1 %cond3276, label %bb_rcgnn570, label %bb_rcgdone570
bb_rcgnn570:
  %v3277 = load i64, ptr %slot415, align 8
  %op3278 = sub i64 %v3277, 16
  store i64 %op3278, ptr %slot417, align 8
  %v3279 = load i64, ptr %slot415, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %rgep3281 = getelementptr i8, ptr %p3280, i64 -16
  %ld3282 = load i64, ptr %rgep3281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3282, ptr %slot418, align 8
  %v3283 = load i64, ptr %slot418, align 8
  %op3284 = and i64 %v3283, 4611686018427387906
  store i64 %op3284, ptr %slot419, align 8
  %v3285 = load i64, ptr %slot419, align 8
  %cmp3286 = icmp ne i64 %v3285, 0
  %cv3287 = zext i1 %cmp3286 to i32
  store i32 %cv3287, ptr %slot420, align 8
  %v3288 = load i32, ptr %slot420, align 8
  %cv3289 = zext i32 %v3288 to i64
  %cond3290 = icmp ne i64 %cv3289, 0
  br i1 %cond3290, label %bb_rcgclear570, label %bb_rcgcounted570
bb_rcgcounted570:
  %v3291 = load i64, ptr %slot415, align 8
  %op3292 = sub i64 %v3291, 32
  store i64 %op3292, ptr %slot421, align 8
  %v3293 = load i64, ptr %slot415, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %rgep3295 = getelementptr i8, ptr %p3294, i64 -32
  %ld3296 = load i64, ptr %rgep3295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3296, ptr %slot422, align 8
  %v3297 = load i64, ptr %slot422, align 8
  %op3298 = sub i64 %v3297, 1
  store i64 %op3298, ptr %slot423, align 8
  %v3299 = load i64, ptr %slot423, align 8
  %cmp3300 = icmp eq i64 %v3299, 0
  %cv3301 = zext i1 %cmp3300 to i32
  store i32 %cv3301, ptr %slot424, align 8
  %v3302 = load i32, ptr %slot424, align 8
  %cv3303 = zext i32 %v3302 to i64
  %cond3304 = icmp ne i64 %cv3303, 0
  br i1 %cond3304, label %bb_rcglast570, label %bb_rcgdec570
bb_rcglast570:
  %v3305 = load i64, ptr %slot415, align 8
  %op3306 = sub i64 %v3305, 24
  store i64 %op3306, ptr %slot425, align 8
  %v3307 = load i64, ptr %slot415, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  %rgep3309 = getelementptr i8, ptr %p3308, i64 -24
  %ld3310 = load i64, ptr %rgep3309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3310, ptr %slot426, align 8
  %v3311 = load i64, ptr %slot426, align 8
  %cmp3312 = icmp ne i64 %v3311, 0
  %cv3313 = zext i1 %cmp3312 to i32
  store i32 %cv3313, ptr %slot427, align 8
  %v3314 = load i32, ptr %slot427, align 8
  %cv3315 = zext i32 %v3314 to i64
  %cond3316 = icmp ne i64 %cv3315, 0
  br i1 %cond3316, label %bb_rcgdec570, label %bb_rcgslow570
bb_rcgslow570:
  %v3317 = load i64, ptr %slot414, align 8
  %v3318 = load i64, ptr %slot413, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3317, i64 %v3318) nomerge, !dbg !138
  br label %bb_rcgdone570
bb_rcgdec570:
  %v3319 = load i64, ptr %slot423, align 8
  %v3320 = load i64, ptr %slot415, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  %rgep3322 = getelementptr i8, ptr %p3321, i64 -32
  store i64 %v3319, ptr %rgep3322, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear570
bb_rcgclear570:
  %v3323 = load i64, ptr %slot413, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i64 0, ptr %p3324, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone570
bb_rcgdone570:
  %v3325 = load i64, ptr %slot409, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  store i64 0, ptr %p3326, align 8, !alias.scope !3, !noalias !4
  %v3327 = load i64, ptr %slot409, align 8
  %p3329 = inttoptr i64 %v3327 to ptr
  %gep3330 = getelementptr i8, ptr %p3329, i64 8
  %op3328 = ptrtoint ptr %gep3330 to i64
  store i64 %op3328, ptr %slot428, align 8
  %v3331 = load i64, ptr %slot428, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i64 0, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone552
bb_rcslotdone552:
  br label %bb_rcprepared511
bb_rcprepared511:
  %v3333 = load i64, ptr %slot7, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i32, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3335, ptr %slot429, align 8
  %v3336 = load i32, ptr %slot429, align 8
  %cv3337 = zext i32 %v3336 to i64
  %cond3338 = icmp ne i64 %cv3337, 0
  br i1 %cond3338, label %bb_rcslotdrop578, label %bb_rcslotdone578
bb_rcslotdrop578:
  %v3339 = load i64, ptr %slot7, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 0, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot43, align 8
  store i64 %v3341, ptr %slot430, align 8
  %v3342 = load i64, ptr %slot8, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %ld3344 = load i32, ptr %p3343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3344, ptr %slot431, align 8
  %v3345 = load i32, ptr %slot431, align 8
  %op3346 = and i32 %v3345, 28
  store i32 %op3346, ptr %slot432, align 8
  %v3347 = load i32, ptr %slot432, align 8
  %cv3348 = zext i32 %v3347 to i64
  %cond3349 = icmp ne i64 %cv3348, 0
  br i1 %cond3349, label %bb_rcslotrole578, label %bb_rcslotowner578
bb_rcslotrole578:
  %v3350 = load i64, ptr %slot64, align 8
  store i64 %v3350, ptr %slot433, align 8
  %v3351 = load i64, ptr %slot433, align 8
  %v3352 = load i64, ptr %slot430, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3351, i64 %v3352) nomerge, !dbg !138
  br label %bb_rcslotdone578
bb_rcslotowner578:
  %v3353 = load i64, ptr %slot430, align 8
  %p3355 = inttoptr i64 %v3353 to ptr
  %gep3356 = getelementptr i8, ptr %p3355, i64 0
  %op3354 = ptrtoint ptr %gep3356 to i64
  store i64 %op3354, ptr %slot434, align 8
  %v3357 = load i64, ptr %slot64, align 8
  store i64 %v3357, ptr %slot435, align 8
  %v3358 = load i64, ptr %slot434, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3360, ptr %slot436, align 8
  %v3361 = load i64, ptr %slot436, align 8
  %cmp3362 = icmp ne i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot437, align 8
  %v3364 = load i32, ptr %slot437, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcgnn596, label %bb_rcgdone596
bb_rcgnn596:
  %v3367 = load i64, ptr %slot436, align 8
  %op3368 = sub i64 %v3367, 16
  store i64 %op3368, ptr %slot438, align 8
  %v3369 = load i64, ptr %slot436, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %rgep3371 = getelementptr i8, ptr %p3370, i64 -16
  %ld3372 = load i64, ptr %rgep3371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3372, ptr %slot439, align 8
  %v3373 = load i64, ptr %slot439, align 8
  %op3374 = and i64 %v3373, 4611686018427387906
  store i64 %op3374, ptr %slot440, align 8
  %v3375 = load i64, ptr %slot440, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot441, align 8
  %v3378 = load i32, ptr %slot441, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcgclear596, label %bb_rcgcounted596
bb_rcgcounted596:
  %v3381 = load i64, ptr %slot436, align 8
  %op3382 = sub i64 %v3381, 32
  store i64 %op3382, ptr %slot442, align 8
  %v3383 = load i64, ptr %slot436, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %rgep3385 = getelementptr i8, ptr %p3384, i64 -32
  %ld3386 = load i64, ptr %rgep3385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3386, ptr %slot443, align 8
  %v3387 = load i64, ptr %slot443, align 8
  %op3388 = sub i64 %v3387, 1
  store i64 %op3388, ptr %slot444, align 8
  %v3389 = load i64, ptr %slot444, align 8
  %cmp3390 = icmp eq i64 %v3389, 0
  %cv3391 = zext i1 %cmp3390 to i32
  store i32 %cv3391, ptr %slot445, align 8
  %v3392 = load i32, ptr %slot445, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcglast596, label %bb_rcgdec596
bb_rcglast596:
  %v3395 = load i64, ptr %slot436, align 8
  %op3396 = sub i64 %v3395, 24
  store i64 %op3396, ptr %slot446, align 8
  %v3397 = load i64, ptr %slot436, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  %rgep3399 = getelementptr i8, ptr %p3398, i64 -24
  %ld3400 = load i64, ptr %rgep3399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3400, ptr %slot447, align 8
  %v3401 = load i64, ptr %slot447, align 8
  %cmp3402 = icmp ne i64 %v3401, 0
  %cv3403 = zext i1 %cmp3402 to i32
  store i32 %cv3403, ptr %slot448, align 8
  %v3404 = load i32, ptr %slot448, align 8
  %cv3405 = zext i32 %v3404 to i64
  %cond3406 = icmp ne i64 %cv3405, 0
  br i1 %cond3406, label %bb_rcgdec596, label %bb_rcgslow596
bb_rcgslow596:
  %v3407 = load i64, ptr %slot435, align 8
  %v3408 = load i64, ptr %slot434, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3407, i64 %v3408) nomerge, !dbg !138
  br label %bb_rcgdone596
bb_rcgdec596:
  %v3409 = load i64, ptr %slot444, align 8
  %v3410 = load i64, ptr %slot436, align 8
  %p3411 = inttoptr i64 %v3410 to ptr
  %rgep3412 = getelementptr i8, ptr %p3411, i64 -32
  store i64 %v3409, ptr %rgep3412, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear596
bb_rcgclear596:
  %v3413 = load i64, ptr %slot434, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i64 0, ptr %p3414, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone596
bb_rcgdone596:
  %v3415 = load i64, ptr %slot430, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  store i64 0, ptr %p3416, align 8, !alias.scope !3, !noalias !4
  %v3417 = load i64, ptr %slot430, align 8
  %p3419 = inttoptr i64 %v3417 to ptr
  %gep3420 = getelementptr i8, ptr %p3419, i64 8
  %op3418 = ptrtoint ptr %gep3420 to i64
  store i64 %op3418, ptr %slot449, align 8
  %v3421 = load i64, ptr %slot449, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  store i64 0, ptr %p3422, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone578
bb_rcslotdone578:
  %v3423 = load i64, ptr %slot43, align 8
  store i64 %v3423, ptr %slot450, align 8
  %v3424 = load i64, ptr %slot35, align 8
  store i64 %v3424, ptr %slot451, align 8
  %v3425 = load i64, ptr %slot451, align 8
  %v3426 = load i64, ptr %slot450, align 8
  %p3427 = inttoptr i64 %v3425 to ptr
  %p3428 = inttoptr i64 %v3426 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3428, ptr %p3427, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3429 = load i64, ptr %slot27, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  store i32 0, ptr %p3430, align 4, !alias.scope !3, !noalias !4
  %v3431 = load i64, ptr %slot8, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  store i32 2, ptr %p3432, align 4, !alias.scope !3, !noalias !4
  %v3433 = load i64, ptr %slot28, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  %ld3435 = load i32, ptr %p3434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3435, ptr %slot452, align 8
  %v3436 = load i32, ptr %slot452, align 8
  %v3437 = load i64, ptr %slot8, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  store i32 %v3436, ptr %p3438, align 4, !alias.scope !3, !noalias !4
  %v3439 = load i64, ptr %slot7, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  store i32 1, ptr %p3440, align 4, !alias.scope !3, !noalias !4
  %v3441 = load i64, ptr %slot43, align 8
  %v3442 = load i64, ptr %slot53, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  store i64 %v3441, ptr %p3443, align 8, !alias.scope !3, !noalias !4
  %v3444 = load i64, ptr %slot53, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %ld3446 = load i64, ptr %p3445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3446, ptr %slot453, align 8
  %v3447 = load i64, ptr %slot453, align 8
  %op3448 = add i64 %v3447, 0
  store i64 %op3448, ptr %slot454, align 8
  %v3449 = load i64, ptr %slot454, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %ld3451 = load i64, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3451, ptr %slot455, align 8
  %v3452 = load i64, ptr %slot455, align 8
  %v3453 = load i64, ptr %slot53, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  store i64 %v3452, ptr %p3454, align 8, !alias.scope !3, !noalias !4
  %v3455 = load i64, ptr %slot53, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %ld3457 = load i64, ptr %p3456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3457, ptr %slot456, align 8
  %v3458 = load i64, ptr %slot456, align 8
  %v3459 = load i64, ptr %slot33, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i64 %v3458, ptr %p3460, align 8, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot33, align 8
  store i64 %v3461, ptr %slot457, align 8
  %v3462 = load i64, ptr %slot35, align 8
  store i64 %v3462, ptr %slot458, align 8
  %v3463 = load i64, ptr %slot457, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  %ld3465 = load i64, ptr %p3464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3465, ptr %slot459, align 8
  %v3466 = load i64, ptr %slot459, align 8
  %cmp3467 = icmp ne i64 %v3466, 0
  %cv3468 = zext i1 %cmp3467 to i32
  store i32 %cv3468, ptr %slot460, align 8
  %v3469 = load i32, ptr %slot460, align 8
  %cv3470 = zext i32 %v3469 to i64
  %cond3471 = icmp ne i64 %cv3470, 0
  br i1 %cond3471, label %bb_rcgnn615, label %bb_rcgstore615
bb_rcgnn615:
  %v3472 = load i64, ptr %slot459, align 8
  %op3473 = sub i64 %v3472, 16
  store i64 %op3473, ptr %slot461, align 8
  %v3474 = load i64, ptr %slot459, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  %rgep3476 = getelementptr i8, ptr %p3475, i64 -16
  %ld3477 = load i64, ptr %rgep3476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3477, ptr %slot462, align 8
  %v3478 = load i64, ptr %slot462, align 8
  %op3479 = and i64 %v3478, 4611686018427387906
  store i64 %op3479, ptr %slot463, align 8
  %v3480 = load i64, ptr %slot463, align 8
  %cmp3481 = icmp ne i64 %v3480, 0
  %cv3482 = zext i1 %cmp3481 to i32
  store i32 %cv3482, ptr %slot464, align 8
  %v3483 = load i32, ptr %slot464, align 8
  %cv3484 = zext i32 %v3483 to i64
  %cond3485 = icmp ne i64 %cv3484, 0
  br i1 %cond3485, label %bb_rcgstore615, label %bb_rcginc615
bb_rcginc615:
  %v3486 = load i64, ptr %slot459, align 8
  %op3487 = sub i64 %v3486, 24
  store i64 %op3487, ptr %slot465, align 8
  %v3488 = load i64, ptr %slot459, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %rgep3490 = getelementptr i8, ptr %p3489, i64 -24
  %ld3491 = load i64, ptr %rgep3490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3491, ptr %slot466, align 8
  %v3492 = load i64, ptr %slot466, align 8
  %op3493 = add i64 %v3492, 1
  store i64 %op3493, ptr %slot467, align 8
  %v3494 = load i64, ptr %slot467, align 8
  %cmp3495 = icmp eq i64 %v3494, 0
  %cv3496 = zext i1 %cmp3495 to i32
  store i32 %cv3496, ptr %slot468, align 8
  %v3497 = load i32, ptr %slot468, align 8
  %cv3498 = zext i32 %v3497 to i64
  %cond3499 = icmp ne i64 %cv3498, 0
  br i1 %cond3499, label %bb_rcglimit615, label %bb_rcgcapacity615
bb_rcglimit615:
  %v3500 = load i64, ptr %slot1, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  %call3502 = call i32 @myl_qbe_rc_status(ptr %p3501, i32 2) nomerge, !dbg !140
  store i32 %call3502, ptr %slot469, align 8
  br label %bb_failure
bb_rcgcapacity615:
  %v3503 = load i64, ptr %slot467, align 8
  %v3504 = load i64, ptr %slot459, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %rgep3506 = getelementptr i8, ptr %p3505, i64 -24
  store i64 %v3503, ptr %rgep3506, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore615
bb_rcgstore615:
  %v3507 = load i64, ptr %slot459, align 8
  %v3508 = load i64, ptr %slot458, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  store i64 %v3507, ptr %p3509, align 8, !alias.scope !3, !noalias !4
  %v3510 = load i64, ptr %slot28, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i32 2, ptr %p3511, align 4, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot28, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  store i32 16, ptr %p3513, align 4, !alias.scope !3, !noalias !4
  %v3514 = load i64, ptr %slot27, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i32 1, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot21, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  %ld3518 = load i32, ptr %p3517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3518, ptr %slot470, align 8
  %v3519 = load i32, ptr %slot470, align 8
  %cv3520 = zext i32 %v3519 to i64
  %cond3521 = icmp ne i64 %cv3520, 0
  br i1 %cond3521, label %bb_rcslotdrop631, label %bb_rcslotdone631
bb_rcslotdrop631:
  %v3522 = load i64, ptr %slot21, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  store i32 0, ptr %p3523, align 4, !alias.scope !3, !noalias !4
  %v3524 = load i64, ptr %slot30, align 8
  store i64 %v3524, ptr %slot471, align 8
  %v3525 = load i64, ptr %slot22, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  %ld3527 = load i32, ptr %p3526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3527, ptr %slot472, align 8
  %v3528 = load i32, ptr %slot472, align 8
  %op3529 = and i32 %v3528, 28
  store i32 %op3529, ptr %slot473, align 8
  %v3530 = load i32, ptr %slot473, align 8
  %cv3531 = zext i32 %v3530 to i64
  %cond3532 = icmp ne i64 %cv3531, 0
  br i1 %cond3532, label %bb_rcslotrole631, label %bb_rcslotowner631
bb_rcslotrole631:
  %v3533 = load i64, ptr %slot64, align 8
  store i64 %v3533, ptr %slot474, align 8
  %v3534 = load i64, ptr %slot474, align 8
  %v3535 = load i64, ptr %slot471, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3534, i64 %v3535) nomerge, !dbg !140
  br label %bb_rcslotdone631
bb_rcslotowner631:
  %v3536 = load i64, ptr %slot64, align 8
  store i64 %v3536, ptr %slot475, align 8
  %v3537 = load i64, ptr %slot475, align 8
  %v3538 = load i64, ptr %slot471, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3537, i64 %v3538) nomerge, !dbg !140
  br label %bb_rcslotdone631
bb_rcslotdone631:
  %v3539 = load i64, ptr %slot30, align 8
  store i64 %v3539, ptr %slot476, align 8
  %v3540 = load i64, ptr %slot35, align 8
  store i64 %v3540, ptr %slot477, align 8
  %v3541 = load i64, ptr %slot477, align 8
  %v3542 = load i64, ptr %slot476, align 8
  %p3543 = inttoptr i64 %v3541 to ptr
  %p3544 = inttoptr i64 %v3542 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3544, ptr %p3543, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3545 = load i64, ptr %slot22, align 8
  %p3546 = inttoptr i64 %v3545 to ptr
  store i32 2, ptr %p3546, align 4, !alias.scope !3, !noalias !4
  %v3547 = load i64, ptr %slot28, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %ld3549 = load i32, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3549, ptr %slot478, align 8
  %v3550 = load i32, ptr %slot478, align 8
  %v3551 = load i64, ptr %slot22, align 8
  %p3552 = inttoptr i64 %v3551 to ptr
  store i32 %v3550, ptr %p3552, align 4, !alias.scope !3, !noalias !4
  %v3553 = load i64, ptr %slot27, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  store i32 0, ptr %p3554, align 4, !alias.scope !3, !noalias !4
  %v3555 = load i64, ptr %slot21, align 8
  %p3556 = inttoptr i64 %v3555 to ptr
  store i32 1, ptr %p3556, align 4, !alias.scope !3, !noalias !4
  %v3557 = load i64, ptr %slot476, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %ld3559 = load i64, ptr %p3558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3559, ptr %slot479, align 8
  %v3560 = load i64, ptr %slot479, align 8
  %v3561 = load i64, ptr %slot53, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  store i64 %v3560, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  %v3563 = load i64, ptr %slot53, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i64, ptr %p3564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3565, ptr %slot480, align 8
  %v3566 = load i64, ptr %slot480, align 8
  %v3567 = load i64, ptr %slot33, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  store i64 %v3566, ptr %p3568, align 8, !alias.scope !3, !noalias !4
  %v3569 = load i64, ptr %slot33, align 8
  store i64 %v3569, ptr %slot481, align 8
  %v3570 = load i64, ptr %slot21, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %ld3572 = load i32, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3572, ptr %slot482, align 8
  %v3573 = load i64, ptr %slot22, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %ld3575 = load i32, ptr %p3574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3575, ptr %slot483, align 8
  %v3576 = load i32, ptr %slot483, align 8
  %op3577 = and i32 %v3576, 24
  store i32 %op3577, ptr %slot483, align 8
  %v3578 = load i32, ptr %slot483, align 8
  %cmp3579 = icmp eq i32 %v3578, 0
  %cv3580 = zext i1 %cmp3579 to i32
  store i32 %cv3580, ptr %slot484, align 8
  %v3581 = load i32, ptr %slot482, align 8
  %v3582 = load i32, ptr %slot484, align 8
  %op3583 = and i32 %v3581, %v3582
  store i32 %op3583, ptr %slot485, align 8
  %v3584 = load i32, ptr %slot485, align 8
  %cv3585 = zext i32 %v3584 to i64
  %cond3586 = icmp ne i64 %cv3585, 0
  br i1 %cond3586, label %bb_rcprivateown655, label %bb_rcprivateloan655
bb_rcprivateown655:
  %v3587 = load i64, ptr %slot35, align 8
  store i64 %v3587, ptr %slot486, align 8
  %v3588 = load i64, ptr %slot65, align 8
  store i64 %v3588, ptr %slot487, align 8
  %v3589 = load i64, ptr %slot481, align 8
  %v3590 = load i64, ptr %slot486, align 8
  %op3591 = sub i64 %v3589, %v3590
  store i64 %op3591, ptr %slot488, align 8
  %v3592 = load i64, ptr %slot486, align 8
  %v3593 = load i64, ptr %slot481, align 8
  %op3594 = sub i64 %v3592, %v3593
  store i64 %op3594, ptr %slot489, align 8
  %v3595 = load i64, ptr %slot488, align 8
  %cmp3596 = icmp ult i64 %v3595, 8
  %cv3597 = zext i1 %cmp3596 to i32
  store i32 %cv3597, ptr %slot490, align 8
  %v3598 = load i64, ptr %slot489, align 8
  %cmp3599 = icmp ult i64 %v3598, 8
  %cv3600 = zext i1 %cmp3599 to i32
  store i32 %cv3600, ptr %slot491, align 8
  %v3601 = load i32, ptr %slot490, align 8
  %v3602 = load i32, ptr %slot491, align 8
  %op3603 = or i32 %v3601, %v3602
  store i32 %op3603, ptr %slot492, align 8
  %v3604 = load i32, ptr %slot492, align 8
  %cv3605 = zext i32 %v3604 to i64
  %cond3606 = icmp ne i64 %cv3605, 0
  br i1 %cond3606, label %bb_rcmoveslow658, label %bb_rcmovecheck658
bb_rcmovecheck658:
  %v3607 = load i64, ptr %slot481, align 8
  %p3609 = inttoptr i64 %v3607 to ptr
  %gep3610 = getelementptr i8, ptr %p3609, i64 0
  %op3608 = ptrtoint ptr %gep3610 to i64
  store i64 %op3608, ptr %slot493, align 8
  %v3611 = load i64, ptr %slot493, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  %ld3613 = load i64, ptr %p3612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3613, ptr %slot494, align 8
  %v3614 = load i64, ptr %slot494, align 8
  %cmp3615 = icmp ne i64 %v3614, 0
  %cv3616 = zext i1 %cmp3615 to i32
  store i32 %cv3616, ptr %slot495, align 8
  %v3617 = load i32, ptr %slot495, align 8
  %cv3618 = zext i32 %v3617 to i64
  %cond3619 = icmp ne i64 %cv3618, 0
  br i1 %cond3619, label %bb_rcmoveheader666, label %bb_rcmovenext666
bb_rcmoveheader666:
  %v3620 = load i64, ptr %slot494, align 8
  %op3621 = sub i64 %v3620, 16
  store i64 %op3621, ptr %slot496, align 8
  %v3622 = load i64, ptr %slot494, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %rgep3624 = getelementptr i8, ptr %p3623, i64 -16
  %ld3625 = load i64, ptr %rgep3624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3625, ptr %slot497, align 8
  %v3626 = load i64, ptr %slot497, align 8
  %op3627 = and i64 %v3626, 5764607523034234881
  store i64 %op3627, ptr %slot498, align 8
  %v3628 = load i64, ptr %slot498, align 8
  %cmp3629 = icmp ne i64 %v3628, 0
  %cv3630 = zext i1 %cmp3629 to i32
  store i32 %cv3630, ptr %slot499, align 8
  %v3631 = load i32, ptr %slot499, align 8
  %cv3632 = zext i32 %v3631 to i64
  %cond3633 = icmp ne i64 %cv3632, 0
  br i1 %cond3633, label %bb_rcmoveslow658, label %bb_rcmovenext666
bb_rcmovenext666:
  %v3634 = load i64, ptr %slot481, align 8
  %v3635 = load i64, ptr %slot486, align 8
  %p3636 = inttoptr i64 %v3634 to ptr
  %p3637 = inttoptr i64 %v3635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3637, ptr %p3636, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot481, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i64 0, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved658
bb_rcmoveslow658:
  %v3640 = load i64, ptr %slot64, align 8
  %v3641 = load i64, ptr %slot486, align 8
  %v3642 = load i64, ptr %slot481, align 8
  %v3643 = load i64, ptr %slot487, align 8
  %cv3644 = trunc i64 %v3643 to i32
  %call3645 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v3640, i64 %v3641, i64 %v3642, i32 %cv3644) nomerge, !dbg !142
  store i32 %call3645, ptr %slot500, align 8
  %v3646 = load i32, ptr %slot500, align 8
  %cv3647 = zext i32 %v3646 to i64
  %cond3648 = icmp ne i64 %cv3647, 0
  br i1 %cond3648, label %bb_rcsuccess673, label %bb_rcfailure673
bb_rcfailure673:
  %v3649 = load i64, ptr %slot64, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %call3651 = call i32 @myl_rc_take_failure(ptr %p3650) nomerge, !dbg !142
  store i32 %call3651, ptr %slot501, align 8
  %v3652 = load i64, ptr %slot1, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %v3654 = load i32, ptr %slot501, align 8
  %call3655 = call i32 @myl_qbe_rc_status(ptr %p3653, i32 %v3654) nomerge, !dbg !142
  store i32 %call3655, ptr %slot502, align 8
  br label %bb_failure
bb_rcsuccess673:
  br label %bb_rcmoved658
bb_rcmoved658:
  %v3656 = load i64, ptr %slot21, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  store i32 0, ptr %p3657, align 4, !alias.scope !3, !noalias !4
  %v3658 = load i64, ptr %slot28, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  store i32 2, ptr %p3659, align 4, !alias.scope !3, !noalias !4
  %v3660 = load i64, ptr %slot27, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  store i32 1, ptr %p3661, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared655
bb_rcprivateloan655:
  %v3662 = load i64, ptr %slot21, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i32, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3664, ptr %slot503, align 8
  %v3665 = load i64, ptr %slot22, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  %ld3667 = load i32, ptr %p3666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3667, ptr %slot504, align 8
  %v3668 = load i32, ptr %slot504, align 8
  %cmp3669 = icmp eq i32 %v3668, 16
  %cv3670 = zext i1 %cmp3669 to i32
  store i32 %cv3670, ptr %slot505, align 8
  %v3671 = load i32, ptr %slot505, align 8
  %v3672 = load i32, ptr %slot503, align 8
  %op3673 = and i32 %v3671, %v3672
  store i32 %op3673, ptr %slot505, align 8
  %v3674 = load i32, ptr %slot505, align 8
  %cv3675 = zext i32 %v3674 to i64
  %cond3676 = icmp ne i64 %cv3675, 0
  br i1 %cond3676, label %bb_rcprivatemove655, label %bb_rcprivatenew655
bb_rcprivatemove655:
  %v3677 = load i64, ptr %slot35, align 8
  store i64 %v3677, ptr %slot506, align 8
  %v3678 = load i64, ptr %slot481, align 8
  %v3679 = load i64, ptr %slot506, align 8
  %p3680 = inttoptr i64 %v3678 to ptr
  %p3681 = inttoptr i64 %v3679 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3681, ptr %p3680, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3682 = load i64, ptr %slot481, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  store i64 0, ptr %p3683, align 8, !alias.scope !3, !noalias !4
  %v3684 = load i64, ptr %slot28, align 8
  %p3685 = inttoptr i64 %v3684 to ptr
  store i32 2, ptr %p3685, align 4, !alias.scope !3, !noalias !4
  %v3686 = load i64, ptr %slot28, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  store i32 16, ptr %p3687, align 4, !alias.scope !3, !noalias !4
  %v3688 = load i64, ptr %slot27, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  store i32 1, ptr %p3689, align 4, !alias.scope !3, !noalias !4
  %v3690 = load i64, ptr %slot21, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  store i32 0, ptr %p3691, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared655
bb_rcprivatenew655:
  %v3692 = load i64, ptr %slot35, align 8
  store i64 %v3692, ptr %slot507, align 8
  %v3693 = load i64, ptr %slot481, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  %ld3695 = load i64, ptr %p3694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3695, ptr %slot508, align 8
  %v3696 = load i64, ptr %slot508, align 8
  %cmp3697 = icmp ne i64 %v3696, 0
  %cv3698 = zext i1 %cmp3697 to i32
  store i32 %cv3698, ptr %slot509, align 8
  %v3699 = load i32, ptr %slot509, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcgnn691, label %bb_rcgstore691
bb_rcgnn691:
  %v3702 = load i64, ptr %slot508, align 8
  %op3703 = sub i64 %v3702, 16
  store i64 %op3703, ptr %slot510, align 8
  %v3704 = load i64, ptr %slot508, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %rgep3706 = getelementptr i8, ptr %p3705, i64 -16
  %ld3707 = load i64, ptr %rgep3706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3707, ptr %slot511, align 8
  %v3708 = load i64, ptr %slot511, align 8
  %op3709 = and i64 %v3708, 4611686018427387906
  store i64 %op3709, ptr %slot512, align 8
  %v3710 = load i64, ptr %slot512, align 8
  %cmp3711 = icmp ne i64 %v3710, 0
  %cv3712 = zext i1 %cmp3711 to i32
  store i32 %cv3712, ptr %slot513, align 8
  %v3713 = load i32, ptr %slot513, align 8
  %cv3714 = zext i32 %v3713 to i64
  %cond3715 = icmp ne i64 %cv3714, 0
  br i1 %cond3715, label %bb_rcgstore691, label %bb_rcginc691
bb_rcginc691:
  %v3716 = load i64, ptr %slot508, align 8
  %op3717 = sub i64 %v3716, 24
  store i64 %op3717, ptr %slot514, align 8
  %v3718 = load i64, ptr %slot508, align 8
  %p3719 = inttoptr i64 %v3718 to ptr
  %rgep3720 = getelementptr i8, ptr %p3719, i64 -24
  %ld3721 = load i64, ptr %rgep3720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3721, ptr %slot515, align 8
  %v3722 = load i64, ptr %slot515, align 8
  %op3723 = add i64 %v3722, 1
  store i64 %op3723, ptr %slot516, align 8
  %v3724 = load i64, ptr %slot516, align 8
  %cmp3725 = icmp eq i64 %v3724, 0
  %cv3726 = zext i1 %cmp3725 to i32
  store i32 %cv3726, ptr %slot517, align 8
  %v3727 = load i32, ptr %slot517, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rcglimit691, label %bb_rcgcapacity691
bb_rcglimit691:
  %v3730 = load i64, ptr %slot1, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %call3732 = call i32 @myl_qbe_rc_status(ptr %p3731, i32 2) nomerge, !dbg !142
  store i32 %call3732, ptr %slot518, align 8
  br label %bb_failure
bb_rcgcapacity691:
  %v3733 = load i64, ptr %slot516, align 8
  %v3734 = load i64, ptr %slot508, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %rgep3736 = getelementptr i8, ptr %p3735, i64 -24
  store i64 %v3733, ptr %rgep3736, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore691
bb_rcgstore691:
  %v3737 = load i64, ptr %slot508, align 8
  %v3738 = load i64, ptr %slot507, align 8
  %p3739 = inttoptr i64 %v3738 to ptr
  store i64 %v3737, ptr %p3739, align 8, !alias.scope !3, !noalias !4
  %v3740 = load i64, ptr %slot28, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  store i32 2, ptr %p3741, align 4, !alias.scope !3, !noalias !4
  %v3742 = load i64, ptr %slot28, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  store i32 16, ptr %p3743, align 4, !alias.scope !3, !noalias !4
  %v3744 = load i64, ptr %slot27, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  store i32 1, ptr %p3745, align 4, !alias.scope !3, !noalias !4
  %v3746 = load i64, ptr %slot21, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %ld3748 = load i32, ptr %p3747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3748, ptr %slot519, align 8
  %v3749 = load i32, ptr %slot519, align 8
  %cv3750 = zext i32 %v3749 to i64
  %cond3751 = icmp ne i64 %cv3750, 0
  br i1 %cond3751, label %bb_rcslotdrop707, label %bb_rcslotdone707
bb_rcslotdrop707:
  %v3752 = load i64, ptr %slot21, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  store i32 0, ptr %p3753, align 4, !alias.scope !3, !noalias !4
  %v3754 = load i64, ptr %slot30, align 8
  store i64 %v3754, ptr %slot520, align 8
  %v3755 = load i64, ptr %slot22, align 8
  %p3756 = inttoptr i64 %v3755 to ptr
  %ld3757 = load i32, ptr %p3756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3757, ptr %slot521, align 8
  %v3758 = load i32, ptr %slot521, align 8
  %op3759 = and i32 %v3758, 28
  store i32 %op3759, ptr %slot522, align 8
  %v3760 = load i32, ptr %slot522, align 8
  %cv3761 = zext i32 %v3760 to i64
  %cond3762 = icmp ne i64 %cv3761, 0
  br i1 %cond3762, label %bb_rcslotrole707, label %bb_rcslotowner707
bb_rcslotrole707:
  %v3763 = load i64, ptr %slot64, align 8
  store i64 %v3763, ptr %slot523, align 8
  %v3764 = load i64, ptr %slot520, align 8
  %p3765 = inttoptr i64 %v3764 to ptr
  %ld3766 = load i64, ptr %p3765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3766, ptr %slot524, align 8
  %v3767 = load i64, ptr %slot524, align 8
  %cmp3768 = icmp ne i64 %v3767, 0
  %cv3769 = zext i1 %cmp3768 to i32
  store i32 %cv3769, ptr %slot525, align 8
  %v3770 = load i32, ptr %slot525, align 8
  %cv3771 = zext i32 %v3770 to i64
  %cond3772 = icmp ne i64 %cv3771, 0
  br i1 %cond3772, label %bb_rcgnn723, label %bb_rcgdone723
bb_rcgnn723:
  %v3773 = load i64, ptr %slot524, align 8
  %op3774 = sub i64 %v3773, 16
  store i64 %op3774, ptr %slot526, align 8
  %v3775 = load i64, ptr %slot524, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %rgep3777 = getelementptr i8, ptr %p3776, i64 -16
  %ld3778 = load i64, ptr %rgep3777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3778, ptr %slot527, align 8
  %v3779 = load i64, ptr %slot527, align 8
  %op3780 = and i64 %v3779, 4611686018427387906
  store i64 %op3780, ptr %slot528, align 8
  %v3781 = load i64, ptr %slot528, align 8
  %cmp3782 = icmp ne i64 %v3781, 0
  %cv3783 = zext i1 %cmp3782 to i32
  store i32 %cv3783, ptr %slot529, align 8
  %v3784 = load i32, ptr %slot529, align 8
  %cv3785 = zext i32 %v3784 to i64
  %cond3786 = icmp ne i64 %cv3785, 0
  br i1 %cond3786, label %bb_rcgclear723, label %bb_rcgcounted723
bb_rcgcounted723:
  %v3787 = load i64, ptr %slot524, align 8
  %op3788 = sub i64 %v3787, 24
  store i64 %op3788, ptr %slot530, align 8
  %v3789 = load i64, ptr %slot524, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  %rgep3791 = getelementptr i8, ptr %p3790, i64 -24
  %ld3792 = load i64, ptr %rgep3791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3792, ptr %slot531, align 8
  %v3793 = load i64, ptr %slot531, align 8
  %op3794 = sub i64 %v3793, 1
  store i64 %op3794, ptr %slot532, align 8
  %v3795 = load i64, ptr %slot532, align 8
  %cmp3796 = icmp eq i64 %v3795, 0
  %cv3797 = zext i1 %cmp3796 to i32
  store i32 %cv3797, ptr %slot533, align 8
  %v3798 = load i32, ptr %slot533, align 8
  %cv3799 = zext i32 %v3798 to i64
  %cond3800 = icmp ne i64 %cv3799, 0
  br i1 %cond3800, label %bb_rcglast723, label %bb_rcgdec723
bb_rcglast723:
  %v3801 = load i64, ptr %slot524, align 8
  %op3802 = sub i64 %v3801, 32
  store i64 %op3802, ptr %slot534, align 8
  %v3803 = load i64, ptr %slot524, align 8
  %p3804 = inttoptr i64 %v3803 to ptr
  %rgep3805 = getelementptr i8, ptr %p3804, i64 -32
  %ld3806 = load i64, ptr %rgep3805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3806, ptr %slot535, align 8
  %v3807 = load i64, ptr %slot535, align 8
  %cmp3808 = icmp ne i64 %v3807, 0
  %cv3809 = zext i1 %cmp3808 to i32
  store i32 %cv3809, ptr %slot536, align 8
  %v3810 = load i32, ptr %slot536, align 8
  %cv3811 = zext i32 %v3810 to i64
  %cond3812 = icmp ne i64 %cv3811, 0
  br i1 %cond3812, label %bb_rcgdec723, label %bb_rcgslow723
bb_rcgslow723:
  %v3813 = load i64, ptr %slot523, align 8
  %v3814 = load i64, ptr %slot520, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3813, i64 %v3814) nomerge, !dbg !142
  br label %bb_rcgdone723
bb_rcgdec723:
  %v3815 = load i64, ptr %slot532, align 8
  %v3816 = load i64, ptr %slot524, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  %rgep3818 = getelementptr i8, ptr %p3817, i64 -24
  store i64 %v3815, ptr %rgep3818, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear723
bb_rcgclear723:
  %v3819 = load i64, ptr %slot520, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  store i64 0, ptr %p3820, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone723
bb_rcgdone723:
  br label %bb_rcslotdone707
bb_rcslotowner707:
  %v3821 = load i64, ptr %slot64, align 8
  store i64 %v3821, ptr %slot537, align 8
  %v3822 = load i64, ptr %slot520, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i64, ptr %p3823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3824, ptr %slot538, align 8
  %v3825 = load i64, ptr %slot538, align 8
  %cmp3826 = icmp ne i64 %v3825, 0
  %cv3827 = zext i1 %cmp3826 to i32
  store i32 %cv3827, ptr %slot539, align 8
  %v3828 = load i32, ptr %slot539, align 8
  %cv3829 = zext i32 %v3828 to i64
  %cond3830 = icmp ne i64 %cv3829, 0
  br i1 %cond3830, label %bb_rcgnn738, label %bb_rcgdone738
bb_rcgnn738:
  %v3831 = load i64, ptr %slot538, align 8
  %op3832 = sub i64 %v3831, 16
  store i64 %op3832, ptr %slot540, align 8
  %v3833 = load i64, ptr %slot538, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %rgep3835 = getelementptr i8, ptr %p3834, i64 -16
  %ld3836 = load i64, ptr %rgep3835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3836, ptr %slot541, align 8
  %v3837 = load i64, ptr %slot541, align 8
  %op3838 = and i64 %v3837, 4611686018427387906
  store i64 %op3838, ptr %slot542, align 8
  %v3839 = load i64, ptr %slot542, align 8
  %cmp3840 = icmp ne i64 %v3839, 0
  %cv3841 = zext i1 %cmp3840 to i32
  store i32 %cv3841, ptr %slot543, align 8
  %v3842 = load i32, ptr %slot543, align 8
  %cv3843 = zext i32 %v3842 to i64
  %cond3844 = icmp ne i64 %cv3843, 0
  br i1 %cond3844, label %bb_rcgclear738, label %bb_rcgcounted738
bb_rcgcounted738:
  %v3845 = load i64, ptr %slot538, align 8
  %op3846 = sub i64 %v3845, 32
  store i64 %op3846, ptr %slot544, align 8
  %v3847 = load i64, ptr %slot538, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %rgep3849 = getelementptr i8, ptr %p3848, i64 -32
  %ld3850 = load i64, ptr %rgep3849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3850, ptr %slot545, align 8
  %v3851 = load i64, ptr %slot545, align 8
  %op3852 = sub i64 %v3851, 1
  store i64 %op3852, ptr %slot546, align 8
  %v3853 = load i64, ptr %slot546, align 8
  %cmp3854 = icmp eq i64 %v3853, 0
  %cv3855 = zext i1 %cmp3854 to i32
  store i32 %cv3855, ptr %slot547, align 8
  %v3856 = load i32, ptr %slot547, align 8
  %cv3857 = zext i32 %v3856 to i64
  %cond3858 = icmp ne i64 %cv3857, 0
  br i1 %cond3858, label %bb_rcglast738, label %bb_rcgdec738
bb_rcglast738:
  %v3859 = load i64, ptr %slot538, align 8
  %op3860 = sub i64 %v3859, 24
  store i64 %op3860, ptr %slot548, align 8
  %v3861 = load i64, ptr %slot538, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %rgep3863 = getelementptr i8, ptr %p3862, i64 -24
  %ld3864 = load i64, ptr %rgep3863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3864, ptr %slot549, align 8
  %v3865 = load i64, ptr %slot549, align 8
  %cmp3866 = icmp ne i64 %v3865, 0
  %cv3867 = zext i1 %cmp3866 to i32
  store i32 %cv3867, ptr %slot550, align 8
  %v3868 = load i32, ptr %slot550, align 8
  %cv3869 = zext i32 %v3868 to i64
  %cond3870 = icmp ne i64 %cv3869, 0
  br i1 %cond3870, label %bb_rcgdec738, label %bb_rcgslow738
bb_rcgslow738:
  %v3871 = load i64, ptr %slot537, align 8
  %v3872 = load i64, ptr %slot520, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3871, i64 %v3872) nomerge, !dbg !142
  br label %bb_rcgdone738
bb_rcgdec738:
  %v3873 = load i64, ptr %slot546, align 8
  %v3874 = load i64, ptr %slot538, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %rgep3876 = getelementptr i8, ptr %p3875, i64 -32
  store i64 %v3873, ptr %rgep3876, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear738
bb_rcgclear738:
  %v3877 = load i64, ptr %slot520, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i64 0, ptr %p3878, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone738
bb_rcgdone738:
  br label %bb_rcslotdone707
bb_rcslotdone707:
  br label %bb_rcprivateprepared655
bb_rcprivateprepared655:
  %v3879 = load i64, ptr %slot9, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %ld3881 = load i32, ptr %p3880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3881, ptr %slot551, align 8
  %v3882 = load i32, ptr %slot551, align 8
  %cv3883 = zext i32 %v3882 to i64
  %cond3884 = icmp ne i64 %cv3883, 0
  br i1 %cond3884, label %bb_rcslotdrop745, label %bb_rcslotdone745
bb_rcslotdrop745:
  %v3885 = load i64, ptr %slot9, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  store i32 0, ptr %p3886, align 4, !alias.scope !3, !noalias !4
  %v3887 = load i64, ptr %slot44, align 8
  store i64 %v3887, ptr %slot552, align 8
  %v3888 = load i64, ptr %slot10, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  %ld3890 = load i32, ptr %p3889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3890, ptr %slot553, align 8
  %v3891 = load i32, ptr %slot553, align 8
  %op3892 = and i32 %v3891, 28
  store i32 %op3892, ptr %slot554, align 8
  %v3893 = load i32, ptr %slot554, align 8
  %cv3894 = zext i32 %v3893 to i64
  %cond3895 = icmp ne i64 %cv3894, 0
  br i1 %cond3895, label %bb_rcslotrole745, label %bb_rcslotowner745
bb_rcslotrole745:
  %v3896 = load i64, ptr %slot64, align 8
  store i64 %v3896, ptr %slot555, align 8
  %v3897 = load i64, ptr %slot552, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %ld3899 = load i64, ptr %p3898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3899, ptr %slot556, align 8
  %v3900 = load i64, ptr %slot556, align 8
  %cmp3901 = icmp ne i64 %v3900, 0
  %cv3902 = zext i1 %cmp3901 to i32
  store i32 %cv3902, ptr %slot557, align 8
  %v3903 = load i32, ptr %slot557, align 8
  %cv3904 = zext i32 %v3903 to i64
  %cond3905 = icmp ne i64 %cv3904, 0
  br i1 %cond3905, label %bb_rcgnn761, label %bb_rcgdone761
bb_rcgnn761:
  %v3906 = load i64, ptr %slot556, align 8
  %op3907 = sub i64 %v3906, 16
  store i64 %op3907, ptr %slot558, align 8
  %v3908 = load i64, ptr %slot556, align 8
  %p3909 = inttoptr i64 %v3908 to ptr
  %rgep3910 = getelementptr i8, ptr %p3909, i64 -16
  %ld3911 = load i64, ptr %rgep3910, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3911, ptr %slot559, align 8
  %v3912 = load i64, ptr %slot559, align 8
  %op3913 = and i64 %v3912, 4611686018427387906
  store i64 %op3913, ptr %slot560, align 8
  %v3914 = load i64, ptr %slot560, align 8
  %cmp3915 = icmp ne i64 %v3914, 0
  %cv3916 = zext i1 %cmp3915 to i32
  store i32 %cv3916, ptr %slot561, align 8
  %v3917 = load i32, ptr %slot561, align 8
  %cv3918 = zext i32 %v3917 to i64
  %cond3919 = icmp ne i64 %cv3918, 0
  br i1 %cond3919, label %bb_rcgclear761, label %bb_rcgcounted761
bb_rcgcounted761:
  %v3920 = load i64, ptr %slot556, align 8
  %op3921 = sub i64 %v3920, 24
  store i64 %op3921, ptr %slot562, align 8
  %v3922 = load i64, ptr %slot556, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  %rgep3924 = getelementptr i8, ptr %p3923, i64 -24
  %ld3925 = load i64, ptr %rgep3924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3925, ptr %slot563, align 8
  %v3926 = load i64, ptr %slot563, align 8
  %op3927 = sub i64 %v3926, 1
  store i64 %op3927, ptr %slot564, align 8
  %v3928 = load i64, ptr %slot564, align 8
  %cmp3929 = icmp eq i64 %v3928, 0
  %cv3930 = zext i1 %cmp3929 to i32
  store i32 %cv3930, ptr %slot565, align 8
  %v3931 = load i32, ptr %slot565, align 8
  %cv3932 = zext i32 %v3931 to i64
  %cond3933 = icmp ne i64 %cv3932, 0
  br i1 %cond3933, label %bb_rcglast761, label %bb_rcgdec761
bb_rcglast761:
  %v3934 = load i64, ptr %slot556, align 8
  %op3935 = sub i64 %v3934, 32
  store i64 %op3935, ptr %slot566, align 8
  %v3936 = load i64, ptr %slot556, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  %rgep3938 = getelementptr i8, ptr %p3937, i64 -32
  %ld3939 = load i64, ptr %rgep3938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3939, ptr %slot567, align 8
  %v3940 = load i64, ptr %slot567, align 8
  %cmp3941 = icmp ne i64 %v3940, 0
  %cv3942 = zext i1 %cmp3941 to i32
  store i32 %cv3942, ptr %slot568, align 8
  %v3943 = load i32, ptr %slot568, align 8
  %cv3944 = zext i32 %v3943 to i64
  %cond3945 = icmp ne i64 %cv3944, 0
  br i1 %cond3945, label %bb_rcgdec761, label %bb_rcgslow761
bb_rcgslow761:
  %v3946 = load i64, ptr %slot555, align 8
  %v3947 = load i64, ptr %slot552, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v3946, i64 %v3947) nomerge, !dbg !142
  br label %bb_rcgdone761
bb_rcgdec761:
  %v3948 = load i64, ptr %slot564, align 8
  %v3949 = load i64, ptr %slot556, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  %rgep3951 = getelementptr i8, ptr %p3950, i64 -24
  store i64 %v3948, ptr %rgep3951, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear761
bb_rcgclear761:
  %v3952 = load i64, ptr %slot552, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  store i64 0, ptr %p3953, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone761
bb_rcgdone761:
  br label %bb_rcslotdone745
bb_rcslotowner745:
  %v3954 = load i64, ptr %slot64, align 8
  store i64 %v3954, ptr %slot569, align 8
  %v3955 = load i64, ptr %slot552, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %ld3957 = load i64, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3957, ptr %slot570, align 8
  %v3958 = load i64, ptr %slot570, align 8
  %cmp3959 = icmp ne i64 %v3958, 0
  %cv3960 = zext i1 %cmp3959 to i32
  store i32 %cv3960, ptr %slot571, align 8
  %v3961 = load i32, ptr %slot571, align 8
  %cv3962 = zext i32 %v3961 to i64
  %cond3963 = icmp ne i64 %cv3962, 0
  br i1 %cond3963, label %bb_rcgnn776, label %bb_rcgdone776
bb_rcgnn776:
  %v3964 = load i64, ptr %slot570, align 8
  %op3965 = sub i64 %v3964, 16
  store i64 %op3965, ptr %slot572, align 8
  %v3966 = load i64, ptr %slot570, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %rgep3968 = getelementptr i8, ptr %p3967, i64 -16
  %ld3969 = load i64, ptr %rgep3968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3969, ptr %slot573, align 8
  %v3970 = load i64, ptr %slot573, align 8
  %op3971 = and i64 %v3970, 4611686018427387906
  store i64 %op3971, ptr %slot574, align 8
  %v3972 = load i64, ptr %slot574, align 8
  %cmp3973 = icmp ne i64 %v3972, 0
  %cv3974 = zext i1 %cmp3973 to i32
  store i32 %cv3974, ptr %slot575, align 8
  %v3975 = load i32, ptr %slot575, align 8
  %cv3976 = zext i32 %v3975 to i64
  %cond3977 = icmp ne i64 %cv3976, 0
  br i1 %cond3977, label %bb_rcgclear776, label %bb_rcgcounted776
bb_rcgcounted776:
  %v3978 = load i64, ptr %slot570, align 8
  %op3979 = sub i64 %v3978, 32
  store i64 %op3979, ptr %slot576, align 8
  %v3980 = load i64, ptr %slot570, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  %rgep3982 = getelementptr i8, ptr %p3981, i64 -32
  %ld3983 = load i64, ptr %rgep3982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3983, ptr %slot577, align 8
  %v3984 = load i64, ptr %slot577, align 8
  %op3985 = sub i64 %v3984, 1
  store i64 %op3985, ptr %slot578, align 8
  %v3986 = load i64, ptr %slot578, align 8
  %cmp3987 = icmp eq i64 %v3986, 0
  %cv3988 = zext i1 %cmp3987 to i32
  store i32 %cv3988, ptr %slot579, align 8
  %v3989 = load i32, ptr %slot579, align 8
  %cv3990 = zext i32 %v3989 to i64
  %cond3991 = icmp ne i64 %cv3990, 0
  br i1 %cond3991, label %bb_rcglast776, label %bb_rcgdec776
bb_rcglast776:
  %v3992 = load i64, ptr %slot570, align 8
  %op3993 = sub i64 %v3992, 24
  store i64 %op3993, ptr %slot580, align 8
  %v3994 = load i64, ptr %slot570, align 8
  %p3995 = inttoptr i64 %v3994 to ptr
  %rgep3996 = getelementptr i8, ptr %p3995, i64 -24
  %ld3997 = load i64, ptr %rgep3996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3997, ptr %slot581, align 8
  %v3998 = load i64, ptr %slot581, align 8
  %cmp3999 = icmp ne i64 %v3998, 0
  %cv4000 = zext i1 %cmp3999 to i32
  store i32 %cv4000, ptr %slot582, align 8
  %v4001 = load i32, ptr %slot582, align 8
  %cv4002 = zext i32 %v4001 to i64
  %cond4003 = icmp ne i64 %cv4002, 0
  br i1 %cond4003, label %bb_rcgdec776, label %bb_rcgslow776
bb_rcgslow776:
  %v4004 = load i64, ptr %slot569, align 8
  %v4005 = load i64, ptr %slot552, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4004, i64 %v4005) nomerge, !dbg !142
  br label %bb_rcgdone776
bb_rcgdec776:
  %v4006 = load i64, ptr %slot578, align 8
  %v4007 = load i64, ptr %slot570, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  %rgep4009 = getelementptr i8, ptr %p4008, i64 -32
  store i64 %v4006, ptr %rgep4009, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear776
bb_rcgclear776:
  %v4010 = load i64, ptr %slot552, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  store i64 0, ptr %p4011, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone776
bb_rcgdone776:
  br label %bb_rcslotdone745
bb_rcslotdone745:
  %v4012 = load i64, ptr %slot44, align 8
  store i64 %v4012, ptr %slot583, align 8
  %v4013 = load i64, ptr %slot35, align 8
  store i64 %v4013, ptr %slot584, align 8
  %v4014 = load i64, ptr %slot584, align 8
  %v4015 = load i64, ptr %slot583, align 8
  %p4016 = inttoptr i64 %v4014 to ptr
  %p4017 = inttoptr i64 %v4015 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4017, ptr %p4016, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4018 = load i64, ptr %slot27, align 8
  %p4019 = inttoptr i64 %v4018 to ptr
  store i32 0, ptr %p4019, align 4, !alias.scope !3, !noalias !4
  %v4020 = load i64, ptr %slot10, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  store i32 2, ptr %p4021, align 4, !alias.scope !3, !noalias !4
  %v4022 = load i64, ptr %slot28, align 8
  %p4023 = inttoptr i64 %v4022 to ptr
  %ld4024 = load i32, ptr %p4023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4024, ptr %slot585, align 8
  %v4025 = load i32, ptr %slot585, align 8
  %v4026 = load i64, ptr %slot10, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  store i32 %v4025, ptr %p4027, align 4, !alias.scope !3, !noalias !4
  %v4028 = load i64, ptr %slot9, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  store i32 1, ptr %p4029, align 4, !alias.scope !3, !noalias !4
  %v4030 = load i64, ptr %slot44, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %ld4032 = load i64, ptr %p4031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4032, ptr %slot586, align 8
  %v4033 = load i64, ptr %slot64, align 8
  %p4034 = inttoptr i64 %v4033 to ptr
  %v4035 = load i64, ptr %slot586, align 8
  %p4036 = inttoptr i64 %v4035 to ptr
  %call4037 = call ptr @myl_native_list_copy(ptr %p4034, ptr %p4036) nomerge, !dbg !144
  %calladdr4038 = ptrtoint ptr %call4037 to i64
  store i64 %calladdr4038, ptr %slot587, align 8
  %v4039 = load i64, ptr %slot587, align 8
  %cond4040 = icmp ne i64 %v4039, 0
  br i1 %cond4040, label %bb_success790, label %bb_failed790
bb_failed790:
  %v4041 = load i64, ptr %slot1, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4042) nomerge, !dbg !144
  unreachable
bb_success790:
  %v4043 = load i64, ptr %slot587, align 8
  %v4044 = load i64, ptr %slot53, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i64 %v4043, ptr %p4045, align 8, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot53, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i64, ptr %p4047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4048, ptr %slot588, align 8
  %v4049 = load i64, ptr %slot588, align 8
  %v4050 = load i64, ptr %slot33, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  store i64 %v4049, ptr %p4051, align 8, !alias.scope !3, !noalias !4
  %v4052 = load i64, ptr %slot33, align 8
  store i64 %v4052, ptr %slot589, align 8
  %v4053 = load i64, ptr %slot35, align 8
  store i64 %v4053, ptr %slot590, align 8
  %v4054 = load i64, ptr %slot589, align 8
  %v4055 = load i64, ptr %slot590, align 8
  %p4056 = inttoptr i64 %v4054 to ptr
  %p4057 = inttoptr i64 %v4055 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4057, ptr %p4056, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4058 = load i64, ptr %slot28, align 8
  %p4059 = inttoptr i64 %v4058 to ptr
  store i32 2, ptr %p4059, align 4, !alias.scope !3, !noalias !4
  %v4060 = load i64, ptr %slot27, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  store i32 1, ptr %p4061, align 4, !alias.scope !3, !noalias !4
  %v4062 = load i64, ptr %slot30, align 8
  store i64 %v4062, ptr %slot591, align 8
  %v4063 = load i64, ptr %slot35, align 8
  store i64 %v4063, ptr %slot592, align 8
  %v4064 = load i64, ptr %slot592, align 8
  %v4065 = load i64, ptr %slot591, align 8
  %p4066 = inttoptr i64 %v4064 to ptr
  %p4067 = inttoptr i64 %v4065 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4067, ptr %p4066, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4068 = load i64, ptr %slot22, align 8
  %p4069 = inttoptr i64 %v4068 to ptr
  store i32 2, ptr %p4069, align 4, !alias.scope !3, !noalias !4
  %v4070 = load i64, ptr %slot28, align 8
  %p4071 = inttoptr i64 %v4070 to ptr
  %ld4072 = load i32, ptr %p4071, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4072, ptr %slot593, align 8
  %v4073 = load i32, ptr %slot593, align 8
  %v4074 = load i64, ptr %slot22, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  store i32 %v4073, ptr %p4075, align 4, !alias.scope !3, !noalias !4
  %v4076 = load i64, ptr %slot27, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i32 0, ptr %p4077, align 4, !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot21, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  store i32 1, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  %v4080 = load i64, ptr %slot591, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  %ld4082 = load i64, ptr %p4081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4082, ptr %slot594, align 8
  %v4083 = load i64, ptr %slot594, align 8
  %v4084 = load i64, ptr %slot53, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  store i64 %v4083, ptr %p4085, align 8, !alias.scope !3, !noalias !4
  %v4086 = load i64, ptr %slot43, align 8
  %v4087 = load i64, ptr %slot54, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  store i64 %v4086, ptr %p4088, align 8, !alias.scope !3, !noalias !4
  %v4089 = load i64, ptr %slot54, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %ld4091 = load i64, ptr %p4090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4091, ptr %slot595, align 8
  %v4092 = load i64, ptr %slot595, align 8
  %op4093 = add i64 %v4092, 8
  store i64 %op4093, ptr %slot596, align 8
  %v4094 = load i64, ptr %slot596, align 8
  %p4095 = inttoptr i64 %v4094 to ptr
  %ld4096 = load i64, ptr %p4095, align 8
  store i64 %ld4096, ptr %slot597, align 8
  %v4097 = load i64, ptr %slot597, align 8
  %v4098 = load i64, ptr %slot54, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  store i64 %v4097, ptr %p4099, align 8, !alias.scope !3, !noalias !4
  %v4100 = load i64, ptr %slot23, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  %ld4102 = load i32, ptr %p4101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4102, ptr %slot598, align 8
  %v4103 = load i32, ptr %slot598, align 8
  %cv4104 = zext i32 %v4103 to i64
  %cond4105 = icmp ne i64 %cv4104, 0
  br i1 %cond4105, label %bb_rcslotdrop810, label %bb_rcslotdone810
bb_rcslotdrop810:
  %v4106 = load i64, ptr %slot23, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  store i32 0, ptr %p4107, align 4, !alias.scope !3, !noalias !4
  %v4108 = load i64, ptr %slot31, align 8
  store i64 %v4108, ptr %slot599, align 8
  %v4109 = load i64, ptr %slot24, align 8
  %p4110 = inttoptr i64 %v4109 to ptr
  %ld4111 = load i32, ptr %p4110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4111, ptr %slot600, align 8
  %v4112 = load i32, ptr %slot600, align 8
  %op4113 = and i32 %v4112, 28
  store i32 %op4113, ptr %slot601, align 8
  %v4114 = load i32, ptr %slot601, align 8
  %cv4115 = zext i32 %v4114 to i64
  %cond4116 = icmp ne i64 %cv4115, 0
  br i1 %cond4116, label %bb_rcslotrole810, label %bb_rcslotowner810
bb_rcslotrole810:
  %v4117 = load i64, ptr %slot64, align 8
  store i64 %v4117, ptr %slot602, align 8
  %v4118 = load i64, ptr %slot602, align 8
  %v4119 = load i64, ptr %slot599, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4118, i64 %v4119) nomerge, !dbg !146
  br label %bb_rcslotdone810
bb_rcslotowner810:
  %v4120 = load i64, ptr %slot64, align 8
  store i64 %v4120, ptr %slot603, align 8
  %v4121 = load i64, ptr %slot603, align 8
  %v4122 = load i64, ptr %slot599, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4121, i64 %v4122) nomerge, !dbg !146
  br label %bb_rcslotdone810
bb_rcslotdone810:
  %v4123 = load i64, ptr %slot56, align 8
  store i64 %v4123, ptr %slot604, align 8
  %v4124 = load i64, ptr %slot604, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  store i64 0, ptr %p4125, align 8, !alias.scope !3, !noalias !4
  %v4126 = load i64, ptr %slot604, align 8
  %p4128 = inttoptr i64 %v4126 to ptr
  %gep4129 = getelementptr i8, ptr %p4128, i64 8
  %op4127 = ptrtoint ptr %gep4129 to i64
  store i64 %op4127, ptr %slot605, align 8
  %v4130 = load i64, ptr %slot605, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  store i64 0, ptr %p4131, align 8, !alias.scope !3, !noalias !4
  %v4132 = load i64, ptr %slot29, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i32 1, ptr %p4133, align 4, !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot65, align 8
  store i64 %v4134, ptr %slot606, align 8
  %v4135 = load i64, ptr %slot53, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %ld4137 = load i64, ptr %p4136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4137, ptr %slot607, align 8
  %v4138 = load i64, ptr %slot607, align 8
  %v4139 = load i64, ptr %slot33, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  store i64 %v4138, ptr %p4140, align 8, !alias.scope !3, !noalias !4
  %v4141 = load i64, ptr %slot33, align 8
  store i64 %v4141, ptr %slot608, align 8
  %v4142 = load i64, ptr %slot604, align 8
  %p4144 = inttoptr i64 %v4142 to ptr
  %gep4145 = getelementptr i8, ptr %p4144, i64 0
  %op4143 = ptrtoint ptr %gep4145 to i64
  store i64 %op4143, ptr %slot609, align 8
  %v4146 = load i64, ptr %slot53, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  %ld4148 = load i64, ptr %p4147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4148, ptr %slot610, align 8
  %v4149 = load i64, ptr %slot610, align 8
  %v4150 = load i64, ptr %slot33, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  store i64 %v4149, ptr %p4151, align 8, !alias.scope !3, !noalias !4
  %v4152 = load i64, ptr %slot33, align 8
  store i64 %v4152, ptr %slot611, align 8
  %v4153 = load i64, ptr %slot21, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  %ld4155 = load i32, ptr %p4154, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4155, ptr %slot612, align 8
  %v4156 = load i64, ptr %slot22, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %ld4158 = load i32, ptr %p4157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4158, ptr %slot613, align 8
  %v4159 = load i32, ptr %slot613, align 8
  %op4160 = and i32 %v4159, 24
  store i32 %op4160, ptr %slot613, align 8
  %v4161 = load i32, ptr %slot613, align 8
  %cmp4162 = icmp eq i32 %v4161, 0
  %cv4163 = zext i1 %cmp4162 to i32
  store i32 %cv4163, ptr %slot614, align 8
  %v4164 = load i32, ptr %slot612, align 8
  %v4165 = load i32, ptr %slot614, align 8
  %op4166 = and i32 %v4164, %v4165
  store i32 %op4166, ptr %slot615, align 8
  %v4167 = load i32, ptr %slot615, align 8
  %cv4168 = zext i32 %v4167 to i64
  %cond4169 = icmp ne i64 %cv4168, 0
  br i1 %cond4169, label %bb_rctake827, label %bb_rccopy827
bb_rctake827:
  %v4170 = load i64, ptr %slot35, align 8
  store i64 %v4170, ptr %slot616, align 8
  %v4171 = load i64, ptr %slot65, align 8
  store i64 %v4171, ptr %slot617, align 8
  %v4172 = load i64, ptr %slot611, align 8
  %v4173 = load i64, ptr %slot616, align 8
  %op4174 = sub i64 %v4172, %v4173
  store i64 %op4174, ptr %slot618, align 8
  %v4175 = load i64, ptr %slot616, align 8
  %v4176 = load i64, ptr %slot611, align 8
  %op4177 = sub i64 %v4175, %v4176
  store i64 %op4177, ptr %slot619, align 8
  %v4178 = load i64, ptr %slot618, align 8
  %cmp4179 = icmp ult i64 %v4178, 8
  %cv4180 = zext i1 %cmp4179 to i32
  store i32 %cv4180, ptr %slot620, align 8
  %v4181 = load i64, ptr %slot619, align 8
  %cmp4182 = icmp ult i64 %v4181, 8
  %cv4183 = zext i1 %cmp4182 to i32
  store i32 %cv4183, ptr %slot621, align 8
  %v4184 = load i32, ptr %slot620, align 8
  %v4185 = load i32, ptr %slot621, align 8
  %op4186 = or i32 %v4184, %v4185
  store i32 %op4186, ptr %slot622, align 8
  %v4187 = load i32, ptr %slot622, align 8
  %cv4188 = zext i32 %v4187 to i64
  %cond4189 = icmp ne i64 %cv4188, 0
  br i1 %cond4189, label %bb_rcmoveslow836, label %bb_rcmovecheck836
bb_rcmovecheck836:
  %v4190 = load i64, ptr %slot611, align 8
  %p4192 = inttoptr i64 %v4190 to ptr
  %gep4193 = getelementptr i8, ptr %p4192, i64 0
  %op4191 = ptrtoint ptr %gep4193 to i64
  store i64 %op4191, ptr %slot623, align 8
  %v4194 = load i64, ptr %slot623, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  %ld4196 = load i64, ptr %p4195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4196, ptr %slot624, align 8
  %v4197 = load i64, ptr %slot624, align 8
  %cmp4198 = icmp ne i64 %v4197, 0
  %cv4199 = zext i1 %cmp4198 to i32
  store i32 %cv4199, ptr %slot625, align 8
  %v4200 = load i32, ptr %slot625, align 8
  %cv4201 = zext i32 %v4200 to i64
  %cond4202 = icmp ne i64 %cv4201, 0
  br i1 %cond4202, label %bb_rcmoveheader844, label %bb_rcmovenext844
bb_rcmoveheader844:
  %v4203 = load i64, ptr %slot624, align 8
  %op4204 = sub i64 %v4203, 16
  store i64 %op4204, ptr %slot626, align 8
  %v4205 = load i64, ptr %slot624, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %rgep4207 = getelementptr i8, ptr %p4206, i64 -16
  %ld4208 = load i64, ptr %rgep4207, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4208, ptr %slot627, align 8
  %v4209 = load i64, ptr %slot627, align 8
  %op4210 = and i64 %v4209, 5764607523034234881
  store i64 %op4210, ptr %slot628, align 8
  %v4211 = load i64, ptr %slot628, align 8
  %cmp4212 = icmp ne i64 %v4211, 0
  %cv4213 = zext i1 %cmp4212 to i32
  store i32 %cv4213, ptr %slot629, align 8
  %v4214 = load i32, ptr %slot629, align 8
  %cv4215 = zext i32 %v4214 to i64
  %cond4216 = icmp ne i64 %cv4215, 0
  br i1 %cond4216, label %bb_rcmoveslow836, label %bb_rcmovenext844
bb_rcmovenext844:
  %v4217 = load i64, ptr %slot611, align 8
  %v4218 = load i64, ptr %slot616, align 8
  %p4219 = inttoptr i64 %v4217 to ptr
  %p4220 = inttoptr i64 %v4218 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4220, ptr %p4219, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4221 = load i64, ptr %slot611, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  store i64 0, ptr %p4222, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved836
bb_rcmoveslow836:
  %v4223 = load i64, ptr %slot64, align 8
  %v4224 = load i64, ptr %slot616, align 8
  %v4225 = load i64, ptr %slot611, align 8
  %v4226 = load i64, ptr %slot617, align 8
  %cv4227 = trunc i64 %v4226 to i32
  %call4228 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v4223, i64 %v4224, i64 %v4225, i32 %cv4227) nomerge, !dbg !148
  store i32 %call4228, ptr %slot630, align 8
  %v4229 = load i32, ptr %slot630, align 8
  %cv4230 = zext i32 %v4229 to i64
  %cond4231 = icmp ne i64 %cv4230, 0
  br i1 %cond4231, label %bb_rcsuccess851, label %bb_rcfailure851
bb_rcfailure851:
  %v4232 = load i64, ptr %slot64, align 8
  %p4233 = inttoptr i64 %v4232 to ptr
  %call4234 = call i32 @myl_rc_take_failure(ptr %p4233) nomerge, !dbg !148
  store i32 %call4234, ptr %slot631, align 8
  %v4235 = load i64, ptr %slot1, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  %v4237 = load i32, ptr %slot631, align 8
  %call4238 = call i32 @myl_qbe_rc_status(ptr %p4236, i32 %v4237) nomerge, !dbg !148
  store i32 %call4238, ptr %slot632, align 8
  br label %bb_failure
bb_rcsuccess851:
  br label %bb_rcmoved836
bb_rcmoved836:
  %v4239 = load i64, ptr %slot21, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  store i32 0, ptr %p4240, align 4, !alias.scope !3, !noalias !4
  %v4241 = load i64, ptr %slot28, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  store i32 2, ptr %p4242, align 4, !alias.scope !3, !noalias !4
  %v4243 = load i64, ptr %slot27, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  store i32 1, ptr %p4244, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared827
bb_rccopy827:
  %v4245 = load i64, ptr %slot35, align 8
  store i64 %v4245, ptr %slot633, align 8
  %v4246 = load i64, ptr %slot65, align 8
  store i64 %v4246, ptr %slot634, align 8
  %v4247 = load i64, ptr %slot611, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %ld4249 = load i64, ptr %p4248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4249, ptr %slot635, align 8
  %v4250 = load i64, ptr %slot635, align 8
  %cmp4251 = icmp ne i64 %v4250, 0
  %cv4252 = zext i1 %cmp4251 to i32
  store i32 %cv4252, ptr %slot636, align 8
  %v4253 = load i32, ptr %slot636, align 8
  %cv4254 = zext i32 %v4253 to i64
  %cond4255 = icmp ne i64 %cv4254, 0
  br i1 %cond4255, label %bb_rcgnn860, label %bb_rcgplain860
bb_rcgnn860:
  %v4256 = load i64, ptr %slot635, align 8
  %op4257 = sub i64 %v4256, 16
  store i64 %op4257, ptr %slot637, align 8
  %v4258 = load i64, ptr %slot635, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  %rgep4260 = getelementptr i8, ptr %p4259, i64 -16
  %ld4261 = load i64, ptr %rgep4260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4261, ptr %slot638, align 8
  %v4262 = load i64, ptr %slot638, align 8
  %op4263 = and i64 %v4262, 4611686018427387906
  store i64 %op4263, ptr %slot639, align 8
  %v4264 = load i64, ptr %slot639, align 8
  %cmp4265 = icmp ne i64 %v4264, 0
  %cv4266 = zext i1 %cmp4265 to i32
  store i32 %cv4266, ptr %slot640, align 8
  %v4267 = load i32, ptr %slot640, align 8
  %cv4268 = zext i32 %v4267 to i64
  %cond4269 = icmp ne i64 %cv4268, 0
  br i1 %cond4269, label %bb_rcgspecial860, label %bb_rcginc860
bb_rcginc860:
  %v4270 = load i64, ptr %slot635, align 8
  %op4271 = sub i64 %v4270, 32
  store i64 %op4271, ptr %slot641, align 8
  %v4272 = load i64, ptr %slot635, align 8
  %p4273 = inttoptr i64 %v4272 to ptr
  %rgep4274 = getelementptr i8, ptr %p4273, i64 -32
  %ld4275 = load i64, ptr %rgep4274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4275, ptr %slot642, align 8
  %v4276 = load i64, ptr %slot642, align 8
  %op4277 = add i64 %v4276, 1
  store i64 %op4277, ptr %slot643, align 8
  %v4278 = load i64, ptr %slot643, align 8
  %cmp4279 = icmp eq i64 %v4278, 0
  %cv4280 = zext i1 %cmp4279 to i32
  store i32 %cv4280, ptr %slot644, align 8
  %v4281 = load i32, ptr %slot644, align 8
  %cv4282 = zext i32 %v4281 to i64
  %cond4283 = icmp ne i64 %cv4282, 0
  br i1 %cond4283, label %bb_rcglimit860, label %bb_rcgcapacity860
bb_rcglimit860:
  %v4284 = load i64, ptr %slot1, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  %call4286 = call i32 @myl_qbe_rc_status(ptr %p4285, i32 2) nomerge, !dbg !148
  store i32 %call4286, ptr %slot645, align 8
  br label %bb_failure
bb_rcgcapacity860:
  %v4287 = load i64, ptr %slot643, align 8
  %v4288 = load i64, ptr %slot635, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  %rgep4290 = getelementptr i8, ptr %p4289, i64 -32
  store i64 %v4287, ptr %rgep4290, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain860
bb_rcgspecial860:
  %v4291 = load i64, ptr %slot638, align 8
  %op4292 = and i64 %v4291, 4611686018427387904
  store i64 %op4292, ptr %slot646, align 8
  %v4293 = load i64, ptr %slot646, align 8
  %cmp4294 = icmp ne i64 %v4293, 0
  %cv4295 = zext i1 %cmp4294 to i32
  store i32 %cv4295, ptr %slot647, align 8
  %v4296 = load i32, ptr %slot647, align 8
  %cv4297 = zext i32 %v4296 to i64
  %cond4298 = icmp ne i64 %cv4297, 0
  br i1 %cond4298, label %bb_rcgslow860, label %bb_rcgplain860
bb_rcgslow860:
  %v4299 = load i64, ptr %slot64, align 8
  %v4300 = load i64, ptr %slot633, align 8
  %v4301 = load i64, ptr %slot611, align 8
  %v4302 = load i64, ptr %slot634, align 8
  %cv4303 = trunc i64 %v4302 to i32
  %call4304 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64 %v4299, i64 %v4300, i64 %v4301, i32 %cv4303) nomerge, !dbg !148
  store i32 %call4304, ptr %slot648, align 8
  %v4305 = load i32, ptr %slot648, align 8
  %cv4306 = zext i32 %v4305 to i64
  %cond4307 = icmp ne i64 %cv4306, 0
  br i1 %cond4307, label %bb_rcsuccess874, label %bb_rcfailure874
bb_rcfailure874:
  %v4308 = load i64, ptr %slot64, align 8
  %p4309 = inttoptr i64 %v4308 to ptr
  %call4310 = call i32 @myl_rc_take_failure(ptr %p4309) nomerge, !dbg !148
  store i32 %call4310, ptr %slot649, align 8
  %v4311 = load i64, ptr %slot1, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  %v4313 = load i32, ptr %slot649, align 8
  %call4314 = call i32 @myl_qbe_rc_status(ptr %p4312, i32 %v4313) nomerge, !dbg !148
  store i32 %call4314, ptr %slot650, align 8
  br label %bb_failure
bb_rcsuccess874:
  br label %bb_rcgdone860
bb_rcgplain860:
  %v4315 = load i64, ptr %slot635, align 8
  %v4316 = load i64, ptr %slot633, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  store i64 %v4315, ptr %p4317, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone860
bb_rcgdone860:
  %v4318 = load i64, ptr %slot28, align 8
  %p4319 = inttoptr i64 %v4318 to ptr
  store i32 2, ptr %p4319, align 4, !alias.scope !3, !noalias !4
  %v4320 = load i64, ptr %slot27, align 8
  %p4321 = inttoptr i64 %v4320 to ptr
  store i32 1, ptr %p4321, align 4, !alias.scope !3, !noalias !4
  %v4322 = load i64, ptr %slot21, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i32, ptr %p4323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4324, ptr %slot651, align 8
  %v4325 = load i32, ptr %slot651, align 8
  %cv4326 = zext i32 %v4325 to i64
  %cond4327 = icmp ne i64 %cv4326, 0
  br i1 %cond4327, label %bb_rcslotdrop881, label %bb_rcslotdone881
bb_rcslotdrop881:
  %v4328 = load i64, ptr %slot21, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  store i32 0, ptr %p4329, align 4, !alias.scope !3, !noalias !4
  %v4330 = load i64, ptr %slot30, align 8
  store i64 %v4330, ptr %slot652, align 8
  %v4331 = load i64, ptr %slot22, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  %ld4333 = load i32, ptr %p4332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4333, ptr %slot653, align 8
  %v4334 = load i32, ptr %slot653, align 8
  %op4335 = and i32 %v4334, 28
  store i32 %op4335, ptr %slot654, align 8
  %v4336 = load i32, ptr %slot654, align 8
  %cv4337 = zext i32 %v4336 to i64
  %cond4338 = icmp ne i64 %cv4337, 0
  br i1 %cond4338, label %bb_rcslotrole881, label %bb_rcslotowner881
bb_rcslotrole881:
  %v4339 = load i64, ptr %slot64, align 8
  store i64 %v4339, ptr %slot655, align 8
  %v4340 = load i64, ptr %slot652, align 8
  %p4341 = inttoptr i64 %v4340 to ptr
  %ld4342 = load i64, ptr %p4341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4342, ptr %slot656, align 8
  %v4343 = load i64, ptr %slot656, align 8
  %cmp4344 = icmp ne i64 %v4343, 0
  %cv4345 = zext i1 %cmp4344 to i32
  store i32 %cv4345, ptr %slot657, align 8
  %v4346 = load i32, ptr %slot657, align 8
  %cv4347 = zext i32 %v4346 to i64
  %cond4348 = icmp ne i64 %cv4347, 0
  br i1 %cond4348, label %bb_rcgnn897, label %bb_rcgdone897
bb_rcgnn897:
  %v4349 = load i64, ptr %slot656, align 8
  %op4350 = sub i64 %v4349, 16
  store i64 %op4350, ptr %slot658, align 8
  %v4351 = load i64, ptr %slot656, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %rgep4353 = getelementptr i8, ptr %p4352, i64 -16
  %ld4354 = load i64, ptr %rgep4353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4354, ptr %slot659, align 8
  %v4355 = load i64, ptr %slot659, align 8
  %op4356 = and i64 %v4355, 4611686018427387906
  store i64 %op4356, ptr %slot660, align 8
  %v4357 = load i64, ptr %slot660, align 8
  %cmp4358 = icmp ne i64 %v4357, 0
  %cv4359 = zext i1 %cmp4358 to i32
  store i32 %cv4359, ptr %slot661, align 8
  %v4360 = load i32, ptr %slot661, align 8
  %cv4361 = zext i32 %v4360 to i64
  %cond4362 = icmp ne i64 %cv4361, 0
  br i1 %cond4362, label %bb_rcgclear897, label %bb_rcgcounted897
bb_rcgcounted897:
  %v4363 = load i64, ptr %slot656, align 8
  %op4364 = sub i64 %v4363, 24
  store i64 %op4364, ptr %slot662, align 8
  %v4365 = load i64, ptr %slot656, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  %rgep4367 = getelementptr i8, ptr %p4366, i64 -24
  %ld4368 = load i64, ptr %rgep4367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4368, ptr %slot663, align 8
  %v4369 = load i64, ptr %slot663, align 8
  %op4370 = sub i64 %v4369, 1
  store i64 %op4370, ptr %slot664, align 8
  %v4371 = load i64, ptr %slot664, align 8
  %cmp4372 = icmp eq i64 %v4371, 0
  %cv4373 = zext i1 %cmp4372 to i32
  store i32 %cv4373, ptr %slot665, align 8
  %v4374 = load i32, ptr %slot665, align 8
  %cv4375 = zext i32 %v4374 to i64
  %cond4376 = icmp ne i64 %cv4375, 0
  br i1 %cond4376, label %bb_rcglast897, label %bb_rcgdec897
bb_rcglast897:
  %v4377 = load i64, ptr %slot656, align 8
  %op4378 = sub i64 %v4377, 32
  store i64 %op4378, ptr %slot666, align 8
  %v4379 = load i64, ptr %slot656, align 8
  %p4380 = inttoptr i64 %v4379 to ptr
  %rgep4381 = getelementptr i8, ptr %p4380, i64 -32
  %ld4382 = load i64, ptr %rgep4381, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4382, ptr %slot667, align 8
  %v4383 = load i64, ptr %slot667, align 8
  %cmp4384 = icmp ne i64 %v4383, 0
  %cv4385 = zext i1 %cmp4384 to i32
  store i32 %cv4385, ptr %slot668, align 8
  %v4386 = load i32, ptr %slot668, align 8
  %cv4387 = zext i32 %v4386 to i64
  %cond4388 = icmp ne i64 %cv4387, 0
  br i1 %cond4388, label %bb_rcgdec897, label %bb_rcgslow897
bb_rcgslow897:
  %v4389 = load i64, ptr %slot655, align 8
  %v4390 = load i64, ptr %slot652, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v4389, i64 %v4390) nomerge, !dbg !148
  br label %bb_rcgdone897
bb_rcgdec897:
  %v4391 = load i64, ptr %slot664, align 8
  %v4392 = load i64, ptr %slot656, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %rgep4394 = getelementptr i8, ptr %p4393, i64 -24
  store i64 %v4391, ptr %rgep4394, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear897
bb_rcgclear897:
  %v4395 = load i64, ptr %slot652, align 8
  %p4396 = inttoptr i64 %v4395 to ptr
  store i64 0, ptr %p4396, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone897
bb_rcgdone897:
  br label %bb_rcslotdone881
bb_rcslotowner881:
  %v4397 = load i64, ptr %slot64, align 8
  store i64 %v4397, ptr %slot669, align 8
  %v4398 = load i64, ptr %slot652, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  %ld4400 = load i64, ptr %p4399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4400, ptr %slot670, align 8
  %v4401 = load i64, ptr %slot670, align 8
  %cmp4402 = icmp ne i64 %v4401, 0
  %cv4403 = zext i1 %cmp4402 to i32
  store i32 %cv4403, ptr %slot671, align 8
  %v4404 = load i32, ptr %slot671, align 8
  %cv4405 = zext i32 %v4404 to i64
  %cond4406 = icmp ne i64 %cv4405, 0
  br i1 %cond4406, label %bb_rcgnn912, label %bb_rcgdone912
bb_rcgnn912:
  %v4407 = load i64, ptr %slot670, align 8
  %op4408 = sub i64 %v4407, 16
  store i64 %op4408, ptr %slot672, align 8
  %v4409 = load i64, ptr %slot670, align 8
  %p4410 = inttoptr i64 %v4409 to ptr
  %rgep4411 = getelementptr i8, ptr %p4410, i64 -16
  %ld4412 = load i64, ptr %rgep4411, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4412, ptr %slot673, align 8
  %v4413 = load i64, ptr %slot673, align 8
  %op4414 = and i64 %v4413, 4611686018427387906
  store i64 %op4414, ptr %slot674, align 8
  %v4415 = load i64, ptr %slot674, align 8
  %cmp4416 = icmp ne i64 %v4415, 0
  %cv4417 = zext i1 %cmp4416 to i32
  store i32 %cv4417, ptr %slot675, align 8
  %v4418 = load i32, ptr %slot675, align 8
  %cv4419 = zext i32 %v4418 to i64
  %cond4420 = icmp ne i64 %cv4419, 0
  br i1 %cond4420, label %bb_rcgclear912, label %bb_rcgcounted912
bb_rcgcounted912:
  %v4421 = load i64, ptr %slot670, align 8
  %op4422 = sub i64 %v4421, 32
  store i64 %op4422, ptr %slot676, align 8
  %v4423 = load i64, ptr %slot670, align 8
  %p4424 = inttoptr i64 %v4423 to ptr
  %rgep4425 = getelementptr i8, ptr %p4424, i64 -32
  %ld4426 = load i64, ptr %rgep4425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4426, ptr %slot677, align 8
  %v4427 = load i64, ptr %slot677, align 8
  %op4428 = sub i64 %v4427, 1
  store i64 %op4428, ptr %slot678, align 8
  %v4429 = load i64, ptr %slot678, align 8
  %cmp4430 = icmp eq i64 %v4429, 0
  %cv4431 = zext i1 %cmp4430 to i32
  store i32 %cv4431, ptr %slot679, align 8
  %v4432 = load i32, ptr %slot679, align 8
  %cv4433 = zext i32 %v4432 to i64
  %cond4434 = icmp ne i64 %cv4433, 0
  br i1 %cond4434, label %bb_rcglast912, label %bb_rcgdec912
bb_rcglast912:
  %v4435 = load i64, ptr %slot670, align 8
  %op4436 = sub i64 %v4435, 24
  store i64 %op4436, ptr %slot680, align 8
  %v4437 = load i64, ptr %slot670, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  %rgep4439 = getelementptr i8, ptr %p4438, i64 -24
  %ld4440 = load i64, ptr %rgep4439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4440, ptr %slot681, align 8
  %v4441 = load i64, ptr %slot681, align 8
  %cmp4442 = icmp ne i64 %v4441, 0
  %cv4443 = zext i1 %cmp4442 to i32
  store i32 %cv4443, ptr %slot682, align 8
  %v4444 = load i32, ptr %slot682, align 8
  %cv4445 = zext i32 %v4444 to i64
  %cond4446 = icmp ne i64 %cv4445, 0
  br i1 %cond4446, label %bb_rcgdec912, label %bb_rcgslow912
bb_rcgslow912:
  %v4447 = load i64, ptr %slot669, align 8
  %v4448 = load i64, ptr %slot652, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4447, i64 %v4448) nomerge, !dbg !148
  br label %bb_rcgdone912
bb_rcgdec912:
  %v4449 = load i64, ptr %slot678, align 8
  %v4450 = load i64, ptr %slot670, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %rgep4452 = getelementptr i8, ptr %p4451, i64 -32
  store i64 %v4449, ptr %rgep4452, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear912
bb_rcgclear912:
  %v4453 = load i64, ptr %slot652, align 8
  %p4454 = inttoptr i64 %v4453 to ptr
  store i64 0, ptr %p4454, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone912
bb_rcgdone912:
  br label %bb_rcslotdone881
bb_rcslotdone881:
  br label %bb_rcprepared827
bb_rcprepared827:
  %v4455 = load i64, ptr %slot35, align 8
  store i64 %v4455, ptr %slot683, align 8
  %v4456 = load i64, ptr %slot683, align 8
  %v4457 = load i64, ptr %slot609, align 8
  %p4458 = inttoptr i64 %v4456 to ptr
  %p4459 = inttoptr i64 %v4457 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4459, ptr %p4458, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4460 = load i64, ptr %slot27, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  store i32 0, ptr %p4461, align 4, !alias.scope !3, !noalias !4
  %v4462 = load i64, ptr %slot54, align 8
  store i64 %v4462, ptr %slot684, align 8
  %v4463 = load i64, ptr %slot604, align 8
  %p4465 = inttoptr i64 %v4463 to ptr
  %gep4466 = getelementptr i8, ptr %p4465, i64 8
  %op4464 = ptrtoint ptr %gep4466 to i64
  store i64 %op4464, ptr %slot685, align 8
  %v4467 = load i64, ptr %slot684, align 8
  %p4468 = inttoptr i64 %v4467 to ptr
  %ld4469 = load i64, ptr %p4468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4469, ptr %slot686, align 8
  %v4470 = load i64, ptr %slot686, align 8
  %v4471 = load i64, ptr %slot685, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  store i64 %v4470, ptr %p4472, align 8, !alias.scope !3, !noalias !4
  %v4473 = load i64, ptr %slot604, align 8
  %v4474 = load i64, ptr %slot53, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  store i64 %v4473, ptr %p4475, align 8, !alias.scope !3, !noalias !4
  %v4476 = load i64, ptr %slot53, align 8
  %p4477 = inttoptr i64 %v4476 to ptr
  %ld4478 = load i64, ptr %p4477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4478, ptr %slot687, align 8
  %v4479 = load i64, ptr %slot30, align 8
  store i64 %v4479, ptr %slot688, align 8
  %v4480 = load i64, ptr %slot687, align 8
  %v4481 = load i64, ptr %slot688, align 8
  %p4482 = inttoptr i64 %v4480 to ptr
  %p4483 = inttoptr i64 %v4481 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4483, ptr %p4482, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4484 = load i64, ptr %slot22, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  store i32 2, ptr %p4485, align 4, !alias.scope !3, !noalias !4
  %v4486 = load i64, ptr %slot21, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  store i32 1, ptr %p4487, align 4, !alias.scope !3, !noalias !4
  %v4488 = load i64, ptr %slot688, align 8
  %v4489 = load i64, ptr %slot53, align 8
  %p4490 = inttoptr i64 %v4489 to ptr
  store i64 %v4488, ptr %p4490, align 8, !alias.scope !3, !noalias !4
  %v4491 = load i64, ptr %slot53, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %ld4493 = load i64, ptr %p4492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4493, ptr %slot689, align 8
  %v4494 = load i64, ptr %slot35, align 8
  store i64 %v4494, ptr %slot690, align 8
  %v4495 = load i64, ptr %slot65, align 8
  store i64 %v4495, ptr %slot691, align 8
  %v4496 = load i64, ptr %slot689, align 8
  %op4497 = add i64 %v4496, 0
  store i64 %op4497, ptr %slot692, align 8
  %v4498 = load i64, ptr %slot692, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  %ld4500 = load i64, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4500, ptr %slot693, align 8
  %v4501 = load i64, ptr %slot693, align 8
  %cmp4502 = icmp ne i64 %v4501, 0
  %cv4503 = zext i1 %cmp4502 to i32
  store i32 %cv4503, ptr %slot694, align 8
  %v4504 = load i32, ptr %slot694, align 8
  %cv4505 = zext i32 %v4504 to i64
  %cond4506 = icmp ne i64 %cv4505, 0
  br i1 %cond4506, label %bb_rcmoveheader931, label %bb_rcmovenext931
bb_rcmoveheader931:
  %v4507 = load i64, ptr %slot693, align 8
  %op4508 = sub i64 %v4507, 16
  store i64 %op4508, ptr %slot695, align 8
  %v4509 = load i64, ptr %slot693, align 8
  %p4510 = inttoptr i64 %v4509 to ptr
  %rgep4511 = getelementptr i8, ptr %p4510, i64 -16
  %ld4512 = load i64, ptr %rgep4511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4512, ptr %slot696, align 8
  %v4513 = load i64, ptr %slot696, align 8
  %op4514 = and i64 %v4513, 5764607523034234881
  store i64 %op4514, ptr %slot697, align 8
  %v4515 = load i64, ptr %slot697, align 8
  %cmp4516 = icmp ne i64 %v4515, 0
  %cv4517 = zext i1 %cmp4516 to i32
  store i32 %cv4517, ptr %slot698, align 8
  %v4518 = load i32, ptr %slot698, align 8
  %cv4519 = zext i32 %v4518 to i64
  %cond4520 = icmp ne i64 %cv4519, 0
  br i1 %cond4520, label %bb_rcmoveslow928, label %bb_rcmovenext931
bb_rcmovenext931:
  %v4521 = load i64, ptr %slot689, align 8
  %v4522 = load i64, ptr %slot690, align 8
  %p4523 = inttoptr i64 %v4521 to ptr
  %p4524 = inttoptr i64 %v4522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4524, ptr %p4523, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4525 = load i64, ptr %slot689, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  store i64 0, ptr %p4526, align 8, !alias.scope !3, !noalias !4
  %v4527 = load i64, ptr %slot689, align 8
  %op4528 = add i64 %v4527, 8
  store i64 %op4528, ptr %slot699, align 8
  %v4529 = load i64, ptr %slot699, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  store i64 0, ptr %p4530, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved928
bb_rcmoveslow928:
  %v4531 = load i64, ptr %slot64, align 8
  %v4532 = load i64, ptr %slot690, align 8
  %v4533 = load i64, ptr %slot689, align 8
  %v4534 = load i64, ptr %slot691, align 8
  %cv4535 = trunc i64 %v4534 to i32
  %call4536 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v4531, i64 %v4532, i64 %v4533, i32 %cv4535) nomerge, !dbg !150
  store i32 %call4536, ptr %slot700, align 8
  %v4537 = load i32, ptr %slot700, align 8
  %cv4538 = zext i32 %v4537 to i64
  %cond4539 = icmp ne i64 %cv4538, 0
  br i1 %cond4539, label %bb_rcsuccess939, label %bb_rcfailure939
bb_rcfailure939:
  %v4540 = load i64, ptr %slot64, align 8
  %p4541 = inttoptr i64 %v4540 to ptr
  %call4542 = call i32 @myl_rc_take_failure(ptr %p4541) nomerge, !dbg !150
  store i32 %call4542, ptr %slot701, align 8
  %v4543 = load i64, ptr %slot1, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %v4545 = load i32, ptr %slot701, align 8
  %call4546 = call i32 @myl_qbe_rc_status(ptr %p4544, i32 %v4545) nomerge, !dbg !150
  store i32 %call4546, ptr %slot702, align 8
  br label %bb_failure
bb_rcsuccess939:
  br label %bb_rcmoved928
bb_rcmoved928:
  %v4547 = load i64, ptr %slot21, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  store i32 0, ptr %p4548, align 4, !alias.scope !3, !noalias !4
  %v4549 = load i64, ptr %slot28, align 8
  %p4550 = inttoptr i64 %v4549 to ptr
  store i32 2, ptr %p4550, align 4, !alias.scope !3, !noalias !4
  %v4551 = load i64, ptr %slot27, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  store i32 1, ptr %p4552, align 4, !alias.scope !3, !noalias !4
  %v4553 = load i64, ptr %slot11, align 8
  %p4554 = inttoptr i64 %v4553 to ptr
  %ld4555 = load i32, ptr %p4554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4555, ptr %slot703, align 8
  %v4556 = load i32, ptr %slot703, align 8
  %cv4557 = zext i32 %v4556 to i64
  %cond4558 = icmp ne i64 %cv4557, 0
  br i1 %cond4558, label %bb_rcslotdrop948, label %bb_rcslotdone948
bb_rcslotdrop948:
  %v4559 = load i64, ptr %slot11, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  store i32 0, ptr %p4560, align 4, !alias.scope !3, !noalias !4
  %v4561 = load i64, ptr %slot45, align 8
  store i64 %v4561, ptr %slot704, align 8
  %v4562 = load i64, ptr %slot12, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  %ld4564 = load i32, ptr %p4563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4564, ptr %slot705, align 8
  %v4565 = load i32, ptr %slot705, align 8
  %op4566 = and i32 %v4565, 28
  store i32 %op4566, ptr %slot706, align 8
  %v4567 = load i32, ptr %slot706, align 8
  %cv4568 = zext i32 %v4567 to i64
  %cond4569 = icmp ne i64 %cv4568, 0
  br i1 %cond4569, label %bb_rcslotrole948, label %bb_rcslotowner948
bb_rcslotrole948:
  %v4570 = load i64, ptr %slot64, align 8
  store i64 %v4570, ptr %slot707, align 8
  %v4571 = load i64, ptr %slot707, align 8
  %v4572 = load i64, ptr %slot704, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4571, i64 %v4572) nomerge, !dbg !150
  br label %bb_rcslotdone948
bb_rcslotowner948:
  %v4573 = load i64, ptr %slot704, align 8
  %p4575 = inttoptr i64 %v4573 to ptr
  %gep4576 = getelementptr i8, ptr %p4575, i64 0
  %op4574 = ptrtoint ptr %gep4576 to i64
  store i64 %op4574, ptr %slot708, align 8
  %v4577 = load i64, ptr %slot64, align 8
  store i64 %v4577, ptr %slot709, align 8
  %v4578 = load i64, ptr %slot708, align 8
  %p4579 = inttoptr i64 %v4578 to ptr
  %ld4580 = load i64, ptr %p4579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4580, ptr %slot710, align 8
  %v4581 = load i64, ptr %slot710, align 8
  %cmp4582 = icmp ne i64 %v4581, 0
  %cv4583 = zext i1 %cmp4582 to i32
  store i32 %cv4583, ptr %slot711, align 8
  %v4584 = load i32, ptr %slot711, align 8
  %cv4585 = zext i32 %v4584 to i64
  %cond4586 = icmp ne i64 %cv4585, 0
  br i1 %cond4586, label %bb_rcgnn966, label %bb_rcgdone966
bb_rcgnn966:
  %v4587 = load i64, ptr %slot710, align 8
  %op4588 = sub i64 %v4587, 16
  store i64 %op4588, ptr %slot712, align 8
  %v4589 = load i64, ptr %slot710, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %rgep4591 = getelementptr i8, ptr %p4590, i64 -16
  %ld4592 = load i64, ptr %rgep4591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4592, ptr %slot713, align 8
  %v4593 = load i64, ptr %slot713, align 8
  %op4594 = and i64 %v4593, 4611686018427387906
  store i64 %op4594, ptr %slot714, align 8
  %v4595 = load i64, ptr %slot714, align 8
  %cmp4596 = icmp ne i64 %v4595, 0
  %cv4597 = zext i1 %cmp4596 to i32
  store i32 %cv4597, ptr %slot715, align 8
  %v4598 = load i32, ptr %slot715, align 8
  %cv4599 = zext i32 %v4598 to i64
  %cond4600 = icmp ne i64 %cv4599, 0
  br i1 %cond4600, label %bb_rcgclear966, label %bb_rcgcounted966
bb_rcgcounted966:
  %v4601 = load i64, ptr %slot710, align 8
  %op4602 = sub i64 %v4601, 32
  store i64 %op4602, ptr %slot716, align 8
  %v4603 = load i64, ptr %slot710, align 8
  %p4604 = inttoptr i64 %v4603 to ptr
  %rgep4605 = getelementptr i8, ptr %p4604, i64 -32
  %ld4606 = load i64, ptr %rgep4605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4606, ptr %slot717, align 8
  %v4607 = load i64, ptr %slot717, align 8
  %op4608 = sub i64 %v4607, 1
  store i64 %op4608, ptr %slot718, align 8
  %v4609 = load i64, ptr %slot718, align 8
  %cmp4610 = icmp eq i64 %v4609, 0
  %cv4611 = zext i1 %cmp4610 to i32
  store i32 %cv4611, ptr %slot719, align 8
  %v4612 = load i32, ptr %slot719, align 8
  %cv4613 = zext i32 %v4612 to i64
  %cond4614 = icmp ne i64 %cv4613, 0
  br i1 %cond4614, label %bb_rcglast966, label %bb_rcgdec966
bb_rcglast966:
  %v4615 = load i64, ptr %slot710, align 8
  %op4616 = sub i64 %v4615, 24
  store i64 %op4616, ptr %slot720, align 8
  %v4617 = load i64, ptr %slot710, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  %rgep4619 = getelementptr i8, ptr %p4618, i64 -24
  %ld4620 = load i64, ptr %rgep4619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4620, ptr %slot721, align 8
  %v4621 = load i64, ptr %slot721, align 8
  %cmp4622 = icmp ne i64 %v4621, 0
  %cv4623 = zext i1 %cmp4622 to i32
  store i32 %cv4623, ptr %slot722, align 8
  %v4624 = load i32, ptr %slot722, align 8
  %cv4625 = zext i32 %v4624 to i64
  %cond4626 = icmp ne i64 %cv4625, 0
  br i1 %cond4626, label %bb_rcgdec966, label %bb_rcgslow966
bb_rcgslow966:
  %v4627 = load i64, ptr %slot709, align 8
  %v4628 = load i64, ptr %slot708, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4627, i64 %v4628) nomerge, !dbg !150
  br label %bb_rcgdone966
bb_rcgdec966:
  %v4629 = load i64, ptr %slot718, align 8
  %v4630 = load i64, ptr %slot710, align 8
  %p4631 = inttoptr i64 %v4630 to ptr
  %rgep4632 = getelementptr i8, ptr %p4631, i64 -32
  store i64 %v4629, ptr %rgep4632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear966
bb_rcgclear966:
  %v4633 = load i64, ptr %slot708, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  store i64 0, ptr %p4634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone966
bb_rcgdone966:
  %v4635 = load i64, ptr %slot704, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i64 0, ptr %p4636, align 8, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot704, align 8
  %p4639 = inttoptr i64 %v4637 to ptr
  %gep4640 = getelementptr i8, ptr %p4639, i64 8
  %op4638 = ptrtoint ptr %gep4640 to i64
  store i64 %op4638, ptr %slot723, align 8
  %v4641 = load i64, ptr %slot723, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  store i64 0, ptr %p4642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone948
bb_rcslotdone948:
  %v4643 = load i64, ptr %slot45, align 8
  store i64 %v4643, ptr %slot724, align 8
  %v4644 = load i64, ptr %slot35, align 8
  store i64 %v4644, ptr %slot725, align 8
  %v4645 = load i64, ptr %slot725, align 8
  %v4646 = load i64, ptr %slot724, align 8
  %p4647 = inttoptr i64 %v4645 to ptr
  %p4648 = inttoptr i64 %v4646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4648, ptr %p4647, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4649 = load i64, ptr %slot27, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  store i32 0, ptr %p4650, align 4, !alias.scope !3, !noalias !4
  %v4651 = load i64, ptr %slot12, align 8
  %p4652 = inttoptr i64 %v4651 to ptr
  store i32 2, ptr %p4652, align 4, !alias.scope !3, !noalias !4
  %v4653 = load i64, ptr %slot28, align 8
  %p4654 = inttoptr i64 %v4653 to ptr
  %ld4655 = load i32, ptr %p4654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4655, ptr %slot726, align 8
  %v4656 = load i32, ptr %slot726, align 8
  %v4657 = load i64, ptr %slot12, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  store i32 %v4656, ptr %p4658, align 4, !alias.scope !3, !noalias !4
  %v4659 = load i64, ptr %slot11, align 8
  %p4660 = inttoptr i64 %v4659 to ptr
  store i32 1, ptr %p4660, align 4, !alias.scope !3, !noalias !4
  %v4661 = load i64, ptr %slot9, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %ld4663 = load i32, ptr %p4662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4663, ptr %slot727, align 8
  %v4664 = load i32, ptr %slot727, align 8
  %cv4665 = zext i32 %v4664 to i64
  %cond4666 = icmp ne i64 %cv4665, 0
  br i1 %cond4666, label %bb_rcslotdrop980, label %bb_rcslotdone980
bb_rcslotdrop980:
  %v4667 = load i64, ptr %slot9, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  store i32 0, ptr %p4668, align 4, !alias.scope !3, !noalias !4
  %v4669 = load i64, ptr %slot44, align 8
  store i64 %v4669, ptr %slot728, align 8
  %v4670 = load i64, ptr %slot10, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  %ld4672 = load i32, ptr %p4671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4672, ptr %slot729, align 8
  %v4673 = load i32, ptr %slot729, align 8
  %op4674 = and i32 %v4673, 28
  store i32 %op4674, ptr %slot730, align 8
  %v4675 = load i32, ptr %slot730, align 8
  %cv4676 = zext i32 %v4675 to i64
  %cond4677 = icmp ne i64 %cv4676, 0
  br i1 %cond4677, label %bb_rcslotrole980, label %bb_rcslotowner980
bb_rcslotrole980:
  %v4678 = load i64, ptr %slot64, align 8
  store i64 %v4678, ptr %slot731, align 8
  %v4679 = load i64, ptr %slot728, align 8
  %p4680 = inttoptr i64 %v4679 to ptr
  %ld4681 = load i64, ptr %p4680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4681, ptr %slot732, align 8
  %v4682 = load i64, ptr %slot732, align 8
  %cmp4683 = icmp ne i64 %v4682, 0
  %cv4684 = zext i1 %cmp4683 to i32
  store i32 %cv4684, ptr %slot733, align 8
  %v4685 = load i32, ptr %slot733, align 8
  %cv4686 = zext i32 %v4685 to i64
  %cond4687 = icmp ne i64 %cv4686, 0
  br i1 %cond4687, label %bb_rcgnn996, label %bb_rcgdone996
bb_rcgnn996:
  %v4688 = load i64, ptr %slot732, align 8
  %op4689 = sub i64 %v4688, 16
  store i64 %op4689, ptr %slot734, align 8
  %v4690 = load i64, ptr %slot732, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  %rgep4692 = getelementptr i8, ptr %p4691, i64 -16
  %ld4693 = load i64, ptr %rgep4692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4693, ptr %slot735, align 8
  %v4694 = load i64, ptr %slot735, align 8
  %op4695 = and i64 %v4694, 4611686018427387906
  store i64 %op4695, ptr %slot736, align 8
  %v4696 = load i64, ptr %slot736, align 8
  %cmp4697 = icmp ne i64 %v4696, 0
  %cv4698 = zext i1 %cmp4697 to i32
  store i32 %cv4698, ptr %slot737, align 8
  %v4699 = load i32, ptr %slot737, align 8
  %cv4700 = zext i32 %v4699 to i64
  %cond4701 = icmp ne i64 %cv4700, 0
  br i1 %cond4701, label %bb_rcgclear996, label %bb_rcgcounted996
bb_rcgcounted996:
  %v4702 = load i64, ptr %slot732, align 8
  %op4703 = sub i64 %v4702, 24
  store i64 %op4703, ptr %slot738, align 8
  %v4704 = load i64, ptr %slot732, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  %rgep4706 = getelementptr i8, ptr %p4705, i64 -24
  %ld4707 = load i64, ptr %rgep4706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4707, ptr %slot739, align 8
  %v4708 = load i64, ptr %slot739, align 8
  %op4709 = sub i64 %v4708, 1
  store i64 %op4709, ptr %slot740, align 8
  %v4710 = load i64, ptr %slot740, align 8
  %cmp4711 = icmp eq i64 %v4710, 0
  %cv4712 = zext i1 %cmp4711 to i32
  store i32 %cv4712, ptr %slot741, align 8
  %v4713 = load i32, ptr %slot741, align 8
  %cv4714 = zext i32 %v4713 to i64
  %cond4715 = icmp ne i64 %cv4714, 0
  br i1 %cond4715, label %bb_rcglast996, label %bb_rcgdec996
bb_rcglast996:
  %v4716 = load i64, ptr %slot732, align 8
  %op4717 = sub i64 %v4716, 32
  store i64 %op4717, ptr %slot742, align 8
  %v4718 = load i64, ptr %slot732, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %rgep4720 = getelementptr i8, ptr %p4719, i64 -32
  %ld4721 = load i64, ptr %rgep4720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4721, ptr %slot743, align 8
  %v4722 = load i64, ptr %slot743, align 8
  %cmp4723 = icmp ne i64 %v4722, 0
  %cv4724 = zext i1 %cmp4723 to i32
  store i32 %cv4724, ptr %slot744, align 8
  %v4725 = load i32, ptr %slot744, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcgdec996, label %bb_rcgslow996
bb_rcgslow996:
  %v4728 = load i64, ptr %slot731, align 8
  %v4729 = load i64, ptr %slot728, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v4728, i64 %v4729) nomerge, !dbg !150
  br label %bb_rcgdone996
bb_rcgdec996:
  %v4730 = load i64, ptr %slot740, align 8
  %v4731 = load i64, ptr %slot732, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  %rgep4733 = getelementptr i8, ptr %p4732, i64 -24
  store i64 %v4730, ptr %rgep4733, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear996
bb_rcgclear996:
  %v4734 = load i64, ptr %slot728, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  store i64 0, ptr %p4735, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone996
bb_rcgdone996:
  br label %bb_rcslotdone980
bb_rcslotowner980:
  %v4736 = load i64, ptr %slot64, align 8
  store i64 %v4736, ptr %slot745, align 8
  %v4737 = load i64, ptr %slot728, align 8
  %p4738 = inttoptr i64 %v4737 to ptr
  %ld4739 = load i64, ptr %p4738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4739, ptr %slot746, align 8
  %v4740 = load i64, ptr %slot746, align 8
  %cmp4741 = icmp ne i64 %v4740, 0
  %cv4742 = zext i1 %cmp4741 to i32
  store i32 %cv4742, ptr %slot747, align 8
  %v4743 = load i32, ptr %slot747, align 8
  %cv4744 = zext i32 %v4743 to i64
  %cond4745 = icmp ne i64 %cv4744, 0
  br i1 %cond4745, label %bb_rcgnn1011, label %bb_rcgdone1011
bb_rcgnn1011:
  %v4746 = load i64, ptr %slot746, align 8
  %op4747 = sub i64 %v4746, 16
  store i64 %op4747, ptr %slot748, align 8
  %v4748 = load i64, ptr %slot746, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  %rgep4750 = getelementptr i8, ptr %p4749, i64 -16
  %ld4751 = load i64, ptr %rgep4750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4751, ptr %slot749, align 8
  %v4752 = load i64, ptr %slot749, align 8
  %op4753 = and i64 %v4752, 4611686018427387906
  store i64 %op4753, ptr %slot750, align 8
  %v4754 = load i64, ptr %slot750, align 8
  %cmp4755 = icmp ne i64 %v4754, 0
  %cv4756 = zext i1 %cmp4755 to i32
  store i32 %cv4756, ptr %slot751, align 8
  %v4757 = load i32, ptr %slot751, align 8
  %cv4758 = zext i32 %v4757 to i64
  %cond4759 = icmp ne i64 %cv4758, 0
  br i1 %cond4759, label %bb_rcgclear1011, label %bb_rcgcounted1011
bb_rcgcounted1011:
  %v4760 = load i64, ptr %slot746, align 8
  %op4761 = sub i64 %v4760, 32
  store i64 %op4761, ptr %slot752, align 8
  %v4762 = load i64, ptr %slot746, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %rgep4764 = getelementptr i8, ptr %p4763, i64 -32
  %ld4765 = load i64, ptr %rgep4764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4765, ptr %slot753, align 8
  %v4766 = load i64, ptr %slot753, align 8
  %op4767 = sub i64 %v4766, 1
  store i64 %op4767, ptr %slot754, align 8
  %v4768 = load i64, ptr %slot754, align 8
  %cmp4769 = icmp eq i64 %v4768, 0
  %cv4770 = zext i1 %cmp4769 to i32
  store i32 %cv4770, ptr %slot755, align 8
  %v4771 = load i32, ptr %slot755, align 8
  %cv4772 = zext i32 %v4771 to i64
  %cond4773 = icmp ne i64 %cv4772, 0
  br i1 %cond4773, label %bb_rcglast1011, label %bb_rcgdec1011
bb_rcglast1011:
  %v4774 = load i64, ptr %slot746, align 8
  %op4775 = sub i64 %v4774, 24
  store i64 %op4775, ptr %slot756, align 8
  %v4776 = load i64, ptr %slot746, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %rgep4778 = getelementptr i8, ptr %p4777, i64 -24
  %ld4779 = load i64, ptr %rgep4778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4779, ptr %slot757, align 8
  %v4780 = load i64, ptr %slot757, align 8
  %cmp4781 = icmp ne i64 %v4780, 0
  %cv4782 = zext i1 %cmp4781 to i32
  store i32 %cv4782, ptr %slot758, align 8
  %v4783 = load i32, ptr %slot758, align 8
  %cv4784 = zext i32 %v4783 to i64
  %cond4785 = icmp ne i64 %cv4784, 0
  br i1 %cond4785, label %bb_rcgdec1011, label %bb_rcgslow1011
bb_rcgslow1011:
  %v4786 = load i64, ptr %slot745, align 8
  %v4787 = load i64, ptr %slot728, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4786, i64 %v4787) nomerge, !dbg !150
  br label %bb_rcgdone1011
bb_rcgdec1011:
  %v4788 = load i64, ptr %slot754, align 8
  %v4789 = load i64, ptr %slot746, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  %rgep4791 = getelementptr i8, ptr %p4790, i64 -32
  store i64 %v4788, ptr %rgep4791, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1011
bb_rcgclear1011:
  %v4792 = load i64, ptr %slot728, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  store i64 0, ptr %p4793, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1011
bb_rcgdone1011:
  br label %bb_rcslotdone980
bb_rcslotdone980:
  %v4794 = load i64, ptr %slot45, align 8
  %v4795 = load i64, ptr %slot53, align 8
  %p4796 = inttoptr i64 %v4795 to ptr
  store i64 %v4794, ptr %p4796, align 8, !alias.scope !3, !noalias !4
  %v4797 = load i64, ptr %slot42, align 8
  %v4798 = load i64, ptr %slot54, align 8
  %p4799 = inttoptr i64 %v4798 to ptr
  store i64 %v4797, ptr %p4799, align 8, !alias.scope !3, !noalias !4
  %v4800 = load i64, ptr %slot53, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %ld4802 = load i64, ptr %p4801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4802, ptr %slot759, align 8
  %v4803 = load i64, ptr %slot54, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %ld4805 = load i64, ptr %p4804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4805, ptr %slot760, align 8
  %v4806 = load i64, ptr %slot1, align 8
  %v4807 = load i64, ptr %slot759, align 8
  %v4808 = load i64, ptr %slot760, align 8
  %call4809 = call i64 @myl_f_f8e1b03fbc79fa9be7d2e95e72decf0bafbd87b704304c17055facf7380d1b01(i64 %v4806, i64 %v4807, i64 %v4808) nomerge, !dbg !152
  store i64 %call4809, ptr %slot761, align 8
  %v4810 = load i64, ptr %slot761, align 8
  %v4811 = load i64, ptr %slot53, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  store i64 %v4810, ptr %p4812, align 8, !alias.scope !3, !noalias !4
  %v4813 = load i64, ptr %slot21, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  %ld4815 = load i32, ptr %p4814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4815, ptr %slot762, align 8
  %v4816 = load i32, ptr %slot762, align 8
  %cv4817 = zext i32 %v4816 to i64
  %cond4818 = icmp ne i64 %cv4817, 0
  br i1 %cond4818, label %bb_rcslotdrop1020, label %bb_rcslotdone1020
bb_rcslotdrop1020:
  %v4819 = load i64, ptr %slot21, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  store i32 0, ptr %p4820, align 4, !alias.scope !3, !noalias !4
  %v4821 = load i64, ptr %slot30, align 8
  store i64 %v4821, ptr %slot763, align 8
  %v4822 = load i64, ptr %slot22, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  %ld4824 = load i32, ptr %p4823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4824, ptr %slot764, align 8
  %v4825 = load i32, ptr %slot764, align 8
  %op4826 = and i32 %v4825, 28
  store i32 %op4826, ptr %slot765, align 8
  %v4827 = load i32, ptr %slot765, align 8
  %cv4828 = zext i32 %v4827 to i64
  %cond4829 = icmp ne i64 %cv4828, 0
  br i1 %cond4829, label %bb_rcslotrole1020, label %bb_rcslotowner1020
bb_rcslotrole1020:
  %v4830 = load i64, ptr %slot64, align 8
  store i64 %v4830, ptr %slot766, align 8
  %v4831 = load i64, ptr %slot766, align 8
  %v4832 = load i64, ptr %slot763, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4831, i64 %v4832) nomerge, !dbg !152
  br label %bb_rcslotdone1020
bb_rcslotowner1020:
  %v4833 = load i64, ptr %slot64, align 8
  store i64 %v4833, ptr %slot767, align 8
  %v4834 = load i64, ptr %slot767, align 8
  %v4835 = load i64, ptr %slot763, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4834, i64 %v4835) nomerge, !dbg !152
  br label %bb_rcslotdone1020
bb_rcslotdone1020:
  %v4836 = load i64, ptr %slot23, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  %ld4838 = load i32, ptr %p4837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4838, ptr %slot768, align 8
  %v4839 = load i32, ptr %slot768, align 8
  %cv4840 = zext i32 %v4839 to i64
  %cond4841 = icmp ne i64 %cv4840, 0
  br i1 %cond4841, label %bb_rcslotdrop1029, label %bb_rcslotdone1029
bb_rcslotdrop1029:
  %v4842 = load i64, ptr %slot23, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  store i32 0, ptr %p4843, align 4, !alias.scope !3, !noalias !4
  %v4844 = load i64, ptr %slot31, align 8
  store i64 %v4844, ptr %slot769, align 8
  %v4845 = load i64, ptr %slot24, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  %ld4847 = load i32, ptr %p4846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4847, ptr %slot770, align 8
  %v4848 = load i32, ptr %slot770, align 8
  %op4849 = and i32 %v4848, 28
  store i32 %op4849, ptr %slot771, align 8
  %v4850 = load i32, ptr %slot771, align 8
  %cv4851 = zext i32 %v4850 to i64
  %cond4852 = icmp ne i64 %cv4851, 0
  br i1 %cond4852, label %bb_rcslotrole1029, label %bb_rcslotowner1029
bb_rcslotrole1029:
  %v4853 = load i64, ptr %slot64, align 8
  store i64 %v4853, ptr %slot772, align 8
  %v4854 = load i64, ptr %slot772, align 8
  %v4855 = load i64, ptr %slot769, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v4854, i64 %v4855) nomerge, !dbg !152
  br label %bb_rcslotdone1029
bb_rcslotowner1029:
  %v4856 = load i64, ptr %slot64, align 8
  store i64 %v4856, ptr %slot773, align 8
  %v4857 = load i64, ptr %slot773, align 8
  %v4858 = load i64, ptr %slot769, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v4857, i64 %v4858) nomerge, !dbg !152
  br label %bb_rcslotdone1029
bb_rcslotdone1029:
  %v4859 = load i64, ptr %slot39, align 8
  %p4860 = inttoptr i64 %v4859 to ptr
  %ld4861 = load i64, ptr %p4860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4861, ptr %slot774, align 8
  %v4862 = load i64, ptr %slot774, align 8
  %v4863 = load i64, ptr %slot53, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  store i64 %v4862, ptr %p4864, align 8, !alias.scope !3, !noalias !4
  %v4865 = load i64, ptr %slot54, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  store i64 0, ptr %p4866, align 8, !alias.scope !3, !noalias !4
  %v4867 = load i64, ptr %slot53, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  %ld4869 = load i64, ptr %p4868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4869, ptr %slot775, align 8
  %v4870 = load i64, ptr %slot54, align 8
  %p4871 = inttoptr i64 %v4870 to ptr
  %ld4872 = load i64, ptr %p4871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4872, ptr %slot776, align 8
  %v4873 = load i64, ptr %slot1, align 8
  %v4874 = load i64, ptr %slot775, align 8
  %v4875 = load i64, ptr %slot776, align 8
  %call4876 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v4873, i64 %v4874, i64 %v4875) nomerge, !dbg !154
  store { i64, i64 } %call4876, ptr %callresult778, align 8
  %addr4877 = ptrtoint ptr %callresult778 to i64
  store i64 %addr4877, ptr %slot777, align 8
  %v4878 = load i64, ptr %slot777, align 8
  %v4879 = load i64, ptr %slot53, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  store i64 %v4878, ptr %p4880, align 8, !alias.scope !3, !noalias !4
  %v4881 = load i64, ptr %slot21, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  %ld4883 = load i32, ptr %p4882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4883, ptr %slot779, align 8
  %v4884 = load i32, ptr %slot779, align 8
  %cv4885 = zext i32 %v4884 to i64
  %cond4886 = icmp ne i64 %cv4885, 0
  br i1 %cond4886, label %bb_rcslotdrop1042, label %bb_rcslotdone1042
bb_rcslotdrop1042:
  %v4887 = load i64, ptr %slot21, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  store i32 0, ptr %p4888, align 4, !alias.scope !3, !noalias !4
  %v4889 = load i64, ptr %slot30, align 8
  store i64 %v4889, ptr %slot780, align 8
  %v4890 = load i64, ptr %slot22, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  %ld4892 = load i32, ptr %p4891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4892, ptr %slot781, align 8
  %v4893 = load i32, ptr %slot781, align 8
  %op4894 = and i32 %v4893, 28
  store i32 %op4894, ptr %slot782, align 8
  %v4895 = load i32, ptr %slot782, align 8
  %cv4896 = zext i32 %v4895 to i64
  %cond4897 = icmp ne i64 %cv4896, 0
  br i1 %cond4897, label %bb_rcslotrole1042, label %bb_rcslotowner1042
bb_rcslotrole1042:
  %v4898 = load i64, ptr %slot64, align 8
  store i64 %v4898, ptr %slot783, align 8
  %v4899 = load i64, ptr %slot783, align 8
  %v4900 = load i64, ptr %slot780, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4899, i64 %v4900) nomerge, !dbg !154
  br label %bb_rcslotdone1042
bb_rcslotowner1042:
  %v4901 = load i64, ptr %slot64, align 8
  store i64 %v4901, ptr %slot784, align 8
  %v4902 = load i64, ptr %slot784, align 8
  %v4903 = load i64, ptr %slot780, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4902, i64 %v4903) nomerge, !dbg !154
  br label %bb_rcslotdone1042
bb_rcslotdone1042:
  %v4904 = load i64, ptr %slot53, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  %ld4906 = load i64, ptr %p4905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4906, ptr %slot785, align 8
  %v4907 = load i64, ptr %slot1, align 8
  %v4908 = load i64, ptr %slot785, align 8
  %call4909 = call i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %v4907, i64 %v4908) nomerge, !dbg !156
  store i64 %call4909, ptr %slot786, align 8
  %v4910 = load i64, ptr %slot786, align 8
  %v4911 = load i64, ptr %slot53, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  store i64 %v4910, ptr %p4912, align 8, !alias.scope !3, !noalias !4
  %v4913 = load i64, ptr %slot53, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  %ld4915 = load i64, ptr %p4914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4915, ptr %slot787, align 8
  %v4916 = load i64, ptr %slot787, align 8
  %v4917 = load i64, ptr %slot46, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  store i64 %v4916, ptr %p4918, align 8, !alias.scope !3, !noalias !4
  %v4919 = load i64, ptr %slot39, align 8
  %p4920 = inttoptr i64 %v4919 to ptr
  %ld4921 = load i64, ptr %p4920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4921, ptr %slot788, align 8
  %v4922 = load i64, ptr %slot788, align 8
  %v4923 = load i64, ptr %slot53, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  store i64 %v4922, ptr %p4924, align 8, !alias.scope !3, !noalias !4
  %v4925 = load i64, ptr %slot46, align 8
  %p4926 = inttoptr i64 %v4925 to ptr
  %ld4927 = load i64, ptr %p4926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4927, ptr %slot789, align 8
  %v4928 = load i64, ptr %slot789, align 8
  %v4929 = load i64, ptr %slot54, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  store i64 %v4928, ptr %p4930, align 8, !alias.scope !3, !noalias !4
  %v4931 = load i64, ptr %slot53, align 8
  %p4932 = inttoptr i64 %v4931 to ptr
  %ld4933 = load i64, ptr %p4932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4933, ptr %slot790, align 8
  %v4934 = load i64, ptr %slot54, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %ld4936 = load i64, ptr %p4935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4936, ptr %slot791, align 8
  %v4937 = load i64, ptr %slot1, align 8
  %v4938 = load i64, ptr %slot790, align 8
  %v4939 = load i64, ptr %slot791, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult793, i64 %v4937, i64 %v4938, i64 %v4939) nomerge, !dbg !158
  %addr4940 = ptrtoint ptr %callresult793 to i64
  store i64 %addr4940, ptr %slot792, align 8
  %v4941 = load i64, ptr %slot792, align 8
  %v4942 = load i64, ptr %slot53, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  store i64 %v4941, ptr %p4943, align 8, !alias.scope !3, !noalias !4
  %v4944 = load i64, ptr %slot53, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  %ld4946 = load i64, ptr %p4945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4946, ptr %slot794, align 8
  %v4947 = load i64, ptr %slot35, align 8
  store i64 %v4947, ptr %slot795, align 8
  %v4948 = load i64, ptr %slot794, align 8
  %v4949 = load i64, ptr %slot795, align 8
  %p4950 = inttoptr i64 %v4948 to ptr
  %p4951 = inttoptr i64 %v4949 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4951, ptr %p4950, i64 24, i1 false)
  %v4952 = load i64, ptr %slot28, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  store i32 2, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  %v4954 = load i64, ptr %slot27, align 8
  %p4955 = inttoptr i64 %v4954 to ptr
  store i32 1, ptr %p4955, align 4, !alias.scope !3, !noalias !4
  %v4956 = load i64, ptr %slot21, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %ld4958 = load i32, ptr %p4957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4958, ptr %slot796, align 8
  %v4959 = load i32, ptr %slot796, align 8
  %cv4960 = zext i32 %v4959 to i64
  %cond4961 = icmp ne i64 %cv4960, 0
  br i1 %cond4961, label %bb_rcslotdrop1063, label %bb_rcslotdone1063
bb_rcslotdrop1063:
  %v4962 = load i64, ptr %slot21, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  store i32 0, ptr %p4963, align 4, !alias.scope !3, !noalias !4
  %v4964 = load i64, ptr %slot30, align 8
  store i64 %v4964, ptr %slot797, align 8
  %v4965 = load i64, ptr %slot22, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  %ld4967 = load i32, ptr %p4966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4967, ptr %slot798, align 8
  %v4968 = load i32, ptr %slot798, align 8
  %op4969 = and i32 %v4968, 28
  store i32 %op4969, ptr %slot799, align 8
  %v4970 = load i32, ptr %slot799, align 8
  %cv4971 = zext i32 %v4970 to i64
  %cond4972 = icmp ne i64 %cv4971, 0
  br i1 %cond4972, label %bb_rcslotrole1063, label %bb_rcslotowner1063
bb_rcslotrole1063:
  %v4973 = load i64, ptr %slot64, align 8
  store i64 %v4973, ptr %slot800, align 8
  %v4974 = load i64, ptr %slot800, align 8
  %v4975 = load i64, ptr %slot797, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4974, i64 %v4975) nomerge, !dbg !158
  br label %bb_rcslotdone1063
bb_rcslotowner1063:
  %v4976 = load i64, ptr %slot64, align 8
  store i64 %v4976, ptr %slot801, align 8
  %v4977 = load i64, ptr %slot801, align 8
  %v4978 = load i64, ptr %slot797, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4977, i64 %v4978) nomerge, !dbg !158
  br label %bb_rcslotdone1063
bb_rcslotdone1063:
  %v4979 = load i64, ptr %slot30, align 8
  store i64 %v4979, ptr %slot802, align 8
  %v4980 = load i64, ptr %slot35, align 8
  store i64 %v4980, ptr %slot803, align 8
  %v4981 = load i64, ptr %slot803, align 8
  %v4982 = load i64, ptr %slot802, align 8
  %p4983 = inttoptr i64 %v4981 to ptr
  %p4984 = inttoptr i64 %v4982 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4984, ptr %p4983, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4985 = load i64, ptr %slot22, align 8
  %p4986 = inttoptr i64 %v4985 to ptr
  store i32 2, ptr %p4986, align 4, !alias.scope !3, !noalias !4
  %v4987 = load i64, ptr %slot28, align 8
  %p4988 = inttoptr i64 %v4987 to ptr
  %ld4989 = load i32, ptr %p4988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4989, ptr %slot804, align 8
  %v4990 = load i32, ptr %slot804, align 8
  %v4991 = load i64, ptr %slot22, align 8
  %p4992 = inttoptr i64 %v4991 to ptr
  store i32 %v4990, ptr %p4992, align 4, !alias.scope !3, !noalias !4
  %v4993 = load i64, ptr %slot27, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  store i32 0, ptr %p4994, align 4, !alias.scope !3, !noalias !4
  %v4995 = load i64, ptr %slot21, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  store i32 1, ptr %p4996, align 4, !alias.scope !3, !noalias !4
  %v4997 = load i64, ptr %slot802, align 8
  %v4998 = load i64, ptr %slot53, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  store i64 %v4997, ptr %p4999, align 8, !alias.scope !3, !noalias !4
  %v5000 = load i64, ptr %slot53, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  %ld5002 = load i64, ptr %p5001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5002, ptr %slot805, align 8
  %v5003 = load i64, ptr %slot35, align 8
  store i64 %v5003, ptr %slot806, align 8
  %v5004 = load i64, ptr %slot65, align 8
  store i64 %v5004, ptr %slot807, align 8
  %v5005 = load i64, ptr %slot805, align 8
  %op5006 = add i64 %v5005, 8
  store i64 %op5006, ptr %slot808, align 8
  %v5007 = load i64, ptr %slot808, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  %ld5009 = load i64, ptr %p5008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5009, ptr %slot809, align 8
  %v5010 = load i64, ptr %slot809, align 8
  %cmp5011 = icmp ne i64 %v5010, 0
  %cv5012 = zext i1 %cmp5011 to i32
  store i32 %cv5012, ptr %slot810, align 8
  %v5013 = load i32, ptr %slot810, align 8
  %cv5014 = zext i32 %v5013 to i64
  %cond5015 = icmp ne i64 %cv5014, 0
  br i1 %cond5015, label %bb_rcmoveheader1084, label %bb_rcmovenext1084
bb_rcmoveheader1084:
  %v5016 = load i64, ptr %slot809, align 8
  %op5017 = sub i64 %v5016, 16
  store i64 %op5017, ptr %slot811, align 8
  %v5018 = load i64, ptr %slot809, align 8
  %p5019 = inttoptr i64 %v5018 to ptr
  %rgep5020 = getelementptr i8, ptr %p5019, i64 -16
  %ld5021 = load i64, ptr %rgep5020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5021, ptr %slot812, align 8
  %v5022 = load i64, ptr %slot812, align 8
  %op5023 = and i64 %v5022, 5764607523034234881
  store i64 %op5023, ptr %slot813, align 8
  %v5024 = load i64, ptr %slot813, align 8
  %cmp5025 = icmp ne i64 %v5024, 0
  %cv5026 = zext i1 %cmp5025 to i32
  store i32 %cv5026, ptr %slot814, align 8
  %v5027 = load i32, ptr %slot814, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcmoveslow1081, label %bb_rcmovenext1084
bb_rcmovenext1084:
  %v5030 = load i64, ptr %slot805, align 8
  %v5031 = load i64, ptr %slot806, align 8
  %p5032 = inttoptr i64 %v5030 to ptr
  %p5033 = inttoptr i64 %v5031 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5033, ptr %p5032, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5034 = load i64, ptr %slot805, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  store i64 0, ptr %p5035, align 8, !alias.scope !3, !noalias !4
  %v5036 = load i64, ptr %slot805, align 8
  %op5037 = add i64 %v5036, 8
  store i64 %op5037, ptr %slot815, align 8
  %v5038 = load i64, ptr %slot815, align 8
  %p5039 = inttoptr i64 %v5038 to ptr
  store i64 0, ptr %p5039, align 8, !alias.scope !3, !noalias !4
  %v5040 = load i64, ptr %slot805, align 8
  %op5041 = add i64 %v5040, 16
  store i64 %op5041, ptr %slot816, align 8
  %v5042 = load i64, ptr %slot816, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  store i64 0, ptr %p5043, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1081
bb_rcmoveslow1081:
  %v5044 = load i64, ptr %slot64, align 8
  %v5045 = load i64, ptr %slot806, align 8
  %v5046 = load i64, ptr %slot805, align 8
  %v5047 = load i64, ptr %slot807, align 8
  %cv5048 = trunc i64 %v5047 to i32
  %call5049 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v5044, i64 %v5045, i64 %v5046, i32 %cv5048) nomerge, !dbg !160
  store i32 %call5049, ptr %slot817, align 8
  %v5050 = load i32, ptr %slot817, align 8
  %cv5051 = zext i32 %v5050 to i64
  %cond5052 = icmp ne i64 %cv5051, 0
  br i1 %cond5052, label %bb_rcsuccess1093, label %bb_rcfailure1093
bb_rcfailure1093:
  %v5053 = load i64, ptr %slot64, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %call5055 = call i32 @myl_rc_take_failure(ptr %p5054) nomerge, !dbg !160
  store i32 %call5055, ptr %slot818, align 8
  %v5056 = load i64, ptr %slot1, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %v5058 = load i32, ptr %slot818, align 8
  %call5059 = call i32 @myl_qbe_rc_status(ptr %p5057, i32 %v5058) nomerge, !dbg !160
  store i32 %call5059, ptr %slot819, align 8
  br label %bb_failure
bb_rcsuccess1093:
  br label %bb_rcmoved1081
bb_rcmoved1081:
  %v5060 = load i64, ptr %slot21, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  store i32 0, ptr %p5061, align 4, !alias.scope !3, !noalias !4
  %v5062 = load i64, ptr %slot28, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  store i32 2, ptr %p5063, align 4, !alias.scope !3, !noalias !4
  %v5064 = load i64, ptr %slot27, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  store i32 1, ptr %p5065, align 4, !alias.scope !3, !noalias !4
  %v5066 = load i64, ptr %slot13, align 8
  %p5067 = inttoptr i64 %v5066 to ptr
  %ld5068 = load i32, ptr %p5067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5068, ptr %slot820, align 8
  %v5069 = load i32, ptr %slot820, align 8
  %cv5070 = zext i32 %v5069 to i64
  %cond5071 = icmp ne i64 %cv5070, 0
  br i1 %cond5071, label %bb_rcslotdrop1102, label %bb_rcslotdone1102
bb_rcslotdrop1102:
  %v5072 = load i64, ptr %slot13, align 8
  %p5073 = inttoptr i64 %v5072 to ptr
  store i32 0, ptr %p5073, align 4, !alias.scope !3, !noalias !4
  %v5074 = load i64, ptr %slot47, align 8
  store i64 %v5074, ptr %slot821, align 8
  %v5075 = load i64, ptr %slot14, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  %ld5077 = load i32, ptr %p5076, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5077, ptr %slot822, align 8
  %v5078 = load i32, ptr %slot822, align 8
  %op5079 = and i32 %v5078, 28
  store i32 %op5079, ptr %slot823, align 8
  %v5080 = load i32, ptr %slot823, align 8
  %cv5081 = zext i32 %v5080 to i64
  %cond5082 = icmp ne i64 %cv5081, 0
  br i1 %cond5082, label %bb_rcslotrole1102, label %bb_rcslotowner1102
bb_rcslotrole1102:
  %v5083 = load i64, ptr %slot64, align 8
  store i64 %v5083, ptr %slot824, align 8
  %v5084 = load i64, ptr %slot824, align 8
  %v5085 = load i64, ptr %slot821, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v5084, i64 %v5085) nomerge, !dbg !160
  br label %bb_rcslotdone1102
bb_rcslotowner1102:
  %v5086 = load i64, ptr %slot821, align 8
  %p5088 = inttoptr i64 %v5086 to ptr
  %gep5089 = getelementptr i8, ptr %p5088, i64 8
  %op5087 = ptrtoint ptr %gep5089 to i64
  store i64 %op5087, ptr %slot825, align 8
  %v5090 = load i64, ptr %slot64, align 8
  store i64 %v5090, ptr %slot826, align 8
  %v5091 = load i64, ptr %slot825, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  %ld5093 = load i64, ptr %p5092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5093, ptr %slot827, align 8
  %v5094 = load i64, ptr %slot827, align 8
  %cmp5095 = icmp ne i64 %v5094, 0
  %cv5096 = zext i1 %cmp5095 to i32
  store i32 %cv5096, ptr %slot828, align 8
  %v5097 = load i32, ptr %slot828, align 8
  %cv5098 = zext i32 %v5097 to i64
  %cond5099 = icmp ne i64 %cv5098, 0
  br i1 %cond5099, label %bb_rcgnn1120, label %bb_rcgdone1120
bb_rcgnn1120:
  %v5100 = load i64, ptr %slot827, align 8
  %op5101 = sub i64 %v5100, 16
  store i64 %op5101, ptr %slot829, align 8
  %v5102 = load i64, ptr %slot827, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  %rgep5104 = getelementptr i8, ptr %p5103, i64 -16
  %ld5105 = load i64, ptr %rgep5104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5105, ptr %slot830, align 8
  %v5106 = load i64, ptr %slot830, align 8
  %op5107 = and i64 %v5106, 4611686018427387906
  store i64 %op5107, ptr %slot831, align 8
  %v5108 = load i64, ptr %slot831, align 8
  %cmp5109 = icmp ne i64 %v5108, 0
  %cv5110 = zext i1 %cmp5109 to i32
  store i32 %cv5110, ptr %slot832, align 8
  %v5111 = load i32, ptr %slot832, align 8
  %cv5112 = zext i32 %v5111 to i64
  %cond5113 = icmp ne i64 %cv5112, 0
  br i1 %cond5113, label %bb_rcgclear1120, label %bb_rcgcounted1120
bb_rcgcounted1120:
  %v5114 = load i64, ptr %slot827, align 8
  %op5115 = sub i64 %v5114, 32
  store i64 %op5115, ptr %slot833, align 8
  %v5116 = load i64, ptr %slot827, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  %rgep5118 = getelementptr i8, ptr %p5117, i64 -32
  %ld5119 = load i64, ptr %rgep5118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5119, ptr %slot834, align 8
  %v5120 = load i64, ptr %slot834, align 8
  %op5121 = sub i64 %v5120, 1
  store i64 %op5121, ptr %slot835, align 8
  %v5122 = load i64, ptr %slot835, align 8
  %cmp5123 = icmp eq i64 %v5122, 0
  %cv5124 = zext i1 %cmp5123 to i32
  store i32 %cv5124, ptr %slot836, align 8
  %v5125 = load i32, ptr %slot836, align 8
  %cv5126 = zext i32 %v5125 to i64
  %cond5127 = icmp ne i64 %cv5126, 0
  br i1 %cond5127, label %bb_rcglast1120, label %bb_rcgdec1120
bb_rcglast1120:
  %v5128 = load i64, ptr %slot827, align 8
  %op5129 = sub i64 %v5128, 24
  store i64 %op5129, ptr %slot837, align 8
  %v5130 = load i64, ptr %slot827, align 8
  %p5131 = inttoptr i64 %v5130 to ptr
  %rgep5132 = getelementptr i8, ptr %p5131, i64 -24
  %ld5133 = load i64, ptr %rgep5132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5133, ptr %slot838, align 8
  %v5134 = load i64, ptr %slot838, align 8
  %cmp5135 = icmp ne i64 %v5134, 0
  %cv5136 = zext i1 %cmp5135 to i32
  store i32 %cv5136, ptr %slot839, align 8
  %v5137 = load i32, ptr %slot839, align 8
  %cv5138 = zext i32 %v5137 to i64
  %cond5139 = icmp ne i64 %cv5138, 0
  br i1 %cond5139, label %bb_rcgdec1120, label %bb_rcgslow1120
bb_rcgslow1120:
  %v5140 = load i64, ptr %slot826, align 8
  %v5141 = load i64, ptr %slot825, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5140, i64 %v5141) nomerge, !dbg !160
  br label %bb_rcgdone1120
bb_rcgdec1120:
  %v5142 = load i64, ptr %slot835, align 8
  %v5143 = load i64, ptr %slot827, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  %rgep5145 = getelementptr i8, ptr %p5144, i64 -32
  store i64 %v5142, ptr %rgep5145, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1120
bb_rcgclear1120:
  %v5146 = load i64, ptr %slot825, align 8
  %p5147 = inttoptr i64 %v5146 to ptr
  store i64 0, ptr %p5147, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1120
bb_rcgdone1120:
  %v5148 = load i64, ptr %slot821, align 8
  %p5149 = inttoptr i64 %v5148 to ptr
  store i64 0, ptr %p5149, align 8, !alias.scope !3, !noalias !4
  %v5150 = load i64, ptr %slot821, align 8
  %p5152 = inttoptr i64 %v5150 to ptr
  %gep5153 = getelementptr i8, ptr %p5152, i64 8
  %op5151 = ptrtoint ptr %gep5153 to i64
  store i64 %op5151, ptr %slot840, align 8
  %v5154 = load i64, ptr %slot840, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  store i64 0, ptr %p5155, align 8, !alias.scope !3, !noalias !4
  %v5156 = load i64, ptr %slot821, align 8
  %p5158 = inttoptr i64 %v5156 to ptr
  %gep5159 = getelementptr i8, ptr %p5158, i64 16
  %op5157 = ptrtoint ptr %gep5159 to i64
  store i64 %op5157, ptr %slot841, align 8
  %v5160 = load i64, ptr %slot841, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  store i64 0, ptr %p5161, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1102
bb_rcslotdone1102:
  %v5162 = load i64, ptr %slot47, align 8
  store i64 %v5162, ptr %slot842, align 8
  %v5163 = load i64, ptr %slot35, align 8
  store i64 %v5163, ptr %slot843, align 8
  %v5164 = load i64, ptr %slot843, align 8
  %v5165 = load i64, ptr %slot842, align 8
  %p5166 = inttoptr i64 %v5164 to ptr
  %p5167 = inttoptr i64 %v5165 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5167, ptr %p5166, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5168 = load i64, ptr %slot27, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  store i32 0, ptr %p5169, align 4, !alias.scope !3, !noalias !4
  %v5170 = load i64, ptr %slot14, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  store i32 2, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  %v5172 = load i64, ptr %slot28, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  %ld5174 = load i32, ptr %p5173, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5174, ptr %slot844, align 8
  %v5175 = load i32, ptr %slot844, align 8
  %v5176 = load i64, ptr %slot14, align 8
  %p5177 = inttoptr i64 %v5176 to ptr
  store i32 %v5175, ptr %p5177, align 4, !alias.scope !3, !noalias !4
  %v5178 = load i64, ptr %slot13, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  store i32 1, ptr %p5179, align 4, !alias.scope !3, !noalias !4
  %v5180 = load i64, ptr %slot42, align 8
  %v5181 = load i64, ptr %slot53, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  store i64 %v5180, ptr %p5182, align 8, !alias.scope !3, !noalias !4
  %v5183 = load i64, ptr %slot53, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  %ld5185 = load i64, ptr %p5184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5185, ptr %slot845, align 8
  %v5186 = load i64, ptr %slot21, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i32, ptr %p5187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5188, ptr %slot846, align 8
  %v5189 = load i64, ptr %slot22, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  %ld5191 = load i32, ptr %p5190, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5191, ptr %slot847, align 8
  %v5192 = load i32, ptr %slot847, align 8
  %op5193 = and i32 %v5192, 24
  store i32 %op5193, ptr %slot847, align 8
  %v5194 = load i32, ptr %slot847, align 8
  %cmp5195 = icmp eq i32 %v5194, 0
  %cv5196 = zext i1 %cmp5195 to i32
  store i32 %cv5196, ptr %slot848, align 8
  %v5197 = load i32, ptr %slot846, align 8
  %v5198 = load i32, ptr %slot848, align 8
  %op5199 = and i32 %v5197, %v5198
  store i32 %op5199, ptr %slot849, align 8
  %v5200 = load i32, ptr %slot849, align 8
  %cv5201 = zext i32 %v5200 to i64
  %cond5202 = icmp ne i64 %cv5201, 0
  br i1 %cond5202, label %bb_rcprivateown1140, label %bb_rcprivateloan1140
bb_rcprivateown1140:
  %v5203 = load i64, ptr %slot35, align 8
  store i64 %v5203, ptr %slot850, align 8
  %v5204 = load i64, ptr %slot65, align 8
  store i64 %v5204, ptr %slot851, align 8
  %v5205 = load i64, ptr %slot845, align 8
  %v5206 = load i64, ptr %slot850, align 8
  %op5207 = sub i64 %v5205, %v5206
  store i64 %op5207, ptr %slot852, align 8
  %v5208 = load i64, ptr %slot850, align 8
  %v5209 = load i64, ptr %slot845, align 8
  %op5210 = sub i64 %v5208, %v5209
  store i64 %op5210, ptr %slot853, align 8
  %v5211 = load i64, ptr %slot852, align 8
  %cmp5212 = icmp ult i64 %v5211, 16
  %cv5213 = zext i1 %cmp5212 to i32
  store i32 %cv5213, ptr %slot854, align 8
  %v5214 = load i64, ptr %slot853, align 8
  %cmp5215 = icmp ult i64 %v5214, 16
  %cv5216 = zext i1 %cmp5215 to i32
  store i32 %cv5216, ptr %slot855, align 8
  %v5217 = load i32, ptr %slot854, align 8
  %v5218 = load i32, ptr %slot855, align 8
  %op5219 = or i32 %v5217, %v5218
  store i32 %op5219, ptr %slot856, align 8
  %v5220 = load i32, ptr %slot856, align 8
  %cv5221 = zext i32 %v5220 to i64
  %cond5222 = icmp ne i64 %cv5221, 0
  br i1 %cond5222, label %bb_rcmoveslow1143, label %bb_rcmovecheck1143
bb_rcmovecheck1143:
  %v5223 = load i64, ptr %slot845, align 8
  %op5224 = add i64 %v5223, 0
  store i64 %op5224, ptr %slot857, align 8
  %v5225 = load i64, ptr %slot857, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  %ld5227 = load i64, ptr %p5226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5227, ptr %slot858, align 8
  %v5228 = load i64, ptr %slot858, align 8
  %cmp5229 = icmp ne i64 %v5228, 0
  %cv5230 = zext i1 %cmp5229 to i32
  store i32 %cv5230, ptr %slot859, align 8
  %v5231 = load i32, ptr %slot859, align 8
  %cv5232 = zext i32 %v5231 to i64
  %cond5233 = icmp ne i64 %cv5232, 0
  br i1 %cond5233, label %bb_rcmoveheader1151, label %bb_rcmovenext1151
bb_rcmoveheader1151:
  %v5234 = load i64, ptr %slot858, align 8
  %op5235 = sub i64 %v5234, 16
  store i64 %op5235, ptr %slot860, align 8
  %v5236 = load i64, ptr %slot858, align 8
  %p5237 = inttoptr i64 %v5236 to ptr
  %rgep5238 = getelementptr i8, ptr %p5237, i64 -16
  %ld5239 = load i64, ptr %rgep5238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5239, ptr %slot861, align 8
  %v5240 = load i64, ptr %slot861, align 8
  %op5241 = and i64 %v5240, 5764607523034234881
  store i64 %op5241, ptr %slot862, align 8
  %v5242 = load i64, ptr %slot862, align 8
  %cmp5243 = icmp ne i64 %v5242, 0
  %cv5244 = zext i1 %cmp5243 to i32
  store i32 %cv5244, ptr %slot863, align 8
  %v5245 = load i32, ptr %slot863, align 8
  %cv5246 = zext i32 %v5245 to i64
  %cond5247 = icmp ne i64 %cv5246, 0
  br i1 %cond5247, label %bb_rcmoveslow1143, label %bb_rcmovenext1151
bb_rcmovenext1151:
  %v5248 = load i64, ptr %slot845, align 8
  %v5249 = load i64, ptr %slot850, align 8
  %p5250 = inttoptr i64 %v5248 to ptr
  %p5251 = inttoptr i64 %v5249 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5251, ptr %p5250, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5252 = load i64, ptr %slot845, align 8
  %p5253 = inttoptr i64 %v5252 to ptr
  store i64 0, ptr %p5253, align 8, !alias.scope !3, !noalias !4
  %v5254 = load i64, ptr %slot845, align 8
  %op5255 = add i64 %v5254, 8
  store i64 %op5255, ptr %slot864, align 8
  %v5256 = load i64, ptr %slot864, align 8
  %p5257 = inttoptr i64 %v5256 to ptr
  store i64 0, ptr %p5257, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1143
bb_rcmoveslow1143:
  %v5258 = load i64, ptr %slot64, align 8
  %v5259 = load i64, ptr %slot850, align 8
  %v5260 = load i64, ptr %slot845, align 8
  %v5261 = load i64, ptr %slot851, align 8
  %cv5262 = trunc i64 %v5261 to i32
  %call5263 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v5258, i64 %v5259, i64 %v5260, i32 %cv5262) nomerge, !dbg !162
  store i32 %call5263, ptr %slot865, align 8
  %v5264 = load i32, ptr %slot865, align 8
  %cv5265 = zext i32 %v5264 to i64
  %cond5266 = icmp ne i64 %cv5265, 0
  br i1 %cond5266, label %bb_rcsuccess1159, label %bb_rcfailure1159
bb_rcfailure1159:
  %v5267 = load i64, ptr %slot64, align 8
  %p5268 = inttoptr i64 %v5267 to ptr
  %call5269 = call i32 @myl_rc_take_failure(ptr %p5268) nomerge, !dbg !162
  store i32 %call5269, ptr %slot866, align 8
  %v5270 = load i64, ptr %slot1, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  %v5272 = load i32, ptr %slot866, align 8
  %call5273 = call i32 @myl_qbe_rc_status(ptr %p5271, i32 %v5272) nomerge, !dbg !162
  store i32 %call5273, ptr %slot867, align 8
  br label %bb_failure
bb_rcsuccess1159:
  br label %bb_rcmoved1143
bb_rcmoved1143:
  %v5274 = load i64, ptr %slot21, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  store i32 0, ptr %p5275, align 4, !alias.scope !3, !noalias !4
  %v5276 = load i64, ptr %slot28, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  store i32 2, ptr %p5277, align 4, !alias.scope !3, !noalias !4
  %v5278 = load i64, ptr %slot27, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  store i32 1, ptr %p5279, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1140
bb_rcprivateloan1140:
  %v5280 = load i64, ptr %slot35, align 8
  store i64 %v5280, ptr %slot868, align 8
  %v5281 = load i64, ptr %slot64, align 8
  %v5282 = load i64, ptr %slot868, align 8
  %v5283 = load i64, ptr %slot845, align 8
  %call5284 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v5281, i64 %v5282, i64 %v5283) nomerge, !dbg !162
  store i32 %call5284, ptr %slot869, align 8
  %v5285 = load i32, ptr %slot869, align 8
  %cv5286 = zext i32 %v5285 to i64
  %cond5287 = icmp ne i64 %cv5286, 0
  br i1 %cond5287, label %bb_rcsuccess1167, label %bb_rcfailure1167
bb_rcfailure1167:
  %v5288 = load i64, ptr %slot64, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  %call5290 = call i32 @myl_rc_take_failure(ptr %p5289) nomerge, !dbg !162
  store i32 %call5290, ptr %slot870, align 8
  %v5291 = load i64, ptr %slot1, align 8
  %p5292 = inttoptr i64 %v5291 to ptr
  %v5293 = load i32, ptr %slot870, align 8
  %call5294 = call i32 @myl_qbe_rc_status(ptr %p5292, i32 %v5293) nomerge, !dbg !162
  store i32 %call5294, ptr %slot871, align 8
  br label %bb_failure
bb_rcsuccess1167:
  %v5295 = load i64, ptr %slot28, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  store i32 2, ptr %p5296, align 4, !alias.scope !3, !noalias !4
  %v5297 = load i64, ptr %slot28, align 8
  %p5298 = inttoptr i64 %v5297 to ptr
  store i32 16, ptr %p5298, align 4, !alias.scope !3, !noalias !4
  %v5299 = load i64, ptr %slot27, align 8
  %p5300 = inttoptr i64 %v5299 to ptr
  store i32 1, ptr %p5300, align 4, !alias.scope !3, !noalias !4
  %v5301 = load i64, ptr %slot21, align 8
  %p5302 = inttoptr i64 %v5301 to ptr
  %ld5303 = load i32, ptr %p5302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5303, ptr %slot872, align 8
  %v5304 = load i32, ptr %slot872, align 8
  %cv5305 = zext i32 %v5304 to i64
  %cond5306 = icmp ne i64 %cv5305, 0
  br i1 %cond5306, label %bb_rcslotdrop1175, label %bb_rcslotdone1175
bb_rcslotdrop1175:
  %v5307 = load i64, ptr %slot21, align 8
  %p5308 = inttoptr i64 %v5307 to ptr
  store i32 0, ptr %p5308, align 4, !alias.scope !3, !noalias !4
  %v5309 = load i64, ptr %slot30, align 8
  store i64 %v5309, ptr %slot873, align 8
  %v5310 = load i64, ptr %slot22, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %ld5312 = load i32, ptr %p5311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5312, ptr %slot874, align 8
  %v5313 = load i32, ptr %slot874, align 8
  %op5314 = and i32 %v5313, 28
  store i32 %op5314, ptr %slot875, align 8
  %v5315 = load i32, ptr %slot875, align 8
  %cv5316 = zext i32 %v5315 to i64
  %cond5317 = icmp ne i64 %cv5316, 0
  br i1 %cond5317, label %bb_rcslotrole1175, label %bb_rcslotowner1175
bb_rcslotrole1175:
  %v5318 = load i64, ptr %slot64, align 8
  store i64 %v5318, ptr %slot876, align 8
  %v5319 = load i64, ptr %slot876, align 8
  %v5320 = load i64, ptr %slot873, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5319, i64 %v5320) nomerge, !dbg !162
  br label %bb_rcslotdone1175
bb_rcslotowner1175:
  %v5321 = load i64, ptr %slot873, align 8
  %p5323 = inttoptr i64 %v5321 to ptr
  %gep5324 = getelementptr i8, ptr %p5323, i64 0
  %op5322 = ptrtoint ptr %gep5324 to i64
  store i64 %op5322, ptr %slot877, align 8
  %v5325 = load i64, ptr %slot64, align 8
  store i64 %v5325, ptr %slot878, align 8
  %v5326 = load i64, ptr %slot877, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  %ld5328 = load i64, ptr %p5327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5328, ptr %slot879, align 8
  %v5329 = load i64, ptr %slot879, align 8
  %cmp5330 = icmp ne i64 %v5329, 0
  %cv5331 = zext i1 %cmp5330 to i32
  store i32 %cv5331, ptr %slot880, align 8
  %v5332 = load i32, ptr %slot880, align 8
  %cv5333 = zext i32 %v5332 to i64
  %cond5334 = icmp ne i64 %cv5333, 0
  br i1 %cond5334, label %bb_rcgnn1193, label %bb_rcgdone1193
bb_rcgnn1193:
  %v5335 = load i64, ptr %slot879, align 8
  %op5336 = sub i64 %v5335, 16
  store i64 %op5336, ptr %slot881, align 8
  %v5337 = load i64, ptr %slot879, align 8
  %p5338 = inttoptr i64 %v5337 to ptr
  %rgep5339 = getelementptr i8, ptr %p5338, i64 -16
  %ld5340 = load i64, ptr %rgep5339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5340, ptr %slot882, align 8
  %v5341 = load i64, ptr %slot882, align 8
  %op5342 = and i64 %v5341, 4611686018427387906
  store i64 %op5342, ptr %slot883, align 8
  %v5343 = load i64, ptr %slot883, align 8
  %cmp5344 = icmp ne i64 %v5343, 0
  %cv5345 = zext i1 %cmp5344 to i32
  store i32 %cv5345, ptr %slot884, align 8
  %v5346 = load i32, ptr %slot884, align 8
  %cv5347 = zext i32 %v5346 to i64
  %cond5348 = icmp ne i64 %cv5347, 0
  br i1 %cond5348, label %bb_rcgclear1193, label %bb_rcgcounted1193
bb_rcgcounted1193:
  %v5349 = load i64, ptr %slot879, align 8
  %op5350 = sub i64 %v5349, 32
  store i64 %op5350, ptr %slot885, align 8
  %v5351 = load i64, ptr %slot879, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %rgep5353 = getelementptr i8, ptr %p5352, i64 -32
  %ld5354 = load i64, ptr %rgep5353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5354, ptr %slot886, align 8
  %v5355 = load i64, ptr %slot886, align 8
  %op5356 = sub i64 %v5355, 1
  store i64 %op5356, ptr %slot887, align 8
  %v5357 = load i64, ptr %slot887, align 8
  %cmp5358 = icmp eq i64 %v5357, 0
  %cv5359 = zext i1 %cmp5358 to i32
  store i32 %cv5359, ptr %slot888, align 8
  %v5360 = load i32, ptr %slot888, align 8
  %cv5361 = zext i32 %v5360 to i64
  %cond5362 = icmp ne i64 %cv5361, 0
  br i1 %cond5362, label %bb_rcglast1193, label %bb_rcgdec1193
bb_rcglast1193:
  %v5363 = load i64, ptr %slot879, align 8
  %op5364 = sub i64 %v5363, 24
  store i64 %op5364, ptr %slot889, align 8
  %v5365 = load i64, ptr %slot879, align 8
  %p5366 = inttoptr i64 %v5365 to ptr
  %rgep5367 = getelementptr i8, ptr %p5366, i64 -24
  %ld5368 = load i64, ptr %rgep5367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5368, ptr %slot890, align 8
  %v5369 = load i64, ptr %slot890, align 8
  %cmp5370 = icmp ne i64 %v5369, 0
  %cv5371 = zext i1 %cmp5370 to i32
  store i32 %cv5371, ptr %slot891, align 8
  %v5372 = load i32, ptr %slot891, align 8
  %cv5373 = zext i32 %v5372 to i64
  %cond5374 = icmp ne i64 %cv5373, 0
  br i1 %cond5374, label %bb_rcgdec1193, label %bb_rcgslow1193
bb_rcgslow1193:
  %v5375 = load i64, ptr %slot878, align 8
  %v5376 = load i64, ptr %slot877, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5375, i64 %v5376) nomerge, !dbg !162
  br label %bb_rcgdone1193
bb_rcgdec1193:
  %v5377 = load i64, ptr %slot887, align 8
  %v5378 = load i64, ptr %slot879, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  %rgep5380 = getelementptr i8, ptr %p5379, i64 -32
  store i64 %v5377, ptr %rgep5380, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1193
bb_rcgclear1193:
  %v5381 = load i64, ptr %slot877, align 8
  %p5382 = inttoptr i64 %v5381 to ptr
  store i64 0, ptr %p5382, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1193
bb_rcgdone1193:
  %v5383 = load i64, ptr %slot873, align 8
  %p5384 = inttoptr i64 %v5383 to ptr
  store i64 0, ptr %p5384, align 8, !alias.scope !3, !noalias !4
  %v5385 = load i64, ptr %slot873, align 8
  %p5387 = inttoptr i64 %v5385 to ptr
  %gep5388 = getelementptr i8, ptr %p5387, i64 8
  %op5386 = ptrtoint ptr %gep5388 to i64
  store i64 %op5386, ptr %slot892, align 8
  %v5389 = load i64, ptr %slot892, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  store i64 0, ptr %p5390, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1175
bb_rcslotdone1175:
  br label %bb_rcprivateprepared1140
bb_rcprivateprepared1140:
  %v5391 = load i64, ptr %slot17, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  %ld5393 = load i32, ptr %p5392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5393, ptr %slot893, align 8
  %v5394 = load i32, ptr %slot893, align 8
  %cv5395 = zext i32 %v5394 to i64
  %cond5396 = icmp ne i64 %cv5395, 0
  br i1 %cond5396, label %bb_rcslotdrop1201, label %bb_rcslotdone1201
bb_rcslotdrop1201:
  %v5397 = load i64, ptr %slot17, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  store i32 0, ptr %p5398, align 4, !alias.scope !3, !noalias !4
  %v5399 = load i64, ptr %slot49, align 8
  store i64 %v5399, ptr %slot894, align 8
  %v5400 = load i64, ptr %slot18, align 8
  %p5401 = inttoptr i64 %v5400 to ptr
  %ld5402 = load i32, ptr %p5401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5402, ptr %slot895, align 8
  %v5403 = load i32, ptr %slot895, align 8
  %op5404 = and i32 %v5403, 28
  store i32 %op5404, ptr %slot896, align 8
  %v5405 = load i32, ptr %slot896, align 8
  %cv5406 = zext i32 %v5405 to i64
  %cond5407 = icmp ne i64 %cv5406, 0
  br i1 %cond5407, label %bb_rcslotrole1201, label %bb_rcslotowner1201
bb_rcslotrole1201:
  %v5408 = load i64, ptr %slot64, align 8
  store i64 %v5408, ptr %slot897, align 8
  %v5409 = load i64, ptr %slot897, align 8
  %v5410 = load i64, ptr %slot894, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5409, i64 %v5410) nomerge, !dbg !162
  br label %bb_rcslotdone1201
bb_rcslotowner1201:
  %v5411 = load i64, ptr %slot894, align 8
  %p5413 = inttoptr i64 %v5411 to ptr
  %gep5414 = getelementptr i8, ptr %p5413, i64 0
  %op5412 = ptrtoint ptr %gep5414 to i64
  store i64 %op5412, ptr %slot898, align 8
  %v5415 = load i64, ptr %slot64, align 8
  store i64 %v5415, ptr %slot899, align 8
  %v5416 = load i64, ptr %slot898, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %ld5418 = load i64, ptr %p5417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5418, ptr %slot900, align 8
  %v5419 = load i64, ptr %slot900, align 8
  %cmp5420 = icmp ne i64 %v5419, 0
  %cv5421 = zext i1 %cmp5420 to i32
  store i32 %cv5421, ptr %slot901, align 8
  %v5422 = load i32, ptr %slot901, align 8
  %cv5423 = zext i32 %v5422 to i64
  %cond5424 = icmp ne i64 %cv5423, 0
  br i1 %cond5424, label %bb_rcgnn1219, label %bb_rcgdone1219
bb_rcgnn1219:
  %v5425 = load i64, ptr %slot900, align 8
  %op5426 = sub i64 %v5425, 16
  store i64 %op5426, ptr %slot902, align 8
  %v5427 = load i64, ptr %slot900, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %rgep5429 = getelementptr i8, ptr %p5428, i64 -16
  %ld5430 = load i64, ptr %rgep5429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5430, ptr %slot903, align 8
  %v5431 = load i64, ptr %slot903, align 8
  %op5432 = and i64 %v5431, 4611686018427387906
  store i64 %op5432, ptr %slot904, align 8
  %v5433 = load i64, ptr %slot904, align 8
  %cmp5434 = icmp ne i64 %v5433, 0
  %cv5435 = zext i1 %cmp5434 to i32
  store i32 %cv5435, ptr %slot905, align 8
  %v5436 = load i32, ptr %slot905, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcgclear1219, label %bb_rcgcounted1219
bb_rcgcounted1219:
  %v5439 = load i64, ptr %slot900, align 8
  %op5440 = sub i64 %v5439, 32
  store i64 %op5440, ptr %slot906, align 8
  %v5441 = load i64, ptr %slot900, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %rgep5443 = getelementptr i8, ptr %p5442, i64 -32
  %ld5444 = load i64, ptr %rgep5443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5444, ptr %slot907, align 8
  %v5445 = load i64, ptr %slot907, align 8
  %op5446 = sub i64 %v5445, 1
  store i64 %op5446, ptr %slot908, align 8
  %v5447 = load i64, ptr %slot908, align 8
  %cmp5448 = icmp eq i64 %v5447, 0
  %cv5449 = zext i1 %cmp5448 to i32
  store i32 %cv5449, ptr %slot909, align 8
  %v5450 = load i32, ptr %slot909, align 8
  %cv5451 = zext i32 %v5450 to i64
  %cond5452 = icmp ne i64 %cv5451, 0
  br i1 %cond5452, label %bb_rcglast1219, label %bb_rcgdec1219
bb_rcglast1219:
  %v5453 = load i64, ptr %slot900, align 8
  %op5454 = sub i64 %v5453, 24
  store i64 %op5454, ptr %slot910, align 8
  %v5455 = load i64, ptr %slot900, align 8
  %p5456 = inttoptr i64 %v5455 to ptr
  %rgep5457 = getelementptr i8, ptr %p5456, i64 -24
  %ld5458 = load i64, ptr %rgep5457, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5458, ptr %slot911, align 8
  %v5459 = load i64, ptr %slot911, align 8
  %cmp5460 = icmp ne i64 %v5459, 0
  %cv5461 = zext i1 %cmp5460 to i32
  store i32 %cv5461, ptr %slot912, align 8
  %v5462 = load i32, ptr %slot912, align 8
  %cv5463 = zext i32 %v5462 to i64
  %cond5464 = icmp ne i64 %cv5463, 0
  br i1 %cond5464, label %bb_rcgdec1219, label %bb_rcgslow1219
bb_rcgslow1219:
  %v5465 = load i64, ptr %slot899, align 8
  %v5466 = load i64, ptr %slot898, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5465, i64 %v5466) nomerge, !dbg !162
  br label %bb_rcgdone1219
bb_rcgdec1219:
  %v5467 = load i64, ptr %slot908, align 8
  %v5468 = load i64, ptr %slot900, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  %rgep5470 = getelementptr i8, ptr %p5469, i64 -32
  store i64 %v5467, ptr %rgep5470, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1219
bb_rcgclear1219:
  %v5471 = load i64, ptr %slot898, align 8
  %p5472 = inttoptr i64 %v5471 to ptr
  store i64 0, ptr %p5472, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1219
bb_rcgdone1219:
  %v5473 = load i64, ptr %slot894, align 8
  %p5474 = inttoptr i64 %v5473 to ptr
  store i64 0, ptr %p5474, align 8, !alias.scope !3, !noalias !4
  %v5475 = load i64, ptr %slot894, align 8
  %p5477 = inttoptr i64 %v5475 to ptr
  %gep5478 = getelementptr i8, ptr %p5477, i64 8
  %op5476 = ptrtoint ptr %gep5478 to i64
  store i64 %op5476, ptr %slot913, align 8
  %v5479 = load i64, ptr %slot913, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  store i64 0, ptr %p5480, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1201
bb_rcslotdone1201:
  %v5481 = load i64, ptr %slot49, align 8
  store i64 %v5481, ptr %slot914, align 8
  %v5482 = load i64, ptr %slot35, align 8
  store i64 %v5482, ptr %slot915, align 8
  %v5483 = load i64, ptr %slot915, align 8
  %v5484 = load i64, ptr %slot914, align 8
  %p5485 = inttoptr i64 %v5483 to ptr
  %p5486 = inttoptr i64 %v5484 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5486, ptr %p5485, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5487 = load i64, ptr %slot27, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  store i32 0, ptr %p5488, align 4, !alias.scope !3, !noalias !4
  %v5489 = load i64, ptr %slot18, align 8
  %p5490 = inttoptr i64 %v5489 to ptr
  store i32 2, ptr %p5490, align 4, !alias.scope !3, !noalias !4
  %v5491 = load i64, ptr %slot28, align 8
  %p5492 = inttoptr i64 %v5491 to ptr
  %ld5493 = load i32, ptr %p5492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5493, ptr %slot916, align 8
  %v5494 = load i32, ptr %slot916, align 8
  %v5495 = load i64, ptr %slot18, align 8
  %p5496 = inttoptr i64 %v5495 to ptr
  store i32 %v5494, ptr %p5496, align 4, !alias.scope !3, !noalias !4
  %v5497 = load i64, ptr %slot17, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  store i32 1, ptr %p5498, align 4, !alias.scope !3, !noalias !4
  %v5499 = load i64, ptr %slot47, align 8
  %v5500 = load i64, ptr %slot53, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  store i64 %v5499, ptr %p5501, align 8, !alias.scope !3, !noalias !4
  %v5502 = load i64, ptr %slot53, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %ld5504 = load i64, ptr %p5503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5504, ptr %slot917, align 8
  %v5505 = load i64, ptr %slot21, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  %ld5507 = load i32, ptr %p5506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5507, ptr %slot918, align 8
  %v5508 = load i64, ptr %slot22, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %ld5510 = load i32, ptr %p5509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5510, ptr %slot919, align 8
  %v5511 = load i32, ptr %slot919, align 8
  %op5512 = and i32 %v5511, 24
  store i32 %op5512, ptr %slot919, align 8
  %v5513 = load i32, ptr %slot919, align 8
  %cmp5514 = icmp eq i32 %v5513, 0
  %cv5515 = zext i1 %cmp5514 to i32
  store i32 %cv5515, ptr %slot920, align 8
  %v5516 = load i32, ptr %slot918, align 8
  %v5517 = load i32, ptr %slot920, align 8
  %op5518 = and i32 %v5516, %v5517
  store i32 %op5518, ptr %slot921, align 8
  %v5519 = load i32, ptr %slot921, align 8
  %cv5520 = zext i32 %v5519 to i64
  %cond5521 = icmp ne i64 %cv5520, 0
  br i1 %cond5521, label %bb_rcprivateown1238, label %bb_rcprivateloan1238
bb_rcprivateown1238:
  %v5522 = load i64, ptr %slot35, align 8
  store i64 %v5522, ptr %slot922, align 8
  %v5523 = load i64, ptr %slot65, align 8
  store i64 %v5523, ptr %slot923, align 8
  %v5524 = load i64, ptr %slot917, align 8
  %v5525 = load i64, ptr %slot922, align 8
  %op5526 = sub i64 %v5524, %v5525
  store i64 %op5526, ptr %slot924, align 8
  %v5527 = load i64, ptr %slot922, align 8
  %v5528 = load i64, ptr %slot917, align 8
  %op5529 = sub i64 %v5527, %v5528
  store i64 %op5529, ptr %slot925, align 8
  %v5530 = load i64, ptr %slot924, align 8
  %cmp5531 = icmp ult i64 %v5530, 24
  %cv5532 = zext i1 %cmp5531 to i32
  store i32 %cv5532, ptr %slot926, align 8
  %v5533 = load i64, ptr %slot925, align 8
  %cmp5534 = icmp ult i64 %v5533, 24
  %cv5535 = zext i1 %cmp5534 to i32
  store i32 %cv5535, ptr %slot927, align 8
  %v5536 = load i32, ptr %slot926, align 8
  %v5537 = load i32, ptr %slot927, align 8
  %op5538 = or i32 %v5536, %v5537
  store i32 %op5538, ptr %slot928, align 8
  %v5539 = load i32, ptr %slot928, align 8
  %cv5540 = zext i32 %v5539 to i64
  %cond5541 = icmp ne i64 %cv5540, 0
  br i1 %cond5541, label %bb_rcmoveslow1241, label %bb_rcmovecheck1241
bb_rcmovecheck1241:
  %v5542 = load i64, ptr %slot917, align 8
  %op5543 = add i64 %v5542, 8
  store i64 %op5543, ptr %slot929, align 8
  %v5544 = load i64, ptr %slot929, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  %ld5546 = load i64, ptr %p5545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5546, ptr %slot930, align 8
  %v5547 = load i64, ptr %slot930, align 8
  %cmp5548 = icmp ne i64 %v5547, 0
  %cv5549 = zext i1 %cmp5548 to i32
  store i32 %cv5549, ptr %slot931, align 8
  %v5550 = load i32, ptr %slot931, align 8
  %cv5551 = zext i32 %v5550 to i64
  %cond5552 = icmp ne i64 %cv5551, 0
  br i1 %cond5552, label %bb_rcmoveheader1249, label %bb_rcmovenext1249
bb_rcmoveheader1249:
  %v5553 = load i64, ptr %slot930, align 8
  %op5554 = sub i64 %v5553, 16
  store i64 %op5554, ptr %slot932, align 8
  %v5555 = load i64, ptr %slot930, align 8
  %p5556 = inttoptr i64 %v5555 to ptr
  %rgep5557 = getelementptr i8, ptr %p5556, i64 -16
  %ld5558 = load i64, ptr %rgep5557, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5558, ptr %slot933, align 8
  %v5559 = load i64, ptr %slot933, align 8
  %op5560 = and i64 %v5559, 5764607523034234881
  store i64 %op5560, ptr %slot934, align 8
  %v5561 = load i64, ptr %slot934, align 8
  %cmp5562 = icmp ne i64 %v5561, 0
  %cv5563 = zext i1 %cmp5562 to i32
  store i32 %cv5563, ptr %slot935, align 8
  %v5564 = load i32, ptr %slot935, align 8
  %cv5565 = zext i32 %v5564 to i64
  %cond5566 = icmp ne i64 %cv5565, 0
  br i1 %cond5566, label %bb_rcmoveslow1241, label %bb_rcmovenext1249
bb_rcmovenext1249:
  %v5567 = load i64, ptr %slot917, align 8
  %v5568 = load i64, ptr %slot922, align 8
  %p5569 = inttoptr i64 %v5567 to ptr
  %p5570 = inttoptr i64 %v5568 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5570, ptr %p5569, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5571 = load i64, ptr %slot917, align 8
  %p5572 = inttoptr i64 %v5571 to ptr
  store i64 0, ptr %p5572, align 8, !alias.scope !3, !noalias !4
  %v5573 = load i64, ptr %slot917, align 8
  %op5574 = add i64 %v5573, 8
  store i64 %op5574, ptr %slot936, align 8
  %v5575 = load i64, ptr %slot936, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  store i64 0, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  %v5577 = load i64, ptr %slot917, align 8
  %op5578 = add i64 %v5577, 16
  store i64 %op5578, ptr %slot937, align 8
  %v5579 = load i64, ptr %slot937, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i64 0, ptr %p5580, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1241
bb_rcmoveslow1241:
  %v5581 = load i64, ptr %slot64, align 8
  %v5582 = load i64, ptr %slot922, align 8
  %v5583 = load i64, ptr %slot917, align 8
  %v5584 = load i64, ptr %slot923, align 8
  %cv5585 = trunc i64 %v5584 to i32
  %call5586 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v5581, i64 %v5582, i64 %v5583, i32 %cv5585) nomerge, !dbg !164
  store i32 %call5586, ptr %slot938, align 8
  %v5587 = load i32, ptr %slot938, align 8
  %cv5588 = zext i32 %v5587 to i64
  %cond5589 = icmp ne i64 %cv5588, 0
  br i1 %cond5589, label %bb_rcsuccess1258, label %bb_rcfailure1258
bb_rcfailure1258:
  %v5590 = load i64, ptr %slot64, align 8
  %p5591 = inttoptr i64 %v5590 to ptr
  %call5592 = call i32 @myl_rc_take_failure(ptr %p5591) nomerge, !dbg !164
  store i32 %call5592, ptr %slot939, align 8
  %v5593 = load i64, ptr %slot1, align 8
  %p5594 = inttoptr i64 %v5593 to ptr
  %v5595 = load i32, ptr %slot939, align 8
  %call5596 = call i32 @myl_qbe_rc_status(ptr %p5594, i32 %v5595) nomerge, !dbg !164
  store i32 %call5596, ptr %slot940, align 8
  br label %bb_failure
bb_rcsuccess1258:
  br label %bb_rcmoved1241
bb_rcmoved1241:
  %v5597 = load i64, ptr %slot21, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  store i32 0, ptr %p5598, align 4, !alias.scope !3, !noalias !4
  %v5599 = load i64, ptr %slot28, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  store i32 2, ptr %p5600, align 4, !alias.scope !3, !noalias !4
  %v5601 = load i64, ptr %slot27, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  store i32 1, ptr %p5602, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1238
bb_rcprivateloan1238:
  %v5603 = load i64, ptr %slot35, align 8
  store i64 %v5603, ptr %slot941, align 8
  %v5604 = load i64, ptr %slot64, align 8
  %v5605 = load i64, ptr %slot941, align 8
  %v5606 = load i64, ptr %slot917, align 8
  %call5607 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v5604, i64 %v5605, i64 %v5606) nomerge, !dbg !164
  store i32 %call5607, ptr %slot942, align 8
  %v5608 = load i32, ptr %slot942, align 8
  %cv5609 = zext i32 %v5608 to i64
  %cond5610 = icmp ne i64 %cv5609, 0
  br i1 %cond5610, label %bb_rcsuccess1266, label %bb_rcfailure1266
bb_rcfailure1266:
  %v5611 = load i64, ptr %slot64, align 8
  %p5612 = inttoptr i64 %v5611 to ptr
  %call5613 = call i32 @myl_rc_take_failure(ptr %p5612) nomerge, !dbg !164
  store i32 %call5613, ptr %slot943, align 8
  %v5614 = load i64, ptr %slot1, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  %v5616 = load i32, ptr %slot943, align 8
  %call5617 = call i32 @myl_qbe_rc_status(ptr %p5615, i32 %v5616) nomerge, !dbg !164
  store i32 %call5617, ptr %slot944, align 8
  br label %bb_failure
bb_rcsuccess1266:
  %v5618 = load i64, ptr %slot28, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  store i32 2, ptr %p5619, align 4, !alias.scope !3, !noalias !4
  %v5620 = load i64, ptr %slot28, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  store i32 16, ptr %p5621, align 4, !alias.scope !3, !noalias !4
  %v5622 = load i64, ptr %slot27, align 8
  %p5623 = inttoptr i64 %v5622 to ptr
  store i32 1, ptr %p5623, align 4, !alias.scope !3, !noalias !4
  %v5624 = load i64, ptr %slot21, align 8
  %p5625 = inttoptr i64 %v5624 to ptr
  %ld5626 = load i32, ptr %p5625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5626, ptr %slot945, align 8
  %v5627 = load i32, ptr %slot945, align 8
  %cv5628 = zext i32 %v5627 to i64
  %cond5629 = icmp ne i64 %cv5628, 0
  br i1 %cond5629, label %bb_rcslotdrop1274, label %bb_rcslotdone1274
bb_rcslotdrop1274:
  %v5630 = load i64, ptr %slot21, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  store i32 0, ptr %p5631, align 4, !alias.scope !3, !noalias !4
  %v5632 = load i64, ptr %slot30, align 8
  store i64 %v5632, ptr %slot946, align 8
  %v5633 = load i64, ptr %slot22, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  %ld5635 = load i32, ptr %p5634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5635, ptr %slot947, align 8
  %v5636 = load i32, ptr %slot947, align 8
  %op5637 = and i32 %v5636, 28
  store i32 %op5637, ptr %slot948, align 8
  %v5638 = load i32, ptr %slot948, align 8
  %cv5639 = zext i32 %v5638 to i64
  %cond5640 = icmp ne i64 %cv5639, 0
  br i1 %cond5640, label %bb_rcslotrole1274, label %bb_rcslotowner1274
bb_rcslotrole1274:
  %v5641 = load i64, ptr %slot64, align 8
  store i64 %v5641, ptr %slot949, align 8
  %v5642 = load i64, ptr %slot949, align 8
  %v5643 = load i64, ptr %slot946, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v5642, i64 %v5643) nomerge, !dbg !164
  br label %bb_rcslotdone1274
bb_rcslotowner1274:
  %v5644 = load i64, ptr %slot946, align 8
  %p5646 = inttoptr i64 %v5644 to ptr
  %gep5647 = getelementptr i8, ptr %p5646, i64 8
  %op5645 = ptrtoint ptr %gep5647 to i64
  store i64 %op5645, ptr %slot950, align 8
  %v5648 = load i64, ptr %slot64, align 8
  store i64 %v5648, ptr %slot951, align 8
  %v5649 = load i64, ptr %slot950, align 8
  %p5650 = inttoptr i64 %v5649 to ptr
  %ld5651 = load i64, ptr %p5650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5651, ptr %slot952, align 8
  %v5652 = load i64, ptr %slot952, align 8
  %cmp5653 = icmp ne i64 %v5652, 0
  %cv5654 = zext i1 %cmp5653 to i32
  store i32 %cv5654, ptr %slot953, align 8
  %v5655 = load i32, ptr %slot953, align 8
  %cv5656 = zext i32 %v5655 to i64
  %cond5657 = icmp ne i64 %cv5656, 0
  br i1 %cond5657, label %bb_rcgnn1292, label %bb_rcgdone1292
bb_rcgnn1292:
  %v5658 = load i64, ptr %slot952, align 8
  %op5659 = sub i64 %v5658, 16
  store i64 %op5659, ptr %slot954, align 8
  %v5660 = load i64, ptr %slot952, align 8
  %p5661 = inttoptr i64 %v5660 to ptr
  %rgep5662 = getelementptr i8, ptr %p5661, i64 -16
  %ld5663 = load i64, ptr %rgep5662, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5663, ptr %slot955, align 8
  %v5664 = load i64, ptr %slot955, align 8
  %op5665 = and i64 %v5664, 4611686018427387906
  store i64 %op5665, ptr %slot956, align 8
  %v5666 = load i64, ptr %slot956, align 8
  %cmp5667 = icmp ne i64 %v5666, 0
  %cv5668 = zext i1 %cmp5667 to i32
  store i32 %cv5668, ptr %slot957, align 8
  %v5669 = load i32, ptr %slot957, align 8
  %cv5670 = zext i32 %v5669 to i64
  %cond5671 = icmp ne i64 %cv5670, 0
  br i1 %cond5671, label %bb_rcgclear1292, label %bb_rcgcounted1292
bb_rcgcounted1292:
  %v5672 = load i64, ptr %slot952, align 8
  %op5673 = sub i64 %v5672, 32
  store i64 %op5673, ptr %slot958, align 8
  %v5674 = load i64, ptr %slot952, align 8
  %p5675 = inttoptr i64 %v5674 to ptr
  %rgep5676 = getelementptr i8, ptr %p5675, i64 -32
  %ld5677 = load i64, ptr %rgep5676, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5677, ptr %slot959, align 8
  %v5678 = load i64, ptr %slot959, align 8
  %op5679 = sub i64 %v5678, 1
  store i64 %op5679, ptr %slot960, align 8
  %v5680 = load i64, ptr %slot960, align 8
  %cmp5681 = icmp eq i64 %v5680, 0
  %cv5682 = zext i1 %cmp5681 to i32
  store i32 %cv5682, ptr %slot961, align 8
  %v5683 = load i32, ptr %slot961, align 8
  %cv5684 = zext i32 %v5683 to i64
  %cond5685 = icmp ne i64 %cv5684, 0
  br i1 %cond5685, label %bb_rcglast1292, label %bb_rcgdec1292
bb_rcglast1292:
  %v5686 = load i64, ptr %slot952, align 8
  %op5687 = sub i64 %v5686, 24
  store i64 %op5687, ptr %slot962, align 8
  %v5688 = load i64, ptr %slot952, align 8
  %p5689 = inttoptr i64 %v5688 to ptr
  %rgep5690 = getelementptr i8, ptr %p5689, i64 -24
  %ld5691 = load i64, ptr %rgep5690, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5691, ptr %slot963, align 8
  %v5692 = load i64, ptr %slot963, align 8
  %cmp5693 = icmp ne i64 %v5692, 0
  %cv5694 = zext i1 %cmp5693 to i32
  store i32 %cv5694, ptr %slot964, align 8
  %v5695 = load i32, ptr %slot964, align 8
  %cv5696 = zext i32 %v5695 to i64
  %cond5697 = icmp ne i64 %cv5696, 0
  br i1 %cond5697, label %bb_rcgdec1292, label %bb_rcgslow1292
bb_rcgslow1292:
  %v5698 = load i64, ptr %slot951, align 8
  %v5699 = load i64, ptr %slot950, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5698, i64 %v5699) nomerge, !dbg !164
  br label %bb_rcgdone1292
bb_rcgdec1292:
  %v5700 = load i64, ptr %slot960, align 8
  %v5701 = load i64, ptr %slot952, align 8
  %p5702 = inttoptr i64 %v5701 to ptr
  %rgep5703 = getelementptr i8, ptr %p5702, i64 -32
  store i64 %v5700, ptr %rgep5703, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1292
bb_rcgclear1292:
  %v5704 = load i64, ptr %slot950, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  store i64 0, ptr %p5705, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1292
bb_rcgdone1292:
  %v5706 = load i64, ptr %slot946, align 8
  %p5707 = inttoptr i64 %v5706 to ptr
  store i64 0, ptr %p5707, align 8, !alias.scope !3, !noalias !4
  %v5708 = load i64, ptr %slot946, align 8
  %p5710 = inttoptr i64 %v5708 to ptr
  %gep5711 = getelementptr i8, ptr %p5710, i64 8
  %op5709 = ptrtoint ptr %gep5711 to i64
  store i64 %op5709, ptr %slot965, align 8
  %v5712 = load i64, ptr %slot965, align 8
  %p5713 = inttoptr i64 %v5712 to ptr
  store i64 0, ptr %p5713, align 8, !alias.scope !3, !noalias !4
  %v5714 = load i64, ptr %slot946, align 8
  %p5716 = inttoptr i64 %v5714 to ptr
  %gep5717 = getelementptr i8, ptr %p5716, i64 16
  %op5715 = ptrtoint ptr %gep5717 to i64
  store i64 %op5715, ptr %slot966, align 8
  %v5718 = load i64, ptr %slot966, align 8
  %p5719 = inttoptr i64 %v5718 to ptr
  store i64 0, ptr %p5719, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1274
bb_rcslotdone1274:
  br label %bb_rcprivateprepared1238
bb_rcprivateprepared1238:
  %v5720 = load i64, ptr %slot15, align 8
  %p5721 = inttoptr i64 %v5720 to ptr
  %ld5722 = load i32, ptr %p5721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5722, ptr %slot967, align 8
  %v5723 = load i32, ptr %slot967, align 8
  %cv5724 = zext i32 %v5723 to i64
  %cond5725 = icmp ne i64 %cv5724, 0
  br i1 %cond5725, label %bb_rcslotdrop1301, label %bb_rcslotdone1301
bb_rcslotdrop1301:
  %v5726 = load i64, ptr %slot15, align 8
  %p5727 = inttoptr i64 %v5726 to ptr
  store i32 0, ptr %p5727, align 4, !alias.scope !3, !noalias !4
  %v5728 = load i64, ptr %slot48, align 8
  store i64 %v5728, ptr %slot968, align 8
  %v5729 = load i64, ptr %slot16, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  %ld5731 = load i32, ptr %p5730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5731, ptr %slot969, align 8
  %v5732 = load i32, ptr %slot969, align 8
  %op5733 = and i32 %v5732, 28
  store i32 %op5733, ptr %slot970, align 8
  %v5734 = load i32, ptr %slot970, align 8
  %cv5735 = zext i32 %v5734 to i64
  %cond5736 = icmp ne i64 %cv5735, 0
  br i1 %cond5736, label %bb_rcslotrole1301, label %bb_rcslotowner1301
bb_rcslotrole1301:
  %v5737 = load i64, ptr %slot64, align 8
  store i64 %v5737, ptr %slot971, align 8
  %v5738 = load i64, ptr %slot971, align 8
  %v5739 = load i64, ptr %slot968, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v5738, i64 %v5739) nomerge, !dbg !164
  br label %bb_rcslotdone1301
bb_rcslotowner1301:
  %v5740 = load i64, ptr %slot968, align 8
  %p5742 = inttoptr i64 %v5740 to ptr
  %gep5743 = getelementptr i8, ptr %p5742, i64 8
  %op5741 = ptrtoint ptr %gep5743 to i64
  store i64 %op5741, ptr %slot972, align 8
  %v5744 = load i64, ptr %slot64, align 8
  store i64 %v5744, ptr %slot973, align 8
  %v5745 = load i64, ptr %slot972, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %ld5747 = load i64, ptr %p5746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5747, ptr %slot974, align 8
  %v5748 = load i64, ptr %slot974, align 8
  %cmp5749 = icmp ne i64 %v5748, 0
  %cv5750 = zext i1 %cmp5749 to i32
  store i32 %cv5750, ptr %slot975, align 8
  %v5751 = load i32, ptr %slot975, align 8
  %cv5752 = zext i32 %v5751 to i64
  %cond5753 = icmp ne i64 %cv5752, 0
  br i1 %cond5753, label %bb_rcgnn1319, label %bb_rcgdone1319
bb_rcgnn1319:
  %v5754 = load i64, ptr %slot974, align 8
  %op5755 = sub i64 %v5754, 16
  store i64 %op5755, ptr %slot976, align 8
  %v5756 = load i64, ptr %slot974, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  %rgep5758 = getelementptr i8, ptr %p5757, i64 -16
  %ld5759 = load i64, ptr %rgep5758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5759, ptr %slot977, align 8
  %v5760 = load i64, ptr %slot977, align 8
  %op5761 = and i64 %v5760, 4611686018427387906
  store i64 %op5761, ptr %slot978, align 8
  %v5762 = load i64, ptr %slot978, align 8
  %cmp5763 = icmp ne i64 %v5762, 0
  %cv5764 = zext i1 %cmp5763 to i32
  store i32 %cv5764, ptr %slot979, align 8
  %v5765 = load i32, ptr %slot979, align 8
  %cv5766 = zext i32 %v5765 to i64
  %cond5767 = icmp ne i64 %cv5766, 0
  br i1 %cond5767, label %bb_rcgclear1319, label %bb_rcgcounted1319
bb_rcgcounted1319:
  %v5768 = load i64, ptr %slot974, align 8
  %op5769 = sub i64 %v5768, 32
  store i64 %op5769, ptr %slot980, align 8
  %v5770 = load i64, ptr %slot974, align 8
  %p5771 = inttoptr i64 %v5770 to ptr
  %rgep5772 = getelementptr i8, ptr %p5771, i64 -32
  %ld5773 = load i64, ptr %rgep5772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5773, ptr %slot981, align 8
  %v5774 = load i64, ptr %slot981, align 8
  %op5775 = sub i64 %v5774, 1
  store i64 %op5775, ptr %slot982, align 8
  %v5776 = load i64, ptr %slot982, align 8
  %cmp5777 = icmp eq i64 %v5776, 0
  %cv5778 = zext i1 %cmp5777 to i32
  store i32 %cv5778, ptr %slot983, align 8
  %v5779 = load i32, ptr %slot983, align 8
  %cv5780 = zext i32 %v5779 to i64
  %cond5781 = icmp ne i64 %cv5780, 0
  br i1 %cond5781, label %bb_rcglast1319, label %bb_rcgdec1319
bb_rcglast1319:
  %v5782 = load i64, ptr %slot974, align 8
  %op5783 = sub i64 %v5782, 24
  store i64 %op5783, ptr %slot984, align 8
  %v5784 = load i64, ptr %slot974, align 8
  %p5785 = inttoptr i64 %v5784 to ptr
  %rgep5786 = getelementptr i8, ptr %p5785, i64 -24
  %ld5787 = load i64, ptr %rgep5786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5787, ptr %slot985, align 8
  %v5788 = load i64, ptr %slot985, align 8
  %cmp5789 = icmp ne i64 %v5788, 0
  %cv5790 = zext i1 %cmp5789 to i32
  store i32 %cv5790, ptr %slot986, align 8
  %v5791 = load i32, ptr %slot986, align 8
  %cv5792 = zext i32 %v5791 to i64
  %cond5793 = icmp ne i64 %cv5792, 0
  br i1 %cond5793, label %bb_rcgdec1319, label %bb_rcgslow1319
bb_rcgslow1319:
  %v5794 = load i64, ptr %slot973, align 8
  %v5795 = load i64, ptr %slot972, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5794, i64 %v5795) nomerge, !dbg !164
  br label %bb_rcgdone1319
bb_rcgdec1319:
  %v5796 = load i64, ptr %slot982, align 8
  %v5797 = load i64, ptr %slot974, align 8
  %p5798 = inttoptr i64 %v5797 to ptr
  %rgep5799 = getelementptr i8, ptr %p5798, i64 -32
  store i64 %v5796, ptr %rgep5799, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1319
bb_rcgclear1319:
  %v5800 = load i64, ptr %slot972, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  store i64 0, ptr %p5801, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1319
bb_rcgdone1319:
  %v5802 = load i64, ptr %slot968, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  store i64 0, ptr %p5803, align 8, !alias.scope !3, !noalias !4
  %v5804 = load i64, ptr %slot968, align 8
  %p5806 = inttoptr i64 %v5804 to ptr
  %gep5807 = getelementptr i8, ptr %p5806, i64 8
  %op5805 = ptrtoint ptr %gep5807 to i64
  store i64 %op5805, ptr %slot987, align 8
  %v5808 = load i64, ptr %slot987, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  store i64 0, ptr %p5809, align 8, !alias.scope !3, !noalias !4
  %v5810 = load i64, ptr %slot968, align 8
  %p5812 = inttoptr i64 %v5810 to ptr
  %gep5813 = getelementptr i8, ptr %p5812, i64 16
  %op5811 = ptrtoint ptr %gep5813 to i64
  store i64 %op5811, ptr %slot988, align 8
  %v5814 = load i64, ptr %slot988, align 8
  %p5815 = inttoptr i64 %v5814 to ptr
  store i64 0, ptr %p5815, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1301
bb_rcslotdone1301:
  %v5816 = load i64, ptr %slot48, align 8
  store i64 %v5816, ptr %slot989, align 8
  %v5817 = load i64, ptr %slot35, align 8
  store i64 %v5817, ptr %slot990, align 8
  %v5818 = load i64, ptr %slot990, align 8
  %v5819 = load i64, ptr %slot989, align 8
  %p5820 = inttoptr i64 %v5818 to ptr
  %p5821 = inttoptr i64 %v5819 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5821, ptr %p5820, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5822 = load i64, ptr %slot27, align 8
  %p5823 = inttoptr i64 %v5822 to ptr
  store i32 0, ptr %p5823, align 4, !alias.scope !3, !noalias !4
  %v5824 = load i64, ptr %slot16, align 8
  %p5825 = inttoptr i64 %v5824 to ptr
  store i32 2, ptr %p5825, align 4, !alias.scope !3, !noalias !4
  %v5826 = load i64, ptr %slot28, align 8
  %p5827 = inttoptr i64 %v5826 to ptr
  %ld5828 = load i32, ptr %p5827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5828, ptr %slot991, align 8
  %v5829 = load i32, ptr %slot991, align 8
  %v5830 = load i64, ptr %slot16, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  store i32 %v5829, ptr %p5831, align 4, !alias.scope !3, !noalias !4
  %v5832 = load i64, ptr %slot15, align 8
  %p5833 = inttoptr i64 %v5832 to ptr
  store i32 1, ptr %p5833, align 4, !alias.scope !3, !noalias !4
  %v5834 = load i64, ptr %slot47, align 8
  %v5835 = load i64, ptr %slot53, align 8
  %p5836 = inttoptr i64 %v5835 to ptr
  store i64 %v5834, ptr %p5836, align 8, !alias.scope !3, !noalias !4
  %v5837 = load i64, ptr %slot53, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  %ld5839 = load i64, ptr %p5838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5839, ptr %slot992, align 8
  %v5840 = load i64, ptr %slot21, align 8
  %p5841 = inttoptr i64 %v5840 to ptr
  %ld5842 = load i32, ptr %p5841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5842, ptr %slot993, align 8
  %v5843 = load i64, ptr %slot22, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  %ld5845 = load i32, ptr %p5844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5845, ptr %slot994, align 8
  %v5846 = load i32, ptr %slot994, align 8
  %op5847 = and i32 %v5846, 24
  store i32 %op5847, ptr %slot994, align 8
  %v5848 = load i32, ptr %slot994, align 8
  %cmp5849 = icmp eq i32 %v5848, 0
  %cv5850 = zext i1 %cmp5849 to i32
  store i32 %cv5850, ptr %slot995, align 8
  %v5851 = load i32, ptr %slot993, align 8
  %v5852 = load i32, ptr %slot995, align 8
  %op5853 = and i32 %v5851, %v5852
  store i32 %op5853, ptr %slot996, align 8
  %v5854 = load i32, ptr %slot996, align 8
  %cv5855 = zext i32 %v5854 to i64
  %cond5856 = icmp ne i64 %cv5855, 0
  br i1 %cond5856, label %bb_rcprivateown1339, label %bb_rcprivateloan1339
bb_rcprivateown1339:
  %v5857 = load i64, ptr %slot35, align 8
  store i64 %v5857, ptr %slot997, align 8
  %v5858 = load i64, ptr %slot65, align 8
  store i64 %v5858, ptr %slot998, align 8
  %v5859 = load i64, ptr %slot992, align 8
  %v5860 = load i64, ptr %slot997, align 8
  %op5861 = sub i64 %v5859, %v5860
  store i64 %op5861, ptr %slot999, align 8
  %v5862 = load i64, ptr %slot997, align 8
  %v5863 = load i64, ptr %slot992, align 8
  %op5864 = sub i64 %v5862, %v5863
  store i64 %op5864, ptr %slot1000, align 8
  %v5865 = load i64, ptr %slot999, align 8
  %cmp5866 = icmp ult i64 %v5865, 24
  %cv5867 = zext i1 %cmp5866 to i32
  store i32 %cv5867, ptr %slot1001, align 8
  %v5868 = load i64, ptr %slot1000, align 8
  %cmp5869 = icmp ult i64 %v5868, 24
  %cv5870 = zext i1 %cmp5869 to i32
  store i32 %cv5870, ptr %slot1002, align 8
  %v5871 = load i32, ptr %slot1001, align 8
  %v5872 = load i32, ptr %slot1002, align 8
  %op5873 = or i32 %v5871, %v5872
  store i32 %op5873, ptr %slot1003, align 8
  %v5874 = load i32, ptr %slot1003, align 8
  %cv5875 = zext i32 %v5874 to i64
  %cond5876 = icmp ne i64 %cv5875, 0
  br i1 %cond5876, label %bb_rcmoveslow1342, label %bb_rcmovecheck1342
bb_rcmovecheck1342:
  %v5877 = load i64, ptr %slot992, align 8
  %op5878 = add i64 %v5877, 8
  store i64 %op5878, ptr %slot1004, align 8
  %v5879 = load i64, ptr %slot1004, align 8
  %p5880 = inttoptr i64 %v5879 to ptr
  %ld5881 = load i64, ptr %p5880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5881, ptr %slot1005, align 8
  %v5882 = load i64, ptr %slot1005, align 8
  %cmp5883 = icmp ne i64 %v5882, 0
  %cv5884 = zext i1 %cmp5883 to i32
  store i32 %cv5884, ptr %slot1006, align 8
  %v5885 = load i32, ptr %slot1006, align 8
  %cv5886 = zext i32 %v5885 to i64
  %cond5887 = icmp ne i64 %cv5886, 0
  br i1 %cond5887, label %bb_rcmoveheader1350, label %bb_rcmovenext1350
bb_rcmoveheader1350:
  %v5888 = load i64, ptr %slot1005, align 8
  %op5889 = sub i64 %v5888, 16
  store i64 %op5889, ptr %slot1007, align 8
  %v5890 = load i64, ptr %slot1005, align 8
  %p5891 = inttoptr i64 %v5890 to ptr
  %rgep5892 = getelementptr i8, ptr %p5891, i64 -16
  %ld5893 = load i64, ptr %rgep5892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5893, ptr %slot1008, align 8
  %v5894 = load i64, ptr %slot1008, align 8
  %op5895 = and i64 %v5894, 5764607523034234881
  store i64 %op5895, ptr %slot1009, align 8
  %v5896 = load i64, ptr %slot1009, align 8
  %cmp5897 = icmp ne i64 %v5896, 0
  %cv5898 = zext i1 %cmp5897 to i32
  store i32 %cv5898, ptr %slot1010, align 8
  %v5899 = load i32, ptr %slot1010, align 8
  %cv5900 = zext i32 %v5899 to i64
  %cond5901 = icmp ne i64 %cv5900, 0
  br i1 %cond5901, label %bb_rcmoveslow1342, label %bb_rcmovenext1350
bb_rcmovenext1350:
  %v5902 = load i64, ptr %slot992, align 8
  %v5903 = load i64, ptr %slot997, align 8
  %p5904 = inttoptr i64 %v5902 to ptr
  %p5905 = inttoptr i64 %v5903 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5905, ptr %p5904, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5906 = load i64, ptr %slot992, align 8
  %p5907 = inttoptr i64 %v5906 to ptr
  store i64 0, ptr %p5907, align 8, !alias.scope !3, !noalias !4
  %v5908 = load i64, ptr %slot992, align 8
  %op5909 = add i64 %v5908, 8
  store i64 %op5909, ptr %slot1011, align 8
  %v5910 = load i64, ptr %slot1011, align 8
  %p5911 = inttoptr i64 %v5910 to ptr
  store i64 0, ptr %p5911, align 8, !alias.scope !3, !noalias !4
  %v5912 = load i64, ptr %slot992, align 8
  %op5913 = add i64 %v5912, 16
  store i64 %op5913, ptr %slot1012, align 8
  %v5914 = load i64, ptr %slot1012, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  store i64 0, ptr %p5915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1342
bb_rcmoveslow1342:
  %v5916 = load i64, ptr %slot64, align 8
  %v5917 = load i64, ptr %slot997, align 8
  %v5918 = load i64, ptr %slot992, align 8
  %v5919 = load i64, ptr %slot998, align 8
  %cv5920 = trunc i64 %v5919 to i32
  %call5921 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v5916, i64 %v5917, i64 %v5918, i32 %cv5920) nomerge, !dbg !166
  store i32 %call5921, ptr %slot1013, align 8
  %v5922 = load i32, ptr %slot1013, align 8
  %cv5923 = zext i32 %v5922 to i64
  %cond5924 = icmp ne i64 %cv5923, 0
  br i1 %cond5924, label %bb_rcsuccess1359, label %bb_rcfailure1359
bb_rcfailure1359:
  %v5925 = load i64, ptr %slot64, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %call5927 = call i32 @myl_rc_take_failure(ptr %p5926) nomerge, !dbg !166
  store i32 %call5927, ptr %slot1014, align 8
  %v5928 = load i64, ptr %slot1, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  %v5930 = load i32, ptr %slot1014, align 8
  %call5931 = call i32 @myl_qbe_rc_status(ptr %p5929, i32 %v5930) nomerge, !dbg !166
  store i32 %call5931, ptr %slot1015, align 8
  br label %bb_failure
bb_rcsuccess1359:
  br label %bb_rcmoved1342
bb_rcmoved1342:
  %v5932 = load i64, ptr %slot21, align 8
  %p5933 = inttoptr i64 %v5932 to ptr
  store i32 0, ptr %p5933, align 4, !alias.scope !3, !noalias !4
  %v5934 = load i64, ptr %slot28, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  store i32 2, ptr %p5935, align 4, !alias.scope !3, !noalias !4
  %v5936 = load i64, ptr %slot27, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  store i32 1, ptr %p5937, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1339
bb_rcprivateloan1339:
  %v5938 = load i64, ptr %slot35, align 8
  store i64 %v5938, ptr %slot1016, align 8
  %v5939 = load i64, ptr %slot64, align 8
  %v5940 = load i64, ptr %slot1016, align 8
  %v5941 = load i64, ptr %slot992, align 8
  %call5942 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64 %v5939, i64 %v5940, i64 %v5941) nomerge, !dbg !166
  store i32 %call5942, ptr %slot1017, align 8
  %v5943 = load i32, ptr %slot1017, align 8
  %cv5944 = zext i32 %v5943 to i64
  %cond5945 = icmp ne i64 %cv5944, 0
  br i1 %cond5945, label %bb_rcsuccess1367, label %bb_rcfailure1367
bb_rcfailure1367:
  %v5946 = load i64, ptr %slot64, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  %call5948 = call i32 @myl_rc_take_failure(ptr %p5947) nomerge, !dbg !166
  store i32 %call5948, ptr %slot1018, align 8
  %v5949 = load i64, ptr %slot1, align 8
  %p5950 = inttoptr i64 %v5949 to ptr
  %v5951 = load i32, ptr %slot1018, align 8
  %call5952 = call i32 @myl_qbe_rc_status(ptr %p5950, i32 %v5951) nomerge, !dbg !166
  store i32 %call5952, ptr %slot1019, align 8
  br label %bb_failure
bb_rcsuccess1367:
  %v5953 = load i64, ptr %slot28, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  store i32 2, ptr %p5954, align 4, !alias.scope !3, !noalias !4
  %v5955 = load i64, ptr %slot28, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  store i32 16, ptr %p5956, align 4, !alias.scope !3, !noalias !4
  %v5957 = load i64, ptr %slot27, align 8
  %p5958 = inttoptr i64 %v5957 to ptr
  store i32 1, ptr %p5958, align 4, !alias.scope !3, !noalias !4
  %v5959 = load i64, ptr %slot21, align 8
  %p5960 = inttoptr i64 %v5959 to ptr
  %ld5961 = load i32, ptr %p5960, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5961, ptr %slot1020, align 8
  %v5962 = load i32, ptr %slot1020, align 8
  %cv5963 = zext i32 %v5962 to i64
  %cond5964 = icmp ne i64 %cv5963, 0
  br i1 %cond5964, label %bb_rcslotdrop1375, label %bb_rcslotdone1375
bb_rcslotdrop1375:
  %v5965 = load i64, ptr %slot21, align 8
  %p5966 = inttoptr i64 %v5965 to ptr
  store i32 0, ptr %p5966, align 4, !alias.scope !3, !noalias !4
  %v5967 = load i64, ptr %slot30, align 8
  store i64 %v5967, ptr %slot1021, align 8
  %v5968 = load i64, ptr %slot22, align 8
  %p5969 = inttoptr i64 %v5968 to ptr
  %ld5970 = load i32, ptr %p5969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5970, ptr %slot1022, align 8
  %v5971 = load i32, ptr %slot1022, align 8
  %op5972 = and i32 %v5971, 28
  store i32 %op5972, ptr %slot1023, align 8
  %v5973 = load i32, ptr %slot1023, align 8
  %cv5974 = zext i32 %v5973 to i64
  %cond5975 = icmp ne i64 %cv5974, 0
  br i1 %cond5975, label %bb_rcslotrole1375, label %bb_rcslotowner1375
bb_rcslotrole1375:
  %v5976 = load i64, ptr %slot64, align 8
  store i64 %v5976, ptr %slot1024, align 8
  %v5977 = load i64, ptr %slot1024, align 8
  %v5978 = load i64, ptr %slot1021, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v5977, i64 %v5978) nomerge, !dbg !166
  br label %bb_rcslotdone1375
bb_rcslotowner1375:
  %v5979 = load i64, ptr %slot1021, align 8
  %p5981 = inttoptr i64 %v5979 to ptr
  %gep5982 = getelementptr i8, ptr %p5981, i64 8
  %op5980 = ptrtoint ptr %gep5982 to i64
  store i64 %op5980, ptr %slot1025, align 8
  %v5983 = load i64, ptr %slot64, align 8
  store i64 %v5983, ptr %slot1026, align 8
  %v5984 = load i64, ptr %slot1025, align 8
  %p5985 = inttoptr i64 %v5984 to ptr
  %ld5986 = load i64, ptr %p5985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5986, ptr %slot1027, align 8
  %v5987 = load i64, ptr %slot1027, align 8
  %cmp5988 = icmp ne i64 %v5987, 0
  %cv5989 = zext i1 %cmp5988 to i32
  store i32 %cv5989, ptr %slot1028, align 8
  %v5990 = load i32, ptr %slot1028, align 8
  %cv5991 = zext i32 %v5990 to i64
  %cond5992 = icmp ne i64 %cv5991, 0
  br i1 %cond5992, label %bb_rcgnn1393, label %bb_rcgdone1393
bb_rcgnn1393:
  %v5993 = load i64, ptr %slot1027, align 8
  %op5994 = sub i64 %v5993, 16
  store i64 %op5994, ptr %slot1029, align 8
  %v5995 = load i64, ptr %slot1027, align 8
  %p5996 = inttoptr i64 %v5995 to ptr
  %rgep5997 = getelementptr i8, ptr %p5996, i64 -16
  %ld5998 = load i64, ptr %rgep5997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5998, ptr %slot1030, align 8
  %v5999 = load i64, ptr %slot1030, align 8
  %op6000 = and i64 %v5999, 4611686018427387906
  store i64 %op6000, ptr %slot1031, align 8
  %v6001 = load i64, ptr %slot1031, align 8
  %cmp6002 = icmp ne i64 %v6001, 0
  %cv6003 = zext i1 %cmp6002 to i32
  store i32 %cv6003, ptr %slot1032, align 8
  %v6004 = load i32, ptr %slot1032, align 8
  %cv6005 = zext i32 %v6004 to i64
  %cond6006 = icmp ne i64 %cv6005, 0
  br i1 %cond6006, label %bb_rcgclear1393, label %bb_rcgcounted1393
bb_rcgcounted1393:
  %v6007 = load i64, ptr %slot1027, align 8
  %op6008 = sub i64 %v6007, 32
  store i64 %op6008, ptr %slot1033, align 8
  %v6009 = load i64, ptr %slot1027, align 8
  %p6010 = inttoptr i64 %v6009 to ptr
  %rgep6011 = getelementptr i8, ptr %p6010, i64 -32
  %ld6012 = load i64, ptr %rgep6011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6012, ptr %slot1034, align 8
  %v6013 = load i64, ptr %slot1034, align 8
  %op6014 = sub i64 %v6013, 1
  store i64 %op6014, ptr %slot1035, align 8
  %v6015 = load i64, ptr %slot1035, align 8
  %cmp6016 = icmp eq i64 %v6015, 0
  %cv6017 = zext i1 %cmp6016 to i32
  store i32 %cv6017, ptr %slot1036, align 8
  %v6018 = load i32, ptr %slot1036, align 8
  %cv6019 = zext i32 %v6018 to i64
  %cond6020 = icmp ne i64 %cv6019, 0
  br i1 %cond6020, label %bb_rcglast1393, label %bb_rcgdec1393
bb_rcglast1393:
  %v6021 = load i64, ptr %slot1027, align 8
  %op6022 = sub i64 %v6021, 24
  store i64 %op6022, ptr %slot1037, align 8
  %v6023 = load i64, ptr %slot1027, align 8
  %p6024 = inttoptr i64 %v6023 to ptr
  %rgep6025 = getelementptr i8, ptr %p6024, i64 -24
  %ld6026 = load i64, ptr %rgep6025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6026, ptr %slot1038, align 8
  %v6027 = load i64, ptr %slot1038, align 8
  %cmp6028 = icmp ne i64 %v6027, 0
  %cv6029 = zext i1 %cmp6028 to i32
  store i32 %cv6029, ptr %slot1039, align 8
  %v6030 = load i32, ptr %slot1039, align 8
  %cv6031 = zext i32 %v6030 to i64
  %cond6032 = icmp ne i64 %cv6031, 0
  br i1 %cond6032, label %bb_rcgdec1393, label %bb_rcgslow1393
bb_rcgslow1393:
  %v6033 = load i64, ptr %slot1026, align 8
  %v6034 = load i64, ptr %slot1025, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6033, i64 %v6034) nomerge, !dbg !166
  br label %bb_rcgdone1393
bb_rcgdec1393:
  %v6035 = load i64, ptr %slot1035, align 8
  %v6036 = load i64, ptr %slot1027, align 8
  %p6037 = inttoptr i64 %v6036 to ptr
  %rgep6038 = getelementptr i8, ptr %p6037, i64 -32
  store i64 %v6035, ptr %rgep6038, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1393
bb_rcgclear1393:
  %v6039 = load i64, ptr %slot1025, align 8
  %p6040 = inttoptr i64 %v6039 to ptr
  store i64 0, ptr %p6040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1393
bb_rcgdone1393:
  %v6041 = load i64, ptr %slot1021, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  store i64 0, ptr %p6042, align 8, !alias.scope !3, !noalias !4
  %v6043 = load i64, ptr %slot1021, align 8
  %p6045 = inttoptr i64 %v6043 to ptr
  %gep6046 = getelementptr i8, ptr %p6045, i64 8
  %op6044 = ptrtoint ptr %gep6046 to i64
  store i64 %op6044, ptr %slot1040, align 8
  %v6047 = load i64, ptr %slot1040, align 8
  %p6048 = inttoptr i64 %v6047 to ptr
  store i64 0, ptr %p6048, align 8, !alias.scope !3, !noalias !4
  %v6049 = load i64, ptr %slot1021, align 8
  %p6051 = inttoptr i64 %v6049 to ptr
  %gep6052 = getelementptr i8, ptr %p6051, i64 16
  %op6050 = ptrtoint ptr %gep6052 to i64
  store i64 %op6050, ptr %slot1041, align 8
  %v6053 = load i64, ptr %slot1041, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  store i64 0, ptr %p6054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1375
bb_rcslotdone1375:
  br label %bb_rcprivateprepared1339
bb_rcprivateprepared1339:
  %v6055 = load i64, ptr %slot15, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  %ld6057 = load i32, ptr %p6056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6057, ptr %slot1042, align 8
  %v6058 = load i32, ptr %slot1042, align 8
  %cv6059 = zext i32 %v6058 to i64
  %cond6060 = icmp ne i64 %cv6059, 0
  br i1 %cond6060, label %bb_rcslotdrop1402, label %bb_rcslotdone1402
bb_rcslotdrop1402:
  %v6061 = load i64, ptr %slot15, align 8
  %p6062 = inttoptr i64 %v6061 to ptr
  store i32 0, ptr %p6062, align 4, !alias.scope !3, !noalias !4
  %v6063 = load i64, ptr %slot48, align 8
  store i64 %v6063, ptr %slot1043, align 8
  %v6064 = load i64, ptr %slot16, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  %ld6066 = load i32, ptr %p6065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6066, ptr %slot1044, align 8
  %v6067 = load i32, ptr %slot1044, align 8
  %op6068 = and i32 %v6067, 28
  store i32 %op6068, ptr %slot1045, align 8
  %v6069 = load i32, ptr %slot1045, align 8
  %cv6070 = zext i32 %v6069 to i64
  %cond6071 = icmp ne i64 %cv6070, 0
  br i1 %cond6071, label %bb_rcslotrole1402, label %bb_rcslotowner1402
bb_rcslotrole1402:
  %v6072 = load i64, ptr %slot64, align 8
  store i64 %v6072, ptr %slot1046, align 8
  %v6073 = load i64, ptr %slot1046, align 8
  %v6074 = load i64, ptr %slot1043, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6073, i64 %v6074) nomerge, !dbg !166
  br label %bb_rcslotdone1402
bb_rcslotowner1402:
  %v6075 = load i64, ptr %slot1043, align 8
  %p6077 = inttoptr i64 %v6075 to ptr
  %gep6078 = getelementptr i8, ptr %p6077, i64 8
  %op6076 = ptrtoint ptr %gep6078 to i64
  store i64 %op6076, ptr %slot1047, align 8
  %v6079 = load i64, ptr %slot64, align 8
  store i64 %v6079, ptr %slot1048, align 8
  %v6080 = load i64, ptr %slot1047, align 8
  %p6081 = inttoptr i64 %v6080 to ptr
  %ld6082 = load i64, ptr %p6081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6082, ptr %slot1049, align 8
  %v6083 = load i64, ptr %slot1049, align 8
  %cmp6084 = icmp ne i64 %v6083, 0
  %cv6085 = zext i1 %cmp6084 to i32
  store i32 %cv6085, ptr %slot1050, align 8
  %v6086 = load i32, ptr %slot1050, align 8
  %cv6087 = zext i32 %v6086 to i64
  %cond6088 = icmp ne i64 %cv6087, 0
  br i1 %cond6088, label %bb_rcgnn1420, label %bb_rcgdone1420
bb_rcgnn1420:
  %v6089 = load i64, ptr %slot1049, align 8
  %op6090 = sub i64 %v6089, 16
  store i64 %op6090, ptr %slot1051, align 8
  %v6091 = load i64, ptr %slot1049, align 8
  %p6092 = inttoptr i64 %v6091 to ptr
  %rgep6093 = getelementptr i8, ptr %p6092, i64 -16
  %ld6094 = load i64, ptr %rgep6093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6094, ptr %slot1052, align 8
  %v6095 = load i64, ptr %slot1052, align 8
  %op6096 = and i64 %v6095, 4611686018427387906
  store i64 %op6096, ptr %slot1053, align 8
  %v6097 = load i64, ptr %slot1053, align 8
  %cmp6098 = icmp ne i64 %v6097, 0
  %cv6099 = zext i1 %cmp6098 to i32
  store i32 %cv6099, ptr %slot1054, align 8
  %v6100 = load i32, ptr %slot1054, align 8
  %cv6101 = zext i32 %v6100 to i64
  %cond6102 = icmp ne i64 %cv6101, 0
  br i1 %cond6102, label %bb_rcgclear1420, label %bb_rcgcounted1420
bb_rcgcounted1420:
  %v6103 = load i64, ptr %slot1049, align 8
  %op6104 = sub i64 %v6103, 32
  store i64 %op6104, ptr %slot1055, align 8
  %v6105 = load i64, ptr %slot1049, align 8
  %p6106 = inttoptr i64 %v6105 to ptr
  %rgep6107 = getelementptr i8, ptr %p6106, i64 -32
  %ld6108 = load i64, ptr %rgep6107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6108, ptr %slot1056, align 8
  %v6109 = load i64, ptr %slot1056, align 8
  %op6110 = sub i64 %v6109, 1
  store i64 %op6110, ptr %slot1057, align 8
  %v6111 = load i64, ptr %slot1057, align 8
  %cmp6112 = icmp eq i64 %v6111, 0
  %cv6113 = zext i1 %cmp6112 to i32
  store i32 %cv6113, ptr %slot1058, align 8
  %v6114 = load i32, ptr %slot1058, align 8
  %cv6115 = zext i32 %v6114 to i64
  %cond6116 = icmp ne i64 %cv6115, 0
  br i1 %cond6116, label %bb_rcglast1420, label %bb_rcgdec1420
bb_rcglast1420:
  %v6117 = load i64, ptr %slot1049, align 8
  %op6118 = sub i64 %v6117, 24
  store i64 %op6118, ptr %slot1059, align 8
  %v6119 = load i64, ptr %slot1049, align 8
  %p6120 = inttoptr i64 %v6119 to ptr
  %rgep6121 = getelementptr i8, ptr %p6120, i64 -24
  %ld6122 = load i64, ptr %rgep6121, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6122, ptr %slot1060, align 8
  %v6123 = load i64, ptr %slot1060, align 8
  %cmp6124 = icmp ne i64 %v6123, 0
  %cv6125 = zext i1 %cmp6124 to i32
  store i32 %cv6125, ptr %slot1061, align 8
  %v6126 = load i32, ptr %slot1061, align 8
  %cv6127 = zext i32 %v6126 to i64
  %cond6128 = icmp ne i64 %cv6127, 0
  br i1 %cond6128, label %bb_rcgdec1420, label %bb_rcgslow1420
bb_rcgslow1420:
  %v6129 = load i64, ptr %slot1048, align 8
  %v6130 = load i64, ptr %slot1047, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6129, i64 %v6130) nomerge, !dbg !166
  br label %bb_rcgdone1420
bb_rcgdec1420:
  %v6131 = load i64, ptr %slot1057, align 8
  %v6132 = load i64, ptr %slot1049, align 8
  %p6133 = inttoptr i64 %v6132 to ptr
  %rgep6134 = getelementptr i8, ptr %p6133, i64 -32
  store i64 %v6131, ptr %rgep6134, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1420
bb_rcgclear1420:
  %v6135 = load i64, ptr %slot1047, align 8
  %p6136 = inttoptr i64 %v6135 to ptr
  store i64 0, ptr %p6136, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1420
bb_rcgdone1420:
  %v6137 = load i64, ptr %slot1043, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  store i64 0, ptr %p6138, align 8, !alias.scope !3, !noalias !4
  %v6139 = load i64, ptr %slot1043, align 8
  %p6141 = inttoptr i64 %v6139 to ptr
  %gep6142 = getelementptr i8, ptr %p6141, i64 8
  %op6140 = ptrtoint ptr %gep6142 to i64
  store i64 %op6140, ptr %slot1062, align 8
  %v6143 = load i64, ptr %slot1062, align 8
  %p6144 = inttoptr i64 %v6143 to ptr
  store i64 0, ptr %p6144, align 8, !alias.scope !3, !noalias !4
  %v6145 = load i64, ptr %slot1043, align 8
  %p6147 = inttoptr i64 %v6145 to ptr
  %gep6148 = getelementptr i8, ptr %p6147, i64 16
  %op6146 = ptrtoint ptr %gep6148 to i64
  store i64 %op6146, ptr %slot1063, align 8
  %v6149 = load i64, ptr %slot1063, align 8
  %p6150 = inttoptr i64 %v6149 to ptr
  store i64 0, ptr %p6150, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1402
bb_rcslotdone1402:
  %v6151 = load i64, ptr %slot48, align 8
  store i64 %v6151, ptr %slot1064, align 8
  %v6152 = load i64, ptr %slot35, align 8
  store i64 %v6152, ptr %slot1065, align 8
  %v6153 = load i64, ptr %slot1065, align 8
  %v6154 = load i64, ptr %slot1064, align 8
  %p6155 = inttoptr i64 %v6153 to ptr
  %p6156 = inttoptr i64 %v6154 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6156, ptr %p6155, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6157 = load i64, ptr %slot27, align 8
  %p6158 = inttoptr i64 %v6157 to ptr
  store i32 0, ptr %p6158, align 4, !alias.scope !3, !noalias !4
  %v6159 = load i64, ptr %slot16, align 8
  %p6160 = inttoptr i64 %v6159 to ptr
  store i32 2, ptr %p6160, align 4, !alias.scope !3, !noalias !4
  %v6161 = load i64, ptr %slot28, align 8
  %p6162 = inttoptr i64 %v6161 to ptr
  %ld6163 = load i32, ptr %p6162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6163, ptr %slot1066, align 8
  %v6164 = load i32, ptr %slot1066, align 8
  %v6165 = load i64, ptr %slot16, align 8
  %p6166 = inttoptr i64 %v6165 to ptr
  store i32 %v6164, ptr %p6166, align 4, !alias.scope !3, !noalias !4
  %v6167 = load i64, ptr %slot15, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  store i32 1, ptr %p6168, align 4, !alias.scope !3, !noalias !4
  %v6169 = load i64, ptr %slot48, align 8
  %v6170 = load i64, ptr %slot53, align 8
  %p6171 = inttoptr i64 %v6170 to ptr
  store i64 %v6169, ptr %p6171, align 8, !alias.scope !3, !noalias !4
  %v6172 = load i64, ptr %slot49, align 8
  %v6173 = load i64, ptr %slot54, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  store i64 %v6172, ptr %p6174, align 8, !alias.scope !3, !noalias !4
  %v6175 = load i64, ptr %slot54, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  %ld6177 = load i64, ptr %p6176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6177, ptr %slot1067, align 8
  %v6178 = load i64, ptr %slot23, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i32, ptr %p6179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6180, ptr %slot1068, align 8
  %v6181 = load i64, ptr %slot24, align 8
  %p6182 = inttoptr i64 %v6181 to ptr
  %ld6183 = load i32, ptr %p6182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6183, ptr %slot1069, align 8
  %v6184 = load i32, ptr %slot1069, align 8
  %op6185 = and i32 %v6184, 24
  store i32 %op6185, ptr %slot1069, align 8
  %v6186 = load i32, ptr %slot1069, align 8
  %cmp6187 = icmp eq i32 %v6186, 0
  %cv6188 = zext i1 %cmp6187 to i32
  store i32 %cv6188, ptr %slot1070, align 8
  %v6189 = load i32, ptr %slot1068, align 8
  %v6190 = load i32, ptr %slot1070, align 8
  %op6191 = and i32 %v6189, %v6190
  store i32 %op6191, ptr %slot1071, align 8
  %v6192 = load i64, ptr %slot65, align 8
  store i64 %v6192, ptr %slot1072, align 8
  %v6193 = load i32, ptr %slot1071, align 8
  %op6194 = mul i32 %v6193, 4
  store i32 %op6194, ptr %slot1073, align 8
  %v6195 = load i32, ptr %slot1073, align 8
  %op6196 = or i32 %v6195, 0
  store i32 %op6196, ptr %slot1074, align 8
  %v6197 = load i64, ptr %slot35, align 8
  store i64 %v6197, ptr %slot1075, align 8
  %v6198 = load i64, ptr %slot64, align 8
  %v6199 = load i64, ptr %slot1075, align 8
  %v6200 = load i64, ptr %slot1067, align 8
  %v6201 = load i64, ptr %slot1072, align 8
  %cv6202 = trunc i64 %v6201 to i32
  %v6203 = load i32, ptr %slot1074, align 8
  %call6204 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64 %v6198, i64 %v6199, i64 %v6200, i32 %cv6202, i32 %v6203) nomerge, !dbg !168
  store i32 %call6204, ptr %slot1076, align 8
  %v6205 = load i32, ptr %slot1076, align 8
  %cv6206 = zext i32 %v6205 to i64
  %cond6207 = icmp ne i64 %cv6206, 0
  br i1 %cond6207, label %bb_rcsuccess1447, label %bb_rcfailure1447
bb_rcfailure1447:
  %v6208 = load i64, ptr %slot64, align 8
  %p6209 = inttoptr i64 %v6208 to ptr
  %call6210 = call i32 @myl_rc_take_failure(ptr %p6209) nomerge, !dbg !168
  store i32 %call6210, ptr %slot1077, align 8
  %v6211 = load i64, ptr %slot1, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %v6213 = load i32, ptr %slot1077, align 8
  %call6214 = call i32 @myl_qbe_rc_status(ptr %p6212, i32 %v6213) nomerge, !dbg !168
  store i32 %call6214, ptr %slot1078, align 8
  br label %bb_failure
bb_rcsuccess1447:
  %v6215 = load i32, ptr %slot1071, align 8
  %cv6216 = zext i32 %v6215 to i64
  %cond6217 = icmp ne i64 %cv6216, 0
  br i1 %cond6217, label %bb_rchtaken1450, label %bb_rchcopied1450
bb_rchcopied1450:
  %v6218 = load i64, ptr %slot23, align 8
  %p6219 = inttoptr i64 %v6218 to ptr
  %ld6220 = load i32, ptr %p6219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6220, ptr %slot1079, align 8
  %v6221 = load i32, ptr %slot1079, align 8
  %cv6222 = zext i32 %v6221 to i64
  %cond6223 = icmp ne i64 %cv6222, 0
  br i1 %cond6223, label %bb_rcslotdrop1453, label %bb_rcslotdone1453
bb_rcslotdrop1453:
  %v6224 = load i64, ptr %slot23, align 8
  %p6225 = inttoptr i64 %v6224 to ptr
  store i32 0, ptr %p6225, align 4, !alias.scope !3, !noalias !4
  %v6226 = load i64, ptr %slot31, align 8
  store i64 %v6226, ptr %slot1080, align 8
  %v6227 = load i64, ptr %slot24, align 8
  %p6228 = inttoptr i64 %v6227 to ptr
  %ld6229 = load i32, ptr %p6228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6229, ptr %slot1081, align 8
  %v6230 = load i32, ptr %slot1081, align 8
  %op6231 = and i32 %v6230, 28
  store i32 %op6231, ptr %slot1082, align 8
  %v6232 = load i32, ptr %slot1082, align 8
  %cv6233 = zext i32 %v6232 to i64
  %cond6234 = icmp ne i64 %cv6233, 0
  br i1 %cond6234, label %bb_rcslotrole1453, label %bb_rcslotowner1453
bb_rcslotrole1453:
  %v6235 = load i64, ptr %slot64, align 8
  store i64 %v6235, ptr %slot1083, align 8
  %v6236 = load i64, ptr %slot1083, align 8
  %v6237 = load i64, ptr %slot1080, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v6236, i64 %v6237) nomerge, !dbg !168
  br label %bb_rcslotdone1453
bb_rcslotowner1453:
  %v6238 = load i64, ptr %slot64, align 8
  store i64 %v6238, ptr %slot1084, align 8
  %v6239 = load i64, ptr %slot1084, align 8
  %v6240 = load i64, ptr %slot1080, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v6239, i64 %v6240) nomerge, !dbg !168
  br label %bb_rcslotdone1453
bb_rcslotdone1453:
  br label %bb_rchprepared1450
bb_rchtaken1450:
  %v6241 = load i64, ptr %slot23, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  store i32 0, ptr %p6242, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1450
bb_rchprepared1450:
  %v6243 = load i64, ptr %slot28, align 8
  %p6244 = inttoptr i64 %v6243 to ptr
  store i32 2, ptr %p6244, align 4, !alias.scope !3, !noalias !4
  %v6245 = load i64, ptr %slot27, align 8
  %p6246 = inttoptr i64 %v6245 to ptr
  store i32 1, ptr %p6246, align 4, !alias.scope !3, !noalias !4
  %v6247 = load i64, ptr %slot31, align 8
  store i64 %v6247, ptr %slot1085, align 8
  %v6248 = load i64, ptr %slot35, align 8
  store i64 %v6248, ptr %slot1086, align 8
  %v6249 = load i64, ptr %slot1086, align 8
  %v6250 = load i64, ptr %slot1085, align 8
  %p6251 = inttoptr i64 %v6249 to ptr
  %p6252 = inttoptr i64 %v6250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6252, ptr %p6251, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6253 = load i64, ptr %slot24, align 8
  %p6254 = inttoptr i64 %v6253 to ptr
  store i32 2, ptr %p6254, align 4, !alias.scope !3, !noalias !4
  %v6255 = load i64, ptr %slot28, align 8
  %p6256 = inttoptr i64 %v6255 to ptr
  %ld6257 = load i32, ptr %p6256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6257, ptr %slot1087, align 8
  %v6258 = load i32, ptr %slot1087, align 8
  %v6259 = load i64, ptr %slot24, align 8
  %p6260 = inttoptr i64 %v6259 to ptr
  store i32 %v6258, ptr %p6260, align 4, !alias.scope !3, !noalias !4
  %v6261 = load i64, ptr %slot27, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  store i32 0, ptr %p6262, align 4, !alias.scope !3, !noalias !4
  %v6263 = load i64, ptr %slot23, align 8
  %p6264 = inttoptr i64 %v6263 to ptr
  store i32 1, ptr %p6264, align 4, !alias.scope !3, !noalias !4
  %v6265 = load i64, ptr %slot1085, align 8
  %v6266 = load i64, ptr %slot54, align 8
  %p6267 = inttoptr i64 %v6266 to ptr
  store i64 %v6265, ptr %p6267, align 8, !alias.scope !3, !noalias !4
  %v6268 = load i64, ptr %slot53, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  %ld6270 = load i64, ptr %p6269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6270, ptr %slot1088, align 8
  %v6271 = load i64, ptr %slot21, align 8
  %p6272 = inttoptr i64 %v6271 to ptr
  %ld6273 = load i32, ptr %p6272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6273, ptr %slot1089, align 8
  %v6274 = load i64, ptr %slot22, align 8
  %p6275 = inttoptr i64 %v6274 to ptr
  %ld6276 = load i32, ptr %p6275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6276, ptr %slot1090, align 8
  %v6277 = load i32, ptr %slot1090, align 8
  %op6278 = and i32 %v6277, 24
  store i32 %op6278, ptr %slot1090, align 8
  %v6279 = load i32, ptr %slot1090, align 8
  %cmp6280 = icmp eq i32 %v6279, 0
  %cv6281 = zext i1 %cmp6280 to i32
  store i32 %cv6281, ptr %slot1091, align 8
  %v6282 = load i32, ptr %slot1089, align 8
  %v6283 = load i32, ptr %slot1091, align 8
  %op6284 = and i32 %v6282, %v6283
  store i32 %op6284, ptr %slot1092, align 8
  %v6285 = load i32, ptr %slot1092, align 8
  %cv6286 = zext i32 %v6285 to i64
  %cond6287 = icmp ne i64 %cv6286, 0
  br i1 %cond6287, label %bb_rctake1472, label %bb_rccopy1472
bb_rctake1472:
  %v6288 = load i64, ptr %slot35, align 8
  store i64 %v6288, ptr %slot1093, align 8
  %v6289 = load i64, ptr %slot65, align 8
  store i64 %v6289, ptr %slot1094, align 8
  %v6290 = load i64, ptr %slot1088, align 8
  %v6291 = load i64, ptr %slot1093, align 8
  %op6292 = sub i64 %v6290, %v6291
  store i64 %op6292, ptr %slot1095, align 8
  %v6293 = load i64, ptr %slot1093, align 8
  %v6294 = load i64, ptr %slot1088, align 8
  %op6295 = sub i64 %v6293, %v6294
  store i64 %op6295, ptr %slot1096, align 8
  %v6296 = load i64, ptr %slot1095, align 8
  %cmp6297 = icmp ult i64 %v6296, 24
  %cv6298 = zext i1 %cmp6297 to i32
  store i32 %cv6298, ptr %slot1097, align 8
  %v6299 = load i64, ptr %slot1096, align 8
  %cmp6300 = icmp ult i64 %v6299, 24
  %cv6301 = zext i1 %cmp6300 to i32
  store i32 %cv6301, ptr %slot1098, align 8
  %v6302 = load i32, ptr %slot1097, align 8
  %v6303 = load i32, ptr %slot1098, align 8
  %op6304 = or i32 %v6302, %v6303
  store i32 %op6304, ptr %slot1099, align 8
  %v6305 = load i32, ptr %slot1099, align 8
  %cv6306 = zext i32 %v6305 to i64
  %cond6307 = icmp ne i64 %cv6306, 0
  br i1 %cond6307, label %bb_rcmoveslow1481, label %bb_rcmovecheck1481
bb_rcmovecheck1481:
  %v6308 = load i64, ptr %slot1088, align 8
  %op6309 = add i64 %v6308, 8
  store i64 %op6309, ptr %slot1100, align 8
  %v6310 = load i64, ptr %slot1100, align 8
  %p6311 = inttoptr i64 %v6310 to ptr
  %ld6312 = load i64, ptr %p6311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6312, ptr %slot1101, align 8
  %v6313 = load i64, ptr %slot1101, align 8
  %cmp6314 = icmp ne i64 %v6313, 0
  %cv6315 = zext i1 %cmp6314 to i32
  store i32 %cv6315, ptr %slot1102, align 8
  %v6316 = load i32, ptr %slot1102, align 8
  %cv6317 = zext i32 %v6316 to i64
  %cond6318 = icmp ne i64 %cv6317, 0
  br i1 %cond6318, label %bb_rcmoveheader1489, label %bb_rcmovenext1489
bb_rcmoveheader1489:
  %v6319 = load i64, ptr %slot1101, align 8
  %op6320 = sub i64 %v6319, 16
  store i64 %op6320, ptr %slot1103, align 8
  %v6321 = load i64, ptr %slot1101, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  %rgep6323 = getelementptr i8, ptr %p6322, i64 -16
  %ld6324 = load i64, ptr %rgep6323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6324, ptr %slot1104, align 8
  %v6325 = load i64, ptr %slot1104, align 8
  %op6326 = and i64 %v6325, 5764607523034234881
  store i64 %op6326, ptr %slot1105, align 8
  %v6327 = load i64, ptr %slot1105, align 8
  %cmp6328 = icmp ne i64 %v6327, 0
  %cv6329 = zext i1 %cmp6328 to i32
  store i32 %cv6329, ptr %slot1106, align 8
  %v6330 = load i32, ptr %slot1106, align 8
  %cv6331 = zext i32 %v6330 to i64
  %cond6332 = icmp ne i64 %cv6331, 0
  br i1 %cond6332, label %bb_rcmoveslow1481, label %bb_rcmovenext1489
bb_rcmovenext1489:
  %v6333 = load i64, ptr %slot1088, align 8
  %v6334 = load i64, ptr %slot1093, align 8
  %p6335 = inttoptr i64 %v6333 to ptr
  %p6336 = inttoptr i64 %v6334 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6336, ptr %p6335, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6337 = load i64, ptr %slot1088, align 8
  %p6338 = inttoptr i64 %v6337 to ptr
  store i64 0, ptr %p6338, align 8, !alias.scope !3, !noalias !4
  %v6339 = load i64, ptr %slot1088, align 8
  %op6340 = add i64 %v6339, 8
  store i64 %op6340, ptr %slot1107, align 8
  %v6341 = load i64, ptr %slot1107, align 8
  %p6342 = inttoptr i64 %v6341 to ptr
  store i64 0, ptr %p6342, align 8, !alias.scope !3, !noalias !4
  %v6343 = load i64, ptr %slot1088, align 8
  %op6344 = add i64 %v6343, 16
  store i64 %op6344, ptr %slot1108, align 8
  %v6345 = load i64, ptr %slot1108, align 8
  %p6346 = inttoptr i64 %v6345 to ptr
  store i64 0, ptr %p6346, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1481
bb_rcmoveslow1481:
  %v6347 = load i64, ptr %slot64, align 8
  %v6348 = load i64, ptr %slot1093, align 8
  %v6349 = load i64, ptr %slot1088, align 8
  %v6350 = load i64, ptr %slot1094, align 8
  %cv6351 = trunc i64 %v6350 to i32
  %call6352 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v6347, i64 %v6348, i64 %v6349, i32 %cv6351) nomerge, !dbg !170
  store i32 %call6352, ptr %slot1109, align 8
  %v6353 = load i32, ptr %slot1109, align 8
  %cv6354 = zext i32 %v6353 to i64
  %cond6355 = icmp ne i64 %cv6354, 0
  br i1 %cond6355, label %bb_rcsuccess1498, label %bb_rcfailure1498
bb_rcfailure1498:
  %v6356 = load i64, ptr %slot64, align 8
  %p6357 = inttoptr i64 %v6356 to ptr
  %call6358 = call i32 @myl_rc_take_failure(ptr %p6357) nomerge, !dbg !170
  store i32 %call6358, ptr %slot1110, align 8
  %v6359 = load i64, ptr %slot1, align 8
  %p6360 = inttoptr i64 %v6359 to ptr
  %v6361 = load i32, ptr %slot1110, align 8
  %call6362 = call i32 @myl_qbe_rc_status(ptr %p6360, i32 %v6361) nomerge, !dbg !170
  store i32 %call6362, ptr %slot1111, align 8
  br label %bb_failure
bb_rcsuccess1498:
  br label %bb_rcmoved1481
bb_rcmoved1481:
  %v6363 = load i64, ptr %slot21, align 8
  %p6364 = inttoptr i64 %v6363 to ptr
  store i32 0, ptr %p6364, align 4, !alias.scope !3, !noalias !4
  %v6365 = load i64, ptr %slot28, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  store i32 2, ptr %p6366, align 4, !alias.scope !3, !noalias !4
  %v6367 = load i64, ptr %slot27, align 8
  %p6368 = inttoptr i64 %v6367 to ptr
  store i32 1, ptr %p6368, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1472
bb_rccopy1472:
  %v6369 = load i64, ptr %slot35, align 8
  store i64 %v6369, ptr %slot1112, align 8
  %v6370 = load i64, ptr %slot65, align 8
  store i64 %v6370, ptr %slot1113, align 8
  %v6371 = load i64, ptr %slot64, align 8
  %v6372 = load i64, ptr %slot1112, align 8
  %v6373 = load i64, ptr %slot1088, align 8
  %v6374 = load i64, ptr %slot1113, align 8
  %cv6375 = trunc i64 %v6374 to i32
  %call6376 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v6371, i64 %v6372, i64 %v6373, i32 %cv6375) nomerge, !dbg !170
  store i32 %call6376, ptr %slot1114, align 8
  %v6377 = load i32, ptr %slot1114, align 8
  %cv6378 = zext i32 %v6377 to i64
  %cond6379 = icmp ne i64 %cv6378, 0
  br i1 %cond6379, label %bb_rcsuccess1507, label %bb_rcfailure1507
bb_rcfailure1507:
  %v6380 = load i64, ptr %slot64, align 8
  %p6381 = inttoptr i64 %v6380 to ptr
  %call6382 = call i32 @myl_rc_take_failure(ptr %p6381) nomerge, !dbg !170
  store i32 %call6382, ptr %slot1115, align 8
  %v6383 = load i64, ptr %slot1, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  %v6385 = load i32, ptr %slot1115, align 8
  %call6386 = call i32 @myl_qbe_rc_status(ptr %p6384, i32 %v6385) nomerge, !dbg !170
  store i32 %call6386, ptr %slot1116, align 8
  br label %bb_failure
bb_rcsuccess1507:
  %v6387 = load i64, ptr %slot28, align 8
  %p6388 = inttoptr i64 %v6387 to ptr
  store i32 2, ptr %p6388, align 4, !alias.scope !3, !noalias !4
  %v6389 = load i64, ptr %slot27, align 8
  %p6390 = inttoptr i64 %v6389 to ptr
  store i32 1, ptr %p6390, align 4, !alias.scope !3, !noalias !4
  %v6391 = load i64, ptr %slot21, align 8
  %p6392 = inttoptr i64 %v6391 to ptr
  %ld6393 = load i32, ptr %p6392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6393, ptr %slot1117, align 8
  %v6394 = load i32, ptr %slot1117, align 8
  %cv6395 = zext i32 %v6394 to i64
  %cond6396 = icmp ne i64 %cv6395, 0
  br i1 %cond6396, label %bb_rcslotdrop1514, label %bb_rcslotdone1514
bb_rcslotdrop1514:
  %v6397 = load i64, ptr %slot21, align 8
  %p6398 = inttoptr i64 %v6397 to ptr
  store i32 0, ptr %p6398, align 4, !alias.scope !3, !noalias !4
  %v6399 = load i64, ptr %slot30, align 8
  store i64 %v6399, ptr %slot1118, align 8
  %v6400 = load i64, ptr %slot22, align 8
  %p6401 = inttoptr i64 %v6400 to ptr
  %ld6402 = load i32, ptr %p6401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6402, ptr %slot1119, align 8
  %v6403 = load i32, ptr %slot1119, align 8
  %op6404 = and i32 %v6403, 28
  store i32 %op6404, ptr %slot1120, align 8
  %v6405 = load i32, ptr %slot1120, align 8
  %cv6406 = zext i32 %v6405 to i64
  %cond6407 = icmp ne i64 %cv6406, 0
  br i1 %cond6407, label %bb_rcslotrole1514, label %bb_rcslotowner1514
bb_rcslotrole1514:
  %v6408 = load i64, ptr %slot64, align 8
  store i64 %v6408, ptr %slot1121, align 8
  %v6409 = load i64, ptr %slot1121, align 8
  %v6410 = load i64, ptr %slot1118, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6409, i64 %v6410) nomerge, !dbg !170
  br label %bb_rcslotdone1514
bb_rcslotowner1514:
  %v6411 = load i64, ptr %slot64, align 8
  store i64 %v6411, ptr %slot1122, align 8
  %v6412 = load i64, ptr %slot1122, align 8
  %v6413 = load i64, ptr %slot1118, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v6412, i64 %v6413) nomerge, !dbg !170
  br label %bb_rcslotdone1514
bb_rcslotdone1514:
  br label %bb_rcprepared1472
bb_rcprepared1472:
  %v6414 = load i64, ptr %slot35, align 8
  store i64 %v6414, ptr %slot1123, align 8
  %v6415 = load i64, ptr %slot57, align 8
  store i64 %v6415, ptr %slot1124, align 8
  %v6416 = load i64, ptr %slot1123, align 8
  %v6417 = load i64, ptr %slot1124, align 8
  %p6418 = inttoptr i64 %v6416 to ptr
  %p6419 = inttoptr i64 %v6417 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6419, ptr %p6418, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6420 = load i64, ptr %slot27, align 8
  %p6421 = inttoptr i64 %v6420 to ptr
  store i32 0, ptr %p6421, align 4, !alias.scope !3, !noalias !4
  %v6422 = load i64, ptr %slot29, align 8
  %p6423 = inttoptr i64 %v6422 to ptr
  store i32 1, ptr %p6423, align 4, !alias.scope !3, !noalias !4
  %v6424 = load i64, ptr %slot65, align 8
  store i64 %v6424, ptr %slot1125, align 8
  %v6425 = load i64, ptr %slot54, align 8
  %p6426 = inttoptr i64 %v6425 to ptr
  %ld6427 = load i64, ptr %p6426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6427, ptr %slot1126, align 8
  %v6428 = load i64, ptr %slot1124, align 8
  %p6430 = inttoptr i64 %v6428 to ptr
  %gep6431 = getelementptr i8, ptr %p6430, i64 8
  %op6429 = ptrtoint ptr %gep6431 to i64
  store i64 %op6429, ptr %slot1127, align 8
  %v6432 = load i64, ptr %slot35, align 8
  store i64 %v6432, ptr %slot1128, align 8
  %v6433 = load i64, ptr %slot54, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  %ld6435 = load i64, ptr %p6434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6435, ptr %slot1129, align 8
  %v6436 = load i64, ptr %slot35, align 8
  store i64 %v6436, ptr %slot1130, align 8
  %v6437 = load i64, ptr %slot65, align 8
  store i64 %v6437, ptr %slot1131, align 8
  %v6438 = load i64, ptr %slot1129, align 8
  %op6439 = add i64 %v6438, 0
  store i64 %op6439, ptr %slot1132, align 8
  %v6440 = load i64, ptr %slot1132, align 8
  %p6441 = inttoptr i64 %v6440 to ptr
  %ld6442 = load i64, ptr %p6441, align 8
  store i64 %ld6442, ptr %slot1133, align 8
  %v6443 = load i64, ptr %slot1133, align 8
  %cmp6444 = icmp ne i64 %v6443, 0
  %cv6445 = zext i1 %cmp6444 to i32
  store i32 %cv6445, ptr %slot1134, align 8
  %v6446 = load i32, ptr %slot1134, align 8
  %cv6447 = zext i32 %v6446 to i64
  %cond6448 = icmp ne i64 %cv6447, 0
  br i1 %cond6448, label %bb_rcmoveheader1536, label %bb_rcmovenext1536
bb_rcmoveheader1536:
  %v6449 = load i64, ptr %slot1133, align 8
  %op6450 = sub i64 %v6449, 16
  store i64 %op6450, ptr %slot1135, align 8
  %v6451 = load i64, ptr %slot1133, align 8
  %p6452 = inttoptr i64 %v6451 to ptr
  %rgep6453 = getelementptr i8, ptr %p6452, i64 -16
  %ld6454 = load i64, ptr %rgep6453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6454, ptr %slot1136, align 8
  %v6455 = load i64, ptr %slot1136, align 8
  %op6456 = and i64 %v6455, 5764607523034234881
  store i64 %op6456, ptr %slot1137, align 8
  %v6457 = load i64, ptr %slot1137, align 8
  %cmp6458 = icmp ne i64 %v6457, 0
  %cv6459 = zext i1 %cmp6458 to i32
  store i32 %cv6459, ptr %slot1138, align 8
  %v6460 = load i32, ptr %slot1138, align 8
  %cv6461 = zext i32 %v6460 to i64
  %cond6462 = icmp ne i64 %cv6461, 0
  br i1 %cond6462, label %bb_rcmoveslow1533, label %bb_rcmovenext1536
bb_rcmovenext1536:
  %v6463 = load i64, ptr %slot1129, align 8
  %v6464 = load i64, ptr %slot1130, align 8
  %p6465 = inttoptr i64 %v6463 to ptr
  %p6466 = inttoptr i64 %v6464 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6466, ptr %p6465, i64 16, i1 false)
  %v6467 = load i64, ptr %slot1129, align 8
  %p6468 = inttoptr i64 %v6467 to ptr
  store i64 0, ptr %p6468, align 8
  %v6469 = load i64, ptr %slot1129, align 8
  %op6470 = add i64 %v6469, 8
  store i64 %op6470, ptr %slot1139, align 8
  %v6471 = load i64, ptr %slot1139, align 8
  %p6472 = inttoptr i64 %v6471 to ptr
  store i64 0, ptr %p6472, align 8
  br label %bb_rcmoved1533
bb_rcmoveslow1533:
  %v6473 = load i64, ptr %slot64, align 8
  %v6474 = load i64, ptr %slot1130, align 8
  %v6475 = load i64, ptr %slot1129, align 8
  %v6476 = load i64, ptr %slot1131, align 8
  %cv6477 = trunc i64 %v6476 to i32
  %call6478 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v6473, i64 %v6474, i64 %v6475, i32 %cv6477) nomerge, !dbg !170
  store i32 %call6478, ptr %slot1140, align 8
  %v6479 = load i32, ptr %slot1140, align 8
  %cv6480 = zext i32 %v6479 to i64
  %cond6481 = icmp ne i64 %cv6480, 0
  br i1 %cond6481, label %bb_rcsuccess1544, label %bb_rcfailure1544
bb_rcfailure1544:
  %v6482 = load i64, ptr %slot64, align 8
  %p6483 = inttoptr i64 %v6482 to ptr
  %call6484 = call i32 @myl_rc_take_failure(ptr %p6483) nomerge, !dbg !170
  store i32 %call6484, ptr %slot1141, align 8
  %v6485 = load i64, ptr %slot1, align 8
  %p6486 = inttoptr i64 %v6485 to ptr
  %v6487 = load i32, ptr %slot1141, align 8
  %call6488 = call i32 @myl_qbe_rc_status(ptr %p6486, i32 %v6487) nomerge, !dbg !170
  store i32 %call6488, ptr %slot1142, align 8
  br label %bb_failure
bb_rcsuccess1544:
  br label %bb_rcmoved1533
bb_rcmoved1533:
  %v6489 = load i64, ptr %slot23, align 8
  %p6490 = inttoptr i64 %v6489 to ptr
  store i32 0, ptr %p6490, align 4, !alias.scope !3, !noalias !4
  %v6491 = load i64, ptr %slot28, align 8
  %p6492 = inttoptr i64 %v6491 to ptr
  store i32 2, ptr %p6492, align 4, !alias.scope !3, !noalias !4
  %v6493 = load i64, ptr %slot27, align 8
  %p6494 = inttoptr i64 %v6493 to ptr
  store i32 1, ptr %p6494, align 4, !alias.scope !3, !noalias !4
  %v6495 = load i64, ptr %slot35, align 8
  store i64 %v6495, ptr %slot1143, align 8
  %v6496 = load i64, ptr %slot1143, align 8
  %v6497 = load i64, ptr %slot1128, align 8
  %p6498 = inttoptr i64 %v6496 to ptr
  %p6499 = inttoptr i64 %v6497 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6499, ptr %p6498, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6500 = load i64, ptr %slot27, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  store i32 0, ptr %p6501, align 4, !alias.scope !3, !noalias !4
  %v6502 = load i64, ptr %slot28, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  store i32 2, ptr %p6503, align 4, !alias.scope !3, !noalias !4
  %v6504 = load i64, ptr %slot27, align 8
  %p6505 = inttoptr i64 %v6504 to ptr
  store i32 1, ptr %p6505, align 4, !alias.scope !3, !noalias !4
  %v6506 = load i64, ptr %slot64, align 8
  store i64 %v6506, ptr %slot1144, align 8
  %v6507 = load i64, ptr %slot1144, align 8
  %v6508 = load i64, ptr %slot1127, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v6507, i64 %v6508) nomerge, !dbg !170
  %v6509 = load i64, ptr %slot1128, align 8
  %v6510 = load i64, ptr %slot1127, align 8
  %p6511 = inttoptr i64 %v6509 to ptr
  %p6512 = inttoptr i64 %v6510 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6512, ptr %p6511, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v6513 = load i64, ptr %slot27, align 8
  %p6514 = inttoptr i64 %v6513 to ptr
  store i32 0, ptr %p6514, align 4, !alias.scope !3, !noalias !4
  %v6515 = load i64, ptr %slot1124, align 8
  %v6516 = load i64, ptr %slot53, align 8
  %p6517 = inttoptr i64 %v6516 to ptr
  store i64 %v6515, ptr %p6517, align 8, !alias.scope !3, !noalias !4
  %v6518 = load i64, ptr %slot53, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  %ld6520 = load i64, ptr %p6519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6520, ptr %slot1145, align 8
  %v6521 = load i64, ptr %slot35, align 8
  store i64 %v6521, ptr %slot1146, align 8
  %v6522 = load i64, ptr %slot1145, align 8
  %v6523 = load i64, ptr %slot1146, align 8
  %p6524 = inttoptr i64 %v6522 to ptr
  %p6525 = inttoptr i64 %v6523 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6525, ptr %p6524, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6526 = load i64, ptr %slot28, align 8
  %p6527 = inttoptr i64 %v6526 to ptr
  store i32 2, ptr %p6527, align 4, !alias.scope !3, !noalias !4
  %v6528 = load i64, ptr %slot27, align 8
  %p6529 = inttoptr i64 %v6528 to ptr
  store i32 1, ptr %p6529, align 4, !alias.scope !3, !noalias !4
  %v6530 = load i64, ptr %slot21, align 8
  %p6531 = inttoptr i64 %v6530 to ptr
  %ld6532 = load i32, ptr %p6531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6532, ptr %slot1147, align 8
  %v6533 = load i32, ptr %slot1147, align 8
  %cv6534 = zext i32 %v6533 to i64
  %cond6535 = icmp ne i64 %cv6534, 0
  br i1 %cond6535, label %bb_rcslotdrop1562, label %bb_rcslotdone1562
bb_rcslotdrop1562:
  %v6536 = load i64, ptr %slot21, align 8
  %p6537 = inttoptr i64 %v6536 to ptr
  store i32 0, ptr %p6537, align 4, !alias.scope !3, !noalias !4
  %v6538 = load i64, ptr %slot30, align 8
  store i64 %v6538, ptr %slot1148, align 8
  %v6539 = load i64, ptr %slot22, align 8
  %p6540 = inttoptr i64 %v6539 to ptr
  %ld6541 = load i32, ptr %p6540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6541, ptr %slot1149, align 8
  %v6542 = load i32, ptr %slot1149, align 8
  %op6543 = and i32 %v6542, 28
  store i32 %op6543, ptr %slot1150, align 8
  %v6544 = load i32, ptr %slot1150, align 8
  %cv6545 = zext i32 %v6544 to i64
  %cond6546 = icmp ne i64 %cv6545, 0
  br i1 %cond6546, label %bb_rcslotrole1562, label %bb_rcslotowner1562
bb_rcslotrole1562:
  %v6547 = load i64, ptr %slot64, align 8
  store i64 %v6547, ptr %slot1151, align 8
  %v6548 = load i64, ptr %slot1151, align 8
  %v6549 = load i64, ptr %slot1148, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6548, i64 %v6549) nomerge, !dbg !170
  br label %bb_rcslotdone1562
bb_rcslotowner1562:
  %v6550 = load i64, ptr %slot64, align 8
  store i64 %v6550, ptr %slot1152, align 8
  %v6551 = load i64, ptr %slot1152, align 8
  %v6552 = load i64, ptr %slot1148, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v6551, i64 %v6552) nomerge, !dbg !170
  br label %bb_rcslotdone1562
bb_rcslotdone1562:
  %v6553 = load i64, ptr %slot23, align 8
  %p6554 = inttoptr i64 %v6553 to ptr
  %ld6555 = load i32, ptr %p6554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6555, ptr %slot1153, align 8
  %v6556 = load i32, ptr %slot1153, align 8
  %cv6557 = zext i32 %v6556 to i64
  %cond6558 = icmp ne i64 %cv6557, 0
  br i1 %cond6558, label %bb_rcslotdrop1571, label %bb_rcslotdone1571
bb_rcslotdrop1571:
  %v6559 = load i64, ptr %slot23, align 8
  %p6560 = inttoptr i64 %v6559 to ptr
  store i32 0, ptr %p6560, align 4, !alias.scope !3, !noalias !4
  %v6561 = load i64, ptr %slot31, align 8
  store i64 %v6561, ptr %slot1154, align 8
  %v6562 = load i64, ptr %slot24, align 8
  %p6563 = inttoptr i64 %v6562 to ptr
  %ld6564 = load i32, ptr %p6563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6564, ptr %slot1155, align 8
  %v6565 = load i32, ptr %slot1155, align 8
  %op6566 = and i32 %v6565, 28
  store i32 %op6566, ptr %slot1156, align 8
  %v6567 = load i32, ptr %slot1156, align 8
  %cv6568 = zext i32 %v6567 to i64
  %cond6569 = icmp ne i64 %cv6568, 0
  br i1 %cond6569, label %bb_rcslotrole1571, label %bb_rcslotowner1571
bb_rcslotrole1571:
  %v6570 = load i64, ptr %slot64, align 8
  store i64 %v6570, ptr %slot1157, align 8
  %v6571 = load i64, ptr %slot1157, align 8
  %v6572 = load i64, ptr %slot1154, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v6571, i64 %v6572) nomerge, !dbg !170
  br label %bb_rcslotdone1571
bb_rcslotowner1571:
  %v6573 = load i64, ptr %slot64, align 8
  store i64 %v6573, ptr %slot1158, align 8
  %v6574 = load i64, ptr %slot1158, align 8
  %v6575 = load i64, ptr %slot1154, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v6574, i64 %v6575) nomerge, !dbg !170
  br label %bb_rcslotdone1571
bb_rcslotdone1571:
  %v6576 = load i64, ptr %slot30, align 8
  store i64 %v6576, ptr %slot1159, align 8
  %v6577 = load i64, ptr %slot35, align 8
  store i64 %v6577, ptr %slot1160, align 8
  %v6578 = load i64, ptr %slot1160, align 8
  %v6579 = load i64, ptr %slot1159, align 8
  %p6580 = inttoptr i64 %v6578 to ptr
  %p6581 = inttoptr i64 %v6579 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6581, ptr %p6580, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6582 = load i64, ptr %slot22, align 8
  %p6583 = inttoptr i64 %v6582 to ptr
  store i32 2, ptr %p6583, align 4, !alias.scope !3, !noalias !4
  %v6584 = load i64, ptr %slot28, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  %ld6586 = load i32, ptr %p6585, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6586, ptr %slot1161, align 8
  %v6587 = load i32, ptr %slot1161, align 8
  %v6588 = load i64, ptr %slot22, align 8
  %p6589 = inttoptr i64 %v6588 to ptr
  store i32 %v6587, ptr %p6589, align 4, !alias.scope !3, !noalias !4
  %v6590 = load i64, ptr %slot27, align 8
  %p6591 = inttoptr i64 %v6590 to ptr
  store i32 0, ptr %p6591, align 4, !alias.scope !3, !noalias !4
  %v6592 = load i64, ptr %slot21, align 8
  %p6593 = inttoptr i64 %v6592 to ptr
  store i32 1, ptr %p6593, align 4, !alias.scope !3, !noalias !4
  %v6594 = load i64, ptr %slot1159, align 8
  %v6595 = load i64, ptr %slot53, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  store i64 %v6594, ptr %p6596, align 8, !alias.scope !3, !noalias !4
  %v6597 = load i64, ptr %slot53, align 8
  %p6598 = inttoptr i64 %v6597 to ptr
  %ld6599 = load i64, ptr %p6598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6599, ptr %slot1162, align 8
  %v6600 = load i64, ptr %slot21, align 8
  %p6601 = inttoptr i64 %v6600 to ptr
  %ld6602 = load i32, ptr %p6601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6602, ptr %slot1163, align 8
  %v6603 = load i64, ptr %slot22, align 8
  %p6604 = inttoptr i64 %v6603 to ptr
  %ld6605 = load i32, ptr %p6604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6605, ptr %slot1164, align 8
  %v6606 = load i32, ptr %slot1164, align 8
  %op6607 = and i32 %v6606, 24
  store i32 %op6607, ptr %slot1164, align 8
  %v6608 = load i32, ptr %slot1164, align 8
  %cmp6609 = icmp eq i32 %v6608, 0
  %cv6610 = zext i1 %cmp6609 to i32
  store i32 %cv6610, ptr %slot1165, align 8
  %v6611 = load i32, ptr %slot1163, align 8
  %v6612 = load i32, ptr %slot1165, align 8
  %op6613 = and i32 %v6611, %v6612
  store i32 %op6613, ptr %slot1166, align 8
  %v6614 = load i32, ptr %slot1166, align 8
  %cv6615 = zext i32 %v6614 to i64
  %cond6616 = icmp ne i64 %cv6615, 0
  br i1 %cond6616, label %bb_rctake1587, label %bb_rccopy1587
bb_rctake1587:
  %v6617 = load i64, ptr %slot35, align 8
  store i64 %v6617, ptr %slot1167, align 8
  %v6618 = load i64, ptr %slot65, align 8
  store i64 %v6618, ptr %slot1168, align 8
  %v6619 = load i64, ptr %slot1162, align 8
  %v6620 = load i64, ptr %slot1167, align 8
  %op6621 = sub i64 %v6619, %v6620
  store i64 %op6621, ptr %slot1169, align 8
  %v6622 = load i64, ptr %slot1167, align 8
  %v6623 = load i64, ptr %slot1162, align 8
  %op6624 = sub i64 %v6622, %v6623
  store i64 %op6624, ptr %slot1170, align 8
  %v6625 = load i64, ptr %slot1169, align 8
  %cmp6626 = icmp ult i64 %v6625, 24
  %cv6627 = zext i1 %cmp6626 to i32
  store i32 %cv6627, ptr %slot1171, align 8
  %v6628 = load i64, ptr %slot1170, align 8
  %cmp6629 = icmp ult i64 %v6628, 24
  %cv6630 = zext i1 %cmp6629 to i32
  store i32 %cv6630, ptr %slot1172, align 8
  %v6631 = load i32, ptr %slot1171, align 8
  %v6632 = load i32, ptr %slot1172, align 8
  %op6633 = or i32 %v6631, %v6632
  store i32 %op6633, ptr %slot1173, align 8
  %v6634 = load i32, ptr %slot1173, align 8
  %cv6635 = zext i32 %v6634 to i64
  %cond6636 = icmp ne i64 %cv6635, 0
  br i1 %cond6636, label %bb_rcmoveslow1596, label %bb_rcmovecheck1596
bb_rcmovecheck1596:
  %v6637 = load i64, ptr %slot1162, align 8
  %op6638 = add i64 %v6637, 8
  store i64 %op6638, ptr %slot1174, align 8
  %v6639 = load i64, ptr %slot1174, align 8
  %p6640 = inttoptr i64 %v6639 to ptr
  %ld6641 = load i64, ptr %p6640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6641, ptr %slot1175, align 8
  %v6642 = load i64, ptr %slot1175, align 8
  %cmp6643 = icmp ne i64 %v6642, 0
  %cv6644 = zext i1 %cmp6643 to i32
  store i32 %cv6644, ptr %slot1176, align 8
  %v6645 = load i32, ptr %slot1176, align 8
  %cv6646 = zext i32 %v6645 to i64
  %cond6647 = icmp ne i64 %cv6646, 0
  br i1 %cond6647, label %bb_rcmoveheader1604, label %bb_rcmovenext1604
bb_rcmoveheader1604:
  %v6648 = load i64, ptr %slot1175, align 8
  %op6649 = sub i64 %v6648, 16
  store i64 %op6649, ptr %slot1177, align 8
  %v6650 = load i64, ptr %slot1175, align 8
  %p6651 = inttoptr i64 %v6650 to ptr
  %rgep6652 = getelementptr i8, ptr %p6651, i64 -16
  %ld6653 = load i64, ptr %rgep6652, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6653, ptr %slot1178, align 8
  %v6654 = load i64, ptr %slot1178, align 8
  %op6655 = and i64 %v6654, 5764607523034234881
  store i64 %op6655, ptr %slot1179, align 8
  %v6656 = load i64, ptr %slot1179, align 8
  %cmp6657 = icmp ne i64 %v6656, 0
  %cv6658 = zext i1 %cmp6657 to i32
  store i32 %cv6658, ptr %slot1180, align 8
  %v6659 = load i32, ptr %slot1180, align 8
  %cv6660 = zext i32 %v6659 to i64
  %cond6661 = icmp ne i64 %cv6660, 0
  br i1 %cond6661, label %bb_rcmoveslow1596, label %bb_rcmovenext1604
bb_rcmovenext1604:
  %v6662 = load i64, ptr %slot1162, align 8
  %v6663 = load i64, ptr %slot1167, align 8
  %p6664 = inttoptr i64 %v6662 to ptr
  %p6665 = inttoptr i64 %v6663 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6665, ptr %p6664, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6666 = load i64, ptr %slot1162, align 8
  %p6667 = inttoptr i64 %v6666 to ptr
  store i64 0, ptr %p6667, align 8, !alias.scope !3, !noalias !4
  %v6668 = load i64, ptr %slot1162, align 8
  %op6669 = add i64 %v6668, 8
  store i64 %op6669, ptr %slot1181, align 8
  %v6670 = load i64, ptr %slot1181, align 8
  %p6671 = inttoptr i64 %v6670 to ptr
  store i64 0, ptr %p6671, align 8, !alias.scope !3, !noalias !4
  %v6672 = load i64, ptr %slot1162, align 8
  %op6673 = add i64 %v6672, 16
  store i64 %op6673, ptr %slot1182, align 8
  %v6674 = load i64, ptr %slot1182, align 8
  %p6675 = inttoptr i64 %v6674 to ptr
  store i64 0, ptr %p6675, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1596
bb_rcmoveslow1596:
  %v6676 = load i64, ptr %slot64, align 8
  %v6677 = load i64, ptr %slot1167, align 8
  %v6678 = load i64, ptr %slot1162, align 8
  %v6679 = load i64, ptr %slot1168, align 8
  %cv6680 = trunc i64 %v6679 to i32
  %call6681 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v6676, i64 %v6677, i64 %v6678, i32 %cv6680) nomerge, !dbg !172
  store i32 %call6681, ptr %slot1183, align 8
  %v6682 = load i32, ptr %slot1183, align 8
  %cv6683 = zext i32 %v6682 to i64
  %cond6684 = icmp ne i64 %cv6683, 0
  br i1 %cond6684, label %bb_rcsuccess1613, label %bb_rcfailure1613
bb_rcfailure1613:
  %v6685 = load i64, ptr %slot64, align 8
  %p6686 = inttoptr i64 %v6685 to ptr
  %call6687 = call i32 @myl_rc_take_failure(ptr %p6686) nomerge, !dbg !172
  store i32 %call6687, ptr %slot1184, align 8
  %v6688 = load i64, ptr %slot1, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  %v6690 = load i32, ptr %slot1184, align 8
  %call6691 = call i32 @myl_qbe_rc_status(ptr %p6689, i32 %v6690) nomerge, !dbg !172
  store i32 %call6691, ptr %slot1185, align 8
  br label %bb_failure
bb_rcsuccess1613:
  br label %bb_rcmoved1596
bb_rcmoved1596:
  %v6692 = load i64, ptr %slot21, align 8
  %p6693 = inttoptr i64 %v6692 to ptr
  store i32 0, ptr %p6693, align 4, !alias.scope !3, !noalias !4
  %v6694 = load i64, ptr %slot28, align 8
  %p6695 = inttoptr i64 %v6694 to ptr
  store i32 2, ptr %p6695, align 4, !alias.scope !3, !noalias !4
  %v6696 = load i64, ptr %slot27, align 8
  %p6697 = inttoptr i64 %v6696 to ptr
  store i32 1, ptr %p6697, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1587
bb_rccopy1587:
  %v6698 = load i64, ptr %slot35, align 8
  store i64 %v6698, ptr %slot1186, align 8
  %v6699 = load i64, ptr %slot65, align 8
  store i64 %v6699, ptr %slot1187, align 8
  %v6700 = load i64, ptr %slot64, align 8
  %v6701 = load i64, ptr %slot1186, align 8
  %v6702 = load i64, ptr %slot1162, align 8
  %v6703 = load i64, ptr %slot1187, align 8
  %cv6704 = trunc i64 %v6703 to i32
  %call6705 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64 %v6700, i64 %v6701, i64 %v6702, i32 %cv6704) nomerge, !dbg !172
  store i32 %call6705, ptr %slot1188, align 8
  %v6706 = load i32, ptr %slot1188, align 8
  %cv6707 = zext i32 %v6706 to i64
  %cond6708 = icmp ne i64 %cv6707, 0
  br i1 %cond6708, label %bb_rcsuccess1622, label %bb_rcfailure1622
bb_rcfailure1622:
  %v6709 = load i64, ptr %slot64, align 8
  %p6710 = inttoptr i64 %v6709 to ptr
  %call6711 = call i32 @myl_rc_take_failure(ptr %p6710) nomerge, !dbg !172
  store i32 %call6711, ptr %slot1189, align 8
  %v6712 = load i64, ptr %slot1, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  %v6714 = load i32, ptr %slot1189, align 8
  %call6715 = call i32 @myl_qbe_rc_status(ptr %p6713, i32 %v6714) nomerge, !dbg !172
  store i32 %call6715, ptr %slot1190, align 8
  br label %bb_failure
bb_rcsuccess1622:
  %v6716 = load i64, ptr %slot28, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  store i32 2, ptr %p6717, align 4, !alias.scope !3, !noalias !4
  %v6718 = load i64, ptr %slot27, align 8
  %p6719 = inttoptr i64 %v6718 to ptr
  store i32 1, ptr %p6719, align 4, !alias.scope !3, !noalias !4
  %v6720 = load i64, ptr %slot21, align 8
  %p6721 = inttoptr i64 %v6720 to ptr
  %ld6722 = load i32, ptr %p6721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6722, ptr %slot1191, align 8
  %v6723 = load i32, ptr %slot1191, align 8
  %cv6724 = zext i32 %v6723 to i64
  %cond6725 = icmp ne i64 %cv6724, 0
  br i1 %cond6725, label %bb_rcslotdrop1629, label %bb_rcslotdone1629
bb_rcslotdrop1629:
  %v6726 = load i64, ptr %slot21, align 8
  %p6727 = inttoptr i64 %v6726 to ptr
  store i32 0, ptr %p6727, align 4, !alias.scope !3, !noalias !4
  %v6728 = load i64, ptr %slot30, align 8
  store i64 %v6728, ptr %slot1192, align 8
  %v6729 = load i64, ptr %slot22, align 8
  %p6730 = inttoptr i64 %v6729 to ptr
  %ld6731 = load i32, ptr %p6730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6731, ptr %slot1193, align 8
  %v6732 = load i32, ptr %slot1193, align 8
  %op6733 = and i32 %v6732, 28
  store i32 %op6733, ptr %slot1194, align 8
  %v6734 = load i32, ptr %slot1194, align 8
  %cv6735 = zext i32 %v6734 to i64
  %cond6736 = icmp ne i64 %cv6735, 0
  br i1 %cond6736, label %bb_rcslotrole1629, label %bb_rcslotowner1629
bb_rcslotrole1629:
  %v6737 = load i64, ptr %slot64, align 8
  store i64 %v6737, ptr %slot1195, align 8
  %v6738 = load i64, ptr %slot1195, align 8
  %v6739 = load i64, ptr %slot1192, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6738, i64 %v6739) nomerge, !dbg !172
  br label %bb_rcslotdone1629
bb_rcslotowner1629:
  %v6740 = load i64, ptr %slot1192, align 8
  %p6742 = inttoptr i64 %v6740 to ptr
  %gep6743 = getelementptr i8, ptr %p6742, i64 8
  %op6741 = ptrtoint ptr %gep6743 to i64
  store i64 %op6741, ptr %slot1196, align 8
  %v6744 = load i64, ptr %slot64, align 8
  store i64 %v6744, ptr %slot1197, align 8
  %v6745 = load i64, ptr %slot1196, align 8
  %p6746 = inttoptr i64 %v6745 to ptr
  %ld6747 = load i64, ptr %p6746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6747, ptr %slot1198, align 8
  %v6748 = load i64, ptr %slot1198, align 8
  %cmp6749 = icmp ne i64 %v6748, 0
  %cv6750 = zext i1 %cmp6749 to i32
  store i32 %cv6750, ptr %slot1199, align 8
  %v6751 = load i32, ptr %slot1199, align 8
  %cv6752 = zext i32 %v6751 to i64
  %cond6753 = icmp ne i64 %cv6752, 0
  br i1 %cond6753, label %bb_rcgnn1647, label %bb_rcgdone1647
bb_rcgnn1647:
  %v6754 = load i64, ptr %slot1198, align 8
  %op6755 = sub i64 %v6754, 16
  store i64 %op6755, ptr %slot1200, align 8
  %v6756 = load i64, ptr %slot1198, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  %rgep6758 = getelementptr i8, ptr %p6757, i64 -16
  %ld6759 = load i64, ptr %rgep6758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6759, ptr %slot1201, align 8
  %v6760 = load i64, ptr %slot1201, align 8
  %op6761 = and i64 %v6760, 4611686018427387906
  store i64 %op6761, ptr %slot1202, align 8
  %v6762 = load i64, ptr %slot1202, align 8
  %cmp6763 = icmp ne i64 %v6762, 0
  %cv6764 = zext i1 %cmp6763 to i32
  store i32 %cv6764, ptr %slot1203, align 8
  %v6765 = load i32, ptr %slot1203, align 8
  %cv6766 = zext i32 %v6765 to i64
  %cond6767 = icmp ne i64 %cv6766, 0
  br i1 %cond6767, label %bb_rcgclear1647, label %bb_rcgcounted1647
bb_rcgcounted1647:
  %v6768 = load i64, ptr %slot1198, align 8
  %op6769 = sub i64 %v6768, 32
  store i64 %op6769, ptr %slot1204, align 8
  %v6770 = load i64, ptr %slot1198, align 8
  %p6771 = inttoptr i64 %v6770 to ptr
  %rgep6772 = getelementptr i8, ptr %p6771, i64 -32
  %ld6773 = load i64, ptr %rgep6772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6773, ptr %slot1205, align 8
  %v6774 = load i64, ptr %slot1205, align 8
  %op6775 = sub i64 %v6774, 1
  store i64 %op6775, ptr %slot1206, align 8
  %v6776 = load i64, ptr %slot1206, align 8
  %cmp6777 = icmp eq i64 %v6776, 0
  %cv6778 = zext i1 %cmp6777 to i32
  store i32 %cv6778, ptr %slot1207, align 8
  %v6779 = load i32, ptr %slot1207, align 8
  %cv6780 = zext i32 %v6779 to i64
  %cond6781 = icmp ne i64 %cv6780, 0
  br i1 %cond6781, label %bb_rcglast1647, label %bb_rcgdec1647
bb_rcglast1647:
  %v6782 = load i64, ptr %slot1198, align 8
  %op6783 = sub i64 %v6782, 24
  store i64 %op6783, ptr %slot1208, align 8
  %v6784 = load i64, ptr %slot1198, align 8
  %p6785 = inttoptr i64 %v6784 to ptr
  %rgep6786 = getelementptr i8, ptr %p6785, i64 -24
  %ld6787 = load i64, ptr %rgep6786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6787, ptr %slot1209, align 8
  %v6788 = load i64, ptr %slot1209, align 8
  %cmp6789 = icmp ne i64 %v6788, 0
  %cv6790 = zext i1 %cmp6789 to i32
  store i32 %cv6790, ptr %slot1210, align 8
  %v6791 = load i32, ptr %slot1210, align 8
  %cv6792 = zext i32 %v6791 to i64
  %cond6793 = icmp ne i64 %cv6792, 0
  br i1 %cond6793, label %bb_rcgdec1647, label %bb_rcgslow1647
bb_rcgslow1647:
  %v6794 = load i64, ptr %slot1197, align 8
  %v6795 = load i64, ptr %slot1196, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6794, i64 %v6795) nomerge, !dbg !172
  br label %bb_rcgdone1647
bb_rcgdec1647:
  %v6796 = load i64, ptr %slot1206, align 8
  %v6797 = load i64, ptr %slot1198, align 8
  %p6798 = inttoptr i64 %v6797 to ptr
  %rgep6799 = getelementptr i8, ptr %p6798, i64 -32
  store i64 %v6796, ptr %rgep6799, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1647
bb_rcgclear1647:
  %v6800 = load i64, ptr %slot1196, align 8
  %p6801 = inttoptr i64 %v6800 to ptr
  store i64 0, ptr %p6801, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1647
bb_rcgdone1647:
  %v6802 = load i64, ptr %slot1192, align 8
  %p6803 = inttoptr i64 %v6802 to ptr
  store i64 0, ptr %p6803, align 8, !alias.scope !3, !noalias !4
  %v6804 = load i64, ptr %slot1192, align 8
  %p6806 = inttoptr i64 %v6804 to ptr
  %gep6807 = getelementptr i8, ptr %p6806, i64 8
  %op6805 = ptrtoint ptr %gep6807 to i64
  store i64 %op6805, ptr %slot1211, align 8
  %v6808 = load i64, ptr %slot1211, align 8
  %p6809 = inttoptr i64 %v6808 to ptr
  store i64 0, ptr %p6809, align 8, !alias.scope !3, !noalias !4
  %v6810 = load i64, ptr %slot1192, align 8
  %p6812 = inttoptr i64 %v6810 to ptr
  %gep6813 = getelementptr i8, ptr %p6812, i64 16
  %op6811 = ptrtoint ptr %gep6813 to i64
  store i64 %op6811, ptr %slot1212, align 8
  %v6814 = load i64, ptr %slot1212, align 8
  %p6815 = inttoptr i64 %v6814 to ptr
  store i64 0, ptr %p6815, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1629
bb_rcslotdone1629:
  br label %bb_rcprepared1587
bb_rcprepared1587:
  %v6816 = load i64, ptr %slot13, align 8
  %p6817 = inttoptr i64 %v6816 to ptr
  %ld6818 = load i32, ptr %p6817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6818, ptr %slot1213, align 8
  %v6819 = load i32, ptr %slot1213, align 8
  %cv6820 = zext i32 %v6819 to i64
  %cond6821 = icmp ne i64 %cv6820, 0
  br i1 %cond6821, label %bb_rcslotdrop1656, label %bb_rcslotdone1656
bb_rcslotdrop1656:
  %v6822 = load i64, ptr %slot13, align 8
  %p6823 = inttoptr i64 %v6822 to ptr
  store i32 0, ptr %p6823, align 4, !alias.scope !3, !noalias !4
  %v6824 = load i64, ptr %slot47, align 8
  store i64 %v6824, ptr %slot1214, align 8
  %v6825 = load i64, ptr %slot14, align 8
  %p6826 = inttoptr i64 %v6825 to ptr
  %ld6827 = load i32, ptr %p6826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6827, ptr %slot1215, align 8
  %v6828 = load i32, ptr %slot1215, align 8
  %op6829 = and i32 %v6828, 28
  store i32 %op6829, ptr %slot1216, align 8
  %v6830 = load i32, ptr %slot1216, align 8
  %cv6831 = zext i32 %v6830 to i64
  %cond6832 = icmp ne i64 %cv6831, 0
  br i1 %cond6832, label %bb_rcslotrole1656, label %bb_rcslotowner1656
bb_rcslotrole1656:
  %v6833 = load i64, ptr %slot64, align 8
  store i64 %v6833, ptr %slot1217, align 8
  %v6834 = load i64, ptr %slot1217, align 8
  %v6835 = load i64, ptr %slot1214, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6834, i64 %v6835) nomerge, !dbg !172
  br label %bb_rcslotdone1656
bb_rcslotowner1656:
  %v6836 = load i64, ptr %slot1214, align 8
  %p6838 = inttoptr i64 %v6836 to ptr
  %gep6839 = getelementptr i8, ptr %p6838, i64 8
  %op6837 = ptrtoint ptr %gep6839 to i64
  store i64 %op6837, ptr %slot1218, align 8
  %v6840 = load i64, ptr %slot64, align 8
  store i64 %v6840, ptr %slot1219, align 8
  %v6841 = load i64, ptr %slot1218, align 8
  %p6842 = inttoptr i64 %v6841 to ptr
  %ld6843 = load i64, ptr %p6842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6843, ptr %slot1220, align 8
  %v6844 = load i64, ptr %slot1220, align 8
  %cmp6845 = icmp ne i64 %v6844, 0
  %cv6846 = zext i1 %cmp6845 to i32
  store i32 %cv6846, ptr %slot1221, align 8
  %v6847 = load i32, ptr %slot1221, align 8
  %cv6848 = zext i32 %v6847 to i64
  %cond6849 = icmp ne i64 %cv6848, 0
  br i1 %cond6849, label %bb_rcgnn1674, label %bb_rcgdone1674
bb_rcgnn1674:
  %v6850 = load i64, ptr %slot1220, align 8
  %op6851 = sub i64 %v6850, 16
  store i64 %op6851, ptr %slot1222, align 8
  %v6852 = load i64, ptr %slot1220, align 8
  %p6853 = inttoptr i64 %v6852 to ptr
  %rgep6854 = getelementptr i8, ptr %p6853, i64 -16
  %ld6855 = load i64, ptr %rgep6854, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6855, ptr %slot1223, align 8
  %v6856 = load i64, ptr %slot1223, align 8
  %op6857 = and i64 %v6856, 4611686018427387906
  store i64 %op6857, ptr %slot1224, align 8
  %v6858 = load i64, ptr %slot1224, align 8
  %cmp6859 = icmp ne i64 %v6858, 0
  %cv6860 = zext i1 %cmp6859 to i32
  store i32 %cv6860, ptr %slot1225, align 8
  %v6861 = load i32, ptr %slot1225, align 8
  %cv6862 = zext i32 %v6861 to i64
  %cond6863 = icmp ne i64 %cv6862, 0
  br i1 %cond6863, label %bb_rcgclear1674, label %bb_rcgcounted1674
bb_rcgcounted1674:
  %v6864 = load i64, ptr %slot1220, align 8
  %op6865 = sub i64 %v6864, 32
  store i64 %op6865, ptr %slot1226, align 8
  %v6866 = load i64, ptr %slot1220, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  %rgep6868 = getelementptr i8, ptr %p6867, i64 -32
  %ld6869 = load i64, ptr %rgep6868, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6869, ptr %slot1227, align 8
  %v6870 = load i64, ptr %slot1227, align 8
  %op6871 = sub i64 %v6870, 1
  store i64 %op6871, ptr %slot1228, align 8
  %v6872 = load i64, ptr %slot1228, align 8
  %cmp6873 = icmp eq i64 %v6872, 0
  %cv6874 = zext i1 %cmp6873 to i32
  store i32 %cv6874, ptr %slot1229, align 8
  %v6875 = load i32, ptr %slot1229, align 8
  %cv6876 = zext i32 %v6875 to i64
  %cond6877 = icmp ne i64 %cv6876, 0
  br i1 %cond6877, label %bb_rcglast1674, label %bb_rcgdec1674
bb_rcglast1674:
  %v6878 = load i64, ptr %slot1220, align 8
  %op6879 = sub i64 %v6878, 24
  store i64 %op6879, ptr %slot1230, align 8
  %v6880 = load i64, ptr %slot1220, align 8
  %p6881 = inttoptr i64 %v6880 to ptr
  %rgep6882 = getelementptr i8, ptr %p6881, i64 -24
  %ld6883 = load i64, ptr %rgep6882, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6883, ptr %slot1231, align 8
  %v6884 = load i64, ptr %slot1231, align 8
  %cmp6885 = icmp ne i64 %v6884, 0
  %cv6886 = zext i1 %cmp6885 to i32
  store i32 %cv6886, ptr %slot1232, align 8
  %v6887 = load i32, ptr %slot1232, align 8
  %cv6888 = zext i32 %v6887 to i64
  %cond6889 = icmp ne i64 %cv6888, 0
  br i1 %cond6889, label %bb_rcgdec1674, label %bb_rcgslow1674
bb_rcgslow1674:
  %v6890 = load i64, ptr %slot1219, align 8
  %v6891 = load i64, ptr %slot1218, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v6890, i64 %v6891) nomerge, !dbg !172
  br label %bb_rcgdone1674
bb_rcgdec1674:
  %v6892 = load i64, ptr %slot1228, align 8
  %v6893 = load i64, ptr %slot1220, align 8
  %p6894 = inttoptr i64 %v6893 to ptr
  %rgep6895 = getelementptr i8, ptr %p6894, i64 -32
  store i64 %v6892, ptr %rgep6895, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1674
bb_rcgclear1674:
  %v6896 = load i64, ptr %slot1218, align 8
  %p6897 = inttoptr i64 %v6896 to ptr
  store i64 0, ptr %p6897, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1674
bb_rcgdone1674:
  %v6898 = load i64, ptr %slot1214, align 8
  %p6899 = inttoptr i64 %v6898 to ptr
  store i64 0, ptr %p6899, align 8, !alias.scope !3, !noalias !4
  %v6900 = load i64, ptr %slot1214, align 8
  %p6902 = inttoptr i64 %v6900 to ptr
  %gep6903 = getelementptr i8, ptr %p6902, i64 8
  %op6901 = ptrtoint ptr %gep6903 to i64
  store i64 %op6901, ptr %slot1233, align 8
  %v6904 = load i64, ptr %slot1233, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  store i64 0, ptr %p6905, align 8, !alias.scope !3, !noalias !4
  %v6906 = load i64, ptr %slot1214, align 8
  %p6908 = inttoptr i64 %v6906 to ptr
  %gep6909 = getelementptr i8, ptr %p6908, i64 16
  %op6907 = ptrtoint ptr %gep6909 to i64
  store i64 %op6907, ptr %slot1234, align 8
  %v6910 = load i64, ptr %slot1234, align 8
  %p6911 = inttoptr i64 %v6910 to ptr
  store i64 0, ptr %p6911, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1656
bb_rcslotdone1656:
  %v6912 = load i64, ptr %slot47, align 8
  store i64 %v6912, ptr %slot1235, align 8
  %v6913 = load i64, ptr %slot35, align 8
  store i64 %v6913, ptr %slot1236, align 8
  %v6914 = load i64, ptr %slot1236, align 8
  %v6915 = load i64, ptr %slot1235, align 8
  %p6916 = inttoptr i64 %v6914 to ptr
  %p6917 = inttoptr i64 %v6915 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6917, ptr %p6916, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6918 = load i64, ptr %slot27, align 8
  %p6919 = inttoptr i64 %v6918 to ptr
  store i32 0, ptr %p6919, align 4, !alias.scope !3, !noalias !4
  %v6920 = load i64, ptr %slot14, align 8
  %p6921 = inttoptr i64 %v6920 to ptr
  store i32 2, ptr %p6921, align 4, !alias.scope !3, !noalias !4
  %v6922 = load i64, ptr %slot28, align 8
  %p6923 = inttoptr i64 %v6922 to ptr
  %ld6924 = load i32, ptr %p6923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6924, ptr %slot1237, align 8
  %v6925 = load i32, ptr %slot1237, align 8
  %v6926 = load i64, ptr %slot14, align 8
  %p6927 = inttoptr i64 %v6926 to ptr
  store i32 %v6925, ptr %p6927, align 4, !alias.scope !3, !noalias !4
  %v6928 = load i64, ptr %slot13, align 8
  %p6929 = inttoptr i64 %v6928 to ptr
  store i32 1, ptr %p6929, align 4, !alias.scope !3, !noalias !4
  %v6930 = load i64, ptr %slot53, align 8
  %p6931 = inttoptr i64 %v6930 to ptr
  store i64 0, ptr %p6931, align 8, !alias.scope !3, !noalias !4
  %v6932 = load i64, ptr %slot47, align 8
  %v6933 = load i64, ptr %slot53, align 8
  %p6934 = inttoptr i64 %v6933 to ptr
  store i64 %v6932, ptr %p6934, align 8, !alias.scope !3, !noalias !4
  %v6935 = load i64, ptr %slot53, align 8
  %p6936 = inttoptr i64 %v6935 to ptr
  %ld6937 = load i64, ptr %p6936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6937, ptr %slot1238, align 8
  %v6938 = load i64, ptr %slot21, align 8
  %p6939 = inttoptr i64 %v6938 to ptr
  %ld6940 = load i32, ptr %p6939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6940, ptr %slot1239, align 8
  %v6941 = load i64, ptr %slot22, align 8
  %p6942 = inttoptr i64 %v6941 to ptr
  %ld6943 = load i32, ptr %p6942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6943, ptr %slot1240, align 8
  %v6944 = load i32, ptr %slot1240, align 8
  %op6945 = and i32 %v6944, 24
  store i32 %op6945, ptr %slot1240, align 8
  %v6946 = load i32, ptr %slot1240, align 8
  %cmp6947 = icmp eq i32 %v6946, 0
  %cv6948 = zext i1 %cmp6947 to i32
  store i32 %cv6948, ptr %slot1241, align 8
  %v6949 = load i32, ptr %slot1239, align 8
  %v6950 = load i32, ptr %slot1241, align 8
  %op6951 = and i32 %v6949, %v6950
  store i32 %op6951, ptr %slot1242, align 8
  %v6952 = load i64, ptr %slot65, align 8
  store i64 %v6952, ptr %slot1243, align 8
  %v6953 = load i32, ptr %slot1242, align 8
  %op6954 = mul i32 %v6953, 4
  store i32 %op6954, ptr %slot1244, align 8
  %v6955 = load i32, ptr %slot1244, align 8
  %op6956 = or i32 %v6955, 0
  store i32 %op6956, ptr %slot1245, align 8
  %v6957 = load i64, ptr %slot35, align 8
  store i64 %v6957, ptr %slot1246, align 8
  %v6958 = load i64, ptr %slot64, align 8
  %v6959 = load i64, ptr %slot1246, align 8
  %v6960 = load i64, ptr %slot1238, align 8
  %v6961 = load i64, ptr %slot1243, align 8
  %cv6962 = trunc i64 %v6961 to i32
  %v6963 = load i32, ptr %slot1245, align 8
  %call6964 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64 %v6958, i64 %v6959, i64 %v6960, i32 %cv6962, i32 %v6963) nomerge, !dbg !174
  store i32 %call6964, ptr %slot1247, align 8
  %v6965 = load i32, ptr %slot1247, align 8
  %cv6966 = zext i32 %v6965 to i64
  %cond6967 = icmp ne i64 %cv6966, 0
  br i1 %cond6967, label %bb_rcsuccess1701, label %bb_rcfailure1701
bb_rcfailure1701:
  %v6968 = load i64, ptr %slot64, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  %call6970 = call i32 @myl_rc_take_failure(ptr %p6969) nomerge, !dbg !174
  store i32 %call6970, ptr %slot1248, align 8
  %v6971 = load i64, ptr %slot1, align 8
  %p6972 = inttoptr i64 %v6971 to ptr
  %v6973 = load i32, ptr %slot1248, align 8
  %call6974 = call i32 @myl_qbe_rc_status(ptr %p6972, i32 %v6973) nomerge, !dbg !174
  store i32 %call6974, ptr %slot1249, align 8
  br label %bb_failure
bb_rcsuccess1701:
  %v6975 = load i32, ptr %slot1242, align 8
  %cv6976 = zext i32 %v6975 to i64
  %cond6977 = icmp ne i64 %cv6976, 0
  br i1 %cond6977, label %bb_rchtaken1704, label %bb_rchcopied1704
bb_rchcopied1704:
  %v6978 = load i64, ptr %slot21, align 8
  %p6979 = inttoptr i64 %v6978 to ptr
  %ld6980 = load i32, ptr %p6979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6980, ptr %slot1250, align 8
  %v6981 = load i32, ptr %slot1250, align 8
  %cv6982 = zext i32 %v6981 to i64
  %cond6983 = icmp ne i64 %cv6982, 0
  br i1 %cond6983, label %bb_rcslotdrop1707, label %bb_rcslotdone1707
bb_rcslotdrop1707:
  %v6984 = load i64, ptr %slot21, align 8
  %p6985 = inttoptr i64 %v6984 to ptr
  store i32 0, ptr %p6985, align 4, !alias.scope !3, !noalias !4
  %v6986 = load i64, ptr %slot30, align 8
  store i64 %v6986, ptr %slot1251, align 8
  %v6987 = load i64, ptr %slot22, align 8
  %p6988 = inttoptr i64 %v6987 to ptr
  %ld6989 = load i32, ptr %p6988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6989, ptr %slot1252, align 8
  %v6990 = load i32, ptr %slot1252, align 8
  %op6991 = and i32 %v6990, 28
  store i32 %op6991, ptr %slot1253, align 8
  %v6992 = load i32, ptr %slot1253, align 8
  %cv6993 = zext i32 %v6992 to i64
  %cond6994 = icmp ne i64 %cv6993, 0
  br i1 %cond6994, label %bb_rcslotrole1707, label %bb_rcslotowner1707
bb_rcslotrole1707:
  %v6995 = load i64, ptr %slot64, align 8
  store i64 %v6995, ptr %slot1254, align 8
  %v6996 = load i64, ptr %slot1254, align 8
  %v6997 = load i64, ptr %slot1251, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v6996, i64 %v6997) nomerge, !dbg !174
  br label %bb_rcslotdone1707
bb_rcslotowner1707:
  %v6998 = load i64, ptr %slot64, align 8
  store i64 %v6998, ptr %slot1255, align 8
  %v6999 = load i64, ptr %slot1255, align 8
  %v7000 = load i64, ptr %slot1251, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v6999, i64 %v7000) nomerge, !dbg !174
  br label %bb_rcslotdone1707
bb_rcslotdone1707:
  br label %bb_rchprepared1704
bb_rchtaken1704:
  %v7001 = load i64, ptr %slot21, align 8
  %p7002 = inttoptr i64 %v7001 to ptr
  store i32 0, ptr %p7002, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1704
bb_rchprepared1704:
  %v7003 = load i64, ptr %slot28, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  store i32 2, ptr %p7004, align 4, !alias.scope !3, !noalias !4
  %v7005 = load i64, ptr %slot27, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  store i32 1, ptr %p7006, align 4, !alias.scope !3, !noalias !4
  %v7007 = load i64, ptr %slot30, align 8
  store i64 %v7007, ptr %slot1256, align 8
  %v7008 = load i64, ptr %slot35, align 8
  store i64 %v7008, ptr %slot1257, align 8
  %v7009 = load i64, ptr %slot1257, align 8
  %v7010 = load i64, ptr %slot1256, align 8
  %p7011 = inttoptr i64 %v7009 to ptr
  %p7012 = inttoptr i64 %v7010 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7012, ptr %p7011, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7013 = load i64, ptr %slot22, align 8
  %p7014 = inttoptr i64 %v7013 to ptr
  store i32 2, ptr %p7014, align 4, !alias.scope !3, !noalias !4
  %v7015 = load i64, ptr %slot28, align 8
  %p7016 = inttoptr i64 %v7015 to ptr
  %ld7017 = load i32, ptr %p7016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7017, ptr %slot1258, align 8
  %v7018 = load i32, ptr %slot1258, align 8
  %v7019 = load i64, ptr %slot22, align 8
  %p7020 = inttoptr i64 %v7019 to ptr
  store i32 %v7018, ptr %p7020, align 4, !alias.scope !3, !noalias !4
  %v7021 = load i64, ptr %slot27, align 8
  %p7022 = inttoptr i64 %v7021 to ptr
  store i32 0, ptr %p7022, align 4, !alias.scope !3, !noalias !4
  %v7023 = load i64, ptr %slot21, align 8
  %p7024 = inttoptr i64 %v7023 to ptr
  store i32 1, ptr %p7024, align 4, !alias.scope !3, !noalias !4
  %v7025 = load i64, ptr %slot1256, align 8
  %v7026 = load i64, ptr %slot53, align 8
  %p7027 = inttoptr i64 %v7026 to ptr
  store i64 %v7025, ptr %p7027, align 8, !alias.scope !3, !noalias !4
  %v7028 = load i64, ptr %slot58, align 8
  store i64 %v7028, ptr %slot1259, align 8
  %v7029 = load i64, ptr %slot1259, align 8
  %p7030 = inttoptr i64 %v7029 to ptr
  store i64 0, ptr %p7030, align 8, !alias.scope !3, !noalias !4
  %v7031 = load i64, ptr %slot1259, align 8
  %p7033 = inttoptr i64 %v7031 to ptr
  %gep7034 = getelementptr i8, ptr %p7033, i64 8
  %op7032 = ptrtoint ptr %gep7034 to i64
  store i64 %op7032, ptr %slot1260, align 8
  %v7035 = load i64, ptr %slot1260, align 8
  %p7036 = inttoptr i64 %v7035 to ptr
  store i64 0, ptr %p7036, align 8, !alias.scope !3, !noalias !4
  %v7037 = load i64, ptr %slot1259, align 8
  %p7039 = inttoptr i64 %v7037 to ptr
  %gep7040 = getelementptr i8, ptr %p7039, i64 16
  %op7038 = ptrtoint ptr %gep7040 to i64
  store i64 %op7038, ptr %slot1261, align 8
  %v7041 = load i64, ptr %slot1261, align 8
  %p7042 = inttoptr i64 %v7041 to ptr
  store i64 0, ptr %p7042, align 8, !alias.scope !3, !noalias !4
  %v7043 = load i64, ptr %slot1259, align 8
  %p7045 = inttoptr i64 %v7043 to ptr
  %gep7046 = getelementptr i8, ptr %p7045, i64 24
  %op7044 = ptrtoint ptr %gep7046 to i64
  store i64 %op7044, ptr %slot1262, align 8
  %v7047 = load i64, ptr %slot1262, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  store i64 0, ptr %p7048, align 8, !alias.scope !3, !noalias !4
  %v7049 = load i64, ptr %slot1259, align 8
  %p7051 = inttoptr i64 %v7049 to ptr
  %gep7052 = getelementptr i8, ptr %p7051, i64 32
  %op7050 = ptrtoint ptr %gep7052 to i64
  store i64 %op7050, ptr %slot1263, align 8
  %v7053 = load i64, ptr %slot1263, align 8
  %p7054 = inttoptr i64 %v7053 to ptr
  store i64 0, ptr %p7054, align 8, !alias.scope !3, !noalias !4
  %v7055 = load i64, ptr %slot1259, align 8
  %p7057 = inttoptr i64 %v7055 to ptr
  %gep7058 = getelementptr i8, ptr %p7057, i64 40
  %op7056 = ptrtoint ptr %gep7058 to i64
  store i64 %op7056, ptr %slot1264, align 8
  %v7059 = load i64, ptr %slot1264, align 8
  %p7060 = inttoptr i64 %v7059 to ptr
  store i64 0, ptr %p7060, align 8, !alias.scope !3, !noalias !4
  %v7061 = load i64, ptr %slot1259, align 8
  %p7063 = inttoptr i64 %v7061 to ptr
  %gep7064 = getelementptr i8, ptr %p7063, i64 48
  %op7062 = ptrtoint ptr %gep7064 to i64
  store i64 %op7062, ptr %slot1265, align 8
  %v7065 = load i64, ptr %slot1265, align 8
  %p7066 = inttoptr i64 %v7065 to ptr
  store i64 0, ptr %p7066, align 8, !alias.scope !3, !noalias !4
  %v7067 = load i64, ptr %slot1259, align 8
  %p7068 = inttoptr i64 %v7067 to ptr
  store i32 6, ptr %p7068, align 4, !alias.scope !3, !noalias !4
  %v7069 = load i64, ptr %slot29, align 8
  %p7070 = inttoptr i64 %v7069 to ptr
  store i32 1, ptr %p7070, align 4, !alias.scope !3, !noalias !4
  %v7071 = load i64, ptr %slot53, align 8
  %p7072 = inttoptr i64 %v7071 to ptr
  %ld7073 = load i64, ptr %p7072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7073, ptr %slot1266, align 8
  %v7074 = load i64, ptr %slot1259, align 8
  %p7076 = inttoptr i64 %v7074 to ptr
  %gep7077 = getelementptr i8, ptr %p7076, i64 8
  %op7075 = ptrtoint ptr %gep7077 to i64
  store i64 %op7075, ptr %slot1267, align 8
  %v7078 = load i64, ptr %slot65, align 8
  store i64 %v7078, ptr %slot1268, align 8
  %v7079 = load i64, ptr %slot53, align 8
  %p7080 = inttoptr i64 %v7079 to ptr
  %ld7081 = load i64, ptr %p7080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7081, ptr %slot1269, align 8
  %v7082 = load i64, ptr %slot35, align 8
  store i64 %v7082, ptr %slot1270, align 8
  %v7083 = load i64, ptr %slot65, align 8
  store i64 %v7083, ptr %slot1271, align 8
  %v7084 = load i64, ptr %slot1269, align 8
  %op7085 = add i64 %v7084, 8
  store i64 %op7085, ptr %slot1272, align 8
  %v7086 = load i64, ptr %slot1272, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %ld7088 = load i64, ptr %p7087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7088, ptr %slot1273, align 8
  %v7089 = load i64, ptr %slot1273, align 8
  %cmp7090 = icmp ne i64 %v7089, 0
  %cv7091 = zext i1 %cmp7090 to i32
  store i32 %cv7091, ptr %slot1274, align 8
  %v7092 = load i32, ptr %slot1274, align 8
  %cv7093 = zext i32 %v7092 to i64
  %cond7094 = icmp ne i64 %cv7093, 0
  br i1 %cond7094, label %bb_rcmoveheader1743, label %bb_rcmovenext1743
bb_rcmoveheader1743:
  %v7095 = load i64, ptr %slot1273, align 8
  %op7096 = sub i64 %v7095, 16
  store i64 %op7096, ptr %slot1275, align 8
  %v7097 = load i64, ptr %slot1273, align 8
  %p7098 = inttoptr i64 %v7097 to ptr
  %rgep7099 = getelementptr i8, ptr %p7098, i64 -16
  %ld7100 = load i64, ptr %rgep7099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7100, ptr %slot1276, align 8
  %v7101 = load i64, ptr %slot1276, align 8
  %op7102 = and i64 %v7101, 5764607523034234881
  store i64 %op7102, ptr %slot1277, align 8
  %v7103 = load i64, ptr %slot1277, align 8
  %cmp7104 = icmp ne i64 %v7103, 0
  %cv7105 = zext i1 %cmp7104 to i32
  store i32 %cv7105, ptr %slot1278, align 8
  %v7106 = load i32, ptr %slot1278, align 8
  %cv7107 = zext i32 %v7106 to i64
  %cond7108 = icmp ne i64 %cv7107, 0
  br i1 %cond7108, label %bb_rcmoveslow1740, label %bb_rcmovenext1743
bb_rcmovenext1743:
  %v7109 = load i64, ptr %slot1269, align 8
  %v7110 = load i64, ptr %slot1270, align 8
  %p7111 = inttoptr i64 %v7109 to ptr
  %p7112 = inttoptr i64 %v7110 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7112, ptr %p7111, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7113 = load i64, ptr %slot1269, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  store i64 0, ptr %p7114, align 8, !alias.scope !3, !noalias !4
  %v7115 = load i64, ptr %slot1269, align 8
  %op7116 = add i64 %v7115, 8
  store i64 %op7116, ptr %slot1279, align 8
  %v7117 = load i64, ptr %slot1279, align 8
  %p7118 = inttoptr i64 %v7117 to ptr
  store i64 0, ptr %p7118, align 8, !alias.scope !3, !noalias !4
  %v7119 = load i64, ptr %slot1269, align 8
  %op7120 = add i64 %v7119, 16
  store i64 %op7120, ptr %slot1280, align 8
  %v7121 = load i64, ptr %slot1280, align 8
  %p7122 = inttoptr i64 %v7121 to ptr
  store i64 0, ptr %p7122, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1740
bb_rcmoveslow1740:
  %v7123 = load i64, ptr %slot64, align 8
  %v7124 = load i64, ptr %slot1270, align 8
  %v7125 = load i64, ptr %slot1269, align 8
  %v7126 = load i64, ptr %slot1271, align 8
  %cv7127 = trunc i64 %v7126 to i32
  %call7128 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v7123, i64 %v7124, i64 %v7125, i32 %cv7127) nomerge, !dbg !176
  store i32 %call7128, ptr %slot1281, align 8
  %v7129 = load i32, ptr %slot1281, align 8
  %cv7130 = zext i32 %v7129 to i64
  %cond7131 = icmp ne i64 %cv7130, 0
  br i1 %cond7131, label %bb_rcsuccess1752, label %bb_rcfailure1752
bb_rcfailure1752:
  %v7132 = load i64, ptr %slot64, align 8
  %p7133 = inttoptr i64 %v7132 to ptr
  %call7134 = call i32 @myl_rc_take_failure(ptr %p7133) nomerge, !dbg !176
  store i32 %call7134, ptr %slot1282, align 8
  %v7135 = load i64, ptr %slot1, align 8
  %p7136 = inttoptr i64 %v7135 to ptr
  %v7137 = load i32, ptr %slot1282, align 8
  %call7138 = call i32 @myl_qbe_rc_status(ptr %p7136, i32 %v7137) nomerge, !dbg !176
  store i32 %call7138, ptr %slot1283, align 8
  br label %bb_failure
bb_rcsuccess1752:
  br label %bb_rcmoved1740
bb_rcmoved1740:
  %v7139 = load i64, ptr %slot21, align 8
  %p7140 = inttoptr i64 %v7139 to ptr
  store i32 0, ptr %p7140, align 4, !alias.scope !3, !noalias !4
  %v7141 = load i64, ptr %slot28, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  store i32 2, ptr %p7142, align 4, !alias.scope !3, !noalias !4
  %v7143 = load i64, ptr %slot27, align 8
  %p7144 = inttoptr i64 %v7143 to ptr
  store i32 1, ptr %p7144, align 4, !alias.scope !3, !noalias !4
  %v7145 = load i64, ptr %slot35, align 8
  store i64 %v7145, ptr %slot1284, align 8
  %v7146 = load i64, ptr %slot1284, align 8
  %v7147 = load i64, ptr %slot1267, align 8
  %p7148 = inttoptr i64 %v7146 to ptr
  %p7149 = inttoptr i64 %v7147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7149, ptr %p7148, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7150 = load i64, ptr %slot27, align 8
  %p7151 = inttoptr i64 %v7150 to ptr
  store i32 0, ptr %p7151, align 4, !alias.scope !3, !noalias !4
  %v7152 = load i64, ptr %slot1259, align 8
  %v7153 = load i64, ptr %slot53, align 8
  %p7154 = inttoptr i64 %v7153 to ptr
  store i64 %v7152, ptr %p7154, align 8, !alias.scope !3, !noalias !4
  %v7155 = load i64, ptr %slot53, align 8
  %p7156 = inttoptr i64 %v7155 to ptr
  %ld7157 = load i64, ptr %p7156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7157, ptr %slot1285, align 8
  %v7158 = load i64, ptr %slot30, align 8
  store i64 %v7158, ptr %slot1286, align 8
  %v7159 = load i64, ptr %slot1285, align 8
  %v7160 = load i64, ptr %slot1286, align 8
  %p7161 = inttoptr i64 %v7159 to ptr
  %p7162 = inttoptr i64 %v7160 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7162, ptr %p7161, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7163 = load i64, ptr %slot22, align 8
  %p7164 = inttoptr i64 %v7163 to ptr
  store i32 2, ptr %p7164, align 4, !alias.scope !3, !noalias !4
  %v7165 = load i64, ptr %slot21, align 8
  %p7166 = inttoptr i64 %v7165 to ptr
  store i32 1, ptr %p7166, align 4, !alias.scope !3, !noalias !4
  %v7167 = load i64, ptr %slot1286, align 8
  %v7168 = load i64, ptr %slot53, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  store i64 %v7167, ptr %p7169, align 8, !alias.scope !3, !noalias !4
  %v7170 = load i64, ptr %slot53, align 8
  %p7171 = inttoptr i64 %v7170 to ptr
  %ld7172 = load i64, ptr %p7171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7172, ptr %slot1287, align 8
  %v7173 = load i64, ptr %slot21, align 8
  %p7174 = inttoptr i64 %v7173 to ptr
  %ld7175 = load i32, ptr %p7174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7175, ptr %slot1288, align 8
  %v7176 = load i64, ptr %slot22, align 8
  %p7177 = inttoptr i64 %v7176 to ptr
  %ld7178 = load i32, ptr %p7177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7178, ptr %slot1289, align 8
  %v7179 = load i32, ptr %slot1289, align 8
  %op7180 = and i32 %v7179, 24
  store i32 %op7180, ptr %slot1289, align 8
  %v7181 = load i32, ptr %slot1289, align 8
  %cmp7182 = icmp eq i32 %v7181, 0
  %cv7183 = zext i1 %cmp7182 to i32
  store i32 %cv7183, ptr %slot1290, align 8
  %v7184 = load i32, ptr %slot1288, align 8
  %v7185 = load i32, ptr %slot1290, align 8
  %op7186 = and i32 %v7184, %v7185
  store i32 %op7186, ptr %slot1291, align 8
  %v7187 = load i32, ptr %slot1291, align 8
  %cv7188 = zext i32 %v7187 to i64
  %cond7189 = icmp ne i64 %cv7188, 0
  br i1 %cond7189, label %bb_rcprivateown1771, label %bb_rcprivateloan1771
bb_rcprivateown1771:
  %v7190 = load i64, ptr %slot35, align 8
  store i64 %v7190, ptr %slot1292, align 8
  %v7191 = load i64, ptr %slot65, align 8
  store i64 %v7191, ptr %slot1293, align 8
  %v7192 = load i64, ptr %slot64, align 8
  %v7193 = load i64, ptr %slot1292, align 8
  %v7194 = load i64, ptr %slot1287, align 8
  %v7195 = load i64, ptr %slot1293, align 8
  %cv7196 = trunc i64 %v7195 to i32
  %call7197 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v7192, i64 %v7193, i64 %v7194, i32 %cv7196) nomerge, !dbg !178
  store i32 %call7197, ptr %slot1294, align 8
  %v7198 = load i32, ptr %slot1294, align 8
  %cv7199 = zext i32 %v7198 to i64
  %cond7200 = icmp ne i64 %cv7199, 0
  br i1 %cond7200, label %bb_rcsuccess1775, label %bb_rcfailure1775
bb_rcfailure1775:
  %v7201 = load i64, ptr %slot64, align 8
  %p7202 = inttoptr i64 %v7201 to ptr
  %call7203 = call i32 @myl_rc_take_failure(ptr %p7202) nomerge, !dbg !178
  store i32 %call7203, ptr %slot1295, align 8
  %v7204 = load i64, ptr %slot1, align 8
  %p7205 = inttoptr i64 %v7204 to ptr
  %v7206 = load i32, ptr %slot1295, align 8
  %call7207 = call i32 @myl_qbe_rc_status(ptr %p7205, i32 %v7206) nomerge, !dbg !178
  store i32 %call7207, ptr %slot1296, align 8
  br label %bb_failure
bb_rcsuccess1775:
  %v7208 = load i64, ptr %slot21, align 8
  %p7209 = inttoptr i64 %v7208 to ptr
  store i32 0, ptr %p7209, align 4, !alias.scope !3, !noalias !4
  %v7210 = load i64, ptr %slot28, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  store i32 2, ptr %p7211, align 4, !alias.scope !3, !noalias !4
  %v7212 = load i64, ptr %slot27, align 8
  %p7213 = inttoptr i64 %v7212 to ptr
  store i32 1, ptr %p7213, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1771
bb_rcprivateloan1771:
  %v7214 = load i64, ptr %slot21, align 8
  %p7215 = inttoptr i64 %v7214 to ptr
  %ld7216 = load i32, ptr %p7215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7216, ptr %slot1297, align 8
  %v7217 = load i64, ptr %slot22, align 8
  %p7218 = inttoptr i64 %v7217 to ptr
  %ld7219 = load i32, ptr %p7218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7219, ptr %slot1298, align 8
  %v7220 = load i32, ptr %slot1298, align 8
  %cmp7221 = icmp eq i32 %v7220, 16
  %cv7222 = zext i1 %cmp7221 to i32
  store i32 %cv7222, ptr %slot1299, align 8
  %v7223 = load i32, ptr %slot1299, align 8
  %v7224 = load i32, ptr %slot1297, align 8
  %op7225 = and i32 %v7223, %v7224
  store i32 %op7225, ptr %slot1299, align 8
  %v7226 = load i32, ptr %slot1299, align 8
  %cv7227 = zext i32 %v7226 to i64
  %cond7228 = icmp ne i64 %cv7227, 0
  br i1 %cond7228, label %bb_rcprivatemove1771, label %bb_rcprivatenew1771
bb_rcprivatemove1771:
  %v7229 = load i64, ptr %slot35, align 8
  store i64 %v7229, ptr %slot1300, align 8
  %v7230 = load i64, ptr %slot1287, align 8
  %v7231 = load i64, ptr %slot1300, align 8
  %p7232 = inttoptr i64 %v7230 to ptr
  %p7233 = inttoptr i64 %v7231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7233, ptr %p7232, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7234 = load i64, ptr %slot1287, align 8
  %p7235 = inttoptr i64 %v7234 to ptr
  call void @llvm.memset.p0.i64(ptr %p7235, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !178
  %v7236 = load i64, ptr %slot28, align 8
  %p7237 = inttoptr i64 %v7236 to ptr
  store i32 2, ptr %p7237, align 4, !alias.scope !3, !noalias !4
  %v7238 = load i64, ptr %slot28, align 8
  %p7239 = inttoptr i64 %v7238 to ptr
  store i32 16, ptr %p7239, align 4, !alias.scope !3, !noalias !4
  %v7240 = load i64, ptr %slot27, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  store i32 1, ptr %p7241, align 4, !alias.scope !3, !noalias !4
  %v7242 = load i64, ptr %slot21, align 8
  %p7243 = inttoptr i64 %v7242 to ptr
  store i32 0, ptr %p7243, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1771
bb_rcprivatenew1771:
  %v7244 = load i64, ptr %slot35, align 8
  store i64 %v7244, ptr %slot1301, align 8
  %v7245 = load i64, ptr %slot64, align 8
  %v7246 = load i64, ptr %slot1301, align 8
  %v7247 = load i64, ptr %slot1287, align 8
  %call7248 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v7245, i64 %v7246, i64 %v7247) nomerge, !dbg !178
  store i32 %call7248, ptr %slot1302, align 8
  %v7249 = load i32, ptr %slot1302, align 8
  %cv7250 = zext i32 %v7249 to i64
  %cond7251 = icmp ne i64 %cv7250, 0
  br i1 %cond7251, label %bb_rcsuccess1793, label %bb_rcfailure1793
bb_rcfailure1793:
  %v7252 = load i64, ptr %slot64, align 8
  %p7253 = inttoptr i64 %v7252 to ptr
  %call7254 = call i32 @myl_rc_take_failure(ptr %p7253) nomerge, !dbg !178
  store i32 %call7254, ptr %slot1303, align 8
  %v7255 = load i64, ptr %slot1, align 8
  %p7256 = inttoptr i64 %v7255 to ptr
  %v7257 = load i32, ptr %slot1303, align 8
  %call7258 = call i32 @myl_qbe_rc_status(ptr %p7256, i32 %v7257) nomerge, !dbg !178
  store i32 %call7258, ptr %slot1304, align 8
  br label %bb_failure
bb_rcsuccess1793:
  %v7259 = load i64, ptr %slot28, align 8
  %p7260 = inttoptr i64 %v7259 to ptr
  store i32 2, ptr %p7260, align 4, !alias.scope !3, !noalias !4
  %v7261 = load i64, ptr %slot28, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  store i32 16, ptr %p7262, align 4, !alias.scope !3, !noalias !4
  %v7263 = load i64, ptr %slot27, align 8
  %p7264 = inttoptr i64 %v7263 to ptr
  store i32 1, ptr %p7264, align 4, !alias.scope !3, !noalias !4
  %v7265 = load i64, ptr %slot21, align 8
  %p7266 = inttoptr i64 %v7265 to ptr
  %ld7267 = load i32, ptr %p7266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7267, ptr %slot1305, align 8
  %v7268 = load i32, ptr %slot1305, align 8
  %cv7269 = zext i32 %v7268 to i64
  %cond7270 = icmp ne i64 %cv7269, 0
  br i1 %cond7270, label %bb_rcslotdrop1801, label %bb_rcslotdone1801
bb_rcslotdrop1801:
  %v7271 = load i64, ptr %slot21, align 8
  %p7272 = inttoptr i64 %v7271 to ptr
  store i32 0, ptr %p7272, align 4, !alias.scope !3, !noalias !4
  %v7273 = load i64, ptr %slot30, align 8
  store i64 %v7273, ptr %slot1306, align 8
  %v7274 = load i64, ptr %slot22, align 8
  %p7275 = inttoptr i64 %v7274 to ptr
  %ld7276 = load i32, ptr %p7275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7276, ptr %slot1307, align 8
  %v7277 = load i32, ptr %slot1307, align 8
  %op7278 = and i32 %v7277, 28
  store i32 %op7278, ptr %slot1308, align 8
  %v7279 = load i32, ptr %slot1308, align 8
  %cv7280 = zext i32 %v7279 to i64
  %cond7281 = icmp ne i64 %cv7280, 0
  br i1 %cond7281, label %bb_rcslotrole1801, label %bb_rcslotowner1801
bb_rcslotrole1801:
  %v7282 = load i64, ptr %slot64, align 8
  store i64 %v7282, ptr %slot1309, align 8
  %v7283 = load i64, ptr %slot1309, align 8
  %v7284 = load i64, ptr %slot1306, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7283, i64 %v7284) nomerge, !dbg !178
  br label %bb_rcslotdone1801
bb_rcslotowner1801:
  %v7285 = load i64, ptr %slot64, align 8
  store i64 %v7285, ptr %slot1310, align 8
  %v7286 = load i64, ptr %slot1310, align 8
  %v7287 = load i64, ptr %slot1306, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7286, i64 %v7287) nomerge, !dbg !178
  br label %bb_rcslotdone1801
bb_rcslotdone1801:
  br label %bb_rcprivateprepared1771
bb_rcprivateprepared1771:
  %v7288 = load i64, ptr %slot19, align 8
  %p7289 = inttoptr i64 %v7288 to ptr
  %ld7290 = load i32, ptr %p7289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7290, ptr %slot1311, align 8
  %v7291 = load i32, ptr %slot1311, align 8
  %cv7292 = zext i32 %v7291 to i64
  %cond7293 = icmp ne i64 %cv7292, 0
  br i1 %cond7293, label %bb_rcslotdrop1811, label %bb_rcslotdone1811
bb_rcslotdrop1811:
  %v7294 = load i64, ptr %slot19, align 8
  %p7295 = inttoptr i64 %v7294 to ptr
  store i32 0, ptr %p7295, align 4, !alias.scope !3, !noalias !4
  %v7296 = load i64, ptr %slot51, align 8
  store i64 %v7296, ptr %slot1312, align 8
  %v7297 = load i64, ptr %slot20, align 8
  %p7298 = inttoptr i64 %v7297 to ptr
  %ld7299 = load i32, ptr %p7298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7299, ptr %slot1313, align 8
  %v7300 = load i32, ptr %slot1313, align 8
  %op7301 = and i32 %v7300, 28
  store i32 %op7301, ptr %slot1314, align 8
  %v7302 = load i32, ptr %slot1314, align 8
  %cv7303 = zext i32 %v7302 to i64
  %cond7304 = icmp ne i64 %cv7303, 0
  br i1 %cond7304, label %bb_rcslotrole1811, label %bb_rcslotowner1811
bb_rcslotrole1811:
  %v7305 = load i64, ptr %slot64, align 8
  store i64 %v7305, ptr %slot1315, align 8
  %v7306 = load i64, ptr %slot1315, align 8
  %v7307 = load i64, ptr %slot1312, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7306, i64 %v7307) nomerge, !dbg !178
  br label %bb_rcslotdone1811
bb_rcslotowner1811:
  %v7308 = load i64, ptr %slot64, align 8
  store i64 %v7308, ptr %slot1316, align 8
  %v7309 = load i64, ptr %slot1316, align 8
  %v7310 = load i64, ptr %slot1312, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7309, i64 %v7310) nomerge, !dbg !178
  br label %bb_rcslotdone1811
bb_rcslotdone1811:
  %v7311 = load i64, ptr %slot51, align 8
  store i64 %v7311, ptr %slot1317, align 8
  %v7312 = load i64, ptr %slot35, align 8
  store i64 %v7312, ptr %slot1318, align 8
  %v7313 = load i64, ptr %slot1318, align 8
  %v7314 = load i64, ptr %slot1317, align 8
  %p7315 = inttoptr i64 %v7313 to ptr
  %p7316 = inttoptr i64 %v7314 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7316, ptr %p7315, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7317 = load i64, ptr %slot27, align 8
  %p7318 = inttoptr i64 %v7317 to ptr
  store i32 0, ptr %p7318, align 4, !alias.scope !3, !noalias !4
  %v7319 = load i64, ptr %slot20, align 8
  %p7320 = inttoptr i64 %v7319 to ptr
  store i32 2, ptr %p7320, align 4, !alias.scope !3, !noalias !4
  %v7321 = load i64, ptr %slot28, align 8
  %p7322 = inttoptr i64 %v7321 to ptr
  %ld7323 = load i32, ptr %p7322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7323, ptr %slot1319, align 8
  %v7324 = load i32, ptr %slot1319, align 8
  %v7325 = load i64, ptr %slot20, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  store i32 %v7324, ptr %p7326, align 4, !alias.scope !3, !noalias !4
  %v7327 = load i64, ptr %slot19, align 8
  %p7328 = inttoptr i64 %v7327 to ptr
  store i32 1, ptr %p7328, align 4, !alias.scope !3, !noalias !4
  %v7329 = load i64, ptr %slot39, align 8
  %p7330 = inttoptr i64 %v7329 to ptr
  %ld7331 = load i64, ptr %p7330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7331, ptr %slot1320, align 8
  %v7332 = load i64, ptr %slot1320, align 8
  %v7333 = load i64, ptr %slot53, align 8
  %p7334 = inttoptr i64 %v7333 to ptr
  store i64 %v7332, ptr %p7334, align 8, !alias.scope !3, !noalias !4
  %v7335 = load i64, ptr %slot53, align 8
  %p7336 = inttoptr i64 %v7335 to ptr
  %ld7337 = load i64, ptr %p7336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7337, ptr %slot1321, align 8
  %v7338 = load i64, ptr %slot1321, align 8
  %op7339 = add i64 %v7338, 0
  store i64 %op7339, ptr %slot1322, align 8
  %v7340 = load i64, ptr %slot1322, align 8
  %p7341 = inttoptr i64 %v7340 to ptr
  %ld7342 = load i64, ptr %p7341, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7342, ptr %slot1323, align 8
  %v7343 = load i64, ptr %slot1323, align 8
  %v7344 = load i64, ptr %slot53, align 8
  %p7345 = inttoptr i64 %v7344 to ptr
  store i64 %v7343, ptr %p7345, align 8, !alias.scope !3, !noalias !4
  %v7346 = load i64, ptr %slot21, align 8
  %p7347 = inttoptr i64 %v7346 to ptr
  %ld7348 = load i32, ptr %p7347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7348, ptr %slot1324, align 8
  %v7349 = load i32, ptr %slot1324, align 8
  %cv7350 = zext i32 %v7349 to i64
  %cond7351 = icmp ne i64 %cv7350, 0
  br i1 %cond7351, label %bb_rcslotdrop1831, label %bb_rcslotdone1831
bb_rcslotdrop1831:
  %v7352 = load i64, ptr %slot21, align 8
  %p7353 = inttoptr i64 %v7352 to ptr
  store i32 0, ptr %p7353, align 4, !alias.scope !3, !noalias !4
  %v7354 = load i64, ptr %slot30, align 8
  store i64 %v7354, ptr %slot1325, align 8
  %v7355 = load i64, ptr %slot22, align 8
  %p7356 = inttoptr i64 %v7355 to ptr
  %ld7357 = load i32, ptr %p7356, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7357, ptr %slot1326, align 8
  %v7358 = load i32, ptr %slot1326, align 8
  %op7359 = and i32 %v7358, 28
  store i32 %op7359, ptr %slot1327, align 8
  %v7360 = load i32, ptr %slot1327, align 8
  %cv7361 = zext i32 %v7360 to i64
  %cond7362 = icmp ne i64 %cv7361, 0
  br i1 %cond7362, label %bb_rcslotrole1831, label %bb_rcslotowner1831
bb_rcslotrole1831:
  %v7363 = load i64, ptr %slot64, align 8
  store i64 %v7363, ptr %slot1328, align 8
  %v7364 = load i64, ptr %slot1328, align 8
  %v7365 = load i64, ptr %slot1325, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7364, i64 %v7365) nomerge, !dbg !180
  br label %bb_rcslotdone1831
bb_rcslotowner1831:
  %v7366 = load i64, ptr %slot64, align 8
  store i64 %v7366, ptr %slot1329, align 8
  %v7367 = load i64, ptr %slot1329, align 8
  %v7368 = load i64, ptr %slot1325, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7367, i64 %v7368) nomerge, !dbg !180
  br label %bb_rcslotdone1831
bb_rcslotdone1831:
  %v7369 = load i64, ptr %slot53, align 8
  %p7370 = inttoptr i64 %v7369 to ptr
  %ld7371 = load i64, ptr %p7370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7371, ptr %slot1330, align 8
  %v7372 = load i64, ptr %slot39, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  %ld7374 = load i64, ptr %p7373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7374, ptr %slot1331, align 8
  %v7375 = load i64, ptr %slot21, align 8
  %p7376 = inttoptr i64 %v7375 to ptr
  %ld7377 = load i32, ptr %p7376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7377, ptr %slot1332, align 8
  %v7378 = load i32, ptr %slot1332, align 8
  %cv7379 = zext i32 %v7378 to i64
  %cond7380 = icmp ne i64 %cv7379, 0
  br i1 %cond7380, label %bb_rcslotdrop1843, label %bb_rcslotdone1843
bb_rcslotdrop1843:
  %v7381 = load i64, ptr %slot21, align 8
  %p7382 = inttoptr i64 %v7381 to ptr
  store i32 0, ptr %p7382, align 4, !alias.scope !3, !noalias !4
  %v7383 = load i64, ptr %slot30, align 8
  store i64 %v7383, ptr %slot1333, align 8
  %v7384 = load i64, ptr %slot22, align 8
  %p7385 = inttoptr i64 %v7384 to ptr
  %ld7386 = load i32, ptr %p7385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7386, ptr %slot1334, align 8
  %v7387 = load i32, ptr %slot1334, align 8
  %op7388 = and i32 %v7387, 28
  store i32 %op7388, ptr %slot1335, align 8
  %v7389 = load i32, ptr %slot1335, align 8
  %cv7390 = zext i32 %v7389 to i64
  %cond7391 = icmp ne i64 %cv7390, 0
  br i1 %cond7391, label %bb_rcslotrole1843, label %bb_rcslotowner1843
bb_rcslotrole1843:
  %v7392 = load i64, ptr %slot64, align 8
  store i64 %v7392, ptr %slot1336, align 8
  %v7393 = load i64, ptr %slot1333, align 8
  %p7394 = inttoptr i64 %v7393 to ptr
  %ld7395 = load i64, ptr %p7394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7395, ptr %slot1337, align 8
  %v7396 = load i64, ptr %slot1337, align 8
  %cmp7397 = icmp ne i64 %v7396, 0
  %cv7398 = zext i1 %cmp7397 to i32
  store i32 %cv7398, ptr %slot1338, align 8
  %v7399 = load i32, ptr %slot1338, align 8
  %cv7400 = zext i32 %v7399 to i64
  %cond7401 = icmp ne i64 %cv7400, 0
  br i1 %cond7401, label %bb_rcgnn1859, label %bb_rcgdone1859
bb_rcgnn1859:
  %v7402 = load i64, ptr %slot1337, align 8
  %op7403 = sub i64 %v7402, 16
  store i64 %op7403, ptr %slot1339, align 8
  %v7404 = load i64, ptr %slot1337, align 8
  %p7405 = inttoptr i64 %v7404 to ptr
  %rgep7406 = getelementptr i8, ptr %p7405, i64 -16
  %ld7407 = load i64, ptr %rgep7406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7407, ptr %slot1340, align 8
  %v7408 = load i64, ptr %slot1340, align 8
  %op7409 = and i64 %v7408, 4611686018427387906
  store i64 %op7409, ptr %slot1341, align 8
  %v7410 = load i64, ptr %slot1341, align 8
  %cmp7411 = icmp ne i64 %v7410, 0
  %cv7412 = zext i1 %cmp7411 to i32
  store i32 %cv7412, ptr %slot1342, align 8
  %v7413 = load i32, ptr %slot1342, align 8
  %cv7414 = zext i32 %v7413 to i64
  %cond7415 = icmp ne i64 %cv7414, 0
  br i1 %cond7415, label %bb_rcgclear1859, label %bb_rcgcounted1859
bb_rcgcounted1859:
  %v7416 = load i64, ptr %slot1337, align 8
  %op7417 = sub i64 %v7416, 24
  store i64 %op7417, ptr %slot1343, align 8
  %v7418 = load i64, ptr %slot1337, align 8
  %p7419 = inttoptr i64 %v7418 to ptr
  %rgep7420 = getelementptr i8, ptr %p7419, i64 -24
  %ld7421 = load i64, ptr %rgep7420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7421, ptr %slot1344, align 8
  %v7422 = load i64, ptr %slot1344, align 8
  %op7423 = sub i64 %v7422, 1
  store i64 %op7423, ptr %slot1345, align 8
  %v7424 = load i64, ptr %slot1345, align 8
  %cmp7425 = icmp eq i64 %v7424, 0
  %cv7426 = zext i1 %cmp7425 to i32
  store i32 %cv7426, ptr %slot1346, align 8
  %v7427 = load i32, ptr %slot1346, align 8
  %cv7428 = zext i32 %v7427 to i64
  %cond7429 = icmp ne i64 %cv7428, 0
  br i1 %cond7429, label %bb_rcglast1859, label %bb_rcgdec1859
bb_rcglast1859:
  %v7430 = load i64, ptr %slot1337, align 8
  %op7431 = sub i64 %v7430, 32
  store i64 %op7431, ptr %slot1347, align 8
  %v7432 = load i64, ptr %slot1337, align 8
  %p7433 = inttoptr i64 %v7432 to ptr
  %rgep7434 = getelementptr i8, ptr %p7433, i64 -32
  %ld7435 = load i64, ptr %rgep7434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7435, ptr %slot1348, align 8
  %v7436 = load i64, ptr %slot1348, align 8
  %cmp7437 = icmp ne i64 %v7436, 0
  %cv7438 = zext i1 %cmp7437 to i32
  store i32 %cv7438, ptr %slot1349, align 8
  %v7439 = load i32, ptr %slot1349, align 8
  %cv7440 = zext i32 %v7439 to i64
  %cond7441 = icmp ne i64 %cv7440, 0
  br i1 %cond7441, label %bb_rcgdec1859, label %bb_rcgslow1859
bb_rcgslow1859:
  %v7442 = load i64, ptr %slot1336, align 8
  %v7443 = load i64, ptr %slot1333, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v7442, i64 %v7443) nomerge, !dbg !182
  br label %bb_rcgdone1859
bb_rcgdec1859:
  %v7444 = load i64, ptr %slot1345, align 8
  %v7445 = load i64, ptr %slot1337, align 8
  %p7446 = inttoptr i64 %v7445 to ptr
  %rgep7447 = getelementptr i8, ptr %p7446, i64 -24
  store i64 %v7444, ptr %rgep7447, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1859
bb_rcgclear1859:
  %v7448 = load i64, ptr %slot1333, align 8
  %p7449 = inttoptr i64 %v7448 to ptr
  store i64 0, ptr %p7449, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1859
bb_rcgdone1859:
  br label %bb_rcslotdone1843
bb_rcslotowner1843:
  %v7450 = load i64, ptr %slot64, align 8
  store i64 %v7450, ptr %slot1350, align 8
  %v7451 = load i64, ptr %slot1333, align 8
  %p7452 = inttoptr i64 %v7451 to ptr
  %ld7453 = load i64, ptr %p7452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7453, ptr %slot1351, align 8
  %v7454 = load i64, ptr %slot1351, align 8
  %cmp7455 = icmp ne i64 %v7454, 0
  %cv7456 = zext i1 %cmp7455 to i32
  store i32 %cv7456, ptr %slot1352, align 8
  %v7457 = load i32, ptr %slot1352, align 8
  %cv7458 = zext i32 %v7457 to i64
  %cond7459 = icmp ne i64 %cv7458, 0
  br i1 %cond7459, label %bb_rcgnn1874, label %bb_rcgdone1874
bb_rcgnn1874:
  %v7460 = load i64, ptr %slot1351, align 8
  %op7461 = sub i64 %v7460, 16
  store i64 %op7461, ptr %slot1353, align 8
  %v7462 = load i64, ptr %slot1351, align 8
  %p7463 = inttoptr i64 %v7462 to ptr
  %rgep7464 = getelementptr i8, ptr %p7463, i64 -16
  %ld7465 = load i64, ptr %rgep7464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7465, ptr %slot1354, align 8
  %v7466 = load i64, ptr %slot1354, align 8
  %op7467 = and i64 %v7466, 4611686018427387906
  store i64 %op7467, ptr %slot1355, align 8
  %v7468 = load i64, ptr %slot1355, align 8
  %cmp7469 = icmp ne i64 %v7468, 0
  %cv7470 = zext i1 %cmp7469 to i32
  store i32 %cv7470, ptr %slot1356, align 8
  %v7471 = load i32, ptr %slot1356, align 8
  %cv7472 = zext i32 %v7471 to i64
  %cond7473 = icmp ne i64 %cv7472, 0
  br i1 %cond7473, label %bb_rcgclear1874, label %bb_rcgcounted1874
bb_rcgcounted1874:
  %v7474 = load i64, ptr %slot1351, align 8
  %op7475 = sub i64 %v7474, 32
  store i64 %op7475, ptr %slot1357, align 8
  %v7476 = load i64, ptr %slot1351, align 8
  %p7477 = inttoptr i64 %v7476 to ptr
  %rgep7478 = getelementptr i8, ptr %p7477, i64 -32
  %ld7479 = load i64, ptr %rgep7478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7479, ptr %slot1358, align 8
  %v7480 = load i64, ptr %slot1358, align 8
  %op7481 = sub i64 %v7480, 1
  store i64 %op7481, ptr %slot1359, align 8
  %v7482 = load i64, ptr %slot1359, align 8
  %cmp7483 = icmp eq i64 %v7482, 0
  %cv7484 = zext i1 %cmp7483 to i32
  store i32 %cv7484, ptr %slot1360, align 8
  %v7485 = load i32, ptr %slot1360, align 8
  %cv7486 = zext i32 %v7485 to i64
  %cond7487 = icmp ne i64 %cv7486, 0
  br i1 %cond7487, label %bb_rcglast1874, label %bb_rcgdec1874
bb_rcglast1874:
  %v7488 = load i64, ptr %slot1351, align 8
  %op7489 = sub i64 %v7488, 24
  store i64 %op7489, ptr %slot1361, align 8
  %v7490 = load i64, ptr %slot1351, align 8
  %p7491 = inttoptr i64 %v7490 to ptr
  %rgep7492 = getelementptr i8, ptr %p7491, i64 -24
  %ld7493 = load i64, ptr %rgep7492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7493, ptr %slot1362, align 8
  %v7494 = load i64, ptr %slot1362, align 8
  %cmp7495 = icmp ne i64 %v7494, 0
  %cv7496 = zext i1 %cmp7495 to i32
  store i32 %cv7496, ptr %slot1363, align 8
  %v7497 = load i32, ptr %slot1363, align 8
  %cv7498 = zext i32 %v7497 to i64
  %cond7499 = icmp ne i64 %cv7498, 0
  br i1 %cond7499, label %bb_rcgdec1874, label %bb_rcgslow1874
bb_rcgslow1874:
  %v7500 = load i64, ptr %slot1350, align 8
  %v7501 = load i64, ptr %slot1333, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v7500, i64 %v7501) nomerge, !dbg !182
  br label %bb_rcgdone1874
bb_rcgdec1874:
  %v7502 = load i64, ptr %slot1359, align 8
  %v7503 = load i64, ptr %slot1351, align 8
  %p7504 = inttoptr i64 %v7503 to ptr
  %rgep7505 = getelementptr i8, ptr %p7504, i64 -32
  store i64 %v7502, ptr %rgep7505, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1874
bb_rcgclear1874:
  %v7506 = load i64, ptr %slot1333, align 8
  %p7507 = inttoptr i64 %v7506 to ptr
  store i64 0, ptr %p7507, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1874
bb_rcgdone1874:
  br label %bb_rcslotdone1843
bb_rcslotdone1843:
  %v7508 = load i64, ptr %slot1331, align 8
  %op7509 = add i64 %v7508, 0
  store i64 %op7509, ptr %slot1364, align 8
  store i64 0, ptr %slot1365, align 8
  %v7510 = load i64, ptr %slot1364, align 8
  %p7511 = inttoptr i64 %v7510 to ptr
  %ld7512 = load i64, ptr %p7511, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7512, ptr %slot1366, align 8
  %v7513 = load i64, ptr %slot1366, align 8
  %cmp7514 = icmp ne i64 %v7513, 0
  %cv7515 = zext i1 %cmp7514 to i32
  store i32 %cv7515, ptr %slot1367, align 8
  %v7516 = load i32, ptr %slot1367, align 8
  %cv7517 = zext i32 %v7516 to i64
  %cond7518 = icmp ne i64 %cv7517, 0
  br i1 %cond7518, label %bb_rcguniquenn1880, label %bb_rcgunique1880
bb_rcguniquenn1880:
  %v7519 = load i64, ptr %slot1366, align 8
  %op7520 = sub i64 %v7519, 16
  store i64 %op7520, ptr %slot1368, align 8
  %v7521 = load i64, ptr %slot1366, align 8
  %p7522 = inttoptr i64 %v7521 to ptr
  %rgep7523 = getelementptr i8, ptr %p7522, i64 -16
  %ld7524 = load i64, ptr %rgep7523, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7524, ptr %slot1369, align 8
  %v7525 = load i64, ptr %slot1369, align 8
  %op7526 = and i64 %v7525, 6917529027641081858
  store i64 %op7526, ptr %slot1370, align 8
  %v7527 = load i64, ptr %slot1370, align 8
  %cmp7528 = icmp ne i64 %v7527, 0
  %cv7529 = zext i1 %cmp7528 to i32
  store i32 %cv7529, ptr %slot1371, align 8
  %v7530 = load i32, ptr %slot1371, align 8
  %cv7531 = zext i32 %v7530 to i64
  %cond7532 = icmp ne i64 %cv7531, 0
  br i1 %cond7532, label %bb_rcguniqueslow1880, label %bb_rcguniquecount1880
bb_rcguniquecount1880:
  %v7533 = load i64, ptr %slot1366, align 8
  %op7534 = sub i64 %v7533, 32
  store i64 %op7534, ptr %slot1372, align 8
  %v7535 = load i64, ptr %slot1366, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  %rgep7537 = getelementptr i8, ptr %p7536, i64 -32
  %ld7538 = load i64, ptr %rgep7537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7538, ptr %slot1373, align 8
  %v7539 = load i64, ptr %slot1373, align 8
  %cmp7540 = icmp ult i64 %v7539, 2
  %cv7541 = zext i1 %cmp7540 to i32
  store i32 %cv7541, ptr %slot1374, align 8
  %v7542 = load i32, ptr %slot1374, align 8
  %cv7543 = zext i32 %v7542 to i64
  %cond7544 = icmp ne i64 %cv7543, 0
  br i1 %cond7544, label %bb_rcgunique1880, label %bb_rcguniqueslow1880
bb_rcguniqueslow1880:
  %v7545 = load i64, ptr %slot1, align 8
  %p7546 = inttoptr i64 %v7545 to ptr
  %p7547 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v7548 = load i64, ptr %slot1364, align 8
  %p7549 = inttoptr i64 %v7548 to ptr
  %v7550 = load i64, ptr %slot1365, align 8
  %p7551 = inttoptr i64 %v7550 to ptr
  %call7552 = call i32 @myl_qbe_rc_unique_field(ptr %p7546, ptr %p7547, ptr %p7549, ptr %p7551) nomerge, !dbg !182
  store i32 %call7552, ptr %slot1375, align 8
  %v7553 = load i32, ptr %slot1375, align 8
  %cv7554 = zext i32 %v7553 to i64
  %cond7555 = icmp ne i64 %cv7554, 0
  br i1 %cond7555, label %bb_rcunique1890, label %bb_failure
bb_rcunique1890:
  br label %bb_rcgunique1880
bb_rcgunique1880:
  %v7556 = load i64, ptr %slot1364, align 8
  %p7557 = inttoptr i64 %v7556 to ptr
  %ld7558 = load i64, ptr %p7557, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7558, ptr %slot1376, align 8
  %v7559 = load i64, ptr %slot1376, align 8
  %v7560 = load i64, ptr %slot53, align 8
  %p7561 = inttoptr i64 %v7560 to ptr
  store i64 %v7559, ptr %p7561, align 8, !alias.scope !3, !noalias !4
  %v7562 = load i64, ptr %slot53, align 8
  %p7563 = inttoptr i64 %v7562 to ptr
  %ld7564 = load i64, ptr %p7563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7564, ptr %slot1377, align 8
  %v7565 = load i64, ptr %slot21, align 8
  %p7566 = inttoptr i64 %v7565 to ptr
  %ld7567 = load i32, ptr %p7566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7567, ptr %slot1378, align 8
  %v7568 = load i32, ptr %slot1378, align 8
  %cv7569 = zext i32 %v7568 to i64
  %cond7570 = icmp ne i64 %cv7569, 0
  br i1 %cond7570, label %bb_rcslotdrop1895, label %bb_rcslotdone1895
bb_rcslotdrop1895:
  %v7571 = load i64, ptr %slot21, align 8
  %p7572 = inttoptr i64 %v7571 to ptr
  store i32 0, ptr %p7572, align 4, !alias.scope !3, !noalias !4
  %v7573 = load i64, ptr %slot30, align 8
  store i64 %v7573, ptr %slot1379, align 8
  %v7574 = load i64, ptr %slot22, align 8
  %p7575 = inttoptr i64 %v7574 to ptr
  %ld7576 = load i32, ptr %p7575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7576, ptr %slot1380, align 8
  %v7577 = load i32, ptr %slot1380, align 8
  %op7578 = and i32 %v7577, 28
  store i32 %op7578, ptr %slot1381, align 8
  %v7579 = load i32, ptr %slot1381, align 8
  %cv7580 = zext i32 %v7579 to i64
  %cond7581 = icmp ne i64 %cv7580, 0
  br i1 %cond7581, label %bb_rcslotrole1895, label %bb_rcslotowner1895
bb_rcslotrole1895:
  %v7582 = load i64, ptr %slot64, align 8
  store i64 %v7582, ptr %slot1382, align 8
  %v7583 = load i64, ptr %slot1379, align 8
  %p7584 = inttoptr i64 %v7583 to ptr
  %ld7585 = load i64, ptr %p7584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7585, ptr %slot1383, align 8
  %v7586 = load i64, ptr %slot1383, align 8
  %cmp7587 = icmp ne i64 %v7586, 0
  %cv7588 = zext i1 %cmp7587 to i32
  store i32 %cv7588, ptr %slot1384, align 8
  %v7589 = load i32, ptr %slot1384, align 8
  %cv7590 = zext i32 %v7589 to i64
  %cond7591 = icmp ne i64 %cv7590, 0
  br i1 %cond7591, label %bb_rcgnn1911, label %bb_rcgdone1911
bb_rcgnn1911:
  %v7592 = load i64, ptr %slot1383, align 8
  %op7593 = sub i64 %v7592, 16
  store i64 %op7593, ptr %slot1385, align 8
  %v7594 = load i64, ptr %slot1383, align 8
  %p7595 = inttoptr i64 %v7594 to ptr
  %rgep7596 = getelementptr i8, ptr %p7595, i64 -16
  %ld7597 = load i64, ptr %rgep7596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7597, ptr %slot1386, align 8
  %v7598 = load i64, ptr %slot1386, align 8
  %op7599 = and i64 %v7598, 4611686018427387906
  store i64 %op7599, ptr %slot1387, align 8
  %v7600 = load i64, ptr %slot1387, align 8
  %cmp7601 = icmp ne i64 %v7600, 0
  %cv7602 = zext i1 %cmp7601 to i32
  store i32 %cv7602, ptr %slot1388, align 8
  %v7603 = load i32, ptr %slot1388, align 8
  %cv7604 = zext i32 %v7603 to i64
  %cond7605 = icmp ne i64 %cv7604, 0
  br i1 %cond7605, label %bb_rcgclear1911, label %bb_rcgcounted1911
bb_rcgcounted1911:
  %v7606 = load i64, ptr %slot1383, align 8
  %op7607 = sub i64 %v7606, 24
  store i64 %op7607, ptr %slot1389, align 8
  %v7608 = load i64, ptr %slot1383, align 8
  %p7609 = inttoptr i64 %v7608 to ptr
  %rgep7610 = getelementptr i8, ptr %p7609, i64 -24
  %ld7611 = load i64, ptr %rgep7610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7611, ptr %slot1390, align 8
  %v7612 = load i64, ptr %slot1390, align 8
  %op7613 = sub i64 %v7612, 1
  store i64 %op7613, ptr %slot1391, align 8
  %v7614 = load i64, ptr %slot1391, align 8
  %cmp7615 = icmp eq i64 %v7614, 0
  %cv7616 = zext i1 %cmp7615 to i32
  store i32 %cv7616, ptr %slot1392, align 8
  %v7617 = load i32, ptr %slot1392, align 8
  %cv7618 = zext i32 %v7617 to i64
  %cond7619 = icmp ne i64 %cv7618, 0
  br i1 %cond7619, label %bb_rcglast1911, label %bb_rcgdec1911
bb_rcglast1911:
  %v7620 = load i64, ptr %slot1383, align 8
  %op7621 = sub i64 %v7620, 32
  store i64 %op7621, ptr %slot1393, align 8
  %v7622 = load i64, ptr %slot1383, align 8
  %p7623 = inttoptr i64 %v7622 to ptr
  %rgep7624 = getelementptr i8, ptr %p7623, i64 -32
  %ld7625 = load i64, ptr %rgep7624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7625, ptr %slot1394, align 8
  %v7626 = load i64, ptr %slot1394, align 8
  %cmp7627 = icmp ne i64 %v7626, 0
  %cv7628 = zext i1 %cmp7627 to i32
  store i32 %cv7628, ptr %slot1395, align 8
  %v7629 = load i32, ptr %slot1395, align 8
  %cv7630 = zext i32 %v7629 to i64
  %cond7631 = icmp ne i64 %cv7630, 0
  br i1 %cond7631, label %bb_rcgdec1911, label %bb_rcgslow1911
bb_rcgslow1911:
  %v7632 = load i64, ptr %slot1382, align 8
  %v7633 = load i64, ptr %slot1379, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v7632, i64 %v7633) nomerge, !dbg !182
  br label %bb_rcgdone1911
bb_rcgdec1911:
  %v7634 = load i64, ptr %slot1391, align 8
  %v7635 = load i64, ptr %slot1383, align 8
  %p7636 = inttoptr i64 %v7635 to ptr
  %rgep7637 = getelementptr i8, ptr %p7636, i64 -24
  store i64 %v7634, ptr %rgep7637, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1911
bb_rcgclear1911:
  %v7638 = load i64, ptr %slot1379, align 8
  %p7639 = inttoptr i64 %v7638 to ptr
  store i64 0, ptr %p7639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1911
bb_rcgdone1911:
  br label %bb_rcslotdone1895
bb_rcslotowner1895:
  %v7640 = load i64, ptr %slot64, align 8
  store i64 %v7640, ptr %slot1396, align 8
  %v7641 = load i64, ptr %slot1379, align 8
  %p7642 = inttoptr i64 %v7641 to ptr
  %ld7643 = load i64, ptr %p7642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7643, ptr %slot1397, align 8
  %v7644 = load i64, ptr %slot1397, align 8
  %cmp7645 = icmp ne i64 %v7644, 0
  %cv7646 = zext i1 %cmp7645 to i32
  store i32 %cv7646, ptr %slot1398, align 8
  %v7647 = load i32, ptr %slot1398, align 8
  %cv7648 = zext i32 %v7647 to i64
  %cond7649 = icmp ne i64 %cv7648, 0
  br i1 %cond7649, label %bb_rcgnn1926, label %bb_rcgdone1926
bb_rcgnn1926:
  %v7650 = load i64, ptr %slot1397, align 8
  %op7651 = sub i64 %v7650, 16
  store i64 %op7651, ptr %slot1399, align 8
  %v7652 = load i64, ptr %slot1397, align 8
  %p7653 = inttoptr i64 %v7652 to ptr
  %rgep7654 = getelementptr i8, ptr %p7653, i64 -16
  %ld7655 = load i64, ptr %rgep7654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7655, ptr %slot1400, align 8
  %v7656 = load i64, ptr %slot1400, align 8
  %op7657 = and i64 %v7656, 4611686018427387906
  store i64 %op7657, ptr %slot1401, align 8
  %v7658 = load i64, ptr %slot1401, align 8
  %cmp7659 = icmp ne i64 %v7658, 0
  %cv7660 = zext i1 %cmp7659 to i32
  store i32 %cv7660, ptr %slot1402, align 8
  %v7661 = load i32, ptr %slot1402, align 8
  %cv7662 = zext i32 %v7661 to i64
  %cond7663 = icmp ne i64 %cv7662, 0
  br i1 %cond7663, label %bb_rcgclear1926, label %bb_rcgcounted1926
bb_rcgcounted1926:
  %v7664 = load i64, ptr %slot1397, align 8
  %op7665 = sub i64 %v7664, 32
  store i64 %op7665, ptr %slot1403, align 8
  %v7666 = load i64, ptr %slot1397, align 8
  %p7667 = inttoptr i64 %v7666 to ptr
  %rgep7668 = getelementptr i8, ptr %p7667, i64 -32
  %ld7669 = load i64, ptr %rgep7668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7669, ptr %slot1404, align 8
  %v7670 = load i64, ptr %slot1404, align 8
  %op7671 = sub i64 %v7670, 1
  store i64 %op7671, ptr %slot1405, align 8
  %v7672 = load i64, ptr %slot1405, align 8
  %cmp7673 = icmp eq i64 %v7672, 0
  %cv7674 = zext i1 %cmp7673 to i32
  store i32 %cv7674, ptr %slot1406, align 8
  %v7675 = load i32, ptr %slot1406, align 8
  %cv7676 = zext i32 %v7675 to i64
  %cond7677 = icmp ne i64 %cv7676, 0
  br i1 %cond7677, label %bb_rcglast1926, label %bb_rcgdec1926
bb_rcglast1926:
  %v7678 = load i64, ptr %slot1397, align 8
  %op7679 = sub i64 %v7678, 24
  store i64 %op7679, ptr %slot1407, align 8
  %v7680 = load i64, ptr %slot1397, align 8
  %p7681 = inttoptr i64 %v7680 to ptr
  %rgep7682 = getelementptr i8, ptr %p7681, i64 -24
  %ld7683 = load i64, ptr %rgep7682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7683, ptr %slot1408, align 8
  %v7684 = load i64, ptr %slot1408, align 8
  %cmp7685 = icmp ne i64 %v7684, 0
  %cv7686 = zext i1 %cmp7685 to i32
  store i32 %cv7686, ptr %slot1409, align 8
  %v7687 = load i32, ptr %slot1409, align 8
  %cv7688 = zext i32 %v7687 to i64
  %cond7689 = icmp ne i64 %cv7688, 0
  br i1 %cond7689, label %bb_rcgdec1926, label %bb_rcgslow1926
bb_rcgslow1926:
  %v7690 = load i64, ptr %slot1396, align 8
  %v7691 = load i64, ptr %slot1379, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v7690, i64 %v7691) nomerge, !dbg !182
  br label %bb_rcgdone1926
bb_rcgdec1926:
  %v7692 = load i64, ptr %slot1405, align 8
  %v7693 = load i64, ptr %slot1397, align 8
  %p7694 = inttoptr i64 %v7693 to ptr
  %rgep7695 = getelementptr i8, ptr %p7694, i64 -32
  store i64 %v7692, ptr %rgep7695, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1926
bb_rcgclear1926:
  %v7696 = load i64, ptr %slot1379, align 8
  %p7697 = inttoptr i64 %v7696 to ptr
  store i64 0, ptr %p7697, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1926
bb_rcgdone1926:
  br label %bb_rcslotdone1895
bb_rcslotdone1895:
  %v7698 = load i64, ptr %slot1377, align 8
  %v7699 = load i64, ptr %slot50, align 8
  %p7700 = inttoptr i64 %v7699 to ptr
  store i64 %v7698, ptr %p7700, align 8, !alias.scope !3, !noalias !4
  %v7701 = load i64, ptr %slot46, align 8
  %p7702 = inttoptr i64 %v7701 to ptr
  %ld7703 = load i64, ptr %p7702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7703, ptr %slot1410, align 8
  %v7704 = load i64, ptr %slot1410, align 8
  %v7705 = load i64, ptr %slot53, align 8
  %p7706 = inttoptr i64 %v7705 to ptr
  store i64 %v7704, ptr %p7706, align 8, !alias.scope !3, !noalias !4
  %v7707 = load i64, ptr %slot53, align 8
  %p7708 = inttoptr i64 %v7707 to ptr
  %ld7709 = load i64, ptr %p7708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7709, ptr %slot1411, align 8
  %v7710 = load i64, ptr %slot1411, align 8
  %v7711 = load i64, ptr %slot52, align 8
  %p7712 = inttoptr i64 %v7711 to ptr
  store i64 %v7710, ptr %p7712, align 8, !alias.scope !3, !noalias !4
  %v7713 = load i64, ptr %slot52, align 8
  %p7714 = inttoptr i64 %v7713 to ptr
  %ld7715 = load i64, ptr %p7714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7715, ptr %slot1412, align 8
  %v7716 = load i64, ptr %slot1412, align 8
  %v7717 = load i64, ptr %slot53, align 8
  %p7718 = inttoptr i64 %v7717 to ptr
  store i64 %v7716, ptr %p7718, align 8, !alias.scope !3, !noalias !4
  %v7719 = load i64, ptr %slot54, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  store i64 0, ptr %p7720, align 8, !alias.scope !3, !noalias !4
  %v7721 = load i64, ptr %slot54, align 8
  %p7722 = inttoptr i64 %v7721 to ptr
  %ld7723 = load i64, ptr %p7722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7723, ptr %slot1413, align 8
  %v7724 = load i64, ptr %slot53, align 8
  %p7725 = inttoptr i64 %v7724 to ptr
  %ld7726 = load i64, ptr %p7725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7726, ptr %slot1414, align 8
  %v7727 = load i64, ptr %slot1414, align 8
  %v7728 = load i64, ptr %slot1413, align 8
  %cmp7729 = icmp slt i64 %v7727, %v7728
  %cv7730 = zext i1 %cmp7729 to i64
  store i64 %cv7730, ptr %slot1415, align 8
  %v7731 = load i64, ptr %slot1415, align 8
  %v7732 = load i64, ptr %slot53, align 8
  %p7733 = inttoptr i64 %v7732 to ptr
  store i64 %v7731, ptr %p7733, align 8, !alias.scope !3, !noalias !4
  %v7734 = load i64, ptr %slot53, align 8
  %p7735 = inttoptr i64 %v7734 to ptr
  %ld7736 = load i64, ptr %p7735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7736, ptr %slot1416, align 8
  %v7737 = load i64, ptr %slot1416, align 8
  %cond7738 = icmp ne i64 %v7737, 0
  br i1 %cond7738, label %bb_next1974, label %bb_i80
bb_next1974:
  %v7739 = load i64, ptr %slot50, align 8
  %p7740 = inttoptr i64 %v7739 to ptr
  %ld7741 = load i64, ptr %p7740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7741, ptr %slot1417, align 8
  %v7742 = load i64, ptr %slot1417, align 8
  %op7743 = add i64 %v7742, 0
  store i64 %op7743, ptr %slot1418, align 8
  %v7744 = load i64, ptr %slot1418, align 8
  %p7745 = inttoptr i64 %v7744 to ptr
  %ld7746 = load i64, ptr %p7745, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7746, ptr %slot1419, align 8
  %v7747 = load i64, ptr %slot1419, align 8
  %v7748 = load i64, ptr %slot53, align 8
  %p7749 = inttoptr i64 %v7748 to ptr
  store i64 %v7747, ptr %p7749, align 8, !alias.scope !3, !noalias !4
  %v7750 = load i64, ptr %slot53, align 8
  %p7751 = inttoptr i64 %v7750 to ptr
  %ld7752 = load i64, ptr %p7751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7752, ptr %slot1420, align 8
  %v7753 = load i64, ptr %slot1420, align 8
  %cmp7754 = icmp ugt i64 %v7753, 9223372036854775807
  %cv7755 = zext i1 %cmp7754 to i64
  store i64 %cv7755, ptr %slot1421, align 8
  %v7756 = load i64, ptr %slot1421, align 8
  %cond7757 = icmp ne i64 %v7756, 0
  br i1 %cond7757, label %bb_cast_overflow1979, label %bb_cast_ok1979
bb_cast_overflow1979:
  %v7758 = load i64, ptr %slot1, align 8
  %p7759 = inttoptr i64 %v7758 to ptr
  %v7760 = load i64, ptr %slot1420, align 8
  call void @myl_qbe_fail_cast(ptr %p7759, i64 %v7760, i64 320) nomerge, !dbg !184
  unreachable
bb_cast_ok1979:
  %v7761 = load i64, ptr %slot1420, align 8
  %v7762 = load i64, ptr %slot53, align 8
  %p7763 = inttoptr i64 %v7762 to ptr
  store i64 %v7761, ptr %p7763, align 8, !alias.scope !3, !noalias !4
  %v7764 = load i64, ptr %slot52, align 8
  %p7765 = inttoptr i64 %v7764 to ptr
  %ld7766 = load i64, ptr %p7765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7766, ptr %slot1422, align 8
  %v7767 = load i64, ptr %slot1422, align 8
  %v7768 = load i64, ptr %slot54, align 8
  %p7769 = inttoptr i64 %v7768 to ptr
  store i64 %v7767, ptr %p7769, align 8, !alias.scope !3, !noalias !4
  %v7770 = load i64, ptr %slot54, align 8
  %p7771 = inttoptr i64 %v7770 to ptr
  %ld7772 = load i64, ptr %p7771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7772, ptr %slot1423, align 8
  %v7773 = load i64, ptr %slot53, align 8
  %p7774 = inttoptr i64 %v7773 to ptr
  %ld7775 = load i64, ptr %p7774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7775, ptr %slot1424, align 8
  %v7776 = load i64, ptr %slot1424, align 8
  %v7777 = load i64, ptr %slot1423, align 8
  %ovpair7779 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7776, i64 %v7777)
  %op7778 = extractvalue { i64, i1 } %ovpair7779, 0
  %ov7780 = extractvalue { i64, i1 } %ovpair7779, 1
  store i64 %op7778, ptr %slot1425, align 8
  %v7781 = load i64, ptr %slot1424, align 8
  %v7782 = load i64, ptr %slot1425, align 8
  %op7783 = xor i64 %v7781, %v7782
  store i64 %op7783, ptr %slot1426, align 8
  %v7784 = load i64, ptr %slot1423, align 8
  %v7785 = load i64, ptr %slot1425, align 8
  %op7786 = xor i64 %v7784, %v7785
  store i64 %op7786, ptr %slot1427, align 8
  %v7787 = load i64, ptr %slot1426, align 8
  %v7788 = load i64, ptr %slot1427, align 8
  %op7789 = and i64 %v7787, %v7788
  store i64 %op7789, ptr %slot1428, align 8
  %cv7790 = zext i1 %ov7780 to i64
  store i64 %cv7790, ptr %slot1429, align 8
  %v7791 = load i64, ptr %slot1429, align 8
  %cond7792 = icmp ne i64 %v7791, 0
  br i1 %cond7792, label %bb_overflow1983, label %bb_checked1983
bb_overflow1983:
  %v7793 = load i64, ptr %slot1, align 8
  %p7794 = inttoptr i64 %v7793 to ptr
  %v7795 = load i64, ptr %slot1424, align 8
  %v7796 = load i64, ptr %slot1423, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7794, i64 0, i64 %v7795, i64 %v7796, i64 64) nomerge, !dbg !186
  unreachable
bb_checked1983:
  %v7797 = load i64, ptr %slot1425, align 8
  %v7798 = load i64, ptr %slot53, align 8
  %p7799 = inttoptr i64 %v7798 to ptr
  store i64 %v7797, ptr %p7799, align 8, !alias.scope !3, !noalias !4
  %v7800 = load i64, ptr %slot53, align 8
  %p7801 = inttoptr i64 %v7800 to ptr
  %ld7802 = load i64, ptr %p7801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7802, ptr %slot1430, align 8
  %v7803 = load i64, ptr %slot1430, align 8
  %v7804 = load i64, ptr %slot52, align 8
  %p7805 = inttoptr i64 %v7804 to ptr
  store i64 %v7803, ptr %p7805, align 8, !alias.scope !3, !noalias !4
  br label %bb_i80
bb_i80:
  %v7806 = load i64, ptr %slot52, align 8
  %p7807 = inttoptr i64 %v7806 to ptr
  %ld7808 = load i64, ptr %p7807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7808, ptr %slot1431, align 8
  %v7809 = load i64, ptr %slot1431, align 8
  %v7810 = load i64, ptr %slot53, align 8
  %p7811 = inttoptr i64 %v7810 to ptr
  store i64 %v7809, ptr %p7811, align 8, !alias.scope !3, !noalias !4
  %v7812 = load i64, ptr %slot51, align 8
  %v7813 = load i64, ptr %slot59, align 8
  %p7814 = inttoptr i64 %v7812 to ptr
  %p7815 = inttoptr i64 %v7813 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7815, ptr %p7814, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7816 = load i64, ptr %slot59, align 8
  %v7817 = load i64, ptr %slot54, align 8
  %p7818 = inttoptr i64 %v7817 to ptr
  store i64 %v7816, ptr %p7818, align 8, !alias.scope !3, !noalias !4
  %v7819 = load i64, ptr %slot50, align 8
  %p7820 = inttoptr i64 %v7819 to ptr
  %ld7821 = load i64, ptr %p7820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7821, ptr %slot1432, align 8
  %v7822 = load i64, ptr %slot54, align 8
  %p7823 = inttoptr i64 %v7822 to ptr
  %ld7824 = load i64, ptr %p7823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7824, ptr %slot1433, align 8
  %v7825 = load i64, ptr %slot53, align 8
  %p7826 = inttoptr i64 %v7825 to ptr
  %ld7827 = load i64, ptr %p7826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7827, ptr %slot1434, align 8
  %v7828 = load i64, ptr %slot1432, align 8
  %p7829 = inttoptr i64 %v7828 to ptr
  %ld7830 = load i64, ptr %p7829, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7830, ptr %slot1435, align 8
  %v7831 = load i64, ptr %slot1434, align 8
  %v7832 = load i64, ptr %slot1435, align 8
  %cmp7833 = icmp ult i64 %v7831, %v7832
  %cv7834 = zext i1 %cmp7833 to i64
  store i64 %cv7834, ptr %slot1436, align 8
  %v7835 = load i64, ptr %slot1436, align 8
  %cond7836 = icmp ne i64 %v7835, 0
  br i1 %cond7836, label %bb_success1996, label %bb_failed1996
bb_failed1996:
  %v7837 = load i64, ptr %slot1, align 8
  %p7838 = inttoptr i64 %v7837 to ptr
  %v7839 = load i64, ptr %slot1434, align 8
  %v7840 = load i64, ptr %slot1435, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p7838, i64 %v7839, i64 %v7840) nomerge, !dbg !188
  unreachable
bb_success1996:
  %v7841 = load i64, ptr %slot54, align 8
  %p7842 = inttoptr i64 %v7841 to ptr
  %ld7843 = load i64, ptr %p7842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7843, ptr %slot1437, align 8
  %v7844 = load i64, ptr %slot64, align 8
  %v7845 = load i64, ptr %slot1432, align 8
  %v7846 = load i64, ptr %slot1434, align 8
  %v7847 = load i64, ptr %slot1437, align 8
  %call7848 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v7844, i64 %v7845, i64 %v7846, i64 %v7847) nomerge, !dbg !188
  store i32 %call7848, ptr %slot1438, align 8
  %v7849 = load i32, ptr %slot1438, align 8
  %cv7850 = zext i32 %v7849 to i64
  %cond7851 = icmp ne i64 %cv7850, 0
  br i1 %cond7851, label %bb_success1999, label %bb_failed1999
bb_failed1999:
  %v7852 = load i64, ptr %slot1, align 8
  %p7853 = inttoptr i64 %v7852 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7853) nomerge, !dbg !188
  unreachable
bb_success1999:
  %v7854 = load i64, ptr %slot53, align 8
  %p7855 = inttoptr i64 %v7854 to ptr
  store i64 0, ptr %p7855, align 8, !alias.scope !3, !noalias !4
  %v7856 = load i64, ptr %slot23, align 8
  %p7857 = inttoptr i64 %v7856 to ptr
  %ld7858 = load i32, ptr %p7857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7858, ptr %slot1439, align 8
  %v7859 = load i32, ptr %slot1439, align 8
  %cv7860 = zext i32 %v7859 to i64
  %cond7861 = icmp ne i64 %cv7860, 0
  br i1 %cond7861, label %bb_rcslotdrop2002, label %bb_rcslotdone2002
bb_rcslotdrop2002:
  %v7862 = load i64, ptr %slot23, align 8
  %p7863 = inttoptr i64 %v7862 to ptr
  store i32 0, ptr %p7863, align 4, !alias.scope !3, !noalias !4
  %v7864 = load i64, ptr %slot31, align 8
  store i64 %v7864, ptr %slot1440, align 8
  %v7865 = load i64, ptr %slot24, align 8
  %p7866 = inttoptr i64 %v7865 to ptr
  %ld7867 = load i32, ptr %p7866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7867, ptr %slot1441, align 8
  %v7868 = load i32, ptr %slot1441, align 8
  %op7869 = and i32 %v7868, 28
  store i32 %op7869, ptr %slot1442, align 8
  %v7870 = load i32, ptr %slot1442, align 8
  %cv7871 = zext i32 %v7870 to i64
  %cond7872 = icmp ne i64 %cv7871, 0
  br i1 %cond7872, label %bb_rcslotrole2002, label %bb_rcslotowner2002
bb_rcslotrole2002:
  %v7873 = load i64, ptr %slot64, align 8
  store i64 %v7873, ptr %slot1443, align 8
  %v7874 = load i64, ptr %slot1443, align 8
  %v7875 = load i64, ptr %slot1440, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7874, i64 %v7875) nomerge, !dbg !188
  br label %bb_rcslotdone2002
bb_rcslotowner2002:
  %v7876 = load i64, ptr %slot64, align 8
  store i64 %v7876, ptr %slot1444, align 8
  %v7877 = load i64, ptr %slot1444, align 8
  %v7878 = load i64, ptr %slot1440, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7877, i64 %v7878) nomerge, !dbg !188
  br label %bb_rcslotdone2002
bb_rcslotdone2002:
  %v7879 = load i64, ptr %slot39, align 8
  %p7880 = inttoptr i64 %v7879 to ptr
  %ld7881 = load i64, ptr %p7880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7881, ptr %slot1445, align 8
  %v7882 = load i64, ptr %slot1445, align 8
  %v7883 = load i64, ptr %slot53, align 8
  %p7884 = inttoptr i64 %v7883 to ptr
  store i64 %v7882, ptr %p7884, align 8, !alias.scope !3, !noalias !4
  %v7885 = load i64, ptr %slot53, align 8
  %p7886 = inttoptr i64 %v7885 to ptr
  %ld7887 = load i64, ptr %p7886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7887, ptr %slot1446, align 8
  %v7888 = load i64, ptr %slot1, align 8
  %v7889 = load i64, ptr %slot1446, align 8
  %call7890 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v7888, i64 %v7889) nomerge, !dbg !190
  store { i64, i64 } %call7890, ptr %callresult1448, align 8
  %addr7891 = ptrtoint ptr %callresult1448 to i64
  store i64 %addr7891, ptr %slot1447, align 8
  %v7892 = load i64, ptr %slot1447, align 8
  %v7893 = load i64, ptr %slot53, align 8
  %p7894 = inttoptr i64 %v7893 to ptr
  store i64 %v7892, ptr %p7894, align 8, !alias.scope !3, !noalias !4
  %v7895 = load i64, ptr %slot21, align 8
  %p7896 = inttoptr i64 %v7895 to ptr
  %ld7897 = load i32, ptr %p7896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7897, ptr %slot1449, align 8
  %v7898 = load i32, ptr %slot1449, align 8
  %cv7899 = zext i32 %v7898 to i64
  %cond7900 = icmp ne i64 %cv7899, 0
  br i1 %cond7900, label %bb_rcslotdrop2014, label %bb_rcslotdone2014
bb_rcslotdrop2014:
  %v7901 = load i64, ptr %slot21, align 8
  %p7902 = inttoptr i64 %v7901 to ptr
  store i32 0, ptr %p7902, align 4, !alias.scope !3, !noalias !4
  %v7903 = load i64, ptr %slot30, align 8
  store i64 %v7903, ptr %slot1450, align 8
  %v7904 = load i64, ptr %slot22, align 8
  %p7905 = inttoptr i64 %v7904 to ptr
  %ld7906 = load i32, ptr %p7905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7906, ptr %slot1451, align 8
  %v7907 = load i32, ptr %slot1451, align 8
  %op7908 = and i32 %v7907, 28
  store i32 %op7908, ptr %slot1452, align 8
  %v7909 = load i32, ptr %slot1452, align 8
  %cv7910 = zext i32 %v7909 to i64
  %cond7911 = icmp ne i64 %cv7910, 0
  br i1 %cond7911, label %bb_rcslotrole2014, label %bb_rcslotowner2014
bb_rcslotrole2014:
  %v7912 = load i64, ptr %slot64, align 8
  store i64 %v7912, ptr %slot1453, align 8
  %v7913 = load i64, ptr %slot1453, align 8
  %v7914 = load i64, ptr %slot1450, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7913, i64 %v7914) nomerge, !dbg !190
  br label %bb_rcslotdone2014
bb_rcslotowner2014:
  %v7915 = load i64, ptr %slot64, align 8
  store i64 %v7915, ptr %slot1454, align 8
  %v7916 = load i64, ptr %slot1454, align 8
  %v7917 = load i64, ptr %slot1450, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7916, i64 %v7917) nomerge, !dbg !190
  br label %bb_rcslotdone2014
bb_rcslotdone2014:
  %v7918 = load i64, ptr %slot53, align 8
  %p7919 = inttoptr i64 %v7918 to ptr
  store i64 1, ptr %p7919, align 8, !alias.scope !3, !noalias !4
  %v7920 = load i64, ptr %slot53, align 8
  %p7921 = inttoptr i64 %v7920 to ptr
  %ld7922 = load i64, ptr %p7921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7922, ptr %slot1455, align 8
  %v7923 = load i64, ptr %slot36, align 8
  %p7925 = inttoptr i64 %v7923 to ptr
  %gep7926 = getelementptr i8, ptr %p7925, i64 24
  %op7924 = ptrtoint ptr %gep7926 to i64
  store i64 %op7924, ptr %slot1456, align 8
  %v7927 = load i64, ptr %slot1456, align 8
  %p7928 = inttoptr i64 %v7927 to ptr
  %ld7929 = load i32, ptr %p7928, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7929, ptr %slot1457, align 8
  %v7930 = load i32, ptr %slot1457, align 8
  %cv7931 = zext i32 %v7930 to i64
  %cond7932 = icmp ne i64 %cv7931, 0
  br i1 %cond7932, label %bb_rcscopesopen2024, label %bb_rcscopesclosed2024
bb_rcscopesopen2024:
  %v7933 = load i64, ptr %slot38, align 8
  %p7935 = inttoptr i64 %v7933 to ptr
  %gep7936 = getelementptr i8, ptr %p7935, i64 0
  %op7934 = ptrtoint ptr %gep7936 to i64
  store i64 %op7934, ptr %slot1458, align 8
  %v7937 = load i64, ptr %slot36, align 8
  %v7938 = load i64, ptr %slot1458, align 8
  %p7939 = inttoptr i64 %v7938 to ptr
  store i64 %v7937, ptr %p7939, align 8, !alias.scope !3, !noalias !4
  %v7940 = load i64, ptr %slot1, align 8
  %p7941 = inttoptr i64 %v7940 to ptr
  %v7942 = load i64, ptr %slot38, align 8
  %p7943 = inttoptr i64 %v7942 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7941, ptr %p7943, i64 1) nomerge, !dbg !192
  br label %bb_rcscopesclosed2024
bb_rcscopesclosed2024:
  %v7944 = load i64, ptr %slot21, align 8
  %p7945 = inttoptr i64 %v7944 to ptr
  %ld7946 = load i32, ptr %p7945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7946, ptr %slot1459, align 8
  %v7947 = load i32, ptr %slot1459, align 8
  %cv7948 = zext i32 %v7947 to i64
  %cond7949 = icmp ne i64 %cv7948, 0
  br i1 %cond7949, label %bb_rcslotdrop2028, label %bb_rcslotdone2028
bb_rcslotdrop2028:
  %v7950 = load i64, ptr %slot21, align 8
  %p7951 = inttoptr i64 %v7950 to ptr
  store i32 0, ptr %p7951, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2028
bb_rcslotdone2028:
  %v7952 = load i64, ptr %slot19, align 8
  %p7953 = inttoptr i64 %v7952 to ptr
  %ld7954 = load i32, ptr %p7953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7954, ptr %slot1460, align 8
  %v7955 = load i32, ptr %slot1460, align 8
  %cv7956 = zext i32 %v7955 to i64
  %cond7957 = icmp ne i64 %cv7956, 0
  br i1 %cond7957, label %bb_rcslotdrop2031, label %bb_rcslotdone2031
bb_rcslotdrop2031:
  %v7958 = load i64, ptr %slot19, align 8
  %p7959 = inttoptr i64 %v7958 to ptr
  store i32 0, ptr %p7959, align 4, !alias.scope !3, !noalias !4
  %v7960 = load i64, ptr %slot51, align 8
  store i64 %v7960, ptr %slot1461, align 8
  %v7961 = load i64, ptr %slot20, align 8
  %p7962 = inttoptr i64 %v7961 to ptr
  %ld7963 = load i32, ptr %p7962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7963, ptr %slot1462, align 8
  %v7964 = load i32, ptr %slot1462, align 8
  %op7965 = and i32 %v7964, 28
  store i32 %op7965, ptr %slot1463, align 8
  %v7966 = load i32, ptr %slot1463, align 8
  %cv7967 = zext i32 %v7966 to i64
  %cond7968 = icmp ne i64 %cv7967, 0
  br i1 %cond7968, label %bb_rcslotrole2031, label %bb_rcslotowner2031
bb_rcslotrole2031:
  %v7969 = load i64, ptr %slot64, align 8
  store i64 %v7969, ptr %slot1464, align 8
  %v7970 = load i64, ptr %slot1464, align 8
  %v7971 = load i64, ptr %slot1461, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7970, i64 %v7971) nomerge, !dbg !192
  br label %bb_rcslotdone2031
bb_rcslotowner2031:
  %v7972 = load i64, ptr %slot64, align 8
  store i64 %v7972, ptr %slot1465, align 8
  %v7973 = load i64, ptr %slot1465, align 8
  %v7974 = load i64, ptr %slot1461, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7973, i64 %v7974) nomerge, !dbg !192
  br label %bb_rcslotdone2031
bb_rcslotdone2031:
  %v7975 = load i64, ptr %slot17, align 8
  %p7976 = inttoptr i64 %v7975 to ptr
  %ld7977 = load i32, ptr %p7976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7977, ptr %slot1466, align 8
  %v7978 = load i32, ptr %slot1466, align 8
  %cv7979 = zext i32 %v7978 to i64
  %cond7980 = icmp ne i64 %cv7979, 0
  br i1 %cond7980, label %bb_rcslotdrop2077, label %bb_rcslotdone2077
bb_rcslotdrop2077:
  %v7981 = load i64, ptr %slot17, align 8
  %p7982 = inttoptr i64 %v7981 to ptr
  store i32 0, ptr %p7982, align 4, !alias.scope !3, !noalias !4
  %v7983 = load i64, ptr %slot49, align 8
  store i64 %v7983, ptr %slot1467, align 8
  %v7984 = load i64, ptr %slot18, align 8
  %p7985 = inttoptr i64 %v7984 to ptr
  %ld7986 = load i32, ptr %p7985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7986, ptr %slot1468, align 8
  %v7987 = load i32, ptr %slot1468, align 8
  %op7988 = and i32 %v7987, 28
  store i32 %op7988, ptr %slot1469, align 8
  %v7989 = load i32, ptr %slot1469, align 8
  %cv7990 = zext i32 %v7989 to i64
  %cond7991 = icmp ne i64 %cv7990, 0
  br i1 %cond7991, label %bb_rcslotrole2077, label %bb_rcslotowner2077
bb_rcslotrole2077:
  %v7992 = load i64, ptr %slot64, align 8
  store i64 %v7992, ptr %slot1470, align 8
  %v7993 = load i64, ptr %slot1470, align 8
  %v7994 = load i64, ptr %slot1467, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v7993, i64 %v7994) nomerge, !dbg !192
  br label %bb_rcslotdone2077
bb_rcslotowner2077:
  %v7995 = load i64, ptr %slot64, align 8
  store i64 %v7995, ptr %slot1471, align 8
  %v7996 = load i64, ptr %slot1471, align 8
  %v7997 = load i64, ptr %slot1467, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v7996, i64 %v7997) nomerge, !dbg !192
  br label %bb_rcslotdone2077
bb_rcslotdone2077:
  %v7998 = load i64, ptr %slot15, align 8
  %p7999 = inttoptr i64 %v7998 to ptr
  %ld8000 = load i32, ptr %p7999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8000, ptr %slot1472, align 8
  %v8001 = load i32, ptr %slot1472, align 8
  %cv8002 = zext i32 %v8001 to i64
  %cond8003 = icmp ne i64 %cv8002, 0
  br i1 %cond8003, label %bb_rcslotdrop2086, label %bb_rcslotdone2086
bb_rcslotdrop2086:
  %v8004 = load i64, ptr %slot15, align 8
  %p8005 = inttoptr i64 %v8004 to ptr
  store i32 0, ptr %p8005, align 4, !alias.scope !3, !noalias !4
  %v8006 = load i64, ptr %slot48, align 8
  store i64 %v8006, ptr %slot1473, align 8
  %v8007 = load i64, ptr %slot16, align 8
  %p8008 = inttoptr i64 %v8007 to ptr
  %ld8009 = load i32, ptr %p8008, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8009, ptr %slot1474, align 8
  %v8010 = load i32, ptr %slot1474, align 8
  %op8011 = and i32 %v8010, 28
  store i32 %op8011, ptr %slot1475, align 8
  %v8012 = load i32, ptr %slot1475, align 8
  %cv8013 = zext i32 %v8012 to i64
  %cond8014 = icmp ne i64 %cv8013, 0
  br i1 %cond8014, label %bb_rcslotrole2086, label %bb_rcslotowner2086
bb_rcslotrole2086:
  %v8015 = load i64, ptr %slot64, align 8
  store i64 %v8015, ptr %slot1476, align 8
  %v8016 = load i64, ptr %slot1476, align 8
  %v8017 = load i64, ptr %slot1473, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v8016, i64 %v8017) nomerge, !dbg !192
  br label %bb_rcslotdone2086
bb_rcslotowner2086:
  %v8018 = load i64, ptr %slot64, align 8
  store i64 %v8018, ptr %slot1477, align 8
  %v8019 = load i64, ptr %slot1477, align 8
  %v8020 = load i64, ptr %slot1473, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v8019, i64 %v8020) nomerge, !dbg !192
  br label %bb_rcslotdone2086
bb_rcslotdone2086:
  %v8021 = load i64, ptr %slot13, align 8
  %p8022 = inttoptr i64 %v8021 to ptr
  %ld8023 = load i32, ptr %p8022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8023, ptr %slot1478, align 8
  %v8024 = load i32, ptr %slot1478, align 8
  %cv8025 = zext i32 %v8024 to i64
  %cond8026 = icmp ne i64 %cv8025, 0
  br i1 %cond8026, label %bb_rcslotdrop2095, label %bb_rcslotdone2095
bb_rcslotdrop2095:
  %v8027 = load i64, ptr %slot13, align 8
  %p8028 = inttoptr i64 %v8027 to ptr
  store i32 0, ptr %p8028, align 4, !alias.scope !3, !noalias !4
  %v8029 = load i64, ptr %slot47, align 8
  store i64 %v8029, ptr %slot1479, align 8
  %v8030 = load i64, ptr %slot14, align 8
  %p8031 = inttoptr i64 %v8030 to ptr
  %ld8032 = load i32, ptr %p8031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8032, ptr %slot1480, align 8
  %v8033 = load i32, ptr %slot1480, align 8
  %op8034 = and i32 %v8033, 28
  store i32 %op8034, ptr %slot1481, align 8
  %v8035 = load i32, ptr %slot1481, align 8
  %cv8036 = zext i32 %v8035 to i64
  %cond8037 = icmp ne i64 %cv8036, 0
  br i1 %cond8037, label %bb_rcslotrole2095, label %bb_rcslotowner2095
bb_rcslotrole2095:
  %v8038 = load i64, ptr %slot64, align 8
  store i64 %v8038, ptr %slot1482, align 8
  %v8039 = load i64, ptr %slot1482, align 8
  %v8040 = load i64, ptr %slot1479, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v8039, i64 %v8040) nomerge, !dbg !192
  br label %bb_rcslotdone2095
bb_rcslotowner2095:
  %v8041 = load i64, ptr %slot64, align 8
  store i64 %v8041, ptr %slot1483, align 8
  %v8042 = load i64, ptr %slot1483, align 8
  %v8043 = load i64, ptr %slot1479, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v8042, i64 %v8043) nomerge, !dbg !192
  br label %bb_rcslotdone2095
bb_rcslotdone2095:
  %v8044 = load i64, ptr %slot11, align 8
  %p8045 = inttoptr i64 %v8044 to ptr
  %ld8046 = load i32, ptr %p8045, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8046, ptr %slot1484, align 8
  %v8047 = load i32, ptr %slot1484, align 8
  %cv8048 = zext i32 %v8047 to i64
  %cond8049 = icmp ne i64 %cv8048, 0
  br i1 %cond8049, label %bb_rcslotdrop2104, label %bb_rcslotdone2104
bb_rcslotdrop2104:
  %v8050 = load i64, ptr %slot11, align 8
  %p8051 = inttoptr i64 %v8050 to ptr
  store i32 0, ptr %p8051, align 4, !alias.scope !3, !noalias !4
  %v8052 = load i64, ptr %slot45, align 8
  store i64 %v8052, ptr %slot1485, align 8
  %v8053 = load i64, ptr %slot12, align 8
  %p8054 = inttoptr i64 %v8053 to ptr
  %ld8055 = load i32, ptr %p8054, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8055, ptr %slot1486, align 8
  %v8056 = load i32, ptr %slot1486, align 8
  %op8057 = and i32 %v8056, 28
  store i32 %op8057, ptr %slot1487, align 8
  %v8058 = load i32, ptr %slot1487, align 8
  %cv8059 = zext i32 %v8058 to i64
  %cond8060 = icmp ne i64 %cv8059, 0
  br i1 %cond8060, label %bb_rcslotrole2104, label %bb_rcslotowner2104
bb_rcslotrole2104:
  %v8061 = load i64, ptr %slot64, align 8
  store i64 %v8061, ptr %slot1488, align 8
  %v8062 = load i64, ptr %slot1488, align 8
  %v8063 = load i64, ptr %slot1485, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8062, i64 %v8063) nomerge, !dbg !192
  br label %bb_rcslotdone2104
bb_rcslotowner2104:
  %v8064 = load i64, ptr %slot64, align 8
  store i64 %v8064, ptr %slot1489, align 8
  %v8065 = load i64, ptr %slot1489, align 8
  %v8066 = load i64, ptr %slot1485, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8065, i64 %v8066) nomerge, !dbg !192
  br label %bb_rcslotdone2104
bb_rcslotdone2104:
  %v8067 = load i64, ptr %slot9, align 8
  %p8068 = inttoptr i64 %v8067 to ptr
  %ld8069 = load i32, ptr %p8068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8069, ptr %slot1490, align 8
  %v8070 = load i32, ptr %slot1490, align 8
  %cv8071 = zext i32 %v8070 to i64
  %cond8072 = icmp ne i64 %cv8071, 0
  br i1 %cond8072, label %bb_rcslotdrop2113, label %bb_rcslotdone2113
bb_rcslotdrop2113:
  %v8073 = load i64, ptr %slot9, align 8
  %p8074 = inttoptr i64 %v8073 to ptr
  store i32 0, ptr %p8074, align 4, !alias.scope !3, !noalias !4
  %v8075 = load i64, ptr %slot44, align 8
  store i64 %v8075, ptr %slot1491, align 8
  %v8076 = load i64, ptr %slot10, align 8
  %p8077 = inttoptr i64 %v8076 to ptr
  %ld8078 = load i32, ptr %p8077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8078, ptr %slot1492, align 8
  %v8079 = load i32, ptr %slot1492, align 8
  %op8080 = and i32 %v8079, 28
  store i32 %op8080, ptr %slot1493, align 8
  %v8081 = load i32, ptr %slot1493, align 8
  %cv8082 = zext i32 %v8081 to i64
  %cond8083 = icmp ne i64 %cv8082, 0
  br i1 %cond8083, label %bb_rcslotrole2113, label %bb_rcslotowner2113
bb_rcslotrole2113:
  %v8084 = load i64, ptr %slot64, align 8
  store i64 %v8084, ptr %slot1494, align 8
  %v8085 = load i64, ptr %slot1491, align 8
  %p8086 = inttoptr i64 %v8085 to ptr
  %ld8087 = load i64, ptr %p8086, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8087, ptr %slot1495, align 8
  %v8088 = load i64, ptr %slot1495, align 8
  %cmp8089 = icmp ne i64 %v8088, 0
  %cv8090 = zext i1 %cmp8089 to i32
  store i32 %cv8090, ptr %slot1496, align 8
  %v8091 = load i32, ptr %slot1496, align 8
  %cv8092 = zext i32 %v8091 to i64
  %cond8093 = icmp ne i64 %cv8092, 0
  br i1 %cond8093, label %bb_rcgnn2129, label %bb_rcgdone2129
bb_rcgnn2129:
  %v8094 = load i64, ptr %slot1495, align 8
  %op8095 = sub i64 %v8094, 16
  store i64 %op8095, ptr %slot1497, align 8
  %v8096 = load i64, ptr %slot1495, align 8
  %p8097 = inttoptr i64 %v8096 to ptr
  %rgep8098 = getelementptr i8, ptr %p8097, i64 -16
  %ld8099 = load i64, ptr %rgep8098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8099, ptr %slot1498, align 8
  %v8100 = load i64, ptr %slot1498, align 8
  %op8101 = and i64 %v8100, 4611686018427387906
  store i64 %op8101, ptr %slot1499, align 8
  %v8102 = load i64, ptr %slot1499, align 8
  %cmp8103 = icmp ne i64 %v8102, 0
  %cv8104 = zext i1 %cmp8103 to i32
  store i32 %cv8104, ptr %slot1500, align 8
  %v8105 = load i32, ptr %slot1500, align 8
  %cv8106 = zext i32 %v8105 to i64
  %cond8107 = icmp ne i64 %cv8106, 0
  br i1 %cond8107, label %bb_rcgclear2129, label %bb_rcgcounted2129
bb_rcgcounted2129:
  %v8108 = load i64, ptr %slot1495, align 8
  %op8109 = sub i64 %v8108, 24
  store i64 %op8109, ptr %slot1501, align 8
  %v8110 = load i64, ptr %slot1495, align 8
  %p8111 = inttoptr i64 %v8110 to ptr
  %rgep8112 = getelementptr i8, ptr %p8111, i64 -24
  %ld8113 = load i64, ptr %rgep8112, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8113, ptr %slot1502, align 8
  %v8114 = load i64, ptr %slot1502, align 8
  %op8115 = sub i64 %v8114, 1
  store i64 %op8115, ptr %slot1503, align 8
  %v8116 = load i64, ptr %slot1503, align 8
  %cmp8117 = icmp eq i64 %v8116, 0
  %cv8118 = zext i1 %cmp8117 to i32
  store i32 %cv8118, ptr %slot1504, align 8
  %v8119 = load i32, ptr %slot1504, align 8
  %cv8120 = zext i32 %v8119 to i64
  %cond8121 = icmp ne i64 %cv8120, 0
  br i1 %cond8121, label %bb_rcglast2129, label %bb_rcgdec2129
bb_rcglast2129:
  %v8122 = load i64, ptr %slot1495, align 8
  %op8123 = sub i64 %v8122, 32
  store i64 %op8123, ptr %slot1505, align 8
  %v8124 = load i64, ptr %slot1495, align 8
  %p8125 = inttoptr i64 %v8124 to ptr
  %rgep8126 = getelementptr i8, ptr %p8125, i64 -32
  %ld8127 = load i64, ptr %rgep8126, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8127, ptr %slot1506, align 8
  %v8128 = load i64, ptr %slot1506, align 8
  %cmp8129 = icmp ne i64 %v8128, 0
  %cv8130 = zext i1 %cmp8129 to i32
  store i32 %cv8130, ptr %slot1507, align 8
  %v8131 = load i32, ptr %slot1507, align 8
  %cv8132 = zext i32 %v8131 to i64
  %cond8133 = icmp ne i64 %cv8132, 0
  br i1 %cond8133, label %bb_rcgdec2129, label %bb_rcgslow2129
bb_rcgslow2129:
  %v8134 = load i64, ptr %slot1494, align 8
  %v8135 = load i64, ptr %slot1491, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v8134, i64 %v8135) nomerge, !dbg !192
  br label %bb_rcgdone2129
bb_rcgdec2129:
  %v8136 = load i64, ptr %slot1503, align 8
  %v8137 = load i64, ptr %slot1495, align 8
  %p8138 = inttoptr i64 %v8137 to ptr
  %rgep8139 = getelementptr i8, ptr %p8138, i64 -24
  store i64 %v8136, ptr %rgep8139, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2129
bb_rcgclear2129:
  %v8140 = load i64, ptr %slot1491, align 8
  %p8141 = inttoptr i64 %v8140 to ptr
  store i64 0, ptr %p8141, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2129
bb_rcgdone2129:
  br label %bb_rcslotdone2113
bb_rcslotowner2113:
  %v8142 = load i64, ptr %slot64, align 8
  store i64 %v8142, ptr %slot1508, align 8
  %v8143 = load i64, ptr %slot1491, align 8
  %p8144 = inttoptr i64 %v8143 to ptr
  %ld8145 = load i64, ptr %p8144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8145, ptr %slot1509, align 8
  %v8146 = load i64, ptr %slot1509, align 8
  %cmp8147 = icmp ne i64 %v8146, 0
  %cv8148 = zext i1 %cmp8147 to i32
  store i32 %cv8148, ptr %slot1510, align 8
  %v8149 = load i32, ptr %slot1510, align 8
  %cv8150 = zext i32 %v8149 to i64
  %cond8151 = icmp ne i64 %cv8150, 0
  br i1 %cond8151, label %bb_rcgnn2144, label %bb_rcgdone2144
bb_rcgnn2144:
  %v8152 = load i64, ptr %slot1509, align 8
  %op8153 = sub i64 %v8152, 16
  store i64 %op8153, ptr %slot1511, align 8
  %v8154 = load i64, ptr %slot1509, align 8
  %p8155 = inttoptr i64 %v8154 to ptr
  %rgep8156 = getelementptr i8, ptr %p8155, i64 -16
  %ld8157 = load i64, ptr %rgep8156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8157, ptr %slot1512, align 8
  %v8158 = load i64, ptr %slot1512, align 8
  %op8159 = and i64 %v8158, 4611686018427387906
  store i64 %op8159, ptr %slot1513, align 8
  %v8160 = load i64, ptr %slot1513, align 8
  %cmp8161 = icmp ne i64 %v8160, 0
  %cv8162 = zext i1 %cmp8161 to i32
  store i32 %cv8162, ptr %slot1514, align 8
  %v8163 = load i32, ptr %slot1514, align 8
  %cv8164 = zext i32 %v8163 to i64
  %cond8165 = icmp ne i64 %cv8164, 0
  br i1 %cond8165, label %bb_rcgclear2144, label %bb_rcgcounted2144
bb_rcgcounted2144:
  %v8166 = load i64, ptr %slot1509, align 8
  %op8167 = sub i64 %v8166, 32
  store i64 %op8167, ptr %slot1515, align 8
  %v8168 = load i64, ptr %slot1509, align 8
  %p8169 = inttoptr i64 %v8168 to ptr
  %rgep8170 = getelementptr i8, ptr %p8169, i64 -32
  %ld8171 = load i64, ptr %rgep8170, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8171, ptr %slot1516, align 8
  %v8172 = load i64, ptr %slot1516, align 8
  %op8173 = sub i64 %v8172, 1
  store i64 %op8173, ptr %slot1517, align 8
  %v8174 = load i64, ptr %slot1517, align 8
  %cmp8175 = icmp eq i64 %v8174, 0
  %cv8176 = zext i1 %cmp8175 to i32
  store i32 %cv8176, ptr %slot1518, align 8
  %v8177 = load i32, ptr %slot1518, align 8
  %cv8178 = zext i32 %v8177 to i64
  %cond8179 = icmp ne i64 %cv8178, 0
  br i1 %cond8179, label %bb_rcglast2144, label %bb_rcgdec2144
bb_rcglast2144:
  %v8180 = load i64, ptr %slot1509, align 8
  %op8181 = sub i64 %v8180, 24
  store i64 %op8181, ptr %slot1519, align 8
  %v8182 = load i64, ptr %slot1509, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  %rgep8184 = getelementptr i8, ptr %p8183, i64 -24
  %ld8185 = load i64, ptr %rgep8184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8185, ptr %slot1520, align 8
  %v8186 = load i64, ptr %slot1520, align 8
  %cmp8187 = icmp ne i64 %v8186, 0
  %cv8188 = zext i1 %cmp8187 to i32
  store i32 %cv8188, ptr %slot1521, align 8
  %v8189 = load i32, ptr %slot1521, align 8
  %cv8190 = zext i32 %v8189 to i64
  %cond8191 = icmp ne i64 %cv8190, 0
  br i1 %cond8191, label %bb_rcgdec2144, label %bb_rcgslow2144
bb_rcgslow2144:
  %v8192 = load i64, ptr %slot1508, align 8
  %v8193 = load i64, ptr %slot1491, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v8192, i64 %v8193) nomerge, !dbg !192
  br label %bb_rcgdone2144
bb_rcgdec2144:
  %v8194 = load i64, ptr %slot1517, align 8
  %v8195 = load i64, ptr %slot1509, align 8
  %p8196 = inttoptr i64 %v8195 to ptr
  %rgep8197 = getelementptr i8, ptr %p8196, i64 -32
  store i64 %v8194, ptr %rgep8197, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2144
bb_rcgclear2144:
  %v8198 = load i64, ptr %slot1491, align 8
  %p8199 = inttoptr i64 %v8198 to ptr
  store i64 0, ptr %p8199, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2144
bb_rcgdone2144:
  br label %bb_rcslotdone2113
bb_rcslotdone2113:
  %v8200 = load i64, ptr %slot7, align 8
  %p8201 = inttoptr i64 %v8200 to ptr
  %ld8202 = load i32, ptr %p8201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8202, ptr %slot1522, align 8
  %v8203 = load i32, ptr %slot1522, align 8
  %cv8204 = zext i32 %v8203 to i64
  %cond8205 = icmp ne i64 %cv8204, 0
  br i1 %cond8205, label %bb_rcslotdrop2150, label %bb_rcslotdone2150
bb_rcslotdrop2150:
  %v8206 = load i64, ptr %slot7, align 8
  %p8207 = inttoptr i64 %v8206 to ptr
  store i32 0, ptr %p8207, align 4, !alias.scope !3, !noalias !4
  %v8208 = load i64, ptr %slot43, align 8
  store i64 %v8208, ptr %slot1523, align 8
  %v8209 = load i64, ptr %slot8, align 8
  %p8210 = inttoptr i64 %v8209 to ptr
  %ld8211 = load i32, ptr %p8210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8211, ptr %slot1524, align 8
  %v8212 = load i32, ptr %slot1524, align 8
  %op8213 = and i32 %v8212, 28
  store i32 %op8213, ptr %slot1525, align 8
  %v8214 = load i32, ptr %slot1525, align 8
  %cv8215 = zext i32 %v8214 to i64
  %cond8216 = icmp ne i64 %cv8215, 0
  br i1 %cond8216, label %bb_rcslotrole2150, label %bb_rcslotowner2150
bb_rcslotrole2150:
  %v8217 = load i64, ptr %slot64, align 8
  store i64 %v8217, ptr %slot1526, align 8
  %v8218 = load i64, ptr %slot1526, align 8
  %v8219 = load i64, ptr %slot1523, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8218, i64 %v8219) nomerge, !dbg !192
  br label %bb_rcslotdone2150
bb_rcslotowner2150:
  %v8220 = load i64, ptr %slot64, align 8
  store i64 %v8220, ptr %slot1527, align 8
  %v8221 = load i64, ptr %slot1527, align 8
  %v8222 = load i64, ptr %slot1523, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8221, i64 %v8222) nomerge, !dbg !192
  br label %bb_rcslotdone2150
bb_rcslotdone2150:
  %v8223 = load i64, ptr %slot5, align 8
  %p8224 = inttoptr i64 %v8223 to ptr
  %ld8225 = load i32, ptr %p8224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8225, ptr %slot1528, align 8
  %v8226 = load i32, ptr %slot1528, align 8
  %cv8227 = zext i32 %v8226 to i64
  %cond8228 = icmp ne i64 %cv8227, 0
  br i1 %cond8228, label %bb_rcslotdrop2159, label %bb_rcslotdone2159
bb_rcslotdrop2159:
  %v8229 = load i64, ptr %slot5, align 8
  %p8230 = inttoptr i64 %v8229 to ptr
  store i32 0, ptr %p8230, align 4, !alias.scope !3, !noalias !4
  %v8231 = load i64, ptr %slot42, align 8
  store i64 %v8231, ptr %slot1529, align 8
  %v8232 = load i64, ptr %slot6, align 8
  %p8233 = inttoptr i64 %v8232 to ptr
  %ld8234 = load i32, ptr %p8233, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8234, ptr %slot1530, align 8
  %v8235 = load i32, ptr %slot1530, align 8
  %op8236 = and i32 %v8235, 28
  store i32 %op8236, ptr %slot1531, align 8
  %v8237 = load i32, ptr %slot1531, align 8
  %cv8238 = zext i32 %v8237 to i64
  %cond8239 = icmp ne i64 %cv8238, 0
  br i1 %cond8239, label %bb_rcslotrole2159, label %bb_rcslotowner2159
bb_rcslotrole2159:
  %v8240 = load i64, ptr %slot64, align 8
  store i64 %v8240, ptr %slot1532, align 8
  %v8241 = load i64, ptr %slot1532, align 8
  %v8242 = load i64, ptr %slot1529, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8241, i64 %v8242) nomerge, !dbg !192
  br label %bb_rcslotdone2159
bb_rcslotowner2159:
  %v8243 = load i64, ptr %slot64, align 8
  store i64 %v8243, ptr %slot1533, align 8
  %v8244 = load i64, ptr %slot1533, align 8
  %v8245 = load i64, ptr %slot1529, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8244, i64 %v8245) nomerge, !dbg !192
  br label %bb_rcslotdone2159
bb_rcslotdone2159:
  %v8246 = load i64, ptr %slot1455, align 8
  ret i64 %v8246
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_2988f248bcf7fecf94868b447d50e1ca761d4666b8875670525fa0e5a4347a5f = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_4680c94320ae82d3642670f8407600cccd57188842621865ec871008bcaae5c7(i64, i64, i64)
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64, i64)
declare i64 @myl_f_f8e1b03fbc79fa9be7d2e95e72decf0bafbd87b704304c17055facf7380d1b01(i64, i64, i64)
declare ptr @myl_native_list_copy(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_loan(i64, i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_4d66cd4231d4d1dca45177a9eaa74f584b15e1afd3ce4666fe2966f861de9665", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_4d66cd4231d4d1dca45177a9eaa74f584b15e1afd3ce4666fe2966f861de9665", linkageName: "myl_f_4d66cd4231d4d1dca45177a9eaa74f584b15e1afd3ce4666fe2966f861de9665", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17841779332295640839, i64 0, !"myl_f_4d66cd4231d4d1dca45177a9eaa74f584b15e1afd3ce4666fe2966f861de9665"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!122 = !DILocation(line: 18, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!124 = !DILocation(line: 19, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!130 = !DILocation(line: 22, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!132 = !DILocation(line: 25, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!134 = !DILocation(line: 26, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!136 = !DILocation(line: 27, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!138 = !DILocation(line: 28, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!140 = !DILocation(line: 30, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!142 = !DILocation(line: 31, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!144 = !DILocation(line: 32, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!146 = !DILocation(line: 34, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!148 = !DILocation(line: 35, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!150 = !DILocation(line: 36, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!152 = !DILocation(line: 39, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!154 = !DILocation(line: 43, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!156 = !DILocation(line: 44, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!158 = !DILocation(line: 48, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!160 = !DILocation(line: 49, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!162 = !DILocation(line: 51, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!164 = !DILocation(line: 53, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!166 = !DILocation(line: 55, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!168 = !DILocation(line: 58, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!170 = !DILocation(line: 59, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!172 = !DILocation(line: 60, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!174 = !DILocation(line: 64, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!176 = !DILocation(line: 65, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!178 = !DILocation(line: 66, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!180 = !DILocation(line: 68, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!182 = !DILocation(line: 69, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!184 = !DILocation(line: 77, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!186 = !DILocation(line: 79, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647207)
!188 = !DILocation(line: 84, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!190 = !DILocation(line: 87, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!192 = !DILocation(line: 90, column: 0, scope: !193)
