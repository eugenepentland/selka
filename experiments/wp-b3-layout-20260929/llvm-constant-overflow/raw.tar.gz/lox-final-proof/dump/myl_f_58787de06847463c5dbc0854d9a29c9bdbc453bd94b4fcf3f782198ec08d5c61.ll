target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_58787de06847463c5dbc0854d9a29c9bdbc453bd94b4fcf3f782198ec08d5c61(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v23 = load i64, ptr %slot1, align 8
  %op24 = add i64 %v23, 32
  store i64 %op24, ptr %slot3, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot4, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot5, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot6, align 8
  %v31 = load i64, ptr %slot2, align 8
  %v32 = load i64, ptr %slot4, align 8
  %p33 = inttoptr i64 %v32 to ptr
  store i64 %v31, ptr %p33, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v34 = load i64, ptr %slot4, align 8
  %p35 = inttoptr i64 %v34 to ptr
  %ld36 = load i64, ptr %p35, align 8, !alias.scope !3, !noalias !4
  store i64 %ld36, ptr %slot7, align 8
  %v37 = load i64, ptr %slot7, align 8
  %v38 = load i64, ptr %slot6, align 8
  %p39 = inttoptr i64 %v38 to ptr
  store i64 %v37, ptr %p39, align 8, !alias.scope !3, !noalias !4
  %v40 = load i64, ptr %slot6, align 8
  %p41 = inttoptr i64 %v40 to ptr
  %ld42 = load i64, ptr %p41, align 8, !alias.scope !3, !noalias !4
  store i64 %ld42, ptr %slot8, align 8
  %v43 = load i64, ptr %slot8, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i32, ptr %p44, align 4, !alias.scope !4, !noalias !3
  %ext46 = zext i32 %ld45 to i64
  store i64 %ext46, ptr %slot9, align 8
  %v47 = load i64, ptr %slot9, align 8
  %cmp48 = icmp eq i64 %v47, 0
  %cv49 = zext i1 %cmp48 to i64
  store i64 %cv49, ptr %slot10, align 8
  %v50 = load i64, ptr %slot10, align 8
  %cond51 = icmp ne i64 %v50, 0
  br i1 %cond51, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i2
bb_armnext3:
  %v52 = load i64, ptr %slot9, align 8
  %cmp53 = icmp eq i64 %v52, 1
  %cv54 = zext i1 %cmp53 to i64
  store i64 %cv54, ptr %slot11, align 8
  %v55 = load i64, ptr %slot11, align 8
  %cond56 = icmp ne i64 %v55, 0
  br i1 %cond56, label %bb_arm4, label %bb_armnext4
bb_arm4:
  %v57 = load i64, ptr %slot8, align 8
  %op58 = add i64 %v57, 8
  store i64 %op58, ptr %slot12, align 8
  %v59 = load i64, ptr %slot12, align 8
  %p60 = inttoptr i64 %v59 to ptr
  %ld61 = load i8, ptr %p60, align 1, !alias.scope !4, !noalias !3
  %ext62 = zext i8 %ld61 to i64
  store i64 %ext62, ptr %slot13, align 8
  %v63 = load i64, ptr %slot13, align 8
  %v64 = load i64, ptr %slot5, align 8
  %p65 = inttoptr i64 %v64 to ptr
  store i64 %v63, ptr %p65, align 8, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_armnext4:
  %v66 = load i64, ptr %slot9, align 8
  %cmp67 = icmp eq i64 %v66, 2
  %cv68 = zext i1 %cmp67 to i64
  store i64 %cv68, ptr %slot14, align 8
  %v69 = load i64, ptr %slot14, align 8
  %cond70 = icmp ne i64 %v69, 0
  br i1 %cond70, label %bb_arm7, label %bb_armnext7
bb_arm7:
  br label %bb_i7
bb_armnext7:
  %v71 = load i64, ptr %slot9, align 8
  %cmp72 = icmp eq i64 %v71, 3
  %cv73 = zext i1 %cmp72 to i64
  store i64 %cv73, ptr %slot15, align 8
  %v74 = load i64, ptr %slot15, align 8
  %cond75 = icmp ne i64 %v74, 0
  br i1 %cond75, label %bb_arm8, label %bb_armnext8
bb_arm8:
  br label %bb_i9
bb_armnext8:
  br label %bb_failure
bb_i2:
  %v76 = load i64, ptr %slot6, align 8
  %p77 = inttoptr i64 %v76 to ptr
  store i64 1, ptr %p77, align 8, !alias.scope !3, !noalias !4
  %v78 = load i64, ptr %slot6, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot16, align 8
  %v81 = load i64, ptr %slot16, align 8
  ret i64 %v81
bb_i4:
  %v82 = load i64, ptr %slot5, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot17, align 8
  %v85 = load i64, ptr %slot17, align 8
  %v86 = load i64, ptr %slot6, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot6, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot18, align 8
  %v91 = load i64, ptr %slot18, align 8
  %op92 = xor i64 %v91, 1
  store i64 %op92, ptr %slot19, align 8
  %v93 = load i64, ptr %slot19, align 8
  %v94 = load i64, ptr %slot6, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot6, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot20, align 8
  %v99 = load i64, ptr %slot20, align 8
  ret i64 %v99
bb_i7:
  %v100 = load i64, ptr %slot6, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 0, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot6, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld104, ptr %slot21, align 8
  %v105 = load i64, ptr %slot21, align 8
  ret i64 %v105
bb_i9:
  %v106 = load i64, ptr %slot6, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 0, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot6, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot22, align 8
  %v111 = load i64, ptr %slot22, align 8
  ret i64 %v111
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
