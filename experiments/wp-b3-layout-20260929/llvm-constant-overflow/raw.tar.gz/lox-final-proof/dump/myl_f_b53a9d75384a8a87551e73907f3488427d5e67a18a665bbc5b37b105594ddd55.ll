target triple = "x86_64-unknown-linux-gnu"

define dllexport i32 @myl_f_b53a9d75384a8a87551e73907f3488427d5e67a18a665bbc5b37b105594ddd55(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %callresult73 = alloca [16 x i8], align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %callresult119 = alloca [16 x i8], align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %callresult150 = alloca [4 x i8], align 4
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v158 = load i64, ptr %slot1, align 8
  %op159 = add i64 %v158, 32
  store i64 %op159, ptr %slot5, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot6, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot7, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot8, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot9, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot10, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot11, align 8
  %mem172 = alloca i8, i64 56, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot12, align 8
  %mem174 = alloca i8, i64 208, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot13, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot14, align 8
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot15, align 8
  %mem180 = alloca i8, i64 8, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot16, align 8
  %mem182 = alloca i8, i64 8, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot17, align 8
  %mem184 = alloca i8, i64 8, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot18, align 8
  %mem186 = alloca i8, i64 8, align 8
  %ptr187 = ptrtoint ptr %mem186 to i64
  store i64 %ptr187, ptr %slot19, align 8
  %mem188 = alloca i8, i64 8, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot20, align 8
  %mem190 = alloca i8, i64 8, align 8
  %ptr191 = ptrtoint ptr %mem190 to i64
  store i64 %ptr191, ptr %slot21, align 8
  %mem192 = alloca i8, i64 8, align 8
  %ptr193 = ptrtoint ptr %mem192 to i64
  store i64 %ptr193, ptr %slot22, align 8
  %mem194 = alloca i8, i64 8, align 8
  %ptr195 = ptrtoint ptr %mem194 to i64
  store i64 %ptr195, ptr %slot23, align 8
  %mem196 = alloca i8, i64 208, align 8
  %ptr197 = ptrtoint ptr %mem196 to i64
  store i64 %ptr197, ptr %slot24, align 8
  %mem198 = alloca i8, i64 208, align 8
  %ptr199 = ptrtoint ptr %mem198 to i64
  store i64 %ptr199, ptr %slot25, align 8
  %mem200 = alloca i8, i64 208, align 8
  %ptr201 = ptrtoint ptr %mem200 to i64
  store i64 %ptr201, ptr %slot26, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem202 = alloca i8, i64 8, align 8
  %ptr203 = ptrtoint ptr %mem202 to i64
  store i64 %ptr203, ptr %slot27, align 8
  %v204 = load i64, ptr %slot1, align 8
  %op205 = add i64 %v204, 64
  store i64 %op205, ptr %slot28, align 8
  %v206 = load i64, ptr %slot28, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !4, !noalias !3
  store i64 %ld208, ptr %slot29, align 8
  %stack209 = call ptr @llvm.stacksave()
  %stackaddr210 = ptrtoint ptr %stack209 to i64
  %v211 = load i64, ptr %slot29, align 8
  %cmp212 = icmp ult i64 %stackaddr210, %v211
  %cv213 = zext i1 %cmp212 to i64
  store i64 %cv213, ptr %slot30, align 8
  %v214 = load i64, ptr %slot30, align 8
  %cond215 = icmp ne i64 %v214, 0
  br i1 %cond215, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v216 = load i64, ptr %slot1, align 8
  %p217 = inttoptr i64 %v216 to ptr
  call void @myl_qbe_fail_frame(ptr %p217) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v218 = load i64, ptr %slot2, align 8
  %v219 = load i64, ptr %slot14, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot3, align 8
  %v222 = load i64, ptr %slot15, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  %v224 = load i64, ptr %slot4, align 8
  %v225 = load i64, ptr %slot16, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot1, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %call229 = call ptr @myl_qbe_heap(ptr %p228) nomerge, !dbg !112
  %calladdr230 = ptrtoint ptr %call229 to i64
  store i64 %calladdr230, ptr %slot31, align 8
  %v231 = load i64, ptr %slot1, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %call233 = call i64 @myl_qbe_region_mark(ptr %p232) nomerge, !dbg !112
  store i64 %call233, ptr %slot32, align 8
  %v234 = load i64, ptr %slot7, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i32 0, ptr %p235, align 4, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot8, align 8
  %p237 = inttoptr i64 %v236 to ptr
  store i32 0, ptr %p237, align 4, !alias.scope !3, !noalias !4
  %v238 = load i64, ptr %slot9, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i32 0, ptr %p239, align 4, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot10, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i32 0, ptr %p241, align 4, !alias.scope !3, !noalias !4
  %v242 = load i64, ptr %slot11, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i32 0, ptr %p243, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v244 = load i64, ptr %slot14, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot33, align 8
  %v247 = load i64, ptr %slot33, align 8
  %v248 = load i64, ptr %slot19, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 %v247, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot19, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot34, align 8
  %v253 = load i64, ptr %slot1, align 8
  %v254 = load i64, ptr %slot34, align 8
  %call255 = call i64 @myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3(i64 %v253, i64 %v254) nomerge, !dbg !114
  store i64 %call255, ptr %slot35, align 8
  %v256 = load i64, ptr %slot35, align 8
  %v257 = load i64, ptr %slot19, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i64 %v256, ptr %p258, align 8, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot14, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot36, align 8
  %v262 = load i64, ptr %slot36, align 8
  %v263 = load i64, ptr %slot19, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot15, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot37, align 8
  %v268 = load i64, ptr %slot37, align 8
  %v269 = load i64, ptr %slot20, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot16, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot38, align 8
  %v274 = load i64, ptr %slot38, align 8
  %v275 = load i64, ptr %slot21, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i64 %v274, ptr %p276, align 8, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot19, align 8
  %p278 = inttoptr i64 %v277 to ptr
  %ld279 = load i64, ptr %p278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld279, ptr %slot39, align 8
  %v280 = load i64, ptr %slot20, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot40, align 8
  %v283 = load i64, ptr %slot21, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot41, align 8
  %v286 = load i64, ptr %slot1, align 8
  %v287 = load i64, ptr %slot39, align 8
  %v288 = load i64, ptr %slot40, align 8
  %v289 = load i64, ptr %slot41, align 8
  %call290 = call i64 @myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059(i64 %v286, i64 %v287, i64 %v288, i64 %v289) nomerge, !dbg !116
  store i64 %call290, ptr %slot42, align 8
  %v291 = load i64, ptr %slot42, align 8
  %v292 = load i64, ptr %slot19, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot7, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %ld296 = load i32, ptr %p295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld296, ptr %slot43, align 8
  %v297 = load i32, ptr %slot43, align 8
  %cv298 = zext i32 %v297 to i64
  %cond299 = icmp ne i64 %cv298, 0
  br i1 %cond299, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v300 = load i64, ptr %slot7, align 8
  %p301 = inttoptr i64 %v300 to ptr
  store i32 0, ptr %p301, align 4, !alias.scope !3, !noalias !4
  %v302 = load i64, ptr %slot12, align 8
  store i64 %v302, ptr %slot44, align 8
  %v303 = load i64, ptr %slot8, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i32, ptr %p304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld305, ptr %slot45, align 8
  %v306 = load i32, ptr %slot45, align 8
  %op307 = and i32 %v306, 28
  store i32 %op307, ptr %slot46, align 8
  %v308 = load i32, ptr %slot46, align 8
  %cv309 = zext i32 %v308 to i64
  %cond310 = icmp ne i64 %cv309, 0
  br i1 %cond310, label %bb_rcslotrole40, label %bb_rcslotowner40
bb_rcslotrole40:
  %v311 = load i64, ptr %slot31, align 8
  store i64 %v311, ptr %slot47, align 8
  %v312 = load i64, ptr %slot47, align 8
  %v313 = load i64, ptr %slot44, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v312, i64 %v313) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotowner40:
  %v314 = load i64, ptr %slot31, align 8
  store i64 %v314, ptr %slot48, align 8
  %v315 = load i64, ptr %slot48, align 8
  %v316 = load i64, ptr %slot44, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v315, i64 %v316) nomerge, !dbg !116
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v317 = load i64, ptr %slot19, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot49, align 8
  %v320 = load i64, ptr %slot49, align 8
  %v321 = load i64, ptr %slot17, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot17, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot50, align 8
  %v326 = load i64, ptr %slot50, align 8
  %v327 = load i64, ptr %slot19, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot20, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 18446744073709551615, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot20, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %ld333 = load i64, ptr %p332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld333, ptr %slot51, align 8
  %v334 = load i64, ptr %slot19, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot52, align 8
  %v337 = load i64, ptr %slot52, align 8
  %v338 = load i64, ptr %slot51, align 8
  %cmp339 = icmp eq i64 %v337, %v338
  %cv340 = zext i1 %cmp339 to i64
  store i64 %cv340, ptr %slot53, align 8
  %v341 = load i64, ptr %slot53, align 8
  %v342 = load i64, ptr %slot19, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 %v341, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot19, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i64, ptr %p345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot54, align 8
  %v347 = load i64, ptr %slot54, align 8
  %cond348 = icmp ne i64 %v347, 0
  br i1 %cond348, label %bb_next90, label %bb_i14
bb_next90:
  %v349 = load i64, ptr %slot23, align 8
  store i64 %v349, ptr %slot55, align 8
  %v350 = load i64, ptr %slot55, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 0, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot55, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot55, align 8
  %v355 = load i64, ptr %slot19, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i64 %v354, ptr %p356, align 8, !alias.scope !3, !noalias !4
  %v357 = load i64, ptr %slot19, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot56, align 8
  %v360 = load i64, ptr %slot56, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ret362 = load i32, ptr %p361, align 4
  ret i32 %ret362
bb_i14:
  %v363 = load i64, ptr %slot14, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot57, align 8
  %v366 = load i64, ptr %slot57, align 8
  %v367 = load i64, ptr %slot19, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i64 %v366, ptr %p368, align 8, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot17, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot58, align 8
  %v372 = load i64, ptr %slot58, align 8
  %v373 = load i64, ptr %slot20, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i64 %v372, ptr %p374, align 8, !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot24, align 8
  store i64 %v375, ptr %slot59, align 8
  %v376 = load i64, ptr %slot59, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i64 0, ptr %p377, align 8, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot59, align 8
  %p380 = inttoptr i64 %v378 to ptr
  %gep381 = getelementptr i8, ptr %p380, i64 8
  %op379 = ptrtoint ptr %gep381 to i64
  store i64 %op379, ptr %slot60, align 8
  %v382 = load i64, ptr %slot60, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 0, ptr %p383, align 8, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot59, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i32 3, ptr %p385, align 4, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot11, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 1, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot20, align 8
  store i64 %v388, ptr %slot61, align 8
  %v389 = load i64, ptr %slot59, align 8
  %p391 = inttoptr i64 %v389 to ptr
  %gep392 = getelementptr i8, ptr %p391, i64 8
  %op390 = ptrtoint ptr %gep392 to i64
  store i64 %op390, ptr %slot62, align 8
  %v393 = load i64, ptr %slot32, align 8
  store i64 %v393, ptr %slot63, align 8
  %v394 = load i64, ptr %slot61, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot64, align 8
  %v397 = load i64, ptr %slot64, align 8
  %v398 = load i64, ptr %slot62, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 %v397, ptr %p399, align 8, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot59, align 8
  %v401 = load i64, ptr %slot20, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 %v400, ptr %p402, align 8, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot19, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot65, align 8
  %v406 = load i64, ptr %slot20, align 8
  %p407 = inttoptr i64 %v406 to ptr
  %ld408 = load i64, ptr %p407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld408, ptr %slot66, align 8
  %v409 = load i64, ptr %slot1, align 8
  %v410 = load i64, ptr %slot65, align 8
  %v411 = load i64, ptr %slot66, align 8
  %call412 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v409, i64 %v410, i64 %v411) nomerge, !dbg !118
  store i64 %call412, ptr %slot67, align 8
  %v413 = load i64, ptr %slot67, align 8
  %v414 = load i64, ptr %slot19, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i64 %v413, ptr %p415, align 8, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot14, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i64, ptr %p417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld418, ptr %slot68, align 8
  %v419 = load i64, ptr %slot68, align 8
  %v420 = load i64, ptr %slot19, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 %v419, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot17, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot69, align 8
  %v425 = load i64, ptr %slot69, align 8
  %v426 = load i64, ptr %slot20, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i64 %v425, ptr %p427, align 8, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot21, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 0, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot20, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot70, align 8
  %v433 = load i64, ptr %slot21, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i64, ptr %p434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld435, ptr %slot71, align 8
  %v436 = load i64, ptr %slot1, align 8
  %v437 = load i64, ptr %slot70, align 8
  %v438 = load i64, ptr %slot71, align 8
  %call439 = call { i64, i64 } @myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71(i64 %v436, i64 %v437, i64 %v438) nomerge, !dbg !120
  store { i64, i64 } %call439, ptr %callresult73, align 8
  %addr440 = ptrtoint ptr %callresult73 to i64
  store i64 %addr440, ptr %slot72, align 8
  %v441 = load i64, ptr %slot72, align 8
  %v442 = load i64, ptr %slot20, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i64 %v441, ptr %p443, align 8, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot20, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot74, align 8
  %v447 = load i64, ptr %slot13, align 8
  store i64 %v447, ptr %slot75, align 8
  %v448 = load i64, ptr %slot74, align 8
  %v449 = load i64, ptr %slot75, align 8
  %p450 = inttoptr i64 %v448 to ptr
  %p451 = inttoptr i64 %v449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p451, ptr %p450, i64 16, i1 false)
  %v452 = load i64, ptr %slot10, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i32 2, ptr %p453, align 4, !alias.scope !3, !noalias !4
  %v454 = load i64, ptr %slot9, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i32 1, ptr %p455, align 4, !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot12, align 8
  store i64 %v456, ptr %slot76, align 8
  %v457 = load i64, ptr %slot13, align 8
  store i64 %v457, ptr %slot77, align 8
  %v458 = load i64, ptr %slot77, align 8
  %v459 = load i64, ptr %slot76, align 8
  %p460 = inttoptr i64 %v458 to ptr
  %p461 = inttoptr i64 %v459 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p461, ptr %p460, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot8, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i32 2, ptr %p463, align 4, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot10, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i32, ptr %p465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld466, ptr %slot78, align 8
  %v467 = load i32, ptr %slot78, align 8
  %v468 = load i64, ptr %slot8, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 %v467, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot9, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 0, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot7, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 1, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot76, align 8
  %v475 = load i64, ptr %slot20, align 8
  %p476 = inttoptr i64 %v475 to ptr
  store i64 %v474, ptr %p476, align 8, !alias.scope !3, !noalias !4
  %v477 = load i64, ptr %slot25, align 8
  store i64 %v477, ptr %slot79, align 8
  %v478 = load i64, ptr %slot79, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i64 0, ptr %p479, align 8, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot79, align 8
  %p482 = inttoptr i64 %v480 to ptr
  %gep483 = getelementptr i8, ptr %p482, i64 8
  %op481 = ptrtoint ptr %gep483 to i64
  store i64 %op481, ptr %slot80, align 8
  %v484 = load i64, ptr %slot80, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i64 0, ptr %p485, align 8, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot79, align 8
  %p488 = inttoptr i64 %v486 to ptr
  %gep489 = getelementptr i8, ptr %p488, i64 16
  %op487 = ptrtoint ptr %gep489 to i64
  store i64 %op487, ptr %slot81, align 8
  %v490 = load i64, ptr %slot81, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 0, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot79, align 8
  %p494 = inttoptr i64 %v492 to ptr
  %gep495 = getelementptr i8, ptr %p494, i64 24
  %op493 = ptrtoint ptr %gep495 to i64
  store i64 %op493, ptr %slot82, align 8
  %v496 = load i64, ptr %slot82, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 0, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot79, align 8
  %p500 = inttoptr i64 %v498 to ptr
  %gep501 = getelementptr i8, ptr %p500, i64 32
  %op499 = ptrtoint ptr %gep501 to i64
  store i64 %op499, ptr %slot83, align 8
  %v502 = load i64, ptr %slot83, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 0, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot79, align 8
  %p506 = inttoptr i64 %v504 to ptr
  %gep507 = getelementptr i8, ptr %p506, i64 40
  %op505 = ptrtoint ptr %gep507 to i64
  store i64 %op505, ptr %slot84, align 8
  %v508 = load i64, ptr %slot84, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 0, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot79, align 8
  %p512 = inttoptr i64 %v510 to ptr
  %gep513 = getelementptr i8, ptr %p512, i64 48
  %op511 = ptrtoint ptr %gep513 to i64
  store i64 %op511, ptr %slot85, align 8
  %v514 = load i64, ptr %slot85, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 0, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot79, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 4, ptr %p517, align 4, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot11, align 8
  %p519 = inttoptr i64 %v518 to ptr
  store i32 1, ptr %p519, align 4, !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot20, align 8
  %p521 = inttoptr i64 %v520 to ptr
  %ld522 = load i64, ptr %p521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld522, ptr %slot86, align 8
  %v523 = load i64, ptr %slot79, align 8
  %p525 = inttoptr i64 %v523 to ptr
  %gep526 = getelementptr i8, ptr %p525, i64 8
  %op524 = ptrtoint ptr %gep526 to i64
  store i64 %op524, ptr %slot87, align 8
  %v527 = load i64, ptr %slot32, align 8
  store i64 %v527, ptr %slot88, align 8
  %v528 = load i64, ptr %slot20, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot89, align 8
  %v531 = load i64, ptr %slot13, align 8
  store i64 %v531, ptr %slot90, align 8
  %v532 = load i64, ptr %slot32, align 8
  store i64 %v532, ptr %slot91, align 8
  %v533 = load i64, ptr %slot89, align 8
  %op534 = add i64 %v533, 8
  store i64 %op534, ptr %slot92, align 8
  %v535 = load i64, ptr %slot92, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8
  store i64 %ld537, ptr %slot93, align 8
  %v538 = load i64, ptr %slot93, align 8
  %cmp539 = icmp ne i64 %v538, 0
  %cv540 = zext i1 %cmp539 to i32
  store i32 %cv540, ptr %slot94, align 8
  %v541 = load i32, ptr %slot94, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcmoveheader207, label %bb_rcmovenext207
bb_rcmoveheader207:
  %v544 = load i64, ptr %slot93, align 8
  %op545 = sub i64 %v544, 16
  store i64 %op545, ptr %slot95, align 8
  %v546 = load i64, ptr %slot93, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %rgep548 = getelementptr i8, ptr %p547, i64 -16
  %ld549 = load i64, ptr %rgep548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld549, ptr %slot96, align 8
  %v550 = load i64, ptr %slot96, align 8
  %op551 = and i64 %v550, 5764607523034234881
  store i64 %op551, ptr %slot97, align 8
  %v552 = load i64, ptr %slot97, align 8
  %cmp553 = icmp ne i64 %v552, 0
  %cv554 = zext i1 %cmp553 to i32
  store i32 %cv554, ptr %slot98, align 8
  %v555 = load i32, ptr %slot98, align 8
  %cv556 = zext i32 %v555 to i64
  %cond557 = icmp ne i64 %cv556, 0
  br i1 %cond557, label %bb_rcmoveslow204, label %bb_rcmovenext207
bb_rcmovenext207:
  %v558 = load i64, ptr %slot89, align 8
  %v559 = load i64, ptr %slot90, align 8
  %p560 = inttoptr i64 %v558 to ptr
  %p561 = inttoptr i64 %v559 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p561, ptr %p560, i64 16, i1 false)
  %v562 = load i64, ptr %slot89, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 0, ptr %p563, align 8
  %v564 = load i64, ptr %slot89, align 8
  %op565 = add i64 %v564, 8
  store i64 %op565, ptr %slot99, align 8
  %v566 = load i64, ptr %slot99, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 0, ptr %p567, align 8
  br label %bb_rcmoved204
bb_rcmoveslow204:
  %v568 = load i64, ptr %slot31, align 8
  %v569 = load i64, ptr %slot90, align 8
  %v570 = load i64, ptr %slot89, align 8
  %v571 = load i64, ptr %slot91, align 8
  %cv572 = trunc i64 %v571 to i32
  %call573 = call i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64 %v568, i64 %v569, i64 %v570, i32 %cv572) nomerge, !dbg !122
  store i32 %call573, ptr %slot100, align 8
  %v574 = load i32, ptr %slot100, align 8
  %cv575 = zext i32 %v574 to i64
  %cond576 = icmp ne i64 %cv575, 0
  br i1 %cond576, label %bb_rcsuccess215, label %bb_rcfailure215
bb_rcfailure215:
  %v577 = load i64, ptr %slot31, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %call579 = call i32 @myl_rc_take_failure(ptr %p578) nomerge, !dbg !122
  store i32 %call579, ptr %slot101, align 8
  %v580 = load i64, ptr %slot1, align 8
  %p581 = inttoptr i64 %v580 to ptr
  %v582 = load i32, ptr %slot101, align 8
  %call583 = call i32 @myl_qbe_rc_status(ptr %p581, i32 %v582) nomerge, !dbg !122
  store i32 %call583, ptr %slot102, align 8
  br label %bb_failure
bb_rcsuccess215:
  br label %bb_rcmoved204
bb_rcmoved204:
  %v584 = load i64, ptr %slot7, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i32 0, ptr %p585, align 4, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot10, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i32 2, ptr %p587, align 4, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot9, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 1, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot13, align 8
  store i64 %v590, ptr %slot103, align 8
  %v591 = load i64, ptr %slot103, align 8
  %v592 = load i64, ptr %slot87, align 8
  %p593 = inttoptr i64 %v591 to ptr
  %p594 = inttoptr i64 %v592 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p594, ptr %p593, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot9, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i32 0, ptr %p596, align 4, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot79, align 8
  %v598 = load i64, ptr %slot20, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 %v597, ptr %p599, align 8, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot20, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i64, ptr %p601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld602, ptr %slot104, align 8
  %v603 = load i64, ptr %slot12, align 8
  store i64 %v603, ptr %slot105, align 8
  %v604 = load i64, ptr %slot104, align 8
  %v605 = load i64, ptr %slot105, align 8
  %p606 = inttoptr i64 %v604 to ptr
  %p607 = inttoptr i64 %v605 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p607, ptr %p606, i64 56, i1 false)
  %v608 = load i64, ptr %slot8, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i32 2, ptr %p609, align 4, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot7, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i32 1, ptr %p611, align 4, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot105, align 8
  %v613 = load i64, ptr %slot20, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i64 %v612, ptr %p614, align 8, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot19, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %ld617 = load i64, ptr %p616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld617, ptr %slot106, align 8
  %v618 = load i64, ptr %slot20, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %ld620 = load i64, ptr %p619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld620, ptr %slot107, align 8
  %v621 = load i64, ptr %slot1, align 8
  %v622 = load i64, ptr %slot106, align 8
  %v623 = load i64, ptr %slot107, align 8
  %call624 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v621, i64 %v622, i64 %v623) nomerge, !dbg !124
  store i64 %call624, ptr %slot108, align 8
  %v625 = load i64, ptr %slot108, align 8
  %v626 = load i64, ptr %slot19, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i64 %v625, ptr %p627, align 8, !alias.scope !3, !noalias !4
  %v628 = load i64, ptr %slot7, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i32, ptr %p629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld630, ptr %slot109, align 8
  %v631 = load i32, ptr %slot109, align 8
  %cv632 = zext i32 %v631 to i64
  %cond633 = icmp ne i64 %cv632, 0
  br i1 %cond633, label %bb_rcslotdrop241, label %bb_rcslotdone241
bb_rcslotdrop241:
  %v634 = load i64, ptr %slot7, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i32 0, ptr %p635, align 4, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot12, align 8
  store i64 %v636, ptr %slot110, align 8
  %v637 = load i64, ptr %slot8, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i32, ptr %p638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld639, ptr %slot111, align 8
  %v640 = load i32, ptr %slot111, align 8
  %op641 = and i32 %v640, 28
  store i32 %op641, ptr %slot112, align 8
  %v642 = load i32, ptr %slot112, align 8
  %cv643 = zext i32 %v642 to i64
  %cond644 = icmp ne i64 %cv643, 0
  br i1 %cond644, label %bb_rcslotrole241, label %bb_rcslotowner241
bb_rcslotrole241:
  %v645 = load i64, ptr %slot31, align 8
  store i64 %v645, ptr %slot113, align 8
  %v646 = load i64, ptr %slot113, align 8
  %v647 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v646, i64 %v647) nomerge, !dbg !124
  br label %bb_rcslotdone241
bb_rcslotowner241:
  %v648 = load i64, ptr %slot31, align 8
  store i64 %v648, ptr %slot114, align 8
  %v649 = load i64, ptr %slot114, align 8
  %v650 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v649, i64 %v650) nomerge, !dbg !124
  br label %bb_rcslotdone241
bb_rcslotdone241:
  %v651 = load i64, ptr %slot19, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot115, align 8
  %v654 = load i64, ptr %slot115, align 8
  %v655 = load i64, ptr %slot18, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i64 %v654, ptr %p656, align 8, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot14, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot116, align 8
  %v660 = load i64, ptr %slot116, align 8
  %v661 = load i64, ptr %slot19, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot19, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot117, align 8
  %v666 = load i64, ptr %slot1, align 8
  %v667 = load i64, ptr %slot117, align 8
  %call668 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v666, i64 %v667) nomerge, !dbg !126
  store { i64, i64 } %call668, ptr %callresult119, align 8
  %addr669 = ptrtoint ptr %callresult119 to i64
  store i64 %addr669, ptr %slot118, align 8
  %v670 = load i64, ptr %slot118, align 8
  %v671 = load i64, ptr %slot19, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i64 %v670, ptr %p672, align 8, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot14, align 8
  %p674 = inttoptr i64 %v673 to ptr
  %ld675 = load i64, ptr %p674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld675, ptr %slot120, align 8
  %v676 = load i64, ptr %slot120, align 8
  %v677 = load i64, ptr %slot19, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i64 %v676, ptr %p678, align 8, !alias.scope !3, !noalias !4
  %v679 = load i64, ptr %slot18, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %ld681 = load i64, ptr %p680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld681, ptr %slot121, align 8
  %v682 = load i64, ptr %slot121, align 8
  %v683 = load i64, ptr %slot20, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i64 %v682, ptr %p684, align 8, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot26, align 8
  store i64 %v685, ptr %slot122, align 8
  %v686 = load i64, ptr %slot122, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 0, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot122, align 8
  %p690 = inttoptr i64 %v688 to ptr
  %gep691 = getelementptr i8, ptr %p690, i64 8
  %op689 = ptrtoint ptr %gep691 to i64
  store i64 %op689, ptr %slot123, align 8
  %v692 = load i64, ptr %slot123, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 0, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot122, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i32 3, ptr %p695, align 4, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot11, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i32 1, ptr %p697, align 4, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot20, align 8
  store i64 %v698, ptr %slot124, align 8
  %v699 = load i64, ptr %slot122, align 8
  %p701 = inttoptr i64 %v699 to ptr
  %gep702 = getelementptr i8, ptr %p701, i64 8
  %op700 = ptrtoint ptr %gep702 to i64
  store i64 %op700, ptr %slot125, align 8
  %v703 = load i64, ptr %slot32, align 8
  store i64 %v703, ptr %slot126, align 8
  %v704 = load i64, ptr %slot124, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %ld706 = load i64, ptr %p705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld706, ptr %slot127, align 8
  %v707 = load i64, ptr %slot127, align 8
  %v708 = load i64, ptr %slot125, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i64 %v707, ptr %p709, align 8, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot122, align 8
  %v711 = load i64, ptr %slot20, align 8
  %p712 = inttoptr i64 %v711 to ptr
  store i64 %v710, ptr %p712, align 8, !alias.scope !3, !noalias !4
  %v713 = load i64, ptr %slot19, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %ld715 = load i64, ptr %p714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld715, ptr %slot128, align 8
  %v716 = load i64, ptr %slot20, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot129, align 8
  %v719 = load i64, ptr %slot1, align 8
  %v720 = load i64, ptr %slot128, align 8
  %v721 = load i64, ptr %slot129, align 8
  %call722 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v719, i64 %v720, i64 %v721) nomerge, !dbg !128
  store i64 %call722, ptr %slot130, align 8
  %v723 = load i64, ptr %slot130, align 8
  %v724 = load i64, ptr %slot19, align 8
  %p725 = inttoptr i64 %v724 to ptr
  store i64 %v723, ptr %p725, align 8, !alias.scope !3, !noalias !4
  %v726 = load i64, ptr %slot14, align 8
  %p727 = inttoptr i64 %v726 to ptr
  %ld728 = load i64, ptr %p727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld728, ptr %slot131, align 8
  %v729 = load i64, ptr %slot131, align 8
  %v730 = load i64, ptr %slot19, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i64 %v729, ptr %p731, align 8, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot15, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot132, align 8
  %v735 = load i64, ptr %slot132, align 8
  %v736 = load i64, ptr %slot20, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i64 %v735, ptr %p737, align 8, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot18, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot133, align 8
  %v741 = load i64, ptr %slot133, align 8
  %v742 = load i64, ptr %slot21, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i64 %v741, ptr %p743, align 8, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot22, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 0, ptr %p745, align 8, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot19, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i64, ptr %p747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld748, ptr %slot134, align 8
  %v749 = load i64, ptr %slot20, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %ld751 = load i64, ptr %p750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld751, ptr %slot135, align 8
  %v752 = load i64, ptr %slot21, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i64, ptr %p753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld754, ptr %slot136, align 8
  %v755 = load i64, ptr %slot22, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %ld757 = load i64, ptr %p756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld757, ptr %slot137, align 8
  %v758 = load i64, ptr %slot1, align 8
  %v759 = load i64, ptr %slot134, align 8
  %v760 = load i64, ptr %slot135, align 8
  %v761 = load i64, ptr %slot136, align 8
  %v762 = load i64, ptr %slot137, align 8
  %call763 = call i64 @myl_f_e6dd1a9167d6b59c9752b8305d109d76520bac8300dd423db9728be656322e7c(i64 %v758, i64 %v759, i64 %v760, i64 %v761, i64 %v762) nomerge, !dbg !130
  store i64 %call763, ptr %slot138, align 8
  %v764 = load i64, ptr %slot138, align 8
  %v765 = load i64, ptr %slot19, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i64 %v764, ptr %p766, align 8, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot7, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i32, ptr %p768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld769, ptr %slot139, align 8
  %v770 = load i32, ptr %slot139, align 8
  %cv771 = zext i32 %v770 to i64
  %cond772 = icmp ne i64 %cv771, 0
  br i1 %cond772, label %bb_rcslotdrop302, label %bb_rcslotdone302
bb_rcslotdrop302:
  %v773 = load i64, ptr %slot7, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i32 0, ptr %p774, align 4, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot12, align 8
  store i64 %v775, ptr %slot140, align 8
  %v776 = load i64, ptr %slot8, align 8
  %p777 = inttoptr i64 %v776 to ptr
  %ld778 = load i32, ptr %p777, align 4, !alias.scope !3, !noalias !4
  store i32 %ld778, ptr %slot141, align 8
  %v779 = load i32, ptr %slot141, align 8
  %op780 = and i32 %v779, 28
  store i32 %op780, ptr %slot142, align 8
  %v781 = load i32, ptr %slot142, align 8
  %cv782 = zext i32 %v781 to i64
  %cond783 = icmp ne i64 %cv782, 0
  br i1 %cond783, label %bb_rcslotrole302, label %bb_rcslotowner302
bb_rcslotrole302:
  %v784 = load i64, ptr %slot31, align 8
  store i64 %v784, ptr %slot143, align 8
  %v785 = load i64, ptr %slot143, align 8
  %v786 = load i64, ptr %slot140, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v785, i64 %v786) nomerge, !dbg !130
  br label %bb_rcslotdone302
bb_rcslotowner302:
  %v787 = load i64, ptr %slot31, align 8
  store i64 %v787, ptr %slot144, align 8
  %v788 = load i64, ptr %slot144, align 8
  %v789 = load i64, ptr %slot140, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v788, i64 %v789) nomerge, !dbg !130
  br label %bb_rcslotdone302
bb_rcslotdone302:
  %v790 = load i64, ptr %slot14, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i64, ptr %p791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld792, ptr %slot145, align 8
  %v793 = load i64, ptr %slot145, align 8
  %v794 = load i64, ptr %slot19, align 8
  %p795 = inttoptr i64 %v794 to ptr
  store i64 %v793, ptr %p795, align 8, !alias.scope !3, !noalias !4
  %v796 = load i64, ptr %slot15, align 8
  %p797 = inttoptr i64 %v796 to ptr
  %ld798 = load i64, ptr %p797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld798, ptr %slot146, align 8
  %v799 = load i64, ptr %slot146, align 8
  %v800 = load i64, ptr %slot20, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i64 %v799, ptr %p801, align 8, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot19, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i64, ptr %p803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld804, ptr %slot147, align 8
  %v805 = load i64, ptr %slot20, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i64, ptr %p806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld807, ptr %slot148, align 8
  %v808 = load i64, ptr %slot1, align 8
  %v809 = load i64, ptr %slot147, align 8
  %v810 = load i64, ptr %slot148, align 8
  %call811 = call i32 @myl_f_a0e96f299197f34d601c1a9da1cbd514090305d2a21036d06ba179b733ea6e29(i64 %v808, i64 %v809, i64 %v810) nomerge, !dbg !132
  store i32 %call811, ptr %callresult150, align 4
  %addr812 = ptrtoint ptr %callresult150 to i64
  store i64 %addr812, ptr %slot149, align 8
  %v813 = load i64, ptr %slot149, align 8
  %v814 = load i64, ptr %slot19, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 %v813, ptr %p815, align 8, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot7, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i32, ptr %p817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld818, ptr %slot151, align 8
  %v819 = load i32, ptr %slot151, align 8
  %cv820 = zext i32 %v819 to i64
  %cond821 = icmp ne i64 %cv820, 0
  br i1 %cond821, label %bb_rcslotdrop325, label %bb_rcslotdone325
bb_rcslotdrop325:
  %v822 = load i64, ptr %slot7, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i32 0, ptr %p823, align 4, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot12, align 8
  store i64 %v824, ptr %slot152, align 8
  %v825 = load i64, ptr %slot8, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i32, ptr %p826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld827, ptr %slot153, align 8
  %v828 = load i32, ptr %slot153, align 8
  %op829 = and i32 %v828, 28
  store i32 %op829, ptr %slot154, align 8
  %v830 = load i32, ptr %slot154, align 8
  %cv831 = zext i32 %v830 to i64
  %cond832 = icmp ne i64 %cv831, 0
  br i1 %cond832, label %bb_rcslotrole325, label %bb_rcslotowner325
bb_rcslotrole325:
  %v833 = load i64, ptr %slot31, align 8
  store i64 %v833, ptr %slot155, align 8
  %v834 = load i64, ptr %slot155, align 8
  %v835 = load i64, ptr %slot152, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v834, i64 %v835) nomerge, !dbg !132
  br label %bb_rcslotdone325
bb_rcslotowner325:
  %v836 = load i64, ptr %slot31, align 8
  store i64 %v836, ptr %slot156, align 8
  %v837 = load i64, ptr %slot156, align 8
  %v838 = load i64, ptr %slot152, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v837, i64 %v838) nomerge, !dbg !132
  br label %bb_rcslotdone325
bb_rcslotdone325:
  %v839 = load i64, ptr %slot19, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot157, align 8
  %v842 = load i64, ptr %slot157, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ret844 = load i32, ptr %p843, align 4
  ret i32 %ret844
bb_failure:
  %v845 = load i64, ptr %slot6, align 8
  %p846 = inttoptr i64 %v845 to ptr
  call void @llvm.memset.p0.i64(ptr %p846, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v847 = load i64, ptr %slot6, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ret849 = load i32, ptr %p848, align 4
  ret i32 %ret849
bb_entry_failure:
  %v850 = load i64, ptr %slot6, align 8
  %p851 = inttoptr i64 %v850 to ptr
  call void @llvm.memset.p0.i64(ptr %p851, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v852 = load i64, ptr %slot6, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %ret854 = load i32, ptr %p853, align 4
  ret i32 %ret854
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_2939debd275151b39f5eff8d155285c9bce2a4c03f27899659f13a1077ddb3f3(i64, i64)
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_3630acb655f9e1aa5d70df28747f81788f82bcead7fb7dc504ad96e854540059(i64, i64, i64, i64)
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare { i64, i64 } @myl_f_8279ec0aa6001ed6f35e2df4808f447a2169eaa25c777c765ebc0c340fafee71(i64, i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i32 @myl_f_a0e96f299197f34d601c1a9da1cbd514090305d2a21036d06ba179b733ea6e29(i64, i64, i64)
declare i64 @myl_f_e6dd1a9167d6b59c9752b8305d109d76520bac8300dd423db9728be656322e7c(i64, i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare i32 @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b53a9d75384a8a87551e73907f3488427d5e67a18a665bbc5b37b105594ddd55", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b53a9d75384a8a87551e73907f3488427d5e67a18a665bbc5b37b105594ddd55", linkageName: "myl_f_b53a9d75384a8a87551e73907f3488427d5e67a18a665bbc5b37b105594ddd55", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4042768076802345117, i64 0, !"myl_f_b53a9d75384a8a87551e73907f3488427d5e67a18a665bbc5b37b105594ddd55"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!118 = !DILocation(line: 18, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!120 = !DILocation(line: 23, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!122 = !DILocation(line: 24, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!124 = !DILocation(line: 25, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!126 = !DILocation(line: 28, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!128 = !DILocation(line: 33, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!130 = !DILocation(line: 39, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!132 = !DILocation(line: 43, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!134 = !DILocation(line: 44, column: 0, scope: !135)
