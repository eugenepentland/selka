target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %callresult322 = alloca [40 x i8], align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v841 = load i64, ptr %slot1, align 8
  %op842 = add i64 %v841, 32
  store i64 %op842, ptr %slot3, align 8
  %mem843 = alloca i8, i64 8, align 8
  %ptr844 = ptrtoint ptr %mem843 to i64
  store i64 %ptr844, ptr %slot4, align 8
  %mem845 = alloca i8, i64 8, align 8
  %ptr846 = ptrtoint ptr %mem845 to i64
  store i64 %ptr846, ptr %slot5, align 8
  %mem847 = alloca i8, i64 8, align 8
  %ptr848 = ptrtoint ptr %mem847 to i64
  store i64 %ptr848, ptr %slot6, align 8
  %mem849 = alloca i8, i64 8, align 8
  %ptr850 = ptrtoint ptr %mem849 to i64
  store i64 %ptr850, ptr %slot7, align 8
  %mem851 = alloca i8, i64 8, align 8
  %ptr852 = ptrtoint ptr %mem851 to i64
  store i64 %ptr852, ptr %slot8, align 8
  %mem853 = alloca i8, i64 8, align 8
  %ptr854 = ptrtoint ptr %mem853 to i64
  store i64 %ptr854, ptr %slot9, align 8
  %mem855 = alloca i8, i64 8, align 8
  %ptr856 = ptrtoint ptr %mem855 to i64
  store i64 %ptr856, ptr %slot10, align 8
  %mem857 = alloca i8, i64 8, align 8
  %ptr858 = ptrtoint ptr %mem857 to i64
  store i64 %ptr858, ptr %slot11, align 8
  %mem859 = alloca i8, i64 8, align 8
  %ptr860 = ptrtoint ptr %mem859 to i64
  store i64 %ptr860, ptr %slot12, align 8
  %mem861 = alloca i8, i64 8, align 8
  %ptr862 = ptrtoint ptr %mem861 to i64
  store i64 %ptr862, ptr %slot13, align 8
  %mem863 = alloca i8, i64 8, align 8
  %ptr864 = ptrtoint ptr %mem863 to i64
  store i64 %ptr864, ptr %slot14, align 8
  %mem865 = alloca i8, i64 8, align 8
  %ptr866 = ptrtoint ptr %mem865 to i64
  store i64 %ptr866, ptr %slot15, align 8
  %mem867 = alloca i8, i64 8, align 8
  %ptr868 = ptrtoint ptr %mem867 to i64
  store i64 %ptr868, ptr %slot16, align 8
  %mem869 = alloca i8, i64 8, align 8
  %ptr870 = ptrtoint ptr %mem869 to i64
  store i64 %ptr870, ptr %slot17, align 8
  %mem871 = alloca i8, i64 8, align 8
  %ptr872 = ptrtoint ptr %mem871 to i64
  store i64 %ptr872, ptr %slot18, align 8
  %mem873 = alloca i8, i64 8, align 8
  %ptr874 = ptrtoint ptr %mem873 to i64
  store i64 %ptr874, ptr %slot19, align 8
  %mem875 = alloca i8, i64 8, align 8
  %ptr876 = ptrtoint ptr %mem875 to i64
  store i64 %ptr876, ptr %slot20, align 8
  %mem877 = alloca i8, i64 8, align 8
  %ptr878 = ptrtoint ptr %mem877 to i64
  store i64 %ptr878, ptr %slot21, align 8
  %mem879 = alloca i8, i64 8, align 8
  %ptr880 = ptrtoint ptr %mem879 to i64
  store i64 %ptr880, ptr %slot22, align 8
  %mem881 = alloca i8, i64 8, align 8
  %ptr882 = ptrtoint ptr %mem881 to i64
  store i64 %ptr882, ptr %slot23, align 8
  %mem883 = alloca i8, i64 8, align 8
  %ptr884 = ptrtoint ptr %mem883 to i64
  store i64 %ptr884, ptr %slot24, align 8
  %mem885 = alloca i8, i64 8, align 8
  %ptr886 = ptrtoint ptr %mem885 to i64
  store i64 %ptr886, ptr %slot25, align 8
  %mem887 = alloca i8, i64 392, align 8
  %ptr888 = ptrtoint ptr %mem887 to i64
  store i64 %ptr888, ptr %slot26, align 8
  %mem889 = alloca i8, i64 392, align 8
  %ptr890 = ptrtoint ptr %mem889 to i64
  store i64 %ptr890, ptr %slot27, align 8
  %mem891 = alloca i8, i64 8, align 8
  %ptr892 = ptrtoint ptr %mem891 to i64
  store i64 %ptr892, ptr %slot28, align 8
  %mem893 = alloca i8, i64 392, align 8
  %ptr894 = ptrtoint ptr %mem893 to i64
  store i64 %ptr894, ptr %slot29, align 8
  %mem895 = alloca i8, i64 40, align 8
  %ptr896 = ptrtoint ptr %mem895 to i64
  store i64 %ptr896, ptr %slot30, align 8
  %mem897 = alloca i8, i64 32, align 8
  %ptr898 = ptrtoint ptr %mem897 to i64
  store i64 %ptr898, ptr %slot31, align 8
  %mem899 = alloca i8, i64 40, align 8
  %ptr900 = ptrtoint ptr %mem899 to i64
  store i64 %ptr900, ptr %slot32, align 8
  %mem901 = alloca i8, i64 392, align 8
  %ptr902 = ptrtoint ptr %mem901 to i64
  store i64 %ptr902, ptr %slot33, align 8
  %mem903 = alloca i8, i64 32, align 8
  %ptr904 = ptrtoint ptr %mem903 to i64
  store i64 %ptr904, ptr %slot34, align 8
  %mem905 = alloca i8, i64 392, align 8
  %ptr906 = ptrtoint ptr %mem905 to i64
  store i64 %ptr906, ptr %slot35, align 8
  %mem907 = alloca i8, i64 40, align 8
  %ptr908 = ptrtoint ptr %mem907 to i64
  store i64 %ptr908, ptr %slot36, align 8
  %mem909 = alloca i8, i64 8, align 8
  %ptr910 = ptrtoint ptr %mem909 to i64
  store i64 %ptr910, ptr %slot37, align 8
  %mem911 = alloca i8, i64 8, align 8
  %ptr912 = ptrtoint ptr %mem911 to i64
  store i64 %ptr912, ptr %slot38, align 8
  %mem913 = alloca i8, i64 392, align 8
  %ptr914 = ptrtoint ptr %mem913 to i64
  store i64 %ptr914, ptr %slot39, align 8
  %mem915 = alloca i8, i64 392, align 8
  %ptr916 = ptrtoint ptr %mem915 to i64
  store i64 %ptr916, ptr %slot40, align 8
  %mem917 = alloca i8, i64 392, align 8
  %ptr918 = ptrtoint ptr %mem917 to i64
  store i64 %ptr918, ptr %slot41, align 8
  %mem919 = alloca i8, i64 40, align 8
  %ptr920 = ptrtoint ptr %mem919 to i64
  store i64 %ptr920, ptr %slot42, align 8
  %mem921 = alloca i8, i64 8, align 8
  %ptr922 = ptrtoint ptr %mem921 to i64
  store i64 %ptr922, ptr %slot43, align 8
  %mem923 = alloca i8, i64 392, align 8
  %ptr924 = ptrtoint ptr %mem923 to i64
  store i64 %ptr924, ptr %slot44, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem925 = alloca i8, i64 8, align 8
  %ptr926 = ptrtoint ptr %mem925 to i64
  store i64 %ptr926, ptr %slot45, align 8
  %v927 = load i64, ptr %slot1, align 8
  %op928 = add i64 %v927, 64
  store i64 %op928, ptr %slot46, align 8
  %v929 = load i64, ptr %slot46, align 8
  %p930 = inttoptr i64 %v929 to ptr
  %ld931 = load i64, ptr %p930, align 8, !alias.scope !4, !noalias !3
  store i64 %ld931, ptr %slot47, align 8
  %stack932 = call ptr @llvm.stacksave()
  %stackaddr933 = ptrtoint ptr %stack932 to i64
  %v934 = load i64, ptr %slot47, align 8
  %cmp935 = icmp ult i64 %stackaddr933, %v934
  %cv936 = zext i1 %cmp935 to i64
  store i64 %cv936, ptr %slot48, align 8
  %v937 = load i64, ptr %slot48, align 8
  %cond938 = icmp ne i64 %v937, 0
  br i1 %cond938, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v939 = load i64, ptr %slot1, align 8
  %p940 = inttoptr i64 %v939 to ptr
  call void @myl_qbe_fail_frame(ptr %p940) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v941 = load i64, ptr %slot2, align 8
  %v942 = load i64, ptr %slot28, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i64 %v941, ptr %p943, align 8, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot1, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %call946 = call ptr @myl_qbe_heap(ptr %p945) nomerge, !dbg !112
  %calladdr947 = ptrtoint ptr %call946 to i64
  store i64 %calladdr947, ptr %slot49, align 8
  %v948 = load i64, ptr %slot1, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %call950 = call i64 @myl_qbe_region_mark(ptr %p949) nomerge, !dbg !112
  store i64 %call950, ptr %slot50, align 8
  %v951 = load i64, ptr %slot4, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i32 0, ptr %p952, align 4, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot5, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i32 0, ptr %p954, align 4, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot6, align 8
  %p956 = inttoptr i64 %v955 to ptr
  store i32 0, ptr %p956, align 4, !alias.scope !3, !noalias !4
  %v957 = load i64, ptr %slot7, align 8
  %p958 = inttoptr i64 %v957 to ptr
  store i32 0, ptr %p958, align 4, !alias.scope !3, !noalias !4
  %v959 = load i64, ptr %slot8, align 8
  %p960 = inttoptr i64 %v959 to ptr
  store i32 0, ptr %p960, align 4, !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot9, align 8
  %p962 = inttoptr i64 %v961 to ptr
  store i32 0, ptr %p962, align 4, !alias.scope !3, !noalias !4
  %v963 = load i64, ptr %slot10, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i32 0, ptr %p964, align 4, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot11, align 8
  %p966 = inttoptr i64 %v965 to ptr
  store i32 0, ptr %p966, align 4, !alias.scope !3, !noalias !4
  %v967 = load i64, ptr %slot12, align 8
  %p968 = inttoptr i64 %v967 to ptr
  store i32 0, ptr %p968, align 4, !alias.scope !3, !noalias !4
  %v969 = load i64, ptr %slot13, align 8
  %p970 = inttoptr i64 %v969 to ptr
  store i32 0, ptr %p970, align 4, !alias.scope !3, !noalias !4
  %v971 = load i64, ptr %slot14, align 8
  %p972 = inttoptr i64 %v971 to ptr
  store i32 0, ptr %p972, align 4, !alias.scope !3, !noalias !4
  %v973 = load i64, ptr %slot15, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i32 0, ptr %p974, align 4, !alias.scope !3, !noalias !4
  %v975 = load i64, ptr %slot16, align 8
  %p976 = inttoptr i64 %v975 to ptr
  store i32 0, ptr %p976, align 4, !alias.scope !3, !noalias !4
  %v977 = load i64, ptr %slot17, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i32 0, ptr %p978, align 4, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot18, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i32 0, ptr %p980, align 4, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot19, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i32 0, ptr %p982, align 4, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot20, align 8
  %p984 = inttoptr i64 %v983 to ptr
  store i32 0, ptr %p984, align 4, !alias.scope !3, !noalias !4
  %v985 = load i64, ptr %slot21, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i32 0, ptr %p986, align 4, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot22, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i32 0, ptr %p988, align 4, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot23, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i32 0, ptr %p990, align 4, !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot24, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i32 0, ptr %p992, align 4, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot25, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i32 0, ptr %p994, align 4, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot5, align 8
  %p996 = inttoptr i64 %v995 to ptr
  store i32 2, ptr %p996, align 4, !alias.scope !3, !noalias !4
  %v997 = load i64, ptr %slot7, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i32 2, ptr %p998, align 4, !alias.scope !3, !noalias !4
  %v999 = load i64, ptr %slot9, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  store i32 2, ptr %p1000, align 4, !alias.scope !3, !noalias !4
  %v1001 = load i64, ptr %slot11, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i32 2, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  %v1003 = load i64, ptr %slot13, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  store i32 2, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  %v1005 = load i64, ptr %slot15, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i32 2, ptr %p1006, align 4, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot17, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  store i32 2, ptr %p1008, align 4, !alias.scope !3, !noalias !4
  %v1009 = load i64, ptr %slot19, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i32 2, ptr %p1010, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1011 = load i64, ptr %slot28, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %ld1013 = load i64, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1013, ptr %slot51, align 8
  %v1014 = load i64, ptr %slot51, align 8
  %v1015 = load i64, ptr %slot37, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  store i64 %v1014, ptr %p1016, align 8, !alias.scope !3, !noalias !4
  %v1017 = load i64, ptr %slot37, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %ld1019 = load i64, ptr %p1018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1019, ptr %slot52, align 8
  %v1020 = load i64, ptr %slot52, align 8
  %op1021 = add i64 %v1020, 288
  store i64 %op1021, ptr %slot53, align 8
  %v1022 = load i64, ptr %slot53, align 8
  %v1023 = load i64, ptr %slot37, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i64 %v1022, ptr %p1024, align 8, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot20, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i32, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1027, ptr %slot54, align 8
  %v1028 = load i32, ptr %slot54, align 8
  %cv1029 = zext i32 %v1028 to i64
  %cond1030 = icmp ne i64 %cv1029, 0
  br i1 %cond1030, label %bb_rcslotdrop21, label %bb_rcslotdone21
bb_rcslotdrop21:
  %v1031 = load i64, ptr %slot20, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i32 0, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  %v1033 = load i64, ptr %slot26, align 8
  store i64 %v1033, ptr %slot55, align 8
  %v1034 = load i64, ptr %slot21, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i32, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1036, ptr %slot56, align 8
  %v1037 = load i32, ptr %slot56, align 8
  %op1038 = and i32 %v1037, 28
  store i32 %op1038, ptr %slot57, align 8
  %v1039 = load i32, ptr %slot57, align 8
  %cv1040 = zext i32 %v1039 to i64
  %cond1041 = icmp ne i64 %cv1040, 0
  br i1 %cond1041, label %bb_rcslotrole21, label %bb_rcslotowner21
bb_rcslotrole21:
  %v1042 = load i64, ptr %slot49, align 8
  store i64 %v1042, ptr %slot58, align 8
  %v1043 = load i64, ptr %slot58, align 8
  %v1044 = load i64, ptr %slot55, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1043, i64 %v1044) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotowner21:
  %v1045 = load i64, ptr %slot49, align 8
  store i64 %v1045, ptr %slot59, align 8
  %v1046 = load i64, ptr %slot59, align 8
  %v1047 = load i64, ptr %slot55, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1046, i64 %v1047) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotdone21:
  %v1048 = load i64, ptr %slot37, align 8
  %p1049 = inttoptr i64 %v1048 to ptr
  %ld1050 = load i64, ptr %p1049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1050, ptr %slot60, align 8
  %v1051 = load i64, ptr %slot20, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %ld1053 = load i32, ptr %p1052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1053, ptr %slot61, align 8
  %v1054 = load i64, ptr %slot21, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %ld1056 = load i32, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1056, ptr %slot62, align 8
  %v1057 = load i32, ptr %slot62, align 8
  %op1058 = and i32 %v1057, 24
  store i32 %op1058, ptr %slot62, align 8
  %v1059 = load i32, ptr %slot62, align 8
  %cmp1060 = icmp eq i32 %v1059, 0
  %cv1061 = zext i1 %cmp1060 to i32
  store i32 %cv1061, ptr %slot63, align 8
  %v1062 = load i32, ptr %slot61, align 8
  %v1063 = load i32, ptr %slot63, align 8
  %op1064 = and i32 %v1062, %v1063
  store i32 %op1064, ptr %slot64, align 8
  %v1065 = load i32, ptr %slot64, align 8
  %cv1066 = zext i32 %v1065 to i64
  %cond1067 = icmp ne i64 %cv1066, 0
  br i1 %cond1067, label %bb_rcprivateown35, label %bb_rcprivateloan35
bb_rcprivateown35:
  %v1068 = load i64, ptr %slot27, align 8
  store i64 %v1068, ptr %slot65, align 8
  %v1069 = load i64, ptr %slot50, align 8
  store i64 %v1069, ptr %slot66, align 8
  %v1070 = load i64, ptr %slot49, align 8
  %v1071 = load i64, ptr %slot65, align 8
  %v1072 = load i64, ptr %slot60, align 8
  %v1073 = load i64, ptr %slot66, align 8
  %cv1074 = trunc i64 %v1073 to i32
  %call1075 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1070, i64 %v1071, i64 %v1072, i32 %cv1074) nomerge, !dbg !116
  store i32 %call1075, ptr %slot67, align 8
  %v1076 = load i32, ptr %slot67, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcsuccess39, label %bb_rcfailure39
bb_rcfailure39:
  %v1079 = load i64, ptr %slot49, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %call1081 = call i32 @myl_rc_take_failure(ptr %p1080) nomerge, !dbg !116
  store i32 %call1081, ptr %slot68, align 8
  %v1082 = load i64, ptr %slot1, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  %v1084 = load i32, ptr %slot68, align 8
  %call1085 = call i32 @myl_qbe_rc_status(ptr %p1083, i32 %v1084) nomerge, !dbg !116
  store i32 %call1085, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess39:
  %v1086 = load i64, ptr %slot20, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i32 0, ptr %p1087, align 4, !alias.scope !3, !noalias !4
  %v1088 = load i64, ptr %slot24, align 8
  %p1089 = inttoptr i64 %v1088 to ptr
  store i32 2, ptr %p1089, align 4, !alias.scope !3, !noalias !4
  %v1090 = load i64, ptr %slot23, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  store i32 1, ptr %p1091, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared35
bb_rcprivateloan35:
  %v1092 = load i64, ptr %slot20, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i32, ptr %p1093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1094, ptr %slot70, align 8
  %v1095 = load i64, ptr %slot21, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %ld1097 = load i32, ptr %p1096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1097, ptr %slot71, align 8
  %v1098 = load i32, ptr %slot71, align 8
  %cmp1099 = icmp eq i32 %v1098, 16
  %cv1100 = zext i1 %cmp1099 to i32
  store i32 %cv1100, ptr %slot72, align 8
  %v1101 = load i32, ptr %slot72, align 8
  %v1102 = load i32, ptr %slot70, align 8
  %op1103 = and i32 %v1101, %v1102
  store i32 %op1103, ptr %slot72, align 8
  %v1104 = load i32, ptr %slot72, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcprivatemove35, label %bb_rcprivatenew35
bb_rcprivatemove35:
  %v1107 = load i64, ptr %slot27, align 8
  store i64 %v1107, ptr %slot73, align 8
  %v1108 = load i64, ptr %slot60, align 8
  %v1109 = load i64, ptr %slot73, align 8
  %p1110 = inttoptr i64 %v1108 to ptr
  %p1111 = inttoptr i64 %v1109 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1111, ptr %p1110, i64 40, i1 false), !alias.scope !10000000
  %v1112 = load i64, ptr %slot60, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  call void @llvm.memset.p0.i64(ptr %p1113, i8 0, i64 40, i1 false), !alias.scope !4, !noalias !3, !dbg !116
  %v1114 = load i64, ptr %slot24, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i32 2, ptr %p1115, align 4, !alias.scope !3, !noalias !4
  %v1116 = load i64, ptr %slot24, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  store i32 16, ptr %p1117, align 4, !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot23, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i32 1, ptr %p1119, align 4, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot20, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i32 0, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared35
bb_rcprivatenew35:
  %v1122 = load i64, ptr %slot27, align 8
  store i64 %v1122, ptr %slot74, align 8
  %v1123 = load i64, ptr %slot49, align 8
  %v1124 = load i64, ptr %slot74, align 8
  %v1125 = load i64, ptr %slot60, align 8
  %call1126 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v1123, i64 %v1124, i64 %v1125) nomerge, !dbg !116
  store i32 %call1126, ptr %slot75, align 8
  %v1127 = load i32, ptr %slot75, align 8
  %cv1128 = zext i32 %v1127 to i64
  %cond1129 = icmp ne i64 %cv1128, 0
  br i1 %cond1129, label %bb_rcsuccess57, label %bb_rcfailure57
bb_rcfailure57:
  %v1130 = load i64, ptr %slot49, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %call1132 = call i32 @myl_rc_take_failure(ptr %p1131) nomerge, !dbg !116
  store i32 %call1132, ptr %slot76, align 8
  %v1133 = load i64, ptr %slot1, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  %v1135 = load i32, ptr %slot76, align 8
  %call1136 = call i32 @myl_qbe_rc_status(ptr %p1134, i32 %v1135) nomerge, !dbg !116
  store i32 %call1136, ptr %slot77, align 8
  br label %bb_failure
bb_rcsuccess57:
  %v1137 = load i64, ptr %slot24, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i32 2, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot24, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  store i32 16, ptr %p1140, align 4, !alias.scope !3, !noalias !4
  %v1141 = load i64, ptr %slot23, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i32 1, ptr %p1142, align 4, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot20, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  %ld1145 = load i32, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1145, ptr %slot78, align 8
  %v1146 = load i32, ptr %slot78, align 8
  %cv1147 = zext i32 %v1146 to i64
  %cond1148 = icmp ne i64 %cv1147, 0
  br i1 %cond1148, label %bb_rcslotdrop65, label %bb_rcslotdone65
bb_rcslotdrop65:
  %v1149 = load i64, ptr %slot20, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  store i32 0, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  %v1151 = load i64, ptr %slot26, align 8
  store i64 %v1151, ptr %slot79, align 8
  %v1152 = load i64, ptr %slot21, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i32, ptr %p1153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1154, ptr %slot80, align 8
  %v1155 = load i32, ptr %slot80, align 8
  %op1156 = and i32 %v1155, 28
  store i32 %op1156, ptr %slot81, align 8
  %v1157 = load i32, ptr %slot81, align 8
  %cv1158 = zext i32 %v1157 to i64
  %cond1159 = icmp ne i64 %cv1158, 0
  br i1 %cond1159, label %bb_rcslotrole65, label %bb_rcslotowner65
bb_rcslotrole65:
  %v1160 = load i64, ptr %slot49, align 8
  store i64 %v1160, ptr %slot82, align 8
  %v1161 = load i64, ptr %slot82, align 8
  %v1162 = load i64, ptr %slot79, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1161, i64 %v1162) nomerge, !dbg !116
  br label %bb_rcslotdone65
bb_rcslotowner65:
  %v1163 = load i64, ptr %slot49, align 8
  store i64 %v1163, ptr %slot83, align 8
  %v1164 = load i64, ptr %slot83, align 8
  %v1165 = load i64, ptr %slot79, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1164, i64 %v1165) nomerge, !dbg !116
  br label %bb_rcslotdone65
bb_rcslotdone65:
  br label %bb_rcprivateprepared35
bb_rcprivateprepared35:
  %v1166 = load i64, ptr %slot6, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i32, ptr %p1167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1168, ptr %slot84, align 8
  %v1169 = load i32, ptr %slot84, align 8
  %cv1170 = zext i32 %v1169 to i64
  %cond1171 = icmp ne i64 %cv1170, 0
  br i1 %cond1171, label %bb_rcslotdrop75, label %bb_rcslotdone75
bb_rcslotdrop75:
  %v1172 = load i64, ptr %slot6, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i32 0, ptr %p1173, align 4, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot30, align 8
  store i64 %v1174, ptr %slot85, align 8
  %v1175 = load i64, ptr %slot7, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %ld1177 = load i32, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1177, ptr %slot86, align 8
  %v1178 = load i32, ptr %slot86, align 8
  %op1179 = and i32 %v1178, 28
  store i32 %op1179, ptr %slot87, align 8
  %v1180 = load i32, ptr %slot87, align 8
  %cv1181 = zext i32 %v1180 to i64
  %cond1182 = icmp ne i64 %cv1181, 0
  br i1 %cond1182, label %bb_rcslotrole75, label %bb_rcslotowner75
bb_rcslotrole75:
  %v1183 = load i64, ptr %slot49, align 8
  store i64 %v1183, ptr %slot88, align 8
  %v1184 = load i64, ptr %slot88, align 8
  %v1185 = load i64, ptr %slot85, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1184, i64 %v1185) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotowner75:
  %v1186 = load i64, ptr %slot49, align 8
  store i64 %v1186, ptr %slot89, align 8
  %v1187 = load i64, ptr %slot89, align 8
  %v1188 = load i64, ptr %slot85, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1187, i64 %v1188) nomerge, !dbg !116
  br label %bb_rcslotdone75
bb_rcslotdone75:
  %v1189 = load i64, ptr %slot30, align 8
  store i64 %v1189, ptr %slot90, align 8
  %v1190 = load i64, ptr %slot27, align 8
  store i64 %v1190, ptr %slot91, align 8
  %v1191 = load i64, ptr %slot91, align 8
  %v1192 = load i64, ptr %slot90, align 8
  %p1193 = inttoptr i64 %v1191 to ptr
  %p1194 = inttoptr i64 %v1192 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1194, ptr %p1193, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot23, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i32 0, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot7, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i32 2, ptr %p1198, align 4, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot24, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %ld1201 = load i32, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1201, ptr %slot92, align 8
  %v1202 = load i32, ptr %slot92, align 8
  %v1203 = load i64, ptr %slot7, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i32 %v1202, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  %v1205 = load i64, ptr %slot6, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i32 1, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot28, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  %ld1209 = load i64, ptr %p1208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1209, ptr %slot93, align 8
  %v1210 = load i64, ptr %slot93, align 8
  %v1211 = load i64, ptr %slot37, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i64 %v1210, ptr %p1212, align 8, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot37, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i64, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1215, ptr %slot94, align 8
  %v1216 = load i64, ptr %slot20, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %ld1218 = load i32, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1218, ptr %slot95, align 8
  %v1219 = load i64, ptr %slot21, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  %ld1221 = load i32, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1221, ptr %slot96, align 8
  %v1222 = load i32, ptr %slot96, align 8
  %op1223 = and i32 %v1222, 24
  store i32 %op1223, ptr %slot96, align 8
  %v1224 = load i32, ptr %slot96, align 8
  %cmp1225 = icmp eq i32 %v1224, 0
  %cv1226 = zext i1 %cmp1225 to i32
  store i32 %cv1226, ptr %slot97, align 8
  %v1227 = load i32, ptr %slot95, align 8
  %v1228 = load i32, ptr %slot97, align 8
  %op1229 = and i32 %v1227, %v1228
  store i32 %op1229, ptr %slot98, align 8
  %v1230 = load i32, ptr %slot98, align 8
  %cv1231 = zext i32 %v1230 to i64
  %cond1232 = icmp ne i64 %cv1231, 0
  br i1 %cond1232, label %bb_rcprivateown97, label %bb_rcprivateloan97
bb_rcprivateown97:
  %v1233 = load i64, ptr %slot27, align 8
  store i64 %v1233, ptr %slot99, align 8
  %v1234 = load i64, ptr %slot50, align 8
  store i64 %v1234, ptr %slot100, align 8
  %v1235 = load i64, ptr %slot49, align 8
  %v1236 = load i64, ptr %slot99, align 8
  %v1237 = load i64, ptr %slot94, align 8
  %v1238 = load i64, ptr %slot100, align 8
  %cv1239 = trunc i64 %v1238 to i32
  %call1240 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v1235, i64 %v1236, i64 %v1237, i32 %cv1239) nomerge, !dbg !118
  store i32 %call1240, ptr %slot101, align 8
  %v1241 = load i32, ptr %slot101, align 8
  %cv1242 = zext i32 %v1241 to i64
  %cond1243 = icmp ne i64 %cv1242, 0
  br i1 %cond1243, label %bb_rcsuccess101, label %bb_rcfailure101
bb_rcfailure101:
  %v1244 = load i64, ptr %slot49, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %call1246 = call i32 @myl_rc_take_failure(ptr %p1245) nomerge, !dbg !118
  store i32 %call1246, ptr %slot102, align 8
  %v1247 = load i64, ptr %slot1, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %v1249 = load i32, ptr %slot102, align 8
  %call1250 = call i32 @myl_qbe_rc_status(ptr %p1248, i32 %v1249) nomerge, !dbg !118
  store i32 %call1250, ptr %slot103, align 8
  br label %bb_failure
bb_rcsuccess101:
  %v1251 = load i64, ptr %slot20, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  store i32 0, ptr %p1252, align 4, !alias.scope !3, !noalias !4
  %v1253 = load i64, ptr %slot24, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i32 2, ptr %p1254, align 4, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot23, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i32 1, ptr %p1256, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared97
bb_rcprivateloan97:
  %v1257 = load i64, ptr %slot27, align 8
  store i64 %v1257, ptr %slot104, align 8
  %v1258 = load i64, ptr %slot49, align 8
  %v1259 = load i64, ptr %slot104, align 8
  %v1260 = load i64, ptr %slot94, align 8
  %call1261 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v1258, i64 %v1259, i64 %v1260) nomerge, !dbg !118
  store i32 %call1261, ptr %slot105, align 8
  %v1262 = load i32, ptr %slot105, align 8
  %cv1263 = zext i32 %v1262 to i64
  %cond1264 = icmp ne i64 %cv1263, 0
  br i1 %cond1264, label %bb_rcsuccess109, label %bb_rcfailure109
bb_rcfailure109:
  %v1265 = load i64, ptr %slot49, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %call1267 = call i32 @myl_rc_take_failure(ptr %p1266) nomerge, !dbg !118
  store i32 %call1267, ptr %slot106, align 8
  %v1268 = load i64, ptr %slot1, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  %v1270 = load i32, ptr %slot106, align 8
  %call1271 = call i32 @myl_qbe_rc_status(ptr %p1269, i32 %v1270) nomerge, !dbg !118
  store i32 %call1271, ptr %slot107, align 8
  br label %bb_failure
bb_rcsuccess109:
  %v1272 = load i64, ptr %slot24, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  store i32 2, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  %v1274 = load i64, ptr %slot24, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i32 16, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot23, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i32 1, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot20, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i32, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1280, ptr %slot108, align 8
  %v1281 = load i32, ptr %slot108, align 8
  %cv1282 = zext i32 %v1281 to i64
  %cond1283 = icmp ne i64 %cv1282, 0
  br i1 %cond1283, label %bb_rcslotdrop117, label %bb_rcslotdone117
bb_rcslotdrop117:
  %v1284 = load i64, ptr %slot20, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i32 0, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot26, align 8
  store i64 %v1286, ptr %slot109, align 8
  %v1287 = load i64, ptr %slot21, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %ld1289 = load i32, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1289, ptr %slot110, align 8
  %v1290 = load i32, ptr %slot110, align 8
  %op1291 = and i32 %v1290, 28
  store i32 %op1291, ptr %slot111, align 8
  %v1292 = load i32, ptr %slot111, align 8
  %cv1293 = zext i32 %v1292 to i64
  %cond1294 = icmp ne i64 %cv1293, 0
  br i1 %cond1294, label %bb_rcslotrole117, label %bb_rcslotowner117
bb_rcslotrole117:
  %v1295 = load i64, ptr %slot49, align 8
  store i64 %v1295, ptr %slot112, align 8
  %v1296 = load i64, ptr %slot112, align 8
  %v1297 = load i64, ptr %slot109, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1296, i64 %v1297) nomerge, !dbg !118
  br label %bb_rcslotdone117
bb_rcslotowner117:
  %v1298 = load i64, ptr %slot49, align 8
  store i64 %v1298, ptr %slot113, align 8
  %v1299 = load i64, ptr %slot113, align 8
  %v1300 = load i64, ptr %slot109, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1299, i64 %v1300) nomerge, !dbg !118
  br label %bb_rcslotdone117
bb_rcslotdone117:
  br label %bb_rcprivateprepared97
bb_rcprivateprepared97:
  %v1301 = load i64, ptr %slot4, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  %ld1303 = load i32, ptr %p1302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1303, ptr %slot114, align 8
  %v1304 = load i32, ptr %slot114, align 8
  %cv1305 = zext i32 %v1304 to i64
  %cond1306 = icmp ne i64 %cv1305, 0
  br i1 %cond1306, label %bb_rcslotdrop127, label %bb_rcslotdone127
bb_rcslotdrop127:
  %v1307 = load i64, ptr %slot4, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 0, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot29, align 8
  store i64 %v1309, ptr %slot115, align 8
  %v1310 = load i64, ptr %slot5, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  %ld1312 = load i32, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1312, ptr %slot116, align 8
  %v1313 = load i32, ptr %slot116, align 8
  %op1314 = and i32 %v1313, 28
  store i32 %op1314, ptr %slot117, align 8
  %v1315 = load i32, ptr %slot117, align 8
  %cv1316 = zext i32 %v1315 to i64
  %cond1317 = icmp ne i64 %cv1316, 0
  br i1 %cond1317, label %bb_rcslotrole127, label %bb_rcslotowner127
bb_rcslotrole127:
  %v1318 = load i64, ptr %slot49, align 8
  store i64 %v1318, ptr %slot118, align 8
  %v1319 = load i64, ptr %slot118, align 8
  %v1320 = load i64, ptr %slot115, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1319, i64 %v1320) nomerge, !dbg !118
  br label %bb_rcslotdone127
bb_rcslotowner127:
  %v1321 = load i64, ptr %slot49, align 8
  store i64 %v1321, ptr %slot119, align 8
  %v1322 = load i64, ptr %slot119, align 8
  %v1323 = load i64, ptr %slot115, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1322, i64 %v1323) nomerge, !dbg !118
  br label %bb_rcslotdone127
bb_rcslotdone127:
  %v1324 = load i64, ptr %slot29, align 8
  store i64 %v1324, ptr %slot120, align 8
  %v1325 = load i64, ptr %slot27, align 8
  store i64 %v1325, ptr %slot121, align 8
  %v1326 = load i64, ptr %slot121, align 8
  %v1327 = load i64, ptr %slot120, align 8
  %p1328 = inttoptr i64 %v1326 to ptr
  %p1329 = inttoptr i64 %v1327 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1329, ptr %p1328, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot23, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 0, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot5, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 2, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot24, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  %ld1336 = load i32, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1336, ptr %slot122, align 8
  %v1337 = load i32, ptr %slot122, align 8
  %v1338 = load i64, ptr %slot5, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 %v1337, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot4, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 1, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot28, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i64, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1344, ptr %slot123, align 8
  %v1345 = load i64, ptr %slot123, align 8
  %v1346 = load i64, ptr %slot37, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  store i64 %v1345, ptr %p1347, align 8, !alias.scope !3, !noalias !4
  %v1348 = load i64, ptr %slot37, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  %ld1350 = load i64, ptr %p1349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1350, ptr %slot124, align 8
  %v1351 = load i64, ptr %slot20, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  %ld1353 = load i32, ptr %p1352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1353, ptr %slot125, align 8
  %v1354 = load i64, ptr %slot21, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  %ld1356 = load i32, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1356, ptr %slot126, align 8
  %v1357 = load i32, ptr %slot126, align 8
  %op1358 = and i32 %v1357, 24
  store i32 %op1358, ptr %slot126, align 8
  %v1359 = load i32, ptr %slot126, align 8
  %cmp1360 = icmp eq i32 %v1359, 0
  %cv1361 = zext i1 %cmp1360 to i32
  store i32 %cv1361, ptr %slot127, align 8
  %v1362 = load i32, ptr %slot125, align 8
  %v1363 = load i32, ptr %slot127, align 8
  %op1364 = and i32 %v1362, %v1363
  store i32 %op1364, ptr %slot128, align 8
  %v1365 = load i32, ptr %slot128, align 8
  %cv1366 = zext i32 %v1365 to i64
  %cond1367 = icmp ne i64 %cv1366, 0
  br i1 %cond1367, label %bb_rcprivateown149, label %bb_rcprivateloan149
bb_rcprivateown149:
  %v1368 = load i64, ptr %slot27, align 8
  store i64 %v1368, ptr %slot129, align 8
  %v1369 = load i64, ptr %slot50, align 8
  store i64 %v1369, ptr %slot130, align 8
  %v1370 = load i64, ptr %slot49, align 8
  %v1371 = load i64, ptr %slot129, align 8
  %v1372 = load i64, ptr %slot124, align 8
  %v1373 = load i64, ptr %slot130, align 8
  %cv1374 = trunc i64 %v1373 to i32
  %call1375 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v1370, i64 %v1371, i64 %v1372, i32 %cv1374) nomerge, !dbg !120
  store i32 %call1375, ptr %slot131, align 8
  %v1376 = load i32, ptr %slot131, align 8
  %cv1377 = zext i32 %v1376 to i64
  %cond1378 = icmp ne i64 %cv1377, 0
  br i1 %cond1378, label %bb_rcsuccess153, label %bb_rcfailure153
bb_rcfailure153:
  %v1379 = load i64, ptr %slot49, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  %call1381 = call i32 @myl_rc_take_failure(ptr %p1380) nomerge, !dbg !120
  store i32 %call1381, ptr %slot132, align 8
  %v1382 = load i64, ptr %slot1, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %v1384 = load i32, ptr %slot132, align 8
  %call1385 = call i32 @myl_qbe_rc_status(ptr %p1383, i32 %v1384) nomerge, !dbg !120
  store i32 %call1385, ptr %slot133, align 8
  br label %bb_failure
bb_rcsuccess153:
  %v1386 = load i64, ptr %slot20, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i32 0, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot24, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  store i32 2, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot23, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i32 1, ptr %p1391, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared149
bb_rcprivateloan149:
  %v1392 = load i64, ptr %slot27, align 8
  store i64 %v1392, ptr %slot134, align 8
  %v1393 = load i64, ptr %slot49, align 8
  %v1394 = load i64, ptr %slot134, align 8
  %v1395 = load i64, ptr %slot124, align 8
  %call1396 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v1393, i64 %v1394, i64 %v1395) nomerge, !dbg !120
  store i32 %call1396, ptr %slot135, align 8
  %v1397 = load i32, ptr %slot135, align 8
  %cv1398 = zext i32 %v1397 to i64
  %cond1399 = icmp ne i64 %cv1398, 0
  br i1 %cond1399, label %bb_rcsuccess161, label %bb_rcfailure161
bb_rcfailure161:
  %v1400 = load i64, ptr %slot49, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %call1402 = call i32 @myl_rc_take_failure(ptr %p1401) nomerge, !dbg !120
  store i32 %call1402, ptr %slot136, align 8
  %v1403 = load i64, ptr %slot1, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  %v1405 = load i32, ptr %slot136, align 8
  %call1406 = call i32 @myl_qbe_rc_status(ptr %p1404, i32 %v1405) nomerge, !dbg !120
  store i32 %call1406, ptr %slot137, align 8
  br label %bb_failure
bb_rcsuccess161:
  %v1407 = load i64, ptr %slot24, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i32 2, ptr %p1408, align 4, !alias.scope !3, !noalias !4
  %v1409 = load i64, ptr %slot24, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i32 16, ptr %p1410, align 4, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot23, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  store i32 1, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  %v1413 = load i64, ptr %slot20, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  %ld1415 = load i32, ptr %p1414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1415, ptr %slot138, align 8
  %v1416 = load i32, ptr %slot138, align 8
  %cv1417 = zext i32 %v1416 to i64
  %cond1418 = icmp ne i64 %cv1417, 0
  br i1 %cond1418, label %bb_rcslotdrop169, label %bb_rcslotdone169
bb_rcslotdrop169:
  %v1419 = load i64, ptr %slot20, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  store i32 0, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot26, align 8
  store i64 %v1421, ptr %slot139, align 8
  %v1422 = load i64, ptr %slot21, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  %ld1424 = load i32, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1424, ptr %slot140, align 8
  %v1425 = load i32, ptr %slot140, align 8
  %op1426 = and i32 %v1425, 28
  store i32 %op1426, ptr %slot141, align 8
  %v1427 = load i32, ptr %slot141, align 8
  %cv1428 = zext i32 %v1427 to i64
  %cond1429 = icmp ne i64 %cv1428, 0
  br i1 %cond1429, label %bb_rcslotrole169, label %bb_rcslotowner169
bb_rcslotrole169:
  %v1430 = load i64, ptr %slot49, align 8
  store i64 %v1430, ptr %slot142, align 8
  %v1431 = load i64, ptr %slot142, align 8
  %v1432 = load i64, ptr %slot139, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1431, i64 %v1432) nomerge, !dbg !120
  br label %bb_rcslotdone169
bb_rcslotowner169:
  %v1433 = load i64, ptr %slot49, align 8
  store i64 %v1433, ptr %slot143, align 8
  %v1434 = load i64, ptr %slot143, align 8
  %v1435 = load i64, ptr %slot139, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1434, i64 %v1435) nomerge, !dbg !120
  br label %bb_rcslotdone169
bb_rcslotdone169:
  br label %bb_rcprivateprepared149
bb_rcprivateprepared149:
  %v1436 = load i64, ptr %slot4, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  %ld1438 = load i32, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1438, ptr %slot144, align 8
  %v1439 = load i32, ptr %slot144, align 8
  %cv1440 = zext i32 %v1439 to i64
  %cond1441 = icmp ne i64 %cv1440, 0
  br i1 %cond1441, label %bb_rcslotdrop179, label %bb_rcslotdone179
bb_rcslotdrop179:
  %v1442 = load i64, ptr %slot4, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i32 0, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot29, align 8
  store i64 %v1444, ptr %slot145, align 8
  %v1445 = load i64, ptr %slot5, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  %ld1447 = load i32, ptr %p1446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1447, ptr %slot146, align 8
  %v1448 = load i32, ptr %slot146, align 8
  %op1449 = and i32 %v1448, 28
  store i32 %op1449, ptr %slot147, align 8
  %v1450 = load i32, ptr %slot147, align 8
  %cv1451 = zext i32 %v1450 to i64
  %cond1452 = icmp ne i64 %cv1451, 0
  br i1 %cond1452, label %bb_rcslotrole179, label %bb_rcslotowner179
bb_rcslotrole179:
  %v1453 = load i64, ptr %slot49, align 8
  store i64 %v1453, ptr %slot148, align 8
  %v1454 = load i64, ptr %slot148, align 8
  %v1455 = load i64, ptr %slot145, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1454, i64 %v1455) nomerge, !dbg !120
  br label %bb_rcslotdone179
bb_rcslotowner179:
  %v1456 = load i64, ptr %slot49, align 8
  store i64 %v1456, ptr %slot149, align 8
  %v1457 = load i64, ptr %slot149, align 8
  %v1458 = load i64, ptr %slot145, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1457, i64 %v1458) nomerge, !dbg !120
  br label %bb_rcslotdone179
bb_rcslotdone179:
  %v1459 = load i64, ptr %slot29, align 8
  store i64 %v1459, ptr %slot150, align 8
  %v1460 = load i64, ptr %slot27, align 8
  store i64 %v1460, ptr %slot151, align 8
  %v1461 = load i64, ptr %slot151, align 8
  %v1462 = load i64, ptr %slot150, align 8
  %p1463 = inttoptr i64 %v1461 to ptr
  %p1464 = inttoptr i64 %v1462 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1464, ptr %p1463, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot23, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i32 0, ptr %p1466, align 4, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot5, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i32 2, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot24, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i32, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1471, ptr %slot152, align 8
  %v1472 = load i32, ptr %slot152, align 8
  %v1473 = load i64, ptr %slot5, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i32 %v1472, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot4, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  store i32 1, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  %v1477 = load i64, ptr %slot29, align 8
  %v1478 = load i64, ptr %slot37, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  store i64 %v1477, ptr %p1479, align 8, !alias.scope !3, !noalias !4
  %v1480 = load i64, ptr %slot30, align 8
  %v1481 = load i64, ptr %slot38, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i64 %v1480, ptr %p1482, align 8, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot37, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %ld1485 = load i64, ptr %p1484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1485, ptr %slot153, align 8
  %v1486 = load i64, ptr %slot20, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %ld1488 = load i32, ptr %p1487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1488, ptr %slot154, align 8
  %v1489 = load i64, ptr %slot21, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  %ld1491 = load i32, ptr %p1490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1491, ptr %slot155, align 8
  %v1492 = load i32, ptr %slot155, align 8
  %op1493 = and i32 %v1492, 24
  store i32 %op1493, ptr %slot155, align 8
  %v1494 = load i32, ptr %slot155, align 8
  %cmp1495 = icmp eq i32 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot156, align 8
  %v1497 = load i32, ptr %slot154, align 8
  %v1498 = load i32, ptr %slot156, align 8
  %op1499 = and i32 %v1497, %v1498
  store i32 %op1499, ptr %slot157, align 8
  %v1500 = load i32, ptr %slot157, align 8
  %cv1501 = zext i32 %v1500 to i64
  %cond1502 = icmp ne i64 %cv1501, 0
  br i1 %cond1502, label %bb_rctake194, label %bb_rccopy194
bb_rctake194:
  %v1503 = load i64, ptr %slot27, align 8
  store i64 %v1503, ptr %slot158, align 8
  %v1504 = load i64, ptr %slot50, align 8
  store i64 %v1504, ptr %slot159, align 8
  %v1505 = load i64, ptr %slot49, align 8
  %v1506 = load i64, ptr %slot158, align 8
  %v1507 = load i64, ptr %slot153, align 8
  %v1508 = load i64, ptr %slot159, align 8
  %cv1509 = trunc i64 %v1508 to i32
  %call1510 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v1505, i64 %v1506, i64 %v1507, i32 %cv1509) nomerge, !dbg !122
  store i32 %call1510, ptr %slot160, align 8
  %v1511 = load i32, ptr %slot160, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcsuccess204, label %bb_rcfailure204
bb_rcfailure204:
  %v1514 = load i64, ptr %slot49, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %call1516 = call i32 @myl_rc_take_failure(ptr %p1515) nomerge, !dbg !122
  store i32 %call1516, ptr %slot161, align 8
  %v1517 = load i64, ptr %slot1, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  %v1519 = load i32, ptr %slot161, align 8
  %call1520 = call i32 @myl_qbe_rc_status(ptr %p1518, i32 %v1519) nomerge, !dbg !122
  store i32 %call1520, ptr %slot162, align 8
  br label %bb_failure
bb_rcsuccess204:
  %v1521 = load i64, ptr %slot20, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i32 0, ptr %p1522, align 4, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot24, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 2, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot23, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i32 1, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared194
bb_rccopy194:
  %v1527 = load i64, ptr %slot27, align 8
  store i64 %v1527, ptr %slot163, align 8
  %v1528 = load i64, ptr %slot50, align 8
  store i64 %v1528, ptr %slot164, align 8
  %v1529 = load i64, ptr %slot49, align 8
  %v1530 = load i64, ptr %slot163, align 8
  %v1531 = load i64, ptr %slot153, align 8
  %v1532 = load i64, ptr %slot164, align 8
  %cv1533 = trunc i64 %v1532 to i32
  %call1534 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v1529, i64 %v1530, i64 %v1531, i32 %cv1533) nomerge, !dbg !122
  store i32 %call1534, ptr %slot165, align 8
  %v1535 = load i32, ptr %slot165, align 8
  %cv1536 = zext i32 %v1535 to i64
  %cond1537 = icmp ne i64 %cv1536, 0
  br i1 %cond1537, label %bb_rcsuccess213, label %bb_rcfailure213
bb_rcfailure213:
  %v1538 = load i64, ptr %slot49, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  %call1540 = call i32 @myl_rc_take_failure(ptr %p1539) nomerge, !dbg !122
  store i32 %call1540, ptr %slot166, align 8
  %v1541 = load i64, ptr %slot1, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  %v1543 = load i32, ptr %slot166, align 8
  %call1544 = call i32 @myl_qbe_rc_status(ptr %p1542, i32 %v1543) nomerge, !dbg !122
  store i32 %call1544, ptr %slot167, align 8
  br label %bb_failure
bb_rcsuccess213:
  %v1545 = load i64, ptr %slot24, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i32 2, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  %v1547 = load i64, ptr %slot23, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i32 1, ptr %p1548, align 4, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot20, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %ld1551 = load i32, ptr %p1550, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1551, ptr %slot168, align 8
  %v1552 = load i32, ptr %slot168, align 8
  %cv1553 = zext i32 %v1552 to i64
  %cond1554 = icmp ne i64 %cv1553, 0
  br i1 %cond1554, label %bb_rcslotdrop220, label %bb_rcslotdone220
bb_rcslotdrop220:
  %v1555 = load i64, ptr %slot20, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i32 0, ptr %p1556, align 4, !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot26, align 8
  store i64 %v1557, ptr %slot169, align 8
  %v1558 = load i64, ptr %slot21, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %ld1560 = load i32, ptr %p1559, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1560, ptr %slot170, align 8
  %v1561 = load i32, ptr %slot170, align 8
  %op1562 = and i32 %v1561, 28
  store i32 %op1562, ptr %slot171, align 8
  %v1563 = load i32, ptr %slot171, align 8
  %cv1564 = zext i32 %v1563 to i64
  %cond1565 = icmp ne i64 %cv1564, 0
  br i1 %cond1565, label %bb_rcslotrole220, label %bb_rcslotowner220
bb_rcslotrole220:
  %v1566 = load i64, ptr %slot49, align 8
  store i64 %v1566, ptr %slot172, align 8
  %v1567 = load i64, ptr %slot172, align 8
  %v1568 = load i64, ptr %slot169, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1567, i64 %v1568) nomerge, !dbg !122
  br label %bb_rcslotdone220
bb_rcslotowner220:
  %v1569 = load i64, ptr %slot49, align 8
  store i64 %v1569, ptr %slot173, align 8
  %v1570 = load i64, ptr %slot173, align 8
  %v1571 = load i64, ptr %slot169, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1570, i64 %v1571) nomerge, !dbg !122
  br label %bb_rcslotdone220
bb_rcslotdone220:
  br label %bb_rcprepared194
bb_rcprepared194:
  %v1572 = load i64, ptr %slot27, align 8
  store i64 %v1572, ptr %slot174, align 8
  %v1573 = load i64, ptr %slot39, align 8
  store i64 %v1573, ptr %slot175, align 8
  %v1574 = load i64, ptr %slot174, align 8
  %v1575 = load i64, ptr %slot175, align 8
  %p1576 = inttoptr i64 %v1574 to ptr
  %p1577 = inttoptr i64 %v1575 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1577, ptr %p1576, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v1578 = load i64, ptr %slot23, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i32 0, ptr %p1579, align 4, !alias.scope !3, !noalias !4
  %v1580 = load i64, ptr %slot25, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  store i32 1, ptr %p1581, align 4, !alias.scope !3, !noalias !4
  %v1582 = load i64, ptr %slot50, align 8
  store i64 %v1582, ptr %slot176, align 8
  %v1583 = load i64, ptr %slot38, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %ld1585 = load i64, ptr %p1584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1585, ptr %slot177, align 8
  %v1586 = load i64, ptr %slot175, align 8
  %p1588 = inttoptr i64 %v1586 to ptr
  %gep1589 = getelementptr i8, ptr %p1588, i64 328
  %op1587 = ptrtoint ptr %gep1589 to i64
  store i64 %op1587, ptr %slot178, align 8
  %v1590 = load i64, ptr %slot27, align 8
  store i64 %v1590, ptr %slot179, align 8
  %v1591 = load i64, ptr %slot38, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %ld1593 = load i64, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1593, ptr %slot180, align 8
  store i32 0, ptr %slot181, align 8
  %v1594 = load i64, ptr %slot22, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  %ld1596 = load i32, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1596, ptr %slot182, align 8
  %v1597 = load i32, ptr %slot182, align 8
  %op1598 = and i32 %v1597, 24
  store i32 %op1598, ptr %slot182, align 8
  %v1599 = load i32, ptr %slot182, align 8
  %cmp1600 = icmp eq i32 %v1599, 0
  %cv1601 = zext i1 %cmp1600 to i32
  store i32 %cv1601, ptr %slot183, align 8
  %v1602 = load i32, ptr %slot181, align 8
  %v1603 = load i32, ptr %slot183, align 8
  %op1604 = and i32 %v1602, %v1603
  store i32 %op1604, ptr %slot184, align 8
  %v1605 = load i32, ptr %slot184, align 8
  %cv1606 = zext i32 %v1605 to i64
  %cond1607 = icmp ne i64 %cv1606, 0
  br i1 %cond1607, label %bb_rctake237, label %bb_rccopy237
bb_rctake237:
  %v1608 = load i64, ptr %slot27, align 8
  store i64 %v1608, ptr %slot185, align 8
  %v1609 = load i64, ptr %slot50, align 8
  store i64 %v1609, ptr %slot186, align 8
  %v1610 = load i64, ptr %slot49, align 8
  %v1611 = load i64, ptr %slot185, align 8
  %v1612 = load i64, ptr %slot180, align 8
  %v1613 = load i64, ptr %slot186, align 8
  %cv1614 = trunc i64 %v1613 to i32
  %call1615 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1610, i64 %v1611, i64 %v1612, i32 %cv1614) nomerge, !dbg !122
  store i32 %call1615, ptr %slot187, align 8
  %v1616 = load i32, ptr %slot187, align 8
  %cv1617 = zext i32 %v1616 to i64
  %cond1618 = icmp ne i64 %cv1617, 0
  br i1 %cond1618, label %bb_rcsuccess247, label %bb_rcfailure247
bb_rcfailure247:
  %v1619 = load i64, ptr %slot49, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  %call1621 = call i32 @myl_rc_take_failure(ptr %p1620) nomerge, !dbg !122
  store i32 %call1621, ptr %slot188, align 8
  %v1622 = load i64, ptr %slot1, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  %v1624 = load i32, ptr %slot188, align 8
  %call1625 = call i32 @myl_qbe_rc_status(ptr %p1623, i32 %v1624) nomerge, !dbg !122
  store i32 %call1625, ptr %slot189, align 8
  br label %bb_failure
bb_rcsuccess247:
  %v1626 = load i64, ptr %slot24, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 2, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot23, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 1, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared237
bb_rccopy237:
  %v1630 = load i64, ptr %slot27, align 8
  store i64 %v1630, ptr %slot190, align 8
  %v1631 = load i64, ptr %slot50, align 8
  store i64 %v1631, ptr %slot191, align 8
  %v1632 = load i64, ptr %slot49, align 8
  %v1633 = load i64, ptr %slot190, align 8
  %v1634 = load i64, ptr %slot180, align 8
  %v1635 = load i64, ptr %slot191, align 8
  %cv1636 = trunc i64 %v1635 to i32
  %call1637 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1632, i64 %v1633, i64 %v1634, i32 %cv1636) nomerge, !dbg !122
  store i32 %call1637, ptr %slot192, align 8
  %v1638 = load i32, ptr %slot192, align 8
  %cv1639 = zext i32 %v1638 to i64
  %cond1640 = icmp ne i64 %cv1639, 0
  br i1 %cond1640, label %bb_rcsuccess256, label %bb_rcfailure256
bb_rcfailure256:
  %v1641 = load i64, ptr %slot49, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %call1643 = call i32 @myl_rc_take_failure(ptr %p1642) nomerge, !dbg !122
  store i32 %call1643, ptr %slot193, align 8
  %v1644 = load i64, ptr %slot1, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  %v1646 = load i32, ptr %slot193, align 8
  %call1647 = call i32 @myl_qbe_rc_status(ptr %p1645, i32 %v1646) nomerge, !dbg !122
  store i32 %call1647, ptr %slot194, align 8
  br label %bb_failure
bb_rcsuccess256:
  %v1648 = load i64, ptr %slot24, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  store i32 2, ptr %p1649, align 4, !alias.scope !3, !noalias !4
  %v1650 = load i64, ptr %slot23, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  store i32 1, ptr %p1651, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared237
bb_rcprepared237:
  %v1652 = load i64, ptr %slot27, align 8
  store i64 %v1652, ptr %slot195, align 8
  %v1653 = load i64, ptr %slot195, align 8
  %v1654 = load i64, ptr %slot179, align 8
  %p1655 = inttoptr i64 %v1653 to ptr
  %p1656 = inttoptr i64 %v1654 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1656, ptr %p1655, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1657 = load i64, ptr %slot23, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i32 0, ptr %p1658, align 4, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot24, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i32 2, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot23, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  store i32 1, ptr %p1662, align 4, !alias.scope !3, !noalias !4
  %v1663 = load i64, ptr %slot49, align 8
  store i64 %v1663, ptr %slot196, align 8
  %v1664 = load i64, ptr %slot196, align 8
  %v1665 = load i64, ptr %slot178, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1664, i64 %v1665) nomerge, !dbg !122
  %v1666 = load i64, ptr %slot179, align 8
  %v1667 = load i64, ptr %slot178, align 8
  %p1668 = inttoptr i64 %v1666 to ptr
  %p1669 = inttoptr i64 %v1667 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1669, ptr %p1668, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1670 = load i64, ptr %slot23, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i32 0, ptr %p1671, align 4, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot175, align 8
  %v1673 = load i64, ptr %slot37, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  store i64 %v1672, ptr %p1674, align 8, !alias.scope !3, !noalias !4
  %v1675 = load i64, ptr %slot37, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %ld1677 = load i64, ptr %p1676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1677, ptr %slot197, align 8
  %v1678 = load i64, ptr %slot27, align 8
  store i64 %v1678, ptr %slot198, align 8
  %v1679 = load i64, ptr %slot197, align 8
  %v1680 = load i64, ptr %slot198, align 8
  %p1681 = inttoptr i64 %v1679 to ptr
  %p1682 = inttoptr i64 %v1680 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1682, ptr %p1681, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot24, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  store i32 2, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  %v1685 = load i64, ptr %slot23, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i32 1, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  %v1687 = load i64, ptr %slot20, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  %ld1689 = load i32, ptr %p1688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1689, ptr %slot199, align 8
  %v1690 = load i32, ptr %slot199, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcslotdrop282, label %bb_rcslotdone282
bb_rcslotdrop282:
  %v1693 = load i64, ptr %slot20, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot26, align 8
  store i64 %v1695, ptr %slot200, align 8
  %v1696 = load i64, ptr %slot21, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %ld1698 = load i32, ptr %p1697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1698, ptr %slot201, align 8
  %v1699 = load i32, ptr %slot201, align 8
  %op1700 = and i32 %v1699, 28
  store i32 %op1700, ptr %slot202, align 8
  %v1701 = load i32, ptr %slot202, align 8
  %cv1702 = zext i32 %v1701 to i64
  %cond1703 = icmp ne i64 %cv1702, 0
  br i1 %cond1703, label %bb_rcslotrole282, label %bb_rcslotowner282
bb_rcslotrole282:
  %v1704 = load i64, ptr %slot49, align 8
  store i64 %v1704, ptr %slot203, align 8
  %v1705 = load i64, ptr %slot203, align 8
  %v1706 = load i64, ptr %slot200, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1705, i64 %v1706) nomerge, !dbg !122
  br label %bb_rcslotdone282
bb_rcslotowner282:
  %v1707 = load i64, ptr %slot49, align 8
  store i64 %v1707, ptr %slot204, align 8
  %v1708 = load i64, ptr %slot204, align 8
  %v1709 = load i64, ptr %slot200, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1708, i64 %v1709) nomerge, !dbg !122
  br label %bb_rcslotdone282
bb_rcslotdone282:
  %v1710 = load i64, ptr %slot26, align 8
  store i64 %v1710, ptr %slot205, align 8
  %v1711 = load i64, ptr %slot27, align 8
  store i64 %v1711, ptr %slot206, align 8
  %v1712 = load i64, ptr %slot206, align 8
  %v1713 = load i64, ptr %slot205, align 8
  %p1714 = inttoptr i64 %v1712 to ptr
  %p1715 = inttoptr i64 %v1713 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1715, ptr %p1714, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v1716 = load i64, ptr %slot21, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  store i32 2, ptr %p1717, align 4, !alias.scope !3, !noalias !4
  %v1718 = load i64, ptr %slot24, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %ld1720 = load i32, ptr %p1719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1720, ptr %slot207, align 8
  %v1721 = load i32, ptr %slot207, align 8
  %v1722 = load i64, ptr %slot21, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i32 %v1721, ptr %p1723, align 4, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot23, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 0, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot20, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 1, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot205, align 8
  %v1729 = load i64, ptr %slot37, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i64 %v1728, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot37, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i64, ptr %p1732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1733, ptr %slot208, align 8
  %v1734 = load i64, ptr %slot20, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %ld1736 = load i32, ptr %p1735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1736, ptr %slot209, align 8
  %v1737 = load i64, ptr %slot21, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  %ld1739 = load i32, ptr %p1738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1739, ptr %slot210, align 8
  %v1740 = load i32, ptr %slot210, align 8
  %op1741 = and i32 %v1740, 24
  store i32 %op1741, ptr %slot210, align 8
  %v1742 = load i32, ptr %slot210, align 8
  %cmp1743 = icmp eq i32 %v1742, 0
  %cv1744 = zext i1 %cmp1743 to i32
  store i32 %cv1744, ptr %slot211, align 8
  %v1745 = load i32, ptr %slot209, align 8
  %v1746 = load i32, ptr %slot211, align 8
  %op1747 = and i32 %v1745, %v1746
  store i32 %op1747, ptr %slot212, align 8
  %v1748 = load i32, ptr %slot212, align 8
  %cv1749 = zext i32 %v1748 to i64
  %cond1750 = icmp ne i64 %cv1749, 0
  br i1 %cond1750, label %bb_rctake307, label %bb_rccopy307
bb_rctake307:
  %v1751 = load i64, ptr %slot27, align 8
  store i64 %v1751, ptr %slot213, align 8
  %v1752 = load i64, ptr %slot50, align 8
  store i64 %v1752, ptr %slot214, align 8
  %v1753 = load i64, ptr %slot49, align 8
  %v1754 = load i64, ptr %slot213, align 8
  %v1755 = load i64, ptr %slot208, align 8
  %v1756 = load i64, ptr %slot214, align 8
  %cv1757 = trunc i64 %v1756 to i32
  %call1758 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v1753, i64 %v1754, i64 %v1755, i32 %cv1757) nomerge, !dbg !124
  store i32 %call1758, ptr %slot215, align 8
  %v1759 = load i32, ptr %slot215, align 8
  %cv1760 = zext i32 %v1759 to i64
  %cond1761 = icmp ne i64 %cv1760, 0
  br i1 %cond1761, label %bb_rcsuccess317, label %bb_rcfailure317
bb_rcfailure317:
  %v1762 = load i64, ptr %slot49, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %call1764 = call i32 @myl_rc_take_failure(ptr %p1763) nomerge, !dbg !124
  store i32 %call1764, ptr %slot216, align 8
  %v1765 = load i64, ptr %slot1, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %v1767 = load i32, ptr %slot216, align 8
  %call1768 = call i32 @myl_qbe_rc_status(ptr %p1766, i32 %v1767) nomerge, !dbg !124
  store i32 %call1768, ptr %slot217, align 8
  br label %bb_failure
bb_rcsuccess317:
  %v1769 = load i64, ptr %slot20, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  store i32 0, ptr %p1770, align 4, !alias.scope !3, !noalias !4
  %v1771 = load i64, ptr %slot24, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i32 2, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  %v1773 = load i64, ptr %slot23, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  store i32 1, ptr %p1774, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared307
bb_rccopy307:
  %v1775 = load i64, ptr %slot27, align 8
  store i64 %v1775, ptr %slot218, align 8
  %v1776 = load i64, ptr %slot50, align 8
  store i64 %v1776, ptr %slot219, align 8
  %v1777 = load i64, ptr %slot49, align 8
  %v1778 = load i64, ptr %slot218, align 8
  %v1779 = load i64, ptr %slot208, align 8
  %v1780 = load i64, ptr %slot219, align 8
  %cv1781 = trunc i64 %v1780 to i32
  %call1782 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v1777, i64 %v1778, i64 %v1779, i32 %cv1781) nomerge, !dbg !124
  store i32 %call1782, ptr %slot220, align 8
  %v1783 = load i32, ptr %slot220, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rcsuccess326, label %bb_rcfailure326
bb_rcfailure326:
  %v1786 = load i64, ptr %slot49, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  %call1788 = call i32 @myl_rc_take_failure(ptr %p1787) nomerge, !dbg !124
  store i32 %call1788, ptr %slot221, align 8
  %v1789 = load i64, ptr %slot1, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %v1791 = load i32, ptr %slot221, align 8
  %call1792 = call i32 @myl_qbe_rc_status(ptr %p1790, i32 %v1791) nomerge, !dbg !124
  store i32 %call1792, ptr %slot222, align 8
  br label %bb_failure
bb_rcsuccess326:
  %v1793 = load i64, ptr %slot24, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  store i32 2, ptr %p1794, align 4, !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot23, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i32 1, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot20, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %ld1799 = load i32, ptr %p1798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1799, ptr %slot223, align 8
  %v1800 = load i32, ptr %slot223, align 8
  %cv1801 = zext i32 %v1800 to i64
  %cond1802 = icmp ne i64 %cv1801, 0
  br i1 %cond1802, label %bb_rcslotdrop333, label %bb_rcslotdone333
bb_rcslotdrop333:
  %v1803 = load i64, ptr %slot20, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 0, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot26, align 8
  store i64 %v1805, ptr %slot224, align 8
  %v1806 = load i64, ptr %slot21, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  %ld1808 = load i32, ptr %p1807, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1808, ptr %slot225, align 8
  %v1809 = load i32, ptr %slot225, align 8
  %op1810 = and i32 %v1809, 28
  store i32 %op1810, ptr %slot226, align 8
  %v1811 = load i32, ptr %slot226, align 8
  %cv1812 = zext i32 %v1811 to i64
  %cond1813 = icmp ne i64 %cv1812, 0
  br i1 %cond1813, label %bb_rcslotrole333, label %bb_rcslotowner333
bb_rcslotrole333:
  %v1814 = load i64, ptr %slot49, align 8
  store i64 %v1814, ptr %slot227, align 8
  %v1815 = load i64, ptr %slot227, align 8
  %v1816 = load i64, ptr %slot224, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1815, i64 %v1816) nomerge, !dbg !124
  br label %bb_rcslotdone333
bb_rcslotowner333:
  %v1817 = load i64, ptr %slot49, align 8
  store i64 %v1817, ptr %slot228, align 8
  %v1818 = load i64, ptr %slot228, align 8
  %v1819 = load i64, ptr %slot224, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1818, i64 %v1819) nomerge, !dbg !124
  br label %bb_rcslotdone333
bb_rcslotdone333:
  br label %bb_rcprepared307
bb_rcprepared307:
  %v1820 = load i64, ptr %slot28, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i64, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1822, ptr %slot229, align 8
  %v1823 = load i64, ptr %slot49, align 8
  store i64 %v1823, ptr %slot230, align 8
  %v1824 = load i64, ptr %slot230, align 8
  %v1825 = load i64, ptr %slot229, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1824, i64 %v1825) nomerge, !dbg !124
  %v1826 = load i64, ptr %slot27, align 8
  store i64 %v1826, ptr %slot231, align 8
  %v1827 = load i64, ptr %slot231, align 8
  %v1828 = load i64, ptr %slot229, align 8
  %p1829 = inttoptr i64 %v1827 to ptr
  %p1830 = inttoptr i64 %v1828 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1830, ptr %p1829, i64 392, i1 false), !alias.scope !10000000
  %v1831 = load i64, ptr %slot23, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 0, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot37, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i64 0, ptr %p1834, align 8, !alias.scope !3, !noalias !4
  br label %bb_i13
bb_i13:
  %v1835 = load i64, ptr %slot28, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i64, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1837, ptr %slot232, align 8
  %v1838 = load i64, ptr %slot232, align 8
  %v1839 = load i64, ptr %slot37, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i64 %v1838, ptr %p1840, align 8, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot37, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i64, ptr %p1842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1843, ptr %slot233, align 8
  %v1844 = load i64, ptr %slot233, align 8
  %op1845 = add i64 %v1844, 256
  store i64 %op1845, ptr %slot234, align 8
  %v1846 = load i64, ptr %slot234, align 8
  %v1847 = load i64, ptr %slot37, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i64 %v1846, ptr %p1848, align 8, !alias.scope !3, !noalias !4
  %v1849 = load i64, ptr %slot20, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i32, ptr %p1850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1851, ptr %slot235, align 8
  %v1852 = load i32, ptr %slot235, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcslotdrop349, label %bb_rcslotdone349
bb_rcslotdrop349:
  %v1855 = load i64, ptr %slot20, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 0, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot26, align 8
  store i64 %v1857, ptr %slot236, align 8
  %v1858 = load i64, ptr %slot21, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %ld1860 = load i32, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1860, ptr %slot237, align 8
  %v1861 = load i32, ptr %slot237, align 8
  %op1862 = and i32 %v1861, 28
  store i32 %op1862, ptr %slot238, align 8
  %v1863 = load i32, ptr %slot238, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcslotrole349, label %bb_rcslotowner349
bb_rcslotrole349:
  %v1866 = load i64, ptr %slot49, align 8
  store i64 %v1866, ptr %slot239, align 8
  %v1867 = load i64, ptr %slot239, align 8
  %v1868 = load i64, ptr %slot236, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1867, i64 %v1868) nomerge, !dbg !126
  br label %bb_rcslotdone349
bb_rcslotowner349:
  %v1869 = load i64, ptr %slot49, align 8
  store i64 %v1869, ptr %slot240, align 8
  %v1870 = load i64, ptr %slot240, align 8
  %v1871 = load i64, ptr %slot236, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1870, i64 %v1871) nomerge, !dbg !126
  br label %bb_rcslotdone349
bb_rcslotdone349:
  %v1872 = load i64, ptr %slot37, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %ld1874 = load i64, ptr %p1873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1874, ptr %slot241, align 8
  %v1875 = load i64, ptr %slot20, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %ld1877 = load i32, ptr %p1876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1877, ptr %slot242, align 8
  %v1878 = load i64, ptr %slot21, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i32, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1880, ptr %slot243, align 8
  %v1881 = load i32, ptr %slot243, align 8
  %op1882 = and i32 %v1881, 24
  store i32 %op1882, ptr %slot243, align 8
  %v1883 = load i32, ptr %slot243, align 8
  %cmp1884 = icmp eq i32 %v1883, 0
  %cv1885 = zext i1 %cmp1884 to i32
  store i32 %cv1885, ptr %slot244, align 8
  %v1886 = load i32, ptr %slot242, align 8
  %v1887 = load i32, ptr %slot244, align 8
  %op1888 = and i32 %v1886, %v1887
  store i32 %op1888, ptr %slot245, align 8
  %v1889 = load i32, ptr %slot245, align 8
  %cv1890 = zext i32 %v1889 to i64
  %cond1891 = icmp ne i64 %cv1890, 0
  br i1 %cond1891, label %bb_rctake357, label %bb_rccopy357
bb_rctake357:
  %v1892 = load i64, ptr %slot27, align 8
  store i64 %v1892, ptr %slot246, align 8
  %v1893 = load i64, ptr %slot50, align 8
  store i64 %v1893, ptr %slot247, align 8
  %v1894 = load i64, ptr %slot241, align 8
  %v1895 = load i64, ptr %slot246, align 8
  %op1896 = sub i64 %v1894, %v1895
  store i64 %op1896, ptr %slot248, align 8
  %v1897 = load i64, ptr %slot246, align 8
  %v1898 = load i64, ptr %slot241, align 8
  %op1899 = sub i64 %v1897, %v1898
  store i64 %op1899, ptr %slot249, align 8
  %v1900 = load i64, ptr %slot248, align 8
  %cmp1901 = icmp ult i64 %v1900, 32
  %cv1902 = zext i1 %cmp1901 to i32
  store i32 %cv1902, ptr %slot250, align 8
  %v1903 = load i64, ptr %slot249, align 8
  %cmp1904 = icmp ult i64 %v1903, 32
  %cv1905 = zext i1 %cmp1904 to i32
  store i32 %cv1905, ptr %slot251, align 8
  %v1906 = load i32, ptr %slot250, align 8
  %v1907 = load i32, ptr %slot251, align 8
  %op1908 = or i32 %v1906, %v1907
  store i32 %op1908, ptr %slot252, align 8
  %v1909 = load i32, ptr %slot252, align 8
  %cv1910 = zext i32 %v1909 to i64
  %cond1911 = icmp ne i64 %cv1910, 0
  br i1 %cond1911, label %bb_rcmoveslow366, label %bb_rcmovecheck366
bb_rcmovecheck366:
  %v1912 = load i64, ptr %slot241, align 8
  %op1913 = add i64 %v1912, 0
  store i64 %op1913, ptr %slot253, align 8
  %v1914 = load i64, ptr %slot253, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %ld1916 = load i64, ptr %p1915, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1916, ptr %slot254, align 8
  %v1917 = load i64, ptr %slot254, align 8
  %cmp1918 = icmp ne i64 %v1917, 0
  %cv1919 = zext i1 %cmp1918 to i32
  store i32 %cv1919, ptr %slot255, align 8
  %v1920 = load i32, ptr %slot255, align 8
  %cv1921 = zext i32 %v1920 to i64
  %cond1922 = icmp ne i64 %cv1921, 0
  br i1 %cond1922, label %bb_rcmoveheader374, label %bb_rcmovenext374
bb_rcmoveheader374:
  %v1923 = load i64, ptr %slot254, align 8
  %op1924 = sub i64 %v1923, 16
  store i64 %op1924, ptr %slot256, align 8
  %v1925 = load i64, ptr %slot254, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %rgep1927 = getelementptr i8, ptr %p1926, i64 -16
  %ld1928 = load i64, ptr %rgep1927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1928, ptr %slot257, align 8
  %v1929 = load i64, ptr %slot257, align 8
  %op1930 = and i64 %v1929, 5764607523034234881
  store i64 %op1930, ptr %slot258, align 8
  %v1931 = load i64, ptr %slot258, align 8
  %cmp1932 = icmp ne i64 %v1931, 0
  %cv1933 = zext i1 %cmp1932 to i32
  store i32 %cv1933, ptr %slot259, align 8
  %v1934 = load i32, ptr %slot259, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcmoveslow366, label %bb_rcmovenext374
bb_rcmovenext374:
  %v1937 = load i64, ptr %slot241, align 8
  %v1938 = load i64, ptr %slot246, align 8
  %p1939 = inttoptr i64 %v1937 to ptr
  %p1940 = inttoptr i64 %v1938 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1940, ptr %p1939, i64 32, i1 false), !alias.scope !10000000
  %v1941 = load i64, ptr %slot241, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 0, ptr %p1942, align 8, !alias.scope !4, !noalias !3
  %v1943 = load i64, ptr %slot241, align 8
  %op1944 = add i64 %v1943, 8
  store i64 %op1944, ptr %slot260, align 8
  %v1945 = load i64, ptr %slot260, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  store i64 0, ptr %p1946, align 8, !alias.scope !4, !noalias !3
  %v1947 = load i64, ptr %slot241, align 8
  %op1948 = add i64 %v1947, 16
  store i64 %op1948, ptr %slot261, align 8
  %v1949 = load i64, ptr %slot261, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  store i64 0, ptr %p1950, align 8, !alias.scope !4, !noalias !3
  %v1951 = load i64, ptr %slot241, align 8
  %op1952 = add i64 %v1951, 24
  store i64 %op1952, ptr %slot262, align 8
  %v1953 = load i64, ptr %slot262, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 0, ptr %p1954, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved366
bb_rcmoveslow366:
  %v1955 = load i64, ptr %slot49, align 8
  %v1956 = load i64, ptr %slot246, align 8
  %v1957 = load i64, ptr %slot241, align 8
  %v1958 = load i64, ptr %slot247, align 8
  %cv1959 = trunc i64 %v1958 to i32
  %call1960 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v1955, i64 %v1956, i64 %v1957, i32 %cv1959) nomerge, !dbg !128
  store i32 %call1960, ptr %slot263, align 8
  %v1961 = load i32, ptr %slot263, align 8
  %cv1962 = zext i32 %v1961 to i64
  %cond1963 = icmp ne i64 %cv1962, 0
  br i1 %cond1963, label %bb_rcsuccess384, label %bb_rcfailure384
bb_rcfailure384:
  %v1964 = load i64, ptr %slot49, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %call1966 = call i32 @myl_rc_take_failure(ptr %p1965) nomerge, !dbg !128
  store i32 %call1966, ptr %slot264, align 8
  %v1967 = load i64, ptr %slot1, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %v1969 = load i32, ptr %slot264, align 8
  %call1970 = call i32 @myl_qbe_rc_status(ptr %p1968, i32 %v1969) nomerge, !dbg !128
  store i32 %call1970, ptr %slot265, align 8
  br label %bb_failure
bb_rcsuccess384:
  br label %bb_rcmoved366
bb_rcmoved366:
  %v1971 = load i64, ptr %slot20, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  store i32 0, ptr %p1972, align 4, !alias.scope !3, !noalias !4
  %v1973 = load i64, ptr %slot24, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  store i32 2, ptr %p1974, align 4, !alias.scope !3, !noalias !4
  %v1975 = load i64, ptr %slot23, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  store i32 1, ptr %p1976, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared357
bb_rccopy357:
  %v1977 = load i64, ptr %slot27, align 8
  store i64 %v1977, ptr %slot266, align 8
  %v1978 = load i64, ptr %slot50, align 8
  store i64 %v1978, ptr %slot267, align 8
  %v1979 = load i64, ptr %slot49, align 8
  %v1980 = load i64, ptr %slot266, align 8
  %v1981 = load i64, ptr %slot241, align 8
  %v1982 = load i64, ptr %slot267, align 8
  %cv1983 = trunc i64 %v1982 to i32
  %call1984 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v1979, i64 %v1980, i64 %v1981, i32 %cv1983) nomerge, !dbg !128
  store i32 %call1984, ptr %slot268, align 8
  %v1985 = load i32, ptr %slot268, align 8
  %cv1986 = zext i32 %v1985 to i64
  %cond1987 = icmp ne i64 %cv1986, 0
  br i1 %cond1987, label %bb_rcsuccess393, label %bb_rcfailure393
bb_rcfailure393:
  %v1988 = load i64, ptr %slot49, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %call1990 = call i32 @myl_rc_take_failure(ptr %p1989) nomerge, !dbg !128
  store i32 %call1990, ptr %slot269, align 8
  %v1991 = load i64, ptr %slot1, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %v1993 = load i32, ptr %slot269, align 8
  %call1994 = call i32 @myl_qbe_rc_status(ptr %p1992, i32 %v1993) nomerge, !dbg !128
  store i32 %call1994, ptr %slot270, align 8
  br label %bb_failure
bb_rcsuccess393:
  %v1995 = load i64, ptr %slot24, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i32 2, ptr %p1996, align 4, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot23, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i32 1, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  %v1999 = load i64, ptr %slot20, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %ld2001 = load i32, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2001, ptr %slot271, align 8
  %v2002 = load i32, ptr %slot271, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcslotdrop400, label %bb_rcslotdone400
bb_rcslotdrop400:
  %v2005 = load i64, ptr %slot20, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i32 0, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot26, align 8
  store i64 %v2007, ptr %slot272, align 8
  %v2008 = load i64, ptr %slot21, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i32, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2010, ptr %slot273, align 8
  %v2011 = load i32, ptr %slot273, align 8
  %op2012 = and i32 %v2011, 28
  store i32 %op2012, ptr %slot274, align 8
  %v2013 = load i32, ptr %slot274, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcslotrole400, label %bb_rcslotowner400
bb_rcslotrole400:
  %v2016 = load i64, ptr %slot49, align 8
  store i64 %v2016, ptr %slot275, align 8
  %v2017 = load i64, ptr %slot275, align 8
  %v2018 = load i64, ptr %slot272, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2017, i64 %v2018) nomerge, !dbg !128
  br label %bb_rcslotdone400
bb_rcslotowner400:
  %v2019 = load i64, ptr %slot272, align 8
  %p2021 = inttoptr i64 %v2019 to ptr
  %gep2022 = getelementptr i8, ptr %p2021, i64 0
  %op2020 = ptrtoint ptr %gep2022 to i64
  store i64 %op2020, ptr %slot276, align 8
  %v2023 = load i64, ptr %slot49, align 8
  store i64 %v2023, ptr %slot277, align 8
  %v2024 = load i64, ptr %slot276, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %ld2026 = load i64, ptr %p2025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2026, ptr %slot278, align 8
  %v2027 = load i64, ptr %slot278, align 8
  %cmp2028 = icmp ne i64 %v2027, 0
  %cv2029 = zext i1 %cmp2028 to i32
  store i32 %cv2029, ptr %slot279, align 8
  %v2030 = load i32, ptr %slot279, align 8
  %cv2031 = zext i32 %v2030 to i64
  %cond2032 = icmp ne i64 %cv2031, 0
  br i1 %cond2032, label %bb_rcgnn418, label %bb_rcgdone418
bb_rcgnn418:
  %v2033 = load i64, ptr %slot278, align 8
  %op2034 = sub i64 %v2033, 16
  store i64 %op2034, ptr %slot280, align 8
  %v2035 = load i64, ptr %slot278, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  %rgep2037 = getelementptr i8, ptr %p2036, i64 -16
  %ld2038 = load i64, ptr %rgep2037, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2038, ptr %slot281, align 8
  %v2039 = load i64, ptr %slot281, align 8
  %op2040 = and i64 %v2039, 4611686018427387906
  store i64 %op2040, ptr %slot282, align 8
  %v2041 = load i64, ptr %slot282, align 8
  %cmp2042 = icmp ne i64 %v2041, 0
  %cv2043 = zext i1 %cmp2042 to i32
  store i32 %cv2043, ptr %slot283, align 8
  %v2044 = load i32, ptr %slot283, align 8
  %cv2045 = zext i32 %v2044 to i64
  %cond2046 = icmp ne i64 %cv2045, 0
  br i1 %cond2046, label %bb_rcgclear418, label %bb_rcgcounted418
bb_rcgcounted418:
  %v2047 = load i64, ptr %slot278, align 8
  %op2048 = sub i64 %v2047, 32
  store i64 %op2048, ptr %slot284, align 8
  %v2049 = load i64, ptr %slot278, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  %rgep2051 = getelementptr i8, ptr %p2050, i64 -32
  %ld2052 = load i64, ptr %rgep2051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2052, ptr %slot285, align 8
  %v2053 = load i64, ptr %slot285, align 8
  %op2054 = sub i64 %v2053, 1
  store i64 %op2054, ptr %slot286, align 8
  %v2055 = load i64, ptr %slot286, align 8
  %cmp2056 = icmp eq i64 %v2055, 0
  %cv2057 = zext i1 %cmp2056 to i32
  store i32 %cv2057, ptr %slot287, align 8
  %v2058 = load i32, ptr %slot287, align 8
  %cv2059 = zext i32 %v2058 to i64
  %cond2060 = icmp ne i64 %cv2059, 0
  br i1 %cond2060, label %bb_rcglast418, label %bb_rcgdec418
bb_rcglast418:
  %v2061 = load i64, ptr %slot278, align 8
  %op2062 = sub i64 %v2061, 24
  store i64 %op2062, ptr %slot288, align 8
  %v2063 = load i64, ptr %slot278, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %rgep2065 = getelementptr i8, ptr %p2064, i64 -24
  %ld2066 = load i64, ptr %rgep2065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2066, ptr %slot289, align 8
  %v2067 = load i64, ptr %slot289, align 8
  %cmp2068 = icmp ne i64 %v2067, 0
  %cv2069 = zext i1 %cmp2068 to i32
  store i32 %cv2069, ptr %slot290, align 8
  %v2070 = load i32, ptr %slot290, align 8
  %cv2071 = zext i32 %v2070 to i64
  %cond2072 = icmp ne i64 %cv2071, 0
  br i1 %cond2072, label %bb_rcgdec418, label %bb_rcgslow418
bb_rcgslow418:
  %v2073 = load i64, ptr %slot277, align 8
  %v2074 = load i64, ptr %slot276, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2073, i64 %v2074) nomerge, !dbg !128
  br label %bb_rcgdone418
bb_rcgdec418:
  %v2075 = load i64, ptr %slot286, align 8
  %v2076 = load i64, ptr %slot278, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %rgep2078 = getelementptr i8, ptr %p2077, i64 -32
  store i64 %v2075, ptr %rgep2078, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear418
bb_rcgclear418:
  %v2079 = load i64, ptr %slot276, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i64 0, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone418
bb_rcgdone418:
  %v2081 = load i64, ptr %slot272, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i64 0, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot272, align 8
  %p2085 = inttoptr i64 %v2083 to ptr
  %gep2086 = getelementptr i8, ptr %p2085, i64 8
  %op2084 = ptrtoint ptr %gep2086 to i64
  store i64 %op2084, ptr %slot291, align 8
  %v2087 = load i64, ptr %slot291, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i64 0, ptr %p2088, align 8, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot272, align 8
  %p2091 = inttoptr i64 %v2089 to ptr
  %gep2092 = getelementptr i8, ptr %p2091, i64 16
  %op2090 = ptrtoint ptr %gep2092 to i64
  store i64 %op2090, ptr %slot292, align 8
  %v2093 = load i64, ptr %slot292, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  store i64 0, ptr %p2094, align 8, !alias.scope !3, !noalias !4
  %v2095 = load i64, ptr %slot272, align 8
  %p2097 = inttoptr i64 %v2095 to ptr
  %gep2098 = getelementptr i8, ptr %p2097, i64 24
  %op2096 = ptrtoint ptr %gep2098 to i64
  store i64 %op2096, ptr %slot293, align 8
  %v2099 = load i64, ptr %slot293, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i64 0, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone400
bb_rcslotdone400:
  br label %bb_rcprepared357
bb_rcprepared357:
  %v2101 = load i64, ptr %slot8, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %ld2103 = load i32, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2103, ptr %slot294, align 8
  %v2104 = load i32, ptr %slot294, align 8
  %cv2105 = zext i32 %v2104 to i64
  %cond2106 = icmp ne i64 %cv2105, 0
  br i1 %cond2106, label %bb_rcslotdrop428, label %bb_rcslotdone428
bb_rcslotdrop428:
  %v2107 = load i64, ptr %slot8, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i32 0, ptr %p2108, align 4, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot31, align 8
  store i64 %v2109, ptr %slot295, align 8
  %v2110 = load i64, ptr %slot9, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i32, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2112, ptr %slot296, align 8
  %v2113 = load i32, ptr %slot296, align 8
  %op2114 = and i32 %v2113, 28
  store i32 %op2114, ptr %slot297, align 8
  %v2115 = load i32, ptr %slot297, align 8
  %cv2116 = zext i32 %v2115 to i64
  %cond2117 = icmp ne i64 %cv2116, 0
  br i1 %cond2117, label %bb_rcslotrole428, label %bb_rcslotowner428
bb_rcslotrole428:
  %v2118 = load i64, ptr %slot49, align 8
  store i64 %v2118, ptr %slot298, align 8
  %v2119 = load i64, ptr %slot298, align 8
  %v2120 = load i64, ptr %slot295, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2119, i64 %v2120) nomerge, !dbg !128
  br label %bb_rcslotdone428
bb_rcslotowner428:
  %v2121 = load i64, ptr %slot295, align 8
  %p2123 = inttoptr i64 %v2121 to ptr
  %gep2124 = getelementptr i8, ptr %p2123, i64 0
  %op2122 = ptrtoint ptr %gep2124 to i64
  store i64 %op2122, ptr %slot299, align 8
  %v2125 = load i64, ptr %slot49, align 8
  store i64 %v2125, ptr %slot300, align 8
  %v2126 = load i64, ptr %slot299, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  %ld2128 = load i64, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2128, ptr %slot301, align 8
  %v2129 = load i64, ptr %slot301, align 8
  %cmp2130 = icmp ne i64 %v2129, 0
  %cv2131 = zext i1 %cmp2130 to i32
  store i32 %cv2131, ptr %slot302, align 8
  %v2132 = load i32, ptr %slot302, align 8
  %cv2133 = zext i32 %v2132 to i64
  %cond2134 = icmp ne i64 %cv2133, 0
  br i1 %cond2134, label %bb_rcgnn446, label %bb_rcgdone446
bb_rcgnn446:
  %v2135 = load i64, ptr %slot301, align 8
  %op2136 = sub i64 %v2135, 16
  store i64 %op2136, ptr %slot303, align 8
  %v2137 = load i64, ptr %slot301, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %rgep2139 = getelementptr i8, ptr %p2138, i64 -16
  %ld2140 = load i64, ptr %rgep2139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2140, ptr %slot304, align 8
  %v2141 = load i64, ptr %slot304, align 8
  %op2142 = and i64 %v2141, 4611686018427387906
  store i64 %op2142, ptr %slot305, align 8
  %v2143 = load i64, ptr %slot305, align 8
  %cmp2144 = icmp ne i64 %v2143, 0
  %cv2145 = zext i1 %cmp2144 to i32
  store i32 %cv2145, ptr %slot306, align 8
  %v2146 = load i32, ptr %slot306, align 8
  %cv2147 = zext i32 %v2146 to i64
  %cond2148 = icmp ne i64 %cv2147, 0
  br i1 %cond2148, label %bb_rcgclear446, label %bb_rcgcounted446
bb_rcgcounted446:
  %v2149 = load i64, ptr %slot301, align 8
  %op2150 = sub i64 %v2149, 32
  store i64 %op2150, ptr %slot307, align 8
  %v2151 = load i64, ptr %slot301, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %rgep2153 = getelementptr i8, ptr %p2152, i64 -32
  %ld2154 = load i64, ptr %rgep2153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2154, ptr %slot308, align 8
  %v2155 = load i64, ptr %slot308, align 8
  %op2156 = sub i64 %v2155, 1
  store i64 %op2156, ptr %slot309, align 8
  %v2157 = load i64, ptr %slot309, align 8
  %cmp2158 = icmp eq i64 %v2157, 0
  %cv2159 = zext i1 %cmp2158 to i32
  store i32 %cv2159, ptr %slot310, align 8
  %v2160 = load i32, ptr %slot310, align 8
  %cv2161 = zext i32 %v2160 to i64
  %cond2162 = icmp ne i64 %cv2161, 0
  br i1 %cond2162, label %bb_rcglast446, label %bb_rcgdec446
bb_rcglast446:
  %v2163 = load i64, ptr %slot301, align 8
  %op2164 = sub i64 %v2163, 24
  store i64 %op2164, ptr %slot311, align 8
  %v2165 = load i64, ptr %slot301, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %rgep2167 = getelementptr i8, ptr %p2166, i64 -24
  %ld2168 = load i64, ptr %rgep2167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2168, ptr %slot312, align 8
  %v2169 = load i64, ptr %slot312, align 8
  %cmp2170 = icmp ne i64 %v2169, 0
  %cv2171 = zext i1 %cmp2170 to i32
  store i32 %cv2171, ptr %slot313, align 8
  %v2172 = load i32, ptr %slot313, align 8
  %cv2173 = zext i32 %v2172 to i64
  %cond2174 = icmp ne i64 %cv2173, 0
  br i1 %cond2174, label %bb_rcgdec446, label %bb_rcgslow446
bb_rcgslow446:
  %v2175 = load i64, ptr %slot300, align 8
  %v2176 = load i64, ptr %slot299, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2175, i64 %v2176) nomerge, !dbg !128
  br label %bb_rcgdone446
bb_rcgdec446:
  %v2177 = load i64, ptr %slot309, align 8
  %v2178 = load i64, ptr %slot301, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %rgep2180 = getelementptr i8, ptr %p2179, i64 -32
  store i64 %v2177, ptr %rgep2180, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear446
bb_rcgclear446:
  %v2181 = load i64, ptr %slot299, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i64 0, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone446
bb_rcgdone446:
  %v2183 = load i64, ptr %slot295, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i64 0, ptr %p2184, align 8, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot295, align 8
  %p2187 = inttoptr i64 %v2185 to ptr
  %gep2188 = getelementptr i8, ptr %p2187, i64 8
  %op2186 = ptrtoint ptr %gep2188 to i64
  store i64 %op2186, ptr %slot314, align 8
  %v2189 = load i64, ptr %slot314, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i64 0, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  %v2191 = load i64, ptr %slot295, align 8
  %p2193 = inttoptr i64 %v2191 to ptr
  %gep2194 = getelementptr i8, ptr %p2193, i64 16
  %op2192 = ptrtoint ptr %gep2194 to i64
  store i64 %op2192, ptr %slot315, align 8
  %v2195 = load i64, ptr %slot315, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i64 0, ptr %p2196, align 8, !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot295, align 8
  %p2199 = inttoptr i64 %v2197 to ptr
  %gep2200 = getelementptr i8, ptr %p2199, i64 24
  %op2198 = ptrtoint ptr %gep2200 to i64
  store i64 %op2198, ptr %slot316, align 8
  %v2201 = load i64, ptr %slot316, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i64 0, ptr %p2202, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone428
bb_rcslotdone428:
  %v2203 = load i64, ptr %slot31, align 8
  store i64 %v2203, ptr %slot317, align 8
  %v2204 = load i64, ptr %slot27, align 8
  store i64 %v2204, ptr %slot318, align 8
  %v2205 = load i64, ptr %slot318, align 8
  %v2206 = load i64, ptr %slot317, align 8
  %p2207 = inttoptr i64 %v2205 to ptr
  %p2208 = inttoptr i64 %v2206 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2208, ptr %p2207, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2209 = load i64, ptr %slot23, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  store i32 0, ptr %p2210, align 4, !alias.scope !3, !noalias !4
  %v2211 = load i64, ptr %slot9, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  store i32 2, ptr %p2212, align 4, !alias.scope !3, !noalias !4
  %v2213 = load i64, ptr %slot24, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i32, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2215, ptr %slot319, align 8
  %v2216 = load i32, ptr %slot319, align 8
  %v2217 = load i64, ptr %slot9, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  store i32 %v2216, ptr %p2218, align 4, !alias.scope !3, !noalias !4
  %v2219 = load i64, ptr %slot8, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  store i32 1, ptr %p2220, align 4, !alias.scope !3, !noalias !4
  %v2221 = load i64, ptr %slot31, align 8
  %v2222 = load i64, ptr %slot37, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i64 %v2221, ptr %p2223, align 8, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot37, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i64, ptr %p2225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2226, ptr %slot320, align 8
  %v2227 = load i64, ptr %slot1, align 8
  %v2228 = load i64, ptr %slot320, align 8
  call void @myl_f_e4b0bf9563972641903c91a76184ac78f1f83b05bb4beab9462ad6bdca4a1ea9(ptr sret([40 x i8]) align 8 %callresult322, i64 %v2227, i64 %v2228) nomerge, !dbg !130
  %addr2229 = ptrtoint ptr %callresult322 to i64
  store i64 %addr2229, ptr %slot321, align 8
  %v2230 = load i64, ptr %slot321, align 8
  %v2231 = load i64, ptr %slot37, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  store i64 %v2230, ptr %p2232, align 8, !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot37, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i64, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2235, ptr %slot323, align 8
  %v2236 = load i64, ptr %slot27, align 8
  store i64 %v2236, ptr %slot324, align 8
  %v2237 = load i64, ptr %slot323, align 8
  %v2238 = load i64, ptr %slot324, align 8
  %p2239 = inttoptr i64 %v2237 to ptr
  %p2240 = inttoptr i64 %v2238 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2240, ptr %p2239, i64 40, i1 false)
  %v2241 = load i64, ptr %slot24, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  store i32 2, ptr %p2242, align 4, !alias.scope !3, !noalias !4
  %v2243 = load i64, ptr %slot23, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  store i32 1, ptr %p2244, align 4, !alias.scope !3, !noalias !4
  %v2245 = load i64, ptr %slot20, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i32, ptr %p2246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2247, ptr %slot325, align 8
  %v2248 = load i32, ptr %slot325, align 8
  %cv2249 = zext i32 %v2248 to i64
  %cond2250 = icmp ne i64 %cv2249, 0
  br i1 %cond2250, label %bb_rcslotdrop468, label %bb_rcslotdone468
bb_rcslotdrop468:
  %v2251 = load i64, ptr %slot20, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i32 0, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot26, align 8
  store i64 %v2253, ptr %slot326, align 8
  %v2254 = load i64, ptr %slot21, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  %ld2256 = load i32, ptr %p2255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2256, ptr %slot327, align 8
  %v2257 = load i32, ptr %slot327, align 8
  %op2258 = and i32 %v2257, 28
  store i32 %op2258, ptr %slot328, align 8
  %v2259 = load i32, ptr %slot328, align 8
  %cv2260 = zext i32 %v2259 to i64
  %cond2261 = icmp ne i64 %cv2260, 0
  br i1 %cond2261, label %bb_rcslotrole468, label %bb_rcslotowner468
bb_rcslotrole468:
  %v2262 = load i64, ptr %slot49, align 8
  store i64 %v2262, ptr %slot329, align 8
  %v2263 = load i64, ptr %slot329, align 8
  %v2264 = load i64, ptr %slot326, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2263, i64 %v2264) nomerge, !dbg !130
  br label %bb_rcslotdone468
bb_rcslotowner468:
  %v2265 = load i64, ptr %slot49, align 8
  store i64 %v2265, ptr %slot330, align 8
  %v2266 = load i64, ptr %slot330, align 8
  %v2267 = load i64, ptr %slot326, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v2266, i64 %v2267) nomerge, !dbg !130
  br label %bb_rcslotdone468
bb_rcslotdone468:
  %v2268 = load i64, ptr %slot26, align 8
  store i64 %v2268, ptr %slot331, align 8
  %v2269 = load i64, ptr %slot27, align 8
  store i64 %v2269, ptr %slot332, align 8
  %v2270 = load i64, ptr %slot332, align 8
  %v2271 = load i64, ptr %slot331, align 8
  %p2272 = inttoptr i64 %v2270 to ptr
  %p2273 = inttoptr i64 %v2271 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2273, ptr %p2272, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2274 = load i64, ptr %slot21, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i32 2, ptr %p2275, align 4, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot24, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i32, ptr %p2277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2278, ptr %slot333, align 8
  %v2279 = load i32, ptr %slot333, align 8
  %v2280 = load i64, ptr %slot21, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i32 %v2279, ptr %p2281, align 4, !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot23, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i32 0, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  %v2284 = load i64, ptr %slot20, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 1, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot331, align 8
  %v2287 = load i64, ptr %slot37, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i64 %v2286, ptr %p2288, align 8, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot37, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ld2291 = load i64, ptr %p2290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2291, ptr %slot334, align 8
  %v2292 = load i64, ptr %slot27, align 8
  store i64 %v2292, ptr %slot335, align 8
  %v2293 = load i64, ptr %slot50, align 8
  store i64 %v2293, ptr %slot336, align 8
  %v2294 = load i64, ptr %slot49, align 8
  %v2295 = load i64, ptr %slot335, align 8
  %v2296 = load i64, ptr %slot334, align 8
  %v2297 = load i64, ptr %slot336, align 8
  %cv2298 = trunc i64 %v2297 to i32
  %call2299 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v2294, i64 %v2295, i64 %v2296, i32 %cv2298) nomerge, !dbg !132
  store i32 %call2299, ptr %slot337, align 8
  %v2300 = load i32, ptr %slot337, align 8
  %cv2301 = zext i32 %v2300 to i64
  %cond2302 = icmp ne i64 %cv2301, 0
  br i1 %cond2302, label %bb_rcsuccess487, label %bb_rcfailure487
bb_rcfailure487:
  %v2303 = load i64, ptr %slot49, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  %call2305 = call i32 @myl_rc_take_failure(ptr %p2304) nomerge, !dbg !132
  store i32 %call2305, ptr %slot338, align 8
  %v2306 = load i64, ptr %slot1, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  %v2308 = load i32, ptr %slot338, align 8
  %call2309 = call i32 @myl_qbe_rc_status(ptr %p2307, i32 %v2308) nomerge, !dbg !132
  store i32 %call2309, ptr %slot339, align 8
  br label %bb_failure
bb_rcsuccess487:
  %v2310 = load i64, ptr %slot20, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  store i32 0, ptr %p2311, align 4, !alias.scope !3, !noalias !4
  %v2312 = load i64, ptr %slot24, align 8
  %p2313 = inttoptr i64 %v2312 to ptr
  store i32 2, ptr %p2313, align 4, !alias.scope !3, !noalias !4
  %v2314 = load i64, ptr %slot23, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 1, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot10, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i32, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2318, ptr %slot340, align 8
  %v2319 = load i32, ptr %slot340, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcslotdrop496, label %bb_rcslotdone496
bb_rcslotdrop496:
  %v2322 = load i64, ptr %slot10, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  store i32 0, ptr %p2323, align 4, !alias.scope !3, !noalias !4
  %v2324 = load i64, ptr %slot32, align 8
  store i64 %v2324, ptr %slot341, align 8
  %v2325 = load i64, ptr %slot11, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %ld2327 = load i32, ptr %p2326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2327, ptr %slot342, align 8
  %v2328 = load i32, ptr %slot342, align 8
  %op2329 = and i32 %v2328, 28
  store i32 %op2329, ptr %slot343, align 8
  %v2330 = load i32, ptr %slot343, align 8
  %cv2331 = zext i32 %v2330 to i64
  %cond2332 = icmp ne i64 %cv2331, 0
  br i1 %cond2332, label %bb_rcslotrole496, label %bb_rcslotowner496
bb_rcslotrole496:
  %v2333 = load i64, ptr %slot49, align 8
  store i64 %v2333, ptr %slot344, align 8
  %v2334 = load i64, ptr %slot344, align 8
  %v2335 = load i64, ptr %slot341, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2334, i64 %v2335) nomerge, !dbg !132
  br label %bb_rcslotdone496
bb_rcslotowner496:
  %v2336 = load i64, ptr %slot49, align 8
  store i64 %v2336, ptr %slot345, align 8
  %v2337 = load i64, ptr %slot345, align 8
  %v2338 = load i64, ptr %slot341, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2337, i64 %v2338) nomerge, !dbg !132
  br label %bb_rcslotdone496
bb_rcslotdone496:
  %v2339 = load i64, ptr %slot32, align 8
  store i64 %v2339, ptr %slot346, align 8
  %v2340 = load i64, ptr %slot27, align 8
  store i64 %v2340, ptr %slot347, align 8
  %v2341 = load i64, ptr %slot347, align 8
  %v2342 = load i64, ptr %slot346, align 8
  %p2343 = inttoptr i64 %v2341 to ptr
  %p2344 = inttoptr i64 %v2342 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2344, ptr %p2343, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot23, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  store i32 0, ptr %p2346, align 4, !alias.scope !3, !noalias !4
  %v2347 = load i64, ptr %slot11, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  store i32 2, ptr %p2348, align 4, !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot24, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  %ld2351 = load i32, ptr %p2350, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2351, ptr %slot348, align 8
  %v2352 = load i32, ptr %slot348, align 8
  %v2353 = load i64, ptr %slot11, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i32 %v2352, ptr %p2354, align 4, !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot10, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i32 1, ptr %p2356, align 4, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot31, align 8
  %v2358 = load i64, ptr %slot37, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i64 %v2357, ptr %p2359, align 8, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot37, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i64, ptr %p2361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2362, ptr %slot349, align 8
  %v2363 = load i64, ptr %slot20, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i32, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2365, ptr %slot350, align 8
  %v2366 = load i64, ptr %slot21, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %ld2368 = load i32, ptr %p2367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2368, ptr %slot351, align 8
  %v2369 = load i32, ptr %slot351, align 8
  %op2370 = and i32 %v2369, 24
  store i32 %op2370, ptr %slot351, align 8
  %v2371 = load i32, ptr %slot351, align 8
  %cmp2372 = icmp eq i32 %v2371, 0
  %cv2373 = zext i1 %cmp2372 to i32
  store i32 %cv2373, ptr %slot352, align 8
  %v2374 = load i32, ptr %slot350, align 8
  %v2375 = load i32, ptr %slot352, align 8
  %op2376 = and i32 %v2374, %v2375
  store i32 %op2376, ptr %slot353, align 8
  %v2377 = load i32, ptr %slot353, align 8
  %cv2378 = zext i32 %v2377 to i64
  %cond2379 = icmp ne i64 %cv2378, 0
  br i1 %cond2379, label %bb_rcprivateown517, label %bb_rcprivateloan517
bb_rcprivateown517:
  %v2380 = load i64, ptr %slot27, align 8
  store i64 %v2380, ptr %slot354, align 8
  %v2381 = load i64, ptr %slot50, align 8
  store i64 %v2381, ptr %slot355, align 8
  %v2382 = load i64, ptr %slot349, align 8
  %v2383 = load i64, ptr %slot354, align 8
  %op2384 = sub i64 %v2382, %v2383
  store i64 %op2384, ptr %slot356, align 8
  %v2385 = load i64, ptr %slot354, align 8
  %v2386 = load i64, ptr %slot349, align 8
  %op2387 = sub i64 %v2385, %v2386
  store i64 %op2387, ptr %slot357, align 8
  %v2388 = load i64, ptr %slot356, align 8
  %cmp2389 = icmp ult i64 %v2388, 32
  %cv2390 = zext i1 %cmp2389 to i32
  store i32 %cv2390, ptr %slot358, align 8
  %v2391 = load i64, ptr %slot357, align 8
  %cmp2392 = icmp ult i64 %v2391, 32
  %cv2393 = zext i1 %cmp2392 to i32
  store i32 %cv2393, ptr %slot359, align 8
  %v2394 = load i32, ptr %slot358, align 8
  %v2395 = load i32, ptr %slot359, align 8
  %op2396 = or i32 %v2394, %v2395
  store i32 %op2396, ptr %slot360, align 8
  %v2397 = load i32, ptr %slot360, align 8
  %cv2398 = zext i32 %v2397 to i64
  %cond2399 = icmp ne i64 %cv2398, 0
  br i1 %cond2399, label %bb_rcmoveslow520, label %bb_rcmovecheck520
bb_rcmovecheck520:
  %v2400 = load i64, ptr %slot349, align 8
  %op2401 = add i64 %v2400, 0
  store i64 %op2401, ptr %slot361, align 8
  %v2402 = load i64, ptr %slot361, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  %ld2404 = load i64, ptr %p2403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2404, ptr %slot362, align 8
  %v2405 = load i64, ptr %slot362, align 8
  %cmp2406 = icmp ne i64 %v2405, 0
  %cv2407 = zext i1 %cmp2406 to i32
  store i32 %cv2407, ptr %slot363, align 8
  %v2408 = load i32, ptr %slot363, align 8
  %cv2409 = zext i32 %v2408 to i64
  %cond2410 = icmp ne i64 %cv2409, 0
  br i1 %cond2410, label %bb_rcmoveheader528, label %bb_rcmovenext528
bb_rcmoveheader528:
  %v2411 = load i64, ptr %slot362, align 8
  %op2412 = sub i64 %v2411, 16
  store i64 %op2412, ptr %slot364, align 8
  %v2413 = load i64, ptr %slot362, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  %rgep2415 = getelementptr i8, ptr %p2414, i64 -16
  %ld2416 = load i64, ptr %rgep2415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2416, ptr %slot365, align 8
  %v2417 = load i64, ptr %slot365, align 8
  %op2418 = and i64 %v2417, 5764607523034234881
  store i64 %op2418, ptr %slot366, align 8
  %v2419 = load i64, ptr %slot366, align 8
  %cmp2420 = icmp ne i64 %v2419, 0
  %cv2421 = zext i1 %cmp2420 to i32
  store i32 %cv2421, ptr %slot367, align 8
  %v2422 = load i32, ptr %slot367, align 8
  %cv2423 = zext i32 %v2422 to i64
  %cond2424 = icmp ne i64 %cv2423, 0
  br i1 %cond2424, label %bb_rcmoveslow520, label %bb_rcmovenext528
bb_rcmovenext528:
  %v2425 = load i64, ptr %slot349, align 8
  %v2426 = load i64, ptr %slot354, align 8
  %p2427 = inttoptr i64 %v2425 to ptr
  %p2428 = inttoptr i64 %v2426 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2428, ptr %p2427, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2429 = load i64, ptr %slot349, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  store i64 0, ptr %p2430, align 8, !alias.scope !3, !noalias !4
  %v2431 = load i64, ptr %slot349, align 8
  %op2432 = add i64 %v2431, 8
  store i64 %op2432, ptr %slot368, align 8
  %v2433 = load i64, ptr %slot368, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i64 0, ptr %p2434, align 8, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot349, align 8
  %op2436 = add i64 %v2435, 16
  store i64 %op2436, ptr %slot369, align 8
  %v2437 = load i64, ptr %slot369, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  store i64 0, ptr %p2438, align 8, !alias.scope !3, !noalias !4
  %v2439 = load i64, ptr %slot349, align 8
  %op2440 = add i64 %v2439, 24
  store i64 %op2440, ptr %slot370, align 8
  %v2441 = load i64, ptr %slot370, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i64 0, ptr %p2442, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved520
bb_rcmoveslow520:
  %v2443 = load i64, ptr %slot49, align 8
  %v2444 = load i64, ptr %slot354, align 8
  %v2445 = load i64, ptr %slot349, align 8
  %v2446 = load i64, ptr %slot355, align 8
  %cv2447 = trunc i64 %v2446 to i32
  %call2448 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v2443, i64 %v2444, i64 %v2445, i32 %cv2447) nomerge, !dbg !134
  store i32 %call2448, ptr %slot371, align 8
  %v2449 = load i32, ptr %slot371, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcsuccess538, label %bb_rcfailure538
bb_rcfailure538:
  %v2452 = load i64, ptr %slot49, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %call2454 = call i32 @myl_rc_take_failure(ptr %p2453) nomerge, !dbg !134
  store i32 %call2454, ptr %slot372, align 8
  %v2455 = load i64, ptr %slot1, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %v2457 = load i32, ptr %slot372, align 8
  %call2458 = call i32 @myl_qbe_rc_status(ptr %p2456, i32 %v2457) nomerge, !dbg !134
  store i32 %call2458, ptr %slot373, align 8
  br label %bb_failure
bb_rcsuccess538:
  br label %bb_rcmoved520
bb_rcmoved520:
  %v2459 = load i64, ptr %slot20, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  store i32 0, ptr %p2460, align 4, !alias.scope !3, !noalias !4
  %v2461 = load i64, ptr %slot24, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  store i32 2, ptr %p2462, align 4, !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot23, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  store i32 1, ptr %p2464, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared517
bb_rcprivateloan517:
  %v2465 = load i64, ptr %slot27, align 8
  store i64 %v2465, ptr %slot374, align 8
  %v2466 = load i64, ptr %slot49, align 8
  %v2467 = load i64, ptr %slot374, align 8
  %v2468 = load i64, ptr %slot349, align 8
  %call2469 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_loan(i64 %v2466, i64 %v2467, i64 %v2468) nomerge, !dbg !134
  store i32 %call2469, ptr %slot375, align 8
  %v2470 = load i32, ptr %slot375, align 8
  %cv2471 = zext i32 %v2470 to i64
  %cond2472 = icmp ne i64 %cv2471, 0
  br i1 %cond2472, label %bb_rcsuccess546, label %bb_rcfailure546
bb_rcfailure546:
  %v2473 = load i64, ptr %slot49, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %call2475 = call i32 @myl_rc_take_failure(ptr %p2474) nomerge, !dbg !134
  store i32 %call2475, ptr %slot376, align 8
  %v2476 = load i64, ptr %slot1, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %v2478 = load i32, ptr %slot376, align 8
  %call2479 = call i32 @myl_qbe_rc_status(ptr %p2477, i32 %v2478) nomerge, !dbg !134
  store i32 %call2479, ptr %slot377, align 8
  br label %bb_failure
bb_rcsuccess546:
  %v2480 = load i64, ptr %slot24, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  store i32 2, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot24, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i32 16, ptr %p2483, align 4, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot23, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i32 1, ptr %p2485, align 4, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot20, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  %ld2488 = load i32, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2488, ptr %slot378, align 8
  %v2489 = load i32, ptr %slot378, align 8
  %cv2490 = zext i32 %v2489 to i64
  %cond2491 = icmp ne i64 %cv2490, 0
  br i1 %cond2491, label %bb_rcslotdrop554, label %bb_rcslotdone554
bb_rcslotdrop554:
  %v2492 = load i64, ptr %slot20, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i32 0, ptr %p2493, align 4, !alias.scope !3, !noalias !4
  %v2494 = load i64, ptr %slot26, align 8
  store i64 %v2494, ptr %slot379, align 8
  %v2495 = load i64, ptr %slot21, align 8
  %p2496 = inttoptr i64 %v2495 to ptr
  %ld2497 = load i32, ptr %p2496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2497, ptr %slot380, align 8
  %v2498 = load i32, ptr %slot380, align 8
  %op2499 = and i32 %v2498, 28
  store i32 %op2499, ptr %slot381, align 8
  %v2500 = load i32, ptr %slot381, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcslotrole554, label %bb_rcslotowner554
bb_rcslotrole554:
  %v2503 = load i64, ptr %slot49, align 8
  store i64 %v2503, ptr %slot382, align 8
  %v2504 = load i64, ptr %slot382, align 8
  %v2505 = load i64, ptr %slot379, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2504, i64 %v2505) nomerge, !dbg !134
  br label %bb_rcslotdone554
bb_rcslotowner554:
  %v2506 = load i64, ptr %slot379, align 8
  %p2508 = inttoptr i64 %v2506 to ptr
  %gep2509 = getelementptr i8, ptr %p2508, i64 0
  %op2507 = ptrtoint ptr %gep2509 to i64
  store i64 %op2507, ptr %slot383, align 8
  %v2510 = load i64, ptr %slot49, align 8
  store i64 %v2510, ptr %slot384, align 8
  %v2511 = load i64, ptr %slot383, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %ld2513 = load i64, ptr %p2512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2513, ptr %slot385, align 8
  %v2514 = load i64, ptr %slot385, align 8
  %cmp2515 = icmp ne i64 %v2514, 0
  %cv2516 = zext i1 %cmp2515 to i32
  store i32 %cv2516, ptr %slot386, align 8
  %v2517 = load i32, ptr %slot386, align 8
  %cv2518 = zext i32 %v2517 to i64
  %cond2519 = icmp ne i64 %cv2518, 0
  br i1 %cond2519, label %bb_rcgnn572, label %bb_rcgdone572
bb_rcgnn572:
  %v2520 = load i64, ptr %slot385, align 8
  %op2521 = sub i64 %v2520, 16
  store i64 %op2521, ptr %slot387, align 8
  %v2522 = load i64, ptr %slot385, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  %rgep2524 = getelementptr i8, ptr %p2523, i64 -16
  %ld2525 = load i64, ptr %rgep2524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2525, ptr %slot388, align 8
  %v2526 = load i64, ptr %slot388, align 8
  %op2527 = and i64 %v2526, 4611686018427387906
  store i64 %op2527, ptr %slot389, align 8
  %v2528 = load i64, ptr %slot389, align 8
  %cmp2529 = icmp ne i64 %v2528, 0
  %cv2530 = zext i1 %cmp2529 to i32
  store i32 %cv2530, ptr %slot390, align 8
  %v2531 = load i32, ptr %slot390, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rcgclear572, label %bb_rcgcounted572
bb_rcgcounted572:
  %v2534 = load i64, ptr %slot385, align 8
  %op2535 = sub i64 %v2534, 32
  store i64 %op2535, ptr %slot391, align 8
  %v2536 = load i64, ptr %slot385, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %rgep2538 = getelementptr i8, ptr %p2537, i64 -32
  %ld2539 = load i64, ptr %rgep2538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2539, ptr %slot392, align 8
  %v2540 = load i64, ptr %slot392, align 8
  %op2541 = sub i64 %v2540, 1
  store i64 %op2541, ptr %slot393, align 8
  %v2542 = load i64, ptr %slot393, align 8
  %cmp2543 = icmp eq i64 %v2542, 0
  %cv2544 = zext i1 %cmp2543 to i32
  store i32 %cv2544, ptr %slot394, align 8
  %v2545 = load i32, ptr %slot394, align 8
  %cv2546 = zext i32 %v2545 to i64
  %cond2547 = icmp ne i64 %cv2546, 0
  br i1 %cond2547, label %bb_rcglast572, label %bb_rcgdec572
bb_rcglast572:
  %v2548 = load i64, ptr %slot385, align 8
  %op2549 = sub i64 %v2548, 24
  store i64 %op2549, ptr %slot395, align 8
  %v2550 = load i64, ptr %slot385, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %rgep2552 = getelementptr i8, ptr %p2551, i64 -24
  %ld2553 = load i64, ptr %rgep2552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2553, ptr %slot396, align 8
  %v2554 = load i64, ptr %slot396, align 8
  %cmp2555 = icmp ne i64 %v2554, 0
  %cv2556 = zext i1 %cmp2555 to i32
  store i32 %cv2556, ptr %slot397, align 8
  %v2557 = load i32, ptr %slot397, align 8
  %cv2558 = zext i32 %v2557 to i64
  %cond2559 = icmp ne i64 %cv2558, 0
  br i1 %cond2559, label %bb_rcgdec572, label %bb_rcgslow572
bb_rcgslow572:
  %v2560 = load i64, ptr %slot384, align 8
  %v2561 = load i64, ptr %slot383, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2560, i64 %v2561) nomerge, !dbg !134
  br label %bb_rcgdone572
bb_rcgdec572:
  %v2562 = load i64, ptr %slot393, align 8
  %v2563 = load i64, ptr %slot385, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %rgep2565 = getelementptr i8, ptr %p2564, i64 -32
  store i64 %v2562, ptr %rgep2565, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear572
bb_rcgclear572:
  %v2566 = load i64, ptr %slot383, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i64 0, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone572
bb_rcgdone572:
  %v2568 = load i64, ptr %slot379, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  store i64 0, ptr %p2569, align 8, !alias.scope !3, !noalias !4
  %v2570 = load i64, ptr %slot379, align 8
  %p2572 = inttoptr i64 %v2570 to ptr
  %gep2573 = getelementptr i8, ptr %p2572, i64 8
  %op2571 = ptrtoint ptr %gep2573 to i64
  store i64 %op2571, ptr %slot398, align 8
  %v2574 = load i64, ptr %slot398, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  store i64 0, ptr %p2575, align 8, !alias.scope !3, !noalias !4
  %v2576 = load i64, ptr %slot379, align 8
  %p2578 = inttoptr i64 %v2576 to ptr
  %gep2579 = getelementptr i8, ptr %p2578, i64 16
  %op2577 = ptrtoint ptr %gep2579 to i64
  store i64 %op2577, ptr %slot399, align 8
  %v2580 = load i64, ptr %slot399, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  store i64 0, ptr %p2581, align 8, !alias.scope !3, !noalias !4
  %v2582 = load i64, ptr %slot379, align 8
  %p2584 = inttoptr i64 %v2582 to ptr
  %gep2585 = getelementptr i8, ptr %p2584, i64 24
  %op2583 = ptrtoint ptr %gep2585 to i64
  store i64 %op2583, ptr %slot400, align 8
  %v2586 = load i64, ptr %slot400, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  store i64 0, ptr %p2587, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone554
bb_rcslotdone554:
  br label %bb_rcprivateprepared517
bb_rcprivateprepared517:
  %v2588 = load i64, ptr %slot14, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %ld2590 = load i32, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2590, ptr %slot401, align 8
  %v2591 = load i32, ptr %slot401, align 8
  %cv2592 = zext i32 %v2591 to i64
  %cond2593 = icmp ne i64 %cv2592, 0
  br i1 %cond2593, label %bb_rcslotdrop582, label %bb_rcslotdone582
bb_rcslotdrop582:
  %v2594 = load i64, ptr %slot14, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  store i32 0, ptr %p2595, align 4, !alias.scope !3, !noalias !4
  %v2596 = load i64, ptr %slot34, align 8
  store i64 %v2596, ptr %slot402, align 8
  %v2597 = load i64, ptr %slot15, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  %ld2599 = load i32, ptr %p2598, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2599, ptr %slot403, align 8
  %v2600 = load i32, ptr %slot403, align 8
  %op2601 = and i32 %v2600, 28
  store i32 %op2601, ptr %slot404, align 8
  %v2602 = load i32, ptr %slot404, align 8
  %cv2603 = zext i32 %v2602 to i64
  %cond2604 = icmp ne i64 %cv2603, 0
  br i1 %cond2604, label %bb_rcslotrole582, label %bb_rcslotowner582
bb_rcslotrole582:
  %v2605 = load i64, ptr %slot49, align 8
  store i64 %v2605, ptr %slot405, align 8
  %v2606 = load i64, ptr %slot405, align 8
  %v2607 = load i64, ptr %slot402, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v2606, i64 %v2607) nomerge, !dbg !134
  br label %bb_rcslotdone582
bb_rcslotowner582:
  %v2608 = load i64, ptr %slot402, align 8
  %p2610 = inttoptr i64 %v2608 to ptr
  %gep2611 = getelementptr i8, ptr %p2610, i64 0
  %op2609 = ptrtoint ptr %gep2611 to i64
  store i64 %op2609, ptr %slot406, align 8
  %v2612 = load i64, ptr %slot49, align 8
  store i64 %v2612, ptr %slot407, align 8
  %v2613 = load i64, ptr %slot406, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i64, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2615, ptr %slot408, align 8
  %v2616 = load i64, ptr %slot408, align 8
  %cmp2617 = icmp ne i64 %v2616, 0
  %cv2618 = zext i1 %cmp2617 to i32
  store i32 %cv2618, ptr %slot409, align 8
  %v2619 = load i32, ptr %slot409, align 8
  %cv2620 = zext i32 %v2619 to i64
  %cond2621 = icmp ne i64 %cv2620, 0
  br i1 %cond2621, label %bb_rcgnn600, label %bb_rcgdone600
bb_rcgnn600:
  %v2622 = load i64, ptr %slot408, align 8
  %op2623 = sub i64 %v2622, 16
  store i64 %op2623, ptr %slot410, align 8
  %v2624 = load i64, ptr %slot408, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  %rgep2626 = getelementptr i8, ptr %p2625, i64 -16
  %ld2627 = load i64, ptr %rgep2626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2627, ptr %slot411, align 8
  %v2628 = load i64, ptr %slot411, align 8
  %op2629 = and i64 %v2628, 4611686018427387906
  store i64 %op2629, ptr %slot412, align 8
  %v2630 = load i64, ptr %slot412, align 8
  %cmp2631 = icmp ne i64 %v2630, 0
  %cv2632 = zext i1 %cmp2631 to i32
  store i32 %cv2632, ptr %slot413, align 8
  %v2633 = load i32, ptr %slot413, align 8
  %cv2634 = zext i32 %v2633 to i64
  %cond2635 = icmp ne i64 %cv2634, 0
  br i1 %cond2635, label %bb_rcgclear600, label %bb_rcgcounted600
bb_rcgcounted600:
  %v2636 = load i64, ptr %slot408, align 8
  %op2637 = sub i64 %v2636, 32
  store i64 %op2637, ptr %slot414, align 8
  %v2638 = load i64, ptr %slot408, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %rgep2640 = getelementptr i8, ptr %p2639, i64 -32
  %ld2641 = load i64, ptr %rgep2640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2641, ptr %slot415, align 8
  %v2642 = load i64, ptr %slot415, align 8
  %op2643 = sub i64 %v2642, 1
  store i64 %op2643, ptr %slot416, align 8
  %v2644 = load i64, ptr %slot416, align 8
  %cmp2645 = icmp eq i64 %v2644, 0
  %cv2646 = zext i1 %cmp2645 to i32
  store i32 %cv2646, ptr %slot417, align 8
  %v2647 = load i32, ptr %slot417, align 8
  %cv2648 = zext i32 %v2647 to i64
  %cond2649 = icmp ne i64 %cv2648, 0
  br i1 %cond2649, label %bb_rcglast600, label %bb_rcgdec600
bb_rcglast600:
  %v2650 = load i64, ptr %slot408, align 8
  %op2651 = sub i64 %v2650, 24
  store i64 %op2651, ptr %slot418, align 8
  %v2652 = load i64, ptr %slot408, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %rgep2654 = getelementptr i8, ptr %p2653, i64 -24
  %ld2655 = load i64, ptr %rgep2654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2655, ptr %slot419, align 8
  %v2656 = load i64, ptr %slot419, align 8
  %cmp2657 = icmp ne i64 %v2656, 0
  %cv2658 = zext i1 %cmp2657 to i32
  store i32 %cv2658, ptr %slot420, align 8
  %v2659 = load i32, ptr %slot420, align 8
  %cv2660 = zext i32 %v2659 to i64
  %cond2661 = icmp ne i64 %cv2660, 0
  br i1 %cond2661, label %bb_rcgdec600, label %bb_rcgslow600
bb_rcgslow600:
  %v2662 = load i64, ptr %slot407, align 8
  %v2663 = load i64, ptr %slot406, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2662, i64 %v2663) nomerge, !dbg !134
  br label %bb_rcgdone600
bb_rcgdec600:
  %v2664 = load i64, ptr %slot416, align 8
  %v2665 = load i64, ptr %slot408, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %rgep2667 = getelementptr i8, ptr %p2666, i64 -32
  store i64 %v2664, ptr %rgep2667, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear600
bb_rcgclear600:
  %v2668 = load i64, ptr %slot406, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  store i64 0, ptr %p2669, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone600
bb_rcgdone600:
  %v2670 = load i64, ptr %slot402, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i64 0, ptr %p2671, align 8, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot402, align 8
  %p2674 = inttoptr i64 %v2672 to ptr
  %gep2675 = getelementptr i8, ptr %p2674, i64 8
  %op2673 = ptrtoint ptr %gep2675 to i64
  store i64 %op2673, ptr %slot421, align 8
  %v2676 = load i64, ptr %slot421, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i64 0, ptr %p2677, align 8, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot402, align 8
  %p2680 = inttoptr i64 %v2678 to ptr
  %gep2681 = getelementptr i8, ptr %p2680, i64 16
  %op2679 = ptrtoint ptr %gep2681 to i64
  store i64 %op2679, ptr %slot422, align 8
  %v2682 = load i64, ptr %slot422, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i64 0, ptr %p2683, align 8, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot402, align 8
  %p2686 = inttoptr i64 %v2684 to ptr
  %gep2687 = getelementptr i8, ptr %p2686, i64 24
  %op2685 = ptrtoint ptr %gep2687 to i64
  store i64 %op2685, ptr %slot423, align 8
  %v2688 = load i64, ptr %slot423, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i64 0, ptr %p2689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone582
bb_rcslotdone582:
  %v2690 = load i64, ptr %slot34, align 8
  store i64 %v2690, ptr %slot424, align 8
  %v2691 = load i64, ptr %slot27, align 8
  store i64 %v2691, ptr %slot425, align 8
  %v2692 = load i64, ptr %slot425, align 8
  %v2693 = load i64, ptr %slot424, align 8
  %p2694 = inttoptr i64 %v2692 to ptr
  %p2695 = inttoptr i64 %v2693 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2695, ptr %p2694, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot23, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i32 0, ptr %p2697, align 4, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot15, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 2, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  %v2700 = load i64, ptr %slot24, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  %ld2702 = load i32, ptr %p2701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2702, ptr %slot426, align 8
  %v2703 = load i32, ptr %slot426, align 8
  %v2704 = load i64, ptr %slot15, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i32 %v2703, ptr %p2705, align 4, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot14, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i32 1, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot28, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i64, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2710, ptr %slot427, align 8
  %v2711 = load i64, ptr %slot427, align 8
  %v2712 = load i64, ptr %slot37, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  store i64 %v2711, ptr %p2713, align 8, !alias.scope !3, !noalias !4
  %v2714 = load i64, ptr %slot37, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  %ld2716 = load i64, ptr %p2715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2716, ptr %slot428, align 8
  %v2717 = load i64, ptr %slot20, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %ld2719 = load i32, ptr %p2718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2719, ptr %slot429, align 8
  %v2720 = load i64, ptr %slot21, align 8
  %p2721 = inttoptr i64 %v2720 to ptr
  %ld2722 = load i32, ptr %p2721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2722, ptr %slot430, align 8
  %v2723 = load i32, ptr %slot430, align 8
  %op2724 = and i32 %v2723, 24
  store i32 %op2724, ptr %slot430, align 8
  %v2725 = load i32, ptr %slot430, align 8
  %cmp2726 = icmp eq i32 %v2725, 0
  %cv2727 = zext i1 %cmp2726 to i32
  store i32 %cv2727, ptr %slot431, align 8
  %v2728 = load i32, ptr %slot429, align 8
  %v2729 = load i32, ptr %slot431, align 8
  %op2730 = and i32 %v2728, %v2729
  store i32 %op2730, ptr %slot432, align 8
  %v2731 = load i32, ptr %slot432, align 8
  %cv2732 = zext i32 %v2731 to i64
  %cond2733 = icmp ne i64 %cv2732, 0
  br i1 %cond2733, label %bb_rcprivateown622, label %bb_rcprivateloan622
bb_rcprivateown622:
  %v2734 = load i64, ptr %slot27, align 8
  store i64 %v2734, ptr %slot433, align 8
  %v2735 = load i64, ptr %slot50, align 8
  store i64 %v2735, ptr %slot434, align 8
  %v2736 = load i64, ptr %slot49, align 8
  %v2737 = load i64, ptr %slot433, align 8
  %v2738 = load i64, ptr %slot428, align 8
  %v2739 = load i64, ptr %slot434, align 8
  %cv2740 = trunc i64 %v2739 to i32
  %call2741 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v2736, i64 %v2737, i64 %v2738, i32 %cv2740) nomerge, !dbg !136
  store i32 %call2741, ptr %slot435, align 8
  %v2742 = load i32, ptr %slot435, align 8
  %cv2743 = zext i32 %v2742 to i64
  %cond2744 = icmp ne i64 %cv2743, 0
  br i1 %cond2744, label %bb_rcsuccess626, label %bb_rcfailure626
bb_rcfailure626:
  %v2745 = load i64, ptr %slot49, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %call2747 = call i32 @myl_rc_take_failure(ptr %p2746) nomerge, !dbg !136
  store i32 %call2747, ptr %slot436, align 8
  %v2748 = load i64, ptr %slot1, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  %v2750 = load i32, ptr %slot436, align 8
  %call2751 = call i32 @myl_qbe_rc_status(ptr %p2749, i32 %v2750) nomerge, !dbg !136
  store i32 %call2751, ptr %slot437, align 8
  br label %bb_failure
bb_rcsuccess626:
  %v2752 = load i64, ptr %slot20, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  store i32 0, ptr %p2753, align 4, !alias.scope !3, !noalias !4
  %v2754 = load i64, ptr %slot24, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  store i32 2, ptr %p2755, align 4, !alias.scope !3, !noalias !4
  %v2756 = load i64, ptr %slot23, align 8
  %p2757 = inttoptr i64 %v2756 to ptr
  store i32 1, ptr %p2757, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared622
bb_rcprivateloan622:
  %v2758 = load i64, ptr %slot27, align 8
  store i64 %v2758, ptr %slot438, align 8
  %v2759 = load i64, ptr %slot49, align 8
  %v2760 = load i64, ptr %slot438, align 8
  %v2761 = load i64, ptr %slot428, align 8
  %call2762 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v2759, i64 %v2760, i64 %v2761) nomerge, !dbg !136
  store i32 %call2762, ptr %slot439, align 8
  %v2763 = load i32, ptr %slot439, align 8
  %cv2764 = zext i32 %v2763 to i64
  %cond2765 = icmp ne i64 %cv2764, 0
  br i1 %cond2765, label %bb_rcsuccess634, label %bb_rcfailure634
bb_rcfailure634:
  %v2766 = load i64, ptr %slot49, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %call2768 = call i32 @myl_rc_take_failure(ptr %p2767) nomerge, !dbg !136
  store i32 %call2768, ptr %slot440, align 8
  %v2769 = load i64, ptr %slot1, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %v2771 = load i32, ptr %slot440, align 8
  %call2772 = call i32 @myl_qbe_rc_status(ptr %p2770, i32 %v2771) nomerge, !dbg !136
  store i32 %call2772, ptr %slot441, align 8
  br label %bb_failure
bb_rcsuccess634:
  %v2773 = load i64, ptr %slot24, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i32 2, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot24, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i32 16, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot23, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  store i32 1, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot20, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %ld2781 = load i32, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2781, ptr %slot442, align 8
  %v2782 = load i32, ptr %slot442, align 8
  %cv2783 = zext i32 %v2782 to i64
  %cond2784 = icmp ne i64 %cv2783, 0
  br i1 %cond2784, label %bb_rcslotdrop642, label %bb_rcslotdone642
bb_rcslotdrop642:
  %v2785 = load i64, ptr %slot20, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  store i32 0, ptr %p2786, align 4, !alias.scope !3, !noalias !4
  %v2787 = load i64, ptr %slot26, align 8
  store i64 %v2787, ptr %slot443, align 8
  %v2788 = load i64, ptr %slot21, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i32, ptr %p2789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2790, ptr %slot444, align 8
  %v2791 = load i32, ptr %slot444, align 8
  %op2792 = and i32 %v2791, 28
  store i32 %op2792, ptr %slot445, align 8
  %v2793 = load i32, ptr %slot445, align 8
  %cv2794 = zext i32 %v2793 to i64
  %cond2795 = icmp ne i64 %cv2794, 0
  br i1 %cond2795, label %bb_rcslotrole642, label %bb_rcslotowner642
bb_rcslotrole642:
  %v2796 = load i64, ptr %slot49, align 8
  store i64 %v2796, ptr %slot446, align 8
  %v2797 = load i64, ptr %slot446, align 8
  %v2798 = load i64, ptr %slot443, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2797, i64 %v2798) nomerge, !dbg !136
  br label %bb_rcslotdone642
bb_rcslotowner642:
  %v2799 = load i64, ptr %slot49, align 8
  store i64 %v2799, ptr %slot447, align 8
  %v2800 = load i64, ptr %slot447, align 8
  %v2801 = load i64, ptr %slot443, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2800, i64 %v2801) nomerge, !dbg !136
  br label %bb_rcslotdone642
bb_rcslotdone642:
  br label %bb_rcprivateprepared622
bb_rcprivateprepared622:
  %v2802 = load i64, ptr %slot12, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %ld2804 = load i32, ptr %p2803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2804, ptr %slot448, align 8
  %v2805 = load i32, ptr %slot448, align 8
  %cv2806 = zext i32 %v2805 to i64
  %cond2807 = icmp ne i64 %cv2806, 0
  br i1 %cond2807, label %bb_rcslotdrop652, label %bb_rcslotdone652
bb_rcslotdrop652:
  %v2808 = load i64, ptr %slot12, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i32 0, ptr %p2809, align 4, !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot33, align 8
  store i64 %v2810, ptr %slot449, align 8
  %v2811 = load i64, ptr %slot13, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %ld2813 = load i32, ptr %p2812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2813, ptr %slot450, align 8
  %v2814 = load i32, ptr %slot450, align 8
  %op2815 = and i32 %v2814, 28
  store i32 %op2815, ptr %slot451, align 8
  %v2816 = load i32, ptr %slot451, align 8
  %cv2817 = zext i32 %v2816 to i64
  %cond2818 = icmp ne i64 %cv2817, 0
  br i1 %cond2818, label %bb_rcslotrole652, label %bb_rcslotowner652
bb_rcslotrole652:
  %v2819 = load i64, ptr %slot49, align 8
  store i64 %v2819, ptr %slot452, align 8
  %v2820 = load i64, ptr %slot452, align 8
  %v2821 = load i64, ptr %slot449, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2820, i64 %v2821) nomerge, !dbg !136
  br label %bb_rcslotdone652
bb_rcslotowner652:
  %v2822 = load i64, ptr %slot49, align 8
  store i64 %v2822, ptr %slot453, align 8
  %v2823 = load i64, ptr %slot453, align 8
  %v2824 = load i64, ptr %slot449, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2823, i64 %v2824) nomerge, !dbg !136
  br label %bb_rcslotdone652
bb_rcslotdone652:
  %v2825 = load i64, ptr %slot33, align 8
  store i64 %v2825, ptr %slot454, align 8
  %v2826 = load i64, ptr %slot27, align 8
  store i64 %v2826, ptr %slot455, align 8
  %v2827 = load i64, ptr %slot455, align 8
  %v2828 = load i64, ptr %slot454, align 8
  %p2829 = inttoptr i64 %v2827 to ptr
  %p2830 = inttoptr i64 %v2828 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2830, ptr %p2829, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot23, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  store i32 0, ptr %p2832, align 4, !alias.scope !3, !noalias !4
  %v2833 = load i64, ptr %slot13, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  store i32 2, ptr %p2834, align 4, !alias.scope !3, !noalias !4
  %v2835 = load i64, ptr %slot24, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  %ld2837 = load i32, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2837, ptr %slot456, align 8
  %v2838 = load i32, ptr %slot456, align 8
  %v2839 = load i64, ptr %slot13, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 %v2838, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot12, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  store i32 1, ptr %p2842, align 4, !alias.scope !3, !noalias !4
  %v2843 = load i64, ptr %slot28, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  %ld2845 = load i64, ptr %p2844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2845, ptr %slot457, align 8
  %v2846 = load i64, ptr %slot457, align 8
  %v2847 = load i64, ptr %slot37, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  store i64 %v2846, ptr %p2848, align 8, !alias.scope !3, !noalias !4
  %v2849 = load i64, ptr %slot37, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %ld2851 = load i64, ptr %p2850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2851, ptr %slot458, align 8
  %v2852 = load i64, ptr %slot20, align 8
  %p2853 = inttoptr i64 %v2852 to ptr
  %ld2854 = load i32, ptr %p2853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2854, ptr %slot459, align 8
  %v2855 = load i64, ptr %slot21, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  %ld2857 = load i32, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2857, ptr %slot460, align 8
  %v2858 = load i32, ptr %slot460, align 8
  %op2859 = and i32 %v2858, 24
  store i32 %op2859, ptr %slot460, align 8
  %v2860 = load i32, ptr %slot460, align 8
  %cmp2861 = icmp eq i32 %v2860, 0
  %cv2862 = zext i1 %cmp2861 to i32
  store i32 %cv2862, ptr %slot461, align 8
  %v2863 = load i32, ptr %slot459, align 8
  %v2864 = load i32, ptr %slot461, align 8
  %op2865 = and i32 %v2863, %v2864
  store i32 %op2865, ptr %slot462, align 8
  %v2866 = load i32, ptr %slot462, align 8
  %cv2867 = zext i32 %v2866 to i64
  %cond2868 = icmp ne i64 %cv2867, 0
  br i1 %cond2868, label %bb_rcprivateown674, label %bb_rcprivateloan674
bb_rcprivateown674:
  %v2869 = load i64, ptr %slot27, align 8
  store i64 %v2869, ptr %slot463, align 8
  %v2870 = load i64, ptr %slot50, align 8
  store i64 %v2870, ptr %slot464, align 8
  %v2871 = load i64, ptr %slot49, align 8
  %v2872 = load i64, ptr %slot463, align 8
  %v2873 = load i64, ptr %slot458, align 8
  %v2874 = load i64, ptr %slot464, align 8
  %cv2875 = trunc i64 %v2874 to i32
  %call2876 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v2871, i64 %v2872, i64 %v2873, i32 %cv2875) nomerge, !dbg !138
  store i32 %call2876, ptr %slot465, align 8
  %v2877 = load i32, ptr %slot465, align 8
  %cv2878 = zext i32 %v2877 to i64
  %cond2879 = icmp ne i64 %cv2878, 0
  br i1 %cond2879, label %bb_rcsuccess678, label %bb_rcfailure678
bb_rcfailure678:
  %v2880 = load i64, ptr %slot49, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %call2882 = call i32 @myl_rc_take_failure(ptr %p2881) nomerge, !dbg !138
  store i32 %call2882, ptr %slot466, align 8
  %v2883 = load i64, ptr %slot1, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %v2885 = load i32, ptr %slot466, align 8
  %call2886 = call i32 @myl_qbe_rc_status(ptr %p2884, i32 %v2885) nomerge, !dbg !138
  store i32 %call2886, ptr %slot467, align 8
  br label %bb_failure
bb_rcsuccess678:
  %v2887 = load i64, ptr %slot20, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  store i32 0, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  %v2889 = load i64, ptr %slot24, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i32 2, ptr %p2890, align 4, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot23, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  store i32 1, ptr %p2892, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared674
bb_rcprivateloan674:
  %v2893 = load i64, ptr %slot27, align 8
  store i64 %v2893, ptr %slot468, align 8
  %v2894 = load i64, ptr %slot49, align 8
  %v2895 = load i64, ptr %slot468, align 8
  %v2896 = load i64, ptr %slot458, align 8
  %call2897 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v2894, i64 %v2895, i64 %v2896) nomerge, !dbg !138
  store i32 %call2897, ptr %slot469, align 8
  %v2898 = load i32, ptr %slot469, align 8
  %cv2899 = zext i32 %v2898 to i64
  %cond2900 = icmp ne i64 %cv2899, 0
  br i1 %cond2900, label %bb_rcsuccess686, label %bb_rcfailure686
bb_rcfailure686:
  %v2901 = load i64, ptr %slot49, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  %call2903 = call i32 @myl_rc_take_failure(ptr %p2902) nomerge, !dbg !138
  store i32 %call2903, ptr %slot470, align 8
  %v2904 = load i64, ptr %slot1, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %v2906 = load i32, ptr %slot470, align 8
  %call2907 = call i32 @myl_qbe_rc_status(ptr %p2905, i32 %v2906) nomerge, !dbg !138
  store i32 %call2907, ptr %slot471, align 8
  br label %bb_failure
bb_rcsuccess686:
  %v2908 = load i64, ptr %slot24, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  store i32 2, ptr %p2909, align 4, !alias.scope !3, !noalias !4
  %v2910 = load i64, ptr %slot24, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  store i32 16, ptr %p2911, align 4, !alias.scope !3, !noalias !4
  %v2912 = load i64, ptr %slot23, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i32 1, ptr %p2913, align 4, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot20, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %ld2916 = load i32, ptr %p2915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2916, ptr %slot472, align 8
  %v2917 = load i32, ptr %slot472, align 8
  %cv2918 = zext i32 %v2917 to i64
  %cond2919 = icmp ne i64 %cv2918, 0
  br i1 %cond2919, label %bb_rcslotdrop694, label %bb_rcslotdone694
bb_rcslotdrop694:
  %v2920 = load i64, ptr %slot20, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  store i32 0, ptr %p2921, align 4, !alias.scope !3, !noalias !4
  %v2922 = load i64, ptr %slot26, align 8
  store i64 %v2922, ptr %slot473, align 8
  %v2923 = load i64, ptr %slot21, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %ld2925 = load i32, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2925, ptr %slot474, align 8
  %v2926 = load i32, ptr %slot474, align 8
  %op2927 = and i32 %v2926, 28
  store i32 %op2927, ptr %slot475, align 8
  %v2928 = load i32, ptr %slot475, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcslotrole694, label %bb_rcslotowner694
bb_rcslotrole694:
  %v2931 = load i64, ptr %slot49, align 8
  store i64 %v2931, ptr %slot476, align 8
  %v2932 = load i64, ptr %slot476, align 8
  %v2933 = load i64, ptr %slot473, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2932, i64 %v2933) nomerge, !dbg !138
  br label %bb_rcslotdone694
bb_rcslotowner694:
  %v2934 = load i64, ptr %slot49, align 8
  store i64 %v2934, ptr %slot477, align 8
  %v2935 = load i64, ptr %slot477, align 8
  %v2936 = load i64, ptr %slot473, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2935, i64 %v2936) nomerge, !dbg !138
  br label %bb_rcslotdone694
bb_rcslotdone694:
  br label %bb_rcprivateprepared674
bb_rcprivateprepared674:
  %v2937 = load i64, ptr %slot12, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %ld2939 = load i32, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2939, ptr %slot478, align 8
  %v2940 = load i32, ptr %slot478, align 8
  %cv2941 = zext i32 %v2940 to i64
  %cond2942 = icmp ne i64 %cv2941, 0
  br i1 %cond2942, label %bb_rcslotdrop704, label %bb_rcslotdone704
bb_rcslotdrop704:
  %v2943 = load i64, ptr %slot12, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  store i32 0, ptr %p2944, align 4, !alias.scope !3, !noalias !4
  %v2945 = load i64, ptr %slot33, align 8
  store i64 %v2945, ptr %slot479, align 8
  %v2946 = load i64, ptr %slot13, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %ld2948 = load i32, ptr %p2947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2948, ptr %slot480, align 8
  %v2949 = load i32, ptr %slot480, align 8
  %op2950 = and i32 %v2949, 28
  store i32 %op2950, ptr %slot481, align 8
  %v2951 = load i32, ptr %slot481, align 8
  %cv2952 = zext i32 %v2951 to i64
  %cond2953 = icmp ne i64 %cv2952, 0
  br i1 %cond2953, label %bb_rcslotrole704, label %bb_rcslotowner704
bb_rcslotrole704:
  %v2954 = load i64, ptr %slot49, align 8
  store i64 %v2954, ptr %slot482, align 8
  %v2955 = load i64, ptr %slot482, align 8
  %v2956 = load i64, ptr %slot479, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2955, i64 %v2956) nomerge, !dbg !138
  br label %bb_rcslotdone704
bb_rcslotowner704:
  %v2957 = load i64, ptr %slot49, align 8
  store i64 %v2957, ptr %slot483, align 8
  %v2958 = load i64, ptr %slot483, align 8
  %v2959 = load i64, ptr %slot479, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2958, i64 %v2959) nomerge, !dbg !138
  br label %bb_rcslotdone704
bb_rcslotdone704:
  %v2960 = load i64, ptr %slot33, align 8
  store i64 %v2960, ptr %slot484, align 8
  %v2961 = load i64, ptr %slot27, align 8
  store i64 %v2961, ptr %slot485, align 8
  %v2962 = load i64, ptr %slot485, align 8
  %v2963 = load i64, ptr %slot484, align 8
  %p2964 = inttoptr i64 %v2962 to ptr
  %p2965 = inttoptr i64 %v2963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2965, ptr %p2964, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v2966 = load i64, ptr %slot23, align 8
  %p2967 = inttoptr i64 %v2966 to ptr
  store i32 0, ptr %p2967, align 4, !alias.scope !3, !noalias !4
  %v2968 = load i64, ptr %slot13, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 2, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot24, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  %ld2972 = load i32, ptr %p2971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2972, ptr %slot486, align 8
  %v2973 = load i32, ptr %slot486, align 8
  %v2974 = load i64, ptr %slot13, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  store i32 %v2973, ptr %p2975, align 4, !alias.scope !3, !noalias !4
  %v2976 = load i64, ptr %slot12, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i32 1, ptr %p2977, align 4, !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot33, align 8
  %v2979 = load i64, ptr %slot37, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i64 %v2978, ptr %p2980, align 8, !alias.scope !3, !noalias !4
  %v2981 = load i64, ptr %slot34, align 8
  %v2982 = load i64, ptr %slot38, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i64 %v2981, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot37, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  %ld2986 = load i64, ptr %p2985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2986, ptr %slot487, align 8
  %v2987 = load i64, ptr %slot20, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  %ld2989 = load i32, ptr %p2988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2989, ptr %slot488, align 8
  %v2990 = load i64, ptr %slot21, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  %ld2992 = load i32, ptr %p2991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2992, ptr %slot489, align 8
  %v2993 = load i32, ptr %slot489, align 8
  %op2994 = and i32 %v2993, 24
  store i32 %op2994, ptr %slot489, align 8
  %v2995 = load i32, ptr %slot489, align 8
  %cmp2996 = icmp eq i32 %v2995, 0
  %cv2997 = zext i1 %cmp2996 to i32
  store i32 %cv2997, ptr %slot490, align 8
  %v2998 = load i32, ptr %slot488, align 8
  %v2999 = load i32, ptr %slot490, align 8
  %op3000 = and i32 %v2998, %v2999
  store i32 %op3000, ptr %slot491, align 8
  %v3001 = load i32, ptr %slot491, align 8
  %cv3002 = zext i32 %v3001 to i64
  %cond3003 = icmp ne i64 %cv3002, 0
  br i1 %cond3003, label %bb_rctake719, label %bb_rccopy719
bb_rctake719:
  %v3004 = load i64, ptr %slot27, align 8
  store i64 %v3004, ptr %slot492, align 8
  %v3005 = load i64, ptr %slot50, align 8
  store i64 %v3005, ptr %slot493, align 8
  %v3006 = load i64, ptr %slot49, align 8
  %v3007 = load i64, ptr %slot492, align 8
  %v3008 = load i64, ptr %slot487, align 8
  %v3009 = load i64, ptr %slot493, align 8
  %cv3010 = trunc i64 %v3009 to i32
  %call3011 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v3006, i64 %v3007, i64 %v3008, i32 %cv3010) nomerge, !dbg !140
  store i32 %call3011, ptr %slot494, align 8
  %v3012 = load i32, ptr %slot494, align 8
  %cv3013 = zext i32 %v3012 to i64
  %cond3014 = icmp ne i64 %cv3013, 0
  br i1 %cond3014, label %bb_rcsuccess729, label %bb_rcfailure729
bb_rcfailure729:
  %v3015 = load i64, ptr %slot49, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  %call3017 = call i32 @myl_rc_take_failure(ptr %p3016) nomerge, !dbg !140
  store i32 %call3017, ptr %slot495, align 8
  %v3018 = load i64, ptr %slot1, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  %v3020 = load i32, ptr %slot495, align 8
  %call3021 = call i32 @myl_qbe_rc_status(ptr %p3019, i32 %v3020) nomerge, !dbg !140
  store i32 %call3021, ptr %slot496, align 8
  br label %bb_failure
bb_rcsuccess729:
  %v3022 = load i64, ptr %slot20, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  store i32 0, ptr %p3023, align 4, !alias.scope !3, !noalias !4
  %v3024 = load i64, ptr %slot24, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  store i32 2, ptr %p3025, align 4, !alias.scope !3, !noalias !4
  %v3026 = load i64, ptr %slot23, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  store i32 1, ptr %p3027, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared719
bb_rccopy719:
  %v3028 = load i64, ptr %slot27, align 8
  store i64 %v3028, ptr %slot497, align 8
  %v3029 = load i64, ptr %slot50, align 8
  store i64 %v3029, ptr %slot498, align 8
  %v3030 = load i64, ptr %slot49, align 8
  %v3031 = load i64, ptr %slot497, align 8
  %v3032 = load i64, ptr %slot487, align 8
  %v3033 = load i64, ptr %slot498, align 8
  %cv3034 = trunc i64 %v3033 to i32
  %call3035 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v3030, i64 %v3031, i64 %v3032, i32 %cv3034) nomerge, !dbg !140
  store i32 %call3035, ptr %slot499, align 8
  %v3036 = load i32, ptr %slot499, align 8
  %cv3037 = zext i32 %v3036 to i64
  %cond3038 = icmp ne i64 %cv3037, 0
  br i1 %cond3038, label %bb_rcsuccess738, label %bb_rcfailure738
bb_rcfailure738:
  %v3039 = load i64, ptr %slot49, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  %call3041 = call i32 @myl_rc_take_failure(ptr %p3040) nomerge, !dbg !140
  store i32 %call3041, ptr %slot500, align 8
  %v3042 = load i64, ptr %slot1, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  %v3044 = load i32, ptr %slot500, align 8
  %call3045 = call i32 @myl_qbe_rc_status(ptr %p3043, i32 %v3044) nomerge, !dbg !140
  store i32 %call3045, ptr %slot501, align 8
  br label %bb_failure
bb_rcsuccess738:
  %v3046 = load i64, ptr %slot24, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i32 2, ptr %p3047, align 4, !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot23, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  store i32 1, ptr %p3049, align 4, !alias.scope !3, !noalias !4
  %v3050 = load i64, ptr %slot20, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i32, ptr %p3051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3052, ptr %slot502, align 8
  %v3053 = load i32, ptr %slot502, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcslotdrop745, label %bb_rcslotdone745
bb_rcslotdrop745:
  %v3056 = load i64, ptr %slot20, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 0, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot26, align 8
  store i64 %v3058, ptr %slot503, align 8
  %v3059 = load i64, ptr %slot21, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %ld3061 = load i32, ptr %p3060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3061, ptr %slot504, align 8
  %v3062 = load i32, ptr %slot504, align 8
  %op3063 = and i32 %v3062, 28
  store i32 %op3063, ptr %slot505, align 8
  %v3064 = load i32, ptr %slot505, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcslotrole745, label %bb_rcslotowner745
bb_rcslotrole745:
  %v3067 = load i64, ptr %slot49, align 8
  store i64 %v3067, ptr %slot506, align 8
  %v3068 = load i64, ptr %slot506, align 8
  %v3069 = load i64, ptr %slot503, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3068, i64 %v3069) nomerge, !dbg !140
  br label %bb_rcslotdone745
bb_rcslotowner745:
  %v3070 = load i64, ptr %slot49, align 8
  store i64 %v3070, ptr %slot507, align 8
  %v3071 = load i64, ptr %slot507, align 8
  %v3072 = load i64, ptr %slot503, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3071, i64 %v3072) nomerge, !dbg !140
  br label %bb_rcslotdone745
bb_rcslotdone745:
  br label %bb_rcprepared719
bb_rcprepared719:
  %v3073 = load i64, ptr %slot27, align 8
  store i64 %v3073, ptr %slot508, align 8
  %v3074 = load i64, ptr %slot40, align 8
  store i64 %v3074, ptr %slot509, align 8
  %v3075 = load i64, ptr %slot508, align 8
  %v3076 = load i64, ptr %slot509, align 8
  %p3077 = inttoptr i64 %v3075 to ptr
  %p3078 = inttoptr i64 %v3076 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3078, ptr %p3077, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3079 = load i64, ptr %slot23, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i32 0, ptr %p3080, align 4, !alias.scope !3, !noalias !4
  %v3081 = load i64, ptr %slot25, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  store i32 1, ptr %p3082, align 4, !alias.scope !3, !noalias !4
  %v3083 = load i64, ptr %slot50, align 8
  store i64 %v3083, ptr %slot510, align 8
  %v3084 = load i64, ptr %slot38, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  %ld3086 = load i64, ptr %p3085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3086, ptr %slot511, align 8
  %v3087 = load i64, ptr %slot509, align 8
  %p3089 = inttoptr i64 %v3087 to ptr
  %gep3090 = getelementptr i8, ptr %p3089, i64 256
  %op3088 = ptrtoint ptr %gep3090 to i64
  store i64 %op3088, ptr %slot512, align 8
  %v3091 = load i64, ptr %slot27, align 8
  store i64 %v3091, ptr %slot513, align 8
  %v3092 = load i64, ptr %slot38, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  %ld3094 = load i64, ptr %p3093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3094, ptr %slot514, align 8
  store i32 0, ptr %slot515, align 8
  %v3095 = load i64, ptr %slot22, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  %ld3097 = load i32, ptr %p3096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3097, ptr %slot516, align 8
  %v3098 = load i32, ptr %slot516, align 8
  %op3099 = and i32 %v3098, 24
  store i32 %op3099, ptr %slot516, align 8
  %v3100 = load i32, ptr %slot516, align 8
  %cmp3101 = icmp eq i32 %v3100, 0
  %cv3102 = zext i1 %cmp3101 to i32
  store i32 %cv3102, ptr %slot517, align 8
  %v3103 = load i32, ptr %slot515, align 8
  %v3104 = load i32, ptr %slot517, align 8
  %op3105 = and i32 %v3103, %v3104
  store i32 %op3105, ptr %slot518, align 8
  %v3106 = load i32, ptr %slot518, align 8
  %cv3107 = zext i32 %v3106 to i64
  %cond3108 = icmp ne i64 %cv3107, 0
  br i1 %cond3108, label %bb_rctake762, label %bb_rccopy762
bb_rctake762:
  %v3109 = load i64, ptr %slot27, align 8
  store i64 %v3109, ptr %slot519, align 8
  %v3110 = load i64, ptr %slot50, align 8
  store i64 %v3110, ptr %slot520, align 8
  %v3111 = load i64, ptr %slot514, align 8
  %v3112 = load i64, ptr %slot519, align 8
  %op3113 = sub i64 %v3111, %v3112
  store i64 %op3113, ptr %slot521, align 8
  %v3114 = load i64, ptr %slot519, align 8
  %v3115 = load i64, ptr %slot514, align 8
  %op3116 = sub i64 %v3114, %v3115
  store i64 %op3116, ptr %slot522, align 8
  %v3117 = load i64, ptr %slot521, align 8
  %cmp3118 = icmp ult i64 %v3117, 32
  %cv3119 = zext i1 %cmp3118 to i32
  store i32 %cv3119, ptr %slot523, align 8
  %v3120 = load i64, ptr %slot522, align 8
  %cmp3121 = icmp ult i64 %v3120, 32
  %cv3122 = zext i1 %cmp3121 to i32
  store i32 %cv3122, ptr %slot524, align 8
  %v3123 = load i32, ptr %slot523, align 8
  %v3124 = load i32, ptr %slot524, align 8
  %op3125 = or i32 %v3123, %v3124
  store i32 %op3125, ptr %slot525, align 8
  %v3126 = load i32, ptr %slot525, align 8
  %cv3127 = zext i32 %v3126 to i64
  %cond3128 = icmp ne i64 %cv3127, 0
  br i1 %cond3128, label %bb_rcmoveslow771, label %bb_rcmovecheck771
bb_rcmovecheck771:
  %v3129 = load i64, ptr %slot514, align 8
  %op3130 = add i64 %v3129, 0
  store i64 %op3130, ptr %slot526, align 8
  %v3131 = load i64, ptr %slot526, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  %ld3133 = load i64, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3133, ptr %slot527, align 8
  %v3134 = load i64, ptr %slot527, align 8
  %cmp3135 = icmp ne i64 %v3134, 0
  %cv3136 = zext i1 %cmp3135 to i32
  store i32 %cv3136, ptr %slot528, align 8
  %v3137 = load i32, ptr %slot528, align 8
  %cv3138 = zext i32 %v3137 to i64
  %cond3139 = icmp ne i64 %cv3138, 0
  br i1 %cond3139, label %bb_rcmoveheader779, label %bb_rcmovenext779
bb_rcmoveheader779:
  %v3140 = load i64, ptr %slot527, align 8
  %op3141 = sub i64 %v3140, 16
  store i64 %op3141, ptr %slot529, align 8
  %v3142 = load i64, ptr %slot527, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %rgep3144 = getelementptr i8, ptr %p3143, i64 -16
  %ld3145 = load i64, ptr %rgep3144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3145, ptr %slot530, align 8
  %v3146 = load i64, ptr %slot530, align 8
  %op3147 = and i64 %v3146, 5764607523034234881
  store i64 %op3147, ptr %slot531, align 8
  %v3148 = load i64, ptr %slot531, align 8
  %cmp3149 = icmp ne i64 %v3148, 0
  %cv3150 = zext i1 %cmp3149 to i32
  store i32 %cv3150, ptr %slot532, align 8
  %v3151 = load i32, ptr %slot532, align 8
  %cv3152 = zext i32 %v3151 to i64
  %cond3153 = icmp ne i64 %cv3152, 0
  br i1 %cond3153, label %bb_rcmoveslow771, label %bb_rcmovenext779
bb_rcmovenext779:
  %v3154 = load i64, ptr %slot514, align 8
  %v3155 = load i64, ptr %slot519, align 8
  %p3156 = inttoptr i64 %v3154 to ptr
  %p3157 = inttoptr i64 %v3155 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3157, ptr %p3156, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3158 = load i64, ptr %slot514, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  store i64 0, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  %v3160 = load i64, ptr %slot514, align 8
  %op3161 = add i64 %v3160, 8
  store i64 %op3161, ptr %slot533, align 8
  %v3162 = load i64, ptr %slot533, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  store i64 0, ptr %p3163, align 8, !alias.scope !3, !noalias !4
  %v3164 = load i64, ptr %slot514, align 8
  %op3165 = add i64 %v3164, 16
  store i64 %op3165, ptr %slot534, align 8
  %v3166 = load i64, ptr %slot534, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  store i64 0, ptr %p3167, align 8, !alias.scope !3, !noalias !4
  %v3168 = load i64, ptr %slot514, align 8
  %op3169 = add i64 %v3168, 24
  store i64 %op3169, ptr %slot535, align 8
  %v3170 = load i64, ptr %slot535, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  store i64 0, ptr %p3171, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved771
bb_rcmoveslow771:
  %v3172 = load i64, ptr %slot49, align 8
  %v3173 = load i64, ptr %slot519, align 8
  %v3174 = load i64, ptr %slot514, align 8
  %v3175 = load i64, ptr %slot520, align 8
  %cv3176 = trunc i64 %v3175 to i32
  %call3177 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v3172, i64 %v3173, i64 %v3174, i32 %cv3176) nomerge, !dbg !140
  store i32 %call3177, ptr %slot536, align 8
  %v3178 = load i32, ptr %slot536, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcsuccess789, label %bb_rcfailure789
bb_rcfailure789:
  %v3181 = load i64, ptr %slot49, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  %call3183 = call i32 @myl_rc_take_failure(ptr %p3182) nomerge, !dbg !140
  store i32 %call3183, ptr %slot537, align 8
  %v3184 = load i64, ptr %slot1, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  %v3186 = load i32, ptr %slot537, align 8
  %call3187 = call i32 @myl_qbe_rc_status(ptr %p3185, i32 %v3186) nomerge, !dbg !140
  store i32 %call3187, ptr %slot538, align 8
  br label %bb_failure
bb_rcsuccess789:
  br label %bb_rcmoved771
bb_rcmoved771:
  %v3188 = load i64, ptr %slot24, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  store i32 2, ptr %p3189, align 4, !alias.scope !3, !noalias !4
  %v3190 = load i64, ptr %slot23, align 8
  %p3191 = inttoptr i64 %v3190 to ptr
  store i32 1, ptr %p3191, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared762
bb_rccopy762:
  %v3192 = load i64, ptr %slot27, align 8
  store i64 %v3192, ptr %slot539, align 8
  %v3193 = load i64, ptr %slot50, align 8
  store i64 %v3193, ptr %slot540, align 8
  %v3194 = load i64, ptr %slot49, align 8
  %v3195 = load i64, ptr %slot539, align 8
  %v3196 = load i64, ptr %slot514, align 8
  %v3197 = load i64, ptr %slot540, align 8
  %cv3198 = trunc i64 %v3197 to i32
  %call3199 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v3194, i64 %v3195, i64 %v3196, i32 %cv3198) nomerge, !dbg !140
  store i32 %call3199, ptr %slot541, align 8
  %v3200 = load i32, ptr %slot541, align 8
  %cv3201 = zext i32 %v3200 to i64
  %cond3202 = icmp ne i64 %cv3201, 0
  br i1 %cond3202, label %bb_rcsuccess798, label %bb_rcfailure798
bb_rcfailure798:
  %v3203 = load i64, ptr %slot49, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  %call3205 = call i32 @myl_rc_take_failure(ptr %p3204) nomerge, !dbg !140
  store i32 %call3205, ptr %slot542, align 8
  %v3206 = load i64, ptr %slot1, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  %v3208 = load i32, ptr %slot542, align 8
  %call3209 = call i32 @myl_qbe_rc_status(ptr %p3207, i32 %v3208) nomerge, !dbg !140
  store i32 %call3209, ptr %slot543, align 8
  br label %bb_failure
bb_rcsuccess798:
  %v3210 = load i64, ptr %slot24, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i32 2, ptr %p3211, align 4, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot23, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 1, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared762
bb_rcprepared762:
  %v3214 = load i64, ptr %slot27, align 8
  store i64 %v3214, ptr %slot544, align 8
  %v3215 = load i64, ptr %slot544, align 8
  %v3216 = load i64, ptr %slot513, align 8
  %p3217 = inttoptr i64 %v3215 to ptr
  %p3218 = inttoptr i64 %v3216 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3218, ptr %p3217, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot23, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  store i32 0, ptr %p3220, align 4, !alias.scope !3, !noalias !4
  %v3221 = load i64, ptr %slot24, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i32 2, ptr %p3222, align 4, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot23, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  store i32 1, ptr %p3224, align 4, !alias.scope !3, !noalias !4
  %v3225 = load i64, ptr %slot49, align 8
  store i64 %v3225, ptr %slot545, align 8
  %v3226 = load i64, ptr %slot545, align 8
  %v3227 = load i64, ptr %slot512, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v3226, i64 %v3227) nomerge, !dbg !140
  %v3228 = load i64, ptr %slot513, align 8
  %v3229 = load i64, ptr %slot512, align 8
  %p3230 = inttoptr i64 %v3228 to ptr
  %p3231 = inttoptr i64 %v3229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3231, ptr %p3230, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3232 = load i64, ptr %slot23, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i32 0, ptr %p3233, align 4, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot509, align 8
  %v3235 = load i64, ptr %slot37, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  store i64 %v3234, ptr %p3236, align 8, !alias.scope !3, !noalias !4
  %v3237 = load i64, ptr %slot37, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  %ld3239 = load i64, ptr %p3238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3239, ptr %slot546, align 8
  %v3240 = load i64, ptr %slot27, align 8
  store i64 %v3240, ptr %slot547, align 8
  %v3241 = load i64, ptr %slot546, align 8
  %v3242 = load i64, ptr %slot547, align 8
  %p3243 = inttoptr i64 %v3241 to ptr
  %p3244 = inttoptr i64 %v3242 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3244, ptr %p3243, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot24, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i32 2, ptr %p3246, align 4, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot23, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  store i32 1, ptr %p3248, align 4, !alias.scope !3, !noalias !4
  %v3249 = load i64, ptr %slot20, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  %ld3251 = load i32, ptr %p3250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3251, ptr %slot548, align 8
  %v3252 = load i32, ptr %slot548, align 8
  %cv3253 = zext i32 %v3252 to i64
  %cond3254 = icmp ne i64 %cv3253, 0
  br i1 %cond3254, label %bb_rcslotdrop824, label %bb_rcslotdone824
bb_rcslotdrop824:
  %v3255 = load i64, ptr %slot20, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  store i32 0, ptr %p3256, align 4, !alias.scope !3, !noalias !4
  %v3257 = load i64, ptr %slot26, align 8
  store i64 %v3257, ptr %slot549, align 8
  %v3258 = load i64, ptr %slot21, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  %ld3260 = load i32, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3260, ptr %slot550, align 8
  %v3261 = load i32, ptr %slot550, align 8
  %op3262 = and i32 %v3261, 28
  store i32 %op3262, ptr %slot551, align 8
  %v3263 = load i32, ptr %slot551, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcslotrole824, label %bb_rcslotowner824
bb_rcslotrole824:
  %v3266 = load i64, ptr %slot49, align 8
  store i64 %v3266, ptr %slot552, align 8
  %v3267 = load i64, ptr %slot552, align 8
  %v3268 = load i64, ptr %slot549, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3267, i64 %v3268) nomerge, !dbg !140
  br label %bb_rcslotdone824
bb_rcslotowner824:
  %v3269 = load i64, ptr %slot49, align 8
  store i64 %v3269, ptr %slot553, align 8
  %v3270 = load i64, ptr %slot553, align 8
  %v3271 = load i64, ptr %slot549, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3270, i64 %v3271) nomerge, !dbg !140
  br label %bb_rcslotdone824
bb_rcslotdone824:
  %v3272 = load i64, ptr %slot26, align 8
  store i64 %v3272, ptr %slot554, align 8
  %v3273 = load i64, ptr %slot27, align 8
  store i64 %v3273, ptr %slot555, align 8
  %v3274 = load i64, ptr %slot555, align 8
  %v3275 = load i64, ptr %slot554, align 8
  %p3276 = inttoptr i64 %v3274 to ptr
  %p3277 = inttoptr i64 %v3275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3277, ptr %p3276, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot21, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i32 2, ptr %p3279, align 4, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot24, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %ld3282 = load i32, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3282, ptr %slot556, align 8
  %v3283 = load i32, ptr %slot556, align 8
  %v3284 = load i64, ptr %slot21, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  store i32 %v3283, ptr %p3285, align 4, !alias.scope !3, !noalias !4
  %v3286 = load i64, ptr %slot23, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  store i32 0, ptr %p3287, align 4, !alias.scope !3, !noalias !4
  %v3288 = load i64, ptr %slot20, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i32 1, ptr %p3289, align 4, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot554, align 8
  %v3291 = load i64, ptr %slot37, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i64 %v3290, ptr %p3292, align 8, !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot37, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %ld3295 = load i64, ptr %p3294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3295, ptr %slot557, align 8
  %v3296 = load i64, ptr %slot20, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %ld3298 = load i32, ptr %p3297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3298, ptr %slot558, align 8
  %v3299 = load i64, ptr %slot21, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i32, ptr %p3300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3301, ptr %slot559, align 8
  %v3302 = load i32, ptr %slot559, align 8
  %op3303 = and i32 %v3302, 24
  store i32 %op3303, ptr %slot559, align 8
  %v3304 = load i32, ptr %slot559, align 8
  %cmp3305 = icmp eq i32 %v3304, 0
  %cv3306 = zext i1 %cmp3305 to i32
  store i32 %cv3306, ptr %slot560, align 8
  %v3307 = load i32, ptr %slot558, align 8
  %v3308 = load i32, ptr %slot560, align 8
  %op3309 = and i32 %v3307, %v3308
  store i32 %op3309, ptr %slot561, align 8
  %v3310 = load i32, ptr %slot561, align 8
  %cv3311 = zext i32 %v3310 to i64
  %cond3312 = icmp ne i64 %cv3311, 0
  br i1 %cond3312, label %bb_rctake849, label %bb_rccopy849
bb_rctake849:
  %v3313 = load i64, ptr %slot27, align 8
  store i64 %v3313, ptr %slot562, align 8
  %v3314 = load i64, ptr %slot50, align 8
  store i64 %v3314, ptr %slot563, align 8
  %v3315 = load i64, ptr %slot49, align 8
  %v3316 = load i64, ptr %slot562, align 8
  %v3317 = load i64, ptr %slot557, align 8
  %v3318 = load i64, ptr %slot563, align 8
  %cv3319 = trunc i64 %v3318 to i32
  %call3320 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v3315, i64 %v3316, i64 %v3317, i32 %cv3319) nomerge, !dbg !142
  store i32 %call3320, ptr %slot564, align 8
  %v3321 = load i32, ptr %slot564, align 8
  %cv3322 = zext i32 %v3321 to i64
  %cond3323 = icmp ne i64 %cv3322, 0
  br i1 %cond3323, label %bb_rcsuccess859, label %bb_rcfailure859
bb_rcfailure859:
  %v3324 = load i64, ptr %slot49, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %call3326 = call i32 @myl_rc_take_failure(ptr %p3325) nomerge, !dbg !142
  store i32 %call3326, ptr %slot565, align 8
  %v3327 = load i64, ptr %slot1, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  %v3329 = load i32, ptr %slot565, align 8
  %call3330 = call i32 @myl_qbe_rc_status(ptr %p3328, i32 %v3329) nomerge, !dbg !142
  store i32 %call3330, ptr %slot566, align 8
  br label %bb_failure
bb_rcsuccess859:
  %v3331 = load i64, ptr %slot20, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i32 0, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot24, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  store i32 2, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  %v3335 = load i64, ptr %slot23, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  store i32 1, ptr %p3336, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared849
bb_rccopy849:
  %v3337 = load i64, ptr %slot27, align 8
  store i64 %v3337, ptr %slot567, align 8
  %v3338 = load i64, ptr %slot50, align 8
  store i64 %v3338, ptr %slot568, align 8
  %v3339 = load i64, ptr %slot49, align 8
  %v3340 = load i64, ptr %slot567, align 8
  %v3341 = load i64, ptr %slot557, align 8
  %v3342 = load i64, ptr %slot568, align 8
  %cv3343 = trunc i64 %v3342 to i32
  %call3344 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v3339, i64 %v3340, i64 %v3341, i32 %cv3343) nomerge, !dbg !142
  store i32 %call3344, ptr %slot569, align 8
  %v3345 = load i32, ptr %slot569, align 8
  %cv3346 = zext i32 %v3345 to i64
  %cond3347 = icmp ne i64 %cv3346, 0
  br i1 %cond3347, label %bb_rcsuccess868, label %bb_rcfailure868
bb_rcfailure868:
  %v3348 = load i64, ptr %slot49, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  %call3350 = call i32 @myl_rc_take_failure(ptr %p3349) nomerge, !dbg !142
  store i32 %call3350, ptr %slot570, align 8
  %v3351 = load i64, ptr %slot1, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %v3353 = load i32, ptr %slot570, align 8
  %call3354 = call i32 @myl_qbe_rc_status(ptr %p3352, i32 %v3353) nomerge, !dbg !142
  store i32 %call3354, ptr %slot571, align 8
  br label %bb_failure
bb_rcsuccess868:
  %v3355 = load i64, ptr %slot24, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  store i32 2, ptr %p3356, align 4, !alias.scope !3, !noalias !4
  %v3357 = load i64, ptr %slot23, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  store i32 1, ptr %p3358, align 4, !alias.scope !3, !noalias !4
  %v3359 = load i64, ptr %slot20, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  %ld3361 = load i32, ptr %p3360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3361, ptr %slot572, align 8
  %v3362 = load i32, ptr %slot572, align 8
  %cv3363 = zext i32 %v3362 to i64
  %cond3364 = icmp ne i64 %cv3363, 0
  br i1 %cond3364, label %bb_rcslotdrop875, label %bb_rcslotdone875
bb_rcslotdrop875:
  %v3365 = load i64, ptr %slot20, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  store i32 0, ptr %p3366, align 4, !alias.scope !3, !noalias !4
  %v3367 = load i64, ptr %slot26, align 8
  store i64 %v3367, ptr %slot573, align 8
  %v3368 = load i64, ptr %slot21, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  %ld3370 = load i32, ptr %p3369, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3370, ptr %slot574, align 8
  %v3371 = load i32, ptr %slot574, align 8
  %op3372 = and i32 %v3371, 28
  store i32 %op3372, ptr %slot575, align 8
  %v3373 = load i32, ptr %slot575, align 8
  %cv3374 = zext i32 %v3373 to i64
  %cond3375 = icmp ne i64 %cv3374, 0
  br i1 %cond3375, label %bb_rcslotrole875, label %bb_rcslotowner875
bb_rcslotrole875:
  %v3376 = load i64, ptr %slot49, align 8
  store i64 %v3376, ptr %slot576, align 8
  %v3377 = load i64, ptr %slot576, align 8
  %v3378 = load i64, ptr %slot573, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3377, i64 %v3378) nomerge, !dbg !142
  br label %bb_rcslotdone875
bb_rcslotowner875:
  %v3379 = load i64, ptr %slot49, align 8
  store i64 %v3379, ptr %slot577, align 8
  %v3380 = load i64, ptr %slot577, align 8
  %v3381 = load i64, ptr %slot573, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3380, i64 %v3381) nomerge, !dbg !142
  br label %bb_rcslotdone875
bb_rcslotdone875:
  br label %bb_rcprepared849
bb_rcprepared849:
  %v3382 = load i64, ptr %slot28, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  %ld3384 = load i64, ptr %p3383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3384, ptr %slot578, align 8
  %v3385 = load i64, ptr %slot49, align 8
  store i64 %v3385, ptr %slot579, align 8
  %v3386 = load i64, ptr %slot579, align 8
  %v3387 = load i64, ptr %slot578, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3386, i64 %v3387) nomerge, !dbg !142
  %v3388 = load i64, ptr %slot27, align 8
  store i64 %v3388, ptr %slot580, align 8
  %v3389 = load i64, ptr %slot580, align 8
  %v3390 = load i64, ptr %slot578, align 8
  %p3391 = inttoptr i64 %v3389 to ptr
  %p3392 = inttoptr i64 %v3390 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3392, ptr %p3391, i64 392, i1 false), !alias.scope !10000000
  %v3393 = load i64, ptr %slot23, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 0, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot37, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  store i64 0, ptr %p3396, align 8, !alias.scope !3, !noalias !4
  %v3397 = load i64, ptr %slot32, align 8
  %v3398 = load i64, ptr %slot37, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  store i64 %v3397, ptr %p3399, align 8, !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot37, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  %ld3402 = load i64, ptr %p3401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3402, ptr %slot581, align 8
  %v3403 = load i64, ptr %slot20, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %ld3405 = load i32, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3405, ptr %slot582, align 8
  %v3406 = load i64, ptr %slot21, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  %ld3408 = load i32, ptr %p3407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3408, ptr %slot583, align 8
  %v3409 = load i32, ptr %slot583, align 8
  %op3410 = and i32 %v3409, 24
  store i32 %op3410, ptr %slot583, align 8
  %v3411 = load i32, ptr %slot583, align 8
  %cmp3412 = icmp eq i32 %v3411, 0
  %cv3413 = zext i1 %cmp3412 to i32
  store i32 %cv3413, ptr %slot584, align 8
  %v3414 = load i32, ptr %slot582, align 8
  %v3415 = load i32, ptr %slot584, align 8
  %op3416 = and i32 %v3414, %v3415
  store i32 %op3416, ptr %slot585, align 8
  %v3417 = load i32, ptr %slot585, align 8
  %cv3418 = zext i32 %v3417 to i64
  %cond3419 = icmp ne i64 %cv3418, 0
  br i1 %cond3419, label %bb_rcprivateown893, label %bb_rcprivateloan893
bb_rcprivateown893:
  %v3420 = load i64, ptr %slot27, align 8
  store i64 %v3420, ptr %slot586, align 8
  %v3421 = load i64, ptr %slot50, align 8
  store i64 %v3421, ptr %slot587, align 8
  %v3422 = load i64, ptr %slot49, align 8
  %v3423 = load i64, ptr %slot586, align 8
  %v3424 = load i64, ptr %slot581, align 8
  %v3425 = load i64, ptr %slot587, align 8
  %cv3426 = trunc i64 %v3425 to i32
  %call3427 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v3422, i64 %v3423, i64 %v3424, i32 %cv3426) nomerge, !dbg !144
  store i32 %call3427, ptr %slot588, align 8
  %v3428 = load i32, ptr %slot588, align 8
  %cv3429 = zext i32 %v3428 to i64
  %cond3430 = icmp ne i64 %cv3429, 0
  br i1 %cond3430, label %bb_rcsuccess897, label %bb_rcfailure897
bb_rcfailure897:
  %v3431 = load i64, ptr %slot49, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  %call3433 = call i32 @myl_rc_take_failure(ptr %p3432) nomerge, !dbg !144
  store i32 %call3433, ptr %slot589, align 8
  %v3434 = load i64, ptr %slot1, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %v3436 = load i32, ptr %slot589, align 8
  %call3437 = call i32 @myl_qbe_rc_status(ptr %p3435, i32 %v3436) nomerge, !dbg !144
  store i32 %call3437, ptr %slot590, align 8
  br label %bb_failure
bb_rcsuccess897:
  %v3438 = load i64, ptr %slot20, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  store i32 0, ptr %p3439, align 4, !alias.scope !3, !noalias !4
  %v3440 = load i64, ptr %slot24, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  store i32 2, ptr %p3441, align 4, !alias.scope !3, !noalias !4
  %v3442 = load i64, ptr %slot23, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  store i32 1, ptr %p3443, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared893
bb_rcprivateloan893:
  %v3444 = load i64, ptr %slot27, align 8
  store i64 %v3444, ptr %slot591, align 8
  %v3445 = load i64, ptr %slot49, align 8
  %v3446 = load i64, ptr %slot591, align 8
  %v3447 = load i64, ptr %slot581, align 8
  %call3448 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v3445, i64 %v3446, i64 %v3447) nomerge, !dbg !144
  store i32 %call3448, ptr %slot592, align 8
  %v3449 = load i32, ptr %slot592, align 8
  %cv3450 = zext i32 %v3449 to i64
  %cond3451 = icmp ne i64 %cv3450, 0
  br i1 %cond3451, label %bb_rcsuccess905, label %bb_rcfailure905
bb_rcfailure905:
  %v3452 = load i64, ptr %slot49, align 8
  %p3453 = inttoptr i64 %v3452 to ptr
  %call3454 = call i32 @myl_rc_take_failure(ptr %p3453) nomerge, !dbg !144
  store i32 %call3454, ptr %slot593, align 8
  %v3455 = load i64, ptr %slot1, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %v3457 = load i32, ptr %slot593, align 8
  %call3458 = call i32 @myl_qbe_rc_status(ptr %p3456, i32 %v3457) nomerge, !dbg !144
  store i32 %call3458, ptr %slot594, align 8
  br label %bb_failure
bb_rcsuccess905:
  %v3459 = load i64, ptr %slot24, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i32 2, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot24, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  store i32 16, ptr %p3462, align 4, !alias.scope !3, !noalias !4
  %v3463 = load i64, ptr %slot23, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  store i32 1, ptr %p3464, align 4, !alias.scope !3, !noalias !4
  %v3465 = load i64, ptr %slot20, align 8
  %p3466 = inttoptr i64 %v3465 to ptr
  %ld3467 = load i32, ptr %p3466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3467, ptr %slot595, align 8
  %v3468 = load i32, ptr %slot595, align 8
  %cv3469 = zext i32 %v3468 to i64
  %cond3470 = icmp ne i64 %cv3469, 0
  br i1 %cond3470, label %bb_rcslotdrop913, label %bb_rcslotdone913
bb_rcslotdrop913:
  %v3471 = load i64, ptr %slot20, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i32 0, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot26, align 8
  store i64 %v3473, ptr %slot596, align 8
  %v3474 = load i64, ptr %slot21, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  %ld3476 = load i32, ptr %p3475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3476, ptr %slot597, align 8
  %v3477 = load i32, ptr %slot597, align 8
  %op3478 = and i32 %v3477, 28
  store i32 %op3478, ptr %slot598, align 8
  %v3479 = load i32, ptr %slot598, align 8
  %cv3480 = zext i32 %v3479 to i64
  %cond3481 = icmp ne i64 %cv3480, 0
  br i1 %cond3481, label %bb_rcslotrole913, label %bb_rcslotowner913
bb_rcslotrole913:
  %v3482 = load i64, ptr %slot49, align 8
  store i64 %v3482, ptr %slot599, align 8
  %v3483 = load i64, ptr %slot599, align 8
  %v3484 = load i64, ptr %slot596, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3483, i64 %v3484) nomerge, !dbg !144
  br label %bb_rcslotdone913
bb_rcslotowner913:
  %v3485 = load i64, ptr %slot49, align 8
  store i64 %v3485, ptr %slot600, align 8
  %v3486 = load i64, ptr %slot600, align 8
  %v3487 = load i64, ptr %slot596, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3486, i64 %v3487) nomerge, !dbg !144
  br label %bb_rcslotdone913
bb_rcslotdone913:
  br label %bb_rcprivateprepared893
bb_rcprivateprepared893:
  %v3488 = load i64, ptr %slot18, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %ld3490 = load i32, ptr %p3489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3490, ptr %slot601, align 8
  %v3491 = load i32, ptr %slot601, align 8
  %cv3492 = zext i32 %v3491 to i64
  %cond3493 = icmp ne i64 %cv3492, 0
  br i1 %cond3493, label %bb_rcslotdrop923, label %bb_rcslotdone923
bb_rcslotdrop923:
  %v3494 = load i64, ptr %slot18, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  store i32 0, ptr %p3495, align 4, !alias.scope !3, !noalias !4
  %v3496 = load i64, ptr %slot36, align 8
  store i64 %v3496, ptr %slot602, align 8
  %v3497 = load i64, ptr %slot19, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  %ld3499 = load i32, ptr %p3498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3499, ptr %slot603, align 8
  %v3500 = load i32, ptr %slot603, align 8
  %op3501 = and i32 %v3500, 28
  store i32 %op3501, ptr %slot604, align 8
  %v3502 = load i32, ptr %slot604, align 8
  %cv3503 = zext i32 %v3502 to i64
  %cond3504 = icmp ne i64 %cv3503, 0
  br i1 %cond3504, label %bb_rcslotrole923, label %bb_rcslotowner923
bb_rcslotrole923:
  %v3505 = load i64, ptr %slot49, align 8
  store i64 %v3505, ptr %slot605, align 8
  %v3506 = load i64, ptr %slot605, align 8
  %v3507 = load i64, ptr %slot602, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3506, i64 %v3507) nomerge, !dbg !144
  br label %bb_rcslotdone923
bb_rcslotowner923:
  %v3508 = load i64, ptr %slot49, align 8
  store i64 %v3508, ptr %slot606, align 8
  %v3509 = load i64, ptr %slot606, align 8
  %v3510 = load i64, ptr %slot602, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3509, i64 %v3510) nomerge, !dbg !144
  br label %bb_rcslotdone923
bb_rcslotdone923:
  %v3511 = load i64, ptr %slot36, align 8
  store i64 %v3511, ptr %slot607, align 8
  %v3512 = load i64, ptr %slot27, align 8
  store i64 %v3512, ptr %slot608, align 8
  %v3513 = load i64, ptr %slot608, align 8
  %v3514 = load i64, ptr %slot607, align 8
  %p3515 = inttoptr i64 %v3513 to ptr
  %p3516 = inttoptr i64 %v3514 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3516, ptr %p3515, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3517 = load i64, ptr %slot23, align 8
  %p3518 = inttoptr i64 %v3517 to ptr
  store i32 0, ptr %p3518, align 4, !alias.scope !3, !noalias !4
  %v3519 = load i64, ptr %slot19, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  store i32 2, ptr %p3520, align 4, !alias.scope !3, !noalias !4
  %v3521 = load i64, ptr %slot24, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %ld3523 = load i32, ptr %p3522, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3523, ptr %slot609, align 8
  %v3524 = load i32, ptr %slot609, align 8
  %v3525 = load i64, ptr %slot19, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i32 %v3524, ptr %p3526, align 4, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot18, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  store i32 1, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  %v3529 = load i64, ptr %slot28, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  %ld3531 = load i64, ptr %p3530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3531, ptr %slot610, align 8
  %v3532 = load i64, ptr %slot610, align 8
  %v3533 = load i64, ptr %slot37, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  store i64 %v3532, ptr %p3534, align 8, !alias.scope !3, !noalias !4
  %v3535 = load i64, ptr %slot37, align 8
  %p3536 = inttoptr i64 %v3535 to ptr
  %ld3537 = load i64, ptr %p3536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3537, ptr %slot611, align 8
  %v3538 = load i64, ptr %slot20, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  %ld3540 = load i32, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3540, ptr %slot612, align 8
  %v3541 = load i64, ptr %slot21, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  %ld3543 = load i32, ptr %p3542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3543, ptr %slot613, align 8
  %v3544 = load i32, ptr %slot613, align 8
  %op3545 = and i32 %v3544, 24
  store i32 %op3545, ptr %slot613, align 8
  %v3546 = load i32, ptr %slot613, align 8
  %cmp3547 = icmp eq i32 %v3546, 0
  %cv3548 = zext i1 %cmp3547 to i32
  store i32 %cv3548, ptr %slot614, align 8
  %v3549 = load i32, ptr %slot612, align 8
  %v3550 = load i32, ptr %slot614, align 8
  %op3551 = and i32 %v3549, %v3550
  store i32 %op3551, ptr %slot615, align 8
  %v3552 = load i32, ptr %slot615, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcprivateown945, label %bb_rcprivateloan945
bb_rcprivateown945:
  %v3555 = load i64, ptr %slot27, align 8
  store i64 %v3555, ptr %slot616, align 8
  %v3556 = load i64, ptr %slot50, align 8
  store i64 %v3556, ptr %slot617, align 8
  %v3557 = load i64, ptr %slot49, align 8
  %v3558 = load i64, ptr %slot616, align 8
  %v3559 = load i64, ptr %slot611, align 8
  %v3560 = load i64, ptr %slot617, align 8
  %cv3561 = trunc i64 %v3560 to i32
  %call3562 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v3557, i64 %v3558, i64 %v3559, i32 %cv3561) nomerge, !dbg !146
  store i32 %call3562, ptr %slot618, align 8
  %v3563 = load i32, ptr %slot618, align 8
  %cv3564 = zext i32 %v3563 to i64
  %cond3565 = icmp ne i64 %cv3564, 0
  br i1 %cond3565, label %bb_rcsuccess949, label %bb_rcfailure949
bb_rcfailure949:
  %v3566 = load i64, ptr %slot49, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %call3568 = call i32 @myl_rc_take_failure(ptr %p3567) nomerge, !dbg !146
  store i32 %call3568, ptr %slot619, align 8
  %v3569 = load i64, ptr %slot1, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  %v3571 = load i32, ptr %slot619, align 8
  %call3572 = call i32 @myl_qbe_rc_status(ptr %p3570, i32 %v3571) nomerge, !dbg !146
  store i32 %call3572, ptr %slot620, align 8
  br label %bb_failure
bb_rcsuccess949:
  %v3573 = load i64, ptr %slot20, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  store i32 0, ptr %p3574, align 4, !alias.scope !3, !noalias !4
  %v3575 = load i64, ptr %slot24, align 8
  %p3576 = inttoptr i64 %v3575 to ptr
  store i32 2, ptr %p3576, align 4, !alias.scope !3, !noalias !4
  %v3577 = load i64, ptr %slot23, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  store i32 1, ptr %p3578, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared945
bb_rcprivateloan945:
  %v3579 = load i64, ptr %slot27, align 8
  store i64 %v3579, ptr %slot621, align 8
  %v3580 = load i64, ptr %slot49, align 8
  %v3581 = load i64, ptr %slot621, align 8
  %v3582 = load i64, ptr %slot611, align 8
  %call3583 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v3580, i64 %v3581, i64 %v3582) nomerge, !dbg !146
  store i32 %call3583, ptr %slot622, align 8
  %v3584 = load i32, ptr %slot622, align 8
  %cv3585 = zext i32 %v3584 to i64
  %cond3586 = icmp ne i64 %cv3585, 0
  br i1 %cond3586, label %bb_rcsuccess957, label %bb_rcfailure957
bb_rcfailure957:
  %v3587 = load i64, ptr %slot49, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  %call3589 = call i32 @myl_rc_take_failure(ptr %p3588) nomerge, !dbg !146
  store i32 %call3589, ptr %slot623, align 8
  %v3590 = load i64, ptr %slot1, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  %v3592 = load i32, ptr %slot623, align 8
  %call3593 = call i32 @myl_qbe_rc_status(ptr %p3591, i32 %v3592) nomerge, !dbg !146
  store i32 %call3593, ptr %slot624, align 8
  br label %bb_failure
bb_rcsuccess957:
  %v3594 = load i64, ptr %slot24, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  store i32 2, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  %v3596 = load i64, ptr %slot24, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  store i32 16, ptr %p3597, align 4, !alias.scope !3, !noalias !4
  %v3598 = load i64, ptr %slot23, align 8
  %p3599 = inttoptr i64 %v3598 to ptr
  store i32 1, ptr %p3599, align 4, !alias.scope !3, !noalias !4
  %v3600 = load i64, ptr %slot20, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  %ld3602 = load i32, ptr %p3601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3602, ptr %slot625, align 8
  %v3603 = load i32, ptr %slot625, align 8
  %cv3604 = zext i32 %v3603 to i64
  %cond3605 = icmp ne i64 %cv3604, 0
  br i1 %cond3605, label %bb_rcslotdrop965, label %bb_rcslotdone965
bb_rcslotdrop965:
  %v3606 = load i64, ptr %slot20, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  store i32 0, ptr %p3607, align 4, !alias.scope !3, !noalias !4
  %v3608 = load i64, ptr %slot26, align 8
  store i64 %v3608, ptr %slot626, align 8
  %v3609 = load i64, ptr %slot21, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %ld3611 = load i32, ptr %p3610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3611, ptr %slot627, align 8
  %v3612 = load i32, ptr %slot627, align 8
  %op3613 = and i32 %v3612, 28
  store i32 %op3613, ptr %slot628, align 8
  %v3614 = load i32, ptr %slot628, align 8
  %cv3615 = zext i32 %v3614 to i64
  %cond3616 = icmp ne i64 %cv3615, 0
  br i1 %cond3616, label %bb_rcslotrole965, label %bb_rcslotowner965
bb_rcslotrole965:
  %v3617 = load i64, ptr %slot49, align 8
  store i64 %v3617, ptr %slot629, align 8
  %v3618 = load i64, ptr %slot629, align 8
  %v3619 = load i64, ptr %slot626, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3618, i64 %v3619) nomerge, !dbg !146
  br label %bb_rcslotdone965
bb_rcslotowner965:
  %v3620 = load i64, ptr %slot49, align 8
  store i64 %v3620, ptr %slot630, align 8
  %v3621 = load i64, ptr %slot630, align 8
  %v3622 = load i64, ptr %slot626, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3621, i64 %v3622) nomerge, !dbg !146
  br label %bb_rcslotdone965
bb_rcslotdone965:
  br label %bb_rcprivateprepared945
bb_rcprivateprepared945:
  %v3623 = load i64, ptr %slot16, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  %ld3625 = load i32, ptr %p3624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3625, ptr %slot631, align 8
  %v3626 = load i32, ptr %slot631, align 8
  %cv3627 = zext i32 %v3626 to i64
  %cond3628 = icmp ne i64 %cv3627, 0
  br i1 %cond3628, label %bb_rcslotdrop975, label %bb_rcslotdone975
bb_rcslotdrop975:
  %v3629 = load i64, ptr %slot16, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  store i32 0, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  %v3631 = load i64, ptr %slot35, align 8
  store i64 %v3631, ptr %slot632, align 8
  %v3632 = load i64, ptr %slot17, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  %ld3634 = load i32, ptr %p3633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3634, ptr %slot633, align 8
  %v3635 = load i32, ptr %slot633, align 8
  %op3636 = and i32 %v3635, 28
  store i32 %op3636, ptr %slot634, align 8
  %v3637 = load i32, ptr %slot634, align 8
  %cv3638 = zext i32 %v3637 to i64
  %cond3639 = icmp ne i64 %cv3638, 0
  br i1 %cond3639, label %bb_rcslotrole975, label %bb_rcslotowner975
bb_rcslotrole975:
  %v3640 = load i64, ptr %slot49, align 8
  store i64 %v3640, ptr %slot635, align 8
  %v3641 = load i64, ptr %slot635, align 8
  %v3642 = load i64, ptr %slot632, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3641, i64 %v3642) nomerge, !dbg !146
  br label %bb_rcslotdone975
bb_rcslotowner975:
  %v3643 = load i64, ptr %slot49, align 8
  store i64 %v3643, ptr %slot636, align 8
  %v3644 = load i64, ptr %slot636, align 8
  %v3645 = load i64, ptr %slot632, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3644, i64 %v3645) nomerge, !dbg !146
  br label %bb_rcslotdone975
bb_rcslotdone975:
  %v3646 = load i64, ptr %slot35, align 8
  store i64 %v3646, ptr %slot637, align 8
  %v3647 = load i64, ptr %slot27, align 8
  store i64 %v3647, ptr %slot638, align 8
  %v3648 = load i64, ptr %slot638, align 8
  %v3649 = load i64, ptr %slot637, align 8
  %p3650 = inttoptr i64 %v3648 to ptr
  %p3651 = inttoptr i64 %v3649 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3651, ptr %p3650, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3652 = load i64, ptr %slot23, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  store i32 0, ptr %p3653, align 4, !alias.scope !3, !noalias !4
  %v3654 = load i64, ptr %slot17, align 8
  %p3655 = inttoptr i64 %v3654 to ptr
  store i32 2, ptr %p3655, align 4, !alias.scope !3, !noalias !4
  %v3656 = load i64, ptr %slot24, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  %ld3658 = load i32, ptr %p3657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3658, ptr %slot639, align 8
  %v3659 = load i32, ptr %slot639, align 8
  %v3660 = load i64, ptr %slot17, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  store i32 %v3659, ptr %p3661, align 4, !alias.scope !3, !noalias !4
  %v3662 = load i64, ptr %slot16, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  store i32 1, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  %v3664 = load i64, ptr %slot28, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  %ld3666 = load i64, ptr %p3665, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3666, ptr %slot640, align 8
  %v3667 = load i64, ptr %slot640, align 8
  %v3668 = load i64, ptr %slot37, align 8
  %p3669 = inttoptr i64 %v3668 to ptr
  store i64 %v3667, ptr %p3669, align 8, !alias.scope !3, !noalias !4
  %v3670 = load i64, ptr %slot37, align 8
  %p3671 = inttoptr i64 %v3670 to ptr
  %ld3672 = load i64, ptr %p3671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3672, ptr %slot641, align 8
  %v3673 = load i64, ptr %slot20, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i32, ptr %p3674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3675, ptr %slot642, align 8
  %v3676 = load i64, ptr %slot21, align 8
  %p3677 = inttoptr i64 %v3676 to ptr
  %ld3678 = load i32, ptr %p3677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3678, ptr %slot643, align 8
  %v3679 = load i32, ptr %slot643, align 8
  %op3680 = and i32 %v3679, 24
  store i32 %op3680, ptr %slot643, align 8
  %v3681 = load i32, ptr %slot643, align 8
  %cmp3682 = icmp eq i32 %v3681, 0
  %cv3683 = zext i1 %cmp3682 to i32
  store i32 %cv3683, ptr %slot644, align 8
  %v3684 = load i32, ptr %slot642, align 8
  %v3685 = load i32, ptr %slot644, align 8
  %op3686 = and i32 %v3684, %v3685
  store i32 %op3686, ptr %slot645, align 8
  %v3687 = load i32, ptr %slot645, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcprivateown997, label %bb_rcprivateloan997
bb_rcprivateown997:
  %v3690 = load i64, ptr %slot27, align 8
  store i64 %v3690, ptr %slot646, align 8
  %v3691 = load i64, ptr %slot50, align 8
  store i64 %v3691, ptr %slot647, align 8
  %v3692 = load i64, ptr %slot49, align 8
  %v3693 = load i64, ptr %slot646, align 8
  %v3694 = load i64, ptr %slot641, align 8
  %v3695 = load i64, ptr %slot647, align 8
  %cv3696 = trunc i64 %v3695 to i32
  %call3697 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v3692, i64 %v3693, i64 %v3694, i32 %cv3696) nomerge, !dbg !148
  store i32 %call3697, ptr %slot648, align 8
  %v3698 = load i32, ptr %slot648, align 8
  %cv3699 = zext i32 %v3698 to i64
  %cond3700 = icmp ne i64 %cv3699, 0
  br i1 %cond3700, label %bb_rcsuccess1001, label %bb_rcfailure1001
bb_rcfailure1001:
  %v3701 = load i64, ptr %slot49, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  %call3703 = call i32 @myl_rc_take_failure(ptr %p3702) nomerge, !dbg !148
  store i32 %call3703, ptr %slot649, align 8
  %v3704 = load i64, ptr %slot1, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %v3706 = load i32, ptr %slot649, align 8
  %call3707 = call i32 @myl_qbe_rc_status(ptr %p3705, i32 %v3706) nomerge, !dbg !148
  store i32 %call3707, ptr %slot650, align 8
  br label %bb_failure
bb_rcsuccess1001:
  %v3708 = load i64, ptr %slot20, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i32 0, ptr %p3709, align 4, !alias.scope !3, !noalias !4
  %v3710 = load i64, ptr %slot24, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  store i32 2, ptr %p3711, align 4, !alias.scope !3, !noalias !4
  %v3712 = load i64, ptr %slot23, align 8
  %p3713 = inttoptr i64 %v3712 to ptr
  store i32 1, ptr %p3713, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared997
bb_rcprivateloan997:
  %v3714 = load i64, ptr %slot27, align 8
  store i64 %v3714, ptr %slot651, align 8
  %v3715 = load i64, ptr %slot49, align 8
  %v3716 = load i64, ptr %slot651, align 8
  %v3717 = load i64, ptr %slot641, align 8
  %call3718 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64 %v3715, i64 %v3716, i64 %v3717) nomerge, !dbg !148
  store i32 %call3718, ptr %slot652, align 8
  %v3719 = load i32, ptr %slot652, align 8
  %cv3720 = zext i32 %v3719 to i64
  %cond3721 = icmp ne i64 %cv3720, 0
  br i1 %cond3721, label %bb_rcsuccess1009, label %bb_rcfailure1009
bb_rcfailure1009:
  %v3722 = load i64, ptr %slot49, align 8
  %p3723 = inttoptr i64 %v3722 to ptr
  %call3724 = call i32 @myl_rc_take_failure(ptr %p3723) nomerge, !dbg !148
  store i32 %call3724, ptr %slot653, align 8
  %v3725 = load i64, ptr %slot1, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  %v3727 = load i32, ptr %slot653, align 8
  %call3728 = call i32 @myl_qbe_rc_status(ptr %p3726, i32 %v3727) nomerge, !dbg !148
  store i32 %call3728, ptr %slot654, align 8
  br label %bb_failure
bb_rcsuccess1009:
  %v3729 = load i64, ptr %slot24, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i32 2, ptr %p3730, align 4, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot24, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  store i32 16, ptr %p3732, align 4, !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot23, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  store i32 1, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  %v3735 = load i64, ptr %slot20, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %ld3737 = load i32, ptr %p3736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3737, ptr %slot655, align 8
  %v3738 = load i32, ptr %slot655, align 8
  %cv3739 = zext i32 %v3738 to i64
  %cond3740 = icmp ne i64 %cv3739, 0
  br i1 %cond3740, label %bb_rcslotdrop1017, label %bb_rcslotdone1017
bb_rcslotdrop1017:
  %v3741 = load i64, ptr %slot20, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  store i32 0, ptr %p3742, align 4, !alias.scope !3, !noalias !4
  %v3743 = load i64, ptr %slot26, align 8
  store i64 %v3743, ptr %slot656, align 8
  %v3744 = load i64, ptr %slot21, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  %ld3746 = load i32, ptr %p3745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3746, ptr %slot657, align 8
  %v3747 = load i32, ptr %slot657, align 8
  %op3748 = and i32 %v3747, 28
  store i32 %op3748, ptr %slot658, align 8
  %v3749 = load i32, ptr %slot658, align 8
  %cv3750 = zext i32 %v3749 to i64
  %cond3751 = icmp ne i64 %cv3750, 0
  br i1 %cond3751, label %bb_rcslotrole1017, label %bb_rcslotowner1017
bb_rcslotrole1017:
  %v3752 = load i64, ptr %slot49, align 8
  store i64 %v3752, ptr %slot659, align 8
  %v3753 = load i64, ptr %slot659, align 8
  %v3754 = load i64, ptr %slot656, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3753, i64 %v3754) nomerge, !dbg !148
  br label %bb_rcslotdone1017
bb_rcslotowner1017:
  %v3755 = load i64, ptr %slot49, align 8
  store i64 %v3755, ptr %slot660, align 8
  %v3756 = load i64, ptr %slot660, align 8
  %v3757 = load i64, ptr %slot656, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3756, i64 %v3757) nomerge, !dbg !148
  br label %bb_rcslotdone1017
bb_rcslotdone1017:
  br label %bb_rcprivateprepared997
bb_rcprivateprepared997:
  %v3758 = load i64, ptr %slot16, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  %ld3760 = load i32, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3760, ptr %slot661, align 8
  %v3761 = load i32, ptr %slot661, align 8
  %cv3762 = zext i32 %v3761 to i64
  %cond3763 = icmp ne i64 %cv3762, 0
  br i1 %cond3763, label %bb_rcslotdrop1027, label %bb_rcslotdone1027
bb_rcslotdrop1027:
  %v3764 = load i64, ptr %slot16, align 8
  %p3765 = inttoptr i64 %v3764 to ptr
  store i32 0, ptr %p3765, align 4, !alias.scope !3, !noalias !4
  %v3766 = load i64, ptr %slot35, align 8
  store i64 %v3766, ptr %slot662, align 8
  %v3767 = load i64, ptr %slot17, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  %ld3769 = load i32, ptr %p3768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3769, ptr %slot663, align 8
  %v3770 = load i32, ptr %slot663, align 8
  %op3771 = and i32 %v3770, 28
  store i32 %op3771, ptr %slot664, align 8
  %v3772 = load i32, ptr %slot664, align 8
  %cv3773 = zext i32 %v3772 to i64
  %cond3774 = icmp ne i64 %cv3773, 0
  br i1 %cond3774, label %bb_rcslotrole1027, label %bb_rcslotowner1027
bb_rcslotrole1027:
  %v3775 = load i64, ptr %slot49, align 8
  store i64 %v3775, ptr %slot665, align 8
  %v3776 = load i64, ptr %slot665, align 8
  %v3777 = load i64, ptr %slot662, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3776, i64 %v3777) nomerge, !dbg !148
  br label %bb_rcslotdone1027
bb_rcslotowner1027:
  %v3778 = load i64, ptr %slot49, align 8
  store i64 %v3778, ptr %slot666, align 8
  %v3779 = load i64, ptr %slot666, align 8
  %v3780 = load i64, ptr %slot662, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3779, i64 %v3780) nomerge, !dbg !148
  br label %bb_rcslotdone1027
bb_rcslotdone1027:
  %v3781 = load i64, ptr %slot35, align 8
  store i64 %v3781, ptr %slot667, align 8
  %v3782 = load i64, ptr %slot27, align 8
  store i64 %v3782, ptr %slot668, align 8
  %v3783 = load i64, ptr %slot668, align 8
  %v3784 = load i64, ptr %slot667, align 8
  %p3785 = inttoptr i64 %v3783 to ptr
  %p3786 = inttoptr i64 %v3784 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3786, ptr %p3785, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3787 = load i64, ptr %slot23, align 8
  %p3788 = inttoptr i64 %v3787 to ptr
  store i32 0, ptr %p3788, align 4, !alias.scope !3, !noalias !4
  %v3789 = load i64, ptr %slot17, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  store i32 2, ptr %p3790, align 4, !alias.scope !3, !noalias !4
  %v3791 = load i64, ptr %slot24, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  %ld3793 = load i32, ptr %p3792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3793, ptr %slot669, align 8
  %v3794 = load i32, ptr %slot669, align 8
  %v3795 = load i64, ptr %slot17, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  store i32 %v3794, ptr %p3796, align 4, !alias.scope !3, !noalias !4
  %v3797 = load i64, ptr %slot16, align 8
  %p3798 = inttoptr i64 %v3797 to ptr
  store i32 1, ptr %p3798, align 4, !alias.scope !3, !noalias !4
  %v3799 = load i64, ptr %slot35, align 8
  %v3800 = load i64, ptr %slot37, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  store i64 %v3799, ptr %p3801, align 8, !alias.scope !3, !noalias !4
  %v3802 = load i64, ptr %slot36, align 8
  %v3803 = load i64, ptr %slot38, align 8
  %p3804 = inttoptr i64 %v3803 to ptr
  store i64 %v3802, ptr %p3804, align 8, !alias.scope !3, !noalias !4
  %v3805 = load i64, ptr %slot37, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %ld3807 = load i64, ptr %p3806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3807, ptr %slot670, align 8
  %v3808 = load i64, ptr %slot20, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  %ld3810 = load i32, ptr %p3809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3810, ptr %slot671, align 8
  %v3811 = load i64, ptr %slot21, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  %ld3813 = load i32, ptr %p3812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3813, ptr %slot672, align 8
  %v3814 = load i32, ptr %slot672, align 8
  %op3815 = and i32 %v3814, 24
  store i32 %op3815, ptr %slot672, align 8
  %v3816 = load i32, ptr %slot672, align 8
  %cmp3817 = icmp eq i32 %v3816, 0
  %cv3818 = zext i1 %cmp3817 to i32
  store i32 %cv3818, ptr %slot673, align 8
  %v3819 = load i32, ptr %slot671, align 8
  %v3820 = load i32, ptr %slot673, align 8
  %op3821 = and i32 %v3819, %v3820
  store i32 %op3821, ptr %slot674, align 8
  %v3822 = load i32, ptr %slot674, align 8
  %cv3823 = zext i32 %v3822 to i64
  %cond3824 = icmp ne i64 %cv3823, 0
  br i1 %cond3824, label %bb_rctake1042, label %bb_rccopy1042
bb_rctake1042:
  %v3825 = load i64, ptr %slot27, align 8
  store i64 %v3825, ptr %slot675, align 8
  %v3826 = load i64, ptr %slot50, align 8
  store i64 %v3826, ptr %slot676, align 8
  %v3827 = load i64, ptr %slot49, align 8
  %v3828 = load i64, ptr %slot675, align 8
  %v3829 = load i64, ptr %slot670, align 8
  %v3830 = load i64, ptr %slot676, align 8
  %cv3831 = trunc i64 %v3830 to i32
  %call3832 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v3827, i64 %v3828, i64 %v3829, i32 %cv3831) nomerge, !dbg !150
  store i32 %call3832, ptr %slot677, align 8
  %v3833 = load i32, ptr %slot677, align 8
  %cv3834 = zext i32 %v3833 to i64
  %cond3835 = icmp ne i64 %cv3834, 0
  br i1 %cond3835, label %bb_rcsuccess1052, label %bb_rcfailure1052
bb_rcfailure1052:
  %v3836 = load i64, ptr %slot49, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  %call3838 = call i32 @myl_rc_take_failure(ptr %p3837) nomerge, !dbg !150
  store i32 %call3838, ptr %slot678, align 8
  %v3839 = load i64, ptr %slot1, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %v3841 = load i32, ptr %slot678, align 8
  %call3842 = call i32 @myl_qbe_rc_status(ptr %p3840, i32 %v3841) nomerge, !dbg !150
  store i32 %call3842, ptr %slot679, align 8
  br label %bb_failure
bb_rcsuccess1052:
  %v3843 = load i64, ptr %slot20, align 8
  %p3844 = inttoptr i64 %v3843 to ptr
  store i32 0, ptr %p3844, align 4, !alias.scope !3, !noalias !4
  %v3845 = load i64, ptr %slot24, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i32 2, ptr %p3846, align 4, !alias.scope !3, !noalias !4
  %v3847 = load i64, ptr %slot23, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  store i32 1, ptr %p3848, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1042
bb_rccopy1042:
  %v3849 = load i64, ptr %slot27, align 8
  store i64 %v3849, ptr %slot680, align 8
  %v3850 = load i64, ptr %slot50, align 8
  store i64 %v3850, ptr %slot681, align 8
  %v3851 = load i64, ptr %slot49, align 8
  %v3852 = load i64, ptr %slot680, align 8
  %v3853 = load i64, ptr %slot670, align 8
  %v3854 = load i64, ptr %slot681, align 8
  %cv3855 = trunc i64 %v3854 to i32
  %call3856 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v3851, i64 %v3852, i64 %v3853, i32 %cv3855) nomerge, !dbg !150
  store i32 %call3856, ptr %slot682, align 8
  %v3857 = load i32, ptr %slot682, align 8
  %cv3858 = zext i32 %v3857 to i64
  %cond3859 = icmp ne i64 %cv3858, 0
  br i1 %cond3859, label %bb_rcsuccess1061, label %bb_rcfailure1061
bb_rcfailure1061:
  %v3860 = load i64, ptr %slot49, align 8
  %p3861 = inttoptr i64 %v3860 to ptr
  %call3862 = call i32 @myl_rc_take_failure(ptr %p3861) nomerge, !dbg !150
  store i32 %call3862, ptr %slot683, align 8
  %v3863 = load i64, ptr %slot1, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %v3865 = load i32, ptr %slot683, align 8
  %call3866 = call i32 @myl_qbe_rc_status(ptr %p3864, i32 %v3865) nomerge, !dbg !150
  store i32 %call3866, ptr %slot684, align 8
  br label %bb_failure
bb_rcsuccess1061:
  %v3867 = load i64, ptr %slot24, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  store i32 2, ptr %p3868, align 4, !alias.scope !3, !noalias !4
  %v3869 = load i64, ptr %slot23, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  store i32 1, ptr %p3870, align 4, !alias.scope !3, !noalias !4
  %v3871 = load i64, ptr %slot20, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %ld3873 = load i32, ptr %p3872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3873, ptr %slot685, align 8
  %v3874 = load i32, ptr %slot685, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcslotdrop1068, label %bb_rcslotdone1068
bb_rcslotdrop1068:
  %v3877 = load i64, ptr %slot20, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i32 0, ptr %p3878, align 4, !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot26, align 8
  store i64 %v3879, ptr %slot686, align 8
  %v3880 = load i64, ptr %slot21, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  %ld3882 = load i32, ptr %p3881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3882, ptr %slot687, align 8
  %v3883 = load i32, ptr %slot687, align 8
  %op3884 = and i32 %v3883, 28
  store i32 %op3884, ptr %slot688, align 8
  %v3885 = load i32, ptr %slot688, align 8
  %cv3886 = zext i32 %v3885 to i64
  %cond3887 = icmp ne i64 %cv3886, 0
  br i1 %cond3887, label %bb_rcslotrole1068, label %bb_rcslotowner1068
bb_rcslotrole1068:
  %v3888 = load i64, ptr %slot49, align 8
  store i64 %v3888, ptr %slot689, align 8
  %v3889 = load i64, ptr %slot689, align 8
  %v3890 = load i64, ptr %slot686, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3889, i64 %v3890) nomerge, !dbg !150
  br label %bb_rcslotdone1068
bb_rcslotowner1068:
  %v3891 = load i64, ptr %slot49, align 8
  store i64 %v3891, ptr %slot690, align 8
  %v3892 = load i64, ptr %slot690, align 8
  %v3893 = load i64, ptr %slot686, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3892, i64 %v3893) nomerge, !dbg !150
  br label %bb_rcslotdone1068
bb_rcslotdone1068:
  br label %bb_rcprepared1042
bb_rcprepared1042:
  %v3894 = load i64, ptr %slot27, align 8
  store i64 %v3894, ptr %slot691, align 8
  %v3895 = load i64, ptr %slot41, align 8
  store i64 %v3895, ptr %slot692, align 8
  %v3896 = load i64, ptr %slot691, align 8
  %v3897 = load i64, ptr %slot692, align 8
  %p3898 = inttoptr i64 %v3896 to ptr
  %p3899 = inttoptr i64 %v3897 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3899, ptr %p3898, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot23, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  store i32 0, ptr %p3901, align 4, !alias.scope !3, !noalias !4
  %v3902 = load i64, ptr %slot25, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  store i32 1, ptr %p3903, align 4, !alias.scope !3, !noalias !4
  %v3904 = load i64, ptr %slot50, align 8
  store i64 %v3904, ptr %slot693, align 8
  %v3905 = load i64, ptr %slot38, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %ld3907 = load i64, ptr %p3906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3907, ptr %slot694, align 8
  %v3908 = load i64, ptr %slot692, align 8
  %p3910 = inttoptr i64 %v3908 to ptr
  %gep3911 = getelementptr i8, ptr %p3910, i64 288
  %op3909 = ptrtoint ptr %gep3911 to i64
  store i64 %op3909, ptr %slot695, align 8
  %v3912 = load i64, ptr %slot27, align 8
  store i64 %v3912, ptr %slot696, align 8
  %v3913 = load i64, ptr %slot38, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %ld3915 = load i64, ptr %p3914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3915, ptr %slot697, align 8
  store i32 0, ptr %slot698, align 8
  %v3916 = load i64, ptr %slot22, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  %ld3918 = load i32, ptr %p3917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3918, ptr %slot699, align 8
  %v3919 = load i32, ptr %slot699, align 8
  %op3920 = and i32 %v3919, 24
  store i32 %op3920, ptr %slot699, align 8
  %v3921 = load i32, ptr %slot699, align 8
  %cmp3922 = icmp eq i32 %v3921, 0
  %cv3923 = zext i1 %cmp3922 to i32
  store i32 %cv3923, ptr %slot700, align 8
  %v3924 = load i32, ptr %slot698, align 8
  %v3925 = load i32, ptr %slot700, align 8
  %op3926 = and i32 %v3924, %v3925
  store i32 %op3926, ptr %slot701, align 8
  %v3927 = load i32, ptr %slot701, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rctake1085, label %bb_rccopy1085
bb_rctake1085:
  %v3930 = load i64, ptr %slot27, align 8
  store i64 %v3930, ptr %slot702, align 8
  %v3931 = load i64, ptr %slot50, align 8
  store i64 %v3931, ptr %slot703, align 8
  %v3932 = load i64, ptr %slot49, align 8
  %v3933 = load i64, ptr %slot702, align 8
  %v3934 = load i64, ptr %slot697, align 8
  %v3935 = load i64, ptr %slot703, align 8
  %cv3936 = trunc i64 %v3935 to i32
  %call3937 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v3932, i64 %v3933, i64 %v3934, i32 %cv3936) nomerge, !dbg !150
  store i32 %call3937, ptr %slot704, align 8
  %v3938 = load i32, ptr %slot704, align 8
  %cv3939 = zext i32 %v3938 to i64
  %cond3940 = icmp ne i64 %cv3939, 0
  br i1 %cond3940, label %bb_rcsuccess1095, label %bb_rcfailure1095
bb_rcfailure1095:
  %v3941 = load i64, ptr %slot49, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  %call3943 = call i32 @myl_rc_take_failure(ptr %p3942) nomerge, !dbg !150
  store i32 %call3943, ptr %slot705, align 8
  %v3944 = load i64, ptr %slot1, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  %v3946 = load i32, ptr %slot705, align 8
  %call3947 = call i32 @myl_qbe_rc_status(ptr %p3945, i32 %v3946) nomerge, !dbg !150
  store i32 %call3947, ptr %slot706, align 8
  br label %bb_failure
bb_rcsuccess1095:
  %v3948 = load i64, ptr %slot24, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  store i32 2, ptr %p3949, align 4, !alias.scope !3, !noalias !4
  %v3950 = load i64, ptr %slot23, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  store i32 1, ptr %p3951, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1085
bb_rccopy1085:
  %v3952 = load i64, ptr %slot27, align 8
  store i64 %v3952, ptr %slot707, align 8
  %v3953 = load i64, ptr %slot50, align 8
  store i64 %v3953, ptr %slot708, align 8
  %v3954 = load i64, ptr %slot49, align 8
  %v3955 = load i64, ptr %slot707, align 8
  %v3956 = load i64, ptr %slot697, align 8
  %v3957 = load i64, ptr %slot708, align 8
  %cv3958 = trunc i64 %v3957 to i32
  %call3959 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v3954, i64 %v3955, i64 %v3956, i32 %cv3958) nomerge, !dbg !150
  store i32 %call3959, ptr %slot709, align 8
  %v3960 = load i32, ptr %slot709, align 8
  %cv3961 = zext i32 %v3960 to i64
  %cond3962 = icmp ne i64 %cv3961, 0
  br i1 %cond3962, label %bb_rcsuccess1104, label %bb_rcfailure1104
bb_rcfailure1104:
  %v3963 = load i64, ptr %slot49, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  %call3965 = call i32 @myl_rc_take_failure(ptr %p3964) nomerge, !dbg !150
  store i32 %call3965, ptr %slot710, align 8
  %v3966 = load i64, ptr %slot1, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %v3968 = load i32, ptr %slot710, align 8
  %call3969 = call i32 @myl_qbe_rc_status(ptr %p3967, i32 %v3968) nomerge, !dbg !150
  store i32 %call3969, ptr %slot711, align 8
  br label %bb_failure
bb_rcsuccess1104:
  %v3970 = load i64, ptr %slot24, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i32 2, ptr %p3971, align 4, !alias.scope !3, !noalias !4
  %v3972 = load i64, ptr %slot23, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  store i32 1, ptr %p3973, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1085
bb_rcprepared1085:
  %v3974 = load i64, ptr %slot27, align 8
  store i64 %v3974, ptr %slot712, align 8
  %v3975 = load i64, ptr %slot712, align 8
  %v3976 = load i64, ptr %slot696, align 8
  %p3977 = inttoptr i64 %v3975 to ptr
  %p3978 = inttoptr i64 %v3976 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3978, ptr %p3977, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3979 = load i64, ptr %slot23, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  store i32 0, ptr %p3980, align 4, !alias.scope !3, !noalias !4
  %v3981 = load i64, ptr %slot24, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  store i32 2, ptr %p3982, align 4, !alias.scope !3, !noalias !4
  %v3983 = load i64, ptr %slot23, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  store i32 1, ptr %p3984, align 4, !alias.scope !3, !noalias !4
  %v3985 = load i64, ptr %slot49, align 8
  store i64 %v3985, ptr %slot713, align 8
  %v3986 = load i64, ptr %slot713, align 8
  %v3987 = load i64, ptr %slot695, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3986, i64 %v3987) nomerge, !dbg !150
  %v3988 = load i64, ptr %slot696, align 8
  %v3989 = load i64, ptr %slot695, align 8
  %p3990 = inttoptr i64 %v3988 to ptr
  %p3991 = inttoptr i64 %v3989 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3991, ptr %p3990, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3992 = load i64, ptr %slot23, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  store i32 0, ptr %p3993, align 4, !alias.scope !3, !noalias !4
  %v3994 = load i64, ptr %slot692, align 8
  %v3995 = load i64, ptr %slot37, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  store i64 %v3994, ptr %p3996, align 8, !alias.scope !3, !noalias !4
  %v3997 = load i64, ptr %slot37, align 8
  %p3998 = inttoptr i64 %v3997 to ptr
  %ld3999 = load i64, ptr %p3998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3999, ptr %slot714, align 8
  %v4000 = load i64, ptr %slot27, align 8
  store i64 %v4000, ptr %slot715, align 8
  %v4001 = load i64, ptr %slot714, align 8
  %v4002 = load i64, ptr %slot715, align 8
  %p4003 = inttoptr i64 %v4001 to ptr
  %p4004 = inttoptr i64 %v4002 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4004, ptr %p4003, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v4005 = load i64, ptr %slot24, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  store i32 2, ptr %p4006, align 4, !alias.scope !3, !noalias !4
  %v4007 = load i64, ptr %slot23, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  store i32 1, ptr %p4008, align 4, !alias.scope !3, !noalias !4
  %v4009 = load i64, ptr %slot20, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  %ld4011 = load i32, ptr %p4010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4011, ptr %slot716, align 8
  %v4012 = load i32, ptr %slot716, align 8
  %cv4013 = zext i32 %v4012 to i64
  %cond4014 = icmp ne i64 %cv4013, 0
  br i1 %cond4014, label %bb_rcslotdrop1130, label %bb_rcslotdone1130
bb_rcslotdrop1130:
  %v4015 = load i64, ptr %slot20, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  store i32 0, ptr %p4016, align 4, !alias.scope !3, !noalias !4
  %v4017 = load i64, ptr %slot26, align 8
  store i64 %v4017, ptr %slot717, align 8
  %v4018 = load i64, ptr %slot21, align 8
  %p4019 = inttoptr i64 %v4018 to ptr
  %ld4020 = load i32, ptr %p4019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4020, ptr %slot718, align 8
  %v4021 = load i32, ptr %slot718, align 8
  %op4022 = and i32 %v4021, 28
  store i32 %op4022, ptr %slot719, align 8
  %v4023 = load i32, ptr %slot719, align 8
  %cv4024 = zext i32 %v4023 to i64
  %cond4025 = icmp ne i64 %cv4024, 0
  br i1 %cond4025, label %bb_rcslotrole1130, label %bb_rcslotowner1130
bb_rcslotrole1130:
  %v4026 = load i64, ptr %slot49, align 8
  store i64 %v4026, ptr %slot720, align 8
  %v4027 = load i64, ptr %slot720, align 8
  %v4028 = load i64, ptr %slot717, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4027, i64 %v4028) nomerge, !dbg !150
  br label %bb_rcslotdone1130
bb_rcslotowner1130:
  %v4029 = load i64, ptr %slot49, align 8
  store i64 %v4029, ptr %slot721, align 8
  %v4030 = load i64, ptr %slot721, align 8
  %v4031 = load i64, ptr %slot717, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4030, i64 %v4031) nomerge, !dbg !150
  br label %bb_rcslotdone1130
bb_rcslotdone1130:
  %v4032 = load i64, ptr %slot26, align 8
  store i64 %v4032, ptr %slot722, align 8
  %v4033 = load i64, ptr %slot27, align 8
  store i64 %v4033, ptr %slot723, align 8
  %v4034 = load i64, ptr %slot723, align 8
  %v4035 = load i64, ptr %slot722, align 8
  %p4036 = inttoptr i64 %v4034 to ptr
  %p4037 = inttoptr i64 %v4035 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4037, ptr %p4036, i64 392, i1 false), !alias.scope !3, !noalias !4
  %v4038 = load i64, ptr %slot21, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 2, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot24, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i32, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4042, ptr %slot724, align 8
  %v4043 = load i32, ptr %slot724, align 8
  %v4044 = load i64, ptr %slot21, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i32 %v4043, ptr %p4045, align 4, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot23, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  store i32 0, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  %v4048 = load i64, ptr %slot20, align 8
  %p4049 = inttoptr i64 %v4048 to ptr
  store i32 1, ptr %p4049, align 4, !alias.scope !3, !noalias !4
  %v4050 = load i64, ptr %slot722, align 8
  %v4051 = load i64, ptr %slot37, align 8
  %p4052 = inttoptr i64 %v4051 to ptr
  store i64 %v4050, ptr %p4052, align 8, !alias.scope !3, !noalias !4
  %v4053 = load i64, ptr %slot37, align 8
  %p4054 = inttoptr i64 %v4053 to ptr
  %ld4055 = load i64, ptr %p4054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4055, ptr %slot725, align 8
  %v4056 = load i64, ptr %slot20, align 8
  %p4057 = inttoptr i64 %v4056 to ptr
  %ld4058 = load i32, ptr %p4057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4058, ptr %slot726, align 8
  %v4059 = load i64, ptr %slot21, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  %ld4061 = load i32, ptr %p4060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4061, ptr %slot727, align 8
  %v4062 = load i32, ptr %slot727, align 8
  %op4063 = and i32 %v4062, 24
  store i32 %op4063, ptr %slot727, align 8
  %v4064 = load i32, ptr %slot727, align 8
  %cmp4065 = icmp eq i32 %v4064, 0
  %cv4066 = zext i1 %cmp4065 to i32
  store i32 %cv4066, ptr %slot728, align 8
  %v4067 = load i32, ptr %slot726, align 8
  %v4068 = load i32, ptr %slot728, align 8
  %op4069 = and i32 %v4067, %v4068
  store i32 %op4069, ptr %slot729, align 8
  %v4070 = load i32, ptr %slot729, align 8
  %cv4071 = zext i32 %v4070 to i64
  %cond4072 = icmp ne i64 %cv4071, 0
  br i1 %cond4072, label %bb_rctake1155, label %bb_rccopy1155
bb_rctake1155:
  %v4073 = load i64, ptr %slot27, align 8
  store i64 %v4073, ptr %slot730, align 8
  %v4074 = load i64, ptr %slot50, align 8
  store i64 %v4074, ptr %slot731, align 8
  %v4075 = load i64, ptr %slot49, align 8
  %v4076 = load i64, ptr %slot730, align 8
  %v4077 = load i64, ptr %slot725, align 8
  %v4078 = load i64, ptr %slot731, align 8
  %cv4079 = trunc i64 %v4078 to i32
  %call4080 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64 %v4075, i64 %v4076, i64 %v4077, i32 %cv4079) nomerge, !dbg !152
  store i32 %call4080, ptr %slot732, align 8
  %v4081 = load i32, ptr %slot732, align 8
  %cv4082 = zext i32 %v4081 to i64
  %cond4083 = icmp ne i64 %cv4082, 0
  br i1 %cond4083, label %bb_rcsuccess1165, label %bb_rcfailure1165
bb_rcfailure1165:
  %v4084 = load i64, ptr %slot49, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  %call4086 = call i32 @myl_rc_take_failure(ptr %p4085) nomerge, !dbg !152
  store i32 %call4086, ptr %slot733, align 8
  %v4087 = load i64, ptr %slot1, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  %v4089 = load i32, ptr %slot733, align 8
  %call4090 = call i32 @myl_qbe_rc_status(ptr %p4088, i32 %v4089) nomerge, !dbg !152
  store i32 %call4090, ptr %slot734, align 8
  br label %bb_failure
bb_rcsuccess1165:
  %v4091 = load i64, ptr %slot20, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  store i32 0, ptr %p4092, align 4, !alias.scope !3, !noalias !4
  %v4093 = load i64, ptr %slot24, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i32 2, ptr %p4094, align 4, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot23, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  store i32 1, ptr %p4096, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1155
bb_rccopy1155:
  %v4097 = load i64, ptr %slot27, align 8
  store i64 %v4097, ptr %slot735, align 8
  %v4098 = load i64, ptr %slot50, align 8
  store i64 %v4098, ptr %slot736, align 8
  %v4099 = load i64, ptr %slot49, align 8
  %v4100 = load i64, ptr %slot735, align 8
  %v4101 = load i64, ptr %slot725, align 8
  %v4102 = load i64, ptr %slot736, align 8
  %cv4103 = trunc i64 %v4102 to i32
  %call4104 = call i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64 %v4099, i64 %v4100, i64 %v4101, i32 %cv4103) nomerge, !dbg !152
  store i32 %call4104, ptr %slot737, align 8
  %v4105 = load i32, ptr %slot737, align 8
  %cv4106 = zext i32 %v4105 to i64
  %cond4107 = icmp ne i64 %cv4106, 0
  br i1 %cond4107, label %bb_rcsuccess1174, label %bb_rcfailure1174
bb_rcfailure1174:
  %v4108 = load i64, ptr %slot49, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  %call4110 = call i32 @myl_rc_take_failure(ptr %p4109) nomerge, !dbg !152
  store i32 %call4110, ptr %slot738, align 8
  %v4111 = load i64, ptr %slot1, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  %v4113 = load i32, ptr %slot738, align 8
  %call4114 = call i32 @myl_qbe_rc_status(ptr %p4112, i32 %v4113) nomerge, !dbg !152
  store i32 %call4114, ptr %slot739, align 8
  br label %bb_failure
bb_rcsuccess1174:
  %v4115 = load i64, ptr %slot24, align 8
  %p4116 = inttoptr i64 %v4115 to ptr
  store i32 2, ptr %p4116, align 4, !alias.scope !3, !noalias !4
  %v4117 = load i64, ptr %slot23, align 8
  %p4118 = inttoptr i64 %v4117 to ptr
  store i32 1, ptr %p4118, align 4, !alias.scope !3, !noalias !4
  %v4119 = load i64, ptr %slot20, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %ld4121 = load i32, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4121, ptr %slot740, align 8
  %v4122 = load i32, ptr %slot740, align 8
  %cv4123 = zext i32 %v4122 to i64
  %cond4124 = icmp ne i64 %cv4123, 0
  br i1 %cond4124, label %bb_rcslotdrop1181, label %bb_rcslotdone1181
bb_rcslotdrop1181:
  %v4125 = load i64, ptr %slot20, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  store i32 0, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  %v4127 = load i64, ptr %slot26, align 8
  store i64 %v4127, ptr %slot741, align 8
  %v4128 = load i64, ptr %slot21, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  %ld4130 = load i32, ptr %p4129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4130, ptr %slot742, align 8
  %v4131 = load i32, ptr %slot742, align 8
  %op4132 = and i32 %v4131, 28
  store i32 %op4132, ptr %slot743, align 8
  %v4133 = load i32, ptr %slot743, align 8
  %cv4134 = zext i32 %v4133 to i64
  %cond4135 = icmp ne i64 %cv4134, 0
  br i1 %cond4135, label %bb_rcslotrole1181, label %bb_rcslotowner1181
bb_rcslotrole1181:
  %v4136 = load i64, ptr %slot49, align 8
  store i64 %v4136, ptr %slot744, align 8
  %v4137 = load i64, ptr %slot744, align 8
  %v4138 = load i64, ptr %slot741, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4137, i64 %v4138) nomerge, !dbg !152
  br label %bb_rcslotdone1181
bb_rcslotowner1181:
  %v4139 = load i64, ptr %slot49, align 8
  store i64 %v4139, ptr %slot745, align 8
  %v4140 = load i64, ptr %slot745, align 8
  %v4141 = load i64, ptr %slot741, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4140, i64 %v4141) nomerge, !dbg !152
  br label %bb_rcslotdone1181
bb_rcslotdone1181:
  br label %bb_rcprepared1155
bb_rcprepared1155:
  %v4142 = load i64, ptr %slot28, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %ld4144 = load i64, ptr %p4143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4144, ptr %slot746, align 8
  %v4145 = load i64, ptr %slot49, align 8
  store i64 %v4145, ptr %slot747, align 8
  %v4146 = load i64, ptr %slot747, align 8
  %v4147 = load i64, ptr %slot746, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4146, i64 %v4147) nomerge, !dbg !152
  %v4148 = load i64, ptr %slot27, align 8
  store i64 %v4148, ptr %slot748, align 8
  %v4149 = load i64, ptr %slot748, align 8
  %v4150 = load i64, ptr %slot746, align 8
  %p4151 = inttoptr i64 %v4149 to ptr
  %p4152 = inttoptr i64 %v4150 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4152, ptr %p4151, i64 392, i1 false), !alias.scope !10000000
  %v4153 = load i64, ptr %slot23, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  store i32 0, ptr %p4154, align 4, !alias.scope !3, !noalias !4
  %v4155 = load i64, ptr %slot37, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  store i64 0, ptr %p4156, align 8, !alias.scope !3, !noalias !4
  %v4157 = load i64, ptr %slot28, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %ld4159 = load i64, ptr %p4158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4159, ptr %slot749, align 8
  %v4160 = load i64, ptr %slot749, align 8
  %v4161 = load i64, ptr %slot37, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  store i64 %v4160, ptr %p4162, align 8, !alias.scope !3, !noalias !4
  %v4163 = load i64, ptr %slot37, align 8
  %p4164 = inttoptr i64 %v4163 to ptr
  %ld4165 = load i64, ptr %p4164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4165, ptr %slot750, align 8
  %v4166 = load i64, ptr %slot750, align 8
  %op4167 = add i64 %v4166, 288
  store i64 %op4167, ptr %slot751, align 8
  %v4168 = load i64, ptr %slot751, align 8
  %v4169 = load i64, ptr %slot37, align 8
  %p4170 = inttoptr i64 %v4169 to ptr
  store i64 %v4168, ptr %p4170, align 8, !alias.scope !3, !noalias !4
  %v4171 = load i64, ptr %slot20, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i32, ptr %p4172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4173, ptr %slot752, align 8
  %v4174 = load i32, ptr %slot752, align 8
  %cv4175 = zext i32 %v4174 to i64
  %cond4176 = icmp ne i64 %cv4175, 0
  br i1 %cond4176, label %bb_rcslotdrop1197, label %bb_rcslotdone1197
bb_rcslotdrop1197:
  %v4177 = load i64, ptr %slot20, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  store i32 0, ptr %p4178, align 4, !alias.scope !3, !noalias !4
  %v4179 = load i64, ptr %slot26, align 8
  store i64 %v4179, ptr %slot753, align 8
  %v4180 = load i64, ptr %slot21, align 8
  %p4181 = inttoptr i64 %v4180 to ptr
  %ld4182 = load i32, ptr %p4181, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4182, ptr %slot754, align 8
  %v4183 = load i32, ptr %slot754, align 8
  %op4184 = and i32 %v4183, 28
  store i32 %op4184, ptr %slot755, align 8
  %v4185 = load i32, ptr %slot755, align 8
  %cv4186 = zext i32 %v4185 to i64
  %cond4187 = icmp ne i64 %cv4186, 0
  br i1 %cond4187, label %bb_rcslotrole1197, label %bb_rcslotowner1197
bb_rcslotrole1197:
  %v4188 = load i64, ptr %slot49, align 8
  store i64 %v4188, ptr %slot756, align 8
  %v4189 = load i64, ptr %slot756, align 8
  %v4190 = load i64, ptr %slot753, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4189, i64 %v4190) nomerge, !dbg !154
  br label %bb_rcslotdone1197
bb_rcslotowner1197:
  %v4191 = load i64, ptr %slot49, align 8
  store i64 %v4191, ptr %slot757, align 8
  %v4192 = load i64, ptr %slot757, align 8
  %v4193 = load i64, ptr %slot753, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4192, i64 %v4193) nomerge, !dbg !154
  br label %bb_rcslotdone1197
bb_rcslotdone1197:
  %v4194 = load i64, ptr %slot37, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  %ld4196 = load i64, ptr %p4195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4196, ptr %slot758, align 8
  %v4197 = load i64, ptr %slot758, align 8
  %op4198 = add i64 %v4197, 0
  store i64 %op4198, ptr %slot759, align 8
  %v4199 = load i64, ptr %slot759, align 8
  %v4200 = load i64, ptr %slot37, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  store i64 %v4199, ptr %p4201, align 8, !alias.scope !3, !noalias !4
  %v4202 = load i64, ptr %slot37, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  %ld4204 = load i64, ptr %p4203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4204, ptr %slot760, align 8
  %v4205 = load i64, ptr %slot42, align 8
  store i64 %v4205, ptr %slot761, align 8
  %v4206 = load i64, ptr %slot760, align 8
  %v4207 = load i64, ptr %slot761, align 8
  %p4208 = inttoptr i64 %v4206 to ptr
  %p4209 = inttoptr i64 %v4207 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4209, ptr %p4208, i64 4, i1 false), !alias.scope !10000000
  %v4210 = load i64, ptr %slot761, align 8
  %v4211 = load i64, ptr %slot37, align 8
  %p4212 = inttoptr i64 %v4211 to ptr
  store i64 %v4210, ptr %p4212, align 8, !alias.scope !3, !noalias !4
  %v4213 = load i64, ptr %slot20, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %ld4215 = load i32, ptr %p4214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4215, ptr %slot762, align 8
  %v4216 = load i32, ptr %slot762, align 8
  %cv4217 = zext i32 %v4216 to i64
  %cond4218 = icmp ne i64 %cv4217, 0
  br i1 %cond4218, label %bb_rcslotdrop1210, label %bb_rcslotdone1210
bb_rcslotdrop1210:
  %v4219 = load i64, ptr %slot20, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  store i32 0, ptr %p4220, align 4, !alias.scope !3, !noalias !4
  %v4221 = load i64, ptr %slot26, align 8
  store i64 %v4221, ptr %slot763, align 8
  %v4222 = load i64, ptr %slot21, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  %ld4224 = load i32, ptr %p4223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4224, ptr %slot764, align 8
  %v4225 = load i32, ptr %slot764, align 8
  %op4226 = and i32 %v4225, 28
  store i32 %op4226, ptr %slot765, align 8
  %v4227 = load i32, ptr %slot765, align 8
  %cv4228 = zext i32 %v4227 to i64
  %cond4229 = icmp ne i64 %cv4228, 0
  br i1 %cond4229, label %bb_rcslotrole1210, label %bb_rcslotowner1210
bb_rcslotrole1210:
  %v4230 = load i64, ptr %slot49, align 8
  store i64 %v4230, ptr %slot766, align 8
  %v4231 = load i64, ptr %slot766, align 8
  %v4232 = load i64, ptr %slot763, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4231, i64 %v4232) nomerge, !dbg !156
  br label %bb_rcslotdone1210
bb_rcslotowner1210:
  %v4233 = load i64, ptr %slot49, align 8
  store i64 %v4233, ptr %slot767, align 8
  %v4234 = load i64, ptr %slot767, align 8
  %v4235 = load i64, ptr %slot763, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4234, i64 %v4235) nomerge, !dbg !156
  br label %bb_rcslotdone1210
bb_rcslotdone1210:
  %v4236 = load i64, ptr %slot43, align 8
  store i64 %v4236, ptr %slot768, align 8
  %v4237 = load i64, ptr %slot768, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  store i32 0, ptr %p4238, align 4, !alias.scope !3, !noalias !4
  %v4239 = load i64, ptr %slot768, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  store i32 38, ptr %p4240, align 4, !alias.scope !3, !noalias !4
  %v4241 = load i64, ptr %slot768, align 8
  %v4242 = load i64, ptr %slot38, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  store i64 %v4241, ptr %p4243, align 8, !alias.scope !3, !noalias !4
  %v4244 = load i64, ptr %slot38, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %ld4246 = load i64, ptr %p4245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4246, ptr %slot769, align 8
  %v4247 = load i64, ptr %slot37, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %ld4249 = load i64, ptr %p4248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4249, ptr %slot770, align 8
  %v4250 = load i64, ptr %slot770, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  %ld4252 = load i32, ptr %p4251, align 4, !alias.scope !3, !noalias !4
  %ext4253 = zext i32 %ld4252 to i64
  store i64 %ext4253, ptr %slot771, align 8
  %v4254 = load i64, ptr %slot769, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  %ld4256 = load i32, ptr %p4255, align 4, !alias.scope !3, !noalias !4
  %ext4257 = zext i32 %ld4256 to i64
  store i64 %ext4257, ptr %slot772, align 8
  %v4258 = load i64, ptr %slot771, align 8
  %v4259 = load i64, ptr %slot772, align 8
  %cmp4260 = icmp ne i64 %v4258, %v4259
  %cv4261 = zext i1 %cmp4260 to i64
  store i64 %cv4261, ptr %slot773, align 8
  %v4262 = load i64, ptr %slot773, align 8
  %v4263 = load i64, ptr %slot37, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  store i64 %v4262, ptr %p4264, align 8, !alias.scope !3, !noalias !4
  %v4265 = load i64, ptr %slot37, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  %ld4267 = load i64, ptr %p4266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4267, ptr %slot774, align 8
  %v4268 = load i64, ptr %slot774, align 8
  %cond4269 = icmp ne i64 %v4268, 0
  br i1 %cond4269, label %bb_next1224, label %bb_i51
bb_next1224:
  %v4270 = load i64, ptr %slot37, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  store i64 0, ptr %p4271, align 8, !alias.scope !3, !noalias !4
  %v4272 = load i64, ptr %slot37, align 8
  %p4273 = inttoptr i64 %v4272 to ptr
  %ld4274 = load i64, ptr %p4273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4274, ptr %slot775, align 8
  %v4275 = load i64, ptr %slot20, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  %ld4277 = load i32, ptr %p4276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4277, ptr %slot776, align 8
  %v4278 = load i32, ptr %slot776, align 8
  %cv4279 = zext i32 %v4278 to i64
  %cond4280 = icmp ne i64 %cv4279, 0
  br i1 %cond4280, label %bb_rcslotdrop1227, label %bb_rcslotdone1227
bb_rcslotdrop1227:
  %v4281 = load i64, ptr %slot20, align 8
  %p4282 = inttoptr i64 %v4281 to ptr
  store i32 0, ptr %p4282, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1227
bb_rcslotdone1227:
  %v4283 = load i64, ptr %slot18, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  %ld4285 = load i32, ptr %p4284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4285, ptr %slot777, align 8
  %v4286 = load i32, ptr %slot777, align 8
  %cv4287 = zext i32 %v4286 to i64
  %cond4288 = icmp ne i64 %cv4287, 0
  br i1 %cond4288, label %bb_rcslotdrop1230, label %bb_rcslotdone1230
bb_rcslotdrop1230:
  %v4289 = load i64, ptr %slot18, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  store i32 0, ptr %p4290, align 4, !alias.scope !3, !noalias !4
  %v4291 = load i64, ptr %slot36, align 8
  store i64 %v4291, ptr %slot778, align 8
  %v4292 = load i64, ptr %slot19, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  %ld4294 = load i32, ptr %p4293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4294, ptr %slot779, align 8
  %v4295 = load i32, ptr %slot779, align 8
  %op4296 = and i32 %v4295, 28
  store i32 %op4296, ptr %slot780, align 8
  %v4297 = load i32, ptr %slot780, align 8
  %cv4298 = zext i32 %v4297 to i64
  %cond4299 = icmp ne i64 %cv4298, 0
  br i1 %cond4299, label %bb_rcslotrole1230, label %bb_rcslotowner1230
bb_rcslotrole1230:
  %v4300 = load i64, ptr %slot49, align 8
  store i64 %v4300, ptr %slot781, align 8
  %v4301 = load i64, ptr %slot781, align 8
  %v4302 = load i64, ptr %slot778, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4301, i64 %v4302) nomerge, !dbg !158
  br label %bb_rcslotdone1230
bb_rcslotowner1230:
  %v4303 = load i64, ptr %slot49, align 8
  store i64 %v4303, ptr %slot782, align 8
  %v4304 = load i64, ptr %slot782, align 8
  %v4305 = load i64, ptr %slot778, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4304, i64 %v4305) nomerge, !dbg !158
  br label %bb_rcslotdone1230
bb_rcslotdone1230:
  %v4306 = load i64, ptr %slot16, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  %ld4308 = load i32, ptr %p4307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4308, ptr %slot783, align 8
  %v4309 = load i32, ptr %slot783, align 8
  %cv4310 = zext i32 %v4309 to i64
  %cond4311 = icmp ne i64 %cv4310, 0
  br i1 %cond4311, label %bb_rcslotdrop1239, label %bb_rcslotdone1239
bb_rcslotdrop1239:
  %v4312 = load i64, ptr %slot16, align 8
  %p4313 = inttoptr i64 %v4312 to ptr
  store i32 0, ptr %p4313, align 4, !alias.scope !3, !noalias !4
  %v4314 = load i64, ptr %slot35, align 8
  store i64 %v4314, ptr %slot784, align 8
  %v4315 = load i64, ptr %slot17, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  %ld4317 = load i32, ptr %p4316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4317, ptr %slot785, align 8
  %v4318 = load i32, ptr %slot785, align 8
  %op4319 = and i32 %v4318, 28
  store i32 %op4319, ptr %slot786, align 8
  %v4320 = load i32, ptr %slot786, align 8
  %cv4321 = zext i32 %v4320 to i64
  %cond4322 = icmp ne i64 %cv4321, 0
  br i1 %cond4322, label %bb_rcslotrole1239, label %bb_rcslotowner1239
bb_rcslotrole1239:
  %v4323 = load i64, ptr %slot49, align 8
  store i64 %v4323, ptr %slot787, align 8
  %v4324 = load i64, ptr %slot787, align 8
  %v4325 = load i64, ptr %slot784, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4324, i64 %v4325) nomerge, !dbg !158
  br label %bb_rcslotdone1239
bb_rcslotowner1239:
  %v4326 = load i64, ptr %slot49, align 8
  store i64 %v4326, ptr %slot788, align 8
  %v4327 = load i64, ptr %slot788, align 8
  %v4328 = load i64, ptr %slot784, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4327, i64 %v4328) nomerge, !dbg !158
  br label %bb_rcslotdone1239
bb_rcslotdone1239:
  %v4329 = load i64, ptr %slot14, align 8
  %p4330 = inttoptr i64 %v4329 to ptr
  %ld4331 = load i32, ptr %p4330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4331, ptr %slot789, align 8
  %v4332 = load i32, ptr %slot789, align 8
  %cv4333 = zext i32 %v4332 to i64
  %cond4334 = icmp ne i64 %cv4333, 0
  br i1 %cond4334, label %bb_rcslotdrop1248, label %bb_rcslotdone1248
bb_rcslotdrop1248:
  %v4335 = load i64, ptr %slot14, align 8
  %p4336 = inttoptr i64 %v4335 to ptr
  store i32 0, ptr %p4336, align 4, !alias.scope !3, !noalias !4
  %v4337 = load i64, ptr %slot34, align 8
  store i64 %v4337, ptr %slot790, align 8
  %v4338 = load i64, ptr %slot15, align 8
  %p4339 = inttoptr i64 %v4338 to ptr
  %ld4340 = load i32, ptr %p4339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4340, ptr %slot791, align 8
  %v4341 = load i32, ptr %slot791, align 8
  %op4342 = and i32 %v4341, 28
  store i32 %op4342, ptr %slot792, align 8
  %v4343 = load i32, ptr %slot792, align 8
  %cv4344 = zext i32 %v4343 to i64
  %cond4345 = icmp ne i64 %cv4344, 0
  br i1 %cond4345, label %bb_rcslotrole1248, label %bb_rcslotowner1248
bb_rcslotrole1248:
  %v4346 = load i64, ptr %slot49, align 8
  store i64 %v4346, ptr %slot793, align 8
  %v4347 = load i64, ptr %slot793, align 8
  %v4348 = load i64, ptr %slot790, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4347, i64 %v4348) nomerge, !dbg !158
  br label %bb_rcslotdone1248
bb_rcslotowner1248:
  %v4349 = load i64, ptr %slot49, align 8
  store i64 %v4349, ptr %slot794, align 8
  %v4350 = load i64, ptr %slot794, align 8
  %v4351 = load i64, ptr %slot790, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4350, i64 %v4351) nomerge, !dbg !158
  br label %bb_rcslotdone1248
bb_rcslotdone1248:
  %v4352 = load i64, ptr %slot12, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  %ld4354 = load i32, ptr %p4353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4354, ptr %slot795, align 8
  %v4355 = load i32, ptr %slot795, align 8
  %cv4356 = zext i32 %v4355 to i64
  %cond4357 = icmp ne i64 %cv4356, 0
  br i1 %cond4357, label %bb_rcslotdrop1257, label %bb_rcslotdone1257
bb_rcslotdrop1257:
  %v4358 = load i64, ptr %slot12, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  store i32 0, ptr %p4359, align 4, !alias.scope !3, !noalias !4
  %v4360 = load i64, ptr %slot33, align 8
  store i64 %v4360, ptr %slot796, align 8
  %v4361 = load i64, ptr %slot13, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  %ld4363 = load i32, ptr %p4362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4363, ptr %slot797, align 8
  %v4364 = load i32, ptr %slot797, align 8
  %op4365 = and i32 %v4364, 28
  store i32 %op4365, ptr %slot798, align 8
  %v4366 = load i32, ptr %slot798, align 8
  %cv4367 = zext i32 %v4366 to i64
  %cond4368 = icmp ne i64 %cv4367, 0
  br i1 %cond4368, label %bb_rcslotrole1257, label %bb_rcslotowner1257
bb_rcslotrole1257:
  %v4369 = load i64, ptr %slot49, align 8
  store i64 %v4369, ptr %slot799, align 8
  %v4370 = load i64, ptr %slot799, align 8
  %v4371 = load i64, ptr %slot796, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4370, i64 %v4371) nomerge, !dbg !158
  br label %bb_rcslotdone1257
bb_rcslotowner1257:
  %v4372 = load i64, ptr %slot49, align 8
  store i64 %v4372, ptr %slot800, align 8
  %v4373 = load i64, ptr %slot800, align 8
  %v4374 = load i64, ptr %slot796, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4373, i64 %v4374) nomerge, !dbg !158
  br label %bb_rcslotdone1257
bb_rcslotdone1257:
  %v4375 = load i64, ptr %slot10, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  %ld4377 = load i32, ptr %p4376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4377, ptr %slot801, align 8
  %v4378 = load i32, ptr %slot801, align 8
  %cv4379 = zext i32 %v4378 to i64
  %cond4380 = icmp ne i64 %cv4379, 0
  br i1 %cond4380, label %bb_rcslotdrop1266, label %bb_rcslotdone1266
bb_rcslotdrop1266:
  %v4381 = load i64, ptr %slot10, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i32 0, ptr %p4382, align 4, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot32, align 8
  store i64 %v4383, ptr %slot802, align 8
  %v4384 = load i64, ptr %slot11, align 8
  %p4385 = inttoptr i64 %v4384 to ptr
  %ld4386 = load i32, ptr %p4385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4386, ptr %slot803, align 8
  %v4387 = load i32, ptr %slot803, align 8
  %op4388 = and i32 %v4387, 28
  store i32 %op4388, ptr %slot804, align 8
  %v4389 = load i32, ptr %slot804, align 8
  %cv4390 = zext i32 %v4389 to i64
  %cond4391 = icmp ne i64 %cv4390, 0
  br i1 %cond4391, label %bb_rcslotrole1266, label %bb_rcslotowner1266
bb_rcslotrole1266:
  %v4392 = load i64, ptr %slot49, align 8
  store i64 %v4392, ptr %slot805, align 8
  %v4393 = load i64, ptr %slot805, align 8
  %v4394 = load i64, ptr %slot802, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4393, i64 %v4394) nomerge, !dbg !158
  br label %bb_rcslotdone1266
bb_rcslotowner1266:
  %v4395 = load i64, ptr %slot49, align 8
  store i64 %v4395, ptr %slot806, align 8
  %v4396 = load i64, ptr %slot806, align 8
  %v4397 = load i64, ptr %slot802, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4396, i64 %v4397) nomerge, !dbg !158
  br label %bb_rcslotdone1266
bb_rcslotdone1266:
  %v4398 = load i64, ptr %slot8, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  %ld4400 = load i32, ptr %p4399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4400, ptr %slot807, align 8
  %v4401 = load i32, ptr %slot807, align 8
  %cv4402 = zext i32 %v4401 to i64
  %cond4403 = icmp ne i64 %cv4402, 0
  br i1 %cond4403, label %bb_rcslotdrop1275, label %bb_rcslotdone1275
bb_rcslotdrop1275:
  %v4404 = load i64, ptr %slot8, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  store i32 0, ptr %p4405, align 4, !alias.scope !3, !noalias !4
  %v4406 = load i64, ptr %slot31, align 8
  store i64 %v4406, ptr %slot808, align 8
  %v4407 = load i64, ptr %slot9, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  %ld4409 = load i32, ptr %p4408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4409, ptr %slot809, align 8
  %v4410 = load i32, ptr %slot809, align 8
  %op4411 = and i32 %v4410, 28
  store i32 %op4411, ptr %slot810, align 8
  %v4412 = load i32, ptr %slot810, align 8
  %cv4413 = zext i32 %v4412 to i64
  %cond4414 = icmp ne i64 %cv4413, 0
  br i1 %cond4414, label %bb_rcslotrole1275, label %bb_rcslotowner1275
bb_rcslotrole1275:
  %v4415 = load i64, ptr %slot49, align 8
  store i64 %v4415, ptr %slot811, align 8
  %v4416 = load i64, ptr %slot811, align 8
  %v4417 = load i64, ptr %slot808, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v4416, i64 %v4417) nomerge, !dbg !158
  br label %bb_rcslotdone1275
bb_rcslotowner1275:
  %v4418 = load i64, ptr %slot49, align 8
  store i64 %v4418, ptr %slot812, align 8
  %v4419 = load i64, ptr %slot812, align 8
  %v4420 = load i64, ptr %slot808, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v4419, i64 %v4420) nomerge, !dbg !158
  br label %bb_rcslotdone1275
bb_rcslotdone1275:
  %v4421 = load i64, ptr %slot6, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %ld4423 = load i32, ptr %p4422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4423, ptr %slot813, align 8
  %v4424 = load i32, ptr %slot813, align 8
  %cv4425 = zext i32 %v4424 to i64
  %cond4426 = icmp ne i64 %cv4425, 0
  br i1 %cond4426, label %bb_rcslotdrop1284, label %bb_rcslotdone1284
bb_rcslotdrop1284:
  %v4427 = load i64, ptr %slot6, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  store i32 0, ptr %p4428, align 4, !alias.scope !3, !noalias !4
  %v4429 = load i64, ptr %slot30, align 8
  store i64 %v4429, ptr %slot814, align 8
  %v4430 = load i64, ptr %slot7, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  %ld4432 = load i32, ptr %p4431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4432, ptr %slot815, align 8
  %v4433 = load i32, ptr %slot815, align 8
  %op4434 = and i32 %v4433, 28
  store i32 %op4434, ptr %slot816, align 8
  %v4435 = load i32, ptr %slot816, align 8
  %cv4436 = zext i32 %v4435 to i64
  %cond4437 = icmp ne i64 %cv4436, 0
  br i1 %cond4437, label %bb_rcslotrole1284, label %bb_rcslotowner1284
bb_rcslotrole1284:
  %v4438 = load i64, ptr %slot49, align 8
  store i64 %v4438, ptr %slot817, align 8
  %v4439 = load i64, ptr %slot817, align 8
  %v4440 = load i64, ptr %slot814, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4439, i64 %v4440) nomerge, !dbg !158
  br label %bb_rcslotdone1284
bb_rcslotowner1284:
  %v4441 = load i64, ptr %slot49, align 8
  store i64 %v4441, ptr %slot818, align 8
  %v4442 = load i64, ptr %slot818, align 8
  %v4443 = load i64, ptr %slot814, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4442, i64 %v4443) nomerge, !dbg !158
  br label %bb_rcslotdone1284
bb_rcslotdone1284:
  %v4444 = load i64, ptr %slot4, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %ld4446 = load i32, ptr %p4445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4446, ptr %slot819, align 8
  %v4447 = load i32, ptr %slot819, align 8
  %cv4448 = zext i32 %v4447 to i64
  %cond4449 = icmp ne i64 %cv4448, 0
  br i1 %cond4449, label %bb_rcslotdrop1293, label %bb_rcslotdone1293
bb_rcslotdrop1293:
  %v4450 = load i64, ptr %slot4, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  store i32 0, ptr %p4451, align 4, !alias.scope !3, !noalias !4
  %v4452 = load i64, ptr %slot29, align 8
  store i64 %v4452, ptr %slot820, align 8
  %v4453 = load i64, ptr %slot5, align 8
  %p4454 = inttoptr i64 %v4453 to ptr
  %ld4455 = load i32, ptr %p4454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4455, ptr %slot821, align 8
  %v4456 = load i32, ptr %slot821, align 8
  %op4457 = and i32 %v4456, 28
  store i32 %op4457, ptr %slot822, align 8
  %v4458 = load i32, ptr %slot822, align 8
  %cv4459 = zext i32 %v4458 to i64
  %cond4460 = icmp ne i64 %cv4459, 0
  br i1 %cond4460, label %bb_rcslotrole1293, label %bb_rcslotowner1293
bb_rcslotrole1293:
  %v4461 = load i64, ptr %slot49, align 8
  store i64 %v4461, ptr %slot823, align 8
  %v4462 = load i64, ptr %slot823, align 8
  %v4463 = load i64, ptr %slot820, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4462, i64 %v4463) nomerge, !dbg !158
  br label %bb_rcslotdone1293
bb_rcslotowner1293:
  %v4464 = load i64, ptr %slot49, align 8
  store i64 %v4464, ptr %slot824, align 8
  %v4465 = load i64, ptr %slot824, align 8
  %v4466 = load i64, ptr %slot820, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4465, i64 %v4466) nomerge, !dbg !158
  br label %bb_rcslotdone1293
bb_rcslotdone1293:
  %v4467 = load i64, ptr %slot775, align 8
  ret i64 %v4467
bb_i51:
  %v4468 = load i64, ptr %slot28, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %ld4470 = load i64, ptr %p4469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4470, ptr %slot825, align 8
  %v4471 = load i64, ptr %slot825, align 8
  %v4472 = load i64, ptr %slot37, align 8
  %p4473 = inttoptr i64 %v4472 to ptr
  store i64 %v4471, ptr %p4473, align 8, !alias.scope !3, !noalias !4
  %v4474 = load i64, ptr %slot28, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  %ld4476 = load i64, ptr %p4475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4476, ptr %slot826, align 8
  %v4477 = load i64, ptr %slot826, align 8
  %v4478 = load i64, ptr %slot44, align 8
  %p4479 = inttoptr i64 %v4477 to ptr
  %p4480 = inttoptr i64 %v4478 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4480, ptr %p4479, i64 392, i1 false), !alias.scope !10000000
  %v4481 = load i64, ptr %slot44, align 8
  %v4482 = load i64, ptr %slot38, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  store i64 %v4481, ptr %p4483, align 8, !alias.scope !3, !noalias !4
  %v4484 = load i64, ptr %slot38, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  %ld4486 = load i64, ptr %p4485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4486, ptr %slot827, align 8
  %v4487 = load i64, ptr %slot827, align 8
  %op4488 = add i64 %v4487, 288
  store i64 %op4488, ptr %slot828, align 8
  %v4489 = load i64, ptr %slot828, align 8
  %v4490 = load i64, ptr %slot38, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i64 %v4489, ptr %p4491, align 8, !alias.scope !3, !noalias !4
  %v4492 = load i64, ptr %slot38, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  %ld4494 = load i64, ptr %p4493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4494, ptr %slot829, align 8
  %v4495 = load i64, ptr %slot829, align 8
  %op4496 = add i64 %v4495, 32
  store i64 %op4496, ptr %slot830, align 8
  %v4497 = load i64, ptr %slot830, align 8
  %p4498 = inttoptr i64 %v4497 to ptr
  %ld4499 = load i64, ptr %p4498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4499, ptr %slot831, align 8
  %v4500 = load i64, ptr %slot831, align 8
  %v4501 = load i64, ptr %slot38, align 8
  %p4502 = inttoptr i64 %v4501 to ptr
  store i64 %v4500, ptr %p4502, align 8, !alias.scope !3, !noalias !4
  %v4503 = load i64, ptr %slot37, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  %ld4505 = load i64, ptr %p4504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4505, ptr %slot832, align 8
  %v4506 = load i64, ptr %slot38, align 8
  %p4507 = inttoptr i64 %v4506 to ptr
  %ld4508 = load i64, ptr %p4507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4508, ptr %slot833, align 8
  %v4509 = load i64, ptr %slot1, align 8
  %v4510 = load i64, ptr %slot832, align 8
  %v4511 = load i64, ptr %slot833, align 8
  %call4512 = call i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64 %v4509, i64 %v4510, i64 %v4511) nomerge, !dbg !160
  store i64 %call4512, ptr %slot834, align 8
  %v4513 = load i64, ptr %slot834, align 8
  %v4514 = load i64, ptr %slot37, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  store i64 %v4513, ptr %p4515, align 8, !alias.scope !3, !noalias !4
  %v4516 = load i64, ptr %slot20, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  %ld4518 = load i32, ptr %p4517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4518, ptr %slot835, align 8
  %v4519 = load i32, ptr %slot835, align 8
  %cv4520 = zext i32 %v4519 to i64
  %cond4521 = icmp ne i64 %cv4520, 0
  br i1 %cond4521, label %bb_rcslotdrop1339, label %bb_rcslotdone1339
bb_rcslotdrop1339:
  %v4522 = load i64, ptr %slot20, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  store i32 0, ptr %p4523, align 4, !alias.scope !3, !noalias !4
  %v4524 = load i64, ptr %slot26, align 8
  store i64 %v4524, ptr %slot836, align 8
  %v4525 = load i64, ptr %slot21, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %ld4527 = load i32, ptr %p4526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4527, ptr %slot837, align 8
  %v4528 = load i32, ptr %slot837, align 8
  %op4529 = and i32 %v4528, 28
  store i32 %op4529, ptr %slot838, align 8
  %v4530 = load i32, ptr %slot838, align 8
  %cv4531 = zext i32 %v4530 to i64
  %cond4532 = icmp ne i64 %cv4531, 0
  br i1 %cond4532, label %bb_rcslotrole1339, label %bb_rcslotowner1339
bb_rcslotrole1339:
  %v4533 = load i64, ptr %slot49, align 8
  store i64 %v4533, ptr %slot839, align 8
  %v4534 = load i64, ptr %slot839, align 8
  %v4535 = load i64, ptr %slot836, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4534, i64 %v4535) nomerge, !dbg !160
  br label %bb_rcslotdone1339
bb_rcslotowner1339:
  %v4536 = load i64, ptr %slot49, align 8
  store i64 %v4536, ptr %slot840, align 8
  %v4537 = load i64, ptr %slot840, align 8
  %v4538 = load i64, ptr %slot836, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4537, i64 %v4538) nomerge, !dbg !160
  br label %bb_rcslotdone1339
bb_rcslotdone1339:
  br label %bb_i13
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64, i64, i64)
declare void @myl_f_e4b0bf9563972641903c91a76184ac78f1f83b05bb4beab9462ad6bdca4a1ea9(ptr sret([40 x i8]) align 8, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_loan(i64, i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_loan(i64, i64, i64)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_take(i64, i64, i64, i32)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf", linkageName: "myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14832311236853698551, i64 0, !"myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!128 = !DILocation(line: 16, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!132 = !DILocation(line: 19, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!134 = !DILocation(line: 21, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!136 = !DILocation(line: 23, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!138 = !DILocation(line: 25, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!140 = !DILocation(line: 28, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!142 = !DILocation(line: 29, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!144 = !DILocation(line: 33, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!146 = !DILocation(line: 35, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!148 = !DILocation(line: 37, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!150 = !DILocation(line: 40, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!152 = !DILocation(line: 41, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!154 = !DILocation(line: 45, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!156 = !DILocation(line: 46, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!158 = !DILocation(line: 51, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!160 = !DILocation(line: 56, column: 0, scope: !161)
