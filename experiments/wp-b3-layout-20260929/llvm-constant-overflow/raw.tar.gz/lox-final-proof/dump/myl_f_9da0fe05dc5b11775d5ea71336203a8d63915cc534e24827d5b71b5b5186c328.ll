target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v633 = load i64, ptr %slot1, align 8
  %op634 = add i64 %v633, 32
  store i64 %op634, ptr %slot5, align 8
  %mem635 = alloca i8, i64 8, align 8
  %ptr636 = ptrtoint ptr %mem635 to i64
  store i64 %ptr636, ptr %slot6, align 8
  %mem637 = alloca i8, i64 8, align 8
  %ptr638 = ptrtoint ptr %mem637 to i64
  store i64 %ptr638, ptr %slot7, align 8
  %mem639 = alloca i8, i64 8, align 8
  %ptr640 = ptrtoint ptr %mem639 to i64
  store i64 %ptr640, ptr %slot8, align 8
  %mem641 = alloca i8, i64 8, align 8
  %ptr642 = ptrtoint ptr %mem641 to i64
  store i64 %ptr642, ptr %slot9, align 8
  %mem643 = alloca i8, i64 8, align 8
  %ptr644 = ptrtoint ptr %mem643 to i64
  store i64 %ptr644, ptr %slot10, align 8
  %mem645 = alloca i8, i64 8, align 8
  %ptr646 = ptrtoint ptr %mem645 to i64
  store i64 %ptr646, ptr %slot11, align 8
  %mem647 = alloca i8, i64 8, align 8
  %ptr648 = ptrtoint ptr %mem647 to i64
  store i64 %ptr648, ptr %slot12, align 8
  %mem649 = alloca i8, i64 8, align 8
  %ptr650 = ptrtoint ptr %mem649 to i64
  store i64 %ptr650, ptr %slot13, align 8
  %mem651 = alloca i8, i64 8, align 8
  %ptr652 = ptrtoint ptr %mem651 to i64
  store i64 %ptr652, ptr %slot14, align 8
  %mem653 = alloca i8, i64 392, align 8
  %ptr654 = ptrtoint ptr %mem653 to i64
  store i64 %ptr654, ptr %slot15, align 8
  %mem655 = alloca i8, i64 88, align 8
  %ptr656 = ptrtoint ptr %mem655 to i64
  store i64 %ptr656, ptr %slot16, align 8
  %mem657 = alloca i8, i64 8, align 8
  %ptr658 = ptrtoint ptr %mem657 to i64
  store i64 %ptr658, ptr %slot17, align 8
  %mem659 = alloca i8, i64 392, align 8
  %ptr660 = ptrtoint ptr %mem659 to i64
  store i64 %ptr660, ptr %slot18, align 8
  %mem661 = alloca i8, i64 32, align 8
  %ptr662 = ptrtoint ptr %mem661 to i64
  store i64 %ptr662, ptr %slot19, align 8
  %v663 = load i64, ptr %slot19, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %gep666 = getelementptr i8, ptr %p665, i64 24
  %op664 = ptrtoint ptr %gep666 to i64
  store i64 %op664, ptr %slot20, align 8
  %v667 = load i64, ptr %slot20, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 0, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %mem669 = alloca i8, i64 32, align 8
  %ptr670 = ptrtoint ptr %mem669 to i64
  store i64 %ptr670, ptr %slot21, align 8
  %v671 = load i64, ptr %slot21, align 8
  %p673 = inttoptr i64 %v671 to ptr
  %gep674 = getelementptr i8, ptr %p673, i64 24
  %op672 = ptrtoint ptr %gep674 to i64
  store i64 %op672, ptr %slot22, align 8
  %v675 = load i64, ptr %slot22, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i64 0, ptr %p676, align 8, !alias.scope !3, !noalias !4
  %mem677 = alloca i8, i64 16, align 8
  %ptr678 = ptrtoint ptr %mem677 to i64
  store i64 %ptr678, ptr %slot23, align 8
  %mem679 = alloca i8, i64 8, align 8
  %ptr680 = ptrtoint ptr %mem679 to i64
  store i64 %ptr680, ptr %slot24, align 8
  %mem681 = alloca i8, i64 8, align 8
  %ptr682 = ptrtoint ptr %mem681 to i64
  store i64 %ptr682, ptr %slot25, align 8
  %mem683 = alloca i8, i64 8, align 8
  %ptr684 = ptrtoint ptr %mem683 to i64
  store i64 %ptr684, ptr %slot26, align 8
  %mem685 = alloca i8, i64 8, align 8
  %ptr686 = ptrtoint ptr %mem685 to i64
  store i64 %ptr686, ptr %slot27, align 8
  %mem687 = alloca i8, i64 88, align 8
  %ptr688 = ptrtoint ptr %mem687 to i64
  store i64 %ptr688, ptr %slot28, align 8
  %mem689 = alloca i8, i64 8, align 8
  %ptr690 = ptrtoint ptr %mem689 to i64
  store i64 %ptr690, ptr %slot29, align 8
  %mem691 = alloca i8, i64 8, align 8
  %ptr692 = ptrtoint ptr %mem691 to i64
  store i64 %ptr692, ptr %slot30, align 8
  %mem693 = alloca i8, i64 56, align 8
  %ptr694 = ptrtoint ptr %mem693 to i64
  store i64 %ptr694, ptr %slot31, align 8
  %mem695 = alloca i8, i64 8, align 8
  %ptr696 = ptrtoint ptr %mem695 to i64
  store i64 %ptr696, ptr %slot32, align 8
  %mem697 = alloca i8, i64 8, align 8
  %ptr698 = ptrtoint ptr %mem697 to i64
  store i64 %ptr698, ptr %slot33, align 8
  %mem699 = alloca i8, i64 8, align 8
  %ptr700 = ptrtoint ptr %mem699 to i64
  store i64 %ptr700, ptr %slot34, align 8
  %mem701 = alloca i8, i64 56, align 8
  %ptr702 = ptrtoint ptr %mem701 to i64
  store i64 %ptr702, ptr %slot35, align 8
  %mem703 = alloca i8, i64 56, align 8
  %ptr704 = ptrtoint ptr %mem703 to i64
  store i64 %ptr704, ptr %slot36, align 8
  %v705 = load i64, ptr %slot27, align 8
  %p706 = inttoptr i64 %v705 to ptr
  store i64 0, ptr %p706, align 8, !alias.scope !3, !noalias !4
  %v707 = load i64, ptr %slot30, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i64 0, ptr %p708, align 8, !alias.scope !3, !noalias !4
  %v709 = load i64, ptr %slot2, align 8
  %v710 = load i64, ptr %slot24, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 %v709, ptr %p711, align 8, !alias.scope !3, !noalias !4
  %v712 = load i64, ptr %slot3, align 8
  %v713 = load i64, ptr %slot25, align 8
  %p714 = inttoptr i64 %v713 to ptr
  store i64 %v712, ptr %p714, align 8, !alias.scope !3, !noalias !4
  %v715 = load i64, ptr %slot4, align 8
  %v716 = load i64, ptr %slot26, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i64 %v715, ptr %p717, align 8, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot1, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %call720 = call ptr @myl_qbe_heap(ptr %p719) nomerge, !dbg !110
  %calladdr721 = ptrtoint ptr %call720 to i64
  store i64 %calladdr721, ptr %slot37, align 8
  %v722 = load i64, ptr %slot1, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %call724 = call i64 @myl_qbe_region_mark(ptr %p723) nomerge, !dbg !110
  store i64 %call724, ptr %slot38, align 8
  %v725 = load i64, ptr %slot6, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 0, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot7, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 0, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot8, align 8
  %p730 = inttoptr i64 %v729 to ptr
  store i32 0, ptr %p730, align 4, !alias.scope !3, !noalias !4
  %v731 = load i64, ptr %slot9, align 8
  %p732 = inttoptr i64 %v731 to ptr
  store i32 0, ptr %p732, align 4, !alias.scope !3, !noalias !4
  %v733 = load i64, ptr %slot10, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i32 0, ptr %p734, align 4, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot11, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i32 0, ptr %p736, align 4, !alias.scope !3, !noalias !4
  %v737 = load i64, ptr %slot12, align 8
  %p738 = inttoptr i64 %v737 to ptr
  store i32 0, ptr %p738, align 4, !alias.scope !3, !noalias !4
  %v739 = load i64, ptr %slot13, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i32 0, ptr %p740, align 4, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot14, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i32 0, ptr %p742, align 4, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot7, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i32 2, ptr %p744, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v745 = load i64, ptr %slot26, align 8
  %p746 = inttoptr i64 %v745 to ptr
  %ld747 = load i64, ptr %p746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld747, ptr %slot39, align 8
  %v748 = load i64, ptr %slot39, align 8
  %v749 = load i64, ptr %slot33, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 %v748, ptr %p750, align 8, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot33, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i64, ptr %p752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld753, ptr %slot40, align 8
  %v754 = load i64, ptr %slot40, align 8
  %v755 = load i64, ptr %slot28, align 8
  %p756 = inttoptr i64 %v754 to ptr
  %p757 = inttoptr i64 %v755 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p757, ptr %p756, i64 88, i1 false), !alias.scope !10000000
  %v758 = load i64, ptr %slot24, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %ld760 = load i64, ptr %p759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld760, ptr %slot41, align 8
  %v761 = load i64, ptr %slot41, align 8
  %v762 = load i64, ptr %slot33, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 %v761, ptr %p763, align 8, !alias.scope !3, !noalias !4
  %v764 = load i64, ptr %slot33, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %ld766 = load i64, ptr %p765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld766, ptr %slot42, align 8
  %v767 = load i64, ptr %slot42, align 8
  %op768 = add i64 %v767, 376
  store i64 %op768, ptr %slot43, align 8
  %v769 = load i64, ptr %slot43, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i64, ptr %p770, align 8, !alias.scope !4, !noalias !3
  store i64 %ld771, ptr %slot44, align 8
  %v772 = load i64, ptr %slot44, align 8
  %v773 = load i64, ptr %slot33, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i64 %v772, ptr %p774, align 8, !alias.scope !3, !noalias !4
  %v775 = load i64, ptr %slot8, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %ld777 = load i32, ptr %p776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld777, ptr %slot45, align 8
  %v778 = load i32, ptr %slot45, align 8
  %cv779 = zext i32 %v778 to i64
  %cond780 = icmp ne i64 %cv779, 0
  br i1 %cond780, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v781 = load i64, ptr %slot8, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i32 0, ptr %p782, align 4, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot15, align 8
  store i64 %v783, ptr %slot46, align 8
  %v784 = load i64, ptr %slot9, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %ld786 = load i32, ptr %p785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld786, ptr %slot47, align 8
  %v787 = load i32, ptr %slot47, align 8
  %op788 = and i32 %v787, 28
  store i32 %op788, ptr %slot48, align 8
  %v789 = load i32, ptr %slot48, align 8
  %cv790 = zext i32 %v789 to i64
  %cond791 = icmp ne i64 %cv790, 0
  br i1 %cond791, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v792 = load i64, ptr %slot37, align 8
  store i64 %v792, ptr %slot49, align 8
  %v793 = load i64, ptr %slot49, align 8
  %v794 = load i64, ptr %slot46, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v793, i64 %v794) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v795 = load i64, ptr %slot37, align 8
  store i64 %v795, ptr %slot50, align 8
  %v796 = load i64, ptr %slot50, align 8
  %v797 = load i64, ptr %slot46, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v796, i64 %v797) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v798 = load i64, ptr %slot33, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld800, ptr %slot51, align 8
  %v801 = load i64, ptr %slot24, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %ld803 = load i64, ptr %p802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld803, ptr %slot52, align 8
  %v804 = load i64, ptr %slot8, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i32, ptr %p805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld806, ptr %slot53, align 8
  %v807 = load i32, ptr %slot53, align 8
  %cv808 = zext i32 %v807 to i64
  %cond809 = icmp ne i64 %cv808, 0
  br i1 %cond809, label %bb_rcslotdrop27, label %bb_rcslotdone27
bb_rcslotdrop27:
  %v810 = load i64, ptr %slot8, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 0, ptr %p811, align 4, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot15, align 8
  store i64 %v812, ptr %slot54, align 8
  %v813 = load i64, ptr %slot9, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i32, ptr %p814, align 4, !alias.scope !3, !noalias !4
  store i32 %ld815, ptr %slot55, align 8
  %v816 = load i32, ptr %slot55, align 8
  %op817 = and i32 %v816, 28
  store i32 %op817, ptr %slot56, align 8
  %v818 = load i32, ptr %slot56, align 8
  %cv819 = zext i32 %v818 to i64
  %cond820 = icmp ne i64 %cv819, 0
  br i1 %cond820, label %bb_rcslotrole27, label %bb_rcslotowner27
bb_rcslotrole27:
  %v821 = load i64, ptr %slot37, align 8
  store i64 %v821, ptr %slot57, align 8
  %v822 = load i64, ptr %slot54, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot58, align 8
  %v825 = load i64, ptr %slot58, align 8
  %cmp826 = icmp ne i64 %v825, 0
  %cv827 = zext i1 %cmp826 to i32
  store i32 %cv827, ptr %slot59, align 8
  %v828 = load i32, ptr %slot59, align 8
  %cv829 = zext i32 %v828 to i64
  %cond830 = icmp ne i64 %cv829, 0
  br i1 %cond830, label %bb_rcgnn43, label %bb_rcgdone43
bb_rcgnn43:
  %v831 = load i64, ptr %slot58, align 8
  %op832 = sub i64 %v831, 16
  store i64 %op832, ptr %slot60, align 8
  %v833 = load i64, ptr %slot58, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %rgep835 = getelementptr i8, ptr %p834, i64 -16
  %ld836 = load i64, ptr %rgep835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld836, ptr %slot61, align 8
  %v837 = load i64, ptr %slot61, align 8
  %op838 = and i64 %v837, 4611686018427387906
  store i64 %op838, ptr %slot62, align 8
  %v839 = load i64, ptr %slot62, align 8
  %cmp840 = icmp ne i64 %v839, 0
  %cv841 = zext i1 %cmp840 to i32
  store i32 %cv841, ptr %slot63, align 8
  %v842 = load i32, ptr %slot63, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcgclear43, label %bb_rcgcounted43
bb_rcgcounted43:
  %v845 = load i64, ptr %slot58, align 8
  %op846 = sub i64 %v845, 24
  store i64 %op846, ptr %slot64, align 8
  %v847 = load i64, ptr %slot58, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %rgep849 = getelementptr i8, ptr %p848, i64 -24
  %ld850 = load i64, ptr %rgep849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld850, ptr %slot65, align 8
  %v851 = load i64, ptr %slot65, align 8
  %op852 = sub i64 %v851, 1
  store i64 %op852, ptr %slot66, align 8
  %v853 = load i64, ptr %slot66, align 8
  %cmp854 = icmp eq i64 %v853, 0
  %cv855 = zext i1 %cmp854 to i32
  store i32 %cv855, ptr %slot67, align 8
  %v856 = load i32, ptr %slot67, align 8
  %cv857 = zext i32 %v856 to i64
  %cond858 = icmp ne i64 %cv857, 0
  br i1 %cond858, label %bb_rcglast43, label %bb_rcgdec43
bb_rcglast43:
  %v859 = load i64, ptr %slot58, align 8
  %op860 = sub i64 %v859, 32
  store i64 %op860, ptr %slot68, align 8
  %v861 = load i64, ptr %slot58, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %rgep863 = getelementptr i8, ptr %p862, i64 -32
  %ld864 = load i64, ptr %rgep863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld864, ptr %slot69, align 8
  %v865 = load i64, ptr %slot69, align 8
  %cmp866 = icmp ne i64 %v865, 0
  %cv867 = zext i1 %cmp866 to i32
  store i32 %cv867, ptr %slot70, align 8
  %v868 = load i32, ptr %slot70, align 8
  %cv869 = zext i32 %v868 to i64
  %cond870 = icmp ne i64 %cv869, 0
  br i1 %cond870, label %bb_rcgdec43, label %bb_rcgslow43
bb_rcgslow43:
  %v871 = load i64, ptr %slot57, align 8
  %v872 = load i64, ptr %slot54, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v871, i64 %v872) nomerge, !dbg !114
  br label %bb_rcgdone43
bb_rcgdec43:
  %v873 = load i64, ptr %slot66, align 8
  %v874 = load i64, ptr %slot58, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %rgep876 = getelementptr i8, ptr %p875, i64 -24
  store i64 %v873, ptr %rgep876, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear43
bb_rcgclear43:
  %v877 = load i64, ptr %slot54, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 0, ptr %p878, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone43
bb_rcgdone43:
  br label %bb_rcslotdone27
bb_rcslotowner27:
  %v879 = load i64, ptr %slot37, align 8
  store i64 %v879, ptr %slot71, align 8
  %v880 = load i64, ptr %slot54, align 8
  %p881 = inttoptr i64 %v880 to ptr
  %ld882 = load i64, ptr %p881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld882, ptr %slot72, align 8
  %v883 = load i64, ptr %slot72, align 8
  %cmp884 = icmp ne i64 %v883, 0
  %cv885 = zext i1 %cmp884 to i32
  store i32 %cv885, ptr %slot73, align 8
  %v886 = load i32, ptr %slot73, align 8
  %cv887 = zext i32 %v886 to i64
  %cond888 = icmp ne i64 %cv887, 0
  br i1 %cond888, label %bb_rcgnn58, label %bb_rcgdone58
bb_rcgnn58:
  %v889 = load i64, ptr %slot72, align 8
  %op890 = sub i64 %v889, 16
  store i64 %op890, ptr %slot74, align 8
  %v891 = load i64, ptr %slot72, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %rgep893 = getelementptr i8, ptr %p892, i64 -16
  %ld894 = load i64, ptr %rgep893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld894, ptr %slot75, align 8
  %v895 = load i64, ptr %slot75, align 8
  %op896 = and i64 %v895, 4611686018427387906
  store i64 %op896, ptr %slot76, align 8
  %v897 = load i64, ptr %slot76, align 8
  %cmp898 = icmp ne i64 %v897, 0
  %cv899 = zext i1 %cmp898 to i32
  store i32 %cv899, ptr %slot77, align 8
  %v900 = load i32, ptr %slot77, align 8
  %cv901 = zext i32 %v900 to i64
  %cond902 = icmp ne i64 %cv901, 0
  br i1 %cond902, label %bb_rcgclear58, label %bb_rcgcounted58
bb_rcgcounted58:
  %v903 = load i64, ptr %slot72, align 8
  %op904 = sub i64 %v903, 32
  store i64 %op904, ptr %slot78, align 8
  %v905 = load i64, ptr %slot72, align 8
  %p906 = inttoptr i64 %v905 to ptr
  %rgep907 = getelementptr i8, ptr %p906, i64 -32
  %ld908 = load i64, ptr %rgep907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld908, ptr %slot79, align 8
  %v909 = load i64, ptr %slot79, align 8
  %op910 = sub i64 %v909, 1
  store i64 %op910, ptr %slot80, align 8
  %v911 = load i64, ptr %slot80, align 8
  %cmp912 = icmp eq i64 %v911, 0
  %cv913 = zext i1 %cmp912 to i32
  store i32 %cv913, ptr %slot81, align 8
  %v914 = load i32, ptr %slot81, align 8
  %cv915 = zext i32 %v914 to i64
  %cond916 = icmp ne i64 %cv915, 0
  br i1 %cond916, label %bb_rcglast58, label %bb_rcgdec58
bb_rcglast58:
  %v917 = load i64, ptr %slot72, align 8
  %op918 = sub i64 %v917, 24
  store i64 %op918, ptr %slot82, align 8
  %v919 = load i64, ptr %slot72, align 8
  %p920 = inttoptr i64 %v919 to ptr
  %rgep921 = getelementptr i8, ptr %p920, i64 -24
  %ld922 = load i64, ptr %rgep921, align 8, !alias.scope !9, !noalias !10
  store i64 %ld922, ptr %slot83, align 8
  %v923 = load i64, ptr %slot83, align 8
  %cmp924 = icmp ne i64 %v923, 0
  %cv925 = zext i1 %cmp924 to i32
  store i32 %cv925, ptr %slot84, align 8
  %v926 = load i32, ptr %slot84, align 8
  %cv927 = zext i32 %v926 to i64
  %cond928 = icmp ne i64 %cv927, 0
  br i1 %cond928, label %bb_rcgdec58, label %bb_rcgslow58
bb_rcgslow58:
  %v929 = load i64, ptr %slot71, align 8
  %v930 = load i64, ptr %slot54, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v929, i64 %v930) nomerge, !dbg !114
  br label %bb_rcgdone58
bb_rcgdec58:
  %v931 = load i64, ptr %slot80, align 8
  %v932 = load i64, ptr %slot72, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %rgep934 = getelementptr i8, ptr %p933, i64 -32
  store i64 %v931, ptr %rgep934, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear58
bb_rcgclear58:
  %v935 = load i64, ptr %slot54, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i64 0, ptr %p936, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone58
bb_rcgdone58:
  br label %bb_rcslotdone27
bb_rcslotdone27:
  %v937 = load i64, ptr %slot52, align 8
  %op938 = add i64 %v937, 376
  store i64 %op938, ptr %slot85, align 8
  store i64 0, ptr %slot86, align 8
  %v939 = load i64, ptr %slot85, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %ld941 = load i64, ptr %p940, align 8, !alias.scope !4, !noalias !3
  store i64 %ld941, ptr %slot87, align 8
  %v942 = load i64, ptr %slot87, align 8
  %cmp943 = icmp ne i64 %v942, 0
  %cv944 = zext i1 %cmp943 to i32
  store i32 %cv944, ptr %slot88, align 8
  %v945 = load i32, ptr %slot88, align 8
  %cv946 = zext i32 %v945 to i64
  %cond947 = icmp ne i64 %cv946, 0
  br i1 %cond947, label %bb_rcguniquenn64, label %bb_rcgunique64
bb_rcguniquenn64:
  %v948 = load i64, ptr %slot87, align 8
  %op949 = sub i64 %v948, 16
  store i64 %op949, ptr %slot89, align 8
  %v950 = load i64, ptr %slot87, align 8
  %p951 = inttoptr i64 %v950 to ptr
  %rgep952 = getelementptr i8, ptr %p951, i64 -16
  %ld953 = load i64, ptr %rgep952, align 8, !alias.scope !9, !noalias !10
  store i64 %ld953, ptr %slot90, align 8
  %v954 = load i64, ptr %slot90, align 8
  %op955 = and i64 %v954, 6917529027641081858
  store i64 %op955, ptr %slot91, align 8
  %v956 = load i64, ptr %slot91, align 8
  %cmp957 = icmp ne i64 %v956, 0
  %cv958 = zext i1 %cmp957 to i32
  store i32 %cv958, ptr %slot92, align 8
  %v959 = load i32, ptr %slot92, align 8
  %cv960 = zext i32 %v959 to i64
  %cond961 = icmp ne i64 %cv960, 0
  br i1 %cond961, label %bb_rcguniqueslow64, label %bb_rcguniquecount64
bb_rcguniquecount64:
  %v962 = load i64, ptr %slot87, align 8
  %op963 = sub i64 %v962, 32
  store i64 %op963, ptr %slot93, align 8
  %v964 = load i64, ptr %slot87, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %rgep966 = getelementptr i8, ptr %p965, i64 -32
  %ld967 = load i64, ptr %rgep966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld967, ptr %slot94, align 8
  %v968 = load i64, ptr %slot94, align 8
  %cmp969 = icmp ult i64 %v968, 2
  %cv970 = zext i1 %cmp969 to i32
  store i32 %cv970, ptr %slot95, align 8
  %v971 = load i32, ptr %slot95, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcgunique64, label %bb_rcguniqueslow64
bb_rcguniqueslow64:
  %v974 = load i64, ptr %slot1, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %p976 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v977 = load i64, ptr %slot85, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %v979 = load i64, ptr %slot86, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %call981 = call i32 @myl_qbe_rc_unique_field(ptr %p975, ptr %p976, ptr %p978, ptr %p980) nomerge, !dbg !114
  store i32 %call981, ptr %slot96, align 8
  %v982 = load i32, ptr %slot96, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcunique74, label %bb_failure
bb_rcunique74:
  br label %bb_rcgunique64
bb_rcgunique64:
  %v985 = load i64, ptr %slot85, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %ld987 = load i64, ptr %p986, align 8, !alias.scope !4, !noalias !3
  store i64 %ld987, ptr %slot97, align 8
  %v988 = load i64, ptr %slot97, align 8
  %v989 = load i64, ptr %slot33, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 %v988, ptr %p990, align 8, !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot33, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i64, ptr %p992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld993, ptr %slot98, align 8
  %v994 = load i64, ptr %slot8, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i32, ptr %p995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld996, ptr %slot99, align 8
  %v997 = load i32, ptr %slot99, align 8
  %cv998 = zext i32 %v997 to i64
  %cond999 = icmp ne i64 %cv998, 0
  br i1 %cond999, label %bb_rcslotdrop79, label %bb_rcslotdone79
bb_rcslotdrop79:
  %v1000 = load i64, ptr %slot8, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  store i32 0, ptr %p1001, align 4, !alias.scope !3, !noalias !4
  %v1002 = load i64, ptr %slot15, align 8
  store i64 %v1002, ptr %slot100, align 8
  %v1003 = load i64, ptr %slot9, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i32, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1005, ptr %slot101, align 8
  %v1006 = load i32, ptr %slot101, align 8
  %op1007 = and i32 %v1006, 28
  store i32 %op1007, ptr %slot102, align 8
  %v1008 = load i32, ptr %slot102, align 8
  %cv1009 = zext i32 %v1008 to i64
  %cond1010 = icmp ne i64 %cv1009, 0
  br i1 %cond1010, label %bb_rcslotrole79, label %bb_rcslotowner79
bb_rcslotrole79:
  %v1011 = load i64, ptr %slot37, align 8
  store i64 %v1011, ptr %slot103, align 8
  %v1012 = load i64, ptr %slot100, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %ld1014 = load i64, ptr %p1013, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1014, ptr %slot104, align 8
  %v1015 = load i64, ptr %slot104, align 8
  %cmp1016 = icmp ne i64 %v1015, 0
  %cv1017 = zext i1 %cmp1016 to i32
  store i32 %cv1017, ptr %slot105, align 8
  %v1018 = load i32, ptr %slot105, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcgnn95, label %bb_rcgdone95
bb_rcgnn95:
  %v1021 = load i64, ptr %slot104, align 8
  %op1022 = sub i64 %v1021, 16
  store i64 %op1022, ptr %slot106, align 8
  %v1023 = load i64, ptr %slot104, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %rgep1025 = getelementptr i8, ptr %p1024, i64 -16
  %ld1026 = load i64, ptr %rgep1025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1026, ptr %slot107, align 8
  %v1027 = load i64, ptr %slot107, align 8
  %op1028 = and i64 %v1027, 4611686018427387906
  store i64 %op1028, ptr %slot108, align 8
  %v1029 = load i64, ptr %slot108, align 8
  %cmp1030 = icmp ne i64 %v1029, 0
  %cv1031 = zext i1 %cmp1030 to i32
  store i32 %cv1031, ptr %slot109, align 8
  %v1032 = load i32, ptr %slot109, align 8
  %cv1033 = zext i32 %v1032 to i64
  %cond1034 = icmp ne i64 %cv1033, 0
  br i1 %cond1034, label %bb_rcgclear95, label %bb_rcgcounted95
bb_rcgcounted95:
  %v1035 = load i64, ptr %slot104, align 8
  %op1036 = sub i64 %v1035, 24
  store i64 %op1036, ptr %slot110, align 8
  %v1037 = load i64, ptr %slot104, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  %rgep1039 = getelementptr i8, ptr %p1038, i64 -24
  %ld1040 = load i64, ptr %rgep1039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1040, ptr %slot111, align 8
  %v1041 = load i64, ptr %slot111, align 8
  %op1042 = sub i64 %v1041, 1
  store i64 %op1042, ptr %slot112, align 8
  %v1043 = load i64, ptr %slot112, align 8
  %cmp1044 = icmp eq i64 %v1043, 0
  %cv1045 = zext i1 %cmp1044 to i32
  store i32 %cv1045, ptr %slot113, align 8
  %v1046 = load i32, ptr %slot113, align 8
  %cv1047 = zext i32 %v1046 to i64
  %cond1048 = icmp ne i64 %cv1047, 0
  br i1 %cond1048, label %bb_rcglast95, label %bb_rcgdec95
bb_rcglast95:
  %v1049 = load i64, ptr %slot104, align 8
  %op1050 = sub i64 %v1049, 32
  store i64 %op1050, ptr %slot114, align 8
  %v1051 = load i64, ptr %slot104, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  %rgep1053 = getelementptr i8, ptr %p1052, i64 -32
  %ld1054 = load i64, ptr %rgep1053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1054, ptr %slot115, align 8
  %v1055 = load i64, ptr %slot115, align 8
  %cmp1056 = icmp ne i64 %v1055, 0
  %cv1057 = zext i1 %cmp1056 to i32
  store i32 %cv1057, ptr %slot116, align 8
  %v1058 = load i32, ptr %slot116, align 8
  %cv1059 = zext i32 %v1058 to i64
  %cond1060 = icmp ne i64 %cv1059, 0
  br i1 %cond1060, label %bb_rcgdec95, label %bb_rcgslow95
bb_rcgslow95:
  %v1061 = load i64, ptr %slot103, align 8
  %v1062 = load i64, ptr %slot100, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v1061, i64 %v1062) nomerge, !dbg !114
  br label %bb_rcgdone95
bb_rcgdec95:
  %v1063 = load i64, ptr %slot112, align 8
  %v1064 = load i64, ptr %slot104, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %rgep1066 = getelementptr i8, ptr %p1065, i64 -24
  store i64 %v1063, ptr %rgep1066, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear95
bb_rcgclear95:
  %v1067 = load i64, ptr %slot100, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i64 0, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone95
bb_rcgdone95:
  br label %bb_rcslotdone79
bb_rcslotowner79:
  %v1069 = load i64, ptr %slot37, align 8
  store i64 %v1069, ptr %slot117, align 8
  %v1070 = load i64, ptr %slot100, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %ld1072 = load i64, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1072, ptr %slot118, align 8
  %v1073 = load i64, ptr %slot118, align 8
  %cmp1074 = icmp ne i64 %v1073, 0
  %cv1075 = zext i1 %cmp1074 to i32
  store i32 %cv1075, ptr %slot119, align 8
  %v1076 = load i32, ptr %slot119, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcgnn110, label %bb_rcgdone110
bb_rcgnn110:
  %v1079 = load i64, ptr %slot118, align 8
  %op1080 = sub i64 %v1079, 16
  store i64 %op1080, ptr %slot120, align 8
  %v1081 = load i64, ptr %slot118, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %rgep1083 = getelementptr i8, ptr %p1082, i64 -16
  %ld1084 = load i64, ptr %rgep1083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1084, ptr %slot121, align 8
  %v1085 = load i64, ptr %slot121, align 8
  %op1086 = and i64 %v1085, 4611686018427387906
  store i64 %op1086, ptr %slot122, align 8
  %v1087 = load i64, ptr %slot122, align 8
  %cmp1088 = icmp ne i64 %v1087, 0
  %cv1089 = zext i1 %cmp1088 to i32
  store i32 %cv1089, ptr %slot123, align 8
  %v1090 = load i32, ptr %slot123, align 8
  %cv1091 = zext i32 %v1090 to i64
  %cond1092 = icmp ne i64 %cv1091, 0
  br i1 %cond1092, label %bb_rcgclear110, label %bb_rcgcounted110
bb_rcgcounted110:
  %v1093 = load i64, ptr %slot118, align 8
  %op1094 = sub i64 %v1093, 32
  store i64 %op1094, ptr %slot124, align 8
  %v1095 = load i64, ptr %slot118, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %rgep1097 = getelementptr i8, ptr %p1096, i64 -32
  %ld1098 = load i64, ptr %rgep1097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1098, ptr %slot125, align 8
  %v1099 = load i64, ptr %slot125, align 8
  %op1100 = sub i64 %v1099, 1
  store i64 %op1100, ptr %slot126, align 8
  %v1101 = load i64, ptr %slot126, align 8
  %cmp1102 = icmp eq i64 %v1101, 0
  %cv1103 = zext i1 %cmp1102 to i32
  store i32 %cv1103, ptr %slot127, align 8
  %v1104 = load i32, ptr %slot127, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcglast110, label %bb_rcgdec110
bb_rcglast110:
  %v1107 = load i64, ptr %slot118, align 8
  %op1108 = sub i64 %v1107, 24
  store i64 %op1108, ptr %slot128, align 8
  %v1109 = load i64, ptr %slot118, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  %rgep1111 = getelementptr i8, ptr %p1110, i64 -24
  %ld1112 = load i64, ptr %rgep1111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1112, ptr %slot129, align 8
  %v1113 = load i64, ptr %slot129, align 8
  %cmp1114 = icmp ne i64 %v1113, 0
  %cv1115 = zext i1 %cmp1114 to i32
  store i32 %cv1115, ptr %slot130, align 8
  %v1116 = load i32, ptr %slot130, align 8
  %cv1117 = zext i32 %v1116 to i64
  %cond1118 = icmp ne i64 %cv1117, 0
  br i1 %cond1118, label %bb_rcgdec110, label %bb_rcgslow110
bb_rcgslow110:
  %v1119 = load i64, ptr %slot117, align 8
  %v1120 = load i64, ptr %slot100, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v1119, i64 %v1120) nomerge, !dbg !114
  br label %bb_rcgdone110
bb_rcgdec110:
  %v1121 = load i64, ptr %slot126, align 8
  %v1122 = load i64, ptr %slot118, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  %rgep1124 = getelementptr i8, ptr %p1123, i64 -32
  store i64 %v1121, ptr %rgep1124, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear110
bb_rcgclear110:
  %v1125 = load i64, ptr %slot100, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i64 0, ptr %p1126, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone110
bb_rcgdone110:
  br label %bb_rcslotdone79
bb_rcslotdone79:
  %v1127 = load i64, ptr %slot98, align 8
  %v1128 = load i64, ptr %slot27, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i64 %v1127, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot25, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %ld1132 = load i64, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1132, ptr %slot131, align 8
  %v1133 = load i64, ptr %slot131, align 8
  %v1134 = load i64, ptr %slot33, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i64 %v1133, ptr %p1135, align 8, !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot33, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  %ld1138 = load i64, ptr %p1137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1138, ptr %slot132, align 8
  %v1139 = load i64, ptr %slot132, align 8
  %v1140 = load i64, ptr %slot29, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 %v1139, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot29, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i64, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1144, ptr %slot133, align 8
  %v1145 = load i64, ptr %slot133, align 8
  %v1146 = load i64, ptr %slot33, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i64 %v1145, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot34, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i64 0, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot34, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot134, align 8
  %v1153 = load i64, ptr %slot33, align 8
  %p1154 = inttoptr i64 %v1153 to ptr
  %ld1155 = load i64, ptr %p1154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1155, ptr %slot135, align 8
  %v1156 = load i64, ptr %slot135, align 8
  %v1157 = load i64, ptr %slot134, align 8
  %cmp1158 = icmp slt i64 %v1156, %v1157
  %cv1159 = zext i1 %cmp1158 to i64
  store i64 %cv1159, ptr %slot136, align 8
  %v1160 = load i64, ptr %slot136, align 8
  %v1161 = load i64, ptr %slot33, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  store i64 %v1160, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot33, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1165, ptr %slot137, align 8
  %v1166 = load i64, ptr %slot137, align 8
  %cond1167 = icmp ne i64 %v1166, 0
  br i1 %cond1167, label %bb_next158, label %bb_i16
bb_next158:
  %v1168 = load i64, ptr %slot27, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1170, ptr %slot138, align 8
  %v1171 = load i64, ptr %slot138, align 8
  %op1172 = add i64 %v1171, 0
  store i64 %op1172, ptr %slot139, align 8
  %v1173 = load i64, ptr %slot139, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %ld1175 = load i64, ptr %p1174, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1175, ptr %slot140, align 8
  %v1176 = load i64, ptr %slot140, align 8
  %v1177 = load i64, ptr %slot33, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  store i64 %v1176, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  %v1179 = load i64, ptr %slot33, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i64, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1181, ptr %slot141, align 8
  %v1182 = load i64, ptr %slot141, align 8
  %cmp1183 = icmp ugt i64 %v1182, 9223372036854775807
  %cv1184 = zext i1 %cmp1183 to i64
  store i64 %cv1184, ptr %slot142, align 8
  %v1185 = load i64, ptr %slot142, align 8
  %cond1186 = icmp ne i64 %v1185, 0
  br i1 %cond1186, label %bb_cast_overflow163, label %bb_cast_ok163
bb_cast_overflow163:
  %v1187 = load i64, ptr %slot1, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %v1189 = load i64, ptr %slot141, align 8
  call void @myl_qbe_fail_cast(ptr %p1188, i64 %v1189, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok163:
  %v1190 = load i64, ptr %slot141, align 8
  %v1191 = load i64, ptr %slot33, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i64 %v1190, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot29, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  %ld1195 = load i64, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1195, ptr %slot143, align 8
  %v1196 = load i64, ptr %slot143, align 8
  %v1197 = load i64, ptr %slot34, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i64 %v1196, ptr %p1198, align 8, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot34, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %ld1201 = load i64, ptr %p1200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1201, ptr %slot144, align 8
  %v1202 = load i64, ptr %slot33, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %ld1204 = load i64, ptr %p1203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1204, ptr %slot145, align 8
  %v1205 = load i64, ptr %slot145, align 8
  %v1206 = load i64, ptr %slot144, align 8
  %ovpair1208 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1205, i64 %v1206)
  %op1207 = extractvalue { i64, i1 } %ovpair1208, 0
  %ov1209 = extractvalue { i64, i1 } %ovpair1208, 1
  store i64 %op1207, ptr %slot146, align 8
  %v1210 = load i64, ptr %slot145, align 8
  %v1211 = load i64, ptr %slot146, align 8
  %op1212 = xor i64 %v1210, %v1211
  store i64 %op1212, ptr %slot147, align 8
  %v1213 = load i64, ptr %slot144, align 8
  %v1214 = load i64, ptr %slot146, align 8
  %op1215 = xor i64 %v1213, %v1214
  store i64 %op1215, ptr %slot148, align 8
  %v1216 = load i64, ptr %slot147, align 8
  %v1217 = load i64, ptr %slot148, align 8
  %op1218 = and i64 %v1216, %v1217
  store i64 %op1218, ptr %slot149, align 8
  %cv1219 = zext i1 %ov1209 to i64
  store i64 %cv1219, ptr %slot150, align 8
  %v1220 = load i64, ptr %slot150, align 8
  %cond1221 = icmp ne i64 %v1220, 0
  br i1 %cond1221, label %bb_overflow167, label %bb_checked167
bb_overflow167:
  %v1222 = load i64, ptr %slot1, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %v1224 = load i64, ptr %slot145, align 8
  %v1225 = load i64, ptr %slot144, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1223, i64 0, i64 %v1224, i64 %v1225, i64 64) nomerge, !dbg !118
  unreachable
bb_checked167:
  %v1226 = load i64, ptr %slot146, align 8
  %v1227 = load i64, ptr %slot33, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  store i64 %v1226, ptr %p1228, align 8, !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot33, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  %ld1231 = load i64, ptr %p1230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1231, ptr %slot151, align 8
  %v1232 = load i64, ptr %slot151, align 8
  %v1233 = load i64, ptr %slot29, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i64 %v1232, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v1235 = load i64, ptr %slot29, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i64, ptr %p1236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1237, ptr %slot152, align 8
  %v1238 = load i64, ptr %slot152, align 8
  %v1239 = load i64, ptr %slot33, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i64 %v1238, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot28, align 8
  %v1242 = load i64, ptr %slot34, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 %v1241, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot34, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i64, ptr %p1245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1246, ptr %slot153, align 8
  %v1247 = load i64, ptr %slot10, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %ld1249 = load i32, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1249, ptr %slot154, align 8
  %v1250 = load i64, ptr %slot11, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i32, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1252, ptr %slot155, align 8
  %v1253 = load i32, ptr %slot155, align 8
  %op1254 = and i32 %v1253, 24
  store i32 %op1254, ptr %slot155, align 8
  %v1255 = load i32, ptr %slot155, align 8
  %cmp1256 = icmp eq i32 %v1255, 0
  %cv1257 = zext i1 %cmp1256 to i32
  store i32 %cv1257, ptr %slot156, align 8
  %v1258 = load i32, ptr %slot154, align 8
  %v1259 = load i32, ptr %slot156, align 8
  %op1260 = and i32 %v1258, %v1259
  store i32 %op1260, ptr %slot157, align 8
  %v1261 = load i64, ptr %slot38, align 8
  store i64 %v1261, ptr %slot158, align 8
  %v1262 = load i32, ptr %slot157, align 8
  %op1263 = mul i32 %v1262, 4
  store i32 %op1263, ptr %slot159, align 8
  %v1264 = load i32, ptr %slot159, align 8
  %op1265 = or i32 %v1264, 0
  store i32 %op1265, ptr %slot160, align 8
  %v1266 = load i64, ptr %slot18, align 8
  store i64 %v1266, ptr %slot161, align 8
  %v1267 = load i64, ptr %slot37, align 8
  %v1268 = load i64, ptr %slot161, align 8
  %v1269 = load i64, ptr %slot153, align 8
  %v1270 = load i64, ptr %slot158, align 8
  %cv1271 = trunc i64 %v1270 to i32
  %v1272 = load i32, ptr %slot160, align 8
  %call1273 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v1267, i64 %v1268, i64 %v1269, i32 %cv1271, i32 %v1272) nomerge, !dbg !120
  store i32 %call1273, ptr %slot162, align 8
  %v1274 = load i32, ptr %slot162, align 8
  %cv1275 = zext i32 %v1274 to i64
  %cond1276 = icmp ne i64 %cv1275, 0
  br i1 %cond1276, label %bb_rcsuccess188, label %bb_rcfailure188
bb_rcfailure188:
  %v1277 = load i64, ptr %slot37, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  %call1279 = call i32 @myl_rc_take_failure(ptr %p1278) nomerge, !dbg !120
  store i32 %call1279, ptr %slot163, align 8
  %v1280 = load i64, ptr %slot1, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  %v1282 = load i32, ptr %slot163, align 8
  %call1283 = call i32 @myl_qbe_rc_status(ptr %p1281, i32 %v1282) nomerge, !dbg !120
  store i32 %call1283, ptr %slot164, align 8
  br label %bb_failure
bb_rcsuccess188:
  %v1284 = load i32, ptr %slot157, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rchtaken191, label %bb_rchcopied191
bb_rchcopied191:
  %v1287 = load i64, ptr %slot10, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %ld1289 = load i32, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1289, ptr %slot165, align 8
  %v1290 = load i32, ptr %slot165, align 8
  %cv1291 = zext i32 %v1290 to i64
  %cond1292 = icmp ne i64 %cv1291, 0
  br i1 %cond1292, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v1293 = load i64, ptr %slot10, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  store i32 0, ptr %p1294, align 4, !alias.scope !3, !noalias !4
  %v1295 = load i64, ptr %slot16, align 8
  store i64 %v1295, ptr %slot166, align 8
  %v1296 = load i64, ptr %slot11, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  %ld1298 = load i32, ptr %p1297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1298, ptr %slot167, align 8
  %v1299 = load i32, ptr %slot167, align 8
  %op1300 = and i32 %v1299, 28
  store i32 %op1300, ptr %slot168, align 8
  %v1301 = load i32, ptr %slot168, align 8
  %cv1302 = zext i32 %v1301 to i64
  %cond1303 = icmp ne i64 %cv1302, 0
  br i1 %cond1303, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v1304 = load i64, ptr %slot37, align 8
  store i64 %v1304, ptr %slot169, align 8
  %v1305 = load i64, ptr %slot169, align 8
  %v1306 = load i64, ptr %slot166, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1305, i64 %v1306) nomerge, !dbg !120
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v1307 = load i64, ptr %slot37, align 8
  store i64 %v1307, ptr %slot170, align 8
  %v1308 = load i64, ptr %slot170, align 8
  %v1309 = load i64, ptr %slot166, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1308, i64 %v1309) nomerge, !dbg !120
  br label %bb_rcslotdone194
bb_rcslotdone194:
  br label %bb_rchprepared191
bb_rchtaken191:
  %v1310 = load i64, ptr %slot10, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  store i32 0, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared191
bb_rchprepared191:
  %v1312 = load i64, ptr %slot13, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i32 2, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot12, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  store i32 1, ptr %p1315, align 4, !alias.scope !3, !noalias !4
  %v1316 = load i64, ptr %slot16, align 8
  store i64 %v1316, ptr %slot171, align 8
  %v1317 = load i64, ptr %slot18, align 8
  store i64 %v1317, ptr %slot172, align 8
  %v1318 = load i64, ptr %slot172, align 8
  %v1319 = load i64, ptr %slot171, align 8
  %p1320 = inttoptr i64 %v1318 to ptr
  %p1321 = inttoptr i64 %v1319 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1321, ptr %p1320, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot11, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i32 2, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot13, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %ld1326 = load i32, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1326, ptr %slot173, align 8
  %v1327 = load i32, ptr %slot173, align 8
  %v1328 = load i64, ptr %slot11, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 %v1327, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot12, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 0, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot10, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 1, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot171, align 8
  %v1335 = load i64, ptr %slot34, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i64 %v1334, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot27, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i64, ptr %p1338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1339, ptr %slot174, align 8
  %v1340 = load i64, ptr %slot34, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  %ld1342 = load i64, ptr %p1341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1342, ptr %slot175, align 8
  %v1343 = load i64, ptr %slot33, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  %ld1345 = load i64, ptr %p1344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1345, ptr %slot176, align 8
  %v1346 = load i64, ptr %slot174, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i64, ptr %p1347, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1348, ptr %slot177, align 8
  %v1349 = load i64, ptr %slot176, align 8
  %v1350 = load i64, ptr %slot177, align 8
  %cmp1351 = icmp ult i64 %v1349, %v1350
  %cv1352 = zext i1 %cmp1351 to i64
  store i64 %cv1352, ptr %slot178, align 8
  %v1353 = load i64, ptr %slot178, align 8
  %cond1354 = icmp ne i64 %v1353, 0
  br i1 %cond1354, label %bb_success218, label %bb_failed218
bb_failed218:
  %v1355 = load i64, ptr %slot1, align 8
  %p1356 = inttoptr i64 %v1355 to ptr
  %v1357 = load i64, ptr %slot176, align 8
  %v1358 = load i64, ptr %slot177, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1356, i64 %v1357, i64 %v1358) nomerge, !dbg !122
  unreachable
bb_success218:
  %v1359 = load i64, ptr %slot34, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %ld1361 = load i64, ptr %p1360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1361, ptr %slot179, align 8
  %v1362 = load i64, ptr %slot37, align 8
  %v1363 = load i64, ptr %slot174, align 8
  %v1364 = load i64, ptr %slot176, align 8
  %v1365 = load i64, ptr %slot179, align 8
  %call1366 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v1362, i64 %v1363, i64 %v1364, i64 %v1365) nomerge, !dbg !122
  store i32 %call1366, ptr %slot180, align 8
  %v1367 = load i32, ptr %slot180, align 8
  %cv1368 = zext i32 %v1367 to i64
  %cond1369 = icmp ne i64 %cv1368, 0
  br i1 %cond1369, label %bb_success221, label %bb_failed221
bb_failed221:
  %v1370 = load i64, ptr %slot1, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1371) nomerge, !dbg !122
  unreachable
bb_success221:
  %v1372 = load i64, ptr %slot33, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  store i64 0, ptr %p1373, align 8, !alias.scope !3, !noalias !4
  %v1374 = load i64, ptr %slot10, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  %ld1376 = load i32, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1376, ptr %slot181, align 8
  %v1377 = load i32, ptr %slot181, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rcslotdrop224, label %bb_rcslotdone224
bb_rcslotdrop224:
  %v1380 = load i64, ptr %slot10, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i32 0, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  %v1382 = load i64, ptr %slot16, align 8
  store i64 %v1382, ptr %slot182, align 8
  %v1383 = load i64, ptr %slot11, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %ld1385 = load i32, ptr %p1384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1385, ptr %slot183, align 8
  %v1386 = load i32, ptr %slot183, align 8
  %op1387 = and i32 %v1386, 28
  store i32 %op1387, ptr %slot184, align 8
  %v1388 = load i32, ptr %slot184, align 8
  %cv1389 = zext i32 %v1388 to i64
  %cond1390 = icmp ne i64 %cv1389, 0
  br i1 %cond1390, label %bb_rcslotrole224, label %bb_rcslotowner224
bb_rcslotrole224:
  %v1391 = load i64, ptr %slot37, align 8
  store i64 %v1391, ptr %slot185, align 8
  %v1392 = load i64, ptr %slot185, align 8
  %v1393 = load i64, ptr %slot182, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1392, i64 %v1393) nomerge, !dbg !122
  br label %bb_rcslotdone224
bb_rcslotowner224:
  %v1394 = load i64, ptr %slot37, align 8
  store i64 %v1394, ptr %slot186, align 8
  %v1395 = load i64, ptr %slot186, align 8
  %v1396 = load i64, ptr %slot182, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1395, i64 %v1396) nomerge, !dbg !122
  br label %bb_rcslotdone224
bb_rcslotdone224:
  %v1397 = load i64, ptr %slot26, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  %ld1399 = load i64, ptr %p1398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1399, ptr %slot187, align 8
  %v1400 = load i64, ptr %slot187, align 8
  %v1401 = load i64, ptr %slot33, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  store i64 %v1400, ptr %p1402, align 8, !alias.scope !3, !noalias !4
  %v1403 = load i64, ptr %slot33, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  %ld1405 = load i64, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1405, ptr %slot188, align 8
  %v1406 = load i64, ptr %slot188, align 8
  %op1407 = add i64 %v1406, 0
  store i64 %op1407, ptr %slot189, align 8
  %v1408 = load i64, ptr %slot189, align 8
  %v1409 = load i64, ptr %slot33, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i64 %v1408, ptr %p1410, align 8, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot8, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i32, ptr %p1412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1413, ptr %slot190, align 8
  %v1414 = load i32, ptr %slot190, align 8
  %cv1415 = zext i32 %v1414 to i64
  %cond1416 = icmp ne i64 %cv1415, 0
  br i1 %cond1416, label %bb_rcslotdrop236, label %bb_rcslotdone236
bb_rcslotdrop236:
  %v1417 = load i64, ptr %slot8, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 0, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot15, align 8
  store i64 %v1419, ptr %slot191, align 8
  %v1420 = load i64, ptr %slot9, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %ld1422 = load i32, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1422, ptr %slot192, align 8
  %v1423 = load i32, ptr %slot192, align 8
  %op1424 = and i32 %v1423, 28
  store i32 %op1424, ptr %slot193, align 8
  %v1425 = load i32, ptr %slot193, align 8
  %cv1426 = zext i32 %v1425 to i64
  %cond1427 = icmp ne i64 %cv1426, 0
  br i1 %cond1427, label %bb_rcslotrole236, label %bb_rcslotowner236
bb_rcslotrole236:
  %v1428 = load i64, ptr %slot37, align 8
  store i64 %v1428, ptr %slot194, align 8
  %v1429 = load i64, ptr %slot194, align 8
  %v1430 = load i64, ptr %slot191, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1429, i64 %v1430) nomerge, !dbg !124
  br label %bb_rcslotdone236
bb_rcslotowner236:
  %v1431 = load i64, ptr %slot37, align 8
  store i64 %v1431, ptr %slot195, align 8
  %v1432 = load i64, ptr %slot195, align 8
  %v1433 = load i64, ptr %slot191, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1432, i64 %v1433) nomerge, !dbg !124
  br label %bb_rcslotdone236
bb_rcslotdone236:
  %v1434 = load i64, ptr %slot33, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i64, ptr %p1435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1436, ptr %slot196, align 8
  %v1437 = load i64, ptr %slot8, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  %ld1439 = load i32, ptr %p1438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1439, ptr %slot197, align 8
  %v1440 = load i64, ptr %slot9, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i32, ptr %p1441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1442, ptr %slot198, align 8
  %v1443 = load i32, ptr %slot198, align 8
  %op1444 = and i32 %v1443, 24
  store i32 %op1444, ptr %slot198, align 8
  %v1445 = load i32, ptr %slot198, align 8
  %cmp1446 = icmp eq i32 %v1445, 0
  %cv1447 = zext i1 %cmp1446 to i32
  store i32 %cv1447, ptr %slot199, align 8
  %v1448 = load i32, ptr %slot197, align 8
  %v1449 = load i32, ptr %slot199, align 8
  %op1450 = and i32 %v1448, %v1449
  store i32 %op1450, ptr %slot200, align 8
  %v1451 = load i64, ptr %slot38, align 8
  store i64 %v1451, ptr %slot201, align 8
  %v1452 = load i32, ptr %slot200, align 8
  %op1453 = mul i32 %v1452, 4
  store i32 %op1453, ptr %slot202, align 8
  %v1454 = load i32, ptr %slot202, align 8
  %op1455 = or i32 %v1454, 0
  store i32 %op1455, ptr %slot203, align 8
  %v1456 = load i64, ptr %slot18, align 8
  store i64 %v1456, ptr %slot204, align 8
  %v1457 = load i64, ptr %slot37, align 8
  %v1458 = load i64, ptr %slot204, align 8
  %v1459 = load i64, ptr %slot196, align 8
  %v1460 = load i64, ptr %slot201, align 8
  %cv1461 = trunc i64 %v1460 to i32
  %v1462 = load i32, ptr %slot203, align 8
  %call1463 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v1457, i64 %v1458, i64 %v1459, i32 %cv1461, i32 %v1462) nomerge, !dbg !126
  store i32 %call1463, ptr %slot205, align 8
  %v1464 = load i32, ptr %slot205, align 8
  %cv1465 = zext i32 %v1464 to i64
  %cond1466 = icmp ne i64 %cv1465, 0
  br i1 %cond1466, label %bb_rcsuccess257, label %bb_rcfailure257
bb_rcfailure257:
  %v1467 = load i64, ptr %slot37, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %call1469 = call i32 @myl_rc_take_failure(ptr %p1468) nomerge, !dbg !126
  store i32 %call1469, ptr %slot206, align 8
  %v1470 = load i64, ptr %slot1, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %v1472 = load i32, ptr %slot206, align 8
  %call1473 = call i32 @myl_qbe_rc_status(ptr %p1471, i32 %v1472) nomerge, !dbg !126
  store i32 %call1473, ptr %slot207, align 8
  br label %bb_failure
bb_rcsuccess257:
  %v1474 = load i32, ptr %slot200, align 8
  %cv1475 = zext i32 %v1474 to i64
  %cond1476 = icmp ne i64 %cv1475, 0
  br i1 %cond1476, label %bb_rchtaken260, label %bb_rchcopied260
bb_rchcopied260:
  %v1477 = load i64, ptr %slot8, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  %ld1479 = load i32, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1479, ptr %slot208, align 8
  %v1480 = load i32, ptr %slot208, align 8
  %cv1481 = zext i32 %v1480 to i64
  %cond1482 = icmp ne i64 %cv1481, 0
  br i1 %cond1482, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v1483 = load i64, ptr %slot8, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i32 0, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  %v1485 = load i64, ptr %slot15, align 8
  store i64 %v1485, ptr %slot209, align 8
  %v1486 = load i64, ptr %slot9, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  %ld1488 = load i32, ptr %p1487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1488, ptr %slot210, align 8
  %v1489 = load i32, ptr %slot210, align 8
  %op1490 = and i32 %v1489, 28
  store i32 %op1490, ptr %slot211, align 8
  %v1491 = load i32, ptr %slot211, align 8
  %cv1492 = zext i32 %v1491 to i64
  %cond1493 = icmp ne i64 %cv1492, 0
  br i1 %cond1493, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v1494 = load i64, ptr %slot37, align 8
  store i64 %v1494, ptr %slot212, align 8
  %v1495 = load i64, ptr %slot212, align 8
  %v1496 = load i64, ptr %slot209, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v1495, i64 %v1496) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v1497 = load i64, ptr %slot37, align 8
  store i64 %v1497, ptr %slot213, align 8
  %v1498 = load i64, ptr %slot213, align 8
  %v1499 = load i64, ptr %slot209, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v1498, i64 %v1499) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotdone263:
  br label %bb_rchprepared260
bb_rchtaken260:
  %v1500 = load i64, ptr %slot8, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i32 0, ptr %p1501, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared260
bb_rchprepared260:
  %v1502 = load i64, ptr %slot13, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i32 2, ptr %p1503, align 4, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot12, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  store i32 1, ptr %p1505, align 4, !alias.scope !3, !noalias !4
  %v1506 = load i64, ptr %slot15, align 8
  store i64 %v1506, ptr %slot214, align 8
  %v1507 = load i64, ptr %slot18, align 8
  store i64 %v1507, ptr %slot215, align 8
  %v1508 = load i64, ptr %slot215, align 8
  %v1509 = load i64, ptr %slot214, align 8
  %p1510 = inttoptr i64 %v1508 to ptr
  %p1511 = inttoptr i64 %v1509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1511, ptr %p1510, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1512 = load i64, ptr %slot9, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  store i32 2, ptr %p1513, align 4, !alias.scope !3, !noalias !4
  %v1514 = load i64, ptr %slot13, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %ld1516 = load i32, ptr %p1515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1516, ptr %slot216, align 8
  %v1517 = load i32, ptr %slot216, align 8
  %v1518 = load i64, ptr %slot9, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  store i32 %v1517, ptr %p1519, align 4, !alias.scope !3, !noalias !4
  %v1520 = load i64, ptr %slot12, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  store i32 0, ptr %p1521, align 4, !alias.scope !3, !noalias !4
  %v1522 = load i64, ptr %slot8, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i32 1, ptr %p1523, align 4, !alias.scope !3, !noalias !4
  %v1524 = load i64, ptr %slot214, align 8
  %v1525 = load i64, ptr %slot33, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i64 %v1524, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot35, align 8
  store i64 %v1527, ptr %slot217, align 8
  %v1528 = load i64, ptr %slot217, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  store i64 0, ptr %p1529, align 8, !alias.scope !3, !noalias !4
  %v1530 = load i64, ptr %slot217, align 8
  %p1532 = inttoptr i64 %v1530 to ptr
  %gep1533 = getelementptr i8, ptr %p1532, i64 8
  %op1531 = ptrtoint ptr %gep1533 to i64
  store i64 %op1531, ptr %slot218, align 8
  %v1534 = load i64, ptr %slot218, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i64 0, ptr %p1535, align 8, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot217, align 8
  %p1538 = inttoptr i64 %v1536 to ptr
  %gep1539 = getelementptr i8, ptr %p1538, i64 16
  %op1537 = ptrtoint ptr %gep1539 to i64
  store i64 %op1537, ptr %slot219, align 8
  %v1540 = load i64, ptr %slot219, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  store i64 0, ptr %p1541, align 8, !alias.scope !3, !noalias !4
  %v1542 = load i64, ptr %slot217, align 8
  %p1544 = inttoptr i64 %v1542 to ptr
  %gep1545 = getelementptr i8, ptr %p1544, i64 24
  %op1543 = ptrtoint ptr %gep1545 to i64
  store i64 %op1543, ptr %slot220, align 8
  %v1546 = load i64, ptr %slot220, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i64 0, ptr %p1547, align 8, !alias.scope !3, !noalias !4
  %v1548 = load i64, ptr %slot217, align 8
  %p1550 = inttoptr i64 %v1548 to ptr
  %gep1551 = getelementptr i8, ptr %p1550, i64 32
  %op1549 = ptrtoint ptr %gep1551 to i64
  store i64 %op1549, ptr %slot221, align 8
  %v1552 = load i64, ptr %slot221, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i64 0, ptr %p1553, align 8, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot217, align 8
  %p1556 = inttoptr i64 %v1554 to ptr
  %gep1557 = getelementptr i8, ptr %p1556, i64 40
  %op1555 = ptrtoint ptr %gep1557 to i64
  store i64 %op1555, ptr %slot222, align 8
  %v1558 = load i64, ptr %slot222, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i64 0, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  %v1560 = load i64, ptr %slot217, align 8
  %p1562 = inttoptr i64 %v1560 to ptr
  %gep1563 = getelementptr i8, ptr %p1562, i64 48
  %op1561 = ptrtoint ptr %gep1563 to i64
  store i64 %op1561, ptr %slot223, align 8
  %v1564 = load i64, ptr %slot223, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 0, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot217, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i32 2, ptr %p1567, align 4, !alias.scope !3, !noalias !4
  %v1568 = load i64, ptr %slot14, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  store i32 1, ptr %p1569, align 4, !alias.scope !3, !noalias !4
  %v1570 = load i64, ptr %slot33, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  %ld1572 = load i64, ptr %p1571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1572, ptr %slot224, align 8
  %v1573 = load i64, ptr %slot217, align 8
  %p1575 = inttoptr i64 %v1573 to ptr
  %gep1576 = getelementptr i8, ptr %p1575, i64 8
  %op1574 = ptrtoint ptr %gep1576 to i64
  store i64 %op1574, ptr %slot225, align 8
  %v1577 = load i64, ptr %slot38, align 8
  store i64 %v1577, ptr %slot226, align 8
  %v1578 = load i64, ptr %slot33, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %ld1580 = load i64, ptr %p1579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1580, ptr %slot227, align 8
  %v1581 = load i64, ptr %slot18, align 8
  store i64 %v1581, ptr %slot228, align 8
  %v1582 = load i64, ptr %slot38, align 8
  store i64 %v1582, ptr %slot229, align 8
  %v1583 = load i64, ptr %slot227, align 8
  %op1584 = add i64 %v1583, 16
  store i64 %op1584, ptr %slot230, align 8
  %v1585 = load i64, ptr %slot230, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %ld1587 = load i64, ptr %p1586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1587, ptr %slot231, align 8
  %v1588 = load i64, ptr %slot231, align 8
  %cmp1589 = icmp ne i64 %v1588, 0
  %cv1590 = zext i1 %cmp1589 to i32
  store i32 %cv1590, ptr %slot232, align 8
  %v1591 = load i32, ptr %slot232, align 8
  %cv1592 = zext i32 %v1591 to i64
  %cond1593 = icmp ne i64 %cv1592, 0
  br i1 %cond1593, label %bb_rcmoveheader299, label %bb_rcmovenext299
bb_rcmoveheader299:
  %v1594 = load i64, ptr %slot231, align 8
  %op1595 = sub i64 %v1594, 16
  store i64 %op1595, ptr %slot233, align 8
  %v1596 = load i64, ptr %slot231, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %rgep1598 = getelementptr i8, ptr %p1597, i64 -16
  %ld1599 = load i64, ptr %rgep1598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1599, ptr %slot234, align 8
  %v1600 = load i64, ptr %slot234, align 8
  %op1601 = and i64 %v1600, 5764607523034234881
  store i64 %op1601, ptr %slot235, align 8
  %v1602 = load i64, ptr %slot235, align 8
  %cmp1603 = icmp ne i64 %v1602, 0
  %cv1604 = zext i1 %cmp1603 to i32
  store i32 %cv1604, ptr %slot236, align 8
  %v1605 = load i32, ptr %slot236, align 8
  %cv1606 = zext i32 %v1605 to i64
  %cond1607 = icmp ne i64 %cv1606, 0
  br i1 %cond1607, label %bb_rcmoveslow296, label %bb_rcmovenext299
bb_rcmovenext299:
  %v1608 = load i64, ptr %slot227, align 8
  %op1609 = add i64 %v1608, 24
  store i64 %op1609, ptr %slot237, align 8
  %v1610 = load i64, ptr %slot237, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i64, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1612, ptr %slot238, align 8
  %v1613 = load i64, ptr %slot238, align 8
  %cmp1614 = icmp ne i64 %v1613, 0
  %cv1615 = zext i1 %cmp1614 to i32
  store i32 %cv1615, ptr %slot239, align 8
  %v1616 = load i32, ptr %slot239, align 8
  %cv1617 = zext i32 %v1616 to i64
  %cond1618 = icmp ne i64 %cv1617, 0
  br i1 %cond1618, label %bb_rcmoveheader307, label %bb_rcmovenext307
bb_rcmoveheader307:
  %v1619 = load i64, ptr %slot238, align 8
  %op1620 = sub i64 %v1619, 16
  store i64 %op1620, ptr %slot240, align 8
  %v1621 = load i64, ptr %slot238, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %rgep1623 = getelementptr i8, ptr %p1622, i64 -16
  %ld1624 = load i64, ptr %rgep1623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1624, ptr %slot241, align 8
  %v1625 = load i64, ptr %slot241, align 8
  %op1626 = and i64 %v1625, 5764607523034234881
  store i64 %op1626, ptr %slot242, align 8
  %v1627 = load i64, ptr %slot242, align 8
  %cmp1628 = icmp ne i64 %v1627, 0
  %cv1629 = zext i1 %cmp1628 to i32
  store i32 %cv1629, ptr %slot243, align 8
  %v1630 = load i32, ptr %slot243, align 8
  %cv1631 = zext i32 %v1630 to i64
  %cond1632 = icmp ne i64 %cv1631, 0
  br i1 %cond1632, label %bb_rcmoveslow296, label %bb_rcmovenext307
bb_rcmovenext307:
  %v1633 = load i64, ptr %slot227, align 8
  %op1634 = add i64 %v1633, 32
  store i64 %op1634, ptr %slot244, align 8
  %v1635 = load i64, ptr %slot244, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i64, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1637, ptr %slot245, align 8
  %v1638 = load i64, ptr %slot245, align 8
  %cmp1639 = icmp ne i64 %v1638, 0
  %cv1640 = zext i1 %cmp1639 to i32
  store i32 %cv1640, ptr %slot246, align 8
  %v1641 = load i32, ptr %slot246, align 8
  %cv1642 = zext i32 %v1641 to i64
  %cond1643 = icmp ne i64 %cv1642, 0
  br i1 %cond1643, label %bb_rcmoveheader315, label %bb_rcmovenext315
bb_rcmoveheader315:
  %v1644 = load i64, ptr %slot245, align 8
  %op1645 = sub i64 %v1644, 16
  store i64 %op1645, ptr %slot247, align 8
  %v1646 = load i64, ptr %slot245, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %rgep1648 = getelementptr i8, ptr %p1647, i64 -16
  %ld1649 = load i64, ptr %rgep1648, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1649, ptr %slot248, align 8
  %v1650 = load i64, ptr %slot248, align 8
  %op1651 = and i64 %v1650, 5764607523034234881
  store i64 %op1651, ptr %slot249, align 8
  %v1652 = load i64, ptr %slot249, align 8
  %cmp1653 = icmp ne i64 %v1652, 0
  %cv1654 = zext i1 %cmp1653 to i32
  store i32 %cv1654, ptr %slot250, align 8
  %v1655 = load i32, ptr %slot250, align 8
  %cv1656 = zext i32 %v1655 to i64
  %cond1657 = icmp ne i64 %cv1656, 0
  br i1 %cond1657, label %bb_rcmoveslow296, label %bb_rcmovenext315
bb_rcmovenext315:
  %v1658 = load i64, ptr %slot227, align 8
  %v1659 = load i64, ptr %slot228, align 8
  %p1660 = inttoptr i64 %v1658 to ptr
  %p1661 = inttoptr i64 %v1659 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1661, ptr %p1660, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1662 = load i64, ptr %slot227, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i64 0, ptr %p1663, align 8, !alias.scope !3, !noalias !4
  %v1664 = load i64, ptr %slot227, align 8
  %op1665 = add i64 %v1664, 8
  store i64 %op1665, ptr %slot251, align 8
  %v1666 = load i64, ptr %slot251, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 0, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot227, align 8
  %op1669 = add i64 %v1668, 16
  store i64 %op1669, ptr %slot252, align 8
  %v1670 = load i64, ptr %slot252, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  store i64 0, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  %v1672 = load i64, ptr %slot227, align 8
  %op1673 = add i64 %v1672, 24
  store i64 %op1673, ptr %slot253, align 8
  %v1674 = load i64, ptr %slot253, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot227, align 8
  %op1677 = add i64 %v1676, 32
  store i64 %op1677, ptr %slot254, align 8
  %v1678 = load i64, ptr %slot254, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  store i64 0, ptr %p1679, align 8, !alias.scope !3, !noalias !4
  %v1680 = load i64, ptr %slot227, align 8
  %op1681 = add i64 %v1680, 40
  store i64 %op1681, ptr %slot255, align 8
  %v1682 = load i64, ptr %slot255, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i64 0, ptr %p1683, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved296
bb_rcmoveslow296:
  %v1684 = load i64, ptr %slot37, align 8
  %v1685 = load i64, ptr %slot228, align 8
  %v1686 = load i64, ptr %slot227, align 8
  %v1687 = load i64, ptr %slot229, align 8
  %cv1688 = trunc i64 %v1687 to i32
  %call1689 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v1684, i64 %v1685, i64 %v1686, i32 %cv1688) nomerge, !dbg !128
  store i32 %call1689, ptr %slot256, align 8
  %v1690 = load i32, ptr %slot256, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcsuccess327, label %bb_rcfailure327
bb_rcfailure327:
  %v1693 = load i64, ptr %slot37, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %call1695 = call i32 @myl_rc_take_failure(ptr %p1694) nomerge, !dbg !128
  store i32 %call1695, ptr %slot257, align 8
  %v1696 = load i64, ptr %slot1, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %v1698 = load i32, ptr %slot257, align 8
  %call1699 = call i32 @myl_qbe_rc_status(ptr %p1697, i32 %v1698) nomerge, !dbg !128
  store i32 %call1699, ptr %slot258, align 8
  br label %bb_failure
bb_rcsuccess327:
  br label %bb_rcmoved296
bb_rcmoved296:
  %v1700 = load i64, ptr %slot8, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  store i32 0, ptr %p1701, align 4, !alias.scope !3, !noalias !4
  %v1702 = load i64, ptr %slot13, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  store i32 2, ptr %p1703, align 4, !alias.scope !3, !noalias !4
  %v1704 = load i64, ptr %slot12, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i32 1, ptr %p1705, align 4, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot18, align 8
  store i64 %v1706, ptr %slot259, align 8
  %v1707 = load i64, ptr %slot259, align 8
  %v1708 = load i64, ptr %slot225, align 8
  %p1709 = inttoptr i64 %v1707 to ptr
  %p1710 = inttoptr i64 %v1708 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1710, ptr %p1709, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot12, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot217, align 8
  %v1714 = load i64, ptr %slot33, align 8
  %p1715 = inttoptr i64 %v1714 to ptr
  store i64 %v1713, ptr %p1715, align 8, !alias.scope !3, !noalias !4
  %v1716 = load i64, ptr %slot33, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  %ld1718 = load i64, ptr %p1717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1718, ptr %slot260, align 8
  %v1719 = load i64, ptr %slot15, align 8
  store i64 %v1719, ptr %slot261, align 8
  %v1720 = load i64, ptr %slot260, align 8
  %v1721 = load i64, ptr %slot261, align 8
  %p1722 = inttoptr i64 %v1720 to ptr
  %p1723 = inttoptr i64 %v1721 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1723, ptr %p1722, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot9, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 2, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot8, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 1, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot261, align 8
  %v1729 = load i64, ptr %slot33, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i64 %v1728, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot33, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i64, ptr %p1732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1733, ptr %slot262, align 8
  %v1734 = load i64, ptr %slot8, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %ld1736 = load i32, ptr %p1735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1736, ptr %slot263, align 8
  %v1737 = load i64, ptr %slot9, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  %ld1739 = load i32, ptr %p1738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1739, ptr %slot264, align 8
  %v1740 = load i32, ptr %slot264, align 8
  %op1741 = and i32 %v1740, 24
  store i32 %op1741, ptr %slot264, align 8
  %v1742 = load i32, ptr %slot264, align 8
  %cmp1743 = icmp eq i32 %v1742, 0
  %cv1744 = zext i1 %cmp1743 to i32
  store i32 %cv1744, ptr %slot265, align 8
  %v1745 = load i32, ptr %slot263, align 8
  %v1746 = load i32, ptr %slot265, align 8
  %op1747 = and i32 %v1745, %v1746
  store i32 %op1747, ptr %slot266, align 8
  %v1748 = load i32, ptr %slot266, align 8
  %cv1749 = zext i32 %v1748 to i64
  %cond1750 = icmp ne i64 %cv1749, 0
  br i1 %cond1750, label %bb_rcprivateown346, label %bb_rcprivateloan346
bb_rcprivateown346:
  %v1751 = load i64, ptr %slot18, align 8
  store i64 %v1751, ptr %slot267, align 8
  %v1752 = load i64, ptr %slot38, align 8
  store i64 %v1752, ptr %slot268, align 8
  %v1753 = load i64, ptr %slot37, align 8
  %v1754 = load i64, ptr %slot267, align 8
  %v1755 = load i64, ptr %slot262, align 8
  %v1756 = load i64, ptr %slot268, align 8
  %cv1757 = trunc i64 %v1756 to i32
  %call1758 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v1753, i64 %v1754, i64 %v1755, i32 %cv1757) nomerge, !dbg !130
  store i32 %call1758, ptr %slot269, align 8
  %v1759 = load i32, ptr %slot269, align 8
  %cv1760 = zext i32 %v1759 to i64
  %cond1761 = icmp ne i64 %cv1760, 0
  br i1 %cond1761, label %bb_rcsuccess350, label %bb_rcfailure350
bb_rcfailure350:
  %v1762 = load i64, ptr %slot37, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %call1764 = call i32 @myl_rc_take_failure(ptr %p1763) nomerge, !dbg !130
  store i32 %call1764, ptr %slot270, align 8
  %v1765 = load i64, ptr %slot1, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %v1767 = load i32, ptr %slot270, align 8
  %call1768 = call i32 @myl_qbe_rc_status(ptr %p1766, i32 %v1767) nomerge, !dbg !130
  store i32 %call1768, ptr %slot271, align 8
  br label %bb_failure
bb_rcsuccess350:
  %v1769 = load i64, ptr %slot8, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  store i32 0, ptr %p1770, align 4, !alias.scope !3, !noalias !4
  %v1771 = load i64, ptr %slot13, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i32 2, ptr %p1772, align 4, !alias.scope !3, !noalias !4
  %v1773 = load i64, ptr %slot12, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  store i32 1, ptr %p1774, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared346
bb_rcprivateloan346:
  %v1775 = load i64, ptr %slot8, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i32, ptr %p1776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1777, ptr %slot272, align 8
  %v1778 = load i64, ptr %slot9, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %ld1780 = load i32, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1780, ptr %slot273, align 8
  %v1781 = load i32, ptr %slot273, align 8
  %cmp1782 = icmp eq i32 %v1781, 16
  %cv1783 = zext i1 %cmp1782 to i32
  store i32 %cv1783, ptr %slot274, align 8
  %v1784 = load i32, ptr %slot274, align 8
  %v1785 = load i32, ptr %slot272, align 8
  %op1786 = and i32 %v1784, %v1785
  store i32 %op1786, ptr %slot274, align 8
  %v1787 = load i32, ptr %slot274, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rcprivatemove346, label %bb_rcprivatenew346
bb_rcprivatemove346:
  %v1790 = load i64, ptr %slot18, align 8
  store i64 %v1790, ptr %slot275, align 8
  %v1791 = load i64, ptr %slot262, align 8
  %v1792 = load i64, ptr %slot275, align 8
  %p1793 = inttoptr i64 %v1791 to ptr
  %p1794 = inttoptr i64 %v1792 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1794, ptr %p1793, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot262, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  call void @llvm.memset.p0.i64(ptr %p1796, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v1797 = load i64, ptr %slot13, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  store i32 2, ptr %p1798, align 4, !alias.scope !3, !noalias !4
  %v1799 = load i64, ptr %slot13, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i32 16, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot12, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i32 1, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot8, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 0, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared346
bb_rcprivatenew346:
  %v1805 = load i64, ptr %slot18, align 8
  store i64 %v1805, ptr %slot276, align 8
  %v1806 = load i64, ptr %slot37, align 8
  %v1807 = load i64, ptr %slot276, align 8
  %v1808 = load i64, ptr %slot262, align 8
  %call1809 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v1806, i64 %v1807, i64 %v1808) nomerge, !dbg !130
  store i32 %call1809, ptr %slot277, align 8
  %v1810 = load i32, ptr %slot277, align 8
  %cv1811 = zext i32 %v1810 to i64
  %cond1812 = icmp ne i64 %cv1811, 0
  br i1 %cond1812, label %bb_rcsuccess368, label %bb_rcfailure368
bb_rcfailure368:
  %v1813 = load i64, ptr %slot37, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %call1815 = call i32 @myl_rc_take_failure(ptr %p1814) nomerge, !dbg !130
  store i32 %call1815, ptr %slot278, align 8
  %v1816 = load i64, ptr %slot1, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %v1818 = load i32, ptr %slot278, align 8
  %call1819 = call i32 @myl_qbe_rc_status(ptr %p1817, i32 %v1818) nomerge, !dbg !130
  store i32 %call1819, ptr %slot279, align 8
  br label %bb_failure
bb_rcsuccess368:
  %v1820 = load i64, ptr %slot13, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i32 2, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot13, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  store i32 16, ptr %p1823, align 4, !alias.scope !3, !noalias !4
  %v1824 = load i64, ptr %slot12, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  store i32 1, ptr %p1825, align 4, !alias.scope !3, !noalias !4
  %v1826 = load i64, ptr %slot8, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  %ld1828 = load i32, ptr %p1827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1828, ptr %slot280, align 8
  %v1829 = load i32, ptr %slot280, align 8
  %cv1830 = zext i32 %v1829 to i64
  %cond1831 = icmp ne i64 %cv1830, 0
  br i1 %cond1831, label %bb_rcslotdrop376, label %bb_rcslotdone376
bb_rcslotdrop376:
  %v1832 = load i64, ptr %slot8, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  store i32 0, ptr %p1833, align 4, !alias.scope !3, !noalias !4
  %v1834 = load i64, ptr %slot15, align 8
  store i64 %v1834, ptr %slot281, align 8
  %v1835 = load i64, ptr %slot9, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i32, ptr %p1836, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1837, ptr %slot282, align 8
  %v1838 = load i32, ptr %slot282, align 8
  %op1839 = and i32 %v1838, 28
  store i32 %op1839, ptr %slot283, align 8
  %v1840 = load i32, ptr %slot283, align 8
  %cv1841 = zext i32 %v1840 to i64
  %cond1842 = icmp ne i64 %cv1841, 0
  br i1 %cond1842, label %bb_rcslotrole376, label %bb_rcslotowner376
bb_rcslotrole376:
  %v1843 = load i64, ptr %slot37, align 8
  store i64 %v1843, ptr %slot284, align 8
  %v1844 = load i64, ptr %slot284, align 8
  %v1845 = load i64, ptr %slot281, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1844, i64 %v1845) nomerge, !dbg !130
  br label %bb_rcslotdone376
bb_rcslotowner376:
  %v1846 = load i64, ptr %slot37, align 8
  store i64 %v1846, ptr %slot285, align 8
  %v1847 = load i64, ptr %slot285, align 8
  %v1848 = load i64, ptr %slot281, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1847, i64 %v1848) nomerge, !dbg !130
  br label %bb_rcslotdone376
bb_rcslotdone376:
  br label %bb_rcprivateprepared346
bb_rcprivateprepared346:
  %v1849 = load i64, ptr %slot6, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i32, ptr %p1850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1851, ptr %slot286, align 8
  %v1852 = load i32, ptr %slot286, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcslotdrop386, label %bb_rcslotdone386
bb_rcslotdrop386:
  %v1855 = load i64, ptr %slot6, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 0, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot31, align 8
  store i64 %v1857, ptr %slot287, align 8
  %v1858 = load i64, ptr %slot7, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %ld1860 = load i32, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1860, ptr %slot288, align 8
  %v1861 = load i32, ptr %slot288, align 8
  %op1862 = and i32 %v1861, 28
  store i32 %op1862, ptr %slot289, align 8
  %v1863 = load i32, ptr %slot289, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcslotrole386, label %bb_rcslotowner386
bb_rcslotrole386:
  %v1866 = load i64, ptr %slot37, align 8
  store i64 %v1866, ptr %slot290, align 8
  %v1867 = load i64, ptr %slot290, align 8
  %v1868 = load i64, ptr %slot287, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1867, i64 %v1868) nomerge, !dbg !130
  br label %bb_rcslotdone386
bb_rcslotowner386:
  %v1869 = load i64, ptr %slot37, align 8
  store i64 %v1869, ptr %slot291, align 8
  %v1870 = load i64, ptr %slot291, align 8
  %v1871 = load i64, ptr %slot287, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1870, i64 %v1871) nomerge, !dbg !130
  br label %bb_rcslotdone386
bb_rcslotdone386:
  %v1872 = load i64, ptr %slot31, align 8
  store i64 %v1872, ptr %slot292, align 8
  %v1873 = load i64, ptr %slot18, align 8
  store i64 %v1873, ptr %slot293, align 8
  %v1874 = load i64, ptr %slot293, align 8
  %v1875 = load i64, ptr %slot292, align 8
  %p1876 = inttoptr i64 %v1874 to ptr
  %p1877 = inttoptr i64 %v1875 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1877, ptr %p1876, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot12, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 0, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot7, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i32 2, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  %v1882 = load i64, ptr %slot13, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %ld1884 = load i32, ptr %p1883, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1884, ptr %slot294, align 8
  %v1885 = load i32, ptr %slot294, align 8
  %v1886 = load i64, ptr %slot7, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 %v1885, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot6, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 1, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot24, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %ld1892 = load i64, ptr %p1891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1892, ptr %slot295, align 8
  %v1893 = load i64, ptr %slot295, align 8
  %v1894 = load i64, ptr %slot33, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i64 %v1893, ptr %p1895, align 8, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot33, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %ld1898 = load i64, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1898, ptr %slot296, align 8
  %v1899 = load i64, ptr %slot296, align 8
  %op1900 = add i64 %v1899, 0
  store i64 %op1900, ptr %slot297, align 8
  %v1901 = load i64, ptr %slot297, align 8
  %v1902 = load i64, ptr %slot33, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i64 %v1901, ptr %p1903, align 8, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot8, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %ld1906 = load i32, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1906, ptr %slot298, align 8
  %v1907 = load i32, ptr %slot298, align 8
  %cv1908 = zext i32 %v1907 to i64
  %cond1909 = icmp ne i64 %cv1908, 0
  br i1 %cond1909, label %bb_rcslotdrop405, label %bb_rcslotdone405
bb_rcslotdrop405:
  %v1910 = load i64, ptr %slot8, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 0, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot15, align 8
  store i64 %v1912, ptr %slot299, align 8
  %v1913 = load i64, ptr %slot9, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i32, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1915, ptr %slot300, align 8
  %v1916 = load i32, ptr %slot300, align 8
  %op1917 = and i32 %v1916, 28
  store i32 %op1917, ptr %slot301, align 8
  %v1918 = load i32, ptr %slot301, align 8
  %cv1919 = zext i32 %v1918 to i64
  %cond1920 = icmp ne i64 %cv1919, 0
  br i1 %cond1920, label %bb_rcslotrole405, label %bb_rcslotowner405
bb_rcslotrole405:
  %v1921 = load i64, ptr %slot37, align 8
  store i64 %v1921, ptr %slot302, align 8
  %v1922 = load i64, ptr %slot302, align 8
  %v1923 = load i64, ptr %slot299, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1922, i64 %v1923) nomerge, !dbg !132
  br label %bb_rcslotdone405
bb_rcslotowner405:
  %v1924 = load i64, ptr %slot37, align 8
  store i64 %v1924, ptr %slot303, align 8
  %v1925 = load i64, ptr %slot303, align 8
  %v1926 = load i64, ptr %slot299, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1925, i64 %v1926) nomerge, !dbg !132
  br label %bb_rcslotdone405
bb_rcslotdone405:
  %v1927 = load i64, ptr %slot33, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %ld1929 = load i64, ptr %p1928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1929, ptr %slot304, align 8
  %v1930 = load i64, ptr %slot304, align 8
  %op1931 = add i64 %v1930, 0
  store i64 %op1931, ptr %slot305, align 8
  %v1932 = load i64, ptr %slot305, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %ld1934 = load i64, ptr %p1933, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1934, ptr %slot306, align 8
  %v1935 = load i64, ptr %slot306, align 8
  %v1936 = load i64, ptr %slot33, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  store i64 %v1935, ptr %p1937, align 8, !alias.scope !3, !noalias !4
  %v1938 = load i64, ptr %slot33, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %ld1940 = load i64, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1940, ptr %slot307, align 8
  %v1941 = load i64, ptr %slot307, align 8
  %v1942 = load i64, ptr %slot17, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i64 %v1941, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot17, align 8
  store i64 %v1944, ptr %slot308, align 8
  %v1945 = load i64, ptr %slot18, align 8
  store i64 %v1945, ptr %slot309, align 8
  %v1946 = load i64, ptr %slot308, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  %ld1948 = load i64, ptr %p1947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1948, ptr %slot310, align 8
  %v1949 = load i64, ptr %slot310, align 8
  %cmp1950 = icmp ne i64 %v1949, 0
  %cv1951 = zext i1 %cmp1950 to i32
  store i32 %cv1951, ptr %slot311, align 8
  %v1952 = load i32, ptr %slot311, align 8
  %cv1953 = zext i32 %v1952 to i64
  %cond1954 = icmp ne i64 %cv1953, 0
  br i1 %cond1954, label %bb_rcgnn419, label %bb_rcgstore419
bb_rcgnn419:
  %v1955 = load i64, ptr %slot310, align 8
  %op1956 = sub i64 %v1955, 16
  store i64 %op1956, ptr %slot312, align 8
  %v1957 = load i64, ptr %slot310, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %rgep1959 = getelementptr i8, ptr %p1958, i64 -16
  %ld1960 = load i64, ptr %rgep1959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1960, ptr %slot313, align 8
  %v1961 = load i64, ptr %slot313, align 8
  %op1962 = and i64 %v1961, 4611686018427387906
  store i64 %op1962, ptr %slot314, align 8
  %v1963 = load i64, ptr %slot314, align 8
  %cmp1964 = icmp ne i64 %v1963, 0
  %cv1965 = zext i1 %cmp1964 to i32
  store i32 %cv1965, ptr %slot315, align 8
  %v1966 = load i32, ptr %slot315, align 8
  %cv1967 = zext i32 %v1966 to i64
  %cond1968 = icmp ne i64 %cv1967, 0
  br i1 %cond1968, label %bb_rcgstore419, label %bb_rcginc419
bb_rcginc419:
  %v1969 = load i64, ptr %slot310, align 8
  %op1970 = sub i64 %v1969, 24
  store i64 %op1970, ptr %slot316, align 8
  %v1971 = load i64, ptr %slot310, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  %rgep1973 = getelementptr i8, ptr %p1972, i64 -24
  %ld1974 = load i64, ptr %rgep1973, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1974, ptr %slot317, align 8
  %v1975 = load i64, ptr %slot317, align 8
  %op1976 = add i64 %v1975, 1
  store i64 %op1976, ptr %slot318, align 8
  %v1977 = load i64, ptr %slot318, align 8
  %cmp1978 = icmp eq i64 %v1977, 0
  %cv1979 = zext i1 %cmp1978 to i32
  store i32 %cv1979, ptr %slot319, align 8
  %v1980 = load i32, ptr %slot319, align 8
  %cv1981 = zext i32 %v1980 to i64
  %cond1982 = icmp ne i64 %cv1981, 0
  br i1 %cond1982, label %bb_rcglimit419, label %bb_rcgcapacity419
bb_rcglimit419:
  %v1983 = load i64, ptr %slot1, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %call1985 = call i32 @myl_qbe_rc_status(ptr %p1984, i32 2) nomerge, !dbg !134
  store i32 %call1985, ptr %slot320, align 8
  br label %bb_failure
bb_rcgcapacity419:
  %v1986 = load i64, ptr %slot318, align 8
  %v1987 = load i64, ptr %slot310, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %rgep1989 = getelementptr i8, ptr %p1988, i64 -24
  store i64 %v1986, ptr %rgep1989, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore419
bb_rcgstore419:
  %v1990 = load i64, ptr %slot310, align 8
  %v1991 = load i64, ptr %slot309, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i64 %v1990, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot13, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  store i32 2, ptr %p1994, align 4, !alias.scope !3, !noalias !4
  %v1995 = load i64, ptr %slot13, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i32 16, ptr %p1996, align 4, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot12, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i32 1, ptr %p1998, align 4, !alias.scope !3, !noalias !4
  %v1999 = load i64, ptr %slot8, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %ld2001 = load i32, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2001, ptr %slot321, align 8
  %v2002 = load i32, ptr %slot321, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcslotdrop435, label %bb_rcslotdone435
bb_rcslotdrop435:
  %v2005 = load i64, ptr %slot8, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i32 0, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot15, align 8
  store i64 %v2007, ptr %slot322, align 8
  %v2008 = load i64, ptr %slot9, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i32, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2010, ptr %slot323, align 8
  %v2011 = load i32, ptr %slot323, align 8
  %op2012 = and i32 %v2011, 28
  store i32 %op2012, ptr %slot324, align 8
  %v2013 = load i32, ptr %slot324, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcslotrole435, label %bb_rcslotowner435
bb_rcslotrole435:
  %v2016 = load i64, ptr %slot37, align 8
  store i64 %v2016, ptr %slot325, align 8
  %v2017 = load i64, ptr %slot325, align 8
  %v2018 = load i64, ptr %slot322, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2017, i64 %v2018) nomerge, !dbg !134
  br label %bb_rcslotdone435
bb_rcslotowner435:
  %v2019 = load i64, ptr %slot37, align 8
  store i64 %v2019, ptr %slot326, align 8
  %v2020 = load i64, ptr %slot326, align 8
  %v2021 = load i64, ptr %slot322, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2020, i64 %v2021) nomerge, !dbg !134
  br label %bb_rcslotdone435
bb_rcslotdone435:
  %v2022 = load i64, ptr %slot15, align 8
  store i64 %v2022, ptr %slot327, align 8
  %v2023 = load i64, ptr %slot18, align 8
  store i64 %v2023, ptr %slot328, align 8
  %v2024 = load i64, ptr %slot328, align 8
  %v2025 = load i64, ptr %slot327, align 8
  %p2026 = inttoptr i64 %v2024 to ptr
  %p2027 = inttoptr i64 %v2025 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2027, ptr %p2026, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot9, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  store i32 2, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  %v2030 = load i64, ptr %slot13, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i32, ptr %p2031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2032, ptr %slot329, align 8
  %v2033 = load i32, ptr %slot329, align 8
  %v2034 = load i64, ptr %slot9, align 8
  %p2035 = inttoptr i64 %v2034 to ptr
  store i32 %v2033, ptr %p2035, align 4, !alias.scope !3, !noalias !4
  %v2036 = load i64, ptr %slot12, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  store i32 0, ptr %p2037, align 4, !alias.scope !3, !noalias !4
  %v2038 = load i64, ptr %slot8, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i32 1, ptr %p2039, align 4, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot327, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %ld2042 = load i64, ptr %p2041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2042, ptr %slot330, align 8
  %v2043 = load i64, ptr %slot330, align 8
  %v2044 = load i64, ptr %slot33, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  store i64 %v2043, ptr %p2045, align 8, !alias.scope !3, !noalias !4
  %v2046 = load i64, ptr %slot33, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  %ld2048 = load i64, ptr %p2047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2048, ptr %slot331, align 8
  %v2049 = load i64, ptr %slot24, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  %ld2051 = load i64, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2051, ptr %slot332, align 8
  %v2052 = load i64, ptr %slot8, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %ld2054 = load i32, ptr %p2053, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2054, ptr %slot333, align 8
  %v2055 = load i32, ptr %slot333, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcslotdrop456, label %bb_rcslotdone456
bb_rcslotdrop456:
  %v2058 = load i64, ptr %slot8, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i32 0, ptr %p2059, align 4, !alias.scope !3, !noalias !4
  %v2060 = load i64, ptr %slot15, align 8
  store i64 %v2060, ptr %slot334, align 8
  %v2061 = load i64, ptr %slot9, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %ld2063 = load i32, ptr %p2062, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2063, ptr %slot335, align 8
  %v2064 = load i32, ptr %slot335, align 8
  %op2065 = and i32 %v2064, 28
  store i32 %op2065, ptr %slot336, align 8
  %v2066 = load i32, ptr %slot336, align 8
  %cv2067 = zext i32 %v2066 to i64
  %cond2068 = icmp ne i64 %cv2067, 0
  br i1 %cond2068, label %bb_rcslotrole456, label %bb_rcslotowner456
bb_rcslotrole456:
  %v2069 = load i64, ptr %slot37, align 8
  store i64 %v2069, ptr %slot337, align 8
  %v2070 = load i64, ptr %slot334, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  %ld2072 = load i64, ptr %p2071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2072, ptr %slot338, align 8
  %v2073 = load i64, ptr %slot338, align 8
  %cmp2074 = icmp ne i64 %v2073, 0
  %cv2075 = zext i1 %cmp2074 to i32
  store i32 %cv2075, ptr %slot339, align 8
  %v2076 = load i32, ptr %slot339, align 8
  %cv2077 = zext i32 %v2076 to i64
  %cond2078 = icmp ne i64 %cv2077, 0
  br i1 %cond2078, label %bb_rcgnn472, label %bb_rcgdone472
bb_rcgnn472:
  %v2079 = load i64, ptr %slot338, align 8
  %op2080 = sub i64 %v2079, 16
  store i64 %op2080, ptr %slot340, align 8
  %v2081 = load i64, ptr %slot338, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  %rgep2083 = getelementptr i8, ptr %p2082, i64 -16
  %ld2084 = load i64, ptr %rgep2083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2084, ptr %slot341, align 8
  %v2085 = load i64, ptr %slot341, align 8
  %op2086 = and i64 %v2085, 4611686018427387906
  store i64 %op2086, ptr %slot342, align 8
  %v2087 = load i64, ptr %slot342, align 8
  %cmp2088 = icmp ne i64 %v2087, 0
  %cv2089 = zext i1 %cmp2088 to i32
  store i32 %cv2089, ptr %slot343, align 8
  %v2090 = load i32, ptr %slot343, align 8
  %cv2091 = zext i32 %v2090 to i64
  %cond2092 = icmp ne i64 %cv2091, 0
  br i1 %cond2092, label %bb_rcgclear472, label %bb_rcgcounted472
bb_rcgcounted472:
  %v2093 = load i64, ptr %slot338, align 8
  %op2094 = sub i64 %v2093, 24
  store i64 %op2094, ptr %slot344, align 8
  %v2095 = load i64, ptr %slot338, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %rgep2097 = getelementptr i8, ptr %p2096, i64 -24
  %ld2098 = load i64, ptr %rgep2097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2098, ptr %slot345, align 8
  %v2099 = load i64, ptr %slot345, align 8
  %op2100 = sub i64 %v2099, 1
  store i64 %op2100, ptr %slot346, align 8
  %v2101 = load i64, ptr %slot346, align 8
  %cmp2102 = icmp eq i64 %v2101, 0
  %cv2103 = zext i1 %cmp2102 to i32
  store i32 %cv2103, ptr %slot347, align 8
  %v2104 = load i32, ptr %slot347, align 8
  %cv2105 = zext i32 %v2104 to i64
  %cond2106 = icmp ne i64 %cv2105, 0
  br i1 %cond2106, label %bb_rcglast472, label %bb_rcgdec472
bb_rcglast472:
  %v2107 = load i64, ptr %slot338, align 8
  %op2108 = sub i64 %v2107, 32
  store i64 %op2108, ptr %slot348, align 8
  %v2109 = load i64, ptr %slot338, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  %rgep2111 = getelementptr i8, ptr %p2110, i64 -32
  %ld2112 = load i64, ptr %rgep2111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2112, ptr %slot349, align 8
  %v2113 = load i64, ptr %slot349, align 8
  %cmp2114 = icmp ne i64 %v2113, 0
  %cv2115 = zext i1 %cmp2114 to i32
  store i32 %cv2115, ptr %slot350, align 8
  %v2116 = load i32, ptr %slot350, align 8
  %cv2117 = zext i32 %v2116 to i64
  %cond2118 = icmp ne i64 %cv2117, 0
  br i1 %cond2118, label %bb_rcgdec472, label %bb_rcgslow472
bb_rcgslow472:
  %v2119 = load i64, ptr %slot337, align 8
  %v2120 = load i64, ptr %slot334, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v2119, i64 %v2120) nomerge, !dbg !136
  br label %bb_rcgdone472
bb_rcgdec472:
  %v2121 = load i64, ptr %slot346, align 8
  %v2122 = load i64, ptr %slot338, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %rgep2124 = getelementptr i8, ptr %p2123, i64 -24
  store i64 %v2121, ptr %rgep2124, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear472
bb_rcgclear472:
  %v2125 = load i64, ptr %slot334, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  store i64 0, ptr %p2126, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone472
bb_rcgdone472:
  br label %bb_rcslotdone456
bb_rcslotowner456:
  %v2127 = load i64, ptr %slot37, align 8
  store i64 %v2127, ptr %slot351, align 8
  %v2128 = load i64, ptr %slot334, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %ld2130 = load i64, ptr %p2129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2130, ptr %slot352, align 8
  %v2131 = load i64, ptr %slot352, align 8
  %cmp2132 = icmp ne i64 %v2131, 0
  %cv2133 = zext i1 %cmp2132 to i32
  store i32 %cv2133, ptr %slot353, align 8
  %v2134 = load i32, ptr %slot353, align 8
  %cv2135 = zext i32 %v2134 to i64
  %cond2136 = icmp ne i64 %cv2135, 0
  br i1 %cond2136, label %bb_rcgnn487, label %bb_rcgdone487
bb_rcgnn487:
  %v2137 = load i64, ptr %slot352, align 8
  %op2138 = sub i64 %v2137, 16
  store i64 %op2138, ptr %slot354, align 8
  %v2139 = load i64, ptr %slot352, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  %rgep2141 = getelementptr i8, ptr %p2140, i64 -16
  %ld2142 = load i64, ptr %rgep2141, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2142, ptr %slot355, align 8
  %v2143 = load i64, ptr %slot355, align 8
  %op2144 = and i64 %v2143, 4611686018427387906
  store i64 %op2144, ptr %slot356, align 8
  %v2145 = load i64, ptr %slot356, align 8
  %cmp2146 = icmp ne i64 %v2145, 0
  %cv2147 = zext i1 %cmp2146 to i32
  store i32 %cv2147, ptr %slot357, align 8
  %v2148 = load i32, ptr %slot357, align 8
  %cv2149 = zext i32 %v2148 to i64
  %cond2150 = icmp ne i64 %cv2149, 0
  br i1 %cond2150, label %bb_rcgclear487, label %bb_rcgcounted487
bb_rcgcounted487:
  %v2151 = load i64, ptr %slot352, align 8
  %op2152 = sub i64 %v2151, 32
  store i64 %op2152, ptr %slot358, align 8
  %v2153 = load i64, ptr %slot352, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %rgep2155 = getelementptr i8, ptr %p2154, i64 -32
  %ld2156 = load i64, ptr %rgep2155, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2156, ptr %slot359, align 8
  %v2157 = load i64, ptr %slot359, align 8
  %op2158 = sub i64 %v2157, 1
  store i64 %op2158, ptr %slot360, align 8
  %v2159 = load i64, ptr %slot360, align 8
  %cmp2160 = icmp eq i64 %v2159, 0
  %cv2161 = zext i1 %cmp2160 to i32
  store i32 %cv2161, ptr %slot361, align 8
  %v2162 = load i32, ptr %slot361, align 8
  %cv2163 = zext i32 %v2162 to i64
  %cond2164 = icmp ne i64 %cv2163, 0
  br i1 %cond2164, label %bb_rcglast487, label %bb_rcgdec487
bb_rcglast487:
  %v2165 = load i64, ptr %slot352, align 8
  %op2166 = sub i64 %v2165, 24
  store i64 %op2166, ptr %slot362, align 8
  %v2167 = load i64, ptr %slot352, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  %rgep2169 = getelementptr i8, ptr %p2168, i64 -24
  %ld2170 = load i64, ptr %rgep2169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2170, ptr %slot363, align 8
  %v2171 = load i64, ptr %slot363, align 8
  %cmp2172 = icmp ne i64 %v2171, 0
  %cv2173 = zext i1 %cmp2172 to i32
  store i32 %cv2173, ptr %slot364, align 8
  %v2174 = load i32, ptr %slot364, align 8
  %cv2175 = zext i32 %v2174 to i64
  %cond2176 = icmp ne i64 %cv2175, 0
  br i1 %cond2176, label %bb_rcgdec487, label %bb_rcgslow487
bb_rcgslow487:
  %v2177 = load i64, ptr %slot351, align 8
  %v2178 = load i64, ptr %slot334, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v2177, i64 %v2178) nomerge, !dbg !136
  br label %bb_rcgdone487
bb_rcgdec487:
  %v2179 = load i64, ptr %slot360, align 8
  %v2180 = load i64, ptr %slot352, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %rgep2182 = getelementptr i8, ptr %p2181, i64 -32
  store i64 %v2179, ptr %rgep2182, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear487
bb_rcgclear487:
  %v2183 = load i64, ptr %slot334, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i64 0, ptr %p2184, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone487
bb_rcgdone487:
  br label %bb_rcslotdone456
bb_rcslotdone456:
  %v2185 = load i64, ptr %slot332, align 8
  %op2186 = add i64 %v2185, 0
  store i64 %op2186, ptr %slot365, align 8
  %v2187 = load i64, ptr %slot365, align 8
  %op2188 = add i64 %v2187, 0
  store i64 %op2188, ptr %slot366, align 8
  store i64 0, ptr %slot367, align 8
  %v2189 = load i64, ptr %slot366, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i64, ptr %p2190, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2191, ptr %slot368, align 8
  %v2192 = load i64, ptr %slot368, align 8
  %cmp2193 = icmp ne i64 %v2192, 0
  %cv2194 = zext i1 %cmp2193 to i32
  store i32 %cv2194, ptr %slot369, align 8
  %v2195 = load i32, ptr %slot369, align 8
  %cv2196 = zext i32 %v2195 to i64
  %cond2197 = icmp ne i64 %cv2196, 0
  br i1 %cond2197, label %bb_rcguniquenn494, label %bb_rcgunique494
bb_rcguniquenn494:
  %v2198 = load i64, ptr %slot368, align 8
  %op2199 = sub i64 %v2198, 16
  store i64 %op2199, ptr %slot370, align 8
  %v2200 = load i64, ptr %slot368, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %rgep2202 = getelementptr i8, ptr %p2201, i64 -16
  %ld2203 = load i64, ptr %rgep2202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2203, ptr %slot371, align 8
  %v2204 = load i64, ptr %slot371, align 8
  %op2205 = and i64 %v2204, 6917529027641081858
  store i64 %op2205, ptr %slot372, align 8
  %v2206 = load i64, ptr %slot372, align 8
  %cmp2207 = icmp ne i64 %v2206, 0
  %cv2208 = zext i1 %cmp2207 to i32
  store i32 %cv2208, ptr %slot373, align 8
  %v2209 = load i32, ptr %slot373, align 8
  %cv2210 = zext i32 %v2209 to i64
  %cond2211 = icmp ne i64 %cv2210, 0
  br i1 %cond2211, label %bb_rcguniqueslow494, label %bb_rcguniquecount494
bb_rcguniquecount494:
  %v2212 = load i64, ptr %slot368, align 8
  %op2213 = sub i64 %v2212, 32
  store i64 %op2213, ptr %slot374, align 8
  %v2214 = load i64, ptr %slot368, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %rgep2216 = getelementptr i8, ptr %p2215, i64 -32
  %ld2217 = load i64, ptr %rgep2216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2217, ptr %slot375, align 8
  %v2218 = load i64, ptr %slot375, align 8
  %cmp2219 = icmp ult i64 %v2218, 2
  %cv2220 = zext i1 %cmp2219 to i32
  store i32 %cv2220, ptr %slot376, align 8
  %v2221 = load i32, ptr %slot376, align 8
  %cv2222 = zext i32 %v2221 to i64
  %cond2223 = icmp ne i64 %cv2222, 0
  br i1 %cond2223, label %bb_rcgunique494, label %bb_rcguniqueslow494
bb_rcguniqueslow494:
  %v2224 = load i64, ptr %slot1, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %p2226 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v2227 = load i64, ptr %slot366, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %v2229 = load i64, ptr %slot367, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %call2231 = call i32 @myl_qbe_rc_unique_field(ptr %p2225, ptr %p2226, ptr %p2228, ptr %p2230) nomerge, !dbg !136
  store i32 %call2231, ptr %slot377, align 8
  %v2232 = load i32, ptr %slot377, align 8
  %cv2233 = zext i32 %v2232 to i64
  %cond2234 = icmp ne i64 %cv2233, 0
  br i1 %cond2234, label %bb_rcunique504, label %bb_failure
bb_rcunique504:
  br label %bb_rcgunique494
bb_rcgunique494:
  %v2235 = load i64, ptr %slot366, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i64, ptr %p2236, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2237, ptr %slot378, align 8
  %v2238 = load i64, ptr %slot378, align 8
  %v2239 = load i64, ptr %slot33, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i64 %v2238, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  %v2241 = load i64, ptr %slot33, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %ld2243 = load i64, ptr %p2242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2243, ptr %slot379, align 8
  %v2244 = load i64, ptr %slot8, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  %ld2246 = load i32, ptr %p2245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2246, ptr %slot380, align 8
  %v2247 = load i32, ptr %slot380, align 8
  %cv2248 = zext i32 %v2247 to i64
  %cond2249 = icmp ne i64 %cv2248, 0
  br i1 %cond2249, label %bb_rcslotdrop509, label %bb_rcslotdone509
bb_rcslotdrop509:
  %v2250 = load i64, ptr %slot8, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i32 0, ptr %p2251, align 4, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot15, align 8
  store i64 %v2252, ptr %slot381, align 8
  %v2253 = load i64, ptr %slot9, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %ld2255 = load i32, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2255, ptr %slot382, align 8
  %v2256 = load i32, ptr %slot382, align 8
  %op2257 = and i32 %v2256, 28
  store i32 %op2257, ptr %slot383, align 8
  %v2258 = load i32, ptr %slot383, align 8
  %cv2259 = zext i32 %v2258 to i64
  %cond2260 = icmp ne i64 %cv2259, 0
  br i1 %cond2260, label %bb_rcslotrole509, label %bb_rcslotowner509
bb_rcslotrole509:
  %v2261 = load i64, ptr %slot37, align 8
  store i64 %v2261, ptr %slot384, align 8
  %v2262 = load i64, ptr %slot381, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  %ld2264 = load i64, ptr %p2263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2264, ptr %slot385, align 8
  %v2265 = load i64, ptr %slot385, align 8
  %cmp2266 = icmp ne i64 %v2265, 0
  %cv2267 = zext i1 %cmp2266 to i32
  store i32 %cv2267, ptr %slot386, align 8
  %v2268 = load i32, ptr %slot386, align 8
  %cv2269 = zext i32 %v2268 to i64
  %cond2270 = icmp ne i64 %cv2269, 0
  br i1 %cond2270, label %bb_rcgnn525, label %bb_rcgdone525
bb_rcgnn525:
  %v2271 = load i64, ptr %slot385, align 8
  %op2272 = sub i64 %v2271, 16
  store i64 %op2272, ptr %slot387, align 8
  %v2273 = load i64, ptr %slot385, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  %rgep2275 = getelementptr i8, ptr %p2274, i64 -16
  %ld2276 = load i64, ptr %rgep2275, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2276, ptr %slot388, align 8
  %v2277 = load i64, ptr %slot388, align 8
  %op2278 = and i64 %v2277, 4611686018427387906
  store i64 %op2278, ptr %slot389, align 8
  %v2279 = load i64, ptr %slot389, align 8
  %cmp2280 = icmp ne i64 %v2279, 0
  %cv2281 = zext i1 %cmp2280 to i32
  store i32 %cv2281, ptr %slot390, align 8
  %v2282 = load i32, ptr %slot390, align 8
  %cv2283 = zext i32 %v2282 to i64
  %cond2284 = icmp ne i64 %cv2283, 0
  br i1 %cond2284, label %bb_rcgclear525, label %bb_rcgcounted525
bb_rcgcounted525:
  %v2285 = load i64, ptr %slot385, align 8
  %op2286 = sub i64 %v2285, 24
  store i64 %op2286, ptr %slot391, align 8
  %v2287 = load i64, ptr %slot385, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  %rgep2289 = getelementptr i8, ptr %p2288, i64 -24
  %ld2290 = load i64, ptr %rgep2289, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2290, ptr %slot392, align 8
  %v2291 = load i64, ptr %slot392, align 8
  %op2292 = sub i64 %v2291, 1
  store i64 %op2292, ptr %slot393, align 8
  %v2293 = load i64, ptr %slot393, align 8
  %cmp2294 = icmp eq i64 %v2293, 0
  %cv2295 = zext i1 %cmp2294 to i32
  store i32 %cv2295, ptr %slot394, align 8
  %v2296 = load i32, ptr %slot394, align 8
  %cv2297 = zext i32 %v2296 to i64
  %cond2298 = icmp ne i64 %cv2297, 0
  br i1 %cond2298, label %bb_rcglast525, label %bb_rcgdec525
bb_rcglast525:
  %v2299 = load i64, ptr %slot385, align 8
  %op2300 = sub i64 %v2299, 32
  store i64 %op2300, ptr %slot395, align 8
  %v2301 = load i64, ptr %slot385, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %rgep2303 = getelementptr i8, ptr %p2302, i64 -32
  %ld2304 = load i64, ptr %rgep2303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2304, ptr %slot396, align 8
  %v2305 = load i64, ptr %slot396, align 8
  %cmp2306 = icmp ne i64 %v2305, 0
  %cv2307 = zext i1 %cmp2306 to i32
  store i32 %cv2307, ptr %slot397, align 8
  %v2308 = load i32, ptr %slot397, align 8
  %cv2309 = zext i32 %v2308 to i64
  %cond2310 = icmp ne i64 %cv2309, 0
  br i1 %cond2310, label %bb_rcgdec525, label %bb_rcgslow525
bb_rcgslow525:
  %v2311 = load i64, ptr %slot384, align 8
  %v2312 = load i64, ptr %slot381, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v2311, i64 %v2312) nomerge, !dbg !136
  br label %bb_rcgdone525
bb_rcgdec525:
  %v2313 = load i64, ptr %slot393, align 8
  %v2314 = load i64, ptr %slot385, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %rgep2316 = getelementptr i8, ptr %p2315, i64 -24
  store i64 %v2313, ptr %rgep2316, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear525
bb_rcgclear525:
  %v2317 = load i64, ptr %slot381, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  store i64 0, ptr %p2318, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone525
bb_rcgdone525:
  br label %bb_rcslotdone509
bb_rcslotowner509:
  %v2319 = load i64, ptr %slot37, align 8
  store i64 %v2319, ptr %slot398, align 8
  %v2320 = load i64, ptr %slot381, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  %ld2322 = load i64, ptr %p2321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2322, ptr %slot399, align 8
  %v2323 = load i64, ptr %slot399, align 8
  %cmp2324 = icmp ne i64 %v2323, 0
  %cv2325 = zext i1 %cmp2324 to i32
  store i32 %cv2325, ptr %slot400, align 8
  %v2326 = load i32, ptr %slot400, align 8
  %cv2327 = zext i32 %v2326 to i64
  %cond2328 = icmp ne i64 %cv2327, 0
  br i1 %cond2328, label %bb_rcgnn540, label %bb_rcgdone540
bb_rcgnn540:
  %v2329 = load i64, ptr %slot399, align 8
  %op2330 = sub i64 %v2329, 16
  store i64 %op2330, ptr %slot401, align 8
  %v2331 = load i64, ptr %slot399, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %rgep2333 = getelementptr i8, ptr %p2332, i64 -16
  %ld2334 = load i64, ptr %rgep2333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2334, ptr %slot402, align 8
  %v2335 = load i64, ptr %slot402, align 8
  %op2336 = and i64 %v2335, 4611686018427387906
  store i64 %op2336, ptr %slot403, align 8
  %v2337 = load i64, ptr %slot403, align 8
  %cmp2338 = icmp ne i64 %v2337, 0
  %cv2339 = zext i1 %cmp2338 to i32
  store i32 %cv2339, ptr %slot404, align 8
  %v2340 = load i32, ptr %slot404, align 8
  %cv2341 = zext i32 %v2340 to i64
  %cond2342 = icmp ne i64 %cv2341, 0
  br i1 %cond2342, label %bb_rcgclear540, label %bb_rcgcounted540
bb_rcgcounted540:
  %v2343 = load i64, ptr %slot399, align 8
  %op2344 = sub i64 %v2343, 32
  store i64 %op2344, ptr %slot405, align 8
  %v2345 = load i64, ptr %slot399, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %rgep2347 = getelementptr i8, ptr %p2346, i64 -32
  %ld2348 = load i64, ptr %rgep2347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2348, ptr %slot406, align 8
  %v2349 = load i64, ptr %slot406, align 8
  %op2350 = sub i64 %v2349, 1
  store i64 %op2350, ptr %slot407, align 8
  %v2351 = load i64, ptr %slot407, align 8
  %cmp2352 = icmp eq i64 %v2351, 0
  %cv2353 = zext i1 %cmp2352 to i32
  store i32 %cv2353, ptr %slot408, align 8
  %v2354 = load i32, ptr %slot408, align 8
  %cv2355 = zext i32 %v2354 to i64
  %cond2356 = icmp ne i64 %cv2355, 0
  br i1 %cond2356, label %bb_rcglast540, label %bb_rcgdec540
bb_rcglast540:
  %v2357 = load i64, ptr %slot399, align 8
  %op2358 = sub i64 %v2357, 24
  store i64 %op2358, ptr %slot409, align 8
  %v2359 = load i64, ptr %slot399, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %rgep2361 = getelementptr i8, ptr %p2360, i64 -24
  %ld2362 = load i64, ptr %rgep2361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2362, ptr %slot410, align 8
  %v2363 = load i64, ptr %slot410, align 8
  %cmp2364 = icmp ne i64 %v2363, 0
  %cv2365 = zext i1 %cmp2364 to i32
  store i32 %cv2365, ptr %slot411, align 8
  %v2366 = load i32, ptr %slot411, align 8
  %cv2367 = zext i32 %v2366 to i64
  %cond2368 = icmp ne i64 %cv2367, 0
  br i1 %cond2368, label %bb_rcgdec540, label %bb_rcgslow540
bb_rcgslow540:
  %v2369 = load i64, ptr %slot398, align 8
  %v2370 = load i64, ptr %slot381, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v2369, i64 %v2370) nomerge, !dbg !136
  br label %bb_rcgdone540
bb_rcgdec540:
  %v2371 = load i64, ptr %slot407, align 8
  %v2372 = load i64, ptr %slot399, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %rgep2374 = getelementptr i8, ptr %p2373, i64 -32
  store i64 %v2371, ptr %rgep2374, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear540
bb_rcgclear540:
  %v2375 = load i64, ptr %slot381, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  store i64 0, ptr %p2376, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone540
bb_rcgdone540:
  br label %bb_rcslotdone509
bb_rcslotdone509:
  %v2377 = load i64, ptr %slot21, align 8
  store i64 %v2377, ptr %slot412, align 8
  %v2378 = load i64, ptr %slot37, align 8
  %v2379 = load i64, ptr %slot412, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i64 %v2378, ptr %p2380, align 8, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot37, align 8
  %p2383 = inttoptr i64 %v2381 to ptr
  %gep2384 = getelementptr i8, ptr %p2383, i64 5640
  %op2382 = ptrtoint ptr %gep2384 to i64
  store i64 %op2382, ptr %slot413, align 8
  %v2385 = load i64, ptr %slot413, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i64, ptr %p2386, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2387, ptr %slot414, align 8
  %v2388 = load i64, ptr %slot414, align 8
  %op2389 = add i64 %v2388, 248
  store i64 %op2389, ptr %slot415, align 8
  %v2390 = load i64, ptr %slot415, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %ld2392 = load i64, ptr %p2391, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2392, ptr %slot416, align 8
  %v2393 = load i64, ptr %slot412, align 8
  %p2395 = inttoptr i64 %v2393 to ptr
  %gep2396 = getelementptr i8, ptr %p2395, i64 8
  %op2394 = ptrtoint ptr %gep2396 to i64
  store i64 %op2394, ptr %slot417, align 8
  %v2397 = load i64, ptr %slot416, align 8
  %v2398 = load i64, ptr %slot417, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot412, align 8
  %p2402 = inttoptr i64 %v2400 to ptr
  %gep2403 = getelementptr i8, ptr %p2402, i64 16
  %op2401 = ptrtoint ptr %gep2403 to i64
  store i64 %op2401, ptr %slot418, align 8
  %v2404 = load i64, ptr %slot418, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i64 0, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot37, align 8
  %p2408 = inttoptr i64 %v2406 to ptr
  %gep2409 = getelementptr i8, ptr %p2408, i64 112
  %op2407 = ptrtoint ptr %gep2409 to i64
  store i64 %op2407, ptr %slot419, align 8
  %v2410 = load i64, ptr %slot412, align 8
  %p2412 = inttoptr i64 %v2410 to ptr
  %gep2413 = getelementptr i8, ptr %p2412, i64 24
  %op2411 = ptrtoint ptr %gep2413 to i64
  store i64 %op2411, ptr %slot420, align 8
  %v2414 = load i64, ptr %slot412, align 8
  %p2416 = inttoptr i64 %v2414 to ptr
  %gep2417 = getelementptr i8, ptr %p2416, i64 28
  %op2415 = ptrtoint ptr %gep2417 to i64
  store i64 %op2415, ptr %slot421, align 8
  %v2418 = load i64, ptr %slot419, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  %ld2420 = load i32, ptr %p2419, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld2420, ptr %slot422, align 8
  %v2421 = load i64, ptr %slot420, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  store i32 1, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  %v2423 = load i32, ptr %slot422, align 8
  %v2424 = load i64, ptr %slot421, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  store i32 %v2423, ptr %p2425, align 4, !alias.scope !3, !noalias !4
  %v2426 = load i64, ptr %slot412, align 8
  %v2427 = load i64, ptr %slot415, align 8
  %p2428 = inttoptr i64 %v2427 to ptr
  store i64 %v2426, ptr %p2428, align 8, !alias.scope !9999998, !noalias !9999999
  %v2429 = load i64, ptr %slot379, align 8
  %cmp2430 = icmp ne i64 %v2429, 0
  %cv2431 = zext i1 %cmp2430 to i32
  store i32 %cv2431, ptr %slot423, align 8
  %v2432 = load i32, ptr %slot423, align 8
  %cv2433 = zext i32 %v2432 to i64
  %cond2434 = icmp ne i64 %cv2433, 0
  br i1 %cond2434, label %bb_rcspinmark592, label %bb_rcspindone592
bb_rcspinmark592:
  %v2435 = load i64, ptr %slot379, align 8
  %op2436 = sub i64 %v2435, 16
  store i64 %op2436, ptr %slot424, align 8
  %v2437 = load i64, ptr %slot379, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %rgep2439 = getelementptr i8, ptr %p2438, i64 -16
  %ld2440 = load i64, ptr %rgep2439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2440, ptr %slot425, align 8
  %v2441 = load i64, ptr %slot425, align 8
  %op2442 = and i64 %v2441, 2
  store i64 %op2442, ptr %slot426, align 8
  %v2443 = load i64, ptr %slot426, align 8
  %cmp2444 = icmp ne i64 %v2443, 0
  %cv2445 = zext i1 %cmp2444 to i32
  store i32 %cv2445, ptr %slot427, align 8
  %v2446 = load i32, ptr %slot427, align 8
  %cv2447 = zext i32 %v2446 to i64
  %cond2448 = icmp ne i64 %cv2447, 0
  br i1 %cond2448, label %bb_rcspindone592, label %bb_rcspintype592
bb_rcspintype592:
  %v2449 = load i64, ptr %slot425, align 8
  %op2450 = and i64 %v2449, 4611686018427387907
  store i64 %op2450, ptr %slot428, align 8
  %v2451 = load i64, ptr %slot428, align 8
  %cmp2452 = icmp eq i64 %v2451, 0
  %cv2453 = zext i1 %cmp2452 to i32
  store i32 %cv2453, ptr %slot429, align 8
  %v2454 = load i32, ptr %slot429, align 8
  %cv2455 = zext i32 %v2454 to i64
  %cond2456 = icmp ne i64 %cv2455, 0
  br i1 %cond2456, label %bb_rcs600, label %bb_rcspinslow592
bb_rcs600:
  %v2457 = load i64, ptr %slot379, align 8
  %op2458 = sub i64 %v2457, 8
  store i64 %op2458, ptr %slot430, align 8
  %v2459 = load i64, ptr %slot379, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %rgep2461 = getelementptr i8, ptr %p2460, i64 -8
  %ld2462 = load i64, ptr %rgep2461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2462, ptr %slot431, align 8
  %p2463 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld2464 = load i64, ptr %p2463, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2464, ptr %slot432, align 8
  %v2465 = load i64, ptr %slot431, align 8
  %v2466 = load i64, ptr %slot432, align 8
  %cmp2467 = icmp eq i64 %v2465, %v2466
  %cv2468 = zext i1 %cmp2467 to i32
  store i32 %cv2468, ptr %slot433, align 8
  %v2469 = load i32, ptr %slot433, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rcs605, label %bb_rcspinslow592
bb_rcs605:
  %v2472 = load i64, ptr %slot37, align 8
  %p2474 = inttoptr i64 %v2472 to ptr
  %gep2475 = getelementptr i8, ptr %p2474, i64 5640
  %op2473 = ptrtoint ptr %gep2475 to i64
  store i64 %op2473, ptr %slot434, align 8
  %v2476 = load i64, ptr %slot434, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %ld2478 = load i64, ptr %p2477, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2478, ptr %slot435, align 8
  %v2479 = load i64, ptr %slot435, align 8
  %op2480 = add i64 %v2479, 256
  store i64 %op2480, ptr %slot436, align 8
  %v2481 = load i64, ptr %slot436, align 8
  %p2482 = inttoptr i64 %v2481 to ptr
  %ld2483 = load i64, ptr %p2482, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2483, ptr %slot437, align 8
  %v2484 = load i64, ptr %slot437, align 8
  %cmp2485 = icmp ne i64 %v2484, 0
  %cv2486 = zext i1 %cmp2485 to i32
  store i32 %cv2486, ptr %slot438, align 8
  %v2487 = load i32, ptr %slot438, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcs611, label %bb_rcspinslow592
bb_rcs611:
  %v2490 = load i64, ptr %slot37, align 8
  %p2492 = inttoptr i64 %v2490 to ptr
  %gep2493 = getelementptr i8, ptr %p2492, i64 24
  %op2491 = ptrtoint ptr %gep2493 to i64
  store i64 %op2491, ptr %slot439, align 8
  %v2494 = load i64, ptr %slot439, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %ld2496 = load i64, ptr %p2495, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2496, ptr %slot440, align 8
  %v2497 = load i64, ptr %slot440, align 8
  %op2498 = add i64 %v2497, 40
  store i64 %op2498, ptr %slot441, align 8
  %v2499 = load i64, ptr %slot441, align 8
  %v2500 = load i64, ptr %slot440, align 8
  %cmp2501 = icmp uge i64 %v2499, %v2500
  %cv2502 = zext i1 %cmp2501 to i32
  store i32 %cv2502, ptr %slot442, align 8
  %v2503 = load i32, ptr %slot442, align 8
  %cv2504 = zext i32 %v2503 to i64
  %cond2505 = icmp ne i64 %cv2504, 0
  br i1 %cond2505, label %bb_rcs616, label %bb_rcspinslow592
bb_rcs616:
  %v2506 = load i64, ptr %slot37, align 8
  %p2508 = inttoptr i64 %v2506 to ptr
  %gep2509 = getelementptr i8, ptr %p2508, i64 88
  %op2507 = ptrtoint ptr %gep2509 to i64
  store i64 %op2507, ptr %slot443, align 8
  %v2510 = load i64, ptr %slot443, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %ld2512 = load i64, ptr %p2511, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2512, ptr %slot444, align 8
  %v2513 = load i64, ptr %slot444, align 8
  %cmp2514 = icmp eq i64 %v2513, 0
  %cv2515 = zext i1 %cmp2514 to i32
  store i32 %cv2515, ptr %slot445, align 8
  %v2516 = load i64, ptr %slot441, align 8
  %v2517 = load i64, ptr %slot444, align 8
  %cmp2518 = icmp ule i64 %v2516, %v2517
  %cv2519 = zext i1 %cmp2518 to i32
  store i32 %cv2519, ptr %slot446, align 8
  %v2520 = load i32, ptr %slot445, align 8
  %v2521 = load i32, ptr %slot446, align 8
  %op2522 = or i32 %v2520, %v2521
  store i32 %op2522, ptr %slot447, align 8
  %v2523 = load i32, ptr %slot447, align 8
  %cv2524 = zext i32 %v2523 to i64
  %cond2525 = icmp ne i64 %cv2524, 0
  br i1 %cond2525, label %bb_rcs622, label %bb_rcspinslow592
bb_rcs622:
  %v2526 = load i64, ptr %slot379, align 8
  %op2527 = sub i64 %v2526, 24
  store i64 %op2527, ptr %slot448, align 8
  %v2528 = load i64, ptr %slot379, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %rgep2530 = getelementptr i8, ptr %p2529, i64 -24
  %ld2531 = load i64, ptr %rgep2530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2531, ptr %slot449, align 8
  %v2532 = load i64, ptr %slot449, align 8
  %cmp2533 = icmp ne i64 %v2532, 18446744073709551615
  %cv2534 = zext i1 %cmp2533 to i32
  store i32 %cv2534, ptr %slot450, align 8
  %v2535 = load i32, ptr %slot450, align 8
  %cv2536 = zext i32 %v2535 to i64
  %cond2537 = icmp ne i64 %cv2536, 0
  br i1 %cond2537, label %bb_rcs626, label %bb_rcspinslow592
bb_rcs626:
  %v2538 = load i64, ptr %slot379, align 8
  %op2539 = add i64 %v2538, 32
  store i64 %op2539, ptr %slot451, align 8
  %v2540 = load i64, ptr %slot451, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i64, ptr %p2541, align 8
  store i64 %ld2542, ptr %slot452, align 8
  %v2543 = load i64, ptr %slot452, align 8
  %cmp2544 = icmp ne i64 %v2543, 0
  %cv2545 = zext i1 %cmp2544 to i32
  store i32 %cv2545, ptr %slot453, align 8
  %v2546 = load i32, ptr %slot453, align 8
  %cv2547 = zext i32 %v2546 to i64
  %cond2548 = icmp ne i64 %cv2547, 0
  br i1 %cond2548, label %bb_rcspinbacking592, label %bb_rcspincommit592
bb_rcspinbacking592:
  %v2549 = load i64, ptr %slot452, align 8
  %op2550 = sub i64 %v2549, 16
  store i64 %op2550, ptr %slot454, align 8
  %v2551 = load i64, ptr %slot452, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %rgep2553 = getelementptr i8, ptr %p2552, i64 -16
  %ld2554 = load i64, ptr %rgep2553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2554, ptr %slot455, align 8
  %v2555 = load i64, ptr %slot455, align 8
  %op2556 = and i64 %v2555, 4611686018427387907
  store i64 %op2556, ptr %slot456, align 8
  %v2557 = load i64, ptr %slot456, align 8
  %cmp2558 = icmp eq i64 %v2557, 0
  %cv2559 = zext i1 %cmp2558 to i32
  store i32 %cv2559, ptr %slot457, align 8
  %v2560 = load i32, ptr %slot457, align 8
  %cv2561 = zext i32 %v2560 to i64
  %cond2562 = icmp ne i64 %cv2561, 0
  br i1 %cond2562, label %bb_rcs634, label %bb_rcspinslow592
bb_rcs634:
  %v2563 = load i64, ptr %slot452, align 8
  %op2564 = sub i64 %v2563, 24
  store i64 %op2564, ptr %slot458, align 8
  %v2565 = load i64, ptr %slot452, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  %rgep2567 = getelementptr i8, ptr %p2566, i64 -24
  %ld2568 = load i64, ptr %rgep2567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2568, ptr %slot459, align 8
  %v2569 = load i64, ptr %slot459, align 8
  %cmp2570 = icmp ne i64 %v2569, 18446744073709551615
  %cv2571 = zext i1 %cmp2570 to i32
  store i32 %cv2571, ptr %slot460, align 8
  %v2572 = load i32, ptr %slot460, align 8
  %cv2573 = zext i32 %v2572 to i64
  %cond2574 = icmp ne i64 %cv2573, 0
  br i1 %cond2574, label %bb_rcs638, label %bb_rcspinslow592
bb_rcs638:
  br label %bb_rcspincommit592
bb_rcspincommit592:
  %v2575 = load i64, ptr %slot437, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  %ld2577 = load i64, ptr %p2576, align 8
  store i64 %ld2577, ptr %slot461, align 8
  %v2578 = load i64, ptr %slot435, align 8
  %op2579 = add i64 %v2578, 256
  store i64 %op2579, ptr %slot462, align 8
  %v2580 = load i64, ptr %slot461, align 8
  %v2581 = load i64, ptr %slot462, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i64 %v2580, ptr %p2582, align 8, !alias.scope !9999998, !noalias !9999999
  %v2583 = load i64, ptr %slot435, align 8
  %op2584 = add i64 %v2583, 264
  store i64 %op2584, ptr %slot463, align 8
  %v2585 = load i64, ptr %slot463, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  %ld2587 = load i64, ptr %p2586, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2587, ptr %slot464, align 8
  %v2588 = load i64, ptr %slot464, align 8
  %op2589 = add i64 %v2588, 18446744073709551615
  store i64 %op2589, ptr %slot465, align 8
  %v2590 = load i64, ptr %slot465, align 8
  %v2591 = load i64, ptr %slot463, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  store i64 %v2590, ptr %p2592, align 8, !alias.scope !9999998, !noalias !9999999
  %v2593 = load i64, ptr %slot37, align 8
  %p2595 = inttoptr i64 %v2593 to ptr
  %gep2596 = getelementptr i8, ptr %p2595, i64 24
  %op2594 = ptrtoint ptr %gep2596 to i64
  store i64 %op2594, ptr %slot466, align 8
  %v2597 = load i64, ptr %slot466, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  %ld2599 = load i64, ptr %p2598, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2599, ptr %slot467, align 8
  %v2600 = load i64, ptr %slot467, align 8
  %op2601 = add i64 %v2600, 40
  store i64 %op2601, ptr %slot468, align 8
  %v2602 = load i64, ptr %slot468, align 8
  %v2603 = load i64, ptr %slot466, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  store i64 %v2602, ptr %p2604, align 8, !alias.scope !9999998, !noalias !9999999
  %v2605 = load i64, ptr %slot435, align 8
  %op2606 = add i64 %v2605, 48
  store i64 %op2606, ptr %slot469, align 8
  %v2607 = load i64, ptr %slot469, align 8
  %p2608 = inttoptr i64 %v2607 to ptr
  %ld2609 = load i64, ptr %p2608, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2609, ptr %slot470, align 8
  %v2610 = load i64, ptr %slot470, align 8
  %op2611 = add i64 %v2610, 40
  store i64 %op2611, ptr %slot471, align 8
  %v2612 = load i64, ptr %slot471, align 8
  %v2613 = load i64, ptr %slot469, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i64 %v2612, ptr %p2614, align 8, !alias.scope !9999998, !noalias !9999999
  %v2615 = load i64, ptr %slot379, align 8
  %op2616 = sub i64 %v2615, 24
  store i64 %op2616, ptr %slot472, align 8
  %v2617 = load i64, ptr %slot379, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %rgep2619 = getelementptr i8, ptr %p2618, i64 -24
  %ld2620 = load i64, ptr %rgep2619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2620, ptr %slot473, align 8
  %v2621 = load i64, ptr %slot473, align 8
  %op2622 = add i64 %v2621, 1
  store i64 %op2622, ptr %slot474, align 8
  %v2623 = load i64, ptr %slot474, align 8
  %v2624 = load i64, ptr %slot379, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  %rgep2626 = getelementptr i8, ptr %p2625, i64 -24
  store i64 %v2623, ptr %rgep2626, align 8, !alias.scope !9, !noalias !10
  %v2627 = load i64, ptr %slot452, align 8
  %cmp2628 = icmp ne i64 %v2627, 0
  %cv2629 = zext i1 %cmp2628 to i32
  store i32 %cv2629, ptr %slot475, align 8
  %v2630 = load i32, ptr %slot475, align 8
  %cv2631 = zext i32 %v2630 to i64
  %cond2632 = icmp ne i64 %cv2631, 0
  br i1 %cond2632, label %bb_rcspinhold592, label %bb_rcspinjournal592
bb_rcspinhold592:
  %v2633 = load i64, ptr %slot452, align 8
  %op2634 = sub i64 %v2633, 24
  store i64 %op2634, ptr %slot476, align 8
  %v2635 = load i64, ptr %slot452, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  %rgep2637 = getelementptr i8, ptr %p2636, i64 -24
  %ld2638 = load i64, ptr %rgep2637, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2638, ptr %slot477, align 8
  %v2639 = load i64, ptr %slot477, align 8
  %op2640 = add i64 %v2639, 1
  store i64 %op2640, ptr %slot478, align 8
  %v2641 = load i64, ptr %slot478, align 8
  %v2642 = load i64, ptr %slot452, align 8
  %p2643 = inttoptr i64 %v2642 to ptr
  %rgep2644 = getelementptr i8, ptr %p2643, i64 -24
  store i64 %v2641, ptr %rgep2644, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal592
bb_rcspinjournal592:
  %v2645 = load i64, ptr %slot425, align 8
  %op2646 = and i64 %v2645, 1152921504606846976
  store i64 %op2646, ptr %slot479, align 8
  %v2647 = load i64, ptr %slot425, align 8
  %op2648 = or i64 %v2647, 1152921504606846976
  store i64 %op2648, ptr %slot480, align 8
  %v2649 = load i64, ptr %slot379, align 8
  %op2650 = sub i64 %v2649, 16
  store i64 %op2650, ptr %slot481, align 8
  %v2651 = load i64, ptr %slot480, align 8
  %v2652 = load i64, ptr %slot379, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %rgep2654 = getelementptr i8, ptr %p2653, i64 -16
  store i64 %v2651, ptr %rgep2654, align 8, !alias.scope !9, !noalias !10
  %v2655 = load i64, ptr %slot412, align 8
  %p2657 = inttoptr i64 %v2655 to ptr
  %gep2658 = getelementptr i8, ptr %p2657, i64 16
  %op2656 = ptrtoint ptr %gep2658 to i64
  store i64 %op2656, ptr %slot482, align 8
  %v2659 = load i64, ptr %slot482, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %ld2661 = load i64, ptr %p2660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2661, ptr %slot483, align 8
  %v2662 = load i64, ptr %slot437, align 8
  %op2663 = add i64 %v2662, 0
  store i64 %op2663, ptr %slot484, align 8
  %v2664 = load i64, ptr %slot483, align 8
  %v2665 = load i64, ptr %slot484, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i64 %v2664, ptr %p2666, align 8, !alias.scope !9999998, !noalias !9999999
  %v2667 = load i64, ptr %slot437, align 8
  %op2668 = add i64 %v2667, 8
  store i64 %op2668, ptr %slot485, align 8
  %v2669 = load i64, ptr %slot379, align 8
  %v2670 = load i64, ptr %slot485, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i64 %v2669, ptr %p2671, align 8, !alias.scope !9999998, !noalias !9999999
  %v2672 = load i64, ptr %slot437, align 8
  %op2673 = add i64 %v2672, 16
  store i64 %op2673, ptr %slot486, align 8
  %v2674 = load i64, ptr %slot479, align 8
  %v2675 = load i64, ptr %slot486, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  store i64 %v2674, ptr %p2676, align 8, !alias.scope !9999998, !noalias !9999999
  %v2677 = load i64, ptr %slot437, align 8
  %op2678 = add i64 %v2677, 24
  store i64 %op2678, ptr %slot487, align 8
  %v2679 = load i64, ptr %slot487, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  store i32 1, ptr %p2680, align 4, !alias.scope !9999998, !noalias !9999999
  %v2681 = load i64, ptr %slot437, align 8
  %op2682 = add i64 %v2681, 32
  store i64 %op2682, ptr %slot488, align 8
  %v2683 = load i64, ptr %slot452, align 8
  %v2684 = load i64, ptr %slot488, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i64 %v2683, ptr %p2685, align 8, !alias.scope !9999998, !noalias !9999999
  %v2686 = load i64, ptr %slot412, align 8
  %p2688 = inttoptr i64 %v2686 to ptr
  %gep2689 = getelementptr i8, ptr %p2688, i64 16
  %op2687 = ptrtoint ptr %gep2689 to i64
  store i64 %op2687, ptr %slot489, align 8
  %v2690 = load i64, ptr %slot437, align 8
  %v2691 = load i64, ptr %slot489, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i64 %v2690, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone592
bb_rcspinslow592:
  %v2693 = load i64, ptr %slot1, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  %v2695 = load i64, ptr %slot412, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  %v2697 = load i64, ptr %slot379, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %call2699 = call i32 @myl_qbe_rc_scope_pin(ptr %p2694, ptr %p2696, ptr %p2698) nomerge, !dbg !136
  store i32 %call2699, ptr %slot490, align 8
  %v2700 = load i32, ptr %slot490, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcunique669, label %bb_failure
bb_rcunique669:
  br label %bb_rcspindone592
bb_rcspindone592:
  %v2703 = load i64, ptr %slot379, align 8
  %v2704 = load i64, ptr %slot30, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i64 %v2703, ptr %p2705, align 8, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot26, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %ld2708 = load i64, ptr %p2707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2708, ptr %slot491, align 8
  %v2709 = load i64, ptr %slot491, align 8
  %v2710 = load i64, ptr %slot33, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  store i64 %v2709, ptr %p2711, align 8, !alias.scope !3, !noalias !4
  %v2712 = load i64, ptr %slot33, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  %ld2714 = load i64, ptr %p2713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2714, ptr %slot492, align 8
  %v2715 = load i64, ptr %slot492, align 8
  %op2716 = add i64 %v2715, 48
  store i64 %op2716, ptr %slot493, align 8
  %v2717 = load i64, ptr %slot493, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %ld2719 = load i64, ptr %p2718, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2719, ptr %slot494, align 8
  %v2720 = load i64, ptr %slot494, align 8
  %v2721 = load i64, ptr %slot33, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i64 %v2720, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot8, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %ld2725 = load i32, ptr %p2724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2725, ptr %slot495, align 8
  %v2726 = load i32, ptr %slot495, align 8
  %cv2727 = zext i32 %v2726 to i64
  %cond2728 = icmp ne i64 %cv2727, 0
  br i1 %cond2728, label %bb_rcslotdrop676, label %bb_rcslotdone676
bb_rcslotdrop676:
  %v2729 = load i64, ptr %slot8, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  store i32 0, ptr %p2730, align 4, !alias.scope !3, !noalias !4
  %v2731 = load i64, ptr %slot15, align 8
  store i64 %v2731, ptr %slot496, align 8
  %v2732 = load i64, ptr %slot9, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  %ld2734 = load i32, ptr %p2733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2734, ptr %slot497, align 8
  %v2735 = load i32, ptr %slot497, align 8
  %op2736 = and i32 %v2735, 28
  store i32 %op2736, ptr %slot498, align 8
  %v2737 = load i32, ptr %slot498, align 8
  %cv2738 = zext i32 %v2737 to i64
  %cond2739 = icmp ne i64 %cv2738, 0
  br i1 %cond2739, label %bb_rcslotrole676, label %bb_rcslotowner676
bb_rcslotrole676:
  %v2740 = load i64, ptr %slot37, align 8
  store i64 %v2740, ptr %slot499, align 8
  %v2741 = load i64, ptr %slot499, align 8
  %v2742 = load i64, ptr %slot496, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2741, i64 %v2742) nomerge, !dbg !138
  br label %bb_rcslotdone676
bb_rcslotowner676:
  %v2743 = load i64, ptr %slot37, align 8
  store i64 %v2743, ptr %slot500, align 8
  %v2744 = load i64, ptr %slot500, align 8
  %v2745 = load i64, ptr %slot496, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2744, i64 %v2745) nomerge, !dbg !138
  br label %bb_rcslotdone676
bb_rcslotdone676:
  %v2746 = load i64, ptr %slot33, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  %ld2748 = load i64, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2748, ptr %slot501, align 8
  %v2749 = load i64, ptr %slot501, align 8
  %v2750 = load i64, ptr %slot32, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i64 %v2749, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  %v2752 = load i64, ptr %slot32, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %ld2754 = load i64, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2754, ptr %slot502, align 8
  %v2755 = load i64, ptr %slot502, align 8
  %v2756 = load i64, ptr %slot33, align 8
  %p2757 = inttoptr i64 %v2756 to ptr
  store i64 %v2755, ptr %p2757, align 8, !alias.scope !3, !noalias !4
  %v2758 = load i64, ptr %slot34, align 8
  %p2759 = inttoptr i64 %v2758 to ptr
  store i64 0, ptr %p2759, align 8, !alias.scope !3, !noalias !4
  %v2760 = load i64, ptr %slot34, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %ld2762 = load i64, ptr %p2761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2762, ptr %slot503, align 8
  %v2763 = load i64, ptr %slot33, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot504, align 8
  %v2766 = load i64, ptr %slot504, align 8
  %v2767 = load i64, ptr %slot503, align 8
  %cmp2768 = icmp slt i64 %v2766, %v2767
  %cv2769 = zext i1 %cmp2768 to i64
  store i64 %cv2769, ptr %slot505, align 8
  %v2770 = load i64, ptr %slot505, align 8
  %v2771 = load i64, ptr %slot33, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 %v2770, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot33, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %ld2775 = load i64, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2775, ptr %slot506, align 8
  %v2776 = load i64, ptr %slot506, align 8
  %cond2777 = icmp ne i64 %v2776, 0
  br i1 %cond2777, label %bb_next689, label %bb_i42
bb_next689:
  %v2778 = load i64, ptr %slot30, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  %ld2780 = load i64, ptr %p2779, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2780, ptr %slot507, align 8
  %v2781 = load i64, ptr %slot507, align 8
  %op2782 = add i64 %v2781, 0
  store i64 %op2782, ptr %slot508, align 8
  %v2783 = load i64, ptr %slot508, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  %ld2785 = load i64, ptr %p2784, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2785, ptr %slot509, align 8
  %v2786 = load i64, ptr %slot509, align 8
  %v2787 = load i64, ptr %slot33, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  store i64 %v2786, ptr %p2788, align 8, !alias.scope !3, !noalias !4
  %v2789 = load i64, ptr %slot33, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  %ld2791 = load i64, ptr %p2790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2791, ptr %slot510, align 8
  %v2792 = load i64, ptr %slot510, align 8
  %cmp2793 = icmp ugt i64 %v2792, 9223372036854775807
  %cv2794 = zext i1 %cmp2793 to i64
  store i64 %cv2794, ptr %slot511, align 8
  %v2795 = load i64, ptr %slot511, align 8
  %cond2796 = icmp ne i64 %v2795, 0
  br i1 %cond2796, label %bb_cast_overflow694, label %bb_cast_ok694
bb_cast_overflow694:
  %v2797 = load i64, ptr %slot1, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %v2799 = load i64, ptr %slot510, align 8
  call void @myl_qbe_fail_cast(ptr %p2798, i64 %v2799, i64 320) nomerge, !dbg !140
  unreachable
bb_cast_ok694:
  %v2800 = load i64, ptr %slot510, align 8
  %v2801 = load i64, ptr %slot33, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i64 %v2800, ptr %p2802, align 8, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot32, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  %ld2805 = load i64, ptr %p2804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2805, ptr %slot512, align 8
  %v2806 = load i64, ptr %slot512, align 8
  %v2807 = load i64, ptr %slot34, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  store i64 %v2806, ptr %p2808, align 8, !alias.scope !3, !noalias !4
  %v2809 = load i64, ptr %slot34, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  %ld2811 = load i64, ptr %p2810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2811, ptr %slot513, align 8
  %v2812 = load i64, ptr %slot33, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  %ld2814 = load i64, ptr %p2813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2814, ptr %slot514, align 8
  %v2815 = load i64, ptr %slot514, align 8
  %v2816 = load i64, ptr %slot513, align 8
  %ovpair2818 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2815, i64 %v2816)
  %op2817 = extractvalue { i64, i1 } %ovpair2818, 0
  %ov2819 = extractvalue { i64, i1 } %ovpair2818, 1
  store i64 %op2817, ptr %slot515, align 8
  %v2820 = load i64, ptr %slot514, align 8
  %v2821 = load i64, ptr %slot515, align 8
  %op2822 = xor i64 %v2820, %v2821
  store i64 %op2822, ptr %slot516, align 8
  %v2823 = load i64, ptr %slot513, align 8
  %v2824 = load i64, ptr %slot515, align 8
  %op2825 = xor i64 %v2823, %v2824
  store i64 %op2825, ptr %slot517, align 8
  %v2826 = load i64, ptr %slot516, align 8
  %v2827 = load i64, ptr %slot517, align 8
  %op2828 = and i64 %v2826, %v2827
  store i64 %op2828, ptr %slot518, align 8
  %cv2829 = zext i1 %ov2819 to i64
  store i64 %cv2829, ptr %slot519, align 8
  %v2830 = load i64, ptr %slot519, align 8
  %cond2831 = icmp ne i64 %v2830, 0
  br i1 %cond2831, label %bb_overflow698, label %bb_checked698
bb_overflow698:
  %v2832 = load i64, ptr %slot1, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %v2834 = load i64, ptr %slot514, align 8
  %v2835 = load i64, ptr %slot513, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2833, i64 0, i64 %v2834, i64 %v2835, i64 64) nomerge, !dbg !142
  unreachable
bb_checked698:
  %v2836 = load i64, ptr %slot515, align 8
  %v2837 = load i64, ptr %slot33, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  store i64 %v2836, ptr %p2838, align 8, !alias.scope !3, !noalias !4
  %v2839 = load i64, ptr %slot33, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  %ld2841 = load i64, ptr %p2840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2841, ptr %slot520, align 8
  %v2842 = load i64, ptr %slot520, align 8
  %v2843 = load i64, ptr %slot32, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i64 %v2842, ptr %p2844, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  %v2845 = load i64, ptr %slot32, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  %ld2847 = load i64, ptr %p2846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2847, ptr %slot521, align 8
  %v2848 = load i64, ptr %slot521, align 8
  %v2849 = load i64, ptr %slot33, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  store i64 %v2848, ptr %p2850, align 8, !alias.scope !3, !noalias !4
  %v2851 = load i64, ptr %slot31, align 8
  %v2852 = load i64, ptr %slot36, align 8
  %p2853 = inttoptr i64 %v2851 to ptr
  %p2854 = inttoptr i64 %v2852 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2854, ptr %p2853, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot36, align 8
  %v2856 = load i64, ptr %slot34, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  store i64 %v2855, ptr %p2857, align 8, !alias.scope !3, !noalias !4
  %v2858 = load i64, ptr %slot30, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %ld2860 = load i64, ptr %p2859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2860, ptr %slot522, align 8
  %v2861 = load i64, ptr %slot34, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %ld2863 = load i64, ptr %p2862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2863, ptr %slot523, align 8
  %v2864 = load i64, ptr %slot33, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  %ld2866 = load i64, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2866, ptr %slot524, align 8
  %v2867 = load i64, ptr %slot522, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %ld2869 = load i64, ptr %p2868, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2869, ptr %slot525, align 8
  %v2870 = load i64, ptr %slot524, align 8
  %v2871 = load i64, ptr %slot525, align 8
  %cmp2872 = icmp ult i64 %v2870, %v2871
  %cv2873 = zext i1 %cmp2872 to i64
  store i64 %cv2873, ptr %slot526, align 8
  %v2874 = load i64, ptr %slot526, align 8
  %cond2875 = icmp ne i64 %v2874, 0
  br i1 %cond2875, label %bb_success711, label %bb_failed711
bb_failed711:
  %v2876 = load i64, ptr %slot1, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %v2878 = load i64, ptr %slot524, align 8
  %v2879 = load i64, ptr %slot525, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2877, i64 %v2878, i64 %v2879) nomerge, !dbg !144
  unreachable
bb_success711:
  %v2880 = load i64, ptr %slot34, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %ld2882 = load i64, ptr %p2881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2882, ptr %slot527, align 8
  %v2883 = load i64, ptr %slot37, align 8
  %v2884 = load i64, ptr %slot522, align 8
  %v2885 = load i64, ptr %slot524, align 8
  %v2886 = load i64, ptr %slot527, align 8
  %call2887 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v2883, i64 %v2884, i64 %v2885, i64 %v2886) nomerge, !dbg !144
  store i32 %call2887, ptr %slot528, align 8
  %v2888 = load i32, ptr %slot528, align 8
  %cv2889 = zext i32 %v2888 to i64
  %cond2890 = icmp ne i64 %cv2889, 0
  br i1 %cond2890, label %bb_success714, label %bb_failed714
bb_failed714:
  %v2891 = load i64, ptr %slot1, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2892) nomerge, !dbg !144
  unreachable
bb_success714:
  %v2893 = load i64, ptr %slot33, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  store i64 0, ptr %p2894, align 8, !alias.scope !3, !noalias !4
  %v2895 = load i64, ptr %slot10, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  %ld2897 = load i32, ptr %p2896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2897, ptr %slot529, align 8
  %v2898 = load i32, ptr %slot529, align 8
  %cv2899 = zext i32 %v2898 to i64
  %cond2900 = icmp ne i64 %cv2899, 0
  br i1 %cond2900, label %bb_rcslotdrop717, label %bb_rcslotdone717
bb_rcslotdrop717:
  %v2901 = load i64, ptr %slot10, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  store i32 0, ptr %p2902, align 4, !alias.scope !3, !noalias !4
  %v2903 = load i64, ptr %slot16, align 8
  store i64 %v2903, ptr %slot530, align 8
  %v2904 = load i64, ptr %slot11, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %ld2906 = load i32, ptr %p2905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2906, ptr %slot531, align 8
  %v2907 = load i32, ptr %slot531, align 8
  %op2908 = and i32 %v2907, 28
  store i32 %op2908, ptr %slot532, align 8
  %v2909 = load i32, ptr %slot532, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcslotrole717, label %bb_rcslotowner717
bb_rcslotrole717:
  %v2912 = load i64, ptr %slot37, align 8
  store i64 %v2912, ptr %slot533, align 8
  %v2913 = load i64, ptr %slot533, align 8
  %v2914 = load i64, ptr %slot530, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2913, i64 %v2914) nomerge, !dbg !144
  br label %bb_rcslotdone717
bb_rcslotowner717:
  %v2915 = load i64, ptr %slot37, align 8
  store i64 %v2915, ptr %slot534, align 8
  %v2916 = load i64, ptr %slot534, align 8
  %v2917 = load i64, ptr %slot530, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2916, i64 %v2917) nomerge, !dbg !144
  br label %bb_rcslotdone717
bb_rcslotdone717:
  %v2918 = load i64, ptr %slot21, align 8
  store i64 %v2918, ptr %slot535, align 8
  %v2919 = load i64, ptr %slot535, align 8
  %p2921 = inttoptr i64 %v2919 to ptr
  %gep2922 = getelementptr i8, ptr %p2921, i64 24
  %op2920 = ptrtoint ptr %gep2922 to i64
  store i64 %op2920, ptr %slot536, align 8
  %v2923 = load i64, ptr %slot536, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %ld2925 = load i32, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2925, ptr %slot537, align 8
  %v2926 = load i32, ptr %slot537, align 8
  %cv2927 = zext i32 %v2926 to i64
  %cond2928 = icmp ne i64 %cv2927, 0
  br i1 %cond2928, label %bb_rcsendactive725, label %bb_rcsenddone725
bb_rcsendactive725:
  %v2929 = load i64, ptr %slot37, align 8
  %p2931 = inttoptr i64 %v2929 to ptr
  %gep2932 = getelementptr i8, ptr %p2931, i64 5640
  %op2930 = ptrtoint ptr %gep2932 to i64
  store i64 %op2930, ptr %slot538, align 8
  %v2933 = load i64, ptr %slot538, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %ld2935 = load i64, ptr %p2934, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2935, ptr %slot539, align 8
  %v2936 = load i64, ptr %slot539, align 8
  %op2937 = add i64 %v2936, 248
  store i64 %op2937, ptr %slot540, align 8
  %v2938 = load i64, ptr %slot540, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %ld2940 = load i64, ptr %p2939, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2940, ptr %slot541, align 8
  %v2941 = load i64, ptr %slot541, align 8
  %v2942 = load i64, ptr %slot535, align 8
  %cmp2943 = icmp eq i64 %v2941, %v2942
  %cv2944 = zext i1 %cmp2943 to i32
  store i32 %cv2944, ptr %slot542, align 8
  %v2945 = load i32, ptr %slot542, align 8
  %cv2946 = zext i32 %v2945 to i64
  %cond2947 = icmp ne i64 %cv2946, 0
  br i1 %cond2947, label %bb_rcs733, label %bb_rcsendslow725
bb_rcs733:
  %v2948 = load i64, ptr %slot539, align 8
  %op2949 = add i64 %v2948, 200
  store i64 %op2949, ptr %slot543, align 8
  %v2950 = load i64, ptr %slot543, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  %ld2952 = load i64, ptr %p2951, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2952, ptr %slot544, align 8
  %v2953 = load i64, ptr %slot544, align 8
  %cmp2954 = icmp eq i64 %v2953, 0
  %cv2955 = zext i1 %cmp2954 to i32
  store i32 %cv2955, ptr %slot545, align 8
  %v2956 = load i32, ptr %slot545, align 8
  %cv2957 = zext i32 %v2956 to i64
  %cond2958 = icmp ne i64 %cv2957, 0
  br i1 %cond2958, label %bb_rcs737, label %bb_rcsendslow725
bb_rcs737:
  %v2959 = load i64, ptr %slot535, align 8
  %p2961 = inttoptr i64 %v2959 to ptr
  %gep2962 = getelementptr i8, ptr %p2961, i64 16
  %op2960 = ptrtoint ptr %gep2962 to i64
  store i64 %op2960, ptr %slot546, align 8
  %v2963 = load i64, ptr %slot546, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %ld2965 = load i64, ptr %p2964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2965, ptr %slot547, align 8
  %v2966 = load i64, ptr %slot547, align 8
  %cmp2967 = icmp ne i64 %v2966, 0
  %cv2968 = zext i1 %cmp2967 to i32
  store i32 %cv2968, ptr %slot548, align 8
  %v2969 = load i32, ptr %slot548, align 8
  %cv2970 = zext i32 %v2969 to i64
  %cond2971 = icmp ne i64 %cv2970, 0
  br i1 %cond2971, label %bb_rcsendnode725, label %bb_rcsendunlink725
bb_rcsendnode725:
  %v2972 = load i64, ptr %slot547, align 8
  %op2973 = add i64 %v2972, 0
  store i64 %op2973, ptr %slot549, align 8
  %v2974 = load i64, ptr %slot549, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  %ld2976 = load i64, ptr %p2975, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2976, ptr %slot550, align 8
  %v2977 = load i64, ptr %slot550, align 8
  %cmp2978 = icmp eq i64 %v2977, 0
  %cv2979 = zext i1 %cmp2978 to i32
  store i32 %cv2979, ptr %slot551, align 8
  %v2980 = load i32, ptr %slot551, align 8
  %cv2981 = zext i32 %v2980 to i64
  %cond2982 = icmp ne i64 %cv2981, 0
  br i1 %cond2982, label %bb_rcs744, label %bb_rcsendslow725
bb_rcs744:
  %v2983 = load i64, ptr %slot539, align 8
  %op2984 = add i64 %v2983, 264
  store i64 %op2984, ptr %slot552, align 8
  %v2985 = load i64, ptr %slot552, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %ld2987 = load i64, ptr %p2986, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2987, ptr %slot553, align 8
  %v2988 = load i64, ptr %slot553, align 8
  %cmp2989 = icmp ult i64 %v2988, 32
  %cv2990 = zext i1 %cmp2989 to i32
  store i32 %cv2990, ptr %slot554, align 8
  %v2991 = load i32, ptr %slot554, align 8
  %cv2992 = zext i32 %v2991 to i64
  %cond2993 = icmp ne i64 %cv2992, 0
  br i1 %cond2993, label %bb_rcs748, label %bb_rcsendslow725
bb_rcs748:
  %v2994 = load i64, ptr %slot547, align 8
  %op2995 = add i64 %v2994, 8
  store i64 %op2995, ptr %slot555, align 8
  %v2996 = load i64, ptr %slot555, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %ld2998 = load i64, ptr %p2997, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2998, ptr %slot556, align 8
  %v2999 = load i64, ptr %slot556, align 8
  %cmp3000 = icmp ne i64 %v2999, 0
  %cv3001 = zext i1 %cmp3000 to i32
  store i32 %cv3001, ptr %slot557, align 8
  %v3002 = load i32, ptr %slot557, align 8
  %cv3003 = zext i32 %v3002 to i64
  %cond3004 = icmp ne i64 %cv3003, 0
  br i1 %cond3004, label %bb_rcs752, label %bb_rcsendslow725
bb_rcs752:
  %v3005 = load i64, ptr %slot556, align 8
  %op3006 = sub i64 %v3005, 16
  store i64 %op3006, ptr %slot558, align 8
  %v3007 = load i64, ptr %slot556, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %rgep3009 = getelementptr i8, ptr %p3008, i64 -16
  %ld3010 = load i64, ptr %rgep3009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3010, ptr %slot559, align 8
  %v3011 = load i64, ptr %slot559, align 8
  %op3012 = and i64 %v3011, 4611686018427387907
  store i64 %op3012, ptr %slot560, align 8
  %v3013 = load i64, ptr %slot560, align 8
  %cmp3014 = icmp eq i64 %v3013, 0
  %cv3015 = zext i1 %cmp3014 to i32
  store i32 %cv3015, ptr %slot561, align 8
  %v3016 = load i32, ptr %slot561, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcs757, label %bb_rcsendslow725
bb_rcs757:
  %v3019 = load i64, ptr %slot556, align 8
  %op3020 = sub i64 %v3019, 24
  store i64 %op3020, ptr %slot562, align 8
  %v3021 = load i64, ptr %slot556, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %rgep3023 = getelementptr i8, ptr %p3022, i64 -24
  %ld3024 = load i64, ptr %rgep3023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3024, ptr %slot563, align 8
  %v3025 = load i64, ptr %slot563, align 8
  %cmp3026 = icmp ne i64 %v3025, 0
  %cv3027 = zext i1 %cmp3026 to i32
  store i32 %cv3027, ptr %slot564, align 8
  %v3028 = load i32, ptr %slot564, align 8
  %cv3029 = zext i32 %v3028 to i64
  %cond3030 = icmp ne i64 %cv3029, 0
  br i1 %cond3030, label %bb_rcs761, label %bb_rcsendslow725
bb_rcs761:
  %v3031 = load i64, ptr %slot556, align 8
  %op3032 = sub i64 %v3031, 32
  store i64 %op3032, ptr %slot565, align 8
  %v3033 = load i64, ptr %slot556, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  %rgep3035 = getelementptr i8, ptr %p3034, i64 -32
  %ld3036 = load i64, ptr %rgep3035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3036, ptr %slot566, align 8
  %v3037 = load i64, ptr %slot563, align 8
  %cmp3038 = icmp ugt i64 %v3037, 1
  %cv3039 = zext i1 %cmp3038 to i32
  store i32 %cv3039, ptr %slot567, align 8
  %v3040 = load i64, ptr %slot566, align 8
  %cmp3041 = icmp ne i64 %v3040, 0
  %cv3042 = zext i1 %cmp3041 to i32
  store i32 %cv3042, ptr %slot568, align 8
  %v3043 = load i32, ptr %slot567, align 8
  %v3044 = load i32, ptr %slot568, align 8
  %op3045 = or i32 %v3043, %v3044
  store i32 %op3045, ptr %slot569, align 8
  %v3046 = load i32, ptr %slot569, align 8
  %cv3047 = zext i32 %v3046 to i64
  %cond3048 = icmp ne i64 %cv3047, 0
  br i1 %cond3048, label %bb_rcs767, label %bb_rcsendslow725
bb_rcs767:
  %v3049 = load i64, ptr %slot547, align 8
  %op3050 = add i64 %v3049, 32
  store i64 %op3050, ptr %slot570, align 8
  %v3051 = load i64, ptr %slot570, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %ld3053 = load i64, ptr %p3052, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3053, ptr %slot571, align 8
  %v3054 = load i64, ptr %slot571, align 8
  %cmp3055 = icmp ne i64 %v3054, 0
  %cv3056 = zext i1 %cmp3055 to i32
  store i32 %cv3056, ptr %slot572, align 8
  %v3057 = load i32, ptr %slot572, align 8
  %cv3058 = zext i32 %v3057 to i64
  %cond3059 = icmp ne i64 %cv3058, 0
  br i1 %cond3059, label %bb_rcsendbacking725, label %bb_rcsendcommit725
bb_rcsendbacking725:
  %v3060 = load i64, ptr %slot571, align 8
  %op3061 = sub i64 %v3060, 16
  store i64 %op3061, ptr %slot573, align 8
  %v3062 = load i64, ptr %slot571, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %rgep3064 = getelementptr i8, ptr %p3063, i64 -16
  %ld3065 = load i64, ptr %rgep3064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3065, ptr %slot574, align 8
  %v3066 = load i64, ptr %slot574, align 8
  %op3067 = and i64 %v3066, 4611686018427387907
  store i64 %op3067, ptr %slot575, align 8
  %v3068 = load i64, ptr %slot575, align 8
  %cmp3069 = icmp eq i64 %v3068, 0
  %cv3070 = zext i1 %cmp3069 to i32
  store i32 %cv3070, ptr %slot576, align 8
  %v3071 = load i32, ptr %slot576, align 8
  %cv3072 = zext i32 %v3071 to i64
  %cond3073 = icmp ne i64 %cv3072, 0
  br i1 %cond3073, label %bb_rcs775, label %bb_rcsendslow725
bb_rcs775:
  %v3074 = load i64, ptr %slot571, align 8
  %op3075 = sub i64 %v3074, 24
  store i64 %op3075, ptr %slot577, align 8
  %v3076 = load i64, ptr %slot571, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %rgep3078 = getelementptr i8, ptr %p3077, i64 -24
  %ld3079 = load i64, ptr %rgep3078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3079, ptr %slot578, align 8
  %v3080 = load i64, ptr %slot578, align 8
  %cmp3081 = icmp ne i64 %v3080, 0
  %cv3082 = zext i1 %cmp3081 to i32
  store i32 %cv3082, ptr %slot579, align 8
  %v3083 = load i32, ptr %slot579, align 8
  %cv3084 = zext i32 %v3083 to i64
  %cond3085 = icmp ne i64 %cv3084, 0
  br i1 %cond3085, label %bb_rcs779, label %bb_rcsendslow725
bb_rcs779:
  %v3086 = load i64, ptr %slot571, align 8
  %op3087 = sub i64 %v3086, 32
  store i64 %op3087, ptr %slot580, align 8
  %v3088 = load i64, ptr %slot571, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  %rgep3090 = getelementptr i8, ptr %p3089, i64 -32
  %ld3091 = load i64, ptr %rgep3090, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3091, ptr %slot581, align 8
  %v3092 = load i64, ptr %slot578, align 8
  %cmp3093 = icmp ugt i64 %v3092, 1
  %cv3094 = zext i1 %cmp3093 to i32
  store i32 %cv3094, ptr %slot582, align 8
  %v3095 = load i64, ptr %slot581, align 8
  %cmp3096 = icmp ne i64 %v3095, 0
  %cv3097 = zext i1 %cmp3096 to i32
  store i32 %cv3097, ptr %slot583, align 8
  %v3098 = load i32, ptr %slot582, align 8
  %v3099 = load i32, ptr %slot583, align 8
  %op3100 = or i32 %v3098, %v3099
  store i32 %op3100, ptr %slot584, align 8
  %v3101 = load i32, ptr %slot584, align 8
  %cv3102 = zext i32 %v3101 to i64
  %cond3103 = icmp ne i64 %cv3102, 0
  br i1 %cond3103, label %bb_rcs785, label %bb_rcsendslow725
bb_rcs785:
  br label %bb_rcsendcommit725
bb_rcsendcommit725:
  %v3104 = load i64, ptr %slot547, align 8
  %op3105 = add i64 %v3104, 24
  store i64 %op3105, ptr %slot585, align 8
  %v3106 = load i64, ptr %slot585, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  %ld3108 = load i32, ptr %p3107, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld3108, ptr %slot586, align 8
  %v3109 = load i32, ptr %slot586, align 8
  %cv3110 = zext i32 %v3109 to i64
  %cond3111 = icmp ne i64 %cv3110, 0
  br i1 %cond3111, label %bb_rcsendrestore725, label %bb_rcsendreturned725
bb_rcsendrestore725:
  %v3112 = load i64, ptr %slot547, align 8
  %op3113 = add i64 %v3112, 16
  store i64 %op3113, ptr %slot587, align 8
  %v3114 = load i64, ptr %slot587, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %ld3116 = load i64, ptr %p3115, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3116, ptr %slot588, align 8
  %v3117 = load i64, ptr %slot559, align 8
  %op3118 = and i64 %v3117, 17293822569102704639
  store i64 %op3118, ptr %slot589, align 8
  %v3119 = load i64, ptr %slot589, align 8
  %v3120 = load i64, ptr %slot588, align 8
  %op3121 = or i64 %v3119, %v3120
  store i64 %op3121, ptr %slot590, align 8
  %v3122 = load i64, ptr %slot556, align 8
  %op3123 = sub i64 %v3122, 16
  store i64 %op3123, ptr %slot591, align 8
  %v3124 = load i64, ptr %slot590, align 8
  %v3125 = load i64, ptr %slot556, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  %rgep3127 = getelementptr i8, ptr %p3126, i64 -16
  store i64 %v3124, ptr %rgep3127, align 8, !alias.scope !9, !noalias !10
  %v3128 = load i64, ptr %slot535, align 8
  %p3130 = inttoptr i64 %v3128 to ptr
  %gep3131 = getelementptr i8, ptr %p3130, i64 16
  %op3129 = ptrtoint ptr %gep3131 to i64
  store i64 %op3129, ptr %slot592, align 8
  br label %bb_rcsendreturned725
bb_rcsendreturned725:
  %v3132 = load i64, ptr %slot592, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i64 0, ptr %p3133, align 8, !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot539, align 8
  %op3135 = add i64 %v3134, 256
  store i64 %op3135, ptr %slot593, align 8
  %v3136 = load i64, ptr %slot593, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %ld3138 = load i64, ptr %p3137, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3138, ptr %slot594, align 8
  %v3139 = load i64, ptr %slot547, align 8
  %op3140 = add i64 %v3139, 0
  store i64 %op3140, ptr %slot595, align 8
  %v3141 = load i64, ptr %slot594, align 8
  %v3142 = load i64, ptr %slot595, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  store i64 %v3141, ptr %p3143, align 8, !alias.scope !9999998, !noalias !9999999
  %v3144 = load i64, ptr %slot539, align 8
  %op3145 = add i64 %v3144, 256
  store i64 %op3145, ptr %slot596, align 8
  %v3146 = load i64, ptr %slot547, align 8
  %v3147 = load i64, ptr %slot596, align 8
  %p3148 = inttoptr i64 %v3147 to ptr
  store i64 %v3146, ptr %p3148, align 8, !alias.scope !9999998, !noalias !9999999
  %v3149 = load i64, ptr %slot539, align 8
  %op3150 = add i64 %v3149, 264
  store i64 %op3150, ptr %slot597, align 8
  %v3151 = load i64, ptr %slot597, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i64, ptr %p3152, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3153, ptr %slot598, align 8
  %v3154 = load i64, ptr %slot598, align 8
  %op3155 = add i64 %v3154, 1
  store i64 %op3155, ptr %slot599, align 8
  %v3156 = load i64, ptr %slot599, align 8
  %v3157 = load i64, ptr %slot597, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i64 %v3156, ptr %p3158, align 8, !alias.scope !9999998, !noalias !9999999
  %v3159 = load i64, ptr %slot37, align 8
  %p3161 = inttoptr i64 %v3159 to ptr
  %gep3162 = getelementptr i8, ptr %p3161, i64 24
  %op3160 = ptrtoint ptr %gep3162 to i64
  store i64 %op3160, ptr %slot600, align 8
  %v3163 = load i64, ptr %slot600, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i64, ptr %p3164, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3165, ptr %slot601, align 8
  %v3166 = load i64, ptr %slot601, align 8
  %op3167 = add i64 %v3166, 18446744073709551576
  store i64 %op3167, ptr %slot602, align 8
  %v3168 = load i64, ptr %slot602, align 8
  %v3169 = load i64, ptr %slot600, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  store i64 %v3168, ptr %p3170, align 8, !alias.scope !9999998, !noalias !9999999
  %v3171 = load i64, ptr %slot539, align 8
  %op3172 = add i64 %v3171, 48
  store i64 %op3172, ptr %slot603, align 8
  %v3173 = load i64, ptr %slot603, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  %ld3175 = load i64, ptr %p3174, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3175, ptr %slot604, align 8
  %v3176 = load i64, ptr %slot604, align 8
  %op3177 = add i64 %v3176, 18446744073709551576
  store i64 %op3177, ptr %slot605, align 8
  %v3178 = load i64, ptr %slot605, align 8
  %v3179 = load i64, ptr %slot603, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  store i64 %v3178, ptr %p3180, align 8, !alias.scope !9999998, !noalias !9999999
  %v3181 = load i64, ptr %slot571, align 8
  %cmp3182 = icmp ne i64 %v3181, 0
  %cv3183 = zext i1 %cmp3182 to i32
  store i32 %cv3183, ptr %slot606, align 8
  %v3184 = load i32, ptr %slot606, align 8
  %cv3185 = zext i32 %v3184 to i64
  %cond3186 = icmp ne i64 %cv3185, 0
  br i1 %cond3186, label %bb_rcsenddropbacking725, label %bb_rcsenddroppayload725
bb_rcsenddropbacking725:
  %v3187 = load i64, ptr %slot571, align 8
  %op3188 = sub i64 %v3187, 24
  store i64 %op3188, ptr %slot607, align 8
  %v3189 = load i64, ptr %slot571, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  %rgep3191 = getelementptr i8, ptr %p3190, i64 -24
  %ld3192 = load i64, ptr %rgep3191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3192, ptr %slot608, align 8
  %v3193 = load i64, ptr %slot608, align 8
  %op3194 = add i64 %v3193, 18446744073709551615
  store i64 %op3194, ptr %slot609, align 8
  %v3195 = load i64, ptr %slot609, align 8
  %v3196 = load i64, ptr %slot571, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  %rgep3198 = getelementptr i8, ptr %p3197, i64 -24
  store i64 %v3195, ptr %rgep3198, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload725
bb_rcsenddroppayload725:
  %v3199 = load i64, ptr %slot556, align 8
  %op3200 = sub i64 %v3199, 24
  store i64 %op3200, ptr %slot610, align 8
  %v3201 = load i64, ptr %slot556, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %rgep3203 = getelementptr i8, ptr %p3202, i64 -24
  %ld3204 = load i64, ptr %rgep3203, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3204, ptr %slot611, align 8
  %v3205 = load i64, ptr %slot611, align 8
  %op3206 = add i64 %v3205, 18446744073709551615
  store i64 %op3206, ptr %slot612, align 8
  %v3207 = load i64, ptr %slot612, align 8
  %v3208 = load i64, ptr %slot556, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  %rgep3210 = getelementptr i8, ptr %p3209, i64 -24
  store i64 %v3207, ptr %rgep3210, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink725
bb_rcsendunlink725:
  %v3211 = load i64, ptr %slot535, align 8
  %p3213 = inttoptr i64 %v3211 to ptr
  %gep3214 = getelementptr i8, ptr %p3213, i64 8
  %op3212 = ptrtoint ptr %gep3214 to i64
  store i64 %op3212, ptr %slot613, align 8
  %v3215 = load i64, ptr %slot613, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i64, ptr %p3216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3217, ptr %slot614, align 8
  %v3218 = load i64, ptr %slot539, align 8
  %op3219 = add i64 %v3218, 248
  store i64 %op3219, ptr %slot615, align 8
  %v3220 = load i64, ptr %slot614, align 8
  %v3221 = load i64, ptr %slot615, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 %v3220, ptr %p3222, align 8, !alias.scope !9999998, !noalias !9999999
  %v3223 = load i64, ptr %slot535, align 8
  %p3225 = inttoptr i64 %v3223 to ptr
  %gep3226 = getelementptr i8, ptr %p3225, i64 24
  %op3224 = ptrtoint ptr %gep3226 to i64
  store i64 %op3224, ptr %slot616, align 8
  %v3227 = load i64, ptr %slot535, align 8
  %p3229 = inttoptr i64 %v3227 to ptr
  %gep3230 = getelementptr i8, ptr %p3229, i64 8
  %op3228 = ptrtoint ptr %gep3230 to i64
  store i64 %op3228, ptr %slot617, align 8
  %v3231 = load i64, ptr %slot616, align 8
  %p3232 = inttoptr i64 %v3231 to ptr
  store i32 0, ptr %p3232, align 4, !alias.scope !3, !noalias !4
  %v3233 = load i64, ptr %slot617, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  store i64 0, ptr %p3234, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone725
bb_rcsendslow725:
  %v3235 = load i64, ptr %slot1, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  %v3237 = load i64, ptr %slot535, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p3236, ptr %p3238) nomerge, !dbg !144
  br label %bb_rcsenddone725
bb_rcsenddone725:
  %v3239 = load i64, ptr %slot33, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  store i64 0, ptr %p3240, align 8, !alias.scope !3, !noalias !4
  %v3241 = load i64, ptr %slot33, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  %ld3243 = load i64, ptr %p3242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3243, ptr %slot618, align 8
  %v3244 = load i64, ptr %slot19, align 8
  %p3246 = inttoptr i64 %v3244 to ptr
  %gep3247 = getelementptr i8, ptr %p3246, i64 24
  %op3245 = ptrtoint ptr %gep3247 to i64
  store i64 %op3245, ptr %slot619, align 8
  %v3248 = load i64, ptr %slot619, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %ld3250 = load i32, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3250, ptr %slot620, align 8
  %v3251 = load i64, ptr %slot21, align 8
  %p3253 = inttoptr i64 %v3251 to ptr
  %gep3254 = getelementptr i8, ptr %p3253, i64 24
  %op3252 = ptrtoint ptr %gep3254 to i64
  store i64 %op3252, ptr %slot621, align 8
  %v3255 = load i64, ptr %slot621, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %ld3257 = load i32, ptr %p3256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3257, ptr %slot622, align 8
  %v3258 = load i32, ptr %slot620, align 8
  %v3259 = load i32, ptr %slot622, align 8
  %op3260 = or i32 %v3258, %v3259
  store i32 %op3260, ptr %slot623, align 8
  %v3261 = load i32, ptr %slot623, align 8
  %cv3262 = zext i32 %v3261 to i64
  %cond3263 = icmp ne i64 %cv3262, 0
  br i1 %cond3263, label %bb_rcscopesopen825, label %bb_rcscopesclosed825
bb_rcscopesopen825:
  %v3264 = load i64, ptr %slot23, align 8
  %p3266 = inttoptr i64 %v3264 to ptr
  %gep3267 = getelementptr i8, ptr %p3266, i64 0
  %op3265 = ptrtoint ptr %gep3267 to i64
  store i64 %op3265, ptr %slot624, align 8
  %v3268 = load i64, ptr %slot19, align 8
  %v3269 = load i64, ptr %slot624, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  store i64 %v3268, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  %v3271 = load i64, ptr %slot23, align 8
  %p3273 = inttoptr i64 %v3271 to ptr
  %gep3274 = getelementptr i8, ptr %p3273, i64 8
  %op3272 = ptrtoint ptr %gep3274 to i64
  store i64 %op3272, ptr %slot625, align 8
  %v3275 = load i64, ptr %slot21, align 8
  %v3276 = load i64, ptr %slot625, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  store i64 %v3275, ptr %p3277, align 8, !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot1, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  %v3280 = load i64, ptr %slot23, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p3279, ptr %p3281, i64 2) nomerge, !dbg !146
  br label %bb_rcscopesclosed825
bb_rcscopesclosed825:
  %v3282 = load i64, ptr %slot8, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %ld3284 = load i32, ptr %p3283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3284, ptr %slot626, align 8
  %v3285 = load i32, ptr %slot626, align 8
  %cv3286 = zext i32 %v3285 to i64
  %cond3287 = icmp ne i64 %cv3286, 0
  br i1 %cond3287, label %bb_rcslotdrop830, label %bb_rcslotdone830
bb_rcslotdrop830:
  %v3288 = load i64, ptr %slot8, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i32 0, ptr %p3289, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone830
bb_rcslotdone830:
  %v3290 = load i64, ptr %slot6, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ld3292 = load i32, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3292, ptr %slot627, align 8
  %v3293 = load i32, ptr %slot627, align 8
  %cv3294 = zext i32 %v3293 to i64
  %cond3295 = icmp ne i64 %cv3294, 0
  br i1 %cond3295, label %bb_rcslotdrop833, label %bb_rcslotdone833
bb_rcslotdrop833:
  %v3296 = load i64, ptr %slot6, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  store i32 0, ptr %p3297, align 4, !alias.scope !3, !noalias !4
  %v3298 = load i64, ptr %slot31, align 8
  store i64 %v3298, ptr %slot628, align 8
  %v3299 = load i64, ptr %slot7, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i32, ptr %p3300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3301, ptr %slot629, align 8
  %v3302 = load i32, ptr %slot629, align 8
  %op3303 = and i32 %v3302, 28
  store i32 %op3303, ptr %slot630, align 8
  %v3304 = load i32, ptr %slot630, align 8
  %cv3305 = zext i32 %v3304 to i64
  %cond3306 = icmp ne i64 %cv3305, 0
  br i1 %cond3306, label %bb_rcslotrole833, label %bb_rcslotowner833
bb_rcslotrole833:
  %v3307 = load i64, ptr %slot37, align 8
  store i64 %v3307, ptr %slot631, align 8
  %v3308 = load i64, ptr %slot631, align 8
  %v3309 = load i64, ptr %slot628, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3308, i64 %v3309) nomerge, !dbg !146
  br label %bb_rcslotdone833
bb_rcslotowner833:
  %v3310 = load i64, ptr %slot37, align 8
  store i64 %v3310, ptr %slot632, align 8
  %v3311 = load i64, ptr %slot632, align 8
  %v3312 = load i64, ptr %slot628, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3311, i64 %v3312) nomerge, !dbg !146
  br label %bb_rcslotdone833
bb_rcslotdone833:
  %v3313 = load i64, ptr %slot618, align 8
  ret i64 %v3313
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328", linkageName: "myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1667472824326708685, i64 0, !"myl_f_9da0fe05dc5b11775d5ea71336203a8d63915cc534e24827d5b71b5b5186c328"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!118 = !DILocation(line: 15, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!122 = !DILocation(line: 20, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!124 = !DILocation(line: 23, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!126 = !DILocation(line: 24, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!136 = !DILocation(line: 30, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!138 = !DILocation(line: 32, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!140 = !DILocation(line: 39, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!142 = !DILocation(line: 41, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!144 = !DILocation(line: 46, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!146 = !DILocation(line: 49, column: 0, scope: !147)
