target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v137 = load i64, ptr %slot1, align 8
  %op138 = add i64 %v137, 32
  store i64 %op138, ptr %slot3, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot4, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot5, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot6, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot7, align 8
  %mem147 = alloca i8, i64 8, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot8, align 8
  %mem149 = alloca i8, i64 8, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot9, align 8
  %mem151 = alloca i8, i64 8, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot10, align 8
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot11, align 8
  %mem155 = alloca i8, i64 8, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot12, align 8
  %mem157 = alloca i8, i64 8, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot13, align 8
  %mem159 = alloca i8, i64 392, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot14, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot15, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot16, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot17, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot18, align 8
  %mem169 = alloca i8, i64 8, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot19, align 8
  %mem171 = alloca i8, i64 392, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot20, align 8
  %mem173 = alloca i8, i64 392, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot21, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot22, align 8
  %v177 = load i64, ptr %slot1, align 8
  %op178 = add i64 %v177, 64
  store i64 %op178, ptr %slot23, align 8
  %v179 = load i64, ptr %slot23, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !4, !noalias !3
  store i64 %ld181, ptr %slot24, align 8
  %stack182 = call ptr @llvm.stacksave()
  %stackaddr183 = ptrtoint ptr %stack182 to i64
  %v184 = load i64, ptr %slot24, align 8
  %cmp185 = icmp ult i64 %stackaddr183, %v184
  %cv186 = zext i1 %cmp185 to i64
  store i64 %cv186, ptr %slot25, align 8
  %v187 = load i64, ptr %slot25, align 8
  %cond188 = icmp ne i64 %v187, 0
  br i1 %cond188, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v189 = load i64, ptr %slot1, align 8
  %p190 = inttoptr i64 %v189 to ptr
  call void @myl_qbe_fail_frame(ptr %p190) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v191 = load i64, ptr %slot2, align 8
  %v192 = load i64, ptr %slot15, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 %v191, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot1, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %call196 = call ptr @myl_qbe_heap(ptr %p195) nomerge, !dbg !112
  %calladdr197 = ptrtoint ptr %call196 to i64
  store i64 %calladdr197, ptr %slot26, align 8
  %v198 = load i64, ptr %slot4, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i32 0, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot5, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i32 0, ptr %p201, align 4, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot6, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i32 0, ptr %p203, align 4, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot7, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i32 0, ptr %p205, align 4, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot8, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i32 0, ptr %p207, align 4, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot9, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i32 0, ptr %p209, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v210 = load i64, ptr %slot15, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot27, align 8
  %v213 = load i64, ptr %slot27, align 8
  %v214 = load i64, ptr %slot17, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i64 %v213, ptr %p215, align 8, !alias.scope !3, !noalias !4
  %p216 = inttoptr i64 ptrtoint (ptr @myl_lit_1b09457477ce8976b6dd5c0bb92b9d43a791e77aa5ffb457e7d39663b0d18cde to i64) to ptr
  %ld217 = load i64, ptr %p216, align 8, !alias.scope !4, !noalias !3
  store i64 %ld217, ptr %slot28, align 8
  %v218 = load i64, ptr %slot28, align 8
  %v219 = load i64, ptr %slot18, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot18, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot29, align 8
  %v224 = load i64, ptr %slot29, align 8
  %v225 = load i64, ptr %slot12, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot12, align 8
  store i64 %v227, ptr %slot30, align 8
  %v228 = load i64, ptr %slot14, align 8
  store i64 %v228, ptr %slot31, align 8
  %v229 = load i64, ptr %slot30, align 8
  %v230 = load i64, ptr %slot31, align 8
  %p231 = inttoptr i64 %v229 to ptr
  %p232 = inttoptr i64 %v230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p232, ptr %p231, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot9, align 8
  %p234 = inttoptr i64 %v233 to ptr
  store i32 2, ptr %p234, align 4, !alias.scope !3, !noalias !4
  %v235 = load i64, ptr %slot8, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i32 1, ptr %p236, align 4, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot10, align 8
  store i64 %v237, ptr %slot32, align 8
  %v238 = load i64, ptr %slot14, align 8
  store i64 %v238, ptr %slot33, align 8
  %v239 = load i64, ptr %slot33, align 8
  %v240 = load i64, ptr %slot32, align 8
  %p241 = inttoptr i64 %v239 to ptr
  %p242 = inttoptr i64 %v240 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p242, ptr %p241, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 2, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot9, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i32, ptr %p246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld247, ptr %slot34, align 8
  %v248 = load i32, ptr %slot34, align 8
  %v249 = load i64, ptr %slot5, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i32 %v248, ptr %p250, align 4, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot8, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 0, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot4, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 1, ptr %p254, align 4, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot32, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot35, align 8
  %v258 = load i64, ptr %slot35, align 8
  %v259 = load i64, ptr %slot18, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i64 %v258, ptr %p260, align 8, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot17, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot36, align 8
  %v264 = load i64, ptr %slot18, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot37, align 8
  %v267 = load i64, ptr %slot1, align 8
  %v268 = load i64, ptr %slot36, align 8
  %v269 = load i64, ptr %slot37, align 8
  %call270 = call i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64 %v267, i64 %v268, i64 %v269) nomerge, !dbg !114
  store i64 %call270, ptr %slot38, align 8
  %v271 = load i64, ptr %slot38, align 8
  %v272 = load i64, ptr %slot17, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i64 %v271, ptr %p273, align 8, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot4, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i32, ptr %p275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld276, ptr %slot39, align 8
  %v277 = load i32, ptr %slot39, align 8
  %cv278 = zext i32 %v277 to i64
  %cond279 = icmp ne i64 %cv278, 0
  br i1 %cond279, label %bb_rcslotdrop39, label %bb_rcslotdone39
bb_rcslotdrop39:
  %v280 = load i64, ptr %slot4, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 0, ptr %p281, align 4, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot10, align 8
  store i64 %v282, ptr %slot40, align 8
  %v283 = load i64, ptr %slot5, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i32, ptr %p284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld285, ptr %slot41, align 8
  %v286 = load i32, ptr %slot41, align 8
  %op287 = and i32 %v286, 28
  store i32 %op287, ptr %slot42, align 8
  %v288 = load i32, ptr %slot42, align 8
  %cv289 = zext i32 %v288 to i64
  %cond290 = icmp ne i64 %cv289, 0
  br i1 %cond290, label %bb_rcslotrole39, label %bb_rcslotowner39
bb_rcslotrole39:
  %v291 = load i64, ptr %slot26, align 8
  store i64 %v291, ptr %slot43, align 8
  %v292 = load i64, ptr %slot40, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld294, ptr %slot44, align 8
  %v295 = load i64, ptr %slot44, align 8
  %cmp296 = icmp ne i64 %v295, 0
  %cv297 = zext i1 %cmp296 to i32
  store i32 %cv297, ptr %slot45, align 8
  %v298 = load i32, ptr %slot45, align 8
  %cv299 = zext i32 %v298 to i64
  %cond300 = icmp ne i64 %cv299, 0
  br i1 %cond300, label %bb_rcgnn55, label %bb_rcgdone55
bb_rcgnn55:
  %v301 = load i64, ptr %slot44, align 8
  %op302 = sub i64 %v301, 16
  store i64 %op302, ptr %slot46, align 8
  %v303 = load i64, ptr %slot44, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %rgep305 = getelementptr i8, ptr %p304, i64 -16
  %ld306 = load i64, ptr %rgep305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld306, ptr %slot47, align 8
  %v307 = load i64, ptr %slot47, align 8
  %op308 = and i64 %v307, 4611686018427387906
  store i64 %op308, ptr %slot48, align 8
  %v309 = load i64, ptr %slot48, align 8
  %cmp310 = icmp ne i64 %v309, 0
  %cv311 = zext i1 %cmp310 to i32
  store i32 %cv311, ptr %slot49, align 8
  %v312 = load i32, ptr %slot49, align 8
  %cv313 = zext i32 %v312 to i64
  %cond314 = icmp ne i64 %cv313, 0
  br i1 %cond314, label %bb_rcgclear55, label %bb_rcgcounted55
bb_rcgcounted55:
  %v315 = load i64, ptr %slot44, align 8
  %op316 = sub i64 %v315, 24
  store i64 %op316, ptr %slot50, align 8
  %v317 = load i64, ptr %slot44, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %rgep319 = getelementptr i8, ptr %p318, i64 -24
  %ld320 = load i64, ptr %rgep319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld320, ptr %slot51, align 8
  %v321 = load i64, ptr %slot51, align 8
  %op322 = sub i64 %v321, 1
  store i64 %op322, ptr %slot52, align 8
  %v323 = load i64, ptr %slot52, align 8
  %cmp324 = icmp eq i64 %v323, 0
  %cv325 = zext i1 %cmp324 to i32
  store i32 %cv325, ptr %slot53, align 8
  %v326 = load i32, ptr %slot53, align 8
  %cv327 = zext i32 %v326 to i64
  %cond328 = icmp ne i64 %cv327, 0
  br i1 %cond328, label %bb_rcglast55, label %bb_rcgdec55
bb_rcglast55:
  %v329 = load i64, ptr %slot44, align 8
  %op330 = sub i64 %v329, 32
  store i64 %op330, ptr %slot54, align 8
  %v331 = load i64, ptr %slot44, align 8
  %p332 = inttoptr i64 %v331 to ptr
  %rgep333 = getelementptr i8, ptr %p332, i64 -32
  %ld334 = load i64, ptr %rgep333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld334, ptr %slot55, align 8
  %v335 = load i64, ptr %slot55, align 8
  %cmp336 = icmp ne i64 %v335, 0
  %cv337 = zext i1 %cmp336 to i32
  store i32 %cv337, ptr %slot56, align 8
  %v338 = load i32, ptr %slot56, align 8
  %cv339 = zext i32 %v338 to i64
  %cond340 = icmp ne i64 %cv339, 0
  br i1 %cond340, label %bb_rcgdec55, label %bb_rcgslow55
bb_rcgslow55:
  %v341 = load i64, ptr %slot43, align 8
  %v342 = load i64, ptr %slot40, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v341, i64 %v342) nomerge, !dbg !114
  br label %bb_rcgdone55
bb_rcgdec55:
  %v343 = load i64, ptr %slot52, align 8
  %v344 = load i64, ptr %slot44, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %rgep346 = getelementptr i8, ptr %p345, i64 -24
  store i64 %v343, ptr %rgep346, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear55
bb_rcgclear55:
  %v347 = load i64, ptr %slot40, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 0, ptr %p348, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone55
bb_rcgdone55:
  br label %bb_rcslotdone39
bb_rcslotowner39:
  %v349 = load i64, ptr %slot26, align 8
  store i64 %v349, ptr %slot57, align 8
  %v350 = load i64, ptr %slot40, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot58, align 8
  %v353 = load i64, ptr %slot58, align 8
  %cmp354 = icmp ne i64 %v353, 0
  %cv355 = zext i1 %cmp354 to i32
  store i32 %cv355, ptr %slot59, align 8
  %v356 = load i32, ptr %slot59, align 8
  %cv357 = zext i32 %v356 to i64
  %cond358 = icmp ne i64 %cv357, 0
  br i1 %cond358, label %bb_rcgnn70, label %bb_rcgdone70
bb_rcgnn70:
  %v359 = load i64, ptr %slot58, align 8
  %op360 = sub i64 %v359, 16
  store i64 %op360, ptr %slot60, align 8
  %v361 = load i64, ptr %slot58, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %rgep363 = getelementptr i8, ptr %p362, i64 -16
  %ld364 = load i64, ptr %rgep363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld364, ptr %slot61, align 8
  %v365 = load i64, ptr %slot61, align 8
  %op366 = and i64 %v365, 4611686018427387906
  store i64 %op366, ptr %slot62, align 8
  %v367 = load i64, ptr %slot62, align 8
  %cmp368 = icmp ne i64 %v367, 0
  %cv369 = zext i1 %cmp368 to i32
  store i32 %cv369, ptr %slot63, align 8
  %v370 = load i32, ptr %slot63, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcgclear70, label %bb_rcgcounted70
bb_rcgcounted70:
  %v373 = load i64, ptr %slot58, align 8
  %op374 = sub i64 %v373, 32
  store i64 %op374, ptr %slot64, align 8
  %v375 = load i64, ptr %slot58, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %rgep377 = getelementptr i8, ptr %p376, i64 -32
  %ld378 = load i64, ptr %rgep377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld378, ptr %slot65, align 8
  %v379 = load i64, ptr %slot65, align 8
  %op380 = sub i64 %v379, 1
  store i64 %op380, ptr %slot66, align 8
  %v381 = load i64, ptr %slot66, align 8
  %cmp382 = icmp eq i64 %v381, 0
  %cv383 = zext i1 %cmp382 to i32
  store i32 %cv383, ptr %slot67, align 8
  %v384 = load i32, ptr %slot67, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rcglast70, label %bb_rcgdec70
bb_rcglast70:
  %v387 = load i64, ptr %slot58, align 8
  %op388 = sub i64 %v387, 24
  store i64 %op388, ptr %slot68, align 8
  %v389 = load i64, ptr %slot58, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %rgep391 = getelementptr i8, ptr %p390, i64 -24
  %ld392 = load i64, ptr %rgep391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld392, ptr %slot69, align 8
  %v393 = load i64, ptr %slot69, align 8
  %cmp394 = icmp ne i64 %v393, 0
  %cv395 = zext i1 %cmp394 to i32
  store i32 %cv395, ptr %slot70, align 8
  %v396 = load i32, ptr %slot70, align 8
  %cv397 = zext i32 %v396 to i64
  %cond398 = icmp ne i64 %cv397, 0
  br i1 %cond398, label %bb_rcgdec70, label %bb_rcgslow70
bb_rcgslow70:
  %v399 = load i64, ptr %slot57, align 8
  %v400 = load i64, ptr %slot40, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v399, i64 %v400) nomerge, !dbg !114
  br label %bb_rcgdone70
bb_rcgdec70:
  %v401 = load i64, ptr %slot66, align 8
  %v402 = load i64, ptr %slot58, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %rgep404 = getelementptr i8, ptr %p403, i64 -32
  store i64 %v401, ptr %rgep404, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear70
bb_rcgclear70:
  %v405 = load i64, ptr %slot40, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 0, ptr %p406, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone70
bb_rcgdone70:
  br label %bb_rcslotdone39
bb_rcslotdone39:
  %v407 = load i64, ptr %slot17, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot71, align 8
  %v410 = load i64, ptr %slot71, align 8
  %v411 = load i64, ptr %slot16, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i64 %v410, ptr %p412, align 8, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot15, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot72, align 8
  %v416 = load i64, ptr %slot72, align 8
  %v417 = load i64, ptr %slot17, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i64 %v416, ptr %p418, align 8, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot20, align 8
  store i64 %v419, ptr %slot73, align 8
  %v420 = load i64, ptr %slot73, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i32 0, ptr %p421, align 4, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot73, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i32 13, ptr %p423, align 4, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot73, align 8
  %v425 = load i64, ptr %slot18, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i64 %v424, ptr %p426, align 8, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot17, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %ld429 = load i64, ptr %p428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld429, ptr %slot74, align 8
  %v430 = load i64, ptr %slot18, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot75, align 8
  %v433 = load i64, ptr %slot1, align 8
  %v434 = load i64, ptr %slot74, align 8
  %v435 = load i64, ptr %slot75, align 8
  %call436 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v433, i64 %v434, i64 %v435) nomerge, !dbg !116
  store i64 %call436, ptr %slot76, align 8
  %v437 = load i64, ptr %slot76, align 8
  %v438 = load i64, ptr %slot17, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 %v437, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot17, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i64, ptr %p441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld442, ptr %slot77, align 8
  %v443 = load i64, ptr %slot77, align 8
  %cond444 = icmp ne i64 %v443, 0
  br i1 %cond444, label %bb_next90, label %bb_i12
bb_next90:
  %v445 = load i64, ptr %slot15, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ld447 = load i64, ptr %p446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld447, ptr %slot78, align 8
  %v448 = load i64, ptr %slot78, align 8
  %v449 = load i64, ptr %slot17, align 8
  %p450 = inttoptr i64 %v449 to ptr
  store i64 %v448, ptr %p450, align 8, !alias.scope !3, !noalias !4
  %v451 = load i64, ptr %slot17, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %ld453 = load i64, ptr %p452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld453, ptr %slot79, align 8
  %v454 = load i64, ptr %slot1, align 8
  %v455 = load i64, ptr %slot79, align 8
  %call456 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v454, i64 %v455) nomerge, !dbg !118
  store i64 %call456, ptr %slot80, align 8
  %v457 = load i64, ptr %slot80, align 8
  %v458 = load i64, ptr %slot17, align 8
  %p459 = inttoptr i64 %v458 to ptr
  store i64 %v457, ptr %p459, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i12:
  %v460 = load i64, ptr %slot15, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %ld462 = load i64, ptr %p461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld462, ptr %slot81, align 8
  %v463 = load i64, ptr %slot81, align 8
  %v464 = load i64, ptr %slot17, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i64 %v463, ptr %p465, align 8, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot18, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i64 1, ptr %p467, align 8, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot17, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld470, ptr %slot82, align 8
  %v471 = load i64, ptr %slot18, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot83, align 8
  %v474 = load i64, ptr %slot1, align 8
  %v475 = load i64, ptr %slot82, align 8
  %v476 = load i64, ptr %slot83, align 8
  %call477 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v474, i64 %v475, i64 %v476) nomerge, !dbg !120
  store i64 %call477, ptr %slot84, align 8
  %v478 = load i64, ptr %slot84, align 8
  %v479 = load i64, ptr %slot17, align 8
  %p480 = inttoptr i64 %v479 to ptr
  store i64 %v478, ptr %p480, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v481 = load i64, ptr %slot15, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ld483 = load i64, ptr %p482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld483, ptr %slot85, align 8
  %v484 = load i64, ptr %slot85, align 8
  %v485 = load i64, ptr %slot17, align 8
  %p486 = inttoptr i64 %v485 to ptr
  store i64 %v484, ptr %p486, align 8, !alias.scope !3, !noalias !4
  %v487 = load i64, ptr %slot21, align 8
  store i64 %v487, ptr %slot86, align 8
  %v488 = load i64, ptr %slot86, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i32 0, ptr %p489, align 4, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot86, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i32 8, ptr %p491, align 4, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot86, align 8
  %v493 = load i64, ptr %slot18, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i64 %v492, ptr %p494, align 8, !alias.scope !3, !noalias !4
  %p495 = inttoptr i64 ptrtoint (ptr @myl_lit_4e48faae1476188ceb23066f96fc5c60c763d46a99320deefec8a56ef9779402 to i64) to ptr
  %ld496 = load i64, ptr %p495, align 8, !alias.scope !4, !noalias !3
  store i64 %ld496, ptr %slot87, align 8
  %v497 = load i64, ptr %slot87, align 8
  %v498 = load i64, ptr %slot19, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot19, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot88, align 8
  %v503 = load i64, ptr %slot88, align 8
  %v504 = load i64, ptr %slot13, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i64 %v503, ptr %p505, align 8, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot13, align 8
  store i64 %v506, ptr %slot89, align 8
  %v507 = load i64, ptr %slot14, align 8
  store i64 %v507, ptr %slot90, align 8
  %v508 = load i64, ptr %slot89, align 8
  %v509 = load i64, ptr %slot90, align 8
  %p510 = inttoptr i64 %v508 to ptr
  %p511 = inttoptr i64 %v509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p511, ptr %p510, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot9, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i32 2, ptr %p513, align 4, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot8, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 1, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot11, align 8
  store i64 %v516, ptr %slot91, align 8
  %v517 = load i64, ptr %slot14, align 8
  store i64 %v517, ptr %slot92, align 8
  %v518 = load i64, ptr %slot92, align 8
  %v519 = load i64, ptr %slot91, align 8
  %p520 = inttoptr i64 %v518 to ptr
  %p521 = inttoptr i64 %v519 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p521, ptr %p520, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot7, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 2, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot9, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ld526 = load i32, ptr %p525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld526, ptr %slot93, align 8
  %v527 = load i32, ptr %slot93, align 8
  %v528 = load i64, ptr %slot7, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i32 %v527, ptr %p529, align 4, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot8, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 0, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot6, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i32 1, ptr %p533, align 4, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot91, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot94, align 8
  %v537 = load i64, ptr %slot94, align 8
  %v538 = load i64, ptr %slot19, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i64 %v537, ptr %p539, align 8, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot17, align 8
  %p541 = inttoptr i64 %v540 to ptr
  %ld542 = load i64, ptr %p541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld542, ptr %slot95, align 8
  %v543 = load i64, ptr %slot18, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i64, ptr %p544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld545, ptr %slot96, align 8
  %v546 = load i64, ptr %slot19, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot97, align 8
  %v549 = load i64, ptr %slot1, align 8
  %v550 = load i64, ptr %slot95, align 8
  %v551 = load i64, ptr %slot96, align 8
  %v552 = load i64, ptr %slot97, align 8
  %call553 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v549, i64 %v550, i64 %v551, i64 %v552) nomerge, !dbg !122
  store i64 %call553, ptr %slot98, align 8
  %v554 = load i64, ptr %slot98, align 8
  %v555 = load i64, ptr %slot17, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot6, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i32, ptr %p558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld559, ptr %slot99, align 8
  %v560 = load i32, ptr %slot99, align 8
  %cv561 = zext i32 %v560 to i64
  %cond562 = icmp ne i64 %cv561, 0
  br i1 %cond562, label %bb_rcslotdrop148, label %bb_rcslotdone148
bb_rcslotdrop148:
  %v563 = load i64, ptr %slot6, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot11, align 8
  store i64 %v565, ptr %slot100, align 8
  %v566 = load i64, ptr %slot7, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i32, ptr %p567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld568, ptr %slot101, align 8
  %v569 = load i32, ptr %slot101, align 8
  %op570 = and i32 %v569, 28
  store i32 %op570, ptr %slot102, align 8
  %v571 = load i32, ptr %slot102, align 8
  %cv572 = zext i32 %v571 to i64
  %cond573 = icmp ne i64 %cv572, 0
  br i1 %cond573, label %bb_rcslotrole148, label %bb_rcslotowner148
bb_rcslotrole148:
  %v574 = load i64, ptr %slot26, align 8
  store i64 %v574, ptr %slot103, align 8
  %v575 = load i64, ptr %slot100, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot104, align 8
  %v578 = load i64, ptr %slot104, align 8
  %cmp579 = icmp ne i64 %v578, 0
  %cv580 = zext i1 %cmp579 to i32
  store i32 %cv580, ptr %slot105, align 8
  %v581 = load i32, ptr %slot105, align 8
  %cv582 = zext i32 %v581 to i64
  %cond583 = icmp ne i64 %cv582, 0
  br i1 %cond583, label %bb_rcgnn164, label %bb_rcgdone164
bb_rcgnn164:
  %v584 = load i64, ptr %slot104, align 8
  %op585 = sub i64 %v584, 16
  store i64 %op585, ptr %slot106, align 8
  %v586 = load i64, ptr %slot104, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %rgep588 = getelementptr i8, ptr %p587, i64 -16
  %ld589 = load i64, ptr %rgep588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld589, ptr %slot107, align 8
  %v590 = load i64, ptr %slot107, align 8
  %op591 = and i64 %v590, 4611686018427387906
  store i64 %op591, ptr %slot108, align 8
  %v592 = load i64, ptr %slot108, align 8
  %cmp593 = icmp ne i64 %v592, 0
  %cv594 = zext i1 %cmp593 to i32
  store i32 %cv594, ptr %slot109, align 8
  %v595 = load i32, ptr %slot109, align 8
  %cv596 = zext i32 %v595 to i64
  %cond597 = icmp ne i64 %cv596, 0
  br i1 %cond597, label %bb_rcgclear164, label %bb_rcgcounted164
bb_rcgcounted164:
  %v598 = load i64, ptr %slot104, align 8
  %op599 = sub i64 %v598, 24
  store i64 %op599, ptr %slot110, align 8
  %v600 = load i64, ptr %slot104, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %rgep602 = getelementptr i8, ptr %p601, i64 -24
  %ld603 = load i64, ptr %rgep602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld603, ptr %slot111, align 8
  %v604 = load i64, ptr %slot111, align 8
  %op605 = sub i64 %v604, 1
  store i64 %op605, ptr %slot112, align 8
  %v606 = load i64, ptr %slot112, align 8
  %cmp607 = icmp eq i64 %v606, 0
  %cv608 = zext i1 %cmp607 to i32
  store i32 %cv608, ptr %slot113, align 8
  %v609 = load i32, ptr %slot113, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcglast164, label %bb_rcgdec164
bb_rcglast164:
  %v612 = load i64, ptr %slot104, align 8
  %op613 = sub i64 %v612, 32
  store i64 %op613, ptr %slot114, align 8
  %v614 = load i64, ptr %slot104, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %rgep616 = getelementptr i8, ptr %p615, i64 -32
  %ld617 = load i64, ptr %rgep616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld617, ptr %slot115, align 8
  %v618 = load i64, ptr %slot115, align 8
  %cmp619 = icmp ne i64 %v618, 0
  %cv620 = zext i1 %cmp619 to i32
  store i32 %cv620, ptr %slot116, align 8
  %v621 = load i32, ptr %slot116, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcgdec164, label %bb_rcgslow164
bb_rcgslow164:
  %v624 = load i64, ptr %slot103, align 8
  %v625 = load i64, ptr %slot100, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v624, i64 %v625) nomerge, !dbg !122
  br label %bb_rcgdone164
bb_rcgdec164:
  %v626 = load i64, ptr %slot112, align 8
  %v627 = load i64, ptr %slot104, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %rgep629 = getelementptr i8, ptr %p628, i64 -24
  store i64 %v626, ptr %rgep629, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear164
bb_rcgclear164:
  %v630 = load i64, ptr %slot100, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i64 0, ptr %p631, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone164
bb_rcgdone164:
  br label %bb_rcslotdone148
bb_rcslotowner148:
  %v632 = load i64, ptr %slot26, align 8
  store i64 %v632, ptr %slot117, align 8
  %v633 = load i64, ptr %slot100, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ld635 = load i64, ptr %p634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld635, ptr %slot118, align 8
  %v636 = load i64, ptr %slot118, align 8
  %cmp637 = icmp ne i64 %v636, 0
  %cv638 = zext i1 %cmp637 to i32
  store i32 %cv638, ptr %slot119, align 8
  %v639 = load i32, ptr %slot119, align 8
  %cv640 = zext i32 %v639 to i64
  %cond641 = icmp ne i64 %cv640, 0
  br i1 %cond641, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v642 = load i64, ptr %slot118, align 8
  %op643 = sub i64 %v642, 16
  store i64 %op643, ptr %slot120, align 8
  %v644 = load i64, ptr %slot118, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %rgep646 = getelementptr i8, ptr %p645, i64 -16
  %ld647 = load i64, ptr %rgep646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld647, ptr %slot121, align 8
  %v648 = load i64, ptr %slot121, align 8
  %op649 = and i64 %v648, 4611686018427387906
  store i64 %op649, ptr %slot122, align 8
  %v650 = load i64, ptr %slot122, align 8
  %cmp651 = icmp ne i64 %v650, 0
  %cv652 = zext i1 %cmp651 to i32
  store i32 %cv652, ptr %slot123, align 8
  %v653 = load i32, ptr %slot123, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v656 = load i64, ptr %slot118, align 8
  %op657 = sub i64 %v656, 32
  store i64 %op657, ptr %slot124, align 8
  %v658 = load i64, ptr %slot118, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %rgep660 = getelementptr i8, ptr %p659, i64 -32
  %ld661 = load i64, ptr %rgep660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld661, ptr %slot125, align 8
  %v662 = load i64, ptr %slot125, align 8
  %op663 = sub i64 %v662, 1
  store i64 %op663, ptr %slot126, align 8
  %v664 = load i64, ptr %slot126, align 8
  %cmp665 = icmp eq i64 %v664, 0
  %cv666 = zext i1 %cmp665 to i32
  store i32 %cv666, ptr %slot127, align 8
  %v667 = load i32, ptr %slot127, align 8
  %cv668 = zext i32 %v667 to i64
  %cond669 = icmp ne i64 %cv668, 0
  br i1 %cond669, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v670 = load i64, ptr %slot118, align 8
  %op671 = sub i64 %v670, 24
  store i64 %op671, ptr %slot128, align 8
  %v672 = load i64, ptr %slot118, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %rgep674 = getelementptr i8, ptr %p673, i64 -24
  %ld675 = load i64, ptr %rgep674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld675, ptr %slot129, align 8
  %v676 = load i64, ptr %slot129, align 8
  %cmp677 = icmp ne i64 %v676, 0
  %cv678 = zext i1 %cmp677 to i32
  store i32 %cv678, ptr %slot130, align 8
  %v679 = load i32, ptr %slot130, align 8
  %cv680 = zext i32 %v679 to i64
  %cond681 = icmp ne i64 %cv680, 0
  br i1 %cond681, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v682 = load i64, ptr %slot117, align 8
  %v683 = load i64, ptr %slot100, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v682, i64 %v683) nomerge, !dbg !122
  br label %bb_rcgdone179
bb_rcgdec179:
  %v684 = load i64, ptr %slot126, align 8
  %v685 = load i64, ptr %slot118, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %rgep687 = getelementptr i8, ptr %p686, i64 -32
  store i64 %v684, ptr %rgep687, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v688 = load i64, ptr %slot100, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 0, ptr %p689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone148
bb_rcslotdone148:
  %v690 = load i64, ptr %slot15, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %ld692 = load i64, ptr %p691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld692, ptr %slot131, align 8
  %v693 = load i64, ptr %slot131, align 8
  %v694 = load i64, ptr %slot17, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 %v693, ptr %p695, align 8, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot16, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %ld698 = load i64, ptr %p697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld698, ptr %slot132, align 8
  %v699 = load i64, ptr %slot132, align 8
  %v700 = load i64, ptr %slot18, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i64 %v699, ptr %p701, align 8, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot17, align 8
  %p703 = inttoptr i64 %v702 to ptr
  %ld704 = load i64, ptr %p703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld704, ptr %slot133, align 8
  %v705 = load i64, ptr %slot18, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i64, ptr %p706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld707, ptr %slot134, align 8
  %v708 = load i64, ptr %slot1, align 8
  %v709 = load i64, ptr %slot133, align 8
  %v710 = load i64, ptr %slot134, align 8
  %call711 = call i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64 %v708, i64 %v709, i64 %v710) nomerge, !dbg !124
  store i64 %call711, ptr %slot135, align 8
  %v712 = load i64, ptr %slot135, align 8
  %v713 = load i64, ptr %slot17, align 8
  %p714 = inttoptr i64 %v713 to ptr
  store i64 %v712, ptr %p714, align 8, !alias.scope !3, !noalias !4
  %v715 = load i64, ptr %slot17, align 8
  %p716 = inttoptr i64 %v715 to ptr
  store i64 0, ptr %p716, align 8, !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot17, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %ld719 = load i64, ptr %p718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld719, ptr %slot136, align 8
  %v720 = load i64, ptr %slot136, align 8
  ret i64 %v720
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_1b09457477ce8976b6dd5c0bb92b9d43a791e77aa5ffb457e7d39663b0d18cde = external global i8, align 8
@myl_lit_4e48faae1476188ceb23066f96fc5c60c763d46a99320deefec8a56ef9779402 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64, i64, i64)
declare i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64, i64, i64)
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45", linkageName: "myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5084296739329672354, i64 0, !"myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!120 = !DILocation(line: 15, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!122 = !DILocation(line: 20, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!124 = !DILocation(line: 24, column: 0, scope: !125)
