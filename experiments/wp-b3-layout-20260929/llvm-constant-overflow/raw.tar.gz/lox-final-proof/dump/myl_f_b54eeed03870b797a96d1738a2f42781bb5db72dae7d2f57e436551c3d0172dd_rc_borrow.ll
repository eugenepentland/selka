target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v156 = load i64, ptr %slot1, align 8
  %op157 = add i64 %v156, 32
  store i64 %op157, ptr %slot4, align 8
  %mem158 = alloca i8, i64 16, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot5, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot6, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot7, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot8, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot9, align 8
  %mem168 = alloca i8, i64 16, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot10, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot11, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot12, align 8
  %mem174 = alloca i8, i64 16, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot13, align 8
  %mem176 = alloca i8, i64 16, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot14, align 8
  %mem178 = alloca i8, i64 16, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot15, align 8
  %mem180 = alloca i8, i64 16, align 8
  %ptr181 = ptrtoint ptr %mem180 to i64
  store i64 %ptr181, ptr %slot16, align 8
  %mem182 = alloca i8, i64 16, align 8
  %ptr183 = ptrtoint ptr %mem182 to i64
  store i64 %ptr183, ptr %slot17, align 8
  %mem184 = alloca i8, i64 16, align 8
  %ptr185 = ptrtoint ptr %mem184 to i64
  store i64 %ptr185, ptr %slot18, align 8
  %mem186 = alloca i8, i64 16, align 8
  %ptr187 = ptrtoint ptr %mem186 to i64
  store i64 %ptr187, ptr %slot19, align 8
  %mem188 = alloca i8, i64 16, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot20, align 8
  %mem190 = alloca i8, i64 16, align 8
  %ptr191 = ptrtoint ptr %mem190 to i64
  store i64 %ptr191, ptr %slot21, align 8
  %mem192 = alloca i8, i64 16, align 8
  %ptr193 = ptrtoint ptr %mem192 to i64
  store i64 %ptr193, ptr %slot22, align 8
  %v194 = load i64, ptr %slot8, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot2, align 8
  %v197 = load i64, ptr %slot6, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 %v196, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot3, align 8
  %v200 = load i64, ptr %slot7, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v202 = load i64, ptr %slot6, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot23, align 8
  %v205 = load i64, ptr %slot23, align 8
  %v206 = load i64, ptr %slot11, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot11, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot24, align 8
  %v211 = load i64, ptr %slot24, align 8
  %op212 = add i64 %v211, 0
  store i64 %op212, ptr %slot25, align 8
  %v213 = load i64, ptr %slot25, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !4, !noalias !3
  store i64 %ld215, ptr %slot26, align 8
  %v216 = load i64, ptr %slot26, align 8
  %v217 = load i64, ptr %slot11, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot11, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot27, align 8
  %v222 = load i64, ptr %slot8, align 8
  store i64 %v222, ptr %slot28, align 8
  %v223 = load i64, ptr %slot27, align 8
  %v224 = load i64, ptr %slot28, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot7, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot29, align 8
  %v229 = load i64, ptr %slot29, align 8
  %v230 = load i64, ptr %slot11, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i64 %v229, ptr %p231, align 8, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot11, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot30, align 8
  %v235 = load i64, ptr %slot9, align 8
  store i64 %v235, ptr %slot31, align 8
  %v236 = load i64, ptr %slot30, align 8
  %v237 = load i64, ptr %slot31, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot9, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot32, align 8
  %v242 = load i64, ptr %slot32, align 8
  %v243 = load i64, ptr %slot11, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 %v242, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot12, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i64 0, ptr %p246, align 8, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot12, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot33, align 8
  %v250 = load i64, ptr %slot11, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot34, align 8
  %v253 = load i64, ptr %slot34, align 8
  %v254 = load i64, ptr %slot33, align 8
  %cmp255 = icmp slt i64 %v253, %v254
  %cv256 = zext i1 %cmp255 to i64
  store i64 %cv256, ptr %slot35, align 8
  %v257 = load i64, ptr %slot35, align 8
  %v258 = load i64, ptr %slot11, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot11, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot36, align 8
  %v263 = load i64, ptr %slot36, align 8
  %cond264 = icmp ne i64 %v263, 0
  br i1 %cond264, label %bb_next17, label %bb_i14
bb_next17:
  %v265 = load i64, ptr %slot8, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot37, align 8
  %v268 = load i64, ptr %slot37, align 8
  %op269 = add i64 %v268, 0
  store i64 %op269, ptr %slot38, align 8
  %v270 = load i64, ptr %slot38, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !6, !noalias !7
  store i64 %ld272, ptr %slot39, align 8
  %v273 = load i64, ptr %slot39, align 8
  %v274 = load i64, ptr %slot11, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 %v273, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot11, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot40, align 8
  %v279 = load i64, ptr %slot40, align 8
  %cmp280 = icmp ugt i64 %v279, 9223372036854775807
  %cv281 = zext i1 %cmp280 to i64
  store i64 %cv281, ptr %slot41, align 8
  %v282 = load i64, ptr %slot41, align 8
  %cond283 = icmp ne i64 %v282, 0
  br i1 %cond283, label %bb_cast_overflow22, label %bb_cast_ok22
bb_cast_overflow22:
  %v284 = load i64, ptr %slot1, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %v286 = load i64, ptr %slot40, align 8
  call void @myl_qbe_fail_cast(ptr %p285, i64 %v286, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok22:
  %v287 = load i64, ptr %slot40, align 8
  %v288 = load i64, ptr %slot11, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 %v287, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot9, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot42, align 8
  %v293 = load i64, ptr %slot42, align 8
  %v294 = load i64, ptr %slot12, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot12, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot43, align 8
  %v299 = load i64, ptr %slot11, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot44, align 8
  %v302 = load i64, ptr %slot44, align 8
  %v303 = load i64, ptr %slot43, align 8
  %ovpair305 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v302, i64 %v303)
  %op304 = extractvalue { i64, i1 } %ovpair305, 0
  %ov306 = extractvalue { i64, i1 } %ovpair305, 1
  store i64 %op304, ptr %slot45, align 8
  %v307 = load i64, ptr %slot44, align 8
  %v308 = load i64, ptr %slot45, align 8
  %op309 = xor i64 %v307, %v308
  store i64 %op309, ptr %slot46, align 8
  %v310 = load i64, ptr %slot43, align 8
  %v311 = load i64, ptr %slot45, align 8
  %op312 = xor i64 %v310, %v311
  store i64 %op312, ptr %slot47, align 8
  %v313 = load i64, ptr %slot46, align 8
  %v314 = load i64, ptr %slot47, align 8
  %op315 = and i64 %v313, %v314
  store i64 %op315, ptr %slot48, align 8
  %cv316 = zext i1 %ov306 to i64
  store i64 %cv316, ptr %slot49, align 8
  %v317 = load i64, ptr %slot49, align 8
  %cond318 = icmp ne i64 %v317, 0
  br i1 %cond318, label %bb_overflow26, label %bb_checked26
bb_overflow26:
  %v319 = load i64, ptr %slot1, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %v321 = load i64, ptr %slot44, align 8
  %v322 = load i64, ptr %slot43, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p320, i64 0, i64 %v321, i64 %v322, i64 64) nomerge, !dbg !112
  unreachable
bb_checked26:
  %v323 = load i64, ptr %slot45, align 8
  %v324 = load i64, ptr %slot11, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot11, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot50, align 8
  %v329 = load i64, ptr %slot9, align 8
  store i64 %v329, ptr %slot51, align 8
  %v330 = load i64, ptr %slot50, align 8
  %v331 = load i64, ptr %slot51, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i64 %v330, ptr %p332, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v333 = load i64, ptr %slot9, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %ld335 = load i64, ptr %p334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld335, ptr %slot52, align 8
  %v336 = load i64, ptr %slot52, align 8
  %v337 = load i64, ptr %slot11, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i64 %v336, ptr %p338, align 8, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot8, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %ld341 = load i64, ptr %p340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld341, ptr %slot53, align 8
  %v342 = load i64, ptr %slot11, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ld344 = load i64, ptr %p343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld344, ptr %slot54, align 8
  %v345 = load i64, ptr %slot53, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !6, !noalias !7
  store i64 %ld347, ptr %slot55, align 8
  %v348 = load i64, ptr %slot54, align 8
  %v349 = load i64, ptr %slot55, align 8
  %cmp350 = icmp ult i64 %v348, %v349
  %cv351 = zext i1 %cmp350 to i64
  store i64 %cv351, ptr %slot56, align 8
  %v352 = load i64, ptr %slot56, align 8
  %cond353 = icmp ne i64 %v352, 0
  br i1 %cond353, label %bb_success39, label %bb_failed39
bb_failed39:
  %v354 = load i64, ptr %slot1, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %v356 = load i64, ptr %slot54, align 8
  %v357 = load i64, ptr %slot55, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p355, i64 %v356, i64 %v357) nomerge, !dbg !114
  unreachable
bb_success39:
  %v358 = load i64, ptr %slot53, align 8
  %op359 = add i64 %v358, 32
  store i64 %op359, ptr %slot57, align 8
  %v360 = load i64, ptr %slot57, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !6, !noalias !7
  store i64 %ld362, ptr %slot58, align 8
  %v363 = load i64, ptr %slot54, align 8
  %op364 = mul i64 %v363, 56
  store i64 %op364, ptr %slot59, align 8
  %v365 = load i64, ptr %slot58, align 8
  %v366 = load i64, ptr %slot59, align 8
  %op367 = add i64 %v365, %v366
  store i64 %op367, ptr %slot60, align 8
  %v368 = load i64, ptr %slot60, align 8
  %v369 = load i64, ptr %slot11, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot11, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot61, align 8
  %v374 = load i64, ptr %slot61, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i32, ptr %p375, align 4, !alias.scope !12, !noalias !13
  %ext377 = zext i32 %ld376 to i64
  store i64 %ext377, ptr %slot62, align 8
  %v378 = load i64, ptr %slot62, align 8
  %cmp379 = icmp eq i64 %v378, 0
  %cv380 = zext i1 %cmp379 to i64
  store i64 %cv380, ptr %slot63, align 8
  %v381 = load i64, ptr %slot63, align 8
  %cond382 = icmp ne i64 %v381, 0
  br i1 %cond382, label %bb_arm46, label %bb_armnext46
bb_arm46:
  br label %bb_i19
bb_armnext46:
  %v383 = load i64, ptr %slot62, align 8
  %cmp384 = icmp eq i64 %v383, 1
  %cv385 = zext i1 %cmp384 to i64
  store i64 %cv385, ptr %slot64, align 8
  %v386 = load i64, ptr %slot64, align 8
  %cond387 = icmp ne i64 %v386, 0
  br i1 %cond387, label %bb_arm47, label %bb_armnext47
bb_arm47:
  %v388 = load i64, ptr %slot61, align 8
  %op389 = add i64 %v388, 8
  store i64 %op389, ptr %slot65, align 8
  %v390 = load i64, ptr %slot65, align 8
  %v391 = load i64, ptr %slot10, align 8
  %p392 = inttoptr i64 %v390 to ptr
  %p393 = inttoptr i64 %v391 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p393, ptr %p392, i64 16, i1 false), !alias.scope !10000000
  br label %bb_i17
bb_armnext47:
  %v394 = load i64, ptr %slot62, align 8
  %cmp395 = icmp eq i64 %v394, 2
  %cv396 = zext i1 %cmp395 to i64
  store i64 %cv396, ptr %slot66, align 8
  %v397 = load i64, ptr %slot66, align 8
  %cond398 = icmp ne i64 %v397, 0
  br i1 %cond398, label %bb_arm49, label %bb_armnext49
bb_arm49:
  br label %bb_i25
bb_armnext49:
  %v399 = load i64, ptr %slot62, align 8
  %cmp400 = icmp eq i64 %v399, 3
  %cv401 = zext i1 %cmp400 to i64
  store i64 %cv401, ptr %slot67, align 8
  %v402 = load i64, ptr %slot67, align 8
  %cond403 = icmp ne i64 %v402, 0
  br i1 %cond403, label %bb_arm50, label %bb_armnext50
bb_arm50:
  br label %bb_i31
bb_armnext50:
  %v404 = load i64, ptr %slot62, align 8
  %cmp405 = icmp eq i64 %v404, 4
  %cv406 = zext i1 %cmp405 to i64
  store i64 %cv406, ptr %slot68, align 8
  %v407 = load i64, ptr %slot68, align 8
  %cond408 = icmp ne i64 %v407, 0
  br i1 %cond408, label %bb_arm51, label %bb_armnext51
bb_arm51:
  br label %bb_i37
bb_armnext51:
  %v409 = load i64, ptr %slot62, align 8
  %cmp410 = icmp eq i64 %v409, 5
  %cv411 = zext i1 %cmp410 to i64
  store i64 %cv411, ptr %slot69, align 8
  %v412 = load i64, ptr %slot69, align 8
  %cond413 = icmp ne i64 %v412, 0
  br i1 %cond413, label %bb_arm52, label %bb_armnext52
bb_arm52:
  br label %bb_i43
bb_armnext52:
  %v414 = load i64, ptr %slot62, align 8
  %cmp415 = icmp eq i64 %v414, 6
  %cv416 = zext i1 %cmp415 to i64
  store i64 %cv416, ptr %slot70, align 8
  %v417 = load i64, ptr %slot70, align 8
  %cond418 = icmp ne i64 %v417, 0
  br i1 %cond418, label %bb_arm53, label %bb_armnext53
bb_arm53:
  br label %bb_i49
bb_armnext53:
  %v419 = load i64, ptr %slot62, align 8
  %cmp420 = icmp eq i64 %v419, 7
  %cv421 = zext i1 %cmp420 to i64
  store i64 %cv421, ptr %slot71, align 8
  %v422 = load i64, ptr %slot71, align 8
  %cond423 = icmp ne i64 %v422, 0
  br i1 %cond423, label %bb_arm54, label %bb_armnext54
bb_arm54:
  br label %bb_i55
bb_armnext54:
  %v424 = load i64, ptr %slot62, align 8
  %cmp425 = icmp eq i64 %v424, 8
  %cv426 = zext i1 %cmp425 to i64
  store i64 %cv426, ptr %slot72, align 8
  %v427 = load i64, ptr %slot72, align 8
  %cond428 = icmp ne i64 %v427, 0
  br i1 %cond428, label %bb_arm55, label %bb_armnext55
bb_arm55:
  br label %bb_i61
bb_armnext55:
  %v429 = load i64, ptr %slot62, align 8
  %cmp430 = icmp eq i64 %v429, 9
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot73, align 8
  %v432 = load i64, ptr %slot73, align 8
  %cond433 = icmp ne i64 %v432, 0
  br i1 %cond433, label %bb_arm56, label %bb_armnext56
bb_arm56:
  br label %bb_i67
bb_armnext56:
  %v434 = load i64, ptr %slot62, align 8
  %cmp435 = icmp eq i64 %v434, 10
  %cv436 = zext i1 %cmp435 to i64
  store i64 %cv436, ptr %slot74, align 8
  %v437 = load i64, ptr %slot74, align 8
  %cond438 = icmp ne i64 %v437, 0
  br i1 %cond438, label %bb_arm57, label %bb_armnext57
bb_arm57:
  br label %bb_i73
bb_armnext57:
  br label %bb_failure
bb_i17:
  %v439 = load i64, ptr %slot10, align 8
  %v440 = load i64, ptr %slot11, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i64 %v439, ptr %p441, align 8, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot11, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %ld444 = load i64, ptr %p443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld444, ptr %slot75, align 8
  %v445 = load i64, ptr %slot75, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ret447 = load { i64, i64 }, ptr %p446, align 8
  ret { i64, i64 } %ret447
bb_i19:
  %v448 = load i64, ptr %slot11, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 0, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot11, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i64, ptr %p451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot76, align 8
  %v453 = load i64, ptr %slot76, align 8
  %cond454 = icmp ne i64 %v453, 0
  br i1 %cond454, label %bb_success124, label %bb_failed124
bb_failed124:
  %v455 = load i64, ptr %slot1, align 8
  %p456 = inttoptr i64 %v455 to ptr
  call void @myl_qbe_fail_assert(ptr %p456) nomerge, !dbg !116
  unreachable
bb_success124:
  %p457 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld458 = load i64, ptr %p457, align 8, !alias.scope !4, !noalias !3
  store i64 %ld458, ptr %slot77, align 8
  %v459 = load i64, ptr %slot77, align 8
  %v460 = load i64, ptr %slot11, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 %v459, ptr %p461, align 8, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot12, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 0, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot13, align 8
  store i64 %v464, ptr %slot78, align 8
  %v465 = load i64, ptr %slot78, align 8
  %p467 = inttoptr i64 %v465 to ptr
  %gep468 = getelementptr i8, ptr %p467, i64 0
  %op466 = ptrtoint ptr %gep468 to i64
  store i64 %op466, ptr %slot79, align 8
  %v469 = load i64, ptr %slot11, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ld471 = load i64, ptr %p470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld471, ptr %slot80, align 8
  %v472 = load i64, ptr %slot80, align 8
  %v473 = load i64, ptr %slot79, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i64 %v472, ptr %p474, align 8, !alias.scope !3, !noalias !4
  %v475 = load i64, ptr %slot78, align 8
  %p477 = inttoptr i64 %v475 to ptr
  %gep478 = getelementptr i8, ptr %p477, i64 8
  %op476 = ptrtoint ptr %gep478 to i64
  store i64 %op476, ptr %slot81, align 8
  %v479 = load i64, ptr %slot12, align 8
  %p480 = inttoptr i64 %v479 to ptr
  %ld481 = load i64, ptr %p480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld481, ptr %slot82, align 8
  %v482 = load i64, ptr %slot82, align 8
  %cv483 = trunc i64 %v482 to i32
  %v484 = load i64, ptr %slot81, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 %cv483, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot78, align 8
  %v487 = load i64, ptr %slot11, align 8
  %p488 = inttoptr i64 %v487 to ptr
  store i64 %v486, ptr %p488, align 8, !alias.scope !3, !noalias !4
  %v489 = load i64, ptr %slot11, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld491, ptr %slot83, align 8
  %v492 = load i64, ptr %slot83, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ret494 = load { i64, i64 }, ptr %p493, align 8
  ret { i64, i64 } %ret494
bb_i25:
  %v495 = load i64, ptr %slot11, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i64 0, ptr %p496, align 8, !alias.scope !3, !noalias !4
  %v497 = load i64, ptr %slot11, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i64, ptr %p498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld499, ptr %slot84, align 8
  %v500 = load i64, ptr %slot84, align 8
  %cond501 = icmp ne i64 %v500, 0
  br i1 %cond501, label %bb_success198, label %bb_failed198
bb_failed198:
  %v502 = load i64, ptr %slot1, align 8
  %p503 = inttoptr i64 %v502 to ptr
  call void @myl_qbe_fail_assert(ptr %p503) nomerge, !dbg !118
  unreachable
bb_success198:
  %p504 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld505 = load i64, ptr %p504, align 8, !alias.scope !4, !noalias !3
  store i64 %ld505, ptr %slot85, align 8
  %v506 = load i64, ptr %slot85, align 8
  %v507 = load i64, ptr %slot11, align 8
  %p508 = inttoptr i64 %v507 to ptr
  store i64 %v506, ptr %p508, align 8, !alias.scope !3, !noalias !4
  %v509 = load i64, ptr %slot12, align 8
  %p510 = inttoptr i64 %v509 to ptr
  store i64 0, ptr %p510, align 8, !alias.scope !3, !noalias !4
  %v511 = load i64, ptr %slot14, align 8
  store i64 %v511, ptr %slot86, align 8
  %v512 = load i64, ptr %slot86, align 8
  %p514 = inttoptr i64 %v512 to ptr
  %gep515 = getelementptr i8, ptr %p514, i64 0
  %op513 = ptrtoint ptr %gep515 to i64
  store i64 %op513, ptr %slot87, align 8
  %v516 = load i64, ptr %slot11, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot88, align 8
  %v519 = load i64, ptr %slot88, align 8
  %v520 = load i64, ptr %slot87, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 %v519, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot86, align 8
  %p524 = inttoptr i64 %v522 to ptr
  %gep525 = getelementptr i8, ptr %p524, i64 8
  %op523 = ptrtoint ptr %gep525 to i64
  store i64 %op523, ptr %slot89, align 8
  %v526 = load i64, ptr %slot12, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %ld528 = load i64, ptr %p527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld528, ptr %slot90, align 8
  %v529 = load i64, ptr %slot90, align 8
  %cv530 = trunc i64 %v529 to i32
  %v531 = load i64, ptr %slot89, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i32 %cv530, ptr %p532, align 4, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot86, align 8
  %v534 = load i64, ptr %slot11, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot11, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld538, ptr %slot91, align 8
  %v539 = load i64, ptr %slot91, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %ret541 = load { i64, i64 }, ptr %p540, align 8
  ret { i64, i64 } %ret541
bb_i31:
  %v542 = load i64, ptr %slot11, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 0, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot11, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot92, align 8
  %v547 = load i64, ptr %slot92, align 8
  %cond548 = icmp ne i64 %v547, 0
  br i1 %cond548, label %bb_success272, label %bb_failed272
bb_failed272:
  %v549 = load i64, ptr %slot1, align 8
  %p550 = inttoptr i64 %v549 to ptr
  call void @myl_qbe_fail_assert(ptr %p550) nomerge, !dbg !120
  unreachable
bb_success272:
  %p551 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !4, !noalias !3
  store i64 %ld552, ptr %slot93, align 8
  %v553 = load i64, ptr %slot93, align 8
  %v554 = load i64, ptr %slot11, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i64 %v553, ptr %p555, align 8, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot12, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i64 0, ptr %p557, align 8, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot15, align 8
  store i64 %v558, ptr %slot94, align 8
  %v559 = load i64, ptr %slot94, align 8
  %p561 = inttoptr i64 %v559 to ptr
  %gep562 = getelementptr i8, ptr %p561, i64 0
  %op560 = ptrtoint ptr %gep562 to i64
  store i64 %op560, ptr %slot95, align 8
  %v563 = load i64, ptr %slot11, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot96, align 8
  %v566 = load i64, ptr %slot96, align 8
  %v567 = load i64, ptr %slot95, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot94, align 8
  %p571 = inttoptr i64 %v569 to ptr
  %gep572 = getelementptr i8, ptr %p571, i64 8
  %op570 = ptrtoint ptr %gep572 to i64
  store i64 %op570, ptr %slot97, align 8
  %v573 = load i64, ptr %slot12, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i64, ptr %p574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld575, ptr %slot98, align 8
  %v576 = load i64, ptr %slot98, align 8
  %cv577 = trunc i64 %v576 to i32
  %v578 = load i64, ptr %slot97, align 8
  %p579 = inttoptr i64 %v578 to ptr
  store i32 %cv577, ptr %p579, align 4, !alias.scope !3, !noalias !4
  %v580 = load i64, ptr %slot94, align 8
  %v581 = load i64, ptr %slot11, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot11, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot99, align 8
  %v586 = load i64, ptr %slot99, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ret588 = load { i64, i64 }, ptr %p587, align 8
  ret { i64, i64 } %ret588
bb_i37:
  %v589 = load i64, ptr %slot11, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 0, ptr %p590, align 8, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot11, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i64, ptr %p592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld593, ptr %slot100, align 8
  %v594 = load i64, ptr %slot100, align 8
  %cond595 = icmp ne i64 %v594, 0
  br i1 %cond595, label %bb_success346, label %bb_failed346
bb_failed346:
  %v596 = load i64, ptr %slot1, align 8
  %p597 = inttoptr i64 %v596 to ptr
  call void @myl_qbe_fail_assert(ptr %p597) nomerge, !dbg !122
  unreachable
bb_success346:
  %p598 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld599 = load i64, ptr %p598, align 8, !alias.scope !4, !noalias !3
  store i64 %ld599, ptr %slot101, align 8
  %v600 = load i64, ptr %slot101, align 8
  %v601 = load i64, ptr %slot11, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i64 %v600, ptr %p602, align 8, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot12, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i64 0, ptr %p604, align 8, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot16, align 8
  store i64 %v605, ptr %slot102, align 8
  %v606 = load i64, ptr %slot102, align 8
  %p608 = inttoptr i64 %v606 to ptr
  %gep609 = getelementptr i8, ptr %p608, i64 0
  %op607 = ptrtoint ptr %gep609 to i64
  store i64 %op607, ptr %slot103, align 8
  %v610 = load i64, ptr %slot11, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot104, align 8
  %v613 = load i64, ptr %slot104, align 8
  %v614 = load i64, ptr %slot103, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i64 %v613, ptr %p615, align 8, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot102, align 8
  %p618 = inttoptr i64 %v616 to ptr
  %gep619 = getelementptr i8, ptr %p618, i64 8
  %op617 = ptrtoint ptr %gep619 to i64
  store i64 %op617, ptr %slot105, align 8
  %v620 = load i64, ptr %slot12, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot106, align 8
  %v623 = load i64, ptr %slot106, align 8
  %cv624 = trunc i64 %v623 to i32
  %v625 = load i64, ptr %slot105, align 8
  %p626 = inttoptr i64 %v625 to ptr
  store i32 %cv624, ptr %p626, align 4, !alias.scope !3, !noalias !4
  %v627 = load i64, ptr %slot102, align 8
  %v628 = load i64, ptr %slot11, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot11, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %ld632 = load i64, ptr %p631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld632, ptr %slot107, align 8
  %v633 = load i64, ptr %slot107, align 8
  %p634 = inttoptr i64 %v633 to ptr
  %ret635 = load { i64, i64 }, ptr %p634, align 8
  ret { i64, i64 } %ret635
bb_i43:
  %v636 = load i64, ptr %slot11, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i64 0, ptr %p637, align 8, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot11, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i64, ptr %p639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld640, ptr %slot108, align 8
  %v641 = load i64, ptr %slot108, align 8
  %cond642 = icmp ne i64 %v641, 0
  br i1 %cond642, label %bb_success420, label %bb_failed420
bb_failed420:
  %v643 = load i64, ptr %slot1, align 8
  %p644 = inttoptr i64 %v643 to ptr
  call void @myl_qbe_fail_assert(ptr %p644) nomerge, !dbg !124
  unreachable
bb_success420:
  %p645 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld646 = load i64, ptr %p645, align 8, !alias.scope !4, !noalias !3
  store i64 %ld646, ptr %slot109, align 8
  %v647 = load i64, ptr %slot109, align 8
  %v648 = load i64, ptr %slot11, align 8
  %p649 = inttoptr i64 %v648 to ptr
  store i64 %v647, ptr %p649, align 8, !alias.scope !3, !noalias !4
  %v650 = load i64, ptr %slot12, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i64 0, ptr %p651, align 8, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot17, align 8
  store i64 %v652, ptr %slot110, align 8
  %v653 = load i64, ptr %slot110, align 8
  %p655 = inttoptr i64 %v653 to ptr
  %gep656 = getelementptr i8, ptr %p655, i64 0
  %op654 = ptrtoint ptr %gep656 to i64
  store i64 %op654, ptr %slot111, align 8
  %v657 = load i64, ptr %slot11, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot112, align 8
  %v660 = load i64, ptr %slot112, align 8
  %v661 = load i64, ptr %slot111, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i64 %v660, ptr %p662, align 8, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot110, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %gep666 = getelementptr i8, ptr %p665, i64 8
  %op664 = ptrtoint ptr %gep666 to i64
  store i64 %op664, ptr %slot113, align 8
  %v667 = load i64, ptr %slot12, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot114, align 8
  %v670 = load i64, ptr %slot114, align 8
  %cv671 = trunc i64 %v670 to i32
  %v672 = load i64, ptr %slot113, align 8
  %p673 = inttoptr i64 %v672 to ptr
  store i32 %cv671, ptr %p673, align 4, !alias.scope !3, !noalias !4
  %v674 = load i64, ptr %slot110, align 8
  %v675 = load i64, ptr %slot11, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i64 %v674, ptr %p676, align 8, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot11, align 8
  %p678 = inttoptr i64 %v677 to ptr
  %ld679 = load i64, ptr %p678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld679, ptr %slot115, align 8
  %v680 = load i64, ptr %slot115, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %ret682 = load { i64, i64 }, ptr %p681, align 8
  ret { i64, i64 } %ret682
bb_i49:
  %v683 = load i64, ptr %slot11, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i64 0, ptr %p684, align 8, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot11, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %ld687 = load i64, ptr %p686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld687, ptr %slot116, align 8
  %v688 = load i64, ptr %slot116, align 8
  %cond689 = icmp ne i64 %v688, 0
  br i1 %cond689, label %bb_success494, label %bb_failed494
bb_failed494:
  %v690 = load i64, ptr %slot1, align 8
  %p691 = inttoptr i64 %v690 to ptr
  call void @myl_qbe_fail_assert(ptr %p691) nomerge, !dbg !126
  unreachable
bb_success494:
  %p692 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld693 = load i64, ptr %p692, align 8, !alias.scope !4, !noalias !3
  store i64 %ld693, ptr %slot117, align 8
  %v694 = load i64, ptr %slot117, align 8
  %v695 = load i64, ptr %slot11, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 %v694, ptr %p696, align 8, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot12, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i64 0, ptr %p698, align 8, !alias.scope !3, !noalias !4
  %v699 = load i64, ptr %slot18, align 8
  store i64 %v699, ptr %slot118, align 8
  %v700 = load i64, ptr %slot118, align 8
  %p702 = inttoptr i64 %v700 to ptr
  %gep703 = getelementptr i8, ptr %p702, i64 0
  %op701 = ptrtoint ptr %gep703 to i64
  store i64 %op701, ptr %slot119, align 8
  %v704 = load i64, ptr %slot11, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %ld706 = load i64, ptr %p705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld706, ptr %slot120, align 8
  %v707 = load i64, ptr %slot120, align 8
  %v708 = load i64, ptr %slot119, align 8
  %p709 = inttoptr i64 %v708 to ptr
  store i64 %v707, ptr %p709, align 8, !alias.scope !3, !noalias !4
  %v710 = load i64, ptr %slot118, align 8
  %p712 = inttoptr i64 %v710 to ptr
  %gep713 = getelementptr i8, ptr %p712, i64 8
  %op711 = ptrtoint ptr %gep713 to i64
  store i64 %op711, ptr %slot121, align 8
  %v714 = load i64, ptr %slot12, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i64, ptr %p715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld716, ptr %slot122, align 8
  %v717 = load i64, ptr %slot122, align 8
  %cv718 = trunc i64 %v717 to i32
  %v719 = load i64, ptr %slot121, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i32 %cv718, ptr %p720, align 4, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot118, align 8
  %v722 = load i64, ptr %slot11, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 %v721, ptr %p723, align 8, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot11, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i64, ptr %p725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld726, ptr %slot123, align 8
  %v727 = load i64, ptr %slot123, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ret729 = load { i64, i64 }, ptr %p728, align 8
  ret { i64, i64 } %ret729
bb_i55:
  %v730 = load i64, ptr %slot11, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i64 0, ptr %p731, align 8, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot11, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot124, align 8
  %v735 = load i64, ptr %slot124, align 8
  %cond736 = icmp ne i64 %v735, 0
  br i1 %cond736, label %bb_success568, label %bb_failed568
bb_failed568:
  %v737 = load i64, ptr %slot1, align 8
  %p738 = inttoptr i64 %v737 to ptr
  call void @myl_qbe_fail_assert(ptr %p738) nomerge, !dbg !128
  unreachable
bb_success568:
  %p739 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !4, !noalias !3
  store i64 %ld740, ptr %slot125, align 8
  %v741 = load i64, ptr %slot125, align 8
  %v742 = load i64, ptr %slot11, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i64 %v741, ptr %p743, align 8, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot12, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 0, ptr %p745, align 8, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot19, align 8
  store i64 %v746, ptr %slot126, align 8
  %v747 = load i64, ptr %slot126, align 8
  %p749 = inttoptr i64 %v747 to ptr
  %gep750 = getelementptr i8, ptr %p749, i64 0
  %op748 = ptrtoint ptr %gep750 to i64
  store i64 %op748, ptr %slot127, align 8
  %v751 = load i64, ptr %slot11, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i64, ptr %p752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld753, ptr %slot128, align 8
  %v754 = load i64, ptr %slot128, align 8
  %v755 = load i64, ptr %slot127, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i64 %v754, ptr %p756, align 8, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot126, align 8
  %p759 = inttoptr i64 %v757 to ptr
  %gep760 = getelementptr i8, ptr %p759, i64 8
  %op758 = ptrtoint ptr %gep760 to i64
  store i64 %op758, ptr %slot129, align 8
  %v761 = load i64, ptr %slot12, align 8
  %p762 = inttoptr i64 %v761 to ptr
  %ld763 = load i64, ptr %p762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld763, ptr %slot130, align 8
  %v764 = load i64, ptr %slot130, align 8
  %cv765 = trunc i64 %v764 to i32
  %v766 = load i64, ptr %slot129, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 %cv765, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot126, align 8
  %v769 = load i64, ptr %slot11, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i64 %v768, ptr %p770, align 8, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot11, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %ld773 = load i64, ptr %p772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld773, ptr %slot131, align 8
  %v774 = load i64, ptr %slot131, align 8
  %p775 = inttoptr i64 %v774 to ptr
  %ret776 = load { i64, i64 }, ptr %p775, align 8
  ret { i64, i64 } %ret776
bb_i61:
  %v777 = load i64, ptr %slot11, align 8
  %p778 = inttoptr i64 %v777 to ptr
  store i64 0, ptr %p778, align 8, !alias.scope !3, !noalias !4
  %v779 = load i64, ptr %slot11, align 8
  %p780 = inttoptr i64 %v779 to ptr
  %ld781 = load i64, ptr %p780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld781, ptr %slot132, align 8
  %v782 = load i64, ptr %slot132, align 8
  %cond783 = icmp ne i64 %v782, 0
  br i1 %cond783, label %bb_success642, label %bb_failed642
bb_failed642:
  %v784 = load i64, ptr %slot1, align 8
  %p785 = inttoptr i64 %v784 to ptr
  call void @myl_qbe_fail_assert(ptr %p785) nomerge, !dbg !130
  unreachable
bb_success642:
  %p786 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld787 = load i64, ptr %p786, align 8, !alias.scope !4, !noalias !3
  store i64 %ld787, ptr %slot133, align 8
  %v788 = load i64, ptr %slot133, align 8
  %v789 = load i64, ptr %slot11, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i64 %v788, ptr %p790, align 8, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot12, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 0, ptr %p792, align 8, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot20, align 8
  store i64 %v793, ptr %slot134, align 8
  %v794 = load i64, ptr %slot134, align 8
  %p796 = inttoptr i64 %v794 to ptr
  %gep797 = getelementptr i8, ptr %p796, i64 0
  %op795 = ptrtoint ptr %gep797 to i64
  store i64 %op795, ptr %slot135, align 8
  %v798 = load i64, ptr %slot11, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld800, ptr %slot136, align 8
  %v801 = load i64, ptr %slot136, align 8
  %v802 = load i64, ptr %slot135, align 8
  %p803 = inttoptr i64 %v802 to ptr
  store i64 %v801, ptr %p803, align 8, !alias.scope !3, !noalias !4
  %v804 = load i64, ptr %slot134, align 8
  %p806 = inttoptr i64 %v804 to ptr
  %gep807 = getelementptr i8, ptr %p806, i64 8
  %op805 = ptrtoint ptr %gep807 to i64
  store i64 %op805, ptr %slot137, align 8
  %v808 = load i64, ptr %slot12, align 8
  %p809 = inttoptr i64 %v808 to ptr
  %ld810 = load i64, ptr %p809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld810, ptr %slot138, align 8
  %v811 = load i64, ptr %slot138, align 8
  %cv812 = trunc i64 %v811 to i32
  %v813 = load i64, ptr %slot137, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i32 %cv812, ptr %p814, align 4, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot134, align 8
  %v816 = load i64, ptr %slot11, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot11, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot139, align 8
  %v821 = load i64, ptr %slot139, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ret823 = load { i64, i64 }, ptr %p822, align 8
  ret { i64, i64 } %ret823
bb_i67:
  %v824 = load i64, ptr %slot11, align 8
  %p825 = inttoptr i64 %v824 to ptr
  store i64 0, ptr %p825, align 8, !alias.scope !3, !noalias !4
  %v826 = load i64, ptr %slot11, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i64, ptr %p827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld828, ptr %slot140, align 8
  %v829 = load i64, ptr %slot140, align 8
  %cond830 = icmp ne i64 %v829, 0
  br i1 %cond830, label %bb_success716, label %bb_failed716
bb_failed716:
  %v831 = load i64, ptr %slot1, align 8
  %p832 = inttoptr i64 %v831 to ptr
  call void @myl_qbe_fail_assert(ptr %p832) nomerge, !dbg !132
  unreachable
bb_success716:
  %p833 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld834 = load i64, ptr %p833, align 8, !alias.scope !4, !noalias !3
  store i64 %ld834, ptr %slot141, align 8
  %v835 = load i64, ptr %slot141, align 8
  %v836 = load i64, ptr %slot11, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i64 %v835, ptr %p837, align 8, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot12, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i64 0, ptr %p839, align 8, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot21, align 8
  store i64 %v840, ptr %slot142, align 8
  %v841 = load i64, ptr %slot142, align 8
  %p843 = inttoptr i64 %v841 to ptr
  %gep844 = getelementptr i8, ptr %p843, i64 0
  %op842 = ptrtoint ptr %gep844 to i64
  store i64 %op842, ptr %slot143, align 8
  %v845 = load i64, ptr %slot11, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld847, ptr %slot144, align 8
  %v848 = load i64, ptr %slot144, align 8
  %v849 = load i64, ptr %slot143, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i64 %v848, ptr %p850, align 8, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot142, align 8
  %p853 = inttoptr i64 %v851 to ptr
  %gep854 = getelementptr i8, ptr %p853, i64 8
  %op852 = ptrtoint ptr %gep854 to i64
  store i64 %op852, ptr %slot145, align 8
  %v855 = load i64, ptr %slot12, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i64, ptr %p856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld857, ptr %slot146, align 8
  %v858 = load i64, ptr %slot146, align 8
  %cv859 = trunc i64 %v858 to i32
  %v860 = load i64, ptr %slot145, align 8
  %p861 = inttoptr i64 %v860 to ptr
  store i32 %cv859, ptr %p861, align 4, !alias.scope !3, !noalias !4
  %v862 = load i64, ptr %slot142, align 8
  %v863 = load i64, ptr %slot11, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i64 %v862, ptr %p864, align 8, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot11, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot147, align 8
  %v868 = load i64, ptr %slot147, align 8
  %p869 = inttoptr i64 %v868 to ptr
  %ret870 = load { i64, i64 }, ptr %p869, align 8
  ret { i64, i64 } %ret870
bb_i73:
  %v871 = load i64, ptr %slot11, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 0, ptr %p872, align 8, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot11, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ld875 = load i64, ptr %p874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld875, ptr %slot148, align 8
  %v876 = load i64, ptr %slot148, align 8
  %cond877 = icmp ne i64 %v876, 0
  br i1 %cond877, label %bb_success790, label %bb_failed790
bb_failed790:
  %v878 = load i64, ptr %slot1, align 8
  %p879 = inttoptr i64 %v878 to ptr
  call void @myl_qbe_fail_assert(ptr %p879) nomerge, !dbg !134
  unreachable
bb_success790:
  %p880 = inttoptr i64 ptrtoint (ptr @myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 to i64) to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !4, !noalias !3
  store i64 %ld881, ptr %slot149, align 8
  %v882 = load i64, ptr %slot149, align 8
  %v883 = load i64, ptr %slot11, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i64 %v882, ptr %p884, align 8, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot12, align 8
  %p886 = inttoptr i64 %v885 to ptr
  store i64 0, ptr %p886, align 8, !alias.scope !3, !noalias !4
  %v887 = load i64, ptr %slot22, align 8
  store i64 %v887, ptr %slot150, align 8
  %v888 = load i64, ptr %slot150, align 8
  %p890 = inttoptr i64 %v888 to ptr
  %gep891 = getelementptr i8, ptr %p890, i64 0
  %op889 = ptrtoint ptr %gep891 to i64
  store i64 %op889, ptr %slot151, align 8
  %v892 = load i64, ptr %slot11, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %ld894 = load i64, ptr %p893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld894, ptr %slot152, align 8
  %v895 = load i64, ptr %slot152, align 8
  %v896 = load i64, ptr %slot151, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i64 %v895, ptr %p897, align 8, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot150, align 8
  %p900 = inttoptr i64 %v898 to ptr
  %gep901 = getelementptr i8, ptr %p900, i64 8
  %op899 = ptrtoint ptr %gep901 to i64
  store i64 %op899, ptr %slot153, align 8
  %v902 = load i64, ptr %slot12, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %ld904 = load i64, ptr %p903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld904, ptr %slot154, align 8
  %v905 = load i64, ptr %slot154, align 8
  %cv906 = trunc i64 %v905 to i32
  %v907 = load i64, ptr %slot153, align 8
  %p908 = inttoptr i64 %v907 to ptr
  store i32 %cv906, ptr %p908, align 4, !alias.scope !3, !noalias !4
  %v909 = load i64, ptr %slot150, align 8
  %v910 = load i64, ptr %slot11, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i64 %v909, ptr %p911, align 8, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot11, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i64, ptr %p913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld914, ptr %slot155, align 8
  %v915 = load i64, ptr %slot155, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ret917 = load { i64, i64 }, ptr %p916, align 8
  ret { i64, i64 } %ret917
bb_failure:
  %v918 = load i64, ptr %slot5, align 8
  %p919 = inttoptr i64 %v918 to ptr
  call void @llvm.memset.p0.i64(ptr %p919, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !136
  %v920 = load i64, ptr %slot5, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ret922 = load { i64, i64 }, ptr %p921, align 8
  ret { i64, i64 } %ret922
bb_entry_failure:
  %v923 = load i64, ptr %slot5, align 8
  %p924 = inttoptr i64 %v923 to ptr
  call void @llvm.memset.p0.i64(ptr %p924, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !136
  %v925 = load i64, ptr %slot5, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ret927 = load { i64, i64 }, ptr %p926, align 8
  ret { i64, i64 } %ret927
}

@myl_lit_5ffcfeefbc77603111eb9faae2375c1bd71d00fc5610c522261905cf007d59b3 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow", linkageName: "myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11293615444448434568, i64 0, !"myl_f_b54eeed03870b797a96d1738a2f42781bb5db72dae7d2f57e436551c3d0172dd_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!110 = !DILocation(line: 11, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!112 = !DILocation(line: 13, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!116 = !DILocation(line: 21, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!118 = !DILocation(line: 27, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!120 = !DILocation(line: 33, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!122 = !DILocation(line: 39, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!124 = !DILocation(line: 45, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!126 = !DILocation(line: 51, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!128 = !DILocation(line: 57, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!130 = !DILocation(line: 63, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!132 = !DILocation(line: 69, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!134 = !DILocation(line: 75, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!136 = !DILocation(line: 79, column: 0, scope: !137)
