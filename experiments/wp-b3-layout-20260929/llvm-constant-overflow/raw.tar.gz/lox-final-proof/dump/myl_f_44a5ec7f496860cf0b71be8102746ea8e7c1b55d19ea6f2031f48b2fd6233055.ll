target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v366 = load i64, ptr %slot1, align 8
  %op367 = add i64 %v366, 32
  store i64 %op367, ptr %slot4, align 8
  %mem368 = alloca i8, i64 8, align 8
  %ptr369 = ptrtoint ptr %mem368 to i64
  store i64 %ptr369, ptr %slot5, align 8
  %mem370 = alloca i8, i64 8, align 8
  %ptr371 = ptrtoint ptr %mem370 to i64
  store i64 %ptr371, ptr %slot6, align 8
  %mem372 = alloca i8, i64 8, align 8
  %ptr373 = ptrtoint ptr %mem372 to i64
  store i64 %ptr373, ptr %slot7, align 8
  %mem374 = alloca i8, i64 8, align 8
  %ptr375 = ptrtoint ptr %mem374 to i64
  store i64 %ptr375, ptr %slot8, align 8
  %mem376 = alloca i8, i64 312, align 8
  %ptr377 = ptrtoint ptr %mem376 to i64
  store i64 %ptr377, ptr %slot9, align 8
  %mem378 = alloca i8, i64 8, align 8
  %ptr379 = ptrtoint ptr %mem378 to i64
  store i64 %ptr379, ptr %slot10, align 8
  %mem380 = alloca i8, i64 312, align 8
  %ptr381 = ptrtoint ptr %mem380 to i64
  store i64 %ptr381, ptr %slot11, align 8
  %mem382 = alloca i8, i64 32, align 8
  %ptr383 = ptrtoint ptr %mem382 to i64
  store i64 %ptr383, ptr %slot12, align 8
  %v384 = load i64, ptr %slot12, align 8
  %p386 = inttoptr i64 %v384 to ptr
  %gep387 = getelementptr i8, ptr %p386, i64 24
  %op385 = ptrtoint ptr %gep387 to i64
  store i64 %op385, ptr %slot13, align 8
  %v388 = load i64, ptr %slot13, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i64 0, ptr %p389, align 8, !alias.scope !3, !noalias !4
  %mem390 = alloca i8, i64 8, align 8
  %ptr391 = ptrtoint ptr %mem390 to i64
  store i64 %ptr391, ptr %slot14, align 8
  %mem392 = alloca i8, i64 8, align 8
  %ptr393 = ptrtoint ptr %mem392 to i64
  store i64 %ptr393, ptr %slot15, align 8
  %mem394 = alloca i8, i64 8, align 8
  %ptr395 = ptrtoint ptr %mem394 to i64
  store i64 %ptr395, ptr %slot16, align 8
  %mem396 = alloca i8, i64 8, align 8
  %ptr397 = ptrtoint ptr %mem396 to i64
  store i64 %ptr397, ptr %slot17, align 8
  %mem398 = alloca i8, i64 8, align 8
  %ptr399 = ptrtoint ptr %mem398 to i64
  store i64 %ptr399, ptr %slot18, align 8
  %mem400 = alloca i8, i64 8, align 8
  %ptr401 = ptrtoint ptr %mem400 to i64
  store i64 %ptr401, ptr %slot19, align 8
  %mem402 = alloca i8, i64 8, align 8
  %ptr403 = ptrtoint ptr %mem402 to i64
  store i64 %ptr403, ptr %slot20, align 8
  %v404 = load i64, ptr %slot17, align 8
  %p405 = inttoptr i64 %v404 to ptr
  store i64 0, ptr %p405, align 8, !alias.scope !3, !noalias !4
  %v406 = load i64, ptr %slot18, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 0, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot2, align 8
  %v409 = load i64, ptr %slot15, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i64 %v408, ptr %p410, align 8, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot3, align 8
  %v412 = load i64, ptr %slot16, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot1, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %call416 = call ptr @myl_qbe_heap(ptr %p415) nomerge, !dbg !110
  %calladdr417 = ptrtoint ptr %call416 to i64
  store i64 %calladdr417, ptr %slot21, align 8
  %v418 = load i64, ptr %slot1, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %call420 = call i64 @myl_qbe_region_mark(ptr %p419) nomerge, !dbg !110
  store i64 %call420, ptr %slot22, align 8
  %v421 = load i64, ptr %slot5, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i32 0, ptr %p422, align 4, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot6, align 8
  %p424 = inttoptr i64 %v423 to ptr
  store i32 0, ptr %p424, align 4, !alias.scope !3, !noalias !4
  %v425 = load i64, ptr %slot7, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i32 0, ptr %p426, align 4, !alias.scope !3, !noalias !4
  %v427 = load i64, ptr %slot8, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i32 0, ptr %p428, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v429 = load i64, ptr %slot15, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot23, align 8
  %v432 = load i64, ptr %slot23, align 8
  %v433 = load i64, ptr %slot19, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot19, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i64, ptr %p436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld437, ptr %slot24, align 8
  %v438 = load i64, ptr %slot24, align 8
  %op439 = add i64 %v438, 280
  store i64 %op439, ptr %slot25, align 8
  %v440 = load i64, ptr %slot25, align 8
  %v441 = load i64, ptr %slot19, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 %v440, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot5, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i32, ptr %p444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld445, ptr %slot26, align 8
  %v446 = load i32, ptr %slot26, align 8
  %cv447 = zext i32 %v446 to i64
  %cond448 = icmp ne i64 %cv447, 0
  br i1 %cond448, label %bb_rcslotdrop10, label %bb_rcslotdone10
bb_rcslotdrop10:
  %v449 = load i64, ptr %slot5, align 8
  %p450 = inttoptr i64 %v449 to ptr
  store i32 0, ptr %p450, align 4, !alias.scope !3, !noalias !4
  %v451 = load i64, ptr %slot9, align 8
  store i64 %v451, ptr %slot27, align 8
  %v452 = load i64, ptr %slot6, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i32, ptr %p453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld454, ptr %slot28, align 8
  %v455 = load i32, ptr %slot28, align 8
  %op456 = and i32 %v455, 28
  store i32 %op456, ptr %slot29, align 8
  %v457 = load i32, ptr %slot29, align 8
  %cv458 = zext i32 %v457 to i64
  %cond459 = icmp ne i64 %cv458, 0
  br i1 %cond459, label %bb_rcslotrole10, label %bb_rcslotowner10
bb_rcslotrole10:
  %v460 = load i64, ptr %slot21, align 8
  store i64 %v460, ptr %slot30, align 8
  %v461 = load i64, ptr %slot30, align 8
  %v462 = load i64, ptr %slot27, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v461, i64 %v462) nomerge, !dbg !112
  br label %bb_rcslotdone10
bb_rcslotowner10:
  %v463 = load i64, ptr %slot21, align 8
  store i64 %v463, ptr %slot31, align 8
  %v464 = load i64, ptr %slot31, align 8
  %v465 = load i64, ptr %slot27, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v464, i64 %v465) nomerge, !dbg !112
  br label %bb_rcslotdone10
bb_rcslotdone10:
  %v466 = load i64, ptr %slot19, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %ld468 = load i64, ptr %p467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld468, ptr %slot32, align 8
  %v469 = load i64, ptr %slot32, align 8
  %op470 = add i64 %v469, 0
  store i64 %op470, ptr %slot33, align 8
  %v471 = load i64, ptr %slot33, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !4, !noalias !3
  store i64 %ld473, ptr %slot34, align 8
  %v474 = load i64, ptr %slot34, align 8
  %v475 = load i64, ptr %slot19, align 8
  %p476 = inttoptr i64 %v475 to ptr
  store i64 %v474, ptr %p476, align 8, !alias.scope !3, !noalias !4
  %v477 = load i64, ptr %slot19, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i64, ptr %p478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld479, ptr %slot35, align 8
  %v480 = load i64, ptr %slot35, align 8
  %v481 = load i64, ptr %slot10, align 8
  %p482 = inttoptr i64 %v481 to ptr
  store i64 %v480, ptr %p482, align 8, !alias.scope !3, !noalias !4
  %v483 = load i64, ptr %slot10, align 8
  store i64 %v483, ptr %slot36, align 8
  %v484 = load i64, ptr %slot11, align 8
  store i64 %v484, ptr %slot37, align 8
  %v485 = load i64, ptr %slot36, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i64, ptr %p486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld487, ptr %slot38, align 8
  %v488 = load i64, ptr %slot38, align 8
  %cmp489 = icmp ne i64 %v488, 0
  %cv490 = zext i1 %cmp489 to i32
  store i32 %cv490, ptr %slot39, align 8
  %v491 = load i32, ptr %slot39, align 8
  %cv492 = zext i32 %v491 to i64
  %cond493 = icmp ne i64 %cv492, 0
  br i1 %cond493, label %bb_rcgnn24, label %bb_rcgstore24
bb_rcgnn24:
  %v494 = load i64, ptr %slot38, align 8
  %op495 = sub i64 %v494, 16
  store i64 %op495, ptr %slot40, align 8
  %v496 = load i64, ptr %slot38, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %rgep498 = getelementptr i8, ptr %p497, i64 -16
  %ld499 = load i64, ptr %rgep498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld499, ptr %slot41, align 8
  %v500 = load i64, ptr %slot41, align 8
  %op501 = and i64 %v500, 4611686018427387906
  store i64 %op501, ptr %slot42, align 8
  %v502 = load i64, ptr %slot42, align 8
  %cmp503 = icmp ne i64 %v502, 0
  %cv504 = zext i1 %cmp503 to i32
  store i32 %cv504, ptr %slot43, align 8
  %v505 = load i32, ptr %slot43, align 8
  %cv506 = zext i32 %v505 to i64
  %cond507 = icmp ne i64 %cv506, 0
  br i1 %cond507, label %bb_rcgstore24, label %bb_rcginc24
bb_rcginc24:
  %v508 = load i64, ptr %slot38, align 8
  %op509 = sub i64 %v508, 24
  store i64 %op509, ptr %slot44, align 8
  %v510 = load i64, ptr %slot38, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %rgep512 = getelementptr i8, ptr %p511, i64 -24
  %ld513 = load i64, ptr %rgep512, align 8, !alias.scope !9, !noalias !10
  store i64 %ld513, ptr %slot45, align 8
  %v514 = load i64, ptr %slot45, align 8
  %op515 = add i64 %v514, 1
  store i64 %op515, ptr %slot46, align 8
  %v516 = load i64, ptr %slot46, align 8
  %cmp517 = icmp eq i64 %v516, 0
  %cv518 = zext i1 %cmp517 to i32
  store i32 %cv518, ptr %slot47, align 8
  %v519 = load i32, ptr %slot47, align 8
  %cv520 = zext i32 %v519 to i64
  %cond521 = icmp ne i64 %cv520, 0
  br i1 %cond521, label %bb_rcglimit24, label %bb_rcgcapacity24
bb_rcglimit24:
  %v522 = load i64, ptr %slot1, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %call524 = call i32 @myl_qbe_rc_status(ptr %p523, i32 2) nomerge, !dbg !114
  store i32 %call524, ptr %slot48, align 8
  br label %bb_failure
bb_rcgcapacity24:
  %v525 = load i64, ptr %slot46, align 8
  %v526 = load i64, ptr %slot38, align 8
  %p527 = inttoptr i64 %v526 to ptr
  %rgep528 = getelementptr i8, ptr %p527, i64 -24
  store i64 %v525, ptr %rgep528, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore24
bb_rcgstore24:
  %v529 = load i64, ptr %slot38, align 8
  %v530 = load i64, ptr %slot37, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot8, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i32 2, ptr %p533, align 4, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot8, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 16, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot7, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i32 1, ptr %p537, align 4, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot5, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i32, ptr %p539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld540, ptr %slot49, align 8
  %v541 = load i32, ptr %slot49, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v544 = load i64, ptr %slot5, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i32 0, ptr %p545, align 4, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot9, align 8
  store i64 %v546, ptr %slot50, align 8
  %v547 = load i64, ptr %slot6, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i32, ptr %p548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld549, ptr %slot51, align 8
  %v550 = load i32, ptr %slot51, align 8
  %op551 = and i32 %v550, 28
  store i32 %op551, ptr %slot52, align 8
  %v552 = load i32, ptr %slot52, align 8
  %cv553 = zext i32 %v552 to i64
  %cond554 = icmp ne i64 %cv553, 0
  br i1 %cond554, label %bb_rcslotrole40, label %bb_rcslotowner40
bb_rcslotrole40:
  %v555 = load i64, ptr %slot21, align 8
  store i64 %v555, ptr %slot53, align 8
  %v556 = load i64, ptr %slot53, align 8
  %v557 = load i64, ptr %slot50, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v556, i64 %v557) nomerge, !dbg !114
  br label %bb_rcslotdone40
bb_rcslotowner40:
  %v558 = load i64, ptr %slot21, align 8
  store i64 %v558, ptr %slot54, align 8
  %v559 = load i64, ptr %slot54, align 8
  %v560 = load i64, ptr %slot50, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v559, i64 %v560) nomerge, !dbg !114
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v561 = load i64, ptr %slot9, align 8
  store i64 %v561, ptr %slot55, align 8
  %v562 = load i64, ptr %slot11, align 8
  store i64 %v562, ptr %slot56, align 8
  %v563 = load i64, ptr %slot56, align 8
  %v564 = load i64, ptr %slot55, align 8
  %p565 = inttoptr i64 %v563 to ptr
  %p566 = inttoptr i64 %v564 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p566, ptr %p565, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v567 = load i64, ptr %slot6, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 2, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot8, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i32, ptr %p570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld571, ptr %slot57, align 8
  %v572 = load i32, ptr %slot57, align 8
  %v573 = load i64, ptr %slot6, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 %v572, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot7, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 0, ptr %p576, align 4, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot5, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i32 1, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot55, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i64, ptr %p580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld581, ptr %slot58, align 8
  %v582 = load i64, ptr %slot58, align 8
  %v583 = load i64, ptr %slot19, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot19, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot59, align 8
  %v588 = load i64, ptr %slot15, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %ld590 = load i64, ptr %p589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld590, ptr %slot60, align 8
  %v591 = load i64, ptr %slot5, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i32, ptr %p592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld593, ptr %slot61, align 8
  %v594 = load i32, ptr %slot61, align 8
  %cv595 = zext i32 %v594 to i64
  %cond596 = icmp ne i64 %cv595, 0
  br i1 %cond596, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v597 = load i64, ptr %slot5, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 0, ptr %p598, align 4, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot9, align 8
  store i64 %v599, ptr %slot62, align 8
  %v600 = load i64, ptr %slot6, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %ld602 = load i32, ptr %p601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld602, ptr %slot63, align 8
  %v603 = load i32, ptr %slot63, align 8
  %op604 = and i32 %v603, 28
  store i32 %op604, ptr %slot64, align 8
  %v605 = load i32, ptr %slot64, align 8
  %cv606 = zext i32 %v605 to i64
  %cond607 = icmp ne i64 %cv606, 0
  br i1 %cond607, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v608 = load i64, ptr %slot21, align 8
  store i64 %v608, ptr %slot65, align 8
  %v609 = load i64, ptr %slot62, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %ld611 = load i64, ptr %p610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld611, ptr %slot66, align 8
  %v612 = load i64, ptr %slot66, align 8
  %cmp613 = icmp ne i64 %v612, 0
  %cv614 = zext i1 %cmp613 to i32
  store i32 %cv614, ptr %slot67, align 8
  %v615 = load i32, ptr %slot67, align 8
  %cv616 = zext i32 %v615 to i64
  %cond617 = icmp ne i64 %cv616, 0
  br i1 %cond617, label %bb_rcgnn77, label %bb_rcgdone77
bb_rcgnn77:
  %v618 = load i64, ptr %slot66, align 8
  %op619 = sub i64 %v618, 16
  store i64 %op619, ptr %slot68, align 8
  %v620 = load i64, ptr %slot66, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %rgep622 = getelementptr i8, ptr %p621, i64 -16
  %ld623 = load i64, ptr %rgep622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld623, ptr %slot69, align 8
  %v624 = load i64, ptr %slot69, align 8
  %op625 = and i64 %v624, 4611686018427387906
  store i64 %op625, ptr %slot70, align 8
  %v626 = load i64, ptr %slot70, align 8
  %cmp627 = icmp ne i64 %v626, 0
  %cv628 = zext i1 %cmp627 to i32
  store i32 %cv628, ptr %slot71, align 8
  %v629 = load i32, ptr %slot71, align 8
  %cv630 = zext i32 %v629 to i64
  %cond631 = icmp ne i64 %cv630, 0
  br i1 %cond631, label %bb_rcgclear77, label %bb_rcgcounted77
bb_rcgcounted77:
  %v632 = load i64, ptr %slot66, align 8
  %op633 = sub i64 %v632, 24
  store i64 %op633, ptr %slot72, align 8
  %v634 = load i64, ptr %slot66, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %rgep636 = getelementptr i8, ptr %p635, i64 -24
  %ld637 = load i64, ptr %rgep636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld637, ptr %slot73, align 8
  %v638 = load i64, ptr %slot73, align 8
  %op639 = sub i64 %v638, 1
  store i64 %op639, ptr %slot74, align 8
  %v640 = load i64, ptr %slot74, align 8
  %cmp641 = icmp eq i64 %v640, 0
  %cv642 = zext i1 %cmp641 to i32
  store i32 %cv642, ptr %slot75, align 8
  %v643 = load i32, ptr %slot75, align 8
  %cv644 = zext i32 %v643 to i64
  %cond645 = icmp ne i64 %cv644, 0
  br i1 %cond645, label %bb_rcglast77, label %bb_rcgdec77
bb_rcglast77:
  %v646 = load i64, ptr %slot66, align 8
  %op647 = sub i64 %v646, 32
  store i64 %op647, ptr %slot76, align 8
  %v648 = load i64, ptr %slot66, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %rgep650 = getelementptr i8, ptr %p649, i64 -32
  %ld651 = load i64, ptr %rgep650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld651, ptr %slot77, align 8
  %v652 = load i64, ptr %slot77, align 8
  %cmp653 = icmp ne i64 %v652, 0
  %cv654 = zext i1 %cmp653 to i32
  store i32 %cv654, ptr %slot78, align 8
  %v655 = load i32, ptr %slot78, align 8
  %cv656 = zext i32 %v655 to i64
  %cond657 = icmp ne i64 %cv656, 0
  br i1 %cond657, label %bb_rcgdec77, label %bb_rcgslow77
bb_rcgslow77:
  %v658 = load i64, ptr %slot65, align 8
  %v659 = load i64, ptr %slot62, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v658, i64 %v659) nomerge, !dbg !116
  br label %bb_rcgdone77
bb_rcgdec77:
  %v660 = load i64, ptr %slot74, align 8
  %v661 = load i64, ptr %slot66, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %rgep663 = getelementptr i8, ptr %p662, i64 -24
  store i64 %v660, ptr %rgep663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear77
bb_rcgclear77:
  %v664 = load i64, ptr %slot62, align 8
  %p665 = inttoptr i64 %v664 to ptr
  store i64 0, ptr %p665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone77
bb_rcgdone77:
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v666 = load i64, ptr %slot21, align 8
  store i64 %v666, ptr %slot79, align 8
  %v667 = load i64, ptr %slot62, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %ld669 = load i64, ptr %p668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld669, ptr %slot80, align 8
  %v670 = load i64, ptr %slot80, align 8
  %cmp671 = icmp ne i64 %v670, 0
  %cv672 = zext i1 %cmp671 to i32
  store i32 %cv672, ptr %slot81, align 8
  %v673 = load i32, ptr %slot81, align 8
  %cv674 = zext i32 %v673 to i64
  %cond675 = icmp ne i64 %cv674, 0
  br i1 %cond675, label %bb_rcgnn92, label %bb_rcgdone92
bb_rcgnn92:
  %v676 = load i64, ptr %slot80, align 8
  %op677 = sub i64 %v676, 16
  store i64 %op677, ptr %slot82, align 8
  %v678 = load i64, ptr %slot80, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %rgep680 = getelementptr i8, ptr %p679, i64 -16
  %ld681 = load i64, ptr %rgep680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld681, ptr %slot83, align 8
  %v682 = load i64, ptr %slot83, align 8
  %op683 = and i64 %v682, 4611686018427387906
  store i64 %op683, ptr %slot84, align 8
  %v684 = load i64, ptr %slot84, align 8
  %cmp685 = icmp ne i64 %v684, 0
  %cv686 = zext i1 %cmp685 to i32
  store i32 %cv686, ptr %slot85, align 8
  %v687 = load i32, ptr %slot85, align 8
  %cv688 = zext i32 %v687 to i64
  %cond689 = icmp ne i64 %cv688, 0
  br i1 %cond689, label %bb_rcgclear92, label %bb_rcgcounted92
bb_rcgcounted92:
  %v690 = load i64, ptr %slot80, align 8
  %op691 = sub i64 %v690, 32
  store i64 %op691, ptr %slot86, align 8
  %v692 = load i64, ptr %slot80, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %rgep694 = getelementptr i8, ptr %p693, i64 -32
  %ld695 = load i64, ptr %rgep694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld695, ptr %slot87, align 8
  %v696 = load i64, ptr %slot87, align 8
  %op697 = sub i64 %v696, 1
  store i64 %op697, ptr %slot88, align 8
  %v698 = load i64, ptr %slot88, align 8
  %cmp699 = icmp eq i64 %v698, 0
  %cv700 = zext i1 %cmp699 to i32
  store i32 %cv700, ptr %slot89, align 8
  %v701 = load i32, ptr %slot89, align 8
  %cv702 = zext i32 %v701 to i64
  %cond703 = icmp ne i64 %cv702, 0
  br i1 %cond703, label %bb_rcglast92, label %bb_rcgdec92
bb_rcglast92:
  %v704 = load i64, ptr %slot80, align 8
  %op705 = sub i64 %v704, 24
  store i64 %op705, ptr %slot90, align 8
  %v706 = load i64, ptr %slot80, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %rgep708 = getelementptr i8, ptr %p707, i64 -24
  %ld709 = load i64, ptr %rgep708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld709, ptr %slot91, align 8
  %v710 = load i64, ptr %slot91, align 8
  %cmp711 = icmp ne i64 %v710, 0
  %cv712 = zext i1 %cmp711 to i32
  store i32 %cv712, ptr %slot92, align 8
  %v713 = load i32, ptr %slot92, align 8
  %cv714 = zext i32 %v713 to i64
  %cond715 = icmp ne i64 %cv714, 0
  br i1 %cond715, label %bb_rcgdec92, label %bb_rcgslow92
bb_rcgslow92:
  %v716 = load i64, ptr %slot79, align 8
  %v717 = load i64, ptr %slot62, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v716, i64 %v717) nomerge, !dbg !116
  br label %bb_rcgdone92
bb_rcgdec92:
  %v718 = load i64, ptr %slot88, align 8
  %v719 = load i64, ptr %slot80, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %rgep721 = getelementptr i8, ptr %p720, i64 -32
  store i64 %v718, ptr %rgep721, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear92
bb_rcgclear92:
  %v722 = load i64, ptr %slot62, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i64 0, ptr %p723, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone92
bb_rcgdone92:
  br label %bb_rcslotdone61
bb_rcslotdone61:
  %v724 = load i64, ptr %slot60, align 8
  %op725 = add i64 %v724, 280
  store i64 %op725, ptr %slot93, align 8
  %v726 = load i64, ptr %slot93, align 8
  %op727 = add i64 %v726, 0
  store i64 %op727, ptr %slot94, align 8
  store i64 0, ptr %slot95, align 8
  %v728 = load i64, ptr %slot94, align 8
  %p729 = inttoptr i64 %v728 to ptr
  %ld730 = load i64, ptr %p729, align 8, !alias.scope !4, !noalias !3
  store i64 %ld730, ptr %slot96, align 8
  %v731 = load i64, ptr %slot96, align 8
  %cmp732 = icmp ne i64 %v731, 0
  %cv733 = zext i1 %cmp732 to i32
  store i32 %cv733, ptr %slot97, align 8
  %v734 = load i32, ptr %slot97, align 8
  %cv735 = zext i32 %v734 to i64
  %cond736 = icmp ne i64 %cv735, 0
  br i1 %cond736, label %bb_rcguniquenn99, label %bb_rcgunique99
bb_rcguniquenn99:
  %v737 = load i64, ptr %slot96, align 8
  %op738 = sub i64 %v737, 16
  store i64 %op738, ptr %slot98, align 8
  %v739 = load i64, ptr %slot96, align 8
  %p740 = inttoptr i64 %v739 to ptr
  %rgep741 = getelementptr i8, ptr %p740, i64 -16
  %ld742 = load i64, ptr %rgep741, align 8, !alias.scope !9, !noalias !10
  store i64 %ld742, ptr %slot99, align 8
  %v743 = load i64, ptr %slot99, align 8
  %op744 = and i64 %v743, 6917529027641081858
  store i64 %op744, ptr %slot100, align 8
  %v745 = load i64, ptr %slot100, align 8
  %cmp746 = icmp ne i64 %v745, 0
  %cv747 = zext i1 %cmp746 to i32
  store i32 %cv747, ptr %slot101, align 8
  %v748 = load i32, ptr %slot101, align 8
  %cv749 = zext i32 %v748 to i64
  %cond750 = icmp ne i64 %cv749, 0
  br i1 %cond750, label %bb_rcguniqueslow99, label %bb_rcguniquecount99
bb_rcguniquecount99:
  %v751 = load i64, ptr %slot96, align 8
  %op752 = sub i64 %v751, 32
  store i64 %op752, ptr %slot102, align 8
  %v753 = load i64, ptr %slot96, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %rgep755 = getelementptr i8, ptr %p754, i64 -32
  %ld756 = load i64, ptr %rgep755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld756, ptr %slot103, align 8
  %v757 = load i64, ptr %slot103, align 8
  %cmp758 = icmp ult i64 %v757, 2
  %cv759 = zext i1 %cmp758 to i32
  store i32 %cv759, ptr %slot104, align 8
  %v760 = load i32, ptr %slot104, align 8
  %cv761 = zext i32 %v760 to i64
  %cond762 = icmp ne i64 %cv761, 0
  br i1 %cond762, label %bb_rcgunique99, label %bb_rcguniqueslow99
bb_rcguniqueslow99:
  %v763 = load i64, ptr %slot1, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %p765 = inttoptr i64 ptrtoint (ptr @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae to i64) to ptr
  %v766 = load i64, ptr %slot94, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %v768 = load i64, ptr %slot95, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %call770 = call i32 @myl_qbe_rc_unique_field(ptr %p764, ptr %p765, ptr %p767, ptr %p769) nomerge, !dbg !116
  store i32 %call770, ptr %slot105, align 8
  %v771 = load i32, ptr %slot105, align 8
  %cv772 = zext i32 %v771 to i64
  %cond773 = icmp ne i64 %cv772, 0
  br i1 %cond773, label %bb_rcunique109, label %bb_failure
bb_rcunique109:
  br label %bb_rcgunique99
bb_rcgunique99:
  %v774 = load i64, ptr %slot94, align 8
  %p775 = inttoptr i64 %v774 to ptr
  %ld776 = load i64, ptr %p775, align 8, !alias.scope !4, !noalias !3
  store i64 %ld776, ptr %slot106, align 8
  %v777 = load i64, ptr %slot106, align 8
  %v778 = load i64, ptr %slot19, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i64 %v777, ptr %p779, align 8, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot19, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %ld782 = load i64, ptr %p781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld782, ptr %slot107, align 8
  %v783 = load i64, ptr %slot5, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i32, ptr %p784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld785, ptr %slot108, align 8
  %v786 = load i32, ptr %slot108, align 8
  %cv787 = zext i32 %v786 to i64
  %cond788 = icmp ne i64 %cv787, 0
  br i1 %cond788, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v789 = load i64, ptr %slot5, align 8
  %p790 = inttoptr i64 %v789 to ptr
  store i32 0, ptr %p790, align 4, !alias.scope !3, !noalias !4
  %v791 = load i64, ptr %slot9, align 8
  store i64 %v791, ptr %slot109, align 8
  %v792 = load i64, ptr %slot6, align 8
  %p793 = inttoptr i64 %v792 to ptr
  %ld794 = load i32, ptr %p793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld794, ptr %slot110, align 8
  %v795 = load i32, ptr %slot110, align 8
  %op796 = and i32 %v795, 28
  store i32 %op796, ptr %slot111, align 8
  %v797 = load i32, ptr %slot111, align 8
  %cv798 = zext i32 %v797 to i64
  %cond799 = icmp ne i64 %cv798, 0
  br i1 %cond799, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v800 = load i64, ptr %slot21, align 8
  store i64 %v800, ptr %slot112, align 8
  %v801 = load i64, ptr %slot109, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %ld803 = load i64, ptr %p802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld803, ptr %slot113, align 8
  %v804 = load i64, ptr %slot113, align 8
  %cmp805 = icmp ne i64 %v804, 0
  %cv806 = zext i1 %cmp805 to i32
  store i32 %cv806, ptr %slot114, align 8
  %v807 = load i32, ptr %slot114, align 8
  %cv808 = zext i32 %v807 to i64
  %cond809 = icmp ne i64 %cv808, 0
  br i1 %cond809, label %bb_rcgnn130, label %bb_rcgdone130
bb_rcgnn130:
  %v810 = load i64, ptr %slot113, align 8
  %op811 = sub i64 %v810, 16
  store i64 %op811, ptr %slot115, align 8
  %v812 = load i64, ptr %slot113, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %rgep814 = getelementptr i8, ptr %p813, i64 -16
  %ld815 = load i64, ptr %rgep814, align 8, !alias.scope !9, !noalias !10
  store i64 %ld815, ptr %slot116, align 8
  %v816 = load i64, ptr %slot116, align 8
  %op817 = and i64 %v816, 4611686018427387906
  store i64 %op817, ptr %slot117, align 8
  %v818 = load i64, ptr %slot117, align 8
  %cmp819 = icmp ne i64 %v818, 0
  %cv820 = zext i1 %cmp819 to i32
  store i32 %cv820, ptr %slot118, align 8
  %v821 = load i32, ptr %slot118, align 8
  %cv822 = zext i32 %v821 to i64
  %cond823 = icmp ne i64 %cv822, 0
  br i1 %cond823, label %bb_rcgclear130, label %bb_rcgcounted130
bb_rcgcounted130:
  %v824 = load i64, ptr %slot113, align 8
  %op825 = sub i64 %v824, 24
  store i64 %op825, ptr %slot119, align 8
  %v826 = load i64, ptr %slot113, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %rgep828 = getelementptr i8, ptr %p827, i64 -24
  %ld829 = load i64, ptr %rgep828, align 8, !alias.scope !9, !noalias !10
  store i64 %ld829, ptr %slot120, align 8
  %v830 = load i64, ptr %slot120, align 8
  %op831 = sub i64 %v830, 1
  store i64 %op831, ptr %slot121, align 8
  %v832 = load i64, ptr %slot121, align 8
  %cmp833 = icmp eq i64 %v832, 0
  %cv834 = zext i1 %cmp833 to i32
  store i32 %cv834, ptr %slot122, align 8
  %v835 = load i32, ptr %slot122, align 8
  %cv836 = zext i32 %v835 to i64
  %cond837 = icmp ne i64 %cv836, 0
  br i1 %cond837, label %bb_rcglast130, label %bb_rcgdec130
bb_rcglast130:
  %v838 = load i64, ptr %slot113, align 8
  %op839 = sub i64 %v838, 32
  store i64 %op839, ptr %slot123, align 8
  %v840 = load i64, ptr %slot113, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %rgep842 = getelementptr i8, ptr %p841, i64 -32
  %ld843 = load i64, ptr %rgep842, align 8, !alias.scope !9, !noalias !10
  store i64 %ld843, ptr %slot124, align 8
  %v844 = load i64, ptr %slot124, align 8
  %cmp845 = icmp ne i64 %v844, 0
  %cv846 = zext i1 %cmp845 to i32
  store i32 %cv846, ptr %slot125, align 8
  %v847 = load i32, ptr %slot125, align 8
  %cv848 = zext i32 %v847 to i64
  %cond849 = icmp ne i64 %cv848, 0
  br i1 %cond849, label %bb_rcgdec130, label %bb_rcgslow130
bb_rcgslow130:
  %v850 = load i64, ptr %slot112, align 8
  %v851 = load i64, ptr %slot109, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v850, i64 %v851) nomerge, !dbg !116
  br label %bb_rcgdone130
bb_rcgdec130:
  %v852 = load i64, ptr %slot121, align 8
  %v853 = load i64, ptr %slot113, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %rgep855 = getelementptr i8, ptr %p854, i64 -24
  store i64 %v852, ptr %rgep855, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear130
bb_rcgclear130:
  %v856 = load i64, ptr %slot109, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i64 0, ptr %p857, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone130
bb_rcgdone130:
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v858 = load i64, ptr %slot21, align 8
  store i64 %v858, ptr %slot126, align 8
  %v859 = load i64, ptr %slot109, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i64, ptr %p860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld861, ptr %slot127, align 8
  %v862 = load i64, ptr %slot127, align 8
  %cmp863 = icmp ne i64 %v862, 0
  %cv864 = zext i1 %cmp863 to i32
  store i32 %cv864, ptr %slot128, align 8
  %v865 = load i32, ptr %slot128, align 8
  %cv866 = zext i32 %v865 to i64
  %cond867 = icmp ne i64 %cv866, 0
  br i1 %cond867, label %bb_rcgnn145, label %bb_rcgdone145
bb_rcgnn145:
  %v868 = load i64, ptr %slot127, align 8
  %op869 = sub i64 %v868, 16
  store i64 %op869, ptr %slot129, align 8
  %v870 = load i64, ptr %slot127, align 8
  %p871 = inttoptr i64 %v870 to ptr
  %rgep872 = getelementptr i8, ptr %p871, i64 -16
  %ld873 = load i64, ptr %rgep872, align 8, !alias.scope !9, !noalias !10
  store i64 %ld873, ptr %slot130, align 8
  %v874 = load i64, ptr %slot130, align 8
  %op875 = and i64 %v874, 4611686018427387906
  store i64 %op875, ptr %slot131, align 8
  %v876 = load i64, ptr %slot131, align 8
  %cmp877 = icmp ne i64 %v876, 0
  %cv878 = zext i1 %cmp877 to i32
  store i32 %cv878, ptr %slot132, align 8
  %v879 = load i32, ptr %slot132, align 8
  %cv880 = zext i32 %v879 to i64
  %cond881 = icmp ne i64 %cv880, 0
  br i1 %cond881, label %bb_rcgclear145, label %bb_rcgcounted145
bb_rcgcounted145:
  %v882 = load i64, ptr %slot127, align 8
  %op883 = sub i64 %v882, 32
  store i64 %op883, ptr %slot133, align 8
  %v884 = load i64, ptr %slot127, align 8
  %p885 = inttoptr i64 %v884 to ptr
  %rgep886 = getelementptr i8, ptr %p885, i64 -32
  %ld887 = load i64, ptr %rgep886, align 8, !alias.scope !9, !noalias !10
  store i64 %ld887, ptr %slot134, align 8
  %v888 = load i64, ptr %slot134, align 8
  %op889 = sub i64 %v888, 1
  store i64 %op889, ptr %slot135, align 8
  %v890 = load i64, ptr %slot135, align 8
  %cmp891 = icmp eq i64 %v890, 0
  %cv892 = zext i1 %cmp891 to i32
  store i32 %cv892, ptr %slot136, align 8
  %v893 = load i32, ptr %slot136, align 8
  %cv894 = zext i32 %v893 to i64
  %cond895 = icmp ne i64 %cv894, 0
  br i1 %cond895, label %bb_rcglast145, label %bb_rcgdec145
bb_rcglast145:
  %v896 = load i64, ptr %slot127, align 8
  %op897 = sub i64 %v896, 24
  store i64 %op897, ptr %slot137, align 8
  %v898 = load i64, ptr %slot127, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %rgep900 = getelementptr i8, ptr %p899, i64 -24
  %ld901 = load i64, ptr %rgep900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld901, ptr %slot138, align 8
  %v902 = load i64, ptr %slot138, align 8
  %cmp903 = icmp ne i64 %v902, 0
  %cv904 = zext i1 %cmp903 to i32
  store i32 %cv904, ptr %slot139, align 8
  %v905 = load i32, ptr %slot139, align 8
  %cv906 = zext i32 %v905 to i64
  %cond907 = icmp ne i64 %cv906, 0
  br i1 %cond907, label %bb_rcgdec145, label %bb_rcgslow145
bb_rcgslow145:
  %v908 = load i64, ptr %slot126, align 8
  %v909 = load i64, ptr %slot109, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v908, i64 %v909) nomerge, !dbg !116
  br label %bb_rcgdone145
bb_rcgdec145:
  %v910 = load i64, ptr %slot135, align 8
  %v911 = load i64, ptr %slot127, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %rgep913 = getelementptr i8, ptr %p912, i64 -32
  store i64 %v910, ptr %rgep913, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear145
bb_rcgclear145:
  %v914 = load i64, ptr %slot109, align 8
  %p915 = inttoptr i64 %v914 to ptr
  store i64 0, ptr %p915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone145
bb_rcgdone145:
  br label %bb_rcslotdone114
bb_rcslotdone114:
  %v916 = load i64, ptr %slot12, align 8
  store i64 %v916, ptr %slot140, align 8
  %v917 = load i64, ptr %slot21, align 8
  %v918 = load i64, ptr %slot140, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i64 %v917, ptr %p919, align 8, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot21, align 8
  %p922 = inttoptr i64 %v920 to ptr
  %gep923 = getelementptr i8, ptr %p922, i64 5640
  %op921 = ptrtoint ptr %gep923 to i64
  store i64 %op921, ptr %slot141, align 8
  %v924 = load i64, ptr %slot141, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i64, ptr %p925, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld926, ptr %slot142, align 8
  %v927 = load i64, ptr %slot142, align 8
  %op928 = add i64 %v927, 248
  store i64 %op928, ptr %slot143, align 8
  %v929 = load i64, ptr %slot143, align 8
  %p930 = inttoptr i64 %v929 to ptr
  %ld931 = load i64, ptr %p930, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld931, ptr %slot144, align 8
  %v932 = load i64, ptr %slot140, align 8
  %p934 = inttoptr i64 %v932 to ptr
  %gep935 = getelementptr i8, ptr %p934, i64 8
  %op933 = ptrtoint ptr %gep935 to i64
  store i64 %op933, ptr %slot145, align 8
  %v936 = load i64, ptr %slot144, align 8
  %v937 = load i64, ptr %slot145, align 8
  %p938 = inttoptr i64 %v937 to ptr
  store i64 %v936, ptr %p938, align 8, !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot140, align 8
  %p941 = inttoptr i64 %v939 to ptr
  %gep942 = getelementptr i8, ptr %p941, i64 16
  %op940 = ptrtoint ptr %gep942 to i64
  store i64 %op940, ptr %slot146, align 8
  %v943 = load i64, ptr %slot146, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i64 0, ptr %p944, align 8, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot21, align 8
  %p947 = inttoptr i64 %v945 to ptr
  %gep948 = getelementptr i8, ptr %p947, i64 112
  %op946 = ptrtoint ptr %gep948 to i64
  store i64 %op946, ptr %slot147, align 8
  %v949 = load i64, ptr %slot140, align 8
  %p951 = inttoptr i64 %v949 to ptr
  %gep952 = getelementptr i8, ptr %p951, i64 24
  %op950 = ptrtoint ptr %gep952 to i64
  store i64 %op950, ptr %slot148, align 8
  %v953 = load i64, ptr %slot140, align 8
  %p955 = inttoptr i64 %v953 to ptr
  %gep956 = getelementptr i8, ptr %p955, i64 28
  %op954 = ptrtoint ptr %gep956 to i64
  store i64 %op954, ptr %slot149, align 8
  %v957 = load i64, ptr %slot147, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ld959 = load i32, ptr %p958, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld959, ptr %slot150, align 8
  %v960 = load i64, ptr %slot148, align 8
  %p961 = inttoptr i64 %v960 to ptr
  store i32 1, ptr %p961, align 4, !alias.scope !3, !noalias !4
  %v962 = load i32, ptr %slot150, align 8
  %v963 = load i64, ptr %slot149, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i32 %v962, ptr %p964, align 4, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot140, align 8
  %v966 = load i64, ptr %slot143, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i64 %v965, ptr %p967, align 8, !alias.scope !9999998, !noalias !9999999
  %v968 = load i64, ptr %slot107, align 8
  %cmp969 = icmp ne i64 %v968, 0
  %cv970 = zext i1 %cmp969 to i32
  store i32 %cv970, ptr %slot151, align 8
  %v971 = load i32, ptr %slot151, align 8
  %cv972 = zext i32 %v971 to i64
  %cond973 = icmp ne i64 %cv972, 0
  br i1 %cond973, label %bb_rcspinmark197, label %bb_rcspindone197
bb_rcspinmark197:
  %v974 = load i64, ptr %slot107, align 8
  %op975 = sub i64 %v974, 16
  store i64 %op975, ptr %slot152, align 8
  %v976 = load i64, ptr %slot107, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %rgep978 = getelementptr i8, ptr %p977, i64 -16
  %ld979 = load i64, ptr %rgep978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld979, ptr %slot153, align 8
  %v980 = load i64, ptr %slot153, align 8
  %op981 = and i64 %v980, 2
  store i64 %op981, ptr %slot154, align 8
  %v982 = load i64, ptr %slot154, align 8
  %cmp983 = icmp ne i64 %v982, 0
  %cv984 = zext i1 %cmp983 to i32
  store i32 %cv984, ptr %slot155, align 8
  %v985 = load i32, ptr %slot155, align 8
  %cv986 = zext i32 %v985 to i64
  %cond987 = icmp ne i64 %cv986, 0
  br i1 %cond987, label %bb_rcspindone197, label %bb_rcspintype197
bb_rcspintype197:
  %v988 = load i64, ptr %slot153, align 8
  %op989 = and i64 %v988, 4611686018427387907
  store i64 %op989, ptr %slot156, align 8
  %v990 = load i64, ptr %slot156, align 8
  %cmp991 = icmp eq i64 %v990, 0
  %cv992 = zext i1 %cmp991 to i32
  store i32 %cv992, ptr %slot157, align 8
  %v993 = load i32, ptr %slot157, align 8
  %cv994 = zext i32 %v993 to i64
  %cond995 = icmp ne i64 %cv994, 0
  br i1 %cond995, label %bb_rcs205, label %bb_rcspinslow197
bb_rcs205:
  %v996 = load i64, ptr %slot107, align 8
  %op997 = sub i64 %v996, 8
  store i64 %op997, ptr %slot158, align 8
  %v998 = load i64, ptr %slot107, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %rgep1000 = getelementptr i8, ptr %p999, i64 -8
  %ld1001 = load i64, ptr %rgep1000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1001, ptr %slot159, align 8
  %p1002 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld1003 = load i64, ptr %p1002, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1003, ptr %slot160, align 8
  %v1004 = load i64, ptr %slot159, align 8
  %v1005 = load i64, ptr %slot160, align 8
  %cmp1006 = icmp eq i64 %v1004, %v1005
  %cv1007 = zext i1 %cmp1006 to i32
  store i32 %cv1007, ptr %slot161, align 8
  %v1008 = load i32, ptr %slot161, align 8
  %cv1009 = zext i32 %v1008 to i64
  %cond1010 = icmp ne i64 %cv1009, 0
  br i1 %cond1010, label %bb_rcs210, label %bb_rcspinslow197
bb_rcs210:
  %v1011 = load i64, ptr %slot21, align 8
  %p1013 = inttoptr i64 %v1011 to ptr
  %gep1014 = getelementptr i8, ptr %p1013, i64 5640
  %op1012 = ptrtoint ptr %gep1014 to i64
  store i64 %op1012, ptr %slot162, align 8
  %v1015 = load i64, ptr %slot162, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ld1017 = load i64, ptr %p1016, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1017, ptr %slot163, align 8
  %v1018 = load i64, ptr %slot163, align 8
  %op1019 = add i64 %v1018, 256
  store i64 %op1019, ptr %slot164, align 8
  %v1020 = load i64, ptr %slot164, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %ld1022 = load i64, ptr %p1021, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1022, ptr %slot165, align 8
  %v1023 = load i64, ptr %slot165, align 8
  %cmp1024 = icmp ne i64 %v1023, 0
  %cv1025 = zext i1 %cmp1024 to i32
  store i32 %cv1025, ptr %slot166, align 8
  %v1026 = load i32, ptr %slot166, align 8
  %cv1027 = zext i32 %v1026 to i64
  %cond1028 = icmp ne i64 %cv1027, 0
  br i1 %cond1028, label %bb_rcs216, label %bb_rcspinslow197
bb_rcs216:
  %v1029 = load i64, ptr %slot21, align 8
  %p1031 = inttoptr i64 %v1029 to ptr
  %gep1032 = getelementptr i8, ptr %p1031, i64 24
  %op1030 = ptrtoint ptr %gep1032 to i64
  store i64 %op1030, ptr %slot167, align 8
  %v1033 = load i64, ptr %slot167, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  %ld1035 = load i64, ptr %p1034, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1035, ptr %slot168, align 8
  %v1036 = load i64, ptr %slot168, align 8
  %op1037 = add i64 %v1036, 40
  store i64 %op1037, ptr %slot169, align 8
  %v1038 = load i64, ptr %slot169, align 8
  %v1039 = load i64, ptr %slot168, align 8
  %cmp1040 = icmp uge i64 %v1038, %v1039
  %cv1041 = zext i1 %cmp1040 to i32
  store i32 %cv1041, ptr %slot170, align 8
  %v1042 = load i32, ptr %slot170, align 8
  %cv1043 = zext i32 %v1042 to i64
  %cond1044 = icmp ne i64 %cv1043, 0
  br i1 %cond1044, label %bb_rcs221, label %bb_rcspinslow197
bb_rcs221:
  %v1045 = load i64, ptr %slot21, align 8
  %p1047 = inttoptr i64 %v1045 to ptr
  %gep1048 = getelementptr i8, ptr %p1047, i64 88
  %op1046 = ptrtoint ptr %gep1048 to i64
  store i64 %op1046, ptr %slot171, align 8
  %v1049 = load i64, ptr %slot171, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %ld1051 = load i64, ptr %p1050, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1051, ptr %slot172, align 8
  %v1052 = load i64, ptr %slot172, align 8
  %cmp1053 = icmp eq i64 %v1052, 0
  %cv1054 = zext i1 %cmp1053 to i32
  store i32 %cv1054, ptr %slot173, align 8
  %v1055 = load i64, ptr %slot169, align 8
  %v1056 = load i64, ptr %slot172, align 8
  %cmp1057 = icmp ule i64 %v1055, %v1056
  %cv1058 = zext i1 %cmp1057 to i32
  store i32 %cv1058, ptr %slot174, align 8
  %v1059 = load i32, ptr %slot173, align 8
  %v1060 = load i32, ptr %slot174, align 8
  %op1061 = or i32 %v1059, %v1060
  store i32 %op1061, ptr %slot175, align 8
  %v1062 = load i32, ptr %slot175, align 8
  %cv1063 = zext i32 %v1062 to i64
  %cond1064 = icmp ne i64 %cv1063, 0
  br i1 %cond1064, label %bb_rcs227, label %bb_rcspinslow197
bb_rcs227:
  %v1065 = load i64, ptr %slot107, align 8
  %op1066 = sub i64 %v1065, 24
  store i64 %op1066, ptr %slot176, align 8
  %v1067 = load i64, ptr %slot107, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %rgep1069 = getelementptr i8, ptr %p1068, i64 -24
  %ld1070 = load i64, ptr %rgep1069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1070, ptr %slot177, align 8
  %v1071 = load i64, ptr %slot177, align 8
  %cmp1072 = icmp ne i64 %v1071, 18446744073709551615
  %cv1073 = zext i1 %cmp1072 to i32
  store i32 %cv1073, ptr %slot178, align 8
  %v1074 = load i32, ptr %slot178, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcs231, label %bb_rcspinslow197
bb_rcs231:
  %v1077 = load i64, ptr %slot107, align 8
  %op1078 = add i64 %v1077, 32
  store i64 %op1078, ptr %slot179, align 8
  %v1079 = load i64, ptr %slot179, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %ld1081 = load i64, ptr %p1080, align 8
  store i64 %ld1081, ptr %slot180, align 8
  %v1082 = load i64, ptr %slot180, align 8
  %cmp1083 = icmp ne i64 %v1082, 0
  %cv1084 = zext i1 %cmp1083 to i32
  store i32 %cv1084, ptr %slot181, align 8
  %v1085 = load i32, ptr %slot181, align 8
  %cv1086 = zext i32 %v1085 to i64
  %cond1087 = icmp ne i64 %cv1086, 0
  br i1 %cond1087, label %bb_rcspinbacking197, label %bb_rcspincommit197
bb_rcspinbacking197:
  %v1088 = load i64, ptr %slot180, align 8
  %op1089 = sub i64 %v1088, 16
  store i64 %op1089, ptr %slot182, align 8
  %v1090 = load i64, ptr %slot180, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %rgep1092 = getelementptr i8, ptr %p1091, i64 -16
  %ld1093 = load i64, ptr %rgep1092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1093, ptr %slot183, align 8
  %v1094 = load i64, ptr %slot183, align 8
  %op1095 = and i64 %v1094, 4611686018427387907
  store i64 %op1095, ptr %slot184, align 8
  %v1096 = load i64, ptr %slot184, align 8
  %cmp1097 = icmp eq i64 %v1096, 0
  %cv1098 = zext i1 %cmp1097 to i32
  store i32 %cv1098, ptr %slot185, align 8
  %v1099 = load i32, ptr %slot185, align 8
  %cv1100 = zext i32 %v1099 to i64
  %cond1101 = icmp ne i64 %cv1100, 0
  br i1 %cond1101, label %bb_rcs239, label %bb_rcspinslow197
bb_rcs239:
  %v1102 = load i64, ptr %slot180, align 8
  %op1103 = sub i64 %v1102, 24
  store i64 %op1103, ptr %slot186, align 8
  %v1104 = load i64, ptr %slot180, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  %rgep1106 = getelementptr i8, ptr %p1105, i64 -24
  %ld1107 = load i64, ptr %rgep1106, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1107, ptr %slot187, align 8
  %v1108 = load i64, ptr %slot187, align 8
  %cmp1109 = icmp ne i64 %v1108, 18446744073709551615
  %cv1110 = zext i1 %cmp1109 to i32
  store i32 %cv1110, ptr %slot188, align 8
  %v1111 = load i32, ptr %slot188, align 8
  %cv1112 = zext i32 %v1111 to i64
  %cond1113 = icmp ne i64 %cv1112, 0
  br i1 %cond1113, label %bb_rcs243, label %bb_rcspinslow197
bb_rcs243:
  br label %bb_rcspincommit197
bb_rcspincommit197:
  %v1114 = load i64, ptr %slot165, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  %ld1116 = load i64, ptr %p1115, align 8
  store i64 %ld1116, ptr %slot189, align 8
  %v1117 = load i64, ptr %slot163, align 8
  %op1118 = add i64 %v1117, 256
  store i64 %op1118, ptr %slot190, align 8
  %v1119 = load i64, ptr %slot189, align 8
  %v1120 = load i64, ptr %slot190, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i64 %v1119, ptr %p1121, align 8, !alias.scope !9999998, !noalias !9999999
  %v1122 = load i64, ptr %slot163, align 8
  %op1123 = add i64 %v1122, 264
  store i64 %op1123, ptr %slot191, align 8
  %v1124 = load i64, ptr %slot191, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  %ld1126 = load i64, ptr %p1125, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1126, ptr %slot192, align 8
  %v1127 = load i64, ptr %slot192, align 8
  %op1128 = add i64 %v1127, 18446744073709551615
  store i64 %op1128, ptr %slot193, align 8
  %v1129 = load i64, ptr %slot193, align 8
  %v1130 = load i64, ptr %slot191, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i64 %v1129, ptr %p1131, align 8, !alias.scope !9999998, !noalias !9999999
  %v1132 = load i64, ptr %slot21, align 8
  %p1134 = inttoptr i64 %v1132 to ptr
  %gep1135 = getelementptr i8, ptr %p1134, i64 24
  %op1133 = ptrtoint ptr %gep1135 to i64
  store i64 %op1133, ptr %slot194, align 8
  %v1136 = load i64, ptr %slot194, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  %ld1138 = load i64, ptr %p1137, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1138, ptr %slot195, align 8
  %v1139 = load i64, ptr %slot195, align 8
  %op1140 = add i64 %v1139, 40
  store i64 %op1140, ptr %slot196, align 8
  %v1141 = load i64, ptr %slot196, align 8
  %v1142 = load i64, ptr %slot194, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i64 %v1141, ptr %p1143, align 8, !alias.scope !9999998, !noalias !9999999
  %v1144 = load i64, ptr %slot163, align 8
  %op1145 = add i64 %v1144, 48
  store i64 %op1145, ptr %slot197, align 8
  %v1146 = load i64, ptr %slot197, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1148, ptr %slot198, align 8
  %v1149 = load i64, ptr %slot198, align 8
  %op1150 = add i64 %v1149, 40
  store i64 %op1150, ptr %slot199, align 8
  %v1151 = load i64, ptr %slot199, align 8
  %v1152 = load i64, ptr %slot197, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  store i64 %v1151, ptr %p1153, align 8, !alias.scope !9999998, !noalias !9999999
  %v1154 = load i64, ptr %slot107, align 8
  %op1155 = sub i64 %v1154, 24
  store i64 %op1155, ptr %slot200, align 8
  %v1156 = load i64, ptr %slot107, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %rgep1158 = getelementptr i8, ptr %p1157, i64 -24
  %ld1159 = load i64, ptr %rgep1158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1159, ptr %slot201, align 8
  %v1160 = load i64, ptr %slot201, align 8
  %op1161 = add i64 %v1160, 1
  store i64 %op1161, ptr %slot202, align 8
  %v1162 = load i64, ptr %slot202, align 8
  %v1163 = load i64, ptr %slot107, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %rgep1165 = getelementptr i8, ptr %p1164, i64 -24
  store i64 %v1162, ptr %rgep1165, align 8, !alias.scope !9, !noalias !10
  %v1166 = load i64, ptr %slot180, align 8
  %cmp1167 = icmp ne i64 %v1166, 0
  %cv1168 = zext i1 %cmp1167 to i32
  store i32 %cv1168, ptr %slot203, align 8
  %v1169 = load i32, ptr %slot203, align 8
  %cv1170 = zext i32 %v1169 to i64
  %cond1171 = icmp ne i64 %cv1170, 0
  br i1 %cond1171, label %bb_rcspinhold197, label %bb_rcspinjournal197
bb_rcspinhold197:
  %v1172 = load i64, ptr %slot180, align 8
  %op1173 = sub i64 %v1172, 24
  store i64 %op1173, ptr %slot204, align 8
  %v1174 = load i64, ptr %slot180, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %rgep1176 = getelementptr i8, ptr %p1175, i64 -24
  %ld1177 = load i64, ptr %rgep1176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1177, ptr %slot205, align 8
  %v1178 = load i64, ptr %slot205, align 8
  %op1179 = add i64 %v1178, 1
  store i64 %op1179, ptr %slot206, align 8
  %v1180 = load i64, ptr %slot206, align 8
  %v1181 = load i64, ptr %slot180, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %rgep1183 = getelementptr i8, ptr %p1182, i64 -24
  store i64 %v1180, ptr %rgep1183, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal197
bb_rcspinjournal197:
  %v1184 = load i64, ptr %slot153, align 8
  %op1185 = and i64 %v1184, 1152921504606846976
  store i64 %op1185, ptr %slot207, align 8
  %v1186 = load i64, ptr %slot153, align 8
  %op1187 = or i64 %v1186, 1152921504606846976
  store i64 %op1187, ptr %slot208, align 8
  %v1188 = load i64, ptr %slot107, align 8
  %op1189 = sub i64 %v1188, 16
  store i64 %op1189, ptr %slot209, align 8
  %v1190 = load i64, ptr %slot208, align 8
  %v1191 = load i64, ptr %slot107, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %rgep1193 = getelementptr i8, ptr %p1192, i64 -16
  store i64 %v1190, ptr %rgep1193, align 8, !alias.scope !9, !noalias !10
  %v1194 = load i64, ptr %slot140, align 8
  %p1196 = inttoptr i64 %v1194 to ptr
  %gep1197 = getelementptr i8, ptr %p1196, i64 16
  %op1195 = ptrtoint ptr %gep1197 to i64
  store i64 %op1195, ptr %slot210, align 8
  %v1198 = load i64, ptr %slot210, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %ld1200 = load i64, ptr %p1199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1200, ptr %slot211, align 8
  %v1201 = load i64, ptr %slot165, align 8
  %op1202 = add i64 %v1201, 0
  store i64 %op1202, ptr %slot212, align 8
  %v1203 = load i64, ptr %slot211, align 8
  %v1204 = load i64, ptr %slot212, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i64 %v1203, ptr %p1205, align 8, !alias.scope !9999998, !noalias !9999999
  %v1206 = load i64, ptr %slot165, align 8
  %op1207 = add i64 %v1206, 8
  store i64 %op1207, ptr %slot213, align 8
  %v1208 = load i64, ptr %slot107, align 8
  %v1209 = load i64, ptr %slot213, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i64 %v1208, ptr %p1210, align 8, !alias.scope !9999998, !noalias !9999999
  %v1211 = load i64, ptr %slot165, align 8
  %op1212 = add i64 %v1211, 16
  store i64 %op1212, ptr %slot214, align 8
  %v1213 = load i64, ptr %slot207, align 8
  %v1214 = load i64, ptr %slot214, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  store i64 %v1213, ptr %p1215, align 8, !alias.scope !9999998, !noalias !9999999
  %v1216 = load i64, ptr %slot165, align 8
  %op1217 = add i64 %v1216, 24
  store i64 %op1217, ptr %slot215, align 8
  %v1218 = load i64, ptr %slot215, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i32 1, ptr %p1219, align 4, !alias.scope !9999998, !noalias !9999999
  %v1220 = load i64, ptr %slot165, align 8
  %op1221 = add i64 %v1220, 32
  store i64 %op1221, ptr %slot216, align 8
  %v1222 = load i64, ptr %slot180, align 8
  %v1223 = load i64, ptr %slot216, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i64 %v1222, ptr %p1224, align 8, !alias.scope !9999998, !noalias !9999999
  %v1225 = load i64, ptr %slot140, align 8
  %p1227 = inttoptr i64 %v1225 to ptr
  %gep1228 = getelementptr i8, ptr %p1227, i64 16
  %op1226 = ptrtoint ptr %gep1228 to i64
  store i64 %op1226, ptr %slot217, align 8
  %v1229 = load i64, ptr %slot165, align 8
  %v1230 = load i64, ptr %slot217, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i64 %v1229, ptr %p1231, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone197
bb_rcspinslow197:
  %v1232 = load i64, ptr %slot1, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  %v1234 = load i64, ptr %slot140, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  %v1236 = load i64, ptr %slot107, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  %call1238 = call i32 @myl_qbe_rc_scope_pin(ptr %p1233, ptr %p1235, ptr %p1237) nomerge, !dbg !116
  store i32 %call1238, ptr %slot218, align 8
  %v1239 = load i32, ptr %slot218, align 8
  %cv1240 = zext i32 %v1239 to i64
  %cond1241 = icmp ne i64 %cv1240, 0
  br i1 %cond1241, label %bb_rcunique274, label %bb_failure
bb_rcunique274:
  br label %bb_rcspindone197
bb_rcspindone197:
  %v1242 = load i64, ptr %slot107, align 8
  %v1243 = load i64, ptr %slot17, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  store i64 %v1242, ptr %p1244, align 8, !alias.scope !3, !noalias !4
  %v1245 = load i64, ptr %slot16, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  %ld1247 = load i64, ptr %p1246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1247, ptr %slot219, align 8
  %v1248 = load i64, ptr %slot219, align 8
  %v1249 = load i64, ptr %slot19, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  store i64 %v1248, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  %v1251 = load i64, ptr %slot19, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  %ld1253 = load i64, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1253, ptr %slot220, align 8
  %v1254 = load i64, ptr %slot5, align 8
  %p1255 = inttoptr i64 %v1254 to ptr
  %ld1256 = load i32, ptr %p1255, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1256, ptr %slot221, align 8
  %v1257 = load i64, ptr %slot6, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i32, ptr %p1258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1259, ptr %slot222, align 8
  %v1260 = load i32, ptr %slot222, align 8
  %op1261 = and i32 %v1260, 24
  store i32 %op1261, ptr %slot222, align 8
  %v1262 = load i32, ptr %slot222, align 8
  %cmp1263 = icmp eq i32 %v1262, 0
  %cv1264 = zext i1 %cmp1263 to i32
  store i32 %cv1264, ptr %slot223, align 8
  %v1265 = load i32, ptr %slot221, align 8
  %v1266 = load i32, ptr %slot223, align 8
  %op1267 = and i32 %v1265, %v1266
  store i32 %op1267, ptr %slot224, align 8
  %v1268 = load i64, ptr %slot22, align 8
  store i64 %v1268, ptr %slot225, align 8
  %v1269 = load i32, ptr %slot224, align 8
  %op1270 = mul i32 %v1269, 4
  store i32 %op1270, ptr %slot226, align 8
  %v1271 = load i32, ptr %slot226, align 8
  %op1272 = or i32 %v1271, 0
  store i32 %op1272, ptr %slot227, align 8
  %v1273 = load i64, ptr %slot11, align 8
  store i64 %v1273, ptr %slot228, align 8
  %v1274 = load i64, ptr %slot21, align 8
  %v1275 = load i64, ptr %slot228, align 8
  %v1276 = load i64, ptr %slot220, align 8
  %v1277 = load i64, ptr %slot225, align 8
  %cv1278 = trunc i64 %v1277 to i32
  %v1279 = load i32, ptr %slot227, align 8
  %call1280 = call i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_publish(i64 %v1274, i64 %v1275, i64 %v1276, i32 %cv1278, i32 %v1279) nomerge, !dbg !118
  store i32 %call1280, ptr %slot229, align 8
  %v1281 = load i32, ptr %slot229, align 8
  %cv1282 = zext i32 %v1281 to i64
  %cond1283 = icmp ne i64 %cv1282, 0
  br i1 %cond1283, label %bb_rcsuccess290, label %bb_rcfailure290
bb_rcfailure290:
  %v1284 = load i64, ptr %slot21, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %call1286 = call i32 @myl_rc_take_failure(ptr %p1285) nomerge, !dbg !118
  store i32 %call1286, ptr %slot230, align 8
  %v1287 = load i64, ptr %slot1, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %v1289 = load i32, ptr %slot230, align 8
  %call1290 = call i32 @myl_qbe_rc_status(ptr %p1288, i32 %v1289) nomerge, !dbg !118
  store i32 %call1290, ptr %slot231, align 8
  br label %bb_failure
bb_rcsuccess290:
  %v1291 = load i32, ptr %slot224, align 8
  %cv1292 = zext i32 %v1291 to i64
  %cond1293 = icmp ne i64 %cv1292, 0
  br i1 %cond1293, label %bb_rchtaken293, label %bb_rchcopied293
bb_rchcopied293:
  %v1294 = load i64, ptr %slot5, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i32, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1296, ptr %slot232, align 8
  %v1297 = load i32, ptr %slot232, align 8
  %cv1298 = zext i32 %v1297 to i64
  %cond1299 = icmp ne i64 %cv1298, 0
  br i1 %cond1299, label %bb_rcslotdrop296, label %bb_rcslotdone296
bb_rcslotdrop296:
  %v1300 = load i64, ptr %slot5, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i32 0, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot9, align 8
  store i64 %v1302, ptr %slot233, align 8
  %v1303 = load i64, ptr %slot6, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i32, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1305, ptr %slot234, align 8
  %v1306 = load i32, ptr %slot234, align 8
  %op1307 = and i32 %v1306, 28
  store i32 %op1307, ptr %slot235, align 8
  %v1308 = load i32, ptr %slot235, align 8
  %cv1309 = zext i32 %v1308 to i64
  %cond1310 = icmp ne i64 %cv1309, 0
  br i1 %cond1310, label %bb_rcslotrole296, label %bb_rcslotowner296
bb_rcslotrole296:
  %v1311 = load i64, ptr %slot21, align 8
  store i64 %v1311, ptr %slot236, align 8
  %v1312 = load i64, ptr %slot236, align 8
  %v1313 = load i64, ptr %slot233, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1312, i64 %v1313) nomerge, !dbg !118
  br label %bb_rcslotdone296
bb_rcslotowner296:
  %v1314 = load i64, ptr %slot21, align 8
  store i64 %v1314, ptr %slot237, align 8
  %v1315 = load i64, ptr %slot237, align 8
  %v1316 = load i64, ptr %slot233, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1315, i64 %v1316) nomerge, !dbg !118
  br label %bb_rcslotdone296
bb_rcslotdone296:
  br label %bb_rchprepared293
bb_rchtaken293:
  %v1317 = load i64, ptr %slot5, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  store i32 0, ptr %p1318, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared293
bb_rchprepared293:
  %v1319 = load i64, ptr %slot8, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  store i32 2, ptr %p1320, align 4, !alias.scope !3, !noalias !4
  %v1321 = load i64, ptr %slot7, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i32 1, ptr %p1322, align 4, !alias.scope !3, !noalias !4
  %v1323 = load i64, ptr %slot9, align 8
  store i64 %v1323, ptr %slot238, align 8
  %v1324 = load i64, ptr %slot11, align 8
  store i64 %v1324, ptr %slot239, align 8
  %v1325 = load i64, ptr %slot239, align 8
  %v1326 = load i64, ptr %slot238, align 8
  %p1327 = inttoptr i64 %v1325 to ptr
  %p1328 = inttoptr i64 %v1326 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1328, ptr %p1327, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v1329 = load i64, ptr %slot6, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  store i32 2, ptr %p1330, align 4, !alias.scope !3, !noalias !4
  %v1331 = load i64, ptr %slot8, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %ld1333 = load i32, ptr %p1332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1333, ptr %slot240, align 8
  %v1334 = load i32, ptr %slot240, align 8
  %v1335 = load i64, ptr %slot6, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i32 %v1334, ptr %p1336, align 4, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot7, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  store i32 0, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  %v1339 = load i64, ptr %slot5, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i32 1, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot238, align 8
  %v1342 = load i64, ptr %slot19, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  store i64 %v1341, ptr %p1343, align 8, !alias.scope !3, !noalias !4
  %v1344 = load i64, ptr %slot17, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  %ld1346 = load i64, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1346, ptr %slot241, align 8
  %v1347 = load i64, ptr %slot19, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %ld1349 = load i64, ptr %p1348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1349, ptr %slot242, align 8
  %v1350 = load i64, ptr %slot21, align 8
  %v1351 = load i64, ptr %slot241, align 8
  %v1352 = load i64, ptr %slot242, align 8
  %call1353 = call i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_list_append(i64 %v1350, i64 %v1351, i64 %v1352) nomerge, !dbg !120
  store i32 %call1353, ptr %slot243, align 8
  %v1354 = load i32, ptr %slot243, align 8
  %cv1355 = zext i32 %v1354 to i64
  %cond1356 = icmp ne i64 %cv1355, 0
  br i1 %cond1356, label %bb_success317, label %bb_failed317
bb_failed317:
  %v1357 = load i64, ptr %slot1, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1358) nomerge, !dbg !120
  unreachable
bb_success317:
  %v1359 = load i64, ptr %slot19, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  store i64 0, ptr %p1360, align 8, !alias.scope !3, !noalias !4
  %v1361 = load i64, ptr %slot5, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  %ld1363 = load i32, ptr %p1362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1363, ptr %slot244, align 8
  %v1364 = load i32, ptr %slot244, align 8
  %cv1365 = zext i32 %v1364 to i64
  %cond1366 = icmp ne i64 %cv1365, 0
  br i1 %cond1366, label %bb_rcslotdrop320, label %bb_rcslotdone320
bb_rcslotdrop320:
  %v1367 = load i64, ptr %slot5, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i32 0, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  %v1369 = load i64, ptr %slot9, align 8
  store i64 %v1369, ptr %slot245, align 8
  %v1370 = load i64, ptr %slot6, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %ld1372 = load i32, ptr %p1371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1372, ptr %slot246, align 8
  %v1373 = load i32, ptr %slot246, align 8
  %op1374 = and i32 %v1373, 28
  store i32 %op1374, ptr %slot247, align 8
  %v1375 = load i32, ptr %slot247, align 8
  %cv1376 = zext i32 %v1375 to i64
  %cond1377 = icmp ne i64 %cv1376, 0
  br i1 %cond1377, label %bb_rcslotrole320, label %bb_rcslotowner320
bb_rcslotrole320:
  %v1378 = load i64, ptr %slot21, align 8
  store i64 %v1378, ptr %slot248, align 8
  %v1379 = load i64, ptr %slot248, align 8
  %v1380 = load i64, ptr %slot245, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v1379, i64 %v1380) nomerge, !dbg !120
  br label %bb_rcslotdone320
bb_rcslotowner320:
  %v1381 = load i64, ptr %slot21, align 8
  store i64 %v1381, ptr %slot249, align 8
  %v1382 = load i64, ptr %slot249, align 8
  %v1383 = load i64, ptr %slot245, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v1382, i64 %v1383) nomerge, !dbg !120
  br label %bb_rcslotdone320
bb_rcslotdone320:
  %v1384 = load i64, ptr %slot12, align 8
  store i64 %v1384, ptr %slot250, align 8
  %v1385 = load i64, ptr %slot250, align 8
  %p1387 = inttoptr i64 %v1385 to ptr
  %gep1388 = getelementptr i8, ptr %p1387, i64 24
  %op1386 = ptrtoint ptr %gep1388 to i64
  store i64 %op1386, ptr %slot251, align 8
  %v1389 = load i64, ptr %slot251, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %ld1391 = load i32, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1391, ptr %slot252, align 8
  %v1392 = load i32, ptr %slot252, align 8
  %cv1393 = zext i32 %v1392 to i64
  %cond1394 = icmp ne i64 %cv1393, 0
  br i1 %cond1394, label %bb_rcsendactive328, label %bb_rcsenddone328
bb_rcsendactive328:
  %v1395 = load i64, ptr %slot21, align 8
  %p1397 = inttoptr i64 %v1395 to ptr
  %gep1398 = getelementptr i8, ptr %p1397, i64 5640
  %op1396 = ptrtoint ptr %gep1398 to i64
  store i64 %op1396, ptr %slot253, align 8
  %v1399 = load i64, ptr %slot253, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i64, ptr %p1400, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1401, ptr %slot254, align 8
  %v1402 = load i64, ptr %slot254, align 8
  %op1403 = add i64 %v1402, 248
  store i64 %op1403, ptr %slot255, align 8
  %v1404 = load i64, ptr %slot255, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i64, ptr %p1405, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1406, ptr %slot256, align 8
  %v1407 = load i64, ptr %slot256, align 8
  %v1408 = load i64, ptr %slot250, align 8
  %cmp1409 = icmp eq i64 %v1407, %v1408
  %cv1410 = zext i1 %cmp1409 to i32
  store i32 %cv1410, ptr %slot257, align 8
  %v1411 = load i32, ptr %slot257, align 8
  %cv1412 = zext i32 %v1411 to i64
  %cond1413 = icmp ne i64 %cv1412, 0
  br i1 %cond1413, label %bb_rcs336, label %bb_rcsendslow328
bb_rcs336:
  %v1414 = load i64, ptr %slot254, align 8
  %op1415 = add i64 %v1414, 200
  store i64 %op1415, ptr %slot258, align 8
  %v1416 = load i64, ptr %slot258, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  %ld1418 = load i64, ptr %p1417, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1418, ptr %slot259, align 8
  %v1419 = load i64, ptr %slot259, align 8
  %cmp1420 = icmp eq i64 %v1419, 0
  %cv1421 = zext i1 %cmp1420 to i32
  store i32 %cv1421, ptr %slot260, align 8
  %v1422 = load i32, ptr %slot260, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcs340, label %bb_rcsendslow328
bb_rcs340:
  %v1425 = load i64, ptr %slot250, align 8
  %p1427 = inttoptr i64 %v1425 to ptr
  %gep1428 = getelementptr i8, ptr %p1427, i64 16
  %op1426 = ptrtoint ptr %gep1428 to i64
  store i64 %op1426, ptr %slot261, align 8
  %v1429 = load i64, ptr %slot261, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot262, align 8
  %v1432 = load i64, ptr %slot262, align 8
  %cmp1433 = icmp ne i64 %v1432, 0
  %cv1434 = zext i1 %cmp1433 to i32
  store i32 %cv1434, ptr %slot263, align 8
  %v1435 = load i32, ptr %slot263, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcsendnode328, label %bb_rcsendunlink328
bb_rcsendnode328:
  %v1438 = load i64, ptr %slot262, align 8
  %op1439 = add i64 %v1438, 0
  store i64 %op1439, ptr %slot264, align 8
  %v1440 = load i64, ptr %slot264, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i64, ptr %p1441, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1442, ptr %slot265, align 8
  %v1443 = load i64, ptr %slot265, align 8
  %cmp1444 = icmp eq i64 %v1443, 0
  %cv1445 = zext i1 %cmp1444 to i32
  store i32 %cv1445, ptr %slot266, align 8
  %v1446 = load i32, ptr %slot266, align 8
  %cv1447 = zext i32 %v1446 to i64
  %cond1448 = icmp ne i64 %cv1447, 0
  br i1 %cond1448, label %bb_rcs347, label %bb_rcsendslow328
bb_rcs347:
  %v1449 = load i64, ptr %slot254, align 8
  %op1450 = add i64 %v1449, 264
  store i64 %op1450, ptr %slot267, align 8
  %v1451 = load i64, ptr %slot267, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  %ld1453 = load i64, ptr %p1452, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1453, ptr %slot268, align 8
  %v1454 = load i64, ptr %slot268, align 8
  %cmp1455 = icmp ult i64 %v1454, 32
  %cv1456 = zext i1 %cmp1455 to i32
  store i32 %cv1456, ptr %slot269, align 8
  %v1457 = load i32, ptr %slot269, align 8
  %cv1458 = zext i32 %v1457 to i64
  %cond1459 = icmp ne i64 %cv1458, 0
  br i1 %cond1459, label %bb_rcs351, label %bb_rcsendslow328
bb_rcs351:
  %v1460 = load i64, ptr %slot262, align 8
  %op1461 = add i64 %v1460, 8
  store i64 %op1461, ptr %slot270, align 8
  %v1462 = load i64, ptr %slot270, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1464, ptr %slot271, align 8
  %v1465 = load i64, ptr %slot271, align 8
  %cmp1466 = icmp ne i64 %v1465, 0
  %cv1467 = zext i1 %cmp1466 to i32
  store i32 %cv1467, ptr %slot272, align 8
  %v1468 = load i32, ptr %slot272, align 8
  %cv1469 = zext i32 %v1468 to i64
  %cond1470 = icmp ne i64 %cv1469, 0
  br i1 %cond1470, label %bb_rcs355, label %bb_rcsendslow328
bb_rcs355:
  %v1471 = load i64, ptr %slot271, align 8
  %op1472 = sub i64 %v1471, 16
  store i64 %op1472, ptr %slot273, align 8
  %v1473 = load i64, ptr %slot271, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %rgep1475 = getelementptr i8, ptr %p1474, i64 -16
  %ld1476 = load i64, ptr %rgep1475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1476, ptr %slot274, align 8
  %v1477 = load i64, ptr %slot274, align 8
  %op1478 = and i64 %v1477, 4611686018427387907
  store i64 %op1478, ptr %slot275, align 8
  %v1479 = load i64, ptr %slot275, align 8
  %cmp1480 = icmp eq i64 %v1479, 0
  %cv1481 = zext i1 %cmp1480 to i32
  store i32 %cv1481, ptr %slot276, align 8
  %v1482 = load i32, ptr %slot276, align 8
  %cv1483 = zext i32 %v1482 to i64
  %cond1484 = icmp ne i64 %cv1483, 0
  br i1 %cond1484, label %bb_rcs360, label %bb_rcsendslow328
bb_rcs360:
  %v1485 = load i64, ptr %slot271, align 8
  %op1486 = sub i64 %v1485, 24
  store i64 %op1486, ptr %slot277, align 8
  %v1487 = load i64, ptr %slot271, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %rgep1489 = getelementptr i8, ptr %p1488, i64 -24
  %ld1490 = load i64, ptr %rgep1489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1490, ptr %slot278, align 8
  %v1491 = load i64, ptr %slot278, align 8
  %cmp1492 = icmp ne i64 %v1491, 0
  %cv1493 = zext i1 %cmp1492 to i32
  store i32 %cv1493, ptr %slot279, align 8
  %v1494 = load i32, ptr %slot279, align 8
  %cv1495 = zext i32 %v1494 to i64
  %cond1496 = icmp ne i64 %cv1495, 0
  br i1 %cond1496, label %bb_rcs364, label %bb_rcsendslow328
bb_rcs364:
  %v1497 = load i64, ptr %slot271, align 8
  %op1498 = sub i64 %v1497, 32
  store i64 %op1498, ptr %slot280, align 8
  %v1499 = load i64, ptr %slot271, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %rgep1501 = getelementptr i8, ptr %p1500, i64 -32
  %ld1502 = load i64, ptr %rgep1501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1502, ptr %slot281, align 8
  %v1503 = load i64, ptr %slot278, align 8
  %cmp1504 = icmp ugt i64 %v1503, 1
  %cv1505 = zext i1 %cmp1504 to i32
  store i32 %cv1505, ptr %slot282, align 8
  %v1506 = load i64, ptr %slot281, align 8
  %cmp1507 = icmp ne i64 %v1506, 0
  %cv1508 = zext i1 %cmp1507 to i32
  store i32 %cv1508, ptr %slot283, align 8
  %v1509 = load i32, ptr %slot282, align 8
  %v1510 = load i32, ptr %slot283, align 8
  %op1511 = or i32 %v1509, %v1510
  store i32 %op1511, ptr %slot284, align 8
  %v1512 = load i32, ptr %slot284, align 8
  %cv1513 = zext i32 %v1512 to i64
  %cond1514 = icmp ne i64 %cv1513, 0
  br i1 %cond1514, label %bb_rcs370, label %bb_rcsendslow328
bb_rcs370:
  %v1515 = load i64, ptr %slot262, align 8
  %op1516 = add i64 %v1515, 32
  store i64 %op1516, ptr %slot285, align 8
  %v1517 = load i64, ptr %slot285, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  %ld1519 = load i64, ptr %p1518, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1519, ptr %slot286, align 8
  %v1520 = load i64, ptr %slot286, align 8
  %cmp1521 = icmp ne i64 %v1520, 0
  %cv1522 = zext i1 %cmp1521 to i32
  store i32 %cv1522, ptr %slot287, align 8
  %v1523 = load i32, ptr %slot287, align 8
  %cv1524 = zext i32 %v1523 to i64
  %cond1525 = icmp ne i64 %cv1524, 0
  br i1 %cond1525, label %bb_rcsendbacking328, label %bb_rcsendcommit328
bb_rcsendbacking328:
  %v1526 = load i64, ptr %slot286, align 8
  %op1527 = sub i64 %v1526, 16
  store i64 %op1527, ptr %slot288, align 8
  %v1528 = load i64, ptr %slot286, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %rgep1530 = getelementptr i8, ptr %p1529, i64 -16
  %ld1531 = load i64, ptr %rgep1530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1531, ptr %slot289, align 8
  %v1532 = load i64, ptr %slot289, align 8
  %op1533 = and i64 %v1532, 4611686018427387907
  store i64 %op1533, ptr %slot290, align 8
  %v1534 = load i64, ptr %slot290, align 8
  %cmp1535 = icmp eq i64 %v1534, 0
  %cv1536 = zext i1 %cmp1535 to i32
  store i32 %cv1536, ptr %slot291, align 8
  %v1537 = load i32, ptr %slot291, align 8
  %cv1538 = zext i32 %v1537 to i64
  %cond1539 = icmp ne i64 %cv1538, 0
  br i1 %cond1539, label %bb_rcs378, label %bb_rcsendslow328
bb_rcs378:
  %v1540 = load i64, ptr %slot286, align 8
  %op1541 = sub i64 %v1540, 24
  store i64 %op1541, ptr %slot292, align 8
  %v1542 = load i64, ptr %slot286, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %rgep1544 = getelementptr i8, ptr %p1543, i64 -24
  %ld1545 = load i64, ptr %rgep1544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1545, ptr %slot293, align 8
  %v1546 = load i64, ptr %slot293, align 8
  %cmp1547 = icmp ne i64 %v1546, 0
  %cv1548 = zext i1 %cmp1547 to i32
  store i32 %cv1548, ptr %slot294, align 8
  %v1549 = load i32, ptr %slot294, align 8
  %cv1550 = zext i32 %v1549 to i64
  %cond1551 = icmp ne i64 %cv1550, 0
  br i1 %cond1551, label %bb_rcs382, label %bb_rcsendslow328
bb_rcs382:
  %v1552 = load i64, ptr %slot286, align 8
  %op1553 = sub i64 %v1552, 32
  store i64 %op1553, ptr %slot295, align 8
  %v1554 = load i64, ptr %slot286, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %rgep1556 = getelementptr i8, ptr %p1555, i64 -32
  %ld1557 = load i64, ptr %rgep1556, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1557, ptr %slot296, align 8
  %v1558 = load i64, ptr %slot293, align 8
  %cmp1559 = icmp ugt i64 %v1558, 1
  %cv1560 = zext i1 %cmp1559 to i32
  store i32 %cv1560, ptr %slot297, align 8
  %v1561 = load i64, ptr %slot296, align 8
  %cmp1562 = icmp ne i64 %v1561, 0
  %cv1563 = zext i1 %cmp1562 to i32
  store i32 %cv1563, ptr %slot298, align 8
  %v1564 = load i32, ptr %slot297, align 8
  %v1565 = load i32, ptr %slot298, align 8
  %op1566 = or i32 %v1564, %v1565
  store i32 %op1566, ptr %slot299, align 8
  %v1567 = load i32, ptr %slot299, align 8
  %cv1568 = zext i32 %v1567 to i64
  %cond1569 = icmp ne i64 %cv1568, 0
  br i1 %cond1569, label %bb_rcs388, label %bb_rcsendslow328
bb_rcs388:
  br label %bb_rcsendcommit328
bb_rcsendcommit328:
  %v1570 = load i64, ptr %slot262, align 8
  %op1571 = add i64 %v1570, 24
  store i64 %op1571, ptr %slot300, align 8
  %v1572 = load i64, ptr %slot300, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %ld1574 = load i32, ptr %p1573, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld1574, ptr %slot301, align 8
  %v1575 = load i32, ptr %slot301, align 8
  %cv1576 = zext i32 %v1575 to i64
  %cond1577 = icmp ne i64 %cv1576, 0
  br i1 %cond1577, label %bb_rcsendrestore328, label %bb_rcsendreturned328
bb_rcsendrestore328:
  %v1578 = load i64, ptr %slot262, align 8
  %op1579 = add i64 %v1578, 16
  store i64 %op1579, ptr %slot302, align 8
  %v1580 = load i64, ptr %slot302, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  %ld1582 = load i64, ptr %p1581, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1582, ptr %slot303, align 8
  %v1583 = load i64, ptr %slot274, align 8
  %op1584 = and i64 %v1583, 17293822569102704639
  store i64 %op1584, ptr %slot304, align 8
  %v1585 = load i64, ptr %slot304, align 8
  %v1586 = load i64, ptr %slot303, align 8
  %op1587 = or i64 %v1585, %v1586
  store i64 %op1587, ptr %slot305, align 8
  %v1588 = load i64, ptr %slot271, align 8
  %op1589 = sub i64 %v1588, 16
  store i64 %op1589, ptr %slot306, align 8
  %v1590 = load i64, ptr %slot305, align 8
  %v1591 = load i64, ptr %slot271, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %rgep1593 = getelementptr i8, ptr %p1592, i64 -16
  store i64 %v1590, ptr %rgep1593, align 8, !alias.scope !9, !noalias !10
  %v1594 = load i64, ptr %slot250, align 8
  %p1596 = inttoptr i64 %v1594 to ptr
  %gep1597 = getelementptr i8, ptr %p1596, i64 16
  %op1595 = ptrtoint ptr %gep1597 to i64
  store i64 %op1595, ptr %slot307, align 8
  br label %bb_rcsendreturned328
bb_rcsendreturned328:
  %v1598 = load i64, ptr %slot307, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i64 0, ptr %p1599, align 8, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot254, align 8
  %op1601 = add i64 %v1600, 256
  store i64 %op1601, ptr %slot308, align 8
  %v1602 = load i64, ptr %slot308, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  %ld1604 = load i64, ptr %p1603, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1604, ptr %slot309, align 8
  %v1605 = load i64, ptr %slot262, align 8
  %op1606 = add i64 %v1605, 0
  store i64 %op1606, ptr %slot310, align 8
  %v1607 = load i64, ptr %slot309, align 8
  %v1608 = load i64, ptr %slot310, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  store i64 %v1607, ptr %p1609, align 8, !alias.scope !9999998, !noalias !9999999
  %v1610 = load i64, ptr %slot254, align 8
  %op1611 = add i64 %v1610, 256
  store i64 %op1611, ptr %slot311, align 8
  %v1612 = load i64, ptr %slot262, align 8
  %v1613 = load i64, ptr %slot311, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 %v1612, ptr %p1614, align 8, !alias.scope !9999998, !noalias !9999999
  %v1615 = load i64, ptr %slot254, align 8
  %op1616 = add i64 %v1615, 264
  store i64 %op1616, ptr %slot312, align 8
  %v1617 = load i64, ptr %slot312, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i64, ptr %p1618, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1619, ptr %slot313, align 8
  %v1620 = load i64, ptr %slot313, align 8
  %op1621 = add i64 %v1620, 1
  store i64 %op1621, ptr %slot314, align 8
  %v1622 = load i64, ptr %slot314, align 8
  %v1623 = load i64, ptr %slot312, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  store i64 %v1622, ptr %p1624, align 8, !alias.scope !9999998, !noalias !9999999
  %v1625 = load i64, ptr %slot21, align 8
  %p1627 = inttoptr i64 %v1625 to ptr
  %gep1628 = getelementptr i8, ptr %p1627, i64 24
  %op1626 = ptrtoint ptr %gep1628 to i64
  store i64 %op1626, ptr %slot315, align 8
  %v1629 = load i64, ptr %slot315, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i64, ptr %p1630, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1631, ptr %slot316, align 8
  %v1632 = load i64, ptr %slot316, align 8
  %op1633 = add i64 %v1632, 18446744073709551576
  store i64 %op1633, ptr %slot317, align 8
  %v1634 = load i64, ptr %slot317, align 8
  %v1635 = load i64, ptr %slot315, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  store i64 %v1634, ptr %p1636, align 8, !alias.scope !9999998, !noalias !9999999
  %v1637 = load i64, ptr %slot254, align 8
  %op1638 = add i64 %v1637, 48
  store i64 %op1638, ptr %slot318, align 8
  %v1639 = load i64, ptr %slot318, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  %ld1641 = load i64, ptr %p1640, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld1641, ptr %slot319, align 8
  %v1642 = load i64, ptr %slot319, align 8
  %op1643 = add i64 %v1642, 18446744073709551576
  store i64 %op1643, ptr %slot320, align 8
  %v1644 = load i64, ptr %slot320, align 8
  %v1645 = load i64, ptr %slot318, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i64 %v1644, ptr %p1646, align 8, !alias.scope !9999998, !noalias !9999999
  %v1647 = load i64, ptr %slot286, align 8
  %cmp1648 = icmp ne i64 %v1647, 0
  %cv1649 = zext i1 %cmp1648 to i32
  store i32 %cv1649, ptr %slot321, align 8
  %v1650 = load i32, ptr %slot321, align 8
  %cv1651 = zext i32 %v1650 to i64
  %cond1652 = icmp ne i64 %cv1651, 0
  br i1 %cond1652, label %bb_rcsenddropbacking328, label %bb_rcsenddroppayload328
bb_rcsenddropbacking328:
  %v1653 = load i64, ptr %slot286, align 8
  %op1654 = sub i64 %v1653, 24
  store i64 %op1654, ptr %slot322, align 8
  %v1655 = load i64, ptr %slot286, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %rgep1657 = getelementptr i8, ptr %p1656, i64 -24
  %ld1658 = load i64, ptr %rgep1657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1658, ptr %slot323, align 8
  %v1659 = load i64, ptr %slot323, align 8
  %op1660 = add i64 %v1659, 18446744073709551615
  store i64 %op1660, ptr %slot324, align 8
  %v1661 = load i64, ptr %slot324, align 8
  %v1662 = load i64, ptr %slot286, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %rgep1664 = getelementptr i8, ptr %p1663, i64 -24
  store i64 %v1661, ptr %rgep1664, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload328
bb_rcsenddroppayload328:
  %v1665 = load i64, ptr %slot271, align 8
  %op1666 = sub i64 %v1665, 24
  store i64 %op1666, ptr %slot325, align 8
  %v1667 = load i64, ptr %slot271, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %rgep1669 = getelementptr i8, ptr %p1668, i64 -24
  %ld1670 = load i64, ptr %rgep1669, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1670, ptr %slot326, align 8
  %v1671 = load i64, ptr %slot326, align 8
  %op1672 = add i64 %v1671, 18446744073709551615
  store i64 %op1672, ptr %slot327, align 8
  %v1673 = load i64, ptr %slot327, align 8
  %v1674 = load i64, ptr %slot271, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  %rgep1676 = getelementptr i8, ptr %p1675, i64 -24
  store i64 %v1673, ptr %rgep1676, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink328
bb_rcsendunlink328:
  %v1677 = load i64, ptr %slot250, align 8
  %p1679 = inttoptr i64 %v1677 to ptr
  %gep1680 = getelementptr i8, ptr %p1679, i64 8
  %op1678 = ptrtoint ptr %gep1680 to i64
  store i64 %op1678, ptr %slot328, align 8
  %v1681 = load i64, ptr %slot328, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  %ld1683 = load i64, ptr %p1682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1683, ptr %slot329, align 8
  %v1684 = load i64, ptr %slot254, align 8
  %op1685 = add i64 %v1684, 248
  store i64 %op1685, ptr %slot330, align 8
  %v1686 = load i64, ptr %slot329, align 8
  %v1687 = load i64, ptr %slot330, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  store i64 %v1686, ptr %p1688, align 8, !alias.scope !9999998, !noalias !9999999
  %v1689 = load i64, ptr %slot250, align 8
  %p1691 = inttoptr i64 %v1689 to ptr
  %gep1692 = getelementptr i8, ptr %p1691, i64 24
  %op1690 = ptrtoint ptr %gep1692 to i64
  store i64 %op1690, ptr %slot331, align 8
  %v1693 = load i64, ptr %slot250, align 8
  %p1695 = inttoptr i64 %v1693 to ptr
  %gep1696 = getelementptr i8, ptr %p1695, i64 8
  %op1694 = ptrtoint ptr %gep1696 to i64
  store i64 %op1694, ptr %slot332, align 8
  %v1697 = load i64, ptr %slot331, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 0, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot332, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i64 0, ptr %p1700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone328
bb_rcsendslow328:
  %v1701 = load i64, ptr %slot1, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %v1703 = load i64, ptr %slot250, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p1702, ptr %p1704) nomerge, !dbg !120
  br label %bb_rcsenddone328
bb_rcsenddone328:
  %v1705 = load i64, ptr %slot15, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %ld1707 = load i64, ptr %p1706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1707, ptr %slot333, align 8
  %v1708 = load i64, ptr %slot333, align 8
  %v1709 = load i64, ptr %slot19, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i64 %v1708, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot19, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i64, ptr %p1712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1713, ptr %slot334, align 8
  %v1714 = load i64, ptr %slot334, align 8
  %op1715 = add i64 %v1714, 280
  store i64 %op1715, ptr %slot335, align 8
  %v1716 = load i64, ptr %slot335, align 8
  %v1717 = load i64, ptr %slot19, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i64 %v1716, ptr %p1718, align 8, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot5, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %ld1721 = load i32, ptr %p1720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1721, ptr %slot336, align 8
  %v1722 = load i32, ptr %slot336, align 8
  %cv1723 = zext i32 %v1722 to i64
  %cond1724 = icmp ne i64 %cv1723, 0
  br i1 %cond1724, label %bb_rcslotdrop427, label %bb_rcslotdone427
bb_rcslotdrop427:
  %v1725 = load i64, ptr %slot5, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i32 0, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot9, align 8
  store i64 %v1727, ptr %slot337, align 8
  %v1728 = load i64, ptr %slot6, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  %ld1730 = load i32, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1730, ptr %slot338, align 8
  %v1731 = load i32, ptr %slot338, align 8
  %op1732 = and i32 %v1731, 28
  store i32 %op1732, ptr %slot339, align 8
  %v1733 = load i32, ptr %slot339, align 8
  %cv1734 = zext i32 %v1733 to i64
  %cond1735 = icmp ne i64 %cv1734, 0
  br i1 %cond1735, label %bb_rcslotrole427, label %bb_rcslotowner427
bb_rcslotrole427:
  %v1736 = load i64, ptr %slot21, align 8
  store i64 %v1736, ptr %slot340, align 8
  %v1737 = load i64, ptr %slot340, align 8
  %v1738 = load i64, ptr %slot337, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1737, i64 %v1738) nomerge, !dbg !122
  br label %bb_rcslotdone427
bb_rcslotowner427:
  %v1739 = load i64, ptr %slot21, align 8
  store i64 %v1739, ptr %slot341, align 8
  %v1740 = load i64, ptr %slot341, align 8
  %v1741 = load i64, ptr %slot337, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1740, i64 %v1741) nomerge, !dbg !122
  br label %bb_rcslotdone427
bb_rcslotdone427:
  %v1742 = load i64, ptr %slot19, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i64, ptr %p1743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1744, ptr %slot342, align 8
  %v1745 = load i64, ptr %slot342, align 8
  %op1746 = add i64 %v1745, 0
  store i64 %op1746, ptr %slot343, align 8
  %v1747 = load i64, ptr %slot343, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  %ld1749 = load i64, ptr %p1748, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1749, ptr %slot344, align 8
  %v1750 = load i64, ptr %slot344, align 8
  %v1751 = load i64, ptr %slot19, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  store i64 %v1750, ptr %p1752, align 8, !alias.scope !3, !noalias !4
  %v1753 = load i64, ptr %slot5, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  %ld1755 = load i32, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1755, ptr %slot345, align 8
  %v1756 = load i32, ptr %slot345, align 8
  %cv1757 = zext i32 %v1756 to i64
  %cond1758 = icmp ne i64 %cv1757, 0
  br i1 %cond1758, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v1759 = load i64, ptr %slot5, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  store i32 0, ptr %p1760, align 4, !alias.scope !3, !noalias !4
  %v1761 = load i64, ptr %slot9, align 8
  store i64 %v1761, ptr %slot346, align 8
  %v1762 = load i64, ptr %slot6, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  %ld1764 = load i32, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1764, ptr %slot347, align 8
  %v1765 = load i32, ptr %slot347, align 8
  %op1766 = and i32 %v1765, 28
  store i32 %op1766, ptr %slot348, align 8
  %v1767 = load i32, ptr %slot348, align 8
  %cv1768 = zext i32 %v1767 to i64
  %cond1769 = icmp ne i64 %cv1768, 0
  br i1 %cond1769, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v1770 = load i64, ptr %slot21, align 8
  store i64 %v1770, ptr %slot349, align 8
  %v1771 = load i64, ptr %slot349, align 8
  %v1772 = load i64, ptr %slot346, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v1771, i64 %v1772) nomerge, !dbg !124
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v1773 = load i64, ptr %slot21, align 8
  store i64 %v1773, ptr %slot350, align 8
  %v1774 = load i64, ptr %slot350, align 8
  %v1775 = load i64, ptr %slot346, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v1774, i64 %v1775) nomerge, !dbg !124
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v1776 = load i64, ptr %slot19, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %ld1778 = load i64, ptr %p1777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1778, ptr %slot351, align 8
  %v1779 = load i64, ptr %slot351, align 8
  %v1780 = load i64, ptr %slot18, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  store i64 %v1779, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  %v1782 = load i64, ptr %slot18, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  %ld1784 = load i64, ptr %p1783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1784, ptr %slot352, align 8
  %v1785 = load i64, ptr %slot352, align 8
  %op1786 = add i64 %v1785, 0
  store i64 %op1786, ptr %slot353, align 8
  %v1787 = load i64, ptr %slot353, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i64, ptr %p1788, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1789, ptr %slot354, align 8
  %v1790 = load i64, ptr %slot354, align 8
  %v1791 = load i64, ptr %slot19, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  store i64 %v1790, ptr %p1792, align 8, !alias.scope !3, !noalias !4
  %v1793 = load i64, ptr %slot19, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  %ld1795 = load i64, ptr %p1794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1795, ptr %slot355, align 8
  %v1796 = load i64, ptr %slot355, align 8
  %cmp1797 = icmp ugt i64 %v1796, 9223372036854775807
  %cv1798 = zext i1 %cmp1797 to i64
  store i64 %cv1798, ptr %slot356, align 8
  %v1799 = load i64, ptr %slot356, align 8
  %cond1800 = icmp ne i64 %v1799, 0
  br i1 %cond1800, label %bb_cast_overflow452, label %bb_cast_ok452
bb_cast_overflow452:
  %v1801 = load i64, ptr %slot1, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  %v1803 = load i64, ptr %slot355, align 8
  call void @myl_qbe_fail_cast(ptr %p1802, i64 %v1803, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok452:
  %v1804 = load i64, ptr %slot355, align 8
  %v1805 = load i64, ptr %slot19, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i64 %v1804, ptr %p1806, align 8, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot20, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i64 1, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot20, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %ld1811 = load i64, ptr %p1810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1811, ptr %slot357, align 8
  %v1812 = load i64, ptr %slot19, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %ld1814 = load i64, ptr %p1813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1814, ptr %slot358, align 8
  %v1815 = load i64, ptr %slot358, align 8
  %v1816 = load i64, ptr %slot357, align 8
  %ovpair1818 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1815, i64 %v1816)
  %op1817 = extractvalue { i64, i1 } %ovpair1818, 0
  %ov1819 = extractvalue { i64, i1 } %ovpair1818, 1
  store i64 %op1817, ptr %slot359, align 8
  %cv1820 = zext i1 %ov1819 to i64
  store i64 %cv1820, ptr %slot360, align 8
  %v1821 = load i64, ptr %slot360, align 8
  %cond1822 = icmp ne i64 %v1821, 0
  br i1 %cond1822, label %bb_overflow455, label %bb_checked455
bb_overflow455:
  %v1823 = load i64, ptr %slot1, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %v1825 = load i64, ptr %slot358, align 8
  %v1826 = load i64, ptr %slot357, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1824, i64 1, i64 %v1825, i64 %v1826, i64 64) nomerge, !dbg !128
  unreachable
bb_checked455:
  %v1827 = load i64, ptr %slot359, align 8
  %v1828 = load i64, ptr %slot19, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i64 %v1827, ptr %p1829, align 8, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot19, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %ld1832 = load i64, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1832, ptr %slot361, align 8
  %v1833 = load i64, ptr %slot12, align 8
  %p1835 = inttoptr i64 %v1833 to ptr
  %gep1836 = getelementptr i8, ptr %p1835, i64 24
  %op1834 = ptrtoint ptr %gep1836 to i64
  store i64 %op1834, ptr %slot362, align 8
  %v1837 = load i64, ptr %slot362, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  %ld1839 = load i32, ptr %p1838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1839, ptr %slot363, align 8
  %v1840 = load i32, ptr %slot363, align 8
  %cv1841 = zext i32 %v1840 to i64
  %cond1842 = icmp ne i64 %cv1841, 0
  br i1 %cond1842, label %bb_rcscopesopen460, label %bb_rcscopesclosed460
bb_rcscopesopen460:
  %v1843 = load i64, ptr %slot14, align 8
  %p1845 = inttoptr i64 %v1843 to ptr
  %gep1846 = getelementptr i8, ptr %p1845, i64 0
  %op1844 = ptrtoint ptr %gep1846 to i64
  store i64 %op1844, ptr %slot364, align 8
  %v1847 = load i64, ptr %slot12, align 8
  %v1848 = load i64, ptr %slot364, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  store i64 %v1847, ptr %p1849, align 8, !alias.scope !3, !noalias !4
  %v1850 = load i64, ptr %slot1, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %v1852 = load i64, ptr %slot14, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p1851, ptr %p1853, i64 1) nomerge, !dbg !130
  br label %bb_rcscopesclosed460
bb_rcscopesclosed460:
  %v1854 = load i64, ptr %slot5, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %ld1856 = load i32, ptr %p1855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1856, ptr %slot365, align 8
  %v1857 = load i32, ptr %slot365, align 8
  %cv1858 = zext i32 %v1857 to i64
  %cond1859 = icmp ne i64 %cv1858, 0
  br i1 %cond1859, label %bb_rcslotdrop464, label %bb_rcslotdone464
bb_rcslotdrop464:
  %v1860 = load i64, ptr %slot5, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  store i32 0, ptr %p1861, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone464
bb_rcslotdone464:
  %v1862 = load i64, ptr %slot361, align 8
  ret i64 %v1862
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64, i64)
declare void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_publish(i64, i64, i64, i32, i32)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055", linkageName: "myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16989488430708749364, i64 0, !"myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!124 = !DILocation(line: 11, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!128 = !DILocation(line: 16, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!130 = !DILocation(line: 17, column: 0, scope: !131)
