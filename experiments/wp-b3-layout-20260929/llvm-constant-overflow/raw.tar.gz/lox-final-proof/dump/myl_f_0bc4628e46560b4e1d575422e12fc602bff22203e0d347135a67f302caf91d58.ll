target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_0bc4628e46560b4e1d575422e12fc602bff22203e0d347135a67f302caf91d58(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v21 = load i64, ptr %slot1, align 8
  %op22 = add i64 %v21, 32
  store i64 %op22, ptr %slot4, align 8
  %mem23 = alloca i8, i64 8, align 8
  %ptr24 = ptrtoint ptr %mem23 to i64
  store i64 %ptr24, ptr %slot5, align 8
  %mem25 = alloca i8, i64 8, align 8
  %ptr26 = ptrtoint ptr %mem25 to i64
  store i64 %ptr26, ptr %slot6, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot7, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot8, align 8
  %v31 = load i64, ptr %slot2, align 8
  %v32 = load i64, ptr %slot5, align 8
  %p33 = inttoptr i64 %v32 to ptr
  store i64 %v31, ptr %p33, align 8, !alias.scope !3, !noalias !4
  %v34 = load i64, ptr %slot3, align 8
  %v35 = load i64, ptr %slot6, align 8
  %p36 = inttoptr i64 %v35 to ptr
  store i64 %v34, ptr %p36, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v37 = load i64, ptr %slot6, align 8
  %p38 = inttoptr i64 %v37 to ptr
  %ld39 = load i64, ptr %p38, align 8, !alias.scope !3, !noalias !4
  store i64 %ld39, ptr %slot9, align 8
  %v40 = load i64, ptr %slot9, align 8
  %v41 = load i64, ptr %slot7, align 8
  %p42 = inttoptr i64 %v41 to ptr
  store i64 %v40, ptr %p42, align 8, !alias.scope !3, !noalias !4
  %v43 = load i64, ptr %slot7, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !3, !noalias !4
  store i64 %ld45, ptr %slot10, align 8
  %v46 = load i64, ptr %slot10, align 8
  %op47 = add i64 %v46, 0
  store i64 %op47, ptr %slot11, align 8
  %v48 = load i64, ptr %slot11, align 8
  %p49 = inttoptr i64 %v48 to ptr
  %ld50 = load i64, ptr %p49, align 8, !alias.scope !4, !noalias !3
  store i64 %ld50, ptr %slot12, align 8
  %v51 = load i64, ptr %slot12, align 8
  %v52 = load i64, ptr %slot7, align 8
  %p53 = inttoptr i64 %v52 to ptr
  store i64 %v51, ptr %p53, align 8, !alias.scope !3, !noalias !4
  %v54 = load i64, ptr %slot5, align 8
  %p55 = inttoptr i64 %v54 to ptr
  %ld56 = load i64, ptr %p55, align 8, !alias.scope !3, !noalias !4
  store i64 %ld56, ptr %slot13, align 8
  %v57 = load i64, ptr %slot13, align 8
  %v58 = load i64, ptr %slot8, align 8
  %p59 = inttoptr i64 %v58 to ptr
  store i64 %v57, ptr %p59, align 8, !alias.scope !3, !noalias !4
  %v60 = load i64, ptr %slot8, align 8
  %p61 = inttoptr i64 %v60 to ptr
  %ld62 = load i64, ptr %p61, align 8, !alias.scope !3, !noalias !4
  store i64 %ld62, ptr %slot14, align 8
  %v63 = load i64, ptr %slot14, align 8
  %op64 = add i64 %v63, 0
  store i64 %op64, ptr %slot15, align 8
  %v65 = load i64, ptr %slot15, align 8
  %p66 = inttoptr i64 %v65 to ptr
  %ld67 = load i64, ptr %p66, align 8, !alias.scope !4, !noalias !3
  store i64 %ld67, ptr %slot16, align 8
  %v68 = load i64, ptr %slot16, align 8
  %v69 = load i64, ptr %slot8, align 8
  %p70 = inttoptr i64 %v69 to ptr
  store i64 %v68, ptr %p70, align 8, !alias.scope !3, !noalias !4
  %v71 = load i64, ptr %slot8, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !3, !noalias !4
  store i64 %ld73, ptr %slot17, align 8
  %v74 = load i64, ptr %slot7, align 8
  %p75 = inttoptr i64 %v74 to ptr
  %ld76 = load i64, ptr %p75, align 8, !alias.scope !3, !noalias !4
  store i64 %ld76, ptr %slot18, align 8
  %v77 = load i64, ptr %slot18, align 8
  %v78 = load i64, ptr %slot17, align 8
  %cmp79 = icmp sge i64 %v77, %v78
  %cv80 = zext i1 %cmp79 to i64
  store i64 %cv80, ptr %slot19, align 8
  %v81 = load i64, ptr %slot19, align 8
  %v82 = load i64, ptr %slot7, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 %v81, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot7, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ld86 = load i64, ptr %p85, align 8, !alias.scope !3, !noalias !4
  store i64 %ld86, ptr %slot20, align 8
  %v87 = load i64, ptr %slot20, align 8
  ret i64 %v87
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
