target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v1044 = load i64, ptr %slot1, align 8
  %op1045 = add i64 %v1044, 32
  store i64 %op1045, ptr %slot5, align 8
  %mem1046 = alloca i8, i64 8, align 8
  %ptr1047 = ptrtoint ptr %mem1046 to i64
  store i64 %ptr1047, ptr %slot6, align 8
  %mem1048 = alloca i8, i64 8, align 8
  %ptr1049 = ptrtoint ptr %mem1048 to i64
  store i64 %ptr1049, ptr %slot7, align 8
  %mem1050 = alloca i8, i64 8, align 8
  %ptr1051 = ptrtoint ptr %mem1050 to i64
  store i64 %ptr1051, ptr %slot8, align 8
  %mem1052 = alloca i8, i64 8, align 8
  %ptr1053 = ptrtoint ptr %mem1052 to i64
  store i64 %ptr1053, ptr %slot9, align 8
  %mem1054 = alloca i8, i64 8, align 8
  %ptr1055 = ptrtoint ptr %mem1054 to i64
  store i64 %ptr1055, ptr %slot10, align 8
  %mem1056 = alloca i8, i64 8, align 8
  %ptr1057 = ptrtoint ptr %mem1056 to i64
  store i64 %ptr1057, ptr %slot11, align 8
  %mem1058 = alloca i8, i64 8, align 8
  %ptr1059 = ptrtoint ptr %mem1058 to i64
  store i64 %ptr1059, ptr %slot12, align 8
  %mem1060 = alloca i8, i64 8, align 8
  %ptr1061 = ptrtoint ptr %mem1060 to i64
  store i64 %ptr1061, ptr %slot13, align 8
  %mem1062 = alloca i8, i64 8, align 8
  %ptr1063 = ptrtoint ptr %mem1062 to i64
  store i64 %ptr1063, ptr %slot14, align 8
  %mem1064 = alloca i8, i64 8, align 8
  %ptr1065 = ptrtoint ptr %mem1064 to i64
  store i64 %ptr1065, ptr %slot15, align 8
  %mem1066 = alloca i8, i64 8, align 8
  %ptr1067 = ptrtoint ptr %mem1066 to i64
  store i64 %ptr1067, ptr %slot16, align 8
  %mem1068 = alloca i8, i64 8, align 8
  %ptr1069 = ptrtoint ptr %mem1068 to i64
  store i64 %ptr1069, ptr %slot17, align 8
  %mem1070 = alloca i8, i64 8, align 8
  %ptr1071 = ptrtoint ptr %mem1070 to i64
  store i64 %ptr1071, ptr %slot18, align 8
  %mem1072 = alloca i8, i64 392, align 8
  %ptr1073 = ptrtoint ptr %mem1072 to i64
  store i64 %ptr1073, ptr %slot19, align 8
  %mem1074 = alloca i8, i64 88, align 8
  %ptr1075 = ptrtoint ptr %mem1074 to i64
  store i64 %ptr1075, ptr %slot20, align 8
  %mem1076 = alloca i8, i64 8, align 8
  %ptr1077 = ptrtoint ptr %mem1076 to i64
  store i64 %ptr1077, ptr %slot21, align 8
  %mem1078 = alloca i8, i64 392, align 8
  %ptr1079 = ptrtoint ptr %mem1078 to i64
  store i64 %ptr1079, ptr %slot22, align 8
  %mem1080 = alloca i8, i64 32, align 8
  %ptr1081 = ptrtoint ptr %mem1080 to i64
  store i64 %ptr1081, ptr %slot23, align 8
  %v1082 = load i64, ptr %slot23, align 8
  %p1084 = inttoptr i64 %v1082 to ptr
  %gep1085 = getelementptr i8, ptr %p1084, i64 24
  %op1083 = ptrtoint ptr %gep1085 to i64
  store i64 %op1083, ptr %slot24, align 8
  %v1086 = load i64, ptr %slot24, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  store i64 0, ptr %p1087, align 8, !alias.scope !3, !noalias !4
  %mem1088 = alloca i8, i64 32, align 8
  %ptr1089 = ptrtoint ptr %mem1088 to i64
  store i64 %ptr1089, ptr %slot25, align 8
  %v1090 = load i64, ptr %slot25, align 8
  %p1092 = inttoptr i64 %v1090 to ptr
  %gep1093 = getelementptr i8, ptr %p1092, i64 24
  %op1091 = ptrtoint ptr %gep1093 to i64
  store i64 %op1091, ptr %slot26, align 8
  %v1094 = load i64, ptr %slot26, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  store i64 0, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  %mem1096 = alloca i8, i64 16, align 8
  %ptr1097 = ptrtoint ptr %mem1096 to i64
  store i64 %ptr1097, ptr %slot27, align 8
  %mem1098 = alloca i8, i64 8, align 8
  %ptr1099 = ptrtoint ptr %mem1098 to i64
  store i64 %ptr1099, ptr %slot28, align 8
  %mem1100 = alloca i8, i64 8, align 8
  %ptr1101 = ptrtoint ptr %mem1100 to i64
  store i64 %ptr1101, ptr %slot29, align 8
  %mem1102 = alloca i8, i64 8, align 8
  %ptr1103 = ptrtoint ptr %mem1102 to i64
  store i64 %ptr1103, ptr %slot30, align 8
  %mem1104 = alloca i8, i64 8, align 8
  %ptr1105 = ptrtoint ptr %mem1104 to i64
  store i64 %ptr1105, ptr %slot31, align 8
  %mem1106 = alloca i8, i64 8, align 8
  %ptr1107 = ptrtoint ptr %mem1106 to i64
  store i64 %ptr1107, ptr %slot32, align 8
  %mem1108 = alloca i8, i64 8, align 8
  %ptr1109 = ptrtoint ptr %mem1108 to i64
  store i64 %ptr1109, ptr %slot33, align 8
  %mem1110 = alloca i8, i64 88, align 8
  %ptr1111 = ptrtoint ptr %mem1110 to i64
  store i64 %ptr1111, ptr %slot34, align 8
  %mem1112 = alloca i8, i64 8, align 8
  %ptr1113 = ptrtoint ptr %mem1112 to i64
  store i64 %ptr1113, ptr %slot35, align 8
  %mem1114 = alloca i8, i64 8, align 8
  %ptr1115 = ptrtoint ptr %mem1114 to i64
  store i64 %ptr1115, ptr %slot36, align 8
  %mem1116 = alloca i8, i64 8, align 8
  %ptr1117 = ptrtoint ptr %mem1116 to i64
  store i64 %ptr1117, ptr %slot37, align 8
  %mem1118 = alloca i8, i64 24, align 8
  %ptr1119 = ptrtoint ptr %mem1118 to i64
  store i64 %ptr1119, ptr %slot38, align 8
  %mem1120 = alloca i8, i64 8, align 8
  %ptr1121 = ptrtoint ptr %mem1120 to i64
  store i64 %ptr1121, ptr %slot39, align 8
  %mem1122 = alloca i8, i64 8, align 8
  %ptr1123 = ptrtoint ptr %mem1122 to i64
  store i64 %ptr1123, ptr %slot40, align 8
  %mem1124 = alloca i8, i64 88, align 8
  %ptr1125 = ptrtoint ptr %mem1124 to i64
  store i64 %ptr1125, ptr %slot41, align 8
  %mem1126 = alloca i8, i64 8, align 8
  %ptr1127 = ptrtoint ptr %mem1126 to i64
  store i64 %ptr1127, ptr %slot42, align 8
  %mem1128 = alloca i8, i64 8, align 8
  %ptr1129 = ptrtoint ptr %mem1128 to i64
  store i64 %ptr1129, ptr %slot43, align 8
  %mem1130 = alloca i8, i64 8, align 8
  %ptr1131 = ptrtoint ptr %mem1130 to i64
  store i64 %ptr1131, ptr %slot44, align 8
  %mem1132 = alloca i8, i64 8, align 8
  %ptr1133 = ptrtoint ptr %mem1132 to i64
  store i64 %ptr1133, ptr %slot45, align 8
  %mem1134 = alloca i8, i64 8, align 8
  %ptr1135 = ptrtoint ptr %mem1134 to i64
  store i64 %ptr1135, ptr %slot46, align 8
  %mem1136 = alloca i8, i64 8, align 8
  %ptr1137 = ptrtoint ptr %mem1136 to i64
  store i64 %ptr1137, ptr %slot47, align 8
  %mem1138 = alloca i8, i64 24, align 8
  %ptr1139 = ptrtoint ptr %mem1138 to i64
  store i64 %ptr1139, ptr %slot48, align 8
  %mem1140 = alloca i8, i64 88, align 8
  %ptr1141 = ptrtoint ptr %mem1140 to i64
  store i64 %ptr1141, ptr %slot49, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem1142 = alloca i8, i64 8, align 8
  %ptr1143 = ptrtoint ptr %mem1142 to i64
  store i64 %ptr1143, ptr %slot50, align 8
  %v1144 = load i64, ptr %slot1, align 8
  %op1145 = add i64 %v1144, 64
  store i64 %op1145, ptr %slot51, align 8
  %v1146 = load i64, ptr %slot51, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1148, ptr %slot52, align 8
  %stack1149 = call ptr @llvm.stacksave()
  %stackaddr1150 = ptrtoint ptr %stack1149 to i64
  %v1151 = load i64, ptr %slot52, align 8
  %cmp1152 = icmp ult i64 %stackaddr1150, %v1151
  %cv1153 = zext i1 %cmp1152 to i64
  store i64 %cv1153, ptr %slot53, align 8
  %v1154 = load i64, ptr %slot53, align 8
  %cond1155 = icmp ne i64 %v1154, 0
  br i1 %cond1155, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v1156 = load i64, ptr %slot1, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  call void @myl_qbe_fail_frame(ptr %p1157) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %mem1158 = alloca i8, i64 88, align 8
  %ptr1159 = ptrtoint ptr %mem1158 to i64
  store i64 %ptr1159, ptr %slot54, align 8
  %v1160 = load i64, ptr %slot32, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i64 0, ptr %p1161, align 8, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot35, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  store i64 0, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  %v1164 = load i64, ptr %slot40, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  store i64 0, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  %v1166 = load i64, ptr %slot2, align 8
  %v1167 = load i64, ptr %slot28, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i64 %v1166, ptr %p1168, align 8, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot3, align 8
  %v1170 = load i64, ptr %slot29, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  store i64 %v1169, ptr %p1171, align 8, !alias.scope !3, !noalias !4
  %v1172 = load i64, ptr %slot4, align 8
  %v1173 = load i64, ptr %slot30, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i64 %v1172, ptr %p1174, align 8, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot1, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %call1177 = call ptr @myl_qbe_heap(ptr %p1176) nomerge, !dbg !112
  %calladdr1178 = ptrtoint ptr %call1177 to i64
  store i64 %calladdr1178, ptr %slot55, align 8
  %v1179 = load i64, ptr %slot1, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %call1181 = call i64 @myl_qbe_region_mark(ptr %p1180) nomerge, !dbg !112
  store i64 %call1181, ptr %slot56, align 8
  %v1182 = load i64, ptr %slot6, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  store i32 0, ptr %p1183, align 4, !alias.scope !3, !noalias !4
  %v1184 = load i64, ptr %slot7, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i32 0, ptr %p1185, align 4, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot8, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  store i32 0, ptr %p1187, align 4, !alias.scope !3, !noalias !4
  %v1188 = load i64, ptr %slot9, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  store i32 0, ptr %p1189, align 4, !alias.scope !3, !noalias !4
  %v1190 = load i64, ptr %slot10, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  store i32 0, ptr %p1191, align 4, !alias.scope !3, !noalias !4
  %v1192 = load i64, ptr %slot11, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  store i32 0, ptr %p1193, align 4, !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot12, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i32 0, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot13, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  store i32 0, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  %v1198 = load i64, ptr %slot14, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  store i32 0, ptr %p1199, align 4, !alias.scope !3, !noalias !4
  %v1200 = load i64, ptr %slot15, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i32 0, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot16, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 0, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot17, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i32 0, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot18, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  store i32 0, ptr %p1207, align 4, !alias.scope !3, !noalias !4
  %v1208 = load i64, ptr %slot7, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  store i32 2, ptr %p1209, align 4, !alias.scope !3, !noalias !4
  %v1210 = load i64, ptr %slot9, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i32 2, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot11, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  store i32 2, ptr %p1213, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1214 = load i64, ptr %slot29, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %ld1216 = load i64, ptr %p1215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1216, ptr %slot57, align 8
  %v1217 = load i64, ptr %slot57, align 8
  %v1218 = load i64, ptr %slot44, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i64 %v1217, ptr %p1219, align 8, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot45, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i64 0, ptr %p1221, align 8, !alias.scope !3, !noalias !4
  %v1222 = load i64, ptr %slot45, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i64, ptr %p1223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1224, ptr %slot58, align 8
  %v1225 = load i64, ptr %slot44, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %ld1227 = load i64, ptr %p1226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1227, ptr %slot59, align 8
  %v1228 = load i64, ptr %slot59, align 8
  %v1229 = load i64, ptr %slot58, align 8
  %cmp1230 = icmp eq i64 %v1228, %v1229
  %cv1231 = zext i1 %cmp1230 to i64
  store i64 %cv1231, ptr %slot60, align 8
  %v1232 = load i64, ptr %slot60, align 8
  %v1233 = load i64, ptr %slot44, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i64 %v1232, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  %v1235 = load i64, ptr %slot44, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i64, ptr %p1236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1237, ptr %slot61, align 8
  %v1238 = load i64, ptr %slot61, align 8
  %cond1239 = icmp ne i64 %v1238, 0
  br i1 %cond1239, label %bb_next22, label %bb_i6
bb_next22:
  %v1240 = load i64, ptr %slot44, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i64 18446744073709551615, ptr %p1241, align 8, !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot44, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %ld1244 = load i64, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1244, ptr %slot62, align 8
  %v1245 = load i64, ptr %slot23, align 8
  %p1247 = inttoptr i64 %v1245 to ptr
  %gep1248 = getelementptr i8, ptr %p1247, i64 24
  %op1246 = ptrtoint ptr %gep1248 to i64
  store i64 %op1246, ptr %slot63, align 8
  %v1249 = load i64, ptr %slot63, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i32, ptr %p1250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1251, ptr %slot64, align 8
  %v1252 = load i64, ptr %slot25, align 8
  %p1254 = inttoptr i64 %v1252 to ptr
  %gep1255 = getelementptr i8, ptr %p1254, i64 24
  %op1253 = ptrtoint ptr %gep1255 to i64
  store i64 %op1253, ptr %slot65, align 8
  %v1256 = load i64, ptr %slot65, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %ld1258 = load i32, ptr %p1257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1258, ptr %slot66, align 8
  %v1259 = load i32, ptr %slot64, align 8
  %v1260 = load i32, ptr %slot66, align 8
  %op1261 = or i32 %v1259, %v1260
  store i32 %op1261, ptr %slot67, align 8
  %v1262 = load i32, ptr %slot67, align 8
  %cv1263 = zext i32 %v1262 to i64
  %cond1264 = icmp ne i64 %cv1263, 0
  br i1 %cond1264, label %bb_rcscopesopen28, label %bb_rcscopesclosed28
bb_rcscopesopen28:
  %v1265 = load i64, ptr %slot27, align 8
  %p1267 = inttoptr i64 %v1265 to ptr
  %gep1268 = getelementptr i8, ptr %p1267, i64 0
  %op1266 = ptrtoint ptr %gep1268 to i64
  store i64 %op1266, ptr %slot68, align 8
  %v1269 = load i64, ptr %slot23, align 8
  %v1270 = load i64, ptr %slot68, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i64 %v1269, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot27, align 8
  %p1274 = inttoptr i64 %v1272 to ptr
  %gep1275 = getelementptr i8, ptr %p1274, i64 8
  %op1273 = ptrtoint ptr %gep1275 to i64
  store i64 %op1273, ptr %slot69, align 8
  %v1276 = load i64, ptr %slot25, align 8
  %v1277 = load i64, ptr %slot69, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  store i64 %v1276, ptr %p1278, align 8, !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot1, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  %v1281 = load i64, ptr %slot27, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p1280, ptr %p1282, i64 2) nomerge, !dbg !114
  br label %bb_rcscopesclosed28
bb_rcscopesclosed28:
  %v1283 = load i64, ptr %slot12, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %ld1285 = load i32, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1285, ptr %slot70, align 8
  %v1286 = load i32, ptr %slot70, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcslotdrop33, label %bb_rcslotdone33
bb_rcslotdrop33:
  %v1289 = load i64, ptr %slot12, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  store i32 0, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone33
bb_rcslotdone33:
  %v1291 = load i64, ptr %slot10, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %ld1293 = load i32, ptr %p1292, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1293, ptr %slot71, align 8
  %v1294 = load i32, ptr %slot71, align 8
  %cv1295 = zext i32 %v1294 to i64
  %cond1296 = icmp ne i64 %cv1295, 0
  br i1 %cond1296, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v1297 = load i64, ptr %slot10, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  store i32 0, ptr %p1298, align 4, !alias.scope !3, !noalias !4
  %v1299 = load i64, ptr %slot41, align 8
  store i64 %v1299, ptr %slot72, align 8
  %v1300 = load i64, ptr %slot11, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  %ld1302 = load i32, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1302, ptr %slot73, align 8
  %v1303 = load i32, ptr %slot73, align 8
  %op1304 = and i32 %v1303, 28
  store i32 %op1304, ptr %slot74, align 8
  %v1305 = load i32, ptr %slot74, align 8
  %cv1306 = zext i32 %v1305 to i64
  %cond1307 = icmp ne i64 %cv1306, 0
  br i1 %cond1307, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v1308 = load i64, ptr %slot55, align 8
  store i64 %v1308, ptr %slot75, align 8
  %v1309 = load i64, ptr %slot75, align 8
  %v1310 = load i64, ptr %slot72, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1309, i64 %v1310) nomerge, !dbg !114
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v1311 = load i64, ptr %slot55, align 8
  store i64 %v1311, ptr %slot76, align 8
  %v1312 = load i64, ptr %slot76, align 8
  %v1313 = load i64, ptr %slot72, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1312, i64 %v1313) nomerge, !dbg !114
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v1314 = load i64, ptr %slot8, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i32, ptr %p1315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1316, ptr %slot77, align 8
  %v1317 = load i32, ptr %slot77, align 8
  %cv1318 = zext i32 %v1317 to i64
  %cond1319 = icmp ne i64 %cv1318, 0
  br i1 %cond1319, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1320 = load i64, ptr %slot8, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i32 0, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot38, align 8
  store i64 %v1322, ptr %slot78, align 8
  %v1323 = load i64, ptr %slot9, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  %ld1325 = load i32, ptr %p1324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1325, ptr %slot79, align 8
  %v1326 = load i32, ptr %slot79, align 8
  %op1327 = and i32 %v1326, 28
  store i32 %op1327, ptr %slot80, align 8
  %v1328 = load i32, ptr %slot80, align 8
  %cv1329 = zext i32 %v1328 to i64
  %cond1330 = icmp ne i64 %cv1329, 0
  br i1 %cond1330, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1331 = load i64, ptr %slot55, align 8
  store i64 %v1331, ptr %slot81, align 8
  %v1332 = load i64, ptr %slot81, align 8
  %v1333 = load i64, ptr %slot78, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v1332, i64 %v1333) nomerge, !dbg !114
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1334 = load i64, ptr %slot55, align 8
  store i64 %v1334, ptr %slot82, align 8
  %v1335 = load i64, ptr %slot82, align 8
  %v1336 = load i64, ptr %slot78, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v1335, i64 %v1336) nomerge, !dbg !114
  br label %bb_rcslotdone82
bb_rcslotdone82:
  %v1337 = load i64, ptr %slot6, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i32, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1339, ptr %slot83, align 8
  %v1340 = load i32, ptr %slot83, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1343 = load i64, ptr %slot6, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i32 0, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot34, align 8
  store i64 %v1345, ptr %slot84, align 8
  %v1346 = load i64, ptr %slot7, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot85, align 8
  %v1349 = load i32, ptr %slot85, align 8
  %op1350 = and i32 %v1349, 28
  store i32 %op1350, ptr %slot86, align 8
  %v1351 = load i32, ptr %slot86, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1354 = load i64, ptr %slot55, align 8
  store i64 %v1354, ptr %slot87, align 8
  %v1355 = load i64, ptr %slot87, align 8
  %v1356 = load i64, ptr %slot84, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1355, i64 %v1356) nomerge, !dbg !114
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1357 = load i64, ptr %slot55, align 8
  store i64 %v1357, ptr %slot88, align 8
  %v1358 = load i64, ptr %slot88, align 8
  %v1359 = load i64, ptr %slot84, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1358, i64 %v1359) nomerge, !dbg !114
  br label %bb_rcslotdone128
bb_rcslotdone128:
  %v1360 = load i64, ptr %slot62, align 8
  ret i64 %v1360
bb_i6:
  %v1361 = load i64, ptr %slot28, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  %ld1363 = load i64, ptr %p1362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1363, ptr %slot89, align 8
  %v1364 = load i64, ptr %slot89, align 8
  %v1365 = load i64, ptr %slot44, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i64 %v1364, ptr %p1366, align 8, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot29, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %ld1369 = load i64, ptr %p1368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1369, ptr %slot90, align 8
  %v1370 = load i64, ptr %slot90, align 8
  %v1371 = load i64, ptr %slot45, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 %v1370, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot46, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i64 1, ptr %p1374, align 8, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot46, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot91, align 8
  %v1378 = load i64, ptr %slot45, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  %ld1380 = load i64, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1380, ptr %slot92, align 8
  %v1381 = load i64, ptr %slot92, align 8
  %v1382 = load i64, ptr %slot91, align 8
  %ovpair1384 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1381, i64 %v1382)
  %op1383 = extractvalue { i64, i1 } %ovpair1384, 0
  %ov1385 = extractvalue { i64, i1 } %ovpair1384, 1
  store i64 %op1383, ptr %slot93, align 8
  %cv1386 = zext i1 %ov1385 to i64
  store i64 %cv1386, ptr %slot94, align 8
  %v1387 = load i64, ptr %slot94, align 8
  %cond1388 = icmp ne i64 %v1387, 0
  br i1 %cond1388, label %bb_overflow222, label %bb_checked222
bb_overflow222:
  %v1389 = load i64, ptr %slot1, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %v1391 = load i64, ptr %slot92, align 8
  %v1392 = load i64, ptr %slot91, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1390, i64 1, i64 %v1391, i64 %v1392, i64 64) nomerge, !dbg !116
  unreachable
bb_checked222:
  %v1393 = load i64, ptr %slot93, align 8
  %v1394 = load i64, ptr %slot45, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i64 %v1393, ptr %p1395, align 8, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot30, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %ld1398 = load i64, ptr %p1397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1398, ptr %slot95, align 8
  %v1399 = load i64, ptr %slot95, align 8
  %v1400 = load i64, ptr %slot46, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i64 %v1399, ptr %p1401, align 8, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot44, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %ld1404 = load i64, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1404, ptr %slot96, align 8
  %v1405 = load i64, ptr %slot45, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot97, align 8
  %v1408 = load i64, ptr %slot46, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot98, align 8
  %v1411 = load i64, ptr %slot1, align 8
  %v1412 = load i64, ptr %slot96, align 8
  %v1413 = load i64, ptr %slot97, align 8
  %v1414 = load i64, ptr %slot98, align 8
  %call1415 = call i64 @myl_f_fb17c5f35998f28d890791c7c29c3b4d8861f8b82ea8c43160c8fd46bb1ae1af(i64 %v1411, i64 %v1412, i64 %v1413, i64 %v1414) nomerge, !dbg !118
  store i64 %call1415, ptr %slot99, align 8
  %v1416 = load i64, ptr %slot99, align 8
  %v1417 = load i64, ptr %slot44, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i64 %v1416, ptr %p1418, align 8, !alias.scope !3, !noalias !4
  %v1419 = load i64, ptr %slot12, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i32, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1421, ptr %slot100, align 8
  %v1422 = load i32, ptr %slot100, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcslotdrop231, label %bb_rcslotdone231
bb_rcslotdrop231:
  %v1425 = load i64, ptr %slot12, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i32 0, ptr %p1426, align 4, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot19, align 8
  store i64 %v1427, ptr %slot101, align 8
  %v1428 = load i64, ptr %slot13, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %ld1430 = load i32, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1430, ptr %slot102, align 8
  %v1431 = load i32, ptr %slot102, align 8
  %op1432 = and i32 %v1431, 28
  store i32 %op1432, ptr %slot103, align 8
  %v1433 = load i32, ptr %slot103, align 8
  %cv1434 = zext i32 %v1433 to i64
  %cond1435 = icmp ne i64 %cv1434, 0
  br i1 %cond1435, label %bb_rcslotrole231, label %bb_rcslotowner231
bb_rcslotrole231:
  %v1436 = load i64, ptr %slot55, align 8
  store i64 %v1436, ptr %slot104, align 8
  %v1437 = load i64, ptr %slot104, align 8
  %v1438 = load i64, ptr %slot101, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1437, i64 %v1438) nomerge, !dbg !118
  br label %bb_rcslotdone231
bb_rcslotowner231:
  %v1439 = load i64, ptr %slot55, align 8
  store i64 %v1439, ptr %slot105, align 8
  %v1440 = load i64, ptr %slot105, align 8
  %v1441 = load i64, ptr %slot101, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1440, i64 %v1441) nomerge, !dbg !118
  br label %bb_rcslotdone231
bb_rcslotdone231:
  %v1442 = load i64, ptr %slot44, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i64, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1444, ptr %slot106, align 8
  %v1445 = load i64, ptr %slot106, align 8
  %v1446 = load i64, ptr %slot31, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i64 %v1445, ptr %p1447, align 8, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot31, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  %ld1450 = load i64, ptr %p1449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1450, ptr %slot107, align 8
  %v1451 = load i64, ptr %slot107, align 8
  %v1452 = load i64, ptr %slot44, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i64 %v1451, ptr %p1453, align 8, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot45, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  store i64 18446744073709551615, ptr %p1455, align 8, !alias.scope !3, !noalias !4
  %v1456 = load i64, ptr %slot45, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %ld1458 = load i64, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1458, ptr %slot108, align 8
  %v1459 = load i64, ptr %slot44, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i64, ptr %p1460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1461, ptr %slot109, align 8
  %v1462 = load i64, ptr %slot109, align 8
  %v1463 = load i64, ptr %slot108, align 8
  %cmp1464 = icmp ne i64 %v1462, %v1463
  %cv1465 = zext i1 %cmp1464 to i64
  store i64 %cv1465, ptr %slot110, align 8
  %v1466 = load i64, ptr %slot110, align 8
  %v1467 = load i64, ptr %slot44, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  store i64 %v1466, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  %v1469 = load i64, ptr %slot44, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1471, ptr %slot111, align 8
  %v1472 = load i64, ptr %slot111, align 8
  %cond1473 = icmp ne i64 %v1472, 0
  br i1 %cond1473, label %bb_next281, label %bb_i98
bb_next281:
  %v1474 = load i64, ptr %slot28, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  %ld1476 = load i64, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1476, ptr %slot112, align 8
  %v1477 = load i64, ptr %slot112, align 8
  %v1478 = load i64, ptr %slot44, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  store i64 %v1477, ptr %p1479, align 8, !alias.scope !3, !noalias !4
  %v1480 = load i64, ptr %slot44, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  %ld1482 = load i64, ptr %p1481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1482, ptr %slot113, align 8
  %v1483 = load i64, ptr %slot113, align 8
  %op1484 = add i64 %v1483, 376
  store i64 %op1484, ptr %slot114, align 8
  %v1485 = load i64, ptr %slot114, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  %ld1487 = load i64, ptr %p1486, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1487, ptr %slot115, align 8
  %v1488 = load i64, ptr %slot115, align 8
  %v1489 = load i64, ptr %slot44, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i64 %v1488, ptr %p1490, align 8, !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot12, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i32, ptr %p1492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1493, ptr %slot116, align 8
  %v1494 = load i32, ptr %slot116, align 8
  %cv1495 = zext i32 %v1494 to i64
  %cond1496 = icmp ne i64 %cv1495, 0
  br i1 %cond1496, label %bb_rcslotdrop287, label %bb_rcslotdone287
bb_rcslotdrop287:
  %v1497 = load i64, ptr %slot12, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i32 0, ptr %p1498, align 4, !alias.scope !3, !noalias !4
  %v1499 = load i64, ptr %slot19, align 8
  store i64 %v1499, ptr %slot117, align 8
  %v1500 = load i64, ptr %slot13, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %ld1502 = load i32, ptr %p1501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1502, ptr %slot118, align 8
  %v1503 = load i32, ptr %slot118, align 8
  %op1504 = and i32 %v1503, 28
  store i32 %op1504, ptr %slot119, align 8
  %v1505 = load i32, ptr %slot119, align 8
  %cv1506 = zext i32 %v1505 to i64
  %cond1507 = icmp ne i64 %cv1506, 0
  br i1 %cond1507, label %bb_rcslotrole287, label %bb_rcslotowner287
bb_rcslotrole287:
  %v1508 = load i64, ptr %slot55, align 8
  store i64 %v1508, ptr %slot120, align 8
  %v1509 = load i64, ptr %slot120, align 8
  %v1510 = load i64, ptr %slot117, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1509, i64 %v1510) nomerge, !dbg !120
  br label %bb_rcslotdone287
bb_rcslotowner287:
  %v1511 = load i64, ptr %slot55, align 8
  store i64 %v1511, ptr %slot121, align 8
  %v1512 = load i64, ptr %slot121, align 8
  %v1513 = load i64, ptr %slot117, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1512, i64 %v1513) nomerge, !dbg !120
  br label %bb_rcslotdone287
bb_rcslotdone287:
  %v1514 = load i64, ptr %slot44, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %ld1516 = load i64, ptr %p1515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1516, ptr %slot122, align 8
  %v1517 = load i64, ptr %slot122, align 8
  %v1518 = load i64, ptr %slot32, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  store i64 %v1517, ptr %p1519, align 8, !alias.scope !3, !noalias !4
  %v1520 = load i64, ptr %slot29, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %ld1522 = load i64, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1522, ptr %slot123, align 8
  %v1523 = load i64, ptr %slot123, align 8
  %v1524 = load i64, ptr %slot44, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i64 %v1523, ptr %p1525, align 8, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot45, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  store i64 1, ptr %p1527, align 8, !alias.scope !3, !noalias !4
  %v1528 = load i64, ptr %slot45, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %ld1530 = load i64, ptr %p1529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1530, ptr %slot124, align 8
  %v1531 = load i64, ptr %slot44, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %ld1533 = load i64, ptr %p1532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1533, ptr %slot125, align 8
  %v1534 = load i64, ptr %slot125, align 8
  %v1535 = load i64, ptr %slot124, align 8
  %ovpair1537 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1534, i64 %v1535)
  %op1536 = extractvalue { i64, i1 } %ovpair1537, 0
  %ov1538 = extractvalue { i64, i1 } %ovpair1537, 1
  store i64 %op1536, ptr %slot126, align 8
  %cv1539 = zext i1 %ov1538 to i64
  store i64 %cv1539, ptr %slot127, align 8
  %v1540 = load i64, ptr %slot127, align 8
  %cond1541 = icmp ne i64 %v1540, 0
  br i1 %cond1541, label %bb_overflow298, label %bb_checked298
bb_overflow298:
  %v1542 = load i64, ptr %slot1, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %v1544 = load i64, ptr %slot125, align 8
  %v1545 = load i64, ptr %slot124, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1543, i64 1, i64 %v1544, i64 %v1545, i64 64) nomerge, !dbg !122
  unreachable
bb_checked298:
  %v1546 = load i64, ptr %slot126, align 8
  %v1547 = load i64, ptr %slot44, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i64 %v1546, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot44, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %ld1551 = load i64, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1551, ptr %slot128, align 8
  %v1552 = load i64, ptr %slot128, align 8
  %v1553 = load i64, ptr %slot33, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  store i64 %v1552, ptr %p1554, align 8, !alias.scope !3, !noalias !4
  %v1555 = load i64, ptr %slot33, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  %ld1557 = load i64, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1557, ptr %slot129, align 8
  %v1558 = load i64, ptr %slot129, align 8
  %v1559 = load i64, ptr %slot44, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i64 %v1558, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot45, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i64 0, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot45, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i64, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1565, ptr %slot130, align 8
  %v1566 = load i64, ptr %slot44, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  %ld1568 = load i64, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1568, ptr %slot131, align 8
  %v1569 = load i64, ptr %slot131, align 8
  %v1570 = load i64, ptr %slot130, align 8
  %cmp1571 = icmp slt i64 %v1569, %v1570
  %cv1572 = zext i1 %cmp1571 to i64
  store i64 %cv1572, ptr %slot132, align 8
  %v1573 = load i64, ptr %slot132, align 8
  %v1574 = load i64, ptr %slot44, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 %v1573, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot44, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %ld1578 = load i64, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1578, ptr %slot133, align 8
  %v1579 = load i64, ptr %slot133, align 8
  %cond1580 = icmp ne i64 %v1579, 0
  br i1 %cond1580, label %bb_next306, label %bb_i33
bb_next306:
  %v1581 = load i64, ptr %slot32, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  %ld1583 = load i64, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1583, ptr %slot134, align 8
  %v1584 = load i64, ptr %slot134, align 8
  %op1585 = add i64 %v1584, 0
  store i64 %op1585, ptr %slot135, align 8
  %v1586 = load i64, ptr %slot135, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i64, ptr %p1587, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1588, ptr %slot136, align 8
  %v1589 = load i64, ptr %slot136, align 8
  %v1590 = load i64, ptr %slot44, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i64 %v1589, ptr %p1591, align 8, !alias.scope !3, !noalias !4
  %v1592 = load i64, ptr %slot44, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %ld1594 = load i64, ptr %p1593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1594, ptr %slot137, align 8
  %v1595 = load i64, ptr %slot137, align 8
  %cmp1596 = icmp ugt i64 %v1595, 9223372036854775807
  %cv1597 = zext i1 %cmp1596 to i64
  store i64 %cv1597, ptr %slot138, align 8
  %v1598 = load i64, ptr %slot138, align 8
  %cond1599 = icmp ne i64 %v1598, 0
  br i1 %cond1599, label %bb_cast_overflow311, label %bb_cast_ok311
bb_cast_overflow311:
  %v1600 = load i64, ptr %slot1, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %v1602 = load i64, ptr %slot137, align 8
  call void @myl_qbe_fail_cast(ptr %p1601, i64 %v1602, i64 320) nomerge, !dbg !124
  unreachable
bb_cast_ok311:
  %v1603 = load i64, ptr %slot137, align 8
  %v1604 = load i64, ptr %slot44, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i64 %v1603, ptr %p1605, align 8, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot33, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i64, ptr %p1607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1608, ptr %slot139, align 8
  %v1609 = load i64, ptr %slot139, align 8
  %v1610 = load i64, ptr %slot45, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i64 %v1609, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot45, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  %ld1614 = load i64, ptr %p1613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1614, ptr %slot140, align 8
  %v1615 = load i64, ptr %slot44, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i64, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1617, ptr %slot141, align 8
  %v1618 = load i64, ptr %slot141, align 8
  %v1619 = load i64, ptr %slot140, align 8
  %ovpair1621 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1618, i64 %v1619)
  %op1620 = extractvalue { i64, i1 } %ovpair1621, 0
  %ov1622 = extractvalue { i64, i1 } %ovpair1621, 1
  store i64 %op1620, ptr %slot142, align 8
  %v1623 = load i64, ptr %slot141, align 8
  %v1624 = load i64, ptr %slot142, align 8
  %op1625 = xor i64 %v1623, %v1624
  store i64 %op1625, ptr %slot143, align 8
  %v1626 = load i64, ptr %slot140, align 8
  %v1627 = load i64, ptr %slot142, align 8
  %op1628 = xor i64 %v1626, %v1627
  store i64 %op1628, ptr %slot144, align 8
  %v1629 = load i64, ptr %slot143, align 8
  %v1630 = load i64, ptr %slot144, align 8
  %op1631 = and i64 %v1629, %v1630
  store i64 %op1631, ptr %slot145, align 8
  %cv1632 = zext i1 %ov1622 to i64
  store i64 %cv1632, ptr %slot146, align 8
  %v1633 = load i64, ptr %slot146, align 8
  %cond1634 = icmp ne i64 %v1633, 0
  br i1 %cond1634, label %bb_overflow315, label %bb_checked315
bb_overflow315:
  %v1635 = load i64, ptr %slot1, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %v1637 = load i64, ptr %slot141, align 8
  %v1638 = load i64, ptr %slot140, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1636, i64 0, i64 %v1637, i64 %v1638, i64 64) nomerge, !dbg !126
  unreachable
bb_checked315:
  %v1639 = load i64, ptr %slot142, align 8
  %v1640 = load i64, ptr %slot44, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i64 %v1639, ptr %p1641, align 8, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot44, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  %ld1644 = load i64, ptr %p1643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1644, ptr %slot147, align 8
  %v1645 = load i64, ptr %slot147, align 8
  %v1646 = load i64, ptr %slot33, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i64 %v1645, ptr %p1647, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i33:
  %v1648 = load i64, ptr %slot33, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  %ld1650 = load i64, ptr %p1649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1650, ptr %slot148, align 8
  %v1651 = load i64, ptr %slot148, align 8
  %v1652 = load i64, ptr %slot44, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  store i64 %v1651, ptr %p1653, align 8, !alias.scope !3, !noalias !4
  %v1654 = load i64, ptr %slot32, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i64, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1656, ptr %slot149, align 8
  %v1657 = load i64, ptr %slot44, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  %ld1659 = load i64, ptr %p1658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1659, ptr %slot150, align 8
  %v1660 = load i64, ptr %slot149, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i64, ptr %p1661, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1662, ptr %slot151, align 8
  %v1663 = load i64, ptr %slot150, align 8
  %v1664 = load i64, ptr %slot151, align 8
  %cmp1665 = icmp ult i64 %v1663, %v1664
  %cv1666 = zext i1 %cmp1665 to i64
  store i64 %cv1666, ptr %slot152, align 8
  %v1667 = load i64, ptr %slot152, align 8
  %cond1668 = icmp ne i64 %v1667, 0
  br i1 %cond1668, label %bb_success327, label %bb_failed327
bb_failed327:
  %v1669 = load i64, ptr %slot1, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  %v1671 = load i64, ptr %slot150, align 8
  %v1672 = load i64, ptr %slot151, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1670, i64 %v1671, i64 %v1672) nomerge, !dbg !128
  unreachable
bb_success327:
  %v1673 = load i64, ptr %slot149, align 8
  %op1674 = add i64 %v1673, 32
  store i64 %op1674, ptr %slot153, align 8
  %v1675 = load i64, ptr %slot153, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %ld1677 = load i64, ptr %p1676, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1677, ptr %slot154, align 8
  %v1678 = load i64, ptr %slot150, align 8
  %op1679 = mul i64 %v1678, 88
  store i64 %op1679, ptr %slot155, align 8
  %v1680 = load i64, ptr %slot154, align 8
  %v1681 = load i64, ptr %slot155, align 8
  %op1682 = add i64 %v1680, %v1681
  store i64 %op1682, ptr %slot156, align 8
  %v1683 = load i64, ptr %slot54, align 8
  store i64 %v1683, ptr %slot157, align 8
  %v1684 = load i64, ptr %slot156, align 8
  %v1685 = load i64, ptr %slot157, align 8
  %p1686 = inttoptr i64 %v1684 to ptr
  %p1687 = inttoptr i64 %v1685 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1687, ptr %p1686, i64 88, i1 false), !alias.scope !10000000
  %v1688 = load i64, ptr %slot157, align 8
  %v1689 = load i64, ptr %slot44, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i64 %v1688, ptr %p1690, align 8, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot44, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot158, align 8
  %v1694 = load i64, ptr %slot22, align 8
  store i64 %v1694, ptr %slot159, align 8
  %v1695 = load i64, ptr %slot55, align 8
  %v1696 = load i64, ptr %slot159, align 8
  %v1697 = load i64, ptr %slot158, align 8
  %call1698 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v1695, i64 %v1696, i64 %v1697) nomerge, !dbg !128
  store i32 %call1698, ptr %slot160, align 8
  %v1699 = load i32, ptr %slot160, align 8
  %cv1700 = zext i32 %v1699 to i64
  %cond1701 = icmp ne i64 %cv1700, 0
  br i1 %cond1701, label %bb_rcsuccess336, label %bb_rcfailure336
bb_rcfailure336:
  %v1702 = load i64, ptr %slot55, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %call1704 = call i32 @myl_rc_take_failure(ptr %p1703) nomerge, !dbg !128
  store i32 %call1704, ptr %slot161, align 8
  %v1705 = load i64, ptr %slot1, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %v1707 = load i32, ptr %slot161, align 8
  %call1708 = call i32 @myl_qbe_rc_status(ptr %p1706, i32 %v1707) nomerge, !dbg !128
  store i32 %call1708, ptr %slot162, align 8
  br label %bb_failure
bb_rcsuccess336:
  %v1709 = load i64, ptr %slot17, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i32 2, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot17, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 16, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot16, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 1, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot19, align 8
  store i64 %v1715, ptr %slot163, align 8
  %v1716 = load i64, ptr %slot22, align 8
  store i64 %v1716, ptr %slot164, align 8
  %v1717 = load i64, ptr %slot164, align 8
  %v1718 = load i64, ptr %slot163, align 8
  %p1719 = inttoptr i64 %v1717 to ptr
  %p1720 = inttoptr i64 %v1718 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1720, ptr %p1719, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot13, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i32 2, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot17, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  %ld1725 = load i32, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1725, ptr %slot165, align 8
  %v1726 = load i32, ptr %slot165, align 8
  %v1727 = load i64, ptr %slot13, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 %v1726, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot16, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i32 0, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot12, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 1, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot163, align 8
  %v1734 = load i64, ptr %slot44, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  store i64 %v1733, ptr %p1735, align 8, !alias.scope !3, !noalias !4
  %v1736 = load i64, ptr %slot44, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i64, ptr %p1737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1738, ptr %slot166, align 8
  %v1739 = load i64, ptr %slot12, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  %ld1741 = load i32, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1741, ptr %slot167, align 8
  %v1742 = load i64, ptr %slot13, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  %ld1744 = load i32, ptr %p1743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1744, ptr %slot168, align 8
  %v1745 = load i32, ptr %slot168, align 8
  %op1746 = and i32 %v1745, 24
  store i32 %op1746, ptr %slot168, align 8
  %v1747 = load i32, ptr %slot168, align 8
  %cmp1748 = icmp eq i32 %v1747, 0
  %cv1749 = zext i1 %cmp1748 to i32
  store i32 %cv1749, ptr %slot169, align 8
  %v1750 = load i32, ptr %slot167, align 8
  %v1751 = load i32, ptr %slot169, align 8
  %op1752 = and i32 %v1750, %v1751
  store i32 %op1752, ptr %slot170, align 8
  %v1753 = load i64, ptr %slot56, align 8
  store i64 %v1753, ptr %slot171, align 8
  %v1754 = load i32, ptr %slot170, align 8
  %op1755 = mul i32 %v1754, 4
  store i32 %op1755, ptr %slot172, align 8
  %v1756 = load i32, ptr %slot172, align 8
  %op1757 = or i32 %v1756, 0
  store i32 %op1757, ptr %slot173, align 8
  %v1758 = load i64, ptr %slot22, align 8
  store i64 %v1758, ptr %slot174, align 8
  %v1759 = load i64, ptr %slot55, align 8
  %v1760 = load i64, ptr %slot174, align 8
  %v1761 = load i64, ptr %slot166, align 8
  %v1762 = load i64, ptr %slot171, align 8
  %cv1763 = trunc i64 %v1762 to i32
  %v1764 = load i32, ptr %slot173, align 8
  %call1765 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v1759, i64 %v1760, i64 %v1761, i32 %cv1763, i32 %v1764) nomerge, !dbg !130
  store i32 %call1765, ptr %slot175, align 8
  %v1766 = load i32, ptr %slot175, align 8
  %cv1767 = zext i32 %v1766 to i64
  %cond1768 = icmp ne i64 %cv1767, 0
  br i1 %cond1768, label %bb_rcsuccess364, label %bb_rcfailure364
bb_rcfailure364:
  %v1769 = load i64, ptr %slot55, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %call1771 = call i32 @myl_rc_take_failure(ptr %p1770) nomerge, !dbg !130
  store i32 %call1771, ptr %slot176, align 8
  %v1772 = load i64, ptr %slot1, align 8
  %p1773 = inttoptr i64 %v1772 to ptr
  %v1774 = load i32, ptr %slot176, align 8
  %call1775 = call i32 @myl_qbe_rc_status(ptr %p1773, i32 %v1774) nomerge, !dbg !130
  store i32 %call1775, ptr %slot177, align 8
  br label %bb_failure
bb_rcsuccess364:
  %v1776 = load i32, ptr %slot170, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rchtaken367, label %bb_rchcopied367
bb_rchcopied367:
  %v1779 = load i64, ptr %slot12, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %ld1781 = load i32, ptr %p1780, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1781, ptr %slot178, align 8
  %v1782 = load i32, ptr %slot178, align 8
  %cv1783 = zext i32 %v1782 to i64
  %cond1784 = icmp ne i64 %cv1783, 0
  br i1 %cond1784, label %bb_rcslotdrop370, label %bb_rcslotdone370
bb_rcslotdrop370:
  %v1785 = load i64, ptr %slot12, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i32 0, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot19, align 8
  store i64 %v1787, ptr %slot179, align 8
  %v1788 = load i64, ptr %slot13, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  %ld1790 = load i32, ptr %p1789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1790, ptr %slot180, align 8
  %v1791 = load i32, ptr %slot180, align 8
  %op1792 = and i32 %v1791, 28
  store i32 %op1792, ptr %slot181, align 8
  %v1793 = load i32, ptr %slot181, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcslotrole370, label %bb_rcslotowner370
bb_rcslotrole370:
  %v1796 = load i64, ptr %slot55, align 8
  store i64 %v1796, ptr %slot182, align 8
  %v1797 = load i64, ptr %slot182, align 8
  %v1798 = load i64, ptr %slot179, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1797, i64 %v1798) nomerge, !dbg !130
  br label %bb_rcslotdone370
bb_rcslotowner370:
  %v1799 = load i64, ptr %slot55, align 8
  store i64 %v1799, ptr %slot183, align 8
  %v1800 = load i64, ptr %slot183, align 8
  %v1801 = load i64, ptr %slot179, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1800, i64 %v1801) nomerge, !dbg !130
  br label %bb_rcslotdone370
bb_rcslotdone370:
  br label %bb_rchprepared367
bb_rchtaken367:
  %v1802 = load i64, ptr %slot12, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  store i32 0, ptr %p1803, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared367
bb_rchprepared367:
  %v1804 = load i64, ptr %slot17, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  store i32 2, ptr %p1805, align 4, !alias.scope !3, !noalias !4
  %v1806 = load i64, ptr %slot16, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  store i32 1, ptr %p1807, align 4, !alias.scope !3, !noalias !4
  %v1808 = load i64, ptr %slot19, align 8
  store i64 %v1808, ptr %slot184, align 8
  %v1809 = load i64, ptr %slot22, align 8
  store i64 %v1809, ptr %slot185, align 8
  %v1810 = load i64, ptr %slot185, align 8
  %v1811 = load i64, ptr %slot184, align 8
  %p1812 = inttoptr i64 %v1810 to ptr
  %p1813 = inttoptr i64 %v1811 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1813, ptr %p1812, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1814 = load i64, ptr %slot13, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  store i32 2, ptr %p1815, align 4, !alias.scope !3, !noalias !4
  %v1816 = load i64, ptr %slot17, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %ld1818 = load i32, ptr %p1817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1818, ptr %slot186, align 8
  %v1819 = load i32, ptr %slot186, align 8
  %v1820 = load i64, ptr %slot13, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i32 %v1819, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot16, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  store i32 0, ptr %p1823, align 4, !alias.scope !3, !noalias !4
  %v1824 = load i64, ptr %slot12, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  store i32 1, ptr %p1825, align 4, !alias.scope !3, !noalias !4
  %v1826 = load i64, ptr %slot184, align 8
  %v1827 = load i64, ptr %slot44, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i64 %v1826, ptr %p1828, align 8, !alias.scope !3, !noalias !4
  %v1829 = load i64, ptr %slot44, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  %ld1831 = load i64, ptr %p1830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1831, ptr %slot187, align 8
  %v1832 = load i64, ptr %slot22, align 8
  store i64 %v1832, ptr %slot188, align 8
  %v1833 = load i64, ptr %slot56, align 8
  store i64 %v1833, ptr %slot189, align 8
  %v1834 = load i64, ptr %slot55, align 8
  %v1835 = load i64, ptr %slot188, align 8
  %v1836 = load i64, ptr %slot187, align 8
  %v1837 = load i64, ptr %slot189, align 8
  %cv1838 = trunc i64 %v1837 to i32
  %call1839 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v1834, i64 %v1835, i64 %v1836, i32 %cv1838) nomerge, !dbg !132
  store i32 %call1839, ptr %slot190, align 8
  %v1840 = load i32, ptr %slot190, align 8
  %cv1841 = zext i32 %v1840 to i64
  %cond1842 = icmp ne i64 %cv1841, 0
  br i1 %cond1842, label %bb_rcsuccess392, label %bb_rcfailure392
bb_rcfailure392:
  %v1843 = load i64, ptr %slot55, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %call1845 = call i32 @myl_rc_take_failure(ptr %p1844) nomerge, !dbg !132
  store i32 %call1845, ptr %slot191, align 8
  %v1846 = load i64, ptr %slot1, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %v1848 = load i32, ptr %slot191, align 8
  %call1849 = call i32 @myl_qbe_rc_status(ptr %p1847, i32 %v1848) nomerge, !dbg !132
  store i32 %call1849, ptr %slot192, align 8
  br label %bb_failure
bb_rcsuccess392:
  %v1850 = load i64, ptr %slot12, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i32 0, ptr %p1851, align 4, !alias.scope !3, !noalias !4
  %v1852 = load i64, ptr %slot17, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  store i32 2, ptr %p1853, align 4, !alias.scope !3, !noalias !4
  %v1854 = load i64, ptr %slot16, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  store i32 1, ptr %p1855, align 4, !alias.scope !3, !noalias !4
  %v1856 = load i64, ptr %slot6, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %ld1858 = load i32, ptr %p1857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1858, ptr %slot193, align 8
  %v1859 = load i32, ptr %slot193, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcslotdrop401, label %bb_rcslotdone401
bb_rcslotdrop401:
  %v1862 = load i64, ptr %slot6, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i32 0, ptr %p1863, align 4, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot34, align 8
  store i64 %v1864, ptr %slot194, align 8
  %v1865 = load i64, ptr %slot7, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  %ld1867 = load i32, ptr %p1866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1867, ptr %slot195, align 8
  %v1868 = load i32, ptr %slot195, align 8
  %op1869 = and i32 %v1868, 28
  store i32 %op1869, ptr %slot196, align 8
  %v1870 = load i32, ptr %slot196, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcslotrole401, label %bb_rcslotowner401
bb_rcslotrole401:
  %v1873 = load i64, ptr %slot55, align 8
  store i64 %v1873, ptr %slot197, align 8
  %v1874 = load i64, ptr %slot197, align 8
  %v1875 = load i64, ptr %slot194, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1874, i64 %v1875) nomerge, !dbg !132
  br label %bb_rcslotdone401
bb_rcslotowner401:
  %v1876 = load i64, ptr %slot55, align 8
  store i64 %v1876, ptr %slot198, align 8
  %v1877 = load i64, ptr %slot198, align 8
  %v1878 = load i64, ptr %slot194, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1877, i64 %v1878) nomerge, !dbg !132
  br label %bb_rcslotdone401
bb_rcslotdone401:
  %v1879 = load i64, ptr %slot34, align 8
  store i64 %v1879, ptr %slot199, align 8
  %v1880 = load i64, ptr %slot22, align 8
  store i64 %v1880, ptr %slot200, align 8
  %v1881 = load i64, ptr %slot200, align 8
  %v1882 = load i64, ptr %slot199, align 8
  %p1883 = inttoptr i64 %v1881 to ptr
  %p1884 = inttoptr i64 %v1882 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1884, ptr %p1883, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot16, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i32 0, ptr %p1886, align 4, !alias.scope !3, !noalias !4
  %v1887 = load i64, ptr %slot7, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i32 2, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot17, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  %ld1891 = load i32, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1891, ptr %slot201, align 8
  %v1892 = load i32, ptr %slot201, align 8
  %v1893 = load i64, ptr %slot7, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  store i32 %v1892, ptr %p1894, align 4, !alias.scope !3, !noalias !4
  %v1895 = load i64, ptr %slot6, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i32 1, ptr %p1896, align 4, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot44, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  store i64 1, ptr %p1898, align 8, !alias.scope !3, !noalias !4
  %v1899 = load i64, ptr %slot44, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  %ld1901 = load i64, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1901, ptr %slot202, align 8
  %v1902 = load i64, ptr %slot202, align 8
  %v1903 = load i64, ptr %slot39, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i64 %v1902, ptr %p1904, align 8, !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot34, align 8
  %v1906 = load i64, ptr %slot44, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i64 %v1905, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot44, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %ld1910 = load i64, ptr %p1909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1910, ptr %slot203, align 8
  %v1911 = load i64, ptr %slot203, align 8
  %op1912 = add i64 %v1911, 64
  store i64 %op1912, ptr %slot204, align 8
  %v1913 = load i64, ptr %slot204, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i64, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1915, ptr %slot205, align 8
  %v1916 = load i64, ptr %slot205, align 8
  %v1917 = load i64, ptr %slot44, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i64 %v1916, ptr %p1918, align 8, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot44, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1921, ptr %slot206, align 8
  %v1922 = load i64, ptr %slot206, align 8
  %v1923 = load i64, ptr %slot21, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i64 %v1922, ptr %p1924, align 8, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot21, align 8
  store i64 %v1925, ptr %slot207, align 8
  %v1926 = load i64, ptr %slot22, align 8
  store i64 %v1926, ptr %slot208, align 8
  %v1927 = load i64, ptr %slot207, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %ld1929 = load i64, ptr %p1928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1929, ptr %slot209, align 8
  %v1930 = load i64, ptr %slot209, align 8
  %cmp1931 = icmp ne i64 %v1930, 0
  %cv1932 = zext i1 %cmp1931 to i32
  store i32 %cv1932, ptr %slot210, align 8
  %v1933 = load i32, ptr %slot210, align 8
  %cv1934 = zext i32 %v1933 to i64
  %cond1935 = icmp ne i64 %cv1934, 0
  br i1 %cond1935, label %bb_rcgnn423, label %bb_rcgstore423
bb_rcgnn423:
  %v1936 = load i64, ptr %slot209, align 8
  %op1937 = sub i64 %v1936, 16
  store i64 %op1937, ptr %slot211, align 8
  %v1938 = load i64, ptr %slot209, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  %rgep1940 = getelementptr i8, ptr %p1939, i64 -16
  %ld1941 = load i64, ptr %rgep1940, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1941, ptr %slot212, align 8
  %v1942 = load i64, ptr %slot212, align 8
  %op1943 = and i64 %v1942, 4611686018427387906
  store i64 %op1943, ptr %slot213, align 8
  %v1944 = load i64, ptr %slot213, align 8
  %cmp1945 = icmp ne i64 %v1944, 0
  %cv1946 = zext i1 %cmp1945 to i32
  store i32 %cv1946, ptr %slot214, align 8
  %v1947 = load i32, ptr %slot214, align 8
  %cv1948 = zext i32 %v1947 to i64
  %cond1949 = icmp ne i64 %cv1948, 0
  br i1 %cond1949, label %bb_rcgstore423, label %bb_rcginc423
bb_rcginc423:
  %v1950 = load i64, ptr %slot209, align 8
  %op1951 = sub i64 %v1950, 24
  store i64 %op1951, ptr %slot215, align 8
  %v1952 = load i64, ptr %slot209, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  %rgep1954 = getelementptr i8, ptr %p1953, i64 -24
  %ld1955 = load i64, ptr %rgep1954, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1955, ptr %slot216, align 8
  %v1956 = load i64, ptr %slot216, align 8
  %op1957 = add i64 %v1956, 1
  store i64 %op1957, ptr %slot217, align 8
  %v1958 = load i64, ptr %slot217, align 8
  %cmp1959 = icmp eq i64 %v1958, 0
  %cv1960 = zext i1 %cmp1959 to i32
  store i32 %cv1960, ptr %slot218, align 8
  %v1961 = load i32, ptr %slot218, align 8
  %cv1962 = zext i32 %v1961 to i64
  %cond1963 = icmp ne i64 %cv1962, 0
  br i1 %cond1963, label %bb_rcglimit423, label %bb_rcgcapacity423
bb_rcglimit423:
  %v1964 = load i64, ptr %slot1, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %call1966 = call i32 @myl_qbe_rc_status(ptr %p1965, i32 2) nomerge, !dbg !134
  store i32 %call1966, ptr %slot219, align 8
  br label %bb_failure
bb_rcgcapacity423:
  %v1967 = load i64, ptr %slot217, align 8
  %v1968 = load i64, ptr %slot209, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  %rgep1970 = getelementptr i8, ptr %p1969, i64 -24
  store i64 %v1967, ptr %rgep1970, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore423
bb_rcgstore423:
  %v1971 = load i64, ptr %slot209, align 8
  %v1972 = load i64, ptr %slot208, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i64 %v1971, ptr %p1973, align 8, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot17, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i32 2, ptr %p1975, align 4, !alias.scope !3, !noalias !4
  %v1976 = load i64, ptr %slot17, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  store i32 16, ptr %p1977, align 4, !alias.scope !3, !noalias !4
  %v1978 = load i64, ptr %slot16, align 8
  %p1979 = inttoptr i64 %v1978 to ptr
  store i32 1, ptr %p1979, align 4, !alias.scope !3, !noalias !4
  %v1980 = load i64, ptr %slot12, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  %ld1982 = load i32, ptr %p1981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1982, ptr %slot220, align 8
  %v1983 = load i32, ptr %slot220, align 8
  %cv1984 = zext i32 %v1983 to i64
  %cond1985 = icmp ne i64 %cv1984, 0
  br i1 %cond1985, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v1986 = load i64, ptr %slot12, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  store i32 0, ptr %p1987, align 4, !alias.scope !3, !noalias !4
  %v1988 = load i64, ptr %slot19, align 8
  store i64 %v1988, ptr %slot221, align 8
  %v1989 = load i64, ptr %slot13, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  %ld1991 = load i32, ptr %p1990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1991, ptr %slot222, align 8
  %v1992 = load i32, ptr %slot222, align 8
  %op1993 = and i32 %v1992, 28
  store i32 %op1993, ptr %slot223, align 8
  %v1994 = load i32, ptr %slot223, align 8
  %cv1995 = zext i32 %v1994 to i64
  %cond1996 = icmp ne i64 %cv1995, 0
  br i1 %cond1996, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v1997 = load i64, ptr %slot55, align 8
  store i64 %v1997, ptr %slot224, align 8
  %v1998 = load i64, ptr %slot224, align 8
  %v1999 = load i64, ptr %slot221, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1998, i64 %v1999) nomerge, !dbg !134
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v2000 = load i64, ptr %slot55, align 8
  store i64 %v2000, ptr %slot225, align 8
  %v2001 = load i64, ptr %slot225, align 8
  %v2002 = load i64, ptr %slot221, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2001, i64 %v2002) nomerge, !dbg !134
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v2003 = load i64, ptr %slot19, align 8
  store i64 %v2003, ptr %slot226, align 8
  %v2004 = load i64, ptr %slot22, align 8
  store i64 %v2004, ptr %slot227, align 8
  %v2005 = load i64, ptr %slot227, align 8
  %v2006 = load i64, ptr %slot226, align 8
  %p2007 = inttoptr i64 %v2005 to ptr
  %p2008 = inttoptr i64 %v2006 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2008, ptr %p2007, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot13, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i32 2, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot17, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %ld2013 = load i32, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2013, ptr %slot228, align 8
  %v2014 = load i32, ptr %slot228, align 8
  %v2015 = load i64, ptr %slot13, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i32 %v2014, ptr %p2016, align 4, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot16, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i32 0, ptr %p2018, align 4, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot12, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i32 1, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  %v2021 = load i64, ptr %slot226, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i64, ptr %p2022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2023, ptr %slot229, align 8
  %v2024 = load i64, ptr %slot229, align 8
  %v2025 = load i64, ptr %slot44, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  store i64 %v2024, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  %v2027 = load i64, ptr %slot44, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %ld2029 = load i64, ptr %p2028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2029, ptr %slot230, align 8
  %v2030 = load i64, ptr %slot34, align 8
  store i64 %v2030, ptr %slot231, align 8
  %v2031 = load i64, ptr %slot12, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  %ld2033 = load i32, ptr %p2032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2033, ptr %slot232, align 8
  %v2034 = load i32, ptr %slot232, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcslotdrop460, label %bb_rcslotdone460
bb_rcslotdrop460:
  %v2037 = load i64, ptr %slot12, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  store i32 0, ptr %p2038, align 4, !alias.scope !3, !noalias !4
  %v2039 = load i64, ptr %slot19, align 8
  store i64 %v2039, ptr %slot233, align 8
  %v2040 = load i64, ptr %slot13, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %ld2042 = load i32, ptr %p2041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2042, ptr %slot234, align 8
  %v2043 = load i32, ptr %slot234, align 8
  %op2044 = and i32 %v2043, 28
  store i32 %op2044, ptr %slot235, align 8
  %v2045 = load i32, ptr %slot235, align 8
  %cv2046 = zext i32 %v2045 to i64
  %cond2047 = icmp ne i64 %cv2046, 0
  br i1 %cond2047, label %bb_rcslotrole460, label %bb_rcslotowner460
bb_rcslotrole460:
  %v2048 = load i64, ptr %slot55, align 8
  store i64 %v2048, ptr %slot236, align 8
  %v2049 = load i64, ptr %slot233, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  %ld2051 = load i64, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2051, ptr %slot237, align 8
  %v2052 = load i64, ptr %slot237, align 8
  %cmp2053 = icmp ne i64 %v2052, 0
  %cv2054 = zext i1 %cmp2053 to i32
  store i32 %cv2054, ptr %slot238, align 8
  %v2055 = load i32, ptr %slot238, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcgnn476, label %bb_rcgdone476
bb_rcgnn476:
  %v2058 = load i64, ptr %slot237, align 8
  %op2059 = sub i64 %v2058, 16
  store i64 %op2059, ptr %slot239, align 8
  %v2060 = load i64, ptr %slot237, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %rgep2062 = getelementptr i8, ptr %p2061, i64 -16
  %ld2063 = load i64, ptr %rgep2062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2063, ptr %slot240, align 8
  %v2064 = load i64, ptr %slot240, align 8
  %op2065 = and i64 %v2064, 4611686018427387906
  store i64 %op2065, ptr %slot241, align 8
  %v2066 = load i64, ptr %slot241, align 8
  %cmp2067 = icmp ne i64 %v2066, 0
  %cv2068 = zext i1 %cmp2067 to i32
  store i32 %cv2068, ptr %slot242, align 8
  %v2069 = load i32, ptr %slot242, align 8
  %cv2070 = zext i32 %v2069 to i64
  %cond2071 = icmp ne i64 %cv2070, 0
  br i1 %cond2071, label %bb_rcgclear476, label %bb_rcgcounted476
bb_rcgcounted476:
  %v2072 = load i64, ptr %slot237, align 8
  %op2073 = sub i64 %v2072, 24
  store i64 %op2073, ptr %slot243, align 8
  %v2074 = load i64, ptr %slot237, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %rgep2076 = getelementptr i8, ptr %p2075, i64 -24
  %ld2077 = load i64, ptr %rgep2076, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2077, ptr %slot244, align 8
  %v2078 = load i64, ptr %slot244, align 8
  %op2079 = sub i64 %v2078, 1
  store i64 %op2079, ptr %slot245, align 8
  %v2080 = load i64, ptr %slot245, align 8
  %cmp2081 = icmp eq i64 %v2080, 0
  %cv2082 = zext i1 %cmp2081 to i32
  store i32 %cv2082, ptr %slot246, align 8
  %v2083 = load i32, ptr %slot246, align 8
  %cv2084 = zext i32 %v2083 to i64
  %cond2085 = icmp ne i64 %cv2084, 0
  br i1 %cond2085, label %bb_rcglast476, label %bb_rcgdec476
bb_rcglast476:
  %v2086 = load i64, ptr %slot237, align 8
  %op2087 = sub i64 %v2086, 32
  store i64 %op2087, ptr %slot247, align 8
  %v2088 = load i64, ptr %slot237, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %rgep2090 = getelementptr i8, ptr %p2089, i64 -32
  %ld2091 = load i64, ptr %rgep2090, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2091, ptr %slot248, align 8
  %v2092 = load i64, ptr %slot248, align 8
  %cmp2093 = icmp ne i64 %v2092, 0
  %cv2094 = zext i1 %cmp2093 to i32
  store i32 %cv2094, ptr %slot249, align 8
  %v2095 = load i32, ptr %slot249, align 8
  %cv2096 = zext i32 %v2095 to i64
  %cond2097 = icmp ne i64 %cv2096, 0
  br i1 %cond2097, label %bb_rcgdec476, label %bb_rcgslow476
bb_rcgslow476:
  %v2098 = load i64, ptr %slot236, align 8
  %v2099 = load i64, ptr %slot233, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v2098, i64 %v2099) nomerge, !dbg !136
  br label %bb_rcgdone476
bb_rcgdec476:
  %v2100 = load i64, ptr %slot245, align 8
  %v2101 = load i64, ptr %slot237, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %rgep2103 = getelementptr i8, ptr %p2102, i64 -24
  store i64 %v2100, ptr %rgep2103, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear476
bb_rcgclear476:
  %v2104 = load i64, ptr %slot233, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i64 0, ptr %p2105, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone476
bb_rcgdone476:
  br label %bb_rcslotdone460
bb_rcslotowner460:
  %v2106 = load i64, ptr %slot55, align 8
  store i64 %v2106, ptr %slot250, align 8
  %v2107 = load i64, ptr %slot233, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i64, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2109, ptr %slot251, align 8
  %v2110 = load i64, ptr %slot251, align 8
  %cmp2111 = icmp ne i64 %v2110, 0
  %cv2112 = zext i1 %cmp2111 to i32
  store i32 %cv2112, ptr %slot252, align 8
  %v2113 = load i32, ptr %slot252, align 8
  %cv2114 = zext i32 %v2113 to i64
  %cond2115 = icmp ne i64 %cv2114, 0
  br i1 %cond2115, label %bb_rcgnn491, label %bb_rcgdone491
bb_rcgnn491:
  %v2116 = load i64, ptr %slot251, align 8
  %op2117 = sub i64 %v2116, 16
  store i64 %op2117, ptr %slot253, align 8
  %v2118 = load i64, ptr %slot251, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %rgep2120 = getelementptr i8, ptr %p2119, i64 -16
  %ld2121 = load i64, ptr %rgep2120, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2121, ptr %slot254, align 8
  %v2122 = load i64, ptr %slot254, align 8
  %op2123 = and i64 %v2122, 4611686018427387906
  store i64 %op2123, ptr %slot255, align 8
  %v2124 = load i64, ptr %slot255, align 8
  %cmp2125 = icmp ne i64 %v2124, 0
  %cv2126 = zext i1 %cmp2125 to i32
  store i32 %cv2126, ptr %slot256, align 8
  %v2127 = load i32, ptr %slot256, align 8
  %cv2128 = zext i32 %v2127 to i64
  %cond2129 = icmp ne i64 %cv2128, 0
  br i1 %cond2129, label %bb_rcgclear491, label %bb_rcgcounted491
bb_rcgcounted491:
  %v2130 = load i64, ptr %slot251, align 8
  %op2131 = sub i64 %v2130, 32
  store i64 %op2131, ptr %slot257, align 8
  %v2132 = load i64, ptr %slot251, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  %rgep2134 = getelementptr i8, ptr %p2133, i64 -32
  %ld2135 = load i64, ptr %rgep2134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2135, ptr %slot258, align 8
  %v2136 = load i64, ptr %slot258, align 8
  %op2137 = sub i64 %v2136, 1
  store i64 %op2137, ptr %slot259, align 8
  %v2138 = load i64, ptr %slot259, align 8
  %cmp2139 = icmp eq i64 %v2138, 0
  %cv2140 = zext i1 %cmp2139 to i32
  store i32 %cv2140, ptr %slot260, align 8
  %v2141 = load i32, ptr %slot260, align 8
  %cv2142 = zext i32 %v2141 to i64
  %cond2143 = icmp ne i64 %cv2142, 0
  br i1 %cond2143, label %bb_rcglast491, label %bb_rcgdec491
bb_rcglast491:
  %v2144 = load i64, ptr %slot251, align 8
  %op2145 = sub i64 %v2144, 24
  store i64 %op2145, ptr %slot261, align 8
  %v2146 = load i64, ptr %slot251, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  %rgep2148 = getelementptr i8, ptr %p2147, i64 -24
  %ld2149 = load i64, ptr %rgep2148, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2149, ptr %slot262, align 8
  %v2150 = load i64, ptr %slot262, align 8
  %cmp2151 = icmp ne i64 %v2150, 0
  %cv2152 = zext i1 %cmp2151 to i32
  store i32 %cv2152, ptr %slot263, align 8
  %v2153 = load i32, ptr %slot263, align 8
  %cv2154 = zext i32 %v2153 to i64
  %cond2155 = icmp ne i64 %cv2154, 0
  br i1 %cond2155, label %bb_rcgdec491, label %bb_rcgslow491
bb_rcgslow491:
  %v2156 = load i64, ptr %slot250, align 8
  %v2157 = load i64, ptr %slot233, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v2156, i64 %v2157) nomerge, !dbg !136
  br label %bb_rcgdone491
bb_rcgdec491:
  %v2158 = load i64, ptr %slot259, align 8
  %v2159 = load i64, ptr %slot251, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %rgep2161 = getelementptr i8, ptr %p2160, i64 -32
  store i64 %v2158, ptr %rgep2161, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear491
bb_rcgclear491:
  %v2162 = load i64, ptr %slot233, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i64 0, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone491
bb_rcgdone491:
  br label %bb_rcslotdone460
bb_rcslotdone460:
  %v2164 = load i64, ptr %slot231, align 8
  %p2166 = inttoptr i64 %v2164 to ptr
  %gep2167 = getelementptr i8, ptr %p2166, i64 64
  %op2165 = ptrtoint ptr %gep2167 to i64
  store i64 %op2165, ptr %slot264, align 8
  store i64 0, ptr %slot265, align 8
  %v2168 = load i64, ptr %slot264, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i64, ptr %p2169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2170, ptr %slot266, align 8
  %v2171 = load i64, ptr %slot266, align 8
  %cmp2172 = icmp ne i64 %v2171, 0
  %cv2173 = zext i1 %cmp2172 to i32
  store i32 %cv2173, ptr %slot267, align 8
  %v2174 = load i32, ptr %slot267, align 8
  %cv2175 = zext i32 %v2174 to i64
  %cond2176 = icmp ne i64 %cv2175, 0
  br i1 %cond2176, label %bb_rcguniquenn497, label %bb_rcgunique497
bb_rcguniquenn497:
  %v2177 = load i64, ptr %slot266, align 8
  %op2178 = sub i64 %v2177, 16
  store i64 %op2178, ptr %slot268, align 8
  %v2179 = load i64, ptr %slot266, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  %rgep2181 = getelementptr i8, ptr %p2180, i64 -16
  %ld2182 = load i64, ptr %rgep2181, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2182, ptr %slot269, align 8
  %v2183 = load i64, ptr %slot269, align 8
  %op2184 = and i64 %v2183, 6917529027641081858
  store i64 %op2184, ptr %slot270, align 8
  %v2185 = load i64, ptr %slot270, align 8
  %cmp2186 = icmp ne i64 %v2185, 0
  %cv2187 = zext i1 %cmp2186 to i32
  store i32 %cv2187, ptr %slot271, align 8
  %v2188 = load i32, ptr %slot271, align 8
  %cv2189 = zext i32 %v2188 to i64
  %cond2190 = icmp ne i64 %cv2189, 0
  br i1 %cond2190, label %bb_rcguniqueslow497, label %bb_rcguniquecount497
bb_rcguniquecount497:
  %v2191 = load i64, ptr %slot266, align 8
  %op2192 = sub i64 %v2191, 32
  store i64 %op2192, ptr %slot272, align 8
  %v2193 = load i64, ptr %slot266, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %rgep2195 = getelementptr i8, ptr %p2194, i64 -32
  %ld2196 = load i64, ptr %rgep2195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2196, ptr %slot273, align 8
  %v2197 = load i64, ptr %slot273, align 8
  %cmp2198 = icmp ult i64 %v2197, 2
  %cv2199 = zext i1 %cmp2198 to i32
  store i32 %cv2199, ptr %slot274, align 8
  %v2200 = load i32, ptr %slot274, align 8
  %cv2201 = zext i32 %v2200 to i64
  %cond2202 = icmp ne i64 %cv2201, 0
  br i1 %cond2202, label %bb_rcgunique497, label %bb_rcguniqueslow497
bb_rcguniqueslow497:
  %v2203 = load i64, ptr %slot1, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  %p2205 = inttoptr i64 ptrtoint (ptr @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f to i64) to ptr
  %v2206 = load i64, ptr %slot264, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  %v2208 = load i64, ptr %slot265, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %call2210 = call i32 @myl_qbe_rc_unique_field(ptr %p2204, ptr %p2205, ptr %p2207, ptr %p2209) nomerge, !dbg !136
  store i32 %call2210, ptr %slot275, align 8
  %v2211 = load i32, ptr %slot275, align 8
  %cv2212 = zext i32 %v2211 to i64
  %cond2213 = icmp ne i64 %cv2212, 0
  br i1 %cond2213, label %bb_rcunique507, label %bb_failure
bb_rcunique507:
  br label %bb_rcgunique497
bb_rcgunique497:
  %v2214 = load i64, ptr %slot264, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i64, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2216, ptr %slot276, align 8
  %v2217 = load i64, ptr %slot276, align 8
  %v2218 = load i64, ptr %slot44, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  store i64 %v2217, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  %v2220 = load i64, ptr %slot44, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %ld2222 = load i64, ptr %p2221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2222, ptr %slot277, align 8
  %v2223 = load i64, ptr %slot12, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %ld2225 = load i32, ptr %p2224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2225, ptr %slot278, align 8
  %v2226 = load i32, ptr %slot278, align 8
  %cv2227 = zext i32 %v2226 to i64
  %cond2228 = icmp ne i64 %cv2227, 0
  br i1 %cond2228, label %bb_rcslotdrop512, label %bb_rcslotdone512
bb_rcslotdrop512:
  %v2229 = load i64, ptr %slot12, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  store i32 0, ptr %p2230, align 4, !alias.scope !3, !noalias !4
  %v2231 = load i64, ptr %slot19, align 8
  store i64 %v2231, ptr %slot279, align 8
  %v2232 = load i64, ptr %slot13, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  %ld2234 = load i32, ptr %p2233, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2234, ptr %slot280, align 8
  %v2235 = load i32, ptr %slot280, align 8
  %op2236 = and i32 %v2235, 28
  store i32 %op2236, ptr %slot281, align 8
  %v2237 = load i32, ptr %slot281, align 8
  %cv2238 = zext i32 %v2237 to i64
  %cond2239 = icmp ne i64 %cv2238, 0
  br i1 %cond2239, label %bb_rcslotrole512, label %bb_rcslotowner512
bb_rcslotrole512:
  %v2240 = load i64, ptr %slot55, align 8
  store i64 %v2240, ptr %slot282, align 8
  %v2241 = load i64, ptr %slot279, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %ld2243 = load i64, ptr %p2242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2243, ptr %slot283, align 8
  %v2244 = load i64, ptr %slot283, align 8
  %cmp2245 = icmp ne i64 %v2244, 0
  %cv2246 = zext i1 %cmp2245 to i32
  store i32 %cv2246, ptr %slot284, align 8
  %v2247 = load i32, ptr %slot284, align 8
  %cv2248 = zext i32 %v2247 to i64
  %cond2249 = icmp ne i64 %cv2248, 0
  br i1 %cond2249, label %bb_rcgnn528, label %bb_rcgdone528
bb_rcgnn528:
  %v2250 = load i64, ptr %slot283, align 8
  %op2251 = sub i64 %v2250, 16
  store i64 %op2251, ptr %slot285, align 8
  %v2252 = load i64, ptr %slot283, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  %rgep2254 = getelementptr i8, ptr %p2253, i64 -16
  %ld2255 = load i64, ptr %rgep2254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2255, ptr %slot286, align 8
  %v2256 = load i64, ptr %slot286, align 8
  %op2257 = and i64 %v2256, 4611686018427387906
  store i64 %op2257, ptr %slot287, align 8
  %v2258 = load i64, ptr %slot287, align 8
  %cmp2259 = icmp ne i64 %v2258, 0
  %cv2260 = zext i1 %cmp2259 to i32
  store i32 %cv2260, ptr %slot288, align 8
  %v2261 = load i32, ptr %slot288, align 8
  %cv2262 = zext i32 %v2261 to i64
  %cond2263 = icmp ne i64 %cv2262, 0
  br i1 %cond2263, label %bb_rcgclear528, label %bb_rcgcounted528
bb_rcgcounted528:
  %v2264 = load i64, ptr %slot283, align 8
  %op2265 = sub i64 %v2264, 24
  store i64 %op2265, ptr %slot289, align 8
  %v2266 = load i64, ptr %slot283, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %rgep2268 = getelementptr i8, ptr %p2267, i64 -24
  %ld2269 = load i64, ptr %rgep2268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2269, ptr %slot290, align 8
  %v2270 = load i64, ptr %slot290, align 8
  %op2271 = sub i64 %v2270, 1
  store i64 %op2271, ptr %slot291, align 8
  %v2272 = load i64, ptr %slot291, align 8
  %cmp2273 = icmp eq i64 %v2272, 0
  %cv2274 = zext i1 %cmp2273 to i32
  store i32 %cv2274, ptr %slot292, align 8
  %v2275 = load i32, ptr %slot292, align 8
  %cv2276 = zext i32 %v2275 to i64
  %cond2277 = icmp ne i64 %cv2276, 0
  br i1 %cond2277, label %bb_rcglast528, label %bb_rcgdec528
bb_rcglast528:
  %v2278 = load i64, ptr %slot283, align 8
  %op2279 = sub i64 %v2278, 32
  store i64 %op2279, ptr %slot293, align 8
  %v2280 = load i64, ptr %slot283, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %rgep2282 = getelementptr i8, ptr %p2281, i64 -32
  %ld2283 = load i64, ptr %rgep2282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2283, ptr %slot294, align 8
  %v2284 = load i64, ptr %slot294, align 8
  %cmp2285 = icmp ne i64 %v2284, 0
  %cv2286 = zext i1 %cmp2285 to i32
  store i32 %cv2286, ptr %slot295, align 8
  %v2287 = load i32, ptr %slot295, align 8
  %cv2288 = zext i32 %v2287 to i64
  %cond2289 = icmp ne i64 %cv2288, 0
  br i1 %cond2289, label %bb_rcgdec528, label %bb_rcgslow528
bb_rcgslow528:
  %v2290 = load i64, ptr %slot282, align 8
  %v2291 = load i64, ptr %slot279, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v2290, i64 %v2291) nomerge, !dbg !136
  br label %bb_rcgdone528
bb_rcgdec528:
  %v2292 = load i64, ptr %slot291, align 8
  %v2293 = load i64, ptr %slot283, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  %rgep2295 = getelementptr i8, ptr %p2294, i64 -24
  store i64 %v2292, ptr %rgep2295, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear528
bb_rcgclear528:
  %v2296 = load i64, ptr %slot279, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i64 0, ptr %p2297, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone528
bb_rcgdone528:
  br label %bb_rcslotdone512
bb_rcslotowner512:
  %v2298 = load i64, ptr %slot55, align 8
  store i64 %v2298, ptr %slot296, align 8
  %v2299 = load i64, ptr %slot279, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i64, ptr %p2300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2301, ptr %slot297, align 8
  %v2302 = load i64, ptr %slot297, align 8
  %cmp2303 = icmp ne i64 %v2302, 0
  %cv2304 = zext i1 %cmp2303 to i32
  store i32 %cv2304, ptr %slot298, align 8
  %v2305 = load i32, ptr %slot298, align 8
  %cv2306 = zext i32 %v2305 to i64
  %cond2307 = icmp ne i64 %cv2306, 0
  br i1 %cond2307, label %bb_rcgnn543, label %bb_rcgdone543
bb_rcgnn543:
  %v2308 = load i64, ptr %slot297, align 8
  %op2309 = sub i64 %v2308, 16
  store i64 %op2309, ptr %slot299, align 8
  %v2310 = load i64, ptr %slot297, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  %rgep2312 = getelementptr i8, ptr %p2311, i64 -16
  %ld2313 = load i64, ptr %rgep2312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2313, ptr %slot300, align 8
  %v2314 = load i64, ptr %slot300, align 8
  %op2315 = and i64 %v2314, 4611686018427387906
  store i64 %op2315, ptr %slot301, align 8
  %v2316 = load i64, ptr %slot301, align 8
  %cmp2317 = icmp ne i64 %v2316, 0
  %cv2318 = zext i1 %cmp2317 to i32
  store i32 %cv2318, ptr %slot302, align 8
  %v2319 = load i32, ptr %slot302, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcgclear543, label %bb_rcgcounted543
bb_rcgcounted543:
  %v2322 = load i64, ptr %slot297, align 8
  %op2323 = sub i64 %v2322, 32
  store i64 %op2323, ptr %slot303, align 8
  %v2324 = load i64, ptr %slot297, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %rgep2326 = getelementptr i8, ptr %p2325, i64 -32
  %ld2327 = load i64, ptr %rgep2326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2327, ptr %slot304, align 8
  %v2328 = load i64, ptr %slot304, align 8
  %op2329 = sub i64 %v2328, 1
  store i64 %op2329, ptr %slot305, align 8
  %v2330 = load i64, ptr %slot305, align 8
  %cmp2331 = icmp eq i64 %v2330, 0
  %cv2332 = zext i1 %cmp2331 to i32
  store i32 %cv2332, ptr %slot306, align 8
  %v2333 = load i32, ptr %slot306, align 8
  %cv2334 = zext i32 %v2333 to i64
  %cond2335 = icmp ne i64 %cv2334, 0
  br i1 %cond2335, label %bb_rcglast543, label %bb_rcgdec543
bb_rcglast543:
  %v2336 = load i64, ptr %slot297, align 8
  %op2337 = sub i64 %v2336, 24
  store i64 %op2337, ptr %slot307, align 8
  %v2338 = load i64, ptr %slot297, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %rgep2340 = getelementptr i8, ptr %p2339, i64 -24
  %ld2341 = load i64, ptr %rgep2340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2341, ptr %slot308, align 8
  %v2342 = load i64, ptr %slot308, align 8
  %cmp2343 = icmp ne i64 %v2342, 0
  %cv2344 = zext i1 %cmp2343 to i32
  store i32 %cv2344, ptr %slot309, align 8
  %v2345 = load i32, ptr %slot309, align 8
  %cv2346 = zext i32 %v2345 to i64
  %cond2347 = icmp ne i64 %cv2346, 0
  br i1 %cond2347, label %bb_rcgdec543, label %bb_rcgslow543
bb_rcgslow543:
  %v2348 = load i64, ptr %slot296, align 8
  %v2349 = load i64, ptr %slot279, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v2348, i64 %v2349) nomerge, !dbg !136
  br label %bb_rcgdone543
bb_rcgdec543:
  %v2350 = load i64, ptr %slot305, align 8
  %v2351 = load i64, ptr %slot297, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %rgep2353 = getelementptr i8, ptr %p2352, i64 -32
  store i64 %v2350, ptr %rgep2353, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear543
bb_rcgclear543:
  %v2354 = load i64, ptr %slot279, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  store i64 0, ptr %p2355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone543
bb_rcgdone543:
  br label %bb_rcslotdone512
bb_rcslotdone512:
  %v2356 = load i64, ptr %slot23, align 8
  store i64 %v2356, ptr %slot310, align 8
  %v2357 = load i64, ptr %slot55, align 8
  %v2358 = load i64, ptr %slot310, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  store i64 %v2357, ptr %p2359, align 8, !alias.scope !3, !noalias !4
  %v2360 = load i64, ptr %slot55, align 8
  %p2362 = inttoptr i64 %v2360 to ptr
  %gep2363 = getelementptr i8, ptr %p2362, i64 5640
  %op2361 = ptrtoint ptr %gep2363 to i64
  store i64 %op2361, ptr %slot311, align 8
  %v2364 = load i64, ptr %slot311, align 8
  %p2365 = inttoptr i64 %v2364 to ptr
  %ld2366 = load i64, ptr %p2365, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2366, ptr %slot312, align 8
  %v2367 = load i64, ptr %slot312, align 8
  %op2368 = add i64 %v2367, 248
  store i64 %op2368, ptr %slot313, align 8
  %v2369 = load i64, ptr %slot313, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  %ld2371 = load i64, ptr %p2370, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2371, ptr %slot314, align 8
  %v2372 = load i64, ptr %slot310, align 8
  %p2374 = inttoptr i64 %v2372 to ptr
  %gep2375 = getelementptr i8, ptr %p2374, i64 8
  %op2373 = ptrtoint ptr %gep2375 to i64
  store i64 %op2373, ptr %slot315, align 8
  %v2376 = load i64, ptr %slot314, align 8
  %v2377 = load i64, ptr %slot315, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i64 %v2376, ptr %p2378, align 8, !alias.scope !3, !noalias !4
  %v2379 = load i64, ptr %slot310, align 8
  %p2381 = inttoptr i64 %v2379 to ptr
  %gep2382 = getelementptr i8, ptr %p2381, i64 16
  %op2380 = ptrtoint ptr %gep2382 to i64
  store i64 %op2380, ptr %slot316, align 8
  %v2383 = load i64, ptr %slot316, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  store i64 0, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  %v2385 = load i64, ptr %slot55, align 8
  %p2387 = inttoptr i64 %v2385 to ptr
  %gep2388 = getelementptr i8, ptr %p2387, i64 112
  %op2386 = ptrtoint ptr %gep2388 to i64
  store i64 %op2386, ptr %slot317, align 8
  %v2389 = load i64, ptr %slot310, align 8
  %p2391 = inttoptr i64 %v2389 to ptr
  %gep2392 = getelementptr i8, ptr %p2391, i64 24
  %op2390 = ptrtoint ptr %gep2392 to i64
  store i64 %op2390, ptr %slot318, align 8
  %v2393 = load i64, ptr %slot310, align 8
  %p2395 = inttoptr i64 %v2393 to ptr
  %gep2396 = getelementptr i8, ptr %p2395, i64 28
  %op2394 = ptrtoint ptr %gep2396 to i64
  store i64 %op2394, ptr %slot319, align 8
  %v2397 = load i64, ptr %slot317, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  %ld2399 = load i32, ptr %p2398, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld2399, ptr %slot320, align 8
  %v2400 = load i64, ptr %slot318, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i32 1, ptr %p2401, align 4, !alias.scope !3, !noalias !4
  %v2402 = load i32, ptr %slot320, align 8
  %v2403 = load i64, ptr %slot319, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i32 %v2402, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot310, align 8
  %v2406 = load i64, ptr %slot313, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  store i64 %v2405, ptr %p2407, align 8, !alias.scope !9999998, !noalias !9999999
  %v2408 = load i64, ptr %slot277, align 8
  %cmp2409 = icmp ne i64 %v2408, 0
  %cv2410 = zext i1 %cmp2409 to i32
  store i32 %cv2410, ptr %slot321, align 8
  %v2411 = load i32, ptr %slot321, align 8
  %cv2412 = zext i32 %v2411 to i64
  %cond2413 = icmp ne i64 %cv2412, 0
  br i1 %cond2413, label %bb_rcspinmark595, label %bb_rcspindone595
bb_rcspinmark595:
  %v2414 = load i64, ptr %slot277, align 8
  %op2415 = sub i64 %v2414, 16
  store i64 %op2415, ptr %slot322, align 8
  %v2416 = load i64, ptr %slot277, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %rgep2418 = getelementptr i8, ptr %p2417, i64 -16
  %ld2419 = load i64, ptr %rgep2418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2419, ptr %slot323, align 8
  %v2420 = load i64, ptr %slot323, align 8
  %op2421 = and i64 %v2420, 2
  store i64 %op2421, ptr %slot324, align 8
  %v2422 = load i64, ptr %slot324, align 8
  %cmp2423 = icmp ne i64 %v2422, 0
  %cv2424 = zext i1 %cmp2423 to i32
  store i32 %cv2424, ptr %slot325, align 8
  %v2425 = load i32, ptr %slot325, align 8
  %cv2426 = zext i32 %v2425 to i64
  %cond2427 = icmp ne i64 %cv2426, 0
  br i1 %cond2427, label %bb_rcspindone595, label %bb_rcspintype595
bb_rcspintype595:
  %v2428 = load i64, ptr %slot323, align 8
  %op2429 = and i64 %v2428, 4611686018427387907
  store i64 %op2429, ptr %slot326, align 8
  %v2430 = load i64, ptr %slot326, align 8
  %cmp2431 = icmp eq i64 %v2430, 0
  %cv2432 = zext i1 %cmp2431 to i32
  store i32 %cv2432, ptr %slot327, align 8
  %v2433 = load i32, ptr %slot327, align 8
  %cv2434 = zext i32 %v2433 to i64
  %cond2435 = icmp ne i64 %cv2434, 0
  br i1 %cond2435, label %bb_rcs603, label %bb_rcspinslow595
bb_rcs603:
  %v2436 = load i64, ptr %slot277, align 8
  %op2437 = sub i64 %v2436, 8
  store i64 %op2437, ptr %slot328, align 8
  %v2438 = load i64, ptr %slot277, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  %rgep2440 = getelementptr i8, ptr %p2439, i64 -8
  %ld2441 = load i64, ptr %rgep2440, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2441, ptr %slot329, align 8
  %p2442 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld2443 = load i64, ptr %p2442, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2443, ptr %slot330, align 8
  %v2444 = load i64, ptr %slot329, align 8
  %v2445 = load i64, ptr %slot330, align 8
  %cmp2446 = icmp eq i64 %v2444, %v2445
  %cv2447 = zext i1 %cmp2446 to i32
  store i32 %cv2447, ptr %slot331, align 8
  %v2448 = load i32, ptr %slot331, align 8
  %cv2449 = zext i32 %v2448 to i64
  %cond2450 = icmp ne i64 %cv2449, 0
  br i1 %cond2450, label %bb_rcs608, label %bb_rcspinslow595
bb_rcs608:
  %v2451 = load i64, ptr %slot55, align 8
  %p2453 = inttoptr i64 %v2451 to ptr
  %gep2454 = getelementptr i8, ptr %p2453, i64 5640
  %op2452 = ptrtoint ptr %gep2454 to i64
  store i64 %op2452, ptr %slot332, align 8
  %v2455 = load i64, ptr %slot332, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i64, ptr %p2456, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2457, ptr %slot333, align 8
  %v2458 = load i64, ptr %slot333, align 8
  %op2459 = add i64 %v2458, 256
  store i64 %op2459, ptr %slot334, align 8
  %v2460 = load i64, ptr %slot334, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %ld2462 = load i64, ptr %p2461, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2462, ptr %slot335, align 8
  %v2463 = load i64, ptr %slot335, align 8
  %cmp2464 = icmp ne i64 %v2463, 0
  %cv2465 = zext i1 %cmp2464 to i32
  store i32 %cv2465, ptr %slot336, align 8
  %v2466 = load i32, ptr %slot336, align 8
  %cv2467 = zext i32 %v2466 to i64
  %cond2468 = icmp ne i64 %cv2467, 0
  br i1 %cond2468, label %bb_rcs614, label %bb_rcspinslow595
bb_rcs614:
  %v2469 = load i64, ptr %slot55, align 8
  %p2471 = inttoptr i64 %v2469 to ptr
  %gep2472 = getelementptr i8, ptr %p2471, i64 24
  %op2470 = ptrtoint ptr %gep2472 to i64
  store i64 %op2470, ptr %slot337, align 8
  %v2473 = load i64, ptr %slot337, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %ld2475 = load i64, ptr %p2474, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2475, ptr %slot338, align 8
  %v2476 = load i64, ptr %slot338, align 8
  %op2477 = add i64 %v2476, 40
  store i64 %op2477, ptr %slot339, align 8
  %v2478 = load i64, ptr %slot339, align 8
  %v2479 = load i64, ptr %slot338, align 8
  %cmp2480 = icmp uge i64 %v2478, %v2479
  %cv2481 = zext i1 %cmp2480 to i32
  store i32 %cv2481, ptr %slot340, align 8
  %v2482 = load i32, ptr %slot340, align 8
  %cv2483 = zext i32 %v2482 to i64
  %cond2484 = icmp ne i64 %cv2483, 0
  br i1 %cond2484, label %bb_rcs619, label %bb_rcspinslow595
bb_rcs619:
  %v2485 = load i64, ptr %slot55, align 8
  %p2487 = inttoptr i64 %v2485 to ptr
  %gep2488 = getelementptr i8, ptr %p2487, i64 88
  %op2486 = ptrtoint ptr %gep2488 to i64
  store i64 %op2486, ptr %slot341, align 8
  %v2489 = load i64, ptr %slot341, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  %ld2491 = load i64, ptr %p2490, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2491, ptr %slot342, align 8
  %v2492 = load i64, ptr %slot342, align 8
  %cmp2493 = icmp eq i64 %v2492, 0
  %cv2494 = zext i1 %cmp2493 to i32
  store i32 %cv2494, ptr %slot343, align 8
  %v2495 = load i64, ptr %slot339, align 8
  %v2496 = load i64, ptr %slot342, align 8
  %cmp2497 = icmp ule i64 %v2495, %v2496
  %cv2498 = zext i1 %cmp2497 to i32
  store i32 %cv2498, ptr %slot344, align 8
  %v2499 = load i32, ptr %slot343, align 8
  %v2500 = load i32, ptr %slot344, align 8
  %op2501 = or i32 %v2499, %v2500
  store i32 %op2501, ptr %slot345, align 8
  %v2502 = load i32, ptr %slot345, align 8
  %cv2503 = zext i32 %v2502 to i64
  %cond2504 = icmp ne i64 %cv2503, 0
  br i1 %cond2504, label %bb_rcs625, label %bb_rcspinslow595
bb_rcs625:
  %v2505 = load i64, ptr %slot277, align 8
  %op2506 = sub i64 %v2505, 24
  store i64 %op2506, ptr %slot346, align 8
  %v2507 = load i64, ptr %slot277, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %rgep2509 = getelementptr i8, ptr %p2508, i64 -24
  %ld2510 = load i64, ptr %rgep2509, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2510, ptr %slot347, align 8
  %v2511 = load i64, ptr %slot347, align 8
  %cmp2512 = icmp ne i64 %v2511, 18446744073709551615
  %cv2513 = zext i1 %cmp2512 to i32
  store i32 %cv2513, ptr %slot348, align 8
  %v2514 = load i32, ptr %slot348, align 8
  %cv2515 = zext i32 %v2514 to i64
  %cond2516 = icmp ne i64 %cv2515, 0
  br i1 %cond2516, label %bb_rcs629, label %bb_rcspinslow595
bb_rcs629:
  %v2517 = load i64, ptr %slot277, align 8
  %op2518 = add i64 %v2517, 32
  store i64 %op2518, ptr %slot349, align 8
  %v2519 = load i64, ptr %slot349, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  %ld2521 = load i64, ptr %p2520, align 8
  store i64 %ld2521, ptr %slot350, align 8
  %v2522 = load i64, ptr %slot350, align 8
  %cmp2523 = icmp ne i64 %v2522, 0
  %cv2524 = zext i1 %cmp2523 to i32
  store i32 %cv2524, ptr %slot351, align 8
  %v2525 = load i32, ptr %slot351, align 8
  %cv2526 = zext i32 %v2525 to i64
  %cond2527 = icmp ne i64 %cv2526, 0
  br i1 %cond2527, label %bb_rcspinbacking595, label %bb_rcspincommit595
bb_rcspinbacking595:
  %v2528 = load i64, ptr %slot350, align 8
  %op2529 = sub i64 %v2528, 16
  store i64 %op2529, ptr %slot352, align 8
  %v2530 = load i64, ptr %slot350, align 8
  %p2531 = inttoptr i64 %v2530 to ptr
  %rgep2532 = getelementptr i8, ptr %p2531, i64 -16
  %ld2533 = load i64, ptr %rgep2532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2533, ptr %slot353, align 8
  %v2534 = load i64, ptr %slot353, align 8
  %op2535 = and i64 %v2534, 4611686018427387907
  store i64 %op2535, ptr %slot354, align 8
  %v2536 = load i64, ptr %slot354, align 8
  %cmp2537 = icmp eq i64 %v2536, 0
  %cv2538 = zext i1 %cmp2537 to i32
  store i32 %cv2538, ptr %slot355, align 8
  %v2539 = load i32, ptr %slot355, align 8
  %cv2540 = zext i32 %v2539 to i64
  %cond2541 = icmp ne i64 %cv2540, 0
  br i1 %cond2541, label %bb_rcs637, label %bb_rcspinslow595
bb_rcs637:
  %v2542 = load i64, ptr %slot350, align 8
  %op2543 = sub i64 %v2542, 24
  store i64 %op2543, ptr %slot356, align 8
  %v2544 = load i64, ptr %slot350, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  %rgep2546 = getelementptr i8, ptr %p2545, i64 -24
  %ld2547 = load i64, ptr %rgep2546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2547, ptr %slot357, align 8
  %v2548 = load i64, ptr %slot357, align 8
  %cmp2549 = icmp ne i64 %v2548, 18446744073709551615
  %cv2550 = zext i1 %cmp2549 to i32
  store i32 %cv2550, ptr %slot358, align 8
  %v2551 = load i32, ptr %slot358, align 8
  %cv2552 = zext i32 %v2551 to i64
  %cond2553 = icmp ne i64 %cv2552, 0
  br i1 %cond2553, label %bb_rcs641, label %bb_rcspinslow595
bb_rcs641:
  br label %bb_rcspincommit595
bb_rcspincommit595:
  %v2554 = load i64, ptr %slot335, align 8
  %p2555 = inttoptr i64 %v2554 to ptr
  %ld2556 = load i64, ptr %p2555, align 8
  store i64 %ld2556, ptr %slot359, align 8
  %v2557 = load i64, ptr %slot333, align 8
  %op2558 = add i64 %v2557, 256
  store i64 %op2558, ptr %slot360, align 8
  %v2559 = load i64, ptr %slot359, align 8
  %v2560 = load i64, ptr %slot360, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  store i64 %v2559, ptr %p2561, align 8, !alias.scope !9999998, !noalias !9999999
  %v2562 = load i64, ptr %slot333, align 8
  %op2563 = add i64 %v2562, 264
  store i64 %op2563, ptr %slot361, align 8
  %v2564 = load i64, ptr %slot361, align 8
  %p2565 = inttoptr i64 %v2564 to ptr
  %ld2566 = load i64, ptr %p2565, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2566, ptr %slot362, align 8
  %v2567 = load i64, ptr %slot362, align 8
  %op2568 = add i64 %v2567, 18446744073709551615
  store i64 %op2568, ptr %slot363, align 8
  %v2569 = load i64, ptr %slot363, align 8
  %v2570 = load i64, ptr %slot361, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  store i64 %v2569, ptr %p2571, align 8, !alias.scope !9999998, !noalias !9999999
  %v2572 = load i64, ptr %slot55, align 8
  %p2574 = inttoptr i64 %v2572 to ptr
  %gep2575 = getelementptr i8, ptr %p2574, i64 24
  %op2573 = ptrtoint ptr %gep2575 to i64
  store i64 %op2573, ptr %slot364, align 8
  %v2576 = load i64, ptr %slot364, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i64, ptr %p2577, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2578, ptr %slot365, align 8
  %v2579 = load i64, ptr %slot365, align 8
  %op2580 = add i64 %v2579, 40
  store i64 %op2580, ptr %slot366, align 8
  %v2581 = load i64, ptr %slot366, align 8
  %v2582 = load i64, ptr %slot364, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  store i64 %v2581, ptr %p2583, align 8, !alias.scope !9999998, !noalias !9999999
  %v2584 = load i64, ptr %slot333, align 8
  %op2585 = add i64 %v2584, 48
  store i64 %op2585, ptr %slot367, align 8
  %v2586 = load i64, ptr %slot367, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  %ld2588 = load i64, ptr %p2587, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld2588, ptr %slot368, align 8
  %v2589 = load i64, ptr %slot368, align 8
  %op2590 = add i64 %v2589, 40
  store i64 %op2590, ptr %slot369, align 8
  %v2591 = load i64, ptr %slot369, align 8
  %v2592 = load i64, ptr %slot367, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  store i64 %v2591, ptr %p2593, align 8, !alias.scope !9999998, !noalias !9999999
  %v2594 = load i64, ptr %slot277, align 8
  %op2595 = sub i64 %v2594, 24
  store i64 %op2595, ptr %slot370, align 8
  %v2596 = load i64, ptr %slot277, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  %rgep2598 = getelementptr i8, ptr %p2597, i64 -24
  %ld2599 = load i64, ptr %rgep2598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2599, ptr %slot371, align 8
  %v2600 = load i64, ptr %slot371, align 8
  %op2601 = add i64 %v2600, 1
  store i64 %op2601, ptr %slot372, align 8
  %v2602 = load i64, ptr %slot372, align 8
  %v2603 = load i64, ptr %slot277, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %rgep2605 = getelementptr i8, ptr %p2604, i64 -24
  store i64 %v2602, ptr %rgep2605, align 8, !alias.scope !9, !noalias !10
  %v2606 = load i64, ptr %slot350, align 8
  %cmp2607 = icmp ne i64 %v2606, 0
  %cv2608 = zext i1 %cmp2607 to i32
  store i32 %cv2608, ptr %slot373, align 8
  %v2609 = load i32, ptr %slot373, align 8
  %cv2610 = zext i32 %v2609 to i64
  %cond2611 = icmp ne i64 %cv2610, 0
  br i1 %cond2611, label %bb_rcspinhold595, label %bb_rcspinjournal595
bb_rcspinhold595:
  %v2612 = load i64, ptr %slot350, align 8
  %op2613 = sub i64 %v2612, 24
  store i64 %op2613, ptr %slot374, align 8
  %v2614 = load i64, ptr %slot350, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  %rgep2616 = getelementptr i8, ptr %p2615, i64 -24
  %ld2617 = load i64, ptr %rgep2616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2617, ptr %slot375, align 8
  %v2618 = load i64, ptr %slot375, align 8
  %op2619 = add i64 %v2618, 1
  store i64 %op2619, ptr %slot376, align 8
  %v2620 = load i64, ptr %slot376, align 8
  %v2621 = load i64, ptr %slot350, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %rgep2623 = getelementptr i8, ptr %p2622, i64 -24
  store i64 %v2620, ptr %rgep2623, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal595
bb_rcspinjournal595:
  %v2624 = load i64, ptr %slot323, align 8
  %op2625 = and i64 %v2624, 1152921504606846976
  store i64 %op2625, ptr %slot377, align 8
  %v2626 = load i64, ptr %slot323, align 8
  %op2627 = or i64 %v2626, 1152921504606846976
  store i64 %op2627, ptr %slot378, align 8
  %v2628 = load i64, ptr %slot277, align 8
  %op2629 = sub i64 %v2628, 16
  store i64 %op2629, ptr %slot379, align 8
  %v2630 = load i64, ptr %slot378, align 8
  %v2631 = load i64, ptr %slot277, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %rgep2633 = getelementptr i8, ptr %p2632, i64 -16
  store i64 %v2630, ptr %rgep2633, align 8, !alias.scope !9, !noalias !10
  %v2634 = load i64, ptr %slot310, align 8
  %p2636 = inttoptr i64 %v2634 to ptr
  %gep2637 = getelementptr i8, ptr %p2636, i64 16
  %op2635 = ptrtoint ptr %gep2637 to i64
  store i64 %op2635, ptr %slot380, align 8
  %v2638 = load i64, ptr %slot380, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %ld2640 = load i64, ptr %p2639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2640, ptr %slot381, align 8
  %v2641 = load i64, ptr %slot335, align 8
  %op2642 = add i64 %v2641, 0
  store i64 %op2642, ptr %slot382, align 8
  %v2643 = load i64, ptr %slot381, align 8
  %v2644 = load i64, ptr %slot382, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i64 %v2643, ptr %p2645, align 8, !alias.scope !9999998, !noalias !9999999
  %v2646 = load i64, ptr %slot335, align 8
  %op2647 = add i64 %v2646, 8
  store i64 %op2647, ptr %slot383, align 8
  %v2648 = load i64, ptr %slot277, align 8
  %v2649 = load i64, ptr %slot383, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  store i64 %v2648, ptr %p2650, align 8, !alias.scope !9999998, !noalias !9999999
  %v2651 = load i64, ptr %slot335, align 8
  %op2652 = add i64 %v2651, 16
  store i64 %op2652, ptr %slot384, align 8
  %v2653 = load i64, ptr %slot377, align 8
  %v2654 = load i64, ptr %slot384, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  store i64 %v2653, ptr %p2655, align 8, !alias.scope !9999998, !noalias !9999999
  %v2656 = load i64, ptr %slot335, align 8
  %op2657 = add i64 %v2656, 24
  store i64 %op2657, ptr %slot385, align 8
  %v2658 = load i64, ptr %slot385, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  store i32 1, ptr %p2659, align 4, !alias.scope !9999998, !noalias !9999999
  %v2660 = load i64, ptr %slot335, align 8
  %op2661 = add i64 %v2660, 32
  store i64 %op2661, ptr %slot386, align 8
  %v2662 = load i64, ptr %slot350, align 8
  %v2663 = load i64, ptr %slot386, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i64 %v2662, ptr %p2664, align 8, !alias.scope !9999998, !noalias !9999999
  %v2665 = load i64, ptr %slot310, align 8
  %p2667 = inttoptr i64 %v2665 to ptr
  %gep2668 = getelementptr i8, ptr %p2667, i64 16
  %op2666 = ptrtoint ptr %gep2668 to i64
  store i64 %op2666, ptr %slot387, align 8
  %v2669 = load i64, ptr %slot335, align 8
  %v2670 = load i64, ptr %slot387, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i64 %v2669, ptr %p2671, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone595
bb_rcspinslow595:
  %v2672 = load i64, ptr %slot1, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  %v2674 = load i64, ptr %slot310, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %v2676 = load i64, ptr %slot277, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  %call2678 = call i32 @myl_qbe_rc_scope_pin(ptr %p2673, ptr %p2675, ptr %p2677) nomerge, !dbg !136
  store i32 %call2678, ptr %slot388, align 8
  %v2679 = load i32, ptr %slot388, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcunique672, label %bb_failure
bb_rcunique672:
  br label %bb_rcspindone595
bb_rcspindone595:
  %v2682 = load i64, ptr %slot277, align 8
  %v2683 = load i64, ptr %slot35, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i64 %v2682, ptr %p2684, align 8, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot31, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i64, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2687, ptr %slot389, align 8
  %v2688 = load i64, ptr %slot389, align 8
  %v2689 = load i64, ptr %slot44, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 %v2688, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  %v2691 = load i64, ptr %slot44, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %ld2693 = load i64, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2693, ptr %slot390, align 8
  %v2694 = load i64, ptr %slot390, align 8
  %v2695 = load i64, ptr %slot37, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  store i64 %v2694, ptr %p2696, align 8, !alias.scope !3, !noalias !4
  %v2697 = load i64, ptr %slot37, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %ld2699 = load i64, ptr %p2698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2699, ptr %slot391, align 8
  %v2700 = load i64, ptr %slot391, align 8
  %v2701 = load i64, ptr %slot44, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i64 %v2700, ptr %p2702, align 8, !alias.scope !3, !noalias !4
  %v2703 = load i64, ptr %slot45, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  store i64 0, ptr %p2704, align 8, !alias.scope !3, !noalias !4
  %v2705 = load i64, ptr %slot45, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %ld2707 = load i64, ptr %p2706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2707, ptr %slot392, align 8
  %v2708 = load i64, ptr %slot44, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i64, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2710, ptr %slot393, align 8
  %v2711 = load i64, ptr %slot393, align 8
  %v2712 = load i64, ptr %slot392, align 8
  %cmp2713 = icmp slt i64 %v2711, %v2712
  %cv2714 = zext i1 %cmp2713 to i64
  store i64 %cv2714, ptr %slot394, align 8
  %v2715 = load i64, ptr %slot394, align 8
  %v2716 = load i64, ptr %slot44, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  store i64 %v2715, ptr %p2717, align 8, !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot44, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  %ld2720 = load i64, ptr %p2719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2720, ptr %slot395, align 8
  %v2721 = load i64, ptr %slot395, align 8
  %cond2722 = icmp ne i64 %v2721, 0
  br i1 %cond2722, label %bb_next680, label %bb_i53
bb_next680:
  %v2723 = load i64, ptr %slot35, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %ld2725 = load i64, ptr %p2724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2725, ptr %slot396, align 8
  %v2726 = load i64, ptr %slot396, align 8
  %op2727 = add i64 %v2726, 0
  store i64 %op2727, ptr %slot397, align 8
  %v2728 = load i64, ptr %slot397, align 8
  %p2729 = inttoptr i64 %v2728 to ptr
  %ld2730 = load i64, ptr %p2729, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2730, ptr %slot398, align 8
  %v2731 = load i64, ptr %slot398, align 8
  %v2732 = load i64, ptr %slot44, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  store i64 %v2731, ptr %p2733, align 8, !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot44, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  %ld2736 = load i64, ptr %p2735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2736, ptr %slot399, align 8
  %v2737 = load i64, ptr %slot399, align 8
  %cmp2738 = icmp ugt i64 %v2737, 9223372036854775807
  %cv2739 = zext i1 %cmp2738 to i64
  store i64 %cv2739, ptr %slot400, align 8
  %v2740 = load i64, ptr %slot400, align 8
  %cond2741 = icmp ne i64 %v2740, 0
  br i1 %cond2741, label %bb_cast_overflow685, label %bb_cast_ok685
bb_cast_overflow685:
  %v2742 = load i64, ptr %slot1, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %v2744 = load i64, ptr %slot399, align 8
  call void @myl_qbe_fail_cast(ptr %p2743, i64 %v2744, i64 320) nomerge, !dbg !138
  unreachable
bb_cast_ok685:
  %v2745 = load i64, ptr %slot399, align 8
  %v2746 = load i64, ptr %slot44, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  store i64 %v2745, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  %v2748 = load i64, ptr %slot37, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  %ld2750 = load i64, ptr %p2749, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2750, ptr %slot401, align 8
  %v2751 = load i64, ptr %slot401, align 8
  %v2752 = load i64, ptr %slot45, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  store i64 %v2751, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  %v2754 = load i64, ptr %slot45, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  %ld2756 = load i64, ptr %p2755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2756, ptr %slot402, align 8
  %v2757 = load i64, ptr %slot44, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %ld2759 = load i64, ptr %p2758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2759, ptr %slot403, align 8
  %v2760 = load i64, ptr %slot403, align 8
  %v2761 = load i64, ptr %slot402, align 8
  %ovpair2763 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2760, i64 %v2761)
  %op2762 = extractvalue { i64, i1 } %ovpair2763, 0
  %ov2764 = extractvalue { i64, i1 } %ovpair2763, 1
  store i64 %op2762, ptr %slot404, align 8
  %v2765 = load i64, ptr %slot403, align 8
  %v2766 = load i64, ptr %slot404, align 8
  %op2767 = xor i64 %v2765, %v2766
  store i64 %op2767, ptr %slot405, align 8
  %v2768 = load i64, ptr %slot402, align 8
  %v2769 = load i64, ptr %slot404, align 8
  %op2770 = xor i64 %v2768, %v2769
  store i64 %op2770, ptr %slot406, align 8
  %v2771 = load i64, ptr %slot405, align 8
  %v2772 = load i64, ptr %slot406, align 8
  %op2773 = and i64 %v2771, %v2772
  store i64 %op2773, ptr %slot407, align 8
  %cv2774 = zext i1 %ov2764 to i64
  store i64 %cv2774, ptr %slot408, align 8
  %v2775 = load i64, ptr %slot408, align 8
  %cond2776 = icmp ne i64 %v2775, 0
  br i1 %cond2776, label %bb_overflow689, label %bb_checked689
bb_overflow689:
  %v2777 = load i64, ptr %slot1, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %v2779 = load i64, ptr %slot403, align 8
  %v2780 = load i64, ptr %slot402, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2778, i64 0, i64 %v2779, i64 %v2780, i64 64) nomerge, !dbg !140
  unreachable
bb_checked689:
  %v2781 = load i64, ptr %slot404, align 8
  %v2782 = load i64, ptr %slot44, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i64 %v2781, ptr %p2783, align 8, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot44, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  %ld2786 = load i64, ptr %p2785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2786, ptr %slot409, align 8
  %v2787 = load i64, ptr %slot409, align 8
  %v2788 = load i64, ptr %slot37, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i64 %v2787, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  br label %bb_i53
bb_i53:
  %v2790 = load i64, ptr %slot37, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  %ld2792 = load i64, ptr %p2791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2792, ptr %slot410, align 8
  %v2793 = load i64, ptr %slot410, align 8
  %v2794 = load i64, ptr %slot44, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  store i64 %v2793, ptr %p2795, align 8, !alias.scope !3, !noalias !4
  %v2796 = load i64, ptr %slot44, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %ld2798 = load i64, ptr %p2797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2798, ptr %slot411, align 8
  %v2799 = load i64, ptr %slot411, align 8
  %v2800 = load i64, ptr %slot36, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  store i64 %v2799, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  %v2802 = load i64, ptr %slot36, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %ld2804 = load i64, ptr %p2803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2804, ptr %slot412, align 8
  %v2805 = load i64, ptr %slot412, align 8
  %v2806 = load i64, ptr %slot44, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i64 %v2805, ptr %p2807, align 8, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot35, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %ld2810 = load i64, ptr %p2809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2810, ptr %slot413, align 8
  %v2811 = load i64, ptr %slot44, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %ld2813 = load i64, ptr %p2812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2813, ptr %slot414, align 8
  %v2814 = load i64, ptr %slot413, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i64, ptr %p2815, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2816, ptr %slot415, align 8
  %v2817 = load i64, ptr %slot414, align 8
  %v2818 = load i64, ptr %slot415, align 8
  %cmp2819 = icmp ult i64 %v2817, %v2818
  %cv2820 = zext i1 %cmp2819 to i64
  store i64 %cv2820, ptr %slot416, align 8
  %v2821 = load i64, ptr %slot416, align 8
  %cond2822 = icmp ne i64 %v2821, 0
  br i1 %cond2822, label %bb_success703, label %bb_failed703
bb_failed703:
  %v2823 = load i64, ptr %slot1, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  %v2825 = load i64, ptr %slot414, align 8
  %v2826 = load i64, ptr %slot415, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2824, i64 %v2825, i64 %v2826) nomerge, !dbg !142
  unreachable
bb_success703:
  %v2827 = load i64, ptr %slot413, align 8
  %op2828 = add i64 %v2827, 32
  store i64 %op2828, ptr %slot417, align 8
  %v2829 = load i64, ptr %slot417, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  %ld2831 = load i64, ptr %p2830, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2831, ptr %slot418, align 8
  %v2832 = load i64, ptr %slot414, align 8
  %op2833 = mul i64 %v2832, 24
  store i64 %op2833, ptr %slot419, align 8
  %v2834 = load i64, ptr %slot418, align 8
  %v2835 = load i64, ptr %slot419, align 8
  %op2836 = add i64 %v2834, %v2835
  store i64 %op2836, ptr %slot420, align 8
  %v2837 = load i64, ptr %slot420, align 8
  %v2838 = load i64, ptr %slot44, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i64 %v2837, ptr %p2839, align 8, !alias.scope !3, !noalias !4
  %v2840 = load i64, ptr %slot44, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %ld2842 = load i64, ptr %p2841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2842, ptr %slot421, align 8
  %v2843 = load i64, ptr %slot22, align 8
  store i64 %v2843, ptr %slot422, align 8
  %v2844 = load i64, ptr %slot55, align 8
  %v2845 = load i64, ptr %slot422, align 8
  %v2846 = load i64, ptr %slot421, align 8
  %call2847 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64 %v2844, i64 %v2845, i64 %v2846) nomerge, !dbg !142
  store i32 %call2847, ptr %slot423, align 8
  %v2848 = load i32, ptr %slot423, align 8
  %cv2849 = zext i32 %v2848 to i64
  %cond2850 = icmp ne i64 %cv2849, 0
  br i1 %cond2850, label %bb_rcsuccess711, label %bb_rcfailure711
bb_rcfailure711:
  %v2851 = load i64, ptr %slot55, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  %call2853 = call i32 @myl_rc_take_failure(ptr %p2852) nomerge, !dbg !142
  store i32 %call2853, ptr %slot424, align 8
  %v2854 = load i64, ptr %slot1, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  %v2856 = load i32, ptr %slot424, align 8
  %call2857 = call i32 @myl_qbe_rc_status(ptr %p2855, i32 %v2856) nomerge, !dbg !142
  store i32 %call2857, ptr %slot425, align 8
  br label %bb_failure
bb_rcsuccess711:
  %v2858 = load i64, ptr %slot17, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i32 2, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot17, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  store i32 16, ptr %p2861, align 4, !alias.scope !3, !noalias !4
  %v2862 = load i64, ptr %slot16, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i32 1, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot19, align 8
  store i64 %v2864, ptr %slot426, align 8
  %v2865 = load i64, ptr %slot22, align 8
  store i64 %v2865, ptr %slot427, align 8
  %v2866 = load i64, ptr %slot427, align 8
  %v2867 = load i64, ptr %slot426, align 8
  %p2868 = inttoptr i64 %v2866 to ptr
  %p2869 = inttoptr i64 %v2867 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2869, ptr %p2868, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2870 = load i64, ptr %slot13, align 8
  %p2871 = inttoptr i64 %v2870 to ptr
  store i32 2, ptr %p2871, align 4, !alias.scope !3, !noalias !4
  %v2872 = load i64, ptr %slot17, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %ld2874 = load i32, ptr %p2873, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2874, ptr %slot428, align 8
  %v2875 = load i32, ptr %slot428, align 8
  %v2876 = load i64, ptr %slot13, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  store i32 %v2875, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  %v2878 = load i64, ptr %slot16, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  store i32 0, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  %v2880 = load i64, ptr %slot12, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  store i32 1, ptr %p2881, align 4, !alias.scope !3, !noalias !4
  %v2882 = load i64, ptr %slot426, align 8
  %v2883 = load i64, ptr %slot44, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i64 %v2882, ptr %p2884, align 8, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot44, align 8
  %p2886 = inttoptr i64 %v2885 to ptr
  %ld2887 = load i64, ptr %p2886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2887, ptr %slot429, align 8
  %v2888 = load i64, ptr %slot12, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  %ld2890 = load i32, ptr %p2889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2890, ptr %slot430, align 8
  %v2891 = load i64, ptr %slot13, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %ld2893 = load i32, ptr %p2892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2893, ptr %slot431, align 8
  %v2894 = load i32, ptr %slot431, align 8
  %op2895 = and i32 %v2894, 24
  store i32 %op2895, ptr %slot431, align 8
  %v2896 = load i32, ptr %slot431, align 8
  %cmp2897 = icmp eq i32 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot432, align 8
  %v2899 = load i32, ptr %slot430, align 8
  %v2900 = load i32, ptr %slot432, align 8
  %op2901 = and i32 %v2899, %v2900
  store i32 %op2901, ptr %slot433, align 8
  %v2902 = load i32, ptr %slot433, align 8
  %cv2903 = zext i32 %v2902 to i64
  %cond2904 = icmp ne i64 %cv2903, 0
  br i1 %cond2904, label %bb_rcprivateown732, label %bb_rcprivateloan732
bb_rcprivateown732:
  %v2905 = load i64, ptr %slot22, align 8
  store i64 %v2905, ptr %slot434, align 8
  %v2906 = load i64, ptr %slot56, align 8
  store i64 %v2906, ptr %slot435, align 8
  %v2907 = load i64, ptr %slot429, align 8
  %v2908 = load i64, ptr %slot434, align 8
  %op2909 = sub i64 %v2907, %v2908
  store i64 %op2909, ptr %slot436, align 8
  %v2910 = load i64, ptr %slot434, align 8
  %v2911 = load i64, ptr %slot429, align 8
  %op2912 = sub i64 %v2910, %v2911
  store i64 %op2912, ptr %slot437, align 8
  %v2913 = load i64, ptr %slot436, align 8
  %cmp2914 = icmp ult i64 %v2913, 24
  %cv2915 = zext i1 %cmp2914 to i32
  store i32 %cv2915, ptr %slot438, align 8
  %v2916 = load i64, ptr %slot437, align 8
  %cmp2917 = icmp ult i64 %v2916, 24
  %cv2918 = zext i1 %cmp2917 to i32
  store i32 %cv2918, ptr %slot439, align 8
  %v2919 = load i32, ptr %slot438, align 8
  %v2920 = load i32, ptr %slot439, align 8
  %op2921 = or i32 %v2919, %v2920
  store i32 %op2921, ptr %slot440, align 8
  %v2922 = load i32, ptr %slot440, align 8
  %cv2923 = zext i32 %v2922 to i64
  %cond2924 = icmp ne i64 %cv2923, 0
  br i1 %cond2924, label %bb_rcmoveslow735, label %bb_rcmovecheck735
bb_rcmovecheck735:
  %v2925 = load i64, ptr %slot429, align 8
  %op2926 = add i64 %v2925, 0
  store i64 %op2926, ptr %slot441, align 8
  %v2927 = load i64, ptr %slot441, align 8
  %p2928 = inttoptr i64 %v2927 to ptr
  %ld2929 = load i64, ptr %p2928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2929, ptr %slot442, align 8
  %v2930 = load i64, ptr %slot442, align 8
  %cmp2931 = icmp ne i64 %v2930, 0
  %cv2932 = zext i1 %cmp2931 to i32
  store i32 %cv2932, ptr %slot443, align 8
  %v2933 = load i32, ptr %slot443, align 8
  %cv2934 = zext i32 %v2933 to i64
  %cond2935 = icmp ne i64 %cv2934, 0
  br i1 %cond2935, label %bb_rcmoveheader743, label %bb_rcmovenext743
bb_rcmoveheader743:
  %v2936 = load i64, ptr %slot442, align 8
  %op2937 = sub i64 %v2936, 16
  store i64 %op2937, ptr %slot444, align 8
  %v2938 = load i64, ptr %slot442, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %rgep2940 = getelementptr i8, ptr %p2939, i64 -16
  %ld2941 = load i64, ptr %rgep2940, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2941, ptr %slot445, align 8
  %v2942 = load i64, ptr %slot445, align 8
  %op2943 = and i64 %v2942, 5764607523034234881
  store i64 %op2943, ptr %slot446, align 8
  %v2944 = load i64, ptr %slot446, align 8
  %cmp2945 = icmp ne i64 %v2944, 0
  %cv2946 = zext i1 %cmp2945 to i32
  store i32 %cv2946, ptr %slot447, align 8
  %v2947 = load i32, ptr %slot447, align 8
  %cv2948 = zext i32 %v2947 to i64
  %cond2949 = icmp ne i64 %cv2948, 0
  br i1 %cond2949, label %bb_rcmoveslow735, label %bb_rcmovenext743
bb_rcmovenext743:
  %v2950 = load i64, ptr %slot429, align 8
  %v2951 = load i64, ptr %slot434, align 8
  %p2952 = inttoptr i64 %v2950 to ptr
  %p2953 = inttoptr i64 %v2951 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2953, ptr %p2952, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2954 = load i64, ptr %slot429, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  store i64 0, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  %v2956 = load i64, ptr %slot429, align 8
  %op2957 = add i64 %v2956, 8
  store i64 %op2957, ptr %slot448, align 8
  %v2958 = load i64, ptr %slot448, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  store i64 0, ptr %p2959, align 8, !alias.scope !3, !noalias !4
  %v2960 = load i64, ptr %slot429, align 8
  %op2961 = add i64 %v2960, 16
  store i64 %op2961, ptr %slot449, align 8
  %v2962 = load i64, ptr %slot449, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  store i64 0, ptr %p2963, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved735
bb_rcmoveslow735:
  %v2964 = load i64, ptr %slot55, align 8
  %v2965 = load i64, ptr %slot434, align 8
  %v2966 = load i64, ptr %slot429, align 8
  %v2967 = load i64, ptr %slot435, align 8
  %cv2968 = trunc i64 %v2967 to i32
  %call2969 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64 %v2964, i64 %v2965, i64 %v2966, i32 %cv2968) nomerge, !dbg !144
  store i32 %call2969, ptr %slot450, align 8
  %v2970 = load i32, ptr %slot450, align 8
  %cv2971 = zext i32 %v2970 to i64
  %cond2972 = icmp ne i64 %cv2971, 0
  br i1 %cond2972, label %bb_rcsuccess752, label %bb_rcfailure752
bb_rcfailure752:
  %v2973 = load i64, ptr %slot55, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  %call2975 = call i32 @myl_rc_take_failure(ptr %p2974) nomerge, !dbg !144
  store i32 %call2975, ptr %slot451, align 8
  %v2976 = load i64, ptr %slot1, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %v2978 = load i32, ptr %slot451, align 8
  %call2979 = call i32 @myl_qbe_rc_status(ptr %p2977, i32 %v2978) nomerge, !dbg !144
  store i32 %call2979, ptr %slot452, align 8
  br label %bb_failure
bb_rcsuccess752:
  br label %bb_rcmoved735
bb_rcmoved735:
  %v2980 = load i64, ptr %slot12, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  store i32 0, ptr %p2981, align 4, !alias.scope !3, !noalias !4
  %v2982 = load i64, ptr %slot17, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i32 2, ptr %p2983, align 4, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot16, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i32 1, ptr %p2985, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared732
bb_rcprivateloan732:
  %v2986 = load i64, ptr %slot12, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ld2988 = load i32, ptr %p2987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2988, ptr %slot453, align 8
  %v2989 = load i64, ptr %slot13, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  %ld2991 = load i32, ptr %p2990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2991, ptr %slot454, align 8
  %v2992 = load i32, ptr %slot454, align 8
  %cmp2993 = icmp eq i32 %v2992, 16
  %cv2994 = zext i1 %cmp2993 to i32
  store i32 %cv2994, ptr %slot455, align 8
  %v2995 = load i32, ptr %slot455, align 8
  %v2996 = load i32, ptr %slot453, align 8
  %op2997 = and i32 %v2995, %v2996
  store i32 %op2997, ptr %slot455, align 8
  %v2998 = load i32, ptr %slot455, align 8
  %cv2999 = zext i32 %v2998 to i64
  %cond3000 = icmp ne i64 %cv2999, 0
  br i1 %cond3000, label %bb_rcprivatemove732, label %bb_rcprivatenew732
bb_rcprivatemove732:
  %v3001 = load i64, ptr %slot22, align 8
  store i64 %v3001, ptr %slot456, align 8
  %v3002 = load i64, ptr %slot429, align 8
  %v3003 = load i64, ptr %slot456, align 8
  %p3004 = inttoptr i64 %v3002 to ptr
  %p3005 = inttoptr i64 %v3003 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3005, ptr %p3004, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot429, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  call void @llvm.memset.p0.i64(ptr %p3007, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !144
  %v3008 = load i64, ptr %slot17, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i32 2, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot17, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i32 16, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot16, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i32 1, ptr %p3013, align 4, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot12, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  store i32 0, ptr %p3015, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared732
bb_rcprivatenew732:
  %v3016 = load i64, ptr %slot22, align 8
  store i64 %v3016, ptr %slot457, align 8
  %v3017 = load i64, ptr %slot55, align 8
  %v3018 = load i64, ptr %slot457, align 8
  %v3019 = load i64, ptr %slot429, align 8
  %call3020 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64 %v3017, i64 %v3018, i64 %v3019) nomerge, !dbg !144
  store i32 %call3020, ptr %slot458, align 8
  %v3021 = load i32, ptr %slot458, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcsuccess770, label %bb_rcfailure770
bb_rcfailure770:
  %v3024 = load i64, ptr %slot55, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  %call3026 = call i32 @myl_rc_take_failure(ptr %p3025) nomerge, !dbg !144
  store i32 %call3026, ptr %slot459, align 8
  %v3027 = load i64, ptr %slot1, align 8
  %p3028 = inttoptr i64 %v3027 to ptr
  %v3029 = load i32, ptr %slot459, align 8
  %call3030 = call i32 @myl_qbe_rc_status(ptr %p3028, i32 %v3029) nomerge, !dbg !144
  store i32 %call3030, ptr %slot460, align 8
  br label %bb_failure
bb_rcsuccess770:
  %v3031 = load i64, ptr %slot17, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  store i32 2, ptr %p3032, align 4, !alias.scope !3, !noalias !4
  %v3033 = load i64, ptr %slot17, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  store i32 16, ptr %p3034, align 4, !alias.scope !3, !noalias !4
  %v3035 = load i64, ptr %slot16, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  store i32 1, ptr %p3036, align 4, !alias.scope !3, !noalias !4
  %v3037 = load i64, ptr %slot12, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  %ld3039 = load i32, ptr %p3038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3039, ptr %slot461, align 8
  %v3040 = load i32, ptr %slot461, align 8
  %cv3041 = zext i32 %v3040 to i64
  %cond3042 = icmp ne i64 %cv3041, 0
  br i1 %cond3042, label %bb_rcslotdrop778, label %bb_rcslotdone778
bb_rcslotdrop778:
  %v3043 = load i64, ptr %slot12, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  store i32 0, ptr %p3044, align 4, !alias.scope !3, !noalias !4
  %v3045 = load i64, ptr %slot19, align 8
  store i64 %v3045, ptr %slot462, align 8
  %v3046 = load i64, ptr %slot13, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  %ld3048 = load i32, ptr %p3047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3048, ptr %slot463, align 8
  %v3049 = load i32, ptr %slot463, align 8
  %op3050 = and i32 %v3049, 28
  store i32 %op3050, ptr %slot464, align 8
  %v3051 = load i32, ptr %slot464, align 8
  %cv3052 = zext i32 %v3051 to i64
  %cond3053 = icmp ne i64 %cv3052, 0
  br i1 %cond3053, label %bb_rcslotrole778, label %bb_rcslotowner778
bb_rcslotrole778:
  %v3054 = load i64, ptr %slot55, align 8
  store i64 %v3054, ptr %slot465, align 8
  %v3055 = load i64, ptr %slot465, align 8
  %v3056 = load i64, ptr %slot462, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3055, i64 %v3056) nomerge, !dbg !144
  br label %bb_rcslotdone778
bb_rcslotowner778:
  %v3057 = load i64, ptr %slot462, align 8
  %p3059 = inttoptr i64 %v3057 to ptr
  %gep3060 = getelementptr i8, ptr %p3059, i64 0
  %op3058 = ptrtoint ptr %gep3060 to i64
  store i64 %op3058, ptr %slot466, align 8
  %v3061 = load i64, ptr %slot55, align 8
  store i64 %v3061, ptr %slot467, align 8
  %v3062 = load i64, ptr %slot466, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %ld3064 = load i64, ptr %p3063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3064, ptr %slot468, align 8
  %v3065 = load i64, ptr %slot468, align 8
  %cmp3066 = icmp ne i64 %v3065, 0
  %cv3067 = zext i1 %cmp3066 to i32
  store i32 %cv3067, ptr %slot469, align 8
  %v3068 = load i32, ptr %slot469, align 8
  %cv3069 = zext i32 %v3068 to i64
  %cond3070 = icmp ne i64 %cv3069, 0
  br i1 %cond3070, label %bb_rcgnn796, label %bb_rcgdone796
bb_rcgnn796:
  %v3071 = load i64, ptr %slot468, align 8
  %op3072 = sub i64 %v3071, 16
  store i64 %op3072, ptr %slot470, align 8
  %v3073 = load i64, ptr %slot468, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  %rgep3075 = getelementptr i8, ptr %p3074, i64 -16
  %ld3076 = load i64, ptr %rgep3075, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3076, ptr %slot471, align 8
  %v3077 = load i64, ptr %slot471, align 8
  %op3078 = and i64 %v3077, 4611686018427387906
  store i64 %op3078, ptr %slot472, align 8
  %v3079 = load i64, ptr %slot472, align 8
  %cmp3080 = icmp ne i64 %v3079, 0
  %cv3081 = zext i1 %cmp3080 to i32
  store i32 %cv3081, ptr %slot473, align 8
  %v3082 = load i32, ptr %slot473, align 8
  %cv3083 = zext i32 %v3082 to i64
  %cond3084 = icmp ne i64 %cv3083, 0
  br i1 %cond3084, label %bb_rcgclear796, label %bb_rcgcounted796
bb_rcgcounted796:
  %v3085 = load i64, ptr %slot468, align 8
  %op3086 = sub i64 %v3085, 32
  store i64 %op3086, ptr %slot474, align 8
  %v3087 = load i64, ptr %slot468, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %rgep3089 = getelementptr i8, ptr %p3088, i64 -32
  %ld3090 = load i64, ptr %rgep3089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3090, ptr %slot475, align 8
  %v3091 = load i64, ptr %slot475, align 8
  %op3092 = sub i64 %v3091, 1
  store i64 %op3092, ptr %slot476, align 8
  %v3093 = load i64, ptr %slot476, align 8
  %cmp3094 = icmp eq i64 %v3093, 0
  %cv3095 = zext i1 %cmp3094 to i32
  store i32 %cv3095, ptr %slot477, align 8
  %v3096 = load i32, ptr %slot477, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcglast796, label %bb_rcgdec796
bb_rcglast796:
  %v3099 = load i64, ptr %slot468, align 8
  %op3100 = sub i64 %v3099, 24
  store i64 %op3100, ptr %slot478, align 8
  %v3101 = load i64, ptr %slot468, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %rgep3103 = getelementptr i8, ptr %p3102, i64 -24
  %ld3104 = load i64, ptr %rgep3103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3104, ptr %slot479, align 8
  %v3105 = load i64, ptr %slot479, align 8
  %cmp3106 = icmp ne i64 %v3105, 0
  %cv3107 = zext i1 %cmp3106 to i32
  store i32 %cv3107, ptr %slot480, align 8
  %v3108 = load i32, ptr %slot480, align 8
  %cv3109 = zext i32 %v3108 to i64
  %cond3110 = icmp ne i64 %cv3109, 0
  br i1 %cond3110, label %bb_rcgdec796, label %bb_rcgslow796
bb_rcgslow796:
  %v3111 = load i64, ptr %slot467, align 8
  %v3112 = load i64, ptr %slot466, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3111, i64 %v3112) nomerge, !dbg !144
  br label %bb_rcgdone796
bb_rcgdec796:
  %v3113 = load i64, ptr %slot476, align 8
  %v3114 = load i64, ptr %slot468, align 8
  %p3115 = inttoptr i64 %v3114 to ptr
  %rgep3116 = getelementptr i8, ptr %p3115, i64 -32
  store i64 %v3113, ptr %rgep3116, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear796
bb_rcgclear796:
  %v3117 = load i64, ptr %slot466, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i64 0, ptr %p3118, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone796
bb_rcgdone796:
  %v3119 = load i64, ptr %slot462, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  store i64 0, ptr %p3120, align 8, !alias.scope !3, !noalias !4
  %v3121 = load i64, ptr %slot462, align 8
  %p3123 = inttoptr i64 %v3121 to ptr
  %gep3124 = getelementptr i8, ptr %p3123, i64 8
  %op3122 = ptrtoint ptr %gep3124 to i64
  store i64 %op3122, ptr %slot481, align 8
  %v3125 = load i64, ptr %slot481, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  store i64 0, ptr %p3126, align 8, !alias.scope !3, !noalias !4
  %v3127 = load i64, ptr %slot462, align 8
  %p3129 = inttoptr i64 %v3127 to ptr
  %gep3130 = getelementptr i8, ptr %p3129, i64 16
  %op3128 = ptrtoint ptr %gep3130 to i64
  store i64 %op3128, ptr %slot482, align 8
  %v3131 = load i64, ptr %slot482, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i64 0, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone778
bb_rcslotdone778:
  br label %bb_rcprivateprepared732
bb_rcprivateprepared732:
  %v3133 = load i64, ptr %slot8, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  %ld3135 = load i32, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3135, ptr %slot483, align 8
  %v3136 = load i32, ptr %slot483, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcslotdrop805, label %bb_rcslotdone805
bb_rcslotdrop805:
  %v3139 = load i64, ptr %slot8, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  store i32 0, ptr %p3140, align 4, !alias.scope !3, !noalias !4
  %v3141 = load i64, ptr %slot38, align 8
  store i64 %v3141, ptr %slot484, align 8
  %v3142 = load i64, ptr %slot9, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot485, align 8
  %v3145 = load i32, ptr %slot485, align 8
  %op3146 = and i32 %v3145, 28
  store i32 %op3146, ptr %slot486, align 8
  %v3147 = load i32, ptr %slot486, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_rcslotrole805, label %bb_rcslotowner805
bb_rcslotrole805:
  %v3150 = load i64, ptr %slot55, align 8
  store i64 %v3150, ptr %slot487, align 8
  %v3151 = load i64, ptr %slot487, align 8
  %v3152 = load i64, ptr %slot484, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3151, i64 %v3152) nomerge, !dbg !144
  br label %bb_rcslotdone805
bb_rcslotowner805:
  %v3153 = load i64, ptr %slot484, align 8
  %p3155 = inttoptr i64 %v3153 to ptr
  %gep3156 = getelementptr i8, ptr %p3155, i64 0
  %op3154 = ptrtoint ptr %gep3156 to i64
  store i64 %op3154, ptr %slot488, align 8
  %v3157 = load i64, ptr %slot55, align 8
  store i64 %v3157, ptr %slot489, align 8
  %v3158 = load i64, ptr %slot488, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %ld3160 = load i64, ptr %p3159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3160, ptr %slot490, align 8
  %v3161 = load i64, ptr %slot490, align 8
  %cmp3162 = icmp ne i64 %v3161, 0
  %cv3163 = zext i1 %cmp3162 to i32
  store i32 %cv3163, ptr %slot491, align 8
  %v3164 = load i32, ptr %slot491, align 8
  %cv3165 = zext i32 %v3164 to i64
  %cond3166 = icmp ne i64 %cv3165, 0
  br i1 %cond3166, label %bb_rcgnn823, label %bb_rcgdone823
bb_rcgnn823:
  %v3167 = load i64, ptr %slot490, align 8
  %op3168 = sub i64 %v3167, 16
  store i64 %op3168, ptr %slot492, align 8
  %v3169 = load i64, ptr %slot490, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %rgep3171 = getelementptr i8, ptr %p3170, i64 -16
  %ld3172 = load i64, ptr %rgep3171, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3172, ptr %slot493, align 8
  %v3173 = load i64, ptr %slot493, align 8
  %op3174 = and i64 %v3173, 4611686018427387906
  store i64 %op3174, ptr %slot494, align 8
  %v3175 = load i64, ptr %slot494, align 8
  %cmp3176 = icmp ne i64 %v3175, 0
  %cv3177 = zext i1 %cmp3176 to i32
  store i32 %cv3177, ptr %slot495, align 8
  %v3178 = load i32, ptr %slot495, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcgclear823, label %bb_rcgcounted823
bb_rcgcounted823:
  %v3181 = load i64, ptr %slot490, align 8
  %op3182 = sub i64 %v3181, 32
  store i64 %op3182, ptr %slot496, align 8
  %v3183 = load i64, ptr %slot490, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %rgep3185 = getelementptr i8, ptr %p3184, i64 -32
  %ld3186 = load i64, ptr %rgep3185, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3186, ptr %slot497, align 8
  %v3187 = load i64, ptr %slot497, align 8
  %op3188 = sub i64 %v3187, 1
  store i64 %op3188, ptr %slot498, align 8
  %v3189 = load i64, ptr %slot498, align 8
  %cmp3190 = icmp eq i64 %v3189, 0
  %cv3191 = zext i1 %cmp3190 to i32
  store i32 %cv3191, ptr %slot499, align 8
  %v3192 = load i32, ptr %slot499, align 8
  %cv3193 = zext i32 %v3192 to i64
  %cond3194 = icmp ne i64 %cv3193, 0
  br i1 %cond3194, label %bb_rcglast823, label %bb_rcgdec823
bb_rcglast823:
  %v3195 = load i64, ptr %slot490, align 8
  %op3196 = sub i64 %v3195, 24
  store i64 %op3196, ptr %slot500, align 8
  %v3197 = load i64, ptr %slot490, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %rgep3199 = getelementptr i8, ptr %p3198, i64 -24
  %ld3200 = load i64, ptr %rgep3199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3200, ptr %slot501, align 8
  %v3201 = load i64, ptr %slot501, align 8
  %cmp3202 = icmp ne i64 %v3201, 0
  %cv3203 = zext i1 %cmp3202 to i32
  store i32 %cv3203, ptr %slot502, align 8
  %v3204 = load i32, ptr %slot502, align 8
  %cv3205 = zext i32 %v3204 to i64
  %cond3206 = icmp ne i64 %cv3205, 0
  br i1 %cond3206, label %bb_rcgdec823, label %bb_rcgslow823
bb_rcgslow823:
  %v3207 = load i64, ptr %slot489, align 8
  %v3208 = load i64, ptr %slot488, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3207, i64 %v3208) nomerge, !dbg !144
  br label %bb_rcgdone823
bb_rcgdec823:
  %v3209 = load i64, ptr %slot498, align 8
  %v3210 = load i64, ptr %slot490, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  %rgep3212 = getelementptr i8, ptr %p3211, i64 -32
  store i64 %v3209, ptr %rgep3212, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear823
bb_rcgclear823:
  %v3213 = load i64, ptr %slot488, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i64 0, ptr %p3214, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone823
bb_rcgdone823:
  %v3215 = load i64, ptr %slot484, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  store i64 0, ptr %p3216, align 8, !alias.scope !3, !noalias !4
  %v3217 = load i64, ptr %slot484, align 8
  %p3219 = inttoptr i64 %v3217 to ptr
  %gep3220 = getelementptr i8, ptr %p3219, i64 8
  %op3218 = ptrtoint ptr %gep3220 to i64
  store i64 %op3218, ptr %slot503, align 8
  %v3221 = load i64, ptr %slot503, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 0, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot484, align 8
  %p3225 = inttoptr i64 %v3223 to ptr
  %gep3226 = getelementptr i8, ptr %p3225, i64 16
  %op3224 = ptrtoint ptr %gep3226 to i64
  store i64 %op3224, ptr %slot504, align 8
  %v3227 = load i64, ptr %slot504, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  store i64 0, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone805
bb_rcslotdone805:
  %v3229 = load i64, ptr %slot38, align 8
  store i64 %v3229, ptr %slot505, align 8
  %v3230 = load i64, ptr %slot22, align 8
  store i64 %v3230, ptr %slot506, align 8
  %v3231 = load i64, ptr %slot506, align 8
  %v3232 = load i64, ptr %slot505, align 8
  %p3233 = inttoptr i64 %v3231 to ptr
  %p3234 = inttoptr i64 %v3232 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3234, ptr %p3233, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3235 = load i64, ptr %slot16, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  store i32 0, ptr %p3236, align 4, !alias.scope !3, !noalias !4
  %v3237 = load i64, ptr %slot9, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  store i32 2, ptr %p3238, align 4, !alias.scope !3, !noalias !4
  %v3239 = load i64, ptr %slot17, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %ld3241 = load i32, ptr %p3240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3241, ptr %slot507, align 8
  %v3242 = load i32, ptr %slot507, align 8
  %v3243 = load i64, ptr %slot9, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i32 %v3242, ptr %p3244, align 4, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot8, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i32 1, ptr %p3246, align 4, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot36, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  %ld3249 = load i64, ptr %p3248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3249, ptr %slot508, align 8
  %v3250 = load i64, ptr %slot508, align 8
  %v3251 = load i64, ptr %slot44, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  store i64 %v3250, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  %v3253 = load i64, ptr %slot35, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %ld3255 = load i64, ptr %p3254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3255, ptr %slot509, align 8
  %v3256 = load i64, ptr %slot44, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  %ld3258 = load i64, ptr %p3257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3258, ptr %slot510, align 8
  %v3259 = load i64, ptr %slot509, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  %ld3261 = load i64, ptr %p3260, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3261, ptr %slot511, align 8
  %v3262 = load i64, ptr %slot510, align 8
  %v3263 = load i64, ptr %slot511, align 8
  %cmp3264 = icmp ult i64 %v3262, %v3263
  %cv3265 = zext i1 %cmp3264 to i64
  store i64 %cv3265, ptr %slot512, align 8
  %v3266 = load i64, ptr %slot512, align 8
  %cond3267 = icmp ne i64 %v3266, 0
  br i1 %cond3267, label %bb_success842, label %bb_failed842
bb_failed842:
  %v3268 = load i64, ptr %slot1, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %v3270 = load i64, ptr %slot510, align 8
  %v3271 = load i64, ptr %slot511, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3269, i64 %v3270, i64 %v3271) nomerge, !dbg !146
  unreachable
bb_success842:
  %v3272 = load i64, ptr %slot509, align 8
  %op3273 = add i64 %v3272, 32
  store i64 %op3273, ptr %slot513, align 8
  %v3274 = load i64, ptr %slot513, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  %ld3276 = load i64, ptr %p3275, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3276, ptr %slot514, align 8
  %v3277 = load i64, ptr %slot510, align 8
  %op3278 = mul i64 %v3277, 24
  store i64 %op3278, ptr %slot515, align 8
  %v3279 = load i64, ptr %slot514, align 8
  %v3280 = load i64, ptr %slot515, align 8
  %op3281 = add i64 %v3279, %v3280
  store i64 %op3281, ptr %slot516, align 8
  %v3282 = load i64, ptr %slot516, align 8
  %v3283 = load i64, ptr %slot44, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  store i64 %v3282, ptr %p3284, align 8, !alias.scope !3, !noalias !4
  %v3285 = load i64, ptr %slot44, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  %ld3287 = load i64, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3287, ptr %slot517, align 8
  %v3288 = load i64, ptr %slot22, align 8
  store i64 %v3288, ptr %slot518, align 8
  %v3289 = load i64, ptr %slot55, align 8
  %v3290 = load i64, ptr %slot518, align 8
  %v3291 = load i64, ptr %slot517, align 8
  %call3292 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64 %v3289, i64 %v3290, i64 %v3291) nomerge, !dbg !146
  store i32 %call3292, ptr %slot519, align 8
  %v3293 = load i32, ptr %slot519, align 8
  %cv3294 = zext i32 %v3293 to i64
  %cond3295 = icmp ne i64 %cv3294, 0
  br i1 %cond3295, label %bb_rcsuccess850, label %bb_rcfailure850
bb_rcfailure850:
  %v3296 = load i64, ptr %slot55, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %call3298 = call i32 @myl_rc_take_failure(ptr %p3297) nomerge, !dbg !146
  store i32 %call3298, ptr %slot520, align 8
  %v3299 = load i64, ptr %slot1, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %v3301 = load i32, ptr %slot520, align 8
  %call3302 = call i32 @myl_qbe_rc_status(ptr %p3300, i32 %v3301) nomerge, !dbg !146
  store i32 %call3302, ptr %slot521, align 8
  br label %bb_failure
bb_rcsuccess850:
  %v3303 = load i64, ptr %slot17, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i32 2, ptr %p3304, align 4, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot17, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  store i32 16, ptr %p3306, align 4, !alias.scope !3, !noalias !4
  %v3307 = load i64, ptr %slot16, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  store i32 1, ptr %p3308, align 4, !alias.scope !3, !noalias !4
  %v3309 = load i64, ptr %slot19, align 8
  store i64 %v3309, ptr %slot522, align 8
  %v3310 = load i64, ptr %slot22, align 8
  store i64 %v3310, ptr %slot523, align 8
  %v3311 = load i64, ptr %slot523, align 8
  %v3312 = load i64, ptr %slot522, align 8
  %p3313 = inttoptr i64 %v3311 to ptr
  %p3314 = inttoptr i64 %v3312 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3314, ptr %p3313, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot13, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i32 2, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot17, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  %ld3319 = load i32, ptr %p3318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3319, ptr %slot524, align 8
  %v3320 = load i32, ptr %slot524, align 8
  %v3321 = load i64, ptr %slot13, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  store i32 %v3320, ptr %p3322, align 4, !alias.scope !3, !noalias !4
  %v3323 = load i64, ptr %slot16, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i32 0, ptr %p3324, align 4, !alias.scope !3, !noalias !4
  %v3325 = load i64, ptr %slot12, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  store i32 1, ptr %p3326, align 4, !alias.scope !3, !noalias !4
  %v3327 = load i64, ptr %slot522, align 8
  %v3328 = load i64, ptr %slot44, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  store i64 %v3327, ptr %p3329, align 8, !alias.scope !3, !noalias !4
  %v3330 = load i64, ptr %slot44, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %ld3332 = load i64, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3332, ptr %slot525, align 8
  %v3333 = load i64, ptr %slot12, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i32, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3335, ptr %slot526, align 8
  %v3336 = load i64, ptr %slot13, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  %ld3338 = load i32, ptr %p3337, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3338, ptr %slot527, align 8
  %v3339 = load i32, ptr %slot527, align 8
  %op3340 = and i32 %v3339, 24
  store i32 %op3340, ptr %slot527, align 8
  %v3341 = load i32, ptr %slot527, align 8
  %cmp3342 = icmp eq i32 %v3341, 0
  %cv3343 = zext i1 %cmp3342 to i32
  store i32 %cv3343, ptr %slot528, align 8
  %v3344 = load i32, ptr %slot526, align 8
  %v3345 = load i32, ptr %slot528, align 8
  %op3346 = and i32 %v3344, %v3345
  store i32 %op3346, ptr %slot529, align 8
  %v3347 = load i32, ptr %slot529, align 8
  %cv3348 = zext i32 %v3347 to i64
  %cond3349 = icmp ne i64 %cv3348, 0
  br i1 %cond3349, label %bb_rcprivateown871, label %bb_rcprivateloan871
bb_rcprivateown871:
  %v3350 = load i64, ptr %slot22, align 8
  store i64 %v3350, ptr %slot530, align 8
  %v3351 = load i64, ptr %slot56, align 8
  store i64 %v3351, ptr %slot531, align 8
  %v3352 = load i64, ptr %slot525, align 8
  %v3353 = load i64, ptr %slot530, align 8
  %op3354 = sub i64 %v3352, %v3353
  store i64 %op3354, ptr %slot532, align 8
  %v3355 = load i64, ptr %slot530, align 8
  %v3356 = load i64, ptr %slot525, align 8
  %op3357 = sub i64 %v3355, %v3356
  store i64 %op3357, ptr %slot533, align 8
  %v3358 = load i64, ptr %slot532, align 8
  %cmp3359 = icmp ult i64 %v3358, 24
  %cv3360 = zext i1 %cmp3359 to i32
  store i32 %cv3360, ptr %slot534, align 8
  %v3361 = load i64, ptr %slot533, align 8
  %cmp3362 = icmp ult i64 %v3361, 24
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot535, align 8
  %v3364 = load i32, ptr %slot534, align 8
  %v3365 = load i32, ptr %slot535, align 8
  %op3366 = or i32 %v3364, %v3365
  store i32 %op3366, ptr %slot536, align 8
  %v3367 = load i32, ptr %slot536, align 8
  %cv3368 = zext i32 %v3367 to i64
  %cond3369 = icmp ne i64 %cv3368, 0
  br i1 %cond3369, label %bb_rcmoveslow874, label %bb_rcmovecheck874
bb_rcmovecheck874:
  %v3370 = load i64, ptr %slot525, align 8
  %op3371 = add i64 %v3370, 0
  store i64 %op3371, ptr %slot537, align 8
  %v3372 = load i64, ptr %slot537, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %ld3374 = load i64, ptr %p3373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3374, ptr %slot538, align 8
  %v3375 = load i64, ptr %slot538, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot539, align 8
  %v3378 = load i32, ptr %slot539, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcmoveheader882, label %bb_rcmovenext882
bb_rcmoveheader882:
  %v3381 = load i64, ptr %slot538, align 8
  %op3382 = sub i64 %v3381, 16
  store i64 %op3382, ptr %slot540, align 8
  %v3383 = load i64, ptr %slot538, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %rgep3385 = getelementptr i8, ptr %p3384, i64 -16
  %ld3386 = load i64, ptr %rgep3385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3386, ptr %slot541, align 8
  %v3387 = load i64, ptr %slot541, align 8
  %op3388 = and i64 %v3387, 5764607523034234881
  store i64 %op3388, ptr %slot542, align 8
  %v3389 = load i64, ptr %slot542, align 8
  %cmp3390 = icmp ne i64 %v3389, 0
  %cv3391 = zext i1 %cmp3390 to i32
  store i32 %cv3391, ptr %slot543, align 8
  %v3392 = load i32, ptr %slot543, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcmoveslow874, label %bb_rcmovenext882
bb_rcmovenext882:
  %v3395 = load i64, ptr %slot525, align 8
  %v3396 = load i64, ptr %slot530, align 8
  %p3397 = inttoptr i64 %v3395 to ptr
  %p3398 = inttoptr i64 %v3396 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3398, ptr %p3397, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3399 = load i64, ptr %slot525, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i64 0, ptr %p3400, align 8, !alias.scope !3, !noalias !4
  %v3401 = load i64, ptr %slot525, align 8
  %op3402 = add i64 %v3401, 8
  store i64 %op3402, ptr %slot544, align 8
  %v3403 = load i64, ptr %slot544, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i64 0, ptr %p3404, align 8, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot525, align 8
  %op3406 = add i64 %v3405, 16
  store i64 %op3406, ptr %slot545, align 8
  %v3407 = load i64, ptr %slot545, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  store i64 0, ptr %p3408, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved874
bb_rcmoveslow874:
  %v3409 = load i64, ptr %slot55, align 8
  %v3410 = load i64, ptr %slot530, align 8
  %v3411 = load i64, ptr %slot525, align 8
  %v3412 = load i64, ptr %slot531, align 8
  %cv3413 = trunc i64 %v3412 to i32
  %call3414 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64 %v3409, i64 %v3410, i64 %v3411, i32 %cv3413) nomerge, !dbg !148
  store i32 %call3414, ptr %slot546, align 8
  %v3415 = load i32, ptr %slot546, align 8
  %cv3416 = zext i32 %v3415 to i64
  %cond3417 = icmp ne i64 %cv3416, 0
  br i1 %cond3417, label %bb_rcsuccess891, label %bb_rcfailure891
bb_rcfailure891:
  %v3418 = load i64, ptr %slot55, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %call3420 = call i32 @myl_rc_take_failure(ptr %p3419) nomerge, !dbg !148
  store i32 %call3420, ptr %slot547, align 8
  %v3421 = load i64, ptr %slot1, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  %v3423 = load i32, ptr %slot547, align 8
  %call3424 = call i32 @myl_qbe_rc_status(ptr %p3422, i32 %v3423) nomerge, !dbg !148
  store i32 %call3424, ptr %slot548, align 8
  br label %bb_failure
bb_rcsuccess891:
  br label %bb_rcmoved874
bb_rcmoved874:
  %v3425 = load i64, ptr %slot12, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  store i32 0, ptr %p3426, align 4, !alias.scope !3, !noalias !4
  %v3427 = load i64, ptr %slot17, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  store i32 2, ptr %p3428, align 4, !alias.scope !3, !noalias !4
  %v3429 = load i64, ptr %slot16, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  store i32 1, ptr %p3430, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared871
bb_rcprivateloan871:
  %v3431 = load i64, ptr %slot12, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  %ld3433 = load i32, ptr %p3432, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3433, ptr %slot549, align 8
  %v3434 = load i64, ptr %slot13, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %ld3436 = load i32, ptr %p3435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3436, ptr %slot550, align 8
  %v3437 = load i32, ptr %slot550, align 8
  %cmp3438 = icmp eq i32 %v3437, 16
  %cv3439 = zext i1 %cmp3438 to i32
  store i32 %cv3439, ptr %slot551, align 8
  %v3440 = load i32, ptr %slot551, align 8
  %v3441 = load i32, ptr %slot549, align 8
  %op3442 = and i32 %v3440, %v3441
  store i32 %op3442, ptr %slot551, align 8
  %v3443 = load i32, ptr %slot551, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcprivatemove871, label %bb_rcprivatenew871
bb_rcprivatemove871:
  %v3446 = load i64, ptr %slot22, align 8
  store i64 %v3446, ptr %slot552, align 8
  %v3447 = load i64, ptr %slot525, align 8
  %v3448 = load i64, ptr %slot552, align 8
  %p3449 = inttoptr i64 %v3447 to ptr
  %p3450 = inttoptr i64 %v3448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3450, ptr %p3449, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3451 = load i64, ptr %slot525, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  call void @llvm.memset.p0.i64(ptr %p3452, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !148
  %v3453 = load i64, ptr %slot17, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  store i32 2, ptr %p3454, align 4, !alias.scope !3, !noalias !4
  %v3455 = load i64, ptr %slot17, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i32 16, ptr %p3456, align 4, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot16, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  store i32 1, ptr %p3458, align 4, !alias.scope !3, !noalias !4
  %v3459 = load i64, ptr %slot12, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i32 0, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared871
bb_rcprivatenew871:
  %v3461 = load i64, ptr %slot22, align 8
  store i64 %v3461, ptr %slot553, align 8
  %v3462 = load i64, ptr %slot55, align 8
  %v3463 = load i64, ptr %slot553, align 8
  %v3464 = load i64, ptr %slot525, align 8
  %call3465 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64 %v3462, i64 %v3463, i64 %v3464) nomerge, !dbg !148
  store i32 %call3465, ptr %slot554, align 8
  %v3466 = load i32, ptr %slot554, align 8
  %cv3467 = zext i32 %v3466 to i64
  %cond3468 = icmp ne i64 %cv3467, 0
  br i1 %cond3468, label %bb_rcsuccess909, label %bb_rcfailure909
bb_rcfailure909:
  %v3469 = load i64, ptr %slot55, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %call3471 = call i32 @myl_rc_take_failure(ptr %p3470) nomerge, !dbg !148
  store i32 %call3471, ptr %slot555, align 8
  %v3472 = load i64, ptr %slot1, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %v3474 = load i32, ptr %slot555, align 8
  %call3475 = call i32 @myl_qbe_rc_status(ptr %p3473, i32 %v3474) nomerge, !dbg !148
  store i32 %call3475, ptr %slot556, align 8
  br label %bb_failure
bb_rcsuccess909:
  %v3476 = load i64, ptr %slot17, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  store i32 2, ptr %p3477, align 4, !alias.scope !3, !noalias !4
  %v3478 = load i64, ptr %slot17, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i32 16, ptr %p3479, align 4, !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot16, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  store i32 1, ptr %p3481, align 4, !alias.scope !3, !noalias !4
  %v3482 = load i64, ptr %slot12, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i32, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3484, ptr %slot557, align 8
  %v3485 = load i32, ptr %slot557, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcslotdrop917, label %bb_rcslotdone917
bb_rcslotdrop917:
  %v3488 = load i64, ptr %slot12, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i32 0, ptr %p3489, align 4, !alias.scope !3, !noalias !4
  %v3490 = load i64, ptr %slot19, align 8
  store i64 %v3490, ptr %slot558, align 8
  %v3491 = load i64, ptr %slot13, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %ld3493 = load i32, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3493, ptr %slot559, align 8
  %v3494 = load i32, ptr %slot559, align 8
  %op3495 = and i32 %v3494, 28
  store i32 %op3495, ptr %slot560, align 8
  %v3496 = load i32, ptr %slot560, align 8
  %cv3497 = zext i32 %v3496 to i64
  %cond3498 = icmp ne i64 %cv3497, 0
  br i1 %cond3498, label %bb_rcslotrole917, label %bb_rcslotowner917
bb_rcslotrole917:
  %v3499 = load i64, ptr %slot55, align 8
  store i64 %v3499, ptr %slot561, align 8
  %v3500 = load i64, ptr %slot561, align 8
  %v3501 = load i64, ptr %slot558, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3500, i64 %v3501) nomerge, !dbg !148
  br label %bb_rcslotdone917
bb_rcslotowner917:
  %v3502 = load i64, ptr %slot558, align 8
  %p3504 = inttoptr i64 %v3502 to ptr
  %gep3505 = getelementptr i8, ptr %p3504, i64 0
  %op3503 = ptrtoint ptr %gep3505 to i64
  store i64 %op3503, ptr %slot562, align 8
  %v3506 = load i64, ptr %slot55, align 8
  store i64 %v3506, ptr %slot563, align 8
  %v3507 = load i64, ptr %slot562, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i64, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3509, ptr %slot564, align 8
  %v3510 = load i64, ptr %slot564, align 8
  %cmp3511 = icmp ne i64 %v3510, 0
  %cv3512 = zext i1 %cmp3511 to i32
  store i32 %cv3512, ptr %slot565, align 8
  %v3513 = load i32, ptr %slot565, align 8
  %cv3514 = zext i32 %v3513 to i64
  %cond3515 = icmp ne i64 %cv3514, 0
  br i1 %cond3515, label %bb_rcgnn935, label %bb_rcgdone935
bb_rcgnn935:
  %v3516 = load i64, ptr %slot564, align 8
  %op3517 = sub i64 %v3516, 16
  store i64 %op3517, ptr %slot566, align 8
  %v3518 = load i64, ptr %slot564, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  %rgep3520 = getelementptr i8, ptr %p3519, i64 -16
  %ld3521 = load i64, ptr %rgep3520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3521, ptr %slot567, align 8
  %v3522 = load i64, ptr %slot567, align 8
  %op3523 = and i64 %v3522, 4611686018427387906
  store i64 %op3523, ptr %slot568, align 8
  %v3524 = load i64, ptr %slot568, align 8
  %cmp3525 = icmp ne i64 %v3524, 0
  %cv3526 = zext i1 %cmp3525 to i32
  store i32 %cv3526, ptr %slot569, align 8
  %v3527 = load i32, ptr %slot569, align 8
  %cv3528 = zext i32 %v3527 to i64
  %cond3529 = icmp ne i64 %cv3528, 0
  br i1 %cond3529, label %bb_rcgclear935, label %bb_rcgcounted935
bb_rcgcounted935:
  %v3530 = load i64, ptr %slot564, align 8
  %op3531 = sub i64 %v3530, 32
  store i64 %op3531, ptr %slot570, align 8
  %v3532 = load i64, ptr %slot564, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %rgep3534 = getelementptr i8, ptr %p3533, i64 -32
  %ld3535 = load i64, ptr %rgep3534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3535, ptr %slot571, align 8
  %v3536 = load i64, ptr %slot571, align 8
  %op3537 = sub i64 %v3536, 1
  store i64 %op3537, ptr %slot572, align 8
  %v3538 = load i64, ptr %slot572, align 8
  %cmp3539 = icmp eq i64 %v3538, 0
  %cv3540 = zext i1 %cmp3539 to i32
  store i32 %cv3540, ptr %slot573, align 8
  %v3541 = load i32, ptr %slot573, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcglast935, label %bb_rcgdec935
bb_rcglast935:
  %v3544 = load i64, ptr %slot564, align 8
  %op3545 = sub i64 %v3544, 24
  store i64 %op3545, ptr %slot574, align 8
  %v3546 = load i64, ptr %slot564, align 8
  %p3547 = inttoptr i64 %v3546 to ptr
  %rgep3548 = getelementptr i8, ptr %p3547, i64 -24
  %ld3549 = load i64, ptr %rgep3548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3549, ptr %slot575, align 8
  %v3550 = load i64, ptr %slot575, align 8
  %cmp3551 = icmp ne i64 %v3550, 0
  %cv3552 = zext i1 %cmp3551 to i32
  store i32 %cv3552, ptr %slot576, align 8
  %v3553 = load i32, ptr %slot576, align 8
  %cv3554 = zext i32 %v3553 to i64
  %cond3555 = icmp ne i64 %cv3554, 0
  br i1 %cond3555, label %bb_rcgdec935, label %bb_rcgslow935
bb_rcgslow935:
  %v3556 = load i64, ptr %slot563, align 8
  %v3557 = load i64, ptr %slot562, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3556, i64 %v3557) nomerge, !dbg !148
  br label %bb_rcgdone935
bb_rcgdec935:
  %v3558 = load i64, ptr %slot572, align 8
  %v3559 = load i64, ptr %slot564, align 8
  %p3560 = inttoptr i64 %v3559 to ptr
  %rgep3561 = getelementptr i8, ptr %p3560, i64 -32
  store i64 %v3558, ptr %rgep3561, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear935
bb_rcgclear935:
  %v3562 = load i64, ptr %slot562, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  store i64 0, ptr %p3563, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone935
bb_rcgdone935:
  %v3564 = load i64, ptr %slot558, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  store i64 0, ptr %p3565, align 8, !alias.scope !3, !noalias !4
  %v3566 = load i64, ptr %slot558, align 8
  %p3568 = inttoptr i64 %v3566 to ptr
  %gep3569 = getelementptr i8, ptr %p3568, i64 8
  %op3567 = ptrtoint ptr %gep3569 to i64
  store i64 %op3567, ptr %slot577, align 8
  %v3570 = load i64, ptr %slot577, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i64 0, ptr %p3571, align 8, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot558, align 8
  %p3574 = inttoptr i64 %v3572 to ptr
  %gep3575 = getelementptr i8, ptr %p3574, i64 16
  %op3573 = ptrtoint ptr %gep3575 to i64
  store i64 %op3573, ptr %slot578, align 8
  %v3576 = load i64, ptr %slot578, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  store i64 0, ptr %p3577, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone917
bb_rcslotdone917:
  br label %bb_rcprivateprepared871
bb_rcprivateprepared871:
  %v3578 = load i64, ptr %slot8, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  %ld3580 = load i32, ptr %p3579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3580, ptr %slot579, align 8
  %v3581 = load i32, ptr %slot579, align 8
  %cv3582 = zext i32 %v3581 to i64
  %cond3583 = icmp ne i64 %cv3582, 0
  br i1 %cond3583, label %bb_rcslotdrop944, label %bb_rcslotdone944
bb_rcslotdrop944:
  %v3584 = load i64, ptr %slot8, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i32 0, ptr %p3585, align 4, !alias.scope !3, !noalias !4
  %v3586 = load i64, ptr %slot38, align 8
  store i64 %v3586, ptr %slot580, align 8
  %v3587 = load i64, ptr %slot9, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  %ld3589 = load i32, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3589, ptr %slot581, align 8
  %v3590 = load i32, ptr %slot581, align 8
  %op3591 = and i32 %v3590, 28
  store i32 %op3591, ptr %slot582, align 8
  %v3592 = load i32, ptr %slot582, align 8
  %cv3593 = zext i32 %v3592 to i64
  %cond3594 = icmp ne i64 %cv3593, 0
  br i1 %cond3594, label %bb_rcslotrole944, label %bb_rcslotowner944
bb_rcslotrole944:
  %v3595 = load i64, ptr %slot55, align 8
  store i64 %v3595, ptr %slot583, align 8
  %v3596 = load i64, ptr %slot583, align 8
  %v3597 = load i64, ptr %slot580, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3596, i64 %v3597) nomerge, !dbg !148
  br label %bb_rcslotdone944
bb_rcslotowner944:
  %v3598 = load i64, ptr %slot580, align 8
  %p3600 = inttoptr i64 %v3598 to ptr
  %gep3601 = getelementptr i8, ptr %p3600, i64 0
  %op3599 = ptrtoint ptr %gep3601 to i64
  store i64 %op3599, ptr %slot584, align 8
  %v3602 = load i64, ptr %slot55, align 8
  store i64 %v3602, ptr %slot585, align 8
  %v3603 = load i64, ptr %slot584, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %ld3605 = load i64, ptr %p3604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3605, ptr %slot586, align 8
  %v3606 = load i64, ptr %slot586, align 8
  %cmp3607 = icmp ne i64 %v3606, 0
  %cv3608 = zext i1 %cmp3607 to i32
  store i32 %cv3608, ptr %slot587, align 8
  %v3609 = load i32, ptr %slot587, align 8
  %cv3610 = zext i32 %v3609 to i64
  %cond3611 = icmp ne i64 %cv3610, 0
  br i1 %cond3611, label %bb_rcgnn962, label %bb_rcgdone962
bb_rcgnn962:
  %v3612 = load i64, ptr %slot586, align 8
  %op3613 = sub i64 %v3612, 16
  store i64 %op3613, ptr %slot588, align 8
  %v3614 = load i64, ptr %slot586, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  %rgep3616 = getelementptr i8, ptr %p3615, i64 -16
  %ld3617 = load i64, ptr %rgep3616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3617, ptr %slot589, align 8
  %v3618 = load i64, ptr %slot589, align 8
  %op3619 = and i64 %v3618, 4611686018427387906
  store i64 %op3619, ptr %slot590, align 8
  %v3620 = load i64, ptr %slot590, align 8
  %cmp3621 = icmp ne i64 %v3620, 0
  %cv3622 = zext i1 %cmp3621 to i32
  store i32 %cv3622, ptr %slot591, align 8
  %v3623 = load i32, ptr %slot591, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcgclear962, label %bb_rcgcounted962
bb_rcgcounted962:
  %v3626 = load i64, ptr %slot586, align 8
  %op3627 = sub i64 %v3626, 32
  store i64 %op3627, ptr %slot592, align 8
  %v3628 = load i64, ptr %slot586, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  %rgep3630 = getelementptr i8, ptr %p3629, i64 -32
  %ld3631 = load i64, ptr %rgep3630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3631, ptr %slot593, align 8
  %v3632 = load i64, ptr %slot593, align 8
  %op3633 = sub i64 %v3632, 1
  store i64 %op3633, ptr %slot594, align 8
  %v3634 = load i64, ptr %slot594, align 8
  %cmp3635 = icmp eq i64 %v3634, 0
  %cv3636 = zext i1 %cmp3635 to i32
  store i32 %cv3636, ptr %slot595, align 8
  %v3637 = load i32, ptr %slot595, align 8
  %cv3638 = zext i32 %v3637 to i64
  %cond3639 = icmp ne i64 %cv3638, 0
  br i1 %cond3639, label %bb_rcglast962, label %bb_rcgdec962
bb_rcglast962:
  %v3640 = load i64, ptr %slot586, align 8
  %op3641 = sub i64 %v3640, 24
  store i64 %op3641, ptr %slot596, align 8
  %v3642 = load i64, ptr %slot586, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  %rgep3644 = getelementptr i8, ptr %p3643, i64 -24
  %ld3645 = load i64, ptr %rgep3644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3645, ptr %slot597, align 8
  %v3646 = load i64, ptr %slot597, align 8
  %cmp3647 = icmp ne i64 %v3646, 0
  %cv3648 = zext i1 %cmp3647 to i32
  store i32 %cv3648, ptr %slot598, align 8
  %v3649 = load i32, ptr %slot598, align 8
  %cv3650 = zext i32 %v3649 to i64
  %cond3651 = icmp ne i64 %cv3650, 0
  br i1 %cond3651, label %bb_rcgdec962, label %bb_rcgslow962
bb_rcgslow962:
  %v3652 = load i64, ptr %slot585, align 8
  %v3653 = load i64, ptr %slot584, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3652, i64 %v3653) nomerge, !dbg !148
  br label %bb_rcgdone962
bb_rcgdec962:
  %v3654 = load i64, ptr %slot594, align 8
  %v3655 = load i64, ptr %slot586, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  %rgep3657 = getelementptr i8, ptr %p3656, i64 -32
  store i64 %v3654, ptr %rgep3657, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear962
bb_rcgclear962:
  %v3658 = load i64, ptr %slot584, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  store i64 0, ptr %p3659, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone962
bb_rcgdone962:
  %v3660 = load i64, ptr %slot580, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  store i64 0, ptr %p3661, align 8, !alias.scope !3, !noalias !4
  %v3662 = load i64, ptr %slot580, align 8
  %p3664 = inttoptr i64 %v3662 to ptr
  %gep3665 = getelementptr i8, ptr %p3664, i64 8
  %op3663 = ptrtoint ptr %gep3665 to i64
  store i64 %op3663, ptr %slot599, align 8
  %v3666 = load i64, ptr %slot599, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  store i64 0, ptr %p3667, align 8, !alias.scope !3, !noalias !4
  %v3668 = load i64, ptr %slot580, align 8
  %p3670 = inttoptr i64 %v3668 to ptr
  %gep3671 = getelementptr i8, ptr %p3670, i64 16
  %op3669 = ptrtoint ptr %gep3671 to i64
  store i64 %op3669, ptr %slot600, align 8
  %v3672 = load i64, ptr %slot600, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  store i64 0, ptr %p3673, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone944
bb_rcslotdone944:
  %v3674 = load i64, ptr %slot38, align 8
  store i64 %v3674, ptr %slot601, align 8
  %v3675 = load i64, ptr %slot22, align 8
  store i64 %v3675, ptr %slot602, align 8
  %v3676 = load i64, ptr %slot602, align 8
  %v3677 = load i64, ptr %slot601, align 8
  %p3678 = inttoptr i64 %v3676 to ptr
  %p3679 = inttoptr i64 %v3677 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3679, ptr %p3678, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3680 = load i64, ptr %slot16, align 8
  %p3681 = inttoptr i64 %v3680 to ptr
  store i32 0, ptr %p3681, align 4, !alias.scope !3, !noalias !4
  %v3682 = load i64, ptr %slot9, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  store i32 2, ptr %p3683, align 4, !alias.scope !3, !noalias !4
  %v3684 = load i64, ptr %slot17, align 8
  %p3685 = inttoptr i64 %v3684 to ptr
  %ld3686 = load i32, ptr %p3685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3686, ptr %slot603, align 8
  %v3687 = load i32, ptr %slot603, align 8
  %v3688 = load i64, ptr %slot9, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  store i32 %v3687, ptr %p3689, align 4, !alias.scope !3, !noalias !4
  %v3690 = load i64, ptr %slot8, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  store i32 1, ptr %p3691, align 4, !alias.scope !3, !noalias !4
  %v3692 = load i64, ptr %slot36, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  %ld3694 = load i64, ptr %p3693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3694, ptr %slot604, align 8
  %v3695 = load i64, ptr %slot604, align 8
  %v3696 = load i64, ptr %slot44, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  store i64 %v3695, ptr %p3697, align 8, !alias.scope !3, !noalias !4
  %v3698 = load i64, ptr %slot38, align 8
  %v3699 = load i64, ptr %slot45, align 8
  %p3700 = inttoptr i64 %v3699 to ptr
  store i64 %v3698, ptr %p3700, align 8, !alias.scope !3, !noalias !4
  %v3701 = load i64, ptr %slot39, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  %ld3703 = load i64, ptr %p3702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3703, ptr %slot605, align 8
  %v3704 = load i64, ptr %slot605, align 8
  %v3705 = load i64, ptr %slot46, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  store i64 %v3704, ptr %p3706, align 8, !alias.scope !3, !noalias !4
  %v3707 = load i64, ptr %slot45, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  %ld3709 = load i64, ptr %p3708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3709, ptr %slot606, align 8
  %v3710 = load i64, ptr %slot14, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %ld3712 = load i32, ptr %p3711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3712, ptr %slot607, align 8
  %v3713 = load i64, ptr %slot15, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %ld3715 = load i32, ptr %p3714, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3715, ptr %slot608, align 8
  %v3716 = load i32, ptr %slot608, align 8
  %op3717 = and i32 %v3716, 24
  store i32 %op3717, ptr %slot608, align 8
  %v3718 = load i32, ptr %slot608, align 8
  %cmp3719 = icmp eq i32 %v3718, 0
  %cv3720 = zext i1 %cmp3719 to i32
  store i32 %cv3720, ptr %slot609, align 8
  %v3721 = load i32, ptr %slot607, align 8
  %v3722 = load i32, ptr %slot609, align 8
  %op3723 = and i32 %v3721, %v3722
  store i32 %op3723, ptr %slot610, align 8
  %v3724 = load i32, ptr %slot610, align 8
  %cv3725 = zext i32 %v3724 to i64
  %cond3726 = icmp ne i64 %cv3725, 0
  br i1 %cond3726, label %bb_rctake978, label %bb_rccopy978
bb_rctake978:
  %v3727 = load i64, ptr %slot22, align 8
  store i64 %v3727, ptr %slot611, align 8
  %v3728 = load i64, ptr %slot56, align 8
  store i64 %v3728, ptr %slot612, align 8
  %v3729 = load i64, ptr %slot606, align 8
  %v3730 = load i64, ptr %slot611, align 8
  %op3731 = sub i64 %v3729, %v3730
  store i64 %op3731, ptr %slot613, align 8
  %v3732 = load i64, ptr %slot611, align 8
  %v3733 = load i64, ptr %slot606, align 8
  %op3734 = sub i64 %v3732, %v3733
  store i64 %op3734, ptr %slot614, align 8
  %v3735 = load i64, ptr %slot613, align 8
  %cmp3736 = icmp ult i64 %v3735, 24
  %cv3737 = zext i1 %cmp3736 to i32
  store i32 %cv3737, ptr %slot615, align 8
  %v3738 = load i64, ptr %slot614, align 8
  %cmp3739 = icmp ult i64 %v3738, 24
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot616, align 8
  %v3741 = load i32, ptr %slot615, align 8
  %v3742 = load i32, ptr %slot616, align 8
  %op3743 = or i32 %v3741, %v3742
  store i32 %op3743, ptr %slot617, align 8
  %v3744 = load i32, ptr %slot617, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcmoveslow987, label %bb_rcmovecheck987
bb_rcmovecheck987:
  %v3747 = load i64, ptr %slot606, align 8
  %op3748 = add i64 %v3747, 0
  store i64 %op3748, ptr %slot618, align 8
  %v3749 = load i64, ptr %slot618, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  %ld3751 = load i64, ptr %p3750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3751, ptr %slot619, align 8
  %v3752 = load i64, ptr %slot619, align 8
  %cmp3753 = icmp ne i64 %v3752, 0
  %cv3754 = zext i1 %cmp3753 to i32
  store i32 %cv3754, ptr %slot620, align 8
  %v3755 = load i32, ptr %slot620, align 8
  %cv3756 = zext i32 %v3755 to i64
  %cond3757 = icmp ne i64 %cv3756, 0
  br i1 %cond3757, label %bb_rcmoveheader995, label %bb_rcmovenext995
bb_rcmoveheader995:
  %v3758 = load i64, ptr %slot619, align 8
  %op3759 = sub i64 %v3758, 16
  store i64 %op3759, ptr %slot621, align 8
  %v3760 = load i64, ptr %slot619, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  %rgep3762 = getelementptr i8, ptr %p3761, i64 -16
  %ld3763 = load i64, ptr %rgep3762, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3763, ptr %slot622, align 8
  %v3764 = load i64, ptr %slot622, align 8
  %op3765 = and i64 %v3764, 5764607523034234881
  store i64 %op3765, ptr %slot623, align 8
  %v3766 = load i64, ptr %slot623, align 8
  %cmp3767 = icmp ne i64 %v3766, 0
  %cv3768 = zext i1 %cmp3767 to i32
  store i32 %cv3768, ptr %slot624, align 8
  %v3769 = load i32, ptr %slot624, align 8
  %cv3770 = zext i32 %v3769 to i64
  %cond3771 = icmp ne i64 %cv3770, 0
  br i1 %cond3771, label %bb_rcmoveslow987, label %bb_rcmovenext995
bb_rcmovenext995:
  %v3772 = load i64, ptr %slot606, align 8
  %v3773 = load i64, ptr %slot611, align 8
  %p3774 = inttoptr i64 %v3772 to ptr
  %p3775 = inttoptr i64 %v3773 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3775, ptr %p3774, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3776 = load i64, ptr %slot606, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  store i64 0, ptr %p3777, align 8, !alias.scope !3, !noalias !4
  %v3778 = load i64, ptr %slot606, align 8
  %op3779 = add i64 %v3778, 8
  store i64 %op3779, ptr %slot625, align 8
  %v3780 = load i64, ptr %slot625, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  store i64 0, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  %v3782 = load i64, ptr %slot606, align 8
  %op3783 = add i64 %v3782, 16
  store i64 %op3783, ptr %slot626, align 8
  %v3784 = load i64, ptr %slot626, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  store i64 0, ptr %p3785, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved987
bb_rcmoveslow987:
  %v3786 = load i64, ptr %slot55, align 8
  %v3787 = load i64, ptr %slot611, align 8
  %v3788 = load i64, ptr %slot606, align 8
  %v3789 = load i64, ptr %slot612, align 8
  %cv3790 = trunc i64 %v3789 to i32
  %call3791 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64 %v3786, i64 %v3787, i64 %v3788, i32 %cv3790) nomerge, !dbg !150
  store i32 %call3791, ptr %slot627, align 8
  %v3792 = load i32, ptr %slot627, align 8
  %cv3793 = zext i32 %v3792 to i64
  %cond3794 = icmp ne i64 %cv3793, 0
  br i1 %cond3794, label %bb_rcsuccess1004, label %bb_rcfailure1004
bb_rcfailure1004:
  %v3795 = load i64, ptr %slot55, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %call3797 = call i32 @myl_rc_take_failure(ptr %p3796) nomerge, !dbg !150
  store i32 %call3797, ptr %slot628, align 8
  %v3798 = load i64, ptr %slot1, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %v3800 = load i32, ptr %slot628, align 8
  %call3801 = call i32 @myl_qbe_rc_status(ptr %p3799, i32 %v3800) nomerge, !dbg !150
  store i32 %call3801, ptr %slot629, align 8
  br label %bb_failure
bb_rcsuccess1004:
  br label %bb_rcmoved987
bb_rcmoved987:
  %v3802 = load i64, ptr %slot14, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  store i32 0, ptr %p3803, align 4, !alias.scope !3, !noalias !4
  %v3804 = load i64, ptr %slot17, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i32 2, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot16, align 8
  %p3807 = inttoptr i64 %v3806 to ptr
  store i32 1, ptr %p3807, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared978
bb_rccopy978:
  %v3808 = load i64, ptr %slot22, align 8
  store i64 %v3808, ptr %slot630, align 8
  %v3809 = load i64, ptr %slot56, align 8
  store i64 %v3809, ptr %slot631, align 8
  %v3810 = load i64, ptr %slot55, align 8
  %v3811 = load i64, ptr %slot630, align 8
  %v3812 = load i64, ptr %slot606, align 8
  %v3813 = load i64, ptr %slot631, align 8
  %cv3814 = trunc i64 %v3813 to i32
  %call3815 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_retain(i64 %v3810, i64 %v3811, i64 %v3812, i32 %cv3814) nomerge, !dbg !150
  store i32 %call3815, ptr %slot632, align 8
  %v3816 = load i32, ptr %slot632, align 8
  %cv3817 = zext i32 %v3816 to i64
  %cond3818 = icmp ne i64 %cv3817, 0
  br i1 %cond3818, label %bb_rcsuccess1013, label %bb_rcfailure1013
bb_rcfailure1013:
  %v3819 = load i64, ptr %slot55, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %call3821 = call i32 @myl_rc_take_failure(ptr %p3820) nomerge, !dbg !150
  store i32 %call3821, ptr %slot633, align 8
  %v3822 = load i64, ptr %slot1, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %v3824 = load i32, ptr %slot633, align 8
  %call3825 = call i32 @myl_qbe_rc_status(ptr %p3823, i32 %v3824) nomerge, !dbg !150
  store i32 %call3825, ptr %slot634, align 8
  br label %bb_failure
bb_rcsuccess1013:
  %v3826 = load i64, ptr %slot17, align 8
  %p3827 = inttoptr i64 %v3826 to ptr
  store i32 2, ptr %p3827, align 4, !alias.scope !3, !noalias !4
  %v3828 = load i64, ptr %slot16, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i32 1, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot14, align 8
  %p3831 = inttoptr i64 %v3830 to ptr
  %ld3832 = load i32, ptr %p3831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3832, ptr %slot635, align 8
  %v3833 = load i32, ptr %slot635, align 8
  %cv3834 = zext i32 %v3833 to i64
  %cond3835 = icmp ne i64 %cv3834, 0
  br i1 %cond3835, label %bb_rcslotdrop1020, label %bb_rcslotdone1020
bb_rcslotdrop1020:
  %v3836 = load i64, ptr %slot14, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  store i32 0, ptr %p3837, align 4, !alias.scope !3, !noalias !4
  %v3838 = load i64, ptr %slot20, align 8
  store i64 %v3838, ptr %slot636, align 8
  %v3839 = load i64, ptr %slot15, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %ld3841 = load i32, ptr %p3840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3841, ptr %slot637, align 8
  %v3842 = load i32, ptr %slot637, align 8
  %op3843 = and i32 %v3842, 28
  store i32 %op3843, ptr %slot638, align 8
  %v3844 = load i32, ptr %slot638, align 8
  %cv3845 = zext i32 %v3844 to i64
  %cond3846 = icmp ne i64 %cv3845, 0
  br i1 %cond3846, label %bb_rcslotrole1020, label %bb_rcslotowner1020
bb_rcslotrole1020:
  %v3847 = load i64, ptr %slot55, align 8
  store i64 %v3847, ptr %slot639, align 8
  %v3848 = load i64, ptr %slot639, align 8
  %v3849 = load i64, ptr %slot636, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3848, i64 %v3849) nomerge, !dbg !150
  br label %bb_rcslotdone1020
bb_rcslotowner1020:
  %v3850 = load i64, ptr %slot55, align 8
  store i64 %v3850, ptr %slot640, align 8
  %v3851 = load i64, ptr %slot640, align 8
  %v3852 = load i64, ptr %slot636, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v3851, i64 %v3852) nomerge, !dbg !150
  br label %bb_rcslotdone1020
bb_rcslotdone1020:
  br label %bb_rcprepared978
bb_rcprepared978:
  %v3853 = load i64, ptr %slot22, align 8
  store i64 %v3853, ptr %slot641, align 8
  %v3854 = load i64, ptr %slot48, align 8
  store i64 %v3854, ptr %slot642, align 8
  %v3855 = load i64, ptr %slot641, align 8
  %v3856 = load i64, ptr %slot642, align 8
  %p3857 = inttoptr i64 %v3855 to ptr
  %p3858 = inttoptr i64 %v3856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3858, ptr %p3857, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3859 = load i64, ptr %slot16, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i32 0, ptr %p3860, align 4, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot18, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  store i32 1, ptr %p3862, align 4, !alias.scope !3, !noalias !4
  %v3863 = load i64, ptr %slot56, align 8
  store i64 %v3863, ptr %slot643, align 8
  %v3864 = load i64, ptr %slot46, align 8
  store i64 %v3864, ptr %slot644, align 8
  %v3865 = load i64, ptr %slot642, align 8
  %p3867 = inttoptr i64 %v3865 to ptr
  %gep3868 = getelementptr i8, ptr %p3867, i64 16
  %op3866 = ptrtoint ptr %gep3868 to i64
  store i64 %op3866, ptr %slot645, align 8
  %v3869 = load i64, ptr %slot644, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i8, ptr %p3870, align 1, !alias.scope !3, !noalias !4
  %ext3872 = zext i8 %ld3871 to i64
  store i64 %ext3872, ptr %slot646, align 8
  %v3873 = load i64, ptr %slot646, align 8
  %cv3874 = trunc i64 %v3873 to i8
  %v3875 = load i64, ptr %slot645, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  store i8 %cv3874, ptr %p3876, align 1, !alias.scope !3, !noalias !4
  %v3877 = load i64, ptr %slot642, align 8
  %v3878 = load i64, ptr %slot45, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  store i64 %v3877, ptr %p3879, align 8, !alias.scope !3, !noalias !4
  %v3880 = load i64, ptr %slot45, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  %ld3882 = load i64, ptr %p3881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3882, ptr %slot647, align 8
  %v3883 = load i64, ptr %slot22, align 8
  store i64 %v3883, ptr %slot648, align 8
  %v3884 = load i64, ptr %slot647, align 8
  %v3885 = load i64, ptr %slot648, align 8
  %p3886 = inttoptr i64 %v3884 to ptr
  %p3887 = inttoptr i64 %v3885 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3887, ptr %p3886, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3888 = load i64, ptr %slot17, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  store i32 2, ptr %p3889, align 4, !alias.scope !3, !noalias !4
  %v3890 = load i64, ptr %slot16, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  store i32 1, ptr %p3891, align 4, !alias.scope !3, !noalias !4
  %v3892 = load i64, ptr %slot14, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %ld3894 = load i32, ptr %p3893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3894, ptr %slot649, align 8
  %v3895 = load i32, ptr %slot649, align 8
  %cv3896 = zext i32 %v3895 to i64
  %cond3897 = icmp ne i64 %cv3896, 0
  br i1 %cond3897, label %bb_rcslotdrop1042, label %bb_rcslotdone1042
bb_rcslotdrop1042:
  %v3898 = load i64, ptr %slot14, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  store i32 0, ptr %p3899, align 4, !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot20, align 8
  store i64 %v3900, ptr %slot650, align 8
  %v3901 = load i64, ptr %slot15, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  %ld3903 = load i32, ptr %p3902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3903, ptr %slot651, align 8
  %v3904 = load i32, ptr %slot651, align 8
  %op3905 = and i32 %v3904, 28
  store i32 %op3905, ptr %slot652, align 8
  %v3906 = load i32, ptr %slot652, align 8
  %cv3907 = zext i32 %v3906 to i64
  %cond3908 = icmp ne i64 %cv3907, 0
  br i1 %cond3908, label %bb_rcslotrole1042, label %bb_rcslotowner1042
bb_rcslotrole1042:
  %v3909 = load i64, ptr %slot55, align 8
  store i64 %v3909, ptr %slot653, align 8
  %v3910 = load i64, ptr %slot653, align 8
  %v3911 = load i64, ptr %slot650, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3910, i64 %v3911) nomerge, !dbg !150
  br label %bb_rcslotdone1042
bb_rcslotowner1042:
  %v3912 = load i64, ptr %slot55, align 8
  store i64 %v3912, ptr %slot654, align 8
  %v3913 = load i64, ptr %slot654, align 8
  %v3914 = load i64, ptr %slot650, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v3913, i64 %v3914) nomerge, !dbg !150
  br label %bb_rcslotdone1042
bb_rcslotdone1042:
  %v3915 = load i64, ptr %slot20, align 8
  store i64 %v3915, ptr %slot655, align 8
  %v3916 = load i64, ptr %slot22, align 8
  store i64 %v3916, ptr %slot656, align 8
  %v3917 = load i64, ptr %slot656, align 8
  %v3918 = load i64, ptr %slot655, align 8
  %p3919 = inttoptr i64 %v3917 to ptr
  %p3920 = inttoptr i64 %v3918 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3920, ptr %p3919, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3921 = load i64, ptr %slot15, align 8
  %p3922 = inttoptr i64 %v3921 to ptr
  store i32 2, ptr %p3922, align 4, !alias.scope !3, !noalias !4
  %v3923 = load i64, ptr %slot17, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %ld3925 = load i32, ptr %p3924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3925, ptr %slot657, align 8
  %v3926 = load i32, ptr %slot657, align 8
  %v3927 = load i64, ptr %slot15, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  store i32 %v3926, ptr %p3928, align 4, !alias.scope !3, !noalias !4
  %v3929 = load i64, ptr %slot16, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i32 0, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  %v3931 = load i64, ptr %slot14, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  store i32 1, ptr %p3932, align 4, !alias.scope !3, !noalias !4
  %v3933 = load i64, ptr %slot655, align 8
  %v3934 = load i64, ptr %slot45, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  store i64 %v3933, ptr %p3935, align 8, !alias.scope !3, !noalias !4
  %v3936 = load i64, ptr %slot35, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  %ld3938 = load i64, ptr %p3937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3938, ptr %slot658, align 8
  %v3939 = load i64, ptr %slot45, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  %ld3941 = load i64, ptr %p3940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3941, ptr %slot659, align 8
  %v3942 = load i64, ptr %slot44, align 8
  %p3943 = inttoptr i64 %v3942 to ptr
  %ld3944 = load i64, ptr %p3943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3944, ptr %slot660, align 8
  %v3945 = load i64, ptr %slot658, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  %ld3947 = load i64, ptr %p3946, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3947, ptr %slot661, align 8
  %v3948 = load i64, ptr %slot660, align 8
  %v3949 = load i64, ptr %slot661, align 8
  %cmp3950 = icmp ult i64 %v3948, %v3949
  %cv3951 = zext i1 %cmp3950 to i64
  store i64 %cv3951, ptr %slot662, align 8
  %v3952 = load i64, ptr %slot662, align 8
  %cond3953 = icmp ne i64 %v3952, 0
  br i1 %cond3953, label %bb_success1063, label %bb_failed1063
bb_failed1063:
  %v3954 = load i64, ptr %slot1, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %v3956 = load i64, ptr %slot660, align 8
  %v3957 = load i64, ptr %slot661, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3955, i64 %v3956, i64 %v3957) nomerge, !dbg !152
  unreachable
bb_success1063:
  %v3958 = load i64, ptr %slot45, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  %ld3960 = load i64, ptr %p3959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3960, ptr %slot663, align 8
  %v3961 = load i64, ptr %slot55, align 8
  %v3962 = load i64, ptr %slot658, align 8
  %v3963 = load i64, ptr %slot660, align 8
  %v3964 = load i64, ptr %slot663, align 8
  %call3965 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_list_set(i64 %v3961, i64 %v3962, i64 %v3963, i64 %v3964) nomerge, !dbg !152
  store i32 %call3965, ptr %slot664, align 8
  %v3966 = load i32, ptr %slot664, align 8
  %cv3967 = zext i32 %v3966 to i64
  %cond3968 = icmp ne i64 %cv3967, 0
  br i1 %cond3968, label %bb_success1066, label %bb_failed1066
bb_failed1066:
  %v3969 = load i64, ptr %slot1, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3970) nomerge, !dbg !152
  unreachable
bb_success1066:
  %v3971 = load i64, ptr %slot44, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  store i64 0, ptr %p3972, align 8, !alias.scope !3, !noalias !4
  %v3973 = load i64, ptr %slot14, align 8
  %p3974 = inttoptr i64 %v3973 to ptr
  %ld3975 = load i32, ptr %p3974, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3975, ptr %slot665, align 8
  %v3976 = load i32, ptr %slot665, align 8
  %cv3977 = zext i32 %v3976 to i64
  %cond3978 = icmp ne i64 %cv3977, 0
  br i1 %cond3978, label %bb_rcslotdrop1069, label %bb_rcslotdone1069
bb_rcslotdrop1069:
  %v3979 = load i64, ptr %slot14, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  store i32 0, ptr %p3980, align 4, !alias.scope !3, !noalias !4
  %v3981 = load i64, ptr %slot20, align 8
  store i64 %v3981, ptr %slot666, align 8
  %v3982 = load i64, ptr %slot15, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %ld3984 = load i32, ptr %p3983, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3984, ptr %slot667, align 8
  %v3985 = load i32, ptr %slot667, align 8
  %op3986 = and i32 %v3985, 28
  store i32 %op3986, ptr %slot668, align 8
  %v3987 = load i32, ptr %slot668, align 8
  %cv3988 = zext i32 %v3987 to i64
  %cond3989 = icmp ne i64 %cv3988, 0
  br i1 %cond3989, label %bb_rcslotrole1069, label %bb_rcslotowner1069
bb_rcslotrole1069:
  %v3990 = load i64, ptr %slot55, align 8
  store i64 %v3990, ptr %slot669, align 8
  %v3991 = load i64, ptr %slot669, align 8
  %v3992 = load i64, ptr %slot666, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v3991, i64 %v3992) nomerge, !dbg !152
  br label %bb_rcslotdone1069
bb_rcslotowner1069:
  %v3993 = load i64, ptr %slot55, align 8
  store i64 %v3993, ptr %slot670, align 8
  %v3994 = load i64, ptr %slot670, align 8
  %v3995 = load i64, ptr %slot666, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v3994, i64 %v3995) nomerge, !dbg !152
  br label %bb_rcslotdone1069
bb_rcslotdone1069:
  %v3996 = load i64, ptr %slot23, align 8
  store i64 %v3996, ptr %slot671, align 8
  %v3997 = load i64, ptr %slot671, align 8
  %p3999 = inttoptr i64 %v3997 to ptr
  %gep4000 = getelementptr i8, ptr %p3999, i64 24
  %op3998 = ptrtoint ptr %gep4000 to i64
  store i64 %op3998, ptr %slot672, align 8
  %v4001 = load i64, ptr %slot672, align 8
  %p4002 = inttoptr i64 %v4001 to ptr
  %ld4003 = load i32, ptr %p4002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4003, ptr %slot673, align 8
  %v4004 = load i32, ptr %slot673, align 8
  %cv4005 = zext i32 %v4004 to i64
  %cond4006 = icmp ne i64 %cv4005, 0
  br i1 %cond4006, label %bb_rcsendactive1077, label %bb_rcsenddone1077
bb_rcsendactive1077:
  %v4007 = load i64, ptr %slot55, align 8
  %p4009 = inttoptr i64 %v4007 to ptr
  %gep4010 = getelementptr i8, ptr %p4009, i64 5640
  %op4008 = ptrtoint ptr %gep4010 to i64
  store i64 %op4008, ptr %slot674, align 8
  %v4011 = load i64, ptr %slot674, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  %ld4013 = load i64, ptr %p4012, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4013, ptr %slot675, align 8
  %v4014 = load i64, ptr %slot675, align 8
  %op4015 = add i64 %v4014, 248
  store i64 %op4015, ptr %slot676, align 8
  %v4016 = load i64, ptr %slot676, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %ld4018 = load i64, ptr %p4017, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4018, ptr %slot677, align 8
  %v4019 = load i64, ptr %slot677, align 8
  %v4020 = load i64, ptr %slot671, align 8
  %cmp4021 = icmp eq i64 %v4019, %v4020
  %cv4022 = zext i1 %cmp4021 to i32
  store i32 %cv4022, ptr %slot678, align 8
  %v4023 = load i32, ptr %slot678, align 8
  %cv4024 = zext i32 %v4023 to i64
  %cond4025 = icmp ne i64 %cv4024, 0
  br i1 %cond4025, label %bb_rcs1085, label %bb_rcsendslow1077
bb_rcs1085:
  %v4026 = load i64, ptr %slot675, align 8
  %op4027 = add i64 %v4026, 200
  store i64 %op4027, ptr %slot679, align 8
  %v4028 = load i64, ptr %slot679, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  %ld4030 = load i64, ptr %p4029, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4030, ptr %slot680, align 8
  %v4031 = load i64, ptr %slot680, align 8
  %cmp4032 = icmp eq i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot681, align 8
  %v4034 = load i32, ptr %slot681, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcs1089, label %bb_rcsendslow1077
bb_rcs1089:
  %v4037 = load i64, ptr %slot671, align 8
  %p4039 = inttoptr i64 %v4037 to ptr
  %gep4040 = getelementptr i8, ptr %p4039, i64 16
  %op4038 = ptrtoint ptr %gep4040 to i64
  store i64 %op4038, ptr %slot682, align 8
  %v4041 = load i64, ptr %slot682, align 8
  %p4042 = inttoptr i64 %v4041 to ptr
  %ld4043 = load i64, ptr %p4042, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4043, ptr %slot683, align 8
  %v4044 = load i64, ptr %slot683, align 8
  %cmp4045 = icmp ne i64 %v4044, 0
  %cv4046 = zext i1 %cmp4045 to i32
  store i32 %cv4046, ptr %slot684, align 8
  %v4047 = load i32, ptr %slot684, align 8
  %cv4048 = zext i32 %v4047 to i64
  %cond4049 = icmp ne i64 %cv4048, 0
  br i1 %cond4049, label %bb_rcsendnode1077, label %bb_rcsendunlink1077
bb_rcsendnode1077:
  %v4050 = load i64, ptr %slot683, align 8
  %op4051 = add i64 %v4050, 0
  store i64 %op4051, ptr %slot685, align 8
  %v4052 = load i64, ptr %slot685, align 8
  %p4053 = inttoptr i64 %v4052 to ptr
  %ld4054 = load i64, ptr %p4053, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4054, ptr %slot686, align 8
  %v4055 = load i64, ptr %slot686, align 8
  %cmp4056 = icmp eq i64 %v4055, 0
  %cv4057 = zext i1 %cmp4056 to i32
  store i32 %cv4057, ptr %slot687, align 8
  %v4058 = load i32, ptr %slot687, align 8
  %cv4059 = zext i32 %v4058 to i64
  %cond4060 = icmp ne i64 %cv4059, 0
  br i1 %cond4060, label %bb_rcs1096, label %bb_rcsendslow1077
bb_rcs1096:
  %v4061 = load i64, ptr %slot675, align 8
  %op4062 = add i64 %v4061, 264
  store i64 %op4062, ptr %slot688, align 8
  %v4063 = load i64, ptr %slot688, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  %ld4065 = load i64, ptr %p4064, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4065, ptr %slot689, align 8
  %v4066 = load i64, ptr %slot689, align 8
  %cmp4067 = icmp ult i64 %v4066, 32
  %cv4068 = zext i1 %cmp4067 to i32
  store i32 %cv4068, ptr %slot690, align 8
  %v4069 = load i32, ptr %slot690, align 8
  %cv4070 = zext i32 %v4069 to i64
  %cond4071 = icmp ne i64 %cv4070, 0
  br i1 %cond4071, label %bb_rcs1100, label %bb_rcsendslow1077
bb_rcs1100:
  %v4072 = load i64, ptr %slot683, align 8
  %op4073 = add i64 %v4072, 8
  store i64 %op4073, ptr %slot691, align 8
  %v4074 = load i64, ptr %slot691, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  %ld4076 = load i64, ptr %p4075, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4076, ptr %slot692, align 8
  %v4077 = load i64, ptr %slot692, align 8
  %cmp4078 = icmp ne i64 %v4077, 0
  %cv4079 = zext i1 %cmp4078 to i32
  store i32 %cv4079, ptr %slot693, align 8
  %v4080 = load i32, ptr %slot693, align 8
  %cv4081 = zext i32 %v4080 to i64
  %cond4082 = icmp ne i64 %cv4081, 0
  br i1 %cond4082, label %bb_rcs1104, label %bb_rcsendslow1077
bb_rcs1104:
  %v4083 = load i64, ptr %slot692, align 8
  %op4084 = sub i64 %v4083, 16
  store i64 %op4084, ptr %slot694, align 8
  %v4085 = load i64, ptr %slot692, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  %rgep4087 = getelementptr i8, ptr %p4086, i64 -16
  %ld4088 = load i64, ptr %rgep4087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4088, ptr %slot695, align 8
  %v4089 = load i64, ptr %slot695, align 8
  %op4090 = and i64 %v4089, 4611686018427387907
  store i64 %op4090, ptr %slot696, align 8
  %v4091 = load i64, ptr %slot696, align 8
  %cmp4092 = icmp eq i64 %v4091, 0
  %cv4093 = zext i1 %cmp4092 to i32
  store i32 %cv4093, ptr %slot697, align 8
  %v4094 = load i32, ptr %slot697, align 8
  %cv4095 = zext i32 %v4094 to i64
  %cond4096 = icmp ne i64 %cv4095, 0
  br i1 %cond4096, label %bb_rcs1109, label %bb_rcsendslow1077
bb_rcs1109:
  %v4097 = load i64, ptr %slot692, align 8
  %op4098 = sub i64 %v4097, 24
  store i64 %op4098, ptr %slot698, align 8
  %v4099 = load i64, ptr %slot692, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  %rgep4101 = getelementptr i8, ptr %p4100, i64 -24
  %ld4102 = load i64, ptr %rgep4101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4102, ptr %slot699, align 8
  %v4103 = load i64, ptr %slot699, align 8
  %cmp4104 = icmp ne i64 %v4103, 0
  %cv4105 = zext i1 %cmp4104 to i32
  store i32 %cv4105, ptr %slot700, align 8
  %v4106 = load i32, ptr %slot700, align 8
  %cv4107 = zext i32 %v4106 to i64
  %cond4108 = icmp ne i64 %cv4107, 0
  br i1 %cond4108, label %bb_rcs1113, label %bb_rcsendslow1077
bb_rcs1113:
  %v4109 = load i64, ptr %slot692, align 8
  %op4110 = sub i64 %v4109, 32
  store i64 %op4110, ptr %slot701, align 8
  %v4111 = load i64, ptr %slot692, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  %rgep4113 = getelementptr i8, ptr %p4112, i64 -32
  %ld4114 = load i64, ptr %rgep4113, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4114, ptr %slot702, align 8
  %v4115 = load i64, ptr %slot699, align 8
  %cmp4116 = icmp ugt i64 %v4115, 1
  %cv4117 = zext i1 %cmp4116 to i32
  store i32 %cv4117, ptr %slot703, align 8
  %v4118 = load i64, ptr %slot702, align 8
  %cmp4119 = icmp ne i64 %v4118, 0
  %cv4120 = zext i1 %cmp4119 to i32
  store i32 %cv4120, ptr %slot704, align 8
  %v4121 = load i32, ptr %slot703, align 8
  %v4122 = load i32, ptr %slot704, align 8
  %op4123 = or i32 %v4121, %v4122
  store i32 %op4123, ptr %slot705, align 8
  %v4124 = load i32, ptr %slot705, align 8
  %cv4125 = zext i32 %v4124 to i64
  %cond4126 = icmp ne i64 %cv4125, 0
  br i1 %cond4126, label %bb_rcs1119, label %bb_rcsendslow1077
bb_rcs1119:
  %v4127 = load i64, ptr %slot683, align 8
  %op4128 = add i64 %v4127, 32
  store i64 %op4128, ptr %slot706, align 8
  %v4129 = load i64, ptr %slot706, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  %ld4131 = load i64, ptr %p4130, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4131, ptr %slot707, align 8
  %v4132 = load i64, ptr %slot707, align 8
  %cmp4133 = icmp ne i64 %v4132, 0
  %cv4134 = zext i1 %cmp4133 to i32
  store i32 %cv4134, ptr %slot708, align 8
  %v4135 = load i32, ptr %slot708, align 8
  %cv4136 = zext i32 %v4135 to i64
  %cond4137 = icmp ne i64 %cv4136, 0
  br i1 %cond4137, label %bb_rcsendbacking1077, label %bb_rcsendcommit1077
bb_rcsendbacking1077:
  %v4138 = load i64, ptr %slot707, align 8
  %op4139 = sub i64 %v4138, 16
  store i64 %op4139, ptr %slot709, align 8
  %v4140 = load i64, ptr %slot707, align 8
  %p4141 = inttoptr i64 %v4140 to ptr
  %rgep4142 = getelementptr i8, ptr %p4141, i64 -16
  %ld4143 = load i64, ptr %rgep4142, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4143, ptr %slot710, align 8
  %v4144 = load i64, ptr %slot710, align 8
  %op4145 = and i64 %v4144, 4611686018427387907
  store i64 %op4145, ptr %slot711, align 8
  %v4146 = load i64, ptr %slot711, align 8
  %cmp4147 = icmp eq i64 %v4146, 0
  %cv4148 = zext i1 %cmp4147 to i32
  store i32 %cv4148, ptr %slot712, align 8
  %v4149 = load i32, ptr %slot712, align 8
  %cv4150 = zext i32 %v4149 to i64
  %cond4151 = icmp ne i64 %cv4150, 0
  br i1 %cond4151, label %bb_rcs1127, label %bb_rcsendslow1077
bb_rcs1127:
  %v4152 = load i64, ptr %slot707, align 8
  %op4153 = sub i64 %v4152, 24
  store i64 %op4153, ptr %slot713, align 8
  %v4154 = load i64, ptr %slot707, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  %rgep4156 = getelementptr i8, ptr %p4155, i64 -24
  %ld4157 = load i64, ptr %rgep4156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4157, ptr %slot714, align 8
  %v4158 = load i64, ptr %slot714, align 8
  %cmp4159 = icmp ne i64 %v4158, 0
  %cv4160 = zext i1 %cmp4159 to i32
  store i32 %cv4160, ptr %slot715, align 8
  %v4161 = load i32, ptr %slot715, align 8
  %cv4162 = zext i32 %v4161 to i64
  %cond4163 = icmp ne i64 %cv4162, 0
  br i1 %cond4163, label %bb_rcs1131, label %bb_rcsendslow1077
bb_rcs1131:
  %v4164 = load i64, ptr %slot707, align 8
  %op4165 = sub i64 %v4164, 32
  store i64 %op4165, ptr %slot716, align 8
  %v4166 = load i64, ptr %slot707, align 8
  %p4167 = inttoptr i64 %v4166 to ptr
  %rgep4168 = getelementptr i8, ptr %p4167, i64 -32
  %ld4169 = load i64, ptr %rgep4168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4169, ptr %slot717, align 8
  %v4170 = load i64, ptr %slot714, align 8
  %cmp4171 = icmp ugt i64 %v4170, 1
  %cv4172 = zext i1 %cmp4171 to i32
  store i32 %cv4172, ptr %slot718, align 8
  %v4173 = load i64, ptr %slot717, align 8
  %cmp4174 = icmp ne i64 %v4173, 0
  %cv4175 = zext i1 %cmp4174 to i32
  store i32 %cv4175, ptr %slot719, align 8
  %v4176 = load i32, ptr %slot718, align 8
  %v4177 = load i32, ptr %slot719, align 8
  %op4178 = or i32 %v4176, %v4177
  store i32 %op4178, ptr %slot720, align 8
  %v4179 = load i32, ptr %slot720, align 8
  %cv4180 = zext i32 %v4179 to i64
  %cond4181 = icmp ne i64 %cv4180, 0
  br i1 %cond4181, label %bb_rcs1137, label %bb_rcsendslow1077
bb_rcs1137:
  br label %bb_rcsendcommit1077
bb_rcsendcommit1077:
  %v4182 = load i64, ptr %slot683, align 8
  %op4183 = add i64 %v4182, 24
  store i64 %op4183, ptr %slot721, align 8
  %v4184 = load i64, ptr %slot721, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %ld4186 = load i32, ptr %p4185, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4186, ptr %slot722, align 8
  %v4187 = load i32, ptr %slot722, align 8
  %cv4188 = zext i32 %v4187 to i64
  %cond4189 = icmp ne i64 %cv4188, 0
  br i1 %cond4189, label %bb_rcsendrestore1077, label %bb_rcsendreturned1077
bb_rcsendrestore1077:
  %v4190 = load i64, ptr %slot683, align 8
  %op4191 = add i64 %v4190, 16
  store i64 %op4191, ptr %slot723, align 8
  %v4192 = load i64, ptr %slot723, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  %ld4194 = load i64, ptr %p4193, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4194, ptr %slot724, align 8
  %v4195 = load i64, ptr %slot695, align 8
  %op4196 = and i64 %v4195, 17293822569102704639
  store i64 %op4196, ptr %slot725, align 8
  %v4197 = load i64, ptr %slot725, align 8
  %v4198 = load i64, ptr %slot724, align 8
  %op4199 = or i64 %v4197, %v4198
  store i64 %op4199, ptr %slot726, align 8
  %v4200 = load i64, ptr %slot692, align 8
  %op4201 = sub i64 %v4200, 16
  store i64 %op4201, ptr %slot727, align 8
  %v4202 = load i64, ptr %slot726, align 8
  %v4203 = load i64, ptr %slot692, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  %rgep4205 = getelementptr i8, ptr %p4204, i64 -16
  store i64 %v4202, ptr %rgep4205, align 8, !alias.scope !9, !noalias !10
  %v4206 = load i64, ptr %slot671, align 8
  %p4208 = inttoptr i64 %v4206 to ptr
  %gep4209 = getelementptr i8, ptr %p4208, i64 16
  %op4207 = ptrtoint ptr %gep4209 to i64
  store i64 %op4207, ptr %slot728, align 8
  br label %bb_rcsendreturned1077
bb_rcsendreturned1077:
  %v4210 = load i64, ptr %slot728, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  store i64 0, ptr %p4211, align 8, !alias.scope !3, !noalias !4
  %v4212 = load i64, ptr %slot675, align 8
  %op4213 = add i64 %v4212, 256
  store i64 %op4213, ptr %slot729, align 8
  %v4214 = load i64, ptr %slot729, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  %ld4216 = load i64, ptr %p4215, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4216, ptr %slot730, align 8
  %v4217 = load i64, ptr %slot683, align 8
  %op4218 = add i64 %v4217, 0
  store i64 %op4218, ptr %slot731, align 8
  %v4219 = load i64, ptr %slot730, align 8
  %v4220 = load i64, ptr %slot731, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  store i64 %v4219, ptr %p4221, align 8, !alias.scope !9999998, !noalias !9999999
  %v4222 = load i64, ptr %slot675, align 8
  %op4223 = add i64 %v4222, 256
  store i64 %op4223, ptr %slot732, align 8
  %v4224 = load i64, ptr %slot683, align 8
  %v4225 = load i64, ptr %slot732, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  store i64 %v4224, ptr %p4226, align 8, !alias.scope !9999998, !noalias !9999999
  %v4227 = load i64, ptr %slot675, align 8
  %op4228 = add i64 %v4227, 264
  store i64 %op4228, ptr %slot733, align 8
  %v4229 = load i64, ptr %slot733, align 8
  %p4230 = inttoptr i64 %v4229 to ptr
  %ld4231 = load i64, ptr %p4230, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4231, ptr %slot734, align 8
  %v4232 = load i64, ptr %slot734, align 8
  %op4233 = add i64 %v4232, 1
  store i64 %op4233, ptr %slot735, align 8
  %v4234 = load i64, ptr %slot735, align 8
  %v4235 = load i64, ptr %slot733, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  store i64 %v4234, ptr %p4236, align 8, !alias.scope !9999998, !noalias !9999999
  %v4237 = load i64, ptr %slot55, align 8
  %p4239 = inttoptr i64 %v4237 to ptr
  %gep4240 = getelementptr i8, ptr %p4239, i64 24
  %op4238 = ptrtoint ptr %gep4240 to i64
  store i64 %op4238, ptr %slot736, align 8
  %v4241 = load i64, ptr %slot736, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %ld4243 = load i64, ptr %p4242, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4243, ptr %slot737, align 8
  %v4244 = load i64, ptr %slot737, align 8
  %op4245 = add i64 %v4244, 18446744073709551576
  store i64 %op4245, ptr %slot738, align 8
  %v4246 = load i64, ptr %slot738, align 8
  %v4247 = load i64, ptr %slot736, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  store i64 %v4246, ptr %p4248, align 8, !alias.scope !9999998, !noalias !9999999
  %v4249 = load i64, ptr %slot675, align 8
  %op4250 = add i64 %v4249, 48
  store i64 %op4250, ptr %slot739, align 8
  %v4251 = load i64, ptr %slot739, align 8
  %p4252 = inttoptr i64 %v4251 to ptr
  %ld4253 = load i64, ptr %p4252, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4253, ptr %slot740, align 8
  %v4254 = load i64, ptr %slot740, align 8
  %op4255 = add i64 %v4254, 18446744073709551576
  store i64 %op4255, ptr %slot741, align 8
  %v4256 = load i64, ptr %slot741, align 8
  %v4257 = load i64, ptr %slot739, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  store i64 %v4256, ptr %p4258, align 8, !alias.scope !9999998, !noalias !9999999
  %v4259 = load i64, ptr %slot707, align 8
  %cmp4260 = icmp ne i64 %v4259, 0
  %cv4261 = zext i1 %cmp4260 to i32
  store i32 %cv4261, ptr %slot742, align 8
  %v4262 = load i32, ptr %slot742, align 8
  %cv4263 = zext i32 %v4262 to i64
  %cond4264 = icmp ne i64 %cv4263, 0
  br i1 %cond4264, label %bb_rcsenddropbacking1077, label %bb_rcsenddroppayload1077
bb_rcsenddropbacking1077:
  %v4265 = load i64, ptr %slot707, align 8
  %op4266 = sub i64 %v4265, 24
  store i64 %op4266, ptr %slot743, align 8
  %v4267 = load i64, ptr %slot707, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  %rgep4269 = getelementptr i8, ptr %p4268, i64 -24
  %ld4270 = load i64, ptr %rgep4269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4270, ptr %slot744, align 8
  %v4271 = load i64, ptr %slot744, align 8
  %op4272 = add i64 %v4271, 18446744073709551615
  store i64 %op4272, ptr %slot745, align 8
  %v4273 = load i64, ptr %slot745, align 8
  %v4274 = load i64, ptr %slot707, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  %rgep4276 = getelementptr i8, ptr %p4275, i64 -24
  store i64 %v4273, ptr %rgep4276, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1077
bb_rcsenddroppayload1077:
  %v4277 = load i64, ptr %slot692, align 8
  %op4278 = sub i64 %v4277, 24
  store i64 %op4278, ptr %slot746, align 8
  %v4279 = load i64, ptr %slot692, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  %rgep4281 = getelementptr i8, ptr %p4280, i64 -24
  %ld4282 = load i64, ptr %rgep4281, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4282, ptr %slot747, align 8
  %v4283 = load i64, ptr %slot747, align 8
  %op4284 = add i64 %v4283, 18446744073709551615
  store i64 %op4284, ptr %slot748, align 8
  %v4285 = load i64, ptr %slot748, align 8
  %v4286 = load i64, ptr %slot692, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  %rgep4288 = getelementptr i8, ptr %p4287, i64 -24
  store i64 %v4285, ptr %rgep4288, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1077
bb_rcsendunlink1077:
  %v4289 = load i64, ptr %slot671, align 8
  %p4291 = inttoptr i64 %v4289 to ptr
  %gep4292 = getelementptr i8, ptr %p4291, i64 8
  %op4290 = ptrtoint ptr %gep4292 to i64
  store i64 %op4290, ptr %slot749, align 8
  %v4293 = load i64, ptr %slot749, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  %ld4295 = load i64, ptr %p4294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4295, ptr %slot750, align 8
  %v4296 = load i64, ptr %slot675, align 8
  %op4297 = add i64 %v4296, 248
  store i64 %op4297, ptr %slot751, align 8
  %v4298 = load i64, ptr %slot750, align 8
  %v4299 = load i64, ptr %slot751, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  store i64 %v4298, ptr %p4300, align 8, !alias.scope !9999998, !noalias !9999999
  %v4301 = load i64, ptr %slot671, align 8
  %p4303 = inttoptr i64 %v4301 to ptr
  %gep4304 = getelementptr i8, ptr %p4303, i64 24
  %op4302 = ptrtoint ptr %gep4304 to i64
  store i64 %op4302, ptr %slot752, align 8
  %v4305 = load i64, ptr %slot671, align 8
  %p4307 = inttoptr i64 %v4305 to ptr
  %gep4308 = getelementptr i8, ptr %p4307, i64 8
  %op4306 = ptrtoint ptr %gep4308 to i64
  store i64 %op4306, ptr %slot753, align 8
  %v4309 = load i64, ptr %slot752, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i32 0, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot753, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  store i64 0, ptr %p4312, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1077
bb_rcsendslow1077:
  %v4313 = load i64, ptr %slot1, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  %v4315 = load i64, ptr %slot671, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p4314, ptr %p4316) nomerge, !dbg !152
  br label %bb_rcsenddone1077
bb_rcsenddone1077:
  %v4317 = load i64, ptr %slot44, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  store i64 0, ptr %p4318, align 8, !alias.scope !3, !noalias !4
  %v4319 = load i64, ptr %slot34, align 8
  %v4320 = load i64, ptr %slot44, align 8
  %p4321 = inttoptr i64 %v4320 to ptr
  store i64 %v4319, ptr %p4321, align 8, !alias.scope !3, !noalias !4
  %v4322 = load i64, ptr %slot44, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i64, ptr %p4323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4324, ptr %slot754, align 8
  %v4325 = load i64, ptr %slot12, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  %ld4327 = load i32, ptr %p4326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4327, ptr %slot755, align 8
  %v4328 = load i64, ptr %slot13, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %ld4330 = load i32, ptr %p4329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4330, ptr %slot756, align 8
  %v4331 = load i32, ptr %slot756, align 8
  %op4332 = and i32 %v4331, 24
  store i32 %op4332, ptr %slot756, align 8
  %v4333 = load i32, ptr %slot756, align 8
  %cmp4334 = icmp eq i32 %v4333, 0
  %cv4335 = zext i1 %cmp4334 to i32
  store i32 %cv4335, ptr %slot757, align 8
  %v4336 = load i32, ptr %slot755, align 8
  %v4337 = load i32, ptr %slot757, align 8
  %op4338 = and i32 %v4336, %v4337
  store i32 %op4338, ptr %slot758, align 8
  %v4339 = load i32, ptr %slot758, align 8
  %cv4340 = zext i32 %v4339 to i64
  %cond4341 = icmp ne i64 %cv4340, 0
  br i1 %cond4341, label %bb_rcprivateown1178, label %bb_rcprivateloan1178
bb_rcprivateown1178:
  %v4342 = load i64, ptr %slot22, align 8
  store i64 %v4342, ptr %slot759, align 8
  %v4343 = load i64, ptr %slot56, align 8
  store i64 %v4343, ptr %slot760, align 8
  %v4344 = load i64, ptr %slot55, align 8
  %v4345 = load i64, ptr %slot759, align 8
  %v4346 = load i64, ptr %slot754, align 8
  %v4347 = load i64, ptr %slot760, align 8
  %cv4348 = trunc i64 %v4347 to i32
  %call4349 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4344, i64 %v4345, i64 %v4346, i32 %cv4348) nomerge, !dbg !154
  store i32 %call4349, ptr %slot761, align 8
  %v4350 = load i32, ptr %slot761, align 8
  %cv4351 = zext i32 %v4350 to i64
  %cond4352 = icmp ne i64 %cv4351, 0
  br i1 %cond4352, label %bb_rcsuccess1182, label %bb_rcfailure1182
bb_rcfailure1182:
  %v4353 = load i64, ptr %slot55, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %call4355 = call i32 @myl_rc_take_failure(ptr %p4354) nomerge, !dbg !154
  store i32 %call4355, ptr %slot762, align 8
  %v4356 = load i64, ptr %slot1, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  %v4358 = load i32, ptr %slot762, align 8
  %call4359 = call i32 @myl_qbe_rc_status(ptr %p4357, i32 %v4358) nomerge, !dbg !154
  store i32 %call4359, ptr %slot763, align 8
  br label %bb_failure
bb_rcsuccess1182:
  %v4360 = load i64, ptr %slot12, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i32 0, ptr %p4361, align 4, !alias.scope !3, !noalias !4
  %v4362 = load i64, ptr %slot17, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  store i32 2, ptr %p4363, align 4, !alias.scope !3, !noalias !4
  %v4364 = load i64, ptr %slot16, align 8
  %p4365 = inttoptr i64 %v4364 to ptr
  store i32 1, ptr %p4365, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1178
bb_rcprivateloan1178:
  %v4366 = load i64, ptr %slot22, align 8
  store i64 %v4366, ptr %slot764, align 8
  %v4367 = load i64, ptr %slot55, align 8
  %v4368 = load i64, ptr %slot764, align 8
  %v4369 = load i64, ptr %slot754, align 8
  %call4370 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v4367, i64 %v4368, i64 %v4369) nomerge, !dbg !154
  store i32 %call4370, ptr %slot765, align 8
  %v4371 = load i32, ptr %slot765, align 8
  %cv4372 = zext i32 %v4371 to i64
  %cond4373 = icmp ne i64 %cv4372, 0
  br i1 %cond4373, label %bb_rcsuccess1190, label %bb_rcfailure1190
bb_rcfailure1190:
  %v4374 = load i64, ptr %slot55, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  %call4376 = call i32 @myl_rc_take_failure(ptr %p4375) nomerge, !dbg !154
  store i32 %call4376, ptr %slot766, align 8
  %v4377 = load i64, ptr %slot1, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  %v4379 = load i32, ptr %slot766, align 8
  %call4380 = call i32 @myl_qbe_rc_status(ptr %p4378, i32 %v4379) nomerge, !dbg !154
  store i32 %call4380, ptr %slot767, align 8
  br label %bb_failure
bb_rcsuccess1190:
  %v4381 = load i64, ptr %slot17, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i32 2, ptr %p4382, align 4, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot17, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  store i32 16, ptr %p4384, align 4, !alias.scope !3, !noalias !4
  %v4385 = load i64, ptr %slot16, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  store i32 1, ptr %p4386, align 4, !alias.scope !3, !noalias !4
  %v4387 = load i64, ptr %slot12, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  %ld4389 = load i32, ptr %p4388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4389, ptr %slot768, align 8
  %v4390 = load i32, ptr %slot768, align 8
  %cv4391 = zext i32 %v4390 to i64
  %cond4392 = icmp ne i64 %cv4391, 0
  br i1 %cond4392, label %bb_rcslotdrop1198, label %bb_rcslotdone1198
bb_rcslotdrop1198:
  %v4393 = load i64, ptr %slot12, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  store i32 0, ptr %p4394, align 4, !alias.scope !3, !noalias !4
  %v4395 = load i64, ptr %slot19, align 8
  store i64 %v4395, ptr %slot769, align 8
  %v4396 = load i64, ptr %slot13, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %ld4398 = load i32, ptr %p4397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4398, ptr %slot770, align 8
  %v4399 = load i32, ptr %slot770, align 8
  %op4400 = and i32 %v4399, 28
  store i32 %op4400, ptr %slot771, align 8
  %v4401 = load i32, ptr %slot771, align 8
  %cv4402 = zext i32 %v4401 to i64
  %cond4403 = icmp ne i64 %cv4402, 0
  br i1 %cond4403, label %bb_rcslotrole1198, label %bb_rcslotowner1198
bb_rcslotrole1198:
  %v4404 = load i64, ptr %slot55, align 8
  store i64 %v4404, ptr %slot772, align 8
  %v4405 = load i64, ptr %slot772, align 8
  %v4406 = load i64, ptr %slot769, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4405, i64 %v4406) nomerge, !dbg !154
  br label %bb_rcslotdone1198
bb_rcslotowner1198:
  %v4407 = load i64, ptr %slot55, align 8
  store i64 %v4407, ptr %slot773, align 8
  %v4408 = load i64, ptr %slot773, align 8
  %v4409 = load i64, ptr %slot769, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4408, i64 %v4409) nomerge, !dbg !154
  br label %bb_rcslotdone1198
bb_rcslotdone1198:
  br label %bb_rcprivateprepared1178
bb_rcprivateprepared1178:
  %v4410 = load i64, ptr %slot10, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  %ld4412 = load i32, ptr %p4411, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4412, ptr %slot774, align 8
  %v4413 = load i32, ptr %slot774, align 8
  %cv4414 = zext i32 %v4413 to i64
  %cond4415 = icmp ne i64 %cv4414, 0
  br i1 %cond4415, label %bb_rcslotdrop1208, label %bb_rcslotdone1208
bb_rcslotdrop1208:
  %v4416 = load i64, ptr %slot10, align 8
  %p4417 = inttoptr i64 %v4416 to ptr
  store i32 0, ptr %p4417, align 4, !alias.scope !3, !noalias !4
  %v4418 = load i64, ptr %slot41, align 8
  store i64 %v4418, ptr %slot775, align 8
  %v4419 = load i64, ptr %slot11, align 8
  %p4420 = inttoptr i64 %v4419 to ptr
  %ld4421 = load i32, ptr %p4420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4421, ptr %slot776, align 8
  %v4422 = load i32, ptr %slot776, align 8
  %op4423 = and i32 %v4422, 28
  store i32 %op4423, ptr %slot777, align 8
  %v4424 = load i32, ptr %slot777, align 8
  %cv4425 = zext i32 %v4424 to i64
  %cond4426 = icmp ne i64 %cv4425, 0
  br i1 %cond4426, label %bb_rcslotrole1208, label %bb_rcslotowner1208
bb_rcslotrole1208:
  %v4427 = load i64, ptr %slot55, align 8
  store i64 %v4427, ptr %slot778, align 8
  %v4428 = load i64, ptr %slot778, align 8
  %v4429 = load i64, ptr %slot775, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4428, i64 %v4429) nomerge, !dbg !154
  br label %bb_rcslotdone1208
bb_rcslotowner1208:
  %v4430 = load i64, ptr %slot55, align 8
  store i64 %v4430, ptr %slot779, align 8
  %v4431 = load i64, ptr %slot779, align 8
  %v4432 = load i64, ptr %slot775, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4431, i64 %v4432) nomerge, !dbg !154
  br label %bb_rcslotdone1208
bb_rcslotdone1208:
  %v4433 = load i64, ptr %slot41, align 8
  store i64 %v4433, ptr %slot780, align 8
  %v4434 = load i64, ptr %slot22, align 8
  store i64 %v4434, ptr %slot781, align 8
  %v4435 = load i64, ptr %slot781, align 8
  %v4436 = load i64, ptr %slot780, align 8
  %p4437 = inttoptr i64 %v4435 to ptr
  %p4438 = inttoptr i64 %v4436 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4438, ptr %p4437, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4439 = load i64, ptr %slot16, align 8
  %p4440 = inttoptr i64 %v4439 to ptr
  store i32 0, ptr %p4440, align 4, !alias.scope !3, !noalias !4
  %v4441 = load i64, ptr %slot11, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i32 2, ptr %p4442, align 4, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot17, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i32, ptr %p4444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4445, ptr %slot782, align 8
  %v4446 = load i32, ptr %slot782, align 8
  %v4447 = load i64, ptr %slot11, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  store i32 %v4446, ptr %p4448, align 4, !alias.scope !3, !noalias !4
  %v4449 = load i64, ptr %slot10, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  store i32 1, ptr %p4450, align 4, !alias.scope !3, !noalias !4
  %v4451 = load i64, ptr %slot28, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  %ld4453 = load i64, ptr %p4452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4453, ptr %slot783, align 8
  %v4454 = load i64, ptr %slot783, align 8
  %v4455 = load i64, ptr %slot44, align 8
  %p4456 = inttoptr i64 %v4455 to ptr
  store i64 %v4454, ptr %p4456, align 8, !alias.scope !3, !noalias !4
  %v4457 = load i64, ptr %slot44, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  %ld4459 = load i64, ptr %p4458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4459, ptr %slot784, align 8
  %v4460 = load i64, ptr %slot784, align 8
  %op4461 = add i64 %v4460, 376
  store i64 %op4461, ptr %slot785, align 8
  %v4462 = load i64, ptr %slot785, align 8
  %p4463 = inttoptr i64 %v4462 to ptr
  %ld4464 = load i64, ptr %p4463, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4464, ptr %slot786, align 8
  %v4465 = load i64, ptr %slot786, align 8
  %v4466 = load i64, ptr %slot44, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  store i64 %v4465, ptr %p4467, align 8, !alias.scope !3, !noalias !4
  %v4468 = load i64, ptr %slot12, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %ld4470 = load i32, ptr %p4469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4470, ptr %slot787, align 8
  %v4471 = load i32, ptr %slot787, align 8
  %cv4472 = zext i32 %v4471 to i64
  %cond4473 = icmp ne i64 %cv4472, 0
  br i1 %cond4473, label %bb_rcslotdrop1228, label %bb_rcslotdone1228
bb_rcslotdrop1228:
  %v4474 = load i64, ptr %slot12, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  store i32 0, ptr %p4475, align 4, !alias.scope !3, !noalias !4
  %v4476 = load i64, ptr %slot19, align 8
  store i64 %v4476, ptr %slot788, align 8
  %v4477 = load i64, ptr %slot13, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  %ld4479 = load i32, ptr %p4478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4479, ptr %slot789, align 8
  %v4480 = load i32, ptr %slot789, align 8
  %op4481 = and i32 %v4480, 28
  store i32 %op4481, ptr %slot790, align 8
  %v4482 = load i32, ptr %slot790, align 8
  %cv4483 = zext i32 %v4482 to i64
  %cond4484 = icmp ne i64 %cv4483, 0
  br i1 %cond4484, label %bb_rcslotrole1228, label %bb_rcslotowner1228
bb_rcslotrole1228:
  %v4485 = load i64, ptr %slot55, align 8
  store i64 %v4485, ptr %slot791, align 8
  %v4486 = load i64, ptr %slot791, align 8
  %v4487 = load i64, ptr %slot788, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4486, i64 %v4487) nomerge, !dbg !156
  br label %bb_rcslotdone1228
bb_rcslotowner1228:
  %v4488 = load i64, ptr %slot55, align 8
  store i64 %v4488, ptr %slot792, align 8
  %v4489 = load i64, ptr %slot792, align 8
  %v4490 = load i64, ptr %slot788, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4489, i64 %v4490) nomerge, !dbg !156
  br label %bb_rcslotdone1228
bb_rcslotdone1228:
  %v4491 = load i64, ptr %slot44, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %ld4493 = load i64, ptr %p4492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4493, ptr %slot793, align 8
  %v4494 = load i64, ptr %slot28, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  %ld4496 = load i64, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4496, ptr %slot794, align 8
  %v4497 = load i64, ptr %slot12, align 8
  %p4498 = inttoptr i64 %v4497 to ptr
  %ld4499 = load i32, ptr %p4498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4499, ptr %slot795, align 8
  %v4500 = load i32, ptr %slot795, align 8
  %cv4501 = zext i32 %v4500 to i64
  %cond4502 = icmp ne i64 %cv4501, 0
  br i1 %cond4502, label %bb_rcslotdrop1240, label %bb_rcslotdone1240
bb_rcslotdrop1240:
  %v4503 = load i64, ptr %slot12, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  store i32 0, ptr %p4504, align 4, !alias.scope !3, !noalias !4
  %v4505 = load i64, ptr %slot19, align 8
  store i64 %v4505, ptr %slot796, align 8
  %v4506 = load i64, ptr %slot13, align 8
  %p4507 = inttoptr i64 %v4506 to ptr
  %ld4508 = load i32, ptr %p4507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4508, ptr %slot797, align 8
  %v4509 = load i32, ptr %slot797, align 8
  %op4510 = and i32 %v4509, 28
  store i32 %op4510, ptr %slot798, align 8
  %v4511 = load i32, ptr %slot798, align 8
  %cv4512 = zext i32 %v4511 to i64
  %cond4513 = icmp ne i64 %cv4512, 0
  br i1 %cond4513, label %bb_rcslotrole1240, label %bb_rcslotowner1240
bb_rcslotrole1240:
  %v4514 = load i64, ptr %slot55, align 8
  store i64 %v4514, ptr %slot799, align 8
  %v4515 = load i64, ptr %slot796, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  %ld4517 = load i64, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4517, ptr %slot800, align 8
  %v4518 = load i64, ptr %slot800, align 8
  %cmp4519 = icmp ne i64 %v4518, 0
  %cv4520 = zext i1 %cmp4519 to i32
  store i32 %cv4520, ptr %slot801, align 8
  %v4521 = load i32, ptr %slot801, align 8
  %cv4522 = zext i32 %v4521 to i64
  %cond4523 = icmp ne i64 %cv4522, 0
  br i1 %cond4523, label %bb_rcgnn1256, label %bb_rcgdone1256
bb_rcgnn1256:
  %v4524 = load i64, ptr %slot800, align 8
  %op4525 = sub i64 %v4524, 16
  store i64 %op4525, ptr %slot802, align 8
  %v4526 = load i64, ptr %slot800, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %rgep4528 = getelementptr i8, ptr %p4527, i64 -16
  %ld4529 = load i64, ptr %rgep4528, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4529, ptr %slot803, align 8
  %v4530 = load i64, ptr %slot803, align 8
  %op4531 = and i64 %v4530, 4611686018427387906
  store i64 %op4531, ptr %slot804, align 8
  %v4532 = load i64, ptr %slot804, align 8
  %cmp4533 = icmp ne i64 %v4532, 0
  %cv4534 = zext i1 %cmp4533 to i32
  store i32 %cv4534, ptr %slot805, align 8
  %v4535 = load i32, ptr %slot805, align 8
  %cv4536 = zext i32 %v4535 to i64
  %cond4537 = icmp ne i64 %cv4536, 0
  br i1 %cond4537, label %bb_rcgclear1256, label %bb_rcgcounted1256
bb_rcgcounted1256:
  %v4538 = load i64, ptr %slot800, align 8
  %op4539 = sub i64 %v4538, 24
  store i64 %op4539, ptr %slot806, align 8
  %v4540 = load i64, ptr %slot800, align 8
  %p4541 = inttoptr i64 %v4540 to ptr
  %rgep4542 = getelementptr i8, ptr %p4541, i64 -24
  %ld4543 = load i64, ptr %rgep4542, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4543, ptr %slot807, align 8
  %v4544 = load i64, ptr %slot807, align 8
  %op4545 = sub i64 %v4544, 1
  store i64 %op4545, ptr %slot808, align 8
  %v4546 = load i64, ptr %slot808, align 8
  %cmp4547 = icmp eq i64 %v4546, 0
  %cv4548 = zext i1 %cmp4547 to i32
  store i32 %cv4548, ptr %slot809, align 8
  %v4549 = load i32, ptr %slot809, align 8
  %cv4550 = zext i32 %v4549 to i64
  %cond4551 = icmp ne i64 %cv4550, 0
  br i1 %cond4551, label %bb_rcglast1256, label %bb_rcgdec1256
bb_rcglast1256:
  %v4552 = load i64, ptr %slot800, align 8
  %op4553 = sub i64 %v4552, 32
  store i64 %op4553, ptr %slot810, align 8
  %v4554 = load i64, ptr %slot800, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  %rgep4556 = getelementptr i8, ptr %p4555, i64 -32
  %ld4557 = load i64, ptr %rgep4556, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4557, ptr %slot811, align 8
  %v4558 = load i64, ptr %slot811, align 8
  %cmp4559 = icmp ne i64 %v4558, 0
  %cv4560 = zext i1 %cmp4559 to i32
  store i32 %cv4560, ptr %slot812, align 8
  %v4561 = load i32, ptr %slot812, align 8
  %cv4562 = zext i32 %v4561 to i64
  %cond4563 = icmp ne i64 %cv4562, 0
  br i1 %cond4563, label %bb_rcgdec1256, label %bb_rcgslow1256
bb_rcgslow1256:
  %v4564 = load i64, ptr %slot799, align 8
  %v4565 = load i64, ptr %slot796, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v4564, i64 %v4565) nomerge, !dbg !158
  br label %bb_rcgdone1256
bb_rcgdec1256:
  %v4566 = load i64, ptr %slot808, align 8
  %v4567 = load i64, ptr %slot800, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %rgep4569 = getelementptr i8, ptr %p4568, i64 -24
  store i64 %v4566, ptr %rgep4569, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1256
bb_rcgclear1256:
  %v4570 = load i64, ptr %slot796, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  store i64 0, ptr %p4571, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1256
bb_rcgdone1256:
  br label %bb_rcslotdone1240
bb_rcslotowner1240:
  %v4572 = load i64, ptr %slot55, align 8
  store i64 %v4572, ptr %slot813, align 8
  %v4573 = load i64, ptr %slot796, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  %ld4575 = load i64, ptr %p4574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4575, ptr %slot814, align 8
  %v4576 = load i64, ptr %slot814, align 8
  %cmp4577 = icmp ne i64 %v4576, 0
  %cv4578 = zext i1 %cmp4577 to i32
  store i32 %cv4578, ptr %slot815, align 8
  %v4579 = load i32, ptr %slot815, align 8
  %cv4580 = zext i32 %v4579 to i64
  %cond4581 = icmp ne i64 %cv4580, 0
  br i1 %cond4581, label %bb_rcgnn1271, label %bb_rcgdone1271
bb_rcgnn1271:
  %v4582 = load i64, ptr %slot814, align 8
  %op4583 = sub i64 %v4582, 16
  store i64 %op4583, ptr %slot816, align 8
  %v4584 = load i64, ptr %slot814, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  %rgep4586 = getelementptr i8, ptr %p4585, i64 -16
  %ld4587 = load i64, ptr %rgep4586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4587, ptr %slot817, align 8
  %v4588 = load i64, ptr %slot817, align 8
  %op4589 = and i64 %v4588, 4611686018427387906
  store i64 %op4589, ptr %slot818, align 8
  %v4590 = load i64, ptr %slot818, align 8
  %cmp4591 = icmp ne i64 %v4590, 0
  %cv4592 = zext i1 %cmp4591 to i32
  store i32 %cv4592, ptr %slot819, align 8
  %v4593 = load i32, ptr %slot819, align 8
  %cv4594 = zext i32 %v4593 to i64
  %cond4595 = icmp ne i64 %cv4594, 0
  br i1 %cond4595, label %bb_rcgclear1271, label %bb_rcgcounted1271
bb_rcgcounted1271:
  %v4596 = load i64, ptr %slot814, align 8
  %op4597 = sub i64 %v4596, 32
  store i64 %op4597, ptr %slot820, align 8
  %v4598 = load i64, ptr %slot814, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %rgep4600 = getelementptr i8, ptr %p4599, i64 -32
  %ld4601 = load i64, ptr %rgep4600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4601, ptr %slot821, align 8
  %v4602 = load i64, ptr %slot821, align 8
  %op4603 = sub i64 %v4602, 1
  store i64 %op4603, ptr %slot822, align 8
  %v4604 = load i64, ptr %slot822, align 8
  %cmp4605 = icmp eq i64 %v4604, 0
  %cv4606 = zext i1 %cmp4605 to i32
  store i32 %cv4606, ptr %slot823, align 8
  %v4607 = load i32, ptr %slot823, align 8
  %cv4608 = zext i32 %v4607 to i64
  %cond4609 = icmp ne i64 %cv4608, 0
  br i1 %cond4609, label %bb_rcglast1271, label %bb_rcgdec1271
bb_rcglast1271:
  %v4610 = load i64, ptr %slot814, align 8
  %op4611 = sub i64 %v4610, 24
  store i64 %op4611, ptr %slot824, align 8
  %v4612 = load i64, ptr %slot814, align 8
  %p4613 = inttoptr i64 %v4612 to ptr
  %rgep4614 = getelementptr i8, ptr %p4613, i64 -24
  %ld4615 = load i64, ptr %rgep4614, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4615, ptr %slot825, align 8
  %v4616 = load i64, ptr %slot825, align 8
  %cmp4617 = icmp ne i64 %v4616, 0
  %cv4618 = zext i1 %cmp4617 to i32
  store i32 %cv4618, ptr %slot826, align 8
  %v4619 = load i32, ptr %slot826, align 8
  %cv4620 = zext i32 %v4619 to i64
  %cond4621 = icmp ne i64 %cv4620, 0
  br i1 %cond4621, label %bb_rcgdec1271, label %bb_rcgslow1271
bb_rcgslow1271:
  %v4622 = load i64, ptr %slot813, align 8
  %v4623 = load i64, ptr %slot796, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v4622, i64 %v4623) nomerge, !dbg !158
  br label %bb_rcgdone1271
bb_rcgdec1271:
  %v4624 = load i64, ptr %slot822, align 8
  %v4625 = load i64, ptr %slot814, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %rgep4627 = getelementptr i8, ptr %p4626, i64 -32
  store i64 %v4624, ptr %rgep4627, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1271
bb_rcgclear1271:
  %v4628 = load i64, ptr %slot796, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  store i64 0, ptr %p4629, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1271
bb_rcgdone1271:
  br label %bb_rcslotdone1240
bb_rcslotdone1240:
  %v4630 = load i64, ptr %slot794, align 8
  %op4631 = add i64 %v4630, 376
  store i64 %op4631, ptr %slot827, align 8
  store i64 0, ptr %slot828, align 8
  %v4632 = load i64, ptr %slot827, align 8
  %p4633 = inttoptr i64 %v4632 to ptr
  %ld4634 = load i64, ptr %p4633, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4634, ptr %slot829, align 8
  %v4635 = load i64, ptr %slot829, align 8
  %cmp4636 = icmp ne i64 %v4635, 0
  %cv4637 = zext i1 %cmp4636 to i32
  store i32 %cv4637, ptr %slot830, align 8
  %v4638 = load i32, ptr %slot830, align 8
  %cv4639 = zext i32 %v4638 to i64
  %cond4640 = icmp ne i64 %cv4639, 0
  br i1 %cond4640, label %bb_rcguniquenn1277, label %bb_rcgunique1277
bb_rcguniquenn1277:
  %v4641 = load i64, ptr %slot829, align 8
  %op4642 = sub i64 %v4641, 16
  store i64 %op4642, ptr %slot831, align 8
  %v4643 = load i64, ptr %slot829, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  %rgep4645 = getelementptr i8, ptr %p4644, i64 -16
  %ld4646 = load i64, ptr %rgep4645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4646, ptr %slot832, align 8
  %v4647 = load i64, ptr %slot832, align 8
  %op4648 = and i64 %v4647, 6917529027641081858
  store i64 %op4648, ptr %slot833, align 8
  %v4649 = load i64, ptr %slot833, align 8
  %cmp4650 = icmp ne i64 %v4649, 0
  %cv4651 = zext i1 %cmp4650 to i32
  store i32 %cv4651, ptr %slot834, align 8
  %v4652 = load i32, ptr %slot834, align 8
  %cv4653 = zext i32 %v4652 to i64
  %cond4654 = icmp ne i64 %cv4653, 0
  br i1 %cond4654, label %bb_rcguniqueslow1277, label %bb_rcguniquecount1277
bb_rcguniquecount1277:
  %v4655 = load i64, ptr %slot829, align 8
  %op4656 = sub i64 %v4655, 32
  store i64 %op4656, ptr %slot835, align 8
  %v4657 = load i64, ptr %slot829, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  %rgep4659 = getelementptr i8, ptr %p4658, i64 -32
  %ld4660 = load i64, ptr %rgep4659, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4660, ptr %slot836, align 8
  %v4661 = load i64, ptr %slot836, align 8
  %cmp4662 = icmp ult i64 %v4661, 2
  %cv4663 = zext i1 %cmp4662 to i32
  store i32 %cv4663, ptr %slot837, align 8
  %v4664 = load i32, ptr %slot837, align 8
  %cv4665 = zext i32 %v4664 to i64
  %cond4666 = icmp ne i64 %cv4665, 0
  br i1 %cond4666, label %bb_rcgunique1277, label %bb_rcguniqueslow1277
bb_rcguniqueslow1277:
  %v4667 = load i64, ptr %slot1, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %p4669 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v4670 = load i64, ptr %slot827, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  %v4672 = load i64, ptr %slot828, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  %call4674 = call i32 @myl_qbe_rc_unique_field(ptr %p4668, ptr %p4669, ptr %p4671, ptr %p4673) nomerge, !dbg !158
  store i32 %call4674, ptr %slot838, align 8
  %v4675 = load i32, ptr %slot838, align 8
  %cv4676 = zext i32 %v4675 to i64
  %cond4677 = icmp ne i64 %cv4676, 0
  br i1 %cond4677, label %bb_rcunique1287, label %bb_failure
bb_rcunique1287:
  br label %bb_rcgunique1277
bb_rcgunique1277:
  %v4678 = load i64, ptr %slot827, align 8
  %p4679 = inttoptr i64 %v4678 to ptr
  %ld4680 = load i64, ptr %p4679, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4680, ptr %slot839, align 8
  %v4681 = load i64, ptr %slot839, align 8
  %v4682 = load i64, ptr %slot44, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  store i64 %v4681, ptr %p4683, align 8, !alias.scope !3, !noalias !4
  %v4684 = load i64, ptr %slot44, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %ld4686 = load i64, ptr %p4685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4686, ptr %slot840, align 8
  %v4687 = load i64, ptr %slot12, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  %ld4689 = load i32, ptr %p4688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4689, ptr %slot841, align 8
  %v4690 = load i32, ptr %slot841, align 8
  %cv4691 = zext i32 %v4690 to i64
  %cond4692 = icmp ne i64 %cv4691, 0
  br i1 %cond4692, label %bb_rcslotdrop1292, label %bb_rcslotdone1292
bb_rcslotdrop1292:
  %v4693 = load i64, ptr %slot12, align 8
  %p4694 = inttoptr i64 %v4693 to ptr
  store i32 0, ptr %p4694, align 4, !alias.scope !3, !noalias !4
  %v4695 = load i64, ptr %slot19, align 8
  store i64 %v4695, ptr %slot842, align 8
  %v4696 = load i64, ptr %slot13, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %ld4698 = load i32, ptr %p4697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4698, ptr %slot843, align 8
  %v4699 = load i32, ptr %slot843, align 8
  %op4700 = and i32 %v4699, 28
  store i32 %op4700, ptr %slot844, align 8
  %v4701 = load i32, ptr %slot844, align 8
  %cv4702 = zext i32 %v4701 to i64
  %cond4703 = icmp ne i64 %cv4702, 0
  br i1 %cond4703, label %bb_rcslotrole1292, label %bb_rcslotowner1292
bb_rcslotrole1292:
  %v4704 = load i64, ptr %slot55, align 8
  store i64 %v4704, ptr %slot845, align 8
  %v4705 = load i64, ptr %slot842, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  %ld4707 = load i64, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4707, ptr %slot846, align 8
  %v4708 = load i64, ptr %slot846, align 8
  %cmp4709 = icmp ne i64 %v4708, 0
  %cv4710 = zext i1 %cmp4709 to i32
  store i32 %cv4710, ptr %slot847, align 8
  %v4711 = load i32, ptr %slot847, align 8
  %cv4712 = zext i32 %v4711 to i64
  %cond4713 = icmp ne i64 %cv4712, 0
  br i1 %cond4713, label %bb_rcgnn1308, label %bb_rcgdone1308
bb_rcgnn1308:
  %v4714 = load i64, ptr %slot846, align 8
  %op4715 = sub i64 %v4714, 16
  store i64 %op4715, ptr %slot848, align 8
  %v4716 = load i64, ptr %slot846, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  %rgep4718 = getelementptr i8, ptr %p4717, i64 -16
  %ld4719 = load i64, ptr %rgep4718, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4719, ptr %slot849, align 8
  %v4720 = load i64, ptr %slot849, align 8
  %op4721 = and i64 %v4720, 4611686018427387906
  store i64 %op4721, ptr %slot850, align 8
  %v4722 = load i64, ptr %slot850, align 8
  %cmp4723 = icmp ne i64 %v4722, 0
  %cv4724 = zext i1 %cmp4723 to i32
  store i32 %cv4724, ptr %slot851, align 8
  %v4725 = load i32, ptr %slot851, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcgclear1308, label %bb_rcgcounted1308
bb_rcgcounted1308:
  %v4728 = load i64, ptr %slot846, align 8
  %op4729 = sub i64 %v4728, 24
  store i64 %op4729, ptr %slot852, align 8
  %v4730 = load i64, ptr %slot846, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  %rgep4732 = getelementptr i8, ptr %p4731, i64 -24
  %ld4733 = load i64, ptr %rgep4732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4733, ptr %slot853, align 8
  %v4734 = load i64, ptr %slot853, align 8
  %op4735 = sub i64 %v4734, 1
  store i64 %op4735, ptr %slot854, align 8
  %v4736 = load i64, ptr %slot854, align 8
  %cmp4737 = icmp eq i64 %v4736, 0
  %cv4738 = zext i1 %cmp4737 to i32
  store i32 %cv4738, ptr %slot855, align 8
  %v4739 = load i32, ptr %slot855, align 8
  %cv4740 = zext i32 %v4739 to i64
  %cond4741 = icmp ne i64 %cv4740, 0
  br i1 %cond4741, label %bb_rcglast1308, label %bb_rcgdec1308
bb_rcglast1308:
  %v4742 = load i64, ptr %slot846, align 8
  %op4743 = sub i64 %v4742, 32
  store i64 %op4743, ptr %slot856, align 8
  %v4744 = load i64, ptr %slot846, align 8
  %p4745 = inttoptr i64 %v4744 to ptr
  %rgep4746 = getelementptr i8, ptr %p4745, i64 -32
  %ld4747 = load i64, ptr %rgep4746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4747, ptr %slot857, align 8
  %v4748 = load i64, ptr %slot857, align 8
  %cmp4749 = icmp ne i64 %v4748, 0
  %cv4750 = zext i1 %cmp4749 to i32
  store i32 %cv4750, ptr %slot858, align 8
  %v4751 = load i32, ptr %slot858, align 8
  %cv4752 = zext i32 %v4751 to i64
  %cond4753 = icmp ne i64 %cv4752, 0
  br i1 %cond4753, label %bb_rcgdec1308, label %bb_rcgslow1308
bb_rcgslow1308:
  %v4754 = load i64, ptr %slot845, align 8
  %v4755 = load i64, ptr %slot842, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v4754, i64 %v4755) nomerge, !dbg !158
  br label %bb_rcgdone1308
bb_rcgdec1308:
  %v4756 = load i64, ptr %slot854, align 8
  %v4757 = load i64, ptr %slot846, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  %rgep4759 = getelementptr i8, ptr %p4758, i64 -24
  store i64 %v4756, ptr %rgep4759, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1308
bb_rcgclear1308:
  %v4760 = load i64, ptr %slot842, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  store i64 0, ptr %p4761, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1308
bb_rcgdone1308:
  br label %bb_rcslotdone1292
bb_rcslotowner1292:
  %v4762 = load i64, ptr %slot55, align 8
  store i64 %v4762, ptr %slot859, align 8
  %v4763 = load i64, ptr %slot842, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  %ld4765 = load i64, ptr %p4764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4765, ptr %slot860, align 8
  %v4766 = load i64, ptr %slot860, align 8
  %cmp4767 = icmp ne i64 %v4766, 0
  %cv4768 = zext i1 %cmp4767 to i32
  store i32 %cv4768, ptr %slot861, align 8
  %v4769 = load i32, ptr %slot861, align 8
  %cv4770 = zext i32 %v4769 to i64
  %cond4771 = icmp ne i64 %cv4770, 0
  br i1 %cond4771, label %bb_rcgnn1323, label %bb_rcgdone1323
bb_rcgnn1323:
  %v4772 = load i64, ptr %slot860, align 8
  %op4773 = sub i64 %v4772, 16
  store i64 %op4773, ptr %slot862, align 8
  %v4774 = load i64, ptr %slot860, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  %rgep4776 = getelementptr i8, ptr %p4775, i64 -16
  %ld4777 = load i64, ptr %rgep4776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4777, ptr %slot863, align 8
  %v4778 = load i64, ptr %slot863, align 8
  %op4779 = and i64 %v4778, 4611686018427387906
  store i64 %op4779, ptr %slot864, align 8
  %v4780 = load i64, ptr %slot864, align 8
  %cmp4781 = icmp ne i64 %v4780, 0
  %cv4782 = zext i1 %cmp4781 to i32
  store i32 %cv4782, ptr %slot865, align 8
  %v4783 = load i32, ptr %slot865, align 8
  %cv4784 = zext i32 %v4783 to i64
  %cond4785 = icmp ne i64 %cv4784, 0
  br i1 %cond4785, label %bb_rcgclear1323, label %bb_rcgcounted1323
bb_rcgcounted1323:
  %v4786 = load i64, ptr %slot860, align 8
  %op4787 = sub i64 %v4786, 32
  store i64 %op4787, ptr %slot866, align 8
  %v4788 = load i64, ptr %slot860, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  %rgep4790 = getelementptr i8, ptr %p4789, i64 -32
  %ld4791 = load i64, ptr %rgep4790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4791, ptr %slot867, align 8
  %v4792 = load i64, ptr %slot867, align 8
  %op4793 = sub i64 %v4792, 1
  store i64 %op4793, ptr %slot868, align 8
  %v4794 = load i64, ptr %slot868, align 8
  %cmp4795 = icmp eq i64 %v4794, 0
  %cv4796 = zext i1 %cmp4795 to i32
  store i32 %cv4796, ptr %slot869, align 8
  %v4797 = load i32, ptr %slot869, align 8
  %cv4798 = zext i32 %v4797 to i64
  %cond4799 = icmp ne i64 %cv4798, 0
  br i1 %cond4799, label %bb_rcglast1323, label %bb_rcgdec1323
bb_rcglast1323:
  %v4800 = load i64, ptr %slot860, align 8
  %op4801 = sub i64 %v4800, 24
  store i64 %op4801, ptr %slot870, align 8
  %v4802 = load i64, ptr %slot860, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  %rgep4804 = getelementptr i8, ptr %p4803, i64 -24
  %ld4805 = load i64, ptr %rgep4804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4805, ptr %slot871, align 8
  %v4806 = load i64, ptr %slot871, align 8
  %cmp4807 = icmp ne i64 %v4806, 0
  %cv4808 = zext i1 %cmp4807 to i32
  store i32 %cv4808, ptr %slot872, align 8
  %v4809 = load i32, ptr %slot872, align 8
  %cv4810 = zext i32 %v4809 to i64
  %cond4811 = icmp ne i64 %cv4810, 0
  br i1 %cond4811, label %bb_rcgdec1323, label %bb_rcgslow1323
bb_rcgslow1323:
  %v4812 = load i64, ptr %slot859, align 8
  %v4813 = load i64, ptr %slot842, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v4812, i64 %v4813) nomerge, !dbg !158
  br label %bb_rcgdone1323
bb_rcgdec1323:
  %v4814 = load i64, ptr %slot868, align 8
  %v4815 = load i64, ptr %slot860, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %rgep4817 = getelementptr i8, ptr %p4816, i64 -32
  store i64 %v4814, ptr %rgep4817, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1323
bb_rcgclear1323:
  %v4818 = load i64, ptr %slot842, align 8
  %p4819 = inttoptr i64 %v4818 to ptr
  store i64 0, ptr %p4819, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1323
bb_rcgdone1323:
  br label %bb_rcslotdone1292
bb_rcslotdone1292:
  %v4820 = load i64, ptr %slot840, align 8
  %v4821 = load i64, ptr %slot40, align 8
  %p4822 = inttoptr i64 %v4821 to ptr
  store i64 %v4820, ptr %p4822, align 8, !alias.scope !3, !noalias !4
  %v4823 = load i64, ptr %slot29, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  %ld4825 = load i64, ptr %p4824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4825, ptr %slot873, align 8
  %v4826 = load i64, ptr %slot873, align 8
  %v4827 = load i64, ptr %slot44, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  store i64 %v4826, ptr %p4828, align 8, !alias.scope !3, !noalias !4
  %v4829 = load i64, ptr %slot45, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  store i64 1, ptr %p4830, align 8, !alias.scope !3, !noalias !4
  %v4831 = load i64, ptr %slot45, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  %ld4833 = load i64, ptr %p4832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4833, ptr %slot874, align 8
  %v4834 = load i64, ptr %slot44, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  %ld4836 = load i64, ptr %p4835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4836, ptr %slot875, align 8
  %v4837 = load i64, ptr %slot875, align 8
  %v4838 = load i64, ptr %slot874, align 8
  %ovpair4840 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v4837, i64 %v4838)
  %op4839 = extractvalue { i64, i1 } %ovpair4840, 0
  %ov4841 = extractvalue { i64, i1 } %ovpair4840, 1
  store i64 %op4839, ptr %slot876, align 8
  %cv4842 = zext i1 %ov4841 to i64
  store i64 %cv4842, ptr %slot877, align 8
  %v4843 = load i64, ptr %slot877, align 8
  %cond4844 = icmp ne i64 %v4843, 0
  br i1 %cond4844, label %bb_overflow1367, label %bb_checked1367
bb_overflow1367:
  %v4845 = load i64, ptr %slot1, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  %v4847 = load i64, ptr %slot875, align 8
  %v4848 = load i64, ptr %slot874, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4846, i64 1, i64 %v4847, i64 %v4848, i64 64) nomerge, !dbg !160
  unreachable
bb_checked1367:
  %v4849 = load i64, ptr %slot876, align 8
  %v4850 = load i64, ptr %slot44, align 8
  %p4851 = inttoptr i64 %v4850 to ptr
  store i64 %v4849, ptr %p4851, align 8, !alias.scope !3, !noalias !4
  %v4852 = load i64, ptr %slot44, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  %ld4854 = load i64, ptr %p4853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4854, ptr %slot878, align 8
  %v4855 = load i64, ptr %slot878, align 8
  %v4856 = load i64, ptr %slot42, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  store i64 %v4855, ptr %p4857, align 8, !alias.scope !3, !noalias !4
  %v4858 = load i64, ptr %slot42, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  %ld4860 = load i64, ptr %p4859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4860, ptr %slot879, align 8
  %v4861 = load i64, ptr %slot879, align 8
  %v4862 = load i64, ptr %slot44, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  store i64 %v4861, ptr %p4863, align 8, !alias.scope !3, !noalias !4
  %v4864 = load i64, ptr %slot45, align 8
  %p4865 = inttoptr i64 %v4864 to ptr
  store i64 0, ptr %p4865, align 8, !alias.scope !3, !noalias !4
  %v4866 = load i64, ptr %slot45, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  %ld4868 = load i64, ptr %p4867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4868, ptr %slot880, align 8
  %v4869 = load i64, ptr %slot44, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i64, ptr %p4870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4871, ptr %slot881, align 8
  %v4872 = load i64, ptr %slot881, align 8
  %v4873 = load i64, ptr %slot880, align 8
  %cmp4874 = icmp slt i64 %v4872, %v4873
  %cv4875 = zext i1 %cmp4874 to i64
  store i64 %cv4875, ptr %slot882, align 8
  %v4876 = load i64, ptr %slot882, align 8
  %v4877 = load i64, ptr %slot44, align 8
  %p4878 = inttoptr i64 %v4877 to ptr
  store i64 %v4876, ptr %p4878, align 8, !alias.scope !3, !noalias !4
  %v4879 = load i64, ptr %slot44, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  %ld4881 = load i64, ptr %p4880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4881, ptr %slot883, align 8
  %v4882 = load i64, ptr %slot883, align 8
  %cond4883 = icmp ne i64 %v4882, 0
  br i1 %cond4883, label %bb_next1375, label %bb_i87
bb_next1375:
  %v4884 = load i64, ptr %slot40, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %ld4886 = load i64, ptr %p4885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4886, ptr %slot884, align 8
  %v4887 = load i64, ptr %slot884, align 8
  %op4888 = add i64 %v4887, 0
  store i64 %op4888, ptr %slot885, align 8
  %v4889 = load i64, ptr %slot885, align 8
  %p4890 = inttoptr i64 %v4889 to ptr
  %ld4891 = load i64, ptr %p4890, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4891, ptr %slot886, align 8
  %v4892 = load i64, ptr %slot886, align 8
  %v4893 = load i64, ptr %slot44, align 8
  %p4894 = inttoptr i64 %v4893 to ptr
  store i64 %v4892, ptr %p4894, align 8, !alias.scope !3, !noalias !4
  %v4895 = load i64, ptr %slot44, align 8
  %p4896 = inttoptr i64 %v4895 to ptr
  %ld4897 = load i64, ptr %p4896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4897, ptr %slot887, align 8
  %v4898 = load i64, ptr %slot887, align 8
  %cmp4899 = icmp ugt i64 %v4898, 9223372036854775807
  %cv4900 = zext i1 %cmp4899 to i64
  store i64 %cv4900, ptr %slot888, align 8
  %v4901 = load i64, ptr %slot888, align 8
  %cond4902 = icmp ne i64 %v4901, 0
  br i1 %cond4902, label %bb_cast_overflow1380, label %bb_cast_ok1380
bb_cast_overflow1380:
  %v4903 = load i64, ptr %slot1, align 8
  %p4904 = inttoptr i64 %v4903 to ptr
  %v4905 = load i64, ptr %slot887, align 8
  call void @myl_qbe_fail_cast(ptr %p4904, i64 %v4905, i64 320) nomerge, !dbg !162
  unreachable
bb_cast_ok1380:
  %v4906 = load i64, ptr %slot887, align 8
  %v4907 = load i64, ptr %slot44, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  store i64 %v4906, ptr %p4908, align 8, !alias.scope !3, !noalias !4
  %v4909 = load i64, ptr %slot42, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  %ld4911 = load i64, ptr %p4910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4911, ptr %slot889, align 8
  %v4912 = load i64, ptr %slot889, align 8
  %v4913 = load i64, ptr %slot45, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  store i64 %v4912, ptr %p4914, align 8, !alias.scope !3, !noalias !4
  %v4915 = load i64, ptr %slot45, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  %ld4917 = load i64, ptr %p4916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4917, ptr %slot890, align 8
  %v4918 = load i64, ptr %slot44, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  %ld4920 = load i64, ptr %p4919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4920, ptr %slot891, align 8
  %v4921 = load i64, ptr %slot891, align 8
  %v4922 = load i64, ptr %slot890, align 8
  %ovpair4924 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4921, i64 %v4922)
  %op4923 = extractvalue { i64, i1 } %ovpair4924, 0
  %ov4925 = extractvalue { i64, i1 } %ovpair4924, 1
  store i64 %op4923, ptr %slot892, align 8
  %v4926 = load i64, ptr %slot891, align 8
  %v4927 = load i64, ptr %slot892, align 8
  %op4928 = xor i64 %v4926, %v4927
  store i64 %op4928, ptr %slot893, align 8
  %v4929 = load i64, ptr %slot890, align 8
  %v4930 = load i64, ptr %slot892, align 8
  %op4931 = xor i64 %v4929, %v4930
  store i64 %op4931, ptr %slot894, align 8
  %v4932 = load i64, ptr %slot893, align 8
  %v4933 = load i64, ptr %slot894, align 8
  %op4934 = and i64 %v4932, %v4933
  store i64 %op4934, ptr %slot895, align 8
  %cv4935 = zext i1 %ov4925 to i64
  store i64 %cv4935, ptr %slot896, align 8
  %v4936 = load i64, ptr %slot896, align 8
  %cond4937 = icmp ne i64 %v4936, 0
  br i1 %cond4937, label %bb_overflow1384, label %bb_checked1384
bb_overflow1384:
  %v4938 = load i64, ptr %slot1, align 8
  %p4939 = inttoptr i64 %v4938 to ptr
  %v4940 = load i64, ptr %slot891, align 8
  %v4941 = load i64, ptr %slot890, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4939, i64 0, i64 %v4940, i64 %v4941, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1384:
  %v4942 = load i64, ptr %slot892, align 8
  %v4943 = load i64, ptr %slot44, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  store i64 %v4942, ptr %p4944, align 8, !alias.scope !3, !noalias !4
  %v4945 = load i64, ptr %slot44, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  %ld4947 = load i64, ptr %p4946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4947, ptr %slot897, align 8
  %v4948 = load i64, ptr %slot897, align 8
  %v4949 = load i64, ptr %slot42, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  store i64 %v4948, ptr %p4950, align 8, !alias.scope !3, !noalias !4
  br label %bb_i87
bb_i87:
  %v4951 = load i64, ptr %slot42, align 8
  %p4952 = inttoptr i64 %v4951 to ptr
  %ld4953 = load i64, ptr %p4952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4953, ptr %slot898, align 8
  %v4954 = load i64, ptr %slot898, align 8
  %v4955 = load i64, ptr %slot44, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  store i64 %v4954, ptr %p4956, align 8, !alias.scope !3, !noalias !4
  %v4957 = load i64, ptr %slot41, align 8
  %v4958 = load i64, ptr %slot49, align 8
  %p4959 = inttoptr i64 %v4957 to ptr
  %p4960 = inttoptr i64 %v4958 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4960, ptr %p4959, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4961 = load i64, ptr %slot49, align 8
  %v4962 = load i64, ptr %slot45, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  store i64 %v4961, ptr %p4963, align 8, !alias.scope !3, !noalias !4
  %v4964 = load i64, ptr %slot40, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %ld4966 = load i64, ptr %p4965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4966, ptr %slot899, align 8
  %v4967 = load i64, ptr %slot45, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i64, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4969, ptr %slot900, align 8
  %v4970 = load i64, ptr %slot44, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  %ld4972 = load i64, ptr %p4971, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4972, ptr %slot901, align 8
  %v4973 = load i64, ptr %slot899, align 8
  %p4974 = inttoptr i64 %v4973 to ptr
  %ld4975 = load i64, ptr %p4974, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4975, ptr %slot902, align 8
  %v4976 = load i64, ptr %slot901, align 8
  %v4977 = load i64, ptr %slot902, align 8
  %cmp4978 = icmp ult i64 %v4976, %v4977
  %cv4979 = zext i1 %cmp4978 to i64
  store i64 %cv4979, ptr %slot903, align 8
  %v4980 = load i64, ptr %slot903, align 8
  %cond4981 = icmp ne i64 %v4980, 0
  br i1 %cond4981, label %bb_success1397, label %bb_failed1397
bb_failed1397:
  %v4982 = load i64, ptr %slot1, align 8
  %p4983 = inttoptr i64 %v4982 to ptr
  %v4984 = load i64, ptr %slot901, align 8
  %v4985 = load i64, ptr %slot902, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4983, i64 %v4984, i64 %v4985) nomerge, !dbg !166
  unreachable
bb_success1397:
  %v4986 = load i64, ptr %slot45, align 8
  %p4987 = inttoptr i64 %v4986 to ptr
  %ld4988 = load i64, ptr %p4987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4988, ptr %slot904, align 8
  %v4989 = load i64, ptr %slot55, align 8
  %v4990 = load i64, ptr %slot899, align 8
  %v4991 = load i64, ptr %slot901, align 8
  %v4992 = load i64, ptr %slot904, align 8
  %call4993 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v4989, i64 %v4990, i64 %v4991, i64 %v4992) nomerge, !dbg !166
  store i32 %call4993, ptr %slot905, align 8
  %v4994 = load i32, ptr %slot905, align 8
  %cv4995 = zext i32 %v4994 to i64
  %cond4996 = icmp ne i64 %cv4995, 0
  br i1 %cond4996, label %bb_success1400, label %bb_failed1400
bb_failed1400:
  %v4997 = load i64, ptr %slot1, align 8
  %p4998 = inttoptr i64 %v4997 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4998) nomerge, !dbg !166
  unreachable
bb_success1400:
  %v4999 = load i64, ptr %slot44, align 8
  %p5000 = inttoptr i64 %v4999 to ptr
  store i64 0, ptr %p5000, align 8, !alias.scope !3, !noalias !4
  %v5001 = load i64, ptr %slot14, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  %ld5003 = load i32, ptr %p5002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5003, ptr %slot906, align 8
  %v5004 = load i32, ptr %slot906, align 8
  %cv5005 = zext i32 %v5004 to i64
  %cond5006 = icmp ne i64 %cv5005, 0
  br i1 %cond5006, label %bb_rcslotdrop1403, label %bb_rcslotdone1403
bb_rcslotdrop1403:
  %v5007 = load i64, ptr %slot14, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  store i32 0, ptr %p5008, align 4, !alias.scope !3, !noalias !4
  %v5009 = load i64, ptr %slot20, align 8
  store i64 %v5009, ptr %slot907, align 8
  %v5010 = load i64, ptr %slot15, align 8
  %p5011 = inttoptr i64 %v5010 to ptr
  %ld5012 = load i32, ptr %p5011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5012, ptr %slot908, align 8
  %v5013 = load i32, ptr %slot908, align 8
  %op5014 = and i32 %v5013, 28
  store i32 %op5014, ptr %slot909, align 8
  %v5015 = load i32, ptr %slot909, align 8
  %cv5016 = zext i32 %v5015 to i64
  %cond5017 = icmp ne i64 %cv5016, 0
  br i1 %cond5017, label %bb_rcslotrole1403, label %bb_rcslotowner1403
bb_rcslotrole1403:
  %v5018 = load i64, ptr %slot55, align 8
  store i64 %v5018, ptr %slot910, align 8
  %v5019 = load i64, ptr %slot910, align 8
  %v5020 = load i64, ptr %slot907, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5019, i64 %v5020) nomerge, !dbg !166
  br label %bb_rcslotdone1403
bb_rcslotowner1403:
  %v5021 = load i64, ptr %slot55, align 8
  store i64 %v5021, ptr %slot911, align 8
  %v5022 = load i64, ptr %slot911, align 8
  %v5023 = load i64, ptr %slot907, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5022, i64 %v5023) nomerge, !dbg !166
  br label %bb_rcslotdone1403
bb_rcslotdone1403:
  %v5024 = load i64, ptr %slot28, align 8
  %p5025 = inttoptr i64 %v5024 to ptr
  %ld5026 = load i64, ptr %p5025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5026, ptr %slot912, align 8
  %v5027 = load i64, ptr %slot912, align 8
  %v5028 = load i64, ptr %slot44, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  store i64 %v5027, ptr %p5029, align 8, !alias.scope !3, !noalias !4
  %v5030 = load i64, ptr %slot29, align 8
  %p5031 = inttoptr i64 %v5030 to ptr
  %ld5032 = load i64, ptr %p5031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5032, ptr %slot913, align 8
  %v5033 = load i64, ptr %slot913, align 8
  %v5034 = load i64, ptr %slot45, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  store i64 %v5033, ptr %p5035, align 8, !alias.scope !3, !noalias !4
  %v5036 = load i64, ptr %slot31, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  %ld5038 = load i64, ptr %p5037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5038, ptr %slot914, align 8
  %v5039 = load i64, ptr %slot914, align 8
  %v5040 = load i64, ptr %slot46, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  store i64 %v5039, ptr %p5041, align 8, !alias.scope !3, !noalias !4
  %v5042 = load i64, ptr %slot47, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  store i64 1, ptr %p5043, align 8, !alias.scope !3, !noalias !4
  %v5044 = load i64, ptr %slot44, align 8
  %p5045 = inttoptr i64 %v5044 to ptr
  %ld5046 = load i64, ptr %p5045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5046, ptr %slot915, align 8
  %v5047 = load i64, ptr %slot45, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %ld5049 = load i64, ptr %p5048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5049, ptr %slot916, align 8
  %v5050 = load i64, ptr %slot46, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  %ld5052 = load i64, ptr %p5051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5052, ptr %slot917, align 8
  %v5053 = load i64, ptr %slot47, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %ld5055 = load i64, ptr %p5054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5055, ptr %slot918, align 8
  %v5056 = load i64, ptr %slot1, align 8
  %v5057 = load i64, ptr %slot915, align 8
  %v5058 = load i64, ptr %slot916, align 8
  %v5059 = load i64, ptr %slot917, align 8
  %v5060 = load i64, ptr %slot918, align 8
  %call5061 = call i64 @myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195(i64 %v5056, i64 %v5057, i64 %v5058, i64 %v5059, i64 %v5060) nomerge, !dbg !168
  store i64 %call5061, ptr %slot919, align 8
  %v5062 = load i64, ptr %slot919, align 8
  %v5063 = load i64, ptr %slot44, align 8
  %p5064 = inttoptr i64 %v5063 to ptr
  store i64 %v5062, ptr %p5064, align 8, !alias.scope !3, !noalias !4
  %v5065 = load i64, ptr %slot12, align 8
  %p5066 = inttoptr i64 %v5065 to ptr
  %ld5067 = load i32, ptr %p5066, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5067, ptr %slot920, align 8
  %v5068 = load i32, ptr %slot920, align 8
  %cv5069 = zext i32 %v5068 to i64
  %cond5070 = icmp ne i64 %cv5069, 0
  br i1 %cond5070, label %bb_rcslotdrop1420, label %bb_rcslotdone1420
bb_rcslotdrop1420:
  %v5071 = load i64, ptr %slot12, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  store i32 0, ptr %p5072, align 4, !alias.scope !3, !noalias !4
  %v5073 = load i64, ptr %slot19, align 8
  store i64 %v5073, ptr %slot921, align 8
  %v5074 = load i64, ptr %slot13, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  %ld5076 = load i32, ptr %p5075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5076, ptr %slot922, align 8
  %v5077 = load i32, ptr %slot922, align 8
  %op5078 = and i32 %v5077, 28
  store i32 %op5078, ptr %slot923, align 8
  %v5079 = load i32, ptr %slot923, align 8
  %cv5080 = zext i32 %v5079 to i64
  %cond5081 = icmp ne i64 %cv5080, 0
  br i1 %cond5081, label %bb_rcslotrole1420, label %bb_rcslotowner1420
bb_rcslotrole1420:
  %v5082 = load i64, ptr %slot55, align 8
  store i64 %v5082, ptr %slot924, align 8
  %v5083 = load i64, ptr %slot924, align 8
  %v5084 = load i64, ptr %slot921, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5083, i64 %v5084) nomerge, !dbg !168
  br label %bb_rcslotdone1420
bb_rcslotowner1420:
  %v5085 = load i64, ptr %slot55, align 8
  store i64 %v5085, ptr %slot925, align 8
  %v5086 = load i64, ptr %slot925, align 8
  %v5087 = load i64, ptr %slot921, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5086, i64 %v5087) nomerge, !dbg !168
  br label %bb_rcslotdone1420
bb_rcslotdone1420:
  %v5088 = load i64, ptr %slot44, align 8
  %p5089 = inttoptr i64 %v5088 to ptr
  %ld5090 = load i64, ptr %p5089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5090, ptr %slot926, align 8
  %v5091 = load i64, ptr %slot23, align 8
  %p5093 = inttoptr i64 %v5091 to ptr
  %gep5094 = getelementptr i8, ptr %p5093, i64 24
  %op5092 = ptrtoint ptr %gep5094 to i64
  store i64 %op5092, ptr %slot927, align 8
  %v5095 = load i64, ptr %slot927, align 8
  %p5096 = inttoptr i64 %v5095 to ptr
  %ld5097 = load i32, ptr %p5096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5097, ptr %slot928, align 8
  %v5098 = load i64, ptr %slot25, align 8
  %p5100 = inttoptr i64 %v5098 to ptr
  %gep5101 = getelementptr i8, ptr %p5100, i64 24
  %op5099 = ptrtoint ptr %gep5101 to i64
  store i64 %op5099, ptr %slot929, align 8
  %v5102 = load i64, ptr %slot929, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  %ld5104 = load i32, ptr %p5103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5104, ptr %slot930, align 8
  %v5105 = load i32, ptr %slot928, align 8
  %v5106 = load i32, ptr %slot930, align 8
  %op5107 = or i32 %v5105, %v5106
  store i32 %op5107, ptr %slot931, align 8
  %v5108 = load i32, ptr %slot931, align 8
  %cv5109 = zext i32 %v5108 to i64
  %cond5110 = icmp ne i64 %cv5109, 0
  br i1 %cond5110, label %bb_rcscopesopen1433, label %bb_rcscopesclosed1433
bb_rcscopesopen1433:
  %v5111 = load i64, ptr %slot27, align 8
  %p5113 = inttoptr i64 %v5111 to ptr
  %gep5114 = getelementptr i8, ptr %p5113, i64 0
  %op5112 = ptrtoint ptr %gep5114 to i64
  store i64 %op5112, ptr %slot932, align 8
  %v5115 = load i64, ptr %slot23, align 8
  %v5116 = load i64, ptr %slot932, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  store i64 %v5115, ptr %p5117, align 8, !alias.scope !3, !noalias !4
  %v5118 = load i64, ptr %slot27, align 8
  %p5120 = inttoptr i64 %v5118 to ptr
  %gep5121 = getelementptr i8, ptr %p5120, i64 8
  %op5119 = ptrtoint ptr %gep5121 to i64
  store i64 %op5119, ptr %slot933, align 8
  %v5122 = load i64, ptr %slot25, align 8
  %v5123 = load i64, ptr %slot933, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i64 %v5122, ptr %p5124, align 8, !alias.scope !3, !noalias !4
  %v5125 = load i64, ptr %slot1, align 8
  %p5126 = inttoptr i64 %v5125 to ptr
  %v5127 = load i64, ptr %slot27, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5126, ptr %p5128, i64 2) nomerge, !dbg !170
  br label %bb_rcscopesclosed1433
bb_rcscopesclosed1433:
  %v5129 = load i64, ptr %slot12, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  %ld5131 = load i32, ptr %p5130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5131, ptr %slot934, align 8
  %v5132 = load i32, ptr %slot934, align 8
  %cv5133 = zext i32 %v5132 to i64
  %cond5134 = icmp ne i64 %cv5133, 0
  br i1 %cond5134, label %bb_rcslotdrop1438, label %bb_rcslotdone1438
bb_rcslotdrop1438:
  %v5135 = load i64, ptr %slot12, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  store i32 0, ptr %p5136, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1438
bb_rcslotdone1438:
  %v5137 = load i64, ptr %slot10, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  %ld5139 = load i32, ptr %p5138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5139, ptr %slot935, align 8
  %v5140 = load i32, ptr %slot935, align 8
  %cv5141 = zext i32 %v5140 to i64
  %cond5142 = icmp ne i64 %cv5141, 0
  br i1 %cond5142, label %bb_rcslotdrop1441, label %bb_rcslotdone1441
bb_rcslotdrop1441:
  %v5143 = load i64, ptr %slot10, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  store i32 0, ptr %p5144, align 4, !alias.scope !3, !noalias !4
  %v5145 = load i64, ptr %slot41, align 8
  store i64 %v5145, ptr %slot936, align 8
  %v5146 = load i64, ptr %slot11, align 8
  %p5147 = inttoptr i64 %v5146 to ptr
  %ld5148 = load i32, ptr %p5147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5148, ptr %slot937, align 8
  %v5149 = load i32, ptr %slot937, align 8
  %op5150 = and i32 %v5149, 28
  store i32 %op5150, ptr %slot938, align 8
  %v5151 = load i32, ptr %slot938, align 8
  %cv5152 = zext i32 %v5151 to i64
  %cond5153 = icmp ne i64 %cv5152, 0
  br i1 %cond5153, label %bb_rcslotrole1441, label %bb_rcslotowner1441
bb_rcslotrole1441:
  %v5154 = load i64, ptr %slot55, align 8
  store i64 %v5154, ptr %slot939, align 8
  %v5155 = load i64, ptr %slot939, align 8
  %v5156 = load i64, ptr %slot936, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5155, i64 %v5156) nomerge, !dbg !170
  br label %bb_rcslotdone1441
bb_rcslotowner1441:
  %v5157 = load i64, ptr %slot55, align 8
  store i64 %v5157, ptr %slot940, align 8
  %v5158 = load i64, ptr %slot940, align 8
  %v5159 = load i64, ptr %slot936, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5158, i64 %v5159) nomerge, !dbg !170
  br label %bb_rcslotdone1441
bb_rcslotdone1441:
  %v5160 = load i64, ptr %slot8, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  %ld5162 = load i32, ptr %p5161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5162, ptr %slot941, align 8
  %v5163 = load i32, ptr %slot941, align 8
  %cv5164 = zext i32 %v5163 to i64
  %cond5165 = icmp ne i64 %cv5164, 0
  br i1 %cond5165, label %bb_rcslotdrop1487, label %bb_rcslotdone1487
bb_rcslotdrop1487:
  %v5166 = load i64, ptr %slot8, align 8
  %p5167 = inttoptr i64 %v5166 to ptr
  store i32 0, ptr %p5167, align 4, !alias.scope !3, !noalias !4
  %v5168 = load i64, ptr %slot38, align 8
  store i64 %v5168, ptr %slot942, align 8
  %v5169 = load i64, ptr %slot9, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  %ld5171 = load i32, ptr %p5170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5171, ptr %slot943, align 8
  %v5172 = load i32, ptr %slot943, align 8
  %op5173 = and i32 %v5172, 28
  store i32 %op5173, ptr %slot944, align 8
  %v5174 = load i32, ptr %slot944, align 8
  %cv5175 = zext i32 %v5174 to i64
  %cond5176 = icmp ne i64 %cv5175, 0
  br i1 %cond5176, label %bb_rcslotrole1487, label %bb_rcslotowner1487
bb_rcslotrole1487:
  %v5177 = load i64, ptr %slot55, align 8
  store i64 %v5177, ptr %slot945, align 8
  %v5178 = load i64, ptr %slot945, align 8
  %v5179 = load i64, ptr %slot942, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v5178, i64 %v5179) nomerge, !dbg !170
  br label %bb_rcslotdone1487
bb_rcslotowner1487:
  %v5180 = load i64, ptr %slot55, align 8
  store i64 %v5180, ptr %slot946, align 8
  %v5181 = load i64, ptr %slot946, align 8
  %v5182 = load i64, ptr %slot942, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v5181, i64 %v5182) nomerge, !dbg !170
  br label %bb_rcslotdone1487
bb_rcslotdone1487:
  %v5183 = load i64, ptr %slot6, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  %ld5185 = load i32, ptr %p5184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5185, ptr %slot947, align 8
  %v5186 = load i32, ptr %slot947, align 8
  %cv5187 = zext i32 %v5186 to i64
  %cond5188 = icmp ne i64 %cv5187, 0
  br i1 %cond5188, label %bb_rcslotdrop1533, label %bb_rcslotdone1533
bb_rcslotdrop1533:
  %v5189 = load i64, ptr %slot6, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  store i32 0, ptr %p5190, align 4, !alias.scope !3, !noalias !4
  %v5191 = load i64, ptr %slot34, align 8
  store i64 %v5191, ptr %slot948, align 8
  %v5192 = load i64, ptr %slot7, align 8
  %p5193 = inttoptr i64 %v5192 to ptr
  %ld5194 = load i32, ptr %p5193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5194, ptr %slot949, align 8
  %v5195 = load i32, ptr %slot949, align 8
  %op5196 = and i32 %v5195, 28
  store i32 %op5196, ptr %slot950, align 8
  %v5197 = load i32, ptr %slot950, align 8
  %cv5198 = zext i32 %v5197 to i64
  %cond5199 = icmp ne i64 %cv5198, 0
  br i1 %cond5199, label %bb_rcslotrole1533, label %bb_rcslotowner1533
bb_rcslotrole1533:
  %v5200 = load i64, ptr %slot55, align 8
  store i64 %v5200, ptr %slot951, align 8
  %v5201 = load i64, ptr %slot951, align 8
  %v5202 = load i64, ptr %slot948, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5201, i64 %v5202) nomerge, !dbg !170
  br label %bb_rcslotdone1533
bb_rcslotowner1533:
  %v5203 = load i64, ptr %slot55, align 8
  store i64 %v5203, ptr %slot952, align 8
  %v5204 = load i64, ptr %slot952, align 8
  %v5205 = load i64, ptr %slot948, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5204, i64 %v5205) nomerge, !dbg !170
  br label %bb_rcslotdone1533
bb_rcslotdone1533:
  %v5206 = load i64, ptr %slot926, align 8
  ret i64 %v5206
bb_i98:
  %v5207 = load i64, ptr %slot28, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  %ld5209 = load i64, ptr %p5208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5209, ptr %slot953, align 8
  %v5210 = load i64, ptr %slot953, align 8
  %v5211 = load i64, ptr %slot44, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  store i64 %v5210, ptr %p5212, align 8, !alias.scope !3, !noalias !4
  %v5213 = load i64, ptr %slot29, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %ld5215 = load i64, ptr %p5214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5215, ptr %slot954, align 8
  %v5216 = load i64, ptr %slot954, align 8
  %v5217 = load i64, ptr %slot45, align 8
  %p5218 = inttoptr i64 %v5217 to ptr
  store i64 %v5216, ptr %p5218, align 8, !alias.scope !3, !noalias !4
  %v5219 = load i64, ptr %slot46, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  store i64 1, ptr %p5220, align 8, !alias.scope !3, !noalias !4
  %v5221 = load i64, ptr %slot46, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  %ld5223 = load i64, ptr %p5222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5223, ptr %slot955, align 8
  %v5224 = load i64, ptr %slot45, align 8
  %p5225 = inttoptr i64 %v5224 to ptr
  %ld5226 = load i64, ptr %p5225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5226, ptr %slot956, align 8
  %v5227 = load i64, ptr %slot956, align 8
  %v5228 = load i64, ptr %slot955, align 8
  %ovpair5230 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v5227, i64 %v5228)
  %op5229 = extractvalue { i64, i1 } %ovpair5230, 0
  %ov5231 = extractvalue { i64, i1 } %ovpair5230, 1
  store i64 %op5229, ptr %slot957, align 8
  %cv5232 = zext i1 %ov5231 to i64
  store i64 %cv5232, ptr %slot958, align 8
  %v5233 = load i64, ptr %slot958, align 8
  %cond5234 = icmp ne i64 %v5233, 0
  br i1 %cond5234, label %bb_overflow1627, label %bb_checked1627
bb_overflow1627:
  %v5235 = load i64, ptr %slot1, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %v5237 = load i64, ptr %slot956, align 8
  %v5238 = load i64, ptr %slot955, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5236, i64 1, i64 %v5237, i64 %v5238, i64 64) nomerge, !dbg !172
  unreachable
bb_checked1627:
  %v5239 = load i64, ptr %slot957, align 8
  %v5240 = load i64, ptr %slot45, align 8
  %p5241 = inttoptr i64 %v5240 to ptr
  store i64 %v5239, ptr %p5241, align 8, !alias.scope !3, !noalias !4
  %v5242 = load i64, ptr %slot30, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  %ld5244 = load i64, ptr %p5243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5244, ptr %slot959, align 8
  %v5245 = load i64, ptr %slot959, align 8
  %v5246 = load i64, ptr %slot46, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  store i64 %v5245, ptr %p5247, align 8, !alias.scope !3, !noalias !4
  %v5248 = load i64, ptr %slot44, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  %ld5250 = load i64, ptr %p5249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5250, ptr %slot960, align 8
  %v5251 = load i64, ptr %slot45, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  %ld5253 = load i64, ptr %p5252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5253, ptr %slot961, align 8
  %v5254 = load i64, ptr %slot46, align 8
  %p5255 = inttoptr i64 %v5254 to ptr
  %ld5256 = load i64, ptr %p5255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5256, ptr %slot962, align 8
  %v5257 = load i64, ptr %slot1, align 8
  %v5258 = load i64, ptr %slot960, align 8
  %v5259 = load i64, ptr %slot961, align 8
  %v5260 = load i64, ptr %slot962, align 8
  %call5261 = call i64 @myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69(i64 %v5257, i64 %v5258, i64 %v5259, i64 %v5260) nomerge, !dbg !174
  store i64 %call5261, ptr %slot963, align 8
  %v5262 = load i64, ptr %slot963, align 8
  %v5263 = load i64, ptr %slot44, align 8
  %p5264 = inttoptr i64 %v5263 to ptr
  store i64 %v5262, ptr %p5264, align 8, !alias.scope !3, !noalias !4
  %v5265 = load i64, ptr %slot12, align 8
  %p5266 = inttoptr i64 %v5265 to ptr
  %ld5267 = load i32, ptr %p5266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5267, ptr %slot964, align 8
  %v5268 = load i32, ptr %slot964, align 8
  %cv5269 = zext i32 %v5268 to i64
  %cond5270 = icmp ne i64 %cv5269, 0
  br i1 %cond5270, label %bb_rcslotdrop1636, label %bb_rcslotdone1636
bb_rcslotdrop1636:
  %v5271 = load i64, ptr %slot12, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  store i32 0, ptr %p5272, align 4, !alias.scope !3, !noalias !4
  %v5273 = load i64, ptr %slot19, align 8
  store i64 %v5273, ptr %slot965, align 8
  %v5274 = load i64, ptr %slot13, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  %ld5276 = load i32, ptr %p5275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5276, ptr %slot966, align 8
  %v5277 = load i32, ptr %slot966, align 8
  %op5278 = and i32 %v5277, 28
  store i32 %op5278, ptr %slot967, align 8
  %v5279 = load i32, ptr %slot967, align 8
  %cv5280 = zext i32 %v5279 to i64
  %cond5281 = icmp ne i64 %cv5280, 0
  br i1 %cond5281, label %bb_rcslotrole1636, label %bb_rcslotowner1636
bb_rcslotrole1636:
  %v5282 = load i64, ptr %slot55, align 8
  store i64 %v5282, ptr %slot968, align 8
  %v5283 = load i64, ptr %slot968, align 8
  %v5284 = load i64, ptr %slot965, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5283, i64 %v5284) nomerge, !dbg !174
  br label %bb_rcslotdone1636
bb_rcslotowner1636:
  %v5285 = load i64, ptr %slot55, align 8
  store i64 %v5285, ptr %slot969, align 8
  %v5286 = load i64, ptr %slot969, align 8
  %v5287 = load i64, ptr %slot965, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5286, i64 %v5287) nomerge, !dbg !174
  br label %bb_rcslotdone1636
bb_rcslotdone1636:
  %v5288 = load i64, ptr %slot44, align 8
  %p5289 = inttoptr i64 %v5288 to ptr
  %ld5290 = load i64, ptr %p5289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5290, ptr %slot970, align 8
  %v5291 = load i64, ptr %slot970, align 8
  %v5292 = load i64, ptr %slot43, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  store i64 %v5291, ptr %p5293, align 8, !alias.scope !3, !noalias !4
  %v5294 = load i64, ptr %slot43, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %ld5296 = load i64, ptr %p5295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5296, ptr %slot971, align 8
  %v5297 = load i64, ptr %slot971, align 8
  %v5298 = load i64, ptr %slot44, align 8
  %p5299 = inttoptr i64 %v5298 to ptr
  store i64 %v5297, ptr %p5299, align 8, !alias.scope !3, !noalias !4
  %v5300 = load i64, ptr %slot45, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  store i64 18446744073709551615, ptr %p5301, align 8, !alias.scope !3, !noalias !4
  %v5302 = load i64, ptr %slot45, align 8
  %p5303 = inttoptr i64 %v5302 to ptr
  %ld5304 = load i64, ptr %p5303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5304, ptr %slot972, align 8
  %v5305 = load i64, ptr %slot44, align 8
  %p5306 = inttoptr i64 %v5305 to ptr
  %ld5307 = load i64, ptr %p5306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5307, ptr %slot973, align 8
  %v5308 = load i64, ptr %slot973, align 8
  %v5309 = load i64, ptr %slot972, align 8
  %cmp5310 = icmp ne i64 %v5308, %v5309
  %cv5311 = zext i1 %cmp5310 to i64
  store i64 %cv5311, ptr %slot974, align 8
  %v5312 = load i64, ptr %slot974, align 8
  %v5313 = load i64, ptr %slot44, align 8
  %p5314 = inttoptr i64 %v5313 to ptr
  store i64 %v5312, ptr %p5314, align 8, !alias.scope !3, !noalias !4
  %v5315 = load i64, ptr %slot44, align 8
  %p5316 = inttoptr i64 %v5315 to ptr
  %ld5317 = load i64, ptr %p5316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5317, ptr %slot975, align 8
  %v5318 = load i64, ptr %slot975, align 8
  %cond5319 = icmp ne i64 %v5318, 0
  br i1 %cond5319, label %bb_next1686, label %bb_i115
bb_next1686:
  %v5320 = load i64, ptr %slot28, align 8
  %p5321 = inttoptr i64 %v5320 to ptr
  %ld5322 = load i64, ptr %p5321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5322, ptr %slot976, align 8
  %v5323 = load i64, ptr %slot976, align 8
  %v5324 = load i64, ptr %slot44, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  store i64 %v5323, ptr %p5325, align 8, !alias.scope !3, !noalias !4
  %v5326 = load i64, ptr %slot29, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  %ld5328 = load i64, ptr %p5327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5328, ptr %slot977, align 8
  %v5329 = load i64, ptr %slot977, align 8
  %v5330 = load i64, ptr %slot45, align 8
  %p5331 = inttoptr i64 %v5330 to ptr
  store i64 %v5329, ptr %p5331, align 8, !alias.scope !3, !noalias !4
  %v5332 = load i64, ptr %slot43, align 8
  %p5333 = inttoptr i64 %v5332 to ptr
  %ld5334 = load i64, ptr %p5333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5334, ptr %slot978, align 8
  %v5335 = load i64, ptr %slot978, align 8
  %v5336 = load i64, ptr %slot46, align 8
  %p5337 = inttoptr i64 %v5336 to ptr
  store i64 %v5335, ptr %p5337, align 8, !alias.scope !3, !noalias !4
  %v5338 = load i64, ptr %slot47, align 8
  %p5339 = inttoptr i64 %v5338 to ptr
  store i64 0, ptr %p5339, align 8, !alias.scope !3, !noalias !4
  %v5340 = load i64, ptr %slot44, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %ld5342 = load i64, ptr %p5341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5342, ptr %slot979, align 8
  %v5343 = load i64, ptr %slot45, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  %ld5345 = load i64, ptr %p5344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5345, ptr %slot980, align 8
  %v5346 = load i64, ptr %slot46, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  %ld5348 = load i64, ptr %p5347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5348, ptr %slot981, align 8
  %v5349 = load i64, ptr %slot47, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  %ld5351 = load i64, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5351, ptr %slot982, align 8
  %v5352 = load i64, ptr %slot1, align 8
  %v5353 = load i64, ptr %slot979, align 8
  %v5354 = load i64, ptr %slot980, align 8
  %v5355 = load i64, ptr %slot981, align 8
  %v5356 = load i64, ptr %slot982, align 8
  %call5357 = call i64 @myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195(i64 %v5352, i64 %v5353, i64 %v5354, i64 %v5355, i64 %v5356) nomerge, !dbg !176
  store i64 %call5357, ptr %slot983, align 8
  %v5358 = load i64, ptr %slot983, align 8
  %v5359 = load i64, ptr %slot44, align 8
  %p5360 = inttoptr i64 %v5359 to ptr
  store i64 %v5358, ptr %p5360, align 8, !alias.scope !3, !noalias !4
  %v5361 = load i64, ptr %slot12, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  %ld5363 = load i32, ptr %p5362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5363, ptr %slot984, align 8
  %v5364 = load i32, ptr %slot984, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcslotdrop1696, label %bb_rcslotdone1696
bb_rcslotdrop1696:
  %v5367 = load i64, ptr %slot12, align 8
  %p5368 = inttoptr i64 %v5367 to ptr
  store i32 0, ptr %p5368, align 4, !alias.scope !3, !noalias !4
  %v5369 = load i64, ptr %slot19, align 8
  store i64 %v5369, ptr %slot985, align 8
  %v5370 = load i64, ptr %slot13, align 8
  %p5371 = inttoptr i64 %v5370 to ptr
  %ld5372 = load i32, ptr %p5371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5372, ptr %slot986, align 8
  %v5373 = load i32, ptr %slot986, align 8
  %op5374 = and i32 %v5373, 28
  store i32 %op5374, ptr %slot987, align 8
  %v5375 = load i32, ptr %slot987, align 8
  %cv5376 = zext i32 %v5375 to i64
  %cond5377 = icmp ne i64 %cv5376, 0
  br i1 %cond5377, label %bb_rcslotrole1696, label %bb_rcslotowner1696
bb_rcslotrole1696:
  %v5378 = load i64, ptr %slot55, align 8
  store i64 %v5378, ptr %slot988, align 8
  %v5379 = load i64, ptr %slot988, align 8
  %v5380 = load i64, ptr %slot985, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5379, i64 %v5380) nomerge, !dbg !176
  br label %bb_rcslotdone1696
bb_rcslotowner1696:
  %v5381 = load i64, ptr %slot55, align 8
  store i64 %v5381, ptr %slot989, align 8
  %v5382 = load i64, ptr %slot989, align 8
  %v5383 = load i64, ptr %slot985, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5382, i64 %v5383) nomerge, !dbg !176
  br label %bb_rcslotdone1696
bb_rcslotdone1696:
  %v5384 = load i64, ptr %slot44, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  %ld5386 = load i64, ptr %p5385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5386, ptr %slot990, align 8
  %v5387 = load i64, ptr %slot23, align 8
  %p5389 = inttoptr i64 %v5387 to ptr
  %gep5390 = getelementptr i8, ptr %p5389, i64 24
  %op5388 = ptrtoint ptr %gep5390 to i64
  store i64 %op5388, ptr %slot991, align 8
  %v5391 = load i64, ptr %slot991, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  %ld5393 = load i32, ptr %p5392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5393, ptr %slot992, align 8
  %v5394 = load i64, ptr %slot25, align 8
  %p5396 = inttoptr i64 %v5394 to ptr
  %gep5397 = getelementptr i8, ptr %p5396, i64 24
  %op5395 = ptrtoint ptr %gep5397 to i64
  store i64 %op5395, ptr %slot993, align 8
  %v5398 = load i64, ptr %slot993, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  %ld5400 = load i32, ptr %p5399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5400, ptr %slot994, align 8
  %v5401 = load i32, ptr %slot992, align 8
  %v5402 = load i32, ptr %slot994, align 8
  %op5403 = or i32 %v5401, %v5402
  store i32 %op5403, ptr %slot995, align 8
  %v5404 = load i32, ptr %slot995, align 8
  %cv5405 = zext i32 %v5404 to i64
  %cond5406 = icmp ne i64 %cv5405, 0
  br i1 %cond5406, label %bb_rcscopesopen1709, label %bb_rcscopesclosed1709
bb_rcscopesopen1709:
  %v5407 = load i64, ptr %slot27, align 8
  %p5409 = inttoptr i64 %v5407 to ptr
  %gep5410 = getelementptr i8, ptr %p5409, i64 0
  %op5408 = ptrtoint ptr %gep5410 to i64
  store i64 %op5408, ptr %slot996, align 8
  %v5411 = load i64, ptr %slot23, align 8
  %v5412 = load i64, ptr %slot996, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  store i64 %v5411, ptr %p5413, align 8, !alias.scope !3, !noalias !4
  %v5414 = load i64, ptr %slot27, align 8
  %p5416 = inttoptr i64 %v5414 to ptr
  %gep5417 = getelementptr i8, ptr %p5416, i64 8
  %op5415 = ptrtoint ptr %gep5417 to i64
  store i64 %op5415, ptr %slot997, align 8
  %v5418 = load i64, ptr %slot25, align 8
  %v5419 = load i64, ptr %slot997, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  store i64 %v5418, ptr %p5420, align 8, !alias.scope !3, !noalias !4
  %v5421 = load i64, ptr %slot1, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %v5423 = load i64, ptr %slot27, align 8
  %p5424 = inttoptr i64 %v5423 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5422, ptr %p5424, i64 2) nomerge, !dbg !178
  br label %bb_rcscopesclosed1709
bb_rcscopesclosed1709:
  %v5425 = load i64, ptr %slot12, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  %ld5427 = load i32, ptr %p5426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5427, ptr %slot998, align 8
  %v5428 = load i32, ptr %slot998, align 8
  %cv5429 = zext i32 %v5428 to i64
  %cond5430 = icmp ne i64 %cv5429, 0
  br i1 %cond5430, label %bb_rcslotdrop1714, label %bb_rcslotdone1714
bb_rcslotdrop1714:
  %v5431 = load i64, ptr %slot12, align 8
  %p5432 = inttoptr i64 %v5431 to ptr
  store i32 0, ptr %p5432, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1714
bb_rcslotdone1714:
  %v5433 = load i64, ptr %slot10, align 8
  %p5434 = inttoptr i64 %v5433 to ptr
  %ld5435 = load i32, ptr %p5434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5435, ptr %slot999, align 8
  %v5436 = load i32, ptr %slot999, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcslotdrop1717, label %bb_rcslotdone1717
bb_rcslotdrop1717:
  %v5439 = load i64, ptr %slot10, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  store i32 0, ptr %p5440, align 4, !alias.scope !3, !noalias !4
  %v5441 = load i64, ptr %slot41, align 8
  store i64 %v5441, ptr %slot1000, align 8
  %v5442 = load i64, ptr %slot11, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  %ld5444 = load i32, ptr %p5443, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5444, ptr %slot1001, align 8
  %v5445 = load i32, ptr %slot1001, align 8
  %op5446 = and i32 %v5445, 28
  store i32 %op5446, ptr %slot1002, align 8
  %v5447 = load i32, ptr %slot1002, align 8
  %cv5448 = zext i32 %v5447 to i64
  %cond5449 = icmp ne i64 %cv5448, 0
  br i1 %cond5449, label %bb_rcslotrole1717, label %bb_rcslotowner1717
bb_rcslotrole1717:
  %v5450 = load i64, ptr %slot55, align 8
  store i64 %v5450, ptr %slot1003, align 8
  %v5451 = load i64, ptr %slot1003, align 8
  %v5452 = load i64, ptr %slot1000, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5451, i64 %v5452) nomerge, !dbg !178
  br label %bb_rcslotdone1717
bb_rcslotowner1717:
  %v5453 = load i64, ptr %slot55, align 8
  store i64 %v5453, ptr %slot1004, align 8
  %v5454 = load i64, ptr %slot1004, align 8
  %v5455 = load i64, ptr %slot1000, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5454, i64 %v5455) nomerge, !dbg !178
  br label %bb_rcslotdone1717
bb_rcslotdone1717:
  %v5456 = load i64, ptr %slot8, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  %ld5458 = load i32, ptr %p5457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5458, ptr %slot1005, align 8
  %v5459 = load i32, ptr %slot1005, align 8
  %cv5460 = zext i32 %v5459 to i64
  %cond5461 = icmp ne i64 %cv5460, 0
  br i1 %cond5461, label %bb_rcslotdrop1763, label %bb_rcslotdone1763
bb_rcslotdrop1763:
  %v5462 = load i64, ptr %slot8, align 8
  %p5463 = inttoptr i64 %v5462 to ptr
  store i32 0, ptr %p5463, align 4, !alias.scope !3, !noalias !4
  %v5464 = load i64, ptr %slot38, align 8
  store i64 %v5464, ptr %slot1006, align 8
  %v5465 = load i64, ptr %slot9, align 8
  %p5466 = inttoptr i64 %v5465 to ptr
  %ld5467 = load i32, ptr %p5466, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5467, ptr %slot1007, align 8
  %v5468 = load i32, ptr %slot1007, align 8
  %op5469 = and i32 %v5468, 28
  store i32 %op5469, ptr %slot1008, align 8
  %v5470 = load i32, ptr %slot1008, align 8
  %cv5471 = zext i32 %v5470 to i64
  %cond5472 = icmp ne i64 %cv5471, 0
  br i1 %cond5472, label %bb_rcslotrole1763, label %bb_rcslotowner1763
bb_rcslotrole1763:
  %v5473 = load i64, ptr %slot55, align 8
  store i64 %v5473, ptr %slot1009, align 8
  %v5474 = load i64, ptr %slot1009, align 8
  %v5475 = load i64, ptr %slot1006, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v5474, i64 %v5475) nomerge, !dbg !178
  br label %bb_rcslotdone1763
bb_rcslotowner1763:
  %v5476 = load i64, ptr %slot55, align 8
  store i64 %v5476, ptr %slot1010, align 8
  %v5477 = load i64, ptr %slot1010, align 8
  %v5478 = load i64, ptr %slot1006, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v5477, i64 %v5478) nomerge, !dbg !178
  br label %bb_rcslotdone1763
bb_rcslotdone1763:
  %v5479 = load i64, ptr %slot6, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %ld5481 = load i32, ptr %p5480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5481, ptr %slot1011, align 8
  %v5482 = load i32, ptr %slot1011, align 8
  %cv5483 = zext i32 %v5482 to i64
  %cond5484 = icmp ne i64 %cv5483, 0
  br i1 %cond5484, label %bb_rcslotdrop1809, label %bb_rcslotdone1809
bb_rcslotdrop1809:
  %v5485 = load i64, ptr %slot6, align 8
  %p5486 = inttoptr i64 %v5485 to ptr
  store i32 0, ptr %p5486, align 4, !alias.scope !3, !noalias !4
  %v5487 = load i64, ptr %slot34, align 8
  store i64 %v5487, ptr %slot1012, align 8
  %v5488 = load i64, ptr %slot7, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  %ld5490 = load i32, ptr %p5489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5490, ptr %slot1013, align 8
  %v5491 = load i32, ptr %slot1013, align 8
  %op5492 = and i32 %v5491, 28
  store i32 %op5492, ptr %slot1014, align 8
  %v5493 = load i32, ptr %slot1014, align 8
  %cv5494 = zext i32 %v5493 to i64
  %cond5495 = icmp ne i64 %cv5494, 0
  br i1 %cond5495, label %bb_rcslotrole1809, label %bb_rcslotowner1809
bb_rcslotrole1809:
  %v5496 = load i64, ptr %slot55, align 8
  store i64 %v5496, ptr %slot1015, align 8
  %v5497 = load i64, ptr %slot1015, align 8
  %v5498 = load i64, ptr %slot1012, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5497, i64 %v5498) nomerge, !dbg !178
  br label %bb_rcslotdone1809
bb_rcslotowner1809:
  %v5499 = load i64, ptr %slot55, align 8
  store i64 %v5499, ptr %slot1016, align 8
  %v5500 = load i64, ptr %slot1016, align 8
  %v5501 = load i64, ptr %slot1012, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5500, i64 %v5501) nomerge, !dbg !178
  br label %bb_rcslotdone1809
bb_rcslotdone1809:
  %v5502 = load i64, ptr %slot990, align 8
  ret i64 %v5502
bb_i115:
  %v5503 = load i64, ptr %slot44, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  store i64 18446744073709551615, ptr %p5504, align 8, !alias.scope !3, !noalias !4
  %v5505 = load i64, ptr %slot44, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  %ld5507 = load i64, ptr %p5506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5507, ptr %slot1017, align 8
  %v5508 = load i64, ptr %slot23, align 8
  %p5510 = inttoptr i64 %v5508 to ptr
  %gep5511 = getelementptr i8, ptr %p5510, i64 24
  %op5509 = ptrtoint ptr %gep5511 to i64
  store i64 %op5509, ptr %slot1018, align 8
  %v5512 = load i64, ptr %slot1018, align 8
  %p5513 = inttoptr i64 %v5512 to ptr
  %ld5514 = load i32, ptr %p5513, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5514, ptr %slot1019, align 8
  %v5515 = load i64, ptr %slot25, align 8
  %p5517 = inttoptr i64 %v5515 to ptr
  %gep5518 = getelementptr i8, ptr %p5517, i64 24
  %op5516 = ptrtoint ptr %gep5518 to i64
  store i64 %op5516, ptr %slot1020, align 8
  %v5519 = load i64, ptr %slot1020, align 8
  %p5520 = inttoptr i64 %v5519 to ptr
  %ld5521 = load i32, ptr %p5520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5521, ptr %slot1021, align 8
  %v5522 = load i32, ptr %slot1019, align 8
  %v5523 = load i32, ptr %slot1021, align 8
  %op5524 = or i32 %v5522, %v5523
  store i32 %op5524, ptr %slot1022, align 8
  %v5525 = load i32, ptr %slot1022, align 8
  %cv5526 = zext i32 %v5525 to i64
  %cond5527 = icmp ne i64 %cv5526, 0
  br i1 %cond5527, label %bb_rcscopesopen1905, label %bb_rcscopesclosed1905
bb_rcscopesopen1905:
  %v5528 = load i64, ptr %slot27, align 8
  %p5530 = inttoptr i64 %v5528 to ptr
  %gep5531 = getelementptr i8, ptr %p5530, i64 0
  %op5529 = ptrtoint ptr %gep5531 to i64
  store i64 %op5529, ptr %slot1023, align 8
  %v5532 = load i64, ptr %slot23, align 8
  %v5533 = load i64, ptr %slot1023, align 8
  %p5534 = inttoptr i64 %v5533 to ptr
  store i64 %v5532, ptr %p5534, align 8, !alias.scope !3, !noalias !4
  %v5535 = load i64, ptr %slot27, align 8
  %p5537 = inttoptr i64 %v5535 to ptr
  %gep5538 = getelementptr i8, ptr %p5537, i64 8
  %op5536 = ptrtoint ptr %gep5538 to i64
  store i64 %op5536, ptr %slot1024, align 8
  %v5539 = load i64, ptr %slot25, align 8
  %v5540 = load i64, ptr %slot1024, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  store i64 %v5539, ptr %p5541, align 8, !alias.scope !3, !noalias !4
  %v5542 = load i64, ptr %slot1, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  %v5544 = load i64, ptr %slot27, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5543, ptr %p5545, i64 2) nomerge, !dbg !180
  br label %bb_rcscopesclosed1905
bb_rcscopesclosed1905:
  %v5546 = load i64, ptr %slot12, align 8
  %p5547 = inttoptr i64 %v5546 to ptr
  %ld5548 = load i32, ptr %p5547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5548, ptr %slot1025, align 8
  %v5549 = load i32, ptr %slot1025, align 8
  %cv5550 = zext i32 %v5549 to i64
  %cond5551 = icmp ne i64 %cv5550, 0
  br i1 %cond5551, label %bb_rcslotdrop1910, label %bb_rcslotdone1910
bb_rcslotdrop1910:
  %v5552 = load i64, ptr %slot12, align 8
  %p5553 = inttoptr i64 %v5552 to ptr
  store i32 0, ptr %p5553, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1910
bb_rcslotdone1910:
  %v5554 = load i64, ptr %slot10, align 8
  %p5555 = inttoptr i64 %v5554 to ptr
  %ld5556 = load i32, ptr %p5555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5556, ptr %slot1026, align 8
  %v5557 = load i32, ptr %slot1026, align 8
  %cv5558 = zext i32 %v5557 to i64
  %cond5559 = icmp ne i64 %cv5558, 0
  br i1 %cond5559, label %bb_rcslotdrop1913, label %bb_rcslotdone1913
bb_rcslotdrop1913:
  %v5560 = load i64, ptr %slot10, align 8
  %p5561 = inttoptr i64 %v5560 to ptr
  store i32 0, ptr %p5561, align 4, !alias.scope !3, !noalias !4
  %v5562 = load i64, ptr %slot41, align 8
  store i64 %v5562, ptr %slot1027, align 8
  %v5563 = load i64, ptr %slot11, align 8
  %p5564 = inttoptr i64 %v5563 to ptr
  %ld5565 = load i32, ptr %p5564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5565, ptr %slot1028, align 8
  %v5566 = load i32, ptr %slot1028, align 8
  %op5567 = and i32 %v5566, 28
  store i32 %op5567, ptr %slot1029, align 8
  %v5568 = load i32, ptr %slot1029, align 8
  %cv5569 = zext i32 %v5568 to i64
  %cond5570 = icmp ne i64 %cv5569, 0
  br i1 %cond5570, label %bb_rcslotrole1913, label %bb_rcslotowner1913
bb_rcslotrole1913:
  %v5571 = load i64, ptr %slot55, align 8
  store i64 %v5571, ptr %slot1030, align 8
  %v5572 = load i64, ptr %slot1030, align 8
  %v5573 = load i64, ptr %slot1027, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5572, i64 %v5573) nomerge, !dbg !180
  br label %bb_rcslotdone1913
bb_rcslotowner1913:
  %v5574 = load i64, ptr %slot55, align 8
  store i64 %v5574, ptr %slot1031, align 8
  %v5575 = load i64, ptr %slot1031, align 8
  %v5576 = load i64, ptr %slot1027, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5575, i64 %v5576) nomerge, !dbg !180
  br label %bb_rcslotdone1913
bb_rcslotdone1913:
  %v5577 = load i64, ptr %slot8, align 8
  %p5578 = inttoptr i64 %v5577 to ptr
  %ld5579 = load i32, ptr %p5578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5579, ptr %slot1032, align 8
  %v5580 = load i32, ptr %slot1032, align 8
  %cv5581 = zext i32 %v5580 to i64
  %cond5582 = icmp ne i64 %cv5581, 0
  br i1 %cond5582, label %bb_rcslotdrop1959, label %bb_rcslotdone1959
bb_rcslotdrop1959:
  %v5583 = load i64, ptr %slot8, align 8
  %p5584 = inttoptr i64 %v5583 to ptr
  store i32 0, ptr %p5584, align 4, !alias.scope !3, !noalias !4
  %v5585 = load i64, ptr %slot38, align 8
  store i64 %v5585, ptr %slot1033, align 8
  %v5586 = load i64, ptr %slot9, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i32, ptr %p5587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5588, ptr %slot1034, align 8
  %v5589 = load i32, ptr %slot1034, align 8
  %op5590 = and i32 %v5589, 28
  store i32 %op5590, ptr %slot1035, align 8
  %v5591 = load i32, ptr %slot1035, align 8
  %cv5592 = zext i32 %v5591 to i64
  %cond5593 = icmp ne i64 %cv5592, 0
  br i1 %cond5593, label %bb_rcslotrole1959, label %bb_rcslotowner1959
bb_rcslotrole1959:
  %v5594 = load i64, ptr %slot55, align 8
  store i64 %v5594, ptr %slot1036, align 8
  %v5595 = load i64, ptr %slot1036, align 8
  %v5596 = load i64, ptr %slot1033, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v5595, i64 %v5596) nomerge, !dbg !180
  br label %bb_rcslotdone1959
bb_rcslotowner1959:
  %v5597 = load i64, ptr %slot55, align 8
  store i64 %v5597, ptr %slot1037, align 8
  %v5598 = load i64, ptr %slot1037, align 8
  %v5599 = load i64, ptr %slot1033, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v5598, i64 %v5599) nomerge, !dbg !180
  br label %bb_rcslotdone1959
bb_rcslotdone1959:
  %v5600 = load i64, ptr %slot6, align 8
  %p5601 = inttoptr i64 %v5600 to ptr
  %ld5602 = load i32, ptr %p5601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5602, ptr %slot1038, align 8
  %v5603 = load i32, ptr %slot1038, align 8
  %cv5604 = zext i32 %v5603 to i64
  %cond5605 = icmp ne i64 %cv5604, 0
  br i1 %cond5605, label %bb_rcslotdrop2005, label %bb_rcslotdone2005
bb_rcslotdrop2005:
  %v5606 = load i64, ptr %slot6, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  store i32 0, ptr %p5607, align 4, !alias.scope !3, !noalias !4
  %v5608 = load i64, ptr %slot34, align 8
  store i64 %v5608, ptr %slot1039, align 8
  %v5609 = load i64, ptr %slot7, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  %ld5611 = load i32, ptr %p5610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5611, ptr %slot1040, align 8
  %v5612 = load i32, ptr %slot1040, align 8
  %op5613 = and i32 %v5612, 28
  store i32 %op5613, ptr %slot1041, align 8
  %v5614 = load i32, ptr %slot1041, align 8
  %cv5615 = zext i32 %v5614 to i64
  %cond5616 = icmp ne i64 %cv5615, 0
  br i1 %cond5616, label %bb_rcslotrole2005, label %bb_rcslotowner2005
bb_rcslotrole2005:
  %v5617 = load i64, ptr %slot55, align 8
  store i64 %v5617, ptr %slot1042, align 8
  %v5618 = load i64, ptr %slot1042, align 8
  %v5619 = load i64, ptr %slot1039, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5618, i64 %v5619) nomerge, !dbg !180
  br label %bb_rcslotdone2005
bb_rcslotowner2005:
  %v5620 = load i64, ptr %slot55, align 8
  store i64 %v5620, ptr %slot1043, align 8
  %v5621 = load i64, ptr %slot1043, align 8
  %v5622 = load i64, ptr %slot1039, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5621, i64 %v5622) nomerge, !dbg !180
  br label %bb_rcslotdone2005
bb_rcslotdone2005:
  %v5623 = load i64, ptr %slot1017, align 8
  ret i64 %v5623
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_9f8b01b4a14ac178a8d4478a45b00281882a104c69ea880428c8a220fcfbc195(i64, i64, i64, i64, i64)
declare i64 @myl_f_fb17c5f35998f28d890791c7c29c3b4d8861f8b82ea8c43160c8fd46bb1ae1af(i64, i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64, i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64, i64, i64, i32)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64, i64)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69", linkageName: "myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11448037927998296630, i64 0, !"myl_f_9fe99126ce7100c94bb52bd39bf7343ad112c972712644f8a2e44eec03514e69"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!116 = !DILocation(line: 10, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!122 = !DILocation(line: 23, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!124 = !DILocation(line: 30, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!126 = !DILocation(line: 32, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!128 = !DILocation(line: 35, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!130 = !DILocation(line: 36, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!132 = !DILocation(line: 37, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!134 = !DILocation(line: 41, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!136 = !DILocation(line: 42, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!138 = !DILocation(line: 50, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!140 = !DILocation(line: 52, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!142 = !DILocation(line: 57, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!144 = !DILocation(line: 58, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!146 = !DILocation(line: 60, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!148 = !DILocation(line: 61, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!150 = !DILocation(line: 65, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!152 = !DILocation(line: 66, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!154 = !DILocation(line: 71, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!156 = !DILocation(line: 73, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!158 = !DILocation(line: 74, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!160 = !DILocation(line: 77, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647207)
!162 = !DILocation(line: 84, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!164 = !DILocation(line: 86, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647263)
!166 = !DILocation(line: 91, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!168 = !DILocation(line: 97, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!170 = !DILocation(line: 98, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!172 = !DILocation(line: 102, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!174 = !DILocation(line: 104, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!176 = !DILocation(line: 114, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647455)
!178 = !DILocation(line: 115, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!180 = !DILocation(line: 117, column: 0, scope: !181)
