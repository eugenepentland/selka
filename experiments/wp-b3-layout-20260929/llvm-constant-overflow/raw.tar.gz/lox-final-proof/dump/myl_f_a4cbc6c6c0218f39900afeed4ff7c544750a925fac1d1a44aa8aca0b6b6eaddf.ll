target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a4cbc6c6c0218f39900afeed4ff7c544750a925fac1d1a44aa8aca0b6b6eaddf(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i32, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v919 = load i64, ptr %slot1, align 8
  %op920 = add i64 %v919, 32
  store i64 %op920, ptr %slot5, align 8
  %mem921 = alloca i8, i64 8, align 8
  %ptr922 = ptrtoint ptr %mem921 to i64
  store i64 %ptr922, ptr %slot6, align 8
  %mem923 = alloca i8, i64 8, align 8
  %ptr924 = ptrtoint ptr %mem923 to i64
  store i64 %ptr924, ptr %slot7, align 8
  %mem925 = alloca i8, i64 8, align 8
  %ptr926 = ptrtoint ptr %mem925 to i64
  store i64 %ptr926, ptr %slot8, align 8
  %mem927 = alloca i8, i64 8, align 8
  %ptr928 = ptrtoint ptr %mem927 to i64
  store i64 %ptr928, ptr %slot9, align 8
  %mem929 = alloca i8, i64 8, align 8
  %ptr930 = ptrtoint ptr %mem929 to i64
  store i64 %ptr930, ptr %slot10, align 8
  %mem931 = alloca i8, i64 8, align 8
  %ptr932 = ptrtoint ptr %mem931 to i64
  store i64 %ptr932, ptr %slot11, align 8
  %mem933 = alloca i8, i64 8, align 8
  %ptr934 = ptrtoint ptr %mem933 to i64
  store i64 %ptr934, ptr %slot12, align 8
  %mem935 = alloca i8, i64 8, align 8
  %ptr936 = ptrtoint ptr %mem935 to i64
  store i64 %ptr936, ptr %slot13, align 8
  %mem937 = alloca i8, i64 8, align 8
  %ptr938 = ptrtoint ptr %mem937 to i64
  store i64 %ptr938, ptr %slot14, align 8
  %mem939 = alloca i8, i64 8, align 8
  %ptr940 = ptrtoint ptr %mem939 to i64
  store i64 %ptr940, ptr %slot15, align 8
  %mem941 = alloca i8, i64 8, align 8
  %ptr942 = ptrtoint ptr %mem941 to i64
  store i64 %ptr942, ptr %slot16, align 8
  %mem943 = alloca i8, i64 8, align 8
  %ptr944 = ptrtoint ptr %mem943 to i64
  store i64 %ptr944, ptr %slot17, align 8
  %mem945 = alloca i8, i64 8, align 8
  %ptr946 = ptrtoint ptr %mem945 to i64
  store i64 %ptr946, ptr %slot18, align 8
  %mem947 = alloca i8, i64 8, align 8
  %ptr948 = ptrtoint ptr %mem947 to i64
  store i64 %ptr948, ptr %slot19, align 8
  %mem949 = alloca i8, i64 8, align 8
  %ptr950 = ptrtoint ptr %mem949 to i64
  store i64 %ptr950, ptr %slot20, align 8
  %mem951 = alloca i8, i64 208, align 8
  %ptr952 = ptrtoint ptr %mem951 to i64
  store i64 %ptr952, ptr %slot21, align 8
  %mem953 = alloca i8, i64 56, align 8
  %ptr954 = ptrtoint ptr %mem953 to i64
  store i64 %ptr954, ptr %slot22, align 8
  %mem955 = alloca i8, i64 208, align 8
  %ptr956 = ptrtoint ptr %mem955 to i64
  store i64 %ptr956, ptr %slot23, align 8
  %mem957 = alloca i8, i64 32, align 8
  %ptr958 = ptrtoint ptr %mem957 to i64
  store i64 %ptr958, ptr %slot24, align 8
  %v959 = load i64, ptr %slot24, align 8
  %p961 = inttoptr i64 %v959 to ptr
  %gep962 = getelementptr i8, ptr %p961, i64 24
  %op960 = ptrtoint ptr %gep962 to i64
  store i64 %op960, ptr %slot25, align 8
  %v963 = load i64, ptr %slot25, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i64 0, ptr %p964, align 8, !alias.scope !3, !noalias !4
  %mem965 = alloca i8, i64 8, align 8
  %ptr966 = ptrtoint ptr %mem965 to i64
  store i64 %ptr966, ptr %slot26, align 8
  %mem967 = alloca i8, i64 8, align 8
  %ptr968 = ptrtoint ptr %mem967 to i64
  store i64 %ptr968, ptr %slot27, align 8
  %mem969 = alloca i8, i64 8, align 8
  %ptr970 = ptrtoint ptr %mem969 to i64
  store i64 %ptr970, ptr %slot28, align 8
  %mem971 = alloca i8, i64 8, align 8
  %ptr972 = ptrtoint ptr %mem971 to i64
  store i64 %ptr972, ptr %slot29, align 8
  %mem973 = alloca i8, i64 8, align 8
  %ptr974 = ptrtoint ptr %mem973 to i64
  store i64 %ptr974, ptr %slot30, align 8
  %mem975 = alloca i8, i64 8, align 8
  %ptr976 = ptrtoint ptr %mem975 to i64
  store i64 %ptr976, ptr %slot31, align 8
  %mem977 = alloca i8, i64 24, align 8
  %ptr978 = ptrtoint ptr %mem977 to i64
  store i64 %ptr978, ptr %slot32, align 8
  %mem979 = alloca i8, i64 24, align 8
  %ptr980 = ptrtoint ptr %mem979 to i64
  store i64 %ptr980, ptr %slot33, align 8
  %mem981 = alloca i8, i64 24, align 8
  %ptr982 = ptrtoint ptr %mem981 to i64
  store i64 %ptr982, ptr %slot34, align 8
  %mem983 = alloca i8, i64 16, align 8
  %ptr984 = ptrtoint ptr %mem983 to i64
  store i64 %ptr984, ptr %slot35, align 8
  %mem985 = alloca i8, i64 8, align 8
  %ptr986 = ptrtoint ptr %mem985 to i64
  store i64 %ptr986, ptr %slot36, align 8
  %mem987 = alloca i8, i64 56, align 8
  %ptr988 = ptrtoint ptr %mem987 to i64
  store i64 %ptr988, ptr %slot37, align 8
  %mem989 = alloca i8, i64 8, align 8
  %ptr990 = ptrtoint ptr %mem989 to i64
  store i64 %ptr990, ptr %slot38, align 8
  %mem991 = alloca i8, i64 8, align 8
  %ptr992 = ptrtoint ptr %mem991 to i64
  store i64 %ptr992, ptr %slot39, align 8
  %mem993 = alloca i8, i64 8, align 8
  %ptr994 = ptrtoint ptr %mem993 to i64
  store i64 %ptr994, ptr %slot40, align 8
  %mem995 = alloca i8, i64 24, align 8
  %ptr996 = ptrtoint ptr %mem995 to i64
  store i64 %ptr996, ptr %slot41, align 8
  %mem997 = alloca i8, i64 24, align 8
  %ptr998 = ptrtoint ptr %mem997 to i64
  store i64 %ptr998, ptr %slot42, align 8
  %mem999 = alloca i8, i64 56, align 8
  %ptr1000 = ptrtoint ptr %mem999 to i64
  store i64 %ptr1000, ptr %slot43, align 8
  %mem1001 = alloca i8, i64 56, align 8
  %ptr1002 = ptrtoint ptr %mem1001 to i64
  store i64 %ptr1002, ptr %slot44, align 8
  %v1003 = load i64, ptr %slot30, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  store i64 0, ptr %p1004, align 8, !alias.scope !3, !noalias !4
  %v1005 = load i64, ptr %slot36, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i64 0, ptr %p1006, align 8, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot2, align 8
  %v1008 = load i64, ptr %slot27, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i64 %v1007, ptr %p1009, align 8, !alias.scope !3, !noalias !4
  %v1010 = load i64, ptr %slot3, align 8
  %v1011 = load i64, ptr %slot28, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  store i64 %v1010, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  %v1013 = load i64, ptr %slot4, align 8
  %v1014 = load i64, ptr %slot29, align 8
  %p1015 = inttoptr i64 %v1014 to ptr
  store i64 %v1013, ptr %p1015, align 8, !alias.scope !3, !noalias !4
  %v1016 = load i64, ptr %slot1, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %call1018 = call ptr @myl_qbe_heap(ptr %p1017) nomerge, !dbg !110
  %calladdr1019 = ptrtoint ptr %call1018 to i64
  store i64 %calladdr1019, ptr %slot45, align 8
  %v1020 = load i64, ptr %slot1, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %call1022 = call i64 @myl_qbe_region_mark(ptr %p1021) nomerge, !dbg !110
  store i64 %call1022, ptr %slot46, align 8
  %v1023 = load i64, ptr %slot6, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 0, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot7, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  store i32 0, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  %v1027 = load i64, ptr %slot8, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i32 0, ptr %p1028, align 4, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot9, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  store i32 0, ptr %p1030, align 4, !alias.scope !3, !noalias !4
  %v1031 = load i64, ptr %slot10, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i32 0, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  %v1033 = load i64, ptr %slot11, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  store i32 0, ptr %p1034, align 4, !alias.scope !3, !noalias !4
  %v1035 = load i64, ptr %slot12, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  store i32 0, ptr %p1036, align 4, !alias.scope !3, !noalias !4
  %v1037 = load i64, ptr %slot13, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  store i32 0, ptr %p1038, align 4, !alias.scope !3, !noalias !4
  %v1039 = load i64, ptr %slot14, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i32 0, ptr %p1040, align 4, !alias.scope !3, !noalias !4
  %v1041 = load i64, ptr %slot15, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  store i32 0, ptr %p1042, align 4, !alias.scope !3, !noalias !4
  %v1043 = load i64, ptr %slot16, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  store i32 0, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  %v1045 = load i64, ptr %slot17, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i32 0, ptr %p1046, align 4, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot18, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i32 0, ptr %p1048, align 4, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot19, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i32 0, ptr %p1050, align 4, !alias.scope !3, !noalias !4
  %v1051 = load i64, ptr %slot20, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  store i32 0, ptr %p1052, align 4, !alias.scope !3, !noalias !4
  %v1053 = load i64, ptr %slot7, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 2, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot9, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  store i32 2, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot11, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 2, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot13, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  store i32 2, ptr %p1060, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1061 = load i64, ptr %slot27, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %ld1063 = load i64, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1063, ptr %slot47, align 8
  %v1064 = load i64, ptr %slot47, align 8
  %v1065 = load i64, ptr %slot39, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  store i64 %v1064, ptr %p1066, align 8, !alias.scope !3, !noalias !4
  %v1067 = load i64, ptr %slot39, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %ld1069 = load i64, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1069, ptr %slot48, align 8
  %v1070 = load i64, ptr %slot48, align 8
  %op1071 = add i64 %v1070, 0
  store i64 %op1071, ptr %slot49, align 8
  %v1072 = load i64, ptr %slot49, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i64, ptr %p1073, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1074, ptr %slot50, align 8
  %v1075 = load i64, ptr %slot50, align 8
  %v1076 = load i64, ptr %slot39, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  store i64 %v1075, ptr %p1077, align 8, !alias.scope !3, !noalias !4
  %v1078 = load i64, ptr %slot14, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %ld1080 = load i32, ptr %p1079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1080, ptr %slot51, align 8
  %v1081 = load i32, ptr %slot51, align 8
  %cv1082 = zext i32 %v1081 to i64
  %cond1083 = icmp ne i64 %cv1082, 0
  br i1 %cond1083, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v1084 = load i64, ptr %slot14, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  store i32 0, ptr %p1085, align 4, !alias.scope !3, !noalias !4
  %v1086 = load i64, ptr %slot21, align 8
  store i64 %v1086, ptr %slot52, align 8
  %v1087 = load i64, ptr %slot15, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %ld1089 = load i32, ptr %p1088, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1089, ptr %slot53, align 8
  %v1090 = load i32, ptr %slot53, align 8
  %op1091 = and i32 %v1090, 28
  store i32 %op1091, ptr %slot54, align 8
  %v1092 = load i32, ptr %slot54, align 8
  %cv1093 = zext i32 %v1092 to i64
  %cond1094 = icmp ne i64 %cv1093, 0
  br i1 %cond1094, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v1095 = load i64, ptr %slot45, align 8
  store i64 %v1095, ptr %slot55, align 8
  %v1096 = load i64, ptr %slot55, align 8
  %v1097 = load i64, ptr %slot52, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1096, i64 %v1097) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v1098 = load i64, ptr %slot45, align 8
  store i64 %v1098, ptr %slot56, align 8
  %v1099 = load i64, ptr %slot56, align 8
  %v1100 = load i64, ptr %slot52, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1099, i64 %v1100) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v1101 = load i64, ptr %slot39, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %ld1103 = load i64, ptr %p1102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1103, ptr %slot57, align 8
  %v1104 = load i64, ptr %slot57, align 8
  %v1105 = load i64, ptr %slot30, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i64 %v1104, ptr %p1106, align 8, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot28, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i64, ptr %p1108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1109, ptr %slot58, align 8
  %v1110 = load i64, ptr %slot58, align 8
  %v1111 = load i64, ptr %slot39, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i64 %v1110, ptr %p1112, align 8, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot39, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  %ld1115 = load i64, ptr %p1114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1115, ptr %slot59, align 8
  %v1116 = load i64, ptr %slot59, align 8
  %v1117 = load i64, ptr %slot31, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  store i64 %v1116, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot31, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %ld1121 = load i64, ptr %p1120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1121, ptr %slot60, align 8
  %v1122 = load i64, ptr %slot60, align 8
  %v1123 = load i64, ptr %slot39, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i64 %v1122, ptr %p1124, align 8, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot40, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i64 0, ptr %p1126, align 8, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot40, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  %ld1129 = load i64, ptr %p1128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1129, ptr %slot61, align 8
  %v1130 = load i64, ptr %slot39, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %ld1132 = load i64, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1132, ptr %slot62, align 8
  %v1133 = load i64, ptr %slot62, align 8
  %v1134 = load i64, ptr %slot61, align 8
  %cmp1135 = icmp slt i64 %v1133, %v1134
  %cv1136 = zext i1 %cmp1135 to i64
  store i64 %cv1136, ptr %slot63, align 8
  %v1137 = load i64, ptr %slot63, align 8
  %v1138 = load i64, ptr %slot39, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 %v1137, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot39, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i64, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1142, ptr %slot64, align 8
  %v1143 = load i64, ptr %slot64, align 8
  %cond1144 = icmp ne i64 %v1143, 0
  br i1 %cond1144, label %bb_next30, label %bb_i14
bb_next30:
  %v1145 = load i64, ptr %slot30, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  %ld1147 = load i64, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1147, ptr %slot65, align 8
  %v1148 = load i64, ptr %slot65, align 8
  %op1149 = add i64 %v1148, 0
  store i64 %op1149, ptr %slot66, align 8
  %v1150 = load i64, ptr %slot66, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1152, ptr %slot67, align 8
  %v1153 = load i64, ptr %slot67, align 8
  %v1154 = load i64, ptr %slot39, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot39, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %ld1158 = load i64, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1158, ptr %slot68, align 8
  %v1159 = load i64, ptr %slot68, align 8
  %cmp1160 = icmp ugt i64 %v1159, 9223372036854775807
  %cv1161 = zext i1 %cmp1160 to i64
  store i64 %cv1161, ptr %slot69, align 8
  %v1162 = load i64, ptr %slot69, align 8
  %cond1163 = icmp ne i64 %v1162, 0
  br i1 %cond1163, label %bb_cast_overflow35, label %bb_cast_ok35
bb_cast_overflow35:
  %v1164 = load i64, ptr %slot1, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %v1166 = load i64, ptr %slot68, align 8
  call void @myl_qbe_fail_cast(ptr %p1165, i64 %v1166, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok35:
  %v1167 = load i64, ptr %slot68, align 8
  %v1168 = load i64, ptr %slot39, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i64 %v1167, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot31, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  %ld1172 = load i64, ptr %p1171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1172, ptr %slot70, align 8
  %v1173 = load i64, ptr %slot70, align 8
  %v1174 = load i64, ptr %slot40, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  store i64 %v1173, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  %v1176 = load i64, ptr %slot40, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  %ld1178 = load i64, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1178, ptr %slot71, align 8
  %v1179 = load i64, ptr %slot39, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i64, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1181, ptr %slot72, align 8
  %v1182 = load i64, ptr %slot72, align 8
  %v1183 = load i64, ptr %slot71, align 8
  %ovpair1185 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1182, i64 %v1183)
  %op1184 = extractvalue { i64, i1 } %ovpair1185, 0
  %ov1186 = extractvalue { i64, i1 } %ovpair1185, 1
  store i64 %op1184, ptr %slot73, align 8
  %v1187 = load i64, ptr %slot72, align 8
  %v1188 = load i64, ptr %slot73, align 8
  %op1189 = xor i64 %v1187, %v1188
  store i64 %op1189, ptr %slot74, align 8
  %v1190 = load i64, ptr %slot71, align 8
  %v1191 = load i64, ptr %slot73, align 8
  %op1192 = xor i64 %v1190, %v1191
  store i64 %op1192, ptr %slot75, align 8
  %v1193 = load i64, ptr %slot74, align 8
  %v1194 = load i64, ptr %slot75, align 8
  %op1195 = and i64 %v1193, %v1194
  store i64 %op1195, ptr %slot76, align 8
  %cv1196 = zext i1 %ov1186 to i64
  store i64 %cv1196, ptr %slot77, align 8
  %v1197 = load i64, ptr %slot77, align 8
  %cond1198 = icmp ne i64 %v1197, 0
  br i1 %cond1198, label %bb_overflow39, label %bb_checked39
bb_overflow39:
  %v1199 = load i64, ptr %slot1, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %v1201 = load i64, ptr %slot72, align 8
  %v1202 = load i64, ptr %slot71, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1200, i64 0, i64 %v1201, i64 %v1202, i64 64) nomerge, !dbg !116
  unreachable
bb_checked39:
  %v1203 = load i64, ptr %slot73, align 8
  %v1204 = load i64, ptr %slot39, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i64 %v1203, ptr %p1205, align 8, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot39, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  %ld1208 = load i64, ptr %p1207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1208, ptr %slot78, align 8
  %v1209 = load i64, ptr %slot78, align 8
  %v1210 = load i64, ptr %slot31, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i64 %v1209, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v1212 = load i64, ptr %slot31, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %ld1214 = load i64, ptr %p1213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1214, ptr %slot79, align 8
  %v1215 = load i64, ptr %slot79, align 8
  %v1216 = load i64, ptr %slot39, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i64 %v1215, ptr %p1217, align 8, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot30, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  %ld1220 = load i64, ptr %p1219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1220, ptr %slot80, align 8
  %v1221 = load i64, ptr %slot39, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  %ld1223 = load i64, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1223, ptr %slot81, align 8
  %v1224 = load i64, ptr %slot80, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i64, ptr %p1225, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1226, ptr %slot82, align 8
  %v1227 = load i64, ptr %slot81, align 8
  %v1228 = load i64, ptr %slot82, align 8
  %cmp1229 = icmp ult i64 %v1227, %v1228
  %cv1230 = zext i1 %cmp1229 to i64
  store i64 %cv1230, ptr %slot83, align 8
  %v1231 = load i64, ptr %slot83, align 8
  %cond1232 = icmp ne i64 %v1231, 0
  br i1 %cond1232, label %bb_success51, label %bb_failed51
bb_failed51:
  %v1233 = load i64, ptr %slot1, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  %v1235 = load i64, ptr %slot81, align 8
  %v1236 = load i64, ptr %slot82, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1234, i64 %v1235, i64 %v1236) nomerge, !dbg !118
  unreachable
bb_success51:
  %v1237 = load i64, ptr %slot80, align 8
  %op1238 = add i64 %v1237, 32
  store i64 %op1238, ptr %slot84, align 8
  %v1239 = load i64, ptr %slot84, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %ld1241 = load i64, ptr %p1240, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1241, ptr %slot85, align 8
  %v1242 = load i64, ptr %slot81, align 8
  %op1243 = mul i64 %v1242, 56
  store i64 %op1243, ptr %slot86, align 8
  %v1244 = load i64, ptr %slot85, align 8
  %v1245 = load i64, ptr %slot86, align 8
  %op1246 = add i64 %v1244, %v1245
  store i64 %op1246, ptr %slot87, align 8
  %v1247 = load i64, ptr %slot87, align 8
  %v1248 = load i64, ptr %slot39, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i64 %v1247, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot39, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i64, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1252, ptr %slot88, align 8
  %v1253 = load i64, ptr %slot23, align 8
  store i64 %v1253, ptr %slot89, align 8
  %v1254 = load i64, ptr %slot45, align 8
  %v1255 = load i64, ptr %slot89, align 8
  %v1256 = load i64, ptr %slot88, align 8
  %call1257 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v1254, i64 %v1255, i64 %v1256) nomerge, !dbg !118
  store i32 %call1257, ptr %slot90, align 8
  %v1258 = load i32, ptr %slot90, align 8
  %cv1259 = zext i32 %v1258 to i64
  %cond1260 = icmp ne i64 %cv1259, 0
  br i1 %cond1260, label %bb_rcsuccess59, label %bb_rcfailure59
bb_rcfailure59:
  %v1261 = load i64, ptr %slot45, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %call1263 = call i32 @myl_rc_take_failure(ptr %p1262) nomerge, !dbg !118
  store i32 %call1263, ptr %slot91, align 8
  %v1264 = load i64, ptr %slot1, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  %v1266 = load i32, ptr %slot91, align 8
  %call1267 = call i32 @myl_qbe_rc_status(ptr %p1265, i32 %v1266) nomerge, !dbg !118
  store i32 %call1267, ptr %slot92, align 8
  br label %bb_failure
bb_rcsuccess59:
  %v1268 = load i64, ptr %slot19, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i32 2, ptr %p1269, align 4, !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot19, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i32 16, ptr %p1271, align 4, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot18, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  store i32 1, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  %v1274 = load i64, ptr %slot21, align 8
  store i64 %v1274, ptr %slot93, align 8
  %v1275 = load i64, ptr %slot23, align 8
  store i64 %v1275, ptr %slot94, align 8
  %v1276 = load i64, ptr %slot94, align 8
  %v1277 = load i64, ptr %slot93, align 8
  %p1278 = inttoptr i64 %v1276 to ptr
  %p1279 = inttoptr i64 %v1277 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1279, ptr %p1278, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot15, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i32 2, ptr %p1281, align 4, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot19, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  %ld1284 = load i32, ptr %p1283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1284, ptr %slot95, align 8
  %v1285 = load i32, ptr %slot95, align 8
  %v1286 = load i64, ptr %slot15, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i32 %v1285, ptr %p1287, align 4, !alias.scope !3, !noalias !4
  %v1288 = load i64, ptr %slot18, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  store i32 0, ptr %p1289, align 4, !alias.scope !3, !noalias !4
  %v1290 = load i64, ptr %slot14, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i32 1, ptr %p1291, align 4, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot93, align 8
  %v1293 = load i64, ptr %slot39, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  store i64 %v1292, ptr %p1294, align 8, !alias.scope !3, !noalias !4
  %v1295 = load i64, ptr %slot39, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  %ld1297 = load i64, ptr %p1296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1297, ptr %slot96, align 8
  %v1298 = load i64, ptr %slot96, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  %ld1300 = load i32, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  %ext1301 = zext i32 %ld1300 to i64
  store i64 %ext1301, ptr %slot97, align 8
  %v1302 = load i64, ptr %slot97, align 8
  %cmp1303 = icmp eq i64 %v1302, 0
  %cv1304 = zext i1 %cmp1303 to i64
  store i64 %cv1304, ptr %slot98, align 8
  %v1305 = load i64, ptr %slot98, align 8
  %cond1306 = icmp ne i64 %v1305, 0
  br i1 %cond1306, label %bb_rcarm75, label %bb_rcarmnext75
bb_rcarm75:
  %v1307 = load i64, ptr %slot14, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i32, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1309, ptr %slot99, align 8
  %v1310 = load i32, ptr %slot99, align 8
  %cv1311 = zext i32 %v1310 to i64
  %cond1312 = icmp ne i64 %cv1311, 0
  br i1 %cond1312, label %bb_rcslotdrop78, label %bb_rcslotdone78
bb_rcslotdrop78:
  %v1313 = load i64, ptr %slot14, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  store i32 0, ptr %p1314, align 4, !alias.scope !3, !noalias !4
  %v1315 = load i64, ptr %slot21, align 8
  store i64 %v1315, ptr %slot100, align 8
  %v1316 = load i64, ptr %slot15, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  %ld1318 = load i32, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1318, ptr %slot101, align 8
  %v1319 = load i32, ptr %slot101, align 8
  %op1320 = and i32 %v1319, 28
  store i32 %op1320, ptr %slot102, align 8
  %v1321 = load i32, ptr %slot102, align 8
  %cv1322 = zext i32 %v1321 to i64
  %cond1323 = icmp ne i64 %cv1322, 0
  br i1 %cond1323, label %bb_rcslotrole78, label %bb_rcslotowner78
bb_rcslotrole78:
  %v1324 = load i64, ptr %slot45, align 8
  store i64 %v1324, ptr %slot103, align 8
  %v1325 = load i64, ptr %slot103, align 8
  %v1326 = load i64, ptr %slot100, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1325, i64 %v1326) nomerge, !dbg !120
  br label %bb_rcslotdone78
bb_rcslotowner78:
  %v1327 = load i64, ptr %slot45, align 8
  store i64 %v1327, ptr %slot104, align 8
  %v1328 = load i64, ptr %slot104, align 8
  %v1329 = load i64, ptr %slot100, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1328, i64 %v1329) nomerge, !dbg !120
  br label %bb_rcslotdone78
bb_rcslotdone78:
  br label %bb_i61
bb_rcarmnext75:
  %v1330 = load i64, ptr %slot97, align 8
  %cmp1331 = icmp eq i64 %v1330, 1
  %cv1332 = zext i1 %cmp1331 to i64
  store i64 %cv1332, ptr %slot105, align 8
  %v1333 = load i64, ptr %slot105, align 8
  %cond1334 = icmp ne i64 %v1333, 0
  br i1 %cond1334, label %bb_rcarm85, label %bb_rcarmnext85
bb_rcarm85:
  %v1335 = load i64, ptr %slot14, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  %ld1337 = load i32, ptr %p1336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1337, ptr %slot106, align 8
  %v1338 = load i32, ptr %slot106, align 8
  %cv1339 = zext i32 %v1338 to i64
  %cond1340 = icmp ne i64 %cv1339, 0
  br i1 %cond1340, label %bb_rcslotdrop88, label %bb_rcslotdone88
bb_rcslotdrop88:
  %v1341 = load i64, ptr %slot14, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  store i32 0, ptr %p1342, align 4, !alias.scope !3, !noalias !4
  %v1343 = load i64, ptr %slot21, align 8
  store i64 %v1343, ptr %slot107, align 8
  %v1344 = load i64, ptr %slot15, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  %ld1346 = load i32, ptr %p1345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1346, ptr %slot108, align 8
  %v1347 = load i32, ptr %slot108, align 8
  %op1348 = and i32 %v1347, 28
  store i32 %op1348, ptr %slot109, align 8
  %v1349 = load i32, ptr %slot109, align 8
  %cv1350 = zext i32 %v1349 to i64
  %cond1351 = icmp ne i64 %cv1350, 0
  br i1 %cond1351, label %bb_rcslotrole88, label %bb_rcslotowner88
bb_rcslotrole88:
  %v1352 = load i64, ptr %slot45, align 8
  store i64 %v1352, ptr %slot110, align 8
  %v1353 = load i64, ptr %slot110, align 8
  %v1354 = load i64, ptr %slot107, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1353, i64 %v1354) nomerge, !dbg !120
  br label %bb_rcslotdone88
bb_rcslotowner88:
  %v1355 = load i64, ptr %slot45, align 8
  store i64 %v1355, ptr %slot111, align 8
  %v1356 = load i64, ptr %slot111, align 8
  %v1357 = load i64, ptr %slot107, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1356, i64 %v1357) nomerge, !dbg !120
  br label %bb_rcslotdone88
bb_rcslotdone88:
  br label %bb_i64
bb_rcarmnext85:
  %v1358 = load i64, ptr %slot97, align 8
  %cmp1359 = icmp eq i64 %v1358, 2
  %cv1360 = zext i1 %cmp1359 to i64
  store i64 %cv1360, ptr %slot112, align 8
  %v1361 = load i64, ptr %slot112, align 8
  %cond1362 = icmp ne i64 %v1361, 0
  br i1 %cond1362, label %bb_rcarm95, label %bb_rcarmnext95
bb_rcarm95:
  %v1363 = load i64, ptr %slot14, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %ld1365 = load i32, ptr %p1364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1365, ptr %slot113, align 8
  %v1366 = load i32, ptr %slot113, align 8
  %cv1367 = zext i32 %v1366 to i64
  %cond1368 = icmp ne i64 %cv1367, 0
  br i1 %cond1368, label %bb_rcslotdrop98, label %bb_rcslotdone98
bb_rcslotdrop98:
  %v1369 = load i64, ptr %slot14, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  store i32 0, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot21, align 8
  store i64 %v1371, ptr %slot114, align 8
  %v1372 = load i64, ptr %slot15, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  %ld1374 = load i32, ptr %p1373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1374, ptr %slot115, align 8
  %v1375 = load i32, ptr %slot115, align 8
  %op1376 = and i32 %v1375, 28
  store i32 %op1376, ptr %slot116, align 8
  %v1377 = load i32, ptr %slot116, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rcslotrole98, label %bb_rcslotowner98
bb_rcslotrole98:
  %v1380 = load i64, ptr %slot45, align 8
  store i64 %v1380, ptr %slot117, align 8
  %v1381 = load i64, ptr %slot117, align 8
  %v1382 = load i64, ptr %slot114, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1381, i64 %v1382) nomerge, !dbg !120
  br label %bb_rcslotdone98
bb_rcslotowner98:
  %v1383 = load i64, ptr %slot45, align 8
  store i64 %v1383, ptr %slot118, align 8
  %v1384 = load i64, ptr %slot118, align 8
  %v1385 = load i64, ptr %slot114, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1384, i64 %v1385) nomerge, !dbg !120
  br label %bb_rcslotdone98
bb_rcslotdone98:
  br label %bb_i67
bb_rcarmnext95:
  %v1386 = load i64, ptr %slot97, align 8
  %cmp1387 = icmp eq i64 %v1386, 3
  %cv1388 = zext i1 %cmp1387 to i64
  store i64 %cv1388, ptr %slot119, align 8
  %v1389 = load i64, ptr %slot119, align 8
  %cond1390 = icmp ne i64 %v1389, 0
  br i1 %cond1390, label %bb_rcarm105, label %bb_rcarmnext105
bb_rcarm105:
  %v1391 = load i64, ptr %slot14, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i32, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1393, ptr %slot120, align 8
  %v1394 = load i32, ptr %slot120, align 8
  %cv1395 = zext i32 %v1394 to i64
  %cond1396 = icmp ne i64 %cv1395, 0
  br i1 %cond1396, label %bb_rcslotdrop108, label %bb_rcslotdone108
bb_rcslotdrop108:
  %v1397 = load i64, ptr %slot14, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 0, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot21, align 8
  store i64 %v1399, ptr %slot121, align 8
  %v1400 = load i64, ptr %slot15, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %ld1402 = load i32, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1402, ptr %slot122, align 8
  %v1403 = load i32, ptr %slot122, align 8
  %op1404 = and i32 %v1403, 28
  store i32 %op1404, ptr %slot123, align 8
  %v1405 = load i32, ptr %slot123, align 8
  %cv1406 = zext i32 %v1405 to i64
  %cond1407 = icmp ne i64 %cv1406, 0
  br i1 %cond1407, label %bb_rcslotrole108, label %bb_rcslotowner108
bb_rcslotrole108:
  %v1408 = load i64, ptr %slot45, align 8
  store i64 %v1408, ptr %slot124, align 8
  %v1409 = load i64, ptr %slot124, align 8
  %v1410 = load i64, ptr %slot121, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1409, i64 %v1410) nomerge, !dbg !120
  br label %bb_rcslotdone108
bb_rcslotowner108:
  %v1411 = load i64, ptr %slot45, align 8
  store i64 %v1411, ptr %slot125, align 8
  %v1412 = load i64, ptr %slot125, align 8
  %v1413 = load i64, ptr %slot121, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1412, i64 %v1413) nomerge, !dbg !120
  br label %bb_rcslotdone108
bb_rcslotdone108:
  br label %bb_i70
bb_rcarmnext105:
  %v1414 = load i64, ptr %slot97, align 8
  %cmp1415 = icmp eq i64 %v1414, 4
  %cv1416 = zext i1 %cmp1415 to i64
  store i64 %cv1416, ptr %slot126, align 8
  %v1417 = load i64, ptr %slot126, align 8
  %cond1418 = icmp ne i64 %v1417, 0
  br i1 %cond1418, label %bb_rcarm115, label %bb_rcarmnext115
bb_rcarm115:
  %v1419 = load i64, ptr %slot14, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i32, ptr %p1420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1421, ptr %slot127, align 8
  %v1422 = load i32, ptr %slot127, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcslotdrop118, label %bb_rcslotdone118
bb_rcslotdrop118:
  %v1425 = load i64, ptr %slot14, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i32 0, ptr %p1426, align 4, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot21, align 8
  store i64 %v1427, ptr %slot128, align 8
  %v1428 = load i64, ptr %slot15, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  %ld1430 = load i32, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1430, ptr %slot129, align 8
  %v1431 = load i32, ptr %slot129, align 8
  %op1432 = and i32 %v1431, 28
  store i32 %op1432, ptr %slot130, align 8
  %v1433 = load i32, ptr %slot130, align 8
  %cv1434 = zext i32 %v1433 to i64
  %cond1435 = icmp ne i64 %cv1434, 0
  br i1 %cond1435, label %bb_rcslotrole118, label %bb_rcslotowner118
bb_rcslotrole118:
  %v1436 = load i64, ptr %slot45, align 8
  store i64 %v1436, ptr %slot131, align 8
  %v1437 = load i64, ptr %slot131, align 8
  %v1438 = load i64, ptr %slot128, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1437, i64 %v1438) nomerge, !dbg !120
  br label %bb_rcslotdone118
bb_rcslotowner118:
  %v1439 = load i64, ptr %slot45, align 8
  store i64 %v1439, ptr %slot132, align 8
  %v1440 = load i64, ptr %slot132, align 8
  %v1441 = load i64, ptr %slot128, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1440, i64 %v1441) nomerge, !dbg !120
  br label %bb_rcslotdone118
bb_rcslotdone118:
  br label %bb_i73
bb_rcarmnext115:
  %v1442 = load i64, ptr %slot97, align 8
  %cmp1443 = icmp eq i64 %v1442, 5
  %cv1444 = zext i1 %cmp1443 to i64
  store i64 %cv1444, ptr %slot133, align 8
  %v1445 = load i64, ptr %slot133, align 8
  %cond1446 = icmp ne i64 %v1445, 0
  br i1 %cond1446, label %bb_rcarm125, label %bb_rcarmnext125
bb_rcarm125:
  %v1447 = load i64, ptr %slot14, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i32, ptr %p1448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1449, ptr %slot134, align 8
  %v1450 = load i32, ptr %slot134, align 8
  %cv1451 = zext i32 %v1450 to i64
  %cond1452 = icmp ne i64 %cv1451, 0
  br i1 %cond1452, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1453 = load i64, ptr %slot14, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  store i32 0, ptr %p1454, align 4, !alias.scope !3, !noalias !4
  %v1455 = load i64, ptr %slot21, align 8
  store i64 %v1455, ptr %slot135, align 8
  %v1456 = load i64, ptr %slot15, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %ld1458 = load i32, ptr %p1457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1458, ptr %slot136, align 8
  %v1459 = load i32, ptr %slot136, align 8
  %op1460 = and i32 %v1459, 28
  store i32 %op1460, ptr %slot137, align 8
  %v1461 = load i32, ptr %slot137, align 8
  %cv1462 = zext i32 %v1461 to i64
  %cond1463 = icmp ne i64 %cv1462, 0
  br i1 %cond1463, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1464 = load i64, ptr %slot45, align 8
  store i64 %v1464, ptr %slot138, align 8
  %v1465 = load i64, ptr %slot138, align 8
  %v1466 = load i64, ptr %slot135, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1465, i64 %v1466) nomerge, !dbg !120
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1467 = load i64, ptr %slot45, align 8
  store i64 %v1467, ptr %slot139, align 8
  %v1468 = load i64, ptr %slot139, align 8
  %v1469 = load i64, ptr %slot135, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1468, i64 %v1469) nomerge, !dbg !120
  br label %bb_rcslotdone128
bb_rcslotdone128:
  br label %bb_i76
bb_rcarmnext125:
  %v1470 = load i64, ptr %slot97, align 8
  %cmp1471 = icmp eq i64 %v1470, 6
  %cv1472 = zext i1 %cmp1471 to i64
  store i64 %cv1472, ptr %slot140, align 8
  %v1473 = load i64, ptr %slot140, align 8
  %cond1474 = icmp ne i64 %v1473, 0
  br i1 %cond1474, label %bb_rcarm135, label %bb_rcarmnext135
bb_rcarm135:
  %v1475 = load i64, ptr %slot14, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i32, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1477, ptr %slot141, align 8
  %v1478 = load i32, ptr %slot141, align 8
  %cv1479 = zext i32 %v1478 to i64
  %cond1480 = icmp ne i64 %cv1479, 0
  br i1 %cond1480, label %bb_rcslotdrop138, label %bb_rcslotdone138
bb_rcslotdrop138:
  %v1481 = load i64, ptr %slot14, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 0, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot21, align 8
  store i64 %v1483, ptr %slot142, align 8
  %v1484 = load i64, ptr %slot15, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i32, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1486, ptr %slot143, align 8
  %v1487 = load i32, ptr %slot143, align 8
  %op1488 = and i32 %v1487, 28
  store i32 %op1488, ptr %slot144, align 8
  %v1489 = load i32, ptr %slot144, align 8
  %cv1490 = zext i32 %v1489 to i64
  %cond1491 = icmp ne i64 %cv1490, 0
  br i1 %cond1491, label %bb_rcslotrole138, label %bb_rcslotowner138
bb_rcslotrole138:
  %v1492 = load i64, ptr %slot45, align 8
  store i64 %v1492, ptr %slot145, align 8
  %v1493 = load i64, ptr %slot145, align 8
  %v1494 = load i64, ptr %slot142, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1493, i64 %v1494) nomerge, !dbg !120
  br label %bb_rcslotdone138
bb_rcslotowner138:
  %v1495 = load i64, ptr %slot45, align 8
  store i64 %v1495, ptr %slot146, align 8
  %v1496 = load i64, ptr %slot146, align 8
  %v1497 = load i64, ptr %slot142, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1496, i64 %v1497) nomerge, !dbg !120
  br label %bb_rcslotdone138
bb_rcslotdone138:
  br label %bb_i79
bb_rcarmnext135:
  %v1498 = load i64, ptr %slot97, align 8
  %cmp1499 = icmp eq i64 %v1498, 7
  %cv1500 = zext i1 %cmp1499 to i64
  store i64 %cv1500, ptr %slot147, align 8
  %v1501 = load i64, ptr %slot147, align 8
  %cond1502 = icmp ne i64 %v1501, 0
  br i1 %cond1502, label %bb_rcarm145, label %bb_rcarmnext145
bb_rcarm145:
  %v1503 = load i64, ptr %slot23, align 8
  store i64 %v1503, ptr %slot148, align 8
  %v1504 = load i64, ptr %slot96, align 8
  %op1505 = add i64 %v1504, 8
  store i64 %op1505, ptr %slot149, align 8
  %v1506 = load i64, ptr %slot46, align 8
  store i64 %v1506, ptr %slot150, align 8
  %v1507 = load i64, ptr %slot45, align 8
  %v1508 = load i64, ptr %slot148, align 8
  %v1509 = load i64, ptr %slot149, align 8
  %v1510 = load i64, ptr %slot150, align 8
  %cv1511 = trunc i64 %v1510 to i32
  %call1512 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v1507, i64 %v1508, i64 %v1509, i32 %cv1511) nomerge, !dbg !120
  store i32 %call1512, ptr %slot151, align 8
  %v1513 = load i32, ptr %slot151, align 8
  %cv1514 = zext i32 %v1513 to i64
  %cond1515 = icmp ne i64 %cv1514, 0
  br i1 %cond1515, label %bb_rcsuccess150, label %bb_rcfailure150
bb_rcfailure150:
  %v1516 = load i64, ptr %slot45, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %call1518 = call i32 @myl_rc_take_failure(ptr %p1517) nomerge, !dbg !120
  store i32 %call1518, ptr %slot152, align 8
  %v1519 = load i64, ptr %slot1, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %v1521 = load i32, ptr %slot152, align 8
  %call1522 = call i32 @myl_qbe_rc_status(ptr %p1520, i32 %v1521) nomerge, !dbg !120
  store i32 %call1522, ptr %slot153, align 8
  br label %bb_failure
bb_rcsuccess150:
  %v1523 = load i64, ptr %slot19, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 2, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot18, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i32 1, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot6, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %ld1529 = load i32, ptr %p1528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1529, ptr %slot154, align 8
  %v1530 = load i32, ptr %slot154, align 8
  %cv1531 = zext i32 %v1530 to i64
  %cond1532 = icmp ne i64 %cv1531, 0
  br i1 %cond1532, label %bb_rcslotdrop157, label %bb_rcslotdone157
bb_rcslotdrop157:
  %v1533 = load i64, ptr %slot6, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  store i32 0, ptr %p1534, align 4, !alias.scope !3, !noalias !4
  %v1535 = load i64, ptr %slot32, align 8
  store i64 %v1535, ptr %slot155, align 8
  %v1536 = load i64, ptr %slot7, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %ld1538 = load i32, ptr %p1537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1538, ptr %slot156, align 8
  %v1539 = load i32, ptr %slot156, align 8
  %op1540 = and i32 %v1539, 28
  store i32 %op1540, ptr %slot157, align 8
  %v1541 = load i32, ptr %slot157, align 8
  %cv1542 = zext i32 %v1541 to i64
  %cond1543 = icmp ne i64 %cv1542, 0
  br i1 %cond1543, label %bb_rcslotrole157, label %bb_rcslotowner157
bb_rcslotrole157:
  %v1544 = load i64, ptr %slot45, align 8
  store i64 %v1544, ptr %slot158, align 8
  %v1545 = load i64, ptr %slot158, align 8
  %v1546 = load i64, ptr %slot155, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1545, i64 %v1546) nomerge, !dbg !120
  br label %bb_rcslotdone157
bb_rcslotowner157:
  %v1547 = load i64, ptr %slot45, align 8
  store i64 %v1547, ptr %slot159, align 8
  %v1548 = load i64, ptr %slot159, align 8
  %v1549 = load i64, ptr %slot155, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v1548, i64 %v1549) nomerge, !dbg !120
  br label %bb_rcslotdone157
bb_rcslotdone157:
  %v1550 = load i64, ptr %slot148, align 8
  %v1551 = load i64, ptr %slot32, align 8
  %p1552 = inttoptr i64 %v1550 to ptr
  %p1553 = inttoptr i64 %v1551 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1553, ptr %p1552, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot18, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  store i32 0, ptr %p1555, align 4, !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot32, align 8
  store i64 %v1556, ptr %slot160, align 8
  %v1557 = load i64, ptr %slot7, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i32 2, ptr %p1558, align 4, !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot6, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 1, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot14, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %ld1563 = load i32, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1563, ptr %slot161, align 8
  %v1564 = load i32, ptr %slot161, align 8
  %cv1565 = zext i32 %v1564 to i64
  %cond1566 = icmp ne i64 %cv1565, 0
  br i1 %cond1566, label %bb_rcslotdrop170, label %bb_rcslotdone170
bb_rcslotdrop170:
  %v1567 = load i64, ptr %slot14, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i32 0, ptr %p1568, align 4, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot21, align 8
  store i64 %v1569, ptr %slot162, align 8
  %v1570 = load i64, ptr %slot15, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  %ld1572 = load i32, ptr %p1571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1572, ptr %slot163, align 8
  %v1573 = load i32, ptr %slot163, align 8
  %op1574 = and i32 %v1573, 28
  store i32 %op1574, ptr %slot164, align 8
  %v1575 = load i32, ptr %slot164, align 8
  %cv1576 = zext i32 %v1575 to i64
  %cond1577 = icmp ne i64 %cv1576, 0
  br i1 %cond1577, label %bb_rcslotrole170, label %bb_rcslotowner170
bb_rcslotrole170:
  %v1578 = load i64, ptr %slot45, align 8
  store i64 %v1578, ptr %slot165, align 8
  %v1579 = load i64, ptr %slot165, align 8
  %v1580 = load i64, ptr %slot162, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1579, i64 %v1580) nomerge, !dbg !120
  br label %bb_rcslotdone170
bb_rcslotowner170:
  %v1581 = load i64, ptr %slot45, align 8
  store i64 %v1581, ptr %slot166, align 8
  %v1582 = load i64, ptr %slot166, align 8
  %v1583 = load i64, ptr %slot162, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1582, i64 %v1583) nomerge, !dbg !120
  br label %bb_rcslotdone170
bb_rcslotdone170:
  br label %bb_i17
bb_rcarmnext145:
  %v1584 = load i64, ptr %slot97, align 8
  %cmp1585 = icmp eq i64 %v1584, 8
  %cv1586 = zext i1 %cmp1585 to i64
  store i64 %cv1586, ptr %slot167, align 8
  %v1587 = load i64, ptr %slot167, align 8
  %cond1588 = icmp ne i64 %v1587, 0
  br i1 %cond1588, label %bb_rcarm177, label %bb_rcarmnext177
bb_rcarm177:
  %v1589 = load i64, ptr %slot14, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %ld1591 = load i32, ptr %p1590, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1591, ptr %slot168, align 8
  %v1592 = load i32, ptr %slot168, align 8
  %cv1593 = zext i32 %v1592 to i64
  %cond1594 = icmp ne i64 %cv1593, 0
  br i1 %cond1594, label %bb_rcslotdrop180, label %bb_rcslotdone180
bb_rcslotdrop180:
  %v1595 = load i64, ptr %slot14, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  store i32 0, ptr %p1596, align 4, !alias.scope !3, !noalias !4
  %v1597 = load i64, ptr %slot21, align 8
  store i64 %v1597, ptr %slot169, align 8
  %v1598 = load i64, ptr %slot15, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  %ld1600 = load i32, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1600, ptr %slot170, align 8
  %v1601 = load i32, ptr %slot170, align 8
  %op1602 = and i32 %v1601, 28
  store i32 %op1602, ptr %slot171, align 8
  %v1603 = load i32, ptr %slot171, align 8
  %cv1604 = zext i32 %v1603 to i64
  %cond1605 = icmp ne i64 %cv1604, 0
  br i1 %cond1605, label %bb_rcslotrole180, label %bb_rcslotowner180
bb_rcslotrole180:
  %v1606 = load i64, ptr %slot45, align 8
  store i64 %v1606, ptr %slot172, align 8
  %v1607 = load i64, ptr %slot172, align 8
  %v1608 = load i64, ptr %slot169, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1607, i64 %v1608) nomerge, !dbg !120
  br label %bb_rcslotdone180
bb_rcslotowner180:
  %v1609 = load i64, ptr %slot45, align 8
  store i64 %v1609, ptr %slot173, align 8
  %v1610 = load i64, ptr %slot173, align 8
  %v1611 = load i64, ptr %slot169, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1610, i64 %v1611) nomerge, !dbg !120
  br label %bb_rcslotdone180
bb_rcslotdone180:
  br label %bb_i82
bb_rcarmnext177:
  %v1612 = load i64, ptr %slot97, align 8
  %cmp1613 = icmp eq i64 %v1612, 9
  %cv1614 = zext i1 %cmp1613 to i64
  store i64 %cv1614, ptr %slot174, align 8
  %v1615 = load i64, ptr %slot174, align 8
  %cond1616 = icmp ne i64 %v1615, 0
  br i1 %cond1616, label %bb_rcarm187, label %bb_rcarmnext187
bb_rcarm187:
  %v1617 = load i64, ptr %slot14, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i32, ptr %p1618, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1619, ptr %slot175, align 8
  %v1620 = load i32, ptr %slot175, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcslotdrop190, label %bb_rcslotdone190
bb_rcslotdrop190:
  %v1623 = load i64, ptr %slot14, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  store i32 0, ptr %p1624, align 4, !alias.scope !3, !noalias !4
  %v1625 = load i64, ptr %slot21, align 8
  store i64 %v1625, ptr %slot176, align 8
  %v1626 = load i64, ptr %slot15, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i32, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1628, ptr %slot177, align 8
  %v1629 = load i32, ptr %slot177, align 8
  %op1630 = and i32 %v1629, 28
  store i32 %op1630, ptr %slot178, align 8
  %v1631 = load i32, ptr %slot178, align 8
  %cv1632 = zext i32 %v1631 to i64
  %cond1633 = icmp ne i64 %cv1632, 0
  br i1 %cond1633, label %bb_rcslotrole190, label %bb_rcslotowner190
bb_rcslotrole190:
  %v1634 = load i64, ptr %slot45, align 8
  store i64 %v1634, ptr %slot179, align 8
  %v1635 = load i64, ptr %slot179, align 8
  %v1636 = load i64, ptr %slot176, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1635, i64 %v1636) nomerge, !dbg !120
  br label %bb_rcslotdone190
bb_rcslotowner190:
  %v1637 = load i64, ptr %slot45, align 8
  store i64 %v1637, ptr %slot180, align 8
  %v1638 = load i64, ptr %slot180, align 8
  %v1639 = load i64, ptr %slot176, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1638, i64 %v1639) nomerge, !dbg !120
  br label %bb_rcslotdone190
bb_rcslotdone190:
  br label %bb_i85
bb_rcarmnext187:
  %v1640 = load i64, ptr %slot97, align 8
  %cmp1641 = icmp eq i64 %v1640, 10
  %cv1642 = zext i1 %cmp1641 to i64
  store i64 %cv1642, ptr %slot181, align 8
  %v1643 = load i64, ptr %slot181, align 8
  %cond1644 = icmp ne i64 %v1643, 0
  br i1 %cond1644, label %bb_rcarm197, label %bb_rcarmnext197
bb_rcarm197:
  %v1645 = load i64, ptr %slot14, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %ld1647 = load i32, ptr %p1646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1647, ptr %slot182, align 8
  %v1648 = load i32, ptr %slot182, align 8
  %cv1649 = zext i32 %v1648 to i64
  %cond1650 = icmp ne i64 %cv1649, 0
  br i1 %cond1650, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1651 = load i64, ptr %slot14, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i32 0, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot21, align 8
  store i64 %v1653, ptr %slot183, align 8
  %v1654 = load i64, ptr %slot15, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i32, ptr %p1655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1656, ptr %slot184, align 8
  %v1657 = load i32, ptr %slot184, align 8
  %op1658 = and i32 %v1657, 28
  store i32 %op1658, ptr %slot185, align 8
  %v1659 = load i32, ptr %slot185, align 8
  %cv1660 = zext i32 %v1659 to i64
  %cond1661 = icmp ne i64 %cv1660, 0
  br i1 %cond1661, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1662 = load i64, ptr %slot45, align 8
  store i64 %v1662, ptr %slot186, align 8
  %v1663 = load i64, ptr %slot186, align 8
  %v1664 = load i64, ptr %slot183, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1663, i64 %v1664) nomerge, !dbg !120
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1665 = load i64, ptr %slot45, align 8
  store i64 %v1665, ptr %slot187, align 8
  %v1666 = load i64, ptr %slot187, align 8
  %v1667 = load i64, ptr %slot183, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1666, i64 %v1667) nomerge, !dbg !120
  br label %bb_rcslotdone200
bb_rcslotdone200:
  br label %bb_i88
bb_rcarmnext197:
  br label %bb_failure
bb_i17:
  %v1668 = load i64, ptr %slot32, align 8
  %v1669 = load i64, ptr %slot39, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  store i64 %v1668, ptr %p1670, align 8, !alias.scope !3, !noalias !4
  %v1671 = load i64, ptr %slot6, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i32, ptr %p1672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1673, ptr %slot188, align 8
  %v1674 = load i64, ptr %slot7, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  %ld1676 = load i32, ptr %p1675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1676, ptr %slot189, align 8
  %v1677 = load i32, ptr %slot189, align 8
  %op1678 = and i32 %v1677, 24
  store i32 %op1678, ptr %slot189, align 8
  %v1679 = load i32, ptr %slot189, align 8
  %cmp1680 = icmp eq i32 %v1679, 0
  %cv1681 = zext i1 %cmp1680 to i32
  store i32 %cv1681, ptr %slot190, align 8
  %v1682 = load i32, ptr %slot188, align 8
  %v1683 = load i32, ptr %slot190, align 8
  %op1684 = and i32 %v1682, %v1683
  store i32 %op1684, ptr %slot191, align 8
  %v1685 = load i32, ptr %slot191, align 8
  %cv1686 = zext i32 %v1685 to i64
  %cond1687 = icmp ne i64 %cv1686, 0
  br i1 %cond1687, label %bb_rcselfkept213, label %bb_rcselfstore213
bb_rcselfstore213:
  %v1688 = load i64, ptr %slot39, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %ld1690 = load i64, ptr %p1689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1690, ptr %slot192, align 8
  %v1691 = load i64, ptr %slot14, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i32, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1693, ptr %slot193, align 8
  %v1694 = load i64, ptr %slot15, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i32, ptr %p1695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1696, ptr %slot194, align 8
  %v1697 = load i32, ptr %slot194, align 8
  %op1698 = and i32 %v1697, 24
  store i32 %op1698, ptr %slot194, align 8
  %v1699 = load i32, ptr %slot194, align 8
  %cmp1700 = icmp eq i32 %v1699, 0
  %cv1701 = zext i1 %cmp1700 to i32
  store i32 %cv1701, ptr %slot195, align 8
  %v1702 = load i32, ptr %slot193, align 8
  %v1703 = load i32, ptr %slot195, align 8
  %op1704 = and i32 %v1702, %v1703
  store i32 %op1704, ptr %slot196, align 8
  %v1705 = load i32, ptr %slot196, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rctake215, label %bb_rccopy215
bb_rctake215:
  %v1708 = load i64, ptr %slot23, align 8
  store i64 %v1708, ptr %slot197, align 8
  %v1709 = load i64, ptr %slot46, align 8
  store i64 %v1709, ptr %slot198, align 8
  %v1710 = load i64, ptr %slot192, align 8
  %v1711 = load i64, ptr %slot197, align 8
  %op1712 = sub i64 %v1710, %v1711
  store i64 %op1712, ptr %slot199, align 8
  %v1713 = load i64, ptr %slot197, align 8
  %v1714 = load i64, ptr %slot192, align 8
  %op1715 = sub i64 %v1713, %v1714
  store i64 %op1715, ptr %slot200, align 8
  %v1716 = load i64, ptr %slot199, align 8
  %cmp1717 = icmp ult i64 %v1716, 24
  %cv1718 = zext i1 %cmp1717 to i32
  store i32 %cv1718, ptr %slot201, align 8
  %v1719 = load i64, ptr %slot200, align 8
  %cmp1720 = icmp ult i64 %v1719, 24
  %cv1721 = zext i1 %cmp1720 to i32
  store i32 %cv1721, ptr %slot202, align 8
  %v1722 = load i32, ptr %slot201, align 8
  %v1723 = load i32, ptr %slot202, align 8
  %op1724 = or i32 %v1722, %v1723
  store i32 %op1724, ptr %slot203, align 8
  %v1725 = load i32, ptr %slot203, align 8
  %cv1726 = zext i32 %v1725 to i64
  %cond1727 = icmp ne i64 %cv1726, 0
  br i1 %cond1727, label %bb_rcmoveslow224, label %bb_rcmovecheck224
bb_rcmovecheck224:
  %v1728 = load i64, ptr %slot192, align 8
  %op1729 = add i64 %v1728, 8
  store i64 %op1729, ptr %slot204, align 8
  %v1730 = load i64, ptr %slot204, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  %ld1732 = load i64, ptr %p1731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1732, ptr %slot205, align 8
  %v1733 = load i64, ptr %slot205, align 8
  %cmp1734 = icmp ne i64 %v1733, 0
  %cv1735 = zext i1 %cmp1734 to i32
  store i32 %cv1735, ptr %slot206, align 8
  %v1736 = load i32, ptr %slot206, align 8
  %cv1737 = zext i32 %v1736 to i64
  %cond1738 = icmp ne i64 %cv1737, 0
  br i1 %cond1738, label %bb_rcmoveheader232, label %bb_rcmovenext232
bb_rcmoveheader232:
  %v1739 = load i64, ptr %slot205, align 8
  %op1740 = sub i64 %v1739, 16
  store i64 %op1740, ptr %slot207, align 8
  %v1741 = load i64, ptr %slot205, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %rgep1743 = getelementptr i8, ptr %p1742, i64 -16
  %ld1744 = load i64, ptr %rgep1743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1744, ptr %slot208, align 8
  %v1745 = load i64, ptr %slot208, align 8
  %op1746 = and i64 %v1745, 5764607523034234881
  store i64 %op1746, ptr %slot209, align 8
  %v1747 = load i64, ptr %slot209, align 8
  %cmp1748 = icmp ne i64 %v1747, 0
  %cv1749 = zext i1 %cmp1748 to i32
  store i32 %cv1749, ptr %slot210, align 8
  %v1750 = load i32, ptr %slot210, align 8
  %cv1751 = zext i32 %v1750 to i64
  %cond1752 = icmp ne i64 %cv1751, 0
  br i1 %cond1752, label %bb_rcmoveslow224, label %bb_rcmovenext232
bb_rcmovenext232:
  %v1753 = load i64, ptr %slot192, align 8
  %v1754 = load i64, ptr %slot197, align 8
  %p1755 = inttoptr i64 %v1753 to ptr
  %p1756 = inttoptr i64 %v1754 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1756, ptr %p1755, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot192, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  store i64 0, ptr %p1758, align 8, !alias.scope !3, !noalias !4
  %v1759 = load i64, ptr %slot192, align 8
  %op1760 = add i64 %v1759, 8
  store i64 %op1760, ptr %slot211, align 8
  %v1761 = load i64, ptr %slot211, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  store i64 0, ptr %p1762, align 8, !alias.scope !3, !noalias !4
  %v1763 = load i64, ptr %slot192, align 8
  %op1764 = add i64 %v1763, 16
  store i64 %op1764, ptr %slot212, align 8
  %v1765 = load i64, ptr %slot212, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  store i64 0, ptr %p1766, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved224
bb_rcmoveslow224:
  %v1767 = load i64, ptr %slot45, align 8
  %v1768 = load i64, ptr %slot197, align 8
  %v1769 = load i64, ptr %slot192, align 8
  %v1770 = load i64, ptr %slot198, align 8
  %cv1771 = trunc i64 %v1770 to i32
  %call1772 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v1767, i64 %v1768, i64 %v1769, i32 %cv1771) nomerge, !dbg !122
  store i32 %call1772, ptr %slot213, align 8
  %v1773 = load i32, ptr %slot213, align 8
  %cv1774 = zext i32 %v1773 to i64
  %cond1775 = icmp ne i64 %cv1774, 0
  br i1 %cond1775, label %bb_rcsuccess241, label %bb_rcfailure241
bb_rcfailure241:
  %v1776 = load i64, ptr %slot45, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  %call1778 = call i32 @myl_rc_take_failure(ptr %p1777) nomerge, !dbg !122
  store i32 %call1778, ptr %slot214, align 8
  %v1779 = load i64, ptr %slot1, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %v1781 = load i32, ptr %slot214, align 8
  %call1782 = call i32 @myl_qbe_rc_status(ptr %p1780, i32 %v1781) nomerge, !dbg !122
  store i32 %call1782, ptr %slot215, align 8
  br label %bb_failure
bb_rcsuccess241:
  br label %bb_rcmoved224
bb_rcmoved224:
  %v1783 = load i64, ptr %slot14, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  store i32 0, ptr %p1784, align 4, !alias.scope !3, !noalias !4
  %v1785 = load i64, ptr %slot19, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i32 2, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot18, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i32 1, ptr %p1788, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared215
bb_rccopy215:
  %v1789 = load i64, ptr %slot23, align 8
  store i64 %v1789, ptr %slot216, align 8
  %v1790 = load i64, ptr %slot46, align 8
  store i64 %v1790, ptr %slot217, align 8
  %v1791 = load i64, ptr %slot45, align 8
  %v1792 = load i64, ptr %slot216, align 8
  %v1793 = load i64, ptr %slot192, align 8
  %v1794 = load i64, ptr %slot217, align 8
  %cv1795 = trunc i64 %v1794 to i32
  %call1796 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v1791, i64 %v1792, i64 %v1793, i32 %cv1795) nomerge, !dbg !122
  store i32 %call1796, ptr %slot218, align 8
  %v1797 = load i32, ptr %slot218, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcsuccess250, label %bb_rcfailure250
bb_rcfailure250:
  %v1800 = load i64, ptr %slot45, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %call1802 = call i32 @myl_rc_take_failure(ptr %p1801) nomerge, !dbg !122
  store i32 %call1802, ptr %slot219, align 8
  %v1803 = load i64, ptr %slot1, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %v1805 = load i32, ptr %slot219, align 8
  %call1806 = call i32 @myl_qbe_rc_status(ptr %p1804, i32 %v1805) nomerge, !dbg !122
  store i32 %call1806, ptr %slot220, align 8
  br label %bb_failure
bb_rcsuccess250:
  %v1807 = load i64, ptr %slot19, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 2, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot18, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 1, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot14, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i32, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1813, ptr %slot221, align 8
  %v1814 = load i32, ptr %slot221, align 8
  %cv1815 = zext i32 %v1814 to i64
  %cond1816 = icmp ne i64 %cv1815, 0
  br i1 %cond1816, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v1817 = load i64, ptr %slot14, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot21, align 8
  store i64 %v1819, ptr %slot222, align 8
  %v1820 = load i64, ptr %slot15, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  %ld1822 = load i32, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1822, ptr %slot223, align 8
  %v1823 = load i32, ptr %slot223, align 8
  %op1824 = and i32 %v1823, 28
  store i32 %op1824, ptr %slot224, align 8
  %v1825 = load i32, ptr %slot224, align 8
  %cv1826 = zext i32 %v1825 to i64
  %cond1827 = icmp ne i64 %cv1826, 0
  br i1 %cond1827, label %bb_rcslotrole257, label %bb_rcslotowner257
bb_rcslotrole257:
  %v1828 = load i64, ptr %slot45, align 8
  store i64 %v1828, ptr %slot225, align 8
  %v1829 = load i64, ptr %slot225, align 8
  %v1830 = load i64, ptr %slot222, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1829, i64 %v1830) nomerge, !dbg !122
  br label %bb_rcslotdone257
bb_rcslotowner257:
  %v1831 = load i64, ptr %slot222, align 8
  %p1833 = inttoptr i64 %v1831 to ptr
  %gep1834 = getelementptr i8, ptr %p1833, i64 8
  %op1832 = ptrtoint ptr %gep1834 to i64
  store i64 %op1832, ptr %slot226, align 8
  %v1835 = load i64, ptr %slot45, align 8
  store i64 %v1835, ptr %slot227, align 8
  %v1836 = load i64, ptr %slot226, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot228, align 8
  %v1839 = load i64, ptr %slot228, align 8
  %cmp1840 = icmp ne i64 %v1839, 0
  %cv1841 = zext i1 %cmp1840 to i32
  store i32 %cv1841, ptr %slot229, align 8
  %v1842 = load i32, ptr %slot229, align 8
  %cv1843 = zext i32 %v1842 to i64
  %cond1844 = icmp ne i64 %cv1843, 0
  br i1 %cond1844, label %bb_rcgnn275, label %bb_rcgdone275
bb_rcgnn275:
  %v1845 = load i64, ptr %slot228, align 8
  %op1846 = sub i64 %v1845, 16
  store i64 %op1846, ptr %slot230, align 8
  %v1847 = load i64, ptr %slot228, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %rgep1849 = getelementptr i8, ptr %p1848, i64 -16
  %ld1850 = load i64, ptr %rgep1849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1850, ptr %slot231, align 8
  %v1851 = load i64, ptr %slot231, align 8
  %op1852 = and i64 %v1851, 4611686018427387906
  store i64 %op1852, ptr %slot232, align 8
  %v1853 = load i64, ptr %slot232, align 8
  %cmp1854 = icmp ne i64 %v1853, 0
  %cv1855 = zext i1 %cmp1854 to i32
  store i32 %cv1855, ptr %slot233, align 8
  %v1856 = load i32, ptr %slot233, align 8
  %cv1857 = zext i32 %v1856 to i64
  %cond1858 = icmp ne i64 %cv1857, 0
  br i1 %cond1858, label %bb_rcgclear275, label %bb_rcgcounted275
bb_rcgcounted275:
  %v1859 = load i64, ptr %slot228, align 8
  %op1860 = sub i64 %v1859, 32
  store i64 %op1860, ptr %slot234, align 8
  %v1861 = load i64, ptr %slot228, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %rgep1863 = getelementptr i8, ptr %p1862, i64 -32
  %ld1864 = load i64, ptr %rgep1863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1864, ptr %slot235, align 8
  %v1865 = load i64, ptr %slot235, align 8
  %op1866 = sub i64 %v1865, 1
  store i64 %op1866, ptr %slot236, align 8
  %v1867 = load i64, ptr %slot236, align 8
  %cmp1868 = icmp eq i64 %v1867, 0
  %cv1869 = zext i1 %cmp1868 to i32
  store i32 %cv1869, ptr %slot237, align 8
  %v1870 = load i32, ptr %slot237, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcglast275, label %bb_rcgdec275
bb_rcglast275:
  %v1873 = load i64, ptr %slot228, align 8
  %op1874 = sub i64 %v1873, 24
  store i64 %op1874, ptr %slot238, align 8
  %v1875 = load i64, ptr %slot228, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %rgep1877 = getelementptr i8, ptr %p1876, i64 -24
  %ld1878 = load i64, ptr %rgep1877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1878, ptr %slot239, align 8
  %v1879 = load i64, ptr %slot239, align 8
  %cmp1880 = icmp ne i64 %v1879, 0
  %cv1881 = zext i1 %cmp1880 to i32
  store i32 %cv1881, ptr %slot240, align 8
  %v1882 = load i32, ptr %slot240, align 8
  %cv1883 = zext i32 %v1882 to i64
  %cond1884 = icmp ne i64 %cv1883, 0
  br i1 %cond1884, label %bb_rcgdec275, label %bb_rcgslow275
bb_rcgslow275:
  %v1885 = load i64, ptr %slot227, align 8
  %v1886 = load i64, ptr %slot226, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1885, i64 %v1886) nomerge, !dbg !122
  br label %bb_rcgdone275
bb_rcgdec275:
  %v1887 = load i64, ptr %slot236, align 8
  %v1888 = load i64, ptr %slot228, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %rgep1890 = getelementptr i8, ptr %p1889, i64 -32
  store i64 %v1887, ptr %rgep1890, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear275
bb_rcgclear275:
  %v1891 = load i64, ptr %slot226, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i64 0, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone275
bb_rcgdone275:
  %v1893 = load i64, ptr %slot222, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  store i64 0, ptr %p1894, align 8, !alias.scope !3, !noalias !4
  %v1895 = load i64, ptr %slot222, align 8
  %p1897 = inttoptr i64 %v1895 to ptr
  %gep1898 = getelementptr i8, ptr %p1897, i64 8
  %op1896 = ptrtoint ptr %gep1898 to i64
  store i64 %op1896, ptr %slot241, align 8
  %v1899 = load i64, ptr %slot241, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  store i64 0, ptr %p1900, align 8, !alias.scope !3, !noalias !4
  %v1901 = load i64, ptr %slot222, align 8
  %p1903 = inttoptr i64 %v1901 to ptr
  %gep1904 = getelementptr i8, ptr %p1903, i64 16
  %op1902 = ptrtoint ptr %gep1904 to i64
  store i64 %op1902, ptr %slot242, align 8
  %v1905 = load i64, ptr %slot242, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  store i64 0, ptr %p1906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone257
bb_rcslotdone257:
  br label %bb_rcprepared215
bb_rcprepared215:
  %v1907 = load i64, ptr %slot6, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  %ld1909 = load i32, ptr %p1908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1909, ptr %slot243, align 8
  %v1910 = load i32, ptr %slot243, align 8
  %cv1911 = zext i32 %v1910 to i64
  %cond1912 = icmp ne i64 %cv1911, 0
  br i1 %cond1912, label %bb_rcslotdrop284, label %bb_rcslotdone284
bb_rcslotdrop284:
  %v1913 = load i64, ptr %slot6, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i32 0, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot32, align 8
  store i64 %v1915, ptr %slot244, align 8
  %v1916 = load i64, ptr %slot7, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i32, ptr %p1917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1918, ptr %slot245, align 8
  %v1919 = load i32, ptr %slot245, align 8
  %op1920 = and i32 %v1919, 28
  store i32 %op1920, ptr %slot246, align 8
  %v1921 = load i32, ptr %slot246, align 8
  %cv1922 = zext i32 %v1921 to i64
  %cond1923 = icmp ne i64 %cv1922, 0
  br i1 %cond1923, label %bb_rcslotrole284, label %bb_rcslotowner284
bb_rcslotrole284:
  %v1924 = load i64, ptr %slot45, align 8
  store i64 %v1924, ptr %slot247, align 8
  %v1925 = load i64, ptr %slot247, align 8
  %v1926 = load i64, ptr %slot244, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1925, i64 %v1926) nomerge, !dbg !122
  br label %bb_rcslotdone284
bb_rcslotowner284:
  %v1927 = load i64, ptr %slot244, align 8
  %p1929 = inttoptr i64 %v1927 to ptr
  %gep1930 = getelementptr i8, ptr %p1929, i64 8
  %op1928 = ptrtoint ptr %gep1930 to i64
  store i64 %op1928, ptr %slot248, align 8
  %v1931 = load i64, ptr %slot45, align 8
  store i64 %v1931, ptr %slot249, align 8
  %v1932 = load i64, ptr %slot248, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %ld1934 = load i64, ptr %p1933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1934, ptr %slot250, align 8
  %v1935 = load i64, ptr %slot250, align 8
  %cmp1936 = icmp ne i64 %v1935, 0
  %cv1937 = zext i1 %cmp1936 to i32
  store i32 %cv1937, ptr %slot251, align 8
  %v1938 = load i32, ptr %slot251, align 8
  %cv1939 = zext i32 %v1938 to i64
  %cond1940 = icmp ne i64 %cv1939, 0
  br i1 %cond1940, label %bb_rcgnn302, label %bb_rcgdone302
bb_rcgnn302:
  %v1941 = load i64, ptr %slot250, align 8
  %op1942 = sub i64 %v1941, 16
  store i64 %op1942, ptr %slot252, align 8
  %v1943 = load i64, ptr %slot250, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %rgep1945 = getelementptr i8, ptr %p1944, i64 -16
  %ld1946 = load i64, ptr %rgep1945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1946, ptr %slot253, align 8
  %v1947 = load i64, ptr %slot253, align 8
  %op1948 = and i64 %v1947, 4611686018427387906
  store i64 %op1948, ptr %slot254, align 8
  %v1949 = load i64, ptr %slot254, align 8
  %cmp1950 = icmp ne i64 %v1949, 0
  %cv1951 = zext i1 %cmp1950 to i32
  store i32 %cv1951, ptr %slot255, align 8
  %v1952 = load i32, ptr %slot255, align 8
  %cv1953 = zext i32 %v1952 to i64
  %cond1954 = icmp ne i64 %cv1953, 0
  br i1 %cond1954, label %bb_rcgclear302, label %bb_rcgcounted302
bb_rcgcounted302:
  %v1955 = load i64, ptr %slot250, align 8
  %op1956 = sub i64 %v1955, 32
  store i64 %op1956, ptr %slot256, align 8
  %v1957 = load i64, ptr %slot250, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %rgep1959 = getelementptr i8, ptr %p1958, i64 -32
  %ld1960 = load i64, ptr %rgep1959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1960, ptr %slot257, align 8
  %v1961 = load i64, ptr %slot257, align 8
  %op1962 = sub i64 %v1961, 1
  store i64 %op1962, ptr %slot258, align 8
  %v1963 = load i64, ptr %slot258, align 8
  %cmp1964 = icmp eq i64 %v1963, 0
  %cv1965 = zext i1 %cmp1964 to i32
  store i32 %cv1965, ptr %slot259, align 8
  %v1966 = load i32, ptr %slot259, align 8
  %cv1967 = zext i32 %v1966 to i64
  %cond1968 = icmp ne i64 %cv1967, 0
  br i1 %cond1968, label %bb_rcglast302, label %bb_rcgdec302
bb_rcglast302:
  %v1969 = load i64, ptr %slot250, align 8
  %op1970 = sub i64 %v1969, 24
  store i64 %op1970, ptr %slot260, align 8
  %v1971 = load i64, ptr %slot250, align 8
  %p1972 = inttoptr i64 %v1971 to ptr
  %rgep1973 = getelementptr i8, ptr %p1972, i64 -24
  %ld1974 = load i64, ptr %rgep1973, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1974, ptr %slot261, align 8
  %v1975 = load i64, ptr %slot261, align 8
  %cmp1976 = icmp ne i64 %v1975, 0
  %cv1977 = zext i1 %cmp1976 to i32
  store i32 %cv1977, ptr %slot262, align 8
  %v1978 = load i32, ptr %slot262, align 8
  %cv1979 = zext i32 %v1978 to i64
  %cond1980 = icmp ne i64 %cv1979, 0
  br i1 %cond1980, label %bb_rcgdec302, label %bb_rcgslow302
bb_rcgslow302:
  %v1981 = load i64, ptr %slot249, align 8
  %v1982 = load i64, ptr %slot248, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1981, i64 %v1982) nomerge, !dbg !122
  br label %bb_rcgdone302
bb_rcgdec302:
  %v1983 = load i64, ptr %slot258, align 8
  %v1984 = load i64, ptr %slot250, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %rgep1986 = getelementptr i8, ptr %p1985, i64 -32
  store i64 %v1983, ptr %rgep1986, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear302
bb_rcgclear302:
  %v1987 = load i64, ptr %slot248, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i64 0, ptr %p1988, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone302
bb_rcgdone302:
  %v1989 = load i64, ptr %slot244, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i64 0, ptr %p1990, align 8, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot244, align 8
  %p1993 = inttoptr i64 %v1991 to ptr
  %gep1994 = getelementptr i8, ptr %p1993, i64 8
  %op1992 = ptrtoint ptr %gep1994 to i64
  store i64 %op1992, ptr %slot263, align 8
  %v1995 = load i64, ptr %slot263, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i64 0, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot244, align 8
  %p1999 = inttoptr i64 %v1997 to ptr
  %gep2000 = getelementptr i8, ptr %p1999, i64 16
  %op1998 = ptrtoint ptr %gep2000 to i64
  store i64 %op1998, ptr %slot264, align 8
  %v2001 = load i64, ptr %slot264, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  store i64 0, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone284
bb_rcslotdone284:
  %v2003 = load i64, ptr %slot32, align 8
  store i64 %v2003, ptr %slot265, align 8
  %v2004 = load i64, ptr %slot23, align 8
  store i64 %v2004, ptr %slot266, align 8
  %v2005 = load i64, ptr %slot266, align 8
  %v2006 = load i64, ptr %slot265, align 8
  %p2007 = inttoptr i64 %v2005 to ptr
  %p2008 = inttoptr i64 %v2006 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2008, ptr %p2007, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot18, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i32 0, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot7, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i32 2, ptr %p2012, align 4, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot19, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %ld2015 = load i32, ptr %p2014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2015, ptr %slot267, align 8
  %v2016 = load i32, ptr %slot267, align 8
  %v2017 = load i64, ptr %slot7, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i32 %v2016, ptr %p2018, align 4, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot6, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  store i32 1, ptr %p2020, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcselfkept213
bb_rcselfkept213:
  %v2021 = load i64, ptr %slot32, align 8
  %v2022 = load i64, ptr %slot39, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  store i64 %v2021, ptr %p2023, align 8, !alias.scope !3, !noalias !4
  %v2024 = load i64, ptr %slot39, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %ld2026 = load i64, ptr %p2025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2026, ptr %slot268, align 8
  %v2027 = load i64, ptr %slot14, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %ld2029 = load i32, ptr %p2028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2029, ptr %slot269, align 8
  %v2030 = load i64, ptr %slot15, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i32, ptr %p2031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2032, ptr %slot270, align 8
  %v2033 = load i32, ptr %slot270, align 8
  %op2034 = and i32 %v2033, 24
  store i32 %op2034, ptr %slot270, align 8
  %v2035 = load i32, ptr %slot270, align 8
  %cmp2036 = icmp eq i32 %v2035, 0
  %cv2037 = zext i1 %cmp2036 to i32
  store i32 %cv2037, ptr %slot271, align 8
  %v2038 = load i32, ptr %slot269, align 8
  %v2039 = load i32, ptr %slot271, align 8
  %op2040 = and i32 %v2038, %v2039
  store i32 %op2040, ptr %slot272, align 8
  %v2041 = load i64, ptr %slot46, align 8
  store i64 %v2041, ptr %slot273, align 8
  %v2042 = load i32, ptr %slot272, align 8
  %op2043 = mul i32 %v2042, 4
  store i32 %op2043, ptr %slot274, align 8
  %v2044 = load i32, ptr %slot274, align 8
  %op2045 = or i32 %v2044, 0
  store i32 %op2045, ptr %slot275, align 8
  %v2046 = load i64, ptr %slot23, align 8
  store i64 %v2046, ptr %slot276, align 8
  %v2047 = load i64, ptr %slot45, align 8
  %v2048 = load i64, ptr %slot276, align 8
  %v2049 = load i64, ptr %slot268, align 8
  %v2050 = load i64, ptr %slot273, align 8
  %cv2051 = trunc i64 %v2050 to i32
  %v2052 = load i32, ptr %slot275, align 8
  %call2053 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64 %v2047, i64 %v2048, i64 %v2049, i32 %cv2051, i32 %v2052) nomerge, !dbg !124
  store i32 %call2053, ptr %slot277, align 8
  %v2054 = load i32, ptr %slot277, align 8
  %cv2055 = zext i32 %v2054 to i64
  %cond2056 = icmp ne i64 %cv2055, 0
  br i1 %cond2056, label %bb_rcsuccess329, label %bb_rcfailure329
bb_rcfailure329:
  %v2057 = load i64, ptr %slot45, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %call2059 = call i32 @myl_rc_take_failure(ptr %p2058) nomerge, !dbg !124
  store i32 %call2059, ptr %slot278, align 8
  %v2060 = load i64, ptr %slot1, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %v2062 = load i32, ptr %slot278, align 8
  %call2063 = call i32 @myl_qbe_rc_status(ptr %p2061, i32 %v2062) nomerge, !dbg !124
  store i32 %call2063, ptr %slot279, align 8
  br label %bb_failure
bb_rcsuccess329:
  %v2064 = load i32, ptr %slot272, align 8
  %cv2065 = zext i32 %v2064 to i64
  %cond2066 = icmp ne i64 %cv2065, 0
  br i1 %cond2066, label %bb_rchtaken332, label %bb_rchcopied332
bb_rchcopied332:
  %v2067 = load i64, ptr %slot14, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %ld2069 = load i32, ptr %p2068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2069, ptr %slot280, align 8
  %v2070 = load i32, ptr %slot280, align 8
  %cv2071 = zext i32 %v2070 to i64
  %cond2072 = icmp ne i64 %cv2071, 0
  br i1 %cond2072, label %bb_rcslotdrop335, label %bb_rcslotdone335
bb_rcslotdrop335:
  %v2073 = load i64, ptr %slot14, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  store i32 0, ptr %p2074, align 4, !alias.scope !3, !noalias !4
  %v2075 = load i64, ptr %slot21, align 8
  store i64 %v2075, ptr %slot281, align 8
  %v2076 = load i64, ptr %slot15, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %ld2078 = load i32, ptr %p2077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2078, ptr %slot282, align 8
  %v2079 = load i32, ptr %slot282, align 8
  %op2080 = and i32 %v2079, 28
  store i32 %op2080, ptr %slot283, align 8
  %v2081 = load i32, ptr %slot283, align 8
  %cv2082 = zext i32 %v2081 to i64
  %cond2083 = icmp ne i64 %cv2082, 0
  br i1 %cond2083, label %bb_rcslotrole335, label %bb_rcslotowner335
bb_rcslotrole335:
  %v2084 = load i64, ptr %slot45, align 8
  store i64 %v2084, ptr %slot284, align 8
  %v2085 = load i64, ptr %slot284, align 8
  %v2086 = load i64, ptr %slot281, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2085, i64 %v2086) nomerge, !dbg !124
  br label %bb_rcslotdone335
bb_rcslotowner335:
  %v2087 = load i64, ptr %slot45, align 8
  store i64 %v2087, ptr %slot285, align 8
  %v2088 = load i64, ptr %slot285, align 8
  %v2089 = load i64, ptr %slot281, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v2088, i64 %v2089) nomerge, !dbg !124
  br label %bb_rcslotdone335
bb_rcslotdone335:
  br label %bb_rchprepared332
bb_rchtaken332:
  %v2090 = load i64, ptr %slot14, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i32 0, ptr %p2091, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared332
bb_rchprepared332:
  %v2092 = load i64, ptr %slot19, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  store i32 2, ptr %p2093, align 4, !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot18, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 1, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot21, align 8
  store i64 %v2096, ptr %slot286, align 8
  %v2097 = load i64, ptr %slot23, align 8
  store i64 %v2097, ptr %slot287, align 8
  %v2098 = load i64, ptr %slot287, align 8
  %v2099 = load i64, ptr %slot286, align 8
  %p2100 = inttoptr i64 %v2098 to ptr
  %p2101 = inttoptr i64 %v2099 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2101, ptr %p2100, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2102 = load i64, ptr %slot15, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i32 2, ptr %p2103, align 4, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot19, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i32, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2106, ptr %slot288, align 8
  %v2107 = load i32, ptr %slot288, align 8
  %v2108 = load i64, ptr %slot15, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i32 %v2107, ptr %p2109, align 4, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot18, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  store i32 0, ptr %p2111, align 4, !alias.scope !3, !noalias !4
  %v2112 = load i64, ptr %slot14, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i32 1, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot286, align 8
  %v2115 = load i64, ptr %slot39, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  store i64 %v2114, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  %v2117 = load i64, ptr %slot39, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i64, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2119, ptr %slot289, align 8
  %v2120 = load i64, ptr %slot23, align 8
  store i64 %v2120, ptr %slot290, align 8
  %v2121 = load i64, ptr %slot46, align 8
  store i64 %v2121, ptr %slot291, align 8
  %v2122 = load i64, ptr %slot289, align 8
  %op2123 = add i64 %v2122, 8
  store i64 %op2123, ptr %slot292, align 8
  %v2124 = load i64, ptr %slot292, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %ld2126 = load i64, ptr %p2125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2126, ptr %slot293, align 8
  %v2127 = load i64, ptr %slot293, align 8
  %cmp2128 = icmp ne i64 %v2127, 0
  %cv2129 = zext i1 %cmp2128 to i32
  store i32 %cv2129, ptr %slot294, align 8
  %v2130 = load i32, ptr %slot294, align 8
  %cv2131 = zext i32 %v2130 to i64
  %cond2132 = icmp ne i64 %cv2131, 0
  br i1 %cond2132, label %bb_rcmoveheader359, label %bb_rcmovenext359
bb_rcmoveheader359:
  %v2133 = load i64, ptr %slot293, align 8
  %op2134 = sub i64 %v2133, 16
  store i64 %op2134, ptr %slot295, align 8
  %v2135 = load i64, ptr %slot293, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  %rgep2137 = getelementptr i8, ptr %p2136, i64 -16
  %ld2138 = load i64, ptr %rgep2137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2138, ptr %slot296, align 8
  %v2139 = load i64, ptr %slot296, align 8
  %op2140 = and i64 %v2139, 5764607523034234881
  store i64 %op2140, ptr %slot297, align 8
  %v2141 = load i64, ptr %slot297, align 8
  %cmp2142 = icmp ne i64 %v2141, 0
  %cv2143 = zext i1 %cmp2142 to i32
  store i32 %cv2143, ptr %slot298, align 8
  %v2144 = load i32, ptr %slot298, align 8
  %cv2145 = zext i32 %v2144 to i64
  %cond2146 = icmp ne i64 %cv2145, 0
  br i1 %cond2146, label %bb_rcmoveslow356, label %bb_rcmovenext359
bb_rcmovenext359:
  %v2147 = load i64, ptr %slot289, align 8
  %v2148 = load i64, ptr %slot290, align 8
  %p2149 = inttoptr i64 %v2147 to ptr
  %p2150 = inttoptr i64 %v2148 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2150, ptr %p2149, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2151 = load i64, ptr %slot289, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 0, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot289, align 8
  %op2154 = add i64 %v2153, 8
  store i64 %op2154, ptr %slot299, align 8
  %v2155 = load i64, ptr %slot299, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  store i64 0, ptr %p2156, align 8, !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot289, align 8
  %op2158 = add i64 %v2157, 16
  store i64 %op2158, ptr %slot300, align 8
  %v2159 = load i64, ptr %slot300, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  store i64 0, ptr %p2160, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved356
bb_rcmoveslow356:
  %v2161 = load i64, ptr %slot45, align 8
  %v2162 = load i64, ptr %slot290, align 8
  %v2163 = load i64, ptr %slot289, align 8
  %v2164 = load i64, ptr %slot291, align 8
  %cv2165 = trunc i64 %v2164 to i32
  %call2166 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v2161, i64 %v2162, i64 %v2163, i32 %cv2165) nomerge, !dbg !126
  store i32 %call2166, ptr %slot301, align 8
  %v2167 = load i32, ptr %slot301, align 8
  %cv2168 = zext i32 %v2167 to i64
  %cond2169 = icmp ne i64 %cv2168, 0
  br i1 %cond2169, label %bb_rcsuccess368, label %bb_rcfailure368
bb_rcfailure368:
  %v2170 = load i64, ptr %slot45, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  %call2172 = call i32 @myl_rc_take_failure(ptr %p2171) nomerge, !dbg !126
  store i32 %call2172, ptr %slot302, align 8
  %v2173 = load i64, ptr %slot1, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %v2175 = load i32, ptr %slot302, align 8
  %call2176 = call i32 @myl_qbe_rc_status(ptr %p2174, i32 %v2175) nomerge, !dbg !126
  store i32 %call2176, ptr %slot303, align 8
  br label %bb_failure
bb_rcsuccess368:
  br label %bb_rcmoved356
bb_rcmoved356:
  %v2177 = load i64, ptr %slot14, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  store i32 0, ptr %p2178, align 4, !alias.scope !3, !noalias !4
  %v2179 = load i64, ptr %slot19, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  store i32 2, ptr %p2180, align 4, !alias.scope !3, !noalias !4
  %v2181 = load i64, ptr %slot18, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i32 1, ptr %p2182, align 4, !alias.scope !3, !noalias !4
  %v2183 = load i64, ptr %slot8, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  %ld2185 = load i32, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2185, ptr %slot304, align 8
  %v2186 = load i32, ptr %slot304, align 8
  %cv2187 = zext i32 %v2186 to i64
  %cond2188 = icmp ne i64 %cv2187, 0
  br i1 %cond2188, label %bb_rcslotdrop377, label %bb_rcslotdone377
bb_rcslotdrop377:
  %v2189 = load i64, ptr %slot8, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i32 0, ptr %p2190, align 4, !alias.scope !3, !noalias !4
  %v2191 = load i64, ptr %slot33, align 8
  store i64 %v2191, ptr %slot305, align 8
  %v2192 = load i64, ptr %slot9, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i32, ptr %p2193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2194, ptr %slot306, align 8
  %v2195 = load i32, ptr %slot306, align 8
  %op2196 = and i32 %v2195, 28
  store i32 %op2196, ptr %slot307, align 8
  %v2197 = load i32, ptr %slot307, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rcslotrole377, label %bb_rcslotowner377
bb_rcslotrole377:
  %v2200 = load i64, ptr %slot45, align 8
  store i64 %v2200, ptr %slot308, align 8
  %v2201 = load i64, ptr %slot308, align 8
  %v2202 = load i64, ptr %slot305, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2201, i64 %v2202) nomerge, !dbg !126
  br label %bb_rcslotdone377
bb_rcslotowner377:
  %v2203 = load i64, ptr %slot305, align 8
  %p2205 = inttoptr i64 %v2203 to ptr
  %gep2206 = getelementptr i8, ptr %p2205, i64 8
  %op2204 = ptrtoint ptr %gep2206 to i64
  store i64 %op2204, ptr %slot309, align 8
  %v2207 = load i64, ptr %slot45, align 8
  store i64 %v2207, ptr %slot310, align 8
  %v2208 = load i64, ptr %slot309, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %ld2210 = load i64, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2210, ptr %slot311, align 8
  %v2211 = load i64, ptr %slot311, align 8
  %cmp2212 = icmp ne i64 %v2211, 0
  %cv2213 = zext i1 %cmp2212 to i32
  store i32 %cv2213, ptr %slot312, align 8
  %v2214 = load i32, ptr %slot312, align 8
  %cv2215 = zext i32 %v2214 to i64
  %cond2216 = icmp ne i64 %cv2215, 0
  br i1 %cond2216, label %bb_rcgnn395, label %bb_rcgdone395
bb_rcgnn395:
  %v2217 = load i64, ptr %slot311, align 8
  %op2218 = sub i64 %v2217, 16
  store i64 %op2218, ptr %slot313, align 8
  %v2219 = load i64, ptr %slot311, align 8
  %p2220 = inttoptr i64 %v2219 to ptr
  %rgep2221 = getelementptr i8, ptr %p2220, i64 -16
  %ld2222 = load i64, ptr %rgep2221, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2222, ptr %slot314, align 8
  %v2223 = load i64, ptr %slot314, align 8
  %op2224 = and i64 %v2223, 4611686018427387906
  store i64 %op2224, ptr %slot315, align 8
  %v2225 = load i64, ptr %slot315, align 8
  %cmp2226 = icmp ne i64 %v2225, 0
  %cv2227 = zext i1 %cmp2226 to i32
  store i32 %cv2227, ptr %slot316, align 8
  %v2228 = load i32, ptr %slot316, align 8
  %cv2229 = zext i32 %v2228 to i64
  %cond2230 = icmp ne i64 %cv2229, 0
  br i1 %cond2230, label %bb_rcgclear395, label %bb_rcgcounted395
bb_rcgcounted395:
  %v2231 = load i64, ptr %slot311, align 8
  %op2232 = sub i64 %v2231, 32
  store i64 %op2232, ptr %slot317, align 8
  %v2233 = load i64, ptr %slot311, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %rgep2235 = getelementptr i8, ptr %p2234, i64 -32
  %ld2236 = load i64, ptr %rgep2235, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2236, ptr %slot318, align 8
  %v2237 = load i64, ptr %slot318, align 8
  %op2238 = sub i64 %v2237, 1
  store i64 %op2238, ptr %slot319, align 8
  %v2239 = load i64, ptr %slot319, align 8
  %cmp2240 = icmp eq i64 %v2239, 0
  %cv2241 = zext i1 %cmp2240 to i32
  store i32 %cv2241, ptr %slot320, align 8
  %v2242 = load i32, ptr %slot320, align 8
  %cv2243 = zext i32 %v2242 to i64
  %cond2244 = icmp ne i64 %cv2243, 0
  br i1 %cond2244, label %bb_rcglast395, label %bb_rcgdec395
bb_rcglast395:
  %v2245 = load i64, ptr %slot311, align 8
  %op2246 = sub i64 %v2245, 24
  store i64 %op2246, ptr %slot321, align 8
  %v2247 = load i64, ptr %slot311, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %rgep2249 = getelementptr i8, ptr %p2248, i64 -24
  %ld2250 = load i64, ptr %rgep2249, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2250, ptr %slot322, align 8
  %v2251 = load i64, ptr %slot322, align 8
  %cmp2252 = icmp ne i64 %v2251, 0
  %cv2253 = zext i1 %cmp2252 to i32
  store i32 %cv2253, ptr %slot323, align 8
  %v2254 = load i32, ptr %slot323, align 8
  %cv2255 = zext i32 %v2254 to i64
  %cond2256 = icmp ne i64 %cv2255, 0
  br i1 %cond2256, label %bb_rcgdec395, label %bb_rcgslow395
bb_rcgslow395:
  %v2257 = load i64, ptr %slot310, align 8
  %v2258 = load i64, ptr %slot309, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2257, i64 %v2258) nomerge, !dbg !126
  br label %bb_rcgdone395
bb_rcgdec395:
  %v2259 = load i64, ptr %slot319, align 8
  %v2260 = load i64, ptr %slot311, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  %rgep2262 = getelementptr i8, ptr %p2261, i64 -32
  store i64 %v2259, ptr %rgep2262, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear395
bb_rcgclear395:
  %v2263 = load i64, ptr %slot309, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 0, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone395
bb_rcgdone395:
  %v2265 = load i64, ptr %slot305, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i64 0, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot305, align 8
  %p2269 = inttoptr i64 %v2267 to ptr
  %gep2270 = getelementptr i8, ptr %p2269, i64 8
  %op2268 = ptrtoint ptr %gep2270 to i64
  store i64 %op2268, ptr %slot324, align 8
  %v2271 = load i64, ptr %slot324, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i64 0, ptr %p2272, align 8, !alias.scope !3, !noalias !4
  %v2273 = load i64, ptr %slot305, align 8
  %p2275 = inttoptr i64 %v2273 to ptr
  %gep2276 = getelementptr i8, ptr %p2275, i64 16
  %op2274 = ptrtoint ptr %gep2276 to i64
  store i64 %op2274, ptr %slot325, align 8
  %v2277 = load i64, ptr %slot325, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i64 0, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone377
bb_rcslotdone377:
  %v2279 = load i64, ptr %slot33, align 8
  store i64 %v2279, ptr %slot326, align 8
  %v2280 = load i64, ptr %slot23, align 8
  store i64 %v2280, ptr %slot327, align 8
  %v2281 = load i64, ptr %slot327, align 8
  %v2282 = load i64, ptr %slot326, align 8
  %p2283 = inttoptr i64 %v2281 to ptr
  %p2284 = inttoptr i64 %v2282 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2284, ptr %p2283, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot18, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  store i32 0, ptr %p2286, align 4, !alias.scope !3, !noalias !4
  %v2287 = load i64, ptr %slot9, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i32 2, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot19, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ld2291 = load i32, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2291, ptr %slot328, align 8
  %v2292 = load i32, ptr %slot328, align 8
  %v2293 = load i64, ptr %slot9, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  store i32 %v2292, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  %v2295 = load i64, ptr %slot8, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  store i32 1, ptr %p2296, align 4, !alias.scope !3, !noalias !4
  %v2297 = load i64, ptr %slot29, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %ld2299 = load i64, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2299, ptr %slot329, align 8
  %v2300 = load i64, ptr %slot329, align 8
  %v2301 = load i64, ptr %slot39, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  store i64 %v2300, ptr %p2302, align 8, !alias.scope !3, !noalias !4
  %v2303 = load i64, ptr %slot39, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  %ld2305 = load i64, ptr %p2304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2305, ptr %slot330, align 8
  %v2306 = load i64, ptr %slot330, align 8
  %v2307 = load i64, ptr %slot35, align 8
  %p2308 = inttoptr i64 %v2306 to ptr
  %p2309 = inttoptr i64 %v2307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2309, ptr %p2308, i64 16, i1 false), !alias.scope !10000000
  %v2310 = load i64, ptr %slot33, align 8
  %v2311 = load i64, ptr %slot39, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  store i64 %v2310, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  %v2313 = load i64, ptr %slot39, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  %ld2315 = load i64, ptr %p2314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2315, ptr %slot331, align 8
  %v2316 = load i64, ptr %slot14, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i32, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2318, ptr %slot332, align 8
  %v2319 = load i64, ptr %slot15, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  %ld2321 = load i32, ptr %p2320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2321, ptr %slot333, align 8
  %v2322 = load i32, ptr %slot333, align 8
  %op2323 = and i32 %v2322, 24
  store i32 %op2323, ptr %slot333, align 8
  %v2324 = load i32, ptr %slot333, align 8
  %cmp2325 = icmp eq i32 %v2324, 0
  %cv2326 = zext i1 %cmp2325 to i32
  store i32 %cv2326, ptr %slot334, align 8
  %v2327 = load i32, ptr %slot332, align 8
  %v2328 = load i32, ptr %slot334, align 8
  %op2329 = and i32 %v2327, %v2328
  store i32 %op2329, ptr %slot335, align 8
  %v2330 = load i32, ptr %slot335, align 8
  %cv2331 = zext i32 %v2330 to i64
  %cond2332 = icmp ne i64 %cv2331, 0
  br i1 %cond2332, label %bb_rcprivateown417, label %bb_rcprivateloan417
bb_rcprivateown417:
  %v2333 = load i64, ptr %slot23, align 8
  store i64 %v2333, ptr %slot336, align 8
  %v2334 = load i64, ptr %slot46, align 8
  store i64 %v2334, ptr %slot337, align 8
  %v2335 = load i64, ptr %slot331, align 8
  %v2336 = load i64, ptr %slot336, align 8
  %op2337 = sub i64 %v2335, %v2336
  store i64 %op2337, ptr %slot338, align 8
  %v2338 = load i64, ptr %slot336, align 8
  %v2339 = load i64, ptr %slot331, align 8
  %op2340 = sub i64 %v2338, %v2339
  store i64 %op2340, ptr %slot339, align 8
  %v2341 = load i64, ptr %slot338, align 8
  %cmp2342 = icmp ult i64 %v2341, 24
  %cv2343 = zext i1 %cmp2342 to i32
  store i32 %cv2343, ptr %slot340, align 8
  %v2344 = load i64, ptr %slot339, align 8
  %cmp2345 = icmp ult i64 %v2344, 24
  %cv2346 = zext i1 %cmp2345 to i32
  store i32 %cv2346, ptr %slot341, align 8
  %v2347 = load i32, ptr %slot340, align 8
  %v2348 = load i32, ptr %slot341, align 8
  %op2349 = or i32 %v2347, %v2348
  store i32 %op2349, ptr %slot342, align 8
  %v2350 = load i32, ptr %slot342, align 8
  %cv2351 = zext i32 %v2350 to i64
  %cond2352 = icmp ne i64 %cv2351, 0
  br i1 %cond2352, label %bb_rcmoveslow420, label %bb_rcmovecheck420
bb_rcmovecheck420:
  %v2353 = load i64, ptr %slot331, align 8
  %op2354 = add i64 %v2353, 8
  store i64 %op2354, ptr %slot343, align 8
  %v2355 = load i64, ptr %slot343, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  %ld2357 = load i64, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2357, ptr %slot344, align 8
  %v2358 = load i64, ptr %slot344, align 8
  %cmp2359 = icmp ne i64 %v2358, 0
  %cv2360 = zext i1 %cmp2359 to i32
  store i32 %cv2360, ptr %slot345, align 8
  %v2361 = load i32, ptr %slot345, align 8
  %cv2362 = zext i32 %v2361 to i64
  %cond2363 = icmp ne i64 %cv2362, 0
  br i1 %cond2363, label %bb_rcmoveheader428, label %bb_rcmovenext428
bb_rcmoveheader428:
  %v2364 = load i64, ptr %slot344, align 8
  %op2365 = sub i64 %v2364, 16
  store i64 %op2365, ptr %slot346, align 8
  %v2366 = load i64, ptr %slot344, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %rgep2368 = getelementptr i8, ptr %p2367, i64 -16
  %ld2369 = load i64, ptr %rgep2368, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2369, ptr %slot347, align 8
  %v2370 = load i64, ptr %slot347, align 8
  %op2371 = and i64 %v2370, 5764607523034234881
  store i64 %op2371, ptr %slot348, align 8
  %v2372 = load i64, ptr %slot348, align 8
  %cmp2373 = icmp ne i64 %v2372, 0
  %cv2374 = zext i1 %cmp2373 to i32
  store i32 %cv2374, ptr %slot349, align 8
  %v2375 = load i32, ptr %slot349, align 8
  %cv2376 = zext i32 %v2375 to i64
  %cond2377 = icmp ne i64 %cv2376, 0
  br i1 %cond2377, label %bb_rcmoveslow420, label %bb_rcmovenext428
bb_rcmovenext428:
  %v2378 = load i64, ptr %slot331, align 8
  %v2379 = load i64, ptr %slot336, align 8
  %p2380 = inttoptr i64 %v2378 to ptr
  %p2381 = inttoptr i64 %v2379 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2381, ptr %p2380, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot331, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i64 0, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot331, align 8
  %op2385 = add i64 %v2384, 8
  store i64 %op2385, ptr %slot350, align 8
  %v2386 = load i64, ptr %slot350, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i64 0, ptr %p2387, align 8, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot331, align 8
  %op2389 = add i64 %v2388, 16
  store i64 %op2389, ptr %slot351, align 8
  %v2390 = load i64, ptr %slot351, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  store i64 0, ptr %p2391, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved420
bb_rcmoveslow420:
  %v2392 = load i64, ptr %slot45, align 8
  %v2393 = load i64, ptr %slot336, align 8
  %v2394 = load i64, ptr %slot331, align 8
  %v2395 = load i64, ptr %slot337, align 8
  %cv2396 = trunc i64 %v2395 to i32
  %call2397 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v2392, i64 %v2393, i64 %v2394, i32 %cv2396) nomerge, !dbg !128
  store i32 %call2397, ptr %slot352, align 8
  %v2398 = load i32, ptr %slot352, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcsuccess437, label %bb_rcfailure437
bb_rcfailure437:
  %v2401 = load i64, ptr %slot45, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  %call2403 = call i32 @myl_rc_take_failure(ptr %p2402) nomerge, !dbg !128
  store i32 %call2403, ptr %slot353, align 8
  %v2404 = load i64, ptr %slot1, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %v2406 = load i32, ptr %slot353, align 8
  %call2407 = call i32 @myl_qbe_rc_status(ptr %p2405, i32 %v2406) nomerge, !dbg !128
  store i32 %call2407, ptr %slot354, align 8
  br label %bb_failure
bb_rcsuccess437:
  br label %bb_rcmoved420
bb_rcmoved420:
  %v2408 = load i64, ptr %slot14, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i32 0, ptr %p2409, align 4, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot19, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  store i32 2, ptr %p2411, align 4, !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot18, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i32 1, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared417
bb_rcprivateloan417:
  %v2414 = load i64, ptr %slot23, align 8
  store i64 %v2414, ptr %slot355, align 8
  %v2415 = load i64, ptr %slot45, align 8
  %v2416 = load i64, ptr %slot355, align 8
  %v2417 = load i64, ptr %slot331, align 8
  %call2418 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64 %v2415, i64 %v2416, i64 %v2417) nomerge, !dbg !128
  store i32 %call2418, ptr %slot356, align 8
  %v2419 = load i32, ptr %slot356, align 8
  %cv2420 = zext i32 %v2419 to i64
  %cond2421 = icmp ne i64 %cv2420, 0
  br i1 %cond2421, label %bb_rcsuccess445, label %bb_rcfailure445
bb_rcfailure445:
  %v2422 = load i64, ptr %slot45, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %call2424 = call i32 @myl_rc_take_failure(ptr %p2423) nomerge, !dbg !128
  store i32 %call2424, ptr %slot357, align 8
  %v2425 = load i64, ptr %slot1, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %v2427 = load i32, ptr %slot357, align 8
  %call2428 = call i32 @myl_qbe_rc_status(ptr %p2426, i32 %v2427) nomerge, !dbg !128
  store i32 %call2428, ptr %slot358, align 8
  br label %bb_failure
bb_rcsuccess445:
  %v2429 = load i64, ptr %slot19, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  store i32 2, ptr %p2430, align 4, !alias.scope !3, !noalias !4
  %v2431 = load i64, ptr %slot19, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  store i32 16, ptr %p2432, align 4, !alias.scope !3, !noalias !4
  %v2433 = load i64, ptr %slot18, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i32 1, ptr %p2434, align 4, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot14, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %ld2437 = load i32, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2437, ptr %slot359, align 8
  %v2438 = load i32, ptr %slot359, align 8
  %cv2439 = zext i32 %v2438 to i64
  %cond2440 = icmp ne i64 %cv2439, 0
  br i1 %cond2440, label %bb_rcslotdrop453, label %bb_rcslotdone453
bb_rcslotdrop453:
  %v2441 = load i64, ptr %slot14, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 0, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot21, align 8
  store i64 %v2443, ptr %slot360, align 8
  %v2444 = load i64, ptr %slot15, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %ld2446 = load i32, ptr %p2445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2446, ptr %slot361, align 8
  %v2447 = load i32, ptr %slot361, align 8
  %op2448 = and i32 %v2447, 28
  store i32 %op2448, ptr %slot362, align 8
  %v2449 = load i32, ptr %slot362, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcslotrole453, label %bb_rcslotowner453
bb_rcslotrole453:
  %v2452 = load i64, ptr %slot45, align 8
  store i64 %v2452, ptr %slot363, align 8
  %v2453 = load i64, ptr %slot363, align 8
  %v2454 = load i64, ptr %slot360, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2453, i64 %v2454) nomerge, !dbg !128
  br label %bb_rcslotdone453
bb_rcslotowner453:
  %v2455 = load i64, ptr %slot360, align 8
  %p2457 = inttoptr i64 %v2455 to ptr
  %gep2458 = getelementptr i8, ptr %p2457, i64 8
  %op2456 = ptrtoint ptr %gep2458 to i64
  store i64 %op2456, ptr %slot364, align 8
  %v2459 = load i64, ptr %slot45, align 8
  store i64 %v2459, ptr %slot365, align 8
  %v2460 = load i64, ptr %slot364, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %ld2462 = load i64, ptr %p2461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2462, ptr %slot366, align 8
  %v2463 = load i64, ptr %slot366, align 8
  %cmp2464 = icmp ne i64 %v2463, 0
  %cv2465 = zext i1 %cmp2464 to i32
  store i32 %cv2465, ptr %slot367, align 8
  %v2466 = load i32, ptr %slot367, align 8
  %cv2467 = zext i32 %v2466 to i64
  %cond2468 = icmp ne i64 %cv2467, 0
  br i1 %cond2468, label %bb_rcgnn471, label %bb_rcgdone471
bb_rcgnn471:
  %v2469 = load i64, ptr %slot366, align 8
  %op2470 = sub i64 %v2469, 16
  store i64 %op2470, ptr %slot368, align 8
  %v2471 = load i64, ptr %slot366, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %rgep2473 = getelementptr i8, ptr %p2472, i64 -16
  %ld2474 = load i64, ptr %rgep2473, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2474, ptr %slot369, align 8
  %v2475 = load i64, ptr %slot369, align 8
  %op2476 = and i64 %v2475, 4611686018427387906
  store i64 %op2476, ptr %slot370, align 8
  %v2477 = load i64, ptr %slot370, align 8
  %cmp2478 = icmp ne i64 %v2477, 0
  %cv2479 = zext i1 %cmp2478 to i32
  store i32 %cv2479, ptr %slot371, align 8
  %v2480 = load i32, ptr %slot371, align 8
  %cv2481 = zext i32 %v2480 to i64
  %cond2482 = icmp ne i64 %cv2481, 0
  br i1 %cond2482, label %bb_rcgclear471, label %bb_rcgcounted471
bb_rcgcounted471:
  %v2483 = load i64, ptr %slot366, align 8
  %op2484 = sub i64 %v2483, 32
  store i64 %op2484, ptr %slot372, align 8
  %v2485 = load i64, ptr %slot366, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  %rgep2487 = getelementptr i8, ptr %p2486, i64 -32
  %ld2488 = load i64, ptr %rgep2487, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2488, ptr %slot373, align 8
  %v2489 = load i64, ptr %slot373, align 8
  %op2490 = sub i64 %v2489, 1
  store i64 %op2490, ptr %slot374, align 8
  %v2491 = load i64, ptr %slot374, align 8
  %cmp2492 = icmp eq i64 %v2491, 0
  %cv2493 = zext i1 %cmp2492 to i32
  store i32 %cv2493, ptr %slot375, align 8
  %v2494 = load i32, ptr %slot375, align 8
  %cv2495 = zext i32 %v2494 to i64
  %cond2496 = icmp ne i64 %cv2495, 0
  br i1 %cond2496, label %bb_rcglast471, label %bb_rcgdec471
bb_rcglast471:
  %v2497 = load i64, ptr %slot366, align 8
  %op2498 = sub i64 %v2497, 24
  store i64 %op2498, ptr %slot376, align 8
  %v2499 = load i64, ptr %slot366, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %rgep2501 = getelementptr i8, ptr %p2500, i64 -24
  %ld2502 = load i64, ptr %rgep2501, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2502, ptr %slot377, align 8
  %v2503 = load i64, ptr %slot377, align 8
  %cmp2504 = icmp ne i64 %v2503, 0
  %cv2505 = zext i1 %cmp2504 to i32
  store i32 %cv2505, ptr %slot378, align 8
  %v2506 = load i32, ptr %slot378, align 8
  %cv2507 = zext i32 %v2506 to i64
  %cond2508 = icmp ne i64 %cv2507, 0
  br i1 %cond2508, label %bb_rcgdec471, label %bb_rcgslow471
bb_rcgslow471:
  %v2509 = load i64, ptr %slot365, align 8
  %v2510 = load i64, ptr %slot364, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2509, i64 %v2510) nomerge, !dbg !128
  br label %bb_rcgdone471
bb_rcgdec471:
  %v2511 = load i64, ptr %slot374, align 8
  %v2512 = load i64, ptr %slot366, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  %rgep2514 = getelementptr i8, ptr %p2513, i64 -32
  store i64 %v2511, ptr %rgep2514, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear471
bb_rcgclear471:
  %v2515 = load i64, ptr %slot364, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  store i64 0, ptr %p2516, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone471
bb_rcgdone471:
  %v2517 = load i64, ptr %slot360, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i64 0, ptr %p2518, align 8, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot360, align 8
  %p2521 = inttoptr i64 %v2519 to ptr
  %gep2522 = getelementptr i8, ptr %p2521, i64 8
  %op2520 = ptrtoint ptr %gep2522 to i64
  store i64 %op2520, ptr %slot379, align 8
  %v2523 = load i64, ptr %slot379, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  store i64 0, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  %v2525 = load i64, ptr %slot360, align 8
  %p2527 = inttoptr i64 %v2525 to ptr
  %gep2528 = getelementptr i8, ptr %p2527, i64 16
  %op2526 = ptrtoint ptr %gep2528 to i64
  store i64 %op2526, ptr %slot380, align 8
  %v2529 = load i64, ptr %slot380, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  store i64 0, ptr %p2530, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone453
bb_rcslotdone453:
  br label %bb_rcprivateprepared417
bb_rcprivateprepared417:
  %v2531 = load i64, ptr %slot10, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %ld2533 = load i32, ptr %p2532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2533, ptr %slot381, align 8
  %v2534 = load i32, ptr %slot381, align 8
  %cv2535 = zext i32 %v2534 to i64
  %cond2536 = icmp ne i64 %cv2535, 0
  br i1 %cond2536, label %bb_rcslotdrop480, label %bb_rcslotdone480
bb_rcslotdrop480:
  %v2537 = load i64, ptr %slot10, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 0, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot34, align 8
  store i64 %v2539, ptr %slot382, align 8
  %v2540 = load i64, ptr %slot11, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %ld2542 = load i32, ptr %p2541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2542, ptr %slot383, align 8
  %v2543 = load i32, ptr %slot383, align 8
  %op2544 = and i32 %v2543, 28
  store i32 %op2544, ptr %slot384, align 8
  %v2545 = load i32, ptr %slot384, align 8
  %cv2546 = zext i32 %v2545 to i64
  %cond2547 = icmp ne i64 %cv2546, 0
  br i1 %cond2547, label %bb_rcslotrole480, label %bb_rcslotowner480
bb_rcslotrole480:
  %v2548 = load i64, ptr %slot45, align 8
  store i64 %v2548, ptr %slot385, align 8
  %v2549 = load i64, ptr %slot385, align 8
  %v2550 = load i64, ptr %slot382, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2549, i64 %v2550) nomerge, !dbg !128
  br label %bb_rcslotdone480
bb_rcslotowner480:
  %v2551 = load i64, ptr %slot382, align 8
  %p2553 = inttoptr i64 %v2551 to ptr
  %gep2554 = getelementptr i8, ptr %p2553, i64 8
  %op2552 = ptrtoint ptr %gep2554 to i64
  store i64 %op2552, ptr %slot386, align 8
  %v2555 = load i64, ptr %slot45, align 8
  store i64 %v2555, ptr %slot387, align 8
  %v2556 = load i64, ptr %slot386, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i64, ptr %p2557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2558, ptr %slot388, align 8
  %v2559 = load i64, ptr %slot388, align 8
  %cmp2560 = icmp ne i64 %v2559, 0
  %cv2561 = zext i1 %cmp2560 to i32
  store i32 %cv2561, ptr %slot389, align 8
  %v2562 = load i32, ptr %slot389, align 8
  %cv2563 = zext i32 %v2562 to i64
  %cond2564 = icmp ne i64 %cv2563, 0
  br i1 %cond2564, label %bb_rcgnn498, label %bb_rcgdone498
bb_rcgnn498:
  %v2565 = load i64, ptr %slot388, align 8
  %op2566 = sub i64 %v2565, 16
  store i64 %op2566, ptr %slot390, align 8
  %v2567 = load i64, ptr %slot388, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  %rgep2569 = getelementptr i8, ptr %p2568, i64 -16
  %ld2570 = load i64, ptr %rgep2569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2570, ptr %slot391, align 8
  %v2571 = load i64, ptr %slot391, align 8
  %op2572 = and i64 %v2571, 4611686018427387906
  store i64 %op2572, ptr %slot392, align 8
  %v2573 = load i64, ptr %slot392, align 8
  %cmp2574 = icmp ne i64 %v2573, 0
  %cv2575 = zext i1 %cmp2574 to i32
  store i32 %cv2575, ptr %slot393, align 8
  %v2576 = load i32, ptr %slot393, align 8
  %cv2577 = zext i32 %v2576 to i64
  %cond2578 = icmp ne i64 %cv2577, 0
  br i1 %cond2578, label %bb_rcgclear498, label %bb_rcgcounted498
bb_rcgcounted498:
  %v2579 = load i64, ptr %slot388, align 8
  %op2580 = sub i64 %v2579, 32
  store i64 %op2580, ptr %slot394, align 8
  %v2581 = load i64, ptr %slot388, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %rgep2583 = getelementptr i8, ptr %p2582, i64 -32
  %ld2584 = load i64, ptr %rgep2583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2584, ptr %slot395, align 8
  %v2585 = load i64, ptr %slot395, align 8
  %op2586 = sub i64 %v2585, 1
  store i64 %op2586, ptr %slot396, align 8
  %v2587 = load i64, ptr %slot396, align 8
  %cmp2588 = icmp eq i64 %v2587, 0
  %cv2589 = zext i1 %cmp2588 to i32
  store i32 %cv2589, ptr %slot397, align 8
  %v2590 = load i32, ptr %slot397, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcglast498, label %bb_rcgdec498
bb_rcglast498:
  %v2593 = load i64, ptr %slot388, align 8
  %op2594 = sub i64 %v2593, 24
  store i64 %op2594, ptr %slot398, align 8
  %v2595 = load i64, ptr %slot388, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %rgep2597 = getelementptr i8, ptr %p2596, i64 -24
  %ld2598 = load i64, ptr %rgep2597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2598, ptr %slot399, align 8
  %v2599 = load i64, ptr %slot399, align 8
  %cmp2600 = icmp ne i64 %v2599, 0
  %cv2601 = zext i1 %cmp2600 to i32
  store i32 %cv2601, ptr %slot400, align 8
  %v2602 = load i32, ptr %slot400, align 8
  %cv2603 = zext i32 %v2602 to i64
  %cond2604 = icmp ne i64 %cv2603, 0
  br i1 %cond2604, label %bb_rcgdec498, label %bb_rcgslow498
bb_rcgslow498:
  %v2605 = load i64, ptr %slot387, align 8
  %v2606 = load i64, ptr %slot386, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2605, i64 %v2606) nomerge, !dbg !128
  br label %bb_rcgdone498
bb_rcgdec498:
  %v2607 = load i64, ptr %slot396, align 8
  %v2608 = load i64, ptr %slot388, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %rgep2610 = getelementptr i8, ptr %p2609, i64 -32
  store i64 %v2607, ptr %rgep2610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear498
bb_rcgclear498:
  %v2611 = load i64, ptr %slot386, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  store i64 0, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone498
bb_rcgdone498:
  %v2613 = load i64, ptr %slot382, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i64 0, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot382, align 8
  %p2617 = inttoptr i64 %v2615 to ptr
  %gep2618 = getelementptr i8, ptr %p2617, i64 8
  %op2616 = ptrtoint ptr %gep2618 to i64
  store i64 %op2616, ptr %slot401, align 8
  %v2619 = load i64, ptr %slot401, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i64 0, ptr %p2620, align 8, !alias.scope !3, !noalias !4
  %v2621 = load i64, ptr %slot382, align 8
  %p2623 = inttoptr i64 %v2621 to ptr
  %gep2624 = getelementptr i8, ptr %p2623, i64 16
  %op2622 = ptrtoint ptr %gep2624 to i64
  store i64 %op2622, ptr %slot402, align 8
  %v2625 = load i64, ptr %slot402, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 0, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone480
bb_rcslotdone480:
  %v2627 = load i64, ptr %slot34, align 8
  store i64 %v2627, ptr %slot403, align 8
  %v2628 = load i64, ptr %slot23, align 8
  store i64 %v2628, ptr %slot404, align 8
  %v2629 = load i64, ptr %slot404, align 8
  %v2630 = load i64, ptr %slot403, align 8
  %p2631 = inttoptr i64 %v2629 to ptr
  %p2632 = inttoptr i64 %v2630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2632, ptr %p2631, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2633 = load i64, ptr %slot18, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i32 0, ptr %p2634, align 4, !alias.scope !3, !noalias !4
  %v2635 = load i64, ptr %slot11, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i32 2, ptr %p2636, align 4, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot19, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i32, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2639, ptr %slot405, align 8
  %v2640 = load i32, ptr %slot405, align 8
  %v2641 = load i64, ptr %slot11, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  store i32 %v2640, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot10, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i32 1, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot33, align 8
  %v2646 = load i64, ptr %slot39, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i64 %v2645, ptr %p2647, align 8, !alias.scope !3, !noalias !4
  %v2648 = load i64, ptr %slot39, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %ld2650 = load i64, ptr %p2649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2650, ptr %slot406, align 8
  %v2651 = load i64, ptr %slot14, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  %ld2653 = load i32, ptr %p2652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2653, ptr %slot407, align 8
  %v2654 = load i64, ptr %slot15, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %ld2656 = load i32, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2656, ptr %slot408, align 8
  %v2657 = load i32, ptr %slot408, align 8
  %op2658 = and i32 %v2657, 24
  store i32 %op2658, ptr %slot408, align 8
  %v2659 = load i32, ptr %slot408, align 8
  %cmp2660 = icmp eq i32 %v2659, 0
  %cv2661 = zext i1 %cmp2660 to i32
  store i32 %cv2661, ptr %slot409, align 8
  %v2662 = load i32, ptr %slot407, align 8
  %v2663 = load i32, ptr %slot409, align 8
  %op2664 = and i32 %v2662, %v2663
  store i32 %op2664, ptr %slot410, align 8
  %v2665 = load i32, ptr %slot410, align 8
  %cv2666 = zext i32 %v2665 to i64
  %cond2667 = icmp ne i64 %cv2666, 0
  br i1 %cond2667, label %bb_rcprivateown518, label %bb_rcprivateloan518
bb_rcprivateown518:
  %v2668 = load i64, ptr %slot23, align 8
  store i64 %v2668, ptr %slot411, align 8
  %v2669 = load i64, ptr %slot46, align 8
  store i64 %v2669, ptr %slot412, align 8
  %v2670 = load i64, ptr %slot406, align 8
  %v2671 = load i64, ptr %slot411, align 8
  %op2672 = sub i64 %v2670, %v2671
  store i64 %op2672, ptr %slot413, align 8
  %v2673 = load i64, ptr %slot411, align 8
  %v2674 = load i64, ptr %slot406, align 8
  %op2675 = sub i64 %v2673, %v2674
  store i64 %op2675, ptr %slot414, align 8
  %v2676 = load i64, ptr %slot413, align 8
  %cmp2677 = icmp ult i64 %v2676, 24
  %cv2678 = zext i1 %cmp2677 to i32
  store i32 %cv2678, ptr %slot415, align 8
  %v2679 = load i64, ptr %slot414, align 8
  %cmp2680 = icmp ult i64 %v2679, 24
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot416, align 8
  %v2682 = load i32, ptr %slot415, align 8
  %v2683 = load i32, ptr %slot416, align 8
  %op2684 = or i32 %v2682, %v2683
  store i32 %op2684, ptr %slot417, align 8
  %v2685 = load i32, ptr %slot417, align 8
  %cv2686 = zext i32 %v2685 to i64
  %cond2687 = icmp ne i64 %cv2686, 0
  br i1 %cond2687, label %bb_rcmoveslow521, label %bb_rcmovecheck521
bb_rcmovecheck521:
  %v2688 = load i64, ptr %slot406, align 8
  %op2689 = add i64 %v2688, 8
  store i64 %op2689, ptr %slot418, align 8
  %v2690 = load i64, ptr %slot418, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i64, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2692, ptr %slot419, align 8
  %v2693 = load i64, ptr %slot419, align 8
  %cmp2694 = icmp ne i64 %v2693, 0
  %cv2695 = zext i1 %cmp2694 to i32
  store i32 %cv2695, ptr %slot420, align 8
  %v2696 = load i32, ptr %slot420, align 8
  %cv2697 = zext i32 %v2696 to i64
  %cond2698 = icmp ne i64 %cv2697, 0
  br i1 %cond2698, label %bb_rcmoveheader529, label %bb_rcmovenext529
bb_rcmoveheader529:
  %v2699 = load i64, ptr %slot419, align 8
  %op2700 = sub i64 %v2699, 16
  store i64 %op2700, ptr %slot421, align 8
  %v2701 = load i64, ptr %slot419, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  %rgep2703 = getelementptr i8, ptr %p2702, i64 -16
  %ld2704 = load i64, ptr %rgep2703, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2704, ptr %slot422, align 8
  %v2705 = load i64, ptr %slot422, align 8
  %op2706 = and i64 %v2705, 5764607523034234881
  store i64 %op2706, ptr %slot423, align 8
  %v2707 = load i64, ptr %slot423, align 8
  %cmp2708 = icmp ne i64 %v2707, 0
  %cv2709 = zext i1 %cmp2708 to i32
  store i32 %cv2709, ptr %slot424, align 8
  %v2710 = load i32, ptr %slot424, align 8
  %cv2711 = zext i32 %v2710 to i64
  %cond2712 = icmp ne i64 %cv2711, 0
  br i1 %cond2712, label %bb_rcmoveslow521, label %bb_rcmovenext529
bb_rcmovenext529:
  %v2713 = load i64, ptr %slot406, align 8
  %v2714 = load i64, ptr %slot411, align 8
  %p2715 = inttoptr i64 %v2713 to ptr
  %p2716 = inttoptr i64 %v2714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2716, ptr %p2715, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot406, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  store i64 0, ptr %p2718, align 8, !alias.scope !3, !noalias !4
  %v2719 = load i64, ptr %slot406, align 8
  %op2720 = add i64 %v2719, 8
  store i64 %op2720, ptr %slot425, align 8
  %v2721 = load i64, ptr %slot425, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i64 0, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  %v2723 = load i64, ptr %slot406, align 8
  %op2724 = add i64 %v2723, 16
  store i64 %op2724, ptr %slot426, align 8
  %v2725 = load i64, ptr %slot426, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  store i64 0, ptr %p2726, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved521
bb_rcmoveslow521:
  %v2727 = load i64, ptr %slot45, align 8
  %v2728 = load i64, ptr %slot411, align 8
  %v2729 = load i64, ptr %slot406, align 8
  %v2730 = load i64, ptr %slot412, align 8
  %cv2731 = trunc i64 %v2730 to i32
  %call2732 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v2727, i64 %v2728, i64 %v2729, i32 %cv2731) nomerge, !dbg !130
  store i32 %call2732, ptr %slot427, align 8
  %v2733 = load i32, ptr %slot427, align 8
  %cv2734 = zext i32 %v2733 to i64
  %cond2735 = icmp ne i64 %cv2734, 0
  br i1 %cond2735, label %bb_rcsuccess538, label %bb_rcfailure538
bb_rcfailure538:
  %v2736 = load i64, ptr %slot45, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  %call2738 = call i32 @myl_rc_take_failure(ptr %p2737) nomerge, !dbg !130
  store i32 %call2738, ptr %slot428, align 8
  %v2739 = load i64, ptr %slot1, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  %v2741 = load i32, ptr %slot428, align 8
  %call2742 = call i32 @myl_qbe_rc_status(ptr %p2740, i32 %v2741) nomerge, !dbg !130
  store i32 %call2742, ptr %slot429, align 8
  br label %bb_failure
bb_rcsuccess538:
  br label %bb_rcmoved521
bb_rcmoved521:
  %v2743 = load i64, ptr %slot14, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  store i32 0, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  %v2745 = load i64, ptr %slot19, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  store i32 2, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  %v2747 = load i64, ptr %slot18, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i32 1, ptr %p2748, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared518
bb_rcprivateloan518:
  %v2749 = load i64, ptr %slot23, align 8
  store i64 %v2749, ptr %slot430, align 8
  %v2750 = load i64, ptr %slot45, align 8
  %v2751 = load i64, ptr %slot430, align 8
  %v2752 = load i64, ptr %slot406, align 8
  %call2753 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64 %v2750, i64 %v2751, i64 %v2752) nomerge, !dbg !130
  store i32 %call2753, ptr %slot431, align 8
  %v2754 = load i32, ptr %slot431, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcsuccess546, label %bb_rcfailure546
bb_rcfailure546:
  %v2757 = load i64, ptr %slot45, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %call2759 = call i32 @myl_rc_take_failure(ptr %p2758) nomerge, !dbg !130
  store i32 %call2759, ptr %slot432, align 8
  %v2760 = load i64, ptr %slot1, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %v2762 = load i32, ptr %slot432, align 8
  %call2763 = call i32 @myl_qbe_rc_status(ptr %p2761, i32 %v2762) nomerge, !dbg !130
  store i32 %call2763, ptr %slot433, align 8
  br label %bb_failure
bb_rcsuccess546:
  %v2764 = load i64, ptr %slot19, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  store i32 2, ptr %p2765, align 4, !alias.scope !3, !noalias !4
  %v2766 = load i64, ptr %slot19, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  store i32 16, ptr %p2767, align 4, !alias.scope !3, !noalias !4
  %v2768 = load i64, ptr %slot18, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  store i32 1, ptr %p2769, align 4, !alias.scope !3, !noalias !4
  %v2770 = load i64, ptr %slot14, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  %ld2772 = load i32, ptr %p2771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2772, ptr %slot434, align 8
  %v2773 = load i32, ptr %slot434, align 8
  %cv2774 = zext i32 %v2773 to i64
  %cond2775 = icmp ne i64 %cv2774, 0
  br i1 %cond2775, label %bb_rcslotdrop554, label %bb_rcslotdone554
bb_rcslotdrop554:
  %v2776 = load i64, ptr %slot14, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  store i32 0, ptr %p2777, align 4, !alias.scope !3, !noalias !4
  %v2778 = load i64, ptr %slot21, align 8
  store i64 %v2778, ptr %slot435, align 8
  %v2779 = load i64, ptr %slot15, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %ld2781 = load i32, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2781, ptr %slot436, align 8
  %v2782 = load i32, ptr %slot436, align 8
  %op2783 = and i32 %v2782, 28
  store i32 %op2783, ptr %slot437, align 8
  %v2784 = load i32, ptr %slot437, align 8
  %cv2785 = zext i32 %v2784 to i64
  %cond2786 = icmp ne i64 %cv2785, 0
  br i1 %cond2786, label %bb_rcslotrole554, label %bb_rcslotowner554
bb_rcslotrole554:
  %v2787 = load i64, ptr %slot45, align 8
  store i64 %v2787, ptr %slot438, align 8
  %v2788 = load i64, ptr %slot438, align 8
  %v2789 = load i64, ptr %slot435, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2788, i64 %v2789) nomerge, !dbg !130
  br label %bb_rcslotdone554
bb_rcslotowner554:
  %v2790 = load i64, ptr %slot435, align 8
  %p2792 = inttoptr i64 %v2790 to ptr
  %gep2793 = getelementptr i8, ptr %p2792, i64 8
  %op2791 = ptrtoint ptr %gep2793 to i64
  store i64 %op2791, ptr %slot439, align 8
  %v2794 = load i64, ptr %slot45, align 8
  store i64 %v2794, ptr %slot440, align 8
  %v2795 = load i64, ptr %slot439, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %ld2797 = load i64, ptr %p2796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2797, ptr %slot441, align 8
  %v2798 = load i64, ptr %slot441, align 8
  %cmp2799 = icmp ne i64 %v2798, 0
  %cv2800 = zext i1 %cmp2799 to i32
  store i32 %cv2800, ptr %slot442, align 8
  %v2801 = load i32, ptr %slot442, align 8
  %cv2802 = zext i32 %v2801 to i64
  %cond2803 = icmp ne i64 %cv2802, 0
  br i1 %cond2803, label %bb_rcgnn572, label %bb_rcgdone572
bb_rcgnn572:
  %v2804 = load i64, ptr %slot441, align 8
  %op2805 = sub i64 %v2804, 16
  store i64 %op2805, ptr %slot443, align 8
  %v2806 = load i64, ptr %slot441, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %rgep2808 = getelementptr i8, ptr %p2807, i64 -16
  %ld2809 = load i64, ptr %rgep2808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2809, ptr %slot444, align 8
  %v2810 = load i64, ptr %slot444, align 8
  %op2811 = and i64 %v2810, 4611686018427387906
  store i64 %op2811, ptr %slot445, align 8
  %v2812 = load i64, ptr %slot445, align 8
  %cmp2813 = icmp ne i64 %v2812, 0
  %cv2814 = zext i1 %cmp2813 to i32
  store i32 %cv2814, ptr %slot446, align 8
  %v2815 = load i32, ptr %slot446, align 8
  %cv2816 = zext i32 %v2815 to i64
  %cond2817 = icmp ne i64 %cv2816, 0
  br i1 %cond2817, label %bb_rcgclear572, label %bb_rcgcounted572
bb_rcgcounted572:
  %v2818 = load i64, ptr %slot441, align 8
  %op2819 = sub i64 %v2818, 32
  store i64 %op2819, ptr %slot447, align 8
  %v2820 = load i64, ptr %slot441, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  %rgep2822 = getelementptr i8, ptr %p2821, i64 -32
  %ld2823 = load i64, ptr %rgep2822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2823, ptr %slot448, align 8
  %v2824 = load i64, ptr %slot448, align 8
  %op2825 = sub i64 %v2824, 1
  store i64 %op2825, ptr %slot449, align 8
  %v2826 = load i64, ptr %slot449, align 8
  %cmp2827 = icmp eq i64 %v2826, 0
  %cv2828 = zext i1 %cmp2827 to i32
  store i32 %cv2828, ptr %slot450, align 8
  %v2829 = load i32, ptr %slot450, align 8
  %cv2830 = zext i32 %v2829 to i64
  %cond2831 = icmp ne i64 %cv2830, 0
  br i1 %cond2831, label %bb_rcglast572, label %bb_rcgdec572
bb_rcglast572:
  %v2832 = load i64, ptr %slot441, align 8
  %op2833 = sub i64 %v2832, 24
  store i64 %op2833, ptr %slot451, align 8
  %v2834 = load i64, ptr %slot441, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  %rgep2836 = getelementptr i8, ptr %p2835, i64 -24
  %ld2837 = load i64, ptr %rgep2836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2837, ptr %slot452, align 8
  %v2838 = load i64, ptr %slot452, align 8
  %cmp2839 = icmp ne i64 %v2838, 0
  %cv2840 = zext i1 %cmp2839 to i32
  store i32 %cv2840, ptr %slot453, align 8
  %v2841 = load i32, ptr %slot453, align 8
  %cv2842 = zext i32 %v2841 to i64
  %cond2843 = icmp ne i64 %cv2842, 0
  br i1 %cond2843, label %bb_rcgdec572, label %bb_rcgslow572
bb_rcgslow572:
  %v2844 = load i64, ptr %slot440, align 8
  %v2845 = load i64, ptr %slot439, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2844, i64 %v2845) nomerge, !dbg !130
  br label %bb_rcgdone572
bb_rcgdec572:
  %v2846 = load i64, ptr %slot449, align 8
  %v2847 = load i64, ptr %slot441, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %rgep2849 = getelementptr i8, ptr %p2848, i64 -32
  store i64 %v2846, ptr %rgep2849, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear572
bb_rcgclear572:
  %v2850 = load i64, ptr %slot439, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  store i64 0, ptr %p2851, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone572
bb_rcgdone572:
  %v2852 = load i64, ptr %slot435, align 8
  %p2853 = inttoptr i64 %v2852 to ptr
  store i64 0, ptr %p2853, align 8, !alias.scope !3, !noalias !4
  %v2854 = load i64, ptr %slot435, align 8
  %p2856 = inttoptr i64 %v2854 to ptr
  %gep2857 = getelementptr i8, ptr %p2856, i64 8
  %op2855 = ptrtoint ptr %gep2857 to i64
  store i64 %op2855, ptr %slot454, align 8
  %v2858 = load i64, ptr %slot454, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  store i64 0, ptr %p2859, align 8, !alias.scope !3, !noalias !4
  %v2860 = load i64, ptr %slot435, align 8
  %p2862 = inttoptr i64 %v2860 to ptr
  %gep2863 = getelementptr i8, ptr %p2862, i64 16
  %op2861 = ptrtoint ptr %gep2863 to i64
  store i64 %op2861, ptr %slot455, align 8
  %v2864 = load i64, ptr %slot455, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i64 0, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone554
bb_rcslotdone554:
  br label %bb_rcprivateprepared518
bb_rcprivateprepared518:
  %v2866 = load i64, ptr %slot10, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  %ld2868 = load i32, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2868, ptr %slot456, align 8
  %v2869 = load i32, ptr %slot456, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcslotdrop581, label %bb_rcslotdone581
bb_rcslotdrop581:
  %v2872 = load i64, ptr %slot10, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  store i32 0, ptr %p2873, align 4, !alias.scope !3, !noalias !4
  %v2874 = load i64, ptr %slot34, align 8
  store i64 %v2874, ptr %slot457, align 8
  %v2875 = load i64, ptr %slot11, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %ld2877 = load i32, ptr %p2876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2877, ptr %slot458, align 8
  %v2878 = load i32, ptr %slot458, align 8
  %op2879 = and i32 %v2878, 28
  store i32 %op2879, ptr %slot459, align 8
  %v2880 = load i32, ptr %slot459, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcslotrole581, label %bb_rcslotowner581
bb_rcslotrole581:
  %v2883 = load i64, ptr %slot45, align 8
  store i64 %v2883, ptr %slot460, align 8
  %v2884 = load i64, ptr %slot460, align 8
  %v2885 = load i64, ptr %slot457, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v2884, i64 %v2885) nomerge, !dbg !130
  br label %bb_rcslotdone581
bb_rcslotowner581:
  %v2886 = load i64, ptr %slot457, align 8
  %p2888 = inttoptr i64 %v2886 to ptr
  %gep2889 = getelementptr i8, ptr %p2888, i64 8
  %op2887 = ptrtoint ptr %gep2889 to i64
  store i64 %op2887, ptr %slot461, align 8
  %v2890 = load i64, ptr %slot45, align 8
  store i64 %v2890, ptr %slot462, align 8
  %v2891 = load i64, ptr %slot461, align 8
  %p2892 = inttoptr i64 %v2891 to ptr
  %ld2893 = load i64, ptr %p2892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2893, ptr %slot463, align 8
  %v2894 = load i64, ptr %slot463, align 8
  %cmp2895 = icmp ne i64 %v2894, 0
  %cv2896 = zext i1 %cmp2895 to i32
  store i32 %cv2896, ptr %slot464, align 8
  %v2897 = load i32, ptr %slot464, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcgnn599, label %bb_rcgdone599
bb_rcgnn599:
  %v2900 = load i64, ptr %slot463, align 8
  %op2901 = sub i64 %v2900, 16
  store i64 %op2901, ptr %slot465, align 8
  %v2902 = load i64, ptr %slot463, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -16
  %ld2905 = load i64, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2905, ptr %slot466, align 8
  %v2906 = load i64, ptr %slot466, align 8
  %op2907 = and i64 %v2906, 4611686018427387906
  store i64 %op2907, ptr %slot467, align 8
  %v2908 = load i64, ptr %slot467, align 8
  %cmp2909 = icmp ne i64 %v2908, 0
  %cv2910 = zext i1 %cmp2909 to i32
  store i32 %cv2910, ptr %slot468, align 8
  %v2911 = load i32, ptr %slot468, align 8
  %cv2912 = zext i32 %v2911 to i64
  %cond2913 = icmp ne i64 %cv2912, 0
  br i1 %cond2913, label %bb_rcgclear599, label %bb_rcgcounted599
bb_rcgcounted599:
  %v2914 = load i64, ptr %slot463, align 8
  %op2915 = sub i64 %v2914, 32
  store i64 %op2915, ptr %slot469, align 8
  %v2916 = load i64, ptr %slot463, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %rgep2918 = getelementptr i8, ptr %p2917, i64 -32
  %ld2919 = load i64, ptr %rgep2918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2919, ptr %slot470, align 8
  %v2920 = load i64, ptr %slot470, align 8
  %op2921 = sub i64 %v2920, 1
  store i64 %op2921, ptr %slot471, align 8
  %v2922 = load i64, ptr %slot471, align 8
  %cmp2923 = icmp eq i64 %v2922, 0
  %cv2924 = zext i1 %cmp2923 to i32
  store i32 %cv2924, ptr %slot472, align 8
  %v2925 = load i32, ptr %slot472, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcglast599, label %bb_rcgdec599
bb_rcglast599:
  %v2928 = load i64, ptr %slot463, align 8
  %op2929 = sub i64 %v2928, 24
  store i64 %op2929, ptr %slot473, align 8
  %v2930 = load i64, ptr %slot463, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %rgep2932 = getelementptr i8, ptr %p2931, i64 -24
  %ld2933 = load i64, ptr %rgep2932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2933, ptr %slot474, align 8
  %v2934 = load i64, ptr %slot474, align 8
  %cmp2935 = icmp ne i64 %v2934, 0
  %cv2936 = zext i1 %cmp2935 to i32
  store i32 %cv2936, ptr %slot475, align 8
  %v2937 = load i32, ptr %slot475, align 8
  %cv2938 = zext i32 %v2937 to i64
  %cond2939 = icmp ne i64 %cv2938, 0
  br i1 %cond2939, label %bb_rcgdec599, label %bb_rcgslow599
bb_rcgslow599:
  %v2940 = load i64, ptr %slot462, align 8
  %v2941 = load i64, ptr %slot461, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v2940, i64 %v2941) nomerge, !dbg !130
  br label %bb_rcgdone599
bb_rcgdec599:
  %v2942 = load i64, ptr %slot471, align 8
  %v2943 = load i64, ptr %slot463, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %rgep2945 = getelementptr i8, ptr %p2944, i64 -32
  store i64 %v2942, ptr %rgep2945, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear599
bb_rcgclear599:
  %v2946 = load i64, ptr %slot461, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i64 0, ptr %p2947, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone599
bb_rcgdone599:
  %v2948 = load i64, ptr %slot457, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  store i64 0, ptr %p2949, align 8, !alias.scope !3, !noalias !4
  %v2950 = load i64, ptr %slot457, align 8
  %p2952 = inttoptr i64 %v2950 to ptr
  %gep2953 = getelementptr i8, ptr %p2952, i64 8
  %op2951 = ptrtoint ptr %gep2953 to i64
  store i64 %op2951, ptr %slot476, align 8
  %v2954 = load i64, ptr %slot476, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  store i64 0, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  %v2956 = load i64, ptr %slot457, align 8
  %p2958 = inttoptr i64 %v2956 to ptr
  %gep2959 = getelementptr i8, ptr %p2958, i64 16
  %op2957 = ptrtoint ptr %gep2959 to i64
  store i64 %op2957, ptr %slot477, align 8
  %v2960 = load i64, ptr %slot477, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  store i64 0, ptr %p2961, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone581
bb_rcslotdone581:
  %v2962 = load i64, ptr %slot34, align 8
  store i64 %v2962, ptr %slot478, align 8
  %v2963 = load i64, ptr %slot23, align 8
  store i64 %v2963, ptr %slot479, align 8
  %v2964 = load i64, ptr %slot479, align 8
  %v2965 = load i64, ptr %slot478, align 8
  %p2966 = inttoptr i64 %v2964 to ptr
  %p2967 = inttoptr i64 %v2965 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2967, ptr %p2966, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2968 = load i64, ptr %slot18, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 0, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot11, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  store i32 2, ptr %p2971, align 4, !alias.scope !3, !noalias !4
  %v2972 = load i64, ptr %slot19, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %ld2974 = load i32, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2974, ptr %slot480, align 8
  %v2975 = load i32, ptr %slot480, align 8
  %v2976 = load i64, ptr %slot11, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i32 %v2975, ptr %p2977, align 4, !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot10, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i32 1, ptr %p2979, align 4, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot34, align 8
  %v2981 = load i64, ptr %slot39, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  store i64 %v2980, ptr %p2982, align 8, !alias.scope !3, !noalias !4
  %v2983 = load i64, ptr %slot35, align 8
  %v2984 = load i64, ptr %slot40, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i64 %v2983, ptr %p2985, align 8, !alias.scope !3, !noalias !4
  %v2986 = load i64, ptr %slot40, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ld2988 = load i64, ptr %p2987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2988, ptr %slot481, align 8
  %v2989 = load i64, ptr %slot16, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  %ld2991 = load i32, ptr %p2990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2991, ptr %slot482, align 8
  %v2992 = load i64, ptr %slot17, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  %ld2994 = load i32, ptr %p2993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2994, ptr %slot483, align 8
  %v2995 = load i32, ptr %slot483, align 8
  %op2996 = and i32 %v2995, 24
  store i32 %op2996, ptr %slot483, align 8
  %v2997 = load i32, ptr %slot483, align 8
  %cmp2998 = icmp eq i32 %v2997, 0
  %cv2999 = zext i1 %cmp2998 to i32
  store i32 %cv2999, ptr %slot484, align 8
  %v3000 = load i32, ptr %slot482, align 8
  %v3001 = load i32, ptr %slot484, align 8
  %op3002 = and i32 %v3000, %v3001
  store i32 %op3002, ptr %slot485, align 8
  %v3003 = load i64, ptr %slot46, align 8
  store i64 %v3003, ptr %slot486, align 8
  %v3004 = load i32, ptr %slot485, align 8
  %op3005 = mul i32 %v3004, 4
  store i32 %op3005, ptr %slot487, align 8
  %v3006 = load i32, ptr %slot487, align 8
  %op3007 = or i32 %v3006, 0
  store i32 %op3007, ptr %slot488, align 8
  %v3008 = load i64, ptr %slot23, align 8
  store i64 %v3008, ptr %slot489, align 8
  %v3009 = load i64, ptr %slot45, align 8
  %v3010 = load i64, ptr %slot489, align 8
  %v3011 = load i64, ptr %slot481, align 8
  %v3012 = load i64, ptr %slot486, align 8
  %cv3013 = trunc i64 %v3012 to i32
  %v3014 = load i32, ptr %slot488, align 8
  %call3015 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64 %v3009, i64 %v3010, i64 %v3011, i32 %cv3013, i32 %v3014) nomerge, !dbg !132
  store i32 %call3015, ptr %slot490, align 8
  %v3016 = load i32, ptr %slot490, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcsuccess626, label %bb_rcfailure626
bb_rcfailure626:
  %v3019 = load i64, ptr %slot45, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %call3021 = call i32 @myl_rc_take_failure(ptr %p3020) nomerge, !dbg !132
  store i32 %call3021, ptr %slot491, align 8
  %v3022 = load i64, ptr %slot1, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  %v3024 = load i32, ptr %slot491, align 8
  %call3025 = call i32 @myl_qbe_rc_status(ptr %p3023, i32 %v3024) nomerge, !dbg !132
  store i32 %call3025, ptr %slot492, align 8
  br label %bb_failure
bb_rcsuccess626:
  %v3026 = load i32, ptr %slot485, align 8
  %cv3027 = zext i32 %v3026 to i64
  %cond3028 = icmp ne i64 %cv3027, 0
  br i1 %cond3028, label %bb_rchtaken629, label %bb_rchcopied629
bb_rchcopied629:
  %v3029 = load i64, ptr %slot16, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  %ld3031 = load i32, ptr %p3030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3031, ptr %slot493, align 8
  %v3032 = load i32, ptr %slot493, align 8
  %cv3033 = zext i32 %v3032 to i64
  %cond3034 = icmp ne i64 %cv3033, 0
  br i1 %cond3034, label %bb_rcslotdrop632, label %bb_rcslotdone632
bb_rcslotdrop632:
  %v3035 = load i64, ptr %slot16, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  store i32 0, ptr %p3036, align 4, !alias.scope !3, !noalias !4
  %v3037 = load i64, ptr %slot22, align 8
  store i64 %v3037, ptr %slot494, align 8
  %v3038 = load i64, ptr %slot17, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %ld3040 = load i32, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3040, ptr %slot495, align 8
  %v3041 = load i32, ptr %slot495, align 8
  %op3042 = and i32 %v3041, 28
  store i32 %op3042, ptr %slot496, align 8
  %v3043 = load i32, ptr %slot496, align 8
  %cv3044 = zext i32 %v3043 to i64
  %cond3045 = icmp ne i64 %cv3044, 0
  br i1 %cond3045, label %bb_rcslotrole632, label %bb_rcslotowner632
bb_rcslotrole632:
  %v3046 = load i64, ptr %slot45, align 8
  store i64 %v3046, ptr %slot497, align 8
  %v3047 = load i64, ptr %slot497, align 8
  %v3048 = load i64, ptr %slot494, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3047, i64 %v3048) nomerge, !dbg !132
  br label %bb_rcslotdone632
bb_rcslotowner632:
  %v3049 = load i64, ptr %slot45, align 8
  store i64 %v3049, ptr %slot498, align 8
  %v3050 = load i64, ptr %slot498, align 8
  %v3051 = load i64, ptr %slot494, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3050, i64 %v3051) nomerge, !dbg !132
  br label %bb_rcslotdone632
bb_rcslotdone632:
  br label %bb_rchprepared629
bb_rchtaken629:
  %v3052 = load i64, ptr %slot16, align 8
  %p3053 = inttoptr i64 %v3052 to ptr
  store i32 0, ptr %p3053, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared629
bb_rchprepared629:
  %v3054 = load i64, ptr %slot19, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i32 2, ptr %p3055, align 4, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot18, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 1, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot22, align 8
  store i64 %v3058, ptr %slot499, align 8
  %v3059 = load i64, ptr %slot23, align 8
  store i64 %v3059, ptr %slot500, align 8
  %v3060 = load i64, ptr %slot500, align 8
  %v3061 = load i64, ptr %slot499, align 8
  %p3062 = inttoptr i64 %v3060 to ptr
  %p3063 = inttoptr i64 %v3061 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3063, ptr %p3062, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3064 = load i64, ptr %slot17, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  store i32 2, ptr %p3065, align 4, !alias.scope !3, !noalias !4
  %v3066 = load i64, ptr %slot19, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  %ld3068 = load i32, ptr %p3067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3068, ptr %slot501, align 8
  %v3069 = load i32, ptr %slot501, align 8
  %v3070 = load i64, ptr %slot17, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i32 %v3069, ptr %p3071, align 4, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot18, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i32 0, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  %v3074 = load i64, ptr %slot16, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i32 1, ptr %p3075, align 4, !alias.scope !3, !noalias !4
  %v3076 = load i64, ptr %slot499, align 8
  %v3077 = load i64, ptr %slot40, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  store i64 %v3076, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  %v3079 = load i64, ptr %slot39, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  %ld3081 = load i64, ptr %p3080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3081, ptr %slot502, align 8
  %v3082 = load i64, ptr %slot14, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %ld3084 = load i32, ptr %p3083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3084, ptr %slot503, align 8
  %v3085 = load i64, ptr %slot15, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  %ld3087 = load i32, ptr %p3086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3087, ptr %slot504, align 8
  %v3088 = load i32, ptr %slot504, align 8
  %op3089 = and i32 %v3088, 24
  store i32 %op3089, ptr %slot504, align 8
  %v3090 = load i32, ptr %slot504, align 8
  %cmp3091 = icmp eq i32 %v3090, 0
  %cv3092 = zext i1 %cmp3091 to i32
  store i32 %cv3092, ptr %slot505, align 8
  %v3093 = load i32, ptr %slot503, align 8
  %v3094 = load i32, ptr %slot505, align 8
  %op3095 = and i32 %v3093, %v3094
  store i32 %op3095, ptr %slot506, align 8
  %v3096 = load i32, ptr %slot506, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rctake651, label %bb_rccopy651
bb_rctake651:
  %v3099 = load i64, ptr %slot23, align 8
  store i64 %v3099, ptr %slot507, align 8
  %v3100 = load i64, ptr %slot46, align 8
  store i64 %v3100, ptr %slot508, align 8
  %v3101 = load i64, ptr %slot502, align 8
  %v3102 = load i64, ptr %slot507, align 8
  %op3103 = sub i64 %v3101, %v3102
  store i64 %op3103, ptr %slot509, align 8
  %v3104 = load i64, ptr %slot507, align 8
  %v3105 = load i64, ptr %slot502, align 8
  %op3106 = sub i64 %v3104, %v3105
  store i64 %op3106, ptr %slot510, align 8
  %v3107 = load i64, ptr %slot509, align 8
  %cmp3108 = icmp ult i64 %v3107, 24
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot511, align 8
  %v3110 = load i64, ptr %slot510, align 8
  %cmp3111 = icmp ult i64 %v3110, 24
  %cv3112 = zext i1 %cmp3111 to i32
  store i32 %cv3112, ptr %slot512, align 8
  %v3113 = load i32, ptr %slot511, align 8
  %v3114 = load i32, ptr %slot512, align 8
  %op3115 = or i32 %v3113, %v3114
  store i32 %op3115, ptr %slot513, align 8
  %v3116 = load i32, ptr %slot513, align 8
  %cv3117 = zext i32 %v3116 to i64
  %cond3118 = icmp ne i64 %cv3117, 0
  br i1 %cond3118, label %bb_rcmoveslow660, label %bb_rcmovecheck660
bb_rcmovecheck660:
  %v3119 = load i64, ptr %slot502, align 8
  %op3120 = add i64 %v3119, 8
  store i64 %op3120, ptr %slot514, align 8
  %v3121 = load i64, ptr %slot514, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %ld3123 = load i64, ptr %p3122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3123, ptr %slot515, align 8
  %v3124 = load i64, ptr %slot515, align 8
  %cmp3125 = icmp ne i64 %v3124, 0
  %cv3126 = zext i1 %cmp3125 to i32
  store i32 %cv3126, ptr %slot516, align 8
  %v3127 = load i32, ptr %slot516, align 8
  %cv3128 = zext i32 %v3127 to i64
  %cond3129 = icmp ne i64 %cv3128, 0
  br i1 %cond3129, label %bb_rcmoveheader668, label %bb_rcmovenext668
bb_rcmoveheader668:
  %v3130 = load i64, ptr %slot515, align 8
  %op3131 = sub i64 %v3130, 16
  store i64 %op3131, ptr %slot517, align 8
  %v3132 = load i64, ptr %slot515, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %rgep3134 = getelementptr i8, ptr %p3133, i64 -16
  %ld3135 = load i64, ptr %rgep3134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3135, ptr %slot518, align 8
  %v3136 = load i64, ptr %slot518, align 8
  %op3137 = and i64 %v3136, 5764607523034234881
  store i64 %op3137, ptr %slot519, align 8
  %v3138 = load i64, ptr %slot519, align 8
  %cmp3139 = icmp ne i64 %v3138, 0
  %cv3140 = zext i1 %cmp3139 to i32
  store i32 %cv3140, ptr %slot520, align 8
  %v3141 = load i32, ptr %slot520, align 8
  %cv3142 = zext i32 %v3141 to i64
  %cond3143 = icmp ne i64 %cv3142, 0
  br i1 %cond3143, label %bb_rcmoveslow660, label %bb_rcmovenext668
bb_rcmovenext668:
  %v3144 = load i64, ptr %slot502, align 8
  %v3145 = load i64, ptr %slot507, align 8
  %p3146 = inttoptr i64 %v3144 to ptr
  %p3147 = inttoptr i64 %v3145 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3147, ptr %p3146, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3148 = load i64, ptr %slot502, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  store i64 0, ptr %p3149, align 8, !alias.scope !3, !noalias !4
  %v3150 = load i64, ptr %slot502, align 8
  %op3151 = add i64 %v3150, 8
  store i64 %op3151, ptr %slot521, align 8
  %v3152 = load i64, ptr %slot521, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  store i64 0, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  %v3154 = load i64, ptr %slot502, align 8
  %op3155 = add i64 %v3154, 16
  store i64 %op3155, ptr %slot522, align 8
  %v3156 = load i64, ptr %slot522, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  store i64 0, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved660
bb_rcmoveslow660:
  %v3158 = load i64, ptr %slot45, align 8
  %v3159 = load i64, ptr %slot507, align 8
  %v3160 = load i64, ptr %slot502, align 8
  %v3161 = load i64, ptr %slot508, align 8
  %cv3162 = trunc i64 %v3161 to i32
  %call3163 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v3158, i64 %v3159, i64 %v3160, i32 %cv3162) nomerge, !dbg !134
  store i32 %call3163, ptr %slot523, align 8
  %v3164 = load i32, ptr %slot523, align 8
  %cv3165 = zext i32 %v3164 to i64
  %cond3166 = icmp ne i64 %cv3165, 0
  br i1 %cond3166, label %bb_rcsuccess677, label %bb_rcfailure677
bb_rcfailure677:
  %v3167 = load i64, ptr %slot45, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %call3169 = call i32 @myl_rc_take_failure(ptr %p3168) nomerge, !dbg !134
  store i32 %call3169, ptr %slot524, align 8
  %v3170 = load i64, ptr %slot1, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  %v3172 = load i32, ptr %slot524, align 8
  %call3173 = call i32 @myl_qbe_rc_status(ptr %p3171, i32 %v3172) nomerge, !dbg !134
  store i32 %call3173, ptr %slot525, align 8
  br label %bb_failure
bb_rcsuccess677:
  br label %bb_rcmoved660
bb_rcmoved660:
  %v3174 = load i64, ptr %slot14, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  store i32 0, ptr %p3175, align 4, !alias.scope !3, !noalias !4
  %v3176 = load i64, ptr %slot19, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  store i32 2, ptr %p3177, align 4, !alias.scope !3, !noalias !4
  %v3178 = load i64, ptr %slot18, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  store i32 1, ptr %p3179, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared651
bb_rccopy651:
  %v3180 = load i64, ptr %slot23, align 8
  store i64 %v3180, ptr %slot526, align 8
  %v3181 = load i64, ptr %slot46, align 8
  store i64 %v3181, ptr %slot527, align 8
  %v3182 = load i64, ptr %slot45, align 8
  %v3183 = load i64, ptr %slot526, align 8
  %v3184 = load i64, ptr %slot502, align 8
  %v3185 = load i64, ptr %slot527, align 8
  %cv3186 = trunc i64 %v3185 to i32
  %call3187 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v3182, i64 %v3183, i64 %v3184, i32 %cv3186) nomerge, !dbg !134
  store i32 %call3187, ptr %slot528, align 8
  %v3188 = load i32, ptr %slot528, align 8
  %cv3189 = zext i32 %v3188 to i64
  %cond3190 = icmp ne i64 %cv3189, 0
  br i1 %cond3190, label %bb_rcsuccess686, label %bb_rcfailure686
bb_rcfailure686:
  %v3191 = load i64, ptr %slot45, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  %call3193 = call i32 @myl_rc_take_failure(ptr %p3192) nomerge, !dbg !134
  store i32 %call3193, ptr %slot529, align 8
  %v3194 = load i64, ptr %slot1, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  %v3196 = load i32, ptr %slot529, align 8
  %call3197 = call i32 @myl_qbe_rc_status(ptr %p3195, i32 %v3196) nomerge, !dbg !134
  store i32 %call3197, ptr %slot530, align 8
  br label %bb_failure
bb_rcsuccess686:
  %v3198 = load i64, ptr %slot19, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  store i32 2, ptr %p3199, align 4, !alias.scope !3, !noalias !4
  %v3200 = load i64, ptr %slot18, align 8
  %p3201 = inttoptr i64 %v3200 to ptr
  store i32 1, ptr %p3201, align 4, !alias.scope !3, !noalias !4
  %v3202 = load i64, ptr %slot14, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %ld3204 = load i32, ptr %p3203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3204, ptr %slot531, align 8
  %v3205 = load i32, ptr %slot531, align 8
  %cv3206 = zext i32 %v3205 to i64
  %cond3207 = icmp ne i64 %cv3206, 0
  br i1 %cond3207, label %bb_rcslotdrop693, label %bb_rcslotdone693
bb_rcslotdrop693:
  %v3208 = load i64, ptr %slot14, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  store i32 0, ptr %p3209, align 4, !alias.scope !3, !noalias !4
  %v3210 = load i64, ptr %slot21, align 8
  store i64 %v3210, ptr %slot532, align 8
  %v3211 = load i64, ptr %slot15, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i32, ptr %p3212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3213, ptr %slot533, align 8
  %v3214 = load i32, ptr %slot533, align 8
  %op3215 = and i32 %v3214, 28
  store i32 %op3215, ptr %slot534, align 8
  %v3216 = load i32, ptr %slot534, align 8
  %cv3217 = zext i32 %v3216 to i64
  %cond3218 = icmp ne i64 %cv3217, 0
  br i1 %cond3218, label %bb_rcslotrole693, label %bb_rcslotowner693
bb_rcslotrole693:
  %v3219 = load i64, ptr %slot45, align 8
  store i64 %v3219, ptr %slot535, align 8
  %v3220 = load i64, ptr %slot535, align 8
  %v3221 = load i64, ptr %slot532, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3220, i64 %v3221) nomerge, !dbg !134
  br label %bb_rcslotdone693
bb_rcslotowner693:
  %v3222 = load i64, ptr %slot45, align 8
  store i64 %v3222, ptr %slot536, align 8
  %v3223 = load i64, ptr %slot536, align 8
  %v3224 = load i64, ptr %slot532, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3223, i64 %v3224) nomerge, !dbg !134
  br label %bb_rcslotdone693
bb_rcslotdone693:
  br label %bb_rcprepared651
bb_rcprepared651:
  %v3225 = load i64, ptr %slot23, align 8
  store i64 %v3225, ptr %slot537, align 8
  %v3226 = load i64, ptr %slot41, align 8
  store i64 %v3226, ptr %slot538, align 8
  %v3227 = load i64, ptr %slot537, align 8
  %v3228 = load i64, ptr %slot538, align 8
  %p3229 = inttoptr i64 %v3227 to ptr
  %p3230 = inttoptr i64 %v3228 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3230, ptr %p3229, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3231 = load i64, ptr %slot18, align 8
  %p3232 = inttoptr i64 %v3231 to ptr
  store i32 0, ptr %p3232, align 4, !alias.scope !3, !noalias !4
  %v3233 = load i64, ptr %slot20, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  store i32 1, ptr %p3234, align 4, !alias.scope !3, !noalias !4
  %v3235 = load i64, ptr %slot46, align 8
  store i64 %v3235, ptr %slot539, align 8
  %v3236 = load i64, ptr %slot40, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %ld3238 = load i64, ptr %p3237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3238, ptr %slot540, align 8
  %v3239 = load i64, ptr %slot538, align 8
  %p3241 = inttoptr i64 %v3239 to ptr
  %gep3242 = getelementptr i8, ptr %p3241, i64 8
  %op3240 = ptrtoint ptr %gep3242 to i64
  store i64 %op3240, ptr %slot541, align 8
  %v3243 = load i64, ptr %slot23, align 8
  store i64 %v3243, ptr %slot542, align 8
  %v3244 = load i64, ptr %slot40, align 8
  %p3245 = inttoptr i64 %v3244 to ptr
  %ld3246 = load i64, ptr %p3245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3246, ptr %slot543, align 8
  %v3247 = load i64, ptr %slot23, align 8
  store i64 %v3247, ptr %slot544, align 8
  %v3248 = load i64, ptr %slot46, align 8
  store i64 %v3248, ptr %slot545, align 8
  %v3249 = load i64, ptr %slot543, align 8
  %op3250 = add i64 %v3249, 0
  store i64 %op3250, ptr %slot546, align 8
  %v3251 = load i64, ptr %slot546, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %ld3253 = load i64, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3253, ptr %slot547, align 8
  %v3254 = load i64, ptr %slot547, align 8
  %cmp3255 = icmp ne i64 %v3254, 0
  %cv3256 = zext i1 %cmp3255 to i32
  store i32 %cv3256, ptr %slot548, align 8
  %v3257 = load i32, ptr %slot548, align 8
  %cv3258 = zext i32 %v3257 to i64
  %cond3259 = icmp ne i64 %cv3258, 0
  br i1 %cond3259, label %bb_rcmoveheader715, label %bb_rcmovenext715
bb_rcmoveheader715:
  %v3260 = load i64, ptr %slot547, align 8
  %op3261 = sub i64 %v3260, 16
  store i64 %op3261, ptr %slot549, align 8
  %v3262 = load i64, ptr %slot547, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %rgep3264 = getelementptr i8, ptr %p3263, i64 -16
  %ld3265 = load i64, ptr %rgep3264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3265, ptr %slot550, align 8
  %v3266 = load i64, ptr %slot550, align 8
  %op3267 = and i64 %v3266, 5764607523034234881
  store i64 %op3267, ptr %slot551, align 8
  %v3268 = load i64, ptr %slot551, align 8
  %cmp3269 = icmp ne i64 %v3268, 0
  %cv3270 = zext i1 %cmp3269 to i32
  store i32 %cv3270, ptr %slot552, align 8
  %v3271 = load i32, ptr %slot552, align 8
  %cv3272 = zext i32 %v3271 to i64
  %cond3273 = icmp ne i64 %cv3272, 0
  br i1 %cond3273, label %bb_rcmoveslow712, label %bb_rcmovenext715
bb_rcmovenext715:
  %v3274 = load i64, ptr %slot543, align 8
  %v3275 = load i64, ptr %slot544, align 8
  %p3276 = inttoptr i64 %v3274 to ptr
  %p3277 = inttoptr i64 %v3275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3277, ptr %p3276, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot543, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i64 0, ptr %p3279, align 8, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot543, align 8
  %op3281 = add i64 %v3280, 8
  store i64 %op3281, ptr %slot553, align 8
  %v3282 = load i64, ptr %slot553, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i64 0, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved712
bb_rcmoveslow712:
  %v3284 = load i64, ptr %slot45, align 8
  %v3285 = load i64, ptr %slot544, align 8
  %v3286 = load i64, ptr %slot543, align 8
  %v3287 = load i64, ptr %slot545, align 8
  %cv3288 = trunc i64 %v3287 to i32
  %call3289 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3284, i64 %v3285, i64 %v3286, i32 %cv3288) nomerge, !dbg !134
  store i32 %call3289, ptr %slot554, align 8
  %v3290 = load i32, ptr %slot554, align 8
  %cv3291 = zext i32 %v3290 to i64
  %cond3292 = icmp ne i64 %cv3291, 0
  br i1 %cond3292, label %bb_rcsuccess723, label %bb_rcfailure723
bb_rcfailure723:
  %v3293 = load i64, ptr %slot45, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %call3295 = call i32 @myl_rc_take_failure(ptr %p3294) nomerge, !dbg !134
  store i32 %call3295, ptr %slot555, align 8
  %v3296 = load i64, ptr %slot1, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %v3298 = load i32, ptr %slot555, align 8
  %call3299 = call i32 @myl_qbe_rc_status(ptr %p3297, i32 %v3298) nomerge, !dbg !134
  store i32 %call3299, ptr %slot556, align 8
  br label %bb_failure
bb_rcsuccess723:
  br label %bb_rcmoved712
bb_rcmoved712:
  %v3300 = load i64, ptr %slot16, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i32 0, ptr %p3301, align 4, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot19, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  store i32 2, ptr %p3303, align 4, !alias.scope !3, !noalias !4
  %v3304 = load i64, ptr %slot18, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  store i32 1, ptr %p3305, align 4, !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot23, align 8
  store i64 %v3306, ptr %slot557, align 8
  %v3307 = load i64, ptr %slot557, align 8
  %v3308 = load i64, ptr %slot542, align 8
  %p3309 = inttoptr i64 %v3307 to ptr
  %p3310 = inttoptr i64 %v3308 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3310, ptr %p3309, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot18, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 0, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot19, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i32 2, ptr %p3314, align 4, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot18, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i32 1, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot45, align 8
  store i64 %v3317, ptr %slot558, align 8
  %v3318 = load i64, ptr %slot558, align 8
  %v3319 = load i64, ptr %slot541, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3318, i64 %v3319) nomerge, !dbg !134
  %v3320 = load i64, ptr %slot542, align 8
  %v3321 = load i64, ptr %slot541, align 8
  %p3322 = inttoptr i64 %v3320 to ptr
  %p3323 = inttoptr i64 %v3321 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3323, ptr %p3322, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot18, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  store i32 0, ptr %p3325, align 4, !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot538, align 8
  %v3327 = load i64, ptr %slot39, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  store i64 %v3326, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  %v3329 = load i64, ptr %slot39, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %ld3331 = load i64, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3331, ptr %slot559, align 8
  %v3332 = load i64, ptr %slot23, align 8
  store i64 %v3332, ptr %slot560, align 8
  %v3333 = load i64, ptr %slot559, align 8
  %v3334 = load i64, ptr %slot560, align 8
  %p3335 = inttoptr i64 %v3333 to ptr
  %p3336 = inttoptr i64 %v3334 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3336, ptr %p3335, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3337 = load i64, ptr %slot19, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  store i32 2, ptr %p3338, align 4, !alias.scope !3, !noalias !4
  %v3339 = load i64, ptr %slot18, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 1, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot14, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i32, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3343, ptr %slot561, align 8
  %v3344 = load i32, ptr %slot561, align 8
  %cv3345 = zext i32 %v3344 to i64
  %cond3346 = icmp ne i64 %cv3345, 0
  br i1 %cond3346, label %bb_rcslotdrop741, label %bb_rcslotdone741
bb_rcslotdrop741:
  %v3347 = load i64, ptr %slot14, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  store i32 0, ptr %p3348, align 4, !alias.scope !3, !noalias !4
  %v3349 = load i64, ptr %slot21, align 8
  store i64 %v3349, ptr %slot562, align 8
  %v3350 = load i64, ptr %slot15, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i32, ptr %p3351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3352, ptr %slot563, align 8
  %v3353 = load i32, ptr %slot563, align 8
  %op3354 = and i32 %v3353, 28
  store i32 %op3354, ptr %slot564, align 8
  %v3355 = load i32, ptr %slot564, align 8
  %cv3356 = zext i32 %v3355 to i64
  %cond3357 = icmp ne i64 %cv3356, 0
  br i1 %cond3357, label %bb_rcslotrole741, label %bb_rcslotowner741
bb_rcslotrole741:
  %v3358 = load i64, ptr %slot45, align 8
  store i64 %v3358, ptr %slot565, align 8
  %v3359 = load i64, ptr %slot565, align 8
  %v3360 = load i64, ptr %slot562, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3359, i64 %v3360) nomerge, !dbg !134
  br label %bb_rcslotdone741
bb_rcslotowner741:
  %v3361 = load i64, ptr %slot45, align 8
  store i64 %v3361, ptr %slot566, align 8
  %v3362 = load i64, ptr %slot566, align 8
  %v3363 = load i64, ptr %slot562, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3362, i64 %v3363) nomerge, !dbg !134
  br label %bb_rcslotdone741
bb_rcslotdone741:
  %v3364 = load i64, ptr %slot16, align 8
  %p3365 = inttoptr i64 %v3364 to ptr
  %ld3366 = load i32, ptr %p3365, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3366, ptr %slot567, align 8
  %v3367 = load i32, ptr %slot567, align 8
  %cv3368 = zext i32 %v3367 to i64
  %cond3369 = icmp ne i64 %cv3368, 0
  br i1 %cond3369, label %bb_rcslotdrop750, label %bb_rcslotdone750
bb_rcslotdrop750:
  %v3370 = load i64, ptr %slot16, align 8
  %p3371 = inttoptr i64 %v3370 to ptr
  store i32 0, ptr %p3371, align 4, !alias.scope !3, !noalias !4
  %v3372 = load i64, ptr %slot22, align 8
  store i64 %v3372, ptr %slot568, align 8
  %v3373 = load i64, ptr %slot17, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  %ld3375 = load i32, ptr %p3374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3375, ptr %slot569, align 8
  %v3376 = load i32, ptr %slot569, align 8
  %op3377 = and i32 %v3376, 28
  store i32 %op3377, ptr %slot570, align 8
  %v3378 = load i32, ptr %slot570, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcslotrole750, label %bb_rcslotowner750
bb_rcslotrole750:
  %v3381 = load i64, ptr %slot45, align 8
  store i64 %v3381, ptr %slot571, align 8
  %v3382 = load i64, ptr %slot571, align 8
  %v3383 = load i64, ptr %slot568, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v3382, i64 %v3383) nomerge, !dbg !134
  br label %bb_rcslotdone750
bb_rcslotowner750:
  %v3384 = load i64, ptr %slot45, align 8
  store i64 %v3384, ptr %slot572, align 8
  %v3385 = load i64, ptr %slot572, align 8
  %v3386 = load i64, ptr %slot568, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v3385, i64 %v3386) nomerge, !dbg !134
  br label %bb_rcslotdone750
bb_rcslotdone750:
  %v3387 = load i64, ptr %slot21, align 8
  store i64 %v3387, ptr %slot573, align 8
  %v3388 = load i64, ptr %slot23, align 8
  store i64 %v3388, ptr %slot574, align 8
  %v3389 = load i64, ptr %slot574, align 8
  %v3390 = load i64, ptr %slot573, align 8
  %p3391 = inttoptr i64 %v3389 to ptr
  %p3392 = inttoptr i64 %v3390 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3392, ptr %p3391, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot15, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 2, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot19, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  %ld3397 = load i32, ptr %p3396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3397, ptr %slot575, align 8
  %v3398 = load i32, ptr %slot575, align 8
  %v3399 = load i64, ptr %slot15, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i32 %v3398, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  %v3401 = load i64, ptr %slot18, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  store i32 0, ptr %p3402, align 4, !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot14, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i32 1, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot573, align 8
  %v3406 = load i64, ptr %slot39, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i64 %v3405, ptr %p3407, align 8, !alias.scope !3, !noalias !4
  %v3408 = load i64, ptr %slot39, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  %ld3410 = load i64, ptr %p3409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3410, ptr %slot576, align 8
  %v3411 = load i64, ptr %slot14, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %ld3413 = load i32, ptr %p3412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3413, ptr %slot577, align 8
  %v3414 = load i64, ptr %slot15, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %ld3416 = load i32, ptr %p3415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3416, ptr %slot578, align 8
  %v3417 = load i32, ptr %slot578, align 8
  %op3418 = and i32 %v3417, 24
  store i32 %op3418, ptr %slot578, align 8
  %v3419 = load i32, ptr %slot578, align 8
  %cmp3420 = icmp eq i32 %v3419, 0
  %cv3421 = zext i1 %cmp3420 to i32
  store i32 %cv3421, ptr %slot579, align 8
  %v3422 = load i32, ptr %slot577, align 8
  %v3423 = load i32, ptr %slot579, align 8
  %op3424 = and i32 %v3422, %v3423
  store i32 %op3424, ptr %slot580, align 8
  %v3425 = load i32, ptr %slot580, align 8
  %cv3426 = zext i32 %v3425 to i64
  %cond3427 = icmp ne i64 %cv3426, 0
  br i1 %cond3427, label %bb_rctake766, label %bb_rccopy766
bb_rctake766:
  %v3428 = load i64, ptr %slot23, align 8
  store i64 %v3428, ptr %slot581, align 8
  %v3429 = load i64, ptr %slot46, align 8
  store i64 %v3429, ptr %slot582, align 8
  %v3430 = load i64, ptr %slot576, align 8
  %v3431 = load i64, ptr %slot581, align 8
  %op3432 = sub i64 %v3430, %v3431
  store i64 %op3432, ptr %slot583, align 8
  %v3433 = load i64, ptr %slot581, align 8
  %v3434 = load i64, ptr %slot576, align 8
  %op3435 = sub i64 %v3433, %v3434
  store i64 %op3435, ptr %slot584, align 8
  %v3436 = load i64, ptr %slot583, align 8
  %cmp3437 = icmp ult i64 %v3436, 24
  %cv3438 = zext i1 %cmp3437 to i32
  store i32 %cv3438, ptr %slot585, align 8
  %v3439 = load i64, ptr %slot584, align 8
  %cmp3440 = icmp ult i64 %v3439, 24
  %cv3441 = zext i1 %cmp3440 to i32
  store i32 %cv3441, ptr %slot586, align 8
  %v3442 = load i32, ptr %slot585, align 8
  %v3443 = load i32, ptr %slot586, align 8
  %op3444 = or i32 %v3442, %v3443
  store i32 %op3444, ptr %slot587, align 8
  %v3445 = load i32, ptr %slot587, align 8
  %cv3446 = zext i32 %v3445 to i64
  %cond3447 = icmp ne i64 %cv3446, 0
  br i1 %cond3447, label %bb_rcmoveslow775, label %bb_rcmovecheck775
bb_rcmovecheck775:
  %v3448 = load i64, ptr %slot576, align 8
  %op3449 = add i64 %v3448, 8
  store i64 %op3449, ptr %slot588, align 8
  %v3450 = load i64, ptr %slot588, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i64, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3452, ptr %slot589, align 8
  %v3453 = load i64, ptr %slot589, align 8
  %cmp3454 = icmp ne i64 %v3453, 0
  %cv3455 = zext i1 %cmp3454 to i32
  store i32 %cv3455, ptr %slot590, align 8
  %v3456 = load i32, ptr %slot590, align 8
  %cv3457 = zext i32 %v3456 to i64
  %cond3458 = icmp ne i64 %cv3457, 0
  br i1 %cond3458, label %bb_rcmoveheader783, label %bb_rcmovenext783
bb_rcmoveheader783:
  %v3459 = load i64, ptr %slot589, align 8
  %op3460 = sub i64 %v3459, 16
  store i64 %op3460, ptr %slot591, align 8
  %v3461 = load i64, ptr %slot589, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %rgep3463 = getelementptr i8, ptr %p3462, i64 -16
  %ld3464 = load i64, ptr %rgep3463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3464, ptr %slot592, align 8
  %v3465 = load i64, ptr %slot592, align 8
  %op3466 = and i64 %v3465, 5764607523034234881
  store i64 %op3466, ptr %slot593, align 8
  %v3467 = load i64, ptr %slot593, align 8
  %cmp3468 = icmp ne i64 %v3467, 0
  %cv3469 = zext i1 %cmp3468 to i32
  store i32 %cv3469, ptr %slot594, align 8
  %v3470 = load i32, ptr %slot594, align 8
  %cv3471 = zext i32 %v3470 to i64
  %cond3472 = icmp ne i64 %cv3471, 0
  br i1 %cond3472, label %bb_rcmoveslow775, label %bb_rcmovenext783
bb_rcmovenext783:
  %v3473 = load i64, ptr %slot576, align 8
  %v3474 = load i64, ptr %slot581, align 8
  %p3475 = inttoptr i64 %v3473 to ptr
  %p3476 = inttoptr i64 %v3474 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3476, ptr %p3475, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot576, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  store i64 0, ptr %p3478, align 8, !alias.scope !3, !noalias !4
  %v3479 = load i64, ptr %slot576, align 8
  %op3480 = add i64 %v3479, 8
  store i64 %op3480, ptr %slot595, align 8
  %v3481 = load i64, ptr %slot595, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i64 0, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  %v3483 = load i64, ptr %slot576, align 8
  %op3484 = add i64 %v3483, 16
  store i64 %op3484, ptr %slot596, align 8
  %v3485 = load i64, ptr %slot596, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  store i64 0, ptr %p3486, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved775
bb_rcmoveslow775:
  %v3487 = load i64, ptr %slot45, align 8
  %v3488 = load i64, ptr %slot581, align 8
  %v3489 = load i64, ptr %slot576, align 8
  %v3490 = load i64, ptr %slot582, align 8
  %cv3491 = trunc i64 %v3490 to i32
  %call3492 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v3487, i64 %v3488, i64 %v3489, i32 %cv3491) nomerge, !dbg !136
  store i32 %call3492, ptr %slot597, align 8
  %v3493 = load i32, ptr %slot597, align 8
  %cv3494 = zext i32 %v3493 to i64
  %cond3495 = icmp ne i64 %cv3494, 0
  br i1 %cond3495, label %bb_rcsuccess792, label %bb_rcfailure792
bb_rcfailure792:
  %v3496 = load i64, ptr %slot45, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %call3498 = call i32 @myl_rc_take_failure(ptr %p3497) nomerge, !dbg !136
  store i32 %call3498, ptr %slot598, align 8
  %v3499 = load i64, ptr %slot1, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  %v3501 = load i32, ptr %slot598, align 8
  %call3502 = call i32 @myl_qbe_rc_status(ptr %p3500, i32 %v3501) nomerge, !dbg !136
  store i32 %call3502, ptr %slot599, align 8
  br label %bb_failure
bb_rcsuccess792:
  br label %bb_rcmoved775
bb_rcmoved775:
  %v3503 = load i64, ptr %slot14, align 8
  %p3504 = inttoptr i64 %v3503 to ptr
  store i32 0, ptr %p3504, align 4, !alias.scope !3, !noalias !4
  %v3505 = load i64, ptr %slot19, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  store i32 2, ptr %p3506, align 4, !alias.scope !3, !noalias !4
  %v3507 = load i64, ptr %slot18, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  store i32 1, ptr %p3508, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared766
bb_rccopy766:
  %v3509 = load i64, ptr %slot23, align 8
  store i64 %v3509, ptr %slot600, align 8
  %v3510 = load i64, ptr %slot46, align 8
  store i64 %v3510, ptr %slot601, align 8
  %v3511 = load i64, ptr %slot45, align 8
  %v3512 = load i64, ptr %slot600, align 8
  %v3513 = load i64, ptr %slot576, align 8
  %v3514 = load i64, ptr %slot601, align 8
  %cv3515 = trunc i64 %v3514 to i32
  %call3516 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v3511, i64 %v3512, i64 %v3513, i32 %cv3515) nomerge, !dbg !136
  store i32 %call3516, ptr %slot602, align 8
  %v3517 = load i32, ptr %slot602, align 8
  %cv3518 = zext i32 %v3517 to i64
  %cond3519 = icmp ne i64 %cv3518, 0
  br i1 %cond3519, label %bb_rcsuccess801, label %bb_rcfailure801
bb_rcfailure801:
  %v3520 = load i64, ptr %slot45, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %call3522 = call i32 @myl_rc_take_failure(ptr %p3521) nomerge, !dbg !136
  store i32 %call3522, ptr %slot603, align 8
  %v3523 = load i64, ptr %slot1, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %v3525 = load i32, ptr %slot603, align 8
  %call3526 = call i32 @myl_qbe_rc_status(ptr %p3524, i32 %v3525) nomerge, !dbg !136
  store i32 %call3526, ptr %slot604, align 8
  br label %bb_failure
bb_rcsuccess801:
  %v3527 = load i64, ptr %slot19, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  store i32 2, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  %v3529 = load i64, ptr %slot18, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  store i32 1, ptr %p3530, align 4, !alias.scope !3, !noalias !4
  %v3531 = load i64, ptr %slot14, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  %ld3533 = load i32, ptr %p3532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3533, ptr %slot605, align 8
  %v3534 = load i32, ptr %slot605, align 8
  %cv3535 = zext i32 %v3534 to i64
  %cond3536 = icmp ne i64 %cv3535, 0
  br i1 %cond3536, label %bb_rcslotdrop808, label %bb_rcslotdone808
bb_rcslotdrop808:
  %v3537 = load i64, ptr %slot14, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  store i32 0, ptr %p3538, align 4, !alias.scope !3, !noalias !4
  %v3539 = load i64, ptr %slot21, align 8
  store i64 %v3539, ptr %slot606, align 8
  %v3540 = load i64, ptr %slot15, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %ld3542 = load i32, ptr %p3541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3542, ptr %slot607, align 8
  %v3543 = load i32, ptr %slot607, align 8
  %op3544 = and i32 %v3543, 28
  store i32 %op3544, ptr %slot608, align 8
  %v3545 = load i32, ptr %slot608, align 8
  %cv3546 = zext i32 %v3545 to i64
  %cond3547 = icmp ne i64 %cv3546, 0
  br i1 %cond3547, label %bb_rcslotrole808, label %bb_rcslotowner808
bb_rcslotrole808:
  %v3548 = load i64, ptr %slot45, align 8
  store i64 %v3548, ptr %slot609, align 8
  %v3549 = load i64, ptr %slot609, align 8
  %v3550 = load i64, ptr %slot606, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3549, i64 %v3550) nomerge, !dbg !136
  br label %bb_rcslotdone808
bb_rcslotowner808:
  %v3551 = load i64, ptr %slot606, align 8
  %p3553 = inttoptr i64 %v3551 to ptr
  %gep3554 = getelementptr i8, ptr %p3553, i64 8
  %op3552 = ptrtoint ptr %gep3554 to i64
  store i64 %op3552, ptr %slot610, align 8
  %v3555 = load i64, ptr %slot45, align 8
  store i64 %v3555, ptr %slot611, align 8
  %v3556 = load i64, ptr %slot610, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  %ld3558 = load i64, ptr %p3557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3558, ptr %slot612, align 8
  %v3559 = load i64, ptr %slot612, align 8
  %cmp3560 = icmp ne i64 %v3559, 0
  %cv3561 = zext i1 %cmp3560 to i32
  store i32 %cv3561, ptr %slot613, align 8
  %v3562 = load i32, ptr %slot613, align 8
  %cv3563 = zext i32 %v3562 to i64
  %cond3564 = icmp ne i64 %cv3563, 0
  br i1 %cond3564, label %bb_rcgnn826, label %bb_rcgdone826
bb_rcgnn826:
  %v3565 = load i64, ptr %slot612, align 8
  %op3566 = sub i64 %v3565, 16
  store i64 %op3566, ptr %slot614, align 8
  %v3567 = load i64, ptr %slot612, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  %rgep3569 = getelementptr i8, ptr %p3568, i64 -16
  %ld3570 = load i64, ptr %rgep3569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3570, ptr %slot615, align 8
  %v3571 = load i64, ptr %slot615, align 8
  %op3572 = and i64 %v3571, 4611686018427387906
  store i64 %op3572, ptr %slot616, align 8
  %v3573 = load i64, ptr %slot616, align 8
  %cmp3574 = icmp ne i64 %v3573, 0
  %cv3575 = zext i1 %cmp3574 to i32
  store i32 %cv3575, ptr %slot617, align 8
  %v3576 = load i32, ptr %slot617, align 8
  %cv3577 = zext i32 %v3576 to i64
  %cond3578 = icmp ne i64 %cv3577, 0
  br i1 %cond3578, label %bb_rcgclear826, label %bb_rcgcounted826
bb_rcgcounted826:
  %v3579 = load i64, ptr %slot612, align 8
  %op3580 = sub i64 %v3579, 32
  store i64 %op3580, ptr %slot618, align 8
  %v3581 = load i64, ptr %slot612, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %rgep3583 = getelementptr i8, ptr %p3582, i64 -32
  %ld3584 = load i64, ptr %rgep3583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3584, ptr %slot619, align 8
  %v3585 = load i64, ptr %slot619, align 8
  %op3586 = sub i64 %v3585, 1
  store i64 %op3586, ptr %slot620, align 8
  %v3587 = load i64, ptr %slot620, align 8
  %cmp3588 = icmp eq i64 %v3587, 0
  %cv3589 = zext i1 %cmp3588 to i32
  store i32 %cv3589, ptr %slot621, align 8
  %v3590 = load i32, ptr %slot621, align 8
  %cv3591 = zext i32 %v3590 to i64
  %cond3592 = icmp ne i64 %cv3591, 0
  br i1 %cond3592, label %bb_rcglast826, label %bb_rcgdec826
bb_rcglast826:
  %v3593 = load i64, ptr %slot612, align 8
  %op3594 = sub i64 %v3593, 24
  store i64 %op3594, ptr %slot622, align 8
  %v3595 = load i64, ptr %slot612, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %rgep3597 = getelementptr i8, ptr %p3596, i64 -24
  %ld3598 = load i64, ptr %rgep3597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3598, ptr %slot623, align 8
  %v3599 = load i64, ptr %slot623, align 8
  %cmp3600 = icmp ne i64 %v3599, 0
  %cv3601 = zext i1 %cmp3600 to i32
  store i32 %cv3601, ptr %slot624, align 8
  %v3602 = load i32, ptr %slot624, align 8
  %cv3603 = zext i32 %v3602 to i64
  %cond3604 = icmp ne i64 %cv3603, 0
  br i1 %cond3604, label %bb_rcgdec826, label %bb_rcgslow826
bb_rcgslow826:
  %v3605 = load i64, ptr %slot611, align 8
  %v3606 = load i64, ptr %slot610, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3605, i64 %v3606) nomerge, !dbg !136
  br label %bb_rcgdone826
bb_rcgdec826:
  %v3607 = load i64, ptr %slot620, align 8
  %v3608 = load i64, ptr %slot612, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %rgep3610 = getelementptr i8, ptr %p3609, i64 -32
  store i64 %v3607, ptr %rgep3610, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear826
bb_rcgclear826:
  %v3611 = load i64, ptr %slot610, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  store i64 0, ptr %p3612, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone826
bb_rcgdone826:
  %v3613 = load i64, ptr %slot606, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i64 0, ptr %p3614, align 8, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot606, align 8
  %p3617 = inttoptr i64 %v3615 to ptr
  %gep3618 = getelementptr i8, ptr %p3617, i64 8
  %op3616 = ptrtoint ptr %gep3618 to i64
  store i64 %op3616, ptr %slot625, align 8
  %v3619 = load i64, ptr %slot625, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  store i64 0, ptr %p3620, align 8, !alias.scope !3, !noalias !4
  %v3621 = load i64, ptr %slot606, align 8
  %p3623 = inttoptr i64 %v3621 to ptr
  %gep3624 = getelementptr i8, ptr %p3623, i64 16
  %op3622 = ptrtoint ptr %gep3624 to i64
  store i64 %op3622, ptr %slot626, align 8
  %v3625 = load i64, ptr %slot626, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i64 0, ptr %p3626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone808
bb_rcslotdone808:
  br label %bb_rcprepared766
bb_rcprepared766:
  %v3627 = load i64, ptr %slot8, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i32, ptr %p3628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3629, ptr %slot627, align 8
  %v3630 = load i32, ptr %slot627, align 8
  %cv3631 = zext i32 %v3630 to i64
  %cond3632 = icmp ne i64 %cv3631, 0
  br i1 %cond3632, label %bb_rcslotdrop835, label %bb_rcslotdone835
bb_rcslotdrop835:
  %v3633 = load i64, ptr %slot8, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  store i32 0, ptr %p3634, align 4, !alias.scope !3, !noalias !4
  %v3635 = load i64, ptr %slot33, align 8
  store i64 %v3635, ptr %slot628, align 8
  %v3636 = load i64, ptr %slot9, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  %ld3638 = load i32, ptr %p3637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3638, ptr %slot629, align 8
  %v3639 = load i32, ptr %slot629, align 8
  %op3640 = and i32 %v3639, 28
  store i32 %op3640, ptr %slot630, align 8
  %v3641 = load i32, ptr %slot630, align 8
  %cv3642 = zext i32 %v3641 to i64
  %cond3643 = icmp ne i64 %cv3642, 0
  br i1 %cond3643, label %bb_rcslotrole835, label %bb_rcslotowner835
bb_rcslotrole835:
  %v3644 = load i64, ptr %slot45, align 8
  store i64 %v3644, ptr %slot631, align 8
  %v3645 = load i64, ptr %slot631, align 8
  %v3646 = load i64, ptr %slot628, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3645, i64 %v3646) nomerge, !dbg !136
  br label %bb_rcslotdone835
bb_rcslotowner835:
  %v3647 = load i64, ptr %slot628, align 8
  %p3649 = inttoptr i64 %v3647 to ptr
  %gep3650 = getelementptr i8, ptr %p3649, i64 8
  %op3648 = ptrtoint ptr %gep3650 to i64
  store i64 %op3648, ptr %slot632, align 8
  %v3651 = load i64, ptr %slot45, align 8
  store i64 %v3651, ptr %slot633, align 8
  %v3652 = load i64, ptr %slot632, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %ld3654 = load i64, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3654, ptr %slot634, align 8
  %v3655 = load i64, ptr %slot634, align 8
  %cmp3656 = icmp ne i64 %v3655, 0
  %cv3657 = zext i1 %cmp3656 to i32
  store i32 %cv3657, ptr %slot635, align 8
  %v3658 = load i32, ptr %slot635, align 8
  %cv3659 = zext i32 %v3658 to i64
  %cond3660 = icmp ne i64 %cv3659, 0
  br i1 %cond3660, label %bb_rcgnn853, label %bb_rcgdone853
bb_rcgnn853:
  %v3661 = load i64, ptr %slot634, align 8
  %op3662 = sub i64 %v3661, 16
  store i64 %op3662, ptr %slot636, align 8
  %v3663 = load i64, ptr %slot634, align 8
  %p3664 = inttoptr i64 %v3663 to ptr
  %rgep3665 = getelementptr i8, ptr %p3664, i64 -16
  %ld3666 = load i64, ptr %rgep3665, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3666, ptr %slot637, align 8
  %v3667 = load i64, ptr %slot637, align 8
  %op3668 = and i64 %v3667, 4611686018427387906
  store i64 %op3668, ptr %slot638, align 8
  %v3669 = load i64, ptr %slot638, align 8
  %cmp3670 = icmp ne i64 %v3669, 0
  %cv3671 = zext i1 %cmp3670 to i32
  store i32 %cv3671, ptr %slot639, align 8
  %v3672 = load i32, ptr %slot639, align 8
  %cv3673 = zext i32 %v3672 to i64
  %cond3674 = icmp ne i64 %cv3673, 0
  br i1 %cond3674, label %bb_rcgclear853, label %bb_rcgcounted853
bb_rcgcounted853:
  %v3675 = load i64, ptr %slot634, align 8
  %op3676 = sub i64 %v3675, 32
  store i64 %op3676, ptr %slot640, align 8
  %v3677 = load i64, ptr %slot634, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %rgep3679 = getelementptr i8, ptr %p3678, i64 -32
  %ld3680 = load i64, ptr %rgep3679, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3680, ptr %slot641, align 8
  %v3681 = load i64, ptr %slot641, align 8
  %op3682 = sub i64 %v3681, 1
  store i64 %op3682, ptr %slot642, align 8
  %v3683 = load i64, ptr %slot642, align 8
  %cmp3684 = icmp eq i64 %v3683, 0
  %cv3685 = zext i1 %cmp3684 to i32
  store i32 %cv3685, ptr %slot643, align 8
  %v3686 = load i32, ptr %slot643, align 8
  %cv3687 = zext i32 %v3686 to i64
  %cond3688 = icmp ne i64 %cv3687, 0
  br i1 %cond3688, label %bb_rcglast853, label %bb_rcgdec853
bb_rcglast853:
  %v3689 = load i64, ptr %slot634, align 8
  %op3690 = sub i64 %v3689, 24
  store i64 %op3690, ptr %slot644, align 8
  %v3691 = load i64, ptr %slot634, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  %rgep3693 = getelementptr i8, ptr %p3692, i64 -24
  %ld3694 = load i64, ptr %rgep3693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3694, ptr %slot645, align 8
  %v3695 = load i64, ptr %slot645, align 8
  %cmp3696 = icmp ne i64 %v3695, 0
  %cv3697 = zext i1 %cmp3696 to i32
  store i32 %cv3697, ptr %slot646, align 8
  %v3698 = load i32, ptr %slot646, align 8
  %cv3699 = zext i32 %v3698 to i64
  %cond3700 = icmp ne i64 %cv3699, 0
  br i1 %cond3700, label %bb_rcgdec853, label %bb_rcgslow853
bb_rcgslow853:
  %v3701 = load i64, ptr %slot633, align 8
  %v3702 = load i64, ptr %slot632, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v3701, i64 %v3702) nomerge, !dbg !136
  br label %bb_rcgdone853
bb_rcgdec853:
  %v3703 = load i64, ptr %slot642, align 8
  %v3704 = load i64, ptr %slot634, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %rgep3706 = getelementptr i8, ptr %p3705, i64 -32
  store i64 %v3703, ptr %rgep3706, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear853
bb_rcgclear853:
  %v3707 = load i64, ptr %slot632, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  store i64 0, ptr %p3708, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone853
bb_rcgdone853:
  %v3709 = load i64, ptr %slot628, align 8
  %p3710 = inttoptr i64 %v3709 to ptr
  store i64 0, ptr %p3710, align 8, !alias.scope !3, !noalias !4
  %v3711 = load i64, ptr %slot628, align 8
  %p3713 = inttoptr i64 %v3711 to ptr
  %gep3714 = getelementptr i8, ptr %p3713, i64 8
  %op3712 = ptrtoint ptr %gep3714 to i64
  store i64 %op3712, ptr %slot647, align 8
  %v3715 = load i64, ptr %slot647, align 8
  %p3716 = inttoptr i64 %v3715 to ptr
  store i64 0, ptr %p3716, align 8, !alias.scope !3, !noalias !4
  %v3717 = load i64, ptr %slot628, align 8
  %p3719 = inttoptr i64 %v3717 to ptr
  %gep3720 = getelementptr i8, ptr %p3719, i64 16
  %op3718 = ptrtoint ptr %gep3720 to i64
  store i64 %op3718, ptr %slot648, align 8
  %v3721 = load i64, ptr %slot648, align 8
  %p3722 = inttoptr i64 %v3721 to ptr
  store i64 0, ptr %p3722, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone835
bb_rcslotdone835:
  %v3723 = load i64, ptr %slot33, align 8
  store i64 %v3723, ptr %slot649, align 8
  %v3724 = load i64, ptr %slot23, align 8
  store i64 %v3724, ptr %slot650, align 8
  %v3725 = load i64, ptr %slot650, align 8
  %v3726 = load i64, ptr %slot649, align 8
  %p3727 = inttoptr i64 %v3725 to ptr
  %p3728 = inttoptr i64 %v3726 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3728, ptr %p3727, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3729 = load i64, ptr %slot18, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i32 0, ptr %p3730, align 4, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot9, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  store i32 2, ptr %p3732, align 4, !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot19, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  %ld3735 = load i32, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3735, ptr %slot651, align 8
  %v3736 = load i32, ptr %slot651, align 8
  %v3737 = load i64, ptr %slot9, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  store i32 %v3736, ptr %p3738, align 4, !alias.scope !3, !noalias !4
  %v3739 = load i64, ptr %slot8, align 8
  %p3740 = inttoptr i64 %v3739 to ptr
  store i32 1, ptr %p3740, align 4, !alias.scope !3, !noalias !4
  %v3741 = load i64, ptr %slot39, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  store i64 0, ptr %p3742, align 8, !alias.scope !3, !noalias !4
  %v3743 = load i64, ptr %slot33, align 8
  %v3744 = load i64, ptr %slot42, align 8
  %p3745 = inttoptr i64 %v3743 to ptr
  %p3746 = inttoptr i64 %v3744 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3746, ptr %p3745, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3747 = load i64, ptr %slot42, align 8
  %v3748 = load i64, ptr %slot39, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  store i64 %v3747, ptr %p3749, align 8, !alias.scope !3, !noalias !4
  %v3750 = load i64, ptr %slot43, align 8
  store i64 %v3750, ptr %slot652, align 8
  %v3751 = load i64, ptr %slot652, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  store i64 0, ptr %p3752, align 8, !alias.scope !3, !noalias !4
  %v3753 = load i64, ptr %slot652, align 8
  %p3755 = inttoptr i64 %v3753 to ptr
  %gep3756 = getelementptr i8, ptr %p3755, i64 8
  %op3754 = ptrtoint ptr %gep3756 to i64
  store i64 %op3754, ptr %slot653, align 8
  %v3757 = load i64, ptr %slot653, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  store i64 0, ptr %p3758, align 8, !alias.scope !3, !noalias !4
  %v3759 = load i64, ptr %slot652, align 8
  %p3761 = inttoptr i64 %v3759 to ptr
  %gep3762 = getelementptr i8, ptr %p3761, i64 16
  %op3760 = ptrtoint ptr %gep3762 to i64
  store i64 %op3760, ptr %slot654, align 8
  %v3763 = load i64, ptr %slot654, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  store i64 0, ptr %p3764, align 8, !alias.scope !3, !noalias !4
  %v3765 = load i64, ptr %slot652, align 8
  %p3767 = inttoptr i64 %v3765 to ptr
  %gep3768 = getelementptr i8, ptr %p3767, i64 24
  %op3766 = ptrtoint ptr %gep3768 to i64
  store i64 %op3766, ptr %slot655, align 8
  %v3769 = load i64, ptr %slot655, align 8
  %p3770 = inttoptr i64 %v3769 to ptr
  store i64 0, ptr %p3770, align 8, !alias.scope !3, !noalias !4
  %v3771 = load i64, ptr %slot652, align 8
  %p3773 = inttoptr i64 %v3771 to ptr
  %gep3774 = getelementptr i8, ptr %p3773, i64 32
  %op3772 = ptrtoint ptr %gep3774 to i64
  store i64 %op3772, ptr %slot656, align 8
  %v3775 = load i64, ptr %slot656, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  store i64 0, ptr %p3776, align 8, !alias.scope !3, !noalias !4
  %v3777 = load i64, ptr %slot652, align 8
  %p3779 = inttoptr i64 %v3777 to ptr
  %gep3780 = getelementptr i8, ptr %p3779, i64 40
  %op3778 = ptrtoint ptr %gep3780 to i64
  store i64 %op3778, ptr %slot657, align 8
  %v3781 = load i64, ptr %slot657, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  store i64 0, ptr %p3782, align 8, !alias.scope !3, !noalias !4
  %v3783 = load i64, ptr %slot652, align 8
  %p3785 = inttoptr i64 %v3783 to ptr
  %gep3786 = getelementptr i8, ptr %p3785, i64 48
  %op3784 = ptrtoint ptr %gep3786 to i64
  store i64 %op3784, ptr %slot658, align 8
  %v3787 = load i64, ptr %slot658, align 8
  %p3788 = inttoptr i64 %v3787 to ptr
  store i64 0, ptr %p3788, align 8, !alias.scope !3, !noalias !4
  %v3789 = load i64, ptr %slot652, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  store i32 7, ptr %p3790, align 4, !alias.scope !3, !noalias !4
  %v3791 = load i64, ptr %slot20, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  store i32 1, ptr %p3792, align 4, !alias.scope !3, !noalias !4
  %v3793 = load i64, ptr %slot39, align 8
  %p3794 = inttoptr i64 %v3793 to ptr
  %ld3795 = load i64, ptr %p3794, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3795, ptr %slot659, align 8
  %v3796 = load i64, ptr %slot652, align 8
  %p3798 = inttoptr i64 %v3796 to ptr
  %gep3799 = getelementptr i8, ptr %p3798, i64 8
  %op3797 = ptrtoint ptr %gep3799 to i64
  store i64 %op3797, ptr %slot660, align 8
  %v3800 = load i64, ptr %slot46, align 8
  store i64 %v3800, ptr %slot661, align 8
  %v3801 = load i64, ptr %slot39, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  %ld3803 = load i64, ptr %p3802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3803, ptr %slot662, align 8
  %v3804 = load i64, ptr %slot14, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %ld3806 = load i32, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3806, ptr %slot663, align 8
  %v3807 = load i64, ptr %slot15, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %ld3809 = load i32, ptr %p3808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3809, ptr %slot664, align 8
  %v3810 = load i32, ptr %slot664, align 8
  %op3811 = and i32 %v3810, 24
  store i32 %op3811, ptr %slot664, align 8
  %v3812 = load i32, ptr %slot664, align 8
  %cmp3813 = icmp eq i32 %v3812, 0
  %cv3814 = zext i1 %cmp3813 to i32
  store i32 %cv3814, ptr %slot665, align 8
  %v3815 = load i32, ptr %slot663, align 8
  %v3816 = load i32, ptr %slot665, align 8
  %op3817 = and i32 %v3815, %v3816
  store i32 %op3817, ptr %slot666, align 8
  %v3818 = load i32, ptr %slot666, align 8
  %cv3819 = zext i32 %v3818 to i64
  %cond3820 = icmp ne i64 %cv3819, 0
  br i1 %cond3820, label %bb_rctake879, label %bb_rccopy879
bb_rctake879:
  %v3821 = load i64, ptr %slot23, align 8
  store i64 %v3821, ptr %slot667, align 8
  %v3822 = load i64, ptr %slot46, align 8
  store i64 %v3822, ptr %slot668, align 8
  %v3823 = load i64, ptr %slot662, align 8
  %v3824 = load i64, ptr %slot667, align 8
  %op3825 = sub i64 %v3823, %v3824
  store i64 %op3825, ptr %slot669, align 8
  %v3826 = load i64, ptr %slot667, align 8
  %v3827 = load i64, ptr %slot662, align 8
  %op3828 = sub i64 %v3826, %v3827
  store i64 %op3828, ptr %slot670, align 8
  %v3829 = load i64, ptr %slot669, align 8
  %cmp3830 = icmp ult i64 %v3829, 24
  %cv3831 = zext i1 %cmp3830 to i32
  store i32 %cv3831, ptr %slot671, align 8
  %v3832 = load i64, ptr %slot670, align 8
  %cmp3833 = icmp ult i64 %v3832, 24
  %cv3834 = zext i1 %cmp3833 to i32
  store i32 %cv3834, ptr %slot672, align 8
  %v3835 = load i32, ptr %slot671, align 8
  %v3836 = load i32, ptr %slot672, align 8
  %op3837 = or i32 %v3835, %v3836
  store i32 %op3837, ptr %slot673, align 8
  %v3838 = load i32, ptr %slot673, align 8
  %cv3839 = zext i32 %v3838 to i64
  %cond3840 = icmp ne i64 %cv3839, 0
  br i1 %cond3840, label %bb_rcmoveslow888, label %bb_rcmovecheck888
bb_rcmovecheck888:
  %v3841 = load i64, ptr %slot662, align 8
  %op3842 = add i64 %v3841, 8
  store i64 %op3842, ptr %slot674, align 8
  %v3843 = load i64, ptr %slot674, align 8
  %p3844 = inttoptr i64 %v3843 to ptr
  %ld3845 = load i64, ptr %p3844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3845, ptr %slot675, align 8
  %v3846 = load i64, ptr %slot675, align 8
  %cmp3847 = icmp ne i64 %v3846, 0
  %cv3848 = zext i1 %cmp3847 to i32
  store i32 %cv3848, ptr %slot676, align 8
  %v3849 = load i32, ptr %slot676, align 8
  %cv3850 = zext i32 %v3849 to i64
  %cond3851 = icmp ne i64 %cv3850, 0
  br i1 %cond3851, label %bb_rcmoveheader896, label %bb_rcmovenext896
bb_rcmoveheader896:
  %v3852 = load i64, ptr %slot675, align 8
  %op3853 = sub i64 %v3852, 16
  store i64 %op3853, ptr %slot677, align 8
  %v3854 = load i64, ptr %slot675, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  %rgep3856 = getelementptr i8, ptr %p3855, i64 -16
  %ld3857 = load i64, ptr %rgep3856, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3857, ptr %slot678, align 8
  %v3858 = load i64, ptr %slot678, align 8
  %op3859 = and i64 %v3858, 5764607523034234881
  store i64 %op3859, ptr %slot679, align 8
  %v3860 = load i64, ptr %slot679, align 8
  %cmp3861 = icmp ne i64 %v3860, 0
  %cv3862 = zext i1 %cmp3861 to i32
  store i32 %cv3862, ptr %slot680, align 8
  %v3863 = load i32, ptr %slot680, align 8
  %cv3864 = zext i32 %v3863 to i64
  %cond3865 = icmp ne i64 %cv3864, 0
  br i1 %cond3865, label %bb_rcmoveslow888, label %bb_rcmovenext896
bb_rcmovenext896:
  %v3866 = load i64, ptr %slot662, align 8
  %v3867 = load i64, ptr %slot667, align 8
  %p3868 = inttoptr i64 %v3866 to ptr
  %p3869 = inttoptr i64 %v3867 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3869, ptr %p3868, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3870 = load i64, ptr %slot662, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  store i64 0, ptr %p3871, align 8, !alias.scope !3, !noalias !4
  %v3872 = load i64, ptr %slot662, align 8
  %op3873 = add i64 %v3872, 8
  store i64 %op3873, ptr %slot681, align 8
  %v3874 = load i64, ptr %slot681, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  store i64 0, ptr %p3875, align 8, !alias.scope !3, !noalias !4
  %v3876 = load i64, ptr %slot662, align 8
  %op3877 = add i64 %v3876, 16
  store i64 %op3877, ptr %slot682, align 8
  %v3878 = load i64, ptr %slot682, align 8
  %p3879 = inttoptr i64 %v3878 to ptr
  store i64 0, ptr %p3879, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved888
bb_rcmoveslow888:
  %v3880 = load i64, ptr %slot45, align 8
  %v3881 = load i64, ptr %slot667, align 8
  %v3882 = load i64, ptr %slot662, align 8
  %v3883 = load i64, ptr %slot668, align 8
  %cv3884 = trunc i64 %v3883 to i32
  %call3885 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v3880, i64 %v3881, i64 %v3882, i32 %cv3884) nomerge, !dbg !138
  store i32 %call3885, ptr %slot683, align 8
  %v3886 = load i32, ptr %slot683, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcsuccess905, label %bb_rcfailure905
bb_rcfailure905:
  %v3889 = load i64, ptr %slot45, align 8
  %p3890 = inttoptr i64 %v3889 to ptr
  %call3891 = call i32 @myl_rc_take_failure(ptr %p3890) nomerge, !dbg !138
  store i32 %call3891, ptr %slot684, align 8
  %v3892 = load i64, ptr %slot1, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %v3894 = load i32, ptr %slot684, align 8
  %call3895 = call i32 @myl_qbe_rc_status(ptr %p3893, i32 %v3894) nomerge, !dbg !138
  store i32 %call3895, ptr %slot685, align 8
  br label %bb_failure
bb_rcsuccess905:
  br label %bb_rcmoved888
bb_rcmoved888:
  %v3896 = load i64, ptr %slot14, align 8
  %p3897 = inttoptr i64 %v3896 to ptr
  store i32 0, ptr %p3897, align 4, !alias.scope !3, !noalias !4
  %v3898 = load i64, ptr %slot19, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  store i32 2, ptr %p3899, align 4, !alias.scope !3, !noalias !4
  %v3900 = load i64, ptr %slot18, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  store i32 1, ptr %p3901, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared879
bb_rccopy879:
  %v3902 = load i64, ptr %slot23, align 8
  store i64 %v3902, ptr %slot686, align 8
  %v3903 = load i64, ptr %slot46, align 8
  store i64 %v3903, ptr %slot687, align 8
  %v3904 = load i64, ptr %slot45, align 8
  %v3905 = load i64, ptr %slot686, align 8
  %v3906 = load i64, ptr %slot662, align 8
  %v3907 = load i64, ptr %slot687, align 8
  %cv3908 = trunc i64 %v3907 to i32
  %call3909 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64 %v3904, i64 %v3905, i64 %v3906, i32 %cv3908) nomerge, !dbg !138
  store i32 %call3909, ptr %slot688, align 8
  %v3910 = load i32, ptr %slot688, align 8
  %cv3911 = zext i32 %v3910 to i64
  %cond3912 = icmp ne i64 %cv3911, 0
  br i1 %cond3912, label %bb_rcsuccess914, label %bb_rcfailure914
bb_rcfailure914:
  %v3913 = load i64, ptr %slot45, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %call3915 = call i32 @myl_rc_take_failure(ptr %p3914) nomerge, !dbg !138
  store i32 %call3915, ptr %slot689, align 8
  %v3916 = load i64, ptr %slot1, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  %v3918 = load i32, ptr %slot689, align 8
  %call3919 = call i32 @myl_qbe_rc_status(ptr %p3917, i32 %v3918) nomerge, !dbg !138
  store i32 %call3919, ptr %slot690, align 8
  br label %bb_failure
bb_rcsuccess914:
  %v3920 = load i64, ptr %slot19, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i32 2, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot18, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  store i32 1, ptr %p3923, align 4, !alias.scope !3, !noalias !4
  %v3924 = load i64, ptr %slot14, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %ld3926 = load i32, ptr %p3925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3926, ptr %slot691, align 8
  %v3927 = load i32, ptr %slot691, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rcslotdrop921, label %bb_rcslotdone921
bb_rcslotdrop921:
  %v3930 = load i64, ptr %slot14, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  store i32 0, ptr %p3931, align 4, !alias.scope !3, !noalias !4
  %v3932 = load i64, ptr %slot21, align 8
  store i64 %v3932, ptr %slot692, align 8
  %v3933 = load i64, ptr %slot15, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %ld3935 = load i32, ptr %p3934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3935, ptr %slot693, align 8
  %v3936 = load i32, ptr %slot693, align 8
  %op3937 = and i32 %v3936, 28
  store i32 %op3937, ptr %slot694, align 8
  %v3938 = load i32, ptr %slot694, align 8
  %cv3939 = zext i32 %v3938 to i64
  %cond3940 = icmp ne i64 %cv3939, 0
  br i1 %cond3940, label %bb_rcslotrole921, label %bb_rcslotowner921
bb_rcslotrole921:
  %v3941 = load i64, ptr %slot45, align 8
  store i64 %v3941, ptr %slot695, align 8
  %v3942 = load i64, ptr %slot695, align 8
  %v3943 = load i64, ptr %slot692, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v3942, i64 %v3943) nomerge, !dbg !138
  br label %bb_rcslotdone921
bb_rcslotowner921:
  %v3944 = load i64, ptr %slot45, align 8
  store i64 %v3944, ptr %slot696, align 8
  %v3945 = load i64, ptr %slot696, align 8
  %v3946 = load i64, ptr %slot692, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v3945, i64 %v3946) nomerge, !dbg !138
  br label %bb_rcslotdone921
bb_rcslotdone921:
  br label %bb_rcprepared879
bb_rcprepared879:
  %v3947 = load i64, ptr %slot23, align 8
  store i64 %v3947, ptr %slot697, align 8
  %v3948 = load i64, ptr %slot697, align 8
  %v3949 = load i64, ptr %slot660, align 8
  %p3950 = inttoptr i64 %v3948 to ptr
  %p3951 = inttoptr i64 %v3949 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3951, ptr %p3950, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3952 = load i64, ptr %slot18, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  store i32 0, ptr %p3953, align 4, !alias.scope !3, !noalias !4
  %v3954 = load i64, ptr %slot652, align 8
  %v3955 = load i64, ptr %slot39, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  store i64 %v3954, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  %v3957 = load i64, ptr %slot39, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i64, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3959, ptr %slot698, align 8
  %v3960 = load i64, ptr %slot21, align 8
  store i64 %v3960, ptr %slot699, align 8
  %v3961 = load i64, ptr %slot698, align 8
  %v3962 = load i64, ptr %slot699, align 8
  %p3963 = inttoptr i64 %v3961 to ptr
  %p3964 = inttoptr i64 %v3962 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3964, ptr %p3963, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot15, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  store i32 2, ptr %p3966, align 4, !alias.scope !3, !noalias !4
  %v3967 = load i64, ptr %slot14, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  store i32 1, ptr %p3968, align 4, !alias.scope !3, !noalias !4
  %v3969 = load i64, ptr %slot699, align 8
  %v3970 = load i64, ptr %slot39, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i64 %v3969, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  %v3972 = load i64, ptr %slot39, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  %ld3974 = load i64, ptr %p3973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3974, ptr %slot700, align 8
  %v3975 = load i64, ptr %slot14, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  %ld3977 = load i32, ptr %p3976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3977, ptr %slot701, align 8
  %v3978 = load i64, ptr %slot15, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  %ld3980 = load i32, ptr %p3979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3980, ptr %slot702, align 8
  %v3981 = load i32, ptr %slot702, align 8
  %op3982 = and i32 %v3981, 24
  store i32 %op3982, ptr %slot702, align 8
  %v3983 = load i32, ptr %slot702, align 8
  %cmp3984 = icmp eq i32 %v3983, 0
  %cv3985 = zext i1 %cmp3984 to i32
  store i32 %cv3985, ptr %slot703, align 8
  %v3986 = load i32, ptr %slot701, align 8
  %v3987 = load i32, ptr %slot703, align 8
  %op3988 = and i32 %v3986, %v3987
  store i32 %op3988, ptr %slot704, align 8
  %v3989 = load i32, ptr %slot704, align 8
  %cv3990 = zext i32 %v3989 to i64
  %cond3991 = icmp ne i64 %cv3990, 0
  br i1 %cond3991, label %bb_rcprivateown941, label %bb_rcprivateloan941
bb_rcprivateown941:
  %v3992 = load i64, ptr %slot23, align 8
  store i64 %v3992, ptr %slot705, align 8
  %v3993 = load i64, ptr %slot46, align 8
  store i64 %v3993, ptr %slot706, align 8
  %v3994 = load i64, ptr %slot45, align 8
  %v3995 = load i64, ptr %slot705, align 8
  %v3996 = load i64, ptr %slot700, align 8
  %v3997 = load i64, ptr %slot706, align 8
  %cv3998 = trunc i64 %v3997 to i32
  %call3999 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v3994, i64 %v3995, i64 %v3996, i32 %cv3998) nomerge, !dbg !140
  store i32 %call3999, ptr %slot707, align 8
  %v4000 = load i32, ptr %slot707, align 8
  %cv4001 = zext i32 %v4000 to i64
  %cond4002 = icmp ne i64 %cv4001, 0
  br i1 %cond4002, label %bb_rcsuccess945, label %bb_rcfailure945
bb_rcfailure945:
  %v4003 = load i64, ptr %slot45, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %call4005 = call i32 @myl_rc_take_failure(ptr %p4004) nomerge, !dbg !140
  store i32 %call4005, ptr %slot708, align 8
  %v4006 = load i64, ptr %slot1, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  %v4008 = load i32, ptr %slot708, align 8
  %call4009 = call i32 @myl_qbe_rc_status(ptr %p4007, i32 %v4008) nomerge, !dbg !140
  store i32 %call4009, ptr %slot709, align 8
  br label %bb_failure
bb_rcsuccess945:
  %v4010 = load i64, ptr %slot14, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  store i32 0, ptr %p4011, align 4, !alias.scope !3, !noalias !4
  %v4012 = load i64, ptr %slot19, align 8
  %p4013 = inttoptr i64 %v4012 to ptr
  store i32 2, ptr %p4013, align 4, !alias.scope !3, !noalias !4
  %v4014 = load i64, ptr %slot18, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  store i32 1, ptr %p4015, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared941
bb_rcprivateloan941:
  %v4016 = load i64, ptr %slot14, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %ld4018 = load i32, ptr %p4017, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4018, ptr %slot710, align 8
  %v4019 = load i64, ptr %slot15, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %ld4021 = load i32, ptr %p4020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4021, ptr %slot711, align 8
  %v4022 = load i32, ptr %slot711, align 8
  %cmp4023 = icmp eq i32 %v4022, 16
  %cv4024 = zext i1 %cmp4023 to i32
  store i32 %cv4024, ptr %slot712, align 8
  %v4025 = load i32, ptr %slot712, align 8
  %v4026 = load i32, ptr %slot710, align 8
  %op4027 = and i32 %v4025, %v4026
  store i32 %op4027, ptr %slot712, align 8
  %v4028 = load i32, ptr %slot712, align 8
  %cv4029 = zext i32 %v4028 to i64
  %cond4030 = icmp ne i64 %cv4029, 0
  br i1 %cond4030, label %bb_rcprivatemove941, label %bb_rcprivatenew941
bb_rcprivatemove941:
  %v4031 = load i64, ptr %slot23, align 8
  store i64 %v4031, ptr %slot713, align 8
  %v4032 = load i64, ptr %slot700, align 8
  %v4033 = load i64, ptr %slot713, align 8
  %p4034 = inttoptr i64 %v4032 to ptr
  %p4035 = inttoptr i64 %v4033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4035, ptr %p4034, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4036 = load i64, ptr %slot700, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  call void @llvm.memset.p0.i64(ptr %p4037, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v4038 = load i64, ptr %slot19, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  store i32 2, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  %v4040 = load i64, ptr %slot19, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  store i32 16, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  %v4042 = load i64, ptr %slot18, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  store i32 1, ptr %p4043, align 4, !alias.scope !3, !noalias !4
  %v4044 = load i64, ptr %slot14, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i32 0, ptr %p4045, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared941
bb_rcprivatenew941:
  %v4046 = load i64, ptr %slot23, align 8
  store i64 %v4046, ptr %slot714, align 8
  %v4047 = load i64, ptr %slot45, align 8
  %v4048 = load i64, ptr %slot714, align 8
  %v4049 = load i64, ptr %slot700, align 8
  %call4050 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v4047, i64 %v4048, i64 %v4049) nomerge, !dbg !140
  store i32 %call4050, ptr %slot715, align 8
  %v4051 = load i32, ptr %slot715, align 8
  %cv4052 = zext i32 %v4051 to i64
  %cond4053 = icmp ne i64 %cv4052, 0
  br i1 %cond4053, label %bb_rcsuccess963, label %bb_rcfailure963
bb_rcfailure963:
  %v4054 = load i64, ptr %slot45, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  %call4056 = call i32 @myl_rc_take_failure(ptr %p4055) nomerge, !dbg !140
  store i32 %call4056, ptr %slot716, align 8
  %v4057 = load i64, ptr %slot1, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %v4059 = load i32, ptr %slot716, align 8
  %call4060 = call i32 @myl_qbe_rc_status(ptr %p4058, i32 %v4059) nomerge, !dbg !140
  store i32 %call4060, ptr %slot717, align 8
  br label %bb_failure
bb_rcsuccess963:
  %v4061 = load i64, ptr %slot19, align 8
  %p4062 = inttoptr i64 %v4061 to ptr
  store i32 2, ptr %p4062, align 4, !alias.scope !3, !noalias !4
  %v4063 = load i64, ptr %slot19, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  store i32 16, ptr %p4064, align 4, !alias.scope !3, !noalias !4
  %v4065 = load i64, ptr %slot18, align 8
  %p4066 = inttoptr i64 %v4065 to ptr
  store i32 1, ptr %p4066, align 4, !alias.scope !3, !noalias !4
  %v4067 = load i64, ptr %slot14, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  %ld4069 = load i32, ptr %p4068, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4069, ptr %slot718, align 8
  %v4070 = load i32, ptr %slot718, align 8
  %cv4071 = zext i32 %v4070 to i64
  %cond4072 = icmp ne i64 %cv4071, 0
  br i1 %cond4072, label %bb_rcslotdrop971, label %bb_rcslotdone971
bb_rcslotdrop971:
  %v4073 = load i64, ptr %slot14, align 8
  %p4074 = inttoptr i64 %v4073 to ptr
  store i32 0, ptr %p4074, align 4, !alias.scope !3, !noalias !4
  %v4075 = load i64, ptr %slot21, align 8
  store i64 %v4075, ptr %slot719, align 8
  %v4076 = load i64, ptr %slot15, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  %ld4078 = load i32, ptr %p4077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4078, ptr %slot720, align 8
  %v4079 = load i32, ptr %slot720, align 8
  %op4080 = and i32 %v4079, 28
  store i32 %op4080, ptr %slot721, align 8
  %v4081 = load i32, ptr %slot721, align 8
  %cv4082 = zext i32 %v4081 to i64
  %cond4083 = icmp ne i64 %cv4082, 0
  br i1 %cond4083, label %bb_rcslotrole971, label %bb_rcslotowner971
bb_rcslotrole971:
  %v4084 = load i64, ptr %slot45, align 8
  store i64 %v4084, ptr %slot722, align 8
  %v4085 = load i64, ptr %slot722, align 8
  %v4086 = load i64, ptr %slot719, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4085, i64 %v4086) nomerge, !dbg !140
  br label %bb_rcslotdone971
bb_rcslotowner971:
  %v4087 = load i64, ptr %slot45, align 8
  store i64 %v4087, ptr %slot723, align 8
  %v4088 = load i64, ptr %slot723, align 8
  %v4089 = load i64, ptr %slot719, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4088, i64 %v4089) nomerge, !dbg !140
  br label %bb_rcslotdone971
bb_rcslotdone971:
  br label %bb_rcprivateprepared941
bb_rcprivateprepared941:
  %v4090 = load i64, ptr %slot12, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %ld4092 = load i32, ptr %p4091, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4092, ptr %slot724, align 8
  %v4093 = load i32, ptr %slot724, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcslotdrop981, label %bb_rcslotdone981
bb_rcslotdrop981:
  %v4096 = load i64, ptr %slot12, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  store i32 0, ptr %p4097, align 4, !alias.scope !3, !noalias !4
  %v4098 = load i64, ptr %slot37, align 8
  store i64 %v4098, ptr %slot725, align 8
  %v4099 = load i64, ptr %slot13, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  %ld4101 = load i32, ptr %p4100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4101, ptr %slot726, align 8
  %v4102 = load i32, ptr %slot726, align 8
  %op4103 = and i32 %v4102, 28
  store i32 %op4103, ptr %slot727, align 8
  %v4104 = load i32, ptr %slot727, align 8
  %cv4105 = zext i32 %v4104 to i64
  %cond4106 = icmp ne i64 %cv4105, 0
  br i1 %cond4106, label %bb_rcslotrole981, label %bb_rcslotowner981
bb_rcslotrole981:
  %v4107 = load i64, ptr %slot45, align 8
  store i64 %v4107, ptr %slot728, align 8
  %v4108 = load i64, ptr %slot728, align 8
  %v4109 = load i64, ptr %slot725, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4108, i64 %v4109) nomerge, !dbg !140
  br label %bb_rcslotdone981
bb_rcslotowner981:
  %v4110 = load i64, ptr %slot45, align 8
  store i64 %v4110, ptr %slot729, align 8
  %v4111 = load i64, ptr %slot729, align 8
  %v4112 = load i64, ptr %slot725, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4111, i64 %v4112) nomerge, !dbg !140
  br label %bb_rcslotdone981
bb_rcslotdone981:
  %v4113 = load i64, ptr %slot37, align 8
  store i64 %v4113, ptr %slot730, align 8
  %v4114 = load i64, ptr %slot23, align 8
  store i64 %v4114, ptr %slot731, align 8
  %v4115 = load i64, ptr %slot731, align 8
  %v4116 = load i64, ptr %slot730, align 8
  %p4117 = inttoptr i64 %v4115 to ptr
  %p4118 = inttoptr i64 %v4116 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4118, ptr %p4117, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4119 = load i64, ptr %slot18, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  store i32 0, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  %v4121 = load i64, ptr %slot13, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  store i32 2, ptr %p4122, align 4, !alias.scope !3, !noalias !4
  %v4123 = load i64, ptr %slot19, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  %ld4125 = load i32, ptr %p4124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4125, ptr %slot732, align 8
  %v4126 = load i32, ptr %slot732, align 8
  %v4127 = load i64, ptr %slot13, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  store i32 %v4126, ptr %p4128, align 4, !alias.scope !3, !noalias !4
  %v4129 = load i64, ptr %slot12, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  store i32 1, ptr %p4130, align 4, !alias.scope !3, !noalias !4
  %v4131 = load i64, ptr %slot27, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ld4133 = load i64, ptr %p4132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4133, ptr %slot733, align 8
  %v4134 = load i64, ptr %slot733, align 8
  %v4135 = load i64, ptr %slot39, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  store i64 %v4134, ptr %p4136, align 8, !alias.scope !3, !noalias !4
  %v4137 = load i64, ptr %slot39, align 8
  %p4138 = inttoptr i64 %v4137 to ptr
  %ld4139 = load i64, ptr %p4138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4139, ptr %slot734, align 8
  %v4140 = load i64, ptr %slot734, align 8
  %op4141 = add i64 %v4140, 0
  store i64 %op4141, ptr %slot735, align 8
  %v4142 = load i64, ptr %slot735, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %ld4144 = load i64, ptr %p4143, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4144, ptr %slot736, align 8
  %v4145 = load i64, ptr %slot736, align 8
  %v4146 = load i64, ptr %slot39, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  store i64 %v4145, ptr %p4147, align 8, !alias.scope !3, !noalias !4
  %v4148 = load i64, ptr %slot14, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  %ld4150 = load i32, ptr %p4149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4150, ptr %slot737, align 8
  %v4151 = load i32, ptr %slot737, align 8
  %cv4152 = zext i32 %v4151 to i64
  %cond4153 = icmp ne i64 %cv4152, 0
  br i1 %cond4153, label %bb_rcslotdrop1001, label %bb_rcslotdone1001
bb_rcslotdrop1001:
  %v4154 = load i64, ptr %slot14, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  store i32 0, ptr %p4155, align 4, !alias.scope !3, !noalias !4
  %v4156 = load i64, ptr %slot21, align 8
  store i64 %v4156, ptr %slot738, align 8
  %v4157 = load i64, ptr %slot15, align 8
  %p4158 = inttoptr i64 %v4157 to ptr
  %ld4159 = load i32, ptr %p4158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4159, ptr %slot739, align 8
  %v4160 = load i32, ptr %slot739, align 8
  %op4161 = and i32 %v4160, 28
  store i32 %op4161, ptr %slot740, align 8
  %v4162 = load i32, ptr %slot740, align 8
  %cv4163 = zext i32 %v4162 to i64
  %cond4164 = icmp ne i64 %cv4163, 0
  br i1 %cond4164, label %bb_rcslotrole1001, label %bb_rcslotowner1001
bb_rcslotrole1001:
  %v4165 = load i64, ptr %slot45, align 8
  store i64 %v4165, ptr %slot741, align 8
  %v4166 = load i64, ptr %slot741, align 8
  %v4167 = load i64, ptr %slot738, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4166, i64 %v4167) nomerge, !dbg !142
  br label %bb_rcslotdone1001
bb_rcslotowner1001:
  %v4168 = load i64, ptr %slot45, align 8
  store i64 %v4168, ptr %slot742, align 8
  %v4169 = load i64, ptr %slot742, align 8
  %v4170 = load i64, ptr %slot738, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4169, i64 %v4170) nomerge, !dbg !142
  br label %bb_rcslotdone1001
bb_rcslotdone1001:
  %v4171 = load i64, ptr %slot39, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i64, ptr %p4172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4173, ptr %slot743, align 8
  %v4174 = load i64, ptr %slot27, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %ld4176 = load i64, ptr %p4175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4176, ptr %slot744, align 8
  %v4177 = load i64, ptr %slot14, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  %ld4179 = load i32, ptr %p4178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4179, ptr %slot745, align 8
  %v4180 = load i32, ptr %slot745, align 8
  %cv4181 = zext i32 %v4180 to i64
  %cond4182 = icmp ne i64 %cv4181, 0
  br i1 %cond4182, label %bb_rcslotdrop1013, label %bb_rcslotdone1013
bb_rcslotdrop1013:
  %v4183 = load i64, ptr %slot14, align 8
  %p4184 = inttoptr i64 %v4183 to ptr
  store i32 0, ptr %p4184, align 4, !alias.scope !3, !noalias !4
  %v4185 = load i64, ptr %slot21, align 8
  store i64 %v4185, ptr %slot746, align 8
  %v4186 = load i64, ptr %slot15, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  %ld4188 = load i32, ptr %p4187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4188, ptr %slot747, align 8
  %v4189 = load i32, ptr %slot747, align 8
  %op4190 = and i32 %v4189, 28
  store i32 %op4190, ptr %slot748, align 8
  %v4191 = load i32, ptr %slot748, align 8
  %cv4192 = zext i32 %v4191 to i64
  %cond4193 = icmp ne i64 %cv4192, 0
  br i1 %cond4193, label %bb_rcslotrole1013, label %bb_rcslotowner1013
bb_rcslotrole1013:
  %v4194 = load i64, ptr %slot45, align 8
  store i64 %v4194, ptr %slot749, align 8
  %v4195 = load i64, ptr %slot746, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  %ld4197 = load i64, ptr %p4196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4197, ptr %slot750, align 8
  %v4198 = load i64, ptr %slot750, align 8
  %cmp4199 = icmp ne i64 %v4198, 0
  %cv4200 = zext i1 %cmp4199 to i32
  store i32 %cv4200, ptr %slot751, align 8
  %v4201 = load i32, ptr %slot751, align 8
  %cv4202 = zext i32 %v4201 to i64
  %cond4203 = icmp ne i64 %cv4202, 0
  br i1 %cond4203, label %bb_rcgnn1029, label %bb_rcgdone1029
bb_rcgnn1029:
  %v4204 = load i64, ptr %slot750, align 8
  %op4205 = sub i64 %v4204, 16
  store i64 %op4205, ptr %slot752, align 8
  %v4206 = load i64, ptr %slot750, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  %rgep4208 = getelementptr i8, ptr %p4207, i64 -16
  %ld4209 = load i64, ptr %rgep4208, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4209, ptr %slot753, align 8
  %v4210 = load i64, ptr %slot753, align 8
  %op4211 = and i64 %v4210, 4611686018427387906
  store i64 %op4211, ptr %slot754, align 8
  %v4212 = load i64, ptr %slot754, align 8
  %cmp4213 = icmp ne i64 %v4212, 0
  %cv4214 = zext i1 %cmp4213 to i32
  store i32 %cv4214, ptr %slot755, align 8
  %v4215 = load i32, ptr %slot755, align 8
  %cv4216 = zext i32 %v4215 to i64
  %cond4217 = icmp ne i64 %cv4216, 0
  br i1 %cond4217, label %bb_rcgclear1029, label %bb_rcgcounted1029
bb_rcgcounted1029:
  %v4218 = load i64, ptr %slot750, align 8
  %op4219 = sub i64 %v4218, 24
  store i64 %op4219, ptr %slot756, align 8
  %v4220 = load i64, ptr %slot750, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %rgep4222 = getelementptr i8, ptr %p4221, i64 -24
  %ld4223 = load i64, ptr %rgep4222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4223, ptr %slot757, align 8
  %v4224 = load i64, ptr %slot757, align 8
  %op4225 = sub i64 %v4224, 1
  store i64 %op4225, ptr %slot758, align 8
  %v4226 = load i64, ptr %slot758, align 8
  %cmp4227 = icmp eq i64 %v4226, 0
  %cv4228 = zext i1 %cmp4227 to i32
  store i32 %cv4228, ptr %slot759, align 8
  %v4229 = load i32, ptr %slot759, align 8
  %cv4230 = zext i32 %v4229 to i64
  %cond4231 = icmp ne i64 %cv4230, 0
  br i1 %cond4231, label %bb_rcglast1029, label %bb_rcgdec1029
bb_rcglast1029:
  %v4232 = load i64, ptr %slot750, align 8
  %op4233 = sub i64 %v4232, 32
  store i64 %op4233, ptr %slot760, align 8
  %v4234 = load i64, ptr %slot750, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  %rgep4236 = getelementptr i8, ptr %p4235, i64 -32
  %ld4237 = load i64, ptr %rgep4236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4237, ptr %slot761, align 8
  %v4238 = load i64, ptr %slot761, align 8
  %cmp4239 = icmp ne i64 %v4238, 0
  %cv4240 = zext i1 %cmp4239 to i32
  store i32 %cv4240, ptr %slot762, align 8
  %v4241 = load i32, ptr %slot762, align 8
  %cv4242 = zext i32 %v4241 to i64
  %cond4243 = icmp ne i64 %cv4242, 0
  br i1 %cond4243, label %bb_rcgdec1029, label %bb_rcgslow1029
bb_rcgslow1029:
  %v4244 = load i64, ptr %slot749, align 8
  %v4245 = load i64, ptr %slot746, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4244, i64 %v4245) nomerge, !dbg !144
  br label %bb_rcgdone1029
bb_rcgdec1029:
  %v4246 = load i64, ptr %slot758, align 8
  %v4247 = load i64, ptr %slot750, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  %rgep4249 = getelementptr i8, ptr %p4248, i64 -24
  store i64 %v4246, ptr %rgep4249, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1029
bb_rcgclear1029:
  %v4250 = load i64, ptr %slot746, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  store i64 0, ptr %p4251, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1029
bb_rcgdone1029:
  br label %bb_rcslotdone1013
bb_rcslotowner1013:
  %v4252 = load i64, ptr %slot45, align 8
  store i64 %v4252, ptr %slot763, align 8
  %v4253 = load i64, ptr %slot746, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  %ld4255 = load i64, ptr %p4254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4255, ptr %slot764, align 8
  %v4256 = load i64, ptr %slot764, align 8
  %cmp4257 = icmp ne i64 %v4256, 0
  %cv4258 = zext i1 %cmp4257 to i32
  store i32 %cv4258, ptr %slot765, align 8
  %v4259 = load i32, ptr %slot765, align 8
  %cv4260 = zext i32 %v4259 to i64
  %cond4261 = icmp ne i64 %cv4260, 0
  br i1 %cond4261, label %bb_rcgnn1044, label %bb_rcgdone1044
bb_rcgnn1044:
  %v4262 = load i64, ptr %slot764, align 8
  %op4263 = sub i64 %v4262, 16
  store i64 %op4263, ptr %slot766, align 8
  %v4264 = load i64, ptr %slot764, align 8
  %p4265 = inttoptr i64 %v4264 to ptr
  %rgep4266 = getelementptr i8, ptr %p4265, i64 -16
  %ld4267 = load i64, ptr %rgep4266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4267, ptr %slot767, align 8
  %v4268 = load i64, ptr %slot767, align 8
  %op4269 = and i64 %v4268, 4611686018427387906
  store i64 %op4269, ptr %slot768, align 8
  %v4270 = load i64, ptr %slot768, align 8
  %cmp4271 = icmp ne i64 %v4270, 0
  %cv4272 = zext i1 %cmp4271 to i32
  store i32 %cv4272, ptr %slot769, align 8
  %v4273 = load i32, ptr %slot769, align 8
  %cv4274 = zext i32 %v4273 to i64
  %cond4275 = icmp ne i64 %cv4274, 0
  br i1 %cond4275, label %bb_rcgclear1044, label %bb_rcgcounted1044
bb_rcgcounted1044:
  %v4276 = load i64, ptr %slot764, align 8
  %op4277 = sub i64 %v4276, 32
  store i64 %op4277, ptr %slot770, align 8
  %v4278 = load i64, ptr %slot764, align 8
  %p4279 = inttoptr i64 %v4278 to ptr
  %rgep4280 = getelementptr i8, ptr %p4279, i64 -32
  %ld4281 = load i64, ptr %rgep4280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4281, ptr %slot771, align 8
  %v4282 = load i64, ptr %slot771, align 8
  %op4283 = sub i64 %v4282, 1
  store i64 %op4283, ptr %slot772, align 8
  %v4284 = load i64, ptr %slot772, align 8
  %cmp4285 = icmp eq i64 %v4284, 0
  %cv4286 = zext i1 %cmp4285 to i32
  store i32 %cv4286, ptr %slot773, align 8
  %v4287 = load i32, ptr %slot773, align 8
  %cv4288 = zext i32 %v4287 to i64
  %cond4289 = icmp ne i64 %cv4288, 0
  br i1 %cond4289, label %bb_rcglast1044, label %bb_rcgdec1044
bb_rcglast1044:
  %v4290 = load i64, ptr %slot764, align 8
  %op4291 = sub i64 %v4290, 24
  store i64 %op4291, ptr %slot774, align 8
  %v4292 = load i64, ptr %slot764, align 8
  %p4293 = inttoptr i64 %v4292 to ptr
  %rgep4294 = getelementptr i8, ptr %p4293, i64 -24
  %ld4295 = load i64, ptr %rgep4294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4295, ptr %slot775, align 8
  %v4296 = load i64, ptr %slot775, align 8
  %cmp4297 = icmp ne i64 %v4296, 0
  %cv4298 = zext i1 %cmp4297 to i32
  store i32 %cv4298, ptr %slot776, align 8
  %v4299 = load i32, ptr %slot776, align 8
  %cv4300 = zext i32 %v4299 to i64
  %cond4301 = icmp ne i64 %cv4300, 0
  br i1 %cond4301, label %bb_rcgdec1044, label %bb_rcgslow1044
bb_rcgslow1044:
  %v4302 = load i64, ptr %slot763, align 8
  %v4303 = load i64, ptr %slot746, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4302, i64 %v4303) nomerge, !dbg !144
  br label %bb_rcgdone1044
bb_rcgdec1044:
  %v4304 = load i64, ptr %slot772, align 8
  %v4305 = load i64, ptr %slot764, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  %rgep4307 = getelementptr i8, ptr %p4306, i64 -32
  store i64 %v4304, ptr %rgep4307, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1044
bb_rcgclear1044:
  %v4308 = load i64, ptr %slot746, align 8
  %p4309 = inttoptr i64 %v4308 to ptr
  store i64 0, ptr %p4309, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1044
bb_rcgdone1044:
  br label %bb_rcslotdone1013
bb_rcslotdone1013:
  %v4310 = load i64, ptr %slot744, align 8
  %op4311 = add i64 %v4310, 0
  store i64 %op4311, ptr %slot777, align 8
  store i64 0, ptr %slot778, align 8
  %v4312 = load i64, ptr %slot777, align 8
  %p4313 = inttoptr i64 %v4312 to ptr
  %ld4314 = load i64, ptr %p4313, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4314, ptr %slot779, align 8
  %v4315 = load i64, ptr %slot779, align 8
  %cmp4316 = icmp ne i64 %v4315, 0
  %cv4317 = zext i1 %cmp4316 to i32
  store i32 %cv4317, ptr %slot780, align 8
  %v4318 = load i32, ptr %slot780, align 8
  %cv4319 = zext i32 %v4318 to i64
  %cond4320 = icmp ne i64 %cv4319, 0
  br i1 %cond4320, label %bb_rcguniquenn1050, label %bb_rcgunique1050
bb_rcguniquenn1050:
  %v4321 = load i64, ptr %slot779, align 8
  %op4322 = sub i64 %v4321, 16
  store i64 %op4322, ptr %slot781, align 8
  %v4323 = load i64, ptr %slot779, align 8
  %p4324 = inttoptr i64 %v4323 to ptr
  %rgep4325 = getelementptr i8, ptr %p4324, i64 -16
  %ld4326 = load i64, ptr %rgep4325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4326, ptr %slot782, align 8
  %v4327 = load i64, ptr %slot782, align 8
  %op4328 = and i64 %v4327, 6917529027641081858
  store i64 %op4328, ptr %slot783, align 8
  %v4329 = load i64, ptr %slot783, align 8
  %cmp4330 = icmp ne i64 %v4329, 0
  %cv4331 = zext i1 %cmp4330 to i32
  store i32 %cv4331, ptr %slot784, align 8
  %v4332 = load i32, ptr %slot784, align 8
  %cv4333 = zext i32 %v4332 to i64
  %cond4334 = icmp ne i64 %cv4333, 0
  br i1 %cond4334, label %bb_rcguniqueslow1050, label %bb_rcguniquecount1050
bb_rcguniquecount1050:
  %v4335 = load i64, ptr %slot779, align 8
  %op4336 = sub i64 %v4335, 32
  store i64 %op4336, ptr %slot785, align 8
  %v4337 = load i64, ptr %slot779, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  %rgep4339 = getelementptr i8, ptr %p4338, i64 -32
  %ld4340 = load i64, ptr %rgep4339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4340, ptr %slot786, align 8
  %v4341 = load i64, ptr %slot786, align 8
  %cmp4342 = icmp ult i64 %v4341, 2
  %cv4343 = zext i1 %cmp4342 to i32
  store i32 %cv4343, ptr %slot787, align 8
  %v4344 = load i32, ptr %slot787, align 8
  %cv4345 = zext i32 %v4344 to i64
  %cond4346 = icmp ne i64 %cv4345, 0
  br i1 %cond4346, label %bb_rcgunique1050, label %bb_rcguniqueslow1050
bb_rcguniqueslow1050:
  %v4347 = load i64, ptr %slot1, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  %p4349 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v4350 = load i64, ptr %slot777, align 8
  %p4351 = inttoptr i64 %v4350 to ptr
  %v4352 = load i64, ptr %slot778, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  %call4354 = call i32 @myl_qbe_rc_unique_field(ptr %p4348, ptr %p4349, ptr %p4351, ptr %p4353) nomerge, !dbg !144
  store i32 %call4354, ptr %slot788, align 8
  %v4355 = load i32, ptr %slot788, align 8
  %cv4356 = zext i32 %v4355 to i64
  %cond4357 = icmp ne i64 %cv4356, 0
  br i1 %cond4357, label %bb_rcunique1060, label %bb_failure
bb_rcunique1060:
  br label %bb_rcgunique1050
bb_rcgunique1050:
  %v4358 = load i64, ptr %slot777, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  %ld4360 = load i64, ptr %p4359, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4360, ptr %slot789, align 8
  %v4361 = load i64, ptr %slot789, align 8
  %v4362 = load i64, ptr %slot39, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  store i64 %v4361, ptr %p4363, align 8, !alias.scope !3, !noalias !4
  %v4364 = load i64, ptr %slot39, align 8
  %p4365 = inttoptr i64 %v4364 to ptr
  %ld4366 = load i64, ptr %p4365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4366, ptr %slot790, align 8
  %v4367 = load i64, ptr %slot14, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i32, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4369, ptr %slot791, align 8
  %v4370 = load i32, ptr %slot791, align 8
  %cv4371 = zext i32 %v4370 to i64
  %cond4372 = icmp ne i64 %cv4371, 0
  br i1 %cond4372, label %bb_rcslotdrop1065, label %bb_rcslotdone1065
bb_rcslotdrop1065:
  %v4373 = load i64, ptr %slot14, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  store i32 0, ptr %p4374, align 4, !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot21, align 8
  store i64 %v4375, ptr %slot792, align 8
  %v4376 = load i64, ptr %slot15, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %ld4378 = load i32, ptr %p4377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4378, ptr %slot793, align 8
  %v4379 = load i32, ptr %slot793, align 8
  %op4380 = and i32 %v4379, 28
  store i32 %op4380, ptr %slot794, align 8
  %v4381 = load i32, ptr %slot794, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcslotrole1065, label %bb_rcslotowner1065
bb_rcslotrole1065:
  %v4384 = load i64, ptr %slot45, align 8
  store i64 %v4384, ptr %slot795, align 8
  %v4385 = load i64, ptr %slot792, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  %ld4387 = load i64, ptr %p4386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4387, ptr %slot796, align 8
  %v4388 = load i64, ptr %slot796, align 8
  %cmp4389 = icmp ne i64 %v4388, 0
  %cv4390 = zext i1 %cmp4389 to i32
  store i32 %cv4390, ptr %slot797, align 8
  %v4391 = load i32, ptr %slot797, align 8
  %cv4392 = zext i32 %v4391 to i64
  %cond4393 = icmp ne i64 %cv4392, 0
  br i1 %cond4393, label %bb_rcgnn1081, label %bb_rcgdone1081
bb_rcgnn1081:
  %v4394 = load i64, ptr %slot796, align 8
  %op4395 = sub i64 %v4394, 16
  store i64 %op4395, ptr %slot798, align 8
  %v4396 = load i64, ptr %slot796, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %rgep4398 = getelementptr i8, ptr %p4397, i64 -16
  %ld4399 = load i64, ptr %rgep4398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4399, ptr %slot799, align 8
  %v4400 = load i64, ptr %slot799, align 8
  %op4401 = and i64 %v4400, 4611686018427387906
  store i64 %op4401, ptr %slot800, align 8
  %v4402 = load i64, ptr %slot800, align 8
  %cmp4403 = icmp ne i64 %v4402, 0
  %cv4404 = zext i1 %cmp4403 to i32
  store i32 %cv4404, ptr %slot801, align 8
  %v4405 = load i32, ptr %slot801, align 8
  %cv4406 = zext i32 %v4405 to i64
  %cond4407 = icmp ne i64 %cv4406, 0
  br i1 %cond4407, label %bb_rcgclear1081, label %bb_rcgcounted1081
bb_rcgcounted1081:
  %v4408 = load i64, ptr %slot796, align 8
  %op4409 = sub i64 %v4408, 24
  store i64 %op4409, ptr %slot802, align 8
  %v4410 = load i64, ptr %slot796, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  %rgep4412 = getelementptr i8, ptr %p4411, i64 -24
  %ld4413 = load i64, ptr %rgep4412, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4413, ptr %slot803, align 8
  %v4414 = load i64, ptr %slot803, align 8
  %op4415 = sub i64 %v4414, 1
  store i64 %op4415, ptr %slot804, align 8
  %v4416 = load i64, ptr %slot804, align 8
  %cmp4417 = icmp eq i64 %v4416, 0
  %cv4418 = zext i1 %cmp4417 to i32
  store i32 %cv4418, ptr %slot805, align 8
  %v4419 = load i32, ptr %slot805, align 8
  %cv4420 = zext i32 %v4419 to i64
  %cond4421 = icmp ne i64 %cv4420, 0
  br i1 %cond4421, label %bb_rcglast1081, label %bb_rcgdec1081
bb_rcglast1081:
  %v4422 = load i64, ptr %slot796, align 8
  %op4423 = sub i64 %v4422, 32
  store i64 %op4423, ptr %slot806, align 8
  %v4424 = load i64, ptr %slot796, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %rgep4426 = getelementptr i8, ptr %p4425, i64 -32
  %ld4427 = load i64, ptr %rgep4426, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4427, ptr %slot807, align 8
  %v4428 = load i64, ptr %slot807, align 8
  %cmp4429 = icmp ne i64 %v4428, 0
  %cv4430 = zext i1 %cmp4429 to i32
  store i32 %cv4430, ptr %slot808, align 8
  %v4431 = load i32, ptr %slot808, align 8
  %cv4432 = zext i32 %v4431 to i64
  %cond4433 = icmp ne i64 %cv4432, 0
  br i1 %cond4433, label %bb_rcgdec1081, label %bb_rcgslow1081
bb_rcgslow1081:
  %v4434 = load i64, ptr %slot795, align 8
  %v4435 = load i64, ptr %slot792, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4434, i64 %v4435) nomerge, !dbg !144
  br label %bb_rcgdone1081
bb_rcgdec1081:
  %v4436 = load i64, ptr %slot804, align 8
  %v4437 = load i64, ptr %slot796, align 8
  %p4438 = inttoptr i64 %v4437 to ptr
  %rgep4439 = getelementptr i8, ptr %p4438, i64 -24
  store i64 %v4436, ptr %rgep4439, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1081
bb_rcgclear1081:
  %v4440 = load i64, ptr %slot792, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  store i64 0, ptr %p4441, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1081
bb_rcgdone1081:
  br label %bb_rcslotdone1065
bb_rcslotowner1065:
  %v4442 = load i64, ptr %slot45, align 8
  store i64 %v4442, ptr %slot809, align 8
  %v4443 = load i64, ptr %slot792, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i64, ptr %p4444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4445, ptr %slot810, align 8
  %v4446 = load i64, ptr %slot810, align 8
  %cmp4447 = icmp ne i64 %v4446, 0
  %cv4448 = zext i1 %cmp4447 to i32
  store i32 %cv4448, ptr %slot811, align 8
  %v4449 = load i32, ptr %slot811, align 8
  %cv4450 = zext i32 %v4449 to i64
  %cond4451 = icmp ne i64 %cv4450, 0
  br i1 %cond4451, label %bb_rcgnn1096, label %bb_rcgdone1096
bb_rcgnn1096:
  %v4452 = load i64, ptr %slot810, align 8
  %op4453 = sub i64 %v4452, 16
  store i64 %op4453, ptr %slot812, align 8
  %v4454 = load i64, ptr %slot810, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  %rgep4456 = getelementptr i8, ptr %p4455, i64 -16
  %ld4457 = load i64, ptr %rgep4456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4457, ptr %slot813, align 8
  %v4458 = load i64, ptr %slot813, align 8
  %op4459 = and i64 %v4458, 4611686018427387906
  store i64 %op4459, ptr %slot814, align 8
  %v4460 = load i64, ptr %slot814, align 8
  %cmp4461 = icmp ne i64 %v4460, 0
  %cv4462 = zext i1 %cmp4461 to i32
  store i32 %cv4462, ptr %slot815, align 8
  %v4463 = load i32, ptr %slot815, align 8
  %cv4464 = zext i32 %v4463 to i64
  %cond4465 = icmp ne i64 %cv4464, 0
  br i1 %cond4465, label %bb_rcgclear1096, label %bb_rcgcounted1096
bb_rcgcounted1096:
  %v4466 = load i64, ptr %slot810, align 8
  %op4467 = sub i64 %v4466, 32
  store i64 %op4467, ptr %slot816, align 8
  %v4468 = load i64, ptr %slot810, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %rgep4470 = getelementptr i8, ptr %p4469, i64 -32
  %ld4471 = load i64, ptr %rgep4470, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4471, ptr %slot817, align 8
  %v4472 = load i64, ptr %slot817, align 8
  %op4473 = sub i64 %v4472, 1
  store i64 %op4473, ptr %slot818, align 8
  %v4474 = load i64, ptr %slot818, align 8
  %cmp4475 = icmp eq i64 %v4474, 0
  %cv4476 = zext i1 %cmp4475 to i32
  store i32 %cv4476, ptr %slot819, align 8
  %v4477 = load i32, ptr %slot819, align 8
  %cv4478 = zext i32 %v4477 to i64
  %cond4479 = icmp ne i64 %cv4478, 0
  br i1 %cond4479, label %bb_rcglast1096, label %bb_rcgdec1096
bb_rcglast1096:
  %v4480 = load i64, ptr %slot810, align 8
  %op4481 = sub i64 %v4480, 24
  store i64 %op4481, ptr %slot820, align 8
  %v4482 = load i64, ptr %slot810, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  %rgep4484 = getelementptr i8, ptr %p4483, i64 -24
  %ld4485 = load i64, ptr %rgep4484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4485, ptr %slot821, align 8
  %v4486 = load i64, ptr %slot821, align 8
  %cmp4487 = icmp ne i64 %v4486, 0
  %cv4488 = zext i1 %cmp4487 to i32
  store i32 %cv4488, ptr %slot822, align 8
  %v4489 = load i32, ptr %slot822, align 8
  %cv4490 = zext i32 %v4489 to i64
  %cond4491 = icmp ne i64 %cv4490, 0
  br i1 %cond4491, label %bb_rcgdec1096, label %bb_rcgslow1096
bb_rcgslow1096:
  %v4492 = load i64, ptr %slot809, align 8
  %v4493 = load i64, ptr %slot792, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4492, i64 %v4493) nomerge, !dbg !144
  br label %bb_rcgdone1096
bb_rcgdec1096:
  %v4494 = load i64, ptr %slot818, align 8
  %v4495 = load i64, ptr %slot810, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  %rgep4497 = getelementptr i8, ptr %p4496, i64 -32
  store i64 %v4494, ptr %rgep4497, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1096
bb_rcgclear1096:
  %v4498 = load i64, ptr %slot792, align 8
  %p4499 = inttoptr i64 %v4498 to ptr
  store i64 0, ptr %p4499, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1096
bb_rcgdone1096:
  br label %bb_rcslotdone1065
bb_rcslotdone1065:
  %v4500 = load i64, ptr %slot790, align 8
  %v4501 = load i64, ptr %slot36, align 8
  %p4502 = inttoptr i64 %v4501 to ptr
  store i64 %v4500, ptr %p4502, align 8, !alias.scope !3, !noalias !4
  %v4503 = load i64, ptr %slot28, align 8
  %p4504 = inttoptr i64 %v4503 to ptr
  %ld4505 = load i64, ptr %p4504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4505, ptr %slot823, align 8
  %v4506 = load i64, ptr %slot823, align 8
  %v4507 = load i64, ptr %slot39, align 8
  %p4508 = inttoptr i64 %v4507 to ptr
  store i64 %v4506, ptr %p4508, align 8, !alias.scope !3, !noalias !4
  %v4509 = load i64, ptr %slot39, align 8
  %p4510 = inttoptr i64 %v4509 to ptr
  %ld4511 = load i64, ptr %p4510, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4511, ptr %slot824, align 8
  %v4512 = load i64, ptr %slot824, align 8
  %v4513 = load i64, ptr %slot38, align 8
  %p4514 = inttoptr i64 %v4513 to ptr
  store i64 %v4512, ptr %p4514, align 8, !alias.scope !3, !noalias !4
  %v4515 = load i64, ptr %slot38, align 8
  %p4516 = inttoptr i64 %v4515 to ptr
  %ld4517 = load i64, ptr %p4516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4517, ptr %slot825, align 8
  %v4518 = load i64, ptr %slot825, align 8
  %v4519 = load i64, ptr %slot39, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  store i64 %v4518, ptr %p4520, align 8, !alias.scope !3, !noalias !4
  %v4521 = load i64, ptr %slot40, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  store i64 0, ptr %p4522, align 8, !alias.scope !3, !noalias !4
  %v4523 = load i64, ptr %slot40, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  %ld4525 = load i64, ptr %p4524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4525, ptr %slot826, align 8
  %v4526 = load i64, ptr %slot39, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %ld4528 = load i64, ptr %p4527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4528, ptr %slot827, align 8
  %v4529 = load i64, ptr %slot827, align 8
  %v4530 = load i64, ptr %slot826, align 8
  %cmp4531 = icmp slt i64 %v4529, %v4530
  %cv4532 = zext i1 %cmp4531 to i64
  store i64 %cv4532, ptr %slot828, align 8
  %v4533 = load i64, ptr %slot828, align 8
  %v4534 = load i64, ptr %slot39, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  store i64 %v4533, ptr %p4535, align 8, !alias.scope !3, !noalias !4
  %v4536 = load i64, ptr %slot39, align 8
  %p4537 = inttoptr i64 %v4536 to ptr
  %ld4538 = load i64, ptr %p4537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4538, ptr %slot829, align 8
  %v4539 = load i64, ptr %slot829, align 8
  %cond4540 = icmp ne i64 %v4539, 0
  br i1 %cond4540, label %bb_next1144, label %bb_i54
bb_next1144:
  %v4541 = load i64, ptr %slot36, align 8
  %p4542 = inttoptr i64 %v4541 to ptr
  %ld4543 = load i64, ptr %p4542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4543, ptr %slot830, align 8
  %v4544 = load i64, ptr %slot830, align 8
  %op4545 = add i64 %v4544, 0
  store i64 %op4545, ptr %slot831, align 8
  %v4546 = load i64, ptr %slot831, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  %ld4548 = load i64, ptr %p4547, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4548, ptr %slot832, align 8
  %v4549 = load i64, ptr %slot832, align 8
  %v4550 = load i64, ptr %slot39, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  store i64 %v4549, ptr %p4551, align 8, !alias.scope !3, !noalias !4
  %v4552 = load i64, ptr %slot39, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %ld4554 = load i64, ptr %p4553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4554, ptr %slot833, align 8
  %v4555 = load i64, ptr %slot833, align 8
  %cmp4556 = icmp ugt i64 %v4555, 9223372036854775807
  %cv4557 = zext i1 %cmp4556 to i64
  store i64 %cv4557, ptr %slot834, align 8
  %v4558 = load i64, ptr %slot834, align 8
  %cond4559 = icmp ne i64 %v4558, 0
  br i1 %cond4559, label %bb_cast_overflow1149, label %bb_cast_ok1149
bb_cast_overflow1149:
  %v4560 = load i64, ptr %slot1, align 8
  %p4561 = inttoptr i64 %v4560 to ptr
  %v4562 = load i64, ptr %slot833, align 8
  call void @myl_qbe_fail_cast(ptr %p4561, i64 %v4562, i64 320) nomerge, !dbg !146
  unreachable
bb_cast_ok1149:
  %v4563 = load i64, ptr %slot833, align 8
  %v4564 = load i64, ptr %slot39, align 8
  %p4565 = inttoptr i64 %v4564 to ptr
  store i64 %v4563, ptr %p4565, align 8, !alias.scope !3, !noalias !4
  %v4566 = load i64, ptr %slot38, align 8
  %p4567 = inttoptr i64 %v4566 to ptr
  %ld4568 = load i64, ptr %p4567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4568, ptr %slot835, align 8
  %v4569 = load i64, ptr %slot835, align 8
  %v4570 = load i64, ptr %slot40, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  store i64 %v4569, ptr %p4571, align 8, !alias.scope !3, !noalias !4
  %v4572 = load i64, ptr %slot40, align 8
  %p4573 = inttoptr i64 %v4572 to ptr
  %ld4574 = load i64, ptr %p4573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4574, ptr %slot836, align 8
  %v4575 = load i64, ptr %slot39, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  %ld4577 = load i64, ptr %p4576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4577, ptr %slot837, align 8
  %v4578 = load i64, ptr %slot837, align 8
  %v4579 = load i64, ptr %slot836, align 8
  %ovpair4581 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4578, i64 %v4579)
  %op4580 = extractvalue { i64, i1 } %ovpair4581, 0
  %ov4582 = extractvalue { i64, i1 } %ovpair4581, 1
  store i64 %op4580, ptr %slot838, align 8
  %v4583 = load i64, ptr %slot837, align 8
  %v4584 = load i64, ptr %slot838, align 8
  %op4585 = xor i64 %v4583, %v4584
  store i64 %op4585, ptr %slot839, align 8
  %v4586 = load i64, ptr %slot836, align 8
  %v4587 = load i64, ptr %slot838, align 8
  %op4588 = xor i64 %v4586, %v4587
  store i64 %op4588, ptr %slot840, align 8
  %v4589 = load i64, ptr %slot839, align 8
  %v4590 = load i64, ptr %slot840, align 8
  %op4591 = and i64 %v4589, %v4590
  store i64 %op4591, ptr %slot841, align 8
  %cv4592 = zext i1 %ov4582 to i64
  store i64 %cv4592, ptr %slot842, align 8
  %v4593 = load i64, ptr %slot842, align 8
  %cond4594 = icmp ne i64 %v4593, 0
  br i1 %cond4594, label %bb_overflow1153, label %bb_checked1153
bb_overflow1153:
  %v4595 = load i64, ptr %slot1, align 8
  %p4596 = inttoptr i64 %v4595 to ptr
  %v4597 = load i64, ptr %slot837, align 8
  %v4598 = load i64, ptr %slot836, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4596, i64 0, i64 %v4597, i64 %v4598, i64 64) nomerge, !dbg !148
  unreachable
bb_checked1153:
  %v4599 = load i64, ptr %slot838, align 8
  %v4600 = load i64, ptr %slot39, align 8
  %p4601 = inttoptr i64 %v4600 to ptr
  store i64 %v4599, ptr %p4601, align 8, !alias.scope !3, !noalias !4
  %v4602 = load i64, ptr %slot39, align 8
  %p4603 = inttoptr i64 %v4602 to ptr
  %ld4604 = load i64, ptr %p4603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4604, ptr %slot843, align 8
  %v4605 = load i64, ptr %slot843, align 8
  %v4606 = load i64, ptr %slot38, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  store i64 %v4605, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  br label %bb_i54
bb_i54:
  %v4608 = load i64, ptr %slot38, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  %ld4610 = load i64, ptr %p4609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4610, ptr %slot844, align 8
  %v4611 = load i64, ptr %slot844, align 8
  %v4612 = load i64, ptr %slot39, align 8
  %p4613 = inttoptr i64 %v4612 to ptr
  store i64 %v4611, ptr %p4613, align 8, !alias.scope !3, !noalias !4
  %v4614 = load i64, ptr %slot37, align 8
  %v4615 = load i64, ptr %slot44, align 8
  %p4616 = inttoptr i64 %v4614 to ptr
  %p4617 = inttoptr i64 %v4615 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4617, ptr %p4616, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4618 = load i64, ptr %slot44, align 8
  %v4619 = load i64, ptr %slot40, align 8
  %p4620 = inttoptr i64 %v4619 to ptr
  store i64 %v4618, ptr %p4620, align 8, !alias.scope !3, !noalias !4
  %v4621 = load i64, ptr %slot36, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %ld4623 = load i64, ptr %p4622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4623, ptr %slot845, align 8
  %v4624 = load i64, ptr %slot40, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  %ld4626 = load i64, ptr %p4625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4626, ptr %slot846, align 8
  %v4627 = load i64, ptr %slot39, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  %ld4629 = load i64, ptr %p4628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4629, ptr %slot847, align 8
  %v4630 = load i64, ptr %slot845, align 8
  %p4631 = inttoptr i64 %v4630 to ptr
  %ld4632 = load i64, ptr %p4631, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4632, ptr %slot848, align 8
  %v4633 = load i64, ptr %slot847, align 8
  %v4634 = load i64, ptr %slot848, align 8
  %cmp4635 = icmp ult i64 %v4633, %v4634
  %cv4636 = zext i1 %cmp4635 to i64
  store i64 %cv4636, ptr %slot849, align 8
  %v4637 = load i64, ptr %slot849, align 8
  %cond4638 = icmp ne i64 %v4637, 0
  br i1 %cond4638, label %bb_success1166, label %bb_failed1166
bb_failed1166:
  %v4639 = load i64, ptr %slot1, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %v4641 = load i64, ptr %slot847, align 8
  %v4642 = load i64, ptr %slot848, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4640, i64 %v4641, i64 %v4642) nomerge, !dbg !150
  unreachable
bb_success1166:
  %v4643 = load i64, ptr %slot40, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  %ld4645 = load i64, ptr %p4644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4645, ptr %slot850, align 8
  %v4646 = load i64, ptr %slot45, align 8
  %v4647 = load i64, ptr %slot845, align 8
  %v4648 = load i64, ptr %slot847, align 8
  %v4649 = load i64, ptr %slot850, align 8
  %call4650 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v4646, i64 %v4647, i64 %v4648, i64 %v4649) nomerge, !dbg !150
  store i32 %call4650, ptr %slot851, align 8
  %v4651 = load i32, ptr %slot851, align 8
  %cv4652 = zext i32 %v4651 to i64
  %cond4653 = icmp ne i64 %cv4652, 0
  br i1 %cond4653, label %bb_success1169, label %bb_failed1169
bb_failed1169:
  %v4654 = load i64, ptr %slot1, align 8
  %p4655 = inttoptr i64 %v4654 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4655) nomerge, !dbg !150
  unreachable
bb_success1169:
  %v4656 = load i64, ptr %slot39, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  store i64 0, ptr %p4657, align 8, !alias.scope !3, !noalias !4
  %v4658 = load i64, ptr %slot16, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %ld4660 = load i32, ptr %p4659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4660, ptr %slot852, align 8
  %v4661 = load i32, ptr %slot852, align 8
  %cv4662 = zext i32 %v4661 to i64
  %cond4663 = icmp ne i64 %cv4662, 0
  br i1 %cond4663, label %bb_rcslotdrop1172, label %bb_rcslotdone1172
bb_rcslotdrop1172:
  %v4664 = load i64, ptr %slot16, align 8
  %p4665 = inttoptr i64 %v4664 to ptr
  store i32 0, ptr %p4665, align 4, !alias.scope !3, !noalias !4
  %v4666 = load i64, ptr %slot22, align 8
  store i64 %v4666, ptr %slot853, align 8
  %v4667 = load i64, ptr %slot17, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  %ld4669 = load i32, ptr %p4668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4669, ptr %slot854, align 8
  %v4670 = load i32, ptr %slot854, align 8
  %op4671 = and i32 %v4670, 28
  store i32 %op4671, ptr %slot855, align 8
  %v4672 = load i32, ptr %slot855, align 8
  %cv4673 = zext i32 %v4672 to i64
  %cond4674 = icmp ne i64 %cv4673, 0
  br i1 %cond4674, label %bb_rcslotrole1172, label %bb_rcslotowner1172
bb_rcslotrole1172:
  %v4675 = load i64, ptr %slot45, align 8
  store i64 %v4675, ptr %slot856, align 8
  %v4676 = load i64, ptr %slot856, align 8
  %v4677 = load i64, ptr %slot853, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4676, i64 %v4677) nomerge, !dbg !150
  br label %bb_rcslotdone1172
bb_rcslotowner1172:
  %v4678 = load i64, ptr %slot45, align 8
  store i64 %v4678, ptr %slot857, align 8
  %v4679 = load i64, ptr %slot857, align 8
  %v4680 = load i64, ptr %slot853, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4679, i64 %v4680) nomerge, !dbg !150
  br label %bb_rcslotdone1172
bb_rcslotdone1172:
  %v4681 = load i64, ptr %slot6, align 8
  %p4682 = inttoptr i64 %v4681 to ptr
  %ld4683 = load i32, ptr %p4682, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4683, ptr %slot858, align 8
  %v4684 = load i32, ptr %slot858, align 8
  %cv4685 = zext i32 %v4684 to i64
  %cond4686 = icmp ne i64 %cv4685, 0
  br i1 %cond4686, label %bb_rcslotdrop1181, label %bb_rcslotdone1181
bb_rcslotdrop1181:
  %v4687 = load i64, ptr %slot6, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  store i32 0, ptr %p4688, align 4, !alias.scope !3, !noalias !4
  %v4689 = load i64, ptr %slot32, align 8
  store i64 %v4689, ptr %slot859, align 8
  %v4690 = load i64, ptr %slot7, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  %ld4692 = load i32, ptr %p4691, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4692, ptr %slot860, align 8
  %v4693 = load i32, ptr %slot860, align 8
  %op4694 = and i32 %v4693, 28
  store i32 %op4694, ptr %slot861, align 8
  %v4695 = load i32, ptr %slot861, align 8
  %cv4696 = zext i32 %v4695 to i64
  %cond4697 = icmp ne i64 %cv4696, 0
  br i1 %cond4697, label %bb_rcslotrole1181, label %bb_rcslotowner1181
bb_rcslotrole1181:
  %v4698 = load i64, ptr %slot45, align 8
  store i64 %v4698, ptr %slot862, align 8
  %v4699 = load i64, ptr %slot862, align 8
  %v4700 = load i64, ptr %slot859, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4699, i64 %v4700) nomerge, !dbg !152
  br label %bb_rcslotdone1181
bb_rcslotowner1181:
  %v4701 = load i64, ptr %slot859, align 8
  %p4703 = inttoptr i64 %v4701 to ptr
  %gep4704 = getelementptr i8, ptr %p4703, i64 8
  %op4702 = ptrtoint ptr %gep4704 to i64
  store i64 %op4702, ptr %slot863, align 8
  %v4705 = load i64, ptr %slot45, align 8
  store i64 %v4705, ptr %slot864, align 8
  %v4706 = load i64, ptr %slot863, align 8
  %p4707 = inttoptr i64 %v4706 to ptr
  %ld4708 = load i64, ptr %p4707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4708, ptr %slot865, align 8
  %v4709 = load i64, ptr %slot865, align 8
  %cmp4710 = icmp ne i64 %v4709, 0
  %cv4711 = zext i1 %cmp4710 to i32
  store i32 %cv4711, ptr %slot866, align 8
  %v4712 = load i32, ptr %slot866, align 8
  %cv4713 = zext i32 %v4712 to i64
  %cond4714 = icmp ne i64 %cv4713, 0
  br i1 %cond4714, label %bb_rcgnn1199, label %bb_rcgdone1199
bb_rcgnn1199:
  %v4715 = load i64, ptr %slot865, align 8
  %op4716 = sub i64 %v4715, 16
  store i64 %op4716, ptr %slot867, align 8
  %v4717 = load i64, ptr %slot865, align 8
  %p4718 = inttoptr i64 %v4717 to ptr
  %rgep4719 = getelementptr i8, ptr %p4718, i64 -16
  %ld4720 = load i64, ptr %rgep4719, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4720, ptr %slot868, align 8
  %v4721 = load i64, ptr %slot868, align 8
  %op4722 = and i64 %v4721, 4611686018427387906
  store i64 %op4722, ptr %slot869, align 8
  %v4723 = load i64, ptr %slot869, align 8
  %cmp4724 = icmp ne i64 %v4723, 0
  %cv4725 = zext i1 %cmp4724 to i32
  store i32 %cv4725, ptr %slot870, align 8
  %v4726 = load i32, ptr %slot870, align 8
  %cv4727 = zext i32 %v4726 to i64
  %cond4728 = icmp ne i64 %cv4727, 0
  br i1 %cond4728, label %bb_rcgclear1199, label %bb_rcgcounted1199
bb_rcgcounted1199:
  %v4729 = load i64, ptr %slot865, align 8
  %op4730 = sub i64 %v4729, 32
  store i64 %op4730, ptr %slot871, align 8
  %v4731 = load i64, ptr %slot865, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  %rgep4733 = getelementptr i8, ptr %p4732, i64 -32
  %ld4734 = load i64, ptr %rgep4733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4734, ptr %slot872, align 8
  %v4735 = load i64, ptr %slot872, align 8
  %op4736 = sub i64 %v4735, 1
  store i64 %op4736, ptr %slot873, align 8
  %v4737 = load i64, ptr %slot873, align 8
  %cmp4738 = icmp eq i64 %v4737, 0
  %cv4739 = zext i1 %cmp4738 to i32
  store i32 %cv4739, ptr %slot874, align 8
  %v4740 = load i32, ptr %slot874, align 8
  %cv4741 = zext i32 %v4740 to i64
  %cond4742 = icmp ne i64 %cv4741, 0
  br i1 %cond4742, label %bb_rcglast1199, label %bb_rcgdec1199
bb_rcglast1199:
  %v4743 = load i64, ptr %slot865, align 8
  %op4744 = sub i64 %v4743, 24
  store i64 %op4744, ptr %slot875, align 8
  %v4745 = load i64, ptr %slot865, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  %rgep4747 = getelementptr i8, ptr %p4746, i64 -24
  %ld4748 = load i64, ptr %rgep4747, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4748, ptr %slot876, align 8
  %v4749 = load i64, ptr %slot876, align 8
  %cmp4750 = icmp ne i64 %v4749, 0
  %cv4751 = zext i1 %cmp4750 to i32
  store i32 %cv4751, ptr %slot877, align 8
  %v4752 = load i32, ptr %slot877, align 8
  %cv4753 = zext i32 %v4752 to i64
  %cond4754 = icmp ne i64 %cv4753, 0
  br i1 %cond4754, label %bb_rcgdec1199, label %bb_rcgslow1199
bb_rcgslow1199:
  %v4755 = load i64, ptr %slot864, align 8
  %v4756 = load i64, ptr %slot863, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v4755, i64 %v4756) nomerge, !dbg !152
  br label %bb_rcgdone1199
bb_rcgdec1199:
  %v4757 = load i64, ptr %slot873, align 8
  %v4758 = load i64, ptr %slot865, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  %rgep4760 = getelementptr i8, ptr %p4759, i64 -32
  store i64 %v4757, ptr %rgep4760, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1199
bb_rcgclear1199:
  %v4761 = load i64, ptr %slot863, align 8
  %p4762 = inttoptr i64 %v4761 to ptr
  store i64 0, ptr %p4762, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1199
bb_rcgdone1199:
  %v4763 = load i64, ptr %slot859, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  store i64 0, ptr %p4764, align 8, !alias.scope !3, !noalias !4
  %v4765 = load i64, ptr %slot859, align 8
  %p4767 = inttoptr i64 %v4765 to ptr
  %gep4768 = getelementptr i8, ptr %p4767, i64 8
  %op4766 = ptrtoint ptr %gep4768 to i64
  store i64 %op4766, ptr %slot878, align 8
  %v4769 = load i64, ptr %slot878, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  store i64 0, ptr %p4770, align 8, !alias.scope !3, !noalias !4
  %v4771 = load i64, ptr %slot859, align 8
  %p4773 = inttoptr i64 %v4771 to ptr
  %gep4774 = getelementptr i8, ptr %p4773, i64 16
  %op4772 = ptrtoint ptr %gep4774 to i64
  store i64 %op4772, ptr %slot879, align 8
  %v4775 = load i64, ptr %slot879, align 8
  %p4776 = inttoptr i64 %v4775 to ptr
  store i64 0, ptr %p4776, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1181
bb_rcslotdone1181:
  br label %bb_i91
bb_i61:
  %v4777 = load i64, ptr %slot39, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  store i64 0, ptr %p4778, align 8, !alias.scope !3, !noalias !4
  %v4779 = load i64, ptr %slot39, align 8
  %p4780 = inttoptr i64 %v4779 to ptr
  %ld4781 = load i64, ptr %p4780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4781, ptr %slot880, align 8
  %v4782 = load i64, ptr %slot880, align 8
  %cond4783 = icmp ne i64 %v4782, 0
  br i1 %cond4783, label %bb_success1206, label %bb_failed1206
bb_failed1206:
  %v4784 = load i64, ptr %slot1, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  call void @myl_qbe_fail_assert(ptr %p4785) nomerge, !dbg !154
  unreachable
bb_success1206:
  br label %bb_i91
bb_i64:
  %v4786 = load i64, ptr %slot39, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i64 0, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot39, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  %ld4790 = load i64, ptr %p4789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4790, ptr %slot881, align 8
  %v4791 = load i64, ptr %slot881, align 8
  %cond4792 = icmp ne i64 %v4791, 0
  br i1 %cond4792, label %bb_success1208, label %bb_failed1208
bb_failed1208:
  %v4793 = load i64, ptr %slot1, align 8
  %p4794 = inttoptr i64 %v4793 to ptr
  call void @myl_qbe_fail_assert(ptr %p4794) nomerge, !dbg !156
  unreachable
bb_success1208:
  br label %bb_i91
bb_i67:
  %v4795 = load i64, ptr %slot39, align 8
  %p4796 = inttoptr i64 %v4795 to ptr
  store i64 0, ptr %p4796, align 8, !alias.scope !3, !noalias !4
  %v4797 = load i64, ptr %slot39, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %ld4799 = load i64, ptr %p4798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4799, ptr %slot882, align 8
  %v4800 = load i64, ptr %slot882, align 8
  %cond4801 = icmp ne i64 %v4800, 0
  br i1 %cond4801, label %bb_success1210, label %bb_failed1210
bb_failed1210:
  %v4802 = load i64, ptr %slot1, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  call void @myl_qbe_fail_assert(ptr %p4803) nomerge, !dbg !158
  unreachable
bb_success1210:
  br label %bb_i91
bb_i70:
  %v4804 = load i64, ptr %slot39, align 8
  %p4805 = inttoptr i64 %v4804 to ptr
  store i64 0, ptr %p4805, align 8, !alias.scope !3, !noalias !4
  %v4806 = load i64, ptr %slot39, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  %ld4808 = load i64, ptr %p4807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4808, ptr %slot883, align 8
  %v4809 = load i64, ptr %slot883, align 8
  %cond4810 = icmp ne i64 %v4809, 0
  br i1 %cond4810, label %bb_success1212, label %bb_failed1212
bb_failed1212:
  %v4811 = load i64, ptr %slot1, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  call void @myl_qbe_fail_assert(ptr %p4812) nomerge, !dbg !160
  unreachable
bb_success1212:
  br label %bb_i91
bb_i73:
  %v4813 = load i64, ptr %slot39, align 8
  %p4814 = inttoptr i64 %v4813 to ptr
  store i64 0, ptr %p4814, align 8, !alias.scope !3, !noalias !4
  %v4815 = load i64, ptr %slot39, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %ld4817 = load i64, ptr %p4816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4817, ptr %slot884, align 8
  %v4818 = load i64, ptr %slot884, align 8
  %cond4819 = icmp ne i64 %v4818, 0
  br i1 %cond4819, label %bb_success1214, label %bb_failed1214
bb_failed1214:
  %v4820 = load i64, ptr %slot1, align 8
  %p4821 = inttoptr i64 %v4820 to ptr
  call void @myl_qbe_fail_assert(ptr %p4821) nomerge, !dbg !162
  unreachable
bb_success1214:
  br label %bb_i91
bb_i76:
  %v4822 = load i64, ptr %slot39, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  store i64 0, ptr %p4823, align 8, !alias.scope !3, !noalias !4
  %v4824 = load i64, ptr %slot39, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %ld4826 = load i64, ptr %p4825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4826, ptr %slot885, align 8
  %v4827 = load i64, ptr %slot885, align 8
  %cond4828 = icmp ne i64 %v4827, 0
  br i1 %cond4828, label %bb_success1216, label %bb_failed1216
bb_failed1216:
  %v4829 = load i64, ptr %slot1, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  call void @myl_qbe_fail_assert(ptr %p4830) nomerge, !dbg !164
  unreachable
bb_success1216:
  br label %bb_i91
bb_i79:
  %v4831 = load i64, ptr %slot39, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  store i64 0, ptr %p4832, align 8, !alias.scope !3, !noalias !4
  %v4833 = load i64, ptr %slot39, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  %ld4835 = load i64, ptr %p4834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4835, ptr %slot886, align 8
  %v4836 = load i64, ptr %slot886, align 8
  %cond4837 = icmp ne i64 %v4836, 0
  br i1 %cond4837, label %bb_success1218, label %bb_failed1218
bb_failed1218:
  %v4838 = load i64, ptr %slot1, align 8
  %p4839 = inttoptr i64 %v4838 to ptr
  call void @myl_qbe_fail_assert(ptr %p4839) nomerge, !dbg !166
  unreachable
bb_success1218:
  br label %bb_i91
bb_i82:
  %v4840 = load i64, ptr %slot39, align 8
  %p4841 = inttoptr i64 %v4840 to ptr
  store i64 0, ptr %p4841, align 8, !alias.scope !3, !noalias !4
  %v4842 = load i64, ptr %slot39, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  %ld4844 = load i64, ptr %p4843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4844, ptr %slot887, align 8
  %v4845 = load i64, ptr %slot887, align 8
  %cond4846 = icmp ne i64 %v4845, 0
  br i1 %cond4846, label %bb_success1220, label %bb_failed1220
bb_failed1220:
  %v4847 = load i64, ptr %slot1, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  call void @myl_qbe_fail_assert(ptr %p4848) nomerge, !dbg !168
  unreachable
bb_success1220:
  br label %bb_i91
bb_i85:
  %v4849 = load i64, ptr %slot39, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  store i64 0, ptr %p4850, align 8, !alias.scope !3, !noalias !4
  %v4851 = load i64, ptr %slot39, align 8
  %p4852 = inttoptr i64 %v4851 to ptr
  %ld4853 = load i64, ptr %p4852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4853, ptr %slot888, align 8
  %v4854 = load i64, ptr %slot888, align 8
  %cond4855 = icmp ne i64 %v4854, 0
  br i1 %cond4855, label %bb_success1222, label %bb_failed1222
bb_failed1222:
  %v4856 = load i64, ptr %slot1, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  call void @myl_qbe_fail_assert(ptr %p4857) nomerge, !dbg !170
  unreachable
bb_success1222:
  br label %bb_i91
bb_i88:
  %v4858 = load i64, ptr %slot39, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  store i64 0, ptr %p4859, align 8, !alias.scope !3, !noalias !4
  %v4860 = load i64, ptr %slot39, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %ld4862 = load i64, ptr %p4861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4862, ptr %slot889, align 8
  %v4863 = load i64, ptr %slot889, align 8
  %cond4864 = icmp ne i64 %v4863, 0
  br i1 %cond4864, label %bb_success1224, label %bb_failed1224
bb_failed1224:
  %v4865 = load i64, ptr %slot1, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  call void @myl_qbe_fail_assert(ptr %p4866) nomerge, !dbg !172
  unreachable
bb_success1224:
  br label %bb_i91
bb_i91:
  %v4867 = load i64, ptr %slot39, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  store i64 0, ptr %p4868, align 8, !alias.scope !3, !noalias !4
  %v4869 = load i64, ptr %slot39, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i64, ptr %p4870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4871, ptr %slot890, align 8
  %v4872 = load i64, ptr %slot24, align 8
  %p4874 = inttoptr i64 %v4872 to ptr
  %gep4875 = getelementptr i8, ptr %p4874, i64 24
  %op4873 = ptrtoint ptr %gep4875 to i64
  store i64 %op4873, ptr %slot891, align 8
  %v4876 = load i64, ptr %slot891, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i32, ptr %p4877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4878, ptr %slot892, align 8
  %v4879 = load i32, ptr %slot892, align 8
  %cv4880 = zext i32 %v4879 to i64
  %cond4881 = icmp ne i64 %cv4880, 0
  br i1 %cond4881, label %bb_rcscopesopen1228, label %bb_rcscopesclosed1228
bb_rcscopesopen1228:
  %v4882 = load i64, ptr %slot26, align 8
  %p4884 = inttoptr i64 %v4882 to ptr
  %gep4885 = getelementptr i8, ptr %p4884, i64 0
  %op4883 = ptrtoint ptr %gep4885 to i64
  store i64 %op4883, ptr %slot893, align 8
  %v4886 = load i64, ptr %slot24, align 8
  %v4887 = load i64, ptr %slot893, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  store i64 %v4886, ptr %p4888, align 8, !alias.scope !3, !noalias !4
  %v4889 = load i64, ptr %slot1, align 8
  %p4890 = inttoptr i64 %v4889 to ptr
  %v4891 = load i64, ptr %slot26, align 8
  %p4892 = inttoptr i64 %v4891 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p4890, ptr %p4892, i64 1) nomerge, !dbg !174
  br label %bb_rcscopesclosed1228
bb_rcscopesclosed1228:
  %v4893 = load i64, ptr %slot14, align 8
  %p4894 = inttoptr i64 %v4893 to ptr
  %ld4895 = load i32, ptr %p4894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4895, ptr %slot894, align 8
  %v4896 = load i32, ptr %slot894, align 8
  %cv4897 = zext i32 %v4896 to i64
  %cond4898 = icmp ne i64 %cv4897, 0
  br i1 %cond4898, label %bb_rcslotdrop1232, label %bb_rcslotdone1232
bb_rcslotdrop1232:
  %v4899 = load i64, ptr %slot14, align 8
  %p4900 = inttoptr i64 %v4899 to ptr
  store i32 0, ptr %p4900, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1232
bb_rcslotdone1232:
  %v4901 = load i64, ptr %slot12, align 8
  %p4902 = inttoptr i64 %v4901 to ptr
  %ld4903 = load i32, ptr %p4902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4903, ptr %slot895, align 8
  %v4904 = load i32, ptr %slot895, align 8
  %cv4905 = zext i32 %v4904 to i64
  %cond4906 = icmp ne i64 %cv4905, 0
  br i1 %cond4906, label %bb_rcslotdrop1235, label %bb_rcslotdone1235
bb_rcslotdrop1235:
  %v4907 = load i64, ptr %slot12, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  store i32 0, ptr %p4908, align 4, !alias.scope !3, !noalias !4
  %v4909 = load i64, ptr %slot37, align 8
  store i64 %v4909, ptr %slot896, align 8
  %v4910 = load i64, ptr %slot13, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %ld4912 = load i32, ptr %p4911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4912, ptr %slot897, align 8
  %v4913 = load i32, ptr %slot897, align 8
  %op4914 = and i32 %v4913, 28
  store i32 %op4914, ptr %slot898, align 8
  %v4915 = load i32, ptr %slot898, align 8
  %cv4916 = zext i32 %v4915 to i64
  %cond4917 = icmp ne i64 %cv4916, 0
  br i1 %cond4917, label %bb_rcslotrole1235, label %bb_rcslotowner1235
bb_rcslotrole1235:
  %v4918 = load i64, ptr %slot45, align 8
  store i64 %v4918, ptr %slot899, align 8
  %v4919 = load i64, ptr %slot899, align 8
  %v4920 = load i64, ptr %slot896, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4919, i64 %v4920) nomerge, !dbg !174
  br label %bb_rcslotdone1235
bb_rcslotowner1235:
  %v4921 = load i64, ptr %slot45, align 8
  store i64 %v4921, ptr %slot900, align 8
  %v4922 = load i64, ptr %slot900, align 8
  %v4923 = load i64, ptr %slot896, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4922, i64 %v4923) nomerge, !dbg !174
  br label %bb_rcslotdone1235
bb_rcslotdone1235:
  %v4924 = load i64, ptr %slot10, align 8
  %p4925 = inttoptr i64 %v4924 to ptr
  %ld4926 = load i32, ptr %p4925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4926, ptr %slot901, align 8
  %v4927 = load i32, ptr %slot901, align 8
  %cv4928 = zext i32 %v4927 to i64
  %cond4929 = icmp ne i64 %cv4928, 0
  br i1 %cond4929, label %bb_rcslotdrop1281, label %bb_rcslotdone1281
bb_rcslotdrop1281:
  %v4930 = load i64, ptr %slot10, align 8
  %p4931 = inttoptr i64 %v4930 to ptr
  store i32 0, ptr %p4931, align 4, !alias.scope !3, !noalias !4
  %v4932 = load i64, ptr %slot34, align 8
  store i64 %v4932, ptr %slot902, align 8
  %v4933 = load i64, ptr %slot11, align 8
  %p4934 = inttoptr i64 %v4933 to ptr
  %ld4935 = load i32, ptr %p4934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4935, ptr %slot903, align 8
  %v4936 = load i32, ptr %slot903, align 8
  %op4937 = and i32 %v4936, 28
  store i32 %op4937, ptr %slot904, align 8
  %v4938 = load i32, ptr %slot904, align 8
  %cv4939 = zext i32 %v4938 to i64
  %cond4940 = icmp ne i64 %cv4939, 0
  br i1 %cond4940, label %bb_rcslotrole1281, label %bb_rcslotowner1281
bb_rcslotrole1281:
  %v4941 = load i64, ptr %slot45, align 8
  store i64 %v4941, ptr %slot905, align 8
  %v4942 = load i64, ptr %slot905, align 8
  %v4943 = load i64, ptr %slot902, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4942, i64 %v4943) nomerge, !dbg !174
  br label %bb_rcslotdone1281
bb_rcslotowner1281:
  %v4944 = load i64, ptr %slot45, align 8
  store i64 %v4944, ptr %slot906, align 8
  %v4945 = load i64, ptr %slot906, align 8
  %v4946 = load i64, ptr %slot902, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4945, i64 %v4946) nomerge, !dbg !174
  br label %bb_rcslotdone1281
bb_rcslotdone1281:
  %v4947 = load i64, ptr %slot8, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  %ld4949 = load i32, ptr %p4948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4949, ptr %slot907, align 8
  %v4950 = load i32, ptr %slot907, align 8
  %cv4951 = zext i32 %v4950 to i64
  %cond4952 = icmp ne i64 %cv4951, 0
  br i1 %cond4952, label %bb_rcslotdrop1290, label %bb_rcslotdone1290
bb_rcslotdrop1290:
  %v4953 = load i64, ptr %slot8, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  store i32 0, ptr %p4954, align 4, !alias.scope !3, !noalias !4
  %v4955 = load i64, ptr %slot33, align 8
  store i64 %v4955, ptr %slot908, align 8
  %v4956 = load i64, ptr %slot9, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %ld4958 = load i32, ptr %p4957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4958, ptr %slot909, align 8
  %v4959 = load i32, ptr %slot909, align 8
  %op4960 = and i32 %v4959, 28
  store i32 %op4960, ptr %slot910, align 8
  %v4961 = load i32, ptr %slot910, align 8
  %cv4962 = zext i32 %v4961 to i64
  %cond4963 = icmp ne i64 %cv4962, 0
  br i1 %cond4963, label %bb_rcslotrole1290, label %bb_rcslotowner1290
bb_rcslotrole1290:
  %v4964 = load i64, ptr %slot45, align 8
  store i64 %v4964, ptr %slot911, align 8
  %v4965 = load i64, ptr %slot911, align 8
  %v4966 = load i64, ptr %slot908, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4965, i64 %v4966) nomerge, !dbg !174
  br label %bb_rcslotdone1290
bb_rcslotowner1290:
  %v4967 = load i64, ptr %slot45, align 8
  store i64 %v4967, ptr %slot912, align 8
  %v4968 = load i64, ptr %slot912, align 8
  %v4969 = load i64, ptr %slot908, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4968, i64 %v4969) nomerge, !dbg !174
  br label %bb_rcslotdone1290
bb_rcslotdone1290:
  %v4970 = load i64, ptr %slot6, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  %ld4972 = load i32, ptr %p4971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4972, ptr %slot913, align 8
  %v4973 = load i32, ptr %slot913, align 8
  %cv4974 = zext i32 %v4973 to i64
  %cond4975 = icmp ne i64 %cv4974, 0
  br i1 %cond4975, label %bb_rcslotdrop1299, label %bb_rcslotdone1299
bb_rcslotdrop1299:
  %v4976 = load i64, ptr %slot6, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  store i32 0, ptr %p4977, align 4, !alias.scope !3, !noalias !4
  %v4978 = load i64, ptr %slot32, align 8
  store i64 %v4978, ptr %slot914, align 8
  %v4979 = load i64, ptr %slot7, align 8
  %p4980 = inttoptr i64 %v4979 to ptr
  %ld4981 = load i32, ptr %p4980, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4981, ptr %slot915, align 8
  %v4982 = load i32, ptr %slot915, align 8
  %op4983 = and i32 %v4982, 28
  store i32 %op4983, ptr %slot916, align 8
  %v4984 = load i32, ptr %slot916, align 8
  %cv4985 = zext i32 %v4984 to i64
  %cond4986 = icmp ne i64 %cv4985, 0
  br i1 %cond4986, label %bb_rcslotrole1299, label %bb_rcslotowner1299
bb_rcslotrole1299:
  %v4987 = load i64, ptr %slot45, align 8
  store i64 %v4987, ptr %slot917, align 8
  %v4988 = load i64, ptr %slot917, align 8
  %v4989 = load i64, ptr %slot914, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v4988, i64 %v4989) nomerge, !dbg !174
  br label %bb_rcslotdone1299
bb_rcslotowner1299:
  %v4990 = load i64, ptr %slot45, align 8
  store i64 %v4990, ptr %slot918, align 8
  %v4991 = load i64, ptr %slot918, align 8
  %v4992 = load i64, ptr %slot914, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v4991, i64 %v4992) nomerge, !dbg !174
  br label %bb_rcslotdone1299
bb_rcslotdone1299:
  %v4993 = load i64, ptr %slot890, align 8
  ret i64 %v4993
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_loan(i64, i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64, i64, i64, i32)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a4cbc6c6c0218f39900afeed4ff7c544750a925fac1d1a44aa8aca0b6b6eaddf", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a4cbc6c6c0218f39900afeed4ff7c544750a925fac1d1a44aa8aca0b6b6eaddf", linkageName: "myl_f_a4cbc6c6c0218f39900afeed4ff7c544750a925fac1d1a44aa8aca0b6b6eaddf", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7566029518107555586, i64 0, !"myl_f_a4cbc6c6c0218f39900afeed4ff7c544750a925fac1d1a44aa8aca0b6b6eaddf"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!114 = !DILocation(line: 11, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!118 = !DILocation(line: 16, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!120 = !DILocation(line: 17, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!122 = !DILocation(line: 20, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!128 = !DILocation(line: 27, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!130 = !DILocation(line: 29, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!134 = !DILocation(line: 33, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!136 = !DILocation(line: 34, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!140 = !DILocation(line: 40, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!144 = !DILocation(line: 43, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!146 = !DILocation(line: 51, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!148 = !DILocation(line: 53, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!150 = !DILocation(line: 58, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!152 = !DILocation(line: 60, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!154 = !DILocation(line: 63, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!156 = !DILocation(line: 66, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!158 = !DILocation(line: 69, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!160 = !DILocation(line: 72, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!162 = !DILocation(line: 75, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!164 = !DILocation(line: 78, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!166 = !DILocation(line: 81, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647207)
!168 = !DILocation(line: 84, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!170 = !DILocation(line: 87, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647255)
!172 = !DILocation(line: 90, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!174 = !DILocation(line: 93, column: 0, scope: !175)
