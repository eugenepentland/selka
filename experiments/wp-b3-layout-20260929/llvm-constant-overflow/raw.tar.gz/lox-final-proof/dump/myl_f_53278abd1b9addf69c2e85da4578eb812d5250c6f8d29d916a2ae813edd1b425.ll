target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %callresult325 = alloca [16 x i8], align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %callresult391 = alloca [48 x i8], align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v735 = load i64, ptr %slot1, align 8
  %op736 = add i64 %v735, 32
  store i64 %op736, ptr %slot3, align 8
  %mem737 = alloca i8, i64 16, align 8
  %ptr738 = ptrtoint ptr %mem737 to i64
  store i64 %ptr738, ptr %slot4, align 8
  %mem739 = alloca i8, i64 8, align 8
  %ptr740 = ptrtoint ptr %mem739 to i64
  store i64 %ptr740, ptr %slot5, align 8
  %mem741 = alloca i8, i64 8, align 8
  %ptr742 = ptrtoint ptr %mem741 to i64
  store i64 %ptr742, ptr %slot6, align 8
  %mem743 = alloca i8, i64 8, align 8
  %ptr744 = ptrtoint ptr %mem743 to i64
  store i64 %ptr744, ptr %slot7, align 8
  %mem745 = alloca i8, i64 8, align 8
  %ptr746 = ptrtoint ptr %mem745 to i64
  store i64 %ptr746, ptr %slot8, align 8
  %mem747 = alloca i8, i64 8, align 8
  %ptr748 = ptrtoint ptr %mem747 to i64
  store i64 %ptr748, ptr %slot9, align 8
  %mem749 = alloca i8, i64 8, align 8
  %ptr750 = ptrtoint ptr %mem749 to i64
  store i64 %ptr750, ptr %slot10, align 8
  %mem751 = alloca i8, i64 8, align 8
  %ptr752 = ptrtoint ptr %mem751 to i64
  store i64 %ptr752, ptr %slot11, align 8
  %mem753 = alloca i8, i64 8, align 8
  %ptr754 = ptrtoint ptr %mem753 to i64
  store i64 %ptr754, ptr %slot12, align 8
  %mem755 = alloca i8, i64 8, align 8
  %ptr756 = ptrtoint ptr %mem755 to i64
  store i64 %ptr756, ptr %slot13, align 8
  %mem757 = alloca i8, i64 8, align 8
  %ptr758 = ptrtoint ptr %mem757 to i64
  store i64 %ptr758, ptr %slot14, align 8
  %mem759 = alloca i8, i64 8, align 8
  %ptr760 = ptrtoint ptr %mem759 to i64
  store i64 %ptr760, ptr %slot15, align 8
  %mem761 = alloca i8, i64 312, align 8
  %ptr762 = ptrtoint ptr %mem761 to i64
  store i64 %ptr762, ptr %slot16, align 8
  %mem763 = alloca i8, i64 8, align 8
  %ptr764 = ptrtoint ptr %mem763 to i64
  store i64 %ptr764, ptr %slot17, align 8
  %mem765 = alloca i8, i64 8, align 8
  %ptr766 = ptrtoint ptr %mem765 to i64
  store i64 %ptr766, ptr %slot18, align 8
  %mem767 = alloca i8, i64 8, align 8
  %ptr768 = ptrtoint ptr %mem767 to i64
  store i64 %ptr768, ptr %slot19, align 8
  %mem769 = alloca i8, i64 312, align 8
  %ptr770 = ptrtoint ptr %mem769 to i64
  store i64 %ptr770, ptr %slot20, align 8
  %mem771 = alloca i8, i64 8, align 8
  %ptr772 = ptrtoint ptr %mem771 to i64
  store i64 %ptr772, ptr %slot21, align 8
  %mem773 = alloca i8, i64 8, align 8
  %ptr774 = ptrtoint ptr %mem773 to i64
  store i64 %ptr774, ptr %slot22, align 8
  %mem775 = alloca i8, i64 8, align 8
  %ptr776 = ptrtoint ptr %mem775 to i64
  store i64 %ptr776, ptr %slot23, align 8
  %mem777 = alloca i8, i64 8, align 8
  %ptr778 = ptrtoint ptr %mem777 to i64
  store i64 %ptr778, ptr %slot24, align 8
  %mem779 = alloca i8, i64 8, align 8
  %ptr780 = ptrtoint ptr %mem779 to i64
  store i64 %ptr780, ptr %slot25, align 8
  %mem781 = alloca i8, i64 8, align 8
  %ptr782 = ptrtoint ptr %mem781 to i64
  store i64 %ptr782, ptr %slot26, align 8
  %mem783 = alloca i8, i64 8, align 8
  %ptr784 = ptrtoint ptr %mem783 to i64
  store i64 %ptr784, ptr %slot27, align 8
  %mem785 = alloca i8, i64 8, align 8
  %ptr786 = ptrtoint ptr %mem785 to i64
  store i64 %ptr786, ptr %slot28, align 8
  %mem787 = alloca i8, i64 312, align 8
  %ptr788 = ptrtoint ptr %mem787 to i64
  store i64 %ptr788, ptr %slot29, align 8
  %mem789 = alloca i8, i64 312, align 8
  %ptr790 = ptrtoint ptr %mem789 to i64
  store i64 %ptr790, ptr %slot30, align 8
  %mem791 = alloca i8, i64 48, align 8
  %ptr792 = ptrtoint ptr %mem791 to i64
  store i64 %ptr792, ptr %slot31, align 8
  %mem793 = alloca i8, i64 16, align 8
  %ptr794 = ptrtoint ptr %mem793 to i64
  store i64 %ptr794, ptr %slot32, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem795 = alloca i8, i64 8, align 8
  %ptr796 = ptrtoint ptr %mem795 to i64
  store i64 %ptr796, ptr %slot33, align 8
  %v797 = load i64, ptr %slot1, align 8
  %op798 = add i64 %v797, 64
  store i64 %op798, ptr %slot34, align 8
  %v799 = load i64, ptr %slot34, align 8
  %p800 = inttoptr i64 %v799 to ptr
  %ld801 = load i64, ptr %p800, align 8, !alias.scope !4, !noalias !3
  store i64 %ld801, ptr %slot35, align 8
  %stack802 = call ptr @llvm.stacksave()
  %stackaddr803 = ptrtoint ptr %stack802 to i64
  %v804 = load i64, ptr %slot35, align 8
  %cmp805 = icmp ult i64 %stackaddr803, %v804
  %cv806 = zext i1 %cmp805 to i64
  store i64 %cv806, ptr %slot36, align 8
  %v807 = load i64, ptr %slot36, align 8
  %cond808 = icmp ne i64 %v807, 0
  br i1 %cond808, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v809 = load i64, ptr %slot1, align 8
  %p810 = inttoptr i64 %v809 to ptr
  call void @myl_qbe_fail_frame(ptr %p810) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v811 = load i64, ptr %slot23, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i64 0, ptr %p812, align 8, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot24, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i64 0, ptr %p814, align 8, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot2, align 8
  %v816 = load i64, ptr %slot22, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot1, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %call820 = call ptr @myl_qbe_heap(ptr %p819) nomerge, !dbg !112
  %calladdr821 = ptrtoint ptr %call820 to i64
  store i64 %calladdr821, ptr %slot37, align 8
  %v822 = load i64, ptr %slot1, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %call824 = call i64 @myl_qbe_region_mark(ptr %p823) nomerge, !dbg !112
  store i64 %call824, ptr %slot38, align 8
  %v825 = load i64, ptr %slot5, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i32 0, ptr %p826, align 4, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot6, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 0, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot7, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 0, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot8, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i32 0, ptr %p832, align 4, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot9, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i32 0, ptr %p834, align 4, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot10, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i32 0, ptr %p836, align 4, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot11, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot12, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 0, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot13, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i32 0, ptr %p842, align 4, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot14, align 8
  %p844 = inttoptr i64 %v843 to ptr
  store i32 0, ptr %p844, align 4, !alias.scope !3, !noalias !4
  %v845 = load i64, ptr %slot15, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot6, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i32 2, ptr %p848, align 4, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot8, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i32 2, ptr %p850, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v851 = load i64, ptr %slot26, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 0, ptr %p852, align 8, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot26, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot39, align 8
  %v856 = load i64, ptr %slot39, align 8
  %cmp857 = icmp sge i64 %v856, 0
  %cv858 = zext i1 %cmp857 to i64
  store i64 %cv858, ptr %slot40, align 8
  %v859 = load i64, ptr %slot40, align 8
  %cond860 = icmp ne i64 %v859, 0
  br i1 %cond860, label %bb_success12, label %bb_failed12
bb_failed12:
  %v861 = load i64, ptr %slot1, align 8
  %p862 = inttoptr i64 %v861 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p862) nomerge, !dbg !114
  unreachable
bb_success12:
  %v863 = load i64, ptr %slot37, align 8
  %p864 = inttoptr i64 %v863 to ptr
  %p865 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v866 = load i64, ptr %slot39, align 8
  %call867 = call ptr @myl_native_list_new(ptr %p864, ptr %p865, i64 %v866) nomerge, !dbg !114
  %calladdr868 = ptrtoint ptr %call867 to i64
  store i64 %calladdr868, ptr %slot41, align 8
  %v869 = load i64, ptr %slot41, align 8
  %cond870 = icmp ne i64 %v869, 0
  br i1 %cond870, label %bb_success14, label %bb_failed14
bb_failed14:
  %v871 = load i64, ptr %slot1, align 8
  %p872 = inttoptr i64 %v871 to ptr
  call void @myl_qbe_fail_allocation(ptr %p872) nomerge, !dbg !114
  unreachable
bb_success14:
  %v873 = load i64, ptr %slot41, align 8
  %v874 = load i64, ptr %slot26, align 8
  %p875 = inttoptr i64 %v874 to ptr
  store i64 %v873, ptr %p875, align 8, !alias.scope !3, !noalias !4
  %v876 = load i64, ptr %slot26, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld878, ptr %slot42, align 8
  %v879 = load i64, ptr %slot42, align 8
  %v880 = load i64, ptr %slot18, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 %v879, ptr %p881, align 8, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot18, align 8
  store i64 %v882, ptr %slot43, align 8
  %v883 = load i64, ptr %slot20, align 8
  store i64 %v883, ptr %slot44, align 8
  %v884 = load i64, ptr %slot43, align 8
  %v885 = load i64, ptr %slot44, align 8
  %p886 = inttoptr i64 %v884 to ptr
  %p887 = inttoptr i64 %v885 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p887, ptr %p886, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v888 = load i64, ptr %slot14, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i32 2, ptr %p889, align 4, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot13, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 1, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot16, align 8
  store i64 %v892, ptr %slot45, align 8
  %v893 = load i64, ptr %slot20, align 8
  store i64 %v893, ptr %slot46, align 8
  %v894 = load i64, ptr %slot46, align 8
  %v895 = load i64, ptr %slot45, align 8
  %p896 = inttoptr i64 %v894 to ptr
  %p897 = inttoptr i64 %v895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p897, ptr %p896, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot10, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 2, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot14, align 8
  %p901 = inttoptr i64 %v900 to ptr
  %ld902 = load i32, ptr %p901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld902, ptr %slot47, align 8
  %v903 = load i32, ptr %slot47, align 8
  %v904 = load i64, ptr %slot10, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 %v903, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot13, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 0, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot9, align 8
  %p909 = inttoptr i64 %v908 to ptr
  store i32 1, ptr %p909, align 4, !alias.scope !3, !noalias !4
  %v910 = load i64, ptr %slot45, align 8
  %p911 = inttoptr i64 %v910 to ptr
  %ld912 = load i64, ptr %p911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld912, ptr %slot48, align 8
  %v913 = load i64, ptr %slot48, align 8
  %v914 = load i64, ptr %slot26, align 8
  %p915 = inttoptr i64 %v914 to ptr
  store i64 %v913, ptr %p915, align 8, !alias.scope !3, !noalias !4
  %v916 = load i64, ptr %slot26, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %ld918 = load i64, ptr %p917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld918, ptr %slot49, align 8
  %v919 = load i64, ptr %slot49, align 8
  %v920 = load i64, ptr %slot18, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i64 %v919, ptr %p921, align 8, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot18, align 8
  store i64 %v922, ptr %slot50, align 8
  %v923 = load i64, ptr %slot9, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i32, ptr %p924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld925, ptr %slot51, align 8
  %v926 = load i64, ptr %slot10, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot52, align 8
  %v929 = load i32, ptr %slot52, align 8
  %op930 = and i32 %v929, 24
  store i32 %op930, ptr %slot52, align 8
  %v931 = load i32, ptr %slot52, align 8
  %cmp932 = icmp eq i32 %v931, 0
  %cv933 = zext i1 %cmp932 to i32
  store i32 %cv933, ptr %slot53, align 8
  %v934 = load i32, ptr %slot51, align 8
  %v935 = load i32, ptr %slot53, align 8
  %op936 = and i32 %v934, %v935
  store i32 %op936, ptr %slot54, align 8
  %v937 = load i32, ptr %slot54, align 8
  %cv938 = zext i32 %v937 to i64
  %cond939 = icmp ne i64 %cv938, 0
  br i1 %cond939, label %bb_rcprivateown37, label %bb_rcprivateloan37
bb_rcprivateown37:
  %v940 = load i64, ptr %slot20, align 8
  store i64 %v940, ptr %slot55, align 8
  %v941 = load i64, ptr %slot38, align 8
  store i64 %v941, ptr %slot56, align 8
  %v942 = load i64, ptr %slot50, align 8
  %v943 = load i64, ptr %slot55, align 8
  %op944 = sub i64 %v942, %v943
  store i64 %op944, ptr %slot57, align 8
  %v945 = load i64, ptr %slot55, align 8
  %v946 = load i64, ptr %slot50, align 8
  %op947 = sub i64 %v945, %v946
  store i64 %op947, ptr %slot58, align 8
  %v948 = load i64, ptr %slot57, align 8
  %cmp949 = icmp ult i64 %v948, 8
  %cv950 = zext i1 %cmp949 to i32
  store i32 %cv950, ptr %slot59, align 8
  %v951 = load i64, ptr %slot58, align 8
  %cmp952 = icmp ult i64 %v951, 8
  %cv953 = zext i1 %cmp952 to i32
  store i32 %cv953, ptr %slot60, align 8
  %v954 = load i32, ptr %slot59, align 8
  %v955 = load i32, ptr %slot60, align 8
  %op956 = or i32 %v954, %v955
  store i32 %op956, ptr %slot61, align 8
  %v957 = load i32, ptr %slot61, align 8
  %cv958 = zext i32 %v957 to i64
  %cond959 = icmp ne i64 %cv958, 0
  br i1 %cond959, label %bb_rcmoveslow40, label %bb_rcmovecheck40
bb_rcmovecheck40:
  %v960 = load i64, ptr %slot50, align 8
  %p962 = inttoptr i64 %v960 to ptr
  %gep963 = getelementptr i8, ptr %p962, i64 0
  %op961 = ptrtoint ptr %gep963 to i64
  store i64 %op961, ptr %slot62, align 8
  %v964 = load i64, ptr %slot62, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %ld966 = load i64, ptr %p965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld966, ptr %slot63, align 8
  %v967 = load i64, ptr %slot63, align 8
  %cmp968 = icmp ne i64 %v967, 0
  %cv969 = zext i1 %cmp968 to i32
  store i32 %cv969, ptr %slot64, align 8
  %v970 = load i32, ptr %slot64, align 8
  %cv971 = zext i32 %v970 to i64
  %cond972 = icmp ne i64 %cv971, 0
  br i1 %cond972, label %bb_rcmoveheader48, label %bb_rcmovenext48
bb_rcmoveheader48:
  %v973 = load i64, ptr %slot63, align 8
  %op974 = sub i64 %v973, 16
  store i64 %op974, ptr %slot65, align 8
  %v975 = load i64, ptr %slot63, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %rgep977 = getelementptr i8, ptr %p976, i64 -16
  %ld978 = load i64, ptr %rgep977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld978, ptr %slot66, align 8
  %v979 = load i64, ptr %slot66, align 8
  %op980 = and i64 %v979, 5764607523034234881
  store i64 %op980, ptr %slot67, align 8
  %v981 = load i64, ptr %slot67, align 8
  %cmp982 = icmp ne i64 %v981, 0
  %cv983 = zext i1 %cmp982 to i32
  store i32 %cv983, ptr %slot68, align 8
  %v984 = load i32, ptr %slot68, align 8
  %cv985 = zext i32 %v984 to i64
  %cond986 = icmp ne i64 %cv985, 0
  br i1 %cond986, label %bb_rcmoveslow40, label %bb_rcmovenext48
bb_rcmovenext48:
  %v987 = load i64, ptr %slot50, align 8
  %v988 = load i64, ptr %slot55, align 8
  %p989 = inttoptr i64 %v987 to ptr
  %p990 = inttoptr i64 %v988 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p990, ptr %p989, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot50, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i64 0, ptr %p992, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved40
bb_rcmoveslow40:
  %v993 = load i64, ptr %slot37, align 8
  %v994 = load i64, ptr %slot55, align 8
  %v995 = load i64, ptr %slot50, align 8
  %v996 = load i64, ptr %slot56, align 8
  %cv997 = trunc i64 %v996 to i32
  %call998 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v993, i64 %v994, i64 %v995, i32 %cv997) nomerge, !dbg !116
  store i32 %call998, ptr %slot69, align 8
  %v999 = load i32, ptr %slot69, align 8
  %cv1000 = zext i32 %v999 to i64
  %cond1001 = icmp ne i64 %cv1000, 0
  br i1 %cond1001, label %bb_rcsuccess55, label %bb_rcfailure55
bb_rcfailure55:
  %v1002 = load i64, ptr %slot37, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  %call1004 = call i32 @myl_rc_take_failure(ptr %p1003) nomerge, !dbg !116
  store i32 %call1004, ptr %slot70, align 8
  %v1005 = load i64, ptr %slot1, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  %v1007 = load i32, ptr %slot70, align 8
  %call1008 = call i32 @myl_qbe_rc_status(ptr %p1006, i32 %v1007) nomerge, !dbg !116
  store i32 %call1008, ptr %slot71, align 8
  br label %bb_failure
bb_rcsuccess55:
  br label %bb_rcmoved40
bb_rcmoved40:
  %v1009 = load i64, ptr %slot9, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i32 0, ptr %p1010, align 4, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot14, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  store i32 2, ptr %p1012, align 4, !alias.scope !3, !noalias !4
  %v1013 = load i64, ptr %slot13, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  store i32 1, ptr %p1014, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared37
bb_rcprivateloan37:
  %v1015 = load i64, ptr %slot9, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ld1017 = load i32, ptr %p1016, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1017, ptr %slot72, align 8
  %v1018 = load i64, ptr %slot10, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %ld1020 = load i32, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1020, ptr %slot73, align 8
  %v1021 = load i32, ptr %slot73, align 8
  %cmp1022 = icmp eq i32 %v1021, 16
  %cv1023 = zext i1 %cmp1022 to i32
  store i32 %cv1023, ptr %slot74, align 8
  %v1024 = load i32, ptr %slot74, align 8
  %v1025 = load i32, ptr %slot72, align 8
  %op1026 = and i32 %v1024, %v1025
  store i32 %op1026, ptr %slot74, align 8
  %v1027 = load i32, ptr %slot74, align 8
  %cv1028 = zext i32 %v1027 to i64
  %cond1029 = icmp ne i64 %cv1028, 0
  br i1 %cond1029, label %bb_rcprivatemove37, label %bb_rcprivatenew37
bb_rcprivatemove37:
  %v1030 = load i64, ptr %slot20, align 8
  store i64 %v1030, ptr %slot75, align 8
  %v1031 = load i64, ptr %slot50, align 8
  %v1032 = load i64, ptr %slot75, align 8
  %p1033 = inttoptr i64 %v1031 to ptr
  %p1034 = inttoptr i64 %v1032 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1034, ptr %p1033, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1035 = load i64, ptr %slot50, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  store i64 0, ptr %p1036, align 8, !alias.scope !3, !noalias !4
  %v1037 = load i64, ptr %slot14, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  store i32 2, ptr %p1038, align 4, !alias.scope !3, !noalias !4
  %v1039 = load i64, ptr %slot14, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i32 16, ptr %p1040, align 4, !alias.scope !3, !noalias !4
  %v1041 = load i64, ptr %slot13, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  store i32 1, ptr %p1042, align 4, !alias.scope !3, !noalias !4
  %v1043 = load i64, ptr %slot9, align 8
  %p1044 = inttoptr i64 %v1043 to ptr
  store i32 0, ptr %p1044, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared37
bb_rcprivatenew37:
  %v1045 = load i64, ptr %slot20, align 8
  store i64 %v1045, ptr %slot76, align 8
  %v1046 = load i64, ptr %slot50, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i64, ptr %p1047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1048, ptr %slot77, align 8
  %v1049 = load i64, ptr %slot77, align 8
  %cmp1050 = icmp ne i64 %v1049, 0
  %cv1051 = zext i1 %cmp1050 to i32
  store i32 %cv1051, ptr %slot78, align 8
  %v1052 = load i32, ptr %slot78, align 8
  %cv1053 = zext i32 %v1052 to i64
  %cond1054 = icmp ne i64 %cv1053, 0
  br i1 %cond1054, label %bb_rcgnn73, label %bb_rcgstore73
bb_rcgnn73:
  %v1055 = load i64, ptr %slot77, align 8
  %op1056 = sub i64 %v1055, 16
  store i64 %op1056, ptr %slot79, align 8
  %v1057 = load i64, ptr %slot77, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  %rgep1059 = getelementptr i8, ptr %p1058, i64 -16
  %ld1060 = load i64, ptr %rgep1059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1060, ptr %slot80, align 8
  %v1061 = load i64, ptr %slot80, align 8
  %op1062 = and i64 %v1061, 4611686018427387906
  store i64 %op1062, ptr %slot81, align 8
  %v1063 = load i64, ptr %slot81, align 8
  %cmp1064 = icmp ne i64 %v1063, 0
  %cv1065 = zext i1 %cmp1064 to i32
  store i32 %cv1065, ptr %slot82, align 8
  %v1066 = load i32, ptr %slot82, align 8
  %cv1067 = zext i32 %v1066 to i64
  %cond1068 = icmp ne i64 %cv1067, 0
  br i1 %cond1068, label %bb_rcgstore73, label %bb_rcginc73
bb_rcginc73:
  %v1069 = load i64, ptr %slot77, align 8
  %op1070 = sub i64 %v1069, 24
  store i64 %op1070, ptr %slot83, align 8
  %v1071 = load i64, ptr %slot77, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  %rgep1073 = getelementptr i8, ptr %p1072, i64 -24
  %ld1074 = load i64, ptr %rgep1073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1074, ptr %slot84, align 8
  %v1075 = load i64, ptr %slot84, align 8
  %op1076 = add i64 %v1075, 1
  store i64 %op1076, ptr %slot85, align 8
  %v1077 = load i64, ptr %slot85, align 8
  %cmp1078 = icmp eq i64 %v1077, 0
  %cv1079 = zext i1 %cmp1078 to i32
  store i32 %cv1079, ptr %slot86, align 8
  %v1080 = load i32, ptr %slot86, align 8
  %cv1081 = zext i32 %v1080 to i64
  %cond1082 = icmp ne i64 %cv1081, 0
  br i1 %cond1082, label %bb_rcglimit73, label %bb_rcgcapacity73
bb_rcglimit73:
  %v1083 = load i64, ptr %slot1, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %call1085 = call i32 @myl_qbe_rc_status(ptr %p1084, i32 2) nomerge, !dbg !116
  store i32 %call1085, ptr %slot87, align 8
  br label %bb_failure
bb_rcgcapacity73:
  %v1086 = load i64, ptr %slot85, align 8
  %v1087 = load i64, ptr %slot77, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %rgep1089 = getelementptr i8, ptr %p1088, i64 -24
  store i64 %v1086, ptr %rgep1089, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore73
bb_rcgstore73:
  %v1090 = load i64, ptr %slot77, align 8
  %v1091 = load i64, ptr %slot76, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  store i64 %v1090, ptr %p1092, align 8, !alias.scope !3, !noalias !4
  %v1093 = load i64, ptr %slot14, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  store i32 2, ptr %p1094, align 4, !alias.scope !3, !noalias !4
  %v1095 = load i64, ptr %slot14, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  store i32 16, ptr %p1096, align 4, !alias.scope !3, !noalias !4
  %v1097 = load i64, ptr %slot13, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i32 1, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot9, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i32, ptr %p1100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1101, ptr %slot88, align 8
  %v1102 = load i32, ptr %slot88, align 8
  %cv1103 = zext i32 %v1102 to i64
  %cond1104 = icmp ne i64 %cv1103, 0
  br i1 %cond1104, label %bb_rcslotdrop89, label %bb_rcslotdone89
bb_rcslotdrop89:
  %v1105 = load i64, ptr %slot9, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i32 0, ptr %p1106, align 4, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot16, align 8
  store i64 %v1107, ptr %slot89, align 8
  %v1108 = load i64, ptr %slot10, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %ld1110 = load i32, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1110, ptr %slot90, align 8
  %v1111 = load i32, ptr %slot90, align 8
  %op1112 = and i32 %v1111, 28
  store i32 %op1112, ptr %slot91, align 8
  %v1113 = load i32, ptr %slot91, align 8
  %cv1114 = zext i32 %v1113 to i64
  %cond1115 = icmp ne i64 %cv1114, 0
  br i1 %cond1115, label %bb_rcslotrole89, label %bb_rcslotowner89
bb_rcslotrole89:
  %v1116 = load i64, ptr %slot37, align 8
  store i64 %v1116, ptr %slot92, align 8
  %v1117 = load i64, ptr %slot89, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i64, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1119, ptr %slot93, align 8
  %v1120 = load i64, ptr %slot93, align 8
  %cmp1121 = icmp ne i64 %v1120, 0
  %cv1122 = zext i1 %cmp1121 to i32
  store i32 %cv1122, ptr %slot94, align 8
  %v1123 = load i32, ptr %slot94, align 8
  %cv1124 = zext i32 %v1123 to i64
  %cond1125 = icmp ne i64 %cv1124, 0
  br i1 %cond1125, label %bb_rcgnn105, label %bb_rcgdone105
bb_rcgnn105:
  %v1126 = load i64, ptr %slot93, align 8
  %op1127 = sub i64 %v1126, 16
  store i64 %op1127, ptr %slot95, align 8
  %v1128 = load i64, ptr %slot93, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %rgep1130 = getelementptr i8, ptr %p1129, i64 -16
  %ld1131 = load i64, ptr %rgep1130, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1131, ptr %slot96, align 8
  %v1132 = load i64, ptr %slot96, align 8
  %op1133 = and i64 %v1132, 4611686018427387906
  store i64 %op1133, ptr %slot97, align 8
  %v1134 = load i64, ptr %slot97, align 8
  %cmp1135 = icmp ne i64 %v1134, 0
  %cv1136 = zext i1 %cmp1135 to i32
  store i32 %cv1136, ptr %slot98, align 8
  %v1137 = load i32, ptr %slot98, align 8
  %cv1138 = zext i32 %v1137 to i64
  %cond1139 = icmp ne i64 %cv1138, 0
  br i1 %cond1139, label %bb_rcgclear105, label %bb_rcgcounted105
bb_rcgcounted105:
  %v1140 = load i64, ptr %slot93, align 8
  %op1141 = sub i64 %v1140, 24
  store i64 %op1141, ptr %slot99, align 8
  %v1142 = load i64, ptr %slot93, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %rgep1144 = getelementptr i8, ptr %p1143, i64 -24
  %ld1145 = load i64, ptr %rgep1144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1145, ptr %slot100, align 8
  %v1146 = load i64, ptr %slot100, align 8
  %op1147 = sub i64 %v1146, 1
  store i64 %op1147, ptr %slot101, align 8
  %v1148 = load i64, ptr %slot101, align 8
  %cmp1149 = icmp eq i64 %v1148, 0
  %cv1150 = zext i1 %cmp1149 to i32
  store i32 %cv1150, ptr %slot102, align 8
  %v1151 = load i32, ptr %slot102, align 8
  %cv1152 = zext i32 %v1151 to i64
  %cond1153 = icmp ne i64 %cv1152, 0
  br i1 %cond1153, label %bb_rcglast105, label %bb_rcgdec105
bb_rcglast105:
  %v1154 = load i64, ptr %slot93, align 8
  %op1155 = sub i64 %v1154, 32
  store i64 %op1155, ptr %slot103, align 8
  %v1156 = load i64, ptr %slot93, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %rgep1158 = getelementptr i8, ptr %p1157, i64 -32
  %ld1159 = load i64, ptr %rgep1158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1159, ptr %slot104, align 8
  %v1160 = load i64, ptr %slot104, align 8
  %cmp1161 = icmp ne i64 %v1160, 0
  %cv1162 = zext i1 %cmp1161 to i32
  store i32 %cv1162, ptr %slot105, align 8
  %v1163 = load i32, ptr %slot105, align 8
  %cv1164 = zext i32 %v1163 to i64
  %cond1165 = icmp ne i64 %cv1164, 0
  br i1 %cond1165, label %bb_rcgdec105, label %bb_rcgslow105
bb_rcgslow105:
  %v1166 = load i64, ptr %slot92, align 8
  %v1167 = load i64, ptr %slot89, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1166, i64 %v1167) nomerge, !dbg !116
  br label %bb_rcgdone105
bb_rcgdec105:
  %v1168 = load i64, ptr %slot101, align 8
  %v1169 = load i64, ptr %slot93, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %rgep1171 = getelementptr i8, ptr %p1170, i64 -24
  store i64 %v1168, ptr %rgep1171, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear105
bb_rcgclear105:
  %v1172 = load i64, ptr %slot89, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i64 0, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone105
bb_rcgdone105:
  br label %bb_rcslotdone89
bb_rcslotowner89:
  %v1174 = load i64, ptr %slot37, align 8
  store i64 %v1174, ptr %slot106, align 8
  %v1175 = load i64, ptr %slot89, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %ld1177 = load i64, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1177, ptr %slot107, align 8
  %v1178 = load i64, ptr %slot107, align 8
  %cmp1179 = icmp ne i64 %v1178, 0
  %cv1180 = zext i1 %cmp1179 to i32
  store i32 %cv1180, ptr %slot108, align 8
  %v1181 = load i32, ptr %slot108, align 8
  %cv1182 = zext i32 %v1181 to i64
  %cond1183 = icmp ne i64 %cv1182, 0
  br i1 %cond1183, label %bb_rcgnn120, label %bb_rcgdone120
bb_rcgnn120:
  %v1184 = load i64, ptr %slot107, align 8
  %op1185 = sub i64 %v1184, 16
  store i64 %op1185, ptr %slot109, align 8
  %v1186 = load i64, ptr %slot107, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %rgep1188 = getelementptr i8, ptr %p1187, i64 -16
  %ld1189 = load i64, ptr %rgep1188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1189, ptr %slot110, align 8
  %v1190 = load i64, ptr %slot110, align 8
  %op1191 = and i64 %v1190, 4611686018427387906
  store i64 %op1191, ptr %slot111, align 8
  %v1192 = load i64, ptr %slot111, align 8
  %cmp1193 = icmp ne i64 %v1192, 0
  %cv1194 = zext i1 %cmp1193 to i32
  store i32 %cv1194, ptr %slot112, align 8
  %v1195 = load i32, ptr %slot112, align 8
  %cv1196 = zext i32 %v1195 to i64
  %cond1197 = icmp ne i64 %cv1196, 0
  br i1 %cond1197, label %bb_rcgclear120, label %bb_rcgcounted120
bb_rcgcounted120:
  %v1198 = load i64, ptr %slot107, align 8
  %op1199 = sub i64 %v1198, 32
  store i64 %op1199, ptr %slot113, align 8
  %v1200 = load i64, ptr %slot107, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %rgep1202 = getelementptr i8, ptr %p1201, i64 -32
  %ld1203 = load i64, ptr %rgep1202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1203, ptr %slot114, align 8
  %v1204 = load i64, ptr %slot114, align 8
  %op1205 = sub i64 %v1204, 1
  store i64 %op1205, ptr %slot115, align 8
  %v1206 = load i64, ptr %slot115, align 8
  %cmp1207 = icmp eq i64 %v1206, 0
  %cv1208 = zext i1 %cmp1207 to i32
  store i32 %cv1208, ptr %slot116, align 8
  %v1209 = load i32, ptr %slot116, align 8
  %cv1210 = zext i32 %v1209 to i64
  %cond1211 = icmp ne i64 %cv1210, 0
  br i1 %cond1211, label %bb_rcglast120, label %bb_rcgdec120
bb_rcglast120:
  %v1212 = load i64, ptr %slot107, align 8
  %op1213 = sub i64 %v1212, 24
  store i64 %op1213, ptr %slot117, align 8
  %v1214 = load i64, ptr %slot107, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  %rgep1216 = getelementptr i8, ptr %p1215, i64 -24
  %ld1217 = load i64, ptr %rgep1216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1217, ptr %slot118, align 8
  %v1218 = load i64, ptr %slot118, align 8
  %cmp1219 = icmp ne i64 %v1218, 0
  %cv1220 = zext i1 %cmp1219 to i32
  store i32 %cv1220, ptr %slot119, align 8
  %v1221 = load i32, ptr %slot119, align 8
  %cv1222 = zext i32 %v1221 to i64
  %cond1223 = icmp ne i64 %cv1222, 0
  br i1 %cond1223, label %bb_rcgdec120, label %bb_rcgslow120
bb_rcgslow120:
  %v1224 = load i64, ptr %slot106, align 8
  %v1225 = load i64, ptr %slot89, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1224, i64 %v1225) nomerge, !dbg !116
  br label %bb_rcgdone120
bb_rcgdec120:
  %v1226 = load i64, ptr %slot115, align 8
  %v1227 = load i64, ptr %slot107, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %rgep1229 = getelementptr i8, ptr %p1228, i64 -32
  store i64 %v1226, ptr %rgep1229, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear120
bb_rcgclear120:
  %v1230 = load i64, ptr %slot89, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i64 0, ptr %p1231, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone120
bb_rcgdone120:
  br label %bb_rcslotdone89
bb_rcslotdone89:
  br label %bb_rcprivateprepared37
bb_rcprivateprepared37:
  %v1232 = load i64, ptr %slot5, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  %ld1234 = load i32, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1234, ptr %slot120, align 8
  %v1235 = load i32, ptr %slot120, align 8
  %cv1236 = zext i32 %v1235 to i64
  %cond1237 = icmp ne i64 %cv1236, 0
  br i1 %cond1237, label %bb_rcslotdrop127, label %bb_rcslotdone127
bb_rcslotdrop127:
  %v1238 = load i64, ptr %slot5, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i32 0, ptr %p1239, align 4, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot23, align 8
  store i64 %v1240, ptr %slot121, align 8
  %v1241 = load i64, ptr %slot6, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i32, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1243, ptr %slot122, align 8
  %v1244 = load i32, ptr %slot122, align 8
  %op1245 = and i32 %v1244, 28
  store i32 %op1245, ptr %slot123, align 8
  %v1246 = load i32, ptr %slot123, align 8
  %cv1247 = zext i32 %v1246 to i64
  %cond1248 = icmp ne i64 %cv1247, 0
  br i1 %cond1248, label %bb_rcslotrole127, label %bb_rcslotowner127
bb_rcslotrole127:
  %v1249 = load i64, ptr %slot37, align 8
  store i64 %v1249, ptr %slot124, align 8
  %v1250 = load i64, ptr %slot121, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i64, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1252, ptr %slot125, align 8
  %v1253 = load i64, ptr %slot125, align 8
  %cmp1254 = icmp ne i64 %v1253, 0
  %cv1255 = zext i1 %cmp1254 to i32
  store i32 %cv1255, ptr %slot126, align 8
  %v1256 = load i32, ptr %slot126, align 8
  %cv1257 = zext i32 %v1256 to i64
  %cond1258 = icmp ne i64 %cv1257, 0
  br i1 %cond1258, label %bb_rcgnn143, label %bb_rcgdone143
bb_rcgnn143:
  %v1259 = load i64, ptr %slot125, align 8
  %op1260 = sub i64 %v1259, 16
  store i64 %op1260, ptr %slot127, align 8
  %v1261 = load i64, ptr %slot125, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %rgep1263 = getelementptr i8, ptr %p1262, i64 -16
  %ld1264 = load i64, ptr %rgep1263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1264, ptr %slot128, align 8
  %v1265 = load i64, ptr %slot128, align 8
  %op1266 = and i64 %v1265, 4611686018427387906
  store i64 %op1266, ptr %slot129, align 8
  %v1267 = load i64, ptr %slot129, align 8
  %cmp1268 = icmp ne i64 %v1267, 0
  %cv1269 = zext i1 %cmp1268 to i32
  store i32 %cv1269, ptr %slot130, align 8
  %v1270 = load i32, ptr %slot130, align 8
  %cv1271 = zext i32 %v1270 to i64
  %cond1272 = icmp ne i64 %cv1271, 0
  br i1 %cond1272, label %bb_rcgclear143, label %bb_rcgcounted143
bb_rcgcounted143:
  %v1273 = load i64, ptr %slot125, align 8
  %op1274 = sub i64 %v1273, 24
  store i64 %op1274, ptr %slot131, align 8
  %v1275 = load i64, ptr %slot125, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %rgep1277 = getelementptr i8, ptr %p1276, i64 -24
  %ld1278 = load i64, ptr %rgep1277, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1278, ptr %slot132, align 8
  %v1279 = load i64, ptr %slot132, align 8
  %op1280 = sub i64 %v1279, 1
  store i64 %op1280, ptr %slot133, align 8
  %v1281 = load i64, ptr %slot133, align 8
  %cmp1282 = icmp eq i64 %v1281, 0
  %cv1283 = zext i1 %cmp1282 to i32
  store i32 %cv1283, ptr %slot134, align 8
  %v1284 = load i32, ptr %slot134, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rcglast143, label %bb_rcgdec143
bb_rcglast143:
  %v1287 = load i64, ptr %slot125, align 8
  %op1288 = sub i64 %v1287, 32
  store i64 %op1288, ptr %slot135, align 8
  %v1289 = load i64, ptr %slot125, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %rgep1291 = getelementptr i8, ptr %p1290, i64 -32
  %ld1292 = load i64, ptr %rgep1291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1292, ptr %slot136, align 8
  %v1293 = load i64, ptr %slot136, align 8
  %cmp1294 = icmp ne i64 %v1293, 0
  %cv1295 = zext i1 %cmp1294 to i32
  store i32 %cv1295, ptr %slot137, align 8
  %v1296 = load i32, ptr %slot137, align 8
  %cv1297 = zext i32 %v1296 to i64
  %cond1298 = icmp ne i64 %cv1297, 0
  br i1 %cond1298, label %bb_rcgdec143, label %bb_rcgslow143
bb_rcgslow143:
  %v1299 = load i64, ptr %slot124, align 8
  %v1300 = load i64, ptr %slot121, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1299, i64 %v1300) nomerge, !dbg !116
  br label %bb_rcgdone143
bb_rcgdec143:
  %v1301 = load i64, ptr %slot133, align 8
  %v1302 = load i64, ptr %slot125, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %rgep1304 = getelementptr i8, ptr %p1303, i64 -24
  store i64 %v1301, ptr %rgep1304, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear143
bb_rcgclear143:
  %v1305 = load i64, ptr %slot121, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  store i64 0, ptr %p1306, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone143
bb_rcgdone143:
  br label %bb_rcslotdone127
bb_rcslotowner127:
  %v1307 = load i64, ptr %slot37, align 8
  store i64 %v1307, ptr %slot138, align 8
  %v1308 = load i64, ptr %slot121, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  %ld1310 = load i64, ptr %p1309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1310, ptr %slot139, align 8
  %v1311 = load i64, ptr %slot139, align 8
  %cmp1312 = icmp ne i64 %v1311, 0
  %cv1313 = zext i1 %cmp1312 to i32
  store i32 %cv1313, ptr %slot140, align 8
  %v1314 = load i32, ptr %slot140, align 8
  %cv1315 = zext i32 %v1314 to i64
  %cond1316 = icmp ne i64 %cv1315, 0
  br i1 %cond1316, label %bb_rcgnn158, label %bb_rcgdone158
bb_rcgnn158:
  %v1317 = load i64, ptr %slot139, align 8
  %op1318 = sub i64 %v1317, 16
  store i64 %op1318, ptr %slot141, align 8
  %v1319 = load i64, ptr %slot139, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  %rgep1321 = getelementptr i8, ptr %p1320, i64 -16
  %ld1322 = load i64, ptr %rgep1321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1322, ptr %slot142, align 8
  %v1323 = load i64, ptr %slot142, align 8
  %op1324 = and i64 %v1323, 4611686018427387906
  store i64 %op1324, ptr %slot143, align 8
  %v1325 = load i64, ptr %slot143, align 8
  %cmp1326 = icmp ne i64 %v1325, 0
  %cv1327 = zext i1 %cmp1326 to i32
  store i32 %cv1327, ptr %slot144, align 8
  %v1328 = load i32, ptr %slot144, align 8
  %cv1329 = zext i32 %v1328 to i64
  %cond1330 = icmp ne i64 %cv1329, 0
  br i1 %cond1330, label %bb_rcgclear158, label %bb_rcgcounted158
bb_rcgcounted158:
  %v1331 = load i64, ptr %slot139, align 8
  %op1332 = sub i64 %v1331, 32
  store i64 %op1332, ptr %slot145, align 8
  %v1333 = load i64, ptr %slot139, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %rgep1335 = getelementptr i8, ptr %p1334, i64 -32
  %ld1336 = load i64, ptr %rgep1335, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1336, ptr %slot146, align 8
  %v1337 = load i64, ptr %slot146, align 8
  %op1338 = sub i64 %v1337, 1
  store i64 %op1338, ptr %slot147, align 8
  %v1339 = load i64, ptr %slot147, align 8
  %cmp1340 = icmp eq i64 %v1339, 0
  %cv1341 = zext i1 %cmp1340 to i32
  store i32 %cv1341, ptr %slot148, align 8
  %v1342 = load i32, ptr %slot148, align 8
  %cv1343 = zext i32 %v1342 to i64
  %cond1344 = icmp ne i64 %cv1343, 0
  br i1 %cond1344, label %bb_rcglast158, label %bb_rcgdec158
bb_rcglast158:
  %v1345 = load i64, ptr %slot139, align 8
  %op1346 = sub i64 %v1345, 24
  store i64 %op1346, ptr %slot149, align 8
  %v1347 = load i64, ptr %slot139, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %rgep1349 = getelementptr i8, ptr %p1348, i64 -24
  %ld1350 = load i64, ptr %rgep1349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1350, ptr %slot150, align 8
  %v1351 = load i64, ptr %slot150, align 8
  %cmp1352 = icmp ne i64 %v1351, 0
  %cv1353 = zext i1 %cmp1352 to i32
  store i32 %cv1353, ptr %slot151, align 8
  %v1354 = load i32, ptr %slot151, align 8
  %cv1355 = zext i32 %v1354 to i64
  %cond1356 = icmp ne i64 %cv1355, 0
  br i1 %cond1356, label %bb_rcgdec158, label %bb_rcgslow158
bb_rcgslow158:
  %v1357 = load i64, ptr %slot138, align 8
  %v1358 = load i64, ptr %slot121, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1357, i64 %v1358) nomerge, !dbg !116
  br label %bb_rcgdone158
bb_rcgdec158:
  %v1359 = load i64, ptr %slot147, align 8
  %v1360 = load i64, ptr %slot139, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  %rgep1362 = getelementptr i8, ptr %p1361, i64 -32
  store i64 %v1359, ptr %rgep1362, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear158
bb_rcgclear158:
  %v1363 = load i64, ptr %slot121, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  store i64 0, ptr %p1364, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone158
bb_rcgdone158:
  br label %bb_rcslotdone127
bb_rcslotdone127:
  %v1365 = load i64, ptr %slot23, align 8
  store i64 %v1365, ptr %slot152, align 8
  %v1366 = load i64, ptr %slot20, align 8
  store i64 %v1366, ptr %slot153, align 8
  %v1367 = load i64, ptr %slot153, align 8
  %v1368 = load i64, ptr %slot152, align 8
  %p1369 = inttoptr i64 %v1367 to ptr
  %p1370 = inttoptr i64 %v1368 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1370, ptr %p1369, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot13, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 0, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot6, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 2, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot14, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i32, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1377, ptr %slot154, align 8
  %v1378 = load i32, ptr %slot154, align 8
  %v1379 = load i64, ptr %slot6, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i32 %v1378, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot5, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  store i32 1, ptr %p1382, align 4, !alias.scope !3, !noalias !4
  %v1383 = load i64, ptr %slot23, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %ld1385 = load i64, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1385, ptr %slot155, align 8
  %v1386 = load i64, ptr %slot155, align 8
  %v1387 = load i64, ptr %slot26, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  store i64 %v1386, ptr %p1388, align 8, !alias.scope !3, !noalias !4
  %v1389 = load i64, ptr %slot26, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %ld1391 = load i64, ptr %p1390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1391, ptr %slot156, align 8
  %v1392 = load i64, ptr %slot156, align 8
  %v1393 = load i64, ptr %slot18, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i64 %v1392, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot18, align 8
  store i64 %v1395, ptr %slot157, align 8
  %v1396 = load i64, ptr %slot9, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %ld1398 = load i32, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1398, ptr %slot158, align 8
  %v1399 = load i64, ptr %slot10, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i32, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1401, ptr %slot159, align 8
  %v1402 = load i32, ptr %slot159, align 8
  %op1403 = and i32 %v1402, 24
  store i32 %op1403, ptr %slot159, align 8
  %v1404 = load i32, ptr %slot159, align 8
  %cmp1405 = icmp eq i32 %v1404, 0
  %cv1406 = zext i1 %cmp1405 to i32
  store i32 %cv1406, ptr %slot160, align 8
  %v1407 = load i32, ptr %slot158, align 8
  %v1408 = load i32, ptr %slot160, align 8
  %op1409 = and i32 %v1407, %v1408
  store i32 %op1409, ptr %slot161, align 8
  %v1410 = load i32, ptr %slot161, align 8
  %cv1411 = zext i32 %v1410 to i64
  %cond1412 = icmp ne i64 %cv1411, 0
  br i1 %cond1412, label %bb_rctake172, label %bb_rccopy172
bb_rctake172:
  %v1413 = load i64, ptr %slot20, align 8
  store i64 %v1413, ptr %slot162, align 8
  %v1414 = load i64, ptr %slot38, align 8
  store i64 %v1414, ptr %slot163, align 8
  %v1415 = load i64, ptr %slot157, align 8
  %v1416 = load i64, ptr %slot162, align 8
  %op1417 = sub i64 %v1415, %v1416
  store i64 %op1417, ptr %slot164, align 8
  %v1418 = load i64, ptr %slot162, align 8
  %v1419 = load i64, ptr %slot157, align 8
  %op1420 = sub i64 %v1418, %v1419
  store i64 %op1420, ptr %slot165, align 8
  %v1421 = load i64, ptr %slot164, align 8
  %cmp1422 = icmp ult i64 %v1421, 8
  %cv1423 = zext i1 %cmp1422 to i32
  store i32 %cv1423, ptr %slot166, align 8
  %v1424 = load i64, ptr %slot165, align 8
  %cmp1425 = icmp ult i64 %v1424, 8
  %cv1426 = zext i1 %cmp1425 to i32
  store i32 %cv1426, ptr %slot167, align 8
  %v1427 = load i32, ptr %slot166, align 8
  %v1428 = load i32, ptr %slot167, align 8
  %op1429 = or i32 %v1427, %v1428
  store i32 %op1429, ptr %slot168, align 8
  %v1430 = load i32, ptr %slot168, align 8
  %cv1431 = zext i32 %v1430 to i64
  %cond1432 = icmp ne i64 %cv1431, 0
  br i1 %cond1432, label %bb_rcmoveslow181, label %bb_rcmovecheck181
bb_rcmovecheck181:
  %v1433 = load i64, ptr %slot157, align 8
  %p1435 = inttoptr i64 %v1433 to ptr
  %gep1436 = getelementptr i8, ptr %p1435, i64 0
  %op1434 = ptrtoint ptr %gep1436 to i64
  store i64 %op1434, ptr %slot169, align 8
  %v1437 = load i64, ptr %slot169, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  %ld1439 = load i64, ptr %p1438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1439, ptr %slot170, align 8
  %v1440 = load i64, ptr %slot170, align 8
  %cmp1441 = icmp ne i64 %v1440, 0
  %cv1442 = zext i1 %cmp1441 to i32
  store i32 %cv1442, ptr %slot171, align 8
  %v1443 = load i32, ptr %slot171, align 8
  %cv1444 = zext i32 %v1443 to i64
  %cond1445 = icmp ne i64 %cv1444, 0
  br i1 %cond1445, label %bb_rcmoveheader189, label %bb_rcmovenext189
bb_rcmoveheader189:
  %v1446 = load i64, ptr %slot170, align 8
  %op1447 = sub i64 %v1446, 16
  store i64 %op1447, ptr %slot172, align 8
  %v1448 = load i64, ptr %slot170, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  %rgep1450 = getelementptr i8, ptr %p1449, i64 -16
  %ld1451 = load i64, ptr %rgep1450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1451, ptr %slot173, align 8
  %v1452 = load i64, ptr %slot173, align 8
  %op1453 = and i64 %v1452, 5764607523034234881
  store i64 %op1453, ptr %slot174, align 8
  %v1454 = load i64, ptr %slot174, align 8
  %cmp1455 = icmp ne i64 %v1454, 0
  %cv1456 = zext i1 %cmp1455 to i32
  store i32 %cv1456, ptr %slot175, align 8
  %v1457 = load i32, ptr %slot175, align 8
  %cv1458 = zext i32 %v1457 to i64
  %cond1459 = icmp ne i64 %cv1458, 0
  br i1 %cond1459, label %bb_rcmoveslow181, label %bb_rcmovenext189
bb_rcmovenext189:
  %v1460 = load i64, ptr %slot157, align 8
  %v1461 = load i64, ptr %slot162, align 8
  %p1462 = inttoptr i64 %v1460 to ptr
  %p1463 = inttoptr i64 %v1461 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1463, ptr %p1462, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot157, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  store i64 0, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved181
bb_rcmoveslow181:
  %v1466 = load i64, ptr %slot37, align 8
  %v1467 = load i64, ptr %slot162, align 8
  %v1468 = load i64, ptr %slot157, align 8
  %v1469 = load i64, ptr %slot163, align 8
  %cv1470 = trunc i64 %v1469 to i32
  %call1471 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1466, i64 %v1467, i64 %v1468, i32 %cv1470) nomerge, !dbg !118
  store i32 %call1471, ptr %slot176, align 8
  %v1472 = load i32, ptr %slot176, align 8
  %cv1473 = zext i32 %v1472 to i64
  %cond1474 = icmp ne i64 %cv1473, 0
  br i1 %cond1474, label %bb_rcsuccess196, label %bb_rcfailure196
bb_rcfailure196:
  %v1475 = load i64, ptr %slot37, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %call1477 = call i32 @myl_rc_take_failure(ptr %p1476) nomerge, !dbg !118
  store i32 %call1477, ptr %slot177, align 8
  %v1478 = load i64, ptr %slot1, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  %v1480 = load i32, ptr %slot177, align 8
  %call1481 = call i32 @myl_qbe_rc_status(ptr %p1479, i32 %v1480) nomerge, !dbg !118
  store i32 %call1481, ptr %slot178, align 8
  br label %bb_failure
bb_rcsuccess196:
  br label %bb_rcmoved181
bb_rcmoved181:
  %v1482 = load i64, ptr %slot9, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  store i32 0, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  %v1484 = load i64, ptr %slot14, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  store i32 2, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  %v1486 = load i64, ptr %slot13, align 8
  %p1487 = inttoptr i64 %v1486 to ptr
  store i32 1, ptr %p1487, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared172
bb_rccopy172:
  %v1488 = load i64, ptr %slot20, align 8
  store i64 %v1488, ptr %slot179, align 8
  %v1489 = load i64, ptr %slot38, align 8
  store i64 %v1489, ptr %slot180, align 8
  %v1490 = load i64, ptr %slot157, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  %ld1492 = load i64, ptr %p1491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1492, ptr %slot181, align 8
  %v1493 = load i64, ptr %slot181, align 8
  %cmp1494 = icmp ne i64 %v1493, 0
  %cv1495 = zext i1 %cmp1494 to i32
  store i32 %cv1495, ptr %slot182, align 8
  %v1496 = load i32, ptr %slot182, align 8
  %cv1497 = zext i32 %v1496 to i64
  %cond1498 = icmp ne i64 %cv1497, 0
  br i1 %cond1498, label %bb_rcgnn205, label %bb_rcgplain205
bb_rcgnn205:
  %v1499 = load i64, ptr %slot181, align 8
  %op1500 = sub i64 %v1499, 16
  store i64 %op1500, ptr %slot183, align 8
  %v1501 = load i64, ptr %slot181, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  %rgep1503 = getelementptr i8, ptr %p1502, i64 -16
  %ld1504 = load i64, ptr %rgep1503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1504, ptr %slot184, align 8
  %v1505 = load i64, ptr %slot184, align 8
  %op1506 = and i64 %v1505, 4611686018427387906
  store i64 %op1506, ptr %slot185, align 8
  %v1507 = load i64, ptr %slot185, align 8
  %cmp1508 = icmp ne i64 %v1507, 0
  %cv1509 = zext i1 %cmp1508 to i32
  store i32 %cv1509, ptr %slot186, align 8
  %v1510 = load i32, ptr %slot186, align 8
  %cv1511 = zext i32 %v1510 to i64
  %cond1512 = icmp ne i64 %cv1511, 0
  br i1 %cond1512, label %bb_rcgspecial205, label %bb_rcginc205
bb_rcginc205:
  %v1513 = load i64, ptr %slot181, align 8
  %op1514 = sub i64 %v1513, 32
  store i64 %op1514, ptr %slot187, align 8
  %v1515 = load i64, ptr %slot181, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %rgep1517 = getelementptr i8, ptr %p1516, i64 -32
  %ld1518 = load i64, ptr %rgep1517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1518, ptr %slot188, align 8
  %v1519 = load i64, ptr %slot188, align 8
  %op1520 = add i64 %v1519, 1
  store i64 %op1520, ptr %slot189, align 8
  %v1521 = load i64, ptr %slot189, align 8
  %cmp1522 = icmp eq i64 %v1521, 0
  %cv1523 = zext i1 %cmp1522 to i32
  store i32 %cv1523, ptr %slot190, align 8
  %v1524 = load i32, ptr %slot190, align 8
  %cv1525 = zext i32 %v1524 to i64
  %cond1526 = icmp ne i64 %cv1525, 0
  br i1 %cond1526, label %bb_rcglimit205, label %bb_rcgcapacity205
bb_rcglimit205:
  %v1527 = load i64, ptr %slot1, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %call1529 = call i32 @myl_qbe_rc_status(ptr %p1528, i32 2) nomerge, !dbg !118
  store i32 %call1529, ptr %slot191, align 8
  br label %bb_failure
bb_rcgcapacity205:
  %v1530 = load i64, ptr %slot189, align 8
  %v1531 = load i64, ptr %slot181, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %rgep1533 = getelementptr i8, ptr %p1532, i64 -32
  store i64 %v1530, ptr %rgep1533, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain205
bb_rcgspecial205:
  %v1534 = load i64, ptr %slot184, align 8
  %op1535 = and i64 %v1534, 4611686018427387904
  store i64 %op1535, ptr %slot192, align 8
  %v1536 = load i64, ptr %slot192, align 8
  %cmp1537 = icmp ne i64 %v1536, 0
  %cv1538 = zext i1 %cmp1537 to i32
  store i32 %cv1538, ptr %slot193, align 8
  %v1539 = load i32, ptr %slot193, align 8
  %cv1540 = zext i32 %v1539 to i64
  %cond1541 = icmp ne i64 %cv1540, 0
  br i1 %cond1541, label %bb_rcgslow205, label %bb_rcgplain205
bb_rcgslow205:
  %v1542 = load i64, ptr %slot37, align 8
  %v1543 = load i64, ptr %slot179, align 8
  %v1544 = load i64, ptr %slot157, align 8
  %v1545 = load i64, ptr %slot180, align 8
  %cv1546 = trunc i64 %v1545 to i32
  %call1547 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1542, i64 %v1543, i64 %v1544, i32 %cv1546) nomerge, !dbg !118
  store i32 %call1547, ptr %slot194, align 8
  %v1548 = load i32, ptr %slot194, align 8
  %cv1549 = zext i32 %v1548 to i64
  %cond1550 = icmp ne i64 %cv1549, 0
  br i1 %cond1550, label %bb_rcsuccess219, label %bb_rcfailure219
bb_rcfailure219:
  %v1551 = load i64, ptr %slot37, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %call1553 = call i32 @myl_rc_take_failure(ptr %p1552) nomerge, !dbg !118
  store i32 %call1553, ptr %slot195, align 8
  %v1554 = load i64, ptr %slot1, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %v1556 = load i32, ptr %slot195, align 8
  %call1557 = call i32 @myl_qbe_rc_status(ptr %p1555, i32 %v1556) nomerge, !dbg !118
  store i32 %call1557, ptr %slot196, align 8
  br label %bb_failure
bb_rcsuccess219:
  br label %bb_rcgdone205
bb_rcgplain205:
  %v1558 = load i64, ptr %slot181, align 8
  %v1559 = load i64, ptr %slot179, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i64 %v1558, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone205
bb_rcgdone205:
  %v1561 = load i64, ptr %slot14, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i32 2, ptr %p1562, align 4, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot13, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i32 1, ptr %p1564, align 4, !alias.scope !3, !noalias !4
  %v1565 = load i64, ptr %slot9, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  %ld1567 = load i32, ptr %p1566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1567, ptr %slot197, align 8
  %v1568 = load i32, ptr %slot197, align 8
  %cv1569 = zext i32 %v1568 to i64
  %cond1570 = icmp ne i64 %cv1569, 0
  br i1 %cond1570, label %bb_rcslotdrop226, label %bb_rcslotdone226
bb_rcslotdrop226:
  %v1571 = load i64, ptr %slot9, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i32 0, ptr %p1572, align 4, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot16, align 8
  store i64 %v1573, ptr %slot198, align 8
  %v1574 = load i64, ptr %slot10, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %ld1576 = load i32, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1576, ptr %slot199, align 8
  %v1577 = load i32, ptr %slot199, align 8
  %op1578 = and i32 %v1577, 28
  store i32 %op1578, ptr %slot200, align 8
  %v1579 = load i32, ptr %slot200, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcslotrole226, label %bb_rcslotowner226
bb_rcslotrole226:
  %v1582 = load i64, ptr %slot37, align 8
  store i64 %v1582, ptr %slot201, align 8
  %v1583 = load i64, ptr %slot198, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %ld1585 = load i64, ptr %p1584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1585, ptr %slot202, align 8
  %v1586 = load i64, ptr %slot202, align 8
  %cmp1587 = icmp ne i64 %v1586, 0
  %cv1588 = zext i1 %cmp1587 to i32
  store i32 %cv1588, ptr %slot203, align 8
  %v1589 = load i32, ptr %slot203, align 8
  %cv1590 = zext i32 %v1589 to i64
  %cond1591 = icmp ne i64 %cv1590, 0
  br i1 %cond1591, label %bb_rcgnn242, label %bb_rcgdone242
bb_rcgnn242:
  %v1592 = load i64, ptr %slot202, align 8
  %op1593 = sub i64 %v1592, 16
  store i64 %op1593, ptr %slot204, align 8
  %v1594 = load i64, ptr %slot202, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  %rgep1596 = getelementptr i8, ptr %p1595, i64 -16
  %ld1597 = load i64, ptr %rgep1596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1597, ptr %slot205, align 8
  %v1598 = load i64, ptr %slot205, align 8
  %op1599 = and i64 %v1598, 4611686018427387906
  store i64 %op1599, ptr %slot206, align 8
  %v1600 = load i64, ptr %slot206, align 8
  %cmp1601 = icmp ne i64 %v1600, 0
  %cv1602 = zext i1 %cmp1601 to i32
  store i32 %cv1602, ptr %slot207, align 8
  %v1603 = load i32, ptr %slot207, align 8
  %cv1604 = zext i32 %v1603 to i64
  %cond1605 = icmp ne i64 %cv1604, 0
  br i1 %cond1605, label %bb_rcgclear242, label %bb_rcgcounted242
bb_rcgcounted242:
  %v1606 = load i64, ptr %slot202, align 8
  %op1607 = sub i64 %v1606, 24
  store i64 %op1607, ptr %slot208, align 8
  %v1608 = load i64, ptr %slot202, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  %rgep1610 = getelementptr i8, ptr %p1609, i64 -24
  %ld1611 = load i64, ptr %rgep1610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1611, ptr %slot209, align 8
  %v1612 = load i64, ptr %slot209, align 8
  %op1613 = sub i64 %v1612, 1
  store i64 %op1613, ptr %slot210, align 8
  %v1614 = load i64, ptr %slot210, align 8
  %cmp1615 = icmp eq i64 %v1614, 0
  %cv1616 = zext i1 %cmp1615 to i32
  store i32 %cv1616, ptr %slot211, align 8
  %v1617 = load i32, ptr %slot211, align 8
  %cv1618 = zext i32 %v1617 to i64
  %cond1619 = icmp ne i64 %cv1618, 0
  br i1 %cond1619, label %bb_rcglast242, label %bb_rcgdec242
bb_rcglast242:
  %v1620 = load i64, ptr %slot202, align 8
  %op1621 = sub i64 %v1620, 32
  store i64 %op1621, ptr %slot212, align 8
  %v1622 = load i64, ptr %slot202, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  %rgep1624 = getelementptr i8, ptr %p1623, i64 -32
  %ld1625 = load i64, ptr %rgep1624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1625, ptr %slot213, align 8
  %v1626 = load i64, ptr %slot213, align 8
  %cmp1627 = icmp ne i64 %v1626, 0
  %cv1628 = zext i1 %cmp1627 to i32
  store i32 %cv1628, ptr %slot214, align 8
  %v1629 = load i32, ptr %slot214, align 8
  %cv1630 = zext i32 %v1629 to i64
  %cond1631 = icmp ne i64 %cv1630, 0
  br i1 %cond1631, label %bb_rcgdec242, label %bb_rcgslow242
bb_rcgslow242:
  %v1632 = load i64, ptr %slot201, align 8
  %v1633 = load i64, ptr %slot198, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1632, i64 %v1633) nomerge, !dbg !118
  br label %bb_rcgdone242
bb_rcgdec242:
  %v1634 = load i64, ptr %slot210, align 8
  %v1635 = load i64, ptr %slot202, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %rgep1637 = getelementptr i8, ptr %p1636, i64 -24
  store i64 %v1634, ptr %rgep1637, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear242
bb_rcgclear242:
  %v1638 = load i64, ptr %slot198, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i64 0, ptr %p1639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone242
bb_rcgdone242:
  br label %bb_rcslotdone226
bb_rcslotowner226:
  %v1640 = load i64, ptr %slot37, align 8
  store i64 %v1640, ptr %slot215, align 8
  %v1641 = load i64, ptr %slot198, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  %ld1643 = load i64, ptr %p1642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1643, ptr %slot216, align 8
  %v1644 = load i64, ptr %slot216, align 8
  %cmp1645 = icmp ne i64 %v1644, 0
  %cv1646 = zext i1 %cmp1645 to i32
  store i32 %cv1646, ptr %slot217, align 8
  %v1647 = load i32, ptr %slot217, align 8
  %cv1648 = zext i32 %v1647 to i64
  %cond1649 = icmp ne i64 %cv1648, 0
  br i1 %cond1649, label %bb_rcgnn257, label %bb_rcgdone257
bb_rcgnn257:
  %v1650 = load i64, ptr %slot216, align 8
  %op1651 = sub i64 %v1650, 16
  store i64 %op1651, ptr %slot218, align 8
  %v1652 = load i64, ptr %slot216, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  %rgep1654 = getelementptr i8, ptr %p1653, i64 -16
  %ld1655 = load i64, ptr %rgep1654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1655, ptr %slot219, align 8
  %v1656 = load i64, ptr %slot219, align 8
  %op1657 = and i64 %v1656, 4611686018427387906
  store i64 %op1657, ptr %slot220, align 8
  %v1658 = load i64, ptr %slot220, align 8
  %cmp1659 = icmp ne i64 %v1658, 0
  %cv1660 = zext i1 %cmp1659 to i32
  store i32 %cv1660, ptr %slot221, align 8
  %v1661 = load i32, ptr %slot221, align 8
  %cv1662 = zext i32 %v1661 to i64
  %cond1663 = icmp ne i64 %cv1662, 0
  br i1 %cond1663, label %bb_rcgclear257, label %bb_rcgcounted257
bb_rcgcounted257:
  %v1664 = load i64, ptr %slot216, align 8
  %op1665 = sub i64 %v1664, 32
  store i64 %op1665, ptr %slot222, align 8
  %v1666 = load i64, ptr %slot216, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %rgep1668 = getelementptr i8, ptr %p1667, i64 -32
  %ld1669 = load i64, ptr %rgep1668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1669, ptr %slot223, align 8
  %v1670 = load i64, ptr %slot223, align 8
  %op1671 = sub i64 %v1670, 1
  store i64 %op1671, ptr %slot224, align 8
  %v1672 = load i64, ptr %slot224, align 8
  %cmp1673 = icmp eq i64 %v1672, 0
  %cv1674 = zext i1 %cmp1673 to i32
  store i32 %cv1674, ptr %slot225, align 8
  %v1675 = load i32, ptr %slot225, align 8
  %cv1676 = zext i32 %v1675 to i64
  %cond1677 = icmp ne i64 %cv1676, 0
  br i1 %cond1677, label %bb_rcglast257, label %bb_rcgdec257
bb_rcglast257:
  %v1678 = load i64, ptr %slot216, align 8
  %op1679 = sub i64 %v1678, 24
  store i64 %op1679, ptr %slot226, align 8
  %v1680 = load i64, ptr %slot216, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %rgep1682 = getelementptr i8, ptr %p1681, i64 -24
  %ld1683 = load i64, ptr %rgep1682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1683, ptr %slot227, align 8
  %v1684 = load i64, ptr %slot227, align 8
  %cmp1685 = icmp ne i64 %v1684, 0
  %cv1686 = zext i1 %cmp1685 to i32
  store i32 %cv1686, ptr %slot228, align 8
  %v1687 = load i32, ptr %slot228, align 8
  %cv1688 = zext i32 %v1687 to i64
  %cond1689 = icmp ne i64 %cv1688, 0
  br i1 %cond1689, label %bb_rcgdec257, label %bb_rcgslow257
bb_rcgslow257:
  %v1690 = load i64, ptr %slot215, align 8
  %v1691 = load i64, ptr %slot198, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1690, i64 %v1691) nomerge, !dbg !118
  br label %bb_rcgdone257
bb_rcgdec257:
  %v1692 = load i64, ptr %slot224, align 8
  %v1693 = load i64, ptr %slot216, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  %rgep1695 = getelementptr i8, ptr %p1694, i64 -32
  store i64 %v1692, ptr %rgep1695, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear257
bb_rcgclear257:
  %v1696 = load i64, ptr %slot198, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i64 0, ptr %p1697, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone257
bb_rcgdone257:
  br label %bb_rcslotdone226
bb_rcslotdone226:
  br label %bb_rcprepared172
bb_rcprepared172:
  %v1698 = load i64, ptr %slot7, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i32, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1700, ptr %slot229, align 8
  %v1701 = load i32, ptr %slot229, align 8
  %cv1702 = zext i32 %v1701 to i64
  %cond1703 = icmp ne i64 %cv1702, 0
  br i1 %cond1703, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v1704 = load i64, ptr %slot7, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  store i32 0, ptr %p1705, align 4, !alias.scope !3, !noalias !4
  %v1706 = load i64, ptr %slot24, align 8
  store i64 %v1706, ptr %slot230, align 8
  %v1707 = load i64, ptr %slot8, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  %ld1709 = load i32, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1709, ptr %slot231, align 8
  %v1710 = load i32, ptr %slot231, align 8
  %op1711 = and i32 %v1710, 28
  store i32 %op1711, ptr %slot232, align 8
  %v1712 = load i32, ptr %slot232, align 8
  %cv1713 = zext i32 %v1712 to i64
  %cond1714 = icmp ne i64 %cv1713, 0
  br i1 %cond1714, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v1715 = load i64, ptr %slot37, align 8
  store i64 %v1715, ptr %slot233, align 8
  %v1716 = load i64, ptr %slot230, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  %ld1718 = load i64, ptr %p1717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1718, ptr %slot234, align 8
  %v1719 = load i64, ptr %slot234, align 8
  %cmp1720 = icmp ne i64 %v1719, 0
  %cv1721 = zext i1 %cmp1720 to i32
  store i32 %cv1721, ptr %slot235, align 8
  %v1722 = load i32, ptr %slot235, align 8
  %cv1723 = zext i32 %v1722 to i64
  %cond1724 = icmp ne i64 %cv1723, 0
  br i1 %cond1724, label %bb_rcgnn280, label %bb_rcgdone280
bb_rcgnn280:
  %v1725 = load i64, ptr %slot234, align 8
  %op1726 = sub i64 %v1725, 16
  store i64 %op1726, ptr %slot236, align 8
  %v1727 = load i64, ptr %slot234, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %rgep1729 = getelementptr i8, ptr %p1728, i64 -16
  %ld1730 = load i64, ptr %rgep1729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1730, ptr %slot237, align 8
  %v1731 = load i64, ptr %slot237, align 8
  %op1732 = and i64 %v1731, 4611686018427387906
  store i64 %op1732, ptr %slot238, align 8
  %v1733 = load i64, ptr %slot238, align 8
  %cmp1734 = icmp ne i64 %v1733, 0
  %cv1735 = zext i1 %cmp1734 to i32
  store i32 %cv1735, ptr %slot239, align 8
  %v1736 = load i32, ptr %slot239, align 8
  %cv1737 = zext i32 %v1736 to i64
  %cond1738 = icmp ne i64 %cv1737, 0
  br i1 %cond1738, label %bb_rcgclear280, label %bb_rcgcounted280
bb_rcgcounted280:
  %v1739 = load i64, ptr %slot234, align 8
  %op1740 = sub i64 %v1739, 24
  store i64 %op1740, ptr %slot240, align 8
  %v1741 = load i64, ptr %slot234, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %rgep1743 = getelementptr i8, ptr %p1742, i64 -24
  %ld1744 = load i64, ptr %rgep1743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1744, ptr %slot241, align 8
  %v1745 = load i64, ptr %slot241, align 8
  %op1746 = sub i64 %v1745, 1
  store i64 %op1746, ptr %slot242, align 8
  %v1747 = load i64, ptr %slot242, align 8
  %cmp1748 = icmp eq i64 %v1747, 0
  %cv1749 = zext i1 %cmp1748 to i32
  store i32 %cv1749, ptr %slot243, align 8
  %v1750 = load i32, ptr %slot243, align 8
  %cv1751 = zext i32 %v1750 to i64
  %cond1752 = icmp ne i64 %cv1751, 0
  br i1 %cond1752, label %bb_rcglast280, label %bb_rcgdec280
bb_rcglast280:
  %v1753 = load i64, ptr %slot234, align 8
  %op1754 = sub i64 %v1753, 32
  store i64 %op1754, ptr %slot244, align 8
  %v1755 = load i64, ptr %slot234, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  %rgep1757 = getelementptr i8, ptr %p1756, i64 -32
  %ld1758 = load i64, ptr %rgep1757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1758, ptr %slot245, align 8
  %v1759 = load i64, ptr %slot245, align 8
  %cmp1760 = icmp ne i64 %v1759, 0
  %cv1761 = zext i1 %cmp1760 to i32
  store i32 %cv1761, ptr %slot246, align 8
  %v1762 = load i32, ptr %slot246, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcgdec280, label %bb_rcgslow280
bb_rcgslow280:
  %v1765 = load i64, ptr %slot233, align 8
  %v1766 = load i64, ptr %slot230, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1765, i64 %v1766) nomerge, !dbg !118
  br label %bb_rcgdone280
bb_rcgdec280:
  %v1767 = load i64, ptr %slot242, align 8
  %v1768 = load i64, ptr %slot234, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %rgep1770 = getelementptr i8, ptr %p1769, i64 -24
  store i64 %v1767, ptr %rgep1770, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear280
bb_rcgclear280:
  %v1771 = load i64, ptr %slot230, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  store i64 0, ptr %p1772, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone280
bb_rcgdone280:
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v1773 = load i64, ptr %slot37, align 8
  store i64 %v1773, ptr %slot247, align 8
  %v1774 = load i64, ptr %slot230, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i64, ptr %p1775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1776, ptr %slot248, align 8
  %v1777 = load i64, ptr %slot248, align 8
  %cmp1778 = icmp ne i64 %v1777, 0
  %cv1779 = zext i1 %cmp1778 to i32
  store i32 %cv1779, ptr %slot249, align 8
  %v1780 = load i32, ptr %slot249, align 8
  %cv1781 = zext i32 %v1780 to i64
  %cond1782 = icmp ne i64 %cv1781, 0
  br i1 %cond1782, label %bb_rcgnn295, label %bb_rcgdone295
bb_rcgnn295:
  %v1783 = load i64, ptr %slot248, align 8
  %op1784 = sub i64 %v1783, 16
  store i64 %op1784, ptr %slot250, align 8
  %v1785 = load i64, ptr %slot248, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  %rgep1787 = getelementptr i8, ptr %p1786, i64 -16
  %ld1788 = load i64, ptr %rgep1787, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1788, ptr %slot251, align 8
  %v1789 = load i64, ptr %slot251, align 8
  %op1790 = and i64 %v1789, 4611686018427387906
  store i64 %op1790, ptr %slot252, align 8
  %v1791 = load i64, ptr %slot252, align 8
  %cmp1792 = icmp ne i64 %v1791, 0
  %cv1793 = zext i1 %cmp1792 to i32
  store i32 %cv1793, ptr %slot253, align 8
  %v1794 = load i32, ptr %slot253, align 8
  %cv1795 = zext i32 %v1794 to i64
  %cond1796 = icmp ne i64 %cv1795, 0
  br i1 %cond1796, label %bb_rcgclear295, label %bb_rcgcounted295
bb_rcgcounted295:
  %v1797 = load i64, ptr %slot248, align 8
  %op1798 = sub i64 %v1797, 32
  store i64 %op1798, ptr %slot254, align 8
  %v1799 = load i64, ptr %slot248, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %rgep1801 = getelementptr i8, ptr %p1800, i64 -32
  %ld1802 = load i64, ptr %rgep1801, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1802, ptr %slot255, align 8
  %v1803 = load i64, ptr %slot255, align 8
  %op1804 = sub i64 %v1803, 1
  store i64 %op1804, ptr %slot256, align 8
  %v1805 = load i64, ptr %slot256, align 8
  %cmp1806 = icmp eq i64 %v1805, 0
  %cv1807 = zext i1 %cmp1806 to i32
  store i32 %cv1807, ptr %slot257, align 8
  %v1808 = load i32, ptr %slot257, align 8
  %cv1809 = zext i32 %v1808 to i64
  %cond1810 = icmp ne i64 %cv1809, 0
  br i1 %cond1810, label %bb_rcglast295, label %bb_rcgdec295
bb_rcglast295:
  %v1811 = load i64, ptr %slot248, align 8
  %op1812 = sub i64 %v1811, 24
  store i64 %op1812, ptr %slot258, align 8
  %v1813 = load i64, ptr %slot248, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  %rgep1815 = getelementptr i8, ptr %p1814, i64 -24
  %ld1816 = load i64, ptr %rgep1815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1816, ptr %slot259, align 8
  %v1817 = load i64, ptr %slot259, align 8
  %cmp1818 = icmp ne i64 %v1817, 0
  %cv1819 = zext i1 %cmp1818 to i32
  store i32 %cv1819, ptr %slot260, align 8
  %v1820 = load i32, ptr %slot260, align 8
  %cv1821 = zext i32 %v1820 to i64
  %cond1822 = icmp ne i64 %cv1821, 0
  br i1 %cond1822, label %bb_rcgdec295, label %bb_rcgslow295
bb_rcgslow295:
  %v1823 = load i64, ptr %slot247, align 8
  %v1824 = load i64, ptr %slot230, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1823, i64 %v1824) nomerge, !dbg !118
  br label %bb_rcgdone295
bb_rcgdec295:
  %v1825 = load i64, ptr %slot256, align 8
  %v1826 = load i64, ptr %slot248, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  %rgep1828 = getelementptr i8, ptr %p1827, i64 -32
  store i64 %v1825, ptr %rgep1828, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear295
bb_rcgclear295:
  %v1829 = load i64, ptr %slot230, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i64 0, ptr %p1830, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone295
bb_rcgdone295:
  br label %bb_rcslotdone264
bb_rcslotdone264:
  %v1831 = load i64, ptr %slot24, align 8
  store i64 %v1831, ptr %slot261, align 8
  %v1832 = load i64, ptr %slot20, align 8
  store i64 %v1832, ptr %slot262, align 8
  %v1833 = load i64, ptr %slot262, align 8
  %v1834 = load i64, ptr %slot261, align 8
  %p1835 = inttoptr i64 %v1833 to ptr
  %p1836 = inttoptr i64 %v1834 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1836, ptr %p1835, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot13, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  store i32 0, ptr %p1838, align 4, !alias.scope !3, !noalias !4
  %v1839 = load i64, ptr %slot8, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i32 2, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot14, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i32, ptr %p1842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1843, ptr %slot263, align 8
  %v1844 = load i32, ptr %slot263, align 8
  %v1845 = load i64, ptr %slot8, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 %v1844, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot7, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i32 1, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  %v1849 = load i64, ptr %slot5, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i32, ptr %p1850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1851, ptr %slot264, align 8
  %v1852 = load i32, ptr %slot264, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1855 = load i64, ptr %slot5, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 0, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot23, align 8
  store i64 %v1857, ptr %slot265, align 8
  %v1858 = load i64, ptr %slot6, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %ld1860 = load i32, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1860, ptr %slot266, align 8
  %v1861 = load i32, ptr %slot266, align 8
  %op1862 = and i32 %v1861, 28
  store i32 %op1862, ptr %slot267, align 8
  %v1863 = load i32, ptr %slot267, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1866 = load i64, ptr %slot37, align 8
  store i64 %v1866, ptr %slot268, align 8
  %v1867 = load i64, ptr %slot265, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %ld1869 = load i64, ptr %p1868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1869, ptr %slot269, align 8
  %v1870 = load i64, ptr %slot269, align 8
  %cmp1871 = icmp ne i64 %v1870, 0
  %cv1872 = zext i1 %cmp1871 to i32
  store i32 %cv1872, ptr %slot270, align 8
  %v1873 = load i32, ptr %slot270, align 8
  %cv1874 = zext i32 %v1873 to i64
  %cond1875 = icmp ne i64 %cv1874, 0
  br i1 %cond1875, label %bb_rcgnn324, label %bb_rcgdone324
bb_rcgnn324:
  %v1876 = load i64, ptr %slot269, align 8
  %op1877 = sub i64 %v1876, 16
  store i64 %op1877, ptr %slot271, align 8
  %v1878 = load i64, ptr %slot269, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %rgep1880 = getelementptr i8, ptr %p1879, i64 -16
  %ld1881 = load i64, ptr %rgep1880, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1881, ptr %slot272, align 8
  %v1882 = load i64, ptr %slot272, align 8
  %op1883 = and i64 %v1882, 4611686018427387906
  store i64 %op1883, ptr %slot273, align 8
  %v1884 = load i64, ptr %slot273, align 8
  %cmp1885 = icmp ne i64 %v1884, 0
  %cv1886 = zext i1 %cmp1885 to i32
  store i32 %cv1886, ptr %slot274, align 8
  %v1887 = load i32, ptr %slot274, align 8
  %cv1888 = zext i32 %v1887 to i64
  %cond1889 = icmp ne i64 %cv1888, 0
  br i1 %cond1889, label %bb_rcgclear324, label %bb_rcgcounted324
bb_rcgcounted324:
  %v1890 = load i64, ptr %slot269, align 8
  %op1891 = sub i64 %v1890, 24
  store i64 %op1891, ptr %slot275, align 8
  %v1892 = load i64, ptr %slot269, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  %rgep1894 = getelementptr i8, ptr %p1893, i64 -24
  %ld1895 = load i64, ptr %rgep1894, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1895, ptr %slot276, align 8
  %v1896 = load i64, ptr %slot276, align 8
  %op1897 = sub i64 %v1896, 1
  store i64 %op1897, ptr %slot277, align 8
  %v1898 = load i64, ptr %slot277, align 8
  %cmp1899 = icmp eq i64 %v1898, 0
  %cv1900 = zext i1 %cmp1899 to i32
  store i32 %cv1900, ptr %slot278, align 8
  %v1901 = load i32, ptr %slot278, align 8
  %cv1902 = zext i32 %v1901 to i64
  %cond1903 = icmp ne i64 %cv1902, 0
  br i1 %cond1903, label %bb_rcglast324, label %bb_rcgdec324
bb_rcglast324:
  %v1904 = load i64, ptr %slot269, align 8
  %op1905 = sub i64 %v1904, 32
  store i64 %op1905, ptr %slot279, align 8
  %v1906 = load i64, ptr %slot269, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  %rgep1908 = getelementptr i8, ptr %p1907, i64 -32
  %ld1909 = load i64, ptr %rgep1908, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1909, ptr %slot280, align 8
  %v1910 = load i64, ptr %slot280, align 8
  %cmp1911 = icmp ne i64 %v1910, 0
  %cv1912 = zext i1 %cmp1911 to i32
  store i32 %cv1912, ptr %slot281, align 8
  %v1913 = load i32, ptr %slot281, align 8
  %cv1914 = zext i32 %v1913 to i64
  %cond1915 = icmp ne i64 %cv1914, 0
  br i1 %cond1915, label %bb_rcgdec324, label %bb_rcgslow324
bb_rcgslow324:
  %v1916 = load i64, ptr %slot268, align 8
  %v1917 = load i64, ptr %slot265, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1916, i64 %v1917) nomerge, !dbg !118
  br label %bb_rcgdone324
bb_rcgdec324:
  %v1918 = load i64, ptr %slot277, align 8
  %v1919 = load i64, ptr %slot269, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %rgep1921 = getelementptr i8, ptr %p1920, i64 -24
  store i64 %v1918, ptr %rgep1921, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear324
bb_rcgclear324:
  %v1922 = load i64, ptr %slot265, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i64 0, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone324
bb_rcgdone324:
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1924 = load i64, ptr %slot37, align 8
  store i64 %v1924, ptr %slot282, align 8
  %v1925 = load i64, ptr %slot265, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i64, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1927, ptr %slot283, align 8
  %v1928 = load i64, ptr %slot283, align 8
  %cmp1929 = icmp ne i64 %v1928, 0
  %cv1930 = zext i1 %cmp1929 to i32
  store i32 %cv1930, ptr %slot284, align 8
  %v1931 = load i32, ptr %slot284, align 8
  %cv1932 = zext i32 %v1931 to i64
  %cond1933 = icmp ne i64 %cv1932, 0
  br i1 %cond1933, label %bb_rcgnn339, label %bb_rcgdone339
bb_rcgnn339:
  %v1934 = load i64, ptr %slot283, align 8
  %op1935 = sub i64 %v1934, 16
  store i64 %op1935, ptr %slot285, align 8
  %v1936 = load i64, ptr %slot283, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  %rgep1938 = getelementptr i8, ptr %p1937, i64 -16
  %ld1939 = load i64, ptr %rgep1938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1939, ptr %slot286, align 8
  %v1940 = load i64, ptr %slot286, align 8
  %op1941 = and i64 %v1940, 4611686018427387906
  store i64 %op1941, ptr %slot287, align 8
  %v1942 = load i64, ptr %slot287, align 8
  %cmp1943 = icmp ne i64 %v1942, 0
  %cv1944 = zext i1 %cmp1943 to i32
  store i32 %cv1944, ptr %slot288, align 8
  %v1945 = load i32, ptr %slot288, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcgclear339, label %bb_rcgcounted339
bb_rcgcounted339:
  %v1948 = load i64, ptr %slot283, align 8
  %op1949 = sub i64 %v1948, 32
  store i64 %op1949, ptr %slot289, align 8
  %v1950 = load i64, ptr %slot283, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %rgep1952 = getelementptr i8, ptr %p1951, i64 -32
  %ld1953 = load i64, ptr %rgep1952, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1953, ptr %slot290, align 8
  %v1954 = load i64, ptr %slot290, align 8
  %op1955 = sub i64 %v1954, 1
  store i64 %op1955, ptr %slot291, align 8
  %v1956 = load i64, ptr %slot291, align 8
  %cmp1957 = icmp eq i64 %v1956, 0
  %cv1958 = zext i1 %cmp1957 to i32
  store i32 %cv1958, ptr %slot292, align 8
  %v1959 = load i32, ptr %slot292, align 8
  %cv1960 = zext i32 %v1959 to i64
  %cond1961 = icmp ne i64 %cv1960, 0
  br i1 %cond1961, label %bb_rcglast339, label %bb_rcgdec339
bb_rcglast339:
  %v1962 = load i64, ptr %slot283, align 8
  %op1963 = sub i64 %v1962, 24
  store i64 %op1963, ptr %slot293, align 8
  %v1964 = load i64, ptr %slot283, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %rgep1966 = getelementptr i8, ptr %p1965, i64 -24
  %ld1967 = load i64, ptr %rgep1966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1967, ptr %slot294, align 8
  %v1968 = load i64, ptr %slot294, align 8
  %cmp1969 = icmp ne i64 %v1968, 0
  %cv1970 = zext i1 %cmp1969 to i32
  store i32 %cv1970, ptr %slot295, align 8
  %v1971 = load i32, ptr %slot295, align 8
  %cv1972 = zext i32 %v1971 to i64
  %cond1973 = icmp ne i64 %cv1972, 0
  br i1 %cond1973, label %bb_rcgdec339, label %bb_rcgslow339
bb_rcgslow339:
  %v1974 = load i64, ptr %slot282, align 8
  %v1975 = load i64, ptr %slot265, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1974, i64 %v1975) nomerge, !dbg !118
  br label %bb_rcgdone339
bb_rcgdec339:
  %v1976 = load i64, ptr %slot291, align 8
  %v1977 = load i64, ptr %slot283, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  %rgep1979 = getelementptr i8, ptr %p1978, i64 -32
  store i64 %v1976, ptr %rgep1979, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear339
bb_rcgclear339:
  %v1980 = load i64, ptr %slot265, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i64 0, ptr %p1981, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone339
bb_rcgdone339:
  br label %bb_rcslotdone308
bb_rcslotdone308:
  br label %bb_i6
bb_i6:
  %v1982 = load i64, ptr %slot22, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %ld1984 = load i64, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1984, ptr %slot296, align 8
  %v1985 = load i64, ptr %slot296, align 8
  %v1986 = load i64, ptr %slot26, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  store i64 %v1985, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  %v1988 = load i64, ptr %slot29, align 8
  store i64 %v1988, ptr %slot297, align 8
  %v1989 = load i64, ptr %slot297, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i32 0, ptr %p1990, align 4, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot297, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i32 3, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot297, align 8
  %v1994 = load i64, ptr %slot27, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 %v1993, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot26, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot298, align 8
  %v1999 = load i64, ptr %slot27, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %ld2001 = load i64, ptr %p2000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2001, ptr %slot299, align 8
  %v2002 = load i64, ptr %slot1, align 8
  %v2003 = load i64, ptr %slot298, align 8
  %v2004 = load i64, ptr %slot299, align 8
  %call2005 = call i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %v2002, i64 %v2003, i64 %v2004) nomerge, !dbg !120
  store i64 %call2005, ptr %slot300, align 8
  %v2006 = load i64, ptr %slot300, align 8
  %v2007 = load i64, ptr %slot26, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  store i64 %v2006, ptr %p2008, align 8, !alias.scope !3, !noalias !4
  %v2009 = load i64, ptr %slot9, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %ld2011 = load i32, ptr %p2010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2011, ptr %slot301, align 8
  %v2012 = load i32, ptr %slot301, align 8
  %cv2013 = zext i32 %v2012 to i64
  %cond2014 = icmp ne i64 %cv2013, 0
  br i1 %cond2014, label %bb_rcslotdrop350, label %bb_rcslotdone350
bb_rcslotdrop350:
  %v2015 = load i64, ptr %slot9, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  store i32 0, ptr %p2016, align 4, !alias.scope !3, !noalias !4
  %v2017 = load i64, ptr %slot16, align 8
  store i64 %v2017, ptr %slot302, align 8
  %v2018 = load i64, ptr %slot10, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %ld2020 = load i32, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2020, ptr %slot303, align 8
  %v2021 = load i32, ptr %slot303, align 8
  %op2022 = and i32 %v2021, 28
  store i32 %op2022, ptr %slot304, align 8
  %v2023 = load i32, ptr %slot304, align 8
  %cv2024 = zext i32 %v2023 to i64
  %cond2025 = icmp ne i64 %cv2024, 0
  br i1 %cond2025, label %bb_rcslotrole350, label %bb_rcslotowner350
bb_rcslotrole350:
  %v2026 = load i64, ptr %slot37, align 8
  store i64 %v2026, ptr %slot305, align 8
  %v2027 = load i64, ptr %slot305, align 8
  %v2028 = load i64, ptr %slot302, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2027, i64 %v2028) nomerge, !dbg !120
  br label %bb_rcslotdone350
bb_rcslotowner350:
  %v2029 = load i64, ptr %slot37, align 8
  store i64 %v2029, ptr %slot306, align 8
  %v2030 = load i64, ptr %slot306, align 8
  %v2031 = load i64, ptr %slot302, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2030, i64 %v2031) nomerge, !dbg !120
  br label %bb_rcslotdone350
bb_rcslotdone350:
  %v2032 = load i64, ptr %slot26, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %ld2034 = load i64, ptr %p2033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2034, ptr %slot307, align 8
  %v2035 = load i64, ptr %slot307, align 8
  %op2036 = xor i64 %v2035, 1
  store i64 %op2036, ptr %slot308, align 8
  %v2037 = load i64, ptr %slot308, align 8
  %v2038 = load i64, ptr %slot26, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i64 %v2037, ptr %p2039, align 8, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot26, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %ld2042 = load i64, ptr %p2041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2042, ptr %slot309, align 8
  %v2043 = load i64, ptr %slot309, align 8
  %cond2044 = icmp ne i64 %v2043, 0
  br i1 %cond2044, label %bb_next360, label %bb_i15
bb_next360:
  %v2045 = load i64, ptr %slot22, align 8
  %p2046 = inttoptr i64 %v2045 to ptr
  %ld2047 = load i64, ptr %p2046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2047, ptr %slot310, align 8
  %v2048 = load i64, ptr %slot310, align 8
  %v2049 = load i64, ptr %slot26, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i64 %v2048, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot26, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i64, ptr %p2052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2053, ptr %slot311, align 8
  %v2054 = load i64, ptr %slot1, align 8
  %v2055 = load i64, ptr %slot311, align 8
  %call2056 = call i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64 %v2054, i64 %v2055) nomerge, !dbg !122
  store i64 %call2056, ptr %slot312, align 8
  %v2057 = load i64, ptr %slot312, align 8
  %v2058 = load i64, ptr %slot26, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i64 %v2057, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  %v2060 = load i64, ptr %slot9, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %ld2062 = load i32, ptr %p2061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2062, ptr %slot313, align 8
  %v2063 = load i32, ptr %slot313, align 8
  %cv2064 = zext i32 %v2063 to i64
  %cond2065 = icmp ne i64 %cv2064, 0
  br i1 %cond2065, label %bb_rcslotdrop365, label %bb_rcslotdone365
bb_rcslotdrop365:
  %v2066 = load i64, ptr %slot9, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i32 0, ptr %p2067, align 4, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot16, align 8
  store i64 %v2068, ptr %slot314, align 8
  %v2069 = load i64, ptr %slot10, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  %ld2071 = load i32, ptr %p2070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2071, ptr %slot315, align 8
  %v2072 = load i32, ptr %slot315, align 8
  %op2073 = and i32 %v2072, 28
  store i32 %op2073, ptr %slot316, align 8
  %v2074 = load i32, ptr %slot316, align 8
  %cv2075 = zext i32 %v2074 to i64
  %cond2076 = icmp ne i64 %cv2075, 0
  br i1 %cond2076, label %bb_rcslotrole365, label %bb_rcslotowner365
bb_rcslotrole365:
  %v2077 = load i64, ptr %slot37, align 8
  store i64 %v2077, ptr %slot317, align 8
  %v2078 = load i64, ptr %slot317, align 8
  %v2079 = load i64, ptr %slot314, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2078, i64 %v2079) nomerge, !dbg !122
  br label %bb_rcslotdone365
bb_rcslotowner365:
  %v2080 = load i64, ptr %slot37, align 8
  store i64 %v2080, ptr %slot318, align 8
  %v2081 = load i64, ptr %slot318, align 8
  %v2082 = load i64, ptr %slot314, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2081, i64 %v2082) nomerge, !dbg !122
  br label %bb_rcslotdone365
bb_rcslotdone365:
  %v2083 = load i64, ptr %slot26, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i64, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2085, ptr %slot319, align 8
  %v2086 = load i64, ptr %slot319, align 8
  %op2087 = xor i64 %v2086, 1
  store i64 %op2087, ptr %slot320, align 8
  %v2088 = load i64, ptr %slot320, align 8
  %v2089 = load i64, ptr %slot26, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i64 %v2088, ptr %p2090, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i15:
  %v2091 = load i64, ptr %slot26, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  store i64 0, ptr %p2092, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v2093 = load i64, ptr %slot26, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  %ld2095 = load i64, ptr %p2094, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2095, ptr %slot321, align 8
  %v2096 = load i64, ptr %slot321, align 8
  %cond2097 = icmp ne i64 %v2096, 0
  br i1 %cond2097, label %bb_next375, label %bb_i26
bb_next375:
  %v2098 = load i64, ptr %slot22, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i64, ptr %p2099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2100, ptr %slot322, align 8
  %v2101 = load i64, ptr %slot322, align 8
  %v2102 = load i64, ptr %slot26, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i64 %v2101, ptr %p2103, align 8, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot26, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %ld2106 = load i64, ptr %p2105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2106, ptr %slot323, align 8
  %v2107 = load i64, ptr %slot1, align 8
  %v2108 = load i64, ptr %slot323, align 8
  %call2109 = call { i64, i64 } @myl_f_b3086250724b37e1530ea18afd53a87106fe0a2ce8bf702de675deca9c1a6925(i64 %v2107, i64 %v2108) nomerge, !dbg !124
  store { i64, i64 } %call2109, ptr %callresult325, align 8
  %addr2110 = ptrtoint ptr %callresult325 to i64
  store i64 %addr2110, ptr %slot324, align 8
  %v2111 = load i64, ptr %slot324, align 8
  %v2112 = load i64, ptr %slot26, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i64 %v2111, ptr %p2113, align 8, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot9, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i32, ptr %p2115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2116, ptr %slot326, align 8
  %v2117 = load i32, ptr %slot326, align 8
  %cv2118 = zext i32 %v2117 to i64
  %cond2119 = icmp ne i64 %cv2118, 0
  br i1 %cond2119, label %bb_rcslotdrop380, label %bb_rcslotdone380
bb_rcslotdrop380:
  %v2120 = load i64, ptr %slot9, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i32 0, ptr %p2121, align 4, !alias.scope !3, !noalias !4
  %v2122 = load i64, ptr %slot16, align 8
  store i64 %v2122, ptr %slot327, align 8
  %v2123 = load i64, ptr %slot10, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  %ld2125 = load i32, ptr %p2124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2125, ptr %slot328, align 8
  %v2126 = load i32, ptr %slot328, align 8
  %op2127 = and i32 %v2126, 28
  store i32 %op2127, ptr %slot329, align 8
  %v2128 = load i32, ptr %slot329, align 8
  %cv2129 = zext i32 %v2128 to i64
  %cond2130 = icmp ne i64 %cv2129, 0
  br i1 %cond2130, label %bb_rcslotrole380, label %bb_rcslotowner380
bb_rcslotrole380:
  %v2131 = load i64, ptr %slot37, align 8
  store i64 %v2131, ptr %slot330, align 8
  %v2132 = load i64, ptr %slot330, align 8
  %v2133 = load i64, ptr %slot327, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2132, i64 %v2133) nomerge, !dbg !124
  br label %bb_rcslotdone380
bb_rcslotowner380:
  %v2134 = load i64, ptr %slot37, align 8
  store i64 %v2134, ptr %slot331, align 8
  %v2135 = load i64, ptr %slot331, align 8
  %v2136 = load i64, ptr %slot327, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2135, i64 %v2136) nomerge, !dbg !124
  br label %bb_rcslotdone380
bb_rcslotdone380:
  %v2137 = load i64, ptr %slot26, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %ld2139 = load i64, ptr %p2138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2139, ptr %slot332, align 8
  %v2140 = load i64, ptr %slot332, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i32, ptr %p2141, align 4
  %ext2143 = zext i32 %ld2142 to i64
  store i64 %ext2143, ptr %slot333, align 8
  %v2144 = load i64, ptr %slot333, align 8
  %cmp2145 = icmp eq i64 %v2144, 0
  %cv2146 = zext i1 %cmp2145 to i64
  store i64 %cv2146, ptr %slot334, align 8
  %v2147 = load i64, ptr %slot334, align 8
  %cond2148 = icmp ne i64 %v2147, 0
  br i1 %cond2148, label %bb_rcarm389, label %bb_rcarmnext389
bb_rcarm389:
  br label %bb_i24
bb_rcarmnext389:
  %v2149 = load i64, ptr %slot333, align 8
  %cmp2150 = icmp eq i64 %v2149, 1
  %cv2151 = zext i1 %cmp2150 to i64
  store i64 %cv2151, ptr %slot335, align 8
  %v2152 = load i64, ptr %slot335, align 8
  %cond2153 = icmp ne i64 %v2152, 0
  br i1 %cond2153, label %bb_rcarm390, label %bb_rcarmnext390
bb_rcarm390:
  %v2154 = load i64, ptr %slot20, align 8
  store i64 %v2154, ptr %slot336, align 8
  %v2155 = load i64, ptr %slot332, align 8
  %op2156 = add i64 %v2155, 8
  store i64 %op2156, ptr %slot337, align 8
  %v2157 = load i64, ptr %slot38, align 8
  store i64 %v2157, ptr %slot338, align 8
  %v2158 = load i64, ptr %slot337, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %ld2160 = load i64, ptr %p2159, align 8
  store i64 %ld2160, ptr %slot339, align 8
  %v2161 = load i64, ptr %slot339, align 8
  %v2162 = load i64, ptr %slot336, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i64 %v2161, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  %v2164 = load i64, ptr %slot14, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 0, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  %v2166 = load i64, ptr %slot13, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i32 1, ptr %p2167, align 4, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot336, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i64, ptr %p2169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2170, ptr %slot340, align 8
  %v2171 = load i64, ptr %slot340, align 8
  %v2172 = load i64, ptr %slot25, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  store i64 %v2171, ptr %p2173, align 8, !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot13, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 0, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_rcarmnext390:
  br label %bb_failure
bb_i20:
  %v2176 = load i64, ptr %slot25, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2178, ptr %slot341, align 8
  %v2179 = load i64, ptr %slot341, align 8
  %v2180 = load i64, ptr %slot26, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i64 %v2179, ptr %p2181, align 8, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot24, align 8
  store i64 %v2182, ptr %slot342, align 8
  %v2183 = load i64, ptr %slot8, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i32 2, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot342, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot343, align 8
  %v2188 = load i64, ptr %slot343, align 8
  %cmp2189 = icmp ne i64 %v2188, 0
  %cv2190 = zext i1 %cmp2189 to i32
  store i32 %cv2190, ptr %slot344, align 8
  %v2191 = load i32, ptr %slot344, align 8
  %cv2192 = zext i32 %v2191 to i64
  %cond2193 = icmp ne i64 %cv2192, 0
  br i1 %cond2193, label %bb_rcguniquenn403, label %bb_rcgunique403
bb_rcguniquenn403:
  %v2194 = load i64, ptr %slot343, align 8
  %op2195 = sub i64 %v2194, 16
  store i64 %op2195, ptr %slot345, align 8
  %v2196 = load i64, ptr %slot343, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %rgep2198 = getelementptr i8, ptr %p2197, i64 -16
  %ld2199 = load i64, ptr %rgep2198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2199, ptr %slot346, align 8
  %v2200 = load i64, ptr %slot346, align 8
  %op2201 = and i64 %v2200, 6917529027641081858
  store i64 %op2201, ptr %slot347, align 8
  %v2202 = load i64, ptr %slot347, align 8
  %cmp2203 = icmp ne i64 %v2202, 0
  %cv2204 = zext i1 %cmp2203 to i32
  store i32 %cv2204, ptr %slot348, align 8
  %v2205 = load i32, ptr %slot348, align 8
  %cv2206 = zext i32 %v2205 to i64
  %cond2207 = icmp ne i64 %cv2206, 0
  br i1 %cond2207, label %bb_rcguniqueslow403, label %bb_rcguniquecount403
bb_rcguniquecount403:
  %v2208 = load i64, ptr %slot343, align 8
  %op2209 = sub i64 %v2208, 32
  store i64 %op2209, ptr %slot349, align 8
  %v2210 = load i64, ptr %slot343, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  %rgep2212 = getelementptr i8, ptr %p2211, i64 -32
  %ld2213 = load i64, ptr %rgep2212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2213, ptr %slot350, align 8
  %v2214 = load i64, ptr %slot350, align 8
  %cmp2215 = icmp ult i64 %v2214, 2
  %cv2216 = zext i1 %cmp2215 to i32
  store i32 %cv2216, ptr %slot351, align 8
  %v2217 = load i32, ptr %slot351, align 8
  %cv2218 = zext i32 %v2217 to i64
  %cond2219 = icmp ne i64 %cv2218, 0
  br i1 %cond2219, label %bb_rcgunique403, label %bb_rcguniqueslow403
bb_rcguniqueslow403:
  %v2220 = load i64, ptr %slot1, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %p2222 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v2223 = load i64, ptr %slot342, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %v2225 = load i64, ptr %slot7, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  %call2227 = call i32 @myl_qbe_rc_unique_local(ptr %p2221, ptr %p2222, ptr %p2224, ptr %p2226) nomerge, !dbg !126
  store i32 %call2227, ptr %slot352, align 8
  %v2228 = load i32, ptr %slot352, align 8
  %cv2229 = zext i32 %v2228 to i64
  %cond2230 = icmp ne i64 %cv2229, 0
  br i1 %cond2230, label %bb_rcunique414, label %bb_failure
bb_rcunique414:
  br label %bb_rcgunique403
bb_rcgunique403:
  %v2231 = load i64, ptr %slot24, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %ld2233 = load i64, ptr %p2232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2233, ptr %slot353, align 8
  %v2234 = load i64, ptr %slot26, align 8
  store i64 %v2234, ptr %slot354, align 8
  %v2235 = load i64, ptr %slot354, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i64, ptr %p2236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2237, ptr %slot355, align 8
  %v2238 = load i64, ptr %slot353, align 8
  %op2239 = add i64 %v2238, 0
  store i64 %op2239, ptr %slot356, align 8
  %v2240 = load i64, ptr %slot356, align 8
  %p2241 = inttoptr i64 %v2240 to ptr
  %ld2242 = load i64, ptr %p2241, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2242, ptr %slot357, align 8
  %v2243 = load i64, ptr %slot353, align 8
  %op2244 = add i64 %v2243, 8
  store i64 %op2244, ptr %slot358, align 8
  %v2245 = load i64, ptr %slot358, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i64, ptr %p2246, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2247, ptr %slot359, align 8
  %v2248 = load i64, ptr %slot353, align 8
  %op2249 = add i64 %v2248, 16
  store i64 %op2249, ptr %slot360, align 8
  %v2250 = load i64, ptr %slot360, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  %ld2252 = load i64, ptr %p2251, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2252, ptr %slot361, align 8
  %v2253 = load i64, ptr %slot357, align 8
  %v2254 = load i64, ptr %slot359, align 8
  %cmp2255 = icmp ult i64 %v2253, %v2254
  %cv2256 = zext i1 %cmp2255 to i32
  store i32 %cv2256, ptr %slot362, align 8
  %v2257 = load i64, ptr %slot361, align 8
  %cmp2258 = icmp ne i64 %v2257, 18446744073709551615
  %cv2259 = zext i1 %cmp2258 to i32
  store i32 %cv2259, ptr %slot363, align 8
  %v2260 = load i32, ptr %slot362, align 8
  %v2261 = load i32, ptr %slot363, align 8
  %op2262 = and i32 %v2260, %v2261
  store i32 %op2262, ptr %slot364, align 8
  %v2263 = load i32, ptr %slot364, align 8
  %cv2264 = zext i32 %v2263 to i64
  %cond2265 = icmp ne i64 %cv2264, 0
  br i1 %cond2265, label %bb_rcappend_check419, label %bb_rcappend_slow419
bb_rcappend_check419:
  %v2266 = load i64, ptr %slot37, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %v2268 = load i64, ptr %slot353, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %call2270 = call i32 @myl_rc_list_plain_ready(ptr %p2267, ptr %p2269) nomerge, !dbg !126
  store i32 %call2270, ptr %slot365, align 8
  %v2271 = load i32, ptr %slot365, align 8
  %cv2272 = zext i32 %v2271 to i64
  %cond2273 = icmp ne i64 %cv2272, 0
  br i1 %cond2273, label %bb_rcappend_fast419, label %bb_rcappend_slow419
bb_rcappend_slow419:
  %v2274 = load i64, ptr %slot354, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  %ld2276 = load i64, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2276, ptr %slot366, align 8
  %v2277 = load i64, ptr %slot366, align 8
  %v2278 = load i64, ptr %slot21, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  store i64 %v2277, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  %v2280 = load i64, ptr %slot21, align 8
  store i64 %v2280, ptr %slot367, align 8
  %v2281 = load i64, ptr %slot37, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %v2283 = load i64, ptr %slot353, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  %v2285 = load i64, ptr %slot367, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %call2287 = call i32 @myl_rc_list_append(ptr %p2282, ptr %p2284, ptr %p2286) nomerge, !dbg !126
  store i32 %call2287, ptr %slot368, align 8
  %v2288 = load i32, ptr %slot368, align 8
  %cv2289 = zext i32 %v2288 to i64
  %cond2290 = icmp ne i64 %cv2289, 0
  br i1 %cond2290, label %bb_success432, label %bb_failed432
bb_failed432:
  %v2291 = load i64, ptr %slot1, align 8
  %p2292 = inttoptr i64 %v2291 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2292) nomerge, !dbg !126
  unreachable
bb_success432:
  br label %bb_rcappend_done419
bb_rcappend_fast419:
  %v2293 = load i64, ptr %slot353, align 8
  %op2294 = add i64 %v2293, 32
  store i64 %op2294, ptr %slot369, align 8
  %v2295 = load i64, ptr %slot369, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  %ld2297 = load i64, ptr %p2296, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2297, ptr %slot370, align 8
  %v2298 = load i64, ptr %slot357, align 8
  %op2299 = mul i64 %v2298, 8
  store i64 %op2299, ptr %slot371, align 8
  %v2300 = load i64, ptr %slot370, align 8
  %v2301 = load i64, ptr %slot371, align 8
  %op2302 = add i64 %v2300, %v2301
  store i64 %op2302, ptr %slot372, align 8
  %v2303 = load i64, ptr %slot355, align 8
  %v2304 = load i64, ptr %slot370, align 8
  %p2305 = inttoptr i64 %v2304 to ptr
  %v2306 = load i64, ptr %slot371, align 8
  %egep2307 = getelementptr i8, ptr %p2305, i64 %v2306
  store i64 %v2303, ptr %egep2307, align 8, !alias.scope !12, !noalias !13
  %v2308 = load i64, ptr %slot353, align 8
  %op2309 = add i64 %v2308, 0
  store i64 %op2309, ptr %slot373, align 8
  %v2310 = load i64, ptr %slot357, align 8
  %op2311 = add i64 %v2310, 1
  store i64 %op2311, ptr %slot374, align 8
  %v2312 = load i64, ptr %slot374, align 8
  %v2313 = load i64, ptr %slot373, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  store i64 %v2312, ptr %p2314, align 8, !alias.scope !6, !noalias !7
  %v2315 = load i64, ptr %slot353, align 8
  %op2316 = add i64 %v2315, 16
  store i64 %op2316, ptr %slot375, align 8
  %v2317 = load i64, ptr %slot361, align 8
  %op2318 = add i64 %v2317, 1
  store i64 %op2318, ptr %slot376, align 8
  %v2319 = load i64, ptr %slot376, align 8
  %v2320 = load i64, ptr %slot375, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  store i64 %v2319, ptr %p2321, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done419
bb_rcappend_done419:
  %v2322 = load i64, ptr %slot26, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  store i64 0, ptr %p2323, align 8, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_i24:
  br label %bb_i25
bb_i25:
  br label %bb_i6
bb_i26:
  %v2324 = load i64, ptr %slot22, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i64, ptr %p2325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2326, ptr %slot377, align 8
  %v2327 = load i64, ptr %slot377, align 8
  %v2328 = load i64, ptr %slot26, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  store i64 %v2327, ptr %p2329, align 8, !alias.scope !3, !noalias !4
  %v2330 = load i64, ptr %slot30, align 8
  store i64 %v2330, ptr %slot378, align 8
  %v2331 = load i64, ptr %slot378, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 0, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot378, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i32 3, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot378, align 8
  %v2336 = load i64, ptr %slot27, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  store i64 %v2335, ptr %p2337, align 8, !alias.scope !3, !noalias !4
  %p2338 = inttoptr i64 ptrtoint (ptr @myl_lit_146d534849d3e93fd30ab0fa32197316072c792978757f394cddd3246cba50a7 to i64) to ptr
  %ld2339 = load i64, ptr %p2338, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2339, ptr %slot379, align 8
  %v2340 = load i64, ptr %slot379, align 8
  %v2341 = load i64, ptr %slot28, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i64 %v2340, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot28, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i64, ptr %p2344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2345, ptr %slot380, align 8
  %v2346 = load i64, ptr %slot380, align 8
  %v2347 = load i64, ptr %slot19, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  store i64 %v2346, ptr %p2348, align 8, !alias.scope !3, !noalias !4
  %v2349 = load i64, ptr %slot19, align 8
  store i64 %v2349, ptr %slot381, align 8
  %v2350 = load i64, ptr %slot20, align 8
  store i64 %v2350, ptr %slot382, align 8
  %v2351 = load i64, ptr %slot381, align 8
  %v2352 = load i64, ptr %slot382, align 8
  %p2353 = inttoptr i64 %v2351 to ptr
  %p2354 = inttoptr i64 %v2352 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2354, ptr %p2353, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot14, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i32 2, ptr %p2356, align 4, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot13, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i32 1, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot17, align 8
  store i64 %v2359, ptr %slot383, align 8
  %v2360 = load i64, ptr %slot20, align 8
  store i64 %v2360, ptr %slot384, align 8
  %v2361 = load i64, ptr %slot384, align 8
  %v2362 = load i64, ptr %slot383, align 8
  %p2363 = inttoptr i64 %v2361 to ptr
  %p2364 = inttoptr i64 %v2362 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2364, ptr %p2363, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot12, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  store i32 2, ptr %p2366, align 4, !alias.scope !3, !noalias !4
  %v2367 = load i64, ptr %slot14, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %ld2369 = load i32, ptr %p2368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2369, ptr %slot385, align 8
  %v2370 = load i32, ptr %slot385, align 8
  %v2371 = load i64, ptr %slot12, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  store i32 %v2370, ptr %p2372, align 4, !alias.scope !3, !noalias !4
  %v2373 = load i64, ptr %slot13, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  store i32 0, ptr %p2374, align 4, !alias.scope !3, !noalias !4
  %v2375 = load i64, ptr %slot11, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  store i32 1, ptr %p2376, align 4, !alias.scope !3, !noalias !4
  %v2377 = load i64, ptr %slot383, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  %ld2379 = load i64, ptr %p2378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2379, ptr %slot386, align 8
  %v2380 = load i64, ptr %slot386, align 8
  %v2381 = load i64, ptr %slot28, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  store i64 %v2380, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  %v2383 = load i64, ptr %slot26, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  %ld2385 = load i64, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2385, ptr %slot387, align 8
  %v2386 = load i64, ptr %slot27, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %ld2388 = load i64, ptr %p2387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2388, ptr %slot388, align 8
  %v2389 = load i64, ptr %slot28, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  %ld2391 = load i64, ptr %p2390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2391, ptr %slot389, align 8
  %v2392 = load i64, ptr %slot1, align 8
  %v2393 = load i64, ptr %slot387, align 8
  %v2394 = load i64, ptr %slot388, align 8
  %v2395 = load i64, ptr %slot389, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult391, i64 %v2392, i64 %v2393, i64 %v2394, i64 %v2395) nomerge, !dbg !128
  %addr2396 = ptrtoint ptr %callresult391 to i64
  store i64 %addr2396, ptr %slot390, align 8
  %v2397 = load i64, ptr %slot390, align 8
  %v2398 = load i64, ptr %slot26, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot26, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot392, align 8
  %v2403 = load i64, ptr %slot20, align 8
  store i64 %v2403, ptr %slot393, align 8
  %v2404 = load i64, ptr %slot392, align 8
  %v2405 = load i64, ptr %slot393, align 8
  %p2406 = inttoptr i64 %v2404 to ptr
  %p2407 = inttoptr i64 %v2405 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2407, ptr %p2406, i64 48, i1 false)
  %v2408 = load i64, ptr %slot14, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i32 2, ptr %p2409, align 4, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot13, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  store i32 1, ptr %p2411, align 4, !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot9, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %ld2414 = load i32, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2414, ptr %slot394, align 8
  %v2415 = load i32, ptr %slot394, align 8
  %cv2416 = zext i32 %v2415 to i64
  %cond2417 = icmp ne i64 %cv2416, 0
  br i1 %cond2417, label %bb_rcslotdrop469, label %bb_rcslotdone469
bb_rcslotdrop469:
  %v2418 = load i64, ptr %slot9, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  store i32 0, ptr %p2419, align 4, !alias.scope !3, !noalias !4
  %v2420 = load i64, ptr %slot16, align 8
  store i64 %v2420, ptr %slot395, align 8
  %v2421 = load i64, ptr %slot10, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  %ld2423 = load i32, ptr %p2422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2423, ptr %slot396, align 8
  %v2424 = load i32, ptr %slot396, align 8
  %op2425 = and i32 %v2424, 28
  store i32 %op2425, ptr %slot397, align 8
  %v2426 = load i32, ptr %slot397, align 8
  %cv2427 = zext i32 %v2426 to i64
  %cond2428 = icmp ne i64 %cv2427, 0
  br i1 %cond2428, label %bb_rcslotrole469, label %bb_rcslotowner469
bb_rcslotrole469:
  %v2429 = load i64, ptr %slot37, align 8
  store i64 %v2429, ptr %slot398, align 8
  %v2430 = load i64, ptr %slot398, align 8
  %v2431 = load i64, ptr %slot395, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2430, i64 %v2431) nomerge, !dbg !128
  br label %bb_rcslotdone469
bb_rcslotowner469:
  %v2432 = load i64, ptr %slot37, align 8
  store i64 %v2432, ptr %slot399, align 8
  %v2433 = load i64, ptr %slot399, align 8
  %v2434 = load i64, ptr %slot395, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2433, i64 %v2434) nomerge, !dbg !128
  br label %bb_rcslotdone469
bb_rcslotdone469:
  %v2435 = load i64, ptr %slot11, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %ld2437 = load i32, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2437, ptr %slot400, align 8
  %v2438 = load i32, ptr %slot400, align 8
  %cv2439 = zext i32 %v2438 to i64
  %cond2440 = icmp ne i64 %cv2439, 0
  br i1 %cond2440, label %bb_rcslotdrop478, label %bb_rcslotdone478
bb_rcslotdrop478:
  %v2441 = load i64, ptr %slot11, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  store i32 0, ptr %p2442, align 4, !alias.scope !3, !noalias !4
  %v2443 = load i64, ptr %slot17, align 8
  store i64 %v2443, ptr %slot401, align 8
  %v2444 = load i64, ptr %slot12, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %ld2446 = load i32, ptr %p2445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2446, ptr %slot402, align 8
  %v2447 = load i32, ptr %slot402, align 8
  %op2448 = and i32 %v2447, 28
  store i32 %op2448, ptr %slot403, align 8
  %v2449 = load i32, ptr %slot403, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcslotrole478, label %bb_rcslotowner478
bb_rcslotrole478:
  %v2452 = load i64, ptr %slot37, align 8
  store i64 %v2452, ptr %slot404, align 8
  %v2453 = load i64, ptr %slot401, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  %ld2455 = load i64, ptr %p2454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2455, ptr %slot405, align 8
  %v2456 = load i64, ptr %slot405, align 8
  %cmp2457 = icmp ne i64 %v2456, 0
  %cv2458 = zext i1 %cmp2457 to i32
  store i32 %cv2458, ptr %slot406, align 8
  %v2459 = load i32, ptr %slot406, align 8
  %cv2460 = zext i32 %v2459 to i64
  %cond2461 = icmp ne i64 %cv2460, 0
  br i1 %cond2461, label %bb_rcgnn494, label %bb_rcgdone494
bb_rcgnn494:
  %v2462 = load i64, ptr %slot405, align 8
  %op2463 = sub i64 %v2462, 16
  store i64 %op2463, ptr %slot407, align 8
  %v2464 = load i64, ptr %slot405, align 8
  %p2465 = inttoptr i64 %v2464 to ptr
  %rgep2466 = getelementptr i8, ptr %p2465, i64 -16
  %ld2467 = load i64, ptr %rgep2466, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2467, ptr %slot408, align 8
  %v2468 = load i64, ptr %slot408, align 8
  %op2469 = and i64 %v2468, 4611686018427387906
  store i64 %op2469, ptr %slot409, align 8
  %v2470 = load i64, ptr %slot409, align 8
  %cmp2471 = icmp ne i64 %v2470, 0
  %cv2472 = zext i1 %cmp2471 to i32
  store i32 %cv2472, ptr %slot410, align 8
  %v2473 = load i32, ptr %slot410, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcgclear494, label %bb_rcgcounted494
bb_rcgcounted494:
  %v2476 = load i64, ptr %slot405, align 8
  %op2477 = sub i64 %v2476, 24
  store i64 %op2477, ptr %slot411, align 8
  %v2478 = load i64, ptr %slot405, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %rgep2480 = getelementptr i8, ptr %p2479, i64 -24
  %ld2481 = load i64, ptr %rgep2480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2481, ptr %slot412, align 8
  %v2482 = load i64, ptr %slot412, align 8
  %op2483 = sub i64 %v2482, 1
  store i64 %op2483, ptr %slot413, align 8
  %v2484 = load i64, ptr %slot413, align 8
  %cmp2485 = icmp eq i64 %v2484, 0
  %cv2486 = zext i1 %cmp2485 to i32
  store i32 %cv2486, ptr %slot414, align 8
  %v2487 = load i32, ptr %slot414, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcglast494, label %bb_rcgdec494
bb_rcglast494:
  %v2490 = load i64, ptr %slot405, align 8
  %op2491 = sub i64 %v2490, 32
  store i64 %op2491, ptr %slot415, align 8
  %v2492 = load i64, ptr %slot405, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  %rgep2494 = getelementptr i8, ptr %p2493, i64 -32
  %ld2495 = load i64, ptr %rgep2494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2495, ptr %slot416, align 8
  %v2496 = load i64, ptr %slot416, align 8
  %cmp2497 = icmp ne i64 %v2496, 0
  %cv2498 = zext i1 %cmp2497 to i32
  store i32 %cv2498, ptr %slot417, align 8
  %v2499 = load i32, ptr %slot417, align 8
  %cv2500 = zext i32 %v2499 to i64
  %cond2501 = icmp ne i64 %cv2500, 0
  br i1 %cond2501, label %bb_rcgdec494, label %bb_rcgslow494
bb_rcgslow494:
  %v2502 = load i64, ptr %slot404, align 8
  %v2503 = load i64, ptr %slot401, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2502, i64 %v2503) nomerge, !dbg !128
  br label %bb_rcgdone494
bb_rcgdec494:
  %v2504 = load i64, ptr %slot413, align 8
  %v2505 = load i64, ptr %slot405, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -24
  store i64 %v2504, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear494
bb_rcgclear494:
  %v2508 = load i64, ptr %slot401, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  store i64 0, ptr %p2509, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone494
bb_rcgdone494:
  br label %bb_rcslotdone478
bb_rcslotowner478:
  %v2510 = load i64, ptr %slot37, align 8
  store i64 %v2510, ptr %slot418, align 8
  %v2511 = load i64, ptr %slot401, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  %ld2513 = load i64, ptr %p2512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2513, ptr %slot419, align 8
  %v2514 = load i64, ptr %slot419, align 8
  %cmp2515 = icmp ne i64 %v2514, 0
  %cv2516 = zext i1 %cmp2515 to i32
  store i32 %cv2516, ptr %slot420, align 8
  %v2517 = load i32, ptr %slot420, align 8
  %cv2518 = zext i32 %v2517 to i64
  %cond2519 = icmp ne i64 %cv2518, 0
  br i1 %cond2519, label %bb_rcgnn509, label %bb_rcgdone509
bb_rcgnn509:
  %v2520 = load i64, ptr %slot419, align 8
  %op2521 = sub i64 %v2520, 16
  store i64 %op2521, ptr %slot421, align 8
  %v2522 = load i64, ptr %slot419, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  %rgep2524 = getelementptr i8, ptr %p2523, i64 -16
  %ld2525 = load i64, ptr %rgep2524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2525, ptr %slot422, align 8
  %v2526 = load i64, ptr %slot422, align 8
  %op2527 = and i64 %v2526, 4611686018427387906
  store i64 %op2527, ptr %slot423, align 8
  %v2528 = load i64, ptr %slot423, align 8
  %cmp2529 = icmp ne i64 %v2528, 0
  %cv2530 = zext i1 %cmp2529 to i32
  store i32 %cv2530, ptr %slot424, align 8
  %v2531 = load i32, ptr %slot424, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rcgclear509, label %bb_rcgcounted509
bb_rcgcounted509:
  %v2534 = load i64, ptr %slot419, align 8
  %op2535 = sub i64 %v2534, 32
  store i64 %op2535, ptr %slot425, align 8
  %v2536 = load i64, ptr %slot419, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %rgep2538 = getelementptr i8, ptr %p2537, i64 -32
  %ld2539 = load i64, ptr %rgep2538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2539, ptr %slot426, align 8
  %v2540 = load i64, ptr %slot426, align 8
  %op2541 = sub i64 %v2540, 1
  store i64 %op2541, ptr %slot427, align 8
  %v2542 = load i64, ptr %slot427, align 8
  %cmp2543 = icmp eq i64 %v2542, 0
  %cv2544 = zext i1 %cmp2543 to i32
  store i32 %cv2544, ptr %slot428, align 8
  %v2545 = load i32, ptr %slot428, align 8
  %cv2546 = zext i32 %v2545 to i64
  %cond2547 = icmp ne i64 %cv2546, 0
  br i1 %cond2547, label %bb_rcglast509, label %bb_rcgdec509
bb_rcglast509:
  %v2548 = load i64, ptr %slot419, align 8
  %op2549 = sub i64 %v2548, 24
  store i64 %op2549, ptr %slot429, align 8
  %v2550 = load i64, ptr %slot419, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %rgep2552 = getelementptr i8, ptr %p2551, i64 -24
  %ld2553 = load i64, ptr %rgep2552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2553, ptr %slot430, align 8
  %v2554 = load i64, ptr %slot430, align 8
  %cmp2555 = icmp ne i64 %v2554, 0
  %cv2556 = zext i1 %cmp2555 to i32
  store i32 %cv2556, ptr %slot431, align 8
  %v2557 = load i32, ptr %slot431, align 8
  %cv2558 = zext i32 %v2557 to i64
  %cond2559 = icmp ne i64 %cv2558, 0
  br i1 %cond2559, label %bb_rcgdec509, label %bb_rcgslow509
bb_rcgslow509:
  %v2560 = load i64, ptr %slot418, align 8
  %v2561 = load i64, ptr %slot401, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2560, i64 %v2561) nomerge, !dbg !128
  br label %bb_rcgdone509
bb_rcgdec509:
  %v2562 = load i64, ptr %slot427, align 8
  %v2563 = load i64, ptr %slot419, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %rgep2565 = getelementptr i8, ptr %p2564, i64 -32
  store i64 %v2562, ptr %rgep2565, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear509
bb_rcgclear509:
  %v2566 = load i64, ptr %slot401, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i64 0, ptr %p2567, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone509
bb_rcgdone509:
  br label %bb_rcslotdone478
bb_rcslotdone478:
  %v2568 = load i64, ptr %slot16, align 8
  store i64 %v2568, ptr %slot432, align 8
  %v2569 = load i64, ptr %slot20, align 8
  store i64 %v2569, ptr %slot433, align 8
  %v2570 = load i64, ptr %slot433, align 8
  %v2571 = load i64, ptr %slot432, align 8
  %p2572 = inttoptr i64 %v2570 to ptr
  %p2573 = inttoptr i64 %v2571 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2573, ptr %p2572, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2574 = load i64, ptr %slot10, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  store i32 2, ptr %p2575, align 4, !alias.scope !3, !noalias !4
  %v2576 = load i64, ptr %slot14, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %ld2578 = load i32, ptr %p2577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2578, ptr %slot434, align 8
  %v2579 = load i32, ptr %slot434, align 8
  %v2580 = load i64, ptr %slot10, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  store i32 %v2579, ptr %p2581, align 4, !alias.scope !3, !noalias !4
  %v2582 = load i64, ptr %slot13, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  store i32 0, ptr %p2583, align 4, !alias.scope !3, !noalias !4
  %v2584 = load i64, ptr %slot9, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  store i32 1, ptr %p2585, align 4, !alias.scope !3, !noalias !4
  %v2586 = load i64, ptr %slot432, align 8
  %v2587 = load i64, ptr %slot26, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  store i64 %v2586, ptr %p2588, align 8, !alias.scope !3, !noalias !4
  %v2589 = load i64, ptr %slot26, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  %ld2591 = load i64, ptr %p2590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2591, ptr %slot435, align 8
  %v2592 = load i64, ptr %slot435, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  %ld2594 = load i32, ptr %p2593, align 4
  %ext2595 = zext i32 %ld2594 to i64
  store i64 %ext2595, ptr %slot436, align 8
  %v2596 = load i64, ptr %slot436, align 8
  %cmp2597 = icmp eq i64 %v2596, 0
  %cv2598 = zext i1 %cmp2597 to i64
  store i64 %cv2598, ptr %slot437, align 8
  %v2599 = load i64, ptr %slot437, align 8
  %cond2600 = icmp ne i64 %v2599, 0
  br i1 %cond2600, label %bb_rctryok522, label %bb_rctryerror522
bb_rctryerror522:
  %p2601 = inttoptr i64 ptrtoint (ptr @myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2601, i64 12884901918) "call-inline-cost"="0", !dbg !130
  %v2602 = load i64, ptr %slot435, align 8
  %op2603 = add i64 %v2602, 8
  store i64 %op2603, ptr %slot438, align 8
  %v2604 = load i64, ptr %slot31, align 8
  store i64 %v2604, ptr %slot439, align 8
  %v2605 = load i64, ptr %slot439, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  store i64 0, ptr %p2606, align 8, !alias.scope !3, !noalias !4
  %v2607 = load i64, ptr %slot439, align 8
  %p2609 = inttoptr i64 %v2607 to ptr
  %gep2610 = getelementptr i8, ptr %p2609, i64 8
  %op2608 = ptrtoint ptr %gep2610 to i64
  store i64 %op2608, ptr %slot440, align 8
  %v2611 = load i64, ptr %slot440, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  store i64 0, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  %v2613 = load i64, ptr %slot439, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i32 1, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot439, align 8
  %p2617 = inttoptr i64 %v2615 to ptr
  %gep2618 = getelementptr i8, ptr %p2617, i64 8
  %op2616 = ptrtoint ptr %gep2618 to i64
  store i64 %op2616, ptr %slot441, align 8
  %v2619 = load i64, ptr %slot15, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i32 1, ptr %p2620, align 4, !alias.scope !3, !noalias !4
  %v2621 = load i64, ptr %slot38, align 8
  store i64 %v2621, ptr %slot442, align 8
  %v2622 = load i64, ptr %slot439, align 8
  %v2623 = load i64, ptr %slot26, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  store i64 %v2622, ptr %p2624, align 8, !alias.scope !3, !noalias !4
  %v2625 = load i64, ptr %slot26, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  %ld2627 = load i64, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2627, ptr %slot443, align 8
  %v2628 = load i64, ptr %slot20, align 8
  store i64 %v2628, ptr %slot444, align 8
  %v2629 = load i64, ptr %slot443, align 8
  %v2630 = load i64, ptr %slot444, align 8
  %p2631 = inttoptr i64 %v2629 to ptr
  %p2632 = inttoptr i64 %v2630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2632, ptr %p2631, i64 16, i1 false)
  %v2633 = load i64, ptr %slot14, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i32 2, ptr %p2634, align 4, !alias.scope !3, !noalias !4
  %v2635 = load i64, ptr %slot13, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i32 1, ptr %p2636, align 4, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot9, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i32, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2639, ptr %slot445, align 8
  %v2640 = load i32, ptr %slot445, align 8
  %cv2641 = zext i32 %v2640 to i64
  %cond2642 = icmp ne i64 %cv2641, 0
  br i1 %cond2642, label %bb_rcslotdrop537, label %bb_rcslotdone537
bb_rcslotdrop537:
  %v2643 = load i64, ptr %slot9, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i32 0, ptr %p2644, align 4, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot16, align 8
  store i64 %v2645, ptr %slot446, align 8
  %v2646 = load i64, ptr %slot10, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  %ld2648 = load i32, ptr %p2647, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2648, ptr %slot447, align 8
  %v2649 = load i32, ptr %slot447, align 8
  %op2650 = and i32 %v2649, 28
  store i32 %op2650, ptr %slot448, align 8
  %v2651 = load i32, ptr %slot448, align 8
  %cv2652 = zext i32 %v2651 to i64
  %cond2653 = icmp ne i64 %cv2652, 0
  br i1 %cond2653, label %bb_rcslotrole537, label %bb_rcslotowner537
bb_rcslotrole537:
  %v2654 = load i64, ptr %slot37, align 8
  store i64 %v2654, ptr %slot449, align 8
  %v2655 = load i64, ptr %slot449, align 8
  %v2656 = load i64, ptr %slot446, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v2655, i64 %v2656) nomerge, !dbg !130
  br label %bb_rcslotdone537
bb_rcslotowner537:
  %v2657 = load i64, ptr %slot37, align 8
  store i64 %v2657, ptr %slot450, align 8
  %v2658 = load i64, ptr %slot450, align 8
  %v2659 = load i64, ptr %slot446, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v2658, i64 %v2659) nomerge, !dbg !130
  br label %bb_rcslotdone537
bb_rcslotdone537:
  %v2660 = load i64, ptr %slot16, align 8
  store i64 %v2660, ptr %slot451, align 8
  %v2661 = load i64, ptr %slot20, align 8
  store i64 %v2661, ptr %slot452, align 8
  %v2662 = load i64, ptr %slot452, align 8
  %v2663 = load i64, ptr %slot451, align 8
  %p2664 = inttoptr i64 %v2662 to ptr
  %p2665 = inttoptr i64 %v2663 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2665, ptr %p2664, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2666 = load i64, ptr %slot10, align 8
  %p2667 = inttoptr i64 %v2666 to ptr
  store i32 2, ptr %p2667, align 4, !alias.scope !3, !noalias !4
  %v2668 = load i64, ptr %slot14, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  %ld2670 = load i32, ptr %p2669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2670, ptr %slot453, align 8
  %v2671 = load i32, ptr %slot453, align 8
  %v2672 = load i64, ptr %slot10, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  store i32 %v2671, ptr %p2673, align 4, !alias.scope !3, !noalias !4
  %v2674 = load i64, ptr %slot13, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i32 0, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot9, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 1, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot451, align 8
  %v2679 = load i64, ptr %slot26, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  store i64 %v2678, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  br label %bb_i32
bb_rctryok522:
  %v2681 = load i64, ptr %slot31, align 8
  store i64 %v2681, ptr %slot454, align 8
  %v2682 = load i64, ptr %slot454, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i64 0, ptr %p2683, align 8, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot454, align 8
  %p2686 = inttoptr i64 %v2684 to ptr
  %gep2687 = getelementptr i8, ptr %p2686, i64 8
  %op2685 = ptrtoint ptr %gep2687 to i64
  store i64 %op2685, ptr %slot455, align 8
  %v2688 = load i64, ptr %slot455, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  store i64 0, ptr %p2689, align 8, !alias.scope !3, !noalias !4
  %v2690 = load i64, ptr %slot454, align 8
  %p2692 = inttoptr i64 %v2690 to ptr
  %gep2693 = getelementptr i8, ptr %p2692, i64 16
  %op2691 = ptrtoint ptr %gep2693 to i64
  store i64 %op2691, ptr %slot456, align 8
  %v2694 = load i64, ptr %slot456, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  store i64 0, ptr %p2695, align 8, !alias.scope !3, !noalias !4
  %v2696 = load i64, ptr %slot454, align 8
  %p2698 = inttoptr i64 %v2696 to ptr
  %gep2699 = getelementptr i8, ptr %p2698, i64 24
  %op2697 = ptrtoint ptr %gep2699 to i64
  store i64 %op2697, ptr %slot457, align 8
  %v2700 = load i64, ptr %slot457, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  store i64 0, ptr %p2701, align 8, !alias.scope !3, !noalias !4
  %v2702 = load i64, ptr %slot454, align 8
  %p2704 = inttoptr i64 %v2702 to ptr
  %gep2705 = getelementptr i8, ptr %p2704, i64 32
  %op2703 = ptrtoint ptr %gep2705 to i64
  store i64 %op2703, ptr %slot458, align 8
  %v2706 = load i64, ptr %slot458, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i64 0, ptr %p2707, align 8, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot15, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  store i32 1, ptr %p2709, align 4, !alias.scope !3, !noalias !4
  %v2710 = load i64, ptr %slot435, align 8
  %op2711 = add i64 %v2710, 8
  store i64 %op2711, ptr %slot459, align 8
  %v2712 = load i64, ptr %slot38, align 8
  store i64 %v2712, ptr %slot460, align 8
  %v2713 = load i64, ptr %slot37, align 8
  %v2714 = load i64, ptr %slot454, align 8
  %v2715 = load i64, ptr %slot459, align 8
  %v2716 = load i64, ptr %slot460, align 8
  %cv2717 = trunc i64 %v2716 to i32
  %call2718 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v2713, i64 %v2714, i64 %v2715, i32 %cv2717) nomerge, !dbg !130
  store i32 %call2718, ptr %slot461, align 8
  %v2719 = load i32, ptr %slot461, align 8
  %cv2720 = zext i32 %v2719 to i64
  %cond2721 = icmp ne i64 %cv2720, 0
  br i1 %cond2721, label %bb_rcsuccess562, label %bb_rcfailure562
bb_rcfailure562:
  %v2722 = load i64, ptr %slot37, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %call2724 = call i32 @myl_rc_take_failure(ptr %p2723) nomerge, !dbg !130
  store i32 %call2724, ptr %slot462, align 8
  %v2725 = load i64, ptr %slot1, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  %v2727 = load i32, ptr %slot462, align 8
  %call2728 = call i32 @myl_qbe_rc_status(ptr %p2726, i32 %v2727) nomerge, !dbg !130
  store i32 %call2728, ptr %slot463, align 8
  br label %bb_failure
bb_rcsuccess562:
  %v2729 = load i64, ptr %slot454, align 8
  %v2730 = load i64, ptr %slot26, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  store i64 %v2729, ptr %p2731, align 8, !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot26, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  %ld2734 = load i64, ptr %p2733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2734, ptr %slot464, align 8
  %v2735 = load i64, ptr %slot20, align 8
  store i64 %v2735, ptr %slot465, align 8
  %v2736 = load i64, ptr %slot464, align 8
  %v2737 = load i64, ptr %slot465, align 8
  %p2738 = inttoptr i64 %v2736 to ptr
  %p2739 = inttoptr i64 %v2737 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2739, ptr %p2738, i64 40, i1 false)
  %v2740 = load i64, ptr %slot14, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  store i32 2, ptr %p2741, align 4, !alias.scope !3, !noalias !4
  %v2742 = load i64, ptr %slot13, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  store i32 1, ptr %p2743, align 4, !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot9, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  %ld2746 = load i32, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2746, ptr %slot466, align 8
  %v2747 = load i32, ptr %slot466, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcslotdrop571, label %bb_rcslotdone571
bb_rcslotdrop571:
  %v2750 = load i64, ptr %slot9, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i32 0, ptr %p2751, align 4, !alias.scope !3, !noalias !4
  %v2752 = load i64, ptr %slot16, align 8
  store i64 %v2752, ptr %slot467, align 8
  %v2753 = load i64, ptr %slot10, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %ld2755 = load i32, ptr %p2754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2755, ptr %slot468, align 8
  %v2756 = load i32, ptr %slot468, align 8
  %op2757 = and i32 %v2756, 28
  store i32 %op2757, ptr %slot469, align 8
  %v2758 = load i32, ptr %slot469, align 8
  %cv2759 = zext i32 %v2758 to i64
  %cond2760 = icmp ne i64 %cv2759, 0
  br i1 %cond2760, label %bb_rcslotrole571, label %bb_rcslotowner571
bb_rcslotrole571:
  %v2761 = load i64, ptr %slot37, align 8
  store i64 %v2761, ptr %slot470, align 8
  %v2762 = load i64, ptr %slot470, align 8
  %v2763 = load i64, ptr %slot467, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v2762, i64 %v2763) nomerge, !dbg !130
  br label %bb_rcslotdone571
bb_rcslotowner571:
  %v2764 = load i64, ptr %slot37, align 8
  store i64 %v2764, ptr %slot471, align 8
  %v2765 = load i64, ptr %slot471, align 8
  %v2766 = load i64, ptr %slot467, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v2765, i64 %v2766) nomerge, !dbg !130
  br label %bb_rcslotdone571
bb_rcslotdone571:
  %v2767 = load i64, ptr %slot16, align 8
  store i64 %v2767, ptr %slot472, align 8
  %v2768 = load i64, ptr %slot20, align 8
  store i64 %v2768, ptr %slot473, align 8
  %v2769 = load i64, ptr %slot473, align 8
  %v2770 = load i64, ptr %slot472, align 8
  %p2771 = inttoptr i64 %v2769 to ptr
  %p2772 = inttoptr i64 %v2770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2772, ptr %p2771, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot10, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i32 2, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot14, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i32, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2777, ptr %slot474, align 8
  %v2778 = load i32, ptr %slot474, align 8
  %v2779 = load i64, ptr %slot10, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  store i32 %v2778, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  %v2781 = load i64, ptr %slot13, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i32 0, ptr %p2782, align 4, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot9, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 1, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot472, align 8
  %v2786 = load i64, ptr %slot26, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i64 %v2785, ptr %p2787, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i32:
  %v2788 = load i64, ptr %slot26, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2790, ptr %slot475, align 8
  %v2791 = load i64, ptr %slot26, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i64, ptr %p2792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2793, ptr %slot476, align 8
  %v2794 = load i64, ptr %slot9, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %ld2796 = load i32, ptr %p2795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2796, ptr %slot477, align 8
  %v2797 = load i64, ptr %slot10, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i32, ptr %p2798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2799, ptr %slot478, align 8
  %v2800 = load i32, ptr %slot478, align 8
  %op2801 = and i32 %v2800, 24
  store i32 %op2801, ptr %slot478, align 8
  %v2802 = load i32, ptr %slot478, align 8
  %cmp2803 = icmp eq i32 %v2802, 0
  %cv2804 = zext i1 %cmp2803 to i32
  store i32 %cv2804, ptr %slot479, align 8
  %v2805 = load i32, ptr %slot477, align 8
  %v2806 = load i32, ptr %slot479, align 8
  %op2807 = and i32 %v2805, %v2806
  store i32 %op2807, ptr %slot480, align 8
  %v2808 = load i32, ptr %slot480, align 8
  %cv2809 = zext i32 %v2808 to i64
  %cond2810 = icmp ne i64 %cv2809, 0
  br i1 %cond2810, label %bb_rctake588, label %bb_rccopy588
bb_rctake588:
  %v2811 = load i64, ptr %slot20, align 8
  store i64 %v2811, ptr %slot481, align 8
  %v2812 = load i64, ptr %slot38, align 8
  store i64 %v2812, ptr %slot482, align 8
  %v2813 = load i64, ptr %slot37, align 8
  %v2814 = load i64, ptr %slot481, align 8
  %v2815 = load i64, ptr %slot476, align 8
  %v2816 = load i64, ptr %slot482, align 8
  %cv2817 = trunc i64 %v2816 to i32
  %call2818 = call i32 @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_take(i64 %v2813, i64 %v2814, i64 %v2815, i32 %cv2817) nomerge, !dbg !132
  store i32 %call2818, ptr %slot483, align 8
  %v2819 = load i32, ptr %slot483, align 8
  %cv2820 = zext i32 %v2819 to i64
  %cond2821 = icmp ne i64 %cv2820, 0
  br i1 %cond2821, label %bb_rcsuccess598, label %bb_rcfailure598
bb_rcfailure598:
  %v2822 = load i64, ptr %slot37, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %call2824 = call i32 @myl_rc_take_failure(ptr %p2823) nomerge, !dbg !132
  store i32 %call2824, ptr %slot484, align 8
  %v2825 = load i64, ptr %slot1, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  %v2827 = load i32, ptr %slot484, align 8
  %call2828 = call i32 @myl_qbe_rc_status(ptr %p2826, i32 %v2827) nomerge, !dbg !132
  store i32 %call2828, ptr %slot485, align 8
  br label %bb_failure
bb_rcsuccess598:
  %v2829 = load i64, ptr %slot9, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i32 0, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot14, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  store i32 2, ptr %p2832, align 4, !alias.scope !3, !noalias !4
  %v2833 = load i64, ptr %slot13, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  store i32 1, ptr %p2834, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared588
bb_rccopy588:
  %v2835 = load i64, ptr %slot20, align 8
  store i64 %v2835, ptr %slot486, align 8
  %v2836 = load i64, ptr %slot38, align 8
  store i64 %v2836, ptr %slot487, align 8
  %v2837 = load i64, ptr %slot37, align 8
  %v2838 = load i64, ptr %slot486, align 8
  %v2839 = load i64, ptr %slot476, align 8
  %v2840 = load i64, ptr %slot487, align 8
  %cv2841 = trunc i64 %v2840 to i32
  %call2842 = call i32 @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_retain(i64 %v2837, i64 %v2838, i64 %v2839, i32 %cv2841) nomerge, !dbg !132
  store i32 %call2842, ptr %slot488, align 8
  %v2843 = load i32, ptr %slot488, align 8
  %cv2844 = zext i32 %v2843 to i64
  %cond2845 = icmp ne i64 %cv2844, 0
  br i1 %cond2845, label %bb_rcsuccess607, label %bb_rcfailure607
bb_rcfailure607:
  %v2846 = load i64, ptr %slot37, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  %call2848 = call i32 @myl_rc_take_failure(ptr %p2847) nomerge, !dbg !132
  store i32 %call2848, ptr %slot489, align 8
  %v2849 = load i64, ptr %slot1, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %v2851 = load i32, ptr %slot489, align 8
  %call2852 = call i32 @myl_qbe_rc_status(ptr %p2850, i32 %v2851) nomerge, !dbg !132
  store i32 %call2852, ptr %slot490, align 8
  br label %bb_failure
bb_rcsuccess607:
  %v2853 = load i64, ptr %slot14, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 2, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot13, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i32 1, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot9, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %ld2859 = load i32, ptr %p2858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2859, ptr %slot491, align 8
  %v2860 = load i32, ptr %slot491, align 8
  %cv2861 = zext i32 %v2860 to i64
  %cond2862 = icmp ne i64 %cv2861, 0
  br i1 %cond2862, label %bb_rcslotdrop614, label %bb_rcslotdone614
bb_rcslotdrop614:
  %v2863 = load i64, ptr %slot9, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  store i32 0, ptr %p2864, align 4, !alias.scope !3, !noalias !4
  %v2865 = load i64, ptr %slot16, align 8
  store i64 %v2865, ptr %slot492, align 8
  %v2866 = load i64, ptr %slot10, align 8
  %p2867 = inttoptr i64 %v2866 to ptr
  %ld2868 = load i32, ptr %p2867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2868, ptr %slot493, align 8
  %v2869 = load i32, ptr %slot493, align 8
  %op2870 = and i32 %v2869, 28
  store i32 %op2870, ptr %slot494, align 8
  %v2871 = load i32, ptr %slot494, align 8
  %cv2872 = zext i32 %v2871 to i64
  %cond2873 = icmp ne i64 %cv2872, 0
  br i1 %cond2873, label %bb_rcslotrole614, label %bb_rcslotowner614
bb_rcslotrole614:
  %v2874 = load i64, ptr %slot37, align 8
  store i64 %v2874, ptr %slot495, align 8
  %v2875 = load i64, ptr %slot495, align 8
  %v2876 = load i64, ptr %slot492, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64 %v2875, i64 %v2876) nomerge, !dbg !132
  br label %bb_rcslotdone614
bb_rcslotowner614:
  %v2877 = load i64, ptr %slot37, align 8
  store i64 %v2877, ptr %slot496, align 8
  %v2878 = load i64, ptr %slot496, align 8
  %v2879 = load i64, ptr %slot492, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64 %v2878, i64 %v2879) nomerge, !dbg !132
  br label %bb_rcslotdone614
bb_rcslotdone614:
  br label %bb_rcprepared588
bb_rcprepared588:
  %v2880 = load i64, ptr %slot20, align 8
  store i64 %v2880, ptr %slot497, align 8
  %v2881 = load i64, ptr %slot13, align 8
  %p2882 = inttoptr i64 %v2881 to ptr
  store i32 0, ptr %p2882, align 4, !alias.scope !3, !noalias !4
  %v2883 = load i64, ptr %slot9, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  %ld2885 = load i32, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2885, ptr %slot498, align 8
  %v2886 = load i32, ptr %slot498, align 8
  %cv2887 = zext i32 %v2886 to i64
  %cond2888 = icmp ne i64 %cv2887, 0
  br i1 %cond2888, label %bb_rcslotdrop625, label %bb_rcslotdone625
bb_rcslotdrop625:
  %v2889 = load i64, ptr %slot9, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i32 0, ptr %p2890, align 4, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot16, align 8
  store i64 %v2891, ptr %slot499, align 8
  %v2892 = load i64, ptr %slot10, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  %ld2894 = load i32, ptr %p2893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2894, ptr %slot500, align 8
  %v2895 = load i32, ptr %slot500, align 8
  %op2896 = and i32 %v2895, 28
  store i32 %op2896, ptr %slot501, align 8
  %v2897 = load i32, ptr %slot501, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcslotrole625, label %bb_rcslotowner625
bb_rcslotrole625:
  %v2900 = load i64, ptr %slot37, align 8
  store i64 %v2900, ptr %slot502, align 8
  %v2901 = load i64, ptr %slot502, align 8
  %v2902 = load i64, ptr %slot499, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64 %v2901, i64 %v2902) nomerge, !dbg !132
  br label %bb_rcslotdone625
bb_rcslotowner625:
  %v2903 = load i64, ptr %slot37, align 8
  store i64 %v2903, ptr %slot503, align 8
  %v2904 = load i64, ptr %slot503, align 8
  %v2905 = load i64, ptr %slot499, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64 %v2904, i64 %v2905) nomerge, !dbg !132
  br label %bb_rcslotdone625
bb_rcslotdone625:
  %v2906 = load i64, ptr %slot7, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %ld2908 = load i32, ptr %p2907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2908, ptr %slot504, align 8
  %v2909 = load i32, ptr %slot504, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcslotdrop634, label %bb_rcslotdone634
bb_rcslotdrop634:
  %v2912 = load i64, ptr %slot7, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i32 0, ptr %p2913, align 4, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot24, align 8
  store i64 %v2914, ptr %slot505, align 8
  %v2915 = load i64, ptr %slot8, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %ld2917 = load i32, ptr %p2916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2917, ptr %slot506, align 8
  %v2918 = load i32, ptr %slot506, align 8
  %op2919 = and i32 %v2918, 28
  store i32 %op2919, ptr %slot507, align 8
  %v2920 = load i32, ptr %slot507, align 8
  %cv2921 = zext i32 %v2920 to i64
  %cond2922 = icmp ne i64 %cv2921, 0
  br i1 %cond2922, label %bb_rcslotrole634, label %bb_rcslotowner634
bb_rcslotrole634:
  %v2923 = load i64, ptr %slot37, align 8
  store i64 %v2923, ptr %slot508, align 8
  %v2924 = load i64, ptr %slot505, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  %ld2926 = load i64, ptr %p2925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2926, ptr %slot509, align 8
  %v2927 = load i64, ptr %slot509, align 8
  %cmp2928 = icmp ne i64 %v2927, 0
  %cv2929 = zext i1 %cmp2928 to i32
  store i32 %cv2929, ptr %slot510, align 8
  %v2930 = load i32, ptr %slot510, align 8
  %cv2931 = zext i32 %v2930 to i64
  %cond2932 = icmp ne i64 %cv2931, 0
  br i1 %cond2932, label %bb_rcgnn650, label %bb_rcgdone650
bb_rcgnn650:
  %v2933 = load i64, ptr %slot509, align 8
  %op2934 = sub i64 %v2933, 16
  store i64 %op2934, ptr %slot511, align 8
  %v2935 = load i64, ptr %slot509, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  %rgep2937 = getelementptr i8, ptr %p2936, i64 -16
  %ld2938 = load i64, ptr %rgep2937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2938, ptr %slot512, align 8
  %v2939 = load i64, ptr %slot512, align 8
  %op2940 = and i64 %v2939, 4611686018427387906
  store i64 %op2940, ptr %slot513, align 8
  %v2941 = load i64, ptr %slot513, align 8
  %cmp2942 = icmp ne i64 %v2941, 0
  %cv2943 = zext i1 %cmp2942 to i32
  store i32 %cv2943, ptr %slot514, align 8
  %v2944 = load i32, ptr %slot514, align 8
  %cv2945 = zext i32 %v2944 to i64
  %cond2946 = icmp ne i64 %cv2945, 0
  br i1 %cond2946, label %bb_rcgclear650, label %bb_rcgcounted650
bb_rcgcounted650:
  %v2947 = load i64, ptr %slot509, align 8
  %op2948 = sub i64 %v2947, 24
  store i64 %op2948, ptr %slot515, align 8
  %v2949 = load i64, ptr %slot509, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %rgep2951 = getelementptr i8, ptr %p2950, i64 -24
  %ld2952 = load i64, ptr %rgep2951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2952, ptr %slot516, align 8
  %v2953 = load i64, ptr %slot516, align 8
  %op2954 = sub i64 %v2953, 1
  store i64 %op2954, ptr %slot517, align 8
  %v2955 = load i64, ptr %slot517, align 8
  %cmp2956 = icmp eq i64 %v2955, 0
  %cv2957 = zext i1 %cmp2956 to i32
  store i32 %cv2957, ptr %slot518, align 8
  %v2958 = load i32, ptr %slot518, align 8
  %cv2959 = zext i32 %v2958 to i64
  %cond2960 = icmp ne i64 %cv2959, 0
  br i1 %cond2960, label %bb_rcglast650, label %bb_rcgdec650
bb_rcglast650:
  %v2961 = load i64, ptr %slot509, align 8
  %op2962 = sub i64 %v2961, 32
  store i64 %op2962, ptr %slot519, align 8
  %v2963 = load i64, ptr %slot509, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  %rgep2965 = getelementptr i8, ptr %p2964, i64 -32
  %ld2966 = load i64, ptr %rgep2965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2966, ptr %slot520, align 8
  %v2967 = load i64, ptr %slot520, align 8
  %cmp2968 = icmp ne i64 %v2967, 0
  %cv2969 = zext i1 %cmp2968 to i32
  store i32 %cv2969, ptr %slot521, align 8
  %v2970 = load i32, ptr %slot521, align 8
  %cv2971 = zext i32 %v2970 to i64
  %cond2972 = icmp ne i64 %cv2971, 0
  br i1 %cond2972, label %bb_rcgdec650, label %bb_rcgslow650
bb_rcgslow650:
  %v2973 = load i64, ptr %slot508, align 8
  %v2974 = load i64, ptr %slot505, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2973, i64 %v2974) nomerge, !dbg !132
  br label %bb_rcgdone650
bb_rcgdec650:
  %v2975 = load i64, ptr %slot517, align 8
  %v2976 = load i64, ptr %slot509, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %rgep2978 = getelementptr i8, ptr %p2977, i64 -24
  store i64 %v2975, ptr %rgep2978, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear650
bb_rcgclear650:
  %v2979 = load i64, ptr %slot505, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i64 0, ptr %p2980, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone650
bb_rcgdone650:
  br label %bb_rcslotdone634
bb_rcslotowner634:
  %v2981 = load i64, ptr %slot37, align 8
  store i64 %v2981, ptr %slot522, align 8
  %v2982 = load i64, ptr %slot505, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  %ld2984 = load i64, ptr %p2983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2984, ptr %slot523, align 8
  %v2985 = load i64, ptr %slot523, align 8
  %cmp2986 = icmp ne i64 %v2985, 0
  %cv2987 = zext i1 %cmp2986 to i32
  store i32 %cv2987, ptr %slot524, align 8
  %v2988 = load i32, ptr %slot524, align 8
  %cv2989 = zext i32 %v2988 to i64
  %cond2990 = icmp ne i64 %cv2989, 0
  br i1 %cond2990, label %bb_rcgnn665, label %bb_rcgdone665
bb_rcgnn665:
  %v2991 = load i64, ptr %slot523, align 8
  %op2992 = sub i64 %v2991, 16
  store i64 %op2992, ptr %slot525, align 8
  %v2993 = load i64, ptr %slot523, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %rgep2995 = getelementptr i8, ptr %p2994, i64 -16
  %ld2996 = load i64, ptr %rgep2995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2996, ptr %slot526, align 8
  %v2997 = load i64, ptr %slot526, align 8
  %op2998 = and i64 %v2997, 4611686018427387906
  store i64 %op2998, ptr %slot527, align 8
  %v2999 = load i64, ptr %slot527, align 8
  %cmp3000 = icmp ne i64 %v2999, 0
  %cv3001 = zext i1 %cmp3000 to i32
  store i32 %cv3001, ptr %slot528, align 8
  %v3002 = load i32, ptr %slot528, align 8
  %cv3003 = zext i32 %v3002 to i64
  %cond3004 = icmp ne i64 %cv3003, 0
  br i1 %cond3004, label %bb_rcgclear665, label %bb_rcgcounted665
bb_rcgcounted665:
  %v3005 = load i64, ptr %slot523, align 8
  %op3006 = sub i64 %v3005, 32
  store i64 %op3006, ptr %slot529, align 8
  %v3007 = load i64, ptr %slot523, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %rgep3009 = getelementptr i8, ptr %p3008, i64 -32
  %ld3010 = load i64, ptr %rgep3009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3010, ptr %slot530, align 8
  %v3011 = load i64, ptr %slot530, align 8
  %op3012 = sub i64 %v3011, 1
  store i64 %op3012, ptr %slot531, align 8
  %v3013 = load i64, ptr %slot531, align 8
  %cmp3014 = icmp eq i64 %v3013, 0
  %cv3015 = zext i1 %cmp3014 to i32
  store i32 %cv3015, ptr %slot532, align 8
  %v3016 = load i32, ptr %slot532, align 8
  %cv3017 = zext i32 %v3016 to i64
  %cond3018 = icmp ne i64 %cv3017, 0
  br i1 %cond3018, label %bb_rcglast665, label %bb_rcgdec665
bb_rcglast665:
  %v3019 = load i64, ptr %slot523, align 8
  %op3020 = sub i64 %v3019, 24
  store i64 %op3020, ptr %slot533, align 8
  %v3021 = load i64, ptr %slot523, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %rgep3023 = getelementptr i8, ptr %p3022, i64 -24
  %ld3024 = load i64, ptr %rgep3023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3024, ptr %slot534, align 8
  %v3025 = load i64, ptr %slot534, align 8
  %cmp3026 = icmp ne i64 %v3025, 0
  %cv3027 = zext i1 %cmp3026 to i32
  store i32 %cv3027, ptr %slot535, align 8
  %v3028 = load i32, ptr %slot535, align 8
  %cv3029 = zext i32 %v3028 to i64
  %cond3030 = icmp ne i64 %cv3029, 0
  br i1 %cond3030, label %bb_rcgdec665, label %bb_rcgslow665
bb_rcgslow665:
  %v3031 = load i64, ptr %slot522, align 8
  %v3032 = load i64, ptr %slot505, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3031, i64 %v3032) nomerge, !dbg !132
  br label %bb_rcgdone665
bb_rcgdec665:
  %v3033 = load i64, ptr %slot531, align 8
  %v3034 = load i64, ptr %slot523, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %rgep3036 = getelementptr i8, ptr %p3035, i64 -32
  store i64 %v3033, ptr %rgep3036, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear665
bb_rcgclear665:
  %v3037 = load i64, ptr %slot505, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  store i64 0, ptr %p3038, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone665
bb_rcgdone665:
  br label %bb_rcslotdone634
bb_rcslotdone634:
  %v3039 = load i64, ptr %slot5, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  %ld3041 = load i32, ptr %p3040, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3041, ptr %slot536, align 8
  %v3042 = load i32, ptr %slot536, align 8
  %cv3043 = zext i32 %v3042 to i64
  %cond3044 = icmp ne i64 %cv3043, 0
  br i1 %cond3044, label %bb_rcslotdrop671, label %bb_rcslotdone671
bb_rcslotdrop671:
  %v3045 = load i64, ptr %slot5, align 8
  %p3046 = inttoptr i64 %v3045 to ptr
  store i32 0, ptr %p3046, align 4, !alias.scope !3, !noalias !4
  %v3047 = load i64, ptr %slot23, align 8
  store i64 %v3047, ptr %slot537, align 8
  %v3048 = load i64, ptr %slot6, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i32, ptr %p3049, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3050, ptr %slot538, align 8
  %v3051 = load i32, ptr %slot538, align 8
  %op3052 = and i32 %v3051, 28
  store i32 %op3052, ptr %slot539, align 8
  %v3053 = load i32, ptr %slot539, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcslotrole671, label %bb_rcslotowner671
bb_rcslotrole671:
  %v3056 = load i64, ptr %slot37, align 8
  store i64 %v3056, ptr %slot540, align 8
  %v3057 = load i64, ptr %slot537, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %ld3059 = load i64, ptr %p3058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3059, ptr %slot541, align 8
  %v3060 = load i64, ptr %slot541, align 8
  %cmp3061 = icmp ne i64 %v3060, 0
  %cv3062 = zext i1 %cmp3061 to i32
  store i32 %cv3062, ptr %slot542, align 8
  %v3063 = load i32, ptr %slot542, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcgnn687, label %bb_rcgdone687
bb_rcgnn687:
  %v3066 = load i64, ptr %slot541, align 8
  %op3067 = sub i64 %v3066, 16
  store i64 %op3067, ptr %slot543, align 8
  %v3068 = load i64, ptr %slot541, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -16
  %ld3071 = load i64, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3071, ptr %slot544, align 8
  %v3072 = load i64, ptr %slot544, align 8
  %op3073 = and i64 %v3072, 4611686018427387906
  store i64 %op3073, ptr %slot545, align 8
  %v3074 = load i64, ptr %slot545, align 8
  %cmp3075 = icmp ne i64 %v3074, 0
  %cv3076 = zext i1 %cmp3075 to i32
  store i32 %cv3076, ptr %slot546, align 8
  %v3077 = load i32, ptr %slot546, align 8
  %cv3078 = zext i32 %v3077 to i64
  %cond3079 = icmp ne i64 %cv3078, 0
  br i1 %cond3079, label %bb_rcgclear687, label %bb_rcgcounted687
bb_rcgcounted687:
  %v3080 = load i64, ptr %slot541, align 8
  %op3081 = sub i64 %v3080, 24
  store i64 %op3081, ptr %slot547, align 8
  %v3082 = load i64, ptr %slot541, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %rgep3084 = getelementptr i8, ptr %p3083, i64 -24
  %ld3085 = load i64, ptr %rgep3084, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3085, ptr %slot548, align 8
  %v3086 = load i64, ptr %slot548, align 8
  %op3087 = sub i64 %v3086, 1
  store i64 %op3087, ptr %slot549, align 8
  %v3088 = load i64, ptr %slot549, align 8
  %cmp3089 = icmp eq i64 %v3088, 0
  %cv3090 = zext i1 %cmp3089 to i32
  store i32 %cv3090, ptr %slot550, align 8
  %v3091 = load i32, ptr %slot550, align 8
  %cv3092 = zext i32 %v3091 to i64
  %cond3093 = icmp ne i64 %cv3092, 0
  br i1 %cond3093, label %bb_rcglast687, label %bb_rcgdec687
bb_rcglast687:
  %v3094 = load i64, ptr %slot541, align 8
  %op3095 = sub i64 %v3094, 32
  store i64 %op3095, ptr %slot551, align 8
  %v3096 = load i64, ptr %slot541, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %rgep3098 = getelementptr i8, ptr %p3097, i64 -32
  %ld3099 = load i64, ptr %rgep3098, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3099, ptr %slot552, align 8
  %v3100 = load i64, ptr %slot552, align 8
  %cmp3101 = icmp ne i64 %v3100, 0
  %cv3102 = zext i1 %cmp3101 to i32
  store i32 %cv3102, ptr %slot553, align 8
  %v3103 = load i32, ptr %slot553, align 8
  %cv3104 = zext i32 %v3103 to i64
  %cond3105 = icmp ne i64 %cv3104, 0
  br i1 %cond3105, label %bb_rcgdec687, label %bb_rcgslow687
bb_rcgslow687:
  %v3106 = load i64, ptr %slot540, align 8
  %v3107 = load i64, ptr %slot537, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3106, i64 %v3107) nomerge, !dbg !132
  br label %bb_rcgdone687
bb_rcgdec687:
  %v3108 = load i64, ptr %slot549, align 8
  %v3109 = load i64, ptr %slot541, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %rgep3111 = getelementptr i8, ptr %p3110, i64 -24
  store i64 %v3108, ptr %rgep3111, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear687
bb_rcgclear687:
  %v3112 = load i64, ptr %slot537, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  store i64 0, ptr %p3113, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone687
bb_rcgdone687:
  br label %bb_rcslotdone671
bb_rcslotowner671:
  %v3114 = load i64, ptr %slot37, align 8
  store i64 %v3114, ptr %slot554, align 8
  %v3115 = load i64, ptr %slot537, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  %ld3117 = load i64, ptr %p3116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3117, ptr %slot555, align 8
  %v3118 = load i64, ptr %slot555, align 8
  %cmp3119 = icmp ne i64 %v3118, 0
  %cv3120 = zext i1 %cmp3119 to i32
  store i32 %cv3120, ptr %slot556, align 8
  %v3121 = load i32, ptr %slot556, align 8
  %cv3122 = zext i32 %v3121 to i64
  %cond3123 = icmp ne i64 %cv3122, 0
  br i1 %cond3123, label %bb_rcgnn702, label %bb_rcgdone702
bb_rcgnn702:
  %v3124 = load i64, ptr %slot555, align 8
  %op3125 = sub i64 %v3124, 16
  store i64 %op3125, ptr %slot557, align 8
  %v3126 = load i64, ptr %slot555, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %rgep3128 = getelementptr i8, ptr %p3127, i64 -16
  %ld3129 = load i64, ptr %rgep3128, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3129, ptr %slot558, align 8
  %v3130 = load i64, ptr %slot558, align 8
  %op3131 = and i64 %v3130, 4611686018427387906
  store i64 %op3131, ptr %slot559, align 8
  %v3132 = load i64, ptr %slot559, align 8
  %cmp3133 = icmp ne i64 %v3132, 0
  %cv3134 = zext i1 %cmp3133 to i32
  store i32 %cv3134, ptr %slot560, align 8
  %v3135 = load i32, ptr %slot560, align 8
  %cv3136 = zext i32 %v3135 to i64
  %cond3137 = icmp ne i64 %cv3136, 0
  br i1 %cond3137, label %bb_rcgclear702, label %bb_rcgcounted702
bb_rcgcounted702:
  %v3138 = load i64, ptr %slot555, align 8
  %op3139 = sub i64 %v3138, 32
  store i64 %op3139, ptr %slot561, align 8
  %v3140 = load i64, ptr %slot555, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  %rgep3142 = getelementptr i8, ptr %p3141, i64 -32
  %ld3143 = load i64, ptr %rgep3142, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3143, ptr %slot562, align 8
  %v3144 = load i64, ptr %slot562, align 8
  %op3145 = sub i64 %v3144, 1
  store i64 %op3145, ptr %slot563, align 8
  %v3146 = load i64, ptr %slot563, align 8
  %cmp3147 = icmp eq i64 %v3146, 0
  %cv3148 = zext i1 %cmp3147 to i32
  store i32 %cv3148, ptr %slot564, align 8
  %v3149 = load i32, ptr %slot564, align 8
  %cv3150 = zext i32 %v3149 to i64
  %cond3151 = icmp ne i64 %cv3150, 0
  br i1 %cond3151, label %bb_rcglast702, label %bb_rcgdec702
bb_rcglast702:
  %v3152 = load i64, ptr %slot555, align 8
  %op3153 = sub i64 %v3152, 24
  store i64 %op3153, ptr %slot565, align 8
  %v3154 = load i64, ptr %slot555, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %rgep3156 = getelementptr i8, ptr %p3155, i64 -24
  %ld3157 = load i64, ptr %rgep3156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3157, ptr %slot566, align 8
  %v3158 = load i64, ptr %slot566, align 8
  %cmp3159 = icmp ne i64 %v3158, 0
  %cv3160 = zext i1 %cmp3159 to i32
  store i32 %cv3160, ptr %slot567, align 8
  %v3161 = load i32, ptr %slot567, align 8
  %cv3162 = zext i32 %v3161 to i64
  %cond3163 = icmp ne i64 %cv3162, 0
  br i1 %cond3163, label %bb_rcgdec702, label %bb_rcgslow702
bb_rcgslow702:
  %v3164 = load i64, ptr %slot554, align 8
  %v3165 = load i64, ptr %slot537, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3164, i64 %v3165) nomerge, !dbg !132
  br label %bb_rcgdone702
bb_rcgdec702:
  %v3166 = load i64, ptr %slot563, align 8
  %v3167 = load i64, ptr %slot555, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %rgep3169 = getelementptr i8, ptr %p3168, i64 -32
  store i64 %v3166, ptr %rgep3169, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear702
bb_rcgclear702:
  %v3170 = load i64, ptr %slot537, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  store i64 0, ptr %p3171, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone702
bb_rcgdone702:
  br label %bb_rcslotdone671
bb_rcslotdone671:
  %v3172 = load i64, ptr %slot497, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %ret3174 = load { i64, i64 }, ptr %p3173, align 8
  ret { i64, i64 } %ret3174
bb_i33:
  %v3175 = load i64, ptr %slot9, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  %ld3177 = load i32, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3177, ptr %slot568, align 8
  %v3178 = load i32, ptr %slot568, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcslotdrop717, label %bb_rcslotdone717
bb_rcslotdrop717:
  %v3181 = load i64, ptr %slot9, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  store i32 0, ptr %p3182, align 4, !alias.scope !3, !noalias !4
  %v3183 = load i64, ptr %slot16, align 8
  store i64 %v3183, ptr %slot569, align 8
  %v3184 = load i64, ptr %slot10, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  %ld3186 = load i32, ptr %p3185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3186, ptr %slot570, align 8
  %v3187 = load i32, ptr %slot570, align 8
  %op3188 = and i32 %v3187, 28
  store i32 %op3188, ptr %slot571, align 8
  %v3189 = load i32, ptr %slot571, align 8
  %cv3190 = zext i32 %v3189 to i64
  %cond3191 = icmp ne i64 %cv3190, 0
  br i1 %cond3191, label %bb_rcslotrole717, label %bb_rcslotowner717
bb_rcslotrole717:
  %v3192 = load i64, ptr %slot37, align 8
  store i64 %v3192, ptr %slot572, align 8
  %v3193 = load i64, ptr %slot572, align 8
  %v3194 = load i64, ptr %slot569, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3193, i64 %v3194) nomerge, !dbg !134
  br label %bb_rcslotdone717
bb_rcslotowner717:
  %v3195 = load i64, ptr %slot37, align 8
  store i64 %v3195, ptr %slot573, align 8
  %v3196 = load i64, ptr %slot573, align 8
  %v3197 = load i64, ptr %slot569, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3196, i64 %v3197) nomerge, !dbg !134
  br label %bb_rcslotdone717
bb_rcslotdone717:
  %v3198 = load i64, ptr %slot24, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  %ld3200 = load i64, ptr %p3199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3200, ptr %slot574, align 8
  %v3201 = load i64, ptr %slot574, align 8
  %v3202 = load i64, ptr %slot26, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i64 %v3201, ptr %p3203, align 8, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot32, align 8
  store i64 %v3204, ptr %slot575, align 8
  %v3205 = load i64, ptr %slot575, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i64 0, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot575, align 8
  %p3209 = inttoptr i64 %v3207 to ptr
  %gep3210 = getelementptr i8, ptr %p3209, i64 8
  %op3208 = ptrtoint ptr %gep3210 to i64
  store i64 %op3208, ptr %slot576, align 8
  %v3211 = load i64, ptr %slot576, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  store i64 0, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  %v3213 = load i64, ptr %slot575, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i32 0, ptr %p3214, align 4, !alias.scope !3, !noalias !4
  %v3215 = load i64, ptr %slot15, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  store i32 1, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  %v3217 = load i64, ptr %slot26, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  %ld3219 = load i64, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3219, ptr %slot577, align 8
  %v3220 = load i64, ptr %slot577, align 8
  %v3221 = load i64, ptr %slot18, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 %v3220, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot18, align 8
  store i64 %v3223, ptr %slot578, align 8
  %v3224 = load i64, ptr %slot575, align 8
  %p3226 = inttoptr i64 %v3224 to ptr
  %gep3227 = getelementptr i8, ptr %p3226, i64 8
  %op3225 = ptrtoint ptr %gep3227 to i64
  store i64 %op3225, ptr %slot579, align 8
  %v3228 = load i64, ptr %slot38, align 8
  store i64 %v3228, ptr %slot580, align 8
  %v3229 = load i64, ptr %slot26, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %ld3231 = load i64, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3231, ptr %slot581, align 8
  %v3232 = load i64, ptr %slot581, align 8
  %v3233 = load i64, ptr %slot18, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  store i64 %v3232, ptr %p3234, align 8, !alias.scope !3, !noalias !4
  %v3235 = load i64, ptr %slot18, align 8
  store i64 %v3235, ptr %slot582, align 8
  %v3236 = load i64, ptr %slot9, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %ld3238 = load i32, ptr %p3237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3238, ptr %slot583, align 8
  %v3239 = load i64, ptr %slot10, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %ld3241 = load i32, ptr %p3240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3241, ptr %slot584, align 8
  %v3242 = load i32, ptr %slot584, align 8
  %op3243 = and i32 %v3242, 24
  store i32 %op3243, ptr %slot584, align 8
  %v3244 = load i32, ptr %slot584, align 8
  %cmp3245 = icmp eq i32 %v3244, 0
  %cv3246 = zext i1 %cmp3245 to i32
  store i32 %cv3246, ptr %slot585, align 8
  %v3247 = load i32, ptr %slot583, align 8
  %v3248 = load i32, ptr %slot585, align 8
  %op3249 = and i32 %v3247, %v3248
  store i32 %op3249, ptr %slot586, align 8
  %v3250 = load i32, ptr %slot586, align 8
  %cv3251 = zext i32 %v3250 to i64
  %cond3252 = icmp ne i64 %cv3251, 0
  br i1 %cond3252, label %bb_rctake735, label %bb_rccopy735
bb_rctake735:
  %v3253 = load i64, ptr %slot20, align 8
  store i64 %v3253, ptr %slot587, align 8
  %v3254 = load i64, ptr %slot38, align 8
  store i64 %v3254, ptr %slot588, align 8
  %v3255 = load i64, ptr %slot582, align 8
  %v3256 = load i64, ptr %slot587, align 8
  %op3257 = sub i64 %v3255, %v3256
  store i64 %op3257, ptr %slot589, align 8
  %v3258 = load i64, ptr %slot587, align 8
  %v3259 = load i64, ptr %slot582, align 8
  %op3260 = sub i64 %v3258, %v3259
  store i64 %op3260, ptr %slot590, align 8
  %v3261 = load i64, ptr %slot589, align 8
  %cmp3262 = icmp ult i64 %v3261, 8
  %cv3263 = zext i1 %cmp3262 to i32
  store i32 %cv3263, ptr %slot591, align 8
  %v3264 = load i64, ptr %slot590, align 8
  %cmp3265 = icmp ult i64 %v3264, 8
  %cv3266 = zext i1 %cmp3265 to i32
  store i32 %cv3266, ptr %slot592, align 8
  %v3267 = load i32, ptr %slot591, align 8
  %v3268 = load i32, ptr %slot592, align 8
  %op3269 = or i32 %v3267, %v3268
  store i32 %op3269, ptr %slot593, align 8
  %v3270 = load i32, ptr %slot593, align 8
  %cv3271 = zext i32 %v3270 to i64
  %cond3272 = icmp ne i64 %cv3271, 0
  br i1 %cond3272, label %bb_rcmoveslow744, label %bb_rcmovecheck744
bb_rcmovecheck744:
  %v3273 = load i64, ptr %slot582, align 8
  %p3275 = inttoptr i64 %v3273 to ptr
  %gep3276 = getelementptr i8, ptr %p3275, i64 0
  %op3274 = ptrtoint ptr %gep3276 to i64
  store i64 %op3274, ptr %slot594, align 8
  %v3277 = load i64, ptr %slot594, align 8
  %p3278 = inttoptr i64 %v3277 to ptr
  %ld3279 = load i64, ptr %p3278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3279, ptr %slot595, align 8
  %v3280 = load i64, ptr %slot595, align 8
  %cmp3281 = icmp ne i64 %v3280, 0
  %cv3282 = zext i1 %cmp3281 to i32
  store i32 %cv3282, ptr %slot596, align 8
  %v3283 = load i32, ptr %slot596, align 8
  %cv3284 = zext i32 %v3283 to i64
  %cond3285 = icmp ne i64 %cv3284, 0
  br i1 %cond3285, label %bb_rcmoveheader752, label %bb_rcmovenext752
bb_rcmoveheader752:
  %v3286 = load i64, ptr %slot595, align 8
  %op3287 = sub i64 %v3286, 16
  store i64 %op3287, ptr %slot597, align 8
  %v3288 = load i64, ptr %slot595, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  %rgep3290 = getelementptr i8, ptr %p3289, i64 -16
  %ld3291 = load i64, ptr %rgep3290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3291, ptr %slot598, align 8
  %v3292 = load i64, ptr %slot598, align 8
  %op3293 = and i64 %v3292, 5764607523034234881
  store i64 %op3293, ptr %slot599, align 8
  %v3294 = load i64, ptr %slot599, align 8
  %cmp3295 = icmp ne i64 %v3294, 0
  %cv3296 = zext i1 %cmp3295 to i32
  store i32 %cv3296, ptr %slot600, align 8
  %v3297 = load i32, ptr %slot600, align 8
  %cv3298 = zext i32 %v3297 to i64
  %cond3299 = icmp ne i64 %cv3298, 0
  br i1 %cond3299, label %bb_rcmoveslow744, label %bb_rcmovenext752
bb_rcmovenext752:
  %v3300 = load i64, ptr %slot582, align 8
  %v3301 = load i64, ptr %slot587, align 8
  %p3302 = inttoptr i64 %v3300 to ptr
  %p3303 = inttoptr i64 %v3301 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3303, ptr %p3302, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3304 = load i64, ptr %slot582, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  store i64 0, ptr %p3305, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved744
bb_rcmoveslow744:
  %v3306 = load i64, ptr %slot37, align 8
  %v3307 = load i64, ptr %slot587, align 8
  %v3308 = load i64, ptr %slot582, align 8
  %v3309 = load i64, ptr %slot588, align 8
  %cv3310 = trunc i64 %v3309 to i32
  %call3311 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3306, i64 %v3307, i64 %v3308, i32 %cv3310) nomerge, !dbg !136
  store i32 %call3311, ptr %slot601, align 8
  %v3312 = load i32, ptr %slot601, align 8
  %cv3313 = zext i32 %v3312 to i64
  %cond3314 = icmp ne i64 %cv3313, 0
  br i1 %cond3314, label %bb_rcsuccess759, label %bb_rcfailure759
bb_rcfailure759:
  %v3315 = load i64, ptr %slot37, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  %call3317 = call i32 @myl_rc_take_failure(ptr %p3316) nomerge, !dbg !136
  store i32 %call3317, ptr %slot602, align 8
  %v3318 = load i64, ptr %slot1, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  %v3320 = load i32, ptr %slot602, align 8
  %call3321 = call i32 @myl_qbe_rc_status(ptr %p3319, i32 %v3320) nomerge, !dbg !136
  store i32 %call3321, ptr %slot603, align 8
  br label %bb_failure
bb_rcsuccess759:
  br label %bb_rcmoved744
bb_rcmoved744:
  %v3322 = load i64, ptr %slot9, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i32 0, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot14, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  store i32 2, ptr %p3325, align 4, !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot13, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  store i32 1, ptr %p3327, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared735
bb_rccopy735:
  %v3328 = load i64, ptr %slot20, align 8
  store i64 %v3328, ptr %slot604, align 8
  %v3329 = load i64, ptr %slot38, align 8
  store i64 %v3329, ptr %slot605, align 8
  %v3330 = load i64, ptr %slot582, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %ld3332 = load i64, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3332, ptr %slot606, align 8
  %v3333 = load i64, ptr %slot606, align 8
  %cmp3334 = icmp ne i64 %v3333, 0
  %cv3335 = zext i1 %cmp3334 to i32
  store i32 %cv3335, ptr %slot607, align 8
  %v3336 = load i32, ptr %slot607, align 8
  %cv3337 = zext i32 %v3336 to i64
  %cond3338 = icmp ne i64 %cv3337, 0
  br i1 %cond3338, label %bb_rcgnn768, label %bb_rcgplain768
bb_rcgnn768:
  %v3339 = load i64, ptr %slot606, align 8
  %op3340 = sub i64 %v3339, 16
  store i64 %op3340, ptr %slot608, align 8
  %v3341 = load i64, ptr %slot606, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %rgep3343 = getelementptr i8, ptr %p3342, i64 -16
  %ld3344 = load i64, ptr %rgep3343, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3344, ptr %slot609, align 8
  %v3345 = load i64, ptr %slot609, align 8
  %op3346 = and i64 %v3345, 4611686018427387906
  store i64 %op3346, ptr %slot610, align 8
  %v3347 = load i64, ptr %slot610, align 8
  %cmp3348 = icmp ne i64 %v3347, 0
  %cv3349 = zext i1 %cmp3348 to i32
  store i32 %cv3349, ptr %slot611, align 8
  %v3350 = load i32, ptr %slot611, align 8
  %cv3351 = zext i32 %v3350 to i64
  %cond3352 = icmp ne i64 %cv3351, 0
  br i1 %cond3352, label %bb_rcgspecial768, label %bb_rcginc768
bb_rcginc768:
  %v3353 = load i64, ptr %slot606, align 8
  %op3354 = sub i64 %v3353, 32
  store i64 %op3354, ptr %slot612, align 8
  %v3355 = load i64, ptr %slot606, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %rgep3357 = getelementptr i8, ptr %p3356, i64 -32
  %ld3358 = load i64, ptr %rgep3357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3358, ptr %slot613, align 8
  %v3359 = load i64, ptr %slot613, align 8
  %op3360 = add i64 %v3359, 1
  store i64 %op3360, ptr %slot614, align 8
  %v3361 = load i64, ptr %slot614, align 8
  %cmp3362 = icmp eq i64 %v3361, 0
  %cv3363 = zext i1 %cmp3362 to i32
  store i32 %cv3363, ptr %slot615, align 8
  %v3364 = load i32, ptr %slot615, align 8
  %cv3365 = zext i32 %v3364 to i64
  %cond3366 = icmp ne i64 %cv3365, 0
  br i1 %cond3366, label %bb_rcglimit768, label %bb_rcgcapacity768
bb_rcglimit768:
  %v3367 = load i64, ptr %slot1, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  %call3369 = call i32 @myl_qbe_rc_status(ptr %p3368, i32 2) nomerge, !dbg !136
  store i32 %call3369, ptr %slot616, align 8
  br label %bb_failure
bb_rcgcapacity768:
  %v3370 = load i64, ptr %slot614, align 8
  %v3371 = load i64, ptr %slot606, align 8
  %p3372 = inttoptr i64 %v3371 to ptr
  %rgep3373 = getelementptr i8, ptr %p3372, i64 -32
  store i64 %v3370, ptr %rgep3373, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain768
bb_rcgspecial768:
  %v3374 = load i64, ptr %slot609, align 8
  %op3375 = and i64 %v3374, 4611686018427387904
  store i64 %op3375, ptr %slot617, align 8
  %v3376 = load i64, ptr %slot617, align 8
  %cmp3377 = icmp ne i64 %v3376, 0
  %cv3378 = zext i1 %cmp3377 to i32
  store i32 %cv3378, ptr %slot618, align 8
  %v3379 = load i32, ptr %slot618, align 8
  %cv3380 = zext i32 %v3379 to i64
  %cond3381 = icmp ne i64 %cv3380, 0
  br i1 %cond3381, label %bb_rcgslow768, label %bb_rcgplain768
bb_rcgslow768:
  %v3382 = load i64, ptr %slot37, align 8
  %v3383 = load i64, ptr %slot604, align 8
  %v3384 = load i64, ptr %slot582, align 8
  %v3385 = load i64, ptr %slot605, align 8
  %cv3386 = trunc i64 %v3385 to i32
  %call3387 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v3382, i64 %v3383, i64 %v3384, i32 %cv3386) nomerge, !dbg !136
  store i32 %call3387, ptr %slot619, align 8
  %v3388 = load i32, ptr %slot619, align 8
  %cv3389 = zext i32 %v3388 to i64
  %cond3390 = icmp ne i64 %cv3389, 0
  br i1 %cond3390, label %bb_rcsuccess782, label %bb_rcfailure782
bb_rcfailure782:
  %v3391 = load i64, ptr %slot37, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  %call3393 = call i32 @myl_rc_take_failure(ptr %p3392) nomerge, !dbg !136
  store i32 %call3393, ptr %slot620, align 8
  %v3394 = load i64, ptr %slot1, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  %v3396 = load i32, ptr %slot620, align 8
  %call3397 = call i32 @myl_qbe_rc_status(ptr %p3395, i32 %v3396) nomerge, !dbg !136
  store i32 %call3397, ptr %slot621, align 8
  br label %bb_failure
bb_rcsuccess782:
  br label %bb_rcgdone768
bb_rcgplain768:
  %v3398 = load i64, ptr %slot606, align 8
  %v3399 = load i64, ptr %slot604, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i64 %v3398, ptr %p3400, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone768
bb_rcgdone768:
  %v3401 = load i64, ptr %slot14, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  store i32 2, ptr %p3402, align 4, !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot13, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i32 1, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot9, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %ld3407 = load i32, ptr %p3406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3407, ptr %slot622, align 8
  %v3408 = load i32, ptr %slot622, align 8
  %cv3409 = zext i32 %v3408 to i64
  %cond3410 = icmp ne i64 %cv3409, 0
  br i1 %cond3410, label %bb_rcslotdrop789, label %bb_rcslotdone789
bb_rcslotdrop789:
  %v3411 = load i64, ptr %slot9, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  store i32 0, ptr %p3412, align 4, !alias.scope !3, !noalias !4
  %v3413 = load i64, ptr %slot16, align 8
  store i64 %v3413, ptr %slot623, align 8
  %v3414 = load i64, ptr %slot10, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %ld3416 = load i32, ptr %p3415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3416, ptr %slot624, align 8
  %v3417 = load i32, ptr %slot624, align 8
  %op3418 = and i32 %v3417, 28
  store i32 %op3418, ptr %slot625, align 8
  %v3419 = load i32, ptr %slot625, align 8
  %cv3420 = zext i32 %v3419 to i64
  %cond3421 = icmp ne i64 %cv3420, 0
  br i1 %cond3421, label %bb_rcslotrole789, label %bb_rcslotowner789
bb_rcslotrole789:
  %v3422 = load i64, ptr %slot37, align 8
  store i64 %v3422, ptr %slot626, align 8
  %v3423 = load i64, ptr %slot623, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  %ld3425 = load i64, ptr %p3424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3425, ptr %slot627, align 8
  %v3426 = load i64, ptr %slot627, align 8
  %cmp3427 = icmp ne i64 %v3426, 0
  %cv3428 = zext i1 %cmp3427 to i32
  store i32 %cv3428, ptr %slot628, align 8
  %v3429 = load i32, ptr %slot628, align 8
  %cv3430 = zext i32 %v3429 to i64
  %cond3431 = icmp ne i64 %cv3430, 0
  br i1 %cond3431, label %bb_rcgnn805, label %bb_rcgdone805
bb_rcgnn805:
  %v3432 = load i64, ptr %slot627, align 8
  %op3433 = sub i64 %v3432, 16
  store i64 %op3433, ptr %slot629, align 8
  %v3434 = load i64, ptr %slot627, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %rgep3436 = getelementptr i8, ptr %p3435, i64 -16
  %ld3437 = load i64, ptr %rgep3436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3437, ptr %slot630, align 8
  %v3438 = load i64, ptr %slot630, align 8
  %op3439 = and i64 %v3438, 4611686018427387906
  store i64 %op3439, ptr %slot631, align 8
  %v3440 = load i64, ptr %slot631, align 8
  %cmp3441 = icmp ne i64 %v3440, 0
  %cv3442 = zext i1 %cmp3441 to i32
  store i32 %cv3442, ptr %slot632, align 8
  %v3443 = load i32, ptr %slot632, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcgclear805, label %bb_rcgcounted805
bb_rcgcounted805:
  %v3446 = load i64, ptr %slot627, align 8
  %op3447 = sub i64 %v3446, 24
  store i64 %op3447, ptr %slot633, align 8
  %v3448 = load i64, ptr %slot627, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  %rgep3450 = getelementptr i8, ptr %p3449, i64 -24
  %ld3451 = load i64, ptr %rgep3450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3451, ptr %slot634, align 8
  %v3452 = load i64, ptr %slot634, align 8
  %op3453 = sub i64 %v3452, 1
  store i64 %op3453, ptr %slot635, align 8
  %v3454 = load i64, ptr %slot635, align 8
  %cmp3455 = icmp eq i64 %v3454, 0
  %cv3456 = zext i1 %cmp3455 to i32
  store i32 %cv3456, ptr %slot636, align 8
  %v3457 = load i32, ptr %slot636, align 8
  %cv3458 = zext i32 %v3457 to i64
  %cond3459 = icmp ne i64 %cv3458, 0
  br i1 %cond3459, label %bb_rcglast805, label %bb_rcgdec805
bb_rcglast805:
  %v3460 = load i64, ptr %slot627, align 8
  %op3461 = sub i64 %v3460, 32
  store i64 %op3461, ptr %slot637, align 8
  %v3462 = load i64, ptr %slot627, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %rgep3464 = getelementptr i8, ptr %p3463, i64 -32
  %ld3465 = load i64, ptr %rgep3464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3465, ptr %slot638, align 8
  %v3466 = load i64, ptr %slot638, align 8
  %cmp3467 = icmp ne i64 %v3466, 0
  %cv3468 = zext i1 %cmp3467 to i32
  store i32 %cv3468, ptr %slot639, align 8
  %v3469 = load i32, ptr %slot639, align 8
  %cv3470 = zext i32 %v3469 to i64
  %cond3471 = icmp ne i64 %cv3470, 0
  br i1 %cond3471, label %bb_rcgdec805, label %bb_rcgslow805
bb_rcgslow805:
  %v3472 = load i64, ptr %slot626, align 8
  %v3473 = load i64, ptr %slot623, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3472, i64 %v3473) nomerge, !dbg !136
  br label %bb_rcgdone805
bb_rcgdec805:
  %v3474 = load i64, ptr %slot635, align 8
  %v3475 = load i64, ptr %slot627, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %rgep3477 = getelementptr i8, ptr %p3476, i64 -24
  store i64 %v3474, ptr %rgep3477, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear805
bb_rcgclear805:
  %v3478 = load i64, ptr %slot623, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i64 0, ptr %p3479, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone805
bb_rcgdone805:
  br label %bb_rcslotdone789
bb_rcslotowner789:
  %v3480 = load i64, ptr %slot37, align 8
  store i64 %v3480, ptr %slot640, align 8
  %v3481 = load i64, ptr %slot623, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i64, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3483, ptr %slot641, align 8
  %v3484 = load i64, ptr %slot641, align 8
  %cmp3485 = icmp ne i64 %v3484, 0
  %cv3486 = zext i1 %cmp3485 to i32
  store i32 %cv3486, ptr %slot642, align 8
  %v3487 = load i32, ptr %slot642, align 8
  %cv3488 = zext i32 %v3487 to i64
  %cond3489 = icmp ne i64 %cv3488, 0
  br i1 %cond3489, label %bb_rcgnn820, label %bb_rcgdone820
bb_rcgnn820:
  %v3490 = load i64, ptr %slot641, align 8
  %op3491 = sub i64 %v3490, 16
  store i64 %op3491, ptr %slot643, align 8
  %v3492 = load i64, ptr %slot641, align 8
  %p3493 = inttoptr i64 %v3492 to ptr
  %rgep3494 = getelementptr i8, ptr %p3493, i64 -16
  %ld3495 = load i64, ptr %rgep3494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3495, ptr %slot644, align 8
  %v3496 = load i64, ptr %slot644, align 8
  %op3497 = and i64 %v3496, 4611686018427387906
  store i64 %op3497, ptr %slot645, align 8
  %v3498 = load i64, ptr %slot645, align 8
  %cmp3499 = icmp ne i64 %v3498, 0
  %cv3500 = zext i1 %cmp3499 to i32
  store i32 %cv3500, ptr %slot646, align 8
  %v3501 = load i32, ptr %slot646, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcgclear820, label %bb_rcgcounted820
bb_rcgcounted820:
  %v3504 = load i64, ptr %slot641, align 8
  %op3505 = sub i64 %v3504, 32
  store i64 %op3505, ptr %slot647, align 8
  %v3506 = load i64, ptr %slot641, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  %rgep3508 = getelementptr i8, ptr %p3507, i64 -32
  %ld3509 = load i64, ptr %rgep3508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3509, ptr %slot648, align 8
  %v3510 = load i64, ptr %slot648, align 8
  %op3511 = sub i64 %v3510, 1
  store i64 %op3511, ptr %slot649, align 8
  %v3512 = load i64, ptr %slot649, align 8
  %cmp3513 = icmp eq i64 %v3512, 0
  %cv3514 = zext i1 %cmp3513 to i32
  store i32 %cv3514, ptr %slot650, align 8
  %v3515 = load i32, ptr %slot650, align 8
  %cv3516 = zext i32 %v3515 to i64
  %cond3517 = icmp ne i64 %cv3516, 0
  br i1 %cond3517, label %bb_rcglast820, label %bb_rcgdec820
bb_rcglast820:
  %v3518 = load i64, ptr %slot641, align 8
  %op3519 = sub i64 %v3518, 24
  store i64 %op3519, ptr %slot651, align 8
  %v3520 = load i64, ptr %slot641, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  %rgep3522 = getelementptr i8, ptr %p3521, i64 -24
  %ld3523 = load i64, ptr %rgep3522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3523, ptr %slot652, align 8
  %v3524 = load i64, ptr %slot652, align 8
  %cmp3525 = icmp ne i64 %v3524, 0
  %cv3526 = zext i1 %cmp3525 to i32
  store i32 %cv3526, ptr %slot653, align 8
  %v3527 = load i32, ptr %slot653, align 8
  %cv3528 = zext i32 %v3527 to i64
  %cond3529 = icmp ne i64 %cv3528, 0
  br i1 %cond3529, label %bb_rcgdec820, label %bb_rcgslow820
bb_rcgslow820:
  %v3530 = load i64, ptr %slot640, align 8
  %v3531 = load i64, ptr %slot623, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3530, i64 %v3531) nomerge, !dbg !136
  br label %bb_rcgdone820
bb_rcgdec820:
  %v3532 = load i64, ptr %slot649, align 8
  %v3533 = load i64, ptr %slot641, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %rgep3535 = getelementptr i8, ptr %p3534, i64 -32
  store i64 %v3532, ptr %rgep3535, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear820
bb_rcgclear820:
  %v3536 = load i64, ptr %slot623, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  store i64 0, ptr %p3537, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone820
bb_rcgdone820:
  br label %bb_rcslotdone789
bb_rcslotdone789:
  br label %bb_rcprepared735
bb_rcprepared735:
  %v3538 = load i64, ptr %slot20, align 8
  store i64 %v3538, ptr %slot654, align 8
  %v3539 = load i64, ptr %slot654, align 8
  %v3540 = load i64, ptr %slot579, align 8
  %p3541 = inttoptr i64 %v3539 to ptr
  %p3542 = inttoptr i64 %v3540 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3542, ptr %p3541, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3543 = load i64, ptr %slot13, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  store i32 0, ptr %p3544, align 4, !alias.scope !3, !noalias !4
  %v3545 = load i64, ptr %slot575, align 8
  %v3546 = load i64, ptr %slot26, align 8
  %p3547 = inttoptr i64 %v3546 to ptr
  store i64 %v3545, ptr %p3547, align 8, !alias.scope !3, !noalias !4
  %v3548 = load i64, ptr %slot26, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  %ld3550 = load i64, ptr %p3549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3550, ptr %slot655, align 8
  %v3551 = load i64, ptr %slot16, align 8
  store i64 %v3551, ptr %slot656, align 8
  %v3552 = load i64, ptr %slot655, align 8
  %v3553 = load i64, ptr %slot656, align 8
  %p3554 = inttoptr i64 %v3552 to ptr
  %p3555 = inttoptr i64 %v3553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3555, ptr %p3554, i64 16, i1 false)
  %v3556 = load i64, ptr %slot10, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  store i32 2, ptr %p3557, align 4, !alias.scope !3, !noalias !4
  %v3558 = load i64, ptr %slot9, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  store i32 1, ptr %p3559, align 4, !alias.scope !3, !noalias !4
  %v3560 = load i64, ptr %slot656, align 8
  %v3561 = load i64, ptr %slot26, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  store i64 %v3560, ptr %p3562, align 8, !alias.scope !3, !noalias !4
  %v3563 = load i64, ptr %slot26, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i64, ptr %p3564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3565, ptr %slot657, align 8
  %v3566 = load i64, ptr %slot26, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %ld3568 = load i64, ptr %p3567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3568, ptr %slot658, align 8
  %v3569 = load i64, ptr %slot20, align 8
  store i64 %v3569, ptr %slot659, align 8
  %v3570 = load i64, ptr %slot38, align 8
  store i64 %v3570, ptr %slot660, align 8
  %v3571 = load i64, ptr %slot37, align 8
  %v3572 = load i64, ptr %slot659, align 8
  %v3573 = load i64, ptr %slot658, align 8
  %v3574 = load i64, ptr %slot660, align 8
  %cv3575 = trunc i64 %v3574 to i32
  %call3576 = call i32 @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_take(i64 %v3571, i64 %v3572, i64 %v3573, i32 %cv3575) nomerge, !dbg !138
  store i32 %call3576, ptr %slot661, align 8
  %v3577 = load i32, ptr %slot661, align 8
  %cv3578 = zext i32 %v3577 to i64
  %cond3579 = icmp ne i64 %cv3578, 0
  br i1 %cond3579, label %bb_rcsuccess835, label %bb_rcfailure835
bb_rcfailure835:
  %v3580 = load i64, ptr %slot37, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  %call3582 = call i32 @myl_rc_take_failure(ptr %p3581) nomerge, !dbg !138
  store i32 %call3582, ptr %slot662, align 8
  %v3583 = load i64, ptr %slot1, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  %v3585 = load i32, ptr %slot662, align 8
  %call3586 = call i32 @myl_qbe_rc_status(ptr %p3584, i32 %v3585) nomerge, !dbg !138
  store i32 %call3586, ptr %slot663, align 8
  br label %bb_failure
bb_rcsuccess835:
  %v3587 = load i64, ptr %slot9, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i32 0, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  %v3589 = load i64, ptr %slot14, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i32 2, ptr %p3590, align 4, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot13, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  store i32 1, ptr %p3592, align 4, !alias.scope !3, !noalias !4
  %v3593 = load i64, ptr %slot20, align 8
  store i64 %v3593, ptr %slot664, align 8
  %v3594 = load i64, ptr %slot13, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  store i32 0, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  %v3596 = load i64, ptr %slot9, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  %ld3598 = load i32, ptr %p3597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3598, ptr %slot665, align 8
  %v3599 = load i32, ptr %slot665, align 8
  %cv3600 = zext i32 %v3599 to i64
  %cond3601 = icmp ne i64 %cv3600, 0
  br i1 %cond3601, label %bb_rcslotdrop845, label %bb_rcslotdone845
bb_rcslotdrop845:
  %v3602 = load i64, ptr %slot9, align 8
  %p3603 = inttoptr i64 %v3602 to ptr
  store i32 0, ptr %p3603, align 4, !alias.scope !3, !noalias !4
  %v3604 = load i64, ptr %slot16, align 8
  store i64 %v3604, ptr %slot666, align 8
  %v3605 = load i64, ptr %slot10, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  %ld3607 = load i32, ptr %p3606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3607, ptr %slot667, align 8
  %v3608 = load i32, ptr %slot667, align 8
  %op3609 = and i32 %v3608, 28
  store i32 %op3609, ptr %slot668, align 8
  %v3610 = load i32, ptr %slot668, align 8
  %cv3611 = zext i32 %v3610 to i64
  %cond3612 = icmp ne i64 %cv3611, 0
  br i1 %cond3612, label %bb_rcslotrole845, label %bb_rcslotowner845
bb_rcslotrole845:
  %v3613 = load i64, ptr %slot37, align 8
  store i64 %v3613, ptr %slot669, align 8
  %v3614 = load i64, ptr %slot669, align 8
  %v3615 = load i64, ptr %slot666, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64 %v3614, i64 %v3615) nomerge, !dbg !138
  br label %bb_rcslotdone845
bb_rcslotowner845:
  %v3616 = load i64, ptr %slot37, align 8
  store i64 %v3616, ptr %slot670, align 8
  %v3617 = load i64, ptr %slot670, align 8
  %v3618 = load i64, ptr %slot666, align 8
  call void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64 %v3617, i64 %v3618) nomerge, !dbg !138
  br label %bb_rcslotdone845
bb_rcslotdone845:
  %v3619 = load i64, ptr %slot7, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  %ld3621 = load i32, ptr %p3620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3621, ptr %slot671, align 8
  %v3622 = load i32, ptr %slot671, align 8
  %cv3623 = zext i32 %v3622 to i64
  %cond3624 = icmp ne i64 %cv3623, 0
  br i1 %cond3624, label %bb_rcslotdrop854, label %bb_rcslotdone854
bb_rcslotdrop854:
  %v3625 = load i64, ptr %slot7, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i32 0, ptr %p3626, align 4, !alias.scope !3, !noalias !4
  %v3627 = load i64, ptr %slot24, align 8
  store i64 %v3627, ptr %slot672, align 8
  %v3628 = load i64, ptr %slot8, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  %ld3630 = load i32, ptr %p3629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3630, ptr %slot673, align 8
  %v3631 = load i32, ptr %slot673, align 8
  %op3632 = and i32 %v3631, 28
  store i32 %op3632, ptr %slot674, align 8
  %v3633 = load i32, ptr %slot674, align 8
  %cv3634 = zext i32 %v3633 to i64
  %cond3635 = icmp ne i64 %cv3634, 0
  br i1 %cond3635, label %bb_rcslotrole854, label %bb_rcslotowner854
bb_rcslotrole854:
  %v3636 = load i64, ptr %slot37, align 8
  store i64 %v3636, ptr %slot675, align 8
  %v3637 = load i64, ptr %slot672, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  %ld3639 = load i64, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3639, ptr %slot676, align 8
  %v3640 = load i64, ptr %slot676, align 8
  %cmp3641 = icmp ne i64 %v3640, 0
  %cv3642 = zext i1 %cmp3641 to i32
  store i32 %cv3642, ptr %slot677, align 8
  %v3643 = load i32, ptr %slot677, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcgnn870, label %bb_rcgdone870
bb_rcgnn870:
  %v3646 = load i64, ptr %slot676, align 8
  %op3647 = sub i64 %v3646, 16
  store i64 %op3647, ptr %slot678, align 8
  %v3648 = load i64, ptr %slot676, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %rgep3650 = getelementptr i8, ptr %p3649, i64 -16
  %ld3651 = load i64, ptr %rgep3650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3651, ptr %slot679, align 8
  %v3652 = load i64, ptr %slot679, align 8
  %op3653 = and i64 %v3652, 4611686018427387906
  store i64 %op3653, ptr %slot680, align 8
  %v3654 = load i64, ptr %slot680, align 8
  %cmp3655 = icmp ne i64 %v3654, 0
  %cv3656 = zext i1 %cmp3655 to i32
  store i32 %cv3656, ptr %slot681, align 8
  %v3657 = load i32, ptr %slot681, align 8
  %cv3658 = zext i32 %v3657 to i64
  %cond3659 = icmp ne i64 %cv3658, 0
  br i1 %cond3659, label %bb_rcgclear870, label %bb_rcgcounted870
bb_rcgcounted870:
  %v3660 = load i64, ptr %slot676, align 8
  %op3661 = sub i64 %v3660, 24
  store i64 %op3661, ptr %slot682, align 8
  %v3662 = load i64, ptr %slot676, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %rgep3664 = getelementptr i8, ptr %p3663, i64 -24
  %ld3665 = load i64, ptr %rgep3664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3665, ptr %slot683, align 8
  %v3666 = load i64, ptr %slot683, align 8
  %op3667 = sub i64 %v3666, 1
  store i64 %op3667, ptr %slot684, align 8
  %v3668 = load i64, ptr %slot684, align 8
  %cmp3669 = icmp eq i64 %v3668, 0
  %cv3670 = zext i1 %cmp3669 to i32
  store i32 %cv3670, ptr %slot685, align 8
  %v3671 = load i32, ptr %slot685, align 8
  %cv3672 = zext i32 %v3671 to i64
  %cond3673 = icmp ne i64 %cv3672, 0
  br i1 %cond3673, label %bb_rcglast870, label %bb_rcgdec870
bb_rcglast870:
  %v3674 = load i64, ptr %slot676, align 8
  %op3675 = sub i64 %v3674, 32
  store i64 %op3675, ptr %slot686, align 8
  %v3676 = load i64, ptr %slot676, align 8
  %p3677 = inttoptr i64 %v3676 to ptr
  %rgep3678 = getelementptr i8, ptr %p3677, i64 -32
  %ld3679 = load i64, ptr %rgep3678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3679, ptr %slot687, align 8
  %v3680 = load i64, ptr %slot687, align 8
  %cmp3681 = icmp ne i64 %v3680, 0
  %cv3682 = zext i1 %cmp3681 to i32
  store i32 %cv3682, ptr %slot688, align 8
  %v3683 = load i32, ptr %slot688, align 8
  %cv3684 = zext i32 %v3683 to i64
  %cond3685 = icmp ne i64 %cv3684, 0
  br i1 %cond3685, label %bb_rcgdec870, label %bb_rcgslow870
bb_rcgslow870:
  %v3686 = load i64, ptr %slot675, align 8
  %v3687 = load i64, ptr %slot672, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3686, i64 %v3687) nomerge, !dbg !138
  br label %bb_rcgdone870
bb_rcgdec870:
  %v3688 = load i64, ptr %slot684, align 8
  %v3689 = load i64, ptr %slot676, align 8
  %p3690 = inttoptr i64 %v3689 to ptr
  %rgep3691 = getelementptr i8, ptr %p3690, i64 -24
  store i64 %v3688, ptr %rgep3691, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear870
bb_rcgclear870:
  %v3692 = load i64, ptr %slot672, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  store i64 0, ptr %p3693, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone870
bb_rcgdone870:
  br label %bb_rcslotdone854
bb_rcslotowner854:
  %v3694 = load i64, ptr %slot37, align 8
  store i64 %v3694, ptr %slot689, align 8
  %v3695 = load i64, ptr %slot672, align 8
  %p3696 = inttoptr i64 %v3695 to ptr
  %ld3697 = load i64, ptr %p3696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3697, ptr %slot690, align 8
  %v3698 = load i64, ptr %slot690, align 8
  %cmp3699 = icmp ne i64 %v3698, 0
  %cv3700 = zext i1 %cmp3699 to i32
  store i32 %cv3700, ptr %slot691, align 8
  %v3701 = load i32, ptr %slot691, align 8
  %cv3702 = zext i32 %v3701 to i64
  %cond3703 = icmp ne i64 %cv3702, 0
  br i1 %cond3703, label %bb_rcgnn885, label %bb_rcgdone885
bb_rcgnn885:
  %v3704 = load i64, ptr %slot690, align 8
  %op3705 = sub i64 %v3704, 16
  store i64 %op3705, ptr %slot692, align 8
  %v3706 = load i64, ptr %slot690, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  %rgep3708 = getelementptr i8, ptr %p3707, i64 -16
  %ld3709 = load i64, ptr %rgep3708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3709, ptr %slot693, align 8
  %v3710 = load i64, ptr %slot693, align 8
  %op3711 = and i64 %v3710, 4611686018427387906
  store i64 %op3711, ptr %slot694, align 8
  %v3712 = load i64, ptr %slot694, align 8
  %cmp3713 = icmp ne i64 %v3712, 0
  %cv3714 = zext i1 %cmp3713 to i32
  store i32 %cv3714, ptr %slot695, align 8
  %v3715 = load i32, ptr %slot695, align 8
  %cv3716 = zext i32 %v3715 to i64
  %cond3717 = icmp ne i64 %cv3716, 0
  br i1 %cond3717, label %bb_rcgclear885, label %bb_rcgcounted885
bb_rcgcounted885:
  %v3718 = load i64, ptr %slot690, align 8
  %op3719 = sub i64 %v3718, 32
  store i64 %op3719, ptr %slot696, align 8
  %v3720 = load i64, ptr %slot690, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  %rgep3722 = getelementptr i8, ptr %p3721, i64 -32
  %ld3723 = load i64, ptr %rgep3722, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3723, ptr %slot697, align 8
  %v3724 = load i64, ptr %slot697, align 8
  %op3725 = sub i64 %v3724, 1
  store i64 %op3725, ptr %slot698, align 8
  %v3726 = load i64, ptr %slot698, align 8
  %cmp3727 = icmp eq i64 %v3726, 0
  %cv3728 = zext i1 %cmp3727 to i32
  store i32 %cv3728, ptr %slot699, align 8
  %v3729 = load i32, ptr %slot699, align 8
  %cv3730 = zext i32 %v3729 to i64
  %cond3731 = icmp ne i64 %cv3730, 0
  br i1 %cond3731, label %bb_rcglast885, label %bb_rcgdec885
bb_rcglast885:
  %v3732 = load i64, ptr %slot690, align 8
  %op3733 = sub i64 %v3732, 24
  store i64 %op3733, ptr %slot700, align 8
  %v3734 = load i64, ptr %slot690, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %rgep3736 = getelementptr i8, ptr %p3735, i64 -24
  %ld3737 = load i64, ptr %rgep3736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3737, ptr %slot701, align 8
  %v3738 = load i64, ptr %slot701, align 8
  %cmp3739 = icmp ne i64 %v3738, 0
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot702, align 8
  %v3741 = load i32, ptr %slot702, align 8
  %cv3742 = zext i32 %v3741 to i64
  %cond3743 = icmp ne i64 %cv3742, 0
  br i1 %cond3743, label %bb_rcgdec885, label %bb_rcgslow885
bb_rcgslow885:
  %v3744 = load i64, ptr %slot689, align 8
  %v3745 = load i64, ptr %slot672, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3744, i64 %v3745) nomerge, !dbg !138
  br label %bb_rcgdone885
bb_rcgdec885:
  %v3746 = load i64, ptr %slot698, align 8
  %v3747 = load i64, ptr %slot690, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  %rgep3749 = getelementptr i8, ptr %p3748, i64 -32
  store i64 %v3746, ptr %rgep3749, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear885
bb_rcgclear885:
  %v3750 = load i64, ptr %slot672, align 8
  %p3751 = inttoptr i64 %v3750 to ptr
  store i64 0, ptr %p3751, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone885
bb_rcgdone885:
  br label %bb_rcslotdone854
bb_rcslotdone854:
  %v3752 = load i64, ptr %slot5, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  %ld3754 = load i32, ptr %p3753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3754, ptr %slot703, align 8
  %v3755 = load i32, ptr %slot703, align 8
  %cv3756 = zext i32 %v3755 to i64
  %cond3757 = icmp ne i64 %cv3756, 0
  br i1 %cond3757, label %bb_rcslotdrop891, label %bb_rcslotdone891
bb_rcslotdrop891:
  %v3758 = load i64, ptr %slot5, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i32 0, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot23, align 8
  store i64 %v3760, ptr %slot704, align 8
  %v3761 = load i64, ptr %slot6, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %ld3763 = load i32, ptr %p3762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3763, ptr %slot705, align 8
  %v3764 = load i32, ptr %slot705, align 8
  %op3765 = and i32 %v3764, 28
  store i32 %op3765, ptr %slot706, align 8
  %v3766 = load i32, ptr %slot706, align 8
  %cv3767 = zext i32 %v3766 to i64
  %cond3768 = icmp ne i64 %cv3767, 0
  br i1 %cond3768, label %bb_rcslotrole891, label %bb_rcslotowner891
bb_rcslotrole891:
  %v3769 = load i64, ptr %slot37, align 8
  store i64 %v3769, ptr %slot707, align 8
  %v3770 = load i64, ptr %slot704, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  %ld3772 = load i64, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3772, ptr %slot708, align 8
  %v3773 = load i64, ptr %slot708, align 8
  %cmp3774 = icmp ne i64 %v3773, 0
  %cv3775 = zext i1 %cmp3774 to i32
  store i32 %cv3775, ptr %slot709, align 8
  %v3776 = load i32, ptr %slot709, align 8
  %cv3777 = zext i32 %v3776 to i64
  %cond3778 = icmp ne i64 %cv3777, 0
  br i1 %cond3778, label %bb_rcgnn907, label %bb_rcgdone907
bb_rcgnn907:
  %v3779 = load i64, ptr %slot708, align 8
  %op3780 = sub i64 %v3779, 16
  store i64 %op3780, ptr %slot710, align 8
  %v3781 = load i64, ptr %slot708, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  %rgep3783 = getelementptr i8, ptr %p3782, i64 -16
  %ld3784 = load i64, ptr %rgep3783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3784, ptr %slot711, align 8
  %v3785 = load i64, ptr %slot711, align 8
  %op3786 = and i64 %v3785, 4611686018427387906
  store i64 %op3786, ptr %slot712, align 8
  %v3787 = load i64, ptr %slot712, align 8
  %cmp3788 = icmp ne i64 %v3787, 0
  %cv3789 = zext i1 %cmp3788 to i32
  store i32 %cv3789, ptr %slot713, align 8
  %v3790 = load i32, ptr %slot713, align 8
  %cv3791 = zext i32 %v3790 to i64
  %cond3792 = icmp ne i64 %cv3791, 0
  br i1 %cond3792, label %bb_rcgclear907, label %bb_rcgcounted907
bb_rcgcounted907:
  %v3793 = load i64, ptr %slot708, align 8
  %op3794 = sub i64 %v3793, 24
  store i64 %op3794, ptr %slot714, align 8
  %v3795 = load i64, ptr %slot708, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %rgep3797 = getelementptr i8, ptr %p3796, i64 -24
  %ld3798 = load i64, ptr %rgep3797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3798, ptr %slot715, align 8
  %v3799 = load i64, ptr %slot715, align 8
  %op3800 = sub i64 %v3799, 1
  store i64 %op3800, ptr %slot716, align 8
  %v3801 = load i64, ptr %slot716, align 8
  %cmp3802 = icmp eq i64 %v3801, 0
  %cv3803 = zext i1 %cmp3802 to i32
  store i32 %cv3803, ptr %slot717, align 8
  %v3804 = load i32, ptr %slot717, align 8
  %cv3805 = zext i32 %v3804 to i64
  %cond3806 = icmp ne i64 %cv3805, 0
  br i1 %cond3806, label %bb_rcglast907, label %bb_rcgdec907
bb_rcglast907:
  %v3807 = load i64, ptr %slot708, align 8
  %op3808 = sub i64 %v3807, 32
  store i64 %op3808, ptr %slot718, align 8
  %v3809 = load i64, ptr %slot708, align 8
  %p3810 = inttoptr i64 %v3809 to ptr
  %rgep3811 = getelementptr i8, ptr %p3810, i64 -32
  %ld3812 = load i64, ptr %rgep3811, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3812, ptr %slot719, align 8
  %v3813 = load i64, ptr %slot719, align 8
  %cmp3814 = icmp ne i64 %v3813, 0
  %cv3815 = zext i1 %cmp3814 to i32
  store i32 %cv3815, ptr %slot720, align 8
  %v3816 = load i32, ptr %slot720, align 8
  %cv3817 = zext i32 %v3816 to i64
  %cond3818 = icmp ne i64 %cv3817, 0
  br i1 %cond3818, label %bb_rcgdec907, label %bb_rcgslow907
bb_rcgslow907:
  %v3819 = load i64, ptr %slot707, align 8
  %v3820 = load i64, ptr %slot704, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3819, i64 %v3820) nomerge, !dbg !138
  br label %bb_rcgdone907
bb_rcgdec907:
  %v3821 = load i64, ptr %slot716, align 8
  %v3822 = load i64, ptr %slot708, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %rgep3824 = getelementptr i8, ptr %p3823, i64 -24
  store i64 %v3821, ptr %rgep3824, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear907
bb_rcgclear907:
  %v3825 = load i64, ptr %slot704, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i64 0, ptr %p3826, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone907
bb_rcgdone907:
  br label %bb_rcslotdone891
bb_rcslotowner891:
  %v3827 = load i64, ptr %slot37, align 8
  store i64 %v3827, ptr %slot721, align 8
  %v3828 = load i64, ptr %slot704, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  %ld3830 = load i64, ptr %p3829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3830, ptr %slot722, align 8
  %v3831 = load i64, ptr %slot722, align 8
  %cmp3832 = icmp ne i64 %v3831, 0
  %cv3833 = zext i1 %cmp3832 to i32
  store i32 %cv3833, ptr %slot723, align 8
  %v3834 = load i32, ptr %slot723, align 8
  %cv3835 = zext i32 %v3834 to i64
  %cond3836 = icmp ne i64 %cv3835, 0
  br i1 %cond3836, label %bb_rcgnn922, label %bb_rcgdone922
bb_rcgnn922:
  %v3837 = load i64, ptr %slot722, align 8
  %op3838 = sub i64 %v3837, 16
  store i64 %op3838, ptr %slot724, align 8
  %v3839 = load i64, ptr %slot722, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  %rgep3841 = getelementptr i8, ptr %p3840, i64 -16
  %ld3842 = load i64, ptr %rgep3841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3842, ptr %slot725, align 8
  %v3843 = load i64, ptr %slot725, align 8
  %op3844 = and i64 %v3843, 4611686018427387906
  store i64 %op3844, ptr %slot726, align 8
  %v3845 = load i64, ptr %slot726, align 8
  %cmp3846 = icmp ne i64 %v3845, 0
  %cv3847 = zext i1 %cmp3846 to i32
  store i32 %cv3847, ptr %slot727, align 8
  %v3848 = load i32, ptr %slot727, align 8
  %cv3849 = zext i32 %v3848 to i64
  %cond3850 = icmp ne i64 %cv3849, 0
  br i1 %cond3850, label %bb_rcgclear922, label %bb_rcgcounted922
bb_rcgcounted922:
  %v3851 = load i64, ptr %slot722, align 8
  %op3852 = sub i64 %v3851, 32
  store i64 %op3852, ptr %slot728, align 8
  %v3853 = load i64, ptr %slot722, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  %rgep3855 = getelementptr i8, ptr %p3854, i64 -32
  %ld3856 = load i64, ptr %rgep3855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3856, ptr %slot729, align 8
  %v3857 = load i64, ptr %slot729, align 8
  %op3858 = sub i64 %v3857, 1
  store i64 %op3858, ptr %slot730, align 8
  %v3859 = load i64, ptr %slot730, align 8
  %cmp3860 = icmp eq i64 %v3859, 0
  %cv3861 = zext i1 %cmp3860 to i32
  store i32 %cv3861, ptr %slot731, align 8
  %v3862 = load i32, ptr %slot731, align 8
  %cv3863 = zext i32 %v3862 to i64
  %cond3864 = icmp ne i64 %cv3863, 0
  br i1 %cond3864, label %bb_rcglast922, label %bb_rcgdec922
bb_rcglast922:
  %v3865 = load i64, ptr %slot722, align 8
  %op3866 = sub i64 %v3865, 24
  store i64 %op3866, ptr %slot732, align 8
  %v3867 = load i64, ptr %slot722, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  %rgep3869 = getelementptr i8, ptr %p3868, i64 -24
  %ld3870 = load i64, ptr %rgep3869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3870, ptr %slot733, align 8
  %v3871 = load i64, ptr %slot733, align 8
  %cmp3872 = icmp ne i64 %v3871, 0
  %cv3873 = zext i1 %cmp3872 to i32
  store i32 %cv3873, ptr %slot734, align 8
  %v3874 = load i32, ptr %slot734, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcgdec922, label %bb_rcgslow922
bb_rcgslow922:
  %v3877 = load i64, ptr %slot721, align 8
  %v3878 = load i64, ptr %slot704, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3877, i64 %v3878) nomerge, !dbg !138
  br label %bb_rcgdone922
bb_rcgdec922:
  %v3879 = load i64, ptr %slot730, align 8
  %v3880 = load i64, ptr %slot722, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  %rgep3882 = getelementptr i8, ptr %p3881, i64 -32
  store i64 %v3879, ptr %rgep3882, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear922
bb_rcgclear922:
  %v3883 = load i64, ptr %slot704, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  store i64 0, ptr %p3884, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone922
bb_rcgdone922:
  br label %bb_rcslotdone891
bb_rcslotdone891:
  %v3885 = load i64, ptr %slot664, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  %ret3887 = load { i64, i64 }, ptr %p3886, align 8
  ret { i64, i64 } %ret3887
bb_failure:
  %v3888 = load i64, ptr %slot4, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  call void @llvm.memset.p0.i64(ptr %p3889, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !138
  %v3890 = load i64, ptr %slot4, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  %ret3892 = load { i64, i64 }, ptr %p3891, align 8
  ret { i64, i64 } %ret3892
bb_entry_failure:
  %v3893 = load i64, ptr %slot4, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  call void @llvm.memset.p0.i64(ptr %p3894, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !138
  %v3895 = load i64, ptr %slot4, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %ret3897 = load { i64, i64 }, ptr %p3896, align 8
  ret { i64, i64 } %ret3897
}

@myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425_meta = external global i8, align 8
@myl_lit_146d534849d3e93fd30ab0fa32197316072c792978757f394cddd3246cba50a7 = external global i8, align 8
@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64, i64)
declare i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64, i64, i64)
declare { i64, i64 } @myl_f_b3086250724b37e1530ea18afd53a87106fe0a2ce8bf702de675deca9c1a6925(i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_drop(i64, i64)
declare i32 @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_28983af2d8e181339f1f77fc606150f9d12e29a0123ae43d0c506c810d07685c_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425", linkageName: "myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14068570237639975477, i64 0, !"myl_f_53278abd1b9addf69c2e85da4578eb812d5250c6f8d29d916a2ae813edd1b425"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!124 = !DILocation(line: 19, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!126 = !DILocation(line: 22, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!128 = !DILocation(line: 30, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!130 = !DILocation(line: 31, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!132 = !DILocation(line: 33, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!134 = !DILocation(line: 34, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!136 = !DILocation(line: 37, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!138 = !DILocation(line: 38, column: 0, scope: !139)
