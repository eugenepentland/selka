target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775_rc_immortal(i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v6 = load i64, ptr %slot1, align 8
  %op7 = add i64 %v6, 32
  store i64 %op7, ptr %slot2, align 8
  %mem8 = alloca i8, i64 8, align 8
  %ptr9 = ptrtoint ptr %mem8 to i64
  store i64 %ptr9, ptr %slot3, align 8
  br label %bb_i0
bb_i0:
  %p10 = inttoptr i64 ptrtoint (ptr @myl_lit_53beca18892d5027da95cf5218f2ce6ed55f2f49a89a46fc2c0da5220764cdfc to i64) to ptr
  %ld11 = load i64, ptr %p10, align 8, !alias.scope !4, !noalias !3
  store i64 %ld11, ptr %slot4, align 8
  %v12 = load i64, ptr %slot4, align 8
  %v13 = load i64, ptr %slot3, align 8
  %p14 = inttoptr i64 %v13 to ptr
  store i64 %v12, ptr %p14, align 8, !alias.scope !3, !noalias !4
  %v15 = load i64, ptr %slot3, align 8
  %p16 = inttoptr i64 %v15 to ptr
  %ld17 = load i64, ptr %p16, align 8, !alias.scope !3, !noalias !4
  store i64 %ld17, ptr %slot5, align 8
  %v18 = load i64, ptr %slot5, align 8
  ret i64 %v18
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_53beca18892d5027da95cf5218f2ce6ed55f2f49a89a46fc2c0da5220764cdfc = external global i8, align 8

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775_rc_immortal", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775_rc_immortal", linkageName: "myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775_rc_immortal", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2012837861183785682, i64 0, !"myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775_rc_immortal"}
