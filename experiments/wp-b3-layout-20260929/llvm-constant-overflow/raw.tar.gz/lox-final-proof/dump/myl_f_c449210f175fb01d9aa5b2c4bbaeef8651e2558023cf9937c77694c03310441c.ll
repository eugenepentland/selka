target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v220 = load i64, ptr %slot1, align 8
  %op221 = add i64 %v220, 32
  store i64 %op221, ptr %slot3, align 8
  %mem222 = alloca i8, i64 16, align 8
  %ptr223 = ptrtoint ptr %mem222 to i64
  store i64 %ptr223, ptr %slot4, align 8
  %mem224 = alloca i8, i64 8, align 8
  %ptr225 = ptrtoint ptr %mem224 to i64
  store i64 %ptr225, ptr %slot5, align 8
  %mem226 = alloca i8, i64 8, align 8
  %ptr227 = ptrtoint ptr %mem226 to i64
  store i64 %ptr227, ptr %slot6, align 8
  %mem228 = alloca i8, i64 8, align 8
  %ptr229 = ptrtoint ptr %mem228 to i64
  store i64 %ptr229, ptr %slot7, align 8
  %mem230 = alloca i8, i64 8, align 8
  %ptr231 = ptrtoint ptr %mem230 to i64
  store i64 %ptr231, ptr %slot8, align 8
  %mem232 = alloca i8, i64 8, align 8
  %ptr233 = ptrtoint ptr %mem232 to i64
  store i64 %ptr233, ptr %slot9, align 8
  %mem234 = alloca i8, i64 16, align 8
  %ptr235 = ptrtoint ptr %mem234 to i64
  store i64 %ptr235, ptr %slot10, align 8
  %mem236 = alloca i8, i64 8, align 8
  %ptr237 = ptrtoint ptr %mem236 to i64
  store i64 %ptr237, ptr %slot11, align 8
  %mem238 = alloca i8, i64 16, align 8
  %ptr239 = ptrtoint ptr %mem238 to i64
  store i64 %ptr239, ptr %slot12, align 8
  %mem240 = alloca i8, i64 16, align 8
  %ptr241 = ptrtoint ptr %mem240 to i64
  store i64 %ptr241, ptr %slot13, align 8
  %mem242 = alloca i8, i64 8, align 8
  %ptr243 = ptrtoint ptr %mem242 to i64
  store i64 %ptr243, ptr %slot14, align 8
  %mem244 = alloca i8, i64 8, align 8
  %ptr245 = ptrtoint ptr %mem244 to i64
  store i64 %ptr245, ptr %slot15, align 8
  %mem246 = alloca i8, i64 8, align 8
  %ptr247 = ptrtoint ptr %mem246 to i64
  store i64 %ptr247, ptr %slot16, align 8
  %mem248 = alloca i8, i64 8, align 8
  %ptr249 = ptrtoint ptr %mem248 to i64
  store i64 %ptr249, ptr %slot17, align 8
  %mem250 = alloca i8, i64 8, align 8
  %ptr251 = ptrtoint ptr %mem250 to i64
  store i64 %ptr251, ptr %slot18, align 8
  %mem252 = alloca i8, i64 8, align 8
  %ptr253 = ptrtoint ptr %mem252 to i64
  store i64 %ptr253, ptr %slot19, align 8
  %mem254 = alloca i8, i64 16, align 8
  %ptr255 = ptrtoint ptr %mem254 to i64
  store i64 %ptr255, ptr %slot20, align 8
  %mem256 = alloca i8, i64 16, align 8
  %ptr257 = ptrtoint ptr %mem256 to i64
  store i64 %ptr257, ptr %slot21, align 8
  %mem258 = alloca i8, i64 16, align 8
  %ptr259 = ptrtoint ptr %mem258 to i64
  store i64 %ptr259, ptr %slot22, align 8
  %mem260 = alloca i8, i64 16, align 8
  %ptr261 = ptrtoint ptr %mem260 to i64
  store i64 %ptr261, ptr %slot23, align 8
  %mem262 = alloca i8, i64 16, align 8
  %ptr263 = ptrtoint ptr %mem262 to i64
  store i64 %ptr263, ptr %slot24, align 8
  %v264 = load i64, ptr %slot2, align 8
  %v265 = load i64, ptr %slot14, align 8
  %p266 = inttoptr i64 %v265 to ptr
  store i64 %v264, ptr %p266, align 8, !alias.scope !3, !noalias !4
  %v267 = load i64, ptr %slot1, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %call269 = call ptr @myl_qbe_heap(ptr %p268) nomerge, !dbg !110
  %calladdr270 = ptrtoint ptr %call269 to i64
  store i64 %calladdr270, ptr %slot25, align 8
  %v271 = load i64, ptr %slot1, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %call273 = call i64 @myl_qbe_region_mark(ptr %p272) nomerge, !dbg !110
  store i64 %call273, ptr %slot26, align 8
  %v274 = load i64, ptr %slot5, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i32 0, ptr %p275, align 4, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot6, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i32 0, ptr %p277, align 4, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot7, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i32 0, ptr %p279, align 4, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot8, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 0, ptr %p281, align 4, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot9, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i32 0, ptr %p283, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v284 = load i64, ptr %slot14, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot27, align 8
  %v287 = load i64, ptr %slot27, align 8
  %v288 = load i64, ptr %slot17, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 %v287, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot17, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot28, align 8
  %v293 = load i64, ptr %slot1, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %v295 = load i64, ptr %slot28, align 8
  %v296 = load i64, ptr %slot13, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %call298 = call i32 @myl_qbe_external_read(ptr %p294, i64 %v295, i32 0, ptr %p297) nomerge, !dbg !112
  store i32 %call298, ptr %slot29, align 8
  %v299 = load i64, ptr %slot13, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot30, align 8
  %v302 = load i64, ptr %slot24, align 8
  store i64 %v302, ptr %slot31, align 8
  %v303 = load i64, ptr %slot31, align 8
  %p305 = inttoptr i64 %v303 to ptr
  %gep306 = getelementptr i8, ptr %p305, i64 8
  %op304 = ptrtoint ptr %gep306 to i64
  store i64 %op304, ptr %slot32, align 8
  %v307 = load i32, ptr %slot29, align 8
  %cv308 = zext i32 %v307 to i64
  %cond309 = icmp ne i64 %cv308, 0
  br i1 %cond309, label %bb_providererror6, label %bb_providerok6
bb_providererror6:
  %p310 = inttoptr i64 ptrtoint (ptr @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p310, i64 4294967297) "call-inline-cost"="0", !dbg !112
  %v311 = load i64, ptr %slot31, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i32 1, ptr %p312, align 4, !alias.scope !3, !noalias !4
  %v313 = load i32, ptr %slot29, align 8
  %ext314 = sext i32 %v313 to i64
  store i64 %ext314, ptr %slot33, align 8
  %v315 = load i64, ptr %slot33, align 8
  %v316 = load i64, ptr %slot32, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 %v315, ptr %p317, align 8, !alias.scope !3, !noalias !4
  br label %bb_providerresult6
bb_providerok6:
  %v318 = load i64, ptr %slot31, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i32 0, ptr %p319, align 4, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot30, align 8
  %v321 = load i64, ptr %slot32, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  br label %bb_providerresult6
bb_providerresult6:
  %v323 = load i64, ptr %slot31, align 8
  %v324 = load i64, ptr %slot17, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 %v323, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot17, align 8
  %p327 = inttoptr i64 %v326 to ptr
  %ld328 = load i64, ptr %p327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld328, ptr %slot34, align 8
  %v329 = load i64, ptr %slot34, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i32, ptr %p330, align 4
  %ext332 = zext i32 %ld331 to i64
  store i64 %ext332, ptr %slot35, align 8
  %v333 = load i64, ptr %slot35, align 8
  %cmp334 = icmp eq i64 %v333, 0
  %cv335 = zext i1 %cmp334 to i64
  store i64 %cv335, ptr %slot36, align 8
  %v336 = load i64, ptr %slot36, align 8
  %cond337 = icmp ne i64 %v336, 0
  br i1 %cond337, label %bb_rcarm10, label %bb_rcarmnext10
bb_rcarm10:
  %v338 = load i64, ptr %slot12, align 8
  store i64 %v338, ptr %slot37, align 8
  %v339 = load i64, ptr %slot34, align 8
  %op340 = add i64 %v339, 8
  store i64 %op340, ptr %slot38, align 8
  %v341 = load i64, ptr %slot26, align 8
  store i64 %v341, ptr %slot39, align 8
  %v342 = load i64, ptr %slot38, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ld344 = load i64, ptr %p343, align 8
  store i64 %ld344, ptr %slot40, align 8
  %v345 = load i64, ptr %slot40, align 8
  %v346 = load i64, ptr %slot37, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i64 %v345, ptr %p347, align 8, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot8, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 0, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot7, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 1, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot37, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %ld354 = load i64, ptr %p353, align 8, !alias.scope !3, !noalias !4
  store i64 %ld354, ptr %slot41, align 8
  %v355 = load i64, ptr %slot41, align 8
  %v356 = load i64, ptr %slot15, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot7, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i32 0, ptr %p359, align 4, !alias.scope !3, !noalias !4
  br label %bb_i3
bb_rcarmnext10:
  %v360 = load i64, ptr %slot35, align 8
  %cmp361 = icmp eq i64 %v360, 1
  %cv362 = zext i1 %cmp361 to i64
  store i64 %cv362, ptr %slot42, align 8
  %v363 = load i64, ptr %slot42, align 8
  %cond364 = icmp ne i64 %v363, 0
  br i1 %cond364, label %bb_rcarm19, label %bb_rcarmnext19
bb_rcarm19:
  %v365 = load i64, ptr %slot12, align 8
  store i64 %v365, ptr %slot43, align 8
  %v366 = load i64, ptr %slot34, align 8
  %op367 = add i64 %v366, 8
  store i64 %op367, ptr %slot44, align 8
  %v368 = load i64, ptr %slot26, align 8
  store i64 %v368, ptr %slot45, align 8
  %v369 = load i64, ptr %slot44, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8
  store i64 %ld371, ptr %slot46, align 8
  %v372 = load i64, ptr %slot46, align 8
  %v373 = load i64, ptr %slot43, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i64 %v372, ptr %p374, align 8, !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot8, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i32 0, ptr %p376, align 4, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot7, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i32 1, ptr %p378, align 4, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot43, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot47, align 8
  %v382 = load i64, ptr %slot47, align 8
  %v383 = load i64, ptr %slot16, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i64 %v382, ptr %p384, align 8, !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot7, align 8
  %p386 = inttoptr i64 %v385 to ptr
  store i32 0, ptr %p386, align 4, !alias.scope !3, !noalias !4
  br label %bb_i7
bb_rcarmnext19:
  br label %bb_failure
bb_i3:
  %v387 = load i64, ptr %slot15, align 8
  %p388 = inttoptr i64 %v387 to ptr
  %ld389 = load i64, ptr %p388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld389, ptr %slot48, align 8
  %v390 = load i64, ptr %slot48, align 8
  %v391 = load i64, ptr %slot17, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 %v390, ptr %p392, align 8, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot19, align 8
  store i64 %v393, ptr %slot49, align 8
  %v394 = load i64, ptr %slot26, align 8
  store i64 %v394, ptr %slot50, align 8
  %v395 = load i64, ptr %slot17, align 8
  store i64 %v395, ptr %slot51, align 8
  %v396 = load i64, ptr %slot49, align 8
  %p398 = inttoptr i64 %v396 to ptr
  %gep399 = getelementptr i8, ptr %p398, i64 0
  %op397 = ptrtoint ptr %gep399 to i64
  store i64 %op397, ptr %slot52, align 8
  %v400 = load i64, ptr %slot51, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %ld402 = load i64, ptr %p401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld402, ptr %slot53, align 8
  %v403 = load i64, ptr %slot53, align 8
  %v404 = load i64, ptr %slot52, align 8
  %p405 = inttoptr i64 %v404 to ptr
  store i64 %v403, ptr %p405, align 8, !alias.scope !3, !noalias !4
  %v406 = load i64, ptr %slot49, align 8
  %v407 = load i64, ptr %slot17, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i64 %v406, ptr %p408, align 8, !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot20, align 8
  store i64 %v409, ptr %slot54, align 8
  %v410 = load i64, ptr %slot54, align 8
  %p411 = inttoptr i64 %v410 to ptr
  store i64 0, ptr %p411, align 8, !alias.scope !3, !noalias !4
  %v412 = load i64, ptr %slot54, align 8
  %p414 = inttoptr i64 %v412 to ptr
  %gep415 = getelementptr i8, ptr %p414, i64 8
  %op413 = ptrtoint ptr %gep415 to i64
  store i64 %op413, ptr %slot55, align 8
  %v416 = load i64, ptr %slot55, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i64 0, ptr %p417, align 8, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot54, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i32 0, ptr %p419, align 4, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot9, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i32 1, ptr %p421, align 4, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot17, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot56, align 8
  %v425 = load i64, ptr %slot54, align 8
  %p427 = inttoptr i64 %v425 to ptr
  %gep428 = getelementptr i8, ptr %p427, i64 8
  %op426 = ptrtoint ptr %gep428 to i64
  store i64 %op426, ptr %slot57, align 8
  %v429 = load i64, ptr %slot26, align 8
  store i64 %v429, ptr %slot58, align 8
  %v430 = load i64, ptr %slot56, align 8
  %v431 = load i64, ptr %slot57, align 8
  %p432 = inttoptr i64 %v430 to ptr
  %p433 = inttoptr i64 %v431 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p433, ptr %p432, i64 8, i1 false)
  %v434 = load i64, ptr %slot54, align 8
  %v435 = load i64, ptr %slot17, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i64 %v434, ptr %p436, align 8, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot17, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld439, ptr %slot59, align 8
  %v440 = load i64, ptr %slot10, align 8
  store i64 %v440, ptr %slot60, align 8
  %v441 = load i64, ptr %slot59, align 8
  %v442 = load i64, ptr %slot60, align 8
  %p443 = inttoptr i64 %v441 to ptr
  %p444 = inttoptr i64 %v442 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p444, ptr %p443, i64 16, i1 false)
  %v445 = load i64, ptr %slot6, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i32 2, ptr %p446, align 4, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot5, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 1, ptr %p448, align 4, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot60, align 8
  %v450 = load i64, ptr %slot17, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i64 %v449, ptr %p451, align 8, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot17, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot61, align 8
  %v455 = load i64, ptr %slot17, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %ld457 = load i64, ptr %p456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld457, ptr %slot62, align 8
  %v458 = load i64, ptr %slot12, align 8
  store i64 %v458, ptr %slot63, align 8
  %v459 = load i64, ptr %slot26, align 8
  store i64 %v459, ptr %slot64, align 8
  %v460 = load i64, ptr %slot25, align 8
  %v461 = load i64, ptr %slot63, align 8
  %v462 = load i64, ptr %slot62, align 8
  %v463 = load i64, ptr %slot64, align 8
  %cv464 = trunc i64 %v463 to i32
  %call465 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v460, i64 %v461, i64 %v462, i32 %cv464) nomerge, !dbg !114
  store i32 %call465, ptr %slot65, align 8
  %v466 = load i32, ptr %slot65, align 8
  %cv467 = zext i32 %v466 to i64
  %cond468 = icmp ne i64 %cv467, 0
  br i1 %cond468, label %bb_rcsuccess50, label %bb_rcfailure50
bb_rcfailure50:
  %v469 = load i64, ptr %slot25, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %call471 = call i32 @myl_rc_take_failure(ptr %p470) nomerge, !dbg !114
  store i32 %call471, ptr %slot66, align 8
  %v472 = load i64, ptr %slot1, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %v474 = load i32, ptr %slot66, align 8
  %call475 = call i32 @myl_qbe_rc_status(ptr %p473, i32 %v474) nomerge, !dbg !114
  store i32 %call475, ptr %slot67, align 8
  br label %bb_failure
bb_rcsuccess50:
  %v476 = load i64, ptr %slot5, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 0, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot8, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 2, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot7, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 1, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot12, align 8
  store i64 %v482, ptr %slot68, align 8
  %v483 = load i64, ptr %slot7, align 8
  %p484 = inttoptr i64 %v483 to ptr
  store i32 0, ptr %p484, align 4, !alias.scope !3, !noalias !4
  %v485 = load i64, ptr %slot5, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i32, ptr %p486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld487, ptr %slot69, align 8
  %v488 = load i32, ptr %slot69, align 8
  %cv489 = zext i32 %v488 to i64
  %cond490 = icmp ne i64 %cv489, 0
  br i1 %cond490, label %bb_rcslotdrop60, label %bb_rcslotdone60
bb_rcslotdrop60:
  %v491 = load i64, ptr %slot5, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 0, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot10, align 8
  store i64 %v493, ptr %slot70, align 8
  %v494 = load i64, ptr %slot6, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %ld496 = load i32, ptr %p495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld496, ptr %slot71, align 8
  %v497 = load i32, ptr %slot71, align 8
  %op498 = and i32 %v497, 28
  store i32 %op498, ptr %slot72, align 8
  %v499 = load i32, ptr %slot72, align 8
  %cv500 = zext i32 %v499 to i64
  %cond501 = icmp ne i64 %cv500, 0
  br i1 %cond501, label %bb_rcslotrole60, label %bb_rcslotowner60
bb_rcslotrole60:
  %v502 = load i64, ptr %slot25, align 8
  store i64 %v502, ptr %slot73, align 8
  %v503 = load i64, ptr %slot73, align 8
  %v504 = load i64, ptr %slot70, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v503, i64 %v504) nomerge, !dbg !114
  br label %bb_rcslotdone60
bb_rcslotowner60:
  %v505 = load i64, ptr %slot25, align 8
  store i64 %v505, ptr %slot74, align 8
  %v506 = load i64, ptr %slot74, align 8
  %v507 = load i64, ptr %slot70, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v506, i64 %v507) nomerge, !dbg !114
  br label %bb_rcslotdone60
bb_rcslotdone60:
  %v508 = load i64, ptr %slot68, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ret510 = load { i64, i64 }, ptr %p509, align 8
  ret { i64, i64 } %ret510
bb_i7:
  %v511 = load i64, ptr %slot16, align 8
  %p512 = inttoptr i64 %v511 to ptr
  %ld513 = load i64, ptr %p512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld513, ptr %slot75, align 8
  %v514 = load i64, ptr %slot75, align 8
  %v515 = load i64, ptr %slot17, align 8
  %p516 = inttoptr i64 %v515 to ptr
  store i64 %v514, ptr %p516, align 8, !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot18, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 1, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot18, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i64, ptr %p520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld521, ptr %slot76, align 8
  %v522 = load i64, ptr %slot17, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld524, ptr %slot77, align 8
  %v525 = load i64, ptr %slot77, align 8
  %v526 = load i64, ptr %slot76, align 8
  %cmp527 = icmp eq i64 %v525, %v526
  %cv528 = zext i1 %cmp527 to i64
  store i64 %cv528, ptr %slot78, align 8
  %v529 = load i64, ptr %slot78, align 8
  %v530 = load i64, ptr %slot17, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot17, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot79, align 8
  %v535 = load i64, ptr %slot79, align 8
  %cond536 = icmp ne i64 %v535, 0
  br i1 %cond536, label %bb_next72, label %bb_i14
bb_next72:
  %p537 = inttoptr i64 ptrtoint (ptr @myl_lit_2a783d763ead5d0f06471f24d9bb44896b740005391a4afafe5eae5ecc885e6e to i64) to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !4, !noalias !3
  store i64 %ld538, ptr %slot80, align 8
  %v539 = load i64, ptr %slot80, align 8
  %v540 = load i64, ptr %slot17, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot17, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot81, align 8
  %v545 = load i64, ptr %slot81, align 8
  %v546 = load i64, ptr %slot11, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot11, align 8
  store i64 %v548, ptr %slot82, align 8
  %v549 = load i64, ptr %slot12, align 8
  store i64 %v549, ptr %slot83, align 8
  %v550 = load i64, ptr %slot82, align 8
  %v551 = load i64, ptr %slot83, align 8
  %p552 = inttoptr i64 %v550 to ptr
  %p553 = inttoptr i64 %v551 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p553, ptr %p552, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot8, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i32 2, ptr %p555, align 4, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot7, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i32 1, ptr %p557, align 4, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot10, align 8
  store i64 %v558, ptr %slot84, align 8
  %v559 = load i64, ptr %slot12, align 8
  store i64 %v559, ptr %slot85, align 8
  %v560 = load i64, ptr %slot85, align 8
  %v561 = load i64, ptr %slot84, align 8
  %p562 = inttoptr i64 %v560 to ptr
  %p563 = inttoptr i64 %v561 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p563, ptr %p562, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v564 = load i64, ptr %slot6, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i32 2, ptr %p565, align 4, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot8, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i32, ptr %p567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld568, ptr %slot86, align 8
  %v569 = load i32, ptr %slot86, align 8
  %v570 = load i64, ptr %slot6, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i32 %v569, ptr %p571, align 4, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot7, align 8
  %p573 = inttoptr i64 %v572 to ptr
  store i32 0, ptr %p573, align 4, !alias.scope !3, !noalias !4
  %v574 = load i64, ptr %slot5, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i32 1, ptr %p575, align 4, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot84, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i64, ptr %p577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld578, ptr %slot87, align 8
  %v579 = load i64, ptr %slot87, align 8
  %v580 = load i64, ptr %slot17, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 %v579, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot21, align 8
  store i64 %v582, ptr %slot88, align 8
  %v583 = load i64, ptr %slot88, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 0, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot88, align 8
  %p587 = inttoptr i64 %v585 to ptr
  %gep588 = getelementptr i8, ptr %p587, i64 8
  %op586 = ptrtoint ptr %gep588 to i64
  store i64 %op586, ptr %slot89, align 8
  %v589 = load i64, ptr %slot89, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 0, ptr %p590, align 8, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot88, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 1, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot9, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 1, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot17, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot90, align 8
  %v598 = load i64, ptr %slot90, align 8
  %v599 = load i64, ptr %slot11, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i64 %v598, ptr %p600, align 8, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot11, align 8
  store i64 %v601, ptr %slot91, align 8
  %v602 = load i64, ptr %slot88, align 8
  %p604 = inttoptr i64 %v602 to ptr
  %gep605 = getelementptr i8, ptr %p604, i64 8
  %op603 = ptrtoint ptr %gep605 to i64
  store i64 %op603, ptr %slot92, align 8
  %v606 = load i64, ptr %slot26, align 8
  store i64 %v606, ptr %slot93, align 8
  %v607 = load i64, ptr %slot17, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i64, ptr %p608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld609, ptr %slot94, align 8
  %v610 = load i64, ptr %slot94, align 8
  %v611 = load i64, ptr %slot11, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i64 %v610, ptr %p612, align 8, !alias.scope !3, !noalias !4
  %v613 = load i64, ptr %slot11, align 8
  store i64 %v613, ptr %slot95, align 8
  %v614 = load i64, ptr %slot12, align 8
  store i64 %v614, ptr %slot96, align 8
  %v615 = load i64, ptr %slot26, align 8
  store i64 %v615, ptr %slot97, align 8
  %v616 = load i64, ptr %slot95, align 8
  %p618 = inttoptr i64 %v616 to ptr
  %gep619 = getelementptr i8, ptr %p618, i64 0
  %op617 = ptrtoint ptr %gep619 to i64
  store i64 %op617, ptr %slot98, align 8
  %v620 = load i64, ptr %slot98, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot99, align 8
  %v623 = load i64, ptr %slot99, align 8
  %cmp624 = icmp ne i64 %v623, 0
  %cv625 = zext i1 %cmp624 to i32
  store i32 %cv625, ptr %slot100, align 8
  %v626 = load i32, ptr %slot100, align 8
  %cv627 = zext i32 %v626 to i64
  %cond628 = icmp ne i64 %cv627, 0
  br i1 %cond628, label %bb_rcmoveheader103, label %bb_rcmovenext103
bb_rcmoveheader103:
  %v629 = load i64, ptr %slot99, align 8
  %op630 = sub i64 %v629, 16
  store i64 %op630, ptr %slot101, align 8
  %v631 = load i64, ptr %slot99, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %rgep633 = getelementptr i8, ptr %p632, i64 -16
  %ld634 = load i64, ptr %rgep633, align 8, !alias.scope !9, !noalias !10
  store i64 %ld634, ptr %slot102, align 8
  %v635 = load i64, ptr %slot102, align 8
  %op636 = and i64 %v635, 5764607523034234881
  store i64 %op636, ptr %slot103, align 8
  %v637 = load i64, ptr %slot103, align 8
  %cmp638 = icmp ne i64 %v637, 0
  %cv639 = zext i1 %cmp638 to i32
  store i32 %cv639, ptr %slot104, align 8
  %v640 = load i32, ptr %slot104, align 8
  %cv641 = zext i32 %v640 to i64
  %cond642 = icmp ne i64 %cv641, 0
  br i1 %cond642, label %bb_rcmoveslow100, label %bb_rcmovenext103
bb_rcmovenext103:
  %v643 = load i64, ptr %slot95, align 8
  %v644 = load i64, ptr %slot96, align 8
  %p645 = inttoptr i64 %v643 to ptr
  %p646 = inttoptr i64 %v644 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p646, ptr %p645, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot95, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i64 0, ptr %p648, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved100
bb_rcmoveslow100:
  %v649 = load i64, ptr %slot25, align 8
  %v650 = load i64, ptr %slot96, align 8
  %v651 = load i64, ptr %slot95, align 8
  %v652 = load i64, ptr %slot97, align 8
  %cv653 = trunc i64 %v652 to i32
  %call654 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v649, i64 %v650, i64 %v651, i32 %cv653) nomerge, !dbg !116
  store i32 %call654, ptr %slot105, align 8
  %v655 = load i32, ptr %slot105, align 8
  %cv656 = zext i32 %v655 to i64
  %cond657 = icmp ne i64 %cv656, 0
  br i1 %cond657, label %bb_rcsuccess110, label %bb_rcfailure110
bb_rcfailure110:
  %v658 = load i64, ptr %slot25, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %call660 = call i32 @myl_rc_take_failure(ptr %p659) nomerge, !dbg !116
  store i32 %call660, ptr %slot106, align 8
  %v661 = load i64, ptr %slot1, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %v663 = load i32, ptr %slot106, align 8
  %call664 = call i32 @myl_qbe_rc_status(ptr %p662, i32 %v663) nomerge, !dbg !116
  store i32 %call664, ptr %slot107, align 8
  br label %bb_failure
bb_rcsuccess110:
  br label %bb_rcmoved100
bb_rcmoved100:
  %v665 = load i64, ptr %slot5, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 0, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot8, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 2, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot7, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 1, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot12, align 8
  store i64 %v671, ptr %slot108, align 8
  %v672 = load i64, ptr %slot108, align 8
  %v673 = load i64, ptr %slot92, align 8
  %p674 = inttoptr i64 %v672 to ptr
  %p675 = inttoptr i64 %v673 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p675, ptr %p674, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v676 = load i64, ptr %slot7, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i32 0, ptr %p677, align 4, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot88, align 8
  %v679 = load i64, ptr %slot17, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 %v678, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %p681 = inttoptr i64 ptrtoint (ptr @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p681, i64 12) "call-inline-cost"="0", !dbg !116
  %v682 = load i64, ptr %slot17, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot109, align 8
  %v685 = load i64, ptr %slot10, align 8
  store i64 %v685, ptr %slot110, align 8
  %v686 = load i64, ptr %slot109, align 8
  %v687 = load i64, ptr %slot110, align 8
  %p688 = inttoptr i64 %v686 to ptr
  %p689 = inttoptr i64 %v687 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p689, ptr %p688, i64 16, i1 false)
  %v690 = load i64, ptr %slot6, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i32 2, ptr %p691, align 4, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot5, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i32 1, ptr %p693, align 4, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot110, align 8
  %v695 = load i64, ptr %slot17, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i64 %v694, ptr %p696, align 8, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot17, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i64, ptr %p698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld699, ptr %slot111, align 8
  %v700 = load i64, ptr %slot17, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %ld702 = load i64, ptr %p701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld702, ptr %slot112, align 8
  %v703 = load i64, ptr %slot12, align 8
  store i64 %v703, ptr %slot113, align 8
  %v704 = load i64, ptr %slot26, align 8
  store i64 %v704, ptr %slot114, align 8
  %v705 = load i64, ptr %slot25, align 8
  %v706 = load i64, ptr %slot113, align 8
  %v707 = load i64, ptr %slot112, align 8
  %v708 = load i64, ptr %slot114, align 8
  %cv709 = trunc i64 %v708 to i32
  %call710 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v705, i64 %v706, i64 %v707, i32 %cv709) nomerge, !dbg !118
  store i32 %call710, ptr %slot115, align 8
  %v711 = load i32, ptr %slot115, align 8
  %cv712 = zext i32 %v711 to i64
  %cond713 = icmp ne i64 %cv712, 0
  br i1 %cond713, label %bb_rcsuccess127, label %bb_rcfailure127
bb_rcfailure127:
  %v714 = load i64, ptr %slot25, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %call716 = call i32 @myl_rc_take_failure(ptr %p715) nomerge, !dbg !118
  store i32 %call716, ptr %slot116, align 8
  %v717 = load i64, ptr %slot1, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %v719 = load i32, ptr %slot116, align 8
  %call720 = call i32 @myl_qbe_rc_status(ptr %p718, i32 %v719) nomerge, !dbg !118
  store i32 %call720, ptr %slot117, align 8
  br label %bb_failure
bb_rcsuccess127:
  %v721 = load i64, ptr %slot5, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i32 0, ptr %p722, align 4, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot8, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i32 2, ptr %p724, align 4, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot7, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 1, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot12, align 8
  store i64 %v727, ptr %slot118, align 8
  %v728 = load i64, ptr %slot7, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 0, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot5, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i32, ptr %p731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld732, ptr %slot119, align 8
  %v733 = load i32, ptr %slot119, align 8
  %cv734 = zext i32 %v733 to i64
  %cond735 = icmp ne i64 %cv734, 0
  br i1 %cond735, label %bb_rcslotdrop137, label %bb_rcslotdone137
bb_rcslotdrop137:
  %v736 = load i64, ptr %slot5, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i32 0, ptr %p737, align 4, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot10, align 8
  store i64 %v738, ptr %slot120, align 8
  %v739 = load i64, ptr %slot6, align 8
  %p740 = inttoptr i64 %v739 to ptr
  %ld741 = load i32, ptr %p740, align 4, !alias.scope !3, !noalias !4
  store i32 %ld741, ptr %slot121, align 8
  %v742 = load i32, ptr %slot121, align 8
  %op743 = and i32 %v742, 28
  store i32 %op743, ptr %slot122, align 8
  %v744 = load i32, ptr %slot122, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcslotrole137, label %bb_rcslotowner137
bb_rcslotrole137:
  %v747 = load i64, ptr %slot25, align 8
  store i64 %v747, ptr %slot123, align 8
  %v748 = load i64, ptr %slot123, align 8
  %v749 = load i64, ptr %slot120, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v748, i64 %v749) nomerge, !dbg !118
  br label %bb_rcslotdone137
bb_rcslotowner137:
  %v750 = load i64, ptr %slot25, align 8
  store i64 %v750, ptr %slot124, align 8
  %v751 = load i64, ptr %slot124, align 8
  %v752 = load i64, ptr %slot120, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v751, i64 %v752) nomerge, !dbg !118
  br label %bb_rcslotdone137
bb_rcslotdone137:
  %v753 = load i64, ptr %slot118, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ret755 = load { i64, i64 }, ptr %p754, align 8
  ret { i64, i64 } %ret755
bb_i14:
  %v756 = load i64, ptr %slot16, align 8
  %p757 = inttoptr i64 %v756 to ptr
  %ld758 = load i64, ptr %p757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld758, ptr %slot125, align 8
  %v759 = load i64, ptr %slot125, align 8
  %v760 = load i64, ptr %slot17, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i64 %v759, ptr %p761, align 8, !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot18, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 2, ptr %p763, align 8, !alias.scope !3, !noalias !4
  %v764 = load i64, ptr %slot18, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %ld766 = load i64, ptr %p765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld766, ptr %slot126, align 8
  %v767 = load i64, ptr %slot17, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i64, ptr %p768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld769, ptr %slot127, align 8
  %v770 = load i64, ptr %slot127, align 8
  %v771 = load i64, ptr %slot126, align 8
  %cmp772 = icmp eq i64 %v770, %v771
  %cv773 = zext i1 %cmp772 to i64
  store i64 %cv773, ptr %slot128, align 8
  %v774 = load i64, ptr %slot128, align 8
  %v775 = load i64, ptr %slot17, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i64 %v774, ptr %p776, align 8, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot17, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i64, ptr %p778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld779, ptr %slot129, align 8
  %v780 = load i64, ptr %slot129, align 8
  %cond781 = icmp ne i64 %v780, 0
  br i1 %cond781, label %bb_next149, label %bb_i21
bb_next149:
  %p782 = inttoptr i64 ptrtoint (ptr @myl_lit_1b60d1144300d5255a2a0f70e48320fe88a6202cef2ca80b540c41a74305a317 to i64) to ptr
  %ld783 = load i64, ptr %p782, align 8, !alias.scope !4, !noalias !3
  store i64 %ld783, ptr %slot130, align 8
  %v784 = load i64, ptr %slot130, align 8
  %v785 = load i64, ptr %slot17, align 8
  %p786 = inttoptr i64 %v785 to ptr
  store i64 %v784, ptr %p786, align 8, !alias.scope !3, !noalias !4
  %v787 = load i64, ptr %slot17, align 8
  %p788 = inttoptr i64 %v787 to ptr
  %ld789 = load i64, ptr %p788, align 8, !alias.scope !3, !noalias !4
  store i64 %ld789, ptr %slot131, align 8
  %v790 = load i64, ptr %slot131, align 8
  %v791 = load i64, ptr %slot11, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 %v790, ptr %p792, align 8, !alias.scope !3, !noalias !4
  %v793 = load i64, ptr %slot11, align 8
  store i64 %v793, ptr %slot132, align 8
  %v794 = load i64, ptr %slot12, align 8
  store i64 %v794, ptr %slot133, align 8
  %v795 = load i64, ptr %slot132, align 8
  %v796 = load i64, ptr %slot133, align 8
  %p797 = inttoptr i64 %v795 to ptr
  %p798 = inttoptr i64 %v796 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p798, ptr %p797, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v799 = load i64, ptr %slot8, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i32 2, ptr %p800, align 4, !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot7, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i32 1, ptr %p802, align 4, !alias.scope !3, !noalias !4
  %v803 = load i64, ptr %slot10, align 8
  store i64 %v803, ptr %slot134, align 8
  %v804 = load i64, ptr %slot12, align 8
  store i64 %v804, ptr %slot135, align 8
  %v805 = load i64, ptr %slot135, align 8
  %v806 = load i64, ptr %slot134, align 8
  %p807 = inttoptr i64 %v805 to ptr
  %p808 = inttoptr i64 %v806 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p808, ptr %p807, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot6, align 8
  %p810 = inttoptr i64 %v809 to ptr
  store i32 2, ptr %p810, align 4, !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot8, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %ld813 = load i32, ptr %p812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld813, ptr %slot136, align 8
  %v814 = load i32, ptr %slot136, align 8
  %v815 = load i64, ptr %slot6, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i32 %v814, ptr %p816, align 4, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot7, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i32 0, ptr %p818, align 4, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot5, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i32 1, ptr %p820, align 4, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot134, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld823, ptr %slot137, align 8
  %v824 = load i64, ptr %slot137, align 8
  %v825 = load i64, ptr %slot17, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i64 %v824, ptr %p826, align 8, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot22, align 8
  store i64 %v827, ptr %slot138, align 8
  %v828 = load i64, ptr %slot138, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 0, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot138, align 8
  %p832 = inttoptr i64 %v830 to ptr
  %gep833 = getelementptr i8, ptr %p832, i64 8
  %op831 = ptrtoint ptr %gep833 to i64
  store i64 %op831, ptr %slot139, align 8
  %v834 = load i64, ptr %slot139, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 0, ptr %p835, align 8, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot138, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i32 1, ptr %p837, align 4, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot9, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i32 1, ptr %p839, align 4, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot17, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i64, ptr %p841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld842, ptr %slot140, align 8
  %v843 = load i64, ptr %slot140, align 8
  %v844 = load i64, ptr %slot11, align 8
  %p845 = inttoptr i64 %v844 to ptr
  store i64 %v843, ptr %p845, align 8, !alias.scope !3, !noalias !4
  %v846 = load i64, ptr %slot11, align 8
  store i64 %v846, ptr %slot141, align 8
  %v847 = load i64, ptr %slot138, align 8
  %p849 = inttoptr i64 %v847 to ptr
  %gep850 = getelementptr i8, ptr %p849, i64 8
  %op848 = ptrtoint ptr %gep850 to i64
  store i64 %op848, ptr %slot142, align 8
  %v851 = load i64, ptr %slot26, align 8
  store i64 %v851, ptr %slot143, align 8
  %v852 = load i64, ptr %slot17, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %ld854 = load i64, ptr %p853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld854, ptr %slot144, align 8
  %v855 = load i64, ptr %slot144, align 8
  %v856 = load i64, ptr %slot11, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i64 %v855, ptr %p857, align 8, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot11, align 8
  store i64 %v858, ptr %slot145, align 8
  %v859 = load i64, ptr %slot12, align 8
  store i64 %v859, ptr %slot146, align 8
  %v860 = load i64, ptr %slot26, align 8
  store i64 %v860, ptr %slot147, align 8
  %v861 = load i64, ptr %slot145, align 8
  %p863 = inttoptr i64 %v861 to ptr
  %gep864 = getelementptr i8, ptr %p863, i64 0
  %op862 = ptrtoint ptr %gep864 to i64
  store i64 %op862, ptr %slot148, align 8
  %v865 = load i64, ptr %slot148, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot149, align 8
  %v868 = load i64, ptr %slot149, align 8
  %cmp869 = icmp ne i64 %v868, 0
  %cv870 = zext i1 %cmp869 to i32
  store i32 %cv870, ptr %slot150, align 8
  %v871 = load i32, ptr %slot150, align 8
  %cv872 = zext i32 %v871 to i64
  %cond873 = icmp ne i64 %cv872, 0
  br i1 %cond873, label %bb_rcmoveheader180, label %bb_rcmovenext180
bb_rcmoveheader180:
  %v874 = load i64, ptr %slot149, align 8
  %op875 = sub i64 %v874, 16
  store i64 %op875, ptr %slot151, align 8
  %v876 = load i64, ptr %slot149, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %rgep878 = getelementptr i8, ptr %p877, i64 -16
  %ld879 = load i64, ptr %rgep878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld879, ptr %slot152, align 8
  %v880 = load i64, ptr %slot152, align 8
  %op881 = and i64 %v880, 5764607523034234881
  store i64 %op881, ptr %slot153, align 8
  %v882 = load i64, ptr %slot153, align 8
  %cmp883 = icmp ne i64 %v882, 0
  %cv884 = zext i1 %cmp883 to i32
  store i32 %cv884, ptr %slot154, align 8
  %v885 = load i32, ptr %slot154, align 8
  %cv886 = zext i32 %v885 to i64
  %cond887 = icmp ne i64 %cv886, 0
  br i1 %cond887, label %bb_rcmoveslow177, label %bb_rcmovenext180
bb_rcmovenext180:
  %v888 = load i64, ptr %slot145, align 8
  %v889 = load i64, ptr %slot146, align 8
  %p890 = inttoptr i64 %v888 to ptr
  %p891 = inttoptr i64 %v889 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p891, ptr %p890, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot145, align 8
  %p893 = inttoptr i64 %v892 to ptr
  store i64 0, ptr %p893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved177
bb_rcmoveslow177:
  %v894 = load i64, ptr %slot25, align 8
  %v895 = load i64, ptr %slot146, align 8
  %v896 = load i64, ptr %slot145, align 8
  %v897 = load i64, ptr %slot147, align 8
  %cv898 = trunc i64 %v897 to i32
  %call899 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v894, i64 %v895, i64 %v896, i32 %cv898) nomerge, !dbg !120
  store i32 %call899, ptr %slot155, align 8
  %v900 = load i32, ptr %slot155, align 8
  %cv901 = zext i32 %v900 to i64
  %cond902 = icmp ne i64 %cv901, 0
  br i1 %cond902, label %bb_rcsuccess187, label %bb_rcfailure187
bb_rcfailure187:
  %v903 = load i64, ptr %slot25, align 8
  %p904 = inttoptr i64 %v903 to ptr
  %call905 = call i32 @myl_rc_take_failure(ptr %p904) nomerge, !dbg !120
  store i32 %call905, ptr %slot156, align 8
  %v906 = load i64, ptr %slot1, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %v908 = load i32, ptr %slot156, align 8
  %call909 = call i32 @myl_qbe_rc_status(ptr %p907, i32 %v908) nomerge, !dbg !120
  store i32 %call909, ptr %slot157, align 8
  br label %bb_failure
bb_rcsuccess187:
  br label %bb_rcmoved177
bb_rcmoved177:
  %v910 = load i64, ptr %slot5, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i32 0, ptr %p911, align 4, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot8, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 2, ptr %p913, align 4, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot7, align 8
  %p915 = inttoptr i64 %v914 to ptr
  store i32 1, ptr %p915, align 4, !alias.scope !3, !noalias !4
  %v916 = load i64, ptr %slot12, align 8
  store i64 %v916, ptr %slot158, align 8
  %v917 = load i64, ptr %slot158, align 8
  %v918 = load i64, ptr %slot142, align 8
  %p919 = inttoptr i64 %v917 to ptr
  %p920 = inttoptr i64 %v918 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p920, ptr %p919, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v921 = load i64, ptr %slot7, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i32 0, ptr %p922, align 4, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot138, align 8
  %v924 = load i64, ptr %slot17, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i64 %v923, ptr %p925, align 8, !alias.scope !3, !noalias !4
  %p926 = inttoptr i64 ptrtoint (ptr @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p926, i64 19) "call-inline-cost"="0", !dbg !120
  %v927 = load i64, ptr %slot17, align 8
  %p928 = inttoptr i64 %v927 to ptr
  %ld929 = load i64, ptr %p928, align 8, !alias.scope !3, !noalias !4
  store i64 %ld929, ptr %slot159, align 8
  %v930 = load i64, ptr %slot10, align 8
  store i64 %v930, ptr %slot160, align 8
  %v931 = load i64, ptr %slot159, align 8
  %v932 = load i64, ptr %slot160, align 8
  %p933 = inttoptr i64 %v931 to ptr
  %p934 = inttoptr i64 %v932 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p934, ptr %p933, i64 16, i1 false)
  %v935 = load i64, ptr %slot6, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i32 2, ptr %p936, align 4, !alias.scope !3, !noalias !4
  %v937 = load i64, ptr %slot5, align 8
  %p938 = inttoptr i64 %v937 to ptr
  store i32 1, ptr %p938, align 4, !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot160, align 8
  %v940 = load i64, ptr %slot17, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i64 %v939, ptr %p941, align 8, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot17, align 8
  %p943 = inttoptr i64 %v942 to ptr
  %ld944 = load i64, ptr %p943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld944, ptr %slot161, align 8
  %v945 = load i64, ptr %slot17, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i64, ptr %p946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld947, ptr %slot162, align 8
  %v948 = load i64, ptr %slot12, align 8
  store i64 %v948, ptr %slot163, align 8
  %v949 = load i64, ptr %slot26, align 8
  store i64 %v949, ptr %slot164, align 8
  %v950 = load i64, ptr %slot25, align 8
  %v951 = load i64, ptr %slot163, align 8
  %v952 = load i64, ptr %slot162, align 8
  %v953 = load i64, ptr %slot164, align 8
  %cv954 = trunc i64 %v953 to i32
  %call955 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v950, i64 %v951, i64 %v952, i32 %cv954) nomerge, !dbg !122
  store i32 %call955, ptr %slot165, align 8
  %v956 = load i32, ptr %slot165, align 8
  %cv957 = zext i32 %v956 to i64
  %cond958 = icmp ne i64 %cv957, 0
  br i1 %cond958, label %bb_rcsuccess204, label %bb_rcfailure204
bb_rcfailure204:
  %v959 = load i64, ptr %slot25, align 8
  %p960 = inttoptr i64 %v959 to ptr
  %call961 = call i32 @myl_rc_take_failure(ptr %p960) nomerge, !dbg !122
  store i32 %call961, ptr %slot166, align 8
  %v962 = load i64, ptr %slot1, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %v964 = load i32, ptr %slot166, align 8
  %call965 = call i32 @myl_qbe_rc_status(ptr %p963, i32 %v964) nomerge, !dbg !122
  store i32 %call965, ptr %slot167, align 8
  br label %bb_failure
bb_rcsuccess204:
  %v966 = load i64, ptr %slot5, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i32 0, ptr %p967, align 4, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot8, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i32 2, ptr %p969, align 4, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot7, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i32 1, ptr %p971, align 4, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot12, align 8
  store i64 %v972, ptr %slot168, align 8
  %v973 = load i64, ptr %slot7, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i32 0, ptr %p974, align 4, !alias.scope !3, !noalias !4
  %v975 = load i64, ptr %slot5, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i32, ptr %p976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld977, ptr %slot169, align 8
  %v978 = load i32, ptr %slot169, align 8
  %cv979 = zext i32 %v978 to i64
  %cond980 = icmp ne i64 %cv979, 0
  br i1 %cond980, label %bb_rcslotdrop214, label %bb_rcslotdone214
bb_rcslotdrop214:
  %v981 = load i64, ptr %slot5, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i32 0, ptr %p982, align 4, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot10, align 8
  store i64 %v983, ptr %slot170, align 8
  %v984 = load i64, ptr %slot6, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i32, ptr %p985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld986, ptr %slot171, align 8
  %v987 = load i32, ptr %slot171, align 8
  %op988 = and i32 %v987, 28
  store i32 %op988, ptr %slot172, align 8
  %v989 = load i32, ptr %slot172, align 8
  %cv990 = zext i32 %v989 to i64
  %cond991 = icmp ne i64 %cv990, 0
  br i1 %cond991, label %bb_rcslotrole214, label %bb_rcslotowner214
bb_rcslotrole214:
  %v992 = load i64, ptr %slot25, align 8
  store i64 %v992, ptr %slot173, align 8
  %v993 = load i64, ptr %slot173, align 8
  %v994 = load i64, ptr %slot170, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v993, i64 %v994) nomerge, !dbg !122
  br label %bb_rcslotdone214
bb_rcslotowner214:
  %v995 = load i64, ptr %slot25, align 8
  store i64 %v995, ptr %slot174, align 8
  %v996 = load i64, ptr %slot174, align 8
  %v997 = load i64, ptr %slot170, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v996, i64 %v997) nomerge, !dbg !122
  br label %bb_rcslotdone214
bb_rcslotdone214:
  %v998 = load i64, ptr %slot168, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %ret1000 = load { i64, i64 }, ptr %p999, align 8
  ret { i64, i64 } %ret1000
bb_i21:
  %p1001 = inttoptr i64 ptrtoint (ptr @myl_lit_c1ecc0853024398f95c525fbabe622e97660f71635b139ca4c636117149e7330 to i64) to ptr
  %ld1002 = load i64, ptr %p1001, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1002, ptr %slot175, align 8
  %v1003 = load i64, ptr %slot175, align 8
  %v1004 = load i64, ptr %slot17, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  store i64 %v1003, ptr %p1005, align 8, !alias.scope !3, !noalias !4
  %v1006 = load i64, ptr %slot17, align 8
  %p1007 = inttoptr i64 %v1006 to ptr
  %ld1008 = load i64, ptr %p1007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1008, ptr %slot176, align 8
  %v1009 = load i64, ptr %slot176, align 8
  %v1010 = load i64, ptr %slot11, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  store i64 %v1009, ptr %p1011, align 8, !alias.scope !3, !noalias !4
  %v1012 = load i64, ptr %slot11, align 8
  store i64 %v1012, ptr %slot177, align 8
  %v1013 = load i64, ptr %slot12, align 8
  store i64 %v1013, ptr %slot178, align 8
  %v1014 = load i64, ptr %slot177, align 8
  %v1015 = load i64, ptr %slot178, align 8
  %p1016 = inttoptr i64 %v1014 to ptr
  %p1017 = inttoptr i64 %v1015 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1017, ptr %p1016, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1018 = load i64, ptr %slot8, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  store i32 2, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  %v1020 = load i64, ptr %slot7, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  store i32 1, ptr %p1021, align 4, !alias.scope !3, !noalias !4
  %v1022 = load i64, ptr %slot10, align 8
  store i64 %v1022, ptr %slot179, align 8
  %v1023 = load i64, ptr %slot12, align 8
  store i64 %v1023, ptr %slot180, align 8
  %v1024 = load i64, ptr %slot180, align 8
  %v1025 = load i64, ptr %slot179, align 8
  %p1026 = inttoptr i64 %v1024 to ptr
  %p1027 = inttoptr i64 %v1025 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1027, ptr %p1026, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1028 = load i64, ptr %slot6, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i32 2, ptr %p1029, align 4, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot8, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  %ld1032 = load i32, ptr %p1031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1032, ptr %slot181, align 8
  %v1033 = load i32, ptr %slot181, align 8
  %v1034 = load i64, ptr %slot6, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  store i32 %v1033, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot7, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i32 0, ptr %p1037, align 4, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot5, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i32 1, ptr %p1039, align 4, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot179, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot182, align 8
  %v1043 = load i64, ptr %slot182, align 8
  %v1044 = load i64, ptr %slot17, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i64 %v1043, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot23, align 8
  store i64 %v1046, ptr %slot183, align 8
  %v1047 = load i64, ptr %slot183, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i64 0, ptr %p1048, align 8, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot183, align 8
  %p1051 = inttoptr i64 %v1049 to ptr
  %gep1052 = getelementptr i8, ptr %p1051, i64 8
  %op1050 = ptrtoint ptr %gep1052 to i64
  store i64 %op1050, ptr %slot184, align 8
  %v1053 = load i64, ptr %slot184, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 0, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot183, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  store i32 1, ptr %p1056, align 4, !alias.scope !3, !noalias !4
  %v1057 = load i64, ptr %slot9, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i32 1, ptr %p1058, align 4, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot17, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %ld1061 = load i64, ptr %p1060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1061, ptr %slot185, align 8
  %v1062 = load i64, ptr %slot185, align 8
  %v1063 = load i64, ptr %slot11, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  store i64 %v1062, ptr %p1064, align 8, !alias.scope !3, !noalias !4
  %v1065 = load i64, ptr %slot11, align 8
  store i64 %v1065, ptr %slot186, align 8
  %v1066 = load i64, ptr %slot183, align 8
  %p1068 = inttoptr i64 %v1066 to ptr
  %gep1069 = getelementptr i8, ptr %p1068, i64 8
  %op1067 = ptrtoint ptr %gep1069 to i64
  store i64 %op1067, ptr %slot187, align 8
  %v1070 = load i64, ptr %slot26, align 8
  store i64 %v1070, ptr %slot188, align 8
  %v1071 = load i64, ptr %slot17, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  %ld1073 = load i64, ptr %p1072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1073, ptr %slot189, align 8
  %v1074 = load i64, ptr %slot189, align 8
  %v1075 = load i64, ptr %slot11, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i64 %v1074, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot11, align 8
  store i64 %v1077, ptr %slot190, align 8
  %v1078 = load i64, ptr %slot12, align 8
  store i64 %v1078, ptr %slot191, align 8
  %v1079 = load i64, ptr %slot26, align 8
  store i64 %v1079, ptr %slot192, align 8
  %v1080 = load i64, ptr %slot190, align 8
  %p1082 = inttoptr i64 %v1080 to ptr
  %gep1083 = getelementptr i8, ptr %p1082, i64 0
  %op1081 = ptrtoint ptr %gep1083 to i64
  store i64 %op1081, ptr %slot193, align 8
  %v1084 = load i64, ptr %slot193, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i64, ptr %p1085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1086, ptr %slot194, align 8
  %v1087 = load i64, ptr %slot194, align 8
  %cmp1088 = icmp ne i64 %v1087, 0
  %cv1089 = zext i1 %cmp1088 to i32
  store i32 %cv1089, ptr %slot195, align 8
  %v1090 = load i32, ptr %slot195, align 8
  %cv1091 = zext i32 %v1090 to i64
  %cond1092 = icmp ne i64 %cv1091, 0
  br i1 %cond1092, label %bb_rcmoveheader252, label %bb_rcmovenext252
bb_rcmoveheader252:
  %v1093 = load i64, ptr %slot194, align 8
  %op1094 = sub i64 %v1093, 16
  store i64 %op1094, ptr %slot196, align 8
  %v1095 = load i64, ptr %slot194, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %rgep1097 = getelementptr i8, ptr %p1096, i64 -16
  %ld1098 = load i64, ptr %rgep1097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1098, ptr %slot197, align 8
  %v1099 = load i64, ptr %slot197, align 8
  %op1100 = and i64 %v1099, 5764607523034234881
  store i64 %op1100, ptr %slot198, align 8
  %v1101 = load i64, ptr %slot198, align 8
  %cmp1102 = icmp ne i64 %v1101, 0
  %cv1103 = zext i1 %cmp1102 to i32
  store i32 %cv1103, ptr %slot199, align 8
  %v1104 = load i32, ptr %slot199, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcmoveslow249, label %bb_rcmovenext252
bb_rcmovenext252:
  %v1107 = load i64, ptr %slot190, align 8
  %v1108 = load i64, ptr %slot191, align 8
  %p1109 = inttoptr i64 %v1107 to ptr
  %p1110 = inttoptr i64 %v1108 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1110, ptr %p1109, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1111 = load i64, ptr %slot190, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i64 0, ptr %p1112, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved249
bb_rcmoveslow249:
  %v1113 = load i64, ptr %slot25, align 8
  %v1114 = load i64, ptr %slot191, align 8
  %v1115 = load i64, ptr %slot190, align 8
  %v1116 = load i64, ptr %slot192, align 8
  %cv1117 = trunc i64 %v1116 to i32
  %call1118 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v1113, i64 %v1114, i64 %v1115, i32 %cv1117) nomerge, !dbg !124
  store i32 %call1118, ptr %slot200, align 8
  %v1119 = load i32, ptr %slot200, align 8
  %cv1120 = zext i32 %v1119 to i64
  %cond1121 = icmp ne i64 %cv1120, 0
  br i1 %cond1121, label %bb_rcsuccess259, label %bb_rcfailure259
bb_rcfailure259:
  %v1122 = load i64, ptr %slot25, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  %call1124 = call i32 @myl_rc_take_failure(ptr %p1123) nomerge, !dbg !124
  store i32 %call1124, ptr %slot201, align 8
  %v1125 = load i64, ptr %slot1, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  %v1127 = load i32, ptr %slot201, align 8
  %call1128 = call i32 @myl_qbe_rc_status(ptr %p1126, i32 %v1127) nomerge, !dbg !124
  store i32 %call1128, ptr %slot202, align 8
  br label %bb_failure
bb_rcsuccess259:
  br label %bb_rcmoved249
bb_rcmoved249:
  %v1129 = load i64, ptr %slot5, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  store i32 0, ptr %p1130, align 4, !alias.scope !3, !noalias !4
  %v1131 = load i64, ptr %slot8, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  store i32 2, ptr %p1132, align 4, !alias.scope !3, !noalias !4
  %v1133 = load i64, ptr %slot7, align 8
  %p1134 = inttoptr i64 %v1133 to ptr
  store i32 1, ptr %p1134, align 4, !alias.scope !3, !noalias !4
  %v1135 = load i64, ptr %slot12, align 8
  store i64 %v1135, ptr %slot203, align 8
  %v1136 = load i64, ptr %slot203, align 8
  %v1137 = load i64, ptr %slot187, align 8
  %p1138 = inttoptr i64 %v1136 to ptr
  %p1139 = inttoptr i64 %v1137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1139, ptr %p1138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot7, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 0, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot183, align 8
  %v1143 = load i64, ptr %slot17, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 %v1142, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %p1145 = inttoptr i64 ptrtoint (ptr @myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p1145, i64 22) "call-inline-cost"="0", !dbg !124
  %v1146 = load i64, ptr %slot17, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1148, ptr %slot204, align 8
  %v1149 = load i64, ptr %slot10, align 8
  store i64 %v1149, ptr %slot205, align 8
  %v1150 = load i64, ptr %slot204, align 8
  %v1151 = load i64, ptr %slot205, align 8
  %p1152 = inttoptr i64 %v1150 to ptr
  %p1153 = inttoptr i64 %v1151 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1153, ptr %p1152, i64 16, i1 false)
  %v1154 = load i64, ptr %slot6, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i32 2, ptr %p1155, align 4, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot5, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i32 1, ptr %p1157, align 4, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot205, align 8
  %v1159 = load i64, ptr %slot17, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  store i64 %v1158, ptr %p1160, align 8, !alias.scope !3, !noalias !4
  %v1161 = load i64, ptr %slot17, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %ld1163 = load i64, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1163, ptr %slot206, align 8
  %v1164 = load i64, ptr %slot17, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %ld1166 = load i64, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1166, ptr %slot207, align 8
  %v1167 = load i64, ptr %slot12, align 8
  store i64 %v1167, ptr %slot208, align 8
  %v1168 = load i64, ptr %slot26, align 8
  store i64 %v1168, ptr %slot209, align 8
  %v1169 = load i64, ptr %slot25, align 8
  %v1170 = load i64, ptr %slot208, align 8
  %v1171 = load i64, ptr %slot207, align 8
  %v1172 = load i64, ptr %slot209, align 8
  %cv1173 = trunc i64 %v1172 to i32
  %call1174 = call i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64 %v1169, i64 %v1170, i64 %v1171, i32 %cv1173) nomerge, !dbg !126
  store i32 %call1174, ptr %slot210, align 8
  %v1175 = load i32, ptr %slot210, align 8
  %cv1176 = zext i32 %v1175 to i64
  %cond1177 = icmp ne i64 %cv1176, 0
  br i1 %cond1177, label %bb_rcsuccess276, label %bb_rcfailure276
bb_rcfailure276:
  %v1178 = load i64, ptr %slot25, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %call1180 = call i32 @myl_rc_take_failure(ptr %p1179) nomerge, !dbg !126
  store i32 %call1180, ptr %slot211, align 8
  %v1181 = load i64, ptr %slot1, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %v1183 = load i32, ptr %slot211, align 8
  %call1184 = call i32 @myl_qbe_rc_status(ptr %p1182, i32 %v1183) nomerge, !dbg !126
  store i32 %call1184, ptr %slot212, align 8
  br label %bb_failure
bb_rcsuccess276:
  %v1185 = load i64, ptr %slot5, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i32 0, ptr %p1186, align 4, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot8, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i32 2, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot7, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  store i32 1, ptr %p1190, align 4, !alias.scope !3, !noalias !4
  %v1191 = load i64, ptr %slot12, align 8
  store i64 %v1191, ptr %slot213, align 8
  %v1192 = load i64, ptr %slot7, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  store i32 0, ptr %p1193, align 4, !alias.scope !3, !noalias !4
  %v1194 = load i64, ptr %slot5, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  %ld1196 = load i32, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1196, ptr %slot214, align 8
  %v1197 = load i32, ptr %slot214, align 8
  %cv1198 = zext i32 %v1197 to i64
  %cond1199 = icmp ne i64 %cv1198, 0
  br i1 %cond1199, label %bb_rcslotdrop286, label %bb_rcslotdone286
bb_rcslotdrop286:
  %v1200 = load i64, ptr %slot5, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i32 0, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot10, align 8
  store i64 %v1202, ptr %slot215, align 8
  %v1203 = load i64, ptr %slot6, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  %ld1205 = load i32, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1205, ptr %slot216, align 8
  %v1206 = load i32, ptr %slot216, align 8
  %op1207 = and i32 %v1206, 28
  store i32 %op1207, ptr %slot217, align 8
  %v1208 = load i32, ptr %slot217, align 8
  %cv1209 = zext i32 %v1208 to i64
  %cond1210 = icmp ne i64 %cv1209, 0
  br i1 %cond1210, label %bb_rcslotrole286, label %bb_rcslotowner286
bb_rcslotrole286:
  %v1211 = load i64, ptr %slot25, align 8
  store i64 %v1211, ptr %slot218, align 8
  %v1212 = load i64, ptr %slot218, align 8
  %v1213 = load i64, ptr %slot215, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64 %v1212, i64 %v1213) nomerge, !dbg !126
  br label %bb_rcslotdone286
bb_rcslotowner286:
  %v1214 = load i64, ptr %slot25, align 8
  store i64 %v1214, ptr %slot219, align 8
  %v1215 = load i64, ptr %slot219, align 8
  %v1216 = load i64, ptr %slot215, align 8
  call void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64 %v1215, i64 %v1216) nomerge, !dbg !126
  br label %bb_rcslotdone286
bb_rcslotdone286:
  %v1217 = load i64, ptr %slot213, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ret1219 = load { i64, i64 }, ptr %p1218, align 8
  ret { i64, i64 } %ret1219
bb_failure:
  %v1220 = load i64, ptr %slot4, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  call void @llvm.memset.p0.i64(ptr %p1221, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v1222 = load i64, ptr %slot4, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ret1224 = load { i64, i64 }, ptr %p1223, align 8
  ret { i64, i64 } %ret1224
bb_entry_failure:
  %v1225 = load i64, ptr %slot4, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  call void @llvm.memset.p0.i64(ptr %p1226, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v1227 = load i64, ptr %slot4, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %ret1229 = load { i64, i64 }, ptr %p1228, align 8
  ret { i64, i64 } %ret1229
}

@myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c_meta = external global i8, align 8
@myl_lit_1b60d1144300d5255a2a0f70e48320fe88a6202cef2ca80b540c41a74305a317 = external global i8, align 8
@myl_lit_2a783d763ead5d0f06471f24d9bb44896b740005391a4afafe5eae5ecc885e6e = external global i8, align 8
@myl_lit_c1ecc0853024398f95c525fbabe622e97660f71635b139ca4c636117149e7330 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare i32 @myl_qbe_external_read(ptr, i64, i32, ptr)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_drop(i64, i64)
declare i32 @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_70a89a4e0f14e03d324e6919ff41f721a02a9986ebc4d1588ab8187f522d7c0c_rcg_unloan(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c", linkageName: "myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8337361381463826324, i64 0, !"myl_f_c449210f175fb01d9aa5b2c4bbaeef8651e2558023cf9937c77694c03310441c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!114 = !DILocation(line: 7, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!116 = !DILocation(line: 13, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!118 = !DILocation(line: 14, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!120 = !DILocation(line: 20, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!122 = !DILocation(line: 21, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!124 = !DILocation(line: 23, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!126 = !DILocation(line: 24, column: 0, scope: !127)
