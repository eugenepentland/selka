target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i32, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i32, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i32, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i32, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i32, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1072 = load i64, ptr %slot1, align 8
  %op1073 = add i64 %v1072, 32
  store i64 %op1073, ptr %slot4, align 8
  %mem1074 = alloca i8, i64 8, align 8
  %ptr1075 = ptrtoint ptr %mem1074 to i64
  store i64 %ptr1075, ptr %slot5, align 8
  %mem1076 = alloca i8, i64 8, align 8
  %ptr1077 = ptrtoint ptr %mem1076 to i64
  store i64 %ptr1077, ptr %slot6, align 8
  %mem1078 = alloca i8, i64 8, align 8
  %ptr1079 = ptrtoint ptr %mem1078 to i64
  store i64 %ptr1079, ptr %slot7, align 8
  %mem1080 = alloca i8, i64 8, align 8
  %ptr1081 = ptrtoint ptr %mem1080 to i64
  store i64 %ptr1081, ptr %slot8, align 8
  %mem1082 = alloca i8, i64 8, align 8
  %ptr1083 = ptrtoint ptr %mem1082 to i64
  store i64 %ptr1083, ptr %slot9, align 8
  %mem1084 = alloca i8, i64 8, align 8
  %ptr1085 = ptrtoint ptr %mem1084 to i64
  store i64 %ptr1085, ptr %slot10, align 8
  %mem1086 = alloca i8, i64 8, align 8
  %ptr1087 = ptrtoint ptr %mem1086 to i64
  store i64 %ptr1087, ptr %slot11, align 8
  %mem1088 = alloca i8, i64 8, align 8
  %ptr1089 = ptrtoint ptr %mem1088 to i64
  store i64 %ptr1089, ptr %slot12, align 8
  %mem1090 = alloca i8, i64 8, align 8
  %ptr1091 = ptrtoint ptr %mem1090 to i64
  store i64 %ptr1091, ptr %slot13, align 8
  %mem1092 = alloca i8, i64 8, align 8
  %ptr1093 = ptrtoint ptr %mem1092 to i64
  store i64 %ptr1093, ptr %slot14, align 8
  %mem1094 = alloca i8, i64 40, align 8
  %ptr1095 = ptrtoint ptr %mem1094 to i64
  store i64 %ptr1095, ptr %slot15, align 8
  %mem1096 = alloca i8, i64 8, align 8
  %ptr1097 = ptrtoint ptr %mem1096 to i64
  store i64 %ptr1097, ptr %slot16, align 8
  %mem1098 = alloca i8, i64 40, align 8
  %ptr1099 = ptrtoint ptr %mem1098 to i64
  store i64 %ptr1099, ptr %slot17, align 8
  %mem1100 = alloca i8, i64 32, align 8
  %ptr1101 = ptrtoint ptr %mem1100 to i64
  store i64 %ptr1101, ptr %slot18, align 8
  %v1102 = load i64, ptr %slot18, align 8
  %p1104 = inttoptr i64 %v1102 to ptr
  %gep1105 = getelementptr i8, ptr %p1104, i64 24
  %op1103 = ptrtoint ptr %gep1105 to i64
  store i64 %op1103, ptr %slot19, align 8
  %v1106 = load i64, ptr %slot19, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  store i64 0, ptr %p1107, align 8, !alias.scope !3, !noalias !4
  %mem1108 = alloca i8, i64 32, align 8
  %ptr1109 = ptrtoint ptr %mem1108 to i64
  store i64 %ptr1109, ptr %slot20, align 8
  %v1110 = load i64, ptr %slot20, align 8
  %p1112 = inttoptr i64 %v1110 to ptr
  %gep1113 = getelementptr i8, ptr %p1112, i64 24
  %op1111 = ptrtoint ptr %gep1113 to i64
  store i64 %op1111, ptr %slot21, align 8
  %v1114 = load i64, ptr %slot21, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i64 0, ptr %p1115, align 8, !alias.scope !3, !noalias !4
  %mem1116 = alloca i8, i64 16, align 8
  %ptr1117 = ptrtoint ptr %mem1116 to i64
  store i64 %ptr1117, ptr %slot22, align 8
  %mem1118 = alloca i8, i64 8, align 8
  %ptr1119 = ptrtoint ptr %mem1118 to i64
  store i64 %ptr1119, ptr %slot23, align 8
  %mem1120 = alloca i8, i64 8, align 8
  %ptr1121 = ptrtoint ptr %mem1120 to i64
  store i64 %ptr1121, ptr %slot24, align 8
  %mem1122 = alloca i8, i64 8, align 8
  %ptr1123 = ptrtoint ptr %mem1122 to i64
  store i64 %ptr1123, ptr %slot25, align 8
  %mem1124 = alloca i8, i64 8, align 8
  %ptr1125 = ptrtoint ptr %mem1124 to i64
  store i64 %ptr1125, ptr %slot26, align 8
  %mem1126 = alloca i8, i64 8, align 8
  %ptr1127 = ptrtoint ptr %mem1126 to i64
  store i64 %ptr1127, ptr %slot27, align 8
  %mem1128 = alloca i8, i64 8, align 8
  %ptr1129 = ptrtoint ptr %mem1128 to i64
  store i64 %ptr1129, ptr %slot28, align 8
  %mem1130 = alloca i8, i64 8, align 8
  %ptr1131 = ptrtoint ptr %mem1130 to i64
  store i64 %ptr1131, ptr %slot29, align 8
  %mem1132 = alloca i8, i64 8, align 8
  %ptr1133 = ptrtoint ptr %mem1132 to i64
  store i64 %ptr1133, ptr %slot30, align 8
  %mem1134 = alloca i8, i64 8, align 8
  %ptr1135 = ptrtoint ptr %mem1134 to i64
  store i64 %ptr1135, ptr %slot31, align 8
  %mem1136 = alloca i8, i64 8, align 8
  %ptr1137 = ptrtoint ptr %mem1136 to i64
  store i64 %ptr1137, ptr %slot32, align 8
  %mem1138 = alloca i8, i64 8, align 8
  %ptr1139 = ptrtoint ptr %mem1138 to i64
  store i64 %ptr1139, ptr %slot33, align 8
  %v1140 = load i64, ptr %slot25, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 0, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot26, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i64 0, ptr %p1143, align 8, !alias.scope !3, !noalias !4
  %v1144 = load i64, ptr %slot27, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i64 0, ptr %p1145, align 8, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot28, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i64 0, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot29, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i64 0, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot2, align 8
  %v1151 = load i64, ptr %slot23, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  store i64 %v1150, ptr %p1152, align 8, !alias.scope !3, !noalias !4
  %v1153 = load i64, ptr %slot3, align 8
  %v1154 = load i64, ptr %slot24, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i64 %v1153, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot1, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  %call1158 = call ptr @myl_qbe_heap(ptr %p1157) nomerge, !dbg !110
  %calladdr1159 = ptrtoint ptr %call1158 to i64
  store i64 %calladdr1159, ptr %slot34, align 8
  %v1160 = load i64, ptr %slot1, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  %call1162 = call i64 @myl_qbe_region_mark(ptr %p1161) nomerge, !dbg !110
  store i64 %call1162, ptr %slot35, align 8
  %v1163 = load i64, ptr %slot5, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i32 0, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot6, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i32 0, ptr %p1166, align 4, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot7, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i32 0, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot8, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 0, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot9, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  store i32 0, ptr %p1172, align 4, !alias.scope !3, !noalias !4
  %v1173 = load i64, ptr %slot10, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i32 0, ptr %p1174, align 4, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot11, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i32 0, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot12, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  store i32 0, ptr %p1178, align 4, !alias.scope !3, !noalias !4
  %v1179 = load i64, ptr %slot13, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i32 0, ptr %p1180, align 4, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot14, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i32 0, ptr %p1182, align 4, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot6, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  store i32 2, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot8, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i32 2, ptr %p1186, align 4, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot10, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i32 2, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1189 = load i64, ptr %slot23, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i64, ptr %p1190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1191, ptr %slot36, align 8
  %v1192 = load i64, ptr %slot36, align 8
  %v1193 = load i64, ptr %slot31, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i64 %v1192, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot31, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i64, ptr %p1196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1197, ptr %slot37, align 8
  %v1198 = load i64, ptr %slot37, align 8
  %op1199 = add i64 %v1198, 32
  store i64 %op1199, ptr %slot38, align 8
  %v1200 = load i64, ptr %slot38, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %ld1202 = load i8, ptr %p1201, align 1, !alias.scope !4, !noalias !3
  %ext1203 = zext i8 %ld1202 to i64
  store i64 %ext1203, ptr %slot39, align 8
  %v1204 = load i64, ptr %slot39, align 8
  %v1205 = load i64, ptr %slot31, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i64 %v1204, ptr %p1206, align 8, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot11, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  %ld1209 = load i32, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1209, ptr %slot40, align 8
  %v1210 = load i32, ptr %slot40, align 8
  %cv1211 = zext i32 %v1210 to i64
  %cond1212 = icmp ne i64 %cv1211, 0
  br i1 %cond1212, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v1213 = load i64, ptr %slot11, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  store i32 0, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  %v1215 = load i64, ptr %slot15, align 8
  store i64 %v1215, ptr %slot41, align 8
  %v1216 = load i64, ptr %slot12, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  %ld1218 = load i32, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1218, ptr %slot42, align 8
  %v1219 = load i32, ptr %slot42, align 8
  %op1220 = and i32 %v1219, 28
  store i32 %op1220, ptr %slot43, align 8
  %v1221 = load i32, ptr %slot43, align 8
  %cv1222 = zext i32 %v1221 to i64
  %cond1223 = icmp ne i64 %cv1222, 0
  br i1 %cond1223, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v1224 = load i64, ptr %slot34, align 8
  store i64 %v1224, ptr %slot44, align 8
  %v1225 = load i64, ptr %slot44, align 8
  %v1226 = load i64, ptr %slot41, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1225, i64 %v1226) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v1227 = load i64, ptr %slot34, align 8
  store i64 %v1227, ptr %slot45, align 8
  %v1228 = load i64, ptr %slot45, align 8
  %v1229 = load i64, ptr %slot41, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1228, i64 %v1229) nomerge, !dbg !112
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v1230 = load i64, ptr %slot31, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %ld1232 = load i64, ptr %p1231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1232, ptr %slot46, align 8
  %v1233 = load i64, ptr %slot46, align 8
  %cond1234 = icmp ne i64 %v1233, 0
  br i1 %cond1234, label %bb_next23, label %bb_i20
bb_next23:
  %v1235 = load i64, ptr %slot23, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i64, ptr %p1236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1237, ptr %slot47, align 8
  %v1238 = load i64, ptr %slot47, align 8
  %v1239 = load i64, ptr %slot31, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i64 %v1238, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot31, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i64, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1243, ptr %slot48, align 8
  %v1244 = load i64, ptr %slot48, align 8
  %op1245 = add i64 %v1244, 8
  store i64 %op1245, ptr %slot49, align 8
  %v1246 = load i64, ptr %slot49, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  %ld1248 = load i64, ptr %p1247, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1248, ptr %slot50, align 8
  %v1249 = load i64, ptr %slot50, align 8
  %v1250 = load i64, ptr %slot31, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i64 %v1249, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot11, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %ld1254 = load i32, ptr %p1253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1254, ptr %slot51, align 8
  %v1255 = load i32, ptr %slot51, align 8
  %cv1256 = zext i32 %v1255 to i64
  %cond1257 = icmp ne i64 %cv1256, 0
  br i1 %cond1257, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v1258 = load i64, ptr %slot11, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  store i32 0, ptr %p1259, align 4, !alias.scope !3, !noalias !4
  %v1260 = load i64, ptr %slot15, align 8
  store i64 %v1260, ptr %slot52, align 8
  %v1261 = load i64, ptr %slot12, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %ld1263 = load i32, ptr %p1262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1263, ptr %slot53, align 8
  %v1264 = load i32, ptr %slot53, align 8
  %op1265 = and i32 %v1264, 28
  store i32 %op1265, ptr %slot54, align 8
  %v1266 = load i32, ptr %slot54, align 8
  %cv1267 = zext i32 %v1266 to i64
  %cond1268 = icmp ne i64 %cv1267, 0
  br i1 %cond1268, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v1269 = load i64, ptr %slot34, align 8
  store i64 %v1269, ptr %slot55, align 8
  %v1270 = load i64, ptr %slot55, align 8
  %v1271 = load i64, ptr %slot52, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1270, i64 %v1271) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v1272 = load i64, ptr %slot34, align 8
  store i64 %v1272, ptr %slot56, align 8
  %v1273 = load i64, ptr %slot56, align 8
  %v1274 = load i64, ptr %slot52, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1273, i64 %v1274) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v1275 = load i64, ptr %slot31, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i64, ptr %p1276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1277, ptr %slot57, align 8
  %v1278 = load i64, ptr %slot23, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i64, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1280, ptr %slot58, align 8
  %v1281 = load i64, ptr %slot11, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i32, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1283, ptr %slot59, align 8
  %v1284 = load i32, ptr %slot59, align 8
  %cv1285 = zext i32 %v1284 to i64
  %cond1286 = icmp ne i64 %cv1285, 0
  br i1 %cond1286, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v1287 = load i64, ptr %slot11, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 0, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot15, align 8
  store i64 %v1289, ptr %slot60, align 8
  %v1290 = load i64, ptr %slot12, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  %ld1292 = load i32, ptr %p1291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1292, ptr %slot61, align 8
  %v1293 = load i32, ptr %slot61, align 8
  %op1294 = and i32 %v1293, 28
  store i32 %op1294, ptr %slot62, align 8
  %v1295 = load i32, ptr %slot62, align 8
  %cv1296 = zext i32 %v1295 to i64
  %cond1297 = icmp ne i64 %cv1296, 0
  br i1 %cond1297, label %bb_rcslotrole41, label %bb_rcslotowner41
bb_rcslotrole41:
  %v1298 = load i64, ptr %slot34, align 8
  store i64 %v1298, ptr %slot63, align 8
  %v1299 = load i64, ptr %slot60, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  %ld1301 = load i64, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1301, ptr %slot64, align 8
  %v1302 = load i64, ptr %slot64, align 8
  %cmp1303 = icmp ne i64 %v1302, 0
  %cv1304 = zext i1 %cmp1303 to i32
  store i32 %cv1304, ptr %slot65, align 8
  %v1305 = load i32, ptr %slot65, align 8
  %cv1306 = zext i32 %v1305 to i64
  %cond1307 = icmp ne i64 %cv1306, 0
  br i1 %cond1307, label %bb_rcgnn57, label %bb_rcgdone57
bb_rcgnn57:
  %v1308 = load i64, ptr %slot64, align 8
  %op1309 = sub i64 %v1308, 16
  store i64 %op1309, ptr %slot66, align 8
  %v1310 = load i64, ptr %slot64, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  %rgep1312 = getelementptr i8, ptr %p1311, i64 -16
  %ld1313 = load i64, ptr %rgep1312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1313, ptr %slot67, align 8
  %v1314 = load i64, ptr %slot67, align 8
  %op1315 = and i64 %v1314, 4611686018427387906
  store i64 %op1315, ptr %slot68, align 8
  %v1316 = load i64, ptr %slot68, align 8
  %cmp1317 = icmp ne i64 %v1316, 0
  %cv1318 = zext i1 %cmp1317 to i32
  store i32 %cv1318, ptr %slot69, align 8
  %v1319 = load i32, ptr %slot69, align 8
  %cv1320 = zext i32 %v1319 to i64
  %cond1321 = icmp ne i64 %cv1320, 0
  br i1 %cond1321, label %bb_rcgclear57, label %bb_rcgcounted57
bb_rcgcounted57:
  %v1322 = load i64, ptr %slot64, align 8
  %op1323 = sub i64 %v1322, 24
  store i64 %op1323, ptr %slot70, align 8
  %v1324 = load i64, ptr %slot64, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %rgep1326 = getelementptr i8, ptr %p1325, i64 -24
  %ld1327 = load i64, ptr %rgep1326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1327, ptr %slot71, align 8
  %v1328 = load i64, ptr %slot71, align 8
  %op1329 = sub i64 %v1328, 1
  store i64 %op1329, ptr %slot72, align 8
  %v1330 = load i64, ptr %slot72, align 8
  %cmp1331 = icmp eq i64 %v1330, 0
  %cv1332 = zext i1 %cmp1331 to i32
  store i32 %cv1332, ptr %slot73, align 8
  %v1333 = load i32, ptr %slot73, align 8
  %cv1334 = zext i32 %v1333 to i64
  %cond1335 = icmp ne i64 %cv1334, 0
  br i1 %cond1335, label %bb_rcglast57, label %bb_rcgdec57
bb_rcglast57:
  %v1336 = load i64, ptr %slot64, align 8
  %op1337 = sub i64 %v1336, 32
  store i64 %op1337, ptr %slot74, align 8
  %v1338 = load i64, ptr %slot64, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %rgep1340 = getelementptr i8, ptr %p1339, i64 -32
  %ld1341 = load i64, ptr %rgep1340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1341, ptr %slot75, align 8
  %v1342 = load i64, ptr %slot75, align 8
  %cmp1343 = icmp ne i64 %v1342, 0
  %cv1344 = zext i1 %cmp1343 to i32
  store i32 %cv1344, ptr %slot76, align 8
  %v1345 = load i32, ptr %slot76, align 8
  %cv1346 = zext i32 %v1345 to i64
  %cond1347 = icmp ne i64 %cv1346, 0
  br i1 %cond1347, label %bb_rcgdec57, label %bb_rcgslow57
bb_rcgslow57:
  %v1348 = load i64, ptr %slot63, align 8
  %v1349 = load i64, ptr %slot60, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1348, i64 %v1349) nomerge, !dbg !116
  br label %bb_rcgdone57
bb_rcgdec57:
  %v1350 = load i64, ptr %slot72, align 8
  %v1351 = load i64, ptr %slot64, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  %rgep1353 = getelementptr i8, ptr %p1352, i64 -24
  store i64 %v1350, ptr %rgep1353, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear57
bb_rcgclear57:
  %v1354 = load i64, ptr %slot60, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  store i64 0, ptr %p1355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone57
bb_rcgdone57:
  br label %bb_rcslotdone41
bb_rcslotowner41:
  %v1356 = load i64, ptr %slot34, align 8
  store i64 %v1356, ptr %slot77, align 8
  %v1357 = load i64, ptr %slot60, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  %ld1359 = load i64, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1359, ptr %slot78, align 8
  %v1360 = load i64, ptr %slot78, align 8
  %cmp1361 = icmp ne i64 %v1360, 0
  %cv1362 = zext i1 %cmp1361 to i32
  store i32 %cv1362, ptr %slot79, align 8
  %v1363 = load i32, ptr %slot79, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcgnn72, label %bb_rcgdone72
bb_rcgnn72:
  %v1366 = load i64, ptr %slot78, align 8
  %op1367 = sub i64 %v1366, 16
  store i64 %op1367, ptr %slot80, align 8
  %v1368 = load i64, ptr %slot78, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %rgep1370 = getelementptr i8, ptr %p1369, i64 -16
  %ld1371 = load i64, ptr %rgep1370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1371, ptr %slot81, align 8
  %v1372 = load i64, ptr %slot81, align 8
  %op1373 = and i64 %v1372, 4611686018427387906
  store i64 %op1373, ptr %slot82, align 8
  %v1374 = load i64, ptr %slot82, align 8
  %cmp1375 = icmp ne i64 %v1374, 0
  %cv1376 = zext i1 %cmp1375 to i32
  store i32 %cv1376, ptr %slot83, align 8
  %v1377 = load i32, ptr %slot83, align 8
  %cv1378 = zext i32 %v1377 to i64
  %cond1379 = icmp ne i64 %cv1378, 0
  br i1 %cond1379, label %bb_rcgclear72, label %bb_rcgcounted72
bb_rcgcounted72:
  %v1380 = load i64, ptr %slot78, align 8
  %op1381 = sub i64 %v1380, 32
  store i64 %op1381, ptr %slot84, align 8
  %v1382 = load i64, ptr %slot78, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %rgep1384 = getelementptr i8, ptr %p1383, i64 -32
  %ld1385 = load i64, ptr %rgep1384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1385, ptr %slot85, align 8
  %v1386 = load i64, ptr %slot85, align 8
  %op1387 = sub i64 %v1386, 1
  store i64 %op1387, ptr %slot86, align 8
  %v1388 = load i64, ptr %slot86, align 8
  %cmp1389 = icmp eq i64 %v1388, 0
  %cv1390 = zext i1 %cmp1389 to i32
  store i32 %cv1390, ptr %slot87, align 8
  %v1391 = load i32, ptr %slot87, align 8
  %cv1392 = zext i32 %v1391 to i64
  %cond1393 = icmp ne i64 %cv1392, 0
  br i1 %cond1393, label %bb_rcglast72, label %bb_rcgdec72
bb_rcglast72:
  %v1394 = load i64, ptr %slot78, align 8
  %op1395 = sub i64 %v1394, 24
  store i64 %op1395, ptr %slot88, align 8
  %v1396 = load i64, ptr %slot78, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  %rgep1398 = getelementptr i8, ptr %p1397, i64 -24
  %ld1399 = load i64, ptr %rgep1398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1399, ptr %slot89, align 8
  %v1400 = load i64, ptr %slot89, align 8
  %cmp1401 = icmp ne i64 %v1400, 0
  %cv1402 = zext i1 %cmp1401 to i32
  store i32 %cv1402, ptr %slot90, align 8
  %v1403 = load i32, ptr %slot90, align 8
  %cv1404 = zext i32 %v1403 to i64
  %cond1405 = icmp ne i64 %cv1404, 0
  br i1 %cond1405, label %bb_rcgdec72, label %bb_rcgslow72
bb_rcgslow72:
  %v1406 = load i64, ptr %slot77, align 8
  %v1407 = load i64, ptr %slot60, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1406, i64 %v1407) nomerge, !dbg !116
  br label %bb_rcgdone72
bb_rcgdec72:
  %v1408 = load i64, ptr %slot86, align 8
  %v1409 = load i64, ptr %slot78, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %rgep1411 = getelementptr i8, ptr %p1410, i64 -32
  store i64 %v1408, ptr %rgep1411, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear72
bb_rcgclear72:
  %v1412 = load i64, ptr %slot60, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i64 0, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone72
bb_rcgdone72:
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v1414 = load i64, ptr %slot58, align 8
  %op1415 = add i64 %v1414, 8
  store i64 %op1415, ptr %slot91, align 8
  store i64 0, ptr %slot92, align 8
  %v1416 = load i64, ptr %slot91, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  %ld1418 = load i64, ptr %p1417, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1418, ptr %slot93, align 8
  %v1419 = load i64, ptr %slot93, align 8
  %cmp1420 = icmp ne i64 %v1419, 0
  %cv1421 = zext i1 %cmp1420 to i32
  store i32 %cv1421, ptr %slot94, align 8
  %v1422 = load i32, ptr %slot94, align 8
  %cv1423 = zext i32 %v1422 to i64
  %cond1424 = icmp ne i64 %cv1423, 0
  br i1 %cond1424, label %bb_rcguniquenn78, label %bb_rcgunique78
bb_rcguniquenn78:
  %v1425 = load i64, ptr %slot93, align 8
  %op1426 = sub i64 %v1425, 16
  store i64 %op1426, ptr %slot95, align 8
  %v1427 = load i64, ptr %slot93, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %rgep1429 = getelementptr i8, ptr %p1428, i64 -16
  %ld1430 = load i64, ptr %rgep1429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1430, ptr %slot96, align 8
  %v1431 = load i64, ptr %slot96, align 8
  %op1432 = and i64 %v1431, 6917529027641081858
  store i64 %op1432, ptr %slot97, align 8
  %v1433 = load i64, ptr %slot97, align 8
  %cmp1434 = icmp ne i64 %v1433, 0
  %cv1435 = zext i1 %cmp1434 to i32
  store i32 %cv1435, ptr %slot98, align 8
  %v1436 = load i32, ptr %slot98, align 8
  %cv1437 = zext i32 %v1436 to i64
  %cond1438 = icmp ne i64 %cv1437, 0
  br i1 %cond1438, label %bb_rcguniqueslow78, label %bb_rcguniquecount78
bb_rcguniquecount78:
  %v1439 = load i64, ptr %slot93, align 8
  %op1440 = sub i64 %v1439, 32
  store i64 %op1440, ptr %slot99, align 8
  %v1441 = load i64, ptr %slot93, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  %rgep1443 = getelementptr i8, ptr %p1442, i64 -32
  %ld1444 = load i64, ptr %rgep1443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1444, ptr %slot100, align 8
  %v1445 = load i64, ptr %slot100, align 8
  %cmp1446 = icmp ult i64 %v1445, 2
  %cv1447 = zext i1 %cmp1446 to i32
  store i32 %cv1447, ptr %slot101, align 8
  %v1448 = load i32, ptr %slot101, align 8
  %cv1449 = zext i32 %v1448 to i64
  %cond1450 = icmp ne i64 %cv1449, 0
  br i1 %cond1450, label %bb_rcgunique78, label %bb_rcguniqueslow78
bb_rcguniqueslow78:
  %v1451 = load i64, ptr %slot1, align 8
  %p1452 = inttoptr i64 %v1451 to ptr
  %p1453 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v1454 = load i64, ptr %slot91, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %v1456 = load i64, ptr %slot92, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %call1458 = call i32 @myl_qbe_rc_unique_field(ptr %p1452, ptr %p1453, ptr %p1455, ptr %p1457) nomerge, !dbg !116
  store i32 %call1458, ptr %slot102, align 8
  %v1459 = load i32, ptr %slot102, align 8
  %cv1460 = zext i32 %v1459 to i64
  %cond1461 = icmp ne i64 %cv1460, 0
  br i1 %cond1461, label %bb_rcunique88, label %bb_failure
bb_rcunique88:
  br label %bb_rcgunique78
bb_rcgunique78:
  %v1462 = load i64, ptr %slot91, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1464, ptr %slot103, align 8
  %v1465 = load i64, ptr %slot103, align 8
  %v1466 = load i64, ptr %slot31, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  store i64 %v1465, ptr %p1467, align 8, !alias.scope !3, !noalias !4
  %v1468 = load i64, ptr %slot31, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %ld1470 = load i64, ptr %p1469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1470, ptr %slot104, align 8
  %v1471 = load i64, ptr %slot11, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  %ld1473 = load i32, ptr %p1472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1473, ptr %slot105, align 8
  %v1474 = load i32, ptr %slot105, align 8
  %cv1475 = zext i32 %v1474 to i64
  %cond1476 = icmp ne i64 %cv1475, 0
  br i1 %cond1476, label %bb_rcslotdrop93, label %bb_rcslotdone93
bb_rcslotdrop93:
  %v1477 = load i64, ptr %slot11, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i32 0, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot15, align 8
  store i64 %v1479, ptr %slot106, align 8
  %v1480 = load i64, ptr %slot12, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  %ld1482 = load i32, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1482, ptr %slot107, align 8
  %v1483 = load i32, ptr %slot107, align 8
  %op1484 = and i32 %v1483, 28
  store i32 %op1484, ptr %slot108, align 8
  %v1485 = load i32, ptr %slot108, align 8
  %cv1486 = zext i32 %v1485 to i64
  %cond1487 = icmp ne i64 %cv1486, 0
  br i1 %cond1487, label %bb_rcslotrole93, label %bb_rcslotowner93
bb_rcslotrole93:
  %v1488 = load i64, ptr %slot34, align 8
  store i64 %v1488, ptr %slot109, align 8
  %v1489 = load i64, ptr %slot106, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  %ld1491 = load i64, ptr %p1490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1491, ptr %slot110, align 8
  %v1492 = load i64, ptr %slot110, align 8
  %cmp1493 = icmp ne i64 %v1492, 0
  %cv1494 = zext i1 %cmp1493 to i32
  store i32 %cv1494, ptr %slot111, align 8
  %v1495 = load i32, ptr %slot111, align 8
  %cv1496 = zext i32 %v1495 to i64
  %cond1497 = icmp ne i64 %cv1496, 0
  br i1 %cond1497, label %bb_rcgnn109, label %bb_rcgdone109
bb_rcgnn109:
  %v1498 = load i64, ptr %slot110, align 8
  %op1499 = sub i64 %v1498, 16
  store i64 %op1499, ptr %slot112, align 8
  %v1500 = load i64, ptr %slot110, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %rgep1502 = getelementptr i8, ptr %p1501, i64 -16
  %ld1503 = load i64, ptr %rgep1502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1503, ptr %slot113, align 8
  %v1504 = load i64, ptr %slot113, align 8
  %op1505 = and i64 %v1504, 4611686018427387906
  store i64 %op1505, ptr %slot114, align 8
  %v1506 = load i64, ptr %slot114, align 8
  %cmp1507 = icmp ne i64 %v1506, 0
  %cv1508 = zext i1 %cmp1507 to i32
  store i32 %cv1508, ptr %slot115, align 8
  %v1509 = load i32, ptr %slot115, align 8
  %cv1510 = zext i32 %v1509 to i64
  %cond1511 = icmp ne i64 %cv1510, 0
  br i1 %cond1511, label %bb_rcgclear109, label %bb_rcgcounted109
bb_rcgcounted109:
  %v1512 = load i64, ptr %slot110, align 8
  %op1513 = sub i64 %v1512, 24
  store i64 %op1513, ptr %slot116, align 8
  %v1514 = load i64, ptr %slot110, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %rgep1516 = getelementptr i8, ptr %p1515, i64 -24
  %ld1517 = load i64, ptr %rgep1516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1517, ptr %slot117, align 8
  %v1518 = load i64, ptr %slot117, align 8
  %op1519 = sub i64 %v1518, 1
  store i64 %op1519, ptr %slot118, align 8
  %v1520 = load i64, ptr %slot118, align 8
  %cmp1521 = icmp eq i64 %v1520, 0
  %cv1522 = zext i1 %cmp1521 to i32
  store i32 %cv1522, ptr %slot119, align 8
  %v1523 = load i32, ptr %slot119, align 8
  %cv1524 = zext i32 %v1523 to i64
  %cond1525 = icmp ne i64 %cv1524, 0
  br i1 %cond1525, label %bb_rcglast109, label %bb_rcgdec109
bb_rcglast109:
  %v1526 = load i64, ptr %slot110, align 8
  %op1527 = sub i64 %v1526, 32
  store i64 %op1527, ptr %slot120, align 8
  %v1528 = load i64, ptr %slot110, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %rgep1530 = getelementptr i8, ptr %p1529, i64 -32
  %ld1531 = load i64, ptr %rgep1530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1531, ptr %slot121, align 8
  %v1532 = load i64, ptr %slot121, align 8
  %cmp1533 = icmp ne i64 %v1532, 0
  %cv1534 = zext i1 %cmp1533 to i32
  store i32 %cv1534, ptr %slot122, align 8
  %v1535 = load i32, ptr %slot122, align 8
  %cv1536 = zext i32 %v1535 to i64
  %cond1537 = icmp ne i64 %cv1536, 0
  br i1 %cond1537, label %bb_rcgdec109, label %bb_rcgslow109
bb_rcgslow109:
  %v1538 = load i64, ptr %slot109, align 8
  %v1539 = load i64, ptr %slot106, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1538, i64 %v1539) nomerge, !dbg !116
  br label %bb_rcgdone109
bb_rcgdec109:
  %v1540 = load i64, ptr %slot118, align 8
  %v1541 = load i64, ptr %slot110, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  %rgep1543 = getelementptr i8, ptr %p1542, i64 -24
  store i64 %v1540, ptr %rgep1543, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear109
bb_rcgclear109:
  %v1544 = load i64, ptr %slot106, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i64 0, ptr %p1545, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone109
bb_rcgdone109:
  br label %bb_rcslotdone93
bb_rcslotowner93:
  %v1546 = load i64, ptr %slot34, align 8
  store i64 %v1546, ptr %slot123, align 8
  %v1547 = load i64, ptr %slot106, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  %ld1549 = load i64, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1549, ptr %slot124, align 8
  %v1550 = load i64, ptr %slot124, align 8
  %cmp1551 = icmp ne i64 %v1550, 0
  %cv1552 = zext i1 %cmp1551 to i32
  store i32 %cv1552, ptr %slot125, align 8
  %v1553 = load i32, ptr %slot125, align 8
  %cv1554 = zext i32 %v1553 to i64
  %cond1555 = icmp ne i64 %cv1554, 0
  br i1 %cond1555, label %bb_rcgnn124, label %bb_rcgdone124
bb_rcgnn124:
  %v1556 = load i64, ptr %slot124, align 8
  %op1557 = sub i64 %v1556, 16
  store i64 %op1557, ptr %slot126, align 8
  %v1558 = load i64, ptr %slot124, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %rgep1560 = getelementptr i8, ptr %p1559, i64 -16
  %ld1561 = load i64, ptr %rgep1560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1561, ptr %slot127, align 8
  %v1562 = load i64, ptr %slot127, align 8
  %op1563 = and i64 %v1562, 4611686018427387906
  store i64 %op1563, ptr %slot128, align 8
  %v1564 = load i64, ptr %slot128, align 8
  %cmp1565 = icmp ne i64 %v1564, 0
  %cv1566 = zext i1 %cmp1565 to i32
  store i32 %cv1566, ptr %slot129, align 8
  %v1567 = load i32, ptr %slot129, align 8
  %cv1568 = zext i32 %v1567 to i64
  %cond1569 = icmp ne i64 %cv1568, 0
  br i1 %cond1569, label %bb_rcgclear124, label %bb_rcgcounted124
bb_rcgcounted124:
  %v1570 = load i64, ptr %slot124, align 8
  %op1571 = sub i64 %v1570, 32
  store i64 %op1571, ptr %slot130, align 8
  %v1572 = load i64, ptr %slot124, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %rgep1574 = getelementptr i8, ptr %p1573, i64 -32
  %ld1575 = load i64, ptr %rgep1574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1575, ptr %slot131, align 8
  %v1576 = load i64, ptr %slot131, align 8
  %op1577 = sub i64 %v1576, 1
  store i64 %op1577, ptr %slot132, align 8
  %v1578 = load i64, ptr %slot132, align 8
  %cmp1579 = icmp eq i64 %v1578, 0
  %cv1580 = zext i1 %cmp1579 to i32
  store i32 %cv1580, ptr %slot133, align 8
  %v1581 = load i32, ptr %slot133, align 8
  %cv1582 = zext i32 %v1581 to i64
  %cond1583 = icmp ne i64 %cv1582, 0
  br i1 %cond1583, label %bb_rcglast124, label %bb_rcgdec124
bb_rcglast124:
  %v1584 = load i64, ptr %slot124, align 8
  %op1585 = sub i64 %v1584, 24
  store i64 %op1585, ptr %slot134, align 8
  %v1586 = load i64, ptr %slot124, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %rgep1588 = getelementptr i8, ptr %p1587, i64 -24
  %ld1589 = load i64, ptr %rgep1588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1589, ptr %slot135, align 8
  %v1590 = load i64, ptr %slot135, align 8
  %cmp1591 = icmp ne i64 %v1590, 0
  %cv1592 = zext i1 %cmp1591 to i32
  store i32 %cv1592, ptr %slot136, align 8
  %v1593 = load i32, ptr %slot136, align 8
  %cv1594 = zext i32 %v1593 to i64
  %cond1595 = icmp ne i64 %cv1594, 0
  br i1 %cond1595, label %bb_rcgdec124, label %bb_rcgslow124
bb_rcgslow124:
  %v1596 = load i64, ptr %slot123, align 8
  %v1597 = load i64, ptr %slot106, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1596, i64 %v1597) nomerge, !dbg !116
  br label %bb_rcgdone124
bb_rcgdec124:
  %v1598 = load i64, ptr %slot132, align 8
  %v1599 = load i64, ptr %slot124, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  %rgep1601 = getelementptr i8, ptr %p1600, i64 -32
  store i64 %v1598, ptr %rgep1601, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear124
bb_rcgclear124:
  %v1602 = load i64, ptr %slot106, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i64 0, ptr %p1603, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone124
bb_rcgdone124:
  br label %bb_rcslotdone93
bb_rcslotdone93:
  %v1604 = load i64, ptr %slot104, align 8
  %v1605 = load i64, ptr %slot25, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i64 %v1604, ptr %p1606, align 8, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot24, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  %ld1609 = load i64, ptr %p1608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1609, ptr %slot137, align 8
  %v1610 = load i64, ptr %slot137, align 8
  %v1611 = load i64, ptr %slot31, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  store i64 %v1610, ptr %p1612, align 8, !alias.scope !3, !noalias !4
  %v1613 = load i64, ptr %slot32, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 0, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot24, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i64, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1617, ptr %slot138, align 8
  %v1618 = load i64, ptr %slot138, align 8
  %v1619 = load i64, ptr %slot33, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  store i64 %v1618, ptr %p1620, align 8, !alias.scope !3, !noalias !4
  %v1621 = load i64, ptr %slot33, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %ld1623 = load i64, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1623, ptr %slot139, align 8
  %v1624 = load i64, ptr %slot139, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i64, ptr %p1625, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1626, ptr %slot140, align 8
  %v1627 = load i64, ptr %slot140, align 8
  %v1628 = load i64, ptr %slot33, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i64 %v1627, ptr %p1629, align 8, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot25, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  %ld1632 = load i64, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1632, ptr %slot141, align 8
  %v1633 = load i64, ptr %slot31, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %ld1635 = load i64, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1635, ptr %slot142, align 8
  %v1636 = load i64, ptr %slot32, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i64, ptr %p1637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1638, ptr %slot143, align 8
  %v1639 = load i64, ptr %slot33, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  %ld1641 = load i64, ptr %p1640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1641, ptr %slot144, align 8
  %v1642 = load i64, ptr %slot141, align 8
  %op1643 = add i64 %v1642, 8
  store i64 %op1643, ptr %slot145, align 8
  %v1644 = load i64, ptr %slot143, align 8
  %cmp1645 = icmp sge i64 %v1644, 0
  %cv1646 = zext i1 %cmp1645 to i64
  store i64 %cv1646, ptr %slot146, align 8
  %v1647 = load i64, ptr %slot146, align 8
  %cond1648 = icmp ne i64 %v1647, 0
  br i1 %cond1648, label %bb_buf_start211, label %bb_buf_refused211
bb_buf_start211:
  %v1649 = load i64, ptr %slot143, align 8
  %v1650 = load i64, ptr %slot144, align 8
  %cmp1651 = icmp sle i64 %v1649, %v1650
  %cv1652 = zext i1 %cmp1651 to i64
  store i64 %cv1652, ptr %slot147, align 8
  %v1653 = load i64, ptr %slot147, align 8
  %cond1654 = icmp ne i64 %v1653, 0
  br i1 %cond1654, label %bb_buf_order211, label %bb_buf_refused211
bb_buf_order211:
  %v1655 = load i64, ptr %slot142, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %ld1657 = load i64, ptr %p1656, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1657, ptr %slot148, align 8
  %v1658 = load i64, ptr %slot144, align 8
  %v1659 = load i64, ptr %slot148, align 8
  %cmp1660 = icmp ule i64 %v1658, %v1659
  %cv1661 = zext i1 %cmp1660 to i64
  store i64 %cv1661, ptr %slot149, align 8
  %v1662 = load i64, ptr %slot149, align 8
  %cond1663 = icmp ne i64 %v1662, 0
  br i1 %cond1663, label %bb_buf_bound211, label %bb_buf_refused211
bb_buf_bound211:
  %v1664 = load i64, ptr %slot141, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  %ld1666 = load i64, ptr %p1665, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1666, ptr %slot150, align 8
  %v1667 = load i64, ptr %slot145, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %ld1669 = load i64, ptr %p1668, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1669, ptr %slot151, align 8
  %v1670 = load i64, ptr %slot144, align 8
  %v1671 = load i64, ptr %slot143, align 8
  %op1672 = sub i64 %v1670, %v1671
  store i64 %op1672, ptr %slot152, align 8
  %v1673 = load i64, ptr %slot151, align 8
  %v1674 = load i64, ptr %slot150, align 8
  %op1675 = sub i64 %v1673, %v1674
  store i64 %op1675, ptr %slot153, align 8
  %v1676 = load i64, ptr %slot152, align 8
  %v1677 = load i64, ptr %slot153, align 8
  %cmp1678 = icmp ult i64 %v1676, %v1677
  %cv1679 = zext i1 %cmp1678 to i64
  store i64 %cv1679, ptr %slot154, align 8
  %v1680 = load i64, ptr %slot154, align 8
  %cond1681 = icmp ne i64 %v1680, 0
  br i1 %cond1681, label %bb_buf_fast211, label %bb_buf_slow211
bb_buf_slow211:
  %v1682 = load i64, ptr %slot34, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %v1684 = load i64, ptr %slot141, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  %v1686 = load i64, ptr %slot142, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %v1688 = load i64, ptr %slot143, align 8
  %v1689 = load i64, ptr %slot144, align 8
  %call1690 = call i32 @myl_native_bytes_buffer_append_range(ptr %p1683, ptr %p1685, ptr %p1687, i64 %v1688, i64 %v1689) nomerge, !dbg !118
  store i32 %call1690, ptr %slot155, align 8
  %v1691 = load i32, ptr %slot155, align 8
  %ext1692 = zext i32 %v1691 to i64
  store i64 %ext1692, ptr %slot156, align 8
  %v1693 = load i64, ptr %slot156, align 8
  %cmp1694 = icmp ne i64 %v1693, 0
  %cv1695 = zext i1 %cmp1694 to i64
  store i64 %cv1695, ptr %slot157, align 8
  %v1696 = load i64, ptr %slot157, align 8
  %cond1697 = icmp ne i64 %v1696, 0
  br i1 %cond1697, label %bb_success225, label %bb_failed225
bb_failed225:
  %v1698 = load i64, ptr %slot1, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1699) nomerge, !dbg !118
  unreachable
bb_success225:
  %v1700 = load i32, ptr %slot155, align 8
  %cmp1701 = icmp eq i32 %v1700, 1
  %cv1702 = zext i1 %cmp1701 to i32
  store i32 %cv1702, ptr %slot158, align 8
  %v1703 = load i32, ptr %slot158, align 8
  %ext1704 = zext i32 %v1703 to i64
  store i64 %ext1704, ptr %slot159, align 8
  %v1705 = load i64, ptr %slot159, align 8
  %v1706 = load i64, ptr %slot31, align 8
  %p1707 = inttoptr i64 %v1706 to ptr
  store i64 %v1705, ptr %p1707, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done211
bb_buf_fast211:
  %v1708 = load i64, ptr %slot141, align 8
  %op1709 = add i64 %v1708, 32
  store i64 %op1709, ptr %slot160, align 8
  %v1710 = load i64, ptr %slot142, align 8
  %op1711 = add i64 %v1710, 32
  store i64 %op1711, ptr %slot161, align 8
  %v1712 = load i64, ptr %slot160, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i64, ptr %p1713, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1714, ptr %slot162, align 8
  %v1715 = load i64, ptr %slot162, align 8
  %v1716 = load i64, ptr %slot150, align 8
  %op1717 = add i64 %v1715, %v1716
  store i64 %op1717, ptr %slot163, align 8
  %v1718 = load i64, ptr %slot161, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  %ld1720 = load i64, ptr %p1719, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1720, ptr %slot164, align 8
  %v1721 = load i64, ptr %slot164, align 8
  %v1722 = load i64, ptr %slot143, align 8
  %op1723 = add i64 %v1721, %v1722
  store i64 %op1723, ptr %slot165, align 8
  %v1724 = load i64, ptr %slot163, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  %v1726 = load i64, ptr %slot165, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  %v1728 = load i64, ptr %slot152, align 8
  call void @myl_native_bytes_copy_octets(ptr %p1725, ptr %p1727, i64 %v1728) nomerge, !dbg !118
  %v1729 = load i64, ptr %slot150, align 8
  %v1730 = load i64, ptr %slot152, align 8
  %op1731 = add i64 %v1729, %v1730
  store i64 %op1731, ptr %slot166, align 8
  %v1732 = load i64, ptr %slot166, align 8
  %v1733 = load i64, ptr %slot141, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i64 %v1732, ptr %p1734, align 8, !alias.scope !6, !noalias !7
  %v1735 = load i64, ptr %slot31, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i64 1, ptr %p1736, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done211
bb_buf_refused211:
  %v1737 = load i64, ptr %slot31, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  store i64 0, ptr %p1738, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done211
bb_buf_done211:
  %v1739 = load i64, ptr %slot11, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  %ld1741 = load i32, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1741, ptr %slot167, align 8
  %v1742 = load i32, ptr %slot167, align 8
  %cv1743 = zext i32 %v1742 to i64
  %cond1744 = icmp ne i64 %cv1743, 0
  br i1 %cond1744, label %bb_rcslotdrop237, label %bb_rcslotdone237
bb_rcslotdrop237:
  %v1745 = load i64, ptr %slot11, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i32 0, ptr %p1746, align 4, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot15, align 8
  store i64 %v1747, ptr %slot168, align 8
  %v1748 = load i64, ptr %slot12, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  %ld1750 = load i32, ptr %p1749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1750, ptr %slot169, align 8
  %v1751 = load i32, ptr %slot169, align 8
  %op1752 = and i32 %v1751, 28
  store i32 %op1752, ptr %slot170, align 8
  %v1753 = load i32, ptr %slot170, align 8
  %cv1754 = zext i32 %v1753 to i64
  %cond1755 = icmp ne i64 %cv1754, 0
  br i1 %cond1755, label %bb_rcslotrole237, label %bb_rcslotowner237
bb_rcslotrole237:
  %v1756 = load i64, ptr %slot34, align 8
  store i64 %v1756, ptr %slot171, align 8
  %v1757 = load i64, ptr %slot168, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  %ld1759 = load i64, ptr %p1758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1759, ptr %slot172, align 8
  %v1760 = load i64, ptr %slot172, align 8
  %cmp1761 = icmp ne i64 %v1760, 0
  %cv1762 = zext i1 %cmp1761 to i32
  store i32 %cv1762, ptr %slot173, align 8
  %v1763 = load i32, ptr %slot173, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcgnn253, label %bb_rcgdone253
bb_rcgnn253:
  %v1766 = load i64, ptr %slot172, align 8
  %op1767 = sub i64 %v1766, 16
  store i64 %op1767, ptr %slot174, align 8
  %v1768 = load i64, ptr %slot172, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %rgep1770 = getelementptr i8, ptr %p1769, i64 -16
  %ld1771 = load i64, ptr %rgep1770, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1771, ptr %slot175, align 8
  %v1772 = load i64, ptr %slot175, align 8
  %op1773 = and i64 %v1772, 4611686018427387906
  store i64 %op1773, ptr %slot176, align 8
  %v1774 = load i64, ptr %slot176, align 8
  %cmp1775 = icmp ne i64 %v1774, 0
  %cv1776 = zext i1 %cmp1775 to i32
  store i32 %cv1776, ptr %slot177, align 8
  %v1777 = load i32, ptr %slot177, align 8
  %cv1778 = zext i32 %v1777 to i64
  %cond1779 = icmp ne i64 %cv1778, 0
  br i1 %cond1779, label %bb_rcgclear253, label %bb_rcgcounted253
bb_rcgcounted253:
  %v1780 = load i64, ptr %slot172, align 8
  %op1781 = sub i64 %v1780, 24
  store i64 %op1781, ptr %slot178, align 8
  %v1782 = load i64, ptr %slot172, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  %rgep1784 = getelementptr i8, ptr %p1783, i64 -24
  %ld1785 = load i64, ptr %rgep1784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1785, ptr %slot179, align 8
  %v1786 = load i64, ptr %slot179, align 8
  %op1787 = sub i64 %v1786, 1
  store i64 %op1787, ptr %slot180, align 8
  %v1788 = load i64, ptr %slot180, align 8
  %cmp1789 = icmp eq i64 %v1788, 0
  %cv1790 = zext i1 %cmp1789 to i32
  store i32 %cv1790, ptr %slot181, align 8
  %v1791 = load i32, ptr %slot181, align 8
  %cv1792 = zext i32 %v1791 to i64
  %cond1793 = icmp ne i64 %cv1792, 0
  br i1 %cond1793, label %bb_rcglast253, label %bb_rcgdec253
bb_rcglast253:
  %v1794 = load i64, ptr %slot172, align 8
  %op1795 = sub i64 %v1794, 32
  store i64 %op1795, ptr %slot182, align 8
  %v1796 = load i64, ptr %slot172, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  %rgep1798 = getelementptr i8, ptr %p1797, i64 -32
  %ld1799 = load i64, ptr %rgep1798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1799, ptr %slot183, align 8
  %v1800 = load i64, ptr %slot183, align 8
  %cmp1801 = icmp ne i64 %v1800, 0
  %cv1802 = zext i1 %cmp1801 to i32
  store i32 %cv1802, ptr %slot184, align 8
  %v1803 = load i32, ptr %slot184, align 8
  %cv1804 = zext i32 %v1803 to i64
  %cond1805 = icmp ne i64 %cv1804, 0
  br i1 %cond1805, label %bb_rcgdec253, label %bb_rcgslow253
bb_rcgslow253:
  %v1806 = load i64, ptr %slot171, align 8
  %v1807 = load i64, ptr %slot168, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1806, i64 %v1807) nomerge, !dbg !118
  br label %bb_rcgdone253
bb_rcgdec253:
  %v1808 = load i64, ptr %slot180, align 8
  %v1809 = load i64, ptr %slot172, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %rgep1811 = getelementptr i8, ptr %p1810, i64 -24
  store i64 %v1808, ptr %rgep1811, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear253
bb_rcgclear253:
  %v1812 = load i64, ptr %slot168, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  store i64 0, ptr %p1813, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone253
bb_rcgdone253:
  br label %bb_rcslotdone237
bb_rcslotowner237:
  %v1814 = load i64, ptr %slot34, align 8
  store i64 %v1814, ptr %slot185, align 8
  %v1815 = load i64, ptr %slot168, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  %ld1817 = load i64, ptr %p1816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1817, ptr %slot186, align 8
  %v1818 = load i64, ptr %slot186, align 8
  %cmp1819 = icmp ne i64 %v1818, 0
  %cv1820 = zext i1 %cmp1819 to i32
  store i32 %cv1820, ptr %slot187, align 8
  %v1821 = load i32, ptr %slot187, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcgnn268, label %bb_rcgdone268
bb_rcgnn268:
  %v1824 = load i64, ptr %slot186, align 8
  %op1825 = sub i64 %v1824, 16
  store i64 %op1825, ptr %slot188, align 8
  %v1826 = load i64, ptr %slot186, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  %rgep1828 = getelementptr i8, ptr %p1827, i64 -16
  %ld1829 = load i64, ptr %rgep1828, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1829, ptr %slot189, align 8
  %v1830 = load i64, ptr %slot189, align 8
  %op1831 = and i64 %v1830, 4611686018427387906
  store i64 %op1831, ptr %slot190, align 8
  %v1832 = load i64, ptr %slot190, align 8
  %cmp1833 = icmp ne i64 %v1832, 0
  %cv1834 = zext i1 %cmp1833 to i32
  store i32 %cv1834, ptr %slot191, align 8
  %v1835 = load i32, ptr %slot191, align 8
  %cv1836 = zext i32 %v1835 to i64
  %cond1837 = icmp ne i64 %cv1836, 0
  br i1 %cond1837, label %bb_rcgclear268, label %bb_rcgcounted268
bb_rcgcounted268:
  %v1838 = load i64, ptr %slot186, align 8
  %op1839 = sub i64 %v1838, 32
  store i64 %op1839, ptr %slot192, align 8
  %v1840 = load i64, ptr %slot186, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %rgep1842 = getelementptr i8, ptr %p1841, i64 -32
  %ld1843 = load i64, ptr %rgep1842, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1843, ptr %slot193, align 8
  %v1844 = load i64, ptr %slot193, align 8
  %op1845 = sub i64 %v1844, 1
  store i64 %op1845, ptr %slot194, align 8
  %v1846 = load i64, ptr %slot194, align 8
  %cmp1847 = icmp eq i64 %v1846, 0
  %cv1848 = zext i1 %cmp1847 to i32
  store i32 %cv1848, ptr %slot195, align 8
  %v1849 = load i32, ptr %slot195, align 8
  %cv1850 = zext i32 %v1849 to i64
  %cond1851 = icmp ne i64 %cv1850, 0
  br i1 %cond1851, label %bb_rcglast268, label %bb_rcgdec268
bb_rcglast268:
  %v1852 = load i64, ptr %slot186, align 8
  %op1853 = sub i64 %v1852, 24
  store i64 %op1853, ptr %slot196, align 8
  %v1854 = load i64, ptr %slot186, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %rgep1856 = getelementptr i8, ptr %p1855, i64 -24
  %ld1857 = load i64, ptr %rgep1856, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1857, ptr %slot197, align 8
  %v1858 = load i64, ptr %slot197, align 8
  %cmp1859 = icmp ne i64 %v1858, 0
  %cv1860 = zext i1 %cmp1859 to i32
  store i32 %cv1860, ptr %slot198, align 8
  %v1861 = load i32, ptr %slot198, align 8
  %cv1862 = zext i32 %v1861 to i64
  %cond1863 = icmp ne i64 %cv1862, 0
  br i1 %cond1863, label %bb_rcgdec268, label %bb_rcgslow268
bb_rcgslow268:
  %v1864 = load i64, ptr %slot185, align 8
  %v1865 = load i64, ptr %slot168, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1864, i64 %v1865) nomerge, !dbg !118
  br label %bb_rcgdone268
bb_rcgdec268:
  %v1866 = load i64, ptr %slot194, align 8
  %v1867 = load i64, ptr %slot186, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %rgep1869 = getelementptr i8, ptr %p1868, i64 -32
  store i64 %v1866, ptr %rgep1869, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear268
bb_rcgclear268:
  %v1870 = load i64, ptr %slot168, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  store i64 0, ptr %p1871, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone268
bb_rcgdone268:
  br label %bb_rcslotdone237
bb_rcslotdone237:
  %v1872 = load i64, ptr %slot23, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %ld1874 = load i64, ptr %p1873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1874, ptr %slot199, align 8
  %v1875 = load i64, ptr %slot199, align 8
  %v1876 = load i64, ptr %slot31, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i64 %v1875, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot31, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i64, ptr %p1879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1880, ptr %slot200, align 8
  %v1881 = load i64, ptr %slot200, align 8
  %op1882 = add i64 %v1881, 8
  store i64 %op1882, ptr %slot201, align 8
  %v1883 = load i64, ptr %slot201, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %ld1885 = load i64, ptr %p1884, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1885, ptr %slot202, align 8
  %v1886 = load i64, ptr %slot202, align 8
  %v1887 = load i64, ptr %slot31, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  store i64 %v1886, ptr %p1888, align 8, !alias.scope !3, !noalias !4
  %v1889 = load i64, ptr %slot11, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  %ld1891 = load i32, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1891, ptr %slot203, align 8
  %v1892 = load i32, ptr %slot203, align 8
  %cv1893 = zext i32 %v1892 to i64
  %cond1894 = icmp ne i64 %cv1893, 0
  br i1 %cond1894, label %bb_rcslotdrop278, label %bb_rcslotdone278
bb_rcslotdrop278:
  %v1895 = load i64, ptr %slot11, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i32 0, ptr %p1896, align 4, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot15, align 8
  store i64 %v1897, ptr %slot204, align 8
  %v1898 = load i64, ptr %slot12, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %ld1900 = load i32, ptr %p1899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1900, ptr %slot205, align 8
  %v1901 = load i32, ptr %slot205, align 8
  %op1902 = and i32 %v1901, 28
  store i32 %op1902, ptr %slot206, align 8
  %v1903 = load i32, ptr %slot206, align 8
  %cv1904 = zext i32 %v1903 to i64
  %cond1905 = icmp ne i64 %cv1904, 0
  br i1 %cond1905, label %bb_rcslotrole278, label %bb_rcslotowner278
bb_rcslotrole278:
  %v1906 = load i64, ptr %slot34, align 8
  store i64 %v1906, ptr %slot207, align 8
  %v1907 = load i64, ptr %slot207, align 8
  %v1908 = load i64, ptr %slot204, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1907, i64 %v1908) nomerge, !dbg !120
  br label %bb_rcslotdone278
bb_rcslotowner278:
  %v1909 = load i64, ptr %slot34, align 8
  store i64 %v1909, ptr %slot208, align 8
  %v1910 = load i64, ptr %slot208, align 8
  %v1911 = load i64, ptr %slot204, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1910, i64 %v1911) nomerge, !dbg !120
  br label %bb_rcslotdone278
bb_rcslotdone278:
  %v1912 = load i64, ptr %slot31, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  %ld1914 = load i64, ptr %p1913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1914, ptr %slot209, align 8
  %v1915 = load i64, ptr %slot23, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  %ld1917 = load i64, ptr %p1916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1917, ptr %slot210, align 8
  %v1918 = load i64, ptr %slot11, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  %ld1920 = load i32, ptr %p1919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1920, ptr %slot211, align 8
  %v1921 = load i32, ptr %slot211, align 8
  %cv1922 = zext i32 %v1921 to i64
  %cond1923 = icmp ne i64 %cv1922, 0
  br i1 %cond1923, label %bb_rcslotdrop290, label %bb_rcslotdone290
bb_rcslotdrop290:
  %v1924 = load i64, ptr %slot11, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  store i32 0, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  %v1926 = load i64, ptr %slot15, align 8
  store i64 %v1926, ptr %slot212, align 8
  %v1927 = load i64, ptr %slot12, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %ld1929 = load i32, ptr %p1928, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1929, ptr %slot213, align 8
  %v1930 = load i32, ptr %slot213, align 8
  %op1931 = and i32 %v1930, 28
  store i32 %op1931, ptr %slot214, align 8
  %v1932 = load i32, ptr %slot214, align 8
  %cv1933 = zext i32 %v1932 to i64
  %cond1934 = icmp ne i64 %cv1933, 0
  br i1 %cond1934, label %bb_rcslotrole290, label %bb_rcslotowner290
bb_rcslotrole290:
  %v1935 = load i64, ptr %slot34, align 8
  store i64 %v1935, ptr %slot215, align 8
  %v1936 = load i64, ptr %slot212, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  %ld1938 = load i64, ptr %p1937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1938, ptr %slot216, align 8
  %v1939 = load i64, ptr %slot216, align 8
  %cmp1940 = icmp ne i64 %v1939, 0
  %cv1941 = zext i1 %cmp1940 to i32
  store i32 %cv1941, ptr %slot217, align 8
  %v1942 = load i32, ptr %slot217, align 8
  %cv1943 = zext i32 %v1942 to i64
  %cond1944 = icmp ne i64 %cv1943, 0
  br i1 %cond1944, label %bb_rcgnn306, label %bb_rcgdone306
bb_rcgnn306:
  %v1945 = load i64, ptr %slot216, align 8
  %op1946 = sub i64 %v1945, 16
  store i64 %op1946, ptr %slot218, align 8
  %v1947 = load i64, ptr %slot216, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %rgep1949 = getelementptr i8, ptr %p1948, i64 -16
  %ld1950 = load i64, ptr %rgep1949, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1950, ptr %slot219, align 8
  %v1951 = load i64, ptr %slot219, align 8
  %op1952 = and i64 %v1951, 4611686018427387906
  store i64 %op1952, ptr %slot220, align 8
  %v1953 = load i64, ptr %slot220, align 8
  %cmp1954 = icmp ne i64 %v1953, 0
  %cv1955 = zext i1 %cmp1954 to i32
  store i32 %cv1955, ptr %slot221, align 8
  %v1956 = load i32, ptr %slot221, align 8
  %cv1957 = zext i32 %v1956 to i64
  %cond1958 = icmp ne i64 %cv1957, 0
  br i1 %cond1958, label %bb_rcgclear306, label %bb_rcgcounted306
bb_rcgcounted306:
  %v1959 = load i64, ptr %slot216, align 8
  %op1960 = sub i64 %v1959, 24
  store i64 %op1960, ptr %slot222, align 8
  %v1961 = load i64, ptr %slot216, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  %rgep1963 = getelementptr i8, ptr %p1962, i64 -24
  %ld1964 = load i64, ptr %rgep1963, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1964, ptr %slot223, align 8
  %v1965 = load i64, ptr %slot223, align 8
  %op1966 = sub i64 %v1965, 1
  store i64 %op1966, ptr %slot224, align 8
  %v1967 = load i64, ptr %slot224, align 8
  %cmp1968 = icmp eq i64 %v1967, 0
  %cv1969 = zext i1 %cmp1968 to i32
  store i32 %cv1969, ptr %slot225, align 8
  %v1970 = load i32, ptr %slot225, align 8
  %cv1971 = zext i32 %v1970 to i64
  %cond1972 = icmp ne i64 %cv1971, 0
  br i1 %cond1972, label %bb_rcglast306, label %bb_rcgdec306
bb_rcglast306:
  %v1973 = load i64, ptr %slot216, align 8
  %op1974 = sub i64 %v1973, 32
  store i64 %op1974, ptr %slot226, align 8
  %v1975 = load i64, ptr %slot216, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  %rgep1977 = getelementptr i8, ptr %p1976, i64 -32
  %ld1978 = load i64, ptr %rgep1977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1978, ptr %slot227, align 8
  %v1979 = load i64, ptr %slot227, align 8
  %cmp1980 = icmp ne i64 %v1979, 0
  %cv1981 = zext i1 %cmp1980 to i32
  store i32 %cv1981, ptr %slot228, align 8
  %v1982 = load i32, ptr %slot228, align 8
  %cv1983 = zext i32 %v1982 to i64
  %cond1984 = icmp ne i64 %cv1983, 0
  br i1 %cond1984, label %bb_rcgdec306, label %bb_rcgslow306
bb_rcgslow306:
  %v1985 = load i64, ptr %slot215, align 8
  %v1986 = load i64, ptr %slot212, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1985, i64 %v1986) nomerge, !dbg !122
  br label %bb_rcgdone306
bb_rcgdec306:
  %v1987 = load i64, ptr %slot224, align 8
  %v1988 = load i64, ptr %slot216, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %rgep1990 = getelementptr i8, ptr %p1989, i64 -24
  store i64 %v1987, ptr %rgep1990, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear306
bb_rcgclear306:
  %v1991 = load i64, ptr %slot212, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i64 0, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone306
bb_rcgdone306:
  br label %bb_rcslotdone290
bb_rcslotowner290:
  %v1993 = load i64, ptr %slot34, align 8
  store i64 %v1993, ptr %slot229, align 8
  %v1994 = load i64, ptr %slot212, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  %ld1996 = load i64, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1996, ptr %slot230, align 8
  %v1997 = load i64, ptr %slot230, align 8
  %cmp1998 = icmp ne i64 %v1997, 0
  %cv1999 = zext i1 %cmp1998 to i32
  store i32 %cv1999, ptr %slot231, align 8
  %v2000 = load i32, ptr %slot231, align 8
  %cv2001 = zext i32 %v2000 to i64
  %cond2002 = icmp ne i64 %cv2001, 0
  br i1 %cond2002, label %bb_rcgnn321, label %bb_rcgdone321
bb_rcgnn321:
  %v2003 = load i64, ptr %slot230, align 8
  %op2004 = sub i64 %v2003, 16
  store i64 %op2004, ptr %slot232, align 8
  %v2005 = load i64, ptr %slot230, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  %rgep2007 = getelementptr i8, ptr %p2006, i64 -16
  %ld2008 = load i64, ptr %rgep2007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2008, ptr %slot233, align 8
  %v2009 = load i64, ptr %slot233, align 8
  %op2010 = and i64 %v2009, 4611686018427387906
  store i64 %op2010, ptr %slot234, align 8
  %v2011 = load i64, ptr %slot234, align 8
  %cmp2012 = icmp ne i64 %v2011, 0
  %cv2013 = zext i1 %cmp2012 to i32
  store i32 %cv2013, ptr %slot235, align 8
  %v2014 = load i32, ptr %slot235, align 8
  %cv2015 = zext i32 %v2014 to i64
  %cond2016 = icmp ne i64 %cv2015, 0
  br i1 %cond2016, label %bb_rcgclear321, label %bb_rcgcounted321
bb_rcgcounted321:
  %v2017 = load i64, ptr %slot230, align 8
  %op2018 = sub i64 %v2017, 32
  store i64 %op2018, ptr %slot236, align 8
  %v2019 = load i64, ptr %slot230, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %rgep2021 = getelementptr i8, ptr %p2020, i64 -32
  %ld2022 = load i64, ptr %rgep2021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2022, ptr %slot237, align 8
  %v2023 = load i64, ptr %slot237, align 8
  %op2024 = sub i64 %v2023, 1
  store i64 %op2024, ptr %slot238, align 8
  %v2025 = load i64, ptr %slot238, align 8
  %cmp2026 = icmp eq i64 %v2025, 0
  %cv2027 = zext i1 %cmp2026 to i32
  store i32 %cv2027, ptr %slot239, align 8
  %v2028 = load i32, ptr %slot239, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcglast321, label %bb_rcgdec321
bb_rcglast321:
  %v2031 = load i64, ptr %slot230, align 8
  %op2032 = sub i64 %v2031, 24
  store i64 %op2032, ptr %slot240, align 8
  %v2033 = load i64, ptr %slot230, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  %rgep2035 = getelementptr i8, ptr %p2034, i64 -24
  %ld2036 = load i64, ptr %rgep2035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2036, ptr %slot241, align 8
  %v2037 = load i64, ptr %slot241, align 8
  %cmp2038 = icmp ne i64 %v2037, 0
  %cv2039 = zext i1 %cmp2038 to i32
  store i32 %cv2039, ptr %slot242, align 8
  %v2040 = load i32, ptr %slot242, align 8
  %cv2041 = zext i32 %v2040 to i64
  %cond2042 = icmp ne i64 %cv2041, 0
  br i1 %cond2042, label %bb_rcgdec321, label %bb_rcgslow321
bb_rcgslow321:
  %v2043 = load i64, ptr %slot229, align 8
  %v2044 = load i64, ptr %slot212, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2043, i64 %v2044) nomerge, !dbg !122
  br label %bb_rcgdone321
bb_rcgdec321:
  %v2045 = load i64, ptr %slot238, align 8
  %v2046 = load i64, ptr %slot230, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  %rgep2048 = getelementptr i8, ptr %p2047, i64 -32
  store i64 %v2045, ptr %rgep2048, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear321
bb_rcgclear321:
  %v2049 = load i64, ptr %slot212, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i64 0, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone321
bb_rcgdone321:
  br label %bb_rcslotdone290
bb_rcslotdone290:
  %v2051 = load i64, ptr %slot210, align 8
  %op2052 = add i64 %v2051, 8
  store i64 %op2052, ptr %slot243, align 8
  store i64 0, ptr %slot244, align 8
  %v2053 = load i64, ptr %slot243, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  %ld2055 = load i64, ptr %p2054, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2055, ptr %slot245, align 8
  %v2056 = load i64, ptr %slot245, align 8
  %cmp2057 = icmp ne i64 %v2056, 0
  %cv2058 = zext i1 %cmp2057 to i32
  store i32 %cv2058, ptr %slot246, align 8
  %v2059 = load i32, ptr %slot246, align 8
  %cv2060 = zext i32 %v2059 to i64
  %cond2061 = icmp ne i64 %cv2060, 0
  br i1 %cond2061, label %bb_rcguniquenn327, label %bb_rcgunique327
bb_rcguniquenn327:
  %v2062 = load i64, ptr %slot245, align 8
  %op2063 = sub i64 %v2062, 16
  store i64 %op2063, ptr %slot247, align 8
  %v2064 = load i64, ptr %slot245, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  %rgep2066 = getelementptr i8, ptr %p2065, i64 -16
  %ld2067 = load i64, ptr %rgep2066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2067, ptr %slot248, align 8
  %v2068 = load i64, ptr %slot248, align 8
  %op2069 = and i64 %v2068, 6917529027641081858
  store i64 %op2069, ptr %slot249, align 8
  %v2070 = load i64, ptr %slot249, align 8
  %cmp2071 = icmp ne i64 %v2070, 0
  %cv2072 = zext i1 %cmp2071 to i32
  store i32 %cv2072, ptr %slot250, align 8
  %v2073 = load i32, ptr %slot250, align 8
  %cv2074 = zext i32 %v2073 to i64
  %cond2075 = icmp ne i64 %cv2074, 0
  br i1 %cond2075, label %bb_rcguniqueslow327, label %bb_rcguniquecount327
bb_rcguniquecount327:
  %v2076 = load i64, ptr %slot245, align 8
  %op2077 = sub i64 %v2076, 32
  store i64 %op2077, ptr %slot251, align 8
  %v2078 = load i64, ptr %slot245, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  %rgep2080 = getelementptr i8, ptr %p2079, i64 -32
  %ld2081 = load i64, ptr %rgep2080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2081, ptr %slot252, align 8
  %v2082 = load i64, ptr %slot252, align 8
  %cmp2083 = icmp ult i64 %v2082, 2
  %cv2084 = zext i1 %cmp2083 to i32
  store i32 %cv2084, ptr %slot253, align 8
  %v2085 = load i32, ptr %slot253, align 8
  %cv2086 = zext i32 %v2085 to i64
  %cond2087 = icmp ne i64 %cv2086, 0
  br i1 %cond2087, label %bb_rcgunique327, label %bb_rcguniqueslow327
bb_rcguniqueslow327:
  %v2088 = load i64, ptr %slot1, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %p2090 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v2091 = load i64, ptr %slot243, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %v2093 = load i64, ptr %slot244, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  %call2095 = call i32 @myl_qbe_rc_unique_field(ptr %p2089, ptr %p2090, ptr %p2092, ptr %p2094) nomerge, !dbg !122
  store i32 %call2095, ptr %slot254, align 8
  %v2096 = load i32, ptr %slot254, align 8
  %cv2097 = zext i32 %v2096 to i64
  %cond2098 = icmp ne i64 %cv2097, 0
  br i1 %cond2098, label %bb_rcunique337, label %bb_failure
bb_rcunique337:
  br label %bb_rcgunique327
bb_rcgunique327:
  %v2099 = load i64, ptr %slot243, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %ld2101 = load i64, ptr %p2100, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2101, ptr %slot255, align 8
  %v2102 = load i64, ptr %slot255, align 8
  %v2103 = load i64, ptr %slot31, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i64 %v2102, ptr %p2104, align 8, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot31, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  %ld2107 = load i64, ptr %p2106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2107, ptr %slot256, align 8
  %v2108 = load i64, ptr %slot11, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %ld2110 = load i32, ptr %p2109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2110, ptr %slot257, align 8
  %v2111 = load i32, ptr %slot257, align 8
  %cv2112 = zext i32 %v2111 to i64
  %cond2113 = icmp ne i64 %cv2112, 0
  br i1 %cond2113, label %bb_rcslotdrop342, label %bb_rcslotdone342
bb_rcslotdrop342:
  %v2114 = load i64, ptr %slot11, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  store i32 0, ptr %p2115, align 4, !alias.scope !3, !noalias !4
  %v2116 = load i64, ptr %slot15, align 8
  store i64 %v2116, ptr %slot258, align 8
  %v2117 = load i64, ptr %slot12, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %ld2119 = load i32, ptr %p2118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2119, ptr %slot259, align 8
  %v2120 = load i32, ptr %slot259, align 8
  %op2121 = and i32 %v2120, 28
  store i32 %op2121, ptr %slot260, align 8
  %v2122 = load i32, ptr %slot260, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcslotrole342, label %bb_rcslotowner342
bb_rcslotrole342:
  %v2125 = load i64, ptr %slot34, align 8
  store i64 %v2125, ptr %slot261, align 8
  %v2126 = load i64, ptr %slot258, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  %ld2128 = load i64, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2128, ptr %slot262, align 8
  %v2129 = load i64, ptr %slot262, align 8
  %cmp2130 = icmp ne i64 %v2129, 0
  %cv2131 = zext i1 %cmp2130 to i32
  store i32 %cv2131, ptr %slot263, align 8
  %v2132 = load i32, ptr %slot263, align 8
  %cv2133 = zext i32 %v2132 to i64
  %cond2134 = icmp ne i64 %cv2133, 0
  br i1 %cond2134, label %bb_rcgnn358, label %bb_rcgdone358
bb_rcgnn358:
  %v2135 = load i64, ptr %slot262, align 8
  %op2136 = sub i64 %v2135, 16
  store i64 %op2136, ptr %slot264, align 8
  %v2137 = load i64, ptr %slot262, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %rgep2139 = getelementptr i8, ptr %p2138, i64 -16
  %ld2140 = load i64, ptr %rgep2139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2140, ptr %slot265, align 8
  %v2141 = load i64, ptr %slot265, align 8
  %op2142 = and i64 %v2141, 4611686018427387906
  store i64 %op2142, ptr %slot266, align 8
  %v2143 = load i64, ptr %slot266, align 8
  %cmp2144 = icmp ne i64 %v2143, 0
  %cv2145 = zext i1 %cmp2144 to i32
  store i32 %cv2145, ptr %slot267, align 8
  %v2146 = load i32, ptr %slot267, align 8
  %cv2147 = zext i32 %v2146 to i64
  %cond2148 = icmp ne i64 %cv2147, 0
  br i1 %cond2148, label %bb_rcgclear358, label %bb_rcgcounted358
bb_rcgcounted358:
  %v2149 = load i64, ptr %slot262, align 8
  %op2150 = sub i64 %v2149, 24
  store i64 %op2150, ptr %slot268, align 8
  %v2151 = load i64, ptr %slot262, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  %rgep2153 = getelementptr i8, ptr %p2152, i64 -24
  %ld2154 = load i64, ptr %rgep2153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2154, ptr %slot269, align 8
  %v2155 = load i64, ptr %slot269, align 8
  %op2156 = sub i64 %v2155, 1
  store i64 %op2156, ptr %slot270, align 8
  %v2157 = load i64, ptr %slot270, align 8
  %cmp2158 = icmp eq i64 %v2157, 0
  %cv2159 = zext i1 %cmp2158 to i32
  store i32 %cv2159, ptr %slot271, align 8
  %v2160 = load i32, ptr %slot271, align 8
  %cv2161 = zext i32 %v2160 to i64
  %cond2162 = icmp ne i64 %cv2161, 0
  br i1 %cond2162, label %bb_rcglast358, label %bb_rcgdec358
bb_rcglast358:
  %v2163 = load i64, ptr %slot262, align 8
  %op2164 = sub i64 %v2163, 32
  store i64 %op2164, ptr %slot272, align 8
  %v2165 = load i64, ptr %slot262, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %rgep2167 = getelementptr i8, ptr %p2166, i64 -32
  %ld2168 = load i64, ptr %rgep2167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2168, ptr %slot273, align 8
  %v2169 = load i64, ptr %slot273, align 8
  %cmp2170 = icmp ne i64 %v2169, 0
  %cv2171 = zext i1 %cmp2170 to i32
  store i32 %cv2171, ptr %slot274, align 8
  %v2172 = load i32, ptr %slot274, align 8
  %cv2173 = zext i32 %v2172 to i64
  %cond2174 = icmp ne i64 %cv2173, 0
  br i1 %cond2174, label %bb_rcgdec358, label %bb_rcgslow358
bb_rcgslow358:
  %v2175 = load i64, ptr %slot261, align 8
  %v2176 = load i64, ptr %slot258, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2175, i64 %v2176) nomerge, !dbg !122
  br label %bb_rcgdone358
bb_rcgdec358:
  %v2177 = load i64, ptr %slot270, align 8
  %v2178 = load i64, ptr %slot262, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %rgep2180 = getelementptr i8, ptr %p2179, i64 -24
  store i64 %v2177, ptr %rgep2180, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear358
bb_rcgclear358:
  %v2181 = load i64, ptr %slot258, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i64 0, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone358
bb_rcgdone358:
  br label %bb_rcslotdone342
bb_rcslotowner342:
  %v2183 = load i64, ptr %slot34, align 8
  store i64 %v2183, ptr %slot275, align 8
  %v2184 = load i64, ptr %slot258, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  %ld2186 = load i64, ptr %p2185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2186, ptr %slot276, align 8
  %v2187 = load i64, ptr %slot276, align 8
  %cmp2188 = icmp ne i64 %v2187, 0
  %cv2189 = zext i1 %cmp2188 to i32
  store i32 %cv2189, ptr %slot277, align 8
  %v2190 = load i32, ptr %slot277, align 8
  %cv2191 = zext i32 %v2190 to i64
  %cond2192 = icmp ne i64 %cv2191, 0
  br i1 %cond2192, label %bb_rcgnn373, label %bb_rcgdone373
bb_rcgnn373:
  %v2193 = load i64, ptr %slot276, align 8
  %op2194 = sub i64 %v2193, 16
  store i64 %op2194, ptr %slot278, align 8
  %v2195 = load i64, ptr %slot276, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  %rgep2197 = getelementptr i8, ptr %p2196, i64 -16
  %ld2198 = load i64, ptr %rgep2197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2198, ptr %slot279, align 8
  %v2199 = load i64, ptr %slot279, align 8
  %op2200 = and i64 %v2199, 4611686018427387906
  store i64 %op2200, ptr %slot280, align 8
  %v2201 = load i64, ptr %slot280, align 8
  %cmp2202 = icmp ne i64 %v2201, 0
  %cv2203 = zext i1 %cmp2202 to i32
  store i32 %cv2203, ptr %slot281, align 8
  %v2204 = load i32, ptr %slot281, align 8
  %cv2205 = zext i32 %v2204 to i64
  %cond2206 = icmp ne i64 %cv2205, 0
  br i1 %cond2206, label %bb_rcgclear373, label %bb_rcgcounted373
bb_rcgcounted373:
  %v2207 = load i64, ptr %slot276, align 8
  %op2208 = sub i64 %v2207, 32
  store i64 %op2208, ptr %slot282, align 8
  %v2209 = load i64, ptr %slot276, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  %rgep2211 = getelementptr i8, ptr %p2210, i64 -32
  %ld2212 = load i64, ptr %rgep2211, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2212, ptr %slot283, align 8
  %v2213 = load i64, ptr %slot283, align 8
  %op2214 = sub i64 %v2213, 1
  store i64 %op2214, ptr %slot284, align 8
  %v2215 = load i64, ptr %slot284, align 8
  %cmp2216 = icmp eq i64 %v2215, 0
  %cv2217 = zext i1 %cmp2216 to i32
  store i32 %cv2217, ptr %slot285, align 8
  %v2218 = load i32, ptr %slot285, align 8
  %cv2219 = zext i32 %v2218 to i64
  %cond2220 = icmp ne i64 %cv2219, 0
  br i1 %cond2220, label %bb_rcglast373, label %bb_rcgdec373
bb_rcglast373:
  %v2221 = load i64, ptr %slot276, align 8
  %op2222 = sub i64 %v2221, 24
  store i64 %op2222, ptr %slot286, align 8
  %v2223 = load i64, ptr %slot276, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %rgep2225 = getelementptr i8, ptr %p2224, i64 -24
  %ld2226 = load i64, ptr %rgep2225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2226, ptr %slot287, align 8
  %v2227 = load i64, ptr %slot287, align 8
  %cmp2228 = icmp ne i64 %v2227, 0
  %cv2229 = zext i1 %cmp2228 to i32
  store i32 %cv2229, ptr %slot288, align 8
  %v2230 = load i32, ptr %slot288, align 8
  %cv2231 = zext i32 %v2230 to i64
  %cond2232 = icmp ne i64 %cv2231, 0
  br i1 %cond2232, label %bb_rcgdec373, label %bb_rcgslow373
bb_rcgslow373:
  %v2233 = load i64, ptr %slot275, align 8
  %v2234 = load i64, ptr %slot258, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2233, i64 %v2234) nomerge, !dbg !122
  br label %bb_rcgdone373
bb_rcgdec373:
  %v2235 = load i64, ptr %slot284, align 8
  %v2236 = load i64, ptr %slot276, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %rgep2238 = getelementptr i8, ptr %p2237, i64 -32
  store i64 %v2235, ptr %rgep2238, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear373
bb_rcgclear373:
  %v2239 = load i64, ptr %slot258, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i64 0, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone373
bb_rcgdone373:
  br label %bb_rcslotdone342
bb_rcslotdone342:
  %v2241 = load i64, ptr %slot256, align 8
  %v2242 = load i64, ptr %slot26, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  store i64 %v2241, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  %v2244 = load i64, ptr %slot31, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  store i64 10, ptr %p2245, align 8, !alias.scope !3, !noalias !4
  %v2246 = load i64, ptr %slot26, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %ld2248 = load i64, ptr %p2247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2248, ptr %slot289, align 8
  %v2249 = load i64, ptr %slot31, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  %ld2251 = load i64, ptr %p2250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2251, ptr %slot290, align 8
  %v2252 = load i64, ptr %slot289, align 8
  %op2253 = add i64 %v2252, 8
  store i64 %op2253, ptr %slot291, align 8
  %v2254 = load i64, ptr %slot290, align 8
  %cmp2255 = icmp sge i64 %v2254, 0
  %cv2256 = zext i1 %cmp2255 to i64
  store i64 %cv2256, ptr %slot292, align 8
  %v2257 = load i64, ptr %slot292, align 8
  %cond2258 = icmp ne i64 %v2257, 0
  br i1 %cond2258, label %bb_byte_low417, label %bb_byte_refused417
bb_byte_low417:
  %v2259 = load i64, ptr %slot290, align 8
  %cmp2260 = icmp sle i64 %v2259, 255
  %cv2261 = zext i1 %cmp2260 to i64
  store i64 %cv2261, ptr %slot293, align 8
  %v2262 = load i64, ptr %slot293, align 8
  %cond2263 = icmp ne i64 %v2262, 0
  br i1 %cond2263, label %bb_byte_high417, label %bb_byte_refused417
bb_byte_high417:
  %v2264 = load i64, ptr %slot289, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %ld2266 = load i64, ptr %p2265, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2266, ptr %slot294, align 8
  %v2267 = load i64, ptr %slot291, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2269, ptr %slot295, align 8
  %v2270 = load i64, ptr %slot294, align 8
  %v2271 = load i64, ptr %slot295, align 8
  %cmp2272 = icmp ult i64 %v2270, %v2271
  %cv2273 = zext i1 %cmp2272 to i64
  store i64 %cv2273, ptr %slot296, align 8
  %v2274 = load i64, ptr %slot296, align 8
  %cond2275 = icmp ne i64 %v2274, 0
  br i1 %cond2275, label %bb_byte_fast417, label %bb_byte_slow417
bb_byte_slow417:
  %v2276 = load i64, ptr %slot34, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %v2278 = load i64, ptr %slot289, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %v2280 = load i64, ptr %slot290, align 8
  %call2281 = call i32 @myl_native_bytes_buffer_append_byte(ptr %p2277, ptr %p2279, i64 %v2280) nomerge, !dbg !124
  store i32 %call2281, ptr %slot297, align 8
  %v2282 = load i32, ptr %slot297, align 8
  %ext2283 = zext i32 %v2282 to i64
  store i64 %ext2283, ptr %slot298, align 8
  %v2284 = load i64, ptr %slot298, align 8
  %cmp2285 = icmp ne i64 %v2284, 0
  %cv2286 = zext i1 %cmp2285 to i64
  store i64 %cv2286, ptr %slot299, align 8
  %v2287 = load i64, ptr %slot299, align 8
  %cond2288 = icmp ne i64 %v2287, 0
  br i1 %cond2288, label %bb_success427, label %bb_failed427
bb_failed427:
  %v2289 = load i64, ptr %slot1, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2290) nomerge, !dbg !124
  unreachable
bb_success427:
  %v2291 = load i32, ptr %slot297, align 8
  %cmp2292 = icmp eq i32 %v2291, 1
  %cv2293 = zext i1 %cmp2292 to i32
  store i32 %cv2293, ptr %slot300, align 8
  %v2294 = load i32, ptr %slot300, align 8
  %ext2295 = zext i32 %v2294 to i64
  store i64 %ext2295, ptr %slot301, align 8
  %v2296 = load i64, ptr %slot301, align 8
  %v2297 = load i64, ptr %slot31, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 %v2296, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done417
bb_byte_fast417:
  %v2299 = load i64, ptr %slot289, align 8
  %op2300 = add i64 %v2299, 32
  store i64 %op2300, ptr %slot302, align 8
  %v2301 = load i64, ptr %slot302, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  %ld2303 = load i64, ptr %p2302, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2303, ptr %slot303, align 8
  %v2304 = load i64, ptr %slot303, align 8
  %v2305 = load i64, ptr %slot294, align 8
  %op2306 = add i64 %v2304, %v2305
  store i64 %op2306, ptr %slot304, align 8
  %v2307 = load i64, ptr %slot290, align 8
  %cv2308 = trunc i64 %v2307 to i8
  %v2309 = load i64, ptr %slot303, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  %v2311 = load i64, ptr %slot294, align 8
  %egep2312 = getelementptr i8, ptr %p2310, i64 %v2311
  store i8 %cv2308, ptr %egep2312, align 1, !alias.scope !12, !noalias !13
  %v2313 = load i64, ptr %slot294, align 8
  %op2314 = add i64 %v2313, 1
  store i64 %op2314, ptr %slot305, align 8
  %v2315 = load i64, ptr %slot305, align 8
  %v2316 = load i64, ptr %slot289, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  store i64 %v2315, ptr %p2317, align 8, !alias.scope !6, !noalias !7
  %v2318 = load i64, ptr %slot31, align 8
  %p2319 = inttoptr i64 %v2318 to ptr
  store i64 1, ptr %p2319, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done417
bb_byte_refused417:
  %v2320 = load i64, ptr %slot31, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  store i64 0, ptr %p2321, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done417
bb_byte_done417:
  %v2322 = load i64, ptr %slot31, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  store i64 0, ptr %p2323, align 8, !alias.scope !3, !noalias !4
  %v2324 = load i64, ptr %slot31, align 8
  %p2325 = inttoptr i64 %v2324 to ptr
  %ld2326 = load i64, ptr %p2325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2326, ptr %slot306, align 8
  %v2327 = load i64, ptr %slot18, align 8
  %p2329 = inttoptr i64 %v2327 to ptr
  %gep2330 = getelementptr i8, ptr %p2329, i64 24
  %op2328 = ptrtoint ptr %gep2330 to i64
  store i64 %op2328, ptr %slot307, align 8
  %v2331 = load i64, ptr %slot307, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i32, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2333, ptr %slot308, align 8
  %v2334 = load i64, ptr %slot20, align 8
  %p2336 = inttoptr i64 %v2334 to ptr
  %gep2337 = getelementptr i8, ptr %p2336, i64 24
  %op2335 = ptrtoint ptr %gep2337 to i64
  store i64 %op2335, ptr %slot309, align 8
  %v2338 = load i64, ptr %slot309, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %ld2340 = load i32, ptr %p2339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2340, ptr %slot310, align 8
  %v2341 = load i32, ptr %slot308, align 8
  %v2342 = load i32, ptr %slot310, align 8
  %op2343 = or i32 %v2341, %v2342
  store i32 %op2343, ptr %slot311, align 8
  %v2344 = load i32, ptr %slot311, align 8
  %cv2345 = zext i32 %v2344 to i64
  %cond2346 = icmp ne i64 %cv2345, 0
  br i1 %cond2346, label %bb_rcscopesopen440, label %bb_rcscopesclosed440
bb_rcscopesopen440:
  %v2347 = load i64, ptr %slot22, align 8
  %p2349 = inttoptr i64 %v2347 to ptr
  %gep2350 = getelementptr i8, ptr %p2349, i64 0
  %op2348 = ptrtoint ptr %gep2350 to i64
  store i64 %op2348, ptr %slot312, align 8
  %v2351 = load i64, ptr %slot18, align 8
  %v2352 = load i64, ptr %slot312, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  store i64 %v2351, ptr %p2353, align 8, !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot22, align 8
  %p2356 = inttoptr i64 %v2354 to ptr
  %gep2357 = getelementptr i8, ptr %p2356, i64 8
  %op2355 = ptrtoint ptr %gep2357 to i64
  store i64 %op2355, ptr %slot313, align 8
  %v2358 = load i64, ptr %slot20, align 8
  %v2359 = load i64, ptr %slot313, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  store i64 %v2358, ptr %p2360, align 8, !alias.scope !3, !noalias !4
  %v2361 = load i64, ptr %slot1, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  %v2363 = load i64, ptr %slot22, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p2362, ptr %p2364, i64 2) nomerge, !dbg !126
  br label %bb_rcscopesclosed440
bb_rcscopesclosed440:
  %v2365 = load i64, ptr %slot11, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i32, ptr %p2366, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2367, ptr %slot314, align 8
  %v2368 = load i32, ptr %slot314, align 8
  %cv2369 = zext i32 %v2368 to i64
  %cond2370 = icmp ne i64 %cv2369, 0
  br i1 %cond2370, label %bb_rcslotdrop445, label %bb_rcslotdone445
bb_rcslotdrop445:
  %v2371 = load i64, ptr %slot11, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  store i32 0, ptr %p2372, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone445
bb_rcslotdone445:
  %v2373 = load i64, ptr %slot9, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %ld2375 = load i32, ptr %p2374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2375, ptr %slot315, align 8
  %v2376 = load i32, ptr %slot315, align 8
  %cv2377 = zext i32 %v2376 to i64
  %cond2378 = icmp ne i64 %cv2377, 0
  br i1 %cond2378, label %bb_rcslotdrop448, label %bb_rcslotdone448
bb_rcslotdrop448:
  %v2379 = load i64, ptr %slot9, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i32 0, ptr %p2380, align 4, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot29, align 8
  store i64 %v2381, ptr %slot316, align 8
  %v2382 = load i64, ptr %slot10, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i32, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2384, ptr %slot317, align 8
  %v2385 = load i32, ptr %slot317, align 8
  %op2386 = and i32 %v2385, 28
  store i32 %op2386, ptr %slot318, align 8
  %v2387 = load i32, ptr %slot318, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcslotrole448, label %bb_rcslotowner448
bb_rcslotrole448:
  %v2390 = load i64, ptr %slot34, align 8
  store i64 %v2390, ptr %slot319, align 8
  %v2391 = load i64, ptr %slot316, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  %ld2393 = load i64, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2393, ptr %slot320, align 8
  %v2394 = load i64, ptr %slot320, align 8
  %cmp2395 = icmp ne i64 %v2394, 0
  %cv2396 = zext i1 %cmp2395 to i32
  store i32 %cv2396, ptr %slot321, align 8
  %v2397 = load i32, ptr %slot321, align 8
  %cv2398 = zext i32 %v2397 to i64
  %cond2399 = icmp ne i64 %cv2398, 0
  br i1 %cond2399, label %bb_rcgnn464, label %bb_rcgdone464
bb_rcgnn464:
  %v2400 = load i64, ptr %slot320, align 8
  %op2401 = sub i64 %v2400, 16
  store i64 %op2401, ptr %slot322, align 8
  %v2402 = load i64, ptr %slot320, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  %rgep2404 = getelementptr i8, ptr %p2403, i64 -16
  %ld2405 = load i64, ptr %rgep2404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2405, ptr %slot323, align 8
  %v2406 = load i64, ptr %slot323, align 8
  %op2407 = and i64 %v2406, 4611686018427387906
  store i64 %op2407, ptr %slot324, align 8
  %v2408 = load i64, ptr %slot324, align 8
  %cmp2409 = icmp ne i64 %v2408, 0
  %cv2410 = zext i1 %cmp2409 to i32
  store i32 %cv2410, ptr %slot325, align 8
  %v2411 = load i32, ptr %slot325, align 8
  %cv2412 = zext i32 %v2411 to i64
  %cond2413 = icmp ne i64 %cv2412, 0
  br i1 %cond2413, label %bb_rcgclear464, label %bb_rcgcounted464
bb_rcgcounted464:
  %v2414 = load i64, ptr %slot320, align 8
  %op2415 = sub i64 %v2414, 24
  store i64 %op2415, ptr %slot326, align 8
  %v2416 = load i64, ptr %slot320, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %rgep2418 = getelementptr i8, ptr %p2417, i64 -24
  %ld2419 = load i64, ptr %rgep2418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2419, ptr %slot327, align 8
  %v2420 = load i64, ptr %slot327, align 8
  %op2421 = sub i64 %v2420, 1
  store i64 %op2421, ptr %slot328, align 8
  %v2422 = load i64, ptr %slot328, align 8
  %cmp2423 = icmp eq i64 %v2422, 0
  %cv2424 = zext i1 %cmp2423 to i32
  store i32 %cv2424, ptr %slot329, align 8
  %v2425 = load i32, ptr %slot329, align 8
  %cv2426 = zext i32 %v2425 to i64
  %cond2427 = icmp ne i64 %cv2426, 0
  br i1 %cond2427, label %bb_rcglast464, label %bb_rcgdec464
bb_rcglast464:
  %v2428 = load i64, ptr %slot320, align 8
  %op2429 = sub i64 %v2428, 32
  store i64 %op2429, ptr %slot330, align 8
  %v2430 = load i64, ptr %slot320, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %rgep2432 = getelementptr i8, ptr %p2431, i64 -32
  %ld2433 = load i64, ptr %rgep2432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2433, ptr %slot331, align 8
  %v2434 = load i64, ptr %slot331, align 8
  %cmp2435 = icmp ne i64 %v2434, 0
  %cv2436 = zext i1 %cmp2435 to i32
  store i32 %cv2436, ptr %slot332, align 8
  %v2437 = load i32, ptr %slot332, align 8
  %cv2438 = zext i32 %v2437 to i64
  %cond2439 = icmp ne i64 %cv2438, 0
  br i1 %cond2439, label %bb_rcgdec464, label %bb_rcgslow464
bb_rcgslow464:
  %v2440 = load i64, ptr %slot319, align 8
  %v2441 = load i64, ptr %slot316, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2440, i64 %v2441) nomerge, !dbg !126
  br label %bb_rcgdone464
bb_rcgdec464:
  %v2442 = load i64, ptr %slot328, align 8
  %v2443 = load i64, ptr %slot320, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %rgep2445 = getelementptr i8, ptr %p2444, i64 -24
  store i64 %v2442, ptr %rgep2445, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear464
bb_rcgclear464:
  %v2446 = load i64, ptr %slot316, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i64 0, ptr %p2447, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone464
bb_rcgdone464:
  br label %bb_rcslotdone448
bb_rcslotowner448:
  %v2448 = load i64, ptr %slot34, align 8
  store i64 %v2448, ptr %slot333, align 8
  %v2449 = load i64, ptr %slot316, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  %ld2451 = load i64, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2451, ptr %slot334, align 8
  %v2452 = load i64, ptr %slot334, align 8
  %cmp2453 = icmp ne i64 %v2452, 0
  %cv2454 = zext i1 %cmp2453 to i32
  store i32 %cv2454, ptr %slot335, align 8
  %v2455 = load i32, ptr %slot335, align 8
  %cv2456 = zext i32 %v2455 to i64
  %cond2457 = icmp ne i64 %cv2456, 0
  br i1 %cond2457, label %bb_rcgnn479, label %bb_rcgdone479
bb_rcgnn479:
  %v2458 = load i64, ptr %slot334, align 8
  %op2459 = sub i64 %v2458, 16
  store i64 %op2459, ptr %slot336, align 8
  %v2460 = load i64, ptr %slot334, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %rgep2462 = getelementptr i8, ptr %p2461, i64 -16
  %ld2463 = load i64, ptr %rgep2462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2463, ptr %slot337, align 8
  %v2464 = load i64, ptr %slot337, align 8
  %op2465 = and i64 %v2464, 4611686018427387906
  store i64 %op2465, ptr %slot338, align 8
  %v2466 = load i64, ptr %slot338, align 8
  %cmp2467 = icmp ne i64 %v2466, 0
  %cv2468 = zext i1 %cmp2467 to i32
  store i32 %cv2468, ptr %slot339, align 8
  %v2469 = load i32, ptr %slot339, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rcgclear479, label %bb_rcgcounted479
bb_rcgcounted479:
  %v2472 = load i64, ptr %slot334, align 8
  %op2473 = sub i64 %v2472, 32
  store i64 %op2473, ptr %slot340, align 8
  %v2474 = load i64, ptr %slot334, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %rgep2476 = getelementptr i8, ptr %p2475, i64 -32
  %ld2477 = load i64, ptr %rgep2476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2477, ptr %slot341, align 8
  %v2478 = load i64, ptr %slot341, align 8
  %op2479 = sub i64 %v2478, 1
  store i64 %op2479, ptr %slot342, align 8
  %v2480 = load i64, ptr %slot342, align 8
  %cmp2481 = icmp eq i64 %v2480, 0
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot343, align 8
  %v2483 = load i32, ptr %slot343, align 8
  %cv2484 = zext i32 %v2483 to i64
  %cond2485 = icmp ne i64 %cv2484, 0
  br i1 %cond2485, label %bb_rcglast479, label %bb_rcgdec479
bb_rcglast479:
  %v2486 = load i64, ptr %slot334, align 8
  %op2487 = sub i64 %v2486, 24
  store i64 %op2487, ptr %slot344, align 8
  %v2488 = load i64, ptr %slot334, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  %rgep2490 = getelementptr i8, ptr %p2489, i64 -24
  %ld2491 = load i64, ptr %rgep2490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2491, ptr %slot345, align 8
  %v2492 = load i64, ptr %slot345, align 8
  %cmp2493 = icmp ne i64 %v2492, 0
  %cv2494 = zext i1 %cmp2493 to i32
  store i32 %cv2494, ptr %slot346, align 8
  %v2495 = load i32, ptr %slot346, align 8
  %cv2496 = zext i32 %v2495 to i64
  %cond2497 = icmp ne i64 %cv2496, 0
  br i1 %cond2497, label %bb_rcgdec479, label %bb_rcgslow479
bb_rcgslow479:
  %v2498 = load i64, ptr %slot333, align 8
  %v2499 = load i64, ptr %slot316, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2498, i64 %v2499) nomerge, !dbg !126
  br label %bb_rcgdone479
bb_rcgdec479:
  %v2500 = load i64, ptr %slot342, align 8
  %v2501 = load i64, ptr %slot334, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  %rgep2503 = getelementptr i8, ptr %p2502, i64 -32
  store i64 %v2500, ptr %rgep2503, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear479
bb_rcgclear479:
  %v2504 = load i64, ptr %slot316, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  store i64 0, ptr %p2505, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone479
bb_rcgdone479:
  br label %bb_rcslotdone448
bb_rcslotdone448:
  %v2506 = load i64, ptr %slot7, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %ld2508 = load i32, ptr %p2507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2508, ptr %slot347, align 8
  %v2509 = load i32, ptr %slot347, align 8
  %cv2510 = zext i32 %v2509 to i64
  %cond2511 = icmp ne i64 %cv2510, 0
  br i1 %cond2511, label %bb_rcslotdrop485, label %bb_rcslotdone485
bb_rcslotdrop485:
  %v2512 = load i64, ptr %slot7, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i32 0, ptr %p2513, align 4, !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot28, align 8
  store i64 %v2514, ptr %slot348, align 8
  %v2515 = load i64, ptr %slot8, align 8
  %p2516 = inttoptr i64 %v2515 to ptr
  %ld2517 = load i32, ptr %p2516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2517, ptr %slot349, align 8
  %v2518 = load i32, ptr %slot349, align 8
  %op2519 = and i32 %v2518, 28
  store i32 %op2519, ptr %slot350, align 8
  %v2520 = load i32, ptr %slot350, align 8
  %cv2521 = zext i32 %v2520 to i64
  %cond2522 = icmp ne i64 %cv2521, 0
  br i1 %cond2522, label %bb_rcslotrole485, label %bb_rcslotowner485
bb_rcslotrole485:
  %v2523 = load i64, ptr %slot34, align 8
  store i64 %v2523, ptr %slot351, align 8
  %v2524 = load i64, ptr %slot348, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %ld2526 = load i64, ptr %p2525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2526, ptr %slot352, align 8
  %v2527 = load i64, ptr %slot352, align 8
  %cmp2528 = icmp ne i64 %v2527, 0
  %cv2529 = zext i1 %cmp2528 to i32
  store i32 %cv2529, ptr %slot353, align 8
  %v2530 = load i32, ptr %slot353, align 8
  %cv2531 = zext i32 %v2530 to i64
  %cond2532 = icmp ne i64 %cv2531, 0
  br i1 %cond2532, label %bb_rcgnn501, label %bb_rcgdone501
bb_rcgnn501:
  %v2533 = load i64, ptr %slot352, align 8
  %op2534 = sub i64 %v2533, 16
  store i64 %op2534, ptr %slot354, align 8
  %v2535 = load i64, ptr %slot352, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  %rgep2537 = getelementptr i8, ptr %p2536, i64 -16
  %ld2538 = load i64, ptr %rgep2537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2538, ptr %slot355, align 8
  %v2539 = load i64, ptr %slot355, align 8
  %op2540 = and i64 %v2539, 4611686018427387906
  store i64 %op2540, ptr %slot356, align 8
  %v2541 = load i64, ptr %slot356, align 8
  %cmp2542 = icmp ne i64 %v2541, 0
  %cv2543 = zext i1 %cmp2542 to i32
  store i32 %cv2543, ptr %slot357, align 8
  %v2544 = load i32, ptr %slot357, align 8
  %cv2545 = zext i32 %v2544 to i64
  %cond2546 = icmp ne i64 %cv2545, 0
  br i1 %cond2546, label %bb_rcgclear501, label %bb_rcgcounted501
bb_rcgcounted501:
  %v2547 = load i64, ptr %slot352, align 8
  %op2548 = sub i64 %v2547, 24
  store i64 %op2548, ptr %slot358, align 8
  %v2549 = load i64, ptr %slot352, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %rgep2551 = getelementptr i8, ptr %p2550, i64 -24
  %ld2552 = load i64, ptr %rgep2551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2552, ptr %slot359, align 8
  %v2553 = load i64, ptr %slot359, align 8
  %op2554 = sub i64 %v2553, 1
  store i64 %op2554, ptr %slot360, align 8
  %v2555 = load i64, ptr %slot360, align 8
  %cmp2556 = icmp eq i64 %v2555, 0
  %cv2557 = zext i1 %cmp2556 to i32
  store i32 %cv2557, ptr %slot361, align 8
  %v2558 = load i32, ptr %slot361, align 8
  %cv2559 = zext i32 %v2558 to i64
  %cond2560 = icmp ne i64 %cv2559, 0
  br i1 %cond2560, label %bb_rcglast501, label %bb_rcgdec501
bb_rcglast501:
  %v2561 = load i64, ptr %slot352, align 8
  %op2562 = sub i64 %v2561, 32
  store i64 %op2562, ptr %slot362, align 8
  %v2563 = load i64, ptr %slot352, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %rgep2565 = getelementptr i8, ptr %p2564, i64 -32
  %ld2566 = load i64, ptr %rgep2565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2566, ptr %slot363, align 8
  %v2567 = load i64, ptr %slot363, align 8
  %cmp2568 = icmp ne i64 %v2567, 0
  %cv2569 = zext i1 %cmp2568 to i32
  store i32 %cv2569, ptr %slot364, align 8
  %v2570 = load i32, ptr %slot364, align 8
  %cv2571 = zext i32 %v2570 to i64
  %cond2572 = icmp ne i64 %cv2571, 0
  br i1 %cond2572, label %bb_rcgdec501, label %bb_rcgslow501
bb_rcgslow501:
  %v2573 = load i64, ptr %slot351, align 8
  %v2574 = load i64, ptr %slot348, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2573, i64 %v2574) nomerge, !dbg !126
  br label %bb_rcgdone501
bb_rcgdec501:
  %v2575 = load i64, ptr %slot360, align 8
  %v2576 = load i64, ptr %slot352, align 8
  %p2577 = inttoptr i64 %v2576 to ptr
  %rgep2578 = getelementptr i8, ptr %p2577, i64 -24
  store i64 %v2575, ptr %rgep2578, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear501
bb_rcgclear501:
  %v2579 = load i64, ptr %slot348, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i64 0, ptr %p2580, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone501
bb_rcgdone501:
  br label %bb_rcslotdone485
bb_rcslotowner485:
  %v2581 = load i64, ptr %slot34, align 8
  store i64 %v2581, ptr %slot365, align 8
  %v2582 = load i64, ptr %slot348, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %ld2584 = load i64, ptr %p2583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2584, ptr %slot366, align 8
  %v2585 = load i64, ptr %slot366, align 8
  %cmp2586 = icmp ne i64 %v2585, 0
  %cv2587 = zext i1 %cmp2586 to i32
  store i32 %cv2587, ptr %slot367, align 8
  %v2588 = load i32, ptr %slot367, align 8
  %cv2589 = zext i32 %v2588 to i64
  %cond2590 = icmp ne i64 %cv2589, 0
  br i1 %cond2590, label %bb_rcgnn516, label %bb_rcgdone516
bb_rcgnn516:
  %v2591 = load i64, ptr %slot366, align 8
  %op2592 = sub i64 %v2591, 16
  store i64 %op2592, ptr %slot368, align 8
  %v2593 = load i64, ptr %slot366, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %rgep2595 = getelementptr i8, ptr %p2594, i64 -16
  %ld2596 = load i64, ptr %rgep2595, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2596, ptr %slot369, align 8
  %v2597 = load i64, ptr %slot369, align 8
  %op2598 = and i64 %v2597, 4611686018427387906
  store i64 %op2598, ptr %slot370, align 8
  %v2599 = load i64, ptr %slot370, align 8
  %cmp2600 = icmp ne i64 %v2599, 0
  %cv2601 = zext i1 %cmp2600 to i32
  store i32 %cv2601, ptr %slot371, align 8
  %v2602 = load i32, ptr %slot371, align 8
  %cv2603 = zext i32 %v2602 to i64
  %cond2604 = icmp ne i64 %cv2603, 0
  br i1 %cond2604, label %bb_rcgclear516, label %bb_rcgcounted516
bb_rcgcounted516:
  %v2605 = load i64, ptr %slot366, align 8
  %op2606 = sub i64 %v2605, 32
  store i64 %op2606, ptr %slot372, align 8
  %v2607 = load i64, ptr %slot366, align 8
  %p2608 = inttoptr i64 %v2607 to ptr
  %rgep2609 = getelementptr i8, ptr %p2608, i64 -32
  %ld2610 = load i64, ptr %rgep2609, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2610, ptr %slot373, align 8
  %v2611 = load i64, ptr %slot373, align 8
  %op2612 = sub i64 %v2611, 1
  store i64 %op2612, ptr %slot374, align 8
  %v2613 = load i64, ptr %slot374, align 8
  %cmp2614 = icmp eq i64 %v2613, 0
  %cv2615 = zext i1 %cmp2614 to i32
  store i32 %cv2615, ptr %slot375, align 8
  %v2616 = load i32, ptr %slot375, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcglast516, label %bb_rcgdec516
bb_rcglast516:
  %v2619 = load i64, ptr %slot366, align 8
  %op2620 = sub i64 %v2619, 24
  store i64 %op2620, ptr %slot376, align 8
  %v2621 = load i64, ptr %slot366, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %rgep2623 = getelementptr i8, ptr %p2622, i64 -24
  %ld2624 = load i64, ptr %rgep2623, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2624, ptr %slot377, align 8
  %v2625 = load i64, ptr %slot377, align 8
  %cmp2626 = icmp ne i64 %v2625, 0
  %cv2627 = zext i1 %cmp2626 to i32
  store i32 %cv2627, ptr %slot378, align 8
  %v2628 = load i32, ptr %slot378, align 8
  %cv2629 = zext i32 %v2628 to i64
  %cond2630 = icmp ne i64 %cv2629, 0
  br i1 %cond2630, label %bb_rcgdec516, label %bb_rcgslow516
bb_rcgslow516:
  %v2631 = load i64, ptr %slot365, align 8
  %v2632 = load i64, ptr %slot348, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2631, i64 %v2632) nomerge, !dbg !126
  br label %bb_rcgdone516
bb_rcgdec516:
  %v2633 = load i64, ptr %slot374, align 8
  %v2634 = load i64, ptr %slot366, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  %rgep2636 = getelementptr i8, ptr %p2635, i64 -32
  store i64 %v2633, ptr %rgep2636, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear516
bb_rcgclear516:
  %v2637 = load i64, ptr %slot348, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i64 0, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone516
bb_rcgdone516:
  br label %bb_rcslotdone485
bb_rcslotdone485:
  %v2639 = load i64, ptr %slot5, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  %ld2641 = load i32, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2641, ptr %slot379, align 8
  %v2642 = load i32, ptr %slot379, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcslotdrop522, label %bb_rcslotdone522
bb_rcslotdrop522:
  %v2645 = load i64, ptr %slot5, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i32 0, ptr %p2646, align 4, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot27, align 8
  store i64 %v2647, ptr %slot380, align 8
  %v2648 = load i64, ptr %slot6, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %ld2650 = load i32, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2650, ptr %slot381, align 8
  %v2651 = load i32, ptr %slot381, align 8
  %op2652 = and i32 %v2651, 28
  store i32 %op2652, ptr %slot382, align 8
  %v2653 = load i32, ptr %slot382, align 8
  %cv2654 = zext i32 %v2653 to i64
  %cond2655 = icmp ne i64 %cv2654, 0
  br i1 %cond2655, label %bb_rcslotrole522, label %bb_rcslotowner522
bb_rcslotrole522:
  %v2656 = load i64, ptr %slot34, align 8
  store i64 %v2656, ptr %slot383, align 8
  %v2657 = load i64, ptr %slot380, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  %ld2659 = load i64, ptr %p2658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2659, ptr %slot384, align 8
  %v2660 = load i64, ptr %slot384, align 8
  %cmp2661 = icmp ne i64 %v2660, 0
  %cv2662 = zext i1 %cmp2661 to i32
  store i32 %cv2662, ptr %slot385, align 8
  %v2663 = load i32, ptr %slot385, align 8
  %cv2664 = zext i32 %v2663 to i64
  %cond2665 = icmp ne i64 %cv2664, 0
  br i1 %cond2665, label %bb_rcgnn538, label %bb_rcgdone538
bb_rcgnn538:
  %v2666 = load i64, ptr %slot384, align 8
  %op2667 = sub i64 %v2666, 16
  store i64 %op2667, ptr %slot386, align 8
  %v2668 = load i64, ptr %slot384, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  %rgep2670 = getelementptr i8, ptr %p2669, i64 -16
  %ld2671 = load i64, ptr %rgep2670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2671, ptr %slot387, align 8
  %v2672 = load i64, ptr %slot387, align 8
  %op2673 = and i64 %v2672, 4611686018427387906
  store i64 %op2673, ptr %slot388, align 8
  %v2674 = load i64, ptr %slot388, align 8
  %cmp2675 = icmp ne i64 %v2674, 0
  %cv2676 = zext i1 %cmp2675 to i32
  store i32 %cv2676, ptr %slot389, align 8
  %v2677 = load i32, ptr %slot389, align 8
  %cv2678 = zext i32 %v2677 to i64
  %cond2679 = icmp ne i64 %cv2678, 0
  br i1 %cond2679, label %bb_rcgclear538, label %bb_rcgcounted538
bb_rcgcounted538:
  %v2680 = load i64, ptr %slot384, align 8
  %op2681 = sub i64 %v2680, 24
  store i64 %op2681, ptr %slot390, align 8
  %v2682 = load i64, ptr %slot384, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  %rgep2684 = getelementptr i8, ptr %p2683, i64 -24
  %ld2685 = load i64, ptr %rgep2684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2685, ptr %slot391, align 8
  %v2686 = load i64, ptr %slot391, align 8
  %op2687 = sub i64 %v2686, 1
  store i64 %op2687, ptr %slot392, align 8
  %v2688 = load i64, ptr %slot392, align 8
  %cmp2689 = icmp eq i64 %v2688, 0
  %cv2690 = zext i1 %cmp2689 to i32
  store i32 %cv2690, ptr %slot393, align 8
  %v2691 = load i32, ptr %slot393, align 8
  %cv2692 = zext i32 %v2691 to i64
  %cond2693 = icmp ne i64 %cv2692, 0
  br i1 %cond2693, label %bb_rcglast538, label %bb_rcgdec538
bb_rcglast538:
  %v2694 = load i64, ptr %slot384, align 8
  %op2695 = sub i64 %v2694, 32
  store i64 %op2695, ptr %slot394, align 8
  %v2696 = load i64, ptr %slot384, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %rgep2698 = getelementptr i8, ptr %p2697, i64 -32
  %ld2699 = load i64, ptr %rgep2698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2699, ptr %slot395, align 8
  %v2700 = load i64, ptr %slot395, align 8
  %cmp2701 = icmp ne i64 %v2700, 0
  %cv2702 = zext i1 %cmp2701 to i32
  store i32 %cv2702, ptr %slot396, align 8
  %v2703 = load i32, ptr %slot396, align 8
  %cv2704 = zext i32 %v2703 to i64
  %cond2705 = icmp ne i64 %cv2704, 0
  br i1 %cond2705, label %bb_rcgdec538, label %bb_rcgslow538
bb_rcgslow538:
  %v2706 = load i64, ptr %slot383, align 8
  %v2707 = load i64, ptr %slot380, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2706, i64 %v2707) nomerge, !dbg !126
  br label %bb_rcgdone538
bb_rcgdec538:
  %v2708 = load i64, ptr %slot392, align 8
  %v2709 = load i64, ptr %slot384, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %rgep2711 = getelementptr i8, ptr %p2710, i64 -24
  store i64 %v2708, ptr %rgep2711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear538
bb_rcgclear538:
  %v2712 = load i64, ptr %slot380, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  store i64 0, ptr %p2713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone538
bb_rcgdone538:
  br label %bb_rcslotdone522
bb_rcslotowner522:
  %v2714 = load i64, ptr %slot34, align 8
  store i64 %v2714, ptr %slot397, align 8
  %v2715 = load i64, ptr %slot380, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %ld2717 = load i64, ptr %p2716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2717, ptr %slot398, align 8
  %v2718 = load i64, ptr %slot398, align 8
  %cmp2719 = icmp ne i64 %v2718, 0
  %cv2720 = zext i1 %cmp2719 to i32
  store i32 %cv2720, ptr %slot399, align 8
  %v2721 = load i32, ptr %slot399, align 8
  %cv2722 = zext i32 %v2721 to i64
  %cond2723 = icmp ne i64 %cv2722, 0
  br i1 %cond2723, label %bb_rcgnn553, label %bb_rcgdone553
bb_rcgnn553:
  %v2724 = load i64, ptr %slot398, align 8
  %op2725 = sub i64 %v2724, 16
  store i64 %op2725, ptr %slot400, align 8
  %v2726 = load i64, ptr %slot398, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  %rgep2728 = getelementptr i8, ptr %p2727, i64 -16
  %ld2729 = load i64, ptr %rgep2728, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2729, ptr %slot401, align 8
  %v2730 = load i64, ptr %slot401, align 8
  %op2731 = and i64 %v2730, 4611686018427387906
  store i64 %op2731, ptr %slot402, align 8
  %v2732 = load i64, ptr %slot402, align 8
  %cmp2733 = icmp ne i64 %v2732, 0
  %cv2734 = zext i1 %cmp2733 to i32
  store i32 %cv2734, ptr %slot403, align 8
  %v2735 = load i32, ptr %slot403, align 8
  %cv2736 = zext i32 %v2735 to i64
  %cond2737 = icmp ne i64 %cv2736, 0
  br i1 %cond2737, label %bb_rcgclear553, label %bb_rcgcounted553
bb_rcgcounted553:
  %v2738 = load i64, ptr %slot398, align 8
  %op2739 = sub i64 %v2738, 32
  store i64 %op2739, ptr %slot404, align 8
  %v2740 = load i64, ptr %slot398, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  %rgep2742 = getelementptr i8, ptr %p2741, i64 -32
  %ld2743 = load i64, ptr %rgep2742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2743, ptr %slot405, align 8
  %v2744 = load i64, ptr %slot405, align 8
  %op2745 = sub i64 %v2744, 1
  store i64 %op2745, ptr %slot406, align 8
  %v2746 = load i64, ptr %slot406, align 8
  %cmp2747 = icmp eq i64 %v2746, 0
  %cv2748 = zext i1 %cmp2747 to i32
  store i32 %cv2748, ptr %slot407, align 8
  %v2749 = load i32, ptr %slot407, align 8
  %cv2750 = zext i32 %v2749 to i64
  %cond2751 = icmp ne i64 %cv2750, 0
  br i1 %cond2751, label %bb_rcglast553, label %bb_rcgdec553
bb_rcglast553:
  %v2752 = load i64, ptr %slot398, align 8
  %op2753 = sub i64 %v2752, 24
  store i64 %op2753, ptr %slot408, align 8
  %v2754 = load i64, ptr %slot398, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  %rgep2756 = getelementptr i8, ptr %p2755, i64 -24
  %ld2757 = load i64, ptr %rgep2756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2757, ptr %slot409, align 8
  %v2758 = load i64, ptr %slot409, align 8
  %cmp2759 = icmp ne i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot410, align 8
  %v2761 = load i32, ptr %slot410, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcgdec553, label %bb_rcgslow553
bb_rcgslow553:
  %v2764 = load i64, ptr %slot397, align 8
  %v2765 = load i64, ptr %slot380, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2764, i64 %v2765) nomerge, !dbg !126
  br label %bb_rcgdone553
bb_rcgdec553:
  %v2766 = load i64, ptr %slot406, align 8
  %v2767 = load i64, ptr %slot398, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  %rgep2769 = getelementptr i8, ptr %p2768, i64 -32
  store i64 %v2766, ptr %rgep2769, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear553
bb_rcgclear553:
  %v2770 = load i64, ptr %slot380, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  store i64 0, ptr %p2771, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone553
bb_rcgdone553:
  br label %bb_rcslotdone522
bb_rcslotdone522:
  %v2772 = load i64, ptr %slot306, align 8
  ret i64 %v2772
bb_i20:
  %v2773 = load i64, ptr %slot31, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i64 0, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot31, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i64, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2777, ptr %slot411, align 8
  %v2778 = load i64, ptr %slot411, align 8
  %cmp2779 = icmp sge i64 %v2778, 0
  %cv2780 = zext i1 %cmp2779 to i64
  store i64 %cv2780, ptr %slot412, align 8
  %v2781 = load i64, ptr %slot412, align 8
  %cond2782 = icmp ne i64 %v2781, 0
  br i1 %cond2782, label %bb_success679, label %bb_failed679
bb_failed679:
  %v2783 = load i64, ptr %slot1, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p2784) nomerge, !dbg !128
  unreachable
bb_success679:
  %v2785 = load i64, ptr %slot34, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %p2787 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v2788 = load i64, ptr %slot411, align 8
  %call2789 = call ptr @myl_native_list_new(ptr %p2786, ptr %p2787, i64 %v2788) nomerge, !dbg !128
  %calladdr2790 = ptrtoint ptr %call2789 to i64
  store i64 %calladdr2790, ptr %slot413, align 8
  %v2791 = load i64, ptr %slot413, align 8
  %cond2792 = icmp ne i64 %v2791, 0
  br i1 %cond2792, label %bb_success681, label %bb_failed681
bb_failed681:
  %v2793 = load i64, ptr %slot1, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2794) nomerge, !dbg !128
  unreachable
bb_success681:
  %v2795 = load i64, ptr %slot413, align 8
  %v2796 = load i64, ptr %slot31, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  store i64 %v2795, ptr %p2797, align 8, !alias.scope !3, !noalias !4
  %v2798 = load i64, ptr %slot31, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  %ld2800 = load i64, ptr %p2799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2800, ptr %slot414, align 8
  %v2801 = load i64, ptr %slot414, align 8
  %v2802 = load i64, ptr %slot16, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  store i64 %v2801, ptr %p2803, align 8, !alias.scope !3, !noalias !4
  %v2804 = load i64, ptr %slot16, align 8
  store i64 %v2804, ptr %slot415, align 8
  %v2805 = load i64, ptr %slot17, align 8
  store i64 %v2805, ptr %slot416, align 8
  %v2806 = load i64, ptr %slot415, align 8
  %v2807 = load i64, ptr %slot416, align 8
  %p2808 = inttoptr i64 %v2806 to ptr
  %p2809 = inttoptr i64 %v2807 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2809, ptr %p2808, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot14, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 2, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot13, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i32 1, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  %v2814 = load i64, ptr %slot15, align 8
  store i64 %v2814, ptr %slot417, align 8
  %v2815 = load i64, ptr %slot17, align 8
  store i64 %v2815, ptr %slot418, align 8
  %v2816 = load i64, ptr %slot418, align 8
  %v2817 = load i64, ptr %slot417, align 8
  %p2818 = inttoptr i64 %v2816 to ptr
  %p2819 = inttoptr i64 %v2817 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2819, ptr %p2818, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2820 = load i64, ptr %slot12, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  store i32 2, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  %v2822 = load i64, ptr %slot14, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %ld2824 = load i32, ptr %p2823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2824, ptr %slot419, align 8
  %v2825 = load i32, ptr %slot419, align 8
  %v2826 = load i64, ptr %slot12, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i32 %v2825, ptr %p2827, align 4, !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot13, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  store i32 0, ptr %p2829, align 4, !alias.scope !3, !noalias !4
  %v2830 = load i64, ptr %slot11, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i32 1, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot417, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i64, ptr %p2833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2834, ptr %slot420, align 8
  %v2835 = load i64, ptr %slot420, align 8
  %v2836 = load i64, ptr %slot31, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  store i64 %v2835, ptr %p2837, align 8, !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot31, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  %ld2840 = load i64, ptr %p2839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2840, ptr %slot421, align 8
  %v2841 = load i64, ptr %slot421, align 8
  %v2842 = load i64, ptr %slot16, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  store i64 %v2841, ptr %p2843, align 8, !alias.scope !3, !noalias !4
  %v2844 = load i64, ptr %slot16, align 8
  store i64 %v2844, ptr %slot422, align 8
  %v2845 = load i64, ptr %slot11, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  %ld2847 = load i32, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2847, ptr %slot423, align 8
  %v2848 = load i64, ptr %slot12, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  %ld2850 = load i32, ptr %p2849, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2850, ptr %slot424, align 8
  %v2851 = load i32, ptr %slot424, align 8
  %op2852 = and i32 %v2851, 24
  store i32 %op2852, ptr %slot424, align 8
  %v2853 = load i32, ptr %slot424, align 8
  %cmp2854 = icmp eq i32 %v2853, 0
  %cv2855 = zext i1 %cmp2854 to i32
  store i32 %cv2855, ptr %slot425, align 8
  %v2856 = load i32, ptr %slot423, align 8
  %v2857 = load i32, ptr %slot425, align 8
  %op2858 = and i32 %v2856, %v2857
  store i32 %op2858, ptr %slot426, align 8
  %v2859 = load i32, ptr %slot426, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcprivateown704, label %bb_rcprivateloan704
bb_rcprivateown704:
  %v2862 = load i64, ptr %slot17, align 8
  store i64 %v2862, ptr %slot427, align 8
  %v2863 = load i64, ptr %slot35, align 8
  store i64 %v2863, ptr %slot428, align 8
  %v2864 = load i64, ptr %slot422, align 8
  %v2865 = load i64, ptr %slot427, align 8
  %op2866 = sub i64 %v2864, %v2865
  store i64 %op2866, ptr %slot429, align 8
  %v2867 = load i64, ptr %slot427, align 8
  %v2868 = load i64, ptr %slot422, align 8
  %op2869 = sub i64 %v2867, %v2868
  store i64 %op2869, ptr %slot430, align 8
  %v2870 = load i64, ptr %slot429, align 8
  %cmp2871 = icmp ult i64 %v2870, 8
  %cv2872 = zext i1 %cmp2871 to i32
  store i32 %cv2872, ptr %slot431, align 8
  %v2873 = load i64, ptr %slot430, align 8
  %cmp2874 = icmp ult i64 %v2873, 8
  %cv2875 = zext i1 %cmp2874 to i32
  store i32 %cv2875, ptr %slot432, align 8
  %v2876 = load i32, ptr %slot431, align 8
  %v2877 = load i32, ptr %slot432, align 8
  %op2878 = or i32 %v2876, %v2877
  store i32 %op2878, ptr %slot433, align 8
  %v2879 = load i32, ptr %slot433, align 8
  %cv2880 = zext i32 %v2879 to i64
  %cond2881 = icmp ne i64 %cv2880, 0
  br i1 %cond2881, label %bb_rcmoveslow707, label %bb_rcmovecheck707
bb_rcmovecheck707:
  %v2882 = load i64, ptr %slot422, align 8
  %p2884 = inttoptr i64 %v2882 to ptr
  %gep2885 = getelementptr i8, ptr %p2884, i64 0
  %op2883 = ptrtoint ptr %gep2885 to i64
  store i64 %op2883, ptr %slot434, align 8
  %v2886 = load i64, ptr %slot434, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %ld2888 = load i64, ptr %p2887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2888, ptr %slot435, align 8
  %v2889 = load i64, ptr %slot435, align 8
  %cmp2890 = icmp ne i64 %v2889, 0
  %cv2891 = zext i1 %cmp2890 to i32
  store i32 %cv2891, ptr %slot436, align 8
  %v2892 = load i32, ptr %slot436, align 8
  %cv2893 = zext i32 %v2892 to i64
  %cond2894 = icmp ne i64 %cv2893, 0
  br i1 %cond2894, label %bb_rcmoveheader715, label %bb_rcmovenext715
bb_rcmoveheader715:
  %v2895 = load i64, ptr %slot435, align 8
  %op2896 = sub i64 %v2895, 16
  store i64 %op2896, ptr %slot437, align 8
  %v2897 = load i64, ptr %slot435, align 8
  %p2898 = inttoptr i64 %v2897 to ptr
  %rgep2899 = getelementptr i8, ptr %p2898, i64 -16
  %ld2900 = load i64, ptr %rgep2899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2900, ptr %slot438, align 8
  %v2901 = load i64, ptr %slot438, align 8
  %op2902 = and i64 %v2901, 5764607523034234881
  store i64 %op2902, ptr %slot439, align 8
  %v2903 = load i64, ptr %slot439, align 8
  %cmp2904 = icmp ne i64 %v2903, 0
  %cv2905 = zext i1 %cmp2904 to i32
  store i32 %cv2905, ptr %slot440, align 8
  %v2906 = load i32, ptr %slot440, align 8
  %cv2907 = zext i32 %v2906 to i64
  %cond2908 = icmp ne i64 %cv2907, 0
  br i1 %cond2908, label %bb_rcmoveslow707, label %bb_rcmovenext715
bb_rcmovenext715:
  %v2909 = load i64, ptr %slot422, align 8
  %v2910 = load i64, ptr %slot427, align 8
  %p2911 = inttoptr i64 %v2909 to ptr
  %p2912 = inttoptr i64 %v2910 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2912, ptr %p2911, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2913 = load i64, ptr %slot422, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  store i64 0, ptr %p2914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved707
bb_rcmoveslow707:
  %v2915 = load i64, ptr %slot34, align 8
  %v2916 = load i64, ptr %slot427, align 8
  %v2917 = load i64, ptr %slot422, align 8
  %v2918 = load i64, ptr %slot428, align 8
  %cv2919 = trunc i64 %v2918 to i32
  %call2920 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2915, i64 %v2916, i64 %v2917, i32 %cv2919) nomerge, !dbg !130
  store i32 %call2920, ptr %slot441, align 8
  %v2921 = load i32, ptr %slot441, align 8
  %cv2922 = zext i32 %v2921 to i64
  %cond2923 = icmp ne i64 %cv2922, 0
  br i1 %cond2923, label %bb_rcsuccess722, label %bb_rcfailure722
bb_rcfailure722:
  %v2924 = load i64, ptr %slot34, align 8
  %p2925 = inttoptr i64 %v2924 to ptr
  %call2926 = call i32 @myl_rc_take_failure(ptr %p2925) nomerge, !dbg !130
  store i32 %call2926, ptr %slot442, align 8
  %v2927 = load i64, ptr %slot1, align 8
  %p2928 = inttoptr i64 %v2927 to ptr
  %v2929 = load i32, ptr %slot442, align 8
  %call2930 = call i32 @myl_qbe_rc_status(ptr %p2928, i32 %v2929) nomerge, !dbg !130
  store i32 %call2930, ptr %slot443, align 8
  br label %bb_failure
bb_rcsuccess722:
  br label %bb_rcmoved707
bb_rcmoved707:
  %v2931 = load i64, ptr %slot11, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  store i32 0, ptr %p2932, align 4, !alias.scope !3, !noalias !4
  %v2933 = load i64, ptr %slot14, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  store i32 2, ptr %p2934, align 4, !alias.scope !3, !noalias !4
  %v2935 = load i64, ptr %slot13, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i32 1, ptr %p2936, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared704
bb_rcprivateloan704:
  %v2937 = load i64, ptr %slot11, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %ld2939 = load i32, ptr %p2938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2939, ptr %slot444, align 8
  %v2940 = load i64, ptr %slot12, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %ld2942 = load i32, ptr %p2941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2942, ptr %slot445, align 8
  %v2943 = load i32, ptr %slot445, align 8
  %cmp2944 = icmp eq i32 %v2943, 16
  %cv2945 = zext i1 %cmp2944 to i32
  store i32 %cv2945, ptr %slot446, align 8
  %v2946 = load i32, ptr %slot446, align 8
  %v2947 = load i32, ptr %slot444, align 8
  %op2948 = and i32 %v2946, %v2947
  store i32 %op2948, ptr %slot446, align 8
  %v2949 = load i32, ptr %slot446, align 8
  %cv2950 = zext i32 %v2949 to i64
  %cond2951 = icmp ne i64 %cv2950, 0
  br i1 %cond2951, label %bb_rcprivatemove704, label %bb_rcprivatenew704
bb_rcprivatemove704:
  %v2952 = load i64, ptr %slot17, align 8
  store i64 %v2952, ptr %slot447, align 8
  %v2953 = load i64, ptr %slot422, align 8
  %v2954 = load i64, ptr %slot447, align 8
  %p2955 = inttoptr i64 %v2953 to ptr
  %p2956 = inttoptr i64 %v2954 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2956, ptr %p2955, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2957 = load i64, ptr %slot422, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  store i64 0, ptr %p2958, align 8, !alias.scope !3, !noalias !4
  %v2959 = load i64, ptr %slot14, align 8
  %p2960 = inttoptr i64 %v2959 to ptr
  store i32 2, ptr %p2960, align 4, !alias.scope !3, !noalias !4
  %v2961 = load i64, ptr %slot14, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  store i32 16, ptr %p2962, align 4, !alias.scope !3, !noalias !4
  %v2963 = load i64, ptr %slot13, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  store i32 1, ptr %p2964, align 4, !alias.scope !3, !noalias !4
  %v2965 = load i64, ptr %slot11, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  store i32 0, ptr %p2966, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared704
bb_rcprivatenew704:
  %v2967 = load i64, ptr %slot17, align 8
  store i64 %v2967, ptr %slot448, align 8
  %v2968 = load i64, ptr %slot422, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %ld2970 = load i64, ptr %p2969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2970, ptr %slot449, align 8
  %v2971 = load i64, ptr %slot449, align 8
  %cmp2972 = icmp ne i64 %v2971, 0
  %cv2973 = zext i1 %cmp2972 to i32
  store i32 %cv2973, ptr %slot450, align 8
  %v2974 = load i32, ptr %slot450, align 8
  %cv2975 = zext i32 %v2974 to i64
  %cond2976 = icmp ne i64 %cv2975, 0
  br i1 %cond2976, label %bb_rcgnn740, label %bb_rcgstore740
bb_rcgnn740:
  %v2977 = load i64, ptr %slot449, align 8
  %op2978 = sub i64 %v2977, 16
  store i64 %op2978, ptr %slot451, align 8
  %v2979 = load i64, ptr %slot449, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  %rgep2981 = getelementptr i8, ptr %p2980, i64 -16
  %ld2982 = load i64, ptr %rgep2981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2982, ptr %slot452, align 8
  %v2983 = load i64, ptr %slot452, align 8
  %op2984 = and i64 %v2983, 4611686018427387906
  store i64 %op2984, ptr %slot453, align 8
  %v2985 = load i64, ptr %slot453, align 8
  %cmp2986 = icmp ne i64 %v2985, 0
  %cv2987 = zext i1 %cmp2986 to i32
  store i32 %cv2987, ptr %slot454, align 8
  %v2988 = load i32, ptr %slot454, align 8
  %cv2989 = zext i32 %v2988 to i64
  %cond2990 = icmp ne i64 %cv2989, 0
  br i1 %cond2990, label %bb_rcgstore740, label %bb_rcginc740
bb_rcginc740:
  %v2991 = load i64, ptr %slot449, align 8
  %op2992 = sub i64 %v2991, 24
  store i64 %op2992, ptr %slot455, align 8
  %v2993 = load i64, ptr %slot449, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  %rgep2995 = getelementptr i8, ptr %p2994, i64 -24
  %ld2996 = load i64, ptr %rgep2995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2996, ptr %slot456, align 8
  %v2997 = load i64, ptr %slot456, align 8
  %op2998 = add i64 %v2997, 1
  store i64 %op2998, ptr %slot457, align 8
  %v2999 = load i64, ptr %slot457, align 8
  %cmp3000 = icmp eq i64 %v2999, 0
  %cv3001 = zext i1 %cmp3000 to i32
  store i32 %cv3001, ptr %slot458, align 8
  %v3002 = load i32, ptr %slot458, align 8
  %cv3003 = zext i32 %v3002 to i64
  %cond3004 = icmp ne i64 %cv3003, 0
  br i1 %cond3004, label %bb_rcglimit740, label %bb_rcgcapacity740
bb_rcglimit740:
  %v3005 = load i64, ptr %slot1, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  %call3007 = call i32 @myl_qbe_rc_status(ptr %p3006, i32 2) nomerge, !dbg !130
  store i32 %call3007, ptr %slot459, align 8
  br label %bb_failure
bb_rcgcapacity740:
  %v3008 = load i64, ptr %slot457, align 8
  %v3009 = load i64, ptr %slot449, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %rgep3011 = getelementptr i8, ptr %p3010, i64 -24
  store i64 %v3008, ptr %rgep3011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore740
bb_rcgstore740:
  %v3012 = load i64, ptr %slot449, align 8
  %v3013 = load i64, ptr %slot448, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  store i64 %v3012, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  %v3015 = load i64, ptr %slot14, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  store i32 2, ptr %p3016, align 4, !alias.scope !3, !noalias !4
  %v3017 = load i64, ptr %slot14, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  store i32 16, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  %v3019 = load i64, ptr %slot13, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  store i32 1, ptr %p3020, align 4, !alias.scope !3, !noalias !4
  %v3021 = load i64, ptr %slot11, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %ld3023 = load i32, ptr %p3022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3023, ptr %slot460, align 8
  %v3024 = load i32, ptr %slot460, align 8
  %cv3025 = zext i32 %v3024 to i64
  %cond3026 = icmp ne i64 %cv3025, 0
  br i1 %cond3026, label %bb_rcslotdrop756, label %bb_rcslotdone756
bb_rcslotdrop756:
  %v3027 = load i64, ptr %slot11, align 8
  %p3028 = inttoptr i64 %v3027 to ptr
  store i32 0, ptr %p3028, align 4, !alias.scope !3, !noalias !4
  %v3029 = load i64, ptr %slot15, align 8
  store i64 %v3029, ptr %slot461, align 8
  %v3030 = load i64, ptr %slot12, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  %ld3032 = load i32, ptr %p3031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3032, ptr %slot462, align 8
  %v3033 = load i32, ptr %slot462, align 8
  %op3034 = and i32 %v3033, 28
  store i32 %op3034, ptr %slot463, align 8
  %v3035 = load i32, ptr %slot463, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcslotrole756, label %bb_rcslotowner756
bb_rcslotrole756:
  %v3038 = load i64, ptr %slot34, align 8
  store i64 %v3038, ptr %slot464, align 8
  %v3039 = load i64, ptr %slot461, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  %ld3041 = load i64, ptr %p3040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3041, ptr %slot465, align 8
  %v3042 = load i64, ptr %slot465, align 8
  %cmp3043 = icmp ne i64 %v3042, 0
  %cv3044 = zext i1 %cmp3043 to i32
  store i32 %cv3044, ptr %slot466, align 8
  %v3045 = load i32, ptr %slot466, align 8
  %cv3046 = zext i32 %v3045 to i64
  %cond3047 = icmp ne i64 %cv3046, 0
  br i1 %cond3047, label %bb_rcgnn772, label %bb_rcgdone772
bb_rcgnn772:
  %v3048 = load i64, ptr %slot465, align 8
  %op3049 = sub i64 %v3048, 16
  store i64 %op3049, ptr %slot467, align 8
  %v3050 = load i64, ptr %slot465, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %rgep3052 = getelementptr i8, ptr %p3051, i64 -16
  %ld3053 = load i64, ptr %rgep3052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3053, ptr %slot468, align 8
  %v3054 = load i64, ptr %slot468, align 8
  %op3055 = and i64 %v3054, 4611686018427387906
  store i64 %op3055, ptr %slot469, align 8
  %v3056 = load i64, ptr %slot469, align 8
  %cmp3057 = icmp ne i64 %v3056, 0
  %cv3058 = zext i1 %cmp3057 to i32
  store i32 %cv3058, ptr %slot470, align 8
  %v3059 = load i32, ptr %slot470, align 8
  %cv3060 = zext i32 %v3059 to i64
  %cond3061 = icmp ne i64 %cv3060, 0
  br i1 %cond3061, label %bb_rcgclear772, label %bb_rcgcounted772
bb_rcgcounted772:
  %v3062 = load i64, ptr %slot465, align 8
  %op3063 = sub i64 %v3062, 24
  store i64 %op3063, ptr %slot471, align 8
  %v3064 = load i64, ptr %slot465, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %rgep3066 = getelementptr i8, ptr %p3065, i64 -24
  %ld3067 = load i64, ptr %rgep3066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3067, ptr %slot472, align 8
  %v3068 = load i64, ptr %slot472, align 8
  %op3069 = sub i64 %v3068, 1
  store i64 %op3069, ptr %slot473, align 8
  %v3070 = load i64, ptr %slot473, align 8
  %cmp3071 = icmp eq i64 %v3070, 0
  %cv3072 = zext i1 %cmp3071 to i32
  store i32 %cv3072, ptr %slot474, align 8
  %v3073 = load i32, ptr %slot474, align 8
  %cv3074 = zext i32 %v3073 to i64
  %cond3075 = icmp ne i64 %cv3074, 0
  br i1 %cond3075, label %bb_rcglast772, label %bb_rcgdec772
bb_rcglast772:
  %v3076 = load i64, ptr %slot465, align 8
  %op3077 = sub i64 %v3076, 32
  store i64 %op3077, ptr %slot475, align 8
  %v3078 = load i64, ptr %slot465, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %rgep3080 = getelementptr i8, ptr %p3079, i64 -32
  %ld3081 = load i64, ptr %rgep3080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3081, ptr %slot476, align 8
  %v3082 = load i64, ptr %slot476, align 8
  %cmp3083 = icmp ne i64 %v3082, 0
  %cv3084 = zext i1 %cmp3083 to i32
  store i32 %cv3084, ptr %slot477, align 8
  %v3085 = load i32, ptr %slot477, align 8
  %cv3086 = zext i32 %v3085 to i64
  %cond3087 = icmp ne i64 %cv3086, 0
  br i1 %cond3087, label %bb_rcgdec772, label %bb_rcgslow772
bb_rcgslow772:
  %v3088 = load i64, ptr %slot464, align 8
  %v3089 = load i64, ptr %slot461, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3088, i64 %v3089) nomerge, !dbg !130
  br label %bb_rcgdone772
bb_rcgdec772:
  %v3090 = load i64, ptr %slot473, align 8
  %v3091 = load i64, ptr %slot465, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  %rgep3093 = getelementptr i8, ptr %p3092, i64 -24
  store i64 %v3090, ptr %rgep3093, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear772
bb_rcgclear772:
  %v3094 = load i64, ptr %slot461, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  store i64 0, ptr %p3095, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone772
bb_rcgdone772:
  br label %bb_rcslotdone756
bb_rcslotowner756:
  %v3096 = load i64, ptr %slot34, align 8
  store i64 %v3096, ptr %slot478, align 8
  %v3097 = load i64, ptr %slot461, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  %ld3099 = load i64, ptr %p3098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3099, ptr %slot479, align 8
  %v3100 = load i64, ptr %slot479, align 8
  %cmp3101 = icmp ne i64 %v3100, 0
  %cv3102 = zext i1 %cmp3101 to i32
  store i32 %cv3102, ptr %slot480, align 8
  %v3103 = load i32, ptr %slot480, align 8
  %cv3104 = zext i32 %v3103 to i64
  %cond3105 = icmp ne i64 %cv3104, 0
  br i1 %cond3105, label %bb_rcgnn787, label %bb_rcgdone787
bb_rcgnn787:
  %v3106 = load i64, ptr %slot479, align 8
  %op3107 = sub i64 %v3106, 16
  store i64 %op3107, ptr %slot481, align 8
  %v3108 = load i64, ptr %slot479, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  %rgep3110 = getelementptr i8, ptr %p3109, i64 -16
  %ld3111 = load i64, ptr %rgep3110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3111, ptr %slot482, align 8
  %v3112 = load i64, ptr %slot482, align 8
  %op3113 = and i64 %v3112, 4611686018427387906
  store i64 %op3113, ptr %slot483, align 8
  %v3114 = load i64, ptr %slot483, align 8
  %cmp3115 = icmp ne i64 %v3114, 0
  %cv3116 = zext i1 %cmp3115 to i32
  store i32 %cv3116, ptr %slot484, align 8
  %v3117 = load i32, ptr %slot484, align 8
  %cv3118 = zext i32 %v3117 to i64
  %cond3119 = icmp ne i64 %cv3118, 0
  br i1 %cond3119, label %bb_rcgclear787, label %bb_rcgcounted787
bb_rcgcounted787:
  %v3120 = load i64, ptr %slot479, align 8
  %op3121 = sub i64 %v3120, 32
  store i64 %op3121, ptr %slot485, align 8
  %v3122 = load i64, ptr %slot479, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  %rgep3124 = getelementptr i8, ptr %p3123, i64 -32
  %ld3125 = load i64, ptr %rgep3124, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3125, ptr %slot486, align 8
  %v3126 = load i64, ptr %slot486, align 8
  %op3127 = sub i64 %v3126, 1
  store i64 %op3127, ptr %slot487, align 8
  %v3128 = load i64, ptr %slot487, align 8
  %cmp3129 = icmp eq i64 %v3128, 0
  %cv3130 = zext i1 %cmp3129 to i32
  store i32 %cv3130, ptr %slot488, align 8
  %v3131 = load i32, ptr %slot488, align 8
  %cv3132 = zext i32 %v3131 to i64
  %cond3133 = icmp ne i64 %cv3132, 0
  br i1 %cond3133, label %bb_rcglast787, label %bb_rcgdec787
bb_rcglast787:
  %v3134 = load i64, ptr %slot479, align 8
  %op3135 = sub i64 %v3134, 24
  store i64 %op3135, ptr %slot489, align 8
  %v3136 = load i64, ptr %slot479, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %rgep3138 = getelementptr i8, ptr %p3137, i64 -24
  %ld3139 = load i64, ptr %rgep3138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3139, ptr %slot490, align 8
  %v3140 = load i64, ptr %slot490, align 8
  %cmp3141 = icmp ne i64 %v3140, 0
  %cv3142 = zext i1 %cmp3141 to i32
  store i32 %cv3142, ptr %slot491, align 8
  %v3143 = load i32, ptr %slot491, align 8
  %cv3144 = zext i32 %v3143 to i64
  %cond3145 = icmp ne i64 %cv3144, 0
  br i1 %cond3145, label %bb_rcgdec787, label %bb_rcgslow787
bb_rcgslow787:
  %v3146 = load i64, ptr %slot478, align 8
  %v3147 = load i64, ptr %slot461, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3146, i64 %v3147) nomerge, !dbg !130
  br label %bb_rcgdone787
bb_rcgdec787:
  %v3148 = load i64, ptr %slot487, align 8
  %v3149 = load i64, ptr %slot479, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  %rgep3151 = getelementptr i8, ptr %p3150, i64 -32
  store i64 %v3148, ptr %rgep3151, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear787
bb_rcgclear787:
  %v3152 = load i64, ptr %slot461, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  store i64 0, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone787
bb_rcgdone787:
  br label %bb_rcslotdone756
bb_rcslotdone756:
  br label %bb_rcprivateprepared704
bb_rcprivateprepared704:
  %v3154 = load i64, ptr %slot5, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i32, ptr %p3155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3156, ptr %slot492, align 8
  %v3157 = load i32, ptr %slot492, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcslotdrop794, label %bb_rcslotdone794
bb_rcslotdrop794:
  %v3160 = load i64, ptr %slot5, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  store i32 0, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  %v3162 = load i64, ptr %slot27, align 8
  store i64 %v3162, ptr %slot493, align 8
  %v3163 = load i64, ptr %slot6, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i32, ptr %p3164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3165, ptr %slot494, align 8
  %v3166 = load i32, ptr %slot494, align 8
  %op3167 = and i32 %v3166, 28
  store i32 %op3167, ptr %slot495, align 8
  %v3168 = load i32, ptr %slot495, align 8
  %cv3169 = zext i32 %v3168 to i64
  %cond3170 = icmp ne i64 %cv3169, 0
  br i1 %cond3170, label %bb_rcslotrole794, label %bb_rcslotowner794
bb_rcslotrole794:
  %v3171 = load i64, ptr %slot34, align 8
  store i64 %v3171, ptr %slot496, align 8
  %v3172 = load i64, ptr %slot493, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %ld3174 = load i64, ptr %p3173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3174, ptr %slot497, align 8
  %v3175 = load i64, ptr %slot497, align 8
  %cmp3176 = icmp ne i64 %v3175, 0
  %cv3177 = zext i1 %cmp3176 to i32
  store i32 %cv3177, ptr %slot498, align 8
  %v3178 = load i32, ptr %slot498, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcgnn810, label %bb_rcgdone810
bb_rcgnn810:
  %v3181 = load i64, ptr %slot497, align 8
  %op3182 = sub i64 %v3181, 16
  store i64 %op3182, ptr %slot499, align 8
  %v3183 = load i64, ptr %slot497, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %rgep3185 = getelementptr i8, ptr %p3184, i64 -16
  %ld3186 = load i64, ptr %rgep3185, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3186, ptr %slot500, align 8
  %v3187 = load i64, ptr %slot500, align 8
  %op3188 = and i64 %v3187, 4611686018427387906
  store i64 %op3188, ptr %slot501, align 8
  %v3189 = load i64, ptr %slot501, align 8
  %cmp3190 = icmp ne i64 %v3189, 0
  %cv3191 = zext i1 %cmp3190 to i32
  store i32 %cv3191, ptr %slot502, align 8
  %v3192 = load i32, ptr %slot502, align 8
  %cv3193 = zext i32 %v3192 to i64
  %cond3194 = icmp ne i64 %cv3193, 0
  br i1 %cond3194, label %bb_rcgclear810, label %bb_rcgcounted810
bb_rcgcounted810:
  %v3195 = load i64, ptr %slot497, align 8
  %op3196 = sub i64 %v3195, 24
  store i64 %op3196, ptr %slot503, align 8
  %v3197 = load i64, ptr %slot497, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %rgep3199 = getelementptr i8, ptr %p3198, i64 -24
  %ld3200 = load i64, ptr %rgep3199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3200, ptr %slot504, align 8
  %v3201 = load i64, ptr %slot504, align 8
  %op3202 = sub i64 %v3201, 1
  store i64 %op3202, ptr %slot505, align 8
  %v3203 = load i64, ptr %slot505, align 8
  %cmp3204 = icmp eq i64 %v3203, 0
  %cv3205 = zext i1 %cmp3204 to i32
  store i32 %cv3205, ptr %slot506, align 8
  %v3206 = load i32, ptr %slot506, align 8
  %cv3207 = zext i32 %v3206 to i64
  %cond3208 = icmp ne i64 %cv3207, 0
  br i1 %cond3208, label %bb_rcglast810, label %bb_rcgdec810
bb_rcglast810:
  %v3209 = load i64, ptr %slot497, align 8
  %op3210 = sub i64 %v3209, 32
  store i64 %op3210, ptr %slot507, align 8
  %v3211 = load i64, ptr %slot497, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %rgep3213 = getelementptr i8, ptr %p3212, i64 -32
  %ld3214 = load i64, ptr %rgep3213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3214, ptr %slot508, align 8
  %v3215 = load i64, ptr %slot508, align 8
  %cmp3216 = icmp ne i64 %v3215, 0
  %cv3217 = zext i1 %cmp3216 to i32
  store i32 %cv3217, ptr %slot509, align 8
  %v3218 = load i32, ptr %slot509, align 8
  %cv3219 = zext i32 %v3218 to i64
  %cond3220 = icmp ne i64 %cv3219, 0
  br i1 %cond3220, label %bb_rcgdec810, label %bb_rcgslow810
bb_rcgslow810:
  %v3221 = load i64, ptr %slot496, align 8
  %v3222 = load i64, ptr %slot493, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3221, i64 %v3222) nomerge, !dbg !130
  br label %bb_rcgdone810
bb_rcgdec810:
  %v3223 = load i64, ptr %slot505, align 8
  %v3224 = load i64, ptr %slot497, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %rgep3226 = getelementptr i8, ptr %p3225, i64 -24
  store i64 %v3223, ptr %rgep3226, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear810
bb_rcgclear810:
  %v3227 = load i64, ptr %slot493, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  store i64 0, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone810
bb_rcgdone810:
  br label %bb_rcslotdone794
bb_rcslotowner794:
  %v3229 = load i64, ptr %slot34, align 8
  store i64 %v3229, ptr %slot510, align 8
  %v3230 = load i64, ptr %slot493, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  %ld3232 = load i64, ptr %p3231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3232, ptr %slot511, align 8
  %v3233 = load i64, ptr %slot511, align 8
  %cmp3234 = icmp ne i64 %v3233, 0
  %cv3235 = zext i1 %cmp3234 to i32
  store i32 %cv3235, ptr %slot512, align 8
  %v3236 = load i32, ptr %slot512, align 8
  %cv3237 = zext i32 %v3236 to i64
  %cond3238 = icmp ne i64 %cv3237, 0
  br i1 %cond3238, label %bb_rcgnn825, label %bb_rcgdone825
bb_rcgnn825:
  %v3239 = load i64, ptr %slot511, align 8
  %op3240 = sub i64 %v3239, 16
  store i64 %op3240, ptr %slot513, align 8
  %v3241 = load i64, ptr %slot511, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  %rgep3243 = getelementptr i8, ptr %p3242, i64 -16
  %ld3244 = load i64, ptr %rgep3243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3244, ptr %slot514, align 8
  %v3245 = load i64, ptr %slot514, align 8
  %op3246 = and i64 %v3245, 4611686018427387906
  store i64 %op3246, ptr %slot515, align 8
  %v3247 = load i64, ptr %slot515, align 8
  %cmp3248 = icmp ne i64 %v3247, 0
  %cv3249 = zext i1 %cmp3248 to i32
  store i32 %cv3249, ptr %slot516, align 8
  %v3250 = load i32, ptr %slot516, align 8
  %cv3251 = zext i32 %v3250 to i64
  %cond3252 = icmp ne i64 %cv3251, 0
  br i1 %cond3252, label %bb_rcgclear825, label %bb_rcgcounted825
bb_rcgcounted825:
  %v3253 = load i64, ptr %slot511, align 8
  %op3254 = sub i64 %v3253, 32
  store i64 %op3254, ptr %slot517, align 8
  %v3255 = load i64, ptr %slot511, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %rgep3257 = getelementptr i8, ptr %p3256, i64 -32
  %ld3258 = load i64, ptr %rgep3257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3258, ptr %slot518, align 8
  %v3259 = load i64, ptr %slot518, align 8
  %op3260 = sub i64 %v3259, 1
  store i64 %op3260, ptr %slot519, align 8
  %v3261 = load i64, ptr %slot519, align 8
  %cmp3262 = icmp eq i64 %v3261, 0
  %cv3263 = zext i1 %cmp3262 to i32
  store i32 %cv3263, ptr %slot520, align 8
  %v3264 = load i32, ptr %slot520, align 8
  %cv3265 = zext i32 %v3264 to i64
  %cond3266 = icmp ne i64 %cv3265, 0
  br i1 %cond3266, label %bb_rcglast825, label %bb_rcgdec825
bb_rcglast825:
  %v3267 = load i64, ptr %slot511, align 8
  %op3268 = sub i64 %v3267, 24
  store i64 %op3268, ptr %slot521, align 8
  %v3269 = load i64, ptr %slot511, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %rgep3271 = getelementptr i8, ptr %p3270, i64 -24
  %ld3272 = load i64, ptr %rgep3271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3272, ptr %slot522, align 8
  %v3273 = load i64, ptr %slot522, align 8
  %cmp3274 = icmp ne i64 %v3273, 0
  %cv3275 = zext i1 %cmp3274 to i32
  store i32 %cv3275, ptr %slot523, align 8
  %v3276 = load i32, ptr %slot523, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcgdec825, label %bb_rcgslow825
bb_rcgslow825:
  %v3279 = load i64, ptr %slot510, align 8
  %v3280 = load i64, ptr %slot493, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3279, i64 %v3280) nomerge, !dbg !130
  br label %bb_rcgdone825
bb_rcgdec825:
  %v3281 = load i64, ptr %slot519, align 8
  %v3282 = load i64, ptr %slot511, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %rgep3284 = getelementptr i8, ptr %p3283, i64 -32
  store i64 %v3281, ptr %rgep3284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear825
bb_rcgclear825:
  %v3285 = load i64, ptr %slot493, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  store i64 0, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone825
bb_rcgdone825:
  br label %bb_rcslotdone794
bb_rcslotdone794:
  %v3287 = load i64, ptr %slot27, align 8
  store i64 %v3287, ptr %slot524, align 8
  %v3288 = load i64, ptr %slot17, align 8
  store i64 %v3288, ptr %slot525, align 8
  %v3289 = load i64, ptr %slot525, align 8
  %v3290 = load i64, ptr %slot524, align 8
  %p3291 = inttoptr i64 %v3289 to ptr
  %p3292 = inttoptr i64 %v3290 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3292, ptr %p3291, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot13, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i32 0, ptr %p3294, align 4, !alias.scope !3, !noalias !4
  %v3295 = load i64, ptr %slot6, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  store i32 2, ptr %p3296, align 4, !alias.scope !3, !noalias !4
  %v3297 = load i64, ptr %slot14, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  %ld3299 = load i32, ptr %p3298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3299, ptr %slot526, align 8
  %v3300 = load i32, ptr %slot526, align 8
  %v3301 = load i64, ptr %slot6, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  store i32 %v3300, ptr %p3302, align 4, !alias.scope !3, !noalias !4
  %v3303 = load i64, ptr %slot5, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i32 1, ptr %p3304, align 4, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot27, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i64, ptr %p3306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3307, ptr %slot527, align 8
  %v3308 = load i64, ptr %slot527, align 8
  %v3309 = load i64, ptr %slot31, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i64 %v3308, ptr %p3310, align 8, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot31, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %ld3313 = load i64, ptr %p3312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3313, ptr %slot528, align 8
  %v3314 = load i64, ptr %slot528, align 8
  %v3315 = load i64, ptr %slot16, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i64 %v3314, ptr %p3316, align 8, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot16, align 8
  store i64 %v3317, ptr %slot529, align 8
  %v3318 = load i64, ptr %slot11, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  %ld3320 = load i32, ptr %p3319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3320, ptr %slot530, align 8
  %v3321 = load i64, ptr %slot12, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %ld3323 = load i32, ptr %p3322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3323, ptr %slot531, align 8
  %v3324 = load i32, ptr %slot531, align 8
  %op3325 = and i32 %v3324, 24
  store i32 %op3325, ptr %slot531, align 8
  %v3326 = load i32, ptr %slot531, align 8
  %cmp3327 = icmp eq i32 %v3326, 0
  %cv3328 = zext i1 %cmp3327 to i32
  store i32 %cv3328, ptr %slot532, align 8
  %v3329 = load i32, ptr %slot530, align 8
  %v3330 = load i32, ptr %slot532, align 8
  %op3331 = and i32 %v3329, %v3330
  store i32 %op3331, ptr %slot533, align 8
  %v3332 = load i32, ptr %slot533, align 8
  %cv3333 = zext i32 %v3332 to i64
  %cond3334 = icmp ne i64 %cv3333, 0
  br i1 %cond3334, label %bb_rctake839, label %bb_rccopy839
bb_rctake839:
  %v3335 = load i64, ptr %slot17, align 8
  store i64 %v3335, ptr %slot534, align 8
  %v3336 = load i64, ptr %slot35, align 8
  store i64 %v3336, ptr %slot535, align 8
  %v3337 = load i64, ptr %slot529, align 8
  %v3338 = load i64, ptr %slot534, align 8
  %op3339 = sub i64 %v3337, %v3338
  store i64 %op3339, ptr %slot536, align 8
  %v3340 = load i64, ptr %slot534, align 8
  %v3341 = load i64, ptr %slot529, align 8
  %op3342 = sub i64 %v3340, %v3341
  store i64 %op3342, ptr %slot537, align 8
  %v3343 = load i64, ptr %slot536, align 8
  %cmp3344 = icmp ult i64 %v3343, 8
  %cv3345 = zext i1 %cmp3344 to i32
  store i32 %cv3345, ptr %slot538, align 8
  %v3346 = load i64, ptr %slot537, align 8
  %cmp3347 = icmp ult i64 %v3346, 8
  %cv3348 = zext i1 %cmp3347 to i32
  store i32 %cv3348, ptr %slot539, align 8
  %v3349 = load i32, ptr %slot538, align 8
  %v3350 = load i32, ptr %slot539, align 8
  %op3351 = or i32 %v3349, %v3350
  store i32 %op3351, ptr %slot540, align 8
  %v3352 = load i32, ptr %slot540, align 8
  %cv3353 = zext i32 %v3352 to i64
  %cond3354 = icmp ne i64 %cv3353, 0
  br i1 %cond3354, label %bb_rcmoveslow848, label %bb_rcmovecheck848
bb_rcmovecheck848:
  %v3355 = load i64, ptr %slot529, align 8
  %p3357 = inttoptr i64 %v3355 to ptr
  %gep3358 = getelementptr i8, ptr %p3357, i64 0
  %op3356 = ptrtoint ptr %gep3358 to i64
  store i64 %op3356, ptr %slot541, align 8
  %v3359 = load i64, ptr %slot541, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  %ld3361 = load i64, ptr %p3360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3361, ptr %slot542, align 8
  %v3362 = load i64, ptr %slot542, align 8
  %cmp3363 = icmp ne i64 %v3362, 0
  %cv3364 = zext i1 %cmp3363 to i32
  store i32 %cv3364, ptr %slot543, align 8
  %v3365 = load i32, ptr %slot543, align 8
  %cv3366 = zext i32 %v3365 to i64
  %cond3367 = icmp ne i64 %cv3366, 0
  br i1 %cond3367, label %bb_rcmoveheader856, label %bb_rcmovenext856
bb_rcmoveheader856:
  %v3368 = load i64, ptr %slot542, align 8
  %op3369 = sub i64 %v3368, 16
  store i64 %op3369, ptr %slot544, align 8
  %v3370 = load i64, ptr %slot542, align 8
  %p3371 = inttoptr i64 %v3370 to ptr
  %rgep3372 = getelementptr i8, ptr %p3371, i64 -16
  %ld3373 = load i64, ptr %rgep3372, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3373, ptr %slot545, align 8
  %v3374 = load i64, ptr %slot545, align 8
  %op3375 = and i64 %v3374, 5764607523034234881
  store i64 %op3375, ptr %slot546, align 8
  %v3376 = load i64, ptr %slot546, align 8
  %cmp3377 = icmp ne i64 %v3376, 0
  %cv3378 = zext i1 %cmp3377 to i32
  store i32 %cv3378, ptr %slot547, align 8
  %v3379 = load i32, ptr %slot547, align 8
  %cv3380 = zext i32 %v3379 to i64
  %cond3381 = icmp ne i64 %cv3380, 0
  br i1 %cond3381, label %bb_rcmoveslow848, label %bb_rcmovenext856
bb_rcmovenext856:
  %v3382 = load i64, ptr %slot529, align 8
  %v3383 = load i64, ptr %slot534, align 8
  %p3384 = inttoptr i64 %v3382 to ptr
  %p3385 = inttoptr i64 %v3383 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3385, ptr %p3384, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3386 = load i64, ptr %slot529, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  store i64 0, ptr %p3387, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved848
bb_rcmoveslow848:
  %v3388 = load i64, ptr %slot34, align 8
  %v3389 = load i64, ptr %slot534, align 8
  %v3390 = load i64, ptr %slot529, align 8
  %v3391 = load i64, ptr %slot535, align 8
  %cv3392 = trunc i64 %v3391 to i32
  %call3393 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v3388, i64 %v3389, i64 %v3390, i32 %cv3392) nomerge, !dbg !132
  store i32 %call3393, ptr %slot548, align 8
  %v3394 = load i32, ptr %slot548, align 8
  %cv3395 = zext i32 %v3394 to i64
  %cond3396 = icmp ne i64 %cv3395, 0
  br i1 %cond3396, label %bb_rcsuccess863, label %bb_rcfailure863
bb_rcfailure863:
  %v3397 = load i64, ptr %slot34, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  %call3399 = call i32 @myl_rc_take_failure(ptr %p3398) nomerge, !dbg !132
  store i32 %call3399, ptr %slot549, align 8
  %v3400 = load i64, ptr %slot1, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  %v3402 = load i32, ptr %slot549, align 8
  %call3403 = call i32 @myl_qbe_rc_status(ptr %p3401, i32 %v3402) nomerge, !dbg !132
  store i32 %call3403, ptr %slot550, align 8
  br label %bb_failure
bb_rcsuccess863:
  br label %bb_rcmoved848
bb_rcmoved848:
  %v3404 = load i64, ptr %slot11, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  store i32 0, ptr %p3405, align 4, !alias.scope !3, !noalias !4
  %v3406 = load i64, ptr %slot14, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i32 2, ptr %p3407, align 4, !alias.scope !3, !noalias !4
  %v3408 = load i64, ptr %slot13, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  store i32 1, ptr %p3409, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared839
bb_rccopy839:
  %v3410 = load i64, ptr %slot17, align 8
  store i64 %v3410, ptr %slot551, align 8
  %v3411 = load i64, ptr %slot35, align 8
  store i64 %v3411, ptr %slot552, align 8
  %v3412 = load i64, ptr %slot529, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  %ld3414 = load i64, ptr %p3413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3414, ptr %slot553, align 8
  %v3415 = load i64, ptr %slot553, align 8
  %cmp3416 = icmp ne i64 %v3415, 0
  %cv3417 = zext i1 %cmp3416 to i32
  store i32 %cv3417, ptr %slot554, align 8
  %v3418 = load i32, ptr %slot554, align 8
  %cv3419 = zext i32 %v3418 to i64
  %cond3420 = icmp ne i64 %cv3419, 0
  br i1 %cond3420, label %bb_rcgnn872, label %bb_rcgplain872
bb_rcgnn872:
  %v3421 = load i64, ptr %slot553, align 8
  %op3422 = sub i64 %v3421, 16
  store i64 %op3422, ptr %slot555, align 8
  %v3423 = load i64, ptr %slot553, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  %rgep3425 = getelementptr i8, ptr %p3424, i64 -16
  %ld3426 = load i64, ptr %rgep3425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3426, ptr %slot556, align 8
  %v3427 = load i64, ptr %slot556, align 8
  %op3428 = and i64 %v3427, 4611686018427387906
  store i64 %op3428, ptr %slot557, align 8
  %v3429 = load i64, ptr %slot557, align 8
  %cmp3430 = icmp ne i64 %v3429, 0
  %cv3431 = zext i1 %cmp3430 to i32
  store i32 %cv3431, ptr %slot558, align 8
  %v3432 = load i32, ptr %slot558, align 8
  %cv3433 = zext i32 %v3432 to i64
  %cond3434 = icmp ne i64 %cv3433, 0
  br i1 %cond3434, label %bb_rcgspecial872, label %bb_rcginc872
bb_rcginc872:
  %v3435 = load i64, ptr %slot553, align 8
  %op3436 = sub i64 %v3435, 32
  store i64 %op3436, ptr %slot559, align 8
  %v3437 = load i64, ptr %slot553, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  %rgep3439 = getelementptr i8, ptr %p3438, i64 -32
  %ld3440 = load i64, ptr %rgep3439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3440, ptr %slot560, align 8
  %v3441 = load i64, ptr %slot560, align 8
  %op3442 = add i64 %v3441, 1
  store i64 %op3442, ptr %slot561, align 8
  %v3443 = load i64, ptr %slot561, align 8
  %cmp3444 = icmp eq i64 %v3443, 0
  %cv3445 = zext i1 %cmp3444 to i32
  store i32 %cv3445, ptr %slot562, align 8
  %v3446 = load i32, ptr %slot562, align 8
  %cv3447 = zext i32 %v3446 to i64
  %cond3448 = icmp ne i64 %cv3447, 0
  br i1 %cond3448, label %bb_rcglimit872, label %bb_rcgcapacity872
bb_rcglimit872:
  %v3449 = load i64, ptr %slot1, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %call3451 = call i32 @myl_qbe_rc_status(ptr %p3450, i32 2) nomerge, !dbg !132
  store i32 %call3451, ptr %slot563, align 8
  br label %bb_failure
bb_rcgcapacity872:
  %v3452 = load i64, ptr %slot561, align 8
  %v3453 = load i64, ptr %slot553, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  %rgep3455 = getelementptr i8, ptr %p3454, i64 -32
  store i64 %v3452, ptr %rgep3455, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain872
bb_rcgspecial872:
  %v3456 = load i64, ptr %slot556, align 8
  %op3457 = and i64 %v3456, 4611686018427387904
  store i64 %op3457, ptr %slot564, align 8
  %v3458 = load i64, ptr %slot564, align 8
  %cmp3459 = icmp ne i64 %v3458, 0
  %cv3460 = zext i1 %cmp3459 to i32
  store i32 %cv3460, ptr %slot565, align 8
  %v3461 = load i32, ptr %slot565, align 8
  %cv3462 = zext i32 %v3461 to i64
  %cond3463 = icmp ne i64 %cv3462, 0
  br i1 %cond3463, label %bb_rcgslow872, label %bb_rcgplain872
bb_rcgslow872:
  %v3464 = load i64, ptr %slot34, align 8
  %v3465 = load i64, ptr %slot551, align 8
  %v3466 = load i64, ptr %slot529, align 8
  %v3467 = load i64, ptr %slot552, align 8
  %cv3468 = trunc i64 %v3467 to i32
  %call3469 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v3464, i64 %v3465, i64 %v3466, i32 %cv3468) nomerge, !dbg !132
  store i32 %call3469, ptr %slot566, align 8
  %v3470 = load i32, ptr %slot566, align 8
  %cv3471 = zext i32 %v3470 to i64
  %cond3472 = icmp ne i64 %cv3471, 0
  br i1 %cond3472, label %bb_rcsuccess886, label %bb_rcfailure886
bb_rcfailure886:
  %v3473 = load i64, ptr %slot34, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %call3475 = call i32 @myl_rc_take_failure(ptr %p3474) nomerge, !dbg !132
  store i32 %call3475, ptr %slot567, align 8
  %v3476 = load i64, ptr %slot1, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %v3478 = load i32, ptr %slot567, align 8
  %call3479 = call i32 @myl_qbe_rc_status(ptr %p3477, i32 %v3478) nomerge, !dbg !132
  store i32 %call3479, ptr %slot568, align 8
  br label %bb_failure
bb_rcsuccess886:
  br label %bb_rcgdone872
bb_rcgplain872:
  %v3480 = load i64, ptr %slot553, align 8
  %v3481 = load i64, ptr %slot551, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i64 %v3480, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone872
bb_rcgdone872:
  %v3483 = load i64, ptr %slot14, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  store i32 2, ptr %p3484, align 4, !alias.scope !3, !noalias !4
  %v3485 = load i64, ptr %slot13, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  store i32 1, ptr %p3486, align 4, !alias.scope !3, !noalias !4
  %v3487 = load i64, ptr %slot11, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  %ld3489 = load i32, ptr %p3488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3489, ptr %slot569, align 8
  %v3490 = load i32, ptr %slot569, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcslotdrop893, label %bb_rcslotdone893
bb_rcslotdrop893:
  %v3493 = load i64, ptr %slot11, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  store i32 0, ptr %p3494, align 4, !alias.scope !3, !noalias !4
  %v3495 = load i64, ptr %slot15, align 8
  store i64 %v3495, ptr %slot570, align 8
  %v3496 = load i64, ptr %slot12, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %ld3498 = load i32, ptr %p3497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3498, ptr %slot571, align 8
  %v3499 = load i32, ptr %slot571, align 8
  %op3500 = and i32 %v3499, 28
  store i32 %op3500, ptr %slot572, align 8
  %v3501 = load i32, ptr %slot572, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcslotrole893, label %bb_rcslotowner893
bb_rcslotrole893:
  %v3504 = load i64, ptr %slot34, align 8
  store i64 %v3504, ptr %slot573, align 8
  %v3505 = load i64, ptr %slot570, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %ld3507 = load i64, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3507, ptr %slot574, align 8
  %v3508 = load i64, ptr %slot574, align 8
  %cmp3509 = icmp ne i64 %v3508, 0
  %cv3510 = zext i1 %cmp3509 to i32
  store i32 %cv3510, ptr %slot575, align 8
  %v3511 = load i32, ptr %slot575, align 8
  %cv3512 = zext i32 %v3511 to i64
  %cond3513 = icmp ne i64 %cv3512, 0
  br i1 %cond3513, label %bb_rcgnn909, label %bb_rcgdone909
bb_rcgnn909:
  %v3514 = load i64, ptr %slot574, align 8
  %op3515 = sub i64 %v3514, 16
  store i64 %op3515, ptr %slot576, align 8
  %v3516 = load i64, ptr %slot574, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  %rgep3518 = getelementptr i8, ptr %p3517, i64 -16
  %ld3519 = load i64, ptr %rgep3518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3519, ptr %slot577, align 8
  %v3520 = load i64, ptr %slot577, align 8
  %op3521 = and i64 %v3520, 4611686018427387906
  store i64 %op3521, ptr %slot578, align 8
  %v3522 = load i64, ptr %slot578, align 8
  %cmp3523 = icmp ne i64 %v3522, 0
  %cv3524 = zext i1 %cmp3523 to i32
  store i32 %cv3524, ptr %slot579, align 8
  %v3525 = load i32, ptr %slot579, align 8
  %cv3526 = zext i32 %v3525 to i64
  %cond3527 = icmp ne i64 %cv3526, 0
  br i1 %cond3527, label %bb_rcgclear909, label %bb_rcgcounted909
bb_rcgcounted909:
  %v3528 = load i64, ptr %slot574, align 8
  %op3529 = sub i64 %v3528, 24
  store i64 %op3529, ptr %slot580, align 8
  %v3530 = load i64, ptr %slot574, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %rgep3532 = getelementptr i8, ptr %p3531, i64 -24
  %ld3533 = load i64, ptr %rgep3532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3533, ptr %slot581, align 8
  %v3534 = load i64, ptr %slot581, align 8
  %op3535 = sub i64 %v3534, 1
  store i64 %op3535, ptr %slot582, align 8
  %v3536 = load i64, ptr %slot582, align 8
  %cmp3537 = icmp eq i64 %v3536, 0
  %cv3538 = zext i1 %cmp3537 to i32
  store i32 %cv3538, ptr %slot583, align 8
  %v3539 = load i32, ptr %slot583, align 8
  %cv3540 = zext i32 %v3539 to i64
  %cond3541 = icmp ne i64 %cv3540, 0
  br i1 %cond3541, label %bb_rcglast909, label %bb_rcgdec909
bb_rcglast909:
  %v3542 = load i64, ptr %slot574, align 8
  %op3543 = sub i64 %v3542, 32
  store i64 %op3543, ptr %slot584, align 8
  %v3544 = load i64, ptr %slot574, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %rgep3546 = getelementptr i8, ptr %p3545, i64 -32
  %ld3547 = load i64, ptr %rgep3546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3547, ptr %slot585, align 8
  %v3548 = load i64, ptr %slot585, align 8
  %cmp3549 = icmp ne i64 %v3548, 0
  %cv3550 = zext i1 %cmp3549 to i32
  store i32 %cv3550, ptr %slot586, align 8
  %v3551 = load i32, ptr %slot586, align 8
  %cv3552 = zext i32 %v3551 to i64
  %cond3553 = icmp ne i64 %cv3552, 0
  br i1 %cond3553, label %bb_rcgdec909, label %bb_rcgslow909
bb_rcgslow909:
  %v3554 = load i64, ptr %slot573, align 8
  %v3555 = load i64, ptr %slot570, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3554, i64 %v3555) nomerge, !dbg !132
  br label %bb_rcgdone909
bb_rcgdec909:
  %v3556 = load i64, ptr %slot582, align 8
  %v3557 = load i64, ptr %slot574, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %rgep3559 = getelementptr i8, ptr %p3558, i64 -24
  store i64 %v3556, ptr %rgep3559, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear909
bb_rcgclear909:
  %v3560 = load i64, ptr %slot570, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i64 0, ptr %p3561, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone909
bb_rcgdone909:
  br label %bb_rcslotdone893
bb_rcslotowner893:
  %v3562 = load i64, ptr %slot34, align 8
  store i64 %v3562, ptr %slot587, align 8
  %v3563 = load i64, ptr %slot570, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %ld3565 = load i64, ptr %p3564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3565, ptr %slot588, align 8
  %v3566 = load i64, ptr %slot588, align 8
  %cmp3567 = icmp ne i64 %v3566, 0
  %cv3568 = zext i1 %cmp3567 to i32
  store i32 %cv3568, ptr %slot589, align 8
  %v3569 = load i32, ptr %slot589, align 8
  %cv3570 = zext i32 %v3569 to i64
  %cond3571 = icmp ne i64 %cv3570, 0
  br i1 %cond3571, label %bb_rcgnn924, label %bb_rcgdone924
bb_rcgnn924:
  %v3572 = load i64, ptr %slot588, align 8
  %op3573 = sub i64 %v3572, 16
  store i64 %op3573, ptr %slot590, align 8
  %v3574 = load i64, ptr %slot588, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %rgep3576 = getelementptr i8, ptr %p3575, i64 -16
  %ld3577 = load i64, ptr %rgep3576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3577, ptr %slot591, align 8
  %v3578 = load i64, ptr %slot591, align 8
  %op3579 = and i64 %v3578, 4611686018427387906
  store i64 %op3579, ptr %slot592, align 8
  %v3580 = load i64, ptr %slot592, align 8
  %cmp3581 = icmp ne i64 %v3580, 0
  %cv3582 = zext i1 %cmp3581 to i32
  store i32 %cv3582, ptr %slot593, align 8
  %v3583 = load i32, ptr %slot593, align 8
  %cv3584 = zext i32 %v3583 to i64
  %cond3585 = icmp ne i64 %cv3584, 0
  br i1 %cond3585, label %bb_rcgclear924, label %bb_rcgcounted924
bb_rcgcounted924:
  %v3586 = load i64, ptr %slot588, align 8
  %op3587 = sub i64 %v3586, 32
  store i64 %op3587, ptr %slot594, align 8
  %v3588 = load i64, ptr %slot588, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  %rgep3590 = getelementptr i8, ptr %p3589, i64 -32
  %ld3591 = load i64, ptr %rgep3590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3591, ptr %slot595, align 8
  %v3592 = load i64, ptr %slot595, align 8
  %op3593 = sub i64 %v3592, 1
  store i64 %op3593, ptr %slot596, align 8
  %v3594 = load i64, ptr %slot596, align 8
  %cmp3595 = icmp eq i64 %v3594, 0
  %cv3596 = zext i1 %cmp3595 to i32
  store i32 %cv3596, ptr %slot597, align 8
  %v3597 = load i32, ptr %slot597, align 8
  %cv3598 = zext i32 %v3597 to i64
  %cond3599 = icmp ne i64 %cv3598, 0
  br i1 %cond3599, label %bb_rcglast924, label %bb_rcgdec924
bb_rcglast924:
  %v3600 = load i64, ptr %slot588, align 8
  %op3601 = sub i64 %v3600, 24
  store i64 %op3601, ptr %slot598, align 8
  %v3602 = load i64, ptr %slot588, align 8
  %p3603 = inttoptr i64 %v3602 to ptr
  %rgep3604 = getelementptr i8, ptr %p3603, i64 -24
  %ld3605 = load i64, ptr %rgep3604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3605, ptr %slot599, align 8
  %v3606 = load i64, ptr %slot599, align 8
  %cmp3607 = icmp ne i64 %v3606, 0
  %cv3608 = zext i1 %cmp3607 to i32
  store i32 %cv3608, ptr %slot600, align 8
  %v3609 = load i32, ptr %slot600, align 8
  %cv3610 = zext i32 %v3609 to i64
  %cond3611 = icmp ne i64 %cv3610, 0
  br i1 %cond3611, label %bb_rcgdec924, label %bb_rcgslow924
bb_rcgslow924:
  %v3612 = load i64, ptr %slot587, align 8
  %v3613 = load i64, ptr %slot570, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3612, i64 %v3613) nomerge, !dbg !132
  br label %bb_rcgdone924
bb_rcgdec924:
  %v3614 = load i64, ptr %slot596, align 8
  %v3615 = load i64, ptr %slot588, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %rgep3617 = getelementptr i8, ptr %p3616, i64 -32
  store i64 %v3614, ptr %rgep3617, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear924
bb_rcgclear924:
  %v3618 = load i64, ptr %slot570, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i64 0, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone924
bb_rcgdone924:
  br label %bb_rcslotdone893
bb_rcslotdone893:
  br label %bb_rcprepared839
bb_rcprepared839:
  %v3620 = load i64, ptr %slot7, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %ld3622 = load i32, ptr %p3621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3622, ptr %slot601, align 8
  %v3623 = load i32, ptr %slot601, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcslotdrop931, label %bb_rcslotdone931
bb_rcslotdrop931:
  %v3626 = load i64, ptr %slot7, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i32 0, ptr %p3627, align 4, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot28, align 8
  store i64 %v3628, ptr %slot602, align 8
  %v3629 = load i64, ptr %slot8, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %ld3631 = load i32, ptr %p3630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3631, ptr %slot603, align 8
  %v3632 = load i32, ptr %slot603, align 8
  %op3633 = and i32 %v3632, 28
  store i32 %op3633, ptr %slot604, align 8
  %v3634 = load i32, ptr %slot604, align 8
  %cv3635 = zext i32 %v3634 to i64
  %cond3636 = icmp ne i64 %cv3635, 0
  br i1 %cond3636, label %bb_rcslotrole931, label %bb_rcslotowner931
bb_rcslotrole931:
  %v3637 = load i64, ptr %slot34, align 8
  store i64 %v3637, ptr %slot605, align 8
  %v3638 = load i64, ptr %slot602, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  %ld3640 = load i64, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3640, ptr %slot606, align 8
  %v3641 = load i64, ptr %slot606, align 8
  %cmp3642 = icmp ne i64 %v3641, 0
  %cv3643 = zext i1 %cmp3642 to i32
  store i32 %cv3643, ptr %slot607, align 8
  %v3644 = load i32, ptr %slot607, align 8
  %cv3645 = zext i32 %v3644 to i64
  %cond3646 = icmp ne i64 %cv3645, 0
  br i1 %cond3646, label %bb_rcgnn947, label %bb_rcgdone947
bb_rcgnn947:
  %v3647 = load i64, ptr %slot606, align 8
  %op3648 = sub i64 %v3647, 16
  store i64 %op3648, ptr %slot608, align 8
  %v3649 = load i64, ptr %slot606, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %rgep3651 = getelementptr i8, ptr %p3650, i64 -16
  %ld3652 = load i64, ptr %rgep3651, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3652, ptr %slot609, align 8
  %v3653 = load i64, ptr %slot609, align 8
  %op3654 = and i64 %v3653, 4611686018427387906
  store i64 %op3654, ptr %slot610, align 8
  %v3655 = load i64, ptr %slot610, align 8
  %cmp3656 = icmp ne i64 %v3655, 0
  %cv3657 = zext i1 %cmp3656 to i32
  store i32 %cv3657, ptr %slot611, align 8
  %v3658 = load i32, ptr %slot611, align 8
  %cv3659 = zext i32 %v3658 to i64
  %cond3660 = icmp ne i64 %cv3659, 0
  br i1 %cond3660, label %bb_rcgclear947, label %bb_rcgcounted947
bb_rcgcounted947:
  %v3661 = load i64, ptr %slot606, align 8
  %op3662 = sub i64 %v3661, 24
  store i64 %op3662, ptr %slot612, align 8
  %v3663 = load i64, ptr %slot606, align 8
  %p3664 = inttoptr i64 %v3663 to ptr
  %rgep3665 = getelementptr i8, ptr %p3664, i64 -24
  %ld3666 = load i64, ptr %rgep3665, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3666, ptr %slot613, align 8
  %v3667 = load i64, ptr %slot613, align 8
  %op3668 = sub i64 %v3667, 1
  store i64 %op3668, ptr %slot614, align 8
  %v3669 = load i64, ptr %slot614, align 8
  %cmp3670 = icmp eq i64 %v3669, 0
  %cv3671 = zext i1 %cmp3670 to i32
  store i32 %cv3671, ptr %slot615, align 8
  %v3672 = load i32, ptr %slot615, align 8
  %cv3673 = zext i32 %v3672 to i64
  %cond3674 = icmp ne i64 %cv3673, 0
  br i1 %cond3674, label %bb_rcglast947, label %bb_rcgdec947
bb_rcglast947:
  %v3675 = load i64, ptr %slot606, align 8
  %op3676 = sub i64 %v3675, 32
  store i64 %op3676, ptr %slot616, align 8
  %v3677 = load i64, ptr %slot606, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  %rgep3679 = getelementptr i8, ptr %p3678, i64 -32
  %ld3680 = load i64, ptr %rgep3679, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3680, ptr %slot617, align 8
  %v3681 = load i64, ptr %slot617, align 8
  %cmp3682 = icmp ne i64 %v3681, 0
  %cv3683 = zext i1 %cmp3682 to i32
  store i32 %cv3683, ptr %slot618, align 8
  %v3684 = load i32, ptr %slot618, align 8
  %cv3685 = zext i32 %v3684 to i64
  %cond3686 = icmp ne i64 %cv3685, 0
  br i1 %cond3686, label %bb_rcgdec947, label %bb_rcgslow947
bb_rcgslow947:
  %v3687 = load i64, ptr %slot605, align 8
  %v3688 = load i64, ptr %slot602, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3687, i64 %v3688) nomerge, !dbg !132
  br label %bb_rcgdone947
bb_rcgdec947:
  %v3689 = load i64, ptr %slot614, align 8
  %v3690 = load i64, ptr %slot606, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %rgep3692 = getelementptr i8, ptr %p3691, i64 -24
  store i64 %v3689, ptr %rgep3692, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear947
bb_rcgclear947:
  %v3693 = load i64, ptr %slot602, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  store i64 0, ptr %p3694, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone947
bb_rcgdone947:
  br label %bb_rcslotdone931
bb_rcslotowner931:
  %v3695 = load i64, ptr %slot34, align 8
  store i64 %v3695, ptr %slot619, align 8
  %v3696 = load i64, ptr %slot602, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i64, ptr %p3697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3698, ptr %slot620, align 8
  %v3699 = load i64, ptr %slot620, align 8
  %cmp3700 = icmp ne i64 %v3699, 0
  %cv3701 = zext i1 %cmp3700 to i32
  store i32 %cv3701, ptr %slot621, align 8
  %v3702 = load i32, ptr %slot621, align 8
  %cv3703 = zext i32 %v3702 to i64
  %cond3704 = icmp ne i64 %cv3703, 0
  br i1 %cond3704, label %bb_rcgnn962, label %bb_rcgdone962
bb_rcgnn962:
  %v3705 = load i64, ptr %slot620, align 8
  %op3706 = sub i64 %v3705, 16
  store i64 %op3706, ptr %slot622, align 8
  %v3707 = load i64, ptr %slot620, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  %rgep3709 = getelementptr i8, ptr %p3708, i64 -16
  %ld3710 = load i64, ptr %rgep3709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3710, ptr %slot623, align 8
  %v3711 = load i64, ptr %slot623, align 8
  %op3712 = and i64 %v3711, 4611686018427387906
  store i64 %op3712, ptr %slot624, align 8
  %v3713 = load i64, ptr %slot624, align 8
  %cmp3714 = icmp ne i64 %v3713, 0
  %cv3715 = zext i1 %cmp3714 to i32
  store i32 %cv3715, ptr %slot625, align 8
  %v3716 = load i32, ptr %slot625, align 8
  %cv3717 = zext i32 %v3716 to i64
  %cond3718 = icmp ne i64 %cv3717, 0
  br i1 %cond3718, label %bb_rcgclear962, label %bb_rcgcounted962
bb_rcgcounted962:
  %v3719 = load i64, ptr %slot620, align 8
  %op3720 = sub i64 %v3719, 32
  store i64 %op3720, ptr %slot626, align 8
  %v3721 = load i64, ptr %slot620, align 8
  %p3722 = inttoptr i64 %v3721 to ptr
  %rgep3723 = getelementptr i8, ptr %p3722, i64 -32
  %ld3724 = load i64, ptr %rgep3723, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3724, ptr %slot627, align 8
  %v3725 = load i64, ptr %slot627, align 8
  %op3726 = sub i64 %v3725, 1
  store i64 %op3726, ptr %slot628, align 8
  %v3727 = load i64, ptr %slot628, align 8
  %cmp3728 = icmp eq i64 %v3727, 0
  %cv3729 = zext i1 %cmp3728 to i32
  store i32 %cv3729, ptr %slot629, align 8
  %v3730 = load i32, ptr %slot629, align 8
  %cv3731 = zext i32 %v3730 to i64
  %cond3732 = icmp ne i64 %cv3731, 0
  br i1 %cond3732, label %bb_rcglast962, label %bb_rcgdec962
bb_rcglast962:
  %v3733 = load i64, ptr %slot620, align 8
  %op3734 = sub i64 %v3733, 24
  store i64 %op3734, ptr %slot630, align 8
  %v3735 = load i64, ptr %slot620, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  %rgep3737 = getelementptr i8, ptr %p3736, i64 -24
  %ld3738 = load i64, ptr %rgep3737, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3738, ptr %slot631, align 8
  %v3739 = load i64, ptr %slot631, align 8
  %cmp3740 = icmp ne i64 %v3739, 0
  %cv3741 = zext i1 %cmp3740 to i32
  store i32 %cv3741, ptr %slot632, align 8
  %v3742 = load i32, ptr %slot632, align 8
  %cv3743 = zext i32 %v3742 to i64
  %cond3744 = icmp ne i64 %cv3743, 0
  br i1 %cond3744, label %bb_rcgdec962, label %bb_rcgslow962
bb_rcgslow962:
  %v3745 = load i64, ptr %slot619, align 8
  %v3746 = load i64, ptr %slot602, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3745, i64 %v3746) nomerge, !dbg !132
  br label %bb_rcgdone962
bb_rcgdec962:
  %v3747 = load i64, ptr %slot628, align 8
  %v3748 = load i64, ptr %slot620, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %rgep3750 = getelementptr i8, ptr %p3749, i64 -32
  store i64 %v3747, ptr %rgep3750, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear962
bb_rcgclear962:
  %v3751 = load i64, ptr %slot602, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  store i64 0, ptr %p3752, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone962
bb_rcgdone962:
  br label %bb_rcslotdone931
bb_rcslotdone931:
  %v3753 = load i64, ptr %slot28, align 8
  store i64 %v3753, ptr %slot633, align 8
  %v3754 = load i64, ptr %slot17, align 8
  store i64 %v3754, ptr %slot634, align 8
  %v3755 = load i64, ptr %slot634, align 8
  %v3756 = load i64, ptr %slot633, align 8
  %p3757 = inttoptr i64 %v3755 to ptr
  %p3758 = inttoptr i64 %v3756 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3758, ptr %p3757, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3759 = load i64, ptr %slot13, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  store i32 0, ptr %p3760, align 4, !alias.scope !3, !noalias !4
  %v3761 = load i64, ptr %slot8, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  store i32 2, ptr %p3762, align 4, !alias.scope !3, !noalias !4
  %v3763 = load i64, ptr %slot14, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  %ld3765 = load i32, ptr %p3764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3765, ptr %slot635, align 8
  %v3766 = load i32, ptr %slot635, align 8
  %v3767 = load i64, ptr %slot8, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  store i32 %v3766, ptr %p3768, align 4, !alias.scope !3, !noalias !4
  %v3769 = load i64, ptr %slot7, align 8
  %p3770 = inttoptr i64 %v3769 to ptr
  store i32 1, ptr %p3770, align 4, !alias.scope !3, !noalias !4
  %v3771 = load i64, ptr %slot5, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  %ld3773 = load i32, ptr %p3772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3773, ptr %slot636, align 8
  %v3774 = load i32, ptr %slot636, align 8
  %cv3775 = zext i32 %v3774 to i64
  %cond3776 = icmp ne i64 %cv3775, 0
  br i1 %cond3776, label %bb_rcslotdrop975, label %bb_rcslotdone975
bb_rcslotdrop975:
  %v3777 = load i64, ptr %slot5, align 8
  %p3778 = inttoptr i64 %v3777 to ptr
  store i32 0, ptr %p3778, align 4, !alias.scope !3, !noalias !4
  %v3779 = load i64, ptr %slot27, align 8
  store i64 %v3779, ptr %slot637, align 8
  %v3780 = load i64, ptr %slot6, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  %ld3782 = load i32, ptr %p3781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3782, ptr %slot638, align 8
  %v3783 = load i32, ptr %slot638, align 8
  %op3784 = and i32 %v3783, 28
  store i32 %op3784, ptr %slot639, align 8
  %v3785 = load i32, ptr %slot639, align 8
  %cv3786 = zext i32 %v3785 to i64
  %cond3787 = icmp ne i64 %cv3786, 0
  br i1 %cond3787, label %bb_rcslotrole975, label %bb_rcslotowner975
bb_rcslotrole975:
  %v3788 = load i64, ptr %slot34, align 8
  store i64 %v3788, ptr %slot640, align 8
  %v3789 = load i64, ptr %slot637, align 8
  %p3790 = inttoptr i64 %v3789 to ptr
  %ld3791 = load i64, ptr %p3790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3791, ptr %slot641, align 8
  %v3792 = load i64, ptr %slot641, align 8
  %cmp3793 = icmp ne i64 %v3792, 0
  %cv3794 = zext i1 %cmp3793 to i32
  store i32 %cv3794, ptr %slot642, align 8
  %v3795 = load i32, ptr %slot642, align 8
  %cv3796 = zext i32 %v3795 to i64
  %cond3797 = icmp ne i64 %cv3796, 0
  br i1 %cond3797, label %bb_rcgnn991, label %bb_rcgdone991
bb_rcgnn991:
  %v3798 = load i64, ptr %slot641, align 8
  %op3799 = sub i64 %v3798, 16
  store i64 %op3799, ptr %slot643, align 8
  %v3800 = load i64, ptr %slot641, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  %rgep3802 = getelementptr i8, ptr %p3801, i64 -16
  %ld3803 = load i64, ptr %rgep3802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3803, ptr %slot644, align 8
  %v3804 = load i64, ptr %slot644, align 8
  %op3805 = and i64 %v3804, 4611686018427387906
  store i64 %op3805, ptr %slot645, align 8
  %v3806 = load i64, ptr %slot645, align 8
  %cmp3807 = icmp ne i64 %v3806, 0
  %cv3808 = zext i1 %cmp3807 to i32
  store i32 %cv3808, ptr %slot646, align 8
  %v3809 = load i32, ptr %slot646, align 8
  %cv3810 = zext i32 %v3809 to i64
  %cond3811 = icmp ne i64 %cv3810, 0
  br i1 %cond3811, label %bb_rcgclear991, label %bb_rcgcounted991
bb_rcgcounted991:
  %v3812 = load i64, ptr %slot641, align 8
  %op3813 = sub i64 %v3812, 24
  store i64 %op3813, ptr %slot647, align 8
  %v3814 = load i64, ptr %slot641, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  %rgep3816 = getelementptr i8, ptr %p3815, i64 -24
  %ld3817 = load i64, ptr %rgep3816, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3817, ptr %slot648, align 8
  %v3818 = load i64, ptr %slot648, align 8
  %op3819 = sub i64 %v3818, 1
  store i64 %op3819, ptr %slot649, align 8
  %v3820 = load i64, ptr %slot649, align 8
  %cmp3821 = icmp eq i64 %v3820, 0
  %cv3822 = zext i1 %cmp3821 to i32
  store i32 %cv3822, ptr %slot650, align 8
  %v3823 = load i32, ptr %slot650, align 8
  %cv3824 = zext i32 %v3823 to i64
  %cond3825 = icmp ne i64 %cv3824, 0
  br i1 %cond3825, label %bb_rcglast991, label %bb_rcgdec991
bb_rcglast991:
  %v3826 = load i64, ptr %slot641, align 8
  %op3827 = sub i64 %v3826, 32
  store i64 %op3827, ptr %slot651, align 8
  %v3828 = load i64, ptr %slot641, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  %rgep3830 = getelementptr i8, ptr %p3829, i64 -32
  %ld3831 = load i64, ptr %rgep3830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3831, ptr %slot652, align 8
  %v3832 = load i64, ptr %slot652, align 8
  %cmp3833 = icmp ne i64 %v3832, 0
  %cv3834 = zext i1 %cmp3833 to i32
  store i32 %cv3834, ptr %slot653, align 8
  %v3835 = load i32, ptr %slot653, align 8
  %cv3836 = zext i32 %v3835 to i64
  %cond3837 = icmp ne i64 %cv3836, 0
  br i1 %cond3837, label %bb_rcgdec991, label %bb_rcgslow991
bb_rcgslow991:
  %v3838 = load i64, ptr %slot640, align 8
  %v3839 = load i64, ptr %slot637, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3838, i64 %v3839) nomerge, !dbg !132
  br label %bb_rcgdone991
bb_rcgdec991:
  %v3840 = load i64, ptr %slot649, align 8
  %v3841 = load i64, ptr %slot641, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %rgep3843 = getelementptr i8, ptr %p3842, i64 -24
  store i64 %v3840, ptr %rgep3843, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear991
bb_rcgclear991:
  %v3844 = load i64, ptr %slot637, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  store i64 0, ptr %p3845, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone991
bb_rcgdone991:
  br label %bb_rcslotdone975
bb_rcslotowner975:
  %v3846 = load i64, ptr %slot34, align 8
  store i64 %v3846, ptr %slot654, align 8
  %v3847 = load i64, ptr %slot637, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i64, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3849, ptr %slot655, align 8
  %v3850 = load i64, ptr %slot655, align 8
  %cmp3851 = icmp ne i64 %v3850, 0
  %cv3852 = zext i1 %cmp3851 to i32
  store i32 %cv3852, ptr %slot656, align 8
  %v3853 = load i32, ptr %slot656, align 8
  %cv3854 = zext i32 %v3853 to i64
  %cond3855 = icmp ne i64 %cv3854, 0
  br i1 %cond3855, label %bb_rcgnn1006, label %bb_rcgdone1006
bb_rcgnn1006:
  %v3856 = load i64, ptr %slot655, align 8
  %op3857 = sub i64 %v3856, 16
  store i64 %op3857, ptr %slot657, align 8
  %v3858 = load i64, ptr %slot655, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %rgep3860 = getelementptr i8, ptr %p3859, i64 -16
  %ld3861 = load i64, ptr %rgep3860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3861, ptr %slot658, align 8
  %v3862 = load i64, ptr %slot658, align 8
  %op3863 = and i64 %v3862, 4611686018427387906
  store i64 %op3863, ptr %slot659, align 8
  %v3864 = load i64, ptr %slot659, align 8
  %cmp3865 = icmp ne i64 %v3864, 0
  %cv3866 = zext i1 %cmp3865 to i32
  store i32 %cv3866, ptr %slot660, align 8
  %v3867 = load i32, ptr %slot660, align 8
  %cv3868 = zext i32 %v3867 to i64
  %cond3869 = icmp ne i64 %cv3868, 0
  br i1 %cond3869, label %bb_rcgclear1006, label %bb_rcgcounted1006
bb_rcgcounted1006:
  %v3870 = load i64, ptr %slot655, align 8
  %op3871 = sub i64 %v3870, 32
  store i64 %op3871, ptr %slot661, align 8
  %v3872 = load i64, ptr %slot655, align 8
  %p3873 = inttoptr i64 %v3872 to ptr
  %rgep3874 = getelementptr i8, ptr %p3873, i64 -32
  %ld3875 = load i64, ptr %rgep3874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3875, ptr %slot662, align 8
  %v3876 = load i64, ptr %slot662, align 8
  %op3877 = sub i64 %v3876, 1
  store i64 %op3877, ptr %slot663, align 8
  %v3878 = load i64, ptr %slot663, align 8
  %cmp3879 = icmp eq i64 %v3878, 0
  %cv3880 = zext i1 %cmp3879 to i32
  store i32 %cv3880, ptr %slot664, align 8
  %v3881 = load i32, ptr %slot664, align 8
  %cv3882 = zext i32 %v3881 to i64
  %cond3883 = icmp ne i64 %cv3882, 0
  br i1 %cond3883, label %bb_rcglast1006, label %bb_rcgdec1006
bb_rcglast1006:
  %v3884 = load i64, ptr %slot655, align 8
  %op3885 = sub i64 %v3884, 24
  store i64 %op3885, ptr %slot665, align 8
  %v3886 = load i64, ptr %slot655, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %rgep3888 = getelementptr i8, ptr %p3887, i64 -24
  %ld3889 = load i64, ptr %rgep3888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3889, ptr %slot666, align 8
  %v3890 = load i64, ptr %slot666, align 8
  %cmp3891 = icmp ne i64 %v3890, 0
  %cv3892 = zext i1 %cmp3891 to i32
  store i32 %cv3892, ptr %slot667, align 8
  %v3893 = load i32, ptr %slot667, align 8
  %cv3894 = zext i32 %v3893 to i64
  %cond3895 = icmp ne i64 %cv3894, 0
  br i1 %cond3895, label %bb_rcgdec1006, label %bb_rcgslow1006
bb_rcgslow1006:
  %v3896 = load i64, ptr %slot654, align 8
  %v3897 = load i64, ptr %slot637, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3896, i64 %v3897) nomerge, !dbg !132
  br label %bb_rcgdone1006
bb_rcgdec1006:
  %v3898 = load i64, ptr %slot663, align 8
  %v3899 = load i64, ptr %slot655, align 8
  %p3900 = inttoptr i64 %v3899 to ptr
  %rgep3901 = getelementptr i8, ptr %p3900, i64 -32
  store i64 %v3898, ptr %rgep3901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1006
bb_rcgclear1006:
  %v3902 = load i64, ptr %slot637, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  store i64 0, ptr %p3903, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1006
bb_rcgdone1006:
  br label %bb_rcslotdone975
bb_rcslotdone975:
  %v3904 = load i64, ptr %slot28, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  %ld3906 = load i64, ptr %p3905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3906, ptr %slot668, align 8
  %v3907 = load i64, ptr %slot668, align 8
  %v3908 = load i64, ptr %slot31, align 8
  %p3909 = inttoptr i64 %v3908 to ptr
  store i64 %v3907, ptr %p3909, align 8, !alias.scope !3, !noalias !4
  %v3910 = load i64, ptr %slot31, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  %ld3912 = load i64, ptr %p3911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3912, ptr %slot669, align 8
  %v3913 = load i64, ptr %slot1, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %v3915 = load i64, ptr %slot669, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %call3917 = call ptr @myl_qbe_bytes_from_list(ptr %p3914, ptr %p3916) nomerge, !dbg !134
  %calladdr3918 = ptrtoint ptr %call3917 to i64
  store i64 %calladdr3918, ptr %slot670, align 8
  %v3919 = load i64, ptr %slot670, align 8
  %v3920 = load i64, ptr %slot31, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i64 %v3919, ptr %p3921, align 8, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot31, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  %ld3924 = load i64, ptr %p3923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3924, ptr %slot671, align 8
  %v3925 = load i64, ptr %slot671, align 8
  %v3926 = load i64, ptr %slot16, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  store i64 %v3925, ptr %p3927, align 8, !alias.scope !3, !noalias !4
  %v3928 = load i64, ptr %slot16, align 8
  store i64 %v3928, ptr %slot672, align 8
  %v3929 = load i64, ptr %slot17, align 8
  store i64 %v3929, ptr %slot673, align 8
  %v3930 = load i64, ptr %slot672, align 8
  %v3931 = load i64, ptr %slot673, align 8
  %p3932 = inttoptr i64 %v3930 to ptr
  %p3933 = inttoptr i64 %v3931 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3933, ptr %p3932, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3934 = load i64, ptr %slot14, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  store i32 2, ptr %p3935, align 4, !alias.scope !3, !noalias !4
  %v3936 = load i64, ptr %slot13, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  store i32 1, ptr %p3937, align 4, !alias.scope !3, !noalias !4
  %v3938 = load i64, ptr %slot11, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %ld3940 = load i32, ptr %p3939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3940, ptr %slot674, align 8
  %v3941 = load i32, ptr %slot674, align 8
  %cv3942 = zext i32 %v3941 to i64
  %cond3943 = icmp ne i64 %cv3942, 0
  br i1 %cond3943, label %bb_rcslotdrop1020, label %bb_rcslotdone1020
bb_rcslotdrop1020:
  %v3944 = load i64, ptr %slot11, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  store i32 0, ptr %p3945, align 4, !alias.scope !3, !noalias !4
  %v3946 = load i64, ptr %slot15, align 8
  store i64 %v3946, ptr %slot675, align 8
  %v3947 = load i64, ptr %slot12, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  %ld3949 = load i32, ptr %p3948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3949, ptr %slot676, align 8
  %v3950 = load i32, ptr %slot676, align 8
  %op3951 = and i32 %v3950, 28
  store i32 %op3951, ptr %slot677, align 8
  %v3952 = load i32, ptr %slot677, align 8
  %cv3953 = zext i32 %v3952 to i64
  %cond3954 = icmp ne i64 %cv3953, 0
  br i1 %cond3954, label %bb_rcslotrole1020, label %bb_rcslotowner1020
bb_rcslotrole1020:
  %v3955 = load i64, ptr %slot34, align 8
  store i64 %v3955, ptr %slot678, align 8
  %v3956 = load i64, ptr %slot675, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  %ld3958 = load i64, ptr %p3957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3958, ptr %slot679, align 8
  %v3959 = load i64, ptr %slot679, align 8
  %cmp3960 = icmp ne i64 %v3959, 0
  %cv3961 = zext i1 %cmp3960 to i32
  store i32 %cv3961, ptr %slot680, align 8
  %v3962 = load i32, ptr %slot680, align 8
  %cv3963 = zext i32 %v3962 to i64
  %cond3964 = icmp ne i64 %cv3963, 0
  br i1 %cond3964, label %bb_rcgnn1036, label %bb_rcgdone1036
bb_rcgnn1036:
  %v3965 = load i64, ptr %slot679, align 8
  %op3966 = sub i64 %v3965, 16
  store i64 %op3966, ptr %slot681, align 8
  %v3967 = load i64, ptr %slot679, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  %rgep3969 = getelementptr i8, ptr %p3968, i64 -16
  %ld3970 = load i64, ptr %rgep3969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3970, ptr %slot682, align 8
  %v3971 = load i64, ptr %slot682, align 8
  %op3972 = and i64 %v3971, 4611686018427387906
  store i64 %op3972, ptr %slot683, align 8
  %v3973 = load i64, ptr %slot683, align 8
  %cmp3974 = icmp ne i64 %v3973, 0
  %cv3975 = zext i1 %cmp3974 to i32
  store i32 %cv3975, ptr %slot684, align 8
  %v3976 = load i32, ptr %slot684, align 8
  %cv3977 = zext i32 %v3976 to i64
  %cond3978 = icmp ne i64 %cv3977, 0
  br i1 %cond3978, label %bb_rcgclear1036, label %bb_rcgcounted1036
bb_rcgcounted1036:
  %v3979 = load i64, ptr %slot679, align 8
  %op3980 = sub i64 %v3979, 24
  store i64 %op3980, ptr %slot685, align 8
  %v3981 = load i64, ptr %slot679, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  %rgep3983 = getelementptr i8, ptr %p3982, i64 -24
  %ld3984 = load i64, ptr %rgep3983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3984, ptr %slot686, align 8
  %v3985 = load i64, ptr %slot686, align 8
  %op3986 = sub i64 %v3985, 1
  store i64 %op3986, ptr %slot687, align 8
  %v3987 = load i64, ptr %slot687, align 8
  %cmp3988 = icmp eq i64 %v3987, 0
  %cv3989 = zext i1 %cmp3988 to i32
  store i32 %cv3989, ptr %slot688, align 8
  %v3990 = load i32, ptr %slot688, align 8
  %cv3991 = zext i32 %v3990 to i64
  %cond3992 = icmp ne i64 %cv3991, 0
  br i1 %cond3992, label %bb_rcglast1036, label %bb_rcgdec1036
bb_rcglast1036:
  %v3993 = load i64, ptr %slot679, align 8
  %op3994 = sub i64 %v3993, 32
  store i64 %op3994, ptr %slot689, align 8
  %v3995 = load i64, ptr %slot679, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  %rgep3997 = getelementptr i8, ptr %p3996, i64 -32
  %ld3998 = load i64, ptr %rgep3997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3998, ptr %slot690, align 8
  %v3999 = load i64, ptr %slot690, align 8
  %cmp4000 = icmp ne i64 %v3999, 0
  %cv4001 = zext i1 %cmp4000 to i32
  store i32 %cv4001, ptr %slot691, align 8
  %v4002 = load i32, ptr %slot691, align 8
  %cv4003 = zext i32 %v4002 to i64
  %cond4004 = icmp ne i64 %cv4003, 0
  br i1 %cond4004, label %bb_rcgdec1036, label %bb_rcgslow1036
bb_rcgslow1036:
  %v4005 = load i64, ptr %slot678, align 8
  %v4006 = load i64, ptr %slot675, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4005, i64 %v4006) nomerge, !dbg !134
  br label %bb_rcgdone1036
bb_rcgdec1036:
  %v4007 = load i64, ptr %slot687, align 8
  %v4008 = load i64, ptr %slot679, align 8
  %p4009 = inttoptr i64 %v4008 to ptr
  %rgep4010 = getelementptr i8, ptr %p4009, i64 -24
  store i64 %v4007, ptr %rgep4010, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1036
bb_rcgclear1036:
  %v4011 = load i64, ptr %slot675, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  store i64 0, ptr %p4012, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1036
bb_rcgdone1036:
  br label %bb_rcslotdone1020
bb_rcslotowner1020:
  %v4013 = load i64, ptr %slot34, align 8
  store i64 %v4013, ptr %slot692, align 8
  %v4014 = load i64, ptr %slot675, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i64, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4016, ptr %slot693, align 8
  %v4017 = load i64, ptr %slot693, align 8
  %cmp4018 = icmp ne i64 %v4017, 0
  %cv4019 = zext i1 %cmp4018 to i32
  store i32 %cv4019, ptr %slot694, align 8
  %v4020 = load i32, ptr %slot694, align 8
  %cv4021 = zext i32 %v4020 to i64
  %cond4022 = icmp ne i64 %cv4021, 0
  br i1 %cond4022, label %bb_rcgnn1051, label %bb_rcgdone1051
bb_rcgnn1051:
  %v4023 = load i64, ptr %slot693, align 8
  %op4024 = sub i64 %v4023, 16
  store i64 %op4024, ptr %slot695, align 8
  %v4025 = load i64, ptr %slot693, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  %rgep4027 = getelementptr i8, ptr %p4026, i64 -16
  %ld4028 = load i64, ptr %rgep4027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4028, ptr %slot696, align 8
  %v4029 = load i64, ptr %slot696, align 8
  %op4030 = and i64 %v4029, 4611686018427387906
  store i64 %op4030, ptr %slot697, align 8
  %v4031 = load i64, ptr %slot697, align 8
  %cmp4032 = icmp ne i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot698, align 8
  %v4034 = load i32, ptr %slot698, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcgclear1051, label %bb_rcgcounted1051
bb_rcgcounted1051:
  %v4037 = load i64, ptr %slot693, align 8
  %op4038 = sub i64 %v4037, 32
  store i64 %op4038, ptr %slot699, align 8
  %v4039 = load i64, ptr %slot693, align 8
  %p4040 = inttoptr i64 %v4039 to ptr
  %rgep4041 = getelementptr i8, ptr %p4040, i64 -32
  %ld4042 = load i64, ptr %rgep4041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4042, ptr %slot700, align 8
  %v4043 = load i64, ptr %slot700, align 8
  %op4044 = sub i64 %v4043, 1
  store i64 %op4044, ptr %slot701, align 8
  %v4045 = load i64, ptr %slot701, align 8
  %cmp4046 = icmp eq i64 %v4045, 0
  %cv4047 = zext i1 %cmp4046 to i32
  store i32 %cv4047, ptr %slot702, align 8
  %v4048 = load i32, ptr %slot702, align 8
  %cv4049 = zext i32 %v4048 to i64
  %cond4050 = icmp ne i64 %cv4049, 0
  br i1 %cond4050, label %bb_rcglast1051, label %bb_rcgdec1051
bb_rcglast1051:
  %v4051 = load i64, ptr %slot693, align 8
  %op4052 = sub i64 %v4051, 24
  store i64 %op4052, ptr %slot703, align 8
  %v4053 = load i64, ptr %slot693, align 8
  %p4054 = inttoptr i64 %v4053 to ptr
  %rgep4055 = getelementptr i8, ptr %p4054, i64 -24
  %ld4056 = load i64, ptr %rgep4055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4056, ptr %slot704, align 8
  %v4057 = load i64, ptr %slot704, align 8
  %cmp4058 = icmp ne i64 %v4057, 0
  %cv4059 = zext i1 %cmp4058 to i32
  store i32 %cv4059, ptr %slot705, align 8
  %v4060 = load i32, ptr %slot705, align 8
  %cv4061 = zext i32 %v4060 to i64
  %cond4062 = icmp ne i64 %cv4061, 0
  br i1 %cond4062, label %bb_rcgdec1051, label %bb_rcgslow1051
bb_rcgslow1051:
  %v4063 = load i64, ptr %slot692, align 8
  %v4064 = load i64, ptr %slot675, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4063, i64 %v4064) nomerge, !dbg !134
  br label %bb_rcgdone1051
bb_rcgdec1051:
  %v4065 = load i64, ptr %slot701, align 8
  %v4066 = load i64, ptr %slot693, align 8
  %p4067 = inttoptr i64 %v4066 to ptr
  %rgep4068 = getelementptr i8, ptr %p4067, i64 -32
  store i64 %v4065, ptr %rgep4068, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1051
bb_rcgclear1051:
  %v4069 = load i64, ptr %slot675, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  store i64 0, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1051
bb_rcgdone1051:
  br label %bb_rcslotdone1020
bb_rcslotdone1020:
  %v4071 = load i64, ptr %slot15, align 8
  store i64 %v4071, ptr %slot706, align 8
  %v4072 = load i64, ptr %slot17, align 8
  store i64 %v4072, ptr %slot707, align 8
  %v4073 = load i64, ptr %slot707, align 8
  %v4074 = load i64, ptr %slot706, align 8
  %p4075 = inttoptr i64 %v4073 to ptr
  %p4076 = inttoptr i64 %v4074 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4076, ptr %p4075, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot12, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  store i32 2, ptr %p4078, align 4, !alias.scope !3, !noalias !4
  %v4079 = load i64, ptr %slot14, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  %ld4081 = load i32, ptr %p4080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4081, ptr %slot708, align 8
  %v4082 = load i32, ptr %slot708, align 8
  %v4083 = load i64, ptr %slot12, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  store i32 %v4082, ptr %p4084, align 4, !alias.scope !3, !noalias !4
  %v4085 = load i64, ptr %slot13, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  store i32 0, ptr %p4086, align 4, !alias.scope !3, !noalias !4
  %v4087 = load i64, ptr %slot11, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  store i32 1, ptr %p4088, align 4, !alias.scope !3, !noalias !4
  %v4089 = load i64, ptr %slot706, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %ld4091 = load i64, ptr %p4090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4091, ptr %slot709, align 8
  %v4092 = load i64, ptr %slot709, align 8
  %v4093 = load i64, ptr %slot31, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i64 %v4092, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  %v4095 = load i64, ptr %slot31, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  %ld4097 = load i64, ptr %p4096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4097, ptr %slot710, align 8
  %v4098 = load i64, ptr %slot710, align 8
  %v4099 = load i64, ptr %slot16, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i64 %v4098, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  %v4101 = load i64, ptr %slot16, align 8
  store i64 %v4101, ptr %slot711, align 8
  %v4102 = load i64, ptr %slot11, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %ld4104 = load i32, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4104, ptr %slot712, align 8
  %v4105 = load i64, ptr %slot12, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %ld4107 = load i32, ptr %p4106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4107, ptr %slot713, align 8
  %v4108 = load i32, ptr %slot713, align 8
  %op4109 = and i32 %v4108, 24
  store i32 %op4109, ptr %slot713, align 8
  %v4110 = load i32, ptr %slot713, align 8
  %cmp4111 = icmp eq i32 %v4110, 0
  %cv4112 = zext i1 %cmp4111 to i32
  store i32 %cv4112, ptr %slot714, align 8
  %v4113 = load i32, ptr %slot712, align 8
  %v4114 = load i32, ptr %slot714, align 8
  %op4115 = and i32 %v4113, %v4114
  store i32 %op4115, ptr %slot715, align 8
  %v4116 = load i32, ptr %slot715, align 8
  %cv4117 = zext i32 %v4116 to i64
  %cond4118 = icmp ne i64 %cv4117, 0
  br i1 %cond4118, label %bb_rctake1066, label %bb_rccopy1066
bb_rctake1066:
  %v4119 = load i64, ptr %slot17, align 8
  store i64 %v4119, ptr %slot716, align 8
  %v4120 = load i64, ptr %slot35, align 8
  store i64 %v4120, ptr %slot717, align 8
  %v4121 = load i64, ptr %slot711, align 8
  %v4122 = load i64, ptr %slot716, align 8
  %op4123 = sub i64 %v4121, %v4122
  store i64 %op4123, ptr %slot718, align 8
  %v4124 = load i64, ptr %slot716, align 8
  %v4125 = load i64, ptr %slot711, align 8
  %op4126 = sub i64 %v4124, %v4125
  store i64 %op4126, ptr %slot719, align 8
  %v4127 = load i64, ptr %slot718, align 8
  %cmp4128 = icmp ult i64 %v4127, 8
  %cv4129 = zext i1 %cmp4128 to i32
  store i32 %cv4129, ptr %slot720, align 8
  %v4130 = load i64, ptr %slot719, align 8
  %cmp4131 = icmp ult i64 %v4130, 8
  %cv4132 = zext i1 %cmp4131 to i32
  store i32 %cv4132, ptr %slot721, align 8
  %v4133 = load i32, ptr %slot720, align 8
  %v4134 = load i32, ptr %slot721, align 8
  %op4135 = or i32 %v4133, %v4134
  store i32 %op4135, ptr %slot722, align 8
  %v4136 = load i32, ptr %slot722, align 8
  %cv4137 = zext i32 %v4136 to i64
  %cond4138 = icmp ne i64 %cv4137, 0
  br i1 %cond4138, label %bb_rcmoveslow1075, label %bb_rcmovecheck1075
bb_rcmovecheck1075:
  %v4139 = load i64, ptr %slot711, align 8
  %p4141 = inttoptr i64 %v4139 to ptr
  %gep4142 = getelementptr i8, ptr %p4141, i64 0
  %op4140 = ptrtoint ptr %gep4142 to i64
  store i64 %op4140, ptr %slot723, align 8
  %v4143 = load i64, ptr %slot723, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %ld4145 = load i64, ptr %p4144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4145, ptr %slot724, align 8
  %v4146 = load i64, ptr %slot724, align 8
  %cmp4147 = icmp ne i64 %v4146, 0
  %cv4148 = zext i1 %cmp4147 to i32
  store i32 %cv4148, ptr %slot725, align 8
  %v4149 = load i32, ptr %slot725, align 8
  %cv4150 = zext i32 %v4149 to i64
  %cond4151 = icmp ne i64 %cv4150, 0
  br i1 %cond4151, label %bb_rcmoveheader1083, label %bb_rcmovenext1083
bb_rcmoveheader1083:
  %v4152 = load i64, ptr %slot724, align 8
  %op4153 = sub i64 %v4152, 16
  store i64 %op4153, ptr %slot726, align 8
  %v4154 = load i64, ptr %slot724, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  %rgep4156 = getelementptr i8, ptr %p4155, i64 -16
  %ld4157 = load i64, ptr %rgep4156, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4157, ptr %slot727, align 8
  %v4158 = load i64, ptr %slot727, align 8
  %op4159 = and i64 %v4158, 5764607523034234881
  store i64 %op4159, ptr %slot728, align 8
  %v4160 = load i64, ptr %slot728, align 8
  %cmp4161 = icmp ne i64 %v4160, 0
  %cv4162 = zext i1 %cmp4161 to i32
  store i32 %cv4162, ptr %slot729, align 8
  %v4163 = load i32, ptr %slot729, align 8
  %cv4164 = zext i32 %v4163 to i64
  %cond4165 = icmp ne i64 %cv4164, 0
  br i1 %cond4165, label %bb_rcmoveslow1075, label %bb_rcmovenext1083
bb_rcmovenext1083:
  %v4166 = load i64, ptr %slot711, align 8
  %v4167 = load i64, ptr %slot716, align 8
  %p4168 = inttoptr i64 %v4166 to ptr
  %p4169 = inttoptr i64 %v4167 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4169, ptr %p4168, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4170 = load i64, ptr %slot711, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  store i64 0, ptr %p4171, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1075
bb_rcmoveslow1075:
  %v4172 = load i64, ptr %slot34, align 8
  %v4173 = load i64, ptr %slot716, align 8
  %v4174 = load i64, ptr %slot711, align 8
  %v4175 = load i64, ptr %slot717, align 8
  %cv4176 = trunc i64 %v4175 to i32
  %call4177 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v4172, i64 %v4173, i64 %v4174, i32 %cv4176) nomerge, !dbg !136
  store i32 %call4177, ptr %slot730, align 8
  %v4178 = load i32, ptr %slot730, align 8
  %cv4179 = zext i32 %v4178 to i64
  %cond4180 = icmp ne i64 %cv4179, 0
  br i1 %cond4180, label %bb_rcsuccess1090, label %bb_rcfailure1090
bb_rcfailure1090:
  %v4181 = load i64, ptr %slot34, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %call4183 = call i32 @myl_rc_take_failure(ptr %p4182) nomerge, !dbg !136
  store i32 %call4183, ptr %slot731, align 8
  %v4184 = load i64, ptr %slot1, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %v4186 = load i32, ptr %slot731, align 8
  %call4187 = call i32 @myl_qbe_rc_status(ptr %p4185, i32 %v4186) nomerge, !dbg !136
  store i32 %call4187, ptr %slot732, align 8
  br label %bb_failure
bb_rcsuccess1090:
  br label %bb_rcmoved1075
bb_rcmoved1075:
  %v4188 = load i64, ptr %slot11, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  store i32 0, ptr %p4189, align 4, !alias.scope !3, !noalias !4
  %v4190 = load i64, ptr %slot14, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  store i32 2, ptr %p4191, align 4, !alias.scope !3, !noalias !4
  %v4192 = load i64, ptr %slot13, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  store i32 1, ptr %p4193, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1066
bb_rccopy1066:
  %v4194 = load i64, ptr %slot17, align 8
  store i64 %v4194, ptr %slot733, align 8
  %v4195 = load i64, ptr %slot35, align 8
  store i64 %v4195, ptr %slot734, align 8
  %v4196 = load i64, ptr %slot711, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  %ld4198 = load i64, ptr %p4197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4198, ptr %slot735, align 8
  %v4199 = load i64, ptr %slot735, align 8
  %cmp4200 = icmp ne i64 %v4199, 0
  %cv4201 = zext i1 %cmp4200 to i32
  store i32 %cv4201, ptr %slot736, align 8
  %v4202 = load i32, ptr %slot736, align 8
  %cv4203 = zext i32 %v4202 to i64
  %cond4204 = icmp ne i64 %cv4203, 0
  br i1 %cond4204, label %bb_rcgnn1099, label %bb_rcgplain1099
bb_rcgnn1099:
  %v4205 = load i64, ptr %slot735, align 8
  %op4206 = sub i64 %v4205, 16
  store i64 %op4206, ptr %slot737, align 8
  %v4207 = load i64, ptr %slot735, align 8
  %p4208 = inttoptr i64 %v4207 to ptr
  %rgep4209 = getelementptr i8, ptr %p4208, i64 -16
  %ld4210 = load i64, ptr %rgep4209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4210, ptr %slot738, align 8
  %v4211 = load i64, ptr %slot738, align 8
  %op4212 = and i64 %v4211, 4611686018427387906
  store i64 %op4212, ptr %slot739, align 8
  %v4213 = load i64, ptr %slot739, align 8
  %cmp4214 = icmp ne i64 %v4213, 0
  %cv4215 = zext i1 %cmp4214 to i32
  store i32 %cv4215, ptr %slot740, align 8
  %v4216 = load i32, ptr %slot740, align 8
  %cv4217 = zext i32 %v4216 to i64
  %cond4218 = icmp ne i64 %cv4217, 0
  br i1 %cond4218, label %bb_rcgspecial1099, label %bb_rcginc1099
bb_rcginc1099:
  %v4219 = load i64, ptr %slot735, align 8
  %op4220 = sub i64 %v4219, 32
  store i64 %op4220, ptr %slot741, align 8
  %v4221 = load i64, ptr %slot735, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  %rgep4223 = getelementptr i8, ptr %p4222, i64 -32
  %ld4224 = load i64, ptr %rgep4223, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4224, ptr %slot742, align 8
  %v4225 = load i64, ptr %slot742, align 8
  %op4226 = add i64 %v4225, 1
  store i64 %op4226, ptr %slot743, align 8
  %v4227 = load i64, ptr %slot743, align 8
  %cmp4228 = icmp eq i64 %v4227, 0
  %cv4229 = zext i1 %cmp4228 to i32
  store i32 %cv4229, ptr %slot744, align 8
  %v4230 = load i32, ptr %slot744, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcglimit1099, label %bb_rcgcapacity1099
bb_rcglimit1099:
  %v4233 = load i64, ptr %slot1, align 8
  %p4234 = inttoptr i64 %v4233 to ptr
  %call4235 = call i32 @myl_qbe_rc_status(ptr %p4234, i32 2) nomerge, !dbg !136
  store i32 %call4235, ptr %slot745, align 8
  br label %bb_failure
bb_rcgcapacity1099:
  %v4236 = load i64, ptr %slot743, align 8
  %v4237 = load i64, ptr %slot735, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  %rgep4239 = getelementptr i8, ptr %p4238, i64 -32
  store i64 %v4236, ptr %rgep4239, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1099
bb_rcgspecial1099:
  %v4240 = load i64, ptr %slot738, align 8
  %op4241 = and i64 %v4240, 4611686018427387904
  store i64 %op4241, ptr %slot746, align 8
  %v4242 = load i64, ptr %slot746, align 8
  %cmp4243 = icmp ne i64 %v4242, 0
  %cv4244 = zext i1 %cmp4243 to i32
  store i32 %cv4244, ptr %slot747, align 8
  %v4245 = load i32, ptr %slot747, align 8
  %cv4246 = zext i32 %v4245 to i64
  %cond4247 = icmp ne i64 %cv4246, 0
  br i1 %cond4247, label %bb_rcgslow1099, label %bb_rcgplain1099
bb_rcgslow1099:
  %v4248 = load i64, ptr %slot34, align 8
  %v4249 = load i64, ptr %slot733, align 8
  %v4250 = load i64, ptr %slot711, align 8
  %v4251 = load i64, ptr %slot734, align 8
  %cv4252 = trunc i64 %v4251 to i32
  %call4253 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v4248, i64 %v4249, i64 %v4250, i32 %cv4252) nomerge, !dbg !136
  store i32 %call4253, ptr %slot748, align 8
  %v4254 = load i32, ptr %slot748, align 8
  %cv4255 = zext i32 %v4254 to i64
  %cond4256 = icmp ne i64 %cv4255, 0
  br i1 %cond4256, label %bb_rcsuccess1113, label %bb_rcfailure1113
bb_rcfailure1113:
  %v4257 = load i64, ptr %slot34, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  %call4259 = call i32 @myl_rc_take_failure(ptr %p4258) nomerge, !dbg !136
  store i32 %call4259, ptr %slot749, align 8
  %v4260 = load i64, ptr %slot1, align 8
  %p4261 = inttoptr i64 %v4260 to ptr
  %v4262 = load i32, ptr %slot749, align 8
  %call4263 = call i32 @myl_qbe_rc_status(ptr %p4261, i32 %v4262) nomerge, !dbg !136
  store i32 %call4263, ptr %slot750, align 8
  br label %bb_failure
bb_rcsuccess1113:
  br label %bb_rcgdone1099
bb_rcgplain1099:
  %v4264 = load i64, ptr %slot735, align 8
  %v4265 = load i64, ptr %slot733, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  store i64 %v4264, ptr %p4266, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1099
bb_rcgdone1099:
  %v4267 = load i64, ptr %slot14, align 8
  %p4268 = inttoptr i64 %v4267 to ptr
  store i32 2, ptr %p4268, align 4, !alias.scope !3, !noalias !4
  %v4269 = load i64, ptr %slot13, align 8
  %p4270 = inttoptr i64 %v4269 to ptr
  store i32 1, ptr %p4270, align 4, !alias.scope !3, !noalias !4
  %v4271 = load i64, ptr %slot11, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  %ld4273 = load i32, ptr %p4272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4273, ptr %slot751, align 8
  %v4274 = load i32, ptr %slot751, align 8
  %cv4275 = zext i32 %v4274 to i64
  %cond4276 = icmp ne i64 %cv4275, 0
  br i1 %cond4276, label %bb_rcslotdrop1120, label %bb_rcslotdone1120
bb_rcslotdrop1120:
  %v4277 = load i64, ptr %slot11, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  store i32 0, ptr %p4278, align 4, !alias.scope !3, !noalias !4
  %v4279 = load i64, ptr %slot15, align 8
  store i64 %v4279, ptr %slot752, align 8
  %v4280 = load i64, ptr %slot12, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  %ld4282 = load i32, ptr %p4281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4282, ptr %slot753, align 8
  %v4283 = load i32, ptr %slot753, align 8
  %op4284 = and i32 %v4283, 28
  store i32 %op4284, ptr %slot754, align 8
  %v4285 = load i32, ptr %slot754, align 8
  %cv4286 = zext i32 %v4285 to i64
  %cond4287 = icmp ne i64 %cv4286, 0
  br i1 %cond4287, label %bb_rcslotrole1120, label %bb_rcslotowner1120
bb_rcslotrole1120:
  %v4288 = load i64, ptr %slot34, align 8
  store i64 %v4288, ptr %slot755, align 8
  %v4289 = load i64, ptr %slot752, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  %ld4291 = load i64, ptr %p4290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4291, ptr %slot756, align 8
  %v4292 = load i64, ptr %slot756, align 8
  %cmp4293 = icmp ne i64 %v4292, 0
  %cv4294 = zext i1 %cmp4293 to i32
  store i32 %cv4294, ptr %slot757, align 8
  %v4295 = load i32, ptr %slot757, align 8
  %cv4296 = zext i32 %v4295 to i64
  %cond4297 = icmp ne i64 %cv4296, 0
  br i1 %cond4297, label %bb_rcgnn1136, label %bb_rcgdone1136
bb_rcgnn1136:
  %v4298 = load i64, ptr %slot756, align 8
  %op4299 = sub i64 %v4298, 16
  store i64 %op4299, ptr %slot758, align 8
  %v4300 = load i64, ptr %slot756, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  %rgep4302 = getelementptr i8, ptr %p4301, i64 -16
  %ld4303 = load i64, ptr %rgep4302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4303, ptr %slot759, align 8
  %v4304 = load i64, ptr %slot759, align 8
  %op4305 = and i64 %v4304, 4611686018427387906
  store i64 %op4305, ptr %slot760, align 8
  %v4306 = load i64, ptr %slot760, align 8
  %cmp4307 = icmp ne i64 %v4306, 0
  %cv4308 = zext i1 %cmp4307 to i32
  store i32 %cv4308, ptr %slot761, align 8
  %v4309 = load i32, ptr %slot761, align 8
  %cv4310 = zext i32 %v4309 to i64
  %cond4311 = icmp ne i64 %cv4310, 0
  br i1 %cond4311, label %bb_rcgclear1136, label %bb_rcgcounted1136
bb_rcgcounted1136:
  %v4312 = load i64, ptr %slot756, align 8
  %op4313 = sub i64 %v4312, 24
  store i64 %op4313, ptr %slot762, align 8
  %v4314 = load i64, ptr %slot756, align 8
  %p4315 = inttoptr i64 %v4314 to ptr
  %rgep4316 = getelementptr i8, ptr %p4315, i64 -24
  %ld4317 = load i64, ptr %rgep4316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4317, ptr %slot763, align 8
  %v4318 = load i64, ptr %slot763, align 8
  %op4319 = sub i64 %v4318, 1
  store i64 %op4319, ptr %slot764, align 8
  %v4320 = load i64, ptr %slot764, align 8
  %cmp4321 = icmp eq i64 %v4320, 0
  %cv4322 = zext i1 %cmp4321 to i32
  store i32 %cv4322, ptr %slot765, align 8
  %v4323 = load i32, ptr %slot765, align 8
  %cv4324 = zext i32 %v4323 to i64
  %cond4325 = icmp ne i64 %cv4324, 0
  br i1 %cond4325, label %bb_rcglast1136, label %bb_rcgdec1136
bb_rcglast1136:
  %v4326 = load i64, ptr %slot756, align 8
  %op4327 = sub i64 %v4326, 32
  store i64 %op4327, ptr %slot766, align 8
  %v4328 = load i64, ptr %slot756, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %rgep4330 = getelementptr i8, ptr %p4329, i64 -32
  %ld4331 = load i64, ptr %rgep4330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4331, ptr %slot767, align 8
  %v4332 = load i64, ptr %slot767, align 8
  %cmp4333 = icmp ne i64 %v4332, 0
  %cv4334 = zext i1 %cmp4333 to i32
  store i32 %cv4334, ptr %slot768, align 8
  %v4335 = load i32, ptr %slot768, align 8
  %cv4336 = zext i32 %v4335 to i64
  %cond4337 = icmp ne i64 %cv4336, 0
  br i1 %cond4337, label %bb_rcgdec1136, label %bb_rcgslow1136
bb_rcgslow1136:
  %v4338 = load i64, ptr %slot755, align 8
  %v4339 = load i64, ptr %slot752, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4338, i64 %v4339) nomerge, !dbg !136
  br label %bb_rcgdone1136
bb_rcgdec1136:
  %v4340 = load i64, ptr %slot764, align 8
  %v4341 = load i64, ptr %slot756, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  %rgep4343 = getelementptr i8, ptr %p4342, i64 -24
  store i64 %v4340, ptr %rgep4343, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1136
bb_rcgclear1136:
  %v4344 = load i64, ptr %slot752, align 8
  %p4345 = inttoptr i64 %v4344 to ptr
  store i64 0, ptr %p4345, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1136
bb_rcgdone1136:
  br label %bb_rcslotdone1120
bb_rcslotowner1120:
  %v4346 = load i64, ptr %slot34, align 8
  store i64 %v4346, ptr %slot769, align 8
  %v4347 = load i64, ptr %slot752, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  %ld4349 = load i64, ptr %p4348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4349, ptr %slot770, align 8
  %v4350 = load i64, ptr %slot770, align 8
  %cmp4351 = icmp ne i64 %v4350, 0
  %cv4352 = zext i1 %cmp4351 to i32
  store i32 %cv4352, ptr %slot771, align 8
  %v4353 = load i32, ptr %slot771, align 8
  %cv4354 = zext i32 %v4353 to i64
  %cond4355 = icmp ne i64 %cv4354, 0
  br i1 %cond4355, label %bb_rcgnn1151, label %bb_rcgdone1151
bb_rcgnn1151:
  %v4356 = load i64, ptr %slot770, align 8
  %op4357 = sub i64 %v4356, 16
  store i64 %op4357, ptr %slot772, align 8
  %v4358 = load i64, ptr %slot770, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  %rgep4360 = getelementptr i8, ptr %p4359, i64 -16
  %ld4361 = load i64, ptr %rgep4360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4361, ptr %slot773, align 8
  %v4362 = load i64, ptr %slot773, align 8
  %op4363 = and i64 %v4362, 4611686018427387906
  store i64 %op4363, ptr %slot774, align 8
  %v4364 = load i64, ptr %slot774, align 8
  %cmp4365 = icmp ne i64 %v4364, 0
  %cv4366 = zext i1 %cmp4365 to i32
  store i32 %cv4366, ptr %slot775, align 8
  %v4367 = load i32, ptr %slot775, align 8
  %cv4368 = zext i32 %v4367 to i64
  %cond4369 = icmp ne i64 %cv4368, 0
  br i1 %cond4369, label %bb_rcgclear1151, label %bb_rcgcounted1151
bb_rcgcounted1151:
  %v4370 = load i64, ptr %slot770, align 8
  %op4371 = sub i64 %v4370, 32
  store i64 %op4371, ptr %slot776, align 8
  %v4372 = load i64, ptr %slot770, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  %rgep4374 = getelementptr i8, ptr %p4373, i64 -32
  %ld4375 = load i64, ptr %rgep4374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4375, ptr %slot777, align 8
  %v4376 = load i64, ptr %slot777, align 8
  %op4377 = sub i64 %v4376, 1
  store i64 %op4377, ptr %slot778, align 8
  %v4378 = load i64, ptr %slot778, align 8
  %cmp4379 = icmp eq i64 %v4378, 0
  %cv4380 = zext i1 %cmp4379 to i32
  store i32 %cv4380, ptr %slot779, align 8
  %v4381 = load i32, ptr %slot779, align 8
  %cv4382 = zext i32 %v4381 to i64
  %cond4383 = icmp ne i64 %cv4382, 0
  br i1 %cond4383, label %bb_rcglast1151, label %bb_rcgdec1151
bb_rcglast1151:
  %v4384 = load i64, ptr %slot770, align 8
  %op4385 = sub i64 %v4384, 24
  store i64 %op4385, ptr %slot780, align 8
  %v4386 = load i64, ptr %slot770, align 8
  %p4387 = inttoptr i64 %v4386 to ptr
  %rgep4388 = getelementptr i8, ptr %p4387, i64 -24
  %ld4389 = load i64, ptr %rgep4388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4389, ptr %slot781, align 8
  %v4390 = load i64, ptr %slot781, align 8
  %cmp4391 = icmp ne i64 %v4390, 0
  %cv4392 = zext i1 %cmp4391 to i32
  store i32 %cv4392, ptr %slot782, align 8
  %v4393 = load i32, ptr %slot782, align 8
  %cv4394 = zext i32 %v4393 to i64
  %cond4395 = icmp ne i64 %cv4394, 0
  br i1 %cond4395, label %bb_rcgdec1151, label %bb_rcgslow1151
bb_rcgslow1151:
  %v4396 = load i64, ptr %slot769, align 8
  %v4397 = load i64, ptr %slot752, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4396, i64 %v4397) nomerge, !dbg !136
  br label %bb_rcgdone1151
bb_rcgdec1151:
  %v4398 = load i64, ptr %slot778, align 8
  %v4399 = load i64, ptr %slot770, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  %rgep4401 = getelementptr i8, ptr %p4400, i64 -32
  store i64 %v4398, ptr %rgep4401, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1151
bb_rcgclear1151:
  %v4402 = load i64, ptr %slot752, align 8
  %p4403 = inttoptr i64 %v4402 to ptr
  store i64 0, ptr %p4403, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1151
bb_rcgdone1151:
  br label %bb_rcslotdone1120
bb_rcslotdone1120:
  br label %bb_rcprepared1066
bb_rcprepared1066:
  %v4404 = load i64, ptr %slot9, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  %ld4406 = load i32, ptr %p4405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4406, ptr %slot783, align 8
  %v4407 = load i32, ptr %slot783, align 8
  %cv4408 = zext i32 %v4407 to i64
  %cond4409 = icmp ne i64 %cv4408, 0
  br i1 %cond4409, label %bb_rcslotdrop1158, label %bb_rcslotdone1158
bb_rcslotdrop1158:
  %v4410 = load i64, ptr %slot9, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  store i32 0, ptr %p4411, align 4, !alias.scope !3, !noalias !4
  %v4412 = load i64, ptr %slot29, align 8
  store i64 %v4412, ptr %slot784, align 8
  %v4413 = load i64, ptr %slot10, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  %ld4415 = load i32, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4415, ptr %slot785, align 8
  %v4416 = load i32, ptr %slot785, align 8
  %op4417 = and i32 %v4416, 28
  store i32 %op4417, ptr %slot786, align 8
  %v4418 = load i32, ptr %slot786, align 8
  %cv4419 = zext i32 %v4418 to i64
  %cond4420 = icmp ne i64 %cv4419, 0
  br i1 %cond4420, label %bb_rcslotrole1158, label %bb_rcslotowner1158
bb_rcslotrole1158:
  %v4421 = load i64, ptr %slot34, align 8
  store i64 %v4421, ptr %slot787, align 8
  %v4422 = load i64, ptr %slot784, align 8
  %p4423 = inttoptr i64 %v4422 to ptr
  %ld4424 = load i64, ptr %p4423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4424, ptr %slot788, align 8
  %v4425 = load i64, ptr %slot788, align 8
  %cmp4426 = icmp ne i64 %v4425, 0
  %cv4427 = zext i1 %cmp4426 to i32
  store i32 %cv4427, ptr %slot789, align 8
  %v4428 = load i32, ptr %slot789, align 8
  %cv4429 = zext i32 %v4428 to i64
  %cond4430 = icmp ne i64 %cv4429, 0
  br i1 %cond4430, label %bb_rcgnn1174, label %bb_rcgdone1174
bb_rcgnn1174:
  %v4431 = load i64, ptr %slot788, align 8
  %op4432 = sub i64 %v4431, 16
  store i64 %op4432, ptr %slot790, align 8
  %v4433 = load i64, ptr %slot788, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %rgep4435 = getelementptr i8, ptr %p4434, i64 -16
  %ld4436 = load i64, ptr %rgep4435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4436, ptr %slot791, align 8
  %v4437 = load i64, ptr %slot791, align 8
  %op4438 = and i64 %v4437, 4611686018427387906
  store i64 %op4438, ptr %slot792, align 8
  %v4439 = load i64, ptr %slot792, align 8
  %cmp4440 = icmp ne i64 %v4439, 0
  %cv4441 = zext i1 %cmp4440 to i32
  store i32 %cv4441, ptr %slot793, align 8
  %v4442 = load i32, ptr %slot793, align 8
  %cv4443 = zext i32 %v4442 to i64
  %cond4444 = icmp ne i64 %cv4443, 0
  br i1 %cond4444, label %bb_rcgclear1174, label %bb_rcgcounted1174
bb_rcgcounted1174:
  %v4445 = load i64, ptr %slot788, align 8
  %op4446 = sub i64 %v4445, 24
  store i64 %op4446, ptr %slot794, align 8
  %v4447 = load i64, ptr %slot788, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  %rgep4449 = getelementptr i8, ptr %p4448, i64 -24
  %ld4450 = load i64, ptr %rgep4449, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4450, ptr %slot795, align 8
  %v4451 = load i64, ptr %slot795, align 8
  %op4452 = sub i64 %v4451, 1
  store i64 %op4452, ptr %slot796, align 8
  %v4453 = load i64, ptr %slot796, align 8
  %cmp4454 = icmp eq i64 %v4453, 0
  %cv4455 = zext i1 %cmp4454 to i32
  store i32 %cv4455, ptr %slot797, align 8
  %v4456 = load i32, ptr %slot797, align 8
  %cv4457 = zext i32 %v4456 to i64
  %cond4458 = icmp ne i64 %cv4457, 0
  br i1 %cond4458, label %bb_rcglast1174, label %bb_rcgdec1174
bb_rcglast1174:
  %v4459 = load i64, ptr %slot788, align 8
  %op4460 = sub i64 %v4459, 32
  store i64 %op4460, ptr %slot798, align 8
  %v4461 = load i64, ptr %slot788, align 8
  %p4462 = inttoptr i64 %v4461 to ptr
  %rgep4463 = getelementptr i8, ptr %p4462, i64 -32
  %ld4464 = load i64, ptr %rgep4463, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4464, ptr %slot799, align 8
  %v4465 = load i64, ptr %slot799, align 8
  %cmp4466 = icmp ne i64 %v4465, 0
  %cv4467 = zext i1 %cmp4466 to i32
  store i32 %cv4467, ptr %slot800, align 8
  %v4468 = load i32, ptr %slot800, align 8
  %cv4469 = zext i32 %v4468 to i64
  %cond4470 = icmp ne i64 %cv4469, 0
  br i1 %cond4470, label %bb_rcgdec1174, label %bb_rcgslow1174
bb_rcgslow1174:
  %v4471 = load i64, ptr %slot787, align 8
  %v4472 = load i64, ptr %slot784, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v4471, i64 %v4472) nomerge, !dbg !136
  br label %bb_rcgdone1174
bb_rcgdec1174:
  %v4473 = load i64, ptr %slot796, align 8
  %v4474 = load i64, ptr %slot788, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  %rgep4476 = getelementptr i8, ptr %p4475, i64 -24
  store i64 %v4473, ptr %rgep4476, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1174
bb_rcgclear1174:
  %v4477 = load i64, ptr %slot784, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  store i64 0, ptr %p4478, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1174
bb_rcgdone1174:
  br label %bb_rcslotdone1158
bb_rcslotowner1158:
  %v4479 = load i64, ptr %slot34, align 8
  store i64 %v4479, ptr %slot801, align 8
  %v4480 = load i64, ptr %slot784, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  %ld4482 = load i64, ptr %p4481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4482, ptr %slot802, align 8
  %v4483 = load i64, ptr %slot802, align 8
  %cmp4484 = icmp ne i64 %v4483, 0
  %cv4485 = zext i1 %cmp4484 to i32
  store i32 %cv4485, ptr %slot803, align 8
  %v4486 = load i32, ptr %slot803, align 8
  %cv4487 = zext i32 %v4486 to i64
  %cond4488 = icmp ne i64 %cv4487, 0
  br i1 %cond4488, label %bb_rcgnn1189, label %bb_rcgdone1189
bb_rcgnn1189:
  %v4489 = load i64, ptr %slot802, align 8
  %op4490 = sub i64 %v4489, 16
  store i64 %op4490, ptr %slot804, align 8
  %v4491 = load i64, ptr %slot802, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %rgep4493 = getelementptr i8, ptr %p4492, i64 -16
  %ld4494 = load i64, ptr %rgep4493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4494, ptr %slot805, align 8
  %v4495 = load i64, ptr %slot805, align 8
  %op4496 = and i64 %v4495, 4611686018427387906
  store i64 %op4496, ptr %slot806, align 8
  %v4497 = load i64, ptr %slot806, align 8
  %cmp4498 = icmp ne i64 %v4497, 0
  %cv4499 = zext i1 %cmp4498 to i32
  store i32 %cv4499, ptr %slot807, align 8
  %v4500 = load i32, ptr %slot807, align 8
  %cv4501 = zext i32 %v4500 to i64
  %cond4502 = icmp ne i64 %cv4501, 0
  br i1 %cond4502, label %bb_rcgclear1189, label %bb_rcgcounted1189
bb_rcgcounted1189:
  %v4503 = load i64, ptr %slot802, align 8
  %op4504 = sub i64 %v4503, 32
  store i64 %op4504, ptr %slot808, align 8
  %v4505 = load i64, ptr %slot802, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  %rgep4507 = getelementptr i8, ptr %p4506, i64 -32
  %ld4508 = load i64, ptr %rgep4507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4508, ptr %slot809, align 8
  %v4509 = load i64, ptr %slot809, align 8
  %op4510 = sub i64 %v4509, 1
  store i64 %op4510, ptr %slot810, align 8
  %v4511 = load i64, ptr %slot810, align 8
  %cmp4512 = icmp eq i64 %v4511, 0
  %cv4513 = zext i1 %cmp4512 to i32
  store i32 %cv4513, ptr %slot811, align 8
  %v4514 = load i32, ptr %slot811, align 8
  %cv4515 = zext i32 %v4514 to i64
  %cond4516 = icmp ne i64 %cv4515, 0
  br i1 %cond4516, label %bb_rcglast1189, label %bb_rcgdec1189
bb_rcglast1189:
  %v4517 = load i64, ptr %slot802, align 8
  %op4518 = sub i64 %v4517, 24
  store i64 %op4518, ptr %slot812, align 8
  %v4519 = load i64, ptr %slot802, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  %rgep4521 = getelementptr i8, ptr %p4520, i64 -24
  %ld4522 = load i64, ptr %rgep4521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4522, ptr %slot813, align 8
  %v4523 = load i64, ptr %slot813, align 8
  %cmp4524 = icmp ne i64 %v4523, 0
  %cv4525 = zext i1 %cmp4524 to i32
  store i32 %cv4525, ptr %slot814, align 8
  %v4526 = load i32, ptr %slot814, align 8
  %cv4527 = zext i32 %v4526 to i64
  %cond4528 = icmp ne i64 %cv4527, 0
  br i1 %cond4528, label %bb_rcgdec1189, label %bb_rcgslow1189
bb_rcgslow1189:
  %v4529 = load i64, ptr %slot801, align 8
  %v4530 = load i64, ptr %slot784, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v4529, i64 %v4530) nomerge, !dbg !136
  br label %bb_rcgdone1189
bb_rcgdec1189:
  %v4531 = load i64, ptr %slot810, align 8
  %v4532 = load i64, ptr %slot802, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  %rgep4534 = getelementptr i8, ptr %p4533, i64 -32
  store i64 %v4531, ptr %rgep4534, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1189
bb_rcgclear1189:
  %v4535 = load i64, ptr %slot784, align 8
  %p4536 = inttoptr i64 %v4535 to ptr
  store i64 0, ptr %p4536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1189
bb_rcgdone1189:
  br label %bb_rcslotdone1158
bb_rcslotdone1158:
  %v4537 = load i64, ptr %slot29, align 8
  store i64 %v4537, ptr %slot815, align 8
  %v4538 = load i64, ptr %slot17, align 8
  store i64 %v4538, ptr %slot816, align 8
  %v4539 = load i64, ptr %slot816, align 8
  %v4540 = load i64, ptr %slot815, align 8
  %p4541 = inttoptr i64 %v4539 to ptr
  %p4542 = inttoptr i64 %v4540 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4542, ptr %p4541, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4543 = load i64, ptr %slot13, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  store i32 0, ptr %p4544, align 4, !alias.scope !3, !noalias !4
  %v4545 = load i64, ptr %slot10, align 8
  %p4546 = inttoptr i64 %v4545 to ptr
  store i32 2, ptr %p4546, align 4, !alias.scope !3, !noalias !4
  %v4547 = load i64, ptr %slot14, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  %ld4549 = load i32, ptr %p4548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4549, ptr %slot817, align 8
  %v4550 = load i32, ptr %slot817, align 8
  %v4551 = load i64, ptr %slot10, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  store i32 %v4550, ptr %p4552, align 4, !alias.scope !3, !noalias !4
  %v4553 = load i64, ptr %slot9, align 8
  %p4554 = inttoptr i64 %v4553 to ptr
  store i32 1, ptr %p4554, align 4, !alias.scope !3, !noalias !4
  %v4555 = load i64, ptr %slot7, align 8
  %p4556 = inttoptr i64 %v4555 to ptr
  %ld4557 = load i32, ptr %p4556, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4557, ptr %slot818, align 8
  %v4558 = load i32, ptr %slot818, align 8
  %cv4559 = zext i32 %v4558 to i64
  %cond4560 = icmp ne i64 %cv4559, 0
  br i1 %cond4560, label %bb_rcslotdrop1202, label %bb_rcslotdone1202
bb_rcslotdrop1202:
  %v4561 = load i64, ptr %slot7, align 8
  %p4562 = inttoptr i64 %v4561 to ptr
  store i32 0, ptr %p4562, align 4, !alias.scope !3, !noalias !4
  %v4563 = load i64, ptr %slot28, align 8
  store i64 %v4563, ptr %slot819, align 8
  %v4564 = load i64, ptr %slot8, align 8
  %p4565 = inttoptr i64 %v4564 to ptr
  %ld4566 = load i32, ptr %p4565, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4566, ptr %slot820, align 8
  %v4567 = load i32, ptr %slot820, align 8
  %op4568 = and i32 %v4567, 28
  store i32 %op4568, ptr %slot821, align 8
  %v4569 = load i32, ptr %slot821, align 8
  %cv4570 = zext i32 %v4569 to i64
  %cond4571 = icmp ne i64 %cv4570, 0
  br i1 %cond4571, label %bb_rcslotrole1202, label %bb_rcslotowner1202
bb_rcslotrole1202:
  %v4572 = load i64, ptr %slot34, align 8
  store i64 %v4572, ptr %slot822, align 8
  %v4573 = load i64, ptr %slot819, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  %ld4575 = load i64, ptr %p4574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4575, ptr %slot823, align 8
  %v4576 = load i64, ptr %slot823, align 8
  %cmp4577 = icmp ne i64 %v4576, 0
  %cv4578 = zext i1 %cmp4577 to i32
  store i32 %cv4578, ptr %slot824, align 8
  %v4579 = load i32, ptr %slot824, align 8
  %cv4580 = zext i32 %v4579 to i64
  %cond4581 = icmp ne i64 %cv4580, 0
  br i1 %cond4581, label %bb_rcgnn1218, label %bb_rcgdone1218
bb_rcgnn1218:
  %v4582 = load i64, ptr %slot823, align 8
  %op4583 = sub i64 %v4582, 16
  store i64 %op4583, ptr %slot825, align 8
  %v4584 = load i64, ptr %slot823, align 8
  %p4585 = inttoptr i64 %v4584 to ptr
  %rgep4586 = getelementptr i8, ptr %p4585, i64 -16
  %ld4587 = load i64, ptr %rgep4586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4587, ptr %slot826, align 8
  %v4588 = load i64, ptr %slot826, align 8
  %op4589 = and i64 %v4588, 4611686018427387906
  store i64 %op4589, ptr %slot827, align 8
  %v4590 = load i64, ptr %slot827, align 8
  %cmp4591 = icmp ne i64 %v4590, 0
  %cv4592 = zext i1 %cmp4591 to i32
  store i32 %cv4592, ptr %slot828, align 8
  %v4593 = load i32, ptr %slot828, align 8
  %cv4594 = zext i32 %v4593 to i64
  %cond4595 = icmp ne i64 %cv4594, 0
  br i1 %cond4595, label %bb_rcgclear1218, label %bb_rcgcounted1218
bb_rcgcounted1218:
  %v4596 = load i64, ptr %slot823, align 8
  %op4597 = sub i64 %v4596, 24
  store i64 %op4597, ptr %slot829, align 8
  %v4598 = load i64, ptr %slot823, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %rgep4600 = getelementptr i8, ptr %p4599, i64 -24
  %ld4601 = load i64, ptr %rgep4600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4601, ptr %slot830, align 8
  %v4602 = load i64, ptr %slot830, align 8
  %op4603 = sub i64 %v4602, 1
  store i64 %op4603, ptr %slot831, align 8
  %v4604 = load i64, ptr %slot831, align 8
  %cmp4605 = icmp eq i64 %v4604, 0
  %cv4606 = zext i1 %cmp4605 to i32
  store i32 %cv4606, ptr %slot832, align 8
  %v4607 = load i32, ptr %slot832, align 8
  %cv4608 = zext i32 %v4607 to i64
  %cond4609 = icmp ne i64 %cv4608, 0
  br i1 %cond4609, label %bb_rcglast1218, label %bb_rcgdec1218
bb_rcglast1218:
  %v4610 = load i64, ptr %slot823, align 8
  %op4611 = sub i64 %v4610, 32
  store i64 %op4611, ptr %slot833, align 8
  %v4612 = load i64, ptr %slot823, align 8
  %p4613 = inttoptr i64 %v4612 to ptr
  %rgep4614 = getelementptr i8, ptr %p4613, i64 -32
  %ld4615 = load i64, ptr %rgep4614, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4615, ptr %slot834, align 8
  %v4616 = load i64, ptr %slot834, align 8
  %cmp4617 = icmp ne i64 %v4616, 0
  %cv4618 = zext i1 %cmp4617 to i32
  store i32 %cv4618, ptr %slot835, align 8
  %v4619 = load i32, ptr %slot835, align 8
  %cv4620 = zext i32 %v4619 to i64
  %cond4621 = icmp ne i64 %cv4620, 0
  br i1 %cond4621, label %bb_rcgdec1218, label %bb_rcgslow1218
bb_rcgslow1218:
  %v4622 = load i64, ptr %slot822, align 8
  %v4623 = load i64, ptr %slot819, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4622, i64 %v4623) nomerge, !dbg !136
  br label %bb_rcgdone1218
bb_rcgdec1218:
  %v4624 = load i64, ptr %slot831, align 8
  %v4625 = load i64, ptr %slot823, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %rgep4627 = getelementptr i8, ptr %p4626, i64 -24
  store i64 %v4624, ptr %rgep4627, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1218
bb_rcgclear1218:
  %v4628 = load i64, ptr %slot819, align 8
  %p4629 = inttoptr i64 %v4628 to ptr
  store i64 0, ptr %p4629, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1218
bb_rcgdone1218:
  br label %bb_rcslotdone1202
bb_rcslotowner1202:
  %v4630 = load i64, ptr %slot34, align 8
  store i64 %v4630, ptr %slot836, align 8
  %v4631 = load i64, ptr %slot819, align 8
  %p4632 = inttoptr i64 %v4631 to ptr
  %ld4633 = load i64, ptr %p4632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4633, ptr %slot837, align 8
  %v4634 = load i64, ptr %slot837, align 8
  %cmp4635 = icmp ne i64 %v4634, 0
  %cv4636 = zext i1 %cmp4635 to i32
  store i32 %cv4636, ptr %slot838, align 8
  %v4637 = load i32, ptr %slot838, align 8
  %cv4638 = zext i32 %v4637 to i64
  %cond4639 = icmp ne i64 %cv4638, 0
  br i1 %cond4639, label %bb_rcgnn1233, label %bb_rcgdone1233
bb_rcgnn1233:
  %v4640 = load i64, ptr %slot837, align 8
  %op4641 = sub i64 %v4640, 16
  store i64 %op4641, ptr %slot839, align 8
  %v4642 = load i64, ptr %slot837, align 8
  %p4643 = inttoptr i64 %v4642 to ptr
  %rgep4644 = getelementptr i8, ptr %p4643, i64 -16
  %ld4645 = load i64, ptr %rgep4644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4645, ptr %slot840, align 8
  %v4646 = load i64, ptr %slot840, align 8
  %op4647 = and i64 %v4646, 4611686018427387906
  store i64 %op4647, ptr %slot841, align 8
  %v4648 = load i64, ptr %slot841, align 8
  %cmp4649 = icmp ne i64 %v4648, 0
  %cv4650 = zext i1 %cmp4649 to i32
  store i32 %cv4650, ptr %slot842, align 8
  %v4651 = load i32, ptr %slot842, align 8
  %cv4652 = zext i32 %v4651 to i64
  %cond4653 = icmp ne i64 %cv4652, 0
  br i1 %cond4653, label %bb_rcgclear1233, label %bb_rcgcounted1233
bb_rcgcounted1233:
  %v4654 = load i64, ptr %slot837, align 8
  %op4655 = sub i64 %v4654, 32
  store i64 %op4655, ptr %slot843, align 8
  %v4656 = load i64, ptr %slot837, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %rgep4658 = getelementptr i8, ptr %p4657, i64 -32
  %ld4659 = load i64, ptr %rgep4658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4659, ptr %slot844, align 8
  %v4660 = load i64, ptr %slot844, align 8
  %op4661 = sub i64 %v4660, 1
  store i64 %op4661, ptr %slot845, align 8
  %v4662 = load i64, ptr %slot845, align 8
  %cmp4663 = icmp eq i64 %v4662, 0
  %cv4664 = zext i1 %cmp4663 to i32
  store i32 %cv4664, ptr %slot846, align 8
  %v4665 = load i32, ptr %slot846, align 8
  %cv4666 = zext i32 %v4665 to i64
  %cond4667 = icmp ne i64 %cv4666, 0
  br i1 %cond4667, label %bb_rcglast1233, label %bb_rcgdec1233
bb_rcglast1233:
  %v4668 = load i64, ptr %slot837, align 8
  %op4669 = sub i64 %v4668, 24
  store i64 %op4669, ptr %slot847, align 8
  %v4670 = load i64, ptr %slot837, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  %rgep4672 = getelementptr i8, ptr %p4671, i64 -24
  %ld4673 = load i64, ptr %rgep4672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4673, ptr %slot848, align 8
  %v4674 = load i64, ptr %slot848, align 8
  %cmp4675 = icmp ne i64 %v4674, 0
  %cv4676 = zext i1 %cmp4675 to i32
  store i32 %cv4676, ptr %slot849, align 8
  %v4677 = load i32, ptr %slot849, align 8
  %cv4678 = zext i32 %v4677 to i64
  %cond4679 = icmp ne i64 %cv4678, 0
  br i1 %cond4679, label %bb_rcgdec1233, label %bb_rcgslow1233
bb_rcgslow1233:
  %v4680 = load i64, ptr %slot836, align 8
  %v4681 = load i64, ptr %slot819, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4680, i64 %v4681) nomerge, !dbg !136
  br label %bb_rcgdone1233
bb_rcgdec1233:
  %v4682 = load i64, ptr %slot845, align 8
  %v4683 = load i64, ptr %slot837, align 8
  %p4684 = inttoptr i64 %v4683 to ptr
  %rgep4685 = getelementptr i8, ptr %p4684, i64 -32
  store i64 %v4682, ptr %rgep4685, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1233
bb_rcgclear1233:
  %v4686 = load i64, ptr %slot819, align 8
  %p4687 = inttoptr i64 %v4686 to ptr
  store i64 0, ptr %p4687, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1233
bb_rcgdone1233:
  br label %bb_rcslotdone1202
bb_rcslotdone1202:
  %v4688 = load i64, ptr %slot24, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  %ld4690 = load i64, ptr %p4689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4690, ptr %slot850, align 8
  %v4691 = load i64, ptr %slot850, align 8
  %v4692 = load i64, ptr %slot31, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  store i64 %v4691, ptr %p4693, align 8, !alias.scope !3, !noalias !4
  %v4694 = load i64, ptr %slot32, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  store i64 0, ptr %p4695, align 8, !alias.scope !3, !noalias !4
  %v4696 = load i64, ptr %slot24, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %ld4698 = load i64, ptr %p4697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4698, ptr %slot851, align 8
  %v4699 = load i64, ptr %slot851, align 8
  %v4700 = load i64, ptr %slot33, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  store i64 %v4699, ptr %p4701, align 8, !alias.scope !3, !noalias !4
  %v4702 = load i64, ptr %slot33, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  %ld4704 = load i64, ptr %p4703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4704, ptr %slot852, align 8
  %v4705 = load i64, ptr %slot852, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  %ld4707 = load i64, ptr %p4706, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4707, ptr %slot853, align 8
  %v4708 = load i64, ptr %slot853, align 8
  %v4709 = load i64, ptr %slot33, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  store i64 %v4708, ptr %p4710, align 8, !alias.scope !3, !noalias !4
  %v4711 = load i64, ptr %slot29, align 8
  store i64 %v4711, ptr %slot854, align 8
  %v4712 = load i64, ptr %slot10, align 8
  %p4713 = inttoptr i64 %v4712 to ptr
  store i32 2, ptr %p4713, align 4, !alias.scope !3, !noalias !4
  %v4714 = load i64, ptr %slot854, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  %ld4716 = load i64, ptr %p4715, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4716, ptr %slot855, align 8
  %v4717 = load i64, ptr %slot855, align 8
  %cmp4718 = icmp ne i64 %v4717, 0
  %cv4719 = zext i1 %cmp4718 to i32
  store i32 %cv4719, ptr %slot856, align 8
  %v4720 = load i32, ptr %slot856, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcguniquenn1281, label %bb_rcgunique1281
bb_rcguniquenn1281:
  %v4723 = load i64, ptr %slot855, align 8
  %op4724 = sub i64 %v4723, 16
  store i64 %op4724, ptr %slot857, align 8
  %v4725 = load i64, ptr %slot855, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %rgep4727 = getelementptr i8, ptr %p4726, i64 -16
  %ld4728 = load i64, ptr %rgep4727, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4728, ptr %slot858, align 8
  %v4729 = load i64, ptr %slot858, align 8
  %op4730 = and i64 %v4729, 6917529027641081858
  store i64 %op4730, ptr %slot859, align 8
  %v4731 = load i64, ptr %slot859, align 8
  %cmp4732 = icmp ne i64 %v4731, 0
  %cv4733 = zext i1 %cmp4732 to i32
  store i32 %cv4733, ptr %slot860, align 8
  %v4734 = load i32, ptr %slot860, align 8
  %cv4735 = zext i32 %v4734 to i64
  %cond4736 = icmp ne i64 %cv4735, 0
  br i1 %cond4736, label %bb_rcguniqueslow1281, label %bb_rcguniquecount1281
bb_rcguniquecount1281:
  %v4737 = load i64, ptr %slot855, align 8
  %op4738 = sub i64 %v4737, 32
  store i64 %op4738, ptr %slot861, align 8
  %v4739 = load i64, ptr %slot855, align 8
  %p4740 = inttoptr i64 %v4739 to ptr
  %rgep4741 = getelementptr i8, ptr %p4740, i64 -32
  %ld4742 = load i64, ptr %rgep4741, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4742, ptr %slot862, align 8
  %v4743 = load i64, ptr %slot862, align 8
  %cmp4744 = icmp ult i64 %v4743, 2
  %cv4745 = zext i1 %cmp4744 to i32
  store i32 %cv4745, ptr %slot863, align 8
  %v4746 = load i32, ptr %slot863, align 8
  %cv4747 = zext i32 %v4746 to i64
  %cond4748 = icmp ne i64 %cv4747, 0
  br i1 %cond4748, label %bb_rcgunique1281, label %bb_rcguniqueslow1281
bb_rcguniqueslow1281:
  %v4749 = load i64, ptr %slot1, align 8
  %p4750 = inttoptr i64 %v4749 to ptr
  %p4751 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v4752 = load i64, ptr %slot854, align 8
  %p4753 = inttoptr i64 %v4752 to ptr
  %v4754 = load i64, ptr %slot9, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  %call4756 = call i32 @myl_qbe_rc_unique_local(ptr %p4750, ptr %p4751, ptr %p4753, ptr %p4755) nomerge, !dbg !138
  store i32 %call4756, ptr %slot864, align 8
  %v4757 = load i32, ptr %slot864, align 8
  %cv4758 = zext i32 %v4757 to i64
  %cond4759 = icmp ne i64 %cv4758, 0
  br i1 %cond4759, label %bb_rcunique1292, label %bb_failure
bb_rcunique1292:
  br label %bb_rcgunique1281
bb_rcgunique1281:
  %v4760 = load i64, ptr %slot29, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %ld4762 = load i64, ptr %p4761, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4762, ptr %slot865, align 8
  %v4763 = load i64, ptr %slot31, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  %ld4765 = load i64, ptr %p4764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4765, ptr %slot866, align 8
  %v4766 = load i64, ptr %slot32, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  %ld4768 = load i64, ptr %p4767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4768, ptr %slot867, align 8
  %v4769 = load i64, ptr %slot33, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  %ld4771 = load i64, ptr %p4770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4771, ptr %slot868, align 8
  %v4772 = load i64, ptr %slot865, align 8
  %op4773 = add i64 %v4772, 8
  store i64 %op4773, ptr %slot869, align 8
  %v4774 = load i64, ptr %slot867, align 8
  %cmp4775 = icmp sge i64 %v4774, 0
  %cv4776 = zext i1 %cmp4775 to i64
  store i64 %cv4776, ptr %slot870, align 8
  %v4777 = load i64, ptr %slot870, align 8
  %cond4778 = icmp ne i64 %v4777, 0
  br i1 %cond4778, label %bb_buf_start1298, label %bb_buf_refused1298
bb_buf_start1298:
  %v4779 = load i64, ptr %slot867, align 8
  %v4780 = load i64, ptr %slot868, align 8
  %cmp4781 = icmp sle i64 %v4779, %v4780
  %cv4782 = zext i1 %cmp4781 to i64
  store i64 %cv4782, ptr %slot871, align 8
  %v4783 = load i64, ptr %slot871, align 8
  %cond4784 = icmp ne i64 %v4783, 0
  br i1 %cond4784, label %bb_buf_order1298, label %bb_buf_refused1298
bb_buf_order1298:
  %v4785 = load i64, ptr %slot866, align 8
  %p4786 = inttoptr i64 %v4785 to ptr
  %ld4787 = load i64, ptr %p4786, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4787, ptr %slot872, align 8
  %v4788 = load i64, ptr %slot868, align 8
  %v4789 = load i64, ptr %slot872, align 8
  %cmp4790 = icmp ule i64 %v4788, %v4789
  %cv4791 = zext i1 %cmp4790 to i64
  store i64 %cv4791, ptr %slot873, align 8
  %v4792 = load i64, ptr %slot873, align 8
  %cond4793 = icmp ne i64 %v4792, 0
  br i1 %cond4793, label %bb_buf_bound1298, label %bb_buf_refused1298
bb_buf_bound1298:
  %v4794 = load i64, ptr %slot865, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %ld4796 = load i64, ptr %p4795, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4796, ptr %slot874, align 8
  %v4797 = load i64, ptr %slot869, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %ld4799 = load i64, ptr %p4798, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4799, ptr %slot875, align 8
  %v4800 = load i64, ptr %slot868, align 8
  %v4801 = load i64, ptr %slot867, align 8
  %op4802 = sub i64 %v4800, %v4801
  store i64 %op4802, ptr %slot876, align 8
  %v4803 = load i64, ptr %slot875, align 8
  %v4804 = load i64, ptr %slot874, align 8
  %op4805 = sub i64 %v4803, %v4804
  store i64 %op4805, ptr %slot877, align 8
  %v4806 = load i64, ptr %slot876, align 8
  %v4807 = load i64, ptr %slot877, align 8
  %cmp4808 = icmp ult i64 %v4806, %v4807
  %cv4809 = zext i1 %cmp4808 to i64
  store i64 %cv4809, ptr %slot878, align 8
  %v4810 = load i64, ptr %slot878, align 8
  %cond4811 = icmp ne i64 %v4810, 0
  br i1 %cond4811, label %bb_buf_fast1298, label %bb_buf_slow1298
bb_buf_slow1298:
  %v4812 = load i64, ptr %slot34, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  %v4814 = load i64, ptr %slot865, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  %v4816 = load i64, ptr %slot866, align 8
  %p4817 = inttoptr i64 %v4816 to ptr
  %v4818 = load i64, ptr %slot867, align 8
  %v4819 = load i64, ptr %slot868, align 8
  %call4820 = call i32 @myl_native_bytes_buffer_append_range(ptr %p4813, ptr %p4815, ptr %p4817, i64 %v4818, i64 %v4819) nomerge, !dbg !138
  store i32 %call4820, ptr %slot879, align 8
  %v4821 = load i32, ptr %slot879, align 8
  %ext4822 = zext i32 %v4821 to i64
  store i64 %ext4822, ptr %slot880, align 8
  %v4823 = load i64, ptr %slot880, align 8
  %cmp4824 = icmp ne i64 %v4823, 0
  %cv4825 = zext i1 %cmp4824 to i64
  store i64 %cv4825, ptr %slot881, align 8
  %v4826 = load i64, ptr %slot881, align 8
  %cond4827 = icmp ne i64 %v4826, 0
  br i1 %cond4827, label %bb_success1312, label %bb_failed1312
bb_failed1312:
  %v4828 = load i64, ptr %slot1, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4829) nomerge, !dbg !138
  unreachable
bb_success1312:
  %v4830 = load i32, ptr %slot879, align 8
  %cmp4831 = icmp eq i32 %v4830, 1
  %cv4832 = zext i1 %cmp4831 to i32
  store i32 %cv4832, ptr %slot882, align 8
  %v4833 = load i32, ptr %slot882, align 8
  %ext4834 = zext i32 %v4833 to i64
  store i64 %ext4834, ptr %slot883, align 8
  %v4835 = load i64, ptr %slot883, align 8
  %v4836 = load i64, ptr %slot31, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  store i64 %v4835, ptr %p4837, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done1298
bb_buf_fast1298:
  %v4838 = load i64, ptr %slot865, align 8
  %op4839 = add i64 %v4838, 32
  store i64 %op4839, ptr %slot884, align 8
  %v4840 = load i64, ptr %slot866, align 8
  %op4841 = add i64 %v4840, 32
  store i64 %op4841, ptr %slot885, align 8
  %v4842 = load i64, ptr %slot884, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  %ld4844 = load i64, ptr %p4843, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4844, ptr %slot886, align 8
  %v4845 = load i64, ptr %slot886, align 8
  %v4846 = load i64, ptr %slot874, align 8
  %op4847 = add i64 %v4845, %v4846
  store i64 %op4847, ptr %slot887, align 8
  %v4848 = load i64, ptr %slot885, align 8
  %p4849 = inttoptr i64 %v4848 to ptr
  %ld4850 = load i64, ptr %p4849, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4850, ptr %slot888, align 8
  %v4851 = load i64, ptr %slot888, align 8
  %v4852 = load i64, ptr %slot867, align 8
  %op4853 = add i64 %v4851, %v4852
  store i64 %op4853, ptr %slot889, align 8
  %v4854 = load i64, ptr %slot887, align 8
  %p4855 = inttoptr i64 %v4854 to ptr
  %v4856 = load i64, ptr %slot889, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  %v4858 = load i64, ptr %slot876, align 8
  call void @myl_native_bytes_copy_octets(ptr %p4855, ptr %p4857, i64 %v4858) nomerge, !dbg !138
  %v4859 = load i64, ptr %slot874, align 8
  %v4860 = load i64, ptr %slot876, align 8
  %op4861 = add i64 %v4859, %v4860
  store i64 %op4861, ptr %slot890, align 8
  %v4862 = load i64, ptr %slot890, align 8
  %v4863 = load i64, ptr %slot865, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  store i64 %v4862, ptr %p4864, align 8, !alias.scope !6, !noalias !7
  %v4865 = load i64, ptr %slot31, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  store i64 1, ptr %p4866, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done1298
bb_buf_refused1298:
  %v4867 = load i64, ptr %slot31, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  store i64 0, ptr %p4868, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done1298
bb_buf_done1298:
  %v4869 = load i64, ptr %slot11, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i32, ptr %p4870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4871, ptr %slot891, align 8
  %v4872 = load i32, ptr %slot891, align 8
  %cv4873 = zext i32 %v4872 to i64
  %cond4874 = icmp ne i64 %cv4873, 0
  br i1 %cond4874, label %bb_rcslotdrop1324, label %bb_rcslotdone1324
bb_rcslotdrop1324:
  %v4875 = load i64, ptr %slot11, align 8
  %p4876 = inttoptr i64 %v4875 to ptr
  store i32 0, ptr %p4876, align 4, !alias.scope !3, !noalias !4
  %v4877 = load i64, ptr %slot15, align 8
  store i64 %v4877, ptr %slot892, align 8
  %v4878 = load i64, ptr %slot12, align 8
  %p4879 = inttoptr i64 %v4878 to ptr
  %ld4880 = load i32, ptr %p4879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4880, ptr %slot893, align 8
  %v4881 = load i32, ptr %slot893, align 8
  %op4882 = and i32 %v4881, 28
  store i32 %op4882, ptr %slot894, align 8
  %v4883 = load i32, ptr %slot894, align 8
  %cv4884 = zext i32 %v4883 to i64
  %cond4885 = icmp ne i64 %cv4884, 0
  br i1 %cond4885, label %bb_rcslotrole1324, label %bb_rcslotowner1324
bb_rcslotrole1324:
  %v4886 = load i64, ptr %slot34, align 8
  store i64 %v4886, ptr %slot895, align 8
  %v4887 = load i64, ptr %slot892, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %ld4889 = load i64, ptr %p4888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4889, ptr %slot896, align 8
  %v4890 = load i64, ptr %slot896, align 8
  %cmp4891 = icmp ne i64 %v4890, 0
  %cv4892 = zext i1 %cmp4891 to i32
  store i32 %cv4892, ptr %slot897, align 8
  %v4893 = load i32, ptr %slot897, align 8
  %cv4894 = zext i32 %v4893 to i64
  %cond4895 = icmp ne i64 %cv4894, 0
  br i1 %cond4895, label %bb_rcgnn1340, label %bb_rcgdone1340
bb_rcgnn1340:
  %v4896 = load i64, ptr %slot896, align 8
  %op4897 = sub i64 %v4896, 16
  store i64 %op4897, ptr %slot898, align 8
  %v4898 = load i64, ptr %slot896, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %rgep4900 = getelementptr i8, ptr %p4899, i64 -16
  %ld4901 = load i64, ptr %rgep4900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4901, ptr %slot899, align 8
  %v4902 = load i64, ptr %slot899, align 8
  %op4903 = and i64 %v4902, 4611686018427387906
  store i64 %op4903, ptr %slot900, align 8
  %v4904 = load i64, ptr %slot900, align 8
  %cmp4905 = icmp ne i64 %v4904, 0
  %cv4906 = zext i1 %cmp4905 to i32
  store i32 %cv4906, ptr %slot901, align 8
  %v4907 = load i32, ptr %slot901, align 8
  %cv4908 = zext i32 %v4907 to i64
  %cond4909 = icmp ne i64 %cv4908, 0
  br i1 %cond4909, label %bb_rcgclear1340, label %bb_rcgcounted1340
bb_rcgcounted1340:
  %v4910 = load i64, ptr %slot896, align 8
  %op4911 = sub i64 %v4910, 24
  store i64 %op4911, ptr %slot902, align 8
  %v4912 = load i64, ptr %slot896, align 8
  %p4913 = inttoptr i64 %v4912 to ptr
  %rgep4914 = getelementptr i8, ptr %p4913, i64 -24
  %ld4915 = load i64, ptr %rgep4914, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4915, ptr %slot903, align 8
  %v4916 = load i64, ptr %slot903, align 8
  %op4917 = sub i64 %v4916, 1
  store i64 %op4917, ptr %slot904, align 8
  %v4918 = load i64, ptr %slot904, align 8
  %cmp4919 = icmp eq i64 %v4918, 0
  %cv4920 = zext i1 %cmp4919 to i32
  store i32 %cv4920, ptr %slot905, align 8
  %v4921 = load i32, ptr %slot905, align 8
  %cv4922 = zext i32 %v4921 to i64
  %cond4923 = icmp ne i64 %cv4922, 0
  br i1 %cond4923, label %bb_rcglast1340, label %bb_rcgdec1340
bb_rcglast1340:
  %v4924 = load i64, ptr %slot896, align 8
  %op4925 = sub i64 %v4924, 32
  store i64 %op4925, ptr %slot906, align 8
  %v4926 = load i64, ptr %slot896, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  %rgep4928 = getelementptr i8, ptr %p4927, i64 -32
  %ld4929 = load i64, ptr %rgep4928, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4929, ptr %slot907, align 8
  %v4930 = load i64, ptr %slot907, align 8
  %cmp4931 = icmp ne i64 %v4930, 0
  %cv4932 = zext i1 %cmp4931 to i32
  store i32 %cv4932, ptr %slot908, align 8
  %v4933 = load i32, ptr %slot908, align 8
  %cv4934 = zext i32 %v4933 to i64
  %cond4935 = icmp ne i64 %cv4934, 0
  br i1 %cond4935, label %bb_rcgdec1340, label %bb_rcgslow1340
bb_rcgslow1340:
  %v4936 = load i64, ptr %slot895, align 8
  %v4937 = load i64, ptr %slot892, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4936, i64 %v4937) nomerge, !dbg !138
  br label %bb_rcgdone1340
bb_rcgdec1340:
  %v4938 = load i64, ptr %slot904, align 8
  %v4939 = load i64, ptr %slot896, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %rgep4941 = getelementptr i8, ptr %p4940, i64 -24
  store i64 %v4938, ptr %rgep4941, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1340
bb_rcgclear1340:
  %v4942 = load i64, ptr %slot892, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  store i64 0, ptr %p4943, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1340
bb_rcgdone1340:
  br label %bb_rcslotdone1324
bb_rcslotowner1324:
  %v4944 = load i64, ptr %slot34, align 8
  store i64 %v4944, ptr %slot909, align 8
  %v4945 = load i64, ptr %slot892, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  %ld4947 = load i64, ptr %p4946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4947, ptr %slot910, align 8
  %v4948 = load i64, ptr %slot910, align 8
  %cmp4949 = icmp ne i64 %v4948, 0
  %cv4950 = zext i1 %cmp4949 to i32
  store i32 %cv4950, ptr %slot911, align 8
  %v4951 = load i32, ptr %slot911, align 8
  %cv4952 = zext i32 %v4951 to i64
  %cond4953 = icmp ne i64 %cv4952, 0
  br i1 %cond4953, label %bb_rcgnn1355, label %bb_rcgdone1355
bb_rcgnn1355:
  %v4954 = load i64, ptr %slot910, align 8
  %op4955 = sub i64 %v4954, 16
  store i64 %op4955, ptr %slot912, align 8
  %v4956 = load i64, ptr %slot910, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %rgep4958 = getelementptr i8, ptr %p4957, i64 -16
  %ld4959 = load i64, ptr %rgep4958, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4959, ptr %slot913, align 8
  %v4960 = load i64, ptr %slot913, align 8
  %op4961 = and i64 %v4960, 4611686018427387906
  store i64 %op4961, ptr %slot914, align 8
  %v4962 = load i64, ptr %slot914, align 8
  %cmp4963 = icmp ne i64 %v4962, 0
  %cv4964 = zext i1 %cmp4963 to i32
  store i32 %cv4964, ptr %slot915, align 8
  %v4965 = load i32, ptr %slot915, align 8
  %cv4966 = zext i32 %v4965 to i64
  %cond4967 = icmp ne i64 %cv4966, 0
  br i1 %cond4967, label %bb_rcgclear1355, label %bb_rcgcounted1355
bb_rcgcounted1355:
  %v4968 = load i64, ptr %slot910, align 8
  %op4969 = sub i64 %v4968, 32
  store i64 %op4969, ptr %slot916, align 8
  %v4970 = load i64, ptr %slot910, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  %rgep4972 = getelementptr i8, ptr %p4971, i64 -32
  %ld4973 = load i64, ptr %rgep4972, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4973, ptr %slot917, align 8
  %v4974 = load i64, ptr %slot917, align 8
  %op4975 = sub i64 %v4974, 1
  store i64 %op4975, ptr %slot918, align 8
  %v4976 = load i64, ptr %slot918, align 8
  %cmp4977 = icmp eq i64 %v4976, 0
  %cv4978 = zext i1 %cmp4977 to i32
  store i32 %cv4978, ptr %slot919, align 8
  %v4979 = load i32, ptr %slot919, align 8
  %cv4980 = zext i32 %v4979 to i64
  %cond4981 = icmp ne i64 %cv4980, 0
  br i1 %cond4981, label %bb_rcglast1355, label %bb_rcgdec1355
bb_rcglast1355:
  %v4982 = load i64, ptr %slot910, align 8
  %op4983 = sub i64 %v4982, 24
  store i64 %op4983, ptr %slot920, align 8
  %v4984 = load i64, ptr %slot910, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  %rgep4986 = getelementptr i8, ptr %p4985, i64 -24
  %ld4987 = load i64, ptr %rgep4986, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4987, ptr %slot921, align 8
  %v4988 = load i64, ptr %slot921, align 8
  %cmp4989 = icmp ne i64 %v4988, 0
  %cv4990 = zext i1 %cmp4989 to i32
  store i32 %cv4990, ptr %slot922, align 8
  %v4991 = load i32, ptr %slot922, align 8
  %cv4992 = zext i32 %v4991 to i64
  %cond4993 = icmp ne i64 %cv4992, 0
  br i1 %cond4993, label %bb_rcgdec1355, label %bb_rcgslow1355
bb_rcgslow1355:
  %v4994 = load i64, ptr %slot909, align 8
  %v4995 = load i64, ptr %slot892, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4994, i64 %v4995) nomerge, !dbg !138
  br label %bb_rcgdone1355
bb_rcgdec1355:
  %v4996 = load i64, ptr %slot918, align 8
  %v4997 = load i64, ptr %slot910, align 8
  %p4998 = inttoptr i64 %v4997 to ptr
  %rgep4999 = getelementptr i8, ptr %p4998, i64 -32
  store i64 %v4996, ptr %rgep4999, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1355
bb_rcgclear1355:
  %v5000 = load i64, ptr %slot892, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  store i64 0, ptr %p5001, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1355
bb_rcgdone1355:
  br label %bb_rcslotdone1324
bb_rcslotdone1324:
  %v5002 = load i64, ptr %slot31, align 8
  %p5003 = inttoptr i64 %v5002 to ptr
  store i64 10, ptr %p5003, align 8, !alias.scope !3, !noalias !4
  %v5004 = load i64, ptr %slot29, align 8
  store i64 %v5004, ptr %slot923, align 8
  %v5005 = load i64, ptr %slot10, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  store i32 2, ptr %p5006, align 4, !alias.scope !3, !noalias !4
  %v5007 = load i64, ptr %slot923, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  %ld5009 = load i64, ptr %p5008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5009, ptr %slot924, align 8
  %v5010 = load i64, ptr %slot924, align 8
  %cmp5011 = icmp ne i64 %v5010, 0
  %cv5012 = zext i1 %cmp5011 to i32
  store i32 %cv5012, ptr %slot925, align 8
  %v5013 = load i32, ptr %slot925, align 8
  %cv5014 = zext i32 %v5013 to i64
  %cond5015 = icmp ne i64 %cv5014, 0
  br i1 %cond5015, label %bb_rcguniquenn1362, label %bb_rcgunique1362
bb_rcguniquenn1362:
  %v5016 = load i64, ptr %slot924, align 8
  %op5017 = sub i64 %v5016, 16
  store i64 %op5017, ptr %slot926, align 8
  %v5018 = load i64, ptr %slot924, align 8
  %p5019 = inttoptr i64 %v5018 to ptr
  %rgep5020 = getelementptr i8, ptr %p5019, i64 -16
  %ld5021 = load i64, ptr %rgep5020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5021, ptr %slot927, align 8
  %v5022 = load i64, ptr %slot927, align 8
  %op5023 = and i64 %v5022, 6917529027641081858
  store i64 %op5023, ptr %slot928, align 8
  %v5024 = load i64, ptr %slot928, align 8
  %cmp5025 = icmp ne i64 %v5024, 0
  %cv5026 = zext i1 %cmp5025 to i32
  store i32 %cv5026, ptr %slot929, align 8
  %v5027 = load i32, ptr %slot929, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcguniqueslow1362, label %bb_rcguniquecount1362
bb_rcguniquecount1362:
  %v5030 = load i64, ptr %slot924, align 8
  %op5031 = sub i64 %v5030, 32
  store i64 %op5031, ptr %slot930, align 8
  %v5032 = load i64, ptr %slot924, align 8
  %p5033 = inttoptr i64 %v5032 to ptr
  %rgep5034 = getelementptr i8, ptr %p5033, i64 -32
  %ld5035 = load i64, ptr %rgep5034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5035, ptr %slot931, align 8
  %v5036 = load i64, ptr %slot931, align 8
  %cmp5037 = icmp ult i64 %v5036, 2
  %cv5038 = zext i1 %cmp5037 to i32
  store i32 %cv5038, ptr %slot932, align 8
  %v5039 = load i32, ptr %slot932, align 8
  %cv5040 = zext i32 %v5039 to i64
  %cond5041 = icmp ne i64 %cv5040, 0
  br i1 %cond5041, label %bb_rcgunique1362, label %bb_rcguniqueslow1362
bb_rcguniqueslow1362:
  %v5042 = load i64, ptr %slot1, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %p5044 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v5045 = load i64, ptr %slot923, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  %v5047 = load i64, ptr %slot9, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  %call5049 = call i32 @myl_qbe_rc_unique_local(ptr %p5043, ptr %p5044, ptr %p5046, ptr %p5048) nomerge, !dbg !140
  store i32 %call5049, ptr %slot933, align 8
  %v5050 = load i32, ptr %slot933, align 8
  %cv5051 = zext i32 %v5050 to i64
  %cond5052 = icmp ne i64 %cv5051, 0
  br i1 %cond5052, label %bb_rcunique1373, label %bb_failure
bb_rcunique1373:
  br label %bb_rcgunique1362
bb_rcgunique1362:
  %v5053 = load i64, ptr %slot29, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %ld5055 = load i64, ptr %p5054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5055, ptr %slot934, align 8
  %v5056 = load i64, ptr %slot31, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %ld5058 = load i64, ptr %p5057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5058, ptr %slot935, align 8
  %v5059 = load i64, ptr %slot934, align 8
  %op5060 = add i64 %v5059, 8
  store i64 %op5060, ptr %slot936, align 8
  %v5061 = load i64, ptr %slot935, align 8
  %cmp5062 = icmp sge i64 %v5061, 0
  %cv5063 = zext i1 %cmp5062 to i64
  store i64 %cv5063, ptr %slot937, align 8
  %v5064 = load i64, ptr %slot937, align 8
  %cond5065 = icmp ne i64 %v5064, 0
  br i1 %cond5065, label %bb_byte_low1377, label %bb_byte_refused1377
bb_byte_low1377:
  %v5066 = load i64, ptr %slot935, align 8
  %cmp5067 = icmp sle i64 %v5066, 255
  %cv5068 = zext i1 %cmp5067 to i64
  store i64 %cv5068, ptr %slot938, align 8
  %v5069 = load i64, ptr %slot938, align 8
  %cond5070 = icmp ne i64 %v5069, 0
  br i1 %cond5070, label %bb_byte_high1377, label %bb_byte_refused1377
bb_byte_high1377:
  %v5071 = load i64, ptr %slot934, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  %ld5073 = load i64, ptr %p5072, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5073, ptr %slot939, align 8
  %v5074 = load i64, ptr %slot936, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  %ld5076 = load i64, ptr %p5075, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5076, ptr %slot940, align 8
  %v5077 = load i64, ptr %slot939, align 8
  %v5078 = load i64, ptr %slot940, align 8
  %cmp5079 = icmp ult i64 %v5077, %v5078
  %cv5080 = zext i1 %cmp5079 to i64
  store i64 %cv5080, ptr %slot941, align 8
  %v5081 = load i64, ptr %slot941, align 8
  %cond5082 = icmp ne i64 %v5081, 0
  br i1 %cond5082, label %bb_byte_fast1377, label %bb_byte_slow1377
bb_byte_slow1377:
  %v5083 = load i64, ptr %slot34, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  %v5085 = load i64, ptr %slot934, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %v5087 = load i64, ptr %slot935, align 8
  %call5088 = call i32 @myl_native_bytes_buffer_append_byte(ptr %p5084, ptr %p5086, i64 %v5087) nomerge, !dbg !140
  store i32 %call5088, ptr %slot942, align 8
  %v5089 = load i32, ptr %slot942, align 8
  %ext5090 = zext i32 %v5089 to i64
  store i64 %ext5090, ptr %slot943, align 8
  %v5091 = load i64, ptr %slot943, align 8
  %cmp5092 = icmp ne i64 %v5091, 0
  %cv5093 = zext i1 %cmp5092 to i64
  store i64 %cv5093, ptr %slot944, align 8
  %v5094 = load i64, ptr %slot944, align 8
  %cond5095 = icmp ne i64 %v5094, 0
  br i1 %cond5095, label %bb_success1387, label %bb_failed1387
bb_failed1387:
  %v5096 = load i64, ptr %slot1, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5097) nomerge, !dbg !140
  unreachable
bb_success1387:
  %v5098 = load i32, ptr %slot942, align 8
  %cmp5099 = icmp eq i32 %v5098, 1
  %cv5100 = zext i1 %cmp5099 to i32
  store i32 %cv5100, ptr %slot945, align 8
  %v5101 = load i32, ptr %slot945, align 8
  %ext5102 = zext i32 %v5101 to i64
  store i64 %ext5102, ptr %slot946, align 8
  %v5103 = load i64, ptr %slot946, align 8
  %v5104 = load i64, ptr %slot31, align 8
  %p5105 = inttoptr i64 %v5104 to ptr
  store i64 %v5103, ptr %p5105, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done1377
bb_byte_fast1377:
  %v5106 = load i64, ptr %slot934, align 8
  %op5107 = add i64 %v5106, 32
  store i64 %op5107, ptr %slot947, align 8
  %v5108 = load i64, ptr %slot947, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %ld5110 = load i64, ptr %p5109, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5110, ptr %slot948, align 8
  %v5111 = load i64, ptr %slot948, align 8
  %v5112 = load i64, ptr %slot939, align 8
  %op5113 = add i64 %v5111, %v5112
  store i64 %op5113, ptr %slot949, align 8
  %v5114 = load i64, ptr %slot935, align 8
  %cv5115 = trunc i64 %v5114 to i8
  %v5116 = load i64, ptr %slot948, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  %v5118 = load i64, ptr %slot939, align 8
  %egep5119 = getelementptr i8, ptr %p5117, i64 %v5118
  store i8 %cv5115, ptr %egep5119, align 1, !alias.scope !12, !noalias !13
  %v5120 = load i64, ptr %slot939, align 8
  %op5121 = add i64 %v5120, 1
  store i64 %op5121, ptr %slot950, align 8
  %v5122 = load i64, ptr %slot950, align 8
  %v5123 = load i64, ptr %slot934, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i64 %v5122, ptr %p5124, align 8, !alias.scope !6, !noalias !7
  %v5125 = load i64, ptr %slot31, align 8
  %p5126 = inttoptr i64 %v5125 to ptr
  store i64 1, ptr %p5126, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done1377
bb_byte_refused1377:
  %v5127 = load i64, ptr %slot31, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  store i64 0, ptr %p5128, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done1377
bb_byte_done1377:
  %v5129 = load i64, ptr %slot23, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  %ld5131 = load i64, ptr %p5130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5131, ptr %slot951, align 8
  %v5132 = load i64, ptr %slot951, align 8
  %v5133 = load i64, ptr %slot31, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  store i64 %v5132, ptr %p5134, align 8, !alias.scope !3, !noalias !4
  %v5135 = load i64, ptr %slot31, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  %ld5137 = load i64, ptr %p5136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5137, ptr %slot952, align 8
  %v5138 = load i64, ptr %slot952, align 8
  %op5139 = add i64 %v5138, 24
  store i64 %op5139, ptr %slot953, align 8
  %v5140 = load i64, ptr %slot953, align 8
  %p5141 = inttoptr i64 %v5140 to ptr
  %ld5142 = load i64, ptr %p5141, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5142, ptr %slot954, align 8
  %v5143 = load i64, ptr %slot954, align 8
  %v5144 = load i64, ptr %slot31, align 8
  %p5145 = inttoptr i64 %v5144 to ptr
  store i64 %v5143, ptr %p5145, align 8, !alias.scope !3, !noalias !4
  %v5146 = load i64, ptr %slot11, align 8
  %p5147 = inttoptr i64 %v5146 to ptr
  %ld5148 = load i32, ptr %p5147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5148, ptr %slot955, align 8
  %v5149 = load i32, ptr %slot955, align 8
  %cv5150 = zext i32 %v5149 to i64
  %cond5151 = icmp ne i64 %cv5150, 0
  br i1 %cond5151, label %bb_rcslotdrop1400, label %bb_rcslotdone1400
bb_rcslotdrop1400:
  %v5152 = load i64, ptr %slot11, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  store i32 0, ptr %p5153, align 4, !alias.scope !3, !noalias !4
  %v5154 = load i64, ptr %slot15, align 8
  store i64 %v5154, ptr %slot956, align 8
  %v5155 = load i64, ptr %slot12, align 8
  %p5156 = inttoptr i64 %v5155 to ptr
  %ld5157 = load i32, ptr %p5156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5157, ptr %slot957, align 8
  %v5158 = load i32, ptr %slot957, align 8
  %op5159 = and i32 %v5158, 28
  store i32 %op5159, ptr %slot958, align 8
  %v5160 = load i32, ptr %slot958, align 8
  %cv5161 = zext i32 %v5160 to i64
  %cond5162 = icmp ne i64 %cv5161, 0
  br i1 %cond5162, label %bb_rcslotrole1400, label %bb_rcslotowner1400
bb_rcslotrole1400:
  %v5163 = load i64, ptr %slot34, align 8
  store i64 %v5163, ptr %slot959, align 8
  %v5164 = load i64, ptr %slot959, align 8
  %v5165 = load i64, ptr %slot956, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v5164, i64 %v5165) nomerge, !dbg !142
  br label %bb_rcslotdone1400
bb_rcslotowner1400:
  %v5166 = load i64, ptr %slot34, align 8
  store i64 %v5166, ptr %slot960, align 8
  %v5167 = load i64, ptr %slot960, align 8
  %v5168 = load i64, ptr %slot956, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5167, i64 %v5168) nomerge, !dbg !142
  br label %bb_rcslotdone1400
bb_rcslotdone1400:
  %v5169 = load i64, ptr %slot31, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  %ld5171 = load i64, ptr %p5170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5171, ptr %slot961, align 8
  %v5172 = load i64, ptr %slot961, align 8
  %v5173 = load i64, ptr %slot30, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  store i64 %v5172, ptr %p5174, align 8, !alias.scope !3, !noalias !4
  %v5175 = load i64, ptr %slot30, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  %ld5177 = load i64, ptr %p5176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5177, ptr %slot962, align 8
  %v5178 = load i64, ptr %slot962, align 8
  %v5179 = load i64, ptr %slot31, align 8
  %p5180 = inttoptr i64 %v5179 to ptr
  store i64 %v5178, ptr %p5180, align 8, !alias.scope !3, !noalias !4
  %v5181 = load i64, ptr %slot29, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  %ld5183 = load i64, ptr %p5182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5183, ptr %slot963, align 8
  %v5184 = load i64, ptr %slot963, align 8
  %v5185 = load i64, ptr %slot32, align 8
  %p5186 = inttoptr i64 %v5185 to ptr
  store i64 %v5184, ptr %p5186, align 8, !alias.scope !3, !noalias !4
  %v5187 = load i64, ptr %slot32, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  %ld5189 = load i64, ptr %p5188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5189, ptr %slot964, align 8
  %v5190 = load i64, ptr %slot31, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  %ld5192 = load i64, ptr %p5191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5192, ptr %slot965, align 8
  %v5193 = load i64, ptr %slot1, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %v5195 = load i64, ptr %slot965, align 8
  %v5196 = load i64, ptr %slot964, align 8
  %p5197 = inttoptr i64 %v5196 to ptr
  %call5198 = call i64 @myl_qbe_stream_write_bytes(ptr %p5194, i64 %v5195, ptr %p5197) nomerge, !dbg !144
  store i64 %call5198, ptr %slot966, align 8
  %v5199 = load i64, ptr %slot966, align 8
  %v5200 = load i64, ptr %slot31, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  store i64 %v5199, ptr %p5201, align 8, !alias.scope !3, !noalias !4
  %v5202 = load i64, ptr %slot31, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  store i64 0, ptr %p5203, align 8, !alias.scope !3, !noalias !4
  %v5204 = load i64, ptr %slot31, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  %ld5206 = load i64, ptr %p5205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5206, ptr %slot967, align 8
  %v5207 = load i64, ptr %slot18, align 8
  %p5209 = inttoptr i64 %v5207 to ptr
  %gep5210 = getelementptr i8, ptr %p5209, i64 24
  %op5208 = ptrtoint ptr %gep5210 to i64
  store i64 %op5208, ptr %slot968, align 8
  %v5211 = load i64, ptr %slot968, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %ld5213 = load i32, ptr %p5212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5213, ptr %slot969, align 8
  %v5214 = load i64, ptr %slot20, align 8
  %p5216 = inttoptr i64 %v5214 to ptr
  %gep5217 = getelementptr i8, ptr %p5216, i64 24
  %op5215 = ptrtoint ptr %gep5217 to i64
  store i64 %op5215, ptr %slot970, align 8
  %v5218 = load i64, ptr %slot970, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %ld5220 = load i32, ptr %p5219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5220, ptr %slot971, align 8
  %v5221 = load i32, ptr %slot969, align 8
  %v5222 = load i32, ptr %slot971, align 8
  %op5223 = or i32 %v5221, %v5222
  store i32 %op5223, ptr %slot972, align 8
  %v5224 = load i32, ptr %slot972, align 8
  %cv5225 = zext i32 %v5224 to i64
  %cond5226 = icmp ne i64 %cv5225, 0
  br i1 %cond5226, label %bb_rcscopesopen1456, label %bb_rcscopesclosed1456
bb_rcscopesopen1456:
  %v5227 = load i64, ptr %slot22, align 8
  %p5229 = inttoptr i64 %v5227 to ptr
  %gep5230 = getelementptr i8, ptr %p5229, i64 0
  %op5228 = ptrtoint ptr %gep5230 to i64
  store i64 %op5228, ptr %slot973, align 8
  %v5231 = load i64, ptr %slot18, align 8
  %v5232 = load i64, ptr %slot973, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  store i64 %v5231, ptr %p5233, align 8, !alias.scope !3, !noalias !4
  %v5234 = load i64, ptr %slot22, align 8
  %p5236 = inttoptr i64 %v5234 to ptr
  %gep5237 = getelementptr i8, ptr %p5236, i64 8
  %op5235 = ptrtoint ptr %gep5237 to i64
  store i64 %op5235, ptr %slot974, align 8
  %v5238 = load i64, ptr %slot20, align 8
  %v5239 = load i64, ptr %slot974, align 8
  %p5240 = inttoptr i64 %v5239 to ptr
  store i64 %v5238, ptr %p5240, align 8, !alias.scope !3, !noalias !4
  %v5241 = load i64, ptr %slot1, align 8
  %p5242 = inttoptr i64 %v5241 to ptr
  %v5243 = load i64, ptr %slot22, align 8
  %p5244 = inttoptr i64 %v5243 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5242, ptr %p5244, i64 2) nomerge, !dbg !146
  br label %bb_rcscopesclosed1456
bb_rcscopesclosed1456:
  %v5245 = load i64, ptr %slot11, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %ld5247 = load i32, ptr %p5246, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5247, ptr %slot975, align 8
  %v5248 = load i32, ptr %slot975, align 8
  %cv5249 = zext i32 %v5248 to i64
  %cond5250 = icmp ne i64 %cv5249, 0
  br i1 %cond5250, label %bb_rcslotdrop1461, label %bb_rcslotdone1461
bb_rcslotdrop1461:
  %v5251 = load i64, ptr %slot11, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  store i32 0, ptr %p5252, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1461
bb_rcslotdone1461:
  %v5253 = load i64, ptr %slot9, align 8
  %p5254 = inttoptr i64 %v5253 to ptr
  %ld5255 = load i32, ptr %p5254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5255, ptr %slot976, align 8
  %v5256 = load i32, ptr %slot976, align 8
  %cv5257 = zext i32 %v5256 to i64
  %cond5258 = icmp ne i64 %cv5257, 0
  br i1 %cond5258, label %bb_rcslotdrop1464, label %bb_rcslotdone1464
bb_rcslotdrop1464:
  %v5259 = load i64, ptr %slot9, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  store i32 0, ptr %p5260, align 4, !alias.scope !3, !noalias !4
  %v5261 = load i64, ptr %slot29, align 8
  store i64 %v5261, ptr %slot977, align 8
  %v5262 = load i64, ptr %slot10, align 8
  %p5263 = inttoptr i64 %v5262 to ptr
  %ld5264 = load i32, ptr %p5263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5264, ptr %slot978, align 8
  %v5265 = load i32, ptr %slot978, align 8
  %op5266 = and i32 %v5265, 28
  store i32 %op5266, ptr %slot979, align 8
  %v5267 = load i32, ptr %slot979, align 8
  %cv5268 = zext i32 %v5267 to i64
  %cond5269 = icmp ne i64 %cv5268, 0
  br i1 %cond5269, label %bb_rcslotrole1464, label %bb_rcslotowner1464
bb_rcslotrole1464:
  %v5270 = load i64, ptr %slot34, align 8
  store i64 %v5270, ptr %slot980, align 8
  %v5271 = load i64, ptr %slot977, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  %ld5273 = load i64, ptr %p5272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5273, ptr %slot981, align 8
  %v5274 = load i64, ptr %slot981, align 8
  %cmp5275 = icmp ne i64 %v5274, 0
  %cv5276 = zext i1 %cmp5275 to i32
  store i32 %cv5276, ptr %slot982, align 8
  %v5277 = load i32, ptr %slot982, align 8
  %cv5278 = zext i32 %v5277 to i64
  %cond5279 = icmp ne i64 %cv5278, 0
  br i1 %cond5279, label %bb_rcgnn1480, label %bb_rcgdone1480
bb_rcgnn1480:
  %v5280 = load i64, ptr %slot981, align 8
  %op5281 = sub i64 %v5280, 16
  store i64 %op5281, ptr %slot983, align 8
  %v5282 = load i64, ptr %slot981, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  %rgep5284 = getelementptr i8, ptr %p5283, i64 -16
  %ld5285 = load i64, ptr %rgep5284, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5285, ptr %slot984, align 8
  %v5286 = load i64, ptr %slot984, align 8
  %op5287 = and i64 %v5286, 4611686018427387906
  store i64 %op5287, ptr %slot985, align 8
  %v5288 = load i64, ptr %slot985, align 8
  %cmp5289 = icmp ne i64 %v5288, 0
  %cv5290 = zext i1 %cmp5289 to i32
  store i32 %cv5290, ptr %slot986, align 8
  %v5291 = load i32, ptr %slot986, align 8
  %cv5292 = zext i32 %v5291 to i64
  %cond5293 = icmp ne i64 %cv5292, 0
  br i1 %cond5293, label %bb_rcgclear1480, label %bb_rcgcounted1480
bb_rcgcounted1480:
  %v5294 = load i64, ptr %slot981, align 8
  %op5295 = sub i64 %v5294, 24
  store i64 %op5295, ptr %slot987, align 8
  %v5296 = load i64, ptr %slot981, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  %rgep5298 = getelementptr i8, ptr %p5297, i64 -24
  %ld5299 = load i64, ptr %rgep5298, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5299, ptr %slot988, align 8
  %v5300 = load i64, ptr %slot988, align 8
  %op5301 = sub i64 %v5300, 1
  store i64 %op5301, ptr %slot989, align 8
  %v5302 = load i64, ptr %slot989, align 8
  %cmp5303 = icmp eq i64 %v5302, 0
  %cv5304 = zext i1 %cmp5303 to i32
  store i32 %cv5304, ptr %slot990, align 8
  %v5305 = load i32, ptr %slot990, align 8
  %cv5306 = zext i32 %v5305 to i64
  %cond5307 = icmp ne i64 %cv5306, 0
  br i1 %cond5307, label %bb_rcglast1480, label %bb_rcgdec1480
bb_rcglast1480:
  %v5308 = load i64, ptr %slot981, align 8
  %op5309 = sub i64 %v5308, 32
  store i64 %op5309, ptr %slot991, align 8
  %v5310 = load i64, ptr %slot981, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %rgep5312 = getelementptr i8, ptr %p5311, i64 -32
  %ld5313 = load i64, ptr %rgep5312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5313, ptr %slot992, align 8
  %v5314 = load i64, ptr %slot992, align 8
  %cmp5315 = icmp ne i64 %v5314, 0
  %cv5316 = zext i1 %cmp5315 to i32
  store i32 %cv5316, ptr %slot993, align 8
  %v5317 = load i32, ptr %slot993, align 8
  %cv5318 = zext i32 %v5317 to i64
  %cond5319 = icmp ne i64 %cv5318, 0
  br i1 %cond5319, label %bb_rcgdec1480, label %bb_rcgslow1480
bb_rcgslow1480:
  %v5320 = load i64, ptr %slot980, align 8
  %v5321 = load i64, ptr %slot977, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v5320, i64 %v5321) nomerge, !dbg !146
  br label %bb_rcgdone1480
bb_rcgdec1480:
  %v5322 = load i64, ptr %slot989, align 8
  %v5323 = load i64, ptr %slot981, align 8
  %p5324 = inttoptr i64 %v5323 to ptr
  %rgep5325 = getelementptr i8, ptr %p5324, i64 -24
  store i64 %v5322, ptr %rgep5325, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1480
bb_rcgclear1480:
  %v5326 = load i64, ptr %slot977, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  store i64 0, ptr %p5327, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1480
bb_rcgdone1480:
  br label %bb_rcslotdone1464
bb_rcslotowner1464:
  %v5328 = load i64, ptr %slot34, align 8
  store i64 %v5328, ptr %slot994, align 8
  %v5329 = load i64, ptr %slot977, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i64, ptr %p5330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5331, ptr %slot995, align 8
  %v5332 = load i64, ptr %slot995, align 8
  %cmp5333 = icmp ne i64 %v5332, 0
  %cv5334 = zext i1 %cmp5333 to i32
  store i32 %cv5334, ptr %slot996, align 8
  %v5335 = load i32, ptr %slot996, align 8
  %cv5336 = zext i32 %v5335 to i64
  %cond5337 = icmp ne i64 %cv5336, 0
  br i1 %cond5337, label %bb_rcgnn1495, label %bb_rcgdone1495
bb_rcgnn1495:
  %v5338 = load i64, ptr %slot995, align 8
  %op5339 = sub i64 %v5338, 16
  store i64 %op5339, ptr %slot997, align 8
  %v5340 = load i64, ptr %slot995, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %rgep5342 = getelementptr i8, ptr %p5341, i64 -16
  %ld5343 = load i64, ptr %rgep5342, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5343, ptr %slot998, align 8
  %v5344 = load i64, ptr %slot998, align 8
  %op5345 = and i64 %v5344, 4611686018427387906
  store i64 %op5345, ptr %slot999, align 8
  %v5346 = load i64, ptr %slot999, align 8
  %cmp5347 = icmp ne i64 %v5346, 0
  %cv5348 = zext i1 %cmp5347 to i32
  store i32 %cv5348, ptr %slot1000, align 8
  %v5349 = load i32, ptr %slot1000, align 8
  %cv5350 = zext i32 %v5349 to i64
  %cond5351 = icmp ne i64 %cv5350, 0
  br i1 %cond5351, label %bb_rcgclear1495, label %bb_rcgcounted1495
bb_rcgcounted1495:
  %v5352 = load i64, ptr %slot995, align 8
  %op5353 = sub i64 %v5352, 32
  store i64 %op5353, ptr %slot1001, align 8
  %v5354 = load i64, ptr %slot995, align 8
  %p5355 = inttoptr i64 %v5354 to ptr
  %rgep5356 = getelementptr i8, ptr %p5355, i64 -32
  %ld5357 = load i64, ptr %rgep5356, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5357, ptr %slot1002, align 8
  %v5358 = load i64, ptr %slot1002, align 8
  %op5359 = sub i64 %v5358, 1
  store i64 %op5359, ptr %slot1003, align 8
  %v5360 = load i64, ptr %slot1003, align 8
  %cmp5361 = icmp eq i64 %v5360, 0
  %cv5362 = zext i1 %cmp5361 to i32
  store i32 %cv5362, ptr %slot1004, align 8
  %v5363 = load i32, ptr %slot1004, align 8
  %cv5364 = zext i32 %v5363 to i64
  %cond5365 = icmp ne i64 %cv5364, 0
  br i1 %cond5365, label %bb_rcglast1495, label %bb_rcgdec1495
bb_rcglast1495:
  %v5366 = load i64, ptr %slot995, align 8
  %op5367 = sub i64 %v5366, 24
  store i64 %op5367, ptr %slot1005, align 8
  %v5368 = load i64, ptr %slot995, align 8
  %p5369 = inttoptr i64 %v5368 to ptr
  %rgep5370 = getelementptr i8, ptr %p5369, i64 -24
  %ld5371 = load i64, ptr %rgep5370, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5371, ptr %slot1006, align 8
  %v5372 = load i64, ptr %slot1006, align 8
  %cmp5373 = icmp ne i64 %v5372, 0
  %cv5374 = zext i1 %cmp5373 to i32
  store i32 %cv5374, ptr %slot1007, align 8
  %v5375 = load i32, ptr %slot1007, align 8
  %cv5376 = zext i32 %v5375 to i64
  %cond5377 = icmp ne i64 %cv5376, 0
  br i1 %cond5377, label %bb_rcgdec1495, label %bb_rcgslow1495
bb_rcgslow1495:
  %v5378 = load i64, ptr %slot994, align 8
  %v5379 = load i64, ptr %slot977, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v5378, i64 %v5379) nomerge, !dbg !146
  br label %bb_rcgdone1495
bb_rcgdec1495:
  %v5380 = load i64, ptr %slot1003, align 8
  %v5381 = load i64, ptr %slot995, align 8
  %p5382 = inttoptr i64 %v5381 to ptr
  %rgep5383 = getelementptr i8, ptr %p5382, i64 -32
  store i64 %v5380, ptr %rgep5383, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1495
bb_rcgclear1495:
  %v5384 = load i64, ptr %slot977, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  store i64 0, ptr %p5385, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1495
bb_rcgdone1495:
  br label %bb_rcslotdone1464
bb_rcslotdone1464:
  %v5386 = load i64, ptr %slot7, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %ld5388 = load i32, ptr %p5387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5388, ptr %slot1008, align 8
  %v5389 = load i32, ptr %slot1008, align 8
  %cv5390 = zext i32 %v5389 to i64
  %cond5391 = icmp ne i64 %cv5390, 0
  br i1 %cond5391, label %bb_rcslotdrop1501, label %bb_rcslotdone1501
bb_rcslotdrop1501:
  %v5392 = load i64, ptr %slot7, align 8
  %p5393 = inttoptr i64 %v5392 to ptr
  store i32 0, ptr %p5393, align 4, !alias.scope !3, !noalias !4
  %v5394 = load i64, ptr %slot28, align 8
  store i64 %v5394, ptr %slot1009, align 8
  %v5395 = load i64, ptr %slot8, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  %ld5397 = load i32, ptr %p5396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5397, ptr %slot1010, align 8
  %v5398 = load i32, ptr %slot1010, align 8
  %op5399 = and i32 %v5398, 28
  store i32 %op5399, ptr %slot1011, align 8
  %v5400 = load i32, ptr %slot1011, align 8
  %cv5401 = zext i32 %v5400 to i64
  %cond5402 = icmp ne i64 %cv5401, 0
  br i1 %cond5402, label %bb_rcslotrole1501, label %bb_rcslotowner1501
bb_rcslotrole1501:
  %v5403 = load i64, ptr %slot34, align 8
  store i64 %v5403, ptr %slot1012, align 8
  %v5404 = load i64, ptr %slot1009, align 8
  %p5405 = inttoptr i64 %v5404 to ptr
  %ld5406 = load i64, ptr %p5405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5406, ptr %slot1013, align 8
  %v5407 = load i64, ptr %slot1013, align 8
  %cmp5408 = icmp ne i64 %v5407, 0
  %cv5409 = zext i1 %cmp5408 to i32
  store i32 %cv5409, ptr %slot1014, align 8
  %v5410 = load i32, ptr %slot1014, align 8
  %cv5411 = zext i32 %v5410 to i64
  %cond5412 = icmp ne i64 %cv5411, 0
  br i1 %cond5412, label %bb_rcgnn1517, label %bb_rcgdone1517
bb_rcgnn1517:
  %v5413 = load i64, ptr %slot1013, align 8
  %op5414 = sub i64 %v5413, 16
  store i64 %op5414, ptr %slot1015, align 8
  %v5415 = load i64, ptr %slot1013, align 8
  %p5416 = inttoptr i64 %v5415 to ptr
  %rgep5417 = getelementptr i8, ptr %p5416, i64 -16
  %ld5418 = load i64, ptr %rgep5417, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5418, ptr %slot1016, align 8
  %v5419 = load i64, ptr %slot1016, align 8
  %op5420 = and i64 %v5419, 4611686018427387906
  store i64 %op5420, ptr %slot1017, align 8
  %v5421 = load i64, ptr %slot1017, align 8
  %cmp5422 = icmp ne i64 %v5421, 0
  %cv5423 = zext i1 %cmp5422 to i32
  store i32 %cv5423, ptr %slot1018, align 8
  %v5424 = load i32, ptr %slot1018, align 8
  %cv5425 = zext i32 %v5424 to i64
  %cond5426 = icmp ne i64 %cv5425, 0
  br i1 %cond5426, label %bb_rcgclear1517, label %bb_rcgcounted1517
bb_rcgcounted1517:
  %v5427 = load i64, ptr %slot1013, align 8
  %op5428 = sub i64 %v5427, 24
  store i64 %op5428, ptr %slot1019, align 8
  %v5429 = load i64, ptr %slot1013, align 8
  %p5430 = inttoptr i64 %v5429 to ptr
  %rgep5431 = getelementptr i8, ptr %p5430, i64 -24
  %ld5432 = load i64, ptr %rgep5431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5432, ptr %slot1020, align 8
  %v5433 = load i64, ptr %slot1020, align 8
  %op5434 = sub i64 %v5433, 1
  store i64 %op5434, ptr %slot1021, align 8
  %v5435 = load i64, ptr %slot1021, align 8
  %cmp5436 = icmp eq i64 %v5435, 0
  %cv5437 = zext i1 %cmp5436 to i32
  store i32 %cv5437, ptr %slot1022, align 8
  %v5438 = load i32, ptr %slot1022, align 8
  %cv5439 = zext i32 %v5438 to i64
  %cond5440 = icmp ne i64 %cv5439, 0
  br i1 %cond5440, label %bb_rcglast1517, label %bb_rcgdec1517
bb_rcglast1517:
  %v5441 = load i64, ptr %slot1013, align 8
  %op5442 = sub i64 %v5441, 32
  store i64 %op5442, ptr %slot1023, align 8
  %v5443 = load i64, ptr %slot1013, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  %rgep5445 = getelementptr i8, ptr %p5444, i64 -32
  %ld5446 = load i64, ptr %rgep5445, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5446, ptr %slot1024, align 8
  %v5447 = load i64, ptr %slot1024, align 8
  %cmp5448 = icmp ne i64 %v5447, 0
  %cv5449 = zext i1 %cmp5448 to i32
  store i32 %cv5449, ptr %slot1025, align 8
  %v5450 = load i32, ptr %slot1025, align 8
  %cv5451 = zext i32 %v5450 to i64
  %cond5452 = icmp ne i64 %cv5451, 0
  br i1 %cond5452, label %bb_rcgdec1517, label %bb_rcgslow1517
bb_rcgslow1517:
  %v5453 = load i64, ptr %slot1012, align 8
  %v5454 = load i64, ptr %slot1009, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5453, i64 %v5454) nomerge, !dbg !146
  br label %bb_rcgdone1517
bb_rcgdec1517:
  %v5455 = load i64, ptr %slot1021, align 8
  %v5456 = load i64, ptr %slot1013, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  %rgep5458 = getelementptr i8, ptr %p5457, i64 -24
  store i64 %v5455, ptr %rgep5458, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1517
bb_rcgclear1517:
  %v5459 = load i64, ptr %slot1009, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  store i64 0, ptr %p5460, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1517
bb_rcgdone1517:
  br label %bb_rcslotdone1501
bb_rcslotowner1501:
  %v5461 = load i64, ptr %slot34, align 8
  store i64 %v5461, ptr %slot1026, align 8
  %v5462 = load i64, ptr %slot1009, align 8
  %p5463 = inttoptr i64 %v5462 to ptr
  %ld5464 = load i64, ptr %p5463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5464, ptr %slot1027, align 8
  %v5465 = load i64, ptr %slot1027, align 8
  %cmp5466 = icmp ne i64 %v5465, 0
  %cv5467 = zext i1 %cmp5466 to i32
  store i32 %cv5467, ptr %slot1028, align 8
  %v5468 = load i32, ptr %slot1028, align 8
  %cv5469 = zext i32 %v5468 to i64
  %cond5470 = icmp ne i64 %cv5469, 0
  br i1 %cond5470, label %bb_rcgnn1532, label %bb_rcgdone1532
bb_rcgnn1532:
  %v5471 = load i64, ptr %slot1027, align 8
  %op5472 = sub i64 %v5471, 16
  store i64 %op5472, ptr %slot1029, align 8
  %v5473 = load i64, ptr %slot1027, align 8
  %p5474 = inttoptr i64 %v5473 to ptr
  %rgep5475 = getelementptr i8, ptr %p5474, i64 -16
  %ld5476 = load i64, ptr %rgep5475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5476, ptr %slot1030, align 8
  %v5477 = load i64, ptr %slot1030, align 8
  %op5478 = and i64 %v5477, 4611686018427387906
  store i64 %op5478, ptr %slot1031, align 8
  %v5479 = load i64, ptr %slot1031, align 8
  %cmp5480 = icmp ne i64 %v5479, 0
  %cv5481 = zext i1 %cmp5480 to i32
  store i32 %cv5481, ptr %slot1032, align 8
  %v5482 = load i32, ptr %slot1032, align 8
  %cv5483 = zext i32 %v5482 to i64
  %cond5484 = icmp ne i64 %cv5483, 0
  br i1 %cond5484, label %bb_rcgclear1532, label %bb_rcgcounted1532
bb_rcgcounted1532:
  %v5485 = load i64, ptr %slot1027, align 8
  %op5486 = sub i64 %v5485, 32
  store i64 %op5486, ptr %slot1033, align 8
  %v5487 = load i64, ptr %slot1027, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  %rgep5489 = getelementptr i8, ptr %p5488, i64 -32
  %ld5490 = load i64, ptr %rgep5489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5490, ptr %slot1034, align 8
  %v5491 = load i64, ptr %slot1034, align 8
  %op5492 = sub i64 %v5491, 1
  store i64 %op5492, ptr %slot1035, align 8
  %v5493 = load i64, ptr %slot1035, align 8
  %cmp5494 = icmp eq i64 %v5493, 0
  %cv5495 = zext i1 %cmp5494 to i32
  store i32 %cv5495, ptr %slot1036, align 8
  %v5496 = load i32, ptr %slot1036, align 8
  %cv5497 = zext i32 %v5496 to i64
  %cond5498 = icmp ne i64 %cv5497, 0
  br i1 %cond5498, label %bb_rcglast1532, label %bb_rcgdec1532
bb_rcglast1532:
  %v5499 = load i64, ptr %slot1027, align 8
  %op5500 = sub i64 %v5499, 24
  store i64 %op5500, ptr %slot1037, align 8
  %v5501 = load i64, ptr %slot1027, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %rgep5503 = getelementptr i8, ptr %p5502, i64 -24
  %ld5504 = load i64, ptr %rgep5503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5504, ptr %slot1038, align 8
  %v5505 = load i64, ptr %slot1038, align 8
  %cmp5506 = icmp ne i64 %v5505, 0
  %cv5507 = zext i1 %cmp5506 to i32
  store i32 %cv5507, ptr %slot1039, align 8
  %v5508 = load i32, ptr %slot1039, align 8
  %cv5509 = zext i32 %v5508 to i64
  %cond5510 = icmp ne i64 %cv5509, 0
  br i1 %cond5510, label %bb_rcgdec1532, label %bb_rcgslow1532
bb_rcgslow1532:
  %v5511 = load i64, ptr %slot1026, align 8
  %v5512 = load i64, ptr %slot1009, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5511, i64 %v5512) nomerge, !dbg !146
  br label %bb_rcgdone1532
bb_rcgdec1532:
  %v5513 = load i64, ptr %slot1035, align 8
  %v5514 = load i64, ptr %slot1027, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  %rgep5516 = getelementptr i8, ptr %p5515, i64 -32
  store i64 %v5513, ptr %rgep5516, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1532
bb_rcgclear1532:
  %v5517 = load i64, ptr %slot1009, align 8
  %p5518 = inttoptr i64 %v5517 to ptr
  store i64 0, ptr %p5518, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1532
bb_rcgdone1532:
  br label %bb_rcslotdone1501
bb_rcslotdone1501:
  %v5519 = load i64, ptr %slot5, align 8
  %p5520 = inttoptr i64 %v5519 to ptr
  %ld5521 = load i32, ptr %p5520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5521, ptr %slot1040, align 8
  %v5522 = load i32, ptr %slot1040, align 8
  %cv5523 = zext i32 %v5522 to i64
  %cond5524 = icmp ne i64 %cv5523, 0
  br i1 %cond5524, label %bb_rcslotdrop1538, label %bb_rcslotdone1538
bb_rcslotdrop1538:
  %v5525 = load i64, ptr %slot5, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  store i32 0, ptr %p5526, align 4, !alias.scope !3, !noalias !4
  %v5527 = load i64, ptr %slot27, align 8
  store i64 %v5527, ptr %slot1041, align 8
  %v5528 = load i64, ptr %slot6, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %ld5530 = load i32, ptr %p5529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5530, ptr %slot1042, align 8
  %v5531 = load i32, ptr %slot1042, align 8
  %op5532 = and i32 %v5531, 28
  store i32 %op5532, ptr %slot1043, align 8
  %v5533 = load i32, ptr %slot1043, align 8
  %cv5534 = zext i32 %v5533 to i64
  %cond5535 = icmp ne i64 %cv5534, 0
  br i1 %cond5535, label %bb_rcslotrole1538, label %bb_rcslotowner1538
bb_rcslotrole1538:
  %v5536 = load i64, ptr %slot34, align 8
  store i64 %v5536, ptr %slot1044, align 8
  %v5537 = load i64, ptr %slot1041, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  %ld5539 = load i64, ptr %p5538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5539, ptr %slot1045, align 8
  %v5540 = load i64, ptr %slot1045, align 8
  %cmp5541 = icmp ne i64 %v5540, 0
  %cv5542 = zext i1 %cmp5541 to i32
  store i32 %cv5542, ptr %slot1046, align 8
  %v5543 = load i32, ptr %slot1046, align 8
  %cv5544 = zext i32 %v5543 to i64
  %cond5545 = icmp ne i64 %cv5544, 0
  br i1 %cond5545, label %bb_rcgnn1554, label %bb_rcgdone1554
bb_rcgnn1554:
  %v5546 = load i64, ptr %slot1045, align 8
  %op5547 = sub i64 %v5546, 16
  store i64 %op5547, ptr %slot1047, align 8
  %v5548 = load i64, ptr %slot1045, align 8
  %p5549 = inttoptr i64 %v5548 to ptr
  %rgep5550 = getelementptr i8, ptr %p5549, i64 -16
  %ld5551 = load i64, ptr %rgep5550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5551, ptr %slot1048, align 8
  %v5552 = load i64, ptr %slot1048, align 8
  %op5553 = and i64 %v5552, 4611686018427387906
  store i64 %op5553, ptr %slot1049, align 8
  %v5554 = load i64, ptr %slot1049, align 8
  %cmp5555 = icmp ne i64 %v5554, 0
  %cv5556 = zext i1 %cmp5555 to i32
  store i32 %cv5556, ptr %slot1050, align 8
  %v5557 = load i32, ptr %slot1050, align 8
  %cv5558 = zext i32 %v5557 to i64
  %cond5559 = icmp ne i64 %cv5558, 0
  br i1 %cond5559, label %bb_rcgclear1554, label %bb_rcgcounted1554
bb_rcgcounted1554:
  %v5560 = load i64, ptr %slot1045, align 8
  %op5561 = sub i64 %v5560, 24
  store i64 %op5561, ptr %slot1051, align 8
  %v5562 = load i64, ptr %slot1045, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %rgep5564 = getelementptr i8, ptr %p5563, i64 -24
  %ld5565 = load i64, ptr %rgep5564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5565, ptr %slot1052, align 8
  %v5566 = load i64, ptr %slot1052, align 8
  %op5567 = sub i64 %v5566, 1
  store i64 %op5567, ptr %slot1053, align 8
  %v5568 = load i64, ptr %slot1053, align 8
  %cmp5569 = icmp eq i64 %v5568, 0
  %cv5570 = zext i1 %cmp5569 to i32
  store i32 %cv5570, ptr %slot1054, align 8
  %v5571 = load i32, ptr %slot1054, align 8
  %cv5572 = zext i32 %v5571 to i64
  %cond5573 = icmp ne i64 %cv5572, 0
  br i1 %cond5573, label %bb_rcglast1554, label %bb_rcgdec1554
bb_rcglast1554:
  %v5574 = load i64, ptr %slot1045, align 8
  %op5575 = sub i64 %v5574, 32
  store i64 %op5575, ptr %slot1055, align 8
  %v5576 = load i64, ptr %slot1045, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  %rgep5578 = getelementptr i8, ptr %p5577, i64 -32
  %ld5579 = load i64, ptr %rgep5578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5579, ptr %slot1056, align 8
  %v5580 = load i64, ptr %slot1056, align 8
  %cmp5581 = icmp ne i64 %v5580, 0
  %cv5582 = zext i1 %cmp5581 to i32
  store i32 %cv5582, ptr %slot1057, align 8
  %v5583 = load i32, ptr %slot1057, align 8
  %cv5584 = zext i32 %v5583 to i64
  %cond5585 = icmp ne i64 %cv5584, 0
  br i1 %cond5585, label %bb_rcgdec1554, label %bb_rcgslow1554
bb_rcgslow1554:
  %v5586 = load i64, ptr %slot1044, align 8
  %v5587 = load i64, ptr %slot1041, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5586, i64 %v5587) nomerge, !dbg !146
  br label %bb_rcgdone1554
bb_rcgdec1554:
  %v5588 = load i64, ptr %slot1053, align 8
  %v5589 = load i64, ptr %slot1045, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %rgep5591 = getelementptr i8, ptr %p5590, i64 -24
  store i64 %v5588, ptr %rgep5591, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1554
bb_rcgclear1554:
  %v5592 = load i64, ptr %slot1041, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  store i64 0, ptr %p5593, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1554
bb_rcgdone1554:
  br label %bb_rcslotdone1538
bb_rcslotowner1538:
  %v5594 = load i64, ptr %slot34, align 8
  store i64 %v5594, ptr %slot1058, align 8
  %v5595 = load i64, ptr %slot1041, align 8
  %p5596 = inttoptr i64 %v5595 to ptr
  %ld5597 = load i64, ptr %p5596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5597, ptr %slot1059, align 8
  %v5598 = load i64, ptr %slot1059, align 8
  %cmp5599 = icmp ne i64 %v5598, 0
  %cv5600 = zext i1 %cmp5599 to i32
  store i32 %cv5600, ptr %slot1060, align 8
  %v5601 = load i32, ptr %slot1060, align 8
  %cv5602 = zext i32 %v5601 to i64
  %cond5603 = icmp ne i64 %cv5602, 0
  br i1 %cond5603, label %bb_rcgnn1569, label %bb_rcgdone1569
bb_rcgnn1569:
  %v5604 = load i64, ptr %slot1059, align 8
  %op5605 = sub i64 %v5604, 16
  store i64 %op5605, ptr %slot1061, align 8
  %v5606 = load i64, ptr %slot1059, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  %rgep5608 = getelementptr i8, ptr %p5607, i64 -16
  %ld5609 = load i64, ptr %rgep5608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5609, ptr %slot1062, align 8
  %v5610 = load i64, ptr %slot1062, align 8
  %op5611 = and i64 %v5610, 4611686018427387906
  store i64 %op5611, ptr %slot1063, align 8
  %v5612 = load i64, ptr %slot1063, align 8
  %cmp5613 = icmp ne i64 %v5612, 0
  %cv5614 = zext i1 %cmp5613 to i32
  store i32 %cv5614, ptr %slot1064, align 8
  %v5615 = load i32, ptr %slot1064, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcgclear1569, label %bb_rcgcounted1569
bb_rcgcounted1569:
  %v5618 = load i64, ptr %slot1059, align 8
  %op5619 = sub i64 %v5618, 32
  store i64 %op5619, ptr %slot1065, align 8
  %v5620 = load i64, ptr %slot1059, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  %rgep5622 = getelementptr i8, ptr %p5621, i64 -32
  %ld5623 = load i64, ptr %rgep5622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5623, ptr %slot1066, align 8
  %v5624 = load i64, ptr %slot1066, align 8
  %op5625 = sub i64 %v5624, 1
  store i64 %op5625, ptr %slot1067, align 8
  %v5626 = load i64, ptr %slot1067, align 8
  %cmp5627 = icmp eq i64 %v5626, 0
  %cv5628 = zext i1 %cmp5627 to i32
  store i32 %cv5628, ptr %slot1068, align 8
  %v5629 = load i32, ptr %slot1068, align 8
  %cv5630 = zext i32 %v5629 to i64
  %cond5631 = icmp ne i64 %cv5630, 0
  br i1 %cond5631, label %bb_rcglast1569, label %bb_rcgdec1569
bb_rcglast1569:
  %v5632 = load i64, ptr %slot1059, align 8
  %op5633 = sub i64 %v5632, 24
  store i64 %op5633, ptr %slot1069, align 8
  %v5634 = load i64, ptr %slot1059, align 8
  %p5635 = inttoptr i64 %v5634 to ptr
  %rgep5636 = getelementptr i8, ptr %p5635, i64 -24
  %ld5637 = load i64, ptr %rgep5636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5637, ptr %slot1070, align 8
  %v5638 = load i64, ptr %slot1070, align 8
  %cmp5639 = icmp ne i64 %v5638, 0
  %cv5640 = zext i1 %cmp5639 to i32
  store i32 %cv5640, ptr %slot1071, align 8
  %v5641 = load i32, ptr %slot1071, align 8
  %cv5642 = zext i32 %v5641 to i64
  %cond5643 = icmp ne i64 %cv5642, 0
  br i1 %cond5643, label %bb_rcgdec1569, label %bb_rcgslow1569
bb_rcgslow1569:
  %v5644 = load i64, ptr %slot1058, align 8
  %v5645 = load i64, ptr %slot1041, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5644, i64 %v5645) nomerge, !dbg !146
  br label %bb_rcgdone1569
bb_rcgdec1569:
  %v5646 = load i64, ptr %slot1067, align 8
  %v5647 = load i64, ptr %slot1059, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  %rgep5649 = getelementptr i8, ptr %p5648, i64 -32
  store i64 %v5646, ptr %rgep5649, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1569
bb_rcgclear1569:
  %v5650 = load i64, ptr %slot1041, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  store i64 0, ptr %p5651, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1569
bb_rcgdone1569:
  br label %bb_rcslotdone1538
bb_rcslotdone1538:
  %v5652 = load i64, ptr %slot967, align 8
  ret i64 %v5652
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare i32 @myl_native_bytes_buffer_append_byte(ptr, ptr, i64)
declare i32 @myl_native_bytes_buffer_append_range(ptr, ptr, ptr, i64, i64)
declare void @myl_native_bytes_copy_octets(ptr, ptr, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_qbe_bytes_from_list(ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i64 @myl_qbe_stream_write_bytes(ptr, i64, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f", linkageName: "myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 744034140973618023, i64 0, !"myl_f_ce937c0a67fd59c0f261e0a4ab35ebce3e2c051d9627ea0c05a57eafb505b71f"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!126 = !DILocation(line: 20, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!128 = !DILocation(line: 22, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!130 = !DILocation(line: 23, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!132 = !DILocation(line: 26, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!134 = !DILocation(line: 28, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!136 = !DILocation(line: 29, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!138 = !DILocation(line: 34, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!142 = !DILocation(line: 40, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!144 = !DILocation(line: 44, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!146 = !DILocation(line: 47, column: 0, scope: !147)
