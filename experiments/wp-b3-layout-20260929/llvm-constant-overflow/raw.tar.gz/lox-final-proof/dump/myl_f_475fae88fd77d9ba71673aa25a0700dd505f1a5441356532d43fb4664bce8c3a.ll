target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %callresult38 = alloca [16 x i8], align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %callresult75 = alloca [48 x i8], align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v194 = load i64, ptr %slot1, align 8
  %op195 = add i64 %v194, 32
  store i64 %op195, ptr %slot3, align 8
  %mem196 = alloca i8, i64 16, align 8
  %ptr197 = ptrtoint ptr %mem196 to i64
  store i64 %ptr197, ptr %slot4, align 8
  %mem198 = alloca i8, i64 8, align 8
  %ptr199 = ptrtoint ptr %mem198 to i64
  store i64 %ptr199, ptr %slot5, align 8
  %mem200 = alloca i8, i64 8, align 8
  %ptr201 = ptrtoint ptr %mem200 to i64
  store i64 %ptr201, ptr %slot6, align 8
  %mem202 = alloca i8, i64 8, align 8
  %ptr203 = ptrtoint ptr %mem202 to i64
  store i64 %ptr203, ptr %slot7, align 8
  %mem204 = alloca i8, i64 8, align 8
  %ptr205 = ptrtoint ptr %mem204 to i64
  store i64 %ptr205, ptr %slot8, align 8
  %mem206 = alloca i8, i64 8, align 8
  %ptr207 = ptrtoint ptr %mem206 to i64
  store i64 %ptr207, ptr %slot9, align 8
  %mem208 = alloca i8, i64 8, align 8
  %ptr209 = ptrtoint ptr %mem208 to i64
  store i64 %ptr209, ptr %slot10, align 8
  %mem210 = alloca i8, i64 8, align 8
  %ptr211 = ptrtoint ptr %mem210 to i64
  store i64 %ptr211, ptr %slot11, align 8
  %mem212 = alloca i8, i64 8, align 8
  %ptr213 = ptrtoint ptr %mem212 to i64
  store i64 %ptr213, ptr %slot12, align 8
  %mem214 = alloca i8, i64 8, align 8
  %ptr215 = ptrtoint ptr %mem214 to i64
  store i64 %ptr215, ptr %slot13, align 8
  %mem216 = alloca i8, i64 312, align 8
  %ptr217 = ptrtoint ptr %mem216 to i64
  store i64 %ptr217, ptr %slot14, align 8
  %mem218 = alloca i8, i64 88, align 8
  %ptr219 = ptrtoint ptr %mem218 to i64
  store i64 %ptr219, ptr %slot15, align 8
  %mem220 = alloca i8, i64 8, align 8
  %ptr221 = ptrtoint ptr %mem220 to i64
  store i64 %ptr221, ptr %slot16, align 8
  %mem222 = alloca i8, i64 8, align 8
  %ptr223 = ptrtoint ptr %mem222 to i64
  store i64 %ptr223, ptr %slot17, align 8
  %mem224 = alloca i8, i64 312, align 8
  %ptr225 = ptrtoint ptr %mem224 to i64
  store i64 %ptr225, ptr %slot18, align 8
  %mem226 = alloca i8, i64 8, align 8
  %ptr227 = ptrtoint ptr %mem226 to i64
  store i64 %ptr227, ptr %slot19, align 8
  %mem228 = alloca i8, i64 8, align 8
  %ptr229 = ptrtoint ptr %mem228 to i64
  store i64 %ptr229, ptr %slot20, align 8
  %mem230 = alloca i8, i64 8, align 8
  %ptr231 = ptrtoint ptr %mem230 to i64
  store i64 %ptr231, ptr %slot21, align 8
  %mem232 = alloca i8, i64 8, align 8
  %ptr233 = ptrtoint ptr %mem232 to i64
  store i64 %ptr233, ptr %slot22, align 8
  %mem234 = alloca i8, i64 8, align 8
  %ptr235 = ptrtoint ptr %mem234 to i64
  store i64 %ptr235, ptr %slot23, align 8
  %mem236 = alloca i8, i64 16, align 8
  %ptr237 = ptrtoint ptr %mem236 to i64
  store i64 %ptr237, ptr %slot24, align 8
  %mem238 = alloca i8, i64 312, align 8
  %ptr239 = ptrtoint ptr %mem238 to i64
  store i64 %ptr239, ptr %slot25, align 8
  %mem240 = alloca i8, i64 48, align 8
  %ptr241 = ptrtoint ptr %mem240 to i64
  store i64 %ptr241, ptr %slot26, align 8
  %mem242 = alloca i8, i64 312, align 8
  %ptr243 = ptrtoint ptr %mem242 to i64
  store i64 %ptr243, ptr %slot27, align 8
  %mem244 = alloca i8, i64 16, align 8
  %ptr245 = ptrtoint ptr %mem244 to i64
  store i64 %ptr245, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem246 = alloca i8, i64 8, align 8
  %ptr247 = ptrtoint ptr %mem246 to i64
  store i64 %ptr247, ptr %slot29, align 8
  %v248 = load i64, ptr %slot1, align 8
  %op249 = add i64 %v248, 64
  store i64 %op249, ptr %slot30, align 8
  %v250 = load i64, ptr %slot30, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !4, !noalias !3
  store i64 %ld252, ptr %slot31, align 8
  %stack253 = call ptr @llvm.stacksave()
  %stackaddr254 = ptrtoint ptr %stack253 to i64
  %v255 = load i64, ptr %slot31, align 8
  %cmp256 = icmp ult i64 %stackaddr254, %v255
  %cv257 = zext i1 %cmp256 to i64
  store i64 %cv257, ptr %slot32, align 8
  %v258 = load i64, ptr %slot32, align 8
  %cond259 = icmp ne i64 %v258, 0
  br i1 %cond259, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v260 = load i64, ptr %slot1, align 8
  %p261 = inttoptr i64 %v260 to ptr
  call void @myl_qbe_fail_frame(ptr %p261) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v262 = load i64, ptr %slot2, align 8
  %v263 = load i64, ptr %slot19, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 %v262, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot1, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %call267 = call ptr @myl_qbe_heap(ptr %p266) nomerge, !dbg !112
  %calladdr268 = ptrtoint ptr %call267 to i64
  store i64 %calladdr268, ptr %slot33, align 8
  %v269 = load i64, ptr %slot1, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %call271 = call i64 @myl_qbe_region_mark(ptr %p270) nomerge, !dbg !112
  store i64 %call271, ptr %slot34, align 8
  %v272 = load i64, ptr %slot5, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i32 0, ptr %p273, align 4, !alias.scope !3, !noalias !4
  %v274 = load i64, ptr %slot6, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i32 0, ptr %p275, align 4, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot7, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i32 0, ptr %p277, align 4, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot8, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i32 0, ptr %p279, align 4, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot9, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i32 0, ptr %p281, align 4, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot10, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i32 0, ptr %p283, align 4, !alias.scope !3, !noalias !4
  %v284 = load i64, ptr %slot11, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i32 0, ptr %p285, align 4, !alias.scope !3, !noalias !4
  %v286 = load i64, ptr %slot12, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i32 0, ptr %p287, align 4, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot13, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i32 0, ptr %p289, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v290 = load i64, ptr %slot19, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot35, align 8
  %v293 = load i64, ptr %slot35, align 8
  %v294 = load i64, ptr %slot21, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot21, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot36, align 8
  %v299 = load i64, ptr %slot1, align 8
  %v300 = load i64, ptr %slot36, align 8
  %call301 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v299, i64 %v300) nomerge, !dbg !114
  store { i64, i64 } %call301, ptr %callresult38, align 8
  %addr302 = ptrtoint ptr %callresult38 to i64
  store i64 %addr302, ptr %slot37, align 8
  %v303 = load i64, ptr %slot37, align 8
  %v304 = load i64, ptr %slot21, align 8
  %p305 = inttoptr i64 %v304 to ptr
  store i64 %v303, ptr %p305, align 8, !alias.scope !3, !noalias !4
  %v306 = load i64, ptr %slot5, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i32, ptr %p307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld308, ptr %slot39, align 8
  %v309 = load i32, ptr %slot39, align 8
  %cv310 = zext i32 %v309 to i64
  %cond311 = icmp ne i64 %cv310, 0
  br i1 %cond311, label %bb_rcslotdrop13, label %bb_rcslotdone13
bb_rcslotdrop13:
  %v312 = load i64, ptr %slot5, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i32 0, ptr %p313, align 4, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot14, align 8
  store i64 %v314, ptr %slot40, align 8
  %v315 = load i64, ptr %slot6, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i32, ptr %p316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld317, ptr %slot41, align 8
  %v318 = load i32, ptr %slot41, align 8
  %op319 = and i32 %v318, 28
  store i32 %op319, ptr %slot42, align 8
  %v320 = load i32, ptr %slot42, align 8
  %cv321 = zext i32 %v320 to i64
  %cond322 = icmp ne i64 %cv321, 0
  br i1 %cond322, label %bb_rcslotrole13, label %bb_rcslotowner13
bb_rcslotrole13:
  %v323 = load i64, ptr %slot33, align 8
  store i64 %v323, ptr %slot43, align 8
  %v324 = load i64, ptr %slot43, align 8
  %v325 = load i64, ptr %slot40, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v324, i64 %v325) nomerge, !dbg !114
  br label %bb_rcslotdone13
bb_rcslotowner13:
  %v326 = load i64, ptr %slot33, align 8
  store i64 %v326, ptr %slot44, align 8
  %v327 = load i64, ptr %slot44, align 8
  %v328 = load i64, ptr %slot40, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v327, i64 %v328) nomerge, !dbg !114
  br label %bb_rcslotdone13
bb_rcslotdone13:
  %v329 = load i64, ptr %slot21, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot45, align 8
  %v332 = load i64, ptr %slot45, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i32, ptr %p333, align 4
  %ext335 = zext i32 %ld334 to i64
  store i64 %ext335, ptr %slot46, align 8
  %v336 = load i64, ptr %slot46, align 8
  %cmp337 = icmp eq i64 %v336, 0
  %cv338 = zext i1 %cmp337 to i64
  store i64 %cv338, ptr %slot47, align 8
  %v339 = load i64, ptr %slot47, align 8
  %cond340 = icmp ne i64 %v339, 0
  br i1 %cond340, label %bb_rctryok21, label %bb_rctryerror21
bb_rctryerror21:
  %p341 = inttoptr i64 ptrtoint (ptr @myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p341, i64 12884901890) "call-inline-cost"="0", !dbg !116
  %v342 = load i64, ptr %slot45, align 8
  %op343 = add i64 %v342, 8
  store i64 %op343, ptr %slot48, align 8
  %v344 = load i64, ptr %slot24, align 8
  store i64 %v344, ptr %slot49, align 8
  %v345 = load i64, ptr %slot49, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i64 0, ptr %p346, align 8, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot49, align 8
  %p349 = inttoptr i64 %v347 to ptr
  %gep350 = getelementptr i8, ptr %p349, i64 8
  %op348 = ptrtoint ptr %gep350 to i64
  store i64 %op348, ptr %slot50, align 8
  %v351 = load i64, ptr %slot50, align 8
  %p352 = inttoptr i64 %v351 to ptr
  store i64 0, ptr %p352, align 8, !alias.scope !3, !noalias !4
  %v353 = load i64, ptr %slot49, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i32 1, ptr %p354, align 4, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot49, align 8
  %p357 = inttoptr i64 %v355 to ptr
  %gep358 = getelementptr i8, ptr %p357, i64 8
  %op356 = ptrtoint ptr %gep358 to i64
  store i64 %op356, ptr %slot51, align 8
  %v359 = load i64, ptr %slot13, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i32 1, ptr %p360, align 4, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot34, align 8
  store i64 %v361, ptr %slot52, align 8
  %v362 = load i64, ptr %slot49, align 8
  %v363 = load i64, ptr %slot21, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rctryok21:
  %v365 = load i64, ptr %slot24, align 8
  store i64 %v365, ptr %slot53, align 8
  %v366 = load i64, ptr %slot53, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 0, ptr %p367, align 8, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot13, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 1, ptr %p369, align 4, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot45, align 8
  %op371 = add i64 %v370, 8
  store i64 %op371, ptr %slot54, align 8
  %v372 = load i64, ptr %slot34, align 8
  store i64 %v372, ptr %slot55, align 8
  %v373 = load i64, ptr %slot54, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i64, ptr %p374, align 8
  store i64 %ld375, ptr %slot56, align 8
  %v376 = load i64, ptr %slot56, align 8
  %v377 = load i64, ptr %slot53, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 %v376, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot53, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot57, align 8
  %v382 = load i64, ptr %slot57, align 8
  %v383 = load i64, ptr %slot21, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i64 %v382, ptr %p384, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i4:
  %v385 = load i64, ptr %slot21, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i64, ptr %p386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld387, ptr %slot58, align 8
  %v388 = load i64, ptr %slot5, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i32, ptr %p389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld390, ptr %slot59, align 8
  %v391 = load i32, ptr %slot59, align 8
  %cv392 = zext i32 %v391 to i64
  %cond393 = icmp ne i64 %cv392, 0
  br i1 %cond393, label %bb_rcslotdrop40, label %bb_rcslotdone40
bb_rcslotdrop40:
  %v394 = load i64, ptr %slot5, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i32 0, ptr %p395, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone40
bb_rcslotdone40:
  %v396 = load i64, ptr %slot58, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ret398 = load { i64, i64 }, ptr %p397, align 8
  ret { i64, i64 } %ret398
bb_i5:
  %v399 = load i64, ptr %slot21, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld401, ptr %slot60, align 8
  %v402 = load i64, ptr %slot60, align 8
  %v403 = load i64, ptr %slot20, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot19, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot61, align 8
  %v408 = load i64, ptr %slot61, align 8
  %v409 = load i64, ptr %slot21, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i64 %v408, ptr %p410, align 8, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot25, align 8
  store i64 %v411, ptr %slot62, align 8
  %v412 = load i64, ptr %slot62, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i32 0, ptr %p413, align 4, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot62, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i32 8, ptr %p415, align 4, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot62, align 8
  %v417 = load i64, ptr %slot22, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i64 %v416, ptr %p418, align 8, !alias.scope !3, !noalias !4
  %p419 = inttoptr i64 ptrtoint (ptr @myl_lit_1d7b28d542275a21ffb926802019519fec7fb59c7843e7a7cdd715c413b30ef4 to i64) to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !4, !noalias !3
  store i64 %ld420, ptr %slot63, align 8
  %v421 = load i64, ptr %slot63, align 8
  %v422 = load i64, ptr %slot23, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot23, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot64, align 8
  %v427 = load i64, ptr %slot64, align 8
  %v428 = load i64, ptr %slot17, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot17, align 8
  store i64 %v430, ptr %slot65, align 8
  %v431 = load i64, ptr %slot18, align 8
  store i64 %v431, ptr %slot66, align 8
  %v432 = load i64, ptr %slot65, align 8
  %v433 = load i64, ptr %slot66, align 8
  %p434 = inttoptr i64 %v432 to ptr
  %p435 = inttoptr i64 %v433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p435, ptr %p434, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot12, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i32 2, ptr %p437, align 4, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot11, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i32 1, ptr %p439, align 4, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot16, align 8
  store i64 %v440, ptr %slot67, align 8
  %v441 = load i64, ptr %slot18, align 8
  store i64 %v441, ptr %slot68, align 8
  %v442 = load i64, ptr %slot68, align 8
  %v443 = load i64, ptr %slot67, align 8
  %p444 = inttoptr i64 %v442 to ptr
  %p445 = inttoptr i64 %v443 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p445, ptr %p444, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot10, align 8
  %p447 = inttoptr i64 %v446 to ptr
  store i32 2, ptr %p447, align 4, !alias.scope !3, !noalias !4
  %v448 = load i64, ptr %slot12, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %ld450 = load i32, ptr %p449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld450, ptr %slot69, align 8
  %v451 = load i32, ptr %slot69, align 8
  %v452 = load i64, ptr %slot10, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i32 %v451, ptr %p453, align 4, !alias.scope !3, !noalias !4
  %v454 = load i64, ptr %slot11, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i32 0, ptr %p455, align 4, !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot9, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i32 1, ptr %p457, align 4, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot67, align 8
  %p459 = inttoptr i64 %v458 to ptr
  %ld460 = load i64, ptr %p459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld460, ptr %slot70, align 8
  %v461 = load i64, ptr %slot70, align 8
  %v462 = load i64, ptr %slot23, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i64 %v461, ptr %p463, align 8, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot21, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot71, align 8
  %v467 = load i64, ptr %slot22, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %ld469 = load i64, ptr %p468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld469, ptr %slot72, align 8
  %v470 = load i64, ptr %slot23, align 8
  %p471 = inttoptr i64 %v470 to ptr
  %ld472 = load i64, ptr %p471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld472, ptr %slot73, align 8
  %v473 = load i64, ptr %slot1, align 8
  %v474 = load i64, ptr %slot71, align 8
  %v475 = load i64, ptr %slot72, align 8
  %v476 = load i64, ptr %slot73, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult75, i64 %v473, i64 %v474, i64 %v475, i64 %v476) nomerge, !dbg !118
  %addr477 = ptrtoint ptr %callresult75 to i64
  store i64 %addr477, ptr %slot74, align 8
  %v478 = load i64, ptr %slot74, align 8
  %v479 = load i64, ptr %slot21, align 8
  %p480 = inttoptr i64 %v479 to ptr
  store i64 %v478, ptr %p480, align 8, !alias.scope !3, !noalias !4
  %v481 = load i64, ptr %slot21, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ld483 = load i64, ptr %p482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld483, ptr %slot76, align 8
  %v484 = load i64, ptr %slot18, align 8
  store i64 %v484, ptr %slot77, align 8
  %v485 = load i64, ptr %slot76, align 8
  %v486 = load i64, ptr %slot77, align 8
  %p487 = inttoptr i64 %v485 to ptr
  %p488 = inttoptr i64 %v486 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p488, ptr %p487, i64 48, i1 false)
  %v489 = load i64, ptr %slot12, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i32 2, ptr %p490, align 4, !alias.scope !3, !noalias !4
  %v491 = load i64, ptr %slot11, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 1, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot5, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i32, ptr %p494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld495, ptr %slot78, align 8
  %v496 = load i32, ptr %slot78, align 8
  %cv497 = zext i32 %v496 to i64
  %cond498 = icmp ne i64 %cv497, 0
  br i1 %cond498, label %bb_rcslotdrop79, label %bb_rcslotdone79
bb_rcslotdrop79:
  %v499 = load i64, ptr %slot5, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i32 0, ptr %p500, align 4, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot14, align 8
  store i64 %v501, ptr %slot79, align 8
  %v502 = load i64, ptr %slot6, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i32, ptr %p503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld504, ptr %slot80, align 8
  %v505 = load i32, ptr %slot80, align 8
  %op506 = and i32 %v505, 28
  store i32 %op506, ptr %slot81, align 8
  %v507 = load i32, ptr %slot81, align 8
  %cv508 = zext i32 %v507 to i64
  %cond509 = icmp ne i64 %cv508, 0
  br i1 %cond509, label %bb_rcslotrole79, label %bb_rcslotowner79
bb_rcslotrole79:
  %v510 = load i64, ptr %slot33, align 8
  store i64 %v510, ptr %slot82, align 8
  %v511 = load i64, ptr %slot82, align 8
  %v512 = load i64, ptr %slot79, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v511, i64 %v512) nomerge, !dbg !118
  br label %bb_rcslotdone79
bb_rcslotowner79:
  %v513 = load i64, ptr %slot33, align 8
  store i64 %v513, ptr %slot83, align 8
  %v514 = load i64, ptr %slot83, align 8
  %v515 = load i64, ptr %slot79, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v514, i64 %v515) nomerge, !dbg !118
  br label %bb_rcslotdone79
bb_rcslotdone79:
  %v516 = load i64, ptr %slot9, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i32, ptr %p517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld518, ptr %slot84, align 8
  %v519 = load i32, ptr %slot84, align 8
  %cv520 = zext i32 %v519 to i64
  %cond521 = icmp ne i64 %cv520, 0
  br i1 %cond521, label %bb_rcslotdrop88, label %bb_rcslotdone88
bb_rcslotdrop88:
  %v522 = load i64, ptr %slot9, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 0, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot16, align 8
  store i64 %v524, ptr %slot85, align 8
  %v525 = load i64, ptr %slot10, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i32, ptr %p526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld527, ptr %slot86, align 8
  %v528 = load i32, ptr %slot86, align 8
  %op529 = and i32 %v528, 28
  store i32 %op529, ptr %slot87, align 8
  %v530 = load i32, ptr %slot87, align 8
  %cv531 = zext i32 %v530 to i64
  %cond532 = icmp ne i64 %cv531, 0
  br i1 %cond532, label %bb_rcslotrole88, label %bb_rcslotowner88
bb_rcslotrole88:
  %v533 = load i64, ptr %slot33, align 8
  store i64 %v533, ptr %slot88, align 8
  %v534 = load i64, ptr %slot85, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot89, align 8
  %v537 = load i64, ptr %slot89, align 8
  %cmp538 = icmp ne i64 %v537, 0
  %cv539 = zext i1 %cmp538 to i32
  store i32 %cv539, ptr %slot90, align 8
  %v540 = load i32, ptr %slot90, align 8
  %cv541 = zext i32 %v540 to i64
  %cond542 = icmp ne i64 %cv541, 0
  br i1 %cond542, label %bb_rcgnn104, label %bb_rcgdone104
bb_rcgnn104:
  %v543 = load i64, ptr %slot89, align 8
  %op544 = sub i64 %v543, 16
  store i64 %op544, ptr %slot91, align 8
  %v545 = load i64, ptr %slot89, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %rgep547 = getelementptr i8, ptr %p546, i64 -16
  %ld548 = load i64, ptr %rgep547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld548, ptr %slot92, align 8
  %v549 = load i64, ptr %slot92, align 8
  %op550 = and i64 %v549, 4611686018427387906
  store i64 %op550, ptr %slot93, align 8
  %v551 = load i64, ptr %slot93, align 8
  %cmp552 = icmp ne i64 %v551, 0
  %cv553 = zext i1 %cmp552 to i32
  store i32 %cv553, ptr %slot94, align 8
  %v554 = load i32, ptr %slot94, align 8
  %cv555 = zext i32 %v554 to i64
  %cond556 = icmp ne i64 %cv555, 0
  br i1 %cond556, label %bb_rcgclear104, label %bb_rcgcounted104
bb_rcgcounted104:
  %v557 = load i64, ptr %slot89, align 8
  %op558 = sub i64 %v557, 24
  store i64 %op558, ptr %slot95, align 8
  %v559 = load i64, ptr %slot89, align 8
  %p560 = inttoptr i64 %v559 to ptr
  %rgep561 = getelementptr i8, ptr %p560, i64 -24
  %ld562 = load i64, ptr %rgep561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld562, ptr %slot96, align 8
  %v563 = load i64, ptr %slot96, align 8
  %op564 = sub i64 %v563, 1
  store i64 %op564, ptr %slot97, align 8
  %v565 = load i64, ptr %slot97, align 8
  %cmp566 = icmp eq i64 %v565, 0
  %cv567 = zext i1 %cmp566 to i32
  store i32 %cv567, ptr %slot98, align 8
  %v568 = load i32, ptr %slot98, align 8
  %cv569 = zext i32 %v568 to i64
  %cond570 = icmp ne i64 %cv569, 0
  br i1 %cond570, label %bb_rcglast104, label %bb_rcgdec104
bb_rcglast104:
  %v571 = load i64, ptr %slot89, align 8
  %op572 = sub i64 %v571, 32
  store i64 %op572, ptr %slot99, align 8
  %v573 = load i64, ptr %slot89, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %rgep575 = getelementptr i8, ptr %p574, i64 -32
  %ld576 = load i64, ptr %rgep575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld576, ptr %slot100, align 8
  %v577 = load i64, ptr %slot100, align 8
  %cmp578 = icmp ne i64 %v577, 0
  %cv579 = zext i1 %cmp578 to i32
  store i32 %cv579, ptr %slot101, align 8
  %v580 = load i32, ptr %slot101, align 8
  %cv581 = zext i32 %v580 to i64
  %cond582 = icmp ne i64 %cv581, 0
  br i1 %cond582, label %bb_rcgdec104, label %bb_rcgslow104
bb_rcgslow104:
  %v583 = load i64, ptr %slot88, align 8
  %v584 = load i64, ptr %slot85, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v583, i64 %v584) nomerge, !dbg !118
  br label %bb_rcgdone104
bb_rcgdec104:
  %v585 = load i64, ptr %slot97, align 8
  %v586 = load i64, ptr %slot89, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %rgep588 = getelementptr i8, ptr %p587, i64 -24
  store i64 %v585, ptr %rgep588, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear104
bb_rcgclear104:
  %v589 = load i64, ptr %slot85, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 0, ptr %p590, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone104
bb_rcgdone104:
  br label %bb_rcslotdone88
bb_rcslotowner88:
  %v591 = load i64, ptr %slot33, align 8
  store i64 %v591, ptr %slot102, align 8
  %v592 = load i64, ptr %slot85, align 8
  %p593 = inttoptr i64 %v592 to ptr
  %ld594 = load i64, ptr %p593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld594, ptr %slot103, align 8
  %v595 = load i64, ptr %slot103, align 8
  %cmp596 = icmp ne i64 %v595, 0
  %cv597 = zext i1 %cmp596 to i32
  store i32 %cv597, ptr %slot104, align 8
  %v598 = load i32, ptr %slot104, align 8
  %cv599 = zext i32 %v598 to i64
  %cond600 = icmp ne i64 %cv599, 0
  br i1 %cond600, label %bb_rcgnn119, label %bb_rcgdone119
bb_rcgnn119:
  %v601 = load i64, ptr %slot103, align 8
  %op602 = sub i64 %v601, 16
  store i64 %op602, ptr %slot105, align 8
  %v603 = load i64, ptr %slot103, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %rgep605 = getelementptr i8, ptr %p604, i64 -16
  %ld606 = load i64, ptr %rgep605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld606, ptr %slot106, align 8
  %v607 = load i64, ptr %slot106, align 8
  %op608 = and i64 %v607, 4611686018427387906
  store i64 %op608, ptr %slot107, align 8
  %v609 = load i64, ptr %slot107, align 8
  %cmp610 = icmp ne i64 %v609, 0
  %cv611 = zext i1 %cmp610 to i32
  store i32 %cv611, ptr %slot108, align 8
  %v612 = load i32, ptr %slot108, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcgclear119, label %bb_rcgcounted119
bb_rcgcounted119:
  %v615 = load i64, ptr %slot103, align 8
  %op616 = sub i64 %v615, 32
  store i64 %op616, ptr %slot109, align 8
  %v617 = load i64, ptr %slot103, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %rgep619 = getelementptr i8, ptr %p618, i64 -32
  %ld620 = load i64, ptr %rgep619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld620, ptr %slot110, align 8
  %v621 = load i64, ptr %slot110, align 8
  %op622 = sub i64 %v621, 1
  store i64 %op622, ptr %slot111, align 8
  %v623 = load i64, ptr %slot111, align 8
  %cmp624 = icmp eq i64 %v623, 0
  %cv625 = zext i1 %cmp624 to i32
  store i32 %cv625, ptr %slot112, align 8
  %v626 = load i32, ptr %slot112, align 8
  %cv627 = zext i32 %v626 to i64
  %cond628 = icmp ne i64 %cv627, 0
  br i1 %cond628, label %bb_rcglast119, label %bb_rcgdec119
bb_rcglast119:
  %v629 = load i64, ptr %slot103, align 8
  %op630 = sub i64 %v629, 24
  store i64 %op630, ptr %slot113, align 8
  %v631 = load i64, ptr %slot103, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %rgep633 = getelementptr i8, ptr %p632, i64 -24
  %ld634 = load i64, ptr %rgep633, align 8, !alias.scope !9, !noalias !10
  store i64 %ld634, ptr %slot114, align 8
  %v635 = load i64, ptr %slot114, align 8
  %cmp636 = icmp ne i64 %v635, 0
  %cv637 = zext i1 %cmp636 to i32
  store i32 %cv637, ptr %slot115, align 8
  %v638 = load i32, ptr %slot115, align 8
  %cv639 = zext i32 %v638 to i64
  %cond640 = icmp ne i64 %cv639, 0
  br i1 %cond640, label %bb_rcgdec119, label %bb_rcgslow119
bb_rcgslow119:
  %v641 = load i64, ptr %slot102, align 8
  %v642 = load i64, ptr %slot85, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v641, i64 %v642) nomerge, !dbg !118
  br label %bb_rcgdone119
bb_rcgdec119:
  %v643 = load i64, ptr %slot111, align 8
  %v644 = load i64, ptr %slot103, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %rgep646 = getelementptr i8, ptr %p645, i64 -32
  store i64 %v643, ptr %rgep646, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear119
bb_rcgclear119:
  %v647 = load i64, ptr %slot85, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i64 0, ptr %p648, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone119
bb_rcgdone119:
  br label %bb_rcslotdone88
bb_rcslotdone88:
  %v649 = load i64, ptr %slot14, align 8
  store i64 %v649, ptr %slot116, align 8
  %v650 = load i64, ptr %slot18, align 8
  store i64 %v650, ptr %slot117, align 8
  %v651 = load i64, ptr %slot117, align 8
  %v652 = load i64, ptr %slot116, align 8
  %p653 = inttoptr i64 %v651 to ptr
  %p654 = inttoptr i64 %v652 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p654, ptr %p653, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot6, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i32 2, ptr %p656, align 4, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot12, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i32, ptr %p658, align 4, !alias.scope !3, !noalias !4
  store i32 %ld659, ptr %slot118, align 8
  %v660 = load i32, ptr %slot118, align 8
  %v661 = load i64, ptr %slot6, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i32 %v660, ptr %p662, align 4, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot11, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 0, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot5, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 1, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot116, align 8
  %v668 = load i64, ptr %slot21, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 %v667, ptr %p669, align 8, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot21, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot119, align 8
  %v673 = load i64, ptr %slot119, align 8
  %p674 = inttoptr i64 %v673 to ptr
  %ld675 = load i32, ptr %p674, align 4
  %ext676 = zext i32 %ld675 to i64
  store i64 %ext676, ptr %slot120, align 8
  %v677 = load i64, ptr %slot120, align 8
  %cmp678 = icmp eq i64 %v677, 0
  %cv679 = zext i1 %cmp678 to i64
  store i64 %cv679, ptr %slot121, align 8
  %v680 = load i64, ptr %slot121, align 8
  %cond681 = icmp ne i64 %v680, 0
  br i1 %cond681, label %bb_rctryok132, label %bb_rctryerror132
bb_rctryerror132:
  %p682 = inttoptr i64 ptrtoint (ptr @myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p682, i64 12884901898) "call-inline-cost"="0", !dbg !120
  %v683 = load i64, ptr %slot119, align 8
  %op684 = add i64 %v683, 8
  store i64 %op684, ptr %slot122, align 8
  %v685 = load i64, ptr %slot26, align 8
  store i64 %v685, ptr %slot123, align 8
  %v686 = load i64, ptr %slot123, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 0, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot123, align 8
  %p690 = inttoptr i64 %v688 to ptr
  %gep691 = getelementptr i8, ptr %p690, i64 8
  %op689 = ptrtoint ptr %gep691 to i64
  store i64 %op689, ptr %slot124, align 8
  %v692 = load i64, ptr %slot124, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 0, ptr %p693, align 8, !alias.scope !3, !noalias !4
  %v694 = load i64, ptr %slot123, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i32 1, ptr %p695, align 4, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot123, align 8
  %p698 = inttoptr i64 %v696 to ptr
  %gep699 = getelementptr i8, ptr %p698, i64 8
  %op697 = ptrtoint ptr %gep699 to i64
  store i64 %op697, ptr %slot125, align 8
  %v700 = load i64, ptr %slot13, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i32 1, ptr %p701, align 4, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot34, align 8
  store i64 %v702, ptr %slot126, align 8
  %v703 = load i64, ptr %slot123, align 8
  %v704 = load i64, ptr %slot21, align 8
  %p705 = inttoptr i64 %v704 to ptr
  store i64 %v703, ptr %p705, align 8, !alias.scope !3, !noalias !4
  %v706 = load i64, ptr %slot5, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ld708 = load i32, ptr %p707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld708, ptr %slot127, align 8
  %v709 = load i32, ptr %slot127, align 8
  %cv710 = zext i32 %v709 to i64
  %cond711 = icmp ne i64 %cv710, 0
  br i1 %cond711, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v712 = load i64, ptr %slot5, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i32 0, ptr %p713, align 4, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot14, align 8
  store i64 %v714, ptr %slot128, align 8
  %v715 = load i64, ptr %slot6, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i32, ptr %p716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld717, ptr %slot129, align 8
  %v718 = load i32, ptr %slot129, align 8
  %op719 = and i32 %v718, 28
  store i32 %op719, ptr %slot130, align 8
  %v720 = load i32, ptr %slot130, align 8
  %cv721 = zext i32 %v720 to i64
  %cond722 = icmp ne i64 %cv721, 0
  br i1 %cond722, label %bb_rcslotrole143, label %bb_rcslotowner143
bb_rcslotrole143:
  %v723 = load i64, ptr %slot33, align 8
  store i64 %v723, ptr %slot131, align 8
  %v724 = load i64, ptr %slot131, align 8
  %v725 = load i64, ptr %slot128, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v724, i64 %v725) nomerge, !dbg !120
  br label %bb_rcslotdone143
bb_rcslotowner143:
  %v726 = load i64, ptr %slot33, align 8
  store i64 %v726, ptr %slot132, align 8
  %v727 = load i64, ptr %slot132, align 8
  %v728 = load i64, ptr %slot128, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v727, i64 %v728) nomerge, !dbg !120
  br label %bb_rcslotdone143
bb_rcslotdone143:
  br label %bb_i12
bb_rctryok132:
  %v729 = load i64, ptr %slot26, align 8
  store i64 %v729, ptr %slot133, align 8
  %v730 = load i64, ptr %slot133, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i64 0, ptr %p731, align 8, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot133, align 8
  %p734 = inttoptr i64 %v732 to ptr
  %gep735 = getelementptr i8, ptr %p734, i64 8
  %op733 = ptrtoint ptr %gep735 to i64
  store i64 %op733, ptr %slot134, align 8
  %v736 = load i64, ptr %slot134, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i64 0, ptr %p737, align 8, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot133, align 8
  %p740 = inttoptr i64 %v738 to ptr
  %gep741 = getelementptr i8, ptr %p740, i64 16
  %op739 = ptrtoint ptr %gep741 to i64
  store i64 %op739, ptr %slot135, align 8
  %v742 = load i64, ptr %slot135, align 8
  %p743 = inttoptr i64 %v742 to ptr
  store i64 0, ptr %p743, align 8, !alias.scope !3, !noalias !4
  %v744 = load i64, ptr %slot133, align 8
  %p746 = inttoptr i64 %v744 to ptr
  %gep747 = getelementptr i8, ptr %p746, i64 24
  %op745 = ptrtoint ptr %gep747 to i64
  store i64 %op745, ptr %slot136, align 8
  %v748 = load i64, ptr %slot136, align 8
  %p749 = inttoptr i64 %v748 to ptr
  store i64 0, ptr %p749, align 8, !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot133, align 8
  %p752 = inttoptr i64 %v750 to ptr
  %gep753 = getelementptr i8, ptr %p752, i64 32
  %op751 = ptrtoint ptr %gep753 to i64
  store i64 %op751, ptr %slot137, align 8
  %v754 = load i64, ptr %slot137, align 8
  %p755 = inttoptr i64 %v754 to ptr
  store i64 0, ptr %p755, align 8, !alias.scope !3, !noalias !4
  %v756 = load i64, ptr %slot13, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i32 1, ptr %p757, align 4, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot119, align 8
  %op759 = add i64 %v758, 8
  store i64 %op759, ptr %slot138, align 8
  %v760 = load i64, ptr %slot34, align 8
  store i64 %v760, ptr %slot139, align 8
  %v761 = load i64, ptr %slot33, align 8
  %v762 = load i64, ptr %slot133, align 8
  %v763 = load i64, ptr %slot138, align 8
  %v764 = load i64, ptr %slot139, align 8
  %cv765 = trunc i64 %v764 to i32
  %call766 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v761, i64 %v762, i64 %v763, i32 %cv765) nomerge, !dbg !120
  store i32 %call766, ptr %slot140, align 8
  %v767 = load i32, ptr %slot140, align 8
  %cv768 = zext i32 %v767 to i64
  %cond769 = icmp ne i64 %cv768, 0
  br i1 %cond769, label %bb_rcsuccess160, label %bb_rcfailure160
bb_rcfailure160:
  %v770 = load i64, ptr %slot33, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %call772 = call i32 @myl_rc_take_failure(ptr %p771) nomerge, !dbg !120
  store i32 %call772, ptr %slot141, align 8
  %v773 = load i64, ptr %slot1, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %v775 = load i32, ptr %slot141, align 8
  %call776 = call i32 @myl_qbe_rc_status(ptr %p774, i32 %v775) nomerge, !dbg !120
  store i32 %call776, ptr %slot142, align 8
  br label %bb_failure
bb_rcsuccess160:
  %v777 = load i64, ptr %slot133, align 8
  %v778 = load i64, ptr %slot21, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i64 %v777, ptr %p779, align 8, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot21, align 8
  %p781 = inttoptr i64 %v780 to ptr
  %ld782 = load i64, ptr %p781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld782, ptr %slot143, align 8
  %v783 = load i64, ptr %slot18, align 8
  store i64 %v783, ptr %slot144, align 8
  %v784 = load i64, ptr %slot143, align 8
  %v785 = load i64, ptr %slot144, align 8
  %p786 = inttoptr i64 %v784 to ptr
  %p787 = inttoptr i64 %v785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p787, ptr %p786, i64 40, i1 false)
  %v788 = load i64, ptr %slot12, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 2, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot11, align 8
  %p791 = inttoptr i64 %v790 to ptr
  store i32 1, ptr %p791, align 4, !alias.scope !3, !noalias !4
  %v792 = load i64, ptr %slot5, align 8
  %p793 = inttoptr i64 %v792 to ptr
  %ld794 = load i32, ptr %p793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld794, ptr %slot145, align 8
  %v795 = load i32, ptr %slot145, align 8
  %cv796 = zext i32 %v795 to i64
  %cond797 = icmp ne i64 %cv796, 0
  br i1 %cond797, label %bb_rcslotdrop169, label %bb_rcslotdone169
bb_rcslotdrop169:
  %v798 = load i64, ptr %slot5, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i32 0, ptr %p799, align 4, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot14, align 8
  store i64 %v800, ptr %slot146, align 8
  %v801 = load i64, ptr %slot6, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %ld803 = load i32, ptr %p802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld803, ptr %slot147, align 8
  %v804 = load i32, ptr %slot147, align 8
  %op805 = and i32 %v804, 28
  store i32 %op805, ptr %slot148, align 8
  %v806 = load i32, ptr %slot148, align 8
  %cv807 = zext i32 %v806 to i64
  %cond808 = icmp ne i64 %cv807, 0
  br i1 %cond808, label %bb_rcslotrole169, label %bb_rcslotowner169
bb_rcslotrole169:
  %v809 = load i64, ptr %slot33, align 8
  store i64 %v809, ptr %slot149, align 8
  %v810 = load i64, ptr %slot149, align 8
  %v811 = load i64, ptr %slot146, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v810, i64 %v811) nomerge, !dbg !120
  br label %bb_rcslotdone169
bb_rcslotowner169:
  %v812 = load i64, ptr %slot33, align 8
  store i64 %v812, ptr %slot150, align 8
  %v813 = load i64, ptr %slot150, align 8
  %v814 = load i64, ptr %slot146, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v813, i64 %v814) nomerge, !dbg !120
  br label %bb_rcslotdone169
bb_rcslotdone169:
  %v815 = load i64, ptr %slot14, align 8
  store i64 %v815, ptr %slot151, align 8
  %v816 = load i64, ptr %slot18, align 8
  store i64 %v816, ptr %slot152, align 8
  %v817 = load i64, ptr %slot152, align 8
  %v818 = load i64, ptr %slot151, align 8
  %p819 = inttoptr i64 %v817 to ptr
  %p820 = inttoptr i64 %v818 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p820, ptr %p819, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot6, align 8
  %p822 = inttoptr i64 %v821 to ptr
  store i32 2, ptr %p822, align 4, !alias.scope !3, !noalias !4
  %v823 = load i64, ptr %slot12, align 8
  %p824 = inttoptr i64 %v823 to ptr
  %ld825 = load i32, ptr %p824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld825, ptr %slot153, align 8
  %v826 = load i32, ptr %slot153, align 8
  %v827 = load i64, ptr %slot6, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 %v826, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot11, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 0, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot5, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i32 1, ptr %p832, align 4, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot151, align 8
  %v834 = load i64, ptr %slot21, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i64 %v833, ptr %p835, align 8, !alias.scope !3, !noalias !4
  br label %bb_i13
bb_i12:
  %v836 = load i64, ptr %slot21, align 8
  %p837 = inttoptr i64 %v836 to ptr
  %ld838 = load i64, ptr %p837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld838, ptr %slot154, align 8
  %v839 = load i64, ptr %slot5, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i32, ptr %p840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld841, ptr %slot155, align 8
  %v842 = load i32, ptr %slot155, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcslotdrop187, label %bb_rcslotdone187
bb_rcslotdrop187:
  %v845 = load i64, ptr %slot5, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 0, ptr %p846, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone187
bb_rcslotdone187:
  %v847 = load i64, ptr %slot154, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ret849 = load { i64, i64 }, ptr %p848, align 8
  ret { i64, i64 } %ret849
bb_i13:
  %v850 = load i64, ptr %slot5, align 8
  %p851 = inttoptr i64 %v850 to ptr
  %ld852 = load i32, ptr %p851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld852, ptr %slot156, align 8
  %v853 = load i32, ptr %slot156, align 8
  %cv854 = zext i32 %v853 to i64
  %cond855 = icmp ne i64 %cv854, 0
  br i1 %cond855, label %bb_rcslotdrop199, label %bb_rcslotdone199
bb_rcslotdrop199:
  %v856 = load i64, ptr %slot5, align 8
  %p857 = inttoptr i64 %v856 to ptr
  store i32 0, ptr %p857, align 4, !alias.scope !3, !noalias !4
  %v858 = load i64, ptr %slot14, align 8
  store i64 %v858, ptr %slot157, align 8
  %v859 = load i64, ptr %slot6, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i32, ptr %p860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld861, ptr %slot158, align 8
  %v862 = load i32, ptr %slot158, align 8
  %op863 = and i32 %v862, 28
  store i32 %op863, ptr %slot159, align 8
  %v864 = load i32, ptr %slot159, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcslotrole199, label %bb_rcslotowner199
bb_rcslotrole199:
  %v867 = load i64, ptr %slot33, align 8
  store i64 %v867, ptr %slot160, align 8
  %v868 = load i64, ptr %slot160, align 8
  %v869 = load i64, ptr %slot157, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v868, i64 %v869) nomerge, !dbg !122
  br label %bb_rcslotdone199
bb_rcslotowner199:
  %v870 = load i64, ptr %slot33, align 8
  store i64 %v870, ptr %slot161, align 8
  %v871 = load i64, ptr %slot161, align 8
  %v872 = load i64, ptr %slot157, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v871, i64 %v872) nomerge, !dbg !122
  br label %bb_rcslotdone199
bb_rcslotdone199:
  %v873 = load i64, ptr %slot19, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ld875 = load i64, ptr %p874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld875, ptr %slot162, align 8
  %v876 = load i64, ptr %slot162, align 8
  %v877 = load i64, ptr %slot21, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 %v876, ptr %p878, align 8, !alias.scope !3, !noalias !4
  %v879 = load i64, ptr %slot20, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot163, align 8
  %v882 = load i64, ptr %slot163, align 8
  %v883 = load i64, ptr %slot22, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i64 %v882, ptr %p884, align 8, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot27, align 8
  store i64 %v885, ptr %slot164, align 8
  %v886 = load i64, ptr %slot164, align 8
  %p887 = inttoptr i64 %v886 to ptr
  call void @llvm.memset.p0.i64(ptr %p887, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v888 = load i64, ptr %slot164, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i32 2, ptr %p889, align 4, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot13, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 1, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot22, align 8
  store i64 %v892, ptr %slot165, align 8
  %v893 = load i64, ptr %slot164, align 8
  %p895 = inttoptr i64 %v893 to ptr
  %gep896 = getelementptr i8, ptr %p895, i64 8
  %op894 = ptrtoint ptr %gep896 to i64
  store i64 %op894, ptr %slot166, align 8
  %v897 = load i64, ptr %slot34, align 8
  store i64 %v897, ptr %slot167, align 8
  %v898 = load i64, ptr %slot165, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %ld900 = load i64, ptr %p899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld900, ptr %slot168, align 8
  %v901 = load i64, ptr %slot168, align 8
  %v902 = load i64, ptr %slot166, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i64 %v901, ptr %p903, align 8, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot164, align 8
  %v905 = load i64, ptr %slot22, align 8
  %p906 = inttoptr i64 %v905 to ptr
  store i64 %v904, ptr %p906, align 8, !alias.scope !3, !noalias !4
  %v907 = load i64, ptr %slot22, align 8
  %p908 = inttoptr i64 %v907 to ptr
  %ld909 = load i64, ptr %p908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld909, ptr %slot169, align 8
  %v910 = load i64, ptr %slot15, align 8
  store i64 %v910, ptr %slot170, align 8
  %v911 = load i64, ptr %slot169, align 8
  %v912 = load i64, ptr %slot170, align 8
  %p913 = inttoptr i64 %v911 to ptr
  %p914 = inttoptr i64 %v912 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p914, ptr %p913, i64 88, i1 false)
  %v915 = load i64, ptr %slot8, align 8
  %p916 = inttoptr i64 %v915 to ptr
  store i32 2, ptr %p916, align 4, !alias.scope !3, !noalias !4
  %v917 = load i64, ptr %slot7, align 8
  %p918 = inttoptr i64 %v917 to ptr
  store i32 1, ptr %p918, align 4, !alias.scope !3, !noalias !4
  %v919 = load i64, ptr %slot170, align 8
  %v920 = load i64, ptr %slot22, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i64 %v919, ptr %p921, align 8, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot21, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i64, ptr %p923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld924, ptr %slot171, align 8
  %v925 = load i64, ptr %slot22, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ld927 = load i64, ptr %p926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld927, ptr %slot172, align 8
  %v928 = load i64, ptr %slot1, align 8
  %v929 = load i64, ptr %slot171, align 8
  %v930 = load i64, ptr %slot172, align 8
  %call931 = call i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64 %v928, i64 %v929, i64 %v930) nomerge, !dbg !126
  store i64 %call931, ptr %slot173, align 8
  %v932 = load i64, ptr %slot173, align 8
  %v933 = load i64, ptr %slot21, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 %v932, ptr %p934, align 8, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot5, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i32, ptr %p936, align 4, !alias.scope !3, !noalias !4
  store i32 %ld937, ptr %slot174, align 8
  %v938 = load i32, ptr %slot174, align 8
  %cv939 = zext i32 %v938 to i64
  %cond940 = icmp ne i64 %cv939, 0
  br i1 %cond940, label %bb_rcslotdrop224, label %bb_rcslotdone224
bb_rcslotdrop224:
  %v941 = load i64, ptr %slot5, align 8
  %p942 = inttoptr i64 %v941 to ptr
  store i32 0, ptr %p942, align 4, !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot14, align 8
  store i64 %v943, ptr %slot175, align 8
  %v944 = load i64, ptr %slot6, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %ld946 = load i32, ptr %p945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld946, ptr %slot176, align 8
  %v947 = load i32, ptr %slot176, align 8
  %op948 = and i32 %v947, 28
  store i32 %op948, ptr %slot177, align 8
  %v949 = load i32, ptr %slot177, align 8
  %cv950 = zext i32 %v949 to i64
  %cond951 = icmp ne i64 %cv950, 0
  br i1 %cond951, label %bb_rcslotrole224, label %bb_rcslotowner224
bb_rcslotrole224:
  %v952 = load i64, ptr %slot33, align 8
  store i64 %v952, ptr %slot178, align 8
  %v953 = load i64, ptr %slot178, align 8
  %v954 = load i64, ptr %slot175, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v953, i64 %v954) nomerge, !dbg !126
  br label %bb_rcslotdone224
bb_rcslotowner224:
  %v955 = load i64, ptr %slot33, align 8
  store i64 %v955, ptr %slot179, align 8
  %v956 = load i64, ptr %slot179, align 8
  %v957 = load i64, ptr %slot175, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v956, i64 %v957) nomerge, !dbg !126
  br label %bb_rcslotdone224
bb_rcslotdone224:
  %v958 = load i64, ptr %slot7, align 8
  %p959 = inttoptr i64 %v958 to ptr
  %ld960 = load i32, ptr %p959, align 4, !alias.scope !3, !noalias !4
  store i32 %ld960, ptr %slot180, align 8
  %v961 = load i32, ptr %slot180, align 8
  %cv962 = zext i32 %v961 to i64
  %cond963 = icmp ne i64 %cv962, 0
  br i1 %cond963, label %bb_rcslotdrop233, label %bb_rcslotdone233
bb_rcslotdrop233:
  %v964 = load i64, ptr %slot7, align 8
  %p965 = inttoptr i64 %v964 to ptr
  store i32 0, ptr %p965, align 4, !alias.scope !3, !noalias !4
  %v966 = load i64, ptr %slot15, align 8
  store i64 %v966, ptr %slot181, align 8
  %v967 = load i64, ptr %slot8, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %ld969 = load i32, ptr %p968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld969, ptr %slot182, align 8
  %v970 = load i32, ptr %slot182, align 8
  %op971 = and i32 %v970, 28
  store i32 %op971, ptr %slot183, align 8
  %v972 = load i32, ptr %slot183, align 8
  %cv973 = zext i32 %v972 to i64
  %cond974 = icmp ne i64 %cv973, 0
  br i1 %cond974, label %bb_rcslotrole233, label %bb_rcslotowner233
bb_rcslotrole233:
  %v975 = load i64, ptr %slot33, align 8
  store i64 %v975, ptr %slot184, align 8
  %v976 = load i64, ptr %slot184, align 8
  %v977 = load i64, ptr %slot181, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v976, i64 %v977) nomerge, !dbg !126
  br label %bb_rcslotdone233
bb_rcslotowner233:
  %v978 = load i64, ptr %slot33, align 8
  store i64 %v978, ptr %slot185, align 8
  %v979 = load i64, ptr %slot185, align 8
  %v980 = load i64, ptr %slot181, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v979, i64 %v980) nomerge, !dbg !126
  br label %bb_rcslotdone233
bb_rcslotdone233:
  %v981 = load i64, ptr %slot28, align 8
  store i64 %v981, ptr %slot186, align 8
  %v982 = load i64, ptr %slot186, align 8
  %p983 = inttoptr i64 %v982 to ptr
  store i64 0, ptr %p983, align 8, !alias.scope !3, !noalias !4
  %v984 = load i64, ptr %slot186, align 8
  %p986 = inttoptr i64 %v984 to ptr
  %gep987 = getelementptr i8, ptr %p986, i64 8
  %op985 = ptrtoint ptr %gep987 to i64
  store i64 %op985, ptr %slot187, align 8
  %v988 = load i64, ptr %slot187, align 8
  %p989 = inttoptr i64 %v988 to ptr
  store i64 0, ptr %p989, align 8, !alias.scope !3, !noalias !4
  %v990 = load i64, ptr %slot186, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i32 0, ptr %p991, align 4, !alias.scope !3, !noalias !4
  %v992 = load i64, ptr %slot13, align 8
  %p993 = inttoptr i64 %v992 to ptr
  store i32 1, ptr %p993, align 4, !alias.scope !3, !noalias !4
  %v994 = load i64, ptr %slot21, align 8
  store i64 %v994, ptr %slot188, align 8
  %v995 = load i64, ptr %slot186, align 8
  %p997 = inttoptr i64 %v995 to ptr
  %gep998 = getelementptr i8, ptr %p997, i64 8
  %op996 = ptrtoint ptr %gep998 to i64
  store i64 %op996, ptr %slot189, align 8
  %v999 = load i64, ptr %slot34, align 8
  store i64 %v999, ptr %slot190, align 8
  %v1000 = load i64, ptr %slot188, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i64, ptr %p1001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1002, ptr %slot191, align 8
  %v1003 = load i64, ptr %slot191, align 8
  %v1004 = load i64, ptr %slot189, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  store i64 %v1003, ptr %p1005, align 8, !alias.scope !3, !noalias !4
  %v1006 = load i64, ptr %slot186, align 8
  %v1007 = load i64, ptr %slot21, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  store i64 %v1006, ptr %p1008, align 8, !alias.scope !3, !noalias !4
  %v1009 = load i64, ptr %slot21, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %ld1011 = load i64, ptr %p1010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1011, ptr %slot192, align 8
  %v1012 = load i64, ptr %slot5, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %ld1014 = load i32, ptr %p1013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1014, ptr %slot193, align 8
  %v1015 = load i32, ptr %slot193, align 8
  %cv1016 = zext i32 %v1015 to i64
  %cond1017 = icmp ne i64 %cv1016, 0
  br i1 %cond1017, label %bb_rcslotdrop251, label %bb_rcslotdone251
bb_rcslotdrop251:
  %v1018 = load i64, ptr %slot5, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  store i32 0, ptr %p1019, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone251
bb_rcslotdone251:
  %v1020 = load i64, ptr %slot192, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %ret1022 = load { i64, i64 }, ptr %p1021, align 8
  ret { i64, i64 } %ret1022
bb_failure:
  %v1023 = load i64, ptr %slot4, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  call void @llvm.memset.p0.i64(ptr %p1024, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v1025 = load i64, ptr %slot4, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ret1027 = load { i64, i64 }, ptr %p1026, align 8
  ret { i64, i64 } %ret1027
bb_entry_failure:
  %v1028 = load i64, ptr %slot4, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  call void @llvm.memset.p0.i64(ptr %p1029, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v1030 = load i64, ptr %slot4, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  %ret1032 = load { i64, i64 }, ptr %p1031, align 8
  ret { i64, i64 } %ret1032
}

@myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a_meta = external global i8, align 8
@myl_lit_1d7b28d542275a21ffb926802019519fec7fb59c7843e7a7cdd715c413b30ef4 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a", linkageName: "myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14179764312525501535, i64 0, !"myl_f_475fae88fd77d9ba71673aa25a0700dd505f1a5441356532d43fb4664bce8c3a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!120 = !DILocation(line: 11, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!122 = !DILocation(line: 14, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!128 = !DILocation(line: 20, column: 0, scope: !129)
