target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6274f19bfab332ff9f87906b74a57c16f50224bbc9c175562082f2250f3526bb(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v71 = load i64, ptr %slot1, align 8
  %op72 = add i64 %v71, 32
  store i64 %op72, ptr %slot3, align 8
  %mem73 = alloca i8, i64 8, align 8
  %ptr74 = ptrtoint ptr %mem73 to i64
  store i64 %ptr74, ptr %slot4, align 8
  %mem75 = alloca i8, i64 8, align 8
  %ptr76 = ptrtoint ptr %mem75 to i64
  store i64 %ptr76, ptr %slot5, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot6, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot7, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot8, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot9, align 8
  %mem85 = alloca i8, i64 392, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot10, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot11, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot12, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot13, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot14, align 8
  %mem95 = alloca i8, i64 392, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot16, align 8
  %v99 = load i64, ptr %slot1, align 8
  %op100 = add i64 %v99, 64
  store i64 %op100, ptr %slot17, align 8
  %v101 = load i64, ptr %slot17, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !4, !noalias !3
  store i64 %ld103, ptr %slot18, align 8
  %stack104 = call ptr @llvm.stacksave()
  %stackaddr105 = ptrtoint ptr %stack104 to i64
  %v106 = load i64, ptr %slot18, align 8
  %cmp107 = icmp ult i64 %stackaddr105, %v106
  %cv108 = zext i1 %cmp107 to i64
  store i64 %cv108, ptr %slot19, align 8
  %v109 = load i64, ptr %slot19, align 8
  %cond110 = icmp ne i64 %v109, 0
  br i1 %cond110, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v111 = load i64, ptr %slot1, align 8
  %p112 = inttoptr i64 %v111 to ptr
  call void @myl_qbe_fail_frame(ptr %p112) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v113 = load i64, ptr %slot2, align 8
  %v114 = load i64, ptr %slot11, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot1, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %call118 = call ptr @myl_qbe_heap(ptr %p117) nomerge, !dbg !112
  %calladdr119 = ptrtoint ptr %call118 to i64
  store i64 %calladdr119, ptr %slot20, align 8
  %v120 = load i64, ptr %slot4, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i32 0, ptr %p121, align 4, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot5, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i32 0, ptr %p123, align 4, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot6, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i32 0, ptr %p125, align 4, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot7, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i32 0, ptr %p127, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v128 = load i64, ptr %slot11, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot21, align 8
  %v131 = load i64, ptr %slot21, align 8
  %v132 = load i64, ptr %slot12, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot12, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %ld136 = load i64, ptr %p135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld136, ptr %slot22, align 8
  %v137 = load i64, ptr %slot1, align 8
  %v138 = load i64, ptr %slot22, align 8
  %call139 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v137, i64 %v138) nomerge, !dbg !114
  store i64 %call139, ptr %slot23, align 8
  %v140 = load i64, ptr %slot23, align 8
  %v141 = load i64, ptr %slot12, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 %v140, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot11, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot24, align 8
  %v146 = load i64, ptr %slot24, align 8
  %v147 = load i64, ptr %slot12, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i64 %v146, ptr %p148, align 8, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot15, align 8
  store i64 %v149, ptr %slot25, align 8
  %v150 = load i64, ptr %slot25, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i32 0, ptr %p151, align 4, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot25, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i32 1, ptr %p153, align 4, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot25, align 8
  %v155 = load i64, ptr %slot13, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %p157 = inttoptr i64 ptrtoint (ptr @myl_lit_4a567dbed804c7cf92d6eb2154c9ccfecc754c82ed316a70b59da8384d2cb99f to i64) to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !4, !noalias !3
  store i64 %ld158, ptr %slot26, align 8
  %v159 = load i64, ptr %slot26, align 8
  %v160 = load i64, ptr %slot14, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot14, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot27, align 8
  %v165 = load i64, ptr %slot27, align 8
  %v166 = load i64, ptr %slot9, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot9, align 8
  store i64 %v168, ptr %slot28, align 8
  %v169 = load i64, ptr %slot10, align 8
  store i64 %v169, ptr %slot29, align 8
  %v170 = load i64, ptr %slot28, align 8
  %v171 = load i64, ptr %slot29, align 8
  %p172 = inttoptr i64 %v170 to ptr
  %p173 = inttoptr i64 %v171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p173, ptr %p172, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot7, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 2, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot6, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 1, ptr %p177, align 4, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot8, align 8
  store i64 %v178, ptr %slot30, align 8
  %v179 = load i64, ptr %slot10, align 8
  store i64 %v179, ptr %slot31, align 8
  %v180 = load i64, ptr %slot31, align 8
  %v181 = load i64, ptr %slot30, align 8
  %p182 = inttoptr i64 %v180 to ptr
  %p183 = inttoptr i64 %v181 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p183, ptr %p182, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot5, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i32 2, ptr %p185, align 4, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot7, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i32, ptr %p187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld188, ptr %slot32, align 8
  %v189 = load i32, ptr %slot32, align 8
  %v190 = load i64, ptr %slot5, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i32 %v189, ptr %p191, align 4, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot6, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i32 0, ptr %p193, align 4, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot4, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i32 1, ptr %p195, align 4, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot30, align 8
  %p197 = inttoptr i64 %v196 to ptr
  %ld198 = load i64, ptr %p197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld198, ptr %slot33, align 8
  %v199 = load i64, ptr %slot33, align 8
  %v200 = load i64, ptr %slot14, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 %v199, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot12, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot34, align 8
  %v205 = load i64, ptr %slot13, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot35, align 8
  %v208 = load i64, ptr %slot14, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot36, align 8
  %v211 = load i64, ptr %slot1, align 8
  %v212 = load i64, ptr %slot34, align 8
  %v213 = load i64, ptr %slot35, align 8
  %v214 = load i64, ptr %slot36, align 8
  %call215 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v211, i64 %v212, i64 %v213, i64 %v214) nomerge, !dbg !116
  store i64 %call215, ptr %slot37, align 8
  %v216 = load i64, ptr %slot37, align 8
  %v217 = load i64, ptr %slot12, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot4, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i32, ptr %p220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld221, ptr %slot38, align 8
  %v222 = load i32, ptr %slot38, align 8
  %cv223 = zext i32 %v222 to i64
  %cond224 = icmp ne i64 %cv223, 0
  br i1 %cond224, label %bb_rcslotdrop53, label %bb_rcslotdone53
bb_rcslotdrop53:
  %v225 = load i64, ptr %slot4, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i32 0, ptr %p226, align 4, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot8, align 8
  store i64 %v227, ptr %slot39, align 8
  %v228 = load i64, ptr %slot5, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i32, ptr %p229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld230, ptr %slot40, align 8
  %v231 = load i32, ptr %slot40, align 8
  %op232 = and i32 %v231, 28
  store i32 %op232, ptr %slot41, align 8
  %v233 = load i32, ptr %slot41, align 8
  %cv234 = zext i32 %v233 to i64
  %cond235 = icmp ne i64 %cv234, 0
  br i1 %cond235, label %bb_rcslotrole53, label %bb_rcslotowner53
bb_rcslotrole53:
  %v236 = load i64, ptr %slot20, align 8
  store i64 %v236, ptr %slot42, align 8
  %v237 = load i64, ptr %slot39, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot43, align 8
  %v240 = load i64, ptr %slot43, align 8
  %cmp241 = icmp ne i64 %v240, 0
  %cv242 = zext i1 %cmp241 to i32
  store i32 %cv242, ptr %slot44, align 8
  %v243 = load i32, ptr %slot44, align 8
  %cv244 = zext i32 %v243 to i64
  %cond245 = icmp ne i64 %cv244, 0
  br i1 %cond245, label %bb_rcgnn69, label %bb_rcgdone69
bb_rcgnn69:
  %v246 = load i64, ptr %slot43, align 8
  %op247 = sub i64 %v246, 16
  store i64 %op247, ptr %slot45, align 8
  %v248 = load i64, ptr %slot43, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %rgep250 = getelementptr i8, ptr %p249, i64 -16
  %ld251 = load i64, ptr %rgep250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld251, ptr %slot46, align 8
  %v252 = load i64, ptr %slot46, align 8
  %op253 = and i64 %v252, 4611686018427387906
  store i64 %op253, ptr %slot47, align 8
  %v254 = load i64, ptr %slot47, align 8
  %cmp255 = icmp ne i64 %v254, 0
  %cv256 = zext i1 %cmp255 to i32
  store i32 %cv256, ptr %slot48, align 8
  %v257 = load i32, ptr %slot48, align 8
  %cv258 = zext i32 %v257 to i64
  %cond259 = icmp ne i64 %cv258, 0
  br i1 %cond259, label %bb_rcgclear69, label %bb_rcgcounted69
bb_rcgcounted69:
  %v260 = load i64, ptr %slot43, align 8
  %op261 = sub i64 %v260, 24
  store i64 %op261, ptr %slot49, align 8
  %v262 = load i64, ptr %slot43, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %rgep264 = getelementptr i8, ptr %p263, i64 -24
  %ld265 = load i64, ptr %rgep264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld265, ptr %slot50, align 8
  %v266 = load i64, ptr %slot50, align 8
  %op267 = sub i64 %v266, 1
  store i64 %op267, ptr %slot51, align 8
  %v268 = load i64, ptr %slot51, align 8
  %cmp269 = icmp eq i64 %v268, 0
  %cv270 = zext i1 %cmp269 to i32
  store i32 %cv270, ptr %slot52, align 8
  %v271 = load i32, ptr %slot52, align 8
  %cv272 = zext i32 %v271 to i64
  %cond273 = icmp ne i64 %cv272, 0
  br i1 %cond273, label %bb_rcglast69, label %bb_rcgdec69
bb_rcglast69:
  %v274 = load i64, ptr %slot43, align 8
  %op275 = sub i64 %v274, 32
  store i64 %op275, ptr %slot53, align 8
  %v276 = load i64, ptr %slot43, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %rgep278 = getelementptr i8, ptr %p277, i64 -32
  %ld279 = load i64, ptr %rgep278, align 8, !alias.scope !9, !noalias !10
  store i64 %ld279, ptr %slot54, align 8
  %v280 = load i64, ptr %slot54, align 8
  %cmp281 = icmp ne i64 %v280, 0
  %cv282 = zext i1 %cmp281 to i32
  store i32 %cv282, ptr %slot55, align 8
  %v283 = load i32, ptr %slot55, align 8
  %cv284 = zext i32 %v283 to i64
  %cond285 = icmp ne i64 %cv284, 0
  br i1 %cond285, label %bb_rcgdec69, label %bb_rcgslow69
bb_rcgslow69:
  %v286 = load i64, ptr %slot42, align 8
  %v287 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v286, i64 %v287) nomerge, !dbg !116
  br label %bb_rcgdone69
bb_rcgdec69:
  %v288 = load i64, ptr %slot51, align 8
  %v289 = load i64, ptr %slot43, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %rgep291 = getelementptr i8, ptr %p290, i64 -24
  store i64 %v288, ptr %rgep291, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear69
bb_rcgclear69:
  %v292 = load i64, ptr %slot39, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 0, ptr %p293, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone69
bb_rcgdone69:
  br label %bb_rcslotdone53
bb_rcslotowner53:
  %v294 = load i64, ptr %slot20, align 8
  store i64 %v294, ptr %slot56, align 8
  %v295 = load i64, ptr %slot39, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %ld297 = load i64, ptr %p296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld297, ptr %slot57, align 8
  %v298 = load i64, ptr %slot57, align 8
  %cmp299 = icmp ne i64 %v298, 0
  %cv300 = zext i1 %cmp299 to i32
  store i32 %cv300, ptr %slot58, align 8
  %v301 = load i32, ptr %slot58, align 8
  %cv302 = zext i32 %v301 to i64
  %cond303 = icmp ne i64 %cv302, 0
  br i1 %cond303, label %bb_rcgnn84, label %bb_rcgdone84
bb_rcgnn84:
  %v304 = load i64, ptr %slot57, align 8
  %op305 = sub i64 %v304, 16
  store i64 %op305, ptr %slot59, align 8
  %v306 = load i64, ptr %slot57, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %rgep308 = getelementptr i8, ptr %p307, i64 -16
  %ld309 = load i64, ptr %rgep308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld309, ptr %slot60, align 8
  %v310 = load i64, ptr %slot60, align 8
  %op311 = and i64 %v310, 4611686018427387906
  store i64 %op311, ptr %slot61, align 8
  %v312 = load i64, ptr %slot61, align 8
  %cmp313 = icmp ne i64 %v312, 0
  %cv314 = zext i1 %cmp313 to i32
  store i32 %cv314, ptr %slot62, align 8
  %v315 = load i32, ptr %slot62, align 8
  %cv316 = zext i32 %v315 to i64
  %cond317 = icmp ne i64 %cv316, 0
  br i1 %cond317, label %bb_rcgclear84, label %bb_rcgcounted84
bb_rcgcounted84:
  %v318 = load i64, ptr %slot57, align 8
  %op319 = sub i64 %v318, 32
  store i64 %op319, ptr %slot63, align 8
  %v320 = load i64, ptr %slot57, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %rgep322 = getelementptr i8, ptr %p321, i64 -32
  %ld323 = load i64, ptr %rgep322, align 8, !alias.scope !9, !noalias !10
  store i64 %ld323, ptr %slot64, align 8
  %v324 = load i64, ptr %slot64, align 8
  %op325 = sub i64 %v324, 1
  store i64 %op325, ptr %slot65, align 8
  %v326 = load i64, ptr %slot65, align 8
  %cmp327 = icmp eq i64 %v326, 0
  %cv328 = zext i1 %cmp327 to i32
  store i32 %cv328, ptr %slot66, align 8
  %v329 = load i32, ptr %slot66, align 8
  %cv330 = zext i32 %v329 to i64
  %cond331 = icmp ne i64 %cv330, 0
  br i1 %cond331, label %bb_rcglast84, label %bb_rcgdec84
bb_rcglast84:
  %v332 = load i64, ptr %slot57, align 8
  %op333 = sub i64 %v332, 24
  store i64 %op333, ptr %slot67, align 8
  %v334 = load i64, ptr %slot57, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %rgep336 = getelementptr i8, ptr %p335, i64 -24
  %ld337 = load i64, ptr %rgep336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld337, ptr %slot68, align 8
  %v338 = load i64, ptr %slot68, align 8
  %cmp339 = icmp ne i64 %v338, 0
  %cv340 = zext i1 %cmp339 to i32
  store i32 %cv340, ptr %slot69, align 8
  %v341 = load i32, ptr %slot69, align 8
  %cv342 = zext i32 %v341 to i64
  %cond343 = icmp ne i64 %cv342, 0
  br i1 %cond343, label %bb_rcgdec84, label %bb_rcgslow84
bb_rcgslow84:
  %v344 = load i64, ptr %slot56, align 8
  %v345 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v344, i64 %v345) nomerge, !dbg !116
  br label %bb_rcgdone84
bb_rcgdec84:
  %v346 = load i64, ptr %slot65, align 8
  %v347 = load i64, ptr %slot57, align 8
  %p348 = inttoptr i64 %v347 to ptr
  %rgep349 = getelementptr i8, ptr %p348, i64 -32
  store i64 %v346, ptr %rgep349, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear84
bb_rcgclear84:
  %v350 = load i64, ptr %slot39, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 0, ptr %p351, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone84
bb_rcgdone84:
  br label %bb_rcslotdone53
bb_rcslotdone53:
  %v352 = load i64, ptr %slot12, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 0, ptr %p353, align 8, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot12, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot70, align 8
  %v357 = load i64, ptr %slot70, align 8
  ret i64 %v357
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_4a567dbed804c7cf92d6eb2154c9ccfecc754c82ed316a70b59da8384d2cb99f = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6274f19bfab332ff9f87906b74a57c16f50224bbc9c175562082f2250f3526bb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6274f19bfab332ff9f87906b74a57c16f50224bbc9c175562082f2250f3526bb", linkageName: "myl_f_6274f19bfab332ff9f87906b74a57c16f50224bbc9c175562082f2250f3526bb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10955111699609023962, i64 0, !"myl_f_6274f19bfab332ff9f87906b74a57c16f50224bbc9c175562082f2250f3526bb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
