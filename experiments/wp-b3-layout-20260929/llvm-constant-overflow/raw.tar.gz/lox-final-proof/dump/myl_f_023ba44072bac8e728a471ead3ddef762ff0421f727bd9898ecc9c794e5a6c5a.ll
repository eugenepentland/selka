target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_023ba44072bac8e728a471ead3ddef762ff0421f727bd9898ecc9c794e5a6c5a(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i32, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i32, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v1230 = load i64, ptr %slot1, align 8
  %op1231 = add i64 %v1230, 32
  store i64 %op1231, ptr %slot3, align 8
  %mem1232 = alloca i8, i64 8, align 8
  %ptr1233 = ptrtoint ptr %mem1232 to i64
  store i64 %ptr1233, ptr %slot4, align 8
  %mem1234 = alloca i8, i64 8, align 8
  %ptr1235 = ptrtoint ptr %mem1234 to i64
  store i64 %ptr1235, ptr %slot5, align 8
  %mem1236 = alloca i8, i64 8, align 8
  %ptr1237 = ptrtoint ptr %mem1236 to i64
  store i64 %ptr1237, ptr %slot6, align 8
  %mem1238 = alloca i8, i64 8, align 8
  %ptr1239 = ptrtoint ptr %mem1238 to i64
  store i64 %ptr1239, ptr %slot7, align 8
  %mem1240 = alloca i8, i64 8, align 8
  %ptr1241 = ptrtoint ptr %mem1240 to i64
  store i64 %ptr1241, ptr %slot8, align 8
  %mem1242 = alloca i8, i64 8, align 8
  %ptr1243 = ptrtoint ptr %mem1242 to i64
  store i64 %ptr1243, ptr %slot9, align 8
  %mem1244 = alloca i8, i64 8, align 8
  %ptr1245 = ptrtoint ptr %mem1244 to i64
  store i64 %ptr1245, ptr %slot10, align 8
  %mem1246 = alloca i8, i64 8, align 8
  %ptr1247 = ptrtoint ptr %mem1246 to i64
  store i64 %ptr1247, ptr %slot11, align 8
  %mem1248 = alloca i8, i64 8, align 8
  %ptr1249 = ptrtoint ptr %mem1248 to i64
  store i64 %ptr1249, ptr %slot12, align 8
  %mem1250 = alloca i8, i64 8, align 8
  %ptr1251 = ptrtoint ptr %mem1250 to i64
  store i64 %ptr1251, ptr %slot13, align 8
  %mem1252 = alloca i8, i64 8, align 8
  %ptr1253 = ptrtoint ptr %mem1252 to i64
  store i64 %ptr1253, ptr %slot14, align 8
  %mem1254 = alloca i8, i64 8, align 8
  %ptr1255 = ptrtoint ptr %mem1254 to i64
  store i64 %ptr1255, ptr %slot15, align 8
  %mem1256 = alloca i8, i64 8, align 8
  %ptr1257 = ptrtoint ptr %mem1256 to i64
  store i64 %ptr1257, ptr %slot16, align 8
  %mem1258 = alloca i8, i64 8, align 8
  %ptr1259 = ptrtoint ptr %mem1258 to i64
  store i64 %ptr1259, ptr %slot17, align 8
  %mem1260 = alloca i8, i64 8, align 8
  %ptr1261 = ptrtoint ptr %mem1260 to i64
  store i64 %ptr1261, ptr %slot18, align 8
  %mem1262 = alloca i8, i64 392, align 8
  %ptr1263 = ptrtoint ptr %mem1262 to i64
  store i64 %ptr1263, ptr %slot19, align 8
  %mem1264 = alloca i8, i64 88, align 8
  %ptr1265 = ptrtoint ptr %mem1264 to i64
  store i64 %ptr1265, ptr %slot20, align 8
  %mem1266 = alloca i8, i64 8, align 8
  %ptr1267 = ptrtoint ptr %mem1266 to i64
  store i64 %ptr1267, ptr %slot21, align 8
  %mem1268 = alloca i8, i64 8, align 8
  %ptr1269 = ptrtoint ptr %mem1268 to i64
  store i64 %ptr1269, ptr %slot22, align 8
  %mem1270 = alloca i8, i64 392, align 8
  %ptr1271 = ptrtoint ptr %mem1270 to i64
  store i64 %ptr1271, ptr %slot23, align 8
  %mem1272 = alloca i8, i64 32, align 8
  %ptr1273 = ptrtoint ptr %mem1272 to i64
  store i64 %ptr1273, ptr %slot24, align 8
  %v1274 = load i64, ptr %slot24, align 8
  %p1276 = inttoptr i64 %v1274 to ptr
  %gep1277 = getelementptr i8, ptr %p1276, i64 24
  %op1275 = ptrtoint ptr %gep1277 to i64
  store i64 %op1275, ptr %slot25, align 8
  %v1278 = load i64, ptr %slot25, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i64 0, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  %mem1280 = alloca i8, i64 32, align 8
  %ptr1281 = ptrtoint ptr %mem1280 to i64
  store i64 %ptr1281, ptr %slot26, align 8
  %v1282 = load i64, ptr %slot26, align 8
  %p1284 = inttoptr i64 %v1282 to ptr
  %gep1285 = getelementptr i8, ptr %p1284, i64 24
  %op1283 = ptrtoint ptr %gep1285 to i64
  store i64 %op1283, ptr %slot27, align 8
  %v1286 = load i64, ptr %slot27, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 0, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  %mem1288 = alloca i8, i64 16, align 8
  %ptr1289 = ptrtoint ptr %mem1288 to i64
  store i64 %ptr1289, ptr %slot28, align 8
  %mem1290 = alloca i8, i64 8, align 8
  %ptr1291 = ptrtoint ptr %mem1290 to i64
  store i64 %ptr1291, ptr %slot29, align 8
  %mem1292 = alloca i8, i64 8, align 8
  %ptr1293 = ptrtoint ptr %mem1292 to i64
  store i64 %ptr1293, ptr %slot30, align 8
  %mem1294 = alloca i8, i64 8, align 8
  %ptr1295 = ptrtoint ptr %mem1294 to i64
  store i64 %ptr1295, ptr %slot31, align 8
  %mem1296 = alloca i8, i64 8, align 8
  %ptr1297 = ptrtoint ptr %mem1296 to i64
  store i64 %ptr1297, ptr %slot32, align 8
  %mem1298 = alloca i8, i64 8, align 8
  %ptr1299 = ptrtoint ptr %mem1298 to i64
  store i64 %ptr1299, ptr %slot33, align 8
  %mem1300 = alloca i8, i64 88, align 8
  %ptr1301 = ptrtoint ptr %mem1300 to i64
  store i64 %ptr1301, ptr %slot34, align 8
  %mem1302 = alloca i8, i64 88, align 8
  %ptr1303 = ptrtoint ptr %mem1302 to i64
  store i64 %ptr1303, ptr %slot35, align 8
  %mem1304 = alloca i8, i64 8, align 8
  %ptr1305 = ptrtoint ptr %mem1304 to i64
  store i64 %ptr1305, ptr %slot36, align 8
  %mem1306 = alloca i8, i64 8, align 8
  %ptr1307 = ptrtoint ptr %mem1306 to i64
  store i64 %ptr1307, ptr %slot37, align 8
  %mem1308 = alloca i8, i64 88, align 8
  %ptr1309 = ptrtoint ptr %mem1308 to i64
  store i64 %ptr1309, ptr %slot38, align 8
  %mem1310 = alloca i8, i64 8, align 8
  %ptr1311 = ptrtoint ptr %mem1310 to i64
  store i64 %ptr1311, ptr %slot39, align 8
  %mem1312 = alloca i8, i64 8, align 8
  %ptr1313 = ptrtoint ptr %mem1312 to i64
  store i64 %ptr1313, ptr %slot40, align 8
  %mem1314 = alloca i8, i64 56, align 8
  %ptr1315 = ptrtoint ptr %mem1314 to i64
  store i64 %ptr1315, ptr %slot41, align 8
  %mem1316 = alloca i8, i64 8, align 8
  %ptr1317 = ptrtoint ptr %mem1316 to i64
  store i64 %ptr1317, ptr %slot42, align 8
  %mem1318 = alloca i8, i64 8, align 8
  %ptr1319 = ptrtoint ptr %mem1318 to i64
  store i64 %ptr1319, ptr %slot43, align 8
  %mem1320 = alloca i8, i64 8, align 8
  %ptr1321 = ptrtoint ptr %mem1320 to i64
  store i64 %ptr1321, ptr %slot44, align 8
  %mem1322 = alloca i8, i64 8, align 8
  %ptr1323 = ptrtoint ptr %mem1322 to i64
  store i64 %ptr1323, ptr %slot45, align 8
  %mem1324 = alloca i8, i64 8, align 8
  %ptr1325 = ptrtoint ptr %mem1324 to i64
  store i64 %ptr1325, ptr %slot46, align 8
  %mem1326 = alloca i8, i64 88, align 8
  %ptr1327 = ptrtoint ptr %mem1326 to i64
  store i64 %ptr1327, ptr %slot47, align 8
  %mem1328 = alloca i8, i64 88, align 8
  %ptr1329 = ptrtoint ptr %mem1328 to i64
  store i64 %ptr1329, ptr %slot48, align 8
  %mem1330 = alloca i8, i64 56, align 8
  %ptr1331 = ptrtoint ptr %mem1330 to i64
  store i64 %ptr1331, ptr %slot49, align 8
  %mem1332 = alloca i8, i64 56, align 8
  %ptr1333 = ptrtoint ptr %mem1332 to i64
  store i64 %ptr1333, ptr %slot50, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem1334 = alloca i8, i64 8, align 8
  %ptr1335 = ptrtoint ptr %mem1334 to i64
  store i64 %ptr1335, ptr %slot51, align 8
  %v1336 = load i64, ptr %slot1, align 8
  %op1337 = add i64 %v1336, 64
  store i64 %op1337, ptr %slot52, align 8
  %v1338 = load i64, ptr %slot52, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %ld1340 = load i64, ptr %p1339, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1340, ptr %slot53, align 8
  %stack1341 = call ptr @llvm.stacksave()
  %stackaddr1342 = ptrtoint ptr %stack1341 to i64
  %v1343 = load i64, ptr %slot53, align 8
  %cmp1344 = icmp ult i64 %stackaddr1342, %v1343
  %cv1345 = zext i1 %cmp1344 to i64
  store i64 %cv1345, ptr %slot54, align 8
  %v1346 = load i64, ptr %slot54, align 8
  %cond1347 = icmp ne i64 %v1346, 0
  br i1 %cond1347, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v1348 = load i64, ptr %slot1, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  call void @myl_qbe_fail_frame(ptr %p1349) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %mem1350 = alloca i8, i64 88, align 8
  %ptr1351 = ptrtoint ptr %mem1350 to i64
  store i64 %ptr1351, ptr %slot55, align 8
  %v1352 = load i64, ptr %slot30, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i64 0, ptr %p1353, align 8, !alias.scope !3, !noalias !4
  %v1354 = load i64, ptr %slot32, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  store i64 0, ptr %p1355, align 8, !alias.scope !3, !noalias !4
  %v1356 = load i64, ptr %slot37, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  store i64 0, ptr %p1357, align 8, !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot40, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i64 0, ptr %p1359, align 8, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot2, align 8
  %v1361 = load i64, ptr %slot29, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  store i64 %v1360, ptr %p1362, align 8, !alias.scope !3, !noalias !4
  %v1363 = load i64, ptr %slot1, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %call1365 = call ptr @myl_qbe_heap(ptr %p1364) nomerge, !dbg !112
  %calladdr1366 = ptrtoint ptr %call1365 to i64
  store i64 %calladdr1366, ptr %slot56, align 8
  %v1367 = load i64, ptr %slot1, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  %call1369 = call i64 @myl_qbe_region_mark(ptr %p1368) nomerge, !dbg !112
  store i64 %call1369, ptr %slot57, align 8
  %v1370 = load i64, ptr %slot4, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  store i32 0, ptr %p1371, align 4, !alias.scope !3, !noalias !4
  %v1372 = load i64, ptr %slot5, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  store i32 0, ptr %p1373, align 4, !alias.scope !3, !noalias !4
  %v1374 = load i64, ptr %slot6, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i32 0, ptr %p1375, align 4, !alias.scope !3, !noalias !4
  %v1376 = load i64, ptr %slot7, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  store i32 0, ptr %p1377, align 4, !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot8, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i32 0, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot9, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i32 0, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  %v1382 = load i64, ptr %slot10, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i32 0, ptr %p1383, align 4, !alias.scope !3, !noalias !4
  %v1384 = load i64, ptr %slot11, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  store i32 0, ptr %p1385, align 4, !alias.scope !3, !noalias !4
  %v1386 = load i64, ptr %slot12, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i32 0, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot13, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  store i32 0, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot14, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i32 0, ptr %p1391, align 4, !alias.scope !3, !noalias !4
  %v1392 = load i64, ptr %slot15, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 0, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot16, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i32 0, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot17, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i32 0, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  %v1398 = load i64, ptr %slot18, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot5, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 2, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot7, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 2, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot9, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 2, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot11, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i32 2, ptr %p1407, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1408 = load i64, ptr %slot29, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot58, align 8
  %v1411 = load i64, ptr %slot58, align 8
  %v1412 = load i64, ptr %slot44, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i64 %v1411, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  %v1414 = load i64, ptr %slot44, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  %ld1416 = load i64, ptr %p1415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1416, ptr %slot59, align 8
  %v1417 = load i64, ptr %slot59, align 8
  %op1418 = add i64 %v1417, 376
  store i64 %op1418, ptr %slot60, align 8
  %v1419 = load i64, ptr %slot60, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %ld1421 = load i64, ptr %p1420, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1421, ptr %slot61, align 8
  %v1422 = load i64, ptr %slot61, align 8
  %v1423 = load i64, ptr %slot44, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  store i64 %v1422, ptr %p1424, align 8, !alias.scope !3, !noalias !4
  %v1425 = load i64, ptr %slot12, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  %ld1427 = load i32, ptr %p1426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1427, ptr %slot62, align 8
  %v1428 = load i32, ptr %slot62, align 8
  %cv1429 = zext i32 %v1428 to i64
  %cond1430 = icmp ne i64 %cv1429, 0
  br i1 %cond1430, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v1431 = load i64, ptr %slot12, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  store i32 0, ptr %p1432, align 4, !alias.scope !3, !noalias !4
  %v1433 = load i64, ptr %slot19, align 8
  store i64 %v1433, ptr %slot63, align 8
  %v1434 = load i64, ptr %slot13, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i32, ptr %p1435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1436, ptr %slot64, align 8
  %v1437 = load i32, ptr %slot64, align 8
  %op1438 = and i32 %v1437, 28
  store i32 %op1438, ptr %slot65, align 8
  %v1439 = load i32, ptr %slot65, align 8
  %cv1440 = zext i32 %v1439 to i64
  %cond1441 = icmp ne i64 %cv1440, 0
  br i1 %cond1441, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v1442 = load i64, ptr %slot56, align 8
  store i64 %v1442, ptr %slot66, align 8
  %v1443 = load i64, ptr %slot66, align 8
  %v1444 = load i64, ptr %slot63, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1443, i64 %v1444) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v1445 = load i64, ptr %slot56, align 8
  store i64 %v1445, ptr %slot67, align 8
  %v1446 = load i64, ptr %slot67, align 8
  %v1447 = load i64, ptr %slot63, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1446, i64 %v1447) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v1448 = load i64, ptr %slot44, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  %ld1450 = load i64, ptr %p1449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1450, ptr %slot68, align 8
  %v1451 = load i64, ptr %slot68, align 8
  %v1452 = load i64, ptr %slot30, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i64 %v1451, ptr %p1453, align 8, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot30, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i64, ptr %p1455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1456, ptr %slot69, align 8
  %v1457 = load i64, ptr %slot69, align 8
  %op1458 = add i64 %v1457, 0
  store i64 %op1458, ptr %slot70, align 8
  %v1459 = load i64, ptr %slot70, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %ld1461 = load i64, ptr %p1460, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1461, ptr %slot71, align 8
  %v1462 = load i64, ptr %slot71, align 8
  %v1463 = load i64, ptr %slot44, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i64 %v1462, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  %v1465 = load i64, ptr %slot44, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  %ld1467 = load i64, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1467, ptr %slot72, align 8
  %v1468 = load i64, ptr %slot72, align 8
  %cmp1469 = icmp ugt i64 %v1468, 9223372036854775807
  %cv1470 = zext i1 %cmp1469 to i64
  store i64 %cv1470, ptr %slot73, align 8
  %v1471 = load i64, ptr %slot73, align 8
  %cond1472 = icmp ne i64 %v1471, 0
  br i1 %cond1472, label %bb_cast_overflow37, label %bb_cast_ok37
bb_cast_overflow37:
  %v1473 = load i64, ptr %slot1, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %v1475 = load i64, ptr %slot72, align 8
  call void @myl_qbe_fail_cast(ptr %p1474, i64 %v1475, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok37:
  %v1476 = load i64, ptr %slot72, align 8
  %v1477 = load i64, ptr %slot44, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i64 %v1476, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot45, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i64 1, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot45, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %ld1483 = load i64, ptr %p1482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1483, ptr %slot74, align 8
  %v1484 = load i64, ptr %slot44, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i64, ptr %p1485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1486, ptr %slot75, align 8
  %v1487 = load i64, ptr %slot75, align 8
  %v1488 = load i64, ptr %slot74, align 8
  %ovpair1490 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1487, i64 %v1488)
  %op1489 = extractvalue { i64, i1 } %ovpair1490, 0
  %ov1491 = extractvalue { i64, i1 } %ovpair1490, 1
  store i64 %op1489, ptr %slot76, align 8
  %cv1492 = zext i1 %ov1491 to i64
  store i64 %cv1492, ptr %slot77, align 8
  %v1493 = load i64, ptr %slot77, align 8
  %cond1494 = icmp ne i64 %v1493, 0
  br i1 %cond1494, label %bb_overflow40, label %bb_checked40
bb_overflow40:
  %v1495 = load i64, ptr %slot1, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  %v1497 = load i64, ptr %slot75, align 8
  %v1498 = load i64, ptr %slot74, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1496, i64 1, i64 %v1497, i64 %v1498, i64 64) nomerge, !dbg !118
  unreachable
bb_checked40:
  %v1499 = load i64, ptr %slot76, align 8
  %v1500 = load i64, ptr %slot44, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i64 %v1499, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot44, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %ld1504 = load i64, ptr %p1503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1504, ptr %slot78, align 8
  %v1505 = load i64, ptr %slot78, align 8
  %v1506 = load i64, ptr %slot31, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  store i64 %v1505, ptr %p1507, align 8, !alias.scope !3, !noalias !4
  %v1508 = load i64, ptr %slot29, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i64, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1510, ptr %slot79, align 8
  %v1511 = load i64, ptr %slot79, align 8
  %v1512 = load i64, ptr %slot44, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  store i64 %v1511, ptr %p1513, align 8, !alias.scope !3, !noalias !4
  %v1514 = load i64, ptr %slot44, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %ld1516 = load i64, ptr %p1515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1516, ptr %slot80, align 8
  %v1517 = load i64, ptr %slot80, align 8
  %op1518 = add i64 %v1517, 376
  store i64 %op1518, ptr %slot81, align 8
  %v1519 = load i64, ptr %slot81, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %ld1521 = load i64, ptr %p1520, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1521, ptr %slot82, align 8
  %v1522 = load i64, ptr %slot82, align 8
  %v1523 = load i64, ptr %slot44, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i64 %v1522, ptr %p1524, align 8, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot12, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i32, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1527, ptr %slot83, align 8
  %v1528 = load i32, ptr %slot83, align 8
  %cv1529 = zext i32 %v1528 to i64
  %cond1530 = icmp ne i64 %cv1529, 0
  br i1 %cond1530, label %bb_rcslotdrop49, label %bb_rcslotdone49
bb_rcslotdrop49:
  %v1531 = load i64, ptr %slot12, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  store i32 0, ptr %p1532, align 4, !alias.scope !3, !noalias !4
  %v1533 = load i64, ptr %slot19, align 8
  store i64 %v1533, ptr %slot84, align 8
  %v1534 = load i64, ptr %slot13, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  %ld1536 = load i32, ptr %p1535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1536, ptr %slot85, align 8
  %v1537 = load i32, ptr %slot85, align 8
  %op1538 = and i32 %v1537, 28
  store i32 %op1538, ptr %slot86, align 8
  %v1539 = load i32, ptr %slot86, align 8
  %cv1540 = zext i32 %v1539 to i64
  %cond1541 = icmp ne i64 %cv1540, 0
  br i1 %cond1541, label %bb_rcslotrole49, label %bb_rcslotowner49
bb_rcslotrole49:
  %v1542 = load i64, ptr %slot56, align 8
  store i64 %v1542, ptr %slot87, align 8
  %v1543 = load i64, ptr %slot87, align 8
  %v1544 = load i64, ptr %slot84, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1543, i64 %v1544) nomerge, !dbg !120
  br label %bb_rcslotdone49
bb_rcslotowner49:
  %v1545 = load i64, ptr %slot56, align 8
  store i64 %v1545, ptr %slot88, align 8
  %v1546 = load i64, ptr %slot88, align 8
  %v1547 = load i64, ptr %slot84, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1546, i64 %v1547) nomerge, !dbg !120
  br label %bb_rcslotdone49
bb_rcslotdone49:
  %v1548 = load i64, ptr %slot44, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %ld1550 = load i64, ptr %p1549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1550, ptr %slot89, align 8
  %v1551 = load i64, ptr %slot89, align 8
  %v1552 = load i64, ptr %slot32, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i64 %v1551, ptr %p1553, align 8, !alias.scope !3, !noalias !4
  %v1554 = load i64, ptr %slot31, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  %ld1556 = load i64, ptr %p1555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1556, ptr %slot90, align 8
  %v1557 = load i64, ptr %slot90, align 8
  %v1558 = load i64, ptr %slot44, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i64 %v1557, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  %v1560 = load i64, ptr %slot44, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %ld1562 = load i64, ptr %p1561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1562, ptr %slot91, align 8
  %v1563 = load i64, ptr %slot91, align 8
  %v1564 = load i64, ptr %slot33, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  store i64 %v1563, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  %v1566 = load i64, ptr %slot33, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  %ld1568 = load i64, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1568, ptr %slot92, align 8
  %v1569 = load i64, ptr %slot92, align 8
  %v1570 = load i64, ptr %slot44, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  store i64 %v1569, ptr %p1571, align 8, !alias.scope !3, !noalias !4
  %v1572 = load i64, ptr %slot45, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i64 0, ptr %p1573, align 8, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot45, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  %ld1576 = load i64, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1576, ptr %slot93, align 8
  %v1577 = load i64, ptr %slot44, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %ld1579 = load i64, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1579, ptr %slot94, align 8
  %v1580 = load i64, ptr %slot94, align 8
  %v1581 = load i64, ptr %slot93, align 8
  %cmp1582 = icmp slt i64 %v1580, %v1581
  %cv1583 = zext i1 %cmp1582 to i64
  store i64 %cv1583, ptr %slot95, align 8
  %v1584 = load i64, ptr %slot95, align 8
  %v1585 = load i64, ptr %slot44, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i64 %v1584, ptr %p1586, align 8, !alias.scope !3, !noalias !4
  %v1587 = load i64, ptr %slot44, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %ld1589 = load i64, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1589, ptr %slot96, align 8
  %v1590 = load i64, ptr %slot96, align 8
  %cond1591 = icmp ne i64 %v1590, 0
  br i1 %cond1591, label %bb_next64, label %bb_i22
bb_next64:
  %v1592 = load i64, ptr %slot32, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  %ld1594 = load i64, ptr %p1593, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1594, ptr %slot97, align 8
  %v1595 = load i64, ptr %slot97, align 8
  %op1596 = add i64 %v1595, 0
  store i64 %op1596, ptr %slot98, align 8
  %v1597 = load i64, ptr %slot98, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %ld1599 = load i64, ptr %p1598, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1599, ptr %slot99, align 8
  %v1600 = load i64, ptr %slot99, align 8
  %v1601 = load i64, ptr %slot44, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i64 %v1600, ptr %p1602, align 8, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot44, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i64, ptr %p1604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1605, ptr %slot100, align 8
  %v1606 = load i64, ptr %slot100, align 8
  %cmp1607 = icmp ugt i64 %v1606, 9223372036854775807
  %cv1608 = zext i1 %cmp1607 to i64
  store i64 %cv1608, ptr %slot101, align 8
  %v1609 = load i64, ptr %slot101, align 8
  %cond1610 = icmp ne i64 %v1609, 0
  br i1 %cond1610, label %bb_cast_overflow69, label %bb_cast_ok69
bb_cast_overflow69:
  %v1611 = load i64, ptr %slot1, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %v1613 = load i64, ptr %slot100, align 8
  call void @myl_qbe_fail_cast(ptr %p1612, i64 %v1613, i64 320) nomerge, !dbg !122
  unreachable
bb_cast_ok69:
  %v1614 = load i64, ptr %slot100, align 8
  %v1615 = load i64, ptr %slot44, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  store i64 %v1614, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  %v1617 = load i64, ptr %slot33, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %ld1619 = load i64, ptr %p1618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1619, ptr %slot102, align 8
  %v1620 = load i64, ptr %slot102, align 8
  %v1621 = load i64, ptr %slot45, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i64 %v1620, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot45, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i64, ptr %p1624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1625, ptr %slot103, align 8
  %v1626 = load i64, ptr %slot44, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot104, align 8
  %v1629 = load i64, ptr %slot104, align 8
  %v1630 = load i64, ptr %slot103, align 8
  %ovpair1632 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1629, i64 %v1630)
  %op1631 = extractvalue { i64, i1 } %ovpair1632, 0
  %ov1633 = extractvalue { i64, i1 } %ovpair1632, 1
  store i64 %op1631, ptr %slot105, align 8
  %v1634 = load i64, ptr %slot104, align 8
  %v1635 = load i64, ptr %slot105, align 8
  %op1636 = xor i64 %v1634, %v1635
  store i64 %op1636, ptr %slot106, align 8
  %v1637 = load i64, ptr %slot103, align 8
  %v1638 = load i64, ptr %slot105, align 8
  %op1639 = xor i64 %v1637, %v1638
  store i64 %op1639, ptr %slot107, align 8
  %v1640 = load i64, ptr %slot106, align 8
  %v1641 = load i64, ptr %slot107, align 8
  %op1642 = and i64 %v1640, %v1641
  store i64 %op1642, ptr %slot108, align 8
  %cv1643 = zext i1 %ov1633 to i64
  store i64 %cv1643, ptr %slot109, align 8
  %v1644 = load i64, ptr %slot109, align 8
  %cond1645 = icmp ne i64 %v1644, 0
  br i1 %cond1645, label %bb_overflow73, label %bb_checked73
bb_overflow73:
  %v1646 = load i64, ptr %slot1, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %v1648 = load i64, ptr %slot104, align 8
  %v1649 = load i64, ptr %slot103, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1647, i64 0, i64 %v1648, i64 %v1649, i64 64) nomerge, !dbg !124
  unreachable
bb_checked73:
  %v1650 = load i64, ptr %slot105, align 8
  %v1651 = load i64, ptr %slot44, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i64 %v1650, ptr %p1652, align 8, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot44, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %ld1655 = load i64, ptr %p1654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1655, ptr %slot110, align 8
  %v1656 = load i64, ptr %slot110, align 8
  %v1657 = load i64, ptr %slot33, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i64 %v1656, ptr %p1658, align 8, !alias.scope !3, !noalias !4
  br label %bb_i22
bb_i22:
  %v1659 = load i64, ptr %slot33, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i64, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1661, ptr %slot111, align 8
  %v1662 = load i64, ptr %slot111, align 8
  %v1663 = load i64, ptr %slot44, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i64 %v1662, ptr %p1664, align 8, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot32, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  %ld1667 = load i64, ptr %p1666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1667, ptr %slot112, align 8
  %v1668 = load i64, ptr %slot44, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i64, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1670, ptr %slot113, align 8
  %v1671 = load i64, ptr %slot112, align 8
  %p1672 = inttoptr i64 %v1671 to ptr
  %ld1673 = load i64, ptr %p1672, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1673, ptr %slot114, align 8
  %v1674 = load i64, ptr %slot113, align 8
  %v1675 = load i64, ptr %slot114, align 8
  %cmp1676 = icmp ult i64 %v1674, %v1675
  %cv1677 = zext i1 %cmp1676 to i64
  store i64 %cv1677, ptr %slot115, align 8
  %v1678 = load i64, ptr %slot115, align 8
  %cond1679 = icmp ne i64 %v1678, 0
  br i1 %cond1679, label %bb_success85, label %bb_failed85
bb_failed85:
  %v1680 = load i64, ptr %slot1, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  %v1682 = load i64, ptr %slot113, align 8
  %v1683 = load i64, ptr %slot114, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1681, i64 %v1682, i64 %v1683) nomerge, !dbg !126
  unreachable
bb_success85:
  %v1684 = load i64, ptr %slot112, align 8
  %op1685 = add i64 %v1684, 32
  store i64 %op1685, ptr %slot116, align 8
  %v1686 = load i64, ptr %slot116, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %ld1688 = load i64, ptr %p1687, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1688, ptr %slot117, align 8
  %v1689 = load i64, ptr %slot113, align 8
  %op1690 = mul i64 %v1689, 88
  store i64 %op1690, ptr %slot118, align 8
  %v1691 = load i64, ptr %slot117, align 8
  %v1692 = load i64, ptr %slot118, align 8
  %op1693 = add i64 %v1691, %v1692
  store i64 %op1693, ptr %slot119, align 8
  %v1694 = load i64, ptr %slot55, align 8
  store i64 %v1694, ptr %slot120, align 8
  %v1695 = load i64, ptr %slot119, align 8
  %v1696 = load i64, ptr %slot120, align 8
  %p1697 = inttoptr i64 %v1695 to ptr
  %p1698 = inttoptr i64 %v1696 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1698, ptr %p1697, i64 88, i1 false), !alias.scope !10000000
  %v1699 = load i64, ptr %slot120, align 8
  %v1700 = load i64, ptr %slot44, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  store i64 %v1699, ptr %p1701, align 8, !alias.scope !3, !noalias !4
  %v1702 = load i64, ptr %slot44, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %ld1704 = load i64, ptr %p1703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1704, ptr %slot121, align 8
  %v1705 = load i64, ptr %slot23, align 8
  store i64 %v1705, ptr %slot122, align 8
  %v1706 = load i64, ptr %slot56, align 8
  %v1707 = load i64, ptr %slot122, align 8
  %v1708 = load i64, ptr %slot121, align 8
  %call1709 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v1706, i64 %v1707, i64 %v1708) nomerge, !dbg !126
  store i32 %call1709, ptr %slot123, align 8
  %v1710 = load i32, ptr %slot123, align 8
  %cv1711 = zext i32 %v1710 to i64
  %cond1712 = icmp ne i64 %cv1711, 0
  br i1 %cond1712, label %bb_rcsuccess94, label %bb_rcfailure94
bb_rcfailure94:
  %v1713 = load i64, ptr %slot56, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  %call1715 = call i32 @myl_rc_take_failure(ptr %p1714) nomerge, !dbg !126
  store i32 %call1715, ptr %slot124, align 8
  %v1716 = load i64, ptr %slot1, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  %v1718 = load i32, ptr %slot124, align 8
  %call1719 = call i32 @myl_qbe_rc_status(ptr %p1717, i32 %v1718) nomerge, !dbg !126
  store i32 %call1719, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess94:
  %v1720 = load i64, ptr %slot17, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  store i32 2, ptr %p1721, align 4, !alias.scope !3, !noalias !4
  %v1722 = load i64, ptr %slot17, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i32 16, ptr %p1723, align 4, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot16, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 1, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot19, align 8
  store i64 %v1726, ptr %slot126, align 8
  %v1727 = load i64, ptr %slot23, align 8
  store i64 %v1727, ptr %slot127, align 8
  %v1728 = load i64, ptr %slot127, align 8
  %v1729 = load i64, ptr %slot126, align 8
  %p1730 = inttoptr i64 %v1728 to ptr
  %p1731 = inttoptr i64 %v1729 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1731, ptr %p1730, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1732 = load i64, ptr %slot13, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  store i32 2, ptr %p1733, align 4, !alias.scope !3, !noalias !4
  %v1734 = load i64, ptr %slot17, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  %ld1736 = load i32, ptr %p1735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1736, ptr %slot128, align 8
  %v1737 = load i32, ptr %slot128, align 8
  %v1738 = load i64, ptr %slot13, align 8
  %p1739 = inttoptr i64 %v1738 to ptr
  store i32 %v1737, ptr %p1739, align 4, !alias.scope !3, !noalias !4
  %v1740 = load i64, ptr %slot16, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  store i32 0, ptr %p1741, align 4, !alias.scope !3, !noalias !4
  %v1742 = load i64, ptr %slot12, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  store i32 1, ptr %p1743, align 4, !alias.scope !3, !noalias !4
  %v1744 = load i64, ptr %slot126, align 8
  %v1745 = load i64, ptr %slot44, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i64 %v1744, ptr %p1746, align 8, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot44, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  %ld1749 = load i64, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1749, ptr %slot129, align 8
  %v1750 = load i64, ptr %slot12, align 8
  %p1751 = inttoptr i64 %v1750 to ptr
  %ld1752 = load i32, ptr %p1751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1752, ptr %slot130, align 8
  %v1753 = load i64, ptr %slot13, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  %ld1755 = load i32, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1755, ptr %slot131, align 8
  %v1756 = load i32, ptr %slot131, align 8
  %op1757 = and i32 %v1756, 24
  store i32 %op1757, ptr %slot131, align 8
  %v1758 = load i32, ptr %slot131, align 8
  %cmp1759 = icmp eq i32 %v1758, 0
  %cv1760 = zext i1 %cmp1759 to i32
  store i32 %cv1760, ptr %slot132, align 8
  %v1761 = load i32, ptr %slot130, align 8
  %v1762 = load i32, ptr %slot132, align 8
  %op1763 = and i32 %v1761, %v1762
  store i32 %op1763, ptr %slot133, align 8
  %v1764 = load i64, ptr %slot57, align 8
  store i64 %v1764, ptr %slot134, align 8
  %v1765 = load i32, ptr %slot133, align 8
  %op1766 = mul i32 %v1765, 4
  store i32 %op1766, ptr %slot135, align 8
  %v1767 = load i32, ptr %slot135, align 8
  %op1768 = or i32 %v1767, 0
  store i32 %op1768, ptr %slot136, align 8
  %v1769 = load i64, ptr %slot23, align 8
  store i64 %v1769, ptr %slot137, align 8
  %v1770 = load i64, ptr %slot56, align 8
  %v1771 = load i64, ptr %slot137, align 8
  %v1772 = load i64, ptr %slot129, align 8
  %v1773 = load i64, ptr %slot134, align 8
  %cv1774 = trunc i64 %v1773 to i32
  %v1775 = load i32, ptr %slot136, align 8
  %call1776 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v1770, i64 %v1771, i64 %v1772, i32 %cv1774, i32 %v1775) nomerge, !dbg !128
  store i32 %call1776, ptr %slot138, align 8
  %v1777 = load i32, ptr %slot138, align 8
  %cv1778 = zext i32 %v1777 to i64
  %cond1779 = icmp ne i64 %cv1778, 0
  br i1 %cond1779, label %bb_rcsuccess122, label %bb_rcfailure122
bb_rcfailure122:
  %v1780 = load i64, ptr %slot56, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %call1782 = call i32 @myl_rc_take_failure(ptr %p1781) nomerge, !dbg !128
  store i32 %call1782, ptr %slot139, align 8
  %v1783 = load i64, ptr %slot1, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %v1785 = load i32, ptr %slot139, align 8
  %call1786 = call i32 @myl_qbe_rc_status(ptr %p1784, i32 %v1785) nomerge, !dbg !128
  store i32 %call1786, ptr %slot140, align 8
  br label %bb_failure
bb_rcsuccess122:
  %v1787 = load i32, ptr %slot133, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rchtaken125, label %bb_rchcopied125
bb_rchcopied125:
  %v1790 = load i64, ptr %slot12, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %ld1792 = load i32, ptr %p1791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1792, ptr %slot141, align 8
  %v1793 = load i32, ptr %slot141, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1796 = load i64, ptr %slot12, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  store i32 0, ptr %p1797, align 4, !alias.scope !3, !noalias !4
  %v1798 = load i64, ptr %slot19, align 8
  store i64 %v1798, ptr %slot142, align 8
  %v1799 = load i64, ptr %slot13, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %ld1801 = load i32, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1801, ptr %slot143, align 8
  %v1802 = load i32, ptr %slot143, align 8
  %op1803 = and i32 %v1802, 28
  store i32 %op1803, ptr %slot144, align 8
  %v1804 = load i32, ptr %slot144, align 8
  %cv1805 = zext i32 %v1804 to i64
  %cond1806 = icmp ne i64 %cv1805, 0
  br i1 %cond1806, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1807 = load i64, ptr %slot56, align 8
  store i64 %v1807, ptr %slot145, align 8
  %v1808 = load i64, ptr %slot145, align 8
  %v1809 = load i64, ptr %slot142, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1808, i64 %v1809) nomerge, !dbg !128
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1810 = load i64, ptr %slot56, align 8
  store i64 %v1810, ptr %slot146, align 8
  %v1811 = load i64, ptr %slot146, align 8
  %v1812 = load i64, ptr %slot142, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1811, i64 %v1812) nomerge, !dbg !128
  br label %bb_rcslotdone128
bb_rcslotdone128:
  br label %bb_rchprepared125
bb_rchtaken125:
  %v1813 = load i64, ptr %slot12, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 0, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared125
bb_rchprepared125:
  %v1815 = load i64, ptr %slot17, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 2, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot16, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 1, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot19, align 8
  store i64 %v1819, ptr %slot147, align 8
  %v1820 = load i64, ptr %slot23, align 8
  store i64 %v1820, ptr %slot148, align 8
  %v1821 = load i64, ptr %slot148, align 8
  %v1822 = load i64, ptr %slot147, align 8
  %p1823 = inttoptr i64 %v1821 to ptr
  %p1824 = inttoptr i64 %v1822 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1824, ptr %p1823, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1825 = load i64, ptr %slot13, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i32 2, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot17, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i32, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1829, ptr %slot149, align 8
  %v1830 = load i32, ptr %slot149, align 8
  %v1831 = load i64, ptr %slot13, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 %v1830, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot16, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i32 0, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  %v1835 = load i64, ptr %slot12, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i32 1, ptr %p1836, align 4, !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot147, align 8
  %v1838 = load i64, ptr %slot44, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  store i64 %v1837, ptr %p1839, align 8, !alias.scope !3, !noalias !4
  %v1840 = load i64, ptr %slot44, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %ld1842 = load i64, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1842, ptr %slot150, align 8
  %v1843 = load i64, ptr %slot23, align 8
  store i64 %v1843, ptr %slot151, align 8
  %v1844 = load i64, ptr %slot57, align 8
  store i64 %v1844, ptr %slot152, align 8
  %v1845 = load i64, ptr %slot56, align 8
  %v1846 = load i64, ptr %slot151, align 8
  %v1847 = load i64, ptr %slot150, align 8
  %v1848 = load i64, ptr %slot152, align 8
  %cv1849 = trunc i64 %v1848 to i32
  %call1850 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v1845, i64 %v1846, i64 %v1847, i32 %cv1849) nomerge, !dbg !130
  store i32 %call1850, ptr %slot153, align 8
  %v1851 = load i32, ptr %slot153, align 8
  %cv1852 = zext i32 %v1851 to i64
  %cond1853 = icmp ne i64 %cv1852, 0
  br i1 %cond1853, label %bb_rcsuccess150, label %bb_rcfailure150
bb_rcfailure150:
  %v1854 = load i64, ptr %slot56, align 8
  %p1855 = inttoptr i64 %v1854 to ptr
  %call1856 = call i32 @myl_rc_take_failure(ptr %p1855) nomerge, !dbg !130
  store i32 %call1856, ptr %slot154, align 8
  %v1857 = load i64, ptr %slot1, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  %v1859 = load i32, ptr %slot154, align 8
  %call1860 = call i32 @myl_qbe_rc_status(ptr %p1858, i32 %v1859) nomerge, !dbg !130
  store i32 %call1860, ptr %slot155, align 8
  br label %bb_failure
bb_rcsuccess150:
  %v1861 = load i64, ptr %slot12, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  store i32 0, ptr %p1862, align 4, !alias.scope !3, !noalias !4
  %v1863 = load i64, ptr %slot17, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  store i32 2, ptr %p1864, align 4, !alias.scope !3, !noalias !4
  %v1865 = load i64, ptr %slot16, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  store i32 1, ptr %p1866, align 4, !alias.scope !3, !noalias !4
  %v1867 = load i64, ptr %slot4, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %ld1869 = load i32, ptr %p1868, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1869, ptr %slot156, align 8
  %v1870 = load i32, ptr %slot156, align 8
  %cv1871 = zext i32 %v1870 to i64
  %cond1872 = icmp ne i64 %cv1871, 0
  br i1 %cond1872, label %bb_rcslotdrop159, label %bb_rcslotdone159
bb_rcslotdrop159:
  %v1873 = load i64, ptr %slot4, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  store i32 0, ptr %p1874, align 4, !alias.scope !3, !noalias !4
  %v1875 = load i64, ptr %slot34, align 8
  store i64 %v1875, ptr %slot157, align 8
  %v1876 = load i64, ptr %slot5, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %ld1878 = load i32, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1878, ptr %slot158, align 8
  %v1879 = load i32, ptr %slot158, align 8
  %op1880 = and i32 %v1879, 28
  store i32 %op1880, ptr %slot159, align 8
  %v1881 = load i32, ptr %slot159, align 8
  %cv1882 = zext i32 %v1881 to i64
  %cond1883 = icmp ne i64 %cv1882, 0
  br i1 %cond1883, label %bb_rcslotrole159, label %bb_rcslotowner159
bb_rcslotrole159:
  %v1884 = load i64, ptr %slot56, align 8
  store i64 %v1884, ptr %slot160, align 8
  %v1885 = load i64, ptr %slot160, align 8
  %v1886 = load i64, ptr %slot157, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1885, i64 %v1886) nomerge, !dbg !130
  br label %bb_rcslotdone159
bb_rcslotowner159:
  %v1887 = load i64, ptr %slot56, align 8
  store i64 %v1887, ptr %slot161, align 8
  %v1888 = load i64, ptr %slot161, align 8
  %v1889 = load i64, ptr %slot157, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1888, i64 %v1889) nomerge, !dbg !130
  br label %bb_rcslotdone159
bb_rcslotdone159:
  %v1890 = load i64, ptr %slot34, align 8
  store i64 %v1890, ptr %slot162, align 8
  %v1891 = load i64, ptr %slot23, align 8
  store i64 %v1891, ptr %slot163, align 8
  %v1892 = load i64, ptr %slot163, align 8
  %v1893 = load i64, ptr %slot162, align 8
  %p1894 = inttoptr i64 %v1892 to ptr
  %p1895 = inttoptr i64 %v1893 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1895, ptr %p1894, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot16, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  store i32 0, ptr %p1897, align 4, !alias.scope !3, !noalias !4
  %v1898 = load i64, ptr %slot5, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  store i32 2, ptr %p1899, align 4, !alias.scope !3, !noalias !4
  %v1900 = load i64, ptr %slot17, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  %ld1902 = load i32, ptr %p1901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1902, ptr %slot164, align 8
  %v1903 = load i32, ptr %slot164, align 8
  %v1904 = load i64, ptr %slot5, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 %v1903, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot4, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i32 1, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  %v1908 = load i64, ptr %slot34, align 8
  %v1909 = load i64, ptr %slot44, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i64 %v1908, ptr %p1910, align 8, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot44, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %ld1913 = load i64, ptr %p1912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1913, ptr %slot165, align 8
  %v1914 = load i64, ptr %slot12, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  %ld1916 = load i32, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1916, ptr %slot166, align 8
  %v1917 = load i64, ptr %slot13, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i32, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1919, ptr %slot167, align 8
  %v1920 = load i32, ptr %slot167, align 8
  %op1921 = and i32 %v1920, 24
  store i32 %op1921, ptr %slot167, align 8
  %v1922 = load i32, ptr %slot167, align 8
  %cmp1923 = icmp eq i32 %v1922, 0
  %cv1924 = zext i1 %cmp1923 to i32
  store i32 %cv1924, ptr %slot168, align 8
  %v1925 = load i32, ptr %slot166, align 8
  %v1926 = load i32, ptr %slot168, align 8
  %op1927 = and i32 %v1925, %v1926
  store i32 %op1927, ptr %slot169, align 8
  %v1928 = load i32, ptr %slot169, align 8
  %cv1929 = zext i32 %v1928 to i64
  %cond1930 = icmp ne i64 %cv1929, 0
  br i1 %cond1930, label %bb_rcprivateown180, label %bb_rcprivateloan180
bb_rcprivateown180:
  %v1931 = load i64, ptr %slot23, align 8
  store i64 %v1931, ptr %slot170, align 8
  %v1932 = load i64, ptr %slot57, align 8
  store i64 %v1932, ptr %slot171, align 8
  %v1933 = load i64, ptr %slot56, align 8
  %v1934 = load i64, ptr %slot170, align 8
  %v1935 = load i64, ptr %slot165, align 8
  %v1936 = load i64, ptr %slot171, align 8
  %cv1937 = trunc i64 %v1936 to i32
  %call1938 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v1933, i64 %v1934, i64 %v1935, i32 %cv1937) nomerge, !dbg !132
  store i32 %call1938, ptr %slot172, align 8
  %v1939 = load i32, ptr %slot172, align 8
  %cv1940 = zext i32 %v1939 to i64
  %cond1941 = icmp ne i64 %cv1940, 0
  br i1 %cond1941, label %bb_rcsuccess184, label %bb_rcfailure184
bb_rcfailure184:
  %v1942 = load i64, ptr %slot56, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %call1944 = call i32 @myl_rc_take_failure(ptr %p1943) nomerge, !dbg !132
  store i32 %call1944, ptr %slot173, align 8
  %v1945 = load i64, ptr %slot1, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  %v1947 = load i32, ptr %slot173, align 8
  %call1948 = call i32 @myl_qbe_rc_status(ptr %p1946, i32 %v1947) nomerge, !dbg !132
  store i32 %call1948, ptr %slot174, align 8
  br label %bb_failure
bb_rcsuccess184:
  %v1949 = load i64, ptr %slot12, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  store i32 0, ptr %p1950, align 4, !alias.scope !3, !noalias !4
  %v1951 = load i64, ptr %slot17, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  store i32 2, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  %v1953 = load i64, ptr %slot16, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i32 1, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared180
bb_rcprivateloan180:
  %v1955 = load i64, ptr %slot23, align 8
  store i64 %v1955, ptr %slot175, align 8
  %v1956 = load i64, ptr %slot56, align 8
  %v1957 = load i64, ptr %slot175, align 8
  %v1958 = load i64, ptr %slot165, align 8
  %call1959 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v1956, i64 %v1957, i64 %v1958) nomerge, !dbg !132
  store i32 %call1959, ptr %slot176, align 8
  %v1960 = load i32, ptr %slot176, align 8
  %cv1961 = zext i32 %v1960 to i64
  %cond1962 = icmp ne i64 %cv1961, 0
  br i1 %cond1962, label %bb_rcsuccess192, label %bb_rcfailure192
bb_rcfailure192:
  %v1963 = load i64, ptr %slot56, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %call1965 = call i32 @myl_rc_take_failure(ptr %p1964) nomerge, !dbg !132
  store i32 %call1965, ptr %slot177, align 8
  %v1966 = load i64, ptr %slot1, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %v1968 = load i32, ptr %slot177, align 8
  %call1969 = call i32 @myl_qbe_rc_status(ptr %p1967, i32 %v1968) nomerge, !dbg !132
  store i32 %call1969, ptr %slot178, align 8
  br label %bb_failure
bb_rcsuccess192:
  %v1970 = load i64, ptr %slot17, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  store i32 2, ptr %p1971, align 4, !alias.scope !3, !noalias !4
  %v1972 = load i64, ptr %slot17, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i32 16, ptr %p1973, align 4, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot16, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i32 1, ptr %p1975, align 4, !alias.scope !3, !noalias !4
  %v1976 = load i64, ptr %slot12, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %ld1978 = load i32, ptr %p1977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1978, ptr %slot179, align 8
  %v1979 = load i32, ptr %slot179, align 8
  %cv1980 = zext i32 %v1979 to i64
  %cond1981 = icmp ne i64 %cv1980, 0
  br i1 %cond1981, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1982 = load i64, ptr %slot12, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 0, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot19, align 8
  store i64 %v1984, ptr %slot180, align 8
  %v1985 = load i64, ptr %slot13, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %ld1987 = load i32, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1987, ptr %slot181, align 8
  %v1988 = load i32, ptr %slot181, align 8
  %op1989 = and i32 %v1988, 28
  store i32 %op1989, ptr %slot182, align 8
  %v1990 = load i32, ptr %slot182, align 8
  %cv1991 = zext i32 %v1990 to i64
  %cond1992 = icmp ne i64 %cv1991, 0
  br i1 %cond1992, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1993 = load i64, ptr %slot56, align 8
  store i64 %v1993, ptr %slot183, align 8
  %v1994 = load i64, ptr %slot183, align 8
  %v1995 = load i64, ptr %slot180, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1994, i64 %v1995) nomerge, !dbg !132
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1996 = load i64, ptr %slot56, align 8
  store i64 %v1996, ptr %slot184, align 8
  %v1997 = load i64, ptr %slot184, align 8
  %v1998 = load i64, ptr %slot180, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1997, i64 %v1998) nomerge, !dbg !132
  br label %bb_rcslotdone200
bb_rcslotdone200:
  br label %bb_rcprivateprepared180
bb_rcprivateprepared180:
  %v1999 = load i64, ptr %slot6, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  %ld2001 = load i32, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2001, ptr %slot185, align 8
  %v2002 = load i32, ptr %slot185, align 8
  %cv2003 = zext i32 %v2002 to i64
  %cond2004 = icmp ne i64 %cv2003, 0
  br i1 %cond2004, label %bb_rcslotdrop210, label %bb_rcslotdone210
bb_rcslotdrop210:
  %v2005 = load i64, ptr %slot6, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i32 0, ptr %p2006, align 4, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot35, align 8
  store i64 %v2007, ptr %slot186, align 8
  %v2008 = load i64, ptr %slot7, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %ld2010 = load i32, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2010, ptr %slot187, align 8
  %v2011 = load i32, ptr %slot187, align 8
  %op2012 = and i32 %v2011, 28
  store i32 %op2012, ptr %slot188, align 8
  %v2013 = load i32, ptr %slot188, align 8
  %cv2014 = zext i32 %v2013 to i64
  %cond2015 = icmp ne i64 %cv2014, 0
  br i1 %cond2015, label %bb_rcslotrole210, label %bb_rcslotowner210
bb_rcslotrole210:
  %v2016 = load i64, ptr %slot56, align 8
  store i64 %v2016, ptr %slot189, align 8
  %v2017 = load i64, ptr %slot189, align 8
  %v2018 = load i64, ptr %slot186, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2017, i64 %v2018) nomerge, !dbg !132
  br label %bb_rcslotdone210
bb_rcslotowner210:
  %v2019 = load i64, ptr %slot56, align 8
  store i64 %v2019, ptr %slot190, align 8
  %v2020 = load i64, ptr %slot190, align 8
  %v2021 = load i64, ptr %slot186, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2020, i64 %v2021) nomerge, !dbg !132
  br label %bb_rcslotdone210
bb_rcslotdone210:
  %v2022 = load i64, ptr %slot35, align 8
  store i64 %v2022, ptr %slot191, align 8
  %v2023 = load i64, ptr %slot23, align 8
  store i64 %v2023, ptr %slot192, align 8
  %v2024 = load i64, ptr %slot192, align 8
  %v2025 = load i64, ptr %slot191, align 8
  %p2026 = inttoptr i64 %v2024 to ptr
  %p2027 = inttoptr i64 %v2025 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2027, ptr %p2026, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot16, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  store i32 0, ptr %p2029, align 4, !alias.scope !3, !noalias !4
  %v2030 = load i64, ptr %slot7, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  store i32 2, ptr %p2031, align 4, !alias.scope !3, !noalias !4
  %v2032 = load i64, ptr %slot17, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %ld2034 = load i32, ptr %p2033, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2034, ptr %slot193, align 8
  %v2035 = load i32, ptr %slot193, align 8
  %v2036 = load i64, ptr %slot7, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  store i32 %v2035, ptr %p2037, align 4, !alias.scope !3, !noalias !4
  %v2038 = load i64, ptr %slot6, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i32 1, ptr %p2039, align 4, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot35, align 8
  %v2041 = load i64, ptr %slot44, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i64 %v2040, ptr %p2042, align 8, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot44, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %ld2045 = load i64, ptr %p2044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2045, ptr %slot194, align 8
  %v2046 = load i64, ptr %slot194, align 8
  %op2047 = add i64 %v2046, 0
  store i64 %op2047, ptr %slot195, align 8
  %v2048 = load i64, ptr %slot195, align 8
  %v2049 = load i64, ptr %slot44, align 8
  %p2050 = inttoptr i64 %v2049 to ptr
  store i64 %v2048, ptr %p2050, align 8, !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot12, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  %ld2053 = load i32, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2053, ptr %slot196, align 8
  %v2054 = load i32, ptr %slot196, align 8
  %cv2055 = zext i32 %v2054 to i64
  %cond2056 = icmp ne i64 %cv2055, 0
  br i1 %cond2056, label %bb_rcslotdrop228, label %bb_rcslotdone228
bb_rcslotdrop228:
  %v2057 = load i64, ptr %slot12, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i32 0, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot19, align 8
  store i64 %v2059, ptr %slot197, align 8
  %v2060 = load i64, ptr %slot13, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  %ld2062 = load i32, ptr %p2061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2062, ptr %slot198, align 8
  %v2063 = load i32, ptr %slot198, align 8
  %op2064 = and i32 %v2063, 28
  store i32 %op2064, ptr %slot199, align 8
  %v2065 = load i32, ptr %slot199, align 8
  %cv2066 = zext i32 %v2065 to i64
  %cond2067 = icmp ne i64 %cv2066, 0
  br i1 %cond2067, label %bb_rcslotrole228, label %bb_rcslotowner228
bb_rcslotrole228:
  %v2068 = load i64, ptr %slot56, align 8
  store i64 %v2068, ptr %slot200, align 8
  %v2069 = load i64, ptr %slot200, align 8
  %v2070 = load i64, ptr %slot197, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2069, i64 %v2070) nomerge, !dbg !134
  br label %bb_rcslotdone228
bb_rcslotowner228:
  %v2071 = load i64, ptr %slot56, align 8
  store i64 %v2071, ptr %slot201, align 8
  %v2072 = load i64, ptr %slot201, align 8
  %v2073 = load i64, ptr %slot197, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2072, i64 %v2073) nomerge, !dbg !134
  br label %bb_rcslotdone228
bb_rcslotdone228:
  %v2074 = load i64, ptr %slot44, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i64, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2076, ptr %slot202, align 8
  %v2077 = load i64, ptr %slot202, align 8
  %op2078 = add i64 %v2077, 0
  store i64 %op2078, ptr %slot203, align 8
  %v2079 = load i64, ptr %slot203, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %ld2081 = load i64, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2081, ptr %slot204, align 8
  %v2082 = load i64, ptr %slot204, align 8
  %v2083 = load i64, ptr %slot44, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i64 %v2082, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot12, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  %ld2087 = load i32, ptr %p2086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2087, ptr %slot205, align 8
  %v2088 = load i32, ptr %slot205, align 8
  %cv2089 = zext i32 %v2088 to i64
  %cond2090 = icmp ne i64 %cv2089, 0
  br i1 %cond2090, label %bb_rcslotdrop240, label %bb_rcslotdone240
bb_rcslotdrop240:
  %v2091 = load i64, ptr %slot12, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  store i32 0, ptr %p2092, align 4, !alias.scope !3, !noalias !4
  %v2093 = load i64, ptr %slot19, align 8
  store i64 %v2093, ptr %slot206, align 8
  %v2094 = load i64, ptr %slot13, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  %ld2096 = load i32, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2096, ptr %slot207, align 8
  %v2097 = load i32, ptr %slot207, align 8
  %op2098 = and i32 %v2097, 28
  store i32 %op2098, ptr %slot208, align 8
  %v2099 = load i32, ptr %slot208, align 8
  %cv2100 = zext i32 %v2099 to i64
  %cond2101 = icmp ne i64 %cv2100, 0
  br i1 %cond2101, label %bb_rcslotrole240, label %bb_rcslotowner240
bb_rcslotrole240:
  %v2102 = load i64, ptr %slot56, align 8
  store i64 %v2102, ptr %slot209, align 8
  %v2103 = load i64, ptr %slot209, align 8
  %v2104 = load i64, ptr %slot206, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2103, i64 %v2104) nomerge, !dbg !136
  br label %bb_rcslotdone240
bb_rcslotowner240:
  %v2105 = load i64, ptr %slot56, align 8
  store i64 %v2105, ptr %slot210, align 8
  %v2106 = load i64, ptr %slot210, align 8
  %v2107 = load i64, ptr %slot206, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2106, i64 %v2107) nomerge, !dbg !136
  br label %bb_rcslotdone240
bb_rcslotdone240:
  %v2108 = load i64, ptr %slot45, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i64 1, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot45, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i64, ptr %p2111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2112, ptr %slot211, align 8
  %v2113 = load i64, ptr %slot44, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %ld2115 = load i64, ptr %p2114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2115, ptr %slot212, align 8
  %v2116 = load i64, ptr %slot212, align 8
  %v2117 = load i64, ptr %slot211, align 8
  %ovpair2119 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2116, i64 %v2117)
  %op2118 = extractvalue { i64, i1 } %ovpair2119, 0
  %ov2120 = extractvalue { i64, i1 } %ovpair2119, 1
  store i64 %op2118, ptr %slot213, align 8
  %cv2121 = zext i1 %ov2120 to i64
  store i64 %cv2121, ptr %slot214, align 8
  %v2122 = load i64, ptr %slot214, align 8
  %cond2123 = icmp ne i64 %v2122, 0
  br i1 %cond2123, label %bb_overflow249, label %bb_checked249
bb_overflow249:
  %v2124 = load i64, ptr %slot1, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %v2126 = load i64, ptr %slot212, align 8
  %v2127 = load i64, ptr %slot211, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2125, i64 0, i64 %v2126, i64 %v2127, i64 64) nomerge, !dbg !138
  unreachable
bb_checked249:
  %v2128 = load i64, ptr %slot213, align 8
  %v2129 = load i64, ptr %slot44, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i64 %v2128, ptr %p2130, align 8, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot44, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i64, ptr %p2132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2133, ptr %slot215, align 8
  %v2134 = load i64, ptr %slot215, align 8
  %v2135 = load i64, ptr %slot36, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i64 %v2134, ptr %p2136, align 8, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot34, align 8
  %v2138 = load i64, ptr %slot44, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  store i64 %v2137, ptr %p2139, align 8, !alias.scope !3, !noalias !4
  %v2140 = load i64, ptr %slot44, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i64, ptr %p2141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2142, ptr %slot216, align 8
  %v2143 = load i64, ptr %slot12, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  %ld2145 = load i32, ptr %p2144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2145, ptr %slot217, align 8
  %v2146 = load i64, ptr %slot13, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  %ld2148 = load i32, ptr %p2147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2148, ptr %slot218, align 8
  %v2149 = load i32, ptr %slot218, align 8
  %op2150 = and i32 %v2149, 24
  store i32 %op2150, ptr %slot218, align 8
  %v2151 = load i32, ptr %slot218, align 8
  %cmp2152 = icmp eq i32 %v2151, 0
  %cv2153 = zext i1 %cmp2152 to i32
  store i32 %cv2153, ptr %slot219, align 8
  %v2154 = load i32, ptr %slot217, align 8
  %v2155 = load i32, ptr %slot219, align 8
  %op2156 = and i32 %v2154, %v2155
  store i32 %op2156, ptr %slot220, align 8
  %v2157 = load i32, ptr %slot220, align 8
  %cv2158 = zext i32 %v2157 to i64
  %cond2159 = icmp ne i64 %cv2158, 0
  br i1 %cond2159, label %bb_rcprivateown259, label %bb_rcprivateloan259
bb_rcprivateown259:
  %v2160 = load i64, ptr %slot23, align 8
  store i64 %v2160, ptr %slot221, align 8
  %v2161 = load i64, ptr %slot57, align 8
  store i64 %v2161, ptr %slot222, align 8
  %v2162 = load i64, ptr %slot56, align 8
  %v2163 = load i64, ptr %slot221, align 8
  %v2164 = load i64, ptr %slot216, align 8
  %v2165 = load i64, ptr %slot222, align 8
  %cv2166 = trunc i64 %v2165 to i32
  %call2167 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2162, i64 %v2163, i64 %v2164, i32 %cv2166) nomerge, !dbg !140
  store i32 %call2167, ptr %slot223, align 8
  %v2168 = load i32, ptr %slot223, align 8
  %cv2169 = zext i32 %v2168 to i64
  %cond2170 = icmp ne i64 %cv2169, 0
  br i1 %cond2170, label %bb_rcsuccess263, label %bb_rcfailure263
bb_rcfailure263:
  %v2171 = load i64, ptr %slot56, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %call2173 = call i32 @myl_rc_take_failure(ptr %p2172) nomerge, !dbg !140
  store i32 %call2173, ptr %slot224, align 8
  %v2174 = load i64, ptr %slot1, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %v2176 = load i32, ptr %slot224, align 8
  %call2177 = call i32 @myl_qbe_rc_status(ptr %p2175, i32 %v2176) nomerge, !dbg !140
  store i32 %call2177, ptr %slot225, align 8
  br label %bb_failure
bb_rcsuccess263:
  %v2178 = load i64, ptr %slot12, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  store i32 0, ptr %p2179, align 4, !alias.scope !3, !noalias !4
  %v2180 = load i64, ptr %slot17, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 2, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot16, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 1, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared259
bb_rcprivateloan259:
  %v2184 = load i64, ptr %slot23, align 8
  store i64 %v2184, ptr %slot226, align 8
  %v2185 = load i64, ptr %slot56, align 8
  %v2186 = load i64, ptr %slot226, align 8
  %v2187 = load i64, ptr %slot216, align 8
  %call2188 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v2185, i64 %v2186, i64 %v2187) nomerge, !dbg !140
  store i32 %call2188, ptr %slot227, align 8
  %v2189 = load i32, ptr %slot227, align 8
  %cv2190 = zext i32 %v2189 to i64
  %cond2191 = icmp ne i64 %cv2190, 0
  br i1 %cond2191, label %bb_rcsuccess271, label %bb_rcfailure271
bb_rcfailure271:
  %v2192 = load i64, ptr %slot56, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %call2194 = call i32 @myl_rc_take_failure(ptr %p2193) nomerge, !dbg !140
  store i32 %call2194, ptr %slot228, align 8
  %v2195 = load i64, ptr %slot1, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  %v2197 = load i32, ptr %slot228, align 8
  %call2198 = call i32 @myl_qbe_rc_status(ptr %p2196, i32 %v2197) nomerge, !dbg !140
  store i32 %call2198, ptr %slot229, align 8
  br label %bb_failure
bb_rcsuccess271:
  %v2199 = load i64, ptr %slot17, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  store i32 2, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  %v2201 = load i64, ptr %slot17, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i32 16, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot16, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  store i32 1, ptr %p2204, align 4, !alias.scope !3, !noalias !4
  %v2205 = load i64, ptr %slot12, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  %ld2207 = load i32, ptr %p2206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2207, ptr %slot230, align 8
  %v2208 = load i32, ptr %slot230, align 8
  %cv2209 = zext i32 %v2208 to i64
  %cond2210 = icmp ne i64 %cv2209, 0
  br i1 %cond2210, label %bb_rcslotdrop279, label %bb_rcslotdone279
bb_rcslotdrop279:
  %v2211 = load i64, ptr %slot12, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  store i32 0, ptr %p2212, align 4, !alias.scope !3, !noalias !4
  %v2213 = load i64, ptr %slot19, align 8
  store i64 %v2213, ptr %slot231, align 8
  %v2214 = load i64, ptr %slot13, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i32, ptr %p2215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2216, ptr %slot232, align 8
  %v2217 = load i32, ptr %slot232, align 8
  %op2218 = and i32 %v2217, 28
  store i32 %op2218, ptr %slot233, align 8
  %v2219 = load i32, ptr %slot233, align 8
  %cv2220 = zext i32 %v2219 to i64
  %cond2221 = icmp ne i64 %cv2220, 0
  br i1 %cond2221, label %bb_rcslotrole279, label %bb_rcslotowner279
bb_rcslotrole279:
  %v2222 = load i64, ptr %slot56, align 8
  store i64 %v2222, ptr %slot234, align 8
  %v2223 = load i64, ptr %slot234, align 8
  %v2224 = load i64, ptr %slot231, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2223, i64 %v2224) nomerge, !dbg !140
  br label %bb_rcslotdone279
bb_rcslotowner279:
  %v2225 = load i64, ptr %slot56, align 8
  store i64 %v2225, ptr %slot235, align 8
  %v2226 = load i64, ptr %slot235, align 8
  %v2227 = load i64, ptr %slot231, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2226, i64 %v2227) nomerge, !dbg !140
  br label %bb_rcslotdone279
bb_rcslotdone279:
  br label %bb_rcprivateprepared259
bb_rcprivateprepared259:
  %v2228 = load i64, ptr %slot6, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  %ld2230 = load i32, ptr %p2229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2230, ptr %slot236, align 8
  %v2231 = load i32, ptr %slot236, align 8
  %cv2232 = zext i32 %v2231 to i64
  %cond2233 = icmp ne i64 %cv2232, 0
  br i1 %cond2233, label %bb_rcslotdrop289, label %bb_rcslotdone289
bb_rcslotdrop289:
  %v2234 = load i64, ptr %slot6, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i32 0, ptr %p2235, align 4, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot35, align 8
  store i64 %v2236, ptr %slot237, align 8
  %v2237 = load i64, ptr %slot7, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  %ld2239 = load i32, ptr %p2238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2239, ptr %slot238, align 8
  %v2240 = load i32, ptr %slot238, align 8
  %op2241 = and i32 %v2240, 28
  store i32 %op2241, ptr %slot239, align 8
  %v2242 = load i32, ptr %slot239, align 8
  %cv2243 = zext i32 %v2242 to i64
  %cond2244 = icmp ne i64 %cv2243, 0
  br i1 %cond2244, label %bb_rcslotrole289, label %bb_rcslotowner289
bb_rcslotrole289:
  %v2245 = load i64, ptr %slot56, align 8
  store i64 %v2245, ptr %slot240, align 8
  %v2246 = load i64, ptr %slot240, align 8
  %v2247 = load i64, ptr %slot237, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2246, i64 %v2247) nomerge, !dbg !140
  br label %bb_rcslotdone289
bb_rcslotowner289:
  %v2248 = load i64, ptr %slot56, align 8
  store i64 %v2248, ptr %slot241, align 8
  %v2249 = load i64, ptr %slot241, align 8
  %v2250 = load i64, ptr %slot237, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2249, i64 %v2250) nomerge, !dbg !140
  br label %bb_rcslotdone289
bb_rcslotdone289:
  %v2251 = load i64, ptr %slot35, align 8
  store i64 %v2251, ptr %slot242, align 8
  %v2252 = load i64, ptr %slot23, align 8
  store i64 %v2252, ptr %slot243, align 8
  %v2253 = load i64, ptr %slot243, align 8
  %v2254 = load i64, ptr %slot242, align 8
  %p2255 = inttoptr i64 %v2253 to ptr
  %p2256 = inttoptr i64 %v2254 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2256, ptr %p2255, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot16, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  store i32 0, ptr %p2258, align 4, !alias.scope !3, !noalias !4
  %v2259 = load i64, ptr %slot7, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i32 2, ptr %p2260, align 4, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot17, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %ld2263 = load i32, ptr %p2262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2263, ptr %slot244, align 8
  %v2264 = load i32, ptr %slot244, align 8
  %v2265 = load i64, ptr %slot7, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i32 %v2264, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot6, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  store i32 1, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  %v2269 = load i64, ptr %slot35, align 8
  %v2270 = load i64, ptr %slot44, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  store i64 %v2269, ptr %p2271, align 8, !alias.scope !3, !noalias !4
  %v2272 = load i64, ptr %slot35, align 8
  %v2273 = load i64, ptr %slot45, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  store i64 %v2272, ptr %p2274, align 8, !alias.scope !3, !noalias !4
  %v2275 = load i64, ptr %slot45, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %ld2277 = load i64, ptr %p2276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2277, ptr %slot245, align 8
  %v2278 = load i64, ptr %slot245, align 8
  %op2279 = add i64 %v2278, 0
  store i64 %op2279, ptr %slot246, align 8
  %v2280 = load i64, ptr %slot246, align 8
  %v2281 = load i64, ptr %slot45, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i64 %v2280, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot45, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  %ld2285 = load i64, ptr %p2284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2285, ptr %slot247, align 8
  %v2286 = load i64, ptr %slot23, align 8
  store i64 %v2286, ptr %slot248, align 8
  %v2287 = load i64, ptr %slot56, align 8
  %v2288 = load i64, ptr %slot248, align 8
  %v2289 = load i64, ptr %slot247, align 8
  %call2290 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v2287, i64 %v2288, i64 %v2289) nomerge, !dbg !142
  store i32 %call2290, ptr %slot249, align 8
  %v2291 = load i32, ptr %slot249, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcsuccess308, label %bb_rcfailure308
bb_rcfailure308:
  %v2294 = load i64, ptr %slot56, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %call2296 = call i32 @myl_rc_take_failure(ptr %p2295) nomerge, !dbg !142
  store i32 %call2296, ptr %slot250, align 8
  %v2297 = load i64, ptr %slot1, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %v2299 = load i32, ptr %slot250, align 8
  %call2300 = call i32 @myl_qbe_rc_status(ptr %p2298, i32 %v2299) nomerge, !dbg !142
  store i32 %call2300, ptr %slot251, align 8
  br label %bb_failure
bb_rcsuccess308:
  %v2301 = load i64, ptr %slot17, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  store i32 2, ptr %p2302, align 4, !alias.scope !3, !noalias !4
  %v2303 = load i64, ptr %slot17, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  store i32 16, ptr %p2304, align 4, !alias.scope !3, !noalias !4
  %v2305 = load i64, ptr %slot16, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  store i32 1, ptr %p2306, align 4, !alias.scope !3, !noalias !4
  %v2307 = load i64, ptr %slot14, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  %ld2309 = load i32, ptr %p2308, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2309, ptr %slot252, align 8
  %v2310 = load i32, ptr %slot252, align 8
  %cv2311 = zext i32 %v2310 to i64
  %cond2312 = icmp ne i64 %cv2311, 0
  br i1 %cond2312, label %bb_rcslotdrop316, label %bb_rcslotdone316
bb_rcslotdrop316:
  %v2313 = load i64, ptr %slot14, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  store i32 0, ptr %p2314, align 4, !alias.scope !3, !noalias !4
  %v2315 = load i64, ptr %slot20, align 8
  store i64 %v2315, ptr %slot253, align 8
  %v2316 = load i64, ptr %slot15, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i32, ptr %p2317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2318, ptr %slot254, align 8
  %v2319 = load i32, ptr %slot254, align 8
  %op2320 = and i32 %v2319, 28
  store i32 %op2320, ptr %slot255, align 8
  %v2321 = load i32, ptr %slot255, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcslotrole316, label %bb_rcslotowner316
bb_rcslotrole316:
  %v2324 = load i64, ptr %slot56, align 8
  store i64 %v2324, ptr %slot256, align 8
  %v2325 = load i64, ptr %slot256, align 8
  %v2326 = load i64, ptr %slot253, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2325, i64 %v2326) nomerge, !dbg !142
  br label %bb_rcslotdone316
bb_rcslotowner316:
  %v2327 = load i64, ptr %slot56, align 8
  store i64 %v2327, ptr %slot257, align 8
  %v2328 = load i64, ptr %slot257, align 8
  %v2329 = load i64, ptr %slot253, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2328, i64 %v2329) nomerge, !dbg !142
  br label %bb_rcslotdone316
bb_rcslotdone316:
  %v2330 = load i64, ptr %slot20, align 8
  store i64 %v2330, ptr %slot258, align 8
  %v2331 = load i64, ptr %slot23, align 8
  store i64 %v2331, ptr %slot259, align 8
  %v2332 = load i64, ptr %slot259, align 8
  %v2333 = load i64, ptr %slot258, align 8
  %p2334 = inttoptr i64 %v2332 to ptr
  %p2335 = inttoptr i64 %v2333 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2335, ptr %p2334, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2336 = load i64, ptr %slot15, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  store i32 2, ptr %p2337, align 4, !alias.scope !3, !noalias !4
  %v2338 = load i64, ptr %slot17, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %ld2340 = load i32, ptr %p2339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2340, ptr %slot260, align 8
  %v2341 = load i32, ptr %slot260, align 8
  %v2342 = load i64, ptr %slot15, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  store i32 %v2341, ptr %p2343, align 4, !alias.scope !3, !noalias !4
  %v2344 = load i64, ptr %slot16, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  store i32 0, ptr %p2345, align 4, !alias.scope !3, !noalias !4
  %v2346 = load i64, ptr %slot14, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i32 1, ptr %p2347, align 4, !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot258, align 8
  %v2349 = load i64, ptr %slot45, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot36, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i64, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2353, ptr %slot261, align 8
  %v2354 = load i64, ptr %slot261, align 8
  %v2355 = load i64, ptr %slot46, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i64 %v2354, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot45, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i64, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2359, ptr %slot262, align 8
  %v2360 = load i64, ptr %slot14, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  %ld2362 = load i32, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2362, ptr %slot263, align 8
  %v2363 = load i64, ptr %slot15, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i32, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2365, ptr %slot264, align 8
  %v2366 = load i32, ptr %slot264, align 8
  %op2367 = and i32 %v2366, 24
  store i32 %op2367, ptr %slot264, align 8
  %v2368 = load i32, ptr %slot264, align 8
  %cmp2369 = icmp eq i32 %v2368, 0
  %cv2370 = zext i1 %cmp2369 to i32
  store i32 %cv2370, ptr %slot265, align 8
  %v2371 = load i32, ptr %slot263, align 8
  %v2372 = load i32, ptr %slot265, align 8
  %op2373 = and i32 %v2371, %v2372
  store i32 %op2373, ptr %slot266, align 8
  %v2374 = load i32, ptr %slot266, align 8
  %cv2375 = zext i32 %v2374 to i64
  %cond2376 = icmp ne i64 %cv2375, 0
  br i1 %cond2376, label %bb_rctake333, label %bb_rccopy333
bb_rctake333:
  %v2377 = load i64, ptr %slot23, align 8
  store i64 %v2377, ptr %slot267, align 8
  %v2378 = load i64, ptr %slot57, align 8
  store i64 %v2378, ptr %slot268, align 8
  %v2379 = load i64, ptr %slot262, align 8
  %v2380 = load i64, ptr %slot267, align 8
  %op2381 = sub i64 %v2379, %v2380
  store i64 %op2381, ptr %slot269, align 8
  %v2382 = load i64, ptr %slot267, align 8
  %v2383 = load i64, ptr %slot262, align 8
  %op2384 = sub i64 %v2382, %v2383
  store i64 %op2384, ptr %slot270, align 8
  %v2385 = load i64, ptr %slot269, align 8
  %cmp2386 = icmp ult i64 %v2385, 48
  %cv2387 = zext i1 %cmp2386 to i32
  store i32 %cv2387, ptr %slot271, align 8
  %v2388 = load i64, ptr %slot270, align 8
  %cmp2389 = icmp ult i64 %v2388, 48
  %cv2390 = zext i1 %cmp2389 to i32
  store i32 %cv2390, ptr %slot272, align 8
  %v2391 = load i32, ptr %slot271, align 8
  %v2392 = load i32, ptr %slot272, align 8
  %op2393 = or i32 %v2391, %v2392
  store i32 %op2393, ptr %slot273, align 8
  %v2394 = load i32, ptr %slot273, align 8
  %cv2395 = zext i32 %v2394 to i64
  %cond2396 = icmp ne i64 %cv2395, 0
  br i1 %cond2396, label %bb_rcmoveslow342, label %bb_rcmovecheck342
bb_rcmovecheck342:
  %v2397 = load i64, ptr %slot262, align 8
  %op2398 = add i64 %v2397, 16
  store i64 %op2398, ptr %slot274, align 8
  %v2399 = load i64, ptr %slot274, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i64, ptr %p2400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2401, ptr %slot275, align 8
  %v2402 = load i64, ptr %slot275, align 8
  %cmp2403 = icmp ne i64 %v2402, 0
  %cv2404 = zext i1 %cmp2403 to i32
  store i32 %cv2404, ptr %slot276, align 8
  %v2405 = load i32, ptr %slot276, align 8
  %cv2406 = zext i32 %v2405 to i64
  %cond2407 = icmp ne i64 %cv2406, 0
  br i1 %cond2407, label %bb_rcmoveheader350, label %bb_rcmovenext350
bb_rcmoveheader350:
  %v2408 = load i64, ptr %slot275, align 8
  %op2409 = sub i64 %v2408, 16
  store i64 %op2409, ptr %slot277, align 8
  %v2410 = load i64, ptr %slot275, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  %rgep2412 = getelementptr i8, ptr %p2411, i64 -16
  %ld2413 = load i64, ptr %rgep2412, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2413, ptr %slot278, align 8
  %v2414 = load i64, ptr %slot278, align 8
  %op2415 = and i64 %v2414, 5764607523034234881
  store i64 %op2415, ptr %slot279, align 8
  %v2416 = load i64, ptr %slot279, align 8
  %cmp2417 = icmp ne i64 %v2416, 0
  %cv2418 = zext i1 %cmp2417 to i32
  store i32 %cv2418, ptr %slot280, align 8
  %v2419 = load i32, ptr %slot280, align 8
  %cv2420 = zext i32 %v2419 to i64
  %cond2421 = icmp ne i64 %cv2420, 0
  br i1 %cond2421, label %bb_rcmoveslow342, label %bb_rcmovenext350
bb_rcmovenext350:
  %v2422 = load i64, ptr %slot262, align 8
  %op2423 = add i64 %v2422, 24
  store i64 %op2423, ptr %slot281, align 8
  %v2424 = load i64, ptr %slot281, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  %ld2426 = load i64, ptr %p2425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2426, ptr %slot282, align 8
  %v2427 = load i64, ptr %slot282, align 8
  %cmp2428 = icmp ne i64 %v2427, 0
  %cv2429 = zext i1 %cmp2428 to i32
  store i32 %cv2429, ptr %slot283, align 8
  %v2430 = load i32, ptr %slot283, align 8
  %cv2431 = zext i32 %v2430 to i64
  %cond2432 = icmp ne i64 %cv2431, 0
  br i1 %cond2432, label %bb_rcmoveheader358, label %bb_rcmovenext358
bb_rcmoveheader358:
  %v2433 = load i64, ptr %slot282, align 8
  %op2434 = sub i64 %v2433, 16
  store i64 %op2434, ptr %slot284, align 8
  %v2435 = load i64, ptr %slot282, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %rgep2437 = getelementptr i8, ptr %p2436, i64 -16
  %ld2438 = load i64, ptr %rgep2437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2438, ptr %slot285, align 8
  %v2439 = load i64, ptr %slot285, align 8
  %op2440 = and i64 %v2439, 5764607523034234881
  store i64 %op2440, ptr %slot286, align 8
  %v2441 = load i64, ptr %slot286, align 8
  %cmp2442 = icmp ne i64 %v2441, 0
  %cv2443 = zext i1 %cmp2442 to i32
  store i32 %cv2443, ptr %slot287, align 8
  %v2444 = load i32, ptr %slot287, align 8
  %cv2445 = zext i32 %v2444 to i64
  %cond2446 = icmp ne i64 %cv2445, 0
  br i1 %cond2446, label %bb_rcmoveslow342, label %bb_rcmovenext358
bb_rcmovenext358:
  %v2447 = load i64, ptr %slot262, align 8
  %op2448 = add i64 %v2447, 32
  store i64 %op2448, ptr %slot288, align 8
  %v2449 = load i64, ptr %slot288, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  %ld2451 = load i64, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2451, ptr %slot289, align 8
  %v2452 = load i64, ptr %slot289, align 8
  %cmp2453 = icmp ne i64 %v2452, 0
  %cv2454 = zext i1 %cmp2453 to i32
  store i32 %cv2454, ptr %slot290, align 8
  %v2455 = load i32, ptr %slot290, align 8
  %cv2456 = zext i32 %v2455 to i64
  %cond2457 = icmp ne i64 %cv2456, 0
  br i1 %cond2457, label %bb_rcmoveheader366, label %bb_rcmovenext366
bb_rcmoveheader366:
  %v2458 = load i64, ptr %slot289, align 8
  %op2459 = sub i64 %v2458, 16
  store i64 %op2459, ptr %slot291, align 8
  %v2460 = load i64, ptr %slot289, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  %rgep2462 = getelementptr i8, ptr %p2461, i64 -16
  %ld2463 = load i64, ptr %rgep2462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2463, ptr %slot292, align 8
  %v2464 = load i64, ptr %slot292, align 8
  %op2465 = and i64 %v2464, 5764607523034234881
  store i64 %op2465, ptr %slot293, align 8
  %v2466 = load i64, ptr %slot293, align 8
  %cmp2467 = icmp ne i64 %v2466, 0
  %cv2468 = zext i1 %cmp2467 to i32
  store i32 %cv2468, ptr %slot294, align 8
  %v2469 = load i32, ptr %slot294, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rcmoveslow342, label %bb_rcmovenext366
bb_rcmovenext366:
  %v2472 = load i64, ptr %slot262, align 8
  %v2473 = load i64, ptr %slot267, align 8
  %p2474 = inttoptr i64 %v2472 to ptr
  %p2475 = inttoptr i64 %v2473 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2475, ptr %p2474, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2476 = load i64, ptr %slot262, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i64 0, ptr %p2477, align 8, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot262, align 8
  %op2479 = add i64 %v2478, 8
  store i64 %op2479, ptr %slot295, align 8
  %v2480 = load i64, ptr %slot295, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  store i64 0, ptr %p2481, align 8, !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot262, align 8
  %op2483 = add i64 %v2482, 16
  store i64 %op2483, ptr %slot296, align 8
  %v2484 = load i64, ptr %slot296, align 8
  %p2485 = inttoptr i64 %v2484 to ptr
  store i64 0, ptr %p2485, align 8, !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot262, align 8
  %op2487 = add i64 %v2486, 24
  store i64 %op2487, ptr %slot297, align 8
  %v2488 = load i64, ptr %slot297, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i64 0, ptr %p2489, align 8, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot262, align 8
  %op2491 = add i64 %v2490, 32
  store i64 %op2491, ptr %slot298, align 8
  %v2492 = load i64, ptr %slot298, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i64 0, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  %v2494 = load i64, ptr %slot262, align 8
  %op2495 = add i64 %v2494, 40
  store i64 %op2495, ptr %slot299, align 8
  %v2496 = load i64, ptr %slot299, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  store i64 0, ptr %p2497, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved342
bb_rcmoveslow342:
  %v2498 = load i64, ptr %slot56, align 8
  %v2499 = load i64, ptr %slot267, align 8
  %v2500 = load i64, ptr %slot262, align 8
  %v2501 = load i64, ptr %slot268, align 8
  %cv2502 = trunc i64 %v2501 to i32
  %call2503 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2498, i64 %v2499, i64 %v2500, i32 %cv2502) nomerge, !dbg !144
  store i32 %call2503, ptr %slot300, align 8
  %v2504 = load i32, ptr %slot300, align 8
  %cv2505 = zext i32 %v2504 to i64
  %cond2506 = icmp ne i64 %cv2505, 0
  br i1 %cond2506, label %bb_rcsuccess378, label %bb_rcfailure378
bb_rcfailure378:
  %v2507 = load i64, ptr %slot56, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %call2509 = call i32 @myl_rc_take_failure(ptr %p2508) nomerge, !dbg !144
  store i32 %call2509, ptr %slot301, align 8
  %v2510 = load i64, ptr %slot1, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %v2512 = load i32, ptr %slot301, align 8
  %call2513 = call i32 @myl_qbe_rc_status(ptr %p2511, i32 %v2512) nomerge, !dbg !144
  store i32 %call2513, ptr %slot302, align 8
  br label %bb_failure
bb_rcsuccess378:
  br label %bb_rcmoved342
bb_rcmoved342:
  %v2514 = load i64, ptr %slot14, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  store i32 0, ptr %p2515, align 4, !alias.scope !3, !noalias !4
  %v2516 = load i64, ptr %slot17, align 8
  %p2517 = inttoptr i64 %v2516 to ptr
  store i32 2, ptr %p2517, align 4, !alias.scope !3, !noalias !4
  %v2518 = load i64, ptr %slot16, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  store i32 1, ptr %p2519, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared333
bb_rccopy333:
  %v2520 = load i64, ptr %slot23, align 8
  store i64 %v2520, ptr %slot303, align 8
  %v2521 = load i64, ptr %slot57, align 8
  store i64 %v2521, ptr %slot304, align 8
  %v2522 = load i64, ptr %slot56, align 8
  %v2523 = load i64, ptr %slot303, align 8
  %v2524 = load i64, ptr %slot262, align 8
  %v2525 = load i64, ptr %slot304, align 8
  %cv2526 = trunc i64 %v2525 to i32
  %call2527 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v2522, i64 %v2523, i64 %v2524, i32 %cv2526) nomerge, !dbg !144
  store i32 %call2527, ptr %slot305, align 8
  %v2528 = load i32, ptr %slot305, align 8
  %cv2529 = zext i32 %v2528 to i64
  %cond2530 = icmp ne i64 %cv2529, 0
  br i1 %cond2530, label %bb_rcsuccess387, label %bb_rcfailure387
bb_rcfailure387:
  %v2531 = load i64, ptr %slot56, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %call2533 = call i32 @myl_rc_take_failure(ptr %p2532) nomerge, !dbg !144
  store i32 %call2533, ptr %slot306, align 8
  %v2534 = load i64, ptr %slot1, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  %v2536 = load i32, ptr %slot306, align 8
  %call2537 = call i32 @myl_qbe_rc_status(ptr %p2535, i32 %v2536) nomerge, !dbg !144
  store i32 %call2537, ptr %slot307, align 8
  br label %bb_failure
bb_rcsuccess387:
  %v2538 = load i64, ptr %slot17, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  store i32 2, ptr %p2539, align 4, !alias.scope !3, !noalias !4
  %v2540 = load i64, ptr %slot16, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  store i32 1, ptr %p2541, align 4, !alias.scope !3, !noalias !4
  %v2542 = load i64, ptr %slot14, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  %ld2544 = load i32, ptr %p2543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2544, ptr %slot308, align 8
  %v2545 = load i32, ptr %slot308, align 8
  %cv2546 = zext i32 %v2545 to i64
  %cond2547 = icmp ne i64 %cv2546, 0
  br i1 %cond2547, label %bb_rcslotdrop394, label %bb_rcslotdone394
bb_rcslotdrop394:
  %v2548 = load i64, ptr %slot14, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  store i32 0, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  %v2550 = load i64, ptr %slot20, align 8
  store i64 %v2550, ptr %slot309, align 8
  %v2551 = load i64, ptr %slot15, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i32, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2553, ptr %slot310, align 8
  %v2554 = load i32, ptr %slot310, align 8
  %op2555 = and i32 %v2554, 28
  store i32 %op2555, ptr %slot311, align 8
  %v2556 = load i32, ptr %slot311, align 8
  %cv2557 = zext i32 %v2556 to i64
  %cond2558 = icmp ne i64 %cv2557, 0
  br i1 %cond2558, label %bb_rcslotrole394, label %bb_rcslotowner394
bb_rcslotrole394:
  %v2559 = load i64, ptr %slot56, align 8
  store i64 %v2559, ptr %slot312, align 8
  %v2560 = load i64, ptr %slot312, align 8
  %v2561 = load i64, ptr %slot309, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2560, i64 %v2561) nomerge, !dbg !144
  br label %bb_rcslotdone394
bb_rcslotowner394:
  %v2562 = load i64, ptr %slot56, align 8
  store i64 %v2562, ptr %slot313, align 8
  %v2563 = load i64, ptr %slot313, align 8
  %v2564 = load i64, ptr %slot309, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2563, i64 %v2564) nomerge, !dbg !144
  br label %bb_rcslotdone394
bb_rcslotdone394:
  br label %bb_rcprepared333
bb_rcprepared333:
  %v2565 = load i64, ptr %slot23, align 8
  store i64 %v2565, ptr %slot314, align 8
  %v2566 = load i64, ptr %slot47, align 8
  store i64 %v2566, ptr %slot315, align 8
  %v2567 = load i64, ptr %slot314, align 8
  %v2568 = load i64, ptr %slot315, align 8
  %p2569 = inttoptr i64 %v2567 to ptr
  %p2570 = inttoptr i64 %v2568 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2570, ptr %p2569, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot16, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i32 0, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot18, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  store i32 1, ptr %p2574, align 4, !alias.scope !3, !noalias !4
  %v2575 = load i64, ptr %slot57, align 8
  store i64 %v2575, ptr %slot316, align 8
  %v2576 = load i64, ptr %slot46, align 8
  store i64 %v2576, ptr %slot317, align 8
  %v2577 = load i64, ptr %slot315, align 8
  %p2579 = inttoptr i64 %v2577 to ptr
  %gep2580 = getelementptr i8, ptr %p2579, i64 0
  %op2578 = ptrtoint ptr %gep2580 to i64
  store i64 %op2578, ptr %slot318, align 8
  %v2581 = load i64, ptr %slot317, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  %ld2583 = load i64, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2583, ptr %slot319, align 8
  %v2584 = load i64, ptr %slot319, align 8
  %v2585 = load i64, ptr %slot318, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i64 %v2584, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot315, align 8
  %v2588 = load i64, ptr %slot45, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  store i64 %v2587, ptr %p2589, align 8, !alias.scope !3, !noalias !4
  %v2590 = load i64, ptr %slot45, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  %ld2592 = load i64, ptr %p2591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2592, ptr %slot320, align 8
  %v2593 = load i64, ptr %slot23, align 8
  store i64 %v2593, ptr %slot321, align 8
  %v2594 = load i64, ptr %slot320, align 8
  %v2595 = load i64, ptr %slot321, align 8
  %p2596 = inttoptr i64 %v2594 to ptr
  %p2597 = inttoptr i64 %v2595 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2597, ptr %p2596, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot17, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  store i32 2, ptr %p2599, align 4, !alias.scope !3, !noalias !4
  %v2600 = load i64, ptr %slot16, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  store i32 1, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  %v2602 = load i64, ptr %slot14, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  %ld2604 = load i32, ptr %p2603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2604, ptr %slot322, align 8
  %v2605 = load i32, ptr %slot322, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcslotdrop416, label %bb_rcslotdone416
bb_rcslotdrop416:
  %v2608 = load i64, ptr %slot14, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i32 0, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot20, align 8
  store i64 %v2610, ptr %slot323, align 8
  %v2611 = load i64, ptr %slot15, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i32, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2613, ptr %slot324, align 8
  %v2614 = load i32, ptr %slot324, align 8
  %op2615 = and i32 %v2614, 28
  store i32 %op2615, ptr %slot325, align 8
  %v2616 = load i32, ptr %slot325, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcslotrole416, label %bb_rcslotowner416
bb_rcslotrole416:
  %v2619 = load i64, ptr %slot56, align 8
  store i64 %v2619, ptr %slot326, align 8
  %v2620 = load i64, ptr %slot326, align 8
  %v2621 = load i64, ptr %slot323, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2620, i64 %v2621) nomerge, !dbg !144
  br label %bb_rcslotdone416
bb_rcslotowner416:
  %v2622 = load i64, ptr %slot56, align 8
  store i64 %v2622, ptr %slot327, align 8
  %v2623 = load i64, ptr %slot327, align 8
  %v2624 = load i64, ptr %slot323, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2623, i64 %v2624) nomerge, !dbg !144
  br label %bb_rcslotdone416
bb_rcslotdone416:
  %v2625 = load i64, ptr %slot20, align 8
  store i64 %v2625, ptr %slot328, align 8
  %v2626 = load i64, ptr %slot23, align 8
  store i64 %v2626, ptr %slot329, align 8
  %v2627 = load i64, ptr %slot329, align 8
  %v2628 = load i64, ptr %slot328, align 8
  %p2629 = inttoptr i64 %v2627 to ptr
  %p2630 = inttoptr i64 %v2628 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2630, ptr %p2629, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot15, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  store i32 2, ptr %p2632, align 4, !alias.scope !3, !noalias !4
  %v2633 = load i64, ptr %slot17, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %ld2635 = load i32, ptr %p2634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2635, ptr %slot330, align 8
  %v2636 = load i32, ptr %slot330, align 8
  %v2637 = load i64, ptr %slot15, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 %v2636, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot16, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 0, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot14, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  store i32 1, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  %v2643 = load i64, ptr %slot328, align 8
  %v2644 = load i64, ptr %slot45, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i64 %v2643, ptr %p2645, align 8, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot45, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  %ld2648 = load i64, ptr %p2647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2648, ptr %slot331, align 8
  %v2649 = load i64, ptr %slot14, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  %ld2651 = load i32, ptr %p2650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2651, ptr %slot332, align 8
  %v2652 = load i64, ptr %slot15, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %ld2654 = load i32, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2654, ptr %slot333, align 8
  %v2655 = load i32, ptr %slot333, align 8
  %op2656 = and i32 %v2655, 24
  store i32 %op2656, ptr %slot333, align 8
  %v2657 = load i32, ptr %slot333, align 8
  %cmp2658 = icmp eq i32 %v2657, 0
  %cv2659 = zext i1 %cmp2658 to i32
  store i32 %cv2659, ptr %slot334, align 8
  %v2660 = load i32, ptr %slot332, align 8
  %v2661 = load i32, ptr %slot334, align 8
  %op2662 = and i32 %v2660, %v2661
  store i32 %op2662, ptr %slot335, align 8
  %v2663 = load i64, ptr %slot57, align 8
  store i64 %v2663, ptr %slot336, align 8
  %v2664 = load i32, ptr %slot335, align 8
  %op2665 = mul i32 %v2664, 4
  store i32 %op2665, ptr %slot337, align 8
  %v2666 = load i32, ptr %slot337, align 8
  %op2667 = or i32 %v2666, 0
  store i32 %op2667, ptr %slot338, align 8
  %v2668 = load i64, ptr %slot23, align 8
  store i64 %v2668, ptr %slot339, align 8
  %v2669 = load i64, ptr %slot56, align 8
  %v2670 = load i64, ptr %slot339, align 8
  %v2671 = load i64, ptr %slot331, align 8
  %v2672 = load i64, ptr %slot336, align 8
  %cv2673 = trunc i64 %v2672 to i32
  %v2674 = load i32, ptr %slot338, align 8
  %call2675 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v2669, i64 %v2670, i64 %v2671, i32 %cv2673, i32 %v2674) nomerge, !dbg !146
  store i32 %call2675, ptr %slot340, align 8
  %v2676 = load i32, ptr %slot340, align 8
  %cv2677 = zext i32 %v2676 to i64
  %cond2678 = icmp ne i64 %cv2677, 0
  br i1 %cond2678, label %bb_rcsuccess445, label %bb_rcfailure445
bb_rcfailure445:
  %v2679 = load i64, ptr %slot56, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %call2681 = call i32 @myl_rc_take_failure(ptr %p2680) nomerge, !dbg !146
  store i32 %call2681, ptr %slot341, align 8
  %v2682 = load i64, ptr %slot1, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  %v2684 = load i32, ptr %slot341, align 8
  %call2685 = call i32 @myl_qbe_rc_status(ptr %p2683, i32 %v2684) nomerge, !dbg !146
  store i32 %call2685, ptr %slot342, align 8
  br label %bb_failure
bb_rcsuccess445:
  %v2686 = load i32, ptr %slot335, align 8
  %cv2687 = zext i32 %v2686 to i64
  %cond2688 = icmp ne i64 %cv2687, 0
  br i1 %cond2688, label %bb_rchtaken448, label %bb_rchcopied448
bb_rchcopied448:
  %v2689 = load i64, ptr %slot14, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  %ld2691 = load i32, ptr %p2690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2691, ptr %slot343, align 8
  %v2692 = load i32, ptr %slot343, align 8
  %cv2693 = zext i32 %v2692 to i64
  %cond2694 = icmp ne i64 %cv2693, 0
  br i1 %cond2694, label %bb_rcslotdrop451, label %bb_rcslotdone451
bb_rcslotdrop451:
  %v2695 = load i64, ptr %slot14, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  store i32 0, ptr %p2696, align 4, !alias.scope !3, !noalias !4
  %v2697 = load i64, ptr %slot20, align 8
  store i64 %v2697, ptr %slot344, align 8
  %v2698 = load i64, ptr %slot15, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  %ld2700 = load i32, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2700, ptr %slot345, align 8
  %v2701 = load i32, ptr %slot345, align 8
  %op2702 = and i32 %v2701, 28
  store i32 %op2702, ptr %slot346, align 8
  %v2703 = load i32, ptr %slot346, align 8
  %cv2704 = zext i32 %v2703 to i64
  %cond2705 = icmp ne i64 %cv2704, 0
  br i1 %cond2705, label %bb_rcslotrole451, label %bb_rcslotowner451
bb_rcslotrole451:
  %v2706 = load i64, ptr %slot56, align 8
  store i64 %v2706, ptr %slot347, align 8
  %v2707 = load i64, ptr %slot347, align 8
  %v2708 = load i64, ptr %slot344, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2707, i64 %v2708) nomerge, !dbg !146
  br label %bb_rcslotdone451
bb_rcslotowner451:
  %v2709 = load i64, ptr %slot56, align 8
  store i64 %v2709, ptr %slot348, align 8
  %v2710 = load i64, ptr %slot348, align 8
  %v2711 = load i64, ptr %slot344, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2710, i64 %v2711) nomerge, !dbg !146
  br label %bb_rcslotdone451
bb_rcslotdone451:
  br label %bb_rchprepared448
bb_rchtaken448:
  %v2712 = load i64, ptr %slot14, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  store i32 0, ptr %p2713, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared448
bb_rchprepared448:
  %v2714 = load i64, ptr %slot17, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  store i32 2, ptr %p2715, align 4, !alias.scope !3, !noalias !4
  %v2716 = load i64, ptr %slot16, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  store i32 1, ptr %p2717, align 4, !alias.scope !3, !noalias !4
  %v2718 = load i64, ptr %slot20, align 8
  store i64 %v2718, ptr %slot349, align 8
  %v2719 = load i64, ptr %slot23, align 8
  store i64 %v2719, ptr %slot350, align 8
  %v2720 = load i64, ptr %slot350, align 8
  %v2721 = load i64, ptr %slot349, align 8
  %p2722 = inttoptr i64 %v2720 to ptr
  %p2723 = inttoptr i64 %v2721 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2723, ptr %p2722, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2724 = load i64, ptr %slot15, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  store i32 2, ptr %p2725, align 4, !alias.scope !3, !noalias !4
  %v2726 = load i64, ptr %slot17, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  %ld2728 = load i32, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2728, ptr %slot351, align 8
  %v2729 = load i32, ptr %slot351, align 8
  %v2730 = load i64, ptr %slot15, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  store i32 %v2729, ptr %p2731, align 4, !alias.scope !3, !noalias !4
  %v2732 = load i64, ptr %slot16, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  store i32 0, ptr %p2733, align 4, !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot14, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  store i32 1, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  %v2736 = load i64, ptr %slot349, align 8
  %v2737 = load i64, ptr %slot45, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i64 %v2736, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot44, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  %ld2741 = load i64, ptr %p2740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2741, ptr %slot352, align 8
  %v2742 = load i64, ptr %slot12, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  %ld2744 = load i32, ptr %p2743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2744, ptr %slot353, align 8
  %v2745 = load i64, ptr %slot13, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i32, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2747, ptr %slot354, align 8
  %v2748 = load i32, ptr %slot354, align 8
  %op2749 = and i32 %v2748, 24
  store i32 %op2749, ptr %slot354, align 8
  %v2750 = load i32, ptr %slot354, align 8
  %cmp2751 = icmp eq i32 %v2750, 0
  %cv2752 = zext i1 %cmp2751 to i32
  store i32 %cv2752, ptr %slot355, align 8
  %v2753 = load i32, ptr %slot353, align 8
  %v2754 = load i32, ptr %slot355, align 8
  %op2755 = and i32 %v2753, %v2754
  store i32 %op2755, ptr %slot356, align 8
  %v2756 = load i32, ptr %slot356, align 8
  %cv2757 = zext i32 %v2756 to i64
  %cond2758 = icmp ne i64 %cv2757, 0
  br i1 %cond2758, label %bb_rctake470, label %bb_rccopy470
bb_rctake470:
  %v2759 = load i64, ptr %slot23, align 8
  store i64 %v2759, ptr %slot357, align 8
  %v2760 = load i64, ptr %slot57, align 8
  store i64 %v2760, ptr %slot358, align 8
  %v2761 = load i64, ptr %slot56, align 8
  %v2762 = load i64, ptr %slot357, align 8
  %v2763 = load i64, ptr %slot352, align 8
  %v2764 = load i64, ptr %slot358, align 8
  %cv2765 = trunc i64 %v2764 to i32
  %call2766 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2761, i64 %v2762, i64 %v2763, i32 %cv2765) nomerge, !dbg !148
  store i32 %call2766, ptr %slot359, align 8
  %v2767 = load i32, ptr %slot359, align 8
  %cv2768 = zext i32 %v2767 to i64
  %cond2769 = icmp ne i64 %cv2768, 0
  br i1 %cond2769, label %bb_rcsuccess480, label %bb_rcfailure480
bb_rcfailure480:
  %v2770 = load i64, ptr %slot56, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  %call2772 = call i32 @myl_rc_take_failure(ptr %p2771) nomerge, !dbg !148
  store i32 %call2772, ptr %slot360, align 8
  %v2773 = load i64, ptr %slot1, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %v2775 = load i32, ptr %slot360, align 8
  %call2776 = call i32 @myl_qbe_rc_status(ptr %p2774, i32 %v2775) nomerge, !dbg !148
  store i32 %call2776, ptr %slot361, align 8
  br label %bb_failure
bb_rcsuccess480:
  %v2777 = load i64, ptr %slot12, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  store i32 0, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot17, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  store i32 2, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  %v2781 = load i64, ptr %slot16, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i32 1, ptr %p2782, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared470
bb_rccopy470:
  %v2783 = load i64, ptr %slot23, align 8
  store i64 %v2783, ptr %slot362, align 8
  %v2784 = load i64, ptr %slot57, align 8
  store i64 %v2784, ptr %slot363, align 8
  %v2785 = load i64, ptr %slot56, align 8
  %v2786 = load i64, ptr %slot362, align 8
  %v2787 = load i64, ptr %slot352, align 8
  %v2788 = load i64, ptr %slot363, align 8
  %cv2789 = trunc i64 %v2788 to i32
  %call2790 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v2785, i64 %v2786, i64 %v2787, i32 %cv2789) nomerge, !dbg !148
  store i32 %call2790, ptr %slot364, align 8
  %v2791 = load i32, ptr %slot364, align 8
  %cv2792 = zext i32 %v2791 to i64
  %cond2793 = icmp ne i64 %cv2792, 0
  br i1 %cond2793, label %bb_rcsuccess489, label %bb_rcfailure489
bb_rcfailure489:
  %v2794 = load i64, ptr %slot56, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %call2796 = call i32 @myl_rc_take_failure(ptr %p2795) nomerge, !dbg !148
  store i32 %call2796, ptr %slot365, align 8
  %v2797 = load i64, ptr %slot1, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %v2799 = load i32, ptr %slot365, align 8
  %call2800 = call i32 @myl_qbe_rc_status(ptr %p2798, i32 %v2799) nomerge, !dbg !148
  store i32 %call2800, ptr %slot366, align 8
  br label %bb_failure
bb_rcsuccess489:
  %v2801 = load i64, ptr %slot17, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i32 2, ptr %p2802, align 4, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot16, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  store i32 1, ptr %p2804, align 4, !alias.scope !3, !noalias !4
  %v2805 = load i64, ptr %slot12, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %ld2807 = load i32, ptr %p2806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2807, ptr %slot367, align 8
  %v2808 = load i32, ptr %slot367, align 8
  %cv2809 = zext i32 %v2808 to i64
  %cond2810 = icmp ne i64 %cv2809, 0
  br i1 %cond2810, label %bb_rcslotdrop496, label %bb_rcslotdone496
bb_rcslotdrop496:
  %v2811 = load i64, ptr %slot12, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  store i32 0, ptr %p2812, align 4, !alias.scope !3, !noalias !4
  %v2813 = load i64, ptr %slot19, align 8
  store i64 %v2813, ptr %slot368, align 8
  %v2814 = load i64, ptr %slot13, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  %ld2816 = load i32, ptr %p2815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2816, ptr %slot369, align 8
  %v2817 = load i32, ptr %slot369, align 8
  %op2818 = and i32 %v2817, 28
  store i32 %op2818, ptr %slot370, align 8
  %v2819 = load i32, ptr %slot370, align 8
  %cv2820 = zext i32 %v2819 to i64
  %cond2821 = icmp ne i64 %cv2820, 0
  br i1 %cond2821, label %bb_rcslotrole496, label %bb_rcslotowner496
bb_rcslotrole496:
  %v2822 = load i64, ptr %slot56, align 8
  store i64 %v2822, ptr %slot371, align 8
  %v2823 = load i64, ptr %slot371, align 8
  %v2824 = load i64, ptr %slot368, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2823, i64 %v2824) nomerge, !dbg !148
  br label %bb_rcslotdone496
bb_rcslotowner496:
  %v2825 = load i64, ptr %slot56, align 8
  store i64 %v2825, ptr %slot372, align 8
  %v2826 = load i64, ptr %slot372, align 8
  %v2827 = load i64, ptr %slot368, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2826, i64 %v2827) nomerge, !dbg !148
  br label %bb_rcslotdone496
bb_rcslotdone496:
  br label %bb_rcprepared470
bb_rcprepared470:
  %v2828 = load i64, ptr %slot23, align 8
  store i64 %v2828, ptr %slot373, align 8
  %v2829 = load i64, ptr %slot48, align 8
  store i64 %v2829, ptr %slot374, align 8
  %v2830 = load i64, ptr %slot373, align 8
  %v2831 = load i64, ptr %slot374, align 8
  %p2832 = inttoptr i64 %v2830 to ptr
  %p2833 = inttoptr i64 %v2831 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2833, ptr %p2832, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2834 = load i64, ptr %slot16, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  store i32 0, ptr %p2835, align 4, !alias.scope !3, !noalias !4
  %v2836 = load i64, ptr %slot18, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  store i32 1, ptr %p2837, align 4, !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot57, align 8
  store i64 %v2838, ptr %slot375, align 8
  %v2839 = load i64, ptr %slot45, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  %ld2841 = load i64, ptr %p2840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2841, ptr %slot376, align 8
  %v2842 = load i64, ptr %slot374, align 8
  %p2844 = inttoptr i64 %v2842 to ptr
  %gep2845 = getelementptr i8, ptr %p2844, i64 0
  %op2843 = ptrtoint ptr %gep2845 to i64
  store i64 %op2843, ptr %slot377, align 8
  %v2846 = load i64, ptr %slot23, align 8
  store i64 %v2846, ptr %slot378, align 8
  %v2847 = load i64, ptr %slot45, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i64, ptr %p2848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2849, ptr %slot379, align 8
  %v2850 = load i64, ptr %slot23, align 8
  store i64 %v2850, ptr %slot380, align 8
  %v2851 = load i64, ptr %slot57, align 8
  store i64 %v2851, ptr %slot381, align 8
  %v2852 = load i64, ptr %slot379, align 8
  %op2853 = add i64 %v2852, 16
  store i64 %op2853, ptr %slot382, align 8
  %v2854 = load i64, ptr %slot382, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  %ld2856 = load i64, ptr %p2855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2856, ptr %slot383, align 8
  %v2857 = load i64, ptr %slot383, align 8
  %cmp2858 = icmp ne i64 %v2857, 0
  %cv2859 = zext i1 %cmp2858 to i32
  store i32 %cv2859, ptr %slot384, align 8
  %v2860 = load i32, ptr %slot384, align 8
  %cv2861 = zext i32 %v2860 to i64
  %cond2862 = icmp ne i64 %cv2861, 0
  br i1 %cond2862, label %bb_rcmoveheader518, label %bb_rcmovenext518
bb_rcmoveheader518:
  %v2863 = load i64, ptr %slot383, align 8
  %op2864 = sub i64 %v2863, 16
  store i64 %op2864, ptr %slot385, align 8
  %v2865 = load i64, ptr %slot383, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %rgep2867 = getelementptr i8, ptr %p2866, i64 -16
  %ld2868 = load i64, ptr %rgep2867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2868, ptr %slot386, align 8
  %v2869 = load i64, ptr %slot386, align 8
  %op2870 = and i64 %v2869, 5764607523034234881
  store i64 %op2870, ptr %slot387, align 8
  %v2871 = load i64, ptr %slot387, align 8
  %cmp2872 = icmp ne i64 %v2871, 0
  %cv2873 = zext i1 %cmp2872 to i32
  store i32 %cv2873, ptr %slot388, align 8
  %v2874 = load i32, ptr %slot388, align 8
  %cv2875 = zext i32 %v2874 to i64
  %cond2876 = icmp ne i64 %cv2875, 0
  br i1 %cond2876, label %bb_rcmoveslow515, label %bb_rcmovenext518
bb_rcmovenext518:
  %v2877 = load i64, ptr %slot379, align 8
  %op2878 = add i64 %v2877, 24
  store i64 %op2878, ptr %slot389, align 8
  %v2879 = load i64, ptr %slot389, align 8
  %p2880 = inttoptr i64 %v2879 to ptr
  %ld2881 = load i64, ptr %p2880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2881, ptr %slot390, align 8
  %v2882 = load i64, ptr %slot390, align 8
  %cmp2883 = icmp ne i64 %v2882, 0
  %cv2884 = zext i1 %cmp2883 to i32
  store i32 %cv2884, ptr %slot391, align 8
  %v2885 = load i32, ptr %slot391, align 8
  %cv2886 = zext i32 %v2885 to i64
  %cond2887 = icmp ne i64 %cv2886, 0
  br i1 %cond2887, label %bb_rcmoveheader526, label %bb_rcmovenext526
bb_rcmoveheader526:
  %v2888 = load i64, ptr %slot390, align 8
  %op2889 = sub i64 %v2888, 16
  store i64 %op2889, ptr %slot392, align 8
  %v2890 = load i64, ptr %slot390, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %rgep2892 = getelementptr i8, ptr %p2891, i64 -16
  %ld2893 = load i64, ptr %rgep2892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2893, ptr %slot393, align 8
  %v2894 = load i64, ptr %slot393, align 8
  %op2895 = and i64 %v2894, 5764607523034234881
  store i64 %op2895, ptr %slot394, align 8
  %v2896 = load i64, ptr %slot394, align 8
  %cmp2897 = icmp ne i64 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot395, align 8
  %v2899 = load i32, ptr %slot395, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcmoveslow515, label %bb_rcmovenext526
bb_rcmovenext526:
  %v2902 = load i64, ptr %slot379, align 8
  %op2903 = add i64 %v2902, 32
  store i64 %op2903, ptr %slot396, align 8
  %v2904 = load i64, ptr %slot396, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  %ld2906 = load i64, ptr %p2905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2906, ptr %slot397, align 8
  %v2907 = load i64, ptr %slot397, align 8
  %cmp2908 = icmp ne i64 %v2907, 0
  %cv2909 = zext i1 %cmp2908 to i32
  store i32 %cv2909, ptr %slot398, align 8
  %v2910 = load i32, ptr %slot398, align 8
  %cv2911 = zext i32 %v2910 to i64
  %cond2912 = icmp ne i64 %cv2911, 0
  br i1 %cond2912, label %bb_rcmoveheader534, label %bb_rcmovenext534
bb_rcmoveheader534:
  %v2913 = load i64, ptr %slot397, align 8
  %op2914 = sub i64 %v2913, 16
  store i64 %op2914, ptr %slot399, align 8
  %v2915 = load i64, ptr %slot397, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %rgep2917 = getelementptr i8, ptr %p2916, i64 -16
  %ld2918 = load i64, ptr %rgep2917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2918, ptr %slot400, align 8
  %v2919 = load i64, ptr %slot400, align 8
  %op2920 = and i64 %v2919, 5764607523034234881
  store i64 %op2920, ptr %slot401, align 8
  %v2921 = load i64, ptr %slot401, align 8
  %cmp2922 = icmp ne i64 %v2921, 0
  %cv2923 = zext i1 %cmp2922 to i32
  store i32 %cv2923, ptr %slot402, align 8
  %v2924 = load i32, ptr %slot402, align 8
  %cv2925 = zext i32 %v2924 to i64
  %cond2926 = icmp ne i64 %cv2925, 0
  br i1 %cond2926, label %bb_rcmoveslow515, label %bb_rcmovenext534
bb_rcmovenext534:
  %v2927 = load i64, ptr %slot379, align 8
  %v2928 = load i64, ptr %slot380, align 8
  %p2929 = inttoptr i64 %v2927 to ptr
  %p2930 = inttoptr i64 %v2928 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2930, ptr %p2929, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2931 = load i64, ptr %slot379, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  store i64 0, ptr %p2932, align 8, !alias.scope !3, !noalias !4
  %v2933 = load i64, ptr %slot379, align 8
  %op2934 = add i64 %v2933, 8
  store i64 %op2934, ptr %slot403, align 8
  %v2935 = load i64, ptr %slot403, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i64 0, ptr %p2936, align 8, !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot379, align 8
  %op2938 = add i64 %v2937, 16
  store i64 %op2938, ptr %slot404, align 8
  %v2939 = load i64, ptr %slot404, align 8
  %p2940 = inttoptr i64 %v2939 to ptr
  store i64 0, ptr %p2940, align 8, !alias.scope !3, !noalias !4
  %v2941 = load i64, ptr %slot379, align 8
  %op2942 = add i64 %v2941, 24
  store i64 %op2942, ptr %slot405, align 8
  %v2943 = load i64, ptr %slot405, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  store i64 0, ptr %p2944, align 8, !alias.scope !3, !noalias !4
  %v2945 = load i64, ptr %slot379, align 8
  %op2946 = add i64 %v2945, 32
  store i64 %op2946, ptr %slot406, align 8
  %v2947 = load i64, ptr %slot406, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  store i64 0, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot379, align 8
  %op2950 = add i64 %v2949, 40
  store i64 %op2950, ptr %slot407, align 8
  %v2951 = load i64, ptr %slot407, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  store i64 0, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved515
bb_rcmoveslow515:
  %v2953 = load i64, ptr %slot56, align 8
  %v2954 = load i64, ptr %slot380, align 8
  %v2955 = load i64, ptr %slot379, align 8
  %v2956 = load i64, ptr %slot381, align 8
  %cv2957 = trunc i64 %v2956 to i32
  %call2958 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v2953, i64 %v2954, i64 %v2955, i32 %cv2957) nomerge, !dbg !148
  store i32 %call2958, ptr %slot408, align 8
  %v2959 = load i32, ptr %slot408, align 8
  %cv2960 = zext i32 %v2959 to i64
  %cond2961 = icmp ne i64 %cv2960, 0
  br i1 %cond2961, label %bb_rcsuccess546, label %bb_rcfailure546
bb_rcfailure546:
  %v2962 = load i64, ptr %slot56, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  %call2964 = call i32 @myl_rc_take_failure(ptr %p2963) nomerge, !dbg !148
  store i32 %call2964, ptr %slot409, align 8
  %v2965 = load i64, ptr %slot1, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %v2967 = load i32, ptr %slot409, align 8
  %call2968 = call i32 @myl_qbe_rc_status(ptr %p2966, i32 %v2967) nomerge, !dbg !148
  store i32 %call2968, ptr %slot410, align 8
  br label %bb_failure
bb_rcsuccess546:
  br label %bb_rcmoved515
bb_rcmoved515:
  %v2969 = load i64, ptr %slot14, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  store i32 0, ptr %p2970, align 4, !alias.scope !3, !noalias !4
  %v2971 = load i64, ptr %slot17, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  store i32 2, ptr %p2972, align 4, !alias.scope !3, !noalias !4
  %v2973 = load i64, ptr %slot16, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  store i32 1, ptr %p2974, align 4, !alias.scope !3, !noalias !4
  %v2975 = load i64, ptr %slot23, align 8
  store i64 %v2975, ptr %slot411, align 8
  %v2976 = load i64, ptr %slot411, align 8
  %v2977 = load i64, ptr %slot378, align 8
  %p2978 = inttoptr i64 %v2976 to ptr
  %p2979 = inttoptr i64 %v2977 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2979, ptr %p2978, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot16, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  store i32 0, ptr %p2981, align 4, !alias.scope !3, !noalias !4
  %v2982 = load i64, ptr %slot17, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i32 2, ptr %p2983, align 4, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot16, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i32 1, ptr %p2985, align 4, !alias.scope !3, !noalias !4
  %v2986 = load i64, ptr %slot56, align 8
  store i64 %v2986, ptr %slot412, align 8
  %v2987 = load i64, ptr %slot412, align 8
  %v2988 = load i64, ptr %slot377, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2987, i64 %v2988) nomerge, !dbg !148
  %v2989 = load i64, ptr %slot378, align 8
  %v2990 = load i64, ptr %slot377, align 8
  %p2991 = inttoptr i64 %v2989 to ptr
  %p2992 = inttoptr i64 %v2990 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2992, ptr %p2991, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2993 = load i64, ptr %slot16, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  store i32 0, ptr %p2994, align 4, !alias.scope !3, !noalias !4
  %v2995 = load i64, ptr %slot374, align 8
  %v2996 = load i64, ptr %slot44, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  store i64 %v2995, ptr %p2997, align 8, !alias.scope !3, !noalias !4
  %v2998 = load i64, ptr %slot44, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  %ld3000 = load i64, ptr %p2999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3000, ptr %slot413, align 8
  %v3001 = load i64, ptr %slot23, align 8
  store i64 %v3001, ptr %slot414, align 8
  %v3002 = load i64, ptr %slot413, align 8
  %v3003 = load i64, ptr %slot414, align 8
  %p3004 = inttoptr i64 %v3002 to ptr
  %p3005 = inttoptr i64 %v3003 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3005, ptr %p3004, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot17, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 2, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot16, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i32 1, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot12, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %ld3012 = load i32, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3012, ptr %slot415, align 8
  %v3013 = load i32, ptr %slot415, align 8
  %cv3014 = zext i32 %v3013 to i64
  %cond3015 = icmp ne i64 %cv3014, 0
  br i1 %cond3015, label %bb_rcslotdrop564, label %bb_rcslotdone564
bb_rcslotdrop564:
  %v3016 = load i64, ptr %slot12, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  store i32 0, ptr %p3017, align 4, !alias.scope !3, !noalias !4
  %v3018 = load i64, ptr %slot19, align 8
  store i64 %v3018, ptr %slot416, align 8
  %v3019 = load i64, ptr %slot13, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i32, ptr %p3020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3021, ptr %slot417, align 8
  %v3022 = load i32, ptr %slot417, align 8
  %op3023 = and i32 %v3022, 28
  store i32 %op3023, ptr %slot418, align 8
  %v3024 = load i32, ptr %slot418, align 8
  %cv3025 = zext i32 %v3024 to i64
  %cond3026 = icmp ne i64 %cv3025, 0
  br i1 %cond3026, label %bb_rcslotrole564, label %bb_rcslotowner564
bb_rcslotrole564:
  %v3027 = load i64, ptr %slot56, align 8
  store i64 %v3027, ptr %slot419, align 8
  %v3028 = load i64, ptr %slot419, align 8
  %v3029 = load i64, ptr %slot416, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3028, i64 %v3029) nomerge, !dbg !148
  br label %bb_rcslotdone564
bb_rcslotowner564:
  %v3030 = load i64, ptr %slot56, align 8
  store i64 %v3030, ptr %slot420, align 8
  %v3031 = load i64, ptr %slot420, align 8
  %v3032 = load i64, ptr %slot416, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3031, i64 %v3032) nomerge, !dbg !148
  br label %bb_rcslotdone564
bb_rcslotdone564:
  %v3033 = load i64, ptr %slot14, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  %ld3035 = load i32, ptr %p3034, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3035, ptr %slot421, align 8
  %v3036 = load i32, ptr %slot421, align 8
  %cv3037 = zext i32 %v3036 to i64
  %cond3038 = icmp ne i64 %cv3037, 0
  br i1 %cond3038, label %bb_rcslotdrop573, label %bb_rcslotdone573
bb_rcslotdrop573:
  %v3039 = load i64, ptr %slot14, align 8
  %p3040 = inttoptr i64 %v3039 to ptr
  store i32 0, ptr %p3040, align 4, !alias.scope !3, !noalias !4
  %v3041 = load i64, ptr %slot20, align 8
  store i64 %v3041, ptr %slot422, align 8
  %v3042 = load i64, ptr %slot15, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  %ld3044 = load i32, ptr %p3043, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3044, ptr %slot423, align 8
  %v3045 = load i32, ptr %slot423, align 8
  %op3046 = and i32 %v3045, 28
  store i32 %op3046, ptr %slot424, align 8
  %v3047 = load i32, ptr %slot424, align 8
  %cv3048 = zext i32 %v3047 to i64
  %cond3049 = icmp ne i64 %cv3048, 0
  br i1 %cond3049, label %bb_rcslotrole573, label %bb_rcslotowner573
bb_rcslotrole573:
  %v3050 = load i64, ptr %slot56, align 8
  store i64 %v3050, ptr %slot425, align 8
  %v3051 = load i64, ptr %slot425, align 8
  %v3052 = load i64, ptr %slot422, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3051, i64 %v3052) nomerge, !dbg !148
  br label %bb_rcslotdone573
bb_rcslotowner573:
  %v3053 = load i64, ptr %slot56, align 8
  store i64 %v3053, ptr %slot426, align 8
  %v3054 = load i64, ptr %slot426, align 8
  %v3055 = load i64, ptr %slot422, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3054, i64 %v3055) nomerge, !dbg !148
  br label %bb_rcslotdone573
bb_rcslotdone573:
  %v3056 = load i64, ptr %slot19, align 8
  store i64 %v3056, ptr %slot427, align 8
  %v3057 = load i64, ptr %slot23, align 8
  store i64 %v3057, ptr %slot428, align 8
  %v3058 = load i64, ptr %slot428, align 8
  %v3059 = load i64, ptr %slot427, align 8
  %p3060 = inttoptr i64 %v3058 to ptr
  %p3061 = inttoptr i64 %v3059 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3061, ptr %p3060, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3062 = load i64, ptr %slot13, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  store i32 2, ptr %p3063, align 4, !alias.scope !3, !noalias !4
  %v3064 = load i64, ptr %slot17, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  %ld3066 = load i32, ptr %p3065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3066, ptr %slot429, align 8
  %v3067 = load i32, ptr %slot429, align 8
  %v3068 = load i64, ptr %slot13, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i32 %v3067, ptr %p3069, align 4, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot16, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  store i32 0, ptr %p3071, align 4, !alias.scope !3, !noalias !4
  %v3072 = load i64, ptr %slot12, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i32 1, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  %v3074 = load i64, ptr %slot427, align 8
  %v3075 = load i64, ptr %slot44, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  store i64 %v3074, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  %v3077 = load i64, ptr %slot44, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  %ld3079 = load i64, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3079, ptr %slot430, align 8
  %v3080 = load i64, ptr %slot12, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  %ld3082 = load i32, ptr %p3081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3082, ptr %slot431, align 8
  %v3083 = load i64, ptr %slot13, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %ld3085 = load i32, ptr %p3084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3085, ptr %slot432, align 8
  %v3086 = load i32, ptr %slot432, align 8
  %op3087 = and i32 %v3086, 24
  store i32 %op3087, ptr %slot432, align 8
  %v3088 = load i32, ptr %slot432, align 8
  %cmp3089 = icmp eq i32 %v3088, 0
  %cv3090 = zext i1 %cmp3089 to i32
  store i32 %cv3090, ptr %slot433, align 8
  %v3091 = load i32, ptr %slot431, align 8
  %v3092 = load i32, ptr %slot433, align 8
  %op3093 = and i32 %v3091, %v3092
  store i32 %op3093, ptr %slot434, align 8
  %v3094 = load i32, ptr %slot434, align 8
  %cv3095 = zext i32 %v3094 to i64
  %cond3096 = icmp ne i64 %cv3095, 0
  br i1 %cond3096, label %bb_rctake589, label %bb_rccopy589
bb_rctake589:
  %v3097 = load i64, ptr %slot23, align 8
  store i64 %v3097, ptr %slot435, align 8
  %v3098 = load i64, ptr %slot57, align 8
  store i64 %v3098, ptr %slot436, align 8
  %v3099 = load i64, ptr %slot56, align 8
  %v3100 = load i64, ptr %slot435, align 8
  %v3101 = load i64, ptr %slot430, align 8
  %v3102 = load i64, ptr %slot436, align 8
  %cv3103 = trunc i64 %v3102 to i32
  %call3104 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3099, i64 %v3100, i64 %v3101, i32 %cv3103) nomerge, !dbg !150
  store i32 %call3104, ptr %slot437, align 8
  %v3105 = load i32, ptr %slot437, align 8
  %cv3106 = zext i32 %v3105 to i64
  %cond3107 = icmp ne i64 %cv3106, 0
  br i1 %cond3107, label %bb_rcsuccess599, label %bb_rcfailure599
bb_rcfailure599:
  %v3108 = load i64, ptr %slot56, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  %call3110 = call i32 @myl_rc_take_failure(ptr %p3109) nomerge, !dbg !150
  store i32 %call3110, ptr %slot438, align 8
  %v3111 = load i64, ptr %slot1, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  %v3113 = load i32, ptr %slot438, align 8
  %call3114 = call i32 @myl_qbe_rc_status(ptr %p3112, i32 %v3113) nomerge, !dbg !150
  store i32 %call3114, ptr %slot439, align 8
  br label %bb_failure
bb_rcsuccess599:
  %v3115 = load i64, ptr %slot12, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  store i32 0, ptr %p3116, align 4, !alias.scope !3, !noalias !4
  %v3117 = load i64, ptr %slot17, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i32 2, ptr %p3118, align 4, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot16, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  store i32 1, ptr %p3120, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared589
bb_rccopy589:
  %v3121 = load i64, ptr %slot23, align 8
  store i64 %v3121, ptr %slot440, align 8
  %v3122 = load i64, ptr %slot57, align 8
  store i64 %v3122, ptr %slot441, align 8
  %v3123 = load i64, ptr %slot56, align 8
  %v3124 = load i64, ptr %slot440, align 8
  %v3125 = load i64, ptr %slot430, align 8
  %v3126 = load i64, ptr %slot441, align 8
  %cv3127 = trunc i64 %v3126 to i32
  %call3128 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v3123, i64 %v3124, i64 %v3125, i32 %cv3127) nomerge, !dbg !150
  store i32 %call3128, ptr %slot442, align 8
  %v3129 = load i32, ptr %slot442, align 8
  %cv3130 = zext i32 %v3129 to i64
  %cond3131 = icmp ne i64 %cv3130, 0
  br i1 %cond3131, label %bb_rcsuccess608, label %bb_rcfailure608
bb_rcfailure608:
  %v3132 = load i64, ptr %slot56, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %call3134 = call i32 @myl_rc_take_failure(ptr %p3133) nomerge, !dbg !150
  store i32 %call3134, ptr %slot443, align 8
  %v3135 = load i64, ptr %slot1, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %v3137 = load i32, ptr %slot443, align 8
  %call3138 = call i32 @myl_qbe_rc_status(ptr %p3136, i32 %v3137) nomerge, !dbg !150
  store i32 %call3138, ptr %slot444, align 8
  br label %bb_failure
bb_rcsuccess608:
  %v3139 = load i64, ptr %slot17, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  store i32 2, ptr %p3140, align 4, !alias.scope !3, !noalias !4
  %v3141 = load i64, ptr %slot16, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  store i32 1, ptr %p3142, align 4, !alias.scope !3, !noalias !4
  %v3143 = load i64, ptr %slot12, align 8
  %p3144 = inttoptr i64 %v3143 to ptr
  %ld3145 = load i32, ptr %p3144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3145, ptr %slot445, align 8
  %v3146 = load i32, ptr %slot445, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcslotdrop615, label %bb_rcslotdone615
bb_rcslotdrop615:
  %v3149 = load i64, ptr %slot12, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  store i32 0, ptr %p3150, align 4, !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot19, align 8
  store i64 %v3151, ptr %slot446, align 8
  %v3152 = load i64, ptr %slot13, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i32, ptr %p3153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3154, ptr %slot447, align 8
  %v3155 = load i32, ptr %slot447, align 8
  %op3156 = and i32 %v3155, 28
  store i32 %op3156, ptr %slot448, align 8
  %v3157 = load i32, ptr %slot448, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcslotrole615, label %bb_rcslotowner615
bb_rcslotrole615:
  %v3160 = load i64, ptr %slot56, align 8
  store i64 %v3160, ptr %slot449, align 8
  %v3161 = load i64, ptr %slot449, align 8
  %v3162 = load i64, ptr %slot446, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3161, i64 %v3162) nomerge, !dbg !150
  br label %bb_rcslotdone615
bb_rcslotowner615:
  %v3163 = load i64, ptr %slot56, align 8
  store i64 %v3163, ptr %slot450, align 8
  %v3164 = load i64, ptr %slot450, align 8
  %v3165 = load i64, ptr %slot446, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3164, i64 %v3165) nomerge, !dbg !150
  br label %bb_rcslotdone615
bb_rcslotdone615:
  br label %bb_rcprepared589
bb_rcprepared589:
  %v3166 = load i64, ptr %slot4, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  %ld3168 = load i32, ptr %p3167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3168, ptr %slot451, align 8
  %v3169 = load i32, ptr %slot451, align 8
  %cv3170 = zext i32 %v3169 to i64
  %cond3171 = icmp ne i64 %cv3170, 0
  br i1 %cond3171, label %bb_rcslotdrop625, label %bb_rcslotdone625
bb_rcslotdrop625:
  %v3172 = load i64, ptr %slot4, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  store i32 0, ptr %p3173, align 4, !alias.scope !3, !noalias !4
  %v3174 = load i64, ptr %slot34, align 8
  store i64 %v3174, ptr %slot452, align 8
  %v3175 = load i64, ptr %slot5, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  %ld3177 = load i32, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3177, ptr %slot453, align 8
  %v3178 = load i32, ptr %slot453, align 8
  %op3179 = and i32 %v3178, 28
  store i32 %op3179, ptr %slot454, align 8
  %v3180 = load i32, ptr %slot454, align 8
  %cv3181 = zext i32 %v3180 to i64
  %cond3182 = icmp ne i64 %cv3181, 0
  br i1 %cond3182, label %bb_rcslotrole625, label %bb_rcslotowner625
bb_rcslotrole625:
  %v3183 = load i64, ptr %slot56, align 8
  store i64 %v3183, ptr %slot455, align 8
  %v3184 = load i64, ptr %slot455, align 8
  %v3185 = load i64, ptr %slot452, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3184, i64 %v3185) nomerge, !dbg !150
  br label %bb_rcslotdone625
bb_rcslotowner625:
  %v3186 = load i64, ptr %slot56, align 8
  store i64 %v3186, ptr %slot456, align 8
  %v3187 = load i64, ptr %slot456, align 8
  %v3188 = load i64, ptr %slot452, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3187, i64 %v3188) nomerge, !dbg !150
  br label %bb_rcslotdone625
bb_rcslotdone625:
  %v3189 = load i64, ptr %slot34, align 8
  store i64 %v3189, ptr %slot457, align 8
  %v3190 = load i64, ptr %slot23, align 8
  store i64 %v3190, ptr %slot458, align 8
  %v3191 = load i64, ptr %slot458, align 8
  %v3192 = load i64, ptr %slot457, align 8
  %p3193 = inttoptr i64 %v3191 to ptr
  %p3194 = inttoptr i64 %v3192 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3194, ptr %p3193, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot16, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i32 0, ptr %p3196, align 4, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot5, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  store i32 2, ptr %p3198, align 4, !alias.scope !3, !noalias !4
  %v3199 = load i64, ptr %slot17, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  %ld3201 = load i32, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3201, ptr %slot459, align 8
  %v3202 = load i32, ptr %slot459, align 8
  %v3203 = load i64, ptr %slot5, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  store i32 %v3202, ptr %p3204, align 4, !alias.scope !3, !noalias !4
  %v3205 = load i64, ptr %slot4, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i32 1, ptr %p3206, align 4, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot44, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  store i64 0, ptr %p3208, align 8, !alias.scope !3, !noalias !4
  %v3209 = load i64, ptr %slot34, align 8
  %v3210 = load i64, ptr %slot44, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i64 %v3209, ptr %p3211, align 8, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot44, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot460, align 8
  %v3215 = load i64, ptr %slot12, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i32, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3217, ptr %slot461, align 8
  %v3218 = load i64, ptr %slot13, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %ld3220 = load i32, ptr %p3219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3220, ptr %slot462, align 8
  %v3221 = load i32, ptr %slot462, align 8
  %op3222 = and i32 %v3221, 24
  store i32 %op3222, ptr %slot462, align 8
  %v3223 = load i32, ptr %slot462, align 8
  %cmp3224 = icmp eq i32 %v3223, 0
  %cv3225 = zext i1 %cmp3224 to i32
  store i32 %cv3225, ptr %slot463, align 8
  %v3226 = load i32, ptr %slot461, align 8
  %v3227 = load i32, ptr %slot463, align 8
  %op3228 = and i32 %v3226, %v3227
  store i32 %op3228, ptr %slot464, align 8
  %v3229 = load i32, ptr %slot464, align 8
  %cv3230 = zext i32 %v3229 to i64
  %cond3231 = icmp ne i64 %cv3230, 0
  br i1 %cond3231, label %bb_rcprivateown646, label %bb_rcprivateloan646
bb_rcprivateown646:
  %v3232 = load i64, ptr %slot23, align 8
  store i64 %v3232, ptr %slot465, align 8
  %v3233 = load i64, ptr %slot57, align 8
  store i64 %v3233, ptr %slot466, align 8
  %v3234 = load i64, ptr %slot56, align 8
  %v3235 = load i64, ptr %slot465, align 8
  %v3236 = load i64, ptr %slot460, align 8
  %v3237 = load i64, ptr %slot466, align 8
  %cv3238 = trunc i64 %v3237 to i32
  %call3239 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3234, i64 %v3235, i64 %v3236, i32 %cv3238) nomerge, !dbg !152
  store i32 %call3239, ptr %slot467, align 8
  %v3240 = load i32, ptr %slot467, align 8
  %cv3241 = zext i32 %v3240 to i64
  %cond3242 = icmp ne i64 %cv3241, 0
  br i1 %cond3242, label %bb_rcsuccess650, label %bb_rcfailure650
bb_rcfailure650:
  %v3243 = load i64, ptr %slot56, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %call3245 = call i32 @myl_rc_take_failure(ptr %p3244) nomerge, !dbg !152
  store i32 %call3245, ptr %slot468, align 8
  %v3246 = load i64, ptr %slot1, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  %v3248 = load i32, ptr %slot468, align 8
  %call3249 = call i32 @myl_qbe_rc_status(ptr %p3247, i32 %v3248) nomerge, !dbg !152
  store i32 %call3249, ptr %slot469, align 8
  br label %bb_failure
bb_rcsuccess650:
  %v3250 = load i64, ptr %slot12, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  store i32 0, ptr %p3251, align 4, !alias.scope !3, !noalias !4
  %v3252 = load i64, ptr %slot17, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  store i32 2, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  %v3254 = load i64, ptr %slot16, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  store i32 1, ptr %p3255, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared646
bb_rcprivateloan646:
  %v3256 = load i64, ptr %slot23, align 8
  store i64 %v3256, ptr %slot470, align 8
  %v3257 = load i64, ptr %slot56, align 8
  %v3258 = load i64, ptr %slot470, align 8
  %v3259 = load i64, ptr %slot460, align 8
  %call3260 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v3257, i64 %v3258, i64 %v3259) nomerge, !dbg !152
  store i32 %call3260, ptr %slot471, align 8
  %v3261 = load i32, ptr %slot471, align 8
  %cv3262 = zext i32 %v3261 to i64
  %cond3263 = icmp ne i64 %cv3262, 0
  br i1 %cond3263, label %bb_rcsuccess658, label %bb_rcfailure658
bb_rcfailure658:
  %v3264 = load i64, ptr %slot56, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  %call3266 = call i32 @myl_rc_take_failure(ptr %p3265) nomerge, !dbg !152
  store i32 %call3266, ptr %slot472, align 8
  %v3267 = load i64, ptr %slot1, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  %v3269 = load i32, ptr %slot472, align 8
  %call3270 = call i32 @myl_qbe_rc_status(ptr %p3268, i32 %v3269) nomerge, !dbg !152
  store i32 %call3270, ptr %slot473, align 8
  br label %bb_failure
bb_rcsuccess658:
  %v3271 = load i64, ptr %slot17, align 8
  %p3272 = inttoptr i64 %v3271 to ptr
  store i32 2, ptr %p3272, align 4, !alias.scope !3, !noalias !4
  %v3273 = load i64, ptr %slot17, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  store i32 16, ptr %p3274, align 4, !alias.scope !3, !noalias !4
  %v3275 = load i64, ptr %slot16, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  store i32 1, ptr %p3276, align 4, !alias.scope !3, !noalias !4
  %v3277 = load i64, ptr %slot12, align 8
  %p3278 = inttoptr i64 %v3277 to ptr
  %ld3279 = load i32, ptr %p3278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3279, ptr %slot474, align 8
  %v3280 = load i32, ptr %slot474, align 8
  %cv3281 = zext i32 %v3280 to i64
  %cond3282 = icmp ne i64 %cv3281, 0
  br i1 %cond3282, label %bb_rcslotdrop666, label %bb_rcslotdone666
bb_rcslotdrop666:
  %v3283 = load i64, ptr %slot12, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  store i32 0, ptr %p3284, align 4, !alias.scope !3, !noalias !4
  %v3285 = load i64, ptr %slot19, align 8
  store i64 %v3285, ptr %slot475, align 8
  %v3286 = load i64, ptr %slot13, align 8
  %p3287 = inttoptr i64 %v3286 to ptr
  %ld3288 = load i32, ptr %p3287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3288, ptr %slot476, align 8
  %v3289 = load i32, ptr %slot476, align 8
  %op3290 = and i32 %v3289, 28
  store i32 %op3290, ptr %slot477, align 8
  %v3291 = load i32, ptr %slot477, align 8
  %cv3292 = zext i32 %v3291 to i64
  %cond3293 = icmp ne i64 %cv3292, 0
  br i1 %cond3293, label %bb_rcslotrole666, label %bb_rcslotowner666
bb_rcslotrole666:
  %v3294 = load i64, ptr %slot56, align 8
  store i64 %v3294, ptr %slot478, align 8
  %v3295 = load i64, ptr %slot478, align 8
  %v3296 = load i64, ptr %slot475, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3295, i64 %v3296) nomerge, !dbg !152
  br label %bb_rcslotdone666
bb_rcslotowner666:
  %v3297 = load i64, ptr %slot56, align 8
  store i64 %v3297, ptr %slot479, align 8
  %v3298 = load i64, ptr %slot479, align 8
  %v3299 = load i64, ptr %slot475, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3298, i64 %v3299) nomerge, !dbg !152
  br label %bb_rcslotdone666
bb_rcslotdone666:
  br label %bb_rcprivateprepared646
bb_rcprivateprepared646:
  %v3300 = load i64, ptr %slot8, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  %ld3302 = load i32, ptr %p3301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3302, ptr %slot480, align 8
  %v3303 = load i32, ptr %slot480, align 8
  %cv3304 = zext i32 %v3303 to i64
  %cond3305 = icmp ne i64 %cv3304, 0
  br i1 %cond3305, label %bb_rcslotdrop676, label %bb_rcslotdone676
bb_rcslotdrop676:
  %v3306 = load i64, ptr %slot8, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i32 0, ptr %p3307, align 4, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot38, align 8
  store i64 %v3308, ptr %slot481, align 8
  %v3309 = load i64, ptr %slot9, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  %ld3311 = load i32, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3311, ptr %slot482, align 8
  %v3312 = load i32, ptr %slot482, align 8
  %op3313 = and i32 %v3312, 28
  store i32 %op3313, ptr %slot483, align 8
  %v3314 = load i32, ptr %slot483, align 8
  %cv3315 = zext i32 %v3314 to i64
  %cond3316 = icmp ne i64 %cv3315, 0
  br i1 %cond3316, label %bb_rcslotrole676, label %bb_rcslotowner676
bb_rcslotrole676:
  %v3317 = load i64, ptr %slot56, align 8
  store i64 %v3317, ptr %slot484, align 8
  %v3318 = load i64, ptr %slot484, align 8
  %v3319 = load i64, ptr %slot481, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3318, i64 %v3319) nomerge, !dbg !152
  br label %bb_rcslotdone676
bb_rcslotowner676:
  %v3320 = load i64, ptr %slot56, align 8
  store i64 %v3320, ptr %slot485, align 8
  %v3321 = load i64, ptr %slot485, align 8
  %v3322 = load i64, ptr %slot481, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3321, i64 %v3322) nomerge, !dbg !152
  br label %bb_rcslotdone676
bb_rcslotdone676:
  %v3323 = load i64, ptr %slot38, align 8
  store i64 %v3323, ptr %slot486, align 8
  %v3324 = load i64, ptr %slot23, align 8
  store i64 %v3324, ptr %slot487, align 8
  %v3325 = load i64, ptr %slot487, align 8
  %v3326 = load i64, ptr %slot486, align 8
  %p3327 = inttoptr i64 %v3325 to ptr
  %p3328 = inttoptr i64 %v3326 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3328, ptr %p3327, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3329 = load i64, ptr %slot16, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i32 0, ptr %p3330, align 4, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot9, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i32 2, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot17, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i32, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3335, ptr %slot488, align 8
  %v3336 = load i32, ptr %slot488, align 8
  %v3337 = load i64, ptr %slot9, align 8
  %p3338 = inttoptr i64 %v3337 to ptr
  store i32 %v3336, ptr %p3338, align 4, !alias.scope !3, !noalias !4
  %v3339 = load i64, ptr %slot8, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 1, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot29, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i64, ptr %p3342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3343, ptr %slot489, align 8
  %v3344 = load i64, ptr %slot489, align 8
  %v3345 = load i64, ptr %slot44, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  store i64 %v3344, ptr %p3346, align 8, !alias.scope !3, !noalias !4
  %v3347 = load i64, ptr %slot44, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  %ld3349 = load i64, ptr %p3348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3349, ptr %slot490, align 8
  %v3350 = load i64, ptr %slot490, align 8
  %op3351 = add i64 %v3350, 376
  store i64 %op3351, ptr %slot491, align 8
  %v3352 = load i64, ptr %slot491, align 8
  %p3353 = inttoptr i64 %v3352 to ptr
  %ld3354 = load i64, ptr %p3353, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3354, ptr %slot492, align 8
  %v3355 = load i64, ptr %slot492, align 8
  %v3356 = load i64, ptr %slot44, align 8
  %p3357 = inttoptr i64 %v3356 to ptr
  store i64 %v3355, ptr %p3357, align 8, !alias.scope !3, !noalias !4
  %v3358 = load i64, ptr %slot12, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i32, ptr %p3359, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3360, ptr %slot493, align 8
  %v3361 = load i32, ptr %slot493, align 8
  %cv3362 = zext i32 %v3361 to i64
  %cond3363 = icmp ne i64 %cv3362, 0
  br i1 %cond3363, label %bb_rcslotdrop696, label %bb_rcslotdone696
bb_rcslotdrop696:
  %v3364 = load i64, ptr %slot12, align 8
  %p3365 = inttoptr i64 %v3364 to ptr
  store i32 0, ptr %p3365, align 4, !alias.scope !3, !noalias !4
  %v3366 = load i64, ptr %slot19, align 8
  store i64 %v3366, ptr %slot494, align 8
  %v3367 = load i64, ptr %slot13, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  %ld3369 = load i32, ptr %p3368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3369, ptr %slot495, align 8
  %v3370 = load i32, ptr %slot495, align 8
  %op3371 = and i32 %v3370, 28
  store i32 %op3371, ptr %slot496, align 8
  %v3372 = load i32, ptr %slot496, align 8
  %cv3373 = zext i32 %v3372 to i64
  %cond3374 = icmp ne i64 %cv3373, 0
  br i1 %cond3374, label %bb_rcslotrole696, label %bb_rcslotowner696
bb_rcslotrole696:
  %v3375 = load i64, ptr %slot56, align 8
  store i64 %v3375, ptr %slot497, align 8
  %v3376 = load i64, ptr %slot497, align 8
  %v3377 = load i64, ptr %slot494, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v3376, i64 %v3377) nomerge, !dbg !154
  br label %bb_rcslotdone696
bb_rcslotowner696:
  %v3378 = load i64, ptr %slot56, align 8
  store i64 %v3378, ptr %slot498, align 8
  %v3379 = load i64, ptr %slot498, align 8
  %v3380 = load i64, ptr %slot494, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v3379, i64 %v3380) nomerge, !dbg !154
  br label %bb_rcslotdone696
bb_rcslotdone696:
  %v3381 = load i64, ptr %slot44, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i64, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3383, ptr %slot499, align 8
  %v3384 = load i64, ptr %slot29, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  %ld3386 = load i64, ptr %p3385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3386, ptr %slot500, align 8
  %v3387 = load i64, ptr %slot12, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i32, ptr %p3388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3389, ptr %slot501, align 8
  %v3390 = load i32, ptr %slot501, align 8
  %cv3391 = zext i32 %v3390 to i64
  %cond3392 = icmp ne i64 %cv3391, 0
  br i1 %cond3392, label %bb_rcslotdrop708, label %bb_rcslotdone708
bb_rcslotdrop708:
  %v3393 = load i64, ptr %slot12, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  store i32 0, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  %v3395 = load i64, ptr %slot19, align 8
  store i64 %v3395, ptr %slot502, align 8
  %v3396 = load i64, ptr %slot13, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %ld3398 = load i32, ptr %p3397, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3398, ptr %slot503, align 8
  %v3399 = load i32, ptr %slot503, align 8
  %op3400 = and i32 %v3399, 28
  store i32 %op3400, ptr %slot504, align 8
  %v3401 = load i32, ptr %slot504, align 8
  %cv3402 = zext i32 %v3401 to i64
  %cond3403 = icmp ne i64 %cv3402, 0
  br i1 %cond3403, label %bb_rcslotrole708, label %bb_rcslotowner708
bb_rcslotrole708:
  %v3404 = load i64, ptr %slot56, align 8
  store i64 %v3404, ptr %slot505, align 8
  %v3405 = load i64, ptr %slot502, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %ld3407 = load i64, ptr %p3406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3407, ptr %slot506, align 8
  %v3408 = load i64, ptr %slot506, align 8
  %cmp3409 = icmp ne i64 %v3408, 0
  %cv3410 = zext i1 %cmp3409 to i32
  store i32 %cv3410, ptr %slot507, align 8
  %v3411 = load i32, ptr %slot507, align 8
  %cv3412 = zext i32 %v3411 to i64
  %cond3413 = icmp ne i64 %cv3412, 0
  br i1 %cond3413, label %bb_rcgnn724, label %bb_rcgdone724
bb_rcgnn724:
  %v3414 = load i64, ptr %slot506, align 8
  %op3415 = sub i64 %v3414, 16
  store i64 %op3415, ptr %slot508, align 8
  %v3416 = load i64, ptr %slot506, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  %rgep3418 = getelementptr i8, ptr %p3417, i64 -16
  %ld3419 = load i64, ptr %rgep3418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3419, ptr %slot509, align 8
  %v3420 = load i64, ptr %slot509, align 8
  %op3421 = and i64 %v3420, 4611686018427387906
  store i64 %op3421, ptr %slot510, align 8
  %v3422 = load i64, ptr %slot510, align 8
  %cmp3423 = icmp ne i64 %v3422, 0
  %cv3424 = zext i1 %cmp3423 to i32
  store i32 %cv3424, ptr %slot511, align 8
  %v3425 = load i32, ptr %slot511, align 8
  %cv3426 = zext i32 %v3425 to i64
  %cond3427 = icmp ne i64 %cv3426, 0
  br i1 %cond3427, label %bb_rcgclear724, label %bb_rcgcounted724
bb_rcgcounted724:
  %v3428 = load i64, ptr %slot506, align 8
  %op3429 = sub i64 %v3428, 24
  store i64 %op3429, ptr %slot512, align 8
  %v3430 = load i64, ptr %slot506, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %rgep3432 = getelementptr i8, ptr %p3431, i64 -24
  %ld3433 = load i64, ptr %rgep3432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3433, ptr %slot513, align 8
  %v3434 = load i64, ptr %slot513, align 8
  %op3435 = sub i64 %v3434, 1
  store i64 %op3435, ptr %slot514, align 8
  %v3436 = load i64, ptr %slot514, align 8
  %cmp3437 = icmp eq i64 %v3436, 0
  %cv3438 = zext i1 %cmp3437 to i32
  store i32 %cv3438, ptr %slot515, align 8
  %v3439 = load i32, ptr %slot515, align 8
  %cv3440 = zext i32 %v3439 to i64
  %cond3441 = icmp ne i64 %cv3440, 0
  br i1 %cond3441, label %bb_rcglast724, label %bb_rcgdec724
bb_rcglast724:
  %v3442 = load i64, ptr %slot506, align 8
  %op3443 = sub i64 %v3442, 32
  store i64 %op3443, ptr %slot516, align 8
  %v3444 = load i64, ptr %slot506, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %rgep3446 = getelementptr i8, ptr %p3445, i64 -32
  %ld3447 = load i64, ptr %rgep3446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3447, ptr %slot517, align 8
  %v3448 = load i64, ptr %slot517, align 8
  %cmp3449 = icmp ne i64 %v3448, 0
  %cv3450 = zext i1 %cmp3449 to i32
  store i32 %cv3450, ptr %slot518, align 8
  %v3451 = load i32, ptr %slot518, align 8
  %cv3452 = zext i32 %v3451 to i64
  %cond3453 = icmp ne i64 %cv3452, 0
  br i1 %cond3453, label %bb_rcgdec724, label %bb_rcgslow724
bb_rcgslow724:
  %v3454 = load i64, ptr %slot505, align 8
  %v3455 = load i64, ptr %slot502, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v3454, i64 %v3455) nomerge, !dbg !156
  br label %bb_rcgdone724
bb_rcgdec724:
  %v3456 = load i64, ptr %slot514, align 8
  %v3457 = load i64, ptr %slot506, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  %rgep3459 = getelementptr i8, ptr %p3458, i64 -24
  store i64 %v3456, ptr %rgep3459, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear724
bb_rcgclear724:
  %v3460 = load i64, ptr %slot502, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  store i64 0, ptr %p3461, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone724
bb_rcgdone724:
  br label %bb_rcslotdone708
bb_rcslotowner708:
  %v3462 = load i64, ptr %slot56, align 8
  store i64 %v3462, ptr %slot519, align 8
  %v3463 = load i64, ptr %slot502, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  %ld3465 = load i64, ptr %p3464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3465, ptr %slot520, align 8
  %v3466 = load i64, ptr %slot520, align 8
  %cmp3467 = icmp ne i64 %v3466, 0
  %cv3468 = zext i1 %cmp3467 to i32
  store i32 %cv3468, ptr %slot521, align 8
  %v3469 = load i32, ptr %slot521, align 8
  %cv3470 = zext i32 %v3469 to i64
  %cond3471 = icmp ne i64 %cv3470, 0
  br i1 %cond3471, label %bb_rcgnn739, label %bb_rcgdone739
bb_rcgnn739:
  %v3472 = load i64, ptr %slot520, align 8
  %op3473 = sub i64 %v3472, 16
  store i64 %op3473, ptr %slot522, align 8
  %v3474 = load i64, ptr %slot520, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  %rgep3476 = getelementptr i8, ptr %p3475, i64 -16
  %ld3477 = load i64, ptr %rgep3476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3477, ptr %slot523, align 8
  %v3478 = load i64, ptr %slot523, align 8
  %op3479 = and i64 %v3478, 4611686018427387906
  store i64 %op3479, ptr %slot524, align 8
  %v3480 = load i64, ptr %slot524, align 8
  %cmp3481 = icmp ne i64 %v3480, 0
  %cv3482 = zext i1 %cmp3481 to i32
  store i32 %cv3482, ptr %slot525, align 8
  %v3483 = load i32, ptr %slot525, align 8
  %cv3484 = zext i32 %v3483 to i64
  %cond3485 = icmp ne i64 %cv3484, 0
  br i1 %cond3485, label %bb_rcgclear739, label %bb_rcgcounted739
bb_rcgcounted739:
  %v3486 = load i64, ptr %slot520, align 8
  %op3487 = sub i64 %v3486, 32
  store i64 %op3487, ptr %slot526, align 8
  %v3488 = load i64, ptr %slot520, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  %rgep3490 = getelementptr i8, ptr %p3489, i64 -32
  %ld3491 = load i64, ptr %rgep3490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3491, ptr %slot527, align 8
  %v3492 = load i64, ptr %slot527, align 8
  %op3493 = sub i64 %v3492, 1
  store i64 %op3493, ptr %slot528, align 8
  %v3494 = load i64, ptr %slot528, align 8
  %cmp3495 = icmp eq i64 %v3494, 0
  %cv3496 = zext i1 %cmp3495 to i32
  store i32 %cv3496, ptr %slot529, align 8
  %v3497 = load i32, ptr %slot529, align 8
  %cv3498 = zext i32 %v3497 to i64
  %cond3499 = icmp ne i64 %cv3498, 0
  br i1 %cond3499, label %bb_rcglast739, label %bb_rcgdec739
bb_rcglast739:
  %v3500 = load i64, ptr %slot520, align 8
  %op3501 = sub i64 %v3500, 24
  store i64 %op3501, ptr %slot530, align 8
  %v3502 = load i64, ptr %slot520, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  %rgep3504 = getelementptr i8, ptr %p3503, i64 -24
  %ld3505 = load i64, ptr %rgep3504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3505, ptr %slot531, align 8
  %v3506 = load i64, ptr %slot531, align 8
  %cmp3507 = icmp ne i64 %v3506, 0
  %cv3508 = zext i1 %cmp3507 to i32
  store i32 %cv3508, ptr %slot532, align 8
  %v3509 = load i32, ptr %slot532, align 8
  %cv3510 = zext i32 %v3509 to i64
  %cond3511 = icmp ne i64 %cv3510, 0
  br i1 %cond3511, label %bb_rcgdec739, label %bb_rcgslow739
bb_rcgslow739:
  %v3512 = load i64, ptr %slot519, align 8
  %v3513 = load i64, ptr %slot502, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v3512, i64 %v3513) nomerge, !dbg !156
  br label %bb_rcgdone739
bb_rcgdec739:
  %v3514 = load i64, ptr %slot528, align 8
  %v3515 = load i64, ptr %slot520, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  %rgep3517 = getelementptr i8, ptr %p3516, i64 -32
  store i64 %v3514, ptr %rgep3517, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear739
bb_rcgclear739:
  %v3518 = load i64, ptr %slot502, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  store i64 0, ptr %p3519, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone739
bb_rcgdone739:
  br label %bb_rcslotdone708
bb_rcslotdone708:
  %v3520 = load i64, ptr %slot500, align 8
  %op3521 = add i64 %v3520, 376
  store i64 %op3521, ptr %slot533, align 8
  store i64 0, ptr %slot534, align 8
  %v3522 = load i64, ptr %slot533, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  %ld3524 = load i64, ptr %p3523, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3524, ptr %slot535, align 8
  %v3525 = load i64, ptr %slot535, align 8
  %cmp3526 = icmp ne i64 %v3525, 0
  %cv3527 = zext i1 %cmp3526 to i32
  store i32 %cv3527, ptr %slot536, align 8
  %v3528 = load i32, ptr %slot536, align 8
  %cv3529 = zext i32 %v3528 to i64
  %cond3530 = icmp ne i64 %cv3529, 0
  br i1 %cond3530, label %bb_rcguniquenn745, label %bb_rcgunique745
bb_rcguniquenn745:
  %v3531 = load i64, ptr %slot535, align 8
  %op3532 = sub i64 %v3531, 16
  store i64 %op3532, ptr %slot537, align 8
  %v3533 = load i64, ptr %slot535, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %rgep3535 = getelementptr i8, ptr %p3534, i64 -16
  %ld3536 = load i64, ptr %rgep3535, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3536, ptr %slot538, align 8
  %v3537 = load i64, ptr %slot538, align 8
  %op3538 = and i64 %v3537, 6917529027641081858
  store i64 %op3538, ptr %slot539, align 8
  %v3539 = load i64, ptr %slot539, align 8
  %cmp3540 = icmp ne i64 %v3539, 0
  %cv3541 = zext i1 %cmp3540 to i32
  store i32 %cv3541, ptr %slot540, align 8
  %v3542 = load i32, ptr %slot540, align 8
  %cv3543 = zext i32 %v3542 to i64
  %cond3544 = icmp ne i64 %cv3543, 0
  br i1 %cond3544, label %bb_rcguniqueslow745, label %bb_rcguniquecount745
bb_rcguniquecount745:
  %v3545 = load i64, ptr %slot535, align 8
  %op3546 = sub i64 %v3545, 32
  store i64 %op3546, ptr %slot541, align 8
  %v3547 = load i64, ptr %slot535, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %rgep3549 = getelementptr i8, ptr %p3548, i64 -32
  %ld3550 = load i64, ptr %rgep3549, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3550, ptr %slot542, align 8
  %v3551 = load i64, ptr %slot542, align 8
  %cmp3552 = icmp ult i64 %v3551, 2
  %cv3553 = zext i1 %cmp3552 to i32
  store i32 %cv3553, ptr %slot543, align 8
  %v3554 = load i32, ptr %slot543, align 8
  %cv3555 = zext i32 %v3554 to i64
  %cond3556 = icmp ne i64 %cv3555, 0
  br i1 %cond3556, label %bb_rcgunique745, label %bb_rcguniqueslow745
bb_rcguniqueslow745:
  %v3557 = load i64, ptr %slot1, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %p3559 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v3560 = load i64, ptr %slot533, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  %v3562 = load i64, ptr %slot534, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  %call3564 = call i32 @myl_qbe_rc_unique_field(ptr %p3558, ptr %p3559, ptr %p3561, ptr %p3563) nomerge, !dbg !156
  store i32 %call3564, ptr %slot544, align 8
  %v3565 = load i32, ptr %slot544, align 8
  %cv3566 = zext i32 %v3565 to i64
  %cond3567 = icmp ne i64 %cv3566, 0
  br i1 %cond3567, label %bb_rcunique755, label %bb_failure
bb_rcunique755:
  br label %bb_rcgunique745
bb_rcgunique745:
  %v3568 = load i64, ptr %slot533, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  %ld3570 = load i64, ptr %p3569, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3570, ptr %slot545, align 8
  %v3571 = load i64, ptr %slot545, align 8
  %v3572 = load i64, ptr %slot44, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i64 %v3571, ptr %p3573, align 8, !alias.scope !3, !noalias !4
  %v3574 = load i64, ptr %slot44, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %ld3576 = load i64, ptr %p3575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3576, ptr %slot546, align 8
  %v3577 = load i64, ptr %slot12, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %ld3579 = load i32, ptr %p3578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3579, ptr %slot547, align 8
  %v3580 = load i32, ptr %slot547, align 8
  %cv3581 = zext i32 %v3580 to i64
  %cond3582 = icmp ne i64 %cv3581, 0
  br i1 %cond3582, label %bb_rcslotdrop760, label %bb_rcslotdone760
bb_rcslotdrop760:
  %v3583 = load i64, ptr %slot12, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i32 0, ptr %p3584, align 4, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot19, align 8
  store i64 %v3585, ptr %slot548, align 8
  %v3586 = load i64, ptr %slot13, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i32, ptr %p3587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3588, ptr %slot549, align 8
  %v3589 = load i32, ptr %slot549, align 8
  %op3590 = and i32 %v3589, 28
  store i32 %op3590, ptr %slot550, align 8
  %v3591 = load i32, ptr %slot550, align 8
  %cv3592 = zext i32 %v3591 to i64
  %cond3593 = icmp ne i64 %cv3592, 0
  br i1 %cond3593, label %bb_rcslotrole760, label %bb_rcslotowner760
bb_rcslotrole760:
  %v3594 = load i64, ptr %slot56, align 8
  store i64 %v3594, ptr %slot551, align 8
  %v3595 = load i64, ptr %slot548, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %ld3597 = load i64, ptr %p3596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3597, ptr %slot552, align 8
  %v3598 = load i64, ptr %slot552, align 8
  %cmp3599 = icmp ne i64 %v3598, 0
  %cv3600 = zext i1 %cmp3599 to i32
  store i32 %cv3600, ptr %slot553, align 8
  %v3601 = load i32, ptr %slot553, align 8
  %cv3602 = zext i32 %v3601 to i64
  %cond3603 = icmp ne i64 %cv3602, 0
  br i1 %cond3603, label %bb_rcgnn776, label %bb_rcgdone776
bb_rcgnn776:
  %v3604 = load i64, ptr %slot552, align 8
  %op3605 = sub i64 %v3604, 16
  store i64 %op3605, ptr %slot554, align 8
  %v3606 = load i64, ptr %slot552, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  %rgep3608 = getelementptr i8, ptr %p3607, i64 -16
  %ld3609 = load i64, ptr %rgep3608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3609, ptr %slot555, align 8
  %v3610 = load i64, ptr %slot555, align 8
  %op3611 = and i64 %v3610, 4611686018427387906
  store i64 %op3611, ptr %slot556, align 8
  %v3612 = load i64, ptr %slot556, align 8
  %cmp3613 = icmp ne i64 %v3612, 0
  %cv3614 = zext i1 %cmp3613 to i32
  store i32 %cv3614, ptr %slot557, align 8
  %v3615 = load i32, ptr %slot557, align 8
  %cv3616 = zext i32 %v3615 to i64
  %cond3617 = icmp ne i64 %cv3616, 0
  br i1 %cond3617, label %bb_rcgclear776, label %bb_rcgcounted776
bb_rcgcounted776:
  %v3618 = load i64, ptr %slot552, align 8
  %op3619 = sub i64 %v3618, 24
  store i64 %op3619, ptr %slot558, align 8
  %v3620 = load i64, ptr %slot552, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  %rgep3622 = getelementptr i8, ptr %p3621, i64 -24
  %ld3623 = load i64, ptr %rgep3622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3623, ptr %slot559, align 8
  %v3624 = load i64, ptr %slot559, align 8
  %op3625 = sub i64 %v3624, 1
  store i64 %op3625, ptr %slot560, align 8
  %v3626 = load i64, ptr %slot560, align 8
  %cmp3627 = icmp eq i64 %v3626, 0
  %cv3628 = zext i1 %cmp3627 to i32
  store i32 %cv3628, ptr %slot561, align 8
  %v3629 = load i32, ptr %slot561, align 8
  %cv3630 = zext i32 %v3629 to i64
  %cond3631 = icmp ne i64 %cv3630, 0
  br i1 %cond3631, label %bb_rcglast776, label %bb_rcgdec776
bb_rcglast776:
  %v3632 = load i64, ptr %slot552, align 8
  %op3633 = sub i64 %v3632, 32
  store i64 %op3633, ptr %slot562, align 8
  %v3634 = load i64, ptr %slot552, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %rgep3636 = getelementptr i8, ptr %p3635, i64 -32
  %ld3637 = load i64, ptr %rgep3636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3637, ptr %slot563, align 8
  %v3638 = load i64, ptr %slot563, align 8
  %cmp3639 = icmp ne i64 %v3638, 0
  %cv3640 = zext i1 %cmp3639 to i32
  store i32 %cv3640, ptr %slot564, align 8
  %v3641 = load i32, ptr %slot564, align 8
  %cv3642 = zext i32 %v3641 to i64
  %cond3643 = icmp ne i64 %cv3642, 0
  br i1 %cond3643, label %bb_rcgdec776, label %bb_rcgslow776
bb_rcgslow776:
  %v3644 = load i64, ptr %slot551, align 8
  %v3645 = load i64, ptr %slot548, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v3644, i64 %v3645) nomerge, !dbg !156
  br label %bb_rcgdone776
bb_rcgdec776:
  %v3646 = load i64, ptr %slot560, align 8
  %v3647 = load i64, ptr %slot552, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %rgep3649 = getelementptr i8, ptr %p3648, i64 -24
  store i64 %v3646, ptr %rgep3649, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear776
bb_rcgclear776:
  %v3650 = load i64, ptr %slot548, align 8
  %p3651 = inttoptr i64 %v3650 to ptr
  store i64 0, ptr %p3651, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone776
bb_rcgdone776:
  br label %bb_rcslotdone760
bb_rcslotowner760:
  %v3652 = load i64, ptr %slot56, align 8
  store i64 %v3652, ptr %slot565, align 8
  %v3653 = load i64, ptr %slot548, align 8
  %p3654 = inttoptr i64 %v3653 to ptr
  %ld3655 = load i64, ptr %p3654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3655, ptr %slot566, align 8
  %v3656 = load i64, ptr %slot566, align 8
  %cmp3657 = icmp ne i64 %v3656, 0
  %cv3658 = zext i1 %cmp3657 to i32
  store i32 %cv3658, ptr %slot567, align 8
  %v3659 = load i32, ptr %slot567, align 8
  %cv3660 = zext i32 %v3659 to i64
  %cond3661 = icmp ne i64 %cv3660, 0
  br i1 %cond3661, label %bb_rcgnn791, label %bb_rcgdone791
bb_rcgnn791:
  %v3662 = load i64, ptr %slot566, align 8
  %op3663 = sub i64 %v3662, 16
  store i64 %op3663, ptr %slot568, align 8
  %v3664 = load i64, ptr %slot566, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  %rgep3666 = getelementptr i8, ptr %p3665, i64 -16
  %ld3667 = load i64, ptr %rgep3666, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3667, ptr %slot569, align 8
  %v3668 = load i64, ptr %slot569, align 8
  %op3669 = and i64 %v3668, 4611686018427387906
  store i64 %op3669, ptr %slot570, align 8
  %v3670 = load i64, ptr %slot570, align 8
  %cmp3671 = icmp ne i64 %v3670, 0
  %cv3672 = zext i1 %cmp3671 to i32
  store i32 %cv3672, ptr %slot571, align 8
  %v3673 = load i32, ptr %slot571, align 8
  %cv3674 = zext i32 %v3673 to i64
  %cond3675 = icmp ne i64 %cv3674, 0
  br i1 %cond3675, label %bb_rcgclear791, label %bb_rcgcounted791
bb_rcgcounted791:
  %v3676 = load i64, ptr %slot566, align 8
  %op3677 = sub i64 %v3676, 32
  store i64 %op3677, ptr %slot572, align 8
  %v3678 = load i64, ptr %slot566, align 8
  %p3679 = inttoptr i64 %v3678 to ptr
  %rgep3680 = getelementptr i8, ptr %p3679, i64 -32
  %ld3681 = load i64, ptr %rgep3680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3681, ptr %slot573, align 8
  %v3682 = load i64, ptr %slot573, align 8
  %op3683 = sub i64 %v3682, 1
  store i64 %op3683, ptr %slot574, align 8
  %v3684 = load i64, ptr %slot574, align 8
  %cmp3685 = icmp eq i64 %v3684, 0
  %cv3686 = zext i1 %cmp3685 to i32
  store i32 %cv3686, ptr %slot575, align 8
  %v3687 = load i32, ptr %slot575, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcglast791, label %bb_rcgdec791
bb_rcglast791:
  %v3690 = load i64, ptr %slot566, align 8
  %op3691 = sub i64 %v3690, 24
  store i64 %op3691, ptr %slot576, align 8
  %v3692 = load i64, ptr %slot566, align 8
  %p3693 = inttoptr i64 %v3692 to ptr
  %rgep3694 = getelementptr i8, ptr %p3693, i64 -24
  %ld3695 = load i64, ptr %rgep3694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3695, ptr %slot577, align 8
  %v3696 = load i64, ptr %slot577, align 8
  %cmp3697 = icmp ne i64 %v3696, 0
  %cv3698 = zext i1 %cmp3697 to i32
  store i32 %cv3698, ptr %slot578, align 8
  %v3699 = load i32, ptr %slot578, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcgdec791, label %bb_rcgslow791
bb_rcgslow791:
  %v3702 = load i64, ptr %slot565, align 8
  %v3703 = load i64, ptr %slot548, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v3702, i64 %v3703) nomerge, !dbg !156
  br label %bb_rcgdone791
bb_rcgdec791:
  %v3704 = load i64, ptr %slot574, align 8
  %v3705 = load i64, ptr %slot566, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %rgep3707 = getelementptr i8, ptr %p3706, i64 -32
  store i64 %v3704, ptr %rgep3707, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear791
bb_rcgclear791:
  %v3708 = load i64, ptr %slot548, align 8
  %p3709 = inttoptr i64 %v3708 to ptr
  store i64 0, ptr %p3709, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone791
bb_rcgdone791:
  br label %bb_rcslotdone760
bb_rcslotdone760:
  %v3710 = load i64, ptr %slot546, align 8
  %v3711 = load i64, ptr %slot37, align 8
  %p3712 = inttoptr i64 %v3711 to ptr
  store i64 %v3710, ptr %p3712, align 8, !alias.scope !3, !noalias !4
  %v3713 = load i64, ptr %slot31, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  %ld3715 = load i64, ptr %p3714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3715, ptr %slot579, align 8
  %v3716 = load i64, ptr %slot579, align 8
  %v3717 = load i64, ptr %slot44, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  store i64 %v3716, ptr %p3718, align 8, !alias.scope !3, !noalias !4
  %v3719 = load i64, ptr %slot44, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i64, ptr %p3720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3721, ptr %slot580, align 8
  %v3722 = load i64, ptr %slot580, align 8
  %v3723 = load i64, ptr %slot39, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  store i64 %v3722, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  %v3725 = load i64, ptr %slot39, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  %ld3727 = load i64, ptr %p3726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3727, ptr %slot581, align 8
  %v3728 = load i64, ptr %slot581, align 8
  %v3729 = load i64, ptr %slot44, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i64 %v3728, ptr %p3730, align 8, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot45, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  store i64 0, ptr %p3732, align 8, !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot45, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  %ld3735 = load i64, ptr %p3734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3735, ptr %slot582, align 8
  %v3736 = load i64, ptr %slot44, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  %ld3738 = load i64, ptr %p3737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3738, ptr %slot583, align 8
  %v3739 = load i64, ptr %slot583, align 8
  %v3740 = load i64, ptr %slot582, align 8
  %cmp3741 = icmp slt i64 %v3739, %v3740
  %cv3742 = zext i1 %cmp3741 to i64
  store i64 %cv3742, ptr %slot584, align 8
  %v3743 = load i64, ptr %slot584, align 8
  %v3744 = load i64, ptr %slot44, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  store i64 %v3743, ptr %p3745, align 8, !alias.scope !3, !noalias !4
  %v3746 = load i64, ptr %slot44, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %ld3748 = load i64, ptr %p3747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3748, ptr %slot585, align 8
  %v3749 = load i64, ptr %slot585, align 8
  %cond3750 = icmp ne i64 %v3749, 0
  br i1 %cond3750, label %bb_next839, label %bb_i62
bb_next839:
  %v3751 = load i64, ptr %slot37, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  %ld3753 = load i64, ptr %p3752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3753, ptr %slot586, align 8
  %v3754 = load i64, ptr %slot586, align 8
  %op3755 = add i64 %v3754, 0
  store i64 %op3755, ptr %slot587, align 8
  %v3756 = load i64, ptr %slot587, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  %ld3758 = load i64, ptr %p3757, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3758, ptr %slot588, align 8
  %v3759 = load i64, ptr %slot588, align 8
  %v3760 = load i64, ptr %slot44, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  store i64 %v3759, ptr %p3761, align 8, !alias.scope !3, !noalias !4
  %v3762 = load i64, ptr %slot44, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i64, ptr %p3763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3764, ptr %slot589, align 8
  %v3765 = load i64, ptr %slot589, align 8
  %cmp3766 = icmp ugt i64 %v3765, 9223372036854775807
  %cv3767 = zext i1 %cmp3766 to i64
  store i64 %cv3767, ptr %slot590, align 8
  %v3768 = load i64, ptr %slot590, align 8
  %cond3769 = icmp ne i64 %v3768, 0
  br i1 %cond3769, label %bb_cast_overflow844, label %bb_cast_ok844
bb_cast_overflow844:
  %v3770 = load i64, ptr %slot1, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  %v3772 = load i64, ptr %slot589, align 8
  call void @myl_qbe_fail_cast(ptr %p3771, i64 %v3772, i64 320) nomerge, !dbg !158
  unreachable
bb_cast_ok844:
  %v3773 = load i64, ptr %slot589, align 8
  %v3774 = load i64, ptr %slot44, align 8
  %p3775 = inttoptr i64 %v3774 to ptr
  store i64 %v3773, ptr %p3775, align 8, !alias.scope !3, !noalias !4
  %v3776 = load i64, ptr %slot39, align 8
  %p3777 = inttoptr i64 %v3776 to ptr
  %ld3778 = load i64, ptr %p3777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3778, ptr %slot591, align 8
  %v3779 = load i64, ptr %slot591, align 8
  %v3780 = load i64, ptr %slot45, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  store i64 %v3779, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  %v3782 = load i64, ptr %slot45, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %ld3784 = load i64, ptr %p3783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3784, ptr %slot592, align 8
  %v3785 = load i64, ptr %slot44, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot593, align 8
  %v3788 = load i64, ptr %slot593, align 8
  %v3789 = load i64, ptr %slot592, align 8
  %ovpair3791 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3788, i64 %v3789)
  %op3790 = extractvalue { i64, i1 } %ovpair3791, 0
  %ov3792 = extractvalue { i64, i1 } %ovpair3791, 1
  store i64 %op3790, ptr %slot594, align 8
  %v3793 = load i64, ptr %slot593, align 8
  %v3794 = load i64, ptr %slot594, align 8
  %op3795 = xor i64 %v3793, %v3794
  store i64 %op3795, ptr %slot595, align 8
  %v3796 = load i64, ptr %slot592, align 8
  %v3797 = load i64, ptr %slot594, align 8
  %op3798 = xor i64 %v3796, %v3797
  store i64 %op3798, ptr %slot596, align 8
  %v3799 = load i64, ptr %slot595, align 8
  %v3800 = load i64, ptr %slot596, align 8
  %op3801 = and i64 %v3799, %v3800
  store i64 %op3801, ptr %slot597, align 8
  %cv3802 = zext i1 %ov3792 to i64
  store i64 %cv3802, ptr %slot598, align 8
  %v3803 = load i64, ptr %slot598, align 8
  %cond3804 = icmp ne i64 %v3803, 0
  br i1 %cond3804, label %bb_overflow848, label %bb_checked848
bb_overflow848:
  %v3805 = load i64, ptr %slot1, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %v3807 = load i64, ptr %slot593, align 8
  %v3808 = load i64, ptr %slot592, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3806, i64 0, i64 %v3807, i64 %v3808, i64 64) nomerge, !dbg !160
  unreachable
bb_checked848:
  %v3809 = load i64, ptr %slot594, align 8
  %v3810 = load i64, ptr %slot44, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  store i64 %v3809, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  %v3812 = load i64, ptr %slot44, align 8
  %p3813 = inttoptr i64 %v3812 to ptr
  %ld3814 = load i64, ptr %p3813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3814, ptr %slot599, align 8
  %v3815 = load i64, ptr %slot599, align 8
  %v3816 = load i64, ptr %slot39, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i64 %v3815, ptr %p3817, align 8, !alias.scope !3, !noalias !4
  br label %bb_i62
bb_i62:
  %v3818 = load i64, ptr %slot39, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  %ld3820 = load i64, ptr %p3819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3820, ptr %slot600, align 8
  %v3821 = load i64, ptr %slot600, align 8
  %v3822 = load i64, ptr %slot44, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  store i64 %v3821, ptr %p3823, align 8, !alias.scope !3, !noalias !4
  %v3824 = load i64, ptr %slot38, align 8
  %v3825 = load i64, ptr %slot45, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i64 %v3824, ptr %p3826, align 8, !alias.scope !3, !noalias !4
  %v3827 = load i64, ptr %slot45, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  %ld3829 = load i64, ptr %p3828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3829, ptr %slot601, align 8
  %v3830 = load i64, ptr %slot14, align 8
  %p3831 = inttoptr i64 %v3830 to ptr
  %ld3832 = load i32, ptr %p3831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3832, ptr %slot602, align 8
  %v3833 = load i64, ptr %slot15, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %ld3835 = load i32, ptr %p3834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3835, ptr %slot603, align 8
  %v3836 = load i32, ptr %slot603, align 8
  %op3837 = and i32 %v3836, 24
  store i32 %op3837, ptr %slot603, align 8
  %v3838 = load i32, ptr %slot603, align 8
  %cmp3839 = icmp eq i32 %v3838, 0
  %cv3840 = zext i1 %cmp3839 to i32
  store i32 %cv3840, ptr %slot604, align 8
  %v3841 = load i32, ptr %slot602, align 8
  %v3842 = load i32, ptr %slot604, align 8
  %op3843 = and i32 %v3841, %v3842
  store i32 %op3843, ptr %slot605, align 8
  %v3844 = load i64, ptr %slot57, align 8
  store i64 %v3844, ptr %slot606, align 8
  %v3845 = load i32, ptr %slot605, align 8
  %op3846 = mul i32 %v3845, 4
  store i32 %op3846, ptr %slot607, align 8
  %v3847 = load i32, ptr %slot607, align 8
  %op3848 = or i32 %v3847, 0
  store i32 %op3848, ptr %slot608, align 8
  %v3849 = load i64, ptr %slot23, align 8
  store i64 %v3849, ptr %slot609, align 8
  %v3850 = load i64, ptr %slot56, align 8
  %v3851 = load i64, ptr %slot609, align 8
  %v3852 = load i64, ptr %slot601, align 8
  %v3853 = load i64, ptr %slot606, align 8
  %cv3854 = trunc i64 %v3853 to i32
  %v3855 = load i32, ptr %slot608, align 8
  %call3856 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v3850, i64 %v3851, i64 %v3852, i32 %cv3854, i32 %v3855) nomerge, !dbg !162
  store i32 %call3856, ptr %slot610, align 8
  %v3857 = load i32, ptr %slot610, align 8
  %cv3858 = zext i32 %v3857 to i64
  %cond3859 = icmp ne i64 %cv3858, 0
  br i1 %cond3859, label %bb_rcsuccess869, label %bb_rcfailure869
bb_rcfailure869:
  %v3860 = load i64, ptr %slot56, align 8
  %p3861 = inttoptr i64 %v3860 to ptr
  %call3862 = call i32 @myl_rc_take_failure(ptr %p3861) nomerge, !dbg !162
  store i32 %call3862, ptr %slot611, align 8
  %v3863 = load i64, ptr %slot1, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %v3865 = load i32, ptr %slot611, align 8
  %call3866 = call i32 @myl_qbe_rc_status(ptr %p3864, i32 %v3865) nomerge, !dbg !162
  store i32 %call3866, ptr %slot612, align 8
  br label %bb_failure
bb_rcsuccess869:
  %v3867 = load i32, ptr %slot605, align 8
  %cv3868 = zext i32 %v3867 to i64
  %cond3869 = icmp ne i64 %cv3868, 0
  br i1 %cond3869, label %bb_rchtaken872, label %bb_rchcopied872
bb_rchcopied872:
  %v3870 = load i64, ptr %slot14, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  %ld3872 = load i32, ptr %p3871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3872, ptr %slot613, align 8
  %v3873 = load i32, ptr %slot613, align 8
  %cv3874 = zext i32 %v3873 to i64
  %cond3875 = icmp ne i64 %cv3874, 0
  br i1 %cond3875, label %bb_rcslotdrop875, label %bb_rcslotdone875
bb_rcslotdrop875:
  %v3876 = load i64, ptr %slot14, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  store i32 0, ptr %p3877, align 4, !alias.scope !3, !noalias !4
  %v3878 = load i64, ptr %slot20, align 8
  store i64 %v3878, ptr %slot614, align 8
  %v3879 = load i64, ptr %slot15, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %ld3881 = load i32, ptr %p3880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3881, ptr %slot615, align 8
  %v3882 = load i32, ptr %slot615, align 8
  %op3883 = and i32 %v3882, 28
  store i32 %op3883, ptr %slot616, align 8
  %v3884 = load i32, ptr %slot616, align 8
  %cv3885 = zext i32 %v3884 to i64
  %cond3886 = icmp ne i64 %cv3885, 0
  br i1 %cond3886, label %bb_rcslotrole875, label %bb_rcslotowner875
bb_rcslotrole875:
  %v3887 = load i64, ptr %slot56, align 8
  store i64 %v3887, ptr %slot617, align 8
  %v3888 = load i64, ptr %slot617, align 8
  %v3889 = load i64, ptr %slot614, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3888, i64 %v3889) nomerge, !dbg !162
  br label %bb_rcslotdone875
bb_rcslotowner875:
  %v3890 = load i64, ptr %slot56, align 8
  store i64 %v3890, ptr %slot618, align 8
  %v3891 = load i64, ptr %slot618, align 8
  %v3892 = load i64, ptr %slot614, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3891, i64 %v3892) nomerge, !dbg !162
  br label %bb_rcslotdone875
bb_rcslotdone875:
  br label %bb_rchprepared872
bb_rchtaken872:
  %v3893 = load i64, ptr %slot14, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  store i32 0, ptr %p3894, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared872
bb_rchprepared872:
  %v3895 = load i64, ptr %slot17, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i32 2, ptr %p3896, align 4, !alias.scope !3, !noalias !4
  %v3897 = load i64, ptr %slot16, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  store i32 1, ptr %p3898, align 4, !alias.scope !3, !noalias !4
  %v3899 = load i64, ptr %slot20, align 8
  store i64 %v3899, ptr %slot619, align 8
  %v3900 = load i64, ptr %slot23, align 8
  store i64 %v3900, ptr %slot620, align 8
  %v3901 = load i64, ptr %slot620, align 8
  %v3902 = load i64, ptr %slot619, align 8
  %p3903 = inttoptr i64 %v3901 to ptr
  %p3904 = inttoptr i64 %v3902 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3904, ptr %p3903, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3905 = load i64, ptr %slot15, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  store i32 2, ptr %p3906, align 4, !alias.scope !3, !noalias !4
  %v3907 = load i64, ptr %slot17, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  %ld3909 = load i32, ptr %p3908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3909, ptr %slot621, align 8
  %v3910 = load i32, ptr %slot621, align 8
  %v3911 = load i64, ptr %slot15, align 8
  %p3912 = inttoptr i64 %v3911 to ptr
  store i32 %v3910, ptr %p3912, align 4, !alias.scope !3, !noalias !4
  %v3913 = load i64, ptr %slot16, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  store i32 0, ptr %p3914, align 4, !alias.scope !3, !noalias !4
  %v3915 = load i64, ptr %slot14, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  store i32 1, ptr %p3916, align 4, !alias.scope !3, !noalias !4
  %v3917 = load i64, ptr %slot619, align 8
  %v3918 = load i64, ptr %slot45, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  store i64 %v3917, ptr %p3919, align 8, !alias.scope !3, !noalias !4
  %v3920 = load i64, ptr %slot37, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  %ld3922 = load i64, ptr %p3921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3922, ptr %slot622, align 8
  %v3923 = load i64, ptr %slot45, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %ld3925 = load i64, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3925, ptr %slot623, align 8
  %v3926 = load i64, ptr %slot44, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  %ld3928 = load i64, ptr %p3927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3928, ptr %slot624, align 8
  %v3929 = load i64, ptr %slot622, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %ld3931 = load i64, ptr %p3930, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3931, ptr %slot625, align 8
  %v3932 = load i64, ptr %slot624, align 8
  %v3933 = load i64, ptr %slot625, align 8
  %cmp3934 = icmp ult i64 %v3932, %v3933
  %cv3935 = zext i1 %cmp3934 to i64
  store i64 %cv3935, ptr %slot626, align 8
  %v3936 = load i64, ptr %slot626, align 8
  %cond3937 = icmp ne i64 %v3936, 0
  br i1 %cond3937, label %bb_success899, label %bb_failed899
bb_failed899:
  %v3938 = load i64, ptr %slot1, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %v3940 = load i64, ptr %slot624, align 8
  %v3941 = load i64, ptr %slot625, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3939, i64 %v3940, i64 %v3941) nomerge, !dbg !164
  unreachable
bb_success899:
  %v3942 = load i64, ptr %slot45, align 8
  %p3943 = inttoptr i64 %v3942 to ptr
  %ld3944 = load i64, ptr %p3943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3944, ptr %slot627, align 8
  %v3945 = load i64, ptr %slot56, align 8
  %v3946 = load i64, ptr %slot622, align 8
  %v3947 = load i64, ptr %slot624, align 8
  %v3948 = load i64, ptr %slot627, align 8
  %call3949 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v3945, i64 %v3946, i64 %v3947, i64 %v3948) nomerge, !dbg !164
  store i32 %call3949, ptr %slot628, align 8
  %v3950 = load i32, ptr %slot628, align 8
  %cv3951 = zext i32 %v3950 to i64
  %cond3952 = icmp ne i64 %cv3951, 0
  br i1 %cond3952, label %bb_success902, label %bb_failed902
bb_failed902:
  %v3953 = load i64, ptr %slot1, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3954) nomerge, !dbg !164
  unreachable
bb_success902:
  %v3955 = load i64, ptr %slot44, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  store i64 0, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  %v3957 = load i64, ptr %slot14, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %ld3959 = load i32, ptr %p3958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3959, ptr %slot629, align 8
  %v3960 = load i32, ptr %slot629, align 8
  %cv3961 = zext i32 %v3960 to i64
  %cond3962 = icmp ne i64 %cv3961, 0
  br i1 %cond3962, label %bb_rcslotdrop905, label %bb_rcslotdone905
bb_rcslotdrop905:
  %v3963 = load i64, ptr %slot14, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 0, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot20, align 8
  store i64 %v3965, ptr %slot630, align 8
  %v3966 = load i64, ptr %slot15, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %ld3968 = load i32, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3968, ptr %slot631, align 8
  %v3969 = load i32, ptr %slot631, align 8
  %op3970 = and i32 %v3969, 28
  store i32 %op3970, ptr %slot632, align 8
  %v3971 = load i32, ptr %slot632, align 8
  %cv3972 = zext i32 %v3971 to i64
  %cond3973 = icmp ne i64 %cv3972, 0
  br i1 %cond3973, label %bb_rcslotrole905, label %bb_rcslotowner905
bb_rcslotrole905:
  %v3974 = load i64, ptr %slot56, align 8
  store i64 %v3974, ptr %slot633, align 8
  %v3975 = load i64, ptr %slot633, align 8
  %v3976 = load i64, ptr %slot630, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3975, i64 %v3976) nomerge, !dbg !164
  br label %bb_rcslotdone905
bb_rcslotowner905:
  %v3977 = load i64, ptr %slot56, align 8
  store i64 %v3977, ptr %slot634, align 8
  %v3978 = load i64, ptr %slot634, align 8
  %v3979 = load i64, ptr %slot630, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3978, i64 %v3979) nomerge, !dbg !164
  br label %bb_rcslotdone905
bb_rcslotdone905:
  %v3980 = load i64, ptr %slot34, align 8
  %v3981 = load i64, ptr %slot44, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  store i64 %v3980, ptr %p3982, align 8, !alias.scope !3, !noalias !4
  %v3983 = load i64, ptr %slot44, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  %ld3985 = load i64, ptr %p3984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3985, ptr %slot635, align 8
  %v3986 = load i64, ptr %slot635, align 8
  %op3987 = add i64 %v3986, 0
  store i64 %op3987, ptr %slot636, align 8
  %v3988 = load i64, ptr %slot636, align 8
  %v3989 = load i64, ptr %slot44, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  store i64 %v3988, ptr %p3990, align 8, !alias.scope !3, !noalias !4
  %v3991 = load i64, ptr %slot12, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  %ld3993 = load i32, ptr %p3992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3993, ptr %slot637, align 8
  %v3994 = load i32, ptr %slot637, align 8
  %cv3995 = zext i32 %v3994 to i64
  %cond3996 = icmp ne i64 %cv3995, 0
  br i1 %cond3996, label %bb_rcslotdrop916, label %bb_rcslotdone916
bb_rcslotdrop916:
  %v3997 = load i64, ptr %slot12, align 8
  %p3998 = inttoptr i64 %v3997 to ptr
  store i32 0, ptr %p3998, align 4, !alias.scope !3, !noalias !4
  %v3999 = load i64, ptr %slot19, align 8
  store i64 %v3999, ptr %slot638, align 8
  %v4000 = load i64, ptr %slot13, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  %ld4002 = load i32, ptr %p4001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4002, ptr %slot639, align 8
  %v4003 = load i32, ptr %slot639, align 8
  %op4004 = and i32 %v4003, 28
  store i32 %op4004, ptr %slot640, align 8
  %v4005 = load i32, ptr %slot640, align 8
  %cv4006 = zext i32 %v4005 to i64
  %cond4007 = icmp ne i64 %cv4006, 0
  br i1 %cond4007, label %bb_rcslotrole916, label %bb_rcslotowner916
bb_rcslotrole916:
  %v4008 = load i64, ptr %slot56, align 8
  store i64 %v4008, ptr %slot641, align 8
  %v4009 = load i64, ptr %slot641, align 8
  %v4010 = load i64, ptr %slot638, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4009, i64 %v4010) nomerge, !dbg !166
  br label %bb_rcslotdone916
bb_rcslotowner916:
  %v4011 = load i64, ptr %slot56, align 8
  store i64 %v4011, ptr %slot642, align 8
  %v4012 = load i64, ptr %slot642, align 8
  %v4013 = load i64, ptr %slot638, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4012, i64 %v4013) nomerge, !dbg !166
  br label %bb_rcslotdone916
bb_rcslotdone916:
  %v4014 = load i64, ptr %slot44, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i64, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4016, ptr %slot643, align 8
  %v4017 = load i64, ptr %slot12, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %ld4019 = load i32, ptr %p4018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4019, ptr %slot644, align 8
  %v4020 = load i64, ptr %slot13, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  %ld4022 = load i32, ptr %p4021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4022, ptr %slot645, align 8
  %v4023 = load i32, ptr %slot645, align 8
  %op4024 = and i32 %v4023, 24
  store i32 %op4024, ptr %slot645, align 8
  %v4025 = load i32, ptr %slot645, align 8
  %cmp4026 = icmp eq i32 %v4025, 0
  %cv4027 = zext i1 %cmp4026 to i32
  store i32 %cv4027, ptr %slot646, align 8
  %v4028 = load i32, ptr %slot644, align 8
  %v4029 = load i32, ptr %slot646, align 8
  %op4030 = and i32 %v4028, %v4029
  store i32 %op4030, ptr %slot647, align 8
  %v4031 = load i64, ptr %slot57, align 8
  store i64 %v4031, ptr %slot648, align 8
  %v4032 = load i32, ptr %slot647, align 8
  %op4033 = mul i32 %v4032, 4
  store i32 %op4033, ptr %slot649, align 8
  %v4034 = load i32, ptr %slot649, align 8
  %op4035 = or i32 %v4034, 0
  store i32 %op4035, ptr %slot650, align 8
  %v4036 = load i64, ptr %slot23, align 8
  store i64 %v4036, ptr %slot651, align 8
  %v4037 = load i64, ptr %slot56, align 8
  %v4038 = load i64, ptr %slot651, align 8
  %v4039 = load i64, ptr %slot643, align 8
  %v4040 = load i64, ptr %slot648, align 8
  %cv4041 = trunc i64 %v4040 to i32
  %v4042 = load i32, ptr %slot650, align 8
  %call4043 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v4037, i64 %v4038, i64 %v4039, i32 %cv4041, i32 %v4042) nomerge, !dbg !168
  store i32 %call4043, ptr %slot652, align 8
  %v4044 = load i32, ptr %slot652, align 8
  %cv4045 = zext i32 %v4044 to i64
  %cond4046 = icmp ne i64 %cv4045, 0
  br i1 %cond4046, label %bb_rcsuccess937, label %bb_rcfailure937
bb_rcfailure937:
  %v4047 = load i64, ptr %slot56, align 8
  %p4048 = inttoptr i64 %v4047 to ptr
  %call4049 = call i32 @myl_rc_take_failure(ptr %p4048) nomerge, !dbg !168
  store i32 %call4049, ptr %slot653, align 8
  %v4050 = load i64, ptr %slot1, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  %v4052 = load i32, ptr %slot653, align 8
  %call4053 = call i32 @myl_qbe_rc_status(ptr %p4051, i32 %v4052) nomerge, !dbg !168
  store i32 %call4053, ptr %slot654, align 8
  br label %bb_failure
bb_rcsuccess937:
  %v4054 = load i32, ptr %slot647, align 8
  %cv4055 = zext i32 %v4054 to i64
  %cond4056 = icmp ne i64 %cv4055, 0
  br i1 %cond4056, label %bb_rchtaken940, label %bb_rchcopied940
bb_rchcopied940:
  %v4057 = load i64, ptr %slot12, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %ld4059 = load i32, ptr %p4058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4059, ptr %slot655, align 8
  %v4060 = load i32, ptr %slot655, align 8
  %cv4061 = zext i32 %v4060 to i64
  %cond4062 = icmp ne i64 %cv4061, 0
  br i1 %cond4062, label %bb_rcslotdrop943, label %bb_rcslotdone943
bb_rcslotdrop943:
  %v4063 = load i64, ptr %slot12, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  store i32 0, ptr %p4064, align 4, !alias.scope !3, !noalias !4
  %v4065 = load i64, ptr %slot19, align 8
  store i64 %v4065, ptr %slot656, align 8
  %v4066 = load i64, ptr %slot13, align 8
  %p4067 = inttoptr i64 %v4066 to ptr
  %ld4068 = load i32, ptr %p4067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4068, ptr %slot657, align 8
  %v4069 = load i32, ptr %slot657, align 8
  %op4070 = and i32 %v4069, 28
  store i32 %op4070, ptr %slot658, align 8
  %v4071 = load i32, ptr %slot658, align 8
  %cv4072 = zext i32 %v4071 to i64
  %cond4073 = icmp ne i64 %cv4072, 0
  br i1 %cond4073, label %bb_rcslotrole943, label %bb_rcslotowner943
bb_rcslotrole943:
  %v4074 = load i64, ptr %slot56, align 8
  store i64 %v4074, ptr %slot659, align 8
  %v4075 = load i64, ptr %slot659, align 8
  %v4076 = load i64, ptr %slot656, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4075, i64 %v4076) nomerge, !dbg !168
  br label %bb_rcslotdone943
bb_rcslotowner943:
  %v4077 = load i64, ptr %slot56, align 8
  store i64 %v4077, ptr %slot660, align 8
  %v4078 = load i64, ptr %slot660, align 8
  %v4079 = load i64, ptr %slot656, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4078, i64 %v4079) nomerge, !dbg !168
  br label %bb_rcslotdone943
bb_rcslotdone943:
  br label %bb_rchprepared940
bb_rchtaken940:
  %v4080 = load i64, ptr %slot12, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  store i32 0, ptr %p4081, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared940
bb_rchprepared940:
  %v4082 = load i64, ptr %slot17, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  store i32 2, ptr %p4083, align 4, !alias.scope !3, !noalias !4
  %v4084 = load i64, ptr %slot16, align 8
  %p4085 = inttoptr i64 %v4084 to ptr
  store i32 1, ptr %p4085, align 4, !alias.scope !3, !noalias !4
  %v4086 = load i64, ptr %slot19, align 8
  store i64 %v4086, ptr %slot661, align 8
  %v4087 = load i64, ptr %slot23, align 8
  store i64 %v4087, ptr %slot662, align 8
  %v4088 = load i64, ptr %slot662, align 8
  %v4089 = load i64, ptr %slot661, align 8
  %p4090 = inttoptr i64 %v4088 to ptr
  %p4091 = inttoptr i64 %v4089 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4091, ptr %p4090, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4092 = load i64, ptr %slot13, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  store i32 2, ptr %p4093, align 4, !alias.scope !3, !noalias !4
  %v4094 = load i64, ptr %slot17, align 8
  %p4095 = inttoptr i64 %v4094 to ptr
  %ld4096 = load i32, ptr %p4095, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4096, ptr %slot663, align 8
  %v4097 = load i32, ptr %slot663, align 8
  %v4098 = load i64, ptr %slot13, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  store i32 %v4097, ptr %p4099, align 4, !alias.scope !3, !noalias !4
  %v4100 = load i64, ptr %slot16, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  store i32 0, ptr %p4101, align 4, !alias.scope !3, !noalias !4
  %v4102 = load i64, ptr %slot12, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  store i32 1, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  %v4104 = load i64, ptr %slot661, align 8
  %v4105 = load i64, ptr %slot44, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i64 %v4104, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot49, align 8
  store i64 %v4107, ptr %slot664, align 8
  %v4108 = load i64, ptr %slot664, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  store i64 0, ptr %p4109, align 8, !alias.scope !3, !noalias !4
  %v4110 = load i64, ptr %slot664, align 8
  %p4112 = inttoptr i64 %v4110 to ptr
  %gep4113 = getelementptr i8, ptr %p4112, i64 8
  %op4111 = ptrtoint ptr %gep4113 to i64
  store i64 %op4111, ptr %slot665, align 8
  %v4114 = load i64, ptr %slot665, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  store i64 0, ptr %p4115, align 8, !alias.scope !3, !noalias !4
  %v4116 = load i64, ptr %slot664, align 8
  %p4118 = inttoptr i64 %v4116 to ptr
  %gep4119 = getelementptr i8, ptr %p4118, i64 16
  %op4117 = ptrtoint ptr %gep4119 to i64
  store i64 %op4117, ptr %slot666, align 8
  %v4120 = load i64, ptr %slot666, align 8
  %p4121 = inttoptr i64 %v4120 to ptr
  store i64 0, ptr %p4121, align 8, !alias.scope !3, !noalias !4
  %v4122 = load i64, ptr %slot664, align 8
  %p4124 = inttoptr i64 %v4122 to ptr
  %gep4125 = getelementptr i8, ptr %p4124, i64 24
  %op4123 = ptrtoint ptr %gep4125 to i64
  store i64 %op4123, ptr %slot667, align 8
  %v4126 = load i64, ptr %slot667, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  store i64 0, ptr %p4127, align 8, !alias.scope !3, !noalias !4
  %v4128 = load i64, ptr %slot664, align 8
  %p4130 = inttoptr i64 %v4128 to ptr
  %gep4131 = getelementptr i8, ptr %p4130, i64 32
  %op4129 = ptrtoint ptr %gep4131 to i64
  store i64 %op4129, ptr %slot668, align 8
  %v4132 = load i64, ptr %slot668, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i64 0, ptr %p4133, align 8, !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot664, align 8
  %p4136 = inttoptr i64 %v4134 to ptr
  %gep4137 = getelementptr i8, ptr %p4136, i64 40
  %op4135 = ptrtoint ptr %gep4137 to i64
  store i64 %op4135, ptr %slot669, align 8
  %v4138 = load i64, ptr %slot669, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  store i64 0, ptr %p4139, align 8, !alias.scope !3, !noalias !4
  %v4140 = load i64, ptr %slot664, align 8
  %p4142 = inttoptr i64 %v4140 to ptr
  %gep4143 = getelementptr i8, ptr %p4142, i64 48
  %op4141 = ptrtoint ptr %gep4143 to i64
  store i64 %op4141, ptr %slot670, align 8
  %v4144 = load i64, ptr %slot670, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i64 0, ptr %p4145, align 8, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot664, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  store i32 2, ptr %p4147, align 4, !alias.scope !3, !noalias !4
  %v4148 = load i64, ptr %slot18, align 8
  %p4149 = inttoptr i64 %v4148 to ptr
  store i32 1, ptr %p4149, align 4, !alias.scope !3, !noalias !4
  %v4150 = load i64, ptr %slot44, align 8
  %p4151 = inttoptr i64 %v4150 to ptr
  %ld4152 = load i64, ptr %p4151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4152, ptr %slot671, align 8
  %v4153 = load i64, ptr %slot664, align 8
  %p4155 = inttoptr i64 %v4153 to ptr
  %gep4156 = getelementptr i8, ptr %p4155, i64 8
  %op4154 = ptrtoint ptr %gep4156 to i64
  store i64 %op4154, ptr %slot672, align 8
  %v4157 = load i64, ptr %slot57, align 8
  store i64 %v4157, ptr %slot673, align 8
  %v4158 = load i64, ptr %slot44, align 8
  %p4159 = inttoptr i64 %v4158 to ptr
  %ld4160 = load i64, ptr %p4159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4160, ptr %slot674, align 8
  %v4161 = load i64, ptr %slot23, align 8
  store i64 %v4161, ptr %slot675, align 8
  %v4162 = load i64, ptr %slot57, align 8
  store i64 %v4162, ptr %slot676, align 8
  %v4163 = load i64, ptr %slot674, align 8
  %op4164 = add i64 %v4163, 16
  store i64 %op4164, ptr %slot677, align 8
  %v4165 = load i64, ptr %slot677, align 8
  %p4166 = inttoptr i64 %v4165 to ptr
  %ld4167 = load i64, ptr %p4166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4167, ptr %slot678, align 8
  %v4168 = load i64, ptr %slot678, align 8
  %cmp4169 = icmp ne i64 %v4168, 0
  %cv4170 = zext i1 %cmp4169 to i32
  store i32 %cv4170, ptr %slot679, align 8
  %v4171 = load i32, ptr %slot679, align 8
  %cv4172 = zext i32 %v4171 to i64
  %cond4173 = icmp ne i64 %cv4172, 0
  br i1 %cond4173, label %bb_rcmoveheader979, label %bb_rcmovenext979
bb_rcmoveheader979:
  %v4174 = load i64, ptr %slot678, align 8
  %op4175 = sub i64 %v4174, 16
  store i64 %op4175, ptr %slot680, align 8
  %v4176 = load i64, ptr %slot678, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  %rgep4178 = getelementptr i8, ptr %p4177, i64 -16
  %ld4179 = load i64, ptr %rgep4178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4179, ptr %slot681, align 8
  %v4180 = load i64, ptr %slot681, align 8
  %op4181 = and i64 %v4180, 5764607523034234881
  store i64 %op4181, ptr %slot682, align 8
  %v4182 = load i64, ptr %slot682, align 8
  %cmp4183 = icmp ne i64 %v4182, 0
  %cv4184 = zext i1 %cmp4183 to i32
  store i32 %cv4184, ptr %slot683, align 8
  %v4185 = load i32, ptr %slot683, align 8
  %cv4186 = zext i32 %v4185 to i64
  %cond4187 = icmp ne i64 %cv4186, 0
  br i1 %cond4187, label %bb_rcmoveslow976, label %bb_rcmovenext979
bb_rcmovenext979:
  %v4188 = load i64, ptr %slot674, align 8
  %op4189 = add i64 %v4188, 24
  store i64 %op4189, ptr %slot684, align 8
  %v4190 = load i64, ptr %slot684, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %ld4192 = load i64, ptr %p4191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4192, ptr %slot685, align 8
  %v4193 = load i64, ptr %slot685, align 8
  %cmp4194 = icmp ne i64 %v4193, 0
  %cv4195 = zext i1 %cmp4194 to i32
  store i32 %cv4195, ptr %slot686, align 8
  %v4196 = load i32, ptr %slot686, align 8
  %cv4197 = zext i32 %v4196 to i64
  %cond4198 = icmp ne i64 %cv4197, 0
  br i1 %cond4198, label %bb_rcmoveheader987, label %bb_rcmovenext987
bb_rcmoveheader987:
  %v4199 = load i64, ptr %slot685, align 8
  %op4200 = sub i64 %v4199, 16
  store i64 %op4200, ptr %slot687, align 8
  %v4201 = load i64, ptr %slot685, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  %rgep4203 = getelementptr i8, ptr %p4202, i64 -16
  %ld4204 = load i64, ptr %rgep4203, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4204, ptr %slot688, align 8
  %v4205 = load i64, ptr %slot688, align 8
  %op4206 = and i64 %v4205, 5764607523034234881
  store i64 %op4206, ptr %slot689, align 8
  %v4207 = load i64, ptr %slot689, align 8
  %cmp4208 = icmp ne i64 %v4207, 0
  %cv4209 = zext i1 %cmp4208 to i32
  store i32 %cv4209, ptr %slot690, align 8
  %v4210 = load i32, ptr %slot690, align 8
  %cv4211 = zext i32 %v4210 to i64
  %cond4212 = icmp ne i64 %cv4211, 0
  br i1 %cond4212, label %bb_rcmoveslow976, label %bb_rcmovenext987
bb_rcmovenext987:
  %v4213 = load i64, ptr %slot674, align 8
  %op4214 = add i64 %v4213, 32
  store i64 %op4214, ptr %slot691, align 8
  %v4215 = load i64, ptr %slot691, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i64, ptr %p4216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4217, ptr %slot692, align 8
  %v4218 = load i64, ptr %slot692, align 8
  %cmp4219 = icmp ne i64 %v4218, 0
  %cv4220 = zext i1 %cmp4219 to i32
  store i32 %cv4220, ptr %slot693, align 8
  %v4221 = load i32, ptr %slot693, align 8
  %cv4222 = zext i32 %v4221 to i64
  %cond4223 = icmp ne i64 %cv4222, 0
  br i1 %cond4223, label %bb_rcmoveheader995, label %bb_rcmovenext995
bb_rcmoveheader995:
  %v4224 = load i64, ptr %slot692, align 8
  %op4225 = sub i64 %v4224, 16
  store i64 %op4225, ptr %slot694, align 8
  %v4226 = load i64, ptr %slot692, align 8
  %p4227 = inttoptr i64 %v4226 to ptr
  %rgep4228 = getelementptr i8, ptr %p4227, i64 -16
  %ld4229 = load i64, ptr %rgep4228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4229, ptr %slot695, align 8
  %v4230 = load i64, ptr %slot695, align 8
  %op4231 = and i64 %v4230, 5764607523034234881
  store i64 %op4231, ptr %slot696, align 8
  %v4232 = load i64, ptr %slot696, align 8
  %cmp4233 = icmp ne i64 %v4232, 0
  %cv4234 = zext i1 %cmp4233 to i32
  store i32 %cv4234, ptr %slot697, align 8
  %v4235 = load i32, ptr %slot697, align 8
  %cv4236 = zext i32 %v4235 to i64
  %cond4237 = icmp ne i64 %cv4236, 0
  br i1 %cond4237, label %bb_rcmoveslow976, label %bb_rcmovenext995
bb_rcmovenext995:
  %v4238 = load i64, ptr %slot674, align 8
  %v4239 = load i64, ptr %slot675, align 8
  %p4240 = inttoptr i64 %v4238 to ptr
  %p4241 = inttoptr i64 %v4239 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4241, ptr %p4240, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4242 = load i64, ptr %slot674, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  store i64 0, ptr %p4243, align 8, !alias.scope !3, !noalias !4
  %v4244 = load i64, ptr %slot674, align 8
  %op4245 = add i64 %v4244, 8
  store i64 %op4245, ptr %slot698, align 8
  %v4246 = load i64, ptr %slot698, align 8
  %p4247 = inttoptr i64 %v4246 to ptr
  store i64 0, ptr %p4247, align 8, !alias.scope !3, !noalias !4
  %v4248 = load i64, ptr %slot674, align 8
  %op4249 = add i64 %v4248, 16
  store i64 %op4249, ptr %slot699, align 8
  %v4250 = load i64, ptr %slot699, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  store i64 0, ptr %p4251, align 8, !alias.scope !3, !noalias !4
  %v4252 = load i64, ptr %slot674, align 8
  %op4253 = add i64 %v4252, 24
  store i64 %op4253, ptr %slot700, align 8
  %v4254 = load i64, ptr %slot700, align 8
  %p4255 = inttoptr i64 %v4254 to ptr
  store i64 0, ptr %p4255, align 8, !alias.scope !3, !noalias !4
  %v4256 = load i64, ptr %slot674, align 8
  %op4257 = add i64 %v4256, 32
  store i64 %op4257, ptr %slot701, align 8
  %v4258 = load i64, ptr %slot701, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  store i64 0, ptr %p4259, align 8, !alias.scope !3, !noalias !4
  %v4260 = load i64, ptr %slot674, align 8
  %op4261 = add i64 %v4260, 40
  store i64 %op4261, ptr %slot702, align 8
  %v4262 = load i64, ptr %slot702, align 8
  %p4263 = inttoptr i64 %v4262 to ptr
  store i64 0, ptr %p4263, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved976
bb_rcmoveslow976:
  %v4264 = load i64, ptr %slot56, align 8
  %v4265 = load i64, ptr %slot675, align 8
  %v4266 = load i64, ptr %slot674, align 8
  %v4267 = load i64, ptr %slot676, align 8
  %cv4268 = trunc i64 %v4267 to i32
  %call4269 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v4264, i64 %v4265, i64 %v4266, i32 %cv4268) nomerge, !dbg !170
  store i32 %call4269, ptr %slot703, align 8
  %v4270 = load i32, ptr %slot703, align 8
  %cv4271 = zext i32 %v4270 to i64
  %cond4272 = icmp ne i64 %cv4271, 0
  br i1 %cond4272, label %bb_rcsuccess1007, label %bb_rcfailure1007
bb_rcfailure1007:
  %v4273 = load i64, ptr %slot56, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %call4275 = call i32 @myl_rc_take_failure(ptr %p4274) nomerge, !dbg !170
  store i32 %call4275, ptr %slot704, align 8
  %v4276 = load i64, ptr %slot1, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  %v4278 = load i32, ptr %slot704, align 8
  %call4279 = call i32 @myl_qbe_rc_status(ptr %p4277, i32 %v4278) nomerge, !dbg !170
  store i32 %call4279, ptr %slot705, align 8
  br label %bb_failure
bb_rcsuccess1007:
  br label %bb_rcmoved976
bb_rcmoved976:
  %v4280 = load i64, ptr %slot12, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  store i32 0, ptr %p4281, align 4, !alias.scope !3, !noalias !4
  %v4282 = load i64, ptr %slot17, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  store i32 2, ptr %p4283, align 4, !alias.scope !3, !noalias !4
  %v4284 = load i64, ptr %slot16, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  store i32 1, ptr %p4285, align 4, !alias.scope !3, !noalias !4
  %v4286 = load i64, ptr %slot23, align 8
  store i64 %v4286, ptr %slot706, align 8
  %v4287 = load i64, ptr %slot706, align 8
  %v4288 = load i64, ptr %slot672, align 8
  %p4289 = inttoptr i64 %v4287 to ptr
  %p4290 = inttoptr i64 %v4288 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4290, ptr %p4289, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4291 = load i64, ptr %slot16, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i32 0, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot664, align 8
  %v4294 = load i64, ptr %slot44, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  store i64 %v4293, ptr %p4295, align 8, !alias.scope !3, !noalias !4
  %v4296 = load i64, ptr %slot44, align 8
  %p4297 = inttoptr i64 %v4296 to ptr
  %ld4298 = load i64, ptr %p4297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4298, ptr %slot707, align 8
  %v4299 = load i64, ptr %slot19, align 8
  store i64 %v4299, ptr %slot708, align 8
  %v4300 = load i64, ptr %slot707, align 8
  %v4301 = load i64, ptr %slot708, align 8
  %p4302 = inttoptr i64 %v4300 to ptr
  %p4303 = inttoptr i64 %v4301 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4303, ptr %p4302, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4304 = load i64, ptr %slot13, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  store i32 2, ptr %p4305, align 4, !alias.scope !3, !noalias !4
  %v4306 = load i64, ptr %slot12, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  store i32 1, ptr %p4307, align 4, !alias.scope !3, !noalias !4
  %v4308 = load i64, ptr %slot708, align 8
  %v4309 = load i64, ptr %slot44, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i64 %v4308, ptr %p4310, align 8, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot44, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  %ld4313 = load i64, ptr %p4312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4313, ptr %slot709, align 8
  %v4314 = load i64, ptr %slot12, align 8
  %p4315 = inttoptr i64 %v4314 to ptr
  %ld4316 = load i32, ptr %p4315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4316, ptr %slot710, align 8
  %v4317 = load i64, ptr %slot13, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %ld4319 = load i32, ptr %p4318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4319, ptr %slot711, align 8
  %v4320 = load i32, ptr %slot711, align 8
  %op4321 = and i32 %v4320, 24
  store i32 %op4321, ptr %slot711, align 8
  %v4322 = load i32, ptr %slot711, align 8
  %cmp4323 = icmp eq i32 %v4322, 0
  %cv4324 = zext i1 %cmp4323 to i32
  store i32 %cv4324, ptr %slot712, align 8
  %v4325 = load i32, ptr %slot710, align 8
  %v4326 = load i32, ptr %slot712, align 8
  %op4327 = and i32 %v4325, %v4326
  store i32 %op4327, ptr %slot713, align 8
  %v4328 = load i32, ptr %slot713, align 8
  %cv4329 = zext i32 %v4328 to i64
  %cond4330 = icmp ne i64 %cv4329, 0
  br i1 %cond4330, label %bb_rcprivateown1026, label %bb_rcprivateloan1026
bb_rcprivateown1026:
  %v4331 = load i64, ptr %slot23, align 8
  store i64 %v4331, ptr %slot714, align 8
  %v4332 = load i64, ptr %slot57, align 8
  store i64 %v4332, ptr %slot715, align 8
  %v4333 = load i64, ptr %slot56, align 8
  %v4334 = load i64, ptr %slot714, align 8
  %v4335 = load i64, ptr %slot709, align 8
  %v4336 = load i64, ptr %slot715, align 8
  %cv4337 = trunc i64 %v4336 to i32
  %call4338 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v4333, i64 %v4334, i64 %v4335, i32 %cv4337) nomerge, !dbg !172
  store i32 %call4338, ptr %slot716, align 8
  %v4339 = load i32, ptr %slot716, align 8
  %cv4340 = zext i32 %v4339 to i64
  %cond4341 = icmp ne i64 %cv4340, 0
  br i1 %cond4341, label %bb_rcsuccess1030, label %bb_rcfailure1030
bb_rcfailure1030:
  %v4342 = load i64, ptr %slot56, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %call4344 = call i32 @myl_rc_take_failure(ptr %p4343) nomerge, !dbg !172
  store i32 %call4344, ptr %slot717, align 8
  %v4345 = load i64, ptr %slot1, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  %v4347 = load i32, ptr %slot717, align 8
  %call4348 = call i32 @myl_qbe_rc_status(ptr %p4346, i32 %v4347) nomerge, !dbg !172
  store i32 %call4348, ptr %slot718, align 8
  br label %bb_failure
bb_rcsuccess1030:
  %v4349 = load i64, ptr %slot12, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  store i32 0, ptr %p4350, align 4, !alias.scope !3, !noalias !4
  %v4351 = load i64, ptr %slot17, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  store i32 2, ptr %p4352, align 4, !alias.scope !3, !noalias !4
  %v4353 = load i64, ptr %slot16, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  store i32 1, ptr %p4354, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1026
bb_rcprivateloan1026:
  %v4355 = load i64, ptr %slot12, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  %ld4357 = load i32, ptr %p4356, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4357, ptr %slot719, align 8
  %v4358 = load i64, ptr %slot13, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  %ld4360 = load i32, ptr %p4359, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4360, ptr %slot720, align 8
  %v4361 = load i32, ptr %slot720, align 8
  %cmp4362 = icmp eq i32 %v4361, 16
  %cv4363 = zext i1 %cmp4362 to i32
  store i32 %cv4363, ptr %slot721, align 8
  %v4364 = load i32, ptr %slot721, align 8
  %v4365 = load i32, ptr %slot719, align 8
  %op4366 = and i32 %v4364, %v4365
  store i32 %op4366, ptr %slot721, align 8
  %v4367 = load i32, ptr %slot721, align 8
  %cv4368 = zext i32 %v4367 to i64
  %cond4369 = icmp ne i64 %cv4368, 0
  br i1 %cond4369, label %bb_rcprivatemove1026, label %bb_rcprivatenew1026
bb_rcprivatemove1026:
  %v4370 = load i64, ptr %slot23, align 8
  store i64 %v4370, ptr %slot722, align 8
  %v4371 = load i64, ptr %slot709, align 8
  %v4372 = load i64, ptr %slot722, align 8
  %p4373 = inttoptr i64 %v4371 to ptr
  %p4374 = inttoptr i64 %v4372 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4374, ptr %p4373, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot709, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  call void @llvm.memset.p0.i64(ptr %p4376, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v4377 = load i64, ptr %slot17, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  store i32 2, ptr %p4378, align 4, !alias.scope !3, !noalias !4
  %v4379 = load i64, ptr %slot17, align 8
  %p4380 = inttoptr i64 %v4379 to ptr
  store i32 16, ptr %p4380, align 4, !alias.scope !3, !noalias !4
  %v4381 = load i64, ptr %slot16, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i32 1, ptr %p4382, align 4, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot12, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  store i32 0, ptr %p4384, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1026
bb_rcprivatenew1026:
  %v4385 = load i64, ptr %slot23, align 8
  store i64 %v4385, ptr %slot723, align 8
  %v4386 = load i64, ptr %slot56, align 8
  %v4387 = load i64, ptr %slot723, align 8
  %v4388 = load i64, ptr %slot709, align 8
  %call4389 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v4386, i64 %v4387, i64 %v4388) nomerge, !dbg !172
  store i32 %call4389, ptr %slot724, align 8
  %v4390 = load i32, ptr %slot724, align 8
  %cv4391 = zext i32 %v4390 to i64
  %cond4392 = icmp ne i64 %cv4391, 0
  br i1 %cond4392, label %bb_rcsuccess1048, label %bb_rcfailure1048
bb_rcfailure1048:
  %v4393 = load i64, ptr %slot56, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  %call4395 = call i32 @myl_rc_take_failure(ptr %p4394) nomerge, !dbg !172
  store i32 %call4395, ptr %slot725, align 8
  %v4396 = load i64, ptr %slot1, align 8
  %p4397 = inttoptr i64 %v4396 to ptr
  %v4398 = load i32, ptr %slot725, align 8
  %call4399 = call i32 @myl_qbe_rc_status(ptr %p4397, i32 %v4398) nomerge, !dbg !172
  store i32 %call4399, ptr %slot726, align 8
  br label %bb_failure
bb_rcsuccess1048:
  %v4400 = load i64, ptr %slot17, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  store i32 2, ptr %p4401, align 4, !alias.scope !3, !noalias !4
  %v4402 = load i64, ptr %slot17, align 8
  %p4403 = inttoptr i64 %v4402 to ptr
  store i32 16, ptr %p4403, align 4, !alias.scope !3, !noalias !4
  %v4404 = load i64, ptr %slot16, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  store i32 1, ptr %p4405, align 4, !alias.scope !3, !noalias !4
  %v4406 = load i64, ptr %slot12, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  %ld4408 = load i32, ptr %p4407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4408, ptr %slot727, align 8
  %v4409 = load i32, ptr %slot727, align 8
  %cv4410 = zext i32 %v4409 to i64
  %cond4411 = icmp ne i64 %cv4410, 0
  br i1 %cond4411, label %bb_rcslotdrop1056, label %bb_rcslotdone1056
bb_rcslotdrop1056:
  %v4412 = load i64, ptr %slot12, align 8
  %p4413 = inttoptr i64 %v4412 to ptr
  store i32 0, ptr %p4413, align 4, !alias.scope !3, !noalias !4
  %v4414 = load i64, ptr %slot19, align 8
  store i64 %v4414, ptr %slot728, align 8
  %v4415 = load i64, ptr %slot13, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %ld4417 = load i32, ptr %p4416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4417, ptr %slot729, align 8
  %v4418 = load i32, ptr %slot729, align 8
  %op4419 = and i32 %v4418, 28
  store i32 %op4419, ptr %slot730, align 8
  %v4420 = load i32, ptr %slot730, align 8
  %cv4421 = zext i32 %v4420 to i64
  %cond4422 = icmp ne i64 %cv4421, 0
  br i1 %cond4422, label %bb_rcslotrole1056, label %bb_rcslotowner1056
bb_rcslotrole1056:
  %v4423 = load i64, ptr %slot56, align 8
  store i64 %v4423, ptr %slot731, align 8
  %v4424 = load i64, ptr %slot731, align 8
  %v4425 = load i64, ptr %slot728, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4424, i64 %v4425) nomerge, !dbg !172
  br label %bb_rcslotdone1056
bb_rcslotowner1056:
  %v4426 = load i64, ptr %slot56, align 8
  store i64 %v4426, ptr %slot732, align 8
  %v4427 = load i64, ptr %slot732, align 8
  %v4428 = load i64, ptr %slot728, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4427, i64 %v4428) nomerge, !dbg !172
  br label %bb_rcslotdone1056
bb_rcslotdone1056:
  br label %bb_rcprivateprepared1026
bb_rcprivateprepared1026:
  %v4429 = load i64, ptr %slot10, align 8
  %p4430 = inttoptr i64 %v4429 to ptr
  %ld4431 = load i32, ptr %p4430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4431, ptr %slot733, align 8
  %v4432 = load i32, ptr %slot733, align 8
  %cv4433 = zext i32 %v4432 to i64
  %cond4434 = icmp ne i64 %cv4433, 0
  br i1 %cond4434, label %bb_rcslotdrop1066, label %bb_rcslotdone1066
bb_rcslotdrop1066:
  %v4435 = load i64, ptr %slot10, align 8
  %p4436 = inttoptr i64 %v4435 to ptr
  store i32 0, ptr %p4436, align 4, !alias.scope !3, !noalias !4
  %v4437 = load i64, ptr %slot41, align 8
  store i64 %v4437, ptr %slot734, align 8
  %v4438 = load i64, ptr %slot11, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  %ld4440 = load i32, ptr %p4439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4440, ptr %slot735, align 8
  %v4441 = load i32, ptr %slot735, align 8
  %op4442 = and i32 %v4441, 28
  store i32 %op4442, ptr %slot736, align 8
  %v4443 = load i32, ptr %slot736, align 8
  %cv4444 = zext i32 %v4443 to i64
  %cond4445 = icmp ne i64 %cv4444, 0
  br i1 %cond4445, label %bb_rcslotrole1066, label %bb_rcslotowner1066
bb_rcslotrole1066:
  %v4446 = load i64, ptr %slot56, align 8
  store i64 %v4446, ptr %slot737, align 8
  %v4447 = load i64, ptr %slot737, align 8
  %v4448 = load i64, ptr %slot734, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v4447, i64 %v4448) nomerge, !dbg !172
  br label %bb_rcslotdone1066
bb_rcslotowner1066:
  %v4449 = load i64, ptr %slot56, align 8
  store i64 %v4449, ptr %slot738, align 8
  %v4450 = load i64, ptr %slot738, align 8
  %v4451 = load i64, ptr %slot734, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v4450, i64 %v4451) nomerge, !dbg !172
  br label %bb_rcslotdone1066
bb_rcslotdone1066:
  %v4452 = load i64, ptr %slot41, align 8
  store i64 %v4452, ptr %slot739, align 8
  %v4453 = load i64, ptr %slot23, align 8
  store i64 %v4453, ptr %slot740, align 8
  %v4454 = load i64, ptr %slot740, align 8
  %v4455 = load i64, ptr %slot739, align 8
  %p4456 = inttoptr i64 %v4454 to ptr
  %p4457 = inttoptr i64 %v4455 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4457, ptr %p4456, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v4458 = load i64, ptr %slot16, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  store i32 0, ptr %p4459, align 4, !alias.scope !3, !noalias !4
  %v4460 = load i64, ptr %slot11, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  store i32 2, ptr %p4461, align 4, !alias.scope !3, !noalias !4
  %v4462 = load i64, ptr %slot17, align 8
  %p4463 = inttoptr i64 %v4462 to ptr
  %ld4464 = load i32, ptr %p4463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4464, ptr %slot741, align 8
  %v4465 = load i32, ptr %slot741, align 8
  %v4466 = load i64, ptr %slot11, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  store i32 %v4465, ptr %p4467, align 4, !alias.scope !3, !noalias !4
  %v4468 = load i64, ptr %slot10, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  store i32 1, ptr %p4469, align 4, !alias.scope !3, !noalias !4
  %v4470 = load i64, ptr %slot29, align 8
  %p4471 = inttoptr i64 %v4470 to ptr
  %ld4472 = load i64, ptr %p4471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4472, ptr %slot742, align 8
  %v4473 = load i64, ptr %slot742, align 8
  %v4474 = load i64, ptr %slot44, align 8
  %p4475 = inttoptr i64 %v4474 to ptr
  store i64 %v4473, ptr %p4475, align 8, !alias.scope !3, !noalias !4
  %v4476 = load i64, ptr %slot44, align 8
  %p4477 = inttoptr i64 %v4476 to ptr
  %ld4478 = load i64, ptr %p4477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4478, ptr %slot743, align 8
  %v4479 = load i64, ptr %slot743, align 8
  %op4480 = add i64 %v4479, 0
  store i64 %op4480, ptr %slot744, align 8
  %v4481 = load i64, ptr %slot744, align 8
  %v4482 = load i64, ptr %slot44, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  store i64 %v4481, ptr %p4483, align 8, !alias.scope !3, !noalias !4
  %v4484 = load i64, ptr %slot12, align 8
  %p4485 = inttoptr i64 %v4484 to ptr
  %ld4486 = load i32, ptr %p4485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4486, ptr %slot745, align 8
  %v4487 = load i32, ptr %slot745, align 8
  %cv4488 = zext i32 %v4487 to i64
  %cond4489 = icmp ne i64 %cv4488, 0
  br i1 %cond4489, label %bb_rcslotdrop1085, label %bb_rcslotdone1085
bb_rcslotdrop1085:
  %v4490 = load i64, ptr %slot12, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i32 0, ptr %p4491, align 4, !alias.scope !3, !noalias !4
  %v4492 = load i64, ptr %slot19, align 8
  store i64 %v4492, ptr %slot746, align 8
  %v4493 = load i64, ptr %slot13, align 8
  %p4494 = inttoptr i64 %v4493 to ptr
  %ld4495 = load i32, ptr %p4494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4495, ptr %slot747, align 8
  %v4496 = load i32, ptr %slot747, align 8
  %op4497 = and i32 %v4496, 28
  store i32 %op4497, ptr %slot748, align 8
  %v4498 = load i32, ptr %slot748, align 8
  %cv4499 = zext i32 %v4498 to i64
  %cond4500 = icmp ne i64 %cv4499, 0
  br i1 %cond4500, label %bb_rcslotrole1085, label %bb_rcslotowner1085
bb_rcslotrole1085:
  %v4501 = load i64, ptr %slot56, align 8
  store i64 %v4501, ptr %slot749, align 8
  %v4502 = load i64, ptr %slot749, align 8
  %v4503 = load i64, ptr %slot746, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4502, i64 %v4503) nomerge, !dbg !174
  br label %bb_rcslotdone1085
bb_rcslotowner1085:
  %v4504 = load i64, ptr %slot56, align 8
  store i64 %v4504, ptr %slot750, align 8
  %v4505 = load i64, ptr %slot750, align 8
  %v4506 = load i64, ptr %slot746, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4505, i64 %v4506) nomerge, !dbg !174
  br label %bb_rcslotdone1085
bb_rcslotdone1085:
  %v4507 = load i64, ptr %slot44, align 8
  %p4508 = inttoptr i64 %v4507 to ptr
  %ld4509 = load i64, ptr %p4508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4509, ptr %slot751, align 8
  %v4510 = load i64, ptr %slot751, align 8
  %op4511 = add i64 %v4510, 0
  store i64 %op4511, ptr %slot752, align 8
  %v4512 = load i64, ptr %slot752, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  %ld4514 = load i64, ptr %p4513, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4514, ptr %slot753, align 8
  %v4515 = load i64, ptr %slot753, align 8
  %v4516 = load i64, ptr %slot44, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  store i64 %v4515, ptr %p4517, align 8, !alias.scope !3, !noalias !4
  %v4518 = load i64, ptr %slot44, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  %ld4520 = load i64, ptr %p4519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4520, ptr %slot754, align 8
  %v4521 = load i64, ptr %slot754, align 8
  %v4522 = load i64, ptr %slot21, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  store i64 %v4521, ptr %p4523, align 8, !alias.scope !3, !noalias !4
  %v4524 = load i64, ptr %slot21, align 8
  store i64 %v4524, ptr %slot755, align 8
  %v4525 = load i64, ptr %slot23, align 8
  store i64 %v4525, ptr %slot756, align 8
  %v4526 = load i64, ptr %slot755, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  %ld4528 = load i64, ptr %p4527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4528, ptr %slot757, align 8
  %v4529 = load i64, ptr %slot757, align 8
  %cmp4530 = icmp ne i64 %v4529, 0
  %cv4531 = zext i1 %cmp4530 to i32
  store i32 %cv4531, ptr %slot758, align 8
  %v4532 = load i32, ptr %slot758, align 8
  %cv4533 = zext i32 %v4532 to i64
  %cond4534 = icmp ne i64 %cv4533, 0
  br i1 %cond4534, label %bb_rcgnn1099, label %bb_rcgstore1099
bb_rcgnn1099:
  %v4535 = load i64, ptr %slot757, align 8
  %op4536 = sub i64 %v4535, 16
  store i64 %op4536, ptr %slot759, align 8
  %v4537 = load i64, ptr %slot757, align 8
  %p4538 = inttoptr i64 %v4537 to ptr
  %rgep4539 = getelementptr i8, ptr %p4538, i64 -16
  %ld4540 = load i64, ptr %rgep4539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4540, ptr %slot760, align 8
  %v4541 = load i64, ptr %slot760, align 8
  %op4542 = and i64 %v4541, 4611686018427387906
  store i64 %op4542, ptr %slot761, align 8
  %v4543 = load i64, ptr %slot761, align 8
  %cmp4544 = icmp ne i64 %v4543, 0
  %cv4545 = zext i1 %cmp4544 to i32
  store i32 %cv4545, ptr %slot762, align 8
  %v4546 = load i32, ptr %slot762, align 8
  %cv4547 = zext i32 %v4546 to i64
  %cond4548 = icmp ne i64 %cv4547, 0
  br i1 %cond4548, label %bb_rcgstore1099, label %bb_rcginc1099
bb_rcginc1099:
  %v4549 = load i64, ptr %slot757, align 8
  %op4550 = sub i64 %v4549, 24
  store i64 %op4550, ptr %slot763, align 8
  %v4551 = load i64, ptr %slot757, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  %rgep4553 = getelementptr i8, ptr %p4552, i64 -24
  %ld4554 = load i64, ptr %rgep4553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4554, ptr %slot764, align 8
  %v4555 = load i64, ptr %slot764, align 8
  %op4556 = add i64 %v4555, 1
  store i64 %op4556, ptr %slot765, align 8
  %v4557 = load i64, ptr %slot765, align 8
  %cmp4558 = icmp eq i64 %v4557, 0
  %cv4559 = zext i1 %cmp4558 to i32
  store i32 %cv4559, ptr %slot766, align 8
  %v4560 = load i32, ptr %slot766, align 8
  %cv4561 = zext i32 %v4560 to i64
  %cond4562 = icmp ne i64 %cv4561, 0
  br i1 %cond4562, label %bb_rcglimit1099, label %bb_rcgcapacity1099
bb_rcglimit1099:
  %v4563 = load i64, ptr %slot1, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  %call4565 = call i32 @myl_qbe_rc_status(ptr %p4564, i32 2) nomerge, !dbg !176
  store i32 %call4565, ptr %slot767, align 8
  br label %bb_failure
bb_rcgcapacity1099:
  %v4566 = load i64, ptr %slot765, align 8
  %v4567 = load i64, ptr %slot757, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %rgep4569 = getelementptr i8, ptr %p4568, i64 -24
  store i64 %v4566, ptr %rgep4569, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1099
bb_rcgstore1099:
  %v4570 = load i64, ptr %slot757, align 8
  %v4571 = load i64, ptr %slot756, align 8
  %p4572 = inttoptr i64 %v4571 to ptr
  store i64 %v4570, ptr %p4572, align 8, !alias.scope !3, !noalias !4
  %v4573 = load i64, ptr %slot17, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  store i32 2, ptr %p4574, align 4, !alias.scope !3, !noalias !4
  %v4575 = load i64, ptr %slot17, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  store i32 16, ptr %p4576, align 4, !alias.scope !3, !noalias !4
  %v4577 = load i64, ptr %slot16, align 8
  %p4578 = inttoptr i64 %v4577 to ptr
  store i32 1, ptr %p4578, align 4, !alias.scope !3, !noalias !4
  %v4579 = load i64, ptr %slot12, align 8
  %p4580 = inttoptr i64 %v4579 to ptr
  %ld4581 = load i32, ptr %p4580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4581, ptr %slot768, align 8
  %v4582 = load i32, ptr %slot768, align 8
  %cv4583 = zext i32 %v4582 to i64
  %cond4584 = icmp ne i64 %cv4583, 0
  br i1 %cond4584, label %bb_rcslotdrop1115, label %bb_rcslotdone1115
bb_rcslotdrop1115:
  %v4585 = load i64, ptr %slot12, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  store i32 0, ptr %p4586, align 4, !alias.scope !3, !noalias !4
  %v4587 = load i64, ptr %slot19, align 8
  store i64 %v4587, ptr %slot769, align 8
  %v4588 = load i64, ptr %slot13, align 8
  %p4589 = inttoptr i64 %v4588 to ptr
  %ld4590 = load i32, ptr %p4589, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4590, ptr %slot770, align 8
  %v4591 = load i32, ptr %slot770, align 8
  %op4592 = and i32 %v4591, 28
  store i32 %op4592, ptr %slot771, align 8
  %v4593 = load i32, ptr %slot771, align 8
  %cv4594 = zext i32 %v4593 to i64
  %cond4595 = icmp ne i64 %cv4594, 0
  br i1 %cond4595, label %bb_rcslotrole1115, label %bb_rcslotowner1115
bb_rcslotrole1115:
  %v4596 = load i64, ptr %slot56, align 8
  store i64 %v4596, ptr %slot772, align 8
  %v4597 = load i64, ptr %slot772, align 8
  %v4598 = load i64, ptr %slot769, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4597, i64 %v4598) nomerge, !dbg !176
  br label %bb_rcslotdone1115
bb_rcslotowner1115:
  %v4599 = load i64, ptr %slot56, align 8
  store i64 %v4599, ptr %slot773, align 8
  %v4600 = load i64, ptr %slot773, align 8
  %v4601 = load i64, ptr %slot769, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4600, i64 %v4601) nomerge, !dbg !176
  br label %bb_rcslotdone1115
bb_rcslotdone1115:
  %v4602 = load i64, ptr %slot19, align 8
  store i64 %v4602, ptr %slot774, align 8
  %v4603 = load i64, ptr %slot23, align 8
  store i64 %v4603, ptr %slot775, align 8
  %v4604 = load i64, ptr %slot775, align 8
  %v4605 = load i64, ptr %slot774, align 8
  %p4606 = inttoptr i64 %v4604 to ptr
  %p4607 = inttoptr i64 %v4605 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4607, ptr %p4606, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4608 = load i64, ptr %slot13, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  store i32 2, ptr %p4609, align 4, !alias.scope !3, !noalias !4
  %v4610 = load i64, ptr %slot17, align 8
  %p4611 = inttoptr i64 %v4610 to ptr
  %ld4612 = load i32, ptr %p4611, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4612, ptr %slot776, align 8
  %v4613 = load i32, ptr %slot776, align 8
  %v4614 = load i64, ptr %slot13, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  store i32 %v4613, ptr %p4615, align 4, !alias.scope !3, !noalias !4
  %v4616 = load i64, ptr %slot16, align 8
  %p4617 = inttoptr i64 %v4616 to ptr
  store i32 0, ptr %p4617, align 4, !alias.scope !3, !noalias !4
  %v4618 = load i64, ptr %slot12, align 8
  %p4619 = inttoptr i64 %v4618 to ptr
  store i32 1, ptr %p4619, align 4, !alias.scope !3, !noalias !4
  %v4620 = load i64, ptr %slot774, align 8
  %p4621 = inttoptr i64 %v4620 to ptr
  %ld4622 = load i64, ptr %p4621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4622, ptr %slot777, align 8
  %v4623 = load i64, ptr %slot777, align 8
  %v4624 = load i64, ptr %slot44, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  store i64 %v4623, ptr %p4625, align 8, !alias.scope !3, !noalias !4
  %v4626 = load i64, ptr %slot44, align 8
  %p4627 = inttoptr i64 %v4626 to ptr
  %ld4628 = load i64, ptr %p4627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4628, ptr %slot778, align 8
  %v4629 = load i64, ptr %slot29, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  %ld4631 = load i64, ptr %p4630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4631, ptr %slot779, align 8
  %v4632 = load i64, ptr %slot12, align 8
  %p4633 = inttoptr i64 %v4632 to ptr
  %ld4634 = load i32, ptr %p4633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4634, ptr %slot780, align 8
  %v4635 = load i32, ptr %slot780, align 8
  %cv4636 = zext i32 %v4635 to i64
  %cond4637 = icmp ne i64 %cv4636, 0
  br i1 %cond4637, label %bb_rcslotdrop1136, label %bb_rcslotdone1136
bb_rcslotdrop1136:
  %v4638 = load i64, ptr %slot12, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  store i32 0, ptr %p4639, align 4, !alias.scope !3, !noalias !4
  %v4640 = load i64, ptr %slot19, align 8
  store i64 %v4640, ptr %slot781, align 8
  %v4641 = load i64, ptr %slot13, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  %ld4643 = load i32, ptr %p4642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4643, ptr %slot782, align 8
  %v4644 = load i32, ptr %slot782, align 8
  %op4645 = and i32 %v4644, 28
  store i32 %op4645, ptr %slot783, align 8
  %v4646 = load i32, ptr %slot783, align 8
  %cv4647 = zext i32 %v4646 to i64
  %cond4648 = icmp ne i64 %cv4647, 0
  br i1 %cond4648, label %bb_rcslotrole1136, label %bb_rcslotowner1136
bb_rcslotrole1136:
  %v4649 = load i64, ptr %slot56, align 8
  store i64 %v4649, ptr %slot784, align 8
  %v4650 = load i64, ptr %slot781, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %ld4652 = load i64, ptr %p4651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4652, ptr %slot785, align 8
  %v4653 = load i64, ptr %slot785, align 8
  %cmp4654 = icmp ne i64 %v4653, 0
  %cv4655 = zext i1 %cmp4654 to i32
  store i32 %cv4655, ptr %slot786, align 8
  %v4656 = load i32, ptr %slot786, align 8
  %cv4657 = zext i32 %v4656 to i64
  %cond4658 = icmp ne i64 %cv4657, 0
  br i1 %cond4658, label %bb_rcgnn1152, label %bb_rcgdone1152
bb_rcgnn1152:
  %v4659 = load i64, ptr %slot785, align 8
  %op4660 = sub i64 %v4659, 16
  store i64 %op4660, ptr %slot787, align 8
  %v4661 = load i64, ptr %slot785, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %rgep4663 = getelementptr i8, ptr %p4662, i64 -16
  %ld4664 = load i64, ptr %rgep4663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4664, ptr %slot788, align 8
  %v4665 = load i64, ptr %slot788, align 8
  %op4666 = and i64 %v4665, 4611686018427387906
  store i64 %op4666, ptr %slot789, align 8
  %v4667 = load i64, ptr %slot789, align 8
  %cmp4668 = icmp ne i64 %v4667, 0
  %cv4669 = zext i1 %cmp4668 to i32
  store i32 %cv4669, ptr %slot790, align 8
  %v4670 = load i32, ptr %slot790, align 8
  %cv4671 = zext i32 %v4670 to i64
  %cond4672 = icmp ne i64 %cv4671, 0
  br i1 %cond4672, label %bb_rcgclear1152, label %bb_rcgcounted1152
bb_rcgcounted1152:
  %v4673 = load i64, ptr %slot785, align 8
  %op4674 = sub i64 %v4673, 24
  store i64 %op4674, ptr %slot791, align 8
  %v4675 = load i64, ptr %slot785, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  %rgep4677 = getelementptr i8, ptr %p4676, i64 -24
  %ld4678 = load i64, ptr %rgep4677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4678, ptr %slot792, align 8
  %v4679 = load i64, ptr %slot792, align 8
  %op4680 = sub i64 %v4679, 1
  store i64 %op4680, ptr %slot793, align 8
  %v4681 = load i64, ptr %slot793, align 8
  %cmp4682 = icmp eq i64 %v4681, 0
  %cv4683 = zext i1 %cmp4682 to i32
  store i32 %cv4683, ptr %slot794, align 8
  %v4684 = load i32, ptr %slot794, align 8
  %cv4685 = zext i32 %v4684 to i64
  %cond4686 = icmp ne i64 %cv4685, 0
  br i1 %cond4686, label %bb_rcglast1152, label %bb_rcgdec1152
bb_rcglast1152:
  %v4687 = load i64, ptr %slot785, align 8
  %op4688 = sub i64 %v4687, 32
  store i64 %op4688, ptr %slot795, align 8
  %v4689 = load i64, ptr %slot785, align 8
  %p4690 = inttoptr i64 %v4689 to ptr
  %rgep4691 = getelementptr i8, ptr %p4690, i64 -32
  %ld4692 = load i64, ptr %rgep4691, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4692, ptr %slot796, align 8
  %v4693 = load i64, ptr %slot796, align 8
  %cmp4694 = icmp ne i64 %v4693, 0
  %cv4695 = zext i1 %cmp4694 to i32
  store i32 %cv4695, ptr %slot797, align 8
  %v4696 = load i32, ptr %slot797, align 8
  %cv4697 = zext i32 %v4696 to i64
  %cond4698 = icmp ne i64 %cv4697, 0
  br i1 %cond4698, label %bb_rcgdec1152, label %bb_rcgslow1152
bb_rcgslow1152:
  %v4699 = load i64, ptr %slot784, align 8
  %v4700 = load i64, ptr %slot781, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4699, i64 %v4700) nomerge, !dbg !178
  br label %bb_rcgdone1152
bb_rcgdec1152:
  %v4701 = load i64, ptr %slot793, align 8
  %v4702 = load i64, ptr %slot785, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  %rgep4704 = getelementptr i8, ptr %p4703, i64 -24
  store i64 %v4701, ptr %rgep4704, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1152
bb_rcgclear1152:
  %v4705 = load i64, ptr %slot781, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  store i64 0, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1152
bb_rcgdone1152:
  br label %bb_rcslotdone1136
bb_rcslotowner1136:
  %v4707 = load i64, ptr %slot56, align 8
  store i64 %v4707, ptr %slot798, align 8
  %v4708 = load i64, ptr %slot781, align 8
  %p4709 = inttoptr i64 %v4708 to ptr
  %ld4710 = load i64, ptr %p4709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4710, ptr %slot799, align 8
  %v4711 = load i64, ptr %slot799, align 8
  %cmp4712 = icmp ne i64 %v4711, 0
  %cv4713 = zext i1 %cmp4712 to i32
  store i32 %cv4713, ptr %slot800, align 8
  %v4714 = load i32, ptr %slot800, align 8
  %cv4715 = zext i32 %v4714 to i64
  %cond4716 = icmp ne i64 %cv4715, 0
  br i1 %cond4716, label %bb_rcgnn1167, label %bb_rcgdone1167
bb_rcgnn1167:
  %v4717 = load i64, ptr %slot799, align 8
  %op4718 = sub i64 %v4717, 16
  store i64 %op4718, ptr %slot801, align 8
  %v4719 = load i64, ptr %slot799, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %rgep4721 = getelementptr i8, ptr %p4720, i64 -16
  %ld4722 = load i64, ptr %rgep4721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4722, ptr %slot802, align 8
  %v4723 = load i64, ptr %slot802, align 8
  %op4724 = and i64 %v4723, 4611686018427387906
  store i64 %op4724, ptr %slot803, align 8
  %v4725 = load i64, ptr %slot803, align 8
  %cmp4726 = icmp ne i64 %v4725, 0
  %cv4727 = zext i1 %cmp4726 to i32
  store i32 %cv4727, ptr %slot804, align 8
  %v4728 = load i32, ptr %slot804, align 8
  %cv4729 = zext i32 %v4728 to i64
  %cond4730 = icmp ne i64 %cv4729, 0
  br i1 %cond4730, label %bb_rcgclear1167, label %bb_rcgcounted1167
bb_rcgcounted1167:
  %v4731 = load i64, ptr %slot799, align 8
  %op4732 = sub i64 %v4731, 32
  store i64 %op4732, ptr %slot805, align 8
  %v4733 = load i64, ptr %slot799, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  %rgep4735 = getelementptr i8, ptr %p4734, i64 -32
  %ld4736 = load i64, ptr %rgep4735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4736, ptr %slot806, align 8
  %v4737 = load i64, ptr %slot806, align 8
  %op4738 = sub i64 %v4737, 1
  store i64 %op4738, ptr %slot807, align 8
  %v4739 = load i64, ptr %slot807, align 8
  %cmp4740 = icmp eq i64 %v4739, 0
  %cv4741 = zext i1 %cmp4740 to i32
  store i32 %cv4741, ptr %slot808, align 8
  %v4742 = load i32, ptr %slot808, align 8
  %cv4743 = zext i32 %v4742 to i64
  %cond4744 = icmp ne i64 %cv4743, 0
  br i1 %cond4744, label %bb_rcglast1167, label %bb_rcgdec1167
bb_rcglast1167:
  %v4745 = load i64, ptr %slot799, align 8
  %op4746 = sub i64 %v4745, 24
  store i64 %op4746, ptr %slot809, align 8
  %v4747 = load i64, ptr %slot799, align 8
  %p4748 = inttoptr i64 %v4747 to ptr
  %rgep4749 = getelementptr i8, ptr %p4748, i64 -24
  %ld4750 = load i64, ptr %rgep4749, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4750, ptr %slot810, align 8
  %v4751 = load i64, ptr %slot810, align 8
  %cmp4752 = icmp ne i64 %v4751, 0
  %cv4753 = zext i1 %cmp4752 to i32
  store i32 %cv4753, ptr %slot811, align 8
  %v4754 = load i32, ptr %slot811, align 8
  %cv4755 = zext i32 %v4754 to i64
  %cond4756 = icmp ne i64 %cv4755, 0
  br i1 %cond4756, label %bb_rcgdec1167, label %bb_rcgslow1167
bb_rcgslow1167:
  %v4757 = load i64, ptr %slot798, align 8
  %v4758 = load i64, ptr %slot781, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4757, i64 %v4758) nomerge, !dbg !178
  br label %bb_rcgdone1167
bb_rcgdec1167:
  %v4759 = load i64, ptr %slot807, align 8
  %v4760 = load i64, ptr %slot799, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %rgep4762 = getelementptr i8, ptr %p4761, i64 -32
  store i64 %v4759, ptr %rgep4762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1167
bb_rcgclear1167:
  %v4763 = load i64, ptr %slot781, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  store i64 0, ptr %p4764, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1167
bb_rcgdone1167:
  br label %bb_rcslotdone1136
bb_rcslotdone1136:
  %v4765 = load i64, ptr %slot779, align 8
  %op4766 = add i64 %v4765, 0
  store i64 %op4766, ptr %slot812, align 8
  %v4767 = load i64, ptr %slot812, align 8
  %op4768 = add i64 %v4767, 0
  store i64 %op4768, ptr %slot813, align 8
  store i64 0, ptr %slot814, align 8
  %v4769 = load i64, ptr %slot813, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  %ld4771 = load i64, ptr %p4770, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4771, ptr %slot815, align 8
  %v4772 = load i64, ptr %slot815, align 8
  %cmp4773 = icmp ne i64 %v4772, 0
  %cv4774 = zext i1 %cmp4773 to i32
  store i32 %cv4774, ptr %slot816, align 8
  %v4775 = load i32, ptr %slot816, align 8
  %cv4776 = zext i32 %v4775 to i64
  %cond4777 = icmp ne i64 %cv4776, 0
  br i1 %cond4777, label %bb_rcguniquenn1174, label %bb_rcgunique1174
bb_rcguniquenn1174:
  %v4778 = load i64, ptr %slot815, align 8
  %op4779 = sub i64 %v4778, 16
  store i64 %op4779, ptr %slot817, align 8
  %v4780 = load i64, ptr %slot815, align 8
  %p4781 = inttoptr i64 %v4780 to ptr
  %rgep4782 = getelementptr i8, ptr %p4781, i64 -16
  %ld4783 = load i64, ptr %rgep4782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4783, ptr %slot818, align 8
  %v4784 = load i64, ptr %slot818, align 8
  %op4785 = and i64 %v4784, 6917529027641081858
  store i64 %op4785, ptr %slot819, align 8
  %v4786 = load i64, ptr %slot819, align 8
  %cmp4787 = icmp ne i64 %v4786, 0
  %cv4788 = zext i1 %cmp4787 to i32
  store i32 %cv4788, ptr %slot820, align 8
  %v4789 = load i32, ptr %slot820, align 8
  %cv4790 = zext i32 %v4789 to i64
  %cond4791 = icmp ne i64 %cv4790, 0
  br i1 %cond4791, label %bb_rcguniqueslow1174, label %bb_rcguniquecount1174
bb_rcguniquecount1174:
  %v4792 = load i64, ptr %slot815, align 8
  %op4793 = sub i64 %v4792, 32
  store i64 %op4793, ptr %slot821, align 8
  %v4794 = load i64, ptr %slot815, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %rgep4796 = getelementptr i8, ptr %p4795, i64 -32
  %ld4797 = load i64, ptr %rgep4796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4797, ptr %slot822, align 8
  %v4798 = load i64, ptr %slot822, align 8
  %cmp4799 = icmp ult i64 %v4798, 2
  %cv4800 = zext i1 %cmp4799 to i32
  store i32 %cv4800, ptr %slot823, align 8
  %v4801 = load i32, ptr %slot823, align 8
  %cv4802 = zext i32 %v4801 to i64
  %cond4803 = icmp ne i64 %cv4802, 0
  br i1 %cond4803, label %bb_rcgunique1174, label %bb_rcguniqueslow1174
bb_rcguniqueslow1174:
  %v4804 = load i64, ptr %slot1, align 8
  %p4805 = inttoptr i64 %v4804 to ptr
  %p4806 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v4807 = load i64, ptr %slot813, align 8
  %p4808 = inttoptr i64 %v4807 to ptr
  %v4809 = load i64, ptr %slot814, align 8
  %p4810 = inttoptr i64 %v4809 to ptr
  %call4811 = call i32 @myl_qbe_rc_unique_field(ptr %p4805, ptr %p4806, ptr %p4808, ptr %p4810) nomerge, !dbg !178
  store i32 %call4811, ptr %slot824, align 8
  %v4812 = load i32, ptr %slot824, align 8
  %cv4813 = zext i32 %v4812 to i64
  %cond4814 = icmp ne i64 %cv4813, 0
  br i1 %cond4814, label %bb_rcunique1184, label %bb_failure
bb_rcunique1184:
  br label %bb_rcgunique1174
bb_rcgunique1174:
  %v4815 = load i64, ptr %slot813, align 8
  %p4816 = inttoptr i64 %v4815 to ptr
  %ld4817 = load i64, ptr %p4816, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4817, ptr %slot825, align 8
  %v4818 = load i64, ptr %slot825, align 8
  %v4819 = load i64, ptr %slot44, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  store i64 %v4818, ptr %p4820, align 8, !alias.scope !3, !noalias !4
  %v4821 = load i64, ptr %slot44, align 8
  %p4822 = inttoptr i64 %v4821 to ptr
  %ld4823 = load i64, ptr %p4822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4823, ptr %slot826, align 8
  %v4824 = load i64, ptr %slot12, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %ld4826 = load i32, ptr %p4825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4826, ptr %slot827, align 8
  %v4827 = load i32, ptr %slot827, align 8
  %cv4828 = zext i32 %v4827 to i64
  %cond4829 = icmp ne i64 %cv4828, 0
  br i1 %cond4829, label %bb_rcslotdrop1189, label %bb_rcslotdone1189
bb_rcslotdrop1189:
  %v4830 = load i64, ptr %slot12, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  store i32 0, ptr %p4831, align 4, !alias.scope !3, !noalias !4
  %v4832 = load i64, ptr %slot19, align 8
  store i64 %v4832, ptr %slot828, align 8
  %v4833 = load i64, ptr %slot13, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  %ld4835 = load i32, ptr %p4834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4835, ptr %slot829, align 8
  %v4836 = load i32, ptr %slot829, align 8
  %op4837 = and i32 %v4836, 28
  store i32 %op4837, ptr %slot830, align 8
  %v4838 = load i32, ptr %slot830, align 8
  %cv4839 = zext i32 %v4838 to i64
  %cond4840 = icmp ne i64 %cv4839, 0
  br i1 %cond4840, label %bb_rcslotrole1189, label %bb_rcslotowner1189
bb_rcslotrole1189:
  %v4841 = load i64, ptr %slot56, align 8
  store i64 %v4841, ptr %slot831, align 8
  %v4842 = load i64, ptr %slot828, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  %ld4844 = load i64, ptr %p4843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4844, ptr %slot832, align 8
  %v4845 = load i64, ptr %slot832, align 8
  %cmp4846 = icmp ne i64 %v4845, 0
  %cv4847 = zext i1 %cmp4846 to i32
  store i32 %cv4847, ptr %slot833, align 8
  %v4848 = load i32, ptr %slot833, align 8
  %cv4849 = zext i32 %v4848 to i64
  %cond4850 = icmp ne i64 %cv4849, 0
  br i1 %cond4850, label %bb_rcgnn1205, label %bb_rcgdone1205
bb_rcgnn1205:
  %v4851 = load i64, ptr %slot832, align 8
  %op4852 = sub i64 %v4851, 16
  store i64 %op4852, ptr %slot834, align 8
  %v4853 = load i64, ptr %slot832, align 8
  %p4854 = inttoptr i64 %v4853 to ptr
  %rgep4855 = getelementptr i8, ptr %p4854, i64 -16
  %ld4856 = load i64, ptr %rgep4855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4856, ptr %slot835, align 8
  %v4857 = load i64, ptr %slot835, align 8
  %op4858 = and i64 %v4857, 4611686018427387906
  store i64 %op4858, ptr %slot836, align 8
  %v4859 = load i64, ptr %slot836, align 8
  %cmp4860 = icmp ne i64 %v4859, 0
  %cv4861 = zext i1 %cmp4860 to i32
  store i32 %cv4861, ptr %slot837, align 8
  %v4862 = load i32, ptr %slot837, align 8
  %cv4863 = zext i32 %v4862 to i64
  %cond4864 = icmp ne i64 %cv4863, 0
  br i1 %cond4864, label %bb_rcgclear1205, label %bb_rcgcounted1205
bb_rcgcounted1205:
  %v4865 = load i64, ptr %slot832, align 8
  %op4866 = sub i64 %v4865, 24
  store i64 %op4866, ptr %slot838, align 8
  %v4867 = load i64, ptr %slot832, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  %rgep4869 = getelementptr i8, ptr %p4868, i64 -24
  %ld4870 = load i64, ptr %rgep4869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4870, ptr %slot839, align 8
  %v4871 = load i64, ptr %slot839, align 8
  %op4872 = sub i64 %v4871, 1
  store i64 %op4872, ptr %slot840, align 8
  %v4873 = load i64, ptr %slot840, align 8
  %cmp4874 = icmp eq i64 %v4873, 0
  %cv4875 = zext i1 %cmp4874 to i32
  store i32 %cv4875, ptr %slot841, align 8
  %v4876 = load i32, ptr %slot841, align 8
  %cv4877 = zext i32 %v4876 to i64
  %cond4878 = icmp ne i64 %cv4877, 0
  br i1 %cond4878, label %bb_rcglast1205, label %bb_rcgdec1205
bb_rcglast1205:
  %v4879 = load i64, ptr %slot832, align 8
  %op4880 = sub i64 %v4879, 32
  store i64 %op4880, ptr %slot842, align 8
  %v4881 = load i64, ptr %slot832, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  %rgep4883 = getelementptr i8, ptr %p4882, i64 -32
  %ld4884 = load i64, ptr %rgep4883, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4884, ptr %slot843, align 8
  %v4885 = load i64, ptr %slot843, align 8
  %cmp4886 = icmp ne i64 %v4885, 0
  %cv4887 = zext i1 %cmp4886 to i32
  store i32 %cv4887, ptr %slot844, align 8
  %v4888 = load i32, ptr %slot844, align 8
  %cv4889 = zext i32 %v4888 to i64
  %cond4890 = icmp ne i64 %cv4889, 0
  br i1 %cond4890, label %bb_rcgdec1205, label %bb_rcgslow1205
bb_rcgslow1205:
  %v4891 = load i64, ptr %slot831, align 8
  %v4892 = load i64, ptr %slot828, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v4891, i64 %v4892) nomerge, !dbg !178
  br label %bb_rcgdone1205
bb_rcgdec1205:
  %v4893 = load i64, ptr %slot840, align 8
  %v4894 = load i64, ptr %slot832, align 8
  %p4895 = inttoptr i64 %v4894 to ptr
  %rgep4896 = getelementptr i8, ptr %p4895, i64 -24
  store i64 %v4893, ptr %rgep4896, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1205
bb_rcgclear1205:
  %v4897 = load i64, ptr %slot828, align 8
  %p4898 = inttoptr i64 %v4897 to ptr
  store i64 0, ptr %p4898, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1205
bb_rcgdone1205:
  br label %bb_rcslotdone1189
bb_rcslotowner1189:
  %v4899 = load i64, ptr %slot56, align 8
  store i64 %v4899, ptr %slot845, align 8
  %v4900 = load i64, ptr %slot828, align 8
  %p4901 = inttoptr i64 %v4900 to ptr
  %ld4902 = load i64, ptr %p4901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4902, ptr %slot846, align 8
  %v4903 = load i64, ptr %slot846, align 8
  %cmp4904 = icmp ne i64 %v4903, 0
  %cv4905 = zext i1 %cmp4904 to i32
  store i32 %cv4905, ptr %slot847, align 8
  %v4906 = load i32, ptr %slot847, align 8
  %cv4907 = zext i32 %v4906 to i64
  %cond4908 = icmp ne i64 %cv4907, 0
  br i1 %cond4908, label %bb_rcgnn1220, label %bb_rcgdone1220
bb_rcgnn1220:
  %v4909 = load i64, ptr %slot846, align 8
  %op4910 = sub i64 %v4909, 16
  store i64 %op4910, ptr %slot848, align 8
  %v4911 = load i64, ptr %slot846, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  %rgep4913 = getelementptr i8, ptr %p4912, i64 -16
  %ld4914 = load i64, ptr %rgep4913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4914, ptr %slot849, align 8
  %v4915 = load i64, ptr %slot849, align 8
  %op4916 = and i64 %v4915, 4611686018427387906
  store i64 %op4916, ptr %slot850, align 8
  %v4917 = load i64, ptr %slot850, align 8
  %cmp4918 = icmp ne i64 %v4917, 0
  %cv4919 = zext i1 %cmp4918 to i32
  store i32 %cv4919, ptr %slot851, align 8
  %v4920 = load i32, ptr %slot851, align 8
  %cv4921 = zext i32 %v4920 to i64
  %cond4922 = icmp ne i64 %cv4921, 0
  br i1 %cond4922, label %bb_rcgclear1220, label %bb_rcgcounted1220
bb_rcgcounted1220:
  %v4923 = load i64, ptr %slot846, align 8
  %op4924 = sub i64 %v4923, 32
  store i64 %op4924, ptr %slot852, align 8
  %v4925 = load i64, ptr %slot846, align 8
  %p4926 = inttoptr i64 %v4925 to ptr
  %rgep4927 = getelementptr i8, ptr %p4926, i64 -32
  %ld4928 = load i64, ptr %rgep4927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4928, ptr %slot853, align 8
  %v4929 = load i64, ptr %slot853, align 8
  %op4930 = sub i64 %v4929, 1
  store i64 %op4930, ptr %slot854, align 8
  %v4931 = load i64, ptr %slot854, align 8
  %cmp4932 = icmp eq i64 %v4931, 0
  %cv4933 = zext i1 %cmp4932 to i32
  store i32 %cv4933, ptr %slot855, align 8
  %v4934 = load i32, ptr %slot855, align 8
  %cv4935 = zext i32 %v4934 to i64
  %cond4936 = icmp ne i64 %cv4935, 0
  br i1 %cond4936, label %bb_rcglast1220, label %bb_rcgdec1220
bb_rcglast1220:
  %v4937 = load i64, ptr %slot846, align 8
  %op4938 = sub i64 %v4937, 24
  store i64 %op4938, ptr %slot856, align 8
  %v4939 = load i64, ptr %slot846, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %rgep4941 = getelementptr i8, ptr %p4940, i64 -24
  %ld4942 = load i64, ptr %rgep4941, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4942, ptr %slot857, align 8
  %v4943 = load i64, ptr %slot857, align 8
  %cmp4944 = icmp ne i64 %v4943, 0
  %cv4945 = zext i1 %cmp4944 to i32
  store i32 %cv4945, ptr %slot858, align 8
  %v4946 = load i32, ptr %slot858, align 8
  %cv4947 = zext i32 %v4946 to i64
  %cond4948 = icmp ne i64 %cv4947, 0
  br i1 %cond4948, label %bb_rcgdec1220, label %bb_rcgslow1220
bb_rcgslow1220:
  %v4949 = load i64, ptr %slot845, align 8
  %v4950 = load i64, ptr %slot828, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v4949, i64 %v4950) nomerge, !dbg !178
  br label %bb_rcgdone1220
bb_rcgdec1220:
  %v4951 = load i64, ptr %slot854, align 8
  %v4952 = load i64, ptr %slot846, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %rgep4954 = getelementptr i8, ptr %p4953, i64 -32
  store i64 %v4951, ptr %rgep4954, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1220
bb_rcgclear1220:
  %v4955 = load i64, ptr %slot828, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  store i64 0, ptr %p4956, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1220
bb_rcgdone1220:
  br label %bb_rcslotdone1189
bb_rcslotdone1189:
  %v4957 = load i64, ptr %slot26, align 8
  store i64 %v4957, ptr %slot859, align 8
  %v4958 = load i64, ptr %slot56, align 8
  %v4959 = load i64, ptr %slot859, align 8
  %p4960 = inttoptr i64 %v4959 to ptr
  store i64 %v4958, ptr %p4960, align 8, !alias.scope !3, !noalias !4
  %v4961 = load i64, ptr %slot56, align 8
  %p4963 = inttoptr i64 %v4961 to ptr
  %gep4964 = getelementptr i8, ptr %p4963, i64 5640
  %op4962 = ptrtoint ptr %gep4964 to i64
  store i64 %op4962, ptr %slot860, align 8
  %v4965 = load i64, ptr %slot860, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  %ld4967 = load i64, ptr %p4966, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4967, ptr %slot861, align 8
  %v4968 = load i64, ptr %slot861, align 8
  %op4969 = add i64 %v4968, 248
  store i64 %op4969, ptr %slot862, align 8
  %v4970 = load i64, ptr %slot862, align 8
  %p4971 = inttoptr i64 %v4970 to ptr
  %ld4972 = load i64, ptr %p4971, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4972, ptr %slot863, align 8
  %v4973 = load i64, ptr %slot859, align 8
  %p4975 = inttoptr i64 %v4973 to ptr
  %gep4976 = getelementptr i8, ptr %p4975, i64 8
  %op4974 = ptrtoint ptr %gep4976 to i64
  store i64 %op4974, ptr %slot864, align 8
  %v4977 = load i64, ptr %slot863, align 8
  %v4978 = load i64, ptr %slot864, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  store i64 %v4977, ptr %p4979, align 8, !alias.scope !3, !noalias !4
  %v4980 = load i64, ptr %slot859, align 8
  %p4982 = inttoptr i64 %v4980 to ptr
  %gep4983 = getelementptr i8, ptr %p4982, i64 16
  %op4981 = ptrtoint ptr %gep4983 to i64
  store i64 %op4981, ptr %slot865, align 8
  %v4984 = load i64, ptr %slot865, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  store i64 0, ptr %p4985, align 8, !alias.scope !3, !noalias !4
  %v4986 = load i64, ptr %slot56, align 8
  %p4988 = inttoptr i64 %v4986 to ptr
  %gep4989 = getelementptr i8, ptr %p4988, i64 112
  %op4987 = ptrtoint ptr %gep4989 to i64
  store i64 %op4987, ptr %slot866, align 8
  %v4990 = load i64, ptr %slot859, align 8
  %p4992 = inttoptr i64 %v4990 to ptr
  %gep4993 = getelementptr i8, ptr %p4992, i64 24
  %op4991 = ptrtoint ptr %gep4993 to i64
  store i64 %op4991, ptr %slot867, align 8
  %v4994 = load i64, ptr %slot859, align 8
  %p4996 = inttoptr i64 %v4994 to ptr
  %gep4997 = getelementptr i8, ptr %p4996, i64 28
  %op4995 = ptrtoint ptr %gep4997 to i64
  store i64 %op4995, ptr %slot868, align 8
  %v4998 = load i64, ptr %slot866, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  %ld5000 = load i32, ptr %p4999, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld5000, ptr %slot869, align 8
  %v5001 = load i64, ptr %slot867, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  store i32 1, ptr %p5002, align 4, !alias.scope !3, !noalias !4
  %v5003 = load i32, ptr %slot869, align 8
  %v5004 = load i64, ptr %slot868, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  store i32 %v5003, ptr %p5005, align 4, !alias.scope !3, !noalias !4
  %v5006 = load i64, ptr %slot859, align 8
  %v5007 = load i64, ptr %slot862, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  store i64 %v5006, ptr %p5008, align 8, !alias.scope !9999998, !noalias !9999999
  %v5009 = load i64, ptr %slot826, align 8
  %cmp5010 = icmp ne i64 %v5009, 0
  %cv5011 = zext i1 %cmp5010 to i32
  store i32 %cv5011, ptr %slot870, align 8
  %v5012 = load i32, ptr %slot870, align 8
  %cv5013 = zext i32 %v5012 to i64
  %cond5014 = icmp ne i64 %cv5013, 0
  br i1 %cond5014, label %bb_rcspinmark1272, label %bb_rcspindone1272
bb_rcspinmark1272:
  %v5015 = load i64, ptr %slot826, align 8
  %op5016 = sub i64 %v5015, 16
  store i64 %op5016, ptr %slot871, align 8
  %v5017 = load i64, ptr %slot826, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  %rgep5019 = getelementptr i8, ptr %p5018, i64 -16
  %ld5020 = load i64, ptr %rgep5019, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5020, ptr %slot872, align 8
  %v5021 = load i64, ptr %slot872, align 8
  %op5022 = and i64 %v5021, 2
  store i64 %op5022, ptr %slot873, align 8
  %v5023 = load i64, ptr %slot873, align 8
  %cmp5024 = icmp ne i64 %v5023, 0
  %cv5025 = zext i1 %cmp5024 to i32
  store i32 %cv5025, ptr %slot874, align 8
  %v5026 = load i32, ptr %slot874, align 8
  %cv5027 = zext i32 %v5026 to i64
  %cond5028 = icmp ne i64 %cv5027, 0
  br i1 %cond5028, label %bb_rcspindone1272, label %bb_rcspintype1272
bb_rcspintype1272:
  %v5029 = load i64, ptr %slot872, align 8
  %op5030 = and i64 %v5029, 4611686018427387907
  store i64 %op5030, ptr %slot875, align 8
  %v5031 = load i64, ptr %slot875, align 8
  %cmp5032 = icmp eq i64 %v5031, 0
  %cv5033 = zext i1 %cmp5032 to i32
  store i32 %cv5033, ptr %slot876, align 8
  %v5034 = load i32, ptr %slot876, align 8
  %cv5035 = zext i32 %v5034 to i64
  %cond5036 = icmp ne i64 %cv5035, 0
  br i1 %cond5036, label %bb_rcs1280, label %bb_rcspinslow1272
bb_rcs1280:
  %v5037 = load i64, ptr %slot826, align 8
  %op5038 = sub i64 %v5037, 8
  store i64 %op5038, ptr %slot877, align 8
  %v5039 = load i64, ptr %slot826, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  %rgep5041 = getelementptr i8, ptr %p5040, i64 -8
  %ld5042 = load i64, ptr %rgep5041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5042, ptr %slot878, align 8
  %p5043 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld5044 = load i64, ptr %p5043, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5044, ptr %slot879, align 8
  %v5045 = load i64, ptr %slot878, align 8
  %v5046 = load i64, ptr %slot879, align 8
  %cmp5047 = icmp eq i64 %v5045, %v5046
  %cv5048 = zext i1 %cmp5047 to i32
  store i32 %cv5048, ptr %slot880, align 8
  %v5049 = load i32, ptr %slot880, align 8
  %cv5050 = zext i32 %v5049 to i64
  %cond5051 = icmp ne i64 %cv5050, 0
  br i1 %cond5051, label %bb_rcs1285, label %bb_rcspinslow1272
bb_rcs1285:
  %v5052 = load i64, ptr %slot56, align 8
  %p5054 = inttoptr i64 %v5052 to ptr
  %gep5055 = getelementptr i8, ptr %p5054, i64 5640
  %op5053 = ptrtoint ptr %gep5055 to i64
  store i64 %op5053, ptr %slot881, align 8
  %v5056 = load i64, ptr %slot881, align 8
  %p5057 = inttoptr i64 %v5056 to ptr
  %ld5058 = load i64, ptr %p5057, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5058, ptr %slot882, align 8
  %v5059 = load i64, ptr %slot882, align 8
  %op5060 = add i64 %v5059, 256
  store i64 %op5060, ptr %slot883, align 8
  %v5061 = load i64, ptr %slot883, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %ld5063 = load i64, ptr %p5062, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5063, ptr %slot884, align 8
  %v5064 = load i64, ptr %slot884, align 8
  %cmp5065 = icmp ne i64 %v5064, 0
  %cv5066 = zext i1 %cmp5065 to i32
  store i32 %cv5066, ptr %slot885, align 8
  %v5067 = load i32, ptr %slot885, align 8
  %cv5068 = zext i32 %v5067 to i64
  %cond5069 = icmp ne i64 %cv5068, 0
  br i1 %cond5069, label %bb_rcs1291, label %bb_rcspinslow1272
bb_rcs1291:
  %v5070 = load i64, ptr %slot56, align 8
  %p5072 = inttoptr i64 %v5070 to ptr
  %gep5073 = getelementptr i8, ptr %p5072, i64 24
  %op5071 = ptrtoint ptr %gep5073 to i64
  store i64 %op5071, ptr %slot886, align 8
  %v5074 = load i64, ptr %slot886, align 8
  %p5075 = inttoptr i64 %v5074 to ptr
  %ld5076 = load i64, ptr %p5075, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5076, ptr %slot887, align 8
  %v5077 = load i64, ptr %slot887, align 8
  %op5078 = add i64 %v5077, 40
  store i64 %op5078, ptr %slot888, align 8
  %v5079 = load i64, ptr %slot888, align 8
  %v5080 = load i64, ptr %slot887, align 8
  %cmp5081 = icmp uge i64 %v5079, %v5080
  %cv5082 = zext i1 %cmp5081 to i32
  store i32 %cv5082, ptr %slot889, align 8
  %v5083 = load i32, ptr %slot889, align 8
  %cv5084 = zext i32 %v5083 to i64
  %cond5085 = icmp ne i64 %cv5084, 0
  br i1 %cond5085, label %bb_rcs1296, label %bb_rcspinslow1272
bb_rcs1296:
  %v5086 = load i64, ptr %slot56, align 8
  %p5088 = inttoptr i64 %v5086 to ptr
  %gep5089 = getelementptr i8, ptr %p5088, i64 88
  %op5087 = ptrtoint ptr %gep5089 to i64
  store i64 %op5087, ptr %slot890, align 8
  %v5090 = load i64, ptr %slot890, align 8
  %p5091 = inttoptr i64 %v5090 to ptr
  %ld5092 = load i64, ptr %p5091, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5092, ptr %slot891, align 8
  %v5093 = load i64, ptr %slot891, align 8
  %cmp5094 = icmp eq i64 %v5093, 0
  %cv5095 = zext i1 %cmp5094 to i32
  store i32 %cv5095, ptr %slot892, align 8
  %v5096 = load i64, ptr %slot888, align 8
  %v5097 = load i64, ptr %slot891, align 8
  %cmp5098 = icmp ule i64 %v5096, %v5097
  %cv5099 = zext i1 %cmp5098 to i32
  store i32 %cv5099, ptr %slot893, align 8
  %v5100 = load i32, ptr %slot892, align 8
  %v5101 = load i32, ptr %slot893, align 8
  %op5102 = or i32 %v5100, %v5101
  store i32 %op5102, ptr %slot894, align 8
  %v5103 = load i32, ptr %slot894, align 8
  %cv5104 = zext i32 %v5103 to i64
  %cond5105 = icmp ne i64 %cv5104, 0
  br i1 %cond5105, label %bb_rcs1302, label %bb_rcspinslow1272
bb_rcs1302:
  %v5106 = load i64, ptr %slot826, align 8
  %op5107 = sub i64 %v5106, 24
  store i64 %op5107, ptr %slot895, align 8
  %v5108 = load i64, ptr %slot826, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %rgep5110 = getelementptr i8, ptr %p5109, i64 -24
  %ld5111 = load i64, ptr %rgep5110, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5111, ptr %slot896, align 8
  %v5112 = load i64, ptr %slot896, align 8
  %cmp5113 = icmp ne i64 %v5112, 18446744073709551615
  %cv5114 = zext i1 %cmp5113 to i32
  store i32 %cv5114, ptr %slot897, align 8
  %v5115 = load i32, ptr %slot897, align 8
  %cv5116 = zext i32 %v5115 to i64
  %cond5117 = icmp ne i64 %cv5116, 0
  br i1 %cond5117, label %bb_rcs1306, label %bb_rcspinslow1272
bb_rcs1306:
  %v5118 = load i64, ptr %slot826, align 8
  %op5119 = add i64 %v5118, 32
  store i64 %op5119, ptr %slot898, align 8
  %v5120 = load i64, ptr %slot898, align 8
  %p5121 = inttoptr i64 %v5120 to ptr
  %ld5122 = load i64, ptr %p5121, align 8
  store i64 %ld5122, ptr %slot899, align 8
  %v5123 = load i64, ptr %slot899, align 8
  %cmp5124 = icmp ne i64 %v5123, 0
  %cv5125 = zext i1 %cmp5124 to i32
  store i32 %cv5125, ptr %slot900, align 8
  %v5126 = load i32, ptr %slot900, align 8
  %cv5127 = zext i32 %v5126 to i64
  %cond5128 = icmp ne i64 %cv5127, 0
  br i1 %cond5128, label %bb_rcspinbacking1272, label %bb_rcspincommit1272
bb_rcspinbacking1272:
  %v5129 = load i64, ptr %slot899, align 8
  %op5130 = sub i64 %v5129, 16
  store i64 %op5130, ptr %slot901, align 8
  %v5131 = load i64, ptr %slot899, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  %rgep5133 = getelementptr i8, ptr %p5132, i64 -16
  %ld5134 = load i64, ptr %rgep5133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5134, ptr %slot902, align 8
  %v5135 = load i64, ptr %slot902, align 8
  %op5136 = and i64 %v5135, 4611686018427387907
  store i64 %op5136, ptr %slot903, align 8
  %v5137 = load i64, ptr %slot903, align 8
  %cmp5138 = icmp eq i64 %v5137, 0
  %cv5139 = zext i1 %cmp5138 to i32
  store i32 %cv5139, ptr %slot904, align 8
  %v5140 = load i32, ptr %slot904, align 8
  %cv5141 = zext i32 %v5140 to i64
  %cond5142 = icmp ne i64 %cv5141, 0
  br i1 %cond5142, label %bb_rcs1314, label %bb_rcspinslow1272
bb_rcs1314:
  %v5143 = load i64, ptr %slot899, align 8
  %op5144 = sub i64 %v5143, 24
  store i64 %op5144, ptr %slot905, align 8
  %v5145 = load i64, ptr %slot899, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  %rgep5147 = getelementptr i8, ptr %p5146, i64 -24
  %ld5148 = load i64, ptr %rgep5147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5148, ptr %slot906, align 8
  %v5149 = load i64, ptr %slot906, align 8
  %cmp5150 = icmp ne i64 %v5149, 18446744073709551615
  %cv5151 = zext i1 %cmp5150 to i32
  store i32 %cv5151, ptr %slot907, align 8
  %v5152 = load i32, ptr %slot907, align 8
  %cv5153 = zext i32 %v5152 to i64
  %cond5154 = icmp ne i64 %cv5153, 0
  br i1 %cond5154, label %bb_rcs1318, label %bb_rcspinslow1272
bb_rcs1318:
  br label %bb_rcspincommit1272
bb_rcspincommit1272:
  %v5155 = load i64, ptr %slot884, align 8
  %p5156 = inttoptr i64 %v5155 to ptr
  %ld5157 = load i64, ptr %p5156, align 8
  store i64 %ld5157, ptr %slot908, align 8
  %v5158 = load i64, ptr %slot882, align 8
  %op5159 = add i64 %v5158, 256
  store i64 %op5159, ptr %slot909, align 8
  %v5160 = load i64, ptr %slot908, align 8
  %v5161 = load i64, ptr %slot909, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  store i64 %v5160, ptr %p5162, align 8, !alias.scope !9999998, !noalias !9999999
  %v5163 = load i64, ptr %slot882, align 8
  %op5164 = add i64 %v5163, 264
  store i64 %op5164, ptr %slot910, align 8
  %v5165 = load i64, ptr %slot910, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  %ld5167 = load i64, ptr %p5166, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5167, ptr %slot911, align 8
  %v5168 = load i64, ptr %slot911, align 8
  %op5169 = add i64 %v5168, 18446744073709551615
  store i64 %op5169, ptr %slot912, align 8
  %v5170 = load i64, ptr %slot912, align 8
  %v5171 = load i64, ptr %slot910, align 8
  %p5172 = inttoptr i64 %v5171 to ptr
  store i64 %v5170, ptr %p5172, align 8, !alias.scope !9999998, !noalias !9999999
  %v5173 = load i64, ptr %slot56, align 8
  %p5175 = inttoptr i64 %v5173 to ptr
  %gep5176 = getelementptr i8, ptr %p5175, i64 24
  %op5174 = ptrtoint ptr %gep5176 to i64
  store i64 %op5174, ptr %slot913, align 8
  %v5177 = load i64, ptr %slot913, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  %ld5179 = load i64, ptr %p5178, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5179, ptr %slot914, align 8
  %v5180 = load i64, ptr %slot914, align 8
  %op5181 = add i64 %v5180, 40
  store i64 %op5181, ptr %slot915, align 8
  %v5182 = load i64, ptr %slot915, align 8
  %v5183 = load i64, ptr %slot913, align 8
  %p5184 = inttoptr i64 %v5183 to ptr
  store i64 %v5182, ptr %p5184, align 8, !alias.scope !9999998, !noalias !9999999
  %v5185 = load i64, ptr %slot882, align 8
  %op5186 = add i64 %v5185, 48
  store i64 %op5186, ptr %slot916, align 8
  %v5187 = load i64, ptr %slot916, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  %ld5189 = load i64, ptr %p5188, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5189, ptr %slot917, align 8
  %v5190 = load i64, ptr %slot917, align 8
  %op5191 = add i64 %v5190, 40
  store i64 %op5191, ptr %slot918, align 8
  %v5192 = load i64, ptr %slot918, align 8
  %v5193 = load i64, ptr %slot916, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  store i64 %v5192, ptr %p5194, align 8, !alias.scope !9999998, !noalias !9999999
  %v5195 = load i64, ptr %slot826, align 8
  %op5196 = sub i64 %v5195, 24
  store i64 %op5196, ptr %slot919, align 8
  %v5197 = load i64, ptr %slot826, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  %rgep5199 = getelementptr i8, ptr %p5198, i64 -24
  %ld5200 = load i64, ptr %rgep5199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5200, ptr %slot920, align 8
  %v5201 = load i64, ptr %slot920, align 8
  %op5202 = add i64 %v5201, 1
  store i64 %op5202, ptr %slot921, align 8
  %v5203 = load i64, ptr %slot921, align 8
  %v5204 = load i64, ptr %slot826, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  %rgep5206 = getelementptr i8, ptr %p5205, i64 -24
  store i64 %v5203, ptr %rgep5206, align 8, !alias.scope !9, !noalias !10
  %v5207 = load i64, ptr %slot899, align 8
  %cmp5208 = icmp ne i64 %v5207, 0
  %cv5209 = zext i1 %cmp5208 to i32
  store i32 %cv5209, ptr %slot922, align 8
  %v5210 = load i32, ptr %slot922, align 8
  %cv5211 = zext i32 %v5210 to i64
  %cond5212 = icmp ne i64 %cv5211, 0
  br i1 %cond5212, label %bb_rcspinhold1272, label %bb_rcspinjournal1272
bb_rcspinhold1272:
  %v5213 = load i64, ptr %slot899, align 8
  %op5214 = sub i64 %v5213, 24
  store i64 %op5214, ptr %slot923, align 8
  %v5215 = load i64, ptr %slot899, align 8
  %p5216 = inttoptr i64 %v5215 to ptr
  %rgep5217 = getelementptr i8, ptr %p5216, i64 -24
  %ld5218 = load i64, ptr %rgep5217, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5218, ptr %slot924, align 8
  %v5219 = load i64, ptr %slot924, align 8
  %op5220 = add i64 %v5219, 1
  store i64 %op5220, ptr %slot925, align 8
  %v5221 = load i64, ptr %slot925, align 8
  %v5222 = load i64, ptr %slot899, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  %rgep5224 = getelementptr i8, ptr %p5223, i64 -24
  store i64 %v5221, ptr %rgep5224, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal1272
bb_rcspinjournal1272:
  %v5225 = load i64, ptr %slot872, align 8
  %op5226 = and i64 %v5225, 1152921504606846976
  store i64 %op5226, ptr %slot926, align 8
  %v5227 = load i64, ptr %slot872, align 8
  %op5228 = or i64 %v5227, 1152921504606846976
  store i64 %op5228, ptr %slot927, align 8
  %v5229 = load i64, ptr %slot826, align 8
  %op5230 = sub i64 %v5229, 16
  store i64 %op5230, ptr %slot928, align 8
  %v5231 = load i64, ptr %slot927, align 8
  %v5232 = load i64, ptr %slot826, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  %rgep5234 = getelementptr i8, ptr %p5233, i64 -16
  store i64 %v5231, ptr %rgep5234, align 8, !alias.scope !9, !noalias !10
  %v5235 = load i64, ptr %slot859, align 8
  %p5237 = inttoptr i64 %v5235 to ptr
  %gep5238 = getelementptr i8, ptr %p5237, i64 16
  %op5236 = ptrtoint ptr %gep5238 to i64
  store i64 %op5236, ptr %slot929, align 8
  %v5239 = load i64, ptr %slot929, align 8
  %p5240 = inttoptr i64 %v5239 to ptr
  %ld5241 = load i64, ptr %p5240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5241, ptr %slot930, align 8
  %v5242 = load i64, ptr %slot884, align 8
  %op5243 = add i64 %v5242, 0
  store i64 %op5243, ptr %slot931, align 8
  %v5244 = load i64, ptr %slot930, align 8
  %v5245 = load i64, ptr %slot931, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  store i64 %v5244, ptr %p5246, align 8, !alias.scope !9999998, !noalias !9999999
  %v5247 = load i64, ptr %slot884, align 8
  %op5248 = add i64 %v5247, 8
  store i64 %op5248, ptr %slot932, align 8
  %v5249 = load i64, ptr %slot826, align 8
  %v5250 = load i64, ptr %slot932, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  store i64 %v5249, ptr %p5251, align 8, !alias.scope !9999998, !noalias !9999999
  %v5252 = load i64, ptr %slot884, align 8
  %op5253 = add i64 %v5252, 16
  store i64 %op5253, ptr %slot933, align 8
  %v5254 = load i64, ptr %slot926, align 8
  %v5255 = load i64, ptr %slot933, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  store i64 %v5254, ptr %p5256, align 8, !alias.scope !9999998, !noalias !9999999
  %v5257 = load i64, ptr %slot884, align 8
  %op5258 = add i64 %v5257, 24
  store i64 %op5258, ptr %slot934, align 8
  %v5259 = load i64, ptr %slot934, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  store i32 1, ptr %p5260, align 4, !alias.scope !9999998, !noalias !9999999
  %v5261 = load i64, ptr %slot884, align 8
  %op5262 = add i64 %v5261, 32
  store i64 %op5262, ptr %slot935, align 8
  %v5263 = load i64, ptr %slot899, align 8
  %v5264 = load i64, ptr %slot935, align 8
  %p5265 = inttoptr i64 %v5264 to ptr
  store i64 %v5263, ptr %p5265, align 8, !alias.scope !9999998, !noalias !9999999
  %v5266 = load i64, ptr %slot859, align 8
  %p5268 = inttoptr i64 %v5266 to ptr
  %gep5269 = getelementptr i8, ptr %p5268, i64 16
  %op5267 = ptrtoint ptr %gep5269 to i64
  store i64 %op5267, ptr %slot936, align 8
  %v5270 = load i64, ptr %slot884, align 8
  %v5271 = load i64, ptr %slot936, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  store i64 %v5270, ptr %p5272, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone1272
bb_rcspinslow1272:
  %v5273 = load i64, ptr %slot1, align 8
  %p5274 = inttoptr i64 %v5273 to ptr
  %v5275 = load i64, ptr %slot859, align 8
  %p5276 = inttoptr i64 %v5275 to ptr
  %v5277 = load i64, ptr %slot826, align 8
  %p5278 = inttoptr i64 %v5277 to ptr
  %call5279 = call i32 @myl_qbe_rc_scope_pin(ptr %p5274, ptr %p5276, ptr %p5278) nomerge, !dbg !178
  store i32 %call5279, ptr %slot937, align 8
  %v5280 = load i32, ptr %slot937, align 8
  %cv5281 = zext i32 %v5280 to i64
  %cond5282 = icmp ne i64 %cv5281, 0
  br i1 %cond5282, label %bb_rcunique1349, label %bb_failure
bb_rcunique1349:
  br label %bb_rcspindone1272
bb_rcspindone1272:
  %v5283 = load i64, ptr %slot826, align 8
  %v5284 = load i64, ptr %slot40, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i64 %v5283, ptr %p5285, align 8, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot34, align 8
  %v5287 = load i64, ptr %slot44, align 8
  %p5288 = inttoptr i64 %v5287 to ptr
  store i64 %v5286, ptr %p5288, align 8, !alias.scope !3, !noalias !4
  %v5289 = load i64, ptr %slot44, align 8
  %p5290 = inttoptr i64 %v5289 to ptr
  %ld5291 = load i64, ptr %p5290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5291, ptr %slot938, align 8
  %v5292 = load i64, ptr %slot938, align 8
  %op5293 = add i64 %v5292, 48
  store i64 %op5293, ptr %slot939, align 8
  %v5294 = load i64, ptr %slot939, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %ld5296 = load i64, ptr %p5295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5296, ptr %slot940, align 8
  %v5297 = load i64, ptr %slot940, align 8
  %v5298 = load i64, ptr %slot44, align 8
  %p5299 = inttoptr i64 %v5298 to ptr
  store i64 %v5297, ptr %p5299, align 8, !alias.scope !3, !noalias !4
  %v5300 = load i64, ptr %slot12, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  %ld5302 = load i32, ptr %p5301, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5302, ptr %slot941, align 8
  %v5303 = load i32, ptr %slot941, align 8
  %cv5304 = zext i32 %v5303 to i64
  %cond5305 = icmp ne i64 %cv5304, 0
  br i1 %cond5305, label %bb_rcslotdrop1355, label %bb_rcslotdone1355
bb_rcslotdrop1355:
  %v5306 = load i64, ptr %slot12, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  store i32 0, ptr %p5307, align 4, !alias.scope !3, !noalias !4
  %v5308 = load i64, ptr %slot19, align 8
  store i64 %v5308, ptr %slot942, align 8
  %v5309 = load i64, ptr %slot13, align 8
  %p5310 = inttoptr i64 %v5309 to ptr
  %ld5311 = load i32, ptr %p5310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5311, ptr %slot943, align 8
  %v5312 = load i32, ptr %slot943, align 8
  %op5313 = and i32 %v5312, 28
  store i32 %op5313, ptr %slot944, align 8
  %v5314 = load i32, ptr %slot944, align 8
  %cv5315 = zext i32 %v5314 to i64
  %cond5316 = icmp ne i64 %cv5315, 0
  br i1 %cond5316, label %bb_rcslotrole1355, label %bb_rcslotowner1355
bb_rcslotrole1355:
  %v5317 = load i64, ptr %slot56, align 8
  store i64 %v5317, ptr %slot945, align 8
  %v5318 = load i64, ptr %slot945, align 8
  %v5319 = load i64, ptr %slot942, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5318, i64 %v5319) nomerge, !dbg !180
  br label %bb_rcslotdone1355
bb_rcslotowner1355:
  %v5320 = load i64, ptr %slot56, align 8
  store i64 %v5320, ptr %slot946, align 8
  %v5321 = load i64, ptr %slot946, align 8
  %v5322 = load i64, ptr %slot942, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5321, i64 %v5322) nomerge, !dbg !180
  br label %bb_rcslotdone1355
bb_rcslotdone1355:
  %v5323 = load i64, ptr %slot44, align 8
  %p5324 = inttoptr i64 %v5323 to ptr
  %ld5325 = load i64, ptr %p5324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5325, ptr %slot947, align 8
  %v5326 = load i64, ptr %slot947, align 8
  %v5327 = load i64, ptr %slot42, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  store i64 %v5326, ptr %p5328, align 8, !alias.scope !3, !noalias !4
  %v5329 = load i64, ptr %slot42, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i64, ptr %p5330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5331, ptr %slot948, align 8
  %v5332 = load i64, ptr %slot948, align 8
  %v5333 = load i64, ptr %slot44, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  store i64 %v5332, ptr %p5334, align 8, !alias.scope !3, !noalias !4
  %v5335 = load i64, ptr %slot45, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  store i64 0, ptr %p5336, align 8, !alias.scope !3, !noalias !4
  %v5337 = load i64, ptr %slot45, align 8
  %p5338 = inttoptr i64 %v5337 to ptr
  %ld5339 = load i64, ptr %p5338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5339, ptr %slot949, align 8
  %v5340 = load i64, ptr %slot44, align 8
  %p5341 = inttoptr i64 %v5340 to ptr
  %ld5342 = load i64, ptr %p5341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5342, ptr %slot950, align 8
  %v5343 = load i64, ptr %slot950, align 8
  %v5344 = load i64, ptr %slot949, align 8
  %cmp5345 = icmp slt i64 %v5343, %v5344
  %cv5346 = zext i1 %cmp5345 to i64
  store i64 %cv5346, ptr %slot951, align 8
  %v5347 = load i64, ptr %slot951, align 8
  %v5348 = load i64, ptr %slot44, align 8
  %p5349 = inttoptr i64 %v5348 to ptr
  store i64 %v5347, ptr %p5349, align 8, !alias.scope !3, !noalias !4
  %v5350 = load i64, ptr %slot44, align 8
  %p5351 = inttoptr i64 %v5350 to ptr
  %ld5352 = load i64, ptr %p5351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5352, ptr %slot952, align 8
  %v5353 = load i64, ptr %slot952, align 8
  %cond5354 = icmp ne i64 %v5353, 0
  br i1 %cond5354, label %bb_next1368, label %bb_i88
bb_next1368:
  %v5355 = load i64, ptr %slot40, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  %ld5357 = load i64, ptr %p5356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5357, ptr %slot953, align 8
  %v5358 = load i64, ptr %slot953, align 8
  %op5359 = add i64 %v5358, 0
  store i64 %op5359, ptr %slot954, align 8
  %v5360 = load i64, ptr %slot954, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %ld5362 = load i64, ptr %p5361, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5362, ptr %slot955, align 8
  %v5363 = load i64, ptr %slot955, align 8
  %v5364 = load i64, ptr %slot44, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  store i64 %v5363, ptr %p5365, align 8, !alias.scope !3, !noalias !4
  %v5366 = load i64, ptr %slot44, align 8
  %p5367 = inttoptr i64 %v5366 to ptr
  %ld5368 = load i64, ptr %p5367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5368, ptr %slot956, align 8
  %v5369 = load i64, ptr %slot956, align 8
  %cmp5370 = icmp ugt i64 %v5369, 9223372036854775807
  %cv5371 = zext i1 %cmp5370 to i64
  store i64 %cv5371, ptr %slot957, align 8
  %v5372 = load i64, ptr %slot957, align 8
  %cond5373 = icmp ne i64 %v5372, 0
  br i1 %cond5373, label %bb_cast_overflow1373, label %bb_cast_ok1373
bb_cast_overflow1373:
  %v5374 = load i64, ptr %slot1, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  %v5376 = load i64, ptr %slot956, align 8
  call void @myl_qbe_fail_cast(ptr %p5375, i64 %v5376, i64 320) nomerge, !dbg !182
  unreachable
bb_cast_ok1373:
  %v5377 = load i64, ptr %slot956, align 8
  %v5378 = load i64, ptr %slot44, align 8
  %p5379 = inttoptr i64 %v5378 to ptr
  store i64 %v5377, ptr %p5379, align 8, !alias.scope !3, !noalias !4
  %v5380 = load i64, ptr %slot42, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %ld5382 = load i64, ptr %p5381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5382, ptr %slot958, align 8
  %v5383 = load i64, ptr %slot958, align 8
  %v5384 = load i64, ptr %slot45, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  store i64 %v5383, ptr %p5385, align 8, !alias.scope !3, !noalias !4
  %v5386 = load i64, ptr %slot45, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %ld5388 = load i64, ptr %p5387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5388, ptr %slot959, align 8
  %v5389 = load i64, ptr %slot44, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  %ld5391 = load i64, ptr %p5390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5391, ptr %slot960, align 8
  %v5392 = load i64, ptr %slot960, align 8
  %v5393 = load i64, ptr %slot959, align 8
  %ovpair5395 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5392, i64 %v5393)
  %op5394 = extractvalue { i64, i1 } %ovpair5395, 0
  %ov5396 = extractvalue { i64, i1 } %ovpair5395, 1
  store i64 %op5394, ptr %slot961, align 8
  %v5397 = load i64, ptr %slot960, align 8
  %v5398 = load i64, ptr %slot961, align 8
  %op5399 = xor i64 %v5397, %v5398
  store i64 %op5399, ptr %slot962, align 8
  %v5400 = load i64, ptr %slot959, align 8
  %v5401 = load i64, ptr %slot961, align 8
  %op5402 = xor i64 %v5400, %v5401
  store i64 %op5402, ptr %slot963, align 8
  %v5403 = load i64, ptr %slot962, align 8
  %v5404 = load i64, ptr %slot963, align 8
  %op5405 = and i64 %v5403, %v5404
  store i64 %op5405, ptr %slot964, align 8
  %cv5406 = zext i1 %ov5396 to i64
  store i64 %cv5406, ptr %slot965, align 8
  %v5407 = load i64, ptr %slot965, align 8
  %cond5408 = icmp ne i64 %v5407, 0
  br i1 %cond5408, label %bb_overflow1377, label %bb_checked1377
bb_overflow1377:
  %v5409 = load i64, ptr %slot1, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  %v5411 = load i64, ptr %slot960, align 8
  %v5412 = load i64, ptr %slot959, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5410, i64 0, i64 %v5411, i64 %v5412, i64 64) nomerge, !dbg !184
  unreachable
bb_checked1377:
  %v5413 = load i64, ptr %slot961, align 8
  %v5414 = load i64, ptr %slot44, align 8
  %p5415 = inttoptr i64 %v5414 to ptr
  store i64 %v5413, ptr %p5415, align 8, !alias.scope !3, !noalias !4
  %v5416 = load i64, ptr %slot44, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %ld5418 = load i64, ptr %p5417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5418, ptr %slot966, align 8
  %v5419 = load i64, ptr %slot966, align 8
  %v5420 = load i64, ptr %slot42, align 8
  %p5421 = inttoptr i64 %v5420 to ptr
  store i64 %v5419, ptr %p5421, align 8, !alias.scope !3, !noalias !4
  br label %bb_i88
bb_i88:
  %v5422 = load i64, ptr %slot42, align 8
  %p5423 = inttoptr i64 %v5422 to ptr
  %ld5424 = load i64, ptr %p5423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5424, ptr %slot967, align 8
  %v5425 = load i64, ptr %slot967, align 8
  %v5426 = load i64, ptr %slot44, align 8
  %p5427 = inttoptr i64 %v5426 to ptr
  store i64 %v5425, ptr %p5427, align 8, !alias.scope !3, !noalias !4
  %v5428 = load i64, ptr %slot41, align 8
  %v5429 = load i64, ptr %slot50, align 8
  %p5430 = inttoptr i64 %v5428 to ptr
  %p5431 = inttoptr i64 %v5429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5431, ptr %p5430, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5432 = load i64, ptr %slot50, align 8
  %v5433 = load i64, ptr %slot45, align 8
  %p5434 = inttoptr i64 %v5433 to ptr
  store i64 %v5432, ptr %p5434, align 8, !alias.scope !3, !noalias !4
  %v5435 = load i64, ptr %slot40, align 8
  %p5436 = inttoptr i64 %v5435 to ptr
  %ld5437 = load i64, ptr %p5436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5437, ptr %slot968, align 8
  %v5438 = load i64, ptr %slot45, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %ld5440 = load i64, ptr %p5439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5440, ptr %slot969, align 8
  %v5441 = load i64, ptr %slot44, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %ld5443 = load i64, ptr %p5442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5443, ptr %slot970, align 8
  %v5444 = load i64, ptr %slot968, align 8
  %p5445 = inttoptr i64 %v5444 to ptr
  %ld5446 = load i64, ptr %p5445, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5446, ptr %slot971, align 8
  %v5447 = load i64, ptr %slot970, align 8
  %v5448 = load i64, ptr %slot971, align 8
  %cmp5449 = icmp ult i64 %v5447, %v5448
  %cv5450 = zext i1 %cmp5449 to i64
  store i64 %cv5450, ptr %slot972, align 8
  %v5451 = load i64, ptr %slot972, align 8
  %cond5452 = icmp ne i64 %v5451, 0
  br i1 %cond5452, label %bb_success1390, label %bb_failed1390
bb_failed1390:
  %v5453 = load i64, ptr %slot1, align 8
  %p5454 = inttoptr i64 %v5453 to ptr
  %v5455 = load i64, ptr %slot970, align 8
  %v5456 = load i64, ptr %slot971, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5454, i64 %v5455, i64 %v5456) nomerge, !dbg !186
  unreachable
bb_success1390:
  %v5457 = load i64, ptr %slot45, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  %ld5459 = load i64, ptr %p5458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5459, ptr %slot973, align 8
  %v5460 = load i64, ptr %slot56, align 8
  %v5461 = load i64, ptr %slot968, align 8
  %v5462 = load i64, ptr %slot970, align 8
  %v5463 = load i64, ptr %slot973, align 8
  %call5464 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v5460, i64 %v5461, i64 %v5462, i64 %v5463) nomerge, !dbg !186
  store i32 %call5464, ptr %slot974, align 8
  %v5465 = load i32, ptr %slot974, align 8
  %cv5466 = zext i32 %v5465 to i64
  %cond5467 = icmp ne i64 %cv5466, 0
  br i1 %cond5467, label %bb_success1393, label %bb_failed1393
bb_failed1393:
  %v5468 = load i64, ptr %slot1, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5469) nomerge, !dbg !186
  unreachable
bb_success1393:
  %v5470 = load i64, ptr %slot44, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  store i64 0, ptr %p5471, align 8, !alias.scope !3, !noalias !4
  %v5472 = load i64, ptr %slot14, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  %ld5474 = load i32, ptr %p5473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5474, ptr %slot975, align 8
  %v5475 = load i32, ptr %slot975, align 8
  %cv5476 = zext i32 %v5475 to i64
  %cond5477 = icmp ne i64 %cv5476, 0
  br i1 %cond5477, label %bb_rcslotdrop1396, label %bb_rcslotdone1396
bb_rcslotdrop1396:
  %v5478 = load i64, ptr %slot14, align 8
  %p5479 = inttoptr i64 %v5478 to ptr
  store i32 0, ptr %p5479, align 4, !alias.scope !3, !noalias !4
  %v5480 = load i64, ptr %slot20, align 8
  store i64 %v5480, ptr %slot976, align 8
  %v5481 = load i64, ptr %slot15, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %ld5483 = load i32, ptr %p5482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5483, ptr %slot977, align 8
  %v5484 = load i32, ptr %slot977, align 8
  %op5485 = and i32 %v5484, 28
  store i32 %op5485, ptr %slot978, align 8
  %v5486 = load i32, ptr %slot978, align 8
  %cv5487 = zext i32 %v5486 to i64
  %cond5488 = icmp ne i64 %cv5487, 0
  br i1 %cond5488, label %bb_rcslotrole1396, label %bb_rcslotowner1396
bb_rcslotrole1396:
  %v5489 = load i64, ptr %slot56, align 8
  store i64 %v5489, ptr %slot979, align 8
  %v5490 = load i64, ptr %slot979, align 8
  %v5491 = load i64, ptr %slot976, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v5490, i64 %v5491) nomerge, !dbg !186
  br label %bb_rcslotdone1396
bb_rcslotowner1396:
  %v5492 = load i64, ptr %slot56, align 8
  store i64 %v5492, ptr %slot980, align 8
  %v5493 = load i64, ptr %slot980, align 8
  %v5494 = load i64, ptr %slot976, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v5493, i64 %v5494) nomerge, !dbg !186
  br label %bb_rcslotdone1396
bb_rcslotdone1396:
  %v5495 = load i64, ptr %slot26, align 8
  store i64 %v5495, ptr %slot981, align 8
  %v5496 = load i64, ptr %slot981, align 8
  %p5498 = inttoptr i64 %v5496 to ptr
  %gep5499 = getelementptr i8, ptr %p5498, i64 24
  %op5497 = ptrtoint ptr %gep5499 to i64
  store i64 %op5497, ptr %slot982, align 8
  %v5500 = load i64, ptr %slot982, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  %ld5502 = load i32, ptr %p5501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5502, ptr %slot983, align 8
  %v5503 = load i32, ptr %slot983, align 8
  %cv5504 = zext i32 %v5503 to i64
  %cond5505 = icmp ne i64 %cv5504, 0
  br i1 %cond5505, label %bb_rcsendactive1404, label %bb_rcsenddone1404
bb_rcsendactive1404:
  %v5506 = load i64, ptr %slot56, align 8
  %p5508 = inttoptr i64 %v5506 to ptr
  %gep5509 = getelementptr i8, ptr %p5508, i64 5640
  %op5507 = ptrtoint ptr %gep5509 to i64
  store i64 %op5507, ptr %slot984, align 8
  %v5510 = load i64, ptr %slot984, align 8
  %p5511 = inttoptr i64 %v5510 to ptr
  %ld5512 = load i64, ptr %p5511, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5512, ptr %slot985, align 8
  %v5513 = load i64, ptr %slot985, align 8
  %op5514 = add i64 %v5513, 248
  store i64 %op5514, ptr %slot986, align 8
  %v5515 = load i64, ptr %slot986, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %ld5517 = load i64, ptr %p5516, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5517, ptr %slot987, align 8
  %v5518 = load i64, ptr %slot987, align 8
  %v5519 = load i64, ptr %slot981, align 8
  %cmp5520 = icmp eq i64 %v5518, %v5519
  %cv5521 = zext i1 %cmp5520 to i32
  store i32 %cv5521, ptr %slot988, align 8
  %v5522 = load i32, ptr %slot988, align 8
  %cv5523 = zext i32 %v5522 to i64
  %cond5524 = icmp ne i64 %cv5523, 0
  br i1 %cond5524, label %bb_rcs1412, label %bb_rcsendslow1404
bb_rcs1412:
  %v5525 = load i64, ptr %slot985, align 8
  %op5526 = add i64 %v5525, 200
  store i64 %op5526, ptr %slot989, align 8
  %v5527 = load i64, ptr %slot989, align 8
  %p5528 = inttoptr i64 %v5527 to ptr
  %ld5529 = load i64, ptr %p5528, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5529, ptr %slot990, align 8
  %v5530 = load i64, ptr %slot990, align 8
  %cmp5531 = icmp eq i64 %v5530, 0
  %cv5532 = zext i1 %cmp5531 to i32
  store i32 %cv5532, ptr %slot991, align 8
  %v5533 = load i32, ptr %slot991, align 8
  %cv5534 = zext i32 %v5533 to i64
  %cond5535 = icmp ne i64 %cv5534, 0
  br i1 %cond5535, label %bb_rcs1416, label %bb_rcsendslow1404
bb_rcs1416:
  %v5536 = load i64, ptr %slot981, align 8
  %p5538 = inttoptr i64 %v5536 to ptr
  %gep5539 = getelementptr i8, ptr %p5538, i64 16
  %op5537 = ptrtoint ptr %gep5539 to i64
  store i64 %op5537, ptr %slot992, align 8
  %v5540 = load i64, ptr %slot992, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  %ld5542 = load i64, ptr %p5541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5542, ptr %slot993, align 8
  %v5543 = load i64, ptr %slot993, align 8
  %cmp5544 = icmp ne i64 %v5543, 0
  %cv5545 = zext i1 %cmp5544 to i32
  store i32 %cv5545, ptr %slot994, align 8
  %v5546 = load i32, ptr %slot994, align 8
  %cv5547 = zext i32 %v5546 to i64
  %cond5548 = icmp ne i64 %cv5547, 0
  br i1 %cond5548, label %bb_rcsendnode1404, label %bb_rcsendunlink1404
bb_rcsendnode1404:
  %v5549 = load i64, ptr %slot993, align 8
  %op5550 = add i64 %v5549, 0
  store i64 %op5550, ptr %slot995, align 8
  %v5551 = load i64, ptr %slot995, align 8
  %p5552 = inttoptr i64 %v5551 to ptr
  %ld5553 = load i64, ptr %p5552, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5553, ptr %slot996, align 8
  %v5554 = load i64, ptr %slot996, align 8
  %cmp5555 = icmp eq i64 %v5554, 0
  %cv5556 = zext i1 %cmp5555 to i32
  store i32 %cv5556, ptr %slot997, align 8
  %v5557 = load i32, ptr %slot997, align 8
  %cv5558 = zext i32 %v5557 to i64
  %cond5559 = icmp ne i64 %cv5558, 0
  br i1 %cond5559, label %bb_rcs1423, label %bb_rcsendslow1404
bb_rcs1423:
  %v5560 = load i64, ptr %slot985, align 8
  %op5561 = add i64 %v5560, 264
  store i64 %op5561, ptr %slot998, align 8
  %v5562 = load i64, ptr %slot998, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %ld5564 = load i64, ptr %p5563, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5564, ptr %slot999, align 8
  %v5565 = load i64, ptr %slot999, align 8
  %cmp5566 = icmp ult i64 %v5565, 32
  %cv5567 = zext i1 %cmp5566 to i32
  store i32 %cv5567, ptr %slot1000, align 8
  %v5568 = load i32, ptr %slot1000, align 8
  %cv5569 = zext i32 %v5568 to i64
  %cond5570 = icmp ne i64 %cv5569, 0
  br i1 %cond5570, label %bb_rcs1427, label %bb_rcsendslow1404
bb_rcs1427:
  %v5571 = load i64, ptr %slot993, align 8
  %op5572 = add i64 %v5571, 8
  store i64 %op5572, ptr %slot1001, align 8
  %v5573 = load i64, ptr %slot1001, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %ld5575 = load i64, ptr %p5574, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5575, ptr %slot1002, align 8
  %v5576 = load i64, ptr %slot1002, align 8
  %cmp5577 = icmp ne i64 %v5576, 0
  %cv5578 = zext i1 %cmp5577 to i32
  store i32 %cv5578, ptr %slot1003, align 8
  %v5579 = load i32, ptr %slot1003, align 8
  %cv5580 = zext i32 %v5579 to i64
  %cond5581 = icmp ne i64 %cv5580, 0
  br i1 %cond5581, label %bb_rcs1431, label %bb_rcsendslow1404
bb_rcs1431:
  %v5582 = load i64, ptr %slot1002, align 8
  %op5583 = sub i64 %v5582, 16
  store i64 %op5583, ptr %slot1004, align 8
  %v5584 = load i64, ptr %slot1002, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  %rgep5586 = getelementptr i8, ptr %p5585, i64 -16
  %ld5587 = load i64, ptr %rgep5586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5587, ptr %slot1005, align 8
  %v5588 = load i64, ptr %slot1005, align 8
  %op5589 = and i64 %v5588, 4611686018427387907
  store i64 %op5589, ptr %slot1006, align 8
  %v5590 = load i64, ptr %slot1006, align 8
  %cmp5591 = icmp eq i64 %v5590, 0
  %cv5592 = zext i1 %cmp5591 to i32
  store i32 %cv5592, ptr %slot1007, align 8
  %v5593 = load i32, ptr %slot1007, align 8
  %cv5594 = zext i32 %v5593 to i64
  %cond5595 = icmp ne i64 %cv5594, 0
  br i1 %cond5595, label %bb_rcs1436, label %bb_rcsendslow1404
bb_rcs1436:
  %v5596 = load i64, ptr %slot1002, align 8
  %op5597 = sub i64 %v5596, 24
  store i64 %op5597, ptr %slot1008, align 8
  %v5598 = load i64, ptr %slot1002, align 8
  %p5599 = inttoptr i64 %v5598 to ptr
  %rgep5600 = getelementptr i8, ptr %p5599, i64 -24
  %ld5601 = load i64, ptr %rgep5600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5601, ptr %slot1009, align 8
  %v5602 = load i64, ptr %slot1009, align 8
  %cmp5603 = icmp ne i64 %v5602, 0
  %cv5604 = zext i1 %cmp5603 to i32
  store i32 %cv5604, ptr %slot1010, align 8
  %v5605 = load i32, ptr %slot1010, align 8
  %cv5606 = zext i32 %v5605 to i64
  %cond5607 = icmp ne i64 %cv5606, 0
  br i1 %cond5607, label %bb_rcs1440, label %bb_rcsendslow1404
bb_rcs1440:
  %v5608 = load i64, ptr %slot1002, align 8
  %op5609 = sub i64 %v5608, 32
  store i64 %op5609, ptr %slot1011, align 8
  %v5610 = load i64, ptr %slot1002, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  %rgep5612 = getelementptr i8, ptr %p5611, i64 -32
  %ld5613 = load i64, ptr %rgep5612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5613, ptr %slot1012, align 8
  %v5614 = load i64, ptr %slot1009, align 8
  %cmp5615 = icmp ugt i64 %v5614, 1
  %cv5616 = zext i1 %cmp5615 to i32
  store i32 %cv5616, ptr %slot1013, align 8
  %v5617 = load i64, ptr %slot1012, align 8
  %cmp5618 = icmp ne i64 %v5617, 0
  %cv5619 = zext i1 %cmp5618 to i32
  store i32 %cv5619, ptr %slot1014, align 8
  %v5620 = load i32, ptr %slot1013, align 8
  %v5621 = load i32, ptr %slot1014, align 8
  %op5622 = or i32 %v5620, %v5621
  store i32 %op5622, ptr %slot1015, align 8
  %v5623 = load i32, ptr %slot1015, align 8
  %cv5624 = zext i32 %v5623 to i64
  %cond5625 = icmp ne i64 %cv5624, 0
  br i1 %cond5625, label %bb_rcs1446, label %bb_rcsendslow1404
bb_rcs1446:
  %v5626 = load i64, ptr %slot993, align 8
  %op5627 = add i64 %v5626, 32
  store i64 %op5627, ptr %slot1016, align 8
  %v5628 = load i64, ptr %slot1016, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %ld5630 = load i64, ptr %p5629, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5630, ptr %slot1017, align 8
  %v5631 = load i64, ptr %slot1017, align 8
  %cmp5632 = icmp ne i64 %v5631, 0
  %cv5633 = zext i1 %cmp5632 to i32
  store i32 %cv5633, ptr %slot1018, align 8
  %v5634 = load i32, ptr %slot1018, align 8
  %cv5635 = zext i32 %v5634 to i64
  %cond5636 = icmp ne i64 %cv5635, 0
  br i1 %cond5636, label %bb_rcsendbacking1404, label %bb_rcsendcommit1404
bb_rcsendbacking1404:
  %v5637 = load i64, ptr %slot1017, align 8
  %op5638 = sub i64 %v5637, 16
  store i64 %op5638, ptr %slot1019, align 8
  %v5639 = load i64, ptr %slot1017, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  %rgep5641 = getelementptr i8, ptr %p5640, i64 -16
  %ld5642 = load i64, ptr %rgep5641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5642, ptr %slot1020, align 8
  %v5643 = load i64, ptr %slot1020, align 8
  %op5644 = and i64 %v5643, 4611686018427387907
  store i64 %op5644, ptr %slot1021, align 8
  %v5645 = load i64, ptr %slot1021, align 8
  %cmp5646 = icmp eq i64 %v5645, 0
  %cv5647 = zext i1 %cmp5646 to i32
  store i32 %cv5647, ptr %slot1022, align 8
  %v5648 = load i32, ptr %slot1022, align 8
  %cv5649 = zext i32 %v5648 to i64
  %cond5650 = icmp ne i64 %cv5649, 0
  br i1 %cond5650, label %bb_rcs1454, label %bb_rcsendslow1404
bb_rcs1454:
  %v5651 = load i64, ptr %slot1017, align 8
  %op5652 = sub i64 %v5651, 24
  store i64 %op5652, ptr %slot1023, align 8
  %v5653 = load i64, ptr %slot1017, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %rgep5655 = getelementptr i8, ptr %p5654, i64 -24
  %ld5656 = load i64, ptr %rgep5655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5656, ptr %slot1024, align 8
  %v5657 = load i64, ptr %slot1024, align 8
  %cmp5658 = icmp ne i64 %v5657, 0
  %cv5659 = zext i1 %cmp5658 to i32
  store i32 %cv5659, ptr %slot1025, align 8
  %v5660 = load i32, ptr %slot1025, align 8
  %cv5661 = zext i32 %v5660 to i64
  %cond5662 = icmp ne i64 %cv5661, 0
  br i1 %cond5662, label %bb_rcs1458, label %bb_rcsendslow1404
bb_rcs1458:
  %v5663 = load i64, ptr %slot1017, align 8
  %op5664 = sub i64 %v5663, 32
  store i64 %op5664, ptr %slot1026, align 8
  %v5665 = load i64, ptr %slot1017, align 8
  %p5666 = inttoptr i64 %v5665 to ptr
  %rgep5667 = getelementptr i8, ptr %p5666, i64 -32
  %ld5668 = load i64, ptr %rgep5667, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5668, ptr %slot1027, align 8
  %v5669 = load i64, ptr %slot1024, align 8
  %cmp5670 = icmp ugt i64 %v5669, 1
  %cv5671 = zext i1 %cmp5670 to i32
  store i32 %cv5671, ptr %slot1028, align 8
  %v5672 = load i64, ptr %slot1027, align 8
  %cmp5673 = icmp ne i64 %v5672, 0
  %cv5674 = zext i1 %cmp5673 to i32
  store i32 %cv5674, ptr %slot1029, align 8
  %v5675 = load i32, ptr %slot1028, align 8
  %v5676 = load i32, ptr %slot1029, align 8
  %op5677 = or i32 %v5675, %v5676
  store i32 %op5677, ptr %slot1030, align 8
  %v5678 = load i32, ptr %slot1030, align 8
  %cv5679 = zext i32 %v5678 to i64
  %cond5680 = icmp ne i64 %cv5679, 0
  br i1 %cond5680, label %bb_rcs1464, label %bb_rcsendslow1404
bb_rcs1464:
  br label %bb_rcsendcommit1404
bb_rcsendcommit1404:
  %v5681 = load i64, ptr %slot993, align 8
  %op5682 = add i64 %v5681, 24
  store i64 %op5682, ptr %slot1031, align 8
  %v5683 = load i64, ptr %slot1031, align 8
  %p5684 = inttoptr i64 %v5683 to ptr
  %ld5685 = load i32, ptr %p5684, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld5685, ptr %slot1032, align 8
  %v5686 = load i32, ptr %slot1032, align 8
  %cv5687 = zext i32 %v5686 to i64
  %cond5688 = icmp ne i64 %cv5687, 0
  br i1 %cond5688, label %bb_rcsendrestore1404, label %bb_rcsendreturned1404
bb_rcsendrestore1404:
  %v5689 = load i64, ptr %slot993, align 8
  %op5690 = add i64 %v5689, 16
  store i64 %op5690, ptr %slot1033, align 8
  %v5691 = load i64, ptr %slot1033, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  %ld5693 = load i64, ptr %p5692, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5693, ptr %slot1034, align 8
  %v5694 = load i64, ptr %slot1005, align 8
  %op5695 = and i64 %v5694, 17293822569102704639
  store i64 %op5695, ptr %slot1035, align 8
  %v5696 = load i64, ptr %slot1035, align 8
  %v5697 = load i64, ptr %slot1034, align 8
  %op5698 = or i64 %v5696, %v5697
  store i64 %op5698, ptr %slot1036, align 8
  %v5699 = load i64, ptr %slot1002, align 8
  %op5700 = sub i64 %v5699, 16
  store i64 %op5700, ptr %slot1037, align 8
  %v5701 = load i64, ptr %slot1036, align 8
  %v5702 = load i64, ptr %slot1002, align 8
  %p5703 = inttoptr i64 %v5702 to ptr
  %rgep5704 = getelementptr i8, ptr %p5703, i64 -16
  store i64 %v5701, ptr %rgep5704, align 8, !alias.scope !9, !noalias !10
  %v5705 = load i64, ptr %slot981, align 8
  %p5707 = inttoptr i64 %v5705 to ptr
  %gep5708 = getelementptr i8, ptr %p5707, i64 16
  %op5706 = ptrtoint ptr %gep5708 to i64
  store i64 %op5706, ptr %slot1038, align 8
  br label %bb_rcsendreturned1404
bb_rcsendreturned1404:
  %v5709 = load i64, ptr %slot1038, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  store i64 0, ptr %p5710, align 8, !alias.scope !3, !noalias !4
  %v5711 = load i64, ptr %slot985, align 8
  %op5712 = add i64 %v5711, 256
  store i64 %op5712, ptr %slot1039, align 8
  %v5713 = load i64, ptr %slot1039, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  %ld5715 = load i64, ptr %p5714, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5715, ptr %slot1040, align 8
  %v5716 = load i64, ptr %slot993, align 8
  %op5717 = add i64 %v5716, 0
  store i64 %op5717, ptr %slot1041, align 8
  %v5718 = load i64, ptr %slot1040, align 8
  %v5719 = load i64, ptr %slot1041, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  store i64 %v5718, ptr %p5720, align 8, !alias.scope !9999998, !noalias !9999999
  %v5721 = load i64, ptr %slot985, align 8
  %op5722 = add i64 %v5721, 256
  store i64 %op5722, ptr %slot1042, align 8
  %v5723 = load i64, ptr %slot993, align 8
  %v5724 = load i64, ptr %slot1042, align 8
  %p5725 = inttoptr i64 %v5724 to ptr
  store i64 %v5723, ptr %p5725, align 8, !alias.scope !9999998, !noalias !9999999
  %v5726 = load i64, ptr %slot985, align 8
  %op5727 = add i64 %v5726, 264
  store i64 %op5727, ptr %slot1043, align 8
  %v5728 = load i64, ptr %slot1043, align 8
  %p5729 = inttoptr i64 %v5728 to ptr
  %ld5730 = load i64, ptr %p5729, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5730, ptr %slot1044, align 8
  %v5731 = load i64, ptr %slot1044, align 8
  %op5732 = add i64 %v5731, 1
  store i64 %op5732, ptr %slot1045, align 8
  %v5733 = load i64, ptr %slot1045, align 8
  %v5734 = load i64, ptr %slot1043, align 8
  %p5735 = inttoptr i64 %v5734 to ptr
  store i64 %v5733, ptr %p5735, align 8, !alias.scope !9999998, !noalias !9999999
  %v5736 = load i64, ptr %slot56, align 8
  %p5738 = inttoptr i64 %v5736 to ptr
  %gep5739 = getelementptr i8, ptr %p5738, i64 24
  %op5737 = ptrtoint ptr %gep5739 to i64
  store i64 %op5737, ptr %slot1046, align 8
  %v5740 = load i64, ptr %slot1046, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  %ld5742 = load i64, ptr %p5741, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5742, ptr %slot1047, align 8
  %v5743 = load i64, ptr %slot1047, align 8
  %op5744 = add i64 %v5743, 18446744073709551576
  store i64 %op5744, ptr %slot1048, align 8
  %v5745 = load i64, ptr %slot1048, align 8
  %v5746 = load i64, ptr %slot1046, align 8
  %p5747 = inttoptr i64 %v5746 to ptr
  store i64 %v5745, ptr %p5747, align 8, !alias.scope !9999998, !noalias !9999999
  %v5748 = load i64, ptr %slot985, align 8
  %op5749 = add i64 %v5748, 48
  store i64 %op5749, ptr %slot1049, align 8
  %v5750 = load i64, ptr %slot1049, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %ld5752 = load i64, ptr %p5751, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld5752, ptr %slot1050, align 8
  %v5753 = load i64, ptr %slot1050, align 8
  %op5754 = add i64 %v5753, 18446744073709551576
  store i64 %op5754, ptr %slot1051, align 8
  %v5755 = load i64, ptr %slot1051, align 8
  %v5756 = load i64, ptr %slot1049, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  store i64 %v5755, ptr %p5757, align 8, !alias.scope !9999998, !noalias !9999999
  %v5758 = load i64, ptr %slot1017, align 8
  %cmp5759 = icmp ne i64 %v5758, 0
  %cv5760 = zext i1 %cmp5759 to i32
  store i32 %cv5760, ptr %slot1052, align 8
  %v5761 = load i32, ptr %slot1052, align 8
  %cv5762 = zext i32 %v5761 to i64
  %cond5763 = icmp ne i64 %cv5762, 0
  br i1 %cond5763, label %bb_rcsenddropbacking1404, label %bb_rcsenddroppayload1404
bb_rcsenddropbacking1404:
  %v5764 = load i64, ptr %slot1017, align 8
  %op5765 = sub i64 %v5764, 24
  store i64 %op5765, ptr %slot1053, align 8
  %v5766 = load i64, ptr %slot1017, align 8
  %p5767 = inttoptr i64 %v5766 to ptr
  %rgep5768 = getelementptr i8, ptr %p5767, i64 -24
  %ld5769 = load i64, ptr %rgep5768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5769, ptr %slot1054, align 8
  %v5770 = load i64, ptr %slot1054, align 8
  %op5771 = add i64 %v5770, 18446744073709551615
  store i64 %op5771, ptr %slot1055, align 8
  %v5772 = load i64, ptr %slot1055, align 8
  %v5773 = load i64, ptr %slot1017, align 8
  %p5774 = inttoptr i64 %v5773 to ptr
  %rgep5775 = getelementptr i8, ptr %p5774, i64 -24
  store i64 %v5772, ptr %rgep5775, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1404
bb_rcsenddroppayload1404:
  %v5776 = load i64, ptr %slot1002, align 8
  %op5777 = sub i64 %v5776, 24
  store i64 %op5777, ptr %slot1056, align 8
  %v5778 = load i64, ptr %slot1002, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  %rgep5780 = getelementptr i8, ptr %p5779, i64 -24
  %ld5781 = load i64, ptr %rgep5780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5781, ptr %slot1057, align 8
  %v5782 = load i64, ptr %slot1057, align 8
  %op5783 = add i64 %v5782, 18446744073709551615
  store i64 %op5783, ptr %slot1058, align 8
  %v5784 = load i64, ptr %slot1058, align 8
  %v5785 = load i64, ptr %slot1002, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  %rgep5787 = getelementptr i8, ptr %p5786, i64 -24
  store i64 %v5784, ptr %rgep5787, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1404
bb_rcsendunlink1404:
  %v5788 = load i64, ptr %slot981, align 8
  %p5790 = inttoptr i64 %v5788 to ptr
  %gep5791 = getelementptr i8, ptr %p5790, i64 8
  %op5789 = ptrtoint ptr %gep5791 to i64
  store i64 %op5789, ptr %slot1059, align 8
  %v5792 = load i64, ptr %slot1059, align 8
  %p5793 = inttoptr i64 %v5792 to ptr
  %ld5794 = load i64, ptr %p5793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5794, ptr %slot1060, align 8
  %v5795 = load i64, ptr %slot985, align 8
  %op5796 = add i64 %v5795, 248
  store i64 %op5796, ptr %slot1061, align 8
  %v5797 = load i64, ptr %slot1060, align 8
  %v5798 = load i64, ptr %slot1061, align 8
  %p5799 = inttoptr i64 %v5798 to ptr
  store i64 %v5797, ptr %p5799, align 8, !alias.scope !9999998, !noalias !9999999
  %v5800 = load i64, ptr %slot981, align 8
  %p5802 = inttoptr i64 %v5800 to ptr
  %gep5803 = getelementptr i8, ptr %p5802, i64 24
  %op5801 = ptrtoint ptr %gep5803 to i64
  store i64 %op5801, ptr %slot1062, align 8
  %v5804 = load i64, ptr %slot981, align 8
  %p5806 = inttoptr i64 %v5804 to ptr
  %gep5807 = getelementptr i8, ptr %p5806, i64 8
  %op5805 = ptrtoint ptr %gep5807 to i64
  store i64 %op5805, ptr %slot1063, align 8
  %v5808 = load i64, ptr %slot1062, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  store i32 0, ptr %p5809, align 4, !alias.scope !3, !noalias !4
  %v5810 = load i64, ptr %slot1063, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  store i64 0, ptr %p5811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1404
bb_rcsendslow1404:
  %v5812 = load i64, ptr %slot1, align 8
  %p5813 = inttoptr i64 %v5812 to ptr
  %v5814 = load i64, ptr %slot981, align 8
  %p5815 = inttoptr i64 %v5814 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p5813, ptr %p5815) nomerge, !dbg !186
  br label %bb_rcsenddone1404
bb_rcsenddone1404:
  %v5816 = load i64, ptr %slot34, align 8
  %v5817 = load i64, ptr %slot44, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i64 %v5816, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot44, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  %ld5821 = load i64, ptr %p5820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5821, ptr %slot1064, align 8
  %v5822 = load i64, ptr %slot1064, align 8
  %op5823 = add i64 %v5822, 0
  store i64 %op5823, ptr %slot1065, align 8
  %v5824 = load i64, ptr %slot1065, align 8
  %v5825 = load i64, ptr %slot44, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  store i64 %v5824, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  %v5827 = load i64, ptr %slot12, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  %ld5829 = load i32, ptr %p5828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5829, ptr %slot1066, align 8
  %v5830 = load i32, ptr %slot1066, align 8
  %cv5831 = zext i32 %v5830 to i64
  %cond5832 = icmp ne i64 %cv5831, 0
  br i1 %cond5832, label %bb_rcslotdrop1502, label %bb_rcslotdone1502
bb_rcslotdrop1502:
  %v5833 = load i64, ptr %slot12, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  store i32 0, ptr %p5834, align 4, !alias.scope !3, !noalias !4
  %v5835 = load i64, ptr %slot19, align 8
  store i64 %v5835, ptr %slot1067, align 8
  %v5836 = load i64, ptr %slot13, align 8
  %p5837 = inttoptr i64 %v5836 to ptr
  %ld5838 = load i32, ptr %p5837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5838, ptr %slot1068, align 8
  %v5839 = load i32, ptr %slot1068, align 8
  %op5840 = and i32 %v5839, 28
  store i32 %op5840, ptr %slot1069, align 8
  %v5841 = load i32, ptr %slot1069, align 8
  %cv5842 = zext i32 %v5841 to i64
  %cond5843 = icmp ne i64 %cv5842, 0
  br i1 %cond5843, label %bb_rcslotrole1502, label %bb_rcslotowner1502
bb_rcslotrole1502:
  %v5844 = load i64, ptr %slot56, align 8
  store i64 %v5844, ptr %slot1070, align 8
  %v5845 = load i64, ptr %slot1070, align 8
  %v5846 = load i64, ptr %slot1067, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5845, i64 %v5846) nomerge, !dbg !188
  br label %bb_rcslotdone1502
bb_rcslotowner1502:
  %v5847 = load i64, ptr %slot56, align 8
  store i64 %v5847, ptr %slot1071, align 8
  %v5848 = load i64, ptr %slot1071, align 8
  %v5849 = load i64, ptr %slot1067, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5848, i64 %v5849) nomerge, !dbg !188
  br label %bb_rcslotdone1502
bb_rcslotdone1502:
  %v5850 = load i64, ptr %slot44, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  %ld5852 = load i64, ptr %p5851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5852, ptr %slot1072, align 8
  %v5853 = load i64, ptr %slot1072, align 8
  %op5854 = add i64 %v5853, 0
  store i64 %op5854, ptr %slot1073, align 8
  %v5855 = load i64, ptr %slot1073, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %ld5857 = load i64, ptr %p5856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5857, ptr %slot1074, align 8
  %v5858 = load i64, ptr %slot1074, align 8
  %v5859 = load i64, ptr %slot44, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  store i64 %v5858, ptr %p5860, align 8, !alias.scope !3, !noalias !4
  %v5861 = load i64, ptr %slot12, align 8
  %p5862 = inttoptr i64 %v5861 to ptr
  %ld5863 = load i32, ptr %p5862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5863, ptr %slot1075, align 8
  %v5864 = load i32, ptr %slot1075, align 8
  %cv5865 = zext i32 %v5864 to i64
  %cond5866 = icmp ne i64 %cv5865, 0
  br i1 %cond5866, label %bb_rcslotdrop1514, label %bb_rcslotdone1514
bb_rcslotdrop1514:
  %v5867 = load i64, ptr %slot12, align 8
  %p5868 = inttoptr i64 %v5867 to ptr
  store i32 0, ptr %p5868, align 4, !alias.scope !3, !noalias !4
  %v5869 = load i64, ptr %slot19, align 8
  store i64 %v5869, ptr %slot1076, align 8
  %v5870 = load i64, ptr %slot13, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %ld5872 = load i32, ptr %p5871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5872, ptr %slot1077, align 8
  %v5873 = load i32, ptr %slot1077, align 8
  %op5874 = and i32 %v5873, 28
  store i32 %op5874, ptr %slot1078, align 8
  %v5875 = load i32, ptr %slot1078, align 8
  %cv5876 = zext i32 %v5875 to i64
  %cond5877 = icmp ne i64 %cv5876, 0
  br i1 %cond5877, label %bb_rcslotrole1514, label %bb_rcslotowner1514
bb_rcslotrole1514:
  %v5878 = load i64, ptr %slot56, align 8
  store i64 %v5878, ptr %slot1079, align 8
  %v5879 = load i64, ptr %slot1079, align 8
  %v5880 = load i64, ptr %slot1076, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v5879, i64 %v5880) nomerge, !dbg !190
  br label %bb_rcslotdone1514
bb_rcslotowner1514:
  %v5881 = load i64, ptr %slot56, align 8
  store i64 %v5881, ptr %slot1080, align 8
  %v5882 = load i64, ptr %slot1080, align 8
  %v5883 = load i64, ptr %slot1076, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v5882, i64 %v5883) nomerge, !dbg !190
  br label %bb_rcslotdone1514
bb_rcslotdone1514:
  %v5884 = load i64, ptr %slot45, align 8
  %p5885 = inttoptr i64 %v5884 to ptr
  store i64 255, ptr %p5885, align 8, !alias.scope !3, !noalias !4
  %v5886 = load i64, ptr %slot45, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  %ld5888 = load i64, ptr %p5887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5888, ptr %slot1081, align 8
  %v5889 = load i64, ptr %slot44, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %ld5891 = load i64, ptr %p5890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5891, ptr %slot1082, align 8
  %v5892 = load i64, ptr %slot1082, align 8
  %v5893 = load i64, ptr %slot1081, align 8
  %cmp5894 = icmp sgt i64 %v5892, %v5893
  %cv5895 = zext i1 %cmp5894 to i64
  store i64 %cv5895, ptr %slot1083, align 8
  %v5896 = load i64, ptr %slot1083, align 8
  %v5897 = load i64, ptr %slot44, align 8
  %p5898 = inttoptr i64 %v5897 to ptr
  store i64 %v5896, ptr %p5898, align 8, !alias.scope !3, !noalias !4
  %v5899 = load i64, ptr %slot44, align 8
  %p5900 = inttoptr i64 %v5899 to ptr
  %ld5901 = load i64, ptr %p5900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5901, ptr %slot1084, align 8
  %v5902 = load i64, ptr %slot1084, align 8
  %cond5903 = icmp ne i64 %v5902, 0
  br i1 %cond5903, label %bb_next1525, label %bb_i103
bb_next1525:
  %v5904 = load i64, ptr %slot29, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  %ld5906 = load i64, ptr %p5905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5906, ptr %slot1085, align 8
  %v5907 = load i64, ptr %slot1085, align 8
  %v5908 = load i64, ptr %slot44, align 8
  %p5909 = inttoptr i64 %v5908 to ptr
  store i64 %v5907, ptr %p5909, align 8, !alias.scope !3, !noalias !4
  %p5910 = inttoptr i64 ptrtoint (ptr @myl_lit_276758a43aa8aee7e44b193c95c360c200446c91bef4c30aa8ef6fba2c11b0b2 to i64) to ptr
  %ld5911 = load i64, ptr %p5910, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5911, ptr %slot1086, align 8
  %v5912 = load i64, ptr %slot1086, align 8
  %v5913 = load i64, ptr %slot45, align 8
  %p5914 = inttoptr i64 %v5913 to ptr
  store i64 %v5912, ptr %p5914, align 8, !alias.scope !3, !noalias !4
  %v5915 = load i64, ptr %slot45, align 8
  %p5916 = inttoptr i64 %v5915 to ptr
  %ld5917 = load i64, ptr %p5916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5917, ptr %slot1087, align 8
  %v5918 = load i64, ptr %slot1087, align 8
  %v5919 = load i64, ptr %slot22, align 8
  %p5920 = inttoptr i64 %v5919 to ptr
  store i64 %v5918, ptr %p5920, align 8, !alias.scope !3, !noalias !4
  %v5921 = load i64, ptr %slot22, align 8
  store i64 %v5921, ptr %slot1088, align 8
  %v5922 = load i64, ptr %slot23, align 8
  store i64 %v5922, ptr %slot1089, align 8
  %v5923 = load i64, ptr %slot1088, align 8
  %v5924 = load i64, ptr %slot1089, align 8
  %p5925 = inttoptr i64 %v5923 to ptr
  %p5926 = inttoptr i64 %v5924 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5926, ptr %p5925, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5927 = load i64, ptr %slot17, align 8
  %p5928 = inttoptr i64 %v5927 to ptr
  store i32 2, ptr %p5928, align 4, !alias.scope !3, !noalias !4
  %v5929 = load i64, ptr %slot16, align 8
  %p5930 = inttoptr i64 %v5929 to ptr
  store i32 1, ptr %p5930, align 4, !alias.scope !3, !noalias !4
  %v5931 = load i64, ptr %slot20, align 8
  store i64 %v5931, ptr %slot1090, align 8
  %v5932 = load i64, ptr %slot23, align 8
  store i64 %v5932, ptr %slot1091, align 8
  %v5933 = load i64, ptr %slot1091, align 8
  %v5934 = load i64, ptr %slot1090, align 8
  %p5935 = inttoptr i64 %v5933 to ptr
  %p5936 = inttoptr i64 %v5934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5936, ptr %p5935, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5937 = load i64, ptr %slot15, align 8
  %p5938 = inttoptr i64 %v5937 to ptr
  store i32 2, ptr %p5938, align 4, !alias.scope !3, !noalias !4
  %v5939 = load i64, ptr %slot17, align 8
  %p5940 = inttoptr i64 %v5939 to ptr
  %ld5941 = load i32, ptr %p5940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5941, ptr %slot1092, align 8
  %v5942 = load i32, ptr %slot1092, align 8
  %v5943 = load i64, ptr %slot15, align 8
  %p5944 = inttoptr i64 %v5943 to ptr
  store i32 %v5942, ptr %p5944, align 4, !alias.scope !3, !noalias !4
  %v5945 = load i64, ptr %slot16, align 8
  %p5946 = inttoptr i64 %v5945 to ptr
  store i32 0, ptr %p5946, align 4, !alias.scope !3, !noalias !4
  %v5947 = load i64, ptr %slot14, align 8
  %p5948 = inttoptr i64 %v5947 to ptr
  store i32 1, ptr %p5948, align 4, !alias.scope !3, !noalias !4
  %v5949 = load i64, ptr %slot1090, align 8
  %p5950 = inttoptr i64 %v5949 to ptr
  %ld5951 = load i64, ptr %p5950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5951, ptr %slot1093, align 8
  %v5952 = load i64, ptr %slot1093, align 8
  %v5953 = load i64, ptr %slot45, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  store i64 %v5952, ptr %p5954, align 8, !alias.scope !3, !noalias !4
  %v5955 = load i64, ptr %slot44, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  %ld5957 = load i64, ptr %p5956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5957, ptr %slot1094, align 8
  %v5958 = load i64, ptr %slot45, align 8
  %p5959 = inttoptr i64 %v5958 to ptr
  %ld5960 = load i64, ptr %p5959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5960, ptr %slot1095, align 8
  %v5961 = load i64, ptr %slot1, align 8
  %v5962 = load i64, ptr %slot1094, align 8
  %v5963 = load i64, ptr %slot1095, align 8
  %call5964 = call i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64 %v5961, i64 %v5962, i64 %v5963) nomerge, !dbg !192
  store i64 %call5964, ptr %slot1096, align 8
  %v5965 = load i64, ptr %slot1096, align 8
  %v5966 = load i64, ptr %slot44, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  store i64 %v5965, ptr %p5967, align 8, !alias.scope !3, !noalias !4
  %v5968 = load i64, ptr %slot12, align 8
  %p5969 = inttoptr i64 %v5968 to ptr
  %ld5970 = load i32, ptr %p5969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5970, ptr %slot1097, align 8
  %v5971 = load i32, ptr %slot1097, align 8
  %cv5972 = zext i32 %v5971 to i64
  %cond5973 = icmp ne i64 %cv5972, 0
  br i1 %cond5973, label %bb_rcslotdrop1547, label %bb_rcslotdone1547
bb_rcslotdrop1547:
  %v5974 = load i64, ptr %slot12, align 8
  %p5975 = inttoptr i64 %v5974 to ptr
  store i32 0, ptr %p5975, align 4, !alias.scope !3, !noalias !4
  %v5976 = load i64, ptr %slot19, align 8
  store i64 %v5976, ptr %slot1098, align 8
  %v5977 = load i64, ptr %slot13, align 8
  %p5978 = inttoptr i64 %v5977 to ptr
  %ld5979 = load i32, ptr %p5978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5979, ptr %slot1099, align 8
  %v5980 = load i32, ptr %slot1099, align 8
  %op5981 = and i32 %v5980, 28
  store i32 %op5981, ptr %slot1100, align 8
  %v5982 = load i32, ptr %slot1100, align 8
  %cv5983 = zext i32 %v5982 to i64
  %cond5984 = icmp ne i64 %cv5983, 0
  br i1 %cond5984, label %bb_rcslotrole1547, label %bb_rcslotowner1547
bb_rcslotrole1547:
  %v5985 = load i64, ptr %slot56, align 8
  store i64 %v5985, ptr %slot1101, align 8
  %v5986 = load i64, ptr %slot1101, align 8
  %v5987 = load i64, ptr %slot1098, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5986, i64 %v5987) nomerge, !dbg !192
  br label %bb_rcslotdone1547
bb_rcslotowner1547:
  %v5988 = load i64, ptr %slot56, align 8
  store i64 %v5988, ptr %slot1102, align 8
  %v5989 = load i64, ptr %slot1102, align 8
  %v5990 = load i64, ptr %slot1098, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5989, i64 %v5990) nomerge, !dbg !192
  br label %bb_rcslotdone1547
bb_rcslotdone1547:
  %v5991 = load i64, ptr %slot14, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  %ld5993 = load i32, ptr %p5992, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5993, ptr %slot1103, align 8
  %v5994 = load i32, ptr %slot1103, align 8
  %cv5995 = zext i32 %v5994 to i64
  %cond5996 = icmp ne i64 %cv5995, 0
  br i1 %cond5996, label %bb_rcslotdrop1556, label %bb_rcslotdone1556
bb_rcslotdrop1556:
  %v5997 = load i64, ptr %slot14, align 8
  %p5998 = inttoptr i64 %v5997 to ptr
  store i32 0, ptr %p5998, align 4, !alias.scope !3, !noalias !4
  %v5999 = load i64, ptr %slot20, align 8
  store i64 %v5999, ptr %slot1104, align 8
  %v6000 = load i64, ptr %slot15, align 8
  %p6001 = inttoptr i64 %v6000 to ptr
  %ld6002 = load i32, ptr %p6001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6002, ptr %slot1105, align 8
  %v6003 = load i32, ptr %slot1105, align 8
  %op6004 = and i32 %v6003, 28
  store i32 %op6004, ptr %slot1106, align 8
  %v6005 = load i32, ptr %slot1106, align 8
  %cv6006 = zext i32 %v6005 to i64
  %cond6007 = icmp ne i64 %cv6006, 0
  br i1 %cond6007, label %bb_rcslotrole1556, label %bb_rcslotowner1556
bb_rcslotrole1556:
  %v6008 = load i64, ptr %slot56, align 8
  store i64 %v6008, ptr %slot1107, align 8
  %v6009 = load i64, ptr %slot1104, align 8
  %p6010 = inttoptr i64 %v6009 to ptr
  %ld6011 = load i64, ptr %p6010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6011, ptr %slot1108, align 8
  %v6012 = load i64, ptr %slot1108, align 8
  %cmp6013 = icmp ne i64 %v6012, 0
  %cv6014 = zext i1 %cmp6013 to i32
  store i32 %cv6014, ptr %slot1109, align 8
  %v6015 = load i32, ptr %slot1109, align 8
  %cv6016 = zext i32 %v6015 to i64
  %cond6017 = icmp ne i64 %cv6016, 0
  br i1 %cond6017, label %bb_rcgnn1572, label %bb_rcgdone1572
bb_rcgnn1572:
  %v6018 = load i64, ptr %slot1108, align 8
  %op6019 = sub i64 %v6018, 16
  store i64 %op6019, ptr %slot1110, align 8
  %v6020 = load i64, ptr %slot1108, align 8
  %p6021 = inttoptr i64 %v6020 to ptr
  %rgep6022 = getelementptr i8, ptr %p6021, i64 -16
  %ld6023 = load i64, ptr %rgep6022, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6023, ptr %slot1111, align 8
  %v6024 = load i64, ptr %slot1111, align 8
  %op6025 = and i64 %v6024, 4611686018427387906
  store i64 %op6025, ptr %slot1112, align 8
  %v6026 = load i64, ptr %slot1112, align 8
  %cmp6027 = icmp ne i64 %v6026, 0
  %cv6028 = zext i1 %cmp6027 to i32
  store i32 %cv6028, ptr %slot1113, align 8
  %v6029 = load i32, ptr %slot1113, align 8
  %cv6030 = zext i32 %v6029 to i64
  %cond6031 = icmp ne i64 %cv6030, 0
  br i1 %cond6031, label %bb_rcgclear1572, label %bb_rcgcounted1572
bb_rcgcounted1572:
  %v6032 = load i64, ptr %slot1108, align 8
  %op6033 = sub i64 %v6032, 24
  store i64 %op6033, ptr %slot1114, align 8
  %v6034 = load i64, ptr %slot1108, align 8
  %p6035 = inttoptr i64 %v6034 to ptr
  %rgep6036 = getelementptr i8, ptr %p6035, i64 -24
  %ld6037 = load i64, ptr %rgep6036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6037, ptr %slot1115, align 8
  %v6038 = load i64, ptr %slot1115, align 8
  %op6039 = sub i64 %v6038, 1
  store i64 %op6039, ptr %slot1116, align 8
  %v6040 = load i64, ptr %slot1116, align 8
  %cmp6041 = icmp eq i64 %v6040, 0
  %cv6042 = zext i1 %cmp6041 to i32
  store i32 %cv6042, ptr %slot1117, align 8
  %v6043 = load i32, ptr %slot1117, align 8
  %cv6044 = zext i32 %v6043 to i64
  %cond6045 = icmp ne i64 %cv6044, 0
  br i1 %cond6045, label %bb_rcglast1572, label %bb_rcgdec1572
bb_rcglast1572:
  %v6046 = load i64, ptr %slot1108, align 8
  %op6047 = sub i64 %v6046, 32
  store i64 %op6047, ptr %slot1118, align 8
  %v6048 = load i64, ptr %slot1108, align 8
  %p6049 = inttoptr i64 %v6048 to ptr
  %rgep6050 = getelementptr i8, ptr %p6049, i64 -32
  %ld6051 = load i64, ptr %rgep6050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6051, ptr %slot1119, align 8
  %v6052 = load i64, ptr %slot1119, align 8
  %cmp6053 = icmp ne i64 %v6052, 0
  %cv6054 = zext i1 %cmp6053 to i32
  store i32 %cv6054, ptr %slot1120, align 8
  %v6055 = load i32, ptr %slot1120, align 8
  %cv6056 = zext i32 %v6055 to i64
  %cond6057 = icmp ne i64 %cv6056, 0
  br i1 %cond6057, label %bb_rcgdec1572, label %bb_rcgslow1572
bb_rcgslow1572:
  %v6058 = load i64, ptr %slot1107, align 8
  %v6059 = load i64, ptr %slot1104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6058, i64 %v6059) nomerge, !dbg !192
  br label %bb_rcgdone1572
bb_rcgdec1572:
  %v6060 = load i64, ptr %slot1116, align 8
  %v6061 = load i64, ptr %slot1108, align 8
  %p6062 = inttoptr i64 %v6061 to ptr
  %rgep6063 = getelementptr i8, ptr %p6062, i64 -24
  store i64 %v6060, ptr %rgep6063, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1572
bb_rcgclear1572:
  %v6064 = load i64, ptr %slot1104, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  store i64 0, ptr %p6065, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1572
bb_rcgdone1572:
  br label %bb_rcslotdone1556
bb_rcslotowner1556:
  %v6066 = load i64, ptr %slot56, align 8
  store i64 %v6066, ptr %slot1121, align 8
  %v6067 = load i64, ptr %slot1104, align 8
  %p6068 = inttoptr i64 %v6067 to ptr
  %ld6069 = load i64, ptr %p6068, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6069, ptr %slot1122, align 8
  %v6070 = load i64, ptr %slot1122, align 8
  %cmp6071 = icmp ne i64 %v6070, 0
  %cv6072 = zext i1 %cmp6071 to i32
  store i32 %cv6072, ptr %slot1123, align 8
  %v6073 = load i32, ptr %slot1123, align 8
  %cv6074 = zext i32 %v6073 to i64
  %cond6075 = icmp ne i64 %cv6074, 0
  br i1 %cond6075, label %bb_rcgnn1587, label %bb_rcgdone1587
bb_rcgnn1587:
  %v6076 = load i64, ptr %slot1122, align 8
  %op6077 = sub i64 %v6076, 16
  store i64 %op6077, ptr %slot1124, align 8
  %v6078 = load i64, ptr %slot1122, align 8
  %p6079 = inttoptr i64 %v6078 to ptr
  %rgep6080 = getelementptr i8, ptr %p6079, i64 -16
  %ld6081 = load i64, ptr %rgep6080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6081, ptr %slot1125, align 8
  %v6082 = load i64, ptr %slot1125, align 8
  %op6083 = and i64 %v6082, 4611686018427387906
  store i64 %op6083, ptr %slot1126, align 8
  %v6084 = load i64, ptr %slot1126, align 8
  %cmp6085 = icmp ne i64 %v6084, 0
  %cv6086 = zext i1 %cmp6085 to i32
  store i32 %cv6086, ptr %slot1127, align 8
  %v6087 = load i32, ptr %slot1127, align 8
  %cv6088 = zext i32 %v6087 to i64
  %cond6089 = icmp ne i64 %cv6088, 0
  br i1 %cond6089, label %bb_rcgclear1587, label %bb_rcgcounted1587
bb_rcgcounted1587:
  %v6090 = load i64, ptr %slot1122, align 8
  %op6091 = sub i64 %v6090, 32
  store i64 %op6091, ptr %slot1128, align 8
  %v6092 = load i64, ptr %slot1122, align 8
  %p6093 = inttoptr i64 %v6092 to ptr
  %rgep6094 = getelementptr i8, ptr %p6093, i64 -32
  %ld6095 = load i64, ptr %rgep6094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6095, ptr %slot1129, align 8
  %v6096 = load i64, ptr %slot1129, align 8
  %op6097 = sub i64 %v6096, 1
  store i64 %op6097, ptr %slot1130, align 8
  %v6098 = load i64, ptr %slot1130, align 8
  %cmp6099 = icmp eq i64 %v6098, 0
  %cv6100 = zext i1 %cmp6099 to i32
  store i32 %cv6100, ptr %slot1131, align 8
  %v6101 = load i32, ptr %slot1131, align 8
  %cv6102 = zext i32 %v6101 to i64
  %cond6103 = icmp ne i64 %cv6102, 0
  br i1 %cond6103, label %bb_rcglast1587, label %bb_rcgdec1587
bb_rcglast1587:
  %v6104 = load i64, ptr %slot1122, align 8
  %op6105 = sub i64 %v6104, 24
  store i64 %op6105, ptr %slot1132, align 8
  %v6106 = load i64, ptr %slot1122, align 8
  %p6107 = inttoptr i64 %v6106 to ptr
  %rgep6108 = getelementptr i8, ptr %p6107, i64 -24
  %ld6109 = load i64, ptr %rgep6108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6109, ptr %slot1133, align 8
  %v6110 = load i64, ptr %slot1133, align 8
  %cmp6111 = icmp ne i64 %v6110, 0
  %cv6112 = zext i1 %cmp6111 to i32
  store i32 %cv6112, ptr %slot1134, align 8
  %v6113 = load i32, ptr %slot1134, align 8
  %cv6114 = zext i32 %v6113 to i64
  %cond6115 = icmp ne i64 %cv6114, 0
  br i1 %cond6115, label %bb_rcgdec1587, label %bb_rcgslow1587
bb_rcgslow1587:
  %v6116 = load i64, ptr %slot1121, align 8
  %v6117 = load i64, ptr %slot1104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6116, i64 %v6117) nomerge, !dbg !192
  br label %bb_rcgdone1587
bb_rcgdec1587:
  %v6118 = load i64, ptr %slot1130, align 8
  %v6119 = load i64, ptr %slot1122, align 8
  %p6120 = inttoptr i64 %v6119 to ptr
  %rgep6121 = getelementptr i8, ptr %p6120, i64 -32
  store i64 %v6118, ptr %rgep6121, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1587
bb_rcgclear1587:
  %v6122 = load i64, ptr %slot1104, align 8
  %p6123 = inttoptr i64 %v6122 to ptr
  store i64 0, ptr %p6123, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1587
bb_rcgdone1587:
  br label %bb_rcslotdone1556
bb_rcslotdone1556:
  br label %bb_i103
bb_i103:
  %v6124 = load i64, ptr %slot29, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  %ld6126 = load i64, ptr %p6125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6126, ptr %slot1135, align 8
  %v6127 = load i64, ptr %slot1135, align 8
  %v6128 = load i64, ptr %slot44, align 8
  %p6129 = inttoptr i64 %v6128 to ptr
  store i64 %v6127, ptr %p6129, align 8, !alias.scope !3, !noalias !4
  %p6130 = inttoptr i64 ptrtoint (ptr @myl_lit_691eb79e5ca7d5f18ee88dedf18c63b109441f7df093eeabb8a7767e58e51cad to i64) to ptr
  %ld6131 = load i64, ptr %p6130, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6131, ptr %slot1136, align 8
  %v6132 = load i64, ptr %slot1136, align 8
  %v6133 = load i64, ptr %slot45, align 8
  %p6134 = inttoptr i64 %v6133 to ptr
  store i64 %v6132, ptr %p6134, align 8, !alias.scope !3, !noalias !4
  %v6135 = load i64, ptr %slot45, align 8
  %p6136 = inttoptr i64 %v6135 to ptr
  %ld6137 = load i64, ptr %p6136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6137, ptr %slot1137, align 8
  %v6138 = load i64, ptr %slot1137, align 8
  %v6139 = load i64, ptr %slot22, align 8
  %p6140 = inttoptr i64 %v6139 to ptr
  store i64 %v6138, ptr %p6140, align 8, !alias.scope !3, !noalias !4
  %v6141 = load i64, ptr %slot22, align 8
  store i64 %v6141, ptr %slot1138, align 8
  %v6142 = load i64, ptr %slot23, align 8
  store i64 %v6142, ptr %slot1139, align 8
  %v6143 = load i64, ptr %slot1138, align 8
  %v6144 = load i64, ptr %slot1139, align 8
  %p6145 = inttoptr i64 %v6143 to ptr
  %p6146 = inttoptr i64 %v6144 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6146, ptr %p6145, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6147 = load i64, ptr %slot17, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  store i32 2, ptr %p6148, align 4, !alias.scope !3, !noalias !4
  %v6149 = load i64, ptr %slot16, align 8
  %p6150 = inttoptr i64 %v6149 to ptr
  store i32 1, ptr %p6150, align 4, !alias.scope !3, !noalias !4
  %v6151 = load i64, ptr %slot20, align 8
  store i64 %v6151, ptr %slot1140, align 8
  %v6152 = load i64, ptr %slot23, align 8
  store i64 %v6152, ptr %slot1141, align 8
  %v6153 = load i64, ptr %slot1141, align 8
  %v6154 = load i64, ptr %slot1140, align 8
  %p6155 = inttoptr i64 %v6153 to ptr
  %p6156 = inttoptr i64 %v6154 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6156, ptr %p6155, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6157 = load i64, ptr %slot15, align 8
  %p6158 = inttoptr i64 %v6157 to ptr
  store i32 2, ptr %p6158, align 4, !alias.scope !3, !noalias !4
  %v6159 = load i64, ptr %slot17, align 8
  %p6160 = inttoptr i64 %v6159 to ptr
  %ld6161 = load i32, ptr %p6160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6161, ptr %slot1142, align 8
  %v6162 = load i32, ptr %slot1142, align 8
  %v6163 = load i64, ptr %slot15, align 8
  %p6164 = inttoptr i64 %v6163 to ptr
  store i32 %v6162, ptr %p6164, align 4, !alias.scope !3, !noalias !4
  %v6165 = load i64, ptr %slot16, align 8
  %p6166 = inttoptr i64 %v6165 to ptr
  store i32 0, ptr %p6166, align 4, !alias.scope !3, !noalias !4
  %v6167 = load i64, ptr %slot14, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  store i32 1, ptr %p6168, align 4, !alias.scope !3, !noalias !4
  %v6169 = load i64, ptr %slot1140, align 8
  %p6170 = inttoptr i64 %v6169 to ptr
  %ld6171 = load i64, ptr %p6170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6171, ptr %slot1143, align 8
  %v6172 = load i64, ptr %slot1143, align 8
  %v6173 = load i64, ptr %slot45, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  store i64 %v6172, ptr %p6174, align 8, !alias.scope !3, !noalias !4
  %v6175 = load i64, ptr %slot44, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  %ld6177 = load i64, ptr %p6176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6177, ptr %slot1144, align 8
  %v6178 = load i64, ptr %slot45, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i64, ptr %p6179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6180, ptr %slot1145, align 8
  %v6181 = load i64, ptr %slot1, align 8
  %v6182 = load i64, ptr %slot1144, align 8
  %v6183 = load i64, ptr %slot1145, align 8
  %call6184 = call i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64 %v6181, i64 %v6182, i64 %v6183) nomerge, !dbg !194
  store i64 %call6184, ptr %slot1146, align 8
  %v6185 = load i64, ptr %slot1146, align 8
  %v6186 = load i64, ptr %slot44, align 8
  %p6187 = inttoptr i64 %v6186 to ptr
  store i64 %v6185, ptr %p6187, align 8, !alias.scope !3, !noalias !4
  %v6188 = load i64, ptr %slot12, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %ld6190 = load i32, ptr %p6189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6190, ptr %slot1147, align 8
  %v6191 = load i32, ptr %slot1147, align 8
  %cv6192 = zext i32 %v6191 to i64
  %cond6193 = icmp ne i64 %cv6192, 0
  br i1 %cond6193, label %bb_rcslotdrop1613, label %bb_rcslotdone1613
bb_rcslotdrop1613:
  %v6194 = load i64, ptr %slot12, align 8
  %p6195 = inttoptr i64 %v6194 to ptr
  store i32 0, ptr %p6195, align 4, !alias.scope !3, !noalias !4
  %v6196 = load i64, ptr %slot19, align 8
  store i64 %v6196, ptr %slot1148, align 8
  %v6197 = load i64, ptr %slot13, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  %ld6199 = load i32, ptr %p6198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6199, ptr %slot1149, align 8
  %v6200 = load i32, ptr %slot1149, align 8
  %op6201 = and i32 %v6200, 28
  store i32 %op6201, ptr %slot1150, align 8
  %v6202 = load i32, ptr %slot1150, align 8
  %cv6203 = zext i32 %v6202 to i64
  %cond6204 = icmp ne i64 %cv6203, 0
  br i1 %cond6204, label %bb_rcslotrole1613, label %bb_rcslotowner1613
bb_rcslotrole1613:
  %v6205 = load i64, ptr %slot56, align 8
  store i64 %v6205, ptr %slot1151, align 8
  %v6206 = load i64, ptr %slot1151, align 8
  %v6207 = load i64, ptr %slot1148, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6206, i64 %v6207) nomerge, !dbg !194
  br label %bb_rcslotdone1613
bb_rcslotowner1613:
  %v6208 = load i64, ptr %slot56, align 8
  store i64 %v6208, ptr %slot1152, align 8
  %v6209 = load i64, ptr %slot1152, align 8
  %v6210 = load i64, ptr %slot1148, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6209, i64 %v6210) nomerge, !dbg !194
  br label %bb_rcslotdone1613
bb_rcslotdone1613:
  %v6211 = load i64, ptr %slot14, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %ld6213 = load i32, ptr %p6212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6213, ptr %slot1153, align 8
  %v6214 = load i32, ptr %slot1153, align 8
  %cv6215 = zext i32 %v6214 to i64
  %cond6216 = icmp ne i64 %cv6215, 0
  br i1 %cond6216, label %bb_rcslotdrop1622, label %bb_rcslotdone1622
bb_rcslotdrop1622:
  %v6217 = load i64, ptr %slot14, align 8
  %p6218 = inttoptr i64 %v6217 to ptr
  store i32 0, ptr %p6218, align 4, !alias.scope !3, !noalias !4
  %v6219 = load i64, ptr %slot20, align 8
  store i64 %v6219, ptr %slot1154, align 8
  %v6220 = load i64, ptr %slot15, align 8
  %p6221 = inttoptr i64 %v6220 to ptr
  %ld6222 = load i32, ptr %p6221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6222, ptr %slot1155, align 8
  %v6223 = load i32, ptr %slot1155, align 8
  %op6224 = and i32 %v6223, 28
  store i32 %op6224, ptr %slot1156, align 8
  %v6225 = load i32, ptr %slot1156, align 8
  %cv6226 = zext i32 %v6225 to i64
  %cond6227 = icmp ne i64 %cv6226, 0
  br i1 %cond6227, label %bb_rcslotrole1622, label %bb_rcslotowner1622
bb_rcslotrole1622:
  %v6228 = load i64, ptr %slot56, align 8
  store i64 %v6228, ptr %slot1157, align 8
  %v6229 = load i64, ptr %slot1154, align 8
  %p6230 = inttoptr i64 %v6229 to ptr
  %ld6231 = load i64, ptr %p6230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6231, ptr %slot1158, align 8
  %v6232 = load i64, ptr %slot1158, align 8
  %cmp6233 = icmp ne i64 %v6232, 0
  %cv6234 = zext i1 %cmp6233 to i32
  store i32 %cv6234, ptr %slot1159, align 8
  %v6235 = load i32, ptr %slot1159, align 8
  %cv6236 = zext i32 %v6235 to i64
  %cond6237 = icmp ne i64 %cv6236, 0
  br i1 %cond6237, label %bb_rcgnn1638, label %bb_rcgdone1638
bb_rcgnn1638:
  %v6238 = load i64, ptr %slot1158, align 8
  %op6239 = sub i64 %v6238, 16
  store i64 %op6239, ptr %slot1160, align 8
  %v6240 = load i64, ptr %slot1158, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %rgep6242 = getelementptr i8, ptr %p6241, i64 -16
  %ld6243 = load i64, ptr %rgep6242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6243, ptr %slot1161, align 8
  %v6244 = load i64, ptr %slot1161, align 8
  %op6245 = and i64 %v6244, 4611686018427387906
  store i64 %op6245, ptr %slot1162, align 8
  %v6246 = load i64, ptr %slot1162, align 8
  %cmp6247 = icmp ne i64 %v6246, 0
  %cv6248 = zext i1 %cmp6247 to i32
  store i32 %cv6248, ptr %slot1163, align 8
  %v6249 = load i32, ptr %slot1163, align 8
  %cv6250 = zext i32 %v6249 to i64
  %cond6251 = icmp ne i64 %cv6250, 0
  br i1 %cond6251, label %bb_rcgclear1638, label %bb_rcgcounted1638
bb_rcgcounted1638:
  %v6252 = load i64, ptr %slot1158, align 8
  %op6253 = sub i64 %v6252, 24
  store i64 %op6253, ptr %slot1164, align 8
  %v6254 = load i64, ptr %slot1158, align 8
  %p6255 = inttoptr i64 %v6254 to ptr
  %rgep6256 = getelementptr i8, ptr %p6255, i64 -24
  %ld6257 = load i64, ptr %rgep6256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6257, ptr %slot1165, align 8
  %v6258 = load i64, ptr %slot1165, align 8
  %op6259 = sub i64 %v6258, 1
  store i64 %op6259, ptr %slot1166, align 8
  %v6260 = load i64, ptr %slot1166, align 8
  %cmp6261 = icmp eq i64 %v6260, 0
  %cv6262 = zext i1 %cmp6261 to i32
  store i32 %cv6262, ptr %slot1167, align 8
  %v6263 = load i32, ptr %slot1167, align 8
  %cv6264 = zext i32 %v6263 to i64
  %cond6265 = icmp ne i64 %cv6264, 0
  br i1 %cond6265, label %bb_rcglast1638, label %bb_rcgdec1638
bb_rcglast1638:
  %v6266 = load i64, ptr %slot1158, align 8
  %op6267 = sub i64 %v6266, 32
  store i64 %op6267, ptr %slot1168, align 8
  %v6268 = load i64, ptr %slot1158, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  %rgep6270 = getelementptr i8, ptr %p6269, i64 -32
  %ld6271 = load i64, ptr %rgep6270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6271, ptr %slot1169, align 8
  %v6272 = load i64, ptr %slot1169, align 8
  %cmp6273 = icmp ne i64 %v6272, 0
  %cv6274 = zext i1 %cmp6273 to i32
  store i32 %cv6274, ptr %slot1170, align 8
  %v6275 = load i32, ptr %slot1170, align 8
  %cv6276 = zext i32 %v6275 to i64
  %cond6277 = icmp ne i64 %cv6276, 0
  br i1 %cond6277, label %bb_rcgdec1638, label %bb_rcgslow1638
bb_rcgslow1638:
  %v6278 = load i64, ptr %slot1157, align 8
  %v6279 = load i64, ptr %slot1154, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6278, i64 %v6279) nomerge, !dbg !194
  br label %bb_rcgdone1638
bb_rcgdec1638:
  %v6280 = load i64, ptr %slot1166, align 8
  %v6281 = load i64, ptr %slot1158, align 8
  %p6282 = inttoptr i64 %v6281 to ptr
  %rgep6283 = getelementptr i8, ptr %p6282, i64 -24
  store i64 %v6280, ptr %rgep6283, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1638
bb_rcgclear1638:
  %v6284 = load i64, ptr %slot1154, align 8
  %p6285 = inttoptr i64 %v6284 to ptr
  store i64 0, ptr %p6285, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1638
bb_rcgdone1638:
  br label %bb_rcslotdone1622
bb_rcslotowner1622:
  %v6286 = load i64, ptr %slot56, align 8
  store i64 %v6286, ptr %slot1171, align 8
  %v6287 = load i64, ptr %slot1154, align 8
  %p6288 = inttoptr i64 %v6287 to ptr
  %ld6289 = load i64, ptr %p6288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6289, ptr %slot1172, align 8
  %v6290 = load i64, ptr %slot1172, align 8
  %cmp6291 = icmp ne i64 %v6290, 0
  %cv6292 = zext i1 %cmp6291 to i32
  store i32 %cv6292, ptr %slot1173, align 8
  %v6293 = load i32, ptr %slot1173, align 8
  %cv6294 = zext i32 %v6293 to i64
  %cond6295 = icmp ne i64 %cv6294, 0
  br i1 %cond6295, label %bb_rcgnn1653, label %bb_rcgdone1653
bb_rcgnn1653:
  %v6296 = load i64, ptr %slot1172, align 8
  %op6297 = sub i64 %v6296, 16
  store i64 %op6297, ptr %slot1174, align 8
  %v6298 = load i64, ptr %slot1172, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %rgep6300 = getelementptr i8, ptr %p6299, i64 -16
  %ld6301 = load i64, ptr %rgep6300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6301, ptr %slot1175, align 8
  %v6302 = load i64, ptr %slot1175, align 8
  %op6303 = and i64 %v6302, 4611686018427387906
  store i64 %op6303, ptr %slot1176, align 8
  %v6304 = load i64, ptr %slot1176, align 8
  %cmp6305 = icmp ne i64 %v6304, 0
  %cv6306 = zext i1 %cmp6305 to i32
  store i32 %cv6306, ptr %slot1177, align 8
  %v6307 = load i32, ptr %slot1177, align 8
  %cv6308 = zext i32 %v6307 to i64
  %cond6309 = icmp ne i64 %cv6308, 0
  br i1 %cond6309, label %bb_rcgclear1653, label %bb_rcgcounted1653
bb_rcgcounted1653:
  %v6310 = load i64, ptr %slot1172, align 8
  %op6311 = sub i64 %v6310, 32
  store i64 %op6311, ptr %slot1178, align 8
  %v6312 = load i64, ptr %slot1172, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  %rgep6314 = getelementptr i8, ptr %p6313, i64 -32
  %ld6315 = load i64, ptr %rgep6314, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6315, ptr %slot1179, align 8
  %v6316 = load i64, ptr %slot1179, align 8
  %op6317 = sub i64 %v6316, 1
  store i64 %op6317, ptr %slot1180, align 8
  %v6318 = load i64, ptr %slot1180, align 8
  %cmp6319 = icmp eq i64 %v6318, 0
  %cv6320 = zext i1 %cmp6319 to i32
  store i32 %cv6320, ptr %slot1181, align 8
  %v6321 = load i32, ptr %slot1181, align 8
  %cv6322 = zext i32 %v6321 to i64
  %cond6323 = icmp ne i64 %cv6322, 0
  br i1 %cond6323, label %bb_rcglast1653, label %bb_rcgdec1653
bb_rcglast1653:
  %v6324 = load i64, ptr %slot1172, align 8
  %op6325 = sub i64 %v6324, 24
  store i64 %op6325, ptr %slot1182, align 8
  %v6326 = load i64, ptr %slot1172, align 8
  %p6327 = inttoptr i64 %v6326 to ptr
  %rgep6328 = getelementptr i8, ptr %p6327, i64 -24
  %ld6329 = load i64, ptr %rgep6328, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6329, ptr %slot1183, align 8
  %v6330 = load i64, ptr %slot1183, align 8
  %cmp6331 = icmp ne i64 %v6330, 0
  %cv6332 = zext i1 %cmp6331 to i32
  store i32 %cv6332, ptr %slot1184, align 8
  %v6333 = load i32, ptr %slot1184, align 8
  %cv6334 = zext i32 %v6333 to i64
  %cond6335 = icmp ne i64 %cv6334, 0
  br i1 %cond6335, label %bb_rcgdec1653, label %bb_rcgslow1653
bb_rcgslow1653:
  %v6336 = load i64, ptr %slot1171, align 8
  %v6337 = load i64, ptr %slot1154, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6336, i64 %v6337) nomerge, !dbg !194
  br label %bb_rcgdone1653
bb_rcgdec1653:
  %v6338 = load i64, ptr %slot1180, align 8
  %v6339 = load i64, ptr %slot1172, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %rgep6341 = getelementptr i8, ptr %p6340, i64 -32
  store i64 %v6338, ptr %rgep6341, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1653
bb_rcgclear1653:
  %v6342 = load i64, ptr %slot1154, align 8
  %p6343 = inttoptr i64 %v6342 to ptr
  store i64 0, ptr %p6343, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1653
bb_rcgdone1653:
  br label %bb_rcslotdone1622
bb_rcslotdone1622:
  %v6344 = load i64, ptr %slot44, align 8
  %p6345 = inttoptr i64 %v6344 to ptr
  %ld6346 = load i64, ptr %p6345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6346, ptr %slot1185, align 8
  %v6347 = load i64, ptr %slot1185, align 8
  %v6348 = load i64, ptr %slot43, align 8
  %p6349 = inttoptr i64 %v6348 to ptr
  store i64 %v6347, ptr %p6349, align 8, !alias.scope !3, !noalias !4
  %v6350 = load i64, ptr %slot29, align 8
  %p6351 = inttoptr i64 %v6350 to ptr
  %ld6352 = load i64, ptr %p6351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6352, ptr %slot1186, align 8
  %v6353 = load i64, ptr %slot1186, align 8
  %v6354 = load i64, ptr %slot44, align 8
  %p6355 = inttoptr i64 %v6354 to ptr
  store i64 %v6353, ptr %p6355, align 8, !alias.scope !3, !noalias !4
  %v6356 = load i64, ptr %slot43, align 8
  %p6357 = inttoptr i64 %v6356 to ptr
  %ld6358 = load i64, ptr %p6357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6358, ptr %slot1187, align 8
  %v6359 = load i64, ptr %slot1187, align 8
  %v6360 = load i64, ptr %slot45, align 8
  %p6361 = inttoptr i64 %v6360 to ptr
  store i64 %v6359, ptr %p6361, align 8, !alias.scope !3, !noalias !4
  %v6362 = load i64, ptr %slot44, align 8
  %p6363 = inttoptr i64 %v6362 to ptr
  %ld6364 = load i64, ptr %p6363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6364, ptr %slot1188, align 8
  %v6365 = load i64, ptr %slot45, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  %ld6367 = load i64, ptr %p6366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6367, ptr %slot1189, align 8
  %v6368 = load i64, ptr %slot1, align 8
  %v6369 = load i64, ptr %slot1188, align 8
  %v6370 = load i64, ptr %slot1189, align 8
  %call6371 = call i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64 %v6368, i64 %v6369, i64 %v6370) nomerge, !dbg !196
  store i64 %call6371, ptr %slot1190, align 8
  %v6372 = load i64, ptr %slot1190, align 8
  %v6373 = load i64, ptr %slot44, align 8
  %p6374 = inttoptr i64 %v6373 to ptr
  store i64 %v6372, ptr %p6374, align 8, !alias.scope !3, !noalias !4
  %v6375 = load i64, ptr %slot12, align 8
  %p6376 = inttoptr i64 %v6375 to ptr
  %ld6377 = load i32, ptr %p6376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6377, ptr %slot1191, align 8
  %v6378 = load i32, ptr %slot1191, align 8
  %cv6379 = zext i32 %v6378 to i64
  %cond6380 = icmp ne i64 %cv6379, 0
  br i1 %cond6380, label %bb_rcslotdrop1665, label %bb_rcslotdone1665
bb_rcslotdrop1665:
  %v6381 = load i64, ptr %slot12, align 8
  %p6382 = inttoptr i64 %v6381 to ptr
  store i32 0, ptr %p6382, align 4, !alias.scope !3, !noalias !4
  %v6383 = load i64, ptr %slot19, align 8
  store i64 %v6383, ptr %slot1192, align 8
  %v6384 = load i64, ptr %slot13, align 8
  %p6385 = inttoptr i64 %v6384 to ptr
  %ld6386 = load i32, ptr %p6385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6386, ptr %slot1193, align 8
  %v6387 = load i32, ptr %slot1193, align 8
  %op6388 = and i32 %v6387, 28
  store i32 %op6388, ptr %slot1194, align 8
  %v6389 = load i32, ptr %slot1194, align 8
  %cv6390 = zext i32 %v6389 to i64
  %cond6391 = icmp ne i64 %cv6390, 0
  br i1 %cond6391, label %bb_rcslotrole1665, label %bb_rcslotowner1665
bb_rcslotrole1665:
  %v6392 = load i64, ptr %slot56, align 8
  store i64 %v6392, ptr %slot1195, align 8
  %v6393 = load i64, ptr %slot1195, align 8
  %v6394 = load i64, ptr %slot1192, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6393, i64 %v6394) nomerge, !dbg !196
  br label %bb_rcslotdone1665
bb_rcslotowner1665:
  %v6395 = load i64, ptr %slot56, align 8
  store i64 %v6395, ptr %slot1196, align 8
  %v6396 = load i64, ptr %slot1196, align 8
  %v6397 = load i64, ptr %slot1192, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6396, i64 %v6397) nomerge, !dbg !196
  br label %bb_rcslotdone1665
bb_rcslotdone1665:
  %v6398 = load i64, ptr %slot44, align 8
  %p6399 = inttoptr i64 %v6398 to ptr
  store i64 0, ptr %p6399, align 8, !alias.scope !3, !noalias !4
  %v6400 = load i64, ptr %slot44, align 8
  %p6401 = inttoptr i64 %v6400 to ptr
  %ld6402 = load i64, ptr %p6401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6402, ptr %slot1197, align 8
  %v6403 = load i64, ptr %slot24, align 8
  %p6405 = inttoptr i64 %v6403 to ptr
  %gep6406 = getelementptr i8, ptr %p6405, i64 24
  %op6404 = ptrtoint ptr %gep6406 to i64
  store i64 %op6404, ptr %slot1198, align 8
  %v6407 = load i64, ptr %slot1198, align 8
  %p6408 = inttoptr i64 %v6407 to ptr
  %ld6409 = load i32, ptr %p6408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6409, ptr %slot1199, align 8
  %v6410 = load i64, ptr %slot26, align 8
  %p6412 = inttoptr i64 %v6410 to ptr
  %gep6413 = getelementptr i8, ptr %p6412, i64 24
  %op6411 = ptrtoint ptr %gep6413 to i64
  store i64 %op6411, ptr %slot1200, align 8
  %v6414 = load i64, ptr %slot1200, align 8
  %p6415 = inttoptr i64 %v6414 to ptr
  %ld6416 = load i32, ptr %p6415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6416, ptr %slot1201, align 8
  %v6417 = load i32, ptr %slot1199, align 8
  %v6418 = load i32, ptr %slot1201, align 8
  %op6419 = or i32 %v6417, %v6418
  store i32 %op6419, ptr %slot1202, align 8
  %v6420 = load i32, ptr %slot1202, align 8
  %cv6421 = zext i32 %v6420 to i64
  %cond6422 = icmp ne i64 %cv6421, 0
  br i1 %cond6422, label %bb_rcscopesopen1678, label %bb_rcscopesclosed1678
bb_rcscopesopen1678:
  %v6423 = load i64, ptr %slot28, align 8
  %p6425 = inttoptr i64 %v6423 to ptr
  %gep6426 = getelementptr i8, ptr %p6425, i64 0
  %op6424 = ptrtoint ptr %gep6426 to i64
  store i64 %op6424, ptr %slot1203, align 8
  %v6427 = load i64, ptr %slot24, align 8
  %v6428 = load i64, ptr %slot1203, align 8
  %p6429 = inttoptr i64 %v6428 to ptr
  store i64 %v6427, ptr %p6429, align 8, !alias.scope !3, !noalias !4
  %v6430 = load i64, ptr %slot28, align 8
  %p6432 = inttoptr i64 %v6430 to ptr
  %gep6433 = getelementptr i8, ptr %p6432, i64 8
  %op6431 = ptrtoint ptr %gep6433 to i64
  store i64 %op6431, ptr %slot1204, align 8
  %v6434 = load i64, ptr %slot26, align 8
  %v6435 = load i64, ptr %slot1204, align 8
  %p6436 = inttoptr i64 %v6435 to ptr
  store i64 %v6434, ptr %p6436, align 8, !alias.scope !3, !noalias !4
  %v6437 = load i64, ptr %slot1, align 8
  %p6438 = inttoptr i64 %v6437 to ptr
  %v6439 = load i64, ptr %slot28, align 8
  %p6440 = inttoptr i64 %v6439 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p6438, ptr %p6440, i64 2) nomerge, !dbg !198
  br label %bb_rcscopesclosed1678
bb_rcscopesclosed1678:
  %v6441 = load i64, ptr %slot12, align 8
  %p6442 = inttoptr i64 %v6441 to ptr
  %ld6443 = load i32, ptr %p6442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6443, ptr %slot1205, align 8
  %v6444 = load i32, ptr %slot1205, align 8
  %cv6445 = zext i32 %v6444 to i64
  %cond6446 = icmp ne i64 %cv6445, 0
  br i1 %cond6446, label %bb_rcslotdrop1683, label %bb_rcslotdone1683
bb_rcslotdrop1683:
  %v6447 = load i64, ptr %slot12, align 8
  %p6448 = inttoptr i64 %v6447 to ptr
  store i32 0, ptr %p6448, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1683
bb_rcslotdone1683:
  %v6449 = load i64, ptr %slot10, align 8
  %p6450 = inttoptr i64 %v6449 to ptr
  %ld6451 = load i32, ptr %p6450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6451, ptr %slot1206, align 8
  %v6452 = load i32, ptr %slot1206, align 8
  %cv6453 = zext i32 %v6452 to i64
  %cond6454 = icmp ne i64 %cv6453, 0
  br i1 %cond6454, label %bb_rcslotdrop1686, label %bb_rcslotdone1686
bb_rcslotdrop1686:
  %v6455 = load i64, ptr %slot10, align 8
  %p6456 = inttoptr i64 %v6455 to ptr
  store i32 0, ptr %p6456, align 4, !alias.scope !3, !noalias !4
  %v6457 = load i64, ptr %slot41, align 8
  store i64 %v6457, ptr %slot1207, align 8
  %v6458 = load i64, ptr %slot11, align 8
  %p6459 = inttoptr i64 %v6458 to ptr
  %ld6460 = load i32, ptr %p6459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6460, ptr %slot1208, align 8
  %v6461 = load i32, ptr %slot1208, align 8
  %op6462 = and i32 %v6461, 28
  store i32 %op6462, ptr %slot1209, align 8
  %v6463 = load i32, ptr %slot1209, align 8
  %cv6464 = zext i32 %v6463 to i64
  %cond6465 = icmp ne i64 %cv6464, 0
  br i1 %cond6465, label %bb_rcslotrole1686, label %bb_rcslotowner1686
bb_rcslotrole1686:
  %v6466 = load i64, ptr %slot56, align 8
  store i64 %v6466, ptr %slot1210, align 8
  %v6467 = load i64, ptr %slot1210, align 8
  %v6468 = load i64, ptr %slot1207, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v6467, i64 %v6468) nomerge, !dbg !198
  br label %bb_rcslotdone1686
bb_rcslotowner1686:
  %v6469 = load i64, ptr %slot56, align 8
  store i64 %v6469, ptr %slot1211, align 8
  %v6470 = load i64, ptr %slot1211, align 8
  %v6471 = load i64, ptr %slot1207, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v6470, i64 %v6471) nomerge, !dbg !198
  br label %bb_rcslotdone1686
bb_rcslotdone1686:
  %v6472 = load i64, ptr %slot8, align 8
  %p6473 = inttoptr i64 %v6472 to ptr
  %ld6474 = load i32, ptr %p6473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6474, ptr %slot1212, align 8
  %v6475 = load i32, ptr %slot1212, align 8
  %cv6476 = zext i32 %v6475 to i64
  %cond6477 = icmp ne i64 %cv6476, 0
  br i1 %cond6477, label %bb_rcslotdrop1732, label %bb_rcslotdone1732
bb_rcslotdrop1732:
  %v6478 = load i64, ptr %slot8, align 8
  %p6479 = inttoptr i64 %v6478 to ptr
  store i32 0, ptr %p6479, align 4, !alias.scope !3, !noalias !4
  %v6480 = load i64, ptr %slot38, align 8
  store i64 %v6480, ptr %slot1213, align 8
  %v6481 = load i64, ptr %slot9, align 8
  %p6482 = inttoptr i64 %v6481 to ptr
  %ld6483 = load i32, ptr %p6482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6483, ptr %slot1214, align 8
  %v6484 = load i32, ptr %slot1214, align 8
  %op6485 = and i32 %v6484, 28
  store i32 %op6485, ptr %slot1215, align 8
  %v6486 = load i32, ptr %slot1215, align 8
  %cv6487 = zext i32 %v6486 to i64
  %cond6488 = icmp ne i64 %cv6487, 0
  br i1 %cond6488, label %bb_rcslotrole1732, label %bb_rcslotowner1732
bb_rcslotrole1732:
  %v6489 = load i64, ptr %slot56, align 8
  store i64 %v6489, ptr %slot1216, align 8
  %v6490 = load i64, ptr %slot1216, align 8
  %v6491 = load i64, ptr %slot1213, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6490, i64 %v6491) nomerge, !dbg !198
  br label %bb_rcslotdone1732
bb_rcslotowner1732:
  %v6492 = load i64, ptr %slot56, align 8
  store i64 %v6492, ptr %slot1217, align 8
  %v6493 = load i64, ptr %slot1217, align 8
  %v6494 = load i64, ptr %slot1213, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6493, i64 %v6494) nomerge, !dbg !198
  br label %bb_rcslotdone1732
bb_rcslotdone1732:
  %v6495 = load i64, ptr %slot6, align 8
  %p6496 = inttoptr i64 %v6495 to ptr
  %ld6497 = load i32, ptr %p6496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6497, ptr %slot1218, align 8
  %v6498 = load i32, ptr %slot1218, align 8
  %cv6499 = zext i32 %v6498 to i64
  %cond6500 = icmp ne i64 %cv6499, 0
  br i1 %cond6500, label %bb_rcslotdrop1778, label %bb_rcslotdone1778
bb_rcslotdrop1778:
  %v6501 = load i64, ptr %slot6, align 8
  %p6502 = inttoptr i64 %v6501 to ptr
  store i32 0, ptr %p6502, align 4, !alias.scope !3, !noalias !4
  %v6503 = load i64, ptr %slot35, align 8
  store i64 %v6503, ptr %slot1219, align 8
  %v6504 = load i64, ptr %slot7, align 8
  %p6505 = inttoptr i64 %v6504 to ptr
  %ld6506 = load i32, ptr %p6505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6506, ptr %slot1220, align 8
  %v6507 = load i32, ptr %slot1220, align 8
  %op6508 = and i32 %v6507, 28
  store i32 %op6508, ptr %slot1221, align 8
  %v6509 = load i32, ptr %slot1221, align 8
  %cv6510 = zext i32 %v6509 to i64
  %cond6511 = icmp ne i64 %cv6510, 0
  br i1 %cond6511, label %bb_rcslotrole1778, label %bb_rcslotowner1778
bb_rcslotrole1778:
  %v6512 = load i64, ptr %slot56, align 8
  store i64 %v6512, ptr %slot1222, align 8
  %v6513 = load i64, ptr %slot1222, align 8
  %v6514 = load i64, ptr %slot1219, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6513, i64 %v6514) nomerge, !dbg !198
  br label %bb_rcslotdone1778
bb_rcslotowner1778:
  %v6515 = load i64, ptr %slot56, align 8
  store i64 %v6515, ptr %slot1223, align 8
  %v6516 = load i64, ptr %slot1223, align 8
  %v6517 = load i64, ptr %slot1219, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6516, i64 %v6517) nomerge, !dbg !198
  br label %bb_rcslotdone1778
bb_rcslotdone1778:
  %v6518 = load i64, ptr %slot4, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  %ld6520 = load i32, ptr %p6519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6520, ptr %slot1224, align 8
  %v6521 = load i32, ptr %slot1224, align 8
  %cv6522 = zext i32 %v6521 to i64
  %cond6523 = icmp ne i64 %cv6522, 0
  br i1 %cond6523, label %bb_rcslotdrop1787, label %bb_rcslotdone1787
bb_rcslotdrop1787:
  %v6524 = load i64, ptr %slot4, align 8
  %p6525 = inttoptr i64 %v6524 to ptr
  store i32 0, ptr %p6525, align 4, !alias.scope !3, !noalias !4
  %v6526 = load i64, ptr %slot34, align 8
  store i64 %v6526, ptr %slot1225, align 8
  %v6527 = load i64, ptr %slot5, align 8
  %p6528 = inttoptr i64 %v6527 to ptr
  %ld6529 = load i32, ptr %p6528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6529, ptr %slot1226, align 8
  %v6530 = load i32, ptr %slot1226, align 8
  %op6531 = and i32 %v6530, 28
  store i32 %op6531, ptr %slot1227, align 8
  %v6532 = load i32, ptr %slot1227, align 8
  %cv6533 = zext i32 %v6532 to i64
  %cond6534 = icmp ne i64 %cv6533, 0
  br i1 %cond6534, label %bb_rcslotrole1787, label %bb_rcslotowner1787
bb_rcslotrole1787:
  %v6535 = load i64, ptr %slot56, align 8
  store i64 %v6535, ptr %slot1228, align 8
  %v6536 = load i64, ptr %slot1228, align 8
  %v6537 = load i64, ptr %slot1225, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6536, i64 %v6537) nomerge, !dbg !198
  br label %bb_rcslotdone1787
bb_rcslotowner1787:
  %v6538 = load i64, ptr %slot56, align 8
  store i64 %v6538, ptr %slot1229, align 8
  %v6539 = load i64, ptr %slot1229, align 8
  %v6540 = load i64, ptr %slot1225, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6539, i64 %v6540) nomerge, !dbg !198
  br label %bb_rcslotdone1787
bb_rcslotdone1787:
  %v6541 = load i64, ptr %slot1197, align 8
  ret i64 %v6541
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_276758a43aa8aee7e44b193c95c360c200446c91bef4c30aa8ef6fba2c11b0b2 = external global i8, align 8
@myl_lit_691eb79e5ca7d5f18ee88dedf18c63b109441f7df093eeabb8a7767e58e51cad = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64, i64, i64)
declare i64 @myl_f_3f1ec2720dd948dcbb71c59f481c23096eb1de40df1330ec608e6fb0494253bd(i64, i64, i64)
declare i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_023ba44072bac8e728a471ead3ddef762ff0421f727bd9898ecc9c794e5a6c5a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_023ba44072bac8e728a471ead3ddef762ff0421f727bd9898ecc9c794e5a6c5a", linkageName: "myl_f_023ba44072bac8e728a471ead3ddef762ff0421f727bd9898ecc9c794e5a6c5a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 12334638679089799146, i64 0, !"myl_f_023ba44072bac8e728a471ead3ddef762ff0421f727bd9898ecc9c794e5a6c5a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!126 = !DILocation(line: 24, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!130 = !DILocation(line: 26, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!136 = !DILocation(line: 31, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!138 = !DILocation(line: 33, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!140 = !DILocation(line: 36, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!142 = !DILocation(line: 39, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!144 = !DILocation(line: 41, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!146 = !DILocation(line: 42, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!148 = !DILocation(line: 43, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!150 = !DILocation(line: 44, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!152 = !DILocation(line: 48, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!154 = !DILocation(line: 50, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!156 = !DILocation(line: 51, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!158 = !DILocation(line: 59, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!160 = !DILocation(line: 61, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!162 = !DILocation(line: 65, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!164 = !DILocation(line: 66, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!166 = !DILocation(line: 69, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!168 = !DILocation(line: 70, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!170 = !DILocation(line: 71, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!172 = !DILocation(line: 72, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!174 = !DILocation(line: 74, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!176 = !DILocation(line: 75, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!178 = !DILocation(line: 76, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!180 = !DILocation(line: 78, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!182 = !DILocation(line: 85, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!184 = !DILocation(line: 87, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!186 = !DILocation(line: 92, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647295)
!188 = !DILocation(line: 95, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!190 = !DILocation(line: 96, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!192 = !DILocation(line: 102, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!194 = !DILocation(line: 106, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!196 = !DILocation(line: 110, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647439)
!198 = !DILocation(line: 113, column: 0, scope: !199)
