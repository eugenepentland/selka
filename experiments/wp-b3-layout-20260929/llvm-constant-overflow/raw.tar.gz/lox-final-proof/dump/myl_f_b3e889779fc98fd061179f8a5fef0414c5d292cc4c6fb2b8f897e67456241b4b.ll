target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %callresult44 = alloca [24 x i8], align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v362 = load i64, ptr %slot1, align 8
  %op363 = add i64 %v362, 32
  store i64 %op363, ptr %slot4, align 8
  %mem364 = alloca i8, i64 8, align 8
  %ptr365 = ptrtoint ptr %mem364 to i64
  store i64 %ptr365, ptr %slot5, align 8
  %mem366 = alloca i8, i64 8, align 8
  %ptr367 = ptrtoint ptr %mem366 to i64
  store i64 %ptr367, ptr %slot6, align 8
  %mem368 = alloca i8, i64 8, align 8
  %ptr369 = ptrtoint ptr %mem368 to i64
  store i64 %ptr369, ptr %slot7, align 8
  %mem370 = alloca i8, i64 8, align 8
  %ptr371 = ptrtoint ptr %mem370 to i64
  store i64 %ptr371, ptr %slot8, align 8
  %mem372 = alloca i8, i64 8, align 8
  %ptr373 = ptrtoint ptr %mem372 to i64
  store i64 %ptr373, ptr %slot9, align 8
  %mem374 = alloca i8, i64 8, align 8
  %ptr375 = ptrtoint ptr %mem374 to i64
  store i64 %ptr375, ptr %slot10, align 8
  %mem376 = alloca i8, i64 8, align 8
  %ptr377 = ptrtoint ptr %mem376 to i64
  store i64 %ptr377, ptr %slot11, align 8
  %mem378 = alloca i8, i64 8, align 8
  %ptr379 = ptrtoint ptr %mem378 to i64
  store i64 %ptr379, ptr %slot12, align 8
  %mem380 = alloca i8, i64 392, align 8
  %ptr381 = ptrtoint ptr %mem380 to i64
  store i64 %ptr381, ptr %slot13, align 8
  %mem382 = alloca i8, i64 8, align 8
  %ptr383 = ptrtoint ptr %mem382 to i64
  store i64 %ptr383, ptr %slot14, align 8
  %mem384 = alloca i8, i64 8, align 8
  %ptr385 = ptrtoint ptr %mem384 to i64
  store i64 %ptr385, ptr %slot15, align 8
  %mem386 = alloca i8, i64 8, align 8
  %ptr387 = ptrtoint ptr %mem386 to i64
  store i64 %ptr387, ptr %slot16, align 8
  %mem388 = alloca i8, i64 392, align 8
  %ptr389 = ptrtoint ptr %mem388 to i64
  store i64 %ptr389, ptr %slot17, align 8
  %mem390 = alloca i8, i64 8, align 8
  %ptr391 = ptrtoint ptr %mem390 to i64
  store i64 %ptr391, ptr %slot18, align 8
  %mem392 = alloca i8, i64 8, align 8
  %ptr393 = ptrtoint ptr %mem392 to i64
  store i64 %ptr393, ptr %slot19, align 8
  %mem394 = alloca i8, i64 8, align 8
  %ptr395 = ptrtoint ptr %mem394 to i64
  store i64 %ptr395, ptr %slot20, align 8
  %mem396 = alloca i8, i64 8, align 8
  %ptr397 = ptrtoint ptr %mem396 to i64
  store i64 %ptr397, ptr %slot21, align 8
  %mem398 = alloca i8, i64 8, align 8
  %ptr399 = ptrtoint ptr %mem398 to i64
  store i64 %ptr399, ptr %slot22, align 8
  %mem400 = alloca i8, i64 8, align 8
  %ptr401 = ptrtoint ptr %mem400 to i64
  store i64 %ptr401, ptr %slot23, align 8
  %mem402 = alloca i8, i64 8, align 8
  %ptr403 = ptrtoint ptr %mem402 to i64
  store i64 %ptr403, ptr %slot24, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem404 = alloca i8, i64 8, align 8
  %ptr405 = ptrtoint ptr %mem404 to i64
  store i64 %ptr405, ptr %slot25, align 8
  %v406 = load i64, ptr %slot1, align 8
  %op407 = add i64 %v406, 64
  store i64 %op407, ptr %slot26, align 8
  %v408 = load i64, ptr %slot26, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !4, !noalias !3
  store i64 %ld410, ptr %slot27, align 8
  %stack411 = call ptr @llvm.stacksave()
  %stackaddr412 = ptrtoint ptr %stack411 to i64
  %v413 = load i64, ptr %slot27, align 8
  %cmp414 = icmp ult i64 %stackaddr412, %v413
  %cv415 = zext i1 %cmp414 to i64
  store i64 %cv415, ptr %slot28, align 8
  %v416 = load i64, ptr %slot28, align 8
  %cond417 = icmp ne i64 %v416, 0
  br i1 %cond417, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v418 = load i64, ptr %slot1, align 8
  %p419 = inttoptr i64 %v418 to ptr
  call void @myl_qbe_fail_frame(ptr %p419) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v420 = load i64, ptr %slot20, align 8
  %p421 = inttoptr i64 %v420 to ptr
  store i64 0, ptr %p421, align 8, !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot2, align 8
  %v423 = load i64, ptr %slot18, align 8
  %p424 = inttoptr i64 %v423 to ptr
  store i64 %v422, ptr %p424, align 8, !alias.scope !3, !noalias !4
  %v425 = load i64, ptr %slot3, align 8
  %v426 = load i64, ptr %slot19, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i64 %v425, ptr %p427, align 8, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot1, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %call430 = call ptr @myl_qbe_heap(ptr %p429) nomerge, !dbg !112
  %calladdr431 = ptrtoint ptr %call430 to i64
  store i64 %calladdr431, ptr %slot29, align 8
  %v432 = load i64, ptr %slot1, align 8
  %p433 = inttoptr i64 %v432 to ptr
  %call434 = call i64 @myl_qbe_region_mark(ptr %p433) nomerge, !dbg !112
  store i64 %call434, ptr %slot30, align 8
  %v435 = load i64, ptr %slot5, align 8
  %p436 = inttoptr i64 %v435 to ptr
  store i32 0, ptr %p436, align 4, !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot6, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 0, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot7, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i32 0, ptr %p440, align 4, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot8, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 0, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot9, align 8
  %p444 = inttoptr i64 %v443 to ptr
  store i32 0, ptr %p444, align 4, !alias.scope !3, !noalias !4
  %v445 = load i64, ptr %slot10, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i32 0, ptr %p446, align 4, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot11, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i32 0, ptr %p448, align 4, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot12, align 8
  %p450 = inttoptr i64 %v449 to ptr
  store i32 0, ptr %p450, align 4, !alias.scope !3, !noalias !4
  %v451 = load i64, ptr %slot6, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i32 2, ptr %p452, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v453 = load i64, ptr %slot18, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i64, ptr %p454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot31, align 8
  %v456 = load i64, ptr %slot31, align 8
  %v457 = load i64, ptr %slot22, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot23, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i64 27, ptr %p460, align 8, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot22, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i64, ptr %p462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld463, ptr %slot32, align 8
  %v464 = load i64, ptr %slot23, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i64, ptr %p465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld466, ptr %slot33, align 8
  %v467 = load i64, ptr %slot1, align 8
  %v468 = load i64, ptr %slot32, align 8
  %v469 = load i64, ptr %slot33, align 8
  %call470 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v467, i64 %v468, i64 %v469) nomerge, !dbg !114
  store i64 %call470, ptr %slot34, align 8
  %v471 = load i64, ptr %slot34, align 8
  %v472 = load i64, ptr %slot22, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 %v471, ptr %p473, align 8, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot7, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i32, ptr %p475, align 4, !alias.scope !3, !noalias !4
  store i32 %ld476, ptr %slot35, align 8
  %v477 = load i32, ptr %slot35, align 8
  %cv478 = zext i32 %v477 to i64
  %cond479 = icmp ne i64 %cv478, 0
  br i1 %cond479, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v480 = load i64, ptr %slot7, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 0, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot13, align 8
  store i64 %v482, ptr %slot36, align 8
  %v483 = load i64, ptr %slot8, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i32, ptr %p484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld485, ptr %slot37, align 8
  %v486 = load i32, ptr %slot37, align 8
  %op487 = and i32 %v486, 28
  store i32 %op487, ptr %slot38, align 8
  %v488 = load i32, ptr %slot38, align 8
  %cv489 = zext i32 %v488 to i64
  %cond490 = icmp ne i64 %cv489, 0
  br i1 %cond490, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v491 = load i64, ptr %slot29, align 8
  store i64 %v491, ptr %slot39, align 8
  %v492 = load i64, ptr %slot39, align 8
  %v493 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v492, i64 %v493) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v494 = load i64, ptr %slot29, align 8
  store i64 %v494, ptr %slot40, align 8
  %v495 = load i64, ptr %slot40, align 8
  %v496 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v495, i64 %v496) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v497 = load i64, ptr %slot18, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i64, ptr %p498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld499, ptr %slot41, align 8
  %v500 = load i64, ptr %slot41, align 8
  %v501 = load i64, ptr %slot22, align 8
  %p502 = inttoptr i64 %v501 to ptr
  store i64 %v500, ptr %p502, align 8, !alias.scope !3, !noalias !4
  %v503 = load i64, ptr %slot22, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %ld505 = load i64, ptr %p504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld505, ptr %slot42, align 8
  %v506 = load i64, ptr %slot1, align 8
  %v507 = load i64, ptr %slot42, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult44, i64 %v506, i64 %v507) nomerge, !dbg !116
  %addr508 = ptrtoint ptr %callresult44 to i64
  store i64 %addr508, ptr %slot43, align 8
  %v509 = load i64, ptr %slot43, align 8
  %v510 = load i64, ptr %slot22, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i64 %v509, ptr %p511, align 8, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot22, align 8
  %p513 = inttoptr i64 %v512 to ptr
  %ld514 = load i64, ptr %p513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld514, ptr %slot45, align 8
  %v515 = load i64, ptr %slot17, align 8
  store i64 %v515, ptr %slot46, align 8
  %v516 = load i64, ptr %slot45, align 8
  %v517 = load i64, ptr %slot46, align 8
  %p518 = inttoptr i64 %v516 to ptr
  %p519 = inttoptr i64 %v517 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p519, ptr %p518, i64 24, i1 false)
  %v520 = load i64, ptr %slot12, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 2, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot11, align 8
  %p523 = inttoptr i64 %v522 to ptr
  store i32 1, ptr %p523, align 4, !alias.scope !3, !noalias !4
  %v524 = load i64, ptr %slot7, align 8
  %p525 = inttoptr i64 %v524 to ptr
  %ld526 = load i32, ptr %p525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld526, ptr %slot47, align 8
  %v527 = load i32, ptr %slot47, align 8
  %cv528 = zext i32 %v527 to i64
  %cond529 = icmp ne i64 %cv528, 0
  br i1 %cond529, label %bb_rcslotdrop31, label %bb_rcslotdone31
bb_rcslotdrop31:
  %v530 = load i64, ptr %slot7, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 0, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot13, align 8
  store i64 %v532, ptr %slot48, align 8
  %v533 = load i64, ptr %slot8, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i32, ptr %p534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld535, ptr %slot49, align 8
  %v536 = load i32, ptr %slot49, align 8
  %op537 = and i32 %v536, 28
  store i32 %op537, ptr %slot50, align 8
  %v538 = load i32, ptr %slot50, align 8
  %cv539 = zext i32 %v538 to i64
  %cond540 = icmp ne i64 %cv539, 0
  br i1 %cond540, label %bb_rcslotrole31, label %bb_rcslotowner31
bb_rcslotrole31:
  %v541 = load i64, ptr %slot29, align 8
  store i64 %v541, ptr %slot51, align 8
  %v542 = load i64, ptr %slot51, align 8
  %v543 = load i64, ptr %slot48, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v542, i64 %v543) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotowner31:
  %v544 = load i64, ptr %slot29, align 8
  store i64 %v544, ptr %slot52, align 8
  %v545 = load i64, ptr %slot52, align 8
  %v546 = load i64, ptr %slot48, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v545, i64 %v546) nomerge, !dbg !116
  br label %bb_rcslotdone31
bb_rcslotdone31:
  %v547 = load i64, ptr %slot13, align 8
  store i64 %v547, ptr %slot53, align 8
  %v548 = load i64, ptr %slot17, align 8
  store i64 %v548, ptr %slot54, align 8
  %v549 = load i64, ptr %slot54, align 8
  %v550 = load i64, ptr %slot53, align 8
  %p551 = inttoptr i64 %v549 to ptr
  %p552 = inttoptr i64 %v550 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p552, ptr %p551, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot8, align 8
  %p554 = inttoptr i64 %v553 to ptr
  store i32 2, ptr %p554, align 4, !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot12, align 8
  %p556 = inttoptr i64 %v555 to ptr
  %ld557 = load i32, ptr %p556, align 4, !alias.scope !3, !noalias !4
  store i32 %ld557, ptr %slot55, align 8
  %v558 = load i32, ptr %slot55, align 8
  %v559 = load i64, ptr %slot8, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i32 %v558, ptr %p560, align 4, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot11, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i32 0, ptr %p562, align 4, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot7, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 1, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot53, align 8
  %v566 = load i64, ptr %slot22, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 %v565, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot22, align 8
  %p569 = inttoptr i64 %v568 to ptr
  %ld570 = load i64, ptr %p569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld570, ptr %slot56, align 8
  %v571 = load i64, ptr %slot56, align 8
  %op572 = add i64 %v571, 0
  store i64 %op572, ptr %slot57, align 8
  %v573 = load i64, ptr %slot57, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i64, ptr %p574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld575, ptr %slot58, align 8
  %v576 = load i64, ptr %slot58, align 8
  %v577 = load i64, ptr %slot22, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i64 %v576, ptr %p578, align 8, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot22, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i64, ptr %p580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld581, ptr %slot59, align 8
  %v582 = load i64, ptr %slot59, align 8
  %v583 = load i64, ptr %slot15, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot15, align 8
  store i64 %v585, ptr %slot60, align 8
  %v586 = load i64, ptr %slot17, align 8
  store i64 %v586, ptr %slot61, align 8
  %v587 = load i64, ptr %slot60, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %ld589 = load i64, ptr %p588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld589, ptr %slot62, align 8
  %v590 = load i64, ptr %slot62, align 8
  %cmp591 = icmp ne i64 %v590, 0
  %cv592 = zext i1 %cmp591 to i32
  store i32 %cv592, ptr %slot63, align 8
  %v593 = load i32, ptr %slot63, align 8
  %cv594 = zext i32 %v593 to i64
  %cond595 = icmp ne i64 %cv594, 0
  br i1 %cond595, label %bb_rcgnn53, label %bb_rcgstore53
bb_rcgnn53:
  %v596 = load i64, ptr %slot62, align 8
  %op597 = sub i64 %v596, 16
  store i64 %op597, ptr %slot64, align 8
  %v598 = load i64, ptr %slot62, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %rgep600 = getelementptr i8, ptr %p599, i64 -16
  %ld601 = load i64, ptr %rgep600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld601, ptr %slot65, align 8
  %v602 = load i64, ptr %slot65, align 8
  %op603 = and i64 %v602, 4611686018427387906
  store i64 %op603, ptr %slot66, align 8
  %v604 = load i64, ptr %slot66, align 8
  %cmp605 = icmp ne i64 %v604, 0
  %cv606 = zext i1 %cmp605 to i32
  store i32 %cv606, ptr %slot67, align 8
  %v607 = load i32, ptr %slot67, align 8
  %cv608 = zext i32 %v607 to i64
  %cond609 = icmp ne i64 %cv608, 0
  br i1 %cond609, label %bb_rcgstore53, label %bb_rcginc53
bb_rcginc53:
  %v610 = load i64, ptr %slot62, align 8
  %op611 = sub i64 %v610, 24
  store i64 %op611, ptr %slot68, align 8
  %v612 = load i64, ptr %slot62, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %rgep614 = getelementptr i8, ptr %p613, i64 -24
  %ld615 = load i64, ptr %rgep614, align 8, !alias.scope !9, !noalias !10
  store i64 %ld615, ptr %slot69, align 8
  %v616 = load i64, ptr %slot69, align 8
  %op617 = add i64 %v616, 1
  store i64 %op617, ptr %slot70, align 8
  %v618 = load i64, ptr %slot70, align 8
  %cmp619 = icmp eq i64 %v618, 0
  %cv620 = zext i1 %cmp619 to i32
  store i32 %cv620, ptr %slot71, align 8
  %v621 = load i32, ptr %slot71, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcglimit53, label %bb_rcgcapacity53
bb_rcglimit53:
  %v624 = load i64, ptr %slot1, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %call626 = call i32 @myl_qbe_rc_status(ptr %p625, i32 2) nomerge, !dbg !118
  store i32 %call626, ptr %slot72, align 8
  br label %bb_failure
bb_rcgcapacity53:
  %v627 = load i64, ptr %slot70, align 8
  %v628 = load i64, ptr %slot62, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %rgep630 = getelementptr i8, ptr %p629, i64 -24
  store i64 %v627, ptr %rgep630, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore53
bb_rcgstore53:
  %v631 = load i64, ptr %slot62, align 8
  %v632 = load i64, ptr %slot61, align 8
  %p633 = inttoptr i64 %v632 to ptr
  store i64 %v631, ptr %p633, align 8, !alias.scope !3, !noalias !4
  %v634 = load i64, ptr %slot12, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i32 2, ptr %p635, align 4, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot12, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 16, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot11, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i32 1, ptr %p639, align 4, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot7, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i32, ptr %p641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld642, ptr %slot73, align 8
  %v643 = load i32, ptr %slot73, align 8
  %cv644 = zext i32 %v643 to i64
  %cond645 = icmp ne i64 %cv644, 0
  br i1 %cond645, label %bb_rcslotdrop69, label %bb_rcslotdone69
bb_rcslotdrop69:
  %v646 = load i64, ptr %slot7, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i32 0, ptr %p647, align 4, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot13, align 8
  store i64 %v648, ptr %slot74, align 8
  %v649 = load i64, ptr %slot8, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %ld651 = load i32, ptr %p650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld651, ptr %slot75, align 8
  %v652 = load i32, ptr %slot75, align 8
  %op653 = and i32 %v652, 28
  store i32 %op653, ptr %slot76, align 8
  %v654 = load i32, ptr %slot76, align 8
  %cv655 = zext i32 %v654 to i64
  %cond656 = icmp ne i64 %cv655, 0
  br i1 %cond656, label %bb_rcslotrole69, label %bb_rcslotowner69
bb_rcslotrole69:
  %v657 = load i64, ptr %slot29, align 8
  store i64 %v657, ptr %slot77, align 8
  %v658 = load i64, ptr %slot77, align 8
  %v659 = load i64, ptr %slot74, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v658, i64 %v659) nomerge, !dbg !118
  br label %bb_rcslotdone69
bb_rcslotowner69:
  %v660 = load i64, ptr %slot29, align 8
  store i64 %v660, ptr %slot78, align 8
  %v661 = load i64, ptr %slot78, align 8
  %v662 = load i64, ptr %slot74, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v661, i64 %v662) nomerge, !dbg !118
  br label %bb_rcslotdone69
bb_rcslotdone69:
  %v663 = load i64, ptr %slot13, align 8
  store i64 %v663, ptr %slot79, align 8
  %v664 = load i64, ptr %slot17, align 8
  store i64 %v664, ptr %slot80, align 8
  %v665 = load i64, ptr %slot80, align 8
  %v666 = load i64, ptr %slot79, align 8
  %p667 = inttoptr i64 %v665 to ptr
  %p668 = inttoptr i64 %v666 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p668, ptr %p667, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot8, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 2, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot12, align 8
  %p672 = inttoptr i64 %v671 to ptr
  %ld673 = load i32, ptr %p672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld673, ptr %slot81, align 8
  %v674 = load i32, ptr %slot81, align 8
  %v675 = load i64, ptr %slot8, align 8
  %p676 = inttoptr i64 %v675 to ptr
  store i32 %v674, ptr %p676, align 4, !alias.scope !3, !noalias !4
  %v677 = load i64, ptr %slot11, align 8
  %p678 = inttoptr i64 %v677 to ptr
  store i32 0, ptr %p678, align 4, !alias.scope !3, !noalias !4
  %v679 = load i64, ptr %slot7, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i32 1, ptr %p680, align 4, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot79, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %ld683 = load i64, ptr %p682, align 8, !alias.scope !3, !noalias !4
  store i64 %ld683, ptr %slot82, align 8
  %v684 = load i64, ptr %slot82, align 8
  %v685 = load i64, ptr %slot22, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i64 %v684, ptr %p686, align 8, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot22, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i64, ptr %p688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld689, ptr %slot83, align 8
  %v690 = load i64, ptr %slot83, align 8
  %v691 = load i64, ptr %slot15, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i64 %v690, ptr %p692, align 8, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot15, align 8
  store i64 %v693, ptr %slot84, align 8
  %v694 = load i64, ptr %slot7, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %ld696 = load i32, ptr %p695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld696, ptr %slot85, align 8
  %v697 = load i64, ptr %slot8, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %ld699 = load i32, ptr %p698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld699, ptr %slot86, align 8
  %v700 = load i32, ptr %slot86, align 8
  %op701 = and i32 %v700, 24
  store i32 %op701, ptr %slot86, align 8
  %v702 = load i32, ptr %slot86, align 8
  %cmp703 = icmp eq i32 %v702, 0
  %cv704 = zext i1 %cmp703 to i32
  store i32 %cv704, ptr %slot87, align 8
  %v705 = load i32, ptr %slot85, align 8
  %v706 = load i32, ptr %slot87, align 8
  %op707 = and i32 %v705, %v706
  store i32 %op707, ptr %slot88, align 8
  %v708 = load i32, ptr %slot88, align 8
  %cv709 = zext i32 %v708 to i64
  %cond710 = icmp ne i64 %cv709, 0
  br i1 %cond710, label %bb_rcprivateown93, label %bb_rcprivateloan93
bb_rcprivateown93:
  %v711 = load i64, ptr %slot17, align 8
  store i64 %v711, ptr %slot89, align 8
  %v712 = load i64, ptr %slot30, align 8
  store i64 %v712, ptr %slot90, align 8
  %v713 = load i64, ptr %slot84, align 8
  %v714 = load i64, ptr %slot89, align 8
  %op715 = sub i64 %v713, %v714
  store i64 %op715, ptr %slot91, align 8
  %v716 = load i64, ptr %slot89, align 8
  %v717 = load i64, ptr %slot84, align 8
  %op718 = sub i64 %v716, %v717
  store i64 %op718, ptr %slot92, align 8
  %v719 = load i64, ptr %slot91, align 8
  %cmp720 = icmp ult i64 %v719, 8
  %cv721 = zext i1 %cmp720 to i32
  store i32 %cv721, ptr %slot93, align 8
  %v722 = load i64, ptr %slot92, align 8
  %cmp723 = icmp ult i64 %v722, 8
  %cv724 = zext i1 %cmp723 to i32
  store i32 %cv724, ptr %slot94, align 8
  %v725 = load i32, ptr %slot93, align 8
  %v726 = load i32, ptr %slot94, align 8
  %op727 = or i32 %v725, %v726
  store i32 %op727, ptr %slot95, align 8
  %v728 = load i32, ptr %slot95, align 8
  %cv729 = zext i32 %v728 to i64
  %cond730 = icmp ne i64 %cv729, 0
  br i1 %cond730, label %bb_rcmoveslow96, label %bb_rcmovecheck96
bb_rcmovecheck96:
  %v731 = load i64, ptr %slot84, align 8
  %p733 = inttoptr i64 %v731 to ptr
  %gep734 = getelementptr i8, ptr %p733, i64 0
  %op732 = ptrtoint ptr %gep734 to i64
  store i64 %op732, ptr %slot96, align 8
  %v735 = load i64, ptr %slot96, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot97, align 8
  %v738 = load i64, ptr %slot97, align 8
  %cmp739 = icmp ne i64 %v738, 0
  %cv740 = zext i1 %cmp739 to i32
  store i32 %cv740, ptr %slot98, align 8
  %v741 = load i32, ptr %slot98, align 8
  %cv742 = zext i32 %v741 to i64
  %cond743 = icmp ne i64 %cv742, 0
  br i1 %cond743, label %bb_rcmoveheader104, label %bb_rcmovenext104
bb_rcmoveheader104:
  %v744 = load i64, ptr %slot97, align 8
  %op745 = sub i64 %v744, 16
  store i64 %op745, ptr %slot99, align 8
  %v746 = load i64, ptr %slot97, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %rgep748 = getelementptr i8, ptr %p747, i64 -16
  %ld749 = load i64, ptr %rgep748, align 8, !alias.scope !9, !noalias !10
  store i64 %ld749, ptr %slot100, align 8
  %v750 = load i64, ptr %slot100, align 8
  %op751 = and i64 %v750, 5764607523034234881
  store i64 %op751, ptr %slot101, align 8
  %v752 = load i64, ptr %slot101, align 8
  %cmp753 = icmp ne i64 %v752, 0
  %cv754 = zext i1 %cmp753 to i32
  store i32 %cv754, ptr %slot102, align 8
  %v755 = load i32, ptr %slot102, align 8
  %cv756 = zext i32 %v755 to i64
  %cond757 = icmp ne i64 %cv756, 0
  br i1 %cond757, label %bb_rcmoveslow96, label %bb_rcmovenext104
bb_rcmovenext104:
  %v758 = load i64, ptr %slot84, align 8
  %v759 = load i64, ptr %slot89, align 8
  %p760 = inttoptr i64 %v758 to ptr
  %p761 = inttoptr i64 %v759 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p761, ptr %p760, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot84, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 0, ptr %p763, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved96
bb_rcmoveslow96:
  %v764 = load i64, ptr %slot29, align 8
  %v765 = load i64, ptr %slot89, align 8
  %v766 = load i64, ptr %slot84, align 8
  %v767 = load i64, ptr %slot90, align 8
  %cv768 = trunc i64 %v767 to i32
  %call769 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v764, i64 %v765, i64 %v766, i32 %cv768) nomerge, !dbg !120
  store i32 %call769, ptr %slot103, align 8
  %v770 = load i32, ptr %slot103, align 8
  %cv771 = zext i32 %v770 to i64
  %cond772 = icmp ne i64 %cv771, 0
  br i1 %cond772, label %bb_rcsuccess111, label %bb_rcfailure111
bb_rcfailure111:
  %v773 = load i64, ptr %slot29, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %call775 = call i32 @myl_rc_take_failure(ptr %p774) nomerge, !dbg !120
  store i32 %call775, ptr %slot104, align 8
  %v776 = load i64, ptr %slot1, align 8
  %p777 = inttoptr i64 %v776 to ptr
  %v778 = load i32, ptr %slot104, align 8
  %call779 = call i32 @myl_qbe_rc_status(ptr %p777, i32 %v778) nomerge, !dbg !120
  store i32 %call779, ptr %slot105, align 8
  br label %bb_failure
bb_rcsuccess111:
  br label %bb_rcmoved96
bb_rcmoved96:
  %v780 = load i64, ptr %slot7, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i32 0, ptr %p781, align 4, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot12, align 8
  %p783 = inttoptr i64 %v782 to ptr
  store i32 2, ptr %p783, align 4, !alias.scope !3, !noalias !4
  %v784 = load i64, ptr %slot11, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i32 1, ptr %p785, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared93
bb_rcprivateloan93:
  %v786 = load i64, ptr %slot7, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i32, ptr %p787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld788, ptr %slot106, align 8
  %v789 = load i64, ptr %slot8, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %ld791 = load i32, ptr %p790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld791, ptr %slot107, align 8
  %v792 = load i32, ptr %slot107, align 8
  %cmp793 = icmp eq i32 %v792, 16
  %cv794 = zext i1 %cmp793 to i32
  store i32 %cv794, ptr %slot108, align 8
  %v795 = load i32, ptr %slot108, align 8
  %v796 = load i32, ptr %slot106, align 8
  %op797 = and i32 %v795, %v796
  store i32 %op797, ptr %slot108, align 8
  %v798 = load i32, ptr %slot108, align 8
  %cv799 = zext i32 %v798 to i64
  %cond800 = icmp ne i64 %cv799, 0
  br i1 %cond800, label %bb_rcprivatemove93, label %bb_rcprivatenew93
bb_rcprivatemove93:
  %v801 = load i64, ptr %slot17, align 8
  store i64 %v801, ptr %slot109, align 8
  %v802 = load i64, ptr %slot84, align 8
  %v803 = load i64, ptr %slot109, align 8
  %p804 = inttoptr i64 %v802 to ptr
  %p805 = inttoptr i64 %v803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p805, ptr %p804, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot84, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i64 0, ptr %p807, align 8, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot12, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 2, ptr %p809, align 4, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot12, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 16, ptr %p811, align 4, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot11, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i32 1, ptr %p813, align 4, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot7, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i32 0, ptr %p815, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared93
bb_rcprivatenew93:
  %v816 = load i64, ptr %slot17, align 8
  store i64 %v816, ptr %slot110, align 8
  %v817 = load i64, ptr %slot84, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i64, ptr %p818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld819, ptr %slot111, align 8
  %v820 = load i64, ptr %slot111, align 8
  %cmp821 = icmp ne i64 %v820, 0
  %cv822 = zext i1 %cmp821 to i32
  store i32 %cv822, ptr %slot112, align 8
  %v823 = load i32, ptr %slot112, align 8
  %cv824 = zext i32 %v823 to i64
  %cond825 = icmp ne i64 %cv824, 0
  br i1 %cond825, label %bb_rcgnn129, label %bb_rcgstore129
bb_rcgnn129:
  %v826 = load i64, ptr %slot111, align 8
  %op827 = sub i64 %v826, 16
  store i64 %op827, ptr %slot113, align 8
  %v828 = load i64, ptr %slot111, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %rgep830 = getelementptr i8, ptr %p829, i64 -16
  %ld831 = load i64, ptr %rgep830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld831, ptr %slot114, align 8
  %v832 = load i64, ptr %slot114, align 8
  %op833 = and i64 %v832, 4611686018427387906
  store i64 %op833, ptr %slot115, align 8
  %v834 = load i64, ptr %slot115, align 8
  %cmp835 = icmp ne i64 %v834, 0
  %cv836 = zext i1 %cmp835 to i32
  store i32 %cv836, ptr %slot116, align 8
  %v837 = load i32, ptr %slot116, align 8
  %cv838 = zext i32 %v837 to i64
  %cond839 = icmp ne i64 %cv838, 0
  br i1 %cond839, label %bb_rcgstore129, label %bb_rcginc129
bb_rcginc129:
  %v840 = load i64, ptr %slot111, align 8
  %op841 = sub i64 %v840, 24
  store i64 %op841, ptr %slot117, align 8
  %v842 = load i64, ptr %slot111, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %rgep844 = getelementptr i8, ptr %p843, i64 -24
  %ld845 = load i64, ptr %rgep844, align 8, !alias.scope !9, !noalias !10
  store i64 %ld845, ptr %slot118, align 8
  %v846 = load i64, ptr %slot118, align 8
  %op847 = add i64 %v846, 1
  store i64 %op847, ptr %slot119, align 8
  %v848 = load i64, ptr %slot119, align 8
  %cmp849 = icmp eq i64 %v848, 0
  %cv850 = zext i1 %cmp849 to i32
  store i32 %cv850, ptr %slot120, align 8
  %v851 = load i32, ptr %slot120, align 8
  %cv852 = zext i32 %v851 to i64
  %cond853 = icmp ne i64 %cv852, 0
  br i1 %cond853, label %bb_rcglimit129, label %bb_rcgcapacity129
bb_rcglimit129:
  %v854 = load i64, ptr %slot1, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %call856 = call i32 @myl_qbe_rc_status(ptr %p855, i32 2) nomerge, !dbg !120
  store i32 %call856, ptr %slot121, align 8
  br label %bb_failure
bb_rcgcapacity129:
  %v857 = load i64, ptr %slot119, align 8
  %v858 = load i64, ptr %slot111, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %rgep860 = getelementptr i8, ptr %p859, i64 -24
  store i64 %v857, ptr %rgep860, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore129
bb_rcgstore129:
  %v861 = load i64, ptr %slot111, align 8
  %v862 = load i64, ptr %slot110, align 8
  %p863 = inttoptr i64 %v862 to ptr
  store i64 %v861, ptr %p863, align 8, !alias.scope !3, !noalias !4
  %v864 = load i64, ptr %slot12, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i32 2, ptr %p865, align 4, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot12, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i32 16, ptr %p867, align 4, !alias.scope !3, !noalias !4
  %v868 = load i64, ptr %slot11, align 8
  %p869 = inttoptr i64 %v868 to ptr
  store i32 1, ptr %p869, align 4, !alias.scope !3, !noalias !4
  %v870 = load i64, ptr %slot7, align 8
  %p871 = inttoptr i64 %v870 to ptr
  %ld872 = load i32, ptr %p871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld872, ptr %slot122, align 8
  %v873 = load i32, ptr %slot122, align 8
  %cv874 = zext i32 %v873 to i64
  %cond875 = icmp ne i64 %cv874, 0
  br i1 %cond875, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v876 = load i64, ptr %slot7, align 8
  %p877 = inttoptr i64 %v876 to ptr
  store i32 0, ptr %p877, align 4, !alias.scope !3, !noalias !4
  %v878 = load i64, ptr %slot13, align 8
  store i64 %v878, ptr %slot123, align 8
  %v879 = load i64, ptr %slot8, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i32, ptr %p880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld881, ptr %slot124, align 8
  %v882 = load i32, ptr %slot124, align 8
  %op883 = and i32 %v882, 28
  store i32 %op883, ptr %slot125, align 8
  %v884 = load i32, ptr %slot125, align 8
  %cv885 = zext i32 %v884 to i64
  %cond886 = icmp ne i64 %cv885, 0
  br i1 %cond886, label %bb_rcslotrole145, label %bb_rcslotowner145
bb_rcslotrole145:
  %v887 = load i64, ptr %slot29, align 8
  store i64 %v887, ptr %slot126, align 8
  %v888 = load i64, ptr %slot123, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %ld890 = load i64, ptr %p889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld890, ptr %slot127, align 8
  %v891 = load i64, ptr %slot127, align 8
  %cmp892 = icmp ne i64 %v891, 0
  %cv893 = zext i1 %cmp892 to i32
  store i32 %cv893, ptr %slot128, align 8
  %v894 = load i32, ptr %slot128, align 8
  %cv895 = zext i32 %v894 to i64
  %cond896 = icmp ne i64 %cv895, 0
  br i1 %cond896, label %bb_rcgnn161, label %bb_rcgdone161
bb_rcgnn161:
  %v897 = load i64, ptr %slot127, align 8
  %op898 = sub i64 %v897, 16
  store i64 %op898, ptr %slot129, align 8
  %v899 = load i64, ptr %slot127, align 8
  %p900 = inttoptr i64 %v899 to ptr
  %rgep901 = getelementptr i8, ptr %p900, i64 -16
  %ld902 = load i64, ptr %rgep901, align 8, !alias.scope !9, !noalias !10
  store i64 %ld902, ptr %slot130, align 8
  %v903 = load i64, ptr %slot130, align 8
  %op904 = and i64 %v903, 4611686018427387906
  store i64 %op904, ptr %slot131, align 8
  %v905 = load i64, ptr %slot131, align 8
  %cmp906 = icmp ne i64 %v905, 0
  %cv907 = zext i1 %cmp906 to i32
  store i32 %cv907, ptr %slot132, align 8
  %v908 = load i32, ptr %slot132, align 8
  %cv909 = zext i32 %v908 to i64
  %cond910 = icmp ne i64 %cv909, 0
  br i1 %cond910, label %bb_rcgclear161, label %bb_rcgcounted161
bb_rcgcounted161:
  %v911 = load i64, ptr %slot127, align 8
  %op912 = sub i64 %v911, 24
  store i64 %op912, ptr %slot133, align 8
  %v913 = load i64, ptr %slot127, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %rgep915 = getelementptr i8, ptr %p914, i64 -24
  %ld916 = load i64, ptr %rgep915, align 8, !alias.scope !9, !noalias !10
  store i64 %ld916, ptr %slot134, align 8
  %v917 = load i64, ptr %slot134, align 8
  %op918 = sub i64 %v917, 1
  store i64 %op918, ptr %slot135, align 8
  %v919 = load i64, ptr %slot135, align 8
  %cmp920 = icmp eq i64 %v919, 0
  %cv921 = zext i1 %cmp920 to i32
  store i32 %cv921, ptr %slot136, align 8
  %v922 = load i32, ptr %slot136, align 8
  %cv923 = zext i32 %v922 to i64
  %cond924 = icmp ne i64 %cv923, 0
  br i1 %cond924, label %bb_rcglast161, label %bb_rcgdec161
bb_rcglast161:
  %v925 = load i64, ptr %slot127, align 8
  %op926 = sub i64 %v925, 32
  store i64 %op926, ptr %slot137, align 8
  %v927 = load i64, ptr %slot127, align 8
  %p928 = inttoptr i64 %v927 to ptr
  %rgep929 = getelementptr i8, ptr %p928, i64 -32
  %ld930 = load i64, ptr %rgep929, align 8, !alias.scope !9, !noalias !10
  store i64 %ld930, ptr %slot138, align 8
  %v931 = load i64, ptr %slot138, align 8
  %cmp932 = icmp ne i64 %v931, 0
  %cv933 = zext i1 %cmp932 to i32
  store i32 %cv933, ptr %slot139, align 8
  %v934 = load i32, ptr %slot139, align 8
  %cv935 = zext i32 %v934 to i64
  %cond936 = icmp ne i64 %cv935, 0
  br i1 %cond936, label %bb_rcgdec161, label %bb_rcgslow161
bb_rcgslow161:
  %v937 = load i64, ptr %slot126, align 8
  %v938 = load i64, ptr %slot123, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v937, i64 %v938) nomerge, !dbg !120
  br label %bb_rcgdone161
bb_rcgdec161:
  %v939 = load i64, ptr %slot135, align 8
  %v940 = load i64, ptr %slot127, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %rgep942 = getelementptr i8, ptr %p941, i64 -24
  store i64 %v939, ptr %rgep942, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear161
bb_rcgclear161:
  %v943 = load i64, ptr %slot123, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i64 0, ptr %p944, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone161
bb_rcgdone161:
  br label %bb_rcslotdone145
bb_rcslotowner145:
  %v945 = load i64, ptr %slot29, align 8
  store i64 %v945, ptr %slot140, align 8
  %v946 = load i64, ptr %slot123, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %ld948 = load i64, ptr %p947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld948, ptr %slot141, align 8
  %v949 = load i64, ptr %slot141, align 8
  %cmp950 = icmp ne i64 %v949, 0
  %cv951 = zext i1 %cmp950 to i32
  store i32 %cv951, ptr %slot142, align 8
  %v952 = load i32, ptr %slot142, align 8
  %cv953 = zext i32 %v952 to i64
  %cond954 = icmp ne i64 %cv953, 0
  br i1 %cond954, label %bb_rcgnn176, label %bb_rcgdone176
bb_rcgnn176:
  %v955 = load i64, ptr %slot141, align 8
  %op956 = sub i64 %v955, 16
  store i64 %op956, ptr %slot143, align 8
  %v957 = load i64, ptr %slot141, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %rgep959 = getelementptr i8, ptr %p958, i64 -16
  %ld960 = load i64, ptr %rgep959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld960, ptr %slot144, align 8
  %v961 = load i64, ptr %slot144, align 8
  %op962 = and i64 %v961, 4611686018427387906
  store i64 %op962, ptr %slot145, align 8
  %v963 = load i64, ptr %slot145, align 8
  %cmp964 = icmp ne i64 %v963, 0
  %cv965 = zext i1 %cmp964 to i32
  store i32 %cv965, ptr %slot146, align 8
  %v966 = load i32, ptr %slot146, align 8
  %cv967 = zext i32 %v966 to i64
  %cond968 = icmp ne i64 %cv967, 0
  br i1 %cond968, label %bb_rcgclear176, label %bb_rcgcounted176
bb_rcgcounted176:
  %v969 = load i64, ptr %slot141, align 8
  %op970 = sub i64 %v969, 32
  store i64 %op970, ptr %slot147, align 8
  %v971 = load i64, ptr %slot141, align 8
  %p972 = inttoptr i64 %v971 to ptr
  %rgep973 = getelementptr i8, ptr %p972, i64 -32
  %ld974 = load i64, ptr %rgep973, align 8, !alias.scope !9, !noalias !10
  store i64 %ld974, ptr %slot148, align 8
  %v975 = load i64, ptr %slot148, align 8
  %op976 = sub i64 %v975, 1
  store i64 %op976, ptr %slot149, align 8
  %v977 = load i64, ptr %slot149, align 8
  %cmp978 = icmp eq i64 %v977, 0
  %cv979 = zext i1 %cmp978 to i32
  store i32 %cv979, ptr %slot150, align 8
  %v980 = load i32, ptr %slot150, align 8
  %cv981 = zext i32 %v980 to i64
  %cond982 = icmp ne i64 %cv981, 0
  br i1 %cond982, label %bb_rcglast176, label %bb_rcgdec176
bb_rcglast176:
  %v983 = load i64, ptr %slot141, align 8
  %op984 = sub i64 %v983, 24
  store i64 %op984, ptr %slot151, align 8
  %v985 = load i64, ptr %slot141, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %rgep987 = getelementptr i8, ptr %p986, i64 -24
  %ld988 = load i64, ptr %rgep987, align 8, !alias.scope !9, !noalias !10
  store i64 %ld988, ptr %slot152, align 8
  %v989 = load i64, ptr %slot152, align 8
  %cmp990 = icmp ne i64 %v989, 0
  %cv991 = zext i1 %cmp990 to i32
  store i32 %cv991, ptr %slot153, align 8
  %v992 = load i32, ptr %slot153, align 8
  %cv993 = zext i32 %v992 to i64
  %cond994 = icmp ne i64 %cv993, 0
  br i1 %cond994, label %bb_rcgdec176, label %bb_rcgslow176
bb_rcgslow176:
  %v995 = load i64, ptr %slot140, align 8
  %v996 = load i64, ptr %slot123, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v995, i64 %v996) nomerge, !dbg !120
  br label %bb_rcgdone176
bb_rcgdec176:
  %v997 = load i64, ptr %slot149, align 8
  %v998 = load i64, ptr %slot141, align 8
  %p999 = inttoptr i64 %v998 to ptr
  %rgep1000 = getelementptr i8, ptr %p999, i64 -32
  store i64 %v997, ptr %rgep1000, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear176
bb_rcgclear176:
  %v1001 = load i64, ptr %slot123, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i64 0, ptr %p1002, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone176
bb_rcgdone176:
  br label %bb_rcslotdone145
bb_rcslotdone145:
  br label %bb_rcprivateprepared93
bb_rcprivateprepared93:
  %v1003 = load i64, ptr %slot5, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i32, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1005, ptr %slot154, align 8
  %v1006 = load i32, ptr %slot154, align 8
  %cv1007 = zext i32 %v1006 to i64
  %cond1008 = icmp ne i64 %cv1007, 0
  br i1 %cond1008, label %bb_rcslotdrop183, label %bb_rcslotdone183
bb_rcslotdrop183:
  %v1009 = load i64, ptr %slot5, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i32 0, ptr %p1010, align 4, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot20, align 8
  store i64 %v1011, ptr %slot155, align 8
  %v1012 = load i64, ptr %slot6, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  %ld1014 = load i32, ptr %p1013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1014, ptr %slot156, align 8
  %v1015 = load i32, ptr %slot156, align 8
  %op1016 = and i32 %v1015, 28
  store i32 %op1016, ptr %slot157, align 8
  %v1017 = load i32, ptr %slot157, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcslotrole183, label %bb_rcslotowner183
bb_rcslotrole183:
  %v1020 = load i64, ptr %slot29, align 8
  store i64 %v1020, ptr %slot158, align 8
  %v1021 = load i64, ptr %slot155, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i64, ptr %p1022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1023, ptr %slot159, align 8
  %v1024 = load i64, ptr %slot159, align 8
  %cmp1025 = icmp ne i64 %v1024, 0
  %cv1026 = zext i1 %cmp1025 to i32
  store i32 %cv1026, ptr %slot160, align 8
  %v1027 = load i32, ptr %slot160, align 8
  %cv1028 = zext i32 %v1027 to i64
  %cond1029 = icmp ne i64 %cv1028, 0
  br i1 %cond1029, label %bb_rcgnn199, label %bb_rcgdone199
bb_rcgnn199:
  %v1030 = load i64, ptr %slot159, align 8
  %op1031 = sub i64 %v1030, 16
  store i64 %op1031, ptr %slot161, align 8
  %v1032 = load i64, ptr %slot159, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %rgep1034 = getelementptr i8, ptr %p1033, i64 -16
  %ld1035 = load i64, ptr %rgep1034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1035, ptr %slot162, align 8
  %v1036 = load i64, ptr %slot162, align 8
  %op1037 = and i64 %v1036, 4611686018427387906
  store i64 %op1037, ptr %slot163, align 8
  %v1038 = load i64, ptr %slot163, align 8
  %cmp1039 = icmp ne i64 %v1038, 0
  %cv1040 = zext i1 %cmp1039 to i32
  store i32 %cv1040, ptr %slot164, align 8
  %v1041 = load i32, ptr %slot164, align 8
  %cv1042 = zext i32 %v1041 to i64
  %cond1043 = icmp ne i64 %cv1042, 0
  br i1 %cond1043, label %bb_rcgclear199, label %bb_rcgcounted199
bb_rcgcounted199:
  %v1044 = load i64, ptr %slot159, align 8
  %op1045 = sub i64 %v1044, 24
  store i64 %op1045, ptr %slot165, align 8
  %v1046 = load i64, ptr %slot159, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %rgep1048 = getelementptr i8, ptr %p1047, i64 -24
  %ld1049 = load i64, ptr %rgep1048, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1049, ptr %slot166, align 8
  %v1050 = load i64, ptr %slot166, align 8
  %op1051 = sub i64 %v1050, 1
  store i64 %op1051, ptr %slot167, align 8
  %v1052 = load i64, ptr %slot167, align 8
  %cmp1053 = icmp eq i64 %v1052, 0
  %cv1054 = zext i1 %cmp1053 to i32
  store i32 %cv1054, ptr %slot168, align 8
  %v1055 = load i32, ptr %slot168, align 8
  %cv1056 = zext i32 %v1055 to i64
  %cond1057 = icmp ne i64 %cv1056, 0
  br i1 %cond1057, label %bb_rcglast199, label %bb_rcgdec199
bb_rcglast199:
  %v1058 = load i64, ptr %slot159, align 8
  %op1059 = sub i64 %v1058, 32
  store i64 %op1059, ptr %slot169, align 8
  %v1060 = load i64, ptr %slot159, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %rgep1062 = getelementptr i8, ptr %p1061, i64 -32
  %ld1063 = load i64, ptr %rgep1062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1063, ptr %slot170, align 8
  %v1064 = load i64, ptr %slot170, align 8
  %cmp1065 = icmp ne i64 %v1064, 0
  %cv1066 = zext i1 %cmp1065 to i32
  store i32 %cv1066, ptr %slot171, align 8
  %v1067 = load i32, ptr %slot171, align 8
  %cv1068 = zext i32 %v1067 to i64
  %cond1069 = icmp ne i64 %cv1068, 0
  br i1 %cond1069, label %bb_rcgdec199, label %bb_rcgslow199
bb_rcgslow199:
  %v1070 = load i64, ptr %slot158, align 8
  %v1071 = load i64, ptr %slot155, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1070, i64 %v1071) nomerge, !dbg !120
  br label %bb_rcgdone199
bb_rcgdec199:
  %v1072 = load i64, ptr %slot167, align 8
  %v1073 = load i64, ptr %slot159, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %rgep1075 = getelementptr i8, ptr %p1074, i64 -24
  store i64 %v1072, ptr %rgep1075, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear199
bb_rcgclear199:
  %v1076 = load i64, ptr %slot155, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  store i64 0, ptr %p1077, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone199
bb_rcgdone199:
  br label %bb_rcslotdone183
bb_rcslotowner183:
  %v1078 = load i64, ptr %slot29, align 8
  store i64 %v1078, ptr %slot172, align 8
  %v1079 = load i64, ptr %slot155, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %ld1081 = load i64, ptr %p1080, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1081, ptr %slot173, align 8
  %v1082 = load i64, ptr %slot173, align 8
  %cmp1083 = icmp ne i64 %v1082, 0
  %cv1084 = zext i1 %cmp1083 to i32
  store i32 %cv1084, ptr %slot174, align 8
  %v1085 = load i32, ptr %slot174, align 8
  %cv1086 = zext i32 %v1085 to i64
  %cond1087 = icmp ne i64 %cv1086, 0
  br i1 %cond1087, label %bb_rcgnn214, label %bb_rcgdone214
bb_rcgnn214:
  %v1088 = load i64, ptr %slot173, align 8
  %op1089 = sub i64 %v1088, 16
  store i64 %op1089, ptr %slot175, align 8
  %v1090 = load i64, ptr %slot173, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %rgep1092 = getelementptr i8, ptr %p1091, i64 -16
  %ld1093 = load i64, ptr %rgep1092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1093, ptr %slot176, align 8
  %v1094 = load i64, ptr %slot176, align 8
  %op1095 = and i64 %v1094, 4611686018427387906
  store i64 %op1095, ptr %slot177, align 8
  %v1096 = load i64, ptr %slot177, align 8
  %cmp1097 = icmp ne i64 %v1096, 0
  %cv1098 = zext i1 %cmp1097 to i32
  store i32 %cv1098, ptr %slot178, align 8
  %v1099 = load i32, ptr %slot178, align 8
  %cv1100 = zext i32 %v1099 to i64
  %cond1101 = icmp ne i64 %cv1100, 0
  br i1 %cond1101, label %bb_rcgclear214, label %bb_rcgcounted214
bb_rcgcounted214:
  %v1102 = load i64, ptr %slot173, align 8
  %op1103 = sub i64 %v1102, 32
  store i64 %op1103, ptr %slot179, align 8
  %v1104 = load i64, ptr %slot173, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  %rgep1106 = getelementptr i8, ptr %p1105, i64 -32
  %ld1107 = load i64, ptr %rgep1106, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1107, ptr %slot180, align 8
  %v1108 = load i64, ptr %slot180, align 8
  %op1109 = sub i64 %v1108, 1
  store i64 %op1109, ptr %slot181, align 8
  %v1110 = load i64, ptr %slot181, align 8
  %cmp1111 = icmp eq i64 %v1110, 0
  %cv1112 = zext i1 %cmp1111 to i32
  store i32 %cv1112, ptr %slot182, align 8
  %v1113 = load i32, ptr %slot182, align 8
  %cv1114 = zext i32 %v1113 to i64
  %cond1115 = icmp ne i64 %cv1114, 0
  br i1 %cond1115, label %bb_rcglast214, label %bb_rcgdec214
bb_rcglast214:
  %v1116 = load i64, ptr %slot173, align 8
  %op1117 = sub i64 %v1116, 24
  store i64 %op1117, ptr %slot183, align 8
  %v1118 = load i64, ptr %slot173, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  %rgep1120 = getelementptr i8, ptr %p1119, i64 -24
  %ld1121 = load i64, ptr %rgep1120, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1121, ptr %slot184, align 8
  %v1122 = load i64, ptr %slot184, align 8
  %cmp1123 = icmp ne i64 %v1122, 0
  %cv1124 = zext i1 %cmp1123 to i32
  store i32 %cv1124, ptr %slot185, align 8
  %v1125 = load i32, ptr %slot185, align 8
  %cv1126 = zext i32 %v1125 to i64
  %cond1127 = icmp ne i64 %cv1126, 0
  br i1 %cond1127, label %bb_rcgdec214, label %bb_rcgslow214
bb_rcgslow214:
  %v1128 = load i64, ptr %slot172, align 8
  %v1129 = load i64, ptr %slot155, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1128, i64 %v1129) nomerge, !dbg !120
  br label %bb_rcgdone214
bb_rcgdec214:
  %v1130 = load i64, ptr %slot181, align 8
  %v1131 = load i64, ptr %slot173, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %rgep1133 = getelementptr i8, ptr %p1132, i64 -32
  store i64 %v1130, ptr %rgep1133, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear214
bb_rcgclear214:
  %v1134 = load i64, ptr %slot155, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i64 0, ptr %p1135, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone214
bb_rcgdone214:
  br label %bb_rcslotdone183
bb_rcslotdone183:
  %v1136 = load i64, ptr %slot20, align 8
  store i64 %v1136, ptr %slot186, align 8
  %v1137 = load i64, ptr %slot17, align 8
  store i64 %v1137, ptr %slot187, align 8
  %v1138 = load i64, ptr %slot187, align 8
  %v1139 = load i64, ptr %slot186, align 8
  %p1140 = inttoptr i64 %v1138 to ptr
  %p1141 = inttoptr i64 %v1139 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1141, ptr %p1140, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot11, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i32 0, ptr %p1143, align 4, !alias.scope !3, !noalias !4
  %v1144 = load i64, ptr %slot6, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i32 2, ptr %p1145, align 4, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot12, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i32, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1148, ptr %slot188, align 8
  %v1149 = load i32, ptr %slot188, align 8
  %v1150 = load i64, ptr %slot6, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i32 %v1149, ptr %p1151, align 4, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot5, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  store i32 1, ptr %p1153, align 4, !alias.scope !3, !noalias !4
  %v1154 = load i64, ptr %slot20, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  %ld1156 = load i64, ptr %p1155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1156, ptr %slot189, align 8
  %v1157 = load i64, ptr %slot189, align 8
  %op1158 = add i64 %v1157, 0
  store i64 %op1158, ptr %slot190, align 8
  %v1159 = load i64, ptr %slot190, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i64, ptr %p1160, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1161, ptr %slot191, align 8
  %v1162 = load i64, ptr %slot191, align 8
  %v1163 = load i64, ptr %slot22, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i64 %v1162, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot22, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i64, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1167, ptr %slot192, align 8
  %v1168 = load i64, ptr %slot192, align 8
  %cmp1169 = icmp ugt i64 %v1168, 9223372036854775807
  %cv1170 = zext i1 %cmp1169 to i64
  store i64 %cv1170, ptr %slot193, align 8
  %v1171 = load i64, ptr %slot193, align 8
  %cond1172 = icmp ne i64 %v1171, 0
  br i1 %cond1172, label %bb_cast_overflow230, label %bb_cast_ok230
bb_cast_overflow230:
  %v1173 = load i64, ptr %slot1, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %v1175 = load i64, ptr %slot192, align 8
  call void @myl_qbe_fail_cast(ptr %p1174, i64 %v1175, i64 320) nomerge, !dbg !122
  unreachable
bb_cast_ok230:
  %v1176 = load i64, ptr %slot192, align 8
  %v1177 = load i64, ptr %slot22, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  store i64 %v1176, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  %v1179 = load i64, ptr %slot19, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i64, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1181, ptr %slot194, align 8
  %v1182 = load i64, ptr %slot194, align 8
  %v1183 = load i64, ptr %slot23, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  store i64 %v1182, ptr %p1184, align 8, !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot23, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %ld1187 = load i64, ptr %p1186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1187, ptr %slot195, align 8
  %v1188 = load i64, ptr %slot22, align 8
  %p1189 = inttoptr i64 %v1188 to ptr
  %ld1190 = load i64, ptr %p1189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1190, ptr %slot196, align 8
  %v1191 = load i64, ptr %slot196, align 8
  %v1192 = load i64, ptr %slot195, align 8
  %ovpair1194 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1191, i64 %v1192)
  %op1193 = extractvalue { i64, i1 } %ovpair1194, 0
  %ov1195 = extractvalue { i64, i1 } %ovpair1194, 1
  store i64 %op1193, ptr %slot197, align 8
  %v1196 = load i64, ptr %slot196, align 8
  %v1197 = load i64, ptr %slot195, align 8
  %op1198 = xor i64 %v1196, %v1197
  store i64 %op1198, ptr %slot198, align 8
  %v1199 = load i64, ptr %slot196, align 8
  %v1200 = load i64, ptr %slot197, align 8
  %op1201 = xor i64 %v1199, %v1200
  store i64 %op1201, ptr %slot199, align 8
  %v1202 = load i64, ptr %slot198, align 8
  %v1203 = load i64, ptr %slot199, align 8
  %op1204 = and i64 %v1202, %v1203
  store i64 %op1204, ptr %slot200, align 8
  %cv1205 = zext i1 %ov1195 to i64
  store i64 %cv1205, ptr %slot201, align 8
  %v1206 = load i64, ptr %slot201, align 8
  %cond1207 = icmp ne i64 %v1206, 0
  br i1 %cond1207, label %bb_overflow234, label %bb_checked234
bb_overflow234:
  %v1208 = load i64, ptr %slot1, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %v1210 = load i64, ptr %slot196, align 8
  %v1211 = load i64, ptr %slot195, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1209, i64 1, i64 %v1210, i64 %v1211, i64 64) nomerge, !dbg !124
  unreachable
bb_checked234:
  %v1212 = load i64, ptr %slot197, align 8
  %v1213 = load i64, ptr %slot22, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  store i64 %v1212, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  %v1215 = load i64, ptr %slot23, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  store i64 2, ptr %p1216, align 8, !alias.scope !3, !noalias !4
  %v1217 = load i64, ptr %slot23, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ld1219 = load i64, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1219, ptr %slot202, align 8
  %v1220 = load i64, ptr %slot22, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  %ld1222 = load i64, ptr %p1221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1222, ptr %slot203, align 8
  %v1223 = load i64, ptr %slot203, align 8
  %v1224 = load i64, ptr %slot202, align 8
  %op1225 = add i64 %v1223, %v1224
  store i64 %op1225, ptr %slot204, align 8
  %v1226 = load i64, ptr %slot203, align 8
  %cmp1227 = icmp sgt i64 %v1226, 9223372036854775805
  %cv1228 = zext i1 %cmp1227 to i64
  store i64 %cv1228, ptr %slot205, align 8
  %v1229 = load i64, ptr %slot205, align 8
  %cond1230 = icmp ne i64 %v1229, 0
  br i1 %cond1230, label %bb_overflow241, label %bb_checked241
bb_overflow241:
  %v1231 = load i64, ptr %slot1, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  %v1233 = load i64, ptr %slot203, align 8
  %v1234 = load i64, ptr %slot202, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1232, i64 0, i64 %v1233, i64 %v1234, i64 64) nomerge, !dbg !126
  unreachable
bb_checked241:
  %v1235 = load i64, ptr %slot204, align 8
  %v1236 = load i64, ptr %slot22, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i64 %v1235, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot22, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ld1240 = load i64, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1240, ptr %slot206, align 8
  %v1241 = load i64, ptr %slot206, align 8
  %v1242 = load i64, ptr %slot21, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 %v1241, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot5, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i32, ptr %p1245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1246, ptr %slot207, align 8
  %v1247 = load i32, ptr %slot207, align 8
  %cv1248 = zext i32 %v1247 to i64
  %cond1249 = icmp ne i64 %cv1248, 0
  br i1 %cond1249, label %bb_rcslotdrop246, label %bb_rcslotdone246
bb_rcslotdrop246:
  %v1250 = load i64, ptr %slot5, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i32 0, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot20, align 8
  store i64 %v1252, ptr %slot208, align 8
  %v1253 = load i64, ptr %slot6, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  %ld1255 = load i32, ptr %p1254, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1255, ptr %slot209, align 8
  %v1256 = load i32, ptr %slot209, align 8
  %op1257 = and i32 %v1256, 28
  store i32 %op1257, ptr %slot210, align 8
  %v1258 = load i32, ptr %slot210, align 8
  %cv1259 = zext i32 %v1258 to i64
  %cond1260 = icmp ne i64 %cv1259, 0
  br i1 %cond1260, label %bb_rcslotrole246, label %bb_rcslotowner246
bb_rcslotrole246:
  %v1261 = load i64, ptr %slot29, align 8
  store i64 %v1261, ptr %slot211, align 8
  %v1262 = load i64, ptr %slot208, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i64, ptr %p1263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1264, ptr %slot212, align 8
  %v1265 = load i64, ptr %slot212, align 8
  %cmp1266 = icmp ne i64 %v1265, 0
  %cv1267 = zext i1 %cmp1266 to i32
  store i32 %cv1267, ptr %slot213, align 8
  %v1268 = load i32, ptr %slot213, align 8
  %cv1269 = zext i32 %v1268 to i64
  %cond1270 = icmp ne i64 %cv1269, 0
  br i1 %cond1270, label %bb_rcgnn262, label %bb_rcgdone262
bb_rcgnn262:
  %v1271 = load i64, ptr %slot212, align 8
  %op1272 = sub i64 %v1271, 16
  store i64 %op1272, ptr %slot214, align 8
  %v1273 = load i64, ptr %slot212, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  %rgep1275 = getelementptr i8, ptr %p1274, i64 -16
  %ld1276 = load i64, ptr %rgep1275, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1276, ptr %slot215, align 8
  %v1277 = load i64, ptr %slot215, align 8
  %op1278 = and i64 %v1277, 4611686018427387906
  store i64 %op1278, ptr %slot216, align 8
  %v1279 = load i64, ptr %slot216, align 8
  %cmp1280 = icmp ne i64 %v1279, 0
  %cv1281 = zext i1 %cmp1280 to i32
  store i32 %cv1281, ptr %slot217, align 8
  %v1282 = load i32, ptr %slot217, align 8
  %cv1283 = zext i32 %v1282 to i64
  %cond1284 = icmp ne i64 %cv1283, 0
  br i1 %cond1284, label %bb_rcgclear262, label %bb_rcgcounted262
bb_rcgcounted262:
  %v1285 = load i64, ptr %slot212, align 8
  %op1286 = sub i64 %v1285, 24
  store i64 %op1286, ptr %slot218, align 8
  %v1287 = load i64, ptr %slot212, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %rgep1289 = getelementptr i8, ptr %p1288, i64 -24
  %ld1290 = load i64, ptr %rgep1289, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1290, ptr %slot219, align 8
  %v1291 = load i64, ptr %slot219, align 8
  %op1292 = sub i64 %v1291, 1
  store i64 %op1292, ptr %slot220, align 8
  %v1293 = load i64, ptr %slot220, align 8
  %cmp1294 = icmp eq i64 %v1293, 0
  %cv1295 = zext i1 %cmp1294 to i32
  store i32 %cv1295, ptr %slot221, align 8
  %v1296 = load i32, ptr %slot221, align 8
  %cv1297 = zext i32 %v1296 to i64
  %cond1298 = icmp ne i64 %cv1297, 0
  br i1 %cond1298, label %bb_rcglast262, label %bb_rcgdec262
bb_rcglast262:
  %v1299 = load i64, ptr %slot212, align 8
  %op1300 = sub i64 %v1299, 32
  store i64 %op1300, ptr %slot222, align 8
  %v1301 = load i64, ptr %slot212, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  %rgep1303 = getelementptr i8, ptr %p1302, i64 -32
  %ld1304 = load i64, ptr %rgep1303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1304, ptr %slot223, align 8
  %v1305 = load i64, ptr %slot223, align 8
  %cmp1306 = icmp ne i64 %v1305, 0
  %cv1307 = zext i1 %cmp1306 to i32
  store i32 %cv1307, ptr %slot224, align 8
  %v1308 = load i32, ptr %slot224, align 8
  %cv1309 = zext i32 %v1308 to i64
  %cond1310 = icmp ne i64 %cv1309, 0
  br i1 %cond1310, label %bb_rcgdec262, label %bb_rcgslow262
bb_rcgslow262:
  %v1311 = load i64, ptr %slot211, align 8
  %v1312 = load i64, ptr %slot208, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1311, i64 %v1312) nomerge, !dbg !128
  br label %bb_rcgdone262
bb_rcgdec262:
  %v1313 = load i64, ptr %slot220, align 8
  %v1314 = load i64, ptr %slot212, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %rgep1316 = getelementptr i8, ptr %p1315, i64 -24
  store i64 %v1313, ptr %rgep1316, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear262
bb_rcgclear262:
  %v1317 = load i64, ptr %slot208, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  store i64 0, ptr %p1318, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone262
bb_rcgdone262:
  br label %bb_rcslotdone246
bb_rcslotowner246:
  %v1319 = load i64, ptr %slot29, align 8
  store i64 %v1319, ptr %slot225, align 8
  %v1320 = load i64, ptr %slot208, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  %ld1322 = load i64, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1322, ptr %slot226, align 8
  %v1323 = load i64, ptr %slot226, align 8
  %cmp1324 = icmp ne i64 %v1323, 0
  %cv1325 = zext i1 %cmp1324 to i32
  store i32 %cv1325, ptr %slot227, align 8
  %v1326 = load i32, ptr %slot227, align 8
  %cv1327 = zext i32 %v1326 to i64
  %cond1328 = icmp ne i64 %cv1327, 0
  br i1 %cond1328, label %bb_rcgnn277, label %bb_rcgdone277
bb_rcgnn277:
  %v1329 = load i64, ptr %slot226, align 8
  %op1330 = sub i64 %v1329, 16
  store i64 %op1330, ptr %slot228, align 8
  %v1331 = load i64, ptr %slot226, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %rgep1333 = getelementptr i8, ptr %p1332, i64 -16
  %ld1334 = load i64, ptr %rgep1333, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1334, ptr %slot229, align 8
  %v1335 = load i64, ptr %slot229, align 8
  %op1336 = and i64 %v1335, 4611686018427387906
  store i64 %op1336, ptr %slot230, align 8
  %v1337 = load i64, ptr %slot230, align 8
  %cmp1338 = icmp ne i64 %v1337, 0
  %cv1339 = zext i1 %cmp1338 to i32
  store i32 %cv1339, ptr %slot231, align 8
  %v1340 = load i32, ptr %slot231, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcgclear277, label %bb_rcgcounted277
bb_rcgcounted277:
  %v1343 = load i64, ptr %slot226, align 8
  %op1344 = sub i64 %v1343, 32
  store i64 %op1344, ptr %slot232, align 8
  %v1345 = load i64, ptr %slot226, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  %rgep1347 = getelementptr i8, ptr %p1346, i64 -32
  %ld1348 = load i64, ptr %rgep1347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1348, ptr %slot233, align 8
  %v1349 = load i64, ptr %slot233, align 8
  %op1350 = sub i64 %v1349, 1
  store i64 %op1350, ptr %slot234, align 8
  %v1351 = load i64, ptr %slot234, align 8
  %cmp1352 = icmp eq i64 %v1351, 0
  %cv1353 = zext i1 %cmp1352 to i32
  store i32 %cv1353, ptr %slot235, align 8
  %v1354 = load i32, ptr %slot235, align 8
  %cv1355 = zext i32 %v1354 to i64
  %cond1356 = icmp ne i64 %cv1355, 0
  br i1 %cond1356, label %bb_rcglast277, label %bb_rcgdec277
bb_rcglast277:
  %v1357 = load i64, ptr %slot226, align 8
  %op1358 = sub i64 %v1357, 24
  store i64 %op1358, ptr %slot236, align 8
  %v1359 = load i64, ptr %slot226, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %rgep1361 = getelementptr i8, ptr %p1360, i64 -24
  %ld1362 = load i64, ptr %rgep1361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1362, ptr %slot237, align 8
  %v1363 = load i64, ptr %slot237, align 8
  %cmp1364 = icmp ne i64 %v1363, 0
  %cv1365 = zext i1 %cmp1364 to i32
  store i32 %cv1365, ptr %slot238, align 8
  %v1366 = load i32, ptr %slot238, align 8
  %cv1367 = zext i32 %v1366 to i64
  %cond1368 = icmp ne i64 %cv1367, 0
  br i1 %cond1368, label %bb_rcgdec277, label %bb_rcgslow277
bb_rcgslow277:
  %v1369 = load i64, ptr %slot225, align 8
  %v1370 = load i64, ptr %slot208, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1369, i64 %v1370) nomerge, !dbg !128
  br label %bb_rcgdone277
bb_rcgdec277:
  %v1371 = load i64, ptr %slot234, align 8
  %v1372 = load i64, ptr %slot226, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  %rgep1374 = getelementptr i8, ptr %p1373, i64 -32
  store i64 %v1371, ptr %rgep1374, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear277
bb_rcgclear277:
  %v1375 = load i64, ptr %slot208, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i64 0, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone277
bb_rcgdone277:
  br label %bb_rcslotdone246
bb_rcslotdone246:
  %v1377 = load i64, ptr %slot21, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i64, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1379, ptr %slot239, align 8
  %v1380 = load i64, ptr %slot239, align 8
  %v1381 = load i64, ptr %slot22, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  store i64 %v1380, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  %v1383 = load i64, ptr %slot23, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i64 65535, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot23, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  %ld1387 = load i64, ptr %p1386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1387, ptr %slot240, align 8
  %v1388 = load i64, ptr %slot22, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i64, ptr %p1389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1390, ptr %slot241, align 8
  %v1391 = load i64, ptr %slot241, align 8
  %v1392 = load i64, ptr %slot240, align 8
  %cmp1393 = icmp sgt i64 %v1391, %v1392
  %cv1394 = zext i1 %cmp1393 to i64
  store i64 %cv1394, ptr %slot242, align 8
  %v1395 = load i64, ptr %slot242, align 8
  %v1396 = load i64, ptr %slot22, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i64 %v1395, ptr %p1397, align 8, !alias.scope !3, !noalias !4
  %v1398 = load i64, ptr %slot22, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i64, ptr %p1399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1400, ptr %slot243, align 8
  %v1401 = load i64, ptr %slot243, align 8
  %cond1402 = icmp ne i64 %v1401, 0
  br i1 %cond1402, label %bb_next286, label %bb_i23
bb_next286:
  %v1403 = load i64, ptr %slot18, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  %ld1405 = load i64, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1405, ptr %slot244, align 8
  %v1406 = load i64, ptr %slot244, align 8
  %v1407 = load i64, ptr %slot22, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  store i64 %v1406, ptr %p1408, align 8, !alias.scope !3, !noalias !4
  %p1409 = inttoptr i64 ptrtoint (ptr @myl_lit_d5b63b07f087fe690f365e8090b26dc7b46c7ec5453c103761aac2800eadaf8f to i64) to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1410, ptr %slot245, align 8
  %v1411 = load i64, ptr %slot245, align 8
  %v1412 = load i64, ptr %slot23, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  store i64 %v1411, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  %v1414 = load i64, ptr %slot23, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  %ld1416 = load i64, ptr %p1415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1416, ptr %slot246, align 8
  %v1417 = load i64, ptr %slot246, align 8
  %v1418 = load i64, ptr %slot16, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  store i64 %v1417, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  %v1420 = load i64, ptr %slot16, align 8
  store i64 %v1420, ptr %slot247, align 8
  %v1421 = load i64, ptr %slot17, align 8
  store i64 %v1421, ptr %slot248, align 8
  %v1422 = load i64, ptr %slot247, align 8
  %v1423 = load i64, ptr %slot248, align 8
  %p1424 = inttoptr i64 %v1422 to ptr
  %p1425 = inttoptr i64 %v1423 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1425, ptr %p1424, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot12, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i32 2, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  %v1428 = load i64, ptr %slot11, align 8
  %p1429 = inttoptr i64 %v1428 to ptr
  store i32 1, ptr %p1429, align 4, !alias.scope !3, !noalias !4
  %v1430 = load i64, ptr %slot14, align 8
  store i64 %v1430, ptr %slot249, align 8
  %v1431 = load i64, ptr %slot17, align 8
  store i64 %v1431, ptr %slot250, align 8
  %v1432 = load i64, ptr %slot250, align 8
  %v1433 = load i64, ptr %slot249, align 8
  %p1434 = inttoptr i64 %v1432 to ptr
  %p1435 = inttoptr i64 %v1433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1435, ptr %p1434, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1436 = load i64, ptr %slot10, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i32 2, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot12, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  %ld1440 = load i32, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1440, ptr %slot251, align 8
  %v1441 = load i32, ptr %slot251, align 8
  %v1442 = load i64, ptr %slot10, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i32 %v1441, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot11, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 0, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot9, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i32 1, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot249, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  %ld1450 = load i64, ptr %p1449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1450, ptr %slot252, align 8
  %v1451 = load i64, ptr %slot252, align 8
  %v1452 = load i64, ptr %slot23, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i64 %v1451, ptr %p1453, align 8, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot22, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i64, ptr %p1455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1456, ptr %slot253, align 8
  %v1457 = load i64, ptr %slot23, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  %ld1459 = load i64, ptr %p1458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1459, ptr %slot254, align 8
  %v1460 = load i64, ptr %slot1, align 8
  %v1461 = load i64, ptr %slot253, align 8
  %v1462 = load i64, ptr %slot254, align 8
  %call1463 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v1460, i64 %v1461, i64 %v1462) nomerge, !dbg !130
  store i64 %call1463, ptr %slot255, align 8
  %v1464 = load i64, ptr %slot255, align 8
  %v1465 = load i64, ptr %slot22, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i64 %v1464, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot7, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %ld1469 = load i32, ptr %p1468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1469, ptr %slot256, align 8
  %v1470 = load i32, ptr %slot256, align 8
  %cv1471 = zext i32 %v1470 to i64
  %cond1472 = icmp ne i64 %cv1471, 0
  br i1 %cond1472, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v1473 = load i64, ptr %slot7, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i32 0, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot13, align 8
  store i64 %v1475, ptr %slot257, align 8
  %v1476 = load i64, ptr %slot8, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  %ld1478 = load i32, ptr %p1477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1478, ptr %slot258, align 8
  %v1479 = load i32, ptr %slot258, align 8
  %op1480 = and i32 %v1479, 28
  store i32 %op1480, ptr %slot259, align 8
  %v1481 = load i32, ptr %slot259, align 8
  %cv1482 = zext i32 %v1481 to i64
  %cond1483 = icmp ne i64 %cv1482, 0
  br i1 %cond1483, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v1484 = load i64, ptr %slot29, align 8
  store i64 %v1484, ptr %slot260, align 8
  %v1485 = load i64, ptr %slot260, align 8
  %v1486 = load i64, ptr %slot257, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1485, i64 %v1486) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v1487 = load i64, ptr %slot29, align 8
  store i64 %v1487, ptr %slot261, align 8
  %v1488 = load i64, ptr %slot261, align 8
  %v1489 = load i64, ptr %slot257, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1488, i64 %v1489) nomerge, !dbg !130
  br label %bb_rcslotdone308
bb_rcslotdone308:
  %v1490 = load i64, ptr %slot9, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  %ld1492 = load i32, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1492, ptr %slot262, align 8
  %v1493 = load i32, ptr %slot262, align 8
  %cv1494 = zext i32 %v1493 to i64
  %cond1495 = icmp ne i64 %cv1494, 0
  br i1 %cond1495, label %bb_rcslotdrop317, label %bb_rcslotdone317
bb_rcslotdrop317:
  %v1496 = load i64, ptr %slot9, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  store i32 0, ptr %p1497, align 4, !alias.scope !3, !noalias !4
  %v1498 = load i64, ptr %slot14, align 8
  store i64 %v1498, ptr %slot263, align 8
  %v1499 = load i64, ptr %slot10, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %ld1501 = load i32, ptr %p1500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1501, ptr %slot264, align 8
  %v1502 = load i32, ptr %slot264, align 8
  %op1503 = and i32 %v1502, 28
  store i32 %op1503, ptr %slot265, align 8
  %v1504 = load i32, ptr %slot265, align 8
  %cv1505 = zext i32 %v1504 to i64
  %cond1506 = icmp ne i64 %cv1505, 0
  br i1 %cond1506, label %bb_rcslotrole317, label %bb_rcslotowner317
bb_rcslotrole317:
  %v1507 = load i64, ptr %slot29, align 8
  store i64 %v1507, ptr %slot266, align 8
  %v1508 = load i64, ptr %slot263, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i64, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1510, ptr %slot267, align 8
  %v1511 = load i64, ptr %slot267, align 8
  %cmp1512 = icmp ne i64 %v1511, 0
  %cv1513 = zext i1 %cmp1512 to i32
  store i32 %cv1513, ptr %slot268, align 8
  %v1514 = load i32, ptr %slot268, align 8
  %cv1515 = zext i32 %v1514 to i64
  %cond1516 = icmp ne i64 %cv1515, 0
  br i1 %cond1516, label %bb_rcgnn333, label %bb_rcgdone333
bb_rcgnn333:
  %v1517 = load i64, ptr %slot267, align 8
  %op1518 = sub i64 %v1517, 16
  store i64 %op1518, ptr %slot269, align 8
  %v1519 = load i64, ptr %slot267, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %rgep1521 = getelementptr i8, ptr %p1520, i64 -16
  %ld1522 = load i64, ptr %rgep1521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1522, ptr %slot270, align 8
  %v1523 = load i64, ptr %slot270, align 8
  %op1524 = and i64 %v1523, 4611686018427387906
  store i64 %op1524, ptr %slot271, align 8
  %v1525 = load i64, ptr %slot271, align 8
  %cmp1526 = icmp ne i64 %v1525, 0
  %cv1527 = zext i1 %cmp1526 to i32
  store i32 %cv1527, ptr %slot272, align 8
  %v1528 = load i32, ptr %slot272, align 8
  %cv1529 = zext i32 %v1528 to i64
  %cond1530 = icmp ne i64 %cv1529, 0
  br i1 %cond1530, label %bb_rcgclear333, label %bb_rcgcounted333
bb_rcgcounted333:
  %v1531 = load i64, ptr %slot267, align 8
  %op1532 = sub i64 %v1531, 24
  store i64 %op1532, ptr %slot273, align 8
  %v1533 = load i64, ptr %slot267, align 8
  %p1534 = inttoptr i64 %v1533 to ptr
  %rgep1535 = getelementptr i8, ptr %p1534, i64 -24
  %ld1536 = load i64, ptr %rgep1535, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1536, ptr %slot274, align 8
  %v1537 = load i64, ptr %slot274, align 8
  %op1538 = sub i64 %v1537, 1
  store i64 %op1538, ptr %slot275, align 8
  %v1539 = load i64, ptr %slot275, align 8
  %cmp1540 = icmp eq i64 %v1539, 0
  %cv1541 = zext i1 %cmp1540 to i32
  store i32 %cv1541, ptr %slot276, align 8
  %v1542 = load i32, ptr %slot276, align 8
  %cv1543 = zext i32 %v1542 to i64
  %cond1544 = icmp ne i64 %cv1543, 0
  br i1 %cond1544, label %bb_rcglast333, label %bb_rcgdec333
bb_rcglast333:
  %v1545 = load i64, ptr %slot267, align 8
  %op1546 = sub i64 %v1545, 32
  store i64 %op1546, ptr %slot277, align 8
  %v1547 = load i64, ptr %slot267, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  %rgep1549 = getelementptr i8, ptr %p1548, i64 -32
  %ld1550 = load i64, ptr %rgep1549, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1550, ptr %slot278, align 8
  %v1551 = load i64, ptr %slot278, align 8
  %cmp1552 = icmp ne i64 %v1551, 0
  %cv1553 = zext i1 %cmp1552 to i32
  store i32 %cv1553, ptr %slot279, align 8
  %v1554 = load i32, ptr %slot279, align 8
  %cv1555 = zext i32 %v1554 to i64
  %cond1556 = icmp ne i64 %cv1555, 0
  br i1 %cond1556, label %bb_rcgdec333, label %bb_rcgslow333
bb_rcgslow333:
  %v1557 = load i64, ptr %slot266, align 8
  %v1558 = load i64, ptr %slot263, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1557, i64 %v1558) nomerge, !dbg !130
  br label %bb_rcgdone333
bb_rcgdec333:
  %v1559 = load i64, ptr %slot275, align 8
  %v1560 = load i64, ptr %slot267, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %rgep1562 = getelementptr i8, ptr %p1561, i64 -24
  store i64 %v1559, ptr %rgep1562, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear333
bb_rcgclear333:
  %v1563 = load i64, ptr %slot263, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i64 0, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone333
bb_rcgdone333:
  br label %bb_rcslotdone317
bb_rcslotowner317:
  %v1565 = load i64, ptr %slot29, align 8
  store i64 %v1565, ptr %slot280, align 8
  %v1566 = load i64, ptr %slot263, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  %ld1568 = load i64, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1568, ptr %slot281, align 8
  %v1569 = load i64, ptr %slot281, align 8
  %cmp1570 = icmp ne i64 %v1569, 0
  %cv1571 = zext i1 %cmp1570 to i32
  store i32 %cv1571, ptr %slot282, align 8
  %v1572 = load i32, ptr %slot282, align 8
  %cv1573 = zext i32 %v1572 to i64
  %cond1574 = icmp ne i64 %cv1573, 0
  br i1 %cond1574, label %bb_rcgnn348, label %bb_rcgdone348
bb_rcgnn348:
  %v1575 = load i64, ptr %slot281, align 8
  %op1576 = sub i64 %v1575, 16
  store i64 %op1576, ptr %slot283, align 8
  %v1577 = load i64, ptr %slot281, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %rgep1579 = getelementptr i8, ptr %p1578, i64 -16
  %ld1580 = load i64, ptr %rgep1579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1580, ptr %slot284, align 8
  %v1581 = load i64, ptr %slot284, align 8
  %op1582 = and i64 %v1581, 4611686018427387906
  store i64 %op1582, ptr %slot285, align 8
  %v1583 = load i64, ptr %slot285, align 8
  %cmp1584 = icmp ne i64 %v1583, 0
  %cv1585 = zext i1 %cmp1584 to i32
  store i32 %cv1585, ptr %slot286, align 8
  %v1586 = load i32, ptr %slot286, align 8
  %cv1587 = zext i32 %v1586 to i64
  %cond1588 = icmp ne i64 %cv1587, 0
  br i1 %cond1588, label %bb_rcgclear348, label %bb_rcgcounted348
bb_rcgcounted348:
  %v1589 = load i64, ptr %slot281, align 8
  %op1590 = sub i64 %v1589, 32
  store i64 %op1590, ptr %slot287, align 8
  %v1591 = load i64, ptr %slot281, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  %rgep1593 = getelementptr i8, ptr %p1592, i64 -32
  %ld1594 = load i64, ptr %rgep1593, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1594, ptr %slot288, align 8
  %v1595 = load i64, ptr %slot288, align 8
  %op1596 = sub i64 %v1595, 1
  store i64 %op1596, ptr %slot289, align 8
  %v1597 = load i64, ptr %slot289, align 8
  %cmp1598 = icmp eq i64 %v1597, 0
  %cv1599 = zext i1 %cmp1598 to i32
  store i32 %cv1599, ptr %slot290, align 8
  %v1600 = load i32, ptr %slot290, align 8
  %cv1601 = zext i32 %v1600 to i64
  %cond1602 = icmp ne i64 %cv1601, 0
  br i1 %cond1602, label %bb_rcglast348, label %bb_rcgdec348
bb_rcglast348:
  %v1603 = load i64, ptr %slot281, align 8
  %op1604 = sub i64 %v1603, 24
  store i64 %op1604, ptr %slot291, align 8
  %v1605 = load i64, ptr %slot281, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  %rgep1607 = getelementptr i8, ptr %p1606, i64 -24
  %ld1608 = load i64, ptr %rgep1607, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1608, ptr %slot292, align 8
  %v1609 = load i64, ptr %slot292, align 8
  %cmp1610 = icmp ne i64 %v1609, 0
  %cv1611 = zext i1 %cmp1610 to i32
  store i32 %cv1611, ptr %slot293, align 8
  %v1612 = load i32, ptr %slot293, align 8
  %cv1613 = zext i32 %v1612 to i64
  %cond1614 = icmp ne i64 %cv1613, 0
  br i1 %cond1614, label %bb_rcgdec348, label %bb_rcgslow348
bb_rcgslow348:
  %v1615 = load i64, ptr %slot280, align 8
  %v1616 = load i64, ptr %slot263, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1615, i64 %v1616) nomerge, !dbg !130
  br label %bb_rcgdone348
bb_rcgdec348:
  %v1617 = load i64, ptr %slot289, align 8
  %v1618 = load i64, ptr %slot281, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %rgep1620 = getelementptr i8, ptr %p1619, i64 -32
  store i64 %v1617, ptr %rgep1620, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear348
bb_rcgclear348:
  %v1621 = load i64, ptr %slot263, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i64 0, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone348
bb_rcgdone348:
  br label %bb_rcslotdone317
bb_rcslotdone317:
  br label %bb_i23
bb_i23:
  %v1623 = load i64, ptr %slot18, align 8
  %p1624 = inttoptr i64 %v1623 to ptr
  %ld1625 = load i64, ptr %p1624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1625, ptr %slot294, align 8
  %v1626 = load i64, ptr %slot294, align 8
  %v1627 = load i64, ptr %slot22, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  store i64 %v1626, ptr %p1628, align 8, !alias.scope !3, !noalias !4
  %v1629 = load i64, ptr %slot21, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i64, ptr %p1630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1631, ptr %slot295, align 8
  %v1632 = load i64, ptr %slot295, align 8
  %v1633 = load i64, ptr %slot23, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 %v1632, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot24, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  store i64 8, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  %v1637 = load i64, ptr %slot24, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %ld1639 = load i64, ptr %p1638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1639, ptr %slot296, align 8
  %v1640 = load i64, ptr %slot23, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  %ld1642 = load i64, ptr %p1641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1642, ptr %slot297, align 8
  %v1643 = load i64, ptr %slot296, align 8
  %cmp1644 = icmp sge i64 %v1643, 64
  %cv1645 = zext i1 %cmp1644 to i64
  store i64 %cv1645, ptr %slot298, align 8
  %v1646 = load i64, ptr %slot296, align 8
  %cmp1647 = icmp slt i64 %v1646, 0
  %cv1648 = zext i1 %cmp1647 to i64
  store i64 %cv1648, ptr %slot299, align 8
  %v1649 = load i64, ptr %slot298, align 8
  %v1650 = load i64, ptr %slot299, align 8
  %op1651 = or i64 %v1649, %v1650
  store i64 %op1651, ptr %slot300, align 8
  %v1652 = load i64, ptr %slot300, align 8
  %cond1653 = icmp ne i64 %v1652, 0
  br i1 %cond1653, label %bb_shift_invalid356, label %bb_shift_valid356
bb_shift_invalid356:
  %v1654 = load i64, ptr %slot1, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %v1656 = load i64, ptr %slot297, align 8
  %v1657 = load i64, ptr %slot296, align 8
  %call1658 = call i64 @myl_qbe_int_binary(ptr %p1655, i64 19, i64 1, i64 64, i64 %v1656, i64 %v1657) nomerge, !dbg !132
  unreachable
bb_shift_valid356:
  %v1659 = load i64, ptr %slot297, align 8
  %v1660 = load i64, ptr %slot296, align 8
  %op1661 = ashr i64 %v1659, %v1660
  store i64 %op1661, ptr %slot301, align 8
  %v1662 = load i64, ptr %slot301, align 8
  %v1663 = load i64, ptr %slot23, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i64 %v1662, ptr %p1664, align 8, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot24, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  store i64 255, ptr %p1666, align 8, !alias.scope !3, !noalias !4
  %v1667 = load i64, ptr %slot24, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %ld1669 = load i64, ptr %p1668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1669, ptr %slot302, align 8
  %v1670 = load i64, ptr %slot23, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  %ld1672 = load i64, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1672, ptr %slot303, align 8
  %v1673 = load i64, ptr %slot303, align 8
  %v1674 = load i64, ptr %slot302, align 8
  %op1675 = and i64 %v1673, %v1674
  store i64 %op1675, ptr %slot304, align 8
  %v1676 = load i64, ptr %slot304, align 8
  %v1677 = load i64, ptr %slot23, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i64 %v1676, ptr %p1678, align 8, !alias.scope !3, !noalias !4
  %v1679 = load i64, ptr %slot22, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %ld1681 = load i64, ptr %p1680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1681, ptr %slot305, align 8
  %v1682 = load i64, ptr %slot23, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %ld1684 = load i64, ptr %p1683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1684, ptr %slot306, align 8
  %v1685 = load i64, ptr %slot1, align 8
  %v1686 = load i64, ptr %slot305, align 8
  %v1687 = load i64, ptr %slot306, align 8
  %call1688 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v1685, i64 %v1686, i64 %v1687) nomerge, !dbg !134
  store i64 %call1688, ptr %slot307, align 8
  %v1689 = load i64, ptr %slot307, align 8
  %v1690 = load i64, ptr %slot22, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i64 %v1689, ptr %p1691, align 8, !alias.scope !3, !noalias !4
  %v1692 = load i64, ptr %slot7, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i32, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1694, ptr %slot308, align 8
  %v1695 = load i32, ptr %slot308, align 8
  %cv1696 = zext i32 %v1695 to i64
  %cond1697 = icmp ne i64 %cv1696, 0
  br i1 %cond1697, label %bb_rcslotdrop368, label %bb_rcslotdone368
bb_rcslotdrop368:
  %v1698 = load i64, ptr %slot7, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  store i32 0, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  %v1700 = load i64, ptr %slot13, align 8
  store i64 %v1700, ptr %slot309, align 8
  %v1701 = load i64, ptr %slot8, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %ld1703 = load i32, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1703, ptr %slot310, align 8
  %v1704 = load i32, ptr %slot310, align 8
  %op1705 = and i32 %v1704, 28
  store i32 %op1705, ptr %slot311, align 8
  %v1706 = load i32, ptr %slot311, align 8
  %cv1707 = zext i32 %v1706 to i64
  %cond1708 = icmp ne i64 %cv1707, 0
  br i1 %cond1708, label %bb_rcslotrole368, label %bb_rcslotowner368
bb_rcslotrole368:
  %v1709 = load i64, ptr %slot29, align 8
  store i64 %v1709, ptr %slot312, align 8
  %v1710 = load i64, ptr %slot312, align 8
  %v1711 = load i64, ptr %slot309, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1710, i64 %v1711) nomerge, !dbg !134
  br label %bb_rcslotdone368
bb_rcslotowner368:
  %v1712 = load i64, ptr %slot29, align 8
  store i64 %v1712, ptr %slot313, align 8
  %v1713 = load i64, ptr %slot313, align 8
  %v1714 = load i64, ptr %slot309, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1713, i64 %v1714) nomerge, !dbg !134
  br label %bb_rcslotdone368
bb_rcslotdone368:
  %v1715 = load i64, ptr %slot18, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i64, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1717, ptr %slot314, align 8
  %v1718 = load i64, ptr %slot314, align 8
  %v1719 = load i64, ptr %slot22, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i64 %v1718, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot21, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %ld1723 = load i64, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1723, ptr %slot315, align 8
  %v1724 = load i64, ptr %slot315, align 8
  %v1725 = load i64, ptr %slot23, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i64 %v1724, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot24, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i64 255, ptr %p1728, align 8, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot24, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i64, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1731, ptr %slot316, align 8
  %v1732 = load i64, ptr %slot23, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  %ld1734 = load i64, ptr %p1733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1734, ptr %slot317, align 8
  %v1735 = load i64, ptr %slot317, align 8
  %v1736 = load i64, ptr %slot316, align 8
  %op1737 = and i64 %v1735, %v1736
  store i64 %op1737, ptr %slot318, align 8
  %v1738 = load i64, ptr %slot318, align 8
  %v1739 = load i64, ptr %slot23, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i64 %v1738, ptr %p1740, align 8, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot22, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %ld1743 = load i64, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1743, ptr %slot319, align 8
  %v1744 = load i64, ptr %slot23, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %ld1746 = load i64, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1746, ptr %slot320, align 8
  %v1747 = load i64, ptr %slot1, align 8
  %v1748 = load i64, ptr %slot319, align 8
  %v1749 = load i64, ptr %slot320, align 8
  %call1750 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v1747, i64 %v1748, i64 %v1749) nomerge, !dbg !136
  store i64 %call1750, ptr %slot321, align 8
  %v1751 = load i64, ptr %slot321, align 8
  %v1752 = load i64, ptr %slot22, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i64 %v1751, ptr %p1753, align 8, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot7, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %ld1756 = load i32, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1756, ptr %slot322, align 8
  %v1757 = load i32, ptr %slot322, align 8
  %cv1758 = zext i32 %v1757 to i64
  %cond1759 = icmp ne i64 %cv1758, 0
  br i1 %cond1759, label %bb_rcslotdrop385, label %bb_rcslotdone385
bb_rcslotdrop385:
  %v1760 = load i64, ptr %slot7, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  store i32 0, ptr %p1761, align 4, !alias.scope !3, !noalias !4
  %v1762 = load i64, ptr %slot13, align 8
  store i64 %v1762, ptr %slot323, align 8
  %v1763 = load i64, ptr %slot8, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  %ld1765 = load i32, ptr %p1764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1765, ptr %slot324, align 8
  %v1766 = load i32, ptr %slot324, align 8
  %op1767 = and i32 %v1766, 28
  store i32 %op1767, ptr %slot325, align 8
  %v1768 = load i32, ptr %slot325, align 8
  %cv1769 = zext i32 %v1768 to i64
  %cond1770 = icmp ne i64 %cv1769, 0
  br i1 %cond1770, label %bb_rcslotrole385, label %bb_rcslotowner385
bb_rcslotrole385:
  %v1771 = load i64, ptr %slot29, align 8
  store i64 %v1771, ptr %slot326, align 8
  %v1772 = load i64, ptr %slot326, align 8
  %v1773 = load i64, ptr %slot323, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1772, i64 %v1773) nomerge, !dbg !136
  br label %bb_rcslotdone385
bb_rcslotowner385:
  %v1774 = load i64, ptr %slot29, align 8
  store i64 %v1774, ptr %slot327, align 8
  %v1775 = load i64, ptr %slot327, align 8
  %v1776 = load i64, ptr %slot323, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1775, i64 %v1776) nomerge, !dbg !136
  br label %bb_rcslotdone385
bb_rcslotdone385:
  %v1777 = load i64, ptr %slot22, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  store i64 0, ptr %p1778, align 8, !alias.scope !3, !noalias !4
  %v1779 = load i64, ptr %slot22, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %ld1781 = load i64, ptr %p1780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1781, ptr %slot328, align 8
  %v1782 = load i64, ptr %slot7, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  %ld1784 = load i32, ptr %p1783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1784, ptr %slot329, align 8
  %v1785 = load i32, ptr %slot329, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcslotdrop395, label %bb_rcslotdone395
bb_rcslotdrop395:
  %v1788 = load i64, ptr %slot7, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  store i32 0, ptr %p1789, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone395
bb_rcslotdone395:
  %v1790 = load i64, ptr %slot5, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  %ld1792 = load i32, ptr %p1791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1792, ptr %slot330, align 8
  %v1793 = load i32, ptr %slot330, align 8
  %cv1794 = zext i32 %v1793 to i64
  %cond1795 = icmp ne i64 %cv1794, 0
  br i1 %cond1795, label %bb_rcslotdrop398, label %bb_rcslotdone398
bb_rcslotdrop398:
  %v1796 = load i64, ptr %slot5, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  store i32 0, ptr %p1797, align 4, !alias.scope !3, !noalias !4
  %v1798 = load i64, ptr %slot20, align 8
  store i64 %v1798, ptr %slot331, align 8
  %v1799 = load i64, ptr %slot6, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  %ld1801 = load i32, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1801, ptr %slot332, align 8
  %v1802 = load i32, ptr %slot332, align 8
  %op1803 = and i32 %v1802, 28
  store i32 %op1803, ptr %slot333, align 8
  %v1804 = load i32, ptr %slot333, align 8
  %cv1805 = zext i32 %v1804 to i64
  %cond1806 = icmp ne i64 %cv1805, 0
  br i1 %cond1806, label %bb_rcslotrole398, label %bb_rcslotowner398
bb_rcslotrole398:
  %v1807 = load i64, ptr %slot29, align 8
  store i64 %v1807, ptr %slot334, align 8
  %v1808 = load i64, ptr %slot331, align 8
  %p1809 = inttoptr i64 %v1808 to ptr
  %ld1810 = load i64, ptr %p1809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1810, ptr %slot335, align 8
  %v1811 = load i64, ptr %slot335, align 8
  %cmp1812 = icmp ne i64 %v1811, 0
  %cv1813 = zext i1 %cmp1812 to i32
  store i32 %cv1813, ptr %slot336, align 8
  %v1814 = load i32, ptr %slot336, align 8
  %cv1815 = zext i32 %v1814 to i64
  %cond1816 = icmp ne i64 %cv1815, 0
  br i1 %cond1816, label %bb_rcgnn414, label %bb_rcgdone414
bb_rcgnn414:
  %v1817 = load i64, ptr %slot335, align 8
  %op1818 = sub i64 %v1817, 16
  store i64 %op1818, ptr %slot337, align 8
  %v1819 = load i64, ptr %slot335, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  %rgep1821 = getelementptr i8, ptr %p1820, i64 -16
  %ld1822 = load i64, ptr %rgep1821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1822, ptr %slot338, align 8
  %v1823 = load i64, ptr %slot338, align 8
  %op1824 = and i64 %v1823, 4611686018427387906
  store i64 %op1824, ptr %slot339, align 8
  %v1825 = load i64, ptr %slot339, align 8
  %cmp1826 = icmp ne i64 %v1825, 0
  %cv1827 = zext i1 %cmp1826 to i32
  store i32 %cv1827, ptr %slot340, align 8
  %v1828 = load i32, ptr %slot340, align 8
  %cv1829 = zext i32 %v1828 to i64
  %cond1830 = icmp ne i64 %cv1829, 0
  br i1 %cond1830, label %bb_rcgclear414, label %bb_rcgcounted414
bb_rcgcounted414:
  %v1831 = load i64, ptr %slot335, align 8
  %op1832 = sub i64 %v1831, 24
  store i64 %op1832, ptr %slot341, align 8
  %v1833 = load i64, ptr %slot335, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %rgep1835 = getelementptr i8, ptr %p1834, i64 -24
  %ld1836 = load i64, ptr %rgep1835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1836, ptr %slot342, align 8
  %v1837 = load i64, ptr %slot342, align 8
  %op1838 = sub i64 %v1837, 1
  store i64 %op1838, ptr %slot343, align 8
  %v1839 = load i64, ptr %slot343, align 8
  %cmp1840 = icmp eq i64 %v1839, 0
  %cv1841 = zext i1 %cmp1840 to i32
  store i32 %cv1841, ptr %slot344, align 8
  %v1842 = load i32, ptr %slot344, align 8
  %cv1843 = zext i32 %v1842 to i64
  %cond1844 = icmp ne i64 %cv1843, 0
  br i1 %cond1844, label %bb_rcglast414, label %bb_rcgdec414
bb_rcglast414:
  %v1845 = load i64, ptr %slot335, align 8
  %op1846 = sub i64 %v1845, 32
  store i64 %op1846, ptr %slot345, align 8
  %v1847 = load i64, ptr %slot335, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %rgep1849 = getelementptr i8, ptr %p1848, i64 -32
  %ld1850 = load i64, ptr %rgep1849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1850, ptr %slot346, align 8
  %v1851 = load i64, ptr %slot346, align 8
  %cmp1852 = icmp ne i64 %v1851, 0
  %cv1853 = zext i1 %cmp1852 to i32
  store i32 %cv1853, ptr %slot347, align 8
  %v1854 = load i32, ptr %slot347, align 8
  %cv1855 = zext i32 %v1854 to i64
  %cond1856 = icmp ne i64 %cv1855, 0
  br i1 %cond1856, label %bb_rcgdec414, label %bb_rcgslow414
bb_rcgslow414:
  %v1857 = load i64, ptr %slot334, align 8
  %v1858 = load i64, ptr %slot331, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1857, i64 %v1858) nomerge, !dbg !138
  br label %bb_rcgdone414
bb_rcgdec414:
  %v1859 = load i64, ptr %slot343, align 8
  %v1860 = load i64, ptr %slot335, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %rgep1862 = getelementptr i8, ptr %p1861, i64 -24
  store i64 %v1859, ptr %rgep1862, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear414
bb_rcgclear414:
  %v1863 = load i64, ptr %slot331, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  store i64 0, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone414
bb_rcgdone414:
  br label %bb_rcslotdone398
bb_rcslotowner398:
  %v1865 = load i64, ptr %slot29, align 8
  store i64 %v1865, ptr %slot348, align 8
  %v1866 = load i64, ptr %slot331, align 8
  %p1867 = inttoptr i64 %v1866 to ptr
  %ld1868 = load i64, ptr %p1867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1868, ptr %slot349, align 8
  %v1869 = load i64, ptr %slot349, align 8
  %cmp1870 = icmp ne i64 %v1869, 0
  %cv1871 = zext i1 %cmp1870 to i32
  store i32 %cv1871, ptr %slot350, align 8
  %v1872 = load i32, ptr %slot350, align 8
  %cv1873 = zext i32 %v1872 to i64
  %cond1874 = icmp ne i64 %cv1873, 0
  br i1 %cond1874, label %bb_rcgnn429, label %bb_rcgdone429
bb_rcgnn429:
  %v1875 = load i64, ptr %slot349, align 8
  %op1876 = sub i64 %v1875, 16
  store i64 %op1876, ptr %slot351, align 8
  %v1877 = load i64, ptr %slot349, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -16
  %ld1880 = load i64, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1880, ptr %slot352, align 8
  %v1881 = load i64, ptr %slot352, align 8
  %op1882 = and i64 %v1881, 4611686018427387906
  store i64 %op1882, ptr %slot353, align 8
  %v1883 = load i64, ptr %slot353, align 8
  %cmp1884 = icmp ne i64 %v1883, 0
  %cv1885 = zext i1 %cmp1884 to i32
  store i32 %cv1885, ptr %slot354, align 8
  %v1886 = load i32, ptr %slot354, align 8
  %cv1887 = zext i32 %v1886 to i64
  %cond1888 = icmp ne i64 %cv1887, 0
  br i1 %cond1888, label %bb_rcgclear429, label %bb_rcgcounted429
bb_rcgcounted429:
  %v1889 = load i64, ptr %slot349, align 8
  %op1890 = sub i64 %v1889, 32
  store i64 %op1890, ptr %slot355, align 8
  %v1891 = load i64, ptr %slot349, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %rgep1893 = getelementptr i8, ptr %p1892, i64 -32
  %ld1894 = load i64, ptr %rgep1893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1894, ptr %slot356, align 8
  %v1895 = load i64, ptr %slot356, align 8
  %op1896 = sub i64 %v1895, 1
  store i64 %op1896, ptr %slot357, align 8
  %v1897 = load i64, ptr %slot357, align 8
  %cmp1898 = icmp eq i64 %v1897, 0
  %cv1899 = zext i1 %cmp1898 to i32
  store i32 %cv1899, ptr %slot358, align 8
  %v1900 = load i32, ptr %slot358, align 8
  %cv1901 = zext i32 %v1900 to i64
  %cond1902 = icmp ne i64 %cv1901, 0
  br i1 %cond1902, label %bb_rcglast429, label %bb_rcgdec429
bb_rcglast429:
  %v1903 = load i64, ptr %slot349, align 8
  %op1904 = sub i64 %v1903, 24
  store i64 %op1904, ptr %slot359, align 8
  %v1905 = load i64, ptr %slot349, align 8
  %p1906 = inttoptr i64 %v1905 to ptr
  %rgep1907 = getelementptr i8, ptr %p1906, i64 -24
  %ld1908 = load i64, ptr %rgep1907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1908, ptr %slot360, align 8
  %v1909 = load i64, ptr %slot360, align 8
  %cmp1910 = icmp ne i64 %v1909, 0
  %cv1911 = zext i1 %cmp1910 to i32
  store i32 %cv1911, ptr %slot361, align 8
  %v1912 = load i32, ptr %slot361, align 8
  %cv1913 = zext i32 %v1912 to i64
  %cond1914 = icmp ne i64 %cv1913, 0
  br i1 %cond1914, label %bb_rcgdec429, label %bb_rcgslow429
bb_rcgslow429:
  %v1915 = load i64, ptr %slot348, align 8
  %v1916 = load i64, ptr %slot331, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1915, i64 %v1916) nomerge, !dbg !138
  br label %bb_rcgdone429
bb_rcgdec429:
  %v1917 = load i64, ptr %slot357, align 8
  %v1918 = load i64, ptr %slot349, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  %rgep1920 = getelementptr i8, ptr %p1919, i64 -32
  store i64 %v1917, ptr %rgep1920, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear429
bb_rcgclear429:
  %v1921 = load i64, ptr %slot331, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i64 0, ptr %p1922, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone429
bb_rcgdone429:
  br label %bb_rcslotdone398
bb_rcslotdone398:
  %v1923 = load i64, ptr %slot328, align 8
  ret i64 %v1923
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_d5b63b07f087fe690f365e8090b26dc7b46c7ec5453c103761aac2800eadaf8f = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8, i64, i64)
declare i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64, i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_int_binary(ptr, i64, i64, i64, i64, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b", linkageName: "myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1730719892153165214, i64 0, !"myl_f_b3e889779fc98fd061179f8a5fef0414c5d292cc4c6fb2b8f897e67456241b4b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!124 = !DILocation(line: 12, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!126 = !DILocation(line: 14, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!128 = !DILocation(line: 15, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!130 = !DILocation(line: 22, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!132 = !DILocation(line: 27, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!134 = !DILocation(line: 30, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
