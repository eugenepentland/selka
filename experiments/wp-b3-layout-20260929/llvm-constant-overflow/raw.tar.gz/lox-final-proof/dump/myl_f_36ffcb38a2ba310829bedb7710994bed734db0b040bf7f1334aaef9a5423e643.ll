target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %callresult60 = alloca [48 x i8], align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %callresult195 = alloca [16 x i8], align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %callresult244 = alloca [48 x i8], align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v426 = load i64, ptr %slot1, align 8
  %op427 = add i64 %v426, 32
  store i64 %op427, ptr %slot3, align 8
  %mem428 = alloca i8, i64 16, align 8
  %ptr429 = ptrtoint ptr %mem428 to i64
  store i64 %ptr429, ptr %slot4, align 8
  %mem430 = alloca i8, i64 8, align 8
  %ptr431 = ptrtoint ptr %mem430 to i64
  store i64 %ptr431, ptr %slot5, align 8
  %mem432 = alloca i8, i64 8, align 8
  %ptr433 = ptrtoint ptr %mem432 to i64
  store i64 %ptr433, ptr %slot6, align 8
  %mem434 = alloca i8, i64 8, align 8
  %ptr435 = ptrtoint ptr %mem434 to i64
  store i64 %ptr435, ptr %slot7, align 8
  %mem436 = alloca i8, i64 8, align 8
  %ptr437 = ptrtoint ptr %mem436 to i64
  store i64 %ptr437, ptr %slot8, align 8
  %mem438 = alloca i8, i64 8, align 8
  %ptr439 = ptrtoint ptr %mem438 to i64
  store i64 %ptr439, ptr %slot9, align 8
  %mem440 = alloca i8, i64 8, align 8
  %ptr441 = ptrtoint ptr %mem440 to i64
  store i64 %ptr441, ptr %slot10, align 8
  %mem442 = alloca i8, i64 8, align 8
  %ptr443 = ptrtoint ptr %mem442 to i64
  store i64 %ptr443, ptr %slot11, align 8
  %mem444 = alloca i8, i64 8, align 8
  %ptr445 = ptrtoint ptr %mem444 to i64
  store i64 %ptr445, ptr %slot12, align 8
  %mem446 = alloca i8, i64 8, align 8
  %ptr447 = ptrtoint ptr %mem446 to i64
  store i64 %ptr447, ptr %slot13, align 8
  %mem448 = alloca i8, i64 8, align 8
  %ptr449 = ptrtoint ptr %mem448 to i64
  store i64 %ptr449, ptr %slot14, align 8
  %mem450 = alloca i8, i64 8, align 8
  %ptr451 = ptrtoint ptr %mem450 to i64
  store i64 %ptr451, ptr %slot15, align 8
  %mem452 = alloca i8, i64 312, align 8
  %ptr453 = ptrtoint ptr %mem452 to i64
  store i64 %ptr453, ptr %slot16, align 8
  %mem454 = alloca i8, i64 88, align 8
  %ptr455 = ptrtoint ptr %mem454 to i64
  store i64 %ptr455, ptr %slot17, align 8
  %mem456 = alloca i8, i64 312, align 8
  %ptr457 = ptrtoint ptr %mem456 to i64
  store i64 %ptr457, ptr %slot18, align 8
  %mem458 = alloca i8, i64 8, align 8
  %ptr459 = ptrtoint ptr %mem458 to i64
  store i64 %ptr459, ptr %slot19, align 8
  %mem460 = alloca i8, i64 312, align 8
  %ptr461 = ptrtoint ptr %mem460 to i64
  store i64 %ptr461, ptr %slot20, align 8
  %mem462 = alloca i8, i64 8, align 8
  %ptr463 = ptrtoint ptr %mem462 to i64
  store i64 %ptr463, ptr %slot21, align 8
  %mem464 = alloca i8, i64 40, align 8
  %ptr465 = ptrtoint ptr %mem464 to i64
  store i64 %ptr465, ptr %slot22, align 8
  %mem466 = alloca i8, i64 16, align 8
  %ptr467 = ptrtoint ptr %mem466 to i64
  store i64 %ptr467, ptr %slot23, align 8
  %mem468 = alloca i8, i64 8, align 8
  %ptr469 = ptrtoint ptr %mem468 to i64
  store i64 %ptr469, ptr %slot24, align 8
  %mem470 = alloca i8, i64 8, align 8
  %ptr471 = ptrtoint ptr %mem470 to i64
  store i64 %ptr471, ptr %slot25, align 8
  %mem472 = alloca i8, i64 8, align 8
  %ptr473 = ptrtoint ptr %mem472 to i64
  store i64 %ptr473, ptr %slot26, align 8
  %mem474 = alloca i8, i64 8, align 8
  %ptr475 = ptrtoint ptr %mem474 to i64
  store i64 %ptr475, ptr %slot27, align 8
  %mem476 = alloca i8, i64 8, align 8
  %ptr477 = ptrtoint ptr %mem476 to i64
  store i64 %ptr477, ptr %slot28, align 8
  %mem478 = alloca i8, i64 312, align 8
  %ptr479 = ptrtoint ptr %mem478 to i64
  store i64 %ptr479, ptr %slot29, align 8
  %mem480 = alloca i8, i64 48, align 8
  %ptr481 = ptrtoint ptr %mem480 to i64
  store i64 %ptr481, ptr %slot30, align 8
  %mem482 = alloca i8, i64 16, align 8
  %ptr483 = ptrtoint ptr %mem482 to i64
  store i64 %ptr483, ptr %slot31, align 8
  %mem484 = alloca i8, i64 312, align 8
  %ptr485 = ptrtoint ptr %mem484 to i64
  store i64 %ptr485, ptr %slot32, align 8
  %mem486 = alloca i8, i64 16, align 8
  %ptr487 = ptrtoint ptr %mem486 to i64
  store i64 %ptr487, ptr %slot33, align 8
  %mem488 = alloca i8, i64 16, align 8
  %ptr489 = ptrtoint ptr %mem488 to i64
  store i64 %ptr489, ptr %slot34, align 8
  %mem490 = alloca i8, i64 312, align 8
  %ptr491 = ptrtoint ptr %mem490 to i64
  store i64 %ptr491, ptr %slot35, align 8
  %mem492 = alloca i8, i64 48, align 8
  %ptr493 = ptrtoint ptr %mem492 to i64
  store i64 %ptr493, ptr %slot36, align 8
  %mem494 = alloca i8, i64 312, align 8
  %ptr495 = ptrtoint ptr %mem494 to i64
  store i64 %ptr495, ptr %slot37, align 8
  %mem496 = alloca i8, i64 312, align 8
  %ptr497 = ptrtoint ptr %mem496 to i64
  store i64 %ptr497, ptr %slot38, align 8
  %mem498 = alloca i8, i64 16, align 8
  %ptr499 = ptrtoint ptr %mem498 to i64
  store i64 %ptr499, ptr %slot39, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem500 = alloca i8, i64 8, align 8
  %ptr501 = ptrtoint ptr %mem500 to i64
  store i64 %ptr501, ptr %slot40, align 8
  %v502 = load i64, ptr %slot1, align 8
  %op503 = add i64 %v502, 64
  store i64 %op503, ptr %slot41, align 8
  %v504 = load i64, ptr %slot41, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !4, !noalias !3
  store i64 %ld506, ptr %slot42, align 8
  %stack507 = call ptr @llvm.stacksave()
  %stackaddr508 = ptrtoint ptr %stack507 to i64
  %v509 = load i64, ptr %slot42, align 8
  %cmp510 = icmp ult i64 %stackaddr508, %v509
  %cv511 = zext i1 %cmp510 to i64
  store i64 %cv511, ptr %slot43, align 8
  %v512 = load i64, ptr %slot43, align 8
  %cond513 = icmp ne i64 %v512, 0
  br i1 %cond513, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v514 = load i64, ptr %slot1, align 8
  %p515 = inttoptr i64 %v514 to ptr
  call void @myl_qbe_fail_frame(ptr %p515) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v516 = load i64, ptr %slot2, align 8
  %v517 = load i64, ptr %slot21, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 %v516, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot1, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %call521 = call ptr @myl_qbe_heap(ptr %p520) nomerge, !dbg !112
  %calladdr522 = ptrtoint ptr %call521 to i64
  store i64 %calladdr522, ptr %slot44, align 8
  %v523 = load i64, ptr %slot1, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %call525 = call i64 @myl_qbe_region_mark(ptr %p524) nomerge, !dbg !112
  store i64 %call525, ptr %slot45, align 8
  %v526 = load i64, ptr %slot5, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i32 0, ptr %p527, align 4, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot6, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i32 0, ptr %p529, align 4, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot7, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i32 0, ptr %p531, align 4, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot8, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i32 0, ptr %p533, align 4, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot9, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 0, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot10, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i32 0, ptr %p537, align 4, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot11, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i32 0, ptr %p539, align 4, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot12, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i32 0, ptr %p541, align 4, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot13, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i32 0, ptr %p543, align 4, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot14, align 8
  %p545 = inttoptr i64 %v544 to ptr
  store i32 0, ptr %p545, align 4, !alias.scope !3, !noalias !4
  %v546 = load i64, ptr %slot15, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i32 0, ptr %p547, align 4, !alias.scope !3, !noalias !4
  %v548 = load i64, ptr %slot6, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i32 2, ptr %p549, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v550 = load i64, ptr %slot21, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot46, align 8
  %v553 = load i64, ptr %slot46, align 8
  %v554 = load i64, ptr %slot24, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i64 %v553, ptr %p555, align 8, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot29, align 8
  store i64 %v556, ptr %slot47, align 8
  %v557 = load i64, ptr %slot47, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i32 0, ptr %p558, align 4, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot47, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i32 19, ptr %p560, align 4, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot47, align 8
  %v562 = load i64, ptr %slot25, align 8
  %p563 = inttoptr i64 %v562 to ptr
  store i64 %v561, ptr %p563, align 8, !alias.scope !3, !noalias !4
  %p564 = inttoptr i64 ptrtoint (ptr @myl_lit_1b09457477ce8976b6dd5c0bb92b9d43a791e77aa5ffb457e7d39663b0d18cde to i64) to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !4, !noalias !3
  store i64 %ld565, ptr %slot48, align 8
  %v566 = load i64, ptr %slot48, align 8
  %v567 = load i64, ptr %slot26, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot26, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot49, align 8
  %v572 = load i64, ptr %slot49, align 8
  %v573 = load i64, ptr %slot19, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i64 %v572, ptr %p574, align 8, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot19, align 8
  store i64 %v575, ptr %slot50, align 8
  %v576 = load i64, ptr %slot20, align 8
  store i64 %v576, ptr %slot51, align 8
  %v577 = load i64, ptr %slot50, align 8
  %v578 = load i64, ptr %slot51, align 8
  %p579 = inttoptr i64 %v577 to ptr
  %p580 = inttoptr i64 %v578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p580, ptr %p579, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot14, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i32 2, ptr %p582, align 4, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot13, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i32 1, ptr %p584, align 4, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot18, align 8
  store i64 %v585, ptr %slot52, align 8
  %v586 = load i64, ptr %slot20, align 8
  store i64 %v586, ptr %slot53, align 8
  %v587 = load i64, ptr %slot53, align 8
  %v588 = load i64, ptr %slot52, align 8
  %p589 = inttoptr i64 %v587 to ptr
  %p590 = inttoptr i64 %v588 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p590, ptr %p589, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot12, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 2, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot14, align 8
  %p594 = inttoptr i64 %v593 to ptr
  %ld595 = load i32, ptr %p594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld595, ptr %slot54, align 8
  %v596 = load i32, ptr %slot54, align 8
  %v597 = load i64, ptr %slot12, align 8
  %p598 = inttoptr i64 %v597 to ptr
  store i32 %v596, ptr %p598, align 4, !alias.scope !3, !noalias !4
  %v599 = load i64, ptr %slot13, align 8
  %p600 = inttoptr i64 %v599 to ptr
  store i32 0, ptr %p600, align 4, !alias.scope !3, !noalias !4
  %v601 = load i64, ptr %slot11, align 8
  %p602 = inttoptr i64 %v601 to ptr
  store i32 1, ptr %p602, align 4, !alias.scope !3, !noalias !4
  %v603 = load i64, ptr %slot52, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %ld605 = load i64, ptr %p604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld605, ptr %slot55, align 8
  %v606 = load i64, ptr %slot55, align 8
  %v607 = load i64, ptr %slot26, align 8
  %p608 = inttoptr i64 %v607 to ptr
  store i64 %v606, ptr %p608, align 8, !alias.scope !3, !noalias !4
  %v609 = load i64, ptr %slot24, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %ld611 = load i64, ptr %p610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld611, ptr %slot56, align 8
  %v612 = load i64, ptr %slot25, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %ld614 = load i64, ptr %p613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld614, ptr %slot57, align 8
  %v615 = load i64, ptr %slot26, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %ld617 = load i64, ptr %p616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld617, ptr %slot58, align 8
  %v618 = load i64, ptr %slot1, align 8
  %v619 = load i64, ptr %slot56, align 8
  %v620 = load i64, ptr %slot57, align 8
  %v621 = load i64, ptr %slot58, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult60, i64 %v618, i64 %v619, i64 %v620, i64 %v621) nomerge, !dbg !114
  %addr622 = ptrtoint ptr %callresult60 to i64
  store i64 %addr622, ptr %slot59, align 8
  %v623 = load i64, ptr %slot59, align 8
  %v624 = load i64, ptr %slot24, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i64 %v623, ptr %p625, align 8, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot24, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %ld628 = load i64, ptr %p627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld628, ptr %slot61, align 8
  %v629 = load i64, ptr %slot20, align 8
  store i64 %v629, ptr %slot62, align 8
  %v630 = load i64, ptr %slot61, align 8
  %v631 = load i64, ptr %slot62, align 8
  %p632 = inttoptr i64 %v630 to ptr
  %p633 = inttoptr i64 %v631 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p633, ptr %p632, i64 48, i1 false)
  %v634 = load i64, ptr %slot14, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i32 2, ptr %p635, align 4, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot13, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 1, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot7, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i32, ptr %p639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld640, ptr %slot63, align 8
  %v641 = load i32, ptr %slot63, align 8
  %cv642 = zext i32 %v641 to i64
  %cond643 = icmp ne i64 %cv642, 0
  br i1 %cond643, label %bb_rcslotdrop37, label %bb_rcslotdone37
bb_rcslotdrop37:
  %v644 = load i64, ptr %slot7, align 8
  %p645 = inttoptr i64 %v644 to ptr
  store i32 0, ptr %p645, align 4, !alias.scope !3, !noalias !4
  %v646 = load i64, ptr %slot16, align 8
  store i64 %v646, ptr %slot64, align 8
  %v647 = load i64, ptr %slot8, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %ld649 = load i32, ptr %p648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld649, ptr %slot65, align 8
  %v650 = load i32, ptr %slot65, align 8
  %op651 = and i32 %v650, 28
  store i32 %op651, ptr %slot66, align 8
  %v652 = load i32, ptr %slot66, align 8
  %cv653 = zext i32 %v652 to i64
  %cond654 = icmp ne i64 %cv653, 0
  br i1 %cond654, label %bb_rcslotrole37, label %bb_rcslotowner37
bb_rcslotrole37:
  %v655 = load i64, ptr %slot44, align 8
  store i64 %v655, ptr %slot67, align 8
  %v656 = load i64, ptr %slot67, align 8
  %v657 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v656, i64 %v657) nomerge, !dbg !114
  br label %bb_rcslotdone37
bb_rcslotowner37:
  %v658 = load i64, ptr %slot44, align 8
  store i64 %v658, ptr %slot68, align 8
  %v659 = load i64, ptr %slot68, align 8
  %v660 = load i64, ptr %slot64, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v659, i64 %v660) nomerge, !dbg !114
  br label %bb_rcslotdone37
bb_rcslotdone37:
  %v661 = load i64, ptr %slot11, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i32, ptr %p662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld663, ptr %slot69, align 8
  %v664 = load i32, ptr %slot69, align 8
  %cv665 = zext i32 %v664 to i64
  %cond666 = icmp ne i64 %cv665, 0
  br i1 %cond666, label %bb_rcslotdrop46, label %bb_rcslotdone46
bb_rcslotdrop46:
  %v667 = load i64, ptr %slot11, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot18, align 8
  store i64 %v669, ptr %slot70, align 8
  %v670 = load i64, ptr %slot12, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i32, ptr %p671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld672, ptr %slot71, align 8
  %v673 = load i32, ptr %slot71, align 8
  %op674 = and i32 %v673, 28
  store i32 %op674, ptr %slot72, align 8
  %v675 = load i32, ptr %slot72, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcslotrole46, label %bb_rcslotowner46
bb_rcslotrole46:
  %v678 = load i64, ptr %slot44, align 8
  store i64 %v678, ptr %slot73, align 8
  %v679 = load i64, ptr %slot70, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %ld681 = load i64, ptr %p680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld681, ptr %slot74, align 8
  %v682 = load i64, ptr %slot74, align 8
  %cmp683 = icmp ne i64 %v682, 0
  %cv684 = zext i1 %cmp683 to i32
  store i32 %cv684, ptr %slot75, align 8
  %v685 = load i32, ptr %slot75, align 8
  %cv686 = zext i32 %v685 to i64
  %cond687 = icmp ne i64 %cv686, 0
  br i1 %cond687, label %bb_rcgnn62, label %bb_rcgdone62
bb_rcgnn62:
  %v688 = load i64, ptr %slot74, align 8
  %op689 = sub i64 %v688, 16
  store i64 %op689, ptr %slot76, align 8
  %v690 = load i64, ptr %slot74, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %rgep692 = getelementptr i8, ptr %p691, i64 -16
  %ld693 = load i64, ptr %rgep692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld693, ptr %slot77, align 8
  %v694 = load i64, ptr %slot77, align 8
  %op695 = and i64 %v694, 4611686018427387906
  store i64 %op695, ptr %slot78, align 8
  %v696 = load i64, ptr %slot78, align 8
  %cmp697 = icmp ne i64 %v696, 0
  %cv698 = zext i1 %cmp697 to i32
  store i32 %cv698, ptr %slot79, align 8
  %v699 = load i32, ptr %slot79, align 8
  %cv700 = zext i32 %v699 to i64
  %cond701 = icmp ne i64 %cv700, 0
  br i1 %cond701, label %bb_rcgclear62, label %bb_rcgcounted62
bb_rcgcounted62:
  %v702 = load i64, ptr %slot74, align 8
  %op703 = sub i64 %v702, 24
  store i64 %op703, ptr %slot80, align 8
  %v704 = load i64, ptr %slot74, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %rgep706 = getelementptr i8, ptr %p705, i64 -24
  %ld707 = load i64, ptr %rgep706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld707, ptr %slot81, align 8
  %v708 = load i64, ptr %slot81, align 8
  %op709 = sub i64 %v708, 1
  store i64 %op709, ptr %slot82, align 8
  %v710 = load i64, ptr %slot82, align 8
  %cmp711 = icmp eq i64 %v710, 0
  %cv712 = zext i1 %cmp711 to i32
  store i32 %cv712, ptr %slot83, align 8
  %v713 = load i32, ptr %slot83, align 8
  %cv714 = zext i32 %v713 to i64
  %cond715 = icmp ne i64 %cv714, 0
  br i1 %cond715, label %bb_rcglast62, label %bb_rcgdec62
bb_rcglast62:
  %v716 = load i64, ptr %slot74, align 8
  %op717 = sub i64 %v716, 32
  store i64 %op717, ptr %slot84, align 8
  %v718 = load i64, ptr %slot74, align 8
  %p719 = inttoptr i64 %v718 to ptr
  %rgep720 = getelementptr i8, ptr %p719, i64 -32
  %ld721 = load i64, ptr %rgep720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld721, ptr %slot85, align 8
  %v722 = load i64, ptr %slot85, align 8
  %cmp723 = icmp ne i64 %v722, 0
  %cv724 = zext i1 %cmp723 to i32
  store i32 %cv724, ptr %slot86, align 8
  %v725 = load i32, ptr %slot86, align 8
  %cv726 = zext i32 %v725 to i64
  %cond727 = icmp ne i64 %cv726, 0
  br i1 %cond727, label %bb_rcgdec62, label %bb_rcgslow62
bb_rcgslow62:
  %v728 = load i64, ptr %slot73, align 8
  %v729 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v728, i64 %v729) nomerge, !dbg !114
  br label %bb_rcgdone62
bb_rcgdec62:
  %v730 = load i64, ptr %slot82, align 8
  %v731 = load i64, ptr %slot74, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %rgep733 = getelementptr i8, ptr %p732, i64 -24
  store i64 %v730, ptr %rgep733, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear62
bb_rcgclear62:
  %v734 = load i64, ptr %slot70, align 8
  %p735 = inttoptr i64 %v734 to ptr
  store i64 0, ptr %p735, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone62
bb_rcgdone62:
  br label %bb_rcslotdone46
bb_rcslotowner46:
  %v736 = load i64, ptr %slot44, align 8
  store i64 %v736, ptr %slot87, align 8
  %v737 = load i64, ptr %slot70, align 8
  %p738 = inttoptr i64 %v737 to ptr
  %ld739 = load i64, ptr %p738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld739, ptr %slot88, align 8
  %v740 = load i64, ptr %slot88, align 8
  %cmp741 = icmp ne i64 %v740, 0
  %cv742 = zext i1 %cmp741 to i32
  store i32 %cv742, ptr %slot89, align 8
  %v743 = load i32, ptr %slot89, align 8
  %cv744 = zext i32 %v743 to i64
  %cond745 = icmp ne i64 %cv744, 0
  br i1 %cond745, label %bb_rcgnn77, label %bb_rcgdone77
bb_rcgnn77:
  %v746 = load i64, ptr %slot88, align 8
  %op747 = sub i64 %v746, 16
  store i64 %op747, ptr %slot90, align 8
  %v748 = load i64, ptr %slot88, align 8
  %p749 = inttoptr i64 %v748 to ptr
  %rgep750 = getelementptr i8, ptr %p749, i64 -16
  %ld751 = load i64, ptr %rgep750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld751, ptr %slot91, align 8
  %v752 = load i64, ptr %slot91, align 8
  %op753 = and i64 %v752, 4611686018427387906
  store i64 %op753, ptr %slot92, align 8
  %v754 = load i64, ptr %slot92, align 8
  %cmp755 = icmp ne i64 %v754, 0
  %cv756 = zext i1 %cmp755 to i32
  store i32 %cv756, ptr %slot93, align 8
  %v757 = load i32, ptr %slot93, align 8
  %cv758 = zext i32 %v757 to i64
  %cond759 = icmp ne i64 %cv758, 0
  br i1 %cond759, label %bb_rcgclear77, label %bb_rcgcounted77
bb_rcgcounted77:
  %v760 = load i64, ptr %slot88, align 8
  %op761 = sub i64 %v760, 32
  store i64 %op761, ptr %slot94, align 8
  %v762 = load i64, ptr %slot88, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %rgep764 = getelementptr i8, ptr %p763, i64 -32
  %ld765 = load i64, ptr %rgep764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld765, ptr %slot95, align 8
  %v766 = load i64, ptr %slot95, align 8
  %op767 = sub i64 %v766, 1
  store i64 %op767, ptr %slot96, align 8
  %v768 = load i64, ptr %slot96, align 8
  %cmp769 = icmp eq i64 %v768, 0
  %cv770 = zext i1 %cmp769 to i32
  store i32 %cv770, ptr %slot97, align 8
  %v771 = load i32, ptr %slot97, align 8
  %cv772 = zext i32 %v771 to i64
  %cond773 = icmp ne i64 %cv772, 0
  br i1 %cond773, label %bb_rcglast77, label %bb_rcgdec77
bb_rcglast77:
  %v774 = load i64, ptr %slot88, align 8
  %op775 = sub i64 %v774, 24
  store i64 %op775, ptr %slot98, align 8
  %v776 = load i64, ptr %slot88, align 8
  %p777 = inttoptr i64 %v776 to ptr
  %rgep778 = getelementptr i8, ptr %p777, i64 -24
  %ld779 = load i64, ptr %rgep778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld779, ptr %slot99, align 8
  %v780 = load i64, ptr %slot99, align 8
  %cmp781 = icmp ne i64 %v780, 0
  %cv782 = zext i1 %cmp781 to i32
  store i32 %cv782, ptr %slot100, align 8
  %v783 = load i32, ptr %slot100, align 8
  %cv784 = zext i32 %v783 to i64
  %cond785 = icmp ne i64 %cv784, 0
  br i1 %cond785, label %bb_rcgdec77, label %bb_rcgslow77
bb_rcgslow77:
  %v786 = load i64, ptr %slot87, align 8
  %v787 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v786, i64 %v787) nomerge, !dbg !114
  br label %bb_rcgdone77
bb_rcgdec77:
  %v788 = load i64, ptr %slot96, align 8
  %v789 = load i64, ptr %slot88, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %rgep791 = getelementptr i8, ptr %p790, i64 -32
  store i64 %v788, ptr %rgep791, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear77
bb_rcgclear77:
  %v792 = load i64, ptr %slot70, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 0, ptr %p793, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone77
bb_rcgdone77:
  br label %bb_rcslotdone46
bb_rcslotdone46:
  %v794 = load i64, ptr %slot16, align 8
  store i64 %v794, ptr %slot101, align 8
  %v795 = load i64, ptr %slot20, align 8
  store i64 %v795, ptr %slot102, align 8
  %v796 = load i64, ptr %slot102, align 8
  %v797 = load i64, ptr %slot101, align 8
  %p798 = inttoptr i64 %v796 to ptr
  %p799 = inttoptr i64 %v797 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p799, ptr %p798, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot8, align 8
  %p801 = inttoptr i64 %v800 to ptr
  store i32 2, ptr %p801, align 4, !alias.scope !3, !noalias !4
  %v802 = load i64, ptr %slot14, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %ld804 = load i32, ptr %p803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld804, ptr %slot103, align 8
  %v805 = load i32, ptr %slot103, align 8
  %v806 = load i64, ptr %slot8, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 %v805, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot13, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 0, ptr %p809, align 4, !alias.scope !3, !noalias !4
  %v810 = load i64, ptr %slot7, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 1, ptr %p811, align 4, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot101, align 8
  %v813 = load i64, ptr %slot24, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i64 %v812, ptr %p814, align 8, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot24, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %ld817 = load i64, ptr %p816, align 8, !alias.scope !3, !noalias !4
  store i64 %ld817, ptr %slot104, align 8
  %v818 = load i64, ptr %slot104, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i32, ptr %p819, align 4
  %ext821 = zext i32 %ld820 to i64
  store i64 %ext821, ptr %slot105, align 8
  %v822 = load i64, ptr %slot105, align 8
  %cmp823 = icmp eq i64 %v822, 0
  %cv824 = zext i1 %cmp823 to i64
  store i64 %cv824, ptr %slot106, align 8
  %v825 = load i64, ptr %slot106, align 8
  %cond826 = icmp ne i64 %v825, 0
  br i1 %cond826, label %bb_rctryok90, label %bb_rctryerror90
bb_rctryerror90:
  %p827 = inttoptr i64 ptrtoint (ptr @myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p827, i64 12884901892) "call-inline-cost"="0", !dbg !116
  %v828 = load i64, ptr %slot104, align 8
  %op829 = add i64 %v828, 8
  store i64 %op829, ptr %slot107, align 8
  %v830 = load i64, ptr %slot30, align 8
  store i64 %v830, ptr %slot108, align 8
  %v831 = load i64, ptr %slot108, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 0, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot108, align 8
  %p835 = inttoptr i64 %v833 to ptr
  %gep836 = getelementptr i8, ptr %p835, i64 8
  %op834 = ptrtoint ptr %gep836 to i64
  store i64 %op834, ptr %slot109, align 8
  %v837 = load i64, ptr %slot109, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i64 0, ptr %p838, align 8, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot108, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 1, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot108, align 8
  %p843 = inttoptr i64 %v841 to ptr
  %gep844 = getelementptr i8, ptr %p843, i64 8
  %op842 = ptrtoint ptr %gep844 to i64
  store i64 %op842, ptr %slot110, align 8
  %v845 = load i64, ptr %slot15, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i32 1, ptr %p846, align 4, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot45, align 8
  store i64 %v847, ptr %slot111, align 8
  %v848 = load i64, ptr %slot108, align 8
  %v849 = load i64, ptr %slot24, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i64 %v848, ptr %p850, align 8, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot7, align 8
  %p852 = inttoptr i64 %v851 to ptr
  %ld853 = load i32, ptr %p852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld853, ptr %slot112, align 8
  %v854 = load i32, ptr %slot112, align 8
  %cv855 = zext i32 %v854 to i64
  %cond856 = icmp ne i64 %cv855, 0
  br i1 %cond856, label %bb_rcslotdrop101, label %bb_rcslotdone101
bb_rcslotdrop101:
  %v857 = load i64, ptr %slot7, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i32 0, ptr %p858, align 4, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot16, align 8
  store i64 %v859, ptr %slot113, align 8
  %v860 = load i64, ptr %slot8, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i32, ptr %p861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld862, ptr %slot114, align 8
  %v863 = load i32, ptr %slot114, align 8
  %op864 = and i32 %v863, 28
  store i32 %op864, ptr %slot115, align 8
  %v865 = load i32, ptr %slot115, align 8
  %cv866 = zext i32 %v865 to i64
  %cond867 = icmp ne i64 %cv866, 0
  br i1 %cond867, label %bb_rcslotrole101, label %bb_rcslotowner101
bb_rcslotrole101:
  %v868 = load i64, ptr %slot44, align 8
  store i64 %v868, ptr %slot116, align 8
  %v869 = load i64, ptr %slot116, align 8
  %v870 = load i64, ptr %slot113, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v869, i64 %v870) nomerge, !dbg !116
  br label %bb_rcslotdone101
bb_rcslotowner101:
  %v871 = load i64, ptr %slot44, align 8
  store i64 %v871, ptr %slot117, align 8
  %v872 = load i64, ptr %slot117, align 8
  %v873 = load i64, ptr %slot113, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v872, i64 %v873) nomerge, !dbg !116
  br label %bb_rcslotdone101
bb_rcslotdone101:
  br label %bb_i6
bb_rctryok90:
  %v874 = load i64, ptr %slot30, align 8
  store i64 %v874, ptr %slot118, align 8
  %v875 = load i64, ptr %slot118, align 8
  %p876 = inttoptr i64 %v875 to ptr
  store i64 0, ptr %p876, align 8, !alias.scope !3, !noalias !4
  %v877 = load i64, ptr %slot118, align 8
  %p879 = inttoptr i64 %v877 to ptr
  %gep880 = getelementptr i8, ptr %p879, i64 8
  %op878 = ptrtoint ptr %gep880 to i64
  store i64 %op878, ptr %slot119, align 8
  %v881 = load i64, ptr %slot119, align 8
  %p882 = inttoptr i64 %v881 to ptr
  store i64 0, ptr %p882, align 8, !alias.scope !3, !noalias !4
  %v883 = load i64, ptr %slot118, align 8
  %p885 = inttoptr i64 %v883 to ptr
  %gep886 = getelementptr i8, ptr %p885, i64 16
  %op884 = ptrtoint ptr %gep886 to i64
  store i64 %op884, ptr %slot120, align 8
  %v887 = load i64, ptr %slot120, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i64 0, ptr %p888, align 8, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot118, align 8
  %p891 = inttoptr i64 %v889 to ptr
  %gep892 = getelementptr i8, ptr %p891, i64 24
  %op890 = ptrtoint ptr %gep892 to i64
  store i64 %op890, ptr %slot121, align 8
  %v893 = load i64, ptr %slot121, align 8
  %p894 = inttoptr i64 %v893 to ptr
  store i64 0, ptr %p894, align 8, !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot118, align 8
  %p897 = inttoptr i64 %v895 to ptr
  %gep898 = getelementptr i8, ptr %p897, i64 32
  %op896 = ptrtoint ptr %gep898 to i64
  store i64 %op896, ptr %slot122, align 8
  %v899 = load i64, ptr %slot122, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i64 0, ptr %p900, align 8, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot15, align 8
  %p902 = inttoptr i64 %v901 to ptr
  store i32 1, ptr %p902, align 4, !alias.scope !3, !noalias !4
  %v903 = load i64, ptr %slot104, align 8
  %op904 = add i64 %v903, 8
  store i64 %op904, ptr %slot123, align 8
  %v905 = load i64, ptr %slot45, align 8
  store i64 %v905, ptr %slot124, align 8
  %v906 = load i64, ptr %slot44, align 8
  %v907 = load i64, ptr %slot118, align 8
  %v908 = load i64, ptr %slot123, align 8
  %v909 = load i64, ptr %slot124, align 8
  %cv910 = trunc i64 %v909 to i32
  %call911 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v906, i64 %v907, i64 %v908, i32 %cv910) nomerge, !dbg !116
  store i32 %call911, ptr %slot125, align 8
  %v912 = load i32, ptr %slot125, align 8
  %cv913 = zext i32 %v912 to i64
  %cond914 = icmp ne i64 %cv913, 0
  br i1 %cond914, label %bb_rcsuccess118, label %bb_rcfailure118
bb_rcfailure118:
  %v915 = load i64, ptr %slot44, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %call917 = call i32 @myl_rc_take_failure(ptr %p916) nomerge, !dbg !116
  store i32 %call917, ptr %slot126, align 8
  %v918 = load i64, ptr %slot1, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %v920 = load i32, ptr %slot126, align 8
  %call921 = call i32 @myl_qbe_rc_status(ptr %p919, i32 %v920) nomerge, !dbg !116
  store i32 %call921, ptr %slot127, align 8
  br label %bb_failure
bb_rcsuccess118:
  %v922 = load i64, ptr %slot118, align 8
  %v923 = load i64, ptr %slot24, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i64 %v922, ptr %p924, align 8, !alias.scope !3, !noalias !4
  %v925 = load i64, ptr %slot24, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ld927 = load i64, ptr %p926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld927, ptr %slot128, align 8
  %v928 = load i64, ptr %slot20, align 8
  store i64 %v928, ptr %slot129, align 8
  %v929 = load i64, ptr %slot128, align 8
  %v930 = load i64, ptr %slot129, align 8
  %p931 = inttoptr i64 %v929 to ptr
  %p932 = inttoptr i64 %v930 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p932, ptr %p931, i64 40, i1 false)
  %v933 = load i64, ptr %slot14, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i32 2, ptr %p934, align 4, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot13, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i32 1, ptr %p936, align 4, !alias.scope !3, !noalias !4
  %v937 = load i64, ptr %slot7, align 8
  %p938 = inttoptr i64 %v937 to ptr
  %ld939 = load i32, ptr %p938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld939, ptr %slot130, align 8
  %v940 = load i32, ptr %slot130, align 8
  %cv941 = zext i32 %v940 to i64
  %cond942 = icmp ne i64 %cv941, 0
  br i1 %cond942, label %bb_rcslotdrop127, label %bb_rcslotdone127
bb_rcslotdrop127:
  %v943 = load i64, ptr %slot7, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i32 0, ptr %p944, align 4, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot16, align 8
  store i64 %v945, ptr %slot131, align 8
  %v946 = load i64, ptr %slot8, align 8
  %p947 = inttoptr i64 %v946 to ptr
  %ld948 = load i32, ptr %p947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld948, ptr %slot132, align 8
  %v949 = load i32, ptr %slot132, align 8
  %op950 = and i32 %v949, 28
  store i32 %op950, ptr %slot133, align 8
  %v951 = load i32, ptr %slot133, align 8
  %cv952 = zext i32 %v951 to i64
  %cond953 = icmp ne i64 %cv952, 0
  br i1 %cond953, label %bb_rcslotrole127, label %bb_rcslotowner127
bb_rcslotrole127:
  %v954 = load i64, ptr %slot44, align 8
  store i64 %v954, ptr %slot134, align 8
  %v955 = load i64, ptr %slot134, align 8
  %v956 = load i64, ptr %slot131, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v955, i64 %v956) nomerge, !dbg !116
  br label %bb_rcslotdone127
bb_rcslotowner127:
  %v957 = load i64, ptr %slot44, align 8
  store i64 %v957, ptr %slot135, align 8
  %v958 = load i64, ptr %slot135, align 8
  %v959 = load i64, ptr %slot131, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v958, i64 %v959) nomerge, !dbg !116
  br label %bb_rcslotdone127
bb_rcslotdone127:
  %v960 = load i64, ptr %slot16, align 8
  store i64 %v960, ptr %slot136, align 8
  %v961 = load i64, ptr %slot20, align 8
  store i64 %v961, ptr %slot137, align 8
  %v962 = load i64, ptr %slot137, align 8
  %v963 = load i64, ptr %slot136, align 8
  %p964 = inttoptr i64 %v962 to ptr
  %p965 = inttoptr i64 %v963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p965, ptr %p964, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v966 = load i64, ptr %slot8, align 8
  %p967 = inttoptr i64 %v966 to ptr
  store i32 2, ptr %p967, align 4, !alias.scope !3, !noalias !4
  %v968 = load i64, ptr %slot14, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %ld970 = load i32, ptr %p969, align 4, !alias.scope !3, !noalias !4
  store i32 %ld970, ptr %slot138, align 8
  %v971 = load i32, ptr %slot138, align 8
  %v972 = load i64, ptr %slot8, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i32 %v971, ptr %p973, align 4, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot13, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 0, ptr %p975, align 4, !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot7, align 8
  %p977 = inttoptr i64 %v976 to ptr
  store i32 1, ptr %p977, align 4, !alias.scope !3, !noalias !4
  %v978 = load i64, ptr %slot136, align 8
  %v979 = load i64, ptr %slot24, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i64 %v978, ptr %p980, align 8, !alias.scope !3, !noalias !4
  br label %bb_i7
bb_i6:
  %v981 = load i64, ptr %slot24, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %ld983 = load i64, ptr %p982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld983, ptr %slot139, align 8
  %v984 = load i64, ptr %slot7, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i32, ptr %p985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld986, ptr %slot140, align 8
  %v987 = load i32, ptr %slot140, align 8
  %cv988 = zext i32 %v987 to i64
  %cond989 = icmp ne i64 %cv988, 0
  br i1 %cond989, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v990 = load i64, ptr %slot7, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i32 0, ptr %p991, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone145
bb_rcslotdone145:
  %v992 = load i64, ptr %slot5, align 8
  %p993 = inttoptr i64 %v992 to ptr
  %ld994 = load i32, ptr %p993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld994, ptr %slot141, align 8
  %v995 = load i32, ptr %slot141, align 8
  %cv996 = zext i32 %v995 to i64
  %cond997 = icmp ne i64 %cv996, 0
  br i1 %cond997, label %bb_rcslotdrop148, label %bb_rcslotdone148
bb_rcslotdrop148:
  %v998 = load i64, ptr %slot5, align 8
  %p999 = inttoptr i64 %v998 to ptr
  store i32 0, ptr %p999, align 4, !alias.scope !3, !noalias !4
  %v1000 = load i64, ptr %slot22, align 8
  store i64 %v1000, ptr %slot142, align 8
  %v1001 = load i64, ptr %slot6, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %ld1003 = load i32, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1003, ptr %slot143, align 8
  %v1004 = load i32, ptr %slot143, align 8
  %op1005 = and i32 %v1004, 28
  store i32 %op1005, ptr %slot144, align 8
  %v1006 = load i32, ptr %slot144, align 8
  %cv1007 = zext i32 %v1006 to i64
  %cond1008 = icmp ne i64 %cv1007, 0
  br i1 %cond1008, label %bb_rcslotrole148, label %bb_rcslotowner148
bb_rcslotrole148:
  %v1009 = load i64, ptr %slot44, align 8
  store i64 %v1009, ptr %slot145, align 8
  %v1010 = load i64, ptr %slot145, align 8
  %v1011 = load i64, ptr %slot142, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1010, i64 %v1011) nomerge, !dbg !118
  br label %bb_rcslotdone148
bb_rcslotowner148:
  %v1012 = load i64, ptr %slot44, align 8
  store i64 %v1012, ptr %slot146, align 8
  %v1013 = load i64, ptr %slot146, align 8
  %v1014 = load i64, ptr %slot142, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1013, i64 %v1014) nomerge, !dbg !118
  br label %bb_rcslotdone148
bb_rcslotdone148:
  %v1015 = load i64, ptr %slot139, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ret1017 = load { i64, i64 }, ptr %p1016, align 8
  ret { i64, i64 } %ret1017
bb_i7:
  %v1018 = load i64, ptr %slot24, align 8
  %p1019 = inttoptr i64 %v1018 to ptr
  %ld1020 = load i64, ptr %p1019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1020, ptr %slot147, align 8
  %v1021 = load i64, ptr %slot7, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i32, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1023, ptr %slot148, align 8
  %v1024 = load i64, ptr %slot8, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %ld1026 = load i32, ptr %p1025, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1026, ptr %slot149, align 8
  %v1027 = load i32, ptr %slot149, align 8
  %op1028 = and i32 %v1027, 24
  store i32 %op1028, ptr %slot149, align 8
  %v1029 = load i32, ptr %slot149, align 8
  %cmp1030 = icmp eq i32 %v1029, 0
  %cv1031 = zext i1 %cmp1030 to i32
  store i32 %cv1031, ptr %slot150, align 8
  %v1032 = load i32, ptr %slot148, align 8
  %v1033 = load i32, ptr %slot150, align 8
  %op1034 = and i32 %v1032, %v1033
  store i32 %op1034, ptr %slot151, align 8
  %v1035 = load i32, ptr %slot151, align 8
  %cv1036 = zext i32 %v1035 to i64
  %cond1037 = icmp ne i64 %cv1036, 0
  br i1 %cond1037, label %bb_rctake165, label %bb_rccopy165
bb_rctake165:
  %v1038 = load i64, ptr %slot20, align 8
  store i64 %v1038, ptr %slot152, align 8
  %v1039 = load i64, ptr %slot45, align 8
  store i64 %v1039, ptr %slot153, align 8
  %v1040 = load i64, ptr %slot44, align 8
  %v1041 = load i64, ptr %slot152, align 8
  %v1042 = load i64, ptr %slot147, align 8
  %v1043 = load i64, ptr %slot153, align 8
  %cv1044 = trunc i64 %v1043 to i32
  %call1045 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1040, i64 %v1041, i64 %v1042, i32 %cv1044) nomerge, !dbg !120
  store i32 %call1045, ptr %slot154, align 8
  %v1046 = load i32, ptr %slot154, align 8
  %cv1047 = zext i32 %v1046 to i64
  %cond1048 = icmp ne i64 %cv1047, 0
  br i1 %cond1048, label %bb_rcsuccess175, label %bb_rcfailure175
bb_rcfailure175:
  %v1049 = load i64, ptr %slot44, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %call1051 = call i32 @myl_rc_take_failure(ptr %p1050) nomerge, !dbg !120
  store i32 %call1051, ptr %slot155, align 8
  %v1052 = load i64, ptr %slot1, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  %v1054 = load i32, ptr %slot155, align 8
  %call1055 = call i32 @myl_qbe_rc_status(ptr %p1053, i32 %v1054) nomerge, !dbg !120
  store i32 %call1055, ptr %slot156, align 8
  br label %bb_failure
bb_rcsuccess175:
  %v1056 = load i64, ptr %slot7, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i32 0, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot14, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i32 2, ptr %p1059, align 4, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot13, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  store i32 1, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared165
bb_rccopy165:
  %v1062 = load i64, ptr %slot20, align 8
  store i64 %v1062, ptr %slot157, align 8
  %v1063 = load i64, ptr %slot45, align 8
  store i64 %v1063, ptr %slot158, align 8
  %v1064 = load i64, ptr %slot44, align 8
  %v1065 = load i64, ptr %slot157, align 8
  %v1066 = load i64, ptr %slot147, align 8
  %v1067 = load i64, ptr %slot158, align 8
  %cv1068 = trunc i64 %v1067 to i32
  %call1069 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1064, i64 %v1065, i64 %v1066, i32 %cv1068) nomerge, !dbg !120
  store i32 %call1069, ptr %slot159, align 8
  %v1070 = load i32, ptr %slot159, align 8
  %cv1071 = zext i32 %v1070 to i64
  %cond1072 = icmp ne i64 %cv1071, 0
  br i1 %cond1072, label %bb_rcsuccess184, label %bb_rcfailure184
bb_rcfailure184:
  %v1073 = load i64, ptr %slot44, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %call1075 = call i32 @myl_rc_take_failure(ptr %p1074) nomerge, !dbg !120
  store i32 %call1075, ptr %slot160, align 8
  %v1076 = load i64, ptr %slot1, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %v1078 = load i32, ptr %slot160, align 8
  %call1079 = call i32 @myl_qbe_rc_status(ptr %p1077, i32 %v1078) nomerge, !dbg !120
  store i32 %call1079, ptr %slot161, align 8
  br label %bb_failure
bb_rcsuccess184:
  %v1080 = load i64, ptr %slot14, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  store i32 2, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  %v1082 = load i64, ptr %slot13, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i32 1, ptr %p1083, align 4, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot7, align 8
  %p1085 = inttoptr i64 %v1084 to ptr
  %ld1086 = load i32, ptr %p1085, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1086, ptr %slot162, align 8
  %v1087 = load i32, ptr %slot162, align 8
  %cv1088 = zext i32 %v1087 to i64
  %cond1089 = icmp ne i64 %cv1088, 0
  br i1 %cond1089, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v1090 = load i64, ptr %slot7, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  store i32 0, ptr %p1091, align 4, !alias.scope !3, !noalias !4
  %v1092 = load i64, ptr %slot16, align 8
  store i64 %v1092, ptr %slot163, align 8
  %v1093 = load i64, ptr %slot8, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  %ld1095 = load i32, ptr %p1094, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1095, ptr %slot164, align 8
  %v1096 = load i32, ptr %slot164, align 8
  %op1097 = and i32 %v1096, 28
  store i32 %op1097, ptr %slot165, align 8
  %v1098 = load i32, ptr %slot165, align 8
  %cv1099 = zext i32 %v1098 to i64
  %cond1100 = icmp ne i64 %cv1099, 0
  br i1 %cond1100, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v1101 = load i64, ptr %slot44, align 8
  store i64 %v1101, ptr %slot166, align 8
  %v1102 = load i64, ptr %slot166, align 8
  %v1103 = load i64, ptr %slot163, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1102, i64 %v1103) nomerge, !dbg !120
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v1104 = load i64, ptr %slot44, align 8
  store i64 %v1104, ptr %slot167, align 8
  %v1105 = load i64, ptr %slot167, align 8
  %v1106 = load i64, ptr %slot163, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1105, i64 %v1106) nomerge, !dbg !120
  br label %bb_rcslotdone191
bb_rcslotdone191:
  br label %bb_rcprepared165
bb_rcprepared165:
  %v1107 = load i64, ptr %slot5, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i32, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1109, ptr %slot168, align 8
  %v1110 = load i32, ptr %slot168, align 8
  %cv1111 = zext i32 %v1110 to i64
  %cond1112 = icmp ne i64 %cv1111, 0
  br i1 %cond1112, label %bb_rcslotdrop201, label %bb_rcslotdone201
bb_rcslotdrop201:
  %v1113 = load i64, ptr %slot5, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i32 0, ptr %p1114, align 4, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot22, align 8
  store i64 %v1115, ptr %slot169, align 8
  %v1116 = load i64, ptr %slot6, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  %ld1118 = load i32, ptr %p1117, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1118, ptr %slot170, align 8
  %v1119 = load i32, ptr %slot170, align 8
  %op1120 = and i32 %v1119, 28
  store i32 %op1120, ptr %slot171, align 8
  %v1121 = load i32, ptr %slot171, align 8
  %cv1122 = zext i32 %v1121 to i64
  %cond1123 = icmp ne i64 %cv1122, 0
  br i1 %cond1123, label %bb_rcslotrole201, label %bb_rcslotowner201
bb_rcslotrole201:
  %v1124 = load i64, ptr %slot44, align 8
  store i64 %v1124, ptr %slot172, align 8
  %v1125 = load i64, ptr %slot172, align 8
  %v1126 = load i64, ptr %slot169, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1125, i64 %v1126) nomerge, !dbg !120
  br label %bb_rcslotdone201
bb_rcslotowner201:
  %v1127 = load i64, ptr %slot44, align 8
  store i64 %v1127, ptr %slot173, align 8
  %v1128 = load i64, ptr %slot173, align 8
  %v1129 = load i64, ptr %slot169, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1128, i64 %v1129) nomerge, !dbg !120
  br label %bb_rcslotdone201
bb_rcslotdone201:
  %v1130 = load i64, ptr %slot22, align 8
  store i64 %v1130, ptr %slot174, align 8
  %v1131 = load i64, ptr %slot20, align 8
  store i64 %v1131, ptr %slot175, align 8
  %v1132 = load i64, ptr %slot175, align 8
  %v1133 = load i64, ptr %slot174, align 8
  %p1134 = inttoptr i64 %v1132 to ptr
  %p1135 = inttoptr i64 %v1133 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1135, ptr %p1134, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot13, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  store i32 0, ptr %p1137, align 4, !alias.scope !3, !noalias !4
  %v1138 = load i64, ptr %slot6, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i32 2, ptr %p1139, align 4, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot14, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot176, align 8
  %v1143 = load i32, ptr %slot176, align 8
  %v1144 = load i64, ptr %slot6, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i32 %v1143, ptr %p1145, align 4, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot5, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 1, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot31, align 8
  store i64 %v1148, ptr %slot177, align 8
  %v1149 = load i64, ptr %slot177, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  store i64 0, ptr %p1150, align 8, !alias.scope !3, !noalias !4
  %v1151 = load i64, ptr %slot177, align 8
  %p1153 = inttoptr i64 %v1151 to ptr
  %gep1154 = getelementptr i8, ptr %p1153, i64 8
  %op1152 = ptrtoint ptr %gep1154 to i64
  store i64 %op1152, ptr %slot178, align 8
  %v1155 = load i64, ptr %slot178, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  store i64 0, ptr %p1156, align 8, !alias.scope !3, !noalias !4
  %v1157 = load i64, ptr %slot177, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  store i32 0, ptr %p1158, align 4, !alias.scope !3, !noalias !4
  %v1159 = load i64, ptr %slot177, align 8
  %v1160 = load i64, ptr %slot24, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i64 %v1159, ptr %p1161, align 8, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot24, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  %ld1164 = load i64, ptr %p1163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1164, ptr %slot179, align 8
  %v1165 = load i64, ptr %slot179, align 8
  %v1166 = load i64, ptr %slot23, align 8
  %p1167 = inttoptr i64 %v1165 to ptr
  %p1168 = inttoptr i64 %v1166 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1168, ptr %p1167, i64 16, i1 false)
  %v1169 = load i64, ptr %slot21, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %ld1171 = load i64, ptr %p1170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1171, ptr %slot180, align 8
  %v1172 = load i64, ptr %slot180, align 8
  %v1173 = load i64, ptr %slot24, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i64 %v1172, ptr %p1174, align 8, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot32, align 8
  store i64 %v1175, ptr %slot181, align 8
  %v1176 = load i64, ptr %slot181, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 0, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot181, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  store i32 13, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  %v1180 = load i64, ptr %slot181, align 8
  %v1181 = load i64, ptr %slot25, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i64 %v1180, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot24, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i64, ptr %p1184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1185, ptr %slot182, align 8
  %v1186 = load i64, ptr %slot25, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i64, ptr %p1187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1188, ptr %slot183, align 8
  %v1189 = load i64, ptr %slot1, align 8
  %v1190 = load i64, ptr %slot182, align 8
  %v1191 = load i64, ptr %slot183, align 8
  %call1192 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v1189, i64 %v1190, i64 %v1191) nomerge, !dbg !122
  store i64 %call1192, ptr %slot184, align 8
  %v1193 = load i64, ptr %slot184, align 8
  %v1194 = load i64, ptr %slot24, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  store i64 %v1193, ptr %p1195, align 8, !alias.scope !3, !noalias !4
  %v1196 = load i64, ptr %slot7, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i32, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1198, ptr %slot185, align 8
  %v1199 = load i32, ptr %slot185, align 8
  %cv1200 = zext i32 %v1199 to i64
  %cond1201 = icmp ne i64 %cv1200, 0
  br i1 %cond1201, label %bb_rcslotdrop225, label %bb_rcslotdone225
bb_rcslotdrop225:
  %v1202 = load i64, ptr %slot7, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 0, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot16, align 8
  store i64 %v1204, ptr %slot186, align 8
  %v1205 = load i64, ptr %slot8, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %ld1207 = load i32, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1207, ptr %slot187, align 8
  %v1208 = load i32, ptr %slot187, align 8
  %op1209 = and i32 %v1208, 28
  store i32 %op1209, ptr %slot188, align 8
  %v1210 = load i32, ptr %slot188, align 8
  %cv1211 = zext i32 %v1210 to i64
  %cond1212 = icmp ne i64 %cv1211, 0
  br i1 %cond1212, label %bb_rcslotrole225, label %bb_rcslotowner225
bb_rcslotrole225:
  %v1213 = load i64, ptr %slot44, align 8
  store i64 %v1213, ptr %slot189, align 8
  %v1214 = load i64, ptr %slot189, align 8
  %v1215 = load i64, ptr %slot186, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1214, i64 %v1215) nomerge, !dbg !122
  br label %bb_rcslotdone225
bb_rcslotowner225:
  %v1216 = load i64, ptr %slot44, align 8
  store i64 %v1216, ptr %slot190, align 8
  %v1217 = load i64, ptr %slot190, align 8
  %v1218 = load i64, ptr %slot186, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1217, i64 %v1218) nomerge, !dbg !122
  br label %bb_rcslotdone225
bb_rcslotdone225:
  %v1219 = load i64, ptr %slot24, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  %ld1221 = load i64, ptr %p1220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1221, ptr %slot191, align 8
  %v1222 = load i64, ptr %slot191, align 8
  %cond1223 = icmp ne i64 %v1222, 0
  br i1 %cond1223, label %bb_next233, label %bb_i21
bb_next233:
  %v1224 = load i64, ptr %slot21, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i64, ptr %p1225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1226, ptr %slot192, align 8
  %v1227 = load i64, ptr %slot192, align 8
  %v1228 = load i64, ptr %slot24, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  store i64 %v1227, ptr %p1229, align 8, !alias.scope !3, !noalias !4
  %v1230 = load i64, ptr %slot24, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  %ld1232 = load i64, ptr %p1231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1232, ptr %slot193, align 8
  %v1233 = load i64, ptr %slot1, align 8
  %v1234 = load i64, ptr %slot193, align 8
  %call1235 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v1233, i64 %v1234) nomerge, !dbg !124
  store { i64, i64 } %call1235, ptr %callresult195, align 8
  %addr1236 = ptrtoint ptr %callresult195 to i64
  store i64 %addr1236, ptr %slot194, align 8
  %v1237 = load i64, ptr %slot194, align 8
  %v1238 = load i64, ptr %slot24, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i64 %v1237, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot7, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  %ld1242 = load i32, ptr %p1241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1242, ptr %slot196, align 8
  %v1243 = load i32, ptr %slot196, align 8
  %cv1244 = zext i32 %v1243 to i64
  %cond1245 = icmp ne i64 %cv1244, 0
  br i1 %cond1245, label %bb_rcslotdrop238, label %bb_rcslotdone238
bb_rcslotdrop238:
  %v1246 = load i64, ptr %slot7, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i32 0, ptr %p1247, align 4, !alias.scope !3, !noalias !4
  %v1248 = load i64, ptr %slot16, align 8
  store i64 %v1248, ptr %slot197, align 8
  %v1249 = load i64, ptr %slot8, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i32, ptr %p1250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1251, ptr %slot198, align 8
  %v1252 = load i32, ptr %slot198, align 8
  %op1253 = and i32 %v1252, 28
  store i32 %op1253, ptr %slot199, align 8
  %v1254 = load i32, ptr %slot199, align 8
  %cv1255 = zext i32 %v1254 to i64
  %cond1256 = icmp ne i64 %cv1255, 0
  br i1 %cond1256, label %bb_rcslotrole238, label %bb_rcslotowner238
bb_rcslotrole238:
  %v1257 = load i64, ptr %slot44, align 8
  store i64 %v1257, ptr %slot200, align 8
  %v1258 = load i64, ptr %slot200, align 8
  %v1259 = load i64, ptr %slot197, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1258, i64 %v1259) nomerge, !dbg !124
  br label %bb_rcslotdone238
bb_rcslotowner238:
  %v1260 = load i64, ptr %slot44, align 8
  store i64 %v1260, ptr %slot201, align 8
  %v1261 = load i64, ptr %slot201, align 8
  %v1262 = load i64, ptr %slot197, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1261, i64 %v1262) nomerge, !dbg !124
  br label %bb_rcslotdone238
bb_rcslotdone238:
  %v1263 = load i64, ptr %slot24, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %ld1265 = load i64, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1265, ptr %slot202, align 8
  %v1266 = load i64, ptr %slot202, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i32, ptr %p1267, align 4
  %ext1269 = zext i32 %ld1268 to i64
  store i64 %ext1269, ptr %slot203, align 8
  %v1270 = load i64, ptr %slot203, align 8
  %cmp1271 = icmp eq i64 %v1270, 0
  %cv1272 = zext i1 %cmp1271 to i64
  store i64 %cv1272, ptr %slot204, align 8
  %v1273 = load i64, ptr %slot204, align 8
  %cond1274 = icmp ne i64 %v1273, 0
  br i1 %cond1274, label %bb_rctryok246, label %bb_rctryerror246
bb_rctryerror246:
  %p1275 = inttoptr i64 ptrtoint (ptr @myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1275, i64 12884901904) "call-inline-cost"="0", !dbg !126
  %v1276 = load i64, ptr %slot202, align 8
  %op1277 = add i64 %v1276, 8
  store i64 %op1277, ptr %slot205, align 8
  %v1278 = load i64, ptr %slot33, align 8
  store i64 %v1278, ptr %slot206, align 8
  %v1279 = load i64, ptr %slot206, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i64 0, ptr %p1280, align 8, !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot206, align 8
  %p1283 = inttoptr i64 %v1281 to ptr
  %gep1284 = getelementptr i8, ptr %p1283, i64 8
  %op1282 = ptrtoint ptr %gep1284 to i64
  store i64 %op1282, ptr %slot207, align 8
  %v1285 = load i64, ptr %slot207, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  store i64 0, ptr %p1286, align 8, !alias.scope !3, !noalias !4
  %v1287 = load i64, ptr %slot206, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 1, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot206, align 8
  %p1291 = inttoptr i64 %v1289 to ptr
  %gep1292 = getelementptr i8, ptr %p1291, i64 8
  %op1290 = ptrtoint ptr %gep1292 to i64
  store i64 %op1290, ptr %slot208, align 8
  %v1293 = load i64, ptr %slot15, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  store i32 1, ptr %p1294, align 4, !alias.scope !3, !noalias !4
  %v1295 = load i64, ptr %slot45, align 8
  store i64 %v1295, ptr %slot209, align 8
  %v1296 = load i64, ptr %slot206, align 8
  %v1297 = load i64, ptr %slot24, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  store i64 %v1296, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_rctryok246:
  %v1299 = load i64, ptr %slot33, align 8
  store i64 %v1299, ptr %slot210, align 8
  %v1300 = load i64, ptr %slot210, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i64 0, ptr %p1301, align 8, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot15, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i32 1, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot202, align 8
  %op1305 = add i64 %v1304, 8
  store i64 %op1305, ptr %slot211, align 8
  %v1306 = load i64, ptr %slot45, align 8
  store i64 %v1306, ptr %slot212, align 8
  %v1307 = load i64, ptr %slot211, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i64, ptr %p1308, align 8
  store i64 %ld1309, ptr %slot213, align 8
  %v1310 = load i64, ptr %slot213, align 8
  %v1311 = load i64, ptr %slot210, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  store i64 %v1310, ptr %p1312, align 8, !alias.scope !3, !noalias !4
  %v1313 = load i64, ptr %slot210, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  %ld1315 = load i64, ptr %p1314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1315, ptr %slot214, align 8
  %v1316 = load i64, ptr %slot214, align 8
  %v1317 = load i64, ptr %slot24, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  store i64 %v1316, ptr %p1318, align 8, !alias.scope !3, !noalias !4
  br label %bb_i19
bb_i18:
  %v1319 = load i64, ptr %slot24, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  %ld1321 = load i64, ptr %p1320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1321, ptr %slot215, align 8
  %v1322 = load i64, ptr %slot7, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i32, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1324, ptr %slot216, align 8
  %v1325 = load i32, ptr %slot216, align 8
  %cv1326 = zext i32 %v1325 to i64
  %cond1327 = icmp ne i64 %cv1326, 0
  br i1 %cond1327, label %bb_rcslotdrop265, label %bb_rcslotdone265
bb_rcslotdrop265:
  %v1328 = load i64, ptr %slot7, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 0, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone265
bb_rcslotdone265:
  %v1330 = load i64, ptr %slot5, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  %ld1332 = load i32, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1332, ptr %slot217, align 8
  %v1333 = load i32, ptr %slot217, align 8
  %cv1334 = zext i32 %v1333 to i64
  %cond1335 = icmp ne i64 %cv1334, 0
  br i1 %cond1335, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v1336 = load i64, ptr %slot5, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 0, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot22, align 8
  store i64 %v1338, ptr %slot218, align 8
  %v1339 = load i64, ptr %slot6, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %ld1341 = load i32, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1341, ptr %slot219, align 8
  %v1342 = load i32, ptr %slot219, align 8
  %op1343 = and i32 %v1342, 28
  store i32 %op1343, ptr %slot220, align 8
  %v1344 = load i32, ptr %slot220, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v1347 = load i64, ptr %slot44, align 8
  store i64 %v1347, ptr %slot221, align 8
  %v1348 = load i64, ptr %slot221, align 8
  %v1349 = load i64, ptr %slot218, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1348, i64 %v1349) nomerge, !dbg !128
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v1350 = load i64, ptr %slot44, align 8
  store i64 %v1350, ptr %slot222, align 8
  %v1351 = load i64, ptr %slot222, align 8
  %v1352 = load i64, ptr %slot218, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1351, i64 %v1352) nomerge, !dbg !128
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v1353 = load i64, ptr %slot215, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ret1355 = load { i64, i64 }, ptr %p1354, align 8
  ret { i64, i64 } %ret1355
bb_i19:
  %v1356 = load i64, ptr %slot34, align 8
  store i64 %v1356, ptr %slot223, align 8
  %v1357 = load i64, ptr %slot223, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i64 0, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot223, align 8
  %p1361 = inttoptr i64 %v1359 to ptr
  %gep1362 = getelementptr i8, ptr %p1361, i64 8
  %op1360 = ptrtoint ptr %gep1362 to i64
  store i64 %op1360, ptr %slot224, align 8
  %v1363 = load i64, ptr %slot224, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  store i64 0, ptr %p1364, align 8, !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot223, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 1, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot15, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i32 1, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  %v1369 = load i64, ptr %slot24, align 8
  store i64 %v1369, ptr %slot225, align 8
  %v1370 = load i64, ptr %slot223, align 8
  %p1372 = inttoptr i64 %v1370 to ptr
  %gep1373 = getelementptr i8, ptr %p1372, i64 8
  %op1371 = ptrtoint ptr %gep1373 to i64
  store i64 %op1371, ptr %slot226, align 8
  %v1374 = load i64, ptr %slot45, align 8
  store i64 %v1374, ptr %slot227, align 8
  %v1375 = load i64, ptr %slot225, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot228, align 8
  %v1378 = load i64, ptr %slot228, align 8
  %v1379 = load i64, ptr %slot226, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i64 %v1378, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot223, align 8
  %v1382 = load i64, ptr %slot24, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i64 %v1381, ptr %p1383, align 8, !alias.scope !3, !noalias !4
  %v1384 = load i64, ptr %slot24, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  %ld1386 = load i64, ptr %p1385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1386, ptr %slot229, align 8
  %v1387 = load i64, ptr %slot229, align 8
  %v1388 = load i64, ptr %slot23, align 8
  %p1389 = inttoptr i64 %v1387 to ptr
  %p1390 = inttoptr i64 %v1388 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1390, ptr %p1389, i64 16, i1 false)
  br label %bb_i21
bb_i21:
  %v1391 = load i64, ptr %slot21, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i64, ptr %p1392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1393, ptr %slot230, align 8
  %v1394 = load i64, ptr %slot230, align 8
  %v1395 = load i64, ptr %slot24, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i64 %v1394, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot35, align 8
  store i64 %v1397, ptr %slot231, align 8
  %v1398 = load i64, ptr %slot231, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot231, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i32 8, ptr %p1401, align 4, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot231, align 8
  %v1403 = load i64, ptr %slot25, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 %v1402, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  %p1405 = inttoptr i64 ptrtoint (ptr @myl_lit_4e48faae1476188ceb23066f96fc5c60c763d46a99320deefec8a56ef9779402 to i64) to ptr
  %ld1406 = load i64, ptr %p1405, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1406, ptr %slot232, align 8
  %v1407 = load i64, ptr %slot232, align 8
  %v1408 = load i64, ptr %slot26, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i64 %v1407, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  %v1410 = load i64, ptr %slot26, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  %ld1412 = load i64, ptr %p1411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1412, ptr %slot233, align 8
  %v1413 = load i64, ptr %slot233, align 8
  %v1414 = load i64, ptr %slot19, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  store i64 %v1413, ptr %p1415, align 8, !alias.scope !3, !noalias !4
  %v1416 = load i64, ptr %slot19, align 8
  store i64 %v1416, ptr %slot234, align 8
  %v1417 = load i64, ptr %slot20, align 8
  store i64 %v1417, ptr %slot235, align 8
  %v1418 = load i64, ptr %slot234, align 8
  %v1419 = load i64, ptr %slot235, align 8
  %p1420 = inttoptr i64 %v1418 to ptr
  %p1421 = inttoptr i64 %v1419 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1421, ptr %p1420, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1422 = load i64, ptr %slot14, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 2, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot13, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 1, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot18, align 8
  store i64 %v1426, ptr %slot236, align 8
  %v1427 = load i64, ptr %slot20, align 8
  store i64 %v1427, ptr %slot237, align 8
  %v1428 = load i64, ptr %slot237, align 8
  %v1429 = load i64, ptr %slot236, align 8
  %p1430 = inttoptr i64 %v1428 to ptr
  %p1431 = inttoptr i64 %v1429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1431, ptr %p1430, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1432 = load i64, ptr %slot12, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  store i32 2, ptr %p1433, align 4, !alias.scope !3, !noalias !4
  %v1434 = load i64, ptr %slot14, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i32, ptr %p1435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1436, ptr %slot238, align 8
  %v1437 = load i32, ptr %slot238, align 8
  %v1438 = load i64, ptr %slot12, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  store i32 %v1437, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot13, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  store i32 0, ptr %p1441, align 4, !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot11, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i32 1, ptr %p1443, align 4, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot236, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  %ld1446 = load i64, ptr %p1445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1446, ptr %slot239, align 8
  %v1447 = load i64, ptr %slot239, align 8
  %v1448 = load i64, ptr %slot26, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i64 %v1447, ptr %p1449, align 8, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot24, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  %ld1452 = load i64, ptr %p1451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1452, ptr %slot240, align 8
  %v1453 = load i64, ptr %slot25, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %ld1455 = load i64, ptr %p1454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1455, ptr %slot241, align 8
  %v1456 = load i64, ptr %slot26, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %ld1458 = load i64, ptr %p1457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1458, ptr %slot242, align 8
  %v1459 = load i64, ptr %slot1, align 8
  %v1460 = load i64, ptr %slot240, align 8
  %v1461 = load i64, ptr %slot241, align 8
  %v1462 = load i64, ptr %slot242, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult244, i64 %v1459, i64 %v1460, i64 %v1461, i64 %v1462) nomerge, !dbg !130
  %addr1463 = ptrtoint ptr %callresult244 to i64
  store i64 %addr1463, ptr %slot243, align 8
  %v1464 = load i64, ptr %slot243, align 8
  %v1465 = load i64, ptr %slot24, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  store i64 %v1464, ptr %p1466, align 8, !alias.scope !3, !noalias !4
  %v1467 = load i64, ptr %slot24, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %ld1469 = load i64, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1469, ptr %slot245, align 8
  %v1470 = load i64, ptr %slot20, align 8
  store i64 %v1470, ptr %slot246, align 8
  %v1471 = load i64, ptr %slot245, align 8
  %v1472 = load i64, ptr %slot246, align 8
  %p1473 = inttoptr i64 %v1471 to ptr
  %p1474 = inttoptr i64 %v1472 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1474, ptr %p1473, i64 48, i1 false)
  %v1475 = load i64, ptr %slot14, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  store i32 2, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  %v1477 = load i64, ptr %slot13, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i32 1, ptr %p1478, align 4, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot7, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  %ld1481 = load i32, ptr %p1480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1481, ptr %slot247, align 8
  %v1482 = load i32, ptr %slot247, align 8
  %cv1483 = zext i32 %v1482 to i64
  %cond1484 = icmp ne i64 %cv1483, 0
  br i1 %cond1484, label %bb_rcslotdrop321, label %bb_rcslotdone321
bb_rcslotdrop321:
  %v1485 = load i64, ptr %slot7, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i32 0, ptr %p1486, align 4, !alias.scope !3, !noalias !4
  %v1487 = load i64, ptr %slot16, align 8
  store i64 %v1487, ptr %slot248, align 8
  %v1488 = load i64, ptr %slot8, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %ld1490 = load i32, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1490, ptr %slot249, align 8
  %v1491 = load i32, ptr %slot249, align 8
  %op1492 = and i32 %v1491, 28
  store i32 %op1492, ptr %slot250, align 8
  %v1493 = load i32, ptr %slot250, align 8
  %cv1494 = zext i32 %v1493 to i64
  %cond1495 = icmp ne i64 %cv1494, 0
  br i1 %cond1495, label %bb_rcslotrole321, label %bb_rcslotowner321
bb_rcslotrole321:
  %v1496 = load i64, ptr %slot44, align 8
  store i64 %v1496, ptr %slot251, align 8
  %v1497 = load i64, ptr %slot251, align 8
  %v1498 = load i64, ptr %slot248, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1497, i64 %v1498) nomerge, !dbg !130
  br label %bb_rcslotdone321
bb_rcslotowner321:
  %v1499 = load i64, ptr %slot44, align 8
  store i64 %v1499, ptr %slot252, align 8
  %v1500 = load i64, ptr %slot252, align 8
  %v1501 = load i64, ptr %slot248, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1500, i64 %v1501) nomerge, !dbg !130
  br label %bb_rcslotdone321
bb_rcslotdone321:
  %v1502 = load i64, ptr %slot11, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %ld1504 = load i32, ptr %p1503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1504, ptr %slot253, align 8
  %v1505 = load i32, ptr %slot253, align 8
  %cv1506 = zext i32 %v1505 to i64
  %cond1507 = icmp ne i64 %cv1506, 0
  br i1 %cond1507, label %bb_rcslotdrop330, label %bb_rcslotdone330
bb_rcslotdrop330:
  %v1508 = load i64, ptr %slot11, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i32 0, ptr %p1509, align 4, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot18, align 8
  store i64 %v1510, ptr %slot254, align 8
  %v1511 = load i64, ptr %slot12, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %ld1513 = load i32, ptr %p1512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1513, ptr %slot255, align 8
  %v1514 = load i32, ptr %slot255, align 8
  %op1515 = and i32 %v1514, 28
  store i32 %op1515, ptr %slot256, align 8
  %v1516 = load i32, ptr %slot256, align 8
  %cv1517 = zext i32 %v1516 to i64
  %cond1518 = icmp ne i64 %cv1517, 0
  br i1 %cond1518, label %bb_rcslotrole330, label %bb_rcslotowner330
bb_rcslotrole330:
  %v1519 = load i64, ptr %slot44, align 8
  store i64 %v1519, ptr %slot257, align 8
  %v1520 = load i64, ptr %slot254, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  %ld1522 = load i64, ptr %p1521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1522, ptr %slot258, align 8
  %v1523 = load i64, ptr %slot258, align 8
  %cmp1524 = icmp ne i64 %v1523, 0
  %cv1525 = zext i1 %cmp1524 to i32
  store i32 %cv1525, ptr %slot259, align 8
  %v1526 = load i32, ptr %slot259, align 8
  %cv1527 = zext i32 %v1526 to i64
  %cond1528 = icmp ne i64 %cv1527, 0
  br i1 %cond1528, label %bb_rcgnn346, label %bb_rcgdone346
bb_rcgnn346:
  %v1529 = load i64, ptr %slot258, align 8
  %op1530 = sub i64 %v1529, 16
  store i64 %op1530, ptr %slot260, align 8
  %v1531 = load i64, ptr %slot258, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %rgep1533 = getelementptr i8, ptr %p1532, i64 -16
  %ld1534 = load i64, ptr %rgep1533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1534, ptr %slot261, align 8
  %v1535 = load i64, ptr %slot261, align 8
  %op1536 = and i64 %v1535, 4611686018427387906
  store i64 %op1536, ptr %slot262, align 8
  %v1537 = load i64, ptr %slot262, align 8
  %cmp1538 = icmp ne i64 %v1537, 0
  %cv1539 = zext i1 %cmp1538 to i32
  store i32 %cv1539, ptr %slot263, align 8
  %v1540 = load i32, ptr %slot263, align 8
  %cv1541 = zext i32 %v1540 to i64
  %cond1542 = icmp ne i64 %cv1541, 0
  br i1 %cond1542, label %bb_rcgclear346, label %bb_rcgcounted346
bb_rcgcounted346:
  %v1543 = load i64, ptr %slot258, align 8
  %op1544 = sub i64 %v1543, 24
  store i64 %op1544, ptr %slot264, align 8
  %v1545 = load i64, ptr %slot258, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %rgep1547 = getelementptr i8, ptr %p1546, i64 -24
  %ld1548 = load i64, ptr %rgep1547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1548, ptr %slot265, align 8
  %v1549 = load i64, ptr %slot265, align 8
  %op1550 = sub i64 %v1549, 1
  store i64 %op1550, ptr %slot266, align 8
  %v1551 = load i64, ptr %slot266, align 8
  %cmp1552 = icmp eq i64 %v1551, 0
  %cv1553 = zext i1 %cmp1552 to i32
  store i32 %cv1553, ptr %slot267, align 8
  %v1554 = load i32, ptr %slot267, align 8
  %cv1555 = zext i32 %v1554 to i64
  %cond1556 = icmp ne i64 %cv1555, 0
  br i1 %cond1556, label %bb_rcglast346, label %bb_rcgdec346
bb_rcglast346:
  %v1557 = load i64, ptr %slot258, align 8
  %op1558 = sub i64 %v1557, 32
  store i64 %op1558, ptr %slot268, align 8
  %v1559 = load i64, ptr %slot258, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %rgep1561 = getelementptr i8, ptr %p1560, i64 -32
  %ld1562 = load i64, ptr %rgep1561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1562, ptr %slot269, align 8
  %v1563 = load i64, ptr %slot269, align 8
  %cmp1564 = icmp ne i64 %v1563, 0
  %cv1565 = zext i1 %cmp1564 to i32
  store i32 %cv1565, ptr %slot270, align 8
  %v1566 = load i32, ptr %slot270, align 8
  %cv1567 = zext i32 %v1566 to i64
  %cond1568 = icmp ne i64 %cv1567, 0
  br i1 %cond1568, label %bb_rcgdec346, label %bb_rcgslow346
bb_rcgslow346:
  %v1569 = load i64, ptr %slot257, align 8
  %v1570 = load i64, ptr %slot254, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1569, i64 %v1570) nomerge, !dbg !130
  br label %bb_rcgdone346
bb_rcgdec346:
  %v1571 = load i64, ptr %slot266, align 8
  %v1572 = load i64, ptr %slot258, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %rgep1574 = getelementptr i8, ptr %p1573, i64 -24
  store i64 %v1571, ptr %rgep1574, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear346
bb_rcgclear346:
  %v1575 = load i64, ptr %slot254, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  store i64 0, ptr %p1576, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone346
bb_rcgdone346:
  br label %bb_rcslotdone330
bb_rcslotowner330:
  %v1577 = load i64, ptr %slot44, align 8
  store i64 %v1577, ptr %slot271, align 8
  %v1578 = load i64, ptr %slot254, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  %ld1580 = load i64, ptr %p1579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1580, ptr %slot272, align 8
  %v1581 = load i64, ptr %slot272, align 8
  %cmp1582 = icmp ne i64 %v1581, 0
  %cv1583 = zext i1 %cmp1582 to i32
  store i32 %cv1583, ptr %slot273, align 8
  %v1584 = load i32, ptr %slot273, align 8
  %cv1585 = zext i32 %v1584 to i64
  %cond1586 = icmp ne i64 %cv1585, 0
  br i1 %cond1586, label %bb_rcgnn361, label %bb_rcgdone361
bb_rcgnn361:
  %v1587 = load i64, ptr %slot272, align 8
  %op1588 = sub i64 %v1587, 16
  store i64 %op1588, ptr %slot274, align 8
  %v1589 = load i64, ptr %slot272, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %rgep1591 = getelementptr i8, ptr %p1590, i64 -16
  %ld1592 = load i64, ptr %rgep1591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1592, ptr %slot275, align 8
  %v1593 = load i64, ptr %slot275, align 8
  %op1594 = and i64 %v1593, 4611686018427387906
  store i64 %op1594, ptr %slot276, align 8
  %v1595 = load i64, ptr %slot276, align 8
  %cmp1596 = icmp ne i64 %v1595, 0
  %cv1597 = zext i1 %cmp1596 to i32
  store i32 %cv1597, ptr %slot277, align 8
  %v1598 = load i32, ptr %slot277, align 8
  %cv1599 = zext i32 %v1598 to i64
  %cond1600 = icmp ne i64 %cv1599, 0
  br i1 %cond1600, label %bb_rcgclear361, label %bb_rcgcounted361
bb_rcgcounted361:
  %v1601 = load i64, ptr %slot272, align 8
  %op1602 = sub i64 %v1601, 32
  store i64 %op1602, ptr %slot278, align 8
  %v1603 = load i64, ptr %slot272, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %rgep1605 = getelementptr i8, ptr %p1604, i64 -32
  %ld1606 = load i64, ptr %rgep1605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1606, ptr %slot279, align 8
  %v1607 = load i64, ptr %slot279, align 8
  %op1608 = sub i64 %v1607, 1
  store i64 %op1608, ptr %slot280, align 8
  %v1609 = load i64, ptr %slot280, align 8
  %cmp1610 = icmp eq i64 %v1609, 0
  %cv1611 = zext i1 %cmp1610 to i32
  store i32 %cv1611, ptr %slot281, align 8
  %v1612 = load i32, ptr %slot281, align 8
  %cv1613 = zext i32 %v1612 to i64
  %cond1614 = icmp ne i64 %cv1613, 0
  br i1 %cond1614, label %bb_rcglast361, label %bb_rcgdec361
bb_rcglast361:
  %v1615 = load i64, ptr %slot272, align 8
  %op1616 = sub i64 %v1615, 24
  store i64 %op1616, ptr %slot282, align 8
  %v1617 = load i64, ptr %slot272, align 8
  %p1618 = inttoptr i64 %v1617 to ptr
  %rgep1619 = getelementptr i8, ptr %p1618, i64 -24
  %ld1620 = load i64, ptr %rgep1619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1620, ptr %slot283, align 8
  %v1621 = load i64, ptr %slot283, align 8
  %cmp1622 = icmp ne i64 %v1621, 0
  %cv1623 = zext i1 %cmp1622 to i32
  store i32 %cv1623, ptr %slot284, align 8
  %v1624 = load i32, ptr %slot284, align 8
  %cv1625 = zext i32 %v1624 to i64
  %cond1626 = icmp ne i64 %cv1625, 0
  br i1 %cond1626, label %bb_rcgdec361, label %bb_rcgslow361
bb_rcgslow361:
  %v1627 = load i64, ptr %slot271, align 8
  %v1628 = load i64, ptr %slot254, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1627, i64 %v1628) nomerge, !dbg !130
  br label %bb_rcgdone361
bb_rcgdec361:
  %v1629 = load i64, ptr %slot280, align 8
  %v1630 = load i64, ptr %slot272, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  %rgep1632 = getelementptr i8, ptr %p1631, i64 -32
  store i64 %v1629, ptr %rgep1632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear361
bb_rcgclear361:
  %v1633 = load i64, ptr %slot254, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 0, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone361
bb_rcgdone361:
  br label %bb_rcslotdone330
bb_rcslotdone330:
  %v1635 = load i64, ptr %slot16, align 8
  store i64 %v1635, ptr %slot285, align 8
  %v1636 = load i64, ptr %slot20, align 8
  store i64 %v1636, ptr %slot286, align 8
  %v1637 = load i64, ptr %slot286, align 8
  %v1638 = load i64, ptr %slot285, align 8
  %p1639 = inttoptr i64 %v1637 to ptr
  %p1640 = inttoptr i64 %v1638 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1640, ptr %p1639, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v1641 = load i64, ptr %slot8, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  store i32 2, ptr %p1642, align 4, !alias.scope !3, !noalias !4
  %v1643 = load i64, ptr %slot14, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  %ld1645 = load i32, ptr %p1644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1645, ptr %slot287, align 8
  %v1646 = load i32, ptr %slot287, align 8
  %v1647 = load i64, ptr %slot8, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  store i32 %v1646, ptr %p1648, align 4, !alias.scope !3, !noalias !4
  %v1649 = load i64, ptr %slot13, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  store i32 0, ptr %p1650, align 4, !alias.scope !3, !noalias !4
  %v1651 = load i64, ptr %slot7, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  store i32 1, ptr %p1652, align 4, !alias.scope !3, !noalias !4
  %v1653 = load i64, ptr %slot285, align 8
  %v1654 = load i64, ptr %slot24, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  store i64 %v1653, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  %v1656 = load i64, ptr %slot24, align 8
  %p1657 = inttoptr i64 %v1656 to ptr
  %ld1658 = load i64, ptr %p1657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1658, ptr %slot288, align 8
  %v1659 = load i64, ptr %slot288, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i32, ptr %p1660, align 4
  %ext1662 = zext i32 %ld1661 to i64
  store i64 %ext1662, ptr %slot289, align 8
  %v1663 = load i64, ptr %slot289, align 8
  %cmp1664 = icmp eq i64 %v1663, 0
  %cv1665 = zext i1 %cmp1664 to i64
  store i64 %cv1665, ptr %slot290, align 8
  %v1666 = load i64, ptr %slot290, align 8
  %cond1667 = icmp ne i64 %v1666, 0
  br i1 %cond1667, label %bb_rctryok374, label %bb_rctryerror374
bb_rctryerror374:
  %p1668 = inttoptr i64 ptrtoint (ptr @myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1668, i64 12884901913) "call-inline-cost"="0", !dbg !132
  %v1669 = load i64, ptr %slot288, align 8
  %op1670 = add i64 %v1669, 8
  store i64 %op1670, ptr %slot291, align 8
  %v1671 = load i64, ptr %slot36, align 8
  store i64 %v1671, ptr %slot292, align 8
  %v1672 = load i64, ptr %slot292, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  store i64 0, ptr %p1673, align 8, !alias.scope !3, !noalias !4
  %v1674 = load i64, ptr %slot292, align 8
  %p1676 = inttoptr i64 %v1674 to ptr
  %gep1677 = getelementptr i8, ptr %p1676, i64 8
  %op1675 = ptrtoint ptr %gep1677 to i64
  store i64 %op1675, ptr %slot293, align 8
  %v1678 = load i64, ptr %slot293, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  store i64 0, ptr %p1679, align 8, !alias.scope !3, !noalias !4
  %v1680 = load i64, ptr %slot292, align 8
  %p1681 = inttoptr i64 %v1680 to ptr
  store i32 1, ptr %p1681, align 4, !alias.scope !3, !noalias !4
  %v1682 = load i64, ptr %slot292, align 8
  %p1684 = inttoptr i64 %v1682 to ptr
  %gep1685 = getelementptr i8, ptr %p1684, i64 8
  %op1683 = ptrtoint ptr %gep1685 to i64
  store i64 %op1683, ptr %slot294, align 8
  %v1686 = load i64, ptr %slot15, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i32 1, ptr %p1687, align 4, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot45, align 8
  store i64 %v1688, ptr %slot295, align 8
  %v1689 = load i64, ptr %slot292, align 8
  %v1690 = load i64, ptr %slot24, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i64 %v1689, ptr %p1691, align 8, !alias.scope !3, !noalias !4
  %v1692 = load i64, ptr %slot7, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i32, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1694, ptr %slot296, align 8
  %v1695 = load i32, ptr %slot296, align 8
  %cv1696 = zext i32 %v1695 to i64
  %cond1697 = icmp ne i64 %cv1696, 0
  br i1 %cond1697, label %bb_rcslotdrop385, label %bb_rcslotdone385
bb_rcslotdrop385:
  %v1698 = load i64, ptr %slot7, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  store i32 0, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  %v1700 = load i64, ptr %slot16, align 8
  store i64 %v1700, ptr %slot297, align 8
  %v1701 = load i64, ptr %slot8, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %ld1703 = load i32, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1703, ptr %slot298, align 8
  %v1704 = load i32, ptr %slot298, align 8
  %op1705 = and i32 %v1704, 28
  store i32 %op1705, ptr %slot299, align 8
  %v1706 = load i32, ptr %slot299, align 8
  %cv1707 = zext i32 %v1706 to i64
  %cond1708 = icmp ne i64 %cv1707, 0
  br i1 %cond1708, label %bb_rcslotrole385, label %bb_rcslotowner385
bb_rcslotrole385:
  %v1709 = load i64, ptr %slot44, align 8
  store i64 %v1709, ptr %slot300, align 8
  %v1710 = load i64, ptr %slot300, align 8
  %v1711 = load i64, ptr %slot297, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1710, i64 %v1711) nomerge, !dbg !132
  br label %bb_rcslotdone385
bb_rcslotowner385:
  %v1712 = load i64, ptr %slot44, align 8
  store i64 %v1712, ptr %slot301, align 8
  %v1713 = load i64, ptr %slot301, align 8
  %v1714 = load i64, ptr %slot297, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1713, i64 %v1714) nomerge, !dbg !132
  br label %bb_rcslotdone385
bb_rcslotdone385:
  br label %bb_i27
bb_rctryok374:
  %v1715 = load i64, ptr %slot36, align 8
  store i64 %v1715, ptr %slot302, align 8
  %v1716 = load i64, ptr %slot302, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  store i64 0, ptr %p1717, align 8, !alias.scope !3, !noalias !4
  %v1718 = load i64, ptr %slot302, align 8
  %p1720 = inttoptr i64 %v1718 to ptr
  %gep1721 = getelementptr i8, ptr %p1720, i64 8
  %op1719 = ptrtoint ptr %gep1721 to i64
  store i64 %op1719, ptr %slot303, align 8
  %v1722 = load i64, ptr %slot303, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i64 0, ptr %p1723, align 8, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot302, align 8
  %p1726 = inttoptr i64 %v1724 to ptr
  %gep1727 = getelementptr i8, ptr %p1726, i64 16
  %op1725 = ptrtoint ptr %gep1727 to i64
  store i64 %op1725, ptr %slot304, align 8
  %v1728 = load i64, ptr %slot304, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  store i64 0, ptr %p1729, align 8, !alias.scope !3, !noalias !4
  %v1730 = load i64, ptr %slot302, align 8
  %p1732 = inttoptr i64 %v1730 to ptr
  %gep1733 = getelementptr i8, ptr %p1732, i64 24
  %op1731 = ptrtoint ptr %gep1733 to i64
  store i64 %op1731, ptr %slot305, align 8
  %v1734 = load i64, ptr %slot305, align 8
  %p1735 = inttoptr i64 %v1734 to ptr
  store i64 0, ptr %p1735, align 8, !alias.scope !3, !noalias !4
  %v1736 = load i64, ptr %slot302, align 8
  %p1738 = inttoptr i64 %v1736 to ptr
  %gep1739 = getelementptr i8, ptr %p1738, i64 32
  %op1737 = ptrtoint ptr %gep1739 to i64
  store i64 %op1737, ptr %slot306, align 8
  %v1740 = load i64, ptr %slot306, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  store i64 0, ptr %p1741, align 8, !alias.scope !3, !noalias !4
  %v1742 = load i64, ptr %slot15, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  store i32 1, ptr %p1743, align 4, !alias.scope !3, !noalias !4
  %v1744 = load i64, ptr %slot288, align 8
  %op1745 = add i64 %v1744, 8
  store i64 %op1745, ptr %slot307, align 8
  %v1746 = load i64, ptr %slot45, align 8
  store i64 %v1746, ptr %slot308, align 8
  %v1747 = load i64, ptr %slot44, align 8
  %v1748 = load i64, ptr %slot302, align 8
  %v1749 = load i64, ptr %slot307, align 8
  %v1750 = load i64, ptr %slot308, align 8
  %cv1751 = trunc i64 %v1750 to i32
  %call1752 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v1747, i64 %v1748, i64 %v1749, i32 %cv1751) nomerge, !dbg !132
  store i32 %call1752, ptr %slot309, align 8
  %v1753 = load i32, ptr %slot309, align 8
  %cv1754 = zext i32 %v1753 to i64
  %cond1755 = icmp ne i64 %cv1754, 0
  br i1 %cond1755, label %bb_rcsuccess402, label %bb_rcfailure402
bb_rcfailure402:
  %v1756 = load i64, ptr %slot44, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %call1758 = call i32 @myl_rc_take_failure(ptr %p1757) nomerge, !dbg !132
  store i32 %call1758, ptr %slot310, align 8
  %v1759 = load i64, ptr %slot1, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  %v1761 = load i32, ptr %slot310, align 8
  %call1762 = call i32 @myl_qbe_rc_status(ptr %p1760, i32 %v1761) nomerge, !dbg !132
  store i32 %call1762, ptr %slot311, align 8
  br label %bb_failure
bb_rcsuccess402:
  %v1763 = load i64, ptr %slot302, align 8
  %v1764 = load i64, ptr %slot24, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  store i64 %v1763, ptr %p1765, align 8, !alias.scope !3, !noalias !4
  %v1766 = load i64, ptr %slot24, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %ld1768 = load i64, ptr %p1767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1768, ptr %slot312, align 8
  %v1769 = load i64, ptr %slot20, align 8
  store i64 %v1769, ptr %slot313, align 8
  %v1770 = load i64, ptr %slot312, align 8
  %v1771 = load i64, ptr %slot313, align 8
  %p1772 = inttoptr i64 %v1770 to ptr
  %p1773 = inttoptr i64 %v1771 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1773, ptr %p1772, i64 40, i1 false)
  %v1774 = load i64, ptr %slot14, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  store i32 2, ptr %p1775, align 4, !alias.scope !3, !noalias !4
  %v1776 = load i64, ptr %slot13, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  store i32 1, ptr %p1777, align 4, !alias.scope !3, !noalias !4
  %v1778 = load i64, ptr %slot7, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %ld1780 = load i32, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1780, ptr %slot314, align 8
  %v1781 = load i32, ptr %slot314, align 8
  %cv1782 = zext i32 %v1781 to i64
  %cond1783 = icmp ne i64 %cv1782, 0
  br i1 %cond1783, label %bb_rcslotdrop411, label %bb_rcslotdone411
bb_rcslotdrop411:
  %v1784 = load i64, ptr %slot7, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  store i32 0, ptr %p1785, align 4, !alias.scope !3, !noalias !4
  %v1786 = load i64, ptr %slot16, align 8
  store i64 %v1786, ptr %slot315, align 8
  %v1787 = load i64, ptr %slot8, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i32, ptr %p1788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1789, ptr %slot316, align 8
  %v1790 = load i32, ptr %slot316, align 8
  %op1791 = and i32 %v1790, 28
  store i32 %op1791, ptr %slot317, align 8
  %v1792 = load i32, ptr %slot317, align 8
  %cv1793 = zext i32 %v1792 to i64
  %cond1794 = icmp ne i64 %cv1793, 0
  br i1 %cond1794, label %bb_rcslotrole411, label %bb_rcslotowner411
bb_rcslotrole411:
  %v1795 = load i64, ptr %slot44, align 8
  store i64 %v1795, ptr %slot318, align 8
  %v1796 = load i64, ptr %slot318, align 8
  %v1797 = load i64, ptr %slot315, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v1796, i64 %v1797) nomerge, !dbg !132
  br label %bb_rcslotdone411
bb_rcslotowner411:
  %v1798 = load i64, ptr %slot44, align 8
  store i64 %v1798, ptr %slot319, align 8
  %v1799 = load i64, ptr %slot319, align 8
  %v1800 = load i64, ptr %slot315, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v1799, i64 %v1800) nomerge, !dbg !132
  br label %bb_rcslotdone411
bb_rcslotdone411:
  %v1801 = load i64, ptr %slot16, align 8
  store i64 %v1801, ptr %slot320, align 8
  %v1802 = load i64, ptr %slot20, align 8
  store i64 %v1802, ptr %slot321, align 8
  %v1803 = load i64, ptr %slot321, align 8
  %v1804 = load i64, ptr %slot320, align 8
  %p1805 = inttoptr i64 %v1803 to ptr
  %p1806 = inttoptr i64 %v1804 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1806, ptr %p1805, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot8, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 2, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot14, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %ld1811 = load i32, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1811, ptr %slot322, align 8
  %v1812 = load i32, ptr %slot322, align 8
  %v1813 = load i64, ptr %slot8, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 %v1812, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot13, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 0, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot7, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 1, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot320, align 8
  %v1820 = load i64, ptr %slot24, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i64 %v1819, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  br label %bb_i28
bb_i27:
  %v1822 = load i64, ptr %slot24, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i64, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1824, ptr %slot323, align 8
  %v1825 = load i64, ptr %slot7, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i32, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1827, ptr %slot324, align 8
  %v1828 = load i32, ptr %slot324, align 8
  %cv1829 = zext i32 %v1828 to i64
  %cond1830 = icmp ne i64 %cv1829, 0
  br i1 %cond1830, label %bb_rcslotdrop429, label %bb_rcslotdone429
bb_rcslotdrop429:
  %v1831 = load i64, ptr %slot7, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 0, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone429
bb_rcslotdone429:
  %v1833 = load i64, ptr %slot5, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  %ld1835 = load i32, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1835, ptr %slot325, align 8
  %v1836 = load i32, ptr %slot325, align 8
  %cv1837 = zext i32 %v1836 to i64
  %cond1838 = icmp ne i64 %cv1837, 0
  br i1 %cond1838, label %bb_rcslotdrop432, label %bb_rcslotdone432
bb_rcslotdrop432:
  %v1839 = load i64, ptr %slot5, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i32 0, ptr %p1840, align 4, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot22, align 8
  store i64 %v1841, ptr %slot326, align 8
  %v1842 = load i64, ptr %slot6, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  %ld1844 = load i32, ptr %p1843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1844, ptr %slot327, align 8
  %v1845 = load i32, ptr %slot327, align 8
  %op1846 = and i32 %v1845, 28
  store i32 %op1846, ptr %slot328, align 8
  %v1847 = load i32, ptr %slot328, align 8
  %cv1848 = zext i32 %v1847 to i64
  %cond1849 = icmp ne i64 %cv1848, 0
  br i1 %cond1849, label %bb_rcslotrole432, label %bb_rcslotowner432
bb_rcslotrole432:
  %v1850 = load i64, ptr %slot44, align 8
  store i64 %v1850, ptr %slot329, align 8
  %v1851 = load i64, ptr %slot329, align 8
  %v1852 = load i64, ptr %slot326, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1851, i64 %v1852) nomerge, !dbg !134
  br label %bb_rcslotdone432
bb_rcslotowner432:
  %v1853 = load i64, ptr %slot44, align 8
  store i64 %v1853, ptr %slot330, align 8
  %v1854 = load i64, ptr %slot330, align 8
  %v1855 = load i64, ptr %slot326, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1854, i64 %v1855) nomerge, !dbg !134
  br label %bb_rcslotdone432
bb_rcslotdone432:
  %v1856 = load i64, ptr %slot323, align 8
  %p1857 = inttoptr i64 %v1856 to ptr
  %ret1858 = load { i64, i64 }, ptr %p1857, align 8
  ret { i64, i64 } %ret1858
bb_i28:
  %v1859 = load i64, ptr %slot7, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  %ld1861 = load i32, ptr %p1860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1861, ptr %slot331, align 8
  %v1862 = load i32, ptr %slot331, align 8
  %cv1863 = zext i32 %v1862 to i64
  %cond1864 = icmp ne i64 %cv1863, 0
  br i1 %cond1864, label %bb_rcslotdrop450, label %bb_rcslotdone450
bb_rcslotdrop450:
  %v1865 = load i64, ptr %slot7, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  store i32 0, ptr %p1866, align 4, !alias.scope !3, !noalias !4
  %v1867 = load i64, ptr %slot16, align 8
  store i64 %v1867, ptr %slot332, align 8
  %v1868 = load i64, ptr %slot8, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  %ld1870 = load i32, ptr %p1869, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1870, ptr %slot333, align 8
  %v1871 = load i32, ptr %slot333, align 8
  %op1872 = and i32 %v1871, 28
  store i32 %op1872, ptr %slot334, align 8
  %v1873 = load i32, ptr %slot334, align 8
  %cv1874 = zext i32 %v1873 to i64
  %cond1875 = icmp ne i64 %cv1874, 0
  br i1 %cond1875, label %bb_rcslotrole450, label %bb_rcslotowner450
bb_rcslotrole450:
  %v1876 = load i64, ptr %slot44, align 8
  store i64 %v1876, ptr %slot335, align 8
  %v1877 = load i64, ptr %slot335, align 8
  %v1878 = load i64, ptr %slot332, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1877, i64 %v1878) nomerge, !dbg !136
  br label %bb_rcslotdone450
bb_rcslotowner450:
  %v1879 = load i64, ptr %slot44, align 8
  store i64 %v1879, ptr %slot336, align 8
  %v1880 = load i64, ptr %slot336, align 8
  %v1881 = load i64, ptr %slot332, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1880, i64 %v1881) nomerge, !dbg !136
  br label %bb_rcslotdone450
bb_rcslotdone450:
  %v1882 = load i64, ptr %slot21, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %ld1884 = load i64, ptr %p1883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1884, ptr %slot337, align 8
  %v1885 = load i64, ptr %slot337, align 8
  %v1886 = load i64, ptr %slot24, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i64 %v1885, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot22, align 8
  %v1889 = load i64, ptr %slot25, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i64 %v1888, ptr %p1890, align 8, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot21, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %ld1893 = load i64, ptr %p1892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1893, ptr %slot338, align 8
  %v1894 = load i64, ptr %slot338, align 8
  %v1895 = load i64, ptr %slot26, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i64 %v1894, ptr %p1896, align 8, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot22, align 8
  %v1898 = load i64, ptr %slot27, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  store i64 %v1897, ptr %p1899, align 8, !alias.scope !3, !noalias !4
  %v1900 = load i64, ptr %slot26, align 8
  %p1901 = inttoptr i64 %v1900 to ptr
  %ld1902 = load i64, ptr %p1901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1902, ptr %slot339, align 8
  %v1903 = load i64, ptr %slot27, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  %ld1905 = load i64, ptr %p1904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1905, ptr %slot340, align 8
  %v1906 = load i64, ptr %slot1, align 8
  %v1907 = load i64, ptr %slot339, align 8
  %v1908 = load i64, ptr %slot340, align 8
  %call1909 = call i64 @myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4(i64 %v1906, i64 %v1907, i64 %v1908) nomerge, !dbg !138
  store i64 %call1909, ptr %slot341, align 8
  %v1910 = load i64, ptr %slot341, align 8
  %v1911 = load i64, ptr %slot26, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  store i64 %v1910, ptr %p1912, align 8, !alias.scope !3, !noalias !4
  %v1913 = load i64, ptr %slot11, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %ld1915 = load i32, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1915, ptr %slot342, align 8
  %v1916 = load i32, ptr %slot342, align 8
  %cv1917 = zext i32 %v1916 to i64
  %cond1918 = icmp ne i64 %cv1917, 0
  br i1 %cond1918, label %bb_rcslotdrop464, label %bb_rcslotdone464
bb_rcslotdrop464:
  %v1919 = load i64, ptr %slot11, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i32 0, ptr %p1920, align 4, !alias.scope !3, !noalias !4
  %v1921 = load i64, ptr %slot18, align 8
  store i64 %v1921, ptr %slot343, align 8
  %v1922 = load i64, ptr %slot12, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i32, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1924, ptr %slot344, align 8
  %v1925 = load i32, ptr %slot344, align 8
  %op1926 = and i32 %v1925, 28
  store i32 %op1926, ptr %slot345, align 8
  %v1927 = load i32, ptr %slot345, align 8
  %cv1928 = zext i32 %v1927 to i64
  %cond1929 = icmp ne i64 %cv1928, 0
  br i1 %cond1929, label %bb_rcslotrole464, label %bb_rcslotowner464
bb_rcslotrole464:
  %v1930 = load i64, ptr %slot44, align 8
  store i64 %v1930, ptr %slot346, align 8
  %v1931 = load i64, ptr %slot346, align 8
  %v1932 = load i64, ptr %slot343, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1931, i64 %v1932) nomerge, !dbg !138
  br label %bb_rcslotdone464
bb_rcslotowner464:
  %v1933 = load i64, ptr %slot44, align 8
  store i64 %v1933, ptr %slot347, align 8
  %v1934 = load i64, ptr %slot347, align 8
  %v1935 = load i64, ptr %slot343, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1934, i64 %v1935) nomerge, !dbg !138
  br label %bb_rcslotdone464
bb_rcslotdone464:
  %v1936 = load i64, ptr %slot23, align 8
  %v1937 = load i64, ptr %slot27, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i64 %v1936, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot28, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  store i64 18446744073709551615, ptr %p1940, align 8, !alias.scope !3, !noalias !4
  %v1941 = load i64, ptr %slot37, align 8
  store i64 %v1941, ptr %slot348, align 8
  %v1942 = load i64, ptr %slot348, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  call void @llvm.memset.p0.i64(ptr %p1943, i8 0, i64 72, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1944 = load i64, ptr %slot15, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  store i32 1, ptr %p1945, align 4, !alias.scope !3, !noalias !4
  %v1946 = load i64, ptr %slot45, align 8
  store i64 %v1946, ptr %slot349, align 8
  %v1947 = load i64, ptr %slot25, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %ld1949 = load i64, ptr %p1948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1949, ptr %slot350, align 8
  %v1950 = load i64, ptr %slot348, align 8
  %p1952 = inttoptr i64 %v1950 to ptr
  %gep1953 = getelementptr i8, ptr %p1952, i64 0
  %op1951 = ptrtoint ptr %gep1953 to i64
  store i64 %op1951, ptr %slot351, align 8
  %v1954 = load i64, ptr %slot25, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  %ld1956 = load i64, ptr %p1955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1956, ptr %slot352, align 8
  %v1957 = load i64, ptr %slot9, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  %ld1959 = load i32, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1959, ptr %slot353, align 8
  %v1960 = load i64, ptr %slot10, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %ld1962 = load i32, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1962, ptr %slot354, align 8
  %v1963 = load i32, ptr %slot354, align 8
  %op1964 = and i32 %v1963, 24
  store i32 %op1964, ptr %slot354, align 8
  %v1965 = load i32, ptr %slot354, align 8
  %cmp1966 = icmp eq i32 %v1965, 0
  %cv1967 = zext i1 %cmp1966 to i32
  store i32 %cv1967, ptr %slot355, align 8
  %v1968 = load i32, ptr %slot353, align 8
  %v1969 = load i32, ptr %slot355, align 8
  %op1970 = and i32 %v1968, %v1969
  store i32 %op1970, ptr %slot356, align 8
  %v1971 = load i32, ptr %slot356, align 8
  %cv1972 = zext i32 %v1971 to i64
  %cond1973 = icmp ne i64 %cv1972, 0
  br i1 %cond1973, label %bb_rctake487, label %bb_rccopy487
bb_rctake487:
  %v1974 = load i64, ptr %slot20, align 8
  store i64 %v1974, ptr %slot357, align 8
  %v1975 = load i64, ptr %slot45, align 8
  store i64 %v1975, ptr %slot358, align 8
  %v1976 = load i64, ptr %slot44, align 8
  %v1977 = load i64, ptr %slot357, align 8
  %v1978 = load i64, ptr %slot352, align 8
  %v1979 = load i64, ptr %slot358, align 8
  %cv1980 = trunc i64 %v1979 to i32
  %call1981 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v1976, i64 %v1977, i64 %v1978, i32 %cv1980) nomerge, !dbg !140
  store i32 %call1981, ptr %slot359, align 8
  %v1982 = load i32, ptr %slot359, align 8
  %cv1983 = zext i32 %v1982 to i64
  %cond1984 = icmp ne i64 %cv1983, 0
  br i1 %cond1984, label %bb_rcsuccess497, label %bb_rcfailure497
bb_rcfailure497:
  %v1985 = load i64, ptr %slot44, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %call1987 = call i32 @myl_rc_take_failure(ptr %p1986) nomerge, !dbg !140
  store i32 %call1987, ptr %slot360, align 8
  %v1988 = load i64, ptr %slot1, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  %v1990 = load i32, ptr %slot360, align 8
  %call1991 = call i32 @myl_qbe_rc_status(ptr %p1989, i32 %v1990) nomerge, !dbg !140
  store i32 %call1991, ptr %slot361, align 8
  br label %bb_failure
bb_rcsuccess497:
  %v1992 = load i64, ptr %slot9, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  store i32 0, ptr %p1993, align 4, !alias.scope !3, !noalias !4
  %v1994 = load i64, ptr %slot14, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i32 2, ptr %p1995, align 4, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot13, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i32 1, ptr %p1997, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared487
bb_rccopy487:
  %v1998 = load i64, ptr %slot20, align 8
  store i64 %v1998, ptr %slot362, align 8
  %v1999 = load i64, ptr %slot45, align 8
  store i64 %v1999, ptr %slot363, align 8
  %v2000 = load i64, ptr %slot44, align 8
  %v2001 = load i64, ptr %slot362, align 8
  %v2002 = load i64, ptr %slot352, align 8
  %v2003 = load i64, ptr %slot363, align 8
  %cv2004 = trunc i64 %v2003 to i32
  %call2005 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v2000, i64 %v2001, i64 %v2002, i32 %cv2004) nomerge, !dbg !140
  store i32 %call2005, ptr %slot364, align 8
  %v2006 = load i32, ptr %slot364, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcsuccess506, label %bb_rcfailure506
bb_rcfailure506:
  %v2009 = load i64, ptr %slot44, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %call2011 = call i32 @myl_rc_take_failure(ptr %p2010) nomerge, !dbg !140
  store i32 %call2011, ptr %slot365, align 8
  %v2012 = load i64, ptr %slot1, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %v2014 = load i32, ptr %slot365, align 8
  %call2015 = call i32 @myl_qbe_rc_status(ptr %p2013, i32 %v2014) nomerge, !dbg !140
  store i32 %call2015, ptr %slot366, align 8
  br label %bb_failure
bb_rcsuccess506:
  %v2016 = load i64, ptr %slot14, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  store i32 2, ptr %p2017, align 4, !alias.scope !3, !noalias !4
  %v2018 = load i64, ptr %slot13, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i32 1, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot9, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  %ld2022 = load i32, ptr %p2021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2022, ptr %slot367, align 8
  %v2023 = load i32, ptr %slot367, align 8
  %cv2024 = zext i32 %v2023 to i64
  %cond2025 = icmp ne i64 %cv2024, 0
  br i1 %cond2025, label %bb_rcslotdrop513, label %bb_rcslotdone513
bb_rcslotdrop513:
  %v2026 = load i64, ptr %slot9, align 8
  %p2027 = inttoptr i64 %v2026 to ptr
  store i32 0, ptr %p2027, align 4, !alias.scope !3, !noalias !4
  %v2028 = load i64, ptr %slot17, align 8
  store i64 %v2028, ptr %slot368, align 8
  %v2029 = load i64, ptr %slot10, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  %ld2031 = load i32, ptr %p2030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2031, ptr %slot369, align 8
  %v2032 = load i32, ptr %slot369, align 8
  %op2033 = and i32 %v2032, 28
  store i32 %op2033, ptr %slot370, align 8
  %v2034 = load i32, ptr %slot370, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcslotrole513, label %bb_rcslotowner513
bb_rcslotrole513:
  %v2037 = load i64, ptr %slot44, align 8
  store i64 %v2037, ptr %slot371, align 8
  %v2038 = load i64, ptr %slot371, align 8
  %v2039 = load i64, ptr %slot368, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2038, i64 %v2039) nomerge, !dbg !140
  br label %bb_rcslotdone513
bb_rcslotowner513:
  %v2040 = load i64, ptr %slot44, align 8
  store i64 %v2040, ptr %slot372, align 8
  %v2041 = load i64, ptr %slot372, align 8
  %v2042 = load i64, ptr %slot368, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2041, i64 %v2042) nomerge, !dbg !140
  br label %bb_rcslotdone513
bb_rcslotdone513:
  br label %bb_rcprepared487
bb_rcprepared487:
  %v2043 = load i64, ptr %slot20, align 8
  store i64 %v2043, ptr %slot373, align 8
  %v2044 = load i64, ptr %slot373, align 8
  %v2045 = load i64, ptr %slot351, align 8
  %p2046 = inttoptr i64 %v2044 to ptr
  %p2047 = inttoptr i64 %v2045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2047, ptr %p2046, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2048 = load i64, ptr %slot13, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i32 0, ptr %p2049, align 4, !alias.scope !3, !noalias !4
  %v2050 = load i64, ptr %slot26, align 8
  store i64 %v2050, ptr %slot374, align 8
  %v2051 = load i64, ptr %slot348, align 8
  %p2053 = inttoptr i64 %v2051 to ptr
  %gep2054 = getelementptr i8, ptr %p2053, i64 40
  %op2052 = ptrtoint ptr %gep2054 to i64
  store i64 %op2052, ptr %slot375, align 8
  %v2055 = load i64, ptr %slot374, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %ld2057 = load i64, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2057, ptr %slot376, align 8
  %v2058 = load i64, ptr %slot376, align 8
  %v2059 = load i64, ptr %slot375, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  store i64 %v2058, ptr %p2060, align 8, !alias.scope !3, !noalias !4
  %v2061 = load i64, ptr %slot27, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %ld2063 = load i64, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2063, ptr %slot377, align 8
  %v2064 = load i64, ptr %slot348, align 8
  %p2066 = inttoptr i64 %v2064 to ptr
  %gep2067 = getelementptr i8, ptr %p2066, i64 48
  %op2065 = ptrtoint ptr %gep2067 to i64
  store i64 %op2065, ptr %slot378, align 8
  %v2068 = load i64, ptr %slot377, align 8
  %v2069 = load i64, ptr %slot378, align 8
  %p2070 = inttoptr i64 %v2068 to ptr
  %p2071 = inttoptr i64 %v2069 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2071, ptr %p2070, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot28, align 8
  store i64 %v2072, ptr %slot379, align 8
  %v2073 = load i64, ptr %slot348, align 8
  %p2075 = inttoptr i64 %v2073 to ptr
  %gep2076 = getelementptr i8, ptr %p2075, i64 64
  %op2074 = ptrtoint ptr %gep2076 to i64
  store i64 %op2074, ptr %slot380, align 8
  %v2077 = load i64, ptr %slot379, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i64, ptr %p2078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2079, ptr %slot381, align 8
  %v2080 = load i64, ptr %slot381, align 8
  %v2081 = load i64, ptr %slot380, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i64 %v2080, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot348, align 8
  %v2084 = load i64, ptr %slot25, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i64 %v2083, ptr %p2085, align 8, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot25, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %ld2088 = load i64, ptr %p2087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2088, ptr %slot382, align 8
  %v2089 = load i64, ptr %slot17, align 8
  store i64 %v2089, ptr %slot383, align 8
  %v2090 = load i64, ptr %slot382, align 8
  %v2091 = load i64, ptr %slot383, align 8
  %p2092 = inttoptr i64 %v2090 to ptr
  %p2093 = inttoptr i64 %v2091 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2093, ptr %p2092, i64 72, i1 false), !alias.scope !3, !noalias !4
  %v2094 = load i64, ptr %slot10, align 8
  %p2095 = inttoptr i64 %v2094 to ptr
  store i32 2, ptr %p2095, align 4, !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot9, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 1, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot383, align 8
  %v2099 = load i64, ptr %slot25, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i64 %v2098, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot38, align 8
  store i64 %v2101, ptr %slot384, align 8
  %v2102 = load i64, ptr %slot384, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  call void @llvm.memset.p0.i64(ptr %p2103, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !142
  %v2104 = load i64, ptr %slot384, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 7, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot15, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 1, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot25, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %ld2110 = load i64, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2110, ptr %slot385, align 8
  %v2111 = load i64, ptr %slot384, align 8
  %p2113 = inttoptr i64 %v2111 to ptr
  %gep2114 = getelementptr i8, ptr %p2113, i64 8
  %op2112 = ptrtoint ptr %gep2114 to i64
  store i64 %op2112, ptr %slot386, align 8
  %v2115 = load i64, ptr %slot45, align 8
  store i64 %v2115, ptr %slot387, align 8
  %v2116 = load i64, ptr %slot25, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2118, ptr %slot388, align 8
  %v2119 = load i64, ptr %slot20, align 8
  store i64 %v2119, ptr %slot389, align 8
  %v2120 = load i64, ptr %slot45, align 8
  store i64 %v2120, ptr %slot390, align 8
  %v2121 = load i64, ptr %slot44, align 8
  %v2122 = load i64, ptr %slot389, align 8
  %v2123 = load i64, ptr %slot388, align 8
  %v2124 = load i64, ptr %slot390, align 8
  %cv2125 = trunc i64 %v2124 to i32
  %call2126 = call i32 @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_take(i64 %v2121, i64 %v2122, i64 %v2123, i32 %cv2125) nomerge, !dbg !142
  store i32 %call2126, ptr %slot391, align 8
  %v2127 = load i32, ptr %slot391, align 8
  %cv2128 = zext i32 %v2127 to i64
  %cond2129 = icmp ne i64 %cv2128, 0
  br i1 %cond2129, label %bb_rcsuccess544, label %bb_rcfailure544
bb_rcfailure544:
  %v2130 = load i64, ptr %slot44, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  %call2132 = call i32 @myl_rc_take_failure(ptr %p2131) nomerge, !dbg !142
  store i32 %call2132, ptr %slot392, align 8
  %v2133 = load i64, ptr %slot1, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  %v2135 = load i32, ptr %slot392, align 8
  %call2136 = call i32 @myl_qbe_rc_status(ptr %p2134, i32 %v2135) nomerge, !dbg !142
  store i32 %call2136, ptr %slot393, align 8
  br label %bb_failure
bb_rcsuccess544:
  %v2137 = load i64, ptr %slot9, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  store i32 0, ptr %p2138, align 4, !alias.scope !3, !noalias !4
  %v2139 = load i64, ptr %slot14, align 8
  %p2140 = inttoptr i64 %v2139 to ptr
  store i32 2, ptr %p2140, align 4, !alias.scope !3, !noalias !4
  %v2141 = load i64, ptr %slot13, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  store i32 1, ptr %p2142, align 4, !alias.scope !3, !noalias !4
  %v2143 = load i64, ptr %slot20, align 8
  store i64 %v2143, ptr %slot394, align 8
  %v2144 = load i64, ptr %slot394, align 8
  %v2145 = load i64, ptr %slot386, align 8
  %p2146 = inttoptr i64 %v2144 to ptr
  %p2147 = inttoptr i64 %v2145 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2147, ptr %p2146, i64 72, i1 false), !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot13, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  store i32 0, ptr %p2149, align 4, !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot384, align 8
  %v2151 = load i64, ptr %slot25, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 %v2150, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot25, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i64, ptr %p2154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2155, ptr %slot395, align 8
  %v2156 = load i64, ptr %slot17, align 8
  store i64 %v2156, ptr %slot396, align 8
  %v2157 = load i64, ptr %slot395, align 8
  %v2158 = load i64, ptr %slot396, align 8
  %p2159 = inttoptr i64 %v2157 to ptr
  %p2160 = inttoptr i64 %v2158 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2160, ptr %p2159, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2161 = load i64, ptr %slot10, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  store i32 2, ptr %p2162, align 4, !alias.scope !3, !noalias !4
  %v2163 = load i64, ptr %slot9, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  store i32 1, ptr %p2164, align 4, !alias.scope !3, !noalias !4
  %v2165 = load i64, ptr %slot396, align 8
  %v2166 = load i64, ptr %slot25, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i64 %v2165, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot24, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i64, ptr %p2169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2170, ptr %slot397, align 8
  %v2171 = load i64, ptr %slot25, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i64, ptr %p2172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2173, ptr %slot398, align 8
  %v2174 = load i64, ptr %slot1, align 8
  %v2175 = load i64, ptr %slot397, align 8
  %v2176 = load i64, ptr %slot398, align 8
  %call2177 = call i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64 %v2174, i64 %v2175, i64 %v2176) nomerge, !dbg !144
  store i64 %call2177, ptr %slot399, align 8
  %v2178 = load i64, ptr %slot399, align 8
  %v2179 = load i64, ptr %slot24, align 8
  %p2180 = inttoptr i64 %v2179 to ptr
  store i64 %v2178, ptr %p2180, align 8, !alias.scope !3, !noalias !4
  %v2181 = load i64, ptr %slot7, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %ld2183 = load i32, ptr %p2182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2183, ptr %slot400, align 8
  %v2184 = load i32, ptr %slot400, align 8
  %cv2185 = zext i32 %v2184 to i64
  %cond2186 = icmp ne i64 %cv2185, 0
  br i1 %cond2186, label %bb_rcslotdrop561, label %bb_rcslotdone561
bb_rcslotdrop561:
  %v2187 = load i64, ptr %slot7, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i32 0, ptr %p2188, align 4, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot16, align 8
  store i64 %v2189, ptr %slot401, align 8
  %v2190 = load i64, ptr %slot8, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  %ld2192 = load i32, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2192, ptr %slot402, align 8
  %v2193 = load i32, ptr %slot402, align 8
  %op2194 = and i32 %v2193, 28
  store i32 %op2194, ptr %slot403, align 8
  %v2195 = load i32, ptr %slot403, align 8
  %cv2196 = zext i32 %v2195 to i64
  %cond2197 = icmp ne i64 %cv2196, 0
  br i1 %cond2197, label %bb_rcslotrole561, label %bb_rcslotowner561
bb_rcslotrole561:
  %v2198 = load i64, ptr %slot44, align 8
  store i64 %v2198, ptr %slot404, align 8
  %v2199 = load i64, ptr %slot404, align 8
  %v2200 = load i64, ptr %slot401, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2199, i64 %v2200) nomerge, !dbg !144
  br label %bb_rcslotdone561
bb_rcslotowner561:
  %v2201 = load i64, ptr %slot44, align 8
  store i64 %v2201, ptr %slot405, align 8
  %v2202 = load i64, ptr %slot405, align 8
  %v2203 = load i64, ptr %slot401, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2202, i64 %v2203) nomerge, !dbg !144
  br label %bb_rcslotdone561
bb_rcslotdone561:
  %v2204 = load i64, ptr %slot9, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %ld2206 = load i32, ptr %p2205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2206, ptr %slot406, align 8
  %v2207 = load i32, ptr %slot406, align 8
  %cv2208 = zext i32 %v2207 to i64
  %cond2209 = icmp ne i64 %cv2208, 0
  br i1 %cond2209, label %bb_rcslotdrop570, label %bb_rcslotdone570
bb_rcslotdrop570:
  %v2210 = load i64, ptr %slot9, align 8
  %p2211 = inttoptr i64 %v2210 to ptr
  store i32 0, ptr %p2211, align 4, !alias.scope !3, !noalias !4
  %v2212 = load i64, ptr %slot17, align 8
  store i64 %v2212, ptr %slot407, align 8
  %v2213 = load i64, ptr %slot10, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i32, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2215, ptr %slot408, align 8
  %v2216 = load i32, ptr %slot408, align 8
  %op2217 = and i32 %v2216, 28
  store i32 %op2217, ptr %slot409, align 8
  %v2218 = load i32, ptr %slot409, align 8
  %cv2219 = zext i32 %v2218 to i64
  %cond2220 = icmp ne i64 %cv2219, 0
  br i1 %cond2220, label %bb_rcslotrole570, label %bb_rcslotowner570
bb_rcslotrole570:
  %v2221 = load i64, ptr %slot44, align 8
  store i64 %v2221, ptr %slot410, align 8
  %v2222 = load i64, ptr %slot410, align 8
  %v2223 = load i64, ptr %slot407, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64 %v2222, i64 %v2223) nomerge, !dbg !144
  br label %bb_rcslotdone570
bb_rcslotowner570:
  %v2224 = load i64, ptr %slot44, align 8
  store i64 %v2224, ptr %slot411, align 8
  %v2225 = load i64, ptr %slot411, align 8
  %v2226 = load i64, ptr %slot407, align 8
  call void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64 %v2225, i64 %v2226) nomerge, !dbg !144
  br label %bb_rcslotdone570
bb_rcslotdone570:
  %v2227 = load i64, ptr %slot39, align 8
  store i64 %v2227, ptr %slot412, align 8
  %v2228 = load i64, ptr %slot412, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  store i64 0, ptr %p2229, align 8, !alias.scope !3, !noalias !4
  %v2230 = load i64, ptr %slot412, align 8
  %p2232 = inttoptr i64 %v2230 to ptr
  %gep2233 = getelementptr i8, ptr %p2232, i64 8
  %op2231 = ptrtoint ptr %gep2233 to i64
  store i64 %op2231, ptr %slot413, align 8
  %v2234 = load i64, ptr %slot413, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i64 0, ptr %p2235, align 8, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot412, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  store i32 0, ptr %p2237, align 4, !alias.scope !3, !noalias !4
  %v2238 = load i64, ptr %slot15, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  store i32 1, ptr %p2239, align 4, !alias.scope !3, !noalias !4
  %v2240 = load i64, ptr %slot24, align 8
  store i64 %v2240, ptr %slot414, align 8
  %v2241 = load i64, ptr %slot412, align 8
  %p2243 = inttoptr i64 %v2241 to ptr
  %gep2244 = getelementptr i8, ptr %p2243, i64 8
  %op2242 = ptrtoint ptr %gep2244 to i64
  store i64 %op2242, ptr %slot415, align 8
  %v2245 = load i64, ptr %slot45, align 8
  store i64 %v2245, ptr %slot416, align 8
  %v2246 = load i64, ptr %slot414, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %ld2248 = load i64, ptr %p2247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2248, ptr %slot417, align 8
  %v2249 = load i64, ptr %slot417, align 8
  %v2250 = load i64, ptr %slot415, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i64 %v2249, ptr %p2251, align 8, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot412, align 8
  %v2253 = load i64, ptr %slot24, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i64 %v2252, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot24, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %ld2257 = load i64, ptr %p2256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2257, ptr %slot418, align 8
  %v2258 = load i64, ptr %slot7, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i32, ptr %p2259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2260, ptr %slot419, align 8
  %v2261 = load i32, ptr %slot419, align 8
  %cv2262 = zext i32 %v2261 to i64
  %cond2263 = icmp ne i64 %cv2262, 0
  br i1 %cond2263, label %bb_rcslotdrop588, label %bb_rcslotdone588
bb_rcslotdrop588:
  %v2264 = load i64, ptr %slot7, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  store i32 0, ptr %p2265, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone588
bb_rcslotdone588:
  %v2266 = load i64, ptr %slot5, align 8
  %p2267 = inttoptr i64 %v2266 to ptr
  %ld2268 = load i32, ptr %p2267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2268, ptr %slot420, align 8
  %v2269 = load i32, ptr %slot420, align 8
  %cv2270 = zext i32 %v2269 to i64
  %cond2271 = icmp ne i64 %cv2270, 0
  br i1 %cond2271, label %bb_rcslotdrop591, label %bb_rcslotdone591
bb_rcslotdrop591:
  %v2272 = load i64, ptr %slot5, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  store i32 0, ptr %p2273, align 4, !alias.scope !3, !noalias !4
  %v2274 = load i64, ptr %slot22, align 8
  store i64 %v2274, ptr %slot421, align 8
  %v2275 = load i64, ptr %slot6, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %ld2277 = load i32, ptr %p2276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2277, ptr %slot422, align 8
  %v2278 = load i32, ptr %slot422, align 8
  %op2279 = and i32 %v2278, 28
  store i32 %op2279, ptr %slot423, align 8
  %v2280 = load i32, ptr %slot423, align 8
  %cv2281 = zext i32 %v2280 to i64
  %cond2282 = icmp ne i64 %cv2281, 0
  br i1 %cond2282, label %bb_rcslotrole591, label %bb_rcslotowner591
bb_rcslotrole591:
  %v2283 = load i64, ptr %slot44, align 8
  store i64 %v2283, ptr %slot424, align 8
  %v2284 = load i64, ptr %slot424, align 8
  %v2285 = load i64, ptr %slot421, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2284, i64 %v2285) nomerge, !dbg !146
  br label %bb_rcslotdone591
bb_rcslotowner591:
  %v2286 = load i64, ptr %slot44, align 8
  store i64 %v2286, ptr %slot425, align 8
  %v2287 = load i64, ptr %slot425, align 8
  %v2288 = load i64, ptr %slot421, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2287, i64 %v2288) nomerge, !dbg !146
  br label %bb_rcslotdone591
bb_rcslotdone591:
  %v2289 = load i64, ptr %slot418, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ret2291 = load { i64, i64 }, ptr %p2290, align 8
  ret { i64, i64 } %ret2291
bb_failure:
  %v2292 = load i64, ptr %slot4, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  call void @llvm.memset.p0.i64(ptr %p2293, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !146
  %v2294 = load i64, ptr %slot4, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %ret2296 = load { i64, i64 }, ptr %p2295, align 8
  ret { i64, i64 } %ret2296
bb_entry_failure:
  %v2297 = load i64, ptr %slot4, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  call void @llvm.memset.p0.i64(ptr %p2298, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !146
  %v2299 = load i64, ptr %slot4, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ret2301 = load { i64, i64 }, ptr %p2300, align 8
  ret { i64, i64 } %ret2301
}

@myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643_meta = external global i8, align 8
@myl_lit_1b09457477ce8976b6dd5c0bb92b9d43a791e77aa5ffb457e7d39663b0d18cde = external global i8, align 8
@myl_lit_4e48faae1476188ceb23066f96fc5c60c763d46a99320deefec8a56ef9779402 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4(i64, i64, i64)
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare i64 @myl_f_5031218b73ce5de434118fc14bb9f9a5cc671db14c89ab44d9f320a070694407(i64, i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_drop(i64, i64)
declare void @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)
declare i32 @myl_t_accf49002e11195a07b47a30866d56751991263d6d8094b977bcb8745a4d40ec_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643", linkageName: "myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17182997215679563986, i64 0, !"myl_f_36ffcb38a2ba310829bedb7710994bed734db0b040bf7f1334aaef9a5423e643"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!124 = !DILocation(line: 16, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!130 = !DILocation(line: 25, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!132 = !DILocation(line: 26, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!134 = !DILocation(line: 28, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!136 = !DILocation(line: 29, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!138 = !DILocation(line: 34, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!142 = !DILocation(line: 38, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!144 = !DILocation(line: 39, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!146 = !DILocation(line: 41, column: 0, scope: !147)
