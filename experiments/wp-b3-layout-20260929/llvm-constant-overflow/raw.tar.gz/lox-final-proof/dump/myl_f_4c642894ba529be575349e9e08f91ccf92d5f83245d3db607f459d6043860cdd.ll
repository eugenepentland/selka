target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v607 = load i64, ptr %slot1, align 8
  %op608 = add i64 %v607, 32
  store i64 %op608, ptr %slot3, align 8
  %mem609 = alloca i8, i64 8, align 8
  %ptr610 = ptrtoint ptr %mem609 to i64
  store i64 %ptr610, ptr %slot4, align 8
  %mem611 = alloca i8, i64 8, align 8
  %ptr612 = ptrtoint ptr %mem611 to i64
  store i64 %ptr612, ptr %slot5, align 8
  %mem613 = alloca i8, i64 8, align 8
  %ptr614 = ptrtoint ptr %mem613 to i64
  store i64 %ptr614, ptr %slot6, align 8
  %mem615 = alloca i8, i64 8, align 8
  %ptr616 = ptrtoint ptr %mem615 to i64
  store i64 %ptr616, ptr %slot7, align 8
  %mem617 = alloca i8, i64 8, align 8
  %ptr618 = ptrtoint ptr %mem617 to i64
  store i64 %ptr618, ptr %slot8, align 8
  %mem619 = alloca i8, i64 8, align 8
  %ptr620 = ptrtoint ptr %mem619 to i64
  store i64 %ptr620, ptr %slot9, align 8
  %mem621 = alloca i8, i64 8, align 8
  %ptr622 = ptrtoint ptr %mem621 to i64
  store i64 %ptr622, ptr %slot10, align 8
  %mem623 = alloca i8, i64 8, align 8
  %ptr624 = ptrtoint ptr %mem623 to i64
  store i64 %ptr624, ptr %slot11, align 8
  %mem625 = alloca i8, i64 8, align 8
  %ptr626 = ptrtoint ptr %mem625 to i64
  store i64 %ptr626, ptr %slot12, align 8
  %mem627 = alloca i8, i64 8, align 8
  %ptr628 = ptrtoint ptr %mem627 to i64
  store i64 %ptr628, ptr %slot13, align 8
  %mem629 = alloca i8, i64 40, align 8
  %ptr630 = ptrtoint ptr %mem629 to i64
  store i64 %ptr630, ptr %slot14, align 8
  %mem631 = alloca i8, i64 8, align 8
  %ptr632 = ptrtoint ptr %mem631 to i64
  store i64 %ptr632, ptr %slot15, align 8
  %mem633 = alloca i8, i64 8, align 8
  %ptr634 = ptrtoint ptr %mem633 to i64
  store i64 %ptr634, ptr %slot16, align 8
  %mem635 = alloca i8, i64 40, align 8
  %ptr636 = ptrtoint ptr %mem635 to i64
  store i64 %ptr636, ptr %slot17, align 8
  %mem637 = alloca i8, i64 8, align 8
  %ptr638 = ptrtoint ptr %mem637 to i64
  store i64 %ptr638, ptr %slot18, align 8
  %mem639 = alloca i8, i64 8, align 8
  %ptr640 = ptrtoint ptr %mem639 to i64
  store i64 %ptr640, ptr %slot19, align 8
  %mem641 = alloca i8, i64 40, align 8
  %ptr642 = ptrtoint ptr %mem641 to i64
  store i64 %ptr642, ptr %slot20, align 8
  %mem643 = alloca i8, i64 8, align 8
  %ptr644 = ptrtoint ptr %mem643 to i64
  store i64 %ptr644, ptr %slot21, align 8
  %mem645 = alloca i8, i64 8, align 8
  %ptr646 = ptrtoint ptr %mem645 to i64
  store i64 %ptr646, ptr %slot22, align 8
  %mem647 = alloca i8, i64 8, align 8
  %ptr648 = ptrtoint ptr %mem647 to i64
  store i64 %ptr648, ptr %slot23, align 8
  %mem649 = alloca i8, i64 40, align 8
  %ptr650 = ptrtoint ptr %mem649 to i64
  store i64 %ptr650, ptr %slot24, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem651 = alloca i8, i64 8, align 8
  %ptr652 = ptrtoint ptr %mem651 to i64
  store i64 %ptr652, ptr %slot25, align 8
  %v653 = load i64, ptr %slot1, align 8
  %op654 = add i64 %v653, 64
  store i64 %op654, ptr %slot26, align 8
  %v655 = load i64, ptr %slot26, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !4, !noalias !3
  store i64 %ld657, ptr %slot27, align 8
  %stack658 = call ptr @llvm.stacksave()
  %stackaddr659 = ptrtoint ptr %stack658 to i64
  %v660 = load i64, ptr %slot27, align 8
  %cmp661 = icmp ult i64 %stackaddr659, %v660
  %cv662 = zext i1 %cmp661 to i64
  store i64 %cv662, ptr %slot28, align 8
  %v663 = load i64, ptr %slot28, align 8
  %cond664 = icmp ne i64 %v663, 0
  br i1 %cond664, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v665 = load i64, ptr %slot1, align 8
  %p666 = inttoptr i64 %v665 to ptr
  call void @myl_qbe_fail_frame(ptr %p666) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v667 = load i64, ptr %slot21, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 0, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot2, align 8
  %v670 = load i64, ptr %slot18, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i64 %v669, ptr %p671, align 8, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot1, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %call674 = call ptr @myl_qbe_heap(ptr %p673) nomerge, !dbg !112
  %calladdr675 = ptrtoint ptr %call674 to i64
  store i64 %calladdr675, ptr %slot29, align 8
  %v676 = load i64, ptr %slot1, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %call678 = call i64 @myl_qbe_region_mark(ptr %p677) nomerge, !dbg !112
  store i64 %call678, ptr %slot30, align 8
  %v679 = load i64, ptr %slot4, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i32 0, ptr %p680, align 4, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot5, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i32 0, ptr %p682, align 4, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot6, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 0, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot7, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i32 0, ptr %p686, align 4, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot8, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i32 0, ptr %p688, align 4, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot9, align 8
  %p690 = inttoptr i64 %v689 to ptr
  store i32 0, ptr %p690, align 4, !alias.scope !3, !noalias !4
  %v691 = load i64, ptr %slot10, align 8
  %p692 = inttoptr i64 %v691 to ptr
  store i32 0, ptr %p692, align 4, !alias.scope !3, !noalias !4
  %v693 = load i64, ptr %slot11, align 8
  %p694 = inttoptr i64 %v693 to ptr
  store i32 0, ptr %p694, align 4, !alias.scope !3, !noalias !4
  %v695 = load i64, ptr %slot12, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i32 0, ptr %p696, align 4, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot13, align 8
  %p698 = inttoptr i64 %v697 to ptr
  store i32 0, ptr %p698, align 4, !alias.scope !3, !noalias !4
  %v699 = load i64, ptr %slot5, align 8
  %p700 = inttoptr i64 %v699 to ptr
  store i32 2, ptr %p700, align 4, !alias.scope !3, !noalias !4
  %v701 = load i64, ptr %slot7, align 8
  %p702 = inttoptr i64 %v701 to ptr
  store i32 2, ptr %p702, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v703 = load i64, ptr %slot18, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i64, ptr %p704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld705, ptr %slot31, align 8
  %v706 = load i64, ptr %slot31, align 8
  %v707 = load i64, ptr %slot22, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i64 %v706, ptr %p708, align 8, !alias.scope !3, !noalias !4
  %v709 = load i64, ptr %slot22, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %ld711 = load i64, ptr %p710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld711, ptr %slot32, align 8
  %v712 = load i64, ptr %slot32, align 8
  %op713 = add i64 %v712, 32
  store i64 %op713, ptr %slot33, align 8
  %v714 = load i64, ptr %slot33, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i8, ptr %p715, align 1, !alias.scope !4, !noalias !3
  %ext717 = zext i8 %ld716 to i64
  store i64 %ext717, ptr %slot34, align 8
  %v718 = load i64, ptr %slot34, align 8
  %v719 = load i64, ptr %slot22, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i64 %v718, ptr %p720, align 8, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot8, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i32, ptr %p722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld723, ptr %slot35, align 8
  %v724 = load i32, ptr %slot35, align 8
  %cv725 = zext i32 %v724 to i64
  %cond726 = icmp ne i64 %cv725, 0
  br i1 %cond726, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v727 = load i64, ptr %slot8, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 0, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot14, align 8
  store i64 %v729, ptr %slot36, align 8
  %v730 = load i64, ptr %slot9, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i32, ptr %p731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld732, ptr %slot37, align 8
  %v733 = load i32, ptr %slot37, align 8
  %op734 = and i32 %v733, 28
  store i32 %op734, ptr %slot38, align 8
  %v735 = load i32, ptr %slot38, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v738 = load i64, ptr %slot29, align 8
  store i64 %v738, ptr %slot39, align 8
  %v739 = load i64, ptr %slot39, align 8
  %v740 = load i64, ptr %slot36, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v739, i64 %v740) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v741 = load i64, ptr %slot29, align 8
  store i64 %v741, ptr %slot40, align 8
  %v742 = load i64, ptr %slot40, align 8
  %v743 = load i64, ptr %slot36, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v742, i64 %v743) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v744 = load i64, ptr %slot22, align 8
  %p745 = inttoptr i64 %v744 to ptr
  %ld746 = load i64, ptr %p745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld746, ptr %slot41, align 8
  %v747 = load i64, ptr %slot41, align 8
  %cond748 = icmp ne i64 %v747, 0
  br i1 %cond748, label %bb_next24, label %bb_i5
bb_next24:
  %v749 = load i64, ptr %slot22, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i64 1, ptr %p750, align 8, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_i5:
  %v751 = load i64, ptr %slot18, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i64, ptr %p752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld753, ptr %slot42, align 8
  %v754 = load i64, ptr %slot42, align 8
  %v755 = load i64, ptr %slot22, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i64 %v754, ptr %p756, align 8, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot22, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %ld759 = load i64, ptr %p758, align 8, !alias.scope !3, !noalias !4
  store i64 %ld759, ptr %slot43, align 8
  %v760 = load i64, ptr %slot43, align 8
  %op761 = add i64 %v760, 0
  store i64 %op761, ptr %slot44, align 8
  %v762 = load i64, ptr %slot44, align 8
  %p763 = inttoptr i64 %v762 to ptr
  %ld764 = load i64, ptr %p763, align 8, !alias.scope !4, !noalias !3
  store i64 %ld764, ptr %slot45, align 8
  %v765 = load i64, ptr %slot45, align 8
  %v766 = load i64, ptr %slot22, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i64 %v765, ptr %p767, align 8, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot8, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i32, ptr %p769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld770, ptr %slot46, align 8
  %v771 = load i32, ptr %slot46, align 8
  %cv772 = zext i32 %v771 to i64
  %cond773 = icmp ne i64 %cv772, 0
  br i1 %cond773, label %bb_rcslotdrop30, label %bb_rcslotdone30
bb_rcslotdrop30:
  %v774 = load i64, ptr %slot8, align 8
  %p775 = inttoptr i64 %v774 to ptr
  store i32 0, ptr %p775, align 4, !alias.scope !3, !noalias !4
  %v776 = load i64, ptr %slot14, align 8
  store i64 %v776, ptr %slot47, align 8
  %v777 = load i64, ptr %slot9, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i32, ptr %p778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld779, ptr %slot48, align 8
  %v780 = load i32, ptr %slot48, align 8
  %op781 = and i32 %v780, 28
  store i32 %op781, ptr %slot49, align 8
  %v782 = load i32, ptr %slot49, align 8
  %cv783 = zext i32 %v782 to i64
  %cond784 = icmp ne i64 %cv783, 0
  br i1 %cond784, label %bb_rcslotrole30, label %bb_rcslotowner30
bb_rcslotrole30:
  %v785 = load i64, ptr %slot29, align 8
  store i64 %v785, ptr %slot50, align 8
  %v786 = load i64, ptr %slot50, align 8
  %v787 = load i64, ptr %slot47, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v786, i64 %v787) nomerge, !dbg !116
  br label %bb_rcslotdone30
bb_rcslotowner30:
  %v788 = load i64, ptr %slot29, align 8
  store i64 %v788, ptr %slot51, align 8
  %v789 = load i64, ptr %slot51, align 8
  %v790 = load i64, ptr %slot47, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v789, i64 %v790) nomerge, !dbg !116
  br label %bb_rcslotdone30
bb_rcslotdone30:
  %v791 = load i64, ptr %slot22, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %ld793 = load i64, ptr %p792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld793, ptr %slot52, align 8
  %v794 = load i64, ptr %slot52, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !6, !noalias !7
  store i64 %ld796, ptr %slot53, align 8
  %v797 = load i64, ptr %slot53, align 8
  %v798 = load i64, ptr %slot22, align 8
  %p799 = inttoptr i64 %v798 to ptr
  store i64 %v797, ptr %p799, align 8, !alias.scope !3, !noalias !4
  %v800 = load i64, ptr %slot8, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i32, ptr %p801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld802, ptr %slot54, align 8
  %v803 = load i32, ptr %slot54, align 8
  %cv804 = zext i32 %v803 to i64
  %cond805 = icmp ne i64 %cv804, 0
  br i1 %cond805, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v806 = load i64, ptr %slot8, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 0, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot14, align 8
  store i64 %v808, ptr %slot55, align 8
  %v809 = load i64, ptr %slot9, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i32, ptr %p810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld811, ptr %slot56, align 8
  %v812 = load i32, ptr %slot56, align 8
  %op813 = and i32 %v812, 28
  store i32 %op813, ptr %slot57, align 8
  %v814 = load i32, ptr %slot57, align 8
  %cv815 = zext i32 %v814 to i64
  %cond816 = icmp ne i64 %cv815, 0
  br i1 %cond816, label %bb_rcslotrole41, label %bb_rcslotowner41
bb_rcslotrole41:
  %v817 = load i64, ptr %slot29, align 8
  store i64 %v817, ptr %slot58, align 8
  %v818 = load i64, ptr %slot55, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot59, align 8
  %v821 = load i64, ptr %slot59, align 8
  %cmp822 = icmp ne i64 %v821, 0
  %cv823 = zext i1 %cmp822 to i32
  store i32 %cv823, ptr %slot60, align 8
  %v824 = load i32, ptr %slot60, align 8
  %cv825 = zext i32 %v824 to i64
  %cond826 = icmp ne i64 %cv825, 0
  br i1 %cond826, label %bb_rcgnn57, label %bb_rcgdone57
bb_rcgnn57:
  %v827 = load i64, ptr %slot59, align 8
  %op828 = sub i64 %v827, 16
  store i64 %op828, ptr %slot61, align 8
  %v829 = load i64, ptr %slot59, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %rgep831 = getelementptr i8, ptr %p830, i64 -16
  %ld832 = load i64, ptr %rgep831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld832, ptr %slot62, align 8
  %v833 = load i64, ptr %slot62, align 8
  %op834 = and i64 %v833, 4611686018427387906
  store i64 %op834, ptr %slot63, align 8
  %v835 = load i64, ptr %slot63, align 8
  %cmp836 = icmp ne i64 %v835, 0
  %cv837 = zext i1 %cmp836 to i32
  store i32 %cv837, ptr %slot64, align 8
  %v838 = load i32, ptr %slot64, align 8
  %cv839 = zext i32 %v838 to i64
  %cond840 = icmp ne i64 %cv839, 0
  br i1 %cond840, label %bb_rcgclear57, label %bb_rcgcounted57
bb_rcgcounted57:
  %v841 = load i64, ptr %slot59, align 8
  %op842 = sub i64 %v841, 24
  store i64 %op842, ptr %slot65, align 8
  %v843 = load i64, ptr %slot59, align 8
  %p844 = inttoptr i64 %v843 to ptr
  %rgep845 = getelementptr i8, ptr %p844, i64 -24
  %ld846 = load i64, ptr %rgep845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld846, ptr %slot66, align 8
  %v847 = load i64, ptr %slot66, align 8
  %op848 = sub i64 %v847, 1
  store i64 %op848, ptr %slot67, align 8
  %v849 = load i64, ptr %slot67, align 8
  %cmp850 = icmp eq i64 %v849, 0
  %cv851 = zext i1 %cmp850 to i32
  store i32 %cv851, ptr %slot68, align 8
  %v852 = load i32, ptr %slot68, align 8
  %cv853 = zext i32 %v852 to i64
  %cond854 = icmp ne i64 %cv853, 0
  br i1 %cond854, label %bb_rcglast57, label %bb_rcgdec57
bb_rcglast57:
  %v855 = load i64, ptr %slot59, align 8
  %op856 = sub i64 %v855, 32
  store i64 %op856, ptr %slot69, align 8
  %v857 = load i64, ptr %slot59, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %rgep859 = getelementptr i8, ptr %p858, i64 -32
  %ld860 = load i64, ptr %rgep859, align 8, !alias.scope !9, !noalias !10
  store i64 %ld860, ptr %slot70, align 8
  %v861 = load i64, ptr %slot70, align 8
  %cmp862 = icmp ne i64 %v861, 0
  %cv863 = zext i1 %cmp862 to i32
  store i32 %cv863, ptr %slot71, align 8
  %v864 = load i32, ptr %slot71, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcgdec57, label %bb_rcgslow57
bb_rcgslow57:
  %v867 = load i64, ptr %slot58, align 8
  %v868 = load i64, ptr %slot55, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v867, i64 %v868) nomerge, !dbg !118
  br label %bb_rcgdone57
bb_rcgdec57:
  %v869 = load i64, ptr %slot67, align 8
  %v870 = load i64, ptr %slot59, align 8
  %p871 = inttoptr i64 %v870 to ptr
  %rgep872 = getelementptr i8, ptr %p871, i64 -24
  store i64 %v869, ptr %rgep872, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear57
bb_rcgclear57:
  %v873 = load i64, ptr %slot55, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i64 0, ptr %p874, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone57
bb_rcgdone57:
  br label %bb_rcslotdone41
bb_rcslotowner41:
  %v875 = load i64, ptr %slot29, align 8
  store i64 %v875, ptr %slot72, align 8
  %v876 = load i64, ptr %slot55, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld878, ptr %slot73, align 8
  %v879 = load i64, ptr %slot73, align 8
  %cmp880 = icmp ne i64 %v879, 0
  %cv881 = zext i1 %cmp880 to i32
  store i32 %cv881, ptr %slot74, align 8
  %v882 = load i32, ptr %slot74, align 8
  %cv883 = zext i32 %v882 to i64
  %cond884 = icmp ne i64 %cv883, 0
  br i1 %cond884, label %bb_rcgnn72, label %bb_rcgdone72
bb_rcgnn72:
  %v885 = load i64, ptr %slot73, align 8
  %op886 = sub i64 %v885, 16
  store i64 %op886, ptr %slot75, align 8
  %v887 = load i64, ptr %slot73, align 8
  %p888 = inttoptr i64 %v887 to ptr
  %rgep889 = getelementptr i8, ptr %p888, i64 -16
  %ld890 = load i64, ptr %rgep889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld890, ptr %slot76, align 8
  %v891 = load i64, ptr %slot76, align 8
  %op892 = and i64 %v891, 4611686018427387906
  store i64 %op892, ptr %slot77, align 8
  %v893 = load i64, ptr %slot77, align 8
  %cmp894 = icmp ne i64 %v893, 0
  %cv895 = zext i1 %cmp894 to i32
  store i32 %cv895, ptr %slot78, align 8
  %v896 = load i32, ptr %slot78, align 8
  %cv897 = zext i32 %v896 to i64
  %cond898 = icmp ne i64 %cv897, 0
  br i1 %cond898, label %bb_rcgclear72, label %bb_rcgcounted72
bb_rcgcounted72:
  %v899 = load i64, ptr %slot73, align 8
  %op900 = sub i64 %v899, 32
  store i64 %op900, ptr %slot79, align 8
  %v901 = load i64, ptr %slot73, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %rgep903 = getelementptr i8, ptr %p902, i64 -32
  %ld904 = load i64, ptr %rgep903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld904, ptr %slot80, align 8
  %v905 = load i64, ptr %slot80, align 8
  %op906 = sub i64 %v905, 1
  store i64 %op906, ptr %slot81, align 8
  %v907 = load i64, ptr %slot81, align 8
  %cmp908 = icmp eq i64 %v907, 0
  %cv909 = zext i1 %cmp908 to i32
  store i32 %cv909, ptr %slot82, align 8
  %v910 = load i32, ptr %slot82, align 8
  %cv911 = zext i32 %v910 to i64
  %cond912 = icmp ne i64 %cv911, 0
  br i1 %cond912, label %bb_rcglast72, label %bb_rcgdec72
bb_rcglast72:
  %v913 = load i64, ptr %slot73, align 8
  %op914 = sub i64 %v913, 24
  store i64 %op914, ptr %slot83, align 8
  %v915 = load i64, ptr %slot73, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %rgep917 = getelementptr i8, ptr %p916, i64 -24
  %ld918 = load i64, ptr %rgep917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld918, ptr %slot84, align 8
  %v919 = load i64, ptr %slot84, align 8
  %cmp920 = icmp ne i64 %v919, 0
  %cv921 = zext i1 %cmp920 to i32
  store i32 %cv921, ptr %slot85, align 8
  %v922 = load i32, ptr %slot85, align 8
  %cv923 = zext i32 %v922 to i64
  %cond924 = icmp ne i64 %cv923, 0
  br i1 %cond924, label %bb_rcgdec72, label %bb_rcgslow72
bb_rcgslow72:
  %v925 = load i64, ptr %slot72, align 8
  %v926 = load i64, ptr %slot55, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v925, i64 %v926) nomerge, !dbg !118
  br label %bb_rcgdone72
bb_rcgdec72:
  %v927 = load i64, ptr %slot81, align 8
  %v928 = load i64, ptr %slot73, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %rgep930 = getelementptr i8, ptr %p929, i64 -32
  store i64 %v927, ptr %rgep930, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear72
bb_rcgclear72:
  %v931 = load i64, ptr %slot55, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i64 0, ptr %p932, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone72
bb_rcgdone72:
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v933 = load i64, ptr %slot23, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 0, ptr %p934, align 8, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot23, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i64, ptr %p936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld937, ptr %slot86, align 8
  %v938 = load i64, ptr %slot22, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot87, align 8
  %v941 = load i64, ptr %slot87, align 8
  %v942 = load i64, ptr %slot86, align 8
  %cmp943 = icmp eq i64 %v941, %v942
  %cv944 = zext i1 %cmp943 to i64
  store i64 %cv944, ptr %slot88, align 8
  %v945 = load i64, ptr %slot88, align 8
  %v946 = load i64, ptr %slot22, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i64 %v945, ptr %p947, align 8, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_i10:
  %v948 = load i64, ptr %slot22, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i64, ptr %p949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld950, ptr %slot89, align 8
  %v951 = load i64, ptr %slot89, align 8
  %cond952 = icmp ne i64 %v951, 0
  br i1 %cond952, label %bb_next80, label %bb_i13
bb_next80:
  %v953 = load i64, ptr %slot22, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i64 0, ptr %p954, align 8, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot22, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %ld957 = load i64, ptr %p956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld957, ptr %slot90, align 8
  %v958 = load i64, ptr %slot8, align 8
  %p959 = inttoptr i64 %v958 to ptr
  %ld960 = load i32, ptr %p959, align 4, !alias.scope !3, !noalias !4
  store i32 %ld960, ptr %slot91, align 8
  %v961 = load i32, ptr %slot91, align 8
  %cv962 = zext i32 %v961 to i64
  %cond963 = icmp ne i64 %cv962, 0
  br i1 %cond963, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v964 = load i64, ptr %slot8, align 8
  %p965 = inttoptr i64 %v964 to ptr
  store i32 0, ptr %p965, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone83
bb_rcslotdone83:
  %v966 = load i64, ptr %slot6, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %ld968 = load i32, ptr %p967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld968, ptr %slot92, align 8
  %v969 = load i32, ptr %slot92, align 8
  %cv970 = zext i32 %v969 to i64
  %cond971 = icmp ne i64 %cv970, 0
  br i1 %cond971, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v972 = load i64, ptr %slot6, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i32 0, ptr %p973, align 4, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot21, align 8
  store i64 %v974, ptr %slot93, align 8
  %v975 = load i64, ptr %slot7, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i32, ptr %p976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld977, ptr %slot94, align 8
  %v978 = load i32, ptr %slot94, align 8
  %op979 = and i32 %v978, 28
  store i32 %op979, ptr %slot95, align 8
  %v980 = load i32, ptr %slot95, align 8
  %cv981 = zext i32 %v980 to i64
  %cond982 = icmp ne i64 %cv981, 0
  br i1 %cond982, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v983 = load i64, ptr %slot29, align 8
  store i64 %v983, ptr %slot96, align 8
  %v984 = load i64, ptr %slot93, align 8
  %p985 = inttoptr i64 %v984 to ptr
  %ld986 = load i64, ptr %p985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld986, ptr %slot97, align 8
  %v987 = load i64, ptr %slot97, align 8
  %cmp988 = icmp ne i64 %v987, 0
  %cv989 = zext i1 %cmp988 to i32
  store i32 %cv989, ptr %slot98, align 8
  %v990 = load i32, ptr %slot98, align 8
  %cv991 = zext i32 %v990 to i64
  %cond992 = icmp ne i64 %cv991, 0
  br i1 %cond992, label %bb_rcgnn102, label %bb_rcgdone102
bb_rcgnn102:
  %v993 = load i64, ptr %slot97, align 8
  %op994 = sub i64 %v993, 16
  store i64 %op994, ptr %slot99, align 8
  %v995 = load i64, ptr %slot97, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %rgep997 = getelementptr i8, ptr %p996, i64 -16
  %ld998 = load i64, ptr %rgep997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld998, ptr %slot100, align 8
  %v999 = load i64, ptr %slot100, align 8
  %op1000 = and i64 %v999, 4611686018427387906
  store i64 %op1000, ptr %slot101, align 8
  %v1001 = load i64, ptr %slot101, align 8
  %cmp1002 = icmp ne i64 %v1001, 0
  %cv1003 = zext i1 %cmp1002 to i32
  store i32 %cv1003, ptr %slot102, align 8
  %v1004 = load i32, ptr %slot102, align 8
  %cv1005 = zext i32 %v1004 to i64
  %cond1006 = icmp ne i64 %cv1005, 0
  br i1 %cond1006, label %bb_rcgclear102, label %bb_rcgcounted102
bb_rcgcounted102:
  %v1007 = load i64, ptr %slot97, align 8
  %op1008 = sub i64 %v1007, 24
  store i64 %op1008, ptr %slot103, align 8
  %v1009 = load i64, ptr %slot97, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %rgep1011 = getelementptr i8, ptr %p1010, i64 -24
  %ld1012 = load i64, ptr %rgep1011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1012, ptr %slot104, align 8
  %v1013 = load i64, ptr %slot104, align 8
  %op1014 = sub i64 %v1013, 1
  store i64 %op1014, ptr %slot105, align 8
  %v1015 = load i64, ptr %slot105, align 8
  %cmp1016 = icmp eq i64 %v1015, 0
  %cv1017 = zext i1 %cmp1016 to i32
  store i32 %cv1017, ptr %slot106, align 8
  %v1018 = load i32, ptr %slot106, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcglast102, label %bb_rcgdec102
bb_rcglast102:
  %v1021 = load i64, ptr %slot97, align 8
  %op1022 = sub i64 %v1021, 32
  store i64 %op1022, ptr %slot107, align 8
  %v1023 = load i64, ptr %slot97, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %rgep1025 = getelementptr i8, ptr %p1024, i64 -32
  %ld1026 = load i64, ptr %rgep1025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1026, ptr %slot108, align 8
  %v1027 = load i64, ptr %slot108, align 8
  %cmp1028 = icmp ne i64 %v1027, 0
  %cv1029 = zext i1 %cmp1028 to i32
  store i32 %cv1029, ptr %slot109, align 8
  %v1030 = load i32, ptr %slot109, align 8
  %cv1031 = zext i32 %v1030 to i64
  %cond1032 = icmp ne i64 %cv1031, 0
  br i1 %cond1032, label %bb_rcgdec102, label %bb_rcgslow102
bb_rcgslow102:
  %v1033 = load i64, ptr %slot96, align 8
  %v1034 = load i64, ptr %slot93, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1033, i64 %v1034) nomerge, !dbg !120
  br label %bb_rcgdone102
bb_rcgdec102:
  %v1035 = load i64, ptr %slot105, align 8
  %v1036 = load i64, ptr %slot97, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %rgep1038 = getelementptr i8, ptr %p1037, i64 -24
  store i64 %v1035, ptr %rgep1038, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear102
bb_rcgclear102:
  %v1039 = load i64, ptr %slot93, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i64 0, ptr %p1040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone102
bb_rcgdone102:
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1041 = load i64, ptr %slot29, align 8
  store i64 %v1041, ptr %slot110, align 8
  %v1042 = load i64, ptr %slot93, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  %ld1044 = load i64, ptr %p1043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1044, ptr %slot111, align 8
  %v1045 = load i64, ptr %slot111, align 8
  %cmp1046 = icmp ne i64 %v1045, 0
  %cv1047 = zext i1 %cmp1046 to i32
  store i32 %cv1047, ptr %slot112, align 8
  %v1048 = load i32, ptr %slot112, align 8
  %cv1049 = zext i32 %v1048 to i64
  %cond1050 = icmp ne i64 %cv1049, 0
  br i1 %cond1050, label %bb_rcgnn117, label %bb_rcgdone117
bb_rcgnn117:
  %v1051 = load i64, ptr %slot111, align 8
  %op1052 = sub i64 %v1051, 16
  store i64 %op1052, ptr %slot113, align 8
  %v1053 = load i64, ptr %slot111, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  %rgep1055 = getelementptr i8, ptr %p1054, i64 -16
  %ld1056 = load i64, ptr %rgep1055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1056, ptr %slot114, align 8
  %v1057 = load i64, ptr %slot114, align 8
  %op1058 = and i64 %v1057, 4611686018427387906
  store i64 %op1058, ptr %slot115, align 8
  %v1059 = load i64, ptr %slot115, align 8
  %cmp1060 = icmp ne i64 %v1059, 0
  %cv1061 = zext i1 %cmp1060 to i32
  store i32 %cv1061, ptr %slot116, align 8
  %v1062 = load i32, ptr %slot116, align 8
  %cv1063 = zext i32 %v1062 to i64
  %cond1064 = icmp ne i64 %cv1063, 0
  br i1 %cond1064, label %bb_rcgclear117, label %bb_rcgcounted117
bb_rcgcounted117:
  %v1065 = load i64, ptr %slot111, align 8
  %op1066 = sub i64 %v1065, 32
  store i64 %op1066, ptr %slot117, align 8
  %v1067 = load i64, ptr %slot111, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %rgep1069 = getelementptr i8, ptr %p1068, i64 -32
  %ld1070 = load i64, ptr %rgep1069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1070, ptr %slot118, align 8
  %v1071 = load i64, ptr %slot118, align 8
  %op1072 = sub i64 %v1071, 1
  store i64 %op1072, ptr %slot119, align 8
  %v1073 = load i64, ptr %slot119, align 8
  %cmp1074 = icmp eq i64 %v1073, 0
  %cv1075 = zext i1 %cmp1074 to i32
  store i32 %cv1075, ptr %slot120, align 8
  %v1076 = load i32, ptr %slot120, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcglast117, label %bb_rcgdec117
bb_rcglast117:
  %v1079 = load i64, ptr %slot111, align 8
  %op1080 = sub i64 %v1079, 24
  store i64 %op1080, ptr %slot121, align 8
  %v1081 = load i64, ptr %slot111, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %rgep1083 = getelementptr i8, ptr %p1082, i64 -24
  %ld1084 = load i64, ptr %rgep1083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1084, ptr %slot122, align 8
  %v1085 = load i64, ptr %slot122, align 8
  %cmp1086 = icmp ne i64 %v1085, 0
  %cv1087 = zext i1 %cmp1086 to i32
  store i32 %cv1087, ptr %slot123, align 8
  %v1088 = load i32, ptr %slot123, align 8
  %cv1089 = zext i32 %v1088 to i64
  %cond1090 = icmp ne i64 %cv1089, 0
  br i1 %cond1090, label %bb_rcgdec117, label %bb_rcgslow117
bb_rcgslow117:
  %v1091 = load i64, ptr %slot110, align 8
  %v1092 = load i64, ptr %slot93, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1091, i64 %v1092) nomerge, !dbg !120
  br label %bb_rcgdone117
bb_rcgdec117:
  %v1093 = load i64, ptr %slot119, align 8
  %v1094 = load i64, ptr %slot111, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %rgep1096 = getelementptr i8, ptr %p1095, i64 -32
  store i64 %v1093, ptr %rgep1096, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear117
bb_rcgclear117:
  %v1097 = load i64, ptr %slot93, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i64 0, ptr %p1098, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone117
bb_rcgdone117:
  br label %bb_rcslotdone86
bb_rcslotdone86:
  %v1099 = load i64, ptr %slot4, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i32, ptr %p1100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1101, ptr %slot124, align 8
  %v1102 = load i32, ptr %slot124, align 8
  %cv1103 = zext i32 %v1102 to i64
  %cond1104 = icmp ne i64 %cv1103, 0
  br i1 %cond1104, label %bb_rcslotdrop123, label %bb_rcslotdone123
bb_rcslotdrop123:
  %v1105 = load i64, ptr %slot4, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i32 0, ptr %p1106, align 4, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot20, align 8
  store i64 %v1107, ptr %slot125, align 8
  %v1108 = load i64, ptr %slot5, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  %ld1110 = load i32, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1110, ptr %slot126, align 8
  %v1111 = load i32, ptr %slot126, align 8
  %op1112 = and i32 %v1111, 28
  store i32 %op1112, ptr %slot127, align 8
  %v1113 = load i32, ptr %slot127, align 8
  %cv1114 = zext i32 %v1113 to i64
  %cond1115 = icmp ne i64 %cv1114, 0
  br i1 %cond1115, label %bb_rcslotrole123, label %bb_rcslotowner123
bb_rcslotrole123:
  %v1116 = load i64, ptr %slot29, align 8
  store i64 %v1116, ptr %slot128, align 8
  %v1117 = load i64, ptr %slot128, align 8
  %v1118 = load i64, ptr %slot125, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1117, i64 %v1118) nomerge, !dbg !120
  br label %bb_rcslotdone123
bb_rcslotowner123:
  %v1119 = load i64, ptr %slot29, align 8
  store i64 %v1119, ptr %slot129, align 8
  %v1120 = load i64, ptr %slot129, align 8
  %v1121 = load i64, ptr %slot125, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1120, i64 %v1121) nomerge, !dbg !120
  br label %bb_rcslotdone123
bb_rcslotdone123:
  %v1122 = load i64, ptr %slot90, align 8
  ret i64 %v1122
bb_i13:
  %v1123 = load i64, ptr %slot18, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %ld1125 = load i64, ptr %p1124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1125, ptr %slot130, align 8
  %v1126 = load i64, ptr %slot130, align 8
  %v1127 = load i64, ptr %slot22, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i64 %v1126, ptr %p1128, align 8, !alias.scope !3, !noalias !4
  %v1129 = load i64, ptr %slot22, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %ld1131 = load i64, ptr %p1130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1131, ptr %slot131, align 8
  %v1132 = load i64, ptr %slot131, align 8
  %op1133 = add i64 %v1132, 16
  store i64 %op1133, ptr %slot132, align 8
  %v1134 = load i64, ptr %slot132, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %ld1136 = load i64, ptr %p1135, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1136, ptr %slot133, align 8
  %v1137 = load i64, ptr %slot133, align 8
  %v1138 = load i64, ptr %slot22, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 %v1137, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot8, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot134, align 8
  %v1143 = load i32, ptr %slot134, align 8
  %cv1144 = zext i32 %v1143 to i64
  %cond1145 = icmp ne i64 %cv1144, 0
  br i1 %cond1145, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v1146 = load i64, ptr %slot8, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i32 0, ptr %p1147, align 4, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot14, align 8
  store i64 %v1148, ptr %slot135, align 8
  %v1149 = load i64, ptr %slot9, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i32, ptr %p1150, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1151, ptr %slot136, align 8
  %v1152 = load i32, ptr %slot136, align 8
  %op1153 = and i32 %v1152, 28
  store i32 %op1153, ptr %slot137, align 8
  %v1154 = load i32, ptr %slot137, align 8
  %cv1155 = zext i32 %v1154 to i64
  %cond1156 = icmp ne i64 %cv1155, 0
  br i1 %cond1156, label %bb_rcslotrole145, label %bb_rcslotowner145
bb_rcslotrole145:
  %v1157 = load i64, ptr %slot29, align 8
  store i64 %v1157, ptr %slot138, align 8
  %v1158 = load i64, ptr %slot138, align 8
  %v1159 = load i64, ptr %slot135, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1158, i64 %v1159) nomerge, !dbg !122
  br label %bb_rcslotdone145
bb_rcslotowner145:
  %v1160 = load i64, ptr %slot29, align 8
  store i64 %v1160, ptr %slot139, align 8
  %v1161 = load i64, ptr %slot139, align 8
  %v1162 = load i64, ptr %slot135, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1161, i64 %v1162) nomerge, !dbg !122
  br label %bb_rcslotdone145
bb_rcslotdone145:
  %v1163 = load i64, ptr %slot22, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1165, ptr %slot140, align 8
  %v1166 = load i64, ptr %slot140, align 8
  %v1167 = load i64, ptr %slot19, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i64 %v1166, ptr %p1168, align 8, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot19, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %ld1171 = load i64, ptr %p1170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1171, ptr %slot141, align 8
  %v1172 = load i64, ptr %slot141, align 8
  %v1173 = load i64, ptr %slot22, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  store i64 %v1172, ptr %p1174, align 8, !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot18, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  %ld1177 = load i64, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1177, ptr %slot142, align 8
  %v1178 = load i64, ptr %slot142, align 8
  %v1179 = load i64, ptr %slot23, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i64 %v1178, ptr %p1180, align 8, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot23, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %ld1183 = load i64, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1183, ptr %slot143, align 8
  %v1184 = load i64, ptr %slot143, align 8
  %op1185 = add i64 %v1184, 0
  store i64 %op1185, ptr %slot144, align 8
  %v1186 = load i64, ptr %slot144, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i64, ptr %p1187, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1188, ptr %slot145, align 8
  %v1189 = load i64, ptr %slot145, align 8
  %v1190 = load i64, ptr %slot23, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  store i64 %v1189, ptr %p1191, align 8, !alias.scope !3, !noalias !4
  %v1192 = load i64, ptr %slot23, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i64, ptr %p1193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1194, ptr %slot146, align 8
  %v1195 = load i64, ptr %slot22, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i64, ptr %p1196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1197, ptr %slot147, align 8
  %v1198 = load i64, ptr %slot1, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %v1200 = load i64, ptr %slot147, align 8
  %v1201 = load i64, ptr %slot146, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %call1203 = call i64 @myl_qbe_stream_write_bytes(ptr %p1199, i64 %v1200, ptr %p1202) nomerge, !dbg !124
  store i64 %call1203, ptr %slot148, align 8
  %v1204 = load i64, ptr %slot148, align 8
  %v1205 = load i64, ptr %slot22, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i64 %v1204, ptr %p1206, align 8, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot1, align 8
  %call1208 = call i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64 %v1207) nomerge, !dbg !126
  store i64 %call1208, ptr %slot149, align 8
  %v1209 = load i64, ptr %slot149, align 8
  %v1210 = load i64, ptr %slot22, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i64 %v1209, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot22, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %ld1214 = load i64, ptr %p1213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1214, ptr %slot150, align 8
  %v1215 = load i64, ptr %slot150, align 8
  %v1216 = load i64, ptr %slot15, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i64 %v1215, ptr %p1217, align 8, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot15, align 8
  store i64 %v1218, ptr %slot151, align 8
  %v1219 = load i64, ptr %slot17, align 8
  store i64 %v1219, ptr %slot152, align 8
  %v1220 = load i64, ptr %slot151, align 8
  %v1221 = load i64, ptr %slot152, align 8
  %p1222 = inttoptr i64 %v1220 to ptr
  %p1223 = inttoptr i64 %v1221 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1223, ptr %p1222, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot12, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 2, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot11, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  store i32 1, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot14, align 8
  store i64 %v1228, ptr %slot153, align 8
  %v1229 = load i64, ptr %slot17, align 8
  store i64 %v1229, ptr %slot154, align 8
  %v1230 = load i64, ptr %slot154, align 8
  %v1231 = load i64, ptr %slot153, align 8
  %p1232 = inttoptr i64 %v1230 to ptr
  %p1233 = inttoptr i64 %v1231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1233, ptr %p1232, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot9, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 2, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot12, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  %ld1238 = load i32, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1238, ptr %slot155, align 8
  %v1239 = load i32, ptr %slot155, align 8
  %v1240 = load i64, ptr %slot9, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i32 %v1239, ptr %p1241, align 4, !alias.scope !3, !noalias !4
  %v1242 = load i64, ptr %slot11, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i32 0, ptr %p1243, align 4, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot8, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  store i32 1, ptr %p1245, align 4, !alias.scope !3, !noalias !4
  %v1246 = load i64, ptr %slot153, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  %ld1248 = load i64, ptr %p1247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1248, ptr %slot156, align 8
  %v1249 = load i64, ptr %slot156, align 8
  %v1250 = load i64, ptr %slot22, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  store i64 %v1249, ptr %p1251, align 8, !alias.scope !3, !noalias !4
  %v1252 = load i64, ptr %slot22, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  %ld1254 = load i64, ptr %p1253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1254, ptr %slot157, align 8
  %v1255 = load i64, ptr %slot157, align 8
  %v1256 = load i64, ptr %slot15, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  store i64 %v1255, ptr %p1257, align 8, !alias.scope !3, !noalias !4
  %v1258 = load i64, ptr %slot15, align 8
  store i64 %v1258, ptr %slot158, align 8
  %v1259 = load i64, ptr %slot8, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  %ld1261 = load i32, ptr %p1260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1261, ptr %slot159, align 8
  %v1262 = load i64, ptr %slot9, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i32, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1264, ptr %slot160, align 8
  %v1265 = load i32, ptr %slot160, align 8
  %op1266 = and i32 %v1265, 24
  store i32 %op1266, ptr %slot160, align 8
  %v1267 = load i32, ptr %slot160, align 8
  %cmp1268 = icmp eq i32 %v1267, 0
  %cv1269 = zext i1 %cmp1268 to i32
  store i32 %cv1269, ptr %slot161, align 8
  %v1270 = load i32, ptr %slot159, align 8
  %v1271 = load i32, ptr %slot161, align 8
  %op1272 = and i32 %v1270, %v1271
  store i32 %op1272, ptr %slot162, align 8
  %v1273 = load i32, ptr %slot162, align 8
  %cv1274 = zext i32 %v1273 to i64
  %cond1275 = icmp ne i64 %cv1274, 0
  br i1 %cond1275, label %bb_rcprivateown230, label %bb_rcprivateloan230
bb_rcprivateown230:
  %v1276 = load i64, ptr %slot17, align 8
  store i64 %v1276, ptr %slot163, align 8
  %v1277 = load i64, ptr %slot30, align 8
  store i64 %v1277, ptr %slot164, align 8
  %v1278 = load i64, ptr %slot158, align 8
  %v1279 = load i64, ptr %slot163, align 8
  %op1280 = sub i64 %v1278, %v1279
  store i64 %op1280, ptr %slot165, align 8
  %v1281 = load i64, ptr %slot163, align 8
  %v1282 = load i64, ptr %slot158, align 8
  %op1283 = sub i64 %v1281, %v1282
  store i64 %op1283, ptr %slot166, align 8
  %v1284 = load i64, ptr %slot165, align 8
  %cmp1285 = icmp ult i64 %v1284, 8
  %cv1286 = zext i1 %cmp1285 to i32
  store i32 %cv1286, ptr %slot167, align 8
  %v1287 = load i64, ptr %slot166, align 8
  %cmp1288 = icmp ult i64 %v1287, 8
  %cv1289 = zext i1 %cmp1288 to i32
  store i32 %cv1289, ptr %slot168, align 8
  %v1290 = load i32, ptr %slot167, align 8
  %v1291 = load i32, ptr %slot168, align 8
  %op1292 = or i32 %v1290, %v1291
  store i32 %op1292, ptr %slot169, align 8
  %v1293 = load i32, ptr %slot169, align 8
  %cv1294 = zext i32 %v1293 to i64
  %cond1295 = icmp ne i64 %cv1294, 0
  br i1 %cond1295, label %bb_rcmoveslow233, label %bb_rcmovecheck233
bb_rcmovecheck233:
  %v1296 = load i64, ptr %slot158, align 8
  %p1298 = inttoptr i64 %v1296 to ptr
  %gep1299 = getelementptr i8, ptr %p1298, i64 0
  %op1297 = ptrtoint ptr %gep1299 to i64
  store i64 %op1297, ptr %slot170, align 8
  %v1300 = load i64, ptr %slot170, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  %ld1302 = load i64, ptr %p1301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1302, ptr %slot171, align 8
  %v1303 = load i64, ptr %slot171, align 8
  %cmp1304 = icmp ne i64 %v1303, 0
  %cv1305 = zext i1 %cmp1304 to i32
  store i32 %cv1305, ptr %slot172, align 8
  %v1306 = load i32, ptr %slot172, align 8
  %cv1307 = zext i32 %v1306 to i64
  %cond1308 = icmp ne i64 %cv1307, 0
  br i1 %cond1308, label %bb_rcmoveheader241, label %bb_rcmovenext241
bb_rcmoveheader241:
  %v1309 = load i64, ptr %slot171, align 8
  %op1310 = sub i64 %v1309, 16
  store i64 %op1310, ptr %slot173, align 8
  %v1311 = load i64, ptr %slot171, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %rgep1313 = getelementptr i8, ptr %p1312, i64 -16
  %ld1314 = load i64, ptr %rgep1313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1314, ptr %slot174, align 8
  %v1315 = load i64, ptr %slot174, align 8
  %op1316 = and i64 %v1315, 5764607523034234881
  store i64 %op1316, ptr %slot175, align 8
  %v1317 = load i64, ptr %slot175, align 8
  %cmp1318 = icmp ne i64 %v1317, 0
  %cv1319 = zext i1 %cmp1318 to i32
  store i32 %cv1319, ptr %slot176, align 8
  %v1320 = load i32, ptr %slot176, align 8
  %cv1321 = zext i32 %v1320 to i64
  %cond1322 = icmp ne i64 %cv1321, 0
  br i1 %cond1322, label %bb_rcmoveslow233, label %bb_rcmovenext241
bb_rcmovenext241:
  %v1323 = load i64, ptr %slot158, align 8
  %v1324 = load i64, ptr %slot163, align 8
  %p1325 = inttoptr i64 %v1323 to ptr
  %p1326 = inttoptr i64 %v1324 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1326, ptr %p1325, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1327 = load i64, ptr %slot158, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  store i64 0, ptr %p1328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved233
bb_rcmoveslow233:
  %v1329 = load i64, ptr %slot29, align 8
  %v1330 = load i64, ptr %slot163, align 8
  %v1331 = load i64, ptr %slot158, align 8
  %v1332 = load i64, ptr %slot164, align 8
  %cv1333 = trunc i64 %v1332 to i32
  %call1334 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v1329, i64 %v1330, i64 %v1331, i32 %cv1333) nomerge, !dbg !128
  store i32 %call1334, ptr %slot177, align 8
  %v1335 = load i32, ptr %slot177, align 8
  %cv1336 = zext i32 %v1335 to i64
  %cond1337 = icmp ne i64 %cv1336, 0
  br i1 %cond1337, label %bb_rcsuccess248, label %bb_rcfailure248
bb_rcfailure248:
  %v1338 = load i64, ptr %slot29, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %call1340 = call i32 @myl_rc_take_failure(ptr %p1339) nomerge, !dbg !128
  store i32 %call1340, ptr %slot178, align 8
  %v1341 = load i64, ptr %slot1, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %v1343 = load i32, ptr %slot178, align 8
  %call1344 = call i32 @myl_qbe_rc_status(ptr %p1342, i32 %v1343) nomerge, !dbg !128
  store i32 %call1344, ptr %slot179, align 8
  br label %bb_failure
bb_rcsuccess248:
  br label %bb_rcmoved233
bb_rcmoved233:
  %v1345 = load i64, ptr %slot8, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i32 0, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot12, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  store i32 2, ptr %p1348, align 4, !alias.scope !3, !noalias !4
  %v1349 = load i64, ptr %slot11, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  store i32 1, ptr %p1350, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared230
bb_rcprivateloan230:
  %v1351 = load i64, ptr %slot8, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  %ld1353 = load i32, ptr %p1352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1353, ptr %slot180, align 8
  %v1354 = load i64, ptr %slot9, align 8
  %p1355 = inttoptr i64 %v1354 to ptr
  %ld1356 = load i32, ptr %p1355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1356, ptr %slot181, align 8
  %v1357 = load i32, ptr %slot181, align 8
  %cmp1358 = icmp eq i32 %v1357, 16
  %cv1359 = zext i1 %cmp1358 to i32
  store i32 %cv1359, ptr %slot182, align 8
  %v1360 = load i32, ptr %slot182, align 8
  %v1361 = load i32, ptr %slot180, align 8
  %op1362 = and i32 %v1360, %v1361
  store i32 %op1362, ptr %slot182, align 8
  %v1363 = load i32, ptr %slot182, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcprivatemove230, label %bb_rcprivatenew230
bb_rcprivatemove230:
  %v1366 = load i64, ptr %slot17, align 8
  store i64 %v1366, ptr %slot183, align 8
  %v1367 = load i64, ptr %slot158, align 8
  %v1368 = load i64, ptr %slot183, align 8
  %p1369 = inttoptr i64 %v1367 to ptr
  %p1370 = inttoptr i64 %v1368 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1370, ptr %p1369, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1371 = load i64, ptr %slot158, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i64 0, ptr %p1372, align 8, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot12, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i32 2, ptr %p1374, align 4, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot12, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i32 16, ptr %p1376, align 4, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot11, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i32 1, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  %v1379 = load i64, ptr %slot8, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i32 0, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared230
bb_rcprivatenew230:
  %v1381 = load i64, ptr %slot17, align 8
  store i64 %v1381, ptr %slot184, align 8
  %v1382 = load i64, ptr %slot158, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %ld1384 = load i64, ptr %p1383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1384, ptr %slot185, align 8
  %v1385 = load i64, ptr %slot185, align 8
  %cmp1386 = icmp ne i64 %v1385, 0
  %cv1387 = zext i1 %cmp1386 to i32
  store i32 %cv1387, ptr %slot186, align 8
  %v1388 = load i32, ptr %slot186, align 8
  %cv1389 = zext i32 %v1388 to i64
  %cond1390 = icmp ne i64 %cv1389, 0
  br i1 %cond1390, label %bb_rcgnn266, label %bb_rcgstore266
bb_rcgnn266:
  %v1391 = load i64, ptr %slot185, align 8
  %op1392 = sub i64 %v1391, 16
  store i64 %op1392, ptr %slot187, align 8
  %v1393 = load i64, ptr %slot185, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  %rgep1395 = getelementptr i8, ptr %p1394, i64 -16
  %ld1396 = load i64, ptr %rgep1395, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1396, ptr %slot188, align 8
  %v1397 = load i64, ptr %slot188, align 8
  %op1398 = and i64 %v1397, 4611686018427387906
  store i64 %op1398, ptr %slot189, align 8
  %v1399 = load i64, ptr %slot189, align 8
  %cmp1400 = icmp ne i64 %v1399, 0
  %cv1401 = zext i1 %cmp1400 to i32
  store i32 %cv1401, ptr %slot190, align 8
  %v1402 = load i32, ptr %slot190, align 8
  %cv1403 = zext i32 %v1402 to i64
  %cond1404 = icmp ne i64 %cv1403, 0
  br i1 %cond1404, label %bb_rcgstore266, label %bb_rcginc266
bb_rcginc266:
  %v1405 = load i64, ptr %slot185, align 8
  %op1406 = sub i64 %v1405, 24
  store i64 %op1406, ptr %slot191, align 8
  %v1407 = load i64, ptr %slot185, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  %rgep1409 = getelementptr i8, ptr %p1408, i64 -24
  %ld1410 = load i64, ptr %rgep1409, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1410, ptr %slot192, align 8
  %v1411 = load i64, ptr %slot192, align 8
  %op1412 = add i64 %v1411, 1
  store i64 %op1412, ptr %slot193, align 8
  %v1413 = load i64, ptr %slot193, align 8
  %cmp1414 = icmp eq i64 %v1413, 0
  %cv1415 = zext i1 %cmp1414 to i32
  store i32 %cv1415, ptr %slot194, align 8
  %v1416 = load i32, ptr %slot194, align 8
  %cv1417 = zext i32 %v1416 to i64
  %cond1418 = icmp ne i64 %cv1417, 0
  br i1 %cond1418, label %bb_rcglimit266, label %bb_rcgcapacity266
bb_rcglimit266:
  %v1419 = load i64, ptr %slot1, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %call1421 = call i32 @myl_qbe_rc_status(ptr %p1420, i32 2) nomerge, !dbg !128
  store i32 %call1421, ptr %slot195, align 8
  br label %bb_failure
bb_rcgcapacity266:
  %v1422 = load i64, ptr %slot193, align 8
  %v1423 = load i64, ptr %slot185, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  %rgep1425 = getelementptr i8, ptr %p1424, i64 -24
  store i64 %v1422, ptr %rgep1425, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore266
bb_rcgstore266:
  %v1426 = load i64, ptr %slot185, align 8
  %v1427 = load i64, ptr %slot184, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 %v1426, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot12, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  store i32 2, ptr %p1430, align 4, !alias.scope !3, !noalias !4
  %v1431 = load i64, ptr %slot12, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  store i32 16, ptr %p1432, align 4, !alias.scope !3, !noalias !4
  %v1433 = load i64, ptr %slot11, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i32 1, ptr %p1434, align 4, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot8, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %ld1437 = load i32, ptr %p1436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1437, ptr %slot196, align 8
  %v1438 = load i32, ptr %slot196, align 8
  %cv1439 = zext i32 %v1438 to i64
  %cond1440 = icmp ne i64 %cv1439, 0
  br i1 %cond1440, label %bb_rcslotdrop282, label %bb_rcslotdone282
bb_rcslotdrop282:
  %v1441 = load i64, ptr %slot8, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  store i32 0, ptr %p1442, align 4, !alias.scope !3, !noalias !4
  %v1443 = load i64, ptr %slot14, align 8
  store i64 %v1443, ptr %slot197, align 8
  %v1444 = load i64, ptr %slot9, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  %ld1446 = load i32, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1446, ptr %slot198, align 8
  %v1447 = load i32, ptr %slot198, align 8
  %op1448 = and i32 %v1447, 28
  store i32 %op1448, ptr %slot199, align 8
  %v1449 = load i32, ptr %slot199, align 8
  %cv1450 = zext i32 %v1449 to i64
  %cond1451 = icmp ne i64 %cv1450, 0
  br i1 %cond1451, label %bb_rcslotrole282, label %bb_rcslotowner282
bb_rcslotrole282:
  %v1452 = load i64, ptr %slot29, align 8
  store i64 %v1452, ptr %slot200, align 8
  %v1453 = load i64, ptr %slot197, align 8
  %p1454 = inttoptr i64 %v1453 to ptr
  %ld1455 = load i64, ptr %p1454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1455, ptr %slot201, align 8
  %v1456 = load i64, ptr %slot201, align 8
  %cmp1457 = icmp ne i64 %v1456, 0
  %cv1458 = zext i1 %cmp1457 to i32
  store i32 %cv1458, ptr %slot202, align 8
  %v1459 = load i32, ptr %slot202, align 8
  %cv1460 = zext i32 %v1459 to i64
  %cond1461 = icmp ne i64 %cv1460, 0
  br i1 %cond1461, label %bb_rcgnn298, label %bb_rcgdone298
bb_rcgnn298:
  %v1462 = load i64, ptr %slot201, align 8
  %op1463 = sub i64 %v1462, 16
  store i64 %op1463, ptr %slot203, align 8
  %v1464 = load i64, ptr %slot201, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %rgep1466 = getelementptr i8, ptr %p1465, i64 -16
  %ld1467 = load i64, ptr %rgep1466, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1467, ptr %slot204, align 8
  %v1468 = load i64, ptr %slot204, align 8
  %op1469 = and i64 %v1468, 4611686018427387906
  store i64 %op1469, ptr %slot205, align 8
  %v1470 = load i64, ptr %slot205, align 8
  %cmp1471 = icmp ne i64 %v1470, 0
  %cv1472 = zext i1 %cmp1471 to i32
  store i32 %cv1472, ptr %slot206, align 8
  %v1473 = load i32, ptr %slot206, align 8
  %cv1474 = zext i32 %v1473 to i64
  %cond1475 = icmp ne i64 %cv1474, 0
  br i1 %cond1475, label %bb_rcgclear298, label %bb_rcgcounted298
bb_rcgcounted298:
  %v1476 = load i64, ptr %slot201, align 8
  %op1477 = sub i64 %v1476, 24
  store i64 %op1477, ptr %slot207, align 8
  %v1478 = load i64, ptr %slot201, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  %rgep1480 = getelementptr i8, ptr %p1479, i64 -24
  %ld1481 = load i64, ptr %rgep1480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1481, ptr %slot208, align 8
  %v1482 = load i64, ptr %slot208, align 8
  %op1483 = sub i64 %v1482, 1
  store i64 %op1483, ptr %slot209, align 8
  %v1484 = load i64, ptr %slot209, align 8
  %cmp1485 = icmp eq i64 %v1484, 0
  %cv1486 = zext i1 %cmp1485 to i32
  store i32 %cv1486, ptr %slot210, align 8
  %v1487 = load i32, ptr %slot210, align 8
  %cv1488 = zext i32 %v1487 to i64
  %cond1489 = icmp ne i64 %cv1488, 0
  br i1 %cond1489, label %bb_rcglast298, label %bb_rcgdec298
bb_rcglast298:
  %v1490 = load i64, ptr %slot201, align 8
  %op1491 = sub i64 %v1490, 32
  store i64 %op1491, ptr %slot211, align 8
  %v1492 = load i64, ptr %slot201, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %rgep1494 = getelementptr i8, ptr %p1493, i64 -32
  %ld1495 = load i64, ptr %rgep1494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1495, ptr %slot212, align 8
  %v1496 = load i64, ptr %slot212, align 8
  %cmp1497 = icmp ne i64 %v1496, 0
  %cv1498 = zext i1 %cmp1497 to i32
  store i32 %cv1498, ptr %slot213, align 8
  %v1499 = load i32, ptr %slot213, align 8
  %cv1500 = zext i32 %v1499 to i64
  %cond1501 = icmp ne i64 %cv1500, 0
  br i1 %cond1501, label %bb_rcgdec298, label %bb_rcgslow298
bb_rcgslow298:
  %v1502 = load i64, ptr %slot200, align 8
  %v1503 = load i64, ptr %slot197, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1502, i64 %v1503) nomerge, !dbg !128
  br label %bb_rcgdone298
bb_rcgdec298:
  %v1504 = load i64, ptr %slot209, align 8
  %v1505 = load i64, ptr %slot201, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %rgep1507 = getelementptr i8, ptr %p1506, i64 -24
  store i64 %v1504, ptr %rgep1507, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear298
bb_rcgclear298:
  %v1508 = load i64, ptr %slot197, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i64 0, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone298
bb_rcgdone298:
  br label %bb_rcslotdone282
bb_rcslotowner282:
  %v1510 = load i64, ptr %slot29, align 8
  store i64 %v1510, ptr %slot214, align 8
  %v1511 = load i64, ptr %slot197, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %ld1513 = load i64, ptr %p1512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1513, ptr %slot215, align 8
  %v1514 = load i64, ptr %slot215, align 8
  %cmp1515 = icmp ne i64 %v1514, 0
  %cv1516 = zext i1 %cmp1515 to i32
  store i32 %cv1516, ptr %slot216, align 8
  %v1517 = load i32, ptr %slot216, align 8
  %cv1518 = zext i32 %v1517 to i64
  %cond1519 = icmp ne i64 %cv1518, 0
  br i1 %cond1519, label %bb_rcgnn313, label %bb_rcgdone313
bb_rcgnn313:
  %v1520 = load i64, ptr %slot215, align 8
  %op1521 = sub i64 %v1520, 16
  store i64 %op1521, ptr %slot217, align 8
  %v1522 = load i64, ptr %slot215, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  %rgep1524 = getelementptr i8, ptr %p1523, i64 -16
  %ld1525 = load i64, ptr %rgep1524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1525, ptr %slot218, align 8
  %v1526 = load i64, ptr %slot218, align 8
  %op1527 = and i64 %v1526, 4611686018427387906
  store i64 %op1527, ptr %slot219, align 8
  %v1528 = load i64, ptr %slot219, align 8
  %cmp1529 = icmp ne i64 %v1528, 0
  %cv1530 = zext i1 %cmp1529 to i32
  store i32 %cv1530, ptr %slot220, align 8
  %v1531 = load i32, ptr %slot220, align 8
  %cv1532 = zext i32 %v1531 to i64
  %cond1533 = icmp ne i64 %cv1532, 0
  br i1 %cond1533, label %bb_rcgclear313, label %bb_rcgcounted313
bb_rcgcounted313:
  %v1534 = load i64, ptr %slot215, align 8
  %op1535 = sub i64 %v1534, 32
  store i64 %op1535, ptr %slot221, align 8
  %v1536 = load i64, ptr %slot215, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %rgep1538 = getelementptr i8, ptr %p1537, i64 -32
  %ld1539 = load i64, ptr %rgep1538, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1539, ptr %slot222, align 8
  %v1540 = load i64, ptr %slot222, align 8
  %op1541 = sub i64 %v1540, 1
  store i64 %op1541, ptr %slot223, align 8
  %v1542 = load i64, ptr %slot223, align 8
  %cmp1543 = icmp eq i64 %v1542, 0
  %cv1544 = zext i1 %cmp1543 to i32
  store i32 %cv1544, ptr %slot224, align 8
  %v1545 = load i32, ptr %slot224, align 8
  %cv1546 = zext i32 %v1545 to i64
  %cond1547 = icmp ne i64 %cv1546, 0
  br i1 %cond1547, label %bb_rcglast313, label %bb_rcgdec313
bb_rcglast313:
  %v1548 = load i64, ptr %slot215, align 8
  %op1549 = sub i64 %v1548, 24
  store i64 %op1549, ptr %slot225, align 8
  %v1550 = load i64, ptr %slot215, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  %rgep1552 = getelementptr i8, ptr %p1551, i64 -24
  %ld1553 = load i64, ptr %rgep1552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1553, ptr %slot226, align 8
  %v1554 = load i64, ptr %slot226, align 8
  %cmp1555 = icmp ne i64 %v1554, 0
  %cv1556 = zext i1 %cmp1555 to i32
  store i32 %cv1556, ptr %slot227, align 8
  %v1557 = load i32, ptr %slot227, align 8
  %cv1558 = zext i32 %v1557 to i64
  %cond1559 = icmp ne i64 %cv1558, 0
  br i1 %cond1559, label %bb_rcgdec313, label %bb_rcgslow313
bb_rcgslow313:
  %v1560 = load i64, ptr %slot214, align 8
  %v1561 = load i64, ptr %slot197, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1560, i64 %v1561) nomerge, !dbg !128
  br label %bb_rcgdone313
bb_rcgdec313:
  %v1562 = load i64, ptr %slot223, align 8
  %v1563 = load i64, ptr %slot215, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %rgep1565 = getelementptr i8, ptr %p1564, i64 -32
  store i64 %v1562, ptr %rgep1565, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear313
bb_rcgclear313:
  %v1566 = load i64, ptr %slot197, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  store i64 0, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone313
bb_rcgdone313:
  br label %bb_rcslotdone282
bb_rcslotdone282:
  br label %bb_rcprivateprepared230
bb_rcprivateprepared230:
  %v1568 = load i64, ptr %slot6, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  %ld1570 = load i32, ptr %p1569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1570, ptr %slot228, align 8
  %v1571 = load i32, ptr %slot228, align 8
  %cv1572 = zext i32 %v1571 to i64
  %cond1573 = icmp ne i64 %cv1572, 0
  br i1 %cond1573, label %bb_rcslotdrop320, label %bb_rcslotdone320
bb_rcslotdrop320:
  %v1574 = load i64, ptr %slot6, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 0, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot21, align 8
  store i64 %v1576, ptr %slot229, align 8
  %v1577 = load i64, ptr %slot7, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  %ld1579 = load i32, ptr %p1578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1579, ptr %slot230, align 8
  %v1580 = load i32, ptr %slot230, align 8
  %op1581 = and i32 %v1580, 28
  store i32 %op1581, ptr %slot231, align 8
  %v1582 = load i32, ptr %slot231, align 8
  %cv1583 = zext i32 %v1582 to i64
  %cond1584 = icmp ne i64 %cv1583, 0
  br i1 %cond1584, label %bb_rcslotrole320, label %bb_rcslotowner320
bb_rcslotrole320:
  %v1585 = load i64, ptr %slot29, align 8
  store i64 %v1585, ptr %slot232, align 8
  %v1586 = load i64, ptr %slot229, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %ld1588 = load i64, ptr %p1587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1588, ptr %slot233, align 8
  %v1589 = load i64, ptr %slot233, align 8
  %cmp1590 = icmp ne i64 %v1589, 0
  %cv1591 = zext i1 %cmp1590 to i32
  store i32 %cv1591, ptr %slot234, align 8
  %v1592 = load i32, ptr %slot234, align 8
  %cv1593 = zext i32 %v1592 to i64
  %cond1594 = icmp ne i64 %cv1593, 0
  br i1 %cond1594, label %bb_rcgnn336, label %bb_rcgdone336
bb_rcgnn336:
  %v1595 = load i64, ptr %slot233, align 8
  %op1596 = sub i64 %v1595, 16
  store i64 %op1596, ptr %slot235, align 8
  %v1597 = load i64, ptr %slot233, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %rgep1599 = getelementptr i8, ptr %p1598, i64 -16
  %ld1600 = load i64, ptr %rgep1599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1600, ptr %slot236, align 8
  %v1601 = load i64, ptr %slot236, align 8
  %op1602 = and i64 %v1601, 4611686018427387906
  store i64 %op1602, ptr %slot237, align 8
  %v1603 = load i64, ptr %slot237, align 8
  %cmp1604 = icmp ne i64 %v1603, 0
  %cv1605 = zext i1 %cmp1604 to i32
  store i32 %cv1605, ptr %slot238, align 8
  %v1606 = load i32, ptr %slot238, align 8
  %cv1607 = zext i32 %v1606 to i64
  %cond1608 = icmp ne i64 %cv1607, 0
  br i1 %cond1608, label %bb_rcgclear336, label %bb_rcgcounted336
bb_rcgcounted336:
  %v1609 = load i64, ptr %slot233, align 8
  %op1610 = sub i64 %v1609, 24
  store i64 %op1610, ptr %slot239, align 8
  %v1611 = load i64, ptr %slot233, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %rgep1613 = getelementptr i8, ptr %p1612, i64 -24
  %ld1614 = load i64, ptr %rgep1613, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1614, ptr %slot240, align 8
  %v1615 = load i64, ptr %slot240, align 8
  %op1616 = sub i64 %v1615, 1
  store i64 %op1616, ptr %slot241, align 8
  %v1617 = load i64, ptr %slot241, align 8
  %cmp1618 = icmp eq i64 %v1617, 0
  %cv1619 = zext i1 %cmp1618 to i32
  store i32 %cv1619, ptr %slot242, align 8
  %v1620 = load i32, ptr %slot242, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcglast336, label %bb_rcgdec336
bb_rcglast336:
  %v1623 = load i64, ptr %slot233, align 8
  %op1624 = sub i64 %v1623, 32
  store i64 %op1624, ptr %slot243, align 8
  %v1625 = load i64, ptr %slot233, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %rgep1627 = getelementptr i8, ptr %p1626, i64 -32
  %ld1628 = load i64, ptr %rgep1627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1628, ptr %slot244, align 8
  %v1629 = load i64, ptr %slot244, align 8
  %cmp1630 = icmp ne i64 %v1629, 0
  %cv1631 = zext i1 %cmp1630 to i32
  store i32 %cv1631, ptr %slot245, align 8
  %v1632 = load i32, ptr %slot245, align 8
  %cv1633 = zext i32 %v1632 to i64
  %cond1634 = icmp ne i64 %cv1633, 0
  br i1 %cond1634, label %bb_rcgdec336, label %bb_rcgslow336
bb_rcgslow336:
  %v1635 = load i64, ptr %slot232, align 8
  %v1636 = load i64, ptr %slot229, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v1635, i64 %v1636) nomerge, !dbg !128
  br label %bb_rcgdone336
bb_rcgdec336:
  %v1637 = load i64, ptr %slot241, align 8
  %v1638 = load i64, ptr %slot233, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  %rgep1640 = getelementptr i8, ptr %p1639, i64 -24
  store i64 %v1637, ptr %rgep1640, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear336
bb_rcgclear336:
  %v1641 = load i64, ptr %slot229, align 8
  %p1642 = inttoptr i64 %v1641 to ptr
  store i64 0, ptr %p1642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone336
bb_rcgdone336:
  br label %bb_rcslotdone320
bb_rcslotowner320:
  %v1643 = load i64, ptr %slot29, align 8
  store i64 %v1643, ptr %slot246, align 8
  %v1644 = load i64, ptr %slot229, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  %ld1646 = load i64, ptr %p1645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1646, ptr %slot247, align 8
  %v1647 = load i64, ptr %slot247, align 8
  %cmp1648 = icmp ne i64 %v1647, 0
  %cv1649 = zext i1 %cmp1648 to i32
  store i32 %cv1649, ptr %slot248, align 8
  %v1650 = load i32, ptr %slot248, align 8
  %cv1651 = zext i32 %v1650 to i64
  %cond1652 = icmp ne i64 %cv1651, 0
  br i1 %cond1652, label %bb_rcgnn351, label %bb_rcgdone351
bb_rcgnn351:
  %v1653 = load i64, ptr %slot247, align 8
  %op1654 = sub i64 %v1653, 16
  store i64 %op1654, ptr %slot249, align 8
  %v1655 = load i64, ptr %slot247, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  %rgep1657 = getelementptr i8, ptr %p1656, i64 -16
  %ld1658 = load i64, ptr %rgep1657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1658, ptr %slot250, align 8
  %v1659 = load i64, ptr %slot250, align 8
  %op1660 = and i64 %v1659, 4611686018427387906
  store i64 %op1660, ptr %slot251, align 8
  %v1661 = load i64, ptr %slot251, align 8
  %cmp1662 = icmp ne i64 %v1661, 0
  %cv1663 = zext i1 %cmp1662 to i32
  store i32 %cv1663, ptr %slot252, align 8
  %v1664 = load i32, ptr %slot252, align 8
  %cv1665 = zext i32 %v1664 to i64
  %cond1666 = icmp ne i64 %cv1665, 0
  br i1 %cond1666, label %bb_rcgclear351, label %bb_rcgcounted351
bb_rcgcounted351:
  %v1667 = load i64, ptr %slot247, align 8
  %op1668 = sub i64 %v1667, 32
  store i64 %op1668, ptr %slot253, align 8
  %v1669 = load i64, ptr %slot247, align 8
  %p1670 = inttoptr i64 %v1669 to ptr
  %rgep1671 = getelementptr i8, ptr %p1670, i64 -32
  %ld1672 = load i64, ptr %rgep1671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1672, ptr %slot254, align 8
  %v1673 = load i64, ptr %slot254, align 8
  %op1674 = sub i64 %v1673, 1
  store i64 %op1674, ptr %slot255, align 8
  %v1675 = load i64, ptr %slot255, align 8
  %cmp1676 = icmp eq i64 %v1675, 0
  %cv1677 = zext i1 %cmp1676 to i32
  store i32 %cv1677, ptr %slot256, align 8
  %v1678 = load i32, ptr %slot256, align 8
  %cv1679 = zext i32 %v1678 to i64
  %cond1680 = icmp ne i64 %cv1679, 0
  br i1 %cond1680, label %bb_rcglast351, label %bb_rcgdec351
bb_rcglast351:
  %v1681 = load i64, ptr %slot247, align 8
  %op1682 = sub i64 %v1681, 24
  store i64 %op1682, ptr %slot257, align 8
  %v1683 = load i64, ptr %slot247, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  %rgep1685 = getelementptr i8, ptr %p1684, i64 -24
  %ld1686 = load i64, ptr %rgep1685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1686, ptr %slot258, align 8
  %v1687 = load i64, ptr %slot258, align 8
  %cmp1688 = icmp ne i64 %v1687, 0
  %cv1689 = zext i1 %cmp1688 to i32
  store i32 %cv1689, ptr %slot259, align 8
  %v1690 = load i32, ptr %slot259, align 8
  %cv1691 = zext i32 %v1690 to i64
  %cond1692 = icmp ne i64 %cv1691, 0
  br i1 %cond1692, label %bb_rcgdec351, label %bb_rcgslow351
bb_rcgslow351:
  %v1693 = load i64, ptr %slot246, align 8
  %v1694 = load i64, ptr %slot229, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v1693, i64 %v1694) nomerge, !dbg !128
  br label %bb_rcgdone351
bb_rcgdec351:
  %v1695 = load i64, ptr %slot255, align 8
  %v1696 = load i64, ptr %slot247, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %rgep1698 = getelementptr i8, ptr %p1697, i64 -32
  store i64 %v1695, ptr %rgep1698, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear351
bb_rcgclear351:
  %v1699 = load i64, ptr %slot229, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i64 0, ptr %p1700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone351
bb_rcgdone351:
  br label %bb_rcslotdone320
bb_rcslotdone320:
  %v1701 = load i64, ptr %slot21, align 8
  store i64 %v1701, ptr %slot260, align 8
  %v1702 = load i64, ptr %slot17, align 8
  store i64 %v1702, ptr %slot261, align 8
  %v1703 = load i64, ptr %slot261, align 8
  %v1704 = load i64, ptr %slot260, align 8
  %p1705 = inttoptr i64 %v1703 to ptr
  %p1706 = inttoptr i64 %v1704 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1706, ptr %p1705, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot11, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 0, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot7, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i32 2, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot12, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i32, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1713, ptr %slot262, align 8
  %v1714 = load i32, ptr %slot262, align 8
  %v1715 = load i64, ptr %slot7, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 %v1714, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot6, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i32 1, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot18, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %ld1721 = load i64, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1721, ptr %slot263, align 8
  %v1722 = load i64, ptr %slot263, align 8
  %v1723 = load i64, ptr %slot22, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i64 %v1722, ptr %p1724, align 8, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot22, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %ld1727 = load i64, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1727, ptr %slot264, align 8
  %v1728 = load i64, ptr %slot8, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  %ld1730 = load i32, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1730, ptr %slot265, align 8
  %v1731 = load i64, ptr %slot9, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i32, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1733, ptr %slot266, align 8
  %v1734 = load i32, ptr %slot266, align 8
  %op1735 = and i32 %v1734, 24
  store i32 %op1735, ptr %slot266, align 8
  %v1736 = load i32, ptr %slot266, align 8
  %cmp1737 = icmp eq i32 %v1736, 0
  %cv1738 = zext i1 %cmp1737 to i32
  store i32 %cv1738, ptr %slot267, align 8
  %v1739 = load i32, ptr %slot265, align 8
  %v1740 = load i32, ptr %slot267, align 8
  %op1741 = and i32 %v1739, %v1740
  store i32 %op1741, ptr %slot268, align 8
  %v1742 = load i32, ptr %slot268, align 8
  %cv1743 = zext i32 %v1742 to i64
  %cond1744 = icmp ne i64 %cv1743, 0
  br i1 %cond1744, label %bb_rcprivateown370, label %bb_rcprivateloan370
bb_rcprivateown370:
  %v1745 = load i64, ptr %slot17, align 8
  store i64 %v1745, ptr %slot269, align 8
  %v1746 = load i64, ptr %slot30, align 8
  store i64 %v1746, ptr %slot270, align 8
  %v1747 = load i64, ptr %slot264, align 8
  %v1748 = load i64, ptr %slot269, align 8
  %op1749 = sub i64 %v1747, %v1748
  store i64 %op1749, ptr %slot271, align 8
  %v1750 = load i64, ptr %slot269, align 8
  %v1751 = load i64, ptr %slot264, align 8
  %op1752 = sub i64 %v1750, %v1751
  store i64 %op1752, ptr %slot272, align 8
  %v1753 = load i64, ptr %slot271, align 8
  %cmp1754 = icmp ult i64 %v1753, 40
  %cv1755 = zext i1 %cmp1754 to i32
  store i32 %cv1755, ptr %slot273, align 8
  %v1756 = load i64, ptr %slot272, align 8
  %cmp1757 = icmp ult i64 %v1756, 40
  %cv1758 = zext i1 %cmp1757 to i32
  store i32 %cv1758, ptr %slot274, align 8
  %v1759 = load i32, ptr %slot273, align 8
  %v1760 = load i32, ptr %slot274, align 8
  %op1761 = or i32 %v1759, %v1760
  store i32 %op1761, ptr %slot275, align 8
  %v1762 = load i32, ptr %slot275, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcmoveslow373, label %bb_rcmovecheck373
bb_rcmovecheck373:
  %v1765 = load i64, ptr %slot264, align 8
  %op1766 = add i64 %v1765, 0
  store i64 %op1766, ptr %slot276, align 8
  %v1767 = load i64, ptr %slot276, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %ld1769 = load i64, ptr %p1768, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1769, ptr %slot277, align 8
  %v1770 = load i64, ptr %slot277, align 8
  %cmp1771 = icmp ne i64 %v1770, 0
  %cv1772 = zext i1 %cmp1771 to i32
  store i32 %cv1772, ptr %slot278, align 8
  %v1773 = load i32, ptr %slot278, align 8
  %cv1774 = zext i32 %v1773 to i64
  %cond1775 = icmp ne i64 %cv1774, 0
  br i1 %cond1775, label %bb_rcmoveheader381, label %bb_rcmovenext381
bb_rcmoveheader381:
  %v1776 = load i64, ptr %slot277, align 8
  %op1777 = sub i64 %v1776, 16
  store i64 %op1777, ptr %slot279, align 8
  %v1778 = load i64, ptr %slot277, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %rgep1780 = getelementptr i8, ptr %p1779, i64 -16
  %ld1781 = load i64, ptr %rgep1780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1781, ptr %slot280, align 8
  %v1782 = load i64, ptr %slot280, align 8
  %op1783 = and i64 %v1782, 5764607523034234881
  store i64 %op1783, ptr %slot281, align 8
  %v1784 = load i64, ptr %slot281, align 8
  %cmp1785 = icmp ne i64 %v1784, 0
  %cv1786 = zext i1 %cmp1785 to i32
  store i32 %cv1786, ptr %slot282, align 8
  %v1787 = load i32, ptr %slot282, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rcmoveslow373, label %bb_rcmovenext381
bb_rcmovenext381:
  %v1790 = load i64, ptr %slot264, align 8
  %op1791 = add i64 %v1790, 8
  store i64 %op1791, ptr %slot283, align 8
  %v1792 = load i64, ptr %slot283, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %ld1794 = load i64, ptr %p1793, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1794, ptr %slot284, align 8
  %v1795 = load i64, ptr %slot284, align 8
  %cmp1796 = icmp ne i64 %v1795, 0
  %cv1797 = zext i1 %cmp1796 to i32
  store i32 %cv1797, ptr %slot285, align 8
  %v1798 = load i32, ptr %slot285, align 8
  %cv1799 = zext i32 %v1798 to i64
  %cond1800 = icmp ne i64 %cv1799, 0
  br i1 %cond1800, label %bb_rcmoveheader389, label %bb_rcmovenext389
bb_rcmoveheader389:
  %v1801 = load i64, ptr %slot284, align 8
  %op1802 = sub i64 %v1801, 16
  store i64 %op1802, ptr %slot286, align 8
  %v1803 = load i64, ptr %slot284, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %rgep1805 = getelementptr i8, ptr %p1804, i64 -16
  %ld1806 = load i64, ptr %rgep1805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1806, ptr %slot287, align 8
  %v1807 = load i64, ptr %slot287, align 8
  %op1808 = and i64 %v1807, 5764607523034234881
  store i64 %op1808, ptr %slot288, align 8
  %v1809 = load i64, ptr %slot288, align 8
  %cmp1810 = icmp ne i64 %v1809, 0
  %cv1811 = zext i1 %cmp1810 to i32
  store i32 %cv1811, ptr %slot289, align 8
  %v1812 = load i32, ptr %slot289, align 8
  %cv1813 = zext i32 %v1812 to i64
  %cond1814 = icmp ne i64 %cv1813, 0
  br i1 %cond1814, label %bb_rcmoveslow373, label %bb_rcmovenext389
bb_rcmovenext389:
  %v1815 = load i64, ptr %slot264, align 8
  %v1816 = load i64, ptr %slot269, align 8
  %p1817 = inttoptr i64 %v1815 to ptr
  %p1818 = inttoptr i64 %v1816 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1818, ptr %p1817, i64 40, i1 false), !alias.scope !10000000
  %v1819 = load i64, ptr %slot264, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i64 0, ptr %p1820, align 8, !alias.scope !4, !noalias !3
  %v1821 = load i64, ptr %slot264, align 8
  %op1822 = add i64 %v1821, 8
  store i64 %op1822, ptr %slot290, align 8
  %v1823 = load i64, ptr %slot290, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  store i64 0, ptr %p1824, align 8, !alias.scope !4, !noalias !3
  %v1825 = load i64, ptr %slot264, align 8
  %op1826 = add i64 %v1825, 16
  store i64 %op1826, ptr %slot291, align 8
  %v1827 = load i64, ptr %slot291, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i64 0, ptr %p1828, align 8, !alias.scope !4, !noalias !3
  %v1829 = load i64, ptr %slot264, align 8
  %op1830 = add i64 %v1829, 24
  store i64 %op1830, ptr %slot292, align 8
  %v1831 = load i64, ptr %slot292, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i64 0, ptr %p1832, align 8, !alias.scope !4, !noalias !3
  %v1833 = load i64, ptr %slot264, align 8
  %op1834 = add i64 %v1833, 32
  store i64 %op1834, ptr %slot293, align 8
  %v1835 = load i64, ptr %slot293, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i64 0, ptr %p1836, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved373
bb_rcmoveslow373:
  %v1837 = load i64, ptr %slot29, align 8
  %v1838 = load i64, ptr %slot269, align 8
  %v1839 = load i64, ptr %slot264, align 8
  %v1840 = load i64, ptr %slot270, align 8
  %cv1841 = trunc i64 %v1840 to i32
  %call1842 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v1837, i64 %v1838, i64 %v1839, i32 %cv1841) nomerge, !dbg !130
  store i32 %call1842, ptr %slot294, align 8
  %v1843 = load i32, ptr %slot294, align 8
  %cv1844 = zext i32 %v1843 to i64
  %cond1845 = icmp ne i64 %cv1844, 0
  br i1 %cond1845, label %bb_rcsuccess400, label %bb_rcfailure400
bb_rcfailure400:
  %v1846 = load i64, ptr %slot29, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %call1848 = call i32 @myl_rc_take_failure(ptr %p1847) nomerge, !dbg !130
  store i32 %call1848, ptr %slot295, align 8
  %v1849 = load i64, ptr %slot1, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %v1851 = load i32, ptr %slot295, align 8
  %call1852 = call i32 @myl_qbe_rc_status(ptr %p1850, i32 %v1851) nomerge, !dbg !130
  store i32 %call1852, ptr %slot296, align 8
  br label %bb_failure
bb_rcsuccess400:
  br label %bb_rcmoved373
bb_rcmoved373:
  %v1853 = load i64, ptr %slot8, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i32 0, ptr %p1854, align 4, !alias.scope !3, !noalias !4
  %v1855 = load i64, ptr %slot12, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 2, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot11, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  store i32 1, ptr %p1858, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared370
bb_rcprivateloan370:
  %v1859 = load i64, ptr %slot17, align 8
  store i64 %v1859, ptr %slot297, align 8
  %v1860 = load i64, ptr %slot29, align 8
  %v1861 = load i64, ptr %slot297, align 8
  %v1862 = load i64, ptr %slot264, align 8
  %call1863 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_loan(i64 %v1860, i64 %v1861, i64 %v1862) nomerge, !dbg !130
  store i32 %call1863, ptr %slot298, align 8
  %v1864 = load i32, ptr %slot298, align 8
  %cv1865 = zext i32 %v1864 to i64
  %cond1866 = icmp ne i64 %cv1865, 0
  br i1 %cond1866, label %bb_rcsuccess408, label %bb_rcfailure408
bb_rcfailure408:
  %v1867 = load i64, ptr %slot29, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %call1869 = call i32 @myl_rc_take_failure(ptr %p1868) nomerge, !dbg !130
  store i32 %call1869, ptr %slot299, align 8
  %v1870 = load i64, ptr %slot1, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  %v1872 = load i32, ptr %slot299, align 8
  %call1873 = call i32 @myl_qbe_rc_status(ptr %p1871, i32 %v1872) nomerge, !dbg !130
  store i32 %call1873, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess408:
  %v1874 = load i64, ptr %slot12, align 8
  %p1875 = inttoptr i64 %v1874 to ptr
  store i32 2, ptr %p1875, align 4, !alias.scope !3, !noalias !4
  %v1876 = load i64, ptr %slot12, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i32 16, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot11, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 1, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot8, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %ld1882 = load i32, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1882, ptr %slot301, align 8
  %v1883 = load i32, ptr %slot301, align 8
  %cv1884 = zext i32 %v1883 to i64
  %cond1885 = icmp ne i64 %cv1884, 0
  br i1 %cond1885, label %bb_rcslotdrop416, label %bb_rcslotdone416
bb_rcslotdrop416:
  %v1886 = load i64, ptr %slot8, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 0, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot14, align 8
  store i64 %v1888, ptr %slot302, align 8
  %v1889 = load i64, ptr %slot9, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  %ld1891 = load i32, ptr %p1890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1891, ptr %slot303, align 8
  %v1892 = load i32, ptr %slot303, align 8
  %op1893 = and i32 %v1892, 28
  store i32 %op1893, ptr %slot304, align 8
  %v1894 = load i32, ptr %slot304, align 8
  %cv1895 = zext i32 %v1894 to i64
  %cond1896 = icmp ne i64 %cv1895, 0
  br i1 %cond1896, label %bb_rcslotrole416, label %bb_rcslotowner416
bb_rcslotrole416:
  %v1897 = load i64, ptr %slot29, align 8
  store i64 %v1897, ptr %slot305, align 8
  %v1898 = load i64, ptr %slot305, align 8
  %v1899 = load i64, ptr %slot302, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1898, i64 %v1899) nomerge, !dbg !130
  br label %bb_rcslotdone416
bb_rcslotowner416:
  %v1900 = load i64, ptr %slot29, align 8
  store i64 %v1900, ptr %slot306, align 8
  %v1901 = load i64, ptr %slot306, align 8
  %v1902 = load i64, ptr %slot302, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1901, i64 %v1902) nomerge, !dbg !130
  br label %bb_rcslotdone416
bb_rcslotdone416:
  br label %bb_rcprivateprepared370
bb_rcprivateprepared370:
  %v1903 = load i64, ptr %slot4, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  %ld1905 = load i32, ptr %p1904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1905, ptr %slot307, align 8
  %v1906 = load i32, ptr %slot307, align 8
  %cv1907 = zext i32 %v1906 to i64
  %cond1908 = icmp ne i64 %cv1907, 0
  br i1 %cond1908, label %bb_rcslotdrop426, label %bb_rcslotdone426
bb_rcslotdrop426:
  %v1909 = load i64, ptr %slot4, align 8
  %p1910 = inttoptr i64 %v1909 to ptr
  store i32 0, ptr %p1910, align 4, !alias.scope !3, !noalias !4
  %v1911 = load i64, ptr %slot20, align 8
  store i64 %v1911, ptr %slot308, align 8
  %v1912 = load i64, ptr %slot5, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  %ld1914 = load i32, ptr %p1913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1914, ptr %slot309, align 8
  %v1915 = load i32, ptr %slot309, align 8
  %op1916 = and i32 %v1915, 28
  store i32 %op1916, ptr %slot310, align 8
  %v1917 = load i32, ptr %slot310, align 8
  %cv1918 = zext i32 %v1917 to i64
  %cond1919 = icmp ne i64 %cv1918, 0
  br i1 %cond1919, label %bb_rcslotrole426, label %bb_rcslotowner426
bb_rcslotrole426:
  %v1920 = load i64, ptr %slot29, align 8
  store i64 %v1920, ptr %slot311, align 8
  %v1921 = load i64, ptr %slot311, align 8
  %v1922 = load i64, ptr %slot308, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1921, i64 %v1922) nomerge, !dbg !130
  br label %bb_rcslotdone426
bb_rcslotowner426:
  %v1923 = load i64, ptr %slot29, align 8
  store i64 %v1923, ptr %slot312, align 8
  %v1924 = load i64, ptr %slot312, align 8
  %v1925 = load i64, ptr %slot308, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1924, i64 %v1925) nomerge, !dbg !130
  br label %bb_rcslotdone426
bb_rcslotdone426:
  %v1926 = load i64, ptr %slot20, align 8
  store i64 %v1926, ptr %slot313, align 8
  %v1927 = load i64, ptr %slot17, align 8
  store i64 %v1927, ptr %slot314, align 8
  %v1928 = load i64, ptr %slot314, align 8
  %v1929 = load i64, ptr %slot313, align 8
  %p1930 = inttoptr i64 %v1928 to ptr
  %p1931 = inttoptr i64 %v1929 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1931, ptr %p1930, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1932 = load i64, ptr %slot11, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i32 0, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot5, align 8
  %p1935 = inttoptr i64 %v1934 to ptr
  store i32 2, ptr %p1935, align 4, !alias.scope !3, !noalias !4
  %v1936 = load i64, ptr %slot12, align 8
  %p1937 = inttoptr i64 %v1936 to ptr
  %ld1938 = load i32, ptr %p1937, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1938, ptr %slot315, align 8
  %v1939 = load i32, ptr %slot315, align 8
  %v1940 = load i64, ptr %slot5, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  store i32 %v1939, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  %v1942 = load i64, ptr %slot4, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i32 1, ptr %p1943, align 4, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot18, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %ld1946 = load i64, ptr %p1945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1946, ptr %slot316, align 8
  %v1947 = load i64, ptr %slot316, align 8
  %v1948 = load i64, ptr %slot22, align 8
  %p1949 = inttoptr i64 %v1948 to ptr
  store i64 %v1947, ptr %p1949, align 8, !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot22, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  %ld1952 = load i64, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1952, ptr %slot317, align 8
  %v1953 = load i64, ptr %slot8, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %ld1955 = load i32, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1955, ptr %slot318, align 8
  %v1956 = load i64, ptr %slot9, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  %ld1958 = load i32, ptr %p1957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1958, ptr %slot319, align 8
  %v1959 = load i32, ptr %slot319, align 8
  %op1960 = and i32 %v1959, 24
  store i32 %op1960, ptr %slot319, align 8
  %v1961 = load i32, ptr %slot319, align 8
  %cmp1962 = icmp eq i32 %v1961, 0
  %cv1963 = zext i1 %cmp1962 to i32
  store i32 %cv1963, ptr %slot320, align 8
  %v1964 = load i32, ptr %slot318, align 8
  %v1965 = load i32, ptr %slot320, align 8
  %op1966 = and i32 %v1964, %v1965
  store i32 %op1966, ptr %slot321, align 8
  %v1967 = load i32, ptr %slot321, align 8
  %cv1968 = zext i32 %v1967 to i64
  %cond1969 = icmp ne i64 %cv1968, 0
  br i1 %cond1969, label %bb_rcprivateown448, label %bb_rcprivateloan448
bb_rcprivateown448:
  %v1970 = load i64, ptr %slot17, align 8
  store i64 %v1970, ptr %slot322, align 8
  %v1971 = load i64, ptr %slot30, align 8
  store i64 %v1971, ptr %slot323, align 8
  %v1972 = load i64, ptr %slot317, align 8
  %v1973 = load i64, ptr %slot322, align 8
  %op1974 = sub i64 %v1972, %v1973
  store i64 %op1974, ptr %slot324, align 8
  %v1975 = load i64, ptr %slot322, align 8
  %v1976 = load i64, ptr %slot317, align 8
  %op1977 = sub i64 %v1975, %v1976
  store i64 %op1977, ptr %slot325, align 8
  %v1978 = load i64, ptr %slot324, align 8
  %cmp1979 = icmp ult i64 %v1978, 40
  %cv1980 = zext i1 %cmp1979 to i32
  store i32 %cv1980, ptr %slot326, align 8
  %v1981 = load i64, ptr %slot325, align 8
  %cmp1982 = icmp ult i64 %v1981, 40
  %cv1983 = zext i1 %cmp1982 to i32
  store i32 %cv1983, ptr %slot327, align 8
  %v1984 = load i32, ptr %slot326, align 8
  %v1985 = load i32, ptr %slot327, align 8
  %op1986 = or i32 %v1984, %v1985
  store i32 %op1986, ptr %slot328, align 8
  %v1987 = load i32, ptr %slot328, align 8
  %cv1988 = zext i32 %v1987 to i64
  %cond1989 = icmp ne i64 %cv1988, 0
  br i1 %cond1989, label %bb_rcmoveslow451, label %bb_rcmovecheck451
bb_rcmovecheck451:
  %v1990 = load i64, ptr %slot317, align 8
  %op1991 = add i64 %v1990, 0
  store i64 %op1991, ptr %slot329, align 8
  %v1992 = load i64, ptr %slot329, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %ld1994 = load i64, ptr %p1993, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1994, ptr %slot330, align 8
  %v1995 = load i64, ptr %slot330, align 8
  %cmp1996 = icmp ne i64 %v1995, 0
  %cv1997 = zext i1 %cmp1996 to i32
  store i32 %cv1997, ptr %slot331, align 8
  %v1998 = load i32, ptr %slot331, align 8
  %cv1999 = zext i32 %v1998 to i64
  %cond2000 = icmp ne i64 %cv1999, 0
  br i1 %cond2000, label %bb_rcmoveheader459, label %bb_rcmovenext459
bb_rcmoveheader459:
  %v2001 = load i64, ptr %slot330, align 8
  %op2002 = sub i64 %v2001, 16
  store i64 %op2002, ptr %slot332, align 8
  %v2003 = load i64, ptr %slot330, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %rgep2005 = getelementptr i8, ptr %p2004, i64 -16
  %ld2006 = load i64, ptr %rgep2005, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2006, ptr %slot333, align 8
  %v2007 = load i64, ptr %slot333, align 8
  %op2008 = and i64 %v2007, 5764607523034234881
  store i64 %op2008, ptr %slot334, align 8
  %v2009 = load i64, ptr %slot334, align 8
  %cmp2010 = icmp ne i64 %v2009, 0
  %cv2011 = zext i1 %cmp2010 to i32
  store i32 %cv2011, ptr %slot335, align 8
  %v2012 = load i32, ptr %slot335, align 8
  %cv2013 = zext i32 %v2012 to i64
  %cond2014 = icmp ne i64 %cv2013, 0
  br i1 %cond2014, label %bb_rcmoveslow451, label %bb_rcmovenext459
bb_rcmovenext459:
  %v2015 = load i64, ptr %slot317, align 8
  %op2016 = add i64 %v2015, 8
  store i64 %op2016, ptr %slot336, align 8
  %v2017 = load i64, ptr %slot336, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  %ld2019 = load i64, ptr %p2018, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2019, ptr %slot337, align 8
  %v2020 = load i64, ptr %slot337, align 8
  %cmp2021 = icmp ne i64 %v2020, 0
  %cv2022 = zext i1 %cmp2021 to i32
  store i32 %cv2022, ptr %slot338, align 8
  %v2023 = load i32, ptr %slot338, align 8
  %cv2024 = zext i32 %v2023 to i64
  %cond2025 = icmp ne i64 %cv2024, 0
  br i1 %cond2025, label %bb_rcmoveheader467, label %bb_rcmovenext467
bb_rcmoveheader467:
  %v2026 = load i64, ptr %slot337, align 8
  %op2027 = sub i64 %v2026, 16
  store i64 %op2027, ptr %slot339, align 8
  %v2028 = load i64, ptr %slot337, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %rgep2030 = getelementptr i8, ptr %p2029, i64 -16
  %ld2031 = load i64, ptr %rgep2030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2031, ptr %slot340, align 8
  %v2032 = load i64, ptr %slot340, align 8
  %op2033 = and i64 %v2032, 5764607523034234881
  store i64 %op2033, ptr %slot341, align 8
  %v2034 = load i64, ptr %slot341, align 8
  %cmp2035 = icmp ne i64 %v2034, 0
  %cv2036 = zext i1 %cmp2035 to i32
  store i32 %cv2036, ptr %slot342, align 8
  %v2037 = load i32, ptr %slot342, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcmoveslow451, label %bb_rcmovenext467
bb_rcmovenext467:
  %v2040 = load i64, ptr %slot317, align 8
  %v2041 = load i64, ptr %slot322, align 8
  %p2042 = inttoptr i64 %v2040 to ptr
  %p2043 = inttoptr i64 %v2041 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2043, ptr %p2042, i64 40, i1 false), !alias.scope !10000000
  %v2044 = load i64, ptr %slot317, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  store i64 0, ptr %p2045, align 8, !alias.scope !4, !noalias !3
  %v2046 = load i64, ptr %slot317, align 8
  %op2047 = add i64 %v2046, 8
  store i64 %op2047, ptr %slot343, align 8
  %v2048 = load i64, ptr %slot343, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i64 0, ptr %p2049, align 8, !alias.scope !4, !noalias !3
  %v2050 = load i64, ptr %slot317, align 8
  %op2051 = add i64 %v2050, 16
  store i64 %op2051, ptr %slot344, align 8
  %v2052 = load i64, ptr %slot344, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i64 0, ptr %p2053, align 8, !alias.scope !4, !noalias !3
  %v2054 = load i64, ptr %slot317, align 8
  %op2055 = add i64 %v2054, 24
  store i64 %op2055, ptr %slot345, align 8
  %v2056 = load i64, ptr %slot345, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i64 0, ptr %p2057, align 8, !alias.scope !4, !noalias !3
  %v2058 = load i64, ptr %slot317, align 8
  %op2059 = add i64 %v2058, 32
  store i64 %op2059, ptr %slot346, align 8
  %v2060 = load i64, ptr %slot346, align 8
  %p2061 = inttoptr i64 %v2060 to ptr
  store i64 0, ptr %p2061, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved451
bb_rcmoveslow451:
  %v2062 = load i64, ptr %slot29, align 8
  %v2063 = load i64, ptr %slot322, align 8
  %v2064 = load i64, ptr %slot317, align 8
  %v2065 = load i64, ptr %slot323, align 8
  %cv2066 = trunc i64 %v2065 to i32
  %call2067 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v2062, i64 %v2063, i64 %v2064, i32 %cv2066) nomerge, !dbg !132
  store i32 %call2067, ptr %slot347, align 8
  %v2068 = load i32, ptr %slot347, align 8
  %cv2069 = zext i32 %v2068 to i64
  %cond2070 = icmp ne i64 %cv2069, 0
  br i1 %cond2070, label %bb_rcsuccess478, label %bb_rcfailure478
bb_rcfailure478:
  %v2071 = load i64, ptr %slot29, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %call2073 = call i32 @myl_rc_take_failure(ptr %p2072) nomerge, !dbg !132
  store i32 %call2073, ptr %slot348, align 8
  %v2074 = load i64, ptr %slot1, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %v2076 = load i32, ptr %slot348, align 8
  %call2077 = call i32 @myl_qbe_rc_status(ptr %p2075, i32 %v2076) nomerge, !dbg !132
  store i32 %call2077, ptr %slot349, align 8
  br label %bb_failure
bb_rcsuccess478:
  br label %bb_rcmoved451
bb_rcmoved451:
  %v2078 = load i64, ptr %slot8, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i32 0, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot12, align 8
  %p2081 = inttoptr i64 %v2080 to ptr
  store i32 2, ptr %p2081, align 4, !alias.scope !3, !noalias !4
  %v2082 = load i64, ptr %slot11, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i32 1, ptr %p2083, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared448
bb_rcprivateloan448:
  %v2084 = load i64, ptr %slot17, align 8
  store i64 %v2084, ptr %slot350, align 8
  %v2085 = load i64, ptr %slot29, align 8
  %v2086 = load i64, ptr %slot350, align 8
  %v2087 = load i64, ptr %slot317, align 8
  %call2088 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_loan(i64 %v2085, i64 %v2086, i64 %v2087) nomerge, !dbg !132
  store i32 %call2088, ptr %slot351, align 8
  %v2089 = load i32, ptr %slot351, align 8
  %cv2090 = zext i32 %v2089 to i64
  %cond2091 = icmp ne i64 %cv2090, 0
  br i1 %cond2091, label %bb_rcsuccess486, label %bb_rcfailure486
bb_rcfailure486:
  %v2092 = load i64, ptr %slot29, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %call2094 = call i32 @myl_rc_take_failure(ptr %p2093) nomerge, !dbg !132
  store i32 %call2094, ptr %slot352, align 8
  %v2095 = load i64, ptr %slot1, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %v2097 = load i32, ptr %slot352, align 8
  %call2098 = call i32 @myl_qbe_rc_status(ptr %p2096, i32 %v2097) nomerge, !dbg !132
  store i32 %call2098, ptr %slot353, align 8
  br label %bb_failure
bb_rcsuccess486:
  %v2099 = load i64, ptr %slot12, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i32 2, ptr %p2100, align 4, !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot12, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  store i32 16, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  %v2103 = load i64, ptr %slot11, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  store i32 1, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  %v2105 = load i64, ptr %slot8, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  %ld2107 = load i32, ptr %p2106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2107, ptr %slot354, align 8
  %v2108 = load i32, ptr %slot354, align 8
  %cv2109 = zext i32 %v2108 to i64
  %cond2110 = icmp ne i64 %cv2109, 0
  br i1 %cond2110, label %bb_rcslotdrop494, label %bb_rcslotdone494
bb_rcslotdrop494:
  %v2111 = load i64, ptr %slot8, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i32 0, ptr %p2112, align 4, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot14, align 8
  store i64 %v2113, ptr %slot355, align 8
  %v2114 = load i64, ptr %slot9, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i32, ptr %p2115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2116, ptr %slot356, align 8
  %v2117 = load i32, ptr %slot356, align 8
  %op2118 = and i32 %v2117, 28
  store i32 %op2118, ptr %slot357, align 8
  %v2119 = load i32, ptr %slot357, align 8
  %cv2120 = zext i32 %v2119 to i64
  %cond2121 = icmp ne i64 %cv2120, 0
  br i1 %cond2121, label %bb_rcslotrole494, label %bb_rcslotowner494
bb_rcslotrole494:
  %v2122 = load i64, ptr %slot29, align 8
  store i64 %v2122, ptr %slot358, align 8
  %v2123 = load i64, ptr %slot358, align 8
  %v2124 = load i64, ptr %slot355, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2123, i64 %v2124) nomerge, !dbg !132
  br label %bb_rcslotdone494
bb_rcslotowner494:
  %v2125 = load i64, ptr %slot29, align 8
  store i64 %v2125, ptr %slot359, align 8
  %v2126 = load i64, ptr %slot359, align 8
  %v2127 = load i64, ptr %slot355, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2126, i64 %v2127) nomerge, !dbg !132
  br label %bb_rcslotdone494
bb_rcslotdone494:
  br label %bb_rcprivateprepared448
bb_rcprivateprepared448:
  %v2128 = load i64, ptr %slot4, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %ld2130 = load i32, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2130, ptr %slot360, align 8
  %v2131 = load i32, ptr %slot360, align 8
  %cv2132 = zext i32 %v2131 to i64
  %cond2133 = icmp ne i64 %cv2132, 0
  br i1 %cond2133, label %bb_rcslotdrop504, label %bb_rcslotdone504
bb_rcslotdrop504:
  %v2134 = load i64, ptr %slot4, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i32 0, ptr %p2135, align 4, !alias.scope !3, !noalias !4
  %v2136 = load i64, ptr %slot20, align 8
  store i64 %v2136, ptr %slot361, align 8
  %v2137 = load i64, ptr %slot5, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  %ld2139 = load i32, ptr %p2138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2139, ptr %slot362, align 8
  %v2140 = load i32, ptr %slot362, align 8
  %op2141 = and i32 %v2140, 28
  store i32 %op2141, ptr %slot363, align 8
  %v2142 = load i32, ptr %slot363, align 8
  %cv2143 = zext i32 %v2142 to i64
  %cond2144 = icmp ne i64 %cv2143, 0
  br i1 %cond2144, label %bb_rcslotrole504, label %bb_rcslotowner504
bb_rcslotrole504:
  %v2145 = load i64, ptr %slot29, align 8
  store i64 %v2145, ptr %slot364, align 8
  %v2146 = load i64, ptr %slot364, align 8
  %v2147 = load i64, ptr %slot361, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2146, i64 %v2147) nomerge, !dbg !132
  br label %bb_rcslotdone504
bb_rcslotowner504:
  %v2148 = load i64, ptr %slot29, align 8
  store i64 %v2148, ptr %slot365, align 8
  %v2149 = load i64, ptr %slot365, align 8
  %v2150 = load i64, ptr %slot361, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2149, i64 %v2150) nomerge, !dbg !132
  br label %bb_rcslotdone504
bb_rcslotdone504:
  %v2151 = load i64, ptr %slot20, align 8
  store i64 %v2151, ptr %slot366, align 8
  %v2152 = load i64, ptr %slot17, align 8
  store i64 %v2152, ptr %slot367, align 8
  %v2153 = load i64, ptr %slot367, align 8
  %v2154 = load i64, ptr %slot366, align 8
  %p2155 = inttoptr i64 %v2153 to ptr
  %p2156 = inttoptr i64 %v2154 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2156, ptr %p2155, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot11, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i32 0, ptr %p2158, align 4, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot5, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  store i32 2, ptr %p2160, align 4, !alias.scope !3, !noalias !4
  %v2161 = load i64, ptr %slot12, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  %ld2163 = load i32, ptr %p2162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2163, ptr %slot368, align 8
  %v2164 = load i32, ptr %slot368, align 8
  %v2165 = load i64, ptr %slot5, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  store i32 %v2164, ptr %p2166, align 4, !alias.scope !3, !noalias !4
  %v2167 = load i64, ptr %slot4, align 8
  %p2168 = inttoptr i64 %v2167 to ptr
  store i32 1, ptr %p2168, align 4, !alias.scope !3, !noalias !4
  %v2169 = load i64, ptr %slot20, align 8
  %v2170 = load i64, ptr %slot22, align 8
  %p2171 = inttoptr i64 %v2170 to ptr
  store i64 %v2169, ptr %p2171, align 8, !alias.scope !3, !noalias !4
  %v2172 = load i64, ptr %slot21, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  %ld2174 = load i64, ptr %p2173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2174, ptr %slot369, align 8
  %v2175 = load i64, ptr %slot369, align 8
  %v2176 = load i64, ptr %slot23, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  store i64 %v2175, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  %v2178 = load i64, ptr %slot22, align 8
  %p2179 = inttoptr i64 %v2178 to ptr
  %ld2180 = load i64, ptr %p2179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2180, ptr %slot370, align 8
  %v2181 = load i64, ptr %slot8, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  %ld2183 = load i32, ptr %p2182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2183, ptr %slot371, align 8
  %v2184 = load i64, ptr %slot9, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  %ld2186 = load i32, ptr %p2185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2186, ptr %slot372, align 8
  %v2187 = load i32, ptr %slot372, align 8
  %op2188 = and i32 %v2187, 24
  store i32 %op2188, ptr %slot372, align 8
  %v2189 = load i32, ptr %slot372, align 8
  %cmp2190 = icmp eq i32 %v2189, 0
  %cv2191 = zext i1 %cmp2190 to i32
  store i32 %cv2191, ptr %slot373, align 8
  %v2192 = load i32, ptr %slot371, align 8
  %v2193 = load i32, ptr %slot373, align 8
  %op2194 = and i32 %v2192, %v2193
  store i32 %op2194, ptr %slot374, align 8
  %v2195 = load i32, ptr %slot374, align 8
  %cv2196 = zext i32 %v2195 to i64
  %cond2197 = icmp ne i64 %cv2196, 0
  br i1 %cond2197, label %bb_rctake520, label %bb_rccopy520
bb_rctake520:
  %v2198 = load i64, ptr %slot17, align 8
  store i64 %v2198, ptr %slot375, align 8
  %v2199 = load i64, ptr %slot30, align 8
  store i64 %v2199, ptr %slot376, align 8
  %v2200 = load i64, ptr %slot370, align 8
  %v2201 = load i64, ptr %slot375, align 8
  %op2202 = sub i64 %v2200, %v2201
  store i64 %op2202, ptr %slot377, align 8
  %v2203 = load i64, ptr %slot375, align 8
  %v2204 = load i64, ptr %slot370, align 8
  %op2205 = sub i64 %v2203, %v2204
  store i64 %op2205, ptr %slot378, align 8
  %v2206 = load i64, ptr %slot377, align 8
  %cmp2207 = icmp ult i64 %v2206, 40
  %cv2208 = zext i1 %cmp2207 to i32
  store i32 %cv2208, ptr %slot379, align 8
  %v2209 = load i64, ptr %slot378, align 8
  %cmp2210 = icmp ult i64 %v2209, 40
  %cv2211 = zext i1 %cmp2210 to i32
  store i32 %cv2211, ptr %slot380, align 8
  %v2212 = load i32, ptr %slot379, align 8
  %v2213 = load i32, ptr %slot380, align 8
  %op2214 = or i32 %v2212, %v2213
  store i32 %op2214, ptr %slot381, align 8
  %v2215 = load i32, ptr %slot381, align 8
  %cv2216 = zext i32 %v2215 to i64
  %cond2217 = icmp ne i64 %cv2216, 0
  br i1 %cond2217, label %bb_rcmoveslow529, label %bb_rcmovecheck529
bb_rcmovecheck529:
  %v2218 = load i64, ptr %slot370, align 8
  %op2219 = add i64 %v2218, 0
  store i64 %op2219, ptr %slot382, align 8
  %v2220 = load i64, ptr %slot382, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  %ld2222 = load i64, ptr %p2221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2222, ptr %slot383, align 8
  %v2223 = load i64, ptr %slot383, align 8
  %cmp2224 = icmp ne i64 %v2223, 0
  %cv2225 = zext i1 %cmp2224 to i32
  store i32 %cv2225, ptr %slot384, align 8
  %v2226 = load i32, ptr %slot384, align 8
  %cv2227 = zext i32 %v2226 to i64
  %cond2228 = icmp ne i64 %cv2227, 0
  br i1 %cond2228, label %bb_rcmoveheader537, label %bb_rcmovenext537
bb_rcmoveheader537:
  %v2229 = load i64, ptr %slot383, align 8
  %op2230 = sub i64 %v2229, 16
  store i64 %op2230, ptr %slot385, align 8
  %v2231 = load i64, ptr %slot383, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %rgep2233 = getelementptr i8, ptr %p2232, i64 -16
  %ld2234 = load i64, ptr %rgep2233, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2234, ptr %slot386, align 8
  %v2235 = load i64, ptr %slot386, align 8
  %op2236 = and i64 %v2235, 5764607523034234881
  store i64 %op2236, ptr %slot387, align 8
  %v2237 = load i64, ptr %slot387, align 8
  %cmp2238 = icmp ne i64 %v2237, 0
  %cv2239 = zext i1 %cmp2238 to i32
  store i32 %cv2239, ptr %slot388, align 8
  %v2240 = load i32, ptr %slot388, align 8
  %cv2241 = zext i32 %v2240 to i64
  %cond2242 = icmp ne i64 %cv2241, 0
  br i1 %cond2242, label %bb_rcmoveslow529, label %bb_rcmovenext537
bb_rcmovenext537:
  %v2243 = load i64, ptr %slot370, align 8
  %op2244 = add i64 %v2243, 8
  store i64 %op2244, ptr %slot389, align 8
  %v2245 = load i64, ptr %slot389, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i64, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2247, ptr %slot390, align 8
  %v2248 = load i64, ptr %slot390, align 8
  %cmp2249 = icmp ne i64 %v2248, 0
  %cv2250 = zext i1 %cmp2249 to i32
  store i32 %cv2250, ptr %slot391, align 8
  %v2251 = load i32, ptr %slot391, align 8
  %cv2252 = zext i32 %v2251 to i64
  %cond2253 = icmp ne i64 %cv2252, 0
  br i1 %cond2253, label %bb_rcmoveheader545, label %bb_rcmovenext545
bb_rcmoveheader545:
  %v2254 = load i64, ptr %slot390, align 8
  %op2255 = sub i64 %v2254, 16
  store i64 %op2255, ptr %slot392, align 8
  %v2256 = load i64, ptr %slot390, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %rgep2258 = getelementptr i8, ptr %p2257, i64 -16
  %ld2259 = load i64, ptr %rgep2258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2259, ptr %slot393, align 8
  %v2260 = load i64, ptr %slot393, align 8
  %op2261 = and i64 %v2260, 5764607523034234881
  store i64 %op2261, ptr %slot394, align 8
  %v2262 = load i64, ptr %slot394, align 8
  %cmp2263 = icmp ne i64 %v2262, 0
  %cv2264 = zext i1 %cmp2263 to i32
  store i32 %cv2264, ptr %slot395, align 8
  %v2265 = load i32, ptr %slot395, align 8
  %cv2266 = zext i32 %v2265 to i64
  %cond2267 = icmp ne i64 %cv2266, 0
  br i1 %cond2267, label %bb_rcmoveslow529, label %bb_rcmovenext545
bb_rcmovenext545:
  %v2268 = load i64, ptr %slot370, align 8
  %v2269 = load i64, ptr %slot375, align 8
  %p2270 = inttoptr i64 %v2268 to ptr
  %p2271 = inttoptr i64 %v2269 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2271, ptr %p2270, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2272 = load i64, ptr %slot370, align 8
  %p2273 = inttoptr i64 %v2272 to ptr
  store i64 0, ptr %p2273, align 8, !alias.scope !3, !noalias !4
  %v2274 = load i64, ptr %slot370, align 8
  %op2275 = add i64 %v2274, 8
  store i64 %op2275, ptr %slot396, align 8
  %v2276 = load i64, ptr %slot396, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i64 0, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  %v2278 = load i64, ptr %slot370, align 8
  %op2279 = add i64 %v2278, 16
  store i64 %op2279, ptr %slot397, align 8
  %v2280 = load i64, ptr %slot397, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i64 0, ptr %p2281, align 8, !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot370, align 8
  %op2283 = add i64 %v2282, 24
  store i64 %op2283, ptr %slot398, align 8
  %v2284 = load i64, ptr %slot398, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i64 0, ptr %p2285, align 8, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot370, align 8
  %op2287 = add i64 %v2286, 32
  store i64 %op2287, ptr %slot399, align 8
  %v2288 = load i64, ptr %slot399, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i64 0, ptr %p2289, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved529
bb_rcmoveslow529:
  %v2290 = load i64, ptr %slot29, align 8
  %v2291 = load i64, ptr %slot375, align 8
  %v2292 = load i64, ptr %slot370, align 8
  %v2293 = load i64, ptr %slot376, align 8
  %cv2294 = trunc i64 %v2293 to i32
  %call2295 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v2290, i64 %v2291, i64 %v2292, i32 %cv2294) nomerge, !dbg !134
  store i32 %call2295, ptr %slot400, align 8
  %v2296 = load i32, ptr %slot400, align 8
  %cv2297 = zext i32 %v2296 to i64
  %cond2298 = icmp ne i64 %cv2297, 0
  br i1 %cond2298, label %bb_rcsuccess556, label %bb_rcfailure556
bb_rcfailure556:
  %v2299 = load i64, ptr %slot29, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %call2301 = call i32 @myl_rc_take_failure(ptr %p2300) nomerge, !dbg !134
  store i32 %call2301, ptr %slot401, align 8
  %v2302 = load i64, ptr %slot1, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %v2304 = load i32, ptr %slot401, align 8
  %call2305 = call i32 @myl_qbe_rc_status(ptr %p2303, i32 %v2304) nomerge, !dbg !134
  store i32 %call2305, ptr %slot402, align 8
  br label %bb_failure
bb_rcsuccess556:
  br label %bb_rcmoved529
bb_rcmoved529:
  %v2306 = load i64, ptr %slot8, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  store i32 0, ptr %p2307, align 4, !alias.scope !3, !noalias !4
  %v2308 = load i64, ptr %slot12, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  store i32 2, ptr %p2309, align 4, !alias.scope !3, !noalias !4
  %v2310 = load i64, ptr %slot11, align 8
  %p2311 = inttoptr i64 %v2310 to ptr
  store i32 1, ptr %p2311, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared520
bb_rccopy520:
  %v2312 = load i64, ptr %slot17, align 8
  store i64 %v2312, ptr %slot403, align 8
  %v2313 = load i64, ptr %slot30, align 8
  store i64 %v2313, ptr %slot404, align 8
  %v2314 = load i64, ptr %slot29, align 8
  %v2315 = load i64, ptr %slot403, align 8
  %v2316 = load i64, ptr %slot370, align 8
  %v2317 = load i64, ptr %slot404, align 8
  %cv2318 = trunc i64 %v2317 to i32
  %call2319 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64 %v2314, i64 %v2315, i64 %v2316, i32 %cv2318) nomerge, !dbg !134
  store i32 %call2319, ptr %slot405, align 8
  %v2320 = load i32, ptr %slot405, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcsuccess565, label %bb_rcfailure565
bb_rcfailure565:
  %v2323 = load i64, ptr %slot29, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  %call2325 = call i32 @myl_rc_take_failure(ptr %p2324) nomerge, !dbg !134
  store i32 %call2325, ptr %slot406, align 8
  %v2326 = load i64, ptr %slot1, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  %v2328 = load i32, ptr %slot406, align 8
  %call2329 = call i32 @myl_qbe_rc_status(ptr %p2327, i32 %v2328) nomerge, !dbg !134
  store i32 %call2329, ptr %slot407, align 8
  br label %bb_failure
bb_rcsuccess565:
  %v2330 = load i64, ptr %slot12, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  store i32 2, ptr %p2331, align 4, !alias.scope !3, !noalias !4
  %v2332 = load i64, ptr %slot11, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  store i32 1, ptr %p2333, align 4, !alias.scope !3, !noalias !4
  %v2334 = load i64, ptr %slot8, align 8
  %p2335 = inttoptr i64 %v2334 to ptr
  %ld2336 = load i32, ptr %p2335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2336, ptr %slot408, align 8
  %v2337 = load i32, ptr %slot408, align 8
  %cv2338 = zext i32 %v2337 to i64
  %cond2339 = icmp ne i64 %cv2338, 0
  br i1 %cond2339, label %bb_rcslotdrop572, label %bb_rcslotdone572
bb_rcslotdrop572:
  %v2340 = load i64, ptr %slot8, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  store i32 0, ptr %p2341, align 4, !alias.scope !3, !noalias !4
  %v2342 = load i64, ptr %slot14, align 8
  store i64 %v2342, ptr %slot409, align 8
  %v2343 = load i64, ptr %slot9, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %ld2345 = load i32, ptr %p2344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2345, ptr %slot410, align 8
  %v2346 = load i32, ptr %slot410, align 8
  %op2347 = and i32 %v2346, 28
  store i32 %op2347, ptr %slot411, align 8
  %v2348 = load i32, ptr %slot411, align 8
  %cv2349 = zext i32 %v2348 to i64
  %cond2350 = icmp ne i64 %cv2349, 0
  br i1 %cond2350, label %bb_rcslotrole572, label %bb_rcslotowner572
bb_rcslotrole572:
  %v2351 = load i64, ptr %slot29, align 8
  store i64 %v2351, ptr %slot412, align 8
  %v2352 = load i64, ptr %slot412, align 8
  %v2353 = load i64, ptr %slot409, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2352, i64 %v2353) nomerge, !dbg !134
  br label %bb_rcslotdone572
bb_rcslotowner572:
  %v2354 = load i64, ptr %slot29, align 8
  store i64 %v2354, ptr %slot413, align 8
  %v2355 = load i64, ptr %slot413, align 8
  %v2356 = load i64, ptr %slot409, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2355, i64 %v2356) nomerge, !dbg !134
  br label %bb_rcslotdone572
bb_rcslotdone572:
  br label %bb_rcprepared520
bb_rcprepared520:
  %v2357 = load i64, ptr %slot17, align 8
  store i64 %v2357, ptr %slot414, align 8
  %v2358 = load i64, ptr %slot24, align 8
  store i64 %v2358, ptr %slot415, align 8
  %v2359 = load i64, ptr %slot414, align 8
  %v2360 = load i64, ptr %slot415, align 8
  %p2361 = inttoptr i64 %v2359 to ptr
  %p2362 = inttoptr i64 %v2360 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2362, ptr %p2361, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2363 = load i64, ptr %slot11, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  store i32 0, ptr %p2364, align 4, !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot13, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  store i32 1, ptr %p2366, align 4, !alias.scope !3, !noalias !4
  %v2367 = load i64, ptr %slot30, align 8
  store i64 %v2367, ptr %slot416, align 8
  %v2368 = load i64, ptr %slot23, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  %ld2370 = load i64, ptr %p2369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2370, ptr %slot417, align 8
  %v2371 = load i64, ptr %slot417, align 8
  %v2372 = load i64, ptr %slot16, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i64 %v2371, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot16, align 8
  store i64 %v2374, ptr %slot418, align 8
  %v2375 = load i64, ptr %slot415, align 8
  %p2377 = inttoptr i64 %v2375 to ptr
  %gep2378 = getelementptr i8, ptr %p2377, i64 0
  %op2376 = ptrtoint ptr %gep2378 to i64
  store i64 %op2376, ptr %slot419, align 8
  %v2379 = load i64, ptr %slot17, align 8
  store i64 %v2379, ptr %slot420, align 8
  %v2380 = load i64, ptr %slot23, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  %ld2382 = load i64, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2382, ptr %slot421, align 8
  %v2383 = load i64, ptr %slot421, align 8
  %v2384 = load i64, ptr %slot16, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  store i64 %v2383, ptr %p2385, align 8, !alias.scope !3, !noalias !4
  %v2386 = load i64, ptr %slot16, align 8
  store i64 %v2386, ptr %slot422, align 8
  store i32 0, ptr %slot423, align 8
  %v2387 = load i64, ptr %slot10, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %ld2389 = load i32, ptr %p2388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2389, ptr %slot424, align 8
  %v2390 = load i32, ptr %slot424, align 8
  %op2391 = and i32 %v2390, 24
  store i32 %op2391, ptr %slot424, align 8
  %v2392 = load i32, ptr %slot424, align 8
  %cmp2393 = icmp eq i32 %v2392, 0
  %cv2394 = zext i1 %cmp2393 to i32
  store i32 %cv2394, ptr %slot425, align 8
  %v2395 = load i32, ptr %slot423, align 8
  %v2396 = load i32, ptr %slot425, align 8
  %op2397 = and i32 %v2395, %v2396
  store i32 %op2397, ptr %slot426, align 8
  %v2398 = load i32, ptr %slot426, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rctake591, label %bb_rccopy591
bb_rctake591:
  %v2401 = load i64, ptr %slot17, align 8
  store i64 %v2401, ptr %slot427, align 8
  %v2402 = load i64, ptr %slot30, align 8
  store i64 %v2402, ptr %slot428, align 8
  %v2403 = load i64, ptr %slot422, align 8
  %v2404 = load i64, ptr %slot427, align 8
  %op2405 = sub i64 %v2403, %v2404
  store i64 %op2405, ptr %slot429, align 8
  %v2406 = load i64, ptr %slot427, align 8
  %v2407 = load i64, ptr %slot422, align 8
  %op2408 = sub i64 %v2406, %v2407
  store i64 %op2408, ptr %slot430, align 8
  %v2409 = load i64, ptr %slot429, align 8
  %cmp2410 = icmp ult i64 %v2409, 8
  %cv2411 = zext i1 %cmp2410 to i32
  store i32 %cv2411, ptr %slot431, align 8
  %v2412 = load i64, ptr %slot430, align 8
  %cmp2413 = icmp ult i64 %v2412, 8
  %cv2414 = zext i1 %cmp2413 to i32
  store i32 %cv2414, ptr %slot432, align 8
  %v2415 = load i32, ptr %slot431, align 8
  %v2416 = load i32, ptr %slot432, align 8
  %op2417 = or i32 %v2415, %v2416
  store i32 %op2417, ptr %slot433, align 8
  %v2418 = load i32, ptr %slot433, align 8
  %cv2419 = zext i32 %v2418 to i64
  %cond2420 = icmp ne i64 %cv2419, 0
  br i1 %cond2420, label %bb_rcmoveslow600, label %bb_rcmovecheck600
bb_rcmovecheck600:
  %v2421 = load i64, ptr %slot422, align 8
  %p2423 = inttoptr i64 %v2421 to ptr
  %gep2424 = getelementptr i8, ptr %p2423, i64 0
  %op2422 = ptrtoint ptr %gep2424 to i64
  store i64 %op2422, ptr %slot434, align 8
  %v2425 = load i64, ptr %slot434, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %ld2427 = load i64, ptr %p2426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2427, ptr %slot435, align 8
  %v2428 = load i64, ptr %slot435, align 8
  %cmp2429 = icmp ne i64 %v2428, 0
  %cv2430 = zext i1 %cmp2429 to i32
  store i32 %cv2430, ptr %slot436, align 8
  %v2431 = load i32, ptr %slot436, align 8
  %cv2432 = zext i32 %v2431 to i64
  %cond2433 = icmp ne i64 %cv2432, 0
  br i1 %cond2433, label %bb_rcmoveheader608, label %bb_rcmovenext608
bb_rcmoveheader608:
  %v2434 = load i64, ptr %slot435, align 8
  %op2435 = sub i64 %v2434, 16
  store i64 %op2435, ptr %slot437, align 8
  %v2436 = load i64, ptr %slot435, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  %rgep2438 = getelementptr i8, ptr %p2437, i64 -16
  %ld2439 = load i64, ptr %rgep2438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2439, ptr %slot438, align 8
  %v2440 = load i64, ptr %slot438, align 8
  %op2441 = and i64 %v2440, 5764607523034234881
  store i64 %op2441, ptr %slot439, align 8
  %v2442 = load i64, ptr %slot439, align 8
  %cmp2443 = icmp ne i64 %v2442, 0
  %cv2444 = zext i1 %cmp2443 to i32
  store i32 %cv2444, ptr %slot440, align 8
  %v2445 = load i32, ptr %slot440, align 8
  %cv2446 = zext i32 %v2445 to i64
  %cond2447 = icmp ne i64 %cv2446, 0
  br i1 %cond2447, label %bb_rcmoveslow600, label %bb_rcmovenext608
bb_rcmovenext608:
  %v2448 = load i64, ptr %slot422, align 8
  %v2449 = load i64, ptr %slot427, align 8
  %p2450 = inttoptr i64 %v2448 to ptr
  %p2451 = inttoptr i64 %v2449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2451, ptr %p2450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2452 = load i64, ptr %slot422, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  store i64 0, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved600
bb_rcmoveslow600:
  %v2454 = load i64, ptr %slot29, align 8
  %v2455 = load i64, ptr %slot427, align 8
  %v2456 = load i64, ptr %slot422, align 8
  %v2457 = load i64, ptr %slot428, align 8
  %cv2458 = trunc i64 %v2457 to i32
  %call2459 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64 %v2454, i64 %v2455, i64 %v2456, i32 %cv2458) nomerge, !dbg !134
  store i32 %call2459, ptr %slot441, align 8
  %v2460 = load i32, ptr %slot441, align 8
  %cv2461 = zext i32 %v2460 to i64
  %cond2462 = icmp ne i64 %cv2461, 0
  br i1 %cond2462, label %bb_rcsuccess615, label %bb_rcfailure615
bb_rcfailure615:
  %v2463 = load i64, ptr %slot29, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %call2465 = call i32 @myl_rc_take_failure(ptr %p2464) nomerge, !dbg !134
  store i32 %call2465, ptr %slot442, align 8
  %v2466 = load i64, ptr %slot1, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %v2468 = load i32, ptr %slot442, align 8
  %call2469 = call i32 @myl_qbe_rc_status(ptr %p2467, i32 %v2468) nomerge, !dbg !134
  store i32 %call2469, ptr %slot443, align 8
  br label %bb_failure
bb_rcsuccess615:
  br label %bb_rcmoved600
bb_rcmoved600:
  %v2470 = load i64, ptr %slot12, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  store i32 2, ptr %p2471, align 4, !alias.scope !3, !noalias !4
  %v2472 = load i64, ptr %slot11, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  store i32 1, ptr %p2473, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared591
bb_rccopy591:
  %v2474 = load i64, ptr %slot17, align 8
  store i64 %v2474, ptr %slot444, align 8
  %v2475 = load i64, ptr %slot30, align 8
  store i64 %v2475, ptr %slot445, align 8
  %v2476 = load i64, ptr %slot422, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  %ld2478 = load i64, ptr %p2477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2478, ptr %slot446, align 8
  %v2479 = load i64, ptr %slot446, align 8
  %cmp2480 = icmp ne i64 %v2479, 0
  %cv2481 = zext i1 %cmp2480 to i32
  store i32 %cv2481, ptr %slot447, align 8
  %v2482 = load i32, ptr %slot447, align 8
  %cv2483 = zext i32 %v2482 to i64
  %cond2484 = icmp ne i64 %cv2483, 0
  br i1 %cond2484, label %bb_rcgnn624, label %bb_rcgplain624
bb_rcgnn624:
  %v2485 = load i64, ptr %slot446, align 8
  %op2486 = sub i64 %v2485, 16
  store i64 %op2486, ptr %slot448, align 8
  %v2487 = load i64, ptr %slot446, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %rgep2489 = getelementptr i8, ptr %p2488, i64 -16
  %ld2490 = load i64, ptr %rgep2489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2490, ptr %slot449, align 8
  %v2491 = load i64, ptr %slot449, align 8
  %op2492 = and i64 %v2491, 4611686018427387906
  store i64 %op2492, ptr %slot450, align 8
  %v2493 = load i64, ptr %slot450, align 8
  %cmp2494 = icmp ne i64 %v2493, 0
  %cv2495 = zext i1 %cmp2494 to i32
  store i32 %cv2495, ptr %slot451, align 8
  %v2496 = load i32, ptr %slot451, align 8
  %cv2497 = zext i32 %v2496 to i64
  %cond2498 = icmp ne i64 %cv2497, 0
  br i1 %cond2498, label %bb_rcgspecial624, label %bb_rcginc624
bb_rcginc624:
  %v2499 = load i64, ptr %slot446, align 8
  %op2500 = sub i64 %v2499, 32
  store i64 %op2500, ptr %slot452, align 8
  %v2501 = load i64, ptr %slot446, align 8
  %p2502 = inttoptr i64 %v2501 to ptr
  %rgep2503 = getelementptr i8, ptr %p2502, i64 -32
  %ld2504 = load i64, ptr %rgep2503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2504, ptr %slot453, align 8
  %v2505 = load i64, ptr %slot453, align 8
  %op2506 = add i64 %v2505, 1
  store i64 %op2506, ptr %slot454, align 8
  %v2507 = load i64, ptr %slot454, align 8
  %cmp2508 = icmp eq i64 %v2507, 0
  %cv2509 = zext i1 %cmp2508 to i32
  store i32 %cv2509, ptr %slot455, align 8
  %v2510 = load i32, ptr %slot455, align 8
  %cv2511 = zext i32 %v2510 to i64
  %cond2512 = icmp ne i64 %cv2511, 0
  br i1 %cond2512, label %bb_rcglimit624, label %bb_rcgcapacity624
bb_rcglimit624:
  %v2513 = load i64, ptr %slot1, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %call2515 = call i32 @myl_qbe_rc_status(ptr %p2514, i32 2) nomerge, !dbg !134
  store i32 %call2515, ptr %slot456, align 8
  br label %bb_failure
bb_rcgcapacity624:
  %v2516 = load i64, ptr %slot454, align 8
  %v2517 = load i64, ptr %slot446, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  %rgep2519 = getelementptr i8, ptr %p2518, i64 -32
  store i64 %v2516, ptr %rgep2519, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain624
bb_rcgspecial624:
  %v2520 = load i64, ptr %slot449, align 8
  %op2521 = and i64 %v2520, 4611686018427387904
  store i64 %op2521, ptr %slot457, align 8
  %v2522 = load i64, ptr %slot457, align 8
  %cmp2523 = icmp ne i64 %v2522, 0
  %cv2524 = zext i1 %cmp2523 to i32
  store i32 %cv2524, ptr %slot458, align 8
  %v2525 = load i32, ptr %slot458, align 8
  %cv2526 = zext i32 %v2525 to i64
  %cond2527 = icmp ne i64 %cv2526, 0
  br i1 %cond2527, label %bb_rcgslow624, label %bb_rcgplain624
bb_rcgslow624:
  %v2528 = load i64, ptr %slot29, align 8
  %v2529 = load i64, ptr %slot444, align 8
  %v2530 = load i64, ptr %slot422, align 8
  %v2531 = load i64, ptr %slot445, align 8
  %cv2532 = trunc i64 %v2531 to i32
  %call2533 = call i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64 %v2528, i64 %v2529, i64 %v2530, i32 %cv2532) nomerge, !dbg !134
  store i32 %call2533, ptr %slot459, align 8
  %v2534 = load i32, ptr %slot459, align 8
  %cv2535 = zext i32 %v2534 to i64
  %cond2536 = icmp ne i64 %cv2535, 0
  br i1 %cond2536, label %bb_rcsuccess638, label %bb_rcfailure638
bb_rcfailure638:
  %v2537 = load i64, ptr %slot29, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %call2539 = call i32 @myl_rc_take_failure(ptr %p2538) nomerge, !dbg !134
  store i32 %call2539, ptr %slot460, align 8
  %v2540 = load i64, ptr %slot1, align 8
  %p2541 = inttoptr i64 %v2540 to ptr
  %v2542 = load i32, ptr %slot460, align 8
  %call2543 = call i32 @myl_qbe_rc_status(ptr %p2541, i32 %v2542) nomerge, !dbg !134
  store i32 %call2543, ptr %slot461, align 8
  br label %bb_failure
bb_rcsuccess638:
  br label %bb_rcgdone624
bb_rcgplain624:
  %v2544 = load i64, ptr %slot446, align 8
  %v2545 = load i64, ptr %slot444, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  store i64 %v2544, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone624
bb_rcgdone624:
  %v2547 = load i64, ptr %slot12, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i32 2, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  %v2549 = load i64, ptr %slot11, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i32 1, ptr %p2550, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared591
bb_rcprepared591:
  %v2551 = load i64, ptr %slot17, align 8
  store i64 %v2551, ptr %slot462, align 8
  %v2552 = load i64, ptr %slot462, align 8
  %v2553 = load i64, ptr %slot420, align 8
  %p2554 = inttoptr i64 %v2552 to ptr
  %p2555 = inttoptr i64 %v2553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2555, ptr %p2554, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2556 = load i64, ptr %slot11, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  store i32 0, ptr %p2557, align 4, !alias.scope !3, !noalias !4
  %v2558 = load i64, ptr %slot12, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i32 2, ptr %p2559, align 4, !alias.scope !3, !noalias !4
  %v2560 = load i64, ptr %slot11, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  store i32 1, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  %v2562 = load i64, ptr %slot29, align 8
  store i64 %v2562, ptr %slot463, align 8
  %v2563 = load i64, ptr %slot419, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %ld2565 = load i64, ptr %p2564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2565, ptr %slot464, align 8
  %v2566 = load i64, ptr %slot464, align 8
  %cmp2567 = icmp ne i64 %v2566, 0
  %cv2568 = zext i1 %cmp2567 to i32
  store i32 %cv2568, ptr %slot465, align 8
  %v2569 = load i32, ptr %slot465, align 8
  %cv2570 = zext i32 %v2569 to i64
  %cond2571 = icmp ne i64 %cv2570, 0
  br i1 %cond2571, label %bb_rcgnn695, label %bb_rcgdone695
bb_rcgnn695:
  %v2572 = load i64, ptr %slot464, align 8
  %op2573 = sub i64 %v2572, 16
  store i64 %op2573, ptr %slot466, align 8
  %v2574 = load i64, ptr %slot464, align 8
  %p2575 = inttoptr i64 %v2574 to ptr
  %rgep2576 = getelementptr i8, ptr %p2575, i64 -16
  %ld2577 = load i64, ptr %rgep2576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2577, ptr %slot467, align 8
  %v2578 = load i64, ptr %slot467, align 8
  %op2579 = and i64 %v2578, 4611686018427387906
  store i64 %op2579, ptr %slot468, align 8
  %v2580 = load i64, ptr %slot468, align 8
  %cmp2581 = icmp ne i64 %v2580, 0
  %cv2582 = zext i1 %cmp2581 to i32
  store i32 %cv2582, ptr %slot469, align 8
  %v2583 = load i32, ptr %slot469, align 8
  %cv2584 = zext i32 %v2583 to i64
  %cond2585 = icmp ne i64 %cv2584, 0
  br i1 %cond2585, label %bb_rcgclear695, label %bb_rcgcounted695
bb_rcgcounted695:
  %v2586 = load i64, ptr %slot464, align 8
  %op2587 = sub i64 %v2586, 32
  store i64 %op2587, ptr %slot470, align 8
  %v2588 = load i64, ptr %slot464, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %rgep2590 = getelementptr i8, ptr %p2589, i64 -32
  %ld2591 = load i64, ptr %rgep2590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2591, ptr %slot471, align 8
  %v2592 = load i64, ptr %slot471, align 8
  %op2593 = sub i64 %v2592, 1
  store i64 %op2593, ptr %slot472, align 8
  %v2594 = load i64, ptr %slot472, align 8
  %cmp2595 = icmp eq i64 %v2594, 0
  %cv2596 = zext i1 %cmp2595 to i32
  store i32 %cv2596, ptr %slot473, align 8
  %v2597 = load i32, ptr %slot473, align 8
  %cv2598 = zext i32 %v2597 to i64
  %cond2599 = icmp ne i64 %cv2598, 0
  br i1 %cond2599, label %bb_rcglast695, label %bb_rcgdec695
bb_rcglast695:
  %v2600 = load i64, ptr %slot464, align 8
  %op2601 = sub i64 %v2600, 24
  store i64 %op2601, ptr %slot474, align 8
  %v2602 = load i64, ptr %slot464, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  %rgep2604 = getelementptr i8, ptr %p2603, i64 -24
  %ld2605 = load i64, ptr %rgep2604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2605, ptr %slot475, align 8
  %v2606 = load i64, ptr %slot475, align 8
  %cmp2607 = icmp ne i64 %v2606, 0
  %cv2608 = zext i1 %cmp2607 to i32
  store i32 %cv2608, ptr %slot476, align 8
  %v2609 = load i32, ptr %slot476, align 8
  %cv2610 = zext i32 %v2609 to i64
  %cond2611 = icmp ne i64 %cv2610, 0
  br i1 %cond2611, label %bb_rcgdec695, label %bb_rcgslow695
bb_rcgslow695:
  %v2612 = load i64, ptr %slot463, align 8
  %v2613 = load i64, ptr %slot419, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v2612, i64 %v2613) nomerge, !dbg !134
  br label %bb_rcgdone695
bb_rcgdec695:
  %v2614 = load i64, ptr %slot472, align 8
  %v2615 = load i64, ptr %slot464, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  %rgep2617 = getelementptr i8, ptr %p2616, i64 -32
  store i64 %v2614, ptr %rgep2617, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear695
bb_rcgclear695:
  %v2618 = load i64, ptr %slot419, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  store i64 0, ptr %p2619, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone695
bb_rcgdone695:
  %v2620 = load i64, ptr %slot420, align 8
  %v2621 = load i64, ptr %slot419, align 8
  %p2622 = inttoptr i64 %v2620 to ptr
  %p2623 = inttoptr i64 %v2621 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2623, ptr %p2622, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot11, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i32 0, ptr %p2625, align 4, !alias.scope !3, !noalias !4
  %v2626 = load i64, ptr %slot415, align 8
  %v2627 = load i64, ptr %slot22, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  store i64 %v2626, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot22, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  %ld2631 = load i64, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2631, ptr %slot477, align 8
  %v2632 = load i64, ptr %slot17, align 8
  store i64 %v2632, ptr %slot478, align 8
  %v2633 = load i64, ptr %slot477, align 8
  %v2634 = load i64, ptr %slot478, align 8
  %p2635 = inttoptr i64 %v2633 to ptr
  %p2636 = inttoptr i64 %v2634 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2636, ptr %p2635, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot12, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 2, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot11, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  store i32 1, ptr %p2640, align 4, !alias.scope !3, !noalias !4
  %v2641 = load i64, ptr %slot8, align 8
  %p2642 = inttoptr i64 %v2641 to ptr
  %ld2643 = load i32, ptr %p2642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2643, ptr %slot479, align 8
  %v2644 = load i32, ptr %slot479, align 8
  %cv2645 = zext i32 %v2644 to i64
  %cond2646 = icmp ne i64 %cv2645, 0
  br i1 %cond2646, label %bb_rcslotdrop706, label %bb_rcslotdone706
bb_rcslotdrop706:
  %v2647 = load i64, ptr %slot8, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  store i32 0, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  %v2649 = load i64, ptr %slot14, align 8
  store i64 %v2649, ptr %slot480, align 8
  %v2650 = load i64, ptr %slot9, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  %ld2652 = load i32, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2652, ptr %slot481, align 8
  %v2653 = load i32, ptr %slot481, align 8
  %op2654 = and i32 %v2653, 28
  store i32 %op2654, ptr %slot482, align 8
  %v2655 = load i32, ptr %slot482, align 8
  %cv2656 = zext i32 %v2655 to i64
  %cond2657 = icmp ne i64 %cv2656, 0
  br i1 %cond2657, label %bb_rcslotrole706, label %bb_rcslotowner706
bb_rcslotrole706:
  %v2658 = load i64, ptr %slot29, align 8
  store i64 %v2658, ptr %slot483, align 8
  %v2659 = load i64, ptr %slot483, align 8
  %v2660 = load i64, ptr %slot480, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2659, i64 %v2660) nomerge, !dbg !134
  br label %bb_rcslotdone706
bb_rcslotowner706:
  %v2661 = load i64, ptr %slot29, align 8
  store i64 %v2661, ptr %slot484, align 8
  %v2662 = load i64, ptr %slot484, align 8
  %v2663 = load i64, ptr %slot480, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2662, i64 %v2663) nomerge, !dbg !134
  br label %bb_rcslotdone706
bb_rcslotdone706:
  %v2664 = load i64, ptr %slot14, align 8
  store i64 %v2664, ptr %slot485, align 8
  %v2665 = load i64, ptr %slot17, align 8
  store i64 %v2665, ptr %slot486, align 8
  %v2666 = load i64, ptr %slot486, align 8
  %v2667 = load i64, ptr %slot485, align 8
  %p2668 = inttoptr i64 %v2666 to ptr
  %p2669 = inttoptr i64 %v2667 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2669, ptr %p2668, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2670 = load i64, ptr %slot9, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i32 2, ptr %p2671, align 4, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot12, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  %ld2674 = load i32, ptr %p2673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2674, ptr %slot487, align 8
  %v2675 = load i32, ptr %slot487, align 8
  %v2676 = load i64, ptr %slot9, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 %v2675, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot11, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  store i32 0, ptr %p2679, align 4, !alias.scope !3, !noalias !4
  %v2680 = load i64, ptr %slot8, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i32 1, ptr %p2681, align 4, !alias.scope !3, !noalias !4
  %v2682 = load i64, ptr %slot485, align 8
  %v2683 = load i64, ptr %slot22, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i64 %v2682, ptr %p2684, align 8, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot22, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i64, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2687, ptr %slot488, align 8
  %v2688 = load i64, ptr %slot8, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %ld2690 = load i32, ptr %p2689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2690, ptr %slot489, align 8
  %v2691 = load i64, ptr %slot9, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %ld2693 = load i32, ptr %p2692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2693, ptr %slot490, align 8
  %v2694 = load i32, ptr %slot490, align 8
  %op2695 = and i32 %v2694, 24
  store i32 %op2695, ptr %slot490, align 8
  %v2696 = load i32, ptr %slot490, align 8
  %cmp2697 = icmp eq i32 %v2696, 0
  %cv2698 = zext i1 %cmp2697 to i32
  store i32 %cv2698, ptr %slot491, align 8
  %v2699 = load i32, ptr %slot489, align 8
  %v2700 = load i32, ptr %slot491, align 8
  %op2701 = and i32 %v2699, %v2700
  store i32 %op2701, ptr %slot492, align 8
  %v2702 = load i32, ptr %slot492, align 8
  %cv2703 = zext i32 %v2702 to i64
  %cond2704 = icmp ne i64 %cv2703, 0
  br i1 %cond2704, label %bb_rctake759, label %bb_rccopy759
bb_rctake759:
  %v2705 = load i64, ptr %slot17, align 8
  store i64 %v2705, ptr %slot493, align 8
  %v2706 = load i64, ptr %slot30, align 8
  store i64 %v2706, ptr %slot494, align 8
  %v2707 = load i64, ptr %slot488, align 8
  %v2708 = load i64, ptr %slot493, align 8
  %op2709 = sub i64 %v2707, %v2708
  store i64 %op2709, ptr %slot495, align 8
  %v2710 = load i64, ptr %slot493, align 8
  %v2711 = load i64, ptr %slot488, align 8
  %op2712 = sub i64 %v2710, %v2711
  store i64 %op2712, ptr %slot496, align 8
  %v2713 = load i64, ptr %slot495, align 8
  %cmp2714 = icmp ult i64 %v2713, 40
  %cv2715 = zext i1 %cmp2714 to i32
  store i32 %cv2715, ptr %slot497, align 8
  %v2716 = load i64, ptr %slot496, align 8
  %cmp2717 = icmp ult i64 %v2716, 40
  %cv2718 = zext i1 %cmp2717 to i32
  store i32 %cv2718, ptr %slot498, align 8
  %v2719 = load i32, ptr %slot497, align 8
  %v2720 = load i32, ptr %slot498, align 8
  %op2721 = or i32 %v2719, %v2720
  store i32 %op2721, ptr %slot499, align 8
  %v2722 = load i32, ptr %slot499, align 8
  %cv2723 = zext i32 %v2722 to i64
  %cond2724 = icmp ne i64 %cv2723, 0
  br i1 %cond2724, label %bb_rcmoveslow768, label %bb_rcmovecheck768
bb_rcmovecheck768:
  %v2725 = load i64, ptr %slot488, align 8
  %op2726 = add i64 %v2725, 0
  store i64 %op2726, ptr %slot500, align 8
  %v2727 = load i64, ptr %slot500, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i64, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2729, ptr %slot501, align 8
  %v2730 = load i64, ptr %slot501, align 8
  %cmp2731 = icmp ne i64 %v2730, 0
  %cv2732 = zext i1 %cmp2731 to i32
  store i32 %cv2732, ptr %slot502, align 8
  %v2733 = load i32, ptr %slot502, align 8
  %cv2734 = zext i32 %v2733 to i64
  %cond2735 = icmp ne i64 %cv2734, 0
  br i1 %cond2735, label %bb_rcmoveheader776, label %bb_rcmovenext776
bb_rcmoveheader776:
  %v2736 = load i64, ptr %slot501, align 8
  %op2737 = sub i64 %v2736, 16
  store i64 %op2737, ptr %slot503, align 8
  %v2738 = load i64, ptr %slot501, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %rgep2740 = getelementptr i8, ptr %p2739, i64 -16
  %ld2741 = load i64, ptr %rgep2740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2741, ptr %slot504, align 8
  %v2742 = load i64, ptr %slot504, align 8
  %op2743 = and i64 %v2742, 5764607523034234881
  store i64 %op2743, ptr %slot505, align 8
  %v2744 = load i64, ptr %slot505, align 8
  %cmp2745 = icmp ne i64 %v2744, 0
  %cv2746 = zext i1 %cmp2745 to i32
  store i32 %cv2746, ptr %slot506, align 8
  %v2747 = load i32, ptr %slot506, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcmoveslow768, label %bb_rcmovenext776
bb_rcmovenext776:
  %v2750 = load i64, ptr %slot488, align 8
  %op2751 = add i64 %v2750, 8
  store i64 %op2751, ptr %slot507, align 8
  %v2752 = load i64, ptr %slot507, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %ld2754 = load i64, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2754, ptr %slot508, align 8
  %v2755 = load i64, ptr %slot508, align 8
  %cmp2756 = icmp ne i64 %v2755, 0
  %cv2757 = zext i1 %cmp2756 to i32
  store i32 %cv2757, ptr %slot509, align 8
  %v2758 = load i32, ptr %slot509, align 8
  %cv2759 = zext i32 %v2758 to i64
  %cond2760 = icmp ne i64 %cv2759, 0
  br i1 %cond2760, label %bb_rcmoveheader784, label %bb_rcmovenext784
bb_rcmoveheader784:
  %v2761 = load i64, ptr %slot508, align 8
  %op2762 = sub i64 %v2761, 16
  store i64 %op2762, ptr %slot510, align 8
  %v2763 = load i64, ptr %slot508, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %rgep2765 = getelementptr i8, ptr %p2764, i64 -16
  %ld2766 = load i64, ptr %rgep2765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2766, ptr %slot511, align 8
  %v2767 = load i64, ptr %slot511, align 8
  %op2768 = and i64 %v2767, 5764607523034234881
  store i64 %op2768, ptr %slot512, align 8
  %v2769 = load i64, ptr %slot512, align 8
  %cmp2770 = icmp ne i64 %v2769, 0
  %cv2771 = zext i1 %cmp2770 to i32
  store i32 %cv2771, ptr %slot513, align 8
  %v2772 = load i32, ptr %slot513, align 8
  %cv2773 = zext i32 %v2772 to i64
  %cond2774 = icmp ne i64 %cv2773, 0
  br i1 %cond2774, label %bb_rcmoveslow768, label %bb_rcmovenext784
bb_rcmovenext784:
  %v2775 = load i64, ptr %slot488, align 8
  %v2776 = load i64, ptr %slot493, align 8
  %p2777 = inttoptr i64 %v2775 to ptr
  %p2778 = inttoptr i64 %v2776 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2778, ptr %p2777, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot488, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  store i64 0, ptr %p2780, align 8, !alias.scope !3, !noalias !4
  %v2781 = load i64, ptr %slot488, align 8
  %op2782 = add i64 %v2781, 8
  store i64 %op2782, ptr %slot514, align 8
  %v2783 = load i64, ptr %slot514, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i64 0, ptr %p2784, align 8, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot488, align 8
  %op2786 = add i64 %v2785, 16
  store i64 %op2786, ptr %slot515, align 8
  %v2787 = load i64, ptr %slot515, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  store i64 0, ptr %p2788, align 8, !alias.scope !3, !noalias !4
  %v2789 = load i64, ptr %slot488, align 8
  %op2790 = add i64 %v2789, 24
  store i64 %op2790, ptr %slot516, align 8
  %v2791 = load i64, ptr %slot516, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  store i64 0, ptr %p2792, align 8, !alias.scope !3, !noalias !4
  %v2793 = load i64, ptr %slot488, align 8
  %op2794 = add i64 %v2793, 32
  store i64 %op2794, ptr %slot517, align 8
  %v2795 = load i64, ptr %slot517, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  store i64 0, ptr %p2796, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved768
bb_rcmoveslow768:
  %v2797 = load i64, ptr %slot29, align 8
  %v2798 = load i64, ptr %slot493, align 8
  %v2799 = load i64, ptr %slot488, align 8
  %v2800 = load i64, ptr %slot494, align 8
  %cv2801 = trunc i64 %v2800 to i32
  %call2802 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v2797, i64 %v2798, i64 %v2799, i32 %cv2801) nomerge, !dbg !136
  store i32 %call2802, ptr %slot518, align 8
  %v2803 = load i32, ptr %slot518, align 8
  %cv2804 = zext i32 %v2803 to i64
  %cond2805 = icmp ne i64 %cv2804, 0
  br i1 %cond2805, label %bb_rcsuccess795, label %bb_rcfailure795
bb_rcfailure795:
  %v2806 = load i64, ptr %slot29, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %call2808 = call i32 @myl_rc_take_failure(ptr %p2807) nomerge, !dbg !136
  store i32 %call2808, ptr %slot519, align 8
  %v2809 = load i64, ptr %slot1, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  %v2811 = load i32, ptr %slot519, align 8
  %call2812 = call i32 @myl_qbe_rc_status(ptr %p2810, i32 %v2811) nomerge, !dbg !136
  store i32 %call2812, ptr %slot520, align 8
  br label %bb_failure
bb_rcsuccess795:
  br label %bb_rcmoved768
bb_rcmoved768:
  %v2813 = load i64, ptr %slot8, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  store i32 0, ptr %p2814, align 4, !alias.scope !3, !noalias !4
  %v2815 = load i64, ptr %slot12, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  store i32 2, ptr %p2816, align 4, !alias.scope !3, !noalias !4
  %v2817 = load i64, ptr %slot11, align 8
  %p2818 = inttoptr i64 %v2817 to ptr
  store i32 1, ptr %p2818, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared759
bb_rccopy759:
  %v2819 = load i64, ptr %slot17, align 8
  store i64 %v2819, ptr %slot521, align 8
  %v2820 = load i64, ptr %slot30, align 8
  store i64 %v2820, ptr %slot522, align 8
  %v2821 = load i64, ptr %slot29, align 8
  %v2822 = load i64, ptr %slot521, align 8
  %v2823 = load i64, ptr %slot488, align 8
  %v2824 = load i64, ptr %slot522, align 8
  %cv2825 = trunc i64 %v2824 to i32
  %call2826 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64 %v2821, i64 %v2822, i64 %v2823, i32 %cv2825) nomerge, !dbg !136
  store i32 %call2826, ptr %slot523, align 8
  %v2827 = load i32, ptr %slot523, align 8
  %cv2828 = zext i32 %v2827 to i64
  %cond2829 = icmp ne i64 %cv2828, 0
  br i1 %cond2829, label %bb_rcsuccess804, label %bb_rcfailure804
bb_rcfailure804:
  %v2830 = load i64, ptr %slot29, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %call2832 = call i32 @myl_rc_take_failure(ptr %p2831) nomerge, !dbg !136
  store i32 %call2832, ptr %slot524, align 8
  %v2833 = load i64, ptr %slot1, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  %v2835 = load i32, ptr %slot524, align 8
  %call2836 = call i32 @myl_qbe_rc_status(ptr %p2834, i32 %v2835) nomerge, !dbg !136
  store i32 %call2836, ptr %slot525, align 8
  br label %bb_failure
bb_rcsuccess804:
  %v2837 = load i64, ptr %slot12, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  store i32 2, ptr %p2838, align 4, !alias.scope !3, !noalias !4
  %v2839 = load i64, ptr %slot11, align 8
  %p2840 = inttoptr i64 %v2839 to ptr
  store i32 1, ptr %p2840, align 4, !alias.scope !3, !noalias !4
  %v2841 = load i64, ptr %slot8, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  %ld2843 = load i32, ptr %p2842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2843, ptr %slot526, align 8
  %v2844 = load i32, ptr %slot526, align 8
  %cv2845 = zext i32 %v2844 to i64
  %cond2846 = icmp ne i64 %cv2845, 0
  br i1 %cond2846, label %bb_rcslotdrop811, label %bb_rcslotdone811
bb_rcslotdrop811:
  %v2847 = load i64, ptr %slot8, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  store i32 0, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  %v2849 = load i64, ptr %slot14, align 8
  store i64 %v2849, ptr %slot527, align 8
  %v2850 = load i64, ptr %slot9, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %ld2852 = load i32, ptr %p2851, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2852, ptr %slot528, align 8
  %v2853 = load i32, ptr %slot528, align 8
  %op2854 = and i32 %v2853, 28
  store i32 %op2854, ptr %slot529, align 8
  %v2855 = load i32, ptr %slot529, align 8
  %cv2856 = zext i32 %v2855 to i64
  %cond2857 = icmp ne i64 %cv2856, 0
  br i1 %cond2857, label %bb_rcslotrole811, label %bb_rcslotowner811
bb_rcslotrole811:
  %v2858 = load i64, ptr %slot29, align 8
  store i64 %v2858, ptr %slot530, align 8
  %v2859 = load i64, ptr %slot530, align 8
  %v2860 = load i64, ptr %slot527, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2859, i64 %v2860) nomerge, !dbg !136
  br label %bb_rcslotdone811
bb_rcslotowner811:
  %v2861 = load i64, ptr %slot29, align 8
  store i64 %v2861, ptr %slot531, align 8
  %v2862 = load i64, ptr %slot531, align 8
  %v2863 = load i64, ptr %slot527, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2862, i64 %v2863) nomerge, !dbg !136
  br label %bb_rcslotdone811
bb_rcslotdone811:
  br label %bb_rcprepared759
bb_rcprepared759:
  %v2864 = load i64, ptr %slot18, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  %ld2866 = load i64, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2866, ptr %slot532, align 8
  %v2867 = load i64, ptr %slot29, align 8
  store i64 %v2867, ptr %slot533, align 8
  %v2868 = load i64, ptr %slot533, align 8
  %v2869 = load i64, ptr %slot532, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2868, i64 %v2869) nomerge, !dbg !136
  %v2870 = load i64, ptr %slot17, align 8
  store i64 %v2870, ptr %slot534, align 8
  %v2871 = load i64, ptr %slot534, align 8
  %v2872 = load i64, ptr %slot532, align 8
  %p2873 = inttoptr i64 %v2871 to ptr
  %p2874 = inttoptr i64 %v2872 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2874, ptr %p2873, i64 40, i1 false), !alias.scope !10000000
  %v2875 = load i64, ptr %slot11, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  store i32 0, ptr %p2876, align 4, !alias.scope !3, !noalias !4
  %v2877 = load i64, ptr %slot6, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i32, ptr %p2878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2879, ptr %slot535, align 8
  %v2880 = load i32, ptr %slot535, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcslotdrop824, label %bb_rcslotdone824
bb_rcslotdrop824:
  %v2883 = load i64, ptr %slot6, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i32 0, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot21, align 8
  store i64 %v2885, ptr %slot536, align 8
  %v2886 = load i64, ptr %slot7, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %ld2888 = load i32, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2888, ptr %slot537, align 8
  %v2889 = load i32, ptr %slot537, align 8
  %op2890 = and i32 %v2889, 28
  store i32 %op2890, ptr %slot538, align 8
  %v2891 = load i32, ptr %slot538, align 8
  %cv2892 = zext i32 %v2891 to i64
  %cond2893 = icmp ne i64 %cv2892, 0
  br i1 %cond2893, label %bb_rcslotrole824, label %bb_rcslotowner824
bb_rcslotrole824:
  %v2894 = load i64, ptr %slot29, align 8
  store i64 %v2894, ptr %slot539, align 8
  %v2895 = load i64, ptr %slot536, align 8
  %p2896 = inttoptr i64 %v2895 to ptr
  %ld2897 = load i64, ptr %p2896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2897, ptr %slot540, align 8
  %v2898 = load i64, ptr %slot540, align 8
  %cmp2899 = icmp ne i64 %v2898, 0
  %cv2900 = zext i1 %cmp2899 to i32
  store i32 %cv2900, ptr %slot541, align 8
  %v2901 = load i32, ptr %slot541, align 8
  %cv2902 = zext i32 %v2901 to i64
  %cond2903 = icmp ne i64 %cv2902, 0
  br i1 %cond2903, label %bb_rcgnn840, label %bb_rcgdone840
bb_rcgnn840:
  %v2904 = load i64, ptr %slot540, align 8
  %op2905 = sub i64 %v2904, 16
  store i64 %op2905, ptr %slot542, align 8
  %v2906 = load i64, ptr %slot540, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %rgep2908 = getelementptr i8, ptr %p2907, i64 -16
  %ld2909 = load i64, ptr %rgep2908, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2909, ptr %slot543, align 8
  %v2910 = load i64, ptr %slot543, align 8
  %op2911 = and i64 %v2910, 4611686018427387906
  store i64 %op2911, ptr %slot544, align 8
  %v2912 = load i64, ptr %slot544, align 8
  %cmp2913 = icmp ne i64 %v2912, 0
  %cv2914 = zext i1 %cmp2913 to i32
  store i32 %cv2914, ptr %slot545, align 8
  %v2915 = load i32, ptr %slot545, align 8
  %cv2916 = zext i32 %v2915 to i64
  %cond2917 = icmp ne i64 %cv2916, 0
  br i1 %cond2917, label %bb_rcgclear840, label %bb_rcgcounted840
bb_rcgcounted840:
  %v2918 = load i64, ptr %slot540, align 8
  %op2919 = sub i64 %v2918, 24
  store i64 %op2919, ptr %slot546, align 8
  %v2920 = load i64, ptr %slot540, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  %rgep2922 = getelementptr i8, ptr %p2921, i64 -24
  %ld2923 = load i64, ptr %rgep2922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2923, ptr %slot547, align 8
  %v2924 = load i64, ptr %slot547, align 8
  %op2925 = sub i64 %v2924, 1
  store i64 %op2925, ptr %slot548, align 8
  %v2926 = load i64, ptr %slot548, align 8
  %cmp2927 = icmp eq i64 %v2926, 0
  %cv2928 = zext i1 %cmp2927 to i32
  store i32 %cv2928, ptr %slot549, align 8
  %v2929 = load i32, ptr %slot549, align 8
  %cv2930 = zext i32 %v2929 to i64
  %cond2931 = icmp ne i64 %cv2930, 0
  br i1 %cond2931, label %bb_rcglast840, label %bb_rcgdec840
bb_rcglast840:
  %v2932 = load i64, ptr %slot540, align 8
  %op2933 = sub i64 %v2932, 32
  store i64 %op2933, ptr %slot550, align 8
  %v2934 = load i64, ptr %slot540, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  %rgep2936 = getelementptr i8, ptr %p2935, i64 -32
  %ld2937 = load i64, ptr %rgep2936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2937, ptr %slot551, align 8
  %v2938 = load i64, ptr %slot551, align 8
  %cmp2939 = icmp ne i64 %v2938, 0
  %cv2940 = zext i1 %cmp2939 to i32
  store i32 %cv2940, ptr %slot552, align 8
  %v2941 = load i32, ptr %slot552, align 8
  %cv2942 = zext i32 %v2941 to i64
  %cond2943 = icmp ne i64 %cv2942, 0
  br i1 %cond2943, label %bb_rcgdec840, label %bb_rcgslow840
bb_rcgslow840:
  %v2944 = load i64, ptr %slot539, align 8
  %v2945 = load i64, ptr %slot536, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v2944, i64 %v2945) nomerge, !dbg !136
  br label %bb_rcgdone840
bb_rcgdec840:
  %v2946 = load i64, ptr %slot548, align 8
  %v2947 = load i64, ptr %slot540, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %rgep2949 = getelementptr i8, ptr %p2948, i64 -24
  store i64 %v2946, ptr %rgep2949, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear840
bb_rcgclear840:
  %v2950 = load i64, ptr %slot536, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  store i64 0, ptr %p2951, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone840
bb_rcgdone840:
  br label %bb_rcslotdone824
bb_rcslotowner824:
  %v2952 = load i64, ptr %slot29, align 8
  store i64 %v2952, ptr %slot553, align 8
  %v2953 = load i64, ptr %slot536, align 8
  %p2954 = inttoptr i64 %v2953 to ptr
  %ld2955 = load i64, ptr %p2954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2955, ptr %slot554, align 8
  %v2956 = load i64, ptr %slot554, align 8
  %cmp2957 = icmp ne i64 %v2956, 0
  %cv2958 = zext i1 %cmp2957 to i32
  store i32 %cv2958, ptr %slot555, align 8
  %v2959 = load i32, ptr %slot555, align 8
  %cv2960 = zext i32 %v2959 to i64
  %cond2961 = icmp ne i64 %cv2960, 0
  br i1 %cond2961, label %bb_rcgnn855, label %bb_rcgdone855
bb_rcgnn855:
  %v2962 = load i64, ptr %slot554, align 8
  %op2963 = sub i64 %v2962, 16
  store i64 %op2963, ptr %slot556, align 8
  %v2964 = load i64, ptr %slot554, align 8
  %p2965 = inttoptr i64 %v2964 to ptr
  %rgep2966 = getelementptr i8, ptr %p2965, i64 -16
  %ld2967 = load i64, ptr %rgep2966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2967, ptr %slot557, align 8
  %v2968 = load i64, ptr %slot557, align 8
  %op2969 = and i64 %v2968, 4611686018427387906
  store i64 %op2969, ptr %slot558, align 8
  %v2970 = load i64, ptr %slot558, align 8
  %cmp2971 = icmp ne i64 %v2970, 0
  %cv2972 = zext i1 %cmp2971 to i32
  store i32 %cv2972, ptr %slot559, align 8
  %v2973 = load i32, ptr %slot559, align 8
  %cv2974 = zext i32 %v2973 to i64
  %cond2975 = icmp ne i64 %cv2974, 0
  br i1 %cond2975, label %bb_rcgclear855, label %bb_rcgcounted855
bb_rcgcounted855:
  %v2976 = load i64, ptr %slot554, align 8
  %op2977 = sub i64 %v2976, 32
  store i64 %op2977, ptr %slot560, align 8
  %v2978 = load i64, ptr %slot554, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %rgep2980 = getelementptr i8, ptr %p2979, i64 -32
  %ld2981 = load i64, ptr %rgep2980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2981, ptr %slot561, align 8
  %v2982 = load i64, ptr %slot561, align 8
  %op2983 = sub i64 %v2982, 1
  store i64 %op2983, ptr %slot562, align 8
  %v2984 = load i64, ptr %slot562, align 8
  %cmp2985 = icmp eq i64 %v2984, 0
  %cv2986 = zext i1 %cmp2985 to i32
  store i32 %cv2986, ptr %slot563, align 8
  %v2987 = load i32, ptr %slot563, align 8
  %cv2988 = zext i32 %v2987 to i64
  %cond2989 = icmp ne i64 %cv2988, 0
  br i1 %cond2989, label %bb_rcglast855, label %bb_rcgdec855
bb_rcglast855:
  %v2990 = load i64, ptr %slot554, align 8
  %op2991 = sub i64 %v2990, 24
  store i64 %op2991, ptr %slot564, align 8
  %v2992 = load i64, ptr %slot554, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  %rgep2994 = getelementptr i8, ptr %p2993, i64 -24
  %ld2995 = load i64, ptr %rgep2994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2995, ptr %slot565, align 8
  %v2996 = load i64, ptr %slot565, align 8
  %cmp2997 = icmp ne i64 %v2996, 0
  %cv2998 = zext i1 %cmp2997 to i32
  store i32 %cv2998, ptr %slot566, align 8
  %v2999 = load i32, ptr %slot566, align 8
  %cv3000 = zext i32 %v2999 to i64
  %cond3001 = icmp ne i64 %cv3000, 0
  br i1 %cond3001, label %bb_rcgdec855, label %bb_rcgslow855
bb_rcgslow855:
  %v3002 = load i64, ptr %slot553, align 8
  %v3003 = load i64, ptr %slot536, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3002, i64 %v3003) nomerge, !dbg !136
  br label %bb_rcgdone855
bb_rcgdec855:
  %v3004 = load i64, ptr %slot562, align 8
  %v3005 = load i64, ptr %slot554, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  %rgep3007 = getelementptr i8, ptr %p3006, i64 -32
  store i64 %v3004, ptr %rgep3007, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear855
bb_rcgclear855:
  %v3008 = load i64, ptr %slot536, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i64 0, ptr %p3009, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone855
bb_rcgdone855:
  br label %bb_rcslotdone824
bb_rcslotdone824:
  %v3010 = load i64, ptr %slot22, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i64 0, ptr %p3011, align 8, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot22, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i64 0, ptr %p3013, align 8, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot22, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  %ld3016 = load i64, ptr %p3015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3016, ptr %slot567, align 8
  %v3017 = load i64, ptr %slot8, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  %ld3019 = load i32, ptr %p3018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3019, ptr %slot568, align 8
  %v3020 = load i32, ptr %slot568, align 8
  %cv3021 = zext i32 %v3020 to i64
  %cond3022 = icmp ne i64 %cv3021, 0
  br i1 %cond3022, label %bb_rcslotdrop862, label %bb_rcslotdone862
bb_rcslotdrop862:
  %v3023 = load i64, ptr %slot8, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  store i32 0, ptr %p3024, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone862
bb_rcslotdone862:
  %v3025 = load i64, ptr %slot6, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  %ld3027 = load i32, ptr %p3026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3027, ptr %slot569, align 8
  %v3028 = load i32, ptr %slot569, align 8
  %cv3029 = zext i32 %v3028 to i64
  %cond3030 = icmp ne i64 %cv3029, 0
  br i1 %cond3030, label %bb_rcslotdrop865, label %bb_rcslotdone865
bb_rcslotdrop865:
  %v3031 = load i64, ptr %slot6, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  store i32 0, ptr %p3032, align 4, !alias.scope !3, !noalias !4
  %v3033 = load i64, ptr %slot21, align 8
  store i64 %v3033, ptr %slot570, align 8
  %v3034 = load i64, ptr %slot7, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  %ld3036 = load i32, ptr %p3035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3036, ptr %slot571, align 8
  %v3037 = load i32, ptr %slot571, align 8
  %op3038 = and i32 %v3037, 28
  store i32 %op3038, ptr %slot572, align 8
  %v3039 = load i32, ptr %slot572, align 8
  %cv3040 = zext i32 %v3039 to i64
  %cond3041 = icmp ne i64 %cv3040, 0
  br i1 %cond3041, label %bb_rcslotrole865, label %bb_rcslotowner865
bb_rcslotrole865:
  %v3042 = load i64, ptr %slot29, align 8
  store i64 %v3042, ptr %slot573, align 8
  %v3043 = load i64, ptr %slot570, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %ld3045 = load i64, ptr %p3044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3045, ptr %slot574, align 8
  %v3046 = load i64, ptr %slot574, align 8
  %cmp3047 = icmp ne i64 %v3046, 0
  %cv3048 = zext i1 %cmp3047 to i32
  store i32 %cv3048, ptr %slot575, align 8
  %v3049 = load i32, ptr %slot575, align 8
  %cv3050 = zext i32 %v3049 to i64
  %cond3051 = icmp ne i64 %cv3050, 0
  br i1 %cond3051, label %bb_rcgnn881, label %bb_rcgdone881
bb_rcgnn881:
  %v3052 = load i64, ptr %slot574, align 8
  %op3053 = sub i64 %v3052, 16
  store i64 %op3053, ptr %slot576, align 8
  %v3054 = load i64, ptr %slot574, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  %rgep3056 = getelementptr i8, ptr %p3055, i64 -16
  %ld3057 = load i64, ptr %rgep3056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3057, ptr %slot577, align 8
  %v3058 = load i64, ptr %slot577, align 8
  %op3059 = and i64 %v3058, 4611686018427387906
  store i64 %op3059, ptr %slot578, align 8
  %v3060 = load i64, ptr %slot578, align 8
  %cmp3061 = icmp ne i64 %v3060, 0
  %cv3062 = zext i1 %cmp3061 to i32
  store i32 %cv3062, ptr %slot579, align 8
  %v3063 = load i32, ptr %slot579, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcgclear881, label %bb_rcgcounted881
bb_rcgcounted881:
  %v3066 = load i64, ptr %slot574, align 8
  %op3067 = sub i64 %v3066, 24
  store i64 %op3067, ptr %slot580, align 8
  %v3068 = load i64, ptr %slot574, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -24
  %ld3071 = load i64, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3071, ptr %slot581, align 8
  %v3072 = load i64, ptr %slot581, align 8
  %op3073 = sub i64 %v3072, 1
  store i64 %op3073, ptr %slot582, align 8
  %v3074 = load i64, ptr %slot582, align 8
  %cmp3075 = icmp eq i64 %v3074, 0
  %cv3076 = zext i1 %cmp3075 to i32
  store i32 %cv3076, ptr %slot583, align 8
  %v3077 = load i32, ptr %slot583, align 8
  %cv3078 = zext i32 %v3077 to i64
  %cond3079 = icmp ne i64 %cv3078, 0
  br i1 %cond3079, label %bb_rcglast881, label %bb_rcgdec881
bb_rcglast881:
  %v3080 = load i64, ptr %slot574, align 8
  %op3081 = sub i64 %v3080, 32
  store i64 %op3081, ptr %slot584, align 8
  %v3082 = load i64, ptr %slot574, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %rgep3084 = getelementptr i8, ptr %p3083, i64 -32
  %ld3085 = load i64, ptr %rgep3084, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3085, ptr %slot585, align 8
  %v3086 = load i64, ptr %slot585, align 8
  %cmp3087 = icmp ne i64 %v3086, 0
  %cv3088 = zext i1 %cmp3087 to i32
  store i32 %cv3088, ptr %slot586, align 8
  %v3089 = load i32, ptr %slot586, align 8
  %cv3090 = zext i32 %v3089 to i64
  %cond3091 = icmp ne i64 %cv3090, 0
  br i1 %cond3091, label %bb_rcgdec881, label %bb_rcgslow881
bb_rcgslow881:
  %v3092 = load i64, ptr %slot573, align 8
  %v3093 = load i64, ptr %slot570, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64 %v3092, i64 %v3093) nomerge, !dbg !138
  br label %bb_rcgdone881
bb_rcgdec881:
  %v3094 = load i64, ptr %slot582, align 8
  %v3095 = load i64, ptr %slot574, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  %rgep3097 = getelementptr i8, ptr %p3096, i64 -24
  store i64 %v3094, ptr %rgep3097, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear881
bb_rcgclear881:
  %v3098 = load i64, ptr %slot570, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  store i64 0, ptr %p3099, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone881
bb_rcgdone881:
  br label %bb_rcslotdone865
bb_rcslotowner865:
  %v3100 = load i64, ptr %slot29, align 8
  store i64 %v3100, ptr %slot587, align 8
  %v3101 = load i64, ptr %slot570, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i64, ptr %p3102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3103, ptr %slot588, align 8
  %v3104 = load i64, ptr %slot588, align 8
  %cmp3105 = icmp ne i64 %v3104, 0
  %cv3106 = zext i1 %cmp3105 to i32
  store i32 %cv3106, ptr %slot589, align 8
  %v3107 = load i32, ptr %slot589, align 8
  %cv3108 = zext i32 %v3107 to i64
  %cond3109 = icmp ne i64 %cv3108, 0
  br i1 %cond3109, label %bb_rcgnn896, label %bb_rcgdone896
bb_rcgnn896:
  %v3110 = load i64, ptr %slot588, align 8
  %op3111 = sub i64 %v3110, 16
  store i64 %op3111, ptr %slot590, align 8
  %v3112 = load i64, ptr %slot588, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  %rgep3114 = getelementptr i8, ptr %p3113, i64 -16
  %ld3115 = load i64, ptr %rgep3114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3115, ptr %slot591, align 8
  %v3116 = load i64, ptr %slot591, align 8
  %op3117 = and i64 %v3116, 4611686018427387906
  store i64 %op3117, ptr %slot592, align 8
  %v3118 = load i64, ptr %slot592, align 8
  %cmp3119 = icmp ne i64 %v3118, 0
  %cv3120 = zext i1 %cmp3119 to i32
  store i32 %cv3120, ptr %slot593, align 8
  %v3121 = load i32, ptr %slot593, align 8
  %cv3122 = zext i32 %v3121 to i64
  %cond3123 = icmp ne i64 %cv3122, 0
  br i1 %cond3123, label %bb_rcgclear896, label %bb_rcgcounted896
bb_rcgcounted896:
  %v3124 = load i64, ptr %slot588, align 8
  %op3125 = sub i64 %v3124, 32
  store i64 %op3125, ptr %slot594, align 8
  %v3126 = load i64, ptr %slot588, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %rgep3128 = getelementptr i8, ptr %p3127, i64 -32
  %ld3129 = load i64, ptr %rgep3128, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3129, ptr %slot595, align 8
  %v3130 = load i64, ptr %slot595, align 8
  %op3131 = sub i64 %v3130, 1
  store i64 %op3131, ptr %slot596, align 8
  %v3132 = load i64, ptr %slot596, align 8
  %cmp3133 = icmp eq i64 %v3132, 0
  %cv3134 = zext i1 %cmp3133 to i32
  store i32 %cv3134, ptr %slot597, align 8
  %v3135 = load i32, ptr %slot597, align 8
  %cv3136 = zext i32 %v3135 to i64
  %cond3137 = icmp ne i64 %cv3136, 0
  br i1 %cond3137, label %bb_rcglast896, label %bb_rcgdec896
bb_rcglast896:
  %v3138 = load i64, ptr %slot588, align 8
  %op3139 = sub i64 %v3138, 24
  store i64 %op3139, ptr %slot598, align 8
  %v3140 = load i64, ptr %slot588, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  %rgep3142 = getelementptr i8, ptr %p3141, i64 -24
  %ld3143 = load i64, ptr %rgep3142, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3143, ptr %slot599, align 8
  %v3144 = load i64, ptr %slot599, align 8
  %cmp3145 = icmp ne i64 %v3144, 0
  %cv3146 = zext i1 %cmp3145 to i32
  store i32 %cv3146, ptr %slot600, align 8
  %v3147 = load i32, ptr %slot600, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_rcgdec896, label %bb_rcgslow896
bb_rcgslow896:
  %v3150 = load i64, ptr %slot587, align 8
  %v3151 = load i64, ptr %slot570, align 8
  call void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64 %v3150, i64 %v3151) nomerge, !dbg !138
  br label %bb_rcgdone896
bb_rcgdec896:
  %v3152 = load i64, ptr %slot596, align 8
  %v3153 = load i64, ptr %slot588, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %rgep3155 = getelementptr i8, ptr %p3154, i64 -32
  store i64 %v3152, ptr %rgep3155, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear896
bb_rcgclear896:
  %v3156 = load i64, ptr %slot570, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  store i64 0, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone896
bb_rcgdone896:
  br label %bb_rcslotdone865
bb_rcslotdone865:
  %v3158 = load i64, ptr %slot4, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %ld3160 = load i32, ptr %p3159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3160, ptr %slot601, align 8
  %v3161 = load i32, ptr %slot601, align 8
  %cv3162 = zext i32 %v3161 to i64
  %cond3163 = icmp ne i64 %cv3162, 0
  br i1 %cond3163, label %bb_rcslotdrop902, label %bb_rcslotdone902
bb_rcslotdrop902:
  %v3164 = load i64, ptr %slot4, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  store i32 0, ptr %p3165, align 4, !alias.scope !3, !noalias !4
  %v3166 = load i64, ptr %slot20, align 8
  store i64 %v3166, ptr %slot602, align 8
  %v3167 = load i64, ptr %slot5, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  %ld3169 = load i32, ptr %p3168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3169, ptr %slot603, align 8
  %v3170 = load i32, ptr %slot603, align 8
  %op3171 = and i32 %v3170, 28
  store i32 %op3171, ptr %slot604, align 8
  %v3172 = load i32, ptr %slot604, align 8
  %cv3173 = zext i32 %v3172 to i64
  %cond3174 = icmp ne i64 %cv3173, 0
  br i1 %cond3174, label %bb_rcslotrole902, label %bb_rcslotowner902
bb_rcslotrole902:
  %v3175 = load i64, ptr %slot29, align 8
  store i64 %v3175, ptr %slot605, align 8
  %v3176 = load i64, ptr %slot605, align 8
  %v3177 = load i64, ptr %slot602, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v3176, i64 %v3177) nomerge, !dbg !138
  br label %bb_rcslotdone902
bb_rcslotowner902:
  %v3178 = load i64, ptr %slot29, align 8
  store i64 %v3178, ptr %slot606, align 8
  %v3179 = load i64, ptr %slot606, align 8
  %v3180 = load i64, ptr %slot602, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v3179, i64 %v3180) nomerge, !dbg !138
  br label %bb_rcslotdone902
bb_rcslotdone902:
  %v3181 = load i64, ptr %slot567, align 8
  ret i64 %v3181
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_81786d41e92353c0bb143ae35a2c48e6baec4e0acc76bc3b9195ca1c2055e4a5(i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i64 @myl_qbe_stream_write_bytes(ptr, i64, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_drop(i64, i64)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd", linkageName: "myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15918801163204952314, i64 0, !"myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!120 = !DILocation(line: 13, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!124 = !DILocation(line: 20, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!126 = !DILocation(line: 22, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!128 = !DILocation(line: 23, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!130 = !DILocation(line: 25, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!132 = !DILocation(line: 27, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!134 = !DILocation(line: 31, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!136 = !DILocation(line: 32, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!138 = !DILocation(line: 36, column: 0, scope: !139)
