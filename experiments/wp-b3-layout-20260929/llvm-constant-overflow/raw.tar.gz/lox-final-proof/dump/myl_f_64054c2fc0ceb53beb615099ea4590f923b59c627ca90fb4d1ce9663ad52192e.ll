target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_64054c2fc0ceb53beb615099ea4590f923b59c627ca90fb4d1ce9663ad52192e(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v61 = load i64, ptr %slot1, align 8
  %op62 = add i64 %v61, 32
  store i64 %op62, ptr %slot5, align 8
  %mem63 = alloca i8, i64 8, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot6, align 8
  %mem65 = alloca i8, i64 8, align 8
  %ptr66 = ptrtoint ptr %mem65 to i64
  store i64 %ptr66, ptr %slot7, align 8
  %mem67 = alloca i8, i64 8, align 8
  %ptr68 = ptrtoint ptr %mem67 to i64
  store i64 %ptr68, ptr %slot8, align 8
  %mem69 = alloca i8, i64 8, align 8
  %ptr70 = ptrtoint ptr %mem69 to i64
  store i64 %ptr70, ptr %slot9, align 8
  %mem71 = alloca i8, i64 8, align 8
  %ptr72 = ptrtoint ptr %mem71 to i64
  store i64 %ptr72, ptr %slot10, align 8
  %mem73 = alloca i8, i64 8, align 8
  %ptr74 = ptrtoint ptr %mem73 to i64
  store i64 %ptr74, ptr %slot11, align 8
  %mem75 = alloca i8, i64 8, align 8
  %ptr76 = ptrtoint ptr %mem75 to i64
  store i64 %ptr76, ptr %slot12, align 8
  %v77 = load i64, ptr %slot2, align 8
  %v78 = load i64, ptr %slot6, align 8
  %p79 = inttoptr i64 %v78 to ptr
  store i64 %v77, ptr %p79, align 8, !alias.scope !3, !noalias !4
  %v80 = load i64, ptr %slot3, align 8
  %v81 = load i64, ptr %slot7, align 8
  %p82 = inttoptr i64 %v81 to ptr
  store i64 %v80, ptr %p82, align 8, !alias.scope !3, !noalias !4
  %v83 = load i64, ptr %slot4, align 8
  %v84 = load i64, ptr %slot8, align 8
  %p85 = inttoptr i64 %v84 to ptr
  store i64 %v83, ptr %p85, align 8, !alias.scope !3, !noalias !4
  %v86 = load i64, ptr %slot1, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %call88 = call ptr @myl_qbe_heap(ptr %p87) nomerge, !dbg !110
  %calladdr89 = ptrtoint ptr %call88 to i64
  store i64 %calladdr89, ptr %slot13, align 8
  br label %bb_i0
bb_i0:
  %v90 = load i64, ptr %slot7, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot14, align 8
  %v93 = load i64, ptr %slot14, align 8
  %v94 = load i64, ptr %slot9, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot8, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot15, align 8
  %v99 = load i64, ptr %slot15, align 8
  %v100 = load i64, ptr %slot10, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 %v99, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot10, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld104, ptr %slot16, align 8
  %v105 = load i64, ptr %slot16, align 8
  %op106 = add i64 %v105, 8
  store i64 %op106, ptr %slot17, align 8
  %v107 = load i64, ptr %slot17, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !4, !noalias !3
  store i64 %ld109, ptr %slot18, align 8
  %v110 = load i64, ptr %slot18, align 8
  %v111 = load i64, ptr %slot10, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i64 %v110, ptr %p112, align 8, !alias.scope !3, !noalias !4
  %v113 = load i64, ptr %slot8, align 8
  %p114 = inttoptr i64 %v113 to ptr
  %ld115 = load i64, ptr %p114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld115, ptr %slot19, align 8
  %v116 = load i64, ptr %slot19, align 8
  %v117 = load i64, ptr %slot11, align 8
  %p118 = inttoptr i64 %v117 to ptr
  store i64 %v116, ptr %p118, align 8, !alias.scope !3, !noalias !4
  %v119 = load i64, ptr %slot11, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i64, ptr %p120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld121, ptr %slot20, align 8
  %v122 = load i64, ptr %slot20, align 8
  %op123 = add i64 %v122, 8
  store i64 %op123, ptr %slot21, align 8
  %v124 = load i64, ptr %slot21, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !4, !noalias !3
  store i64 %ld126, ptr %slot22, align 8
  %v127 = load i64, ptr %slot22, align 8
  %v128 = load i64, ptr %slot11, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i64 %v127, ptr %p129, align 8, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot8, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %ld132 = load i64, ptr %p131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld132, ptr %slot23, align 8
  %v133 = load i64, ptr %slot23, align 8
  %v134 = load i64, ptr %slot12, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i64 %v133, ptr %p135, align 8, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot12, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld138, ptr %slot24, align 8
  %v139 = load i64, ptr %slot24, align 8
  %op140 = add i64 %v139, 16
  store i64 %op140, ptr %slot25, align 8
  %v141 = load i64, ptr %slot25, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !4, !noalias !3
  store i64 %ld143, ptr %slot26, align 8
  %v144 = load i64, ptr %slot26, align 8
  %v145 = load i64, ptr %slot12, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot12, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot27, align 8
  %v150 = load i64, ptr %slot11, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot28, align 8
  %v153 = load i64, ptr %slot28, align 8
  %v154 = load i64, ptr %slot27, align 8
  %ovpair156 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v153, i64 %v154)
  %op155 = extractvalue { i64, i1 } %ovpair156, 0
  %ov157 = extractvalue { i64, i1 } %ovpair156, 1
  store i64 %op155, ptr %slot29, align 8
  %v158 = load i64, ptr %slot28, align 8
  %v159 = load i64, ptr %slot29, align 8
  %op160 = xor i64 %v158, %v159
  store i64 %op160, ptr %slot30, align 8
  %v161 = load i64, ptr %slot27, align 8
  %v162 = load i64, ptr %slot29, align 8
  %op163 = xor i64 %v161, %v162
  store i64 %op163, ptr %slot31, align 8
  %v164 = load i64, ptr %slot30, align 8
  %v165 = load i64, ptr %slot31, align 8
  %op166 = and i64 %v164, %v165
  store i64 %op166, ptr %slot32, align 8
  %cv167 = zext i1 %ov157 to i64
  store i64 %cv167, ptr %slot33, align 8
  %v168 = load i64, ptr %slot33, align 8
  %cond169 = icmp ne i64 %v168, 0
  br i1 %cond169, label %bb_overflow45, label %bb_checked45
bb_overflow45:
  %v170 = load i64, ptr %slot1, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %v172 = load i64, ptr %slot28, align 8
  %v173 = load i64, ptr %slot27, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p171, i64 0, i64 %v172, i64 %v173, i64 64) nomerge, !dbg !112
  unreachable
bb_checked45:
  %v174 = load i64, ptr %slot29, align 8
  %v175 = load i64, ptr %slot11, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot6, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot34, align 8
  %v180 = load i64, ptr %slot9, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot35, align 8
  %v183 = load i64, ptr %slot10, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot36, align 8
  %v186 = load i64, ptr %slot11, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld188, ptr %slot37, align 8
  %v189 = load i64, ptr %slot34, align 8
  %op190 = add i64 %v189, 8
  store i64 %op190, ptr %slot38, align 8
  %v191 = load i64, ptr %slot36, align 8
  %cmp192 = icmp sge i64 %v191, 0
  %cv193 = zext i1 %cmp192 to i64
  store i64 %cv193, ptr %slot39, align 8
  %v194 = load i64, ptr %slot39, align 8
  %cond195 = icmp ne i64 %v194, 0
  br i1 %cond195, label %bb_buf_start55, label %bb_buf_refused55
bb_buf_start55:
  %v196 = load i64, ptr %slot36, align 8
  %v197 = load i64, ptr %slot37, align 8
  %cmp198 = icmp sle i64 %v196, %v197
  %cv199 = zext i1 %cmp198 to i64
  store i64 %cv199, ptr %slot40, align 8
  %v200 = load i64, ptr %slot40, align 8
  %cond201 = icmp ne i64 %v200, 0
  br i1 %cond201, label %bb_buf_order55, label %bb_buf_refused55
bb_buf_order55:
  %v202 = load i64, ptr %slot35, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !6, !noalias !7
  store i64 %ld204, ptr %slot41, align 8
  %v205 = load i64, ptr %slot37, align 8
  %v206 = load i64, ptr %slot41, align 8
  %cmp207 = icmp ule i64 %v205, %v206
  %cv208 = zext i1 %cmp207 to i64
  store i64 %cv208, ptr %slot42, align 8
  %v209 = load i64, ptr %slot42, align 8
  %cond210 = icmp ne i64 %v209, 0
  br i1 %cond210, label %bb_buf_bound55, label %bb_buf_refused55
bb_buf_bound55:
  %v211 = load i64, ptr %slot34, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %ld213 = load i64, ptr %p212, align 8, !alias.scope !6, !noalias !7
  store i64 %ld213, ptr %slot43, align 8
  %v214 = load i64, ptr %slot38, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !6, !noalias !7
  store i64 %ld216, ptr %slot44, align 8
  %v217 = load i64, ptr %slot37, align 8
  %v218 = load i64, ptr %slot36, align 8
  %op219 = sub i64 %v217, %v218
  store i64 %op219, ptr %slot45, align 8
  %v220 = load i64, ptr %slot44, align 8
  %v221 = load i64, ptr %slot43, align 8
  %op222 = sub i64 %v220, %v221
  store i64 %op222, ptr %slot46, align 8
  %v223 = load i64, ptr %slot45, align 8
  %v224 = load i64, ptr %slot46, align 8
  %cmp225 = icmp ult i64 %v223, %v224
  %cv226 = zext i1 %cmp225 to i64
  store i64 %cv226, ptr %slot47, align 8
  %v227 = load i64, ptr %slot47, align 8
  %cond228 = icmp ne i64 %v227, 0
  br i1 %cond228, label %bb_buf_fast55, label %bb_buf_slow55
bb_buf_slow55:
  %v229 = load i64, ptr %slot13, align 8
  %p230 = inttoptr i64 %v229 to ptr
  %v231 = load i64, ptr %slot34, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %v233 = load i64, ptr %slot35, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %v235 = load i64, ptr %slot36, align 8
  %v236 = load i64, ptr %slot37, align 8
  %call237 = call i32 @myl_native_bytes_buffer_append_range(ptr %p230, ptr %p232, ptr %p234, i64 %v235, i64 %v236) nomerge, !dbg !114
  store i32 %call237, ptr %slot48, align 8
  %v238 = load i32, ptr %slot48, align 8
  %ext239 = zext i32 %v238 to i64
  store i64 %ext239, ptr %slot49, align 8
  %v240 = load i64, ptr %slot49, align 8
  %cmp241 = icmp ne i64 %v240, 0
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot50, align 8
  %v243 = load i64, ptr %slot50, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_success69, label %bb_failed69
bb_failed69:
  %v245 = load i64, ptr %slot1, align 8
  %p246 = inttoptr i64 %v245 to ptr
  call void @myl_qbe_fail_allocation(ptr %p246) nomerge, !dbg !114
  unreachable
bb_success69:
  %v247 = load i32, ptr %slot48, align 8
  %cmp248 = icmp eq i32 %v247, 1
  %cv249 = zext i1 %cmp248 to i32
  store i32 %cv249, ptr %slot51, align 8
  %v250 = load i32, ptr %slot51, align 8
  %ext251 = zext i32 %v250 to i64
  store i64 %ext251, ptr %slot52, align 8
  %v252 = load i64, ptr %slot52, align 8
  %v253 = load i64, ptr %slot9, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i64 %v252, ptr %p254, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done55
bb_buf_fast55:
  %v255 = load i64, ptr %slot34, align 8
  %op256 = add i64 %v255, 32
  store i64 %op256, ptr %slot53, align 8
  %v257 = load i64, ptr %slot35, align 8
  %op258 = add i64 %v257, 32
  store i64 %op258, ptr %slot54, align 8
  %v259 = load i64, ptr %slot53, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !6, !noalias !7
  store i64 %ld261, ptr %slot55, align 8
  %v262 = load i64, ptr %slot55, align 8
  %v263 = load i64, ptr %slot43, align 8
  %op264 = add i64 %v262, %v263
  store i64 %op264, ptr %slot56, align 8
  %v265 = load i64, ptr %slot54, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !6, !noalias !7
  store i64 %ld267, ptr %slot57, align 8
  %v268 = load i64, ptr %slot57, align 8
  %v269 = load i64, ptr %slot36, align 8
  %op270 = add i64 %v268, %v269
  store i64 %op270, ptr %slot58, align 8
  %v271 = load i64, ptr %slot56, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %v273 = load i64, ptr %slot58, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %v275 = load i64, ptr %slot45, align 8
  call void @myl_native_bytes_copy_octets(ptr %p272, ptr %p274, i64 %v275) nomerge, !dbg !114
  %v276 = load i64, ptr %slot43, align 8
  %v277 = load i64, ptr %slot45, align 8
  %op278 = add i64 %v276, %v277
  store i64 %op278, ptr %slot59, align 8
  %v279 = load i64, ptr %slot59, align 8
  %v280 = load i64, ptr %slot34, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !6, !noalias !7
  %v282 = load i64, ptr %slot9, align 8
  %p283 = inttoptr i64 %v282 to ptr
  store i64 1, ptr %p283, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done55
bb_buf_refused55:
  %v284 = load i64, ptr %slot9, align 8
  %p285 = inttoptr i64 %v284 to ptr
  store i64 0, ptr %p285, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done55
bb_buf_done55:
  %v286 = load i64, ptr %slot9, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 0, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot9, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot60, align 8
  %v291 = load i64, ptr %slot60, align 8
  ret i64 %v291
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare i32 @myl_native_bytes_buffer_append_range(ptr, ptr, ptr, i64, i64)
declare void @myl_native_bytes_copy_octets(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_64054c2fc0ceb53beb615099ea4590f923b59c627ca90fb4d1ce9663ad52192e", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_64054c2fc0ceb53beb615099ea4590f923b59c627ca90fb4d1ce9663ad52192e", linkageName: "myl_f_64054c2fc0ceb53beb615099ea4590f923b59c627ca90fb4d1ce9663ad52192e", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3263592274347675013, i64 0, !"myl_f_64054c2fc0ceb53beb615099ea4590f923b59c627ca90fb4d1ce9663ad52192e"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!114 = !DILocation(line: 9, column: 0, scope: !115)
